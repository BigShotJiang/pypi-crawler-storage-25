"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};

// node/playwright-wrapper/index.ts
var import_grpc_js3 = require("@grpc/grpc-js");

// node/playwright-wrapper/browser_logger.ts
var import_pino = require("pino");
var _seq = 0;
var currentRFContext = {};
var _kwContextStack = [];
function setRFKeywordContext(ctx) {
  _kwContextStack.push({
    kw_name: currentRFContext.kw_name,
    kw_file: currentRFContext.kw_file,
    kw_line: currentRFContext.kw_line
  });
  if (ctx.kw_name !== void 0) {
    currentRFContext.kw_name = ctx.kw_name;
  } else {
    delete currentRFContext.kw_name;
  }
  if (ctx.kw_file !== void 0) {
    currentRFContext.kw_file = ctx.kw_file;
  } else {
    delete currentRFContext.kw_file;
  }
  if (ctx.kw_line !== void 0) {
    currentRFContext.kw_line = ctx.kw_line;
  } else {
    delete currentRFContext.kw_line;
  }
}
function clearRFKeywordContext() {
  const prev = _kwContextStack.pop();
  if (prev) {
    if (prev.kw_name !== void 0) {
      currentRFContext.kw_name = prev.kw_name;
    } else {
      delete currentRFContext.kw_name;
    }
    if (prev.kw_file !== void 0) {
      currentRFContext.kw_file = prev.kw_file;
    } else {
      delete currentRFContext.kw_file;
    }
    if (prev.kw_line !== void 0) {
      currentRFContext.kw_line = prev.kw_line;
    } else {
      delete currentRFContext.kw_line;
    }
  } else {
    delete currentRFContext.kw_name;
    delete currentRFContext.kw_file;
    delete currentRFContext.kw_line;
  }
}
function setRFTestContext(testId, testName) {
  if (testId) {
    currentRFContext.test_id = testId;
  } else {
    delete currentRFContext.test_id;
  }
  if (testName) {
    currentRFContext.test_name = testName;
  } else {
    delete currentRFContext.test_name;
  }
}
function setRFSuiteContext(suiteId, suiteName) {
  if (suiteId) {
    currentRFContext.suite_id = suiteId;
  } else {
    delete currentRFContext.suite_id;
  }
  if (suiteName) {
    currentRFContext.suite_name = suiteName;
  } else {
    delete currentRFContext.suite_name;
  }
}
function errorType(e) {
  return e instanceof Error ? e.constructor.name : "UnknownError";
}
function createLogger(destination) {
  return (0, import_pino.pino)(
    {
      timestamp: import_pino.stdTimeFunctions.isoTime,
      level: process.env.ROBOT_FRAMEWORK_BROWSER_PINO_LOG_LEVEL || "info",
      base: null,
      formatters: {
        level(label) {
          return { level: label };
        }
      },
      mixin() {
        const { kw_name, kw_file, kw_line, test_id, test_name, suite_id, suite_name } = currentRFContext;
        return {
          seq: ++_seq,
          ...suite_id !== void 0 && { suite_id },
          ...suite_name !== void 0 && { suite_name },
          ...test_name !== void 0 && { test_name },
          ...kw_name !== void 0 && { kw_name },
          ...kw_file !== void 0 && { kw_file },
          ...kw_line !== void 0 && { kw_line },
          ...test_id !== void 0 && { test_id },
          component: "browser-library"
        };
      }
    },
    destination ?? process.stdout
  );
}
var logger = createLogger();

// node/playwright-wrapper/generated/playwright.ts
var import_wire = require("@bufbuild/protobuf/wire");
var import_grpc_js = require("@grpc/grpc-js");
function createBaseRequest_Empty() {
  return {};
}
var Request_Empty = {
  encode(_, writer = new import_wire.BinaryWriter()) {
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Empty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(_) {
    return {};
  },
  toJSON(_) {
    const obj = {};
    return obj;
  },
  create(base) {
    return Request_Empty.fromPartial(base ?? {});
  },
  fromPartial(_) {
    const message = createBaseRequest_Empty();
    return message;
  }
};
function createBaseRequest_AriaSnapShot() {
  return { locator: "", strict: false };
}
var Request_AriaSnapShot = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.locator !== "") {
      writer.uint32(10).string(message.locator);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AriaSnapShot();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.locator = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      locator: isSet(object.locator) ? globalThis.String(object.locator) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.locator !== "") {
      obj.locator = message.locator;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_AriaSnapShot.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AriaSnapShot();
    message.locator = object.locator ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ClosePage() {
  return { runBeforeUnload: false };
}
var Request_ClosePage = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.runBeforeUnload !== false) {
      writer.uint32(8).bool(message.runBeforeUnload);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClosePage();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.runBeforeUnload = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { runBeforeUnload: isSet(object.runBeforeUnload) ? globalThis.Boolean(object.runBeforeUnload) : false };
  },
  toJSON(message) {
    const obj = {};
    if (message.runBeforeUnload !== false) {
      obj.runBeforeUnload = message.runBeforeUnload;
    }
    return obj;
  },
  create(base) {
    return Request_ClosePage.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClosePage();
    message.runBeforeUnload = object.runBeforeUnload ?? false;
    return message;
  }
};
function createBaseRequest_ClockSetTime() {
  return { time: 0, setType: "" };
}
var Request_ClockSetTime = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.time !== 0) {
      writer.uint32(8).int32(message.time);
    }
    if (message.setType !== "") {
      writer.uint32(18).string(message.setType);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClockSetTime();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.time = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.setType = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      time: isSet(object.time) ? globalThis.Number(object.time) : 0,
      setType: isSet(object.setType) ? globalThis.String(object.setType) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.time !== 0) {
      obj.time = Math.round(message.time);
    }
    if (message.setType !== "") {
      obj.setType = message.setType;
    }
    return obj;
  },
  create(base) {
    return Request_ClockSetTime.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClockSetTime();
    message.time = object.time ?? 0;
    message.setType = object.setType ?? "";
    return message;
  }
};
function createBaseRequest_ClockAdvance() {
  return { time: 0, advanceType: "" };
}
var Request_ClockAdvance = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.time !== 0) {
      writer.uint32(8).int32(message.time);
    }
    if (message.advanceType !== "") {
      writer.uint32(18).string(message.advanceType);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClockAdvance();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.time = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.advanceType = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      time: isSet(object.time) ? globalThis.Number(object.time) : 0,
      advanceType: isSet(object.advanceType) ? globalThis.String(object.advanceType) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.time !== 0) {
      obj.time = Math.round(message.time);
    }
    if (message.advanceType !== "") {
      obj.advanceType = message.advanceType;
    }
    return obj;
  },
  create(base) {
    return Request_ClockAdvance.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClockAdvance();
    message.time = object.time ?? 0;
    message.advanceType = object.advanceType ?? "";
    return message;
  }
};
function createBaseRequest_CoverageStart() {
  return {
    coverageType: "",
    resetOnNavigation: false,
    reportAnonymousScripts: false,
    configFile: "",
    coverageDir: "",
    raw: false
  };
}
var Request_CoverageStart = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.coverageType !== "") {
      writer.uint32(10).string(message.coverageType);
    }
    if (message.resetOnNavigation !== false) {
      writer.uint32(16).bool(message.resetOnNavigation);
    }
    if (message.reportAnonymousScripts !== false) {
      writer.uint32(24).bool(message.reportAnonymousScripts);
    }
    if (message.configFile !== "") {
      writer.uint32(34).string(message.configFile);
    }
    if (message.coverageDir !== "") {
      writer.uint32(42).string(message.coverageDir);
    }
    if (message.raw !== false) {
      writer.uint32(48).bool(message.raw);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_CoverageStart();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.coverageType = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.resetOnNavigation = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.reportAnonymousScripts = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.configFile = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.coverageDir = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.raw = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      coverageType: isSet(object.coverageType) ? globalThis.String(object.coverageType) : "",
      resetOnNavigation: isSet(object.resetOnNavigation) ? globalThis.Boolean(object.resetOnNavigation) : false,
      reportAnonymousScripts: isSet(object.reportAnonymousScripts) ? globalThis.Boolean(object.reportAnonymousScripts) : false,
      configFile: isSet(object.configFile) ? globalThis.String(object.configFile) : "",
      coverageDir: isSet(object.coverageDir) ? globalThis.String(object.coverageDir) : "",
      raw: isSet(object.raw) ? globalThis.Boolean(object.raw) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.coverageType !== "") {
      obj.coverageType = message.coverageType;
    }
    if (message.resetOnNavigation !== false) {
      obj.resetOnNavigation = message.resetOnNavigation;
    }
    if (message.reportAnonymousScripts !== false) {
      obj.reportAnonymousScripts = message.reportAnonymousScripts;
    }
    if (message.configFile !== "") {
      obj.configFile = message.configFile;
    }
    if (message.coverageDir !== "") {
      obj.coverageDir = message.coverageDir;
    }
    if (message.raw !== false) {
      obj.raw = message.raw;
    }
    return obj;
  },
  create(base) {
    return Request_CoverageStart.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_CoverageStart();
    message.coverageType = object.coverageType ?? "";
    message.resetOnNavigation = object.resetOnNavigation ?? false;
    message.reportAnonymousScripts = object.reportAnonymousScripts ?? false;
    message.configFile = object.configFile ?? "";
    message.coverageDir = object.coverageDir ?? "";
    message.raw = object.raw ?? false;
    return message;
  }
};
function createBaseRequest_CoverageMerge() {
  return { inputFolder: "", outputFolder: "", config: "", name: "", reports: [] };
}
var Request_CoverageMerge = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.inputFolder !== "") {
      writer.uint32(10).string(message.inputFolder);
    }
    if (message.outputFolder !== "") {
      writer.uint32(18).string(message.outputFolder);
    }
    if (message.config !== "") {
      writer.uint32(26).string(message.config);
    }
    if (message.name !== "") {
      writer.uint32(34).string(message.name);
    }
    for (const v of message.reports) {
      writer.uint32(42).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_CoverageMerge();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.inputFolder = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.outputFolder = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.config = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.reports.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      inputFolder: isSet(object.inputFolder) ? globalThis.String(object.inputFolder) : isSet(object.input_folder) ? globalThis.String(object.input_folder) : "",
      outputFolder: isSet(object.outputFolder) ? globalThis.String(object.outputFolder) : isSet(object.output_folder) ? globalThis.String(object.output_folder) : "",
      config: isSet(object.config) ? globalThis.String(object.config) : "",
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      reports: globalThis.Array.isArray(object?.reports) ? object.reports.map((e) => globalThis.String(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.inputFolder !== "") {
      obj.inputFolder = message.inputFolder;
    }
    if (message.outputFolder !== "") {
      obj.outputFolder = message.outputFolder;
    }
    if (message.config !== "") {
      obj.config = message.config;
    }
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.reports?.length) {
      obj.reports = message.reports;
    }
    return obj;
  },
  create(base) {
    return Request_CoverageMerge.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_CoverageMerge();
    message.inputFolder = object.inputFolder ?? "";
    message.outputFolder = object.outputFolder ?? "";
    message.config = object.config ?? "";
    message.name = object.name ?? "";
    message.reports = object.reports?.map((e) => e) || [];
    return message;
  }
};
function createBaseRequest_TraceGroup() {
  return { name: "", file: "", line: 0, column: 0, contextId: "" };
}
var Request_TraceGroup = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    if (message.file !== "") {
      writer.uint32(18).string(message.file);
    }
    if (message.line !== 0) {
      writer.uint32(24).int32(message.line);
    }
    if (message.column !== 0) {
      writer.uint32(32).int32(message.column);
    }
    if (message.contextId !== "") {
      writer.uint32(42).string(message.contextId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_TraceGroup();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.file = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.line = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.column = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.contextId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      file: isSet(object.file) ? globalThis.String(object.file) : "",
      line: isSet(object.line) ? globalThis.Number(object.line) : 0,
      column: isSet(object.column) ? globalThis.Number(object.column) : 0,
      contextId: isSet(object.contextId) ? globalThis.String(object.contextId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.file !== "") {
      obj.file = message.file;
    }
    if (message.line !== 0) {
      obj.line = Math.round(message.line);
    }
    if (message.column !== 0) {
      obj.column = Math.round(message.column);
    }
    if (message.contextId !== "") {
      obj.contextId = message.contextId;
    }
    return obj;
  },
  create(base) {
    return Request_TraceGroup.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_TraceGroup();
    message.name = object.name ?? "";
    message.file = object.file ?? "";
    message.line = object.line ?? 0;
    message.column = object.column ?? 0;
    message.contextId = object.contextId ?? "";
    return message;
  }
};
function createBaseRequest_RFContext() {
  return { testId: "", testName: "", suiteId: "", suiteName: "" };
}
var Request_RFContext = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.testId !== "") {
      writer.uint32(10).string(message.testId);
    }
    if (message.testName !== "") {
      writer.uint32(18).string(message.testName);
    }
    if (message.suiteId !== "") {
      writer.uint32(26).string(message.suiteId);
    }
    if (message.suiteName !== "") {
      writer.uint32(34).string(message.suiteName);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_RFContext();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.testId = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.testName = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.suiteId = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.suiteName = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      testId: isSet(object.testId) ? globalThis.String(object.testId) : isSet(object.test_id) ? globalThis.String(object.test_id) : "",
      testName: isSet(object.testName) ? globalThis.String(object.testName) : isSet(object.test_name) ? globalThis.String(object.test_name) : "",
      suiteId: isSet(object.suiteId) ? globalThis.String(object.suiteId) : isSet(object.suite_id) ? globalThis.String(object.suite_id) : "",
      suiteName: isSet(object.suiteName) ? globalThis.String(object.suiteName) : isSet(object.suite_name) ? globalThis.String(object.suite_name) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.testId !== "") {
      obj.testId = message.testId;
    }
    if (message.testName !== "") {
      obj.testName = message.testName;
    }
    if (message.suiteId !== "") {
      obj.suiteId = message.suiteId;
    }
    if (message.suiteName !== "") {
      obj.suiteName = message.suiteName;
    }
    return obj;
  },
  create(base) {
    return Request_RFContext.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_RFContext();
    message.testId = object.testId ?? "";
    message.testName = object.testName ?? "";
    message.suiteId = object.suiteId ?? "";
    message.suiteName = object.suiteName ?? "";
    return message;
  }
};
function createBaseRequest_Label() {
  return { label: "" };
}
var Request_Label = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.label !== "") {
      writer.uint32(10).string(message.label);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Label();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.label = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { label: isSet(object.label) ? globalThis.String(object.label) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.label !== "") {
      obj.label = message.label;
    }
    return obj;
  },
  create(base) {
    return Request_Label.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Label();
    message.label = object.label ?? "";
    return message;
  }
};
function createBaseRequest_GetByOptions() {
  return { strategy: "", text: "", options: "", strict: false, all: false, frameSelector: "" };
}
var Request_GetByOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.strategy !== "") {
      writer.uint32(10).string(message.strategy);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    if (message.all !== false) {
      writer.uint32(40).bool(message.all);
    }
    if (message.frameSelector !== "") {
      writer.uint32(50).string(message.frameSelector);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_GetByOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.strategy = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.all = reader.bool();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.frameSelector = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      strategy: isSet(object.strategy) ? globalThis.String(object.strategy) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      all: isSet(object.all) ? globalThis.Boolean(object.all) : false,
      frameSelector: isSet(object.frameSelector) ? globalThis.String(object.frameSelector) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.strategy !== "") {
      obj.strategy = message.strategy;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.all !== false) {
      obj.all = message.all;
    }
    if (message.frameSelector !== "") {
      obj.frameSelector = message.frameSelector;
    }
    return obj;
  },
  create(base) {
    return Request_GetByOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_GetByOptions();
    message.strategy = object.strategy ?? "";
    message.text = object.text ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    message.all = object.all ?? false;
    message.frameSelector = object.frameSelector ?? "";
    return message;
  }
};
function createBaseRequest_Pdf() {
  return {
    displayHeaderFooter: false,
    footerTemplate: "",
    format: "",
    headerTemplate: "",
    height: "",
    landscape: false,
    margin: "",
    outline: false,
    pageRanges: "",
    path: "",
    preferCSSPageSize: false,
    printBackground: false,
    scale: 0,
    tagged: false,
    width: ""
  };
}
var Request_Pdf = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.displayHeaderFooter !== false) {
      writer.uint32(8).bool(message.displayHeaderFooter);
    }
    if (message.footerTemplate !== "") {
      writer.uint32(18).string(message.footerTemplate);
    }
    if (message.format !== "") {
      writer.uint32(26).string(message.format);
    }
    if (message.headerTemplate !== "") {
      writer.uint32(34).string(message.headerTemplate);
    }
    if (message.height !== "") {
      writer.uint32(42).string(message.height);
    }
    if (message.landscape !== false) {
      writer.uint32(48).bool(message.landscape);
    }
    if (message.margin !== "") {
      writer.uint32(58).string(message.margin);
    }
    if (message.outline !== false) {
      writer.uint32(64).bool(message.outline);
    }
    if (message.pageRanges !== "") {
      writer.uint32(74).string(message.pageRanges);
    }
    if (message.path !== "") {
      writer.uint32(82).string(message.path);
    }
    if (message.preferCSSPageSize !== false) {
      writer.uint32(88).bool(message.preferCSSPageSize);
    }
    if (message.printBackground !== false) {
      writer.uint32(96).bool(message.printBackground);
    }
    if (message.scale !== 0) {
      writer.uint32(109).float(message.scale);
    }
    if (message.tagged !== false) {
      writer.uint32(112).bool(message.tagged);
    }
    if (message.width !== "") {
      writer.uint32(122).string(message.width);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Pdf();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.displayHeaderFooter = reader.bool();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.footerTemplate = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.format = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.headerTemplate = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.height = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.landscape = reader.bool();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.margin = reader.string();
          continue;
        }
        case 8: {
          if (tag !== 64) {
            break;
          }
          message.outline = reader.bool();
          continue;
        }
        case 9: {
          if (tag !== 74) {
            break;
          }
          message.pageRanges = reader.string();
          continue;
        }
        case 10: {
          if (tag !== 82) {
            break;
          }
          message.path = reader.string();
          continue;
        }
        case 11: {
          if (tag !== 88) {
            break;
          }
          message.preferCSSPageSize = reader.bool();
          continue;
        }
        case 12: {
          if (tag !== 96) {
            break;
          }
          message.printBackground = reader.bool();
          continue;
        }
        case 13: {
          if (tag !== 109) {
            break;
          }
          message.scale = reader.float();
          continue;
        }
        case 14: {
          if (tag !== 112) {
            break;
          }
          message.tagged = reader.bool();
          continue;
        }
        case 15: {
          if (tag !== 122) {
            break;
          }
          message.width = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      displayHeaderFooter: isSet(object.displayHeaderFooter) ? globalThis.Boolean(object.displayHeaderFooter) : false,
      footerTemplate: isSet(object.footerTemplate) ? globalThis.String(object.footerTemplate) : "",
      format: isSet(object.format) ? globalThis.String(object.format) : "",
      headerTemplate: isSet(object.headerTemplate) ? globalThis.String(object.headerTemplate) : "",
      height: isSet(object.height) ? globalThis.String(object.height) : "",
      landscape: isSet(object.landscape) ? globalThis.Boolean(object.landscape) : false,
      margin: isSet(object.margin) ? globalThis.String(object.margin) : "",
      outline: isSet(object.outline) ? globalThis.Boolean(object.outline) : false,
      pageRanges: isSet(object.pageRanges) ? globalThis.String(object.pageRanges) : "",
      path: isSet(object.path) ? globalThis.String(object.path) : "",
      preferCSSPageSize: isSet(object.preferCSSPageSize) ? globalThis.Boolean(object.preferCSSPageSize) : false,
      printBackground: isSet(object.printBackground) ? globalThis.Boolean(object.printBackground) : false,
      scale: isSet(object.scale) ? globalThis.Number(object.scale) : 0,
      tagged: isSet(object.tagged) ? globalThis.Boolean(object.tagged) : false,
      width: isSet(object.width) ? globalThis.String(object.width) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.displayHeaderFooter !== false) {
      obj.displayHeaderFooter = message.displayHeaderFooter;
    }
    if (message.footerTemplate !== "") {
      obj.footerTemplate = message.footerTemplate;
    }
    if (message.format !== "") {
      obj.format = message.format;
    }
    if (message.headerTemplate !== "") {
      obj.headerTemplate = message.headerTemplate;
    }
    if (message.height !== "") {
      obj.height = message.height;
    }
    if (message.landscape !== false) {
      obj.landscape = message.landscape;
    }
    if (message.margin !== "") {
      obj.margin = message.margin;
    }
    if (message.outline !== false) {
      obj.outline = message.outline;
    }
    if (message.pageRanges !== "") {
      obj.pageRanges = message.pageRanges;
    }
    if (message.path !== "") {
      obj.path = message.path;
    }
    if (message.preferCSSPageSize !== false) {
      obj.preferCSSPageSize = message.preferCSSPageSize;
    }
    if (message.printBackground !== false) {
      obj.printBackground = message.printBackground;
    }
    if (message.scale !== 0) {
      obj.scale = message.scale;
    }
    if (message.tagged !== false) {
      obj.tagged = message.tagged;
    }
    if (message.width !== "") {
      obj.width = message.width;
    }
    return obj;
  },
  create(base) {
    return Request_Pdf.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Pdf();
    message.displayHeaderFooter = object.displayHeaderFooter ?? false;
    message.footerTemplate = object.footerTemplate ?? "";
    message.format = object.format ?? "";
    message.headerTemplate = object.headerTemplate ?? "";
    message.height = object.height ?? "";
    message.landscape = object.landscape ?? false;
    message.margin = object.margin ?? "";
    message.outline = object.outline ?? false;
    message.pageRanges = object.pageRanges ?? "";
    message.path = object.path ?? "";
    message.preferCSSPageSize = object.preferCSSPageSize ?? false;
    message.printBackground = object.printBackground ?? false;
    message.scale = object.scale ?? 0;
    message.tagged = object.tagged ?? false;
    message.width = object.width ?? "";
    return message;
  }
};
function createBaseRequest_EmulateMedia() {
  return { colorScheme: "", forcedColors: "", media: "", reducedMotion: "" };
}
var Request_EmulateMedia = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.colorScheme !== "") {
      writer.uint32(10).string(message.colorScheme);
    }
    if (message.forcedColors !== "") {
      writer.uint32(18).string(message.forcedColors);
    }
    if (message.media !== "") {
      writer.uint32(26).string(message.media);
    }
    if (message.reducedMotion !== "") {
      writer.uint32(34).string(message.reducedMotion);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_EmulateMedia();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.colorScheme = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.forcedColors = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.media = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.reducedMotion = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      colorScheme: isSet(object.colorScheme) ? globalThis.String(object.colorScheme) : "",
      forcedColors: isSet(object.forcedColors) ? globalThis.String(object.forcedColors) : "",
      media: isSet(object.media) ? globalThis.String(object.media) : "",
      reducedMotion: isSet(object.reducedMotion) ? globalThis.String(object.reducedMotion) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.colorScheme !== "") {
      obj.colorScheme = message.colorScheme;
    }
    if (message.forcedColors !== "") {
      obj.forcedColors = message.forcedColors;
    }
    if (message.media !== "") {
      obj.media = message.media;
    }
    if (message.reducedMotion !== "") {
      obj.reducedMotion = message.reducedMotion;
    }
    return obj;
  },
  create(base) {
    return Request_EmulateMedia.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_EmulateMedia();
    message.colorScheme = object.colorScheme ?? "";
    message.forcedColors = object.forcedColors ?? "";
    message.media = object.media ?? "";
    message.reducedMotion = object.reducedMotion ?? "";
    return message;
  }
};
function createBaseRequest_ScreenshotOptions() {
  return { selector: "", mask: "", options: "", strict: false };
}
var Request_ScreenshotOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.mask !== "") {
      writer.uint32(18).string(message.mask);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ScreenshotOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.mask = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      mask: isSet(object.mask) ? globalThis.String(object.mask) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.mask !== "") {
      obj.mask = message.mask;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ScreenshotOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ScreenshotOptions();
    message.selector = object.selector ?? "";
    message.mask = object.mask ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_KeywordCall() {
  return { name: "", arguments: "" };
}
var Request_KeywordCall = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    if (message.arguments !== "") {
      writer.uint32(18).string(message.arguments);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeywordCall();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.arguments = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      arguments: isSet(object.arguments) ? globalThis.String(object.arguments) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.arguments !== "") {
      obj.arguments = message.arguments;
    }
    return obj;
  },
  create(base) {
    return Request_KeywordCall.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeywordCall();
    message.name = object.name ?? "";
    message.arguments = object.arguments ?? "";
    return message;
  }
};
function createBaseRequest_FilePath() {
  return { path: "" };
}
var Request_FilePath = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.path !== "") {
      writer.uint32(10).string(message.path);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FilePath();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.path = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { path: isSet(object.path) ? globalThis.String(object.path) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.path !== "") {
      obj.path = message.path;
    }
    return obj;
  },
  create(base) {
    return Request_FilePath.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FilePath();
    message.path = object.path ?? "";
    return message;
  }
};
function createBaseRequest_FileBySelector() {
  return { path: [], selector: "", strict: false, name: "", mimeType: "", buffer: "" };
}
var Request_FileBySelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.path) {
      writer.uint32(10).string(v);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    if (message.name !== "") {
      writer.uint32(34).string(message.name);
    }
    if (message.mimeType !== "") {
      writer.uint32(42).string(message.mimeType);
    }
    if (message.buffer !== "") {
      writer.uint32(50).string(message.buffer);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FileBySelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.path.push(reader.string());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.name = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.mimeType = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.buffer = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      path: globalThis.Array.isArray(object?.path) ? object.path.map((e) => globalThis.String(e)) : [],
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      name: isSet(object.name) ? globalThis.String(object.name) : "",
      mimeType: isSet(object.mimeType) ? globalThis.String(object.mimeType) : "",
      buffer: isSet(object.buffer) ? globalThis.String(object.buffer) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.path?.length) {
      obj.path = message.path;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.name !== "") {
      obj.name = message.name;
    }
    if (message.mimeType !== "") {
      obj.mimeType = message.mimeType;
    }
    if (message.buffer !== "") {
      obj.buffer = message.buffer;
    }
    return obj;
  },
  create(base) {
    return Request_FileBySelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FileBySelector();
    message.path = object.path?.map((e) => e) || [];
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.name = object.name ?? "";
    message.mimeType = object.mimeType ?? "";
    message.buffer = object.buffer ?? "";
    return message;
  }
};
function createBaseRequest_LocatorHandlerAddCustom() {
  return { selector: "", noWaitAfter: false, times: "", handlerSpecs: [] };
}
var Request_LocatorHandlerAddCustom = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.noWaitAfter !== false) {
      writer.uint32(16).bool(message.noWaitAfter);
    }
    if (message.times !== "") {
      writer.uint32(26).string(message.times);
    }
    for (const v of message.handlerSpecs) {
      Request_LocatorHandlerAddCustomAction.encode(v, writer.uint32(34).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerAddCustom();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.noWaitAfter = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.times = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.handlerSpecs.push(Request_LocatorHandlerAddCustomAction.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      noWaitAfter: isSet(object.noWaitAfter) ? globalThis.Boolean(object.noWaitAfter) : false,
      times: isSet(object.times) ? globalThis.String(object.times) : "",
      handlerSpecs: globalThis.Array.isArray(object?.handlerSpecs) ? object.handlerSpecs.map((e) => Request_LocatorHandlerAddCustomAction.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.noWaitAfter !== false) {
      obj.noWaitAfter = message.noWaitAfter;
    }
    if (message.times !== "") {
      obj.times = message.times;
    }
    if (message.handlerSpecs?.length) {
      obj.handlerSpecs = message.handlerSpecs.map((e) => Request_LocatorHandlerAddCustomAction.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerAddCustom.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerAddCustom();
    message.selector = object.selector ?? "";
    message.noWaitAfter = object.noWaitAfter ?? false;
    message.times = object.times ?? "";
    message.handlerSpecs = object.handlerSpecs?.map((e) => Request_LocatorHandlerAddCustomAction.fromPartial(e)) || [];
    return message;
  }
};
function createBaseRequest_LocatorHandlerAddCustomAction() {
  return { action: "", selector: "", value: "", optionsAsJson: "" };
}
var Request_LocatorHandlerAddCustomAction = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.value !== "") {
      writer.uint32(26).string(message.value);
    }
    if (message.optionsAsJson !== "") {
      writer.uint32(34).string(message.optionsAsJson);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerAddCustomAction();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.value = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.optionsAsJson = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      value: isSet(object.value) ? globalThis.String(object.value) : "",
      optionsAsJson: isSet(object.optionsAsJson) ? globalThis.String(object.optionsAsJson) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.value !== "") {
      obj.value = message.value;
    }
    if (message.optionsAsJson !== "") {
      obj.optionsAsJson = message.optionsAsJson;
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerAddCustomAction.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerAddCustomAction();
    message.action = object.action ?? "";
    message.selector = object.selector ?? "";
    message.value = object.value ?? "";
    message.optionsAsJson = object.optionsAsJson ?? "";
    return message;
  }
};
function createBaseRequest_LocatorHandlerRemove() {
  return { selector: "" };
}
var Request_LocatorHandlerRemove = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_LocatorHandlerRemove();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { selector: isSet(object.selector) ? globalThis.String(object.selector) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    return obj;
  },
  create(base) {
    return Request_LocatorHandlerRemove.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_LocatorHandlerRemove();
    message.selector = object.selector ?? "";
    return message;
  }
};
function createBaseRequest_Json() {
  return { body: "" };
}
var Request_Json = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.body !== "") {
      writer.uint32(10).string(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Json();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.body = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { body: isSet(object.body) ? globalThis.String(object.body) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.body !== "") {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Request_Json.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Json();
    message.body = object.body ?? "";
    return message;
  }
};
function createBaseRequest_MouseButtonOptions() {
  return { action: "", json: "" };
}
var Request_MouseButtonOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.json !== "") {
      writer.uint32(18).string(message.json);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_MouseButtonOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.json = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      json: isSet(object.json) ? globalThis.String(object.json) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.json !== "") {
      obj.json = message.json;
    }
    return obj;
  },
  create(base) {
    return Request_MouseButtonOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_MouseButtonOptions();
    message.action = object.action ?? "";
    message.json = object.json ?? "";
    return message;
  }
};
function createBaseRequest_MouseWheel() {
  return { deltaX: 0, deltaY: 0 };
}
var Request_MouseWheel = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.deltaX !== 0) {
      writer.uint32(8).int32(message.deltaX);
    }
    if (message.deltaY !== 0) {
      writer.uint32(16).int32(message.deltaY);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_MouseWheel();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.deltaX = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.deltaY = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      deltaX: isSet(object.deltaX) ? globalThis.Number(object.deltaX) : 0,
      deltaY: isSet(object.deltaY) ? globalThis.Number(object.deltaY) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.deltaX !== 0) {
      obj.deltaX = Math.round(message.deltaX);
    }
    if (message.deltaY !== 0) {
      obj.deltaY = Math.round(message.deltaY);
    }
    return obj;
  },
  create(base) {
    return Request_MouseWheel.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_MouseWheel();
    message.deltaX = object.deltaX ?? 0;
    message.deltaY = object.deltaY ?? 0;
    return message;
  }
};
function createBaseRequest_KeyboardKeypress() {
  return { action: "", key: "" };
}
var Request_KeyboardKeypress = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.key !== "") {
      writer.uint32(18).string(message.key);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeyboardKeypress();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.key = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      key: isSet(object.key) ? globalThis.String(object.key) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.key !== "") {
      obj.key = message.key;
    }
    return obj;
  },
  create(base) {
    return Request_KeyboardKeypress.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeyboardKeypress();
    message.action = object.action ?? "";
    message.key = object.key ?? "";
    return message;
  }
};
function createBaseRequest_KeyboardInputOptions() {
  return { action: "", input: "", delay: 0 };
}
var Request_KeyboardInputOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.action !== "") {
      writer.uint32(10).string(message.action);
    }
    if (message.input !== "") {
      writer.uint32(18).string(message.input);
    }
    if (message.delay !== 0) {
      writer.uint32(24).int32(message.delay);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_KeyboardInputOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.action = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.input = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.delay = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      action: isSet(object.action) ? globalThis.String(object.action) : "",
      input: isSet(object.input) ? globalThis.String(object.input) : "",
      delay: isSet(object.delay) ? globalThis.Number(object.delay) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.action !== "") {
      obj.action = message.action;
    }
    if (message.input !== "") {
      obj.input = message.input;
    }
    if (message.delay !== 0) {
      obj.delay = Math.round(message.delay);
    }
    return obj;
  },
  create(base) {
    return Request_KeyboardInputOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_KeyboardInputOptions();
    message.action = object.action ?? "";
    message.input = object.input ?? "";
    message.delay = object.delay ?? 0;
    return message;
  }
};
function createBaseRequest_Browser() {
  return { browser: "", rawOptions: "" };
}
var Request_Browser = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.rawOptions !== "") {
      writer.uint32(18).string(message.rawOptions);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Browser();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    return obj;
  },
  create(base) {
    return Request_Browser.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Browser();
    message.browser = object.browser ?? "";
    message.rawOptions = object.rawOptions ?? "";
    return message;
  }
};
function createBaseRequest_Context() {
  return { rawOptions: "", defaultTimeout: 0, traceFile: "" };
}
var Request_Context = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.rawOptions !== "") {
      writer.uint32(10).string(message.rawOptions);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(16).int32(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      writer.uint32(26).string(message.traceFile);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Context();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.traceFile = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0,
      traceFile: isSet(object.traceFile) ? globalThis.String(object.traceFile) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      obj.traceFile = message.traceFile;
    }
    return obj;
  },
  create(base) {
    return Request_Context.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Context();
    message.rawOptions = object.rawOptions ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    message.traceFile = object.traceFile ?? "";
    return message;
  }
};
function createBaseRequest_PersistentContext() {
  return { browser: "", rawOptions: "", defaultTimeout: 0, traceFile: "" };
}
var Request_PersistentContext = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.rawOptions !== "") {
      writer.uint32(18).string(message.rawOptions);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(24).int32(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      writer.uint32(34).string(message.traceFile);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PersistentContext();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.rawOptions = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.traceFile = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      rawOptions: isSet(object.rawOptions) ? globalThis.String(object.rawOptions) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0,
      traceFile: isSet(object.traceFile) ? globalThis.String(object.traceFile) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.rawOptions !== "") {
      obj.rawOptions = message.rawOptions;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    if (message.traceFile !== "") {
      obj.traceFile = message.traceFile;
    }
    return obj;
  },
  create(base) {
    return Request_PersistentContext.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PersistentContext();
    message.browser = object.browser ?? "";
    message.rawOptions = object.rawOptions ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    message.traceFile = object.traceFile ?? "";
    return message;
  }
};
function createBaseRequest_Permissions() {
  return { permissions: [], origin: "" };
}
var Request_Permissions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.permissions) {
      writer.uint32(10).string(v);
    }
    if (message.origin !== "") {
      writer.uint32(18).string(message.origin);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Permissions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.permissions.push(reader.string());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.origin = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      permissions: globalThis.Array.isArray(object?.permissions) ? object.permissions.map((e) => globalThis.String(e)) : [],
      origin: isSet(object.origin) ? globalThis.String(object.origin) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.permissions?.length) {
      obj.permissions = message.permissions;
    }
    if (message.origin !== "") {
      obj.origin = message.origin;
    }
    return obj;
  },
  create(base) {
    return Request_Permissions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Permissions();
    message.permissions = object.permissions?.map((e) => e) || [];
    message.origin = object.origin ?? "";
    return message;
  }
};
function createBaseRequest_Url() {
  return { url: "", defaultTimeout: 0 };
}
var Request_Url = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.defaultTimeout !== 0) {
      writer.uint32(16).int32(message.defaultTimeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Url();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.defaultTimeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      defaultTimeout: isSet(object.defaultTimeout) ? globalThis.Number(object.defaultTimeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.defaultTimeout !== 0) {
      obj.defaultTimeout = Math.round(message.defaultTimeout);
    }
    return obj;
  },
  create(base) {
    return Request_Url.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Url();
    message.url = object.url ?? "";
    message.defaultTimeout = object.defaultTimeout ?? 0;
    return message;
  }
};
function createBaseRequest_DownloadOptions() {
  return { url: "", path: "", waitForFinish: false, downloadTimeout: 0 };
}
var Request_DownloadOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.path !== "") {
      writer.uint32(18).string(message.path);
    }
    if (message.waitForFinish !== false) {
      writer.uint32(24).bool(message.waitForFinish);
    }
    if (message.downloadTimeout !== 0) {
      writer.uint32(32).int32(message.downloadTimeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_DownloadOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.path = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.waitForFinish = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.downloadTimeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      path: isSet(object.path) ? globalThis.String(object.path) : "",
      waitForFinish: isSet(object.waitForFinish) ? globalThis.Boolean(object.waitForFinish) : false,
      downloadTimeout: isSet(object.downloadTimeout) ? globalThis.Number(object.downloadTimeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.path !== "") {
      obj.path = message.path;
    }
    if (message.waitForFinish !== false) {
      obj.waitForFinish = message.waitForFinish;
    }
    if (message.downloadTimeout !== 0) {
      obj.downloadTimeout = Math.round(message.downloadTimeout);
    }
    return obj;
  },
  create(base) {
    return Request_DownloadOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_DownloadOptions();
    message.url = object.url ?? "";
    message.path = object.path ?? "";
    message.waitForFinish = object.waitForFinish ?? false;
    message.downloadTimeout = object.downloadTimeout ?? 0;
    return message;
  }
};
function createBaseRequest_DownloadID() {
  return { id: "" };
}
var Request_DownloadID = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_DownloadID();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { id: isSet(object.id) ? globalThis.String(object.id) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    return obj;
  },
  create(base) {
    return Request_DownloadID.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_DownloadID();
    message.id = object.id ?? "";
    return message;
  }
};
function createBaseRequest_UrlOptions() {
  return { url: void 0, waitUntil: "" };
}
var Request_UrlOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== void 0) {
      Request_Url.encode(message.url, writer.uint32(10).fork()).join();
    }
    if (message.waitUntil !== "") {
      writer.uint32(18).string(message.waitUntil);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_UrlOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = Request_Url.decode(reader, reader.uint32());
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.waitUntil = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? Request_Url.fromJSON(object.url) : void 0,
      waitUntil: isSet(object.waitUntil) ? globalThis.String(object.waitUntil) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== void 0) {
      obj.url = Request_Url.toJSON(message.url);
    }
    if (message.waitUntil !== "") {
      obj.waitUntil = message.waitUntil;
    }
    return obj;
  },
  create(base) {
    return Request_UrlOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_UrlOptions();
    message.url = object.url !== void 0 && object.url !== null ? Request_Url.fromPartial(object.url) : void 0;
    message.waitUntil = object.waitUntil ?? "";
    return message;
  }
};
function createBaseRequest_PageLoadState() {
  return { state: "", timeout: 0 };
}
var Request_PageLoadState = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.state !== "") {
      writer.uint32(10).string(message.state);
    }
    if (message.timeout !== 0) {
      writer.uint32(16).int32(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PageLoadState();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.state = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.timeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      state: isSet(object.state) ? globalThis.String(object.state) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.state !== "") {
      obj.state = message.state;
    }
    if (message.timeout !== 0) {
      obj.timeout = Math.round(message.timeout);
    }
    return obj;
  },
  create(base) {
    return Request_PageLoadState.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PageLoadState();
    message.state = object.state ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_ConnectBrowser() {
  return { browser: "", url: "", connectCDP: false, timeout: 0 };
}
var Request_ConnectBrowser = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.browser !== "") {
      writer.uint32(10).string(message.browser);
    }
    if (message.url !== "") {
      writer.uint32(18).string(message.url);
    }
    if (message.connectCDP !== false) {
      writer.uint32(24).bool(message.connectCDP);
    }
    if (message.timeout !== 0) {
      writer.uint32(32).int32(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ConnectBrowser();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.browser = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.connectCDP = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.timeout = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      browser: isSet(object.browser) ? globalThis.String(object.browser) : "",
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      connectCDP: isSet(object.connectCDP) ? globalThis.Boolean(object.connectCDP) : false,
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.browser !== "") {
      obj.browser = message.browser;
    }
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.connectCDP !== false) {
      obj.connectCDP = message.connectCDP;
    }
    if (message.timeout !== 0) {
      obj.timeout = Math.round(message.timeout);
    }
    return obj;
  },
  create(base) {
    return Request_ConnectBrowser.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ConnectBrowser();
    message.browser = object.browser ?? "";
    message.url = object.url ?? "";
    message.connectCDP = object.connectCDP ?? false;
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_ElementProperty() {
  return { selector: "", property: "", strict: false };
}
var Request_ElementProperty = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.property !== "") {
      writer.uint32(18).string(message.property);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementProperty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.property = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      property: isSet(object.property) ? globalThis.String(object.property) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.property !== "") {
      obj.property = message.property;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementProperty.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementProperty();
    message.selector = object.selector ?? "";
    message.property = object.property ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_TypeText() {
  return { selector: "", text: "", delay: 0, clear: false, strict: false };
}
var Request_TypeText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.delay !== 0) {
      writer.uint32(24).int32(message.delay);
    }
    if (message.clear !== false) {
      writer.uint32(32).bool(message.clear);
    }
    if (message.strict !== false) {
      writer.uint32(40).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_TypeText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.delay = reader.int32();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.clear = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      delay: isSet(object.delay) ? globalThis.Number(object.delay) : 0,
      clear: isSet(object.clear) ? globalThis.Boolean(object.clear) : false,
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.delay !== 0) {
      obj.delay = Math.round(message.delay);
    }
    if (message.clear !== false) {
      obj.clear = message.clear;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_TypeText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_TypeText();
    message.selector = object.selector ?? "";
    message.text = object.text ?? "";
    message.delay = object.delay ?? 0;
    message.clear = object.clear ?? false;
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_FillText() {
  return { selector: "", text: "", strict: false, force: false };
}
var Request_FillText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.text !== "") {
      writer.uint32(18).string(message.text);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    if (message.force !== false) {
      writer.uint32(32).bool(message.force);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_FillText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.text = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.force = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      text: isSet(object.text) ? globalThis.String(object.text) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      force: isSet(object.force) ? globalThis.Boolean(object.force) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.text !== "") {
      obj.text = message.text;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.force !== false) {
      obj.force = message.force;
    }
    return obj;
  },
  create(base) {
    return Request_FillText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_FillText();
    message.selector = object.selector ?? "";
    message.text = object.text ?? "";
    message.strict = object.strict ?? false;
    message.force = object.force ?? false;
    return message;
  }
};
function createBaseRequest_ClearText() {
  return { selector: "", strict: false };
}
var Request_ClearText = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ClearText();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ClearText.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ClearText();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_PressKeys() {
  return { selector: "", strict: false, key: [], pressDelay: 0, keyDelay: 0 };
}
var Request_PressKeys = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    for (const v of message.key) {
      writer.uint32(26).string(v);
    }
    if (message.pressDelay !== 0) {
      writer.uint32(32).int32(message.pressDelay);
    }
    if (message.keyDelay !== 0) {
      writer.uint32(40).int32(message.keyDelay);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_PressKeys();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.key.push(reader.string());
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.pressDelay = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.keyDelay = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      key: globalThis.Array.isArray(object?.key) ? object.key.map((e) => globalThis.String(e)) : [],
      pressDelay: isSet(object.pressDelay) ? globalThis.Number(object.pressDelay) : 0,
      keyDelay: isSet(object.keyDelay) ? globalThis.Number(object.keyDelay) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.key?.length) {
      obj.key = message.key;
    }
    if (message.pressDelay !== 0) {
      obj.pressDelay = Math.round(message.pressDelay);
    }
    if (message.keyDelay !== 0) {
      obj.keyDelay = Math.round(message.keyDelay);
    }
    return obj;
  },
  create(base) {
    return Request_PressKeys.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_PressKeys();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.key = object.key?.map((e) => e) || [];
    message.pressDelay = object.pressDelay ?? 0;
    message.keyDelay = object.keyDelay ?? 0;
    return message;
  }
};
function createBaseRequest_ElementSelector() {
  return { selector: "", strict: false, force: false };
}
var Request_ElementSelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.strict !== false) {
      writer.uint32(16).bool(message.strict);
    }
    if (message.force !== false) {
      writer.uint32(24).bool(message.force);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.force = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      force: isSet(object.force) ? globalThis.Boolean(object.force) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.force !== false) {
      obj.force = message.force;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelector();
    message.selector = object.selector ?? "";
    message.strict = object.strict ?? false;
    message.force = object.force ?? false;
    return message;
  }
};
function createBaseRequest_Timeout() {
  return { timeout: 0 };
}
var Request_Timeout = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.timeout !== 0) {
      writer.uint32(13).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Timeout();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 13) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0 };
  },
  toJSON(message) {
    const obj = {};
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_Timeout.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Timeout();
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_Index() {
  return { index: "" };
}
var Request_Index = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.index !== "") {
      writer.uint32(10).string(message.index);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Index();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.index = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { index: isSet(object.index) ? globalThis.String(object.index) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.index !== "") {
      obj.index = message.index;
    }
    return obj;
  },
  create(base) {
    return Request_Index.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Index();
    message.index = object.index ?? "";
    return message;
  }
};
function createBaseRequest_IdWithTimeout() {
  return { id: "", timeout: 0 };
}
var Request_IdWithTimeout = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.timeout !== 0) {
      writer.uint32(21).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_IdWithTimeout();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 21) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_IdWithTimeout.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_IdWithTimeout();
    message.id = object.id ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_StyleTag() {
  return { content: "" };
}
var Request_StyleTag = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.content !== "") {
      writer.uint32(10).string(message.content);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_StyleTag();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.content = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { content: isSet(object.content) ? globalThis.String(object.content) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.content !== "") {
      obj.content = message.content;
    }
    return obj;
  },
  create(base) {
    return Request_StyleTag.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_StyleTag();
    message.content = object.content ?? "";
    return message;
  }
};
function createBaseRequest_ElementSelectorWithOptions() {
  return { selector: "", options: "", strict: false };
}
var Request_ElementSelectorWithOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.options !== "") {
      writer.uint32(18).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelectorWithOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelectorWithOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelectorWithOptions();
    message.selector = object.selector ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ElementSelectorWithDuration() {
  return { selector: "", duration: 0, width: "", style: "", color: "", strict: false, mode: "" };
}
var Request_ElementSelectorWithDuration = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.duration !== 0) {
      writer.uint32(16).int32(message.duration);
    }
    if (message.width !== "") {
      writer.uint32(26).string(message.width);
    }
    if (message.style !== "") {
      writer.uint32(34).string(message.style);
    }
    if (message.color !== "") {
      writer.uint32(42).string(message.color);
    }
    if (message.strict !== false) {
      writer.uint32(48).bool(message.strict);
    }
    if (message.mode !== "") {
      writer.uint32(58).string(message.mode);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementSelectorWithDuration();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.duration = reader.int32();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.width = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.style = reader.string();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.color = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 48) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.mode = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      duration: isSet(object.duration) ? globalThis.Number(object.duration) : 0,
      width: isSet(object.width) ? globalThis.String(object.width) : "",
      style: isSet(object.style) ? globalThis.String(object.style) : "",
      color: isSet(object.color) ? globalThis.String(object.color) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false,
      mode: isSet(object.mode) ? globalThis.String(object.mode) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.duration !== 0) {
      obj.duration = Math.round(message.duration);
    }
    if (message.width !== "") {
      obj.width = message.width;
    }
    if (message.style !== "") {
      obj.style = message.style;
    }
    if (message.color !== "") {
      obj.color = message.color;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    if (message.mode !== "") {
      obj.mode = message.mode;
    }
    return obj;
  },
  create(base) {
    return Request_ElementSelectorWithDuration.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementSelectorWithDuration();
    message.selector = object.selector ?? "";
    message.duration = object.duration ?? 0;
    message.width = object.width ?? "";
    message.style = object.style ?? "";
    message.color = object.color ?? "";
    message.strict = object.strict ?? false;
    message.mode = object.mode ?? "";
    return message;
  }
};
function createBaseRequest_SelectElementSelector() {
  return { selector: "", matcherJson: "", strict: false };
}
var Request_SelectElementSelector = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.matcherJson !== "") {
      writer.uint32(18).string(message.matcherJson);
    }
    if (message.strict !== false) {
      writer.uint32(24).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_SelectElementSelector();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.matcherJson = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 24) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      matcherJson: isSet(object.matcherJson) ? globalThis.String(object.matcherJson) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.matcherJson !== "") {
      obj.matcherJson = message.matcherJson;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_SelectElementSelector.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_SelectElementSelector();
    message.selector = object.selector ?? "";
    message.matcherJson = object.matcherJson ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_WaitForFunctionOptions() {
  return { script: "", selector: "", options: "", strict: false };
}
var Request_WaitForFunctionOptions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.script !== "") {
      writer.uint32(10).string(message.script);
    }
    if (message.selector !== "") {
      writer.uint32(18).string(message.selector);
    }
    if (message.options !== "") {
      writer.uint32(26).string(message.options);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_WaitForFunctionOptions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.script = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.options = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      script: isSet(object.script) ? globalThis.String(object.script) : "",
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      options: isSet(object.options) ? globalThis.String(object.options) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.script !== "") {
      obj.script = message.script;
    }
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.options !== "") {
      obj.options = message.options;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_WaitForFunctionOptions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_WaitForFunctionOptions();
    message.script = object.script ?? "";
    message.selector = object.selector ?? "";
    message.options = object.options ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_Viewport() {
  return { width: 0, height: 0 };
}
var Request_Viewport = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.width !== 0) {
      writer.uint32(8).int32(message.width);
    }
    if (message.height !== 0) {
      writer.uint32(16).int32(message.height);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Viewport();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.width = reader.int32();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.height = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      width: isSet(object.width) ? globalThis.Number(object.width) : 0,
      height: isSet(object.height) ? globalThis.Number(object.height) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.width !== 0) {
      obj.width = Math.round(message.width);
    }
    if (message.height !== 0) {
      obj.height = Math.round(message.height);
    }
    return obj;
  },
  create(base) {
    return Request_Viewport.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Viewport();
    message.width = object.width ?? 0;
    message.height = object.height ?? 0;
    return message;
  }
};
function createBaseRequest_HttpRequest() {
  return { url: "", method: "", body: "", headers: "" };
}
var Request_HttpRequest = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.url !== "") {
      writer.uint32(10).string(message.url);
    }
    if (message.method !== "") {
      writer.uint32(18).string(message.method);
    }
    if (message.body !== "") {
      writer.uint32(26).string(message.body);
    }
    if (message.headers !== "") {
      writer.uint32(34).string(message.headers);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_HttpRequest();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.url = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.method = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.body = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.headers = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      url: isSet(object.url) ? globalThis.String(object.url) : "",
      method: isSet(object.method) ? globalThis.String(object.method) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : "",
      headers: isSet(object.headers) ? globalThis.String(object.headers) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.url !== "") {
      obj.url = message.url;
    }
    if (message.method !== "") {
      obj.method = message.method;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    if (message.headers !== "") {
      obj.headers = message.headers;
    }
    return obj;
  },
  create(base) {
    return Request_HttpRequest.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_HttpRequest();
    message.url = object.url ?? "";
    message.method = object.method ?? "";
    message.body = object.body ?? "";
    message.headers = object.headers ?? "";
    return message;
  }
};
function createBaseRequest_HttpCapture() {
  return { urlOrPredicate: "", timeout: 0 };
}
var Request_HttpCapture = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.urlOrPredicate !== "") {
      writer.uint32(10).string(message.urlOrPredicate);
    }
    if (message.timeout !== 0) {
      writer.uint32(21).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_HttpCapture();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.urlOrPredicate = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 21) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      urlOrPredicate: isSet(object.urlOrPredicate) ? globalThis.String(object.urlOrPredicate) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.urlOrPredicate !== "") {
      obj.urlOrPredicate = message.urlOrPredicate;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_HttpCapture.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_HttpCapture();
    message.urlOrPredicate = object.urlOrPredicate ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_Device() {
  return { name: "" };
}
var Request_Device = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.name !== "") {
      writer.uint32(10).string(message.name);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Device();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.name = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { name: isSet(object.name) ? globalThis.String(object.name) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.name !== "") {
      obj.name = message.name;
    }
    return obj;
  },
  create(base) {
    return Request_Device.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Device();
    message.name = object.name ?? "";
    return message;
  }
};
function createBaseRequest_AlertAction() {
  return { alertAction: "", promptInput: "", timeout: 0 };
}
var Request_AlertAction = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.alertAction !== "") {
      writer.uint32(10).string(message.alertAction);
    }
    if (message.promptInput !== "") {
      writer.uint32(18).string(message.promptInput);
    }
    if (message.timeout !== 0) {
      writer.uint32(29).float(message.timeout);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AlertAction();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.alertAction = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.promptInput = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 29) {
            break;
          }
          message.timeout = reader.float();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      alertAction: isSet(object.alertAction) ? globalThis.String(object.alertAction) : "",
      promptInput: isSet(object.promptInput) ? globalThis.String(object.promptInput) : "",
      timeout: isSet(object.timeout) ? globalThis.Number(object.timeout) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.alertAction !== "") {
      obj.alertAction = message.alertAction;
    }
    if (message.promptInput !== "") {
      obj.promptInput = message.promptInput;
    }
    if (message.timeout !== 0) {
      obj.timeout = message.timeout;
    }
    return obj;
  },
  create(base) {
    return Request_AlertAction.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AlertAction();
    message.alertAction = object.alertAction ?? "";
    message.promptInput = object.promptInput ?? "";
    message.timeout = object.timeout ?? 0;
    return message;
  }
};
function createBaseRequest_AlertActions() {
  return { items: [] };
}
var Request_AlertActions = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.items) {
      Request_AlertAction.encode(v, writer.uint32(10).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_AlertActions();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.items.push(Request_AlertAction.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      items: globalThis.Array.isArray(object?.items) ? object.items.map((e) => Request_AlertAction.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.items?.length) {
      obj.items = message.items.map((e) => Request_AlertAction.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Request_AlertActions.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_AlertActions();
    message.items = object.items?.map((e) => Request_AlertAction.fromPartial(e)) || [];
    return message;
  }
};
function createBaseRequest_Bool() {
  return { value: false };
}
var Request_Bool = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.value !== false) {
      writer.uint32(8).bool(message.value);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_Bool();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 8) {
            break;
          }
          message.value = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { value: isSet(object.value) ? globalThis.Boolean(object.value) : false };
  },
  toJSON(message) {
    const obj = {};
    if (message.value !== false) {
      obj.value = message.value;
    }
    return obj;
  },
  create(base) {
    return Request_Bool.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_Bool();
    message.value = object.value ?? false;
    return message;
  }
};
function createBaseRequest_EvaluateAll() {
  return { selector: "", script: "", arg: "", allElements: false, strict: false };
}
var Request_EvaluateAll = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.script !== "") {
      writer.uint32(18).string(message.script);
    }
    if (message.arg !== "") {
      writer.uint32(26).string(message.arg);
    }
    if (message.allElements !== false) {
      writer.uint32(32).bool(message.allElements);
    }
    if (message.strict !== false) {
      writer.uint32(40).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_EvaluateAll();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.script = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.arg = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.allElements = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      script: isSet(object.script) ? globalThis.String(object.script) : "",
      arg: isSet(object.arg) ? globalThis.String(object.arg) : "",
      allElements: isSet(object.allElements) ? globalThis.Boolean(object.allElements) : false,
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.script !== "") {
      obj.script = message.script;
    }
    if (message.arg !== "") {
      obj.arg = message.arg;
    }
    if (message.allElements !== false) {
      obj.allElements = message.allElements;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_EvaluateAll.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_EvaluateAll();
    message.selector = object.selector ?? "";
    message.script = object.script ?? "";
    message.arg = object.arg ?? "";
    message.allElements = object.allElements ?? false;
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseRequest_ElementStyle() {
  return { selector: "", pseudo: "", styleKey: "", strict: false };
}
var Request_ElementStyle = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.selector !== "") {
      writer.uint32(10).string(message.selector);
    }
    if (message.pseudo !== "") {
      writer.uint32(18).string(message.pseudo);
    }
    if (message.styleKey !== "") {
      writer.uint32(26).string(message.styleKey);
    }
    if (message.strict !== false) {
      writer.uint32(32).bool(message.strict);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseRequest_ElementStyle();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.selector = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.pseudo = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.styleKey = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.strict = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      selector: isSet(object.selector) ? globalThis.String(object.selector) : "",
      pseudo: isSet(object.pseudo) ? globalThis.String(object.pseudo) : "",
      styleKey: isSet(object.styleKey) ? globalThis.String(object.styleKey) : "",
      strict: isSet(object.strict) ? globalThis.Boolean(object.strict) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.selector !== "") {
      obj.selector = message.selector;
    }
    if (message.pseudo !== "") {
      obj.pseudo = message.pseudo;
    }
    if (message.styleKey !== "") {
      obj.styleKey = message.styleKey;
    }
    if (message.strict !== false) {
      obj.strict = message.strict;
    }
    return obj;
  },
  create(base) {
    return Request_ElementStyle.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseRequest_ElementStyle();
    message.selector = object.selector ?? "";
    message.pseudo = object.pseudo ?? "";
    message.styleKey = object.styleKey ?? "";
    message.strict = object.strict ?? false;
    return message;
  }
};
function createBaseTypes_SelectEntry() {
  return { value: "", label: "", index: 0, selected: false };
}
var Types_SelectEntry = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.value !== "") {
      writer.uint32(18).string(message.value);
    }
    if (message.label !== "") {
      writer.uint32(26).string(message.label);
    }
    if (message.index !== 0) {
      writer.uint32(32).int32(message.index);
    }
    if (message.selected !== false) {
      writer.uint32(40).bool(message.selected);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseTypes_SelectEntry();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.value = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.label = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.index = reader.int32();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.selected = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      value: isSet(object.value) ? globalThis.String(object.value) : "",
      label: isSet(object.label) ? globalThis.String(object.label) : "",
      index: isSet(object.index) ? globalThis.Number(object.index) : 0,
      selected: isSet(object.selected) ? globalThis.Boolean(object.selected) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.value !== "") {
      obj.value = message.value;
    }
    if (message.label !== "") {
      obj.label = message.label;
    }
    if (message.index !== 0) {
      obj.index = Math.round(message.index);
    }
    if (message.selected !== false) {
      obj.selected = message.selected;
    }
    return obj;
  },
  create(base) {
    return Types_SelectEntry.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseTypes_SelectEntry();
    message.value = object.value ?? "";
    message.label = object.label ?? "";
    message.index = object.index ?? 0;
    message.selected = object.selected ?? false;
    return message;
  }
};
function createBaseResponse_Empty() {
  return { log: "" };
}
var Response_Empty = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Empty();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { log: isSet(object.log) ? globalThis.String(object.log) : "" };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    return obj;
  },
  create(base) {
    return Response_Empty.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Empty();
    message.log = object.log ?? "";
    return message;
  }
};
function createBaseResponse_String() {
  return { log: "", body: "" };
}
var Response_String = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== "") {
      writer.uint32(18).string(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_String();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.body = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Response_String.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_String();
    message.log = object.log ?? "";
    message.body = object.body ?? "";
    return message;
  }
};
function createBaseResponse_ListString() {
  return { items: [] };
}
var Response_ListString = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.items) {
      writer.uint32(10).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_ListString();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.items.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return { items: globalThis.Array.isArray(object?.items) ? object.items.map((e) => globalThis.String(e)) : [] };
  },
  toJSON(message) {
    const obj = {};
    if (message.items?.length) {
      obj.items = message.items;
    }
    return obj;
  },
  create(base) {
    return Response_ListString.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_ListString();
    message.items = object.items?.map((e) => e) || [];
    return message;
  }
};
function createBaseResponse_Keywords() {
  return { log: "", keywords: [], keywordDocumentations: [], keywordArguments: [] };
}
var Response_Keywords = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    for (const v of message.keywords) {
      writer.uint32(18).string(v);
    }
    for (const v of message.keywordDocumentations) {
      writer.uint32(26).string(v);
    }
    for (const v of message.keywordArguments) {
      writer.uint32(34).string(v);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Keywords();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.keywords.push(reader.string());
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.keywordDocumentations.push(reader.string());
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.keywordArguments.push(reader.string());
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      keywords: globalThis.Array.isArray(object?.keywords) ? object.keywords.map((e) => globalThis.String(e)) : [],
      keywordDocumentations: globalThis.Array.isArray(object?.keywordDocumentations) ? object.keywordDocumentations.map((e) => globalThis.String(e)) : [],
      keywordArguments: globalThis.Array.isArray(object?.keywordArguments) ? object.keywordArguments.map((e) => globalThis.String(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.keywords?.length) {
      obj.keywords = message.keywords;
    }
    if (message.keywordDocumentations?.length) {
      obj.keywordDocumentations = message.keywordDocumentations;
    }
    if (message.keywordArguments?.length) {
      obj.keywordArguments = message.keywordArguments;
    }
    return obj;
  },
  create(base) {
    return Response_Keywords.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Keywords();
    message.log = object.log ?? "";
    message.keywords = object.keywords?.map((e) => e) || [];
    message.keywordDocumentations = object.keywordDocumentations?.map((e) => e) || [];
    message.keywordArguments = object.keywordArguments?.map((e) => e) || [];
    return message;
  }
};
function createBaseResponse_Bool() {
  return { log: "", body: false };
}
var Response_Bool = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== false) {
      writer.uint32(16).bool(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Bool();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.body = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.Boolean(object.body) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== false) {
      obj.body = message.body;
    }
    return obj;
  },
  create(base) {
    return Response_Bool.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Bool();
    message.log = object.log ?? "";
    message.body = object.body ?? false;
    return message;
  }
};
function createBaseResponse_Int() {
  return { log: "", body: 0 };
}
var Response_Int = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== 0) {
      writer.uint32(16).int32(message.body);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Int();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 16) {
            break;
          }
          message.body = reader.int32();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.Number(object.body) : 0
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== 0) {
      obj.body = Math.round(message.body);
    }
    return obj;
  },
  create(base) {
    return Response_Int.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Int();
    message.log = object.log ?? "";
    message.body = object.body ?? 0;
    return message;
  }
};
function createBaseResponse_Select() {
  return { entry: [] };
}
var Response_Select = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    for (const v of message.entry) {
      Types_SelectEntry.encode(v, writer.uint32(10).fork()).join();
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Select();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.entry.push(Types_SelectEntry.decode(reader, reader.uint32()));
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      entry: globalThis.Array.isArray(object?.entry) ? object.entry.map((e) => Types_SelectEntry.fromJSON(e)) : []
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.entry?.length) {
      obj.entry = message.entry.map((e) => Types_SelectEntry.toJSON(e));
    }
    return obj;
  },
  create(base) {
    return Response_Select.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Select();
    message.entry = object.entry?.map((e) => Types_SelectEntry.fromPartial(e)) || [];
    return message;
  }
};
function createBaseResponse_Json() {
  return { log: "", json: "", bodyPart: "" };
}
var Response_Json = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.json !== "") {
      writer.uint32(18).string(message.json);
    }
    if (message.bodyPart !== "") {
      writer.uint32(26).string(message.bodyPart);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_Json();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.json = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.bodyPart = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      json: isSet(object.json) ? globalThis.String(object.json) : "",
      bodyPart: isSet(object.bodyPart) ? globalThis.String(object.bodyPart) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.json !== "") {
      obj.json = message.json;
    }
    if (message.bodyPart !== "") {
      obj.bodyPart = message.bodyPart;
    }
    return obj;
  },
  create(base) {
    return Response_Json.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_Json();
    message.log = object.log ?? "";
    message.json = object.json ?? "";
    message.bodyPart = object.bodyPart ?? "";
    return message;
  }
};
function createBaseResponse_JavascriptExecutionResult() {
  return { log: "", result: "" };
}
var Response_JavascriptExecutionResult = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.result !== "") {
      writer.uint32(18).string(message.result);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_JavascriptExecutionResult();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.result = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      result: isSet(object.result) ? globalThis.String(object.result) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.result !== "") {
      obj.result = message.result;
    }
    return obj;
  },
  create(base) {
    return Response_JavascriptExecutionResult.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_JavascriptExecutionResult();
    message.log = object.log ?? "";
    message.result = object.result ?? "";
    return message;
  }
};
function createBaseResponse_NewContextResponse() {
  return { id: "", log: "", contextOptions: "", newBrowser: false };
}
var Response_NewContextResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.log !== "") {
      writer.uint32(18).string(message.log);
    }
    if (message.contextOptions !== "") {
      writer.uint32(26).string(message.contextOptions);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewContextResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.contextOptions = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      contextOptions: isSet(object.contextOptions) ? globalThis.String(object.contextOptions) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.contextOptions !== "") {
      obj.contextOptions = message.contextOptions;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    return obj;
  },
  create(base) {
    return Response_NewContextResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewContextResponse();
    message.id = object.id ?? "";
    message.log = object.log ?? "";
    message.contextOptions = object.contextOptions ?? "";
    message.newBrowser = object.newBrowser ?? false;
    return message;
  }
};
function createBaseResponse_NewPersistentContextResponse() {
  return { id: "", log: "", contextOptions: "", newBrowser: false, video: "", pageId: "", browserId: "" };
}
var Response_NewPersistentContextResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.id !== "") {
      writer.uint32(10).string(message.id);
    }
    if (message.log !== "") {
      writer.uint32(18).string(message.log);
    }
    if (message.contextOptions !== "") {
      writer.uint32(26).string(message.contextOptions);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    if (message.video !== "") {
      writer.uint32(42).string(message.video);
    }
    if (message.pageId !== "") {
      writer.uint32(50).string(message.pageId);
    }
    if (message.browserId !== "") {
      writer.uint32(58).string(message.browserId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewPersistentContextResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.id = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.contextOptions = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 42) {
            break;
          }
          message.video = reader.string();
          continue;
        }
        case 6: {
          if (tag !== 50) {
            break;
          }
          message.pageId = reader.string();
          continue;
        }
        case 7: {
          if (tag !== 58) {
            break;
          }
          message.browserId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      id: isSet(object.id) ? globalThis.String(object.id) : "",
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      contextOptions: isSet(object.contextOptions) ? globalThis.String(object.contextOptions) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false,
      video: isSet(object.video) ? globalThis.String(object.video) : "",
      pageId: isSet(object.pageId) ? globalThis.String(object.pageId) : "",
      browserId: isSet(object.browserId) ? globalThis.String(object.browserId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.id !== "") {
      obj.id = message.id;
    }
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.contextOptions !== "") {
      obj.contextOptions = message.contextOptions;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    if (message.video !== "") {
      obj.video = message.video;
    }
    if (message.pageId !== "") {
      obj.pageId = message.pageId;
    }
    if (message.browserId !== "") {
      obj.browserId = message.browserId;
    }
    return obj;
  },
  create(base) {
    return Response_NewPersistentContextResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewPersistentContextResponse();
    message.id = object.id ?? "";
    message.log = object.log ?? "";
    message.contextOptions = object.contextOptions ?? "";
    message.newBrowser = object.newBrowser ?? false;
    message.video = object.video ?? "";
    message.pageId = object.pageId ?? "";
    message.browserId = object.browserId ?? "";
    return message;
  }
};
function createBaseResponse_NewPageResponse() {
  return { log: "", body: "", video: "", newBrowser: false, newContext: false };
}
var Response_NewPageResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.body !== "") {
      writer.uint32(18).string(message.body);
    }
    if (message.video !== "") {
      writer.uint32(26).string(message.video);
    }
    if (message.newBrowser !== false) {
      writer.uint32(32).bool(message.newBrowser);
    }
    if (message.newContext !== false) {
      writer.uint32(40).bool(message.newContext);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_NewPageResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.body = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.video = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 32) {
            break;
          }
          message.newBrowser = reader.bool();
          continue;
        }
        case 5: {
          if (tag !== 40) {
            break;
          }
          message.newContext = reader.bool();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      body: isSet(object.body) ? globalThis.String(object.body) : "",
      video: isSet(object.video) ? globalThis.String(object.video) : "",
      newBrowser: isSet(object.newBrowser) ? globalThis.Boolean(object.newBrowser) : false,
      newContext: isSet(object.newContext) ? globalThis.Boolean(object.newContext) : false
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.body !== "") {
      obj.body = message.body;
    }
    if (message.video !== "") {
      obj.video = message.video;
    }
    if (message.newBrowser !== false) {
      obj.newBrowser = message.newBrowser;
    }
    if (message.newContext !== false) {
      obj.newContext = message.newContext;
    }
    return obj;
  },
  create(base) {
    return Response_NewPageResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_NewPageResponse();
    message.log = object.log ?? "";
    message.body = object.body ?? "";
    message.video = object.video ?? "";
    message.newBrowser = object.newBrowser ?? false;
    message.newContext = object.newContext ?? false;
    return message;
  }
};
function createBaseResponse_PageReportResponse() {
  return { log: "", errors: "", console: "", pageId: "" };
}
var Response_PageReportResponse = {
  encode(message, writer = new import_wire.BinaryWriter()) {
    if (message.log !== "") {
      writer.uint32(10).string(message.log);
    }
    if (message.errors !== "") {
      writer.uint32(18).string(message.errors);
    }
    if (message.console !== "") {
      writer.uint32(26).string(message.console);
    }
    if (message.pageId !== "") {
      writer.uint32(34).string(message.pageId);
    }
    return writer;
  },
  decode(input, length) {
    const reader = input instanceof import_wire.BinaryReader ? input : new import_wire.BinaryReader(input);
    const end = length === void 0 ? reader.len : reader.pos + length;
    const message = createBaseResponse_PageReportResponse();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1: {
          if (tag !== 10) {
            break;
          }
          message.log = reader.string();
          continue;
        }
        case 2: {
          if (tag !== 18) {
            break;
          }
          message.errors = reader.string();
          continue;
        }
        case 3: {
          if (tag !== 26) {
            break;
          }
          message.console = reader.string();
          continue;
        }
        case 4: {
          if (tag !== 34) {
            break;
          }
          message.pageId = reader.string();
          continue;
        }
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skip(tag & 7);
    }
    return message;
  },
  fromJSON(object) {
    return {
      log: isSet(object.log) ? globalThis.String(object.log) : "",
      errors: isSet(object.errors) ? globalThis.String(object.errors) : "",
      console: isSet(object.console) ? globalThis.String(object.console) : "",
      pageId: isSet(object.pageId) ? globalThis.String(object.pageId) : ""
    };
  },
  toJSON(message) {
    const obj = {};
    if (message.log !== "") {
      obj.log = message.log;
    }
    if (message.errors !== "") {
      obj.errors = message.errors;
    }
    if (message.console !== "") {
      obj.console = message.console;
    }
    if (message.pageId !== "") {
      obj.pageId = message.pageId;
    }
    return obj;
  },
  create(base) {
    return Response_PageReportResponse.fromPartial(base ?? {});
  },
  fromPartial(object) {
    const message = createBaseResponse_PageReportResponse();
    message.log = object.log ?? "";
    message.errors = object.errors ?? "";
    message.console = object.console ?? "";
    message.pageId = object.pageId ?? "";
    return message;
  }
};
var PlaywrightService = {
  /** Aria Snapshot */
  ariaSnapShot: {
    path: "/Playwright/AriaSnapShot",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AriaSnapShot.encode(value).finish()),
    requestDeserialize: (value) => Request_AriaSnapShot.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Cookie messages */
  addCookie: {
    path: "/Playwright/AddCookie",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getCookies: {
    path: "/Playwright/GetCookies",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  deleteAllCookies: {
    path: "/Playwright/DeleteAllCookies",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Screen shot method */
  takeScreenshot: {
    path: "/Playwright/TakeScreenshot",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ScreenshotOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ScreenshotOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Opens the url in currently open Playwright page */
  goTo: {
    path: "/Playwright/GoTo",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Navigate to the next page in history */
  goBack: {
    path: "/Playwright/GoBack",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Navigate to the previous page in history. */
  goForward: {
    path: "/Playwright/GoForward",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets title of currently open Playwright page */
  getTitle: {
    path: "/Playwright/GetTitle",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns the count of elements found with selector */
  getElementCount: {
    path: "/Playwright/GetElementCount",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  /** Wraps playwrights page.type to type text into input specified with selector */
  typeText: {
    path: "/Playwright/TypeText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_TypeText.encode(value).finish()),
    requestDeserialize: (value) => Request_TypeText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Wraps playwrights page.fill to fill text of input specified with selector */
  fillText: {
    path: "/Playwright/FillText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FillText.encode(value).finish()),
    requestDeserialize: (value) => Request_FillText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Wraps playwrights page.fill with empty text to clear input specified with selector */
  clearText: {
    path: "/Playwright/ClearText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClearText.encode(value).finish()),
    requestDeserialize: (value) => Request_ClearText.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets the DOM property 'property' of selector specified element */
  getDomProperty: {
    path: "/Playwright/GetDomProperty",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  getText: {
    path: "/Playwright/GetText",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets the XML attribute 'attribute' of selector specified element */
  getElementAttribute: {
    path: "/Playwright/GetElementAttribute",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets the boolean DOM property 'property' of selector specified element */
  getBoolProperty: {
    path: "/Playwright/GetBoolProperty",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementProperty.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementProperty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Bool.encode(value).finish()),
    responseDeserialize: (value) => Response_Bool.decode(value)
  },
  /** Wraps playwrights page.textContent, returns textcontent of element by selector */
  getViewportSize: {
    path: "/Playwright/GetViewportSize",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns current playwright page url */
  getUrl: {
    path: "/Playwright/GetUrl",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Gets page HTML code as a stream of Response.Json messages, with the source split into chunks via bodyPart */
  getPageSource: {
    path: "/Playwright/GetPageSource",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Inputs a list of keypresses to element specified by selector */
  press: {
    path: "/Playwright/Press",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PressKeys.encode(value).finish()),
    requestDeserialize: (value) => Request_PressKeys.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets the Select element specified by selector and returns the contents */
  getSelectContent: {
    path: "/Playwright/GetSelectContent",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Select.encode(value).finish()),
    responseDeserialize: (value) => Response_Select.decode(value)
  },
  /** Selects option matching matcher in Select element matching selector */
  selectOption: {
    path: "/Playwright/SelectOption",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_SelectElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_SelectElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Select.encode(value).finish()),
    responseDeserialize: (value) => Response_Select.decode(value)
  },
  /** Deselects options in Select element matching selector */
  deselectOption: {
    path: "/Playwright/DeselectOption",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Checks checkbox specified by selector */
  checkCheckbox: {
    path: "/Playwright/CheckCheckbox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Unchecks checkbox specified by selector */
  uncheckCheckbox: {
    path: "/Playwright/UncheckCheckbox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Health check endpoint for the service */
  health: {
    path: "/Playwright/Health",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns a reference to a Playwirght element handle. */
  getElement: {
    path: "/Playwright/GetElement",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Returns references to multiple Playwirght element handles. */
  getElements: {
    path: "/Playwright/GetElements",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns references to a Playwirght element handle. */
  getByX: {
    path: "/Playwright/GetByX",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_GetByOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_GetByOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Returns all Element states as IntFlag */
  getElementStates: {
    path: "/Playwright/GetElementStates",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Set's  playwright timeout */
  setTimeout: {
    path: "/Playwright/SetTimeout",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Timeout.encode(value).finish()),
    requestDeserialize: (value) => Request_Timeout.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Adds a <style> to head of site. */
  addStyleTag: {
    path: "/Playwright/AddStyleTag",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_StyleTag.encode(value).finish()),
    requestDeserialize: (value) => Request_StyleTag.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Highlights elements matching selector for duration */
  highlightElements: {
    path: "/Playwright/HighlightElements",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithDuration.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithDuration.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  /** Download url content */
  download: {
    path: "/Playwright/Download",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Clicks element specified by selector and options */
  click: {
    path: "/Playwright/Click",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Taps element specified by selector and options */
  tap: {
    path: "/Playwright/Tap",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Hovers an element specified by selector and options */
  hover: {
    path: "/Playwright/Hover",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Focuses element specified by selector */
  focus: {
    path: "/Playwright/Focus",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Waits for element be in a specific state */
  waitForElementsState: {
    path: "/Playwright/WaitForElementsState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelectorWithOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelectorWithOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Executes javascript on the active page and retries until the expression is true */
  waitForFunction: {
    path: "/Playwright/WaitForFunction",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_WaitForFunctionOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_WaitForFunctionOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Evaluates javascript on the active page */
  evaluateJavascript: {
    path: "/Playwright/EvaluateJavascript",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_EvaluateAll.encode(value).finish()),
    requestDeserialize: (value) => Request_EvaluateAll.decode(value),
    responseSerialize: (value) => Buffer.from(Response_JavascriptExecutionResult.encode(value).finish()),
    responseDeserialize: (value) => Response_JavascriptExecutionResult.decode(value)
  },
  recordSelector: {
    path: "/Playwright/RecordSelector",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Label.encode(value).finish()),
    requestDeserialize: (value) => Request_Label.decode(value),
    responseSerialize: (value) => Buffer.from(Response_JavascriptExecutionResult.encode(value).finish()),
    responseDeserialize: (value) => Response_JavascriptExecutionResult.decode(value)
  },
  /** Get Page State JSON */
  setViewportSize: {
    path: "/Playwright/SetViewportSize",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Viewport.encode(value).finish()),
    requestDeserialize: (value) => Request_Viewport.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Gets an elements computed style */
  getStyle: {
    path: "/Playwright/GetStyle",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementStyle.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementStyle.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Gets elements x, y coordinates and width, height as json object */
  getBoundingBox: {
    path: "/Playwright/GetBoundingBox",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Makes a `fetch` request in the browser */
  httpRequest: {
    path: "/Playwright/HttpRequest",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_HttpRequest.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpRequest.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForRequest: {
    path: "/Playwright/WaitForRequest",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_HttpCapture.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpCapture.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  waitForResponse: {
    path: "/Playwright/WaitForResponse",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_HttpCapture.encode(value).finish()),
    requestDeserialize: (value) => Request_HttpCapture.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForDownload: {
    path: "/Playwright/WaitForDownload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  waitForNavigation: {
    path: "/Playwright/WaitForNavigation",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  waitForPageLoadState: {
    path: "/Playwright/WaitForPageLoadState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PageLoadState.encode(value).finish()),
    requestDeserialize: (value) => Request_PageLoadState.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Geolocation */
  setGeolocation: {
    path: "/Playwright/SetGeolocation",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getDevice: {
    path: "/Playwright/GetDevice",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Device.encode(value).finish()),
    requestDeserialize: (value) => Request_Device.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getDevices: {
    path: "/Playwright/GetDevices",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  /** Locator handlers */
  addLocatorHandlerCustom: {
    path: "/Playwright/AddLocatorHandlerCustom",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_LocatorHandlerAddCustom.encode(value).finish()),
    requestDeserialize: (value) => Request_LocatorHandlerAddCustom.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  removeLocatorHandler: {
    path: "/Playwright/RemoveLocatorHandler",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_LocatorHandlerRemove.encode(value).finish()),
    requestDeserialize: (value) => Request_LocatorHandlerRemove.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  handleAlert: {
    path: "/Playwright/HandleAlert",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AlertAction.encode(value).finish()),
    requestDeserialize: (value) => Request_AlertAction.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  waitForAlerts: {
    path: "/Playwright/WaitForAlerts",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_AlertActions.encode(value).finish()),
    requestDeserialize: (value) => Request_AlertActions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_ListString.encode(value).finish()),
    responseDeserialize: (value) => Response_ListString.decode(value)
  },
  mouseButton: {
    path: "/Playwright/MouseButton",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_MouseButtonOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_MouseButtonOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  mouseMove: {
    path: "/Playwright/MouseMove",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  mouseWheel: {
    path: "/Playwright/MouseWheel",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_MouseWheel.encode(value).finish()),
    requestDeserialize: (value) => Request_MouseWheel.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  keyboardKey: {
    path: "/Playwright/KeyboardKey",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_KeyboardKeypress.encode(value).finish()),
    requestDeserialize: (value) => Request_KeyboardKeypress.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  keyboardInput: {
    path: "/Playwright/KeyboardInput",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_KeyboardInputOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_KeyboardInputOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getTableRowIndex: {
    path: "/Playwright/GetTableRowIndex",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  getTableCellIndex: {
    path: "/Playwright/GetTableCellIndex",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Int.encode(value).finish()),
    responseDeserialize: (value) => Response_Int.decode(value)
  },
  uploadFile: {
    path: "/Playwright/UploadFile",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  uploadFileBySelector: {
    path: "/Playwright/UploadFileBySelector",
    requestStream: true,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FileBySelector.encode(value).finish()),
    requestDeserialize: (value) => Request_FileBySelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  scrollToElement: {
    path: "/Playwright/ScrollToElement",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ElementSelector.encode(value).finish()),
    requestDeserialize: (value) => Request_ElementSelector.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  setOffline: {
    path: "/Playwright/SetOffline",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  reload: {
    path: "/Playwright/Reload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Playwright State handling keywords */
  switchPage: {
    path: "/Playwright/SwitchPage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_IdWithTimeout.encode(value).finish()),
    requestDeserialize: (value) => Request_IdWithTimeout.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  switchContext: {
    path: "/Playwright/SwitchContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  switchBrowser: {
    path: "/Playwright/SwitchBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  newPage: {
    path: "/Playwright/NewPage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_UrlOptions.encode(value).finish()),
    requestDeserialize: (value) => Request_UrlOptions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewPageResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewPageResponse.decode(value)
  },
  newContext: {
    path: "/Playwright/NewContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Context.encode(value).finish()),
    requestDeserialize: (value) => Request_Context.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewContextResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewContextResponse.decode(value)
  },
  newBrowser: {
    path: "/Playwright/NewBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Browser.encode(value).finish()),
    requestDeserialize: (value) => Request_Browser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  launchBrowserServer: {
    path: "/Playwright/LaunchBrowserServer",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Browser.encode(value).finish()),
    requestDeserialize: (value) => Request_Browser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeBrowserServer: {
    path: "/Playwright/CloseBrowserServer",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ConnectBrowser.encode(value).finish()),
    requestDeserialize: (value) => Request_ConnectBrowser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  newPersistentContext: {
    path: "/Playwright/NewPersistentContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_PersistentContext.encode(value).finish()),
    requestDeserialize: (value) => Request_PersistentContext.decode(value),
    responseSerialize: (value) => Buffer.from(Response_NewPersistentContextResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_NewPersistentContextResponse.decode(value)
  },
  connectToBrowser: {
    path: "/Playwright/ConnectToBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ConnectBrowser.encode(value).finish()),
    requestDeserialize: (value) => Request_ConnectBrowser.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeBrowser: {
    path: "/Playwright/CloseBrowser",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  closeAllBrowsers: {
    path: "/Playwright/CloseAllBrowsers",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closeContext: {
    path: "/Playwright/CloseContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closePage: {
    path: "/Playwright/ClosePage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClosePage.encode(value).finish()),
    requestDeserialize: (value) => Request_ClosePage.decode(value),
    responseSerialize: (value) => Buffer.from(Response_PageReportResponse.encode(value).finish()),
    responseDeserialize: (value) => Response_PageReportResponse.decode(value)
  },
  openTraceGroup: {
    path: "/Playwright/OpenTraceGroup",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_TraceGroup.encode(value).finish()),
    requestDeserialize: (value) => Request_TraceGroup.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  closeTraceGroup: {
    path: "/Playwright/CloseTraceGroup",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  setRfContext: {
    path: "/Playwright/SetRFContext",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_RFContext.encode(value).finish()),
    requestDeserialize: (value) => Request_RFContext.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  getConsoleLog: {
    path: "/Playwright/GetConsoleLog",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getErrorMessages: {
    path: "/Playwright/GetErrorMessages",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getBrowserCatalog: {
    path: "/Playwright/GetBrowserCatalog",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Bool.encode(value).finish()),
    requestDeserialize: (value) => Request_Bool.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  getDownloadState: {
    path: "/Playwright/GetDownloadState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadID.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadID.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  cancelDownload: {
    path: "/Playwright/CancelDownload",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_DownloadID.encode(value).finish()),
    requestDeserialize: (value) => Request_DownloadID.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  saveStorageState: {
    path: "/Playwright/SaveStorageState",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  grantPermissions: {
    path: "/Playwright/GrantPermissions",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Permissions.encode(value).finish()),
    requestDeserialize: (value) => Request_Permissions.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  executePlaywright: {
    path: "/Playwright/ExecutePlaywright",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Json.encode(value).finish()),
    requestDeserialize: (value) => Request_Json.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clearPermissions: {
    path: "/Playwright/ClearPermissions",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Extension handling */
  initializeExtension: {
    path: "/Playwright/InitializeExtension",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_FilePath.encode(value).finish()),
    requestDeserialize: (value) => Request_FilePath.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Keywords.encode(value).finish()),
    responseDeserialize: (value) => Response_Keywords.decode(value)
  },
  callExtensionKeyword: {
    path: "/Playwright/CallExtensionKeyword",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value) => Buffer.from(Request_KeywordCall.encode(value).finish()),
    requestDeserialize: (value) => Request_KeywordCall.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Json.encode(value).finish()),
    responseDeserialize: (value) => Response_Json.decode(value)
  },
  setPeerId: {
    path: "/Playwright/SetPeerId",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Index.encode(value).finish()),
    requestDeserialize: (value) => Request_Index.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** pdf */
  pdf: {
    path: "/Playwright/Pdf",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Pdf.encode(value).finish()),
    requestDeserialize: (value) => Request_Pdf.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  emulateMedia: {
    path: "/Playwright/EmulateMedia",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_EmulateMedia.encode(value).finish()),
    requestDeserialize: (value) => Request_EmulateMedia.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  /** Clock messages */
  setTime: {
    path: "/Playwright/SetTime",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockSetTime.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockSetTime.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clockResume: {
    path: "/Playwright/ClockResume",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  clockPauseAt: {
    path: "/Playwright/ClockPauseAt",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockSetTime.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockSetTime.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  advanceClock: {
    path: "/Playwright/AdvanceClock",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_ClockAdvance.encode(value).finish()),
    requestDeserialize: (value) => Request_ClockAdvance.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  /** Coverage */
  startCoverage: {
    path: "/Playwright/StartCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_CoverageStart.encode(value).finish()),
    requestDeserialize: (value) => Request_CoverageStart.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  },
  stopCoverage: {
    path: "/Playwright/StopCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_Empty.encode(value).finish()),
    requestDeserialize: (value) => Request_Empty.decode(value),
    responseSerialize: (value) => Buffer.from(Response_String.encode(value).finish()),
    responseDeserialize: (value) => Response_String.decode(value)
  },
  mergeCoverage: {
    path: "/Playwright/MergeCoverage",
    requestStream: false,
    responseStream: false,
    requestSerialize: (value) => Buffer.from(Request_CoverageMerge.encode(value).finish()),
    requestDeserialize: (value) => Request_CoverageMerge.decode(value),
    responseSerialize: (value) => Buffer.from(Response_Empty.encode(value).finish()),
    responseDeserialize: (value) => Response_Empty.decode(value)
  }
};
var PlaywrightClient = (0, import_grpc_js.makeGenericClientConstructor)(PlaywrightService, "Playwright");
function isSet(value) {
  return value !== null && value !== void 0;
}

// node/playwright-wrapper/playwright-invoke.ts
async function findLocator(state, selector, strictMode, nthLocator, firstOnly) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  if (strictMode) {
    selector = selector.replaceAll(" >>> ", " >> internal:control=enter-frame >> ");
  } else {
    selector = selector.replaceAll(" >>> ", " >> nth=0 >> internal:control=enter-frame >> ");
  }
  if (nthLocator !== void 0) {
    return await findNthLocator(activePage, selector, nthLocator);
  } else if (strictMode) {
    logger.info(`Strict mode is enabled, find Locator with ${selector} in page.`);
    return activePage.locator(selector);
  } else {
    return await findLocatorNotStrict(activePage, selector, firstOnly);
  }
}
async function findNthLocator(activePage, selector, nthLocator) {
  logger.info(`Find ${nthLocator} Locator in page.`);
  return activePage.locator(selector).nth(nthLocator);
}
async function findLocatorNotStrict(activePage, selector, firstOnly) {
  if (firstOnly) {
    logger.info(`Strict mode is disabled, return first Locator: ${selector} in page.`);
    return activePage.locator(selector).first();
  } else {
    logger.info(`Strict mode is disabled, return Locator: ${selector} in page.`);
    return activePage.locator(selector);
  }
}
async function invokeOnMouse(page, methodName, args2) {
  exists(page, `Tried to execute mouse action '${methodName}' but no open page`);
  logger.info(`Invoking mouse action ${methodName} with params ${JSON.stringify(args2)}`);
  const fn = page?.mouse[methodName].bind(page.mouse);
  exists(fn, `Bind failure with '${fn}'`);
  return await fn(...Object.values(args2));
}
async function invokeOnKeyboard(page, methodName, ...args2) {
  logger.info(`Invoking keyboard action ${methodName} with params ${JSON.stringify(args2)}`);
  const fn = page.keyboard[methodName].bind(page.keyboard);
  exists(fn, `Bind failure with '${fn}'`);
  return await fn(...Object.values(args2));
}
function exists(obj, message) {
  if (!obj) {
    throw new Error(message);
  }
}

// node/playwright-wrapper/response-util.ts
var import_grpc_js2 = require("@grpc/grpc-js");
var import_playwright = require("playwright");
function emptyWithLog(text) {
  return { log: text };
}
function pageReportResponse(log, page) {
  return {
    log,
    console: JSON.stringify(
      page.consoleMessages.map((m) => ({
        time: m.time,
        type: m.type,
        text: m.text,
        location: m.location
      }))
    ),
    errors: JSON.stringify(
      page.pageErrors.map((e) => e ? `${e.name}: ${e.message}
${e.stack}` : "unknown error")
    ),
    pageId: page.id
  };
}
function getConsoleLogResponse(page, fullLog, message) {
  const consoleMessages = page.consoleMessages;
  const responseMessages = fullLog ? consoleMessages : consoleMessages.slice(page.consoleIndex);
  page.consoleIndex = consoleMessages.length;
  return { log: message, json: JSON.stringify(responseMessages), bodyPart: "" };
}
function getErrorMessagesResponse(page, fullLog, message) {
  const pageErrors = page.pageErrors;
  const responseErrors = fullLog ? pageErrors : pageErrors.slice(page.errorIndex);
  page.errorIndex = pageErrors.length;
  return { log: message, json: JSON.stringify(responseErrors), bodyPart: "" };
}
function stringResponse(body, logMessage) {
  return { body, log: logMessage };
}
function jsonResponse(body, logMessage, bodyPart = "") {
  return { json: body, log: logMessage, bodyPart };
}
function intResponse(body, logMessage) {
  return { body, log: logMessage };
}
function boolResponse(value, logMessage) {
  return { body: value, log: logMessage };
}
function jsResponse(result, logMessage) {
  return { result: JSON.stringify(result), log: logMessage };
}
function errorResponse(e) {
  logger.error(
    { event_kind: "grpc_error", status: "failed", error_type: errorType(e) },
    e instanceof Error ? e.stack ?? e.message : String(e)
  );
  if (!(e instanceof Error)) return null;
  const errorMessage = e.toString().substring(0, 5e3);
  let errorCode = import_grpc_js2.status.RESOURCE_EXHAUSTED;
  if (e instanceof import_playwright.errors.TimeoutError) {
    errorCode = import_grpc_js2.status.DEADLINE_EXCEEDED;
  }
  return { code: errorCode, message: errorMessage };
}
function keywordsResponse(keywords, keywordArguments, keywordDocs, logMessage) {
  return {
    keywords,
    keywordDocumentations: keywordDocs,
    keywordArguments,
    log: logMessage
  };
}
function parseRegExpOrKeepString(str) {
  const regex = /^\/(?<matcher>.*)\/(?<flags>[gimsuy]+)?$/;
  try {
    const match = str.match(regex);
    if (match) {
      const { matcher, flags } = match.groups;
      return new RegExp(matcher, flags);
    }
    return str;
  } catch {
    return str;
  }
}

// node/playwright-wrapper/browser-control.ts
var { program: pwProgram } = require("playwright-core/lib/cli/program");
async function executePlaywright(request) {
  const args2 = JSON.parse(request.body);
  pwProgram.exitOverride();
  await pwProgram.parseAsync(args2, { from: "user" });
  return emptyWithLog("Executed Playwright command: " + args2.join(" "));
}
async function grantPermissions(request, state) {
  const browserContext = state.getActiveContext();
  if (!browserContext) {
    return emptyWithLog(`No browser context is active. Use 'Open Browser' to open a new one.`);
  }
  await browserContext.grantPermissions(request.permissions, {
    ...request.origin.length > 0 && { origin: request.origin }
  });
  return emptyWithLog(
    `Granted permissions "${request.permissions.join(", ")}"` + (request.origin.length > 0 ? ` for origin "${request.origin}"` : "")
  );
}
async function clearPermissions(request, state) {
  const browserContext = state.getActiveContext();
  if (!browserContext) {
    return emptyWithLog(`No browser context is active. Use 'Open Browser' to open a new one.`);
  }
  await browserContext.clearPermissions();
  return emptyWithLog("Cleared all permissions");
}
async function goTo(request, page) {
  const url = request.url?.url || "about:blank";
  const timeout = request.url?.defaultTimeout;
  const goToOptions = { timeout };
  const waitUntil = request.waitUntil;
  if (waitUntil) {
    goToOptions.waitUntil = waitUntil;
  }
  const response = await page.goto(url, goToOptions);
  return stringResponse(response?.status().toString() || "", `Successfully opened URL ${url}`);
}
async function takeScreenshot(request, state) {
  const selector = request.selector;
  const options = JSON.parse(request.options);
  const mask = JSON.parse(request.mask);
  const strictMode = request.strict;
  const page = state.getActivePage();
  exists(page, "Tried to take screenshot, but no page was open.");
  if (mask) {
    const mask_locators = [];
    for (const sel of mask) {
      mask_locators.push(await findLocator(state, sel, false, void 0, false));
    }
    options.mask = mask_locators;
  }
  logger.info({ "Take screenshot with options: ": options });
  if (selector) {
    logger.info({ "Using selecotr: ": selector });
    const locator = await findLocator(state, selector, strictMode, void 0, true);
    await locator.screenshot(options);
  } else {
    await page.screenshot(options);
  }
  const message = "Screenshot successfully captured to: " + options.path;
  return stringResponse(options.path, message);
}
async function setTimeout2(request, context) {
  if (!context) {
    return emptyWithLog(`No context open.`);
  }
  const timeout = request.timeout;
  context.setDefaultTimeout(timeout);
  return emptyWithLog(`Set timeout to: ${timeout}`);
}
async function setViewportSize(request, page) {
  const size = { width: request.width, height: request.height };
  await page.setViewportSize(size);
  return emptyWithLog(`Set viewport size to: ${JSON.stringify(size)}`);
}
async function setOffline(request, context) {
  exists(context, "Tried to toggle context to offline, no open context");
  const offline = request.value;
  await context.setOffline(offline);
  return emptyWithLog(`Set context to ${offline}`);
}
async function reload(page, body) {
  const options = JSON.parse(body);
  logger.info(`Reload page with options: ${body}`);
  await page.reload(options);
  return emptyWithLog(`Reloaded page with options: ${body}`);
}
async function setGeolocation(request, context) {
  const geolocation = JSON.parse(request.body);
  await context?.setGeolocation(geolocation);
  return emptyWithLog("Geolocation set to: " + JSON.stringify(geolocation));
}

// node/playwright-wrapper/clock.ts
async function setTime(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let time = request.time;
  time = time * 1e3;
  const clockType = request.setType;
  const setTime2 = new Date(time).toISOString();
  if (clockType === "fixed") {
    logger.info(`Setting time to ${time} ${setTime2} as fixed`);
    await activePage.clock.setFixedTime(time);
  } else if (clockType === "system") {
    logger.info(`Setting time to ${time} ${setTime2} as system`);
    await activePage.clock.setSystemTime(time);
  } else if (clockType === "install") {
    logger.info(`Setting time to ${time} ${setTime2} as install`);
    await activePage.clock.install({ time });
  } else {
    logger.info(`Invalid clock type ${clockType}`);
    return emptyWithLog("Invalid clock type");
  }
  return emptyWithLog(`Time set to ${setTime2} as ${clockType}`);
}
async function clockResume(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  await activePage.clock.resume();
  return emptyWithLog("Clock resumed");
}
async function clockPauseAt(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let time = request.time;
  time = time * 1e3;
  const setTime2 = new Date(time).toISOString();
  logger.info(`Pausing clock at ${time} ${setTime2}`);
  await activePage.clock.pauseAt(time);
  return emptyWithLog(`Clock paused at ${setTime2}`);
}
async function advanceClock(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const time = request.time;
  const timeMs = time * 1e3;
  const advanceType = request.advanceType;
  logger.info(`Advancing clock by ${timeMs} ${advanceType}`);
  if (advanceType === "fast_forward") {
    await activePage.clock.fastForward(timeMs);
  } else if (advanceType === "run_for") {
    await activePage.clock.runFor(timeMs);
  }
  return emptyWithLog(`Clock advanced by ${timeMs} seconds by ${advanceType}`);
}

// node/playwright-wrapper/cookie.ts
async function getCookies(context) {
  const allCookies = await context.cookies();
  logger.info({ "Cookies: ": allCookies });
  const cookieName = [];
  for (const cookie of allCookies) {
    cookieName.push(cookie.name);
  }
  return jsonResponse(JSON.stringify(allCookies), cookieName.toString());
}
async function addCookie(request, context) {
  const cookie = JSON.parse(request.body);
  logger.info({ "Cookie data: ": request.body });
  await context.addCookies([cookie]);
  return emptyWithLog('Cookie "' + cookie.name + '" added.');
}
async function deleteAllCookies(context) {
  await context.clearCookies();
  return emptyWithLog("All cookies deleted.");
}

// node/playwright-wrapper/device-descriptors.ts
var import_playwright2 = require("playwright");
function getDevice(request) {
  const name = request.name;
  const device = import_playwright2.devices[name];
  if (!device) throw new Error(`No device named ${name}`);
  return jsonResponse(JSON.stringify(device), "");
}
function getDevices() {
  return jsonResponse(JSON.stringify(import_playwright2.devices), "");
}

// node/playwright-wrapper/evaluation.ts
var path2 = __toESM(require("path"));

// node/playwright-wrapper/network.ts
var path = __toESM(require("path"));

// node_modules/uuid/dist-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist-node/rng.js
var rnds8 = new Uint8Array(16);
function rng() {
  return crypto.getRandomValues(rnds8);
}

// node_modules/uuid/dist-node/v4.js
function v4(options, buf, offset) {
  if (!buf && !options && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return _v4(options, buf, offset);
}
function _v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// node/playwright-wrapper/chunking.ts
var MAX_RESPONSE_CHUNK_BYTES = 1e6;
function splitUtf8ByMaxBytes(text, maxBytes) {
  if (!text) {
    return [];
  }
  const chunks = [];
  let current = "";
  let currentBytes = 0;
  for (const char of text) {
    const charBytes = Buffer.byteLength(char, "utf8");
    if (currentBytes + charBytes > maxBytes && current.length > 0) {
      chunks.push(current);
      current = char;
      currentBytes = charBytes;
    } else {
      current += char;
      currentBytes += charBytes;
    }
  }
  if (current.length > 0) {
    chunks.push(current);
  }
  return chunks;
}

// node/playwright-wrapper/network.ts
async function httpRequest(request, page) {
  const opts = {
    method: request.method,
    url: request.url,
    headers: JSON.parse(request.headers)
  };
  if (opts.method != "GET") {
    opts.body = request.body;
  }
  const response = await page.evaluate(({ url, method, body, headers }) => {
    return fetch(url, { method, body, headers }).then((data) => {
      return data.text().then((body2) => {
        const headers2 = {};
        data.headers.forEach((value, name) => headers2[name] = value);
        return {
          status: data.status,
          body: body2,
          headers: JSON.stringify(headers2),
          type: data.type,
          statusText: data.statusText,
          url: data.url,
          ok: data.ok,
          redirected: data.redirected
        };
      });
    });
  }, opts);
  return jsonResponse(JSON.stringify(response), "Request performed successfully.");
}
function deserializeUrlOrPredicate(urlOrPredicate) {
  if (/^function.*{.*}$/.test(urlOrPredicate) || /([a-zA-Z]\w*|\([a-zA-Z]\w*(,\s*[a-zA-Z]\w*)*\)) =>/.test(urlOrPredicate)) {
    const fn = new Function(`return (${urlOrPredicate})`)();
    if (typeof fn === "function" || Object.prototype.toString.call(fn) === "[object Function]") {
      return fn;
    }
  }
  return parseRegExpOrKeepString(urlOrPredicate);
}
async function waitForResponse(request, page) {
  const urlOrPredicate = deserializeUrlOrPredicate(request.urlOrPredicate);
  const timeout = request.timeout;
  const data = await page.waitForResponse(urlOrPredicate, { timeout });
  let body = null;
  try {
    body = await data.text();
  } catch (e) {
    logger.info(`Error reading response ${String(e)}`);
  }
  const jsonData = JSON.stringify({
    status: data.status(),
    headers: JSON.stringify(data.headers()),
    statusText: data.statusText(),
    url: data.url(),
    ok: data.ok(),
    request: {
      headers: JSON.stringify(data.request().headers()),
      method: data.request().method(),
      postData: data.request().postData()
    }
  });
  const responseChunks = [];
  if (body !== null) {
    const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
    if (bodyChunks.length > 1) {
      logger.info(`body.length: ${body.length}`);
      for (let i = 0; i < bodyChunks.length; i++) {
        const response = jsonResponse(jsonData, `Response received, chunk ${i}`, bodyChunks[i]);
        logger.info(`chunked response: ${i}`);
        responseChunks.push(response);
      }
    } else {
      responseChunks.push(jsonResponse(jsonData, "Response received", body));
    }
  } else {
    const jsonDataMap = JSON.parse(jsonData);
    jsonDataMap.body = null;
    responseChunks.push(jsonResponse(JSON.stringify(jsonDataMap), "Response received with empty body", ""));
  }
  logger.info(`responseChunks.length: ${responseChunks.length}`);
  return responseChunks;
}
async function waitForRequest(request, page) {
  const urlOrPredicate = deserializeUrlOrPredicate(request.urlOrPredicate);
  const timeout = request.timeout;
  const result = await page.waitForRequest(urlOrPredicate, { timeout });
  return stringResponse(result.url(), "Request completed within timeout.");
}
async function waitForNavigation(request, page) {
  const url = parseRegExpOrKeepString(request.url?.url);
  const timeout = request.url?.defaultTimeout;
  const waitUntil = request.waitUntil;
  await page.waitForNavigation({ timeout, url, waitUntil });
  return emptyWithLog(`Navigated to: ${url}, location is: ${page.url()}`);
}
async function WaitForPageLoadState(request, page) {
  const state = request.state;
  const timeout = request.timeout;
  logger.info(`timeout: ${timeout} state: ${state}`);
  await page.waitForLoadState(state, { timeout });
  return emptyWithLog(`Load state ${state} got in ${timeout}`);
}
async function waitForDownload(request, state, page) {
  const saveAs = request.path;
  const waitForFinish = request.waitForFinish;
  const downloadTimeout = request.downloadTimeout;
  return await _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinish);
}
async function _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinished) {
  const downloadObject = await page.waitForEvent("download");
  const downloadsPath = state.activeBrowser.browser?._options?.downloadsPath;
  if (downloadsPath && saveAs) {
    logger.info("saveAs: " + path.resolve(downloadsPath, saveAs));
    if (!path.isAbsolute(saveAs)) {
      saveAs = path.resolve(downloadsPath, saveAs);
    }
  }
  const fileName = downloadObject.suggestedFilename();
  if (!waitForFinished) {
    const downloadID = v4_default();
    const activeIndexedPage = state.activeBrowser?.page;
    if (activeIndexedPage) {
      activeIndexedPage.activeDownloads.set(downloadID, {
        downloadObject,
        suggestedFilename: fileName,
        saveAs
      });
      return jsonResponse(
        JSON.stringify({
          saveAs: "",
          suggestedFilename: fileName,
          state: "in_progress",
          downloadID
        }),
        "Download started successfully."
      );
    } else {
      throw new Error("No active page found");
    }
  }
  if (downloadTimeout > 0) {
    const readStream = await Promise.race([
      downloadObject.createReadStream(),
      new Promise((resolve2) => setTimeout(resolve2, downloadTimeout))
    ]);
    if (!readStream) {
      await downloadObject.cancel();
      throw new Error("Download failed, Timeout exceeded.");
    }
  }
  let filePath;
  if (saveAs) {
    await downloadObject.saveAs(saveAs);
    filePath = path.resolve(saveAs);
  } else {
    filePath = await downloadObject.path();
  }
  logger.info("suggestedFilename: " + fileName + " saveAs path: " + filePath);
  return jsonResponse(
    JSON.stringify({ saveAs: filePath, suggestedFilename: fileName, state: "finished", downloadID: null }),
    "Download done successfully to: " + filePath
  );
}
async function getDownloadState(request, state) {
  const downloadID = request.id;
  const activeIndexedPage = state.activeBrowser?.page;
  if (!activeIndexedPage) {
    throw new Error("No active page found");
  }
  const downloadInfo = activeIndexedPage.activeDownloads.get(downloadID);
  if (!downloadInfo) {
    throw new Error("No download object found for id: " + downloadID);
  }
  const downloadObject = downloadInfo.downloadObject;
  const suggestedFilename = downloadInfo.suggestedFilename;
  const failure = await Promise.race([downloadObject.failure(), new Promise((resolve2) => setTimeout(resolve2, 50))]);
  if (failure === null) {
    const saveAs = downloadInfo.saveAs;
    let filePath;
    if (saveAs) {
      await downloadObject.saveAs(saveAs);
      filePath = path.resolve(saveAs);
    } else {
      filePath = await downloadObject.path();
    }
    return jsonResponse(
      JSON.stringify({
        saveAs: filePath,
        suggestedFilename,
        state: "finished",
        downloadID
      }),
      "Download state received"
    );
  } else if (failure) {
    return jsonResponse(
      JSON.stringify({
        saveAs: "",
        suggestedFilename,
        state: failure,
        downloadID
      }),
      "Download state received"
    );
  } else {
    return jsonResponse(
      JSON.stringify({
        saveAs: "",
        suggestedFilename,
        state: "in_progress",
        downloadID
      }),
      "Download state received"
    );
  }
}
async function cancelDownload(request, state) {
  const downloadID = request.id;
  const activeIndexedPage = state.activeBrowser?.page;
  if (!activeIndexedPage) {
    throw new Error("No active page found");
  }
  const downloadInfo = activeIndexedPage.activeDownloads.get(downloadID);
  if (!downloadInfo) {
    throw new Error("No download object found for id: " + downloadID);
  }
  const downloadObject = downloadInfo.downloadObject;
  await downloadObject.cancel();
  const failure = await downloadObject.failure();
  if (failure == "canceled") {
    return emptyWithLog("Download canceled successfully.");
  } else if (failure === null) {
    return emptyWithLog("Canceling download not possible anymore, download finished.");
  } else {
    return emptyWithLog(`Canceling download not possible anymore, download ${failure}.`);
  }
}

// node/playwright-wrapper/evaluation.ts
async function getElement(request, state) {
  const strictMode = request.strict;
  const selector = request.selector;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.waitFor({ state: "attached" });
  return stringResponse(locator._selector, "Locator found successfully.");
}
async function getElements(request, state) {
  const selector = request.selector;
  const locator = await findLocator(state, selector, false, void 0, false);
  logger.info(`Wait element to reach attached state.`);
  try {
    await locator.first().waitFor({ state: "attached" });
  } catch (e) {
    logger.debug(`Attached state not reached, suppress error: ${String(e)}.`);
  }
  const allLocators = await locator.all();
  logger.info(`Found ${allLocators.length} elements.`);
  const allSelectors = allLocators.map((locator2) => locator2._selector);
  return jsonResponse(JSON.stringify(allSelectors), `Found ${allLocators.length} Locators successfully.`);
}
async function getByX(request, state) {
  const strategy = request.strategy;
  const text = parseRegExpOrKeepString(request.text);
  const options = JSON.parse(request.options);
  const strictMode = request.strict;
  const allElements = request.all;
  const frameSelector = request.frameSelector;
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  let document2 = activePage;
  if (frameSelector) {
    document2 = activePage.frameLocator(frameSelector);
    if (!strictMode) {
      document2 = document2.first();
    }
  }
  let locator;
  switch (strategy) {
    case "AltText": {
      locator = document2.getByAltText(text, options);
      break;
    }
    case "Label": {
      locator = document2.getByLabel(text, options);
      break;
    }
    case "Placeholder": {
      locator = document2.getByPlaceholder(text, options);
      break;
    }
    case "Role": {
      if (options?.name) {
        options.name = parseRegExpOrKeepString(options.name);
      }
      locator = document2.getByRole(text, options);
      break;
    }
    case "TestId": {
      locator = document2.getByTestId(text);
      break;
    }
    case "Text": {
      locator = document2.getByText(text, options);
      break;
    }
    case "Title": {
      locator = document2.getByTitle(text, options);
      break;
    }
    default: {
      throw new Error(`Strategy ${strategy} not supported.`);
    }
  }
  if (!allElements) {
    if (!strictMode) {
      locator = locator.first();
    }
    await locator.waitFor({ state: "attached" });
    return jsonResponse(JSON.stringify(locator._selector), "Locator found successfully.");
  }
  let allSelectors = [];
  try {
    await locator.first().waitFor({ state: "attached" });
    allSelectors = await locator.all().then((locators) => locators.map((loc) => loc._selector));
  } catch (e) {
    logger.debug(`Attached state not reached, suppress error: ${String(e)}.`);
  }
  return jsonResponse(JSON.stringify(allSelectors), `${allSelectors.length} locators found successfully.`);
}
var tryToTransformStringToFunction = (str) => {
  try {
    return new Function("return " + str)();
  } catch (ignored) {
    logger.debug(`Failed to transform string to function: ${String(ignored)}`);
    return str;
  }
};
async function evaluateJavascript(request, state, page) {
  const selector = request.selector;
  const script = tryToTransformStringToFunction(request.script);
  const strictMode = request.strict;
  const arg = JSON.parse(request.arg);
  const allElements = request.allElements;
  async function getJSResult() {
    if (selector !== "") {
      const locator = await findLocator(state, selector, strictMode, void 0, !allElements);
      if (allElements) {
        return await locator.evaluateAll(script, arg);
      }
      return await locator.evaluate(script, arg);
    }
    return await page.evaluate(script, arg);
  }
  return jsResponse(await getJSResult(), "JavaScript executed successfully.");
}
async function waitForElementState(request, state) {
  const selector = request.selector;
  const { state: elementState, timeout } = JSON.parse(request.options);
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  if (elementState === "detached" || elementState === "attached" || elementState === "hidden" || elementState === "visible") {
    await locator.waitFor({ state: elementState, timeout });
  } else {
    const element = await locator.elementHandle({ timeout });
    await element?.waitForElementState(elementState, { timeout });
  }
  return emptyWithLog(`Waited for Element with selector ${selector} at state ${elementState}`);
}
async function waitForFunction(request, state, page) {
  const script = tryToTransformStringToFunction(request.script);
  const selector = request.selector;
  const options = JSON.parse(request.options);
  const strictMode = request.strict;
  logger.info(`unparsed args: ${request.script}, ${request.selector}, ${request.options}`);
  let elem;
  if (selector) {
    const locator = await findLocator(state, selector, strictMode, void 0, true);
    elem = await locator.elementHandle();
  }
  const result = await page.waitForFunction(script, elem, options);
  return jsonResponse(JSON.stringify(await result.jsonValue()), "Wait For Function completed successfully.");
}
async function addStyleTag(request, page) {
  const content = request.content;
  await page.addStyleTag({ content });
  return emptyWithLog("added Style: " + content);
}
var selectorsForPage = {};
async function recordSelector(request, state) {
  if (state.getActiveBrowser().headless) {
    throw Error("Record Selector works only with visible browser. Use Open Browser or New Browser  headless=False");
  }
  const activeBrowser = state.activeBrowser;
  if (!activeBrowser) {
    throw Error("No active browser.");
  }
  const indexedPage2 = activeBrowser.page;
  if (!indexedPage2) {
    throw Error("No active page.");
  }
  const page = indexedPage2.p;
  await page.bringToFront();
  if (!(indexedPage2.id in selectorsForPage)) {
    const myselectors = [];
    selectorsForPage[indexedPage2.id] = myselectors;
    await page.exposeFunction("setRecordedSelector", (index, item) => {
      while (myselectors.length > index) {
        myselectors.pop();
      }
      myselectors.push(item);
    });
    await page.exposeFunction("getRecordedSelectors", () => {
      return myselectors;
    });
    await page.exposeFunction("highlightPWSelector", (selector) => {
      void highlightAll(selector, 1e3, "3px", "dotted", "blue", false, state);
    });
  }
  const result = await recordSelectorIterator(request.label, page.mainFrame());
  while (selectorsForPage[indexedPage2.id].length) {
    selectorsForPage[indexedPage2.id].pop();
  }
  return jsResponse(result, "Selector recorded.");
}
async function attachSelectorFinderScript(frame) {
  try {
    await frame.addScriptTag({
      type: "module",
      path: path2.join(__dirname, "/static/selector-finder.js")
    });
  } catch (e) {
    throw new Error(
      `Adding selector recorder to page failed.
Try New Context  bypassCSP=True and retry recording.`,
      { cause: e }
    );
  }
  await Promise.all(frame.childFrames().map((child) => attachSelectorFinderScript(child)));
}
async function attachSubframeListeners(subframe, index) {
  await subframe.evaluate((index2) => {
    function rafAsync() {
      return new Promise((resolve2) => {
        requestAnimationFrame(resolve2);
      });
    }
    function waitUntilRecorderAvailable() {
      if (!window.subframeSelectorRecorderFindSelector) {
        return rafAsync().then(() => waitUntilRecorderAvailable());
      } else {
        return Promise.resolve(window.subframeSelectorRecorderFindSelector(index2));
      }
    }
    return waitUntilRecorderAvailable();
  }, index);
  await Promise.all(
    subframe.childFrames().filter((f) => f.parentFrame() === subframe).map((child) => attachSubframeListeners(child, index + 1))
  );
}
async function recordSelectorIterator(label, frame) {
  await attachSelectorFinderScript(frame);
  await Promise.all(
    frame.childFrames().filter((f) => f.parentFrame() === frame).map((child) => attachSubframeListeners(child, 1))
  );
  return await frame.evaluate((label2) => {
    function rafAsync() {
      return new Promise((resolve2) => {
        requestAnimationFrame(resolve2);
      });
    }
    function waitUntilRecorderAvailable() {
      if (!window.selectorRecorderFindSelector) {
        return rafAsync().then(() => waitUntilRecorderAvailable());
      } else {
        return Promise.resolve(window.selectorRecorderFindSelector(label2));
      }
    }
    return waitUntilRecorderAvailable();
  }, label);
}
async function highlightElements(request, state) {
  const selector = request.selector;
  const duration = request.duration;
  const width = request.width;
  const style = request.style;
  const color = request.color;
  const strictMode = request.strict;
  const mode = request.mode;
  const count = await highlightAll(
    selector,
    duration,
    width,
    style,
    color,
    strictMode,
    state,
    mode
  );
  const message = duration ? `Highlighted ${count} elements for ${duration} ms.` : `Highlighting ${count} elements`;
  return intResponse(count, message);
}
async function highlightAll(selector, duration, width, style, color, strictMode, state, mode = "border") {
  const locator = await findLocator(state, selector, strictMode, void 0, false);
  let count;
  try {
    count = await locator.count();
  } catch (e) {
    logger.info(e);
    return 0;
  }
  logger.info(`Locator count is ${count}`);
  if (["playwright", "both"].includes(mode)) {
    void locator.highlight();
    if (duration !== 0) {
      setTimeout(() => {
        void state.getActivePage()?.locator("none.highlight-no-element").highlight();
      }, duration);
    }
    if (mode === "playwright") {
      return count;
    }
  }
  await locator.evaluateAll(
    (elements, options) => {
      elements.forEach((e) => {
        const d = document.createElement("div");
        d.className = "robotframework-browser-highlight";
        d.appendChild(document.createTextNode(""));
        d.style.position = "fixed";
        const rect = e.getBoundingClientRect();
        d.style.zIndex = "2147483647";
        d.style.top = `calc(${rect.top}px - ${options?.wdt ?? "1px"})`;
        d.style.left = `calc(${rect.left}px - ${options?.wdt ?? "1px"})`;
        d.style.width = `${rect.width}px`;
        d.style.height = `${rect.height}px`;
        d.style.border = `${options?.wdt ?? "1px"} ${options?.stl ?? `dotted`} ${options?.clr ?? `blue`}`;
        d.style.boxSizing = "content-box";
        document.body.appendChild(d);
        if (options?.dur !== 0) {
          setTimeout(() => {
            d.remove();
          }, options?.dur ?? 5e3);
        }
      });
    },
    { dur: duration, wdt: width, stl: style, clr: color }
  );
  return count;
}
async function download(request, state) {
  const browserState = state.activeBrowser;
  if (browserState === void 0) {
    throw new Error("Download requires an active browser");
  }
  const context = browserState.context;
  if (context === void 0) {
    throw new Error("Download requires an active context");
  }
  if (!(context.options?.acceptDownloads ?? false)) {
    throw new Error("Context acceptDownloads is false");
  }
  const page = state.getActivePage();
  if (page === void 0) {
    throw new Error("Download requires an active page");
  }
  const urlString = request.url;
  const saveAs = request.path;
  const downloadTimeout = request.downloadTimeout;
  const waitForFinish = request.waitForFinish;
  const fromUrl = page.url();
  if (fromUrl === "about:blank") {
    throw new Error("Download requires that the page has been navigated to an url");
  }
  const script = (urlString2) => {
    return fetch(urlString2).then((resp) => {
      return resp.blob();
    }).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = urlString2;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      return a.download;
    });
  };
  const downloadStarted = _waitForDownload(page, state, saveAs, downloadTimeout, waitForFinish);
  logger.info(`Starting download from ${urlString} to ${saveAs}`);
  await page.evaluate(script, urlString);
  return await downloadStarted;
}

// node/playwright-wrapper/getters.ts
var import_playwright3 = require("playwright");
async function getAriaSnapshot(request, state) {
  const selector = request.locator;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const snapshot = await locator.ariaSnapshot();
  logger.info(`Aria snapshot for ${selector}: ${snapshot}`);
  return stringResponse(snapshot, "Aria snapshot received successfully.");
}
async function getTitle(page) {
  const title = await page.title();
  return stringResponse(title, "Active page title is: " + title);
}
async function getUrl(page) {
  const url = page.url();
  return stringResponse(url, url);
}
async function getElementCount(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, false);
  let count = 0;
  try {
    count = await locator.count();
  } catch (e) {
    if (!(e instanceof Error && e.message.includes("failed to find frame for selector"))) {
      throw e;
    }
  }
  return intResponse(count, `Found ${count} element(s).`);
}
async function getSelections(locator) {
  const selectElement = await locator.elementHandle();
  const selectOptions = await selectElement?.evaluate((e) => {
    return Array.from(e.options).map((option) => ({
      label: option.label,
      value: option.value,
      index: option.index,
      selected: option.selected
    }));
  });
  const entry = [];
  if (selectOptions) {
    const entries = selectOptions.map((e) => ({
      value: e.value,
      label: e.label,
      index: e.index,
      selected: e.selected
    }));
    logger.info(`Option entries: ${entries.length}`);
    logger.info(`Selected entries: ${entries.filter((e) => e.selected).length}`);
    entry.push(...entries);
  }
  return { entry };
}
async function getSelectContent(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.elementHandle();
  return await getSelections(locator);
}
async function getDomProperty(request, state) {
  const content = await getProperty(request, state);
  return stringResponse(JSON.stringify(content), "Property received successfully.");
}
async function getTextContent(locator) {
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const tag = await (await element.getProperty("tagName")).jsonValue();
  if (tag === "INPUT" || tag === "TEXTAREA") {
    return await (await element.getProperty("value")).jsonValue();
  }
  return await element.innerText();
}
async function getText(request, state) {
  const selector = request.selector;
  const strict = request.strict;
  const locator = await findLocator(state, selector, strict, void 0, true);
  let content;
  try {
    content = await getTextContent(locator);
    logger.info(`Retrieved text for element ${selector} containing ${content}`);
  } catch (e) {
    if (e instanceof Error) {
      logger.error(e);
    }
    throw e;
  }
  return stringResponse(content, "Text received successfully.");
}
async function getBoolProperty(request, state) {
  const selector = request.selector;
  const content = await getProperty(request, state);
  return boolResponse(content || false, "Retrieved dom property for element " + selector + " containing " + content);
}
async function getProperty(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = findLocator(state, selector, strictMode, void 0, true);
  try {
    const element = await (await locator).elementHandle();
    const propertyName = request.property;
    const property = await element?.getProperty(propertyName);
    const content = await property?.jsonValue();
    logger.info(`Retrieved dom property for element ${selector} containing ${content}`);
    return content;
  } catch (e) {
    if (e instanceof Error) {
      logger.error(e);
    }
    throw e;
  }
}
async function getElementAttribute(request, state) {
  const content = await getAttributeValue(request, state);
  return stringResponse(JSON.stringify(content), "Property received successfully.");
}
async function getAttributeValue(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const attributeName = request.property;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.elementHandle();
  const attribute = await locator.getAttribute(attributeName);
  logger.info(`Retrieved attribute for element ${selector} containing ${attribute}`);
  return attribute;
}
var stateEnum = {
  attached: 1,
  detached: 2,
  visible: 4,
  hidden: 8,
  enabled: 16,
  disabled: 32,
  editable: 64,
  readonly: 128,
  selected: 256,
  deselected: 512,
  focused: 1024,
  defocused: 2048,
  checked: 4096,
  unchecked: 8192,
  stable: 16384
};
async function getCheckedState(locator) {
  try {
    return await locator.isChecked() ? stateEnum.checked : stateEnum.unchecked;
  } catch {
    return 0;
  }
}
async function getSelectState(element) {
  if (await element.evaluate((e) => "selected" in e)) {
    return await element.evaluate((e) => e.selected) ? stateEnum.selected : stateEnum.deselected;
  } else {
    return 0;
  }
}
async function getElementStates(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  let states;
  try {
    await locator.waitFor({ state: "attached", timeout: 250 });
    states = stateEnum.attached;
    states += await locator.isVisible() ? stateEnum.visible : stateEnum.hidden;
    states += await locator.isEnabled() ? stateEnum.enabled : stateEnum.disabled;
    const disabled = await locator.getAttribute("disabled");
    try {
      const editable = await locator.isEditable();
      if (editable && disabled === null) {
        logger.info(`Element ${selector} is editable: ${editable}`);
        states += stateEnum.editable;
      } else if (!editable && disabled !== null) {
        logger.info(`Element ${selector} is disabled: ${disabled}`);
        states += stateEnum.readonly;
      } else {
        logger.info(`Element ${selector} is readonly: ${!editable}`);
        states += stateEnum.readonly;
      }
    } catch (error) {
      logger.info(`Element ${selector} is not editable: ${String(error)}`);
      if (disabled !== null) {
        logger.info(`Element ${selector} is disabled: ${disabled} and therefore readonly`);
        states += stateEnum.readonly;
      }
    }
    logger.info("Checking checked state");
    states += await getCheckedState(locator);
    try {
      const element = await locator.elementHandle();
      exists(element, "Locator did not resolve to elementHandle.");
      states += await getSelectState(element);
      states += await element.evaluate((e) => document.activeElement === e) ? stateEnum.focused : stateEnum.defocused;
    } catch {
    }
  } catch (e) {
    if (e instanceof import_playwright3.errors.TimeoutError) {
      states = stateEnum.detached;
    } else {
      logger.error(e);
      throw e;
    }
  }
  return jsonResponse(JSON.stringify(states), "Returned state.");
}
async function getStyle(request, state) {
  const selector = request.selector;
  const option = {
    styleKey: request.styleKey || null,
    pseudoElement: request.pseudo || null
  };
  const strictMode = request.strict;
  logger.info("Getting css of element on page");
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const result = await locator.evaluate((element, option2) => {
    const cssStyleDeclaration = window.getComputedStyle(element, option2.pseudoElement);
    if (option2.styleKey) {
      return cssStyleDeclaration.getPropertyValue(option2.styleKey);
    } else {
      return Object.fromEntries(
        Array.from(cssStyleDeclaration).map((key) => [key, cssStyleDeclaration.getPropertyValue(key)])
      );
    }
  }, option);
  return jsonResponse(JSON.stringify(result), "Style get successfully.");
}
async function getViewportSize(page) {
  const result = page.viewportSize();
  return jsonResponse(JSON.stringify(result), "View port size received successfully from page.");
}
async function getBoundingBox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const boundingBox = await locator.boundingBox();
  return jsonResponse(JSON.stringify(boundingBox), "Got bounding box successfully.");
}
async function getPageSource(page) {
  const result = await page.content();
  logger.info(result);
  const body = JSON.stringify(result);
  const responseChunks = [];
  const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
  if (bodyChunks.length > 1) {
    for (let i = 0; i < bodyChunks.length; i++) {
      const chunk = bodyChunks[i];
      const response = jsonResponse("{}", `Page source obtained, chunk ${i}`, chunk);
      responseChunks.push(response);
    }
  } else {
    const response = jsonResponse("{}", "Page source obtained successfully.", body);
    responseChunks.push(response);
  }
  return responseChunks;
}
async function getTableCellIndex(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const count = await element.evaluate((element2) => {
    while (!["TD", "TH"].includes(element2.nodeName)) {
      const parent = element2.parentElement;
      if (!parent) {
        throw Error("Selector does not select a table cell!");
      }
      element2 = parent;
    }
    return Array.prototype.indexOf.call(element2.parentNode?.children, element2);
  });
  return intResponse(count, `Cell index in row is ${count}.`);
}
async function getTableRowIndex(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const element = await locator.elementHandle();
  exists(element, "Locator did not resolve to elementHandle.");
  const count = await element.evaluate((element2) => {
    let table_row = null;
    while (element2.nodeName !== "TABLE") {
      if (element2.nodeName === "TR") {
        table_row = element2;
      }
      const parent = element2.parentElement;
      if (!parent) {
        throw Error("Selector does not select a table cell!");
      }
      element2 = parent;
    }
    let rows = element2.querySelectorAll(":scope > * > tr");
    if (rows.length == 0) {
      rows = element2.querySelectorAll(":scope > tr");
    }
    if (rows.length == 0) {
      throw Error(
        `Table rows could not be found. ChildNodes are: ${Array.prototype.slice.call(element2.childNodes).map((e) => `${String(e.nodeName)}.${String(e.className)}`).join(", ")}`
      );
    }
    return Array.prototype.indexOf.call(rows, table_row);
  });
  return intResponse(count, `Row index in table is ${count}.`);
}

// node/playwright-wrapper/interaction.ts
async function selectOption(request, state) {
  const selector = request.selector;
  const matcher = JSON.parse(request.matcherJson);
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  const result = await locator.selectOption(matcher);
  if (result.length == 0) {
    logger.info("Couldn't select any options");
    throw new Error(`No options matched ${matcher}`);
  }
  return await getSelections(locator);
}
async function deSelectOption(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = findLocator(state, selector, strictMode, void 0, true);
  await (await locator).selectOption([]);
  return emptyWithLog(`Deselected options in element ${selector}`);
}
async function typeText(request, state) {
  const selector = request.selector;
  const text = request.text;
  const delayValue = request.delay;
  const clear = request.clear;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  if (clear) {
    await locator.fill("");
  }
  await locator.type(text, { delay: delayValue });
  return emptyWithLog(`Typed text "${text}" on "${selector}"`);
}
async function fillText(request, state) {
  const selector = request.selector;
  const text = request.text;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.fill(text, { force });
  return emptyWithLog(`Fill text ${text} on ${selector} with force: ${force}`);
}
async function clearText(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.fill("");
  return emptyWithLog(`Text ${selector} field cleared.`);
}
async function press(request, state) {
  const selector = request.selector;
  const keyList = request.key;
  const strictMode = request.strict;
  const pressDelay = request.pressDelay;
  const keyDelay = request.keyDelay;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  for (const i of keyList) {
    await locator.press(i, { delay: pressDelay });
    if (keyDelay > 0) {
      await new Promise((r) => setTimeout(r, keyDelay));
    }
  }
  return emptyWithLog(`Pressed keys: "${keyList.join(", ")}" on ${selector} `);
}
async function click(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const result = await internalClick(selector, strictMode, options, state);
  if (result) {
    return emptyWithLog(`Clicked element: '${selector}' with options: '${options}' successfully.`);
  }
  return emptyWithLog(
    `Clicked element: '${selector}' with options: '${options}' but silenced: "Target closed error".`
  );
}
async function tap(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.tap(JSON.parse(options));
  return emptyWithLog(`Tap element: '${selector}' with options: '${options}'`);
}
async function internalClick(selector, strictMode, options, state) {
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  try {
    await locator.click(JSON.parse(options));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("locator.click: Target page, context or browser has been closed")) {
      logger.warn("Supress locator.click: Target page, context or browser has been closed error");
      return false;
    }
    throw error;
  }
}
async function hover(request, state) {
  const selector = request.selector;
  const options = request.options;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.hover(JSON.parse(options));
  return emptyWithLog(`Hovered element: '${selector}' With options: '${options}'`);
}
async function focus(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.focus();
  return emptyWithLog(`Focused element: ${selector}`);
}
async function checkCheckbox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.waitFor({ state: "attached" });
  await locator.check({ force });
  return emptyWithLog(`Checked checkbox: ${selector} with force: ${force}`);
}
async function uncheckCheckbox(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const force = request.force;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.waitFor({ state: "attached" });
  await locator.uncheck({ force });
  return emptyWithLog(`Unchecked checkbox: ${selector} with force: ${force}`);
}
async function uploadFileBySelector(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const path4 = request.path;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  if (path4.length === 0) {
    const name = request.name;
    const mimeType = request.mimeType;
    const buffer = request.buffer;
    logger.info(`Uploading file ${name} as buffer to ${selector}`);
    await locator.setInputFiles({ name, mimeType, buffer: Buffer.from(buffer) });
    return emptyWithLog("Successfully uploaded buffer as file");
  } else {
    logger.info(`Uploading file(s) ${path4.join(", ")} to ${selector}`);
    await locator.setInputFiles(path4);
    return emptyWithLog("Successfully uploaded file(s)");
  }
}
async function uploadFile(request, page) {
  const path4 = request.path;
  const fileChooser = await page.waitForEvent("filechooser");
  await fileChooser.setFiles(path4);
  return emptyWithLog("Successfully uploaded file");
}
async function handleAlert(request, page) {
  const alertAction = request.alertAction;
  const promptInput = request.promptInput;
  const fn = async (dialog) => {
    const dialogueText = dialog.message();
    if (promptInput) await dialog[alertAction](promptInput);
    else await dialog[alertAction]();
    logger.info(`Alert text: ${dialogueText}`);
  };
  page.on("dialog", fn);
  return emptyWithLog("Set event handler for next alert");
}
async function waitForAlerts(request, page) {
  const alertActions = request.items;
  const alertMessages = [];
  for (let index = 0; index < alertActions.length; index++) {
    const alertAction = alertActions[index];
    const promptInput = alertAction.promptInput;
    const timeout = alertAction.timeout;
    const action = alertAction.alertAction;
    logger.info(`Waiting for alert with action: ${action}, promptInput: "${promptInput}" and timeout: ${timeout}`);
    const dialogObject = await page.waitForEvent("dialog", { timeout });
    alertMessages.push(dialogObject.message());
    if (action === "accept" && promptInput) {
      void dialogObject.accept(promptInput);
    } else if (alertAction.alertAction === "accept") {
      void dialogObject.accept();
    } else {
      void dialogObject.dismiss();
    }
  }
  return { items: alertMessages };
}
async function mouseButton(request, page) {
  const action = request.action;
  const params = JSON.parse(request.json);
  await invokeOnMouse(page, action, params);
  return emptyWithLog(`Successfully executed ${action}`);
}
async function mouseMove(request, page) {
  const params = JSON.parse(request.body);
  await invokeOnMouse(page, "move", params);
  return emptyWithLog(`Successfully moved mouse to ${params.x}, ${params.y}`);
}
async function mouseWheel(request, page) {
  const deltaX = request.deltaX;
  const deltaY = request.deltaY;
  exists(page, `but no open page`);
  await page?.mouse.wheel(deltaX, deltaY);
  return emptyWithLog(`Successfully scrolled mouse wheel with ${deltaX}, ${deltaY}`);
}
async function keyboardKey(request, page) {
  const action = request.action;
  const key = request.key;
  await invokeOnKeyboard(page, action, key);
  return emptyWithLog(`Successfully did ${action} for ${key}`);
}
async function keyboardInput(request, page) {
  const action = request.action;
  const delay = request.delay;
  const input = request.input;
  await invokeOnKeyboard(page, action, input, { delay });
  return emptyWithLog(`Successfully did virtual keyboard action ${action} with input ${input}`);
}
async function scrollToElement(request, state) {
  const selector = request.selector;
  const strictMode = request.strict;
  const locator = await findLocator(state, selector, strictMode, void 0, true);
  await locator.scrollIntoViewIfNeeded();
  return emptyWithLog(`Scrolled to ${selector} field if needed.`);
}

// node/playwright-wrapper/keyword-decorators.ts
function class_async_logger(target) {
  for (const propertyName of Object.keys(target.prototype)) {
    const descriptor = Object.getOwnPropertyDescriptor(target.prototype, propertyName);
    const isMethod = descriptor?.value instanceof Function;
    if (!isMethod || !descriptor) continue;
    const timered_method = async_logger(propertyName, descriptor);
    Object.defineProperty(target.prototype, propertyName, timered_method);
  }
}
function async_logger(propertyKey, propertyDescriptor) {
  const originalMethod = propertyDescriptor.value;
  propertyDescriptor.value = async function(...args2) {
    try {
      logger.info({ event_kind: "grpc", action: propertyKey, status: "started" });
      const result = await originalMethod.apply(this, args2);
      logger.info({ event_kind: "grpc", action: propertyKey, status: "succeeded" });
      return result;
    } catch (err) {
      logger.info({ event_kind: "grpc", action: propertyKey, status: "failed" });
      throw err;
    }
  };
  return propertyDescriptor;
}

// node/playwright-wrapper/playwright-state.ts
var import_fs = __toESM(require("fs"));
var import_module = require("module");
var import_monocart_coverage_reports = require("monocart-coverage-reports");
var path3 = __toESM(require("path"));
var playwright = __toESM(require("playwright"));
var import_playwright4 = require("playwright");
var import_strip_comments = __toESM(require("strip-comments"));
function lastItem(array) {
  return array[array.length - 1];
}
var extractArgumentsStringFromJavascript = (javascript) => {
  const regex = /\((.*?)\)/;
  const match = regex.exec((0, import_strip_comments.default)(javascript).replace(/\r?\n/g, ""));
  if (match) {
    return match[1];
  }
  logger.error(`Could not extract arguments from javascript:
${javascript}
defaulting to *args`);
  return "*args";
};
async function initializeExtension(request, state) {
  logger.info(`Initializing extension: ${request.path}`);
  const extension = require(request.path);
  state.extensions.push(extension);
  const kws = Object.keys(extension).filter((key) => extension[key] instanceof Function && !key.startsWith("__"));
  logger.info(`Adding ${kws.length} keywords from JS Extension`);
  return keywordsResponse(
    kws,
    kws.map((v) => {
      return extractArgumentsStringFromJavascript(extension[v].toString());
    }),
    kws.map((v) => {
      const typedV = extension[v];
      return typedV.rfdoc ?? "TODO: Add rfdoc string to exposed function to create documentation";
    }),
    "ok"
  );
}
var getArgumentNamesFromJavascriptKeyword = (keyword) => extractArgumentsStringFromJavascript(keyword.toString()).split(",").map((s) => s.trim().match(/^\w*/)?.[0] || s.trim());
async function extensionKeywordCall(request, call, state) {
  const keywordName = request.name;
  const args2 = JSON.parse(request.arguments);
  const extension = state.extensions.find((extension2) => Object.keys(extension2).includes(keywordName));
  if (!extension) throw Error(`Could not find keyword ${keywordName}`);
  const keyword = extension[keywordName];
  const namedArguments = Object.fromEntries(args2["arguments"]);
  const apiArguments = /* @__PURE__ */ new Map();
  apiArguments.set("page", state.getActivePage());
  apiArguments.set("context", state.getActiveContext());
  apiArguments.set("browser", state.getActiveBrowser()?.browser);
  apiArguments.set("logger", (msg) => call.write(jsonResponse("", msg)));
  apiArguments.set("playwright", playwright);
  const functionArguments = getArgumentNamesFromJavascriptKeyword(keyword).map(
    (argName) => apiArguments.get(argName) || namedArguments[argName]
  );
  const result = await keyword(...functionArguments);
  if (result === void 0) {
    return [jsonResponse("", "ok")];
  }
  const body = JSON.stringify(result);
  const bodyChunks = splitUtf8ByMaxBytes(body, MAX_RESPONSE_CHUNK_BYTES);
  if (bodyChunks.length === 0) {
    return [jsonResponse("", "ok")];
  }
  return bodyChunks.map(
    (chunk, index) => jsonResponse("", index === bodyChunks.length - 1 ? "ok" : `ok chunk ${index}`, chunk)
  );
}
async function _newBrowser(browserType, headless, timeout, options) {
  const browser = await _getBrowserType(browserType).launch({ ...options, headless, timeout });
  return {
    browser,
    browserType,
    headless
  };
}
function _getBrowserType(browserType) {
  let browserTyp;
  switch (browserType) {
    case "chromium":
      browserTyp = import_playwright4.chromium;
      break;
    case "firefox":
      browserTyp = import_playwright4.firefox;
      break;
    case "webkit":
      browserTyp = import_playwright4.webkit;
      break;
    default:
      throw new Error(`"${browserType} is an unsupported browser."`);
  }
  return browserTyp;
}
async function _launchBrowserServer(browserType, headless, timeout, options) {
  let browser;
  const launchOptions = { ...options, headless, timeout };
  if (browserType === "firefox") {
    browser = await import_playwright4.firefox.launchServer(launchOptions);
  } else if (browserType === "chromium") {
    browser = await import_playwright4.chromium.launchServer(launchOptions);
  } else if (browserType === "webkit") {
    browser = await import_playwright4.webkit.launchServer(launchOptions);
  } else {
    throw new Error("unsupported browser");
  }
  return browser;
}
async function _connectBrowser(browserName, url, connectCDP, timeout) {
  logger.info(`Connecting to browser: ${browserName} at ${url} via ${connectCDP ? "CDP" : "WebSocket"}`);
  const browserType = _getBrowserType(browserName);
  timeout = timeout || 3e4;
  const browser = connectCDP ? await browserType.connectOverCDP(url, { timeout }) : await browserType.connect(url, { timeout });
  return {
    browser,
    browserType: browserName,
    headless: false
  };
}
async function _createIndexedContext(context, defaultTimeout, traceFile, options) {
  const contextId = `context=${v4_default()}`;
  if (defaultTimeout) {
    logger.info(`Setting default timeout for context ${contextId} to ${defaultTimeout}`);
    context.setDefaultTimeout(defaultTimeout);
  }
  if (traceFile) {
    if (!traceFile.toLowerCase().endsWith(".zip")) {
      traceFile = path3.join(traceFile, `trace_${contextId}.zip`);
    }
    traceFile = traceFile.replace("{contextid}", contextId);
  }
  const indexedContext = {
    id: contextId,
    c: context,
    pageStack: [],
    options,
    traceFile
  };
  if (traceFile) {
    logger.info("Tracing enabled with: { screenshots: true, snapshots: true }");
    await context.tracing.start({ screenshots: true, snapshots: true });
  }
  indexedContext.c.on("page", async (page) => {
    indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
  });
  return indexedContext;
}
function indexedPage(newPage2) {
  const timestamp = (/* @__PURE__ */ new Date()).getTime() / 1e3;
  const pageErrors = [];
  const consoleMessages = [];
  newPage2.on("pageerror", (error) => {
    logger.warn(
      { event_kind: "internal_error", status: "failed", error_type: error.name },
      error.stack ?? error.message
    );
    const timedError = {
      name: error.name,
      message: error.message,
      stack: error.stack,
      time: /* @__PURE__ */ new Date()
    };
    pageErrors.push(timedError);
  });
  newPage2.on("console", (message) => {
    const timedMessage = {
      type: message.type(),
      text: message.text(),
      location: message.location(),
      time: /* @__PURE__ */ new Date()
    };
    consoleMessages.push(timedMessage);
  });
  return {
    id: `page=${v4_default()}`,
    p: newPage2,
    timestamp,
    pageErrors,
    errorIndex: 0,
    consoleMessages,
    consoleIndex: 0,
    activeDownloads: /* @__PURE__ */ new Map(),
    coverage: void 0
  };
}
async function _newPage(context, page = void 0) {
  const newPage2 = page === void 0 ? await context.c.newPage() : page;
  const contextPage = indexedPage(newPage2);
  newPage2.on("close", () => {
    const oldPageStackLength = context.pageStack.length;
    const filteredPageStack = context.pageStack.filter((page2) => page2.p != contextPage.p);
    if (oldPageStackLength != filteredPageStack.length) {
      context.pageStack = filteredPageStack;
      logger.info("Removed " + contextPage.id + " from " + context.id + " page stack");
    }
  });
  return contextPage;
}
var PlaywrightState = class {
  constructor() {
    this.browserStack = [];
    this.extensions = [];
    this.browserServer = [];
  }
  extensions;
  browserStack;
  browserServer;
  get activeBrowser() {
    return lastItem(this.browserStack);
  }
  getActiveBrowser = () => {
    const currentBrowser = this.activeBrowser;
    if (currentBrowser === void 0) {
      throw new Error("Browser has been closed.");
    }
    return currentBrowser;
  };
  switchTo = (id) => {
    const browser = this.browserStack.find((b) => b.id === id);
    this.browserStack = this.browserStack.filter((b) => b.id !== id);
    exists(browser, `No browser for id '${id}'`);
    this.browserStack.push(browser);
    return this.getActiveBrowser();
  };
  async getOrCreateActiveBrowser(browserType, timeout) {
    const currentBrowser = this.activeBrowser;
    if (currentBrowser === void 0) {
      logger.info("No active browser, creating a new one");
      const browserAndConfs = await _newBrowser(browserType || "chromium", true, timeout);
      const newState = new BrowserState(browserAndConfs);
      this.browserStack.push(newState);
      return { browser: newState, newBrowser: true };
    } else {
      logger.info(`currentBrowser: ${JSON.stringify(currentBrowser)}`);
      return { browser: currentBrowser, newBrowser: false };
    }
  }
  async closeAll() {
    const browsers = this.browserStack;
    for (const browser of browsers) {
      try {
        await browser.close();
      } catch (e) {
      }
    }
    this.browserStack = [];
  }
  async closeAllServers() {
    const servers = this.browserServer;
    for (const server2 of servers) {
      try {
        await server2.close();
      } catch (e) {
      }
    }
    this.browserServer = [];
  }
  getBrowserServer(wsEndpoint) {
    return this.browserServer.find((server2) => server2.wsEndpoint() === wsEndpoint);
  }
  async closeServer(selectedServer) {
    if (!this.browserServer.includes(selectedServer)) {
      throw new Error(`BrowserServer not found.`);
    }
    this.browserServer.splice(this.browserServer.indexOf(selectedServer), 1);
    await selectedServer.close();
  }
  async getCatalog(includePageDetails = true) {
    const pageToContents = async (page) => {
      let title = null;
      let url = "";
      if (includePageDetails) {
        url = page.p.url();
        const titlePromise = page.p.title();
        const titleTimeout = new Promise((_r, rej) => setTimeout(() => rej(new Error("title timeout")), 350));
        try {
          title = await Promise.race([titlePromise, titleTimeout]);
        } catch (e) {
        }
      }
      return {
        type: "page",
        title: title || "",
        url,
        id: page.id,
        timestamp: page.timestamp
      };
    };
    const contextToContents = async (context) => {
      const activePage = lastItem(context.pageStack)?.id;
      return {
        type: "context",
        id: context?.id,
        activePage,
        pages: await Promise.all(context.pageStack.map(pageToContents))
      };
    };
    return Promise.all(
      this.browserStack.map(async (browser) => {
        return {
          type: browser.name,
          id: browser.id,
          contexts: await Promise.all(browser.contextStack.map(contextToContents)),
          activeContext: browser.context?.id,
          activeBrowser: this.activeBrowser === browser
        };
      })
    );
  }
  addBrowser(browserAndConfs) {
    const adding_browser = browserAndConfs.browser;
    logger.info(`Adding browser to stack: ${browserAndConfs.browserType}, version: ${adding_browser?.version()}`);
    let browserState = this.browserStack.find((b) => b.browser === adding_browser);
    if (browserState !== void 0) {
      this.browserStack = this.browserStack.filter((b) => b.browser !== adding_browser);
    } else {
      browserState = new BrowserState(browserAndConfs);
    }
    const browserContexts = browserState.browser?.contexts();
    if (browserContexts !== void 0) {
      logger.info(`Adding ${browserContexts.length} contexts to browser`);
      for (const context of browserContexts) {
        const indexedPages = context.pages().map((page) => indexedPage(page));
        logger.info(`Adding ${indexedPages.length} pages to context`);
        const indexedContext = {
          id: `context=${v4_default()}`,
          c: context,
          pageStack: indexedPages,
          options: {},
          traceFile: ""
        };
        indexedContext.c.on("page", async (page) => {
          indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
        });
        browserState?.pushContext(indexedContext);
      }
    }
    this.browserStack.push(browserState);
    return browserState;
  }
  addBrowserServer = (browserServer) => {
    this.browserServer.push(browserServer);
  };
  popBrowser = () => {
    return this.browserStack.pop();
  };
  getActiveContext = () => {
    return this.activeBrowser?.context?.c;
  };
  getTraceFile = () => {
    return this.activeBrowser?.context?.traceFile;
  };
  getActivePage = () => {
    return this.activeBrowser?.page?.p;
  };
  getActivePageId = () => {
    return this.activeBrowser?.page?.id;
  };
  getCoverageOptions = () => {
    return this.activeBrowser?.page?.coverage;
  };
  addCoverageOptions = (coverage) => {
    if (this.activeBrowser?.page) {
      this.activeBrowser.page.coverage = coverage;
    }
  };
};
var LocatorCache = class {
  cache;
  constructor() {
    this.cache = /* @__PURE__ */ new Map();
  }
  add(key, locator) {
    this.cache.set(key, locator);
  }
  get(key) {
    return this.cache.get(key);
  }
  delete(key) {
    return this.cache.delete(key);
  }
  has(key) {
    return this.cache.has(key);
  }
  clear() {
    this.cache.clear();
  }
};
var locatorCache = new LocatorCache();
var BrowserState = class {
  constructor(browserAndConfs) {
    this.name = browserAndConfs.browserType;
    this.browser = browserAndConfs.browser;
    this.headless = browserAndConfs.headless;
    this._contextStack = [];
    this.id = `browser=${v4_default()}`;
  }
  _contextStack;
  browser;
  name;
  id;
  headless;
  async close() {
    for (const context of this.contextStack) {
      const traceFile = context.traceFile;
      if (traceFile) {
        await context.c.tracing.stop({ path: traceFile });
      }
      await context.c.close();
    }
    this._contextStack = [];
    if (this.browser === null) {
      return;
    }
    await this.browser.close();
  }
  async getOrCreateActiveContext(defaultTimeout) {
    if (this.context) {
      return { context: this.context, newContext: false };
    } else if (this.browser === null) {
      throw new Error("Invalid persistent context browser without context");
    } else {
      const context = await _createIndexedContext(await this.browser.newContext(), defaultTimeout, "");
      this.pushContext(context);
      return { context, newContext: true };
    }
  }
  get context() {
    return lastItem(this._contextStack);
  }
  pushContext(newContext2) {
    if (newContext2 !== void 0) {
      if (newContext2.options === void 0) {
        newContext2.options = this._contextStack.find((c) => c.c === newContext2.c)?.options;
      }
      this._contextStack = this._contextStack.filter((c) => c.c !== newContext2.c);
      if (!newContext2.c) {
        throw new Error("Tried to switch to context, which did not exist anymore.");
      }
      this._contextStack.push(newContext2);
      logger.info(`Changed active context: ${newContext2.id}`);
    } else logger.info("Set active context to undefined");
  }
  unshiftContext(newContext2) {
    this._contextStack.unshift(newContext2);
  }
  get page() {
    const context = this.context;
    if (context) return lastItem(context.pageStack);
    else return void 0;
  }
  async activatePage(page) {
    this.pushPage(page);
    await page.p.bringToFront();
  }
  pushPage(newPage2) {
    const currentContext = this.context;
    if (newPage2 !== void 0 && currentContext !== void 0) {
      currentContext.pageStack = currentContext.pageStack.filter((p) => p.p !== newPage2.p);
      if (!newPage2.p) {
        throw new Error("Tried to switch to page, which did not exist anymore.");
      }
      currentContext.pageStack.push(newPage2);
      logger.info("Changed active page");
    } else {
      logger.info("Set active page to undefined");
    }
  }
  get contextStack() {
    return this._contextStack;
  }
  popPage() {
    const pageStack = this.context?.pageStack || [];
    return pageStack.pop();
  }
  popContext() {
    this._contextStack.pop();
  }
};
async function closeBrowserServer(request, openBrowsers) {
  const wsEndpoint = request.url;
  if (wsEndpoint === "ALL") {
    await openBrowsers.closeAllServers();
    return emptyWithLog("Closed all browser servers");
  }
  const browserServer = openBrowsers.getBrowserServer(wsEndpoint);
  if (!browserServer) throw new Error(`BrowserServer with endpoint ${wsEndpoint} not found.`);
  await openBrowsers.closeServer(browserServer);
  return emptyWithLog(`Closed browser server with endpoint: ${wsEndpoint}`);
}
async function closeBrowser(openBrowsers) {
  const currentBrowser = openBrowsers.activeBrowser;
  if (currentBrowser === void 0) {
    return stringResponse("no-browser", "No browser open, doing nothing");
  }
  openBrowsers.popBrowser();
  try {
    await currentBrowser.close();
    return stringResponse(currentBrowser.id, "Closed browser");
  } catch {
    return stringResponse("", `Browser ${currentBrowser.id} was already closed`);
  }
}
async function closeAllBrowsers(openBrowsers) {
  await openBrowsers.closeAll();
  return emptyWithLog("Closed all browsers");
}
async function closeContext(request, openBrowsers) {
  const saveTrace = request.value;
  const activeBrowser = openBrowsers.getActiveBrowser();
  const traceFile = openBrowsers.getTraceFile();
  if (traceFile && saveTrace) {
    await openBrowsers.getActiveContext()?.tracing.stop({ path: traceFile });
  }
  for (const page of activeBrowser.context?.pageStack || []) {
    await _saveCoverageReport(page);
  }
  await openBrowsers.getActiveContext()?.close();
  activeBrowser.popContext();
  if (activeBrowser.contextStack.length === 0 && activeBrowser.browser === null) {
    void closeBrowser(openBrowsers);
  }
  return emptyWithLog("Successfully closed Context");
}
async function closePage(request, openBrowsers) {
  const activeBrowser = openBrowsers.getActiveBrowser();
  const closedPage = activeBrowser.popPage();
  if (closedPage) {
    await _saveCoverageReport(closedPage);
  }
  const unload = request.runBeforeUnload;
  if (!closedPage) throw new Error("No open page");
  logger.info(`Closing page with runBeforeUnload ${unload}`);
  await closedPage.p.close({ runBeforeUnload: unload });
  return pageReportResponse(`Successfully closed Page with runBeforeUnload ${unload}`, closedPage);
}
async function newPage(request, openBrowsers) {
  const defaultTimeout = request.url?.defaultTimeout;
  const waitUntil = request.waitUntil;
  const browserState = await openBrowsers.getOrCreateActiveBrowser(null, defaultTimeout);
  const newBrowser2 = browserState.newBrowser;
  const context = await browserState.browser.getOrCreateActiveContext(defaultTimeout);
  const page = await _newPage(context.context);
  let videoPath = "";
  try {
    videoPath = await page.p.video()?.path();
  } catch {
    logger.info("Suppress video().path() error");
  }
  logger.info("Video path: " + videoPath);
  browserState.browser.pushPage(page);
  const url = request.url?.url || "about:blank";
  try {
    const goToOptions = { timeout: defaultTimeout };
    if (waitUntil) {
      goToOptions.waitUntil = waitUntil;
    }
    await page.p.goto(url, goToOptions);
    const video = { video_path: videoPath || null, contextUuid: context.context.id };
    return {
      body: page.id,
      log: `Successfully initialized new page object and opened url: ${url}`,
      video: JSON.stringify(video),
      newBrowser: newBrowser2,
      newContext: context.newContext
    };
  } catch (e) {
    void browserState.browser.popPage()?.p.close();
    throw e;
  }
}
async function newContext(request, openBrowsers) {
  const options = JSON.parse(request.rawOptions);
  logger.info("Creating new context with options: " + JSON.stringify(options));
  const defaultTimeout = request.defaultTimeout;
  const browserState = await openBrowsers.getOrCreateActiveBrowser(options.defaultBrowserType, defaultTimeout);
  const traceFile = request.traceFile;
  logger.info(`Trace file: ${traceFile}`);
  if (browserState.browser.browser === null) {
    throw new Error("Trying to create a new context when a persistentContext is active");
  }
  const indexedContext = await _createIndexedContext(
    await browserState.browser.browser.newContext(options),
    defaultTimeout,
    traceFile,
    options
  );
  return await _finishContextResponse(indexedContext, browserState, options);
}
async function _finishContextResponse(indexedContext, browserState, options) {
  browserState.browser.pushContext(indexedContext);
  const log = indexedContext.traceFile ? `Successfully created context and trace file will be saved to: ${indexedContext.traceFile}` : "Successfully created context. ";
  if (indexedContext.traceFile) {
    options.trace = { screenshots: true, snapshots: true };
  }
  return {
    id: indexedContext.id,
    log,
    contextOptions: JSON.stringify(options),
    newBrowser: browserState.newBrowser
  };
}
async function newBrowser(request, openBrowsers) {
  const browserType = request.browser;
  const options = JSON.parse(request.rawOptions);
  const browserAndConfs = await _newBrowser(
    browserType,
    options["headless"],
    options["timeout"],
    options
  );
  const browserState = openBrowsers.addBrowser(browserAndConfs);
  return stringResponse(browserState.id, "Successfully created browser with options: " + JSON.stringify(options));
}
async function launchBrowserServer(request, openBrowsers) {
  const browserType = request.browser;
  const options = JSON.parse(request.rawOptions);
  logger.info(`Launching browser server: ${browserType}`);
  logger.info("Launching browser server with options: " + JSON.stringify(options));
  const browserServer = await _launchBrowserServer(
    browserType,
    options["headless"],
    options["timeout"],
    options
  );
  logger.info(`Browser server launched. Endpoint: ${browserServer.wsEndpoint()}`);
  openBrowsers.addBrowserServer(browserServer);
  return stringResponse(
    browserServer.wsEndpoint(),
    "Successfully created browser server with options: " + JSON.stringify(options)
  );
}
async function newPersistentContext(request, openBrowsers) {
  const traceFile = request.traceFile;
  const timeout = request.defaultTimeout;
  const options = JSON.parse(request.rawOptions);
  const userDataDir = options?.userDataDir;
  const browserName = options.defaultBrowserType || options.browser || "chromium";
  const context = await _getBrowserType(browserName).launchPersistentContext(userDataDir, options);
  const browserAndConfs = {
    browserType: browserName,
    browser: null,
    headless: options?.headless || true
  };
  openBrowsers.addBrowser(browserAndConfs);
  const browserState = await openBrowsers.getOrCreateActiveBrowser(null, timeout);
  if (browserState.newBrowser === true) {
    throw new Error("A new browser was created in error while trying to create a persistent context");
  }
  const indexedContext = await _createIndexedContext(context, timeout, traceFile, options);
  const page = indexedContext.c.pages()[0];
  indexedContext.pageStack.unshift(await _newPage(indexedContext, page));
  const baseResponse = await _finishContextResponse(indexedContext, browserState, options);
  const currentBrowser = openBrowsers.activeBrowser;
  const currentPage = indexedContext.pageStack[0];
  const videoPath = await currentPage.p.video()?.path();
  const video = { video_path: videoPath || null, contextUuid: indexedContext.id };
  return {
    ...baseResponse,
    video: JSON.stringify(video),
    pageId: currentPage.id,
    browserId: currentBrowser?.id || ""
  };
}
async function connectToBrowser(request, openBrowsers) {
  const browserType = request.browser;
  const url = request.url;
  const connectCDP = request.connectCDP;
  const timeout = request.timeout;
  const browserAndConfs = await _connectBrowser(browserType, url, connectCDP, timeout);
  const browserState = openBrowsers.addBrowser(browserAndConfs);
  return stringResponse(browserState.id, "Successfully connected to browser");
}
async function openTraceGroup(request, openBrowsers) {
  const name = request.name;
  const file = request.file;
  const line = request.line;
  const column = request.column;
  const contextId = request.contextId;
  if (openBrowsers?.browserStack) {
    for (const browserState of openBrowsers.browserStack) {
      for (const indexedContext of browserState.contextStack) {
        if (!contextId || indexedContext.id === contextId) {
          await indexedContext.c?.tracing?.group(name, { location: { file, line, column } });
        }
      }
    }
  }
  setRFKeywordContext({ kw_name: name, kw_file: file || void 0, kw_line: line || void 0 });
  return emptyWithLog("Opened trace group");
}
async function closeTraceGroup(openBrowsers) {
  if (openBrowsers?.browserStack) {
    for (const browserState of openBrowsers.browserStack) {
      for (const indexedContext of browserState.contextStack) {
        await indexedContext.c?.tracing?.groupEnd();
      }
    }
  }
  clearRFKeywordContext();
  return emptyWithLog("Closed trace group");
}
async function setRFContext(request) {
  setRFTestContext(request.testId, request.testName);
  setRFSuiteContext(request.suiteId, request.suiteName);
  return emptyWithLog("RF context updated");
}
async function _switchPage(id, browserState) {
  const context = browserState.context?.c;
  if (!context) throw new Error("Tried to switch page, no open context");
  const pages = browserState.context?.pageStack;
  logger.info("Changing current active page: " + id);
  const page = pages?.find((elem) => elem.id == id);
  if (page) {
    await browserState.activatePage(page);
    return;
  } else {
    const mapped = pages?.map((page2) => `{ id: ${page2.id}, url: ${page2.p.url()} }`).join(",");
    const message = `No page for id ${id}. Open pages: ${mapped}`;
    const error = new Error(message);
    throw error;
  }
}
async function _switchContext(id, browserState) {
  const contexts = browserState.contextStack;
  const context = contexts.find((context2) => context2.id === id);
  if (contexts && context) {
    browserState.pushContext(context);
    return;
  } else {
    const mapped = contexts.map((context2) => context2.id);
    const message = `No context for id ${id}. Open contexts: ${mapped.join(", ")}`;
    throw new Error(message);
  }
}
async function switchPage(request, browserState) {
  exists(browserState, "Tried to switch Page but browser wasn't open");
  const context = browserState.context;
  exists(context, "Tried to switch Page but no context was open");
  const id = request.id;
  if (id === "CURRENT") {
    const previous2 = browserState.page?.id || "NO PAGE OPEN";
    void browserState.page?.p.bringToFront();
    return stringResponse(previous2, "Returned active page id");
  }
  if (id === "NEW") {
    const previous2 = browserState.page?.id || "NO PAGE OPEN";
    const previousTime = browserState.page?.timestamp || 0;
    const latest = await findLatestPageAfter(previousTime, request.timeout, context);
    exists(latest, "Tried to activate a new page but no new pages were detected in context.");
    await browserState.activatePage(latest);
    return stringResponse(previous2, `Activated new page ${latest.id}`);
  }
  const previous = browserState.page?.id || "";
  await _switchPage(id, browserState);
  return stringResponse(previous, "Successfully changed active page: " + id);
}
async function findLatestPageAfter(timestamp, timeout, context) {
  if (timeout < 0) {
    return null;
  }
  const latest = context.pageStack.reduce((acc, val) => {
    if (acc === void 0 || acc.timestamp < val.timestamp) {
      return val;
    }
    return acc;
  });
  if (!latest || timestamp && latest.timestamp <= timestamp) {
    await new Promise((resolve2) => setTimeout(resolve2, Math.min(15, timeout)));
    return findLatestPageAfter(timestamp, timeout - 15, context);
  }
  return latest;
}
async function switchContext(request, browserState) {
  const id = request.index;
  const previous = browserState.context?.id || "";
  if (id === "CURRENT") {
    if (!previous) {
      return stringResponse("NO CONTEXT OPEN", "Returned info that no contexts are open");
    }
  } else {
    await _switchContext(id, browserState);
  }
  const page = browserState.page;
  if (page !== void 0) {
    await _switchPage(page.id, browserState);
  }
  return stringResponse(
    previous,
    id === "CURRENT" ? "Returned active context id: " + id : "Successfully changed active context: " + id
  );
}
async function switchBrowser(request, openBrowsers) {
  const id = request.index;
  const previous = openBrowsers.activeBrowser;
  if (id !== "CURRENT") {
    openBrowsers.switchTo(id);
  }
  void openBrowsers.getActivePage()?.bringToFront();
  return stringResponse(
    previous?.id || "NO BROWSER OPEN",
    id === "CURRENT" ? "Returned active browser id. " + id : "Successfully changed active browser: " + id
  );
}
async function getBrowserCatalog(request, openBrowsers) {
  const includePageDetails = request.value ?? true;
  return jsonResponse(JSON.stringify(await openBrowsers.getCatalog(includePageDetails)), "Catalog received");
}
async function getConsoleLog(request, openBrowsers) {
  const activePage = openBrowsers.getActiveBrowser().page;
  if (!activePage) throw new Error("No open page");
  return getConsoleLogResponse(activePage, request.value, "Console log received");
}
async function getErrorMessages(request, openBrowsers) {
  const activePage = openBrowsers.getActiveBrowser().page;
  if (!activePage) throw new Error("No open page");
  return getErrorMessagesResponse(activePage, request.value, "Error messages received");
}
async function saveStorageState(request, browserState) {
  exists(browserState, "Tried to save storage state but browser wasn't open");
  const context = browserState.context;
  exists(context, "Tried to save storage state butno context was open");
  const stateFile = request.path;
  await context.c.storageState({ path: stateFile });
  return emptyWithLog("Current context state is saved to: " + stateFile);
}
async function startCoverage(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const coverageOptions = {
    type: request.coverageType,
    directory: request.coverageDir,
    configFile: request.configFile,
    raw: request.raw
  };
  state.addCoverageOptions(coverageOptions);
  const resetOnNavigation = request.resetOnNavigation;
  const reportAnonymousScripts = request.reportAnonymousScripts;
  if (["js", "all"].includes(coverageOptions.type)) {
    logger.info(
      `Starting JS coverage with resetOnNavigation: ${resetOnNavigation} and reportAnonymousScripts: ${reportAnonymousScripts}`
    );
    await activePage.coverage.startJSCoverage({ reportAnonymousScripts, resetOnNavigation });
  }
  if (["css", "all"].includes(coverageOptions.type)) {
    logger.info(`Starting CSS coverage with resetOnNavigation: ${resetOnNavigation}`);
    await activePage.coverage.startCSSCoverage({ resetOnNavigation });
  }
  return emptyWithLog(`Coverage started for ${coverageOptions.type}`);
}
async function stopCoverage(request, state) {
  const activeIndexedPage = state.activeBrowser?.page;
  exists(activeIndexedPage, "Could not find active page");
  return _saveCoverageReport(activeIndexedPage);
}
async function _saveCoverageReport(activeIndexedPage) {
  const { coverage: coverageOptions, p: activePage, id: pageId } = activeIndexedPage;
  activeIndexedPage.coverage = void 0;
  if (!coverageOptions) {
    return stringResponse("", "Coverage not started");
  }
  const { directory: coverageDir = "", configFile = "", type: coverageType, raw = false } = coverageOptions;
  const allCoverage = [];
  if (["js", "all"].includes(coverageType)) {
    logger.info("Stopping JS coverage");
    allCoverage.push(...await activePage.coverage.stopJSCoverage());
  }
  if (["css", "all"].includes(coverageType)) {
    logger.info("Stopping CSS coverage");
    allCoverage.push(...await activePage.coverage.stopCSSCoverage());
  }
  const outputDir = path3.normalize(path3.join(coverageDir, pageId));
  const options = { outputDir };
  if (raw && configFile === "") {
    logger.info("Raw and v8 coverage enabled");
    options.reports = [["raw"], ["v8"]];
  } else {
    logger.info("v8 coverage disabled");
  }
  let mergedOptions;
  if (import_fs.default.existsSync(configFile)) {
    logger.info({ "Config file exists: ": configFile });
    const configFileModule = require(configFile);
    mergedOptions = { ...configFileModule, ...options };
    console.log({ "Merged options: ": mergedOptions });
  } else {
    console.log({ "No config file found": configFile });
    mergedOptions = { ...options };
  }
  const mcr = new import_monocart_coverage_reports.CoverageReport(mergedOptions);
  await mcr.add(allCoverage);
  await mcr.generate();
  let message = "Coverage stopped and report generated";
  if (!import_fs.default.existsSync(configFile)) {
    message += `. But no config file found at ${configFile}`;
  }
  return stringResponse(outputDir, message);
}
async function mergeCoverage(request, state) {
  state.getActivePage();
  const inputFolder = request.inputFolder;
  const outputFolder = request.outputFolder;
  const configFile = request.config;
  const name = request.name;
  const reports = request.reports;
  if (!inputFolder) {
    throw Error("No input folders specified");
  }
  if (!outputFolder) {
    throw Error("No output folder specified");
  }
  const options = {
    name,
    inputDir: inputFolder,
    outputDir: outputFolder
  };
  logger.info(`Reports to generate: ${reports.join(", ")}`);
  if (reports && reports.length > 0) {
    options.reports = reports.map((r) => [r]);
  }
  const defaultName = "Browser library Merged Coverage Report";
  let mergedOptions;
  if (import_fs.default.existsSync(configFile)) {
    logger.info(`Config file exists:  ${configFile}`);
    const configFileModule = (0, import_module.createRequire)(__filename)(configFile);
    logger.info(`configFileModule options: ${JSON.stringify(configFileModule)}`);
    mergedOptions = { ...configFileModule, ...options };
    if (reports && reports.length === 1 && reports[0] === "v8") {
      mergedOptions.reports = [["v8"], configFileModule.reports || []].flat();
    }
    if (mergedOptions.name === "" && configFileModule.name) {
      mergedOptions.name = configFileModule.name;
    } else {
      mergedOptions.name = defaultName;
    }
    logger.info(`Merged options: ${JSON.stringify(mergedOptions)}`);
  } else {
    logger.info(`No config file found: ${configFile}`);
    mergedOptions = { ...options };
    if (mergedOptions.name === "") {
      mergedOptions.name = defaultName;
    }
  }
  logger.info(`Final options: ${JSON.stringify(mergedOptions)}`);
  logger.info(`Merging coverage from ${inputFolder} into ${outputFolder}`);
  await new import_monocart_coverage_reports.CoverageReport(mergedOptions).generate();
  return emptyWithLog(`Coverage merged from ${inputFolder} into ${outputFolder}`);
}

// node/playwright-wrapper/locator-handler.ts
async function addLocatorHandlerCustom(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const overlaySelector = request.selector;
  const timesString = request.times;
  let times;
  if (timesString === "None") {
    times = void 0;
  } else {
    times = parseInt(timesString);
  }
  logger.info(`Adding locator handler for ${overlaySelector} as times: ${times}`);
  const noWaitAfter = request.noWaitAfter;
  const handlerSpecs = request.handlerSpecs;
  const overlayLocator = await findLocator(state, overlaySelector, false, void 0, true);
  locatorCache.add(`${state.getActivePageId()}-${overlaySelector}`, overlayLocator);
  await activePage.addLocatorHandler(
    overlayLocator,
    async () => {
      logger.info(`Overlay locator ${overlaySelector} is found`);
      for (const handlerSpec of handlerSpecs) {
        const action = handlerSpec.action;
        const actionSelector = handlerSpec.selector;
        const actionLocator = await findLocator(state, actionSelector, false, void 0, true);
        const options = JSON.parse(handlerSpec.optionsAsJson);
        try {
          if (action === "click") {
            logger.info(
              `Overlay click on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.click({ ...options });
          } else if (action === "fill") {
            const value = handlerSpec.value;
            logger.info(
              `Overlay fill on element ${actionSelector} with value ${value} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.fill(value, { ...options });
          } else if (action === "check") {
            logger.info(
              `Overlay check on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.check({ ...options });
          } else if (action === "uncheck") {
            logger.info(
              `Overlay uncheck on element ${actionSelector} with options: ${JSON.stringify(options)}`
            );
            await actionLocator.uncheck({ ...options });
          }
        } catch (error) {
          logger.error(
            { event_kind: "internal_error", status: "failed", error_type: errorType(error) },
            `Error in custom locator handler: ${String(error)}`
          );
        }
      }
    },
    { times, noWaitAfter }
  );
  return emptyWithLog(`Custom locator handler added for element ${overlaySelector}`);
}
async function removeLocatorHandler(request, state) {
  logger.info(`Removing locator handler for ${request.selector}`);
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const activePageId = state.getActivePageId();
  const overlaySelector = request.selector;
  const locator = locatorCache.get(`${activePageId}-${overlaySelector}`);
  locatorCache.delete(`${activePageId}-${overlaySelector}`);
  if (locator === void 0) {
    return emptyWithLog(`No locator handler found for ${overlaySelector}`);
  }
  await activePage.removeLocatorHandler(locator);
  return emptyWithLog(`Removed locator handler ${overlaySelector}`);
}

// node/playwright-wrapper/pdf.ts
async function savePageAsPdf(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const pdfPath = request.path;
  const displayheaderfooter = request.displayHeaderFooter;
  const footertemplate = request.footerTemplate;
  const format = request.format;
  const headerTemplate = request.headerTemplate;
  const height = request.height;
  const landscape = request.landscape;
  const marginString = request.margin;
  const marging = JSON.parse(marginString);
  const outline = request.outline;
  const pageRanges = request.pageRanges;
  const preferCSSPageSize = request.preferCSSPageSize;
  const printBackground = request.printBackground;
  const scale = request.scale;
  const tagged = request.tagged;
  const width = request.width;
  logger.info(`Saving pdf to ${pdfPath}`);
  const message = `Using options: displayHeaderFooter: ${displayheaderfooter}, footerTemplate: ${footertemplate}, format: ${format}, headerTemplate: ${headerTemplate}, height: ${height}, landscape: ${landscape}, margin (as string): ${marginString}, outline: ${outline}, pageRanges: ${pageRanges}, preferCSSPageSize: ${preferCSSPageSize}, printBackground: ${printBackground}, scale: ${scale}, tagged: ${tagged}  and width: ${width}`;
  logger.info(message);
  await activePage.pdf({
    path: pdfPath,
    displayHeaderFooter: displayheaderfooter,
    footerTemplate: footertemplate,
    format,
    headerTemplate,
    height,
    landscape,
    margin: marging,
    outline,
    pageRanges,
    preferCSSPageSize,
    printBackground,
    scale,
    tagged,
    width
  });
  return stringResponse(pdfPath, `Pdf is saved to ${pdfPath}`);
}
async function emulateMedia(request, state) {
  const activePage = state.getActivePage();
  exists(activePage, "Could not find active page");
  const options = {};
  const colorScheme = request.colorScheme;
  if (colorScheme === "not_set") {
    logger.info(`Emulating colorScheme not set`);
  } else if (colorScheme === "null") {
    logger.info(`Emulating colorScheme null`);
    options.colorScheme = null;
  } else {
    logger.info(`Emulating colorScheme ${colorScheme}`);
    options.colorScheme = colorScheme;
  }
  const forcedColors = request.forcedColors;
  if (forcedColors === "not_set") {
    logger.info(`Emulating forcedColors not set`);
  } else if (forcedColors === "null") {
    logger.info(`Emulating forcedColors null`);
    options.forcedColors = null;
  } else {
    logger.info(`Emulating forcedColors ${forcedColors}`);
    options.forcedColors = forcedColors;
  }
  const media = request.media;
  if (media === "not_set") {
    logger.info(`Emulating media not set`);
  } else if (media === "null") {
    logger.info(`Emulating media null`);
    options.media = null;
  } else {
    logger.info(`Emulating media ${media}`);
    options.media = media;
  }
  const reducedMotion = request.reducedMotion;
  if (reducedMotion === "not_set") {
    logger.info(`Emulating reducedMotion not set`);
  } else if (reducedMotion === "null") {
    logger.info(`Emulating reducedMotion null`);
    options.reducedMotion = null;
  } else {
    logger.info(`Emulating reducedMotion ${reducedMotion}`);
    options.reducedMotion = reducedMotion;
  }
  await activePage.emulateMedia(options);
  return stringResponse(JSON.stringify(options), `Emulating media ${JSON.stringify(options)}`);
}

// node/playwright-wrapper/grpc-service.ts
var PlaywrightServer = class {
  states = {};
  peerMap = {};
  createState = (key) => {
    if (!(key in this.states)) {
      this.states[key] = new PlaywrightState();
    }
    return this.states[key];
  };
  getState = (peer) => {
    const mapPeer = this.peerMap[peer.getPeer()];
    if (mapPeer) {
      return this.createState(mapPeer);
    } else {
      this.peerMap[peer.getPeer()] = peer.getPeer();
      const p = peer.getPeer();
      return this.createState(p);
    }
  };
  getActiveBrowser = (peer) => this.getState(peer).getActiveBrowser();
  getActiveContext = (peer) => this.getState(peer).getActiveContext();
  getActivePage = (peer) => {
    const page = this.getState(peer).getActivePage();
    if (!page) throw Error("No page open.");
    return page;
  };
  wrapping = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingDebug = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.debug({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call));
        logger.debug({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.debug({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingState = (func) => {
    return async (call, callback) => {
      try {
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(this.getState(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingPage = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getActivePage(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  wrappingStatePage = (func) => {
    return async (call, callback) => {
      try {
        const request = call.request;
        if (request === null) throw Error("No request");
        logger.info({ event_kind: "grpc", action: func.name, status: "started" });
        const response = await func(request, this.getState(call), this.getActivePage(call));
        logger.info({ event_kind: "grpc", action: func.name, status: "succeeded" });
        callback(null, response);
      } catch (e) {
        logger.info({ event_kind: "grpc", action: func.name, status: "failed" });
        callback(errorResponse(e), null);
      }
    };
  };
  initializeExtension = this.wrapping(initializeExtension);
  async callExtensionKeyword(call) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const results = await extensionKeywordCall(request, call, this.getState(call));
      for (const result of results) {
        call.write(result);
      }
    } catch (e) {
      logger.error(
        { event_kind: "internal_error", status: "failed", error_type: errorType(e) },
        "Error in callExtensionKeyword"
      );
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  closeBrowser = this.wrappingState(closeBrowser);
  closeBrowserServer = this.wrapping(closeBrowserServer);
  closeAllBrowsers = this.wrappingState(closeAllBrowsers);
  closeContext = this.wrapping(closeContext);
  closePage = this.wrapping(closePage);
  openTraceGroup = this.wrapping(openTraceGroup);
  closeTraceGroup = this.wrappingState(closeTraceGroup);
  setRfContext = this.wrappingDebug(setRFContext);
  getBrowserCatalog = this.wrapping(getBrowserCatalog);
  getConsoleLog = this.wrapping(getConsoleLog);
  getErrorMessages = this.wrapping(getErrorMessages);
  async getCookies(call, callback) {
    try {
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await getCookies(context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async addCookie(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await addCookie(request, context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async deleteAllCookies(call, callback) {
    try {
      const context = this.getActiveContext(call);
      if (!context) throw Error("no open context.");
      const result = await deleteAllCookies(context);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async switchPage(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await switchPage(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async switchContext(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await switchContext(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async saveStorageState(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await saveStorageState(request, this.getActiveBrowser(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  switchBrowser = this.wrapping(switchBrowser);
  newPage = this.wrapping(newPage);
  newContext = this.wrapping(newContext);
  newBrowser = this.wrapping(newBrowser);
  startCoverage = this.wrapping(startCoverage);
  stopCoverage = this.wrapping(stopCoverage);
  mergeCoverage = this.wrapping(mergeCoverage);
  launchBrowserServer = this.wrapping(launchBrowserServer);
  newPersistentContext = this.wrapping(newPersistentContext);
  connectToBrowser = this.wrapping(connectToBrowser);
  goTo = this.wrappingPage(goTo);
  pdf = this.wrapping(savePageAsPdf);
  emulateMedia = this.wrapping(emulateMedia);
  async goBack(call, callback) {
    try {
      await this.getActivePage(call).goBack();
      callback(null, emptyWithLog("Did Go Back"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async goForward(call, callback) {
    try {
      await this.getActivePage(call).goForward();
      callback(null, emptyWithLog("Did Go Forward"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  takeScreenshot = this.wrapping(takeScreenshot);
  getBoundingBox = this.wrapping(getBoundingBox);
  ariaSnapShot = this.wrappingStatePage(getAriaSnapshot);
  async getPageSource(call) {
    try {
      const results = await getPageSource(this.getActivePage(call));
      for (const result of results) {
        call.write(result);
      }
    } catch (e) {
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  async setTimeout(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const response = await setTimeout2(request, this.getActiveBrowser(call)?.context?.c);
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getTitle(call, callback) {
    try {
      const response = await getTitle(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getUrl(call, callback) {
    try {
      const response = await getUrl(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  getElementCount = this.wrapping(getElementCount);
  getSelectContent = this.wrapping(getSelectContent);
  getDomProperty = this.wrapping(getDomProperty);
  getText = this.wrapping(getText);
  getBoolProperty = this.wrapping(getBoolProperty);
  getElementAttribute = this.wrapping(getElementAttribute);
  getElementStates = this.wrapping(getElementStates);
  getStyle = this.wrapping(getStyle);
  getTableCellIndex = this.wrapping(getTableCellIndex);
  getTableRowIndex = this.wrapping(getTableRowIndex);
  scrollToElement = this.wrapping(scrollToElement);
  async getViewportSize(call, callback) {
    try {
      const response = await getViewportSize(this.getActivePage(call));
      callback(null, response);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  selectOption = this.wrapping(selectOption);
  executePlaywright = this.wrapping(executePlaywright);
  grantPermissions = this.wrapping(grantPermissions);
  clearPermissions = this.wrapping(clearPermissions);
  deselectOption = this.wrapping(deSelectOption);
  typeText = this.wrapping(typeText);
  fillText = this.wrapping(fillText);
  clearText = this.wrapping(clearText);
  press = this.wrapping(press);
  click = this.wrapping(click);
  addLocatorHandlerCustom = this.wrapping(addLocatorHandlerCustom);
  removeLocatorHandler = this.wrapping(removeLocatorHandler);
  tap = this.wrapping(tap);
  hover = this.wrapping(hover);
  focus = this.wrapping(focus);
  checkCheckbox = this.wrapping(checkCheckbox);
  uncheckCheckbox = this.wrapping(uncheckCheckbox);
  getElement = this.wrapping(getElement);
  getElements = this.wrapping(getElements);
  getByX = this.wrapping(getByX);
  addStyleTag = this.wrappingPage(addStyleTag);
  setTime = this.wrapping(setTime);
  clockResume = this.wrapping(clockResume);
  clockPauseAt = this.wrapping(clockPauseAt);
  advanceClock = this.wrapping(advanceClock);
  waitForElementsState = this.wrapping(waitForElementState);
  waitForRequest = this.wrappingPage(waitForRequest);
  async waitForResponse(call) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const results = await waitForResponse(request, this.getActivePage(call));
      for (const result of results) {
        logger.info(`Sending response ${result.log}`);
        call.write(result);
      }
    } catch (e) {
      call.emit("error", errorResponse(e));
    }
    call.end();
  }
  waitForNavigation = this.wrappingPage(waitForNavigation);
  waitForPageLoadState = this.wrappingPage(WaitForPageLoadState);
  getDownloadState = this.wrapping(getDownloadState);
  cancelDownload = this.wrapping(cancelDownload);
  async waitForFunction(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await waitForFunction(request, this.getState(call), this.getActivePage(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  waitForDownload = this.wrappingStatePage(waitForDownload);
  evaluateJavascript = this.wrappingStatePage(evaluateJavascript);
  recordSelector = this.wrapping(recordSelector);
  async health(call, callback) {
    callback(null, { body: "OK", log: "" });
  }
  highlightElements = this.wrapping(highlightElements);
  download = this.wrapping(download);
  setViewportSize = this.wrappingPage(setViewportSize);
  httpRequest = this.wrappingPage(httpRequest);
  async getDevice(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = getDevice(request);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async getDevices(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = getDevices();
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async uploadFileBySelector(call, callback) {
    let buffer = "";
    let lastRequest;
    call.on("data", (request) => {
      void (async () => {
        try {
          logger.info(`Reading multiplepart uploadFileBySelector`);
          const newBuffer = request.buffer;
          buffer += newBuffer;
          lastRequest = request;
        } catch (e) {
          callback(errorResponse(e), null);
        }
      })();
    });
    call.on("error", (e) => {
      logger.error(
        { event_kind: "internal_error", status: "failed", error_type: errorType(e) },
        "Stream error in uploadFileBySelector"
      );
      callback(errorResponse(e), null);
    });
    call.on("end", () => {
      void (async () => {
        try {
          if (!lastRequest) {
            callback(errorResponse(new Error("No data received for uploadFileBySelector")), null);
            return;
          }
          const finalRequest = { ...lastRequest, buffer };
          const result = await uploadFileBySelector(finalRequest, this.getState(call));
          callback(null, result);
        } catch (e) {
          callback(errorResponse(e), null);
        }
      })();
    });
  }
  uploadFile = this.wrappingPage(uploadFile);
  handleAlert = this.wrappingPage(handleAlert);
  waitForAlerts = this.wrappingPage(waitForAlerts);
  mouseMove = this.wrappingPage(mouseMove);
  mouseWheel = this.wrappingPage(mouseWheel);
  mouseButton = this.wrappingPage(mouseButton);
  keyboardKey = this.wrappingPage(keyboardKey);
  keyboardInput = this.wrappingPage(keyboardInput);
  async setOffline(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await setOffline(request, this.getActiveContext(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async setGeolocation(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const result = await setGeolocation(request, this.getActiveContext(call));
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async reload(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const body = request.body;
      const result = await reload(this.getActivePage(call), body);
      callback(null, result);
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
  async setPeerId(call, callback) {
    try {
      const request = call.request;
      if (request === null) throw Error("No request");
      const oldPeer = this.peerMap[call.getPeer()];
      this.peerMap[call.getPeer()] = request.index;
      callback(null, stringResponse(oldPeer, "Successfully overrode peer id"));
    } catch (e) {
      callback(errorResponse(e), null);
    }
  }
};
PlaywrightServer = __decorateClass([
  class_async_logger
], PlaywrightServer);

// node/playwright-wrapper/index.ts
var args = process.argv.slice(2);
var host = args[0];
var port = args[1];
if (!host) {
  throw new Error(`No host defined`);
}
if (!port) {
  throw new Error(`No port defined`);
}
var server = new import_grpc_js3.Server();
server.addService(PlaywrightService, new PlaywrightServer());
server.bindAsync(`${host}:${port}`, import_grpc_js3.ServerCredentials.createInsecure(), () => {
  logger.info(`Listening on ${host}:${port}`);
});
process.on("SIGTERM", () => {
  logger.info("Received SIGTERM, shutting down gracefully");
  server.tryShutdown(() => {
    process.exit(0);
  });
});
