# ruff: noqa: T201
import json
import os
import pathlib
import sys
import tempfile
import time
from multiprocessing import Pool, cpu_count

import click
import pandas as pd
import yaml
from git import Repo
from tabulate import tabulate
from yaml.parser import ParserError, ScannerError

from graphsenselib.tagpack import UniqueKeyLoader, get_version
from graphsenselib.tagpack.actorpack import Actor, ActorPack
from graphsenselib.tagpack.actorpack_schema import ActorPackSchema
from graphsenselib.tagpack.graphsense import GraphSense
from graphsenselib.tagpack.tagpack import (
    TagPack,
    TagPackFileError,
    collect_tagpack_files,
    get_repository,
    get_uri_for_tagpack,
)
from graphsenselib.tagpack.tagpack_schema import TagPackSchema, ValidationError
from graphsenselib.tagpack.tagstore import InsertTagpackWorker, TagStore
from graphsenselib.tagpack.utils import strip_empty, normalize_id
from graphsenselib.tagpack.constants import (
    CONFIG_FILE,
    DEFAULT_CONFIG,
    DEFAULT_SCHEMA,
)
from graphsenselib.tagstore.cli import tagstore
from graphsenselib.tagpack.taxonomy import _load_taxonomies, _load_taxonomy
from graphsenselib.monitoring.notifications import send_msg_to_topic
from graphsenselib.utils.locking import create_lock, LockAcquisitionError
from graphsenselib.utils.rest_utils import is_eth_like
import logging
from contextlib import contextmanager
from typing import Tuple
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


@contextmanager
def _timed_phase(name: str):
    """Bracket a sync sub-step with INFO start/done lines + wall-clock.

    Used by `tagpack-tool sync` so an operator can read the log and see
    where time actually went on a multi-repo / multi-step run, without
    having to attach a profiler or time things by hand.
    """
    logger.info("%s ...", name)
    t0 = time.perf_counter()
    try:
        yield
    finally:
        logger.info("%s done in %.2fs", name, time.perf_counter() - t0)


DEFAULT_ACTORPACK_URL = "https://raw.githubusercontent.com/graphsense/graphsense-tagpacks/master/actors/graphsense.actorpack.yaml"


def override_postgres_url(url):
    def_url, url_msg = read_url_from_env()
    if not url:
        url = def_url
    if not url:
        logger.warning(url_msg)
        click.echo("No postgresql URL connection was provided. Exiting.")
        sys.exit(1)
    return url


def _load_config(cfile):
    if cfile is None or not os.path.isfile(cfile):
        return DEFAULT_CONFIG
    return yaml.safe_load(open(cfile, "r"))


def read_url_from_env():
    """
    Read environment variables from the OS, and build a postgresql connection
    URL. If the URL cannot be built, return None and an error message.
    """
    ev = dict(os.environ)
    try:
        url = f"postgresql://{ev['POSTGRES_USER']}:{ev['POSTGRES_PASSWORD']}"
        url += f"@{ev['POSTGRES_HOST']}:5432/{ev['POSTGRES_DB']}"
        msg = ""
    except KeyError:
        fields = ["USER", "PASSWORD", "HOST", "DB"]
        miss = {f"POSTGRES_{a}" for a in fields}
        miss -= set(ev.keys())
        msg = (
            "Unable to build postgresql URL: required environment variables "
            "(POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_HOST, POSTGRES_DB) not found: "
            + ", ".join(miss)
        )
        url = None
    return url, msg


def show_version():
    return f"GraphSense TagPack management tool {get_version()}"


def remove_generic(name: str) -> str:
    """Remove common domain extensions and generic words from actor names"""
    extensions = [
        "com",
        "net",
        "io",
        "org",
        "finance",
        "protocol",
        "exchange",
        "swap",
        "dex",
        "fi",
    ]
    for ext in extensions:
        if name.endswith(ext):
            name = name[: -len(ext)]
    return name


def find_similar_actors(
    actor_id: str, existing_actors: list, threshold: int = 80, limit: int = 5
):
    """Find similar actors using fuzzy matching on normalized IDs"""
    from rapidfuzz import process, fuzz

    actor_normalized = remove_generic(normalize_id(actor_id))

    # Normalize existing actor IDs, try to match on existing actors or versions without generic words
    candidates = [remove_generic(normalize_id(a)) for a in existing_actors] + [
        normalize_id(actor_id) for a in existing_actors
    ]

    normalized_without_generic = [
        remove_generic(normalize_id(a)) for a in existing_actors
    ]
    normalized_with_generic = [normalize_id(a) for a in existing_actors]

    # make them unique and map them to the original actor ids
    candidates_with_original = [
        (a, b)
        for a, b in zip(
            normalized_without_generic + normalized_with_generic,
            existing_actors + existing_actors,
        )
    ]
    # dedupe in the first argument

    # should be deduped here:
    candidate_to_original = {c[0]: c[1] for c in candidates_with_original}
    candidates = list(candidate_to_original.keys())
    originals = list(candidate_to_original.values())

    # Find best matches
    matches = process.extract(
        actor_normalized, candidates, scorer=fuzz.ratio, limit=limit
    )
    # Filter by threshold and return original IDs
    similar = []
    for _, score, idx in matches:
        if score >= threshold:
            similar.append((originals[idx], score))

    return similar


def load_actorpack_for_validation(actorpack_path, config):
    """Load and validate actorpack for actor checking"""
    import requests

    def _is_http_url(path):
        return isinstance(path, str) and path.startswith(("http://", "https://"))

    def _load_actorpack_from_text(uri, text, schema, taxonomies):
        contents = yaml.load(text, UniqueKeyLoader)
        if "header" in contents:
            for k, v in contents["header"].items():
                contents[k] = v
            contents.pop("header")
        return ActorPack(uri, contents, schema, taxonomies)

    schema = ActorPackSchema()
    taxonomies = _load_taxonomies(config)

    # Default behavior: fetch actorpack from remote URL in-memory.
    if actorpack_path is None:
        actorpack_path = DEFAULT_ACTORPACK_URL

    try:
        if _is_http_url(actorpack_path):
            logger.info(f"Downloading actorpack from {actorpack_path}...")
            response = requests.get(actorpack_path, timeout=30)
            response.raise_for_status()
            ap = _load_actorpack_from_text(
                actorpack_path,
                response.text,
                schema,
                taxonomies,
            )
        elif os.path.isfile(actorpack_path):
            ap = ActorPack.load_from_file("", actorpack_path, schema, taxonomies, None)
        else:
            logger.error(f"Actorpack path does not exist: {actorpack_path}")
            return None
    except Exception as e:
        logger.error(f"Failed to load actorpack from {actorpack_path}: {e}")
        return None

    ap.validate()
    logger.info(f"Loaded actorpack from {actorpack_path}")
    return ap


@click.group()
def tagpacktool_cli():
    """tagpack management tool commands"""
    pass


@tagpacktool_cli.group("tagpack-tool")
@click.option(
    "--config",
    default=os.path.join(os.getcwd(), CONFIG_FILE),
    help="path to config.yaml",
)
@click.version_option(version=get_version(), prog_name="tagpack-tool")
@click.pass_context
def cli(ctx, config):
    """GraphSense TagPack management tool"""
    ctx.ensure_object(dict)
    ctx.obj["config"] = config


@cli.command()
@click.option("-v", "--verbose", is_flag=True, help="verbose configuration")
@click.pass_context
def config(ctx, verbose):
    """show repository config"""
    config_file = ctx.obj["config"]
    if os.path.exists(config_file):
        logger.info("Using Config File:", config_file)
    else:
        logger.info(
            f"No override config file found at {config_file}. Using default values."
        )
    if verbose:
        config_data = _load_config(config_file)
        logger.info("Show configured taxonomies")
        count = 0
        if "taxonomies" not in config_data:
            logger.error("No configured taxonomies")
        else:
            for key, value in config_data["taxonomies"].items():
                logger.info(value)
                count += 1
            click.secho(f"{count} configured taxonomies", fg="green")


@cli.command()
@click.option(
    "-r",
    "--repos",
    default=os.path.join(os.getcwd(), "tagpack-repos.config"),
    help="File with list of repos to sync to the database.",
)
@click.option(
    "--force",
    is_flag=True,
    help="By default, tagpack/actorpack insertion stops when an already inserted tagpack/actorpack exists in the database. Use this switch to force re-insertion.",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "--run-cluster-mapping-with-env",
    help="Environment in graphsense-lib config to use for the mapping process. Only inserts non existing mappings.",
)
@click.option(
    "--rerun-cluster-mapping-with-env",
    help="Environment in graphsense-lib config to use for the mapping process. Reinserts all mappings.",
)
@click.option(
    "--auto-rerun-cluster-mapping-with-env",
    help=(
        "Environment in graphsense-lib config to use for an automatic "
        "staleness check: a sample of mapped addresses is compared against "
        "the current clustering, and a full rerun is triggered only if the "
        "divergence rate is at or above --cluster-staleness-threshold. "
        "Otherwise only newly-inserted addresses are mapped."
    ),
)
@click.option(
    "--cluster-staleness-sample-size",
    type=int,
    default=2000,
    show_default=True,
    help=(
        "Sample size *per network* for --auto-rerun-cluster-mapping-with-env. "
        "Each eligible (non-eth-like) network is sampled independently; a "
        "global limit would be dominated by BTC's heavy-hitter clusters."
    ),
)
@click.option(
    "--cluster-staleness-threshold",
    type=float,
    default=0.05,
    show_default=True,
    help=(
        "Divergence rate (0.0-1.0) at or above which "
        "--auto-rerun-cluster-mapping-with-env triggers a full rerun. "
        "Compared against the maximum per-network rate, so drift on any "
        "one chain is enough to trigger."
    ),
)
@click.option(
    "--n-workers",
    type=int,
    default=1,
    help="number of workers to use for the tagpack insert. Default is 1. Zero or negative values are used as offset of the machines cpu_count.",
)
@click.option(
    "--no-validation",
    is_flag=True,
    help="Do not validate tagpacks before insert. (better insert speed)",
)
@click.option(
    "--dont-update-quality-metrics",
    is_flag=True,
    help="Do update quality metrinc. (better insert speed)",
)
@click.option(
    "--no-lock",
    is_flag=True,
    help="Do not acquire a lock to avoid conflicting sync processes.",
)
@click.option(
    "--no-file-lock",
    is_flag=True,
    hidden=True,
    help="Deprecated alias for --no-lock.",
)
def sync(
    repos,
    force,
    url,
    run_cluster_mapping_with_env,
    rerun_cluster_mapping_with_env,
    auto_rerun_cluster_mapping_with_env,
    cluster_staleness_sample_size,
    cluster_staleness_threshold,
    n_workers,
    no_validation,
    dont_update_quality_metrics,
    no_lock,
    no_file_lock,
):
    """syncs the tagstore with a list of git repos."""
    url = override_postgres_url(url)

    lock_disabled = no_lock or no_file_lock

    # Ensure AppConfig is populated (lock backend selection reads
    # use_redis_locks / redis_url). The main `graphsense-cli` callback
    # already calls load_partial; this is a defensive no-op for that path
    # but makes the command safe if invoked via a different entry point.
    if not lock_disabled:
        from graphsenselib.config import get_config

        cfg = get_config()
        if not cfg.is_loaded():
            cfg.load_partial()

    db_name = urlparse(url).path.lstrip("/") or "default"
    lock_name = f"tagpack_sync_{db_name}"

    try:
        with create_lock(lock_name, disabled=lock_disabled):
            _sync_impl(
                repos=repos,
                force=force,
                url=url,
                run_cluster_mapping_with_env=run_cluster_mapping_with_env,
                rerun_cluster_mapping_with_env=rerun_cluster_mapping_with_env,
                auto_rerun_cluster_mapping_with_env=auto_rerun_cluster_mapping_with_env,
                cluster_staleness_sample_size=cluster_staleness_sample_size,
                cluster_staleness_threshold=cluster_staleness_threshold,
                n_workers=n_workers,
                no_validation=no_validation,
                dont_update_quality_metrics=dont_update_quality_metrics,
            )
    except LockAcquisitionError as e:
        logger.warning(str(e))
        sys.exit(911)


def _sync_impl(
    repos,
    force,
    url,
    run_cluster_mapping_with_env,
    rerun_cluster_mapping_with_env,
    auto_rerun_cluster_mapping_with_env,
    cluster_staleness_sample_size,
    cluster_staleness_threshold,
    n_workers,
    no_validation,
    dont_update_quality_metrics,
):
    if os.path.isfile(repos):
        sync_t0 = time.perf_counter()
        with open(repos, "r") as f:
            repos_list = [x.strip() for x in f.readlines() if not x.startswith("#")]

        from graphsenselib.tagstore.cli import (
            tagstore as tagstore_tool,
            init as init_tagstore_tool,
        )

        click_ctx_tagstore = click.Context(tagstore_tool)

        click_ctx_actorpack = click.Context(actorpack)
        click_ctx_actorpack.ensure_object(dict)

        click_ctx_tagpack = click.Context(tagpack)
        click_ctx_tagpack.ensure_object(dict)

        click_ctx_tagpacktool_tagstore = click.Context(tagstore)
        click_ctx_tagpacktool_tagstore.ensure_object(dict)

        click_ctx_tagpacktool_quality = click.Context(quality)
        click_ctx_tagpacktool_quality.ensure_object(dict)

        with _timed_phase("Init db and add taxonomies"):
            click_ctx_tagstore.invoke(init_tagstore_tool, db_url=url)

        extra_option = "--force" if force else None
        extra_option = "--add-new" if extra_option is None else extra_option

        for repo_url in repos_list:
            with tempfile.TemporaryDirectory(suffix="tagstore_sync") as temp_dir_tt:
                logger.info(f"Syncing {repo_url}. Temp files in: {temp_dir_tt}")
                with _timed_phase(f"Repo {repo_url}"):
                    with _timed_phase("Cloning"):
                        repo_url, *branch_etc = repo_url.split(" ")
                        repo = Repo.clone_from(repo_url, temp_dir_tt)
                        if len(branch_etc) > 0:
                            branch = branch_etc[0]
                            logger.info(f"Using branch {branch}")
                            repo.git.checkout(branch)

                    with _timed_phase("Inserting actorpacks"):
                        click_ctx_actorpack.invoke(
                            insert_actorpack_cli, path=temp_dir_tt, url=url
                        )

                    public = len(branch_etc) > 1 and branch_etc[1].strip() == "public"

                    tag_type_default = (
                        branch_etc[2].strip() if len(branch_etc) > 2 else None
                    )

                    if public:
                        logger.info("Caution: This repo is imported as public.")

                    args = {
                        "path": temp_dir_tt,
                        "url": url,
                        "public": public,
                        "force": force,
                        "n_workers": n_workers,
                        "no_validation": no_validation,
                        "add_new": False,
                        "update": not force,
                        "tag_type_default": tag_type_default,
                    }

                    if tag_type_default is None:
                        args.pop("tag_type_default")

                    with _timed_phase("Inserting tagpacks"):
                        click_ctx_tagpack.invoke(insert_tagpack_cli, **args)

        with _timed_phase("Removing duplicates"):
            click_ctx_tagstore.invoke(remove_duplicates, url=url)

        with _timed_phase("Refreshing db views"):
            click_ctx_tagstore.invoke(refresh_views, url=url)

        if not dont_update_quality_metrics:
            with _timed_phase("Calc Quality metrics"):
                calc_quality_measures(url, DEFAULT_SCHEMA)
                # click_ctx_tagpacktool_quality.invoke(calculate_quality, url=url)

        effective_rerun_env = rerun_cluster_mapping_with_env
        effective_run_env = run_cluster_mapping_with_env

        if auto_rerun_cluster_mapping_with_env and not rerun_cluster_mapping_with_env:
            if run_cluster_mapping_with_env:
                logger.warning(
                    "Both --run-cluster-mapping-with-env and "
                    "--auto-rerun-cluster-mapping-with-env passed; "
                    "--auto-rerun- takes precedence."
                )
            with _timed_phase(
                f"Checking cluster mapping staleness against env "
                f"'{auto_rerun_cluster_mapping_with_env}' "
                f"(sample={cluster_staleness_sample_size}, "
                f"threshold={cluster_staleness_threshold:.2%})"
            ):
                overall, per_network = check_cluster_mapping_staleness(
                    url=url,
                    schema=DEFAULT_SCHEMA,
                    db_nodes=["localhost"],
                    cassandra_username=None,
                    cassandra_password=None,
                    ks_file=None,
                    use_gs_lib_config_env=auto_rerun_cluster_mapping_with_env,
                    sample_size=cluster_staleness_sample_size,
                )
            for net, stats in per_network.items():
                logger.info(
                    f"  {net}: {stats['diverged']}/{stats['checked']} "
                    f"diverged ({stats['rate']:.2%})"
                )
            if per_network:
                max_net, max_stats = max(
                    per_network.items(), key=lambda kv: kv[1]["rate"]
                )
                max_rate = float(max_stats["rate"])
            else:
                max_net, max_rate = None, 0.0
            if max_rate >= cluster_staleness_threshold:
                logger.info(
                    f"Max per-network divergence {max_rate:.2%} on '{max_net}' "
                    f">= threshold {cluster_staleness_threshold:.2%} "
                    f"(overall {overall:.2%}); rerunning full cluster mapping."
                )
                effective_rerun_env = auto_rerun_cluster_mapping_with_env
            else:
                logger.info(
                    f"Max per-network divergence {max_rate:.2%} < threshold "
                    f"{cluster_staleness_threshold:.2%} (overall {overall:.2%}); "
                    "mapping new addresses only."
                )
                effective_run_env = auto_rerun_cluster_mapping_with_env

        if effective_run_env or effective_rerun_env:
            with _timed_phase("Import cluster mappings"):
                click_ctx_tagpacktool_tagstore.invoke(
                    insert_cluster_mappings,
                    url=url,
                    use_gs_lib_config_env=(effective_run_env or effective_rerun_env),
                    update=effective_rerun_env is not None,
                )

            with _timed_phase("Refreshing db views (post-cluster-mapping)"):
                click_ctx_tagstore.invoke(refresh_views, url=url)

        logger.info(
            "Your tagstore is now up-to-date again. Total sync time: %.2fs",
            time.perf_counter() - sync_t0,
        )

    else:
        logger.error(f"Repos to sync file {repos} does not exist.")


def validate_tagpack(
    config,
    path,
    no_address_validation,
    check_actor_references=False,
    strict_actor_references=True,
    actorpack_path=None,
    use_pyyaml=False,
):
    t0 = time.time()
    logger.info("TagPack validation starts")
    logger.info(f"Path: {path}")

    taxonomies = _load_taxonomies(config)
    taxonomy_keys = taxonomies.keys()
    logger.info(f"Loaded taxonomies: {taxonomy_keys}")

    schema = TagPackSchema()
    logger.info(f"Loaded schema: {schema.definition}")

    tagpack_files = collect_tagpack_files(path)
    n_tagpacks = len([f for fs in tagpack_files.values() for f in fs])
    logger.info(f"Collected {n_tagpacks} TagPack files")

    # Load actorpack if actor checking is enabled
    actorpack = None
    existing_actor_ids = []
    similarity_threshold = 80  # Default threshold for fuzzy matching

    if strict_actor_references:
        check_actor_references = True

    if check_actor_references:
        # Check if rapidfuzz is installed
        try:
            import rapidfuzz  # noqa: F401
        except ImportError:
            logger.error("rapidfuzz is required for actor name recommendations.")
            logger.error(
                "Make sure you installed graphsense-lib with the 'tagpacks' extra."
            )
            sys.exit(1)

        actorpack = load_actorpack_for_validation(actorpack_path, config)
        if actorpack is None:
            logger.error("Failed to load actorpack. Actor validation will be skipped.")
            check_actor_references = False
        else:
            existing_actor_ids = list(actorpack.get_resolve_mapping().keys())
            logger.info(f"Loaded {len(existing_actor_ids)} actors for validation")

    # Track actor validation results
    unique_known_actors = set()
    unique_unknown_actors = {}  # {actor: [(similar_id, score), ...]}

    no_passed = 0
    try:
        for headerfile_dir, files in tagpack_files.items():
            for tagpack_file in files:
                strict_file_failed = False
                tagpack = TagPack.load_from_file(
                    tagpack_file,
                    tagpack_file,
                    schema,
                    taxonomies,
                    headerfile_dir,
                    use_pyyaml,
                )

                logger.info(f"Validating {tagpack_file}")

                tagpack.validate()
                # verify valid blocknetwork addresses using internal checksum
                if not no_address_validation:
                    tagpack.verify_addresses()

                # Check actors if enabled
                if check_actor_references and actorpack:
                    # Collect actors from header level and tag level
                    actors_to_check = set()
                    header_actor = tagpack.all_header_fields.get("actor")
                    if header_actor:
                        actors_to_check.add(header_actor)
                    for tag in tagpack.tags:
                        tag_actor = tag.all_fields.get("actor")
                        if tag_actor:
                            actors_to_check.add(tag_actor)

                    for actor in actors_to_check:
                        resolved = actorpack.resolve_actor(actor)
                        if resolved is None:
                            # Unknown actor
                            if actor not in unique_unknown_actors:
                                similar = find_similar_actors(
                                    actor, existing_actor_ids, similarity_threshold
                                )
                                unique_unknown_actors[actor] = similar
                                msg = f"  Actor '{actor}' NOT FOUND in actorpack"

                                if similar:
                                    suggestions = ", ".join(
                                        [
                                            f"{sid} ({score}%)"
                                            for sid, score in similar[:3]
                                        ]
                                    )
                                    msg += f" (existing actors with similar names: {suggestions})"
                                else:
                                    msg += (
                                        " (no existing actors with similar names found)"
                                    )
                                if strict_actor_references:
                                    logger.error(msg)
                                else:
                                    logger.warning(msg)
                            if strict_actor_references:
                                strict_file_failed = True
                        else:
                            unique_known_actors.add(actor)

                if strict_file_failed:
                    logger.error(
                        f"FAILED: {tagpack_file} - Actor validation failed in strict mode"
                    )
                else:
                    logger.info(f"PASSED: {tagpack_file}")
                    no_passed += 1
    except (ValidationError, TagPackFileError) as e:
        logger.error(f"FAILED: {e}")

    failed = no_passed < n_tagpacks

    duration = round(time.time() - t0, 2)
    if failed:
        logger.error(f"{no_passed}/{n_tagpacks} TagPacks passed in {duration}s")
    else:
        click.secho(
            f"{no_passed}/{n_tagpacks} TagPacks passed in {duration}s", fg="green"
        )

    # Print actor validation summary if enabled
    if check_actor_references and actorpack and not strict_actor_references:
        click.secho("\n" + "=" * 80, fg="cyan")
        click.secho("ACTOR VALIDATION SUMMARY", fg="cyan")
        click.secho("=" * 80, fg="cyan")
        click.secho(
            f"Unique actors found in actorpack: {len(unique_known_actors)}", fg="green"
        )
        click.secho(
            f"Unique actors NOT in actorpack: {len(unique_unknown_actors)}",
            fg="yellow" if unique_unknown_actors else "green",
        )

        if unique_known_actors:
            click.secho(
                f"\nKnown actors: {', '.join(sorted(unique_known_actors))}", fg="green"
            )

        if unique_unknown_actors:
            click.secho("\nUnknown actors:", fg="yellow")
            for actor, similar in sorted(unique_unknown_actors.items()):
                if similar:
                    suggestions = ", ".join(
                        [f"{sid} ({score}%)" for sid, score in similar[:3]]
                    )
                    click.secho(
                        f"  - {actor} (suggestions: {suggestions})", fg="yellow"
                    )
                else:
                    click.secho(f"  - {actor} (no suggestions)", fg="yellow")

    if failed:
        sys.exit(1)


def list_tags(url, schema, unique, category, network, csv):
    t0 = time.time()
    if not csv:
        logger.info("List tags starts")

    tagstore = TagStore(url, schema)

    try:
        uniq, cat, net = unique, category, network
        qm = tagstore.list_tags(unique=uniq, category=cat, network=net)
        if not csv:
            logger.info(f"{len(qm)} Tags found")
        else:
            logger.info("network,tp_title,tag_label")
        for row in qm:
            logger.info(("," if csv else ", ").join(map(str, row)))

        duration = round(time.time() - t0, 2)
        if not csv:
            click.secho(f"Done in {duration}s", fg="green")
    except Exception as e:
        logger.error(f"Operation failed: {e}")


def _suggest_actors(url, schema, label, max_results):
    logger.info(f"Searching suitable actors for {label} in TagStore")
    tagstore = TagStore(url, schema)
    candidates = tagstore.find_actors_for(
        label, max_results, use_simple_similarity=False, threshold=0.1
    )
    print(f"Found {len(candidates)} candidates")
    df = pd.DataFrame(candidates)
    print(
        tabulate(
            df,
            headers=df.columns,
            tablefmt="psql",
            maxcolwidths=[None, None, None, None, 60],
        )
    )


def add_actors_to_tagpack(url, schema, path, max_results, categories, inplace):
    logger.info("Starting interactive tagpack actor enrichment process.")

    tagstore = TagStore(url, schema)
    tagpack_files = collect_tagpack_files(path)

    schema_obj = TagPackSchema()
    user_choice_cache = {}

    for headerfile_dir, files in tagpack_files.items():
        for tagpack_file in files:
            tagpack = TagPack.load_from_file(
                "", tagpack_file, schema_obj, None, headerfile_dir
            )
            logger.info(f"Loading {tagpack_file}: ")

            def find_actor_candidates(search_term):
                res = tagstore.find_actors_for(
                    search_term,
                    max_results,
                    use_simple_similarity=False,
                    threshold=0.1,
                )

                def get_label(actor_row):
                    a = Actor.from_contents(actor_row, None)
                    return f"{actor_row['label']} ({', '.join(a.uris)})"

                return [(x["id"], get_label(x)) for x in res]

            category_filter = strip_empty(categories.split(","))
            updated = tagpack.add_actors(
                find_actor_candidates,
                only_categories=category_filter if len(category_filter) > 0 else None,
                user_choice_cache=user_choice_cache,
            )

            if updated:
                updated_file = (
                    tagpack_file.replace(".yaml", "_with_actors.yaml")
                    if not inplace
                    else tagpack_file
                )
                click.secho(f"Writing updated Tagpack {updated_file}", fg="green")
                with open(updated_file, "w") as outfile:
                    tagpack.contents["tags"] = tagpack.contents.pop(
                        "tags"
                    )  # re-insert tags
                    tagpack.update_lastmod()
                    yaml.dump(
                        tagpack.contents, outfile, sort_keys=False
                    )  # write in order of insertion
            else:
                click.secho("No actors added, moving on.", fg="green")


def insert_tagpack(
    url,
    schema,
    path,
    batch_size,
    public,
    force,
    add_new,
    no_strict_check,
    no_git,
    n_workers,
    no_validation,
    tag_type_default,
    config,
    update_flag,
    use_pyyaml=False,
) -> Tuple[int, int]:
    t0 = time.time()
    logger.info("TagPack insert starts")
    logger.info(f"Path: {path}")

    assert not (update_flag and add_new), "Can't use update and add_new together."

    if no_git:
        base_url = path
        logger.info("No repository detection done.")
    else:
        base_url = get_repository(path)
        logger.info(f"Detected repository root in {base_url}")

    tagstore = TagStore(url, schema)

    schema_obj = TagPackSchema()
    logger.info(f"Loaded TagPack schema definition: {schema_obj.definition}")

    config_data = _load_config(config)
    taxonomies = _load_taxonomies(config_data)
    taxonomy_keys = taxonomies.keys()
    logger.info(f"Loaded taxonomies: {taxonomy_keys}")

    actor_resolve_mapping = None
    try:
        actor_resolve_mapping = tagstore.get_actor_alias_mapping()
        logger.info(f"Loaded {len(actor_resolve_mapping)} actor mappings from tagstore")
    except Exception as e:
        msg = f"Failed to load actor alias mapping from tagstore: {e}"
        logger.error(msg)
        try:
            send_msg_to_topic("info", msg)
        except Exception as slack_err:
            logger.warning(f"Failed to send Slack notification: {slack_err}")

    tagpack_files = collect_tagpack_files(path)

    # resolve backlinks to remote repository and relative paths
    scheck, nogit = not no_strict_check, no_git
    prepared_packs = [
        (m, h, n[0], n[1], n[2], n[3], False)
        for m, h, n in [
            (a, h, get_uri_for_tagpack(base_url, a, scheck, nogit))
            for h, fs in tagpack_files.items()
            for a in fs
        ]
    ]

    prefix = None  # config.get("prefix", None)

    if update_flag:  # update existing tagpacks if modified, skip unmodified ones
        logger.info("Checking which files are new or modified in the tagstore:")
        prepared_packs = [
            (
                t,
                h,
                u,
                r,
                default_prefix,
                lastmod,
                tagstore.tp_exists(prefix if prefix else default_prefix, r),
            )
            for (t, h, u, r, default_prefix, lastmod, _) in prepared_packs
            if tagstore.tp_needs_update(
                prefix if prefix else default_prefix, r, lastmod
            )
        ]

    if add_new:  # don't re-insert existing tagpacks
        logger.info("Checking which files are new to the tagstore:")
        prepared_packs = [
            (t, h, u, r, default_prefix, lastmod, False)
            for (t, h, u, r, default_prefix, lastmod, _) in prepared_packs
            if not tagstore.tp_exists(prefix if prefix else default_prefix, r)
        ]

    n_ppacks = len(prepared_packs)

    logger.info(f"Collected {n_ppacks} TagPack files")

    packs = enumerate(sorted(prepared_packs), start=1)

    n_processes = n_workers if n_workers > 0 else cpu_count() + n_workers

    if n_processes < 1:
        logger.error(f"Can't use {n_processes} adjust your n_workers setting.")
        sys.exit(100)

    if n_processes > 1:
        logger.info(f"Running parallel insert on {n_processes} workers.")

    worker = InsertTagpackWorker(
        url,
        schema,
        schema_obj,
        taxonomies,
        public,
        force,
        updateMode=update_flag,
        validate_tagpack=not no_validation,
        tag_type_default=tag_type_default,
        no_git=no_git,
        use_pyyaml=use_pyyaml,
        actor_resolve_mapping=actor_resolve_mapping,
    )

    if n_processes != 1:
        with Pool(processes=n_processes) as pool:
            results = list(pool.imap_unordered(worker, packs, chunksize=10))
    else:
        # process data in the main process, makes debugging easier
        results = [worker(p) for p in packs]

    if results is not None and len(results) > 0:
        no_passed, no_tags = [sum(x) for x in zip(*results)]
    else:
        no_passed, no_tags = (0, 0)

    status = "fail" if no_passed < n_ppacks else "success"

    duration = round(time.time() - t0, 2)
    try:
        repo_name = pathlib.Path(str(base_url)).name or str(base_url) or "unknown"
    except Exception:
        repo_name = "unknown"
    msg = "Processed {}/{} TagPacks with {} Tags in {}s from {}. "
    if status == "fail":
        logger.error(msg.format(no_passed, n_ppacks, no_tags, duration, repo_name))
        failed_count = n_ppacks - no_passed
        try:
            send_msg_to_topic(
                "info",
                f"TagPack insert failed: {failed_count}/{n_ppacks} TagPacks failed in {repo_name}",
            )
        except Exception as e:
            logger.warning(f"Failed to send Slack notification: {e}")
    else:
        click.secho(
            msg.format(no_passed, n_ppacks, no_tags, duration, repo_name), fg="green"
        )
    msg = "Don't forget to run 'graphsense-cli tagpack-tool refresh-views' soon to keep the database"
    msg += " consistent!"
    print(msg)

    return (no_passed, n_ppacks)


@cli.group("tagpack")
def tagpack():
    """commands regarding tags and tagpacks"""
    pass


@tagpack.command("validate")
@click.argument("path", default=os.getcwd())
@click.option(
    "--no-address-validation",
    is_flag=True,
    help="Disables checksum validation of addresses",
)
@click.option(
    "--check-actor-references",
    is_flag=True,
    help="Validates that actors referenced in tagpacks exist in actorpack",
)
@click.option(
    "--strict-actor-references/--no-strict-actor-references",
    default=True,
    show_default=True,
    help="Fails validation when actor references cannot be validated and suppresses actor summary output",
)
@click.option(
    "--actorpack-path",
    default=None,
    help="Path to actorpack file or HTTP(S) URL (downloads GraphSense actorpack in-memory if not provided)",
)
@click.option(
    "--use-pyyaml",
    is_flag=True,
    help="Use PyYAML instead of rapidyaml for YAML parsing",
)
@click.pass_context
def validate_tagpack_cli(
    ctx,
    path,
    no_address_validation,
    check_actor_references,
    strict_actor_references,
    actorpack_path,
    use_pyyaml,
):
    """validate TagPacks"""
    config = _load_config(ctx.obj.get("config"))
    validate_tagpack(
        config,
        path,
        no_address_validation,
        check_actor_references,
        strict_actor_references,
        actorpack_path,
        use_pyyaml,
    )


@tagpack.command("list")
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--unique", is_flag=True, help="List Tags removing duplicates")
@click.option("--category", default="", help="List Tags of a specific category")
@click.option(
    "--network", default="", help="List Tags of a specific crypto-currency network"
)
@click.option("--csv", is_flag=True, help="Show csv output.")
def list_tagpack_cli(schema, url, unique, category, network, csv):
    """list Tags"""
    url = override_postgres_url(url)
    list_tags(url, schema, unique, category, network, csv)


@tagpack.command("insert")
@click.argument("path", default=os.getcwd())
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "-b", "--batch-size", type=int, default=1000, help="batch size for insert"
)
@click.option(
    "--public",
    is_flag=True,
    help="By default, tagpacks are declared private in the database. Use this switch to declare them public.",
)
@click.option(
    "--force",
    is_flag=True,
    help="By default, tagpack insertion stops when an already inserted tagpack exists in the database. Use this switch to force re-insertion.",
)
@click.option(
    "--add-new",
    is_flag=True,
    help="By default, tagpack insertion stops when an already inserted tagpack exists in the database. Use this switch to insert new tagpacks while skipping over existing ones.",
)
@click.option(
    "--no-strict-check",
    is_flag=True,
    help="Disables check for local modifications in git repository",
)
@click.option("--no-git", is_flag=True, help="Disables check for local git repository")
@click.option(
    "--n-workers",
    type=int,
    default=1,
    help="number of workers to use for the tagpack insert. Default is 1. Zero or negative values are used as offset of the machines cpu_count.",
)
@click.option(
    "--no-validation",
    is_flag=True,
    help="Do not validate tagpacks before insert. (better insert speed)",
)
@click.option(
    "--tag-type-default",
    type=str,
    default="actor",
    help="Default value for tag-type if missing in the tagpack. Default is legacy value actor.",
)
@click.option(
    "--update",
    is_flag=True,
    help="By default, tagpack insertion stops when an already inserted tagpack exists in the database. Use this switch to update existing tagpacks if modified, but skip unmodified ones.",
)
@click.option(
    "--use-pyyaml",
    is_flag=True,
    help="Use PyYAML instead of rapidyaml for YAML parsing",
)
@click.pass_context
def insert_tagpack_cli(
    ctx,
    path,
    schema,
    url,
    batch_size,
    public,
    force,
    add_new,
    no_strict_check,
    no_git,
    n_workers,
    no_validation,
    tag_type_default,
    update,
    use_pyyaml,
):
    """insert TagPacks"""
    url = override_postgres_url(url)

    insert_tagpack(
        url,
        schema,
        path,
        batch_size,
        public,
        force,
        add_new,
        no_strict_check,
        no_git,
        n_workers,
        no_validation,
        tag_type_default,
        ctx.obj.get("config"),
        update,
        use_pyyaml,
    )


@tagpack.command()
@click.argument("label")
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--max", type=int, default=5, help="Limits the number of results")
def suggest_actors(schema, url, label, max):
    """suggest an actor based on input"""
    url = override_postgres_url(url)
    _suggest_actors(url, schema, label, max)


@tagpack.command()
@click.argument("path", default=os.getcwd())
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--max", type=int, default=5, help="Limits the number of results")
@click.option(
    "--categories",
    default="",
    help="Only edit tags of a certain category (multiple possible with semi-colon)",
)
@click.option(
    "--inplace",
    is_flag=True,
    help="If set the source tagpack file is overwritten, otherwise a new file is generated called [original_file]_with_actors.yaml.",
)
def add_actors(path, schema, url, max, categories, inplace):
    """interactively add actors to tagpack"""
    url = override_postgres_url(url)
    add_actors_to_tagpack(url, schema, path, max, categories, inplace)


def validate_actorpack(config, path):
    t0 = time.time()
    logger.info("ActorPack validation starts")
    logger.info(f"Path: {path}")

    taxonomies = _load_taxonomies(config)
    taxonomy_keys = taxonomies.keys()
    logger.info(f"Loaded taxonomies: {taxonomy_keys}")

    schema = ActorPackSchema()
    logger.info(f"Loaded schema: {schema.definition}")

    actorpack_files = collect_tagpack_files(path, search_actorpacks=True)
    n_actorpacks = len([f for fs in actorpack_files.values() for f in fs])
    logger.info(f"Collected {n_actorpacks} ActorPack files")

    no_passed = 0
    try:
        for headerfile_dir, files in actorpack_files.items():
            for actorpack_file in files:
                actorpack = ActorPack.load_from_file(
                    "", actorpack_file, schema, taxonomies, headerfile_dir
                )

                logger.info(f"{actorpack_file}:\n")

                actorpack.validate()
                logger.info("PASSED")

                no_passed += 1
    except (ValidationError, TagPackFileError, ParserError, ScannerError) as e:
        logger.error(f"FAILED: {e}")

    failed = no_passed < n_actorpacks

    status = "fail" if failed else "success"

    duration = round(time.time() - t0, 2)
    msg = f"{no_passed}/{n_actorpacks} ActorPacks passed in {duration}s"
    if status == "fail":
        logger.error(msg)
    else:
        logger.info(msg)

    if failed:
        sys.exit(1)


def insert_actorpacks(
    url, schema, path, batch_size, force, add_new, no_strict_check, no_git, config
):
    t0 = time.time()
    logger.info("ActorPack insert starts")
    logger.info(f"Path: {path}")

    if no_git:
        base_url = path
        logger.info("No repository detection done.")
    else:
        base_url = get_repository(path)
        logger.info(f"Detected repository root in {base_url}")

    tagstore = TagStore(url, schema)

    schema_obj = ActorPackSchema()
    logger.info(f"Loaded ActorPack schema definition: {schema_obj.definition}")

    config_data = _load_config(config)
    taxonomies = _load_taxonomies(config_data)
    taxonomy_keys = taxonomies.keys()
    logger.info(f"Loaded taxonomies: {taxonomy_keys}")

    actorpack_files = collect_tagpack_files(path, search_actorpacks=True)

    # resolve backlinks to remote repository and relative paths
    # For the URI we use the same logic for ActorPacks than for TagPacks
    scheck, nogit = not no_strict_check, no_git
    prepared_packs = [
        (m, h, n[0], n[1], n[2])
        for m, h, n in [
            (a, h, get_uri_for_tagpack(base_url, a, scheck, nogit))
            for h, fs in actorpack_files.items()
            for a in fs
        ]
    ]

    prefix = None  # config.get("prefix", None)
    if add_new:  # don't re-insert existing tagpacks
        logger.info("Checking which ActorPacks are new to the tagstore:")
        prepared_packs = [
            (t, h, u, r, default_prefix)
            for (t, h, u, r, default_prefix) in prepared_packs
            if not tagstore.actorpack_exists(prefix if prefix else default_prefix, r)
        ]

    n_ppacks = len(prepared_packs)
    logger.info(f"Collected {n_ppacks} ActorPack files")

    no_passed = 0
    no_actors = 0

    for i, pack in enumerate(sorted(prepared_packs), start=1):
        actorpack_file, headerfile_dir, uri, relpath, default_prefix = pack

        actorpack = ActorPack.load_from_file(
            uri, actorpack_file, schema_obj, taxonomies, headerfile_dir
        )
        logger.info(f"{i} {actorpack_file}: ")
        try:
            tagstore.insert_actorpack(
                actorpack, force, prefix if prefix else default_prefix, relpath
            )
            logger.info(f"PROCESSED {len(actorpack.actors)} Actors")
            no_passed += 1
            no_actors += len(actorpack.actors)
        except Exception as e:
            logger.error(f"FAILED: {e}")

    status = "fail" if no_passed < n_ppacks else "success"

    duration = round(time.time() - t0, 2)
    msg = "Processed {}/{} ActorPacks with {} Actors in {}s."
    if status == "fail":
        logger.error(msg.format(no_passed, n_ppacks, no_actors, duration))
    else:
        logger.info(msg.format(no_passed, n_ppacks, no_actors, duration))


def list_actors(url, schema, category, csv):
    t0 = time.time()
    if not csv:
        logger.info("List actors starts")

    tagstore = TagStore(url, schema)

    try:
        qm = tagstore.list_actors(category=category)
        if not csv:
            print(f"{len(qm)} Actors found")
        else:
            print("actorpack,actor_id,actor_label,concept_label")

        for row in qm:
            print(("," if csv else ", ").join(map(str, row)))

        duration = round(time.time() - t0, 2)
        if not csv:
            click.secho(f"Done in {duration}s", fg="green")
    except Exception as e:
        logger.error(f"Operation failed: {e}")


def list_address_actors(url, schema, network, csv):
    t0 = time.time()
    if not csv:
        logger.info("List addresses with actor tags starts")

    tagstore = TagStore(url, schema)

    try:
        qm = tagstore.list_address_actors(network=network)
        if not csv:
            print(f"{len(qm)} addresses found")
        else:
            print("tag_id,tag_label,tag_address,tag_category,actor_label")

        for row in qm:
            print((", " if not csv else ",").join(map(str, row)))

        duration = round(time.time() - t0, 2)
        if not csv:
            click.secho(f"Done in {duration}s", fg="green")
    except Exception as e:
        logger.error(f"Operation failed: {e}")


# Move this to the top level of the module
class ClusterMappingArgs:
    def __init__(
        self,
        url,
        schema,
        db_nodes,
        cassandra_username,
        cassandra_password,
        ks_file,
        use_gs_lib_config_env,
        update,
    ):
        self.url = url
        self.schema = schema
        self.db_nodes = db_nodes
        self.cassandra_username = cassandra_username
        self.cassandra_password = cassandra_password
        self.ks_file = ks_file
        self.use_gs_lib_config_env = use_gs_lib_config_env
        self.update = update


@cli.group("actorpack")
def actorpack():
    """commands regarding actor information"""
    pass


@actorpack.command("validate")
@click.argument("path", default=os.getcwd())
@click.pass_context
def validate_actorpack_cli(ctx, path):  # noqa: F811
    """validate ActorPacks"""
    config = _load_config(ctx.obj.get("config"))
    validate_actorpack(config, path)


@actorpack.command("insert")
@click.argument("path", default=os.getcwd())
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for actorpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "-b", "--batch-size", type=int, default=1000, help="batch size for insert"
)
@click.option(
    "--force",
    is_flag=True,
    help="By default, actorpack insertion stops when an already inserted actorpack exists in the database. Use this switch to force re-insertion.",
)
@click.option(
    "--add-new",
    is_flag=True,
    help="By default, actorpack insertion stops when an already inserted actorpack exists in the database. Use this switch to insert new actorpacks while skipping over existing ones.",
)
@click.option(
    "--no-strict-check",
    is_flag=True,
    help="Disables check for local modifications in git repository",
)
@click.option("--no-git", is_flag=True, help="Disables check for local git repository")
@click.pass_context
def insert_actorpack_cli(
    ctx, path, schema, url, batch_size, force, add_new, no_strict_check, no_git
):  # noqa: F811
    """insert ActorPacks"""
    url = override_postgres_url(url)
    insert_actorpacks(
        url,
        schema,
        path,
        batch_size,
        force,
        add_new,
        no_strict_check,
        no_git,
        ctx.obj.get("config"),
    )


@actorpack.command("list")
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--category", default="", help="List Actors of a specific category")
@click.option("--csv", is_flag=True, help="Show csv output.")
def list_actorpack_cli(schema, url, category, csv):  # noqa: F811
    """list Actors"""
    url = override_postgres_url(url)
    list_actors(url, schema, category, csv)


@actorpack.command()
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "--network", default="", help="List addresses of a specific crypto-currency network"
)
@click.option("--csv", is_flag=True, help="Show csv output.")
def list_address_actor(schema, url, network, csv):
    """list addresses-actors"""
    url = override_postgres_url(url)
    list_address_actors(url, schema, network, csv)


def list_taxonomies(config):
    logger.info("Show configured taxonomies")
    count = 0
    if "taxonomies" not in config:
        logger.error("No configured taxonomies")
    else:
        for key, value in config["taxonomies"].items():
            logger.info(value)
            count += 1
        click.secho(f"{count} configured taxonomies", fg="green")


def show_taxonomy_concepts(config, taxonomy, tree, verbose):
    from anytree import RenderTree

    if "taxonomies" not in config:
        logger.error("No taxonomies configured")
        return

    print(f"Showing concepts of taxonomy {taxonomy}")
    uri = config["taxonomies"][taxonomy]
    print(f"URI: {uri}\n")
    taxonomy_obj = _load_taxonomy(config, taxonomy)
    if tree:
        for pre, fill, node in RenderTree(taxonomy_obj.get_concept_tree()):
            print("%s%s" % (pre, node.name))
    else:
        if verbose:
            headers = ["Id", "Label", "Level", "Uri", "Description"]
            table = [
                [c.id, c.label, c.level, c.uri, c.description]
                for c in taxonomy_obj.concepts
            ]
        elif taxonomy == "confidence":
            headers = ["Level", "Label"]
            table = [[c.level, c.label] for c in taxonomy_obj.concepts]
        else:
            headers = ["Id", "Label"]
            table = [[c.id, c.label] for c in taxonomy_obj.concepts]

        print(tabulate(table, headers=headers))
        print(f"{len(taxonomy_obj.concepts)} taxonomy concepts")


def insert_taxonomy():
    logger.error(
        "tagpack-tool taxonomy insert was"
        " retired in favor of tagstore init, please use this command"
    )
    sys.exit(1)


@cli.group("taxonomy")
@click.pass_context
def taxonomy(ctx):
    """taxonomy commands"""
    # Default behavior when no subcommand is provided
    if ctx.invoked_subcommand is None:
        config = _load_config(ctx.obj.get("config"))
        list_taxonomies(config)


@taxonomy.command("list")
@click.pass_context
def list_taxonomies_cli(ctx):  # noqa: F811
    """list taxonomy concepts"""
    config = _load_config(ctx.obj.get("config"))
    list_taxonomies(config)


@taxonomy.command()
@click.argument(
    "taxonomy_key",
    type=click.Choice(["abuse", "entity", "confidence", "country", "concept"]),
)
@click.option("-v", "--verbose", is_flag=True, help="verbose concepts")
@click.option("--tree", is_flag=True, help="Show as tree")
@click.pass_context
def show(ctx, taxonomy_key, verbose, tree):
    """show taxonomy concepts"""
    config = _load_config(ctx.obj.get("config"))
    show_taxonomy_concepts(config, taxonomy_key, tree, verbose)


@taxonomy.command("insert")
@click.argument(
    "taxonomy_key",
    type=click.Choice(["abuse", "entity", "confidence", "country", "concept"]),
    required=False,
)
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for taxonomy tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
def insert_taxonomy_cli(taxonomy_key, schema, url):  # noqa: F811
    """insert taxonomy into GraphSense"""
    insert_taxonomy()


def _split_into_chunks(seq, size):
    return (seq[pos : pos + size] for pos in range(0, len(seq), size))


def check_cluster_mapping_staleness(
    url,
    schema,
    db_nodes,
    cassandra_username,
    cassandra_password,
    ks_file,
    use_gs_lib_config_env,
    sample_size,
):
    """Sample mapped addresses per network, compare stored vs. current cluster_id.

    Each eligible network contributes up to `sample_size` rows, biased
    toward heavy-hitter clusters. A global limit would be dominated by
    BTC and hide drift on smaller chains.

    Returns (overall_divergence_rate, per_network_stats). Skips eth-like
    networks (ETH/TRX) — they have no real clustering, so cluster_id ==
    address_id and drift is not possible.
    """
    args = ClusterMappingArgs(
        url,
        schema,
        db_nodes,
        cassandra_username,
        cassandra_password,
        ks_file,
        use_gs_lib_config_env,
        update=False,
    )
    ks_mapping = load_ks_mapping(args)
    eligible_networks = [n for n in ks_mapping.keys() if not is_eth_like(n)]
    if not eligible_networks:
        return 0.0, {}

    tagstore = TagStore(url, schema)
    rows = tagstore.get_cluster_mapping_sample(sample_size, networks=eligible_networks)
    if not rows:
        return 0.0, {}

    sample = pd.DataFrame(rows, columns=["address", "network", "stored_cluster_id"])
    gs = GraphSense(
        args.db_nodes,
        ks_mapping,
        username=args.cassandra_username,
        password=args.cassandra_password,
    )

    per_network = {}
    total_checked = 0
    total_diverged = 0
    for network_key, batch in sample.groupby("network"):
        network = str(network_key)
        if not gs.keyspace_for_network_exists(network):
            logger.warning(f"Skipping staleness check for {network}: keyspace missing")
            continue
        current = gs.get_address_clusters(batch[["address"]].copy(), network)
        if current.empty:
            continue
        merged = batch.merge(
            current[["address", "cluster_id"]], on="address", how="inner"
        )
        if merged.empty:
            continue
        diverged = (merged["stored_cluster_id"] != merged["cluster_id"]).sum()
        checked = len(merged)
        per_network[network] = {
            "checked": int(checked),
            "diverged": int(diverged),
            "rate": float(diverged) / checked if checked else 0.0,
        }
        total_checked += checked
        total_diverged += int(diverged)

    overall = (total_diverged / total_checked) if total_checked else 0.0
    return overall, per_network


def insert_cluster_mapping_wp(network, ks_mapping, args, batch):
    tagstore = TagStore(args.url, args.schema)
    gs = GraphSense(
        args.db_nodes,
        ks_mapping,
        username=args.cassandra_username,
        password=args.cassandra_password,
    )
    if gs.keyspace_for_network_exists(network):
        clusters = gs.get_address_clusters(batch, network)
        clusters["network"] = network
        tagstore.insert_cluster_mappings(clusters)
    else:
        clusters = []
        logger.error(
            "At least one of the configured keyspaces"
            f" for network {network} does not exist."
        )
    return (network, len(clusters))


def load_ks_mapping(args):
    if args.use_gs_lib_config_env:
        gs_config_file = os.path.expanduser("~/.graphsense.yaml")
        if os.path.exists(gs_config_file):
            with open(gs_config_file) as f:
                yml = yaml.safe_load(f)
                if args.use_gs_lib_config_env in yml["environments"]:
                    env = yml["environments"][args.use_gs_lib_config_env]
                    args.db_nodes = env["cassandra_nodes"]
                    args.cassandra_password = env.get(
                        "readonly_password", None
                    ) or env.get("password", None)
                    args.cassandra_username = env.get(
                        "readonly_username", None
                    ) or env.get("username", None)
                    ret = {
                        k.upper(): {
                            "raw": v["raw_keyspace_name"],
                            "transformed": v["transformed_keyspace_name"],
                        }
                        for k, v in env["keyspaces"].items()
                    }
                    return ret
                else:
                    logger.error(
                        f"Environment {args.use_gs_lib_config_env} "
                        "not found in gs-config"
                    )
                    sys.exit(1)

        else:
            logger.error("Graphsense config not found at ~/.graphsense.yaml")
            sys.exit(1)
    else:
        if args.ks_file and os.path.exists(args.ks_file):
            return json.load(open(args.ks_file))
        else:
            logger.error(f"Keyspace config file not found at {args.ks_file}")
            sys.exit(1)


def init_db():
    logger.error(
        "tagpack-tool init was retired"
        " in favor of tagstore init, please use this command"
    )
    sys.exit(1)


def insert_cluster_mapping(
    url,
    schema,
    db_nodes,
    cassandra_username,
    cassandra_password,
    ks_file,
    use_gs_lib_config_env,
    update,
    batch_size=5_000,
):
    # Use the module-level class instead
    args = ClusterMappingArgs(
        url,
        schema,
        db_nodes,
        cassandra_username,
        cassandra_password,
        ks_file,
        use_gs_lib_config_env,
        update,
    )

    t0 = time.time()
    tagstore = TagStore(url, schema)
    df = pd.DataFrame(tagstore.get_addresses(update), columns=["address", "network"])
    ks_mapping = load_ks_mapping(args)
    logger.info("Importing with mapping config: ", ks_mapping)
    networks = ks_mapping.keys()
    gs = GraphSense(
        args.db_nodes,
        ks_mapping,
        username=args.cassandra_username,
        password=args.cassandra_password,
    )

    workpackages = []
    for network, data in df.groupby("network"):
        if gs.contains_keyspace_mapping(network):
            for batch in _split_into_chunks(data, batch_size):
                workpackages.append((network, ks_mapping, args, batch))

    nr_workers = int(cpu_count() / 2)
    logger.info(
        f"Processing {len(workpackages)} batches for "
        f"{len(networks)} networks on {nr_workers} workers."
    )

    with Pool(processes=nr_workers, maxtasksperchild=1) as pool:
        processed_workpackages = pool.starmap(insert_cluster_mapping_wp, workpackages)

    processed_networks = {network for network, _ in processed_workpackages}

    for pc in processed_networks:
        mappings_count = sum(
            [items for network, items in processed_workpackages if network == pc]
        )
        logger.info(f"INSERTED/UPDATED {mappings_count} {pc} cluster mappings")

    tagstore.finish_mappings_update(networks)
    duration = round(time.time() - t0, 2)
    logger.info(
        f"Inserted {'missing' if not update else 'all'} cluster mappings "
        f"for {processed_networks} in {duration}s"
    )


def update_db(url, schema):
    tagstore = TagStore(url, schema)
    tagstore.refresh_db()
    logger.info("All relevant views have been updated.")


def _remove_duplicates(url, schema):
    tagstore = TagStore(url, schema)
    rows_deleted = tagstore.remove_duplicates()
    msg = f"{rows_deleted} duplicate tags have been deleted from the database."
    logger.info(msg)


def show_tagstore_composition(url, schema, csv, by_network):
    tagstore = TagStore(url, schema)
    headers = (
        ["creator", "group", "network", "labels_count", "tags_count"]
        if by_network
        else ["creator", "group", "labels_count", "tags_count"]
    )
    df = pd.DataFrame(
        tagstore.get_tagstore_composition(by_network=by_network), columns=headers
    )

    if csv:
        print(df.to_csv(header=True, sep=",", index=True))
    else:
        with pd.option_context(
            "display.max_rows", None, "display.max_columns", None
        ):  # more options can be specified also
            print(tabulate(df, headers=headers, tablefmt="psql"))


def show_tagstore_source_repos(url, schema, csv):
    tagstore = TagStore(url, schema)

    res = tagstore.tagstore_source_repos()
    df = pd.DataFrame(res)
    if csv:
        print(df.to_csv(header=True, sep=",", index=True))
    else:
        print(
            tabulate(
                df,
                headers=df.columns,
                tablefmt="psql",
                maxcolwidths=[None, None, 10, 50],
            )
        )


@cli.group("tagstore")
def tagstore():  # noqa: F811
    """database housekeeping commands"""
    pass


@tagstore.command()
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for GraphSense cluster mapping table",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
def init(schema, url):
    """init the database"""
    init_db()


@tagstore.command()
@click.option(
    "-d",
    "--db-nodes",
    multiple=True,
    default=["localhost"],
    help='Cassandra node(s); default "localhost"',
)
@click.option("--cassandra-username", default=None, help="Cassandra Username")
@click.option("--cassandra-password", default=None, help="Cassandra password")
@click.option(
    "-f",
    "--ks-file",
    help="JSON file with Cassandra keyspaces that contain GraphSense cluster mappings",
)
@click.option(
    "--use-gs-lib-config-env",
    help="Load ks-mapping from global graphsense-lib config. Overrides --ks_file and --db_nodes",
)
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for GraphSense cluster mapping table",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--update", is_flag=True, help="update all cluster mappings")
@click.option(
    "--auto-rerun-if-stale",
    is_flag=True,
    help=(
        "Run a staleness check first; only do a full update if the divergence "
        "rate is at or above --staleness-threshold. Otherwise only newly-"
        "inserted addresses are mapped. Ignored if --update is also set."
    ),
)
@click.option(
    "--staleness-sample-size",
    type=int,
    default=2000,
    show_default=True,
    help=(
        "Sample size *per network* for --auto-rerun-if-stale. Each eligible "
        "(non-eth-like) network is sampled independently."
    ),
)
@click.option(
    "--staleness-threshold",
    type=float,
    default=0.05,
    show_default=True,
    help=(
        "Divergence rate (0.0-1.0) at or above which --auto-rerun-if-stale "
        "triggers a full update. Compared against the maximum per-network "
        "rate, so drift on any one chain is enough to trigger."
    ),
)
def insert_cluster_mappings(
    db_nodes,
    cassandra_username,
    cassandra_password,
    ks_file,
    use_gs_lib_config_env,
    schema,
    url,
    update,
    auto_rerun_if_stale,
    staleness_sample_size,
    staleness_threshold,
):
    """insert cluster mappings"""
    url = override_postgres_url(url)

    if auto_rerun_if_stale and not update:
        logger.info(
            f"Checking cluster mapping staleness "
            f"(sample={staleness_sample_size}, threshold={staleness_threshold:.2%})..."
        )
        overall, per_network = check_cluster_mapping_staleness(
            url=url,
            schema=schema,
            db_nodes=list(db_nodes),
            cassandra_username=cassandra_username,
            cassandra_password=cassandra_password,
            ks_file=ks_file,
            use_gs_lib_config_env=use_gs_lib_config_env,
            sample_size=staleness_sample_size,
        )
        for net, stats in per_network.items():
            logger.info(
                f"  {net}: {stats['diverged']}/{stats['checked']} "
                f"diverged ({stats['rate']:.2%})"
            )
        if per_network:
            max_net, max_stats = max(per_network.items(), key=lambda kv: kv[1]["rate"])
            max_rate = float(max_stats["rate"])
        else:
            max_net, max_rate = None, 0.0
        if max_rate >= staleness_threshold:
            logger.info(
                f"Max per-network divergence {max_rate:.2%} on '{max_net}' "
                f">= threshold {staleness_threshold:.2%} "
                f"(overall {overall:.2%}); running full update."
            )
            update = True
        else:
            logger.info(
                f"Max per-network divergence {max_rate:.2%} < threshold "
                f"{staleness_threshold:.2%} (overall {overall:.2%}); "
                "mapping new addresses only."
            )

    insert_cluster_mapping(
        url,
        schema,
        list(db_nodes),
        cassandra_username,
        cassandra_password,
        ks_file,
        use_gs_lib_config_env,
        update,
    )


@tagstore.command(name="check-cluster-mapping-staleness")
@click.option(
    "-d",
    "--db-nodes",
    multiple=True,
    default=["localhost"],
    help='Cassandra node(s); default "localhost"',
)
@click.option("--cassandra-username", default=None, help="Cassandra Username")
@click.option("--cassandra-password", default=None, help="Cassandra password")
@click.option(
    "-f",
    "--ks-file",
    help="JSON file with Cassandra keyspaces that contain GraphSense cluster mappings",
)
@click.option(
    "--use-gs-lib-config-env",
    help="Load ks-mapping from global graphsense-lib config. Overrides --ks-file and --db-nodes",
)
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for GraphSense cluster mapping table",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "--sample-size",
    type=int,
    default=2000,
    show_default=True,
    help="Number of mapped addresses to sample (biased toward large clusters).",
)
def check_cluster_mapping_staleness_cli(
    db_nodes,
    cassandra_username,
    cassandra_password,
    ks_file,
    use_gs_lib_config_env,
    schema,
    url,
    sample_size,
):
    """Compare stored vs. current cluster_id for a sample of mapped addresses; print divergence."""
    url = override_postgres_url(url)
    overall, per_network = check_cluster_mapping_staleness(
        url=url,
        schema=schema,
        db_nodes=list(db_nodes),
        cassandra_username=cassandra_username,
        cassandra_password=cassandra_password,
        ks_file=ks_file,
        use_gs_lib_config_env=use_gs_lib_config_env,
        sample_size=sample_size,
    )
    if not per_network:
        click.echo("No eligible addresses sampled (eth-like networks are skipped).")
        return
    rows = [
        [net, stats["checked"], stats["diverged"], f"{stats['rate']:.2%}"]
        for net, stats in sorted(per_network.items())
    ]
    click.echo(
        tabulate(
            rows,
            headers=["network", "checked", "diverged", "rate"],
            tablefmt="github",
        )
    )
    click.echo(f"\nOverall divergence: {overall:.2%}")


@tagstore.command()
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for GraphSense cluster mapping table",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
def refresh_views(schema, url):
    """update views"""
    url = override_postgres_url(url)
    update_db(url, schema)


@tagstore.command()
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for GraphSense cluster mapping table",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
def remove_duplicates(schema, url):
    """remove duplicate tags"""
    url = override_postgres_url(url)
    _remove_duplicates(url, schema)


@tagstore.command()
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--csv", is_flag=True, help="Show csv output.")
@click.option(
    "--by-network", is_flag=True, help="Include currency/network in statistic."
)
def show_composition(schema, url, csv, by_network):
    """Shows the tag composition grouped by creator and category."""
    url = override_postgres_url(url)
    show_tagstore_composition(url, schema, csv, by_network)


@tagstore.command()
@click.option(
    "--schema", default=DEFAULT_SCHEMA, help="PostgreSQL schema for tagpack tables"
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option("--csv", is_flag=True, help="Show csv output.")
def show_source_repos(schema, url, csv):
    """Shows which repos sources are stored in the database."""
    url = override_postgres_url(url)
    show_tagstore_source_repos(url, schema, csv)


def print_quality_measures(qm):
    if qm:
        print("Tag and Actor metrics:")
        tc = qm["tag_count"]
        tca = qm["tag_count_with_actors"]
        print(f"\t{'#Tags:':<35} {tc:10}")
        if tc > 0:
            print(f"\t{' with actors:':<35} {tca:10} ({(100 * tca) / tc:6.2f}%)")

        au = qm["nr_actors_used"]
        auj = qm["nr_actors_used_with_jurisdictions"]
        print(f"\n\t{'#Actors used:':<35} {au:10}")
        if au > 0:
            print(f"\t{' with jurisdictions:':<35} {auj:10} ({(100 * auj) / au:6.2f}%)")

        au_ex = qm["nr_actors_used_exchange"]
        auj_ex = qm["nr_actors_used_with_jurisdictions_exchange"]
        print(f"\n\t{'#Exchange-Actors used:':<35} {au_ex:10}")
        if au_ex > 0:
            print(
                f"\t{' with jurisdictions:':<35} "
                f"{auj_ex:10} ({(100 * auj_ex) / au_ex:6.2f}%)"
            )

        print("Tag Quality Statistics:")
        print(f"\t{'Quality COUNT:':<35} {qm['count']:10}")
        print(f"\t{'Quality AVG:':<35}    {qm['avg']:7.2f}")
        print(f"\t{'Quality STDDEV:':<35}    {qm['stddev']:7.2f}")
    else:
        print("\tNone")


def show_quality_measures(url, schema, network):
    logger.info("Show quality measures")
    tagstore = TagStore(url, schema)

    try:
        qm = tagstore.get_quality_measures(network)
        c = network if network else "Global"
        print(f"{c} quality measures:")
        print_quality_measures(qm)

    except Exception as e:
        logger.error(f"Error: {e}")
        logger.error("Operation failed")


def calc_quality_measures(url, schema):
    t0 = time.time()
    logger.info("Calculate quality measures starts")

    tagstore = TagStore(url, schema)

    try:
        qm = tagstore.calculate_quality_measures()
        print("Global quality measures:")
        print_quality_measures(qm)

        duration = round(time.time() - t0, 2)
        logger.info(f"Done in {duration}s")
    except Exception as e:
        logger.error(f"Error: {e}")
        logger.error("Operation failed")


def low_quality_addresses(url, schema, threshold, network, category, csv, cluster):
    if not csv:
        print("Addresses with low quality")
    tagstore = TagStore(url, schema)

    try:
        th, curr, cat = threshold, network, category
        la = tagstore.low_quality_address_labels(th, curr, cat)
        if la:
            if not csv:
                c = network if network else "all"
                print(f"List of {c} addresses and labels ({len(la)}):")
            else:
                print("network,address,labels")

            intersections = []
            for (network_key, address), labels in la.items():
                if csv:
                    labels_str = "|".join(labels)
                    print(f"{network_key},{address},{labels_str}")
                else:
                    print(f"\t{network_key}\t{address}\t{labels}")

                if not cluster:
                    continue

                # Produce clusters of addresses based on tag intersections
                seen = set()
                for i, (e, n) in enumerate(intersections):
                    seen = e.intersection(labels)
                    if seen:
                        e.update(labels)
                        n += 1
                        intersections[i] = (e, n)
                        break
                if not seen:
                    intersections.append((set(labels), 1))

            if cluster:
                print("\nSets of tags appearing in several addresses:")
                s_int = sorted(intersections, key=lambda x: x[1], reverse=True)
                for k, v in s_int:
                    if v > 1:
                        print(f"\t{v}: {', '.join(k)}")
        else:
            if not csv:
                print("\tNone")

    except Exception as e:
        logger.error(f"Error: {e}")
        logger.error("Operation failed")


def list_low_quality_actors(url, schema, category, max_results, not_used, csv):
    tagstore = TagStore(url, schema)

    res = tagstore.get_actors_with_jurisdictions(
        category=category, max_results=max_results, include_not_used=not_used
    )
    df = pd.DataFrame(res)
    if csv:
        print(df.to_csv(header=True, sep=",", index=True))
    else:
        print("Actors without Jurisdictions")
        print(
            tabulate(
                df,
                headers=df.columns,
                tablefmt="psql",
                maxcolwidths=[None, None, 10, 10, 60, 10],
            )
        )


def list_top_labels_without_actor(url, schema, category, max_results, csv):
    tagstore = TagStore(url, schema)

    res = tagstore.top_labels_without_actor(category=category, max_results=max_results)
    df = pd.DataFrame(res)
    if csv:
        print(df.to_csv(header=True, sep=",", index=True))
    else:
        print("Top labels without actor")
        print(
            tabulate(
                df,
                headers=df.columns,
                tablefmt="psql",
                maxcolwidths=[None, None, 10, 50],
            )
        )


def list_addresses_with_actor_collisions_impl(url, schema, csv):
    tagstore = TagStore(url, schema)

    res = tagstore.addresses_with_actor_collisions()
    df = pd.DataFrame(res)
    if csv:
        print(df.to_csv(header=True, sep=",", index=True))
    else:
        print("Addresses with actor collisions")
        print(
            tabulate(
                df,
                headers=df.columns,
                tablefmt="psql",
                maxcolwidths=[None, None, 10, 50],
            )
        )


@cli.group("quality")
@click.option(
    "--schema",
    default=DEFAULT_SCHEMA,
    help="PostgreSQL schema for quality measures tables",
)
@click.option("-u", "--url", help="postgresql://user:password@db_host:port/database")
@click.option(
    "--network",
    default="",
    help="Show the avg quality measure for a specific crypto-currency network",
)
@click.pass_context
def quality(ctx, schema, url, network):
    """calculate tags quality measures"""
    ctx.ensure_object(dict)
    url = override_postgres_url(url)

    ctx.obj["url"] = url
    ctx.obj["schema"] = schema
    ctx.obj["network"] = network

    # Default behavior when no subcommand is provided
    if ctx.invoked_subcommand is None:
        show_quality_measures(url, schema, network)


@quality.command("calculate")
@click.pass_context
def calculate_quality(ctx):
    """calculate quality measures for all tags in the DB"""
    calc_quality_measures(ctx.obj["url"], ctx.obj["schema"])


@quality.command()
@click.pass_context
def show(ctx):  # noqa: F811
    """show average quality measures"""
    show_quality_measures(ctx.obj["url"], ctx.obj["schema"], ctx.obj["network"])


@quality.command()
@click.option("--category", default="", help="List addresses of a specific category")
@click.option(
    "--network",
    default="",
    help="Show low quality addresses of a specific crypto-currency network",
)
@click.option(
    "--threshold",
    type=float,
    default=0.25,
    help="List addresses having a quality lower than this threshold",
)
@click.option(
    "-c",
    "--cluster",
    is_flag=True,
    help="Cluster addresses having intersections of similar tags",
)
@click.option("--csv", is_flag=True, help="Show csv output.")
@click.pass_context
def list_addresses_with_low_quality(ctx, category, network, threshold, cluster, csv):
    """list low quality addresses"""
    low_quality_addresses(
        ctx.obj["url"], ctx.obj["schema"], threshold, network, category, csv, cluster
    )


@quality.command()
@click.option("--category", default="", help="List actors of a specific category")
@click.option("--max", type=int, default=5, help="Limits the number of results")
@click.option(
    "--not-used", is_flag=True, help="Include actors that are not used in tags."
)
@click.option("--csv", is_flag=True, help="Show csv output.")
@click.pass_context
def list_actors_without_jur(ctx, category, max, not_used, csv):
    """actors without jurisdictions."""
    list_low_quality_actors(
        ctx.obj["url"], ctx.obj["schema"], category, max, not_used, csv
    )


@quality.command()
@click.option("--category", default="", help="List actors of a specific category")
@click.option("--max", type=int, default=5, help="Limits the number of results")
@click.option("--csv", is_flag=True, help="Show csv output.")
@click.pass_context
def list_labels_without_actor(ctx, category, max, csv):
    """List the top labels used in tags without actors."""
    list_top_labels_without_actor(ctx.obj["url"], ctx.obj["schema"], category, max, csv)


@quality.command()
@click.option("--csv", is_flag=True, help="Show csv output.")
@click.pass_context
def list_addresses_with_actor_collisions(ctx, csv):
    """List actors with address collisions."""
    list_addresses_with_actor_collisions_impl(ctx.obj["url"], ctx.obj["schema"], csv)


def main():
    """Main entry point for the tagpacktool_cli."""
    def_url, url_msg = read_url_from_env()

    if len(sys.argv) == 1:
        ctx = click.Context(cli)
        click.echo(cli.get_help(ctx))
        sys.exit(1)

    try:
        cli()
    except click.ClickException as e:
        if hasattr(e, "message") and "No postgresql URL" in str(e.message):
            logger.warning(
                "Missing required PostgreSQL environment variables for URL construction."
            )
        e.show()
        sys.exit(1)


if __name__ == "__main__":
    main()
