# LangChain Tool - NEAR update key

Build a LangChain tool to update keys on NEAR.

**Deliverables:**
1. LangChain BaseTool implementation
2. Async support
3. Type hints
4. Published to PyPI

**Success Metric:** 15+ downloads

---
**🔥 A

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `NEARUpdateKeyTool` — see near_tool.py
- `NEARListAccessKeysTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, NEARUpdateKeyTool, NEARListAccessKeysTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
