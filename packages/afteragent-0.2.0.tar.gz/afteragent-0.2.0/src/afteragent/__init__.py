"""AfterAgent package."""
