"""Typed exception hierarchy so callers can switch on error kind.

    try:
        client.call(...)
    except DNCBlockedError:
        # don't retry — number is on a suppression list
        ...
    except RateLimitError as e:
        # honor Retry-After
        time.sleep(e.retry_after_seconds or 30)
        ...
    except OpenPhnError as e:
        # anything else
        ...

Every subclass is an `OpenPhnError`, so a single broad except still works.
"""

from __future__ import annotations

from typing import Any


class OpenPhnError(Exception):
    """Base OpenPhn exception. Has `status_code`, `message`, and optional `error_code`.

    `error_code` is the `error` field in the JSON response body (stable
    machine-readable string — `"dnc_blocked"`, `"rate_limited"`, etc.),
    when present. Safe to switch on.
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        error_code: str | None = None,
        body: dict[str, Any] | None = None,
    ):
        super().__init__(f"{status_code}: {message}")
        self.status_code = status_code
        self.message = message
        self.error_code = error_code
        self.body = body or {}


class AuthenticationError(OpenPhnError):
    """401. Your key is missing, malformed, revoked, or expired past the
    rotation grace window. Don't retry; fix the key."""


class PermissionError(OpenPhnError):  # noqa: A001 — shadowing builtin intentionally here
    """403. Your key is valid but lacks the scope, is pinned to a different
    `number_id`, or your account is still `pending_review`. Don't retry."""


class NotFoundError(OpenPhnError):
    """404. Resource doesn't exist or doesn't belong to your tenant."""


class ConflictError(OpenPhnError):
    """409. Most often: reused an Idempotency-Key with a different body.
    The fix is to use a fresh key or not mutate the body."""


class ValidationError(OpenPhnError):
    """422. Request was well-formed but semantically invalid — bad E.164,
    invalid `outcome_schema`, objective too long, etc."""


class RateLimitError(OpenPhnError):
    """429. Slow down. `retry_after_seconds` is the `Retry-After` header
    if the server sent one."""

    def __init__(
        self,
        status_code: int,
        message: str,
        retry_after_seconds: int | None = None,
        error_code: str | None = None,
        body: dict[str, Any] | None = None,
    ):
        super().__init__(status_code, message, error_code=error_code, body=body)
        self.retry_after_seconds = retry_after_seconds


class ServerError(OpenPhnError):
    """5xx. Transient server error. Safe to retry with the same
    Idempotency-Key for idempotent endpoints."""


class DNCBlockedError(PermissionError):
    """403 + `error: "dnc_blocked"`. The destination is on a suppression list
    — either the platform-wide global list or your tenant's DNC.

    Don't retry. Don't add the number back to your DNC upload tomorrow unless
    you've re-confirmed consent.
    """


class ConsentError(ValidationError):
    """422 + consent-related `error` code. `consent_type` missing, invalid,
    or doesn't match the route (e.g. `emergency` on a marketing call)."""


class VerificationPendingError(PermissionError):
    """403 + `error: "verification_pending"`. Your account still needs admin
    approval before it can place calls. Check the dashboard or email ops."""
