"""TypedDict shapes for the common response objects.

These are intentionally NOT pydantic models — we don't want to force pydantic
as a runtime dep on every SDK consumer. TypedDicts give editors + mypy full
completion without adding a validation pass on each response.

If you want pydantic-backed parsing, do it in your own code:

    from pydantic import TypeAdapter
    from openphn.types import Call
    call = TypeAdapter(Call).validate_python(client.get_call("cll_..."))

Fields are `NotRequired` where the backend may omit them (e.g. in-flight
calls don't have `outcome` yet).
"""

from __future__ import annotations

import sys
from typing import Any

# NotRequired landed in typing on 3.11; fall through to typing_extensions
# for 3.10. The SDK's pyproject pins >=3.10.
if sys.version_info >= (3, 11):
    from typing import NotRequired, TypedDict
else:  # pragma: no cover - 3.10 fallback
    from typing_extensions import NotRequired, TypedDict


# ---- Calls ---------------------------------------------------------------


class CallOutcomeField(TypedDict, total=False):
    type: str  # "boolean" | "string" | "number" | "datetime" | "enum"
    optional: NotRequired[bool]
    values: NotRequired[list[str]]  # only for enum


CallOutcomeSchema = dict[str, CallOutcomeField]
"""The shape of `outcome_schema` on `POST /v1/calls`."""


class CallCreated(TypedDict):
    """Response from `POST /v1/calls` / `POST /v1/calls/batch`. The outcome
    is not populated yet — poll `get_call()` or register a webhook."""

    call_id: str
    status: str  # "requested" | "scheduled" | ...


class CallCosts(TypedDict, total=False):
    voice_engine: NotRequired[float | None]
    extraction: NotRequired[float | None]
    platform: NotRequired[float | None]
    total: NotRequired[float | None]


class Call(TypedDict, total=False):
    """The full call row returned from `GET /v1/calls/{id}` once the call has
    finalized. Many fields are None until the pipeline reaches them."""

    id: str
    status: str
    direction: str
    to: str
    from_: NotRequired[str]  # `from` is a reserved word; renamed at client layer
    objective: NotRequired[str]
    outcome_schema: NotRequired[CallOutcomeSchema]
    outcome: NotRequired[dict[str, Any]]
    confidence: NotRequired[float]
    field_confidence: NotRequired[dict[str, float]]
    missing_fields: NotRequired[list[str]]
    ambiguity_notes: NotRequired[str]
    recommended_action: NotRequired[str]
    transcript: NotRequired[list[dict[str, Any]]]
    cost: NotRequired[CallCosts]
    duration_seconds: NotRequired[int]
    first_audio_ms: NotRequired[int]
    turn_latency_p50_ms: NotRequired[int]
    turn_latency_p95_ms: NotRequired[int]
    turn_latency_p99_ms: NotRequired[int]
    turn_latency_sample_count: NotRequired[int]
    error_code: NotRequired[str]
    error_detail: NotRequired[str]
    recording_url: NotRequired[str]
    recording_duration: NotRequired[int]
    created_at: NotRequired[str]


# ---- Webhooks ------------------------------------------------------------


class WebhookCreated(TypedDict):
    """Response from `POST /v1/webhooks`. `secret` is shown ONCE — save it."""

    id: str
    url: str
    secret: str
    description: NotRequired[str]
    active: bool


class WebhookDelivery(TypedDict, total=False):
    id: str
    webhook_id: str
    attempt: int
    status_code: int | None
    response_body: str | None
    latency_ms: int | None
    delivered_at: str | None
    created_at: str


# ---- Numbers -------------------------------------------------------------


class TransferDestination(TypedDict):
    label: str
    phone: str
    enabled: bool
    order: int
    max_attempts: NotRequired[int]


class NumberConfig(TypedDict, total=False):
    id: str
    e164: str
    greeting_text: NotRequired[str]
    greeting_voice_id: NotRequired[str]
    transfer_destinations: NotRequired[list[TransferDestination]]
    flow_id: NotRequired[str]
    recording_enabled: NotRequired[bool]


# ---- DNC -----------------------------------------------------------------


class DNCEntry(TypedDict, total=False):
    id: str
    e164: str
    source: str  # "upload" | "manual" | "api"
    created_at: str


class DNCUploadResult(TypedDict):
    added_count: int
    skipped_count: NotRequired[int]
    invalid_count: NotRequired[int]


# ---- Voices --------------------------------------------------------------


class Voice(TypedDict, total=False):
    id: str
    provider: str  # "gemini" | "elevenlabs" | "google_tts"
    display_name: str
    gender: NotRequired[str]
    language: NotRequired[str]
    preview_url: NotRequired[str]


# ---- Analytics summary ---------------------------------------------------


class AnalyticsSummary(TypedDict, total=False):
    total_calls: int
    delivered_count: int
    success_rate: float
    avg_duration_seconds: float | None
    total_cost: float
    voicemail_count: int
    voicemail_rate: float
    greeting_latency_p50_ms: int | None
    sms_sends_total: NotRequired[int]
    sms_delivery_rate: NotRequired[float]


# ---- Auth ---------------------------------------------------------------


class Me(TypedDict, total=False):
    user_id: str
    email: str
    tenant_id: NotRequired[str]
    verification_status: str
    is_admin: bool
    scopes: NotRequired[list[str]]
    number_ids: NotRequired[list[str]]
