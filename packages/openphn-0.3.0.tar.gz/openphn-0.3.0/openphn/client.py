"""OpenPhn SDK — sync + async HTTP clients for api.openphn.com.

Full REST reference: https://api.openphn.com/docs
Conceptual docs:     https://docs.openphn.com

Design notes:
- TypedDict return types (see openphn.types). No runtime pydantic dep.
- Typed exceptions (see openphn.exceptions) — switch on error kind.
- Optional auto-retry on 429 and 5xx with exponential backoff + jitter.
- `call()` helper optionally polls until terminal state — set `wait=False`
  for fire-and-forget if you have a webhook wired.
"""

from __future__ import annotations

import asyncio
import random
import time
from pathlib import Path
from typing import Any, Iterator

import httpx

from openphn.exceptions import (
    AuthenticationError,
    ConflictError,
    ConsentError,
    DNCBlockedError,
    NotFoundError,
    OpenPhnError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
    VerificationPendingError,
)
from openphn.types import (
    AnalyticsSummary,
    Call,
    CallCreated,
    CallOutcomeSchema,
    DNCUploadResult,
    Me,
    NumberConfig,
    Voice,
    WebhookCreated,
    WebhookDelivery,
)

DEFAULT_BASE_URL = "https://api.openphn.com"
DEFAULT_POLL_INTERVAL = 2.0
DEFAULT_WAIT_TIMEOUT = 300.0
DEFAULT_HTTP_TIMEOUT = 30.0
TERMINAL_STATUSES = frozenset({"delivered", "error", "ended", "failed"})

# Keep in sync with pyproject.toml + openphn/__init__.py.
_VERSION = "0.3.0"


def _map_error(resp: httpx.Response) -> OpenPhnError:
    """Translate a non-2xx response into the most specific exception type.

    The backend returns JSON like `{"error": "dnc_blocked", "message": "..."}`
    (see docs.openphn.com/docs/api/errors). We inspect both `status_code` and
    the stable `error` code to pick the class.
    """
    try:
        body = resp.json()
    except Exception:
        body = None

    if isinstance(body, dict):
        message = body.get("message") or body.get("detail") or resp.text
        error_code = body.get("error")
    else:
        message = resp.text
        error_code = None

    status = resp.status_code
    parsed_body = body if isinstance(body, dict) else None

    # 403s with a known error code → the specific subclass
    if status == 403 and error_code == "dnc_blocked":
        return DNCBlockedError(status, message, error_code=error_code, body=parsed_body)
    if status == 403 and error_code == "verification_pending":
        return VerificationPendingError(status, message, error_code=error_code, body=parsed_body)
    if status == 403:
        return PermissionError(status, message, error_code=error_code, body=parsed_body)

    if status == 401:
        return AuthenticationError(status, message, error_code=error_code, body=parsed_body)
    if status == 404:
        return NotFoundError(status, message, error_code=error_code, body=parsed_body)
    if status == 409:
        return ConflictError(status, message, error_code=error_code, body=parsed_body)
    if status == 422:
        if error_code and "consent" in error_code:
            return ConsentError(status, message, error_code=error_code, body=parsed_body)
        return ValidationError(status, message, error_code=error_code, body=parsed_body)
    if status == 429:
        retry_after = resp.headers.get("retry-after")
        return RateLimitError(
            status,
            message,
            retry_after_seconds=int(retry_after) if retry_after and retry_after.isdigit() else None,
            error_code=error_code,
            body=parsed_body,
        )
    if 500 <= status < 600:
        return ServerError(status, message, error_code=error_code, body=parsed_body)
    return OpenPhnError(status, message, error_code=error_code, body=parsed_body)


def _raise_for_status(resp: httpx.Response) -> None:
    if resp.is_success:
        return
    raise _map_error(resp)


def _retry_delay(attempt: int, retry_after: int | None) -> float:
    """Exponential backoff with jitter. Honors `Retry-After` when present.

    attempt is 1-indexed: 1 → ~0.5s, 2 → ~1s, 3 → ~2s, 4 → ~4s (± 25% jitter).
    """
    if retry_after is not None:
        return float(retry_after)
    base = 0.25 * (2 ** attempt)
    jitter = base * (0.75 + random.random() * 0.5)
    return min(jitter, 30.0)


# ─── Async client ─────────────────────────────────────────────────────────


class AsyncOpenPhn:
    """Async OpenPhn client.

    Usage:

        async with AsyncOpenPhn(api_key="sk_live_...") as client:
            r = await client.call(
                to="+14155551234",
                objective="Confirm order A-14421 ships today",
                outcome_schema={
                    "will_ship_today": {"type": "boolean"},
                    "tracking": {"type": "string", "optional": True},
                },
                consent_type="existing_business_relationship",
            )
            print(r["outcome"])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_HTTP_TIMEOUT,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_retries = max(0, max_retries)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"openphn-python/{_VERSION}",
            },
            timeout=timeout,
        )

    async def __aenter__(self) -> "AsyncOpenPhn":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    # ---- Core request with retry -----------------------------------------

    async def _request(
        self,
        method: str,
        url: str,
        *,
        retriable: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        """Execute a request with retry on 429 + 5xx. Non-idempotent POSTs
        opt in via retriable=True (e.g. when the caller passed an
        Idempotency-Key)."""
        last_error: OpenPhnError | None = None
        for attempt in range(1, self.max_retries + 2):
            resp = await self._client.request(method, url, **kwargs)
            if resp.is_success:
                return resp
            err = _map_error(resp)
            if not retriable or not isinstance(err, (RateLimitError, ServerError)):
                raise err
            last_error = err
            if attempt > self.max_retries:
                raise err
            delay = _retry_delay(
                attempt,
                err.retry_after_seconds if isinstance(err, RateLimitError) else None,
            )
            await asyncio.sleep(delay)
        raise last_error or OpenPhnError(500, "retry loop exited without response")

    # ---- Calls -----------------------------------------------------------

    async def call(
        self,
        to: str,
        objective: str,
        outcome_schema: CallOutcomeSchema,
        consent_type: str,
        *,
        context: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        voice_engine: str = "gemini_25",
        language: str = "en-US",
        voice_id: str | None = None,
        from_number: str | None = None,
        idempotency_key: str | None = None,
        wait: bool = True,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        wait_timeout: float = DEFAULT_WAIT_TIMEOUT,
    ) -> Call | CallCreated:
        """Place a call. If `wait=True`, polls `get_call()` until the status
        is terminal (delivered/error/ended/failed) or `wait_timeout` elapses.

        With `wait=False` returns as soon as the server accepts the request,
        giving you a `{call_id, status}` you can pair with a webhook.
        """
        body: dict[str, Any] = {
            "to": to,
            "objective": objective,
            "outcome_schema": outcome_schema,
            "consent_type": consent_type,
            "voice_engine": voice_engine,
            "language": language,
        }
        for k, v in (
            ("context", context),
            ("tools", tools),
            ("voice_id", voice_id),
            ("from_number", from_number),
            ("idempotency_key", idempotency_key),
        ):
            if v is not None:
                body[k] = v

        retriable = idempotency_key is not None
        resp = await self._request("POST", "/v1/calls", json=body, retriable=retriable)
        created: CallCreated = resp.json()

        if not wait:
            return created

        call_id = created["call_id"]
        deadline = time.time() + wait_timeout
        while time.time() < deadline:
            await asyncio.sleep(poll_interval)
            state = await self.get_call(call_id)
            if state.get("status") in TERMINAL_STATUSES:
                return state
        return await self.get_call(call_id)

    async def create_batch(
        self,
        items: list[dict[str, Any]],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        """Batch-create up to 200 calls. Each `items[i]` is the same shape as
        `call()` kwargs. Per-item DNC / call-hours validation still applies —
        invalid items return with their own error field."""
        body: dict[str, Any] = {"items": items}
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        resp = await self._request(
            "POST",
            "/v1/calls/batch",
            json=body,
            retriable=idempotency_key is not None,
        )
        return resp.json()

    async def get_call(self, call_id: str) -> Call:
        resp = await self._request("GET", f"/v1/calls/{call_id}")
        return resp.json()

    async def list_calls(
        self,
        *,
        status: str | None = None,
        limit: int = 25,
        offset: int = 0,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        resp = await self._request("GET", "/v1/calls", params=params)
        return resp.json()

    def iter_calls(
        self,
        *,
        status: str | None = None,
        page_size: int = 100,
    ) -> "AsyncIteratorCalls":
        """Async iterator over every call matching the filter. Transparently pages."""
        return AsyncIteratorCalls(self, status=status, page_size=page_size)

    async def export_calls_csv(self) -> bytes:
        """Stream the tenant's calls as CSV. Returns raw bytes."""
        resp = await self._request("GET", "/v1/calls/export.csv")
        return resp.content

    # ---- Webhooks --------------------------------------------------------

    async def create_webhook(
        self,
        url: str,
        *,
        description: str | None = None,
    ) -> WebhookCreated:
        body: dict[str, Any] = {"url": url}
        if description is not None:
            body["description"] = description
        resp = await self._request("POST", "/v1/webhooks", json=body, retriable=False)
        return resp.json()

    async def list_webhooks(self) -> dict[str, Any]:
        resp = await self._request("GET", "/v1/webhooks")
        return resp.json()

    async def delete_webhook(self, webhook_id: str) -> dict[str, Any]:
        resp = await self._request("DELETE", f"/v1/webhooks/{webhook_id}", retriable=False)
        return resp.json()

    async def list_webhook_deliveries(
        self,
        webhook_id: str,
        *,
        limit: int = 50,
    ) -> list[WebhookDelivery]:
        resp = await self._request(
            "GET",
            f"/v1/webhooks/{webhook_id}/deliveries",
            params={"limit": limit},
        )
        return resp.json()

    async def retry_webhook_delivery(
        self,
        webhook_id: str,
        delivery_id: str,
    ) -> dict[str, Any]:
        resp = await self._request(
            "POST",
            f"/v1/webhooks/{webhook_id}/deliveries/{delivery_id}/retry",
            retriable=False,
        )
        return resp.json()

    # ---- Numbers ---------------------------------------------------------

    async def list_numbers(self) -> list[NumberConfig]:
        resp = await self._request("GET", "/v1/numbers")
        return resp.json()

    async def update_number(
        self,
        number_id: str,
        **fields: Any,
    ) -> NumberConfig:
        """PATCH a number. Pass any subset of `greeting_text`,
        `transfer_destinations`, `flow_id`, `recording_enabled`, etc."""
        resp = await self._request(
            "PATCH", f"/v1/numbers/{number_id}", json=fields, retriable=False
        )
        return resp.json()

    # ---- DNC -------------------------------------------------------------

    async def upload_dnc(self, csv_path: str | Path) -> DNCUploadResult:
        """Upload a CSV of phone numbers to the tenant's DNC list. Up to 10k
        rows per request. Numbers are normalized to E.164 (NANP only) and
        deduped against existing entries."""
        path = Path(csv_path)
        with path.open("rb") as fh:
            files = {"file": (path.name, fh, "text/csv")}
            resp = await self._request(
                "POST",
                "/v1/dnc/upload",
                files=files,
                retriable=False,
            )
        return resp.json()

    async def list_dnc(
        self, *, limit: int = 100, offset: int = 0
    ) -> dict[str, Any]:
        resp = await self._request(
            "GET", "/v1/dnc", params={"limit": limit, "offset": offset}
        )
        return resp.json()

    async def delete_dnc_entry(self, entry_id: str) -> dict[str, Any]:
        resp = await self._request(
            "DELETE", f"/v1/dnc/{entry_id}", retriable=False
        )
        return resp.json()

    # ---- Voices ----------------------------------------------------------

    async def list_voices(self) -> list[Voice]:
        resp = await self._request("GET", "/v1/voices")
        return resp.json()

    # ---- Providers (BYO Twilio) ------------------------------------------

    async def verify_twilio(
        self,
        account_sid: str,
        auth_token: str,
    ) -> dict[str, Any]:
        """Validate a Twilio subaccount's credentials and list its numbers.
        Credentials are encrypted at rest server-side."""
        resp = await self._request(
            "POST",
            "/v1/providers/twilio/verify",
            json={"account_sid": account_sid, "auth_token": auth_token},
            retriable=False,
        )
        return resp.json()

    async def select_number(self, e164: str) -> dict[str, Any]:
        resp = await self._request(
            "POST",
            "/v1/providers/numbers/select",
            json={"e164": e164},
            retriable=False,
        )
        return resp.json()

    # ---- Analytics -------------------------------------------------------

    async def analytics_summary(
        self,
        *,
        range: str = "30d",
        direction: str = "all",
    ) -> AnalyticsSummary:
        resp = await self._request(
            "GET",
            "/v1/analytics/summary",
            params={"range": range, "direction": direction},
        )
        return resp.json()

    # ---- Auth ------------------------------------------------------------

    async def me(self) -> Me:
        """Sanity-check the API key + surface scopes / number_ids / verification_status."""
        resp = await self._request("GET", "/auth/me")
        return resp.json()

    async def close(self) -> None:
        await self._client.aclose()

    # ---- Legacy pass-through (kept for 0.2.0 callers) --------------------

    async def add_suppression(
        self, phone_numbers: list[str], reason: str | None = None
    ) -> dict[str, Any]:
        """Legacy alias. Prefer `upload_dnc(csv_path)` for >1 number."""
        resp = await self._request(
            "POST",
            "/v1/suppression",
            json={"phone_numbers": phone_numbers, "reason": reason},
            retriable=False,
        )
        return resp.json()

    async def list_suppression(self) -> dict[str, Any]:
        resp = await self._request("GET", "/v1/suppression")
        return resp.json()


class AsyncIteratorCalls:
    """Async iterator that pages through list_calls transparently."""

    def __init__(
        self,
        client: AsyncOpenPhn,
        *,
        status: str | None,
        page_size: int,
    ) -> None:
        self._client = client
        self._status = status
        self._page_size = page_size
        self._offset = 0
        self._buffer: list[dict[str, Any]] = []
        self._done = False

    def __aiter__(self) -> "AsyncIteratorCalls":
        return self

    async def __anext__(self) -> dict[str, Any]:
        if not self._buffer and not self._done:
            page = await self._client.list_calls(
                status=self._status, limit=self._page_size, offset=self._offset
            )
            calls = page.get("calls") or page.get("items") or []
            self._buffer = list(calls)
            self._offset += len(calls)
            if len(calls) < self._page_size:
                self._done = True
        if not self._buffer:
            raise StopAsyncIteration
        return self._buffer.pop(0)


# ─── Sync client ──────────────────────────────────────────────────────────


class OpenPhn:
    """Sync OpenPhn client. Same shape as AsyncOpenPhn minus async/await."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_HTTP_TIMEOUT,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_retries = max(0, max_retries)
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"openphn-python/{_VERSION}",
            },
            timeout=timeout,
        )

    def __enter__(self) -> "OpenPhn":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(
        self,
        method: str,
        url: str,
        *,
        retriable: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        last_error: OpenPhnError | None = None
        for attempt in range(1, self.max_retries + 2):
            resp = self._client.request(method, url, **kwargs)
            if resp.is_success:
                return resp
            err = _map_error(resp)
            if not retriable or not isinstance(err, (RateLimitError, ServerError)):
                raise err
            last_error = err
            if attempt > self.max_retries:
                raise err
            delay = _retry_delay(
                attempt,
                err.retry_after_seconds if isinstance(err, RateLimitError) else None,
            )
            time.sleep(delay)
        raise last_error or OpenPhnError(500, "retry loop exited without response")

    # ---- Calls -----------------------------------------------------------

    def call(
        self,
        to: str,
        objective: str,
        outcome_schema: CallOutcomeSchema,
        consent_type: str,
        *,
        context: str | None = None,
        tools: list[dict[str, Any]] | None = None,
        voice_engine: str = "gemini_25",
        language: str = "en-US",
        voice_id: str | None = None,
        from_number: str | None = None,
        idempotency_key: str | None = None,
        wait: bool = True,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        wait_timeout: float = DEFAULT_WAIT_TIMEOUT,
    ) -> Call | CallCreated:
        body: dict[str, Any] = {
            "to": to,
            "objective": objective,
            "outcome_schema": outcome_schema,
            "consent_type": consent_type,
            "voice_engine": voice_engine,
            "language": language,
        }
        for k, v in (
            ("context", context),
            ("tools", tools),
            ("voice_id", voice_id),
            ("from_number", from_number),
            ("idempotency_key", idempotency_key),
        ):
            if v is not None:
                body[k] = v

        retriable = idempotency_key is not None
        resp = self._request("POST", "/v1/calls", json=body, retriable=retriable)
        created: CallCreated = resp.json()

        if not wait:
            return created

        call_id = created["call_id"]
        deadline = time.time() + wait_timeout
        while time.time() < deadline:
            time.sleep(poll_interval)
            state = self.get_call(call_id)
            if state.get("status") in TERMINAL_STATUSES:
                return state
        return self.get_call(call_id)

    def create_batch(
        self,
        items: list[dict[str, Any]],
        *,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"items": items}
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        resp = self._request(
            "POST",
            "/v1/calls/batch",
            json=body,
            retriable=idempotency_key is not None,
        )
        return resp.json()

    def get_call(self, call_id: str) -> Call:
        resp = self._request("GET", f"/v1/calls/{call_id}")
        return resp.json()

    def list_calls(
        self,
        *,
        status: str | None = None,
        limit: int = 25,
        offset: int = 0,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        resp = self._request("GET", "/v1/calls", params=params)
        return resp.json()

    def iter_calls(
        self,
        *,
        status: str | None = None,
        page_size: int = 100,
    ) -> Iterator[dict[str, Any]]:
        """Generator that pages through list_calls, yielding individual rows."""
        offset = 0
        while True:
            page = self.list_calls(status=status, limit=page_size, offset=offset)
            calls = page.get("calls") or page.get("items") or []
            if not calls:
                return
            for c in calls:
                yield c
            if len(calls) < page_size:
                return
            offset += len(calls)

    def export_calls_csv(self) -> bytes:
        resp = self._request("GET", "/v1/calls/export.csv")
        return resp.content

    # ---- Webhooks --------------------------------------------------------

    def create_webhook(
        self,
        url: str,
        *,
        description: str | None = None,
    ) -> WebhookCreated:
        body: dict[str, Any] = {"url": url}
        if description is not None:
            body["description"] = description
        resp = self._request("POST", "/v1/webhooks", json=body, retriable=False)
        return resp.json()

    def list_webhooks(self) -> dict[str, Any]:
        resp = self._request("GET", "/v1/webhooks")
        return resp.json()

    def delete_webhook(self, webhook_id: str) -> dict[str, Any]:
        resp = self._request("DELETE", f"/v1/webhooks/{webhook_id}", retriable=False)
        return resp.json()

    def list_webhook_deliveries(
        self,
        webhook_id: str,
        *,
        limit: int = 50,
    ) -> list[WebhookDelivery]:
        resp = self._request(
            "GET",
            f"/v1/webhooks/{webhook_id}/deliveries",
            params={"limit": limit},
        )
        return resp.json()

    def retry_webhook_delivery(
        self,
        webhook_id: str,
        delivery_id: str,
    ) -> dict[str, Any]:
        resp = self._request(
            "POST",
            f"/v1/webhooks/{webhook_id}/deliveries/{delivery_id}/retry",
            retriable=False,
        )
        return resp.json()

    # ---- Numbers ---------------------------------------------------------

    def list_numbers(self) -> list[NumberConfig]:
        resp = self._request("GET", "/v1/numbers")
        return resp.json()

    def update_number(self, number_id: str, **fields: Any) -> NumberConfig:
        resp = self._request(
            "PATCH", f"/v1/numbers/{number_id}", json=fields, retriable=False
        )
        return resp.json()

    # ---- DNC -------------------------------------------------------------

    def upload_dnc(self, csv_path: str | Path) -> DNCUploadResult:
        path = Path(csv_path)
        with path.open("rb") as fh:
            files = {"file": (path.name, fh, "text/csv")}
            resp = self._request(
                "POST",
                "/v1/dnc/upload",
                files=files,
                retriable=False,
            )
        return resp.json()

    def list_dnc(self, *, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        resp = self._request(
            "GET", "/v1/dnc", params={"limit": limit, "offset": offset}
        )
        return resp.json()

    def delete_dnc_entry(self, entry_id: str) -> dict[str, Any]:
        resp = self._request("DELETE", f"/v1/dnc/{entry_id}", retriable=False)
        return resp.json()

    # ---- Voices ----------------------------------------------------------

    def list_voices(self) -> list[Voice]:
        resp = self._request("GET", "/v1/voices")
        return resp.json()

    # ---- Providers (BYO Twilio) ------------------------------------------

    def verify_twilio(
        self,
        account_sid: str,
        auth_token: str,
    ) -> dict[str, Any]:
        resp = self._request(
            "POST",
            "/v1/providers/twilio/verify",
            json={"account_sid": account_sid, "auth_token": auth_token},
            retriable=False,
        )
        return resp.json()

    def select_number(self, e164: str) -> dict[str, Any]:
        resp = self._request(
            "POST",
            "/v1/providers/numbers/select",
            json={"e164": e164},
            retriable=False,
        )
        return resp.json()

    # ---- Analytics -------------------------------------------------------

    def analytics_summary(
        self,
        *,
        range: str = "30d",
        direction: str = "all",
    ) -> AnalyticsSummary:
        resp = self._request(
            "GET",
            "/v1/analytics/summary",
            params={"range": range, "direction": direction},
        )
        return resp.json()

    # ---- Auth ------------------------------------------------------------

    def me(self) -> Me:
        resp = self._request("GET", "/auth/me")
        return resp.json()

    def close(self) -> None:
        self._client.close()

    # ---- Legacy pass-through (kept for 0.2.0 callers) --------------------

    def add_suppression(
        self, phone_numbers: list[str], reason: str | None = None
    ) -> dict[str, Any]:
        resp = self._request(
            "POST",
            "/v1/suppression",
            json={"phone_numbers": phone_numbers, "reason": reason},
            retriable=False,
        )
        return resp.json()

    def list_suppression(self) -> dict[str, Any]:
        resp = self._request("GET", "/v1/suppression")
        return resp.json()
