"""OpenPhn — Python SDK.

Quickstart:

    from openphn import OpenPhn

    with OpenPhn(api_key="sk_live_...") as client:
        r = client.call(
            to="+14155551234",
            objective="Confirm order A-14421 ships today",
            outcome_schema={
                "will_ship_today": {"type": "boolean"},
                "tracking": {"type": "string", "optional": True},
            },
            consent_type="existing_business_relationship",
        )
        print(r["outcome"])

Async:

    from openphn import AsyncOpenPhn
    async with AsyncOpenPhn(api_key="sk_live_...") as client:
        ...

Typed errors:

    from openphn import DNCBlockedError, RateLimitError
    try:
        client.call(...)
    except DNCBlockedError:
        # number on suppression — don't retry
        ...
    except RateLimitError as e:
        time.sleep(e.retry_after_seconds or 30)

Full REST reference: https://api.openphn.com/docs
Conceptual docs:     https://docs.openphn.com
"""

from openphn.client import AsyncOpenPhn, OpenPhn
from openphn.exceptions import (
    AuthenticationError,
    ConflictError,
    ConsentError,
    DNCBlockedError,
    NotFoundError,
    OpenPhnError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
    VerificationPendingError,
)

__version__ = "0.3.0"

__all__ = [
    # clients
    "OpenPhn",
    "AsyncOpenPhn",
    # exceptions
    "OpenPhnError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "DNCBlockedError",
    "ConsentError",
    "VerificationPendingError",
    # version
    "__version__",
]
