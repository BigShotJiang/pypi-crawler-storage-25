"""OpenPhn SDK tests. Use respx to stub the httpx transport layer."""

from __future__ import annotations

import pytest
import respx
from httpx import Response

from openphn import (
    AsyncOpenPhn,
    AuthenticationError,
    ConflictError,
    DNCBlockedError,
    OpenPhn,
    OpenPhnError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
    VerificationPendingError,
)


# ─── Client construction ──────────────────────────────────────────────────


def test_client_init():
    client = OpenPhn(api_key="sk_live_test123")
    assert client.api_key == "sk_live_test123"
    assert client.base_url == "https://api.openphn.com"
    client.close()


def test_client_custom_url_strips_trailing_slash():
    client = OpenPhn(api_key="sk_live_test", base_url="http://localhost:8000/")
    assert client.base_url == "http://localhost:8000"
    client.close()


def test_client_sets_user_agent():
    client = OpenPhn(api_key="sk_live_test")
    assert "openphn-python/" in client._client.headers["user-agent"]
    client.close()


# ─── Typed error mapping ──────────────────────────────────────────────────


@respx.mock
def test_dnc_blocked_is_specific_subclass():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(
            403,
            json={"error": "dnc_blocked", "message": "Number is on the global DNC list"},
        )
    )
    with OpenPhn(api_key="sk_live_test") as client:
        with pytest.raises(DNCBlockedError) as excinfo:
            client.call(
                to="+14155551234",
                objective="x",
                outcome_schema={},
                consent_type="prior_express",
                wait=False,
            )
    assert excinfo.value.status_code == 403
    assert excinfo.value.error_code == "dnc_blocked"
    assert isinstance(excinfo.value, PermissionError)
    assert isinstance(excinfo.value, OpenPhnError)


@respx.mock
def test_verification_pending_is_specific_subclass():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(
            403,
            json={"error": "verification_pending", "message": "pending_review"},
        )
    )
    with OpenPhn(api_key="sk_live_test") as client:
        with pytest.raises(VerificationPendingError):
            client.call(
                to="+14155551234", objective="x", outcome_schema={},
                consent_type="prior_express", wait=False,
            )


@respx.mock
def test_401_maps_to_authentication_error():
    respx.get("https://api.openphn.com/auth/me").mock(
        return_value=Response(401, json={"error": "invalid_token", "message": "bad key"})
    )
    with OpenPhn(api_key="sk_live_test", max_retries=0) as client:
        with pytest.raises(AuthenticationError):
            client.me()


@respx.mock
def test_422_maps_to_validation_error():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(
            422, json={"error": "invalid_phone", "message": "not E.164"}
        )
    )
    with OpenPhn(api_key="sk_live_test") as client:
        with pytest.raises(ValidationError) as exc:
            client.call(
                to="not-a-number", objective="x", outcome_schema={},
                consent_type="prior_express", wait=False,
            )
    assert exc.value.error_code == "invalid_phone"


@respx.mock
def test_409_conflict_on_idempotency_reuse():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(
            409, json={"error": "idempotency_conflict", "message": "key reused with different body"}
        )
    )
    with OpenPhn(api_key="sk_live_test", max_retries=0) as client:
        with pytest.raises(ConflictError):
            client.call(
                to="+14155551234", objective="x", outcome_schema={},
                consent_type="prior_express", wait=False,
                idempotency_key="key-1",
            )


@respx.mock
def test_429_maps_to_rate_limit_with_retry_after():
    respx.get("https://api.openphn.com/auth/me").mock(
        return_value=Response(
            429,
            headers={"Retry-After": "7"},
            json={"error": "rate_limited", "message": "slow down"},
        )
    )
    with OpenPhn(api_key="sk_live_test", max_retries=0) as client:
        with pytest.raises(RateLimitError) as exc:
            client.me()
    assert exc.value.retry_after_seconds == 7


@respx.mock
def test_5xx_auto_retries_then_succeeds():
    """max_retries=3 → transient 500 is retried until success."""
    route = respx.get("https://api.openphn.com/auth/me").mock(
        side_effect=[
            Response(500, json={"error": "server", "message": "oops"}),
            Response(500, json={"error": "server", "message": "oops"}),
            Response(200, json={
                "email": "me@example.com",
                "verification_status": "approved",
                "is_admin": False,
            }),
        ]
    )
    with OpenPhn(api_key="sk_live_test", max_retries=3) as client:
        me = client.me()
    assert route.call_count == 3
    assert me["email"] == "me@example.com"


@respx.mock
def test_5xx_exhausts_retries_then_raises():
    respx.get("https://api.openphn.com/auth/me").mock(
        return_value=Response(500, json={"error": "server", "message": "oops"})
    )
    with OpenPhn(api_key="sk_live_test", max_retries=2) as client:
        with pytest.raises(ServerError):
            client.me()


# ─── Calls ────────────────────────────────────────────────────────────────


@respx.mock
def test_sync_call_no_wait():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(201, json={"call_id": "call_123", "status": "requested"})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        result = client.call(
            to="+14165551234",
            objective="Test",
            outcome_schema={"status": {"type": "enum", "values": ["ok"]}},
            consent_type="prior_express",
            wait=False,
        )
    assert result == {"call_id": "call_123", "status": "requested"}


@respx.mock
def test_sync_call_omits_none_optional_kwargs():
    captured: dict = {}

    def handler(request):
        captured["body"] = request.read().decode()
        return Response(201, json={"call_id": "c1", "status": "requested"})

    respx.post("https://api.openphn.com/v1/calls").mock(side_effect=handler)

    with OpenPhn(api_key="sk_live_test") as client:
        client.call(
            to="+14155551234", objective="x", outcome_schema={},
            consent_type="prior_express", wait=False,
        )
    # None-valued optional kwargs must not appear in body as JSON null —
    # saves the backend from parsing them as "caller intended null."
    assert '"voice_id"' not in captured["body"]
    assert '"from_number"' not in captured["body"]
    assert '"tools"' not in captured["body"]
    assert '"context"' not in captured["body"]
    assert '"idempotency_key"' not in captured["body"]


@respx.mock
def test_sync_list_calls():
    respx.get("https://api.openphn.com/v1/calls").mock(
        return_value=Response(200, json={"calls": [], "total": 0, "limit": 25, "offset": 0})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        result = client.list_calls(limit=25)
    assert result["total"] == 0


@respx.mock
def test_sync_iter_calls_pages_through_until_empty():
    respx.get("https://api.openphn.com/v1/calls").mock(
        side_effect=[
            Response(200, json={"calls": [{"id": "a"}, {"id": "b"}]}),
            Response(200, json={"calls": [{"id": "c"}]}),
        ]
    )
    with OpenPhn(api_key="sk_live_test") as client:
        got = list(client.iter_calls(page_size=2))
    assert [c["id"] for c in got] == ["a", "b", "c"]


@respx.mock
def test_sync_create_batch():
    respx.post("https://api.openphn.com/v1/calls/batch").mock(
        return_value=Response(201, json={"created": [{"call_id": "a"}, {"call_id": "b"}]})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        result = client.create_batch(
            items=[
                {"to": "+14155551234", "objective": "x", "outcome_schema": {}, "consent_type": "prior_express"},
                {"to": "+14155551235", "objective": "x", "outcome_schema": {}, "consent_type": "prior_express"},
            ],
            idempotency_key="batch-1",
        )
    assert len(result["created"]) == 2


# ─── Webhooks ────────────────────────────────────────────────────────────


@respx.mock
def test_sync_webhook_crud():
    respx.post("https://api.openphn.com/v1/webhooks").mock(
        return_value=Response(
            201, json={"id": "wh_1", "url": "https://x.y/wh", "secret": "whsec", "active": True}
        )
    )
    respx.get("https://api.openphn.com/v1/webhooks").mock(
        return_value=Response(200, json={"webhooks": [{"id": "wh_1"}]})
    )
    respx.delete("https://api.openphn.com/v1/webhooks/wh_1").mock(
        return_value=Response(200, json={"status": "deleted"})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        created = client.create_webhook(url="https://x.y/wh")
        listed = client.list_webhooks()
        deleted = client.delete_webhook("wh_1")
    assert created["secret"] == "whsec"
    assert listed["webhooks"][0]["id"] == "wh_1"
    assert deleted["status"] == "deleted"


@respx.mock
def test_sync_webhook_deliveries():
    respx.get("https://api.openphn.com/v1/webhooks/wh_1/deliveries").mock(
        return_value=Response(
            200,
            json=[
                {"id": "dlv_1", "attempt": 1, "status_code": 500, "latency_ms": 80},
                {"id": "dlv_2", "attempt": 2, "status_code": 200, "latency_ms": 45},
            ],
        )
    )
    respx.post("https://api.openphn.com/v1/webhooks/wh_1/deliveries/dlv_1/retry").mock(
        return_value=Response(200, json={"queued": True})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        rows = client.list_webhook_deliveries("wh_1")
        retry = client.retry_webhook_delivery("wh_1", "dlv_1")
    assert len(rows) == 2
    assert retry["queued"] is True


# ─── DNC / Numbers / Voices / Providers / Analytics / Auth ────────────────


@respx.mock
def test_sync_list_dnc_and_delete():
    respx.get("https://api.openphn.com/v1/dnc").mock(
        return_value=Response(200, json={"entries": [], "total": 0})
    )
    respx.delete("https://api.openphn.com/v1/dnc/e_1").mock(
        return_value=Response(200, json={"status": "deleted"})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        ls = client.list_dnc()
        dl = client.delete_dnc_entry("e_1")
    assert ls["total"] == 0
    assert dl["status"] == "deleted"


@respx.mock
def test_sync_list_numbers_and_update():
    respx.get("https://api.openphn.com/v1/numbers").mock(
        return_value=Response(200, json=[{"id": "num_1", "e164": "+14155551234"}])
    )
    respx.patch("https://api.openphn.com/v1/numbers/num_1").mock(
        return_value=Response(200, json={"id": "num_1", "greeting_text": "Hi!"})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        numbers = client.list_numbers()
        updated = client.update_number("num_1", greeting_text="Hi!")
    assert numbers[0]["id"] == "num_1"
    assert updated["greeting_text"] == "Hi!"


@respx.mock
def test_sync_list_voices():
    respx.get("https://api.openphn.com/v1/voices").mock(
        return_value=Response(
            200, json=[{"id": "puck", "provider": "gemini", "display_name": "Puck"}]
        )
    )
    with OpenPhn(api_key="sk_live_test") as client:
        voices = client.list_voices()
    assert voices[0]["id"] == "puck"


@respx.mock
def test_sync_verify_twilio_and_select_number():
    respx.post("https://api.openphn.com/v1/providers/twilio/verify").mock(
        return_value=Response(200, json={"numbers": [{"phone_number": "+14155551234"}]})
    )
    respx.post("https://api.openphn.com/v1/providers/numbers/select").mock(
        return_value=Response(200, json={"status": "selected"})
    )
    with OpenPhn(api_key="sk_live_test") as client:
        verified = client.verify_twilio(account_sid="AC123", auth_token="tok")
        selected = client.select_number(e164="+14155551234")
    assert verified["numbers"][0]["phone_number"] == "+14155551234"
    assert selected["status"] == "selected"


@respx.mock
def test_sync_analytics_summary_and_me():
    respx.get("https://api.openphn.com/v1/analytics/summary").mock(
        return_value=Response(
            200,
            json={
                "total_calls": 10, "delivered_count": 8, "success_rate": 0.8,
                "avg_duration_seconds": 62.5, "total_cost": 3.40,
                "voicemail_count": 2, "voicemail_rate": 0.2,
                "greeting_latency_p50_ms": 820,
            },
        )
    )
    respx.get("https://api.openphn.com/auth/me").mock(
        return_value=Response(
            200,
            json={"user_id": "u_1", "email": "me@example.com",
                  "verification_status": "approved", "is_admin": False},
        )
    )
    with OpenPhn(api_key="sk_live_test") as client:
        s = client.analytics_summary(range="7d")
        me = client.me()
    assert s["greeting_latency_p50_ms"] == 820
    assert me["email"] == "me@example.com"


# ─── Async parity ────────────────────────────────────────────────────────


@pytest.mark.asyncio
@respx.mock
async def test_async_call_no_wait():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(201, json={"call_id": "call_123", "status": "requested"})
    )
    async with AsyncOpenPhn(api_key="sk_live_test") as client:
        result = await client.call(
            to="+14165551234",
            objective="Test",
            outcome_schema={"status": {"type": "enum", "values": ["ok"]}},
            consent_type="prior_express",
            wait=False,
        )
    assert result == {"call_id": "call_123", "status": "requested"}


@pytest.mark.asyncio
@respx.mock
async def test_async_get_call():
    respx.get("https://api.openphn.com/v1/calls/abc").mock(
        return_value=Response(200, json={"call_id": "abc", "status": "delivered"})
    )
    async with AsyncOpenPhn(api_key="sk_live_test") as client:
        result = await client.get_call("abc")
    assert result["status"] == "delivered"


@pytest.mark.asyncio
@respx.mock
async def test_async_dnc_blocked_maps_same_as_sync():
    respx.post("https://api.openphn.com/v1/calls").mock(
        return_value=Response(
            403, json={"error": "dnc_blocked", "message": "on list"}
        )
    )
    async with AsyncOpenPhn(api_key="sk_live_test") as client:
        with pytest.raises(DNCBlockedError):
            await client.call(
                to="+14155551234", objective="x", outcome_schema={},
                consent_type="prior_express", wait=False,
            )


@pytest.mark.asyncio
@respx.mock
async def test_async_iter_calls_pages_through():
    respx.get("https://api.openphn.com/v1/calls").mock(
        side_effect=[
            Response(200, json={"calls": [{"id": "a"}, {"id": "b"}]}),
            Response(200, json={"calls": [{"id": "c"}]}),
        ]
    )
    async with AsyncOpenPhn(api_key="sk_live_test") as client:
        got = [c async for c in client.iter_calls(page_size=2)]
    assert [c["id"] for c in got] == ["a", "b", "c"]
