"""Content cleaning and text normalization with Swedish OCR fixes."""

import logging
import re
import unicodedata
from typing import Callable

logger = logging.getLogger(__name__)


class ContentCleaner:
    """
    Clean and normalize extracted text content.

    Includes special handling for Swedish OCR errors and
    common text extraction issues.
    """

    # Swedish OCR error patterns
    SWEDISH_OCR_FIXES = {
        # Common character confusions
        "å": ["a°", "a˚", "å", "ä"],
        "ä": ["a¨", "ä", "a.."],
        "ö": ["o¨", "ö", "o.."],
        "Å": ["A°", "A˚", "Å"],
        "Ä": ["A¨", "Ä", "A.."],
        "Ö": ["O¨", "Ö", "O.."],
        # Common word fixes
        "är": ["ar", "är"],
        "och": ["oeh", "0ch"],
        "för": ["for", "för"],
        "att": ["atl", "alt"],
        "med": ["rned", "rued"],
        "det": ["del", "det"],
        "som": ["sorn", "soin"],
        "kan": ["kau", "kari"],
        "har": ["har", "liar"],
        "ett": ["ett", "elt"],
        "den": ["deu", "den"],
        "mot": ["rnot", "mot"],
        "man": ["rnan", "mau"],
    }

    # Common HTML entities that might remain
    HTML_ENTITIES = {
        "&nbsp;": " ",
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": '"',
        "&apos;": "'",
        "&#39;": "'",
        "&#x27;": "'",
        "&mdash;": "\u2014",
        "&ndash;": "\u2013",
        "&bull;": "\u2022",
        "&hellip;": "\u2026",
        "&copy;": "\u00a9",
        "&reg;": "\u00ae",
        "&trade;": "\u2122",
    }

    def __init__(
        self,
        fix_swedish_ocr: bool = True,
        normalize_unicode: bool = True,
        normalize_whitespace: bool = True,
        decode_html_entities: bool = True,
    ):
        """
        Initialize the cleaner.

        Args:
            fix_swedish_ocr: Apply Swedish OCR fixes
            normalize_unicode: Normalize unicode characters
            normalize_whitespace: Normalize whitespace
            decode_html_entities: Decode remaining HTML entities
        """
        self.fix_swedish_ocr = fix_swedish_ocr
        self.normalize_unicode = normalize_unicode
        self.normalize_whitespace = normalize_whitespace
        self.decode_html_entities = decode_html_entities

    def clean(self, text: str) -> str:
        """
        Clean and normalize text.

        Args:
            text: Text to clean

        Returns:
            Cleaned text
        """
        if not text:
            return ""

        # Decode HTML entities
        if self.decode_html_entities:
            text = self._decode_html_entities(text)

        # Normalize unicode
        if self.normalize_unicode:
            text = self._normalize_unicode(text)

        # Fix Swedish OCR errors
        if self.fix_swedish_ocr:
            text = self._fix_swedish_ocr(text)

        # Normalize whitespace
        if self.normalize_whitespace:
            text = self._normalize_whitespace(text)

        return text.strip()

    def _decode_html_entities(self, text: str) -> str:
        """Decode remaining HTML entities."""
        import html

        # First try standard html unescape
        text = html.unescape(text)

        # Then handle any remaining entities
        for entity, replacement in self.HTML_ENTITIES.items():
            text = text.replace(entity, replacement)

        return text

    def _normalize_unicode(self, text: str) -> str:
        """Normalize unicode characters."""
        # Normalize to NFC form (composed)
        text = unicodedata.normalize("NFC", text)

        # Replace common problematic characters
        replacements = {
            "\u00a0": " ",  # Non-breaking space
            "\u200b": "",  # Zero-width space
            "\u200c": "",  # Zero-width non-joiner
            "\u200d": "",  # Zero-width joiner
            "\ufeff": "",  # Byte order mark
            "\u2028": "\n",  # Line separator
            "\u2029": "\n\n",  # Paragraph separator
            "\u0085": "\n",  # Next line
            "\r\n": "\n",  # Windows line endings
            "\r": "\n",  # Old Mac line endings
        }

        for char, replacement in replacements.items():
            text = text.replace(char, replacement)

        # Remove control characters (except newline and tab)
        text = "".join(
            c if c in "\n\t" or not unicodedata.category(c).startswith("C") else " "
            for c in text
        )

        return text

    def _normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace."""
        # Replace multiple spaces with single space
        text = re.sub(r"[ \t]+", " ", text)

        # Replace multiple newlines with double newline (paragraph break)
        text = re.sub(r"\n{3,}", "\n\n", text)

        # Remove spaces at beginning/end of lines
        text = re.sub(r"^[ \t]+", "", text, flags=re.MULTILINE)
        text = re.sub(r"[ \t]+$", "", text, flags=re.MULTILINE)

        # Remove spaces around newlines
        text = re.sub(r" *\n *", "\n", text)

        return text

    def _fix_swedish_ocr(self, text: str) -> str:
        """
        Apply Swedish OCR fixes.

        Common OCR errors when scanning Swedish documents:
        - å often misread as a° or a˚
        - ä often misread as a¨ or a..
        - ö often misread as o¨ or o..
        - Common word-level errors
        """
        # Fix character-level errors (excluding the correct character itself)
        char_fixes = {
            "a°": "å",
            "a˚": "å",
            "a¨": "ä",
            "o¨": "ö",
            "A°": "Å",
            "A˚": "Å",
            "A¨": "Ä",
            "O¨": "Ö",
        }

        for wrong, correct in char_fixes.items():
            text = text.replace(wrong, correct)

        # Fix common word-level OCR errors
        # Use word boundaries to avoid false positives
        word_fixes = {
            r"\boeh\b": "och",
            r"\b0ch\b": "och",
            r"\brned\b": "med",
            r"\bsorn\b": "som",
            r"\brnan\b": "man",
            r"\brnot\b": "mot",
            r"\bliar\b": "har",
            r"\batl\b": "att",
            r"\bdel\b": "det",  # Be careful with this one
        }

        for pattern, replacement in word_fixes.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

        return text

    def clean_for_llm(self, text: str, max_length: int | None = None) -> str:
        """
        Clean text specifically for LLM processing.

        Applies aggressive cleaning to reduce tokens.

        Args:
            text: Text to clean
            max_length: Optional maximum length

        Returns:
            Cleaned text optimized for LLM
        """
        text = self.clean(text)

        # Remove URLs (they often don't add value for LLM understanding)
        text = re.sub(r"https?://\S+", "[URL]", text)

        # Remove email addresses
        text = re.sub(r"\S+@\S+\.\S+", "[EMAIL]", text)

        # Remove phone numbers (basic pattern)
        text = re.sub(r"\+?\d[\d\s-]{7,}\d", "[PHONE]", text)

        # Collapse repeated punctuation
        text = re.sub(r"([.!?])\1+", r"\1", text)
        text = re.sub(r"[-_=]{3,}", "---", text)

        # Remove excessive capitalization (ALL CAPS -> Title Case)
        def fix_all_caps(match):
            word = match.group(0)
            if len(word) > 3:  # Only fix words longer than 3 chars
                return word.title()
            return word

        text = re.sub(r"\b[A-ZÅÄÖ]{4,}\b", fix_all_caps, text)

        # Truncate if needed
        if max_length and len(text) > max_length:
            text = text[:max_length].rsplit(" ", 1)[0] + "..."

        return text


def clean_text(text: str, fix_swedish_ocr: bool = True) -> str:
    """
    Convenience function to clean text.

    Args:
        text: Text to clean
        fix_swedish_ocr: Apply Swedish OCR fixes

    Returns:
        Cleaned text
    """
    cleaner = ContentCleaner(fix_swedish_ocr=fix_swedish_ocr)
    return cleaner.clean(text)


# =====================================================================
# Extended Swedish OCR corrections for legal documents
# =====================================================================

SWEDISH_OCR_CORRECTIONS: list[tuple[str, str]] = [
    # Character-level OCR confusions (rn -> m is very common)
    (r'(?<=[a-zåäö])rn(?=[a-zåäö])', 'm'),

    # Municipality/government terms
    (r'\bkornrnun', 'kommun'),
    (r'\bkornmun', 'kommun'),
    (r'\bkomrnun', 'kommun'),
    (r'\bKornrnun', 'Kommun'),
    (r'\bKornmun', 'Kommun'),
    (r'\bKomrnun', 'Kommun'),
    (r'\bkornrnunal', 'kommunal'),
    (r'\bkornmunal', 'kommunal'),
    (r'\bkomrnunal', 'kommunal'),
    (r'\bkornrnunfull', 'kommunfull'),
    (r'\bkornmunfull', 'kommunfull'),

    # Supervision/oversight
    (r'\btillsyu\b', 'tillsyn'),
    (r'\btillsyii\b', 'tillsyn'),
    (r'\bTillsyu\b', 'Tillsyn'),

    # Administration
    (r'\bhandläggniug\b', 'handläggning'),
    (r'\bhandlägguiug\b', 'handläggning'),
    (r'\bhandläggare\b', 'handläggare'),
    (r'\bförvaltniug\b', 'förvaltning'),
    (r'\bförvaltuiug\b', 'förvaltning'),
    (r'\bFörvaltniug\b', 'Förvaltning'),

    # Legal terms
    (r'\böverklagaude\b', 'överklagande'),
    (r'\böverklagaiide\b', 'överklagande'),
    (r'\bÖverklagaude\b', 'Överklagande'),
    (r'\bbeslnt\b', 'beslut'),
    (r'\bBeslnt\b', 'Beslut'),

    # Authority/government
    (r'\bmyudighet\b', 'myndighet'),
    (r'\bMyudighet\b', 'Myndighet'),
    (r'\bmyndig\u0068et\b', 'myndighet'),
    (r'\blagstiftuiug\b', 'lagstiftning'),
    (r'\blagstiftniug\b', 'lagstiftning'),
    (r'\bLagstiftuiug\b', 'Lagstiftning'),

    # Common legal document words
    (r'\bbestärnrnelse\b', 'bestämmelse'),
    (r'\bbestärurnelse\b', 'bestämmelse'),
    (r'\bbestämmelse\b', 'bestämmelse'),
    (r'\bBestärnrnelse\b', 'Bestämmelse'),
    (r'\bsarnrnanträde\b', 'sammanträde'),
    (r'\bsarnmanträde\b', 'sammanträde'),
    (r'\bsamrnanträde\b', 'sammanträde'),
    (r'\bSarnrnanträde\b', 'Sammanträde'),

    # Investigation/review
    (r'\butredniug\b', 'utredning'),
    (r'\butredniiig\b', 'utredning'),
    (r'\bUtredniug\b', 'Utredning'),
    (r'\bgranskning\b', 'granskning'),
    (r'\bGrauskning\b', 'Granskning'),

    # Protocol/meeting
    (r'\bprotokoll\b', 'protokoll'),
    (r'\bsamrnanfattning\b', 'sammanfattning'),
    (r'\bsarnrnanfattning\b', 'sammanfattning'),
    (r'\bSarnrnanfattning\b', 'Sammanfattning'),

    # Document types
    (r'\bförordniug\b', 'förordning'),
    (r'\bFörordniug\b', 'Förordning'),
    (r'\bproposition\b', 'proposition'),
    (r'\bskrivelse\b', 'skrivelse'),
    (r'\bremissvar\b', 'remissvar'),
    (r'\brernissvar\b', 'remissvar'),
    (r'\bRerrnissvar\b', 'Remissvar'),

    # Rights and responsibilities
    (r'\bskyldighet\b', 'skyldighet'),
    (r'\brättighet\b', 'rättighet'),
    (r'\btillståud\b', 'tillstånd'),
    (r'\bTillståud\b', 'Tillstånd'),

    # Common verbs
    (r'\bgenornföra\b', 'genomföra'),
    (r'\bgenomföra\b', 'genomföra'),
    (r'\bgenornfört\b', 'genomfört'),
    (r'\böverläruna\b', 'överlämna'),
    (r'\böverlärnna\b', 'överlämna'),

    # Organization names
    (r'\bRiksrevisionen\b', 'Riksrevisionen'),
    (r'\bKarnrnarrätten\b', 'Kammarrätten'),
    (r'\bKamrnarrätten\b', 'Kammarrätten'),
    (r'\bLänsstyrelsen\b', 'Länsstyrelsen'),
    (r'\bläusstyrelseu\b', 'länsstyrelsen'),

    # Numbers and references
    (r'(\d)\s*§', r'\1 §'),  # Fix spacing before paragraph sign
    (r'§\s*(\d)', r'§ \1'),  # Fix spacing after paragraph sign

    # Punctuation fixes
    (r'\s+,', ','),
    (r'\s+\.(?=\s|$)', '.'),
    (r'\s+;', ';'),
]

# Compile patterns for performance
_COMPILED_OCR_CORRECTIONS: list[tuple[re.Pattern, str]] | None = None


def _get_compiled_ocr_corrections() -> list[tuple[re.Pattern, str]]:
    """Lazy-compile OCR correction patterns."""
    global _COMPILED_OCR_CORRECTIONS
    if _COMPILED_OCR_CORRECTIONS is None:
        _COMPILED_OCR_CORRECTIONS = [
            (re.compile(pattern), replacement)
            for pattern, replacement in SWEDISH_OCR_CORRECTIONS
        ]
    return _COMPILED_OCR_CORRECTIONS


def fix_swedish_ocr_extended(text: str) -> str:
    """Apply extended Swedish OCR corrections for legal documents."""
    if not text:
        return ""
    for pattern, replacement in _get_compiled_ocr_corrections():
        text = pattern.sub(replacement, text)
    return text


def strip_html_tags(text: str) -> str:
    """Strip HTML tags from text, removing script and style blocks first."""
    if not text:
        return ""
    # Remove script and style blocks entirely
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Remove HTML comments
    text = re.sub(r'<!--.*?-->', '', text, flags=re.DOTALL)
    # Replace block-level tags with newlines
    text = re.sub(r'<(?:br|p|div|h[1-6]|li|tr)[^>]*/?>', '\n', text, flags=re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r'<[^>]+>', '', text)
    return text


def extract_html_from_dokumentstatus(xml_text: str) -> str | None:
    """Extract HTML content from Riksdagen dokumentstatus XML.

    The Riksdagen API returns documents wrapped in XML with the actual
    HTML body inside ``<dokument><html>`` tags.
    """
    if not xml_text:
        return None

    # Try to find <html> inside <dokument>
    match = re.search(
        r'<dokument>.*?<html>(.*?)</html>',
        xml_text,
        flags=re.DOTALL | re.IGNORECASE,
    )
    if match:
        return match.group(1).strip()

    # Fallback: try bare <html> tag
    match = re.search(
        r'<html[^>]*>(.*?)</html>',
        xml_text,
        flags=re.DOTALL | re.IGNORECASE,
    )
    if match:
        return match.group(1).strip()

    return None


def extract_summary_from_xml(xml_text: str) -> str | None:
    """Extract summary text from Riksdagen XML documents.

    Looks for content in ``<notis>``, ``<dokutskottsforslag>``,
    and ``<debatt>`` tags.
    """
    if not xml_text:
        return None

    parts: list[str] = []

    for tag in ('notis', 'dokutskottsforslag', 'debatt', 'summary'):
        match = re.search(
            rf'<{tag}[^>]*>(.*?)</{tag}>',
            xml_text,
            flags=re.DOTALL | re.IGNORECASE,
        )
        if match:
            content = strip_html_tags(match.group(1)).strip()
            if content:
                parts.append(content)

    return '\n\n'.join(parts) if parts else None


_SCAN_WARNING_PATTERNS = [
    re.compile(r'Dokumentet är inskannat.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'Observera att dokumentet är inskannat.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'OBS!\s*Dokumentet.*?inskannat.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'Detta dokument har skannats.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'Inskannat dokument.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'Skannat dokument.*?kvalitet.*?(?:\n|$)', re.IGNORECASE),
    re.compile(r'OCR-tolkat dokument.*?(?:\n|$)', re.IGNORECASE),
]


def remove_scan_warning(text: str) -> str:
    """Remove common Swedish scan/OCR warning texts."""
    if not text:
        return ""
    for pattern in _SCAN_WARNING_PATTERNS:
        text = pattern.sub('', text)
    return text.strip()


def clean_document_content(
    text: str,
    *,
    decode_entities: bool = True,
    strip_tags: bool = True,
    normalize_ws: bool = True,
    fix_ocr: bool = True,
    remove_warnings: bool = True,
) -> str:
    """Full document cleaning pipeline.

    Applies in order: HTML entity decode -> tag stripping ->
    whitespace normalization -> OCR fixes -> scan warning removal.
    """
    if not text:
        return ""

    if decode_entities:
        import html as html_mod
        text = html_mod.unescape(text)

    if strip_tags:
        text = strip_html_tags(text)

    if normalize_ws:
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'^ +| +$', '', text, flags=re.MULTILINE)

    if fix_ocr:
        text = fix_swedish_ocr_extended(text)

    if remove_warnings:
        text = remove_scan_warning(text)

    return text.strip()


async def fetch_full_document_text(
    doc_id: str,
    text_url: str,
    timeout: float = 30.0,
) -> str | None:
    """Fetch full document text from a Riksdagen text URL.

    Tries HTML extraction from dokumentstatus XML first,
    falls back to plain text content.
    """
    import httpx

    try:
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            follow_redirects=True,
        ) as client:
            response = await client.get(text_url)
            if response.status_code >= 400:
                logger.warning(
                    "Failed to fetch document %s: HTTP %d", doc_id, response.status_code
                )
                return None

            raw = response.text

            # Try to extract HTML from dokumentstatus XML
            html_content = extract_html_from_dokumentstatus(raw)
            if html_content:
                return clean_document_content(html_content)

            # Try XML summary extraction
            summary = extract_summary_from_xml(raw)
            if summary:
                return clean_document_content(summary)

            # Fall back to cleaning raw text
            return clean_document_content(raw)

    except Exception as exc:
        logger.error("Error fetching document %s: %s", doc_id, exc)
        return None


async def batch_clean_directory(
    input_dir: str,
    output_dir: str | None = None,
    pattern: str = "*.json",
) -> int:
    """Batch-clean JSON files in a directory.

    Each JSON file is expected to have a ``content`` or ``text`` field
    which will be cleaned. Returns the number of files processed.
    """
    import json
    from pathlib import Path

    input_path = Path(input_dir)
    output_path = Path(output_dir) if output_dir else input_path

    if not input_path.exists():
        logger.warning("Input directory does not exist: %s", input_dir)
        return 0

    output_path.mkdir(parents=True, exist_ok=True)
    count = 0

    for file_path in input_path.glob(pattern):
        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))

            for key in ("content", "text", "body", "html"):
                if key in data and isinstance(data[key], str):
                    data[key] = clean_document_content(data[key])

            dest = output_path / file_path.name
            dest.write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            count += 1
        except Exception as exc:
            logger.error("Error cleaning %s: %s", file_path, exc)

    logger.info("Batch cleaned %d files from %s", count, input_dir)
    return count
