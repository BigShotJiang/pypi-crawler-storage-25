"""
Swedish PII Anonymization - Detect and replace personal data.

Supports:
- Name pseudonymization (role-aware: child, guardian, staff)
- Swedish personal numbers (personnummer)
- Phone numbers (Swedish format)
- Email addresses
- Street addresses (Swedish patterns)

Example:
    anon = Anonymizer()
    result = anon.anonymize_text("Anna Svensson, 850101-1234, bor på Storgatan 5")
    print(result.text)  # "Person A, [personnummer], bor på [adress]"
"""
import re
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class NameMapper:
    """Track name-to-pseudonym mappings for consistent anonymization."""

    _name_map: dict[str, str] = field(default_factory=dict)
    _guardian_count: int = 0
    _staff_count: int = 0
    _person_count: int = 0

    CHILD_ROLES = {"barnet", "barn", "ungdom", "subjekt", "klient"}
    GUARDIAN_ROLES = {"vårdnadshavare", "mamma", "moder", "pappa", "fader", "förälder", "mor", "far"}
    STAFF_ROLES = {"handläggare", "socialsekreterare", "utredare", "chef", "enhetschef", "personal"}

    def get_pseudonym(self, name: str, role: Optional[str] = None) -> str:
        """Get or create a consistent pseudonym for a name."""
        if not name or not name.strip():
            return name
        name_lower = name.lower().strip()
        if name_lower in self._name_map:
            return self._name_map[name_lower]
        pseudonym = self._generate_pseudonym(name_lower, role)
        self._name_map[name_lower] = pseudonym
        return pseudonym

    def _generate_pseudonym(self, name: str, role: Optional[str] = None) -> str:
        role_lower = role.lower() if role else ""
        if any(kw in name or kw in role_lower for kw in self.CHILD_ROLES):
            return "Barnet"
        elif any(kw in name or kw in role_lower for kw in self.GUARDIAN_ROLES):
            self._guardian_count += 1
            return f"Vårdnadshavare {self._guardian_count}"
        elif any(kw in name or kw in role_lower for kw in self.STAFF_ROLES):
            self._staff_count += 1
            return f"Handläggare {self._staff_count}"
        else:
            self._person_count += 1
            letter = chr(ord('A') + (self._person_count - 1) % 26)
            return f"Person {letter}"

    def reset(self):
        """Reset all mappings."""
        self._name_map.clear()
        self._guardian_count = 0
        self._staff_count = 0
        self._person_count = 0


@dataclass
class AnonymizationResult:
    """Result of text anonymization."""
    text: str
    replacements: int = 0
    details: list[dict] = field(default_factory=list)


# Swedish PII patterns
PERSONNUMMER_PATTERN = re.compile(
    r'\b(\d{6,8}[-\s]?\d{4})\b'
)
PHONE_PATTERN = re.compile(
    r'\b(0\d{1,3}[-\s]?\d{2,3}[-\s]?\d{2,4}[-\s]?\d{0,2})\b'
)
EMAIL_PATTERN = re.compile(
    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
)
ADDRESS_PATTERN = re.compile(
    r'\b([A-ZÅÄÖ][a-zåäö]+(?:gatan|vägen|stigen|torget|platsen|gränd|allén)\s+\d+[A-Za-z]?)\b'
)


class Anonymizer:
    """
    Anonymize Swedish personal data in text.

    Replaces personal numbers, phone numbers, emails, and addresses
    with placeholder tokens. Uses NameMapper for consistent name replacement.
    """

    def __init__(self):
        self.name_mapper = NameMapper()

    def anonymize_text(self, text: str) -> AnonymizationResult:
        """Anonymize all detected PII in text."""
        result = AnonymizationResult(text=text)

        # Replace personnummer
        for match in PERSONNUMMER_PATTERN.finditer(text):
            result.text = result.text.replace(match.group(), "[personnummer]")
            result.replacements += 1
            result.details.append({"type": "personnummer", "original": match.group()})

        # Replace phone numbers
        for match in PHONE_PATTERN.finditer(result.text):
            result.text = result.text.replace(match.group(), "[telefon]")
            result.replacements += 1
            result.details.append({"type": "phone", "original": match.group()})

        # Replace emails
        for match in EMAIL_PATTERN.finditer(result.text):
            result.text = result.text.replace(match.group(), "[e-post]")
            result.replacements += 1
            result.details.append({"type": "email", "original": match.group()})

        # Replace addresses
        for match in ADDRESS_PATTERN.finditer(result.text):
            result.text = result.text.replace(match.group(), "[adress]")
            result.replacements += 1
            result.details.append({"type": "address", "original": match.group()})

        return result

    def anonymize_name(self, name: str, role: Optional[str] = None) -> str:
        """Anonymize a name using consistent pseudonym mapping."""
        return self.name_mapper.get_pseudonym(name, role)

    def reset(self):
        """Reset anonymizer state."""
        self.name_mapper.reset()
