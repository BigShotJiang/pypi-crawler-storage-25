# Filepath: src/tomas_tools/swedish_banking/normalize.py
# Condensed Description: Swedish financial data normalisation utilities — amounts, dates, vendor names
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy: Functions
# Dependencies: stdlib only
# Exposes: normalize_vendor, normalize_date, safe_float, safe_str, parse_swedish_amount, resolve_payment_path

"""Swedish financial data normalisation utilities.

Safe type converters and normalizers for dirty financial data extracted from
bank statements, receipts, and other documents. Patterns drawn from DataCleaner
and data_cleaner codebases.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional


# ---------------------------------------------------------------------------
# Safe type converters — never raise, always return a sensible default
# ---------------------------------------------------------------------------

def safe_str(val: object) -> str:
    """Convert any value to str, returning '' for None/NaN/empty."""
    if val is None:
        return ""
    s = str(val).strip()
    if s.lower() in ("nan", "none", "null", "<na>"):
        return ""
    return s


def safe_float(val: object) -> float:
    """Convert any value to a non-negative float, returning 0.0 on failure.

    Handles Swedish decimal format (space thousands, comma decimal):
      "1 234,50"  → 1234.50
      "1.234,50"  → 1234.50
      "-350,00"   → 350.00  (absolute value — bank exports use negative for debits)
    """
    if val is None:
        return 0.0
    s = safe_str(val)
    if not s:
        return 0.0
    if re.search(r"\d[\s.]\d{3},\d{2}$", s):
        s = s.replace(" ", "").replace(".", "").replace(",", ".")
    else:
        s = s.replace(" ", "").replace(",", ".")
    s = re.sub(r"[^\d.\-]", "", s)
    try:
        return abs(float(s))
    except (ValueError, TypeError):
        return 0.0


def safe_int(val: object, default: int = 0) -> int:
    """Convert to int, returning default on failure."""
    try:
        return int(safe_float(val))
    except (ValueError, TypeError):
        return default


# ---------------------------------------------------------------------------
# Date normalisation — returns ISO 8601 YYYY-MM-DD or ""
# ---------------------------------------------------------------------------

_DATE_FORMATS = [
    "%Y-%m-%d", "%Y%m%d", "%d/%m/%Y", "%d-%m-%Y",
    "%m/%d/%Y", "%d.%m.%Y", "%Y/%m/%d",
    "%d %b %Y", "%d %B %Y", "%B %d, %Y",
]

_SWEDISH_MONTHS = {
    "januari": "January", "februari": "February", "mars": "March",
    "april": "April", "maj": "May", "juni": "June",
    "juli": "July", "augusti": "August", "september": "September",
    "oktober": "October", "november": "November", "december": "December",
    "jan": "Jan", "feb": "Feb", "mar": "Mar", "apr": "Apr",
    "jun": "Jun", "jul": "Jul", "aug": "Aug", "sep": "Sep",
    "okt": "Oct", "nov": "Nov", "dec": "Dec",
}


def normalize_date(val: object) -> str:
    """Parse any date representation and return YYYY-MM-DD, or '' on failure."""
    if val is None:
        return ""
    if hasattr(val, "strftime"):
        try:
            return val.strftime("%Y-%m-%d")
        except Exception:
            pass
    s = safe_str(val)
    if not s:
        return ""
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return s
    lower = s.lower()
    for swe, eng in _SWEDISH_MONTHS.items():
        if swe in lower:
            s = re.sub(swe, eng, s, flags=re.IGNORECASE)
            break
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(s.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return ""


# ---------------------------------------------------------------------------
# Amount parsing (Swedish format)
# ---------------------------------------------------------------------------

def parse_swedish_amount(val: object) -> float:
    """Parse a Swedish-formatted amount string to float (returns absolute value)."""
    return safe_float(val)


# ---------------------------------------------------------------------------
# Vendor normalisation
# ---------------------------------------------------------------------------

PAYMENT_INTERMEDIARIES: frozenset[str] = frozenset({
    "paypal", "stripe", "klarna", "swish", "paddle", "link",
    "google pay", "apple pay", "samsung pay", "mastercard",
    "visa", "amex", "american express",
})


def normalize_vendor(val: object) -> str:
    """Return a cleaned vendor name, or '' if the value looks like a ref number."""
    s = safe_str(val)
    if not s:
        return ""
    if re.match(r"^\d+$", s):
        return ""
    return " ".join(s.split())


def is_payment_intermediary(vendor: str) -> bool:
    """Return True if the vendor is a payment processor, not the actual merchant."""
    return vendor.strip().lower() in PAYMENT_INTERMEDIARIES


# ---------------------------------------------------------------------------
# Payment path parsing
# ---------------------------------------------------------------------------

_PADDLE_CODE_RE = re.compile(r"\[([A-Z0-9]+)\]")

PADDLE_VENDOR_CODES: dict[str, str] = {
    "LEONARDOAI": "Leonardo.AI", "JSON2VIDEO": "JSON2Video",
    "WEBHOOKSTE": "Webhook.site", "COMBOCLEAN": "Combo Cleaner",
    "ELEVENLAB": "ElevenLabs", "RUNWAYML": "Runway ML",
    "MIDJOURNEY": "Midjourney", "REPLICATEI": "Replicate",
    "PIKA": "Pika", "UDIO": "Udio", "SUNOAI": "Suno AI",
    "NEURALFRAME": "Neural Frames",
}

LOCATION_VENDOR_MAP: dict[str, str] = {
    "san francisco": "OpenAI",
    "south san francisco": "Anthropic",
    "seattle": "Amazon Web Services",
    "amsterdam": "DigitalOcean",
    "hamburg": "Neural Frames",
    "malaga": "Magnific",
}


def resolve_payment_path(
    vendor: str,
    description: str,
    location: str = "",
) -> tuple[str, str | None]:
    """Attempt to resolve the real vendor from a payment intermediary transaction.

    Returns (resolved_vendor, payment_path_label).
    """
    vendor_lower = vendor.strip().lower()
    desc_lower = description.strip().lower()

    if "paddle" in desc_lower or "paddle" in vendor_lower:
        paddle_match = _PADDLE_CODE_RE.search(description.upper())
        if paddle_match:
            code = paddle_match.group(1)
            resolved = PADDLE_VENDOR_CODES.get(code, code.title())
            return resolved, "PayPal→Paddle"
        star_match = re.search(r"paddle\s*\*\s*([A-Z0-9]+)", description, re.IGNORECASE)
        if star_match:
            code = star_match.group(1).upper()
            resolved = PADDLE_VENDOR_CODES.get(code, code.title())
            return resolved, "PayPal→Paddle"
        paddle_suffix = re.search(r"paddle\s*\*\s*(.+)", desc_lower)
        if paddle_suffix:
            first_word = paddle_suffix.group(1).split()[0].strip().title()
            return first_word, "PayPal→Paddle"

    if "google" in desc_lower:
        for keyword in ("google one", "google play", "google cloud", "google workspace", "youtube premium"):
            if keyword in desc_lower:
                return keyword.title(), "PayPal→Google"
        return "Google", "PayPal→Google"

    if "paypal" in vendor_lower:
        desc_clean = re.split(r"[\*\(\[]", description)[0].strip()
        if desc_clean:
            return normalize_vendor(desc_clean) or vendor, "PayPal"

    if location:
        loc_lower = location.strip().lower()
        for loc_key, resolved in LOCATION_VENDOR_MAP.items():
            if loc_key in loc_lower and resolved:
                return resolved, "location"

    return vendor, None


# ---------------------------------------------------------------------------
# OCR text cleaning
# ---------------------------------------------------------------------------

def clean_ocr_text(text: str) -> str:
    """Post-process raw OCR output for financial document parsing."""
    if not text:
        return ""
    text = text.replace("\x00", "")
    replacements = {"\ufffd": "?", "€": "Ö", "|": "I"}
    for bad, good in replacements.items():
        text = text.replace(bad, good)
    text = re.sub(r"[^\S\n]+", " ", text)
    return text.strip()
