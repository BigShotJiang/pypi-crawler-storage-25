"""Form and Input Validation.

Required-field checking, type coercion, pattern matching, sanitization
utilities, and Swedish-specific validators (personnummer, organisationsnummer,
phone numbers). Framework-agnostic: returns ``ValidationResult`` objects.

Derived from djangoTestProject's ``modules.input.validators`` (field
validation, password strength, phone, URL, pattern checks) and
``modules.input.sanitizers`` (HTML sanitization, text cleanup),
coparent_app's ``modules.config.settings`` (Swedish locale patterns), and
VentureBuilderOS's ``api.schemas.common`` (Pydantic-style field validation).

Usage:
    from data_cleaner.swedish.validators import (
        validate_fields,
        validate_email,
        validate_personnummer,
        validate_organisationsnummer,
        validate_phone_se,
        validate_password_strength,
        sanitize_text,
        coerce_types,
        ValidationResult,
    )

    # Field validation
    result = validate_fields(
        data={"name": "Tomas", "email": "bad"},
        required=["name", "email", "age"],
        patterns={"email": r"^[^@]+@[^@]+\\.[^@]+$"},
    )
    if not result.valid:
        print(result.errors)  # {"email": ["..."], "age": ["Required"]}

    # Swedish personnummer
    assert validate_personnummer("19850101-1234").valid

    # Type coercion
    data = coerce_types({"age": "25", "active": "true"}, {"age": int, "active": bool})
"""

from __future__ import annotations

import re
import html
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Type, Union


# ---------------------------------------------------------------------------
# Validation Result
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Result of a validation operation.

    Attributes:
        valid: Whether all checks passed.
        errors: Mapping of field name to list of error messages.
        data: Cleaned/coerced data (only populated on success).
    """
    valid: bool = True
    errors: Dict[str, List[str]] = field(default_factory=dict)
    data: Dict[str, Any] = field(default_factory=dict)

    def add_error(self, field_name: str, message: str) -> None:
        """Add an error for *field_name* and mark result invalid."""
        self.valid = False
        self.errors.setdefault(field_name, []).append(message)

    def merge(self, other: "ValidationResult") -> None:
        """Merge another result into this one."""
        if not other.valid:
            self.valid = False
        for k, msgs in other.errors.items():
            self.errors.setdefault(k, []).extend(msgs)
        self.data.update(other.data)


# ---------------------------------------------------------------------------
# Field Validation
# ---------------------------------------------------------------------------

def validate_fields(
    data: Dict[str, Any],
    required: Optional[List[str]] = None,
    types: Optional[Dict[str, Type]] = None,
    patterns: Optional[Dict[str, str]] = None,
    min_lengths: Optional[Dict[str, int]] = None,
    max_lengths: Optional[Dict[str, int]] = None,
    custom: Optional[Dict[str, Callable[[Any], Optional[str]]]] = None,
) -> ValidationResult:
    """Validate a data dict against multiple constraint types.

    Derived from djangoTestProject's ``validate_request`` decorator and
    ``validate_json_structure``.

    Args:
        data: Input dict to validate.
        required: Fields that must be present and non-empty.
        types: Expected Python type per field.
        patterns: Regex patterns per field (matched against string value).
        min_lengths: Minimum string length per field.
        max_lengths: Maximum string length per field.
        custom: Per-field callables ``(value) -> error_msg | None``.

    Returns:
        A ``ValidationResult`` with errors and cleaned data.
    """
    result = ValidationResult(data=dict(data))

    # Required fields
    if required:
        for f in required:
            val = data.get(f)
            if val is None or (isinstance(val, str) and not val.strip()):
                result.add_error(f, "This field is required")

    # Type checks
    if types:
        for f, expected in types.items():
            if f in data and data[f] is not None and not isinstance(data[f], expected):
                result.add_error(f, f"Expected type {expected.__name__}")

    # Pattern checks
    if patterns:
        for f, pattern in patterns.items():
            val = data.get(f)
            if val is not None and isinstance(val, str):
                if not re.match(pattern, val):
                    result.add_error(f, f"Does not match required pattern")

    # Min length
    if min_lengths:
        for f, min_len in min_lengths.items():
            val = data.get(f)
            if val is not None and isinstance(val, str) and len(val) < min_len:
                result.add_error(f, f"Minimum length is {min_len} characters")

    # Max length
    if max_lengths:
        for f, max_len in max_lengths.items():
            val = data.get(f)
            if val is not None and isinstance(val, str) and len(val) > max_len:
                result.add_error(f, f"Maximum length is {max_len} characters")

    # Custom validators
    if custom:
        for f, validator_fn in custom.items():
            val = data.get(f)
            if val is not None:
                err = validator_fn(val)
                if err:
                    result.add_error(f, err)

    return result


# ---------------------------------------------------------------------------
# Email Validation
# ---------------------------------------------------------------------------

_EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}"
    r"[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
)


def validate_email(email: str) -> ValidationResult:
    """Validate an email address format.

    Args:
        email: Email string.

    Returns:
        ValidationResult.
    """
    result = ValidationResult(data={"email": email})
    if not email or not _EMAIL_PATTERN.match(email):
        result.add_error("email", "Invalid email address format")
    return result


# ---------------------------------------------------------------------------
# Password Strength
# ---------------------------------------------------------------------------

def validate_password_strength(
    password: str,
    min_length: int = 8,
    require_upper: bool = True,
    require_lower: bool = True,
    require_digit: bool = True,
    require_special: bool = True,
) -> ValidationResult:
    """Validate password strength.

    Derived from djangoTestProject's ``validate_password_strength``.

    Args:
        password: Password to check.
        min_length: Minimum length.
        require_upper: Require uppercase letter.
        require_lower: Require lowercase letter.
        require_digit: Require digit.
        require_special: Require special character.

    Returns:
        ValidationResult with per-rule errors.
    """
    result = ValidationResult(data={"password": "***"})

    if len(password) < min_length:
        result.add_error("password", f"Must be at least {min_length} characters")
    if require_upper and not re.search(r"[A-Z]", password):
        result.add_error("password", "Must contain at least one uppercase letter")
    if require_lower and not re.search(r"[a-z]", password):
        result.add_error("password", "Must contain at least one lowercase letter")
    if require_digit and not re.search(r"\d", password):
        result.add_error("password", "Must contain at least one digit")
    if require_special and not re.search(r'[!@#$%^&*(),.?":{}|<>\-_=+\[\]\\;\'`~]', password):
        result.add_error("password", "Must contain at least one special character")

    # Common patterns
    common = ["123456", "password", "qwerty", "abc123", "letmein", "welcome"]
    for pattern in common:
        if pattern in password.lower():
            result.add_error("password", "Contains a common pattern")
            break

    return result


# ---------------------------------------------------------------------------
# Swedish-Specific Validators
# ---------------------------------------------------------------------------

def validate_personnummer(pnr: str) -> ValidationResult:
    """Validate a Swedish personnummer (personal identity number).

    Supports formats: YYYYMMDD-XXXX, YYYYMMDDXXXX, YYMMDD-XXXX, YYMMDDXXXX.
    Validates the Luhn checksum on the last digit.

    Derived from coparent_app's Swedish locale configuration and auth module
    validators.

    Args:
        pnr: Personnummer string.

    Returns:
        ValidationResult.
    """
    result = ValidationResult(data={"personnummer": pnr})

    # Normalize: remove separators, handle century prefix
    cleaned = pnr.replace("-", "").replace("+", "")

    if len(cleaned) == 12:
        # YYYYMMDDXXXX -> take last 10 for Luhn
        digits_for_luhn = cleaned[2:]
    elif len(cleaned) == 10:
        digits_for_luhn = cleaned
    else:
        result.add_error("personnummer", "Must be 10 or 12 digits (excluding separator)")
        return result

    if not digits_for_luhn.isdigit():
        result.add_error("personnummer", "Must contain only digits and optional separator")
        return result

    # Basic date validation
    if len(cleaned) == 12:
        year_str = cleaned[:4]
        month_str = cleaned[4:6]
        day_str = cleaned[6:8]
    else:
        year_str = cleaned[:2]
        month_str = cleaned[2:4]
        day_str = cleaned[4:6]

    try:
        month = int(month_str)
        day = int(day_str)
        if not (1 <= month <= 12):
            result.add_error("personnummer", "Invalid month")
            return result
        if not (1 <= day <= 31):
            result.add_error("personnummer", "Invalid day")
            return result
    except ValueError:
        result.add_error("personnummer", "Invalid date components")
        return result

    # Luhn checksum (on the 10-digit form)
    if not _luhn_check(digits_for_luhn):
        result.add_error("personnummer", "Invalid checksum")

    return result


def _luhn_check(digits: str) -> bool:
    """Verify Luhn checksum for a 10-digit Swedish personnummer."""
    total = 0
    for i, ch in enumerate(digits):
        n = int(ch)
        if i % 2 == 0:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def validate_organisationsnummer(org_nr: str) -> ValidationResult:
    """Validate a Swedish organisationsnummer (organization number).

    Format: XXXXXX-XXXX (10 digits, digit 3 >= 2). Luhn checksum on last digit.

    Args:
        org_nr: Organisation number string.

    Returns:
        ValidationResult.
    """
    result = ValidationResult(data={"organisationsnummer": org_nr})

    cleaned = org_nr.replace("-", "").replace(" ", "")

    if len(cleaned) != 10 or not cleaned.isdigit():
        result.add_error("organisationsnummer", "Must be exactly 10 digits")
        return result

    # Third digit must be >= 2 (to distinguish from personnummer)
    if int(cleaned[2]) < 2:
        result.add_error("organisationsnummer", "Third digit must be >= 2")
        return result

    if not _luhn_check(cleaned):
        result.add_error("organisationsnummer", "Invalid checksum")

    return result


def validate_phone_se(phone: str) -> ValidationResult:
    """Validate a Swedish phone number.

    Accepts formats: 07XXXXXXXX, +467XXXXXXXX, 0046-7XX-XXX-XX, etc.

    Args:
        phone: Phone number string.

    Returns:
        ValidationResult.
    """
    result = ValidationResult(data={"phone": phone})

    # Strip common formatting
    cleaned = re.sub(r"[\s\-\(\)]", "", phone)

    # Normalize international prefix
    if cleaned.startswith("+46"):
        cleaned = "0" + cleaned[3:]
    elif cleaned.startswith("0046"):
        cleaned = "0" + cleaned[4:]

    if not cleaned.isdigit():
        result.add_error("phone", "Must contain only digits (with optional +46 prefix)")
        return result

    # Swedish mobile: 07X, landline: 0X (8-10 digits total)
    if not re.match(r"^0[1-9]\d{6,9}$", cleaned):
        result.add_error("phone", "Invalid Swedish phone number format")

    return result


def validate_postnummer(postnr: str) -> ValidationResult:
    """Validate a Swedish postnummer (postal code).

    Format: NNN NN or NNNNN (5 digits).

    Args:
        postnr: Postal code string.

    Returns:
        ValidationResult.
    """
    result = ValidationResult(data={"postnummer": postnr})
    cleaned = postnr.replace(" ", "")

    if not re.match(r"^\d{5}$", cleaned):
        result.add_error("postnummer", "Must be 5 digits (e.g. 114 55)")
        return result

    # Swedish postal codes range from 10000 to 98499
    num = int(cleaned)
    if num < 10000 or num > 98499:
        result.add_error("postnummer", "Outside valid Swedish postal code range")

    return result


# ---------------------------------------------------------------------------
# Type Coercion
# ---------------------------------------------------------------------------

_BOOL_TRUE = {"true", "1", "yes", "on", "ja"}
_BOOL_FALSE = {"false", "0", "no", "off", "nej"}


def coerce_types(
    data: Dict[str, Any],
    type_map: Dict[str, Type],
    strict: bool = False,
) -> Dict[str, Any]:
    """Coerce string values to target types.

    Useful for form data and query parameters that arrive as strings.

    Args:
        data: Input dict.
        type_map: Mapping of field name to target type (int, float, bool, str).
        strict: If True, raise ValueError on coercion failure; otherwise
                leave the original value.

    Returns:
        New dict with coerced values.

    Raises:
        ValueError: If *strict* is True and coercion fails.
    """
    result = dict(data)
    for field_name, target_type in type_map.items():
        if field_name not in result:
            continue
        val = result[field_name]
        if isinstance(val, target_type):
            continue
        try:
            if target_type is bool and isinstance(val, str):
                lower = val.strip().lower()
                if lower in _BOOL_TRUE:
                    result[field_name] = True
                elif lower in _BOOL_FALSE:
                    result[field_name] = False
                elif strict:
                    raise ValueError(f"Cannot coerce '{val}' to bool")
            elif target_type is int:
                result[field_name] = int(val)
            elif target_type is float:
                result[field_name] = float(val)
            elif target_type is str:
                result[field_name] = str(val)
            else:
                result[field_name] = target_type(val)
        except (ValueError, TypeError) as exc:
            if strict:
                raise ValueError(f"Cannot coerce field '{field_name}' to {target_type.__name__}: {exc}") from exc
    return result


# ---------------------------------------------------------------------------
# Sanitization
# ---------------------------------------------------------------------------

# Patterns from djangoTestProject's validators.py
_XSS_PATTERNS = [
    re.compile(r"<script[^>]*>.*?</script>", re.IGNORECASE | re.DOTALL),
    re.compile(r"javascript:", re.IGNORECASE),
    re.compile(r"vbscript:", re.IGNORECASE),
    re.compile(r"on\w+\s*=", re.IGNORECASE),
    re.compile(r"eval\s*\(", re.IGNORECASE),
    re.compile(r"document\.cookie", re.IGNORECASE),
]


def sanitize_text(
    text: str,
    max_length: int = 10000,
    strip_html: bool = True,
    normalize_whitespace: bool = True,
    normalize_unicode: bool = True,
) -> str:
    """Sanitize a text string for safe storage/display.

    Derived from djangoTestProject's ``TextSanitizer`` and ``HTMLSanitizer``.

    Args:
        text: Input text.
        max_length: Maximum output length.
        strip_html: Remove HTML tags.
        normalize_whitespace: Collapse whitespace to single spaces.
        normalize_unicode: NFKC-normalize unicode.

    Returns:
        Sanitized text.
    """
    if not text:
        return ""

    if normalize_unicode:
        text = unicodedata.normalize("NFKC", text)

    # Remove control characters (except newline, tab)
    text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]", "", text)

    if strip_html:
        # Remove script tags and content
        for pattern in _XSS_PATTERNS:
            text = pattern.sub("", text)
        # Strip remaining tags
        text = re.sub(r"<[^>]+>", "", text)
        # Decode entities
        text = html.unescape(text)

    if normalize_whitespace:
        text = re.sub(r"\s+", " ", text).strip()

    if len(text) > max_length:
        text = text[:max_length]

    return text


def sanitize_filename(filename: str, max_length: int = 255) -> str:
    """Sanitize a filename for safe file operations.

    Derived from djangoTestProject's ``FilenameSanitizer``.

    Args:
        filename: Original filename.
        max_length: Maximum filename length.

    Returns:
        Safe filename string.
    """
    if not filename:
        return "file"

    filename = unicodedata.normalize("NFKD", filename)

    # Remove directory separators and traversal FIRST (before extension split)
    filename = re.sub(r"[/\\]", "_", filename)
    filename = re.sub(r"\.\.+", "_", filename)

    # Separate extension
    dot_pos = filename.rfind(".")
    if dot_pos > 0:
        name = filename[:dot_pos]
        ext = filename[dot_pos:]
    else:
        name = filename
        ext = ""

    # Remove remaining dangerous chars
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name)
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")

    # Windows reserved names
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    if name.upper() in reserved:
        name = f"_{name}"

    if not name:
        name = "file"

    result = name + ext
    if len(result) > max_length:
        avail = max_length - len(ext)
        result = name[:avail] + ext

    return result
