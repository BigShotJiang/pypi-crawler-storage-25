"""Swedish Public Records Utilities.

Stdlib-only utilities for Swedish organization numbers (organisationsnummer),
personal identity numbers (personnummer), and public document retrieval
helpers for Bolagsverket, SCB, and other Swedish registries.

Usage:
    from data_cleaner.swedish.org_number import (
        validate_org_number,
        format_org_number,
        classify_org_number,
        validate_personnummer,
        OrgNumberInfo,
        MunicipalityRegistry,
    )

    # Validate and classify an organization number
    info = classify_org_number("5560360793")
    print(info.org_type)   # "Aktiebolag"
    print(info.formatted)  # "556036-0793"
    print(info.valid)      # True

    # Validate format only
    assert validate_org_number("556036-0793")
    assert validate_org_number("5560360793")

    # Format with dash
    assert format_org_number("5560360793") == "556036-0793"

    # Validate a personal identity number
    assert validate_personnummer("198501011234")

    # Municipality registry
    registry = MunicipalityRegistry()
    info = registry.get("0180")
    print(info)  # {"code": "0180", "name": "Stockholm", "county": "Stockholms lan"}
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Organization number validation (Luhn algorithm)
# ---------------------------------------------------------------------------


def _luhn_checksum(number: str) -> int:
    """Calculate Luhn checksum for a digit string.

    The Swedish organization number uses Luhn mod-10 on the last 10 digits.
    The check digit is the last digit.
    """
    digits = [int(d) for d in number]
    odd_sum = 0
    even_sum = 0

    # Process from right to left, skipping the check digit
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:  # Odd positions from right (doubled)
            doubled = d * 2
            odd_sum += doubled if doubled < 10 else doubled - 9
        else:
            even_sum += d

    return (odd_sum + even_sum) % 10


def validate_org_number(org_number: str) -> bool:
    """Validate a Swedish organization number (organisationsnummer).

    Swedish organization numbers are 10 digits, often written as XXXXXX-XXXX.
    The third digit must be >= 2 (distinguishes from personnummer).
    Uses the Luhn algorithm for the check digit.

    Args:
        org_number: Organization number, with or without dash.

    Returns:
        True if the number is valid.
    """
    # Normalize: remove dashes, spaces
    cleaned = re.sub(r"[\s\-]", "", org_number)

    # Must be exactly 10 digits
    if not re.fullmatch(r"\d{10}", cleaned):
        return False

    # Third digit must be >= 2 (org numbers have group digit 2-9)
    if int(cleaned[2]) < 2:
        return False

    # Luhn check
    return _luhn_checksum(cleaned) == 0


def format_org_number(org_number: str) -> str:
    """Format an organization number with standard dash: XXXXXX-XXXX.

    Args:
        org_number: Raw organization number.

    Returns:
        Formatted string, or original if not valid 10 digits.
    """
    cleaned = re.sub(r"[\s\-]", "", org_number)
    if len(cleaned) == 10 and cleaned.isdigit():
        return f"{cleaned[:6]}-{cleaned[6:]}"
    return org_number


# ---------------------------------------------------------------------------
# Organization type classification
# ---------------------------------------------------------------------------

# The first digit of a Swedish org number indicates the legal form
_ORG_TYPE_MAP: Dict[str, str] = {
    "1": "Dodsbon",
    "2": "Stat, kommun, landsting, forsamling",
    "3": "Utlandskt foretag",
    "5": "Aktiebolag",
    "6": "Enkelt bolag / Handelsbolag / Kommanditbolag",
    "7": "Ekonomisk forening / Bostadsrattsforening",
    "8": "Ideell forening / Stiftelse / Trossamfund",
    "9": "Handelsbolag / Kommanditbolag / Ovriga",
}

# More specific classification using the first two digits
_ORG_TYPE_DETAILED: Dict[str, str] = {
    "20": "Staten",
    "21": "Kommun",
    "22": "Kommun",
    "23": "Landsting / Region",
    "24": "Forsamling / Pastorat",
    "25": "Kommun",
    "26": "Kommun",
    "27": "Kommun",
    "28": "Kommun",
    "29": "Kommun",
    "50": "Aktiebolag",
    "51": "Aktiebolag",
    "55": "Aktiebolag",
    "56": "Aktiebolag",
    "59": "Aktiebolag (publikt)",
    "60": "Enkelt bolag",
    "61": "Handelsbolag",
    "62": "Handelsbolag",
    "66": "Kommanditbolag",
    "69": "Kommanditbolag",
    "70": "Ekonomisk forening",
    "71": "Bostadsrattsforening",
    "72": "Kooperativ hyresrattsforening",
    "73": "Ekonomisk forening",
    "76": "Bostadsrattsforening",
    "79": "Ekonomisk forening",
    "80": "Ideell forening",
    "81": "Stiftelse",
    "82": "Stiftelse",
    "83": "Trossamfund",
    "84": "Ideell forening",
    "85": "Ideell forening",
    "90": "Handelsbolag",
    "91": "Ovriga",
    "92": "Ovriga",
    "93": "Enskild firma",
    "94": "Enskild firma",
    "95": "Ovriga",
    "96": "Ovriga",
    "97": "Ovriga",
}


@dataclass
class OrgNumberInfo:
    """Classification information for a Swedish organization number."""

    org_number: str = ""
    formatted: str = ""
    valid: bool = False
    org_type: str = ""
    org_type_detailed: str = ""
    first_digit: str = ""
    group_code: str = ""
    is_government: bool = False
    is_municipality: bool = False
    is_company: bool = False
    is_nonprofit: bool = False
    county_code: str = ""  # For municipalities: first 2 digits of the 4-digit code

    def to_dict(self) -> Dict[str, Any]:
        return {
            "org_number": self.org_number,
            "formatted": self.formatted,
            "valid": self.valid,
            "org_type": self.org_type,
            "org_type_detailed": self.org_type_detailed,
            "is_government": self.is_government,
            "is_municipality": self.is_municipality,
            "is_company": self.is_company,
            "is_nonprofit": self.is_nonprofit,
        }


def classify_org_number(org_number: str) -> OrgNumberInfo:
    """Validate and classify a Swedish organization number.

    Determines the legal form based on the digit pattern and validates
    the Luhn check digit.

    Args:
        org_number: Organization number, with or without dash.

    Returns:
        OrgNumberInfo with classification details.
    """
    cleaned = re.sub(r"[\s\-]", "", org_number)
    info = OrgNumberInfo(
        org_number=cleaned,
        formatted=format_org_number(cleaned),
        valid=validate_org_number(cleaned),
    )

    if len(cleaned) >= 2:
        first = cleaned[0]
        first_two = cleaned[:2]

        info.first_digit = first
        info.group_code = first_two
        info.org_type = _ORG_TYPE_MAP.get(first, "Okand")
        info.org_type_detailed = _ORG_TYPE_DETAILED.get(first_two, info.org_type)

        # Classification flags
        info.is_government = first == "2"
        info.is_municipality = first_two in ("21", "22", "23", "25", "26", "27", "28", "29")
        info.is_company = first in ("5", "6", "9")
        info.is_nonprofit = first in ("7", "8")

    return info


# ---------------------------------------------------------------------------
# Personal identity number (personnummer) validation
# ---------------------------------------------------------------------------


def validate_personnummer(pnr: str) -> bool:
    """Validate a Swedish personal identity number (personnummer).

    Supports both 10-digit (YYMMDD-XXXX) and 12-digit (YYYYMMDDXXXX) formats.
    Uses the Luhn algorithm on the 10-digit form.

    Note: This validates format and check digit only, not that the date
    actually exists or that the number is issued.

    Args:
        pnr: Personal identity number.

    Returns:
        True if format and check digit are valid.
    """
    cleaned = re.sub(r"[\s\-+]", "", pnr)

    # Convert 12-digit to 10-digit
    if len(cleaned) == 12 and cleaned.isdigit():
        cleaned = cleaned[2:]
    elif len(cleaned) != 10 or not cleaned.isdigit():
        return False

    # Basic date validation (YYMMDD)
    month = int(cleaned[2:4])
    day = int(cleaned[4:6])

    # Samordningsnummer: day + 60
    if day > 60:
        day -= 60

    if not (1 <= month <= 12 and 1 <= day <= 31):
        return False

    # Luhn check on all 10 digits
    return _luhn_checksum(cleaned) == 0


def format_personnummer(pnr: str, century: bool = True) -> str:
    """Format a personnummer with standard separators.

    Args:
        pnr: Raw personnummer.
        century: If True, return 12-digit YYYYMMDD-XXXX format.

    Returns:
        Formatted string.
    """
    cleaned = re.sub(r"[\s\-+]", "", pnr)

    if len(cleaned) == 12:
        if century:
            return f"{cleaned[:8]}-{cleaned[8:]}"
        return f"{cleaned[2:8]}-{cleaned[8:]}"
    elif len(cleaned) == 10:
        return f"{cleaned[:6]}-{cleaned[6:]}"
    return pnr


# ---------------------------------------------------------------------------
# Municipality registry
# ---------------------------------------------------------------------------

# All 290 Swedish municipalities (code -> name)
# This is a subset of the most commonly used ones; full list at SCB
_MUNICIPALITIES: Dict[str, str] = {
    "0114": "Upplands Vasby",
    "0115": "Vallentuna",
    "0117": "Osteraker",
    "0120": "Varmdo",
    "0123": "Jarfalla",
    "0125": "Ekero",
    "0126": "Huddinge",
    "0127": "Botkyrka",
    "0128": "Salem",
    "0136": "Haninge",
    "0138": "Tyreso",
    "0139": "Upplands-Bro",
    "0140": "Nykoping",
    "0160": "Taby",
    "0162": "Danderyd",
    "0163": "Sollentuna",
    "0180": "Stockholm",
    "0181": "Sodertalje",
    "0182": "Nacka",
    "0183": "Sundbyberg",
    "0184": "Solna",
    "0186": "Lidingo",
    "0187": "Vaxholm",
    "0188": "Norrtalje",
    "0191": "Sigtuna",
    "0192": "Nynashamn",
    "0305": "Habo",
    "0319": "Alvesta",
    "0360": "Tierp",
    "0380": "Uppsala",
    "0381": "Enkoping",
    "0480": "Nykoping",
    "0481": "Oxelosund",
    "0580": "Linkoping",
    "0581": "Norrkoping",
    "0680": "Jonkoping",
    "0780": "Vaxjo",
    "0880": "Kalmar",
    "0980": "Gotland",
    "1060": "Olofstrom",
    "1080": "Karlskrona",
    "1180": "Karlshamn",
    "1280": "Malmo",
    "1281": "Lund",
    "1282": "Landskrona",
    "1283": "Helsingborg",
    "1284": "Hoganas",
    "1285": "Eslov",
    "1286": "Ystad",
    "1287": "Trelleborg",
    "1290": "Kristianstad",
    "1291": "Simrishamn",
    "1292": "Angelholm",
    "1293": "Hassleholm",
    "1380": "Halmstad",
    "1381": "Laholm",
    "1382": "Falkenberg",
    "1383": "Varberg",
    "1384": "Kungsbacka",
    "1480": "Goteborg",
    "1481": "Molndal",
    "1482": "Kungalv",
    "1484": "Lysekil",
    "1485": "Uddevalla",
    "1486": "Stromstad",
    "1487": "Vanersborg",
    "1488": "Trollhattan",
    "1489": "Alingnas",
    "1490": "Boras",
    "1491": "Ulricehamn",
    "1492": "Amal",
    "1493": "Mariestad",
    "1494": "Lidkoping",
    "1495": "Skara",
    "1496": "Skovde",
    "1580": "Karlstad",
    "1581": "Kristinehamn",
    "1680": "Orebro",
    "1780": "Karlskoga",
    "1880": "Vasteras",
    "1980": "Koping",
    "2080": "Falun",
    "2081": "Borlange",
    "2082": "Ludvika",
    "2083": "Avesta",
    "2180": "Gavle",
    "2181": "Sandviken",
    "2280": "Sundsvall",
    "2281": "Harnosand",
    "2282": "Solleftea",
    "2283": "Ornskoldsvik",
    "2380": "Ostersund",
    "2480": "Umea",
    "2481": "Lycksele",
    "2482": "Skelleftea",
    "2580": "Lulea",
    "2581": "Pitea",
    "2582": "Boden",
    "2583": "Gallivare",
    "2584": "Kiruna",
}

# County codes (first 2 digits of municipality code)
_COUNTIES: Dict[str, str] = {
    "01": "Stockholms lan",
    "03": "Uppsala lan",
    "04": "Sodermanlands lan",
    "05": "Ostergotlands lan",
    "06": "Jonkopings lan",
    "07": "Kronobergs lan",
    "08": "Kalmar lan",
    "09": "Gotlands lan",
    "10": "Blekinge lan",
    "12": "Skane lan",
    "13": "Hallands lan",
    "14": "Vastra Gotalands lan",
    "17": "Varmlands lan",
    "18": "Orebro lan",
    "19": "Vastmanlands lan",
    "20": "Dalarnas lan",
    "21": "Gavleborgs lan",
    "22": "Vasternorrlands lan",
    "23": "Jamtlands lan",
    "24": "Vasterbottens lan",
    "25": "Norrbottens lan",
}


class MunicipalityRegistry:
    """Registry of Swedish municipalities.

    Provides lookup by code and name, plus county information.

    Example:
        >>> registry = MunicipalityRegistry()
        >>> registry.get("0180")
        {'code': '0180', 'name': 'Stockholm', 'county_code': '01', 'county': 'Stockholms lan'}
        >>> registry.find_by_name("Goteborg")
        {'code': '1480', ...}
    """

    def __init__(self, extra_municipalities: Optional[Dict[str, str]] = None):
        """Initialize with built-in registry plus optional additions.

        Args:
            extra_municipalities: Additional code->name mappings.
        """
        self._by_code = dict(_MUNICIPALITIES)
        if extra_municipalities:
            self._by_code.update(extra_municipalities)

        self._by_name: Dict[str, str] = {}
        for code, name in self._by_code.items():
            self._by_name[name.lower()] = code

    def get(self, code: str) -> Optional[Dict[str, str]]:
        """Look up a municipality by its 4-digit code.

        Args:
            code: 4-digit municipality code, e.g. "0180".

        Returns:
            Dict with code, name, county_code, county. None if not found.
        """
        code = code.zfill(4)
        name = self._by_code.get(code)
        if not name:
            return None

        county_code = code[:2]
        return {
            "code": code,
            "name": name,
            "county_code": county_code,
            "county": _COUNTIES.get(county_code, ""),
        }

    def find_by_name(self, name: str) -> Optional[Dict[str, str]]:
        """Look up a municipality by name (case-insensitive).

        Args:
            name: Municipality name.

        Returns:
            Dict with code, name, county_code, county. None if not found.
        """
        code = self._by_name.get(name.lower())
        if code:
            return self.get(code)

        # Fuzzy: try partial match
        name_lower = name.lower()
        for n, c in self._by_name.items():
            if name_lower in n or n in name_lower:
                return self.get(c)
        return None

    def list_all(self) -> List[Dict[str, str]]:
        """List all municipalities.

        Returns:
            List of dicts with code, name, county_code, county.
        """
        results = []
        for code in sorted(self._by_code.keys()):
            info = self.get(code)
            if info:
                results.append(info)
        return results

    def list_by_county(self, county_code: str) -> List[Dict[str, str]]:
        """List municipalities in a specific county.

        Args:
            county_code: 2-digit county code, e.g. "01" for Stockholm.

        Returns:
            List of municipality info dicts.
        """
        return [
            info for info in self.list_all()
            if info["county_code"] == county_code
        ]

    @property
    def counties(self) -> Dict[str, str]:
        """Get all county codes and names."""
        return dict(_COUNTIES)


# ---------------------------------------------------------------------------
# Bolagsverket URL helpers
# ---------------------------------------------------------------------------


def bolagsverket_search_url(org_number: str) -> str:
    """Build a Bolagsverket search URL for an organization number.

    Args:
        org_number: Organization number.

    Returns:
        URL string for the Bolagsverket naringsliv search.
    """
    cleaned = re.sub(r"[\s\-]", "", org_number)
    return f"https://www.allabolag.se/{cleaned}"


def riksdagen_document_url(dok_id: str) -> str:
    """Build a URL to a Riksdag document page.

    Args:
        dok_id: Riksdag document ID.

    Returns:
        URL to the document on riksdagen.se.
    """
    return f"https://www.riksdagen.se/sv/dokument-och-lagar/dokument/_/{dok_id}/"


def jo_search_url(query: str) -> str:
    """Build a URL to search JO decisions.

    Args:
        query: Search query or diarienummer.

    Returns:
        URL to JO search page.
    """
    from urllib.parse import quote
    return f"https://www.jo.se/sv/sok/?query={quote(query)}"


def scb_table_url(table_id: str) -> str:
    """Build a URL to view an SCB table in the web interface.

    Args:
        table_id: SCB table ID.

    Returns:
        URL to the SCB statistics database.
    """
    return f"https://www.statistikdatabasen.scb.se/pxweb/sv/ssd/{table_id}/"
