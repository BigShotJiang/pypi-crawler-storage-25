"""Swedish Personnummer (Personal Identity Number) Validator and Utilities.

Stdlib-only implementation for validating, parsing, formatting, masking, and
extracting Swedish personal identity numbers (personnummer) and coordination
numbers (samordningsnummer).

Supports both 10-digit (YYMMDD-XXXX) and 12-digit (YYYYMMDD-XXXX) formats.

Usage:
    from data_cleaner.swedish.personnummer import (
        validate_personnummer,
        format_personnummer,
        mask_personnummer,
        extract_personnummer,
        luhn_checksum,
        PersonnummerResult,
    )

    result = validate_personnummer("198505151234")
    print(result.valid)               # True/False
    print(result.birth_date)          # date(1985, 5, 15)
    print(result.gender)              # "M" or "F"
    print(result.is_samordningsnummer) # False

    masked = mask_personnummer("19850515-1234")
    # "19850515-****"

    found = extract_personnummer("Person 8505151234 listed here")
    # ["8505151234"]

    formatted = format_personnummer("8505151234", use_12_digits=True)
    # "19850515-1234"
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Matches 10- or 12-digit personnummer with optional separator (- or +)
_PNR_FULL_PATTERN = re.compile(
    r"^(\d{2})?(\d{2})(\d{2})(\d{2})([-+]?)(\d{4})$"
)

# Pattern for extracting personnummer candidates from free text
_PNR_TEXT_PATTERN = re.compile(r"\b(\d{6,8}[-+]?\d{4})\b")


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class PersonnummerResult:
    """Validation and parsing result for a Swedish personnummer."""

    valid: bool = False
    normalized: str = ""
    birth_date: Optional[date] = None
    age: Optional[int] = None
    gender: Optional[str] = None  # "M" or "F"
    is_samordningsnummer: bool = False
    error: Optional[str] = None

    def to_dict(self) -> dict:
        """Serialize to a plain dict (JSON-friendly)."""
        return {
            "valid": self.valid,
            "normalized": self.normalized,
            "birth_date": self.birth_date.isoformat() if self.birth_date else None,
            "age": self.age,
            "gender": self.gender,
            "is_samordningsnummer": self.is_samordningsnummer,
            "error": self.error,
        }


# ---------------------------------------------------------------------------
# Luhn algorithm
# ---------------------------------------------------------------------------


def luhn_checksum(digits: str) -> int:
    """Calculate Luhn mod-10 checksum for a digit string.

    Processes digits from right to left. Doubles every second digit
    (from the rightmost), subtracting 9 if the result exceeds 9.

    Args:
        digits: String of digits to checksum.

    Returns:
        Checksum value (0 means valid).

    Raises:
        ValueError: If *digits* contains non-digit characters.
    """
    if not digits.isdigit():
        raise ValueError(f"Expected only digits, got: {digits!r}")

    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:  # Double every second digit from right
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_century(yy: str, separator: str) -> int:
    """Determine the full year from a 2-digit year and separator.

    In Swedish convention a '+' separator means the person is 100+ years old.
    Without a century prefix we assume 1900 or 2000 based on current year.

    Args:
        yy: Two-digit year string.
        separator: '-' or '+' (or empty).

    Returns:
        Four-digit year.
    """
    current_year = datetime.now().year
    yy_int = int(yy)

    if separator == "+":
        # '+' indicates the person has turned 100
        candidate = 1900 + yy_int
        if candidate + 100 > current_year:
            candidate = 1800 + yy_int
        return candidate

    # Default: pick century so the date is not in the future
    candidate_2000 = 2000 + yy_int
    if candidate_2000 <= current_year:
        return candidate_2000
    return 1900 + yy_int


def _calculate_age(birth: date) -> int:
    """Calculate age in whole years from a birth date to today."""
    today = date.today()
    return today.year - birth.year - (
        (today.month, today.day) < (birth.month, birth.day)
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def validate_personnummer(number: str) -> PersonnummerResult:
    """Validate and parse a Swedish personnummer.

    Accepts 10-digit (YYMMDD-XXXX or YYMMDDXXXX) and 12-digit
    (YYYYMMDDXXXX or YYYYMMDD-XXXX) formats. The '+' separator is
    accepted in the 10-digit form to indicate age >= 100.

    Checks:
        - Format (digit count and structure)
        - Luhn algorithm on the 10-digit representation
        - Month 1-12, day 1-31 (or 61-91 for samordningsnummer)
        - Birth date existence

    Args:
        number: Personal identity number string.

    Returns:
        PersonnummerResult with all extracted information.
    """
    cleaned = re.sub(r"\s", "", number)
    match = _PNR_FULL_PATTERN.match(cleaned)

    if not match:
        return PersonnummerResult(error="Invalid format")

    century_prefix = match.group(1) or ""
    yy = match.group(2)
    mm = match.group(3)
    dd = match.group(4)
    separator = match.group(5) or "-"
    last_four = match.group(6)

    # Determine full year
    if century_prefix:
        full_year = int(century_prefix + yy)
    else:
        full_year = _resolve_century(yy, separator)

    # 10-digit representation for Luhn
    digits_10 = f"{full_year % 100:02d}{mm}{dd}{last_four}"

    if luhn_checksum(digits_10) != 0:
        return PersonnummerResult(
            normalized=f"{full_year}{mm}{dd}-{last_four}",
            error="Invalid checksum (Luhn)",
        )

    # Month validation
    month = int(mm)
    if not 1 <= month <= 12:
        return PersonnummerResult(
            normalized=f"{full_year}{mm}{dd}-{last_four}",
            error=f"Invalid month: {month}",
        )

    # Day and samordningsnummer detection
    raw_day = int(dd)
    is_samordning = raw_day > 60
    actual_day = raw_day - 60 if is_samordning else raw_day

    if not 1 <= actual_day <= 31:
        return PersonnummerResult(
            normalized=f"{full_year}{mm}{dd}-{last_four}",
            error=f"Invalid day: {raw_day}",
        )

    # Birth date validation
    try:
        birth = date(full_year, month, actual_day)
    except ValueError as exc:
        return PersonnummerResult(
            normalized=f"{full_year}{mm}{dd}-{last_four}",
            error=f"Invalid date: {exc}",
        )

    # Gender: second-to-last digit (index 2 of last_four), odd = M, even = F
    gender_digit = int(last_four[2])
    gender = "M" if gender_digit % 2 == 1 else "F"

    return PersonnummerResult(
        valid=True,
        normalized=f"{full_year}{mm}{dd}-{last_four}",
        birth_date=birth,
        age=_calculate_age(birth),
        gender=gender,
        is_samordningsnummer=is_samordning,
    )


def mask_personnummer(number: str, keep_last: int = 4) -> str:
    """Mask a personnummer for privacy-safe display.

    Replaces the last *keep_last* digits with asterisks while preserving
    the date part and separator.

    Examples:
        >>> mask_personnummer("19850515-1234")
        '19850515-****'
        >>> mask_personnummer("850515-1234", keep_last=0)
        '850515-****'

    Args:
        number: Personnummer string.
        keep_last: Number of trailing digits to keep visible.
            Clamped to 0-4. Default 4 masks all of the last group.

    Returns:
        Masked string, or '****' if the format is unrecognizable.
    """
    cleaned = re.sub(r"\s", "", number)
    match = _PNR_FULL_PATTERN.match(cleaned)

    if not match:
        return "****"

    century_prefix = match.group(1) or ""
    yy = match.group(2)
    mm = match.group(3)
    dd = match.group(4)
    last_four = match.group(6)

    keep_last = max(0, min(keep_last, 4))
    masked_part = "*" * keep_last + last_four[keep_last:]

    return f"{century_prefix}{yy}{mm}{dd}-{masked_part}"


def extract_personnummer(text: str) -> List[str]:
    """Extract valid personnummer from free text.

    Finds all substrings matching personnummer patterns and returns those
    that pass Luhn validation.

    Args:
        text: Free-form text to search.

    Returns:
        List of matching personnummer strings (as they appear in text).
    """
    candidates = _PNR_TEXT_PATTERN.findall(text)
    results: List[str] = []
    for candidate in candidates:
        result = validate_personnummer(candidate)
        if result.valid:
            results.append(candidate)
    return results


def format_personnummer(number: str, use_12_digits: bool = True) -> str:
    """Normalize a personnummer to a standard format.

    Args:
        number: Raw personnummer string.
        use_12_digits: If True, return YYYYMMDD-XXXX (12+dash).
            If False, return YYMMDD-XXXX (10+dash).

    Returns:
        Formatted string, or the original input if parsing fails.
    """
    result = validate_personnummer(number)
    if not result.valid:
        return number

    # normalized is always YYYYMMDD-XXXX
    if use_12_digits:
        return result.normalized

    # Strip century prefix for 10-digit form
    return result.normalized[2:]
