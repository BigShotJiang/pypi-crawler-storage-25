"""HTML Converter.

HTML processing with sanitization, text extraction, and conversion to
Markdown or plain text. Includes element creation helpers and a simple
CSS-selector content extractor. Uses only the Python standard library.

Inspired by:
    - Aggregator: html_converter (html.parser-based processing pipeline)

Usage:
    from data_cleaner.html_converter import HTMLConverter, HTMLDocument

    converter = HTMLConverter()

    # Parse HTML and extract metadata
    doc = converter.parse(html_text)
    print(doc.title, doc.meta, doc.headings)

    # Convert to plain text
    text = converter.to_text(html_text)

    # Sanitize untrusted HTML
    safe = converter.sanitize(untrusted_html)
"""

import re
from dataclasses import dataclass, field
from html import escape, unescape
from html.parser import HTMLParser
from typing import Any, Dict, List, Optional, Set, Tuple


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class HTMLElement:
    """Parsed HTML element.

    Attributes:
        tag: Tag name (lowercase).
        attrs: Element attributes.
        content: Text content.
        children: Child elements.
    """
    tag: str
    attrs: Dict[str, str] = field(default_factory=dict)
    content: str = ""
    children: List["HTMLElement"] = field(default_factory=list)


@dataclass
class HTMLDocument:
    """Parsed HTML document with extracted metadata.

    Attributes:
        body: Body content (or full content if no body tag).
        title: Document title from <title> tag.
        meta: Meta tag values (name/property -> content).
        headings: List of (level, text) tuples.
        links: List of (text, url) tuples.
        images: List of (alt, src) tuples.
    """
    body: str
    title: Optional[str] = None
    meta: Dict[str, str] = field(default_factory=dict)
    headings: List[Tuple[int, str]] = field(default_factory=list)
    links: List[Tuple[str, str]] = field(default_factory=list)
    images: List[Tuple[str, str]] = field(default_factory=list)


@dataclass
class SanitizeOptions:
    """Options for HTML sanitization.

    Attributes:
        allowed_tags: Set of allowed tag names.
        allowed_attrs: Dict of allowed attributes per tag.
        strip_comments: Remove HTML comments.
        strip_cdata: Remove CDATA sections.
        allow_data_attrs: Allow data-* attributes.
        escape_disallowed: Escape disallowed tags instead of removing.
    """
    allowed_tags: Optional[Set[str]] = None
    allowed_attrs: Optional[Dict[str, Set[str]]] = None
    strip_comments: bool = True
    strip_cdata: bool = True
    allow_data_attrs: bool = False
    escape_disallowed: bool = False


# =============================================================================
# HTML Parser
# =============================================================================

class HTMLContentParser(HTMLParser):
    """Custom HTML parser for content extraction."""

    def __init__(self) -> None:
        super().__init__()
        self.elements: List[Dict[str, Any]] = []
        self.current_data: List[str] = []
        self.tag_stack: List[str] = []

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        self.tag_stack.append(tag)
        self.elements.append({
            'type': 'start',
            'tag': tag,
            'attrs': {k: v or '' for k, v in attrs},
        })

    def handle_endtag(self, tag: str) -> None:
        if self.tag_stack and self.tag_stack[-1] == tag:
            self.tag_stack.pop()
        self.elements.append({
            'type': 'end',
            'tag': tag,
        })

    def handle_data(self, data: str) -> None:
        if data.strip():
            self.elements.append({
                'type': 'text',
                'content': data,
            })

    def handle_startendtag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        self.elements.append({
            'type': 'self_closing',
            'tag': tag,
            'attrs': {k: v or '' for k, v in attrs},
        })

    def handle_comment(self, data: str) -> None:
        self.elements.append({
            'type': 'comment',
            'content': data,
        })


# =============================================================================
# Main Converter
# =============================================================================

class HTMLConverter:
    """HTML content converter and parser.

    Supports:
    - HTML to plain text extraction
    - HTML to Markdown conversion
    - HTML structure parsing
    - Content sanitization
    - Element creation
    """

    # Block elements that should have newlines
    BLOCK_ELEMENTS = {
        'p', 'div', 'section', 'article', 'header', 'footer', 'main', 'aside', 'nav',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'ul', 'ol', 'li', 'dl', 'dt', 'dd',
        'blockquote', 'pre', 'figure', 'figcaption',
        'table', 'tr', 'form', 'hr', 'br', 'address',
    }

    # Elements to strip completely (including content)
    STRIP_ELEMENTS = {
        'script', 'style', 'noscript', 'iframe', 'object', 'embed',
        'applet', 'frame', 'frameset', 'template',
    }

    # Allowed tags for basic sanitization
    SAFE_TAGS = {
        'p', 'br', 'hr',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'strong', 'b', 'em', 'i', 'u', 's', 'del', 'ins', 'mark', 'sub', 'sup',
        'a', 'img',
        'ul', 'ol', 'li', 'dl', 'dt', 'dd',
        'blockquote', 'pre', 'code', 'kbd', 'samp', 'var',
        'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption',
        'div', 'span', 'section', 'article', 'header', 'footer', 'main', 'aside', 'nav',
        'figure', 'figcaption', 'details', 'summary',
        'abbr', 'cite', 'q', 'time', 'address',
    }

    # Allowed attributes per tag
    SAFE_ATTRS: Dict[str, Set[str]] = {
        'a': {'href', 'title', 'target', 'rel'},
        'img': {'src', 'alt', 'title', 'width', 'height', 'loading'},
        'td': {'colspan', 'rowspan'},
        'th': {'colspan', 'rowspan', 'scope'},
        'time': {'datetime'},
        'abbr': {'title'},
        'q': {'cite'},
        'blockquote': {'cite'},
        'ol': {'start', 'type', 'reversed'},
        'li': {'value'},
        'details': {'open'},
    }

    # Dangerous URL schemes
    DANGEROUS_SCHEMES = {'javascript', 'vbscript', 'data', 'file'}

    def __init__(self, safe_mode: bool = True):
        """Initialize converter.

        Args:
            safe_mode: Enable HTML sanitization by default.
        """
        self.safe_mode = safe_mode

    # -------------------------------------------------------------------------
    # Parsing
    # -------------------------------------------------------------------------

    def parse(self, html: str) -> HTMLDocument:
        """Parse HTML document and extract structure.

        Args:
            html: HTML content.

        Returns:
            HTMLDocument with parsed data.
        """
        # Extract title
        title = None
        title_match = re.search(
            r'<title[^>]*>(.*?)</title>',
            html, re.IGNORECASE | re.DOTALL,
        )
        if title_match:
            title = self._strip_tags(title_match.group(1)).strip()

        # Extract meta tags
        meta: Dict[str, str] = {}
        for match in re.finditer(r'<meta\s+([^>]+)/?\s*>', html, re.IGNORECASE):
            attrs = self._parse_attributes(match.group(1))
            name = attrs.get('name', attrs.get('property', ''))
            content = attrs.get('content', '')
            if name and content:
                meta[name] = content

        # Extract body content
        body_match = re.search(
            r'<body[^>]*>(.*?)</body>',
            html, re.IGNORECASE | re.DOTALL,
        )
        body = body_match.group(1) if body_match else html

        # Extract headings
        headings: List[Tuple[int, str]] = []
        for match in re.finditer(
            r'<h([1-6])[^>]*>(.*?)</h\1>',
            body, re.IGNORECASE | re.DOTALL,
        ):
            level = int(match.group(1))
            text = self._strip_tags(match.group(2)).strip()
            if text:
                headings.append((level, text))

        # Extract links
        links: List[Tuple[str, str]] = []
        for match in re.finditer(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            body, re.IGNORECASE | re.DOTALL,
        ):
            url = match.group(1)
            text = self._strip_tags(match.group(2)).strip()
            links.append((text, url))

        # Extract images
        images: List[Tuple[str, str]] = []
        for match in re.finditer(
            r'<img[^>]*src=["\']([^"\']+)["\'][^>]*>',
            body, re.IGNORECASE,
        ):
            src = match.group(1)
            alt_match = re.search(
                r'alt=["\']([^"\']*)["\']',
                match.group(0), re.IGNORECASE,
            )
            alt = alt_match.group(1) if alt_match else ''
            images.append((alt, src))

        return HTMLDocument(
            body=body,
            title=title,
            meta=meta,
            headings=headings,
            links=links,
            images=images,
        )

    def _parse_attributes(self, attr_string: str) -> Dict[str, str]:
        """Parse HTML attributes from string."""
        attrs: Dict[str, str] = {}
        for match in re.finditer(r'(\w+(?:-\w+)*)=["\']([^"\']*)["\']', attr_string):
            attrs[match.group(1).lower()] = match.group(2)
        return attrs

    # -------------------------------------------------------------------------
    # Conversion
    # -------------------------------------------------------------------------

    def to_text(self, html: str) -> str:
        """Convert HTML to plain text.

        Args:
            html: HTML content.

        Returns:
            Plain text.
        """
        result = html

        # Remove scripts, styles, etc.
        for tag in self.STRIP_ELEMENTS:
            result = re.sub(
                f'<{tag}[^>]*>.*?</{tag}>',
                '', result, flags=re.IGNORECASE | re.DOTALL,
            )

        # Remove comments
        result = re.sub(r'<!--.*?-->', '', result, flags=re.DOTALL)

        # Handle block elements - add newlines
        for tag in self.BLOCK_ELEMENTS:
            result = re.sub(f'<{tag}[^>]*>', '\n', result, flags=re.IGNORECASE)
            result = re.sub(f'</{tag}>', '\n', result, flags=re.IGNORECASE)

        # Handle br and hr
        result = re.sub(r'<br\s*/?>', '\n', result, flags=re.IGNORECASE)
        result = re.sub(r'<hr\s*/?>', '\n---\n', result, flags=re.IGNORECASE)

        # Handle list items
        result = re.sub(r'<li[^>]*>', '\n\u2022 ', result, flags=re.IGNORECASE)

        # Remove all remaining tags
        result = re.sub(r'<[^>]+>', '', result)

        # Decode entities
        result = unescape(result)

        # Clean up whitespace
        result = re.sub(r'[ \t]+', ' ', result)
        result = re.sub(r'\n{3,}', '\n\n', result)
        result = re.sub(r'^\s+', '', result, flags=re.MULTILINE)

        return result.strip()

    def to_markdown(self, html: str) -> str:
        """Convert HTML to Markdown.

        Args:
            html: HTML content.

        Returns:
            Markdown text.
        """
        result = html

        # Remove scripts, styles, etc.
        for tag in self.STRIP_ELEMENTS:
            result = re.sub(
                f'<{tag}[^>]*>.*?</{tag}>',
                '', result, flags=re.IGNORECASE | re.DOTALL,
            )

        # Remove comments
        result = re.sub(r'<!--.*?-->', '', result, flags=re.DOTALL)

        # Headings
        for i in range(1, 7):
            pattern = re.compile(f'<h{i}[^>]*>(.*?)</h{i}>', re.IGNORECASE | re.DOTALL)
            result = pattern.sub(
                lambda m, lvl=i: f'{"#" * lvl} {self._strip_tags(m.group(1))}\n\n',
                result,
            )

        # Paragraphs
        result = re.sub(
            r'<p[^>]*>(.*?)</p>',
            lambda m: f'{self._strip_tags(m.group(1))}\n\n',
            result, flags=re.DOTALL | re.IGNORECASE,
        )

        # Bold
        result = re.sub(
            r'<strong[^>]*>(.*?)</strong>',
            r'**\1**', result, flags=re.IGNORECASE | re.DOTALL,
        )
        result = re.sub(
            r'<b[^>]*>(.*?)</b>',
            r'**\1**', result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Italic
        result = re.sub(
            r'<em[^>]*>(.*?)</em>',
            r'*\1*', result, flags=re.IGNORECASE | re.DOTALL,
        )
        result = re.sub(
            r'<i[^>]*>(.*?)</i>',
            r'*\1*', result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Strikethrough
        result = re.sub(
            r'<del[^>]*>(.*?)</del>',
            r'~~\1~~', result, flags=re.IGNORECASE | re.DOTALL,
        )
        result = re.sub(
            r'<s[^>]*>(.*?)</s>',
            r'~~\1~~', result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Links
        result = re.sub(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            lambda m: f'[{self._strip_tags(m.group(2))}]({m.group(1)})',
            result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Images
        result = re.sub(
            r'<img[^>]*src=["\']([^"\']+)["\'][^>]*alt=["\']([^"\']*)["\'][^>]*/?>',
            r'![\2](\1)', result, flags=re.IGNORECASE,
        )
        result = re.sub(
            r'<img[^>]*src=["\']([^"\']+)["\'][^>]*/?>',
            r'![](\1)', result, flags=re.IGNORECASE,
        )

        # Inline code
        result = re.sub(
            r'<code[^>]*>(.*?)</code>',
            r'`\1`', result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Code blocks
        def convert_pre(match: re.Match) -> str:
            code = match.group(1)
            lang_match = re.search(
                r'class=["\'][^"\']*language-(\w+)',
                match.group(0), re.IGNORECASE,
            )
            lang = lang_match.group(1) if lang_match else ''
            code = re.sub(r'</?code[^>]*>', '', code, flags=re.IGNORECASE)
            code = unescape(code)
            return f'```{lang}\n{code}\n```\n\n'

        result = re.sub(
            r'<pre[^>]*>(.*?)</pre>',
            convert_pre, result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Blockquotes
        def convert_blockquote(match: re.Match) -> str:
            content = self._strip_tags(match.group(1))
            bq_lines = content.strip().split('\n')
            return '\n'.join(f'> {ln}' for ln in bq_lines) + '\n\n'

        result = re.sub(
            r'<blockquote[^>]*>(.*?)</blockquote>',
            convert_blockquote, result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Lists
        def convert_list(match: re.Match) -> str:
            list_type = match.group(1).lower()
            content = match.group(2)
            items = re.findall(
                r'<li[^>]*>(.*?)</li>',
                content, re.IGNORECASE | re.DOTALL,
            )
            lines: List[str] = []
            for idx, item in enumerate(items):
                prefix = '-' if list_type == 'ul' else f'{idx + 1}.'
                lines.append(f'{prefix} {self._strip_tags(item).strip()}')
            return '\n'.join(lines) + '\n\n'

        result = re.sub(
            r'<(ul|ol)[^>]*>(.*?)</\1>',
            convert_list, result, flags=re.IGNORECASE | re.DOTALL,
        )

        # Horizontal rules
        result = re.sub(r'<hr\s*/?>', '\n---\n\n', result, flags=re.IGNORECASE)

        # Line breaks
        result = re.sub(r'<br\s*/?>', '\n', result, flags=re.IGNORECASE)

        # Remove remaining tags
        result = re.sub(r'<[^>]+>', '', result)

        # Clean up whitespace
        result = re.sub(r'\n{3,}', '\n\n', result)
        result = unescape(result)

        return result.strip()

    # -------------------------------------------------------------------------
    # Sanitization
    # -------------------------------------------------------------------------

    def sanitize(
        self,
        html: str,
        allowed_tags: Optional[Set[str]] = None,
        allowed_attrs: Optional[Dict[str, Set[str]]] = None,
        options: Optional[SanitizeOptions] = None,
    ) -> str:
        """Sanitize HTML by removing unsafe elements.

        Args:
            html: HTML content.
            allowed_tags: Set of allowed tag names.
            allowed_attrs: Dict of allowed attributes per tag.
            options: Sanitization options.

        Returns:
            Sanitized HTML.
        """
        options = options or SanitizeOptions()
        allowed_tags = allowed_tags or options.allowed_tags or self.SAFE_TAGS
        allowed_attrs = allowed_attrs or options.allowed_attrs or self.SAFE_ATTRS

        result = html

        # Remove comments
        if options.strip_comments:
            result = re.sub(r'<!--.*?-->', '', result, flags=re.DOTALL)

        # Remove CDATA
        if options.strip_cdata:
            result = re.sub(r'<!\[CDATA\[.*?\]\]>', '', result, flags=re.DOTALL)

        # Remove dangerous elements completely
        for tag in self.STRIP_ELEMENTS:
            result = re.sub(
                f'<{tag}[^>]*>.*?</{tag}>',
                '', result, flags=re.IGNORECASE | re.DOTALL,
            )

        # Process all tags
        def process_tag(match: re.Match) -> str:
            full_tag = match.group(0)
            is_closing = full_tag.startswith('</')

            if is_closing:
                tag_name = match.group(1).lower()
                if tag_name in allowed_tags:
                    return f'</{tag_name}>'
                if options.escape_disallowed:
                    return escape(full_tag)
                return ''

            # Extract tag name and attributes
            tag_match = re.match(r'<(\w+)([^>]*?)(/?)>', full_tag)
            if not tag_match:
                return ''

            tag_name = tag_match.group(1).lower()
            attrs_str = tag_match.group(2)
            is_self_closing = bool(tag_match.group(3))

            if tag_name not in allowed_tags:
                if options.escape_disallowed:
                    return escape(full_tag)
                return ''

            # Filter attributes
            safe_attrs_for_tag = allowed_attrs.get(tag_name, set())
            new_attrs: List[str] = []

            for attr_match in re.finditer(
                r'(\w+(?:-\w+)*)=["\']([^"\']*)["\']',
                attrs_str,
            ):
                attr_name = attr_match.group(1).lower()
                attr_value = attr_match.group(2)

                is_allowed = attr_name in safe_attrs_for_tag
                is_data_attr = attr_name.startswith('data-') and options.allow_data_attrs

                if is_allowed or is_data_attr:
                    if attr_name in ('href', 'src', 'action'):
                        if self._is_dangerous_url(attr_value):
                            continue
                    new_attrs.append(f'{attr_name}="{escape(attr_value)}"')

            attrs_part = ' ' + ' '.join(new_attrs) if new_attrs else ''
            closing = ' /' if is_self_closing else ''

            return f'<{tag_name}{attrs_part}{closing}>'

        # Process opening and self-closing tags
        result = re.sub(r'<(\w+)([^>]*?)/?>', process_tag, result)
        # Process closing tags
        result = re.sub(r'</(\w+)>', process_tag, result)

        return result

    def _is_dangerous_url(self, url: str) -> bool:
        """Check if URL uses a dangerous scheme."""
        url_lower = url.lower().strip()
        for scheme in self.DANGEROUS_SCHEMES:
            if url_lower.startswith(f'{scheme}:'):
                return True
        return False

    def strip_tags(self, html: str) -> str:
        """Remove all HTML tags, keeping only text content.

        Args:
            html: HTML content.

        Returns:
            Text without HTML tags.
        """
        return self._strip_tags(html)

    def _strip_tags(self, html: str) -> str:
        """Remove all HTML tags."""
        text = re.sub(r'<[^>]+>', '', html)
        return unescape(text)

    # -------------------------------------------------------------------------
    # Content Extraction
    # -------------------------------------------------------------------------

    def extract_text_content(
        self,
        html: str,
        selector: Optional[str] = None,
    ) -> str:
        """Extract text content from HTML, optionally from specific elements.

        Supports simple CSS selectors: tag name, .class, #id.

        Args:
            html: HTML content.
            selector: Simple CSS selector (tag, .class, #id).

        Returns:
            Extracted text.
        """
        content = html

        if selector:
            if selector.startswith('#'):
                id_val = selector[1:]
                pattern = rf'<\w+[^>]*id=["\']?{re.escape(id_val)}["\']?[^>]*>(.*?)</\w+>'
                match = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
                content = match.group(1) if match else ''
            elif selector.startswith('.'):
                class_val = selector[1:]
                pattern = rf'<\w+[^>]*class=["\'][^"\']*\b{re.escape(class_val)}\b[^"\']*["\'][^>]*>(.*?)</\w+>'
                matches = re.findall(pattern, html, re.IGNORECASE | re.DOTALL)
                content = '\n'.join(matches)
            else:
                pattern = rf'<{re.escape(selector)}[^>]*>(.*?)</{re.escape(selector)}>'
                matches = re.findall(pattern, html, re.IGNORECASE | re.DOTALL)
                content = '\n'.join(matches)

        return self.to_text(content)

    def extract_attribute(
        self,
        html: str,
        tag: str,
        attribute: str,
    ) -> List[str]:
        """Extract attribute values from matching tags.

        Args:
            html: HTML content.
            tag: Tag name to match.
            attribute: Attribute name to extract.

        Returns:
            List of attribute values.
        """
        pattern = rf'<{re.escape(tag)}[^>]*{re.escape(attribute)}=["\']([^"\']*)["\'][^>]*>'
        return re.findall(pattern, html, re.IGNORECASE)

    # -------------------------------------------------------------------------
    # Element Creation
    # -------------------------------------------------------------------------

    def wrap_content(
        self,
        content: str,
        tag: str = 'div',
        attrs: Optional[Dict[str, str]] = None,
    ) -> str:
        """Wrap content in an HTML tag.

        Args:
            content: Content to wrap.
            tag: Tag name.
            attrs: Tag attributes.

        Returns:
            Wrapped HTML.
        """
        attrs_str = ''
        if attrs:
            attrs_str = ' ' + ' '.join(
                f'{k}="{escape(str(v))}"' for k, v in attrs.items()
            )
        return f'<{tag}{attrs_str}>{content}</{tag}>'

    def create_element(
        self,
        tag: str,
        content: str = '',
        attrs: Optional[Dict[str, str]] = None,
        self_closing: bool = False,
    ) -> str:
        """Create an HTML element.

        Args:
            tag: Tag name.
            content: Element content.
            attrs: Element attributes.
            self_closing: Whether to create self-closing tag.

        Returns:
            HTML element string.
        """
        attrs_str = ''
        if attrs:
            attrs_str = ' ' + ' '.join(
                f'{k}="{escape(str(v))}"' for k, v in attrs.items()
            )

        if self_closing:
            return f'<{tag}{attrs_str} />'
        return f'<{tag}{attrs_str}>{content}</{tag}>'

    def create_link(
        self,
        url: str,
        text: str,
        attrs: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create an HTML link.

        Args:
            url: Link URL.
            text: Link text.
            attrs: Additional attributes.

        Returns:
            HTML anchor element.
        """
        all_attrs = {'href': url}
        if attrs:
            all_attrs.update(attrs)
        return self.wrap_content(escape(text), 'a', all_attrs)

    def create_image(
        self,
        src: str,
        alt: str = '',
        attrs: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create an HTML image tag.

        Args:
            src: Image source URL.
            alt: Alt text.
            attrs: Additional attributes.

        Returns:
            HTML img element.
        """
        all_attrs = {'src': src, 'alt': alt}
        if attrs:
            all_attrs.update(attrs)
        return self.create_element('img', attrs=all_attrs, self_closing=True)

    def create_list(
        self,
        items: List[str],
        ordered: bool = False,
        attrs: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create an HTML list.

        Args:
            items: List items.
            ordered: Use ordered list (ol) instead of unordered (ul).
            attrs: List attributes.

        Returns:
            HTML list element.
        """
        tag = 'ol' if ordered else 'ul'
        li_items = '\n'.join(f'<li>{item}</li>' for item in items)
        return self.wrap_content(li_items, tag, attrs)

    def create_table(
        self,
        headers: List[str],
        rows: List[List[str]],
        attrs: Optional[Dict[str, str]] = None,
    ) -> str:
        """Create an HTML table.

        Args:
            headers: Table headers.
            rows: Table rows (list of lists).
            attrs: Table attributes.

        Returns:
            HTML table element.
        """
        th_cells = ''.join(f'<th>{escape(h)}</th>' for h in headers)
        thead = f'<thead><tr>{th_cells}</tr></thead>'

        body_rows: List[str] = []
        for row in rows:
            td_cells = ''.join(f'<td>{escape(str(c))}</td>' for c in row)
            body_rows.append(f'<tr>{td_cells}</tr>')
        tbody = f'<tbody>{"".join(body_rows)}</tbody>'

        return self.wrap_content(thead + tbody, 'table', attrs)

    # -------------------------------------------------------------------------
    # Utilities
    # -------------------------------------------------------------------------

    def minify(self, html: str) -> str:
        """Minify HTML by removing unnecessary whitespace.

        Args:
            html: HTML content.

        Returns:
            Minified HTML.
        """
        result = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)
        result = re.sub(r'>\s+<', '><', result)
        result = re.sub(r'\s+', ' ', result)
        return result.strip()

    def prettify(self, html: str, indent: str = '  ') -> str:
        """Format HTML with proper indentation (basic).

        Args:
            html: HTML content.
            indent: Indentation string.

        Returns:
            Formatted HTML.
        """
        result = html

        # Add newlines after block elements
        for tag in self.BLOCK_ELEMENTS:
            result = re.sub(f'(<{tag}[^>]*>)', r'\n\1', result, flags=re.IGNORECASE)
            result = re.sub(f'(</{tag}>)', r'\1\n', result, flags=re.IGNORECASE)

        lines = result.split('\n')
        formatted: List[str] = []
        level = 0

        for line in lines:
            line = line.strip()
            if not line:
                continue

            close_match = re.match(r'^</(\w+)>', line)
            if close_match and close_match.group(1).lower() in self.BLOCK_ELEMENTS:
                level = max(0, level - 1)

            formatted.append(indent * level + line)

            for match in re.finditer(r'<(\w+)[^>]*>', line):
                tag = match.group(1).lower()
                if tag in self.BLOCK_ELEMENTS:
                    if not re.search(rf'</{tag}>', line, re.IGNORECASE):
                        level += 1

        return '\n'.join(formatted)


# =============================================================================
# Convenience Functions
# =============================================================================

def html_to_text(html: str) -> str:
    """Convert HTML to plain text.

    Args:
        html: HTML content.

    Returns:
        Plain text.
    """
    converter = HTMLConverter()
    return converter.to_text(html)


def html_to_markdown(html: str) -> str:
    """Convert HTML to Markdown.

    Args:
        html: HTML content.

    Returns:
        Markdown text.
    """
    converter = HTMLConverter()
    return converter.to_markdown(html)


def sanitize_html(
    html: str,
    allowed_tags: Optional[Set[str]] = None,
) -> str:
    """Sanitize HTML by removing unsafe elements.

    Args:
        html: HTML content.
        allowed_tags: Set of allowed tags.

    Returns:
        Sanitized HTML.
    """
    converter = HTMLConverter()
    return converter.sanitize(html, allowed_tags=allowed_tags)


def strip_html_tags(html: str) -> str:
    """Remove all HTML tags from content.

    Args:
        html: HTML content.

    Returns:
        Text without tags.
    """
    converter = HTMLConverter()
    return converter.strip_tags(html)


def parse_html(html: str) -> HTMLDocument:
    """Parse HTML and extract metadata.

    Args:
        html: HTML content.

    Returns:
        HTMLDocument.
    """
    converter = HTMLConverter()
    return converter.parse(html)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Classes
    "HTMLConverter",
    "HTMLDocument",
    "HTMLElement",
    "HTMLContentParser",
    "SanitizeOptions",
    # Functions
    "html_to_text",
    "html_to_markdown",
    "sanitize_html",
    "strip_html_tags",
    "parse_html",
]
