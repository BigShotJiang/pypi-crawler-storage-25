"""
validators.py — Rich input validation utilities.

All stdlib only: re, json, xml.etree.ElementTree, datetime, unicodedata.
Each validator returns a ValidationResult with valid, reason, and details.
"""

from __future__ import annotations

import json
import re
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


# ---------------------------------------------------------------------------
# Core result type
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Immutable-ish result returned by every validator."""
    valid: bool
    reason: str = ""
    details: dict = field(default_factory=dict)

    def __bool__(self) -> bool:
        return self.valid

    def __repr__(self) -> str:
        status = "OK" if self.valid else "FAIL"
        return f"ValidationResult({status}, reason={self.reason!r}, details={self.details})"


def _ok(reason: str = "Valid", **details) -> ValidationResult:
    return ValidationResult(valid=True, reason=reason, details=details)


def _fail(reason: str, **details) -> ValidationResult:
    return ValidationResult(valid=False, reason=reason, details=details)


# ---------------------------------------------------------------------------
# Luhn algorithm helper
# ---------------------------------------------------------------------------

def _luhn_check(digits: str) -> bool:
    """Return True if *digits* passes the Luhn checksum.

    Accepts a string of decimal digits (spaces/dashes already stripped).
    """
    if not digits.isdigit():
        return False
    total = 0
    reverse = digits[::-1]
    for i, ch in enumerate(reverse):
        n = int(ch)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

# RFC 5321-ish pattern — deliberately not full RFC 5322 to keep it readable.
_EMAIL_RE = re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+"
    r"@"
    r"[a-zA-Z0-9]"
    r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
    r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*"
    r"\.[a-zA-Z]{2,}$"
)


def validate_email(email: str, check_format_only: bool = True) -> ValidationResult:
    """Validate an e-mail address.

    Args:
        email: The address to validate.
        check_format_only: When True (default) only regex/format checks are run.
            Reserved for future DNS MX-record verification when False
            (not implemented — stdlib has no DNS resolver).

    Returns:
        ValidationResult
    """
    if not isinstance(email, str):
        return _fail("Input must be a string", input_type=type(email).__name__)

    email = email.strip()

    if not email:
        return _fail("Email address is empty")

    if len(email) > 254:
        return _fail("Email address exceeds maximum length of 254 characters", length=len(email))

    local, _, domain = email.rpartition("@")
    if not local:
        return _fail("Email address missing local part (before @)")
    if not domain:
        return _fail("Email address missing domain part (after @)")

    if len(local) > 64:
        return _fail("Local part exceeds 64 characters", local_length=len(local))

    if not _EMAIL_RE.match(email):
        return _fail("Email address format is invalid", email=email)

    parts = domain.split(".")
    tld = parts[-1]
    if len(tld) < 2:
        return _fail("Top-level domain is too short", tld=tld)

    return _ok("Email address format is valid", local=local, domain=domain, tld=tld)


# ---------------------------------------------------------------------------
# URL
# ---------------------------------------------------------------------------

_SCHEME_RE = re.compile(r"^([a-zA-Z][a-zA-Z0-9+\-.]*):\/\/", re.IGNORECASE)


def validate_url(
    url: str,
    require_https: bool = False,
    allowed_schemes: Optional[list] = None,
) -> ValidationResult:
    """Validate a URL.

    Args:
        url: The URL string to check.
        require_https: If True, only https:// is accepted.
        allowed_schemes: Whitelist of scheme names, e.g. ["http", "https"].
            Overrides *require_https* when provided.

    Returns:
        ValidationResult
    """
    if not isinstance(url, str):
        return _fail("Input must be a string")

    url = url.strip()
    if not url:
        return _fail("URL is empty")

    if len(url) > 2083:
        return _fail("URL exceeds maximum length of 2083 characters", length=len(url))

    m = _SCHEME_RE.match(url)
    if not m:
        return _fail("URL is missing a valid scheme (e.g. https://)", url=url)

    scheme = m.group(1).lower()

    if allowed_schemes is not None:
        allowed_lower = [s.lower() for s in allowed_schemes]
        if scheme not in allowed_lower:
            return _fail(
                f"Scheme '{scheme}' is not in the allowed list",
                scheme=scheme,
                allowed=allowed_lower,
            )
    elif require_https and scheme != "https":
        return _fail("Only HTTPS URLs are accepted", scheme=scheme)

    # Extract host — everything between :// and the first / ? #
    after_scheme = url[m.end():]
    host_part = re.split(r"[/?#]", after_scheme, maxsplit=1)[0]
    # Strip user-info
    if "@" in host_part:
        host_part = host_part.rsplit("@", 1)[1]
    # Strip port
    hostname = host_part.rsplit(":", 1)[0].strip("[]")  # [] for IPv6

    if not hostname:
        return _fail("URL is missing a host", url=url)

    return _ok("URL is valid", scheme=scheme, host=hostname)


# ---------------------------------------------------------------------------
# Phone (Swedish default)
# ---------------------------------------------------------------------------

# Swedish mobile: 07x-xxxxxxx or +46 7x xxxxxxx variations
_SE_MOBILE_RE = re.compile(r"^(?:\+46|0046|0)7[0-9][\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$")
# Swedish landline: 0x(x)-xxxxxxx
_SE_LAND_RE = re.compile(r"^(?:\+46|0046|0)[1-9][0-9]{0,2}[\s\-]?[0-9]{5,8}$")
# Generic E.164 (international)
_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")


def validate_phone(phone: str, country_code: str = "SE") -> ValidationResult:
    """Validate a phone number.

    Args:
        phone: Phone number string.
        country_code: ISO 3166-1 alpha-2 country code. Only "SE" has detailed
            rules; all others fall back to a generic E.164 check.

    Returns:
        ValidationResult
    """
    if not isinstance(phone, str):
        return _fail("Input must be a string")

    phone = phone.strip()
    if not phone:
        return _fail("Phone number is empty")

    digits_only = re.sub(r"[\s\-().+]", "", phone)
    if not digits_only.isdigit():
        return _fail("Phone number contains invalid characters", cleaned=digits_only)

    cc = (country_code or "SE").upper()

    if cc == "SE":
        if _SE_MOBILE_RE.match(phone):
            return _ok("Valid Swedish mobile number", country="SE", type="mobile")
        if _SE_LAND_RE.match(phone):
            return _ok("Valid Swedish landline number", country="SE", type="landline")
        return _fail(
            "Not a recognised Swedish phone number format",
            hint="Expected formats: 070-123 45 67, +46 70 123 45 67, 08-123 456",
        )

    # Generic: accept E.164 or a string of 7–15 digits
    if _E164_RE.match(phone) or (digits_only.isdigit() and 7 <= len(digits_only) <= 15):
        return _ok("Phone number appears valid (generic check)", country=cc)

    return _fail("Phone number failed generic validation", country=cc)


# ---------------------------------------------------------------------------
# IP addresses
# ---------------------------------------------------------------------------

def validate_ipv4(ip: str) -> ValidationResult:
    """Validate an IPv4 address in dotted-decimal notation."""
    if not isinstance(ip, str):
        return _fail("Input must be a string")
    ip = ip.strip()
    parts = ip.split(".")
    if len(parts) != 4:
        return _fail("IPv4 address must have exactly 4 octets", octets=len(parts))
    for part in parts:
        if not part.isdigit():
            return _fail(f"Octet '{part}' is not a decimal integer")
        value = int(part)
        if not (0 <= value <= 255):
            return _fail(f"Octet {value} is out of range 0–255")
        if part != str(value):  # reject leading zeros like 01
            return _fail(f"Octet '{part}' has a leading zero")
    return _ok("Valid IPv4 address", address=ip)


def validate_ipv6(ip: str) -> ValidationResult:
    """Validate an IPv6 address (full or compressed with ::)."""
    if not isinstance(ip, str):
        return _fail("Input must be a string")
    ip = ip.strip()

    # Allow bracket notation [::1]
    if ip.startswith("[") and ip.endswith("]"):
        ip = ip[1:-1]

    # Split on ::
    if ip.count("::") > 1:
        return _fail("IPv6 address contains more than one '::' sequence")

    if "::" in ip:
        left, right = ip.split("::", 1)
        left_groups = [g for g in left.split(":") if g]
        right_groups = [g for g in right.split(":") if g]
        total = len(left_groups) + len(right_groups)
        if total > 7:
            return _fail("IPv6 address has too many groups", groups=total + 1)
        groups = left_groups + ["0"] * (8 - total) + right_groups
    else:
        groups = ip.split(":")
        if len(groups) != 8:
            return _fail("IPv6 address must have exactly 8 groups", groups=len(groups))

    for g in groups:
        if not (1 <= len(g) <= 4 and all(c in "0123456789abcdefABCDEF" for c in g)):
            return _fail(f"Invalid IPv6 group: '{g}'")

    return _ok("Valid IPv6 address", address=ip.lower())


def validate_ip(ip: str) -> ValidationResult:
    """Auto-detect IPv4 vs IPv6 and validate accordingly."""
    if not isinstance(ip, str):
        return _fail("Input must be a string")
    candidate = ip.strip().strip("[]")
    if ":" in candidate:
        result = validate_ipv6(ip)
        if result.valid:
            result.details["version"] = 6
        return result
    result = validate_ipv4(ip)
    if result.valid:
        result.details["version"] = 4
    return result


# ---------------------------------------------------------------------------
# Structured text formats
# ---------------------------------------------------------------------------

def validate_json(text: str) -> ValidationResult:
    """Validate that *text* is well-formed JSON."""
    if not isinstance(text, str):
        return _fail("Input must be a string")
    if not text.strip():
        return _fail("Input is empty")
    try:
        parsed = json.loads(text)
        return _ok(
            "Valid JSON",
            root_type=type(parsed).__name__,
            length=len(text),
        )
    except json.JSONDecodeError as exc:
        return _fail(
            f"JSON parse error: {exc.msg}",
            line=exc.lineno,
            column=exc.colno,
            position=exc.pos,
        )


def validate_yaml(text: str) -> ValidationResult:
    """Validate that *text* is well-formed YAML.

    Uses PyYAML if available; falls back to a basic structural check when it
    is not installed (stdlib-only fallback).
    """
    if not isinstance(text, str):
        return _fail("Input must be a string")
    if not text.strip():
        return _fail("Input is empty")

    try:
        import yaml  # type: ignore

        try:
            yaml.safe_load(text)
            return _ok("Valid YAML", backend="pyyaml")
        except yaml.YAMLError as exc:
            return _fail(f"YAML parse error: {exc}", backend="pyyaml")

    except ImportError:
        # Basic structural heuristic: look for common YAML syntax errors
        lines = text.splitlines()
        for i, line in enumerate(lines, start=1):
            stripped = line.rstrip()
            # Tabs are not allowed as indentation in YAML
            if stripped and line[0] == "\t":
                return _fail(
                    "YAML indentation uses tab characters (not allowed)",
                    line=i,
                    backend="heuristic",
                )
        return _ok(
            "YAML appears structurally valid (basic check, pyyaml not installed)",
            backend="heuristic",
        )


def validate_xml(text: str) -> ValidationResult:
    """Validate that *text* is well-formed XML using stdlib ElementTree."""
    if not isinstance(text, str):
        return _fail("Input must be a string")
    if not text.strip():
        return _fail("Input is empty")
    try:
        root = ET.fromstring(text)
        child_count = len(list(root))
        return _ok("Valid XML", root_tag=root.tag, child_count=child_count)
    except ET.ParseError as exc:
        return _fail(f"XML parse error: {exc}", raw_error=str(exc))


# ---------------------------------------------------------------------------
# Credit card (Luhn)
# ---------------------------------------------------------------------------

_CARD_BRAND_RE = {
    "Visa": re.compile(r"^4[0-9]{12}(?:[0-9]{3})?$"),
    "MasterCard": re.compile(r"^5[1-5][0-9]{14}$"),
    "Amex": re.compile(r"^3[47][0-9]{13}$"),
    "Discover": re.compile(r"^6(?:011|5[0-9]{2})[0-9]{12}$"),
    "Maestro": re.compile(r"^(?:5018|5020|5038|6304|6759|676[1-3])[0-9]{8,15}$"),
}


def validate_credit_card(number: str) -> ValidationResult:
    """Validate a credit-card number using the Luhn algorithm.

    Args:
        number: Card number string — spaces and dashes are stripped automatically.

    Returns:
        ValidationResult with detected brand in details when valid.
    """
    if not isinstance(number, str):
        return _fail("Input must be a string")

    digits = re.sub(r"[\s\-]", "", number)
    if not digits.isdigit():
        return _fail("Card number contains non-digit characters after stripping spaces/dashes")

    if not (13 <= len(digits) <= 19):
        return _fail(
            f"Card number length {len(digits)} is outside the valid range 13–19"
        )

    if not _luhn_check(digits):
        return _fail("Card number failed Luhn checksum verification")

    brand = "Unknown"
    for name, pattern in _CARD_BRAND_RE.items():
        if pattern.match(digits):
            brand = name
            break

    masked = digits[:4] + " **** **** " + digits[-4:]
    return _ok("Card number is valid (Luhn check passed)", brand=brand, masked=masked)


# ---------------------------------------------------------------------------
# Password strength
# ---------------------------------------------------------------------------

def validate_password_strength(
    password: str, min_length: int = 8
) -> ValidationResult:
    """Evaluate password strength.

    Checks:
    - Minimum length
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit
    - At least one special character

    Returns:
        ValidationResult where ``details["score"]`` is 0–5 and
        ``details["checks"]`` is a dict of individual check outcomes.
    """
    if not isinstance(password, str):
        return _fail("Input must be a string")

    checks = {
        "min_length": len(password) >= min_length,
        "has_uppercase": bool(re.search(r"[A-Z]", password)),
        "has_lowercase": bool(re.search(r"[a-z]", password)),
        "has_digit": bool(re.search(r"\d", password)),
        "has_special": bool(re.search(r"[!@#$%^&*()\-_=+\[\]{};:'\",.<>/?\\|`~]", password)),
    }

    score = sum(checks.values())
    failed = [k for k, v in checks.items() if not v]

    if not checks["min_length"]:
        return _fail(
            f"Password is too short (minimum {min_length} characters)",
            score=score,
            checks=checks,
            failed=failed,
        )

    labels = {0: "very weak", 1: "very weak", 2: "weak", 3: "fair", 4: "strong", 5: "very strong"}
    strength = labels[score]

    if score < 3:
        return _fail(
            f"Password is {strength} — missing: {', '.join(failed)}",
            score=score,
            strength=strength,
            checks=checks,
            failed=failed,
        )

    return _ok(
        f"Password strength is {strength}",
        score=score,
        strength=strength,
        checks=checks,
    )


# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------

_DEFAULT_DATE_FORMATS = [
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%d.%m.%Y",
    "%m/%d/%Y",
    "%d %B %Y",
    "%d %b %Y",
    "%B %d, %Y",
    "%b %d, %Y",
    "%Y%m%d",
]


def validate_date(
    date_str: str, formats: Optional[list] = None
) -> ValidationResult:
    """Try to parse *date_str* against a list of common date formats.

    Args:
        date_str: The string to parse.
        formats: Optional list of ``strptime`` format strings. Falls back to
            a built-in list of common formats when not provided.

    Returns:
        ValidationResult with ``details["parsed"]`` (ISO string) and
        ``details["format_matched"]`` on success.
    """
    if not isinstance(date_str, str):
        return _fail("Input must be a string")

    date_str = date_str.strip()
    if not date_str:
        return _fail("Date string is empty")

    fmt_list = formats if formats is not None else _DEFAULT_DATE_FORMATS

    for fmt in fmt_list:
        try:
            parsed = datetime.strptime(date_str, fmt)
            return _ok(
                "Date parsed successfully",
                parsed=parsed.isoformat(),
                format_matched=fmt,
                year=parsed.year,
                month=parsed.month,
                day=parsed.day,
            )
        except ValueError:
            continue

    return _fail(
        "Date string did not match any known format",
        tried_formats=fmt_list,
        input=date_str,
    )


# ---------------------------------------------------------------------------
# Filename sanitisation
# ---------------------------------------------------------------------------

# Characters forbidden on Windows (and generally unsafe cross-platform)
_UNSAFE_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

# Windows reserved filenames (without extension)
_WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
    "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
}


def sanitize_filename(
    filename: str,
    max_length: int = 255,
    replacement: str = "_",
) -> str:
    """Return a sanitised version of *filename* safe for cross-platform use.

    - Replaces characters forbidden on Windows/POSIX with *replacement*.
    - Strips leading/trailing dots and spaces.
    - Handles Windows reserved names (CON, PRN, etc.) by prefixing with '_'.
    - Truncates to *max_length* bytes (UTF-8), preserving the extension.

    Args:
        filename: Original filename string (basename only, no directory).
        max_length: Maximum byte length in UTF-8 encoding (default 255).
        replacement: Character used to replace unsafe characters.

    Returns:
        A sanitised filename string.
    """
    if not isinstance(filename, str):
        filename = str(filename)

    # Normalise unicode (NFC)
    filename = unicodedata.normalize("NFC", filename)

    # Replace unsafe characters
    filename = _UNSAFE_CHARS_RE.sub(replacement, filename)

    # Strip leading/trailing whitespace and dots
    filename = filename.strip(". ")

    if not filename:
        filename = "unnamed"

    # Separate stem and extension
    if "." in filename:
        dot_idx = filename.rfind(".")
        stem = filename[:dot_idx]
        ext = filename[dot_idx:]  # includes the dot
    else:
        stem = filename
        ext = ""

    # Handle Windows reserved names
    if stem.upper() in _WINDOWS_RESERVED:
        stem = "_" + stem

    # Truncate to max_length bytes, keeping extension intact
    ext_bytes = ext.encode("utf-8")
    max_stem_bytes = max_length - len(ext_bytes)
    stem_encoded = stem.encode("utf-8")
    if len(stem_encoded) > max_stem_bytes:
        # Truncate safely (avoid splitting a multi-byte char)
        stem = stem_encoded[:max_stem_bytes].decode("utf-8", errors="ignore")

    return stem + ext


# ---------------------------------------------------------------------------
# Swedish personnummer
# ---------------------------------------------------------------------------

_PNR_RE = re.compile(
    r"^(\d{2})(\d{2})(\d{2})"   # YYMMDD
    r"([-+]?)"                   # optional separator
    r"(\d{4})$"                  # last four digits including check digit
)
_PNR_FULL_RE = re.compile(
    r"^(\d{4})(\d{2})(\d{2})"   # YYYYMMDD
    r"[-]?"
    r"(\d{4})$"
)


def validate_swedish_personnummer(pnr: str) -> ValidationResult:
    """Validate a Swedish personal identity number (personnummer).

    Accepts formats:
    - YYMMDD-XXXX  (10-digit with separator)
    - YYMMDDXXXX   (10-digit without separator)
    - YYYYMMDD-XXXX (12-digit with separator)
    - YYYYMMDDXXXX  (12-digit without separator)

    The '+' separator is accepted (indicates age ≥ 100).

    Validation:
    1. Format check via regex
    2. Basic date sanity (month 1–12, day 1–31, or 61–91 for coordination numbers)
    3. Luhn check on the 10-digit number

    Returns:
        ValidationResult
    """
    if not isinstance(pnr, str):
        return _fail("Input must be a string")

    pnr = pnr.strip()

    # Try 12-digit form first
    m12 = _PNR_FULL_RE.match(pnr)
    if m12:
        yyyy, mm, dd, last4 = m12.groups()
        yy = yyyy[2:]
    else:
        m10 = _PNR_RE.match(pnr)
        if not m10:
            return _fail(
                "Personnummer format is invalid",
                hint="Expected YYMMDD-XXXX, YYYYMMDD-XXXX or without separator",
                input=pnr,
            )
        yy, mm, dd, _sep, last4 = m10.groups()

    mm_int = int(mm)
    dd_int = int(dd)

    # Coordination number: day offset by 60
    is_coordination = dd_int >= 61
    effective_dd = dd_int - 60 if is_coordination else dd_int

    if not (1 <= mm_int <= 12):
        return _fail(f"Month {mm_int} is out of range 1–12")
    if not (1 <= effective_dd <= 31):
        return _fail(f"Day {effective_dd} is out of range 1–31")

    # Build 10-digit string for Luhn: YYMMDD + last4
    ten_digits = yy + mm + dd + last4
    if not _luhn_check(ten_digits):
        return _fail(
            "Personnummer failed Luhn checksum verification",
            ten_digits=ten_digits,
        )

    return _ok(
        "Valid Swedish personnummer",
        year=yy,
        month=mm,
        day=dd,
        last_four=last4,
        is_coordination_number=is_coordination,
    )
