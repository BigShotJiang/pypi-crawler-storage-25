"""
Document/item duplicate detection with weighted similarity and name normalization.

Provides exact, near, and possible duplicate detection using a combination of
name similarity and optional content/token-set similarity.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class MatchType(Enum):
    EXACT = "exact"
    NEAR = "near"
    POSSIBLE = "possible"


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class DuplicateMatch:
    """A single detected duplicate pair."""
    item1_id: str
    item2_id: str
    similarity_score: float
    name_similarity: float
    content_similarity: float
    match_type: MatchType
    metadata: dict = field(default_factory=dict)


@dataclass
class DeduplicationResult:
    """Output of a full duplicate-detection run."""
    total_items: int
    unique_items: int
    duplicates_found: int
    matches: list[DuplicateMatch]
    groups: list[list[str]]  # each inner list is a cluster of duplicate IDs


# ---------------------------------------------------------------------------
# Normalization patterns
# ---------------------------------------------------------------------------

# File extensions to strip
_EXT_RE = re.compile(
    r"\.(pdf|docx?|xlsx?|pptx?|txt|csv|xml|json|html?|odt|ods|odp|rtf|md)$",
    re.IGNORECASE,
)

# Version strings: v1.0, v2, _v3, -v1
_VERSION_RE = re.compile(
    r"[-_\s]*v\d+(?:\.\d+)*\b",
    re.IGNORECASE,
)

# Trailing status markers: _final, _draft, _copy, _bak, (1), (2), _1, _2
_STATUS_RE = re.compile(
    r"[-_\s]*(?:final|draft|copy|bak|backup|old|new|rev(?:ision)?|temp|tmp)"
    r"|[-_\s]*\(\d+\)"
    r"|[-_\s]+\d+$",
    re.IGNORECASE,
)

# Common document prefixes
_PREFIX_RE = re.compile(
    r"^(?:rapport_|rapporter_|doc_|document_|file_|fil_|brev_|letter_|memo_|"
    r"pm_|protokoll_|minutes_|avtal_|contract_|report_)+",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Union-Find (path compression + union by rank)
# ---------------------------------------------------------------------------

class _UnionFind:
    def __init__(self) -> None:
        self._parent: dict[str, str] = {}
        self._rank: dict[str, int] = {}

    def find(self, x: str) -> str:
        if x not in self._parent:
            self._parent[x] = x
            self._rank[x] = 0
        if self._parent[x] != x:
            self._parent[x] = self.find(self._parent[x])
        return self._parent[x]

    def union(self, x: str, y: str) -> None:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        if self._rank[rx] < self._rank[ry]:
            rx, ry = ry, rx
        self._parent[ry] = rx
        if self._rank[rx] == self._rank[ry]:
            self._rank[rx] += 1


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class DuplicateDetector:
    """Detect duplicate items using weighted name + content similarity.

    Parameters
    ----------
    name_weight:
        Weight assigned to name similarity (0–1).
    content_weight:
        Weight assigned to content similarity (0–1).
        ``name_weight + content_weight`` should equal 1.0.
    threshold:
        Minimum combined similarity score to be considered a duplicate.
    """

    def __init__(
        self,
        name_weight: float = 0.6,
        content_weight: float = 0.4,
        threshold: float = 0.7,
    ) -> None:
        if not (0.0 <= name_weight <= 1.0):
            raise ValueError("name_weight must be in [0, 1]")
        if not (0.0 <= content_weight <= 1.0):
            raise ValueError("content_weight must be in [0, 1]")
        self._name_weight = name_weight
        self._content_weight = content_weight
        self._threshold = threshold

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def find_duplicates(self, items: list[dict]) -> DeduplicationResult:
        """Detect all duplicate pairs in *items*.

        Each item dict must have:
        - ``"id"`` (str) — unique identifier
        - ``"name"`` (str) — display name / filename

        Optional keys:
        - ``"content"`` (str) — full text content for content similarity
        - ``"tokens"`` (set[str]) — pre-computed word set for Jaccard similarity

        Returns a :class:`DeduplicationResult` with all matches and clusters.
        """
        if not items:
            return DeduplicationResult(
                total_items=0,
                unique_items=0,
                duplicates_found=0,
                matches=[],
                groups=[],
            )

        matches: list[DuplicateMatch] = []
        n = len(items)

        for i in range(n):
            for j in range(i + 1, n):
                score = self.calculate_similarity(items[i], items[j])
                if score >= self._threshold:
                    name_sim = self.calculate_name_similarity(
                        items[i]["name"], items[j]["name"]
                    )
                    content_sim = self._content_sim(items[i], items[j])
                    match_type = self.classify_match(score)
                    matches.append(
                        DuplicateMatch(
                            item1_id=items[i]["id"],
                            item2_id=items[j]["id"],
                            similarity_score=round(score, 4),
                            name_similarity=round(name_sim, 4),
                            content_similarity=round(content_sim, 4),
                            match_type=match_type,
                            metadata={
                                "item1_name": items[i]["name"],
                                "item2_name": items[j]["name"],
                            },
                        )
                    )

        groups = self.group_duplicates(matches)

        # unique_items = total - items that appear in any group beyond the first
        duplicate_ids: set[str] = set()
        for group in groups:
            if len(group) > 1:
                duplicate_ids.update(group[1:])  # keep first, rest are duplicates

        return DeduplicationResult(
            total_items=n,
            unique_items=n - len(duplicate_ids),
            duplicates_found=len(matches),
            matches=matches,
            groups=groups,
        )

    def calculate_similarity(self, item1: dict, item2: dict) -> float:
        """Weighted combination of name and content similarity.

        When neither ``content`` nor ``tokens`` are present on both items,
        the full weight falls on the name similarity so that content-less
        items are not penalised for missing data.
        """
        name_sim = self.calculate_name_similarity(item1["name"], item2["name"])
        has_content = (
            item1.get("content") or item1.get("tokens") is not None
            or item2.get("content") or item2.get("tokens") is not None
        )
        if not has_content:
            return name_sim

        content_sim = self._content_sim(item1, item2)
        return self._name_weight * name_sim + self._content_weight * content_sim

    def normalize_name(self, name: str) -> str:
        """Normalize a document name/filename for fuzzy comparison.

        Steps applied in order:
        1. Strip file extension
        2. Strip version strings (v1, v1.0, _v2, …)
        3. Strip status markers (_final, _draft, _copy, (1), …)
        4. Strip common document prefixes
        5. Replace non-alphanumeric runs with spaces
        6. Lowercase and strip whitespace
        """
        result = name.strip()
        result = _EXT_RE.sub("", result)
        result = _VERSION_RE.sub("", result)
        result = _STATUS_RE.sub("", result)
        result = _PREFIX_RE.sub("", result)
        result = re.sub(r"[^a-zA-ZåäöÅÄÖ0-9]+", " ", result)
        result = result.lower().strip()
        return result

    def calculate_name_similarity(self, name1: str, name2: str) -> float:
        """SequenceMatcher ratio on normalized names."""
        n1 = self.normalize_name(name1)
        n2 = self.normalize_name(name2)
        if not n1 and not n2:
            return 1.0
        return difflib.SequenceMatcher(None, n1, n2, autojunk=False).ratio()

    def calculate_content_similarity(
        self, content1: str, content2: str
    ) -> float:
        """SequenceMatcher ratio on raw content strings."""
        if not content1 and not content2:
            return 1.0
        if not content1 or not content2:
            return 0.0
        return difflib.SequenceMatcher(
            None, content1, content2, autojunk=False
        ).ratio()

    def calculate_token_similarity(
        self, tokens1: set, tokens2: set
    ) -> float:
        """Jaccard index on pre-computed token sets."""
        if not tokens1 and not tokens2:
            return 1.0
        if not tokens1 or not tokens2:
            return 0.0
        intersection = len(tokens1 & tokens2)
        union = len(tokens1 | tokens2)
        return intersection / union if union else 0.0

    def classify_match(self, score: float) -> MatchType:
        """Map a similarity score to a :class:`MatchType`."""
        if score > 0.95:
            return MatchType.EXACT
        if score > 0.85:
            return MatchType.NEAR
        return MatchType.POSSIBLE

    def group_duplicates(
        self, matches: list[DuplicateMatch]
    ) -> list[list[str]]:
        """Cluster matched items using Union-Find.

        Returns a list of groups; each group contains IDs of items that are
        transitively connected via duplicate matches.  Singletons (items not
        appearing in any match) are not included.
        """
        uf = _UnionFind()
        all_ids: set[str] = set()

        for m in matches:
            uf.union(m.item1_id, m.item2_id)
            all_ids.add(m.item1_id)
            all_ids.add(m.item2_id)

        # Collect groups
        groups_map: dict[str, list[str]] = {}
        for item_id in sorted(all_ids):
            root = uf.find(item_id)
            groups_map.setdefault(root, []).append(item_id)

        return [sorted(g) for g in groups_map.values() if len(g) > 1]

    def deduplicate(
        self, items: list[dict], keep: str = "first"
    ) -> list[dict]:
        """Remove duplicates from *items*, keeping one representative per cluster.

        Parameters
        ----------
        items:
            List of item dicts (must have ``"id"`` and ``"name"`` keys).
        keep:
            Strategy for selecting the representative item:
            - ``"first"`` — keep the item with the lowest index
            - ``"last"``  — keep the item with the highest index
            - ``"longest"`` — keep the item whose ``"content"`` key is longest
              (falls back to ``"first"`` if no content key)
        """
        if keep not in ("first", "last", "longest"):
            raise ValueError(f"keep must be 'first', 'last', or 'longest'; got {keep!r}")

        result = self.find_duplicates(items)
        if not result.groups:
            return list(items)

        # Build id → item lookup
        id_to_item = {item["id"]: item for item in items}
        id_to_index = {item["id"]: idx for idx, item in enumerate(items)}

        ids_to_remove: set[str] = set()

        for group in result.groups:
            if len(group) <= 1:
                continue

            if keep == "first":
                sorted_group = sorted(group, key=lambda x: id_to_index.get(x, 0))
                ids_to_remove.update(sorted_group[1:])

            elif keep == "last":
                sorted_group = sorted(
                    group, key=lambda x: id_to_index.get(x, 0), reverse=True
                )
                ids_to_remove.update(sorted_group[1:])

            elif keep == "longest":
                def _content_length(item_id: str) -> int:
                    item = id_to_item.get(item_id, {})
                    return len(item.get("content", ""))

                sorted_group = sorted(group, key=_content_length, reverse=True)
                ids_to_remove.update(sorted_group[1:])

        return [item for item in items if item["id"] not in ids_to_remove]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _content_sim(self, item1: dict, item2: dict) -> float:
        """Compute content similarity between two items.

        Priority:
        1. ``tokens`` key (Jaccard on pre-computed sets) — cheapest
        2. ``content`` key (SequenceMatcher on text)
        3. 0.0 if neither key is present
        """
        t1 = item1.get("tokens")
        t2 = item2.get("tokens")
        if t1 is not None and t2 is not None:
            return self.calculate_token_similarity(t1, t2)

        c1 = item1.get("content", "")
        c2 = item2.get("content", "")
        if c1 or c2:
            return self.calculate_content_similarity(c1, c2)

        return 0.0
