"""LLM-optimised HTML to Markdown conversion with ~80% token reduction.

Converts raw HTML into clean Markdown suitable for feeding to language models.
Main content is isolated by heuristic detection of <main>, <article>, and
similar semantic containers; navigation, scripts, ads, and other noise are
stripped before conversion.

Requires BeautifulSoup 4 (``pip install beautifulsoup4 lxml``).  When bs4 is
unavailable, a lightweight regex-based fallback is used that achieves partial
conversion without the structural improvements.

Usage::

    from data_cleaner.html_to_markdown import (
        MarkdownConverter, ConversionOptions, html_to_markdown,
    )

    # Quick conversion
    result = html_to_markdown(raw_html, base_url="https://example.com")
    print(result.markdown)
    print(f"Compression: {result.compression_ratio:.1%}")

    # With custom options
    options = ConversionOptions(max_links=20, extract_tables=True)
    converter = MarkdownConverter(options)
    result = converter.convert(raw_html, base_url="https://example.com")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html import unescape
from typing import Optional
from urllib.parse import urljoin, urlparse


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class ConversionOptions:
    """Options controlling the HTML → Markdown conversion."""

    max_links: int = 50
    """Cap the number of links collected into the links section."""

    max_images: int = 20
    """Cap the number of images collected."""

    extract_tables: bool = True
    """Convert HTML tables to Markdown pipe-tables."""

    preserve_emphasis: bool = True
    """Convert <strong>/<b> → **bold** and <em>/<i> → *italic*."""

    include_link_section: bool = True
    """Append a "## Links" reference section at the end of the markdown."""

    min_text_length: int = 10
    """Minimum character length for a text node to be included."""


@dataclass
class ConversionResult:
    """Result of an HTML → Markdown conversion."""

    markdown: str
    """The converted Markdown text."""

    links: list[dict]
    """Collected links: ``[{"url": str, "text": str, "is_external": bool}]``."""

    images: list[dict]
    """Collected images: ``[{"src": str, "alt": str, "title": str}]``."""

    tables: list[str]
    """Markdown-formatted tables extracted from the page."""

    title: str
    """Page title extracted from <title> or the first <h1>."""

    word_count: int
    """Approximate word count of the converted markdown."""

    original_size: int
    """Byte length of the original HTML input."""

    converted_size: int
    """Byte length of the output markdown."""

    @property
    def compression_ratio(self) -> float:
        """Fraction of original size represented by the converted output.

        A value of 0.20 means the markdown is 20% of the original HTML size
        (80% token reduction).  Returns 1.0 when original size is zero.
        """
        if self.original_size == 0:
            return 1.0
        return round(self.converted_size / self.original_size, 4)


# ---------------------------------------------------------------------------
# MarkdownConverter
# ---------------------------------------------------------------------------


class MarkdownConverter:
    """Convert HTML pages to LLM-optimised Markdown.

    The converter:
    1. Isolates the main content area (``<main>``, ``<article>``, etc.).
    2. Strips navigation, scripts, ads, and other noise.
    3. Recursively converts the cleaned DOM tree to Markdown.
    4. Collects links and images as structured metadata.
    """

    # Tags whose entire subtree (including text) is removed
    _STRIP_TAGS: frozenset[str] = frozenset({
        "script", "style", "noscript", "iframe", "object", "embed",
        "applet", "frame", "frameset", "template",
    })

    # Semantic noise containers
    _NOISE_TAGS: frozenset[str] = frozenset({
        "nav", "footer", "header", "aside", "form",
    })

    # CSS class/id substrings that identify noise elements
    _NOISE_PATTERNS: tuple[str, ...] = (
        "advertisement", "cookie-banner", "cookie_banner", "cookiebanner",
        "popup", "modal", "sidebar", "social-share", "social_share",
        "newsletter", "subscribe", "banner", "advert",
    )

    def __init__(self, options: Optional[ConversionOptions] = None) -> None:
        self.options = options or ConversionOptions()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def convert(self, html: str, base_url: str = "") -> ConversionResult:
        """Convert *html* to Markdown.

        Args:
            html: Raw HTML string.
            base_url: Base URL used to resolve relative links and image srcs.

        Returns:
            A :class:`ConversionResult` with markdown, links, images, and metadata.
        """
        original_size = len(html.encode("utf-8"))
        title = self._extract_title_from_html(html)

        try:
            from bs4 import BeautifulSoup  # lazy import

            soup = BeautifulSoup(html, "lxml")
            if not title:
                title_tag = soup.find("title")
                if title_tag:
                    title = self._clean_text(title_tag.get_text())

            self._clean_soup(soup)
            main = self._find_main_content(soup)

            # Extract structured data before text conversion
            links = self._extract_links(main or soup, base_url)
            images = self._extract_images(main or soup, base_url)
            tables = self._extract_tables(main or soup) if self.options.extract_tables else []

            # Convert DOM tree to markdown
            markdown_parts = self._convert_element(main or soup)
            markdown = self._normalise_markdown(markdown_parts)

        except ImportError:
            # Fallback: regex-based stripping
            markdown = self._regex_fallback(html)
            links = self._regex_extract_links(html, base_url)
            images = []
            tables = []

        # Optionally append a links reference section
        if self.options.include_link_section and links:
            link_lines = ["\n\n## Links\n"]
            for idx, lnk in enumerate(links[: self.options.max_links], 1):
                link_lines.append(f"{idx}. [{lnk['text']}]({lnk['url']})")
            markdown += "\n".join(link_lines)

        # Derive title from first h1 if still missing
        if not title:
            h1_match = re.search(r"^#\s+(.+)$", markdown, re.MULTILINE)
            if h1_match:
                title = h1_match.group(1).strip()

        converted_size = len(markdown.encode("utf-8"))
        word_count = len(markdown.split())

        return ConversionResult(
            markdown=markdown.strip(),
            links=links[: self.options.max_links],
            images=images[: self.options.max_images],
            tables=tables,
            title=title,
            word_count=word_count,
            original_size=original_size,
            converted_size=converted_size,
        )

    # ------------------------------------------------------------------
    # Main content detection
    # ------------------------------------------------------------------

    def _find_main_content(self, soup: object) -> Optional[object]:
        """Locate the primary content element in the parsed document.

        Search order:
        1. ``<main>`` tag
        2. ``<article>`` tag
        3. Any element with ``role="main"``
        4. Element with ``id`` containing ``"content"``
        5. Element with ``class`` containing ``"content"``, ``"post"``,
           or ``"article"``
        6. ``<body>`` fallback
        """
        # 1. Semantic <main>
        main = soup.find("main")
        if main:
            return main

        # 2. <article>
        article = soup.find("article")
        if article:
            return article

        # 3. role="main"
        role_main = soup.find(attrs={"role": "main"})
        if role_main:
            return role_main

        # 4. id containing "content"
        for tag in soup.find_all(id=re.compile(r"content", re.I)):
            return tag

        # 5. class containing "content", "post", or "article"
        for cls_pattern in ("content", "post", "article"):
            for tag in soup.find_all(class_=re.compile(cls_pattern, re.I)):
                return tag

        # 6. <body> fallback
        return soup.find("body")

    # ------------------------------------------------------------------
    # Soup cleaning
    # ------------------------------------------------------------------

    def _clean_soup(self, soup: object) -> None:
        """Remove noise elements from the parsed document in-place.

        Removes:
        - Script, style, noscript, iframe and similar non-content tags
        - Semantic noise: nav, footer, header, aside, form
        - Elements with ``hidden`` attribute
        - Elements matching advertisement/cookie/popup class patterns
        """
        # Remove strip tags completely (including content)
        for tag_name in self._STRIP_TAGS:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # Remove semantic noise containers
        for tag_name in self._NOISE_TAGS:
            for tag in soup.find_all(tag_name):
                tag.decompose()

        # Remove hidden elements
        for tag in soup.find_all(attrs={"hidden": True}):
            tag.decompose()
        for tag in soup.find_all(style=re.compile(r"display\s*:\s*none", re.I)):
            tag.decompose()

        # Remove elements matching noise CSS patterns
        for pattern in self._NOISE_PATTERNS:
            for tag in soup.find_all(
                class_=re.compile(pattern, re.I)
            ):
                tag.decompose()
            for tag in soup.find_all(
                id=re.compile(pattern, re.I)
            ):
                tag.decompose()

    # ------------------------------------------------------------------
    # DOM → Markdown recursive conversion
    # ------------------------------------------------------------------

    def _convert_element(self, element: object) -> str:
        """Recursively convert a BeautifulSoup element to Markdown text.

        Handles:
        - Headings h1–h6 → ``# `` … ``###### ``
        - Paragraphs → text + double newline
        - Unordered lists → ``- item``
        - Ordered lists → ``1. item``
        - Links → ``[text](url)``
        - Images → ``![alt](src)``
        - Bold/strong → ``**text**``
        - Italic/em → ``*text*``
        - Inline code → `` `text` ``
        - Preformatted/code blocks → ` ``` ` fenced blocks
        - Blockquotes → ``> text``
        - Horizontal rules → ``---``
        - Tables → delegate to :pymeth:`_convert_table`
        - Block elements → children + double newline
        """
        from bs4 import NavigableString, Tag  # inner import; bs4 already confirmed

        if isinstance(element, NavigableString):
            text = self._clean_text(str(element))
            if len(text) >= self.options.min_text_length:
                return text
            return text  # always return (short text still contributes)

        if not isinstance(element, Tag):
            return ""

        tag = element.name.lower() if element.name else ""

        # Headings
        if tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            level = int(tag[1])
            text = self._clean_text(element.get_text())
            return f"\n\n{'#' * level} {text}\n\n"

        # Paragraph
        if tag == "p":
            inner = self._children_text(element)
            text = self._clean_text(inner) if not inner.strip() else inner
            return f"\n\n{text.strip()}\n\n"

        # Unordered list
        if tag == "ul":
            items = []
            for li in element.find_all("li", recursive=False):
                text = self._clean_text(self._children_text(li))
                if text:
                    items.append(f"- {text}")
            return "\n" + "\n".join(items) + "\n"

        # Ordered list
        if tag == "ol":
            items = []
            for idx, li in enumerate(element.find_all("li", recursive=False), 1):
                text = self._clean_text(self._children_text(li))
                if text:
                    items.append(f"{idx}. {text}")
            return "\n" + "\n".join(items) + "\n"

        # Links
        if tag == "a":
            href = element.get("href", "").strip()
            inner = self._clean_text(self._children_text(element))
            if href and inner:
                return f"[{inner}]({href})"
            return inner

        # Images
        if tag == "img":
            src = element.get("src", "").strip()
            alt = element.get("alt", "").strip()
            if src:
                return f"![{alt}]({src})"
            return ""

        # Bold / strong
        if tag in ("strong", "b") and self.options.preserve_emphasis:
            inner = self._children_text(element)
            text = self._clean_text(inner)
            return f"**{text}**" if text else ""

        # Italic / em
        if tag in ("em", "i") and self.options.preserve_emphasis:
            inner = self._children_text(element)
            text = self._clean_text(inner)
            return f"*{text}*" if text else ""

        # Inline code
        if tag == "code" and element.parent and element.parent.name != "pre":
            text = element.get_text()
            return f"`{text}`" if text else ""

        # Code blocks (pre > code)
        if tag == "pre":
            code_tag = element.find("code")
            code_text = (code_tag or element).get_text()
            lang_class = ""
            if code_tag:
                for cls in (code_tag.get("class") or []):
                    lang_match = re.match(r"language-(\w+)", cls)
                    if lang_match:
                        lang_class = lang_match.group(1)
                        break
            return f"\n\n```{lang_class}\n{code_text.strip()}\n```\n\n"

        # Blockquote
        if tag == "blockquote":
            inner = self._children_text(element)
            lines = inner.strip().splitlines()
            quoted = "\n".join(f"> {ln}" for ln in lines)
            return f"\n\n{quoted}\n\n"

        # Horizontal rule
        if tag == "hr":
            return "\n\n---\n\n"

        # Line break
        if tag == "br":
            return "\n"

        # Table
        if tag == "table" and self.options.extract_tables:
            return self._convert_table(element)

        # Skip noise tags that survived cleaning
        if tag in self._STRIP_TAGS | self._NOISE_TAGS:
            return ""

        # Generic block / inline — recurse into children
        children_text = self._children_text(element)
        tag_block = tag in {
            "div", "section", "article", "main", "figure",
            "figcaption", "details", "summary",
        }
        if tag_block and children_text.strip():
            return f"\n\n{children_text.strip()}\n\n"
        return children_text

    def _children_text(self, element: object) -> str:
        """Concatenate the converted text of all direct children."""
        parts = []
        for child in element.children:
            parts.append(self._convert_element(child))
        return "".join(parts)

    # ------------------------------------------------------------------
    # Table conversion
    # ------------------------------------------------------------------

    def _convert_table(self, table: object) -> str:
        """Convert a BeautifulSoup table element to Markdown pipe-table format."""
        rows: list[list[str]] = []

        # Collect header row from <thead> or the first <tr>
        thead = table.find("thead")
        if thead:
            for tr in thead.find_all("tr"):
                row = [
                    self._clean_text(cell.get_text())
                    for cell in tr.find_all(["th", "td"])
                ]
                if row:
                    rows.append(row)

        # Collect body rows
        tbody = table.find("tbody") or table
        for tr in tbody.find_all("tr"):
            row = [
                self._clean_text(cell.get_text())
                for cell in tr.find_all(["td", "th"])
            ]
            if row:
                rows.append(row)

        if not rows:
            return ""

        # Ensure all rows have the same column count
        max_cols = max(len(r) for r in rows)
        padded = [r + [""] * (max_cols - len(r)) for r in rows]

        header = padded[0]
        separator = ["---"] * max_cols
        body_rows = padded[1:]

        lines = [
            "| " + " | ".join(header) + " |",
            "| " + " | ".join(separator) + " |",
        ]
        for row in body_rows:
            lines.append("| " + " | ".join(row) + " |")

        return "\n\n" + "\n".join(lines) + "\n\n"

    # ------------------------------------------------------------------
    # Link / image extraction
    # ------------------------------------------------------------------

    def _extract_links(self, element: object, base_url: str) -> list[dict]:
        """Collect all anchor links from *element*.

        Returns:
            List of dicts: ``{"url": str, "text": str, "is_external": bool}``
        """
        links: list[dict] = []
        seen_urls: set[str] = set()

        for a_tag in element.find_all("a", href=True):
            href = a_tag.get("href", "").strip()
            if not href or href.startswith("#") or href.startswith("javascript:"):
                continue

            url = self._normalise_url(href, base_url)
            if not url or url in seen_urls:
                continue

            seen_urls.add(url)
            text = self._clean_text(a_tag.get_text())
            is_external = self._is_external_url(url, base_url)

            links.append({"url": url, "text": text or url, "is_external": is_external})

            if len(links) >= self.options.max_links:
                break

        return links

    def _extract_images(self, element: object, base_url: str) -> list[dict]:
        """Collect all images from *element*.

        Returns:
            List of dicts: ``{"src": str, "alt": str, "title": str}``
        """
        images: list[dict] = []

        for img in element.find_all("img", src=True):
            src = img.get("src", "").strip()
            if not src or src.startswith("data:"):
                continue

            resolved_src = self._normalise_url(src, base_url)
            alt = self._clean_text(img.get("alt", ""))
            title = self._clean_text(img.get("title", ""))

            images.append({"src": resolved_src, "alt": alt, "title": title})

            if len(images) >= self.options.max_images:
                break

        return images

    def _extract_tables(self, element: object) -> list[str]:
        """Extract all tables as Markdown-formatted strings."""
        tables: list[str] = []
        for table in element.find_all("table"):
            md_table = self._convert_table(table)
            if md_table.strip():
                tables.append(md_table.strip())
        return tables

    # ------------------------------------------------------------------
    # URL helpers
    # ------------------------------------------------------------------

    def _normalise_url(self, url: str, base_url: str) -> str:
        """Resolve *url* against *base_url* to produce an absolute URL."""
        if not url:
            return ""
        if url.startswith(("http://", "https://", "//", "mailto:", "tel:")):
            return url
        if base_url:
            try:
                return urljoin(base_url, url)
            except Exception:
                pass
        return url

    def _is_external_url(self, url: str, base_url: str) -> bool:
        """Return ``True`` when *url* belongs to a different domain than *base_url*."""
        if not base_url or not url.startswith(("http://", "https://")):
            return False
        try:
            base_host = urlparse(base_url).netloc.lower().removeprefix("www.")
            url_host = urlparse(url).netloc.lower().removeprefix("www.")
            return url_host != base_host
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Text helpers
    # ------------------------------------------------------------------

    def _clean_text(self, text: str) -> str:
        """Collapse whitespace and strip leading/trailing spaces."""
        if not text:
            return ""
        # Decode HTML entities
        text = unescape(text)
        # Replace tabs and non-breaking spaces with regular spaces
        text = text.replace("\t", " ").replace("\xa0", " ")
        # Collapse multiple whitespace into single space
        text = re.sub(r"[ \t]+", " ", text)
        # Preserve single newlines but collapse multiples
        text = re.sub(r"\n{2,}", "\n", text)
        return text.strip()

    def _normalise_markdown(self, text: str) -> str:
        """Clean up excess blank lines and leading/trailing whitespace."""
        # Collapse 3+ blank lines into 2
        text = re.sub(r"\n{3,}", "\n\n", text)
        # Remove trailing whitespace on each line
        text = re.sub(r"[ \t]+$", "", text, flags=re.MULTILINE)
        return text.strip()

    # ------------------------------------------------------------------
    # Regex fallback (no bs4)
    # ------------------------------------------------------------------

    def _regex_fallback(self, html: str) -> str:
        """Lightweight regex-based HTML → Markdown conversion.

        Used when BeautifulSoup is not installed.  Handles the most common
        elements but does not perform content isolation or noise removal.
        """
        text = html

        # Remove script/style content
        text = re.sub(r"<(script|style|noscript)[^>]*>.*?</\1>", "", text,
                      flags=re.IGNORECASE | re.DOTALL)
        # Remove HTML comments
        text = re.sub(r"<!--.*?-->", "", text, flags=re.DOTALL)

        # Headings
        for i in range(1, 7):
            text = re.sub(
                rf"<h{i}[^>]*>(.*?)</h{i}>",
                lambda m, lvl=i: f"\n\n{'#' * lvl} {re.sub('<[^>]+>', '', m.group(1)).strip()}\n\n",
                text, flags=re.IGNORECASE | re.DOTALL,
            )

        # Paragraphs
        text = re.sub(r"<p[^>]*>(.*?)</p>",
                      lambda m: f"\n\n{re.sub('<[^>]+>', '', m.group(1)).strip()}\n\n",
                      text, flags=re.IGNORECASE | re.DOTALL)

        # Bold
        text = re.sub(r"<(strong|b)[^>]*>(.*?)</\1>", r"**\2**",
                      text, flags=re.IGNORECASE | re.DOTALL)

        # Italic
        text = re.sub(r"<(em|i)[^>]*>(.*?)</\1>", r"*\2*",
                      text, flags=re.IGNORECASE | re.DOTALL)

        # Links
        text = re.sub(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            lambda m: f"[{re.sub('<[^>]+>', '', m.group(2)).strip()}]({m.group(1)})",
            text, flags=re.IGNORECASE | re.DOTALL,
        )

        # List items
        text = re.sub(r"<li[^>]*>(.*?)</li>",
                      lambda m: f"\n- {re.sub('<[^>]+>', '', m.group(1)).strip()}",
                      text, flags=re.IGNORECASE | re.DOTALL)

        # BR and HR
        text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"<hr\s*/?>", "\n\n---\n\n", text, flags=re.IGNORECASE)

        # Strip remaining tags
        text = re.sub(r"<[^>]+>", "", text)

        # Decode entities
        text = unescape(text)

        # Normalise whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r"[ \t]+", " ", text)

        return text.strip()

    def _regex_extract_links(self, html: str, base_url: str) -> list[dict]:
        """Extract links using regex when bs4 is unavailable."""
        links: list[dict] = []
        seen: set[str] = set()
        pattern = re.compile(
            r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(html):
            href = match.group(1).strip()
            if not href or href.startswith("#") or href.startswith("javascript:"):
                continue
            url = self._normalise_url(href, base_url)
            if not url or url in seen:
                continue
            seen.add(url)
            text = re.sub(r"<[^>]+>", "", match.group(2)).strip()
            links.append({
                "url": url,
                "text": text or url,
                "is_external": self._is_external_url(url, base_url),
            })
            if len(links) >= self.options.max_links:
                break
        return links

    # ------------------------------------------------------------------
    # Helper: extract <title> from raw HTML
    # ------------------------------------------------------------------

    def _extract_title_from_html(self, html: str) -> str:
        """Extract the document title from raw HTML using regex."""
        match = re.search(
            r"<title[^>]*>(.*?)</title>", html, re.IGNORECASE | re.DOTALL
        )
        if match:
            return unescape(re.sub(r"<[^>]+>", "", match.group(1))).strip()
        return ""


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------


def html_to_markdown(html: str, base_url: str = "") -> ConversionResult:
    """Convert *html* to LLM-optimised Markdown.

    Convenience wrapper around :class:`MarkdownConverter` with default options.

    Args:
        html: Raw HTML string.
        base_url: Optional base URL for resolving relative links and images.

    Returns:
        A :class:`ConversionResult`.

    Example::

        result = html_to_markdown(page_html, base_url="https://example.com")
        print(result.markdown[:500])
        print(f"Reduced to {result.compression_ratio:.0%} of original size")
    """
    converter = MarkdownConverter()
    return converter.convert(html, base_url=base_url)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = [
    "ConversionOptions",
    "ConversionResult",
    "MarkdownConverter",
    "html_to_markdown",
]
