"""Composable Data Validation Framework.

A flexible validation library with 30+ built-in validators, schema support,
and chainable composition. Stdlib-only, no external dependencies.

Usage:
    from data_cleaner.validation import (
        Schema, Required, Email, MinLength, Range,
        Validator, validate, validate_dict,
    )

    # Quick validation
    result = validate("user@example.com", Email())

    # Validator instance with convenience methods
    v = Validator()
    result = v.email("user@example.com")

    # Schema validation
    schema = Schema({
        "name": [Required(), MinLength(2)],
        "email": [Required(), Email()],
        "age": [Optional(), Range(0, 120)],
    })
    result = schema.validate(data)

    # Dict validation shorthand
    result = validate_dict(data, {
        "name": [Required(), MinLength(2)],
        "email": [Required(), Email()],
    })
"""

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, date
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Tuple,
    Type,
    Union,
)


# =============================================================================
# Validation Result
# =============================================================================


@dataclass
class ValidationError:
    """A single validation error."""

    field: str
    message: str
    code: str = "invalid"
    value: Any = None

    def __str__(self) -> str:
        if self.field:
            return f"{self.field}: {self.message}"
        return self.message


@dataclass
class ValidationResult:
    """Result of a validation operation.

    Attributes:
        is_valid: Whether validation passed.
        errors: List of validation errors.
        warnings: List of warning messages.
        data: Cleaned/transformed data.
    """

    is_valid: bool = True
    errors: List[ValidationError] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    data: Any = None

    def add_error(
        self,
        field: str,
        message: str,
        code: str = "invalid",
        value: Any = None,
    ) -> None:
        """Add a validation error."""
        self.errors.append(ValidationError(field, message, code, value))
        self.is_valid = False

    def add_warning(self, message: str) -> None:
        """Add a warning message."""
        self.warnings.append(message)

    def merge(self, other: "ValidationResult", prefix: str = "") -> None:
        """Merge another result into this one."""
        for error in other.errors:
            fld = (
                f"{prefix}.{error.field}"
                if prefix and error.field
                else (prefix or error.field)
            )
            self.add_error(fld, error.message, error.code, error.value)
        self.warnings.extend(other.warnings)

    @property
    def error_messages(self) -> List[str]:
        """Get list of error messages."""
        return [str(e) for e in self.errors]

    @property
    def first_error(self) -> Optional[str]:
        """Get first error message."""
        return str(self.errors[0]) if self.errors else None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "is_valid": self.is_valid,
            "errors": [
                {"field": e.field, "message": e.message, "code": e.code}
                for e in self.errors
            ],
            "warnings": self.warnings,
        }

    @classmethod
    def success(cls, data: Any = None) -> "ValidationResult":
        """Create a successful result."""
        return cls(is_valid=True, data=data)

    @classmethod
    def failure(
        cls, field: str, message: str, code: str = "invalid"
    ) -> "ValidationResult":
        """Create a failed result."""
        result = cls(is_valid=False)
        result.add_error(field, message, code)
        return result


# =============================================================================
# Base Validator
# =============================================================================


class BaseValidator(ABC):
    """Abstract base validator."""

    message: str = "Validation failed"
    code: str = "invalid"

    @abstractmethod
    def validate(self, value: Any, field: str = "") -> ValidationResult:
        """Validate a value.

        Args:
            value: Value to validate.
            field: Field name for error messages.

        Returns:
            ValidationResult.
        """
        pass

    def __call__(self, value: Any, field: str = "") -> ValidationResult:
        """Allow using validator as callable."""
        return self.validate(value, field)

    def _fail(self, field: str, value: Any = None, **kwargs: Any) -> ValidationResult:
        """Create a failure result with formatted message."""
        message = self.message.format(**kwargs) if kwargs else self.message
        result = ValidationResult(is_valid=False)
        result.add_error(field, message, self.code, value)
        return result

    def _success(self, value: Any = None) -> ValidationResult:
        """Create a success result."""
        return ValidationResult(is_valid=True, data=value)


# =============================================================================
# Type Validators
# =============================================================================


class TypeValidator(BaseValidator):
    """Validate value is of a specific type."""

    def __init__(self, expected_type: Union[Type, Tuple[Type, ...]], message: str = None):
        self.expected_type = expected_type
        if isinstance(expected_type, tuple):
            names = "/".join(t.__name__ for t in expected_type)
            self.message = message or f"Must be of type {names}"
        else:
            self.message = message or f"Must be of type {expected_type.__name__}"
        self.code = "type_error"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if not isinstance(value, self.expected_type):
            return self._fail(field, value)
        return self._success(value)


class IsString(TypeValidator):
    """Validate value is a string."""

    def __init__(self, message: str = "Must be a string"):
        super().__init__(str, message)


class IsInt(TypeValidator):
    """Validate value is an integer."""

    def __init__(self, message: str = "Must be an integer"):
        super().__init__(int, message)


class IsFloat(TypeValidator):
    """Validate value is a float (int or float)."""

    def __init__(self, message: str = "Must be a number"):
        super().__init__((int, float), message)


class IsBool(TypeValidator):
    """Validate value is a boolean."""

    def __init__(self, message: str = "Must be a boolean"):
        super().__init__(bool, message)


class IsList(TypeValidator):
    """Validate value is a list."""

    def __init__(self, message: str = "Must be a list"):
        super().__init__(list, message)


class IsDict(TypeValidator):
    """Validate value is a dictionary."""

    def __init__(self, message: str = "Must be a dictionary"):
        super().__init__(dict, message)


# =============================================================================
# Required / Optional
# =============================================================================


class Required(BaseValidator):
    """Validate that a value is present and not empty."""

    def __init__(
        self,
        message: str = "This field is required",
        allow_empty: bool = False,
    ):
        self.message = message
        self.code = "required"
        self.allow_empty = allow_empty

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._fail(field, value)
        if not self.allow_empty:
            if isinstance(value, str) and not value.strip():
                return self._fail(field, value)
            if isinstance(value, (list, dict)) and len(value) == 0:
                return self._fail(field, value)
        return self._success(value)


class OptionalField(BaseValidator):
    """Mark a field as optional (always passes). Returns default when None."""

    def __init__(self, default: Any = None):
        self.default = default

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(self.default)
        return self._success(value)


# Keep 'Optional' name for convenience — shadows typing.Optional locally
# but users import validators explicitly
_Optional = OptionalField


# =============================================================================
# String Validators
# =============================================================================


class MinLength(BaseValidator):
    """Validate minimum string length."""

    def __init__(self, min_length: int, message: str = None):
        self.min_length = min_length
        self.message = message or f"Must be at least {min_length} characters"
        self.code = "min_length"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            value = str(value)
        if len(value) < self.min_length:
            return self._fail(field, value)
        return self._success(value)


class MaxLength(BaseValidator):
    """Validate maximum string length."""

    def __init__(self, max_length: int, message: str = None):
        self.max_length = max_length
        self.message = message or f"Must be at most {max_length} characters"
        self.code = "max_length"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            value = str(value)
        if len(value) > self.max_length:
            return self._fail(field, value)
        return self._success(value)


class Length(BaseValidator):
    """Validate string length is within range."""

    def __init__(
        self, min_length: int = 0, max_length: int = None, message: str = None
    ):
        self.min_length = min_length
        self.max_length = max_length
        if max_length:
            self.message = (
                message
                or f"Must be between {min_length} and {max_length} characters"
            )
        else:
            self.message = message or f"Must be at least {min_length} characters"
        self.code = "length"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            value = str(value)
        length = len(value)
        if length < self.min_length:
            return self._fail(field, value)
        if self.max_length and length > self.max_length:
            return self._fail(field, value)
        return self._success(value)


class Regex(BaseValidator):
    """Validate string matches a regex pattern."""

    def __init__(self, pattern: str, flags: int = 0, message: str = None):
        self.pattern = re.compile(pattern, flags)
        self.message = message or "Does not match required pattern"
        self.code = "regex"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            value = str(value)
        if not self.pattern.match(value):
            return self._fail(field, value)
        return self._success(value)


class Email(BaseValidator):
    """Validate email address format."""

    EMAIL_PATTERN = re.compile(
        r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    )

    def __init__(self, message: str = "Invalid email address"):
        self.message = message
        self.code = "email"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        if not self.EMAIL_PATTERN.match(value):
            return self._fail(field, value)
        return self._success(value.lower())


class URL(BaseValidator):
    """Validate URL format."""

    URL_PATTERN = re.compile(
        r"^https?://"
        r"(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|"
        r"localhost|"
        r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"
        r"(?::\d+)?"
        r"(?:/?|[/?]\S+)$",
        re.IGNORECASE,
    )

    def __init__(self, message: str = "Invalid URL"):
        self.message = message
        self.code = "url"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        if not self.URL_PATTERN.match(value):
            return self._fail(field, value)
        return self._success(value)


class Slug(BaseValidator):
    """Validate URL-safe slug."""

    SLUG_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

    def __init__(self, message: str = "Invalid slug format"):
        self.message = message
        self.code = "slug"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        if not self.SLUG_PATTERN.match(value):
            return self._fail(field, value)
        return self._success(value)


class UUIDValidator(BaseValidator):
    """Validate UUID format."""

    UUID_PATTERN = re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        re.IGNORECASE,
    )

    def __init__(self, message: str = "Invalid UUID format"):
        self.message = message
        self.code = "uuid"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        if not self.UUID_PATTERN.match(value):
            return self._fail(field, value)
        return self._success(value)


# Alias for convenience
UUID = UUIDValidator


class NoWhitespace(BaseValidator):
    """Validate string contains no whitespace."""

    def __init__(self, message: str = "Must not contain whitespace"):
        self.message = message
        self.code = "no_whitespace"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        if any(c.isspace() for c in value):
            return self._fail(field, value)
        return self._success(value)


class Alphanumeric(BaseValidator):
    """Validate string is alphanumeric."""

    def __init__(self, allow_underscore: bool = False, message: str = None):
        self.allow_underscore = allow_underscore
        self.message = message or "Must be alphanumeric"
        self.code = "alphanumeric"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        check_value = value.replace("_", "") if self.allow_underscore else value
        if not check_value.isalnum():
            return self._fail(field, value)
        return self._success(value)


# =============================================================================
# Number Validators
# =============================================================================


class Min(BaseValidator):
    """Validate minimum numeric value."""

    def __init__(
        self, min_value: float, inclusive: bool = True, message: str = None
    ):
        self.min_value = min_value
        self.inclusive = inclusive
        op = ">=" if inclusive else ">"
        self.message = message or f"Must be {op} {min_value}"
        self.code = "min_value"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (int, float)):
            return self._fail(field, value)
        if self.inclusive:
            if value < self.min_value:
                return self._fail(field, value)
        else:
            if value <= self.min_value:
                return self._fail(field, value)
        return self._success(value)


class Max(BaseValidator):
    """Validate maximum numeric value."""

    def __init__(
        self, max_value: float, inclusive: bool = True, message: str = None
    ):
        self.max_value = max_value
        self.inclusive = inclusive
        op = "<=" if inclusive else "<"
        self.message = message or f"Must be {op} {max_value}"
        self.code = "max_value"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (int, float)):
            return self._fail(field, value)
        if self.inclusive:
            if value > self.max_value:
                return self._fail(field, value)
        else:
            if value >= self.max_value:
                return self._fail(field, value)
        return self._success(value)


class Range(BaseValidator):
    """Validate numeric value is within range."""

    def __init__(
        self,
        min_value: float,
        max_value: float,
        inclusive: bool = True,
        message: str = None,
    ):
        self.min_value = min_value
        self.max_value = max_value
        self.inclusive = inclusive
        self.message = message or f"Must be between {min_value} and {max_value}"
        self.code = "range"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (int, float)):
            return self._fail(field, value)
        if self.inclusive:
            if value < self.min_value or value > self.max_value:
                return self._fail(field, value)
        else:
            if value <= self.min_value or value >= self.max_value:
                return self._fail(field, value)
        return self._success(value)


class Positive(BaseValidator):
    """Validate value is positive."""

    def __init__(self, allow_zero: bool = False, message: str = None):
        self.allow_zero = allow_zero
        self.message = message or ("Must be >= 0" if allow_zero else "Must be > 0")
        self.code = "positive"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (int, float)):
            return self._fail(field, value)
        if self.allow_zero:
            if value < 0:
                return self._fail(field, value)
        else:
            if value <= 0:
                return self._fail(field, value)
        return self._success(value)


class Negative(BaseValidator):
    """Validate value is negative."""

    def __init__(self, allow_zero: bool = False, message: str = None):
        self.allow_zero = allow_zero
        self.message = message or ("Must be <= 0" if allow_zero else "Must be < 0")
        self.code = "negative"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (int, float)):
            return self._fail(field, value)
        if self.allow_zero:
            if value > 0:
                return self._fail(field, value)
        else:
            if value >= 0:
                return self._fail(field, value)
        return self._success(value)


# =============================================================================
# Collection Validators
# =============================================================================


class MinItems(BaseValidator):
    """Validate minimum number of items in a collection."""

    def __init__(self, min_items: int, message: str = None):
        self.min_items = min_items
        self.message = message or f"Must have at least {min_items} items"
        self.code = "min_items"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not hasattr(value, "__len__"):
            return self._fail(field, value)
        if len(value) < self.min_items:
            return self._fail(field, value)
        return self._success(value)


class MaxItems(BaseValidator):
    """Validate maximum number of items in a collection."""

    def __init__(self, max_items: int, message: str = None):
        self.max_items = max_items
        self.message = message or f"Must have at most {max_items} items"
        self.code = "max_items"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not hasattr(value, "__len__"):
            return self._fail(field, value)
        if len(value) > self.max_items:
            return self._fail(field, value)
        return self._success(value)


class UniqueItems(BaseValidator):
    """Validate all items in a collection are unique."""

    def __init__(self, message: str = "All items must be unique"):
        self.message = message
        self.code = "unique_items"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (list, tuple)):
            return self._fail(field, value)
        try:
            if len(value) != len(set(value)):
                return self._fail(field, value)
        except TypeError:
            seen: list = []
            for item in value:
                if item in seen:
                    return self._fail(field, value)
                seen.append(item)
        return self._success(value)


class Each(BaseValidator):
    """Validate each item in a collection."""

    def __init__(self, *validators: BaseValidator):
        self.validators = validators
        self.code = "each"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, (list, tuple)):
            return ValidationResult.failure(field, "Must be a list", "type_error")

        result = ValidationResult(is_valid=True, data=[])
        for i, item in enumerate(value):
            item_field = f"{field}[{i}]" if field else f"[{i}]"
            for validator in self.validators:
                v_result = validator.validate(item, item_field)
                if not v_result.is_valid:
                    result.merge(v_result)
                    break
            else:
                result.data.append(item)
        return result


class OneOf(BaseValidator):
    """Validate value is one of allowed values."""

    def __init__(self, allowed: list, message: str = None):
        self.allowed = allowed
        self.message = message or f"Must be one of: {', '.join(str(a) for a in allowed)}"
        self.code = "one_of"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if value not in self.allowed:
            return self._fail(field, value)
        return self._success(value)


class NoneOf(BaseValidator):
    """Validate value is not one of disallowed values."""

    def __init__(self, disallowed: list, message: str = None):
        self.disallowed = disallowed
        self.message = (
            message
            or f"Must not be one of: {', '.join(str(a) for a in disallowed)}"
        )
        self.code = "none_of"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if value in self.disallowed:
            return self._fail(field, value)
        return self._success(value)


# =============================================================================
# Date/Time Validators
# =============================================================================


class DateFormat(BaseValidator):
    """Validate date string format."""

    def __init__(self, fmt: str = "%Y-%m-%d", message: str = None):
        self.fmt = fmt
        self.message = message or f"Must be a valid date in format {fmt}"
        self.code = "date_format"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if isinstance(value, (date, datetime)):
            return self._success(value)
        if not isinstance(value, str):
            return self._fail(field, value)
        try:
            parsed = datetime.strptime(value, self.fmt)
            return self._success(parsed)
        except ValueError:
            return self._fail(field, value)


class FutureDate(BaseValidator):
    """Validate date is in the future."""

    def __init__(self, message: str = "Must be a future date"):
        self.message = message
        self.code = "future_date"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if isinstance(value, datetime):
            if value <= datetime.now():
                return self._fail(field, value)
        elif isinstance(value, date):
            if value <= date.today():
                return self._fail(field, value)
        else:
            return self._fail(field, value)
        return self._success(value)


class PastDate(BaseValidator):
    """Validate date is in the past."""

    def __init__(self, message: str = "Must be a past date"):
        self.message = message
        self.code = "past_date"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if isinstance(value, datetime):
            if value >= datetime.now():
                return self._fail(field, value)
        elif isinstance(value, date):
            if value >= date.today():
                return self._fail(field, value)
        else:
            return self._fail(field, value)
        return self._success(value)


# =============================================================================
# Custom Validators
# =============================================================================


class Custom(BaseValidator):
    """Create a custom validator from a function.

    The function should accept a value and return True if valid.
    """

    def __init__(
        self,
        func: Callable[[Any], bool],
        message: str = "Validation failed",
        code: str = "custom",
    ):
        self.func = func
        self.message = message
        self.code = code

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        try:
            if not self.func(value):
                return self._fail(field, value)
        except Exception:
            return self._fail(field, value)
        return self._success(value)


class Lambda(BaseValidator):
    """Create validator from callable that returns ``(valid, message)``."""

    def __init__(
        self, func: Callable[[Any], Tuple[bool, str]], code: str = "lambda"
    ):
        self.func = func
        self.code = code

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        try:
            valid, message = self.func(value)
            if not valid:
                result = ValidationResult(is_valid=False)
                result.add_error(field, message, self.code, value)
                return result
        except Exception as exc:
            result = ValidationResult(is_valid=False)
            result.add_error(field, str(exc), "error", value)
            return result
        return self._success(value)


# =============================================================================
# Validation Chain
# =============================================================================


class Chain(BaseValidator):
    """Chain multiple validators together sequentially."""

    def __init__(
        self, *validators: BaseValidator, stop_on_first_error: bool = True
    ):
        self.validators = validators
        self.stop_on_first_error = stop_on_first_error

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        result = ValidationResult(is_valid=True, data=value)
        for validator in self.validators:
            v_result = validator.validate(value, field)
            if not v_result.is_valid:
                result.merge(v_result)
                if self.stop_on_first_error:
                    break
            else:
                value = v_result.data  # Use transformed value
        if result.is_valid:
            result.data = value
        return result


# =============================================================================
# Schema Validation
# =============================================================================


class Schema:
    """Validate a dictionary against a schema.

    Usage::

        schema = Schema({
            "name": [Required(), MinLength(2)],
            "email": [Required(), Email()],
            "age": [OptionalField(), Range(0, 120)],
        })
        result = schema.validate(data)
    """

    def __init__(
        self,
        fields: Dict[str, list],
        allow_extra: bool = False,
        strip_extra: bool = True,
    ):
        """Initialize schema.

        Args:
            fields: Map of field names to lists of validators.
            allow_extra: Allow fields not in schema.
            strip_extra: Remove extra fields from result.
        """
        self.fields = fields
        self.allow_extra = allow_extra
        self.strip_extra = strip_extra

    def validate(self, data: Dict[str, Any]) -> ValidationResult:
        """Validate data against schema."""
        if not isinstance(data, dict):
            return ValidationResult.failure("", "Expected a dictionary", "type_error")

        result = ValidationResult(is_valid=True, data={})

        # Check extra fields
        if not self.allow_extra:
            extra_fields = set(data.keys()) - set(self.fields.keys())
            for fld in extra_fields:
                result.add_error(fld, "Unknown field", "extra_field")

        # Validate each field
        for field_name, validators in self.fields.items():
            value = data.get(field_name)
            for validator in validators:
                v_result = validator.validate(value, field_name)
                if not v_result.is_valid:
                    result.merge(v_result)
                    break
                value = v_result.data

            if result.is_valid or field_name not in [
                e.field for e in result.errors
            ]:
                if not self.strip_extra or field_name in self.fields:
                    result.data[field_name] = value

        # Copy non-validated fields if allowed
        if self.allow_extra and not self.strip_extra:
            for key, value in data.items():
                if key not in self.fields:
                    result.data[key] = value

        return result

    def partial(self) -> "Schema":
        """Create a partial schema (all fields optional)."""
        new_fields: Dict[str, list] = {}
        for name, validators in self.fields.items():
            new_validators = [
                v for v in validators if not isinstance(v, Required)
            ]
            if not any(isinstance(v, OptionalField) for v in new_validators):
                new_validators.insert(0, OptionalField())
            new_fields[name] = new_validators
        return Schema(new_fields, self.allow_extra, self.strip_extra)


class NestedSchema(BaseValidator):
    """Validate nested object with a schema."""

    def __init__(self, schema: Schema):
        self.schema = schema
        self.code = "nested"

    def validate(self, value: Any, field: str = "") -> ValidationResult:
        if value is None:
            return self._success(value)
        if not isinstance(value, dict):
            return ValidationResult.failure(
                field, "Expected a dictionary", "type_error"
            )
        result = self.schema.validate(value)
        if not result.is_valid:
            for error in result.errors:
                error.field = (
                    f"{field}.{error.field}" if field else error.field
                )
        return result


# =============================================================================
# Convenience Validator Class
# =============================================================================


class Validator:
    """Convenience class for validating individual values.

    Usage::

        v = Validator()
        result = v.validate("test@example.com", Email())
        result = v.validate(25, Range(18, 120))
    """

    def validate(
        self,
        value: Any,
        *validators: BaseValidator,
        field: str = "",
    ) -> ValidationResult:
        """Validate a value with one or more validators."""
        chain = Chain(*validators)
        return chain.validate(value, field)

    def is_valid(self, value: Any, *validators: BaseValidator) -> bool:
        """Check if value passes all validators."""
        return self.validate(value, *validators).is_valid

    def email(self, value: str, field: str = "") -> ValidationResult:
        """Validate email."""
        return self.validate(value, Required(), Email(), field=field)

    def url(self, value: str, field: str = "") -> ValidationResult:
        """Validate URL."""
        return self.validate(value, Required(), URL(), field=field)

    def positive_int(self, value: Any, field: str = "") -> ValidationResult:
        """Validate positive integer."""
        return self.validate(value, Required(), IsInt(), Positive(), field=field)

    def string_length(
        self,
        value: str,
        min_len: int = 0,
        max_len: int = None,
        field: str = "",
    ) -> ValidationResult:
        """Validate string length."""
        validators: list = [Required(), IsString()]
        if min_len:
            validators.append(MinLength(min_len))
        if max_len:
            validators.append(MaxLength(max_len))
        return self.validate(value, *validators, field=field)


# =============================================================================
# Module-level convenience functions
# =============================================================================


def validate(value: Any, *validators: BaseValidator, field: str = "") -> ValidationResult:
    """Quick-validate a value against one or more validators.

    Args:
        value: Value to validate.
        *validators: Validators to apply sequentially.
        field: Field name for error messages.

    Returns:
        ValidationResult.
    """
    return Chain(*validators).validate(value, field)


def validate_dict(
    data: Dict[str, Any],
    fields: Dict[str, list],
    allow_extra: bool = False,
) -> ValidationResult:
    """Quick-validate a dictionary against field rules.

    Args:
        data: Dictionary to validate.
        fields: Map of field names to lists of validators.
        allow_extra: Allow extra fields.

    Returns:
        ValidationResult.
    """
    return Schema(fields, allow_extra=allow_extra).validate(data)
