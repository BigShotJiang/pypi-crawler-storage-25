"""
GDPR-compliant text anonymization with Swedish PII detection and reversible mappings.

Supports multiple anonymization levels, replacement strategies, and role-aware
processing (e.g., stricter handling for minors and victims).
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class AnonymizationLevel(Enum):
    NONE = 0
    MINIMAL = 1
    STANDARD = 2
    STRICT = 3
    MAXIMUM = 4


class ReplacementStrategy(Enum):
    PSEUDONYM = auto()
    REDACT = auto()
    MASK = auto()
    GENERALIZE = auto()
    HASH = auto()
    PLACEHOLDER = auto()


class DataType(Enum):
    NAME = "NAME"
    EMAIL = "EMAIL"
    PHONE = "PHONE"
    ADDRESS = "ADDRESS"
    PERSONNUMMER = "PERSONNUMMER"
    COMPANY = "COMPANY"
    DATE_OF_BIRTH = "DATE_OF_BIRTH"
    BANK_ACCOUNT = "BANK_ACCOUNT"
    PLATE_NUMBER = "PLATE_NUMBER"
    IP_ADDRESS = "IP_ADDRESS"


class Role(Enum):
    ORDINARY = auto()
    MINOR = auto()
    VICTIM = auto()
    PUBLIC_FIGURE = auto()
    DEFENDANT = auto()
    WHISTLEBLOWER = auto()


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class PII:
    data_type: DataType
    value: str
    start: int
    end: int
    confidence: float


@dataclass
class AnonymizationRule:
    data_type: DataType
    level: AnonymizationLevel
    strategy: ReplacementStrategy
    custom_replacement: Optional[str] = None


@dataclass
class AnonymizationResult:
    anonymized_text: str
    original_text: str
    mappings: dict[str, str]
    pii_found: list[PII]
    statistics: dict


# ---------------------------------------------------------------------------
# Pseudonym pools
# ---------------------------------------------------------------------------

SWEDISH_NAMES: list[str] = [
    "Erik", "Lars", "Karl", "Anders", "Johan", "Per", "Nils", "Lennart",
    "Emil", "Oskar", "Anna", "Maria", "Ingrid", "Karin", "Kristina",
    "Sara", "Lena", "Helena", "Birgitta", "Eva", "Sven", "Magnus",
    "Gustav", "Axel", "Viktor", "Maja", "Elsa", "Saga", "Alva", "Sigrid",
    "Björn", "Mikael", "Stefan", "Håkan", "Ulf", "Gunnar", "Roland",
    "Rolf", "Bengt", "Mattias",
]

_SWEDISH_SURNAMES: list[str] = [
    "Andersson", "Johansson", "Karlsson", "Nilsson", "Eriksson", "Larsson",
    "Olsson", "Persson", "Svensson", "Gustafsson", "Pettersson", "Jonsson",
    "Jansson", "Hansson", "Bengtsson", "Jönsson", "Lindberg", "Jakobsson",
    "Magnusson", "Lindström", "Lindqvist", "Lindgren", "Berg", "Bergström",
    "Lundberg", "Lund", "Holm", "Dahl", "Nyström", "Söderberg",
]

_PLACEHOLDER_COMPANIES: list[str] = [
    "Bolaget AB", "Företaget AB", "Koncernen AB", "Gruppen AB", "Verksamheten AB",
]

_PLACEHOLDER_DOMAINS: list[str] = [
    "example.com", "anonymized.se", "redacted.org",
]


# ---------------------------------------------------------------------------
# PII Detector
# ---------------------------------------------------------------------------

class PIIDetector:
    """Detects personally identifiable information in Swedish-language text."""

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(self, text: str) -> list[PII]:
        """Run all detectors and return PII items sorted by position."""
        results: list[PII] = []
        results.extend(self._detect_emails(text))
        results.extend(self._detect_phones(text))
        results.extend(self._detect_personnummer(text))
        results.extend(self._detect_ip_addresses(text))
        results.extend(self._detect_plate_numbers(text))
        results.extend(self._detect_bank_accounts(text))

        # Deduplicate overlapping spans — keep highest-confidence item
        results = self._deduplicate(results)
        return sorted(results, key=lambda p: p.start)

    # ------------------------------------------------------------------
    # Individual detectors
    # ------------------------------------------------------------------

    def _detect_emails(self, text: str) -> list[PII]:
        pattern = re.compile(
            r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
        )
        return [
            PII(DataType.EMAIL, m.group(), m.start(), m.end(), 0.98)
            for m in pattern.finditer(text)
        ]

    def _detect_phones(self, text: str) -> list[PII]:
        """Detect Swedish phone numbers in various formats."""
        patterns = [
            # International: +46 70 123 45 67 or +46-70-123-45-67
            r"\+46[\s\-]?\d{2}[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}",
            # Mobile: 070 123 45 67 / 073-123 45 67
            r"0[6-9]\d[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}",
            # Stockholm landline: 08-xxx xx xx
            r"08[\s\-]\d{3}[\s\-]\d{2}[\s\-]\d{2}",
            # Other landlines: 0xx-xx xx xx
            r"0\d{1,3}[\s\-]\d{2,3}[\s\-]\d{2}[\s\-]\d{2}",
            # Short mobile without separator: 0701234567
            r"0[6-9]\d{8}\b",
        ]
        combined = re.compile("|".join(f"(?:{p})" for p in patterns))
        return [
            PII(DataType.PHONE, m.group().strip(), m.start(), m.end(), 0.90)
            for m in combined.finditer(text)
        ]

    def _detect_personnummer(self, text: str) -> list[PII]:
        """Detect Swedish personnummer (YYMMDD-XXXX or YYYYMMDD-XXXX)."""
        # Formats: YYMMDD-NNNN, YYMMDD+NNNN (100+), YYYYMMDDNNNN
        pattern = re.compile(
            r"\b(\d{6}|\d{8})([-+])(\d{4})\b"
            r"|\b(\d{12})\b"
        )
        results: list[PII] = []
        for m in pattern.finditer(text):
            raw = m.group()
            # Normalise to 10 digits for Luhn check
            digits = re.sub(r"[-+\s]", "", raw)
            if len(digits) == 12:
                digits_10 = digits[2:]  # drop century
            elif len(digits) == 10:
                digits_10 = digits
            else:
                continue

            if self._luhn_check(digits_10):
                results.append(PII(DataType.PERSONNUMMER, raw, m.start(), m.end(), 0.97))
            else:
                # Still flag with lower confidence — may be valid with century prefix
                results.append(PII(DataType.PERSONNUMMER, raw, m.start(), m.end(), 0.60))

        return results

    def _detect_ip_addresses(self, text: str) -> list[PII]:
        """Detect IPv4 addresses."""
        pattern = re.compile(
            r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}"
            r"(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
        )
        return [
            PII(DataType.IP_ADDRESS, m.group(), m.start(), m.end(), 0.95)
            for m in pattern.finditer(text)
        ]

    def _detect_plate_numbers(self, text: str) -> list[PII]:
        """Detect Swedish vehicle registration plates (ABC 123 or ABC12D format)."""
        # Classic: 3 letters, space, 3 digits (optionally last digit replaced by letter)
        pattern = re.compile(r"\b[A-ZÅÄÖ]{3}[\s]?\d{2}[A-Z0-9]\b", re.IGNORECASE)
        return [
            PII(DataType.PLATE_NUMBER, m.group(), m.start(), m.end(), 0.85)
            for m in pattern.finditer(text)
        ]

    def _detect_bank_accounts(self, text: str) -> list[PII]:
        """Detect Swedish bank clearing number + account number patterns."""
        # Clearing: 4 digits, account: 7-10 digits, separated by space or dash
        pattern = re.compile(
            r"\b\d{4}[\s\-]\d{7,10}\b"
            r"|\b\d{4,5}[\s\-]\d{6,10}\b"
        )
        results: list[PII] = []
        for m in pattern.finditer(text):
            raw = m.group()
            digits = re.sub(r"[\s\-]", "", raw)
            # Basic sanity: total digit count typical for Swedish bank accounts
            if 11 <= len(digits) <= 15:
                results.append(PII(DataType.BANK_ACCOUNT, raw, m.start(), m.end(), 0.80))
        return results

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _luhn_check(digits: str) -> bool:
        """Validate a digit string using the Luhn algorithm (used for personnummer)."""
        if not digits.isdigit():
            return False
        total = 0
        for i, ch in enumerate(digits):
            n = int(ch)
            if i % 2 == 0:  # double every other digit from the left
                n *= 2
                if n > 9:
                    n -= 9
            total += n
        return total % 10 == 0

    @staticmethod
    def _deduplicate(items: list[PII]) -> list[PII]:
        """Remove overlapping PII items, keeping highest confidence."""
        if not items:
            return items
        items = sorted(items, key=lambda p: (p.start, -p.confidence))
        kept: list[PII] = []
        last_end = -1
        for item in items:
            if item.start >= last_end:
                kept.append(item)
                last_end = item.end
            else:
                # Overlapping — replace last if new has higher confidence
                if item.confidence > kept[-1].confidence:
                    kept[-1] = item
                    last_end = item.end
        return kept


# ---------------------------------------------------------------------------
# Anonymizer
# ---------------------------------------------------------------------------

# Default strategy per level
_LEVEL_STRATEGIES: dict[AnonymizationLevel, ReplacementStrategy] = {
    AnonymizationLevel.NONE: ReplacementStrategy.PLACEHOLDER,
    AnonymizationLevel.MINIMAL: ReplacementStrategy.GENERALIZE,
    AnonymizationLevel.STANDARD: ReplacementStrategy.PSEUDONYM,
    AnonymizationLevel.STRICT: ReplacementStrategy.MASK,
    AnonymizationLevel.MAXIMUM: ReplacementStrategy.REDACT,
}

# Override strategies for sensitive roles
_ROLE_OVERRIDES: dict[Role, AnonymizationLevel] = {
    Role.MINOR: AnonymizationLevel.MAXIMUM,
    Role.VICTIM: AnonymizationLevel.MAXIMUM,
    Role.WHISTLEBLOWER: AnonymizationLevel.MAXIMUM,
    Role.DEFENDANT: AnonymizationLevel.STRICT,
    Role.PUBLIC_FIGURE: AnonymizationLevel.MINIMAL,
    Role.ORDINARY: AnonymizationLevel.STANDARD,
}


class Anonymizer:
    """
    GDPR-compliant text anonymizer.

    Supports reversible pseudonymization via stored mappings so that
    authorized processors can deanonymize text for legitimate purposes.
    """

    def __init__(
        self,
        level: AnonymizationLevel = AnonymizationLevel.STANDARD,
        rules: Optional[list[AnonymizationRule]] = None,
        seed: Optional[int] = None,
    ) -> None:
        self.level = level
        self._rules: list[AnonymizationRule] = rules or []
        self._seed = seed
        self._detector = PIIDetector()
        # Persistent pseudonym cache so the same value always maps to the
        # same pseudonym within a session.
        self._pseudonym_cache: dict[str, str] = {}
        self._statistics: dict = {
            "total_processed": 0,
            "total_pii_found": 0,
            "by_type": {dt.value: 0 for dt in DataType},
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def anonymize(
        self, text: str, role: Role = Role.ORDINARY
    ) -> AnonymizationResult:
        """Detect and replace all PII in *text*."""
        pii_list = self._detector.detect(text)
        mappings: dict[str, str] = {}
        result_chars = list(text)
        offset = 0

        for pii in pii_list:
            strategy = self._get_strategy_for_level(pii.data_type, self.level, role)
            replacement = self._apply_strategy(pii.value, pii.data_type, strategy)
            mappings[replacement] = pii.value

            # Splice replacement into character list, adjusting for prior edits
            adj_start = pii.start + offset
            adj_end = pii.end + offset
            result_chars[adj_start:adj_end] = list(replacement)
            offset += len(replacement) - (pii.end - pii.start)

        anonymized = "".join(result_chars)

        # Update statistics
        self._statistics["total_processed"] += 1
        self._statistics["total_pii_found"] += len(pii_list)
        for pii in pii_list:
            self._statistics["by_type"][pii.data_type.value] += 1

        stats = {
            "pii_count": len(pii_list),
            "types_found": list({p.data_type.value for p in pii_list}),
            "role": role.name,
            "level": self.level.name,
        }

        return AnonymizationResult(
            anonymized_text=anonymized,
            original_text=text,
            mappings=mappings,
            pii_found=pii_list,
            statistics=stats,
        )

    def deanonymize(self, text: str, mappings: dict[str, str]) -> str:
        """Reverse the anonymization using the provided mappings."""
        # Replace longest tokens first to avoid partial substitution issues
        for token in sorted(mappings, key=len, reverse=True):
            original = mappings[token]
            text = text.replace(token, original)
        return text

    def add_rule(self, rule: AnonymizationRule) -> None:
        """Add or override an anonymization rule for a specific data type."""
        # Remove existing rule for same data_type+level combination
        self._rules = [
            r for r in self._rules
            if not (r.data_type == rule.data_type and r.level == rule.level)
        ]
        self._rules.append(rule)

    def get_statistics(self) -> dict:
        """Return cumulative processing statistics."""
        return dict(self._statistics)

    # ------------------------------------------------------------------
    # Strategy dispatcher
    # ------------------------------------------------------------------

    def _apply_strategy(
        self,
        value: str,
        data_type: DataType,
        strategy: ReplacementStrategy,
    ) -> str:
        if strategy == ReplacementStrategy.PSEUDONYM:
            return self._pseudonymize(value, data_type)
        if strategy == ReplacementStrategy.REDACT:
            return self._redact(value, data_type)
        if strategy == ReplacementStrategy.MASK:
            return self._mask(value, data_type)
        if strategy == ReplacementStrategy.GENERALIZE:
            return self._generalize(value, data_type)
        if strategy == ReplacementStrategy.HASH:
            return self._hash_value(value)
        # PLACEHOLDER
        return f"[{data_type.value}]"

    # ------------------------------------------------------------------
    # Strategy implementations
    # ------------------------------------------------------------------

    def _pseudonymize(self, value: str, data_type: DataType) -> str:
        """Return a consistent pseudonym derived from the value's hash."""
        if value in self._pseudonym_cache:
            return self._pseudonym_cache[value]

        h = int(hashlib.sha256(value.encode()).hexdigest(), 16)
        seed = (h ^ (self._seed or 0xDEADBEEF)) & 0xFFFFFFFF

        if data_type == DataType.EMAIL:
            first = SWEDISH_NAMES[seed % len(SWEDISH_NAMES)].lower()
            domain = _PLACEHOLDER_DOMAINS[(seed >> 8) % len(_PLACEHOLDER_DOMAINS)]
            replacement = f"{first}@{domain}"

        elif data_type == DataType.PHONE:
            # Produce a plausible-looking but fake Swedish mobile number
            suffix = str((seed % 9000000) + 1000000)
            replacement = f"070-{suffix[:3]} {suffix[3:5]} {suffix[5:]}"

        elif data_type == DataType.PERSONNUMMER:
            # Keep the structure but scramble the digits
            digits = re.sub(r"[-+\s]", "", value)
            fake_suffix = str((seed % 9000) + 1000)
            if len(digits) == 12:
                replacement = f"{digits[:8]}-{fake_suffix}"
            else:
                replacement = f"{digits[:6]}-{fake_suffix}"

        elif data_type == DataType.IP_ADDRESS:
            parts = [str((seed >> (i * 8)) & 0xFF) for i in range(4)]
            # Avoid real-looking addresses; anchor in documentation range
            replacement = f"192.0.2.{int(parts[0]) % 256}"

        elif data_type == DataType.PLATE_NUMBER:
            letters = "ABCDEFGHJKLMNOPRSTUVWXY"
            a = letters[(seed) % len(letters)]
            b = letters[(seed >> 4) % len(letters)]
            c = letters[(seed >> 8) % len(letters)]
            num = (seed % 900) + 100
            replacement = f"{a}{b}{c} {num}"

        elif data_type == DataType.BANK_ACCOUNT:
            clearing = str((seed % 9000) + 1000)
            account = str((seed % 9000000) + 1000000)
            replacement = f"{clearing}-{account}"

        elif data_type == DataType.NAME:
            first = SWEDISH_NAMES[seed % len(SWEDISH_NAMES)]
            last = _SWEDISH_SURNAMES[(seed >> 4) % len(_SWEDISH_SURNAMES)]
            replacement = f"{first} {last}"

        elif data_type == DataType.COMPANY:
            replacement = _PLACEHOLDER_COMPANIES[seed % len(_PLACEHOLDER_COMPANIES)]

        else:
            replacement = f"[PSEUDONYM-{self._hash_value(value)[:8].upper()}]"

        self._pseudonym_cache[value] = replacement
        return replacement

    def _redact(self, value: str, data_type: DataType) -> str:
        """Replace value with a labelled redaction marker."""
        labels = {
            DataType.EMAIL: "REDACTED EMAIL",
            DataType.PHONE: "REDACTED PHONE",
            DataType.PERSONNUMMER: "REDACTED PERSONNUMMER",
            DataType.IP_ADDRESS: "REDACTED IP",
            DataType.PLATE_NUMBER: "REDACTED PLATE",
            DataType.BANK_ACCOUNT: "REDACTED BANK ACCOUNT",
            DataType.NAME: "REDACTED NAME",
            DataType.ADDRESS: "REDACTED ADDRESS",
            DataType.COMPANY: "REDACTED COMPANY",
            DataType.DATE_OF_BIRTH: "REDACTED DOB",
        }
        label = labels.get(data_type, f"REDACTED {data_type.value}")
        return f"[{label}]"

    def _mask(self, value: str, data_type: DataType) -> str:
        """Partially obscure the value while preserving its type-structure."""
        if data_type == DataType.EMAIL:
            if "@" in value:
                local, domain = value.rsplit("@", 1)
                masked_local = local[0] + "***" if local else "***"
                parts = domain.split(".", 1)
                masked_domain = parts[0][0] + "***" + ("." + parts[1] if len(parts) > 1 else "")
                return f"{masked_local}@{masked_domain}"
            return "***@***.***"

        if data_type == DataType.PHONE:
            digits = re.sub(r"\D", "", value)
            if len(digits) >= 6:
                return digits[:3] + "-" + "*" * (len(digits) - 6) + digits[-3:]
            return "***-***"

        if data_type == DataType.PERSONNUMMER:
            raw = re.sub(r"[-+\s]", "", value)
            # Keep birth date part, mask last 4 digits
            if len(raw) >= 10:
                return raw[:6] + "-" + "****"
            return "******-****"

        if data_type == DataType.BANK_ACCOUNT:
            digits = re.sub(r"[\s\-]", "", value)
            # Show clearing, mask account
            return digits[:4] + "-" + "*" * (len(digits) - 4)

        if data_type == DataType.IP_ADDRESS:
            parts = value.split(".")
            if len(parts) == 4:
                return f"{parts[0]}.{parts[1]}.*.*"
            return "*.*.*.*"

        # Generic mask: show first and last character
        if len(value) > 2:
            return value[0] + "*" * (len(value) - 2) + value[-1]
        return "*" * len(value)

    def _generalize(self, value: str, data_type: DataType) -> str:
        """Replace value with a generalized, less specific version."""
        if data_type == DataType.EMAIL:
            if "@" in value:
                _, domain = value.rsplit("@", 1)
                return f"[user@{domain}]"
            return "[email address]"

        if data_type == DataType.PHONE:
            # Keep country/area code only
            if value.startswith("+46"):
                return "+46-XXXXXXX"
            digits = re.sub(r"\D", "", value)
            if len(digits) >= 3:
                return digits[:3] + "-XXXXXXX"
            return "[phone number]"

        if data_type == DataType.PERSONNUMMER:
            raw = re.sub(r"[-+\s]", "", value)
            # Keep decade of birth only
            if len(raw) >= 4:
                decade = raw[:2]
                return f"[born {decade}xx]"
            return "[personnummer]"

        if data_type == DataType.IP_ADDRESS:
            parts = value.split(".")
            if len(parts) >= 2:
                return f"{parts[0]}.{parts[1]}.0.0/16"
            return "[IP address]"

        if data_type == DataType.DATE_OF_BIRTH:
            # Extract year if present
            year_match = re.search(r"\b(19|20)\d{2}\b", value)
            if year_match:
                return f"[born {year_match.group()}]"
            return "[date of birth]"

        return f"[{data_type.value.lower()}]"

    def _hash_value(self, value: str) -> str:
        """Return a truncated SHA-256 hex digest of the value."""
        return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]

    # ------------------------------------------------------------------
    # Level / role logic
    # ------------------------------------------------------------------

    def _get_strategy_for_level(
        self,
        data_type: DataType,
        level: AnonymizationLevel,
        role: Role,
    ) -> ReplacementStrategy:
        """
        Determine the replacement strategy for a given data type, anonymization
        level, and subject role.  Sensitive roles escalate the effective level.
        """
        # Check for explicit rule override first
        for rule in self._rules:
            if rule.data_type == data_type and rule.level == level:
                return rule.strategy

        # Sensitive roles always escalate
        effective_level = level
        role_min_level = _ROLE_OVERRIDES.get(role, AnonymizationLevel.STANDARD)
        if role_min_level.value > effective_level.value:
            effective_level = role_min_level

        # Personnummer is always at least STRICT regardless of level
        if data_type == DataType.PERSONNUMMER and effective_level.value < AnonymizationLevel.STRICT.value:
            effective_level = AnonymizationLevel.STRICT

        return _LEVEL_STRATEGIES[effective_level]
