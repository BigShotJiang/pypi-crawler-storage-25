"""Text Similarity and Deduplication.

Fuzzy string matching (Levenshtein), n-gram similarity, cosine similarity
via TF-IDF, and text deduplication. Uses only the Python standard library;
optionally accelerated by ``rapidfuzz`` if installed.

Inspired by:
    - ValidateCV: StylometryAnalyzer (word frequency / vocabulary analysis)
    - email_extractor: KeywordMatcher (token-based matching)
    - DocumentCommentator: RequirementExtractor.merge_requirement_sets (dedup by desc)

Usage:
    from data_cleaner.text_similarity import TextSimilarity
    sim = TextSimilarity()
    score = sim.levenshtein_ratio("hello", "helo")
    score = sim.ngram_similarity("hello world", "hello there", n=2)
    score = sim.cosine_similarity("the quick brown fox", "a fast brown dog")
    unique = sim.deduplicate(["hello world", "hello  world", "goodbye"])
"""

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass
class SimilarityResult:
    """Result of a pairwise similarity comparison."""
    text_a: str
    text_b: str
    score: float  # 0.0 to 1.0
    method: str = ""


@dataclass
class DedupResult:
    """Result of a deduplication operation."""
    unique_texts: List[str] = field(default_factory=list)
    duplicates: List[Tuple[int, int, float]] = field(default_factory=list)
    original_count: int = 0
    unique_count: int = 0

    @property
    def duplicates_removed(self) -> int:
        return self.original_count - self.unique_count


def _try_rapidfuzz():
    """Lazy-load rapidfuzz for faster Levenshtein if available."""
    try:
        from rapidfuzz import fuzz as _fuzz  # type: ignore
        return _fuzz
    except ImportError:
        return None


class TextSimilarity:
    """Multi-method text similarity comparison."""

    def __init__(self, *, normalize: bool = True):
        """
        Args:
            normalize: Whether to lowercase and strip whitespace before comparing.
        """
        self._normalize = normalize

    # -- Levenshtein distance / ratio --

    def levenshtein_distance(self, a: str, b: str) -> int:
        """Compute the edit distance between two strings.

        Uses dynamic programming (Wagner-Fischer). O(m*n) time and space.
        """
        a, b = self._prep(a), self._prep(b)
        # Try rapidfuzz first for speed
        rf = _try_rapidfuzz()
        if rf:
            # rapidfuzz uses ratio (0-100), reconstruct distance
            ratio = rf.ratio(a, b) / 100.0
            max_len = max(len(a), len(b))
            return round(max_len * (1 - ratio))

        if len(a) < len(b):
            a, b = b, a
        if not b:
            return len(a)

        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            curr = [i] + [0] * len(b)
            for j, cb in enumerate(b, 1):
                cost = 0 if ca == cb else 1
                curr[j] = min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            prev = curr
        return prev[-1]

    def levenshtein_ratio(self, a: str, b: str) -> float:
        """Similarity ratio based on Levenshtein distance (0.0 to 1.0)."""
        a, b = self._prep(a), self._prep(b)
        # Try rapidfuzz first
        rf = _try_rapidfuzz()
        if rf:
            return rf.ratio(a, b) / 100.0

        max_len = max(len(a), len(b))
        if max_len == 0:
            return 1.0
        dist = self.levenshtein_distance(a, b)
        return 1.0 - dist / max_len

    # -- N-gram similarity --

    def ngram_similarity(self, a: str, b: str, *, n: int = 2) -> float:
        """Jaccard similarity of character n-grams.

        Args:
            a, b: Input strings.
            n: N-gram size (default bigrams).

        Returns:
            Similarity score between 0.0 and 1.0.
        """
        a, b = self._prep(a), self._prep(b)
        if not a and not b:
            return 1.0
        if not a or not b:
            return 0.0
        grams_a = self._char_ngrams(a, n)
        grams_b = self._char_ngrams(b, n)
        intersection = grams_a & grams_b
        union = grams_a | grams_b
        if not union:
            return 0.0
        return sum(intersection.values()) / sum(union.values())

    def word_ngram_similarity(self, a: str, b: str, *, n: int = 1) -> float:
        """Jaccard similarity of word n-grams.

        With n=1, this is equivalent to word overlap (bag-of-words Jaccard).
        """
        a, b = self._prep(a), self._prep(b)
        words_a = self._tokenize(a)
        words_b = self._tokenize(b)
        if not words_a and not words_b:
            return 1.0
        if not words_a or not words_b:
            return 0.0
        grams_a = self._word_ngrams(words_a, n)
        grams_b = self._word_ngrams(words_b, n)
        intersection = grams_a & grams_b
        union = grams_a | grams_b
        if not union:
            return 0.0
        return sum(intersection.values()) / sum(union.values())

    # -- Cosine similarity (TF-IDF-style) --

    def cosine_similarity(self, a: str, b: str) -> float:
        """Cosine similarity using term-frequency vectors.

        This is a simplified single-document TF comparison (no IDF corpus).
        For corpus-level TF-IDF, use :meth:`cosine_tfidf`.
        """
        a, b = self._prep(a), self._prep(b)
        vec_a = Counter(self._tokenize(a))
        vec_b = Counter(self._tokenize(b))
        return self._cosine(vec_a, vec_b)

    def cosine_tfidf(self, texts: List[str], query_index: int, target_index: int) -> float:
        """Cosine similarity with TF-IDF weighting across a corpus.

        Args:
            texts: List of documents forming the corpus.
            query_index: Index of the first document.
            target_index: Index of the second document.

        Returns:
            Cosine similarity score (0.0 to 1.0).
        """
        if not texts or query_index >= len(texts) or target_index >= len(texts):
            return 0.0

        tokenized = [Counter(self._tokenize(self._prep(t))) for t in texts]
        n_docs = len(texts)

        # Build IDF
        df: Dict[str, int] = {}
        for tc in tokenized:
            for word in tc:
                df[word] = df.get(word, 0) + 1
        idf = {w: math.log(n_docs / count) for w, count in df.items()}

        # Build TF-IDF vectors
        vec_a = {w: tf * idf.get(w, 0) for w, tf in tokenized[query_index].items()}
        vec_b = {w: tf * idf.get(w, 0) for w, tf in tokenized[target_index].items()}

        return self._cosine(vec_a, vec_b)

    # -- Deduplication --

    def deduplicate(
        self,
        texts: List[str],
        *,
        threshold: float = 0.85,
        method: str = "levenshtein",
    ) -> DedupResult:
        """Remove near-duplicate texts.

        Args:
            texts: Input texts.
            threshold: Similarity threshold above which texts are considered duplicates.
            method: Similarity method ('levenshtein', 'ngram', 'cosine').

        Returns:
            DedupResult with unique texts and duplicate pairs.
        """
        if not texts:
            return DedupResult()

        sim_func = {
            "levenshtein": self.levenshtein_ratio,
            "ngram": self.ngram_similarity,
            "cosine": self.cosine_similarity,
        }.get(method, self.levenshtein_ratio)

        removed: Set[int] = set()
        duplicates: List[Tuple[int, int, float]] = []

        for i in range(len(texts)):
            if i in removed:
                continue
            for j in range(i + 1, len(texts)):
                if j in removed:
                    continue
                score = sim_func(texts[i], texts[j])
                if score >= threshold:
                    removed.add(j)
                    duplicates.append((i, j, score))

        unique = [t for idx, t in enumerate(texts) if idx not in removed]

        return DedupResult(
            unique_texts=unique,
            duplicates=duplicates,
            original_count=len(texts),
            unique_count=len(unique),
        )

    # -- helpers --

    def _prep(self, text: str) -> str:
        if not text:
            return ""
        if self._normalize:
            return text.lower().strip()
        return text

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Simple word tokenizer (keeps Swedish characters)."""
        return re.findall(r"[a-z\u00e5\u00e4\u00f6]+", text.lower())

    @staticmethod
    def _char_ngrams(text: str, n: int) -> Counter:
        if len(text) < n:
            return Counter([text])
        return Counter(text[i: i + n] for i in range(len(text) - n + 1))

    @staticmethod
    def _word_ngrams(words: List[str], n: int) -> Counter:
        if len(words) < n:
            return Counter([" ".join(words)])
        return Counter(
            " ".join(words[i: i + n]) for i in range(len(words) - n + 1)
        )

    @staticmethod
    def _cosine(vec_a: Dict[str, float], vec_b: Dict[str, float]) -> float:
        """Cosine similarity between two frequency vectors."""
        if not vec_a or not vec_b:
            return 0.0
        common = set(vec_a) & set(vec_b)
        dot = sum(vec_a[w] * vec_b[w] for w in common)
        mag_a = math.sqrt(sum(v * v for v in vec_a.values()))
        mag_b = math.sqrt(sum(v * v for v in vec_b.values()))
        if mag_a == 0 or mag_b == 0:
            return 0.0
        return dot / (mag_a * mag_b)
