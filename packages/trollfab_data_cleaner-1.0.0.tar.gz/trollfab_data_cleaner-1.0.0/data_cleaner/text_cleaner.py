"""Text Cleaner.

Strip HTML tags, normalize Unicode and whitespace, handle Swedish characters,
detect and fix encoding issues. Uses only the Python standard library.

Inspired by:
    - DocumentCommentator: TextChunker._normalize_text (whitespace normalization)
    - email_extractor: DataSanitizer (pattern-based text cleaning)
    - ValidateCV: StylometryAnalyzer._tokenize_words (Swedish character handling)

Usage:
    from data_cleaner.text_cleaner import TextCleaner, CleanerConfig
    cleaner = TextCleaner()
    clean = cleaner.clean(html_string)
    fixed = cleaner.fix_encoding(garbled_text)
"""

import html
import re
import unicodedata
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class CleanerConfig:
    """Configuration for text cleaning operations.

    Attributes:
        strip_html: Remove HTML/XML tags.
        normalize_unicode: Apply NFC Unicode normalization.
        normalize_whitespace: Collapse runs of whitespace.
        fix_swedish_chars: Repair mojibake for Swedish characters.
        fix_encoding: Attempt automatic encoding repair.
        strip_urls: Remove HTTP(S) URLs.
        strip_emails: Remove email addresses.
        lowercase: Convert to lowercase.
        max_newlines: Maximum consecutive newlines to keep (0 = unlimited).
    """
    strip_html: bool = True
    normalize_unicode: bool = True
    normalize_whitespace: bool = True
    fix_swedish_chars: bool = True
    fix_encoding: bool = False
    strip_urls: bool = False
    strip_emails: bool = False
    lowercase: bool = False
    max_newlines: int = 2


@dataclass
class CleanResult:
    """Result of a cleaning operation."""
    text: str
    original_length: int = 0
    cleaned_length: int = 0
    operations_applied: List[str] = field(default_factory=list)

    @property
    def reduction_pct(self) -> float:
        """Percentage of characters removed."""
        if self.original_length == 0:
            return 0.0
        return (1.0 - self.cleaned_length / self.original_length) * 100.0


# ---- regex patterns compiled once ----

_RE_HTML_TAG = re.compile(r"<[^>]+>")
_RE_HTML_COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)
_RE_HTML_SCRIPT_STYLE = re.compile(
    r"<(script|style)[^>]*>.*?</\1>", re.DOTALL | re.IGNORECASE
)
_RE_MULTI_SPACE = re.compile(r"[ \t]+")
_RE_MULTI_NEWLINE = re.compile(r"\n{3,}")
_RE_URL = re.compile(r"https?://[^\s<>\"'{}\|\\^`\[\]]+", re.IGNORECASE)
_RE_EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
_RE_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Common mojibake mappings for Swedish characters (Latin-1 misread as UTF-8)
_SWEDISH_MOJIBAKE = {
    "\u00c3\u00a5": "\u00e5",   # a-ring
    "\u00c3\u00a4": "\u00e4",   # a-umlaut
    "\u00c3\u00b6": "\u00f6",   # o-umlaut
    "\u00c3\u0085": "\u00c5",   # A-ring
    "\u00c3\u0084": "\u00c4",   # A-umlaut
    "\u00c3\u0096": "\u00d6",   # O-umlaut
    "\u00c3\u00a9": "\u00e9",   # e-acute
    "\u00c3\u00bc": "\u00fc",   # u-umlaut
    "Ã¥": "\u00e5",
    "Ã¤": "\u00e4",
    "Ã¶": "\u00f6",
    "Ã…": "\u00c5",
    "Ã\x84": "\u00c4",
    "Ã\x96": "\u00d6",
    "Ã©": "\u00e9",
}


class TextCleaner:
    """Production-quality text cleaner.

    Applies a configurable pipeline of cleaning operations to produce
    normalized, encoding-safe plain text.
    """

    def __init__(self, config: Optional[CleanerConfig] = None):
        self._config = config or CleanerConfig()

    # -- public API --

    def clean(self, text: str, config: Optional[CleanerConfig] = None) -> str:
        """Clean text using the configured pipeline.

        Args:
            text: Raw input text.
            config: Override the instance config for this call.

        Returns:
            Cleaned text string.
        """
        return self.clean_detailed(text, config).text

    def clean_detailed(
        self, text: str, config: Optional[CleanerConfig] = None
    ) -> CleanResult:
        """Clean text and return a detailed report.

        Args:
            text: Raw input text.
            config: Override the instance config for this call.

        Returns:
            CleanResult with text, lengths, and applied operations.
        """
        cfg = config or self._config
        original_length = len(text) if text else 0

        if not text:
            return CleanResult(text="", original_length=0, cleaned_length=0)

        ops: List[str] = []

        if cfg.fix_encoding:
            text = self.fix_encoding(text)
            ops.append("fix_encoding")

        if cfg.fix_swedish_chars:
            text = self.fix_swedish_mojibake(text)
            ops.append("fix_swedish_chars")

        if cfg.strip_html:
            text = self.strip_html(text)
            ops.append("strip_html")

        if cfg.normalize_unicode:
            text = self.normalize_unicode(text)
            ops.append("normalize_unicode")

        if cfg.strip_urls:
            text = _RE_URL.sub("", text)
            ops.append("strip_urls")

        if cfg.strip_emails:
            text = _RE_EMAIL.sub("", text)
            ops.append("strip_emails")

        if cfg.normalize_whitespace:
            text = self.normalize_whitespace(text, max_newlines=cfg.max_newlines)
            ops.append("normalize_whitespace")

        if cfg.lowercase:
            text = text.lower()
            ops.append("lowercase")

        text = text.strip()

        return CleanResult(
            text=text,
            original_length=original_length,
            cleaned_length=len(text),
            operations_applied=ops,
        )

    # -- individual operations (usable standalone) --

    @staticmethod
    def strip_html(text: str) -> str:
        """Remove HTML/XML tags and decode entities.

        Removes ``<script>`` and ``<style>`` blocks first, then strips
        remaining tags and decodes HTML entities.
        """
        if not text:
            return text
        text = _RE_HTML_COMMENT.sub("", text)
        text = _RE_HTML_SCRIPT_STYLE.sub("", text)
        text = _RE_HTML_TAG.sub("", text)
        text = html.unescape(text)
        return text

    @staticmethod
    def normalize_unicode(text: str, form: str = "NFC") -> str:
        """Apply Unicode normalization (default NFC).

        Also strips control characters except common whitespace.
        """
        if not text:
            return text
        text = unicodedata.normalize(form, text)
        text = _RE_CONTROL_CHARS.sub("", text)
        return text

    @staticmethod
    def normalize_whitespace(text: str, max_newlines: int = 2) -> str:
        """Collapse whitespace runs while preserving paragraph breaks.

        Args:
            text: Input text.
            max_newlines: Maximum consecutive newlines to keep (0 = no limit).
        """
        if not text:
            return text
        # Collapse horizontal whitespace (spaces and tabs)
        text = _RE_MULTI_SPACE.sub(" ", text)
        # Limit consecutive newlines
        if max_newlines > 0:
            pattern = "\n" * (max_newlines + 1) + "+"
            replacement = "\n" * max_newlines
            text = re.sub(pattern, replacement, text)
        # Strip trailing spaces on each line
        text = "\n".join(line.rstrip() for line in text.split("\n"))
        return text

    @staticmethod
    def fix_swedish_mojibake(text: str) -> str:
        """Repair common mojibake for Swedish characters.

        Fixes double-encoded UTF-8 that appears when Latin-1 bytes
        are misinterpreted as UTF-8.
        """
        if not text:
            return text
        for bad, good in _SWEDISH_MOJIBAKE.items():
            text = text.replace(bad, good)
        return text

    @staticmethod
    def fix_encoding(text: str) -> str:
        """Attempt to fix encoding issues via round-trip decode.

        Tries Latin-1 -> UTF-8 decode, which corrects the most common
        mojibake pattern for Western European languages.
        """
        if not text:
            return text
        try:
            raw = text.encode("latin-1")
            return raw.decode("utf-8")
        except (UnicodeDecodeError, UnicodeEncodeError):
            return text

    @staticmethod
    def detect_encoding(raw_bytes: bytes) -> str:
        """Detect encoding of raw bytes.

        Tries UTF-8 first, then common Western European encodings.
        For more accurate detection install ``chardet`` (optional).

        Returns:
            Encoding name string.
        """
        # Try UTF-8 BOM
        if raw_bytes[:3] == b"\xef\xbb\xbf":
            return "utf-8-sig"
        # Try UTF-8
        try:
            raw_bytes.decode("utf-8")
            return "utf-8"
        except UnicodeDecodeError:
            pass
        # Try Latin-1 (always succeeds, but check for Swedish chars)
        try:
            decoded = raw_bytes.decode("latin-1")
            swedish_chars = set("\u00e5\u00e4\u00f6\u00c5\u00c4\u00d6")
            if any(c in decoded for c in swedish_chars):
                return "latin-1"
        except UnicodeDecodeError:
            pass
        # Try Windows-1252
        try:
            raw_bytes.decode("cp1252")
            return "cp1252"
        except UnicodeDecodeError:
            pass
        # Optional: use chardet if available
        try:
            import chardet  # type: ignore
            result = chardet.detect(raw_bytes)
            if result and result.get("encoding"):
                return result["encoding"]
        except ImportError:
            pass
        return "utf-8"  # fallback

    @staticmethod
    def decode_bytes(raw_bytes: bytes, encoding: Optional[str] = None) -> str:
        """Decode raw bytes to string with optional encoding hint.

        If *encoding* is None, auto-detection is used.
        """
        if encoding is None:
            encoding = TextCleaner.detect_encoding(raw_bytes)
        return raw_bytes.decode(encoding, errors="replace")
