"""JSON Repair for LLM Responses.

Fix truncated, malformed, or incomplete JSON commonly produced by LLMs
when hitting token limits. Multiple recovery strategies from simple
bracket closing to structural extraction.

Usage:
    from data_cleaner.json_repair import repair_json, extract_json

    # Fix truncated JSON
    broken = '{"items": [{"name": "Alice"}, {"name": "Bo'
    fixed = repair_json(broken)  # {"items": [{"name": "Alice"}]}

    # Extract JSON from markdown/text
    text = 'Here is the result:\\n```json\\n{"score": 9}\\n```\\nDone.'
    data = extract_json(text)  # {"score": 9}

    # Parse with automatic repair
    from data_cleaner.json_repair import safe_parse
    result = safe_parse(possibly_broken_json_string)
"""

from __future__ import annotations

import json
import re
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class JSONRepairError(Exception):
    """Raised when all repair strategies have been exhausted."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def repair_json(text: str) -> Any:
    """Attempt to return a valid Python object from *text* using multiple
    repair strategies.

    Strategies are tried in order until one succeeds:

    1. Direct ``json.loads`` — already valid.
    2. Strip markdown fences then parse.
    3. Close unclosed brackets/strings then parse.
    4. Extract the largest complete JSON object found anywhere in the text.
    5. Recover a truncated array by dropping the incomplete tail element.

    Args:
        text: Potentially malformed JSON string.

    Returns:
        Parsed Python object (``dict`` or ``list``).

    Raises:
        JSONRepairError: If every strategy fails.
        ValueError: If *text* is empty or contains only whitespace.
    """
    if not text or not text.strip():
        raise ValueError("Input text is empty or contains only whitespace.")

    # Strategy 1 — already valid
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Strategy 2 — strip markdown fences
    stripped = _strip_markdown_fences(text)
    if stripped != text:
        try:
            return json.loads(stripped)
        except json.JSONDecodeError:
            pass
    else:
        stripped = text

    # Strategy 3 — close open brackets
    try:
        closed = _close_brackets(stripped)
        return json.loads(closed)
    except (json.JSONDecodeError, ValueError):
        pass

    # Strategy 4 — extract largest complete object
    try:
        return _extract_complete_objects(stripped)
    except JSONRepairError:
        pass

    # Strategy 5 — recover truncated array
    try:
        return _recover_truncated_array(stripped)
    except (JSONRepairError, json.JSONDecodeError):
        pass

    raise JSONRepairError(
        "All JSON repair strategies failed. Input may not contain valid JSON fragments."
    )


def extract_json(text: str) -> Optional[Any]:
    """Extract a JSON value from mixed text (markdown, prose, etc.).

    Handles:
    - Markdown code fences: `` ```json ... ``` `` and `` ``` ... ``` ``
    - Inline patterns like ``json\\n{...}``
    - First ``{`` or ``[`` character found in the text

    Args:
        text: Mixed text that may contain embedded JSON.

    Returns:
        Parsed Python object, or ``None`` if no JSON can be found.
    """
    if not text or not text.strip():
        return None

    # Try fenced code block first (most explicit signal)
    fence_patterns = [
        r"```(?:json)?\s*([\s\S]*?)```",
        r"~~~(?:json)?\s*([\s\S]*?)~~~",
    ]
    for pattern in fence_patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            candidate = match.group(1).strip()
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                try:
                    return repair_json(candidate)
                except (JSONRepairError, ValueError):
                    continue

    # Try "json\n{...}" pattern (LLMs sometimes emit this)
    json_prefix = re.search(r"(?:^|\n)\s*json\s*\n\s*(\{[\s\S]*?\}|\[[\s\S]*?\])", text)
    if json_prefix:
        try:
            return json.loads(json_prefix.group(1))
        except json.JSONDecodeError:
            pass

    # Find the first structural character and try from there
    for start_char, end_char in (("{", "}"), ("[", "]")):
        idx = text.find(start_char)
        if idx == -1:
            continue
        # Walk backwards from the last matching close bracket
        last_close = text.rfind(end_char)
        if last_close <= idx:
            candidate = text[idx:]
        else:
            candidate = text[idx: last_close + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            try:
                return repair_json(candidate)
            except (JSONRepairError, ValueError):
                pass

    return None


def safe_parse(text: str, default: Any = None) -> Any:
    """Parse *text* as JSON, repairing if necessary.  Never raises.

    Args:
        text:    Potentially malformed JSON string.
        default: Value returned when all repair strategies fail.

    Returns:
        Parsed Python object, or *default* on any failure.
    """
    try:
        return repair_json(text)
    except (JSONRepairError, ValueError, Exception):
        return default


def validate_structure(
    data: Any, required_keys: Optional[list[str]] = None
) -> bool:
    """Check whether *data* has the expected structure.

    Args:
        data:          Parsed JSON value to validate.
        required_keys: When provided, each key must be present in the
                       top-level dict.

    Returns:
        ``True`` if structure is valid; ``False`` otherwise.
    """
    if data is None:
        return False
    if required_keys is not None:
        if not isinstance(data, dict):
            return False
        return all(k in data for k in required_keys)
    return True


# ---------------------------------------------------------------------------
# Internal repair strategies
# ---------------------------------------------------------------------------


def _strip_markdown_fences(text: str) -> str:
    """Remove opening and closing code fences from *text*.

    Handles:
    - `` ```json `` … `` ``` ``
    - `` ``` `` … `` ``` ``
    - ``~~~`` … ``~~~``

    Args:
        text: Text potentially wrapped in a code fence.

    Returns:
        Inner content with fences removed and surrounding whitespace stripped.
    """
    # Match both backtick and tilde fences with optional language tag
    pattern = r"^(?:```|~~~)[a-zA-Z]*\s*([\s\S]*?)(?:```|~~~)\s*$"
    match = re.match(pattern, text.strip(), re.DOTALL)
    if match:
        return match.group(1).strip()

    # Partial fence at the start only
    start_fence = re.match(r"^(?:```|~~~)[a-zA-Z]*\s*", text.strip())
    if start_fence:
        return text.strip()[start_fence.end():].strip()

    return text


def _close_brackets(text: str) -> str:
    """Close any unclosed brackets, braces, and string literals in *text*.

    Uses a state-machine approach to track open delimiters while correctly
    handling escape sequences inside strings.

    Args:
        text: JSON text that may be truncated mid-structure.

    Returns:
        Repaired text with all unclosed delimiters properly closed.
    """
    text = _remove_trailing_comma(text.rstrip())

    stack: list[str] = []   # open delimiters that need closing
    in_string = False
    escape_next = False

    for char in text:
        if escape_next:
            escape_next = False
            continue
        if char == "\\" and in_string:
            escape_next = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char in ("{", "["):
            stack.append(char)
        elif char in ("}", "]"):
            if stack:
                stack.pop()

    # Close the unclosed string first (if inside one)
    suffix_parts: list[str] = []
    if in_string:
        suffix_parts.append('"')

    # Close containers in reverse
    close_map = {"{": "}", "[": "]"}
    for opener in reversed(stack):
        suffix_parts.append(close_map[opener])

    return text + "".join(suffix_parts)


def _extract_complete_objects(text: str) -> Any:
    """Find the largest valid JSON object or array anywhere in *text*.

    Scans all ``{`` and ``[`` positions, then tries progressively expanding
    substrings until a valid parse is found.  Returns the largest result.

    Args:
        text: Text to scan for JSON fragments.

    Returns:
        The largest successfully parsed Python object.

    Raises:
        JSONRepairError: If no valid JSON fragment is found.
    """
    best: Optional[Any] = None
    best_len: int = 0

    for start_char in ("{", "["):
        pos = 0
        while True:
            idx = text.find(start_char, pos)
            if idx == -1:
                break
            # Try increasingly larger substrings from idx
            for end_char in ("}", "]"):
                end_pos = len(text)
                while end_pos > idx:
                    end_pos = text.rfind(end_char, idx, end_pos)
                    if end_pos == -1:
                        break
                    candidate = text[idx: end_pos + 1]
                    try:
                        parsed = json.loads(candidate)
                        if len(candidate) > best_len:
                            best = parsed
                            best_len = len(candidate)
                        break  # found valid parse for this start/end pair
                    except json.JSONDecodeError:
                        end_pos -= 1  # try shorter
            pos = idx + 1

    if best is None:
        raise JSONRepairError("No complete JSON object or array found in text.")
    return best


def _recover_truncated_array(text: str) -> Any:
    """Recover a JSON structure where an array element was truncated mid-write.

    Finds the last complete array element by scanning for the last comma or
    opening bracket at the top level, then closes the array and any parent
    containers.

    Example::

        '{"items": [{"a": 1}, {"a": 2}, {"a":'
        → {"items": [{"a": 1}, {"a": 2}]}

    Args:
        text: Truncated JSON text.

    Returns:
        Parsed Python object after truncation repair.

    Raises:
        JSONRepairError: If no recoverable array structure is found.
        json.JSONDecodeError: If the repaired text still cannot be parsed.
    """
    # Walk backwards to find a position after the last complete element
    # by looking for the last top-level comma inside an array context.
    depth = 0
    in_string = False
    escape_next = False
    last_top_comma: Optional[int] = None
    array_open: Optional[int] = None

    for i, char in enumerate(text):
        if escape_next:
            escape_next = False
            continue
        if char == "\\" and in_string:
            escape_next = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char in ("{", "["):
            if char == "[" and depth == 0:
                array_open = i
            depth += 1
        elif char in ("}", "]"):
            depth -= 1
        elif char == "," and depth == 1 and array_open is not None:
            last_top_comma = i

    if last_top_comma is None or array_open is None:
        raise JSONRepairError("Could not locate a recoverable array boundary.")

    # Truncate at the last top-level comma (excluding incomplete tail element)
    truncated = text[:last_top_comma].rstrip()
    # Now close all open brackets
    closed = _close_brackets(truncated)
    return json.loads(closed)


def _remove_trailing_comma(text: str) -> str:
    """Remove a trailing comma that appears before a closing bracket or brace.

    LLMs frequently emit trailing commas in array/object literals, which are
    invalid JSON.  This function removes the last such comma.

    Args:
        text: JSON text that may have a trailing comma.

    Returns:
        Text with the offending trailing comma removed.
    """
    # Match comma followed by optional whitespace then a closing delimiter
    return re.sub(r",\s*(?=[}\]])", "", text)
