"""data-cleaner — Production-quality data cleaning, validation, and normalization.

Pure Python (stdlib-only core), with optional acceleration via rapidfuzz and
beautifulsoup4. Includes Swedish-specific utilities in data_cleaner.swedish.

Quick start::

    from data_cleaner import TextCleaner, TextSimilarity, JSONRepair
    from data_cleaner.validation import Schema, Email, Required
    from data_cleaner.swedish import validate_personnummer
"""

from .text_cleaner import TextCleaner, CleanerConfig, CleanResult
from .content_cleaner import (
    ContentCleaner,
    clean_text as clean_content,
    strip_html_tags,
    clean_document_content,
)
from .html_converter import HTMLConverter, HTMLDocument, SanitizeOptions
from .html_to_markdown import MarkdownConverter, ConversionOptions, ConversionResult
from .text_similarity import TextSimilarity, SimilarityResult, DedupResult
from .duplicate_detector import DuplicateDetector
from .validation import (
    Schema,
    BaseValidator,
    ValidationError,
    ValidationResult as SchemaValidationResult,
    Required,
    OptionalField,
    Email,
    URL,
    Regex,
    MinLength,
    MaxLength,
    Length,
    Range,
    IsString,
    IsInt,
    IsFloat,
    IsBool,
    IsList,
    IsDict,
)
from .validators import (
    validate_email,
    validate_url,
    validate_json,
    validate_date,
    validate_credit_card,
)
from .anonymizer import Anonymizer, AnonymizationResult as AnonymizationResultBase
from .json_repair import repair_json, extract_json, safe_parse
from . import swedish

__version__ = "1.0.0"

__all__ = [
    # Text cleaning
    "TextCleaner",
    "CleanerConfig",
    "CleanResult",
    "ContentCleaner",
    "clean_content",
    "strip_html_tags",
    "clean_document_content",
    # HTML
    "HTMLConverter",
    "HTMLDocument",
    "SanitizeOptions",
    "MarkdownConverter",
    "ConversionOptions",
    "ConversionResult",
    # Similarity & deduplication
    "TextSimilarity",
    "SimilarityResult",
    "DedupResult",
    "DuplicateDetector",
    # Validation framework
    "Schema",
    "BaseValidator",
    "ValidationError",
    "SchemaValidationResult",
    "Required",
    "OptionalField",
    "Email",
    "URL",
    "Regex",
    "MinLength",
    "MaxLength",
    "Length",
    "Range",
    "IsString",
    "IsInt",
    "IsFloat",
    "IsBool",
    "IsList",
    "IsDict",
    # Simple validators
    "validate_email",
    "validate_url",
    "validate_json",
    "validate_date",
    "validate_credit_card",
    # Anonymization
    "Anonymizer",
    "AnonymizationResultBase",
    # JSON repair
    "repair_json",
    "extract_json",
    "safe_parse",
    # Swedish subpackage
    "swedish",
]
