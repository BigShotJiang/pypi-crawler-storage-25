from __future__ import annotations

from pydantic import BaseModel, Field

ASK_YOURSELF_COUNT = 5


class FileChange(BaseModel):
    path: str
    status: str  # added | modified | deleted | renamed
    additions: int = 0
    deletions: int = 0
    is_risky: bool = False
    risk_reasons: list[str] = Field(default_factory=list)
    staged: bool = False
    has_unstaged: bool = False


class BriefRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    ticket_url: str | None = None
    base_branch: str | None = None
    head_branch: str | None = None


class ReviewBrief(BaseModel):
    title: str
    summary: str
    why: str
    risk_areas: list[str]
    all_changed_files: list[FileChange] = Field(
        default_factory=list,
        description="Every file in the current compare scope (with stage flags)",
    )
    files_to_scrutinize: list[FileChange]
    ask_yourself: list[str] = Field(
        default_factory=list,
        description="Five self-check questions for the committer before pushing",
    )
    suggested_tests: list[str] = Field(default_factory=list)  # legacy — unused in UI
    questions_for_author: list[str] = Field(default_factory=list)  # legacy alias
    rollback_notes: str
    stats: dict[str, int | str]
    generated_with_llm: bool = False
