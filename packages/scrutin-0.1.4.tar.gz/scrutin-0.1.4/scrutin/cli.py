from __future__ import annotations

import argparse
import sys
import webbrowser
from pathlib import Path

from dotenv import load_dotenv

from scrutin.brief_builder import brief_to_markdown, build_brief
from scrutin.diff_parser import parse_unified_diff
from scrutin.git_workspace import (
    DEFAULT_MODE,
    DIFF_MODES,
    build_workspace_brief,
    detect_base_branch,
    git_toplevel,
)
from scrutin.models import BriefRequest


def _schedule_browser_when_ready(url: str, host: str, port: int, timeout: float = 15.0) -> None:
    """Open the browser only after /health responds (serve used to open too early)."""
    import threading
    import time
    import urllib.error
    import urllib.request

    def _worker() -> None:
        health = f"http://{host}:{port}/health"
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                with urllib.request.urlopen(health, timeout=0.5) as resp:
                    if resp.status == 200:
                        webbrowser.open(url)
                        return
            except (urllib.error.URLError, TimeoutError, OSError):
                time.sleep(0.12)
        print(f"Could not confirm server ready — open manually: {url}")

    threading.Thread(target=_worker, daemon=True).start()


def _run_brief(args: argparse.Namespace) -> int:
    if getattr(args, "open", False):
        return _run_brief_open_browser(args)

    meta = BriefRequest(
        title=args.title,
        description=args.description,
        ticket_url=args.ticket,
    )

    if args.diff:
        text = args.diff.read_text(encoding="utf-8", errors="replace")
        repo = args.repo.resolve() if args.repo else None
        files, ignored = parse_unified_diff(text, repo=repo)
        result = build_brief(files, meta=meta, commits=[])
        result.stats["ignored_paths"] = ignored
        result.stats["diff_mode"] = "file"
    elif args.repo:
        repo = args.repo.resolve()
        if args.mode == "branch" and args.auto_base:
            args.base = detect_base_branch(repo)
        elif args.mode == "branch" and not args.base:
            args.base = detect_base_branch(repo)
        result, _, _ = build_workspace_brief(
            repo,
            args.base or "main",
            args.head,
            mode=args.mode,
            meta=meta,
            use_gh=not args.no_gh,
        )
    else:
        return 2

    if args.json:
        print(result.model_dump_json(indent=2))
    else:
        print(brief_to_markdown(result))
    return 0


def _run_brief_open_browser(args: argparse.Namespace) -> int:
    import os
    import threading
    import time

    import uvicorn

    repo = args.repo
    if not repo:
        try:
            repo = git_toplevel()
        except RuntimeError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1

    repo = git_toplevel(repo.resolve())
    os.environ["SCRUTIN_REPO"] = str(repo)
    host = "127.0.0.1"
    port = 8765
    from urllib.parse import quote

    url = f"http://{host}:{port}/?repo={quote(str(repo))}"

    config = uvicorn.Config("scrutin.app:app", host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)

    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    _schedule_browser_when_ready(url, host, port)
    print(f"Scrutin UI → {url}")
    print("Press Ctrl+C to stop the server.")
    try:
        thread.join()
    except KeyboardInterrupt:
        server.should_exit = True
    return 0


def _run_serve(args: argparse.Namespace) -> int:
    import os

    import uvicorn

    host = args.host
    port = args.port
    repo_path = ""
    if args.repo:
        repo_path = str(git_toplevel(args.repo.resolve()))
        os.environ["SCRUTIN_REPO"] = repo_path

    url = f"http://{host}:{port}/"
    if repo_path:
        from urllib.parse import quote

        url = f"{url}?repo={quote(repo_path)}"

    print(f"Scrutin UI → {url}")
    if repo_path:
        print(f"Repository: {repo_path}")
    else:
        print("Tip: start from your project dir, or: scrutin serve --repo /path/to/project")
    print("Brief appears in the browser — not in this terminal.")
    print("Press Ctrl+C to stop.")

    if args.open_browser:
        _schedule_browser_when_ready(url, host, port)

    # reload=True spawns a parent process; browser must wait on the worker that serves traffic
    uvicorn.run(
        "scrutin.app:app",
        host=host,
        port=port,
        reload=args.reload,
        log_level="info" if not args.quiet else "warning",
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    load_dotenv()
    parser = argparse.ArgumentParser(
        prog="scrutin",
        description="Local-first pre-commit context briefs for developers",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    brief_p = sub.add_parser("brief", help="Generate a review brief")
    brief_p.add_argument("--diff", type=Path, help="Path to unified diff file")
    brief_p.add_argument("--repo", type=Path, help="Local git repository (default: detect from cwd)")
    brief_p.add_argument(
        "--mode",
        choices=DIFF_MODES,
        default=DEFAULT_MODE,
        help="working=pre-commit vs HEAD (default); staged; unstaged; branch",
    )
    brief_p.add_argument("--base", help="Base branch when --mode branch")
    brief_p.add_argument("--head", default="HEAD", help="Head when --mode branch")
    brief_p.add_argument(
        "--auto-base",
        action="store_true",
        help="Detect base branch for branch mode",
    )
    brief_p.add_argument("--no-gh", action="store_true", help="Skip gh pr view in branch mode")
    brief_p.add_argument("--title", help="Override title")
    brief_p.add_argument("--description", help="PR / ticket description")
    brief_p.add_argument("--ticket", help="Ticket URL")
    brief_p.add_argument("--json", action="store_true", help="Output JSON instead of Markdown")
    brief_p.add_argument(
        "--open",
        action="store_true",
        help="Open browser UI (starts server briefly) instead of printing to terminal",
    )
    brief_p.set_defaults(func=_run_brief)

    serve_p = sub.add_parser("serve", help="Local web UI in your browser")
    serve_p.add_argument(
        "--repo",
        type=Path,
        help="Git repository to analyze (default: cwd when serve starts)",
    )
    serve_p.add_argument("--host", default="127.0.0.1")
    serve_p.add_argument("--port", type=int, default=8787)
    serve_p.add_argument("--open", dest="open_browser", action="store_true")
    serve_p.add_argument("--no-open", dest="open_browser", action="store_false")
    serve_p.set_defaults(open_browser=True)
    serve_p.add_argument("--reload", action="store_true", help="Auto-reload on code changes")
    serve_p.add_argument("--quiet", action="store_true")
    serve_p.set_defaults(func=_run_serve)

    args = parser.parse_args(argv)

    if args.cmd == "brief":
        if not args.diff and not args.repo:
            try:
                args.repo = git_toplevel()
            except RuntimeError as e:
                brief_p.error(str(e))
        if args.repo and args.mode == "branch":
            if args.auto_base or not args.base:
                args.base = detect_base_branch(args.repo)
        return _run_brief(args)

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
