from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from scrutin import __version__
from scrutin.brief_builder import brief_to_markdown, build_brief
from scrutin.diff_parser import git_diff, git_log_oneline, parse_unified_diff
from scrutin.models import BriefRequest, ReviewBrief
from scrutin.routes_settings import router as settings_router
from scrutin.routes_git import router as git_router
from scrutin.routes_workspace import router as workspace_router
from scrutin.llm_settings import get_public_settings

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(
    title="Scrutin",
    description="Local-first pre-commit context briefs for developers",
    version=__version__,
)
app.include_router(workspace_router)
app.include_router(git_router)
app.include_router(settings_router)

if STATIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def local_ui() -> FileResponse:
    """Local browser pane (Phase A)."""
    index = STATIC_DIR / "index.html"
    if not index.is_file():
        raise HTTPException(404, "UI not found — static assets missing")
    return FileResponse(index)


class DiffBody(BaseModel):
    diff: str
    meta: BriefRequest | None = None


class GitBody(BaseModel):
    repo_path: str
    base: str = "main"
    head: str = "HEAD"
    meta: BriefRequest | None = None


@app.get("/health")
def health() -> dict[str, str | bool]:
    try:
        llm = get_public_settings()
        brief_mode = llm.brief_mode
        llm_provider = llm.provider
    except Exception:
        brief_mode = "sharpen"
        llm_provider = "none"
    return {
        "status": "ok",
        "service": "scrutin",
        "version": __version__,
        "settings_api": True,
        "local_ui": STATIC_DIR.is_dir(),
        "brief_mode": brief_mode,
        "llm_provider": llm_provider,
    }


@app.post("/v1/brief", response_model=ReviewBrief)
def brief_from_diff(body: DiffBody) -> ReviewBrief:
    if not body.diff.strip():
        raise HTTPException(400, "diff is empty")
    files, _ignored = parse_unified_diff(body.diff)
    return build_brief(files, meta=body.meta)


@app.post("/v1/brief/markdown", response_class=PlainTextResponse)
def brief_markdown_from_diff(body: DiffBody) -> str:
    brief = brief_from_diff(body)
    return brief_to_markdown(brief)


@app.post("/v1/brief/git", response_model=ReviewBrief)
def brief_from_git(body: GitBody) -> ReviewBrief:
    repo = Path(body.repo_path)
    if not repo.is_dir():
        raise HTTPException(400, f"repo_path not found: {body.repo_path}")
    try:
        diff = git_diff(repo, body.base, body.head)
        commits = git_log_oneline(repo, body.base, body.head)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e
    files, _ignored = parse_unified_diff(diff, repo=repo)
    meta = body.meta or BriefRequest()
    if not meta.title:
        meta.title = f"Changes {body.base}...{body.head}"
    return build_brief(files, meta=meta, commits=commits)
