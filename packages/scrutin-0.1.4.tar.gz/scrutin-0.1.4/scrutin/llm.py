from __future__ import annotations

import json

from scrutin.llm_providers import PROVIDERS, chat_json
from scrutin.llm_settings import active_model, resolve_active_provider
from typing import Literal

from scrutin.models import ASK_YOURSELF_COUNT, BriefRequest, FileChange, ReviewBrief

BriefAudience = Literal["precommit", "pr"]


def maybe_enhance_brief(
    brief: ReviewBrief,
    *,
    files: list[FileChange],
    commits: list[str],
    meta: BriefRequest,
    mode: str = "working",
    audience: BriefAudience = "precommit",
) -> ReviewBrief:
    provider_id = resolve_active_provider()
    if not provider_id:
        brief.stats["brief_mode"] = "sharpen"
        brief.stats["llm_provider"] = ""
        return brief

    spec = PROVIDERS[provider_id]
    model = active_model(provider_id)
    risky_paths = [f.path for f in files if f.is_risky][:20]
    payload = {
        "audience": audience,
        "compare_mode": mode,
        "title": brief.title,
        "stats": brief.stats,
        "risk_areas": brief.risk_areas,
        "risky_paths": risky_paths,
        "commits": commits[:15],
        "description": meta.description,
        "ticket": meta.ticket_url,
        "base_branch": meta.base_branch,
        "head_branch": meta.head_branch,
    }
    label = "Pull request context" if audience == "pr" else "Pre-commit change context"
    user = f"{label}:\n{json.dumps(payload, indent=2)}"

    try:
        data = chat_json(provider_id, model, user, audience=audience)
    except Exception:
        brief.stats["brief_mode"] = "sharpen"
        brief.stats["llm_provider"] = provider_id
        brief.stats["llm_error"] = "1"
        return brief

    brief.summary = data.get("summary") or brief.summary
    brief.why = data.get("why") or brief.why
    raw_checks = data.get("ask_yourself") or data.get("questions_for_author") or []
    if raw_checks:
        checks = [str(q).strip() for q in raw_checks if str(q).strip()][:ASK_YOURSELF_COUNT]
        if len(checks) < ASK_YOURSELF_COUNT and brief.ask_yourself:
            seen = set(checks)
            for q in brief.ask_yourself:
                if q not in seen and len(checks) < ASK_YOURSELF_COUNT:
                    checks.append(q)
                    seen.add(q)
        brief.ask_yourself = checks[:ASK_YOURSELF_COUNT]
        brief.questions_for_author = list(brief.ask_yourself)
        brief.suggested_tests = []
    brief.generated_with_llm = True
    brief.stats["brief_mode"] = "llm"
    brief.stats["llm_provider"] = provider_id
    brief.stats["llm_model"] = model
    return brief
