from __future__ import annotations

import json
import subprocess
from pathlib import Path

from scrutin.brief_builder import brief_to_markdown, build_brief
from scrutin.diff_parser import (
    git_diff_for_mode,
    git_log_oneline,
    git_status_short,
    parse_unified_diff,
    repo_has_commits,
)
from scrutin.git_actions import file_stage_flags, list_changed_paths
from scrutin.models import BriefRequest, FileChange, ReviewBrief
from scrutin.path_ignore import load_ignore_patterns, normalize_repo_path, should_ignore_path

BASE_CANDIDATES = ("main", "master", "develop", "development")
DIFF_MODES = ("working", "staged", "unstaged", "branch")
DEFAULT_MODE = "working"


def git_toplevel(start: Path | None = None) -> Path:
    start = (start or Path.cwd()).resolve()
    result = subprocess.run(
        ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        err = (result.stderr or "").strip()
        hint = err or "Not inside a git repository."
        raise RuntimeError(
            f"{hint} Run from your project root, or pass: scrutin brief --repo /path/to/repo"
        )
    return Path(result.stdout.strip())


def branch_exists(repo: Path, ref: str) -> bool:
    result = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--verify", ref],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.returncode == 0


def detect_base_branch(repo: Path) -> str:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "symbolic-ref", "refs/remotes/origin/HEAD"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        ref = result.stdout.strip()
        if ref.startswith("refs/remotes/origin/"):
            candidate = ref.split("/", 3)[-1]
            if branch_exists(repo, candidate):
                return candidate

    for name in BASE_CANDIDATES:
        if branch_exists(repo, f"origin/{name}"):
            return name
        if branch_exists(repo, name):
            return name

    return "main"


def list_local_branches(repo: Path, limit: int = 30) -> list[str]:
    result = subprocess.run(
        [
            "git",
            "-C",
            str(repo),
            "branch",
            "--format=%(refname:short)",
            "--sort=-committerdate",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return []
    lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
    return lines[:limit]


def try_gh_pr_meta(repo: Path) -> BriefRequest | None:
    """If GitHub CLI is available, enrich from the PR for the current branch."""
    try:
        result = subprocess.run(
            [
                "gh",
                "pr",
                "view",
                "--json",
                "title,body,url,baseRefName,headRefName",
            ],
            cwd=str(repo.resolve()),
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        return None
    return BriefRequest(
        title=data.get("title"),
        description=data.get("body"),
        ticket_url=data.get("url"),
        base_branch=data.get("baseRefName"),
        head_branch=data.get("headRefName"),
    )


def _title_for_mode(mode: str, base: str, head: str, *, first_commit: bool = False) -> str:
    if mode == "working":
        if first_commit:
            return "Local changes (no commits yet — staged + unstaged)"
        return "Uncommitted changes (vs HEAD)"
    if mode == "staged":
        return "Staged changes (index vs HEAD)"
    if mode == "unstaged":
        return "Unstaged changes (working tree vs index)"
    return f"Changes {base}…{head}"


def workspace_detect(start: Path | None = None) -> dict:
    repo = git_toplevel(start)
    has_head = repo_has_commits(repo)
    status = git_status_short(repo)
    mode = DEFAULT_MODE
    base = "main"
    head = "HEAD"
    branches: list[str] = []

    gh = None
    if has_head:
        base = detect_base_branch(repo)
        branches = list_local_branches(repo)
        gh = try_gh_pr_meta(repo)
        # Keep default mode=working so UI matches `scrutin brief` (pre-commit).
        # User can switch to "Branch vs base" in the dropdown when needed.
        if gh and gh.base_branch:
            base = gh.base_branch
        if gh and gh.head_branch:
            head = gh.head_branch

    return {
        "repo": str(repo),
        "has_commits": has_head,
        "mode": mode,
        "modes": list(DIFF_MODES),
        "base": base,
        "head": head,
        "base_candidates": list(dict.fromkeys([base, *BASE_CANDIDATES])),
        "branches": branches,
        "uncommitted": status,
        "gh_available": gh is not None,
        "gh_pr": gh.model_dump() if gh else None,
    }


def merge_status_into_changes(repo: Path, files: list[FileChange]) -> tuple[list[FileChange], int]:
    """Union diff-parsed files with every path from git status (incl. ignored / untracked)."""
    ignore_patterns = load_ignore_patterns(repo)
    by_path: dict[str, FileChange] = {f.path: f for f in files}
    order: list[str] = [f.path for f in files]
    extra_ignored = 0
    for entry in list_changed_paths(repo):
        path = normalize_repo_path(str(entry["path"]))
        if not path:
            continue
        staged = bool(entry["staged"])
        has_unstaged = bool(entry["has_unstaged"])
        if path in by_path:
            by_path[path] = by_path[path].model_copy(
                update={"staged": staged, "has_unstaged": has_unstaged}
            )
            continue
        if should_ignore_path(path, ignore_patterns):
            extra_ignored += 1
        status = "added" if not staged and has_unstaged and not repo_has_commits(repo) else "modified"
        if path not in by_path:
            order.append(path)
        by_path[path] = FileChange(
            path=path,
            status=status,
            additions=0,
            deletions=0,
            is_risky=False,
            risk_reasons=[],
            staged=staged,
            has_unstaged=has_unstaged,
        )
    return [by_path[p] for p in order if p in by_path], extra_ignored


def build_workspace_brief(
    repo: Path,
    base: str,
    head: str,
    *,
    mode: str = DEFAULT_MODE,
    meta: BriefRequest | None = None,
    use_gh: bool = True,
) -> tuple[ReviewBrief, str, dict]:
    repo = repo.resolve()
    if mode not in DIFF_MODES:
        raise RuntimeError(f"Invalid mode {mode!r}. Use: {', '.join(DIFF_MODES)}")

    meta = meta or BriefRequest()
    if mode == "branch" and use_gh:
        gh_meta = try_gh_pr_meta(repo)
        if gh_meta:
            if not meta.title and gh_meta.title:
                meta.title = gh_meta.title
            if not meta.description and gh_meta.description:
                meta.description = gh_meta.description
            if not meta.ticket_url and gh_meta.ticket_url:
                meta.ticket_url = gh_meta.ticket_url

    diff = git_diff_for_mode(repo, mode, base, head)
    ignored_count = 0
    empty_note = ""
    if not diff.strip():
        files = []
        empty_note = (
            "No diff in this compare mode — save edits, stage files, switch mode "
            "(e.g. **staged**), or refresh after a commit."
        )
    else:
        files, ignored_count = parse_unified_diff(diff, repo=repo)
        enriched: list = []
        for f in files:
            staged, has_unstaged = file_stage_flags(repo, f.path)
            enriched.append(f.model_copy(update={"staged": staged, "has_unstaged": has_unstaged}))
        files = enriched
        if not files and ignored_count:
            empty_note = (
                f"**{ignored_count}** changed path(s) are hidden by Scrutin ignores "
                "(e.g. `.vscode/`, `.venv/`). You can still **stage** them from the sidebar; "
                "add exceptions in `.scrutinignore` to include them in the review brief."
            )

    status_extra_ignored = 0
    files, status_extra_ignored = merge_status_into_changes(repo, files)
    ignored_count += status_extra_ignored
    if not files and not empty_note:
        status = git_status_short(repo)
        if status.get("has_changes"):
            empty_note = (
                "Changes are present in git status but not in this compare mode. "
                "Try **staged** or **unstaged** mode, or refresh after saving files."
            )
    elif empty_note and files:
        empty_note = ""

    commits: list[str] = []
    if mode == "branch":
        commits = git_log_oneline(repo, base, head)
    else:
        result = subprocess.run(
            ["git", "-C", str(repo), "log", "-1", "--oneline"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0 and result.stdout.strip():
            commits = [result.stdout.strip()]

    if not meta.title:
        meta.title = _title_for_mode(mode, base, head, first_commit=not repo_has_commits(repo))
    if mode in ("working", "staged", "unstaged"):
        meta.base_branch = "HEAD"
        meta.head_branch = "working tree" if mode == "working" else mode
    else:
        if not meta.base_branch:
            meta.base_branch = base
        if not meta.head_branch:
            meta.head_branch = head

    brief = build_brief(files, meta=meta, commits=commits, mode=mode, audience="precommit")
    if empty_note:
        brief = brief.model_copy(update={"summary": empty_note})
    brief.stats["ignored_paths"] = ignored_count
    brief.stats["diff_mode"] = mode
    brief.stats["empty_scope"] = bool(empty_note)

    extra = {
        "mode": mode,
        "ignored_paths": ignored_count,
        "uncommitted": git_status_short(repo),
    }
    return brief, brief_to_markdown(brief), extra
