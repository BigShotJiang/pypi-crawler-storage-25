"""Scrutin — local-first pre-commit context briefs for developers."""

__version__ = "0.1.4"
