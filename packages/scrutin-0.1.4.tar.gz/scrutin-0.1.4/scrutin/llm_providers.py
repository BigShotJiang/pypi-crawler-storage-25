from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

import httpx

SYSTEM_PROMPT_PRECOMMIT = (
    "You are a staff engineer helping a developer review their own diff BEFORE they commit. "
    "Write for the person about to run `git commit`, not for PR reviewers. "
    "Do not mention pull requests unless the JSON audience is 'pr'. "
    "Be concise, specific, and grounded only in the JSON facts provided. "
    "Do not invent files or features. Output valid JSON with keys: "
    "summary (2-3 sentences describing what changed and what to watch), "
    "why (1-2 sentences on intent and scope — help them validate the change belongs in the next commit), "
    "ask_yourself (array of exactly 5 short self-check questions before committing)."
)

SYSTEM_PROMPT_PR = (
    "You are a staff engineer writing a pull request review brief for teammates. "
    "Be concise, specific, and grounded only in the JSON facts provided. "
    "Do not invent files or features. Output valid JSON with keys: "
    "summary (2-3 sentences), why (1-2 sentences), "
    "ask_yourself (array of exactly 5 short self-check questions the author should verify before merge)."
)

SYSTEM_PROMPT = SYSTEM_PROMPT_PRECOMMIT


@dataclass(frozen=True)
class ProviderSpec:
    id: str
    label: str
    api_key_env: str
    model_env: str
    default_model: str
    openai_compatible_url: str | None = None


PROVIDERS: dict[str, ProviderSpec] = {
    "openai": ProviderSpec(
        id="openai",
        label="OpenAI",
        api_key_env="OPENAI_API_KEY",
        model_env="OPENAI_MODEL",
        default_model="gpt-4o-mini",
        openai_compatible_url="https://api.openai.com/v1/chat/completions",
    ),
    "anthropic": ProviderSpec(
        id="anthropic",
        label="Anthropic",
        api_key_env="ANTHROPIC_API_KEY",
        model_env="ANTHROPIC_MODEL",
        default_model="claude-3-5-haiku-20241022",
    ),
    "google": ProviderSpec(
        id="google",
        label="Google Gemini",
        api_key_env="GOOGLE_API_KEY",
        model_env="GOOGLE_MODEL",
        default_model="gemini-2.0-flash",
    ),
    "groq": ProviderSpec(
        id="groq",
        label="Groq",
        api_key_env="GROQ_API_KEY",
        model_env="GROQ_MODEL",
        default_model="llama-3.3-70b-versatile",
        openai_compatible_url="https://api.groq.com/openai/v1/chat/completions",
    ),
    "mistral": ProviderSpec(
        id="mistral",
        label="Mistral",
        api_key_env="MISTRAL_API_KEY",
        model_env="MISTRAL_MODEL",
        default_model="mistral-small-latest",
        openai_compatible_url="https://api.mistral.ai/v1/chat/completions",
    ),
}

PROVIDER_ORDER = ("openai", "anthropic", "google", "groq", "mistral")


def provider_list() -> list[dict[str, str]]:
    return [
        {"id": p.id, "label": p.label, "default_model": p.default_model}
        for p in (PROVIDERS[k] for k in PROVIDER_ORDER)
    ]


def system_prompt_for(audience: str = "precommit") -> str:
    return SYSTEM_PROMPT_PR if audience == "pr" else SYSTEM_PROMPT_PRECOMMIT


def chat_json(
    provider_id: str,
    model: str,
    user_payload: str,
    *,
    audience: str = "precommit",
) -> dict[str, Any]:
    spec = PROVIDERS.get(provider_id)
    if not spec:
        raise ValueError(f"Unknown provider: {provider_id}")

    api_key = os.getenv(spec.api_key_env, "").strip()
    if not api_key:
        raise ValueError(f"{spec.api_key_env} is not set")

    system = system_prompt_for(audience)
    if spec.openai_compatible_url:
        return _openai_compatible(
            spec.openai_compatible_url,
            api_key,
            model,
            user_payload,
            system=system,
            extra_headers={},
        )
    if provider_id == "anthropic":
        return _anthropic(api_key, model, user_payload, system=system)
    if provider_id == "google":
        return _google(api_key, model, user_payload, system=system)
    raise ValueError(f"Provider not implemented: {provider_id}")


def _openai_compatible(
    url: str,
    api_key: str,
    model: str,
    user_payload: str,
    *,
    system: str,
    extra_headers: dict[str, str],
) -> dict[str, Any]:
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_payload},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.2,
    }
    headers = {"Authorization": f"Bearer {api_key}", **extra_headers}
    with httpx.Client(timeout=90.0) as client:
        resp = client.post(url, headers=headers, json=body)
        resp.raise_for_status()
    content = resp.json()["choices"][0]["message"]["content"]
    return json.loads(content)


def _anthropic(
    api_key: str, model: str, user_payload: str, *, system: str
) -> dict[str, Any]:
    body = {
        "model": model,
        "max_tokens": 2048,
        "system": system + " Reply with JSON only, no markdown fences.",
        "messages": [{"role": "user", "content": user_payload}],
    }
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    with httpx.Client(timeout=90.0) as client:
        resp = client.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=body,
        )
        resp.raise_for_status()
    blocks = resp.json().get("content") or []
    text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    return json.loads(text)


def _google(api_key: str, model: str, user_payload: str, *, system: str) -> dict[str, Any]:
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{model}:generateContent"
    )
    body = {
        "contents": [
            {
                "role": "user",
                "parts": [
                    {"text": system + "\n\n" + user_payload},
                ],
            }
        ],
        "generationConfig": {
            "temperature": 0.2,
            "responseMimeType": "application/json",
        },
    }
    with httpx.Client(timeout=90.0) as client:
        resp = client.post(url, params={"key": api_key}, json=body)
        resp.raise_for_status()
    data = resp.json()
    parts = data["candidates"][0]["content"]["parts"]
    text = parts[0].get("text", "")
    return json.loads(text)
