const $ = (id) => document.getElementById(id);

const REVIEW_STORE_KEY = "scrutin.reviewed.v1";

let currentBrief = null;
let reviewedPaths = new Set();
let briefFingerprint = "";
let diffModalPath = null;
let hasStagedChanges = false;
let gitWorkspace = null;
/** @type {{ resolve: (v: { name: string; email: string }) => void; reject: (e: Error) => void } | null} */
let identityModalWaiter = null;

/** Fallback when /api/v1/settings/llm is unavailable (must match server provider_list). */
const LLM_PROVIDERS_FALLBACK = [
  { id: "openai", label: "OpenAI", default_model: "gpt-4o-mini" },
  { id: "anthropic", label: "Anthropic", default_model: "claude-3-5-haiku-20241022" },
  { id: "google", label: "Google Gemini", default_model: "gemini-2.0-flash" },
  { id: "groq", label: "Groq", default_model: "llama-3.3-70b-versatile" },
  { id: "mistral", label: "Mistral", default_model: "mistral-small-latest" },
];

function escapeHtml(text) {
  return String(text ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Omit +/− when the line count is zero (avoids "+0" / "−0"). */
function formatLineDelta(n, kind) {
  const v = Number(n) || 0;
  if (v === 0) return "0";
  return kind === "add" ? `+${v}` : `−${v}`;
}

function repoFromUrl() {
  const p = new URLSearchParams(window.location.search);
  return p.get("repo") || "";
}

function detectUrl() {
  const repo = $("repo").value.trim();
  const q = repo ? `?repo=${encodeURIComponent(repo)}` : "";
  return `/api/v1/workspace/detect${q}`;
}

function errorFromApiDetail(detail, statusText) {
  if (detail && typeof detail === "object" && !Array.isArray(detail)) {
    const err = new Error(detail.message || detail.code || statusText || "Request failed");
    err.code = detail.code;
    err.detail = detail;
    return err;
  }
  const msg = Array.isArray(detail)
    ? detail.map((d) => d.msg || d).join("; ")
    : detail || statusText || "Request failed";
  return new Error(msg);
}

async function api(path, options = {}) {
  const res = await fetch(path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw errorFromApiDetail(data.detail, res.statusText);
  }
  return data;
}

function workspaceRepo() {
  return $("repo").value.trim();
}

function workspaceQuery(extra = {}) {
  const q = new URLSearchParams({
    repo: workspaceRepo(),
    mode: $("mode").value,
    base: $("base").value,
    head: $("head").value,
    ...extra,
  });
  return q;
}

async function apiPost(path, body) {
  return api(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function fetchFileDiff(path) {
  return api(`/api/v1/workspace/file-diff?${workspaceQuery({ path })}`);
}

async function stagePath(path) {
  return apiPost("/api/v1/workspace/stage", { repo: workspaceRepo(), path });
}

async function unstagePath(path) {
  return apiPost("/api/v1/workspace/unstage", { repo: workspaceRepo(), path });
}

async function stagePaths(paths) {
  return apiPost("/api/v1/workspace/stage-files", { repo: workspaceRepo(), paths });
}

async function unstagePaths(paths) {
  return apiPost("/api/v1/workspace/unstage-files", { repo: workspaceRepo(), paths });
}

async function fetchChangedPaths() {
  const repo = workspaceRepo();
  if (!repo) return [];
  const data = await api(`/api/v1/workspace/changed-paths?repo=${encodeURIComponent(repo)}`);
  return data.paths || [];
}

function pathsNeedingStage(files) {
  return files.filter((f) => !(f.staged && !f.has_unstaged)).map((f) => f.path);
}

function pathsStaged(files) {
  return files.filter((f) => f.staged).map((f) => f.path);
}

async function stageAllChanged() {
  let files = currentBrief ? allChangedFiles(currentBrief) : [];
  if (!files.length) {
    files = await fetchChangedPaths();
  }
  const paths = pathsNeedingStage(files);
  if (!paths.length) {
    setStatus("is-ok", "nothing to stage");
    return;
  }
  await stagePaths(paths);
  await loadDetect();
  await loadBrief();
}

async function unstageAllChanged() {
  let files = currentBrief ? allChangedFiles(currentBrief) : [];
  if (!files.length) {
    files = await fetchChangedPaths();
  }
  const paths = pathsStaged(files);
  if (!paths.length) {
    setStatus("is-ok", "nothing staged");
    return;
  }
  await unstagePaths(paths);
  await loadDetect();
  await loadBrief();
}

async function refreshGitWorkspace() {
  const repo = workspaceRepo();
  if (!repo) {
    gitWorkspace = null;
    hasStagedChanges = false;
    return;
  }
  try {
    gitWorkspace = await api(`/api/v1/workspace/git-status?repo=${encodeURIComponent(repo)}`);
    hasStagedChanges = !!gitWorkspace?.has_staged;
  } catch (_) {
    gitWorkspace = null;
    hasStagedChanges = false;
  }
}

async function refreshCommitReady() {
  await refreshGitWorkspace();
}

function allScrutinizeReviewed() {
  if (!currentBrief) return false;
  const displayFiles = scrutinizeList(currentBrief);
  const { pending, total } = fileReviewProgress(displayFiles);
  return total === 0 || pending === 0;
}

async function updateCommitControls() {
  await refreshCommitReady();
  const reviewed = allScrutinizeReviewed();
  const conflicts = !!gitWorkspace?.has_merge_conflicts;
  const canCommit = reviewed && hasStagedChanges && !conflicts;
  const btnCommit = $("btn-commit");
  const btnPush = $("btn-push");
  const btnCommitPush = $("btn-commit-push");
  if (btnCommit) btnCommit.disabled = !canCommit;
  if (btnPush) btnPush.disabled = conflicts;
  if (btnCommitPush) btnCommitPush.disabled = !canCommit || conflicts;
  const hint = $("commit-hint");
  const pushHint = $("push-hint");
  if (hint) {
    if (conflicts) {
      hint.textContent =
        "Unresolved merge conflicts — fix them manually in your editor, then stage and try again.";
    } else if (!reviewed) {
      hint.textContent = "Review all flagged files to enable commit.";
    } else if (!hasStagedChanges) {
      const needStage = currentBrief
        ? allChangedFiles(currentBrief).filter((f) => !f.staged || f.has_unstaged).length
        : 0;
      hint.textContent = needStage
        ? `Stage ${needStage} file(s) below (or Stage all) before committing.`
        : "Stage changes before committing.";
    } else {
      hint.textContent = "Ready to commit staged changes.";
    }
  }
  if (pushHint) {
    const push = gitWorkspace?.push;
    const remotes = gitWorkspace?.remotes || [];
    if (conflicts) {
      pushHint.hidden = true;
    } else if (!push?.has_remote && !push?.has_upstream && (push?.ahead || 0) > 0) {
      pushHint.hidden = false;
      const branch = push?.branch || "main";
      pushHint.textContent = `No git remote — run: git remote add origin <url> then git push -u origin ${branch}`;
    } else if (push?.can_push) {
      pushHint.hidden = false;
      if (push.has_upstream) {
        pushHint.textContent = `${push.ahead} commit(s) ahead of ${push.upstream}.`;
      } else {
        const remote = push.default_remote || "origin";
        pushHint.textContent = `${push.ahead} commit(s) ready to push to ${remote} (sets upstream on first push).`;
      }
    } else if (push?.needs_pull) {
      pushHint.hidden = false;
      pushHint.textContent = `Behind ${push.upstream} by ${push.behind} commit(s) — pull and resolve conflicts manually before pushing.`;
    } else if (remotes.length && !push?.has_upstream) {
      pushHint.hidden = false;
      pushHint.textContent = `Remotes: ${remotes.map((r) => r.name).join(", ")} — no upstream branch set yet.`;
    } else {
      pushHint.hidden = true;
    }
  }
}

function openIdentityModal(prefill = {}) {
  const dlg = $("identity-modal");
  const nameEl = $("git-author-name");
  const emailEl = $("git-author-email");
  if (nameEl) nameEl.value = prefill.name || "";
  if (emailEl) emailEl.value = prefill.email || "";
  dlg?.showModal();
}

function closeIdentityModal() {
  $("identity-modal")?.close();
}

function promptGitIdentity(prefill = {}) {
  return new Promise((resolve, reject) => {
    identityModalWaiter = { resolve, reject };
    openIdentityModal(prefill);
  });
}

async function saveGitIdentity(name, email) {
  await apiPost("/api/v1/workspace/git-identity", {
    repo: workspaceRepo(),
    name,
    email,
  });
  await refreshGitWorkspace();
}

async function ensureGitIdentityConfigured() {
  await refreshGitWorkspace();
  if (gitWorkspace?.identity?.configured) {
    return gitWorkspace.identity;
  }
  const prefill = gitWorkspace?.identity || {};
  const { name, email } = await promptGitIdentity({
    name: prefill.name || "",
    email: prefill.email || "",
  });
  await saveGitIdentity(name, email);
  return { name, email };
}

function showGitActionError(err) {
  const conflictCodes = new Set(["merge_conflict", "push_rejected", "nothing_to_push", "no_remote"]);
  if (err?.code && conflictCodes.has(err.code)) {
    const msg = err.message || String(err);
    setStatus("is-error", msg.split("\n")[0]);
    if (err.code === "no_remote") {
      showBriefNotice(msg);
    }
    void updateCommitControls();
    return;
  }
  if (err?.code === "identity_required") {
    void ensureGitIdentityConfigured().catch((e) => showBriefNotice(e.message));
    return;
  }
  showBriefNotice(err.message || String(err));
}

async function runGitAction(action) {
  try {
    await ensureGitIdentityConfigured();
    return await action();
  } catch (err) {
    if (err?.code === "identity_required") {
      await ensureGitIdentityConfigured();
      return await action();
    }
    throw err;
  }
}

async function suggestCommitMessage() {
  const data = await api(`/api/v1/workspace/commit-message?${workspaceQuery()}`);
  const el = $("commit-message");
  if (el) el.value = data.message || data.subject || "";
}

async function runCommit() {
  const message = ($("commit-message")?.value || "").trim();
  if (!message) throw new Error("Enter a commit message.");
  const result = await runGitAction(() =>
    apiPost("/api/v1/workspace/commit", {
      repo: workspaceRepo(),
      message,
    })
  );
  setStatus("is-ok", `Committed ${result.sha || ""}`.trim());
  if ($("commit-message")) $("commit-message").value = "";
  await refreshAfterGitMutation();
}

async function runPush() {
  const result = await runGitAction(() =>
    apiPost("/api/v1/workspace/push", { repo: workspaceRepo(), set_upstream: true })
  );
  const branch = result.branch || "";
  setStatus("is-ok", branch ? `Pushed ${branch}` : "Pushed to remote");
  await refreshGitWorkspace();
  await updateCommitControls();
}

async function runCommitAndPush() {
  const message = ($("commit-message")?.value || "").trim();
  if (!message) throw new Error("Enter a commit message.");
  const data = await runGitAction(() =>
    apiPost("/api/v1/workspace/commit-and-push", {
      repo: workspaceRepo(),
      message,
    })
  );
  const sha = data.commit?.sha || "";
  setStatus("is-ok", `Committed ${sha} and pushed`.trim());
  if ($("commit-message")) $("commit-message").value = "";
  await refreshAfterGitMutation();
}

async function refreshAfterGitMutation() {
  try {
    await loadDetect();
    await loadBrief();
  } catch (e) {
    showBriefNotice(e.message || String(e));
  }
  await updateCommitControls();
}

function renderDiffPaneLines(lines, side) {
  if (!lines.length) {
    return '<div class="diff-line diff-line--empty"><span class="diff-gutter">&nbsp;</span><span class="diff-text">&nbsp;</span></div>';
  }
  return lines
    .map((line) => {
      const kind = line.kind || "context";
      const text = line.text ?? "";
      if (kind === "empty") {
        return '<div class="diff-line diff-line--empty"><span class="diff-gutter">&nbsp;</span><span class="diff-text">&nbsp;</span></div>';
      }
      if (side === "left") {
        if (kind === "del") {
          return `<div class="diff-line diff-line--del"><span class="diff-gutter">−</span><span class="diff-text">${escapeHtml(text)}</span></div>`;
        }
        if (kind === "context") {
          return `<div class="diff-line diff-line--ctx"><span class="diff-gutter">&nbsp;</span><span class="diff-text">${escapeHtml(text)}</span></div>`;
        }
        return '<div class="diff-line diff-line--empty"><span class="diff-gutter">&nbsp;</span><span class="diff-text">&nbsp;</span></div>';
      }
      if (kind === "add") {
        return `<div class="diff-line diff-line--add"><span class="diff-gutter">+</span><span class="diff-text">${escapeHtml(text)}</span></div>`;
      }
      if (kind === "context") {
        return `<div class="diff-line diff-line--ctx"><span class="diff-gutter">&nbsp;</span><span class="diff-text">${escapeHtml(text)}</span></div>`;
      }
      return '<div class="diff-line diff-line--empty"><span class="diff-gutter">&nbsp;</span><span class="diff-text">&nbsp;</span></div>';
    })
    .join("");
}

function renderDiffModalBody(data) {
  const left = $("diff-pane-left");
  const right = $("diff-pane-right");
  if (!data.hunks?.length) {
    const empty =
      '<div class="diff-line diff-line--ctx"><span class="diff-gutter">&nbsp;</span><span class="diff-text">No diff for this file in the current compare mode.</span></div>';
    left.innerHTML = empty;
    right.innerHTML = empty;
    return;
  }
  left.innerHTML = data.hunks.map((h) => renderDiffPaneLines(h.left, "left")).join("");
  right.innerHTML = data.hunks.map((h) => renderDiffPaneLines(h.right, "right")).join("");
}

function patchFileStageInBrief(path, staged, has_unstaged) {
  if (!currentBrief) return;
  for (const list of [currentBrief.all_changed_files, currentBrief.files_to_scrutinize]) {
    if (!list) continue;
    for (const f of list) {
      if (f.path === path) {
        f.staged = staged;
        f.has_unstaged = has_unstaged;
      }
    }
  }
}

function normalizeFileStageStatus(data) {
  if (typeof data?.staged === "boolean") {
    return {
      staged: data.staged,
      has_unstaged: !!data.has_unstaged,
      in_compare_scope: !!data.in_compare_scope,
    };
  }
  return null;
}

function fileStageStatusFromBrief(path) {
  const f = allChangedFiles(currentBrief).find((x) => x.path === path);
  if (!f) return { staged: false, has_unstaged: true };
  return { staged: !!f.staged, has_unstaged: !!f.has_unstaged };
}

function applyFileStageStatus(path, status) {
  const normalized = normalizeFileStageStatus(status) || {
    staged: !!status?.staged,
    has_unstaged: !!status?.has_unstaged,
    in_compare_scope: !!status?.in_compare_scope,
  };
  patchFileStageInBrief(path, normalized.staged, normalized.has_unstaged);
  if (diffModalPath === path) {
    updateDiffStageBadge(normalized);
  }
  return normalized;
}

function updateDiffStageBadge(data) {
  const badge = $("diff-modal-stage-badge");
  if (!badge) return;
  const staged = !!data.staged;
  const has_unstaged = !!data.has_unstaged;
  const inCompareScope = !!data.in_compare_scope;
  if (staged && has_unstaged) {
    badge.textContent = "Staged + unstaged";
    badge.className = "diff-modal__badge diff-modal__badge--warn";
  } else if (staged) {
    badge.textContent = "Staged";
    badge.className = "diff-modal__badge diff-modal__badge--ok";
  } else if (has_unstaged) {
    badge.textContent = "Unstaged";
    badge.className = "diff-modal__badge diff-modal__badge--muted";
  } else if (inCompareScope) {
    badge.textContent = "In compare scope";
    badge.className = "diff-modal__badge diff-modal__badge--ok";
  } else {
    badge.textContent = "No local changes";
    badge.className = "diff-modal__badge diff-modal__badge--muted";
  }
  const stageBtn = $("btn-diff-stage");
  const unstageBtn = $("btn-diff-unstage");
  const fullyStaged = staged && !has_unstaged;
  if (stageBtn) stageBtn.hidden = fullyStaged;
  if (unstageBtn) unstageBtn.hidden = !staged;
  const markBtn = $("btn-diff-mark-reviewed");
  if (markBtn && diffModalPath) {
    const inScrutinize = scrutinizeList(currentBrief).some((f) => f.path === diffModalPath);
    markBtn.hidden = !inScrutinize;
    const reviewed = reviewedPaths.has(diffModalPath);
    markBtn.textContent = reviewed ? "✓ Reviewed" : "Mark reviewed";
    markBtn.setAttribute("aria-pressed", reviewed ? "true" : "false");
  }
}

async function afterFileStageChange(path, result) {
  applyFileStageStatus(path, result);
  if (currentBrief) renderBrief(currentBrief);
  await updateCommitControls();
  if (diffModalPath === path) {
    const data = await fetchFileDiff(path);
    renderDiffModalBody(data);
    const fromDiff = normalizeFileStageStatus(data);
    if (fromDiff) applyFileStageStatus(path, fromDiff);
  }
}

async function toggleFileStage(path) {
  const file = allChangedFiles(currentBrief).find((f) => f.path === path);
  const fullyStaged = !!file?.staged && !file?.has_unstaged;
  const result = fullyStaged ? await unstagePath(path) : await stagePath(path);
  await afterFileStageChange(path, result);
}

async function openDiffModal(path) {
  diffModalPath = path;
  const dialog = $("diff-modal");
  $("diff-modal-title").textContent = "File diff";
  $("diff-modal-path").textContent = path;
  renderDiffModalBody({ hunks: [] });
  dialog.showModal();
  try {
    const data = await fetchFileDiff(path);
    renderDiffModalBody(data);
    applyFileStageStatus(path, normalizeFileStageStatus(data) || fileStageStatusFromBrief(path));
  } catch (e) {
    renderDiffModalBody({ hunks: [] });
    $("diff-pane-left").innerHTML = `<div class="diff-line diff-line--del"><span class="diff-gutter">−</span><span class="diff-text">${escapeHtml(e.message)}</span></div>`;
    $("diff-pane-right").innerHTML = "";
  }
}

async function refreshDiffModal() {
  if (!diffModalPath) return;
  const data = await fetchFileDiff(diffModalPath);
  renderDiffModalBody(data);
  const fromDiff = normalizeFileStageStatus(data);
  if (fromDiff) applyFileStageStatus(diffModalPath, fromDiff);
  else updateDiffStageBadge(fileStageStatusFromBrief(diffModalPath));
  await updateCommitControls();
}

function setStatus(state, text) {
  const el = $("status");
  el.textContent = text;
  el.className = "status-pill";
  if (state) el.classList.add(state);
}

function setEnvHint({ status, envFile, briefMode } = {}) {
  const el = $("llm-env-hint");
  if (!el) return;
  const parts = [];
  if (status) {
    parts.push(`<span class="env-hint__status">${escapeHtml(status)}</span>`);
  }
  if (envFile) {
    parts.push('<span class="env-hint__label">Env file</span>');
    parts.push(`<code class="env-hint__path">${escapeHtml(envFile)}</code>`);
  }
  if (briefMode) {
    parts.push(`<span class="env-hint__meta">Mode: ${escapeHtml(briefMode)}</span>`);
  }
  if (!parts.length) {
    el.innerHTML = "";
    el.hidden = true;
    return;
  }
  el.innerHTML = parts.join("");
  el.hidden = false;
}

function showBriefLoading(subtitle) {
  const panel = $("brief-panel");
  panel.className = "main main--loading";
  panel.innerHTML = `
    <div class="brief-loading" role="status" aria-live="polite" aria-busy="true">
      <div class="brief-loading__backdrop" aria-hidden="true"></div>
      <div class="brief-loading__card">
        <div class="brief-loading__spinner" aria-hidden="true">
          <span class="brief-loading__ring"></span>
          <span class="brief-loading__ring brief-loading__ring--mid"></span>
          <span class="brief-loading__ring brief-loading__ring--inner"></span>
          <span class="brief-loading__core">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M4 6h16M4 12h10M4 18h16"/>
            </svg>
          </span>
        </div>
        <h2 class="brief-loading__title">Building your brief</h2>
        <p class="brief-loading__sub">${escapeHtml(subtitle || "Parsing diff · scoring risk · assembling dashboard")}</p>
        <ul class="brief-loading__steps" aria-hidden="true">
          <li class="brief-loading__step brief-loading__step--1">Parse diff</li>
          <li class="brief-loading__step brief-loading__step--2">Score risk</li>
          <li class="brief-loading__step brief-loading__step--3">Build dashboard</li>
        </ul>
        <div class="brief-loading__track" aria-hidden="true">
          <div class="brief-loading__bar"></div>
        </div>
      </div>
    </div>`;
}

function settingsUrl() {
  const repo = $("repo").value.trim();
  return repo ? `/api/v1/settings/llm?repo=${encodeURIComponent(repo)}` : "/api/v1/settings/llm";
}

function fillLlmProviders(providers, selected) {
  const sel = $("llm-provider");
  if (!sel) return;
  const list = providers?.length ? providers : LLM_PROVIDERS_FALLBACK;
  sel.innerHTML = '<option value="none">none — Sharpen heuristics only</option>';
  for (const p of list) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.label;
    if (p.id === selected) opt.selected = true;
    sel.appendChild(opt);
  }
  sel.value = selected && [...sel.options].some((o) => o.value === selected) ? selected : "none";
  window.__llmProviders = list;
}

async function fetchLlmProviders() {
  try {
    const data = await api("/api/v1/settings/providers");
    if (data.providers?.length) return data.providers;
  } catch (_) {
    /* use fallback */
  }
  return LLM_PROVIDERS_FALLBACK;
}

function applyLlmSettings(data) {
  const providers = data.providers?.length ? data.providers : LLM_PROVIDERS_FALLBACK;
  fillLlmProviders(providers, data.provider || "none");
  const modelEl = $("llm-model");
  if (modelEl) modelEl.value = data.model || "";
  if (modelEl) {
    modelEl.placeholder =
      providers.find((p) => p.id === data.provider)?.default_model || "model id";
  }
  const hint = $("llm-key-hint");
  if (hint) {
    if (data.api_key_set) {
      hint.textContent = `Key on file: ${data.api_key_hint || "set"} — enter a new key only to replace.`;
    } else {
      hint.textContent = "No API key saved — Sharpen heuristics will be used.";
    }
  }
  setEnvHint({
    envFile: data.env_file || "",
    briefMode: data.brief_mode || "sharpen",
  });
}

async function loadLlmSettings() {
  fillLlmProviders(LLM_PROVIDERS_FALLBACK, "none");
  try {
    const data = await api(settingsUrl());
    applyLlmSettings(data);
    return data;
  } catch (err) {
    const providers = await fetchLlmProviders();
    applyLlmSettings({
      provider: "none",
      model: "",
      api_key_set: false,
      api_key_hint: "",
      env_file: "",
      providers,
    });
    setEnvHint({ status: `Settings API unavailable: ${err.message}. Restart scrutin serve.` });
    return null;
  }
}

function showLlmError(err) {
  const message = err instanceof Error ? err.message : String(err);
  setEnvHint({ status: message });
  setStatus("is-error", "error");
}

async function checkServerVersion() {
  try {
    const h = await api("/health");
    if (!h.settings_api) {
      showLlmError(
        "Server missing settings API (v0.3 or older). Stop serve, run: pip install -U scrutin && scrutin serve"
      );
      return false;
    }
    return true;
  } catch (_) {
    return false;
  }
}

async function saveLlmSettings() {
  const body = {
    provider: $("llm-provider").value,
    model: $("llm-model").value.trim() || null,
  };
  const keyInput = $("llm-key").value;
  if (keyInput.length) body.api_key = keyInput;

  let res = await fetch(settingsUrl(), {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.status === 404 || res.status === 405) {
    res = await fetch(settingsUrl(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = data.detail;
    throw new Error(typeof detail === "string" ? detail : res.statusText || `HTTP ${res.status}`);
  }
  $("llm-key").value = "";
  await loadLlmSettings();
  setEnvHint({
    status: `Saved · ${data.brief_mode === "llm" ? "LLM active" : "Sharpen heuristics"}`,
    envFile: data.env_file || "",
    briefMode: data.brief_mode || "sharpen",
  });
  setStatus("is-ok", data.brief_mode === "llm" ? "llm saved" : "sharpen");
}

function riskTagSeverity(label) {
  const s = String(label).toLowerCase();
  if (
    s.includes("authentication") ||
    s.includes("secret") ||
    s.includes("migration") ||
    s.includes("deploy") ||
    s.includes("pipeline")
  ) {
    return "issue";
  }
  if (s.includes("no automatic") || s.includes("manual review")) {
    return "ok";
  }
  return "warn";
}

function fileSeverity(file) {
  if (!file.is_risky) return "ok";
  const reasons = (file.risk_reasons || []).join(" ").toLowerCase();
  if (
    reasons.includes("authentication") ||
    reasons.includes("secret") ||
    reasons.includes("migration")
  ) {
    return "issue";
  }
  return "warn";
}

function allChangedFiles(brief) {
  if (!brief) return [];
  if (Array.isArray(brief.all_changed_files)) return brief.all_changed_files;
  return brief.files_to_scrutinize || [];
}

function scrutinizeList(brief) {
  const flagged = brief?.files_to_scrutinize || [];
  if (flagged.length) return flagged;
  const all = allChangedFiles(brief);
  const risky = all.filter((f) => f.is_risky);
  if (risky.length) return risky;
  return all.slice(0, 24);
}

function scrutinizePathSet(brief) {
  return new Set(scrutinizeList(brief).map((f) => f.path));
}

function otherChangedFiles(brief) {
  const flagged = scrutinizePathSet(brief);
  return allChangedFiles(brief).filter((f) => !flagged.has(f.path));
}

function isScrutinizePath(brief, path) {
  return scrutinizePathSet(brief).has(path);
}

function computeBriefFingerprint(repo, mode, base, head, files) {
  const sig = files
    .map((f) => `${f.path}:${f.status}:${f.additions}:${f.deletions}`)
    .sort()
    .join("|");
  return `${repo}|${mode}|${base}|${head}|${sig}`;
}

function loadReviewStore() {
  try {
    return JSON.parse(localStorage.getItem(REVIEW_STORE_KEY) || "{}");
  } catch (_) {
    return {};
  }
}

function saveReviewStore(store) {
  try {
    localStorage.setItem(REVIEW_STORE_KEY, JSON.stringify(store));
  } catch (_) {
    /* ignore */
  }
}

function initReviewState(brief, repo, mode, base, head) {
  const displayFiles = scrutinizeList(brief);
  briefFingerprint = computeBriefFingerprint(repo, mode, base, head, displayFiles);
  const store = loadReviewStore();
  const stored = new Set(store[briefFingerprint] || []);
  const paths = new Set(displayFiles.map((f) => f.path));
  reviewedPaths = new Set([...stored].filter((p) => paths.has(p)));
  store[briefFingerprint] = [...reviewedPaths];
  saveReviewStore(store);
  currentBrief = brief;
}

function toggleFileReviewed(path) {
  if (reviewedPaths.has(path)) {
    reviewedPaths.delete(path);
  } else {
    reviewedPaths.add(path);
  }
  const store = loadReviewStore();
  store[briefFingerprint] = [...reviewedPaths];
  saveReviewStore(store);
  if (currentBrief) {
    renderBrief(currentBrief);
    updateReviewStatusPill();
    void updateCommitControls();
  }
}

function fileReviewProgress(displayFiles) {
  const total = displayFiles.length;
  const reviewed = displayFiles.filter((f) => reviewedPaths.has(f.path)).length;
  return { total, reviewed, pending: Math.max(0, total - reviewed) };
}

function reviewNoteText(displayFiles) {
  const { total, reviewed, pending } = fileReviewProgress(displayFiles);
  if (!total) return "";
  if (pending === 0) {
    return `All ${total} flagged file(s) marked reviewed — good to commit once self-checks pass.`;
  }
  const pendingPaths = displayFiles
    .filter((f) => !reviewedPaths.has(f.path))
    .slice(0, 3)
    .map((f) => f.path);
  const more = pending > pendingPaths.length ? ` (+${pending - pendingPaths.length} more)` : "";
  return `${reviewed} of ${total} flagged file(s) reviewed. Still pending: ${pendingPaths.join(", ")}${more}.`;
}

function overallHealth(stats, risks, review) {
  const risky = Number(stats.risky_files || 0);
  const hasIssueRisk = (risks || []).some((r) => riskTagSeverity(r) === "issue");
  const { total, pending } = review || { total: 0, pending: 0 };
  if (total > 0 && pending === 0) {
    return hasIssueRisk ? "warn" : "ok";
  }
  if (risky >= 3 || hasIssueRisk) return "issue";
  if (risky >= 1 || pending > 0) return "warn";
  return "ok";
}

function healthLabel(level, review) {
  const { total, pending } = review || { total: 0, pending: 0 };
  if (total > 0 && pending === 0) {
    return level === "warn" ? "Reviewed — high-risk areas remain" : "Ready to commit";
  }
  if (level === "issue") return "Needs attention";
  if (level === "warn") return "Review carefully";
  return "Looking good";
}

function updateReviewStatusPill() {
  if (!currentBrief) return;
  const displayFiles = scrutinizeList(currentBrief);
  const { total, reviewed, pending } = fileReviewProgress(displayFiles);
  if (!total) return;
  const el = $("status");
  if (pending === 0) {
    setStatus("is-ok", `reviewed ${reviewed}/${total}`);
  } else {
    setStatus("is-busy", `${pending} file(s) left`);
  }
}

function renderBarRow(label, value, max, fillClass) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  return `
    <div class="bar-row">
      <span class="bar-row__label">${escapeHtml(label)}</span>
      <div class="bar-row__track"><div class="bar-row__fill ${fillClass}" style="width:${pct}%"></div></div>
      <span class="bar-row__val">${value}</span>
    </div>`;
}

function renderDonut(risky, safe, issueCount) {
  const total = risky + safe || 1;
  const issue = Math.min(Math.max(0, issueCount), risky);
  const warnOnly = Math.max(0, risky - issue);
  const issueEnd = (issue / total) * 100;
  const warnEnd = issueEnd + (warnOnly / total) * 100;

  let bg = "conic-gradient(var(--ok) 0% 100%)";
  if (issue > 0 && warnOnly > 0 && safe > 0) {
    bg = `conic-gradient(var(--issue) 0% ${issueEnd}%, var(--warn) ${issueEnd}% ${warnEnd}%, var(--ok) ${warnEnd}% 100%)`;
  } else if (issue > 0 && warnOnly > 0) {
    bg = `conic-gradient(var(--issue) 0% ${issueEnd}%, var(--warn) ${issueEnd}% 100%)`;
  } else if (issue > 0 && safe > 0) {
    bg = `conic-gradient(var(--issue) 0% ${issueEnd}%, var(--ok) ${issueEnd}% 100%)`;
  } else if (warnOnly > 0 && safe > 0) {
    bg = `conic-gradient(var(--warn) 0% ${warnEnd}%, var(--ok) ${warnEnd}% 100%)`;
  } else if (issue > 0) {
    bg = "conic-gradient(var(--issue) 0% 100%)";
  } else if (warnOnly > 0) {
    bg = "conic-gradient(var(--warn) 0% 100%)";
  }

  const legend = [];
  if (issue > 0) {
    legend.push(
      `<li><span class="donut-legend__swatch donut-legend__swatch--issue"></span> Critical · ${issue}</li>`
    );
  }
  if (warnOnly > 0) {
    legend.push(
      `<li><span class="donut-legend__swatch donut-legend__swatch--warn"></span> Risky · ${warnOnly}</li>`
    );
  }
  legend.push(`<li><span class="donut-legend__swatch donut-legend__swatch--ok"></span> Safe · ${safe}</li>`);

  return `
    <div class="donut-wrap">
      <div class="donut" style="background:${bg}" role="img" aria-label="File mix chart"></div>
      <ul class="donut-legend">
        ${legend.join("")}
      </ul>
    </div>`;
}

function renderRiskTags(areas) {
  if (!areas.length) {
    return '<p class="empty-msg">No automatic risk tags.</p>';
  }
  return `<div class="tag-grid">${areas
    .map((a) => {
      const sev = riskTagSeverity(a);
      return `<span class="tag tag--${sev}">${escapeHtml(a)}</span>`;
    })
    .join("")}</div>`;
}

function renderReviewProgress(displayFiles) {
  const { total, reviewed, pending } = fileReviewProgress(displayFiles);
  if (!total) return "";
  const pct = Math.round((reviewed / total) * 100);
  return `
    <div class="review-progress" role="status">
      <div class="review-progress__head">
        <span class="review-progress__label">File review</span>
        <span class="review-progress__count">${reviewed} / ${total} reviewed</span>
      </div>
      <div class="review-progress__track" aria-hidden="true">
        <div class="review-progress__fill" style="width:${pct}%"></div>
      </div>
      <p class="review-progress__hint">${pending ? `${pending} file(s) still need your review before commit.` : "All flagged files reviewed."}</p>
    </div>`;
}

function renderFileTiles(files, { reviewable = true } = {}) {
  const reviewForPath =
    typeof reviewable === "function"
      ? reviewable
      : () => !!reviewable;
  if (!files.length) {
    return `<p class="empty-msg">No changed files in this compare scope.</p>`;
  }
  const sorted = [...files].sort((a, b) => {
    const aFlag = reviewForPath(a) ? 0 : 1;
    const bFlag = reviewForPath(b) ? 0 : 1;
    if (aFlag !== bFlag) return aFlag - bFlag;
    if (reviewForPath(a)) {
      const ar = reviewedPaths.has(a.path) ? 1 : 0;
      const br = reviewedPaths.has(b.path) ? 1 : 0;
      if (ar !== br) return ar - br;
    }
    return a.path.localeCompare(b.path);
  });
  return `<div class="file-grid">${sorted
    .map((f) => {
      const sev = fileSeverity(f);
      const reasons = (f.risk_reasons || []).join(" · ") || (f.is_risky ? "review" : "changed");
      const reviewed = reviewedPaths.has(f.path);
      const isStaged = !!f.staged;
      const fullyStaged = isStaged && !f.has_unstaged;
      const needsReview = reviewForPath(f);
      const reviewBtn = needsReview
        ? `<button type="button" class="file-tile__review-btn" data-path="${escapeHtml(f.path)}" aria-pressed="${reviewed ? "true" : "false"}">
              ${reviewed ? "✓ Reviewed" : "Mark reviewed"}
            </button>`
        : "";
      return `
        <article class="file-tile file-tile--${sev}${reviewed ? " file-tile--reviewed" : ""}${isStaged ? " file-tile--staged" : ""}" data-path="${escapeHtml(f.path)}">
          <code class="file-tile__path">${escapeHtml(f.path)}</code>
          <span class="file-tile__meta">${escapeHtml(f.status)} · <span class="stat-add">${formatLineDelta(f.additions, "add")}</span> <span class="stat-del">${formatLineDelta(f.deletions, "del")}</span>${reasons ? ` · ${escapeHtml(reasons)}` : ""}</span>
          <div class="file-tile__actions">
            <button type="button" class="file-tile__diff-btn" data-path="${escapeHtml(f.path)}">View diff</button>
            <button type="button" class="file-tile__stage-btn" data-path="${escapeHtml(f.path)}" data-staged="${fullyStaged ? "true" : "false"}">${fullyStaged ? "Unstage" : "Stage"}</button>
            ${reviewBtn}
          </div>
        </article>`;
    })
    .join("")}</div>`;
}

function bindFileReviewHandlers(root) {
  root.querySelectorAll(".file-tile__review-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleFileReviewed(btn.dataset.path);
    });
  });
  root.querySelectorAll(".file-tile__diff-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openDiffModal(btn.dataset.path).catch(showError);
    });
  });
  root.querySelectorAll(".file-tile__stage-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleFileStage(btn.dataset.path).catch(showError);
    });
  });
}

function renderChecklist(items) {
  if (!items.length) {
    return '<p class="empty-msg">No self-checks generated.</p>';
  }
  return `<ul class="checklist">${items
    .map((text, i) => {
      const sev = i < 2 ? "warn" : "ok";
      return `
        <li class="checklist__item checklist__item--${sev}">
          <span class="checklist__n">${i + 1}</span>
          <p class="checklist__text">${escapeHtml(text)}</p>
        </li>`;
    })
    .join("")}</ul>`;
}

function renderBrief(brief) {
  const panel = $("brief-panel");
  panel.className = "main";

  const stats = brief.stats || {};
  const allFiles = allChangedFiles(brief);
  const displayFiles = scrutinizeList(brief);
  const otherFiles = otherChangedFiles(brief);
  const riskyFiles = allFiles.filter((f) => f.is_risky);
  const risks = brief.risk_areas || [];
  const review = fileReviewProgress(displayFiles);
  const reviewNote = reviewNoteText(displayFiles);
  const selfChecks =
    brief.ask_yourself?.length
      ? brief.ask_yourself
      : (brief.questions_for_author || []).slice(0, 5);

  const additions = Number(stats.additions || 0);
  const deletions = Number(stats.deletions || 0);
  const filesChanged = Number(stats.files_changed || 0);
  const riskyCount = Number(stats.risky_files || 0);
  const safeCount = Math.max(0, filesChanged - riskyCount);
  const lineMax = Math.max(additions, deletions, 1);
  const health = overallHealth(stats, risks, review);
  const briefMode = stats.brief_mode || (brief.generated_with_llm ? "llm" : "sharpen");

  const kpiClass = health === "issue" ? "kpi--issue" : health === "warn" ? "kpi--warn" : "kpi--ok";
  const boxOverview = health === "ok" ? "ok" : health === "warn" ? "warn" : "issue";
  const riskySub =
    review.total > 0
      ? review.pending
        ? `${review.pending} left to review`
        : "all reviewed"
      : riskyCount
        ? "needs scrutiny"
        : "none flagged";

  panel.innerHTML = `
    <div class="dashboard">
      <header class="dash-header">
        <h1 class="dash-header__title">${escapeHtml(brief.title)}</h1>
        <span class="health-badge health-badge--${health}">
          <span class="health-badge__dot"></span>
          ${healthLabel(health, review)}
        </span>
      </header>

      <div class="kpi-row">
        <div class="kpi ${kpiClass}">
          <div class="kpi__label">Files changed</div>
          <div class="kpi__value">${filesChanged}</div>
          <div class="kpi__sub">${stats.diff_mode || "diff"}</div>
        </div>
        <div class="kpi ${review.pending ? "kpi--warn" : review.total ? "kpi--ok" : riskyCount ? "kpi--warn" : "kpi--ok"}">
          <div class="kpi__label">File review</div>
          <div class="kpi__value">${review.total ? `${review.reviewed}/${review.total}` : "—"}</div>
          <div class="kpi__sub">${review.total ? riskySub : riskyCount ? "needs scrutiny" : "none flagged"}</div>
        </div>
        <div class="kpi kpi--add">
          <div class="kpi__label">Lines added</div>
          <div class="kpi__value stat-add">${formatLineDelta(additions, "add")}</div>
        </div>
        <div class="kpi kpi--del">
          <div class="kpi__label">Lines removed</div>
          <div class="kpi__value stat-del">${formatLineDelta(deletions, "del")}</div>
        </div>
        <div class="kpi kpi--ok">
          <div class="kpi__label">Brief engine</div>
          <div class="kpi__value" style="font-size:1.1rem">${escapeHtml(briefMode)}</div>
          <div class="kpi__sub">${escapeHtml(stats.llm_provider || "sharpen")}</div>
        </div>
      </div>

      <div class="charts-row">
        <div class="dash-box">
          <h2 class="dash-box__title">Diff activity</h2>
          <div class="bar-chart">
            ${renderBarRow("Additions", additions, lineMax, "bar-row__fill--add")}
            ${renderBarRow("Deletions", deletions, lineMax, "bar-row__fill--del")}
            ${renderBarRow("Risky files", riskyCount, Math.max(filesChanged, 1), "bar-row__fill--risky")}
          </div>
        </div>
        <div class="dash-box">
          <h2 class="dash-box__title">File mix</h2>
          ${renderDonut(riskyCount, safeCount, riskyFiles.filter((f) => fileSeverity(f) === "issue").length)}
        </div>
        <div class="dash-box dash-box--${boxOverview}">
          <h2 class="dash-box__title">Risk overview</h2>
          <p class="box-body" style="margin-bottom:12px">${riskyCount ? `<strong>${riskyCount}</strong> file(s) flagged · <strong>${risks.length}</strong> risk categories` : "No elevated-risk files detected."}</p>
          ${review.total ? `<p class="box-body review-note">${escapeHtml(reviewNote)}</p>` : ""}
          ${renderRiskTags(risks.slice(0, 8))}
        </div>
      </div>

      <div class="dash-grid">
        <div class="dash-box dash-box--ok dash-grid__span-6">
          <h2 class="dash-box__title">Summary</h2>
          ${reviewNote ? `<p class="box-body review-note review-note--summary">${escapeHtml(reviewNote)}</p>` : ""}
          <p class="box-body box-body--markdown">${escapeHtml(brief.summary)}</p>
        </div>
        <div class="dash-box dash-box--ok dash-grid__span-6">
          <h2 class="dash-box__title">Why</h2>
          <p class="box-body">${escapeHtml(brief.why)}</p>
        </div>

        <div class="dash-box dash-box--${risks.some((r) => riskTagSeverity(r) === "issue") ? "issue" : risks.length ? "warn" : "ok"} dash-grid__span-12">
          <h2 class="dash-box__title">Risk areas</h2>
          ${renderRiskTags(risks)}
        </div>

        ${
          displayFiles.length
            ? `<div class="dash-box dash-box--${review.pending ? "warn" : review.total ? "ok" : "warn"} dash-grid__span-12">
          <h2 class="dash-box__title">Files to scrutinize (${displayFiles.length})</h2>
          <p class="box-body file-section-hint">Higher-risk or largest edits — mark each reviewed before commit.</p>
          ${renderReviewProgress(displayFiles)}
          ${renderFileTiles(displayFiles, { reviewable: true })}
        </div>`
            : ""
        }

        ${
          otherFiles.length
            ? `<div class="dash-box dash-box--ok dash-grid__span-12">
          <h2 class="dash-box__title">Other changed files (${otherFiles.length})</h2>
          <p class="box-body file-section-hint">Additional paths in this compare scope — view diff, stage, or unstage.</p>
          ${renderFileTiles(otherFiles, { reviewable: false })}
        </div>`
            : !displayFiles.length && allFiles.length
              ? `<div class="dash-box dash-box--ok dash-grid__span-12">
          <h2 class="dash-box__title">Changed files (${allFiles.length})</h2>
          <p class="box-body file-section-hint">View diff, stage, or unstage before commit.</p>
          ${renderFileTiles(allFiles, { reviewable: false })}
        </div>`
              : ""
        }

        <div class="dash-box dash-box--warn dash-grid__span-12">
          <h2 class="dash-box__title">Ask yourself — 5 self-checks</h2>
          ${renderChecklist(selfChecks)}
        </div>

        <div class="dash-box dash-grid__span-12">
          <h2 class="dash-box__title">Rollback</h2>
          <p class="box-body">${escapeHtml(brief.rollback_notes)}</p>
        </div>
      </div>

      <p class="dash-footer">Scrutin · local · .scrutinignore</p>
    </div>
  `;
  bindFileReviewHandlers(panel);
  updateReviewStatusPill();
  void updateCommitControls();
}

function fillSelect(select, values, selected) {
  select.innerHTML = "";
  for (const v of values) {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    if (v === selected) opt.selected = true;
    select.appendChild(opt);
  }
}

function toggleBranchFields() {
  const isBranch = $("mode").value === "branch";
  $("branch-fields").hidden = !isBranch;
}

function persistRepo(path) {
  try {
    localStorage.setItem("scrutin.repo", path);
  } catch (_) {
    /* ignore */
  }
}

async function loadDetect() {
  setStatus("is-busy", "detecting…");
  const d = await api(detectUrl());
  $("repo").value = d.repo;
  persistRepo(d.repo);
  $("mode").value = "working";
  fillSelect($("base"), d.base_candidates || [d.base], d.base);
  const headOptions = [...new Set([d.head, "HEAD", ...(d.branches || [])])];
  fillSelect($("head"), headOptions, d.head);
  toggleBranchFields();

  const uc = $("uncommitted-hint");
  if (d.uncommitted?.has_changes) {
    uc.hidden = false;
    const u = d.uncommitted;
    const parts = [];
    if (u.staged) parts.push(`${u.staged} staged`);
    if (u.unstaged) parts.push(`${u.unstaged} unstaged`);
    if (u.untracked) parts.push(`${u.untracked} untracked`);
    const detail = parts.length ? parts.join(", ") : "changed";
    uc.textContent = `${u.total} path(s) with local changes (${detail}).`;
  } else {
    uc.hidden = false;
    uc.textContent = "No uncommitted changes — try Branch vs base, or edit files first.";
  }

  const hint = $("gh-hint");
  if (d.gh_available && d.gh_pr?.title) {
    hint.hidden = false;
    hint.textContent = `Open PR: ${d.gh_pr.title} (use Branch mode to match PR scope)`;
  } else {
    hint.hidden = true;
  }
  setStatus("is-ok", "ready");
  return d;
}

async function loadBrief() {
  const repo = $("repo").value.trim();
  if (!repo) {
    throw new Error("Enter a repository path, then click Detect repo.");
  }
  const mode = $("mode").value;
  const base = $("base").value;
  const head = $("head").value;
  setStatus("is-busy", "building…");
  const modeLabel = $("mode").selectedOptions[0]?.textContent?.split("·")[0]?.trim() || mode;
  showBriefLoading(`Comparing ${modeLabel} · ${base}…${head}`);

  const q = new URLSearchParams({ repo, mode, base, head, use_gh: mode === "branch" ? "true" : "false" });
  const data = await api(`/api/v1/workspace/brief?${q}`);
  if (!data.brief) {
    throw new Error("Brief payload missing from API.");
  }
  initReviewState(data.brief, repo, mode, base, head);
  renderBrief(data.brief);
}

async function init() {
  const fromUrl = repoFromUrl();
  const stored = (() => {
    try {
      return localStorage.getItem("scrutin.repo") || "";
    } catch (_) {
      return "";
    }
  })();
  $("repo").value = fromUrl || stored;

  $("btn-refresh").addEventListener("click", () => loadBrief().catch(showError));
  $("btn-detect").addEventListener("click", () =>
    loadDetect().then(() => loadLlmSettings()).then(() => loadBrief()).catch(showError)
  );
  const btnSaveLlm = $("btn-save-llm");
  if (btnSaveLlm) {
    btnSaveLlm.addEventListener("click", () => saveLlmSettings().catch(showLlmError));
  }
  const llmProvider = $("llm-provider");
  if (llmProvider) {
    llmProvider.addEventListener("change", () => {
      const id = llmProvider.value;
      const p = (window.__llmProviders || LLM_PROVIDERS_FALLBACK).find((x) => x.id === id);
      const modelEl = $("llm-model");
      if (p && modelEl) modelEl.placeholder = p.default_model;
    });
  }
  $("mode").addEventListener("change", () => {
    toggleBranchFields();
    loadBrief().catch(showError);
  });
  $("base").addEventListener("change", () => loadBrief().catch(showError));
  $("head").addEventListener("change", () => loadBrief().catch(showError));

  $("btn-suggest-commit")?.addEventListener("click", () =>
    suggestCommitMessage().catch(showError)
  );
  $("btn-commit")?.addEventListener("click", () => runCommit().catch(showGitActionError));
  $("btn-push")?.addEventListener("click", () => runPush().catch(showGitActionError));
  $("btn-commit-push")?.addEventListener("click", () => runCommitAndPush().catch(showGitActionError));

  $("identity-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = ($("git-author-name")?.value || "").trim();
    const email = ($("git-author-email")?.value || "").trim();
    if (!name || !email) {
      setStatus("is-error", "Name and email are required.");
      return;
    }
    saveGitIdentity(name, email)
      .then(() => {
        closeIdentityModal();
        identityModalWaiter?.resolve({ name, email });
        identityModalWaiter = null;
      })
      .catch((err) => {
        setStatus("is-error", err.message);
      });
  });
  $("btn-identity-cancel")?.addEventListener("click", () => {
    closeIdentityModal();
    identityModalWaiter?.reject(new Error("Git identity required to continue."));
    identityModalWaiter = null;
  });
  $("identity-modal")?.addEventListener("cancel", () => {
    identityModalWaiter?.reject(new Error("Git identity required to continue."));
    identityModalWaiter = null;
  });
  $("btn-stage-all")?.addEventListener("click", () => stageAllChanged().catch(showError));
  $("btn-unstage-all")?.addEventListener("click", () => unstageAllChanged().catch(showError));
  $("btn-diff-close")?.addEventListener("click", () => $("diff-modal")?.close());
  $("btn-diff-unstage")?.addEventListener("click", () => {
    if (!diffModalPath) return;
    unstagePath(diffModalPath)
      .then((r) => afterFileStageChange(diffModalPath, r))
      .catch(showError);
  });
  $("btn-diff-stage")?.addEventListener("click", () => {
    if (!diffModalPath) return;
    stagePath(diffModalPath)
      .then((r) => afterFileStageChange(diffModalPath, r))
      .catch(showError);
  });
  $("btn-diff-mark-reviewed")?.addEventListener("click", () => {
    if (!diffModalPath) return;
    toggleFileReviewed(diffModalPath);
    updateDiffStageBadge(fileStageStatusFromBrief(diffModalPath));
  });
  $("diff-modal")?.addEventListener("click", (e) => {
    if (e.target === $("diff-modal")) $("diff-modal").close();
  });

  toggleBranchFields();

  fillLlmProviders(LLM_PROVIDERS_FALLBACK, "none");
  checkServerVersion().then((ok) => {
    if (ok) loadLlmSettings().catch(showLlmError);
  });

  if ($("repo").value.trim()) {
    try {
      await loadDetect();
      await loadBrief();
    } catch (e) {
      showError(e);
    }
  } else {
    setStatus("", "set repo");
  }
}

function showBriefNotice(message) {
  setStatus("is-error", "notice");
  const panel = $("brief-panel");
  panel.className = "main panel--brief";
  panel.innerHTML = `
    <div class="brief-empty">
      <p class="brief-empty__title">${escapeHtml(message)}</p>
      <p class="brief-empty__sub">
        <button type="button" class="btn btn--ghost" id="btn-retry-brief">Refresh brief</button>
      </p>
    </div>`;
  $("btn-retry-brief")?.addEventListener("click", () => loadBrief().catch(showBriefNotice));
}

function showError(err) {
  showBriefNotice(err.message || String(err));
}

init();
