from __future__ import annotations

import os
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query

from scrutin.git_workspace import build_workspace_brief, git_toplevel, workspace_detect
from scrutin.models import ReviewBrief

router = APIRouter(prefix="/api/v1/workspace", tags=["workspace"])


def _resolve_repo_path(repo: str | None) -> Path | None:
    if repo and repo.strip():
        return git_toplevel(Path(repo.strip()))
    env = os.getenv("SCRUTIN_REPO", "").strip()
    if env:
        return git_toplevel(Path(env))
    return None


@router.get("/detect")
def detect_workspace(
    repo: str | None = Query(None, description="Git repo path; default cwd or SCRUTIN_REPO"),
) -> dict:
    try:
        start = _resolve_repo_path(repo)
        return workspace_detect(start)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e


@router.get("/brief")
def workspace_brief(
    repo: str = Query(..., description="Absolute path to git repository"),
    mode: str = Query(
        "working",
        description="working=staged+unstaged vs HEAD; staged; unstaged; branch=base...head",
    ),
    base: str = Query("main"),
    head: str = Query("HEAD"),
    use_gh: bool = Query(True, description="Enrich from gh pr view when in branch mode"),
) -> dict:
    path = Path(repo)
    if not path.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    try:
        brief, markdown, extra = build_workspace_brief(
            path, base, head, mode=mode, use_gh=use_gh and mode == "branch"
        )
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e

    return {
        "brief": brief.model_dump(),
        "markdown": markdown,
        "repo": str(path.resolve()),
        "mode": mode,
        "base": base,
        "head": head,
        **extra,
    }
