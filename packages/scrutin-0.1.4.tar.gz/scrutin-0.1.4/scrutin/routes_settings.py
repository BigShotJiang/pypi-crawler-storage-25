from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from scrutin.llm_providers import provider_list
from scrutin.llm_settings import LlmSettingsPublic, LlmSettingsUpdate, get_public_settings, save_settings

router = APIRouter(prefix="/api/v1/settings", tags=["settings"])


@router.get("/providers")
def list_llm_providers() -> dict:
    """Provider list for the UI (always available, no .env required)."""
    return {"providers": provider_list()}


@router.get("/llm", response_model=LlmSettingsPublic)
def get_llm_settings(
    repo: str | None = Query(None, description="Git repo path — .env written at repo root"),
) -> LlmSettingsPublic:
    try:
        return get_public_settings(repo)
    except Exception as e:
        raise HTTPException(400, str(e)) from e


def _update_llm_settings(
    body: LlmSettingsUpdate,
    repo: str | None,
) -> LlmSettingsPublic:
    try:
        return save_settings(repo, body)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    except Exception as e:
        raise HTTPException(500, str(e)) from e


@router.put("/llm", response_model=LlmSettingsPublic)
def put_llm_settings(
    body: LlmSettingsUpdate,
    repo: str | None = Query(None, description="Git repo path — .env written at repo root"),
) -> LlmSettingsPublic:
    return _update_llm_settings(body, repo)


@router.post("/llm", response_model=LlmSettingsPublic)
def post_llm_settings(
    body: LlmSettingsUpdate,
    repo: str | None = Query(None, description="Git repo path — .env written at repo root"),
) -> LlmSettingsPublic:
    return _update_llm_settings(body, repo)
