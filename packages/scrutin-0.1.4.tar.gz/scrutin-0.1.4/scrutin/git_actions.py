from __future__ import annotations

import re
import subprocess
from pathlib import Path

from pydantic import BaseModel, Field

from scrutin.diff_parser import extract_file_unified_diff, git_diff_for_mode, repo_has_commits
from scrutin.models import FileChange
from scrutin.path_ignore import normalize_repo_path

HUNK_HEADER = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


class DiffSideLine(BaseModel):
    kind: str  # context | add | del | empty
    text: str = ""


class DiffHunk(BaseModel):
    old_start: int
    new_start: int
    left: list[DiffSideLine]
    right: list[DiffSideLine]


class FileDiffResponse(BaseModel):
    path: str
    mode: str
    staged: bool
    has_unstaged: bool
    in_compare_scope: bool = False
    hunks: list[DiffHunk] = Field(default_factory=list)
    unified: str = ""


class CommitSuggestResponse(BaseModel):
    message: str
    subject: str
    body: str = ""


class GitActionError(RuntimeError):
    """Structured git errors for the UI (identity, push rejected, merge conflicts)."""

    def __init__(self, code: str, message: str, **extra: str | int | bool) -> None:
        self.code = code
        self.extra = extra
        super().__init__(message)


def _run_git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    repo = repo.resolve()
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
        check=False,
    )


def _git_diff_succeeded(result: subprocess.CompletedProcess[str]) -> bool:
    """git diff uses exit 0 (no changes) and 1 (has changes); both are success."""
    return result.returncode in (0, 1)


def _read_git_diff_result(result: subprocess.CompletedProcess[str], *, path: str = "") -> str:
    if result.stdout.strip():
        return result.stdout
    if _git_diff_succeeded(result):
        return ""
    detail = result.stderr.strip() or "git diff failed"
    if path:
        detail = f"{detail} ({path})"
    raise RuntimeError(detail)


def _path_untracked(repo: Path, path: str) -> bool:
    status = _run_git(repo, "status", "--porcelain", "--", path)
    return any(line.startswith("??") for line in status.stdout.splitlines())


def _untracked_file_unified_diff(repo: Path, path: str) -> str:
    """Untracked files do not appear in git diff; compare against empty tree."""
    if not (repo / path).is_file():
        return ""
    result = _run_git(repo, "diff", "--no-index", "--", "/dev/null", path)
    if result.stdout.strip():
        return result.stdout
    if _git_diff_succeeded(result):
        return ""
    if result.stderr.strip():
        raise RuntimeError(result.stderr.strip())
    return ""


def _file_working_unified_diff(repo: Path, path: str) -> str:
    """Staged (index vs HEAD) plus unstaged (tree vs index) for one path."""
    staged = _run_git(repo, "diff", "--cached", "--", path)
    unstaged = _run_git(repo, "diff", "--", path)
    parts: list[str] = []
    for part in (staged, unstaged):
        if part.stdout.strip():
            parts.append(part.stdout)
        elif not _git_diff_succeeded(part) and part.stderr.strip():
            raise RuntimeError(part.stderr.strip())
    if parts:
        return "\n".join(parts)
    if _path_untracked(repo, path):
        return _untracked_file_unified_diff(repo, path)
    if repo_has_commits(repo):
        head = _run_git(repo, "diff", "HEAD", "--", path)
        return _read_git_diff_result(head, path=path)
    return ""


def git_file_unified_diff(
    repo: Path,
    path: str,
    mode: str,
    base: str,
    head: str,
) -> str:
    repo = repo.resolve()
    path = normalize_repo_path(path)
    if mode == "branch":
        result = _run_git(repo, "diff", f"{base}...{head}", "--", path)
        return _read_git_diff_result(result, path=path)
    if mode == "staged":
        result = _run_git(repo, "diff", "--cached", "--", path)
    elif mode == "unstaged":
        result = _run_git(repo, "diff", "--", path)
    else:
        return _file_working_unified_diff(repo, path)
    return _read_git_diff_result(result, path=path)


def parse_unified_to_hunks(unified: str) -> list[DiffHunk]:
    hunks: list[DiffHunk] = []
    current: DiffHunk | None = None

    for raw in unified.splitlines():
        if raw.startswith("diff --git") or raw.startswith("index ") or raw.startswith("---") or raw.startswith("+++"):
            continue
        m = HUNK_HEADER.match(raw)
        if m:
            if current:
                hunks.append(current)
            current = DiffHunk(
                old_start=int(m.group(1)),
                new_start=int(m.group(3)),
                left=[],
                right=[],
            )
            continue
        if not current:
            continue
        if raw.startswith("-") and not raw.startswith("---"):
            current.left.append(DiffSideLine(kind="del", text=raw[1:]))
            current.right.append(DiffSideLine(kind="empty", text=""))
        elif raw.startswith("+") and not raw.startswith("+++"):
            current.left.append(DiffSideLine(kind="empty", text=""))
            current.right.append(DiffSideLine(kind="add", text=raw[1:]))
        elif raw.startswith(" ") or raw == "":
            text = raw[1:] if raw.startswith(" ") else ""
            current.left.append(DiffSideLine(kind="context", text=text))
            current.right.append(DiffSideLine(kind="context", text=text))
        elif raw.startswith("\\"):
            continue

    if current:
        hunks.append(current)
    return hunks


def file_diff(
    repo: Path,
    path: str,
    mode: str,
    base: str,
    head: str,
) -> FileDiffResponse:
    path = normalize_repo_path(path)
    unified = git_file_unified_diff(repo, path, mode, base, head)
    if not unified.strip():
        try:
            full = git_diff_for_mode(repo, mode, base, head)
            unified = extract_file_unified_diff(full, path)
        except RuntimeError:
            pass
    if not unified.strip() and mode == "working" and _path_untracked(repo, path):
        unified = _untracked_file_unified_diff(repo, path)
    staged, has_unstaged = file_stage_flags(repo, path)
    hunks = parse_unified_to_hunks(unified) if unified.strip() else []
    in_compare_scope = bool(hunks) and not staged and not has_unstaged
    return FileDiffResponse(
        path=path,
        mode=mode,
        staged=staged,
        has_unstaged=has_unstaged,
        in_compare_scope=in_compare_scope,
        hunks=hunks,
        unified=unified,
    )


def file_stage_flags(repo: Path, path: str) -> tuple[bool, bool]:
    path = normalize_repo_path(path)
    staged_res = _run_git(repo, "diff", "--cached", "--name-only", "--", path)
    staged = bool(staged_res.stdout.strip())
    unstaged_res = _run_git(repo, "diff", "--name-only", "--", path)
    has_unstaged = bool(unstaged_res.stdout.strip())
    status = _run_git(repo, "status", "--porcelain", "--", path)
    for line in status.stdout.splitlines():
        if len(line) < 2:
            continue
        x, y = line[0], line[1]
        if x == "?" and y == "?":
            has_unstaged = True
            continue
        if x != " " and x != "?":
            staged = True
        if y != " " and y != "?":
            has_unstaged = True
    return staged, has_unstaged


def stage_file(repo: Path, path: str) -> dict[str, bool]:
    path = normalize_repo_path(path)
    result = _run_git(repo, "add", "--", path)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git add failed")
    staged, has_unstaged = file_stage_flags(repo, path)
    return {"staged": staged, "has_unstaged": has_unstaged}


def unstage_file(repo: Path, path: str) -> dict[str, bool]:
    path = normalize_repo_path(path)
    result = _run_git(repo, "restore", "--staged", "--", path)
    if result.returncode != 0:
        result = _run_git(repo, "reset", "HEAD", "--", path)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git unstage failed")
    staged, has_unstaged = file_stage_flags(repo, path)
    return {"staged": staged, "has_unstaged": has_unstaged}


def _normalize_paths(paths: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for raw in paths:
        path = normalize_repo_path(raw)
        if not path or path in seen:
            continue
        seen.add(path)
        out.append(path)
    return out


def stage_files(repo: Path, paths: list[str]) -> dict[str, int | list[str]]:
    norm = _normalize_paths(paths)
    if not norm:
        return {"count": 0, "paths": []}
    result = _run_git(repo, "add", "--", *norm)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git add failed")
    return {"count": len(norm), "paths": norm}


def unstage_files(repo: Path, paths: list[str]) -> dict[str, int | list[str]]:
    norm = _normalize_paths(paths)
    if not norm:
        return {"count": 0, "paths": []}
    result = _run_git(repo, "restore", "--staged", "--", *norm)
    if result.returncode != 0:
        result = _run_git(repo, "reset", "HEAD", "--", *norm)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git unstage failed")
    return {"count": len(norm), "paths": norm}


def has_staged_changes(repo: Path) -> bool:
    result = _run_git(repo, "diff", "--cached", "--quiet")
    return result.returncode == 1


def list_changed_paths(repo: Path) -> list[dict[str, str | bool]]:
    """All paths from git status (not filtered by Scrutin ignore rules)."""
    status = _run_git(repo, "status", "--porcelain")
    paths: list[dict[str, str | bool]] = []
    for line in status.stdout.splitlines():
        if len(line) < 4:
            continue
        x, y = line[0], line[1]
        raw = line[3:].strip()
        if " -> " in raw:
            raw = raw.split(" -> ", 1)[1].strip()
        if x == "?" and y == "?":
            paths.append({"path": raw, "staged": False, "has_unstaged": True})
            continue
        paths.append(
            {
                "path": raw,
                "staged": x not in (" ", "?"),
                "has_unstaged": y not in (" ", "?"),
            }
        )
    return paths


def repo_has_merge_conflicts(repo: Path) -> bool:
    unmerged = _run_git(repo, "diff", "--name-only", "--diff-filter=U")
    if unmerged.stdout.strip():
        return True
    status = _run_git(repo, "status", "--porcelain")
    for line in status.stdout.splitlines():
        if len(line) >= 2 and ("U" in line[0] or "U" in line[1]):
            return True
    return False


def _ensure_no_merge_conflicts(repo: Path) -> None:
    if repo_has_merge_conflicts(repo):
        raise GitActionError(
            "merge_conflict",
            "Unresolved merge conflicts in this repository. Fix conflicts manually "
            "(edit files, then git add), then try again.",
        )


def git_identity(repo: Path) -> dict[str, str | bool]:
    name = _run_git(repo, "config", "--get", "user.name").stdout.strip()
    email = _run_git(repo, "config", "--get", "user.email").stdout.strip()
    configured = bool(name and email)
    return {"configured": configured, "name": name, "email": email}


def set_git_identity(repo: Path, name: str, email: str) -> dict[str, str | bool]:
    name = name.strip()
    email = email.strip()
    if not name or not email:
        raise RuntimeError("Name and email are required.")
    for key, value in (("user.name", name), ("user.email", email)):
        result = _run_git(repo, "config", key, value)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or f"git config {key} failed")
    return git_identity(repo)


def _ensure_git_identity(
    repo: Path,
    *,
    author_name: str | None = None,
    author_email: str | None = None,
) -> dict[str, str | bool]:
    if author_name and author_email:
        return set_git_identity(repo, author_name, author_email)
    identity = git_identity(repo)
    if not identity["configured"]:
        raise GitActionError(
            "identity_required",
            "Git needs your name and email before it can create commits.",
        )
    return identity


def current_branch(repo: Path) -> str:
    result = _run_git(repo, "rev-parse", "--abbrev-ref", "HEAD")
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not determine current branch")
    branch = result.stdout.strip()
    if branch == "HEAD":
        raise RuntimeError("Detached HEAD — checkout a branch before pushing.")
    return branch


def list_git_remotes(repo: Path) -> list[dict[str, str]]:
    names_out = _run_git(repo, "remote")
    names = [n.strip() for n in names_out.stdout.splitlines() if n.strip()]
    remotes: list[dict[str, str]] = []
    for name in names:
        url_out = _run_git(repo, "remote", "get-url", name)
        remotes.append(
            {
                "name": name,
                "url": url_out.stdout.strip() if url_out.returncode == 0 else "",
            }
        )
    return remotes


def resolve_push_remote(repo: Path, remote: str | None = None) -> str:
    remotes = list_git_remotes(repo)
    names = {r["name"] for r in remotes}
    if remote:
        name = remote.strip()
        if name not in names:
            available = ", ".join(sorted(names)) or "(none)"
            raise GitActionError(
                "no_remote",
                f"Remote `{name}` is not configured. Available remotes: {available}.",
            )
        return name
    if not remotes:
        branch = current_branch(repo)
        raise GitActionError(
            "no_remote",
            "This repository has no git remote, so Scrutin cannot push.\n\n"
            "In your repository folder, run:\n"
            "  git remote add origin <your-repo-url>\n"
            f"  git push -u origin {branch}\n\n"
            "Replace `<your-repo-url>` with your GitHub/GitLab SSH or HTTPS URL.",
        )
    for preferred in ("origin", "upstream"):
        if preferred in names:
            return preferred
    return remotes[0]["name"]


def push_status(repo: Path) -> dict[str, str | int | bool]:
    branch = current_branch(repo)
    upstream_ref = _run_git(repo, "rev-parse", "--abbrev-ref", "@{u}")
    has_upstream = upstream_ref.returncode == 0
    upstream = upstream_ref.stdout.strip() if has_upstream else ""
    ahead = 0
    behind = 0
    if has_upstream:
        counts = _run_git(repo, "rev-list", "--left-right", "--count", f"{upstream}...HEAD")
        if counts.returncode == 0 and counts.stdout.strip():
            parts = counts.stdout.strip().split()
            if len(parts) == 2:
                behind, ahead = int(parts[0]), int(parts[1])
    else:
        count = _run_git(repo, "rev-list", "--count", "HEAD")
        ahead = int(count.stdout.strip()) if count.returncode == 0 and count.stdout.strip() else 0
    remotes = list_git_remotes(repo)
    remote_names = [r["name"] for r in remotes]
    default_remote = ""
    if remote_names:
        for preferred in ("origin", "upstream"):
            if preferred in remote_names:
                default_remote = preferred
                break
        if not default_remote:
            default_remote = remote_names[0]
    can_push = ahead > 0 and (has_upstream or bool(remote_names))
    return {
        "branch": branch,
        "has_upstream": has_upstream,
        "upstream": upstream,
        "ahead": ahead,
        "behind": behind,
        "can_push": can_push,
        "needs_pull": behind > 0,
        "remotes": remote_names,
        "default_remote": default_remote,
        "has_remote": bool(remote_names),
    }


def _parse_push_failure(stderr: str, stdout: str) -> GitActionError:
    text = f"{stderr}\n{stdout}".lower()
    if "non-fast-forward" in text or "rejected" in text and "fetch first" in text:
        return GitActionError(
            "push_rejected",
            "Push was rejected because the remote has commits you do not have. "
            "Pull or rebase locally, resolve any conflicts manually, then push again.",
            stderr=stderr.strip(),
        )
    if "authentication failed" in text or "permission denied" in text or "403" in text:
        return GitActionError(
            "auth_failed",
            "Push failed — check your credentials and access to the remote repository.",
            stderr=stderr.strip(),
        )
    if "could not read from remote" in text:
        return GitActionError(
            "remote_unreachable",
            "Could not reach the remote. Check your network and remote URL.",
            stderr=stderr.strip(),
        )
    return GitActionError("push_failed", stderr.strip() or stdout.strip() or "git push failed")


def push_repo(
    repo: Path,
    *,
    set_upstream: bool = True,
    remote: str | None = None,
) -> dict[str, str | bool]:
    _ensure_no_merge_conflicts(repo)
    status = push_status(repo)
    branch = str(status["branch"])
    if status["needs_pull"] and status["has_upstream"]:
        raise GitActionError(
            "push_rejected",
            f"Branch `{branch}` is behind `{status['upstream']}`. "
            "Pull and resolve any conflicts manually, then push again.",
            behind=int(status["behind"]),
        )
    if not status["has_remote"] and not status["has_upstream"]:
        resolve_push_remote(repo, remote)  # raises no_remote with setup instructions
    if not status["can_push"] and status["has_upstream"]:
        raise GitActionError("nothing_to_push", "No local commits to push — already up to date with remote.")
    if status["has_upstream"]:
        result = _run_git(repo, "push")
        upstream = str(status.get("upstream") or "")
        remote_name = upstream.split("/", 1)[0] if "/" in upstream else ""
    elif set_upstream:
        remote_name = resolve_push_remote(repo, remote)
        result = _run_git(repo, "push", "-u", remote_name, branch)
    else:
        raise GitActionError(
            "no_upstream",
            f"Branch `{branch}` has no upstream. Push with upstream set, or configure tracking.",
        )
    if result.returncode != 0:
        raise _parse_push_failure(result.stderr, result.stdout)
    upstream_after = push_status(repo)
    return {
        "ok": True,
        "branch": branch,
        "remote": remote_name,
        "upstream": str(upstream_after.get("upstream") or f"{remote_name}/{branch}"),
        "output": (result.stdout or result.stderr).strip(),
    }


def git_workspace_status(repo: Path) -> dict:
    conflicts = repo_has_merge_conflicts(repo)
    identity = git_identity(repo)
    push = push_status(repo)
    remotes = list_git_remotes(repo)
    return {
        "has_staged": has_staged_changes(repo),
        "identity": identity,
        "has_merge_conflicts": conflicts,
        "push": push,
        "remotes": remotes,
        "can_commit": has_staged_changes(repo) and not conflicts,
        "can_push": bool(push["can_push"]) and not conflicts,
    }


def commit_repo(
    repo: Path,
    message: str,
    *,
    author_name: str | None = None,
    author_email: str | None = None,
) -> dict[str, str | bool]:
    message = message.strip()
    if not message:
        raise RuntimeError("Commit message cannot be empty.")
    _ensure_no_merge_conflicts(repo)
    _ensure_git_identity(repo, author_name=author_name, author_email=author_email)
    if not has_staged_changes(repo):
        raise RuntimeError("Nothing staged — stage files before committing.")
    parts = message.split("\n", 1)
    subject = parts[0].strip()
    if len(parts) > 1 and parts[1].strip():
        result = _run_git(repo, "commit", "-m", subject, "-m", parts[1].strip())
    else:
        result = _run_git(repo, "commit", "-m", subject)
    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "unable to auto-detect email address" in stderr or "Please tell me who you are" in stderr:
            raise GitActionError(
                "identity_required",
                "Git needs your name and email before it can create commits.",
            )
        raise RuntimeError(stderr or "git commit failed")
    sha = _run_git(repo, "rev-parse", "--short", "HEAD")
    return {
        "ok": True,
        "sha": sha.stdout.strip() if sha.returncode == 0 else "",
        "output": result.stdout.strip(),
    }


def commit_and_push_repo(
    repo: Path,
    message: str,
    *,
    author_name: str | None = None,
    author_email: str | None = None,
    set_upstream: bool = True,
    remote: str | None = None,
) -> dict:
    commit_result = commit_repo(
        repo,
        message,
        author_name=author_name,
        author_email=author_email,
    )
    push_result = push_repo(repo, set_upstream=set_upstream, remote=remote)
    return {"commit": commit_result, "push": push_result}


GIT_SUBJECT_MAX = 72

_REASON_TO_THEME: list[tuple[str, str]] = [
    ("database migration", "database migrations"),
    ("authentication / secrets", "authentication and secrets"),
    ("configuration surface", "configuration and environment"),
    ("public API surface", "API behavior"),
    ("event streaming", "event streaming"),
    ("deploy / runtime", "deployment and runtime"),
    ("CI/CD pipeline", "CI/CD"),
    ("money path", "billing and payments"),
    ("large change set", "substantial logic changes"),
]


def _first_subject_candidate(candidates: list[str]) -> str:
    for text in candidates:
        cleaned = " ".join(text.split())
        if len(cleaned) <= GIT_SUBJECT_MAX:
            return cleaned
    return " ".join(candidates[-1].split())


def _commit_prefix(files: list[FileChange]) -> str:
    paths = " ".join(f.path.lower() for f in files)
    if any("configuration surface" in f.risk_reasons for f in files):
        return "chore: "
    if sum(1 for f in files if "/tests/" in f.path.replace("\\", "/") or f.path.startswith("tests/")) >= max(
        1, len(files) // 2
    ):
        return "test: "
    if "readme" in paths or "/docs/" in paths:
        return "docs: "
    return "feat: "


def _path_area_theme(path: str) -> str | None:
    lower = path.lower().replace("\\", "/")
    if "/extension/" in lower or lower.startswith("extension/"):
        return "editor extension"
    if "/static/" in lower or "webview" in lower:
        return "review UI"
    if "cli.py" in lower or "/cli." in lower:
        return "CLI workflow"
    if "routes_" in lower or "/api" in lower or "app.py" in lower:
        return "server and API layer"
    if "git_" in lower or "diff_parser" in lower:
        return "git diff and staging"
    if "brief_" in lower or "llm" in lower:
        return "review brief generation"
    if "/tests/" in lower or lower.startswith("tests/"):
        return "test coverage"
    if ".github/" in lower:
        return "GitHub integration"
    return None


def _collect_functional_themes(files: list[FileChange]) -> list[str]:
    themes: list[str] = []
    seen: set[str] = set()

    def add(theme: str) -> None:
        key = theme.lower()
        if key not in seen:
            seen.add(key)
            themes.append(theme)

    reasons: set[str] = set()
    for f in files:
        reasons.update(f.risk_reasons)
    for reason, label in _REASON_TO_THEME:
        if reason in reasons:
            add(label)

    for f in files:
        area = _path_area_theme(f.path)
        if area:
            add(area)

    if not themes:
        statuses = {f.status for f in files}
        if statuses == {"added"}:
            add("new capabilities")
        elif statuses == {"deleted"}:
            add("removal of unused code")
        elif "added" in statuses:
            add("feature additions and updates")
        else:
            add("application improvements")

    return themes


def _join_themes(themes: list[str]) -> str:
    if not themes:
        return "application improvements"
    if len(themes) == 1:
        return themes[0]
    if len(themes) == 2:
        return f"{themes[0]} and {themes[1]}"
    return f"{themes[0]}, {themes[1]}, and {themes[2]}"


def _compose_subject(focus: list[FileChange]) -> str:
    if not focus:
        return "chore: update repository"

    prefix = _commit_prefix(focus)
    themes = _collect_functional_themes(focus)
    joined = _join_themes(themes)
    n = len(focus)

    return _first_subject_candidate(
        [
            f"{prefix}improve {joined}",
            f"{prefix}refine {joined}",
            f"{prefix}update {joined}",
            f"{prefix}changes across {n} functional areas" if n > 1 else f"{prefix}{joined}",
        ]
    )


def _risk_area_hint(areas: set[str]) -> str:
    if "database migration" in areas:
        return "Includes schema/migration changes."
    if "authentication / secrets" in areas:
        return "Touches auth or secrets; verify carefully."
    if "configuration surface" in areas:
        return "Updates configuration."
    if "public API surface" in areas:
        return "API surface changes."
    return ""


def _summary_for_body(summary: str) -> str:
    text = summary.replace("**", "").strip()
    if not text:
        return ""
    parts = re.split(r"(?<=[.!?])\s+", text)
    sentences = [p.strip() for p in parts if p.strip()]
    if not sentences:
        return text
    if len(sentences) == 1:
        return sentences[0]
    two = f"{sentences[0]} {sentences[1]}"
    if len(two) <= 360:
        return two
    return sentences[0]


def _functional_body_lines(files: list[FileChange]) -> list[str]:
    lines: list[str] = []
    themes = _collect_functional_themes(files)
    for theme in themes[:5]:
        lines.append(f"- {theme[0].upper()}{theme[1:]}")
    adds = sum(f.additions for f in files)
    dels = sum(f.deletions for f in files)
    if adds or dels:
        lines.append(f"- Net diff: +{adds} / -{dels} lines across {len(files)} file(s)")
    return lines


def _strip_path_refs_from_summary(summary: str) -> str:
    text = summary.replace("**", "").strip()
    text = re.sub(r"`[^`]+`", "the codebase", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _compose_body(
    files: list[FileChange],
    *,
    area_hint: str,
    brief_summary: str | None,
) -> str:
    parts: list[str] = []
    functional = _functional_body_lines(files)
    if functional:
        parts.append("Changes:\n" + "\n".join(functional))
    elif area_hint:
        parts.append(area_hint)
    if brief_summary:
        snippet = _summary_for_body(_strip_path_refs_from_summary(brief_summary))
        if snippet:
            parts.append(snippet)
    return "\n\n".join(parts)


def suggest_commit_message(
    files: list[FileChange],
    *,
    brief_summary: str | None = None,
) -> CommitSuggestResponse:
    if not files:
        return CommitSuggestResponse(message="chore: update repository", subject="chore: update repository")

    risky = [f for f in files if f.is_risky]
    focus = risky if risky else files
    focus = sorted(focus, key=lambda f: f.additions + f.deletions, reverse=True)

    subject = _compose_subject(focus)
    areas: set[str] = set()
    for f in focus:
        areas.update(f.risk_reasons)
    body = _compose_body(files, area_hint=_risk_area_hint(areas), brief_summary=brief_summary)
    message = subject if not body else f"{subject}\n\n{body}"

    return CommitSuggestResponse(message=message, subject=subject, body=body)
