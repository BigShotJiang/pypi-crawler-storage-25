from __future__ import annotations

import os
import re
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field

from scrutin.config import reload_settings
from scrutin.llm_providers import PROVIDER_ORDER, PROVIDERS, provider_list

_ENV_LINE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)=(.*)$")


def mask_secret(value: str) -> str:
    v = (value or "").strip()
    if len(v) <= 8:
        return "••••" if v else ""
    return f"{v[:4]}…{v[-4:]}"


def resolve_env_path(repo: str | None = None) -> Path:
    explicit = (os.getenv("SCRUTIN_ENV") or os.getenv("REVIEWPACK_ENV") or "").strip()
    if explicit:
        return Path(explicit).expanduser()
    if repo:
        return Path(repo).expanduser().resolve() / ".env"
    for home in (Path.home() / ".scrutin" / ".env", Path.home() / ".reviewpack" / ".env"):
        if home.is_file():
            return home
    return Path.cwd() / ".env"


def read_env_file(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _ENV_LINE.match(line)
        if not m:
            continue
        key, raw = m.group(1), m.group(2)
        if raw.startswith('"') and raw.endswith('"'):
            raw = raw[1:-1].replace("\\n", "\n")
        elif raw.startswith("'") and raw.endswith("'"):
            raw = raw[1:-1]
        out[key] = raw
    return out


def write_env_file(path: Path, updates: dict[str, str], *, remove_keys: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = read_env_file(path) if path.is_file() else {}
    for key in remove_keys or []:
        existing.pop(key, None)
    existing.update(updates)
    lines = [
        "# Scrutin — local settings (API keys stay on your machine)",
        "",
    ]
    groups = [
        ("LLM provider", ["SCRUTIN_LLM_PROVIDER"]),
        ("OpenAI", ["OPENAI_API_KEY", "OPENAI_MODEL"]),
        ("Anthropic", ["ANTHROPIC_API_KEY", "ANTHROPIC_MODEL"]),
        ("Google Gemini", ["GOOGLE_API_KEY", "GOOGLE_MODEL"]),
        ("Groq", ["GROQ_API_KEY", "GROQ_MODEL"]),
        ("Mistral", ["MISTRAL_API_KEY", "MISTRAL_MODEL"]),
    ]
    written: set[str] = set()
    for title, keys in groups:
        chunk = [k for k in keys if k in existing]
        if not chunk:
            continue
        lines.append(f"# {title}")
        for k in chunk:
            val = existing[k]
            if "KEY" in k and val:
                lines.append(f'{k}="{val}"')
            else:
                lines.append(f"{k}={val}")
            written.add(k)
        lines.append("")
    for k, v in sorted(existing.items()):
        if k in written:
            continue
        lines.append(f"{k}={v}")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def _key_set(env_name: str) -> bool:
    return bool(os.getenv(env_name, "").strip())


def resolve_active_provider() -> str | None:
    preferred = os.getenv("SCRUTIN_LLM_PROVIDER", "").strip().lower()
    if preferred == "none":
        return None
    if preferred in PROVIDERS:
        return preferred if _key_set(PROVIDERS[preferred].api_key_env) else None
    for pid in PROVIDER_ORDER:
        if _key_set(PROVIDERS[pid].api_key_env):
            return pid
    return None


def active_model(provider_id: str) -> str:
    spec = PROVIDERS[provider_id]
    return os.getenv(spec.model_env, spec.default_model).strip() or spec.default_model


def apply_env_to_process(env_path: Path) -> None:
    load_dotenv(env_path, override=True)
    reload_settings()


class LlmSettingsUpdate(BaseModel):
    provider: str = Field(description="openai | anthropic | google | groq | mistral | none")
    model: str | None = None
    api_key: str | None = Field(
        default=None,
        description="New API key; empty string clears; omit to leave unchanged",
    )


class LlmSettingsPublic(BaseModel):
    env_file: str
    provider: str
    model: str
    api_key_set: bool
    api_key_hint: str
    brief_mode: str
    providers: list[dict[str, str]]
    keys_configured: dict[str, bool]


def get_public_settings(repo: str | None = None) -> LlmSettingsPublic:
    env_path = resolve_env_path(repo)
    apply_env_to_process(env_path)

    active = resolve_active_provider()
    provider = active or "none"
    model = active_model(active) if active else ""
    spec = PROVIDERS[active] if active else None
    key_val = os.getenv(spec.api_key_env, "") if spec else ""

    keys_configured = {
        pid: _key_set(PROVIDERS[pid].api_key_env) for pid in PROVIDER_ORDER
    }

    return LlmSettingsPublic(
        env_file=str(env_path.resolve()),
        provider=provider,
        model=model,
        api_key_set=bool(key_val),
        api_key_hint=mask_secret(key_val),
        brief_mode="llm" if active else "sharpen",
        providers=provider_list(),
        keys_configured=keys_configured,
    )


def save_settings(repo: str | None, body: LlmSettingsUpdate) -> LlmSettingsPublic:
    if body.provider not in (*PROVIDER_ORDER, "none"):
        raise ValueError(f"Invalid provider {body.provider!r}")

    env_path = resolve_env_path(repo)
    env_path.parent.mkdir(parents=True, exist_ok=True)
    updates: dict[str, str] = {"SCRUTIN_LLM_PROVIDER": body.provider}
    remove_keys: list[str] = []

    if body.provider == "none":
        for pid in PROVIDER_ORDER:
            remove_keys.append(PROVIDERS[pid].api_key_env)
        updates["SCRUTIN_LLM_PROVIDER"] = "none"
    else:
        spec = PROVIDERS[body.provider]
        if body.model is not None and body.model.strip():
            updates[spec.model_env] = body.model.strip()
        elif body.model is not None and not body.model.strip():
            # Explicit empty model → reset to provider default
            updates[spec.model_env] = spec.default_model
        if body.api_key is not None:
            if body.api_key.strip():
                updates[spec.api_key_env] = body.api_key.strip()
            else:
                remove_keys.append(spec.api_key_env)

    write_env_file(env_path, updates, remove_keys=remove_keys)
    apply_env_to_process(env_path)
    return get_public_settings(repo)
