from __future__ import annotations

from typing import Literal

from scrutin.llm import maybe_enhance_brief
from scrutin.diff_parser import dedupe_file_changes
from scrutin.models import ASK_YOURSELF_COUNT, BriefRequest, FileChange, ReviewBrief

BriefAudience = Literal["precommit", "pr"]

_COMPARE_SCOPE: dict[str, str] = {
    "working": "staged and unstaged changes vs HEAD",
    "staged": "staged changes (index vs HEAD)",
    "unstaged": "unstaged changes (working tree vs index)",
    "branch": "commits on your branch since the base branch",
}

_SELF_CHECK_PAD = [
    "Can I explain why this change is needed in one sentence?",
    "Did I run the smallest check that proves this works?",
    "Are migrations, feature flags, or rollbacks documented and tested?",
    "Did I avoid unrelated edits that dilute review focus?",
    "Would I approve this diff if I were reviewing it cold?",
]


_SCRUTINIZE_PRIORITY_REASONS = frozenset(
    {
        "configuration surface",
        "authentication / secrets",
        "database migration",
    }
)


def _files_to_scrutinize(files: list[FileChange], *, limit: int = 12) -> list[FileChange]:
    """Risky files for the review list; always surface config/secrets/migrations."""
    risky = [f for f in files if f.is_risky]
    priority = [
        f
        for f in risky
        if _SCRUTINIZE_PRIORITY_REASONS.intersection(f.risk_reasons)
    ]
    priority.sort(key=lambda f: f.additions + f.deletions, reverse=True)
    rest = sorted(
        [f for f in risky if f not in priority],
        key=lambda f: f.additions + f.deletions,
        reverse=True,
    )
    ordered: list[FileChange] = []
    seen: set[str] = set()
    for f in priority + rest:
        if f.path in seen:
            continue
        seen.add(f.path)
        ordered.append(f)
        if len(ordered) >= limit:
            break
    if ordered:
        return ordered
    return sorted(files, key=lambda f: f.additions + f.deletions, reverse=True)[:limit]


def _stats(files: list[FileChange]) -> dict[str, int | str]:
    return {
        "files_changed": len(files),
        "additions": sum(f.additions for f in files),
        "deletions": sum(f.deletions for f in files),
        "risky_files": sum(1 for f in files if f.is_risky),
    }


def _heuristic_summary_pr(files: list[FileChange], commits: list[str]) -> str:
    risky = [f for f in files if f.is_risky]
    top = sorted(files, key=lambda f: f.additions + f.deletions, reverse=True)[:5]
    parts = [
        f"This change touches **{len(files)}** files "
        f"(+{sum(f.additions for f in files)} / -{sum(f.deletions for f in files)} lines)."
    ]
    if risky:
        parts.append(
            f"**{len(risky)}** files hit elevated-risk paths ({', '.join(sorted({r for f in risky for r in f.risk_reasons})[:4])})."
        )
    if top:
        parts.append("Largest diffs: " + ", ".join(f"`{f.path}`" for f in top[:3]) + ".")
    if commits:
        parts.append(f"**{len(commits)}** commits on the branch.")
    return " ".join(parts)


def _heuristic_summary_precommit(
    files: list[FileChange],
    commits: list[str],
    *,
    mode: str,
    meta: BriefRequest,
) -> str:
    risky = [f for f in files if f.is_risky]
    top = sorted(files, key=lambda f: f.additions + f.deletions, reverse=True)[:5]
    adds = sum(f.additions for f in files)
    dels = sum(f.deletions for f in files)
    scope = _COMPARE_SCOPE.get(mode, mode)

    parts = [
        f"**{len(files)}** file(s) in your current scope ({scope}) "
        f"with **+{adds}** / **-{dels}** lines — review this before you commit."
    ]
    if risky:
        tags = ", ".join(sorted({r for f in risky for r in f.risk_reasons})[:4])
        parts.append(f"**{len(risky)}** file(s) need extra care ({tags}).")
    if top:
        parts.append("Biggest edits: " + ", ".join(f"`{f.path}`" for f in top[:3]) + ".")
    if mode == "branch" and commits:
        base = meta.base_branch or "base"
        parts.append(f"**{len(commits)}** commit(s) since `{base}`.")
    elif commits and mode != "branch":
        parts.append(f"Current HEAD: `{commits[0]}`.")
    return " ".join(parts)


def _heuristic_why_precommit(files: list[FileChange], meta: BriefRequest, mode: str) -> str:
    if meta.description and meta.description.strip():
        return meta.description.strip()
    if meta.ticket_url:
        return (
            f"Linked work: {meta.ticket_url}. "
            "Confirm your diff matches that scope before you write the commit message."
        )

    risky = [f for f in files if f.is_risky]
    risk_labels = sorted({r for f in risky for r in f.risk_reasons})
    top = sorted(files, key=lambda f: f.additions + f.deletions, reverse=True)[:3]

    if risk_labels:
        focus = ", ".join(risk_labels[:3])
        paths = ", ".join(f"`{f.path}`" for f in top)
        return (
            f"You are preparing to commit changes that touch **{focus}** "
            f"(including {paths}). "
            "Use the risk areas and self-checks below to make sure behavior, secrets, and rollback are intentional."
        )

    if len(files) <= 3:
        paths = ", ".join(f"`{f.path}`" for f in files)
        return (
            f"Focused edit across {paths}. "
            "State the intent clearly in your commit message — no ticket or description was supplied."
        )

    scope = _COMPARE_SCOPE.get(mode, mode)
    return (
        f"No ticket or description was provided for this {scope}. "
        "Explain **why** each file belongs in the next commit and drop anything unrelated."
    )


def _heuristic_why_pr(meta: BriefRequest) -> str:
    if meta.description and meta.description.strip():
        return meta.description.strip()
    if meta.ticket_url:
        return f"Linked work: {meta.ticket_url}"
    return "Add a ticket link or PR description so reviewers understand intent."


def _author_questions(files: list[FileChange], meta: BriefRequest) -> list[str]:
    """Source prompts for Ask Yourself (former ask-author heuristics)."""
    qs: list[str] = []
    if any("database migration" in f.risk_reasons for f in files):
        qs.append("Is there a backward-compatible migration path and estimated lock time?")
    if any("authentication / secrets" in f.risk_reasons for f in files):
        qs.append("Were secrets rotated and old tokens invalidated if models changed?")
    if any("event streaming" in f.risk_reasons for f in files):
        qs.append("Do consumers need a replay or dual-write period for schema/topic changes?")
    if meta.ticket_url:
        qs.append(f"Does this fully satisfy the scope in {meta.ticket_url}?")
    else:
        qs.append("What ticket or doc link explains why this change is needed?")
    if sum(f.additions + f.deletions for f in files) > 500:
        qs.append("Can this be split into smaller commits to reduce risk and ease rollback?")
    return qs


def _ask_yourself(files: list[FileChange], meta: BriefRequest) -> list[str]:
    """Exactly five self-check questions for the committer."""
    merged: list[str] = []
    seen: set[str] = set()
    for q in _author_questions(files, meta) + _SELF_CHECK_PAD:
        key = q.strip()
        if not key or key in seen:
            continue
        seen.add(key)
        merged.append(key)
        if len(merged) >= ASK_YOURSELF_COUNT:
            break
    return merged[:ASK_YOURSELF_COUNT]


def build_brief(
    files: list[FileChange],
    *,
    meta: BriefRequest | None = None,
    commits: list[str] | None = None,
    mode: str = "working",
    audience: BriefAudience = "precommit",
) -> ReviewBrief:
    meta = meta or BriefRequest()
    commits = commits or []
    files = dedupe_file_changes(files)
    is_pr = audience == "pr"
    risky_sorted = _files_to_scrutinize(files)

    risk_labels = sorted({r for f in files for r in f.risk_reasons})
    risk_areas = risk_labels if risk_labels else ["No automatic risk tags — manual review advised."]

    checkpoints = _ask_yourself(files, meta)

    if is_pr:
        summary = _heuristic_summary_pr(files, commits)
        why = _heuristic_why_pr(meta)
        rollback = (
            "Revert the merge commit or redeploy the previous image/tag. "
            "If migrations ran, confirm downgrade script exists before merging."
        )
        default_title = "Pull request review brief"
    else:
        summary = _heuristic_summary_precommit(files, commits, mode=mode, meta=meta)
        why = _heuristic_why_precommit(files, meta, mode)
        rollback = (
            "Before commit: discard with `git restore` (unstaged) or `git restore --staged` (index). "
            "After commit: `git revert` the commit or reset the branch. "
            "If migrations ran locally, verify a downgrade path before pushing."
        )
        default_title = "Pre-commit change brief"

    brief = ReviewBrief(
        title=meta.title or default_title,
        summary=summary,
        why=why,
        risk_areas=risk_areas,
        all_changed_files=files,
        files_to_scrutinize=risky_sorted,
        ask_yourself=checkpoints,
        suggested_tests=[],
        questions_for_author=list(checkpoints),
        rollback_notes=rollback,
        stats={**_stats(files), "brief_mode": "sharpen", "llm_provider": ""},
        generated_with_llm=False,
    )
    return maybe_enhance_brief(
        brief, files=files, commits=commits, meta=meta, mode=mode, audience=audience
    )


def brief_to_markdown(brief: ReviewBrief) -> str:
    checkpoints = brief.ask_yourself or brief.questions_for_author
    lines = [
        f"# {brief.title}",
        "",
        "## Summary",
        brief.summary,
        "",
        "## Why",
        brief.why,
        "",
        "## Risk areas",
        *[f"- {r}" for r in brief.risk_areas],
        "",
        "## Files worth extra care",
    ]
    if brief.files_to_scrutinize:
        for f in brief.files_to_scrutinize:
            flags = ", ".join(f.risk_reasons) if f.risk_reasons else "large diff"
            lines.append(
                f"- `{f.path}` ({f.status}, +{f.additions}/-{f.deletions}) — {flags}"
            )
    else:
        lines.append("- None flagged automatically.")

    lines.extend(["", "## Ask yourself", *[f"- {q}" for q in checkpoints]])
    lines.extend(
        [
            "",
            "## Rollback",
            brief.rollback_notes,
            "",
            "---",
            f"*Stats: {brief.stats} · LLM enhanced: {brief.generated_with_llm}*",
        ]
    )
    return "\n".join(lines)
