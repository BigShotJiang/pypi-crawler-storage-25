from __future__ import annotations

import re
import subprocess
from pathlib import Path

from scrutin.models import FileChange
from scrutin.path_ignore import load_ignore_patterns, should_ignore_path

DIFF_FILE_RE = re.compile(r"^diff --git a/(.*) b/(.*)")
HUNK_RE = re.compile(r"^@@ .* \+(\d+)(?:,(\d+))? -(\d+)(?:,(\d+))?")

RISK_PATTERNS: list[tuple[str, str]] = [
    (r"(auth|security|oauth|jwt|password|credential|secret)", "authentication / secrets"),
    (r"(migration|schema|flyway|liquibase|alembic)", "database migration"),
    (r"(kafka|topic|consumer|producer)", "event streaming"),
    (r"(\.env|config|settings)", "configuration surface"),
    (r"(Dockerfile|docker-compose|helm|k8s|kubernetes)", "deploy / runtime"),
    (r"(api/|controller|route|endpoint|openapi)", "public API surface"),
    (r"(payment|billing|ledger|transaction)", "money path"),
    (r"(\.github/workflows|Jenkinsfile|gitlab-ci)", "CI/CD pipeline"),
]


def _match_risks(path: str) -> list[str]:
    reasons: list[str] = []
    lower = path.lower()
    for pattern, label in RISK_PATTERNS:
        if re.search(pattern, lower):
            reasons.append(label)
    return list(dict.fromkeys(reasons))


def _file_change_from_totals(path: str, status: str, additions: int, deletions: int) -> FileChange:
    reasons = _match_risks(path)
    return FileChange(
        path=path,
        status=status,
        additions=additions,
        deletions=deletions,
        is_risky=bool(reasons) or additions + deletions > 200,
        risk_reasons=reasons
        + (["large change set"] if additions + deletions > 200 and not reasons else []),
    )


def _merge_status(a: str, b: str) -> str:
    priority = {"deleted": 4, "added": 3, "modified": 2, "renamed": 1}
    return a if priority.get(a, 0) >= priority.get(b, 0) else b


def dedupe_file_changes(files: list[FileChange]) -> list[FileChange]:
    """Merge multiple diff hunks for the same path (e.g. staged + unstaged concatenated)."""
    by_path: dict[str, FileChange] = {}
    order: list[str] = []
    for f in files:
        if f.path in by_path:
            prev = by_path[f.path]
            by_path[f.path] = _file_change_from_totals(
                f.path,
                _merge_status(prev.status, f.status),
                prev.additions + f.additions,
                prev.deletions + f.deletions,
            )
        else:
            order.append(f.path)
            by_path[f.path] = f
    return [by_path[p] for p in order]


def parse_unified_diff(
    text: str,
    *,
    repo: Path | None = None,
) -> tuple[list[FileChange], int]:
    """Parse unified diff; return (files, ignored_file_count)."""
    ignore_patterns = load_ignore_patterns(repo)
    files: list[FileChange] = []
    ignored_count = 0
    current_path: str | None = None
    additions = 0
    deletions = 0
    status = "modified"

    def flush() -> None:
        nonlocal current_path, additions, deletions, status, ignored_count
        if not current_path:
            return
        if should_ignore_path(current_path, ignore_patterns):
            ignored_count += 1
            current_path = None
            additions = 0
            deletions = 0
            status = "modified"
            return
        files.append(_file_change_from_totals(current_path, status, additions, deletions))
        current_path = None
        additions = 0
        deletions = 0
        status = "modified"

    for line in text.splitlines():
        m = DIFF_FILE_RE.match(line)
        if m:
            flush()
            old_path, new_path = m.group(1), m.group(2)
            if old_path == "/dev/null":
                status = "added"
                current_path = new_path
            elif new_path == "/dev/null":
                status = "deleted"
                current_path = old_path
            else:
                status = "modified"
                current_path = new_path
            continue

        if line.startswith(("+++", "---")):
            continue
        if line.startswith("+") and not line.startswith("+++"):
            additions += 1
        elif line.startswith("-") and not line.startswith("---"):
            deletions += 1

    flush()
    return dedupe_file_changes(files), ignored_count


def extract_file_unified_diff(full_unified: str, path: str) -> str:
    """Pull one file's diff sections from a multi-file unified diff (matches brief scope)."""
    from scrutin.path_ignore import normalize_repo_path

    target = normalize_repo_path(path)
    blocks: list[str] = []
    current: list[str] | None = None

    for line in full_unified.splitlines():
        m = DIFF_FILE_RE.match(line)
        if m:
            if current is not None:
                blocks.append("\n".join(current))
            old_path, new_path = m.group(1), m.group(2)
            file_path = new_path if new_path != "/dev/null" else old_path
            current = [line] if normalize_repo_path(file_path) == target else None
            continue
        if current is not None:
            current.append(line)

    if current is not None:
        blocks.append("\n".join(current))
    return "\n\n".join(blocks)


DiffMode = str  # working | staged | unstaged | branch


def repo_has_commits(repo: Path) -> bool:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "HEAD"],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.returncode == 0


def git_diff_untracked(repo: Path) -> str:
    """Unified diff for untracked files (not yet in git diff HEAD / --cached)."""
    repo = repo.resolve()
    ignore_patterns = load_ignore_patterns(repo)
    result = subprocess.run(
        ["git", "-C", str(repo), "ls-files", "--others", "--exclude-standard"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return ""
    parts: list[str] = []
    for rel in result.stdout.splitlines():
        rel = rel.strip().replace("\\", "/")
        if not rel or should_ignore_path(rel, ignore_patterns):
            continue
        diff = subprocess.run(
            ["git", "-C", str(repo), "diff", "--no-index", "--", "/dev/null", rel],
            capture_output=True,
            text=True,
            check=False,
        )
        if diff.stdout.strip():
            parts.append(diff.stdout)
    return "\n".join(parts)


def git_diff_working(repo: Path) -> str:
    """Staged + unstaged changes vs last commit, plus untracked files (pre-commit view)."""
    repo = repo.resolve()
    parts: list[str] = []
    if not repo_has_commits(repo):
        staged = git_diff_staged(repo)
        unstaged = git_diff_unstaged(repo)
        parts = [p for p in (staged, unstaged) if p.strip()]
    else:
        result = subprocess.run(
            ["git", "-C", str(repo), "diff", "HEAD"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.stdout.strip():
            parts.append(result.stdout)
        elif result.returncode not in (0, 1):
            raise RuntimeError(result.stderr.strip() or "git diff HEAD failed")

    untracked = git_diff_untracked(repo)
    if untracked.strip():
        parts.append(untracked)
    return "\n".join(parts)


def git_diff_staged(repo: Path) -> str:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "diff", "--cached"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git diff --cached failed")
    return result.stdout


def git_diff_unstaged(repo: Path) -> str:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "diff"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git diff failed")
    return result.stdout


def git_diff_for_mode(repo: Path, mode: str, base: str, head: str) -> str:
    if mode == "branch" and not repo_has_commits(repo):
        raise RuntimeError(
            "Branch compare needs at least one commit. "
            "Use --mode working (default) for a new repository, or run: git commit -m 'initial'"
        )
    if mode == "working":
        return git_diff_working(repo)
    if mode == "staged":
        return git_diff_staged(repo)
    if mode == "unstaged":
        return git_diff_unstaged(repo)
    if mode == "branch":
        return git_diff(repo, base, head)
    raise RuntimeError(f"Unknown diff mode: {mode}. Use working, staged, unstaged, or branch.")


def git_status_short(repo: Path) -> dict[str, int | bool]:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "status", "--porcelain"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return {"has_changes": False, "staged": 0, "unstaged": 0, "total": 0}
    staged = unstaged = untracked = 0
    for line in result.stdout.splitlines():
        if len(line) < 3:
            continue
        x, y = line[0], line[1]
        if x == "?" and y == "?":
            untracked += 1
            continue
        if x != " ":
            staged += 1
        if y != " ":
            unstaged += 1
    total = len([ln for ln in result.stdout.splitlines() if ln.strip()])
    return {
        "has_changes": total > 0,
        "staged": staged,
        "unstaged": unstaged,
        "untracked": untracked,
        "total": total,
    }


def git_diff(repo: Path, base: str, head: str) -> str:
    repo = repo.resolve()
    result = subprocess.run(
        ["git", "-C", str(repo), "diff", f"{base}...{head}"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "git diff failed")
    return result.stdout


def git_log_oneline(repo: Path, base: str, head: str, limit: int = 20) -> list[str]:
    result = subprocess.run(
        ["git", "-C", str(repo.resolve()), "log", f"{base}..{head}", "--oneline", f"-{limit}"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return []
    return [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
