from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from scrutin.diff_parser import dedupe_file_changes, git_diff_for_mode, parse_unified_diff
from scrutin.git_actions import (
    GitActionError,
    commit_and_push_repo,
    commit_repo,
    file_diff,
    git_identity,
    git_workspace_status,
    has_staged_changes,
    list_changed_paths,
    push_repo,
    set_git_identity,
    stage_file,
    stage_files,
    suggest_commit_message,
    unstage_file,
    unstage_files,
)
from scrutin.git_workspace import build_workspace_brief
router = APIRouter(prefix="/api/v1/workspace", tags=["workspace-git"])


class RepoPathBody(BaseModel):
    repo: str
    path: str


class RepoPathsBody(BaseModel):
    repo: str
    paths: list[str] = Field(default_factory=list)


class CommitBody(BaseModel):
    repo: str
    message: str = Field(..., min_length=1)
    author_name: str | None = None
    author_email: str | None = None
    remote: str | None = None


class GitIdentityBody(BaseModel):
    repo: str
    name: str = Field(..., min_length=1)
    email: str = Field(..., min_length=1)


class PushBody(BaseModel):
    repo: str
    set_upstream: bool = True
    remote: str | None = None


def _git_http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, GitActionError):
        detail: dict = {"code": exc.code, "message": str(exc)}
        detail.update(exc.extra)
        status = 409 if exc.code in ("merge_conflict", "push_rejected") else 400
        return HTTPException(status, detail)
    return HTTPException(400, str(exc))


@router.get("/file-diff")
def workspace_file_diff(
    repo: str = Query(...),
    path: str = Query(...),
    mode: str = Query("working"),
    base: str = Query("main"),
    head: str = Query("HEAD"),
) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    try:
        data = file_diff(root, path, mode, base, head)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e
    return data.model_dump()


@router.post("/stage")
def workspace_stage(body: RepoPathBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return stage_file(root, body.path)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/unstage")
def workspace_unstage(body: RepoPathBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return unstage_file(root, body.path)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/stage-files")
def workspace_stage_files(body: RepoPathsBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return stage_files(root, body.paths)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/unstage-files")
def workspace_unstage_files(body: RepoPathsBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return unstage_files(root, body.paths)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e


@router.get("/commit-ready")
def workspace_commit_ready(
    repo: str = Query(...),
) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    return {"has_staged": has_staged_changes(root)}


@router.get("/changed-paths")
def workspace_changed_paths(repo: str = Query(...)) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    paths = list_changed_paths(root)
    return {"paths": paths, "count": len(paths)}


@router.get("/git-status")
def workspace_git_status(repo: str = Query(...)) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    try:
        return git_workspace_status(root)
    except RuntimeError as e:
        raise _git_http_error(e) from e


@router.get("/git-identity")
def workspace_git_identity(repo: str = Query(...)) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    return git_identity(root)


@router.post("/git-identity")
def workspace_set_git_identity(body: GitIdentityBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return set_git_identity(root, body.name, body.email)
    except RuntimeError as e:
        raise _git_http_error(e) from e


@router.get("/commit-message")
def workspace_commit_message(
    repo: str = Query(...),
    mode: str = Query("working"),
    base: str = Query("main"),
    head: str = Query("HEAD"),
) -> dict:
    root = Path(repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {repo}")
    try:
        brief, _, _ = build_workspace_brief(root, base, head, mode=mode, use_gh=False)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e
    files = dedupe_file_changes(brief.all_changed_files or brief.files_to_scrutinize)
    if not files:
        diff = git_diff_for_mode(root, mode, base, head)
        files, _ = parse_unified_diff(diff, repo=root)
        files = dedupe_file_changes(files)
    suggestion = suggest_commit_message(files, brief_summary=brief.summary)
    return suggestion.model_dump()


@router.post("/commit")
def workspace_commit(body: CommitBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return commit_repo(
            root,
            body.message,
            author_name=body.author_name,
            author_email=body.author_email,
        )
    except (RuntimeError, GitActionError) as e:
        raise _git_http_error(e) from e


@router.post("/push")
def workspace_push(body: PushBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return push_repo(root, set_upstream=body.set_upstream, remote=body.remote)
    except (RuntimeError, GitActionError) as e:
        raise _git_http_error(e) from e


@router.post("/commit-and-push")
def workspace_commit_and_push(body: CommitBody) -> dict:
    root = Path(body.repo)
    if not root.is_dir():
        raise HTTPException(400, f"repo not found: {body.repo}")
    try:
        return commit_and_push_repo(
            root,
            body.message,
            author_name=body.author_name,
            author_email=body.author_email,
            remote=body.remote,
            set_upstream=True,
        )
    except (RuntimeError, GitActionError) as e:
        raise _git_http_error(e) from e
