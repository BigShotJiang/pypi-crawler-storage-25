from __future__ import annotations

import fnmatch
from pathlib import Path

# Built-in paths never useful in a pre-commit review brief
DEFAULT_IGNORE_PATTERNS: tuple[str, ...] = (
    ".venv",
    ".venv/*",
    "venv",
    "venv/*",
    "env/",
    "env/**",
    "__pycache__",
    "__pycache__/*",
    "**/__pycache__",
    "**/__pycache__/**",
    "*.pyc",
    "*.pyo",
    "*.egg-info",
    "*.egg-info/*",
    "**/*.egg-info/**",
    ".pytest_cache",
    ".pytest_cache/*",
    ".mypy_cache",
    ".mypy_cache/*",
    ".ruff_cache",
    ".ruff_cache/*",
    ".tox",
    ".tox/*",
    "node_modules",
    "node_modules/*",
    "**/node_modules/**",
    "dist",
    "dist/*",
    "build",
    "build/*",
    "target",
    "target/*",
    ".git",
    ".git/*",
    ".idea",
    ".idea/*",
    ".vscode",
    ".vscode/*",
    ".DS_Store",
    "*.min.js",
    "*.min.css",
    "coverage",
    "coverage/*",
    ".coverage",
    "htmlcov",
    "htmlcov/*",
    "*.log",
    ".cache",
    ".cache/*",
    "vendor",
    "vendor/*",
    "Pods",
    "Pods/*",
)

IGNORE_FILENAMES = frozenset({".ds_store"})


def load_ignore_patterns(repo: Path | None) -> list[str]:
    patterns = list(DEFAULT_IGNORE_PATTERNS)
    if repo is None:
        return patterns
    root = repo.resolve()
    ignore_file = root / ".scrutinignore"
    if not ignore_file.is_file():
        legacy = root / ".reviewpackignore"
        if legacy.is_file():
            ignore_file = legacy
    if ignore_file.is_file():
        for line in ignore_file.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    return patterns


def normalize_repo_path(path: str) -> str:
    """Normalize a repo-relative path; preserve leading dots on dotfiles."""
    path = path.replace("\\", "/").strip()
    while path.startswith("./"):
        path = path[2:]
    return path


def _norm_path(path: str) -> str:
    return normalize_repo_path(path)


def should_ignore_path(path: str, patterns: list[str]) -> bool:
    p = _norm_path(path)
    base = Path(p).name.lower()
    if base in IGNORE_FILENAMES:
        return True

    segments = p.split("/")
    for seg in segments:
        if seg in (".venv", "venv", "node_modules", "__pycache__", ".git", "dist", "build", ".pytest_cache", ".mypy_cache", ".ruff_cache", "htmlcov", "coverage", ".tox", "target", "Pods", "vendor"):
            return True

    for pattern in patterns:
        pat = _norm_path(pattern)
        if fnmatch.fnmatch(p, pat) or fnmatch.fnmatch(p, pat.rstrip("/*")):
            return True
        if fnmatch.fnmatch(p, f"**/{pat}") or fnmatch.fnmatch(p, f"**/{pat.rstrip('/*')}/**"):
            return True
        # Directory prefix: pattern ends with / or is a known dir name
        if pat.endswith("/") and (p.startswith(pat) or f"/{pat}" in f"/{p}/"):
            return True
        if "/" not in pat and p.split("/")[0] == pat:
            return True

    return False
