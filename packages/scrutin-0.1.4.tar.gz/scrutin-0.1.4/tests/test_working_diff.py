from scrutin.diff_parser import parse_unified_diff

DIFF_WITH_VENV = """diff --git a/app.py b/app.py
--- a/app.py
+++ b/app.py
@@ -1 +1,2 @@
 x=1
+x=2
diff --git a/.venv/lib/j.py b/.venv/lib/j.py
--- a/dev/null
+++ b/.venv/lib/j.py
@@ -0,0 +1 @@
+junk
"""


def test_working_diff_skips_venv():
    files, ignored = parse_unified_diff(DIFF_WITH_VENV)
    assert ignored == 1
    assert len(files) == 1
    assert files[0].path == "app.py"
