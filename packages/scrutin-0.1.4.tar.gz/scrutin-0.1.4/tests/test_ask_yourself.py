from __future__ import annotations

import unittest

from scrutin.brief_builder import _ask_yourself, build_brief
from scrutin.models import ASK_YOURSELF_COUNT
from scrutin.diff_parser import FileChange
from scrutin.models import BriefRequest


class AskYourselfTests(unittest.TestCase):
    def test_always_five_checkpoints(self) -> None:
        files = [
            FileChange(path="a.py", status="modified", additions=1, deletions=0),
        ]
        checks = _ask_yourself(files, BriefRequest())
        self.assertEqual(len(checks), ASK_YOURSELF_COUNT)

    def test_brief_includes_ask_yourself(self) -> None:
        files = [
            FileChange(
                path="db/migrate.sql",
                status="modified",
                additions=10,
                deletions=0,
                is_risky=True,
                risk_reasons=["database migration"],
            ),
        ]
        brief = build_brief(files, meta=BriefRequest())
        self.assertEqual(len(brief.ask_yourself), ASK_YOURSELF_COUNT)
        self.assertEqual(brief.suggested_tests, [])


if __name__ == "__main__":
    unittest.main()
