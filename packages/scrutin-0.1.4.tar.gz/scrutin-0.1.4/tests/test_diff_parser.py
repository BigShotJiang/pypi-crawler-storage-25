from scrutin.diff_parser import parse_unified_diff

SAMPLE = """diff --git a/src/auth.py b/src/auth.py
index 111..222 100644
--- a/src/auth.py
+++ b/src/auth.py
@@ -1,3 +1,4 @@
 def login():
+    validate_token()
     return True
diff --git a/README.md b/README.md
index 333..444 100644
--- a/README.md
+++ b/README.md
@@ -1 +1,2 @@
 # App
+Updated
"""


def test_parse_counts_and_risk():
    files, ignored = parse_unified_diff(SAMPLE)
    assert ignored == 0
    assert len(files) == 2
    auth = next(f for f in files if f.path.endswith("auth.py"))
    assert auth.is_risky
    assert "authentication / secrets" in auth.risk_reasons
