from scrutin.brief_builder import build_brief
from scrutin.models import BriefRequest, FileChange


def test_brief_includes_all_changed_files():
    files = [
        FileChange(path="a.py", status="modified", additions=10, deletions=1),
        FileChange(path="b.py", status="modified", additions=2, deletions=0),
    ]
    brief = build_brief(files, meta=BriefRequest(), mode="working")
    assert len(brief.all_changed_files) == 2
    assert {f.path for f in brief.all_changed_files} == {"a.py", "b.py"}
    assert brief.stats["files_changed"] == 2


def test_scrutinize_list_falls_back_when_not_risky():
    files = [
        FileChange(path="readme.md", status="modified", additions=3, deletions=1),
        FileChange(path="notes.txt", status="modified", additions=1, deletions=0),
    ]
    brief = build_brief(files, meta=BriefRequest(), mode="working")
    assert len(brief.files_to_scrutinize) >= 1
    assert brief.files_to_scrutinize[0].path == "readme.md"
