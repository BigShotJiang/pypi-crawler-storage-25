from scrutin.path_ignore import normalize_repo_path, should_ignore_path


def test_normalize_repo_path_preserves_dotfiles():
    assert normalize_repo_path(".env.example") == ".env.example"
    assert normalize_repo_path("./.env") == ".env"
    assert normalize_repo_path(".gitignore") == ".gitignore"


def test_normalize_repo_path_strips_leading_dot_slash_only():
    assert normalize_repo_path("./src/foo.py") == "src/foo.py"
    assert normalize_repo_path("src/foo.py") == "src/foo.py"


def test_ignore_venv_and_pycache():
    patterns = [".venv/*", "**/__pycache__/**", "node_modules/*"]
    assert should_ignore_path(".venv/lib/python3.11/site-packages/foo.py", patterns)
    assert should_ignore_path("src/__pycache__/mod.cpython-311.pyc", patterns)
    assert should_ignore_path("node_modules/lodash/index.js", patterns)
    assert not should_ignore_path("src/api.py", patterns)


def test_ignore_does_not_skip_source():
    patterns = [".venv/*"]
    assert not should_ignore_path("scrutin/cli.py", patterns)
