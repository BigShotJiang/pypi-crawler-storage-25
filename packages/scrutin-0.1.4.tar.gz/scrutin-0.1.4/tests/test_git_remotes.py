from pathlib import Path
from types import SimpleNamespace

import pytest

from scrutin.git_actions import GitActionError, list_git_remotes, push_repo, resolve_push_remote


def test_list_git_remotes_empty(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()

    def fake_run(r, *args):
        if args == ("remote",):
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    assert list_git_remotes(repo) == []


def test_resolve_push_remote_prefers_origin(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    monkeypatch.setattr(
        "scrutin.git_actions.list_git_remotes",
        lambda _r: [
            {"name": "upstream", "url": "git@github.com:org/repo.git"},
            {"name": "origin", "url": "git@github.com:you/repo.git"},
        ],
    )
    assert resolve_push_remote(repo) == "origin"


def test_resolve_push_remote_no_remotes_raises(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    monkeypatch.setattr("scrutin.git_actions.list_git_remotes", lambda _r: [])
    monkeypatch.setattr("scrutin.git_actions.current_branch", lambda _r: "master")
    with pytest.raises(GitActionError) as exc:
        resolve_push_remote(repo)
    assert exc.value.code == "no_remote"
    assert "git remote add origin" in str(exc.value)


def test_push_repo_uses_non_origin_remote(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    calls = []

    def fake_push_status(_r):
        return {
            "branch": "main",
            "has_upstream": False,
            "upstream": "",
            "ahead": 2,
            "behind": 0,
            "can_push": True,
            "needs_pull": False,
            "remotes": ["github"],
            "default_remote": "github",
            "has_remote": True,
        }

    monkeypatch.setattr("scrutin.git_actions.push_status", fake_push_status)
    monkeypatch.setattr("scrutin.git_actions.resolve_push_remote", lambda _r, remote=None: "github")

    def fake_run(r, *args):
        calls.append(args)
        if args[:2] == ("rev-parse", "--abbrev-ref"):
            return SimpleNamespace(returncode=0, stdout="origin/main\n", stderr="")
        return SimpleNamespace(returncode=0, stdout="ok\n", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    monkeypatch.setattr("scrutin.git_actions.repo_has_merge_conflicts", lambda _r: False)

    out = push_repo(repo)
    assert ("push", "-u", "github", "main") in calls
    assert out["remote"] == "github"
