from pathlib import Path
from types import SimpleNamespace

from scrutin.git_workspace import merge_status_into_changes
from scrutin.models import FileChange


def test_merge_status_adds_untracked_paths(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    files = [
        FileChange(path="src/a.py", status="modified", additions=1, deletions=0, staged=False, has_unstaged=True),
    ]

    def fake_list(_repo):
        return [
            {"path": "src/a.py", "staged": False, "has_unstaged": True},
            {"path": ".vscode/settings.json", "staged": False, "has_unstaged": True},
        ]

    monkeypatch.setattr("scrutin.git_workspace.list_changed_paths", fake_list)
    merged, extra_ignored = merge_status_into_changes(repo, files)
    paths = {f.path for f in merged}
    assert "src/a.py" in paths
    assert ".vscode/settings.json" in paths
    assert extra_ignored >= 1
