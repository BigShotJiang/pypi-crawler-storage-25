from scrutin.path_ignore import load_ignore_patterns, should_ignore_path


def test_env_example_not_ignored_by_path_rules():
    patterns = load_ignore_patterns(None)
    assert not should_ignore_path(".env.example", patterns)
    assert not should_ignore_path(".env", patterns)
    assert should_ignore_path("env/local.cfg", patterns)
    assert should_ignore_path("env/foo", patterns)
