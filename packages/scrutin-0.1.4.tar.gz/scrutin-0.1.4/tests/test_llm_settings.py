from __future__ import annotations

import os
import unittest
from pathlib import Path

from scrutin.llm_settings import (
    apply_env_to_process,
    get_public_settings,
    mask_secret,
    read_env_file,
    resolve_active_provider,
    save_settings,
    write_env_file,
    LlmSettingsUpdate,
)


class LlmSettingsTests(unittest.TestCase):
    def test_mask_secret(self) -> None:
        self.assertEqual(mask_secret("sk-abcdefghijklmnop"), "sk-a…mnop")
        self.assertEqual(mask_secret(""), "")

    def test_write_and_read_env(self) -> None:
        with self.subTest("roundtrip"):
            import tempfile

            with tempfile.TemporaryDirectory() as td:
                env = Path(td) / ".env"
                write_env_file(
                    env, {"OPENAI_API_KEY": "sk-test", "SCRUTIN_LLM_PROVIDER": "openai"}
                )
                data = read_env_file(env)
                self.assertEqual(data["OPENAI_API_KEY"], "sk-test")

    def test_resolve_provider(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            env = Path(td) / ".env"
            write_env_file(
                env,
                {"ANTHROPIC_API_KEY": "ant-key", "SCRUTIN_LLM_PROVIDER": "anthropic"},
            )
            os.environ["SCRUTIN_ENV"] = str(env)
            apply_env_to_process(env)
            self.assertEqual(resolve_active_provider(), "anthropic")

    def test_save_none(self) -> None:
        import tempfile

        with tempfile.TemporaryDirectory() as td:
            repo = Path(td) / "proj"
            repo.mkdir()
            env = repo / ".env"
            write_env_file(env, {"OPENAI_API_KEY": "sk-x", "SCRUTIN_LLM_PROVIDER": "openai"})
            os.environ["SCRUTIN_ENV"] = str(env)
            apply_env_to_process(env)
            out = save_settings(str(repo), LlmSettingsUpdate(provider="none"))
            self.assertEqual(out.brief_mode, "sharpen")
            self.assertIsNone(resolve_active_provider())


if __name__ == "__main__":
    unittest.main()
