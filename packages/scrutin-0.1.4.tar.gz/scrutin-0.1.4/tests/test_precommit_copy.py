from scrutin.brief_builder import build_brief
from scrutin.models import BriefRequest, FileChange


def test_precommit_summary_and_why_avoid_pr_language():
    files = [
        FileChange(
            path=".env.example",
            status="modified",
            additions=10,
            deletions=2,
            is_risky=True,
            risk_reasons=["configuration surface"],
        ),
        FileChange(
            path="scrutin/cli.py",
            status="modified",
            additions=50,
            deletions=5,
            is_risky=True,
            risk_reasons=["large change set"],
        ),
    ]
    brief = build_brief(files, meta=BriefRequest(), mode="working", audience="precommit")
    blob = (brief.summary + brief.why).lower()
    assert "pull request" not in blob
    assert "before you commit" in brief.summary.lower()
    assert "commit" in brief.why.lower()
    assert any(f.path == ".env.example" for f in brief.files_to_scrutinize)


def test_pr_audience_keeps_pr_why_fallback():
    brief = build_brief(
        [FileChange(path="a.py", status="modified", additions=1, deletions=0)],
        meta=BriefRequest(),
        audience="pr",
    )
    assert "reviewers" in brief.why.lower() or "ticket" in brief.why.lower()
