from pathlib import Path
from types import SimpleNamespace

from scrutin.git_workspace import build_workspace_brief


def test_build_workspace_brief_empty_diff_no_raise(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    (repo / "README.md").write_text("hi\n", encoding="utf-8")

    def fake_diff(*_a, **_k):
        return ""

    monkeypatch.setattr("scrutin.git_workspace.git_diff_for_mode", fake_diff)
    monkeypatch.setattr(
        "scrutin.git_workspace.repo_has_commits",
        lambda _r: True,
    )
    monkeypatch.setattr(
        "scrutin.git_workspace.git_status_short",
        lambda _r: {"has_changes": False, "staged": 0, "unstaged": 0, "untracked": 0, "total": 0},
    )
    monkeypatch.setattr(
        "scrutin.git_workspace.subprocess.run",
        lambda *a, **k: SimpleNamespace(returncode=0, stdout="abc1234 init\n", stderr=""),
    )
    monkeypatch.setattr("scrutin.git_workspace.list_changed_paths", lambda _r: [])

    brief, _md, extra = build_workspace_brief(repo, "main", "HEAD", mode="working")
    assert brief.stats.get("empty_scope") is True
    assert brief.all_changed_files == []
    assert "No diff" in brief.summary
    assert extra["uncommitted"]["has_changes"] is False
