from scrutin.diff_parser import dedupe_file_changes, parse_unified_diff

DUPLICATE_ENV = """diff --git a/.env.example b/.env.example
index 111..222 100644
--- a/.env.example
+++ b/.env.example
@@ -1,2 +1,5 @@
 A=1
+B=2
+C=3
+D=4
diff --git a/.env.example b/.env.example
index 222..333 100644
--- a/.env.example
+++ b/.env.example
@@ -5,1 +5,2 @@
 D=4
+E=5
"""


def test_parse_merges_duplicate_paths():
    files, _ = parse_unified_diff(DUPLICATE_ENV)
    paths = [f.path for f in files]
    assert paths.count(".env.example") == 1
    env = next(f for f in files if f.path == ".env.example")
    assert env.additions == 4
    assert env.deletions == 0
    assert "configuration surface" in env.risk_reasons


def test_dedupe_preserves_order():
    from scrutin.models import FileChange

    a = FileChange(path="a.txt", status="modified", additions=1, deletions=0)
    b = FileChange(path="b.txt", status="modified", additions=2, deletions=0)
    a2 = FileChange(path="a.txt", status="modified", additions=3, deletions=1)
    merged = dedupe_file_changes([a, b, a2])
    assert [f.path for f in merged] == ["a.txt", "b.txt"]
    assert merged[0].additions == 4
    assert merged[0].deletions == 1
