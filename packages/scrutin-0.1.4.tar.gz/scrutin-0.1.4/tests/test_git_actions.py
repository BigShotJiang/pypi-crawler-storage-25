from pathlib import Path
from types import SimpleNamespace

import pytest

from scrutin.diff_parser import extract_file_unified_diff
from scrutin.git_actions import (
    GitActionError,
    _file_working_unified_diff,
    _path_untracked,
    _untracked_file_unified_diff,
    commit_repo,
    file_stage_flags,
    git_identity,
    repo_has_merge_conflicts,
    set_git_identity,
    parse_unified_to_hunks,
    stage_file,
    suggest_commit_message,
)
from scrutin.models import FileChange

SAMPLE = """diff --git a/foo.py b/foo.py
--- a/foo.py
+++ b/foo.py
@@ -1,3 +1,4 @@
 line1
-removed
+added
 context
"""


def test_parse_unified_to_hunks_split():
    hunks = parse_unified_to_hunks(SAMPLE)
    assert len(hunks) == 1
    h = hunks[0]
    assert any(l.kind == "del" for l in h.left)
    assert any(l.kind == "add" for l in h.right)
    assert any(l.kind == "context" for l in h.left)


def test_suggest_commit_message_single_file():
    files = [
        FileChange(
            path="src/auth.py",
            status="modified",
            additions=5,
            deletions=1,
            is_risky=True,
            risk_reasons=["authentication / secrets"],
        )
    ]
    msg = suggest_commit_message(files)
    assert "auth.py" not in msg.message
    assert "authentication" in msg.message.lower()
    assert "…" not in msg.message
    assert "Files:" not in msg.body


def test_suggest_commit_message_many_files_no_ellipsis():
    files = [
        FileChange(
            path=f"scrutin/module_{i}.py",
            status="modified",
            additions=50,
            deletions=5,
            is_risky=True,
            risk_reasons=["large change set"],
        )
        for i in range(8)
    ]
    msg = suggest_commit_message(files)
    assert "…" not in msg.subject
    assert "…" not in msg.message
    assert len(msg.subject) <= 72
    assert "module_0" not in msg.subject
    assert "Files:" not in msg.body
    assert "Changes:" in msg.body


def test_suggest_commit_message_three_files_functional_subject():
    files = [
        FileChange(
            path="scrutin/static/app.js",
            status="modified",
            additions=10,
            deletions=1,
            is_risky=True,
        ),
        FileChange(
            path="scrutin/static/styles.css",
            status="modified",
            additions=8,
            deletions=0,
            is_risky=True,
        ),
        FileChange(
            path="extension/media/webview.js",
            status="modified",
            additions=6,
            deletions=0,
            is_risky=True,
        ),
    ]
    msg = suggest_commit_message(files)
    assert len(msg.subject) <= 72
    assert "…" not in msg.subject
    assert "app.js" not in msg.subject
    assert "review UI" in msg.message or "editor extension" in msg.message


def test_stage_file_passes_dotenv_path_to_git(monkeypatch):
    calls: list[tuple] = []

    def fake_run(repo, *args):
        calls.append(args)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    def fake_flags(repo, path):
        return True, False

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    monkeypatch.setattr("scrutin.git_actions.file_stage_flags", fake_flags)
    stage_file(Path("/tmp/repo"), ".env.example")
    assert calls[0][0] == "add"
    assert calls[0][1] == "--"
    assert calls[0][2] == ".env.example"


def test_working_file_diff_merges_staged_and_unstaged(monkeypatch):
    repo = Path("/tmp/repo")

    def fake_run(repo_arg, *args):
        if args[:2] == ("diff", "--cached"):
            return SimpleNamespace(
                returncode=1,
                stdout="@@ -1 +1,2 @@\n-old\n+line2-staged\n",
                stderr="",
            )
        if args[:1] == ("diff",) and "--cached" not in args:
            return SimpleNamespace(
                returncode=1,
                stdout="@@ -2 +2,3 @@\n line2-staged\n+line3-unstaged\n",
                stderr="",
            )
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    monkeypatch.setattr("scrutin.git_actions.repo_has_commits", lambda _r: True)
    unified = _file_working_unified_diff(repo, "sample.txt")
    assert "line2-staged" in unified
    assert "line3-unstaged" in unified
    hunks = parse_unified_to_hunks(unified)
    right_text = "\n".join(l.text for h in hunks for l in h.right if l.kind == "add")
    assert "line2-staged" in right_text
    assert "line3-unstaged" in right_text


def test_working_file_diff_skips_head_without_commits(monkeypatch):
    repo = Path("/tmp/repo")
    calls: list[tuple] = []

    def fake_run(repo_arg, *args):
        calls.append(args)
        if args[:2] == ("diff", "--cached"):
            return SimpleNamespace(
                returncode=1,
                stdout="@@ -0,0 +1 @@\n+# Readme\n",
                stderr="",
            )
        if args[:1] == ("diff",):
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        raise AssertionError(f"unexpected git call: {args}")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    monkeypatch.setattr("scrutin.git_actions.repo_has_commits", lambda _r: False)
    unified = _file_working_unified_diff(repo, "README.md")
    assert "# Readme" in unified
    assert not any(args[:2] == ("diff", "HEAD") for args in calls)


def test_extract_file_unified_diff_from_multi_file():
    full = """diff --git a/a.txt b/a.txt
--- a/a.txt
+++ b/a.txt
@@ -1 +1,2 @@
 x
+y
diff --git a/b.txt b/b.txt
--- a/b.txt
+++ b/b.txt
@@ -1 +1,2 @@
 p
+q
"""
    chunk = extract_file_unified_diff(full, "b.txt")
    assert "b.txt" in chunk
    assert "+q" in chunk
    assert "a.txt" not in chunk


def test_file_stage_flags_untracked(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    (repo / "new.txt").write_text("hi\n", encoding="utf-8")

    def fake_run(r, *args):
        if args[:2] == ("status", "--porcelain"):
            return SimpleNamespace(returncode=0, stdout="?? new.txt\n", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    assert file_stage_flags(repo, "new.txt") == (False, True)


def test_untracked_file_diff_uses_no_index(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    (repo / "new.txt").write_text("line\n", encoding="utf-8")
    calls = []

    def fake_run(r, *args):
        calls.append(args)
        if args[:2] == ("diff", "--no-index"):
            return SimpleNamespace(
                returncode=1,
                stdout="@@ -0,0 +1 @@\n+line\n",
                stderr="",
            )
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    text = _untracked_file_unified_diff(repo, "new.txt")
    assert "+line" in text
    assert calls[0][:3] == ("diff", "--no-index", "--")


def test_git_identity_not_configured(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()

    def fake_run(r, *args):
        if args[:3] == ("config", "--get", "user.name"):
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        if args[:3] == ("config", "--get", "user.email"):
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    assert git_identity(repo) == {"configured": False, "name": "", "email": ""}


def test_set_git_identity_local(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()
    store: dict[str, str] = {}

    def fake_run(r, *args):
        if args[:2] == ("config", "user.name"):
            store["name"] = args[2]
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        if args[:2] == ("config", "user.email"):
            store["email"] = args[2]
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        if args[:3] == ("config", "--get", "user.name"):
            return SimpleNamespace(returncode=0, stdout=store.get("name", ""), stderr="")
        if args[:3] == ("config", "--get", "user.email"):
            return SimpleNamespace(returncode=0, stdout=store.get("email", ""), stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    out = set_git_identity(repo, "Ada Lovelace", "ada@example.com")
    assert out["configured"] is True
    assert out["name"] == "Ada Lovelace"
    assert out["email"] == "ada@example.com"


def test_commit_identity_required(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()

    def fake_run(r, *args):
        if args[:3] == ("diff", "--cached", "--quiet"):
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        if args[:3] == ("config", "--get", "user.name"):
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        if args[:3] == ("config", "--get", "user.email"):
            return SimpleNamespace(returncode=1, stdout="", stderr="")
        if args[:1] == ("diff",) and "--diff-filter=U" in args:
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        if args[:2] == ("status", "--porcelain"):
            return SimpleNamespace(returncode=0, stdout="", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    monkeypatch.setattr("scrutin.git_actions.has_staged_changes", lambda _r: True)
    with pytest.raises(GitActionError) as exc:
        commit_repo(repo, "feat: test")
    assert exc.value.code == "identity_required"


def test_repo_has_merge_conflicts_unmerged(tmp_path: Path, monkeypatch):
    repo = tmp_path / "r"
    repo.mkdir()

    def fake_run(r, *args):
        if args[:1] == ("diff",) and "--diff-filter=U" in args:
            return SimpleNamespace(returncode=0, stdout="conflicted.txt\n", stderr="")
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr("scrutin.git_actions._run_git", fake_run)
    assert repo_has_merge_conflicts(repo) is True
