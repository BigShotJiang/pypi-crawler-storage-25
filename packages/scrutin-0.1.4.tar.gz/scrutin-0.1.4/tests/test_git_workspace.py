from pathlib import Path

from scrutin.git_workspace import detect_base_branch, git_toplevel


def test_git_toplevel_scrutin_repo():
    root = Path(__file__).resolve().parents[1]
    assert git_toplevel(root) == root.resolve()


def test_detect_base_branch():
    root = Path(__file__).resolve().parents[1]
    base = detect_base_branch(root)
    assert base in ("main", "master", "develop", "development")
