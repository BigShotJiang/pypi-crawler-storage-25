//! Unified `ThetaData` client -- single entry point, one auth, lazy FPSS.
//!
//! Connect once. Use historical data immediately. Streaming connects
//! on-demand when you first subscribe -- not at startup.
//!
//! ```rust,no_run
//! use thetadatadx::{ThetaDataDx, Credentials, DirectConfig};
//!
//! #[tokio::main]
//! async fn main() -> Result<(), thetadatadx::Error> {
//!     // One connect, one auth. FPSS is NOT connected yet.
//!     // Or inline: Credentials::new("user@example.com", "your-password")
//!     let tdx = ThetaDataDx::connect(
//!         &Credentials::from_file("creds.txt")?,
//!         DirectConfig::production(),
//!     ).await?;
//!
//!     // Historical -- works immediately
//!     let eod = tdx.stock_history_eod("AAPL", "20240101", "20240301").await?;
//!
//!     // Streaming -- FPSS connects lazily on first subscribe
//!     use thetadatadx::fpss::{FpssData, FpssEvent};
//!     use thetadatadx::fpss::protocol::Contract;
//!     tdx.start_streaming(|event| {
//!         if let FpssEvent::Data(FpssData::Trade { price, size, .. }) = event {
//!             println!("trade {price} x {size}");
//!         }
//!     })?;
//!     tdx.subscribe_quotes(&Contract::stock("AAPL"))?;
//!
//!     Ok(())
//! }
//! ```

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use crate::auth::Credentials;
use crate::config::DirectConfig;
use crate::error::Error;
use crate::fpss::protocol::{Contract, SubscriptionKind};
use crate::fpss::{FpssClient, FpssEvent};
use crate::mdds::MddsClient;
use tdbe::types::enums::SecType;

/// Subscription tier information captured at authentication time.
#[derive(Debug, Clone)]
pub struct SubscriptionInfo {
    /// Stock data subscription tier (e.g. "Free", "Value", "Standard", "Pro").
    pub stock: String,
    /// Options data subscription tier (e.g. "Free", "Value", "Standard", "Pro").
    pub options: String,
}

/// Current state of the streaming connection.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum ConnectionStatus {
    /// `start_streaming()` has not been called yet.
    NotStarted,
    /// Connected and authenticated.
    Connected,
    /// Currently attempting to reconnect after an involuntary disconnect.
    Reconnecting,
    /// Explicitly stopped or failed to connect.
    Disconnected,
}

/// Unified `ThetaData` client.
///
/// Authenticates once at connect time. Historical data (MDDS gRPC) is
/// available immediately. Streaming (FPSS TCP) connects lazily when
/// you call [`start_streaming`](Self::start_streaming).
///
/// All historical endpoint methods are available via `Deref` to
/// [`MddsClient`]. Streaming methods are on this struct directly.
pub struct ThetaDataDx {
    historical: MddsClient,
    streaming: Mutex<Option<FpssClient>>,
    creds: Credentials,
    /// Set to `true` once `start_streaming()` succeeds; never cleared.
    /// Used by `connection_status()` to distinguish "never started" from
    /// "was started but the client was dropped/stopped".
    was_streaming: AtomicBool,
}

impl ThetaDataDx {
    /// Connect to `ThetaData`. Authenticates once, opens gRPC channel.
    ///
    /// FPSS streaming is NOT connected yet -- call [`ThetaDataDx::start_streaming`]
    /// when you need real-time data.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub async fn connect(creds: &Credentials, config: DirectConfig) -> Result<Self, Error> {
        // Start the Prometheus exporter BEFORE opening the gRPC channel
        // so the first `thetadatadx.grpc.requests` counter hit is already
        // covered. No-op when the feature is disabled or `metrics_port`
        // is `None` (the default).
        crate::observability::try_install_exporter(&config)?;
        let historical = MddsClient::connect(creds, config).await?;
        Ok(Self {
            historical,
            streaming: Mutex::new(None),
            creds: creds.clone(),
            was_streaming: AtomicBool::new(false),
        })
    }

    /// Start the FPSS streaming connection with a callback handler.
    ///
    /// This opens a TLS/TCP connection to `ThetaData`'s FPSS servers,
    /// authenticates with the same credentials used at connect time,
    /// and starts the Disruptor ring buffer + I/O thread.
    ///
    /// The callback runs on the Disruptor consumer thread -- keep it fast.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn start_streaming<F>(&self, handler: F) -> Result<(), Error>
    where
        F: FnMut(&FpssEvent) + Send + 'static,
    {
        let mut guard = self
            .streaming
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if guard.is_some() {
            return Err(Error::Fpss {
                kind: crate::error::FpssErrorKind::ConnectionRefused,
                message: "streaming already started".into(),
            });
        }
        let config = self.historical.config();
        let client = FpssClient::connect(
            &self.creds,
            &config.fpss_hosts,
            config.fpss_ring_size,
            config.fpss_flush_mode,
            config.reconnect_policy.clone(),
            config.derive_ohlcvc,
            handler,
        )?;
        *guard = Some(client);
        self.was_streaming.store(true, Ordering::Release);
        Ok(())
    }

    /// Whether streaming is currently active.
    pub fn is_streaming(&self) -> bool {
        self.streaming
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .is_some()
    }

    // -- Streaming convenience methods --

    fn with_streaming<R>(
        &self,
        f: impl FnOnce(&FpssClient) -> Result<R, Error>,
    ) -> Result<R, Error> {
        let guard = self
            .streaming
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let client = guard.as_ref().ok_or_else(|| Error::Fpss {
            kind: crate::error::FpssErrorKind::Disconnected,
            message: "streaming not started -- call start_streaming() first".into(),
        })?;
        f(client)
    }

    /// Subscribe to quote updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_quotes(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_quotes(contract))
    }

    /// Subscribe to trade updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_trades(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_trades(contract))
    }

    /// Subscribe to open interest updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_open_interest(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_open_interest(contract))
    }

    /// Subscribe to quotes + trades for a contract (convenience batch).
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_all(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_all(contract))
    }

    /// Subscribe to all trades for a security type (firehose).
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_full_trades(&self, sec_type: SecType) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_full_trades(sec_type))
    }

    /// Subscribe to all open interest for a security type (firehose).
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn subscribe_full_open_interest(&self, sec_type: SecType) -> Result<(), Error> {
        self.with_streaming(|s| s.subscribe_full_open_interest(sec_type))
    }

    /// Unsubscribe from quote updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn unsubscribe_quotes(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.unsubscribe_quotes(contract))
    }

    /// Unsubscribe from trade updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn unsubscribe_trades(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.unsubscribe_trades(contract))
    }

    /// Unsubscribe from open interest updates for a contract.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn unsubscribe_open_interest(&self, contract: &Contract) -> Result<(), Error> {
        self.with_streaming(|s| s.unsubscribe_open_interest(contract))
    }

    /// Unsubscribe from all trades for a security type.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn unsubscribe_full_trades(&self, sec_type: SecType) -> Result<(), Error> {
        self.with_streaming(|s| s.unsubscribe_full_trades(sec_type))
    }

    /// Unsubscribe from all open interest for a security type.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn unsubscribe_full_open_interest(&self, sec_type: SecType) -> Result<(), Error> {
        self.with_streaming(|s| s.unsubscribe_full_open_interest(sec_type))
    }

    /// Get the current contract ID to Contract mapping.
    ///
    /// Values are `Arc<Contract>` — the same refcounted contract every
    /// decoded FPSS event carries. Cloning the map clones Arcs, not
    /// underlying `Contract` values.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn contract_map(&self) -> Result<HashMap<i32, Arc<Contract>>, Error> {
        self.with_streaming(|s| Ok(s.contract_map()))
    }

    /// Look up a contract by its server-assigned ID.
    ///
    /// Returns `Arc<Contract>` so callers share the same heap allocation
    /// as the I/O thread cache and every decoded data event.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn contract_lookup(&self, id: i32) -> Result<Option<Arc<Contract>>, Error> {
        self.with_streaming(|s| Ok(s.contract_lookup(id)))
    }

    /// Get all active per-contract subscriptions.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn active_subscriptions(&self) -> Result<Vec<(SubscriptionKind, Contract)>, Error> {
        self.with_streaming(|s| Ok(s.active_subscriptions()))
    }

    /// Get all active full-type (firehose) subscriptions.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn active_full_subscriptions(&self) -> Result<Vec<(SubscriptionKind, SecType)>, Error> {
        self.with_streaming(|s| Ok(s.active_full_subscriptions()))
    }

    /// Shut down the streaming connection. Historical remains available.
    pub fn stop_streaming(&self) {
        let mut guard = self
            .streaming
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if let Some(client) = guard.take() {
            client.shutdown();
        }
    }

    /// Reconnect the streaming connection, re-subscribing all previous subscriptions.
    ///
    /// This is the caller-driven equivalent of Java's `handleInvoluntaryDisconnect()`.
    /// It saves active subscriptions, stops the current streaming connection,
    /// starts a new one with the provided handler, and re-subscribes everything.
    ///
    /// # Sequence
    ///
    /// 1. Save active per-contract and full-type subscriptions
    /// 2. Stop the current streaming connection
    /// 3. Start a new streaming connection with the provided handler
    /// 4. Re-subscribe all saved subscriptions, collecting per-subscription
    ///    failures rather than aborting on the first error
    ///
    /// # Errors
    ///
    /// Returns [`Error::Fpss`], [`Error::Auth`], etc. when the underlying
    /// streaming session cannot be re-established (steps 1–3).
    ///
    /// Returns [`Error::PartialReconnect`] when the streaming session was
    /// re-established successfully but one or more saved subscriptions
    /// failed to restore. The variant carries the structured list of failed
    /// `(SubscriptionKind, Contract)` pairs so the caller can retry just
    /// those subscriptions or surface the partial failure to the operator.
    /// Per-subscription `tracing::warn!` lines are still emitted for
    /// operational visibility.
    pub fn reconnect_streaming<F>(&self, handler: F) -> Result<(), Error>
    where
        F: FnMut(&FpssEvent) + Send + 'static,
    {
        metrics::counter!("thetadatadx.fpss.reconnects").increment(1);
        // 1. Save active subscriptions before stopping
        let saved_subs = {
            let guard = self
                .streaming
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            match guard.as_ref() {
                Some(client) => (
                    client.active_subscriptions(),
                    client.active_full_subscriptions(),
                ),
                None => (Vec::new(), Vec::new()),
            }
        };

        // 2. Stop streaming
        self.stop_streaming();

        // 3. Start a new streaming connection
        self.start_streaming(handler)?;

        // 4. Re-subscribe all saved subscriptions, accumulating failures
        let (per_contract, full_type) = saved_subs;
        let failed = restore_subscriptions(
            &per_contract,
            &full_type,
            |kind, contract| match kind {
                SubscriptionKind::Quote => self.subscribe_quotes(contract),
                SubscriptionKind::Trade => self.subscribe_trades(contract),
                SubscriptionKind::OpenInterest => self.subscribe_open_interest(contract),
            },
            |kind, sec_type| match kind {
                SubscriptionKind::Trade => Some(self.subscribe_full_trades(sec_type)),
                SubscriptionKind::OpenInterest => Some(self.subscribe_full_open_interest(sec_type)),
                SubscriptionKind::Quote => None,
            },
        );

        if failed.is_empty() {
            Ok(())
        } else {
            Err(Error::PartialReconnect { failed })
        }
    }

    /// Get the current streaming connection status.
    pub fn connection_status(&self) -> ConnectionStatus {
        let guard = self
            .streaming
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        match guard.as_ref() {
            None => {
                // Client is gone (never set, or taken/dropped by stop_streaming).
                if self.was_streaming.load(Ordering::Acquire) {
                    ConnectionStatus::Disconnected
                } else {
                    ConnectionStatus::NotStarted
                }
            }
            Some(client) => {
                if client.is_authenticated() {
                    ConnectionStatus::Connected
                } else {
                    // The client exists but is not authenticated -- this happens
                    // during reconnection (authenticated flag is cleared on
                    // disconnect, restored on successful re-auth).
                    ConnectionStatus::Reconnecting
                }
            }
        }
    }

    /// Access the current MDDS session UUID.
    ///
    /// Returns an owned `String` rather than `&str` because the UUID
    /// lives behind a shared [`crate::auth::SessionToken`] that may be
    /// refreshed mid-session. Reads through the token so callers always
    /// see the current value.
    pub async fn session_uuid(&self) -> String {
        self.historical.session_uuid().await
    }

    /// Access the config.
    pub fn config(&self) -> &DirectConfig {
        self.historical.config()
    }

    /// Get subscription tier information captured at authentication time.
    pub fn subscription_info(&self) -> SubscriptionInfo {
        let tier = |level: Option<i32>| match level {
            Some(0) => "Free".to_string(),
            Some(1) => "Value".to_string(),
            Some(2) => "Standard".to_string(),
            Some(3) => "Pro".to_string(),
            Some(n) => format!("Unknown({n})"),
            None => "Unknown".to_string(),
        };
        SubscriptionInfo {
            stock: tier(self.historical.stock_tier()),
            options: tier(self.historical.options_tier()),
        }
    }

    // ---------------------------------------------------------------------
    // FLATFILES surface (third public surface, alongside FPSS and MDDS).
    //
    // The legacy MDDS port (12000) speaks a custom binary PacketStream
    // protocol that supports a single FLAT_FILE request type. The server
    // pre-builds an INDEX + DATA blob per (sec_type, data_type, date)
    // tuple overnight and streams it back on demand. See
    // [`crate::flatfiles`] for the wire-format details and the decode /
    // writer implementation used by this surface, covering CSV and
    // JSONL output plus a typed in-memory return path.
    // ---------------------------------------------------------------------

    /// Pull a flat-file blob for `(sec_type, req_type, date)` over the legacy
    /// MDDS port, decode it, and write the requested `format` to disk.
    ///
    /// `format` selects the on-disk encoding:
    /// - [`crate::flatfiles::FlatFileFormat::Csv`] — vendor byte-format CSV
    ///   (lowercase headers, comma-separated, no quoting). Byte-matches the
    ///   legacy terminal's downloads on the same input.
    /// - [`crate::flatfiles::FlatFileFormat::Jsonl`] — JSON Lines, one
    ///   object per row.
    ///
    /// If `output_path` lacks a file extension, the format's canonical
    /// extension (`csv` / `jsonl`) is appended automatically.
    ///
    /// For columnar consumers (Parquet, Arrow IPC, polars) use
    /// [`Self::flatfile_request_decoded`] and feed the resulting
    /// `Vec<FlatFileRow>` into the writer of your choice — the SDK does
    /// not pull in Parquet / Arrow itself.
    ///
    /// # Errors
    /// Returns [`Error::FlatFilesUnavailable`] for auth / server
    /// rejection, [`Error::Config`] for malformed wire bytes, or
    /// [`Error::Io`] for local I/O issues.
    pub async fn flatfile_request(
        &self,
        sec_type: crate::flatfiles::SecType,
        req_type: crate::flatfiles::ReqType,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        crate::flatfiles::flatfile_request(
            &self.creds,
            sec_type,
            req_type,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Pull a flat-file blob and return decoded rows in memory.
    ///
    /// Same auth and stream path as [`Self::flatfile_request`], but skips
    /// the on-disk writer. Returns a `Vec<FlatFileRow>` ready to feed into
    /// an algorithm (backtester, risk model, in-memory analytics) without
    /// an intermediate file.
    ///
    /// The whole vector is materialised before the function returns; for
    /// whole-universe blobs that can be hundreds of MB.
    ///
    /// # Errors
    /// Same conditions as [`Self::flatfile_request`].
    pub async fn flatfile_request_decoded(
        &self,
        sec_type: crate::flatfiles::SecType,
        req_type: crate::flatfiles::ReqType,
        date: &str,
    ) -> Result<Vec<crate::flatfiles::FlatFileRow>, Error> {
        crate::flatfiles::flatfile_request_decoded(&self.creds, sec_type, req_type, date).await
    }

    /// Convenience: option open-interest flat file for `date`.
    pub async fn flatfile_option_open_interest(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Option,
            crate::flatfiles::ReqType::OpenInterest,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: option trade-quote flat file for `date`.
    pub async fn flatfile_option_trade_quote(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Option,
            crate::flatfiles::ReqType::TradeQuote,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: option trade flat file for `date`.
    pub async fn flatfile_option_trade(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Option,
            crate::flatfiles::ReqType::Trade,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: option quote flat file for `date`.
    pub async fn flatfile_option_quote(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Option,
            crate::flatfiles::ReqType::Quote,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: option end-of-day flat file for `date`.
    pub async fn flatfile_option_eod(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Option,
            crate::flatfiles::ReqType::Eod,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: stock trade-quote flat file for `date`.
    pub async fn flatfile_stock_trade_quote(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Stock,
            crate::flatfiles::ReqType::TradeQuote,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: stock trade flat file for `date`.
    pub async fn flatfile_stock_trade(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Stock,
            crate::flatfiles::ReqType::Trade,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: stock quote flat file for `date`.
    pub async fn flatfile_stock_quote(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Stock,
            crate::flatfiles::ReqType::Quote,
            date,
            output_path,
            format,
        )
        .await
    }

    /// Convenience: stock end-of-day flat file for `date`.
    pub async fn flatfile_stock_eod(
        &self,
        date: &str,
        output_path: impl AsRef<std::path::Path>,
        format: crate::flatfiles::FlatFileFormat,
    ) -> Result<std::path::PathBuf, Error> {
        self.flatfile_request(
            crate::flatfiles::SecType::Stock,
            crate::flatfiles::ReqType::Eod,
            date,
            output_path,
            format,
        )
        .await
    }
}

impl Drop for ThetaDataDx {
    fn drop(&mut self) {
        self.stop_streaming();
    }
}

// All historical methods available directly via Deref.
impl std::ops::Deref for ThetaDataDx {
    type Target = MddsClient;
    fn deref(&self) -> &MddsClient {
        &self.historical
    }
}

/// Replay every saved subscription against the freshly reconnected
/// streaming client and return the list of subscriptions that failed to
/// restore.
///
/// The two callbacks decouple the loop from the live `ThetaDataDx`
/// streaming methods so the resubscription logic is unit-testable with
/// in-memory fakes — the [`reconnect_streaming`] caller in production
/// passes through to the real `subscribe_quotes` / `subscribe_trades` /
/// `subscribe_open_interest` and `subscribe_full_*` methods, while the
/// regression test below injects closures that return canned `Err` for a
/// specific subscription pair to prove the failure list carries the right
/// structured contents.
///
/// Per-failure operational visibility is preserved: every error path emits a
/// `tracing::warn!` line carrying `kind`, `contract` (or `sec_type`), and
/// the underlying error, identical to the single-call-site loop this
/// helper replaces.
///
/// `full_subscribe` returns `Some(Result<()>)` for kinds that are valid
/// full-type subscriptions, and `None` for kinds that are not (currently
/// only `SubscriptionKind::Quote` is excluded). A `None` triggers the same
/// "skipping" warning the previous in-line loop emitted.
fn restore_subscriptions<P, F>(
    per_contract: &[(SubscriptionKind, Contract)],
    full_type: &[(SubscriptionKind, SecType)],
    mut per_subscribe: P,
    mut full_subscribe: F,
) -> Vec<(SubscriptionKind, Contract)>
where
    P: FnMut(SubscriptionKind, &Contract) -> Result<(), Error>,
    F: FnMut(SubscriptionKind, SecType) -> Option<Result<(), Error>>,
{
    let mut failed: Vec<(SubscriptionKind, Contract)> = Vec::new();

    for (kind, contract) in per_contract {
        if let Err(e) = per_subscribe(*kind, contract) {
            tracing::warn!(
                kind = ?kind,
                contract = %contract,
                error = %e,
                "failed to re-subscribe after reconnect"
            );
            failed.push((*kind, contract.clone()));
        }
    }

    for (kind, sec_type) in full_type {
        match full_subscribe(*kind, *sec_type) {
            Some(Ok(())) => {}
            Some(Err(e)) => {
                tracing::warn!(
                    kind = ?kind,
                    sec_type = ?sec_type,
                    error = %e,
                    "failed to re-subscribe full-type after reconnect"
                );
                // Full-type subscriptions are encoded as a synthetic
                // `Contract` with an empty `root` so the structured failure
                // list stays homogeneous. Operators see the original
                // `sec_type` via the `tracing::warn!` line above.
                failed.push((*kind, Contract::full_type_marker(*sec_type)));
            }
            None => {
                tracing::warn!(
                    kind = ?kind,
                    sec_type = ?sec_type,
                    "full-type subscription is not supported for this kind, skipping"
                );
            }
        }
    }

    failed
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Inject a single failing per-contract subscribe call and prove the
    /// returned failure list contains exactly the failed `(kind, contract)`
    /// pair — not a count, not a boolean, the real structured contents.
    #[test]
    fn restore_subscriptions_collects_failed_per_contract() {
        let aapl = Contract::stock("AAPL");
        let msft = Contract::stock("MSFT");
        let per_contract = vec![
            (SubscriptionKind::Quote, aapl.clone()),
            (SubscriptionKind::Quote, msft.clone()),
        ];
        let full_type: Vec<(SubscriptionKind, SecType)> = Vec::new();

        let failed = restore_subscriptions(
            &per_contract,
            &full_type,
            |_kind, contract| {
                if contract.root == "MSFT" {
                    Err(Error::Fpss {
                        kind: crate::error::FpssErrorKind::Disconnected,
                        message: "injected: MSFT subscribe rejected".to_string(),
                    })
                } else {
                    Ok(())
                }
            },
            |_, _| None,
        );

        assert_eq!(failed.len(), 1, "exactly one subscription must have failed");
        assert_eq!(failed[0].0, SubscriptionKind::Quote);
        assert_eq!(failed[0].1, msft);
    }

    /// A successful run must return an empty failure list — no false
    /// positives, no spurious entries.
    #[test]
    fn restore_subscriptions_empty_on_full_success() {
        let aapl = Contract::stock("AAPL");
        let per_contract = vec![(SubscriptionKind::Trade, aapl)];
        let full_type = vec![(SubscriptionKind::Trade, SecType::Stock)];

        let failed = restore_subscriptions(
            &per_contract,
            &full_type,
            |_, _| Ok(()),
            |_, _| Some(Ok(())),
        );

        assert!(failed.is_empty(), "no failures expected, got {failed:?}");
    }

    /// A full-type subscription failure must show up in the list with the
    /// `full_type_marker` synthetic contract carrying the right `SecType`,
    /// so callers can pattern-match the failure without losing the
    /// originally failed sec_type.
    #[test]
    fn restore_subscriptions_records_full_type_failure() {
        let per_contract: Vec<(SubscriptionKind, Contract)> = Vec::new();
        let full_type = vec![(SubscriptionKind::OpenInterest, SecType::Option)];

        let failed = restore_subscriptions(
            &per_contract,
            &full_type,
            |_, _| Ok(()),
            |_, _| {
                Some(Err(Error::Fpss {
                    kind: crate::error::FpssErrorKind::TooManyRequests,
                    message: "injected: full-type subscribe rate-limited".to_string(),
                }))
            },
        );

        assert_eq!(failed.len(), 1);
        let (kind, contract) = &failed[0];
        assert_eq!(*kind, SubscriptionKind::OpenInterest);
        assert_eq!(contract.sec_type, SecType::Option);
        assert!(
            contract.root.is_empty(),
            "full-type marker carries empty root, got {:?}",
            contract.root
        );
    }

    /// `reconnect_streaming` returns `Error::PartialReconnect` carrying the
    /// failed list when subscriptions cannot be restored — the regression
    /// test for issue #461. The variant payload is asserted by pattern-
    /// match, not just `is_err()`, so a future refactor that changes the
    /// payload shape breaks this test loudly.
    #[test]
    fn partial_reconnect_error_carries_failed_subscriptions() {
        let aapl = Contract::stock("AAPL");
        let per_contract = vec![(SubscriptionKind::Quote, aapl.clone())];
        let full_type: Vec<(SubscriptionKind, SecType)> = Vec::new();

        let failed = restore_subscriptions(
            &per_contract,
            &full_type,
            |_, _| {
                Err(Error::Fpss {
                    kind: crate::error::FpssErrorKind::Disconnected,
                    message: "injected".to_string(),
                })
            },
            |_, _| None,
        );

        // This is exactly the path `reconnect_streaming` takes when failed
        // is non-empty: build the structured `PartialReconnect` error.
        let err = if failed.is_empty() {
            None
        } else {
            Some(Error::PartialReconnect { failed })
        };

        match err {
            Some(Error::PartialReconnect { failed }) => {
                assert_eq!(failed.len(), 1);
                assert_eq!(failed[0].0, SubscriptionKind::Quote);
                assert_eq!(failed[0].1, aapl);
            }
            other => panic!("expected PartialReconnect, got {other:?}"),
        }
    }
}
