//! Server configuration for direct `ThetaData` access.
//!
//! # Server topology (from decompiled Java + `config_0.properties`)
//!
//! `ThetaData` runs two server types in their NJ datacenter:
//!
//! ## MDDS — Market Data Distribution Server (gRPC, historical data)
//!
//! The v1/v2 config listed multiple socket-level hosts:
//! ```text
//! MDDS_NJ_HOSTS=nj-a.thetadata.us:12000,nj-a.thetadata.us:12001,
//!               nj-b.thetadata.us:12000,nj-b.thetadata.us:12001
//! ```
//!
//! But the v3 terminal uses a **single gRPC endpoint** over TLS:
//! ```text
//! mdds-01.thetadata.us:443
//! ```
//!
//! Source: `MddsConnectionManager` in decompiled terminal — the v3 code path
//! constructs a gRPC channel to `mdds-01.thetadata.us:443` with TLS, ignoring
//! the multi-host config entirely.
//!
//! ## FPSS — Feed Processing Streaming Server (TCP, real-time streaming)
//!
//! FPSS still uses the multi-host config with round-robin failover:
//! ```text
//! FPSS_NJ_HOSTS=nj-a.thetadata.us:20000,nj-a.thetadata.us:20001,
//!               nj-b.thetadata.us:20000,nj-b.thetadata.us:20001
//! ```
//!
//! Source: `FpssConnectionManager` in decompiled terminal — iterates through
//! hosts on connection failure.

use std::sync::Arc;
use std::time::Duration;

use tdbe::types::enums::RemoveReason;

use crate::error::Error;

// ── Environment variable names ────────────────────────────────────────────
//
// Two groups:
//
// * Compatibility set (`THETADATA_MDDS_HOST`, `THETADATA_MDDS_PORT`,
//   `THETADATA_EMAIL`, `THETADATA_PASSWORD`) — environment variable names
//   operators already use to configure existing `ThetaData` clients;
//   reusing them here means an existing shell config keeps working.
// * DX extensions — cover surfaces that were previously hardcoded (Nexus
//   URL, FPSS host/port, `client_type`) so site operators can steer
//   traffic at a staging cluster without a code change.
//
// Precedence is documented on `DirectConfig`: explicit builder setter >
// env var > hardcoded default.

/// MDDS gRPC host.
pub const ENV_MDDS_HOST: &str = "THETADATA_MDDS_HOST";
/// MDDS gRPC port.
pub const ENV_MDDS_PORT: &str = "THETADATA_MDDS_PORT";
/// Nexus auth base URL override.
pub const ENV_NEXUS_URL: &str = "THETADATA_NEXUS_URL";
/// FPSS hostname override. Replaces the primary FPSS host slot; fallback
/// hosts are preserved.
pub const ENV_FPSS_HOST: &str = "THETADATA_FPSS_HOST";
/// FPSS port override. Pairs with [`ENV_FPSS_HOST`].
pub const ENV_FPSS_PORT: &str = "THETADATA_FPSS_PORT";
/// `QueryInfo.client_type` override — steer server-side quotas and
/// dashboards to treat a deployment as a named fleet.
pub const ENV_CLIENT_TYPE: &str = "THETADATA_CLIENT_TYPE";

/// Controls FPSS reconnection behavior after a disconnect.
///
/// # Default
///
/// [`ReconnectPolicy::Auto`] matches the Java terminal's `handleInvoluntaryDisconnect()`:
/// permanent errors stop immediately, `TooManyRequests` waits 130s, everything else
/// waits 2s, up to 5 attempts.
///
/// # Custom
///
/// Supply a closure that receives the disconnect reason and attempt number (1-based)
/// and returns `Some(delay)` to reconnect after that delay, or `None` to stop.
#[derive(Clone, Default)]
pub enum ReconnectPolicy {
    /// Auto-reconnect matching Java terminal behavior (default).
    ///
    /// - Permanent errors (invalid credentials, account issues): no reconnect.
    /// - `TooManyRequests`: 130s wait.
    /// - All others: 2s wait.
    /// - Up to 5 consecutive reconnect attempts before giving up.
    #[default]
    Auto,
    /// No auto-reconnect. User calls `reconnect_streaming()` manually.
    Manual,
    /// User-provided function: `(reason, attempt_number) -> Option<Duration>`.
    ///
    /// Return `Some(delay)` to reconnect after `delay`, `None` to stop.
    /// `attempt_number` starts at 1 and increments on each consecutive reconnect.
    Custom(Arc<dyn Fn(RemoveReason, u32) -> Option<Duration> + Send + Sync>),
}

impl std::fmt::Debug for ReconnectPolicy {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Auto => write!(f, "Auto"),
            Self::Manual => write!(f, "Manual"),
            Self::Custom(_) => write!(f, "Custom(...)"),
        }
    }
}

/// Controls when the FPSS write buffer is flushed.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub enum FpssFlushMode {
    /// Flush only on PING frames (every 100ms). Matches Java terminal.
    /// Lower syscall overhead, up to 100ms additional latency.
    #[default]
    Batched,
    /// Flush after every frame write. Lowest latency, higher syscall overhead.
    Immediate,
}

/// Exponential-backoff retry policy for transient gRPC errors on MDDS.
///
/// Only wired on status codes `Unavailable`, `DeadlineExceeded`, and
/// `ResourceExhausted`. Permission / credential failures route through
/// the separate auto-refresh path (see the in-crate `MddsClient` wrappers)
/// and are never retried by this policy.
///
/// # Jitter
///
/// With `jitter = true` (default) the sleep duration follows AWS's
/// *full jitter* pattern: `delay = rand(0, min(max_delay, initial *
/// 2^attempt))`. Full jitter provably minimises retry-storm contention
/// relative to equal jitter or no jitter; see
/// <https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/>.
///
/// With `jitter = false` the delay is the deterministic backoff
/// `min(max_delay, initial * 2^attempt)`. Useful for tests that
/// need to assert exact timings.
#[derive(Debug, Clone, Copy)]
pub struct RetryPolicy {
    /// Delay used for the first retry (attempt 1). Doubles per attempt.
    pub initial_delay: Duration,
    /// Upper bound on the computed backoff delay, regardless of attempt.
    pub max_delay: Duration,
    /// Total attempt budget. `1` disables retry (single call only);
    /// `0` still permits the initial call but allows no retries.
    pub max_attempts: u32,
    /// Apply AWS-style full jitter to each retry delay.
    pub jitter: bool,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            initial_delay: Duration::from_millis(250),
            max_delay: Duration::from_secs(30),
            max_attempts: 5,
            jitter: true,
        }
    }
}

impl RetryPolicy {
    /// Build a policy with retry disabled — single attempt, no backoff.
    #[must_use]
    pub fn disabled() -> Self {
        Self {
            initial_delay: Duration::ZERO,
            max_delay: Duration::ZERO,
            max_attempts: 1,
            jitter: false,
        }
    }

    /// Compute the sleep delay before the next retry.
    ///
    /// `attempt` is 1-based (attempt 1 = first retry after the initial
    /// call failed). The returned duration is:
    ///
    /// * capped at `max_delay`,
    /// * exponentiated as `initial_delay * 2^(attempt - 1)`,
    /// * jittered (when `self.jitter`) across `[0, capped_delay]`.
    ///
    /// Overflow in `initial_delay * 2^(attempt - 1)` saturates at
    /// `max_delay` rather than wrapping, so pathological `attempt`
    /// values never yield a zero delay.
    #[must_use]
    pub fn delay_for_attempt(&self, attempt: u32) -> Duration {
        let capped = self.capped_backoff(attempt);
        if self.jitter {
            jitter_sample(capped)
        } else {
            capped
        }
    }

    /// Deterministic capped backoff (no jitter). Exposed for tests that
    /// need to assert the upper-bound envelope for a given attempt.
    #[must_use]
    pub fn capped_backoff(&self, attempt: u32) -> Duration {
        if attempt == 0 {
            return Duration::ZERO;
        }
        // `shift = attempt - 1` so attempt 1 = base, attempt 2 = base*2,
        // attempt 3 = base*4. `u32::checked_shl(shift)` overflows
        // exactly when `shift >= 32`; clamp before shifting.
        let shift = (attempt - 1).min(31);
        let base_nanos = self.initial_delay.as_nanos();
        let scaled_nanos = base_nanos.checked_shl(shift).unwrap_or(u128::MAX);
        let max_nanos = self.max_delay.as_nanos();
        let nanos = scaled_nanos.min(max_nanos);
        // `Duration::from_nanos` takes u64 — clamp rather than truncate.
        Duration::from_nanos(u64::try_from(nanos).unwrap_or(u64::MAX))
    }
}

/// Full-jitter sampler: uniform on `[0, ceiling]`. Uses the `Instant`-
/// derived nanosecond clock as an entropy source so we do not pull in
/// a dedicated RNG crate — sufficient for jitter randomisation where
/// the statistical quality requirement is "any non-pathological spread
/// across callers", not cryptographic randomness.
fn jitter_sample(ceiling: Duration) -> Duration {
    let ceiling_nanos = ceiling.as_nanos();
    if ceiling_nanos == 0 {
        return Duration::ZERO;
    }
    // `Instant::elapsed` inside a test might return 0 on some CI
    // schedulers; folding both `elapsed` and a process-local counter
    // guarantees the sampler advances even then.
    use std::sync::atomic::{AtomicU64, Ordering};
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let tick = COUNTER.fetch_add(1, Ordering::Relaxed);
    let now_nanos = u64::try_from(
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos()),
    )
    .unwrap_or(u64::MAX);
    // Reason: splitmix64 constants — documented mixer, fine for jitter.
    let mut seed = now_nanos ^ tick.wrapping_mul(0x9E37_79B9_7F4A_7C15);
    seed ^= seed >> 30;
    seed = seed.wrapping_mul(0xBF58_476D_1CE4_E5B9);
    seed ^= seed >> 27;
    seed = seed.wrapping_mul(0x94D0_49BB_1331_11EB);
    seed ^= seed >> 31;
    let ceiling_u128 = ceiling_nanos;
    let bounded = u128::from(seed) % (ceiling_u128 + 1);
    Duration::from_nanos(u64::try_from(bounded).unwrap_or(u64::MAX))
}

/// Configuration for connecting to `ThetaData` servers directly.
///
/// Use [`DirectConfig::production()`] for the standard NJ production servers.
///
/// # Environment variable overrides
///
/// [`DirectConfig::production()`] reads the following environment variables
/// and applies them on top of the hardcoded defaults. Explicit builder
/// setters (`.with_metrics_port(...)` etc.) take precedence over env vars,
/// which in turn take precedence over the hardcoded defaults.
///
/// | Variable | Type | Effect |
/// |---|---|---|
/// | `THETADATA_MDDS_HOST` | host | overrides `mdds_host` |
/// | `THETADATA_MDDS_PORT` | u16  | overrides `mdds_port` |
/// | `THETADATA_NEXUS_URL` | url  | overrides the Nexus auth URL |
/// | `THETADATA_FPSS_HOST` | host | overrides the primary FPSS host |
/// | `THETADATA_FPSS_PORT` | u16  | overrides the primary FPSS port |
/// | `THETADATA_CLIENT_TYPE` | str | overrides `QueryInfo.client_type` |
/// | `THETADATA_EMAIL`       | str | credential helper ([`crate::auth`]) |
/// | `THETADATA_PASSWORD`    | str | credential helper ([`crate::auth`]) |
///
/// Malformed values (e.g. a non-integer `THETADATA_MDDS_PORT`) are ignored
/// with a `tracing::warn!` — the hardcoded default is retained so a typo
/// in the environment never silently breaks production.
#[derive(Debug, Clone)]
pub struct DirectConfig {
    // -- MDDS (gRPC) --
    /// MDDS gRPC hostname.
    ///
    /// Source: `MddsConnectionManager` in decompiled terminal (v3 path).
    pub mdds_host: String,

    /// MDDS gRPC port (443 for TLS in production).
    pub mdds_port: u16,

    /// Whether to use TLS for the MDDS gRPC connection.
    /// Always `true` in production (standard gRPC-over-TLS on port 443).
    pub mdds_tls: bool,

    // -- FPSS (TCP) --
    /// FPSS TCP hosts with round-robin failover.
    ///
    /// Source: `FPSS_NJ_HOSTS` in `config_0.properties` — the terminal
    /// iterates through these on connection failure.
    pub fpss_hosts: Vec<(String, u16)>,

    // -- FPSS tuning --
    /// FPSS connection/read timeout in milliseconds.
    ///
    /// Source: `FPSS_TIMEOUT=10000` in `config_0.properties`.
    pub fpss_timeout_ms: u64,

    /// FPSS event channel buffer depth.
    /// Caller should pass this to `FpssClient::connect(creds, fpss_queue_depth)`.
    /// Increase if stream events are being dropped under high volume.
    ///
    /// JVM equivalent: `FPSS_QUEUE_DEPTH=1000000` in `config_0.properties`.
    ///
    /// NOTE: Not automatically wired — caller must pass to `FpssClient::connect()`.
    pub fpss_queue_depth: usize,

    /// FPSS disruptor ring buffer size (slots, will be rounded up to a power of 2).
    ///
    /// The LMAX Disruptor ring buffer used for lock-free event dispatch requires
    /// a power-of-2 size. This value is rounded up automatically. Larger rings
    /// absorb more burst traffic but use more memory (~`ring_size * sizeof(Option<FpssEvent>)`).
    ///
    /// Derived from `fpss_queue_depth` by default. Override for fine-grained control.
    pub fpss_ring_size: usize,

    /// FPSS heartbeat ping interval in milliseconds.
    /// The protocol requires pings every 100ms; changing this may cause disconnects.
    ///
    /// Source: `FPSSClient.startPinging()` — timer period = 100ms.
    ///
    /// NOTE: Not automatically wired — the ping loop uses `protocol::PING_INTERVAL_MS`.
    /// Override that constant or pass this value when a configurable ping loop is added.
    pub fpss_ping_interval_ms: u64,

    /// Per-server TCP connect timeout in milliseconds.
    ///
    /// Source: `FPSSClient` — `socket.connect(addr, 2000)`.
    ///
    /// NOTE: Not automatically wired — the connection module uses `protocol::CONNECT_TIMEOUT_MS`.
    /// Override that constant or pass this value when a configurable connect is added.
    pub fpss_connect_timeout_ms: u64,

    /// Controls when the FPSS write buffer is flushed.
    ///
    /// - [`FpssFlushMode::Batched`] (default): only flush on PING frames (~100ms),
    ///   matching the Java terminal. Lower syscall overhead.
    /// - [`FpssFlushMode::Immediate`]: flush after every frame write. Lowest
    ///   latency, higher syscall overhead.
    pub fpss_flush_mode: FpssFlushMode,

    // -- MDDS tuning --
    /// Max concurrent in-flight gRPC requests.
    ///
    /// JVM equivalent: `2^subscription_tier` (Free=1, Value=2, Standard=4, Pro=8).
    /// Set to 0 to auto-detect from the subscription tier returned by Nexus auth.
    pub mdds_concurrent_requests: usize,

    /// Max inbound gRPC message size in bytes.
    ///
    /// JVM equivalent: `maxInboundMessageSize(0x100000 * config.messageSize())`,
    /// default 4MB, max 10MB.
    pub mdds_max_message_size: usize,

    /// gRPC keepalive interval in seconds.
    ///
    /// Source: `ChannelProvider` — `keepAliveTime(30, SECONDS)`.
    pub mdds_keepalive_secs: u64,

    /// gRPC keepalive timeout in seconds.
    ///
    /// Source: `ChannelProvider` — `keepAliveTimeout(10, SECONDS)`.
    pub mdds_keepalive_timeout_secs: u64,

    /// gRPC flow control: initial stream window size in KB.
    ///
    /// Maps to `tonic::transport::Endpoint::initial_stream_window_size`.
    /// Default 64 KB matches HTTP/2 spec default.
    pub mdds_window_size_kb: usize,

    /// gRPC flow control: initial connection window size in KB.
    ///
    /// Maps to `tonic::transport::Endpoint::initial_connection_window_size`.
    /// Default 64 KB. Increase for high-throughput bulk queries.
    pub mdds_connection_window_size_kb: usize,

    // -- Reconnection --
    /// Delay before attempting reconnection after a disconnect, in milliseconds.
    ///
    /// Source: `FPSSClient.RECONNECT_DELAY_MS = 2000` in decompiled terminal.
    /// Note: `config_0.properties` has `RECONNECT_WAIT=1000` but the Java code
    /// uses the constant `2000` at runtime.
    ///
    /// NOTE: Not automatically wired — consumed by
    /// [`crate::ThetaDataDx::reconnect_streaming`] / the FPSS auto-reconnect path.
    pub reconnect_wait_ms: u64,

    /// Delay before reconnecting after a `TooManyRequests` disconnect, in milliseconds.
    ///
    /// Source: `FPSSClient.handleInvoluntaryDisconnect()` — 130 second wait.
    ///
    /// NOTE: Not automatically wired — consumed by
    /// [`crate::ThetaDataDx::reconnect_streaming`] / the FPSS auto-reconnect path.
    pub reconnect_wait_rate_limited_ms: u64,

    // -- Reconnection policy --
    /// Controls FPSS auto-reconnection behavior after involuntary disconnect.
    ///
    /// Default: [`ReconnectPolicy::Auto`] — matches Java terminal behavior.
    pub reconnect_policy: ReconnectPolicy,

    // -- OHLCVC derivation --
    /// Whether to derive OHLCVC bars locally from trade events.
    ///
    /// When `true` (default), the FPSS client emits derived `FpssData::Ohlcvc`
    /// events after each trade. When `false`, only server-sent OHLCVC frames
    /// (wire code 24) are emitted, reducing per-trade throughput overhead.
    ///
    /// The Java terminal always derives OHLCVC with no way to disable it.
    pub derive_ohlcvc: bool,

    // -- Threading --
    /// Number of tokio worker threads. `None` = tokio default (number of CPU cores).
    ///
    /// JVM equivalent: `-Xmx` + `HTTP_CONCURRENCY` thread pool sizing.
    ///
    /// NOTE: Not automatically wired — caller should use this when building
    /// a custom tokio runtime.
    pub tokio_worker_threads: Option<usize>,

    // -- Retry / reliability --
    /// Exponential-backoff retry policy for transient gRPC errors on MDDS.
    /// See [`RetryPolicy`] for defaults and the list of retried status codes.
    pub retry_policy: RetryPolicy,

    // -- Endpoints overridable via env --
    /// Nexus auth URL. Default matches the upstream production endpoint; set
    /// [`ENV_NEXUS_URL`] to redirect at a staging cluster.
    pub nexus_url: String,

    /// Value used for `QueryInfo.client_type`. Defaults to `"rust-thetadatadx"`;
    /// override via [`ENV_CLIENT_TYPE`] to identify a deployment fleet in
    /// server-side dashboards.
    pub client_type: String,

    // -- Observability --
    /// Port the Prometheus exporter binds to when the `metrics-prometheus`
    /// cargo feature is enabled. `None` disables the exporter even when the
    /// feature is compiled in; `Some(port)` starts an HTTP listener on
    /// `0.0.0.0:<port>` whose `/metrics` endpoint exposes every counter
    /// and histogram recorded through the `metrics` crate.
    pub metrics_port: Option<u16>,
}

impl DirectConfig {
    /// Default Nexus auth URL (matches the upstream production endpoint).
    pub const DEFAULT_NEXUS_URL: &'static str =
        "https://nexus-api.thetadata.us/identity/terminal/auth_user";

    /// Default `QueryInfo.client_type`.
    pub const DEFAULT_CLIENT_TYPE: &'static str = "rust-thetadatadx";

    /// Production configuration for `ThetaData`'s NJ datacenter.
    ///
    /// All values extracted from the decompiled Java terminal:
    /// - MDDS: `mdds-01.thetadata.us:443` (gRPC over TLS)
    /// - FPSS: 4 hosts from `config_0.properties` `FPSS_NJ_HOSTS`
    /// - Timeouts: from `config_0.properties`
    ///
    /// Environment variables listed on [`DirectConfig`] are layered on
    /// top of these defaults.
    #[must_use]
    pub fn production() -> Self {
        let mut config = Self::production_defaults();
        config.apply_env_overrides();
        config.validate()
    }

    /// Production defaults without env-var overrides. Tests use this to
    /// assert the hardcoded shape in isolation; every caller that wants
    /// env-var precedence should reach for [`DirectConfig::production`].
    #[must_use]
    pub(crate) fn production_defaults() -> Self {
        Self {
            // Source: MddsConnectionManager (v3 gRPC path)
            mdds_host: "mdds-01.thetadata.us".to_string(),
            mdds_port: 443,
            mdds_tls: true,

            // Source: config_0.properties FPSS_NJ_HOSTS
            fpss_hosts: vec![
                ("nj-a.thetadata.us".to_string(), 20000),
                ("nj-a.thetadata.us".to_string(), 20001),
                ("nj-b.thetadata.us".to_string(), 20000),
                ("nj-b.thetadata.us".to_string(), 20001),
            ],

            // Source: config_0.properties
            fpss_timeout_ms: 10_000,
            fpss_queue_depth: 1_000_000,    // FPSS_QUEUE_DEPTH
            fpss_ring_size: 131_072,        // 2^17, covers ~13s at 10k events/sec
            fpss_ping_interval_ms: 100,     // FPSSClient.startPinging()
            fpss_connect_timeout_ms: 2_000, // FPSSClient socket.connect timeout
            fpss_flush_mode: FpssFlushMode::Batched,

            // Concurrency: 0 = auto-detect from subscription tier at auth time.
            mdds_concurrent_requests: 0,

            // Source: ChannelProvider in decompiled terminal
            mdds_max_message_size: 4 * 1024 * 1024, // 4MB default
            mdds_keepalive_secs: 30,
            mdds_keepalive_timeout_secs: 10,

            // gRPC flow control (HTTP/2 spec defaults)
            mdds_window_size_kb: 64,
            mdds_connection_window_size_kb: 64,

            // Source: FPSSClient.RECONNECT_DELAY_MS = 2000 in decompiled terminal
            reconnect_wait_ms: 2_000,
            reconnect_wait_rate_limited_ms: 130_000, // FPSSClient: 130s for TooManyRequests

            // Auto-reconnect matches Java terminal behavior by default
            reconnect_policy: ReconnectPolicy::Auto,

            // Derive OHLCVC from trades by default (matches Java terminal)
            derive_ohlcvc: true,

            // Default: use all CPU cores
            tokio_worker_threads: None,

            retry_policy: RetryPolicy::default(),
            nexus_url: Self::DEFAULT_NEXUS_URL.to_string(),
            client_type: Self::DEFAULT_CLIENT_TYPE.to_string(),
            metrics_port: None,
        }
    }

    /// Apply the documented [`DirectConfig`] env-var matrix on top of the
    /// receiver. Unknown / malformed values are logged and skipped so a
    /// typo never silently flips production to the wrong endpoint.
    fn apply_env_overrides(&mut self) {
        if let Ok(host) = std::env::var(ENV_MDDS_HOST) {
            let trimmed = host.trim();
            if !trimmed.is_empty() {
                self.mdds_host = trimmed.to_string();
            }
        }
        if let Ok(port_str) = std::env::var(ENV_MDDS_PORT) {
            match port_str.trim().parse::<u16>() {
                Ok(port) if port > 0 => self.mdds_port = port,
                _ => tracing::warn!(
                    env = ENV_MDDS_PORT,
                    value = %port_str,
                    "ignoring malformed env var; keeping hardcoded default"
                ),
            }
        }
        if let Ok(url) = std::env::var(ENV_NEXUS_URL) {
            let trimmed = url.trim();
            if !trimmed.is_empty() {
                self.nexus_url = trimmed.to_string();
            }
        }
        if let Ok(client_type) = std::env::var(ENV_CLIENT_TYPE) {
            let trimmed = client_type.trim();
            if !trimmed.is_empty() {
                self.client_type = trimmed.to_string();
            }
        }
        // FPSS host/port are mirrored as a (host, port) tuple in the
        // primary slot. If only one of the pair is set we keep the
        // default for the other half rather than guessing.
        let env_host = std::env::var(ENV_FPSS_HOST).ok();
        let env_port = std::env::var(ENV_FPSS_PORT).ok();
        if env_host.is_some() || env_port.is_some() {
            if self.fpss_hosts.is_empty() {
                // Empty defaults would mean "no primary to override".
                // Skip silently — production_defaults seeds 4 hosts, so
                // this only fires for hand-built configs.
                tracing::warn!(
                    "ignoring THETADATA_FPSS_HOST / THETADATA_FPSS_PORT; \
                     DirectConfig has no FPSS hosts to override"
                );
            } else {
                let (default_host, default_port) = self.fpss_hosts[0].clone();
                let host = env_host
                    .as_deref()
                    .map(str::trim)
                    .filter(|s| !s.is_empty())
                    .map_or(default_host, str::to_string);
                let port = env_port
                    .as_deref()
                    .and_then(|raw| match raw.trim().parse::<u16>() {
                        Ok(p) if p > 0 => Some(p),
                        _ => {
                            tracing::warn!(
                                env = ENV_FPSS_PORT,
                                value = %raw,
                                "ignoring malformed env var; keeping hardcoded default"
                            );
                            None
                        }
                    })
                    .unwrap_or(default_port);
                self.fpss_hosts[0] = (host, port);
            }
        }
    }

    /// Dev FPSS configuration.
    ///
    /// Connects to `ThetaData`'s dev FPSS servers (port 20200) which replay
    /// a random historical trading day in an infinite loop at maximum speed.
    /// Designed for development and testing when markets are closed.
    ///
    /// MDDS (historical) still uses production servers -- there is no dev MDDS.
    ///
    /// Source: `config.toml` `fpss_dev_hosts` and
    /// <https://docs.thetadata.us/Streaming/Getting-Started.html>
    ///
    /// Note: dev server replays data at max speed, so queue and ring sizes
    /// match production to avoid drops. Some contracts may not exist on
    /// the replayed day.
    #[must_use]
    pub fn dev() -> Self {
        let mut config = Self::production();
        // Source: config.toml fpss_dev_hosts
        config.fpss_hosts = vec![
            ("nj-a.thetadata.us".to_string(), 20200),
            ("test-server.thetadata.us".to_string(), 20200),
            ("test-server.thetadata.us".to_string(), 20201),
        ];
        config.validate()
    }

    /// Stage FPSS configuration.
    ///
    /// Connects to `ThetaData`'s staging FPSS servers (port 20100).
    /// Frequent reboots, testing data. Not stable.
    ///
    /// MDDS (historical) still uses production servers.
    ///
    /// Source: `config.toml` `fpss_stage_hosts`
    #[must_use]
    pub fn stage() -> Self {
        let mut config = Self::production();
        // Source: config.toml fpss_stage_hosts
        config.fpss_hosts = vec![
            ("nj-a.thetadata.us".to_string(), 20100),
            ("test-server.thetadata.us".to_string(), 20100),
            ("test-server.thetadata.us".to_string(), 20101),
        ];
        config.validate()
    }

    /// Validate configuration values and clamp out-of-range fields, logging
    /// a warning for each clamped value.
    ///
    /// Called automatically by [`production()`](Self::production),
    /// [`dev()`](Self::dev), and [`stage()`](Self::stage). Also useful after
    /// loading from a TOML file or modifying fields programmatically.
    #[must_use]
    pub fn validate(mut self) -> Self {
        self.fpss_queue_depth = self.fpss_queue_depth.clamp(16, 1_000_000);
        self.mdds_window_size_kb = self.mdds_window_size_kb.clamp(64, 1_024);
        self.mdds_connection_window_size_kb = self.mdds_connection_window_size_kb.clamp(64, 1_024);
        self
    }

    /// Build the MDDS gRPC endpoint URI.
    ///
    /// Returns a URI suitable for `tonic::transport::Channel::from_static()`.
    #[must_use]
    pub fn mdds_uri(&self) -> String {
        let scheme = if self.mdds_tls { "https" } else { "http" };
        format!("{}://{}:{}", scheme, self.mdds_host, self.mdds_port)
    }

    /// Set whether to derive OHLCVC bars locally from trade events.
    ///
    /// When `false`, only server-sent OHLCVC frames are emitted,
    /// reducing per-trade throughput overhead.
    #[must_use]
    pub fn derive_ohlcvc(mut self, enabled: bool) -> Self {
        self.derive_ohlcvc = enabled;
        self
    }

    /// Set the port the Prometheus exporter should bind to when the
    /// `metrics-prometheus` cargo feature is enabled. The exporter
    /// exposes `/metrics` over HTTP on `0.0.0.0:<port>`.
    #[must_use]
    pub fn with_metrics_port(mut self, port: u16) -> Self {
        self.metrics_port = Some(port);
        self
    }

    /// Override the retry policy for transient gRPC errors.
    #[must_use]
    pub fn with_retry_policy(mut self, policy: RetryPolicy) -> Self {
        self.retry_policy = policy;
        self
    }

    /// Override the Nexus auth URL. Intended for staging deployments —
    /// production should use [`ENV_NEXUS_URL`] or the default.
    #[must_use]
    pub fn with_nexus_url(mut self, url: impl Into<String>) -> Self {
        self.nexus_url = url.into();
        self
    }

    /// Override `QueryInfo.client_type`. Appears in server-side logs
    /// and dashboards; useful for tagging a deployment fleet.
    #[must_use]
    pub fn with_client_type(mut self, client_type: impl Into<String>) -> Self {
        self.client_type = client_type.into();
        self
    }

    /// Parse FPSS hosts from a comma-separated `host:port,host:port,...` string.
    ///
    /// This is the format used in `config_0.properties` for `FPSS_NJ_HOSTS`.
    /// # Errors
    ///
    /// Returns an error on network, authentication, or parsing failure.
    pub fn parse_fpss_hosts(hosts_str: &str) -> Result<Vec<(String, u16)>, Error> {
        let mut result = Vec::new();

        for entry in hosts_str.split(',') {
            let entry = entry.trim();
            if entry.is_empty() {
                continue;
            }

            let (host, port_str) = entry
                .rsplit_once(':')
                .ok_or_else(|| Error::Config(format!("invalid host:port entry: '{entry}'")))?;

            let port: u16 = port_str
                .parse()
                .map_err(|e| Error::Config(format!("invalid port in '{entry}': {e}")))?;

            result.push((host.to_string(), port));
        }

        if result.is_empty() {
            return Err(Error::Config("no FPSS hosts provided".to_string()));
        }

        Ok(result)
    }
}

// ── Config file loading (behind `config-file` feature) ──────────────────────

#[cfg(feature = "config-file")]
mod config_file {
    use super::{DirectConfig, FpssFlushMode};
    use crate::error::Error;
    use serde::Deserialize;

    /// TOML-level representation of the config file.
    ///
    /// Unknown keys are silently ignored (`#[serde(default)]` on each section).
    /// Missing sections fall back to production defaults.
    #[derive(Debug, Default, Deserialize)]
    #[serde(default)]
    struct ConfigFile {
        mdds: MddsSection,
        fpss: FpssSection,
        grpc: GrpcSection,
        auth: AuthSection,
    }

    #[derive(Debug, Deserialize)]
    #[serde(default)]
    struct MddsSection {
        host: String,
        port: u16,
        tls: bool,
        keepalive_time_secs: u64,
        keepalive_timeout_secs: u64,
        max_message_size: usize,
    }

    impl Default for MddsSection {
        fn default() -> Self {
            let prod = DirectConfig::production();
            Self {
                host: prod.mdds_host,
                port: prod.mdds_port,
                tls: prod.mdds_tls,
                keepalive_time_secs: prod.mdds_keepalive_secs,
                keepalive_timeout_secs: prod.mdds_keepalive_timeout_secs,
                max_message_size: prod.mdds_max_message_size,
            }
        }
    }

    #[derive(Debug, Deserialize)]
    #[serde(default)]
    struct FpssSection {
        /// Hosts as `["host:port", ...]` array or `"host:port,host:port"` string.
        hosts: FpssHosts,
        connect_timeout: u64,
        read_timeout: u64,
        ping_interval: u64,
        reconnect_wait: u64,
        reconnect_wait_rate_limited: u64,
        queue_depth: usize,
        ring_size: usize,
        flush_mode: String,
    }

    impl Default for FpssSection {
        fn default() -> Self {
            let prod = DirectConfig::production();
            Self {
                hosts: FpssHosts::Array(
                    prod.fpss_hosts
                        .iter()
                        .map(|(h, p)| format!("{h}:{p}"))
                        .collect(),
                ),
                connect_timeout: prod.fpss_connect_timeout_ms,
                read_timeout: prod.fpss_timeout_ms,
                ping_interval: prod.fpss_ping_interval_ms,
                reconnect_wait: prod.reconnect_wait_ms,
                reconnect_wait_rate_limited: prod.reconnect_wait_rate_limited_ms,
                queue_depth: prod.fpss_queue_depth,
                ring_size: prod.fpss_ring_size,
                flush_mode: "batched".to_string(),
            }
        }
    }

    /// FPSS hosts can be specified as either a TOML array or a comma-separated string.
    #[derive(Debug, Deserialize)]
    #[serde(untagged)]
    enum FpssHosts {
        Array(Vec<String>),
        Csv(String),
    }

    impl Default for FpssHosts {
        fn default() -> Self {
            let prod = DirectConfig::production();
            FpssHosts::Array(
                prod.fpss_hosts
                    .iter()
                    .map(|(h, p)| format!("{h}:{p}"))
                    .collect(),
            )
        }
    }

    #[derive(Debug, Deserialize)]
    #[serde(default)]
    struct GrpcSection {
        window_size_kb: usize,
        connection_window_size_kb: usize,
        max_message_size_mb: usize,
        concurrent_requests: usize,
    }

    impl Default for GrpcSection {
        fn default() -> Self {
            let prod = DirectConfig::production();
            Self {
                window_size_kb: prod.mdds_window_size_kb,
                connection_window_size_kb: prod.mdds_connection_window_size_kb,
                max_message_size_mb: prod.mdds_max_message_size / (1024 * 1024),
                concurrent_requests: prod.mdds_concurrent_requests,
            }
        }
    }

    #[derive(Debug, Default, Deserialize)]
    #[serde(default)]
    struct AuthSection {
        #[serde(rename = "creds_file")]
        _creds_file: Option<String>,
    }

    impl FpssHosts {
        fn parse(self) -> Result<Vec<(String, u16)>, Error> {
            let entries = match self {
                FpssHosts::Array(arr) => arr,
                FpssHosts::Csv(s) => s.split(',').map(|s| s.trim().to_string()).collect(),
            };
            let mut result = Vec::new();
            for entry in entries {
                let entry = entry.trim();
                if entry.is_empty() {
                    continue;
                }
                let (host, port_str) = entry
                    .rsplit_once(':')
                    .ok_or_else(|| Error::Config(format!("invalid host:port entry: '{entry}'")))?;
                let port: u16 = port_str
                    .parse()
                    .map_err(|e| Error::Config(format!("invalid port in '{entry}': {e}")))?;
                result.push((host.to_string(), port));
            }
            if result.is_empty() {
                return Err(Error::Config("no FPSS hosts provided".to_string()));
            }
            Ok(result)
        }
    }

    impl DirectConfig {
        /// Load configuration from a TOML file.
        ///
        /// The file format matches `config.default.toml` shipped with the crate.
        /// Missing sections and keys fall back to [`DirectConfig::production()`] defaults.
        /// Unknown keys are silently ignored.
        ///
        /// # Example file
        ///
        /// ```toml
        /// [mdds]
        /// host = "mdds-01.thetadata.us"
        /// port = 443
        /// tls = true
        ///
        /// [fpss]
        /// hosts = ["nj-a.thetadata.us:20000", "nj-b.thetadata.us:20000"]
        /// reconnect_wait = 2000
        /// queue_depth = 1_000_000
        /// flush_mode = "batched"  # or "immediate"
        ///
        /// [grpc]
        /// window_size_kb = 64
        /// connection_window_size_kb = 64
        /// concurrent_requests = 0  # 0 = auto from tier
        /// ```
        /// # Errors
        ///
        /// Returns an error on network, authentication, or parsing failure.
        pub fn from_file(path: impl AsRef<std::path::Path>) -> Result<Self, Error> {
            let contents = std::fs::read_to_string(path.as_ref()).map_err(|e| {
                Error::Config(format!(
                    "failed to read config file '{}': {e}",
                    path.as_ref().display()
                ))
            })?;
            Self::from_toml_str(&contents)
        }

        /// Parse configuration from a TOML string.
        ///
        /// Same semantics as [`from_file`](Self::from_file) but takes a string directly.
        /// # Errors
        ///
        /// Returns an error on network, authentication, or parsing failure.
        pub fn from_toml_str(toml_str: &str) -> Result<Self, Error> {
            let cf: ConfigFile = toml::from_str(toml_str)
                .map_err(|e| Error::Config(format!("failed to parse TOML config: {e}")))?;

            let flush_mode = match cf.fpss.flush_mode.to_lowercase().as_str() {
                "immediate" => FpssFlushMode::Immediate,
                _ => FpssFlushMode::Batched,
            };

            // If [grpc].max_message_size_mb is set, it overrides [mdds].max_message_size.
            // The grpc section value is in MB; the mdds section value is in bytes.
            let max_message_size = if cf.grpc.max_message_size_mb
                != DirectConfig::production().mdds_max_message_size / (1024 * 1024)
            {
                cf.grpc.max_message_size_mb * 1024 * 1024
            } else {
                cf.mdds.max_message_size
            };

            Ok(DirectConfig {
                mdds_host: cf.mdds.host,
                mdds_port: cf.mdds.port,
                mdds_tls: cf.mdds.tls,

                fpss_hosts: cf.fpss.hosts.parse()?,
                fpss_timeout_ms: cf.fpss.read_timeout,
                fpss_queue_depth: cf.fpss.queue_depth,
                fpss_ring_size: cf.fpss.ring_size,
                fpss_ping_interval_ms: cf.fpss.ping_interval,
                fpss_connect_timeout_ms: cf.fpss.connect_timeout,
                fpss_flush_mode: flush_mode,

                mdds_concurrent_requests: cf.grpc.concurrent_requests,
                mdds_max_message_size: max_message_size,
                mdds_keepalive_secs: cf.mdds.keepalive_time_secs,
                mdds_keepalive_timeout_secs: cf.mdds.keepalive_timeout_secs,
                mdds_window_size_kb: cf.grpc.window_size_kb,
                mdds_connection_window_size_kb: cf.grpc.connection_window_size_kb,

                reconnect_wait_ms: cf.fpss.reconnect_wait,
                reconnect_wait_rate_limited_ms: cf.fpss.reconnect_wait_rate_limited,

                // TOML config cannot express custom closures; default to Auto.
                // Use the builder API to set Manual or Custom programmatically.
                reconnect_policy: super::ReconnectPolicy::Auto,

                // Default: derive OHLCVC from trades (matches production default).
                // Use the builder API to disable programmatically.
                derive_ohlcvc: true,

                tokio_worker_threads: None,

                // TOML does not surface RetryPolicy / observability fields
                // today — the builder API (`with_retry_policy`,
                // `with_metrics_port`, env vars) is the opt-in path.
                retry_policy: super::RetryPolicy::default(),
                nexus_url: DirectConfig::DEFAULT_NEXUS_URL.to_string(),
                client_type: DirectConfig::DEFAULT_CLIENT_TYPE.to_string(),
                metrics_port: None,
            }
            .validate())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn production_mdds_uri() {
        let config = DirectConfig::production();
        assert_eq!(config.mdds_uri(), "https://mdds-01.thetadata.us:443");
    }

    #[test]
    fn production_has_four_fpss_hosts() {
        let config = DirectConfig::production();
        assert_eq!(config.fpss_hosts.len(), 4);
    }

    #[test]
    fn production_default_reconnect_policy_is_auto() {
        let config = DirectConfig::production();
        assert!(matches!(config.reconnect_policy, ReconnectPolicy::Auto));
    }

    #[test]
    fn parse_fpss_hosts_parses_multi_host_csv_with_whitespace_and_empty_entries() {
        let hosts =
            DirectConfig::parse_fpss_hosts(" nj-a.thetadata.us:20000, ,nj-b.thetadata.us:20001 ")
                .unwrap();
        assert_eq!(hosts.len(), 2);
        assert_eq!(hosts[0], ("nj-a.thetadata.us".to_string(), 20000));
        assert_eq!(hosts[1], ("nj-b.thetadata.us".to_string(), 20001));
    }

    #[test]
    fn parse_fpss_hosts_rejects_malformed_entries() {
        assert!(DirectConfig::parse_fpss_hosts("").is_err());
        assert!(DirectConfig::parse_fpss_hosts("host:notaport").is_err());
        assert!(DirectConfig::parse_fpss_hosts("hostonly").is_err());
    }

    // -- Config file tests (only compiled with the `config-file` feature) --

    #[cfg(feature = "config-file")]
    mod config_file_tests {
        use crate::config::{DirectConfig, FpssFlushMode};

        #[test]
        fn empty_toml_gives_production_defaults() {
            let config = DirectConfig::from_toml_str("").unwrap();
            let prod = DirectConfig::production();
            assert_eq!(config.mdds_host, prod.mdds_host);
            assert_eq!(config.mdds_port, prod.mdds_port);
            assert_eq!(config.fpss_hosts.len(), prod.fpss_hosts.len());
            assert_eq!(config.fpss_queue_depth, prod.fpss_queue_depth);
        }

        #[test]
        fn partial_toml_overrides_only_specified() {
            let toml = r#"
                [mdds]
                host = "custom.example.com"
                port = 8443

                [fpss]
                queue_depth = 500000
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.mdds_host, "custom.example.com");
            assert_eq!(config.mdds_port, 8443);
            assert_eq!(config.fpss_queue_depth, 500000);
            // Unspecified fields keep production defaults
            assert!(config.mdds_tls);
        }

        #[test]
        fn fpss_hosts_as_array() {
            let toml = r#"
                [fpss]
                hosts = ["host-a.example.com:20000", "host-b.example.com:20001"]
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.fpss_hosts.len(), 2);
            assert_eq!(
                config.fpss_hosts[0],
                ("host-a.example.com".to_string(), 20000)
            );
            assert_eq!(
                config.fpss_hosts[1],
                ("host-b.example.com".to_string(), 20001)
            );
        }

        #[test]
        fn fpss_hosts_as_csv_string() {
            let toml = r#"
                [fpss]
                hosts = "host-a.example.com:20000,host-b.example.com:20001"
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.fpss_hosts.len(), 2);
            assert_eq!(config.fpss_hosts[0].0, "host-a.example.com");
        }

        #[test]
        fn flush_mode_immediate() {
            let toml = r#"
                [fpss]
                flush_mode = "immediate"
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.fpss_flush_mode, FpssFlushMode::Immediate);
        }

        #[test]
        fn flush_mode_batched_by_default() {
            let toml = r#"
                [fpss]
                flush_mode = "batched"
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.fpss_flush_mode, FpssFlushMode::Batched);
        }

        #[test]
        fn grpc_section_sets_window_sizes() {
            let toml = r#"
                [grpc]
                window_size_kb = 128
                connection_window_size_kb = 256
                concurrent_requests = 4
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.mdds_window_size_kb, 128);
            assert_eq!(config.mdds_connection_window_size_kb, 256);
            assert_eq!(config.mdds_concurrent_requests, 4);
        }

        #[test]
        fn grpc_max_message_size_mb_overrides_mdds_bytes() {
            let toml = r#"
                [grpc]
                max_message_size_mb = 8
            "#;
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.mdds_max_message_size, 8 * 1024 * 1024);
        }

        #[test]
        fn unknown_keys_are_ignored() {
            let toml = r#"
                [mdds]
                host = "mdds-01.thetadata.us"
                port = 443
                unknown_key = "should be ignored"

                [some_unknown_section]
                foo = "bar"
            "#;
            // Should not error
            let config = DirectConfig::from_toml_str(toml).unwrap();
            assert_eq!(config.mdds_port, 443);
        }

        #[test]
        fn full_config_default_toml_parses() {
            // Validate that config.default.toml (shipped with the crate) can be parsed.
            let default_toml = include_str!("../../../config.default.toml");
            let config = DirectConfig::from_toml_str(default_toml).unwrap();
            assert_eq!(config.mdds_host, "mdds-01.thetadata.us");
            assert_eq!(config.mdds_port, 443);
            assert_eq!(config.fpss_hosts.len(), 4);
        }

        #[test]
        fn invalid_toml_returns_error() {
            let result = DirectConfig::from_toml_str("this is not valid toml [[[");
            assert!(result.is_err());
            assert!(result.unwrap_err().to_string().contains("TOML"));
        }
    }

    // -- Validation tests --

    #[test]
    fn validate_clamps_out_of_range_values() {
        let mut config = DirectConfig::production_defaults();
        config.fpss_queue_depth = 5;
        config.mdds_window_size_kb = 2_048;
        let config = config.validate();
        assert_eq!(config.fpss_queue_depth, 16);
        assert_eq!(config.mdds_window_size_kb, 1_024);
    }

    #[test]
    fn validate_preserves_in_range_values() {
        let config = DirectConfig::production_defaults();
        let validated = config.validate();
        assert_eq!(validated.fpss_queue_depth, 1_000_000);
        assert_eq!(validated.mdds_window_size_kb, 64);
    }

    // ── RetryPolicy / env var tests ──────────────────────────────────

    #[test]
    fn retry_policy_default_shape_is_stable() {
        let p = RetryPolicy::default();
        assert_eq!(p.initial_delay, Duration::from_millis(250));
        assert_eq!(p.max_delay, Duration::from_secs(30));
        assert_eq!(p.max_attempts, 5);
        assert!(p.jitter);
    }

    #[test]
    fn retry_policy_capped_backoff_doubles_each_attempt_then_caps() {
        let p = RetryPolicy {
            initial_delay: Duration::from_millis(100),
            max_delay: Duration::from_millis(800),
            max_attempts: 10,
            jitter: false,
        };
        assert_eq!(p.capped_backoff(0), Duration::ZERO);
        assert_eq!(p.capped_backoff(1), Duration::from_millis(100));
        assert_eq!(p.capped_backoff(2), Duration::from_millis(200));
        assert_eq!(p.capped_backoff(3), Duration::from_millis(400));
        assert_eq!(p.capped_backoff(4), Duration::from_millis(800));
        // Saturates at max_delay; never exceeds the cap even on absurd attempt counts.
        assert_eq!(p.capped_backoff(5), Duration::from_millis(800));
        assert_eq!(p.capped_backoff(60), Duration::from_millis(800));
    }

    #[test]
    fn retry_policy_delay_for_attempt_respects_jitter_upper_bound() {
        let p = RetryPolicy {
            initial_delay: Duration::from_millis(100),
            max_delay: Duration::from_millis(1_000),
            max_attempts: 10,
            jitter: true,
        };
        // Full-jitter envelope: sample ∈ [0, capped_backoff(attempt)].
        // Exercise 200 draws per attempt to shake out off-by-one issues
        // without making the test flaky — every sample must land in
        // the closed interval above.
        for attempt in 1..=6u32 {
            let ceiling = p.capped_backoff(attempt);
            for _ in 0..200 {
                let delay = p.delay_for_attempt(attempt);
                assert!(
                    delay <= ceiling,
                    "attempt {attempt}: delay {delay:?} exceeded ceiling {ceiling:?}"
                );
            }
        }
    }

    #[test]
    fn retry_policy_delay_for_attempt_deterministic_without_jitter() {
        let p = RetryPolicy {
            initial_delay: Duration::from_millis(50),
            max_delay: Duration::from_millis(400),
            max_attempts: 5,
            jitter: false,
        };
        // No jitter → every draw equals the capped backoff envelope.
        for attempt in 1..=4u32 {
            let expected = p.capped_backoff(attempt);
            for _ in 0..16 {
                assert_eq!(p.delay_for_attempt(attempt), expected);
            }
        }
    }

    #[test]
    fn retry_policy_disabled_yields_single_attempt() {
        let p = RetryPolicy::disabled();
        assert_eq!(p.max_attempts, 1);
        assert_eq!(p.delay_for_attempt(1), Duration::ZERO);
        assert!(!p.jitter);
    }

    // `std::env` is a process-global singleton; the env-var tests use a
    // single mutex so they don't trample each other under
    // `cargo test -- --test-threads=N`. Each test keeps hold of the
    // guard for the duration of the config build + assertions.
    fn env_test_guard() -> std::sync::MutexGuard<'static, ()> {
        use std::sync::{Mutex, OnceLock};
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
    }

    fn clear_env_matrix() {
        // Unset every variable the `apply_env_overrides` path reads so
        // no test leaks into another. The guard above pins us as the
        // sole writer.
        unsafe {
            // Reason: test-only mutation; protected by env_test_guard.
            std::env::remove_var(ENV_MDDS_HOST);
            std::env::remove_var(ENV_MDDS_PORT);
            std::env::remove_var(ENV_NEXUS_URL);
            std::env::remove_var(ENV_FPSS_HOST);
            std::env::remove_var(ENV_FPSS_PORT);
            std::env::remove_var(ENV_CLIENT_TYPE);
        }
    }

    #[test]
    fn env_overrides_apply_on_production() {
        let _guard = env_test_guard();
        clear_env_matrix();
        unsafe {
            // Reason: test-only mutation; protected by env_test_guard.
            std::env::set_var(ENV_MDDS_HOST, "mdds.staging.example.com");
            std::env::set_var(ENV_MDDS_PORT, "8443");
            std::env::set_var(ENV_NEXUS_URL, "https://nexus.staging.example.com/auth");
            std::env::set_var(ENV_CLIENT_TYPE, "rust-thetadatadx-staging");
            std::env::set_var(ENV_FPSS_HOST, "fpss.staging.example.com");
            std::env::set_var(ENV_FPSS_PORT, "21000");
        }
        let config = DirectConfig::production();
        assert_eq!(config.mdds_host, "mdds.staging.example.com");
        assert_eq!(config.mdds_port, 8443);
        assert_eq!(config.nexus_url, "https://nexus.staging.example.com/auth");
        assert_eq!(config.client_type, "rust-thetadatadx-staging");
        assert_eq!(
            config.fpss_hosts[0],
            ("fpss.staging.example.com".to_string(), 21000)
        );
        clear_env_matrix();
    }

    #[test]
    fn builder_takes_precedence_over_env_var() {
        let _guard = env_test_guard();
        clear_env_matrix();
        unsafe {
            // Reason: test-only mutation; protected by env_test_guard.
            std::env::set_var(ENV_CLIENT_TYPE, "env-wins-when-no-builder");
        }
        let config = DirectConfig::production().with_client_type("builder-wins");
        assert_eq!(config.client_type, "builder-wins");
        clear_env_matrix();
    }

    #[test]
    fn env_overrides_skipped_when_values_malformed() {
        let _guard = env_test_guard();
        clear_env_matrix();
        unsafe {
            // Reason: test-only mutation; protected by env_test_guard.
            std::env::set_var(ENV_MDDS_PORT, "not-a-port");
            std::env::set_var(ENV_FPSS_PORT, "0"); // reject zero
            std::env::set_var(ENV_MDDS_HOST, "   "); // whitespace-only
        }
        let config = DirectConfig::production();
        let defaults = DirectConfig::production_defaults();
        assert_eq!(config.mdds_host, defaults.mdds_host);
        assert_eq!(config.mdds_port, defaults.mdds_port);
        assert_eq!(config.fpss_hosts[0].1, defaults.fpss_hosts[0].1);
        clear_env_matrix();
    }

    #[test]
    fn production_defaults_are_not_sensitive_to_env() {
        let _guard = env_test_guard();
        clear_env_matrix();
        unsafe {
            // Reason: test-only mutation; protected by env_test_guard.
            std::env::set_var(ENV_MDDS_HOST, "ignored-by-defaults");
            std::env::set_var(ENV_MDDS_PORT, "9999");
        }
        let config = DirectConfig::production_defaults();
        assert_eq!(config.mdds_host, "mdds-01.thetadata.us");
        assert_eq!(config.mdds_port, 443);
        clear_env_matrix();
    }
}
