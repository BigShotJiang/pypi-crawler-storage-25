"""Temporary PyPI upload scope probe package; safe to delete after testing."""

__version__ = "0.1.0"

__all__ = ["__version__"]
