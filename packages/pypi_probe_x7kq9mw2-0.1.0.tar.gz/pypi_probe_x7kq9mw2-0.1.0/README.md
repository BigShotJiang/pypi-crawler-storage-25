# pypi-probe-x7kq9mw2

Temporary package used to verify PyPI API token upload permissions. You may [yank](https://pypi.org/help/#yanked) or delete releases later if you do not need this name.

## Install

```bash
pip install pypi-probe-x7kq9mw2
```

## Usage

```python
from pypi_probe_x7kq9mw2 import __version__

print(__version__)
```

## Maintainer

**anupams0x1**

## License

MIT
