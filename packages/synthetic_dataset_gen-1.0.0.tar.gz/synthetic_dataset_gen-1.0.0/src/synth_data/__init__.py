"""
synth_data — synthetic training data generator for ML pipelines.

Quick start:
    from synth_data import SynthDataGen

    gen = SynthDataGen()
    qa = gen.qa_pairs(context="Your corpus text...", n=10)
    print(qa.to_jsonl())

    examples = gen.classification(labels=["positive", "negative"], domain="reviews", n=30)
    examples.save("train.csv", format="csv")

    dataset = gen.instructions(task_description="Summarise policy documents", n=15)
    dataset.save("instructions.json", format="json")
"""

from synth_data.generator import SynthDataGen
from synth_data.generators import (
    ClassificationGenerator,
    InstructionGenerator,
    QAPairGenerator,
    TabularGenerator,
)
from synth_data.models import (
    ClassificationExample,
    InstructionExample,
    QAPair,
    SynthDataset,
    TabularRow,
)

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = [
    "SynthDataGen",
    "QAPair",
    "ClassificationExample",
    "InstructionExample",
    "TabularRow",
    "SynthDataset",
    "QAPairGenerator",
    "ClassificationGenerator",
    "InstructionGenerator",
    "TabularGenerator",
]
