"""SynthDataGen — main facade."""

from __future__ import annotations

import synth_data.generators as gen_module
from synth_data.generators import (
    ClassificationGenerator,
    InstructionGenerator,
    QAPairGenerator,
    TabularGenerator,
)
from synth_data.models import SynthDataset


class SynthDataGen:
    """
    Generate synthetic training data for ML pipelines.

    Example:
        gen = SynthDataGen()
        qa = gen.qa_pairs(context="The UK GDPR requires...", n=20)
        print(qa.to_jsonl())
        qa.save("training_data.jsonl")
    """

    def __init__(self, model: str = "claude-opus-4-5") -> None:
        self.model = model
        gen_module.MODEL = model

    def qa_pairs(
        self,
        context: str,
        n: int = 10,
        difficulty: str = "mixed",
        question_types: list[str] | None = None,
    ) -> SynthDataset:
        """Generate Q&A pairs from source text."""
        return QAPairGenerator().generate(
            context=context, n=n, difficulty=difficulty, question_types=question_types
        )

    def classification(
        self,
        labels: list[str],
        domain: str = "general text",
        n: int = 20,
        balance: bool = True,
        style_guidance: str = "",
    ) -> SynthDataset:
        """Generate labelled classification examples."""
        return ClassificationGenerator().generate(
            labels=labels, domain=domain, n=n, balance=balance, style_guidance=style_guidance
        )

    def instructions(
        self,
        task_description: str,
        n: int = 15,
        system_prompt: str = "",
        input_format: str = "",
        output_format: str = "",
    ) -> SynthDataset:
        """Generate instruction-following training examples."""
        return InstructionGenerator().generate(
            task_description=task_description,
            n=n,
            system_prompt=system_prompt,
            input_format=input_format,
            output_format=output_format,
        )

    def tabular(
        self,
        columns: list[str],
        n: int = 50,
        schema: dict[str, str] | None = None,
        domain: str = "",
    ) -> SynthDataset:
        """Generate synthetic tabular data."""
        return TabularGenerator().generate(columns=columns, n=n, schema=schema, domain=domain)
