"""Data models for synthetic-data-gen."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from io import StringIO
from typing import Any


@dataclass
class QAPair:
    question: str
    answer: str
    context: str = ""
    difficulty: str = "medium"
    question_type: str = "factual"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "question": self.question,
            "answer": self.answer,
            "context": self.context,
            "difficulty": self.difficulty,
            "question_type": self.question_type,
        }

    def __repr__(self) -> str:
        return f"QAPair({self.question[:50]!r})"


@dataclass
class ClassificationExample:
    text: str
    label: str
    confidence: float = 1.0
    explanation: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "label": self.label,
            "confidence": self.confidence,
            "explanation": self.explanation,
        }

    def __repr__(self) -> str:
        return f"ClassificationExample(label={self.label!r}, {self.text[:40]!r})"


@dataclass
class InstructionExample:
    instruction: str
    input: str
    output: str
    system: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "instruction": self.instruction,
            "input": self.input,
            "output": self.output,
            "system": self.system,
        }

    def to_alpaca(self) -> dict[str, Any]:
        return {"instruction": self.instruction, "input": self.input, "output": self.output}

    def __repr__(self) -> str:
        return f"InstructionExample({self.instruction[:50]!r})"


@dataclass
class TabularRow:
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return self.data

    def __repr__(self) -> str:
        return f"TabularRow({self.data})"


class SynthDataset:
    """Container for a synthetic dataset with export utilities."""

    def __init__(self, items: list[Any], dataset_type: str = "generic") -> None:
        self.items = items
        self.dataset_type = dataset_type

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps([item.to_dict() for item in self.items], indent=indent)

    def to_jsonl(self) -> str:
        return "\n".join(json.dumps(item.to_dict()) for item in self.items)

    def to_csv(self) -> str:
        if not self.items:
            return ""
        buf = StringIO()
        rows = [item.to_dict() for item in self.items]
        writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
        return buf.getvalue()

    def to_alpaca(self) -> str:
        if self.items and hasattr(self.items[0], "to_alpaca"):
            return json.dumps([item.to_alpaca() for item in self.items], indent=2)
        return self.to_json()

    def save(self, path: str, format: str = "jsonl") -> None:
        content = {"json": self.to_json, "jsonl": self.to_jsonl, "csv": self.to_csv}.get(
            format, self.to_jsonl
        )()
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    def __repr__(self) -> str:
        return f"SynthDataset({len(self)} {self.dataset_type} examples)"
