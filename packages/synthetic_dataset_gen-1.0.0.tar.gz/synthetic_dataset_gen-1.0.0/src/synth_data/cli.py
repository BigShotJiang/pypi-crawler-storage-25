"""synth-data CLI."""

from __future__ import annotations

import argparse


def main() -> None:
    p = argparse.ArgumentParser(
        prog="synth-data", description="Generate synthetic ML training data"
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_qa = sub.add_parser("qa", help="Generate Q&A pairs")
    p_qa.add_argument("--context", required=True, help="Source text file")
    p_qa.add_argument("--n", type=int, default=10)
    p_qa.add_argument("--output", default="qa_pairs.jsonl")

    p_clf = sub.add_parser("classify", help="Generate classification examples")
    p_clf.add_argument("--labels", nargs="+", required=True)
    p_clf.add_argument("--domain", default="general text")
    p_clf.add_argument("--n", type=int, default=20)
    p_clf.add_argument("--output", default="classification.jsonl")

    args = p.parse_args()
    from synth_data import SynthDataGen

    gen = SynthDataGen()

    if args.command == "qa":
        from pathlib import Path

        context = Path(args.context).read_text(encoding="utf-8")
        ds = gen.qa_pairs(context=context, n=args.n)
        ds.save(args.output, format="jsonl")
        print(f"Saved {len(ds)} Q&A pairs to {args.output}")

    elif args.command == "classify":
        ds = gen.classification(labels=args.labels, domain=args.domain, n=args.n)
        ds.save(args.output, format="jsonl")
        print(f"Saved {len(ds)} classification examples to {args.output}")


if __name__ == "__main__":
    main()
