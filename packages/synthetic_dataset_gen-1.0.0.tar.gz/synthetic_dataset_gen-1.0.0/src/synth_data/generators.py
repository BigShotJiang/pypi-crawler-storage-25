"""Individual generators for each data type — all LLM calls go through _call()."""

from __future__ import annotations

import json
import re

from anthropic import Anthropic

from synth_data.models import (
    ClassificationExample,
    InstructionExample,
    QAPair,
    SynthDataset,
    TabularRow,
)

_client: Anthropic | None = None
MODEL = "claude-opus-4-5"


def _get_client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic()
    return _client


def _call(prompt: str, max_tokens: int = 2000) -> str:
    client = _get_client()
    resp = client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.content[0].text.strip()


def _parse_json(text: str) -> list[dict]:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.MULTILINE).strip()
    try:
        result = json.loads(text)
        return result if isinstance(result, list) else [result]
    except json.JSONDecodeError:
        return []


class QAPairGenerator:
    """Generate question-answer pairs from source text."""

    def generate(
        self,
        context: str,
        n: int = 10,
        difficulty: str = "mixed",
        question_types: list[str] | None = None,
    ) -> SynthDataset:
        types = question_types or ["factual", "inferential", "comparative"]
        diff_str = (
            f"difficulty: {difficulty}" if difficulty != "mixed" else "mix of easy/medium/hard"
        )
        prompt = f"""Generate {n} high-quality question-answer pairs from the text below.

Rules:
- Questions must be answerable from the provided text only
- Include types: {", ".join(types)}
- {diff_str}
- Each answer should be 1-3 sentences, specific and accurate

Text:
{context[:4000]}

Return ONLY a JSON array:
[
  {{
    "question": "...",
    "answer": "...",
    "question_type": "factual|inferential|comparative",
    "difficulty": "easy|medium|hard"
  }}
]"""
        raw = _call(prompt)
        items_data = _parse_json(raw)
        items = [
            QAPair(
                question=d["question"],
                answer=d["answer"],
                context=context[:200],
                difficulty=d.get("difficulty", "medium"),
                question_type=d.get("question_type", "factual"),
            )
            for d in items_data
            if d.get("question") and d.get("answer")
        ]
        return SynthDataset(items[:n], dataset_type="qa_pairs")


class ClassificationGenerator:
    """Generate labelled classification examples."""

    def generate(
        self,
        labels: list[str],
        domain: str = "general text",
        n: int = 20,
        balance: bool = True,
        style_guidance: str = "",
    ) -> SynthDataset:
        per_label = max(1, n // len(labels)) if balance else n
        labels_str = ", ".join(f'"{lb}"' for lb in labels)
        style = f"\nStyle guidance: {style_guidance}" if style_guidance else ""
        prompt = f"""Generate synthetic labelled text examples for a {domain} classifier.

Labels: {labels_str}
Examples per label: {per_label}{style}

Requirements:
- Each example should be realistic and representative of its label
- Vary the writing style, length, and vocabulary
- Include some ambiguous or nuanced cases

Return ONLY a JSON array:
[
  {{
    "text": "...",
    "label": "{labels[0]}",
    "confidence": 0.0-1.0,
    "explanation": "brief reason"
  }}
]

Generate {per_label} examples for EACH of these labels: {labels_str}"""
        raw = _call(prompt, max_tokens=3000)
        items_data = _parse_json(raw)
        items = [
            ClassificationExample(
                text=d["text"],
                label=d["label"],
                confidence=float(d.get("confidence", 1.0)),
                explanation=d.get("explanation", ""),
            )
            for d in items_data
            if d.get("text") and d.get("label") and d["label"] in labels
        ]
        return SynthDataset(items[:n], dataset_type="classification")


class InstructionGenerator:
    """Generate instruction-following training examples."""

    def generate(
        self,
        task_description: str,
        n: int = 15,
        system_prompt: str = "",
        input_format: str = "",
        output_format: str = "",
    ) -> SynthDataset:
        prompt = f"""Generate {n} diverse instruction-following examples for this task:

Task: {task_description}
{f"System prompt: {system_prompt}" if system_prompt else ""}
{f"Input format: {input_format}" if input_format else ""}
{f"Output format: {output_format}" if output_format else ""}

Return ONLY a JSON array:
[
  {{
    "instruction": "the task instruction",
    "input": "the user's specific input (can be empty string)",
    "output": "the ideal response",
    "system": "optional system context"
  }}
]"""
        raw = _call(prompt, max_tokens=4000)
        items_data = _parse_json(raw)
        items = [
            InstructionExample(
                instruction=d["instruction"],
                input=d.get("input", ""),
                output=d["output"],
                system=d.get("system", system_prompt),
            )
            for d in items_data
            if d.get("instruction") and d.get("output")
        ]
        return SynthDataset(items[:n], dataset_type="instructions")


class TabularGenerator:
    """Generate synthetic tabular data."""

    def generate(
        self,
        columns: list[str],
        n: int = 50,
        schema: dict[str, str] | None = None,
        domain: str = "",
    ) -> SynthDataset:
        schema_str = ""
        if schema:
            schema_str = "\nColumn constraints:\n" + "\n".join(
                f"  - {col}: {desc}" for col, desc in schema.items()
            )
        domain_str = f" for a {domain} dataset" if domain else ""
        prompt = f"""Generate {n} rows of realistic synthetic tabular data{domain_str}.

Columns: {", ".join(f'"{c}"' for c in columns)}{schema_str}

Return ONLY a JSON array of objects, one per row:
[
  {{{", ".join(f'"{c}": value' for c in columns[:3])}{", ..." if len(columns) > 3 else ""}}}
]"""
        raw = _call(prompt, max_tokens=4000)
        items_data = _parse_json(raw)
        items = [
            TabularRow(data={col: d.get(col, "") for col in columns})
            for d in items_data
            if isinstance(d, dict)
        ]
        return SynthDataset(items[:n], dataset_type="tabular")
