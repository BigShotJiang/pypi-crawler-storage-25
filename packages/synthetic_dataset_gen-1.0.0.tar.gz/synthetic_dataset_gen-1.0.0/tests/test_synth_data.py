"""Tests for synthetic-data-gen. All LLM calls mocked. Run: pytest tests/ -v"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from synth_data import (
    ClassificationExample,
    InstructionExample,
    QAPair,
    SynthDataGen,
    SynthDataset,
    TabularRow,
)
from synth_data.generators import (
    ClassificationGenerator,
    InstructionGenerator,
    QAPairGenerator,
    TabularGenerator,
)

# ── Mock helpers ───────────────────────────────────────────────


def _mock_qa():
    data = [
        {
            "question": "What is RAG?",
            "answer": "Retrieval-Augmented Generation.",
            "question_type": "factual",
            "difficulty": "easy",
        },
        {
            "question": "How does chunking affect retrieval?",
            "answer": "Chunking affects quality.",
            "question_type": "inferential",
            "difficulty": "medium",
        },
    ]
    m = MagicMock()
    m.content = [MagicMock(text=json.dumps(data))]
    return m


def _mock_clf():
    data = [
        {
            "text": "Great product!",
            "label": "positive",
            "confidence": 0.95,
            "explanation": "Positive sentiment",
        },
        {
            "text": "Terrible experience.",
            "label": "negative",
            "confidence": 0.9,
            "explanation": "Negative sentiment",
        },
        {"text": "It's okay.", "label": "neutral", "confidence": 0.7, "explanation": "Mixed"},
    ]
    m = MagicMock()
    m.content = [MagicMock(text=json.dumps(data))]
    return m


def _mock_instructions():
    data = [
        {
            "instruction": "Summarise this document",
            "input": "Long text...",
            "output": "Summary here.",
            "system": "",
        },
        {
            "instruction": "Classify this review",
            "input": "Great product!",
            "output": "positive",
            "system": "",
        },
    ]
    m = MagicMock()
    m.content = [MagicMock(text=json.dumps(data))]
    return m


def _mock_tabular():
    data = [
        {"name": "Alice Smith", "department": "Engineering", "salary": 65000},
        {"name": "Bob Jones", "department": "HR", "salary": 45000},
        {"name": "Carol White", "department": "Finance", "salary": 70000},
    ]
    m = MagicMock()
    m.content = [MagicMock(text=json.dumps(data))]
    return m


CONTEXT = (
    "RAG stands for Retrieval-Augmented Generation. It combines retrieval with LLM generation."
)


# ── Model tests ────────────────────────────────────────────────


class TestQAPair:
    def test_to_dict(self):
        qa = QAPair(question="What?", answer="This.")
        d = qa.to_dict()
        assert d["question"] == "What?"
        assert d["answer"] == "This."

    def test_repr(self):
        qa = QAPair(question="What is RAG?", answer="A technique.")
        assert "What is RAG?" in repr(qa)

    def test_defaults(self):
        qa = QAPair(question="Q?", answer="A.")
        assert qa.difficulty == "medium"
        assert qa.question_type == "factual"


class TestClassificationExample:
    def test_to_dict(self):
        ex = ClassificationExample(text="Great!", label="positive")
        assert ex.to_dict()["label"] == "positive"

    def test_repr(self):
        ex = ClassificationExample(text="Good product.", label="positive")
        assert "positive" in repr(ex)


class TestInstructionExample:
    def test_to_dict(self):
        ex = InstructionExample(instruction="Summarise", input="text", output="summary")
        d = ex.to_dict()
        assert d["instruction"] == "Summarise"

    def test_to_alpaca(self):
        ex = InstructionExample(instruction="Do X", input="input", output="output")
        alpaca = ex.to_alpaca()
        assert "instruction" in alpaca
        assert "system" not in alpaca

    def test_repr(self):
        ex = InstructionExample(instruction="Summarise this", input="", output="")
        assert "Summarise" in repr(ex)


class TestTabularRow:
    def test_to_dict(self):
        row = TabularRow(data={"name": "Alice", "age": 30})
        assert row.to_dict() == {"name": "Alice", "age": 30}

    def test_repr(self):
        row = TabularRow(data={"name": "Alice"})
        assert "Alice" in repr(row)


class TestSynthDataset:
    @pytest.fixture
    def qa_dataset(self):
        items = [
            QAPair(question="Q1?", answer="A1.", question_type="factual", difficulty="easy"),
            QAPair(question="Q2?", answer="A2.", question_type="inferential", difficulty="medium"),
        ]
        return SynthDataset(items, dataset_type="qa_pairs")

    def test_len(self, qa_dataset):
        assert len(qa_dataset) == 2

    def test_iter(self, qa_dataset):
        assert len(list(qa_dataset)) == 2

    def test_to_json(self, qa_dataset):
        parsed = json.loads(qa_dataset.to_json())
        assert len(parsed) == 2
        assert "question" in parsed[0]

    def test_to_jsonl(self, qa_dataset):
        lines = qa_dataset.to_jsonl().strip().split("\n")
        assert len(lines) == 2
        assert json.loads(lines[0])["question"] == "Q1?"

    def test_to_csv(self, qa_dataset):
        result = qa_dataset.to_csv()
        assert "question" in result
        assert "Q1?" in result

    def test_to_alpaca(self):
        items = [InstructionExample(instruction="Do X", input="in", output="out")]
        ds = SynthDataset(items, dataset_type="instructions")
        parsed = json.loads(ds.to_alpaca())
        assert "instruction" in parsed[0]

    def test_save_jsonl(self, qa_dataset, tmp_path):
        path = str(tmp_path / "test.jsonl")
        qa_dataset.save(path, format="jsonl")
        lines = Path(path).read_text().strip().split("\n")
        assert len(lines) == 2

    def test_save_json(self, qa_dataset, tmp_path):
        path = str(tmp_path / "test.json")
        qa_dataset.save(path, format="json")
        parsed = json.loads(Path(path).read_text())
        assert len(parsed) == 2

    def test_save_csv(self, qa_dataset, tmp_path):
        path = str(tmp_path / "test.csv")
        qa_dataset.save(path, format="csv")
        assert "question" in Path(path).read_text()

    def test_repr(self, qa_dataset):
        assert "SynthDataset" in repr(qa_dataset)
        assert "qa_pairs" in repr(qa_dataset)

    def test_empty_csv(self):
        ds = SynthDataset([], dataset_type="qa_pairs")
        assert ds.to_csv() == ""


# ── Generator tests (all mocked) ──────────────────────────────


class TestQAPairGenerator:
    def test_returns_dataset(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_qa()))
            )
            ds = QAPairGenerator().generate(context=CONTEXT, n=2)
        assert isinstance(ds, SynthDataset)
        assert len(ds) >= 1

    def test_qa_pairs_have_questions(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_qa()))
            )
            ds = QAPairGenerator().generate(context=CONTEXT, n=2)
        for item in ds:
            assert isinstance(item, QAPair)
            assert item.question

    def test_handles_invalid_json(self):
        bad = MagicMock()
        bad.content = [MagicMock(text="not valid json")]
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=bad))
            )
            ds = QAPairGenerator().generate(context=CONTEXT, n=2)
        assert len(ds) == 0


class TestClassificationGenerator:
    def test_returns_dataset(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_clf()))
            )
            ds = ClassificationGenerator().generate(labels=["positive", "negative", "neutral"], n=3)
        assert isinstance(ds, SynthDataset)
        assert len(ds) >= 1

    def test_filters_invalid_labels(self):
        data = [
            {"text": "Good", "label": "positive", "confidence": 0.9},
            {"text": "Bad", "label": "INVALID_LABEL", "confidence": 0.8},
        ]
        mock = MagicMock()
        mock.content = [MagicMock(text=json.dumps(data))]
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=mock))
            )
            ds = ClassificationGenerator().generate(labels=["positive", "negative"], n=5)
        for item in ds:
            assert item.label in ["positive", "negative"]


class TestInstructionGenerator:
    def test_returns_dataset(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_instructions()))
            )
            ds = InstructionGenerator().generate(task_description="Summarise documents", n=2)
        assert isinstance(ds, SynthDataset)
        assert len(ds) >= 1

    def test_examples_have_output(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_instructions()))
            )
            ds = InstructionGenerator().generate(task_description="test", n=2)
        for item in ds:
            assert isinstance(item, InstructionExample)
            assert item.output


class TestTabularGenerator:
    def test_returns_dataset(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_tabular()))
            )
            ds = TabularGenerator().generate(columns=["name", "department", "salary"], n=3)
        assert isinstance(ds, SynthDataset)
        assert len(ds) >= 1

    def test_rows_have_correct_columns(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_tabular()))
            )
            cols = ["name", "department", "salary"]
            ds = TabularGenerator().generate(columns=cols, n=3)
        for item in ds:
            assert isinstance(item, TabularRow)
            for col in cols:
                assert col in item.data


class TestSynthDataGen:
    def test_qa_pairs(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_qa()))
            )
            ds = SynthDataGen().qa_pairs(context=CONTEXT, n=2)
        assert isinstance(ds, SynthDataset)

    def test_classification(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_clf()))
            )
            ds = SynthDataGen().classification(labels=["pos", "neg"], n=2)
        assert isinstance(ds, SynthDataset)

    def test_instructions(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_instructions()))
            )
            ds = SynthDataGen().instructions(task_description="test task", n=2)
        assert isinstance(ds, SynthDataset)

    def test_tabular(self):
        with patch("synth_data.generators._get_client") as mock_get:
            mock_get.return_value = MagicMock(
                messages=MagicMock(create=MagicMock(return_value=_mock_tabular()))
            )
            ds = SynthDataGen().tabular(columns=["name", "department", "salary"], n=3)
        assert isinstance(ds, SynthDataset)
