"""
codebookpy — Codebook reader for exploratory data analysis.

Quick start:
    from codebookpy import Codebook, cb_lookup

    cb = Codebook(
        "path/to/codebook.pdf",
        anthropic_api_key="sk-ant-...",
        df=my_df,
    )

    cb_lookup(cb, ["VAR1", "VAR2"], df=my_df, summarize_df=True)
"""

from codebookpy.core import Codebook, cb_lookup

__version__ = "0.1.0"
__all__ = ["Codebook", "cb_lookup"]
