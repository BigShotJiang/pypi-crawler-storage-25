"""
codebookpy/core.py — Codebook reader for exploratory data analysis.

Usage:
    from codebookpy import Codebook, cb_lookup

    cb = Codebook("path/to/codebook.pdf", anthropic_api_key="sk-ant-...")
    # or
    cb = Codebook("path/to/codebook.pdf", openai_api_key="sk-...")

    cb_lookup(cb, ["VAR1", "VAR2"], df=my_df, summarize_df=True)

OCR support (for scanned/image-based PDFs):
    Requires Tesseract OCR to be installed on your system.
    Download: https://github.com/UB-Mannheim/tesseract/wiki
    Default install path on Windows: C:\\Program Files\\Tesseract-OCR\\tesseract.exe
    Also requires: pip install pymupdf pytesseract Pillow
"""

from __future__ import annotations

import io
import json
import re
import tempfile
import warnings
from pathlib import Path
from typing import Optional

import pdfplumber
import pandas as pd
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

# ---------------------------------------------------------------------------
# Tesseract path configuration
# Set this to your Tesseract install path if it is not on your system PATH.
# Windows default: r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# Mac/Linux: usually on PATH automatically after `brew install tesseract`
#            or `sudo apt install tesseract-ocr`, so leave as None.
# ---------------------------------------------------------------------------

TESSERACT_CMD = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-4-20250514"
_OPENAI_DEFAULT_MODEL = "gpt-4o"

_CHUNK_CHAR_LIMIT = 12_000  # characters per LLM chunk

_SYSTEM_PROMPT_TARGETED = """You are a codebook parser. You will receive the full extracted text of a statistical codebook PDF and a small batch of variable names to look up.

For each variable in the batch, search the entire codebook text and return a JSON array with one entry per variable.

Each element must follow this exact schema:
{
  "var_name": "EXACT_VARIABLE_NAME_AS_PROVIDED",
  "label": "Short label or title for the variable as it appears in the codebook",
  "description": "Full description of what the variable measures",
  "values": [
    {"code": "0", "meaning": "Description of code 0"},
    {"code": "1", "meaning": "Description of code 1"}
  ]
}

Rules:
- var_name MUST be exactly as provided in the batch — never alter it
- Search for each variable even if the codebook spells it slightly differently (e.g., "SENT_TOT" in the codebook should match "SENTTOT0" in the batch if clearly the same variable)
- Extract ALL value codes and their meanings — these appear as numbered lines, tables, or entries like "0 = No", "1 = Yes", "1. Male", etc.
- label should be the short title or heading for the variable as written in the codebook
- description should be the full prose description of what the variable measures
- If no discrete value codes exist (continuous variable), set "values" to []
- If a variable cannot be found anywhere in the codebook text, still return an entry for it with empty strings and empty values
- Return ONLY a valid JSON array — no markdown fences, no commentary, no preamble
"""

def _build_targeted_prompt(batch: list[str]) -> str:
    """Build a prompt for a specific batch of variable names."""
    var_list_str = "\n".join(f"- {v}" for v in batch)
    return _SYSTEM_PROMPT_TARGETED + f"\n\nVariables to look up:\n{var_list_str}"

# ---------------------------------------------------------------------------
# PDF extraction — Stage 1: pdfplumber (with pikepdf repair fallback)
# ---------------------------------------------------------------------------

def _extract_text_from_pdf(pdf_path: Path) -> str:
    """
    Extract text from a PDF using pdfplumber.
    If the PDF is malformed, attempts to repair it with pikepdf first.
    Returns empty string if the PDF is image-based (no selectable text).
    """

    def _read_with_pdfplumber(path: Path) -> str:
        pages = []
        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages):
                text = page.extract_text(layout=True)
                if text:
                    pages.append(f"[PAGE {i+1}]\n{text}")
        return "\n\n".join(pages)

    # First attempt: open directly
    try:
        return _read_with_pdfplumber(pdf_path)
    except Exception:
        pass

    # Second attempt: repair with pikepdf then retry
    try:
        import pikepdf
    except ImportError:
        raise ImportError(
            "This PDF appears malformed and requires repair. "
            "Run: pip install pikepdf"
        )

    warnings.warn(
        f"PDF '{pdf_path.name}' appears malformed — attempting repair with pikepdf.",
        UserWarning,
        stacklevel=4,
    )

    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp_path = Path(tmp.name)

    try:
        with pikepdf.open(pdf_path, suppress_warnings=True) as repaired:
            repaired.save(tmp_path)
        return _read_with_pdfplumber(tmp_path)
    finally:
        tmp_path.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# PDF extraction — Stage 2: OCR fallback for image-based PDFs
# ---------------------------------------------------------------------------

def _count_pdf_pages(pdf_path: Path) -> int:
    """Quick page count using pymupdf without full extraction."""
    try:
        import fitz
        doc = fitz.open(str(pdf_path))
        n = len(doc)
        doc.close()
        return n
    except Exception:
        return 0


def _extract_text_ocr(pdf_path: Path, console=None) -> str:
    """
    OCR fallback for scanned/image-based PDFs.
    Uses pymupdf to rasterize pages at 300 DPI, then pytesseract for OCR.
    Tesseract must be installed — see TESSERACT_CMD at top of file.
    """
    try:
        import fitz  # pymupdf
    except ImportError:
        raise ImportError(
            "OCR requires pymupdf. Run: pip install pymupdf"
        )

    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        raise ImportError(
            "OCR requires pytesseract and Pillow. "
            "Run: pip install pytesseract Pillow"
        )

    # Point pytesseract at the Tesseract binary
    if TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD

    # Verify Tesseract is reachable before processing pages
    try:
        pytesseract.get_tesseract_version()
    except Exception:
        raise EnvironmentError(
            f"Tesseract not found at '{TESSERACT_CMD}'.\n"
            "Download and install from: https://github.com/UB-Mannheim/tesseract/wiki\n"
            "Then update TESSERACT_CMD at the top of cbread.py to match your install path."
        )

    pages = []
    doc = fitz.open(str(pdf_path))
    n_pages = len(doc)
    for i, page in enumerate(doc):
        if console:
            console.print(f"  [dim]OCR: page {i+1}/{n_pages}...[/dim]", end="\r")
        mat = fitz.Matrix(300 / 72, 300 / 72)  # 300 DPI
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = Image.open(io.BytesIO(pix.tobytes("png")))
        text = pytesseract.image_to_string(img)
        if text.strip():
            pages.append(f"[PAGE {i+1}]\n{text}")
    doc.close()
    if console:
        console.print()  # newline after \r
    return "\n\n".join(pages)


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def _chunk_text(text: str, max_chars: int = _CHUNK_CHAR_LIMIT) -> list[str]:
    """
    Split text into overlapping chunks at paragraph boundaries.
    Overlap ensures variables split across chunk boundaries are captured.
    """
    paragraphs = re.split(r"\n{2,}", text)
    chunks: list[str] = []
    current: list[str] = []
    current_len = 0

    for para in paragraphs:
        para_len = len(para)
        if current_len + para_len > max_chars and current:
            chunks.append("\n\n".join(current))
            # Keep last ~2000 chars as overlap
            overlap_buffer: list[str] = []
            overlap_len = 0
            for p in reversed(current):
                if overlap_len + len(p) < 2000:
                    overlap_buffer.insert(0, p)
                    overlap_len += len(p)
                else:
                    break
            current = overlap_buffer[:]
            current_len = sum(len(p) for p in current)
        current.append(para)
        current_len += para_len

    if current:
        chunks.append("\n\n".join(current))

    return chunks


# ---------------------------------------------------------------------------
# LLM parsing — Anthropic
# ---------------------------------------------------------------------------

def _parse_batch_anthropic(full_text: str, batch: list[str], api_key: str, model: str) -> list[dict]:
    """Send a batch of variable names + full codebook text to Anthropic and get back parsed entries."""
    try:
        import anthropic
    except ImportError:
        raise ImportError("anthropic package not installed. Run: pip install anthropic")

    client = anthropic.Anthropic(api_key=api_key)
    message = client.messages.create(
        model=model,
        max_tokens=4096,
        system=_build_targeted_prompt(batch),
        messages=[{"role": "user", "content": full_text}],
    )
    raw = message.content[0].text.strip()
    return _safe_parse_json(raw)


# ---------------------------------------------------------------------------
# LLM parsing — OpenAI
# ---------------------------------------------------------------------------

def _parse_batch_openai(full_text: str, batch: list[str], api_key: str, model: str) -> list[dict]:
    """Send a batch of variable names + full codebook text to OpenAI and get back parsed entries."""
    try:
        import openai
    except ImportError:
        raise ImportError("openai package not installed. Run: pip install openai")

    client = openai.OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": _build_targeted_prompt(batch)},
            {"role": "user", "content": full_text},
        ],
        max_tokens=4096,
        temperature=0,
    )
    raw = response.choices[0].message.content.strip()
    return _safe_parse_json(raw)


# ---------------------------------------------------------------------------
# JSON safety
# ---------------------------------------------------------------------------

def _safe_parse_json(raw: str) -> list[dict]:
    """Strip markdown fences if present, then parse JSON."""
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    raw = raw.strip()
    try:
        result = json.loads(raw)
        if isinstance(result, list):
            return result
        return []
    except json.JSONDecodeError:
        warnings.warn("Could not parse LLM response as JSON. Skipping chunk.")
        return []


# ---------------------------------------------------------------------------
# Deduplication & merge
# ---------------------------------------------------------------------------

def _merge_variables(parsed_chunks: list[list[dict]]) -> dict[str, dict]:
    """
    Merge parsed variable dicts from all chunks.
    Later chunks can enrich earlier ones (e.g., values added in a continuation).
    Keyed by uppercase var_name.
    """
    merged: dict[str, dict] = {}
    for chunk_vars in parsed_chunks:
        for var in chunk_vars:
            name = var.get("var_name", "").strip().upper()
            if not name:
                continue
            if name not in merged:
                merged[name] = {
                    "var_name": var.get("var_name", name),
                    "label": var.get("label", ""),
                    "description": var.get("description", ""),
                    "values": var.get("values", []),
                }
            else:
                existing = merged[name]
                if not existing["label"] and var.get("label"):
                    existing["label"] = var["label"]
                if not existing["description"] and var.get("description"):
                    existing["description"] = var["description"]
                existing_codes = {v["code"] for v in existing["values"]}
                for val in var.get("values", []):
                    if val["code"] not in existing_codes:
                        existing["values"].append(val)
                        existing_codes.add(val["code"])
    return merged


# ---------------------------------------------------------------------------
# Relevance-based chunk selection
# ---------------------------------------------------------------------------

def _select_relevant_chunks(chunks: list[str], var_names: list[str], top_n: int = 5) -> list[str]:
    """
    Select the top_n chunks most likely to contain descriptions of the given variables.
    Scores each chunk by how many of the variable names (or their substrings) appear in it.
    Falls back to all chunks if none score above zero.
    """
    # Build search terms: full name + any alpha sub-tokens (e.g. "SENTTOT" from "SENTTOT0")
    search_terms = set()
    for v in var_names:
        search_terms.add(v.upper())
        # also try stripping trailing digits for fuzzy matching
        stripped = v.rstrip("0123456789").upper()
        if len(stripped) >= 3:
            search_terms.add(stripped)

    scored = []
    for chunk in chunks:
        upper_chunk = chunk.upper()
        score = sum(1 for term in search_terms if term in upper_chunk)
        scored.append((score, chunk))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = [chunk for score, chunk in scored[:top_n] if score > 0]

    # If nothing matched, return the top_n highest-scored regardless
    if not top:
        top = [chunk for _, chunk in scored[:top_n]]

    return top


# ---------------------------------------------------------------------------
# Codebook class
# ---------------------------------------------------------------------------

class Codebook:
    """
    Load and parse a codebook PDF into memory using an LLM backend.

    Parameters
    ----------
    pdf_path : str or Path
        Path to the codebook PDF.
    anthropic_api_key : str, optional
        Anthropic API key. Mutually exclusive with openai_api_key.
    openai_api_key : str, optional
        OpenAI API key. Mutually exclusive with anthropic_api_key.
    anthropic_model : str, optional
        Anthropic model to use. Defaults to claude-sonnet-4-20250514.
    openai_model : str, optional
        OpenAI model to use. Defaults to gpt-4o.
    df : pd.DataFrame, optional
        If provided, all column names are used as known variable anchors
        to guide the LLM when parsing the codebook.
    known_vars : list[str], optional
        Explicit list of variable names to anchor the LLM against.
        Takes precedence over df if both are provided.
    verbose : bool
        Print parsing progress. Default True.
    """

    def __init__(
        self,
        pdf_path: str | Path,
        anthropic_api_key: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        anthropic_model: str = _ANTHROPIC_DEFAULT_MODEL,
        openai_model: str = _OPENAI_DEFAULT_MODEL,
        df: Optional[pd.DataFrame] = None,
        known_vars: Optional[list[str]] = None,
        verbose: bool = True,
    ):
        if anthropic_api_key and openai_api_key:
            raise ValueError("Provide only one of anthropic_api_key or openai_api_key, not both.")
        if not anthropic_api_key and not openai_api_key:
            raise ValueError("You must provide either anthropic_api_key or openai_api_key.")

        self.pdf_path = Path(pdf_path)
        self._anthropic_key = anthropic_api_key
        self._openai_key = openai_api_key
        self._anthropic_model = anthropic_model
        self._openai_model = openai_model
        self.verbose = verbose

        # Resolve known variable names: prefer explicit known_vars, then df columns
        if known_vars is not None:
            self._known_vars = [v.upper() for v in known_vars]
        elif df is not None:
            self._known_vars = [c.upper() for c in df.columns]
        else:
            self._known_vars = []

        self._variables: dict[str, dict] = {}
        self._parsed = False

        self._parse()

    def _parse(self):
        console = Console() if self.verbose else None

        if self.verbose:
            console.print(f"\n[bold cyan]cbread[/bold cyan] — Parsing [yellow]{self.pdf_path.name}[/yellow]")

        # 1. Extract text via pdfplumber (with pikepdf repair fallback)
        if self.verbose:
            console.print("  [dim]Extracting text from PDF...[/dim]")
        full_text = _extract_text_from_pdf(self.pdf_path)

        # 2. If no text extracted, fall back to OCR
        if not full_text.strip():
            n_pages = _count_pdf_pages(self.pdf_path)
            est_minutes = max(1, round(n_pages * 3 / 60))  # ~3 sec/page at 300 DPI
            if self.verbose:
                console.print(
                    f"  [yellow]No selectable text found — PDF appears to be scanned ({n_pages} pages).[/yellow]"
                )
                console.print(
                    f"  [yellow]Falling back to OCR. Estimated time: ~{est_minutes} min. Please wait...[/yellow]"
                )
            full_text = _extract_text_ocr(self.pdf_path, console=console if self.verbose else None)
            if not full_text.strip():
                raise ValueError(
                    f"Could not extract any text from '{self.pdf_path.name}' using "
                    "either pdfplumber or OCR. Check that Tesseract is installed and "
                    "that TESSERACT_CMD in cbread.py points to the correct path."
                )
            if self.verbose:
                console.print("  [green]OCR complete.[/green]")

        # 3. Build a searchable index: split full text into chunks, one per page or paragraph
        #    Each batch will only receive the chunks most likely to contain its variables
        all_chunks = [c for c in _chunk_text(full_text, max_chars=4_000) if c.strip()]

        # 4. Batch variables and parse — guarantees 1-1 coverage
        # Each batch: up to 10 variables, sent with only the most relevant text chunks
        BATCH_SIZE = 10
        CHUNKS_PER_BATCH = 5        # top N most relevant chunks per batch
        RATE_LIMIT_DELAY = 15       # seconds to wait between batches (respects 30k TPM limit)

        vars_to_parse = self._known_vars if self._known_vars else []
        batches = [vars_to_parse[i:i+BATCH_SIZE] for i in range(0, len(vars_to_parse), BATCH_SIZE)]

        if self.verbose:
            console.print(
                f"  [dim]Parsing {len(vars_to_parse)} variables in "
                f"{len(batches)} batches of up to {BATCH_SIZE}...[/dim]"
            )

        import time
        parsed_chunks = []
        for i, batch in enumerate(batches):
            # Select chunks most relevant to this batch by keyword presence
            relevant = _select_relevant_chunks(all_chunks, batch, top_n=CHUNKS_PER_BATCH)
            context_text = "\n\n".join(relevant) if relevant else "\n\n".join(all_chunks[:CHUNKS_PER_BATCH])

            if self.verbose:
                console.print(
                    f"  [dim]Batch {i+1}/{len(batches)}: {', '.join(batch)}...[/dim]", end="\r"
                )
            if self._anthropic_key:
                vars_found = _parse_batch_anthropic(context_text, batch, self._anthropic_key, self._anthropic_model)
            else:
                vars_found = _parse_batch_openai(context_text, batch, self._openai_key, self._openai_model)
            parsed_chunks.append(vars_found)

            # Throttle to stay within rate limits (skip delay after last batch)
            if i < len(batches) - 1:
                time.sleep(RATE_LIMIT_DELAY)

        if self.verbose:
            console.print()  # newline after \r

        # 5. Merge
        self._variables = _merge_variables(parsed_chunks)
        self._parsed = True

        if self.verbose:
            console.print(
                f"  [bold green]Done.[/bold green] "
                f"Parsed [bold]{len(self._variables)}[/bold] variables from codebook.\n"
            )

    def get(self, var_name: str) -> Optional[dict]:
        """Return the parsed dict for a variable name (case-insensitive)."""
        return self._variables.get(var_name.upper())

    def list_vars(self) -> list[str]:
        """Return all parsed variable names."""
        return list(self._variables.keys())

    def __repr__(self):
        status = f"{len(self._variables)} variables parsed" if self._parsed else "not parsed"
        return f"Codebook('{self.pdf_path.name}', {status})"


# ---------------------------------------------------------------------------
# cb_lookup
# ---------------------------------------------------------------------------

def cb_lookup(
    codebook: Codebook,
    var_list: list[str],
    df: Optional[pd.DataFrame] = None,
    summarize_df: bool = False,
) -> None:
    """
    Look up variables in a parsed Codebook and print formatted summaries.

    Parameters
    ----------
    codebook : Codebook
        A parsed Codebook object.
    var_list : list[str]
        Variable names to look up.
    df : pd.DataFrame, optional
        DataFrame to summarize alongside codebook entries.
    summarize_df : bool, optional
        If True, print df summary stats for each variable.
        Only valid when df is provided. Ignored (with warning) otherwise.
    """
    if summarize_df and df is None:
        warnings.warn(
            "summarize_df=True has no effect when df is not provided. "
            "Pass a DataFrame via the df= argument.",
            UserWarning,
            stacklevel=2,
        )
        summarize_df = False

    console = Console()

    for var in var_list:
        entry = codebook.get(var)
        _print_variable_panel(console, var, entry, df, summarize_df)


# ---------------------------------------------------------------------------
# Rich display helpers
# ---------------------------------------------------------------------------

def _print_variable_panel(
    console: Console,
    var_name: str,
    entry: Optional[dict],
    df: Optional[pd.DataFrame],
    summarize_df: bool,
) -> None:
    """Render a single variable as a Rich panel."""
    from rich.console import Group

    if entry is None:
        console.print(
            Panel(
                Text(f"Variable '{var_name}' not found in codebook.", style="red"),
                title=f"[bold red]{var_name}[/bold red]",
                border_style="red",
                box=box.ROUNDED,
            )
        )
        return

    content_parts: list = []

    label = entry.get("label", "")
    if label:
        content_parts.append(Text.from_markup(f"[bold]Label:[/bold] {label}"))

    desc = entry.get("description", "")
    if desc:
        content_parts.append(Text.from_markup(f"\n[bold]Description:[/bold]\n{desc}"))

    values = entry.get("values", [])
    if values:
        val_table = Table(
            show_header=True,
            header_style="bold magenta",
            box=box.SIMPLE_HEAVY,
            padding=(0, 1),
        )
        val_table.add_column("Code", style="cyan", no_wrap=True)
        val_table.add_column("Meaning")
        for v in values:
            val_table.add_row(str(v.get("code", "")), str(v.get("meaning", "")))
        content_parts.append(Text.from_markup("\n[bold]Coded Values:[/bold]"))
        content_parts.append(val_table)

    if summarize_df and df is not None:
        df_summary = _build_df_summary(var_name, df)
        if df_summary is not None:
            content_parts.append(Text.from_markup("\n[bold]DataFrame Summary:[/bold]"))
            content_parts.append(df_summary)

    panel = Panel(
        Group(*content_parts) if content_parts else Text("[dim]No information available.[/dim]"),
        title=f"[bold cyan]{entry.get('var_name', var_name)}[/bold cyan]",
        border_style="cyan",
        box=box.ROUNDED,
        padding=(1, 2),
    )
    console.print(panel)
    console.print()


def _build_df_summary(var_name: str, df: pd.DataFrame):
    """Build a Rich table summarizing a column in the dataframe."""
    from rich.console import Group

    col_name = _find_column(var_name, df)
    if col_name is None:
        return Text(f"[dim](Column '{var_name}' not found in DataFrame)[/dim]")

    col = df[col_name]
    n_total = len(col)
    n_missing = int(col.isna().sum())
    pct_missing = 100 * n_missing / n_total if n_total > 0 else 0.0
    dtype_str = str(col.dtype)

    # Header info (always shown)
    info_table = Table(
        show_header=False,
        box=box.SIMPLE_HEAVY,
        padding=(0, 1),
        style="dim",
    )
    info_table.add_column("Key", style="yellow")
    info_table.add_column("Value")
    info_table.add_row("dtype", dtype_str)
    info_table.add_row("N", str(n_total))
    info_table.add_row("Missing", f"{n_missing} ({pct_missing:.1f}%)")

    parts = [info_table]

    # Datetime
    if pd.api.types.is_datetime64_any_dtype(col):
        non_null = col.dropna()
        if len(non_null) > 0:
            range_table = Table(
                show_header=False,
                box=box.SIMPLE_HEAVY,
                padding=(0, 1),
            )
            range_table.add_column("Key", style="yellow")
            range_table.add_column("Value")
            range_table.add_row("Min date", str(non_null.min().date()))
            range_table.add_row("Max date", str(non_null.max().date()))
            range_table.add_row("Range", f"{(non_null.max() - non_null.min()).days} days")
            parts.append(Text.from_markup("\n[bold]Date Range:[/bold]"))
            parts.append(range_table)

    # Numeric / continuous
    elif pd.api.types.is_numeric_dtype(col) and col.nunique() > 10:
        stats = col.describe()
        num_table = Table(
            show_header=True,
            header_style="bold yellow",
            box=box.SIMPLE_HEAVY,
            padding=(0, 1),
        )
        num_table.add_column("Statistic", style="yellow")
        num_table.add_column("Value")
        for stat_name, stat_val in stats.items():
            num_table.add_row(stat_name, f"{stat_val:.4g}")
        parts.append(Text.from_markup("\n[bold]Numeric Summary:[/bold]"))
        parts.append(num_table)

    # Categorical / low-cardinality
    else:
        freq_table = Table(
            show_header=True,
            header_style="bold yellow",
            box=box.SIMPLE_HEAVY,
            padding=(0, 1),
        )
        freq_table.add_column("Value", style="yellow")
        freq_table.add_column("Count")
        freq_table.add_column("Pct")
        vc = col.value_counts(dropna=False).head(20)
        for val, count in vc.items():
            freq_table.add_row(str(val), str(count), f"{100 * count / n_total:.1f}%")
        parts.append(Text.from_markup("\n[bold]Frequency Table:[/bold]"))
        parts.append(freq_table)

    return Group(*parts)


def _find_column(var_name: str, df: pd.DataFrame) -> Optional[str]:
    """Case-insensitive column lookup."""
    if var_name in df.columns:
        return var_name
    upper_map = {c.upper(): c for c in df.columns}
    return upper_map.get(var_name.upper())

