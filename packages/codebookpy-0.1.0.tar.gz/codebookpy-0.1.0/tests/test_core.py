"""
tests/test_core.py — Unit tests for codebookpy core logic.
Run with: pytest tests/
"""

import json
import warnings
import numpy as np
import pandas as pd
import pytest

from codebookpy.core import (
    _chunk_text,
    _merge_variables,
    _find_column,
    _safe_parse_json,
    _build_df_summary,
    _select_relevant_chunks,
    cb_lookup,
)
from rich.console import Console
from rich.text import Text


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

class MockCodebook:
    _variables = {
        "AGE": {
            "var_name": "AGE",
            "label": "Age of respondent",
            "description": "Age in years at time of survey.",
            "values": [{"code": "-1", "meaning": "Missing"}],
        }
    }
    def get(self, name):
        return self._variables.get(name.upper())


@pytest.fixture
def mock_cb():
    return MockCodebook()


@pytest.fixture
def sample_df():
    np.random.seed(42)
    N = 200
    df = pd.DataFrame({
        "AGE":  np.random.randint(18, 90, N).astype(float),
        "RACE": np.random.choice([1, 2, 3, 4], N),
        "DATE": pd.date_range("2010-01-01", periods=N, freq="D"),
    })
    df.loc[:5, "AGE"] = np.nan
    return df


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def test_chunking_produces_multiple_chunks():
    text = "\n\n".join([f"paragraph {i} " + "x" * 200 for i in range(100)])
    chunks = _chunk_text(text, max_chars=3000)
    assert len(chunks) > 1


def test_chunking_single_chunk_for_short_text():
    text = "short text"
    chunks = _chunk_text(text, max_chars=3000)
    assert len(chunks) == 1


# ---------------------------------------------------------------------------
# Merge / dedup
# ---------------------------------------------------------------------------

def test_merge_dedup_prefers_first_label():
    c1 = [{"var_name": "AGE", "label": "Age of respondent", "description": "Years", "values": []}]
    c2 = [{"var_name": "age", "label": "", "description": "", "values": [{"code": "0", "meaning": "Unknown"}]}]
    merged = _merge_variables([c1, c2])
    assert "AGE" in merged
    assert merged["AGE"]["label"] == "Age of respondent"
    assert len(merged["AGE"]["values"]) == 1


def test_merge_skips_empty_var_names():
    c1 = [{"var_name": "", "label": "ghost", "description": "", "values": []}]
    merged = _merge_variables([c1])
    assert len(merged) == 0


# ---------------------------------------------------------------------------
# JSON safety
# ---------------------------------------------------------------------------

def test_json_strips_markdown_fences():
    payload = [{"var_name": "X", "label": "", "description": "", "values": []}]
    raw = "```json\n" + json.dumps(payload) + "\n```"
    parsed = _safe_parse_json(raw)
    assert len(parsed) == 1 and parsed[0]["var_name"] == "X"


def test_json_clean_parse():
    payload = [{"var_name": "X", "label": "", "description": "", "values": []}]
    parsed = _safe_parse_json(json.dumps(payload))
    assert len(parsed) == 1


def test_json_garbage_returns_empty_with_warning():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = _safe_parse_json("not json at all")
        assert result == []
        assert len(w) == 1


# ---------------------------------------------------------------------------
# Column lookup
# ---------------------------------------------------------------------------

def test_find_column_exact():
    df = pd.DataFrame({"Age": [1], "sex": [0]})
    assert _find_column("Age", df) == "Age"


def test_find_column_case_insensitive():
    df = pd.DataFrame({"Age": [1], "sex": [0]})
    assert _find_column("AGE", df) == "Age"


def test_find_column_missing_returns_none():
    df = pd.DataFrame({"Age": [1]})
    assert _find_column("MISSING", df) is None


# ---------------------------------------------------------------------------
# DF summary
# ---------------------------------------------------------------------------

def test_df_summary_continuous(sample_df):
    result = _build_df_summary("AGE", sample_df)
    assert result is not None


def test_df_summary_categorical(sample_df):
    result = _build_df_summary("RACE", sample_df)
    assert result is not None


def test_df_summary_datetime(sample_df):
    result = _build_df_summary("DATE", sample_df)
    assert result is not None


def test_df_summary_missing_column_returns_text(sample_df):
    result = _build_df_summary("ZZZZ", sample_df)
    assert isinstance(result, Text)


# ---------------------------------------------------------------------------
# Relevance-based chunk selection
# ---------------------------------------------------------------------------

def test_select_relevant_chunks_finds_match():
    chunks = ["this chunk mentions SENTTOT0 variable", "unrelated content here", "MONSEX is described here"]
    result = _select_relevant_chunks(chunks, ["SENTTOT0"], top_n=2)
    assert any("SENTTOT0" in c for c in result)


def test_select_relevant_chunks_fallback_when_no_match():
    chunks = ["chunk one", "chunk two", "chunk three"]
    result = _select_relevant_chunks(chunks, ["ZZZNOTAVAR"], top_n=2)
    assert len(result) == 2


# ---------------------------------------------------------------------------
# cb_lookup
# ---------------------------------------------------------------------------

def test_cb_lookup_warns_without_df(mock_cb):
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        cb_lookup(mock_cb, ["AGE"], summarize_df=True)
        assert any("summarize_df" in str(warning.message) for warning in w)


def test_cb_lookup_renders_found_variable(mock_cb, sample_df):
    cb_lookup(mock_cb, ["AGE"], df=sample_df, summarize_df=True)


def test_cb_lookup_renders_missing_variable(mock_cb):
    cb_lookup(mock_cb, ["ZZZNOTAVAR"])

