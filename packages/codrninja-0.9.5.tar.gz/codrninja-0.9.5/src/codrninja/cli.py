"""Command-line interface for codrninja with dual modes."""

import json
import os
import shlex
import sys

from .agent import Agent, AgentMode
from .config import Config
from .core import AICode
from .skills import SkillRegistry
from .tui_textual import CodrninjaTUI, main_tui
from .mcp import MCPManager
from .permissions import PermissionManager, PermissionRule
from .todo import TodoManager, format_todo_item
from .tools import ToolRegistry
from .safety import SafetyConfig


BUILTIN_SUBAGENT_MODES = {
    'general': AgentMode.BUILD,
    'explore': AgentMode.PLAN,
}


def main():
    automation_mode = os.environ.get('AI_CODE_MODE') == 'automation' or '--json' in sys.argv
    args = [arg for arg in sys.argv[1:] if arg != '--json']

    if len(args) < 1:
        start_tui(None)
        return

    first_arg = args[0]
    known_commands = [
        'create-session', 'send', 'list-sessions', 'show-session',
        'config', 'agent', 'run', 'chat', 'interactive', 'i',
        'new', 'help', '--help', '-h', '--version', '-v',
        'tui', 'onboard', 'skills', 'mcp', 'lsp',
        'build', 'plan', 'review', 'explain', 'test', 'commit', 'exec',
        'search', 'fetch', 'subagent', 'subagents', 'todo', 'permissions',
        'session', 'ask', 'reasoning', 'auth', 'serve',
    ]

    if first_arg not in known_commands and not first_arg.startswith('-'):
        start_tui(first_arg)
        return

    command = first_arg
    ai = AICode()

    if command == 'tui':
        session_name = args[1] if len(args) > 1 else 'default'
        start_tui(session_name)
        return

    if command == 'serve':
        host = '127.0.0.1'
        port = 7384
        for i, arg in enumerate(args[1:], 1):
            if arg == '--host' and i + 1 < len(args):
                host = args[i + 1]
            elif arg == '--port' and i + 1 < len(args):
                port = int(args[i + 1])
        from .server import run_server
        print(f'Starting codrninja server on {host}:{port}')
        run_server(host=host, port=port)
        return

    if command == 'session':
        handle_session_command(ai, args[1:], automation_mode)
        return

    if command == 'create-session':
        if len(args) < 2:
            error_out('Usage: codrninja create-session <name>', automation_mode)
        session = ai.create_session(args[1])
        output({'$schema': 'codrninja.create-session.v1', 'id': session.id, 'name': session.name, 'created': True}, automation_mode)

    elif command == 'send':
        if len(args) < 3:
            error_out('Usage: codrninja send <session> <message>', automation_mode)
        result = ai.send_message(args[1], args[2])
        result['$schema'] = 'codrninja.send.v1'
        output(result, automation_mode)

    elif command == 'list-sessions':
        output({'$schema': 'codrninja.list-sessions.v1', 'sessions': ai.list_sessions()}, automation_mode)

    elif command == 'show-session':
        if len(args) < 2:
            error_out('Usage: codrninja show-session <name>', automation_mode)
        result = ai.get_history(args[1])
        if result:
            result['$schema'] = 'codrninja.show-session.v1'
            output(result, automation_mode)
        else:
            error_out(f"Session '{args[1]}' not found", automation_mode)

    elif command == 'config':
        config = Config.from_env()
        output({
            '$schema': 'codrninja.config.v1',
            'ollama_url': config.ollama_url,
            'default_model': config.default_model,
            'db_path': config.db_path,
        }, automation_mode)

    elif command == 'onboard':
        start_onboarding()

    elif command == 'skills':
        handle_skills(args[1:])

    elif command == 'mcp':
        handle_mcp(args[1:], automation_mode)

    elif command == 'lsp':
        handle_lsp(args[1:], automation_mode)

    elif command in ('agent', 'run', 'ask', 'plan', 'build'):
        handle_agent_command(ai, command, args[1:], automation_mode)

    elif command == 'review':
        if len(args) < 3:
            error_out('Usage: codrninja review <session> <file>', automation_mode)
        session_name, target = args[1], args[2]
        result = ai.tools.read_file(target)
        if result.success:
            run_agent_mode(ai, session_name, f'Review this code:\n\n{result.output}', AgentMode.PLAN, automation_mode)
        else:
            error_out(f'Error reading file: {result.error}', automation_mode)

    elif command == 'explain':
        if len(args) < 3:
            error_out('Usage: codrninja explain <session> <topic>', automation_mode)
        run_agent_mode(ai, args[1], f'Explain: {args[2]}', AgentMode.PLAN, automation_mode)

    elif command == 'test':
        session_name = args[1] if len(args) > 2 else 'default'
        test_cmd = args[2] if len(args) > 2 else (args[1] if len(args) > 1 else 'pytest -q')
        result = ai.tools.execute_command(test_cmd)
        output({'$schema': 'codrninja.test.v1', 'success': result.success, 'output': result.output, 'error': result.error, 'session': session_name}, automation_mode)

    elif command == 'commit':
        if len(args) < 2:
            error_out('Usage: codrninja commit <message>', automation_mode)
        msg = args[1]
        ai.tools.execute_command('git add -A')
        result = ai.tools.execute_command(f'git commit -m {shlex.quote(msg)}')
        output({'$schema': 'codrninja.commit.v1', 'success': result.success, 'output': result.output, 'error': result.error}, automation_mode)

    elif command == 'exec':
        if len(args) < 2:
            error_out('Usage: codrninja exec <command>', automation_mode)
        cmd = ' '.join(args[1:])
        result = ai.tools.execute_command(cmd)
        output({'$schema': 'codrninja.exec.v1', 'success': result.success, 'output': result.output, 'error': result.error}, automation_mode)

    elif command == 'search':
        if len(args) < 2:
            error_out('Usage: codrninja search <query>', automation_mode)
        query = ' '.join(args[1:])
        result = ai.tools.web_search(query)
        payload = {'$schema': 'codrninja.search.v1', 'success': result.success, 'results': None, 'output': result.output, 'error': result.error}
        if result.success:
            try:
                payload['results'] = json.loads(result.output)
            except json.JSONDecodeError:
                payload['results'] = result.output
        output(payload, automation_mode)

    elif command == 'fetch':
        if len(args) < 2:
            error_out('Usage: codrninja fetch <url>', automation_mode)
        url = args[1]
        result = ai.tools.web_fetch(url)
        output({'$schema': 'codrninja.fetch.v1', 'success': result.success, 'content': result.output if result.success else None, 'error': result.error}, automation_mode)

    elif command == 'todo':
        handle_todo(args[1:], automation_mode)

    elif command == 'permissions':
        handle_permissions(args[1:], automation_mode)

    elif command == 'auth':
        handle_auth_command(args[1:], automation_mode)

    elif command == 'subagent':
        if len(args) < 4:
            error_out('Usage: codrninja subagent <session> <name> <task>', automation_mode)
        session_name, name = args[1], args[2]
        task = ' '.join(args[3:])
        ai.create_session(session_name)
        agent = Agent(ai, session_name, max_iterations=10, mode=AgentMode.BUILD)
        mode = BUILTIN_SUBAGENT_MODES.get(name.lower(), AgentMode.BUILD)
        subagent = agent.spawn_subagent(name, task, mode)
        result = subagent.run(task, auto_approve=automation_mode)
        output({
            '$schema': 'codrninja.subagent.v1',
            'success': result.get('success', False),
            'session': session_name,
            'subagent': {
                'name': name,
                'session_id': subagent.session_name,
                'task': task,
                'mode': subagent.mode,
            },
            'result': result,
        }, automation_mode)

    elif command == 'subagents':
        if len(args) < 2:
            error_out('Usage: codrninja subagents <session>', automation_mode)
        session_name = args[1]
        ai.create_session(session_name)
        agent = Agent(ai, session_name, max_iterations=10, mode=AgentMode.BUILD)
        output({'$schema': 'codrninja.subagents.v1', 'session': session_name, 'subagents': agent.subagent_manager.list()}, automation_mode)

    elif command == 'reasoning':
        levels = ['none', 'low', 'medium', 'high']
        if len(args) < 2:
            current = ai.config.reasoning_level
            if automation_mode:
                output({'$schema': 'codrninja.reasoning.v1', 'current': current, 'levels': levels}, True)
            else:
                print(f'Current reasoning level: {current}')
                print(f'Levels: {", ".join(levels)}')
                print(f'Usage: codrninja reasoning <{"|".join(levels)}>')
        else:
            level = args[1].lower()
            if level not in levels:
                error_out(f'Invalid level: {level}. Must be one of: {", ".join(levels)}', automation_mode)
            ai.config.reasoning_level = level
            try:
                config_path = os.path.expanduser('~/.codrninja/config.json')
                config = {}
                if os.path.exists(config_path):
                    with open(config_path) as f:
                        config = json.load(f)
                config['reasoning_level'] = level
                os.makedirs(os.path.dirname(config_path), exist_ok=True)
                with open(config_path, 'w') as f:
                    json.dump(config, f, indent=2)
            except Exception:
                pass
            if automation_mode:
                output({'$schema': 'codrninja.reasoning.v1', 'success': True, 'level': level}, True)
            else:
                print(f'Reasoning level set to: {level}')

    elif command in ('chat', 'interactive', 'i'):
        session_name = args[1] if len(args) > 1 else 'default'
        ai.create_session(session_name)
        app = CodrninjaTUI(ai, session_name)
        app.run()

    elif command == 'new':
        session_name = args[1] if len(args) > 1 else f"session-{os.urandom(4).hex()}"
        ai.create_session(session_name)
        if automation_mode:
            output({'$schema': 'codrninja.new.v1', 'session': session_name, 'status': 'created'}, True)
        else:
            print(f"Created session: {session_name}")
            app = CodrninjaTUI(ai, session_name)
            app.run()

    elif command in ('help', '--help', '-h'):
        if automation_mode:
            output({'$schema': 'codrninja.help.v1', 'help': get_help_text()}, True)
        else:
            print_help()

    elif command in ('--version', '-v'):
        print('codrninja 0.8.7')

    else:
        error_out(f'Unknown command: {command}', automation_mode)


def parse_safety_flags(args):
    config = {
        'dry_run': False,
        'no_shell': False,
        'allow_shell': False,
        'allow_write': False,
        'require_approval': False,
        'max_steps': None,
    }
    cleaned = []
    i = 0
    while i < len(args):
        arg = args[i]
        if arg == '--dry-run':
            config['dry_run'] = True
        elif arg == '--no-shell':
            config['no_shell'] = True
        elif arg == '--allow-shell':
            config['allow_shell'] = True
        elif arg == '--allow-write':
            config['allow_write'] = True
        elif arg == '--require-approval':
            config['require_approval'] = True
        elif arg == '--max-steps' and i + 1 < len(args):
            config['max_steps'] = int(args[i + 1])
            i += 1
        else:
            cleaned.append(arg)
        i += 1
    return cleaned, SafetyConfig.from_cli_flags(**config)




def _spinner_thread(msg: str = ""):
    """Return (start_fn, stop_fn) for a Claude-style flower spinner."""
    import sys, threading, time
    running = [False]
    thread = [None]
    # Claude Code thinking animation characters (left-aligned, no text)
    FLOWERS = ["·", "✻", "✽", "✶", "✳", "✢"]
    PEACH = "\033[38;5;216m"   # 256-color peachy pink (like Claude)
    RESET = "\033[0m"

    def _loop():
        idx = 0
        start = time.monotonic()
        while running[0]:
            elapsed = time.monotonic() - start
            char = FLOWERS[idx % len(FLOWERS)]
            sys.stdout.write(f"\r{PEACH}{char}{RESET}")
            sys.stdout.flush()
            time.sleep(0.12)
            idx += 1
        sys.stdout.write("\r \r")
        sys.stdout.flush()

    def start():
        running[0] = True
        thread[0] = threading.Thread(target=_loop, daemon=True)
        thread[0].start()

    def stop():
        running[0] = False
        if thread[0]:
            thread[0].join(timeout=1.0)

    return start, stop


def handle_agent_command(ai, command, args, automation_mode):
    cleaned_args, safety = parse_safety_flags(args)
    mode = AgentMode.BUILD
    if command == 'plan':
        mode = AgentMode.PLAN
    elif command == 'build':
        mode = AgentMode.BUILD
    elif command in ('agent', 'run'):
        for i, arg in enumerate(list(cleaned_args)):
            if arg == '--mode' and i + 1 < len(cleaned_args):
                mode = cleaned_args[i + 1]
                cleaned_args = cleaned_args[:i] + cleaned_args[i + 2:]
                break

    if len(cleaned_args) < 2:
        error_out(f'Usage: codrninja {command} <session> <message>', automation_mode)

    session_name = cleaned_args[0]
    message = cleaned_args[1]
    ai.create_session(session_name)
    agent = Agent(ai, session_name, max_iterations=10, mode=mode, safety_config=safety)

    if not automation_mode:
        def on_progress(msg):
            print(f"  {msg}")
        agent.on_progress = on_progress
        spinner_start, spinner_stop = _spinner_thread()
        spinner_start()

    result = agent.run(message, auto_approve=automation_mode)
    if not automation_mode:
        spinner_stop()

    schema_name = f'codrninja.{command}.v1'
    if automation_mode:
        result['$schema'] = schema_name
        output(result, True)
    elif result['success']:
        print(f"\n[OK] Task completed in {result['iterations']} iterations")
        print(f"Tools used: {result['tool_calls']}")
        print(f"\nResponse:\n{result['response'][:500]}...")
    else:
        print(f"\n[FAIL] Error: {result.get('error', 'Unknown error')}")


def handle_session_command(ai: AICode, args, automation_mode: bool):
    if not args:
        error_out('Usage: codrninja session <create|list|status|log|events|diff|rollback>', automation_mode)
    action = args[0]
    sm = ai.session_manager
    if action == 'create':
        if len(args) < 2:
            error_out('Usage: codrninja session create <name> [--model <model>]', automation_mode)
        name = args[1]
        model = ai.config.default_model
        if '--model' in args:
            idx = args.index('--model')
            if idx + 1 < len(args):
                model = args[idx + 1]
        state = sm.create(name, model=model, provider=ai.config.default_provider, git_branch=ai.git.get_branch() or '')
        output({'$schema': 'codrninja.session.create.v1', 'session': state}, automation_mode)
        return
    if action == 'list':
        output({'$schema': 'codrninja.session.list.v1', 'sessions': ai.list_sessions()}, automation_mode)
        return
    if len(args) < 2:
        error_out(f'Usage: codrninja session {action} <name>', automation_mode)
    name = args[1]
    state = sm.get(name)
    if not state:
        error_out(f"Session '{name}' not found", automation_mode)
    if action == 'status':
        output({'$schema': 'codrninja.session.status.v1', 'session': state}, automation_mode)
        return
    if action == 'log':
        output({'$schema': 'codrninja.session.log.v1', 'session': state.get('name'), 'messages': sm.get_messages(name)}, automation_mode)
        return
    if action == 'events':
        output({'$schema': 'codrninja.session.events.v1', 'session': state.get('name'), 'events': sm.get_events(name)}, automation_mode)
        return
    if action == 'diff':
        diff = ai.git.get_diff()
        payload = {'$schema': 'codrninja.session.diff.v1', 'session': state.get('name'), 'diff': diff}
        output(payload, automation_mode)
        return
    if action == 'rollback':
        result = ai.git.rollback('stash')
        output({'$schema': 'codrninja.session.rollback.v1', 'session': state.get('name'), 'result': result}, automation_mode)
        return
    error_out('Usage: codrninja session <create|list|status|log|events|diff|rollback>', automation_mode)


def output(data: dict, automation_mode: bool):
    if automation_mode:
        print(json.dumps(data))
    else:
        print(json.dumps(data, indent=2))


def error_out(message: str, automation_mode: bool):
    if automation_mode:
        print(json.dumps({'error': message}))
    else:
        print(f'Error: {message}')
    sys.exit(1)


def print_help():
    print(get_help_text())


def get_help_text() -> str:
    return """Available commands:
  create-session <name>          Create a new session
  send <session> <msg>           Send a message to a session
  list-sessions                  List all sessions
  show-session <name>            Show session history
  session create <name>          Create a file-backed session
  session list                   List sessions
  session status <name>          Show session state.json
  session log <name>             Show messages.jsonl
  session events <name>          Show events.jsonl
  session diff <name>            Show git diff
  session rollback <name>        Restore last stash
  run <session> <task>           Run coding agent
  ask <session> <question>       Ask agent in build mode
  plan <session> <task>          Run plan mode
  build <session> <task>         Run build mode
  config                         Show configuration
  chat [session]                 Interactive mode
  new [session]                  Quick start
  tui [session]                  Start TUI
  onboard                        Run onboarding wizard
  skills                         List skills
  mcp ...                        Manage MCP servers
  lsp ...                        Language server operations
  review <s> <file>              Review code
  explain <s> <topic>            Explain code/concept
  test [command]                 Run tests
  commit <message>               Git commit
  exec <command>                 Execute shell command
  search <query>                 Search the web
  fetch <url>                    Fetch and clean a web page
  todo ...                       Manage todos
  permissions ...                Manage permission rules
  auth <provider|status|revoke>  OAuth authentication helpers
  subagent <s> <n> <t>           Run a child subagent task
  subagents <session>            List active subagents
  reasoning [level]              Get/set reasoning level
  help                           Show help
"""


def run_agent_mode(ai, session_name, message, mode, automation_mode):
    agent = Agent(ai, session_name, max_iterations=10, mode=mode)
    if not automation_mode:
        def on_progress(msg):
            print(f"  {msg}")
        agent.on_progress = on_progress
        spinner_start, spinner_stop = _spinner_thread()
        spinner_start()

    result = agent.run(message, auto_approve=automation_mode)
    if not automation_mode:
        spinner_stop()

    if automation_mode:
        output(result, True)
    elif result['success']:
        print(f"\n[OK] Task completed in {result['iterations']} iterations")
        print(f"Tools used: {result['tool_calls']}")
        print(f"\nResponse:\n{result['response'][:500]}...")
    else:
        print(f"\n[FAIL] Error: {result.get('error', 'Unknown error')}")


def _find_ts_tui() -> str | None:
    """Return path to the TypeScript TUI directory, or None if not found."""
    import os
    candidates = [
        os.environ.get('CODRNINJA_TUI_PATH', ''),
        os.path.expanduser('~/.codrninja/tui'),
        os.path.expanduser('~/codrninja-tui'),
    ]
    for path in candidates:
        if path and os.path.isfile(os.path.join(path, 'package.json')):
            return path
    return None


def _port_in_use(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0


def _kill_server(port: int = 7384):
    """Kill any running codrninja server on the given port."""
    import signal
    try:
        import subprocess as _sp
        # Find and kill processes using the port
        result = _sp.run(
            ['lsof', '-ti', f':{port}'],
            capture_output=True, text=True, timeout=3,
        )
        for pid_str in result.stdout.strip().split('\n'):
            pid_str = pid_str.strip()
            if pid_str.isdigit():
                try:
                    os.kill(int(pid_str), signal.SIGTERM)
                except ProcessLookupError:
                    pass
    except Exception:
        pass


def _start_server_background(port: int = 7384):
    """Kill any old server and start a fresh one so updated code is always used."""
    import subprocess as _sp
    import sys as _sys
    import time
    if _port_in_use(port):
        _kill_server(port)
        # Wait briefly for the port to free up
        for _ in range(20):
            if not _port_in_use(port):
                break
            time.sleep(0.1)
    _sp.Popen(
        [_sys.executable, '-m', 'codrninja', 'serve', '--port', str(port)],
        start_new_session=True,
        stdout=_sp.DEVNULL,
        stderr=_sp.DEVNULL,
    )


def _wait_for_server(port: int = 7384, timeout: float = 8.0):
    """Poll /health until server is up or timeout."""
    import time
    import urllib.request
    url = f'http://127.0.0.1:{port}/health'
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            urllib.request.urlopen(url, timeout=0.5)
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f'Server did not start within {timeout}s')


def _launch_ts_tui(tui_path: str, session_name: str | None, port: int = 7384):
    """Exec the TypeScript TUI, replacing the current process image."""
    import os
    import shutil
    import subprocess

    env = {**os.environ, 'CODRNINJA_SERVER': f'http://127.0.0.1:{port}'}
    if session_name:
        env['CODRNINJA_SESSION'] = session_name

    # Prefer pre-built dist, fall back to tsx dev mode
    dist_entry = os.path.join(tui_path, 'dist', 'index.js')
    if os.path.isfile(dist_entry):
        node = shutil.which('node') or 'node'
        cmd = [node, dist_entry]
    else:
        tsx_local = os.path.join(tui_path, 'node_modules', '.bin', 'tsx')
        tsx = shutil.which('tsx') or (tsx_local if os.path.isfile(tsx_local) else None)
        if not tsx:
            if not os.path.isdir(os.path.join(tui_path, 'node_modules')):
                print('Installing TUI dependencies…')
                subprocess.run(['npm', 'install', '--silent'], cwd=tui_path,
                               check=False, timeout=120)
            tsx = tsx_local
        cmd = [tsx, os.path.join(tui_path, 'src', 'index.tsx')]

    # Replace Python process with Node so Ctrl+C goes straight to Node,
    # no dangling Python wrapper to raise KeyboardInterrupt.
    os.execvpe(cmd[0], cmd, {**env, 'FORCE_COLOR': '1'})


def start_tui(session_name: str = None):
    tui_path = _find_ts_tui()
    if tui_path:
        _start_server_background()
        try:
            _wait_for_server()
        except RuntimeError as e:
            print(f'[FAIL] {e}')
            sys.exit(1)
        _launch_ts_tui(tui_path, session_name)
        return

    # Fallback: Textual TUI (no TypeScript TUI found)
    try:
        ai = AICode()
        app = CodrninjaTUI(ai, session_name)
        app.run()
    except ImportError:
        print('[FAIL] Rich not installed. Install with: pip3 install rich')
        print('   Or use: codrninja chat my-session')
        sys.exit(1)
    except Exception as e:
        print(f'[FAIL] Error starting TUI: {e}')
        sys.exit(1)


def start_onboarding():
    ai = AICode()
    app = CodrninjaTUI(ai, 'onboarding')
    app.run()


def handle_skills(args):
    registry = SkillRegistry()
    registry.discover()
    if not args:
        skills = registry.list_skills()
        if not skills:
            print('No skills installed.')
            return
        for skill in skills:
            print(f"{skill['name']}: {skill['description']}")
        return
    error_out('Usage: codrninja skills', False)


def handle_todo(args, automation_mode: bool):
    manager = TodoManager()
    if not args or args[0] == 'list':
        session = args[1] if len(args) > 1 else None
        todos = manager.list(session) if session else manager.list_all()
        payload = [{
            'id': todo.id,
            'session_id': todo.session_id,
            'task': todo.task,
            'status': todo.status,
            'created_at': todo.created_at,
            'completed_at': todo.completed_at,
            'display': format_todo_item(todo),
        } for todo in todos]
        output({'$schema': 'codrninja.todo.list.v1', 'todos': payload}, automation_mode)
        return
    action = args[0]
    if action == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja todo add <session> <task>', automation_mode)
        session = args[1]
        task = ' '.join(args[2:]).strip()
        todo_id = manager.add(task, session)
        todo = manager.get(todo_id)
        output({'$schema': 'codrninja.todo.add.v1', 'success': True, 'todo': {
            'id': todo.id,
            'session_id': todo.session_id,
            'task': todo.task,
            'status': todo.status,
            'created_at': todo.created_at,
            'completed_at': todo.completed_at,
            'display': format_todo_item(todo),
        }}, automation_mode)
        return
    if action == 'done':
        if len(args) < 2:
            error_out('Usage: codrninja todo done <id>', automation_mode)
        ok = manager.complete(args[1])
        if not ok:
            error_out(f"Todo not found: {args[1]}", automation_mode)
        todo = manager.get(args[1])
        output({'$schema': 'codrninja.todo.done.v1', 'success': True, 'todo': {
            'id': todo.id,
            'session_id': todo.session_id,
            'task': todo.task,
            'status': todo.status,
            'created_at': todo.created_at,
            'completed_at': todo.completed_at,
            'display': format_todo_item(todo),
        }}, automation_mode)
        return
    if action == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja todo remove <id>', automation_mode)
        ok = manager.remove(args[1])
        if not ok:
            error_out(f"Todo not found: {args[1]}", automation_mode)
        output({'$schema': 'codrninja.todo.remove.v1', 'success': True, 'removed': args[1]}, automation_mode)
        return
    error_out('Usage: codrninja todo [list [session]|add <session> <task>|done <id>|remove <id>]', automation_mode)


def handle_permissions(args, automation_mode: bool):
    manager = PermissionManager(mode=Config.from_env().permissions_mode)
    if not args or args[0] == 'list':
        rules = [{
            'pattern': rule.pattern,
            'action': rule.action,
            'scope': rule.scope,
            'agent_type': rule.agent_type,
            'priority': rule.priority,
        } for rule in manager.list_rules()]
        output({'$schema': 'codrninja.permissions.list.v1', 'default': manager.default_action, 'rules': rules}, automation_mode)
        return
    command = args[0]
    if command == 'mode':
        if len(args) < 2:
            error_out('Usage: codrninja permissions mode <none|ask|auto|strict|relaxed|custom>', automation_mode)
        manager.set_mode(args[1])
        output({'$schema': 'codrninja.permissions.mode.v1', 'success': True, 'mode': manager.mode, 'default': manager.default_action}, automation_mode)
        return
    if command == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja permissions add <pattern> <action> [scope]', automation_mode)
        pattern = args[1]
        action = args[2]
        scope = args[3] if len(args) > 3 else 'all'
        manager.add_rule(PermissionRule(pattern, action, scope, 'all', 100))
        output({'$schema': 'codrninja.permissions.add.v1', 'success': True, 'added': pattern}, automation_mode)
        return
    if command == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja permissions remove <pattern>', automation_mode)
        removed = manager.remove_rule(args[1])
        output({'$schema': 'codrninja.permissions.remove.v1', 'success': removed, 'removed': args[1]}, automation_mode)
        return
    if command == 'default':
        if len(args) < 2:
            error_out('Usage: codrninja permissions default <action>', automation_mode)
        manager.set_default(args[1])
        output({'$schema': 'codrninja.permissions.default.v1', 'success': True, 'default': manager.default_action}, automation_mode)
        return
    if command == 'explain':
        if len(args) < 3:
            error_out('Usage: codrninja permissions explain <action> <path>', automation_mode)
        output({'$schema': 'codrninja.permissions.explain.v1', 'explanation': manager.explain(args[1], args[2], 'build')}, automation_mode)
        return
    error_out('Usage: codrninja permissions [list|mode|add|remove|default|explain]', automation_mode)


def handle_auth_command(args, automation_mode: bool):
    from .auth import OAuthFlow, TokenManager

    token_manager = TokenManager()
    if not args or args[0] == 'status':
        status = token_manager.list_status()
        payload = {'$schema': 'codrninja.auth.status.v1', 'providers': status}
        if not status:
            payload['providers'] = {}
        output(payload, automation_mode)
        return

    action = args[0].lower()
    if action == 'revoke':
        if len(args) < 2:
            error_out('Usage: codrninja auth revoke <provider>', automation_mode)
        provider = args[1].lower()
        removed = token_manager.revoke(provider)
        if not removed:
            error_out(f'No stored OAuth tokens for {provider}', automation_mode)
        output({'$schema': 'codrninja.auth.revoke.v1', 'success': True, 'provider': provider}, automation_mode)
        return

    provider = action
    if provider not in ('anthropic', 'openai'):
        error_out('Usage: codrninja auth <anthropic|openai|status|revoke>', automation_mode)
    flow = OAuthFlow(provider)
    success, detail = flow.run()
    payload = {'$schema': 'codrninja.auth.run.v1', 'success': success, 'provider': provider, 'detail': detail}
    if not success and automation_mode:
        print(json.dumps(payload))
        sys.exit(1)
    if not success:
        error_out(detail, automation_mode)
    output(payload, automation_mode)


def handle_mcp(args, automation_mode: bool):
    manager = MCPManager()
    if not args or args[0] == 'list':
        servers = [{
            'name': server.name,
            'type': server.type,
            'enabled': server.enabled,
            'tool_count': len(server.tools),
        } for server in manager.list_servers()]
        output({'$schema': 'codrninja.mcp.list.v1', 'servers': servers}, automation_mode)
        return
    command = args[0]
    if command == 'add':
        if len(args) < 3:
            error_out('Usage: codrninja mcp add <name> <config_json>', automation_mode)
        name = args[1]
        try:
            config = json.loads(' '.join(args[2:]))
        except json.JSONDecodeError as e:
            error_out(f'Invalid JSON: {e}', automation_mode)
        config['name'] = name
        server = manager.add_server(config)
        output({'$schema': 'codrninja.mcp.add.v1', 'added': server.name}, automation_mode)
        return
    if command == 'remove':
        if len(args) < 2:
            error_out('Usage: codrninja mcp remove <name>', automation_mode)
        output({'$schema': 'codrninja.mcp.remove.v1', 'removed': manager.remove_server(args[1])}, automation_mode)
        return
    if command == 'tools':
        tools = manager.discover_tools(force=True)
        output({'$schema': 'codrninja.mcp.tools.v1', 'tools': tools}, automation_mode)
        return
    error_out('Usage: codrninja mcp [list|add|remove|tools]', automation_mode)


def handle_lsp(args, automation_mode: bool):
    tools = ToolRegistry()
    if not args or args[0] == 'status':
        output({'$schema': 'codrninja.lsp.status.v1', 'servers': tools.lsp.status()}, automation_mode)
        return
    command = args[0]
    if command == 'start':
        if len(args) < 2:
            error_out('Usage: codrninja lsp start <lang>', automation_mode)
        language = args[1]
        client = tools.lsp.get_client(language)
        if not client:
            error_out(tools.lsp.install_hint(language), automation_mode)
        output({'$schema': 'codrninja.lsp.start.v1', 'started': language, 'command': client.command}, automation_mode)
        return
    if command == 'stop':
        if len(args) < 2:
            error_out('Usage: codrninja lsp stop <lang>', automation_mode)
        language = args[1]
        stopped = tools.lsp.stop(language)
        output({'$schema': 'codrninja.lsp.stop.v1', 'stopped': stopped, 'language': language}, automation_mode)
        return
    if command == 'diagnostics':
        if len(args) < 2:
            error_out('Usage: codrninja lsp diagnostics <file>', automation_mode)
        result = tools.lsp_diagnostics(args[1])
        payload = {'$schema': 'codrninja.lsp.diagnostics.v1', 'success': result.success, 'file': args[1], 'diagnostics': result.output if result.success else None, 'error': result.error}
        output(payload, automation_mode)
        return
    error_out('Usage: codrninja lsp [status|start <lang>|stop <lang>|diagnostics <file>]', automation_mode)


if __name__ == '__main__':
    main()
