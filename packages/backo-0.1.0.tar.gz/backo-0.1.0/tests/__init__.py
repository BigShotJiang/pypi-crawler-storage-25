"""
all imports
"""

import sys

sys.path.insert(1, "../stricto")

from .test_crud import TestCRUD
from .test_log import TestLog

from .test_mongo import TestMongo
from .test_action import TestAction
from .test_routes import TestRoutes
from .test_reference import TestReferences
from .test_selections import TestSelections
from .test_api_toolbox import TestApiToolbox
from .test_meta import TestMeta
from .test_current_user import TestCurrentUser
