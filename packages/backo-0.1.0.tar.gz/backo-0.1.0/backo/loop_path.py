"""
Loop path manipulation
"""

from .error import BackoError

DEFAULT_MAX_LOOP = 40

from .log import log_system, LogLevel

log = log_system.get_or_create_logger("loop", LogLevel.INFO)


class LoopPath:
    """
    A loop object to detect loop maniipulation in reference
    """

    def __init__(self, max_loop=DEFAULT_MAX_LOOP):
        """ """
        self._path = []
        self.max_loop = max_loop

    def is_loop(self, collection_name: str, _id: str, path: str) -> bool:
        """detect if already in the path

        :param collection_name: the name of the collection
        :type collection_name: str
        :param _id: the _id of the object in the collection
        :type _id: str
        :param path: the path (ex : $.site )
        :type path: str
        :return: True if seen
        :rtype: bool
        """
        for m_path in self._path:
            if m_path == (collection_name, _id, path):
                return True
        return False

    def append(self, collection_name: str, _id: str, path: str) -> None:
        """Append to the path a tuple (collection, _id, path )

        :param collection_name: the name of the collection
        :type collection_name: str
        :param _id: the _id of the object in the collection
        :type _id: str
        :param path: the path (ex : $.site )
        :type path: str
        """

        if len(self._path) > self.max_loop:
            raise BackoError(
                "Loop max detected for ( {0}, {1}, {2})", collection_name, _id, path
            )

        self._path.append((collection_name, _id, path))
