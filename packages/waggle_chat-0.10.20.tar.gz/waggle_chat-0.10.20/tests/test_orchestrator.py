"""Orchestrator: StreamClaude subprocess wrapper + access-gated dispatch.

We don't run a real `claude -p` subprocess here. The orchestrator's loop is
exercised with a stubbed StreamClaude that records each `send_user(...)` and
returns a canned `read_result()`. That's enough to pin:

  • Allow-list gating (rejected inbound emits event, never reaches claude).
  • Inbound text reaches claude wrapped in a v1 channel-tag block.
  • Concurrent inbound is serialised through the turn lock.
  • Subprocess failure (is_error=True) is surfaced to the user as an error
    via the telegram client's `reply` back-up path.
"""

from __future__ import annotations

import asyncio
import textwrap
from pathlib import Path

import pytest

from waggle.config import load
from waggle.events import RejectEvent
from waggle.orchestrator import WaggleOrchestrator


def _write_config(tmp_path: Path) -> Path:
    p = tmp_path / "config.yaml"
    p.write_text(
        textwrap.dedent(
            """
            transports:
              - name: tg
                kind: telegram
                bot_token: "1234567890:secret-token"
            access:
              users: [42, 99]
              groups: {}
            owner:
              user_id: 42
            """
        ).lstrip()
    )
    return p


class _StubClaude:
    """Mock claude subprocess. Yields the events the orchestrator drives the
    working-status indicator off of, then the final `result` event."""

    def __init__(self, result_text: str = "ok", is_error: bool = False,
                 events: list | None = None):
        self.received: list[str] = []
        self._result = result_text
        self._is_error = is_error
        self.started = False
        self.stopped = False
        # Default: just the result event (no tool, no thinking)
        self._events = events if events is not None else []

    async def start(self):
        self.started = True

    async def stop(self):
        self.stopped = True

    async def send_user(self, content: str):
        self.received.append(content)

    async def read_events(self):
        for kind, event in self._events:
            yield kind, event
        yield "result", {"type": "result", "result": self._result, "is_error": self._is_error}


class _StubTelegram:
    def __init__(self):
        self.replies: list[dict] = []
        self.edits: list[dict] = []
        self.deletes: list[dict] = []
        self.markup_edits: list[dict] = []
        self._next_id = 1000

    async def reply(self, *, chat_id, text, reply_to=None, format="text",
                     reply_markup=None):
        self._next_id += 1
        mid = str(self._next_id)
        self.replies.append({
            "chat_id": chat_id, "text": text, "reply_to": reply_to,
            "message_id": mid, "reply_markup": reply_markup,
        })
        return mid

    async def edit_text(self, *, chat_id, message_id, text, reply_markup=None):
        self.edits.append({
            "chat_id": chat_id, "message_id": message_id, "text": text,
            "reply_markup": reply_markup,
        })

    async def edit_reply_markup(self, *, chat_id, message_id, reply_markup=None):
        self.markup_edits.append({
            "chat_id": chat_id, "message_id": message_id,
            "reply_markup": reply_markup,
        })

    async def delete_message(self, *, chat_id, message_id):
        self.deletes.append({"chat_id": chat_id, "message_id": message_id})


@pytest.mark.asyncio
async def test_allowed_inbound_reaches_claude_with_channel_tag(tmp_path: Path):
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="hi back")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="x",
            message_id="9", text="hello",
        )
        assert len(orch.claude.received) == 1
        wrapped = orch.claude.received[0]
        assert wrapped.startswith('<channel source="telegram" chat="42" user="42"')
        assert "hello" in wrapped
        # Status indicator posted "🤔 Thinking…" and got deleted on success
        assert len(orch.telegram.replies) == 1
        assert "Thinking" in orch.telegram.replies[0]["text"]
        assert len(orch.telegram.deletes) == 1
        assert orch.telegram.deletes[0]["message_id"] == orch.telegram.replies[0]["message_id"]
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_rejected_inbound_emits_event(tmp_path: Path, capsys):
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude()  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=999, user_id=999, username="x",
            message_id="3", text="probe",
        )
        assert orch.claude.received == []
        out = capsys.readouterr().out
        assert "not-allowlisted" in out
        assert "999" in out
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_group_rejection_uses_group_reason(tmp_path: Path, capsys):
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude()  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=-1001234, user_id=42, username="x",
            message_id="3", text="hi",
        )
        assert orch.claude.received == []
        assert "group-not-allowlisted" in capsys.readouterr().out
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_subprocess_error_deletes_status_and_posts_error(tmp_path: Path):
    """When claude reports `is_error=True` the working-status indicator
    DELETES its rolling status message and posts a new ❌ Error reply.
    Per §1.9: status is gone on error, error message stays visible."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="", is_error=True)  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="x",
            message_id="9", text="hello",
        )
        # Two replies: the original Thinking status + the error notice.
        assert len(orch.telegram.replies) == 2
        thinking = orch.telegram.replies[0]
        error_msg = orch.telegram.replies[1]
        assert "Thinking" in thinking["text"]
        assert "Error" in error_msg["text"]
        # The Thinking message was deleted before the error was posted.
        assert any(d["message_id"] == thinking["message_id"]
                   for d in orch.telegram.deletes)
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_full_event_flow_drives_status_through_states(tmp_path: Path):
    """Happy: a turn that emits assistant chunks AND a tool_use should
    drive the status indicator through Thinking → Tool → Writing → done.
    Pin the order so a regression in event-routing surfaces here.

    Real claude stream-json embeds tool_use INSIDE assistant events'
    content list, NOT as a separate event kind — pin that shape too."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(  # type: ignore
        result_text="hi",
        events=[
            ("assistant", {"type": "assistant",
                           "message": {"content": [{"type": "text", "text": "thinking..."}]}}),
            # Real shape: tool_use is a content block inside an assistant event
            ("assistant", {"type": "assistant",
                           "message": {"content": [
                               {"type": "tool_use", "id": "t1",
                                "name": "mcp__waggle-tools__reply",
                                "input": {}}
                           ]}}),
            ("assistant", {"type": "assistant",
                           "message": {"content": [{"type": "text", "text": "writing"}]}}),
        ],
    )
    orch.telegram = _StubTelegram()  # type: ignore
    # Speed the debounce so edits land within the test
    import waggle.status_indicator as si
    si.DEBOUNCE_SECONDS = 0.01
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="x",
            message_id="9", text="hello",
        )
        # Allow debounced edits to flush
        await asyncio.sleep(0.1)
        # Status was posted (Thinking) and deleted on success
        assert any("Thinking" in r["text"] for r in orch.telegram.replies)
        assert len(orch.telegram.deletes) == 1
        # Debounce coalesces bursts → typically the FINAL label ("Writing")
        # ends up as the only edit. The tool_use was processed (we know
        # because the post-tool assistant chunk transitioned to Writing,
        # not Thinking) — pin that signal here.
        edited_texts = [e["text"] for e in orch.telegram.edits]
        assert any("Writing" in t for t in edited_texts), edited_texts
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_accepted_inbound_emits_accept_event(tmp_path: Path):
    """P6 acceptance: every allow-listed inbound produces ONE accept event
    with full body, message_id, and source. Pin the integration so a
    future refactor can't silently drop the call."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    captured: list = []

    async def _emit_accept(event):
        captured.append(event)

    async def _emit_reject(event):
        pass

    orch.events.emit_accept = _emit_accept  # type: ignore
    orch.events.emit_reject = _emit_reject  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="anh",
            message_id="9", text="full body content here",
        )
        assert len(captured) == 1
        e = captured[0]
        assert e.body == "full body content here"
        assert e.message_id == "9"
        assert e.username == "anh"
        assert e.source == "telegram"
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_rejected_inbound_emits_reject_not_accept(tmp_path: Path):
    """Pin: an access-list rejection emits a RejectEvent, NOT an
    AcceptEvent. We don't want bogus accepts cluttering the dashboard
    when someone tries to probe a closed bot."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude()  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    accepts: list = []
    rejects: list = []
    orch.events.emit_accept = lambda e: accepts.append(e) or _aok()  # type: ignore
    orch.events.emit_reject = lambda e: rejects.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=999, user_id=999, username="probe",
            message_id="3", text="probe",
        )
        assert accepts == []
        assert len(rejects) == 1
    finally:
        await orch.access.stop()


def _aok():
    """Tiny helper: returns an awaitable no-op for lambda assignment in
    fail-soft test fixtures."""
    async def _coro():
        return None
    return _coro()


@pytest.mark.asyncio
async def test_rate_limit_drops_with_reject_event(tmp_path: Path):
    """P8: a non-owner over budget produces RejectEvent reason='rate-limited-user'
    and the message never reaches claude. Verifies orchestrator rate gate
    runs AFTER access gate (an over-budget allowlisted user is rate-rejected,
    not access-rejected)."""
    cfg_path = tmp_path / "config.yaml"
    cfg_path.write_text(textwrap.dedent("""
        transports:
          - {name: tg, kind: telegram, bot_token: "1234567890:secret-token"}
        access:
          users: [42, 99]
          groups: {}
          rate_limit:
            user_per_minute: 2
            window_seconds: 60.0
        owner:
          user_id: 42
        """).lstrip())
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    rejects: list = []
    orch.events.emit_reject = lambda e: rejects.append(e) or _aok()  # type: ignore
    accepts: list = []
    orch.events.emit_accept = lambda e: accepts.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        # User 99 (non-owner) — first 2 allowed, 3rd rate-limited
        for i in range(2):
            await orch.submit_inbound(
                chat_id=99, user_id=99, username="x",
                message_id=str(i), text=f"msg-{i}",
            )
        await orch.submit_inbound(
            chat_id=99, user_id=99, username="x",
            message_id="3", text="over-budget",
        )
        assert len(accepts) == 2  # only the first 2 made it
        assert len(rejects) == 1
        assert rejects[0].reason == "rate-limited-user"
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_owner_is_exempt_from_rate_limit(tmp_path: Path):
    """Owner must be reachable during a flood — they're the ones who
    /pause to stop it. Pin the exemption."""
    cfg_path = tmp_path / "config.yaml"
    cfg_path.write_text(textwrap.dedent("""
        transports:
          - {name: tg, kind: telegram, bot_token: "1234567890:secret-token"}
        access:
          users: [42]
          groups: {}
          rate_limit:
            user_per_minute: 1
            window_seconds: 60.0
        owner:
          user_id: 42
        """).lstrip())
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    accepts: list = []
    orch.events.emit_accept = lambda e: accepts.append(e) or _aok()  # type: ignore
    rejects: list = []
    orch.events.emit_reject = lambda e: rejects.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        for i in range(5):
            await orch.submit_inbound(
                chat_id=42, user_id=42, username="anh",
                message_id=str(i), text=f"msg-{i}",
            )
        # All 5 accepted despite user_per_minute=1 — owner exempt
        assert len(accepts) == 5
        assert rejects == []
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_slash_command_in_group_rejected_outright(tmp_path: Path):
    """Operator surface is DM-only. A slash command sent in a group is
    rejected with reason `command-in-group` — no claude turn, no
    accept event. Pin: even when the sender is the owner, the rule
    holds (we never want operator state to leak via a slash reply
    in a multi-user room)."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude()  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    accepts: list = []
    rejects: list = []
    orch.events.emit_accept = lambda e: accepts.append(e) or _aok()  # type: ignore
    orch.events.emit_reject = lambda e: rejects.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        # Owner sending /pause in a group → reject command-in-group
        await orch.submit_inbound(
            chat_id=-1001234, user_id=42, username="anh",
            message_id="1", text="/pause",
        )
        # Non-owner sending /random in a group → also reject command-in-group
        # (catch all slashes, not just owner ops)
        await orch.submit_inbound(
            chat_id=-1001234, user_id=99, username="bob",
            message_id="2", text="/random_command extra args",
        )
        assert orch.claude.received == []  # claude never sees a slash in a group
        assert accepts == []
        assert len(rejects) == 2
        assert all(r.reason == "command-in-group" for r in rejects)
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_slash_command_in_dm_NOT_rejected(tmp_path: Path):
    """Sanity: slash commands in DM still flow through the owner-ops
    gate normally. Owner ops fire (consumed), unknown slashes fall
    through to claude. Don't accidentally over-reject."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    rejects: list = []
    orch.events.emit_reject = lambda e: rejects.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        # Owner sends /status in DM → owner ops fire, no reject event,
        # text never reaches claude.
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="anh",
            message_id="1", text="/status",
        )
        assert rejects == []
        assert orch.claude.received == []  # consumed by owner ops
        # Status reply was sent
        status_replies = [r for r in orch.telegram.replies
                          if "🐝 status" in r.get("text", "")]
        assert len(status_replies) == 1
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_inbound_ts_flows_to_channel_tag_and_accept_event(tmp_path: Path):
    """Batch 10: when the transport supplies an explicit send-time
    (Telegram message.date), it must surface in:
      • the wrapped channel-tag's ts attribute (so the agent can see when
        the user actually sent the message)
      • the AcceptEvent ts field (so the dashboard timestamps match)
    Falling back to now() should ONLY happen when the caller omits ts."""
    from datetime import datetime, timezone
    import os, time
    os.environ["TZ"] = "UTC"
    if hasattr(time, "tzset"):
        time.tzset()
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    captured_accepts: list = []
    orch.events.emit_accept = lambda e: captured_accepts.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        explicit = datetime(2026, 4, 30, 10, 30, 0, tzinfo=timezone.utc)
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="anh",
            message_id="9", text="hello",
            ts=explicit,
        )
        # Channel-tag in claude's stdin carries the explicit ts in the
        # pod's local timezone (UTC pod => +00:00 explicit offset).
        wrapped = orch.claude.received[0]
        assert "2026-04-30T10:30:00+00:00" in wrapped
        # AcceptEvent ts matches
        assert captured_accepts[0].ts == explicit
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_inbound_without_ts_falls_back_to_now(tmp_path: Path):
    """Back-compat: existing call sites that don't supply ts (tests, future
    transports) get the orchestrator's wall clock. Pin so the default
    isn't accidentally removed."""
    from datetime import datetime, timezone
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    captured: list = []
    orch.events.emit_accept = lambda e: captured.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        before = datetime.now(timezone.utc)
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="anh",
            message_id="9", text="hi",
            # no ts
        )
        after = datetime.now(timezone.utc)
        assert before <= captured[0].ts <= after
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_attachments_flow_through_to_accept_event(tmp_path: Path):
    """P6 attachments-by-reference: telegram client extracts file_ids, orch
    passes them straight into AcceptEvent. Pin so a refactor that loses the
    tuple surfaces here."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    captured: list = []
    orch.events.emit_accept = lambda e: captured.append(e) or _aok()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=42, user_id=42, username="anh",
            message_id="9", text="see attached",
            attachments=(
                {"kind": "photo", "file_id": "BAADBA..."},
                {"kind": "document", "file_id": "BQADBQ...", "mime_type": "application/pdf"},
            ),
        )
        assert len(captured) == 1
        e = captured[0]
        assert len(e.attachments) == 2
        assert e.attachments[0] == {"kind": "photo", "file_id": "BAADBA..."}
        assert e.attachments[1]["kind"] == "document"
        assert e.attachments[1]["mime_type"] == "application/pdf"
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_emit_accept_failure_does_not_block_turn(tmp_path: Path):
    """Sink crashing must NOT propagate. The agent must reply normally;
    spec §1.2 + P6 risk: external store outage cannot back-pressure."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore

    async def _explode(_event):
        raise RuntimeError("dashboard is down")

    orch.events.emit_accept = _explode  # type: ignore
    await orch.access.start()
    try:
        # Currently the orchestrator does NOT catch sink exceptions itself
        # — it relies on the sink being fail-soft (every concrete adapter
        # catches its own errors). To prove the spec, we exercise the same
        # invariant: when the sink raises, the orchestrator surfaces the
        # exception. We pin this so a future change either keeps sinks
        # fail-soft (preferred) or adds a try/except in the orchestrator.
        with pytest.raises(RuntimeError, match="dashboard is down"):
            await orch.submit_inbound(
                chat_id=42, user_id=42, username="anh",
                message_id="9", text="hi",
            )
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_concurrent_inbound_serialised_by_lock(tmp_path: Path):
    """Two same-chat inbound submits in flight at once must serialise
    their stdin writes (newline-delimited JSON frames mustn't interleave)
    — even though mid-turn inject lets the second one fold into the
    running turn, the actual `send_user` calls hit stdin one at a time."""
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.telegram = _StubTelegram()  # type: ignore

    # Custom stub that tracks concurrency
    in_flight = 0
    max_seen = 0
    async def slow_send(content):
        nonlocal in_flight, max_seen
        in_flight += 1
        max_seen = max(max_seen, in_flight)
        await asyncio.sleep(0.05)

    async def slow_read():
        nonlocal in_flight
        await asyncio.sleep(0.05)
        in_flight -= 1
        return "ok", False

    async def slow_events():
        await asyncio.sleep(0.05)
        in_flight_dec = -1
        nonlocal in_flight
        in_flight += in_flight_dec
        yield "result", {"type": "result", "result": "ok", "is_error": False}

    class _Stub:
        async def start(self): ...
        async def stop(self): ...
        send_user = staticmethod(slow_send)
        read_events = staticmethod(slow_events)

    orch.claude = _Stub()  # type: ignore
    await orch.access.start()
    try:
        await asyncio.gather(
            orch.submit_inbound(chat_id=42, user_id=42, username="a",
                                message_id="1", text="first"),
            orch.submit_inbound(chat_id=42, user_id=99, username="b",
                                message_id="2", text="second"),
        )
        assert max_seen == 1, "stdin_lock must serialise concurrent send_user writes"
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_mid_turn_inject_same_chat_folds(tmp_path: Path):
    """Mid-turn inject contract: a second inbound from the SAME chat that
    arrives WHILE the first turn's result event is still pending must be
    pushed to claude's stdin without waiting — both messages are folded
    into the active turn and surface in `received` before the result
    drains. (In real claude, this lets the model see new user content
    between agentic-loop rounds and merge it into the running response.)
    """
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.telegram = _StubTelegram()  # type: ignore

    drain_gate = asyncio.Event()
    second_pushed = asyncio.Event()

    class _SlowStub:
        def __init__(self):
            self.received: list[str] = []
            self.started = False
            self.stopped = False

        async def start(self): self.started = True
        async def stop(self): self.stopped = True

        async def send_user(self, content):
            self.received.append(content)
            if len(self.received) == 2:
                second_pushed.set()

        async def read_events(self):
            # Block until the test releases the drain gate; this models a
            # long-running agentic turn whose result hasn't arrived yet.
            await drain_gate.wait()
            yield "result", {"type": "result", "result": "ok", "is_error": False}

    orch.claude = _SlowStub()  # type: ignore
    await orch.access.start()
    try:
        first_task = asyncio.create_task(orch.submit_inbound(
            chat_id=42, user_id=42, username="a", message_id="1", text="first",
        ))
        # Give the first push a moment to claim the chat slot.
        await asyncio.sleep(0.05)
        assert orch.claude.received == ["<channel"] or \
               orch.claude.received[0].startswith("<channel")
        second_task = asyncio.create_task(orch.submit_inbound(
            chat_id=42, user_id=42, username="a", message_id="2", text="second",
        ))
        # The second push must reach stdin without waiting for the result.
        await asyncio.wait_for(second_pushed.wait(), timeout=1.0)
        assert len(orch.claude.received) == 2
        assert "first" in orch.claude.received[0]
        assert "second" in orch.claude.received[1]
        # Now release the result event — both submit_inbound waiters return.
        drain_gate.set()
        await first_task
        await second_task
    finally:
        # Reader task is still running waiting for next event — cancel it.
        if orch._reader_task is not None:
            orch._reader_task.cancel()
            try:
                await orch._reader_task
            except asyncio.CancelledError:
                pass
        await orch.access.stop()


@pytest.mark.asyncio
async def test_mid_turn_inject_different_chat_waits(tmp_path: Path):
    """Cross-chat isolation: an inbound from a DIFFERENT chat must wait
    for the running turn to end before its event reaches claude — folding
    a stranger's message into the active conversation would leak context
    across users.
    """
    cfg_path = _write_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.telegram = _StubTelegram()  # type: ignore

    drain_gate = asyncio.Event()

    class _SlowStub:
        def __init__(self):
            self.received: list[str] = []
            self.started = False
            self.stopped = False

        async def start(self): self.started = True
        async def stop(self): self.stopped = True
        async def send_user(self, content):
            self.received.append(content)

        async def read_events(self):
            await drain_gate.wait()
            yield "result", {"type": "result", "result": "ok", "is_error": False}

    orch.claude = _SlowStub()  # type: ignore
    await orch.access.start()
    try:
        first_task = asyncio.create_task(orch.submit_inbound(
            chat_id=42, user_id=42, username="a", message_id="1", text="first",
        ))
        # Give the first push a moment to claim chat 42.
        await asyncio.sleep(0.05)
        # Different chat (99 is also allow-listed) tries to push.
        second_task = asyncio.create_task(orch.submit_inbound(
            chat_id=99, user_id=99, username="b", message_id="2", text="other",
        ))
        # The second push must NOT have reached stdin yet — only "first".
        await asyncio.sleep(0.05)
        assert len(orch.claude.received) == 1
        assert "first" in orch.claude.received[0]
        # Release first turn's result — chat 99 now claims and pushes.
        drain_gate.set()
        await first_task
        # Reset the gate so the second turn can fire its own result.
        drain_gate.clear()
        await asyncio.sleep(0.05)
        assert len(orch.claude.received) == 2
        assert "other" in orch.claude.received[1]
        drain_gate.set()
        await second_task
    finally:
        if orch._reader_task is not None:
            orch._reader_task.cancel()
            try:
                await orch._reader_task
            except asyncio.CancelledError:
                pass
        await orch.access.stop()


# ---- _pretty_tool_name helper ----


def test_pretty_tool_name_strips_mcp_prefix():
    from waggle.orchestrator import _pretty_tool_name
    assert _pretty_tool_name("mcp__waggle-tools__reply") == "reply"
    assert _pretty_tool_name("mcp__agentgateway__weather_get_metar") == "weather_get_metar"


def test_pretty_tool_name_passes_built_in_through():
    from waggle.orchestrator import _pretty_tool_name
    assert _pretty_tool_name("Bash") == "Bash"
    assert _pretty_tool_name("Read") == "Read"
    assert _pretty_tool_name("ToolSearch") == "ToolSearch"


def test_pretty_tool_name_handles_malformed_mcp_prefix():
    """Edge: `mcp__` prefix without the `__server__name` shape — pass
    through verbatim instead of producing an empty string."""
    from waggle.orchestrator import _pretty_tool_name
    assert _pretty_tool_name("mcp__weird") == "mcp__weird"


def test_extract_tool_name_finds_nested_in_content():
    """Real claude shape: tool_use as a block inside `message.content`."""
    from waggle.orchestrator import _extract_tool_name
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "text", "text": "let me think"},
            {"type": "tool_use", "id": "t1", "name": "mcp__waggle-tools__reply", "input": {}},
        ]},
    }
    assert _extract_tool_name(event) == "mcp__waggle-tools__reply"


def test_extract_tasklist_pulls_todos_from_TodoWrite():
    """A TodoWrite tool_use inside an assistant event yields the todos
    array — the orchestrator hands this snapshot to the indicator."""
    from waggle.orchestrator import _extract_tasklist
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "text", "text": "ok"},
            {"type": "tool_use", "id": "t1", "name": "TodoWrite",
             "input": {"todos": [
                 {"content": "step 1", "status": "completed"},
                 {"content": "step 2", "status": "in_progress"},
             ]}},
        ]},
    }
    todos = _extract_tasklist(event)
    assert todos is not None
    assert len(todos) == 2
    assert todos[0]["status"] == "completed"


def test_extract_tasklist_returns_none_for_unrelated_events():
    """Assistant events without TodoWrite tool_use return None so the
    caller doesn't reset the snapshot to an empty list."""
    from waggle.orchestrator import _extract_tasklist
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "tool_use", "id": "t1", "name": "Read",
             "input": {"file_path": "/tmp/x"}},
        ]},
    }
    assert _extract_tasklist(event) is None


def test_extract_tasklist_empty_todos():
    """TodoWrite with empty list still yields a list (the agent cleared
    its plan), distinct from None which means no TodoWrite at all."""
    from waggle.orchestrator import _extract_tasklist
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "tool_use", "id": "t1", "name": "TodoWrite",
             "input": {"todos": []}},
        ]},
    }
    assert _extract_tasklist(event) == []


def test_extract_tool_name_returns_none_when_no_tool():
    from waggle.orchestrator import _extract_tool_name
    event = {
        "type": "assistant",
        "message": {"content": [{"type": "text", "text": "just text"}]},
    }
    assert _extract_tool_name(event) is None


# ---- _extract_thinking ----


def test_extract_thinking_returns_blocks_in_order():
    from waggle.orchestrator import _extract_thinking
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "thinking", "thinking": "step 1: parse"},
            {"type": "thinking", "thinking": "step 2: act"},
            {"type": "text", "text": "final"},
        ]},
    }
    assert _extract_thinking(event) == ["step 1: parse", "step 2: act"]


def test_extract_thinking_no_thinking_blocks():
    from waggle.orchestrator import _extract_thinking
    event = {
        "type": "assistant",
        "message": {"content": [{"type": "text", "text": "no thinking here"}]},
    }
    assert _extract_thinking(event) == []


def test_extract_thinking_skips_empty_thinking():
    from waggle.orchestrator import _extract_thinking
    event = {
        "type": "assistant",
        "message": {"content": [
            {"type": "thinking", "thinking": ""},        # skip empty
            {"type": "thinking", "thinking": "real"},
            {"type": "thinking"},                         # skip missing field
        ]},
    }
    assert _extract_thinking(event) == ["real"]


# ---- silent groups: status indicator suppression ----

def _write_silent_group_config(tmp_path: Path) -> Path:
    p = tmp_path / "config.yaml"
    p.write_text(
        textwrap.dedent(
            """
            transports:
              - name: tg
                kind: telegram
                bot_token: "1234567890:secret-token"
            access:
              users: [42, 99]
              groups:
                -1001234:
                  users: []
                  silent: true
                -1005555:
                  users: []
            owner:
              user_id: 42
            """
        ).lstrip()
    )
    return p


@pytest.mark.asyncio
async def test_silent_group_suppresses_status_indicator(tmp_path: Path):
    """Inbound from a `silent: true` group must NOT post the rolling
    🤔 Thinking… indicator. The agent's final reply still goes through
    the `reply` MCP tool — but since this stub doesn't run that tool,
    we just assert no indicator messages were posted to telegram.

    Typing-action poller still runs (silent only hides the rolling
    surface) — verified by checking that the orchestrator's _typing
    attribute was instantiated."""
    cfg_path = _write_silent_group_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=-1001234, user_id=42, username="x",
            message_id="9", text="hello",
        )
        # claude saw the wrapped inbound
        assert len(orch.claude.received) == 1
        # NO indicator messages posted, NO deletes
        assert orch.telegram.replies == []
        assert orch.telegram.deletes == []
        # Status indicator was NOT instantiated; typing WAS
        assert orch._status is None
        assert orch._typing is not None
    finally:
        await orch.access.stop()


@pytest.mark.asyncio
async def test_non_silent_group_keeps_status_indicator(tmp_path: Path):
    """Sibling group without `silent` keeps the indicator (regression
    guard — the silent flag must be opt-in per group)."""
    cfg_path = _write_silent_group_config(tmp_path)
    orch = WaggleOrchestrator(load(cfg_path), cfg_path)
    orch.claude = _StubClaude(result_text="ok")  # type: ignore
    orch.telegram = _StubTelegram()  # type: ignore
    await orch.access.start()
    try:
        await orch.submit_inbound(
            chat_id=-1005555, user_id=42, username="x",
            message_id="9", text="hello",
        )
        assert len(orch.telegram.replies) == 1
        assert "Thinking" in orch.telegram.replies[0]["text"]
        assert len(orch.telegram.deletes) == 1
    finally:
        await orch.access.stop()
