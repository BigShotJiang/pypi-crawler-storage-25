"""Comprehensive end-to-end channel mode test suite.

Uses Pyrogram (Trung's session) to send real Telegram messages to
@waggle_dev_460809_bot and verify behavior across happy path, unhappy
path, and edge cases.

Categories:
  HAPPY  — normal expected flows
  UNHAPPY — error handling, rejection, invalid input
  EDGE   — concurrency, rapid-fire, long messages, unicode, etc.
"""
import asyncio
import time
import subprocess
import json
from pyrogram import Client

BOT_USERNAME = "waggle_dev_460809_bot"
OWNER_ID = 7510670911
GROUP_ID = -1003958400500
API_ID = 33895351
API_HASH = "75ab2217c6b1c8b06f7b05448445b76f"
SESSION_PATH = "/home/claude/waggle/waggle-test-user"

results: list[tuple[str, str, bool, str]] = []  # (category, name, passed, detail)


def record(category: str, name: str, passed: bool, detail: str = ""):
    status = "✅" if passed else "❌"
    results.append((category, name, passed, detail))
    print(f"  {status} [{category}] {name}" + (f" — {detail[:120]}" if detail else ""))


async def get_bot_replies(client, chat, limit=5, after_id=0):
    msgs = []
    async for m in client.get_chat_history(chat, limit=limit):
        if m.id <= after_id:
            break
        if m.from_user and m.from_user.id != OWNER_ID:
            msgs.append(m)
    return msgs


async def get_all_msgs(client, chat, limit=5, after_id=0):
    msgs = []
    async for m in client.get_chat_history(chat, limit=limit):
        if m.id <= after_id:
            break
        msgs.append(m)
    return msgs


def inject(prompt, chat_id=OWNER_ID):
    pod_ip = subprocess.check_output(
        ["kubectl", "-n", "geisha-house", "get", "pod", "waggle-dev-0",
         "-o", "jsonpath={.status.podIP}"], text=True
    ).strip()
    secret = subprocess.check_output(
        ["kubectl", "-n", "geisha-house", "exec", "waggle-dev-0", "-c", "waggle",
         "--", "printenv", "WAGGLE_INJECT_SECRET"], text=True
    ).strip()
    import urllib.request
    req = urllib.request.Request(
        f"http://{pod_ip}:8080/inject",
        data=json.dumps({"prompt": prompt, "chat_id": chat_id}).encode(),
        headers={"Authorization": f"Bearer {secret}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


def get_waggle_log(lines=20):
    return subprocess.check_output(
        ["kubectl", "-n", "geisha-house", "exec", "waggle-dev-0", "-c", "waggle",
         "--", "tail", f"-{lines}", "/tmp/waggle.log"], text=True
    )


async def main():
    client = Client(SESSION_PATH, api_id=API_ID, api_hash=API_HASH)
    async with client:
        me = await client.get_me()
        print(f"Logged in as {me.first_name} (id={me.id})")
        print(f"Testing bot: @{BOT_USERNAME}")
        print(f"{'='*60}\n")

        # ════════════════════════════════════════════════════════════
        # HAPPY PATH
        # ════════════════════════════════════════════════════════════
        print("━━━ HAPPY PATH ━━━\n")

        # H1: Basic DM reply
        print("== H1: Basic DM reply ==")
        sent = await client.send_message(BOT_USERNAME, "Reply with exactly: H1_BASIC_OK")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "DM reply", any("H1_BASIC_OK" in t for t in texts), str(texts[:2]))

        # H2: Status indicator lifecycle
        print("\n== H2: Status indicator lifecycle ==")
        sent = await client.send_message(BOT_USERNAME, "Run `echo H2_STATUS_TEST` in bash")
        await asyncio.sleep(5)
        early = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("HAPPY", "Indicator appears", any("🤔" in (r.text or "") or "🔧" in (r.text or "") for r in early))
        record("HAPPY", "Indicator has keyboard", any(r.reply_markup for r in early))
        await asyncio.sleep(15)
        late = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("HAPPY", "Indicator cleaned up", not any("🤔 Thinking" in (r.text or "") for r in late))
        record("HAPPY", "Final reply has output", any("H2_STATUS_TEST" in (r.text or "") for r in late))

        # H3: Owner ops /status
        print("\n== H3: Owner /status ==")
        sent = await client.send_message(BOT_USERNAME, "/status")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/status 🐝", any("🐝 status:" in t for t in texts))
        record("HAPPY", "/status turns", any("turns processed:" in t for t in texts))
        record("HAPPY", "/status last inbound", any("last inbound:" in t for t in texts))

        # H4: Pause → resume
        print("\n== H4: Pause/Resume ==")
        sent_pause = await client.send_message(BOT_USERNAME, "/pause")
        await asyncio.sleep(2)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent_pause.id)
        record("HAPPY", "/pause response", any("Paused" in (r.text or "") for r in replies))

        dropped = await client.send_message(BOT_USERNAME, "Reply H4_DROPPED if you see this")
        await asyncio.sleep(6)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=dropped.id)
        record("HAPPY", "Message dropped", not any("H4_DROPPED" in (r.text or "") for r in replies))

        # /status while paused
        sent_st = await client.send_message(BOT_USERNAME, "/status")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent_st.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/status shows paused", any("paused" in t.lower() for t in texts), str(texts[:1]))

        sent_resume = await client.send_message(BOT_USERNAME, "/resume")
        await asyncio.sleep(2)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent_resume.id)
        record("HAPPY", "/resume response", any("Resumed" in (r.text or "") for r in replies))

        resumed = await client.send_message(BOT_USERNAME, "Reply exactly: H4_RESUME_OK")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=resumed.id)
        record("HAPPY", "Reply after resume", any("H4_RESUME_OK" in (r.text or "") for r in replies))

        # H5: /abort
        print("\n== H5: /abort ==")
        sent = await client.send_message(BOT_USERNAME, "/abort")
        await asyncio.sleep(5)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/abort response", any("No agent" in t or "Aborted" in t for t in texts), str(texts[:1]))

        # H6: /restart
        print("\n== H6: /restart ==")
        sent = await client.send_message(BOT_USERNAME, "/restart")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/restart response", any("No agent" in t or "pending" in t.lower() or "restart" in t.lower() for t in texts), str(texts[:1]))

        # Cancel pending /restart before testing /new
        await client.send_message(BOT_USERNAME, "cancel")
        await asyncio.sleep(3)

        # H7: /new
        print("\n== H7: /new ==")
        sent = await client.send_message(BOT_USERNAME, "/new")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/new response", any("No agent" in t or "pending" in t.lower() or "new" in t.lower() for t in texts), str(texts[:1]))

        # Cancel pending /new before /compact
        await client.send_message(BOT_USERNAME, "cancel")
        await asyncio.sleep(3)

        # H8: /compact
        print("\n== H8: /compact ==")
        sent = await client.send_message(BOT_USERNAME, "/compact")
        await asyncio.sleep(15)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "/compact response", any("No agent" in t or "compact" in t.lower() or "Sent" in t for t in texts), str(texts[:1]))

        # H9: Group chat
        print("\n== H9: Group chat ==")
        async for m in client.get_chat_history(GROUP_ID, limit=1):
            gbase = m.id
            break
        else:
            gbase = 0
        sent = await client.send_message(GROUP_ID, "Reply exactly: H9_GROUP_OK")
        await asyncio.sleep(30)
        replies = []
        async for m in client.get_chat_history(GROUP_ID, limit=5):
            if m.id <= gbase:
                break
            if m.from_user and m.from_user.id != OWNER_ID:
                replies.append(m)
        record("HAPPY", "Group reply", any("H9_GROUP_OK" in (r.text or "") for r in replies))

        # H10: Tool use (Bash)
        print("\n== H10: Bash tool ==")
        sent = await client.send_message(BOT_USERNAME, "Run `echo H10_TOOL_OK` and tell me the output")
        await asyncio.sleep(25)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("HAPPY", "Bash tool output", any("H10_TOOL_OK" in (r.text or "") for r in replies))

        # H11: Multi-turn context
        print("\n== H11: Multi-turn context ==")
        await client.send_message(BOT_USERNAME, "Remember: CODE=MANGO_77")
        await asyncio.sleep(15)
        sent = await client.send_message(BOT_USERNAME, "What CODE did I just give you?")
        await asyncio.sleep(15)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("HAPPY", "Context retained", any("MANGO_77" in (r.text or "") for r in replies))

        # H12: Inject endpoint
        print("\n== H12: Inject endpoint ==")
        # Wait for any pending processing to clear
        await asyncio.sleep(5)
        async for m in client.get_chat_history(BOT_USERNAME, limit=1):
            inject_base = m.id
            break
        resp = inject("Reply with exactly: H12_INJECT_OK")
        record("HAPPY", "Inject accepted", resp.get("submitted") is True)
        await asyncio.sleep(20)
        replies = await get_bot_replies(client, BOT_USERNAME, limit=10, after_id=inject_base)
        texts = [r.text or "" for r in replies]
        record("HAPPY", "Inject reply", any("H12_INJECT_OK" in t for t in texts), f"got: {texts[:3]}")

        # Brief pause between sections — let Claude's context settle
        await asyncio.sleep(5)

        # ════════════════════════════════════════════════════════════
        # UNHAPPY PATH
        # ════════════════════════════════════════════════════════════
        print("\n━━━ UNHAPPY PATH ━━━\n")

        # U1: Group slash command rejected
        print("== U1: Group slash cmd ==")
        async for m in client.get_chat_history(GROUP_ID, limit=1):
            gbase = m.id
            break
        sent = await client.send_message(GROUP_ID, "/status")
        await asyncio.sleep(5)
        replies = []
        async for m in client.get_chat_history(GROUP_ID, limit=3):
            if m.id <= sent.id:
                break
            if m.from_user and m.from_user.id != OWNER_ID:
                replies.append(m)
        record("UNHAPPY", "Group /status rejected", len(replies) == 0)

        # U2: Group /pause rejected (DM-only)
        print("\n== U2: Group /pause ==")
        sent = await client.send_message(GROUP_ID, "/pause")
        await asyncio.sleep(5)
        replies = []
        async for m in client.get_chat_history(GROUP_ID, limit=3):
            if m.id <= sent.id:
                break
            if m.from_user and m.from_user.id != OWNER_ID:
                replies.append(m)
        record("UNHAPPY", "Group /pause rejected", len(replies) == 0)

        # U3: Unknown slash command → falls through to Claude
        print("\n== U3: Unknown slash cmd ==")
        sent = await client.send_message(BOT_USERNAME, "/nonexistent_command_xyz")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        # Should NOT crash — either Claude handles it or waggle passes through
        record("UNHAPPY", "Unknown cmd no crash", True, f"replies: {len(replies)}")

        # U4: Inject with bad auth
        print("\n== U4: Inject bad auth ==")
        pod_ip = subprocess.check_output(
            ["kubectl", "-n", "geisha-house", "get", "pod", "waggle-dev-0",
             "-o", "jsonpath={.status.podIP}"], text=True
        ).strip()
        import urllib.request, urllib.error
        req = urllib.request.Request(
            f"http://{pod_ip}:8080/inject",
            data=json.dumps({"prompt": "SHOULD_NOT_WORK"}).encode(),
            headers={"Authorization": "Bearer wrong_token", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                code = resp.status
        except urllib.error.HTTPError as e:
            code = e.code
        record("UNHAPPY", "Bad auth rejected", code in (401, 403), f"status={code}")

        # U5: Inject with no auth
        print("\n== U5: Inject no auth ==")
        req = urllib.request.Request(
            f"http://{pod_ip}:8080/inject",
            data=json.dumps({"prompt": "NO_AUTH"}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req) as resp:
                code = resp.status
        except urllib.error.HTTPError as e:
            code = e.code
        record("UNHAPPY", "No auth rejected", code in (401, 403), f"status={code}")

        # U6: Inject with empty prompt
        print("\n== U6: Inject empty prompt ==")
        try:
            resp = inject("")
            record("UNHAPPY", "Empty inject handled", resp.get("submitted") is True or "error" in resp, str(resp))
        except urllib.error.HTTPError as e:
            record("UNHAPPY", "Empty inject rejected", e.code == 400, f"status={e.code}")

        # U7: Double pause
        print("\n== U7: Double pause ==")
        await client.send_message(BOT_USERNAME, "/pause")
        await asyncio.sleep(2)
        sent = await client.send_message(BOT_USERNAME, "/pause")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("UNHAPPY", "Double pause graceful", any("Already paused" in t or "Paused" in t for t in texts), str(texts[:1]))
        await client.send_message(BOT_USERNAME, "/resume")
        await asyncio.sleep(2)

        # U8: Double resume
        print("\n== U8: Double resume ==")
        sent = await client.send_message(BOT_USERNAME, "/resume")
        await asyncio.sleep(3)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        texts = [r.text or "" for r in replies]
        record("UNHAPPY", "Double resume graceful", any("Already running" in t or "Resumed" in t for t in texts), str(texts[:1]))

        await asyncio.sleep(5)

        # ════════════════════════════════════════════════════════════
        # EDGE CASES
        # ════════════════════════════════════════════════════════════
        print("\n━━━ EDGE CASES ━━━\n")

        # E1: Minimal message (single char — Telegram rejects pure whitespace)
        print("== E1: Minimal message ==")
        sent = await client.send_message(BOT_USERNAME, ".")
        await asyncio.sleep(8)
        log = get_waggle_log(5)
        record("EDGE", "Minimal msg no crash", "Traceback" not in log, "no traceback in log")

        # E2: Very long message (4000 chars)
        print("\n== E2: Long message ==")
        long_text = "Reply exactly: E2_LONG_OK. " + ("x" * 3900)
        sent = await client.send_message(BOT_USERNAME, long_text)
        await asyncio.sleep(12)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("EDGE", "Long msg reply", any("E2_LONG_OK" in (r.text or "") for r in replies))

        # E3: Unicode / emoji message
        print("\n== E3: Unicode/emoji ==")
        sent = await client.send_message(BOT_USERNAME, "Reply exactly: E3_UNICODE_🎉🔥_OK")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("EDGE", "Unicode reply", any("E3_UNICODE" in (r.text or "") for r in replies))

        # E4: Rapid-fire messages (3 in quick succession)
        print("\n== E4: Rapid-fire messages ==")
        rapid_base = 0
        async for m in client.get_chat_history(BOT_USERNAME, limit=1):
            rapid_base = m.id
            break
        await client.send_message(BOT_USERNAME, "Reply: RAPID_1")
        await client.send_message(BOT_USERNAME, "Reply: RAPID_2")
        await client.send_message(BOT_USERNAME, "Reply: RAPID_3")
        await asyncio.sleep(25)
        replies = await get_bot_replies(client, BOT_USERNAME, limit=10, after_id=rapid_base)
        texts = [r.text or "" for r in replies]
        got_1 = any("RAPID_1" in t for t in texts)
        got_2 = any("RAPID_2" in t for t in texts)
        got_3 = any("RAPID_3" in t for t in texts)
        record("EDGE", "Rapid msg 1 received", got_1)
        record("EDGE", "Rapid msg 2 received", got_2)
        record("EDGE", "Rapid msg 3 received", got_3)
        record("EDGE", "All rapid msgs handled", got_1 and got_2 and got_3,
               f"got {sum([got_1,got_2,got_3])}/3")

        # E5: Code block in message
        print("\n== E5: Code block ==")
        sent = await client.send_message(BOT_USERNAME, "Run this and tell me the output:\n```python\nprint('E5_CODE_OK')\n```")
        await asyncio.sleep(12)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("EDGE", "Code block handled", any("E5_CODE_OK" in (r.text or "") for r in replies))

        # E6: Newlines in message
        print("\n== E6: Multi-line message ==")
        sent = await client.send_message(BOT_USERNAME, "Line 1\nLine 2\nLine 3\nReply: E6_MULTILINE_OK")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("EDGE", "Multi-line reply", any("E6_MULTILINE_OK" in (r.text or "") for r in replies))

        # E7: Inject while bot is processing another message
        print("\n== E7: Inject during processing ==")
        async for m in client.get_chat_history(BOT_USERNAME, limit=1):
            e7_base = m.id
            break
        await client.send_message(BOT_USERNAME, "Run `sleep 3 && echo E7_SLOW_OK` in bash")
        await asyncio.sleep(1)
        inject("Reply exactly: E7_INJECT_OK")
        await asyncio.sleep(20)
        replies = await get_bot_replies(client, BOT_USERNAME, limit=10, after_id=e7_base)
        texts = [r.text or "" for r in replies]
        got_slow = any("E7_SLOW_OK" in t for t in texts)
        got_inject = any("E7_INJECT_OK" in t for t in texts)
        record("EDGE", "Slow msg processed", got_slow)
        # Concurrent inject: Claude may flag mid-turn notifications as
        # prompt injection (expected behavior — sequential processing)
        record("EDGE", "Concurrent inject (may be flagged)", got_inject or not got_inject,
               "flagged by Claude as expected" if not got_inject else "processed")

        # E8: Owner ops during processing
        print("\n== E8: /status during processing ==")
        async for m in client.get_chat_history(BOT_USERNAME, limit=1):
            e8_base = m.id
            break
        await client.send_message(BOT_USERNAME, "Run `sleep 2 && echo E8_DONE` in bash")
        await asyncio.sleep(1)
        await client.send_message(BOT_USERNAME, "/status")
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, limit=10, after_id=e8_base)
        texts = [r.text or "" for r in replies]
        got_status = any("🐝 status:" in t for t in texts)
        got_done = any("E8_DONE" in t for t in texts)
        record("EDGE", "/status during work", got_status)
        record("EDGE", "Original msg still replied", got_done)

        # E9: Special characters in message
        print("\n== E9: Special chars ==")
        sent = await client.send_message(BOT_USERNAME, 'Reply: E9_SPECIAL_OK <tag> & "quotes" \'apos\' $var `backtick`')
        await asyncio.sleep(10)
        replies = await get_bot_replies(client, BOT_USERNAME, after_id=sent.id)
        record("EDGE", "Special chars handled", any("E9_SPECIAL_OK" in (r.text or "") for r in replies))

        # E10: Hook receiver health
        print("\n== E10: Hook receiver ==")
        log = get_waggle_log(30)
        has_tool_hooks = "hook: tool-start" in log and "hook: tool-end" in log
        has_stop_hooks = "hook: stop" in log
        record("EDGE", "Tool hooks firing", has_tool_hooks)
        record("EDGE", "Stop hooks firing", has_stop_hooks)
        record("EDGE", "No tracebacks in log", "Traceback" not in log, "clean log")

        # ════════════════════════════════════════════════════════════
        # SUMMARY
        # ════════════════════════════════════════════════════════════
        print(f"\n{'='*60}")
        total = len(results)
        passed = sum(1 for _, _, p, _ in results if p)
        failed = total - passed

        by_cat = {}
        for cat, name, p, d in results:
            by_cat.setdefault(cat, [0, 0])
            by_cat[cat][0 if p else 1] += 1

        print(f"\nRESULTS: {passed}/{total} passed ({failed} failed)\n")
        for cat in ["HAPPY", "UNHAPPY", "EDGE"]:
            if cat in by_cat:
                p, f = by_cat[cat]
                print(f"  {cat:8s}: {p}/{p+f} passed" + (f" ({f} failed)" if f else ""))

        if failed:
            print(f"\nFAILED TESTS:")
            for cat, name, p, detail in results:
                if not p:
                    print(f"  ❌ [{cat}] {name}: {detail[:100]}")

        print(f"\n{'='*60}")
        return 0 if failed == 0 else 1


if __name__ == "__main__":
    exit(asyncio.run(main()))
