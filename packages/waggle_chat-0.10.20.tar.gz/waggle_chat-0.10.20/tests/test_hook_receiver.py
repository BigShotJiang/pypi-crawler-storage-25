"""Tests for the hook_receiver module — internal localhost endpoint for
Claude Code hooks (PreToolUse, PostToolUse, Stop, TaskCreated, TaskCompleted)."""

from __future__ import annotations

import asyncio
import pytest
import aiohttp

from waggle.hook_receiver import HookReceiver


@pytest.fixture
async def receiver():
    r = HookReceiver(port=18091)
    await r.start()
    yield r
    await r.stop()


@pytest.fixture
def base_url():
    return "http://127.0.0.1:18091"


@pytest.mark.asyncio
async def test_tool_start(receiver, base_url):
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/tool-start", json={"tool_name": "Bash"})
        assert resp.status == 200
    assert receiver._current_tool == "Bash"


@pytest.mark.asyncio
async def test_tool_end_clears_current(receiver, base_url):
    receiver._current_tool = "Read"
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/tool-end", json={"tool_name": "Read"})
        assert resp.status == 200
    assert receiver._current_tool is None


@pytest.mark.asyncio
async def test_stop_resets_tasks(receiver, base_url):
    receiver._tasks["1"] = {"subject": "Fix bug", "status": "pending"}
    receiver._current_tool = "Bash"
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/stop", json={})
        assert resp.status == 200
    assert receiver._tasks == {}
    assert receiver._current_tool is None


@pytest.mark.asyncio
async def test_task_created(receiver, base_url):
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/task", json={
            "hook_event_name": "TaskCreated",
            "task_id": "abc",
            "subject": "Fix auth",
            "status": "pending",
        })
        assert resp.status == 200
    assert "abc" in receiver._tasks
    assert receiver._tasks["abc"]["subject"] == "Fix auth"
    assert receiver._tasks["abc"]["status"] == "pending"


@pytest.mark.asyncio
async def test_task_completed(receiver, base_url):
    receiver._tasks["abc"] = {"subject": "Fix auth", "status": "in_progress"}
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/task", json={
            "hook_event_name": "TaskCompleted",
            "task_id": "abc",
        })
        assert resp.status == 200
    assert receiver._tasks["abc"]["status"] == "completed"


@pytest.mark.asyncio
async def test_render_tasks(receiver, base_url):
    receiver._tasks["1"] = {"subject": "Fix bug", "status": "completed"}
    receiver._tasks["2"] = {"subject": "Run tests", "status": "in_progress"}
    receiver._tasks["3"] = {"subject": "Deploy", "status": "pending"}
    rendered = receiver._render_tasks()
    assert "📋 Tasks:" in rendered
    assert "✅ Fix bug" in rendered
    assert "🔄 Run tests" in rendered
    assert "⬜ Deploy" in rendered


@pytest.mark.asyncio
async def test_render_tasks_empty(receiver, base_url):
    assert receiver._render_tasks() is None


@pytest.mark.asyncio
async def test_pretty_tool_name(receiver, base_url):
    async with aiohttp.ClientSession() as s:
        await s.post(f"{base_url}/hooks/tool-start", json={"tool_name": "mcp__waggle-tools__reply"})
    assert receiver._current_tool == "reply"


@pytest.mark.asyncio
async def test_malformed_body_doesnt_crash(receiver, base_url):
    async with aiohttp.ClientSession() as s:
        resp = await s.post(f"{base_url}/hooks/tool-start", data=b"not json",
                            headers={"Content-Type": "text/plain"})
        assert resp.status == 200
