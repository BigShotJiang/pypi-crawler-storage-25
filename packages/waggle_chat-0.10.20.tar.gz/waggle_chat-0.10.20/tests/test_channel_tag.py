"""Channel-tag wire format v1 round-trip + escape rules."""

import os
from datetime import datetime, timezone

from waggle.channel_tag import ChannelTag, parse


def test_render_basic_utc(monkeypatch):
    """In a UTC pod (TZ=UTC) the offset still appears as +00:00 instead of
    the legacy 'Z'. Both forms are accepted on parse."""
    monkeypatch.setenv("TZ", "UTC")
    if hasattr(__import__("time"), "tzset"):
        __import__("time").tzset()
    tag = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    out = tag.render("hello world")
    assert out == (
        '<channel source="telegram" chat="-1001234" user="908624017" '
        'ts="2026-04-29T10:00:00+00:00">\nhello world\n</channel>'
    )


def test_render_uses_system_tz(monkeypatch):
    """Operator pins the pod's wall-clock TZ via the POSIX TZ env var; the
    rendered ts attribute reflects that timezone with an explicit offset.
    Agents see local time, no UTC->local conversion needed."""
    monkeypatch.setenv("TZ", "Asia/Ho_Chi_Minh")
    if hasattr(__import__("time"), "tzset"):
        __import__("time").tzset()
    tag = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),  # 10:00 UTC = 17:00 +07
    )
    out = tag.render("hello world")
    assert 'ts="2026-04-29T17:00:00+07:00"' in out


def test_round_trip():
    original = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    rendered = original.render("body with multiple\nlines")
    parsed_tag, parsed_body = parse(rendered)
    assert parsed_tag == original
    assert parsed_body == "body with multiple\nlines"


def test_attribute_escapes():
    # The four chars XML attributes care about
    tag = ChannelTag(
        source="evil&plat",
        chat='evil"chat',
        user="user<x>",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    out = tag.render("body")
    assert "evil&amp;plat" in out
    assert 'evil&quot;chat' in out
    assert "user&lt;x&gt;" in out


def test_now_normalises_utc():
    tag = ChannelTag.now("telegram", -100, 9000)
    assert tag.ts.tzinfo == timezone.utc
    assert tag.chat == "-100"
    assert tag.user == "9000"


def test_empty_body_round_trips():
    tag = ChannelTag(
        source="telegram",
        chat="1",
        user="2",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    parsed_tag, parsed_body = parse(tag.render(""))
    assert parsed_tag == tag
    assert parsed_body == ""


def test_unicode_body_round_trips():
    tag = ChannelTag(
        source="telegram",
        chat="1",
        user="2",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    body = "đ*t mẹ 🔥 — multiline\nwith emoji"
    parsed_tag, parsed_body = parse(tag.render(body))
    assert parsed_tag == tag
    assert parsed_body == body


def test_now_truncates_microseconds_when_rendered():
    """Wire format v1 frozen at second granularity; ChannelTag.now() can
    carry sub-second precision in memory but a render+parse round-trip
    drops microseconds. Pin this so changes to .now() don't accidentally
    break wire format compatibility."""
    tag = ChannelTag.now("telegram", 1, 2)
    parsed, _ = parse(tag.render("body"))
    # Second-level equality
    assert parsed.ts.replace(microsecond=0) == tag.ts.replace(microsecond=0)
    assert parsed.ts.microsecond == 0  # serialized form has no micros


def test_body_with_literal_close_tag_breaks_parser():
    """Documented attack surface: callers must reject `</channel>` upstream.
    The parser is greedy on `body`, so a literal `</channel>` mid-body causes
    a mis-parse — this test pins that behavior so a future refactor that
    silently changes it shows up in CI."""
    import pytest

    tag = ChannelTag.now("telegram", 1, 2)
    rendered = tag.render("a </channel> b")
    # Greedy match captures up to the LAST </channel>, so it parses but
    # body now contains the inner '</channel>'. We document this here.
    parsed_tag, parsed_body = parse(rendered)
    assert "</channel>" in parsed_body  # the embedded one survives
    # And a genuinely malformed block fails to parse
    with pytest.raises(ValueError):
        parse("not a channel tag at all")


# ---- Batch 10: ChannelTag.at() with explicit timestamp ----


def test_at_uses_explicit_ts():
    """When the source carries a real send-time (Telegram message.date),
    the channel-tag ts MUST be that value, not waggle's wall clock."""
    explicit = datetime(2026, 4, 30, 10, 30, 0, tzinfo=timezone.utc)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=explicit)
    assert tag.ts == explicit


def test_at_normalizes_naive_to_utc():
    """Edge: a naive datetime (no tzinfo) is treated as UTC. Telegram's
    pyrogram returns naive UTC; aiogram returns aware UTC. Either works."""
    naive = datetime(2026, 4, 30, 10, 30, 0)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=naive)
    assert tag.ts.tzinfo == timezone.utc
    assert tag.ts.year == 2026 and tag.ts.hour == 10


def test_at_render_emits_explicit_ts(monkeypatch):
    monkeypatch.setenv("TZ", "UTC")
    if hasattr(__import__("time"), "tzset"):
        __import__("time").tzset()
    explicit = datetime(2026, 4, 30, 10, 30, 0, tzinfo=timezone.utc)
    tag = ChannelTag.at(source="telegram", chat=42, user=7, ts=explicit)
    rendered = tag.render("hello")
    assert "2026-04-30T10:30:00+00:00" in rendered


def test_parser_accepts_legacy_z_suffix():
    """Backward compatibility: tags rendered by waggle <= 0.8.11 used
    `…Z` for UTC. The parser must still accept those alongside the modern
    explicit-offset form."""
    rendered = (
        '<channel source="telegram" chat="-1001234" user="908624017" '
        'ts="2026-04-29T10:00:00Z">\nhello\n</channel>'
    )
    tag, body = parse(rendered)
    assert tag.ts == datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc)
    assert body == "hello"


# ---- Batch 11: v2 enriched fields (username, names, premium, chat type/title, topics) ----


def test_render_v2_fields_all_populated(monkeypatch):
    monkeypatch.setenv("TZ", "UTC")
    if hasattr(__import__("time"), "tzset"):
        __import__("time").tzset()
    tag = ChannelTag(
        source="telegram",
        chat="-1003926821116",
        user="908624017",
        ts=datetime(2026, 5, 7, 8, 30, 0, tzinfo=timezone.utc),
        message_id="8016",
        username="zorrop_06",
        first_name="Nam",
        last_name="Phung",
        is_premium=True,
        chat_type="supergroup",
        chat_title="Anh Long và dàn hậu cung",
        message_thread_id="42",
        is_topic_message=True,
    )
    out = tag.render("hi")
    assert 'username="zorrop_06"' in out
    assert 'first_name="Nam"' in out
    assert 'last_name="Phung"' in out
    assert 'is_premium="true"' in out
    assert 'chat_type="supergroup"' in out
    # Chat title is escaped via XML attr rules but Vietnamese diacritics pass through.
    assert 'chat_title="Anh Long và dàn hậu cung"' in out
    assert 'message_thread_id="42"' in out
    assert 'is_topic_message="true"' in out


def test_render_v1_compat_when_optional_fields_empty():
    """v2 optional fields are omitted from the rendered tag when empty so
    v1 prompts stay byte-for-byte stable (prompt-cache friendly)."""
    tag = ChannelTag(
        source="telegram",
        chat="-1001234",
        user="908624017",
        ts=datetime(2026, 4, 29, 10, 0, 0, tzinfo=timezone.utc),
    )
    out = tag.render("hello")
    for forbidden in ("username=", "first_name=", "last_name=", "is_premium=",
                      "chat_type=", "chat_title=", "message_thread_id=", "is_topic_message="):
        assert forbidden not in out


def test_round_trip_v2_fields():
    original = ChannelTag(
        source="telegram",
        chat="-100",
        user="1",
        ts=datetime(2026, 5, 7, 8, 30, 0, tzinfo=timezone.utc),
        message_id="m1",
        username="zorrop_06",
        first_name="Nam",
        last_name="Phung",
        is_premium=False,
        chat_type="private",
        chat_title="",
        message_thread_id="",
        is_topic_message=None,
    )
    rendered = original.render("body")
    parsed, body = parse(rendered)
    assert body == "body"
    assert parsed.username == "zorrop_06"
    assert parsed.first_name == "Nam"
    assert parsed.last_name == "Phung"
    assert parsed.is_premium is False
    assert parsed.chat_type == "private"
    # Empty optionals are not emitted -> parsed back as default empty/None.
    assert parsed.chat_title == ""
    assert parsed.message_thread_id == ""
    assert parsed.is_topic_message is None


def test_now_at_pass_through_v2_kwargs():
    tag = ChannelTag.now(
        "telegram", "-1001", "908624017",
        message_thread_id=42, is_topic_message=True, chat_type="supergroup",
    )
    assert tag.message_thread_id == "42"
    assert tag.is_topic_message is True
    assert tag.chat_type == "supergroup"


def test_chat_title_xml_escaping():
    """Chat titles can contain `&`, `<`, `>`, `"` — must be XML-attr-escaped
    so the parser round-trips and downstream don't see raw markup."""
    tag = ChannelTag(
        source="telegram",
        chat="-100",
        user="1",
        ts=datetime(2026, 5, 7, 0, 0, 0, tzinfo=timezone.utc),
        chat_title='Foo & "Bar" <baz>',
    )
    rendered = tag.render("body")
    assert "&amp;" in rendered
    assert "&quot;" in rendered
    assert "&lt;" in rendered
    assert "&gt;" in rendered
    parsed, _ = parse(rendered)
    assert parsed.chat_title == 'Foo & "Bar" <baz>'
