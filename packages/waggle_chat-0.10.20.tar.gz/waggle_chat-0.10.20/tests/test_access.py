"""Allow-list rule semantics + hot-reload on config mtime change."""

import asyncio
import textwrap
from pathlib import Path

import pytest

from waggle.access import AccessControl, AccessRules, GroupRule, parse_rules


def test_dm_requires_user_in_allowlist():
    rules = AccessRules(users=frozenset({42}))
    assert rules.allows(chat_id=42, user_id=42) is True
    assert rules.allows(chat_id=99, user_id=99) is False


def test_group_requires_chat_in_allowlist():
    rules = AccessRules(users=frozenset({42}), groups={})
    assert rules.allows(chat_id=-1001234, user_id=42) is False  # group not listed


def test_group_per_group_users():
    rules = AccessRules(
        users=frozenset({42}),
        groups={-1001234: GroupRule(users=frozenset({99}))},  # 42 NOT in per-group list
    )
    assert rules.allows(chat_id=-1001234, user_id=99) is True
    assert rules.allows(chat_id=-1001234, user_id=42) is False  # global not enough


def test_group_empty_users_admits_anyone():
    """Empty `users` means the group chat_id itself is the trust boundary —
    anyone in that group is allowed (matches Anthropic's claude-code
    Telegram MCP). The global allowlist is NOT consulted for groups with
    empty users."""
    rules = AccessRules(
        users=frozenset({42}),
        groups={-1001234: GroupRule(users=frozenset())},
    )
    # Owner from global passes (also passes the empty-users check).
    assert rules.allows(chat_id=-1001234, user_id=42) is True
    # Random user in the same group also passes — group membership is
    # what's trusted here, not the global list.
    assert rules.allows(chat_id=-1001234, user_id=99) is True
    # Bot-to-bot mention works too (e.g. Kiku at id 7957574791 pinging
    # another bot in a shared group).
    assert rules.allows(chat_id=-1001234, user_id=7957574791) is True


def test_parse_rules_from_yaml_dict():
    raw = {
        "users": [42, 99],
        "groups": {-1001234: {"users": [42]}},
    }
    rules = parse_rules(raw)
    assert rules.users == frozenset({42, 99})
    assert rules.groups[-1001234].users == frozenset({42})
    assert rules.groups[-1001234].require_mention is False  # default


# ---- Batch 11: require_mention ----


def test_require_mention_blocks_unmentioned():
    rules = AccessRules(
        users=frozenset({42}),
        groups={-1001234: GroupRule(require_mention=True)},
    )
    # Without mention → rejected even though user is in global allowlist
    assert rules.allows(chat_id=-1001234, user_id=42) is False
    assert rules.allows(chat_id=-1001234, user_id=42, is_mentioned=False) is False
    # With mention → accepted
    assert rules.allows(chat_id=-1001234, user_id=42, is_mentioned=True) is True


def test_require_mention_does_not_apply_to_dm():
    """DM is private chat by definition — require_mention is a group concept."""
    rules = AccessRules(users=frozenset({42}))
    # No group rule for DM; mention flag has no effect
    assert rules.allows(chat_id=42, user_id=42, is_mentioned=False) is True
    assert rules.allows(chat_id=42, user_id=42, is_mentioned=True) is True


def test_require_mention_combined_with_per_group_users():
    """require_mention + per-group users: BOTH must pass — must be mentioned
    AND must be in per-group allowlist."""
    rules = AccessRules(
        users=frozenset({42, 99}),
        groups={-1001234: GroupRule(users=frozenset({99}), require_mention=True)},
    )
    # 99 in group + mention → OK
    assert rules.allows(chat_id=-1001234, user_id=99, is_mentioned=True) is True
    # 99 in group but no mention → reject (require_mention)
    assert rules.allows(chat_id=-1001234, user_id=99, is_mentioned=False) is False
    # 42 mention but not in per-group list → reject
    assert rules.allows(chat_id=-1001234, user_id=42, is_mentioned=True) is False


def test_parse_rules_includes_require_mention():
    raw = {
        "users": [42],
        "groups": {
            -1001234: {"users": [], "require_mention": True},
            -1005555: {"users": [99]},  # default require_mention=False
        },
    }
    rules = parse_rules(raw)
    assert rules.groups[-1001234].require_mention is True
    assert rules.groups[-1005555].require_mention is False


# ---- silent flag (suppresses status indicator) ----

def test_silent_default_false_for_groups():
    rules = AccessRules(
        groups={-1001234: GroupRule()},
    )
    assert rules.is_silent(-1001234) is False


def test_silent_true_only_when_group_opts_in():
    rules = AccessRules(
        groups={
            -1001234: GroupRule(silent=True),
            -1005555: GroupRule(),
        },
    )
    assert rules.is_silent(-1001234) is True
    assert rules.is_silent(-1005555) is False


def test_silent_false_for_dm():
    """DMs never silence the indicator — only groups can opt in."""
    rules = AccessRules(users=frozenset({42}))
    assert rules.is_silent(42) is False


def test_silent_false_for_unknown_group():
    """Group not in the allow-list at all — is_silent must not raise."""
    rules = AccessRules()
    assert rules.is_silent(-1009999) is False


def test_parse_rules_includes_silent():
    raw = {
        "users": [42],
        "groups": {
            -1001234: {"users": [], "silent": True},
            -1005555: {"users": [99]},  # default silent=False
        },
    }
    rules = parse_rules(raw)
    assert rules.groups[-1001234].silent is True
    assert rules.groups[-1005555].silent is False


def test_empty_rules_rejects_everyone():
    rules = AccessRules()
    assert rules.allows(chat_id=42, user_id=42) is False
    assert rules.allows(chat_id=-1001234, user_id=42) is False


def test_chat_zero_treated_as_dm():
    """Telegram never assigns chat_id == 0, but the boundary lands in the
    DM branch — pin behavior so future signed-int tweaks don't silently
    flip semantics."""
    rules = AccessRules(users=frozenset({42}))
    assert rules.allows(chat_id=0, user_id=42) is True


@pytest.mark.asyncio
async def test_start_fails_when_file_missing(tmp_path: Path):
    """Initial load must fail loudly — the runtime cannot enforce an
    allow-list it never read."""
    ac = AccessControl(tmp_path / "missing.yaml", poll_interval=0.05)
    with pytest.raises(FileNotFoundError):
        await ac.start()


@pytest.mark.asyncio
async def test_reload_keeps_old_rules_on_yaml_error(tmp_path: Path):
    """If the operator typos a YAML edit, the reload must NOT wipe the
    in-memory rules — we keep enforcing the last good config and log the
    failure."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text("access:\n  users: [42]\n  groups: {}\n")
    ac = AccessControl(cfg, poll_interval=0.05)
    await ac.start()
    try:
        assert ac.allows(42, 42) is True
        # Corrupt the file
        cfg.write_text("access: [this is not\n  valid yaml")
        import os, time
        future = time.time() + 1
        os.utime(cfg, (future, future))
        await asyncio.sleep(0.3)
        # Old rules still in place
        assert ac.allows(42, 42) is True
    finally:
        await ac.stop()


@pytest.mark.asyncio
async def test_reload_keeps_old_rules_on_file_deleted(tmp_path: Path):
    cfg = tmp_path / "config.yaml"
    cfg.write_text("access:\n  users: [42]\n  groups: {}\n")
    ac = AccessControl(cfg, poll_interval=0.05)
    await ac.start()
    try:
        cfg.unlink()
        await asyncio.sleep(0.3)
        # Last good rules still apply; we don't wipe enforcement on file gone
        assert ac.allows(42, 42) is True
    finally:
        await ac.stop()


@pytest.mark.asyncio
async def test_rate_limit_parses_from_access_block(tmp_path: Path):
    """P8: rate-limit budgets live under access (so they hot-reload with
    the same mtime poller). Pin the parse path."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text(textwrap.dedent("""
        access:
          users: [42]
          rate_limit:
            chat_per_minute: 5
            user_per_minute: 3
            window_seconds: 30.0
        """).lstrip())
    ac = AccessControl(cfg, poll_interval=0.05)
    await ac.start()
    try:
        assert ac.rate_limit.chat_per_minute == 5
        assert ac.rate_limit.user_per_minute == 3
        assert ac.rate_limit.window_seconds == 30.0
    finally:
        await ac.stop()


@pytest.mark.asyncio
async def test_rate_limit_default_is_zeros(tmp_path: Path):
    """No rate_limit block → all-zero (disabled). Don't surprise operators
    who aren't using rate limiting."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text(textwrap.dedent("""
        access:
          users: [42]
        """).lstrip())
    ac = AccessControl(cfg, poll_interval=0.05)
    await ac.start()
    try:
        assert ac.rate_limit.chat_per_minute == 0
        assert ac.rate_limit.user_per_minute == 0
    finally:
        await ac.stop()


@pytest.mark.asyncio
async def test_rate_limit_hot_reload_fires_callback(tmp_path: Path):
    """P8: editing access.rate_limit in the configmap triggers the
    on_rate_limit_change callback so the orchestrator's RateLimiter
    updates without a pod restart."""
    cfg = tmp_path / "config.yaml"
    cfg.write_text(textwrap.dedent("""
        access:
          users: [42]
          rate_limit:
            user_per_minute: 1
        """).lstrip())
    captured: list = []
    ac = AccessControl(cfg, poll_interval=0.05)
    ac.on_rate_limit_change(lambda c: captured.append(c))
    await ac.start()
    try:
        # Initial load fires the callback IF the loaded value differs from
        # the default zeros — orchestrator wires this so it doesn't have
        # to push the initial value manually.
        assert len(captured) == 1
        assert captured[0].user_per_minute == 1
        # Edit: tighten to 5
        cfg.write_text(textwrap.dedent("""
            access:
              users: [42]
              rate_limit:
                user_per_minute: 5
            """).lstrip())
        import os, time
        future = time.time() + 1
        os.utime(cfg, (future, future))
        for _ in range(40):
            await asyncio.sleep(0.05)
            if len(captured) >= 2:
                break
        assert len(captured) == 2
        assert captured[1].user_per_minute == 5
    finally:
        await ac.stop()


@pytest.mark.asyncio
async def test_hot_reload_mtime(tmp_path: Path):
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        textwrap.dedent(
            """
            access:
              users: [42]
              groups: {}
            """
        ).lstrip()
    )
    ac = AccessControl(cfg, poll_interval=0.05)
    await ac.start()
    try:
        assert ac.allows(42, 42) is True
        assert ac.allows(99, 99) is False
        # Edit the file: add user 99
        cfg.write_text(
            textwrap.dedent(
                """
                access:
                  users: [42, 99]
                  groups: {}
                """
            ).lstrip()
        )
        # Bump mtime to ensure detection
        import os, time
        future = time.time() + 1
        os.utime(cfg, (future, future))
        # Wait for the watcher to pick it up
        for _ in range(40):  # up to ~2s
            await asyncio.sleep(0.05)
            if ac.allows(99, 99):
                break
        assert ac.allows(99, 99) is True
        assert ac.allows(42, 42) is True
    finally:
        await ac.stop()
