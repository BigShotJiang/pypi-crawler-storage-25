# tmux Session Mode

> `WAGGLE_MODE=tmux` — Prototype tested, not production-ready

Runs Claude Code in interactive mode inside a tmux session. waggle injects messages via `tmux send-keys` and detects turn completion via a Stop hook. Interactive mode uses subscription quota.

**Prerequisite:** Complete the [Setup Guide](../SETUP) first.

## How it works

```
Telegram → waggle (aiogram) → tmux send-keys → Claude (interactive TUI)
                                                     ↕
                                                MCP tools_server
                                                (reply, react, edit)
              ↑                                      ↓
         Stop hook fires ← turn complete ← touch signal file
```

1. waggle starts Claude in a tmux session (no `-p` flag — pure interactive mode)
2. waggle polls Telegram via aiogram (same as CLI mode)
3. On message: format as `<channel>` tag, inject via `tmux send-keys -l`
4. Claude processes in interactive TUI, calls MCP tools to reply
5. Stop hook (`touch /tmp/tmux-bridge/turn-complete`) signals turn done
6. waggle picks up next queued message

## Billing

Interactive mode — uses subscription quota, NOT the $200/month programmatic credit. This is the primary motivation for this mode.

## Mode-specific configuration

### Stop hook (required)

waggle detects turn completion via a signal file. This Stop hook must be present in Claude's `settings.json`:

```json
{
  "hooks": {
    "Stop": [{
      "matcher": "",
      "hooks": [{"type": "command", "command": "touch /tmp/tmux-bridge/turn-complete"}]
    }]
  }
}
```

waggle's entrypoint installs this automatically. If running waggle manually, add the hook before starting.

### One-time OAuth login (required)

tmux mode runs Claude in interactive (TUI) mode. This requires a human to complete OAuth device-code login once:

```bash
claude /login
```

The session persists via `--continue` across restarts. Programmatic tokens (API keys, credential sync) do NOT work for interactive mode — only OAuth login creates a valid TUI session.

### tmux dependency

`tmux` must be available in PATH. waggle uses `tmux send-keys -l` to inject messages and manages the session lifecycle.

### Permission mode

tmux mode only supports `bypass` — interactive mode does not expose permission prompt hooks.

### Mode-specific env vars

| Var | Default | Description |
|-----|---------|-------------|
| `TMUX_SESSION` | `claude-bridge` | tmux session name |
| `TURN_TIMEOUT` | `300` | Seconds to wait for turn completion before timeout |

## What's different from CLI mode

| Feature | CLI mode | tmux mode |
|---------|:--------:|:---------:|
| Input method | stdin JSON | `tmux send-keys -l` |
| Output method | stdout JSON events | MCP tools (reply/react) |
| Turn detection | `result` event on stdout | Stop hook signal file |
| Mid-turn inject | ✅ stdin write | ❌ queued |
| Status indicator | ✅ parsed from events | ❌ no event stream |
| Permission prompts | ✅ configurable | ❌ bypass only |
| Human login | ❌ | ✅ one-time |
| Billing | programmatic credit | subscription quota |

## Prototype results (2026-05-14)

- Self-test: PASSED — Claude received message via `send-keys -l`, responded correctly
- Stop hook: FIRED within 2 seconds of turn completion
- Session persistence: `--continue` works across tmux restarts
- Interactive mode requires OAuth device-code login (programmatic tokens rejected)
- TUI requires `TERM=xterm-256color` or similar

## Limitations

- **Human login** — OAuth token expires periodically, needs human to re-login via `claude /login`
- **No mid-turn inject** — messages queue until current turn completes
- **No status indicator** — can't parse TUI output for thinking/tool states
- **No permission prompts** — interactive mode uses bypass only
- **Sequential turns only** — one message at a time, queued FIFO
- **Experimental** — not battle-tested in production
