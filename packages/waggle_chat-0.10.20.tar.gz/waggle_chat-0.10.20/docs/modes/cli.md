# CLI Subprocess Mode

> `WAGGLE_MODE=cli` (default)

The original and most feature-complete mode. waggle spawns Claude Code as a long-lived subprocess using `-p --input-format stream-json --output-format stream-json`.

**Prerequisite:** Complete the [Setup Guide](../SETUP) first.

## How it works

```
Telegram → waggle → stdin (JSON) → claude -p → stdout (JSON) → waggle → Telegram
                                       ↕
                                  MCP tools_server
                                  (reply, react, edit)
```

1. waggle receives a Telegram message
2. Wraps it in a `<channel>` tag, serializes as stream-json `user` event
3. Writes to claude's stdin
4. Claude processes, calls MCP tools (reply/react via `tools_server.py`)
5. Claude emits `result` event on stdout → waggle marks turn complete

## Mode-specific configuration

No additional config needed beyond the [Setup Guide](../SETUP). CLI is the default mode — omit `WAGGLE_MODE` or set it to `cli`.

## Features unique to CLI mode

### Mid-turn inject

If a user sends a second message while Claude is still processing, waggle writes it to stdin immediately. Claude picks it up between agentic-loop rounds and incorporates both messages in one response. Other modes queue messages until the current turn completes.

### Status indicator

waggle parses stream-json events in real-time:
- `thinking` → 🤔 Thinking...
- `tool_use` → 🔧 Tool: `<name>`
- `text` → 📝 Writing reply...
- `result` → delete status message

Inline keyboard buttons: 🧠 Show thinking, ✅ Show tasks.

### Permission prompts

Only available in CLI mode. Configured via `agent.permission_mode` in config.yaml:
- `bypass` — all tools auto-allowed
- `claude_files` — prompt owner for edits to `*claude*` paths
- `strict` — prompt for every tool call

### Stream-json protocol

One JSON line per event on stdin/stdout:

```json
// waggle → claude (stdin)
{"type": "user", "message": {"role": "user", "content": "<channel ...>text</channel>"}}

// claude → waggle (stdout)
{"type": "assistant", "message": {"content": [...]}}
{"type": "result", "result": "final text", "is_error": false}
```

## Mode-specific env vars

| Var | Default | Description |
|-----|---------|-------------|
| `WAGGLE_CLAUDE_PRINT` | `1` | Set to `0` to omit `-p` flag (breaks stream-json — for debugging only) |

## Limitations

- **Billing**: Classified as programmatic usage. $200/month credit cap starting June 15 2026.
- **Single concurrent turn**: Only one chat's turn runs at a time. Cross-chat messages queue.
