# Agent Modes — Overview

> Author: Your Name (Claude)
> Date: 2026-05-15

waggle supports three modes of communicating with Claude Code. Each mode trades features for billing classification. Select via `WAGGLE_MODE` env var.

**Before choosing a mode**, complete the [Setup Guide](../SETUP) — it covers config.yaml, bot token, access control, inject, and other common configuration that all modes share.

## Comparison

| | CLI Subprocess | Channel | tmux Session |
|---|:-:|:-:|:-:|
| **Env value** | `cli` (default) | `channel` | `tmux` |
| **Claude flag** | `-p --stream-json` | `--channel plugin:telegram` | (none — interactive) |
| **Billing** | Programmatic credit ($200/mo) | Subscription quota | Subscription quota |
| **Mode-specific setup** | None | Channel plugin access | Stop hook, OAuth login, tmux |
| **Mid-turn inject** | ✅ | ❌ | ❌ (queued) |
| **Status indicator** | ✅ (stream-json events) | ❌ | ❌ |
| **Show thinking/tasks** | ✅ | ❌ | ❌ |
| **Owner ops** | ✅ | ✅ | ✅ |
| **Inject endpoint** | ✅ | ✅ | ✅ |
| **Access control** | ✅ | ✅ | ✅ |
| **Permission prompts** | ✅ configurable | ❌ bypass only | ❌ bypass only |
| **Session persistence** | ✅ (`--continue`) | ✅ (`--continue`) | ✅ (`--continue`) |
| **MCP tools** | ✅ (waggle tools_server) | ✅ (built-in channel tools) | ✅ (waggle tools_server) |
| **Human login required** | ❌ | ❌ | ✅ (one-time OAuth) |
| **Maturity** | Production (v0.9.0) | Design phase | Prototype tested |

## When to use which

**CLI Subprocess** — Default. Full feature set. Use when mid-turn inject, status indicator, and permission prompts matter. Accept the $200/mo programmatic credit cost.

**Channel** — Use when cost is the priority and you don't need mid-turn inject or status indicators. Anthropic's built-in plugin handles message relay; waggle wraps it with access control, inject, and owner ops. Currently blocked by server-side gating.

**tmux Session** — Experimental. Use when you need subscription quota AND can provide one-time human OAuth login. Messages are queued (no mid-turn inject). Turn completion detected via Stop hook.

## Detailed pages

Each page covers mode-specific setup, unique features, and limitations:

- [CLI Subprocess](./cli) — `-p` stream-json protocol, mid-turn inject, status indicator
- [Channel](./channel) — Anthropic `--channel` plugin, bot token sharing
- [tmux Session](./tmux) — Stop hook, OAuth login, `tmux send-keys`
