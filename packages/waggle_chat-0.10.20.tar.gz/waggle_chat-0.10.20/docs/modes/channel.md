# Channel Mode

> `WAGGLE_MODE=channel` — Design phase, not yet implemented

Uses Anthropic's built-in `--channel plugin:telegram` to handle message relay. Claude runs in interactive mode (subscription quota). waggle wraps around it for access control, inject, and owner ops.

**Prerequisite:** Complete the [Setup Guide](../SETUP) first.

## How it works

```
Telegram → Anthropic channel plugin → Claude (interactive)
                                          ↕
                                     MCP tools (built-in)
              ↑
waggle provides: access control, inject endpoint, owner ops
```

1. Claude starts with `--channel plugin:telegram` — Anthropic's plugin polls Telegram directly
2. waggle does NOT poll Telegram (plugin owns the bot connection)
3. waggle provides auxiliary services alongside:
   - Access control (pre-filter before messages reach plugin)
   - Inject endpoint (HTTP → push prompt into claude context)
   - Owner operations (slash commands via separate channel)

## Billing

Interactive mode — uses subscription quota, NOT the $200/month programmatic credit. This is the primary motivation for this mode.

## Mode-specific configuration

### Bot token sharing

Both waggle and the Anthropic channel plugin need the same bot token. The design challenge is who "owns" the Telegram connection. Solutions under consideration:

1. **Separate bot tokens** — waggle uses one bot for ACL/owner ops, plugin uses another for chat. Cleanest separation but requires two bots per agent.
2. **Proxy pattern** — waggle intercepts Telegram webhook/polling, applies ACL, forwards allowed messages to the plugin.
3. **Sidecar** — waggle monitors but doesn't interfere with the plugin's Telegram connection. Provides inject + owner ops via separate channel.

### Plugin availability

The `--channel plugin:telegram` feature is currently server-side gated by Anthropic and not available on third-party gateway tokens. See [anthropics/claude-code#36665](https://github.com/anthropics/claude-code/issues/36665).

### Permission mode

Channel mode only supports `bypass` — interactive mode does not expose permission prompt hooks.

## What's different from CLI mode

| Feature | CLI mode | Channel mode |
|---------|:--------:|:------------:|
| Who polls Telegram | waggle (aiogram) | Anthropic plugin |
| Message format | stream-json via stdin | channel push (internal) |
| Mid-turn inject | ✅ stdin write | ❌ not supported |
| Status indicator | ✅ stream-json events | ❌ no event stream |
| Permission prompts | ✅ configurable | ❌ bypass only |
| MCP outbound tools | waggle tools_server | built-in channel tools |
| Billing | programmatic credit | subscription quota |

## Limitations

- **No mid-turn inject** — channel protocol doesn't support injecting messages during a turn
- **No status indicator** — no stream-json events to parse
- **No permission prompts** — interactive mode uses bypass only
- **Plugin dependency** — requires Anthropic's telegram plugin, currently server-side gated
- **Not yet implemented** — design phase only
