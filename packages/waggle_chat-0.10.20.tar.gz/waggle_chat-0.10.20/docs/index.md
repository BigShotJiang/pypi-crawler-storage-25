# waggle

Chat-layer runtime that wires one Claude Code agent to many chat platforms. One agent, unified context, many channels.

## Quick Links

- [Requirements](./REQUIREMENTS) — what waggle does and why
- [Architecture](./ARCHITECTURE) — component view inside the waggle process
- [Design](./DESIGN) — implementation decisions and wire formats
- [Comparison](./COMPARISON) — waggle vs Anthropic Telegram Channel
- [API](./API) — inject endpoint, config schema, events
- [Roadmap](./ROADMAP) — phased delivery plan
- [Tests](./TESTS) — test strategy and running guide

## What is waggle?

waggle sits between chat platforms (Telegram, Matrix, ...) and a Claude Code subprocess. It carries messages in, delivers replies out, and gives the operator runtime controls (restart, compact, pause) — nothing more.

```
external trigger ---+
                    +--> waggle --> claude-code --> waggle --> chat platforms
chat platforms -----+
```

## Key Features

- **Two operating modes** — CLI mode (waggle spawns `claude -p`) or Channel mode (Claude spawns waggle as MCP server)
- **Mid-turn inject** — fold new messages into a running turn
- **Owner operations** — /status, /pause, /resume, /abort, /restart, /new, /compact
- **Status indicator** — live "🤔 Thinking… / 🔧 Tool: X / 📝 Writing…" message with inline keyboard (Show Thinking, Show Tasks)
- **Compact indicator** — "🗜 Compacting…" → "✅ Context compacted" when Claude auto-compacts
- **Hook receiver** — internal HTTP server (127.0.0.1:8091) receiving PreToolUse/PostToolUse/Stop/PreCompact/PostCompact from Claude Code
- **Access control** — per-user, per-group, hot-reload allow-list + rate limiting
- **Inject endpoint** — HTTP trigger for CI, schedulers, alerts (bearer auth, :8080)
- **Deferred indicator attach** — rapid-fire messages don't spawn duplicate indicators
- **Group chat** — full support with mention detection + slash command rejection (DM-only owner ops)

## Operating Modes

| Mode | Env | Architecture | Billing |
|------|-----|--------------|---------|
| CLI (default) | `WAGGLE_MODE=cli` | waggle is parent, spawns `claude -p` subprocess | Programmatic credit |
| Channel | `WAGGLE_MODE=channel` | Claude is parent (tmux), waggle is MCP child | Subscription quota |

Both modes share the same Telegram client, access control, owner ops, inject, hooks, and indicators.

## E2E Test Coverage

47 test cases across 3 categories — all passing on both modes:
- **Happy path** (22): DM, status indicator lifecycle, owner ops (7 commands), pause/resume, group, bash tool, multi-turn context, inject
- **Unhappy path** (8): auth rejection, group command rejection, double pause/resume, empty inject
- **Edge cases** (17): minimal msg, 4K msg, unicode, rapid-fire×3, code blocks, multiline, concurrent inject, /status during work, special chars, hook health
