# waggle — Setup Guide

> Author: Your Name (Claude)
> Date: 2026-05-15

This guide covers the common setup for all waggle modes. Complete this first, then see the [Agent Modes](./modes/overview) page for mode-specific configuration.

---

## 1. Telegram bot token

Create a bot via [@BotFather](https://t.me/BotFather) and save the token.

```
/newbot → pick a name → copy the token
```

Disable "Group Privacy" if the bot will be used in group chats — otherwise the bot only sees messages that mention it or are replies to it.

---

## 2. config.yaml

waggle reads its configuration from `/etc/waggle/config.yaml` (or `--config <path>`). Minimal working config:

```yaml
telegram:
  bot_token: "${TELEGRAM_BOT_TOKEN}"

owner:
  user_id: 908624017            # your Telegram user ID (numeric)
```

### Full reference

```yaml
telegram:
  bot_token: "${TELEGRAM_BOT_TOKEN}"

owner:
  user_id: 908624017            # Telegram user ID — receives owner ops (/help, /reset, /notify)

agent:
  permission_mode: bypass       # bypass | claude_files | strict
  model: sonnet                 # optional — model alias or full ID
  effort: high                  # optional — reasoning effort: low/medium/high/xhigh/max
  working_directory: /home/user/project  # optional — claude's cwd

inject:
  enabled: true                 # enables POST /inject endpoint
  port: 8090                    # inject server listen port
  shared_secret: "${INJECT_SECRET}"     # bearer token for /inject auth
  default_chat_id: 908624017    # fallback chat_id when caller omits it

access:
  users:                        # allowed Telegram user IDs for DMs
    - 908624017
    - 123456789
  groups:                       # allowed group chats
    -1001234567890:
      require_mention: true     # only @bot mentions or replies reach the agent
      users: [908624017]        # optional — only these users in this group

rate_limit:
  per_chat: 30/5m              # sliding window: max messages per duration per chat
  per_user: 60/5m              # sliding window: max messages per duration per user

sinks:                          # event sink pipeline
  - stdout                      # log to stdout (default)
  # - kind: http               # HTTP sink for dashboard ingest
  #   url: https://ingest.example.com/events
  #   secret: "${SINK_SECRET}"
```

### Environment variable interpolation

Values like `"${TELEGRAM_BOT_TOKEN}"` are resolved from environment variables at startup. This keeps secrets out of the config file.

---

## 3. MCP tools server

waggle auto-generates an MCP config file and passes it to claude via `--mcp-config`. The tools server (`tools_server.py`) runs as claude's child process and provides:

| Tool | Description |
|------|-------------|
| `send_message` | Send a Telegram message to a chat |
| `react` | Add an emoji reaction to a message |
| `edit_message` | Edit an existing message |
| `download_attachment` | Download a file attached to a message |

No manual MCP setup is needed — waggle handles the wiring.

---

## 4. Access control

Two-level allow-list, hot-reloaded via mtime polling (no restart needed):

- **DMs**: `access.users` — list of allowed Telegram user IDs
- **Groups**: `access.groups` — map of chat_id with optional filters:
  - `require_mention: true` — only `@bot` mentions or replies to bot messages reach the agent. Lets the bot live silently in a noisy group.
  - `users: [...]` — narrow which users within the group can trigger the agent

The owner (`owner.user_id`) is always allowed regardless of access rules. Messages from non-allowed users are silently dropped (logged as `RejectEvent`).

To find your Telegram user ID, send any message to [@userinfobot](https://t.me/userinfobot).

---

## 5. Inject endpoint

When `inject.enabled: true`, waggle starts an HTTP server for external systems to push prompts into the agent:

```bash
curl -X POST http://waggle:8090/inject \
  -H "Authorization: Bearer ${INJECT_SECRET}" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "check disk usage", "chat_id": 908624017}'
```

Use cases: alertmanager, CI notifications, cron tasks, webhooks from Sonarr/Radarr/etc.

### Silent mode

Inject requests default to `silent: true` — the status indicator (🤔 Thinking… → 🔧 Tool… → 📝 Writing…) is suppressed so high-volume callers don't paint status messages in the chat. Set `silent: false` explicitly if you want the status indicator for a specific inject call.

```json
{"prompt": "...", "chat_id": 908624017, "silent": false}
```

### Raw endpoint

`POST /inject/raw` accepts an arbitrary JSON body and wraps it in a code-fence prompt — for webhook payloads where the body shape isn't yours to define (e.g. Sonarr/Radarr webhooks).

See [API reference](./API) for the full endpoint spec.

---

## 6. Owner operations

The owner (identified by `owner.user_id`) has access to privileged commands:

| Command | Description |
|---------|-------------|
| `/help` | List available commands |
| `/reset` | Reset claude session (restart subprocess) |
| `/pause` / `/resume` | Pause/resume message processing |
| `/status` | Current agent status |
| `/notify <text>` | Proactive push notification |

Non-owner `/foo` messages fall through to claude as normal prompts.

---

## 7. Rate limiting

Sliding-window rate limiting with two independent dimensions:

```yaml
rate_limit:
  per_chat: 30/5m    # one noisy room can't burst the agent
  per_user: 60/5m    # one chatty user across rooms can't drown it
```

- In-memory, per-process — resets on restart
- Owner is exempt (must be able to `/pause` during a flood)
- Rejected messages are counted (flood pushes the window forward)

---

## 8. UX indicators

waggle provides two visual feedback surfaces during agent turns (CLI mode only):

### Status indicator

A rolling reply message edited in place as the turn progresses:
- 🤔 Thinking…
- 🔧 Tool: `<name>` (tool arguments intentionally hidden — PII / accidental secrets)
- 📝 Writing reply…
- Deleted on turn completion

Inline keyboard buttons: 🧠 Show thinking, ✅ Show tasks.

Suppressed when `silent: true` (inject default).

### Typing indicator

Telegram's native "bot is typing…" in the chat header. Re-fired every 4 seconds while a turn is in flight. Auto-clears after 5 seconds of inactivity.

---

## 9. Attachments

waggle handles inbound Telegram attachments (photos, documents, voice, video):

- Photos are downloaded and passed to claude via `image_path` attribute in the `<channel>` tag
- Other file types are passed via `attachment_file_id` — claude can fetch them using the `download_attachment` MCP tool

---

## 10. Session persistence

waggle uses `--continue` to maintain claude's context across turns. If the claude subprocess dies (e.g. OOM, token expiry), waggle restarts it automatically — the pod itself does not restart.

---

## 11. Environment variables

Common env vars across all modes:

| Var | Required | Description |
|-----|:--------:|-------------|
| `WAGGLE_MODE` | | Mode selector: `cli` (default), `channel`, `tmux` |
| `TELEGRAM_BOT_TOKEN` | yes | Telegram bot token |
| `INJECT_SECRET` | | Shared secret for `/inject` endpoint |
| `CLAUDE_MODEL` | | Model override (same as `agent.model` in config) |
| `CLAUDE_EFFORT` | | Reasoning effort override |

Mode-specific env vars are documented on each mode's page.

---

## 12. Verify

After starting waggle, check the logs for:

```
INFO  config loaded from /etc/waggle/config.yaml
INFO  mode=cli
INFO  telegram polling started
INFO  inject server listening on :8090
INFO  access rules loaded: 2 users, 1 group
```

Send a test message from an allowed Telegram user. The status indicator should appear (in CLI mode), followed by a reply.

---

## Next steps

Choose your agent mode and configure mode-specific settings:

- [CLI Subprocess](./modes/cli) — full feature set, programmatic billing
- [Channel](./modes/channel) — subscription quota, Anthropic plugin (design phase)
- [tmux Session](./modes/tmux) — subscription quota, experimental
