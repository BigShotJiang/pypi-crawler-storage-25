# waggle — External API reference

> Author: Your Name (Claude)
> Status: API contract for **external systems** that integrate with waggle:
> alerting tools, CI, schedulers, dashboards. NOT for the agent (claude
> reaches waggle via MCP tools — see `tools_server.py`).

This doc covers two surfaces:

1. **`POST /inject`** — push a prompt into the agent (alertmanager, CI, …)
2. **Sink event JSON** — the JSON shape waggle POSTs to your dashboard
   ingest endpoint (one event per accepted/rejected inbound)

For the spec these surfaces implement, see
[`docs/REQUIREMENTS.md`](./REQUIREMENTS.md) §1.4 and §1.2 + §1.5.

---

## 1. `POST /inject` — external triggers

### Request

```
POST /inject
Authorization: Bearer <inject.shared_secret>
Content-Type: application/json
```

```json
{
  "prompt": "string (required, non-empty)",
  "chat_id": 123456789,
  "silent": true,
  "source": "string (optional, default 'external', truncated to 32 chars)"
}
```

| Field | Type | Required | Notes |
|---|---|:---:|---|
| `prompt` | string | ✅ | The text to push as a synthetic user-turn into the agent's active chat. Must be non-empty after `.strip()`. |
| `chat_id` | int | ⚠ | Required if `inject.default_chat_id` is not configured. When omitted, falls back to `default_chat_id`. Telegram chat_ids: positive for DMs, negative for groups/supergroups. |
| `silent` | bool | | **Default: `true`**. When true, suppresses the status indicator (🤔 Thinking… → 🔧 Tool… → 📝 Writing…) for this turn. High-volume callers (scheduler, Sonarr/Radarr/Bazarr) default silent to avoid painting status messages in the chat. Set `false` explicitly to show status. |
| `source` | string | | Surfaces in the channel-tag's `source` attribute and downstream observability events. Use it to identify the upstream system (`alertmanager`, `ci-prod`, `linear-webhook`). Truncated to 32 chars by the endpoint to defend against absurd inputs. |

### Responses

| Status | Body | When |
|---|---|---|
| `200` | `{"submitted": true, "chat_id": "<resolved>"}` | Submission accepted. **Note**: the agent's reply happens asynchronously via Telegram. The HTTP caller does not wait for the turn to complete. |
| `400` | `{"error": "..."}` | Bad input: malformed JSON, missing/empty prompt, `chat_id` is not an int, body too large (>1 MB) |
| `401` | `{"error": "unauthorized"}` | Missing or wrong `Authorization: Bearer` header. Constant-time compare — no timing leak. |

### Fire-and-forget semantics

`/inject` is **fire-and-forget**: the HTTP handler returns 200 as soon as
the submission is queued. The orchestrator's `submit_external` runs in a
background asyncio task. If `submit_external` later raises (e.g. claude
subprocess died), the failure is logged at WARNING in the pod's stdout —
NOT propagated to the HTTP caller, who has long since received its 200.

This is intentional. Real callers (alertmanager, CI, …) are
notify-and-go pipelines that don't want to block on the agent's turn
latency (~70 s with claude). The agent's reply lands on Telegram via the
MCP `reply` tool independently.

### Concurrency contract

Multiple concurrent POSTs are accepted in parallel and serialised by the
orchestrator's turn lock — claude only sees one user turn in flight at
a time. There is **no de-duplication**: identical bodies posted twice
produce two submissions. If you need idempotency, the caller must encode
it in the prompt.

### Example

```bash
curl -X POST https://waggle.example.com/inject \
  -H "Authorization: Bearer $WAGGLE_INJECT_SECRET" \
  -H "Content-Type: application/json" \
  -d '{
        "prompt": "Prod p99 latency > 500ms for the last 5 minutes. Investigate.",
        "source": "alertmanager"
      }'
# 200 {"submitted": true, "chat_id": "123456789"}
```

### Health

```
GET /healthz
```

Returns `200 {"ok": true}` with no auth required. Use this for K8s
liveness/readiness probes.

---

## 2. Sink event JSON

When `events.sink.kind: http` is configured, waggle POSTs one JSON object
per accepted/rejected inbound to your ingest endpoint:

```
POST <events.sink.url>
Authorization: Bearer <events.sink.secret>
Content-Type: application/json
```

The payload's `type` field distinguishes accept vs reject. **Both event
kinds use the same endpoint** — the dashboard fans out by `type`.

### Fail-soft contract

waggle's HttpSink is **fail-soft**: any HTTP error (timeout, connection
refused, 5xx, 4xx) is logged at WARNING in the pod stdout and dropped.
The agent keeps replying; the dashboard just loses a row. Do NOT rely on
sink delivery for correctness-critical flows.

If your endpoint is down for hours, you'll see one WARN log line per
attempted send in the pod. Future improvement: log throttling.

### `type: accept` — every accepted inbound

Spec §1.2 ("every accepted incoming message persisted in full").

```json
{
  "type": "accept",
  "source": "telegram",
  "chat": "123456789",
  "user": "987654321",
  "username": "anh_nam",
  "message_id": "42",
  "body": "the full message text — no truncation",
  "attachments": [
    {"kind": "photo", "file_id": "BAADBA..."},
    {"kind": "document", "file_id": "BQADBQ...", "mime_type": "application/pdf"}
  ],
  "ts": "2026-04-30T10:30:45Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `type` | const "accept" | |
| `source` | string | Transport name. Currently `"telegram"`. |
| `chat` | string | Stringified Telegram chat_id (DM = positive, group = negative). |
| `user` | string | Stringified user_id of the sender. |
| `username` | string | Telegram username if public, else stringified user_id. |
| `message_id` | string | Telegram message_id. **Exception**: callback_query inbound (button taps) synthesise this from the callback id; it won't match a real Telegram message. |
| `body` | string | Full text of the message OR caption (when message has an attachment + caption). For button taps, `body` is `"choice: <label>"`. |
| `attachments` | array | One entry per attached file. See below. |
| `ts` | string | ISO 8601 UTC, second resolution. |

**Attachments shape** (one entry per file):

```json
{"kind": "photo|document|video|audio|voice|sticker", "file_id": "...", "mime_type": "..." }
```

- `kind` is one of: `photo`, `document`, `video`, `audio`, `voice`, `sticker`
- `file_id` is the Telegram file reference. The dashboard fetches the
  binary on demand via Telegram's [getFile](https://core.telegram.org/bots/api#getfile)
  API. **waggle does not download attachments to local disk.**
- `mime_type` is present for `document`, `video`, `audio`, `voice` when
  Telegram exposes it. Omitted for `photo` and `sticker`.

### `type: reject` — dropped inbound

Spec §1.5 ("rejection events emitted to an external observability channel").

```json
{
  "type": "reject",
  "reason": "not-allowlisted",
  "source": "telegram",
  "chat": "999999999",
  "user": "999999999",
  "text_preview": "first 80 chars of the body",
  "ts": "2026-04-30T10:30:45Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `type` | const "reject" | |
| `reason` | enum | One of: `not-allowlisted`, `group-not-allowlisted`, `owner-only`, `rate-limited-chat`, `rate-limited-user` |
| `source` | string | Same as accept. |
| `chat`, `user` | string | Identifiers of the rejected sender. |
| `text_preview` | string | **First 80 chars only** — never the full body. Defends against the dashboard logging spam content from probes. |
| `ts` | string | ISO 8601 UTC. |

### Reject reason semantics

- **`not-allowlisted`**: DM (positive chat_id) from a user who isn't in
  `access.users`.
- **`group-not-allowlisted`**: Message in a group/supergroup whose
  chat_id isn't in `access.groups`.
- **`owner-only`**: An owner-only operation was attempted by a non-owner.
  (Note: today this reason is reserved but not actively emitted — non-owner
  slash commands fall through to claude rather than getting rejected. May be
  used in a future tighter mode.)
- **`rate-limited-chat`** / **`rate-limited-user`**: Sender exceeded
  `access.rate_limit.chat_per_minute` or `user_per_minute`. The dashboard
  can use this to surface noisy rooms or users for the operator to triage.

### 100-message acceptance contract (P6)

Spec §1.2 acceptance: 100 sequential `submit_inbound` calls produce 100
sink POSTs in order, no drops. Pinned by
`tests/test_events.py::test_http_sink_burst_100_messages`.

### Wire-format stability

These shapes are the v1 wire format. Backwards-incompatible changes
will:

1. Bump `type` to `"accept-v2"` or similar
2. Or add a `version` field to the event

Either way, your endpoint should accept unknown extra fields without
failing — waggle may add new fields (e.g. message reactions, edit
events) in future batches.

---

## 3. Authentication

Both `/inject` and the sink POST use **bearer authentication** with
constant-time compare (`secrets.compare_digest`):

```
Authorization: Bearer <shared_secret>
```

Secrets must be ≥16 characters. Configured via `env:` reference in the
config file so the actual value lives in K8s secrets, never in the
configmap or git.

### Threat model

- The bearer secret is the *only* gate. `chat_id` filtering is the
  caller's responsibility.
- If the secret leaks, an attacker can push arbitrary prompts at the
  agent. **Rotate the secret in K8s + restart the pod** if you suspect
  compromise.
- waggle does NOT log the secret on a wrong-bearer 401. The pod's stdout
  shows only "wrong bearer" — no value.

---

## 4. Versioning

- Endpoint paths (`/inject`, `/healthz`) are stable.
- Event JSON shapes are versioned (see §2 wire-format stability).
- Configuration shape (`config.yaml`) is **not** part of the external
  API — operators control it; backwards compat is best-effort.

When the API contract evolves, this doc is the source of truth.
