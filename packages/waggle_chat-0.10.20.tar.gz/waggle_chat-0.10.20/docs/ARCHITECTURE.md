# waggle — Architecture

> Author: Your Name (Claude)
> Date: 2026-05-15 (updated)

## C4 Level 1 — System Context

![C4 L1 System Context](assets/c4-l1-context.excalidraw)

waggle sits between chat platforms and a Claude Code agent. Three modes of agent communication are supported (see [Multi-mode](#multi-mode) below):

| Mode | Flag | Protocol | Usage classification | Mid-turn inject |
|------|------|----------|---------------------|-----------------|
| **CLI Subprocess** | `-p --stream-json` | stdin/stdout JSON | Programmatic ($200/mo credit) | ✅ |
| **Channel** | `--channel plugin:telegram` | Anthropic channel plugin | Interactive (subscription) | ❌ |
| **tmux Session** | (none — interactive) | `tmux send-keys` + Stop hook | Interactive (subscription) | ❌ (queued) |

---

## Component View

A zoom one level deeper: the components inside the `waggle` Python process — `python -m waggle.cli` — and how they cooperate around the agent.

![waggle component view](assets/architecture.svg)

---

## Why this shape

waggle owns the runtime loop. In **CLI Subprocess** mode (current default), claude-code runs as a long-lived subprocess in `--print --input-format stream-json --output-format stream-json` mode — each Telegram inbound becomes a JSON event written to claude's stdin, and each `result` event read from claude's stdout becomes a Telegram reply.

The whole design exists because the MCP `claude/channel` capability — which would let an MCP server push inbound messages directly into claude's context — is gated server-side by Anthropic and not currently available on third-party gateway tokens (see [anthropics/claude-code#36665](https://github.com/anthropics/claude-code/issues/36665)). The stream-json subprocess pattern is the de-facto workaround used by ductor and other orchestrators. It needs no special server-side feature flag, preserves unified context within a single subprocess across turns, and lets us keep MCP for outbound tools (which work without channel gating).

Per-pod single subprocess. Inbound from the **same chat** is folded into the running turn (mid-turn inject — claude reads new user events from stdin between agentic-loop rounds). Inbound from a **different chat** waits for the current turn to end so contexts don't bleed across users.

### Multi-mode

Starting June 15 2026, Anthropic classifies `claude -p` as programmatic usage with a separate $200/month credit. waggle will support three modes to give operators a choice:

- **CLI Subprocess** (`-p`): Full feature set — mid-turn inject, structured I/O, status indicator. Costs programmatic credit.
- **Channel** (`--channel`): Uses Anthropic's built-in Telegram channel plugin. Claude runs in interactive mode (subscription quota). waggle provides access control, inject, and owner ops on top. No mid-turn inject.
- **tmux Session**: Runs Claude in interactive mode inside tmux. waggle injects messages via `tmux send-keys`, detects turn completion via Stop hook. Subscription quota. No mid-turn inject. Requires one-time human OAuth login.

Mode is selected via `WAGGLE_MODE` env var (`cli` | `channel` | `tmux`). Default: `cli`.

---

## The modules

### Entry & wiring

- **`cli.py`** (~116 LOC) — Entrypoint. Parses args, sets up logging, loads config, wires the orchestrator + Telegram client + inject server + sinks, installs signal handlers, runs `asyncio.gather`. Nothing more.
- **`config.py`** (~208 LOC) — Loads and validates `config.yaml` (mounted from per-bot ConfigMap at `/etc/waggle/config.yaml`). Owner id, allow-list, rate limits, sinks, inject secret reference all flow from here.

### Core loop

- **`WaggleOrchestrator`** (`orchestrator.py`, ~816 LOC) — The single largest module and the load-bearing one. Owns:
  - The long-lived claude-code subprocess (start, restart on crash, drain on shutdown).
  - The per-chat queue: same-chat inbound is mid-turn injected; cross-chat inbound is queued.
  - `submit` (Telegram path) and `submit_external` (inject path) — `silent` flag flows through the inject path to suppress status surfaces.
  - The reply pump: reads claude stdout, dispatches `tool_use` events to StatusIndicator, emits final `result` text via TelegramClient.

### Inbound surfaces

- **`TelegramClient`** (`clients/telegram.py`, ~568 LOC) — The PRIMARY Bot instance (the only one that polls). aiogram's `getUpdates` long-poll, with attachment download (mime, file_id) and reply-to context. UTF-16 entity offset bug fixed in 0.8.2; attachments-only message drop fixed in 0.8.11.
- **`InjectServer`** (`inject.py`, ~243 LOC) — `aiohttp` server on `:8090` with two endpoints. `POST /inject` accepts `{prompt, chat_id, silent, source}` and defaults `silent=true` so high-volume callers (scheduler-v2, Sonarr/Radarr/Bazarr) don't paint a status message in the chat. `POST /inject/raw` accepts an arbitrary JSON body and wraps it in a code-fence prompt — for Sonarr-style webhooks where the body shape isn't ours to define.

### Outbound from claude

- **Tools Server** (`tools_server.py`, ~621 LOC) — An MCP server loaded by claude via `--mcp-config`. It runs as claude's child (waggle's grandchild) with its OWN, send-only Bot instance — that's why polling lives in the orchestrator and never collides here. Tools: `send_message`, `react`, `edit_message`, `download_attachment`. Intentionally does NOT advertise the `claude/channel` capability — that capability is server-side gated.

### UX surfaces

- **`StatusIndicator`** (`status_indicator.py`, ~394 LOC) — One rolling status message per turn, edited in place: 🤔 Thinking… → 🔧 Tool: `<name>` → 📝 Writing reply…. Tool _arguments_ are intentionally not shown (PII / accidental secrets in args).
- **`TypingIndicator`** (`typing_indicator.py`, ~81 LOC) — Telegram's `sendChatAction` paints "bot is typing…" for ~5 seconds. Re-fired periodically while the turn is in flight; orchestrator calls `attach(chat_id)` / `detach(chat_id)`.

### Gates

- **`AccessRules`** (`access.py`) — Allow-list with mtime hot-reload (no pod restart to add a chat). Two-level rule: DM → user_id ∈ `users`; group → chat_id ∈ `groups` (with optional per-group `users` filter for narrowing within a noisy group).
- **`RateLimit`** (`rate_limit.py`, ~111 LOC) — Sliding-window deque, two independent dimensions: per-chat budget (defends one room from bursting) and per-user budget (defends overall throughput from one chatty user across rooms). Pure in-memory; pod restart resets it.
- **`OwnerOps`** (`owner_ops.py`, ~322 LOC) — Privileged commands (`/help`, `/reset`, `/notify`, …) only fire when sender is `config.owner.user_id`. Non-owner `/foo` falls through to claude as a normal prompt, so the model can decide. Also hosts `proactive_notify` for outbound pushes.

### Wire format & events

- **`ChannelTag`** (`channel_tag.py`) — Frozen v1 wire format. Every inbound is wrapped as `<channel source=… chat_id=… user=… message_id=… ts=… [image_path=…] [attachment_file_id=…]>` so prompt construction stays platform-agnostic. `reply_to` quoted-prefix added in 0.8.9; `message_id` attribute added in 0.8.10.
- **Event sinks** (`events.py`, ~219 LOC) — `AcceptEvent` / `RejectEvent` are the adapter boundary. Sinks today: logger + OTLP. Future: S3 archive of accepted prompts, etc.

---

## Why broken into so many modules

The design pressure: keep the core (orchestrator + telegram client + inject) untouched while the auxiliary surfaces (UX indicators, allow-list, rate limit, owner commands) evolve. Each gate (access, rate, owner) can be unit-tested independently of the others; each UX surface can be muted (e.g. `silent=true` on inject) without changing the loop. The orchestrator is intentionally allowed to be the largest file — that's where the inherent complexity (subprocess lifecycle + per-chat queue + mid-turn inject) actually lives.

---

## Lifecycle

```
cli.py  →  load config
        →  spawn orchestrator (which spawns claude-code subprocess)
        →  spawn TelegramClient (poll loop)
        →  spawn InjectServer (aiohttp app)
        →  spawn StatusIndicator + TypingIndicator helpers
        →  asyncio.gather(...)  ── runs forever ──
        ↘  signal SIGTERM / SIGINT → drain orchestrator → kill claude → exit
```

The claude-code subprocess is restarted automatically if it dies (e.g. OAuth token expired, OOM). The pod itself never restarts on a turn failure — only orchestrator-internal state does.
