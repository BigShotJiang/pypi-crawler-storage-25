# PRD: waggle Channel Mode (Development Channel)

> Author: Your Name (Claude)
> Date: 2026-05-15
> Status: Draft
> Audience: product / engineering

---

## Problem

Starting June 15 2026, Anthropic classifies `claude -p` (print mode) as programmatic usage with a separate $200/month credit cap. All waggle bots currently run in CLI Subprocess mode (`-p --stream-json`), meaning the entire fleet will consume programmatic credit.

## Opportunity

Claude Code supports **development channels** — custom MCP servers that push messages into Claude's interactive session via `notifications/claude/channel`. Interactive mode uses subscription quota (Pro $20/mo, Max $100/mo), not programmatic credit. Development channels bypass Anthropic's approved plugin allowlist, so we don't depend on server-side gating.

## Proposal

Build waggle as a **dual-role MCP server** that Claude Code loads as a development channel. waggle keeps its existing responsibilities (Telegram polling, access control, inject, owner ops) but delivers messages via MCP channel notifications instead of stdin writes.

---

## Phase 1: Inbound path (this PRD)

### Goal

A waggle bot receives Telegram messages and delivers them to Claude via MCP channel notification. Claude replies via MCP tools. No `-p` flag, no programmatic credit.

### Architecture

```
Claude Code (interactive mode)
    │
    │  spawns as child (stdio MCP)
    │
    ▼
waggle (MCP server)
    ├── declares claude/channel capability
    ├── declares tools: reply, react, edit_message, download_attachment
    ├── polls Telegram (aiogram)
    ├── listens :8090 (inject endpoint)
    │
    │  on inbound message:
    │  ──► access control check
    │  ──► rate limit check
    │  ──► mcp.notification("notifications/claude/channel", {
    │        content: "<channel source=... chat_id=... user=...>text</channel>",
    │        meta: { chat_id, user, message_id, ts }
    │      })
    │
    │  on tool call from Claude:
    │  ──► reply/react/edit → Telegram API
    │
    └── owner ops (privileged /commands)
```

### Key difference from current architecture

| | CLI mode (current) | Channel mode (new) |
|---|---|---|
| **Who is parent** | waggle spawns claude | Claude spawns waggle |
| **Transport** | stdin/stdout JSON | stdio MCP (notifications + tool calls) |
| **Claude flag** | `-p --stream-json` | `--dangerously-load-development-channels server:waggle` |
| **Billing** | Programmatic ($200/mo credit) | Subscription (Pro/Max quota) |
| **Message delivery** | Write JSON to stdin | `notifications/claude/channel` |
| **Reply delivery** | MCP tool call (same) | MCP tool call (same) |

### What stays the same

- **ChannelTag wire format** — `<channel source="telegram" chat_id="..." user="..." ...>` unchanged
- **Access control** — same allow-list, same hot-reload, same reject events
- **Rate limiting** — same sliding window, same owner exemption
- **Inject endpoint** — same HTTP API on `:8090`, same auth, same silent flag
- **Owner ops** — same privileged commands, same owner.user_id check
- **MCP tools** — reply, react, edit_message, download_attachment (already MCP — just change from separate tools_server to unified server)
- **Attachment handling** — same photo download + channel tag attributes

### What changes

1. **waggle becomes an MCP server** — implements `@modelcontextprotocol/sdk` Server (or Python equivalent), declares `claude/channel` capability + tools
2. **Message delivery** — `orchestrator.submit()` sends MCP notification instead of stdin write
3. **Turn detection** — no `result` event from stdout. Options:
   - Claude calls a `turn_complete` tool when done (waggle exposes it)
   - Or waggle infers turn end from silence + no pending tool calls
4. **Process topology** — Claude is parent, waggle is child. Entrypoint must start Claude with `--dangerously-load-development-channels server:waggle`
5. **tools_server.py merges into waggle** — no separate grandchild process. waggle is both channel + tools in one MCP server

### MCP server manifest

waggle registers in `.mcp.json` (or `--mcp-config`):

```json
{
  "mcpServers": {
    "waggle": {
      "command": "python",
      "args": ["-m", "waggle.mcp_server"],
      "env": {
        "TELEGRAM_BOT_TOKEN": "...",
        "WAGGLE_CONFIG": "/etc/waggle/config.yaml"
      }
    }
  }
}
```

### Notification format

```python
await server.notification(
    method="notifications/claude/channel",
    params={
        "content": "hello agent",
        "meta": {
            "chat_id": "42",
            "user": "908624017",
            "username": "zorrop_06",
            "message_id": "123",
            "ts": "2026-05-15T10:00:00Z"
        }
    }
)
```

Claude receives this as:
```xml
<channel source="waggle" chat_id="42" user="908624017" username="zorrop_06" message_id="123" ts="2026-05-15T10:00:00Z">
hello agent
</channel>
```

### Supported meta fields

`meta` is a free-form dict — any key/value pair becomes an XML attribute on the `<channel>` tag. Keys must be identifiers (letters, digits, underscores).

Standard fields waggle populates:

| Field | Type | Description |
|-------|------|-------------|
| `chat_id` | string | Telegram chat ID (positive = DM, negative = group) |
| `user` | string | Telegram user ID of the sender |
| `username` | string | Telegram username (if public) |
| `message_id` | string | Telegram message ID |
| `ts` | string | ISO 8601 UTC timestamp |
| `image_path` | string | Local path to downloaded photo (when message has a photo) |
| `attachment_file_id` | string | Telegram file_id for non-photo attachments |
| `reply_to` | string | Quoted text from the replied-to message (if replying) |
| `source` | string | Auto-set by Claude to the MCP server name ("waggle") |

Custom fields can be added freely — Claude sees them as additional attributes on the tag.

### Inject in channel mode

Same HTTP contract as CLI mode. waggle delivers the injected prompt via MCP notification instead of stdin write.

```
POST /inject → waggle → access check → rate limit
  → mcp.notification("notifications/claude/channel", ...)
```

#### POST /inject

```bash
curl -X POST http://waggle:8090/inject \
  -H "Authorization: Bearer ${INJECT_SECRET}" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Prod p99 latency > 500ms for 5 minutes. Investigate.",
    "chat_id": 908624017,
    "silent": true,
    "source": "alertmanager"
  }'
```

waggle wraps this into a notification:

```python
await server.notification(
    method="notifications/claude/channel",
    params={
        "content": "Prod p99 latency > 500ms for 5 minutes. Investigate.",
        "meta": {
            "chat_id": "908624017",
            "source": "alertmanager",
            "ts": "2026-05-15T10:00:00Z"
        }
    }
)
```

| Field | Default | Description |
|-------|---------|-------------|
| `prompt` | (required) | Text to inject as a user turn |
| `chat_id` | `inject.default_chat_id` | Target chat |
| `silent` | `true` | Suppress status indicator |
| `source` | `"external"` | Identifies the upstream system (max 32 chars) |

#### POST /inject/raw

For webhooks where the body shape isn't yours to define (Sonarr, Radarr, Bazarr):

```bash
curl -X POST http://waggle:8090/inject/raw \
  -H "Authorization: Bearer ${INJECT_SECRET}" \
  -H "Content-Type: application/json" \
  -d '{
    "eventType": "Download",
    "series": {"title": "Bocchi the Rock!"},
    "episodes": [{"seasonNumber": 1, "episodeNumber": 3}]
  }'
```

waggle wraps the entire body in a code fence and injects it:

```python
await server.notification(
    method="notifications/claude/channel",
    params={
        "content": "External webhook payload:\n```json\n{\"eventType\":\"Download\",\"series\":{\"title\":\"Bocchi the Rock!\"},...}\n```",
        "meta": {
            "chat_id": "908624017",
            "source": "raw-webhook",
            "ts": "2026-05-15T10:00:00Z"
        }
    }
)
```

### Config changes

```yaml
# config.yaml — no changes needed for basic channel mode
# WAGGLE_MODE env var selects the transport:
#   cli     → current behavior (spawn claude -p, stdin/stdout)
#   channel → MCP server mode (claude spawns waggle)
```

### Acceptance criteria

1. waggle starts as MCP server child of Claude Code
2. Claude receives Telegram messages as `<channel>` tags via MCP notification
3. Claude replies via `reply` tool call → message appears in Telegram
4. Claude reacts via `react` tool call → emoji appears on message
5. Access control blocks non-allowlisted users (reject event logged)
6. Rate limiting enforces per-chat and per-user budgets
7. Inject endpoint accepts POST and delivers to Claude via notification
8. Owner ops (`/help`, `/reset`, `/status`) work
9. No `-p` flag used — Claude runs in interactive mode
10. Billing is subscription quota, not programmatic credit

### Out of scope (phase 2+)

- Status indicator (🤔 Thinking… → 🔧 Tool…) — requires event stream from Claude, not available in channel mode
- Show thinking / show tasks buttons
- Mid-turn inject — channel notification may not interrupt an active turn
- Permission prompts relay
- Concurrent turn handling improvements

---

## Phase 2: Hook-driven status + task tracking

**Scope:** All modes (cli, channel, tmux). Not channel-specific — hooks work regardless of transport.

### Goal

Surface agent progress and task state to Telegram via Claude Code hooks. The status message shows both what Claude is doing right now AND a task checklist when tasks exist.

### Hooks architecture

```
Claude Code
    │
    ├── PreToolUse hook ──► HTTP POST 127.0.0.1:8091/hooks/tool-start
    ├── PostToolUse hook ──► HTTP POST 127.0.0.1:8091/hooks/tool-end
    ├── TaskCreated hook ──► HTTP POST 127.0.0.1:8091/hooks/task
    ├── TaskCompleted hook ─► HTTP POST 127.0.0.1:8091/hooks/task
    └── Stop hook ──────────► HTTP POST 127.0.0.1:8091/hooks/stop
                                    │
                                    ▼
                              waggle (status manager)
                                    │
                                    ▼
                              Telegram status message
                              (edit in place)
```

### Hook configuration

Installed in Claude's `settings.json`:

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "",
      "hooks": [{
        "type": "http",
        "url": "http://127.0.0.1:8091/hooks/tool-start"
      }]
    }],
    "PostToolUse": [{
      "matcher": "",
      "hooks": [{
        "type": "http",
        "url": "http://127.0.0.1:8091/hooks/tool-end"
      }]
    }],
    "Stop": [{
      "matcher": "",
      "hooks": [{
        "type": "http",
        "url": "http://127.0.0.1:8091/hooks/stop"
      }]
    }]
  }
}
```

Task hooks (`TaskCreated`, `TaskCompleted`) added when available — currently a known bug where Task* tools bypass hooks (#20243).

### Status message format

Single rolling message, edited in place:

**Without tasks:**
```
🔧 Tool: Bash
```

**With tasks:**
```
🔧 Tool: Bash

📋 Tasks:
✅ Fix auth bug
🔄 Run tests
⬜ Update config
⬜ Write docs
```

**After turn completes (Stop hook):**
Status message deleted (or updated to show final task summary).

### Task state management

waggle maintains an in-memory task map per turn:

| Event | Action |
|-------|--------|
| `TaskCreated` | Add `{taskId, subject, status: "pending"}` to map |
| `TaskCompleted` | Update task status to `"completed"` |
| `PreToolUse` | Update status line: "🔧 Tool: `<name>`" |
| `PostToolUse` | Clear status line (or show next tool) |
| `Stop` | Reset task map, delete/update status message |

### Task clear strategy

1. **Stop hook fires** → reset entire task map (new turn = clean slate)
2. **During turn** — tasks accumulate. Completed tasks stay visible (✅) until turn ends
3. **Task deleted** → remove from map immediately

### What this enables per mode

| Feature | CLI mode | Channel mode | tmux mode |
|---------|:--------:|:------------:|:---------:|
| Tool status (🔧) | ✅ hooks + stream-json | ✅ hooks | ✅ hooks |
| Task checklist (📋) | ✅ hooks | ✅ hooks | ✅ hooks |
| Thinking (🤔) | ✅ stream-json only | ❌ | ❌ |
| Turn detection | ✅ result event + Stop hook | ✅ Stop hook | ✅ Stop hook |

### Acceptance criteria

1. PreToolUse/PostToolUse hooks fire and waggle receives tool name
2. Status message shows current tool in all modes
3. Task checklist renders when Claude creates tasks
4. Tasks update from ⬜ → 🔄 → ✅ as Claude progresses
5. Stop hook resets task state for next turn
6. Silent inject suppresses status message (existing behavior preserved)
7. Works in cli, channel, and tmux modes

### Out of scope (phase 3+)

- Thinking content streaming (no hook exists for this)
- Mid-turn inject in channel/tmux mode
- Permission prompts relay
- Concurrent turn handling

---

## Hook security

### Dual-port isolation

Hook endpoint runs on a separate port from the external inject API, bound to localhost only:

| Port | Scope | Auth | K8s Service | Purpose |
|------|-------|------|-------------|---------|
| `:8090` | External | Bearer token | Yes (exposed) | inject, healthz |
| `:8091` | Internal | None | No | hooks (PreToolUse, PostToolUse, Stop, Task*) |

Port 8091 binds `127.0.0.1` — only processes within the same pod can reach it. No K8s Service exposes it, so cluster-level access is impossible. No auth needed — network isolation is the security boundary.

### Hook configuration

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "",
      "hooks": [{"type": "http", "url": "http://127.0.0.1:8091/hooks/tool-start"}]
    }],
    "PostToolUse": [{
      "matcher": "",
      "hooks": [{"type": "http", "url": "http://127.0.0.1:8091/hooks/tool-end"}]
    }],
    "Stop": [{
      "matcher": "",
      "hooks": [{"type": "http", "url": "http://127.0.0.1:8091/hooks/stop"}]
    }]
  }
}
```

### Data in hook payloads

HTTP hooks receive the full event context:

| Data | Risk | Present in |
|------|------|-----------|
| `tool_name` | Low | PreToolUse, PostToolUse |
| `tool_input` | **High** — may contain secrets, file contents, API keys | PreToolUse |
| `session_id` | Low | All hooks |
| `transcript_path` | Low | Stop |
| `cwd` | Low | All hooks |

**Mitigation:** waggle's hook endpoint only extracts `tool_name` for status display. It does NOT log, store, or forward `tool_input`. Tool arguments are intentionally not shown in the status message (existing design — PII / accidental secrets in args).

### Error behavior

HTTP hook errors are **non-blocking** — if waggle's hook endpoint is down, Claude continues working. Status messages just won't update. This is the correct behavior: hooks are for UX, not for correctness.

---

## Risks

| Risk | Mitigation |
|------|------------|
| `--dangerously-load-development-channels` flag name implies instability | Flag is stable in research preview; name is just a safety warning. Monitor for deprecation. |
| Channel notifications may be dropped if Claude is busy | Test behavior under load. Implement queue + retry in waggle if needed. |
| Interactive mode token expiry requires human re-login | Same as tmux mode — OAuth refresh or creds-sync. Document as operational requirement. |
| Anthropic changes channel protocol | Wire format is MCP standard. Pin to known-good claude-code version. |
| Development channels may graduate to requiring approval | Build waggle as a proper plugin if this happens. The MCP interface is the same. |

---

## Success metrics

- Fleet migrated from CLI to channel mode
- $0 programmatic credit usage post-migration
- Message delivery latency ≤ CLI mode (< 2s from Telegram to Claude)
- Zero missed messages (inject + Telegram) over 7-day soak test
