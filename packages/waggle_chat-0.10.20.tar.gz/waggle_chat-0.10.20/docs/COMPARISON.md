# waggle vs Anthropic Telegram Channel — Feature Comparison

> Author: Your Name (Claude)
> Date: 2026-05-15

Comparison between waggle-chat and Anthropic's built-in `--channels plugin:telegram` for Claude Code.

---

## At a Glance

| Feature | Anthropic Channel | waggle |
|---------|:-:|:-:|
| **Transport** | | |
| Telegram DM | ✅ | ✅ |
| Telegram Groups | ✅ | ✅ |
| Group @mention filter | ✅ | ✅ |
| Matrix / Discord | ❌ | ❌ (designed for P7) |
| **Agent Lifecycle** | | |
| Claude Code subprocess | interactive (`--channels`) | `-p --stream-json` |
| Session persistence (`--continue`) | ✅ | ✅ |
| Mid-turn inject (same chat) | ❌ | ✅ |
| Cross-chat isolation | N/A (single chat) | ✅ |
| Model / effort selection | env only | env + config |
| Auto-restart on crash | ❌ | ❌ (planned P5) |
| **Messaging** | | |
| Text reply | ✅ | ✅ |
| MarkdownV2 formatting | ✅ | ✅ |
| Emoji reactions | ✅ | ✅ |
| Edit sent message | ❌ | ✅ |
| Photo/file attachments (outbound) | ✅ | ✅ |
| Spoiler on images | ✅ (via patch) | ✅ |
| Photo/file receive (inbound) | ✅ | ✅ |
| Inline keyboard (choices) | ❌ | ✅ |
| **Status & Feedback** | | |
| Working indicator (🤔 / 🔧 / 📝) | ❌ | ✅ |
| Show thinking (extended reasoning) | ❌ | ✅ |
| Show tasks (TodoWrite) | ❌ | ✅ |
| Ack reaction on receive | ❌ | ✅ (configurable) |
| **Access Control** | | |
| DM allow-list | ✅ (`access.json`) | ✅ (config.yaml) |
| Group allow-list | ✅ (`access.json`) | ✅ |
| Per-group user filter | ❌ | ✅ |
| Pairing flow (device code) | ✅ | ❌ (direct config) |
| Hot reload allow-list | ❌ (restart needed) | ✅ |
| **Owner Operations** | | |
| `/restart` agent | ❌ | ✅ |
| `/status` agent state | ❌ | ✅ |
| `/compact` memory | ❌ | ✅ |
| `/fresh` new session | ❌ | ✅ |
| `/cancel` in-flight turn | ❌ | ✅ |
| `/pause` / `/resume` | ❌ | ✅ |
| **External Integration** | | |
| Inject endpoint (HTTP) | ❌ | ✅ |
| Shared secret auth | N/A | ✅ |
| Default chat fallback | N/A | ✅ |
| **Permission Prompts** | | |
| Bypass mode | ✅ (`--dangerously-skip-permissions`) | ✅ |
| Per-tool approval (Telegram buttons) | ❌ | ✅ (claude_files / strict) |
| Timeout auto-deny | N/A | ✅ (10min) |
| **Observability** | | |
| OpenTelemetry export | via Claude Code | via Claude Code |
| Reject event logging | ❌ | ✅ (stdout sink) |
| Heartbeat hooks | ❌ (external) | ❌ (external) |
| **MCP Tools** | | |
| Outbound tools (reply/react) | Built-in channel tools | `waggle.tools_server` (MCP) |
| AgentGateway federation | ✅ (separate config) | ✅ (mcp.json) |
| Playwright sidecar | ✅ | ✅ |
| **Usage Classification** | | |
| Anthropic billing | Interactive (subscription) | Programmatic (`-p` → $200 credit June 15) |

---

## Key Differences

### 1. Subprocess Model
- **Anthropic**: Claude runs in interactive mode with `--channels plugin:telegram`. The channel plugin pushes messages INTO the running TUI session. Classification: interactive (subscription quota).
- **waggle**: Claude runs as a subprocess in `-p --input-format stream-json --output-format stream-json` mode. waggle feeds messages via stdin, reads responses via stdout. Classification: programmatic ($200/mo credit after June 15).

### 2. Mid-turn Inject
waggle's killer feature. If a user sends a second message while Claude is still processing the first, waggle writes it to Claude's stdin immediately — Claude picks it up between agentic-loop rounds and incorporates it into the current response. Anthropic's channel does not support this.

### 3. Owner Operations
waggle exposes 7 slash commands exclusively to the configured owner. Anthropic's channel has no operator surface — the bot just runs.

### 4. Working Status Indicator
waggle posts and edits a rolling status message (`🤔 Thinking → 🔧 Tool: X → 📝 Writing`) with inline buttons for Show Thinking and Show Tasks. Anthropic's channel shows nothing until the response is complete.

### 5. Permission Prompts
waggle can route dangerous tool calls to Telegram for owner approval (inline buttons: ✅/❌/🔍). Three modes: bypass, claude_files (only `*claude*` paths), strict (everything). Anthropic's channel only supports bypass.

### 6. Access Control
Both support allow-lists. waggle adds per-group user filters (restrict who in a group can trigger the bot) and hot reload (edit config without restart).

---

## When to Use Which

| Scenario | Recommendation |
|----------|---------------|
| Personal bot, simple setup | Anthropic Channel |
| Multi-user bot, need operator controls | waggle |
| Group chat with mixed trust levels | waggle (per-group user filter) |
| Cost-sensitive after June 15 | Anthropic Channel (subscription) or waggle + tmux-bridge (experimental) |
| Need mid-turn message folding | waggle |
| Need external triggers (CI/scheduler) | waggle (inject endpoint) |
