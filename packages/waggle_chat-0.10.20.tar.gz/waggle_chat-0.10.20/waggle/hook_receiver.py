"""Internal hook receiver — listens on localhost:8091 for Claude Code hooks.

Receives PreToolUse, PostToolUse, Stop, TaskCreated, TaskCompleted events
from Claude Code HTTP hooks and updates the status indicator accordingly.

This endpoint is internal-only: binds 127.0.0.1, no auth, no K8s Service.
Separate from the external inject endpoint on :8090.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

from aiohttp import web

if TYPE_CHECKING:
    from .status_indicator import StatusIndicator

log = logging.getLogger(__name__)

DEFAULT_BIND = "127.0.0.1"
DEFAULT_PORT = 8091


class HookReceiver:
    def __init__(
        self,
        *,
        bind: str = DEFAULT_BIND,
        port: int = DEFAULT_PORT,
    ):
        self._bind = bind
        self._port = port
        self._app = web.Application()
        self._app.router.add_post("/hooks/tool-start", self._handle_tool_start)
        self._app.router.add_post("/hooks/tool-end", self._handle_tool_end)
        self._app.router.add_post("/hooks/stop", self._handle_stop)
        self._app.router.add_post("/hooks/task", self._handle_task)
        self._app.router.add_post("/hooks/compact-start", self._handle_compact_start)
        self._app.router.add_post("/hooks/compact-end", self._handle_compact_end)
        self._runner: web.AppRunner | None = None

        self._status: StatusIndicator | None = None
        self._on_stop: asyncio.Event | None = None
        self._telegram = None  # bound by channel_server/orchestrator for compact notifications
        self._default_chat_id: int | None = None

        self._tasks: dict[str, dict[str, Any]] = {}
        self._current_tool: str | None = None
        self._compact_msg_id: str | None = None

    def bind_status(self, status: StatusIndicator) -> None:
        self._status = status

    def bind_telegram(self, telegram, default_chat_id: int | None = None) -> None:
        self._telegram = telegram
        self._default_chat_id = default_chat_id

    def bind_stop_event(self, event: asyncio.Event) -> None:
        self._on_stop = event

    @property
    def tasks(self) -> dict[str, dict[str, Any]]:
        return self._tasks

    def reset_tasks(self) -> None:
        self._tasks.clear()
        self._current_tool = None

    async def start(self) -> None:
        self._runner = web.AppRunner(self._app, access_log=None)
        await self._runner.setup()
        site = web.TCPSite(self._runner, self._bind, self._port)
        await site.start()
        log.info("hook receiver listening on %s:%s", self._bind, self._port)

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None

    async def _handle_tool_start(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"ok": True})

        tool_name = body.get("tool_name") or body.get("toolName") or ""
        if tool_name:
            self._current_tool = _pretty_tool_name(tool_name)
            if self._status is not None:
                await self._status.set_state(
                    f"🔧 Tool: {self._current_tool}",
                    task_summary=self._render_tasks(),
                )
            log.debug("hook: tool-start %s", self._current_tool)

        return web.json_response({"ok": True})

    async def _handle_tool_end(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"ok": True})

        tool_name = body.get("tool_name") or body.get("toolName") or ""
        if tool_name:
            log.debug("hook: tool-end %s", _pretty_tool_name(tool_name))
        self._current_tool = None

        if self._status is not None and self._tasks:
            await self._status.set_state(
                "📝 Working…",
                task_summary=self._render_tasks(),
            )

        return web.json_response({"ok": True})

    async def _handle_stop(self, request: web.Request) -> web.Response:
        log.debug("hook: stop — resetting task state")
        self.reset_tasks()
        if self._status is not None:
            try:
                await self._status.success()
            except Exception as e:
                log.warning("status success on stop failed: %r", e)
        if self._on_stop is not None:
            self._on_stop.set()
        return web.json_response({"ok": True})

    async def _handle_task(self, request: web.Request) -> web.Response:
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"ok": True})

        event_name = body.get("hook_event_name") or body.get("hookEventName") or ""
        task_id = body.get("task_id") or body.get("taskId") or ""
        subject = body.get("subject") or ""
        status = body.get("status") or ""

        if event_name == "TaskCreated" and task_id:
            self._tasks[task_id] = {
                "subject": subject,
                "status": status or "pending",
            }
            log.debug("hook: task-created id=%s subject=%s", task_id, subject)
        elif event_name == "TaskCompleted" and task_id:
            if task_id in self._tasks:
                self._tasks[task_id]["status"] = "completed"
            else:
                self._tasks[task_id] = {"subject": subject, "status": "completed"}
            log.debug("hook: task-completed id=%s", task_id)

        if self._status is not None:
            label = f"🔧 Tool: {self._current_tool}" if self._current_tool else "📝 Working…"
            await self._status.set_state(label, task_summary=self._render_tasks())

        return web.json_response({"ok": True})

    async def _handle_compact_start(self, request: web.Request) -> web.Response:
        log.info("hook: compact-start")
        chat_id = self._pending_chat or self._default_chat_id
        if self._telegram is not None and chat_id is not None:
            try:
                mid = await self._telegram.reply(
                    chat_id=str(chat_id), text="🗜 Compacting context…",
                )
                self._compact_msg_id = mid
            except Exception as e:
                log.warning("compact indicator send failed: %r", e)
        return web.json_response({"ok": True})

    async def _handle_compact_end(self, request: web.Request) -> web.Response:
        log.info("hook: compact-end")
        chat_id = self._pending_chat or self._default_chat_id
        if self._telegram is not None and chat_id is not None:
            if self._compact_msg_id:
                try:
                    await self._telegram.edit_text(
                        chat_id=str(chat_id),
                        message_id=self._compact_msg_id,
                        text="✅ Context compacted",
                    )
                except Exception as e:
                    log.warning("compact indicator edit failed: %r", e)
            else:
                try:
                    await self._telegram.reply(
                        chat_id=str(chat_id), text="✅ Context compacted",
                    )
                except Exception as e:
                    log.warning("compact indicator send failed: %r", e)
        self._compact_msg_id = None
        return web.json_response({"ok": True})

    def _render_tasks(self) -> str | None:
        if not self._tasks:
            return None
        lines = ["📋 Tasks:"]
        for task in self._tasks.values():
            st = task.get("status", "pending")
            subj = task.get("subject", "?")
            if st == "completed":
                lines.append(f"  ✅ {subj}")
            elif st == "in_progress":
                lines.append(f"  🔄 {subj}")
            else:
                lines.append(f"  ⬜ {subj}")
        return "\n".join(lines)


def _pretty_tool_name(raw: str) -> str:
    if raw.startswith("mcp__"):
        rest = raw[len("mcp__"):]
        _server, _, name = rest.partition("__")
        if name:
            return name
    return raw
