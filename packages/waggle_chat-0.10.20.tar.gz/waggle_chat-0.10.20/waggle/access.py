"""Allow-list with hot-reload via mtime polling.

Two-level rule:

  - DM (chat_id is positive in Telegram): user_id must be in `users`
  - Group (chat_id is negative in Telegram): chat_id must be in `groups`.
    Per-group `users` is an OPTIONAL filter:
      * non-empty → only those user_ids are allowed in this group
      * empty / omitted → ANYONE in the group is allowed (matches the
        Anthropic claude-code Telegram MCP behaviour: once an operator
        whitelists a group, the group itself is the trust boundary)
    `require_mention` further restricts to `@bot` mentions / replies to
    bot messages so the bot stays silent in a chatty group otherwise.

The runtime instantiates this once and registers it as a callable filter
(`access(message)` returns True/False). The instance background-polls the
config file mtime; on change, it re-loads atomically without dropping any
in-flight check.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import yaml

from .rate_limit import RateLimitConfig

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class GroupRule:
    """Per-group access policy.

    `users` empty (or omitted) → ANYONE in the group is allowed. The fact
    that the operator whitelisted this chat_id at all is the trust signal;
    listing every member by id would be tedious and brittle for groups
    that include other bots, ad-hoc invitees, etc.

    `users` non-empty → only those specific user_ids are allowed (useful
    when only a handful of trusted humans in a noisy group should drive
    the agent).

    `require_mention` → only @bot mentions or replies to a bot message
    are accepted (defends a noisy group: bot stays silent unless
    explicitly addressed).

    `silent` → suppress the rolling status indicator for turns triggered
    from this group. Typing-action indicator and final reply still go
    through; only the noisy 🤔 Thinking… message thread surface is
    hidden. Especially important for multi-bot groups where the status
    message would re-trigger sibling bots in a feedback loop."""

    users: frozenset[int] = field(default_factory=frozenset)
    require_mention: bool = False
    silent: bool = False


@dataclass
class AccessRules:
    users: frozenset[int] = field(default_factory=frozenset)
    groups: dict[int, GroupRule] = field(default_factory=dict)

    def allows(self, chat_id: int, user_id: int, *,
               is_mentioned: bool = False) -> bool:
        # DM (Telegram convention: positive chat_id == private chat with that user)
        if chat_id >= 0:
            return user_id in self.users
        # Group: chat must be allow-listed
        rule = self.groups.get(chat_id)
        if rule is None:
            return False
        # If require_mention, the bot only listens when explicitly addressed.
        # `is_mentioned` is True when the message either @-mentions the bot
        # OR is a reply to a previous bot message (implicit mention).
        if rule.require_mention and not is_mentioned:
            return False
        # `users` non-empty restricts to specific senders. Empty means the
        # group itself is the trust boundary — anyone in the chat passes.
        if rule.users:
            return user_id in rule.users
        return True

    def is_silent(self, chat_id: int) -> bool:
        """True when inbound from this chat should suppress the per-turn
        status indicator and typing action. DMs are never silent; only
        configured groups can opt in via `silent: true`."""
        if chat_id >= 0:
            return False
        rule = self.groups.get(chat_id)
        return rule is not None and rule.silent


def _coerce_int_set(items: Iterable) -> frozenset[int]:
    return frozenset(int(x) for x in (items or []))


def _coerce_groups(raw: dict | None) -> dict[int, GroupRule]:
    if not raw:
        return {}
    out: dict[int, GroupRule] = {}
    for k, v in raw.items():
        chat_id = int(k)
        block = v or {}
        users = _coerce_int_set(block.get("users", []))
        require_mention = bool(block.get("require_mention", False))
        silent = bool(block.get("silent", False))
        out[chat_id] = GroupRule(
            users=users,
            require_mention=require_mention,
            silent=silent,
        )
    return out


def parse_rules(access_block: dict | None) -> AccessRules:
    block = access_block or {}
    return AccessRules(
        users=_coerce_int_set(block.get("users", [])),
        groups=_coerce_groups(block.get("groups", {})),
    )


def parse_rate_limit(access_block: dict | None) -> RateLimitConfig:
    block = (access_block or {}).get("rate_limit", {}) or {}
    return RateLimitConfig(
        chat_per_minute=int(block.get("chat_per_minute", 0)),
        user_per_minute=int(block.get("user_per_minute", 0)),
        window_seconds=float(block.get("window_seconds", 60.0)),
    )


class AccessControl:
    """Hot-reloading allow-list. Construct from a YAML config path; call
    `await start()` once before use, `await stop()` on shutdown.

    `allows(chat_id, user_id)` is the synchronous fast path for inbound
    filtering — it reads the latest cached rules without I/O.
    """

    def __init__(self, config_path: Path, *, poll_interval: float = 1.0):
        self._path = config_path
        self._poll_interval = poll_interval
        self._rules = AccessRules()
        self._rate_limit = RateLimitConfig()
        self._mtime: float = 0.0
        self._task: asyncio.Task | None = None
        self._lock = asyncio.Lock()
        # Optional callback fired when rate-limit config changes during a
        # hot-reload. The orchestrator uses this to update its RateLimiter
        # in place — same hot-reload tick as the access list.
        self._on_rate_limit_change = None  # type: ignore

    @property
    def rules(self) -> AccessRules:
        return self._rules

    @property
    def rate_limit(self) -> RateLimitConfig:
        return self._rate_limit

    def on_rate_limit_change(self, cb) -> None:
        """Register a callback invoked whenever the rate-limit block in the
        config file changes. Cb signature: `(RateLimitConfig) -> None`."""
        self._on_rate_limit_change = cb

    def allows(self, chat_id: int, user_id: int, *,
               is_mentioned: bool = False) -> bool:
        return self._rules.allows(chat_id, user_id, is_mentioned=is_mentioned)

    def is_silent(self, chat_id: int) -> bool:
        return self._rules.is_silent(chat_id)

    async def start(self) -> None:
        await self._reload(initial=True)
        self._task = asyncio.create_task(self._watch_loop(), name="access-watch")

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass

    async def _watch_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self._poll_interval)
                try:
                    await self._reload()
                except Exception as e:
                    log.warning("access reload failed: %r", e)
        except asyncio.CancelledError:
            pass

    async def _reload(self, *, initial: bool = False) -> None:
        try:
            stat = self._path.stat()
        except FileNotFoundError:
            if initial:
                raise
            return
        if stat.st_mtime == self._mtime:
            return
        async with self._lock:
            with open(self._path, "rt") as f:
                data = yaml.safe_load(f) or {}
            new_rules = parse_rules(data.get("access"))
            new_rate = parse_rate_limit(data.get("access"))
            old_rate = self._rate_limit
            self._rules = new_rules
            self._rate_limit = new_rate
            self._mtime = stat.st_mtime
            if not initial:
                log.info(
                    "access reloaded: %d users, %d groups, rate(chat=%d/u=%d window=%.0fs)",
                    len(new_rules.users), len(new_rules.groups),
                    new_rate.chat_per_minute, new_rate.user_per_minute,
                    new_rate.window_seconds,
                )
            # Fire the callback whenever the rate-limit config differs from
            # the prior value — including the initial load, so the
            # orchestrator doesn't have to remember to push the value
            # itself after `start()`.
            if new_rate != old_rate and self._on_rate_limit_change is not None:
                try:
                    self._on_rate_limit_change(new_rate)
                except Exception as e:
                    log.warning("rate-limit reload callback failed: %r", e)
