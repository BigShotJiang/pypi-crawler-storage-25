"""waggle v0.3 — stream-json orchestrator.

waggle owns the runtime loop. claude-code runs as a long-lived subprocess
in `--print --input-format stream-json --output-format stream-json` mode;
each Telegram inbound becomes a user JSON event written to claude's stdin,
and each `result` event read from claude's stdout becomes a Telegram reply.

Why this architecture (vs MCP-channels):

  • The MCP `claude/channel` capability that would let an MCP server push
    inbound messages into the agent's context is gated by Anthropic
    server-side and not currently available on third-party-gateway tokens.
    The community confirms this is not yet implemented (anthropics/claude-code#36665).
  • The stream-json subprocess pattern is the de-facto workaround used by
    ductor and other orchestrators. It needs no special server-side feature
    flag, preserves unified context within a single subprocess, and lets us
    keep MCP for outbound tools (which DO work without channels gating).

Per-pod single subprocess. Inbound from the **same chat** is folded into
the running turn (mid-turn inject — claude reads new user events from
stdin between agentic-loop rounds and acknowledges them in the next
inference). Inbound from a **different chat** waits for the current
turn to end so contexts don't bleed across users.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .access import AccessControl
from .channel_tag import ChannelTag
from .config import Config, load as load_config
from .events import AcceptEvent, EventSink, RejectEvent, build_sink
from .owner_ops import NotifyContext, OwnerState, maybe_handle_owner, notify_owner
from .rate_limit import RateLimiter
from .hook_receiver import HookReceiver
from .status_indicator import StatusIndicator
from .typing_indicator import TypingIndicator

log = logging.getLogger(__name__)


class StreamClaude:
    """Long-lived `claude -p` subprocess driven over stream-json stdio.

    Lifecycle: `start()` → `send_user(text)` × N → `read_result()` × N → `stop()`.
    Each `read_result()` returns the final reply text for the most recent
    `send_user()`. claude emits a `result` event at the end of every turn.
    """

    def __init__(
        self,
        *,
        executable: str = "claude",
        session_id: str | None = None,
        continue_session: bool = True,
        extra_args: list[str] | None = None,
        cwd: str | None = None,
    ):
        resolved = shutil.which(executable)
        if resolved is None and not os.path.isabs(executable):
            raise FileNotFoundError(f"claude binary not found on PATH: {executable!r}")
        self.executable = resolved or executable
        # `--continue` resumes the most recent session in `cwd`. On a fresh
        # PVC there is no session yet — claude creates one and `--continue`
        # is a no-op for the first turn. On pod restart the conversation
        # picks up where it left off, which is the unified-context invariant
        # the runtime needs across crashes.
        # `session_id` is still supported for tests / pinning a specific
        # session — when set, it takes precedence over `--continue`.
        self.session_id = session_id
        self.continue_session = continue_session and session_id is None
        self.extra_args = list(extra_args or [])
        self.cwd = cwd
        self._proc: asyncio.subprocess.Process | None = None

    async def start(self) -> None:
        cmd = [self.executable]
        if os.environ.get("WAGGLE_CLAUDE_PRINT", "1") == "1":
            cmd.append("-p")
        cmd.extend([
            "--input-format", "stream-json",
            "--output-format", "stream-json",
            "--verbose",
        ])
        if self.session_id:
            cmd.extend(["--session-id", self.session_id])
        elif self.continue_session:
            cmd.append("--continue")
        cmd.extend(self.extra_args)
        log.info(
            "spawning claude session=%s continue=%s",
            self.session_id or "(new)", self.continue_session,
        )
        # asyncio.StreamReader's default line buffer is 64 KB; claude
        # stream-json emits a single line per event and tool_result events
        # routinely blow past that (browser_snapshot HTML, screenshot
        # base64, big Read-tool dumps). Without a larger limit, readline()
        # raises LimitOverrunError and the reader loop dies — the bot
        # appears to "lose" the agent. 16 MB covers everything we've seen
        # in production and still bounds memory if claude went rogue.
        self._proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.cwd,
            limit=16 * 1024 * 1024,
        )

    async def stop(self) -> None:
        if self._proc is None:
            return
        try:
            if self._proc.stdin and not self._proc.stdin.is_closing():
                self._proc.stdin.close()
            await asyncio.wait_for(self._proc.wait(), timeout=5)
        except asyncio.TimeoutError:
            self._proc.kill()
            await self._proc.wait()
        self._proc = None

    async def send_user(self, content: str) -> None:
        if self._proc is None or self._proc.stdin is None:
            raise RuntimeError("claude subprocess not started")
        event = {
            "type": "user",
            "message": {"role": "user", "content": content},
        }
        line = (json.dumps(event, ensure_ascii=False) + "\n").encode("utf-8")
        self._proc.stdin.write(line)
        await self._proc.stdin.drain()

    async def read_result(self) -> tuple[str, bool]:
        """Read stream-json events until a `result` event arrives.

        Returns (reply_text, is_error)."""
        async for kind, event in self.read_events():
            if kind == "result":
                return str(event.get("result") or ""), bool(event.get("is_error"))
        return "", True

    async def read_events(self):
        """Yield (kind, event_dict) tuples until subprocess closes stdout
        or a `result` event has been seen.

        Used by the working-status indicator to react to intermediate states
        (assistant chunks, tool_use, tool_result) before the turn ends.
        """
        if self._proc is None or self._proc.stdout is None:
            raise RuntimeError("claude subprocess not started")
        while True:
            line = await self._proc.stdout.readline()
            if not line:
                return
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = event.get("type")
            yield kind, event
            if kind == "result":
                return


class WaggleOrchestrator:
    def __init__(self, config: Config, config_path: Path):
        self.config = config
        self.access = AccessControl(config_path)
        # P6: prefer the structured `events.sink` block when set, fall back
        # to the legacy P1 `events.reject_sink` string for back-compat.
        self.events: EventSink = build_sink(
            config.events.sink if config.events.sink is not None
            else config.events.reject_sink
        )
        # Telegram client — same as the v0.2 client, but it now pushes into
        # `submit_inbound` instead of an MCP queue.
        self.telegram = None  # bound by main() before run()
        self.claude = StreamClaude(
            session_id=os.environ.get("WAGGLE_CLAUDE_SESSION_ID"),
            extra_args=self._claude_extra_args(),
            cwd=os.environ.get("WAGGLE_WORKSPACE", "/home/node/workspace"),
        )
        # Mid-turn inject machinery (replaces the old single turn_lock).
        # See module docstring for the high-level model. Three pieces:
        #   • _stdin_lock — serialise concurrent stdin writes (claude reads
        #     newline-delimited JSON, two interleaved writes would corrupt
        #     a frame).
        #   • _claim_cv — claim/fold/release the "active chat" slot. New
        #     inbound from the active chat folds in (push and continue);
        #     new inbound from another chat waits on this CV.
        #   • _turn_done — fired by the reader task when claude emits a
        #     `result` event. All folded waiters return at once.
        self._stdin_lock = asyncio.Lock()
        self._claim_cv = asyncio.Condition()
        self._active_chat: int | None = None
        self._turn_done = asyncio.Event()
        self._turn_done.set()  # no turn in progress at startup
        # Tool-seen flag is per-turn state owned by the reader task —
        # decides "🤔 Thinking" vs "📝 Writing" labels.
        self._saw_tool = False
        # Reader task — long-running, started in run(), drives indicator
        # state changes and fires _turn_done on result events.
        self._reader_task: asyncio.Task | None = None
        # Status indicator built fresh on first inbound (telegram client
        # is bound after construction).
        self._status: StatusIndicator | None = None
        # Typing indicator (P8) — also constructed lazily on first turn.
        self._typing: TypingIndicator | None = None
        # Owner-side state: pause flag, last-activity, pending destructive op.
        self.owner_state = OwnerState()
        # Rate limiter — hot-reloads alongside access list (same config file).
        self.rate_limiter = RateLimiter(self.access.rate_limit)
        self.access.on_rate_limit_change(self.rate_limiter.update_config)
        # Hook receiver — listens on localhost:8091 for Claude Code hook events.
        hook_port = int(os.environ.get("WAGGLE_HOOK_PORT", "8091"))
        self._hook_receiver = HookReceiver(port=hook_port)

    def _claude_extra_args(self) -> list[str]:
        """Built-in defaults plus any operator overrides from env.

        Outbound delivery is via MCP tool calls, NOT by parsing claude's
        stdout text. We point claude at our `tools_server` MCP via
        --mcp-config.

        Permissions:
          • bypass (default) → --dangerously-skip-permissions; claude runs
            every tool without asking. Container boundary is the trust line.
          • claude_files → --permission-prompt-tool; the tools_server-side
            handler auto-allows everything EXCEPT Edit/Write/MultiEdit/
            NotebookEdit on a path containing "claude" — those route to
            Telegram for owner approval.
          • strict → same plumbing, but the handler asks for every tool_use
            (slow; for admin bots).
        """
        args = [
            "--strict-mcp-config",
            "--mcp-config", os.environ.get("WAGGLE_MCP_CONFIG", "/etc/waggle/mcp.json"),
        ]
        mode = self.config.agent.permission_mode
        if mode == "bypass":
            args.append("--dangerously-skip-permissions")
        else:
            # The MCP tool name claude calls. Has to match the schema in
            # tools_server.py. Also forward the mode so tools_server's
            # _should_ask honors it.
            os.environ["WAGGLE_PERMISSION_MODE"] = mode
            args.extend([
                "--permission-prompt-tool", "mcp__waggle-tools__request_permission",
            ])
        args.extend(["--append-system-prompt", _BRIDGE_PROMPT])
        # Forward the operator's chosen model. Without --model, claude
        # falls back to its baseline default which (verified live) emits
        # empty thinking blocks even on reasoning-heavy prompts. Setting
        # `--model sonnet` (or opus/haiku) makes the model produce real
        # extended-thinking content, which is what the Show-thinking
        # button surfaces.
        model = os.environ.get("CLAUDE_MODEL", "").strip()
        if model:
            args.extend(["--model", model])
        # Optional reasoning-effort knob (low/medium/high/xhigh/max).
        # Bots that want richer reasoning per turn can crank it.
        effort = os.environ.get("CLAUDE_EFFORT", "").strip()
        if effort:
            args.extend(["--effort", effort])
        extra = os.environ.get("WAGGLE_CLAUDE_EXTRA_ARGS", "").strip()
        if extra:
            args.extend(extra.split())
        return args

    # ---- Public API ----

    async def submit_external(
        self,
        *,
        chat_id: int,
        prompt: str,
        source_label: str = "external",
        silent: bool = False,
    ) -> None:
        """An external trigger (P3 /inject endpoint) is pushing a prompt into
        the agent. Bypasses the per-user allow-list because the endpoint's
        bearer check is the gate. Posts the result via claude's MCP `reply`
        tool the same way a user-driven turn does.

        `silent=True` suppresses the per-turn rolling status indicator
        ("🤔 Thinking…" / "🔧 Tool: …" / "📝 Writing reply…") so
        high-volume automated triggers don't spam the chat with status
        surfaces — only the agent's final reply is sent. The unobtrusive
        "bot is typing…" header keeps running so users still see liveness.
        """
        tag = ChannelTag.now(source=source_label, chat=chat_id, user="external")
        wrapped = tag.render(prompt)
        log.info(
            "↪ external chat=%s silent=%s: %s",
            chat_id, silent, prompt.replace("\n", " ")[:120],
        )
        await self._claim_and_push(chat_id=chat_id, message_id=None,
                                    wrapped=wrapped, silent=silent)

    async def _claim_and_push(
        self,
        *,
        chat_id: int,
        message_id: str | None,
        wrapped: str,
        silent: bool = False,
    ) -> None:
        """Claim or fold the active-chat slot, push the user event into
        claude, then wait for the active turn to finish.

        Three observable paths:
          1. No turn in flight → claim, attach indicator/typing, push,
             wait. Reader fires _turn_done on `result`.
          2. Turn in flight, **same chat** → fold: don't re-attach
             indicator (it's still up), push another user event (claude
             merges it into the running turn between agentic rounds), wait
             on the same _turn_done event.
          3. Turn in flight, **different chat** → wait on _claim_cv until
             the running turn ends, then go via path 1.
        """
        # Lazy-start the reader task. run() also starts it eagerly, but
        # tests drive submit_inbound directly without run() — make sure
        # the reader is alive whenever a turn could be claimed.
        if self._reader_task is None or self._reader_task.done():
            self._reader_task = asyncio.create_task(self._reader_loop())

        # Phase 1: claim (or fold) under the condition variable.
        async with self._claim_cv:
            while self._active_chat is not None and self._active_chat != chat_id:
                await self._claim_cv.wait()

            first_in_turn = self._active_chat is None
            if first_in_turn:
                self._active_chat = chat_id
                self._turn_done = asyncio.Event()
                self._saw_tool = False
                # Set up the typing-action poller every turn — even silent
                # ones. Telegram's "bot is typing…" header is unobtrusive
                # (no message in the thread) and useful for the user to
                # know the bot is alive. `silent` only suppresses the
                # rolling status SURFACE in the message thread.
                if self._typing is None and self.telegram is not None:
                    self._typing = TypingIndicator(self.telegram)
                if self._typing is not None:
                    await self._typing.attach(chat_id)
                # Status indicator (rolling 🤔 Thinking… message + Show
                # buttons) is the noisy surface. Skipped for silent turns
                # — high-volume /inject automation, multi-bot groups
                # where the indicator would re-trigger sibling bots, etc.
                if not silent:
                    if self._status is None and self.telegram is not None:
                        self._status = StatusIndicator(self.telegram)
                        self._hook_receiver.bind_status(self._status)
                    if self._status is not None:
                        await self._status.attach(chat_id, reply_to=message_id)
            # Snapshot the done event so all folded waiters share the
            # same one — when the reader fires it, they all return.
            my_turn_done = self._turn_done

        # Phase 2: push the user event. stdin_lock keeps two concurrent
        # writes from interleaving JSON frames.
        async with self._stdin_lock:
            await self.claude.send_user(wrapped)

        # Phase 3: wait for the active turn to end. Folded waiters all
        # release on the same result event.
        await my_turn_done.wait()

    async def _reader_loop(self) -> None:
        """Long-running reader. Drives indicator state from claude's
        stream-json events and fires _turn_done on each `result` event.

        Restarts read_events() in a loop because the helper exits on
        result; the next iteration handles the next turn's events.
        Survives subprocess respawn by checking _proc each iteration.

        Cooperative yield (asyncio.sleep(0)) at the top of each iteration
        guards against a tight no-await loop when the underlying claude
        stub or buffered stdout returns events without ever blocking on
        I/O — without it, the reader would starve other tasks.
        """
        while True:
            try:
                await asyncio.sleep(0)
                async for kind, event in self.claude.read_events():
                    chat_id = self._active_chat
                    indicator = self._status
                    typing = self._typing

                    if kind == "assistant" and indicator is not None and chat_id is not None:
                        # Buffer non-empty thinking blocks for the
                        # "🧠 Show thinking" view. Tool args and pre-reply
                        # text chunks are intentionally excluded — anh
                        # only wants the agent's reasoning, not a debug
                        # log of every tool call.
                        for thought in _extract_thinking(event):
                            indicator.append_thinking(chat_id, thought)
                        # Snapshot any TodoWrite tool_use so the user can
                        # tap "✅ Show tasks" and see the agent's current
                        # planned/done/in-progress items.
                        todos = _extract_tasklist(event)
                        if todos is not None:
                            indicator.update_tasklist(chat_id, todos)
                        # tool_use blocks live inside the assistant event's
                        # content list (not a separate event kind).
                        tool_name = _extract_tool_name(event)
                        if tool_name:
                            self._saw_tool = True
                            await indicator.set_state(
                                f"🔧 Tool: {_pretty_tool_name(tool_name)}"
                            )
                        else:
                            label = (
                                StatusIndicator.LABEL_WRITING if self._saw_tool
                                else StatusIndicator.LABEL_THINKING
                            )
                            await indicator.set_state(label)
                    elif kind == "result":
                        result_text = str(event.get("result") or "")
                        is_error = bool(event.get("is_error"))
                        log.info(
                            "← chat=%s is_error=%s: %s",
                            chat_id, is_error,
                            result_text.replace("\n", " ")[:160],
                        )
                        if indicator is not None and chat_id is not None:
                            if is_error:
                                await indicator.error(result_text or "agent error")
                            else:
                                await indicator.success()
                        if typing is not None and chat_id is not None:
                            await typing.detach(chat_id)
                        self.owner_state.turn_count += 1

                        # Release the active chat — folded waiters return,
                        # other-chat waiters can claim.
                        self._hook_receiver.reset_tasks()
                        async with self._claim_cv:
                            self._active_chat = None
                            self._turn_done.set()
                            self._claim_cv.notify_all()
                        self._saw_tool = False

                        await self._respawn_if_dead()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.exception("reader loop iteration crashed: %r", e)
                # Avoid a tight crash loop. If claude is dead,
                # _respawn_if_dead on the next pass will revive it.
                await asyncio.sleep(1)

    async def _respawn_if_dead(self) -> None:
        """If claude exited mid-turn or between turns, respawn and ping owner.

        This is a §1.8 proactive notification: the operator should know when
        the agent has been restarted, because conversation context picks up
        from `--continue` but transient state inside that session (e.g. an
        unfinished tool call) may have been lost.
        """
        proc = getattr(self.claude, "_proc", None)
        if proc is None or proc.returncode is None:
            return
        rc = proc.returncode
        log.warning("claude subprocess exited rc=%s — respawning", rc)
        ctx = self._notify_ctx()
        try:
            await self.claude.start()
            ok = True
        except Exception as e:
            log.exception("claude respawn failed: %r", e)
            ok = False
        if ctx is not None:
            if ok:
                await notify_owner(
                    ctx,
                    f"agent restarted (rc={rc})",
                    why="subprocess exited between turns",
                    todo="re-send the last message if you didn't get a reply",
                )
            else:
                await notify_owner(
                    ctx,
                    "agent respawn FAILED",
                    why=f"subprocess exited rc={rc} and could not be restarted",
                    todo="check pod logs and consider /restart manually",
                )

    def _notify_ctx(self) -> NotifyContext | None:
        if self.telegram is None:
            return None
        return NotifyContext(telegram=self.telegram, owner_chat=self.config.owner.user_id)

    async def submit_inbound(
        self,
        *,
        chat_id: int,
        user_id: int,
        username: str,
        message_id: str,
        text: str,
        attachments: tuple[dict, ...] = (),
        ts: datetime | None = None,
        is_mentioned: bool = False,
        reply_to: dict | None = None,
        # v2 channel-tag enrichment — all optional, omitted from the rendered
        # tag when absent so v1 prompts stay byte-identical.
        first_name: str = "",
        last_name: str = "",
        is_premium: bool | None = None,
        chat_type: str = "",
        chat_title: str = "",
        message_thread_id: str = "",
        is_topic_message: bool | None = None,
    ) -> None:
        """Called by the Telegram client when an allow-listed message arrives."""
        # Owner-ops gate runs before access-list (the configured owner is
        # always implicitly allowed for /status, /pause, etc.). Owner ops
        # consume the inbound so it never reaches claude.
        if await maybe_handle_owner(self, chat_id=chat_id, user_id=user_id, text=text):
            return
        # Pause flag — set by /pause owner command. Drops new inbound silently
        # for non-owner users (owner can /resume to restore).
        if self.owner_state.paused:
            return
        # Track last activity for /status.
        self.owner_state.last_inbound_ts = datetime.now(timezone.utc).timestamp()
        self.owner_state.last_inbound_chat = chat_id
        self.owner_state.last_inbound_preview = text.replace("\n", " ")[:80]
        # Slash commands in groups are rejected outright (operator surface
        # is DM-only). Stops a chatty group from spending claude turns on
        # `/something`-prefixed messages and stops state leak in case of
        # any future owner-op handler that forgets the DM-only check.
        if chat_id < 0 and (text or "").lstrip().startswith("/"):
            await self.events.emit_reject(
                RejectEvent(
                    reason="command-in-group",
                    source="telegram",
                    chat=str(chat_id),
                    user=str(user_id),
                    text_preview=(text or "")[:80],
                    ts=datetime.now(timezone.utc),
                )
            )
            return

        if not self.access.allows(chat_id, user_id, is_mentioned=is_mentioned):
            reason = "not-allowlisted" if chat_id >= 0 else "group-not-allowlisted"
            await self.events.emit_reject(
                RejectEvent(
                    reason=reason,
                    source="telegram",
                    chat=str(chat_id),
                    user=str(user_id),
                    text_preview=(text or "")[:80],
                    ts=datetime.now(timezone.utc),
                )
            )
            return

        # P8 rate-limit gate. Sliding window per-chat AND per-user; either
        # dimension being over budget rejects. Owner is exempt — operators
        # need to be able to /pause / /status during a flood.
        if user_id != self.config.owner.user_id:
            decision = self.rate_limiter.check(chat_id=chat_id, user_id=user_id)
            if not decision.allow:
                reason = (
                    "rate-limited-chat" if decision.scope == "chat"
                    else "rate-limited-user"
                )
                log.info(
                    "rate-limit drop scope=%s used=%d/%d retry_after=%.1fs chat=%s user=%s",
                    decision.scope, decision.used, decision.limit,
                    decision.retry_after, chat_id, user_id,
                )
                await self.events.emit_reject(
                    RejectEvent(
                        reason=reason,
                        source="telegram",
                        chat=str(chat_id),
                        user=str(user_id),
                        text_preview=(text or "")[:80],
                        ts=datetime.now(timezone.utc),
                    )
                )
                return

        # P6: persist every accepted inbound to the external sink before the
        # turn starts. Sink is fail-soft (errors logged, never propagated)
        # so a dashboard outage does not block claude.
        accept_ts = ts if ts is not None else datetime.now(timezone.utc)
        await self.events.emit_accept(
            AcceptEvent(
                source="telegram",
                chat=str(chat_id),
                user=str(user_id),
                username=username,
                message_id=str(message_id),
                body=text or "",
                attachments=tuple(attachments),
                ts=accept_ts,
            )
        )

        # Channel-tag uses the original Telegram send-time when the
        # transport supplies one, falling back to now() otherwise.
        tag_kwargs = dict(
            username=username,
            first_name=first_name,
            last_name=last_name,
            is_premium=is_premium,
            chat_type=chat_type,
            chat_title=chat_title,
            message_thread_id=message_thread_id,
            is_topic_message=is_topic_message,
        )
        if ts is not None:
            tag = ChannelTag.at(source="telegram", chat=chat_id, user=user_id, ts=ts,
                                message_id=message_id, **tag_kwargs)
        else:
            tag = ChannelTag.now(source="telegram", chat=chat_id, user=user_id,
                                 message_id=message_id, **tag_kwargs)
        wrapped = tag.render(text, attachments=attachments, reply_to=reply_to)

        # Mid-turn inject (see module docstring + _claim_and_push). Inbound
        # from the same chat as the active turn is folded in — claude sees
        # the new user event between agentic-loop rounds and merges it into
        # the running response. Inbound from a different chat waits.
        # Outbound delivery happens via the MCP `reply` tool call inside the
        # turn — we don't read claude's `result` text and forward it; the
        # tool implementation in tools_server.py talks to Telegram directly.
        preview_in = text.replace("\n", " ")[:120]
        # `silent` groups suppress the rolling status indicator and typing
        # action — only the agent's final reply lands in the chat.
        silent = self.access.is_silent(chat_id)
        log.info("→ chat=%s user=%s silent=%s: %s",
                 chat_id, user_id, silent, preview_in)
        await self._claim_and_push(chat_id=chat_id, message_id=message_id,
                                    wrapped=wrapped, silent=silent)

    # ---- Run loop ----

    async def run(self) -> None:
        await self.access.start()
        await self.claude.start()
        # Start the long-running reader BEFORE telegram begins polling so
        # the very first inbound's events are processed.
        self._reader_task = asyncio.create_task(self._reader_loop())

        # Hook receiver — internal endpoint for Claude Code hooks
        # (PreToolUse, PostToolUse, Stop, TaskCreated, TaskCompleted,
        # PreCompact, PostCompact).
        self._hook_receiver.bind_telegram(self.telegram, self.config.owner.user_id)
        await self._hook_receiver.start()

        # Optionally bring up the /inject HTTP endpoint (§1.4 / P3).
        inject_server = None
        if self.config.inject.enabled:
            from .inject import InjectServer
            inject_server = InjectServer(
                bind=self.config.inject.bind,
                shared_secret=self.config.inject.shared_secret,
                default_chat_id=self.config.inject.default_chat_id,
                orchestrator=self,
            )
            await inject_server.start()

        try:
            if self.telegram is None:
                raise RuntimeError("telegram client not bound")
            await self.telegram.run(self)
        finally:
            await self._hook_receiver.stop()
            if inject_server is not None:
                await inject_server.stop()
            if self._reader_task is not None:
                self._reader_task.cancel()
                try:
                    await self._reader_task
                except asyncio.CancelledError:
                    pass
                self._reader_task = None
            await self.claude.stop()
            await self.access.stop()
            await self.events.aclose()


def _extract_thinking(event: dict) -> list[str]:
    """Return all `thinking` content blocks' text from a stream-json
    assistant event. Empty list if none.

    Stream-json shape (extended thinking):
        {"type":"assistant","message":{"content":[
            {"type":"thinking","thinking":"...","signature":"..."},
            {"type":"text","text":"..."}
        ]}}
    """
    msg = event.get("message")
    if not isinstance(msg, dict):
        return []
    content = msg.get("content")
    if not isinstance(content, list):
        return []
    out: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "thinking":
            text = block.get("thinking")
            if isinstance(text, str) and text:
                out.append(text)
    return out


def _extract_transcript_entries(event: dict) -> list[str]:
    """Pull human-readable transcript lines from a stream-json assistant
    event. Returns one rendered string per content block, in order:

      • thinking block with text  → "🧠 …"
      • text block                → "💬 …"
      • tool_use block            → "🔧 ToolName(args_preview)"

    Empty thinking blocks are skipped (claude emits placeholder thinking
    blocks with empty text in some configurations — they have no value
    to the user).
    """
    msg = event.get("message")
    if not isinstance(msg, dict):
        return []
    content = msg.get("content")
    if not isinstance(content, list):
        return []
    out: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        btype = block.get("type")
        if btype == "thinking":
            text = block.get("thinking")
            if isinstance(text, str) and text.strip():
                out.append(f"🧠 {text}")
        elif btype == "text":
            text = block.get("text")
            if isinstance(text, str) and text.strip():
                out.append(f"💬 {text}")
        elif btype == "tool_use":
            name = block.get("name") or "?"
            inp = block.get("input")
            args_preview = ""
            if isinstance(inp, dict) and inp:
                # Render a short JSON-ish preview so the user can see
                # what claude was doing — full args may be huge (e.g.
                # Edit's old_string/new_string), so truncate aggressively.
                import json as _json
                try:
                    args_preview = _json.dumps(inp, ensure_ascii=False)
                except Exception:
                    args_preview = str(inp)
                if len(args_preview) > 240:
                    args_preview = args_preview[:240] + "…"
            out.append(f"🔧 {_pretty_tool_name(name)}({args_preview})")
    return out


def _pretty_tool_name(raw: str) -> str:
    """Strip the `mcp__<server>__` prefix that claude prepends to MCP tool
    names so the indicator shows `reply` instead of
    `mcp__waggle-tools__reply`. Built-in tools (Bash, Read, …) pass through
    unchanged."""
    if raw.startswith("mcp__"):
        # mcp__waggle-tools__reply → reply
        rest = raw[len("mcp__"):]
        _server, _, name = rest.partition("__")
        if name:
            return name
    return raw


def _extract_tasklist(event: dict) -> list[dict] | None:
    """Pull the latest TodoWrite snapshot out of an assistant event.

    Claude Code's `TodoWrite` tool input shape:
        {"todos": [
            {"content": "...", "status": "pending|in_progress|completed",
             "activeForm": "..."},
            ...
        ]}

    Returns None when this assistant event has no TodoWrite tool_use.
    Returns the (possibly empty) todos list when one is present — the
    caller treats that snapshot as the authoritative current state.
    """
    msg = event.get("message")
    if not isinstance(msg, dict):
        return None
    content = msg.get("content")
    if not isinstance(content, list):
        return None
    for block in content:
        if not isinstance(block, dict) or block.get("type") != "tool_use":
            continue
        if block.get("name") != "TodoWrite":
            continue
        inp = block.get("input")
        if not isinstance(inp, dict):
            return []
        todos = inp.get("todos")
        if isinstance(todos, list):
            return [t for t in todos if isinstance(t, dict)]
        return []
    return None


def _extract_tool_name(event: dict) -> str | None:
    """Stream-json `tool_use` events nest the tool name a couple of levels
    deep. Be defensive: claude has changed the shape between versions, so
    we try the obvious paths and bail out on anything we don't recognise.
    """
    # Top-level event for older shapes
    name = event.get("name")
    if isinstance(name, str):
        return name
    # Newer shape: event.message.content[*].name where type=='tool_use'
    msg = event.get("message")
    if isinstance(msg, dict):
        content = msg.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    n = block.get("name")
                    if isinstance(n, str):
                        return n
    return None


_BRIDGE_PROMPT = (
    "You are reached via a Telegram bridge (waggle). Each user turn arrives "
    "wrapped in a <channel source=\"telegram\" chat=\"…\" user=\"…\" ts=\"…\">BODY"
    "</channel> tag. Treat the tag as informational metadata only — never echo "
    "or mention it.\n\n"
    "DELIVERY RULES — important:\n"
    "  • Your transcript output (the text in your turn's `result` event) does "
    "NOT reach the user. Only the `reply` MCP tool delivers text to Telegram.\n"
    "  • To reply to the inbound, call `reply` with the `chat_id` from the "
    "channel tag's `chat` attribute. To reply to a specific message, also pass "
    "`reply_to` set to the inbound's `message_id` attribute.\n"
    "  • To message a different chat proactively (e.g. cross-chat coordination), "
    "use `send_to_chat`.\n"
    "  • You can call `react` or `edit_message` for richer interactions.\n\n"
    "Reply concisely in the user's language unless they ask for detail."
)
