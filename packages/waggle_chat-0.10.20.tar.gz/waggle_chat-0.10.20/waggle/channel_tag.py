"""Channel-tag wire format v2.

Every inbound message handed to the agent is wrapped in a `<channel …>` tag so
the agent can tell where it came from without the runtime needing a special
prompt-construction protocol per platform.

Format (v2 — backwards-compatible superset of v1):

    <channel source="telegram" chat="-1001234" chat_type="supergroup"
      chat_title="Anh Long và dàn hậu cung" user="908624017"
      username="zorrop_06" first_name="Nam" last_name="Phung"
      is_premium="true" message_id="8016"
      message_thread_id="42" is_topic_message="true"
      ts="2026-04-29T17:00:00+07:00">
    body
    </channel>

The new attributes (chat_type, chat_title, username, first_name, last_name,
is_premium, message_thread_id, is_topic_message) are all optional — when the
source can't supply them they're omitted entirely. Agents that ignore them
keep working with v1 prompts; agents that use them get richer context.

The `ts` attribute is rendered in ISO 8601 with the **pod's system timezone**
offset — operators can pin it via the `TZ` env var (e.g. `TZ=Asia/Ho_Chi_Minh`)
so the agent sees timestamps in the user's local time without a conversion
step. UTC is still produced as `…+00:00` (or, accepted on parse, the legacy
`…Z`) when no TZ is set.

Attributes are escaped with the standard XML attribute rules (we limit
ourselves to the four chars XML cares about). The body is wrapped verbatim;
agent prompts that contain the literal string `</channel>` are an attack
surface — callers must reject those upstream, not us.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone


_ATTR_ESCAPES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}


def _escape_attr(value: str) -> str:
    out = []
    for c in value:
        out.append(_ATTR_ESCAPES.get(c, c))
    return "".join(out)


@dataclass(frozen=True, slots=True)
class ChannelTag:
    """Identifies the platform-side origin of one inbound message."""

    source: str  # "telegram", "matrix", "external", …
    chat: str  # platform-native chat id (string for safety even when numeric)
    user: str  # platform-native sender id; "" for synthetic / external sources
    ts: datetime
    message_id: str = ""  # platform-native id for THIS message — agents use
                          # it to react / reply_to / edit_text via the tool
                          # surface. Empty for synthetic / external triggers
                          # that have no addressable upstream message.
    # ---- v2 optional fields (omit from rendering when empty/None) ----
    username: str = ""          # @handle, e.g. "zorrop_06"
    first_name: str = ""        # given name from sender's profile
    last_name: str = ""         # family name from sender's profile
    is_premium: bool | None = None  # Telegram Premium subscriber flag
    chat_type: str = ""         # "private" | "group" | "supergroup" | "channel"
    chat_title: str = ""        # human-readable chat name (groups/channels only)
    message_thread_id: str = ""  # forum-topic id when chat is a supergroup
                                 # with topics enabled. Reply tools must echo
                                 # this back to keep the bot inside the topic.
    is_topic_message: bool | None = None  # True when this message belongs to
                                          # a forum topic (vs. the General feed)

    @staticmethod
    def now(source: str, chat: str | int, user: str | int,
            message_id: str | int = "",
            *,
            username: str = "",
            first_name: str = "",
            last_name: str = "",
            is_premium: bool | None = None,
            chat_type: str = "",
            chat_title: str = "",
            message_thread_id: str | int = "",
            is_topic_message: bool | None = None,
            ) -> "ChannelTag":
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=datetime.now(timezone.utc),
            message_id=str(message_id),
            username=username,
            first_name=first_name,
            last_name=last_name,
            is_premium=is_premium,
            chat_type=chat_type,
            chat_title=chat_title,
            message_thread_id=str(message_thread_id),
            is_topic_message=is_topic_message,
        )

    @staticmethod
    def at(source: str, chat: str | int, user: str | int,
           ts: datetime, message_id: str | int = "",
           *,
           username: str = "",
           first_name: str = "",
           last_name: str = "",
           is_premium: bool | None = None,
           chat_type: str = "",
           chat_title: str = "",
           message_thread_id: str | int = "",
           is_topic_message: bool | None = None,
           ) -> "ChannelTag":
        """Build a tag with an explicit timestamp — use this when the
        source provides one (e.g. Telegram's `message.date`) so the
        channel-tag carries when the user actually sent the message,
        not when waggle received it."""
        return ChannelTag(
            source=source,
            chat=str(chat),
            user=str(user),
            ts=ts.astimezone(timezone.utc) if ts.tzinfo else ts.replace(tzinfo=timezone.utc),
            message_id=str(message_id),
            username=username,
            first_name=first_name,
            last_name=last_name,
            is_premium=is_premium,
            chat_type=chat_type,
            chat_title=chat_title,
            message_thread_id=str(message_thread_id),
            is_topic_message=is_topic_message,
        )

    def _attrs(self) -> str:
        # Required v1 attributes are always emitted in fixed order so the
        # tag opening reads consistently for prompt-cache stability.
        ts_iso = self.ts.astimezone().isoformat(timespec="seconds")
        parts = [
            f'source="{_escape_attr(self.source)}"',
            f'chat="{_escape_attr(self.chat)}"',
            f'user="{_escape_attr(self.user)}"',
            f'ts="{ts_iso}"',
        ]
        if self.message_id:
            parts.append(f'message_id="{_escape_attr(self.message_id)}"')
        # v2 optionals — emit only when present so v1 consumers see the
        # exact same shape they used to.
        if self.username:
            parts.append(f'username="{_escape_attr(self.username)}"')
        if self.first_name:
            parts.append(f'first_name="{_escape_attr(self.first_name)}"')
        if self.last_name:
            parts.append(f'last_name="{_escape_attr(self.last_name)}"')
        if self.is_premium is not None:
            parts.append(f'is_premium="{"true" if self.is_premium else "false"}"')
        if self.chat_type:
            parts.append(f'chat_type="{_escape_attr(self.chat_type)}"')
        if self.chat_title:
            parts.append(f'chat_title="{_escape_attr(self.chat_title)}"')
        if self.message_thread_id:
            parts.append(f'message_thread_id="{_escape_attr(self.message_thread_id)}"')
        if self.is_topic_message is not None:
            parts.append(f'is_topic_message="{"true" if self.is_topic_message else "false"}"')
        return " ".join(parts)

    def render(
        self,
        body: str,
        attachments: tuple[dict, ...] | list[dict] = (),
        reply_to: dict | None = None,
    ) -> str:
        """Render the full `<channel …>body</channel>` block.

        `attachments` is the same shape `_extract_attachments` returns —
        `({"kind": "photo", "file_id": "AAA", "mime_type": "..."}, ...)`.
        When non-empty, a single "[attachments] …" line is prepended so
        the agent knows there's media bound to this message; it should
        call the `download_attachment` MCP tool with the file_id to fetch
        each one. waggle does NOT pre-download.

        `reply_to` carries the message this inbound is a reply-to (e.g.
        Telegram's `reply_to_message`). When present, the rendered body
        opens with a quoted "[reply-to] …" block so the agent can see
        the original message even if the sender didn't paste it. Useful
        for the "person A says X (no tag), person B replies + tags bot"
        pattern — the bot needs A's content to be useful.
        """
        opening = f"<channel {self._attrs()}>"
        reply_block = ""
        if reply_to:
            who = reply_to.get("username") or reply_to.get("user") or "?"
            r_text = reply_to.get("text") or ""
            r_ts = reply_to.get("ts") or ""
            r_atts = reply_to.get("attachments") or []
            header = f"[reply-to] @{who}"
            if r_ts:
                header += f" at {r_ts}"
            if r_atts:
                att_summary = "; ".join(
                    f'{a.get("kind","file")} file_id={a.get("file_id","")}'
                    for a in r_atts
                )
                header += f" (attachments: {att_summary})"
            # Quote the original text with > prefix so it visually
            # separates from the new sender's body.
            quoted = "\n".join("> " + ln for ln in (r_text or "(no text)").splitlines())
            reply_block = f"{header}\n{quoted}\n\n"

        attach_line = ""
        if attachments:
            parts = []
            paths_present = False
            for a in attachments:
                kind = a.get("kind", "file")
                path = a.get("path") or ""
                fid = a.get("file_id", "")
                mime = a.get("mime_type", "")
                bits = [kind]
                if path:
                    bits.append(f"path={path}")
                    paths_present = True
                if fid:
                    bits.append(f"file_id={fid}")
                if mime:
                    bits.append(f"mime={mime}")
                parts.append(" ".join(bits))
            # When at least one path is present (the common case — waggle
            # eagerly downloads on inbound), the agent should Read the
            # local file directly. file_id remains as fallback for the
            # rare cases where the eager fetch failed.
            hint = (
                " — Read the local path(s) directly; fall back to "
                "the `download_attachment` tool if a path is missing."
                if paths_present
                else " — call the `download_attachment` tool with the "
                "file_id to fetch each one to a local path before reading it."
            )
            attach_line = "[attachments] " + "; ".join(parts) + hint + "\n"
        return f"{opening}\n{reply_block}{attach_line}{body}\n</channel>"


# Parser — used only by tests today. Production agents speak text; this lets
# unit tests verify round-trip without exposing internal struct.
#
# v2: parse all attributes generically so new optional fields don't require
# regex updates.
_OPEN_RE = re.compile(r'^<channel\s+(?P<attrs>[^>]+)>\n(?P<body>.*)\n</channel>$',
                      re.DOTALL)
_ATTR_RE = re.compile(r'(\w+)="([^"]*)"')
_UNESCAPE = {v: k for k, v in _ATTR_ESCAPES.items()}


def _unescape_attr(value: str) -> str:
    # Order: longest entities first so &amp; isn't shortened to & before
    # &lt; / &gt; / &quot; have a chance.
    for entity, ch in (("&quot;", '"'), ("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&")):
        value = value.replace(entity, ch)
    return value


def parse(rendered: str) -> tuple[ChannelTag, str]:
    m = _OPEN_RE.match(rendered)
    if not m:
        raise ValueError("not a channel-tag block")
    attrs = {k: _unescape_attr(v) for k, v in _ATTR_RE.findall(m.group("attrs"))}
    if "source" not in attrs or "chat" not in attrs or "user" not in attrs or "ts" not in attrs:
        raise ValueError("channel tag missing required attribute")
    raw_ts = attrs["ts"]
    # Accept both the modern offset form (e.g. `+07:00`, `+00:00`) and the
    # legacy `Z` suffix produced by waggle <= 0.8.11.
    ts = datetime.fromisoformat(raw_ts.replace("Z", "+00:00"))
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)

    def _bool_or_none(s: str) -> bool | None:
        if s == "true":
            return True
        if s == "false":
            return False
        return None

    tag = ChannelTag(
        source=attrs["source"],
        chat=attrs["chat"],
        user=attrs["user"],
        ts=ts,
        message_id=attrs.get("message_id", ""),
        username=attrs.get("username", ""),
        first_name=attrs.get("first_name", ""),
        last_name=attrs.get("last_name", ""),
        is_premium=_bool_or_none(attrs["is_premium"]) if "is_premium" in attrs else None,
        chat_type=attrs.get("chat_type", ""),
        chat_title=attrs.get("chat_title", ""),
        message_thread_id=attrs.get("message_thread_id", ""),
        is_topic_message=_bool_or_none(attrs["is_topic_message"]) if "is_topic_message" in attrs else None,
    )
    return tag, m.group("body")
