"""waggle MCP tools server — outbound primitives for claude to call.

Loaded by claude via `--mcp-config` from the orchestrator's launcher. Runs
as claude's child process (claude is itself waggle's child — so this is
waggle's grandchild). One Bot instance per process — send-only, no
polling, so it doesn't conflict with the orchestrator's poller.

The server intentionally does NOT advertise the `claude/channel`
capability. We don't need it: inbound notifications go through claude's
stdin via the orchestrator, not through MCP.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import tempfile
import uuid
from contextlib import AsyncExitStack
from pathlib import Path
from typing import Any

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import (
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReactionTypeEmoji,
)
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.session import ServerSession
from mcp.server.stdio import stdio_server
import mcp.types as mt

log = logging.getLogger(__name__)


def _ok(msg: str) -> list[mt.TextContent]:
    return [mt.TextContent(type="text", text=msg)]


def _err(msg: str) -> list[mt.TextContent]:
    return [mt.TextContent(type="text", text=f"error: {msg}")]


# Where the parent waggle process and tools_server (claude's child) trade
# permission verdicts. Same pod → same /tmp filesystem → no real IPC stack
# needed. Files keyed by request_id; tools_server polls until present.
PERMISSION_DIR = os.environ.get(
    "WAGGLE_PERMISSION_DIR", "/tmp/waggle/permissions",
)


_TOOL_SCHEMAS: dict[str, tuple[str, dict]] = {
    "reply": (
        "Reply to a Telegram chat. Pass chat_id from the inbound channel tag's "
        "`chat` attribute. Use reply_to (a message_id) only when you want the "
        "reply threaded under a specific earlier message; for the most recent "
        "inbound it's optional. Set `spoiler: true` to hide the text behind a "
        "click-to-reveal spoiler (forces markdownv2 formatting). When the "
        "inbound channel tag has a `message_thread_id` attribute (forum-topic "
        "supergroup), echo that value back as `message_thread_id` so the reply "
        "lands in the same topic — omitting it posts to the General feed.",
        {
            "type": "object",
            "properties": {
                "chat_id":           {"type": "string"},
                "text":              {"type": "string"},
                "reply_to":          {"type": "string"},
                "format":            {"type": "string", "enum": ["text", "markdownv2"], "default": "text"},
                "spoiler":           {"type": "boolean", "default": False},
                "message_thread_id": {"type": "string"},
            },
            "required": ["chat_id", "text"],
        },
    ),
    "send_to_chat": (
        "Send a message proactively to a specific chat (no reply_to). Use this "
        "to start a thread or post into a chat without waiting for an inbound. "
        "`spoiler: true` hides the text behind click-to-reveal. Pass "
        "`message_thread_id` to target a specific forum topic in a "
        "supergroup with topics enabled.",
        {
            "type": "object",
            "properties": {
                "chat_id":           {"type": "string"},
                "text":              {"type": "string"},
                "format":            {"type": "string", "enum": ["text", "markdownv2"], "default": "text"},
                "spoiler":           {"type": "boolean", "default": False},
                "message_thread_id": {"type": "string"},
            },
            "required": ["chat_id", "text"],
        },
    ),
    "react": (
        "Add an emoji reaction to a message. Telegram only accepts a fixed "
        "whitelist (👍 👎 ❤ 🔥 👀 🎉 etc).",
        {
            "type": "object",
            "properties": {
                "chat_id":    {"type": "string"},
                "message_id": {"type": "string"},
                "emoji":      {"type": "string"},
            },
            "required": ["chat_id", "message_id", "emoji"],
        },
    ),
    "edit_message": (
        "Edit a previously-sent message. Useful for in-progress updates.",
        {
            "type": "object",
            "properties": {
                "chat_id":    {"type": "string"},
                "message_id": {"type": "string"},
                "text":       {"type": "string"},
            },
            "required": ["chat_id", "message_id", "text"],
        },
    ),
    "download_attachment": (
        "Download a file by file_id (from inbound channel tag's "
        "attachment_file_id) into the local inbox. Returns the absolute path.",
        {
            "type": "object",
            "properties": {
                "file_id": {"type": "string"},
            },
            "required": ["file_id"],
        },
    ),
    "send_photo": (
        "Send a photo by local file path. The path must be readable by the pod "
        "(e.g. something the agent just generated in /home/node/workspace). "
        "Optional `caption` shows under the image; `spoiler: true` hides the "
        "image behind a click-to-reveal cover (Telegram native flag). Pass "
        "`message_thread_id` (echoed from inbound) to land in the same topic.",
        {
            "type": "object",
            "properties": {
                "chat_id":           {"type": "string"},
                "path":              {"type": "string"},
                "caption":           {"type": "string"},
                "spoiler":           {"type": "boolean", "default": False},
                "reply_to":          {"type": "string"},
                "format":            {"type": "string", "enum": ["text", "markdownv2"], "default": "text"},
                "message_thread_id": {"type": "string"},
            },
            "required": ["chat_id", "path"],
        },
    ),
    "send_document": (
        "Send a file (any non-image type) by local file path. PDFs, archives, "
        "logs, generated reports — anything Telegram can attach as a document. "
        "Pass `message_thread_id` (echoed from inbound) to land in the same topic.",
        {
            "type": "object",
            "properties": {
                "chat_id":           {"type": "string"},
                "path":              {"type": "string"},
                "caption":           {"type": "string"},
                "reply_to":          {"type": "string"},
                "format":            {"type": "string", "enum": ["text", "markdownv2"], "default": "text"},
                "message_thread_id": {"type": "string"},
            },
            "required": ["chat_id", "path"],
        },
    ),
    "request_permission": (
        "Permission-prompt tool wired via claude's --permission-prompt-tool. "
        "Claude calls this BEFORE every tool_use when the orchestrator runs in "
        "permission_mode=strict. The implementation sends a Telegram message "
        "to each owner with inline buttons (✅ Allow / ❌ Deny / 🔍 See more) "
        "and waits for the user to tap one. Returns the standard prompt-tool "
        "shape: {behavior: 'allow'|'deny', updatedInput?: {...}, message?: ''}.\n"
        "Agents do NOT call this themselves — it's invoked automatically by "
        "claude. If you see this in your tool list, it's there for the "
        "permission-flow, not for direct use.",
        {
            "type": "object",
            "properties": {
                "tool_name": {"type": "string"},
                "input": {"type": "object"},
                "tool_use_id": {"type": "string"},
            },
            "required": ["tool_name", "input"],
        },
    ),
    "reply_with_choices": (
        "Reply to a Telegram chat with selectable inline-keyboard buttons. "
        "Each `choices` entry becomes one button; the user's tap is delivered "
        "back to you as a normal inbound message whose body is the button label "
        "(prefixed with 'choice: '). Use this for yes/no/cancel prompts, menus, "
        "or any time you want to constrain the user's reply to a known set. "
        "Buttons are arranged in rows of `columns` (default 1).",
        {
            "type": "object",
            "properties": {
                "chat_id":  {"type": "string"},
                "text":     {"type": "string"},
                "choices":  {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 20,
                },
                "columns":           {"type": "integer", "minimum": 1, "maximum": 5, "default": 1},
                "reply_to":          {"type": "string"},
                "format":            {"type": "string", "enum": ["text", "markdownv2"], "default": "text"},
                "message_thread_id": {"type": "string"},
            },
            "required": ["chat_id", "text", "choices"],
        },
    ),
}


SERVER_NAME = "waggle-tools"
SERVER_VERSION = "0.3.0"
SERVER_INSTRUCTIONS = (
    "waggle Telegram tools. Inbound user messages from Telegram arrive in your "
    "context as plain text wrapped in <channel source=\"telegram\" chat=\"…\" "
    "user=\"…\" ts=\"…\"> tags. To deliver a reply BACK to Telegram, you MUST "
    "call the `reply` tool — your transcript output never reaches the user "
    "directly. Pass `chat_id` from the channel tag, optionally `reply_to` to "
    "thread. Use `send_to_chat` for proactive cross-chat messages."
)


class ToolsServer:
    def __init__(self, bot_token: str, attachments_dir: str | None = None):
        self._token = bot_token
        self._bot: Bot | None = None
        self._attachments_dir = attachments_dir or os.path.join(
            tempfile.gettempdir(), "waggle-attachments"
        )
        os.makedirs(self._attachments_dir, exist_ok=True)
        self.mcp = Server(SERVER_NAME)
        self._wire()

    async def _ensure_bot(self) -> Bot:
        if self._bot is None:
            self._bot = Bot(
                token=self._token,
                default=DefaultBotProperties(parse_mode=ParseMode.HTML),
            )
        return self._bot

    def _wire(self) -> None:
        @self.mcp.list_tools()
        async def _list_tools() -> list[mt.Tool]:
            return [
                mt.Tool(name=name, description=desc, inputSchema=schema)
                for name, (desc, schema) in _TOOL_SCHEMAS.items()
            ]

        @self.mcp.call_tool()
        async def _call_tool(name: str, arguments: dict | None) -> list[mt.TextContent]:
            args = arguments or {}
            # Log the tool call up-front so an operator tailing the consolidated
            # waggle log sees activity even when chat.trollllm.xyz is slow.
            chat_id = args.get("chat_id", "?")
            preview = args.get("text", "")[:120].replace("\n", " ") if "text" in args else ""
            log.info("tool %s chat=%s: %s", name, chat_id, preview or "(no text)")
            try:
                bot = await self._ensure_bot()
                if name == "reply":
                    return _ok(await self._send(bot, args, with_reply_to=True))
                if name == "send_to_chat":
                    return _ok(await self._send(bot, args, with_reply_to=False))
                if name == "react":
                    await bot.set_message_reaction(
                        chat_id=int(args["chat_id"]),
                        message_id=int(args["message_id"]),
                        reaction=[ReactionTypeEmoji(emoji=args["emoji"])],
                    )
                    return _ok("reacted")
                if name == "edit_message":
                    await bot.edit_message_text(
                        chat_id=int(args["chat_id"]),
                        message_id=int(args["message_id"]),
                        text=args["text"],
                    )
                    return _ok("edited")
                if name == "download_attachment":
                    f = await bot.get_file(args["file_id"])
                    local = os.path.join(
                        self._attachments_dir,
                        f"{args['file_id']}_{os.path.basename(f.file_path or 'file')}",
                    )
                    await bot.download_file(f.file_path, destination=local)
                    return _ok(f"path={local}")
                if name == "reply_with_choices":
                    return _ok(await self._send_with_choices(bot, args))
                if name == "send_photo":
                    return _ok(await self._send_photo(bot, args))
                if name == "send_document":
                    return _ok(await self._send_document(bot, args))
                if name == "request_permission":
                    return await self._request_permission(bot, args)
                return _err(f"unknown tool: {name}")
            except Exception as e:
                log.exception("tool %s failed", name)
                return _err(f"{type(e).__name__}: {e}")

    async def _send_with_choices(self, bot: Bot, args: dict) -> str:
        """Send a message with an inline keyboard. callback_data carries
        an integer index (`c:<i>`); the telegram client looks up the label
        from the message's reply_markup when the user taps."""
        choices: list[str] = list(args.get("choices") or [])
        if not choices:
            raise ValueError("choices must be a non-empty list")
        # Telegram callback_data is capped at 64 bytes — embed only the index.
        # Label lookup happens on the inbound side (via message.reply_markup)
        # so the model can use long, descriptive labels.
        columns = max(1, min(5, int(args.get("columns") or 1)))
        rows: list[list[InlineKeyboardButton]] = []
        for i, label in enumerate(choices):
            label = str(label)[:64]  # Telegram button text cap
            btn = InlineKeyboardButton(text=label, callback_data=f"c:{i}")
            if i % columns == 0:
                rows.append([btn])
            else:
                rows[-1].append(btn)
        markup = InlineKeyboardMarkup(inline_keyboard=rows)

        kwargs: dict[str, Any] = {"reply_markup": markup}
        fmt = args.get("format", "text")
        if fmt == "markdownv2":
            kwargs["parse_mode"] = ParseMode.MARKDOWN_V2
        elif fmt == "text":
            kwargs["parse_mode"] = None
        if args.get("reply_to"):
            kwargs["reply_to_message_id"] = int(args["reply_to"])
        if args.get("message_thread_id"):
            kwargs["message_thread_id"] = int(args["message_thread_id"])
        sent = await bot.send_message(
            chat_id=int(args["chat_id"]),
            text=args["text"],
            **kwargs,
        )
        return f"sent message_id={sent.message_id} with {len(choices)} choices"

    async def _send(self, bot: Bot, args: dict, *, with_reply_to: bool) -> str:
        kwargs: dict[str, Any] = {}
        text = args["text"]
        spoiler = bool(args.get("spoiler"))
        fmt = args.get("format", "text")
        if spoiler:
            # Spoiler is only valid in markdownv2 (||...|| syntax). When the
            # caller asked for text, we transparently upgrade to markdownv2,
            # escaping the body's special chars first so the only markdown
            # syntax in flight is the spoiler wrap itself.
            if fmt != "markdownv2":
                text = _escape_md_v2(text)
                fmt = "markdownv2"
            text = f"||{text}||"
        if fmt == "markdownv2":
            kwargs["parse_mode"] = ParseMode.MARKDOWN_V2
        elif fmt == "text":
            kwargs["parse_mode"] = None
        if with_reply_to and args.get("reply_to"):
            kwargs["reply_to_message_id"] = int(args["reply_to"])
        if args.get("message_thread_id"):
            kwargs["message_thread_id"] = int(args["message_thread_id"])
        sent = await bot.send_message(
            chat_id=int(args["chat_id"]),
            text=text,
            **kwargs,
        )
        return f"sent message_id={sent.message_id}"

    async def _send_photo(self, bot: Bot, args: dict) -> str:
        path = args["path"]
        if not os.path.isfile(path):
            raise FileNotFoundError(f"path not found: {path}")
        kwargs: dict[str, Any] = {"photo": FSInputFile(path)}
        caption = args.get("caption")
        if caption is not None:
            kwargs["caption"] = caption
            fmt = args.get("format", "text")
            if fmt == "markdownv2":
                kwargs["parse_mode"] = ParseMode.MARKDOWN_V2
            elif fmt == "text":
                kwargs["parse_mode"] = None
        if args.get("spoiler"):
            kwargs["has_spoiler"] = True
        if args.get("reply_to"):
            kwargs["reply_to_message_id"] = int(args["reply_to"])
        if args.get("message_thread_id"):
            kwargs["message_thread_id"] = int(args["message_thread_id"])
        sent = await bot.send_photo(
            chat_id=int(args["chat_id"]),
            **kwargs,
        )
        return f"sent message_id={sent.message_id} photo={os.path.basename(path)}"

    async def _send_document(self, bot: Bot, args: dict) -> str:
        path = args["path"]
        if not os.path.isfile(path):
            raise FileNotFoundError(f"path not found: {path}")
        kwargs: dict[str, Any] = {"document": FSInputFile(path)}
        caption = args.get("caption")
        if caption is not None:
            kwargs["caption"] = caption
            fmt = args.get("format", "text")
            if fmt == "markdownv2":
                kwargs["parse_mode"] = ParseMode.MARKDOWN_V2
            elif fmt == "text":
                kwargs["parse_mode"] = None
        if args.get("reply_to"):
            kwargs["reply_to_message_id"] = int(args["reply_to"])
        if args.get("message_thread_id"):
            kwargs["message_thread_id"] = int(args["message_thread_id"])
        sent = await bot.send_document(
            chat_id=int(args["chat_id"]),
            **kwargs,
        )
        return f"sent message_id={sent.message_id} document={os.path.basename(path)}"

    # ---- Permission prompt (claude --permission-prompt-tool) ----

    # Tools that touch the filesystem — these are the ones we conditionally
    # ask about. Other tools (Read, Grep, WebFetch, MCP tools, etc.) are
    # always auto-allowed; the container boundary is the trust line.
    ASK_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}

    @staticmethod
    def _path_triggers_ask(input_obj: dict) -> bool:
        """Return True if any path-like field in the tool input mentions
        `claude` (case-insensitive). That's the heuristic for "this is a
        Claude-related file, anh wants to confirm before touching it".
        """
        candidates = (
            input_obj.get("file_path"),
            input_obj.get("notebook_path"),
            input_obj.get("path"),
        )
        for p in candidates:
            if isinstance(p, str) and "claude" in p.lower():
                return True
        # MultiEdit has `edits: [{old_string, new_string, ...}]`; the path
        # is on the parent (file_path), already handled above.
        return False

    def _should_ask(self, tool_name: str, tool_input: dict) -> bool:
        """Decide whether a tool call needs a Telegram prompt.
        Permission mode is read from env (orchestrator forwards it through
        mcp.json env when spawning tools_server). Default: claude_files."""
        mode = os.environ.get("WAGGLE_PERMISSION_MODE", "claude_files")
        if mode == "strict":
            return True
        # claude_files (or any unknown value): only the file-edit family
        # touching a "claude"-named path triggers asking.
        if tool_name not in self.ASK_TOOLS:
            return False
        return self._path_triggers_ask(tool_input)

    async def _request_permission(self, bot: Bot, args: dict) -> list[mt.TextContent]:
        """Implements claude's `--permission-prompt-tool` contract.

        Default policy: auto-allow everything. Exception: when claude wants
        to Edit/Write/MultiEdit/NotebookEdit a file whose path contains
        `claude` (case-insensitive), we send a Telegram message to each
        owner and wait for them to tap ✅ Allow / ❌ Deny.

        Tool result MUST be a single TextContent whose text is JSON of the
        form `{"behavior": "allow"|"deny", ...}` per claude code docs.
        """
        tool_name = str(args.get("tool_name") or "")
        tool_input = args.get("input") or {}
        if not isinstance(tool_input, dict):
            tool_input = {}

        # Auto-allow path
        if not self._should_ask(tool_name, tool_input):
            return _ok(json.dumps({
                "behavior": "allow",
                "updatedInput": tool_input,
            }))

        # Ask path: build prompt, send Telegram, wait for verdict file.
        request_id = uuid.uuid4().hex[:8]
        path = (tool_input.get("file_path")
                or tool_input.get("notebook_path")
                or tool_input.get("path") or "?")
        target_chat_ids = _load_owner_chat_ids()
        if not target_chat_ids:
            log.warning("permission asked but no owner chat configured — "
                        "defaulting to allow (would otherwise hang forever)")
            return _ok(json.dumps({"behavior": "allow", "updatedInput": tool_input}))

        # Read PERMISSION_DIR at call time so test monkeypatches take effect
        perm_dir = os.environ.get("WAGGLE_PERMISSION_DIR", PERMISSION_DIR)
        os.makedirs(perm_dir, exist_ok=True)
        prompt_keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Allow", callback_data=f"perm:allow:{request_id}"),
            InlineKeyboardButton(text="❌ Deny", callback_data=f"perm:deny:{request_id}"),
            InlineKeyboardButton(text="🔍 See more", callback_data=f"perm:more:{request_id}"),
        ]])
        text = f"🔐 Permission: {tool_name}\nPath: {path}"
        # Persist details so the "See more" handler in the parent waggle
        # process can render the full input on demand.
        details = {
            "tool_name": tool_name,
            "path": path,
            "input_preview": json.dumps(tool_input, ensure_ascii=False)[:1500],
        }
        with open(os.path.join(perm_dir, f"{request_id}.details"), "w") as f:
            json.dump(details, f)

        sent_message_ids: list[tuple[int, int]] = []
        for chat_id in target_chat_ids:
            try:
                m = await bot.send_message(
                    chat_id=chat_id, text=text, reply_markup=prompt_keyboard,
                )
                sent_message_ids.append((chat_id, m.message_id))
            except Exception as e:
                log.warning("permission send to %s failed: %r", chat_id, e)

        # Wait for the verdict file (written by waggle parent's callback handler).
        verdict_path = os.path.join(perm_dir, f"{request_id}.verdict")
        deadline = asyncio.get_event_loop().time() + 600  # 10 min cap
        while asyncio.get_event_loop().time() < deadline:
            if os.path.exists(verdict_path):
                with open(verdict_path) as f:
                    verdict = json.load(f)
                # Best-effort cleanup
                for fname in (f"{request_id}.verdict", f"{request_id}.details"):
                    try:
                        os.remove(os.path.join(perm_dir, fname))
                    except OSError:
                        pass
                behavior = verdict.get("behavior", "deny")
                result = {"behavior": behavior}
                if behavior == "allow":
                    result["updatedInput"] = tool_input
                else:
                    result["message"] = verdict.get("message",
                                                     "Owner denied the tool call.")
                return _ok(json.dumps(result))
            await asyncio.sleep(0.5)

        # Timeout — default deny so an absent operator doesn't accidentally
        # allow a destructive op.
        log.warning("permission timeout for %s — denying", request_id)
        return _ok(json.dumps({
            "behavior": "deny",
            "message": "Permission request timed out (10 min).",
        }))

    async def run(self) -> None:
        async with stdio_server() as (read, write):
            init_opts = InitializationOptions(
                server_name=SERVER_NAME,
                server_version=SERVER_VERSION,
                capabilities=self.mcp.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},  # NO claude/channel
                ),
                instructions=SERVER_INSTRUCTIONS,
            )
            try:
                await self.mcp.run(read, write, init_opts)
            finally:
                if self._bot is not None:
                    try:
                        await self._bot.session.close()
                    except Exception:
                        pass


def _load_owner_chat_ids() -> list[int]:
    """Read the operator's chat_id list from the same config.yaml the
    orchestrator uses. Falls back to env var WAGGLE_PERMISSION_CHAT_IDS
    (comma-separated) for ad-hoc deployments. Returns [] when neither
    is set so the caller can default to allow rather than hang."""
    env = os.environ.get("WAGGLE_PERMISSION_CHAT_IDS", "").strip()
    if env:
        return [int(x) for x in env.split(",") if x.strip().lstrip("-").isdigit()]
    cfg_path = os.environ.get("WAGGLE_CONFIG", "/etc/waggle/config.yaml")
    try:
        import yaml
        with open(cfg_path) as f:
            data = yaml.safe_load(f) or {}
    except Exception as e:
        log.debug("permission: config read failed: %r", e)
        return []
    out: list[int] = []
    owner = ((data.get("owner") or {}).get("user_id"))
    if isinstance(owner, int):
        out.append(owner)
    return out


_MD_V2_SPECIAL = r"_*[]()~`>#+-=|{}.!"


def _escape_md_v2(text: str) -> str:
    """Escape Telegram MarkdownV2 special chars per the API spec.
    Used when wrapping non-markdownv2 text in spoiler syntax — we don't
    want stray underscores or asterisks in the user's text to flip parse
    mode mid-message and crash the send."""
    return "".join("\\" + c if c in _MD_V2_SPECIAL else c for c in text)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="waggle.tools_server")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    log_file = os.environ.get("WAGGLE_TOOLS_LOG_FILE")
    if log_file:
        handlers.append(logging.FileHandler(log_file))
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        handlers=handlers,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )

    token = os.environ.get("WAGGLE_TG_BOT_TOKEN")
    if not token:
        log.error("WAGGLE_TG_BOT_TOKEN not set")
        return 2
    server = ToolsServer(bot_token=token)
    asyncio.run(server.run())
    return 0


if __name__ == "__main__":
    sys.exit(main())
