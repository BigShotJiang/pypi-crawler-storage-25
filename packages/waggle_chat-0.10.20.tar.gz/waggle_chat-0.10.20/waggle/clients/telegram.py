"""Telegram client used by the waggle orchestrator (v0.3 stream-json).

Two responsibilities:

  • Background long-poll that turns inbound messages into orchestrator
    submissions via `WaggleOrchestrator.submit_inbound(...)`. The orchestrator
    is responsible for access-list gating and dispatching the message to
    claude over stdin.
  • Outbound primitives `reply` / `react` / `edit_text` / `download_attachment`
    used by the orchestrator for error surfaces and ad-hoc operations. The
    main outbound path for replies is now claude calling the MCP `reply`
    tool in `waggle.tools_server`, which has its own Bot instance — this
    client's outbound is the back-up path the orchestrator uses when claude
    fails to produce a turn.
"""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
from datetime import datetime, timezone
from typing import Any, Mapping, TYPE_CHECKING

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import (
    BotCommand,
    BotCommandScopeAllPrivateChats,
    CallbackQuery,
    Message,
    ReactionTypeEmoji,
)

from ..events import RejectEvent

if TYPE_CHECKING:
    from ..orchestrator import WaggleOrchestrator

log = logging.getLogger(__name__)


class TelegramClient:
    """Aiogram-backed Telegram client. `run(server)` runs forever — long-poll
    + dispatch to the bound `WaggleMCPServer`."""

    source = "telegram"

    def __init__(
        self,
        *,
        name: str,
        bot_token: str,
        drop_pending_updates: bool = True,
        attachments_dir: str | None = None,
    ):
        self.name = name
        self._token = bot_token
        self._drop_pending = drop_pending_updates
        self._bot: Bot | None = None
        self._dp: Dispatcher | None = None
        self._orchestrator: "WaggleOrchestrator | None" = None
        self._attachments_dir = attachments_dir or os.path.join(
            tempfile.gettempdir(), "waggle-attachments"
        )
        os.makedirs(self._attachments_dir, exist_ok=True)
        # Bot identity, populated in run() once get_me() returns.
        self._bot_id: int | None = None
        self._bot_username: str = ""

    @classmethod
    def from_config(cls, cfg: Mapping[str, Any]) -> "TelegramClient":
        return cls(
            name=cfg["name"],
            bot_token=cfg["bot_token"],
            drop_pending_updates=bool(cfg.get("drop_pending_updates", True)),
            attachments_dir=cfg.get("attachments_dir"),
        )

    # ---- Lifecycle ----

    async def run(self, orchestrator: "WaggleOrchestrator") -> None:
        """Connect, start polling, dispatch inbound to `orchestrator.submit_inbound`."""
        self._orchestrator = orchestrator
        self._bot = Bot(
            token=self._token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )
        me = await self._bot.get_me()
        # Cache bot identity so the inbound handler can detect @-mentions
        # and reply-to-bot without re-fetching get_me() per message.
        self._bot_id = me.id
        self._bot_username = me.username or ""
        log.info("telegram[%s] connected as @%s (id=%s)", self.name, me.username, me.id)

        # Register owner-op slash commands so Telegram clients show the
        # autocomplete `/` menu. Scoped to private chats only — owner ops
        # are DM-only, so groups don't need to see them. Non-owners who
        # DM the bot will see the menu but the access gate / owner check
        # will reject the call; that's acceptable surface trade-off.
        await self._register_owner_commands()

        self._dp = Dispatcher()
        self._dp.message.register(self._on_message)
        self._dp.callback_query.register(self._on_callback_query)
        try:
            await self._dp.start_polling(
                self._bot,
                drop_pending_updates=self._drop_pending,
                handle_signals=False,
            )
        except asyncio.CancelledError:
            pass
        finally:
            try:
                await self._bot.session.close()
            except Exception:
                pass

    # ---- Outbound (tool implementations) ----

    async def _register_owner_commands(self) -> None:
        """Register the 7 owner slash commands with Telegram so clients
        show the autocomplete menu when the user types `/` in a DM. Scope
        is `AllPrivateChats` — groups don't get the menu (consistent with
        the DM-only owner-ops policy). Best-effort: a failed registration
        is logged at WARN, not fatal."""
        commands = [
            BotCommand(command="status",  description="Liveness + turn count + last inbound"),
            BotCommand(command="pause",   description="Drop new inbound silently until /resume"),
            BotCommand(command="resume",  description="Restore normal flow after /pause"),
            BotCommand(command="abort",   description="Kill in-flight turn + restart agent now"),
            BotCommand(command="restart", description="Restart agent (5s cancel window)"),
            BotCommand(command="new",     description="Drop session context — fresh conversation (5s cancel)"),
            BotCommand(command="compact", description="Compact agent's conversation memory"),
        ]
        try:
            await self._bot.set_my_commands(
                commands=commands,
                scope=BotCommandScopeAllPrivateChats(),
            )
            log.info("registered %d owner commands (scope: all_private_chats)",
                     len(commands))
        except Exception as e:
            log.warning("set_my_commands failed: %r", e)

    async def reply(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to: str | None = None,
        format: str = "text",
        reply_markup: Any = None,
        message_thread_id: str | None = None,
    ) -> str:
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        kwargs: dict[str, Any] = {}
        if format == "markdownv2":
            kwargs["parse_mode"] = ParseMode.MARKDOWN_V2
        elif format == "text":
            # Override the default HTML parse mode set in DefaultBotProperties
            # when caller asked for plain text.
            kwargs["parse_mode"] = None
        if reply_to is not None:
            kwargs["reply_to_message_id"] = int(reply_to)
        if reply_markup is not None:
            kwargs["reply_markup"] = reply_markup
        if message_thread_id is not None and message_thread_id != "":
            # Forum-topic supergroups require this to keep the reply inside
            # the topic; outside topics Telegram ignores the field.
            kwargs["message_thread_id"] = int(message_thread_id)
        sent = await self._bot.send_message(chat_id=int(chat_id), text=text, **kwargs)
        return str(sent.message_id)

    async def react(self, *, chat_id: str, message_id: str, emoji: str) -> None:
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        await self._bot.set_message_reaction(
            chat_id=int(chat_id),
            message_id=int(message_id),
            reaction=[ReactionTypeEmoji(emoji=emoji)],
        )

    async def edit_text(
        self, *, chat_id: str, message_id: str, text: str,
        reply_markup: Any = None,
    ) -> None:
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        kwargs: dict[str, Any] = {}
        if reply_markup is not None:
            kwargs["reply_markup"] = reply_markup
        await self._bot.edit_message_text(
            chat_id=int(chat_id), message_id=int(message_id), text=text, **kwargs,
        )

    async def edit_reply_markup(
        self, *, chat_id: str, message_id: str, reply_markup: Any = None,
    ) -> None:
        """Replace (or clear) just the inline keyboard on a message,
        leaving the text untouched. Pass `reply_markup=None` to remove."""
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        await self._bot.edit_message_reply_markup(
            chat_id=int(chat_id), message_id=int(message_id),
            reply_markup=reply_markup,
        )

    async def send_chat_action(self, *, chat_id: str, action: str = "typing") -> None:
        """Surface the platform-native 'is typing…' indicator. Telegram
        auto-clears after ~5 s, so for a long turn this must be re-sent
        periodically. Best-effort: any aiogram error is swallowed so a
        stale chat (kicked, deleted) does not crash the runtime."""
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        try:
            await self._bot.send_chat_action(chat_id=int(chat_id), action=action)
        except Exception as e:
            log.debug("send_chat_action failed: %r", e)

    async def delete_message(self, *, chat_id: str, message_id: str) -> None:
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        await self._bot.delete_message(chat_id=int(chat_id), message_id=int(message_id))

    async def download_attachment(self, file_id: str) -> str:
        """Download by raw file_id. Returns the absolute local path."""
        if self._bot is None:
            raise RuntimeError("telegram client not started")
        f = await self._bot.get_file(file_id)
        local = os.path.join(self._attachments_dir, f"{file_id}_{os.path.basename(f.file_path or 'file')}")
        await self._bot.download_file(f.file_path, destination=local)
        return local

    # ---- Inbound dispatch ----

    async def _on_message(self, message: Message) -> None:
        if self._orchestrator is None:
            return
        if message.from_user is None:
            return
        text = message.text or message.caption or ""
        attachments = _extract_attachments(message)
        if not text and not attachments:
            # Truly empty message (no text, no caption, no media) — nothing
            # for the agent to act on. Skip without spending an access /
            # rate-limit slot.
            return
        if not text:
            # Attachments-only message (e.g. user just dropped a photo with
            # no caption). The channel-tag's [attachments] line will tell
            # the agent what's bound to this message; surface an empty
            # body so access checks + agent dispatch still run.
            text = ""

        # Reply context — when B replies to A's earlier message tagging
        # the bot, the agent needs to see what A originally said. aiogram
        # surfaces this on `reply_to_message`. Extract just enough to give
        # the agent context (sender + text + any attachments on the
        # quoted message); we don't recurse further (no replies-of-replies)
        # since the body would balloon.
        reply_to: dict | None = None
        if message.reply_to_message is not None:
            r = message.reply_to_message
            r_text = r.text or r.caption or ""
            r_user = (r.from_user.username or str(r.from_user.id)) if r.from_user else ""
            r_user_id = str(r.from_user.id) if r.from_user else ""
            reply_to = {
                "message_id": str(r.message_id),
                "user": r_user_id,
                "username": r_user,
                "text": r_text,
                "ts": r.date.isoformat() if r.date else "",
                "attachments": list(_extract_attachments(r)),
            }

        is_mentioned = _is_bot_addressed(
            message, bot_id=self._bot_id, bot_username=self._bot_username,
        )
        # v2 channel-tag enrichment. aiogram's User and Chat objects expose
        # everything the Bot API surfaces — pull through the safe / non-PII
        # fields. is_premium and is_topic_message are bool|None (None = the
        # source didn't tell us, e.g. private chat has no topic concept).
        u = message.from_user
        c = message.chat
        await self._orchestrator.submit_inbound(
            chat_id=c.id,
            user_id=u.id,
            username=u.username or str(u.id),
            message_id=str(message.message_id),
            text=text,
            attachments=attachments,
            ts=message.date,  # Telegram's send-time, not waggle's receive-time
            is_mentioned=is_mentioned,
            reply_to=reply_to,
            first_name=u.first_name or "",
            last_name=u.last_name or "",
            is_premium=u.is_premium,
            chat_type=c.type or "",
            chat_title=c.title or "",
            message_thread_id=str(message.message_thread_id) if message.message_thread_id else "",
            is_topic_message=message.is_topic_message,
        )

    async def _on_callback_query(self, callback: CallbackQuery) -> None:
        """User tapped an inline keyboard button.

        Two callback flows are dispatched here:

          • `c:<index>` — a choice from `reply_with_choices`. We resolve
            the label, edit the source message to confirm the choice (and
            remove the keyboard so the user can't double-tap), then
            dispatch as a normal inbound `choice: <label>`.

          • `t:show` / `t:refresh` — user opened or refreshed the agent's
            transcript view from the working-status indicator. Forwarded
            to the orchestrator's StatusIndicator.

        We always answer the callback to clear Telegram's loading
        spinner, even if dispatch fails — the spinner is UX, not state.
        """
        # Always answer first so the spinner clears (best-effort)
        try:
            await callback.answer()
        except Exception as e:
            log.debug("callback.answer failed: %r", e)

        if self._orchestrator is None:
            return
        if callback.from_user is None:
            return
        if callback.message is None:
            return

        data = callback.data or ""
        chat = callback.message.chat

        # ── Show / refresh thinking ──────────────────────────────────
        if data in ("t:show", "t:refresh"):
            status = getattr(self._orchestrator, "_status", None)
            if status is not None:
                try:
                    await status.show_thinking(chat.id)
                except Exception as e:
                    log.warning("show_thinking failed: %r", e)
            return

        # ── Show / refresh tasklist ──────────────────────────────────
        if data in ("tk:show", "tk:refresh"):
            status = getattr(self._orchestrator, "_status", None)
            if status is not None:
                try:
                    await status.show_tasklist(chat.id)
                except Exception as e:
                    log.warning("show_tasklist failed: %r", e)
            return

        # ── Permission prompt (waggle's tools_server is waiting on a
        #    verdict file). Format: perm:(allow|deny|more):<request_id>.
        if data.startswith("perm:"):
            await _handle_permission_callback(
                self._bot, callback, chat,
            )
            return

        # ── Choice from reply_with_choices ───────────────────────────
        # callback_data shape: 'c:<index>' (set by reply_with_choices)
        label: str | None = None
        if data.startswith("c:"):
            try:
                idx = int(data[2:])
                markup = callback.message.reply_markup
                if markup is not None and markup.inline_keyboard:
                    flat = [b for row in markup.inline_keyboard for b in row]
                    if 0 <= idx < len(flat):
                        label = flat[idx].text
            except (ValueError, IndexError):
                pass

        if label is None:
            log.warning("callback_query with un-resolvable data %r — dropping",
                        data[:40])
            return

        # Edit the source message: remove the keyboard so the user can't
        # double-tap, and append a confirmation footer with the chosen
        # label. Body of the new message: original text + "\n\n✅ <label>".
        try:
            original = callback.message.text or callback.message.caption or ""
            confirmation = f"{original}\n\n✅ {label}".strip()
            await self.edit_text(
                chat_id=str(chat.id),
                message_id=str(callback.message.message_id),
                text=confirmation,
                reply_markup=None,
            )
        except Exception as e:
            log.debug("edit on selection failed: %r", e)

        # Dispatch as inbound. The body is `choice: <label>` so agent can
        # tell this came from a button vs free text.
        await self._orchestrator.submit_inbound(
            chat_id=chat.id,
            user_id=callback.from_user.id,
            username=callback.from_user.username or str(callback.from_user.id),
            # We synthesise a message_id from the callback id so the
            # orchestrator's last-inbound-preview / accept-event have a
            # stable handle. Real Telegram message_id is on the source
            # button-press, which the bot can't see.
            message_id=str(callback.id),
            text=f"choice: {label}",
            attachments=(),
            # A button tap on a bot-sent keyboard IS by definition
            # addressed to the bot — bypass require_mention groups.
            is_mentioned=True,
        )


async def _handle_permission_callback(bot, callback: CallbackQuery, chat) -> None:
    """User tapped Allow / Deny / See more on a permission prompt.

    Works in tandem with `tools_server.request_permission`: that tool
    polls `<PERMISSION_DIR>/<request_id>.verdict` until present. Here we
    just write the verdict file and edit the message to lock the choice.

    Callback data shape: `perm:(allow|deny|more):<request_id>`. We do not
    re-validate access here — the access gate already filtered inbound
    callbacks by sender."""
    import json as _json
    import os as _os
    import re as _re
    data = callback.data or ""
    m = _re.match(r"^perm:(allow|deny|more):([a-f0-9]{4,16})$", data)
    if not m:
        return
    behavior, request_id = m.group(1), m.group(2)
    perm_dir = _os.environ.get(
        "WAGGLE_PERMISSION_DIR", "/tmp/waggle/permissions",
    )

    if behavior == "more":
        # Expand the message body to show the full input details, keeping
        # Allow/Deny so the user can still vote.
        details_path = _os.path.join(perm_dir, f"{request_id}.details")
        try:
            with open(details_path) as f:
                d = _json.load(f)
        except Exception:
            return
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
        try:
            input_pretty = _json.dumps(_json.loads(d.get("input_preview", "{}")),
                                       indent=2, ensure_ascii=False)
        except Exception:
            input_pretty = d.get("input_preview", "")
        expanded = (
            f"🔐 Permission: {d.get('tool_name','?')}\n\n"
            f"path: {d.get('path','?')}\n"
            f"input_preview:\n{input_pretty}"
        )
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Allow", callback_data=f"perm:allow:{request_id}"),
            InlineKeyboardButton(text="❌ Deny", callback_data=f"perm:deny:{request_id}"),
        ]])
        try:
            await bot.edit_message_text(
                chat_id=chat.id,
                message_id=callback.message.message_id,
                text=expanded[:4000],
                reply_markup=kb,
            )
        except Exception as e:
            log.debug("perm see-more edit failed: %r", e)
        return

    # Allow / Deny: write the verdict file, edit the message to lock.
    _os.makedirs(perm_dir, exist_ok=True)
    verdict = {"behavior": behavior}
    if behavior == "deny":
        verdict["message"] = "Owner denied via Telegram."
    try:
        with open(_os.path.join(perm_dir, f"{request_id}.verdict"), "w") as f:
            _json.dump(verdict, f)
    except Exception as e:
        log.warning("perm verdict write failed: %r", e)
        return

    label = "✅ Allowed" if behavior == "allow" else "❌ Denied"
    try:
        original = (callback.message.text or callback.message.caption or "").strip()
        await bot.edit_message_text(
            chat_id=chat.id,
            message_id=callback.message.message_id,
            text=f"{original}\n\n{label}".strip(),
            reply_markup=None,
        )
    except Exception as e:
        log.debug("perm lock edit failed: %r", e)


def _is_bot_addressed(message: Message, *, bot_id: int | None,
                       bot_username: str) -> bool:
    """Return True iff this message is explicitly addressed to the bot:
    via @-mention (text or text_mention entity) OR by replying to a
    prior bot message OR by a `/cmd@bot_username` slash command.

    Reply-to-bot is treated as an implicit mention because Telegram's
    UX for "answering a bot in a noisy group" is usually to long-press
    the bot's message and reply — never typing @bot_username.

    `/cmd@bot_username` is detected because Telegram turns it into a
    SINGLE `bot_command` entity (not a separate `mention` entity), so
    we can't rely on the mention-entity path for it. We just look for
    the `@bot_username` suffix in any bot_command entity's text.
    """
    # Reply path
    if message.reply_to_message and message.reply_to_message.from_user:
        if bot_id is not None and message.reply_to_message.from_user.id == bot_id:
            return True
    # Entities (message + caption). Telegram entity offsets/lengths are in
    # UTF-16 code units, NOT Python str chars — emoji and other non-BMP
    # code points are 2 UTF-16 units each. `MessageEntity.extract_from`
    # is aiogram's surrogate-aware slicer; using naive `text[off:off+len]`
    # on a message with leading emoji silently picks the wrong substring.
    entities = list(message.entities or []) + list(message.caption_entities or [])
    text = message.text or message.caption or ""
    bot_at = ("@" + bot_username).lower() if bot_username else None
    for ent in entities:
        if ent.type == "mention" and bot_username:
            mentioned = ent.extract_from(text)
            if mentioned.lstrip("@").lower() == bot_username.lower():
                return True
        elif ent.type == "text_mention":
            user = getattr(ent, "user", None)
            if user is not None and bot_id is not None and user.id == bot_id:
                return True
        elif ent.type == "bot_command" and bot_at:
            # `/cmd@bot_username` — Telegram packs the whole thing into
            # one bot_command entity, no separate mention. Sniff the
            # @bot_username suffix.
            cmd_text = ent.extract_from(text).lower()
            if bot_at in cmd_text:
                return True
    return False


def _extract_attachments(message: Message) -> tuple[dict, ...]:
    """Pull a tuple of attachment-by-reference dicts from a Telegram message.

    Each entry is `{"kind": <type>, "file_id": <str>, "mime_type": <str?>}`.
    The dashboard fetches the binary on-demand via Telegram's file API using
    `file_id`. waggle does NOT download anything here.
    """
    out: list[dict] = []
    # Photo: take only the largest size — the smaller PhotoSizes are server-
    # side downscales of the same image, redundant for persistence.
    if message.photo:
        largest = message.photo[-1]
        out.append({"kind": "photo", "file_id": largest.file_id})
    if message.document:
        d = {"kind": "document", "file_id": message.document.file_id}
        if message.document.mime_type:
            d["mime_type"] = message.document.mime_type
        out.append(d)
    if message.video:
        d = {"kind": "video", "file_id": message.video.file_id}
        if message.video.mime_type:
            d["mime_type"] = message.video.mime_type
        out.append(d)
    if message.audio:
        d = {"kind": "audio", "file_id": message.audio.file_id}
        if message.audio.mime_type:
            d["mime_type"] = message.audio.mime_type
        out.append(d)
    if message.voice:
        d = {"kind": "voice", "file_id": message.voice.file_id}
        if message.voice.mime_type:
            d["mime_type"] = message.voice.mime_type
        out.append(d)
    if message.sticker:
        out.append({"kind": "sticker", "file_id": message.sticker.file_id})
    return tuple(out)
