from __future__ import annotations

import datetime as dt
import json
import tempfile
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import PropertyMock, patch

import pytest

from mamonia.config import Settings
from mamonia.models import ReleaseTrack
from mamonia.providers import ProviderRateLimit, ProviderUnavailable, rate_limit_from_exception
from mamonia.providers.deezer import DeezerProvider
from mamonia.providers.apple_music import AppleMusicProvider
from mamonia.providers.lastfm import LastFMProvider
from mamonia.providers.listenbrainz import ListenBrainzProvider
from mamonia.providers.musicbrainz import MusicBrainzProvider
from mamonia.providers.spotify import SPOTIFY_READ_SCOPES, SpotifyProvider
from mamonia.providers.tidal import (
    TidalPlaylistCreationResult,
    TidalProvider,
    _track_matches_lookup_target,
    _authenticate_session,
    _configure_client,
    _describe_auth_flow,
    _detect_auth_flow,
    _tidal_candidate_within_discovery_window,
)
from mamonia.storage import Storage


FIXTURES_DIR = Path(__file__).parent / "fixtures"


class ProviderRateLimitTests(unittest.TestCase):
    def test_exception_parser_extracts_provider_and_retry_after(self) -> None:
        exc = _FakeProviderError(429, {"Retry-After": "62929"}, "rate/request limit")

        rate_limit = rate_limit_from_exception("Spotify", "reading playlist", exc)

        self.assertIsNotNone(rate_limit)
        assert rate_limit is not None
        self.assertEqual(rate_limit.provider, "Spotify")
        self.assertEqual(rate_limit.operation, "reading playlist")
        self.assertEqual(rate_limit.retry_after_seconds, 62929)
        self.assertFalse(rate_limit.should_auto_wait)

    def test_spotify_playlist_rate_limit_fails_fast_with_provider_name(self) -> None:
        provider = SpotifyProvider(_settings())
        provider._user_clients[SPOTIFY_READ_SCOPES] = _FakeSpotifyClient(
            _FakeProviderError(429, {"Retry-After": "62929"}, "rate/request limit")
        )

        with self.assertRaises(ProviderRateLimit) as raised:
            provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(raised.exception.provider, "Spotify")
        self.assertEqual(raised.exception.retry_after_seconds, 62929)

    def test_spotify_optional_rate_limit_disables_provider_for_long_window(self) -> None:
        provider = SpotifyProvider(_settings())
        provider._client = _FakeSpotifySearchClient(
            _FakeProviderError(429, {"Retry-After": "3600"}, "rate limit")
        )

        self.assertIsNone(provider.search_artist("Artist"))
        self.assertEqual(provider.rate_limit_warnings[0].provider, "Spotify")
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_spotify_track_match_retries_shorter_queries_when_primary_query_fails(self) -> None:
        provider = SpotifyProvider(_settings())
        track = ReleaseTrack(title="Non Fiction: I. Sonore - Animato - Meno Mosso", artists="Hania Rani")
        long_query = (
            'artist:"Hania Rani, Manchester Collective, Jack Wyllie, Valentina Magaletti & Hugh Tieppo-Brunt" '
            'track:"Non Fiction: I. Sonore - Animato - Meno Mosso" album:"Non Fiction - Piano Concerto in Four Movements"'
        )

        def _fake_search(*, q: str, type_: str, limit: int, offset: int = 0, use_global_session: bool = False):
            if "Manchester Collective" in q:
                raise RuntimeError("400 bad request")
            if 'track:"Non Fiction: I. Sonore - Animato - Meno Mosso"' in q:
                return {
                    "tracks": {
                        "items": [
                            {
                                "id": "sp-nf-1",
                                "uri": "spotify:track:sp-nf-1",
                                "name": "Non Fiction: I. Sonore - Animato - Meno Mosso",
                                "artists": [{"name": "Hania Rani"}],
                                "album": {"id": "sp-album-1", "name": "Non Fiction - Piano Concerto in Four Movements", "release_date": "2025-11-14"},
                                "external_ids": {"isrc": "USUG12507557"},
                                "popularity": 10,
                            }
                        ]
                    }
                }
            return {"tracks": {"items": []}}

        with patch.object(provider, "_search_request", side_effect=_fake_search):
            match = provider._search_track_match(
                cache_key="test-cache-key",
                query=long_query,
                track=track,
                album_name="Non Fiction - Piano Concerto in Four Movements",
                primary_artist="Hania Rani, Manchester Collective, Jack Wyllie, Valentina Magaletti & Hugh Tieppo-Brunt",
                source="spotify_track_search_strict",
                note="test",
                release_date="2025-11-14",
                discovery_months=6,
                discovery_today=dt.date(2026, 4, 30),
            )
        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.get("id"), "sp-nf-1")

    def test_exception_parser_classifies_auth_failure(self) -> None:
        exc = _FakeProviderError(401, {}, "Unauthorized", response_message="The access token expired")

        issue = rate_limit_from_exception("Spotify", "reading playlist", exc)

        self.assertIsNotNone(issue)
        assert issue is not None
        self.assertEqual(issue.error_kind, "auth_failed")
        self.assertEqual(str(issue), "Spotify authentication failed while reading playlist. The access token expired")

    def test_exception_parser_classifies_scope_failure(self) -> None:
        exc = _FakeProviderError(403, {}, "Forbidden", response_message="Insufficient client scope")

        issue = rate_limit_from_exception("Spotify", "creating playlist", exc)

        self.assertIsNotNone(issue)
        assert issue is not None
        self.assertEqual(issue.error_kind, "insufficient_scope")
        self.assertTrue(issue.is_permission_error)

    def test_exception_parser_classifies_forbidden_playlist_access(self) -> None:
        exc = _FakeProviderError(403, {}, "Forbidden", response_message="Private playlist is not accessible")

        issue = rate_limit_from_exception("Spotify", "reading playlist", exc)

        self.assertIsNotNone(issue)
        assert issue is not None
        self.assertEqual(issue.error_kind, "forbidden_access")
        self.assertEqual(str(issue), "Spotify denied access while reading playlist. Private playlist is not accessible")

    def test_exception_parser_classifies_market_related_invalid_request(self) -> None:
        exc = _FakeProviderError(400, {}, "Bad Request", response_message="Invalid market code")

        issue = rate_limit_from_exception("Spotify", "searching tracks", exc)

        self.assertIsNotNone(issue)
        assert issue is not None
        self.assertEqual(issue.error_kind, "content_unavailable")
        self.assertEqual(str(issue), "Spotify content unavailable while searching tracks. Invalid market code")

    def test_lastfm_http_429_records_provider_warning(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(429, {"Retry-After": "120"}, {}))
        provider._last_request_at = -999.0

        result = provider.top_tags("Artist")

        self.assertEqual(result, [])
        self.assertEqual(provider.rate_limit_warnings[0].provider, "Last.fm")
        self.assertEqual(provider.rate_limit_warnings[0].retry_after_seconds, 120)
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_lastfm_json_rate_limit_records_provider_warning(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, {"error": "29", "message": "Rate Limit Exceeded"}))
        provider._last_request_at = -999.0

        result = provider.similar_artists("Artist")

        self.assertEqual(result, [])
        self.assertEqual(provider.rate_limit_warnings[0].provider, "Last.fm")

    def test_provider_http_clients_do_not_trust_proxy_environment_by_default(self) -> None:
        settings = _settings(lastfm_api_key="lastfm-key", listenbrainz_user_token="test-token")

        providers = [
            LastFMProvider(settings),
            ListenBrainzProvider(settings),
            MusicBrainzProvider(settings),
            DeezerProvider(settings),
        ]

        for provider in providers:
            self.assertFalse(provider.client._trust_env)

    def test_lastfm_request_scopes_api_key_to_lastfm_params_only(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _RecordingHttpClient(_FakeResponse(200, {}, {"toptags": {"tag": []}}))
        provider._last_request_at = -999.0

        provider.top_tags("Artist")

        self.assertEqual(provider.client.last_url, "https://ws.audioscrobbler.com/2.0/")
        self.assertEqual(provider.client.last_kwargs["params"]["api_key"], "lastfm-key")
        self.assertNotIn("headers", provider.client.last_kwargs)
        self.assertNotIn("spotify-secret", json.dumps(provider.client.last_kwargs))

    def test_lastfm_respect_rate_limit_uses_configured_min_interval(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.settings.lastfm_min_interval_seconds = 0.5
        provider._last_request_at = 0.0

        with patch("mamonia.providers.lastfm.time.monotonic", side_effect=[0.1, 0.7]):
            with patch("mamonia.providers.lastfm.time.sleep") as sleep_mock:
                provider._respect_rate_limit()

        sleep_mock.assert_called_once()
        self.assertAlmostEqual(sleep_mock.call_args.args[0], 0.4, places=3)

    def test_musicbrainz_429_records_provider_warning(self) -> None:
        provider = MusicBrainzProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(429, {"Retry-After": "90"}, {}))
        provider._last_request_at = -999.0

        result = provider._get("/artist", {"query": "artist"})

        self.assertIsNone(result)
        self.assertEqual(provider.rate_limit_warnings[0].provider, "MusicBrainz")
        self.assertEqual(provider.rate_limit_warnings[0].retry_after_seconds, 90)
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_tidal_auth_uses_pkce_session_file_for_current_tidalapi(self) -> None:
        session = _FakeTidalSession()
        session_file = Path(tempfile.gettempdir()) / "mamonia-tidal-session-test.json"

        _authenticate_session(session, session_file)

        self.assertEqual(session.session_file, session_file)
        self.assertTrue(session.do_pkce)
        self.assertTrue(session.logged_in)

    def test_tidal_client_settings_are_applied_when_present(self) -> None:
        session = _FakeTidalSession()
        settings = _settings()
        settings.tidal_client_id = "tidal-id"
        settings.tidal_client_secret = "tidal-secret"

        _configure_client(session, settings)

        self.assertEqual(session.config.client_id, "tidal-id")
        self.assertEqual(session.config.client_secret, "tidal-secret")

    def test_tidal_auth_flow_detection_prefers_pkce_when_available(self) -> None:
        self.assertEqual(_detect_auth_flow(_FakeTidalSession), "pkce-session-file")
        self.assertEqual(_describe_auth_flow("pkce-session-file"), "PKCE session-file login")

    def test_tidal_auth_flow_detection_falls_back_to_legacy_login(self) -> None:
        self.assertEqual(_detect_auth_flow(_LegacyLoginOnlySession), "legacy-login")
        self.assertEqual(_describe_auth_flow("legacy-login"), "legacy interactive login")

    def test_tidal_provider_diagnostic_summary_marks_native_playlist_creation_experimental(self) -> None:
        settings = _settings()
        settings.tidal_client_id = "tidal-id"
        settings.tidal_client_secret = "tidal-secret"
        provider = TidalProvider(settings)

        with patch.object(TidalProvider, "available", new_callable=PropertyMock, return_value=True), patch(
            "mamonia.providers.tidal._session_type", return_value=_FakeTidalSession
        ):
            summary = provider.diagnostic_summary()

        self.assertIn("playlist analysis", summary["provider_status"])
        self.assertEqual(summary["auth_flow"], "PKCE session-file login")
        self.assertEqual(
            summary["native_playlist_creation"],
            "experimental; verify with `mamonia tidal-smoke` before relying on it",
        )

    def test_tidal_playlist_accepts_direct_track_items(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalPlaylistSession([_FakeTidalTrack()])

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 1)

    def test_apple_music_fetch_user_playlists_parses_payload(self) -> None:
        settings = _settings()
        settings.apple_music_developer_token = "dev-token"
        settings.apple_music_user_token = "user-token"
        provider = AppleMusicProvider(settings)
        provider.client = _FakeAppleClient(
            _FakeResponse(
                200,
                {},
                {
                    "data": [
                        {
                            "id": "p.1",
                            "attributes": {"name": "My Apple Playlist"},
                            "relationships": {"tracks": {"meta": {"total": 42}}},
                        }
                    ]
                },
            )
        )
        playlists = provider.fetch_user_playlists()
        self.assertEqual(len(playlists), 1)
        self.assertEqual(playlists[0].id, "p.1")
        self.assertEqual(playlists[0].tracks, 42)

    def test_apple_music_create_playlist_without_ids_returns_no_ids(self) -> None:
        settings = _settings()
        settings.apple_music_developer_token = "dev-token"
        settings.apple_music_user_token = "user-token"
        provider = AppleMusicProvider(settings)
        result = provider.create_playlist("name", "desc", [])
        self.assertFalse(result.created)
        self.assertEqual(result.reason, "no_ids")

    def test_tidal_playlist_accepts_wrapped_track_items(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalPlaylistSession([_FakeTidalPlaylistItem(_FakeTidalTrack())])

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 1)
        self.assertEqual(tracks[0].artist, "Artist")

    def test_tidal_playlist_accepts_dict_payloads_for_track_artist_and_album(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalPlaylistSession(
            [
                {
                    "track": {
                        "id": 123,
                        "name": "Dict Track",
                        "artists": [{"id": 456, "name": "Dict Artist"}],
                        "album": {"id": 789, "name": "Dict Album"},
                    }
                }
            ]
        )

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 1)
        self.assertEqual(tracks[0].artist, "Dict Artist")
        self.assertEqual(tracks[0].artists, ["Dict Artist"])
        self.assertEqual(tracks[0].track, "Dict Track")
        self.assertEqual(tracks[0].album, "Dict Album")
        self.assertEqual(tracks[0].tidal_track_id, "123")
        self.assertEqual(tracks[0].tidal_artist_ids, ["456"])
        self.assertEqual(tracks[0].tidal_album_id, "789")

    def test_tidal_playlist_paginates_all_pages(self) -> None:
        provider = TidalProvider(_settings())
        page1 = [_FakeTidalTrack(id=f"track-{idx}") for idx in range(100)]
        page2 = [_FakeTidalTrack(id=f"track-{100 + idx}") for idx in range(5)]
        provider._session = _FakeTidalPlaylistSession(page_items={0: page1, 100: page2})

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 105)
        self.assertEqual(tracks[0].tidal_track_id, "track-0")
        self.assertEqual(tracks[-1].tidal_track_id, "track-104")

    def test_tidal_playlist_deduplicates_track_ids_across_pages(self) -> None:
        provider = TidalProvider(_settings())
        page1 = [_FakeTidalTrack(id=f"track-{idx}") for idx in range(99)] + [_FakeTidalTrack(id="shared-track")]
        page2 = [_FakeTidalTrack(id="shared-track"), _FakeTidalTrack(id="unique-2")]
        provider._session = _FakeTidalPlaylistSession(page_items={0: page1, 100: page2})

        tracks = provider.fetch_playlist_tracks("playlist-id")

        track_ids = [track.tidal_track_id for track in tracks]
        self.assertEqual(track_ids.count("shared-track"), 1)
        self.assertIn("unique-2", track_ids)

    def test_tidal_playlist_retries_transient_page_failure(self) -> None:
        provider = TidalProvider(_settings())
        page1 = [_FakeTidalTrack(id=f"track-{idx}") for idx in range(100)]
        page2 = [_FakeTidalTrack(id="track-100")]
        provider._session = _FakeTidalPlaylistSession(
            page_items={0: page1, 100: page2},
            fail_once_offsets={100},
        )

        with patch("mamonia.providers.tidal.time.sleep", return_value=None):
            tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 101)
        self.assertEqual(provider._session.playlist_obj.calls_by_offset[100], 2)

    def test_tidal_playlist_raises_pagination_error_after_retry_exhaustion(self) -> None:
        provider = TidalProvider(_settings())
        page1 = [_FakeTidalTrack(id=f"track-{idx}") for idx in range(100)]
        provider._session = _FakeTidalPlaylistSession(
            page_items={0: page1},
            always_fail_offsets={100},
        )

        with patch("mamonia.providers.tidal.time.sleep", return_value=None):
            with self.assertRaises(ProviderUnavailable) as raised:
                provider.fetch_playlist_tracks("playlist-id")

        message = str(raised.exception)
        self.assertIn("pagination", message)
        self.assertIn("offset=100", message)
        self.assertIn("fetched_so_far=100", message)


    def test_tidal_ensure_session_returns_false_when_not_configured(self) -> None:
        settings = _settings()
        settings.tidal_client_id = ""
        settings.tidal_client_secret = ""
        provider = TidalProvider(settings)

        self.assertFalse(provider.ensure_session())

    def test_tidal_ensure_session_returns_true_when_session_exists(self) -> None:
        settings = _settings()
        settings.tidal_client_id = "tidal-id"
        settings.tidal_client_secret = "tidal-secret"
        provider = TidalProvider(settings)
        provider._session = _FakeTidalSession()

        self.assertTrue(provider.ensure_session())

    def test_tidal_create_playlist_adds_track_ids(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        provider._session = session

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", ["1", "2"])

        self.assertIsInstance(result, TidalPlaylistCreationResult)
        self.assertTrue(result.created)
        self.assertEqual(result.url, "https://tidal.com/browse/playlist/created-playlist")
        self.assertEqual(session.user.created.name, "Mamonia Test")
        self.assertEqual(session.user.created.description, "Generated by Mamonia.")
        self.assertEqual(session.user.created.added, ["1", "2"])

    def test_tidal_create_playlist_normalizes_wrapped_and_url_track_ids(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        provider._session = session

        result = provider.create_playlist(
            "Mamonia Test",
            "Generated by Mamonia.",
            ["<388084427>", "https://tidal.com/browse/track/12345?foo=bar", "tidal:track:abc-1"],
        )

        self.assertTrue(result.created)
        self.assertEqual(session.user.created.added, ["388084427", "12345", "abc-1"])

    def test_tidal_create_playlist_deduplicates_track_ids(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        provider._session = session

        result = provider.create_playlist(
            "Mamonia Test",
            "Generated by Mamonia.",
            ["12345", "12345", "<12345>"],
        )

        self.assertTrue(result.created)
        self.assertEqual(session.user.created.added, ["12345"])

    def test_tidal_create_playlist_without_ids_avoids_api_calls(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalSession()

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", [])

        self.assertFalse(result.created)
        self.assertEqual(result.reason, "no_ids")

    def test_tidal_fetch_user_playlists_returns_list(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalSession()

        playlists = provider.fetch_user_playlists()

        self.assertEqual(len(playlists), 1)
        self.assertEqual(playlists[0].id, "playlist-1")
        self.assertEqual(playlists[0].name, "Saved Tidal")
        self.assertEqual(playlists[0].tracks, 4)

    def test_tidal_fetch_album_by_id(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalSession()

        album = provider.fetch_album("509870858")

        self.assertIsNotNone(album)
        assert album is not None
        self.assertEqual(album.id, "509870858")
        self.assertEqual(album.name, "Fetched Album")

    def test_tidal_fetch_album_accepts_url_and_strips_suffix(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalSession()

        album = provider.fetch_album("https://tidal.com/album/509870858/u")

        self.assertIsNotNone(album)
        assert album is not None
        self.assertEqual(album.id, "509870858")
        self.assertEqual(album.name, "Fetched Album")

    def test_tidal_lookup_track_by_isrc_returns_match(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        session.search_results = [_FakeTidalTrack(id="track-isrc", isrc="ISRC123")]
        provider._session = session

        match = provider.lookup_track_by_isrc("ISRC123")

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "track-isrc")
        self.assertEqual(match.isrc, "ISRC123")

    def test_tidal_lookup_track_by_isrc_uses_current_openapi_tracks_filter(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        session.request = _FakeTidalOpenApiRequest(
            {
                "data": [
                    {
                        "id": "openapi-track",
                        "type": "tracks",
                        "attributes": {"title": "Open Track", "isrc": "ISRC123"},
                        "relationships": {
                            "artists": {"data": [{"id": "artist-1", "type": "artists"}]},
                            "albums": {"data": [{"id": "album-1", "type": "albums"}]},
                        },
                    }
                ],
                "included": [
                    {"id": "artist-1", "type": "artists", "attributes": {"name": "Open Artist"}},
                    {"id": "album-1", "type": "albums", "attributes": {"title": "Open Album"}},
                ],
            }
        )
        provider._session = session

        match = provider.lookup_track_by_isrc("ISRC123")

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "openapi-track")
        self.assertEqual(match.album_id, "album-1")
        self.assertEqual(match.artists, ["Open Artist"])
        self.assertEqual(session.request.calls[0]["path"], "tracks")
        self.assertEqual(session.request.calls[0]["params"]["filter[isrc]"], "ISRC123")

    def test_tidal_lookup_track_uses_current_openapi_search_relationship(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        session.request = _FakeTidalOpenApiRequest(
            [
                {
                    "data": [{"id": "openapi-track", "type": "tracks"}],
                    "included": [
                        {
                            "id": "openapi-track",
                            "type": "tracks",
                            "attributes": {"title": "Target Song", "isrc": "ISRC123"},
                        }
                    ],
                },
                {
                    "data": [
                        {
                            "id": "openapi-track",
                            "type": "tracks",
                            "attributes": {"title": "Target Song", "isrc": "ISRC123"},
                            "relationships": {
                                "artists": {"data": [{"id": "artist-1", "type": "artists"}]},
                                "albums": {"data": [{"id": "album-1", "type": "albums"}]},
                            },
                        },
                    ],
                    "included": [
                        {"id": "artist-1", "type": "artists", "attributes": {"name": "Target Artist"}},
                        {
                            "id": "album-1",
                            "type": "albums",
                            "attributes": {"title": "Target Album", "releaseDate": "2026-04-01"},
                        },
                    ],
                },
            ]
        )
        provider._session = session

        match = provider.lookup_track("Target Artist", "Target Song", "Target Album")

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "openapi-track")
        self.assertEqual(match.isrc, "ISRC123")
        self.assertIn("searchResults/Target%20Artist%20Target%20Song%20Target%20Album", session.request.calls[0]["path"])
        self.assertEqual(session.request.calls[1]["path"], "tracks")
        self.assertEqual(session.request.calls[1]["params"]["filter[id]"], "openapi-track")

    def test_tidal_lookup_track_prefers_exact_variant_title(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        base = _FakeTidalTrack(id="base-id")
        base.name = "Bass in Your Face"
        remix = _FakeTidalTrack(id="remix-id")
        remix.name = "Bass in Your Face (Cornish mix)"
        session.search_results = [base, remix]
        provider._session = session

        match = provider.lookup_track("Artist", "Bass in Your Face (Cornish mix)", "Bass In Your Face")

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "remix-id")

    def test_tidal_lookup_title_qualifier_match(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        candidate = _FakeTidalTrack(id="fard-id")
        candidate.name = "Fard (piano voix)"
        candidate.album.name = "PIANO-VOIX"
        candidate.artists = [_FakeTidalArtist(name="Mathilde Fernandez")]
        session.search_results = [candidate]
        provider._session = session

        match = provider.lookup_track("Mathilde Fernandez", "Fard", "PIANO-VOIX")

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "fard-id")

    def test_tidal_lookup_allows_album_title_when_artist_script_differs(self) -> None:
        provider = TidalProvider(_settings())
        session = _FakeTidalSession()
        candidate = _FakeTidalTrack(id="shimomura-id")
        candidate.name = "Dance of the Blocks (Yoko Shimomura Remix)"
        candidate.album.name = "Minecraft: Steve Rocks the Block (Original Soundtrack)"
        candidate.artists = [_FakeTidalArtist(name="Yoko Shimomura")]
        session.search_results = [candidate]
        provider._session = session

        match = provider.lookup_track(
            "下村陽子",
            "Dance of the Blocks (Yoko Shimomura Remix)",
            "Minecraft: Steve Rocks the Block (Original Soundtrack)",
        )

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "shimomura-id")

    def test_tidal_window_filters_out_old_strict_match(self) -> None:
        track = _FakeTidalTrack()
        track.album.release_date = "2018-01-01"

        in_window = _tidal_candidate_within_discovery_window(
            track,
            release_date="2026-03-01",
            discovery_months=6,
            discovery_today=dt.date(2026, 4, 29),
        )
        self.assertFalse(in_window)

    def test_tidal_window_allows_missing_album_date_for_strict_path(self) -> None:
        track = _FakeTidalTrack()
        track.album.release_date = None

        in_window = _tidal_candidate_within_discovery_window(
            track,
            release_date="2026-03-01",
            discovery_months=6,
            discovery_today=dt.date(2026, 4, 29),
            allow_missing_album_date=True,
        )
        self.assertTrue(in_window)

    def test_tidal_lookup_with_window_retries_shorter_queries_after_openapi_error(self) -> None:
        provider = TidalProvider(_settings())
        provider._session = _FakeTidalSession()
        candidate = _FakeTidalTrack(id="nf-sonore")
        candidate.name = "Non Fiction: I.I Sonore"
        candidate.album.name = "Non Fiction - Piano Concerto in Four Movements"
        candidate.album.release_date = "2025-11-14"
        candidate.artists = [_FakeTidalArtist(name="Hania Rani")]

        long_artist = "Hania Rani, Manchester Collective, Jack Wyllie, Valentina Magaletti & Hugh Tieppo-Brunt"

        def _fake_search(_session: object, query: str, *, limit: int) -> list[object]:
            if "Manchester Collective" in query:
                raise RuntimeError("400 bad request")
            if query.startswith("Hania Rani Non Fiction: I. Sonore"):
                return [candidate]
            return []

        with patch("mamonia.providers.tidal._search_tracks_current_or_legacy", side_effect=_fake_search):
            match = provider.lookup_track_with_window(
                artist=long_artist,
                title="Non Fiction: I. Sonore - Animato - Meno Mosso",
                album="Non Fiction - Piano Concerto in Four Movements",
                isrc=None,
                release_date="2025-11-14",
                discovery_months=6,
                discovery_today=dt.date(2026, 4, 30),
            )

        self.assertIsNotNone(match)
        assert match is not None
        self.assertEqual(match.track_id, "nf-sonore")


class ProviderFixtureTests(unittest.TestCase):
    def test_spotify_playlist_fixture_parses_to_input_tracks(self) -> None:
        provider = SpotifyProvider(_settings())
        provider._user_clients[SPOTIFY_READ_SCOPES] = _FixtureSpotifyPlaylistClient(_fixture("spotify_playlist_response.json"))

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual([track.artist for track in tracks], ["Example Artist", "Another Artist"])
        self.assertEqual([track.track for track in tracks], ["Example Track", "Another Track"])
        self.assertEqual([track.album for track in tracks], ["Example Album", "Another Album"])
        self.assertEqual(tracks[0].spotify_track_id, "track1")
        self.assertEqual(tracks[1].spotify_album_id, "album2")

    def test_spotify_empty_playlist_fixture_returns_no_tracks(self) -> None:
        provider = SpotifyProvider(_settings())
        provider._user_clients[SPOTIFY_READ_SCOPES] = _FixtureSpotifyPlaylistClient(_fixture("spotify_empty_playlist.json"))

        self.assertEqual(provider.fetch_playlist_tracks("playlist-id"), [])

    def test_spotify_malformed_playlist_fixture_skips_unusable_items(self) -> None:
        provider = SpotifyProvider(_settings())
        provider._user_clients[SPOTIFY_READ_SCOPES] = _FixtureSpotifyPlaylistClient(_fixture("spotify_malformed_payload.json"))

        self.assertEqual(provider.fetch_playlist_tracks("playlist-id"), [])

    def test_spotify_rate_limit_fixture_drives_provider_error(self) -> None:
        fixture = _fixture("spotify_rate_limit_429.json")
        provider = SpotifyProvider(_settings())
        provider._user_clients[SPOTIFY_READ_SCOPES] = _FakeSpotifyClient(
            _FakeProviderError(
                fixture["error"]["status"],
                fixture["headers"],
                fixture["error"]["message"],
            )
        )

        with self.assertRaises(ProviderRateLimit) as raised:
            provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(raised.exception.provider, "Spotify")
        self.assertEqual(raised.exception.retry_after_seconds, 62929)

    def test_lastfm_top_tags_fixture_parses_names(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("lastfm_top_tags_response.json")))
        provider._last_request_at = -999.0

        self.assertEqual(provider.top_tags("Example Artist"), ["rock", "electronic"])

    def test_lastfm_top_tags_fixture_is_cached(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=storage)
            provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("lastfm_top_tags_response.json")))
            provider._last_request_at = -999.0

            self.assertEqual(provider.top_tags("Example Artist"), ["rock", "electronic"])
            self.assertEqual(provider.top_tags("Example Artist"), ["rock", "electronic"])

            self.assertEqual(provider.client.calls, 1)
            storage.close()

    def test_lastfm_cache_key_normalization_ignores_parameter_order(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=storage)
            provider.client = _FakeHttpClient(_FakeResponse(200, {}, {"similarartists": {"artist": []}}))
            provider._last_request_at = -999.0

            first = provider._call("artist.getSimilar", artist="Example Artist", autocorrect=1, limit=5)
            second = provider._call("artist.getSimilar", limit=5, autocorrect=1, artist="Example Artist")
            storage.close()

        self.assertEqual(first, second)
        self.assertEqual(provider.client.calls, 1)

    def test_lastfm_force_refresh_bypasses_cached_response(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            settings = _settings(lastfm_api_key="lastfm-key")
            settings.force_refresh = True
            provider = LastFMProvider(settings, storage=storage)
            provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("lastfm_top_tags_response.json")))
            provider._last_request_at = -999.0

            self.assertEqual(provider.top_tags("Example Artist"), ["rock", "electronic"])
            self.assertEqual(provider.top_tags("Example Artist"), ["rock", "electronic"])
            storage.close()

        self.assertEqual(provider.client.calls, 2)

    def test_lastfm_rate_limit_fixture_records_provider_warning(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("lastfm_rate_limit_429.json")))
        provider._last_request_at = -999.0

        self.assertEqual(provider.top_tags("Example Artist"), [])
        self.assertEqual(provider.rate_limit_warnings[0].provider, "Last.fm")
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_lastfm_malformed_fixture_returns_empty_tags(self) -> None:
        provider = LastFMProvider(_settings(lastfm_api_key="lastfm-key"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("lastfm_malformed_response.json")))
        provider._last_request_at = -999.0

        self.assertEqual(provider.top_tags("Example Artist"), [])
        self.assertEqual(provider.rate_limit_warnings, [])

    def test_listenbrainz_listen_history_fetches_and_parses(self) -> None:
        provider = ListenBrainzProvider(_settings(listenbrainz_user_token="test-token"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("listenbrainz_listen_history.json")))
        provider._last_request_at = -999.0

        result = provider.user_listen_history("test-user", 100)

        self.assertIsNotNone(result)
        self.assertEqual(result["payload"]["listens"][0]["track_metadata"]["artist_name"], "Artist One")

    def test_listenbrainz_unavailable_without_token(self) -> None:
        provider = ListenBrainzProvider(_settings(), storage=None)

        self.assertFalse(provider.available)
        self.assertIsNone(provider.user_listen_history("test-user"))

    def test_listenbrainz_token_is_sent_only_to_listenbrainz_headers(self) -> None:
        provider = ListenBrainzProvider(_settings(listenbrainz_user_token="test-token"), storage=None)
        provider.client = _RecordingHttpClient(_FakeResponse(200, {}, {"payload": {"artists": []}}))
        provider._last_request_at = -999.0

        result = provider.user_top_artists("test-user")

        self.assertEqual(result, {})
        self.assertTrue(provider.client.last_url.startswith("https://api.listenbrainz.org/1/"))
        self.assertEqual(provider.client.last_kwargs["headers"], {"Authorization": "Token test-token"})

    def test_listenbrainz_rate_limit_records_warning(self) -> None:
        provider = ListenBrainzProvider(_settings(listenbrainz_user_token="test-token"), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(429, {"Retry-After": "120"}, {}))
        provider._last_request_at = -999.0

        result = provider.user_listen_history("test-user")

        self.assertIsNone(result)
        self.assertEqual(provider.rate_limit_warnings[0].provider, "ListenBrainz")
        self.assertEqual(provider.rate_limit_warnings[0].retry_after_seconds, 120)
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_deezer_artist_search_returns_first_result(self) -> None:
        provider = DeezerProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("deezer_artist.json")))
        provider._last_request_at = -999.0

        result = provider.search_artist("Test Artist")

        self.assertIsNotNone(result)
        self.assertEqual(result["name"], "Test Artist")
        self.assertEqual(result["id"], 123)

    def test_deezer_always_available(self) -> None:
        provider = DeezerProvider(_settings(), storage=None)

        self.assertTrue(provider.available)

    def test_deezer_rate_limit_records_warning(self) -> None:
        provider = DeezerProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(429, {"Retry-After": "120"}, {}))
        provider._last_request_at = -999.0

        result = provider.search_artist("Test Artist")

        self.assertIsNone(result)
        self.assertEqual(provider.rate_limit_warnings[0].provider, "Deezer")
        self.assertEqual(provider.rate_limit_warnings[0].retry_after_seconds, 120)
        self.assertTrue(provider._disabled_by_rate_limit)

    def test_musicbrainz_artist_fixture_parses_search_result(self) -> None:
        provider = MusicBrainzProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("musicbrainz_artist_response.json")))
        provider._last_request_at = -999.0

        artist = provider.search_artist("Example Artist")

        self.assertEqual(artist["id"], "artist1")
        self.assertEqual(artist["name"], "Example Artist")
        self.assertEqual(artist["type"], "Group")

    def test_musicbrainz_artist_search_falls_back_to_relaxed_query(self) -> None:
        provider = MusicBrainzProvider(_settings(), storage=None)
        provider._last_request_at = -999.0
        with patch.object(
            provider,
            "_get",
            side_effect=[
                {"artists": []},
                {"artists": [{"id": "fisz-id", "name": "Fisz", "score": "100", "type": "Person", "tags": []}]},
            ],
        ):
            artist = provider.search_artist("Fisz")
        self.assertIsNotNone(artist)
        assert artist is not None
        self.assertEqual(artist["id"], "fisz-id")
        self.assertEqual(artist["name"], "Fisz")

    def test_musicbrainz_artist_fixture_is_cached(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = MusicBrainzProvider(_settings(), storage=storage)
            provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("musicbrainz_artist_response.json")))
            provider._last_request_at = -999.0

            self.assertEqual(provider.search_artist("Example Artist")["id"], "artist1")
            self.assertEqual(provider.search_artist("Example Artist")["id"], "artist1")

            self.assertEqual(provider.client.calls, 1)
            storage.close()

    @pytest.mark.slow
    def test_musicbrainz_malformed_fixture_returns_no_artist(self) -> None:
        provider = MusicBrainzProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(200, {}, _fixture("musicbrainz_malformed_response.json")))
        provider._last_request_at = -999.0

        with patch.object(provider, "_respect_rate_limit"):
            self.assertIsNone(provider.search_artist("Example Artist"))
        self.assertEqual(provider.rate_limit_warnings, [])

    @pytest.mark.slow
    def test_musicbrainz_rate_limit_fixture_records_provider_warning(self) -> None:
        provider = MusicBrainzProvider(_settings(), storage=None)
        provider.client = _FakeHttpClient(_FakeResponse(429, {"Retry-After": "90"}, _fixture("musicbrainz_rate_limit_429.json")))
        provider._last_request_at = -999.0

        with patch.object(provider, "_respect_rate_limit"):
            self.assertIsNone(provider.search_artist("Example Artist"))
        self.assertEqual(provider.rate_limit_warnings[0].provider, "MusicBrainz")
        self.assertEqual(provider.rate_limit_warnings[0].retry_after_seconds, 90)

    def test_spotify_rate_limit_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "spotify_rate_limit_429.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertEqual(fixture["error"]["status"], 429)
        self.assertEqual(fixture["headers"]["Retry-After"], "62929")

    def test_spotify_playlist_response_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "spotify_playlist_response.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("items", fixture)
        self.assertGreater(len(fixture["items"]), 0)

    def test_spotify_missing_credentials_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "spotify_missing_credentials.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertEqual(fixture["error"]["status"], 401)

    def test_lastfm_rate_limit_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "lastfm_rate_limit_429.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertEqual(fixture["error"], 29)
        self.assertEqual(fixture["message"], "Rate Limit Exceeded")

    def test_lastfm_top_tags_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "lastfm_top_tags_response.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("toptags", fixture)

    def test_musicbrainz_rate_limit_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "musicbrainz_rate_limit_429.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("error", fixture)

    def test_musicbrainz_artist_response_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "musicbrainz_artist_response.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("artists", fixture)

    def test_spotify_malformed_payload_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "spotify_malformed_payload.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("items", fixture)

    def test_lastfm_malformed_response_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "lastfm_malformed_response.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("error", fixture)

    def test_musicbrainz_malformed_response_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "musicbrainz_malformed_response.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertIn("error", fixture)

    def test_spotify_empty_playlist_fixture_exists(self) -> None:
        fixture_path = FIXTURES_DIR / "spotify_empty_playlist.json"
        self.assertTrue(fixture_path.exists())
        fixture = json.loads(fixture_path.read_text())
        self.assertEqual(fixture["items"], [])


class _FakeProviderError(Exception):
    def __init__(self, http_status: int, headers: dict[str, str], message: str, response_message: str | None = None):
        super().__init__(message)
        self.http_status = http_status
        self.headers = headers
        self._response_message = response_message

    @property
    def response(self):
        if self._response_message is None:
            return None

        class _Response:
            def __init__(self, status_code: int, headers: dict[str, str], message: str):
                self.status_code = status_code
                self.headers = headers
                self._message = message

            def json(self):
                return {"error": {"status": self.status_code, "message": self._message}}

        return _Response(self.http_status, self.headers, self._response_message)


class _FakeSpotifyClient:
    def __init__(self, exc: Exception):
        self.exc = exc

    def playlist_items(self, *args, **kwargs):
        raise self.exc


class _FixtureSpotifyPlaylistClient:
    def __init__(self, payload: dict):
        self.payload = payload

    def playlist_items(self, *args, **kwargs):
        return self.payload


class _FakeSpotifySearchClient:
    def __init__(self, exc: Exception):
        self.exc = exc

    def search(self, *args, **kwargs):
        raise self.exc


class _FakeHttpClient:
    def __init__(self, response: _FakeResponse):
        self.response = response
        self.calls = 0

    def get(self, *args, **kwargs):
        self.calls += 1
        return self.response


class _RecordingHttpClient(_FakeHttpClient):
    def __init__(self, response: _FakeResponse):
        super().__init__(response)
        self.last_url = ""
        self.last_kwargs = {}

    def get(self, url, **kwargs):
        self.last_url = url
        self.last_kwargs = kwargs
        return super().get(url, **kwargs)


class _FakeResponse:
    def __init__(self, status_code: int, headers: dict[str, str], payload: dict):
        self.status_code = status_code
        self.headers = headers
        self.payload = payload

    def json(self):
        return self.payload

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class _FakeAppleClient:
    def __init__(self, response: _FakeResponse):
        self.response = response

    def get(self, *args, **kwargs):
        return self.response

    def request(self, *args, **kwargs):
        return self.response


class _FakeTidalConfig:
    client_id = ""
    client_secret = ""


class _FakeTidalSession:
    def __init__(self):
        self.config = _FakeTidalConfig()
        self.session_file = None
        self.do_pkce = False
        self.logged_in = False
        self.user = _FakeTidalUser()
        self.search_results = []

    def login_session_file(self, session_file, do_pkce=False, fn_print=print):
        self.session_file = session_file
        self.do_pkce = do_pkce
        self.logged_in = True
        return True

    def search(self, *args, **kwargs):
        return {"tracks": self.search_results}

    def album(self, album_id):
        return _FakeFetchedTidalAlbum(str(album_id))


class _FakeTidalOpenApiRequest:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def request(self, method, path, params=None, data=None, headers=None, base_url=None):
        self.calls.append(
            {
                "method": method,
                "path": path,
                "params": params or {},
                "data": data,
                "headers": headers or {},
                "base_url": base_url,
            }
        )
        if isinstance(self.payload, list):
            index = min(len(self.calls) - 1, len(self.payload) - 1)
            payload = self.payload[index]
        else:
            payload = self.payload
        return _FakeTidalOpenApiResponse(payload)


class _FakeTidalOpenApiResponse:
    def __init__(self, payload):
        self.payload = payload

    def json(self):
        return self.payload


class _FakeTidalUser:
    def __init__(self):
        self.created = None

    def create_playlist(self, name, description):
        self.created = _FakeCreatedTidalPlaylist(name, description)
        return self.created

    def playlists(self):
        return [_FakeTidalUserPlaylist()]


class _FakeTidalUserPlaylist:
    id = "playlist-1"
    name = "Saved Tidal"
    num_tracks = 4


class _FakeCreatedTidalPlaylist:
    id = "created-playlist"

    def __init__(self, name, description):
        self.name = name
        self.description = description
        self.added = []

    def add(self, track_ids):
        self.added = list(track_ids)


class _FakeTidalPlaylistSession:
    def __init__(
        self,
        items=None,
        *,
        page_items: dict[int, list[Any]] | None = None,
        page_size: int = 100,
        fail_once_offsets: set[int] | None = None,
        always_fail_offsets: set[int] | None = None,
    ):
        self._items = items
        self.playlist_obj = _FakeTidalPlaylist(
            items=items,
            page_items=page_items,
            page_size=page_size,
            fail_once_offsets=fail_once_offsets,
            always_fail_offsets=always_fail_offsets,
        )

    def playlist(self, playlist_id):
        return self.playlist_obj


class _FakeTidalPlaylist:
    def __init__(
        self,
        *,
        items=None,
        page_items: dict[int, list[Any]] | None = None,
        page_size: int = 100,
        fail_once_offsets: set[int] | None = None,
        always_fail_offsets: set[int] | None = None,
    ):
        self._items = items
        self._page_items = page_items
        self._page_size = page_size
        self._fail_once_offsets = set(fail_once_offsets or set())
        self._always_fail_offsets = set(always_fail_offsets or set())
        self.calls_by_offset: dict[int, int] = {}

    def items(self, limit=None, offset=None):
        if self._page_items is None:
            return self._items
        resolved_limit = int(limit or self._page_size)
        resolved_offset = int(offset or 0)
        self.calls_by_offset[resolved_offset] = self.calls_by_offset.get(resolved_offset, 0) + 1
        if resolved_offset in self._always_fail_offsets:
            raise RuntimeError(f"forced persistent failure for offset {resolved_offset}")
        if resolved_offset in self._fail_once_offsets:
            self._fail_once_offsets.remove(resolved_offset)
            raise RuntimeError(f"forced transient failure for offset {resolved_offset}")
        page = list(self._page_items.get(resolved_offset, []))
        return page[:resolved_limit]


class _FakeTidalPlaylistItem:
    def __init__(self, track):
        self.track = track


class _FakeTidalTrack:
    name = "Track"
    artists = []

    def __init__(self, id="track-id", isrc=None):
        self.id = id
        self.isrc = isrc
        self.artists = [_FakeTidalArtist()]
        self.album = _FakeTidalAlbum()


class _FakeTidalArtist:
    def __init__(self, id="artist-id", name="Artist"):
        self.id = id
        self.name = name


class _FakeTidalAlbum:
    id = "album-id"
    name = "Album"


class _FakeFetchedTidalAlbum:
    def __init__(self, album_id: str):
        self.id = album_id
        self.name = "Fetched Album"


class _LegacyLoginOnlySession:
    def login(self):
        return True


def _settings(lastfm_api_key: str = "", listenbrainz_user_token: str = "") -> Settings:
    tmp = Path(tempfile.gettempdir()) / "mamonia-provider-tests"
    return Settings(
        data_dir=tmp,
        db_path=tmp / "mamonia.sqlite",
        spotify_client_id="spotify-id",
        spotify_client_secret="spotify-secret",
        lastfm_api_key=lastfm_api_key,
        listenbrainz_user_token=listenbrainz_user_token,
        mb_contact="tester@example.com",
    )


def _fixture(name: str) -> dict:
    return json.loads((FIXTURES_DIR / name).read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
