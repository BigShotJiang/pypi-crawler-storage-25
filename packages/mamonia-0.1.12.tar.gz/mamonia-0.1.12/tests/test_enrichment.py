"""Tests for mamonia/enrichment.py — track enrichment functions."""

from __future__ import annotations

import datetime as dt
import unittest
from unittest.mock import MagicMock

import pytest

from mamonia.enrichment import (
    _attach_spotify_tracks,
    _attach_musicbrainz_tracks,
    _backfill_isrc_from_fallbacks,
    _backfill_musicbrainz_tracks,
    _enrich_tracks_with_musicbrainz,
    _track_resolution_score,
    _track_source_priority,
    enrich_recommendation_tracks,
    filter_seed_tracks,
    track_key,
)
from mamonia.models import InputTrack, ReleaseRecommendation, ReleaseTrack

SEED_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
ARTIST_MBID = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
RG_MBID = "c3d4e5f6-a7b8-9012-cdef-123456789012"


# ---------------------------------------------------------------------------
# track_key — parametrized (was 5 separate tests)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("artist,title,expected", [
    ("The Beatles", "Hey Jude", "the beatles|hey jude"),
    (None, "Hey Jude", "hey jude"),
    ("The Beatles", None, "the beatles"),
    (None, None, ""),
    ("  The Beatles  ", "  Hey Jude  ", "the beatles|hey jude"),
])
def test_track_key(artist: str | None, title: str | None, expected: str) -> None:
    assert track_key(artist, title) == expected


class TestFilterSeedTracks(unittest.TestCase):
    """Tests for filter_seed_tracks() function."""

    def test_filter_seed_tracks_no_keys(self):
        """filter_seed_tracks returns all tracks when no keys provided."""
        tracks = [
            ReleaseTrack(title="Track 1", artists="Artist"),
            ReleaseTrack(title="Track 2", artists="Artist"),
        ]
        result = filter_seed_tracks(tracks, set())
        self.assertEqual(len(result), 2)

    def test_filter_seed_tracks_excludes_matching(self):
        """filter_seed_tracks removes tracks matching seed keys."""
        tracks = [
            ReleaseTrack(
                title="Teardrop",
                artists="Massive Attack",
                isrc="US1234567890",
                spotify_track_id="spotify:track:abc123",
            ),
            ReleaseTrack(title="Track 2", artists="Artist"),
        ]
        seed_keys = {
            "massive attack|teardrop",
            "isrc:us1234567890",
            "spotify:track:abc123",
        }
        result = filter_seed_tracks(tracks, seed_keys)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].title, "Track 2")

    def test_filter_seed_tracks_preserves_non_matching(self):
        """filter_seed_tracks keeps tracks that don't match seeds."""
        tracks = [
            ReleaseTrack(title="Track 1", artists="Artist"),
            ReleaseTrack(title="Track 2", artists="Artist"),
        ]
        seed_keys = {"other artist|other track"}
        result = filter_seed_tracks(tracks, seed_keys)
        self.assertEqual(len(result), 2)


class TestEnrichRecommendationTracks(unittest.TestCase):
    """Tests for enrich_recommendation_tracks() function."""

    def test_enrich_with_spotify(self):
        """enrich_recommendation_tracks populates tracks from Spotify."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[],
        )
        sp = MagicMock()
        sp.representative_tracks.return_value = (
            "album-id-123",
            "spotify:album:abc123",
            [
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    spotify_track_id="spotify:track:abc123",
                    isrc="US1234567890",
                    resolution_source="spotify_album_tracklist",
                ),
            ],
        )
        sp.backfill_release_tracks = MagicMock(
            side_effect=lambda title, tracks, **kwargs: tracks
        )
        enrich_recommendation_tracks(rec, spotify=sp, max_tracks=3)
        self.assertGreater(len(rec.tracks), 0)
        self.assertEqual(rec.tracks[0].spotify_track_id, "spotify:track:abc123")

    def test_enrich_with_musicbrainz_fallback(self):
        """enrich_recommendation_tracks uses MusicBrainz when Spotify misses."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[],
        )
        mb = MagicMock()
        mb.release_tracks_for_group.return_value = [
            ReleaseTrack(
                title="Track 1",
                artists="Test Artist",
                track_number=1,
                duration=200000,
                isrc="US1234567890",
            ),
        ]
        enrich_recommendation_tracks(rec, musicbrainz=mb, max_tracks=3)
        self.assertGreater(len(rec.tracks), 0)
        self.assertEqual(rec.tracks[0].isrc, "US1234567890")
        self.assertIn("musicbrainz", rec.tracks[0].resolution_source or "")

    def test_enrich_with_isrc_resolver(self):
        """enrich_recommendation_tracks backfills ISRC via resolver."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    isrc=None,
                ),
            ],
        )
        isrc_resolver = MagicMock()
        isrc_resolver.resolve_track.return_value = MagicMock(
            resolved=True,
            isrc="US1234567890",
            provider="tidal",
        )
        enrich_recommendation_tracks(rec, isrc_resolver=isrc_resolver, max_tracks=3)
        self.assertEqual(rec.tracks[0].isrc, "US1234567890")
        self.assertEqual(rec.tracks[0].isrc_source, "tidal")

    def test_enrich_with_spotify_backfill(self):
        """enrich_recommendation_tracks backfills MB tracks with Spotify IDs."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    resolution_source="musicbrainz_tracklist",
                ),
            ],
        )
        sp = MagicMock()
        sp.backfill_release_tracks.return_value = [
            ReleaseTrack(
                title="Track 1",
                artists="Test Artist",
                track_number=1,
                resolution_source="musicbrainz_tracklist",
                spotify_track_id="spotify:track:abc123",
            ),
        ]
        enrich_recommendation_tracks(rec, spotify=sp, max_tracks=3)
        self.assertEqual(rec.tracks[0].spotify_track_id, "spotify:track:abc123")

    def test_enrich_with_seed_track_filtering(self):
        """enrich_recommendation_tracks filters out seed tracks."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[
                ReleaseTrack(
                    title="Teardrop",
                    artists="Massive Attack",
                    isrc="US1234567890",
                ),
            ],
        )
        seed_keys = {"massive attack|teardrop"}
        enrich_recommendation_tracks(
            rec, max_tracks=3, seed_track_keys=seed_keys
        )
        self.assertEqual(len(rec.tracks), 0)

    def test_enrich_recovers_spotify_matches_after_mb_fallback(self):
        rec = ReleaseRecommendation(
            artist="Clark",
            title="Modal Stims",
            mb_release_group_id=RG_MBID,
            tracks=[],
        )
        mb = MagicMock()
        mb.release_tracks_for_group.return_value = [
            ReleaseTrack(title="Houdini Modal", artists="Clark", track_number=1, resolution_source="musicbrainz_tracklist"),
            ReleaseTrack(title="No Pills U", artists="Clark", track_number=2, resolution_source="musicbrainz_tracklist"),
        ]
        sp = MagicMock()
        # Initial strict album path misses.
        sp.representative_tracks.side_effect = [
            (None, None, []),
            (
                "album-id-123",
                "spotify:album:abc123",
                [
                    ReleaseTrack(
                        title="Houdini Modal",
                        artists="Clark",
                        spotify_track_id="spotify:track:1",
                        spotify_uri="spotify:track:1",
                    ),
                    ReleaseTrack(
                        title="No Pills U",
                        artists="Clark",
                        spotify_track_id="spotify:track:2",
                        spotify_uri="spotify:track:2",
                    ),
                ],
            ),
        ]
        sp.backfill_release_tracks.return_value = mb.release_tracks_for_group.return_value

        enrich_recommendation_tracks(rec, spotify=sp, musicbrainz=mb, max_tracks=3)

        self.assertEqual(len(rec.tracks), 2)
        self.assertTrue(all(track.spotify_uri for track in rec.tracks))

    def test_enrich_rescue_passes_discovery_window_to_spotify_lookup(self):
        rec = ReleaseRecommendation(
            artist="Massive Attack",
            title="Boots on The Ground",
            release_date="2026-04-20",
            tracks=[
                ReleaseTrack(
                    title="Boots on the Ground",
                    artists="Massive Attack",
                    resolution_source="musicbrainz_tracklist",
                ),
            ],
        )
        sp = MagicMock()
        sp.backfill_release_tracks.return_value = rec.tracks
        sp.representative_tracks.return_value = (
            "album-2024",
            "spotify:album:album-2024",
            [
                ReleaseTrack(
                    title="Boots on the Ground",
                    artists="803Fresh",
                    spotify_track_id="spotify:track:wrong",
                    spotify_uri="spotify:track:wrong",
                )
            ],
        )

        enrich_recommendation_tracks(
            rec,
            spotify=sp,
            max_tracks=3,
            discovery_months=6,
            discovery_today=dt.date(2026, 4, 30),
        )

        self.assertEqual(sp.representative_tracks.call_args_list[-1].kwargs["release_date"], "2026-04-20")
        self.assertEqual(sp.representative_tracks.call_args_list[-1].kwargs["discovery_months"], 6)
        self.assertEqual(sp.representative_tracks.call_args_list[-1].kwargs["discovery_today"], dt.date(2026, 4, 30))

    def test_enrich_rescue_uses_musicbrainz_track_release_date_for_window_guard(self):
        rec = ReleaseRecommendation(
            artist="Massive Attack",
            title="Boots on The Ground",
            release_date="2026-04-20",
            tracks=[
                ReleaseTrack(
                    title="Boots on the Ground",
                    artists="Massive Attack",
                    release_date="2024-05-01",
                    resolution_source="musicbrainz_tracklist",
                ),
            ],
        )
        sp = MagicMock()
        sp.backfill_release_tracks.return_value = rec.tracks
        sp.representative_tracks.return_value = (
            "album-2024",
            "spotify:album:album-2024",
            [
                ReleaseTrack(
                    title="Boots on the Ground",
                    artists="Massive Attack",
                    spotify_track_id="spotify:track:wrong",
                    spotify_uri="spotify:track:wrong",
                )
            ],
        )

        enrich_recommendation_tracks(
            rec,
            spotify=sp,
            max_tracks=3,
            discovery_months=6,
            discovery_today=dt.date(2026, 4, 30),
        )

        self.assertEqual(rec.tracks[0].spotify_track_id, "spotify:track:wrong")

    def test_post_selection_prefers_title_match_then_popularity(self):
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Anchor Song",
            tracks=[
                ReleaseTrack(title="Other One", artists="Artist", track_number=1),
                ReleaseTrack(title="Anchor Song", artists="Artist", track_number=3),
                ReleaseTrack(title="Other Two", artists="Artist", track_number=2),
            ],
        )
        lastfm = MagicMock()
        lastfm.available = True

        def _pop(artist: str, title: str):
            return {
                "Other One": {"listeners": 10, "playcount": 20},
                "Other Two": {"listeners": 50, "playcount": 80},
            }.get(title)

        lastfm.track_popularity.side_effect = _pop
        enrich_recommendation_tracks(rec, lastfm=lastfm, max_tracks=2)
        self.assertEqual([track.title for track in rec.tracks], ["Other Two", "Anchor Song"])
        self.assertEqual(rec.explanation.get("picked_tracks_reason"), "title-match+popularity")
        self.assertEqual(rec.explanation.get("popularity_provider"), "lastfm")

    def test_post_selection_preserves_order_when_max_tracks_gte_total(self):
        """When max_tracks >= total tracks, original tracklist order is preserved."""
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Release",
            tracks=[
                ReleaseTrack(title="Track 1", artists="Artist", track_number=1),
                ReleaseTrack(title="Track 2", artists="Artist", track_number=2),
                ReleaseTrack(title="Track 3", artists="Artist", track_number=3),
            ],
        )
        lastfm = MagicMock()
        lastfm.available = True
        lastfm.track_popularity.return_value = None
        # max_tracks=5 is >= total tracks (3)
        enrich_recommendation_tracks(rec, lastfm=lastfm, max_tracks=5)
        # All tracks should be present in their original order
        self.assertEqual(len(rec.tracks), 3)
        self.assertEqual([track.title for track in rec.tracks], ["Track 1", "Track 2", "Track 3"])

    def test_post_selection_preserves_original_order_when_max_tracks_is_zero(self):
        """When max_tracks=0, keep all tracks in provider/original order."""
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Release",
            tracks=[
                ReleaseTrack(title="Third", artists="Artist", track_number=3),
                ReleaseTrack(title="First", artists="Artist", track_number=1),
                ReleaseTrack(title="Second", artists="Artist", track_number=2),
            ],
        )
        lastfm = MagicMock()
        lastfm.available = True
        lastfm.track_popularity.return_value = None

        enrich_recommendation_tracks(rec, lastfm=lastfm, max_tracks=0)

        self.assertEqual(len(rec.tracks), 3)
        self.assertEqual([track.title for track in rec.tracks], ["Third", "First", "Second"])

    def test_popularity_provider_precedence_listenbrainz_before_lastfm(self):
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Release",
            tracks=[ReleaseTrack(title="Track A", artists="Artist", isrc="ISRC123", track_number=1)],
        )
        musicbrainz = MagicMock()
        musicbrainz.lookup_recording_by_isrc.return_value = {"recording_mbid": "rec-mbid-1"}
        listenbrainz = MagicMock()
        listenbrainz.available = True
        listenbrainz.recording_popularity.return_value = {
            "rec-mbid-1": {"total_listen_count": 999, "total_user_count": 10}
        }
        lastfm = MagicMock()
        lastfm.available = True
        lastfm.track_popularity.return_value = {"listeners": 1, "playcount": 1}
        enrich_recommendation_tracks(
            rec,
            musicbrainz=musicbrainz,
            listenbrainz=listenbrainz,
            lastfm=lastfm,
            max_tracks=1,
        )
        self.assertEqual(rec.tracks[0].popularity_provider, "listenbrainz")
        self.assertEqual(rec.explanation.get("popularity_provider"), "listenbrainz")


class TestEnrichTracksWithMusicBrainz(unittest.TestCase):
    """Tests for _enrich_tracks_with_musicbrainz() function."""

    def test_merge_prefers_spotify_data(self):
        """_enrich_tracks_with_musicbrainz prefers Spotify data when available."""
        spotify_tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                track_number=1,
                isrc="spotify-isrc",
            ),
        ]
        mb_tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                track_number=1,
                isrc="mb-isrc",
            ),
        ]
        result = _enrich_tracks_with_musicbrainz(spotify_tracks, mb_tracks)
        self.assertEqual(result[0].isrc, "spotify-isrc")

    def test_merge_copies_mb_isrc_when_spotify_missing(self):
        """_enrich_tracks_with_musicbrainz copies ISRC from MB when Spotify lacks it."""
        spotify_tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                track_number=1,
                isrc=None,
            ),
        ]
        mb_tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                track_number=1,
                isrc="mb-isrc",
            ),
        ]
        result = _enrich_tracks_with_musicbrainz(spotify_tracks, mb_tracks)
        self.assertEqual(result[0].isrc, "mb-isrc")

    def test_merge_appends_unmatched_mb_tracks(self):
        """_enrich_tracks_with_musicbrainz appends unmatched MB tracks."""
        spotify_tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                track_number=1,
            ),
        ]
        mb_tracks = [
            ReleaseTrack(
                title="Track 2",
                artists="Artist",
                track_number=2,
            ),
        ]
        result = _enrich_tracks_with_musicbrainz(spotify_tracks, mb_tracks)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[1].title, "Track 2")


class TestBackfillMusicBrainzTracks(unittest.TestCase):
    """Tests for _backfill_musicbrainz_tracks() function."""

    def test_backfill_adds_spotify_ids(self):
        """_backfill_musicbrainz_tracks adds Spotify IDs to MB tracks."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    resolution_source="musicbrainz_tracklist",
                ),
            ],
        )
        sp = MagicMock()
        sp.backfill_release_tracks.return_value = [
            ReleaseTrack(
                title="Track 1",
                artists="Test Artist",
                track_number=1,
                resolution_source="musicbrainz_tracklist",
                spotify_track_id="spotify:track:abc123",
            ),
        ]
        _backfill_musicbrainz_tracks(rec, sp)
        self.assertEqual(rec.tracks[0].spotify_track_id, "spotify:track:abc123")

    def test_backfill_no_spotify(self):
        """_backfill_musicbrainz_tracks handles None Spotify."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            tracks=[],
        )
        _backfill_musicbrainz_tracks(rec, None)
        self.assertEqual(len(rec.tracks), 0)


class TestBackfillISRCFromFallbacks(unittest.TestCase):
    """Tests for _backfill_isrc_from_fallbacks() function."""

    def test_backfill_isrc_via_resolver(self):
        """_backfill_isrc_from_fallbacks calls ISRC resolver."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    isrc=None,
                ),
            ],
        )
        isrc_resolver = MagicMock()
        isrc_resolver.resolve_track.return_value = MagicMock(
            resolved=True,
            isrc="US1234567890",
            provider="tidal",
        )
        _backfill_isrc_from_fallbacks(rec, isrc_resolver)
        self.assertEqual(rec.tracks[0].isrc, "US1234567890")
        self.assertEqual(rec.tracks[0].isrc_source, "tidal")

    def test_backfill_skips_tracks_with_isrc(self):
        """_backfill_isrc_from_fallbacks skips tracks that already have ISRC."""
        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    isrc="already-have-isrc",
                ),
            ],
        )
        isrc_resolver = MagicMock()
        isrc_resolver.resolve_track.return_value = MagicMock(
            resolved=True,
            isrc="US1234567890",
            provider="tidal",
        )
        _backfill_isrc_from_fallbacks(rec, isrc_resolver)
        self.assertEqual(rec.tracks[0].isrc, "already-have-isrc")
        isrc_resolver.resolve_track.assert_not_called()


class TestTrackResolutionScore(unittest.TestCase):
    """Tests for _track_resolution_score() function."""

    def test_score_counts_spotify_resolved(self):
        """_track_resolution_score counts Spotify-resolved tracks."""
        tracks = [
            ReleaseTrack(title="Track 1", artists="Artist", spotify_track_id="spotify:track:1"),
            ReleaseTrack(title="Track 2", artists="Artist"),
            ReleaseTrack(title="Track 3", artists="Artist", spotify_track_id="spotify:track:3"),
        ]
        spotify_count, priority = _track_resolution_score(tracks)
        self.assertEqual(spotify_count, 2)

    def test_score_prefers_spotify_source(self):
        """_track_resolution_score prefers Spotify source priority."""
        tracks = [
            ReleaseTrack(
                title="Track 1",
                artists="Artist",
                resolution_source="musicbrainz_tracklist",
            ),
        ]
        spotify_count, priority = _track_resolution_score(tracks)
        self.assertEqual(priority, 1)


class TestTrackSourcePriority(unittest.TestCase):
    """Tests for _track_source_priority() function."""

    def test_spotify_album_tracklist_highest(self):
        """_track_source_priority gives highest score to Spotify album tracklist."""
        track = ReleaseTrack(
            title="Track 1",
            artists="Artist",
            resolution_source="spotify_album_tracklist",
        )
        self.assertEqual(_track_source_priority(track), 3)

    def test_spotify_track_search_medium(self):
        """_track_source_priority gives medium score to Spotify track search."""
        track = ReleaseTrack(
            title="Track 1",
            artists="Artist",
            resolution_source="spotify_track_search_album",
        )
        self.assertEqual(_track_source_priority(track), 2)

    def test_musicbrainz_tracklist_low(self):
        """_track_source_priority gives low score to MusicBrainz tracklist."""
        track = ReleaseTrack(
            title="Track 1",
            artists="Artist",
            resolution_source="musicbrainz_tracklist",
        )
        self.assertEqual(_track_source_priority(track), 1)

    def test_unknown_source_zero(self):
        """_track_source_priority gives zero for unknown source."""
        track = ReleaseTrack(
            title="Track 1",
            artists="Artist",
            resolution_source=None,
        )
        self.assertEqual(_track_source_priority(track), 0)


if __name__ == "__main__":
    unittest.main()
