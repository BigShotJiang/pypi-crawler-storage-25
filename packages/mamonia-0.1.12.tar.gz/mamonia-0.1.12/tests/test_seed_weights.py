"""Tests for mamonia/seed_weights.py — §3–4 seed weight computation."""

from __future__ import annotations

import unittest

from mamonia.models import CanonicalTrack
from mamonia.seed_weights import build_artist_seeds


def _ct(
    artist_mbid: str | None = None,
    artist_name: str = "Artist",
    track: str = "Track",
    release_group_mbid: str | None = None,
    confidence: float = 1.0,
    platform_ids: dict | None = None,
    playlist_position: int | None = None,
) -> CanonicalTrack:
    return CanonicalTrack(
        artist_mbid=artist_mbid,
        artist_name_canonical=artist_name,
        input_artist=artist_name,
        input_track=track,
        release_group_mbid=release_group_mbid,
        match_confidence=confidence,
        platform_ids=platform_ids or {},
        playlist_position=playlist_position,
    )


class TestBuildArtistSeeds(unittest.TestCase):

    def test_empty_input_returns_empty(self):
        self.assertEqual(build_artist_seeds([]), [])

    def test_single_track_single_artist(self):
        tracks = [_ct(artist_mbid="mbid-1", artist_name="Massive Attack", track="Teardrop", confidence=1.0)]
        seeds = build_artist_seeds(tracks)
        self.assertEqual(len(seeds), 1)
        self.assertEqual(seeds[0].canonical_name, "Massive Attack")
        self.assertEqual(seeds[0].source_frequency, 1)
        self.assertEqual(seeds[0].unique_track_count, 1)
        self.assertAlmostEqual(seeds[0].seed_weight, 1.0)

    def test_higher_frequency_artist_scores_higher(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="Massive Attack", track="Teardrop", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="Massive Attack", track="Angel", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="Massive Attack", track="Unfinished Sympathy", confidence=1.0),
            _ct(artist_mbid="a2", artist_name="Portishead", track="Sour Times", confidence=1.0),
        ]
        seeds = build_artist_seeds(tracks)
        ma = next(s for s in seeds if s.canonical_name == "Massive Attack")
        ph = next(s for s in seeds if s.canonical_name == "Portishead")
        self.assertGreater(ma.seed_weight, ph.seed_weight)

    def test_duplicate_tracks_do_not_inflate_unique_count(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="Artist", track="Same Song", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="Artist", track="Same Song", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="Artist", track="Same Song", confidence=1.0),
        ]
        seeds = build_artist_seeds(tracks)
        self.assertEqual(seeds[0].unique_track_count, 1)
        self.assertEqual(seeds[0].source_frequency, 3)

    def test_seed_weight_normalized_to_one(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="A", track="T1", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="A", track="T2", confidence=1.0),
            _ct(artist_mbid="a2", artist_name="B", track="T3", confidence=0.5),
        ]
        seeds = build_artist_seeds(tracks)
        max_weight = max(s.seed_weight for s in seeds)
        self.assertAlmostEqual(max_weight, 1.0, places=5)

    def test_all_weights_in_range(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="X", track="T1", confidence=1.0),
            _ct(artist_mbid="a2", artist_name="Y", track="T2", confidence=0.3),
            _ct(artist_mbid="a3", artist_name="Z", track="T3", confidence=0.9),
        ]
        seeds = build_artist_seeds(tracks)
        for s in seeds:
            self.assertGreaterEqual(s.seed_weight, 0.0)
            self.assertLessEqual(s.seed_weight, 1.0)

    def test_seeds_sorted_descending_by_weight(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="A", track="T1", confidence=1.0),
            _ct(artist_mbid="a1", artist_name="A", track="T2", confidence=1.0),
            _ct(artist_mbid="a2", artist_name="B", track="T3", confidence=0.3),
        ]
        seeds = build_artist_seeds(tracks)
        weights = [s.seed_weight for s in seeds]
        self.assertEqual(weights, sorted(weights, reverse=True))

    def test_artist_grouped_by_mbid_not_name_variant(self):
        tracks = [
            _ct(artist_mbid="shared-mbid", artist_name="Massive Attack", track="T1", confidence=1.0),
            _ct(artist_mbid="shared-mbid", artist_name="massive attack", track="T2", confidence=1.0),
        ]
        seeds = build_artist_seeds(tracks)
        self.assertEqual(len(seeds), 1)
        self.assertEqual(seeds[0].source_frequency, 2)

    def test_fallback_groups_by_name_when_no_mbid(self):
        tracks = [
            _ct(artist_mbid=None, artist_name="Burial", track="Archangel", confidence=0.5),
            _ct(artist_mbid=None, artist_name="Burial", track="Raver", confidence=0.5),
        ]
        seeds = build_artist_seeds(tracks)
        self.assertEqual(len(seeds), 1)
        self.assertEqual(seeds[0].source_frequency, 2)

    def test_low_confidence_tracks_lower_seed_weight(self):
        tracks_high = [_ct(artist_mbid="a1", artist_name="A", track="T1", confidence=1.0)]
        tracks_low = [_ct(artist_mbid="a2", artist_name="B", track="T2", confidence=0.3)]
        seeds_high = build_artist_seeds(tracks_high)
        seeds_low = build_artist_seeds(tracks_low)
        self.assertGreater(seeds_high[0].match_confidence_avg, seeds_low[0].match_confidence_avg)

    def test_unique_release_count_tracked(self):
        tracks = [
            _ct(artist_mbid="a1", artist_name="A", track="T1", release_group_mbid="rg1"),
            _ct(artist_mbid="a1", artist_name="A", track="T2", release_group_mbid="rg1"),
            _ct(artist_mbid="a1", artist_name="A", track="T3", release_group_mbid="rg2"),
        ]
        seeds = build_artist_seeds(tracks)
        self.assertEqual(seeds[0].unique_release_count, 2)


if __name__ == "__main__":
    unittest.main()
