from __future__ import annotations

import unittest

from mamonia.providers.musicbrainz import MusicBrainzProvider


class MusicBrainzProviderTests(unittest.TestCase):
    def test_release_group_lookup_uses_valid_includes_and_versioned_cache_key(self) -> None:
        provider = object.__new__(MusicBrainzProvider)
        cache_sets = []
        requests = []
        provider._cache_get = lambda key: None
        provider._cache_set = lambda key, value: cache_sets.append((key, value))
        provider._get = lambda path, params: requests.append((path, params)) or {"release-groups": [{"id": "rg-1"}]}

        groups = MusicBrainzProvider.browse_release_groups(provider, "artist-mbid")

        self.assertEqual(groups, [{"id": "rg-1"}])
        self.assertEqual(cache_sets[0][0], "release-groups-v3:artist id=artist mbid")
        self.assertNotIn("releases", requests[0][1]["inc"])

    def test_release_group_lookup_does_not_cache_provider_failures_as_empty_results(self) -> None:
        provider = object.__new__(MusicBrainzProvider)
        cache_sets = []
        provider._cache_get = lambda key: None
        provider._cache_set = lambda key, value: cache_sets.append((key, value))
        provider._get = lambda path, params: None

        groups = MusicBrainzProvider.browse_release_groups(provider, "artist-mbid")

        self.assertEqual(groups, [])
        self.assertEqual(cache_sets, [])

    def test_release_tracks_for_group_parses_recording_tracklist_and_caches(self) -> None:
        provider = object.__new__(MusicBrainzProvider)
        cache_sets = []
        requests = []
        provider._cache_get = lambda key: None
        provider._cache_set = lambda key, value: cache_sets.append((key, value))
        provider._get = lambda path, params: requests.append((path, params)) or {
            "releases": [
                {"id": "empty", "status": "Official", "date": "2026-01-01", "media": []},
                {
                    "id": "release-1",
                    "status": "Official",
                    "date": "2026-02-01",
                    "country": "PL",
                    "media": [
                        {
                            "tracks": [
                                {
                                    "position": 1,
                                    "title": "Opener",
                                    "recording": {
                                        "artist-credit": [{"name": "Artist"}],
                                        "isrcs": ["ISRC1"],
                                    },
                                },
                                {
                                    "position": 2,
                                    "recording": {
                                        "title": "Second",
                                        "artist-credit": [
                                            {"name": "Artist", "joinphrase": " feat. "},
                                            {"name": "Guest"},
                                        ],
                                    },
                                },
                            ]
                        }
                    ],
                },
            ]
        }

        tracks = MusicBrainzProvider.release_tracks_for_group(provider, "rg-1", cap=10)

        self.assertEqual(requests[0][0], "/release")
        self.assertEqual(requests[0][1]["release-group"], "rg-1")
        self.assertIn("recordings", requests[0][1]["inc"])
        self.assertEqual(cache_sets[0][0], "release-tracks-v2:release group id=rg 1")
        self.assertEqual([track.title for track in tracks], ["Opener", "Second"])
        self.assertEqual(tracks[0].artists, "Artist")
        self.assertEqual(tracks[0].isrc, "ISRC1")
        self.assertEqual(tracks[0].release_date, "2026-02-01")
        self.assertEqual(tracks[1].artists, "Artist feat. Guest")

    def test_release_tracks_for_group_uses_cache(self) -> None:
        provider = object.__new__(MusicBrainzProvider)
        provider._cache_get = lambda key: [{"title": "Cached", "artists": "Artist", "track_number": 1}]
        provider._cache_set = lambda key, value: None
        provider._get = lambda path, params: self.fail("cache hit should not call provider")

        tracks = MusicBrainzProvider.release_tracks_for_group(provider, "rg-1")

        self.assertEqual(tracks[0].title, "Cached")

    def test_label_release_search_uses_versioned_cache_key(self) -> None:
        provider = object.__new__(MusicBrainzProvider)
        cache_sets = []
        requests = []
        provider._cache_get = lambda key: None
        provider._cache_set = lambda key, value: cache_sets.append((key, value))
        provider._get = lambda path, params: requests.append((path, params)) or {"releases": [{"id": "rel-1"}]}

        releases = MusicBrainzProvider.search_releases_by_label(provider, "Warp", limit=10)

        self.assertEqual(releases, [{"id": "rel-1"}])
        self.assertEqual(requests[0][0], "/release")
        self.assertIn('label:"Warp"', requests[0][1]["query"])
        self.assertEqual(cache_sets[0][0], "label-releases-v1:label=warp|limit=10")


if __name__ == "__main__":
    unittest.main()
