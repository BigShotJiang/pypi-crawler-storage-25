"""Tests for mamonia/release_discovery.py — §7–8 release discovery & filtering."""

from __future__ import annotations

import unittest
from datetime import date, timedelta
from unittest.mock import MagicMock

from mamonia.release_discovery import (
    DEFAULT_WINDOW_DAYS,
    CandidateRelease,
    _is_reissue,
    _parse_date,
    fetch_candidates,
    fetch_label_affinity_candidates,
)

VALID_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
OTHER_MBID = "b2c3d4e5-f6a7-8901-bcde-f12345678901"


def _recent_date(days_ago: int = 30) -> str:
    return (date.today() - timedelta(days=days_ago)).isoformat()


def _old_date(days_ago: int = 400) -> str:
    return (date.today() - timedelta(days=days_ago)).isoformat()


def _mid_date(days_ago: int = 200) -> str:
    return (date.today() - timedelta(days=days_ago)).isoformat()


def _make_rg(
    rg_id: str = VALID_MBID,
    title: str = "Test Album",
    primary_type: str = "Album",
    secondary_types: list[str] | None = None,
    date_str: str | None = None,
) -> dict:
    return {
        "id": rg_id,
        "title": title,
        "primary-type": primary_type,
        "secondary-types": secondary_types or [],
        "first-release-date": date_str or _recent_date(30),
    }


def _make_mb(release_groups: list[dict]) -> MagicMock:
    mb = MagicMock()
    mb.browse_release_groups.return_value = release_groups
    return mb


def _tiers_and_names(mbid: str = VALID_MBID, name: str = "Test Artist", tier: str = "Tier 1") -> tuple[dict, dict]:
    return {mbid: tier}, {mbid: name}


class TestFetchCandidatesBasic(unittest.TestCase):

    def test_album_within_window_is_returned(self):
        mb = _make_mb([_make_rg(primary_type="Album")])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "Test Album")

    def test_ep_within_window_is_returned(self):
        mb = _make_mb([_make_rg(primary_type="EP")])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(len(results), 1)

    def test_single_within_window_is_returned(self):
        mb = _make_mb([_make_rg(primary_type="Single")])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(len(results), 1)

    def test_other_type_excluded(self):
        mb = _make_mb([_make_rg(primary_type="Broadcast")])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])

    def test_compilation_excluded_by_default(self):
        mb = _make_mb([_make_rg(secondary_types=["Compilation"])])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])

    def test_live_excluded_by_default(self):
        mb = _make_mb([_make_rg(secondary_types=["Live"])])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])

    def test_compilation_allowed_when_flag_set(self):
        mb = _make_mb([_make_rg(secondary_types=["Compilation"])])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, allow_compilations=True)
        self.assertEqual(len(results), 1)

    def test_live_allowed_when_flag_set(self):
        mb = _make_mb([_make_rg(secondary_types=["Live"])])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, allow_live=True)
        self.assertEqual(len(results), 1)

    def test_bootleg_always_excluded(self):
        mb = _make_mb([_make_rg(secondary_types=["Bootleg"])])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, allow_compilations=True, allow_live=True)
        self.assertEqual(results, [])

    def test_short_form_release_count_annotated_per_artist(self):
        mb = _make_mb([
            _make_rg(rg_id="rg-album", primary_type="Album", title="Album"),
            _make_rg(rg_id="rg-ep-1", primary_type="EP", title="EP 1"),
            _make_rg(rg_id="rg-ep-2", primary_type="EP", title="EP 2"),
            _make_rg(rg_id="rg-single", primary_type="Single", title="Single"),
        ])
        tiers, names = _tiers_and_names()

        results = fetch_candidates(tiers, names, mb)

        self.assertEqual(len(results), 4)
        self.assertTrue(all(r.artist_window_release_count == 3 for r in results))

    def test_short_form_release_count_separated_by_artist(self):
        mbid2 = "c3d4e5f6-a7b8-9012-cdef-123456789012"

        def browse_side_effect(artist_mbid):
            if artist_mbid == VALID_MBID:
                return [
                    _make_rg(rg_id="rg-a-1", primary_type="EP"),
                    _make_rg(rg_id="rg-a-2", primary_type="Single"),
                ]
            return [_make_rg(rg_id="rg-b-1", primary_type="EP")]

        mb = MagicMock()
        mb.browse_release_groups.side_effect = browse_side_effect
        tiers = {VALID_MBID: "Tier 1", mbid2: "Tier 2A"}
        names = {VALID_MBID: "Artist A", mbid2: "Artist B"}

        results = fetch_candidates(tiers, names, mb)
        counts = {r.artist_name: r.artist_window_release_count for r in results}

        self.assertEqual(counts["Artist A"], 2)
        self.assertEqual(counts["Artist B"], 1)


class TestTemporalFilter(unittest.TestCase):

    def test_release_within_window_passes(self):
        mb = _make_mb([_make_rg(date_str=_recent_date(30))])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, window_days=183)
        self.assertEqual(len(results), 1)

    def test_release_outside_window_excluded(self):
        mb = _make_mb([_make_rg(date_str=_old_date(400))])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, window_days=183)
        self.assertEqual(results, [])

    def test_custom_window_respected(self):
        mb = _make_mb([_make_rg(date_str=_recent_date(20))])
        tiers, names = _tiers_and_names()
        # 10-day window: 20-day-old release should be excluded
        results = fetch_candidates(tiers, names, mb, window_days=10)
        self.assertEqual(results, [])

    def test_partial_date_year_only(self):
        # A year-only date parses to Jan 1 of that year
        current_year = date.today().year
        mb = _make_mb([_make_rg(date_str=str(current_year))])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, window_days=DEFAULT_WINDOW_DAYS)
        # Current year Jan 1 may or may not be within window depending on time of year
        self.assertIsInstance(results, list)

    def test_missing_date_excluded(self):
        rg = _make_rg()
        rg["first-release-date"] = ""
        mb = _make_mb([rg])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])


class TestHeardExclusion(unittest.TestCase):

    def test_heard_release_excluded(self):
        mb = _make_mb([_make_rg(rg_id=VALID_MBID)])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, heard_release_group_mbids={VALID_MBID})
        self.assertEqual(results, [])

    def test_unheard_release_included(self):
        mb = _make_mb([_make_rg(rg_id=VALID_MBID)])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, heard_release_group_mbids={OTHER_MBID})
        self.assertEqual(len(results), 1)

    def test_empty_heard_set(self):
        mb = _make_mb([_make_rg()])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb, heard_release_group_mbids=set())
        self.assertEqual(len(results), 1)


class TestDeduplication(unittest.TestCase):

    def test_duplicate_mbid_across_artists_only_once(self):
        mbid2 = "c3d4e5f6-a7b8-9012-cdef-123456789012"
        # Two different artists return the same release-group MBID
        def browse_side_effect(artist_mbid):
            return [_make_rg(rg_id=VALID_MBID)]  # same release for both

        mb = MagicMock()
        mb.browse_release_groups.side_effect = browse_side_effect
        tiers = {VALID_MBID: "Tier 1", mbid2: "Tier 2A"}
        names = {VALID_MBID: "Artist A", mbid2: "Artist B"}
        results = fetch_candidates(tiers, names, mb)
        # Same release-group should appear only once
        mbids = [r.release_group_mbid for r in results]
        self.assertEqual(len(mbids), len(set(mbids)))


class TestReissueDetection(unittest.TestCase):

    def test_remastered_title_flagged(self):
        self.assertTrue(_is_reissue("Blue Lines (Remastered)", []))

    def test_deluxe_title_flagged(self):
        self.assertTrue(_is_reissue("Dummy (Deluxe Edition)", []))

    def test_anniversary_title_flagged(self):
        self.assertTrue(_is_reissue("Mezzanine (25th Anniversary Edition)", []))

    def test_normal_title_not_flagged(self):
        self.assertFalse(_is_reissue("Mezzanine", []))

    def test_compilation_secondary_type_flagged(self):
        self.assertTrue(_is_reissue("Greatest Hits", ["compilation"]))

    def test_reissue_flag_set_on_candidate(self):
        mb = _make_mb([_make_rg(title="Blue Lines (Remastered)")])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].possible_reissue)


class TestParseDateHelper(unittest.TestCase):

    def test_full_date(self):
        self.assertEqual(_parse_date("2025-04-01"), date(2025, 4, 1))

    def test_year_month(self):
        self.assertEqual(_parse_date("2025-04"), date(2025, 4, 1))

    def test_year_only(self):
        self.assertEqual(_parse_date("2025"), date(2025, 1, 1))

    def test_empty_string(self):
        self.assertIsNone(_parse_date(""))

    def test_invalid_string(self):
        self.assertIsNone(_parse_date("not-a-date"))

    def test_iso_datetime_truncated(self):
        self.assertEqual(_parse_date("2025-04-01T00:00:00Z"), date(2025, 4, 1))


class TestNonMbidArtistSkipped(unittest.TestCase):

    def test_artist_without_mbid_key_searched_then_skipped_if_no_result(self):
        # Artist keyed by name (not MBID) — search_artist is attempted,
        # then skipped if no MBID is found
        mb = _make_mb([_make_rg()])
        mb.search_artist.return_value = None
        tiers = {"burial": "Tier 1"}
        names = {"burial": "Burial"}
        results = fetch_candidates(tiers, names, mb)
        mb.search_artist.assert_called_once_with("Burial")
        mb.browse_release_groups.assert_not_called()
        self.assertEqual(results, [])

    def test_mb_error_does_not_crash(self):
        mb = MagicMock()
        mb.browse_release_groups.side_effect = RuntimeError("API down")
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])


class TestNameToMbidResolution(unittest.TestCase):

    def test_name_only_artist_resolved_via_search(self):
        mb = _make_mb([_make_rg()])
        mb.search_artist.return_value = {"id": VALID_MBID, "name": "Test Artist"}
        tiers = {"test artist": "Tier 3"}
        names = {"test artist": "Test Artist"}
        results = fetch_candidates(tiers, names, mb)
        mb.search_artist.assert_called_once_with("Test Artist")
        mb.browse_release_groups.assert_called_once_with(VALID_MBID)
        self.assertEqual(len(results), 1)

    def test_name_only_artist_search_no_result_skipped(self):
        mb = _make_mb([_make_rg()])
        mb.search_artist.return_value = None
        tiers = {"unknown artist": "Tier 3"}
        names = {"unknown artist": "Unknown Artist"}
        results = fetch_candidates(tiers, names, mb)
        mb.search_artist.assert_called_once_with("Unknown Artist")
        mb.browse_release_groups.assert_not_called()
        self.assertEqual(results, [])

    def test_name_resolution_cached_avoids_duplicate_search(self):
        mb = _make_mb([_make_rg()])
        mb.search_artist.return_value = {"id": VALID_MBID, "name": "Test Artist"}
        tiers = {"test artist": "Tier 3", "test artist 2": "Tier 4"}
        names = {"test artist": "Test Artist", "test artist 2": "Test Artist"}
        results = fetch_candidates(tiers, names, mb)
        # search_artist should only be called once because the second artist
        # has the same canonical name and hits the cache
        self.assertEqual(mb.search_artist.call_count, 1)
        # browse_release_groups is called for each distinct artist key,
        # even if they resolve to the same MBID (release-group dedup handles that)
        self.assertEqual(mb.browse_release_groups.call_count, 2)


class TestExtendedWindow(unittest.TestCase):

    def test_200_day_old_release_passes_default_window(self):
        # With 365-day default window, a 200-day-old release should pass
        mb = _make_mb([_make_rg(date_str=_mid_date(200))])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(len(results), 1)

    def test_400_day_old_release_still_excluded(self):
        mb = _make_mb([_make_rg(date_str=_old_date(400))])
        tiers, names = _tiers_and_names()
        results = fetch_candidates(tiers, names, mb)
        self.assertEqual(results, [])


class TestLabelAffinityCandidates(unittest.TestCase):

    def _make_label_mb(self, releases: list[dict]) -> MagicMock:
        mb = MagicMock()
        mb.search_releases_by_label.return_value = releases
        return mb

    def _label_release(
        self,
        *,
        rg_id: str = VALID_MBID,
        primary_type: str = "Album",
        secondary_types: list[str] | None = None,
        date_str: str | None = None,
    ) -> dict:
        return {
            "title": "Label Fresh",
            "date": date_str or _recent_date(10),
            "artist-credit": [{"name": "Label Artist", "artist": {"id": OTHER_MBID, "name": "Label Artist"}}],
            "release-group": {
                "id": rg_id,
                "title": "Label Fresh",
                "primary-type": primary_type,
                "secondary-types": secondary_types or [],
                "first-release-date": date_str or _recent_date(10),
            },
        }

    def test_recent_label_release_becomes_tier3_candidate(self):
        mb = self._make_label_mb([self._label_release()])
        results = fetch_label_affinity_candidates(labels=[("Important Label", 10)], musicbrainz=mb, window_days=183)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].tier, "Tier 3")
        self.assertEqual(results[0].label, "Important Label")

    def test_label_release_uses_same_basic_filters(self):
        releases = [
            self._label_release(rg_id="rg-old", date_str=_old_date(400)),
            self._label_release(rg_id="rg-live", secondary_types=["Live"]),
            self._label_release(rg_id="rg-broadcast", primary_type="Broadcast"),
            self._label_release(rg_id="rg-heard"),
        ]
        mb = self._make_label_mb(releases)
        results = fetch_label_affinity_candidates(
            labels=[("Important Label", 10)],
            musicbrainz=mb,
            heard_release_group_mbids={"rg-heard"},
            window_days=183,
        )

        self.assertEqual(results, [])


if __name__ == "__main__":
    unittest.main()
