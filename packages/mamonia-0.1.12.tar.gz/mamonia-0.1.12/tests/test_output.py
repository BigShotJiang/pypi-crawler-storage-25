from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path

from mamonia.models import ReleaseRecommendation, ReleaseTrack
from mamonia.output import missing_spotify_uri_notice, platform_availability_notice, write_recommendations, write_selection_logic, write_tunemymusic_csv


class OutputTests(unittest.TestCase):
    def test_tunemymusic_csv_writes_track_album_isrc_and_spotify_id(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[
                ReleaseTrack(
                    title="Fresh Track",
                    artists="Fresh Artist, Guest Artist",
                    isrc="TEST123",
                    isrc_source="spotify",
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_csv_2026-04-23.csv"
            write_tunemymusic_csv([rec], path)

            with path.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["Track name"], "Fresh Track")
        self.assertEqual(rows[0]["Artist name"], "Fresh Artist, Guest Artist")
        self.assertEqual(rows[0]["Album"], "Fresh Album")
        self.assertEqual(rows[0]["ISRC"], "TEST123")
        self.assertEqual(rows[0]["ISRC_source"], "spotify")
        self.assertEqual(rows[0]["Tidal ID"], "")

    def test_tunemymusic_csv_keeps_release_level_rows_when_tracks_are_unresolved(self) -> None:
        rec = ReleaseRecommendation(artist="Fresh Artist", title="Fresh Album", release_date="2026-04-23")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_csv_2026-04-23.csv"
            write_recommendations([rec], "csv", path)

            with path.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))

        self.assertEqual(rows[0]["Track name"], "Fresh Album")
        self.assertEqual(rows[0]["Artist name"], "Fresh Artist")
        self.assertEqual(rows[0]["Album"], "Fresh Album")
        self.assertEqual(rows[0]["ISRC"], "")
        self.assertEqual(rows[0]["ISRC_source"], "")
        self.assertEqual(rows[0]["Tidal ID"], "")

    def test_tunemymusic_csv_sets_release_level_isrc_source_from_recovery_result(self) -> None:
        rec = ReleaseRecommendation(
            artist="Archive",
            title="Patterns",
            release_date="2026-02-25",
            rationale=["empty-track-recovery-attempted", "recovery-result:no_tracklist_after_recovery"],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_csv_2026-04-23.csv"
            write_recommendations([rec], "csv", path)

            with path.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))

        self.assertEqual(rows[0]["ISRC_source"], "no_tracklist_after_recovery")

    def test_tunemymusic_csv_sets_release_level_isrc_source_when_attempts_exhausted(self) -> None:
        rec = ReleaseRecommendation(
            artist="Archive",
            title="Patterns",
            release_date="2026-02-25",
            rationale=["empty-track-recovery-attempted", "recovery-result:max_attempts_exhausted"],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_csv_2026-04-23.csv"
            write_recommendations([rec], "csv", path)

            with path.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))

        self.assertEqual(rows[0]["ISRC_source"], "max_attempts_exhausted")

    def test_missing_spotify_uri_notice_lists_csv_rows_without_track_uri(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[
                ReleaseTrack(title="Resolved Track", artists="Fresh Artist", spotify_uri="spotify:track:resolved"),
                ReleaseTrack(title="Missing Track", artists="Fresh Artist, Guest Artist"),
            ],
        )

        notice = missing_spotify_uri_notice([rec])

        self.assertIn("Please note:", notice)
        self.assertIn("1 song is missing Spotify URI.", notice)
        self.assertIn("1 song is missing Tidal ID.", notice)
        self.assertIn("Review these songs:", notice)
        self.assertIn("Track Missing Track by Fresh Artist, Guest Ar... from Fresh Album [2026-04-23]", notice)
        self.assertNotIn("Resolved Track", notice)

    def test_platform_availability_notice_reports_tidal_fallback(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[
                ReleaseTrack(title="Missing Spotify", artists="Fresh Artist", tidal_track_id="tidal-1"),
            ],
        )

        notice = platform_availability_notice([rec])

        self.assertIn("1 song is missing Spotify URI.", notice)
        self.assertIn("0 songs are missing Tidal ID.", notice)
        self.assertIn(
            "Track Missing Spotify by Fresh Artist from Fresh Album [2026-04-23] lacks a Spotify URI and may be unavailable there, but it is accessible on Tidal.",
            notice,
        )

    def test_platform_availability_notice_reports_total_unavailability(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[
                ReleaseTrack(title="Missing Everywhere", artists="Fresh Artist"),
            ],
        )

        notice = platform_availability_notice([rec])

        self.assertIn("1 song is missing Tidal ID.", notice)
        self.assertIn(
            "Track Missing Everywhere by Fresh Artist from Fresh Album [2026-04-23] lacks both a Spotify URI and a Tidal ID; it may be unavailable on these platforms.",
            notice,
        )

    def test_platform_availability_notice_includes_recovery_reason_tag_for_release_level_miss(self) -> None:
        rec = ReleaseRecommendation(
            artist="Archive",
            title="Patterns",
            release_date="2026-02-25",
            rationale=["empty-track-recovery-attempted", "recovery-result:no_tracklist_after_recovery"],
        )
        notice = platform_availability_notice([rec])
        self.assertIn("[no_tracklist_after_recovery]", notice)

    def test_platform_availability_notice_truncates_long_track_and_artist_names(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[
                ReleaseTrack(
                    title="Shake the Snow Globe (from \"Oh. What. Fun.\") (Amazon Music original)",
                    artists="Gwen Stefani featuring Someone With A Very Long Name",
                ),
            ],
        )

        notice = platform_availability_notice([rec])

        self.assertIn("Track Shake the Snow Globe (... by Gwen Stefani featuring... from Fresh Album [2026-04-23]", notice)

    def test_json_output_includes_track_resolution_diagnostics(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            label="Curious Label",
            rationale=[
                "related-act:Seed Artist",
                "label-affinity:Curious Label",
                "musicbrainz-tracklist-fallback",
                "spotify-lookup-missed",
            ],
            mb_release_group_id="mb-rg-1",
            spotify_album_id="sp-album-1",
            spotify_album_uri="spotify:album:sp-album-1",
            tracks=[
                ReleaseTrack(
                    title="Fresh Track",
                    artists="Fresh Artist",
                    spotify_track_id="sp-1",
                    resolution_source="spotify_track_search_keywords",
                    resolution_note="Matched via normalized keyword fallback.",
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_json_2026-04-23.json"
            write_recommendations([rec], "json", path)
            payload = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(payload[0]["tracks"][0]["resolution_source"], "spotify_track_search_keywords")
        self.assertEqual(payload[0]["tracks"][0]["resolution_note"], "Matched via normalized keyword fallback.")
        self.assertEqual(payload[0]["tracks"][0]["spotify_url"], "https://open.spotify.com/track/sp-1")
        self.assertEqual(payload[0]["spotify_album_url"], "https://open.spotify.com/album/sp-album-1")
        self.assertEqual(payload[0]["attribution"]["spotify"]["present"], True)
        self.assertEqual(payload[0]["attribution"]["spotify"]["album_url"], "https://open.spotify.com/album/sp-album-1")
        self.assertEqual(payload[0]["attribution"]["spotify"]["track_urls"], ["https://open.spotify.com/track/sp-1"])
        self.assertEqual(
            payload[0]["explain"]["candidate_sources"],
            [
                {"source": "related-act", "matched_seed": "Seed Artist"},
                {"source": "label-affinity", "matched_seed": "Curious Label"},
            ],
        )
        self.assertEqual(payload[0]["explain"]["provider_evidence"]["label"], "Curious Label")
        self.assertEqual(payload[0]["explain"]["provider_evidence"]["musicbrainz_release_group_id"], "mb-rg-1")
        self.assertEqual(payload[0]["explain"]["provider_evidence"]["spotify_album_id"], "sp-album-1")
        self.assertEqual(
            payload[0]["explain"]["filter_context"],
            [
                "musicbrainz_tracklist_fallback_used",
                "spotify_lookup_missed",
            ],
        )
        self.assertEqual(payload[0]["explain"]["tracklist_derivation"], "spotify-derived")
        self.assertEqual(payload[0]["explain"]["track_resolution_sources"], ["spotify_track_search_keywords"])
        self.assertEqual(payload[0]["explain"]["track_resolution_notes"], ["Matched via normalized keyword fallback."])

    def test_json_output_includes_tidal_urls_and_attribution(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tidal_album_id="td-album-1",
            tracks=[
                ReleaseTrack(title="Fresh Track", artists="Fresh Artist", tidal_track_id="td-track-1"),
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_json_2026-04-23.json"
            write_recommendations([rec], "json", path)
            payload = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(payload[0]["tracks"][0]["tidal_url"], "https://tidal.com/browse/track/td-track-1")
        self.assertEqual(payload[0]["attribution"]["tidal"]["present"], True)
        self.assertEqual(payload[0]["attribution"]["tidal"]["album_url"], "https://tidal.com/browse/album/td-album-1")
        self.assertEqual(payload[0]["attribution"]["tidal"]["track_urls"], ["https://tidal.com/browse/track/td-track-1"])

    def test_write_selection_logic_writes_sidecar(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tier="Tier 1",
            confidence_label="High",
            rationale=["seed-artist"],
            explanation={"picked_tracks_reason": "title-match+popularity", "popularity_provider": "listenbrainz"},
            tracks=[ReleaseTrack(title="Fresh Track", artists="Fresh Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "selection.json"
            write_selection_logic(
                [rec],
                path,
                run_config={"limit": 1},
                profile={"id": 7, "name": "profile"},
                output={"path": "out.csv"},
            )
            payload = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(payload["run_config"]["limit"], 1)
        self.assertEqual(payload["profile"]["id"], 7)
        self.assertEqual(payload["recommendations"][0]["title"], "Fresh Album")
        self.assertEqual(payload["recommendations"][0]["tier"], "Tier 1")

    def test_write_selection_logic_writes_markdown_sidecar_when_path_is_md(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tier="Tier 1",
            confidence_label="High",
            rationale=["seed-artist"],
            explanation={"picked_tracks_reason": "title-match+popularity", "popularity_provider": "listenbrainz"},
            tracks=[ReleaseTrack(title="Fresh Track", artists="Fresh Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "selection.md"
            write_selection_logic(
                [rec],
                path,
                run_config={"limit": 1, "discovery_mode": "balanced"},
                profile={"id": 7, "name": "profile", "profile_state": "reused"},
                output={"path": "out.csv", "format": "csv", "heard_count": 1},
                playlist_results={"tidal": {"created": True, "url": "https://tidal.com/browse/playlist/abc", "reason": None}},
            )
            text = path.read_text(encoding="utf-8")

        self.assertIn("# Selection Logic", text)
        self.assertIn("## Recommendations (1 releases)", text)
        self.assertIn("### 1. Fresh Artist – Fresh Album", text)
        self.assertIn("## Playlists Created", text)
        self.assertIn("**Tidal:** ✓", text)
        self.assertIn("https://tidal.com/browse/playlist/abc", text)
        self.assertIn("0.00% (Tier 1, High confidence)", text)
        self.assertIn("**Track selection:** title-match+popularity", text)

    def test_write_selection_logic_markdown_derives_normalized_tier_and_confidence_when_missing(self) -> None:
        first = ReleaseRecommendation(
            artist="Artist One",
            title="Release One",
            release_date="2026-04-23",
            score=3.913176,
            rationale=["seed-artist"],
            tracks=[ReleaseTrack(title="Track One", artists="Artist One")],
        )
        second = ReleaseRecommendation(
            artist="Artist Two",
            title="Release Two",
            release_date="2026-04-23",
            score=1.0,
            rationale=["profile-network"],
            tracks=[ReleaseTrack(title="Track Two", artists="Artist Two")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "selection.md"
            write_selection_logic(
                [first, second],
                path,
                run_config={"limit": 2, "discovery_mode": "standard"},
                profile={"id": 7, "name": "profile", "profile_state": "reused"},
                output={"path": "out.csv", "format": "csv", "heard_count": 2},
            )
            text = path.read_text(encoding="utf-8")

        self.assertIn("### 1. Artist One – Release One", text)
        self.assertIn("100.00% (Tier 1, High confidence)", text)
        self.assertIn("### 2. Artist Two – Release Two", text)
        self.assertIn("0.00% (Tier 4, Low confidence)", text)

    def test_json_output_marks_musicbrainz_derived_tracklists(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Archive Album",
            release_date="2026-04-23",
            rationale=["seed-artist", "musicbrainz-tracklist-fallback"],
            tracks=[
                ReleaseTrack(
                    title="Archive Track",
                    artists="Fresh Artist",
                    resolution_source="musicbrainz_tracklist",
                    resolution_note="Spotify unresolved; using MusicBrainz tracklist.",
                )
            ],
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "mamonia_json_2026-04-23.json"
            write_recommendations([rec], "json", path)
            payload = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual(payload[0]["explain"]["candidate_sources"], [{"source": "seed-artist", "matched_seed": "Fresh Artist"}])
        self.assertEqual(payload[0]["explain"]["tracklist_derivation"], "musicbrainz-derived")


if __name__ == "__main__":
    unittest.main()
