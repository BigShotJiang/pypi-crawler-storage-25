from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from mamonia.models import InputTrack
from mamonia.profiles import portable_track_set_hash, source_identity, source_identity_from_tracks


class ProfileIdentityTests(unittest.TestCase):
    def test_spotify_playlist_source_key_is_stable_by_playlist_id(self) -> None:
        first = source_identity("https://open.spotify.com/playlist/7jpZgOb9Rqi6drSCJxQKmb?si=abc")
        second = source_identity("spotify:playlist:7jpZgOb9Rqi6drSCJxQKmb")

        self.assertEqual(first["source_key"], "spotify:playlist:7jpZgOb9Rqi6drSCJxQKmb")
        self.assertEqual(first["source_key"], second["source_key"])
        self.assertEqual(first["source_hash"], second["source_hash"])

    def test_tidal_playlist_source_key_is_stable_by_playlist_id(self) -> None:
        first = source_identity("https://tidal.com/playlist/0e3a03f1-a3d6-4826-b10f-535b6297907f")
        second = source_identity("tidal:playlist:0e3a03f1-a3d6-4826-b10f-535b6297907f")

        self.assertEqual(first["source_key"], "tidal:playlist:0e3a03f1-a3d6-4826-b10f-535b6297907f")
        self.assertEqual(first["source_key"], second["source_key"])
        self.assertEqual(first["source_hash"], second["source_hash"])

    def test_text_playlist_source_key_changes_with_file_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "playlist.txt"
            path.write_text("Artist - Song\n", encoding="utf-8")
            first = source_identity(str(path))

            path.write_text("Artist - Different Song\n", encoding="utf-8")
            second = source_identity(str(path))

        self.assertNotEqual(first["source_key"], second["source_key"])
        self.assertTrue(first["source_key"].startswith("txt:"))
        self.assertTrue(second["source_key"].startswith("txt:"))

    def test_csv_playlist_source_key_uses_csv_type_and_content_hash(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "library.csv"
            path.write_text("Artist name,Track name\nSeed Artist,Seed Song\n", encoding="utf-8")

            identity = source_identity(str(path))

        self.assertEqual(identity["source_type"], "csv")
        self.assertTrue(identity["source_key"].startswith("csv:"))
        self.assertEqual(identity["name"], "library")

    def test_track_source_identity_ignores_local_file_order(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            first_path = Path(tmp) / "playlist.txt"
            second_path = Path(tmp) / "playlist-copy.txt"
            first_path.write_text("A - One\nB - Two\n", encoding="utf-8")
            second_path.write_text("B - Two\nA - One\n", encoding="utf-8")
            first_tracks = [
                InputTrack(artist="A", track="One"),
                InputTrack(artist="B", track="Two"),
            ]
            second_tracks = [
                InputTrack(artist="B", track="Two"),
                InputTrack(artist="A", track="One"),
            ]

            first = source_identity_from_tracks(str(first_path), first_tracks)
            second = source_identity_from_tracks(str(second_path), second_tracks)

        self.assertEqual(first["source_key"], second["source_key"])
        self.assertEqual(first["source_hash"], second["source_hash"])
        self.assertEqual(first["source_type"], "txt")

    def test_track_source_identity_preserves_local_file_name_and_ref(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "library.csv"
            path.write_text("Artist name,Track name\nSeed Artist,Seed Song\n", encoding="utf-8")

            identity = source_identity_from_tracks(
                str(path),
                [InputTrack(artist="Seed Artist", track="Seed Song")],
            )

        self.assertEqual(identity["name"], "library")
        self.assertTrue(identity["source_ref"].endswith("library.csv"))
        self.assertTrue(identity["source_key"].startswith("csv:"))

    def test_portable_track_set_hash_matches_tidal_and_csv_tracks_by_metadata(self) -> None:
        tidal_tracks = [
            InputTrack(artist="Seed Artist", track="Seed Song", tidal_track_id="tidal-1"),
            InputTrack(artist="Other Artist", track="Other Song", tidal_track_id="tidal-2"),
        ]
        csv_tracks = [
            InputTrack(artist="Other Artist", track="Other Song", isrc="ISRC2", spotify_track_id="sp-2"),
            InputTrack(artist="Seed Artist", track="Seed Song", isrc="ISRC1", spotify_track_id="sp-1"),
        ]

        self.assertEqual(portable_track_set_hash(tidal_tracks), portable_track_set_hash(csv_tracks))


if __name__ == "__main__":
    unittest.main()
