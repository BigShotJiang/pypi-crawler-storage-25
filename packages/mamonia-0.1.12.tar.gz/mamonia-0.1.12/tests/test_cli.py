from __future__ import annotations

import datetime as dt
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from typer.testing import CliRunner

from mamonia.cli import _default_output_path, app, auto_mark_exported_releases
from mamonia.discovery import track_keys_from_input
from mamonia.models import ArtistProfile, CandidateArtist, InputTrack, ReleaseRecommendation, ReleaseTrack, TasteProfile
from mamonia.providers import ProviderRateLimit
from mamonia.providers.spotify import SpotifyPlaylistCreationResult
from mamonia.providers.tidal import TidalPlaylistCreationResult
from mamonia.profiles import source_identity, source_identity_from_tracks
from mamonia.storage import Storage
from mamonia.workflow import DiscoverOptions, ProfileDecisionContext, _print_provider_warnings, run_discover


class CliTests(unittest.TestCase):
    def test_bare_mamonia_launches_guided_mode(self) -> None:
        with patch("mamonia.cli.launch_guided") as launcher:
            result = CliRunner().invoke(app, [])

        self.assertEqual(result.exit_code, 0)
        launcher.assert_called_once()

    def test_root_help_does_not_launch_guided_mode(self) -> None:
        with patch("mamonia.cli.launch_guided") as launcher:
            result = CliRunner().invoke(app, ["--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Mamonia", result.output)
        launcher.assert_not_called()

    def test_auto_mark_exported_releases_marks_recommendations_as_heard(self) -> None:
        recs = [
            ReleaseRecommendation(
                artist="Artist A",
                title="Fresh A",
                release_date="2026-04-01",
                release_type="album",
                mb_release_group_id="rg-a",
            ),
            ReleaseRecommendation(
                artist="Artist B",
                title="Fresh B",
                release_date="2026-04-02",
                release_type="ep",
                spotify_album_id="sp-b",
            ),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            count = auto_mark_exported_releases(storage, recs)

            self.assertEqual(count, 2)
            self.assertTrue(storage.is_heard_recommendation(recs[0]))
            self.assertTrue(storage.is_heard_recommendation(recs[1]))
            storage.close()

    def test_auto_mark_exported_releases_does_not_duplicate_heard_entries(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Fresh",
            release_date="2026-04-01",
            release_type="single",
            mb_release_group_id="rg-one",
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            count = auto_mark_exported_releases(storage, [rec, rec])

            self.assertEqual(count, 1)
            self.assertEqual(len(storage.list_heard()), 1)
            storage.close()

    def test_heard_remove_uses_active_runtime_db_with_overrides(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            canonical_db = Path(tmp) / "canonical.sqlite"
            runtime_db = Path(tmp) / "runtime.sqlite"

            canonical = Storage(canonical_db)
            entry_id = canonical.add_heard(artist="Artist", title="Release")
            canonical.close()

            runtime = Storage(runtime_db)
            runtime_entry_id = runtime.add_heard(artist="Runtime Artist", title="Runtime Release")
            runtime.close()

            with patch("mamonia.cli.canonical_db_path_for_os", return_value=canonical_db):
                result = CliRunner().invoke(
                    app,
                    ["heard", "remove", "--id", str(runtime_entry_id)],
                    env={"MAMONIA_HOME": str(Path(tmp) / "runtime-home"), "MAMONIA_DB": str(runtime_db)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn(str(runtime_db), result.output)

            canonical = Storage(canonical_db)
            self.assertEqual(len(canonical.list_heard()), 1)
            canonical.close()

            runtime = Storage(runtime_db)
            self.assertEqual(len(runtime.list_heard()), 0)
            runtime.close()

    def test_discover_help_no_longer_exposes_non_interactive_prompt_option(self) -> None:
        result = CliRunner().invoke(app, ["discover", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertNotIn("--non-interactive", result.output)
        self.assertNotIn("prompt", result.output.lower())

    def test_discover_help_exposes_reusable_profile_options(self) -> None:
        result = CliRunner().invoke(app, ["discover", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("--reuse-profile", result.output)
        self.assertIn("--profile", result.output)

    def test_db_health_command_reports_integrity(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "mamonia.sqlite"
            storage = Storage(db_path)
            storage.close()
            result = CliRunner().invoke(
                app,
                ["db", "health"],
                env={"MAMONIA_DB": str(db_path), "MAMONIA_HOME": str(Path(tmp) / "home")},
            )
            self.assertEqual(result.exit_code, 0)
            self.assertIn("integrity_check", result.output)
            self.assertIn(str(db_path), result.output)

    def test_migrate_state_to_managed_dry_run_reports_legacy_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            (tmp_path / ".env").write_text("LASTFM_API_KEY=legacy\n", encoding="utf-8")
            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                result = CliRunner().invoke(
                    app,
                    ["migrate-state-to-managed", "--dry-run"],
                    env={"MAMONIA_HOME": str(tmp_path / "managed-home")},
                )
            finally:
                os.chdir(cwd)
            self.assertEqual(result.exit_code, 0)
            self.assertIn("legacy_artifacts", result.output)

    def test_db_diagnostics_bundle_writes_json_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "mamonia.sqlite"
            storage = Storage(db_path)
            storage.close()
            out = Path(tmp) / "diag.json"
            result = CliRunner().invoke(
                app,
                ["db", "diagnostics-bundle", "--output", str(out)],
                env={"MAMONIA_DB": str(db_path), "MAMONIA_HOME": str(Path(tmp) / "home")},
            )
            self.assertEqual(result.exit_code, 0)
            self.assertTrue(out.exists())
            payload = json.loads(out.read_text(encoding="utf-8"))
            self.assertIn("health", payload)
            self.assertIn("active_db_path", payload)

    def test_diagnose_reports_provider_status_without_secrets(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            home.mkdir(parents=True, exist_ok=True)
            tidal_session = home / "tidal_session.json"
            tidal_session.write_text("{}", encoding="utf-8")
            if hasattr(tidal_session, "chmod"):
                tidal_session.chmod(0o644)
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")

            result = CliRunner().invoke(
                app,
                ["diagnose", "--playlist", str(playlist)],
                env={
                    "MAMONIA_HOME": str(home),
                    "MAMONIA_DB": str(db_path),
                    "SPOTIPY_CLIENT_ID": "",
                    "SPOTIPY_CLIENT_SECRET": "",
                    "LASTFM_API_KEY": "",
                    "MB_CONTACT_EMAIL": "you@example.com",
                    "TIDAL_CLIENT_ID": "",
                    "TIDAL_CLIENT_SECRET": "",
                    "MAMONIA_SPOTIFY_CACHE_TTL_DAYS": "90",
                    "MAMONIA_MUSICBRAINZ_CACHE_TTL_DAYS": "90",
                    "MAMONIA_LASTFM_CACHE_TTL_DAYS": "60",
                    "MAMONIA_DEEZER_CACHE_TTL_DAYS": "60",
                },
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn(f"Managed .env: {home / '.env'} (missing)", result.output)
        self.assertIn(f"CWD .env: {Path('.env').absolute()} (", result.output)
        self.assertIn("Credential file permissions:", result.output)
        self.assertIn("Tidal session not checked", result.output)
        self.assertIn(f"SQLite: {db_path}", result.output)
        self.assertIn("Spotify credentials: missing", result.output)
        self.assertIn("Spotify provider: not configured", result.output)
        self.assertIn("Last.fm API key: missing", result.output)
        self.assertIn("Last.fm provider: optional; disabled", result.output)
        self.assertIn("MusicBrainz contact: warning: placeholder", result.output)
        self.assertIn("MusicBrainz provider: ready for metadata lookup", result.output)
        self.assertIn("Tidal credentials: missing", result.output)
        self.assertIn("Tidal provider: not configured; importer-friendly export fallback only", result.output)
        self.assertIn("Tidal auth flow:", result.output)
        self.assertIn("Tidal native playlist creation: experimental; verify with `mamonia tidal-smoke` before relying on it", result.output)
        self.assertIn("SQLite quick check: ok", result.output)
        self.assertIn(
            "Local state: 0 profile(s), 0 heard release(s), 0 cache entries, "
            "0 artist enrichment row(s), 0 track enrichment row(s), 0 recorded run(s)",
            result.output,
        )
        self.assertIn("Cache TTLs: Spotify 90d, MusicBrainz 90d, Last.fm 60d, Deezer 60d", result.output)
        self.assertIn(
            "Cache stats: Spotify 0 entries, 0 hit(s), 0 miss(es), "
            "MusicBrainz 0 entries, 0 hit(s), 0 miss(es), "
            "Last.fm 0 entries, 0 hit(s), 0 miss(es), "
            "Deezer 0 entries, 0 hit(s), 0 miss(es)",
            result.output,
        )
        self.assertIn("Input file: OK (1 parsed track(s))", result.output)
        self.assertNotIn("secret", result.output.lower())

    def test_tidal_playlists_lists_user_playlists(self) -> None:
        fake_provider = _CliTidalProvider()

        with patch("mamonia.cli.TidalProvider", return_value=fake_provider):
            result = CliRunner().invoke(app, ["tidal-playlists"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("playlist-1\t4\tSaved Tidal", result.output)

    def test_tidal_smoke_runs_non_destructive_checks(self) -> None:
        fake_settings = SimpleNamespace(tidal_configured=True)
        fake_provider = _CliTidalProvider()

        with patch("mamonia.cli.load_settings", return_value=fake_settings), patch(
            "mamonia.cli.TidalProvider",
            return_value=fake_provider,
        ):
            result = CliRunner().invoke(
                app,
                ["tidal-smoke", "--playlist", "playlist-1", "--isrc", "ISRC123"],
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Tidal smoke check", result.output)
        self.assertIn("Session: OK", result.output)
        self.assertIn("User playlists: OK (1 found)", result.output)
        self.assertIn("Playlist read: OK (2 item(s))", result.output)
        self.assertIn("ISRC lookup: OK (track tidal-track-1)", result.output)
        self.assertIsNone(fake_provider.created_with)

    def test_tidal_smoke_creates_playlist_only_when_explicit(self) -> None:
        fake_settings = SimpleNamespace(tidal_configured=True)
        fake_provider = _CliTidalProvider()

        with patch("mamonia.cli.load_settings", return_value=fake_settings), patch(
            "mamonia.cli.TidalProvider",
            return_value=fake_provider,
        ):
            result = CliRunner().invoke(
                app,
                [
                    "tidal-smoke",
                    "--isrc",
                    "ISRC123",
                    "--create-playlist-name",
                    "Mamonia Smoke",
                ],
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Playlist create: OK (https://tidal.com/browse/playlist/smoke)", result.output)
        self.assertEqual(fake_provider.created_with["track_ids"], ["tidal-track-1"])

    def test_tidal_smoke_can_create_playlist_from_explicit_track_id(self) -> None:
        fake_settings = SimpleNamespace(tidal_configured=True)
        fake_provider = _CliTidalProvider()

        with patch("mamonia.cli.load_settings", return_value=fake_settings), patch(
            "mamonia.cli.TidalProvider",
            return_value=fake_provider,
        ):
            result = CliRunner().invoke(
                app,
                [
                    "tidal-smoke",
                    "--track-id",
                    "explicit-track",
                    "--create-playlist-name",
                    "Mamonia Smoke",
                ],
            )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Track ID: using provided Tidal track ID explicit-track", result.output)
        self.assertIn("Playlist create: OK (https://tidal.com/browse/playlist/smoke)", result.output)
        self.assertEqual(fake_provider.created_with["track_ids"], ["explicit-track"])

    def test_profile_show_reports_enrichment_completeness(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"], spotify_track_id="sp-track")]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, spotify_id="sp-artist")],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, spotify_id="sp-artist")],
                n_artists=1,
            )
            storage = Storage(db_path)
            saved = storage.upsert_taste_profile(
                name="stored",
                source_type="txt",
                source_ref="/tmp/stored.txt",
                source_key="txt:stored",
                source_hash="stored",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.upsert_artist_enrichment(provider="spotify", artist_name="Seed Artist", provider_artist_id="sp-artist", payload={})
            storage.upsert_track_enrichment(provider="spotify", track=tracks[0], payload={})
            storage.close()

            show = CliRunner().invoke(
                app,
                ["profile", "show", str(saved["id"])],
                env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
            )
            listing = CliRunner().invoke(
                app,
                ["profile", "list"],
                env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
            )

        self.assertEqual(show.exit_code, 0)
        self.assertIn("Enrichment: complete; artists 1/1, tracks 1/1", show.output)
        self.assertEqual(listing.exit_code, 0)
        self.assertIn("enrichment 1/1 artists, 1/1 tracks", listing.output)

    def test_profile_help_exposes_profile_management_commands(self) -> None:
        result = CliRunner().invoke(app, ["profile", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("list", result.output)
        self.assertIn("show", result.output)
        self.assertIn("refresh", result.output)
        self.assertIn("delete", result.output)

    def test_discover_profile_uses_stored_seed_track_exclusions(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            storage = Storage(db_path)
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            record = storage.upsert_taste_profile(
                name="stored",
                source_type="txt",
                source_ref="/tmp/stored.txt",
                source_key="txt:stored",
                source_hash="stored",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            output_path = Path(tmp) / "out.txt"
            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ) as discover_mock:
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--profile",
                        str(record["id"]),
                        "--output-path",
                        str(output_path),
                        "--discovery-mode",
                        "deep_diverse",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn("[txt; reused; 1 tracks; 1 artists]", result.output)
            self.assertEqual(discover_mock.call_args.kwargs["seed_track_keys"], {"metadata:seed artist|seed song"})
            self.assertTrue(discover_mock.call_args.kwargs["deep_cuts"])
            self.assertTrue(discover_mock.call_args.kwargs["tiered_results"])
            self.assertFalse(output_path.exists())

    def test_discover_keyboard_interrupt_exits_cleanly(self) -> None:
        with patch("mamonia.cli.run_discover", side_effect=KeyboardInterrupt):
            result = CliRunner().invoke(app, ["discover", "--profile", "1"])

        self.assertEqual(result.exit_code, 130)
        self.assertIn("Canceled.", result.output)

    def test_discover_spotify_playlist_without_credentials_has_actionable_error(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"

            result = CliRunner().invoke(
                app,
                ["discover", "--playlist", "https://open.spotify.com/playlist/abc"],
                env={
                    "MAMONIA_HOME": str(home),
                    "MAMONIA_DB": str(db_path),
                    "SPOTIPY_CLIENT_ID": "",
                    "SPOTIPY_CLIENT_SECRET": "",
                },
            )

        self.assertEqual(result.exit_code, 1)
        self.assertIn("Spotify credentials are required for Spotify playlist input", result.output)
        self.assertIn("--reuse-profile/--profile", result.output)
        self.assertIn("local .txt playlist", result.output)

    def test_discover_spotify_playlist_provider_error_is_concise(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(_FailingSpotify())):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", "https://open.spotify.com/playlist/abc"],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

        self.assertEqual(result.exit_code, 1)
        self.assertIn("Spotify playlist unavailable: HTTP 503 from playlist API", result.output)

    def test_discover_csv_persists_input_track_enrichment(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.csv"
            playlist.write_text(
                "Track name,Artist name,Album,Playlist name,Type,ISRC,Spotify - id\n"
                "Seed Song,Seed Artist,Seed Album,Playlist,Playlist,ISRC123,sp-track-1\n",
                encoding="utf-8",
            )
            output_path = Path(tmp) / "out.csv"

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist), "--output", "csv", "--output-path", str(output_path)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            storage = Storage(db_path)
            spotify_row = storage.get_track_enrichment(provider="spotify", spotify_track_id="sp-track-1")
            input_row = storage.get_track_enrichment(provider="input", isrc="ISRC123")
            storage.close()

        self.assertEqual(result.exit_code, 0)
        self.assertIsNotNone(spotify_row)
        self.assertEqual(spotify_row["status"], "success")
        self.assertEqual(spotify_row["payload"]["source"], "input")
        self.assertEqual(spotify_row["payload"]["spotify_track_id"], "sp-track-1")
        self.assertIsNotNone(input_row)
        self.assertEqual(input_row["payload"]["isrc"], "ISRC123")

    def test_discover_csv_reuses_equivalent_tidal_profile_without_overwriting_source(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.csv"
            playlist.write_text(
                "Track name,Artist name,Album,Playlist name,Type,ISRC,Spotify - id\n"
                "Seed Song,Seed Artist,Seed Album,Playlist,Playlist,ISRC123,sp-track-1\n"
                "Other Song,Other Artist,Other Album,Playlist,Playlist,ISRC456,sp-track-2\n",
                encoding="utf-8",
            )
            tidal_source = source_identity("tidal:playlist:0e3a03f1-a3d6-4826-b10f-535b6297907f")
            tidal_tracks = [
                InputTrack(
                    artist="Seed Artist",
                    track="Seed Song",
                    artists=["Seed Artist"],
                    tidal_track_id="tidal-1",
                ),
                InputTrack(
                    artist="Other Artist",
                    track="Other Song",
                    artists=["Other Artist"],
                    tidal_track_id="tidal-2",
                ),
            ]
            profile = TasteProfile(
                artists=[
                    ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2),
                    ArtistProfile(name="Other Artist", playlist_count=1, affinity_score=2),
                ],
                top_artists=[
                    ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2),
                    ArtistProfile(name="Other Artist", playlist_count=1, affinity_score=2),
                ],
                n_artists=2,
            )
            storage = Storage(db_path)
            saved = storage.upsert_taste_profile(
                name=tidal_source["name"],
                source_type=tidal_source["source_type"],
                source_ref=tidal_source["source_ref"],
                source_key=tidal_source["source_key"],
                source_hash=tidal_source["source_hash"],
                track_count=2,
                artist_count=2,
                profile=profile,
                seed_tracks=tidal_tracks,
                seed_track_keys=track_keys_from_input(tidal_tracks),
            )
            storage.close()

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ) as discover_mock:
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            storage = Storage(db_path)
            rows = storage.list_taste_profiles()
            updated = storage.get_taste_profile(saved["id"])
            storage.close()

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Reusing a saved profile from an equivalent source library", result.output)
        self.assertIn("[tidal; equivalent-reused; 2 tracks; 2 artists]", result.output)
        self.assertEqual(len(rows), 1)
        self.assertEqual(updated["source_type"], "tidal")
        self.assertEqual(updated["source_key"], tidal_source["source_key"])
        updated_seed_tracks = json.loads(updated["seed_tracks_json"])
        self.assertEqual(updated_seed_tracks[0]["tidal_track_id"], "tidal-1")
        self.assertEqual(updated_seed_tracks[0]["spotify_track_id"], "sp-track-1")
        self.assertEqual(updated_seed_tracks[0]["isrc"], "ISRC123")
        self.assertEqual(updated_seed_tracks[0]["album"], "Seed Album")
        self.assertEqual(updated_seed_tracks[1]["tidal_track_id"], "tidal-2")
        self.assertEqual(updated_seed_tracks[1]["spotify_track_id"], "sp-track-2")
        self.assertEqual(updated_seed_tracks[1]["isrc"], "ISRC456")
        self.assertEqual(updated_seed_tracks[1]["album"], "Other Album")
        self.assertEqual(
            set(json.loads(updated["seed_track_keys_json"])),
            {
                "tidal:track:tidal-1",
                "tidal:track:tidal-2",
                "metadata:seed artist|seed song",
                "metadata:other artist|other song",
                "isrc:isrc123",
                "isrc:isrc456",
                "spotify:track:sp-track-1",
                "spotify:track:sp-track-2",
            },
        )
        self.assertEqual(
            discover_mock.call_args.kwargs["seed_track_keys"],
            {
                "tidal:track:tidal-1",
                "tidal:track:tidal-2",
                "metadata:seed artist|seed song",
                "metadata:other artist|other song",
                "isrc:isrc123",
                "isrc:isrc456",
                "spotify:track:sp-track-1",
                "spotify:track:sp-track-2",
            },
        )

    def test_discover_csv_with_different_tracks_does_not_reuse_equivalent_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.csv"
            playlist.write_text(
                "Track name,Artist name,Album,Playlist name,Type,ISRC,Spotify - id\n"
                "Seed Song,Seed Artist,Seed Album,Playlist,Playlist,ISRC123,sp-track-1\n"
                "New Song,New Artist,New Album,Playlist,Playlist,ISRC789,sp-track-3\n",
                encoding="utf-8",
            )
            tidal_source = source_identity("tidal:playlist:0e3a03f1-a3d6-4826-b10f-535b6297907f")
            tidal_tracks = [
                InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"], tidal_track_id="tidal-1"),
                InputTrack(artist="Other Artist", track="Other Song", artists=["Other Artist"], tidal_track_id="tidal-2"),
            ]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=tidal_source["name"],
                source_type=tidal_source["source_type"],
                source_ref=tidal_source["source_ref"],
                source_key=tidal_source["source_key"],
                source_hash=tidal_source["source_hash"],
                track_count=2,
                artist_count=1,
                profile=profile,
                seed_tracks=tidal_tracks,
                seed_track_keys=track_keys_from_input(tidal_tracks),
            )
            storage.close()

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            storage = Storage(db_path)
            rows = storage.list_taste_profiles()
            storage.close()

        self.assertEqual(result.exit_code, 0)
        self.assertNotIn("equivalent playlist", result.output)
        self.assertEqual(len(rows), 2)

    def test_spotify_profile_rate_limit_prints_enrichment_context(self) -> None:
        provider = _FakeSpotify()
        provider.rate_limit_warnings = [
            ProviderRateLimit("Spotify", "searching artists", retry_after_seconds=42277)
        ]
        lines: list[str] = []

        _print_provider_warnings([provider], lines.append, stage="profile")

        output = "\n".join(lines)
        self.assertIn("[Spotify API - used to enrich the data]", output)
        self.assertIn("Spotify rate limit while searching artists. Retry after about 11h 44m.", output)
        self.assertIn("Retry-After: 42277s", output)
        self.assertIn("try again at", output)
        self.assertIn("Mamonia kept any cached Spotify enrichment it already had.", output)
        self.assertIn("Spotify enrichment is paused for this run; Last.fm and MusicBrainz analysis will continue.", output)
        self.assertIn("Discovery will continue shortly.", output)
        self.assertEqual(provider.rate_limit_warnings, [])

    def test_discover_dry_run_does_not_export_or_mark_heard(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Release",
            release_date="2026-04-01",
            release_type="album",
            mb_release_group_id="rg-dry-run",
        )
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            storage = Storage(db_path)
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            record = storage.upsert_taste_profile(
                name="stored",
                source_type="txt",
                source_ref="/tmp/stored.txt",
                source_key="txt:stored",
                source_hash="stored",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            output_path = Path(tmp) / "dry-run.txt"
            def discover_side_effect(**kwargs):
                progress = kwargs["progress"]
                candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
                progress.candidate_started(candidate, processed=1, total=1)
                progress.release_group_checked(candidate, {"title": "Fresh Release"})
                progress.release_group_skipped("heard")
                progress.spotify_lookup_missed(rec)
                progress.release_accepted(rec)
                return [rec]

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                side_effect=discover_side_effect,
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--profile",
                        str(record["id"]),
                        "--dry-run",
                        "--output-path",
                        str(output_path),
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn("Dry run", result.output)
            self.assertIn("Discovery summary: 1/1 candidate artist(s), 1 release group(s) checked, 1 accepted.", result.output)
            self.assertIn("Spotify lookup misses: 1.", result.output)
            self.assertIn("Skipped release groups: heard: 1.", result.output)
            self.assertIn("Fresh Artist - Fresh Release", result.output)
            self.assertFalse(output_path.exists())
            storage = Storage(db_path)
            self.assertFalse(storage.is_heard_recommendation(rec))
            row = storage.conn.execute(
                "SELECT config_json FROM recommendation_runs ORDER BY id DESC LIMIT 1"
            ).fetchone()
            config = json.loads(row["config_json"])
            self.assertIn("spotify_cache", config)
            storage.close()

    def test_discover_create_spotify_playlist_prints_created_url(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.txt"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[
                    ReleaseTrack(
                        title="Fresh Song",
                        artists="Fresh Artist",
                        spotify_uri="spotify:track:fresh",
                    )
                ],
            )
            spotify = _PlaylistWorkflowSpotify(
                SpotifyPlaylistCreationResult(created=True, url="https://open.spotify.com/playlist/created")
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(spotify)), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--create-spotify-playlist",
                        "--spotify-playlist-name",
                        "Mamonia Test",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(output_path.exists())
            self.assertEqual(spotify.created_with["uris"], ["spotify:track:fresh"])
            self.assertIn("Spotify playlist created: https://open.spotify.com/playlist/created", result.output)

    def test_discover_create_spotify_playlist_reports_empty_uri_reason(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.txt"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[ReleaseTrack(title="Fresh Song", artists="Fresh Artist")],
            )
            spotify = _PlaylistWorkflowSpotify(SpotifyPlaylistCreationResult(created=False, reason="no_uris"))

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(spotify)), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--create-spotify-playlist",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(output_path.exists())
            self.assertEqual(spotify.created_with["uris"], [])
            self.assertIn(
                "Spotify playlist was not created because recommendations had no resolved Spotify track URIs.",
                result.output,
            )

    def test_discover_create_tidal_playlist_prints_created_url(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.txt"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[
                    ReleaseTrack(
                        title="Fresh Song",
                        artists="Fresh Artist",
                        tidal_track_id="tidal-fresh",
                    )
                ],
            )
            tidal = _PlaylistWorkflowTidal(
                TidalPlaylistCreationResult(created=True, url="https://tidal.com/browse/playlist/created")
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(tidal=tidal)), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--create-tidal-playlist",
                        "--tidal-playlist-name",
                        "Mamonia Tidal",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(output_path.exists())
            self.assertEqual(tidal.created_with["track_ids"], ["tidal-fresh"])
            self.assertIn("unique Tidal IDs prepared: 1", result.output)
            self.assertIn("duplicates dropped before playlist create: 0", result.output)
            self.assertIn("Tidal playlist created: https://tidal.com/browse/playlist/created", result.output)

    def test_discover_save_selection_logic_writes_sidecar(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.txt"
            logic_path = Path(tmp) / "selection.json"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[ReleaseTrack(title="Fresh Song", artists="Fresh Artist")],
                rationale=["seed-artist"],
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--save-selection-logic",
                        "--selection-logic-path",
                        str(logic_path),
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(logic_path.exists())
            payload = json.loads(logic_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["recommendations"][0]["title"], "Fresh Release")
            self.assertIn("Selection logic written:", result.output)

    def test_discover_csv_reports_missing_spotify_track_uris_after_export(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.csv"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[
                    ReleaseTrack(title="Resolved Song", artists="Fresh Artist", spotify_uri="spotify:track:fresh"),
                    ReleaseTrack(title="Missing Song", artists="Fresh Artist, Guest Artist"),
                ],
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist), "--output", "csv", "--output-path", str(output_path)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(output_path.exists())
            self.assertIn("Please note:", result.output)
            self.assertIn("1 song is missing Spotify URI.", result.output)
            self.assertIn("1 song is missing Tidal ID.", result.output)
            self.assertIn("Review these songs:", result.output)
            self.assertIn("If you want to see the details, press E.", result.output)
            self.assertNotIn("Missing Song by Fresh Artist, Guest Artist from Fresh Release [2026-04-01]", result.output)
            self.assertNotIn("Resolved Song by Fresh Artist from Fresh Release", result.output)

    def test_discover_create_spotify_playlist_reports_failure_reason(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "out.txt"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[
                    ReleaseTrack(
                        title="Fresh Song",
                        artists="Fresh Artist",
                        spotify_uri="spotify:track:fresh",
                    )
                ],
            )
            spotify = _PlaylistWorkflowSpotify(
                SpotifyPlaylistCreationResult(created=False, reason="token lacks playlist-modify scope")
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(spotify)), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--create-spotify-playlist",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertTrue(output_path.exists())
            self.assertIn(
                "Spotify playlist was not created due to Spotify error: token lacks playlist-modify scope. Re-authorize Spotify with playlist-modify access.",
                result.output,
            )
            self.assertIn(".spotipy_token_cache_playlist_modify_private_playlist_modify_public", result.output)

    def test_discover_dry_run_does_not_create_spotify_playlist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            output_path = Path(tmp) / "dry-run.txt"
            rec = ReleaseRecommendation(
                artist="Fresh Artist",
                title="Fresh Release",
                release_date="2026-04-01",
                tracks=[
                    ReleaseTrack(
                        title="Fresh Song",
                        artists="Fresh Artist",
                        spotify_uri="spotify:track:fresh",
                    )
                ],
            )
            spotify = _PlaylistWorkflowSpotify(
                SpotifyPlaylistCreationResult(created=True, url="https://open.spotify.com/playlist/created")
            )

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers(spotify)), patch(
                "mamonia.workflow.discover_releases",
                return_value=[rec],
            ):
                result = CliRunner().invoke(
                    app,
                    [
                        "discover",
                        "--playlist",
                        str(playlist),
                        "--output-path",
                        str(output_path),
                        "--create-spotify-playlist",
                        "--dry-run",
                    ],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertFalse(output_path.exists())
            self.assertIsNone(spotify.created_with)
            self.assertIn("no Spotify playlist was created", result.output)

    def test_discover_playlist_reuse_profile_skips_playlist_reload(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            source = source_identity(str(playlist))

            storage = Storage(db_path)
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            output_path = Path(tmp) / "out.txt"
            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow._load_playlist_tracks",
                side_effect=AssertionError("playlist should not be reloaded"),
            ), patch("mamonia.workflow.discover_releases", return_value=[]):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist), "--reuse-profile", "--output-path", str(output_path)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn("[txt; reused; 1 tracks; 1 artists]", result.output)
            self.assertFalse(output_path.exists())

    def test_discover_playlist_delta_update_prompts_and_updates_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            source = source_identity(str(playlist))

            storage = Storage(db_path)
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            saved = storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()
            playlist.write_text("New Artist - New Song\nSeed Artist - Seed Song\n", encoding="utf-8")

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ) as discover_mock:
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist)],
                    input="y\n",
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn("I see that the playlist changed a little.", result.output)
            self.assertIn("added 1 tracks / removed 0 tracks", result.output)
            self.assertIn("[txt; delta-updated; 2 tracks; 2 artists]", result.output)
            self.assertEqual(
                discover_mock.call_args.kwargs["seed_track_keys"],
                {"metadata:seed artist|seed song", "metadata:new artist|new song"},
            )

            storage = Storage(db_path)
            rows = storage.list_taste_profiles()
            updated = storage.get_taste_profile(saved["id"])
            storage.close()

        self.assertEqual(len(rows), 1)
        self.assertEqual(updated["track_count"], 2)

    def test_discover_playlist_declined_delta_keeps_saved_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)

            storage = Storage(db_path)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            saved = storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()
            playlist.write_text("Seed Artist - Seed Song\nNew Artist - New Song\n", encoding="utf-8")

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ) as discover_mock:
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(playlist)],
                    input="n\n",
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

            self.assertEqual(result.exit_code, 0)
            self.assertIn("I see that the playlist changed a little.", result.output)
            self.assertIn("Keeping the saved profile exactly as it is.", result.output)
            self.assertIn("[txt; reused; 1 tracks; 1 artists]", result.output)
            self.assertEqual(discover_mock.call_args.kwargs["seed_track_keys"], {"metadata:seed artist|seed song"})

            storage = Storage(db_path)
            updated = storage.get_taste_profile(saved["id"])
            storage.close()

        self.assertEqual(updated["track_count"], 1)

    def test_discover_profile_decision_callback_can_reuse_changed_playlist_without_cli_prompt(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            saved = storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()
            playlist.write_text("Seed Artist - Seed Song\nNew Artist - New Song\n", encoding="utf-8")
            contexts: list[ProfileDecisionContext] = []
            lines: list[str] = []

            def choose(context: ProfileDecisionContext):
                contexts.append(context)
                return "reuse"

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=_fake_workflow_providers()
            ), patch("mamonia.workflow.discover_releases", return_value=[]) as discover_mock:
                run_discover(
                    DiscoverOptions(playlist=str(playlist), profile_decision_callback=choose),
                    emit=lines.append,
                    emit_error=lines.append,
                )

            storage = Storage(db_path)
            updated = storage.get_taste_profile(saved["id"])
            storage.close()

        self.assertEqual(len(contexts), 1)
        self.assertTrue(contexts[0].changed)
        self.assertEqual(contexts[0].added_count, 1)
        self.assertTrue(any("Keeping the saved profile exactly as it is." in line for line in lines))
        self.assertEqual(updated["track_count"], 1)
        self.assertEqual(discover_mock.call_args.kwargs["seed_track_keys"], {"metadata:seed artist|seed song"})

    def test_discover_profile_decision_context_uses_durable_enrichment_completeness(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [
                InputTrack(
                    artist="Seed Artist",
                    track="Seed Song",
                    artists=["Seed Artist"],
                    spotify_track_id="sp-track-1",
                )
            ]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, spotify_id="sp-artist-1")],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, spotify_id="sp-artist-1")],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.upsert_artist_enrichment(
                provider="spotify",
                artist_name="Seed Artist",
                provider_artist_id="sp-artist-1",
                status="miss",
                error="not enriched yet",
            )
            storage.upsert_track_enrichment(
                provider="spotify",
                track=tracks[0],
                status="miss",
                error="not enriched yet",
            )
            storage.close()
            contexts: list[ProfileDecisionContext] = []

            def choose(context: ProfileDecisionContext):
                contexts.append(context)
                return "reuse"

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=_fake_workflow_providers()
            ), patch("mamonia.workflow.discover_releases", return_value=[]):
                run_discover(
                    DiscoverOptions(playlist=str(playlist), profile_decision_callback=choose),
                    emit=lambda message: None,
                    emit_error=lambda message: None,
                )

        self.assertEqual(len(contexts), 1)
        self.assertFalse(contexts[0].enrichment_complete)

    def test_discover_profile_decision_callback_refreshes_enrichment_with_reused_artists(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, genres=["saved-genre"])],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2, genres=["saved-genre"])],
                top_genres=[],
                n_artists=1,
            )
            storage = Storage(db_path)
            saved = storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()
            lines: list[str] = []

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=_fake_workflow_providers()
            ), patch("mamonia.workflow.discover_releases", return_value=[]):
                run_discover(
                    DiscoverOptions(
                        playlist=str(playlist),
                        profile_decision_callback=lambda context: "refresh_enrichment",
                    ),
                    emit=lines.append,
                    emit_error=lines.append,
                )

            storage = Storage(db_path)
            updated = storage.get_taste_profile(saved["id"])
            updated_profile = TasteProfile.model_validate(json.loads(updated["profile_json"]))
            storage.close()

        self.assertTrue(any("Refreshed the saved profile's enrichment" in line for line in lines))
        self.assertIn("[txt; enrichment-refreshed; 1 tracks; 1 artists]", "\n".join(lines))
        self.assertEqual(updated_profile.artists[0].genres, ["saved-genre"])

    def test_discover_enrichment_only_refreshes_profile_and_skips_discovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()
            lines: list[str] = []

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=_fake_workflow_providers()
            ), patch("mamonia.workflow.discover_releases", return_value=[]) as discover_mock:
                run_discover(
                    DiscoverOptions(
                        playlist=str(playlist),
                        enrichment_only=True,
                        profile_decision_callback=lambda context: "refresh_enrichment",
                    ),
                    emit=lines.append,
                    emit_error=lines.append,
                )

        discover_mock.assert_not_called()
        self.assertIn("[3/5] Enrichment refreshed; discovery skipped for this run.", lines)
        self.assertIn("[5/5] Done.", lines)

    def test_discover_fresh_rebuild_disables_global_memory_for_that_run(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Active Artist - Active Song\n", encoding="utf-8")
            active_tracks = [InputTrack(artist="Active Artist", track="Active Song", artists=["Active Artist"])]
            other_tracks = [InputTrack(artist="Other Artist", track="Other Song", artists=["Other Artist"])]
            source = source_identity_from_tracks(str(playlist), active_tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Active Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Active Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=active_tracks,
                seed_track_keys=track_keys_from_input(active_tracks),
            )
            storage.upsert_taste_profile(
                name="other",
                source_type="txt",
                source_ref="/tmp/other.txt",
                source_key="txt:other",
                source_hash="other",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=other_tracks,
                seed_track_keys=track_keys_from_input(other_tracks),
            )
            storage.close()
            lines: list[str] = []

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=_fake_workflow_providers()
            ), patch("mamonia.workflow.discover_releases", return_value=[]) as discover_mock:
                run_discover(
                    DiscoverOptions(
                        playlist=str(playlist),
                        global_memory=True,
                        profile_decision_callback=lambda context: "fresh_rebuild",
                    ),
                    emit=lines.append,
                    emit_error=lines.append,
                )

            storage = Storage(db_path)
            row = storage.conn.execute(
                "SELECT config_json FROM recommendation_runs ORDER BY id DESC LIMIT 1"
            ).fetchone()
            config = json.loads(row["config_json"])
            storage.close()

        self.assertTrue(any("Global memory is off for this fresh rebuild" in line for line in lines))
        self.assertEqual(discover_mock.call_args.kwargs["seed_track_keys"], {"metadata:active artist|active song"})
        self.assertFalse(config["global_memory"])
        self.assertEqual(config["profile_state"], "fresh-rebuilt")

    def test_discover_matches_copied_shuffled_local_playlist_by_track_hash(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            original = Path(tmp) / "original.txt"
            copied = Path(tmp) / "copy.txt"
            original_tracks = [
                InputTrack(artist="A", track="One"),
                InputTrack(artist="B", track="Two"),
            ]
            original.write_text("A - One\nB - Two\n", encoding="utf-8")
            copied.write_text("B - Two\nA - One\n", encoding="utf-8")
            source = source_identity_from_tracks(str(original), original_tracks)

            storage = Storage(db_path)
            profile = TasteProfile(
                artists=[
                    ArtistProfile(name="A", playlist_count=1, affinity_score=2),
                    ArtistProfile(name="B", playlist_count=1, affinity_score=2),
                ],
                top_artists=[
                    ArtistProfile(name="A", playlist_count=1, affinity_score=2),
                    ArtistProfile(name="B", playlist_count=1, affinity_score=2),
                ],
                n_artists=2,
            )
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=2,
                artist_count=2,
                profile=profile,
                seed_tracks=original_tracks,
                seed_track_keys=track_keys_from_input(original_tracks),
            )
            storage.close()

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ):
                result = CliRunner().invoke(
                    app,
                    ["discover", "--playlist", str(copied)],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("The saved profile already matches this playlist, so there was no track delta to analyze.", result.output)
        self.assertNotIn("Do you want me to update", result.output)

    def test_discover_global_memory_combines_seed_track_exclusions_from_all_profiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            db_path = home / "mamonia.sqlite"
            storage = Storage(db_path)
            active_tracks = [InputTrack(artist="Active Artist", track="Active Song", artists=["Active Artist"])]
            other_tracks = [InputTrack(artist="Other Artist", track="Other Song", artists=["Other Artist"])]
            profile = TasteProfile(
                artists=[ArtistProfile(name="Active Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Active Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            active = storage.upsert_taste_profile(
                name="active",
                source_type="txt",
                source_ref="/tmp/active.txt",
                source_key="txt:active",
                source_hash="active",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=active_tracks,
                seed_track_keys=track_keys_from_input(active_tracks),
            )
            storage.upsert_taste_profile(
                name="other",
                source_type="txt",
                source_ref="/tmp/other.txt",
                source_key="txt:other",
                source_hash="other",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=other_tracks,
                seed_track_keys=track_keys_from_input(other_tracks),
            )
            storage.close()

            with patch("mamonia.workflow._providers", return_value=_fake_workflow_providers()), patch(
                "mamonia.workflow.discover_releases",
                return_value=[],
            ) as discover_mock:
                result = CliRunner().invoke(
                    app,
                    ["discover", "--profile", str(active["id"]), "--global-memory"],
                    env={"MAMONIA_HOME": str(home), "MAMONIA_DB": str(db_path)},
                )

        self.assertEqual(result.exit_code, 0)
        self.assertIn("Global memory: excluding 2 known seed track(s) (1 learned from other saved profile(s)).", result.output)
        self.assertEqual(
            discover_mock.call_args.kwargs["seed_track_keys"],
            {"metadata:active artist|active song", "metadata:other artist|other song"},
        )

    def test_default_output_path_is_current_directory_not_hidden_data_dir(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)
        path = _default_output_path("txt", now=now)

        self.assertEqual(path.parent, Path.cwd())
        self.assertEqual(path.name, "23_04_26.txt")

    def test_default_output_path_uses_csv_suffix_for_csv_export(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)
        path = _default_output_path("csv", now=now)

        self.assertEqual(path.parent, Path.cwd())
        self.assertEqual(path.name, "23_04_26.csv")
        self.assertEqual(path.suffix, ".csv")

    def test_default_output_path_includes_sanitized_source_hint(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)

        path = _default_output_path("csv", source_name="Mój Playlist: Fresh Finds!", now=now)

        self.assertEqual(path.name, "moj-playlist_23_04_26.csv")

    def test_default_output_path_avoids_existing_file_collision(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)
        with tempfile.TemporaryDirectory() as tmp:
            existing = Path(tmp) / "tracks_23_04_26.csv"
            existing.write_text("old\n", encoding="utf-8")

            with patch("mamonia.workflow.Path.cwd", return_value=Path(tmp)):
                path = _default_output_path("csv", source_name="tracks", now=now)

        self.assertEqual(path.name, "tracks_23_04_26_2.csv")

    def test_default_output_path_truncates_source_name_to_twelve_characters(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)

        path = _default_output_path("csv", source_name="tidal-da273418-e295-4098-856a-9613cfc3ef", now=now)

        self.assertEqual(path.name, "tidal-da2734_23_04_26.csv")

    def test_default_output_path_uses_incrementing_suffixes_for_multiple_collisions(self) -> None:
        now = dt.datetime(2026, 4, 23, 12, 34, 56)
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "tracks_23_04_26.csv").write_text("old\n", encoding="utf-8")
            Path(tmp, "tracks_23_04_26_2.csv").write_text("older\n", encoding="utf-8")

            with patch("mamonia.workflow.Path.cwd", return_value=Path(tmp)):
                path = _default_output_path("csv", source_name="tracks", now=now)

        self.assertEqual(path.name, "tracks_23_04_26_3.csv")


class _FakeSpotify:
    available = False


class _FakeListenBrainz:
    available = False
    rate_limit_warnings = []


class _FakeDeezer:
    available = True
    rate_limit_warnings = []


class _FakeTidal:
    available = False


class _PlaylistWorkflowTidal:
    available = True

    def __init__(self, result: TidalPlaylistCreationResult) -> None:
        self.result = result
        self.created_with: dict | None = None
        self.rate_limit_warnings = []

    def ensure_session(self):
        return True

    def lookup_track(self, *args, **kwargs):
        return None

    def create_playlist(self, name: str, description: str, track_ids: list[str]):
        self.created_with = {"name": name, "description": description, "track_ids": list(track_ids)}
        return self.result


class _CliTidalProvider:
    available = True

    def __init__(self):
        self.created_with = None

    def diagnostic_summary(self):
        return {
            "provider_status": "ready for playlist analysis and native playlist creation (experimental)",
            "auth_flow": "PKCE session-file login",
            "native_playlist_creation": "experimental; verify with `mamonia tidal-smoke` before relying on it",
        }

    def ensure_session(self):
        return True

    def fetch_user_playlists(self):
        return [SimpleNamespace(id="playlist-1", tracks=4, name="Saved Tidal")]

    def check_playlist_access(self, playlist):
        return 2

    def lookup_track_by_isrc(self, isrc):
        return SimpleNamespace(track_id="tidal-track-1")

    def create_playlist(self, name, description, track_ids):
        self.created_with = {"name": name, "description": description, "track_ids": list(track_ids)}
        return TidalPlaylistCreationResult(created=True, url="https://tidal.com/browse/playlist/smoke")


class _PlaylistWorkflowSpotify:
    available = True

    def __init__(self, result: SpotifyPlaylistCreationResult) -> None:
        self.result = result
        self.created_with: dict | None = None
        self.rate_limit_warnings = []

    def artist_metadata_from_tracks(self, tracks):
        return {}

    def backfill_track_enrichment(self, tracks):
        return 0

    def create_playlist(self, name: str, description: str, uris: list[str]):
        self.created_with = {"name": name, "description": description, "uris": list(uris)}
        return self.result

    def permission_guidance(self, operation: str) -> str:
        return (
            "Re-authorize Spotify with playlist-modify access. "
            "If you recently changed scopes, delete C:\\fake\\.spotipy_token_cache_playlist_modify_private_playlist_modify_public and rerun so Mamonia can request a fresh token."
        )


class _FailingSpotify:
    available = True

    def fetch_playlist_tracks(self, playlist: str):
        raise RuntimeError("HTTP 503 from playlist API\nsecond line should be hidden")


def _fake_workflow_providers(spotify=None, tidal=None):
    return (
        spotify or _FakeSpotify(),
        object(),
        object(),
        tidal or _FakeTidal(),
        _FakeListenBrainz(),
        _FakeDeezer(),
    )


if __name__ == "__main__":
    unittest.main()
