from __future__ import annotations

import tempfile
import threading
import time
import unittest
import datetime as dt
from pathlib import Path

from mamonia.analysis import build_taste_profile
from mamonia.config import Settings
from mamonia.models import InputTrack, ReleaseTrack
from mamonia.providers import ProviderRateLimit
from mamonia.providers.spotify import (
    SPOTIFY_OPERATION_SPECS,
    SpotifyProvider,
    playlist_item_track,
    select_representative_tracks,
)
from mamonia.storage import Storage
from mamonia.utils import normalized_cache_key


class SpotifySelectionTests(unittest.TestCase):
    def test_playlist_item_track_supports_track_and_item_shapes(self) -> None:
        old_shape = {"track": {"type": "track", "name": "Old"}}
        current_shape = {"item": {"type": "track", "name": "Current"}}

        self.assertEqual(playlist_item_track(old_shape)["name"], "Old")
        self.assertEqual(playlist_item_track(current_shape)["name"], "Current")

    def test_select_representative_tracks_caps_and_preserves_album_order(self) -> None:
        raw = [
            {"id": "1", "name": "Opener", "track_number": 1, "uri": "uri:1", "artists": [{"name": "Artist"}]},
            {"id": "2", "name": "Low Pop", "track_number": 2, "uri": "uri:2", "artists": [{"name": "Artist"}]},
            {"id": "3", "name": "Single", "track_number": 3, "uri": "uri:3", "artists": [{"name": "Artist"}]},
            {"id": "4", "name": "Anchor", "track_number": 4, "uri": "uri:4", "artists": [{"name": "Artist"}]},
        ]
        details = {
            "1": {"id": "1", "popularity": 40},
            "2": {"id": "2", "popularity": 5},
            "3": {"id": "3", "popularity": 80},
            "4": {"id": "4", "popularity": 70},
        }

        selected = select_representative_tracks(raw, details, cap=2)

        self.assertEqual([track.title for track in selected], ["Low Pop", "Single"])
        self.assertEqual(len(selected), 2)

    def test_representative_tracks_does_not_require_bulk_track_details(self) -> None:
        provider = _AlbumOnlySpotifyProvider()

        album_id, album_uri, tracks = provider.representative_tracks("Artist", "Album", cap=2)

        self.assertEqual(album_id, "album-id")
        self.assertEqual(album_uri, "spotify:album:album-id")
        self.assertEqual([track.title for track in tracks], ["Opener", "Second"])
        self.assertTrue(all(track.resolution_source == "spotify_album_tracklist" for track in tracks))

    def test_representative_tracks_falls_back_to_track_search_when_album_lookup_misses(self) -> None:
        provider = _TrackSearchRepresentativeProvider(
            {
                'artist:"Artist" album:"Hard To Find Album"': [],
                'album:"Hard To Find Album"': [],
            },
            {
                'artist:"Artist" album:"Hard To Find Album"': [
                    {
                        "id": "track-1",
                        "name": "Opener",
                        "uri": "spotify:track:track-1",
                        "popularity": 40,
                        "track_number": 1,
                        "artists": [{"name": "Artist"}],
                        "album": {"id": "album-1", "name": "Hard To Find Album"},
                    },
                    {
                        "id": "track-2",
                        "name": "Anchor",
                        "uri": "spotify:track:track-2",
                        "popularity": 60,
                        "track_number": 2,
                        "artists": [{"name": "Artist"}],
                        "album": {"id": "album-1", "name": "Hard To Find Album"},
                    },
                ]
            },
        )

        album_id, album_uri, tracks = provider.representative_tracks("Artist", "Hard To Find Album", cap=2)

        self.assertEqual(album_id, "album-1")
        self.assertEqual(album_uri, "spotify:album:album-1")
        self.assertEqual([track.title for track in tracks], ["Opener", "Anchor"])
        self.assertTrue(all(track.resolution_source == "spotify_track_search_album_context" for track in tracks))
        self.assertEqual(provider._client.search_calls, 3)

    def test_representative_tracks_avoids_broad_track_search_when_disabled(self) -> None:
        provider = _TrackSearchRepresentativeProvider(
            {
                'artist:"Artist" album:"Hard To Find Album"': [],
            },
            {
                'artist:"Artist" album:"Hard To Find Album"': [],
                'album:"Hard To Find Album"': [
                    {
                        "id": "track-2",
                        "name": "Anchor",
                        "uri": "spotify:track:track-2",
                        "popularity": 60,
                        "track_number": 2,
                        "artists": [{"name": "Artist"}],
                        "album": {"id": "album-1", "name": "Hard To Find Album"},
                    },
                ],
            },
        )

        album_id, album_uri, tracks = provider.representative_tracks("Artist", "Hard To Find Album", cap=2, allow_broad_search=False)

        self.assertIsNone(album_id)
        self.assertIsNone(album_uri)
        self.assertEqual(tracks, [])

    def test_search_album_falls_back_to_album_title_when_artist_scoped_query_misses(self) -> None:
        provider = _SearchSpotifyProvider(
            {
                'artist:"Composer" album:"Film Score"': [],
                'album:"Film Score"': [
                    {
                        "id": "various-score",
                        "name": "Film Score",
                        "album_type": "album",
                        "artists": [{"name": "Various Artists"}],
                    }
                ],
            }
        )

        album = provider.search_album("Composer", "Film Score")

        self.assertEqual(album["id"], "various-score")

    def test_search_album_ranks_exact_album_title_above_artist_only_noise(self) -> None:
        provider = _SearchSpotifyProvider(
            {
                'artist:"Composer" album:"Film Score"': [
                    {
                        "id": "artist-noise",
                        "name": "Film Score Live",
                        "album_type": "album",
                        "artists": [{"name": "Composer"}],
                    }
                ],
                'album:"Film Score"': [
                    {
                        "id": "exact-various",
                        "name": "Film Score",
                        "album_type": "album",
                        "artists": [{"name": "Various Artists"}],
                    }
                ],
            }
        )

        album = provider.search_album("Composer", "Film Score")

        self.assertEqual(album["id"], "exact-various")

    def test_search_artist_uses_cached_hit_without_api_call(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache(
                "spotify",
                normalized_cache_key("artist-name-v2", artist="Cached Artist"),
                {"id": "artist-id", "name": "Cached Artist", "genres": ["ambient"]},
                ttl_seconds=60,
            )
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient()

            artist = provider.search_artist("Cached Artist")
            storage.close()

        self.assertEqual(artist["id"], "artist-id")
        self.assertEqual(provider._client.search_calls, 0)

    def test_search_artist_negative_miss_is_cached(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(artist_items=[])

            self.assertIsNone(provider.search_artist("Missing Artist"))
            self.assertIsNone(provider.search_artist("Missing Artist"))
            storage.close()

        self.assertEqual(provider._client.search_calls, 1)
        self.assertNotEqual(provider._client.markets, ["from_token"])

    def test_album_search_negative_miss_is_cached(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(album_items=[])

            self.assertIsNone(provider.search_album("Artist", "Missing Album", allow_album_only=False))
            self.assertIsNone(provider.search_album("Artist", "Missing Album", allow_album_only=False))
            storage.close()

        self.assertEqual(provider._client.search_calls, 1)

    def test_album_tracks_use_cached_tracklist_without_api_call(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache(
                "spotify",
                "album-tracks-v1:album-id",
                [{"id": "track-id", "name": "Cached Track", "track_number": 1, "artists": [{"name": "Artist"}]}],
                ttl_seconds=60,
            )
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient()

            tracks = provider.album_tracks("album-id")
            storage.close()

        self.assertEqual(tracks[0]["name"], "Cached Track")
        self.assertEqual(provider._client.album_track_calls, 0)

    def test_album_tracks_uses_album_tracks_endpoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            settings = _settings(tmp)
            settings.spotify_market = ""
            provider = SpotifyProvider(settings, storage)
            provider._client = _AlbumTracksGetCapableSpotifyClient()

            tracks = provider.album_tracks("album-id")
            storage.close()

        self.assertEqual(provider._client.last_get_path, "albums/album-id/tracks")
        self.assertEqual(provider._client.last_get_kwargs, {"limit": 50, "offset": 0})
        self.assertEqual(tracks[0]["id"], "track-1")

    def test_album_tracks_retries_short_rate_limit_before_succeeding(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = _NoSleepSpotifyProvider(_settings(tmp), storage)
            provider._client = _RetryAlbumTracksClient()

            tracks = provider.album_tracks("album-id")
            storage.close()

        self.assertEqual(tracks[0]["id"], "track-1")
        self.assertEqual(provider._client.calls, 2)
        self.assertIn(3, provider.sleep_calls)

    def test_force_refresh_bypasses_cached_artist_lookup(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            settings = _settings(tmp)
            settings.force_refresh = True
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache(
                "spotify",
                normalized_cache_key("artist-name-v2", artist="Cached Artist"),
                {"id": "artist-id", "name": "Cached Artist"},
                ttl_seconds=60,
            )
            provider = SpotifyProvider(settings, storage)
            provider._client = _CountingSpotifyClient(artist_items=[{"id": "fresh-id", "name": "Cached Artist"}])

            artist = provider.search_artist("Cached Artist")
            storage.close()

        self.assertEqual(artist["id"], "fresh-id")
        self.assertEqual(provider._client.search_calls, 1)

    def test_input_artist_ids_use_cached_id_lookup_instead_of_name_search(self) -> None:
        tracks = [
            InputTrack(
                artist="Input Name",
                artists=["Input Name"],
                track="Seed",
                spotify_artist_ids=["artist-id"],
            ),
            InputTrack(
                artist="Input Name",
                artists=["Input Name"],
                track="Another",
                spotify_artist_ids=["artist-id"],
            ),
        ]
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(
                artists_by_id={
                    "artist-id": {"id": "artist-id", "name": "Spotify Name", "genres": ["industrial"]}
                }
            )

            metadata = provider.artist_metadata_from_tracks(tracks)
            profile = build_taste_profile(tracks, spotify=provider, max_artists=1, spotify_artist_metadata=metadata)
            storage.close()

        self.assertEqual(provider._client.single_artist_calls, 1)
        self.assertEqual(provider._client.artist_calls, 0)
        self.assertEqual(provider._client.search_calls, 0)
        self.assertEqual(profile.artists[0].spotify_id, "artist-id")
        self.assertEqual(profile.artists[0].genres, ["industrial"])

    def test_artists_bulk_bounds_single_artist_request_concurrency(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = _NoSleepSpotifyProvider(_settings(tmp), storage)
            provider._client = _ConcurrentCountingSpotifyClient(
                artists_by_id={
                    f"artist-{idx}": {"id": f"artist-{idx}", "name": f"Artist {idx}"}
                    for idx in range(20)
                }
            )

            artists = provider.artists_bulk([f"artist-{idx}" for idx in range(20)])
            storage.close()

        self.assertEqual(len(artists), 20)
        self.assertLessEqual(provider._client.max_active_artist_calls, 4)
        self.assertEqual(provider._client.artist_calls, 0)
        self.assertEqual(provider._client.single_artist_calls, 20)

    def test_backfill_track_enrichment_uses_spotify_track_ids_and_stores_details(self) -> None:
        tracks = [InputTrack(artist="Input Artist", track="Input Song", spotify_track_id="track-id")]
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_track_enrichment(
                provider="spotify",
                track=tracks[0],
                payload={"source": "input", "spotify_track_id": "track-id"},
            )
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(
                tracks_by_id={
                    "track-id": {
                        "id": "track-id",
                        "name": "Spotify Song",
                        "uri": "spotify:track:track-id",
                        "popularity": 42,
                        "artists": [{"id": "artist-id", "name": "Spotify Artist"}],
                        "album": {"id": "album-id", "name": "Spotify Album", "artists": []},
                        "external_ids": {"isrc": "ISRC123"},
                    }
                }
            )

            saved = provider.backfill_track_enrichment(tracks)
            row = storage.get_track_enrichment(provider="spotify", spotify_track_id="track-id")
            storage.close()

        self.assertEqual(saved, 1)
        self.assertEqual(provider._client.single_track_calls, 1)
        self.assertEqual(provider._client.track_calls, 0)
        self.assertEqual(row["status"], "success")
        self.assertEqual(row["payload"]["source"], "spotify_track_details")
        self.assertEqual(row["payload"]["isrc"], "ISRC123")
        self.assertEqual(row["payload"]["spotify_album_id"], "album-id")

    def test_backfill_track_enrichment_skips_existing_spotify_details(self) -> None:
        tracks = [InputTrack(artist="Input Artist", track="Input Song", spotify_track_id="track-id")]
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_track_enrichment(
                provider="spotify",
                track=tracks[0],
                payload={"source": "spotify_track_details", "spotify_track_id": "track-id"},
            )
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(tracks_by_id={"track-id": {"id": "track-id"}})

            saved = provider.backfill_track_enrichment(tracks)
            storage.close()

        self.assertEqual(saved, 0)
        self.assertEqual(provider._client.track_calls, 0)

    def test_backfill_track_enrichment_records_missing_ids(self) -> None:
        tracks = [InputTrack(artist="Missing Artist", track="Missing Song", spotify_track_id="missing-track")]
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(tracks_by_id={})

            saved = provider.backfill_track_enrichment(tracks)
            row = storage.get_track_enrichment(provider="spotify", spotify_track_id="missing-track")
            storage.close()

        self.assertEqual(saved, 0)
        self.assertEqual(provider._client.single_track_calls, 1)
        self.assertEqual(provider._client.track_calls, 0)
        self.assertEqual(row["status"], "miss")

    def test_tracks_bulk_stops_on_permission_error_without_deprecated_bulk_endpoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(track_error=_ForbiddenError("Forbidden"))

            tracks = provider.tracks_bulk(["track-1", "track-2"])
            storage.close()

        self.assertEqual(tracks, [])
        self.assertEqual(provider._client.track_calls, 0)
        self.assertLessEqual(provider._client.single_track_calls, 4)
        self.assertEqual(len(provider.rate_limit_warnings), 1)
        self.assertTrue(provider.rate_limit_warnings[0].is_permission_error)

    def test_tracks_bulk_omits_market_parameter_when_not_configured(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            settings = _settings(tmp)
            settings.spotify_market = ""
            provider = SpotifyProvider(settings, storage)
            provider._client = _GetCapableSpotifyClient()

            provider.tracks_bulk(["track-1"])
            storage.close()

        self.assertEqual(provider._client.last_get_path, "tracks/track-1")
        self.assertEqual(provider._client.last_get_kwargs, {})

    def test_search_artist_omits_market_parameter_when_not_configured(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            settings = _settings(tmp)
            settings.spotify_market = ""
            provider = SpotifyProvider(settings, storage)
            provider._client = _CountingSpotifyClient(artist_items=[{"id": "artist-id", "name": "Artist"}])

            provider.search_artist("Artist")
            storage.close()

        self.assertEqual(provider._client.search_calls, 1)
        self.assertEqual(provider._client.markets, [None])

    def test_artists_bulk_stops_on_permission_error_without_deprecated_bulk_endpoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(single_artist_error=_ForbiddenError("Forbidden"))

            artists = provider.artists_bulk(["artist-1", "artist-2"])
            storage.close()

        self.assertEqual(artists, [])
        self.assertLessEqual(provider._client.single_artist_calls, 4)
        self.assertEqual(provider._client.artist_calls, 0)
        self.assertEqual(len(provider.rate_limit_warnings), 1)
        self.assertTrue(provider.rate_limit_warnings[0].is_permission_error)

    def test_backfill_release_tracks_uses_cached_enrichment_before_search(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_track_enrichment(
                provider="spotify",
                artist="Artist",
                title="Song",
                album="Album",
                isrc="ISRC1",
                spotify_track_id="cached-track",
                payload={
                    "name": "Song",
                    "uri": "spotify:track:cached-track",
                    "artists": ["Artist"],
                    "album": "Album",
                },
            )
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient()

            tracks = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist", isrc="ISRC1")])
            storage.close()

        self.assertEqual(tracks[0].spotify_track_id, "cached-track")
        self.assertEqual(tracks[0].resolution_source, "spotify_cached_track")
        self.assertEqual(provider._client.search_calls, 0)

    def test_backfill_release_tracks_uses_isrc_hit_and_caches_result(self) -> None:
        query = "isrc:ISRC1"
        item = {
            "id": "sp-1",
            "name": "Song",
            "uri": "spotify:track:sp-1",
            "popularity": 50,
            "artists": [{"name": "Artist"}],
            "album": {"id": "album-1", "name": "Album"},
            "external_ids": {"isrc": "ISRC1"},
        }
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(track_search_items={query: [item]})

            first = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist", isrc="ISRC1")])[0]
            second = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist", isrc="ISRC1")])[0]
            storage.close()

        self.assertEqual(first.spotify_track_id, "sp-1")
        self.assertEqual(first.resolution_source, "spotify_track_search_isrc")
        self.assertEqual(second.spotify_track_id, "sp-1")
        self.assertEqual(provider._client.search_calls, 1)

    def test_backfill_release_tracks_uses_keyword_fallback_after_strict_miss(self) -> None:
        strict_query = 'track:"Song" artist:"Artist" album:"Album"'
        keyword_query = "artist song album"
        keyword_item = {
            "id": "sp-keyword",
            "name": "Song",
            "uri": "spotify:track:sp-keyword",
            "popularity": 33,
            "artists": [{"name": "Artist"}],
            "album": {"id": "album-1", "name": "Album"},
        }
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(
                track_search_items={
                    strict_query: [],
                    keyword_query: [keyword_item],
                }
            )

            resolved = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist")])[0]
            storage.close()

        self.assertEqual(resolved.spotify_track_id, "sp-keyword")
        self.assertEqual(resolved.resolution_source, "spotify_track_search_keywords")
        self.assertEqual(provider._client.search_calls, 2)

    def test_backfill_release_tracks_rejects_low_confidence_candidates_and_caches_miss(self) -> None:
        strict_query = 'track:"Song" artist:"Artist" album:"Album"'
        keyword_query = "artist song album"
        noisy_item = {
            "id": "wrong-track",
            "name": "Different Song",
            "uri": "spotify:track:wrong-track",
            "popularity": 99,
            "artists": [{"name": "Other Artist"}],
            "album": {"id": "album-2", "name": "Different Album"},
        }
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(
                track_search_items={
                    strict_query: [noisy_item],
                    keyword_query: [noisy_item],
                }
            )

            first = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist")])[0]
            second = provider.backfill_release_tracks("Album", [ReleaseTrack(title="Song", artists="Artist")])[0]
            storage.close()

        self.assertIsNone(first.spotify_track_id)
        self.assertEqual(first.resolution_source, "musicbrainz_tracklist")
        self.assertIsNone(second.spotify_track_id)
        self.assertEqual(provider._client.search_calls, 2)

    def test_backfill_release_tracks_rejects_album_first_match_outside_discovery_window(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(
                album_items=[
                    {
                        "id": "album-2024",
                        "name": "Boots on The Ground",
                        "uri": "spotify:album:album-2024",
                        "release_date": "2024-05-01",
                        "album_type": "album",
                        "artists": [{"name": "803Fresh"}],
                    }
                ]
            )

            resolved = provider.backfill_release_tracks(
                "Boots on The Ground",
                [ReleaseTrack(title="Boots on the Ground", artists="Massive Attack", track_number=1)],
                artist_name="Massive Attack",
                release_date="2026-04-20",
                discovery_months=6,
                discovery_today=dt.date(2026, 4, 30),
            )[0]
            storage.close()

        self.assertIsNone(resolved.spotify_track_id)
        self.assertEqual(resolved.resolution_source, "musicbrainz_tracklist")

    def test_backfill_release_tracks_allows_window_fallback_when_mb_date_mismatches(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider.search_album = lambda artist, album, allow_album_only=True: {
                "id": "album-2026",
                "name": "Boots on The Ground",
                "uri": "spotify:album:album-2026",
                "release_date": "2026-04-10",
                "album_type": "album",
                "artists": [{"name": "Massive Attack"}],
            }  # type: ignore[method-assign]
            provider.album_tracks = lambda album_id: [  # type: ignore[method-assign]
                {
                    "id": "track-1",
                    "name": "Boots on the Ground",
                    "track_number": 1,
                    "uri": "spotify:track:track-1",
                    "artists": [{"name": "Massive Attack"}],
                    "external_ids": {},
                }
            ]

            resolved = provider.backfill_release_tracks(
                "Boots on The Ground",
                [ReleaseTrack(title="Boots on the Ground", artists="Massive Attack", track_number=1)],
                artist_name="Massive Attack",
                release_date="2026-04-20",
                discovery_months=6,
                discovery_today=dt.date(2026, 4, 30),
            )[0]
            storage.close()

        self.assertEqual(resolved.spotify_track_id, "track-1")
        self.assertEqual(resolved.resolution_source, "spotify_album_tracklist")

    def test_backfill_release_tracks_allows_discovery_window_fallback_when_mb_date_missing(self) -> None:
        strict_query = 'track:"Song" artist:"Artist" album:"Album"'
        item = {
            "id": "sp-1",
            "name": "Song",
            "uri": "spotify:track:sp-1",
            "popularity": 50,
            "artists": [{"name": "Artist"}],
            "album": {"id": "album-1", "name": "Album", "release_date": "2026-04-10"},
        }
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            provider = SpotifyProvider(_settings(tmp), storage)
            provider._client = _CountingSpotifyClient(track_search_items={strict_query: [item]})

            resolved = provider.backfill_release_tracks(
                "Album",
                [ReleaseTrack(title="Song", artists="Artist")],
                release_date=None,
                discovery_months=6,
                discovery_today=dt.date(2026, 4, 30),
            )[0]
            storage.close()

        self.assertEqual(resolved.spotify_track_id, "sp-1")

    def test_create_playlist_creates_private_playlist_and_adds_items(self) -> None:
        provider = _PlaylistSpotifyProvider()

        result = provider.create_playlist(
            "Mamonia Test",
            "Generated by Mamonia.",
            ["spotify:track:1", "spotify:track:2"],
        )

        self.assertTrue(result.created)
        self.assertEqual(result.url, "https://open.spotify.com/playlist/created")
        self.assertEqual(provider._client.created_playlists[0]["public"], False)
        self.assertEqual(provider._client.created_playlists[0]["name"], "Mamonia Test")
        self.assertEqual(provider._client.added_items, [("created", ["spotify:track:1", "spotify:track:2"])])
        self.assertEqual(provider._client.current_user_playlist_create_calls, 1)
        self.assertEqual(provider._client.user_playlist_create_calls, 0)

    def test_create_playlist_batches_uris_by_100(self) -> None:
        provider = _PlaylistSpotifyProvider()
        uris = [f"spotify:track:{idx}" for idx in range(205)]

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", uris)

        self.assertTrue(result.created)
        self.assertEqual([len(batch) for _, batch in provider._client.added_items], [100, 100, 5])

    def test_create_playlist_with_no_uris_avoids_api_calls(self) -> None:
        provider = _PlaylistSpotifyProvider()

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", [])

        self.assertFalse(result.created)
        self.assertEqual(result.reason, "no_uris")
        self.assertEqual(provider._client.current_user_playlist_create_calls, 0)
        self.assertEqual(provider._client.created_playlists, [])

    def test_create_playlist_reports_api_failure_reason(self) -> None:
        provider = _PlaylistSpotifyProvider(fail_create=RuntimeError("token lacks playlist-modify scope\nsecret detail"))

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", ["spotify:track:1"])

        self.assertFalse(result.created)
        self.assertEqual(result.reason, "token lacks playlist-modify scope")

    def test_permission_guidance_points_to_scope_specific_cache_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = SpotifyProvider(_settings(tmp), storage=None)

            read_guidance = provider.permission_guidance("reading playlist")
            write_guidance = provider.permission_guidance("creating playlist")

        self.assertIn("playlist-read access", read_guidance)
        self.assertIn(".spotipy_token_cache_playlist_read_private_playlist_read_collaborative", read_guidance)
        self.assertIn("playlist-modify access", write_guidance)
        self.assertIn(".spotipy_token_cache_playlist_modify_private", write_guidance)

    def test_issue_guidance_distinguishes_playlist_access_from_scope_failures(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = SpotifyProvider(_settings(tmp), storage=None)

            forbidden_issue = ProviderRateLimit(
                provider="Spotify",
                operation="reading playlist",
                is_permission_error=True,
                status_code=403,
                error_kind="forbidden_access",
                error_message="Private playlist is not accessible",
            )
            scope_issue = ProviderRateLimit(
                provider="Spotify",
                operation="creating playlist",
                is_permission_error=True,
                status_code=403,
                error_kind="insufficient_scope",
                error_message="Insufficient client scope",
            )

            forbidden_guidance = provider.issue_guidance(forbidden_issue)
            scope_guidance = provider.issue_guidance(scope_issue)

        self.assertIn("authorized Spotify account can actually view this playlist", forbidden_guidance)
        self.assertIn("playlist-modify access", scope_guidance)

    def test_issue_guidance_explains_market_errors(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = SpotifyProvider(_settings(tmp), storage=None)
            issue = ProviderRateLimit(
                provider="Spotify",
                operation="searching tracks",
                status_code=400,
                error_kind="content_unavailable",
                error_message="Invalid market code",
            )

            guidance = provider.issue_guidance(issue)

        self.assertIn("SPOTIFY_MARKET", guidance)
        self.assertIn("two-letter market code", guidance)

    def test_user_client_allows_explicit_loopback_http_redirect_uri(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            settings = _settings(tmp)
            settings.spotify_redirect_uri = "http://127.0.0.1:8888/callback"
            provider = SpotifyProvider(settings, storage=None)

            client = provider.user_client("playlist-read-private")

        self.assertIs(client, provider._user_clients["playlist-read-private"])

    def test_user_client_rejects_non_loopback_http_redirect_uri(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            settings = _settings(tmp)
            settings.spotify_redirect_uri = "http://example.com/callback"
            provider = SpotifyProvider(settings, storage=None)

            with self.assertRaisesRegex(RuntimeError, "http://127.0.0.1"):
                provider.user_client("playlist-read-private")

    def test_user_client_rejects_localhost_redirect_uri(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            settings = _settings(tmp)
            settings.spotify_redirect_uri = "http://localhost:8888/callback"
            provider = SpotifyProvider(settings, storage=None)

            with self.assertRaisesRegex(RuntimeError, "http://127.0.0.1"):
                provider.user_client("playlist-read-private")

    def test_operation_specs_keep_user_and_catalog_auth_separate(self) -> None:
        self.assertEqual(SPOTIFY_OPERATION_SPECS["read_playlist"].auth_mode, "pkce")
        self.assertEqual(SPOTIFY_OPERATION_SPECS["read_playlist"].scopes, "playlist-read-private playlist-read-collaborative")
        self.assertEqual(SPOTIFY_OPERATION_SPECS["create_playlist"].auth_mode, "pkce")
        self.assertEqual(SPOTIFY_OPERATION_SPECS["create_playlist"].scopes, "playlist-modify-private")
        self.assertEqual(SPOTIFY_OPERATION_SPECS["search_track"].auth_mode, "client_credentials")
        self.assertFalse(SPOTIFY_OPERATION_SPECS["search_track"].deprecated)
        self.assertEqual(SPOTIFY_OPERATION_SPECS["read_artist_details"].endpoint, "GET /artists/{id}")
        self.assertEqual(SPOTIFY_OPERATION_SPECS["read_track_details"].endpoint, "GET /tracks/{id}")
        self.assertFalse(any(spec.deprecated for spec in SPOTIFY_OPERATION_SPECS.values()))
        self.assertFalse(any(spec.endpoint == "GET /artists" for spec in SPOTIFY_OPERATION_SPECS.values()))
        self.assertFalse(any(spec.endpoint == "GET /tracks" for spec in SPOTIFY_OPERATION_SPECS.values()))

    def test_create_playlist_reports_rate_limit_reason(self) -> None:
        provider = _PlaylistSpotifyProvider(fail_create=_RateLimitError())

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", ["spotify:track:1"])

        self.assertFalse(result.created)
        self.assertEqual(result.reason, "rate_limited")
        self.assertEqual(len(provider.rate_limit_warnings), 1)
        self.assertEqual(provider.sleep_calls, [])

    def test_create_playlist_reports_auth_failure_reason(self) -> None:
        provider = _PlaylistSpotifyProvider(fail_create=_AuthError())

        result = provider.create_playlist("Mamonia Test", "Generated by Mamonia.", ["spotify:track:1"])

        self.assertFalse(result.created)
        self.assertIn("Spotify authentication failed while creating playlist.", result.reason)

    def test_fetch_playlist_tracks_retries_required_rate_limit_before_succeeding(self) -> None:
        provider = _RequiredRetrySpotifyProvider(_RetryPlaylistItemsClient())

        tracks = provider.fetch_playlist_tracks("playlist-id")

        self.assertEqual(len(tracks), 1)
        self.assertEqual(provider.sleep_calls, [3])


class _AlbumOnlySpotifyProvider(SpotifyProvider):
    def __init__(self) -> None:
        pass

    def search_album(self, artist_name: str, album_name: str):
        return {"id": "album-id", "uri": "spotify:album:album-id"}

    def album_tracks(self, album_id: str):
        return [
            {"id": "1", "name": "Opener", "track_number": 1, "uri": "uri:1", "artists": [{"name": "Artist"}]},
            {"id": "2", "name": "Second", "track_number": 2, "uri": "uri:2", "artists": [{"name": "Artist"}]},
            {"id": "3", "name": "Third", "track_number": 3, "uri": "uri:3", "artists": [{"name": "Artist"}]},
        ]

    def tracks_bulk(self, track_ids: list[str]):
        raise AssertionError("bulk track details should not be required")


class _SearchSpotifyProvider(SpotifyProvider):
    def __init__(self, responses: dict[str, list[dict]]) -> None:
        self._client = _FakeSpotifyClient(responses)
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings = []

    def client(self):
        return self._client


class _TrackSearchRepresentativeProvider(SpotifyProvider):
    def __init__(self, album_responses: dict[str, list[dict]], track_responses: dict[str, list[dict]]) -> None:
        self._client = _CombinedSearchSpotifyClient(album_responses, track_responses)
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings = []

    def client(self):
        return self._client


class _FakeSpotifyClient:
    def __init__(self, responses: dict[str, list[dict]]) -> None:
        self.responses = responses

    def search(self, q: str, type: str, limit: int, market: str | None = None, offset: int = 0):
        return {"albums": {"items": self.responses.get(q, [])}}


class _CombinedSearchSpotifyClient:
    def __init__(self, album_responses: dict[str, list[dict]], track_responses: dict[str, list[dict]]) -> None:
        self.album_responses = album_responses
        self.track_responses = track_responses
        self.search_calls = 0

    def search(self, q: str, type: str, limit: int, market: str | None = None, offset: int = 0):
        self.search_calls += 1
        if type == "track":
            return {"tracks": {"items": self.track_responses.get(q, [])}}
        return {"albums": {"items": self.album_responses.get(q, [])}}


class _CountingSpotifyClient:
    def __init__(
        self,
        artist_items: list[dict] | None = None,
        album_items: list[dict] | None = None,
        artists_by_id: dict[str, dict] | None = None,
        tracks_by_id: dict[str, dict] | None = None,
        track_search_items: dict[str, list[dict]] | None = None,
        artist_error: Exception | None = None,
        track_error: Exception | None = None,
        single_artist_error: Exception | None = None,
    ) -> None:
        self.artist_items = artist_items if artist_items is not None else []
        self.album_items = album_items if album_items is not None else []
        self.artists_by_id = artists_by_id or {}
        self.tracks_by_id = tracks_by_id or {}
        self.track_search_items = track_search_items or {}
        self.artist_error = artist_error
        self.track_error = track_error
        self.single_artist_error = single_artist_error
        self.search_calls = 0
        self.artist_calls = 0
        self.album_track_calls = 0
        self.track_calls = 0
        self.single_artist_calls = 0
        self.single_track_calls = 0
        self.markets: list[str | None] = []

    def search(self, q: str, type: str, limit: int, market: str | None = None, offset: int = 0):
        self.search_calls += 1
        self.markets.append(market)
        if type == "artist":
            return {"artists": {"items": self.artist_items}}
        if type == "track":
            return {"tracks": {"items": self.track_search_items.get(q, [])}}
        return {"albums": {"items": self.album_items}}

    def artists(self, ids: list[str]):
        self.artist_calls += 1
        if self.artist_error:
            raise self.artist_error
        return {"artists": [self.artists_by_id.get(artist_id) for artist_id in ids]}

    def album_tracks(self, album_id: str, limit: int, offset: int, market: str | None = None):
        self.album_track_calls += 1
        return {"items": [], "next": None}

    def tracks(self, ids: list[str], market: str | None = None):
        self.track_calls += 1
        if self.track_error:
            raise self.track_error
        return {"tracks": [self.tracks_by_id.get(track_id) for track_id in ids]}

    def artist(self, artist_id: str):
        self.single_artist_calls += 1
        if self.single_artist_error:
            raise self.single_artist_error
        return self.artists_by_id.get(artist_id)

    def track(self, track_id: str, market: str | None = None):
        self.single_track_calls += 1
        if self.track_error:
            raise self.track_error
        return self.tracks_by_id.get(track_id)


class _ConcurrentCountingSpotifyClient(_CountingSpotifyClient):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._active_lock = threading.Lock()
        self._active_artist_calls = 0
        self.max_active_artist_calls = 0

    def artist(self, artist_id: str):
        with self._active_lock:
            self._active_artist_calls += 1
            self.max_active_artist_calls = max(self.max_active_artist_calls, self._active_artist_calls)
        try:
            time.sleep(0.01)
            return super().artist(artist_id)
        finally:
            with self._active_lock:
                self._active_artist_calls -= 1


class _NoSleepSpotifyProvider(SpotifyProvider):
    def _sleep_for_retry(self, seconds: int) -> None:
        if not hasattr(self, "sleep_calls"):
            self.sleep_calls = []
        self.sleep_calls.append(seconds)


class _PlaylistSpotifyProvider(SpotifyProvider):
    available = True

    def __init__(self, fail_create: Exception | None = None) -> None:
        self._client = _PlaylistSpotifyClient(fail_create=fail_create)
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings = []
        self.api_calls = 0
        self.sleep_calls: list[int] = []

    def user_client(self, scopes: str):
        return self._client

    def _sleep_for_retry(self, seconds: int) -> None:
        self.sleep_calls.append(seconds)


class _RequiredRetrySpotifyProvider(SpotifyProvider):
    available = True

    def __init__(self, client) -> None:
        self._client = client
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings = []
        self.api_calls = 0
        self.sleep_calls: list[int] = []

    def user_client(self, scopes: str):
        return self._client

    def _sleep_for_retry(self, seconds: int) -> None:
        self.sleep_calls.append(seconds)


class _PlaylistSpotifyClient:
    def __init__(self, fail_create: Exception | None = None) -> None:
        self.fail_create = fail_create
        self.current_user_playlist_create_calls = 0
        self.user_playlist_create_calls = 0
        self.created_playlists: list[dict] = []
        self.added_items: list[tuple[str, list[str]]] = []

    def current_user_playlist_create(self, name: str, public: bool, description: str):
        self.current_user_playlist_create_calls += 1
        if self.fail_create:
            raise self.fail_create
        self.created_playlists.append(
            {"name": name, "public": public, "description": description}
        )
        return {"id": "created", "external_urls": {"spotify": "https://open.spotify.com/playlist/created"}}

    def user_playlist_create(self, user: str, name: str, public: bool, description: str):
        self.user_playlist_create_calls += 1
        raise AssertionError("Mamonia should use POST /me/playlists via current_user_playlist_create")

    def playlist_add_items(self, playlist_id: str, items: list[str]):
        self.added_items.append((playlist_id, list(items)))


class _RetryPlaylistItemsClient:
    def __init__(self) -> None:
        self.calls = 0

    def playlist_items(self, *args, **kwargs):
        self.calls += 1
        if self.calls == 1:
            raise _ShortRateLimitError()
        return {
            "items": [
                {
                    "item": {
                        "type": "track",
                        "name": "Recovered",
                        "id": "track-1",
                        "artists": [{"name": "Artist", "id": "artist-1"}],
                        "album": {"name": "Album", "id": "album-1"},
                    }
                }
            ],
            "next": None,
            "limit": 100,
        }


class _GetCapableSpotifyClient:
    def __init__(self) -> None:
        self.last_get_path: str | None = None
        self.last_get_kwargs: dict | None = None

    def _get(self, path: str, **kwargs):
        self.last_get_path = path
        self.last_get_kwargs = kwargs
        return {"tracks": [{"id": "track-1", "name": "Track"}]}


class _SearchGetCapableSpotifyClient(_GetCapableSpotifyClient):
    def _get(self, path: str, **kwargs):
        self.last_get_path = path
        self.last_get_kwargs = kwargs
        return {"artists": {"items": []}}


class _AlbumTracksGetCapableSpotifyClient(_GetCapableSpotifyClient):
    def _get(self, path: str, **kwargs):
        self.last_get_path = path
        self.last_get_kwargs = kwargs
        return {"items": [{"id": "track-1", "name": "Track"}], "next": None, "limit": kwargs.get("limit", 50)}


class _RateLimitError(RuntimeError):
    http_status = 429
    headers = {"Retry-After": "120"}


class _ShortRateLimitError(RuntimeError):
    http_status = 429
    headers = {"Retry-After": "3"}

    @property
    def response(self):
        class _Response:
            status_code = 429
            headers = {"Retry-After": "3"}

            @staticmethod
            def json():
                return {"error": {"status": 429, "message": "Rate limit exceeded"}}

        return _Response()


class _RetryAlbumTracksClient:
    def __init__(self) -> None:
        self.calls = 0

    def album_tracks(self, album_id: str, limit: int, offset: int, market: str | None = None):
        self.calls += 1
        if self.calls == 1:
            raise _ShortRateLimitError()
        return {"items": [{"id": "track-1", "name": "Recovered"}], "next": None, "limit": limit, "offset": offset}


class _AuthError(RuntimeError):
    http_status = 401

    @property
    def response(self):
        class _Response:
            status_code = 401
            headers = {}

            @staticmethod
            def json():
                return {"error": {"status": 401, "message": "The access token expired"}}

        return _Response()


class _ForbiddenError(RuntimeError):
    http_status = 403

    def __init__(self, message: str = "Insufficient client scope") -> None:
        super().__init__(message)

    @property
    def response(self):
        class _Response:
            status_code = 403

            @staticmethod
            def json():
                return {"error": {"status": 403, "message": "Insufficient client scope"}}

        return _Response()


def _settings(tmp: str) -> Settings:
    return Settings(
        data_dir=Path(tmp) / "home",
        db_path=Path(tmp) / "home" / "mamonia.sqlite",
        spotify_client_id="spotify-id",
        spotify_client_secret="spotify-secret",
        spotify_market="PL",
        mb_contact="tester@example.com",
    )


class SpotifyUserPlaylistsTests(unittest.TestCase):
    def test_fetch_user_playlists_returns_list(self) -> None:
        provider = _MockSpotifyProvider()
        playlists = provider.fetch_user_playlists()
        self.assertEqual(len(playlists), 2)
        self.assertEqual(playlists[0].id, "playlist-1")
        self.assertEqual(playlists[0].name, "My Playlist")
        self.assertEqual(playlists[0].tracks, 10)
        self.assertEqual(playlists[1].id, "playlist-2")
        self.assertEqual(playlists[1].name, "Another Playlist")
        self.assertEqual(playlists[1].tracks, 5)

    def test_fetch_user_playlists_empty(self) -> None:
        provider = _MockSpotifyProvider(empty_playlists=True)
        playlists = provider.fetch_user_playlists()
        self.assertEqual(len(playlists), 0)

    def test_fetch_user_playlists_pagination(self) -> None:
        provider = _MockSpotifyProvider(paginated=True)
        playlists = provider.fetch_user_playlists()
        self.assertEqual(len(playlists), 100)
        self.assertEqual(provider._client.current_user_playlists_calls, 2)

    def test_fetch_user_playlists_uses_track_count_fallback(self) -> None:
        """Test that track_count is used when tracks is not a dict with total."""
        from mamonia.config import Settings
        from pathlib import Path

        settings = Settings(
            data_dir=Path("/tmp"),
            db_path=Path("/tmp") / "mamonia.sqlite",
            spotify_client_id="test-id",
            spotify_client_secret="test-secret",
        )

        class MockSpotify:
            def current_user_playlists(self, limit: int, offset: int):
                return {
                    "items": [
                        {"id": "playlist-1", "name": "My Playlist", "track_count": 15},
                    ],
                    "next": None,
                    "limit": 50,
                    "offset": 0,
                }

        class TestProvider(SpotifyProvider):
            def user_client(self, scopes: str):
                return MockSpotify()

        provider = TestProvider(settings)
        playlists = provider.fetch_user_playlists()
        self.assertEqual(len(playlists), 1)
        self.assertEqual(playlists[0].id, "playlist-1")
        self.assertEqual(playlists[0].name, "My Playlist")
        self.assertEqual(playlists[0].tracks, 15)

    def test_provider_issue_maps_oauth_invalid_client_without_http_status(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = SpotifyProvider(_settings(tmp), storage=None)
            issue = provider._provider_issue("fetching user playlists", _OAuthInvalidClientError("oauth failed"))

        self.assertIsNotNone(issue)
        assert issue is not None
        self.assertEqual(issue.error_kind, "auth_failed")
        self.assertEqual(issue.action, "RECONNECT_SPOTIFY")

    def test_fetch_user_playlists_invalid_client_recovers_once_with_cache_reset(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = _RecoveringUserPlaylistsProvider(tmp)
            playlists = provider.fetch_user_playlists()

        self.assertEqual([playlist.id for playlist in playlists], ["playlist-ok"])
        self.assertEqual(provider.user_client_calls, 2)
        self.assertFalse(provider.cache_path.exists())

    def test_fetch_user_playlists_invalid_client_second_failure_raises_provider_issue(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = _FailingRecoveryUserPlaylistsProvider(tmp)
            with self.assertRaises(ProviderRateLimit) as raised:
                provider.fetch_user_playlists()

        self.assertEqual(raised.exception.error_kind, "auth_failed")
        self.assertEqual(provider.user_client_calls, 2)

    def test_issue_guidance_for_playlist_auth_failed_points_to_cache_refresh(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            provider = SpotifyProvider(_settings(tmp), storage=None)
            issue = ProviderRateLimit(
                provider="Spotify",
                operation="fetching user playlists",
                status_code=401,
                error_kind="auth_failed",
                error_message="invalid_client",
            )

            guidance = provider.issue_guidance(issue)

        self.assertIn("authorization has expired or is invalid", guidance)
        self.assertIn(".spotipy_token_cache_playlist_read_private_playlist_read_collaborative", guidance)


class _MockSpotifyProvider(SpotifyProvider):
    def __init__(self, empty_playlists: bool = False, paginated: bool = False):
        from mamonia.config import Settings
        from pathlib import Path
        settings = Settings(
            data_dir=Path("/tmp"),
            db_path=Path("/tmp") / "mamonia.sqlite",
            spotify_client_id="test-id",
            spotify_client_secret="test-secret",
        )
        super().__init__(settings)
        self._empty_playlists = empty_playlists
        self._paginated = paginated
        self._client = None  # Initialize _client first

    def user_client(self, scopes: str):
        empty_playlists = self._empty_playlists
        paginated = self._paginated

        class MockSpotify:
            def __init__(self) -> None:
                self.current_user_playlists_calls = 0

            def current_user_playlists(self, limit: int, offset: int):
                self.current_user_playlists_calls += 1
                if empty_playlists:
                    return {"items": [], "next": None, "limit": limit, "offset": offset}
                if paginated and offset == 0:
                    # First page: 50 items, next exists
                    return {
                        "items": [{"id": f"playlist-{i}", "name": f"Playlist {i}", "tracks": {"total": i * 2}} for i in range(50)],
                        "next": "https://api.spotify.com/v1/me/playlists?offset=50",
                        "limit": 50,
                        "offset": 0,
                    }
                if paginated and offset == 50:
                    # Second page: 50 items, no next
                    return {
                        "items": [{"id": f"playlist-{i}", "name": f"Playlist {i}", "tracks": {"total": i * 2}} for i in range(50, 100)],
                        "next": None,
                        "limit": 50,
                        "offset": 50,
                    }
                # Single page with 2 items
                return {
                    "items": [
                        {"id": "playlist-1", "name": "My Playlist", "tracks": {"total": 10}},
                        {"id": "playlist-2", "name": "Another Playlist", "tracks": {"total": 5}},
                    ],
                    "next": None,
                    "limit": 50,
                    "offset": 0,
                }
        self._client = MockSpotify()
        return self._client


class _OAuthInvalidClientError(Exception):
    error = "invalid_client"
    error_description = "Invalid client"


class _RecoveringPlaylistClient:
    def __init__(self, *, fail_first: bool = True, always_fail: bool = False) -> None:
        self._fail_first = fail_first
        self._always_fail = always_fail
        self._calls = 0

    def current_user_playlists(self, limit: int, offset: int):
        self._calls += 1
        if self._always_fail or (self._fail_first and self._calls == 1):
            raise _OAuthInvalidClientError("oauth failed")
        return {
            "items": [{"id": "playlist-ok", "name": "Recovered", "tracks": {"total": 3}}],
            "next": None,
            "limit": limit,
            "offset": offset,
        }


class _RecoveringUserPlaylistsProvider(SpotifyProvider):
    def __init__(self, tmp: str) -> None:
        super().__init__(_settings(tmp), storage=None)
        self.user_client_calls = 0
        self.cache_path = self._scope_cache_path(self.operation_spec("fetch_user_playlists").scopes)
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text("stale", encoding="utf-8")
        self._client = _RecoveringPlaylistClient()

    def user_client(self, scopes: str):
        self.user_client_calls += 1
        if self.user_client_calls == 1:
            return self._client
        return _RecoveringPlaylistClient(fail_first=False, always_fail=False)


class _FailingRecoveryUserPlaylistsProvider(_RecoveringUserPlaylistsProvider):
    def user_client(self, scopes: str):
        self.user_client_calls += 1
        return _RecoveringPlaylistClient(always_fail=True)


class BackfillReleaseTracksTests(unittest.TestCase):
    """Tests for the album-first matching optimization in backfill_release_tracks."""

    def test_backfill_release_tracks_uses_album_first(self) -> None:
        """Test that backfill_release_tracks uses album-first matching when album is found."""
        from mamonia.models import ReleaseTrack
        from pathlib import Path
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmp:
            settings = Settings(
                data_dir=Path(tmp),
                db_path=Path(tmp) / "mamonia.sqlite",
                spotify_client_id="test-id",
                spotify_client_secret="test-secret",
            )
            provider = SpotifyProvider(settings)

            # Mock search_album to return an album
            def mock_search_album(artist: str, album: str, allow_album_only: bool = True):
                return {
                    "id": "album-123",
                    "name": "Test Album",
                    "artists": [{"id": "artist-1", "name": "Test Artist"}],
                }
            provider.search_album = mock_search_album  # type: ignore[method-assign]

            # Mock album_tracks to return tracklist
            def mock_album_tracks(album_id: str):
                return [
                    {"id": "track-1", "name": "Song One", "track_number": 1, "popularity": 80},
                    {"id": "track-2", "name": "Song Two", "track_number": 2, "popularity": 70},
                    {"id": "track-3", "name": "Song Three", "track_number": 3, "popularity": 60},
                ]
            provider.album_tracks = mock_album_tracks  # type: ignore[method-assign]

            # Create release tracks
            tracks = [
                ReleaseTrack(title="Song One", artists="Test Artist", track_number=1),
                ReleaseTrack(title="Song Two", artists="Test Artist", track_number=2),
                ReleaseTrack(title="Song Three", artists="Test Artist", track_number=3),
            ]

            # Call backfill_release_tracks
            result = provider.backfill_release_tracks("Test Album", tracks, artist_name="Test Artist")

            # Verify all tracks got Spotify IDs from album tracklist
            self.assertEqual(len(result), 3)
            self.assertEqual(result[0].spotify_track_id, "track-1")
            self.assertEqual(result[1].spotify_track_id, "track-2")
            self.assertEqual(result[2].spotify_track_id, "track-3")
            self.assertEqual(result[0].resolution_source, "spotify_album_tracklist")
            self.assertEqual(result[1].resolution_source, "spotify_album_tracklist")
            self.assertEqual(result[2].resolution_source, "spotify_album_tracklist")

    def test_backfill_release_tracks_falls_back_to_track_search(self) -> None:
        """Test that backfill_release_tracks falls back to track-by-track search when album not found."""
        from mamonia.models import ReleaseTrack
        from pathlib import Path
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmp:
            settings = Settings(
                data_dir=Path(tmp),
                db_path=Path(tmp) / "mamonia.sqlite",
                spotify_client_id="test-id",
                spotify_client_secret="test-secret",
            )
            provider = SpotifyProvider(settings)

            # Mock search_album to return None (album not found)
            def mock_search_album(artist: str, album: str, allow_album_only: bool = True):
                return None
            provider.search_album = mock_search_album  # type: ignore[method-assign]

            # Mock _search_track_match to return a match
            def mock_search_track_match(*, cache_key: str, query: str, track, album_name: str, primary_artist: str, source: str, note: str):
                return {
                    "id": "track-123",
                    "uri": "spotify:track:123",
                    "name": track.title,
                    "album": {"id": "album-1", "name": album_name},
                    "artists": [{"name": primary_artist}],
                    "external_ids": {"isrc": "US123456789"},
                    "popularity": 50,
                    "resolution_source": source,
                    "resolution_note": note,
                }
            provider._search_track_match = mock_search_track_match  # type: ignore[method-assign]

            # Create release tracks
            tracks = [
                ReleaseTrack(title="Song One", artists="Test Artist", track_number=1, isrc="US123456789"),
            ]

            # Call backfill_release_tracks
            result = provider.backfill_release_tracks("Test Album", tracks, artist_name="Test Artist")

            # Verify track got matched via fallback search
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].spotify_track_id, "track-123")

    def test_backfill_release_tracks_caches_album_match(self) -> None:
        """Test that backfill_release_tracks caches the album-track match result."""
        from mamonia.models import ReleaseTrack
        from pathlib import Path
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmp:
            settings = Settings(
                data_dir=Path(tmp),
                db_path=Path(tmp) / "mamonia.sqlite",
                spotify_client_id="test-id",
                spotify_client_secret="test-secret",
            )
            provider = SpotifyProvider(settings)

            # Mock search_album to return an album
            def mock_search_album(artist: str, album: str, allow_album_only: bool = True):
                return {"id": "album-123", "name": "Test Album", "artists": [{"id": "artist-1", "name": "Test Artist"}]}
            provider.search_album = mock_search_album  # type: ignore[method-assign]

            # Mock album_tracks to return tracklist
            def mock_album_tracks(album_id: str):
                return [
                    {"id": "track-1", "name": "Song One", "track_number": 1, "popularity": 80},
                ]
            provider.album_tracks = mock_album_tracks  # type: ignore[method-assign]

            # Create release tracks
            tracks = [ReleaseTrack(title="Song One", artists="Test Artist", track_number=1)]

            # First call - should search album and fetch tracklist
            result1 = provider.backfill_release_tracks("Test Album", tracks, artist_name="Test Artist")
            self.assertEqual(result1[0].spotify_track_id, "track-1")

            # Second call with same album - should use cached match
            tracks2 = [ReleaseTrack(title="Song One", artists="Test Artist", track_number=1)]
            result2 = provider.backfill_release_tracks("Test Album", tracks2, artist_name="Test Artist")
            self.assertEqual(result2[0].spotify_track_id, "track-1")

    def test_backfill_release_tracks_handles_unmatched_tracks(self) -> None:
        """Test that backfill_release_tracks handles tracks that don't match the album."""
        from mamonia.models import ReleaseTrack
        from pathlib import Path
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as tmp:
            settings = Settings(
                data_dir=Path(tmp),
                db_path=Path(tmp) / "mamonia.sqlite",
                spotify_client_id="test-id",
                spotify_client_secret="test-secret",
            )
            provider = SpotifyProvider(settings)

            # Mock search_album to return an album
            def mock_search_album(artist: str, album: str, allow_album_only: bool = True):
                return {"id": "album-123", "name": "Test Album", "artists": [{"id": "artist-1", "name": "Test Artist"}]}
            provider.search_album = mock_search_album  # type: ignore[method-assign]

            # Mock album_tracks to return tracklist with only one track
            def mock_album_tracks(album_id: str):
                return [
                    {"id": "track-1", "name": "Song One", "track_number": 1, "popularity": 80},
                ]
            provider.album_tracks = mock_album_tracks  # type: ignore[method-assign]

            # Mock _search_track_match for unmatched track
            def mock_search_track_match(*, cache_key: str, query: str, track, album_name: str, primary_artist: str, source: str, note: str):
                return {
                    "id": "unmatched-track",
                    "uri": "spotify:track:unmatched",
                    "name": track.title,
                    "album": {"id": "album-1", "name": album_name},
                    "artists": [{"name": primary_artist}],
                    "external_ids": {"isrc": "US999999999"},
                    "popularity": 30,
                    "resolution_source": source,
                    "resolution_note": note,
                }
            provider._search_track_match = mock_search_track_match  # type: ignore[method-assign]

            # Create release tracks - one matches album, one doesn't
            tracks = [
                ReleaseTrack(title="Song One", artists="Test Artist", track_number=1),
                ReleaseTrack(title="Song Unknown", artists="Test Artist", track_number=99),
            ]

            # Call backfill_release_tracks
            result = provider.backfill_release_tracks("Test Album", tracks, artist_name="Test Artist")

            # Verify first track matched from album, second fell back to search
            self.assertEqual(len(result), 2)
            self.assertEqual(result[0].spotify_track_id, "track-1")  # From album
            self.assertEqual(result[1].spotify_track_id, "unmatched-track")  # From fallback search


if __name__ == "__main__":
    unittest.main()
