from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from mamonia.i18n import (
    get_guided_language,
    get_language_from_env,
    get_saved_language_preference,
    get_translator,
    load_locale,
    save_language_preference,
)


# ---------------------------------------------------------------------------
# load_locale — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("code,name", [
    ("en", "English"),
    ("pl", "Polski"),
])
def test_load_locale(code: str, name: str) -> None:
    locale = load_locale(code)
    assert locale["language"]["code"] == code
    assert locale["language"]["name"] == name
    for section in ("menu", "prompt", "status", "error"):
        assert section in locale


def test_load_invalid_locale_raises_error() -> None:
    from mamonia.i18n import I18nError
    with pytest.raises(I18nError):
        load_locale("invalid")


# ---------------------------------------------------------------------------
# get_translator — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("lang,key,expected", [
    ("en", "menu.root.title", "mamonia"),
    ("en", "menu.root.discover", "Discover new music"),
    ("en", "menu.root.exit", "Exit"),
    ("pl", "menu.root.title", "mamonia"),
    ("pl", "menu.root.discover", "Odkrywaj nową muzykę"),
    ("pl", "menu.root.exit", "Wyjdź"),
])
def test_translator(lang: str, key: str, expected: str) -> None:
    t = get_translator(lang)
    assert t(key) == expected


def test_translator_fallback_to_english_for_missing_key() -> None:
    t = get_translator("pl")
    assert t("nonexistent.key") == "nonexistent.key"


def test_translator_fallback_to_english_for_invalid_language() -> None:
    t = get_translator("invalid")
    assert t("menu.root.title") == "mamonia"


# ---------------------------------------------------------------------------
# get_language_from_env
# ---------------------------------------------------------------------------

def test_get_language_from_env() -> None:
    import os

    if "MAMONIA_LANG" in os.environ:
        del os.environ["MAMONIA_LANG"]
    assert get_language_from_env() is None

    os.environ["MAMONIA_LANG"] = "pl"
    assert get_language_from_env() == "pl"
    del os.environ["MAMONIA_LANG"]


# ---------------------------------------------------------------------------
# save / load language preference
# ---------------------------------------------------------------------------

def test_save_and_load_language_preference() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        home_dir = Path(tmp)
        pref_file = home_dir / "preferences.json"

        assert get_saved_language_preference(home_dir) is None

        save_language_preference(home_dir, "pl")
        assert pref_file.exists()
        assert get_saved_language_preference(home_dir) == "pl"

        save_language_preference(home_dir, "en")
        assert get_saved_language_preference(home_dir) == "en"


# ---------------------------------------------------------------------------
# get_guided_language
# ---------------------------------------------------------------------------

def test_get_guided_language_from_env() -> None:
    import os

    with tempfile.TemporaryDirectory() as tmp:
        home_dir = Path(tmp)
        os.environ["MAMONIA_LANG"] = "pl"
        assert get_guided_language(home_dir, from_cli=False) == "pl"
        del os.environ["MAMONIA_LANG"]


def test_get_guided_language_from_saved_preference() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        home_dir = Path(tmp)
        save_language_preference(home_dir, "pl")
        assert get_guided_language(home_dir, from_cli=False) == "pl"


def test_get_guided_language_defaults_to_english() -> None:
    import os

    with tempfile.TemporaryDirectory() as tmp:
        home_dir = Path(tmp)
        if "MAMONIA_LANG" in os.environ:
            del os.environ["MAMONIA_LANG"]
        assert get_guided_language(home_dir, from_cli=False) == "en"


def test_get_guided_language_from_cli_overrides_all() -> None:
    import os

    with tempfile.TemporaryDirectory() as tmp:
        home_dir = Path(tmp)
        save_language_preference(home_dir, "pl")
        os.environ["MAMONIA_LANG"] = "en"
        assert get_guided_language(home_dir, from_cli=True) == "en"
        del os.environ["MAMONIA_LANG"]
