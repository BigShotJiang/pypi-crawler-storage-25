from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from mamonia.models import InputTrack
from mamonia.models import ReleaseRecommendation, ReleaseTrack
from mamonia.storage import Storage
from mamonia.workflow import (
    DiscoverOptions,
    WorkflowAbort,
    _backfill_tidal_track_ids,
    _drop_heard_recommendations,
    _load_playlist_tracks,
    _mark_input_releases_as_heard,
    _resolve_locale,
    _recover_empty_recommendation_tracks,
    _spotify_profile_artist_metadata,
    emit_collapsible_availability_notice,
    prompt_expand_availability_rows,
    shuffle_recommendations,
)


class WorkflowTests(unittest.TestCase):
    def test_resolve_locale_prefers_explicit_option(self) -> None:
        with patch.dict("os.environ", {"MAMONIA_LANG": "en", "LC_ALL": "pl_PL.UTF-8"}, clear=False):
            self.assertEqual(_resolve_locale(DiscoverOptions(playlist="x", language="pl")), "pl")

    def test_resolve_locale_uses_mamonia_lang_before_system_locale(self) -> None:
        with patch.dict("os.environ", {"MAMONIA_LANG": "pl", "LC_ALL": "en_US.UTF-8", "LANG": "en_US.UTF-8"}, clear=False):
            self.assertEqual(_resolve_locale(DiscoverOptions(playlist="x")), "pl")

    def test_resolve_locale_uses_system_locale_when_mamonia_lang_missing(self) -> None:
        with patch.dict("os.environ", {"LC_ALL": "pl_PL.UTF-8", "LANG": "en_US.UTF-8"}, clear=True):
            self.assertEqual(_resolve_locale(DiscoverOptions(playlist="x")), "pl")

    def test_resolve_locale_falls_back_to_default_for_unsupported_locales(self) -> None:
        with patch.dict("os.environ", {"LC_ALL": "de_DE.UTF-8", "LANG": "fr_FR.UTF-8"}, clear=True):
            self.assertEqual(_resolve_locale(DiscoverOptions(playlist="x")), "en")

    def test_prompt_expand_availability_rows_shows_details_on_e(self) -> None:
        rows = [
            {"message": "Track A lacks a Spotify URI."},
            {"message": "Track B lacks both Spotify and Tidal IDs."},
        ]
        lines: list[str] = []

        with patch("mamonia.workflow.sys.stdin.isatty", return_value=True), patch("mamonia.workflow._read_single_key", return_value="e"):
            expanded = prompt_expand_availability_rows(rows, lines.append)

        self.assertTrue(expanded)
        self.assertEqual(lines[0], "If you want to see the details, press E.")
        self.assertIn("Track A lacks a Spotify URI.", lines)
        self.assertIn("Track B lacks both Spotify and Tidal IDs.", lines)

    def test_emit_collapsible_availability_notice_hides_details_by_default(self) -> None:
        rec = ReleaseRecommendation(
            artist="Fresh Artist",
            title="Fresh Album",
            release_date="2026-04-23",
            tracks=[ReleaseTrack(title="Missing Everywhere", artists="Fresh Artist")],
        )
        lines: list[str] = []

        with patch("mamonia.workflow.sys.stdin.isatty", return_value=True), patch("mamonia.workflow._read_single_key", return_value=""):
            expanded = emit_collapsible_availability_notice([rec], lines.append)

        self.assertFalse(expanded)
        self.assertIn("Please note:", lines)
        self.assertIn("Review these songs:", lines)
        self.assertIn("If you want to see the details, press E.", lines)
        self.assertFalse(any("Track Missing Everywhere by Fresh Artist" in line for line in lines))

    def test_empty_track_recovery_adds_release_level_rescue_track(self) -> None:
        rec = ReleaseRecommendation(
            artist="Archive",
            title="City Walls",
            release_date="2026-01-13",
            tracks=[],
        )
        spotify = _RecoverySpotify()

        _recover_empty_recommendation_tracks(
            [rec],
            spotify=spotify,
            tidal=None,
            musicbrainz=None,
            max_tracks=3,
            seed_track_keys=set(),
            discovery_months=6,
            discovery_today=None,
            attempts_state={},
        )

        self.assertEqual(len(rec.tracks), 1)
        self.assertEqual(rec.tracks[0].spotify_track_id, "sp-recovered")
        self.assertIn("empty-track-recovery-attempted", rec.rationale)

    def test_empty_track_recovery_stops_after_three_attempts(self) -> None:
        rec = ReleaseRecommendation(artist="Archive", title="Patterns", release_date="2026-02-25", tracks=[])
        attempts_state: dict[str, int] = {}
        for _ in range(4):
            _recover_empty_recommendation_tracks(
                [rec],
                spotify=None,
                tidal=None,
                musicbrainz=None,
                max_tracks=3,
                seed_track_keys=set(),
                discovery_months=6,
                discovery_today=None,
                attempts_state=attempts_state,
            )
        self.assertIn("recovery-result:max_attempts_exhausted", rec.rationale)

    def test_drop_heard_recommendations_removes_heard_and_backfills(self) -> None:
        unheard = ReleaseRecommendation(artist="Artist A", title="New Album", tracks=[])
        heard = ReleaseRecommendation(artist="Artist B", title="Old Album", tracks=[])
        storage = MagicMock()
        storage.is_heard_recommendation.side_effect = lambda rec: rec.title == "Old Album"
        storage.backfill_heard_recommendation = MagicMock()

        kept, dropped = _drop_heard_recommendations(storage, [unheard, heard])

        self.assertEqual(dropped, 1)
        self.assertEqual(len(kept), 1)
        self.assertEqual(kept[0].title, "New Album")
        storage.backfill_heard_recommendation.assert_called_once_with(heard)

    def test_load_playlist_tracks_uses_full_tidal_result_count(self) -> None:
        spotify = MagicMock()
        spotify.available = False
        tidal = MagicMock()
        tidal.available = True
        tidal.fetch_playlist_tracks.return_value = [
            InputTrack(artist="Artist", track=f"Track {idx}") for idx in range(120)
        ]

        with patch("mamonia.workflow.looks_like_spotify_playlist", return_value=False), patch(
            "mamonia.workflow.looks_like_tidal_playlist", return_value=True
        ):
            tracks = _load_playlist_tracks("tidal-playlist-id", spotify, tidal)

        self.assertEqual(len(tracks), 120)
        tidal.fetch_playlist_tracks.assert_called_once_with("tidal-playlist-id")

    def test_storage_is_heard_recommendation(self) -> None:
        """Test that storage correctly identifies heard recommendations."""
        tracks = [
            InputTrack(artist="Artist", track="Song", album="Album", spotify_album_id="sp-album-123"),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            
            # Add a release to heard list
            storage.add_heard(
                artist="Artist",
                title="Album",
                release_date="2026-01-01",
                spotify_album_id="sp-album-123",
            )
            
            # Create a mock recommendation for the same release
            from mamonia.models import ReleaseRecommendation, ReleaseTrack
            
            rec = ReleaseRecommendation(
                artist="Artist",
                title="Album",
                release_date="2026-01-01",
                release_type="album",
                spotify_album_id="sp-album-123",
                source_release_keys=set(),
                source_track_keys=set(),
                candidate_score=0.0,
                discovery_score=0.0,
                tracks=[],
            )
            
            # Should be identified as already heard
            self.assertTrue(storage.is_heard_recommendation(rec))
            storage.close()

    def test_storage_is_heard_recommendation_excludes_unheard(self) -> None:
        """Test that storage correctly identifies non-heard recommendations."""
        tracks = [
            InputTrack(artist="Artist", track="Song", album="Album", spotify_album_id="sp-album-123"),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            
            # Create a mock recommendation for a release NOT in heard list
            from mamonia.models import ReleaseRecommendation, ReleaseTrack
            
            rec = ReleaseRecommendation(
                artist="Artist",
                title="Album",
                release_date="2026-01-01",
                release_type="album",
                spotify_album_id="sp-album-999",  # Different ID
                source_release_keys=set(),
                source_track_keys=set(),
                candidate_score=0.0,
                discovery_score=0.0,
                tracks=[],
            )
            
            # Should NOT be identified as heard
            self.assertFalse(storage.is_heard_recommendation(rec))
            storage.close()

    def test_mark_input_releases_as_heard_does_not_fetch_album_details(self) -> None:
        tracks = [
            InputTrack(artist="Artist", track="Song", album="Album", spotify_album_id="sp-album-123"),
            InputTrack(artist="Artist", track="Other Song", album="Album", spotify_album_id="sp-album-123"),
        ]
        spotify = MagicMock()
        musicbrainz = MagicMock()
        tidal = MagicMock()

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")

            marked = _mark_input_releases_as_heard(
                storage,
                tracks,
                spotify=spotify,
                musicbrainz=musicbrainz,
                tidal=tidal,
            )
            heard = storage.list_heard()
            storage.close()

        self.assertEqual(marked, 1)
        self.assertEqual(heard[0]["spotify_album_id"], "sp-album-123")
        spotify.assert_not_called()
        musicbrainz.assert_not_called()
        tidal.assert_not_called()

    def test_tidal_backfill_reuses_cached_success(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Song", artists="Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_track_enrichment(
                provider="tidal",
                artist="Artist",
                title="Song",
                album="Album",
                tidal_track_id="td-cached",
                tidal_album_id="td-album",
                payload={"tidal_track_id": "td-cached", "tidal_album_id": "td-album"},
            )
            tidal = _CountingTidal()

            resolved = _backfill_tidal_track_ids([rec], tidal, storage=storage)
            storage.close()

        self.assertEqual(resolved, 1)
        self.assertEqual(rec.tracks[0].tidal_track_id, "td-cached")
        self.assertEqual(rec.tracks[0].tidal_album_id, "td-album")
        self.assertEqual(tidal.calls, 0)

    def test_tidal_backfill_caches_success_and_miss(self) -> None:
        matched = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Matched", artists="Artist")],
        )
        missed = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Missing", artists="Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            tidal = _CountingTidal({"Matched": _TidalMatch(track_id="td-new", album_id="td-album", isrc="ISRC1")})

            resolved = _backfill_tidal_track_ids([matched, missed], tidal, storage=storage)
            success = storage.get_track_enrichment(provider="tidal", tidal_track_id="td-new")
            miss = storage.get_track_enrichment(provider="tidal", artist="Artist", title="Missing")
            storage.close()

        self.assertEqual(resolved, 1)
        self.assertEqual(matched.tracks[0].tidal_track_id, "td-new")
        self.assertEqual(matched.tracks[0].isrc, "ISRC1")
        self.assertEqual(matched.tracks[0].isrc_source, "tidal")
        self.assertEqual(success["status"], "success")
        self.assertEqual(miss["status"], "miss")
        self.assertEqual(miss["payload"]["lookup_version"], "tidal-track-lookup-v2-openapi")
        self.assertEqual(tidal.calls, 3)

    def test_tidal_backfill_persists_match_stage(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Matched", artists="Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            tidal = _CountingTidal({"Matched": _TidalMatch(track_id="td-new", album_id="td-album", stage="isrc_in_window")})

            resolved = _backfill_tidal_track_ids([rec], tidal, storage=storage)
            success = storage.get_track_enrichment(provider="tidal", tidal_track_id="td-new")
            storage.close()

        self.assertEqual(resolved, 1)
        self.assertEqual(success["payload"]["match_stage"], "isrc_in_window")

    def test_tidal_backfill_ignores_legacy_cached_miss(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Previously Missing", artists="Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_track_enrichment(
                provider="tidal",
                artist="Artist",
                title="Previously Missing",
                album="Album",
                status="miss",
                payload={"source": "recommendation_lookup"},
                error="not found",
            )
            tidal = _CountingTidal({"Previously Missing": _TidalMatch(track_id="td-recovered")})

            resolved = _backfill_tidal_track_ids([rec], tidal, storage=storage)
            storage.close()

        self.assertEqual(resolved, 1)
        self.assertEqual(rec.tracks[0].tidal_track_id, "td-recovered")
        self.assertEqual(tidal.calls, 1)

    def test_tidal_backfill_does_not_cache_provider_errors_as_misses(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="Lookup Error", artists="Artist")],
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            tidal = _ErroringTidal()

            resolved = _backfill_tidal_track_ids([rec], tidal, storage=storage)
            miss = storage.get_track_enrichment(provider="tidal", artist="Artist", title="Lookup Error")
            storage.close()

        self.assertEqual(resolved, 0)
        self.assertIsNone(miss)

    def test_tidal_backfill_target_count_matches_unresolved_tracks(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[
                ReleaseTrack(title="Already Resolved", artists="Artist", tidal_track_id="td-1"),
                ReleaseTrack(title="Needs Backfill", artists="Artist"),
            ],
        )
        tidal = _CountingTidal({"Needs Backfill": _TidalMatch(track_id="td-2")})
        resolved = _backfill_tidal_track_ids([rec], tidal, storage=None)

        self.assertEqual(resolved, 1)
        self.assertEqual(tidal.calls, 1)

    def test_tidal_backfill_retries_without_album_when_first_lookup_misses(self) -> None:
        rec = ReleaseRecommendation(
            artist="HAVVK",
            title="On Time",
            tracks=[ReleaseTrack(title="Happening Again", artists="HAVVK")],
        )
        tidal = _AlbumSensitiveTidal(track_id="td-havvk")

        resolved = _backfill_tidal_track_ids([rec], tidal, storage=None)

        self.assertEqual(resolved, 1)
        self.assertEqual(rec.tracks[0].tidal_track_id, "td-havvk")
        self.assertEqual(tidal.calls, 2)
        self.assertEqual(tidal.albums_seen, ["On Time", None])

    def test_tidal_backfill_uses_release_album_tracklist_when_lookup_misses(self) -> None:
        rec = ReleaseRecommendation(
            artist="HAVVK",
            title="On Time",
            tidal_album_id="509870858",
            tracks=[ReleaseTrack(title="Boots on the Ground", artists="HAVVK")],
        )
        tidal = _AlbumTracklistFallbackTidal(track_id="509870859", artist_name="HAVVK", track_name="Boots on the Ground")

        resolved = _backfill_tidal_track_ids([rec], tidal, storage=None)

        self.assertEqual(resolved, 1)
        self.assertEqual(rec.tracks[0].tidal_track_id, "509870859")
        self.assertEqual(rec.tracks[0].tidal_album_id, "509870858")
        self.assertEqual(tidal.fetch_album_calls, ["509870858"])

    def test_spotify_profile_backfill_rollout_zero_skips_backfill(self) -> None:
        tracks = [InputTrack(artist="A", track="T", spotify_track_id="sp-track-1")]
        spotify = MagicMock()
        spotify.artist_metadata_from_tracks.return_value = {}

        with patch("mamonia.workflow.SPOTIFY_PROFILE_TRACK_BACKFILL_ROLLOUT_PERCENT", 0):
            _spotify_profile_artist_metadata(spotify, tracks)

        spotify.backfill_track_enrichment.assert_not_called()
        spotify.artist_metadata_from_tracks.assert_called_once()

    def test_spotify_profile_backfill_rollout_hundred_calls_backfill(self) -> None:
        tracks = [InputTrack(artist="A", track="T", spotify_track_id="sp-track-1")]
        spotify = MagicMock()
        spotify.artist_metadata_from_tracks.return_value = {}

        with patch("mamonia.workflow.SPOTIFY_PROFILE_TRACK_BACKFILL_ROLLOUT_PERCENT", 100):
            _spotify_profile_artist_metadata(spotify, tracks)

        spotify.backfill_track_enrichment.assert_called_once_with(tracks, limit=75)
        spotify.artist_metadata_from_tracks.assert_called_once()


class WorkflowV2PipelineTests(unittest.TestCase):
    """Tests for v2 pipeline integration in workflow."""

    def test_run_discover_completes_without_legacy_pipeline_toggle(self) -> None:
        """Test that run_discover completes without relying on a pipeline toggle."""
        from mamonia.workflow import DiscoverOptions, run_discover
        from mamonia.storage import Storage
        from pathlib import Path
        import tempfile
        import os

        tracks = [InputTrack(artist="Test Artist", track="Test Track", album="Test Album")]

        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "mamonia.sqlite"
            home_dir = Path(tmp) / "home"
            home_dir.mkdir()

            # Set up environment for this test
            with patch.dict("os.environ", {"MAMONIA_HOME": str(home_dir), "MAMONIA_DB": str(db_path)}):
                storage = Storage(db_path)
                storage.initialize()

                options = DiscoverOptions(limit=5, playlist="test_playlist")  # Required by run_discover

                # Should not raise an exception (may fail due to missing providers, but shouldn't crash)
                try:
                    run_discover(
                        options=options,
                        emit=lambda msg: None,
                        emit_error=lambda msg: None,
                    )
                except WorkflowAbort as e:
                    # Expected - playlist not found or similar
                    pass
                except Exception as e:
                    # Other exceptions are acceptable for this test
                    pass

                storage.close()

    def test_run_discover_routes_through_v2_discovery_wrapper(self) -> None:
        from mamonia.workflow import DiscoverOptions, run_discover
        from mamonia.models import ArtistProfile, TasteProfile
        from mamonia.discovery import track_keys_from_input
        from mamonia.profiles import source_identity_from_tracks

        with tempfile.TemporaryDirectory() as tmp:
            home_dir = Path(tmp) / "home"
            home_dir.mkdir()
            db_path = Path(tmp) / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            spotify = MagicMock()
            spotify.available = False
            spotify.cache_summary.return_value = {"hits": 0, "misses": 0}
            providers = (
                spotify,
                MagicMock(),
                MagicMock(),
                MagicMock(available=False),
                MagicMock(),
                MagicMock(),
            )

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home_dir), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=providers
            ), patch("mamonia.workflow.discover_releases", return_value=[]) as discover_mock:
                run_discover(
                    DiscoverOptions(playlist=str(playlist), reuse_profile=True),
                    emit=lambda _msg: None,
                    emit_error=lambda _msg: None,
                )

        self.assertTrue(discover_mock.called)

    def test_v2_pipeline_produces_enriched_recommendations(self) -> None:
        """Test that v2 pipeline returns ReleaseRecommendation objects with tracks."""
        from mamonia.pipeline_v2 import run_v2_pipeline
        from mamonia.models import ReleaseRecommendation

        tracks = [InputTrack(artist="Test Artist", track="Test Track", album="Test Album")]
        mb = MagicMock()
        mb.search_recording.return_value = None
        mb.browse_release_groups.return_value = []

        results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb)

        # Results should be a list
        self.assertIsInstance(results, list)

        # Each result should be a ReleaseRecommendation
        for rec in results:
            self.assertIsInstance(rec, ReleaseRecommendation)

    def test_v2_pipeline_respects_limit(self) -> None:
        """Test that v2 pipeline respects the limit parameter."""
        from mamonia.pipeline_v2 import run_v2_pipeline

        tracks = [InputTrack(artist="Test Artist", track="Test Track", album="Test Album")]
        mb = MagicMock()
        mb.search_recording.return_value = None
        mb.browse_release_groups.return_value = []

        results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb, limit=3)

        # Should have at most 3 results
        self.assertLessEqual(len(results), 3)

    def test_run_discover_emits_elapsed_time_on_success(self) -> None:
        """Test that elapsed time is tracked from when stage [1/5] begins."""
        # The stopwatch is now initialized right before stage [1/5] begins in run_discover.
        # The elapsed time is emitted at the end of the workflow when complete.
        # This verifies that the stopwatch setup doesn't crash the workflow.
        from mamonia.workflow import DiscoverOptions, run_discover

        messages = []
        options = DiscoverOptions(
            playlist=None,
            profile_ref=None,
            dry_run=True,
        )

        # Run with invalid profile/playlist to test that initialization works
        try:
            run_discover(options, emit=messages.append, emit_error=messages.append)
        except Exception:
            pass

        # Verify that messages were captured (workflow attempted to run)
        self.assertIsInstance(messages, list)

    def test_run_discover_uses_busy_phases_for_blocking_stages(self) -> None:
        from mamonia.workflow import DiscoverOptions, run_discover
        from mamonia.models import ArtistProfile, TasteProfile, InputTrack
        from mamonia.storage import Storage
        from mamonia.discovery import track_keys_from_input
        from mamonia.profiles import source_identity_from_tracks

        class _BusySpy:
            def __init__(self):
                self.labels = []

            class _Ctx:
                def __init__(self, outer, label):
                    self.outer = outer
                    self.label = label

                def __enter__(self):
                    self.outer.labels.append(self.label)
                    return None

                def __exit__(self, exc_type, exc, tb):
                    return False

            def phase(self, label, _lines=None):
                return self._Ctx(self, label)

        with tempfile.TemporaryDirectory() as tmp:
            home_dir = Path(tmp) / "home"
            home_dir.mkdir()
            db_path = Path(tmp) / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            busy_spy = _BusySpy()
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            spotify = MagicMock()
            spotify.available = False
            spotify.cache_summary.return_value = {"hits": 0, "misses": 0}
            providers = (
                spotify,
                MagicMock(),
                MagicMock(),
                MagicMock(available=False),
                MagicMock(),
                MagicMock(),
            )

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home_dir), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=providers
            ), patch("mamonia.workflow.discover_releases", return_value=[]), patch(
                "mamonia.workflow.choose_busy_status_reporter", return_value=busy_spy
            ):
                run_discover(
                    DiscoverOptions(playlist=str(playlist), reuse_profile=True),
                    emit=lambda _msg: None,
                    emit_error=lambda _msg: None,
                )

        self.assertIn("[1/5] Loading saved profile", busy_spy.labels)
        self.assertIn("[3/5] Resolving platform IDs", busy_spy.labels)

    def test_run_discover_emits_verbose_v2_diagnostics(self) -> None:
        from mamonia.workflow import DiscoverOptions, run_discover
        from mamonia.models import ArtistProfile, TasteProfile, InputTrack
        from mamonia.discovery import track_keys_from_input
        from mamonia.profiles import source_identity_from_tracks
        from mamonia.progress import DiscoverySummary

        class _ProgressStub:
            def summary(self):
                return DiscoverySummary(
                    candidates_processed=3,
                    total_candidates=7,
                    release_groups_checked=11,
                    accepted=2,
                    spotify_misses=1,
                    musicbrainz_misses=2,
                    skips={"old_release": 4},
                )

        with tempfile.TemporaryDirectory() as tmp:
            home_dir = Path(tmp) / "home"
            home_dir.mkdir()
            db_path = Path(tmp) / "mamonia.sqlite"
            playlist = Path(tmp) / "tracks.txt"
            playlist.write_text("Seed Artist - Seed Song\n", encoding="utf-8")
            tracks = [InputTrack(artist="Seed Artist", track="Seed Song", artists=["Seed Artist"])]
            source = source_identity_from_tracks(str(playlist), tracks)
            profile = TasteProfile(
                artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                top_artists=[ArtistProfile(name="Seed Artist", playlist_count=1, affinity_score=2)],
                n_artists=1,
            )
            storage = Storage(db_path)
            storage.upsert_taste_profile(
                name=source["name"],
                source_type=source["source_type"],
                source_ref=source["source_ref"],
                source_key=source["source_key"],
                source_hash=source["source_hash"],
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            storage.close()

            spotify = MagicMock()
            spotify.available = False
            spotify.cache_summary.return_value = {"hits": 0, "misses": 0}
            providers = (
                spotify,
                MagicMock(),
                MagicMock(),
                MagicMock(available=False),
                MagicMock(),
                MagicMock(),
            )
            messages: list[str] = []

            with patch.dict("os.environ", {"MAMONIA_HOME": str(home_dir), "MAMONIA_DB": str(db_path)}), patch(
                "mamonia.workflow._providers", return_value=providers
            ), patch("mamonia.workflow.discover_releases", return_value=[]), patch(
                "mamonia.workflow.choose_progress_reporter", return_value=_ProgressStub()
            ):
                run_discover(
                    DiscoverOptions(playlist=str(playlist), reuse_profile=True, verbose=True),
                    emit=messages.append,
                    emit_error=lambda _msg: None,
                )

        self.assertTrue(any("[v2 diagnostics]" in msg for msg in messages))
        self.assertTrue(any("skips=old_release:4" in msg for msg in messages))

import unittest


class SpotifyPlaylistNameTests(unittest.TestCase):
    """Tests for _spotify_playlist_name function."""

    def test_prepends_mmn_prefix(self) -> None:
        """Test that mmn_ prefix is added."""
        from mamonia.workflow import _spotify_playlist_name
        self.assertTrue(_spotify_playlist_name("Test Playlist").startswith("mmn_"))

    def test_preserves_original_case(self) -> None:
        """Test that original case is preserved."""
        from mamonia.workflow import _spotify_playlist_name
        self.assertEqual(_spotify_playlist_name("R11"), "mmn_R11")
        self.assertEqual(_spotify_playlist_name("My Playlist"), "mmn_My_Playlist")
        self.assertEqual(_spotify_playlist_name("UPPERCASE"), "mmn_UPPERCASE")

    def test_handles_empty_string(self) -> None:
        """Test that empty string returns mmn."""
        from mamonia.workflow import _spotify_playlist_name
        self.assertEqual(_spotify_playlist_name(""), "mmn")

    def test_truncates_to_100_chars(self) -> None:
        """Test that name is truncated to 100 chars including prefix."""
        from mamonia.workflow import _spotify_playlist_name
        long_name = "A" * 120
        result = _spotify_playlist_name(long_name)
        self.assertLessEqual(len(result), 100)
        self.assertTrue(result.startswith("mmn_"))


class ShuffleRecommendationTests(unittest.TestCase):

    def test_shuffle_is_deterministic_and_preserves_tracks(self) -> None:
        recommendations = [
            ReleaseRecommendation(
                artist=f"Artist {idx}",
                title=f"Release {idx}",
                tracks=[ReleaseTrack(title=f"Track {idx}", artists=f"Artist {idx}")],
            )
            for idx in range(8)
        ]

        first = shuffle_recommendations(recommendations, seed=123)
        second = shuffle_recommendations(recommendations, seed=123)

        self.assertEqual([r.title for r in first], [r.title for r in second])
        self.assertCountEqual([r.title for r in first], [r.title for r in recommendations])
        self.assertTrue(all(len(r.tracks) == 1 for r in first))
        self.assertNotEqual([r.title for r in first], [r.title for r in recommendations])


class _TidalMatch:
    def __init__(self, track_id: str, album_id: str | None = None, isrc: str | None = None, stage: str | None = None):
        self.track_id = track_id
        self.album_id = album_id
        self.isrc = isrc
        self.title = None
        self.artists = []
        self.stage = stage


class _CountingTidal:
    available = True

    def __init__(self, matches: dict[str, _TidalMatch] | None = None):
        self.matches = matches or {}
        self.calls = 0
        self.last_lookup_error = None

    def lookup_track(self, artist: str, title: str, album: str | None = None, isrc: str | None = None):
        self.calls += 1
        self.last_lookup_error = None
        return self.matches.get(title)


class _ErroringTidal(_CountingTidal):
    def lookup_track(self, artist: str, title: str, album: str | None = None, isrc: str | None = None):
        self.calls += 1
        self.last_lookup_error = "HTTP 403"
        return None


class _AlbumSensitiveTidal(_CountingTidal):
    def __init__(self, track_id: str):
        super().__init__()
        self._match = _TidalMatch(track_id=track_id)
        self.albums_seen: list[str | None] = []

    def lookup_track_with_window(
        self,
        artist: str,
        title: str,
        album: str | None = None,
        isrc: str | None = None,
        *,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_today=None,
    ):
        self.calls += 1
        self.last_lookup_error = None
        self.albums_seen.append(album)
        if album:
            return None
        return self._match


class _AlbumTracklistFallbackTidal(_CountingTidal):
    def __init__(self, track_id: str, artist_name: str, track_name: str):
        super().__init__()
        self.fetch_album_calls: list[str] = []
        self._album = _FakeAlbum(
            tracks=[_FakeAlbumTrack(track_id=track_id, artist_name=artist_name, track_name=track_name)]
        )

    def lookup_track_with_window(
        self,
        artist: str,
        title: str,
        album: str | None = None,
        isrc: str | None = None,
        *,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_today=None,
    ):
        self.calls += 1
        self.last_lookup_error = None
        return None

    def fetch_album(self, album_id: str):
        self.fetch_album_calls.append(album_id)
        return self._album


class _FakeAlbum:
    def __init__(self, tracks):
        self._tracks = tracks

    def tracks(self):
        return list(self._tracks)


class _FakeAlbumTrack:
    def __init__(self, *, track_id: str, artist_name: str, track_name: str):
        self.id = track_id
        self.name = track_name
        self.isrc = None
        self.artists = [_FakeAlbumArtist(artist_name)]


class _FakeAlbumArtist:
    def __init__(self, name: str):
        self.name = name


class _RecoverySpotify:
    available = True

    def representative_tracks(
        self,
        artist_name: str,
        album_name: str,
        cap: int,
        *,
        allow_broad_search: bool = True,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_today=None,
    ):
        return (
            None,
            None,
            [
                ReleaseTrack(
                    title=album_name,
                    artists=artist_name,
                    spotify_track_id="sp-recovered",
                    spotify_uri="spotify:track:sp-recovered",
                    resolution_source="spotify_release_rescue",
                    resolution_note="Recovered from provider release-level rescue.",
                )
            ],
        )


if __name__ == "__main__":
    unittest.main()
