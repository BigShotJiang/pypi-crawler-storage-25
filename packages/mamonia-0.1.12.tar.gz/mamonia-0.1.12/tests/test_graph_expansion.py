"""Tests for mamonia/graph_expansion.py — §5–6 tier assignment & expansion."""

from __future__ import annotations

import unittest
from unittest.mock import MagicMock

from mamonia.graph_expansion import (
    TIER_1, TIER_2A, TIER_2B, TIER_3, TIER_4,
    TIER_FACTORS,
    _looks_like_mbid,
    assign_tier_1,
    expand_graph,
)
from mamonia.models import ArtistSeed


def _seed(
    name: str,
    mbid: str | None = None,
    weight: float = 1.0,
) -> ArtistSeed:
    return ArtistSeed(
        artist_mbid=mbid,
        canonical_name=name,
        seed_weight=weight,
    )


VALID_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
VALID_MBID_2 = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
VALID_MBID_3 = "c3d4e5f6-a7b8-9012-cdef-123456789012"


class TestAssignTier1(unittest.TestCase):

    def test_seeds_marked_tier1(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        graph = assign_tier_1(seeds)
        self.assertIn(VALID_MBID, graph.artist_tiers)
        self.assertEqual(graph.artist_tiers[VALID_MBID], TIER_1)

    def test_seed_without_mbid_keyed_by_name(self):
        seeds = [_seed("Burial")]
        graph = assign_tier_1(seeds)
        self.assertIn("burial", graph.artist_tiers)
        self.assertEqual(graph.artist_tiers["burial"], TIER_1)

    def test_multiple_seeds_all_tier1(self):
        mbid2 = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
        seeds = [_seed("A", mbid=VALID_MBID), _seed("B", mbid=mbid2)]
        graph = assign_tier_1(seeds)
        self.assertEqual(graph.artist_tiers[VALID_MBID], TIER_1)
        self.assertEqual(graph.artist_tiers[mbid2], TIER_1)

    def test_no_edges_at_tier1_stage(self):
        seeds = [_seed("Portishead", mbid=VALID_MBID)]
        graph = assign_tier_1(seeds)
        self.assertEqual(graph.edges, [])


class TestTierFactors(unittest.TestCase):

    def test_tier_factors_sum_descending(self):
        factors = [TIER_FACTORS[t] for t in (TIER_1, TIER_2A, TIER_2B, TIER_3, TIER_4)]
        self.assertEqual(factors, sorted(factors, reverse=True))

    def test_tier1_factor_is_one(self):
        self.assertEqual(TIER_FACTORS[TIER_1], 1.00)

    def test_tier4_factor_is_lowest(self):
        self.assertEqual(TIER_FACTORS[TIER_4], 0.25)


class TestExpandGraphNoBrainz(unittest.TestCase):
    """Expansion with no providers returns just Tier 1 seeds."""

    def test_no_providers_returns_seeds_only(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        graph = expand_graph(seeds)
        self.assertEqual(graph.artist_tiers[VALID_MBID], TIER_1)
        self.assertEqual(graph.edges, [])

    def test_empty_seeds_returns_empty_graph(self):
        graph = expand_graph([])
        self.assertEqual(graph.artist_tiers, {})
        self.assertEqual(graph.edges, [])

    def test_graph_diagnostics_emitted_when_similarity_providers_missing(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        emitted: list[str] = []

        expand_graph(seeds, emit=emitted.append, debug=True)

        text = "\n".join(emitted)
        self.assertIn("lb_missing_provider", text)
        self.assertIn("lf_missing_provider", text)
        self.assertIn("Graph diagnostics", text)


class TestExpandGraphWithListenBrainz(unittest.TestCase):

    def _make_lb(self, similar: list[dict]) -> MagicMock:
        lb = MagicMock()
        lb.get_similar_artists.return_value = similar
        return lb

    def test_lb_similar_added_as_tier3_with_tag_match(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb_mbid = "c3d4e5f6-a7b8-9012-cdef-123456789012"
        lb = self._make_lb([{"artist_mbid": lb_mbid, "artist_name": "Portishead", "score": 0.9}])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic", "downtempo"},
            lb_mbid: {"trip hop", "electronic"},
        }
        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)
        self.assertIn(lb_mbid, graph.artist_tiers)
        self.assertIn(graph.artist_tiers[lb_mbid], (TIER_3, TIER_4))

    def test_lb_similar_tier4_with_no_tag_match(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        lb = self._make_lb([{"artist_mbid": lb_mbid, "artist_name": "Some Artist", "score": 0.5}])
        # no overlapping tags
        seed_tags = {VALID_MBID: {"trip hop"}, lb_mbid: {"country"}}
        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)
        self.assertIn(lb_mbid, graph.artist_tiers)
        self.assertEqual(graph.artist_tiers[lb_mbid], TIER_4)

    def test_lb_similar_missing_tags_defaults_to_tier4(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        lb = self._make_lb([{"artist_mbid": lb_mbid, "artist_name": "Unknown Artist", "score": 8, "share": 0.5}])
        seed_tags = {VALID_MBID: {"trip hop", "electronic"}}

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)

        self.assertEqual(graph.artist_tiers[lb_mbid], TIER_4)

    def test_lb_similar_preserves_multi_seed_edges_for_same_unknown_artist(self):
        target_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        seeds = [
            _seed("Massive Attack", mbid=VALID_MBID),
            _seed("Portishead", mbid=VALID_MBID_2),
        ]
        lb = self._make_lb([{"artist_mbid": target_mbid, "artist_name": "Ghostpoet", "score": 9, "share": 0.6}])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic"},
            VALID_MBID_2: {"trip hop", "downtempo"},
            target_mbid: {"trip hop", "electronic"},
        }

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)
        lb_edges = [e for e in graph.edges if e.target_artist_mbid == target_mbid]

        self.assertEqual(len(lb_edges), 2)
        self.assertEqual(len([k for k in graph.artist_tiers if k == target_mbid]), 1)
        self.assertEqual(graph.artist_tiers[target_mbid], TIER_3)

    def test_lb_similar_dedupes_exact_same_seed_target_relation(self):
        target_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb = self._make_lb([
            {"artist_mbid": target_mbid, "artist_name": "Ghostpoet", "score": 9, "share": 0.6},
            {"artist_mbid": target_mbid, "artist_name": "Ghostpoet", "score": 9, "share": 0.6},
        ])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic"},
            target_mbid: {"trip hop", "electronic"},
        }

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)
        lb_edges = [e for e in graph.edges if e.target_artist_mbid == target_mbid]

        self.assertEqual(len(lb_edges), 1)

    def test_lb_similar_does_not_add_tier1_artist_as_discovery_edge(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb = self._make_lb([{"artist_mbid": VALID_MBID, "artist_name": "Massive Attack", "score": 9, "share": 0.9}])
        seed_tags = {VALID_MBID: {"trip hop", "electronic"}}

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)

        self.assertEqual(graph.edges, [])
        self.assertEqual(graph.artist_tiers[VALID_MBID], TIER_1)

    def test_lb_similar_pairwise_overlap_can_promote_when_global_overlap_is_diluted(self):
        target_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        seeds = [
            _seed("Trip Hop Seed", mbid=VALID_MBID),
            _seed("Metal Seed", mbid=VALID_MBID_2),
            _seed("Folk Seed", mbid=VALID_MBID_3),
        ]
        lb = self._make_lb([{"artist_mbid": target_mbid, "artist_name": "Adjacent Artist", "score": 7, "share": 0.4}])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic", "downtempo", "dub"},
            VALID_MBID_2: {"metal", "doom", "sludge", "noise"},
            VALID_MBID_3: {"folk", "acoustic", "singer-songwriter", "americana"},
            target_mbid: {"trip hop"},
        }

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)

        self.assertEqual(graph.artist_tiers[target_mbid], TIER_3)

    def test_lb_connection_strength_uses_relative_score_and_share(self):
        high_mbid = "d4e5f6a7-b8c9-0123-defa-234567890123"
        low_mbid = "e5f6a7b8-c9d0-1234-efab-345678901234"
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        lb = self._make_lb([
            {"artist_mbid": high_mbid, "artist_name": "High Proof", "score": 10, "share": 0.8},
            {"artist_mbid": low_mbid, "artist_name": "Low Proof", "score": 2, "share": 0.1},
        ])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic"},
            high_mbid: {"trip hop"},
            low_mbid: {"trip hop"},
        }

        graph = expand_graph(seeds, listenbrainz=lb, seed_tags=seed_tags)
        strengths = {e.target_artist_name: e.connection_strength for e in graph.edges}

        self.assertGreater(strengths["High Proof"], strengths["Low Proof"])
        self.assertLess(strengths["Low Proof"], 1.0)

    def test_lb_cap_at_6_similar_per_seed(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        similar = [
            {"artist_mbid": f"mbid-lb-{i:036d}", "artist_name": f"Artist {i}", "score": 0.8}
            for i in range(10)
        ]
        lb = self._make_lb(similar)
        graph = expand_graph(seeds, listenbrainz=lb)
        lb_edges = [e for e in graph.edges if e.relation_type == "listenbrainz_similar"]
        self.assertLessEqual(len(lb_edges), 6)

    def test_total_cap_at_15(self):
        mbid2 = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
        seeds = [
            _seed("A", mbid=VALID_MBID),
            _seed("B", mbid=mbid2),
        ]
        similar = [
            {"artist_mbid": f"mbid-lb-{i:036d}", "artist_name": f"Artist {i}", "score": 0.8}
            for i in range(20)
        ]
        lb = self._make_lb(similar)
        graph = expand_graph(seeds, listenbrainz=lb)
        non_seed_tiers = {k: v for k, v in graph.artist_tiers.items()
                          if v != TIER_1}
        self.assertLessEqual(len(non_seed_tiers), 15)

    def test_interleaving_can_add_lastfm_when_legacy_would_starve(self):
        seed = _seed("Massive Attack", mbid=VALID_MBID)
        lb = self._make_lb([
            {"artist_mbid": f"lb-{i:032d}", "artist_name": f"LB Artist {i}", "score": 0.8}
            for i in range(6)
        ])
        lb.settings = MagicMock(graph_interleave_enabled=True, graph_interleave_mode="per_seed_round_robin", lastfm_tag_budget_per_run=0)
        lf = MagicMock()
        lf.get_similar_artists.return_value = [{"artist_mbid": "lf-artist-1", "artist_name": "LF Artist 1", "match": 0.9}]
        lf.top_tags.return_value = []

        graph = expand_graph([seed], listenbrainz=lb, lastfm=lf)

        lf_edges = [e for e in graph.edges if e.relation_type == "lastfm_similar"]
        self.assertGreaterEqual(len(lf_edges), 1)

    def test_lastfm_tag_budget_limits_hydration_calls(self):
        seed = _seed("Massive Attack", mbid=VALID_MBID)
        lb = self._make_lb([
            {"artist_mbid": "lb-a", "artist_name": "LB A", "score": 0.8},
            {"artist_mbid": "lb-b", "artist_name": "LB B", "score": 0.7},
        ])
        lb.settings = MagicMock(graph_interleave_enabled=False, graph_interleave_mode="per_seed_round_robin", lastfm_tag_budget_per_run=1)
        lf = MagicMock()
        lf.get_similar_artists.return_value = []
        lf.top_tags.return_value = ["trip hop"]

        expand_graph([seed], listenbrainz=lb, lastfm=lf, seed_tags={VALID_MBID: {"trip hop"}})

        self.assertEqual(lf.top_tags.call_count, 1)


class TestExpandGraphWithMusicBrainz(unittest.TestCase):

    def _make_mb(self, relations: list[dict]) -> MagicMock:
        mb = MagicMock()
        mb.get_artist_relations.return_value = relations
        return mb

    def test_strong_relation_with_tag_match_is_tier2a(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        collab_mbid = "e5f6a7b8-c9d0-1234-efab-345678901234"
        mb = self._make_mb([{
            "type": "member of band",
            "artist_mbid": collab_mbid,
            "artist_name": "3D",
        }])
        seed_tags = {
            VALID_MBID: {"trip hop", "electronic"},
            collab_mbid: {"trip hop", "electronic", "hip hop"},
        }
        graph = expand_graph(seeds, musicbrainz=mb, seed_tags=seed_tags)
        self.assertIn(collab_mbid, graph.artist_tiers)
        self.assertEqual(graph.artist_tiers[collab_mbid], TIER_2A)

    def test_strong_relation_without_tag_match_is_tier2b(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        collab_mbid = "f6a7b8c9-d0e1-2345-fabc-456789012345"
        mb = self._make_mb([{
            "type": "collaboration",
            "artist_mbid": collab_mbid,
            "artist_name": "Someone",
        }])
        # tags don't overlap at all
        seed_tags = {VALID_MBID: {"trip hop"}, collab_mbid: {"country"}}
        graph = expand_graph(seeds, musicbrainz=mb, seed_tags=seed_tags)
        self.assertIn(collab_mbid, graph.artist_tiers)
        self.assertEqual(graph.artist_tiers[collab_mbid], TIER_2B)

    def test_medium_relation_without_tag_match_not_added(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        collab_mbid = "a7b8c9d0-e1f2-3456-abcd-567890123456"
        mb = self._make_mb([{
            "type": "producer",
            "artist_mbid": collab_mbid,
            "artist_name": "Producer X",
        }])
        seed_tags = {VALID_MBID: {"trip hop"}, collab_mbid: {"classical"}}
        graph = expand_graph(seeds, musicbrainz=mb, seed_tags=seed_tags)
        # overlap < 0.1 threshold → not added
        self.assertNotIn(collab_mbid, graph.artist_tiers)

    def test_mb_provider_error_does_not_crash(self):
        seeds = [_seed("Massive Attack", mbid=VALID_MBID)]
        mb = MagicMock()
        mb.get_artist_relations.side_effect = RuntimeError("API down")
        graph = expand_graph(seeds, musicbrainz=mb)
        self.assertIn(VALID_MBID, graph.artist_tiers)  # seed still present


class TestHelpers(unittest.TestCase):

    def test_looks_like_mbid_valid(self):
        self.assertTrue(_looks_like_mbid("a1b2c3d4-e5f6-7890-abcd-ef1234567890"))

    def test_looks_like_mbid_invalid(self):
        self.assertFalse(_looks_like_mbid("burial"))
        self.assertFalse(_looks_like_mbid(""))
        self.assertFalse(_looks_like_mbid("not-a-uuid-at-all"))


if __name__ == "__main__":
    unittest.main()
