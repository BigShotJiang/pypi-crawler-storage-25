from __future__ import annotations

import datetime as dt

from mamonia.matching import MatchCandidate, select_staged_candidate
from mamonia.discovery_window import DiscoveryWindow


def _candidate(
    *,
    track_id: str,
    release_date: str | None,
    isrc: str | None,
    fit: int,
) -> MatchCandidate:
    return MatchCandidate(
        provider="test",
        track_id=track_id,
        album_id="alb",
        title="Song",
        artists=["Artist"],
        album_title="Album",
        album_release_date=release_date,
        isrc=isrc,
        fit_score=fit,
        raw_payload={"id": track_id},
    )


def test_stage1_isrc_in_window_beats_out_of_window() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="old", release_date="2025-01-01", isrc="X", fit=999),
            _candidate(track_id="new", release_date="2026-04-10", isrc="X", fit=1),
        ],
        target_isrc="X",
        mb_release_date="2026-04-20",
        discovery_months=6,
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is not None
    assert selected.stage == "isrc_in_window"
    assert selected.candidate.track_id == "new"


def test_stage2_isrc_anywhere_when_none_in_window() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="old", release_date="2024-01-01", isrc="X", fit=30),
            _candidate(track_id="older", release_date="2023-01-01", isrc="X", fit=10),
        ],
        target_isrc="X",
        mb_release_date="2026-04-20",
        discovery_months=6,
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is not None
    assert selected.stage == "isrc_anywhere"
    assert selected.candidate.track_id == "old"


def test_stage3_exact_mb_date_when_no_isrc_match() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="wrong-date", release_date="2026-03-01", isrc=None, fit=100),
            _candidate(track_id="exact-date", release_date="2026-04-20", isrc=None, fit=10),
        ],
        target_isrc="DIFFERENT",
        mb_release_date="2026-04-20",
        discovery_months=6,
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is not None
    assert selected.stage == "mb_exact_date"
    assert selected.candidate.track_id == "exact-date"


def test_stage4_metadata_in_window_when_mb_exact_missing() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="in-window", release_date="2026-04-10", isrc=None, fit=20),
            _candidate(track_id="out-window", release_date="2024-01-01", isrc=None, fit=100),
        ],
        target_isrc=None,
        mb_release_date="2026-04-20",
        discovery_months=6,
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is not None
    assert selected.stage == "metadata_in_window"
    assert selected.candidate.track_id == "in-window"


def test_none_when_nothing_survives_stage4() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="old", release_date="2024-01-01", isrc=None, fit=99),
        ],
        target_isrc=None,
        mb_release_date="2026-04-20",
        discovery_months=6,
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is None


def test_discovery_window_overrides_months() -> None:
    selected = select_staged_candidate(
        [
            _candidate(track_id="in-old-months", release_date="2026-04-10", isrc=None, fit=20),
            _candidate(track_id="in-window", release_date="2025-06-15", isrc=None, fit=5),
        ],
        target_isrc=None,
        mb_release_date="2025-06-20",
        discovery_months=1,
        discovery_window=DiscoveryWindow(start_date=dt.date(2025, 6, 1), end_date=dt.date(2025, 6, 30)),
        discovery_today=dt.date(2026, 4, 30),
    )
    assert selected is not None
    assert selected.candidate.track_id == "in-window"
