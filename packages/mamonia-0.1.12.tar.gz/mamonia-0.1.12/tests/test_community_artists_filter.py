from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from mamonia.config import Settings
from mamonia.filtering.community_artists import CommunityArtistsFilter
from mamonia.filtering.profile_index import ProfileIndex, build_profile_index
from mamonia.models import ArtistProfile, TasteProfile, WeightedTerm, FilteredCommunityArtist


def get_test_settings(**kwargs) -> Settings:
    with tempfile.TemporaryDirectory() as tmpdir:
        return Settings(
            data_dir=Path(tmpdir),
            db_path=Path(tmpdir) / "test.db",
            **kwargs
        )


# ---------------------------------------------------------------------------
# Unit: CommunityArtistsFilter basics
# ---------------------------------------------------------------------------

class TestCommunityArtistsFilter:

    @pytest.mark.parametrize("overrides,expected", [
        ({}, {"ubiquity_threshold": 0.3, "min_genre_overlap": 0.2, "use_global_cache": False, "enable_filtering": True}),
        (
            {"ubiquitous_artist_threshold": 0.5, "genre_overlap_minimum": 0.3, "use_global_ubiquity_cache": True, "enable_community_filtering": False},
            {"ubiquity_threshold": 0.5, "min_genre_overlap": 0.3, "use_global_cache": True, "enable_filtering": False},
        ),
    ])
    def test_filter_init(self, overrides, expected):
        settings = get_test_settings(**overrides)
        f = CommunityArtistsFilter(settings)
        assert f.ubiquity_threshold == expected["ubiquity_threshold"]
        assert f.min_genre_overlap == expected["min_genre_overlap"]
        assert f.use_global_cache == expected["use_global_cache"]
        assert f.enable_filtering == expected["enable_filtering"]

    def test_filter_disabled_returns_original_scores(self):
        settings = get_test_settings(enable_community_filtering=False)
        f = CommunityArtistsFilter(settings)
        profile = TasteProfile(artists=[
            ArtistProfile(name="Artist A", community_artists=["Artist B", "Artist C"]),
        ])
        result = f.filter_community_artists(profile)
        assert "Artist B" in result
        assert "Artist C" in result
        assert isinstance(result["Artist B"], FilteredCommunityArtist)
        assert result["Artist B"].relevance == 1.0
        assert result["Artist C"].relevance == 1.0
        assert result["Artist B"].seed_artists == ["Artist A"]

    def test_collect_community_artists(self):
        settings = get_test_settings()
        f = CommunityArtistsFilter(settings)
        profile = TasteProfile(artists=[
            ArtistProfile(name="Artist A", community_artists=["Artist B", "Artist C"]),
            ArtistProfile(name="Artist D", community_artists=["Artist B", "Artist E"]),
        ])
        all_community = f._collect_community_artists(profile)
        assert "Artist B" in all_community
        assert len(all_community["Artist B"]["seed_artists"]) == 2
        assert len(all_community["Artist C"]["seed_artists"]) == 1

    def test_compute_ubiquity_scores(self):
        settings = get_test_settings()
        f = CommunityArtistsFilter(settings)
        profile = TasteProfile(artists=[
            ArtistProfile(name="Artist A"),
            ArtistProfile(name="Artist B"),
            ArtistProfile(name="Artist C"),
        ])
        all_community = {
            "Artist X": {"count": 1, "seed_artists": {"Artist A"}},
            "Artist Y": {"count": 2, "seed_artists": {"Artist A", "Artist B"}},
            "Artist Z": {"count": 3, "seed_artists": {"Artist A", "Artist B", "Artist C"}},
        }
        scores = f._compute_ubiquity_scores(profile, all_community)
        assert scores["Artist X"] > scores["Artist Y"] > scores["Artist Z"]

    def test_ubiquity_penalty(self):
        settings = get_test_settings()
        f = CommunityArtistsFilter(settings)
        assert f._ubiquity_penalty(0.1) < 0.5
        assert f._ubiquity_penalty(0.9) > 0.5


# ---------------------------------------------------------------------------
# Unit: ProfileIndex
# ---------------------------------------------------------------------------

class TestProfileIndex:

    def _make_profile(self) -> TasteProfile:
        return TasteProfile(artists=[
            ArtistProfile(
                name="Massive Attack",
                genres=["trip-hop", "electronic"],
                tags=["trip hop", "downtempo"],
                labels=["Virgin"],
                collaborator_artists=["Ghostpoet", "Tricky"],
                related_acts=["Portishead"],
                similar_artists=["Portishead", "Burial"],
                community_artists=["Ghostpoet", "VAAV Social Club"],
                community_artists_meta={"Ghostpoet": 0.8, "VAAV Social Club": 0.1},
            ),
            ArtistProfile(
                name="Portishead",
                genres=["trip-hop", "art rock"],
                tags=["trip hop"],
                labels=["Go! Beat"],
                collaborator_artists=["Tricky"],
                related_acts=[],
                similar_artists=["Massive Attack"],
                community_artists=["Burial"],
                community_artists_meta={"Burial": 0.5},
            ),
        ])

    def test_seed_genres_populated(self):
        index = build_profile_index(self._make_profile())
        # normalize_key("trip-hop") → "trip hop"
        assert "trip hop" in index.seed_genres["massive attack"]
        assert "electronic" in index.seed_genres["massive attack"]

    def test_seed_collaborators_populated(self):
        index = build_profile_index(self._make_profile())
        assert "ghostpoet" in index.seed_collaborators["massive attack"]
        assert "tricky" in index.seed_collaborators["massive attack"]

    def test_reverse_collaborator_index(self):
        index = build_profile_index(self._make_profile())
        # Ghostpoet is a collaborator of Massive Attack → should appear in reverse index
        assert "massive attack" in index.collaborator_to_seeds.get("ghostpoet", set())

    def test_reverse_similar_lastfm_index(self):
        index = build_profile_index(self._make_profile())
        # Burial is in Massive Attack's similar_artists → reverse: burial → massive attack
        assert "massive attack" in index.similar_lastfm_to_seeds.get("burial", set())

    def test_lb_listener_share_max_across_seeds(self):
        index = build_profile_index(self._make_profile())
        # Ghostpoet appears in Massive Attack's meta with share=0.8
        assert abs(index.lb_listener_share.get("ghostpoet", 0.0) - 0.8) < 1e-9
        # VAAV Social Club has share=0.1
        assert abs(index.lb_listener_share.get("vaav social club", 0.0) - 0.1) < 1e-9
        # Burial: appears in Portishead meta with share=0.5
        assert abs(index.lb_listener_share.get("burial", 0.0) - 0.5) < 1e-9

    def test_empty_profile_returns_empty_index(self):
        index = build_profile_index(TasteProfile(artists=[]))
        assert index.collaborator_to_seeds == {}
        assert index.lb_listener_share == {}


# ---------------------------------------------------------------------------
# Integration: filter_community_artists
# ---------------------------------------------------------------------------

class TestCommunityArtistsFilterIntegration:

    def test_filter_with_multiple_seed_artists(self):
        """Ubiquitous artist gets lower relevance than specific ones."""
        settings = get_test_settings(ubiquitous_artist_threshold=0.5)
        f = CommunityArtistsFilter(settings)
        profile = TasteProfile(artists=[
            ArtistProfile(name="Seed A", community_artists=["Artist X", "Artist Y"]),
            ArtistProfile(name="Seed B", community_artists=["Artist X", "Artist Z"]),
            ArtistProfile(name="Seed C", community_artists=["Artist X", "Artist W"]),
        ])
        result = f.filter_community_artists(profile)
        # All should be present (specific ones have lb-only:0.00 rescue_reason)
        assert "Artist X" in result
        assert "Artist Y" in result
        assert "Artist Z" in result
        assert "Artist W" in result
        # Ubiquitous artist has lower relevance than specific
        assert result["Artist X"].relevance < result["Artist Y"].relevance

    def test_filter_with_enabled_setting(self):
        settings_enabled = get_test_settings(enable_community_filtering=True)
        settings_disabled = get_test_settings(enable_community_filtering=False)
        profile = TasteProfile(artists=[
            ArtistProfile(name="Artist A", community_artists=["Artist B"]),
        ])
        result_disabled = CommunityArtistsFilter(settings_disabled).filter_community_artists(profile)
        result_enabled = CommunityArtistsFilter(settings_enabled).filter_community_artists(profile)
        assert result_disabled["Artist B"].relevance == 1.0
        assert "Artist B" in result_enabled
        assert isinstance(result_enabled["Artist B"], FilteredCommunityArtist)

    def test_filtered_community_artist_model(self):
        fca = FilteredCommunityArtist(
            relevance=0.85, ubiquity_score=0.9, penalty=0.7,
            contextual_score=0.45, genre_overlap=0.45,
            matching_genres=["electronic", "ambient"],
            tag_overlap=0.0, matching_tags=[],
            collaborated=False, label_overlap=0.0, matching_labels=[],
            seed_artists=["Aphex Twin", "Autechre"],
            rescued=True, rescue_reason="genre-match",
        )
        assert fca.relevance == 0.85
        assert fca.rescued is True
        assert fca.rescue_reason == "genre-match"

    def test_backward_compat_with_float_values(self):
        profile = TasteProfile(
            artists=[],
            filtered_community_artists={"Artist A": 0.85, "Artist B": 1.0},
        )
        assert isinstance(profile.filtered_community_artists["Artist A"], FilteredCommunityArtist)
        assert profile.filtered_community_artists["Artist A"].relevance == 0.85

    def test_rescue_path_ubiquitous_via_collaboration(self):
        """Ubiquitous artist is rescued when it's listed as a collaborator by a seed."""
        settings = get_test_settings(ubiquitous_artist_threshold=0.5)
        f = CommunityArtistsFilter(settings)
        # Artist X is ubiquitous (appears in all 3 seeds' community lists)
        # Seed A explicitly lists Artist X as a collaborator → should rescue
        profile = TasteProfile(artists=[
            ArtistProfile(name="Seed A", collaborator_artists=["Artist X"], community_artists=["Artist X"]),
            ArtistProfile(name="Seed B", community_artists=["Artist X"]),
            ArtistProfile(name="Seed C", community_artists=["Artist X"]),
        ])
        all_community = f._collect_community_artists(profile)
        ubiquity_scores = f._compute_ubiquity_scores(profile, all_community)
        assert ubiquity_scores["Artist X"] < 0.5  # ubiquitous

        result = f.filter_community_artists(profile)
        assert "Artist X" in result
        assert result["Artist X"].rescued is True
        assert result["Artist X"].rescue_reason == "collaboration"
        assert result["Artist X"].collaborated is True
        assert result["Artist X"].relevance > 0.1

    def test_heavily_penalized_path_for_ubiquitous_artists(self):
        """Ubiquitous artist with no overlap gets minimal relevance."""
        settings = get_test_settings(ubiquitous_artist_threshold=0.5)
        f = CommunityArtistsFilter(settings)
        # Seeds have genres but community artist has no enrichment (no provider)
        # → genre overlap = 0, no collaboration → penalized
        profile = TasteProfile(artists=[
            ArtistProfile(name="Seed A", genres=["rock"], community_artists=["Artist X"]),
            ArtistProfile(name="Seed B", genres=["rock"], community_artists=["Artist X"]),
            ArtistProfile(name="Seed C", genres=["rock"], community_artists=["Artist X"]),
        ])
        result = f.filter_community_artists(profile)
        assert "Artist X" in result
        assert result["Artist X"].rescued is False
        assert result["Artist X"].rescue_reason == "none"
        assert result["Artist X"].relevance == 0.1


# ---------------------------------------------------------------------------
# LB gate: specific artists and deep_cuts behavior
# ---------------------------------------------------------------------------

class TestLBGate:

    def test_cross_verified_specific_artist_gets_full_relevance(self):
        """A specific artist appearing in a seed's similar_artists list is cross-verified."""
        settings = get_test_settings(ubiquitous_artist_threshold=0.5)
        f = CommunityArtistsFilter(settings)
        # Ghostpoet appears in only 1 of 2 seeds → specific (ubiquity_score normalized to 1.0)
        # Massive Attack lists Ghostpoet in similar_artists → cross-verified via lastfm-similar
        profile = TasteProfile(artists=[
            ArtistProfile(
                name="Massive Attack",
                similar_artists=["Ghostpoet"],
                community_artists=["Ghostpoet"],
            ),
            ArtistProfile(
                name="Portishead",
                community_artists=["Burial"],  # different CA keeps Ghostpoet specific
            ),
        ])
        result = f.filter_community_artists(profile)
        assert "Ghostpoet" in result
        assert result["Ghostpoet"].rescued is True
        assert "lastfm-similar" in result["Ghostpoet"].rescue_reason
        assert result["Ghostpoet"].relevance == 1.0

    def test_specific_artist_collaborator_cross_verified(self):
        """A specific artist that is a MusicBrainz collaborator of a seed is cross-verified."""
        settings = get_test_settings(ubiquitous_artist_threshold=0.5)
        f = CommunityArtistsFilter(settings)
        # Ghostpoet in only 1 of 2 seeds → specific; MA lists it as collaborator → mb-collaborator
        profile = TasteProfile(artists=[
            ArtistProfile(
                name="Massive Attack",
                collaborator_artists=["Ghostpoet"],
                community_artists=["Ghostpoet"],
            ),
            ArtistProfile(
                name="Portishead",
                community_artists=["Burial"],
            ),
        ])
        result = f.filter_community_artists(profile)
        assert "Ghostpoet" in result
        assert "mb-collaborator" in result["Ghostpoet"].rescue_reason
        assert result["Ghostpoet"].relevance == 1.0

    def test_lb_only_high_share_passes_in_standard_mode(self):
        """LB-only specific artist with share >= solo threshold gets relevance 0.7."""
        settings = get_test_settings(listenbrainz_min_share_for_solo=0.6)
        f = CommunityArtistsFilter(settings)
        # VAAV in only 1 of 2 seeds → specific; no structural verification → lb-density gate
        profile = TasteProfile(artists=[
            ArtistProfile(
                name="Massive Attack",
                community_artists=["VAAV Social Club"],
                community_artists_meta={"VAAV Social Club": 0.7},  # above 0.6 threshold
            ),
            ArtistProfile(
                name="Portishead",
                community_artists=["Burial"],
            ),
        ])
        result = f.filter_community_artists(profile)
        assert "VAAV Social Club" in result
        assert result["VAAV Social Club"].rescue_reason.startswith("lb-density:")
        assert abs(result["VAAV Social Club"].relevance - 0.7) < 1e-9

    def test_lb_only_low_share_stored_with_lb_only_reason(self):
        """LB-only artist with low share is kept but tagged lb-only for discovery gate."""
        settings = get_test_settings(listenbrainz_min_share_for_solo=0.6)
        f = CommunityArtistsFilter(settings)
        # VAAV in only 1 of 2 seeds → specific; share 0.1 < 0.6 → lb-only stored for deep_cuts gate
        profile = TasteProfile(artists=[
            ArtistProfile(
                name="Massive Attack",
                community_artists=["VAAV Social Club"],
                community_artists_meta={"VAAV Social Club": 0.1},  # below 0.6
            ),
            ArtistProfile(
                name="Portishead",
                community_artists=["Burial"],
            ),
        ])
        result = f.filter_community_artists(profile)
        assert "VAAV Social Club" in result
        assert result["VAAV Social Club"].rescue_reason.startswith("lb-only:")
        assert result["VAAV Social Club"].relevance == 0.3
        assert result["VAAV Social Club"].rescued is False


# ---------------------------------------------------------------------------
# Discovery-level gate (candidate_artists_from_profile)
# ---------------------------------------------------------------------------

class TestDiscoveryLBGate:

    def _make_profile_with_fca(self, rescue_reason: str, relevance: float) -> TasteProfile:
        from mamonia.models import FilteredCommunityArtist
        fca = FilteredCommunityArtist(
            relevance=relevance, ubiquity_score=1.0, penalty=0.0,
            contextual_score=0.0, genre_overlap=0.0, matching_genres=[],
            tag_overlap=0.0, matching_tags=[], collaborated=False,
            label_overlap=0.0, matching_labels=[],
            seed_artists=["Massive Attack"],
            rescued="lb-only" not in rescue_reason,
            rescue_reason=rescue_reason,
        )
        return TasteProfile(
            artists=[],
            filtered_community_artists={"VAAV Social Club": fca},
        )

    def test_standard_mode_suppresses_lb_only(self):
        """In standard mode, lb-only candidates are dropped from candidate list."""
        from mamonia.discovery import candidate_artists_from_profile
        profile = self._make_profile_with_fca("lb-only:0.10", 0.3)
        candidates = candidate_artists_from_profile(profile, deep_cuts=False)
        names = [c.name for c in candidates]
        assert "VAAV Social Club" not in names

    def test_deep_cuts_mode_passes_lb_only_above_floor(self):
        """In deep_cuts mode, lb-only with share above floor survives."""
        from mamonia.config import Settings
        from mamonia.discovery import candidate_artists_from_profile
        with tempfile.TemporaryDirectory() as tmpdir:
            settings = Settings(
                data_dir=Path(tmpdir),
                db_path=Path(tmpdir) / "test.db",
                listenbrainz_min_share_for_deep_cuts=0.2,
            )
        profile = self._make_profile_with_fca("lb-only:0.30", 0.3)
        candidates = candidate_artists_from_profile(profile, deep_cuts=True, settings=settings)
        names = [c.name for c in candidates]
        assert "VAAV Social Club" in names

    def test_deep_cuts_mode_drops_lb_only_below_floor(self):
        """In deep_cuts mode, lb-only with share below floor is still dropped."""
        from mamonia.config import Settings
        from mamonia.discovery import candidate_artists_from_profile
        with tempfile.TemporaryDirectory() as tmpdir:
            settings = Settings(
                data_dir=Path(tmpdir),
                db_path=Path(tmpdir) / "test.db",
                listenbrainz_min_share_for_deep_cuts=0.2,
            )
        profile = self._make_profile_with_fca("lb-only:0.05", 0.3)
        candidates = candidate_artists_from_profile(profile, deep_cuts=True, settings=settings)
        names = [c.name for c in candidates]
        assert "VAAV Social Club" not in names

    def test_cross_verified_always_passes_regardless_of_mode(self):
        """Cross-verified candidates are never gated by deep_cuts."""
        from mamonia.discovery import candidate_artists_from_profile
        profile = self._make_profile_with_fca("cross-verified:mb-collaborator", 1.0)
        candidates_std = candidate_artists_from_profile(profile, deep_cuts=False)
        candidates_dc = candidate_artists_from_profile(profile, deep_cuts=True)
        names_std = [c.name for c in candidates_std]
        names_dc = [c.name for c in candidates_dc]
        assert "VAAV Social Club" in names_std
        assert "VAAV Social Club" in names_dc

    def test_source_string_reflects_rescue_reason(self):
        """Source string on candidate accurately mirrors rescue_reason."""
        from mamonia.discovery import candidate_artists_from_profile
        profile = self._make_profile_with_fca("cross-verified:lastfm-similar", 1.0)
        candidates = candidate_artists_from_profile(profile, deep_cuts=False)
        match = next((c for c in candidates if c.name == "VAAV Social Club"), None)
        assert match is not None
        assert "cross-verified" in match.source
