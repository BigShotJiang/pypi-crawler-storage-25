"""Tests for mamonia/pipeline_v2.py — end-to-end v2 pipeline orchestrator."""

from __future__ import annotations

import unittest
from datetime import date, timedelta
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock

from mamonia.models import ArtistProfile, InputTrack, ReleaseRecommendation, TasteProfile, WeightedTerm
from mamonia.pipeline_v2 import (
    _apply_limit_with_fallback,
    _effective_max_tracks,
    _fetch_streaming_provider_candidates,
    _select_scored_releases,
    run_v2_pipeline,
)
from mamonia.progress import PlainTextProgressReporter
from mamonia.scoring_v2 import ScoredRelease
from mamonia.release_discovery import CandidateRelease
from mamonia.storage import Storage

SEED_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
ARTIST_MBID = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
RG_MBID = "c3d4e5f6-a7b8-9012-cdef-123456789012"


def _input_track(
    artist: str = "Massive Attack",
    track: str = "Teardrop",
    album: str = "Mezzanine",
    isrc: str | None = None,
) -> InputTrack:
    return InputTrack(
        artist=artist,
        track=track,
        album=album,
        isrc=isrc,
        source_platform="txt",
    )


def _make_mb_no_results() -> MagicMock:
    mb = MagicMock()
    mb.lookup_recording_by_isrc.return_value = None
    mb.lookup_release_by_upc.return_value = None
    mb.search_recording.return_value = None
    mb.search_artist.return_value = None
    mb.lookup_artist.return_value = None
    mb.get_artist_relations.return_value = []
    mb.browse_release_groups.return_value = []
    return mb


def _make_mb_with_releases() -> MagicMock:
    recent = (date.today() - timedelta(days=30)).isoformat()
    mb = _make_mb_no_results()
    mb.browse_release_groups.return_value = [
        {
            "id": RG_MBID,
            "title": "New Album",
            "primary-type": "Album",
            "secondary-types": [],
            "first-release-date": recent,
        }
    ]
    return mb


class TestRunV2PipelineNoProviders(unittest.TestCase):

    def test_empty_input_returns_empty(self):
        results = run_v2_pipeline(input_tracks=[])
        self.assertEqual(results, [])

    def test_no_providers_no_crash(self):
        tracks = [_input_track()]
        results = run_v2_pipeline(input_tracks=tracks)
        self.assertIsInstance(results, list)

    def test_returns_list_of_release_recommendation(self):
        tracks = [_input_track()]
        results = run_v2_pipeline(input_tracks=tracks)
        for r in results:
            self.assertIsInstance(r, ReleaseRecommendation)


class TestRunV2PipelineWithMocks(unittest.TestCase):

    def _make_lb(self) -> MagicMock:
        lb = MagicMock()
        lb.get_similar_artists.return_value = []
        return lb

    def _make_lf(self) -> MagicMock:
        lf = MagicMock()
        lf.get_top_tags.return_value = [{"name": "trip hop"}]
        lf.get_similar_artists.return_value = []
        return lf

    def test_with_mb_releases_returns_results(self):
        tracks = [_input_track(artist="Massive Attack")]
        mb = _make_mb_with_releases()
        # Make search_recording return a result so canonicalization finds the artist
        mb.search_recording.return_value = {
            "recording_mbid": "rec-mbid-001",
            "release_mbid": "rel-mbid-001",
            "release_group_mbid": "rg-mbid-001",
            "artist_mbid": SEED_MBID,
            "artist_name": "Massive Attack",
        }
        results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb)
        self.assertIsInstance(results, list)

    def test_min_seed_weight_filters_seeds_but_keeps_top_seed_fallback(self):
        tracks = [
            _input_track(artist="Massive Attack", track="Teardrop"),
            _input_track(artist="Portishead", track="Roads"),
        ]
        results = run_v2_pipeline(
            input_tracks=tracks,
            min_seed_weight=1.1,  # clamps to 1.0; fallback should keep at least one seed
        )

        self.assertIsInstance(results, list)

    def test_emit_callable_called(self):
        messages = []
        tracks = [_input_track()]
        run_v2_pipeline(input_tracks=tracks, emit=messages.append)
        self.assertTrue(len(messages) > 0)
        self.assertTrue(any("Canonicalizing input tracks" in m for m in messages))

    def test_pipeline_returns_recommendations(self):
        messages = []
        tracks = [_input_track()]
        results = run_v2_pipeline(input_tracks=tracks, emit=messages.append)
        # Should return a list (possibly empty when no providers available)
        self.assertIsInstance(results, list)

    def test_streaming_provider_fallback_adds_deezer_candidates(self):
        tiers = {"unknown artist": "Tier 1"}
        names = {"unknown artist": "Unknown Artist"}
        deezer = MagicMock()
        deezer.available = True
        deezer.search_artist.return_value = {"id": 123, "name": "Unknown Artist"}
        deezer.browse_artist_albums.return_value = [
            {
                "id": 987,
                "title": "Unknown Album",
                "record_type": "Album",
                "release_date": date.today().isoformat(),
            }
        ]

        candidates = _fetch_streaming_provider_candidates(
            artist_tiers=tiers,
            artist_names=names,
            deezer=deezer,
            tidal=None,
            window_days=183,
            window_start_date=date.today() - timedelta(days=183),
            window_end_date=date.today(),
            emit=lambda *_: None,
        )

        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0].streaming_provider, "deezer")
        self.assertEqual(candidates[0].artist_name, "Unknown Artist")

    def test_streaming_provider_fallback_adds_tidal_candidates(self):
        tiers = {"unknown artist": "Tier 1"}
        names = {"unknown artist": "Unknown Artist"}
        tidal = MagicMock()
        tidal.available = True
        tidal.search_artist_albums.return_value = [
            {
                "id": "567",
                "title": "Unknown Album",
                "release_date": date.today().isoformat(),
                "type": "album",
            }
        ]

        candidates = _fetch_streaming_provider_candidates(
            artist_tiers=tiers,
            artist_names=names,
            deezer=None,
            tidal=tidal,
            window_days=183,
            window_start_date=date.today() - timedelta(days=183),
            window_end_date=date.today(),
            emit=lambda *_: None,
        )

        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0].streaming_provider, "tidal")
        self.assertEqual(candidates[0].artist_name, "Unknown Artist")

    def test_streaming_tidal_diagnostics_only_when_debug_enabled(self):
        tiers = {"unknown artist": "Tier 1"}
        names = {"unknown artist": "Unknown Artist"}
        tidal = MagicMock()
        tidal.available = True
        tidal.search_artist_albums.return_value = [
            {
                "id": "567",
                "title": "Old Album",
                "release_date": (date.today() - timedelta(days=400)).isoformat(),
                "type": "album",
            },
            {
                "id": "568",
                "title": "Fresh Album",
                "release_date": date.today().isoformat(),
                "type": "album",
            },
        ]

        debug_messages: list[str] = []
        _fetch_streaming_provider_candidates(
            artist_tiers=tiers,
            artist_names=names,
            deezer=None,
            tidal=tidal,
            window_days=183,
            window_start_date=date.today() - timedelta(days=183),
            window_end_date=date.today(),
            emit=debug_messages.append,
            debug=True,
        )
        self.assertTrue(any("[Tidal] Found 2 album(s)" in m for m in debug_messages))
        self.assertTrue(any("Old Album" in m and "skipped (before window)" in m for m in debug_messages))
        self.assertTrue(any("Fresh Album" in m and "added" in m for m in debug_messages))

        quiet_messages: list[str] = []
        _fetch_streaming_provider_candidates(
            artist_tiers=tiers,
            artist_names=names,
            deezer=None,
            tidal=tidal,
            window_days=183,
            window_start_date=date.today() - timedelta(days=183),
            window_end_date=date.today(),
            emit=quiet_messages.append,
            debug=False,
        )
        self.assertFalse(any("[Tidal]" in m for m in quiet_messages))
        self.assertTrue(any(m.startswith("[Streaming] ") for m in quiet_messages))

    def test_pipeline_updates_default_progress_stopwatch(self):
        progress_lines: list[str] = []
        progress = PlainTextProgressReporter(emit=progress_lines.append, every_candidates=1)
        tracks = [_input_track()]
        mb = _make_mb_with_releases()
        mb.search_recording.return_value = {
            "recording_mbid": "rec-mbid-001",
            "release_mbid": "rel-mbid-001",
            "release_group_mbid": "rg-mbid-001",
            "artist_mbid": SEED_MBID,
            "artist_name": "Massive Attack",
        }

        run_v2_pipeline(input_tracks=tracks, musicbrainz=mb, progress=progress)

        self.assertTrue(any("elapsed=" in line for line in progress_lines))
        self.assertTrue(any("Canonicalizing input tracks" in line for line in progress_lines))
        self.assertTrue(any("100%" in line or "Massive Attack" in line for line in progress_lines))

    def test_heard_releases_excluded(self):
        tracks = [_input_track()]
        mb = _make_mb_with_releases()
        mb.search_recording.return_value = {
            "artist_mbid": SEED_MBID,
            "artist_name": "Massive Attack",
            "recording_mbid": None,
            "release_mbid": None,
            "release_group_mbid": None,
        }
        results_without_heard = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb)
        results_with_heard = run_v2_pipeline(
            input_tracks=tracks,
            musicbrainz=mb,
            heard_release_group_mbids={RG_MBID},
        )
        # With the release heard, should have fewer or equal results
        self.assertLessEqual(len(results_with_heard), len(results_without_heard))

    def test_pipeline_excludes_heard_release_by_fallback_title_without_mbid_prefilter(self):
        tracks = [_input_track()]
        mb = _make_mb_with_releases()
        mb.search_recording.return_value = {
            "artist_mbid": SEED_MBID,
            "artist_name": "Massive Attack",
            "recording_mbid": None,
            "release_mbid": None,
            "release_group_mbid": None,
        }
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Massive Attack", "New Album", "2026-04-01")
            results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb, storage=storage)
            diag = getattr(storage, "_last_heard_discovery_diagnostics", {})
            storage.close()

        self.assertEqual(results, [])
        self.assertEqual(diag.get("excluded_by_fallback_title"), 1)

    def test_limit_respected(self):
        tracks = [_input_track()]
        mb = _make_mb_no_results()
        results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb, limit=5)
        self.assertLessEqual(len(results), 5)

    def test_label_affinity_profile_adds_tier3_candidate(self):
        tracks = [_input_track(artist="Massive Attack")]
        mb = _make_mb_no_results()
        mb.search_recording.return_value = {
            "artist_mbid": SEED_MBID,
            "artist_name": "Massive Attack",
            "recording_mbid": None,
            "release_mbid": None,
            "release_group_mbid": None,
        }
        mb.search_releases_by_label.return_value = [
            {
                "title": "Label Fresh",
                "date": (date.today() - timedelta(days=20)).isoformat(),
                "artist-credit": [{"name": "Label Artist", "artist": {"id": ARTIST_MBID, "name": "Label Artist"}}],
                "release-group": {
                    "id": RG_MBID,
                    "title": "Label Fresh",
                    "primary-type": "Album",
                    "secondary-types": [],
                    "first-release-date": (date.today() - timedelta(days=20)).isoformat(),
                },
            }
        ]
        profile = TasteProfile(
            artists=[ArtistProfile(name="Massive Attack", labels=["Important Label"])],
            top_labels=[WeightedTerm(name="Important Label", weight=10)],
        )

        results = run_v2_pipeline(input_tracks=tracks, musicbrainz=mb, profile=profile)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "Label Fresh")
        self.assertEqual(results[0].tier, "Tier 3")
        self.assertEqual(results[0].label, "Important Label")
        self.assertIn("label_affinity", results[0].explanation["connection_types"])


class TestApplyLimitWithFallback(unittest.TestCase):

    def _make_scored(
        self,
        score: float,
        *,
        rg_mbid: str | None = None,
        artist_mbid: str | None = None,
        artist_name: str = "Artist",
        seed_artist: str = "Seed Artist",
        tier: str = "Tier 2A",
        relation_type: str = "collaboration",
        label: str | None = None,
    ) -> ScoredRelease:
        return ScoredRelease(
            candidate=CandidateRelease(
                release_group_mbid=rg_mbid or f"rg-{score:.0f}",
                artist_mbid=artist_mbid or ARTIST_MBID,
                artist_name=artist_name,
                title=f"Release {rg_mbid or int(score)}",
                release_date="2025-03-01",
                primary_type="album",
                label=label,
                tier=tier,
            ),
            base_score=score / 100,
            final_score=score / 100,
            score_normalized=score,
            confidence_label="High" if score >= 75 else ("Medium" if score >= 40 else "Low"),
            explanation={
                "seed_artists": [seed_artist],
                "connection_types": [relation_type],
                "tier": tier,
                "source_reliabilities": [1.0],
            },
        )

    def test_high_confidence_filled_first(self):
        scored = [self._make_scored(s) for s in [90.0, 80.0, 50.0, 30.0]]
        results = _apply_limit_with_fallback(scored, limit=2, deep_cuts=False, emit=lambda *_: None)
        self.assertEqual(len(results), 2)
        # Both should come from high scores (≥75)
        for r in results:
            self.assertGreaterEqual(r.score_normalized, 75)

    def test_fallback_to_medium_when_high_exhausted(self):
        scored = [self._make_scored(s) for s in [85.0, 55.0, 45.0]]
        results = _apply_limit_with_fallback(scored, limit=3, deep_cuts=False, emit=lambda *_: None)
        self.assertEqual(len(results), 3)
        scores = [r.score_normalized for r in results]
        self.assertIn(85.0, scores)
        self.assertIn(55.0, scores)

    def test_low_excluded_without_deep_cuts(self):
        scored = [self._make_scored(s) for s in [25.0, 15.0]]
        results = _apply_limit_with_fallback(scored, limit=10, deep_cuts=False, emit=lambda *_: None)
        self.assertEqual(results, [])

    def test_low_included_with_deep_cuts(self):
        scored = [self._make_scored(s) for s in [25.0, 15.0]]
        results = _apply_limit_with_fallback(scored, limit=10, deep_cuts=True, emit=lambda *_: None)
        self.assertEqual(len(results), 2)

    def test_limit_caps_total_results(self):
        scored = [self._make_scored(s) for s in [90.0, 85.0, 80.0, 55.0, 50.0]]
        results = _apply_limit_with_fallback(scored, limit=3, deep_cuts=False, emit=lambda *_: None)
        self.assertLessEqual(len(results), 3)

    def test_fallback_notice_emitted(self):
        messages = []
        scored = [self._make_scored(90.0), self._make_scored(50.0)]
        _apply_limit_with_fallback(scored, limit=2, deep_cuts=False, emit=messages.append)
        self.assertTrue(any("Medium" in m for m in messages))

    def test_no_notice_when_only_medium_results(self):
        messages = []
        scored = [self._make_scored(55.0)]
        _apply_limit_with_fallback(scored, limit=5, deep_cuts=False, emit=messages.append)
        # No high results → no fallback notice expected
        self.assertFalse(any("Medium-confidence" in m for m in messages))

    def test_returns_release_recommendations(self):
        scored = [self._make_scored(85.0)]
        results = _apply_limit_with_fallback(scored, limit=5, deep_cuts=False, emit=lambda *_: None)
        self.assertIsInstance(results[0], ReleaseRecommendation)

    def test_balanced_uses_confidence_quotas(self):
        scored = (
            [self._make_scored(99.0 - i, rg_mbid=f"high-{i}") for i in range(20)]
            + [self._make_scored(60.0 - i, rg_mbid=f"medium-{i}") for i in range(5)]
            + [self._make_scored(30.0 - i, rg_mbid=f"low-{i}") for i in range(5)]
        )

        results = _select_scored_releases(scored, limit=16, deep_cuts=False, balanced=True, emit=lambda *_: None)

        self.assertEqual(len(results), 16)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "High"), 13)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "Medium"), 2)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "Low"), 1)

    def test_balanced_applies_diversity_pressure_inside_score_bands(self):
        same_source = [
            self._make_scored(
                99.0 - i,
                rg_mbid=f"same-{i}",
                seed_artist="Same Seed",
                tier="Tier 2A",
                relation_type="collaboration",
                label="Same Label",
            )
            for i in range(6)
        ]
        alternatives = [
            self._make_scored(94.0, rg_mbid="alt-1", seed_artist="Alt Seed 1", tier="Tier 3", relation_type="lastfm_similar", label="Alt Label 1"),
            self._make_scored(93.0, rg_mbid="alt-2", seed_artist="Alt Seed 2", tier="Tier 2B", relation_type="listenbrainz_similar", label="Alt Label 2"),
        ]

        results = _select_scored_releases(same_source + alternatives, limit=4, deep_cuts=False, balanced=True, emit=lambda *_: None)

        self.assertTrue(any(r.mb_release_group_id in {"alt-1", "alt-2"} for r in results))

    def test_deep_diverse_can_fill_remaining_slots_with_low_confidence(self):
        scored = [
            self._make_scored(90.0, rg_mbid="high-1"),
            self._make_scored(50.0, rg_mbid="medium-1"),
            self._make_scored(30.0, rg_mbid="low-1"),
            self._make_scored(20.0, rg_mbid="low-2"),
        ]

        results = _select_scored_releases(scored, limit=4, deep_cuts=True, balanced=True, emit=lambda *_: None)

        self.assertEqual(len(results), 4)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "Low"), 2)

    def test_balanced_fills_from_low_when_high_medium_exhausted(self):
        """When the high/medium pool is exhausted, balanced mode falls back to
        low-confidence candidates so the requested limit is actually honored.

        The deep_cuts flag only changes ordering (low-first prioritization), not
        eligibility — letting users get fewer recommendations than they asked
        for when candidates exist would surprise them.
        """
        scored = [
            self._make_scored(90.0, rg_mbid="high-1"),
            self._make_scored(50.0, rg_mbid="medium-1"),
            self._make_scored(30.0, rg_mbid="low-1"),
            self._make_scored(20.0, rg_mbid="low-2"),
            self._make_scored(19.0, rg_mbid="low-3"),
        ]

        results = _select_scored_releases(scored, limit=16, deep_cuts=False, balanced=True, emit=lambda *_: None)

        # All 5 candidates should be used since limit (16) exceeds pool size.
        self.assertEqual(len(results), 5)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "High"), 1)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "Medium"), 1)
        self.assertEqual(sum(1 for r in results if r.confidence_label == "Low"), 3)

    def test_label_affinity_does_not_dominate_balanced_results(self):
        label_affinity = [
            self._make_scored(
                99.0 - i,
                rg_mbid=f"label-{i}",
                seed_artist="Seed Artist",
                tier="Tier 3",
                relation_type="label_affinity",
                label="Important Label",
            )
            for i in range(6)
        ]
        graph_results = [
            self._make_scored(94.0, rg_mbid="graph-1", seed_artist="Graph Seed 1", tier="Tier 2A", relation_type="collaboration", label="Graph Label 1"),
            self._make_scored(93.0, rg_mbid="graph-2", seed_artist="Graph Seed 2", tier="Tier 2B", relation_type="member_of", label="Graph Label 2"),
            self._make_scored(92.0, rg_mbid="graph-3", seed_artist="Graph Seed 3", tier="Tier 3", relation_type="listenbrainz_similar", label="Graph Label 3"),
        ]

        results = _select_scored_releases(label_affinity + graph_results, limit=5, deep_cuts=False, balanced=True, emit=lambda *_: None)

        label_count = sum(1 for r in results if "label_affinity" in r.explanation["connection_types"])
        self.assertLess(label_count, len(results))

    def test_listenbrainz_heavy_pool_does_not_fully_dominate_balanced_results(self):
        lb_heavy = [
            self._make_scored(
                98.0 - i,
                rg_mbid=f"lb-{i}",
                seed_artist="LB Seed",
                tier="Tier 3",
                relation_type="listenbrainz_similar",
                label="LB Label",
            )
            for i in range(8)
        ]
        non_lb = [
            self._make_scored(93.0, rg_mbid="graph-a", seed_artist="Graph Seed A", tier="Tier 2A", relation_type="collaboration", label="Graph A"),
            self._make_scored(92.5, rg_mbid="graph-b", seed_artist="Graph Seed B", tier="Tier 2B", relation_type="member_of", label="Graph B"),
        ]

        results = _select_scored_releases(lb_heavy + non_lb, limit=5, deep_cuts=False, balanced=True, emit=lambda *_: None)
        lb_count = sum(1 for r in results if "listenbrainz_similar" in r.explanation["connection_types"])
        self.assertLess(lb_count, len(results))


class TestFrequentArtistPenalty(unittest.TestCase):

    def test_effective_max_tracks_zero_stays_unlimited(self):
        self.assertEqual(
            _effective_max_tracks(0, release_count=8, penalize_frequent_artists=True),
            0,
        )

    def test_effective_max_tracks_unchanged_when_disabled(self):
        self.assertEqual(
            _effective_max_tracks(3, release_count=5, penalize_frequent_artists=False),
            3,
        )

    def test_effective_max_tracks_for_three_or_four_releases(self):
        self.assertEqual(
            _effective_max_tracks(3, release_count=3, penalize_frequent_artists=True),
            2,
        )
        self.assertEqual(
            _effective_max_tracks(2, release_count=4, penalize_frequent_artists=True),
            1,
        )

    def test_effective_max_tracks_for_five_plus_releases_never_below_one(self):
        self.assertEqual(
            _effective_max_tracks(3, release_count=5, penalize_frequent_artists=True),
            1,
        )
        self.assertEqual(
            _effective_max_tracks(1, release_count=8, penalize_frequent_artists=True),
            1,
        )


class TestEnrichment(unittest.TestCase):
    """Tests for track enrichment in the v2 pipeline."""

    def test_enrich_recommendation_tracks_with_spotify(self):
        """Test that enrich_recommendation_tracks works with Spotify."""
        from mamonia.enrichment import enrich_recommendation_tracks
        from mamonia.models import ReleaseRecommendation, ReleaseTrack

        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[],
        )
        sp = MagicMock()
        sp.representative_tracks.return_value = (
            "album-id-123",
            "spotify:album:abc123",
            [
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    spotify_track_id="spotify:track:abc123",
                    spotify_album_id="spotify:album:abc123",
                    isrc="US1234567890",
                    isrc_source="spotify",
                    resolution_source="spotify_album_tracklist",
                ),
            ],
        )
        sp.backfill_release_tracks = MagicMock(
            side_effect=lambda title, tracks, **kwargs: tracks
        )
        enrich_recommendation_tracks(rec, spotify=sp, max_tracks=3)
        self.assertGreater(len(rec.tracks), 0)
        self.assertEqual(rec.tracks[0].spotify_track_id, "spotify:track:abc123")

    def test_enrich_recommendation_tracks_with_musicbrainz(self):
        """Test that enrich_recommendation_tracks works with MusicBrainz."""
        from mamonia.enrichment import enrich_recommendation_tracks
        from mamonia.models import ReleaseRecommendation, ReleaseTrack

        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[],
        )
        mb = MagicMock()
        mb.release_tracks_for_group.return_value = [
            ReleaseTrack(
                title="Track 1",
                artists="Test Artist",
                track_number=1,
                duration=200000,
                isrc="US1234567890",
            ),
        ]
        enrich_recommendation_tracks(rec, musicbrainz=mb, max_tracks=3)
        self.assertGreater(len(rec.tracks), 0)
        self.assertEqual(rec.tracks[0].isrc, "US1234567890")
        self.assertIn("musicbrainz", rec.tracks[0].resolution_source or "")

    def test_enrich_recommendation_tracks_with_isrc_resolver(self):
        """Test that enrich_recommendation_tracks works with ISRC resolver."""
        from mamonia.enrichment import enrich_recommendation_tracks
        from mamonia.models import ReleaseRecommendation, ReleaseTrack

        rec = ReleaseRecommendation(
            artist="Test Artist",
            title="Test Album",
            mb_release_group_id=RG_MBID,
            tracks=[
                ReleaseTrack(
                    title="Track 1",
                    artists="Test Artist",
                    track_number=1,
                    isrc=None,
                ),
            ],
        )
        isrc_resolver = MagicMock()
        isrc_resolver.resolve_track.return_value = MagicMock(
            resolved=True,
            isrc="US1234567890",
            provider="tidal",
        )
        enrich_recommendation_tracks(rec, isrc_resolver=isrc_resolver, max_tracks=3)
        self.assertEqual(rec.tracks[0].isrc, "US1234567890")
        self.assertEqual(rec.tracks[0].isrc_source, "tidal")

    def test_spotify_enrichment_budget_can_skip_rescue_and_keep_mb_tracks(self):
        from mamonia.enrichment import enrich_recommendation_tracks
        from mamonia.models import ReleaseRecommendation, ReleaseTrack

        old_budget = os.environ.get("MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN")
        os.environ["MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN"] = "1"
        try:
            rec = ReleaseRecommendation(
                artist="Test Artist",
                title="Test Album",
                mb_release_group_id=RG_MBID,
                tracks=[],
            )
            sp = MagicMock()
            sp.representative_tracks.return_value = (None, None, [])
            sp.backfill_release_tracks = MagicMock(side_effect=lambda title, tracks, **kwargs: tracks)
            sp.rate_limit_warnings = []
            mb = MagicMock()
            mb.release_tracks_for_group.return_value = [
                ReleaseTrack(title="Track 1", artists="Test Artist", track_number=1, isrc=None)
            ]

            enrich_recommendation_tracks(rec, spotify=sp, musicbrainz=mb, max_tracks=3)

            self.assertGreaterEqual(len(rec.tracks), 1)
            self.assertEqual(sp.representative_tracks.call_count, 1)
            state = getattr(sp, "_mamonia_enrichment_state")
            self.assertTrue(state["budget_exhausted"])
        finally:
            if old_budget is None:
                os.environ.pop("MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN", None)
            else:
                os.environ["MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN"] = old_budget

    def test_disable_rescue_after_429_trips_and_suppresses_second_representative_lookup(self):
        from mamonia.enrichment import enrich_recommendation_tracks
        from mamonia.models import ReleaseRecommendation, ReleaseTrack

        old_flag = os.environ.get("MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429")
        os.environ["MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429"] = "true"
        try:
            rec = ReleaseRecommendation(
                artist="Test Artist",
                title="Test Album",
                mb_release_group_id=RG_MBID,
                tracks=[],
            )
            sp = MagicMock()
            sp.representative_tracks.side_effect = RuntimeError("429")
            sp.backfill_release_tracks = MagicMock(side_effect=lambda title, tracks, **kwargs: tracks)
            sp.rate_limit_warnings = [MagicMock(error_kind="rate_limited")]
            mb = MagicMock()
            mb.release_tracks_for_group.return_value = [
                ReleaseTrack(title="Track 1", artists="Test Artist", track_number=1, isrc=None)
            ]

            enrich_recommendation_tracks(rec, spotify=sp, musicbrainz=mb, max_tracks=3)

            state = getattr(sp, "_mamonia_enrichment_state")
            self.assertTrue(state["rescue_disabled_due_to_429"])
            self.assertEqual(sp.representative_tracks.call_count, 1)
        finally:
            if old_flag is None:
                os.environ.pop("MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429", None)
            else:
                os.environ["MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429"] = old_flag


if __name__ == "__main__":
    unittest.main()
