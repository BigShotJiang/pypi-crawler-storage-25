"""Tests for variant handling utilities — suffix stripping, scoring, content detection."""

from __future__ import annotations

import pytest

from mamonia.storage import canonical_release_key
from mamonia.utils import content_variant_type, normalize_variant_title, strip_variant_suffixes, variant_score
from mamonia.workflow import discovery_mode_to_flags


# ---------------------------------------------------------------------------
# canonical_release_key
# ---------------------------------------------------------------------------

class TestCanonicalReleaseKey:
    def test_with_label_and_catalog(self) -> None:
        key = canonical_release_key(
            artist="Test Artist", title="Test Album", release_date="2026-01-01",
            label="Test Label", catalog_number="CAT123",
        )
        assert "label:test label" in key
        assert "catalog:cat123" in key

    def test_with_label_only(self) -> None:
        key = canonical_release_key(
            artist="Test Artist", title="Test Album", release_date="2026-01-01",
            label="Test Label",
        )
        assert "label:test label" in key
        assert "catalog:" not in key

    def test_without_label_or_catalog(self) -> None:
        key = canonical_release_key(
            artist="Test Artist", title="Test Album", release_date="2026-01-01",
        )
        assert "label:" not in key
        assert "catalog:" not in key


# ---------------------------------------------------------------------------
# strip_variant_suffixes — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("title,expected", [
    ("Album (Remastered)", "Album"),
    ("Album - Remastered", "Album"),
    ("Album (Remastered 2024)", "Album"),
    ("Album (Deluxe Edition)", "Album"),
    ("Album - Deluxe Edition", "Album"),
    ("Album (Deluxe)", "Album"),
    ("Album (25th Anniversary Edition)", "Album"),
    ("Album - 10th Anniversary", "Album"),
    ("Album (Deluxe Edition) (Remastered)", "Album"),
])
def test_strip_variant_suffixes(title: str, expected: str) -> None:
    assert strip_variant_suffixes(title) == expected


# ---------------------------------------------------------------------------
# variant_score — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("title,expected", [
    ("Album (Remastered)", 2),
    ("Album - Remastered", 2),
    ("Album Remastered", 2),
    ("Album (Deluxe Edition)", 1),
    ("Album - Deluxe", 1),
    ("Album Deluxe", 1),
    ("Album", 0),
    ("Album (Standard)", 0),
])
def test_variant_score(title: str, expected: int) -> None:
    assert variant_score(title) == expected


def test_variant_score_remastered_beats_deluxe() -> None:
    assert variant_score("Album (Remastered)") > variant_score("Album (Deluxe Edition)")
    assert variant_score("Album Remastered") > variant_score("Album Deluxe")


# ---------------------------------------------------------------------------
# normalize_variant_title
# ---------------------------------------------------------------------------

def test_normalize_ignores_variants() -> None:
    base = "Test Album"
    base_norm = normalize_variant_title(base)
    assert normalize_variant_title(f"{base} (Remastered)") == base_norm
    assert normalize_variant_title(f"{base} - Deluxe Edition") == base_norm
    assert normalize_variant_title(f"{base} (Anniversary Edition)") == base_norm


def test_normalize_preserves_non_variants() -> None:
    assert normalize_variant_title("Album One") != normalize_variant_title("Album Two")


# ---------------------------------------------------------------------------
# content_variant_type — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("title,expected", [
    ("Album (Explicit)", "explicit"),
    ("Album - Explicit Version", "explicit"),
    ("Album Explicit", "explicit"),
    ("Album (Clean)", "clean"),
    ("Album - Clean Version", "clean"),
    ("Album Clean", "clean"),
    ("Album", None),
    ("Album (Deluxe)", None),
    ("Album Remastered", None),
])
def test_content_variant_type(title: str, expected: str | None) -> None:
    assert content_variant_type(title) == expected


# ---------------------------------------------------------------------------
# discovery_mode_to_flags — parametrized
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("mode,deep_cuts,tiered", [
    ("standard", False, False),
    ("top_first", False, False),
    ("deep_cuts", True, False),
    ("balanced", False, True),
    ("deep_diverse", True, True),
    ("invalid", False, False),
])
def test_discovery_mode_to_flags(mode: str, deep_cuts: bool, tiered: bool) -> None:
    dc, tr = discovery_mode_to_flags(mode)
    assert dc == deep_cuts
    assert tr == tiered
