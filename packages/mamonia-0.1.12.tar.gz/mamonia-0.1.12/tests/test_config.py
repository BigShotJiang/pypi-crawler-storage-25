from __future__ import annotations

import os
import stat
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from mamonia.config import (
    Settings,
    canonical_data_dir_for_os,
    canonical_db_path_for_os,
    credential_file_permission_status,
    harden_secret_file_permissions,
    is_valid_spotify_redirect_uri,
    _ensure_env_file,
    load_settings,
    save_env_credential,
)


class SettingsTests(unittest.TestCase):
    @staticmethod
    def _normalized_path_str(path: Path) -> str:
        return str(path).replace("/", "\\")
    def test_placeholder_musicbrainz_contact_warns_without_blocking(self) -> None:
        settings = Settings(data_dir=Path(".mamonia"), db_path=Path(".mamonia/mamonia.sqlite"))

        self.assertTrue(settings.mb_contact_is_placeholder)
        self.assertIn("MB_CONTACT_EMAIL", settings.warnings()[0])

    def test_spotify_and_lastfm_status_are_contextual(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            spotify_client_id="id",
            spotify_client_secret="secret",
            lastfm_api_key="lastfm",
            mb_contact="tester@example.com",
        )

        self.assertTrue(settings.spotify_configured)
        self.assertTrue(settings.spotify_playlist_configured)
        self.assertTrue(settings.lastfm_configured)
        self.assertEqual(settings.warnings(), [])

    def test_spotify_playlist_configured_does_not_require_client_secret(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            spotify_client_id="id",
            spotify_client_secret="",
            spotify_redirect_uri="http://127.0.0.1:8888/callback",
            mb_contact="tester@example.com",
        )

        self.assertFalse(settings.spotify_configured)
        self.assertTrue(settings.spotify_playlist_configured)

    def test_spotify_redirect_uri_warning_allows_explicit_loopback_http(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            spotify_client_id="id",
            spotify_client_secret="secret",
            spotify_redirect_uri="http://127.0.0.1:8888/callback",
            mb_contact="tester@example.com",
        )

        self.assertEqual(settings.warnings(), [])

    def test_spotify_redirect_uri_warning_rejects_non_loopback_http(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            spotify_client_id="id",
            spotify_client_secret="secret",
            spotify_redirect_uri="http://example.com/callback",
            mb_contact="tester@example.com",
        )

        self.assertIn("http://127.0.0.1", settings.warnings()[0])

    def test_spotify_redirect_uri_validation_accepts_https_and_loopback(self) -> None:
        self.assertTrue(is_valid_spotify_redirect_uri("https://example.com/callback"))
        self.assertTrue(is_valid_spotify_redirect_uri("http://127.0.0.1:8888/callback"))
        self.assertFalse(is_valid_spotify_redirect_uri("http://localhost:8888/callback"))
        self.assertFalse(is_valid_spotify_redirect_uri("https://localhost:8888/callback"))
        self.assertFalse(is_valid_spotify_redirect_uri("http://[::1]:8888/callback"))
        self.assertFalse(is_valid_spotify_redirect_uri("http://example.com/callback"))
        self.assertFalse(is_valid_spotify_redirect_uri("https://*.example.com/callback"))

    def test_tidal_configured_no_longer_requires_username_password(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            tidal_client_id="tidal-id",
            tidal_client_secret="tidal-secret",
        )

        self.assertTrue(settings.tidal_configured)

    def test_provider_cache_ttls_are_clamped_to_supported_ranges(self) -> None:
        settings = Settings(
            data_dir=Path(".mamonia"),
            db_path=Path(".mamonia/mamonia.sqlite"),
            spotify_cache_ttl_days=99,
            spotify_cache_miss_ttl_days=0,
            musicbrainz_cache_ttl_days=2,
            lastfm_cache_ttl_days=30,
        )

        self.assertEqual(settings.spotify_cache_ttl_seconds, 99 * 24 * 60 * 60)
        self.assertEqual(settings.spotify_cache_miss_ttl_seconds, 1 * 24 * 60 * 60)
        self.assertEqual(settings.musicbrainz_cache_ttl_seconds, 2 * 24 * 60 * 60)
        self.assertEqual(settings.lastfm_cache_ttl_seconds, 30 * 24 * 60 * 60)

    def test_load_settings_makes_default_paths_absolute(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                with (
                    patch("mamonia.config.system", return_value="Linux"),
                    patch("mamonia.config._load_dotenv_from_path"),
                    patch("mamonia.config._assert_writable_directory"),
                    patch.dict(os.environ, {"HOME": str(Path(tmp) / "home")}, clear=True),
                ):
                    settings = load_settings()
                    expected_base = (Path(tmp) / "home" / ".local" / "state" / "mamonia").absolute()
            finally:
                os.chdir(cwd)

        self.assertTrue(settings.data_dir.is_absolute())
        self.assertTrue(settings.db_path.is_absolute())
        self.assertEqual(settings.data_dir, expected_base)
        self.assertEqual(settings.db_path, expected_base / "mamonia.sqlite")

    def test_load_settings_makes_relative_env_paths_absolute(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                with patch.dict(os.environ, {"MAMONIA_HOME": "home", "MAMONIA_DB": "db.sqlite"}, clear=True):
                    settings = load_settings()
                    expected_base = Path.cwd()
            finally:
                os.chdir(cwd)

        self.assertEqual(settings.data_dir, expected_base / "home")
        self.assertEqual(settings.db_path, expected_base / "db.sqlite")

    def test_load_settings_uses_windows_localappdata_default(self) -> None:
        with (
            patch("mamonia.config.system", return_value="Windows"),
            patch("mamonia.config._load_dotenv_from_path"),
            patch("mamonia.config._assert_writable_directory"),
            patch.dict(
                os.environ,
                {"LOCALAPPDATA": r"C:\Users\tester\AppData\Local"},
                clear=True,
            ),
        ):
            settings = load_settings()

        self.assertEqual(self._normalized_path_str(settings.data_dir), r"C:\Users\tester\AppData\Local\Mamonia")
        self.assertEqual(self._normalized_path_str(settings.db_path), r"C:\Users\tester\AppData\Local\Mamonia\mamonia.sqlite")

    def test_load_settings_uses_macos_default(self) -> None:
        with (
            patch("mamonia.config.system", return_value="Darwin"),
            patch("mamonia.config._load_dotenv_from_path"),
            patch("mamonia.config._assert_writable_directory"),
            patch.dict(os.environ, {"HOME": "/Users/tester"}, clear=True),
        ):
            settings = load_settings()

        expected = Path("/Users/tester/Library/Application Support/Mamonia").absolute()
        self.assertEqual(settings.data_dir, expected)
        self.assertEqual(settings.db_path, expected / "mamonia.sqlite")

    def test_load_settings_uses_xdg_state_home_on_linux(self) -> None:
        with (
            patch("mamonia.config.system", return_value="Linux"),
            patch("mamonia.config._load_dotenv_from_path"),
            patch("mamonia.config._assert_writable_directory"),
            patch.dict(
                os.environ,
                {"XDG_STATE_HOME": "/tmp/xdg-state"},
                clear=True,
            ),
        ):
            settings = load_settings()

        self.assertEqual(settings.data_dir, Path("/tmp/xdg-state/mamonia").absolute())
        self.assertEqual(settings.db_path, Path("/tmp/xdg-state/mamonia/mamonia.sqlite").absolute())

    def test_canonical_paths_are_cross_platform_and_ignore_mamonia_home_override(self) -> None:
        with (
            patch("mamonia.config.system", return_value="Windows"),
            patch.dict(
                os.environ,
                {
                    "LOCALAPPDATA": r"C:\Users\tester\AppData\Local",
                    "MAMONIA_HOME": r"D:\custom\mamonia",
                    "MAMONIA_DB": r"D:\custom\custom.sqlite",
                },
                clear=True,
            ),
        ):
            self.assertEqual(self._normalized_path_str(canonical_data_dir_for_os()), r"C:\Users\tester\AppData\Local\Mamonia")
            self.assertEqual(self._normalized_path_str(canonical_db_path_for_os()), r"C:\Users\tester\AppData\Local\Mamonia\mamonia.sqlite")

        with (
            patch("mamonia.config.system", return_value="Darwin"),
            patch.dict(
                os.environ,
                {"HOME": "/Users/tester", "MAMONIA_HOME": "/tmp/custom"},
                clear=True,
            ),
        ):
            self.assertEqual(
                canonical_data_dir_for_os(),
                Path("/Users/tester/Library/Application Support/Mamonia").absolute(),
            )
            self.assertEqual(
                canonical_db_path_for_os(),
                Path("/Users/tester/Library/Application Support/Mamonia/mamonia.sqlite").absolute(),
            )

        with (
            patch("mamonia.config.system", return_value="Linux"),
            patch.dict(
                os.environ,
                {"XDG_STATE_HOME": "/tmp/xdg-state", "MAMONIA_HOME": "/tmp/custom"},
                clear=True,
            ),
        ):
            self.assertEqual(canonical_data_dir_for_os(), Path("/tmp/xdg-state/mamonia").absolute())
            self.assertEqual(canonical_db_path_for_os(), Path("/tmp/xdg-state/mamonia/mamonia.sqlite").absolute())

    def test_load_settings_is_stable_across_working_directories(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            d1 = root / "a"
            d2 = root / "b"
            d1.mkdir(parents=True, exist_ok=True)
            d2.mkdir(parents=True, exist_ok=True)
            cwd = Path.cwd()
            try:
                with (
                    patch("mamonia.config.system", return_value="Linux"),
                    patch("mamonia.config._load_dotenv_from_path"),
                    patch("mamonia.config._assert_writable_directory"),
                    patch.dict(os.environ, {"XDG_STATE_HOME": "/tmp/xdg-state"}, clear=True),
                ):
                    os.chdir(d1)
                    settings_a = load_settings()
                    os.chdir(d2)
                    settings_b = load_settings()
            finally:
                os.chdir(cwd)

        self.assertEqual(settings_a.data_dir, settings_b.data_dir)
        self.assertEqual(settings_a.db_path, settings_b.db_path)

    def test_managed_env_under_mamonia_home_overrides_cwd_env_when_legacy_fallback_enabled(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            (tmp_path / ".env").write_text(
                f"MAMONIA_HOME={home}\nLASTFM_API_KEY=cwd-key\n",
                encoding="utf-8",
            )
            (home / ".env").write_text("LASTFM_API_KEY=managed-key\n", encoding="utf-8")

            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                with patch.dict(os.environ, {"MAMONIA_LEGACY_CWD_ENV_FALLBACK": "true"}, clear=True):
                    settings = load_settings()
            finally:
                os.chdir(cwd)

        self.assertEqual(settings.data_dir, home)
        self.assertEqual(settings.lastfm_api_key, "cwd-key")

    def test_default_ignores_cwd_env_without_legacy_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            (tmp_path / ".env").write_text("LASTFM_API_KEY=cwd-key\n", encoding="utf-8")
            cwd = Path.cwd()
            try:
                os.chdir(tmp)
                with (
                    patch.dict(os.environ, {}, clear=True),
                    patch("mamonia.config._assert_writable_directory"),
                    patch("mamonia.config._load_dotenv_from_path"),
                ):
                    settings = load_settings()
            finally:
                os.chdir(cwd)
        self.assertEqual(settings.lastfm_api_key, "")

    def test_ensure_env_file_copies_env_example_when_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            env_path = home / ".env"
            env_example = Path(__file__).parent.parent / ".env.example"
            if env_example.exists():
                _ensure_env_file(env_path)
                self.assertTrue(env_path.exists())
                content = env_path.read_text(encoding="utf-8")
                self.assertIn("SPOTIPY_CLIENT_ID", content)
                self.assertIn("LASTFM_API_KEY", content)

    def test_ensure_env_file_creates_empty_file_when_no_example(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            env_path = home / ".env"
            # Temporarily hide .env.example if it exists
            example_path = Path(__file__).parent.parent / ".env.example"
            example_backup = None
            if example_path.exists():
                example_backup = example_path.read_text(encoding="utf-8")
                example_path.unlink()
            try:
                _ensure_env_file(env_path)
                self.assertTrue(env_path.exists())
                self.assertEqual(env_path.read_text(encoding="utf-8"), "")
            finally:
                if example_backup and not example_path.exists():
                    example_path.write_text(example_backup, encoding="utf-8")

    def test_ensure_env_file_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir(parents=True, exist_ok=True)
            env_path = home / ".env"
            env_path.write_text("EXISTING=value", encoding="utf-8")
            if os.name != "nt":
                env_path.chmod(0o644)
            _ensure_env_file(env_path)
            self.assertEqual(env_path.read_text(encoding="utf-8"), "EXISTING=value")
            if os.name != "nt":
                self.assertEqual(stat.S_IMODE(env_path.stat().st_mode), 0o600)

    def test_save_env_credential_creates_env_from_example(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            env_path = home / ".env"
            env_example = Path(__file__).parent.parent / ".env.example"
            if env_example.exists():
                save_env_credential(env_path, "TEST_KEY", "test_value")
                self.assertTrue(env_path.exists())
                content = env_path.read_text(encoding="utf-8")
                self.assertIn("TEST_KEY=test_value", content)
                if os.name != "nt":
                    self.assertEqual(stat.S_IMODE(env_path.stat().st_mode), 0o600)

    def test_secret_file_permission_status_reports_too_broad_and_ok(self) -> None:
        if os.name == "nt":
            self.skipTest("POSIX file modes are not portable on Windows")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / ".env"
            path.write_text("KEY=value\n", encoding="utf-8")
            path.chmod(0o644)

            self.assertEqual(credential_file_permission_status(path), "too broad")
            self.assertTrue(harden_secret_file_permissions(path))
            self.assertEqual(credential_file_permission_status(path), "OK")
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)


if __name__ == "__main__":
    unittest.main()
