from __future__ import annotations

import re
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
BASELINE = "661 passed, 1 skipped, 1 warning"
STALE_BASELINE = "640 passed, 2 skipped, 1 warning"


def _read(path: str) -> str:
    return (REPO_ROOT / path).read_text(encoding="utf-8")


def test_no_stale_baseline_in_operational_docs() -> None:
    operational = list((REPO_ROOT / "docs").glob("*.md")) + list((REPO_ROOT / ".ai").glob("*.md")) + [REPO_ROOT / "README.md"]
    for path in operational:
        text = path.read_text(encoding="utf-8")
        assert STALE_BASELINE not in text, f"Stale baseline in {path}"


def test_baseline_present_in_canonical_and_mirror_docs() -> None:
    required = [
        "docs/README.md",
        "docs/UNIFIED_INDEX.md",
        "docs/testing.md",
        "docs/system-context.md",
        "docs/PROJECT_MEMORY.md",
        "docs/agents.md",
        ".ai/README.md",
        ".ai/TESTING.md",
        ".ai/MEMORY.md",
        ".ai/AGENTS.md",
    ]
    for rel in required:
        assert BASELINE in _read(rel), f"Missing baseline '{BASELINE}' in {rel}"


def test_ai_mirror_is_active_not_legacy_in_core_ai_docs() -> None:
    for rel in (".ai/README.md", ".ai/AGENTS.md", ".ai/TESTING.md", ".ai/MEMORY.md"):
        text = _read(rel).lower()
        assert "legacy redirect" not in text, f"{rel} still marked as legacy redirect"
        assert "deprecated." not in text, f"{rel} still marked deprecated"


def test_mamonia_home_defaults_documented_cross_platform() -> None:
    docs_text = _read("docs/dependency-map.md")
    ai_text = _read(".ai/DEPENDENCY_MAP.md")
    for text, label in ((docs_text, "docs/dependency-map.md"), (ai_text, ".ai/DEPENDENCY_MAP.md")):
        assert "LOCALAPPDATA" in text, f"Windows default missing in {label}"
        assert "Application Support" in text, f"macOS default missing in {label}"
        assert "XDG_STATE_HOME" in text, f"Linux default missing in {label}"


def test_testing_truthfulness_rule_documented() -> None:
    assert "never claim a green baseline" in _read("docs/testing.md").lower()
    assert "never claim a green baseline" in _read("docs/system-context.md").lower()


def test_internal_markdown_links_resolve_for_docs_and_ai() -> None:
    link_pattern = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
    for folder in ("docs", ".ai"):
        for path in (REPO_ROOT / folder).glob("*.md"):
            text = path.read_text(encoding="utf-8")
            for raw_target in link_pattern.findall(text):
                target = raw_target.strip()
                if not target or target.startswith("#"):
                    continue
                if "://" in target or target.startswith("mailto:"):
                    continue
                target_path = target.split("#", 1)[0]
                if not target_path:
                    continue
                resolved = (path.parent / target_path).resolve()
                assert resolved.exists(), f"Broken link in {path}: {target}"
