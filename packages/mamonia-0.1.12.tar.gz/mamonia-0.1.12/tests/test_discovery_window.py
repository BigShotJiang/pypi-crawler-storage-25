from __future__ import annotations

import datetime as dt

import pytest

from mamonia.discovery_window import parse_discovery_window_input


@pytest.mark.parametrize("input_str,expected_start,expected_end", [
    ("2025", dt.date(2025, 1, 1), dt.date(2025, 12, 31)),
    ("06.2025", dt.date(2025, 6, 1), dt.date(2025, 6, 30)),
    ("2008 - 2003", dt.date(2003, 1, 1), dt.date(2008, 12, 31)),
    ("05.06.2025", dt.date(2025, 6, 5), dt.date(2025, 6, 5)),
])
def test_parse_discovery_window(input_str: str, expected_start: dt.date, expected_end: dt.date) -> None:
    window = parse_discovery_window_input(input_str)
    assert window.start_date == expected_start
    assert window.end_date == expected_end


def test_parse_invalid_value_raises() -> None:
    with pytest.raises(ValueError):
        parse_discovery_window_input("13.2025")
