from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from mamonia.input import (
    extract_apple_music_playlist_id,
    extract_spotify_playlist_id,
    extract_tidal_playlist_id,
    looks_like_apple_music_playlist,
    looks_like_youtube_playlist,
    parse_csv_file,
    parse_text_file,
    parse_track_line,
)
from mamonia.utils import extract_artist_track_from_title


class InputTests(unittest.TestCase):
    def test_extract_spotify_playlist_id_from_url_uri_and_raw_id(self) -> None:
        self.assertEqual(
            extract_spotify_playlist_id("https://open.spotify.com/playlist/37i9dQZF1DX0XUsuxWHRQd?si=abc"),
            "37i9dQZF1DX0XUsuxWHRQd",
        )
        self.assertEqual(
            extract_spotify_playlist_id("spotify:playlist:37i9dQZF1DX0XUsuxWHRQd"),
            "37i9dQZF1DX0XUsuxWHRQd",
        )
        self.assertEqual(extract_spotify_playlist_id("37i9dQZF1DX0XUsuxWHRQd"), "37i9dQZF1DX0XUsuxWHRQd")
        self.assertEqual(extract_spotify_playlist_id("<37i9dQZF1DX0XUsuxWHRQd>"), "37i9dQZF1DX0XUsuxWHRQd")
        self.assertIsNone(extract_spotify_playlist_id("not a playlist"))

    def test_extract_tidal_playlist_id_from_url_uri_raw_and_wrapped_id(self) -> None:
        self.assertEqual(
            extract_tidal_playlist_id("https://tidal.com/playlist/69196ae6-37c7-4bf7-9c09-4ac4a07126e6"),
            "69196ae6-37c7-4bf7-9c09-4ac4a07126e6",
        )
        self.assertEqual(
            extract_tidal_playlist_id("tidal:playlist:69196ae6-37c7-4bf7-9c09-4ac4a07126e6"),
            "69196ae6-37c7-4bf7-9c09-4ac4a07126e6",
        )
        self.assertEqual(
            extract_tidal_playlist_id("69196ae6-37c7-4bf7-9c09-4ac4a07126e6"),
            "69196ae6-37c7-4bf7-9c09-4ac4a07126e6",
        )
        self.assertEqual(
            extract_tidal_playlist_id("<69196ae6-37c7-4bf7-9c09-4ac4a07126e6>"),
            "69196ae6-37c7-4bf7-9c09-4ac4a07126e6",
        )
        self.assertIsNone(extract_tidal_playlist_id("not a playlist"))

    def test_extract_apple_music_playlist_id_from_url_and_raw_id(self) -> None:
        self.assertEqual(
            extract_apple_music_playlist_id(
                "https://music.apple.com/us/playlist/test/pl.u-11zB9b9uKkq2z"
            ),
            "pl.u-11zB9b9uKkq2z",
        )
        self.assertEqual(
            extract_apple_music_playlist_id("pl.u-11zB9b9uKkq2z"),
            "pl.u-11zB9b9uKkq2z",
        )
        self.assertTrue(
            looks_like_apple_music_playlist("https://music.apple.com/us/playlist/test/pl.u-11zB9b9uKkq2z")
        )
        self.assertIsNone(extract_apple_music_playlist_id("not a playlist"))

    def test_parse_track_line_pipe_dash_and_artist_only(self) -> None:
        pipe = parse_track_line("Boards of Canada | Dayvan Cowboy | The Campfire Headphase")
        self.assertIsNotNone(pipe)
        self.assertEqual(pipe.artist, "Boards of Canada")
        self.assertEqual(pipe.track, "Dayvan Cowboy")
        self.assertEqual(pipe.album, "The Campfire Headphase")

        dash = parse_track_line("Burial - Archangel")
        self.assertIsNotNone(dash)
        self.assertEqual(dash.artist, "Burial")
        self.assertEqual(dash.track, "Archangel")

        artist_only = parse_track_line("Coil")
        self.assertIsNotNone(artist_only)
        self.assertEqual(artist_only.artist, "Coil")
        self.assertEqual(artist_only.track, "")

    def test_parse_text_file_skips_comments_and_blank_lines(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "tracks.txt"
            path.write_text("\n# comment\nBurial - Archangel\n\nCoil | Amber Rain | Astral Disaster\n", encoding="utf-8")
            tracks = parse_text_file(path)
        self.assertEqual(len(tracks), 2)
        self.assertEqual(tracks[0].artist, "Burial")
        self.assertEqual(tracks[1].album, "Astral Disaster")

    def test_parse_csv_file_parses_tunemymusic_format(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "playlist.csv"
            path.write_text(
                'Track name,Artist name,Album,Playlist name,Type,ISRC,Spotify - id\n'
                '"Test Song","Test Artist","Test Album","Test Playlist","Playlist","TEST123","4CjNYfz5Vaze4DM0LTspq9"\n'
                '"Another Track","Another Artist","Another Album","Test Playlist","Playlist","TEST456","633Trk9F0nyEjjKaD5BuXs"\n',
                encoding="utf-8",
            )
            tracks = parse_csv_file(path)
        self.assertEqual(len(tracks), 2)
        self.assertEqual(tracks[0].artist, "Test Artist")
        self.assertEqual(tracks[0].track, "Test Song")
        self.assertEqual(tracks[0].album, "Test Album")
        self.assertEqual(tracks[0].isrc, "TEST123")
        self.assertEqual(tracks[0].spotify_track_id, "4CjNYfz5Vaze4DM0LTspq9")
        self.assertEqual(tracks[1].artist, "Another Artist")

    def test_parse_text_file_detects_csv_extension(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = Path(tmp) / "playlist.csv"
            csv_path.write_text(
                'Track name,Artist name,Album,Playlist name,Type,ISRC,Spotify - id\n'
                '"Test Song","Test Artist","Test Album","Test Playlist","Playlist","TEST123","4CjNYfz5Vaze4DM0LTspq9"\n',
                encoding="utf-8",
            )
            tracks = parse_text_file(csv_path)
        self.assertEqual(len(tracks), 1)
        self.assertEqual(tracks[0].artist, "Test Artist")

    def test_extract_artist_track_from_title_youtube_style(self) -> None:
        # Standard YouTube format with noise suffixes
        result = extract_artist_track_from_title("Artist - Track Name (Official Video)")
        self.assertEqual(result, ("Artist", "Track Name"))

        result = extract_artist_track_from_title("Artist | Track Name [Audio]")
        self.assertEqual(result, ("Artist", "Track Name"))

        result = extract_artist_track_from_title("Artist: Track Name (Live)")
        self.assertEqual(result, ("Artist", "Track Name"))

        result = extract_artist_track_from_title("Artist - Track Name (ft. Someone)")
        self.assertEqual(result, ("Artist", "Track Name"))

        result = extract_artist_track_from_title("Artist - Track Name (Official Audio) [HD]")
        self.assertEqual(result, ("Artist", "Track Name"))

        # YouTube-style "by" separator - first part is artist, second is track
        result = extract_artist_track_from_title("Artist by Track Name")
        self.assertEqual(result, ("Artist", "Track Name"))
        # Note: "Track Name by Artist" would be parsed as artist="Track Name", track="Artist"
        # This is consistent with the separator logic - first part is always artist

        # No separator - should return Unknown Artist with cleaned title
        result = extract_artist_track_from_title("Track Name (Official Video)")
        self.assertEqual(result, ("Unknown Artist", "Track Name"))

        # Empty input
        result = extract_artist_track_from_title("")
        self.assertIsNone(result)

        result = extract_artist_track_from_title(None)  # type: ignore
        self.assertIsNone(result)

    def test_parse_track_line_youtube_style_titles(self) -> None:
        # YouTube-style title with noise suffixes should be parsed correctly
        track = parse_track_line("Artist - Track Name (Official Video)")
        self.assertIsNotNone(track)
        self.assertEqual(track.artist, "Artist")
        self.assertEqual(track.track, "Track Name")

        track = parse_track_line("Artist | Track Name [Audio]")
        self.assertIsNotNone(track)
        self.assertEqual(track.artist, "Artist")
        self.assertEqual(track.track, "Track Name")

        # Standard formats should still work
        track = parse_track_line("Artist - Track Name")
        self.assertIsNotNone(track)
        self.assertEqual(track.artist, "Artist")
        self.assertEqual(track.track, "Track Name")

        track = parse_track_line("Artist | Track Name")
        self.assertIsNotNone(track)
        self.assertEqual(track.artist, "Artist")
        self.assertEqual(track.track, "Track Name")

    def test_parse_csv_file_with_combined_title_column(self) -> None:
        # Test CSV with a combined Title column instead of separate Artist/Track
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "playlist.csv"
            path.write_text(
                'Title,Album,ISRC,Spotify - id\n'
                '"Artist - Track Name (Official Video)","Test Album","TEST123","4CjNYfz5Vaze4DM0LTspq9"\n'
                '"Another Artist | Another Track [Audio]","Test Album","TEST456","633Trk9F0nyEjjKaD5BuXs"\n',
                encoding="utf-8",
            )
            tracks = parse_csv_file(path)
        self.assertEqual(len(tracks), 2)
        self.assertEqual(tracks[0].artist, "Artist")
        self.assertEqual(tracks[0].track, "Track Name")
        self.assertEqual(tracks[1].artist, "Another Artist")
        self.assertEqual(tracks[1].track, "Another Track")

    def test_looks_like_youtube_playlist(self) -> None:
        # YouTube Music playlist URLs
        self.assertTrue(looks_like_youtube_playlist("https://music.youtube.com/playlist?list=PL123456789"))
        self.assertTrue(looks_like_youtube_playlist("https://www.youtube.com/playlist?list=PL123456789"))
        self.assertTrue(looks_like_youtube_playlist("https://music.youtube.com/playlist?list=PL123456789&feature=share"))
        # Regular YouTube URLs should also match
        self.assertTrue(looks_like_youtube_playlist("https://youtube.com/playlist?list=PL123456789"))

        # Non-YouTube URLs should not match
        self.assertFalse(looks_like_youtube_playlist("https://open.spotify.com/playlist/37i9dQZF1DX0XUsuxWHRQd"))
        self.assertFalse(looks_like_youtube_playlist("https://tidal.com/playlist/123456789"))
        self.assertFalse(looks_like_youtube_playlist("not a playlist url"))


if __name__ == "__main__":
    unittest.main()
