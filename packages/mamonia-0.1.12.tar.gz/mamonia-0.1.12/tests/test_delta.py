from __future__ import annotations

import unittest

from mamonia.delta import diff_playlist_tracks
from mamonia.models import InputTrack


class PlaylistDeltaTests(unittest.TestCase):
    def test_diff_ignores_shuffled_order(self) -> None:
        previous = [
            InputTrack(artist="A", track="One"),
            InputTrack(artist="B", track="Two"),
        ]
        current = [
            InputTrack(artist="B", track="Two"),
            InputTrack(artist="A", track="One"),
        ]

        diff = diff_playlist_tracks(previous, current)

        self.assertFalse(diff.changed)
        self.assertEqual(diff.added, [])
        self.assertEqual(diff.removed, [])

    def test_diff_reports_added_and_removed_tracks(self) -> None:
        previous = [
            InputTrack(artist="A", track="One"),
            InputTrack(artist="B", track="Two"),
        ]
        current = [
            InputTrack(artist="B", track="Two"),
            InputTrack(artist="C", track="Three"),
        ]

        diff = diff_playlist_tracks(previous, current)

        self.assertEqual([track.track for track in diff.added], ["Three"])
        self.assertEqual([track.track for track in diff.removed], ["One"])

    def test_diff_prefers_provider_track_ids(self) -> None:
        previous = [InputTrack(artist="Old Metadata", track="Title", spotify_track_id="sp-1")]
        current = [InputTrack(artist="New Metadata", track="Retitled", spotify_track_id="sp-1")]

        diff = diff_playlist_tracks(previous, current)

        self.assertFalse(diff.changed)
        self.assertEqual(diff.unchanged_count, 1)

    def test_diff_prefers_isrc_over_provider_track_ids(self) -> None:
        previous = [
            InputTrack(artist="Artist", track="Song", isrc="US-AAA-26-00001", spotify_track_id="spotify-old")
        ]
        current = [
            InputTrack(artist="Artist", track="Song", isrc="US-AAA-26-00001", spotify_track_id="spotify-new")
        ]

        diff = diff_playlist_tracks(previous, current)

        self.assertFalse(diff.changed)
        self.assertEqual(diff.unchanged_count, 1)

    def test_diff_uses_multiset_counts_for_duplicate_tracks(self) -> None:
        previous = [
            InputTrack(artist="A", track="One"),
            InputTrack(artist="A", track="One"),
        ]
        current = [InputTrack(artist="A", track="One")]

        diff = diff_playlist_tracks(previous, current)

        self.assertTrue(diff.changed)
        self.assertEqual(diff.added_count, 0)
        self.assertEqual(diff.removed_count, 1)
        self.assertEqual(diff.unchanged_count, 1)


if __name__ == "__main__":
    unittest.main()
