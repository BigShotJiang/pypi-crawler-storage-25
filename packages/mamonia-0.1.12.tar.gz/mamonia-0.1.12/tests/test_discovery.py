from __future__ import annotations

import datetime as dt
import tempfile
import unittest
from pathlib import Path

from mamonia.discovery import (
    _recommendations_match,
    average_track_popularity,
    candidate_artists_from_profile,
    discover_releases,
    filter_seed_tracks,
    is_allowed_release_group,
    label_affinity_recommendations,
    passes_popularity_filter,
    profile_allows_soundtracks,
    recommendation_matches_source_memory,
    source_release_keys_from_input,
    tiered_sample_recommendations,
    track_keys_from_input,
)
from mamonia.models import ArtistProfile, InputTrack, ReleaseRecommendation, ReleaseTrack, TasteProfile, WeightedTerm
from mamonia.storage import Storage


class FakeMusicBrainz:
    def search_artist(self, name: str) -> dict:
        return {"id": f"{name.lower()}-mbid", "name": name}

    def browse_release_groups(self, mbid: str) -> list[dict]:
        return [
            {
                "id": "rg-heard",
                "title": "Already Heard",
                "primary-type": "Album",
                "secondary-types": [],
                "first-release-date": "2026-03-01",
                "artist-credit": [{"name": "Seed Artist"}],
            },
            {
                "id": "rg-new",
                "title": "Fresh Release",
                "primary-type": "EP",
                "secondary-types": [],
                "first-release-date": "2026-04-01",
                "artist-credit": [{"name": "Seed Artist"}],
            },
            {
                "id": "rg-old",
                "title": "Old Release",
                "primary-type": "Album",
                "secondary-types": [],
                "first-release-date": "2025-01-01",
                "artist-credit": [{"name": "Seed Artist"}],
            },
        ]


class FakeSpotify:
    def representative_tracks(self, artist: str, album: str, cap: int):
        tracks = [
            ReleaseTrack(title=f"Track {idx}", artists=artist, track_number=idx, spotify_uri=f"spotify:track:{idx}")
            for idx in range(1, 6)
        ]
        album_id = f"spotify-album-{album.lower().replace(' ', '-')}"
        return album_id, f"spotify:album:{album_id}", tracks[:cap]


class MissingSpotify:
    def representative_tracks(self, artist: str, album: str, cap: int):
        return None, None, []


class BackfillSpotify(MissingSpotify):
    def __init__(self) -> None:
        self.calls: list[tuple[str, list[str]]] = []

    def backfill_release_tracks(self, album_name: str, tracks: list[ReleaseTrack], *, artist_name: str | None = None):
        self.calls.append((album_name, [track.title for track in tracks]))
        for index, track in enumerate(tracks, start=1):
            track.spotify_track_id = f"bf-{index}"
            track.spotify_uri = f"spotify:track:bf-{index}"
            track.resolution_source = "spotify_track_search_strict"
            track.resolution_note = "Matched exact title/artist/album context."
        return tracks


class ConservativeBackfillSpotify(MissingSpotify):
    def __init__(self) -> None:
        self.calls = 0

    def backfill_release_tracks(self, album_name: str, tracks: list[ReleaseTrack], *, artist_name: str | None = None):
        self.calls += 1
        return tracks


class BroadAwareSpotify:
    def __init__(self) -> None:
        self.calls: list[bool] = []

    def representative_tracks(self, artist: str, album: str, cap: int, allow_broad_search: bool = True):
        self.calls.append(allow_broad_search)
        if allow_broad_search:
            return "spotify-album", "spotify:album", [
                ReleaseTrack(title="Broad Spotify Track", artists=artist, track_number=1)
            ]
        return None, None, []


class TracklistMusicBrainz(FakeMusicBrainz):
    def release_tracks_for_group(self, release_group_id: str, cap: int = 10) -> list[ReleaseTrack]:
        if release_group_id != "rg-new":
            return []
        return [
            ReleaseTrack(title="Known Seed", artists="Seed Artist", track_number=1),
            ReleaseTrack(title="MB Opener", artists="Seed Artist", track_number=2, isrc="ISRC1"),
            ReleaseTrack(title="MB Anchor", artists="Seed Artist", track_number=3),
            ReleaseTrack(title="MB Deep Cut", artists="Seed Artist", track_number=4),
        ][:cap]


class NetworkMusicBrainz:
    def search_artist(self, name: str) -> dict:
        return {"id": f"{name.lower()}-mbid", "name": name}

    def browse_release_groups(self, mbid: str) -> list[dict]:
        artist = mbid.removesuffix("-mbid").title()
        return [
            {
                "id": f"{mbid}-fresh",
                "title": "Network Fresh",
                "primary-type": "Album",
                "secondary-types": [],
                "first-release-date": "2026-04-01",
                "artist-credit": [{"name": artist}],
            }
        ]


class DuplicateReleaseMusicBrainz:
    def search_artist(self, name: str) -> dict:
        return {"id": f"{name.lower()}-mbid", "name": name}

    def browse_release_groups(self, mbid: str) -> list[dict]:
        # Both artists have the same release group ID to test duplicate collapsing
        # based on MusicBrainz ID (primary check in _recommendations_match)
        if mbid == "seed artist-mbid":
            artist_name = "Seed Artist"
        else:
            artist_name = "Seed Artist feat. Guest"
        return [
            {
                "id": "rg-shared",  # Same release group ID for both artists
                "title": "Shared Release",
                "primary-type": "Album",
                "secondary-types": [],
                "first-release-date": "2026-04-01",
                "artist-credit": [{"name": artist_name}],
            }
        ]


class SharedAlbumSpotify:
    def representative_tracks(self, artist: str, album: str, cap: int, allow_broad_search: bool = True):
        return "shared-album", "spotify:album:shared-album", [
            ReleaseTrack(
                title="Shared Track",
                artists=artist,
                track_number=1,
                spotify_track_id="shared-track",
                spotify_uri="spotify:track:shared-track",
                resolution_source="spotify_album_tracklist",
                resolution_note="Resolved from Spotify album tracklist.",
            )
        ][:cap]


class LabelMusicBrainz(FakeMusicBrainz):
    def search_releases_by_label(self, label_name: str, limit: int = 25) -> list[dict]:
        return [
            {
                "id": "release-1",
                "title": "Label Fresh",
                "date": "2026-04-05",
                "artist-credit": [{"name": "Label Artist"}],
                "label-info": [{"label": {"name": label_name}}],
                "release-group": {
                    "id": "rg-label-1",
                    "title": "Label Fresh",
                    "primary-type": "Album",
                    "secondary-types": [],
                    "first-release-date": "2026-04-05",
                },
            }
        ]


class PopularitySpotify:
    def __init__(self, popularities: list[int]) -> None:
        self.popularities = popularities

    def representative_tracks(self, artist: str, album: str, cap: int, allow_broad_search: bool = True):
        tracks = [
            ReleaseTrack(
                title=f"Track {idx}",
                artists=artist,
                track_number=idx,
                spotify_track_id=f"track-{idx}",
                spotify_uri=f"spotify:track:{idx}",
                popularity=popularity,
                resolution_source="spotify_album_tracklist",
                resolution_note="Resolved from Spotify album tracklist.",
            )
            for idx, popularity in enumerate(self.popularities, start=1)
        ]
        return "spotify-album", "spotify:album:spotify-album", tracks[:cap]


class DiscoveryTests(unittest.TestCase):
    def test_release_group_filters_type_secondary_and_date(self) -> None:
        today = dt.date(2026, 4, 22)
        self.assertTrue(
            is_allowed_release_group(
                {"primary-type": "Album", "secondary-types": [], "first-release-date": "2026-04-01"},
                months=6,
                today=today,
            )
        )
        self.assertFalse(
            is_allowed_release_group(
                {"primary-type": "Album", "secondary-types": ["Live"], "first-release-date": "2026-04-01"},
                months=6,
                today=today,
            )
        )
        self.assertFalse(
            is_allowed_release_group(
                {"primary-type": "Broadcast", "secondary-types": [], "first-release-date": "2026-04-01"},
                months=6,
                today=today,
            )
        )
        self.assertFalse(
            is_allowed_release_group(
                {"primary-type": "Album", "secondary-types": ["Soundtrack"], "first-release-date": "2026-04-01"},
                months=6,
                today=today,
            )
        )
        self.assertTrue(
            is_allowed_release_group(
                {"primary-type": "Album", "secondary-types": ["Soundtrack"], "first-release-date": "2026-04-01"},
                months=6,
                today=today,
                allow_soundtracks=True,
            )
        )

    def test_soundtrack_heavy_profile_allows_soundtrack_release_groups(self) -> None:
        profile = TasteProfile(top_tags=[WeightedTerm(name="Soundtrack", weight=100)])

        self.assertTrue(profile_allows_soundtracks(profile))

    def test_release_group_filters_old_dates(self) -> None:
        self.assertFalse(
            is_allowed_release_group(
                {"primary-type": "Album", "secondary-types": [], "first-release-date": "2025-01-01"},
                months=6,
                today=dt.date(2026, 4, 22),
            )
        )

    def test_discovery_excludes_heard_and_caps_tracks(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=FakeMusicBrainz(),
                spotify=FakeSpotify(),
                months=6,
                max_tracks=3,
                today=dt.date(2026, 4, 22),
            )
            heard_diag = getattr(storage, "_last_heard_discovery_diagnostics", {})
            storage.close()

        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0].title, "Fresh Release")
        self.assertEqual(len(recs[0].tracks), 0)
        self.assertEqual(heard_diag.get("excluded_by_mbid"), 1)

    def test_candidate_generation_includes_one_off_artists_with_lower_scores(self) -> None:
        profile = TasteProfile(
            artists=[
                ArtistProfile(name="Frequent", playlist_count=4, affinity_score=8, related_acts=["Frequent Friend"]),
                ArtistProfile(name="One Off", playlist_count=1, affinity_score=2, related_acts=["One Off Friend"]),
            ],
            top_artists=[
                ArtistProfile(name="Frequent", playlist_count=4, affinity_score=8, related_acts=["Frequent Friend"]),
                ArtistProfile(name="One Off", playlist_count=1, affinity_score=2, related_acts=["One Off Friend"]),
            ],
            n_artists=2,
        )

        candidates = {candidate.name: candidate for candidate in candidate_artists_from_profile(profile)}

        self.assertIn("One Off", candidates)
        self.assertIn("One Off Friend", candidates)
        self.assertGreater(candidates["Frequent"].score, candidates["One Off"].score)
        self.assertGreater(candidates["Frequent Friend"].score, candidates["One Off Friend"].score)

    def test_candidate_generation_includes_aggregated_network_artists(self) -> None:
        profile = TasteProfile(
            artists=[ArtistProfile(name="Seed", playlist_count=3, affinity_score=8)],
            network_artists=[WeightedTerm(name="Unknown Adjacent", weight=6)],
            n_artists=1,
        )

        candidates = {candidate.name: candidate for candidate in candidate_artists_from_profile(profile)}

        self.assertIn("Unknown Adjacent", candidates)
        self.assertEqual(candidates["Unknown Adjacent"].source, "profile-network")
        self.assertGreater(candidates["Unknown Adjacent"].score, 0.5)

    def test_candidate_limit_preserves_all_seed_artists(self) -> None:
        profile = TasteProfile(
            artists=[
                ArtistProfile(
                    name="Frequent",
                    playlist_count=4,
                    affinity_score=8,
                    related_acts=["High Score Network"],
                ),
                ArtistProfile(name="One Off", playlist_count=1, affinity_score=2),
                ArtistProfile(name="Another One Off", playlist_count=1, affinity_score=2),
            ],
            network_artists=[WeightedTerm(name="Unknown Adjacent", weight=20)],
            n_artists=3,
        )

        candidates = candidate_artists_from_profile(profile, max_candidates=2)
        candidate_names = {candidate.name for candidate in candidates}

        self.assertEqual(candidate_names, {"Frequent", "One Off", "Another One Off"})

    def test_candidate_limit_keeps_top_network_candidates_after_seeds(self) -> None:
        profile = TasteProfile(
            artists=[ArtistProfile(name="Seed", playlist_count=3, affinity_score=10)],
            network_artists=[
                WeightedTerm(name="Strong Network", weight=20),
                WeightedTerm(name="Weak Network", weight=1),
            ],
            n_artists=1,
        )

        candidates = candidate_artists_from_profile(profile, max_candidates=2)
        candidate_names = {candidate.name for candidate in candidates}

        self.assertEqual(candidate_names, {"Seed", "Strong Network"})

    def test_label_affinity_recommendations_build_release_candidates(self) -> None:
        recs = label_affinity_recommendations(
            musicbrainz=LabelMusicBrainz(),
            label_name="Important Label",
            weight=10,
            months=6,
            today=dt.date(2026, 4, 22),
            allow_soundtracks=False,
        )

        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0].title, "Label Fresh")
        self.assertEqual(recs[0].rationale, ["label-affinity:Important Label"])
        self.assertEqual(recs[0].label, "Important Label")

    def test_discovery_can_recommend_release_from_network_only_artist(self) -> None:
        profile = TasteProfile(
            network_artists=[WeightedTerm(name="Unknown Adjacent", weight=6)],
            n_artists=0,
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=NetworkMusicBrainz(),
                spotify=None,
                months=6,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0].artist, "Unknown Adjacent")
        self.assertEqual(recs[0].rationale, ["profile-network", "musicbrainz-no-tracks"])

    def test_seed_playlist_tracks_are_filtered_from_recommendation_tracks(self) -> None:
        seed_keys = track_keys_from_input(
            [
                InputTrack(artist="Seed Artist", track="Track 1", artists=["Seed Artist"]),
                InputTrack(artist="Other", track="Elsewhere", artists=["Other"]),
            ]
        )
        tracks = [
            ReleaseTrack(title="Track 1", artists="Seed Artist", track_number=1),
            ReleaseTrack(title="Track 2", artists="Seed Artist", track_number=2),
        ]

        filtered = filter_seed_tracks(tracks, seed_keys)

        self.assertEqual([track.title for track in filtered], ["Track 2"])

    def test_discovery_does_not_output_tracks_already_in_seed_playlist(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        seed_tracks = [InputTrack(artist="Seed Artist", track="Track 1", artists=["Seed Artist"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=FakeMusicBrainz(),
                spotify=FakeSpotify(),
                seed_tracks=seed_tracks,
                months=6,
                max_tracks=3,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        self.assertNotIn("Track 1", [track.title for track in fresh.tracks])

    def test_source_release_keys_capture_album_variants_from_seed_tracks(self) -> None:
        keys = source_release_keys_from_input(
            [
                InputTrack(
                    artist="Seed Artist",
                    artists=["Seed Artist", "Guest Artist"],
                    track="Song",
                    album="Fresh Release (Japanese Edition)",
                )
            ]
        )

        self.assertIn("seed artist|fresh release", keys)
        self.assertIn("guest artist|fresh release", keys)

    def test_recommendation_matches_source_memory_for_variant_album_title(self) -> None:
        source_keys = source_release_keys_from_input(
            [InputTrack(artist="Seed Artist", track="Song", album="Fresh Release [US Version]")]
        )
        recommendation = ReleaseRecommendation(
            artist="Seed Artist",
            title="Fresh Release",
            artist_credits=["Seed Artist"],
            release_date="2026-04-01",
        )

        self.assertTrue(recommendation_matches_source_memory(recommendation, source_keys))

    def test_discovery_uses_musicbrainz_tracklist_when_spotify_lookup_misses(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        seed_tracks = [InputTrack(artist="Seed Artist", track="Known Seed", artists=["Seed Artist"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=TracklistMusicBrainz(),
                spotify=MissingSpotify(),
                seed_tracks=seed_tracks,
                months=6,
                max_tracks=2,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        self.assertEqual([track.title for track in fresh.tracks], ["MB Opener", "MB Anchor"])
        self.assertEqual(fresh.tracks[0].isrc, "ISRC1")
        self.assertNotIn("spotify-track-lookup-missed-or-seed-tracks-filtered", fresh.rationale)
        self.assertNotIn("musicbrainz-no-tracks", fresh.rationale)

    def test_musicbrainz_tracklist_prevents_broad_spotify_fallback_call(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        spotify = BroadAwareSpotify()

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=TracklistMusicBrainz(),
                spotify=spotify,
                months=6,
                max_tracks=2,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        self.assertEqual([track.title for track in fresh.tracks], ["Known Seed", "MB Opener"])
        self.assertEqual(spotify.calls, [])

    def test_musicbrainz_enriches_spotify_tracks_with_isrc(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=TracklistMusicBrainz(),
                spotify=FakeSpotify(),
                months=6,
                max_tracks=3,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        # Lightweight discovery uses MusicBrainz-only track enrichment.
        self.assertTrue(all(not track.spotify_uri for track in fresh.tracks))
        # MB ISRC must be present for the matching track (track_number=2)
        track_2 = next(t for t in fresh.tracks if t.track_number == 2)
        self.assertEqual(track_2.isrc, "ISRC1")


    def test_musicbrainz_tracklist_can_gain_spotify_ids_via_backfill(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        spotify = BackfillSpotify()

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=TracklistMusicBrainz(),
                spotify=spotify,
                months=6,
                max_tracks=2,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        self.assertEqual([track.spotify_track_id for track in fresh.tracks], [None, None])
        self.assertEqual([track.resolution_source for track in fresh.tracks], ["musicbrainz_tracklist", "musicbrainz_tracklist"])
        self.assertEqual(spotify.calls, [])

    def test_musicbrainz_tracklist_keeps_unresolved_tracks_when_backfill_rejects_match(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        spotify = ConservativeBackfillSpotify()

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=TracklistMusicBrainz(),
                spotify=spotify,
                months=6,
                max_tracks=2,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        fresh = [rec for rec in recs if rec.title == "Fresh Release"][0]
        self.assertEqual([track.spotify_track_id for track in fresh.tracks], [None, None])
        self.assertEqual([track.resolution_source for track in fresh.tracks], ["musicbrainz_tracklist", "musicbrainz_tracklist"])
        self.assertEqual(spotify.calls, 0)

    def test_discovery_collapses_duplicate_release_by_musicbrainz_id(self) -> None:
        """Test that duplicate releases are collapsed based on MusicBrainz release group ID.
        
        Note: This test uses lightweight enrichment (no Spotify) during discovery,
        so duplicate collapsing is based on mb_release_group_id, not spotify_album_id.
        Full enrichment with Spotify happens after selection in workflow.py.
        """
        profile = TasteProfile(
            top_artists=[
                ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed artist-mbid"),
                ArtistProfile(name="Guest Artist", affinity_score=9, mbid="guest artist-mbid"),
            ],
            n_artists=2,
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=DuplicateReleaseMusicBrainz(),
                spotify=SharedAlbumSpotify(),  # Not used during lightweight enrichment
                months=6,
                max_tracks=1,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        # Should collapse to 1 recommendation based on mb_release_group_id
        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0].mb_release_group_id, "rg-shared")
        self.assertIn("seed-artist", recs[0].rationale[0])

    def test_discovery_skips_release_already_present_in_source_memory_under_variant_title(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        seed_tracks = [
            InputTrack(
                artist="Seed Artist",
                artists=["Seed Artist"],
                track="Known Song",
                album="Fresh Release (Japanese Edition)",
            )
        ]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=FakeMusicBrainz(),
                spotify=MissingSpotify(),
                seed_tracks=seed_tracks,
                months=6,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        self.assertEqual([rec.title for rec in recs], [])

    def test_recommendation_match_uses_artist_credit_overlap_when_ids_and_primary_artist_differ(self) -> None:
        left = ReleaseRecommendation(
            artist="Seed Artist",
            artist_credits=["Seed Artist", "Guest Artist"],
            title="Shared Release",
            release_date="2026-04-01",
        )
        right = ReleaseRecommendation(
            artist="Guest Artist",
            artist_credits=["Guest Artist", "Seed Artist"],
            title="Shared Release (Deluxe Edition)",
            release_date="2026-04-01",
        )

        self.assertTrue(_recommendations_match(left, right))

    def test_recommendation_match_respects_conflicting_labels_when_available(self) -> None:
        left = ReleaseRecommendation(
            artist="Seed Artist",
            artist_credits=["Seed Artist"],
            title="Shared Release",
            release_date="2026-04-01",
            label="Label One",
        )
        right = ReleaseRecommendation(
            artist="Seed Artist",
            artist_credits=["Seed Artist"],
            title="Shared Release",
            release_date="2026-04-01",
            label="Label Two",
        )

        self.assertFalse(_recommendations_match(left, right))

    def test_average_track_popularity_returns_mean_for_resolved_tracks(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[
                ReleaseTrack(title="One", artists="Artist", popularity=20),
                ReleaseTrack(title="Two", artists="Artist", popularity=40),
            ],
        )

        self.assertEqual(average_track_popularity(rec), 30)

    def test_deep_cuts_filter_rejects_high_popularity_recommendations(self) -> None:
        rec = ReleaseRecommendation(
            artist="Artist",
            title="Album",
            tracks=[ReleaseTrack(title="One", artists="Artist", popularity=85)],
        )

        self.assertFalse(passes_popularity_filter(rec, deep_cuts=True))
        self.assertTrue(passes_popularity_filter(rec, deep_cuts=False))

    def test_discovery_deep_cuts_filters_out_high_popularity_release(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=FakeMusicBrainz(),
                spotify=PopularitySpotify([90, 88, 92]),
                months=6,
                max_tracks=3,
                deep_cuts=True,
                today=dt.date(2026, 4, 22),
            )
            storage.close()

        self.assertEqual([rec.title for rec in recs], ["Fresh Release"])

    def test_tiered_sampling_mixes_top_mid_and_low_scored_results(self) -> None:
        results = [
            ReleaseRecommendation(artist=f"Artist {idx}", title=f"Release {idx}", score=100 - idx)
            for idx in range(9)
        ]

        sampled = tiered_sample_recommendations(results, limit=4)

        self.assertEqual(len(sampled), 4)
        self.assertEqual(sampled[0].title, "Release 0")
        self.assertTrue(any(item.title == "Release 3" for item in sampled))
        self.assertTrue(any(item.title in {"Release 6", "Release 7", "Release 8"} for item in sampled))

    def test_discovery_emits_progress_events_without_changing_results(self) -> None:
        profile = TasteProfile(
            top_artists=[ArtistProfile(name="Seed Artist", affinity_score=10, mbid="seed-mbid")],
            n_artists=1,
        )
        progress = RecordingProgress()

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Seed Artist", "Already Heard", "2026-03-01", mb_release_group_id="rg-heard")
            recs = discover_releases(
                profile=profile,
                storage=storage,
                musicbrainz=FakeMusicBrainz(),
                spotify=FakeSpotify(),
                months=6,
                max_tracks=3,
                today=dt.date(2026, 4, 22),
                progress=progress,
            )
            storage.close()

        self.assertEqual([rec.title for rec in recs], ["Fresh Release"])
        self.assertIn(("candidate", "Seed Artist", 1, 1), progress.events)
        self.assertIn(("skipped", "heard"), progress.events)
        self.assertIn(("skipped", "date-or-type-filter"), progress.events)
        self.assertIn(("accepted", "Fresh Release"), progress.events)


class RecordingProgress:
    def __init__(self) -> None:
        self.events: list[tuple] = []

    def candidate_started(self, candidate, processed: int, total: int | None) -> None:
        self.events.append(("candidate", candidate.name, processed, total))

    def release_group_checked(self, candidate, release_group: dict) -> None:
        self.events.append(("checked", candidate.name, release_group["title"]))

    def release_group_skipped(self, reason: str) -> None:
        self.events.append(("skipped", reason))

    def release_accepted(self, recommendation) -> None:
        self.events.append(("accepted", recommendation.title))

    def spotify_lookup_missed(self, recommendation) -> None:
        self.events.append(("spotify-missed", recommendation.title))

    def musicbrainz_lookup_missed(self, recommendation) -> None:
        self.events.append(("musicbrainz-missed", recommendation.title))

    def log_debug(self, message: str) -> None:
        self.events.append(("debug", message))


if __name__ == "__main__":
    unittest.main()
