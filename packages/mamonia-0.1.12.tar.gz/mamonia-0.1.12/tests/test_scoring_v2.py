"""Tests for mamonia/scoring_v2.py — §9–10 scoring engine."""

from __future__ import annotations

import unittest

import pytest

from mamonia.graph_expansion import TIER_1, TIER_2A, TIER_2B, TIER_3, TIER_4
from mamonia.models import ArtistSeed, GraphEdge
from mamonia.release_discovery import CandidateRelease
from mamonia.scoring_v2 import (
    _apply_diminishing_returns,
    _confidence_label,
    score_candidates,
)

SEED_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
ARTIST_MBID = "b2c3d4e5-f6a7-8901-bcde-f12345678901"
RG_MBID = "c3d4e5f6-a7b8-9012-cdef-123456789012"
SEED_MBID_2 = "d4e5f6a7-b8c9-0123-defa-234567890123"
SEED_MBID_3 = "e5f6a7b8-c9d0-1234-efab-345678901234"


def _seed(mbid: str = SEED_MBID, name: str = "Massive Attack", weight: float = 1.0, confidence: float = 1.0) -> ArtistSeed:
    return ArtistSeed(
        artist_mbid=mbid,
        canonical_name=name,
        seed_weight=weight,
        match_confidence_avg=confidence,
    )


def _edge(
    source_mbid: str = SEED_MBID,
    source_name: str = "Massive Attack",
    target_mbid: str = ARTIST_MBID,
    target_name: str = "Portishead",
    relation_type: str = "collaboration",
    confidence: float = 0.9,
    connection_strength: float = 0.8,
    tier: str = TIER_2A,
) -> GraphEdge:
    return GraphEdge(
        source_artist_mbid=source_mbid,
        source_artist_name=source_name,
        target_artist_mbid=target_mbid,
        target_artist_name=target_name,
        relation_type=relation_type,
        confidence=confidence,
        depth=1,
        connection_strength=connection_strength,
        tier=tier,
    )


def _candidate(
    rg_mbid: str = RG_MBID,
    artist_mbid: str = ARTIST_MBID,
    artist_name: str = "Portishead",
    tier: str = TIER_2A,
    possible_reissue: bool = False,
    uncertain_release_type: bool = False,
) -> CandidateRelease:
    return CandidateRelease(
        release_group_mbid=rg_mbid,
        artist_mbid=artist_mbid,
        artist_name=artist_name,
        title="Dummy",
        release_date="2025-03-01",
        primary_type="album",
        tier=tier,
        possible_reissue=possible_reissue,
        uncertain_release_type=uncertain_release_type,
    )


class TestScoreCandidatesBasic(unittest.TestCase):

    def test_empty_candidates_returns_empty(self):
        results = score_candidates([], [], [])
        self.assertEqual(results, [])

    def test_single_tier1_seed_candidate_scores_high(self):
        seeds = [_seed(mbid=SEED_MBID, name="Massive Attack")]
        c = _candidate(artist_mbid=SEED_MBID, artist_name="Massive Attack", tier=TIER_1)
        results = score_candidates([c], seeds, [])
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].score_normalized, 100.0)
        self.assertEqual(results[0].confidence_label, "High")

    def test_tier2a_scores_lower_than_tier1(self):
        seeds = [_seed()]
        edges = [_edge()]
        t1_candidate = _candidate(artist_mbid=SEED_MBID, artist_name="Massive Attack", tier=TIER_1, rg_mbid="rg-seed")
        t2a_candidate = _candidate(tier=TIER_2A)
        results = score_candidates([t1_candidate, t2a_candidate], seeds, edges)
        tier1_result = next(r for r in results if r.candidate.artist_mbid == SEED_MBID)
        tier2a_result = next(r for r in results if r.candidate.artist_mbid == ARTIST_MBID)
        self.assertGreater(tier1_result.score_normalized, tier2a_result.score_normalized)

    def test_higher_tier_scores_higher(self):
        seeds = [_seed()]
        edge_2a = _edge(target_mbid="artist-2a", target_name="2A Artist", tier=TIER_2A, connection_strength=0.9)
        edge_3 = _edge(target_mbid="artist-3", target_name="3 Artist", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=0.7)
        c_2a = _candidate(rg_mbid="rg-2a", artist_mbid="artist-2a", artist_name="2A Artist", tier=TIER_2A)
        c_3 = _candidate(rg_mbid="rg-3", artist_mbid="artist-3", artist_name="3 Artist", tier=TIER_3)
        results = score_candidates([c_2a, c_3], seeds, [edge_2a, edge_3])
        r2a = next(r for r in results if r.candidate.artist_mbid == "artist-2a")
        r3 = next(r for r in results if r.candidate.artist_mbid == "artist-3")
        self.assertGreater(r2a.score_normalized, r3.score_normalized)

    def test_label_affinity_scores_as_tier3_path(self):
        seeds = [_seed()]
        label_edge = _edge(
            target_mbid="label-artist",
            target_name="Label Artist",
            relation_type="label_affinity",
            tier=TIER_3,
            connection_strength=0.38,
        )
        tier2b_edge = _edge(
            target_mbid="tier2b-artist",
            target_name="Tier 2B Artist",
            relation_type="producer",
            tier=TIER_2B,
            connection_strength=0.5,
        )
        label_candidate = _candidate(
            rg_mbid="rg-label",
            artist_mbid="label-artist",
            artist_name="Label Artist",
            tier=TIER_3,
        )
        tier2b_candidate = _candidate(
            rg_mbid="rg-tier2b",
            artist_mbid="tier2b-artist",
            artist_name="Tier 2B Artist",
            tier=TIER_2B,
        )

        results = score_candidates([label_candidate, tier2b_candidate], seeds, [label_edge, tier2b_edge])

        label_result = next(r for r in results if r.candidate.release_group_mbid == "rg-label")
        tier2b_result = next(r for r in results if r.candidate.release_group_mbid == "rg-tier2b")
        self.assertIn("label_affinity", label_result.explanation["connection_types"])
        self.assertGreater(label_result.final_score, 0)
        self.assertLess(label_result.final_score, tier2b_result.final_score)

    def test_sorted_descending(self):
        seeds = [_seed()]
        edge_2a = _edge(target_mbid="artist-2a", target_name="A", tier=TIER_2A, connection_strength=0.9)
        edge_4 = _edge(target_mbid="artist-4", target_name="B", relation_type="lastfm_tag", tier=TIER_4, connection_strength=0.2)
        c1 = _candidate(rg_mbid="rg-a", artist_mbid="artist-2a", artist_name="A", tier=TIER_2A)
        c2 = _candidate(rg_mbid="rg-b", artist_mbid="artist-4", artist_name="B", tier=TIER_4)
        results = score_candidates([c1, c2], seeds, [edge_2a, edge_4])
        scores = [r.score_normalized for r in results]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_all_scores_in_range(self):
        seeds = [_seed()]
        edges = [_edge()]
        candidates = [_candidate()]
        results = score_candidates(candidates, seeds, edges)
        for r in results:
            self.assertGreaterEqual(r.score_normalized, 0.0)
            self.assertLessEqual(r.score_normalized, 100.0)

    def test_multi_seed_unknown_uses_multiple_paths(self):
        seeds = [
            _seed(mbid=SEED_MBID, name="Massive Attack", weight=1.0),
            _seed(mbid=SEED_MBID_2, name="Portishead", weight=0.8),
        ]
        edges = [
            _edge(source_mbid=SEED_MBID, source_name="Massive Attack", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=0.9),
            _edge(source_mbid=SEED_MBID_2, source_name="Portishead", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=0.8),
        ]

        results = score_candidates([_candidate(tier=TIER_3)], seeds, edges)

        self.assertEqual(results[0].explanation["seed_artists"], ["Massive Attack", "Portishead"])
        self.assertGreater(results[0].final_score, 0.45 * 0.9 * 0.85)

    def test_high_potential_unknown_can_outrank_low_weight_tier1_outlier(self):
        unknown_mbid = ARTIST_MBID
        outlier_mbid = "f6a7b8c9-d0e1-2345-fabc-456789012345"
        seeds = [
            _seed(mbid=SEED_MBID, name="Massive Attack", weight=0.5),
            _seed(mbid=SEED_MBID_2, name="Portishead", weight=0.5),
            _seed(mbid=SEED_MBID_3, name="Burial", weight=0.5),
            _seed(mbid=outlier_mbid, name="One Track Outlier", weight=0.25),
        ]
        edges = [
            _edge(source_mbid=SEED_MBID, source_name="Massive Attack", target_mbid=unknown_mbid, target_name="High Potential", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=1.0),
            _edge(source_mbid=SEED_MBID_2, source_name="Portishead", target_mbid=unknown_mbid, target_name="High Potential", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=1.0),
            _edge(source_mbid=SEED_MBID_3, source_name="Burial", target_mbid=unknown_mbid, target_name="High Potential", relation_type="lastfm_similar", tier=TIER_3, connection_strength=1.0),
        ]
        unknown = _candidate(rg_mbid="rg-unknown", artist_mbid=unknown_mbid, artist_name="High Potential", tier=TIER_3)
        outlier = _candidate(rg_mbid="rg-outlier", artist_mbid=outlier_mbid, artist_name="One Track Outlier", tier=TIER_1)

        results = score_candidates([unknown, outlier], seeds, edges)
        unknown_result = next(r for r in results if r.candidate.release_group_mbid == "rg-unknown")
        outlier_result = next(r for r in results if r.candidate.release_group_mbid == "rg-outlier")

        self.assertGreaterEqual(unknown_result.final_score, outlier_result.final_score)

    def test_stronger_listenbrainz_social_proof_ranks_higher(self):
        seeds = [_seed()]
        strong_edge = _edge(target_mbid="strong-lb", target_name="Strong LB", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=0.93)
        weak_edge = _edge(target_mbid="weak-lb", target_name="Weak LB", relation_type="listenbrainz_similar", tier=TIER_3, connection_strength=0.25)
        strong = _candidate(rg_mbid="rg-strong", artist_mbid="strong-lb", artist_name="Strong LB", tier=TIER_3)
        weak = _candidate(rg_mbid="rg-weak", artist_mbid="weak-lb", artist_name="Weak LB", tier=TIER_3)

        results = score_candidates([weak, strong], seeds, [weak_edge, strong_edge])

        self.assertEqual(results[0].candidate.release_group_mbid, "rg-strong")


class TestModifiers(unittest.TestCase):

    def test_reissue_penalty_lowers_score(self):
        seeds = [_seed()]
        edges = [_edge()]
        c_clean = _candidate(rg_mbid="rg-clean")
        c_reissue = _candidate(rg_mbid="rg-reissue", possible_reissue=True)
        results = score_candidates([c_clean, c_reissue], seeds, edges)
        clean_score = next(r for r in results if r.candidate.release_group_mbid == "rg-clean").score_normalized
        reissue_score = next(r for r in results if r.candidate.release_group_mbid == "rg-reissue").score_normalized
        self.assertGreater(clean_score, reissue_score)

    def test_uncertain_type_penalty_applied(self):
        seeds = [_seed()]
        edges = [_edge()]
        c_normal = _candidate(rg_mbid="rg-normal")
        c_uncertain = _candidate(rg_mbid="rg-uncertain", uncertain_release_type=True)
        results = score_candidates([c_normal, c_uncertain], seeds, edges)
        normal_score = next(r for r in results if r.candidate.release_group_mbid == "rg-normal").score_normalized
        uncertain_score = next(r for r in results if r.candidate.release_group_mbid == "rg-uncertain").score_normalized
        self.assertGreater(normal_score, uncertain_score)


class TestMultiSeedDiminishingReturns:

    @pytest.mark.parametrize("scores,expected", [
        ([0.8], 0.8),
        ([0.8, 0.6], 0.8 * 1.0 + 0.6 * 0.7),
        ([1.0, 0.5, 0.3], 1.0 + 0.5 * 0.7 + 0.3 * 0.4),
        ([1.0, 0.5, 0.3, 0.2, 0.1], 1.0 + 0.5 * 0.7 + 0.3 * 0.4 + 0.2 * 0.2 + 0.1 * 0.2),
        ([], 0.0),
    ])
    def test_diminishing_returns(self, scores, expected):
        assert _apply_diminishing_returns(scores) == pytest.approx(expected, abs=1e-6)

    def test_multi_seed_adds_to_score(self):
        one_seed = _apply_diminishing_returns([0.8])
        two_seeds = _apply_diminishing_returns([0.8, 0.6])
        assert two_seeds > one_seed


class TestConfidenceLabel:

    @pytest.mark.parametrize("score,expected", [
        (80, "High"),
        (75, "High"),
        (40, "Medium"),
        (74, "Medium"),
        (39, "Low"),
        (0, "Low"),
    ])
    def test_confidence_label(self, score, expected):
        assert _confidence_label(score) == expected


class TestExplanationStructure(unittest.TestCase):

    def test_explanation_contains_required_keys(self):
        seeds = [_seed()]
        edges = [_edge()]
        results = score_candidates([_candidate()], seeds, edges)
        exp = results[0].explanation
        self.assertIn("seed_artists", exp)
        self.assertIn("connection_types", exp)
        self.assertIn("tier", exp)

    def test_explanation_seed_artist_populated(self):
        seeds = [_seed(name="Massive Attack")]
        edges = [_edge(source_name="Massive Attack")]
        results = score_candidates([_candidate()], seeds, edges)
        self.assertIn("Massive Attack", results[0].explanation["seed_artists"])

    def test_tier1_explanation_connection_type_is_direct(self):
        seeds = [_seed(mbid=SEED_MBID)]
        c = _candidate(artist_mbid=SEED_MBID, artist_name="Massive Attack", tier=TIER_1)
        results = score_candidates([c], seeds, [])
        self.assertIn("direct_seed", results[0].explanation["connection_types"])


if __name__ == "__main__":
    unittest.main()
