from __future__ import annotations

import unittest
import tempfile
from pathlib import Path

from mamonia.analysis import build_taste_profile, build_taste_profile_reusing_artists, infer_artist_counts_and_clusters
from mamonia.models import ArtistProfile, TasteProfile
from mamonia.models import InputTrack
from mamonia.storage import Storage


class AnalysisTests(unittest.TestCase):
    def test_artist_counts_include_collaborators_and_cluster_primary_artist(self) -> None:
        tracks = [
            InputTrack(artist="A", track="1", artists=["A", "B"]),
            InputTrack(artist="A", track="2", artists=["A"]),
            InputTrack(artist="C", track="3", artists=["C"]),
            InputTrack(artist="A", track="4", artists=["A"]),
        ]
        stats = infer_artist_counts_and_clusters(tracks)

        self.assertEqual(stats["a"][1], 3)
        self.assertEqual(stats["b"][1], 1)
        self.assertGreater(stats["a"][2], 0)

    def test_profile_keeps_one_off_artists_while_ranking_frequent_artists_higher(self) -> None:
        tracks = [
            InputTrack(artist="Frequent", track="1", artists=["Frequent"]),
            InputTrack(artist="Frequent", track="2", artists=["Frequent"]),
            InputTrack(artist="Frequent", track="3", artists=["Frequent"]),
            InputTrack(artist="Rare One", track="4", artists=["Rare One"]),
            InputTrack(artist="Rare Two", track="5", artists=["Rare Two"]),
        ]

        profile = build_taste_profile(tracks, max_artists=1)

        self.assertEqual(profile.n_artists, 3)
        self.assertEqual({artist.name for artist in profile.artists}, {"Frequent", "Rare One", "Rare Two"})
        rare = [artist for artist in profile.artists if artist.name == "Rare One"][0]
        frequent = [artist for artist in profile.artists if artist.name == "Frequent"][0]
        self.assertGreater(frequent.affinity_score, rare.affinity_score)
        self.assertIn("Rare One", [artist.name for artist in profile.top_artists])

    def test_delta_profile_reuses_existing_artist_enrichment(self) -> None:
        tracks = [
            InputTrack(artist="Known", track="1", artists=["Known"]),
            InputTrack(artist="Known", track="2", artists=["Known"]),
            InputTrack(artist="New", track="3", artists=["New"]),
        ]
        existing = TasteProfile(
            artists=[
                ArtistProfile(
                    name="Known",
                    playlist_count=1,
                    affinity_score=2,
                    genres=["saved-genre"],
                    tags=["saved-tag"],
                    similar_artists=["Saved Neighbor"],
                )
            ],
            n_artists=1,
        )
        spotify = _CountingSpotify()

        profile = build_taste_profile_reusing_artists(tracks, existing_profile=existing, spotify=spotify, max_artists=10)

        known = [artist for artist in profile.artists if artist.name == "Known"][0]
        self.assertEqual(known.playlist_count, 2)
        self.assertEqual(known.genres, ["saved-genre"])
        self.assertEqual(spotify.searched, ["New"])

    def test_profile_hydrates_artist_enrichment_from_storage_before_provider_calls(self) -> None:
        tracks = [InputTrack(artist="Cached Artist", track="1", artists=["Cached Artist"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_artist_enrichment(
                provider="spotify",
                artist_name="Cached Artist",
                provider_artist_id="sp-cached",
                payload={"id": "sp-cached", "genres": ["stored-genre"]},
            )
            spotify = _StorageSpotify(storage, {"Cached Artist": {"id": "fresh", "genres": ["fresh-genre"]}})

            profile = build_taste_profile(tracks, spotify=spotify, max_artists=10)
            storage.close()

        artist = profile.artists[0]
        self.assertEqual(artist.spotify_id, "sp-cached")
        self.assertEqual(artist.genres, ["stored-genre"])
        self.assertEqual(spotify.searched, [])

    def test_profile_stores_new_artist_enrichment_for_reuse(self) -> None:
        tracks = [InputTrack(artist="Fresh Artist", track="1", artists=["Fresh Artist"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            spotify = _StorageSpotify(storage, {"Fresh Artist": {"id": "sp-fresh", "genres": ["fresh-genre"]}})

            profile = build_taste_profile(tracks, spotify=spotify, max_artists=10)
            stored = storage.get_artist_enrichment(provider="spotify", artist_name="Fresh Artist")
            storage.close()

        artist = profile.artists[0]
        self.assertEqual(artist.spotify_id, "sp-fresh")
        self.assertEqual(artist.genres, ["fresh-genre"])
        self.assertEqual(spotify.searched, ["Fresh Artist"])
        self.assertEqual(stored["status"], "success")
        self.assertEqual(stored["payload"]["id"], "sp-fresh")

    def test_profile_uses_deezer_artist_details_for_genres(self) -> None:
        tracks = [InputTrack(artist="Hania Rani", track="1", artists=["Hania Rani"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            deezer = _StorageDeezer(
                storage,
                search_responses={"Hania Rani": {"id": 12566278, "name": "Hania Rani"}},
                detail_responses={12566278: {"genres": ["modern classical", "ambient"]}},
            )

            profile = build_taste_profile(tracks, deezer=deezer, max_artists=10)
            stored = storage.get_artist_enrichment(provider="deezer", artist_name="Hania Rani")
            storage.close()

        artist = profile.artists[0]
        self.assertEqual(artist.genres, ["modern classical", "ambient"])
        self.assertEqual(deezer.searched, ["Hania Rani"])
        self.assertEqual(deezer.detailed, [12566278])
        self.assertEqual(stored["status"], "success")
        self.assertEqual(stored["payload"]["genres"], ["modern classical", "ambient"])


class _CountingSpotify:
    def __init__(self) -> None:
        self.searched: list[str] = []

    def search_artist(self, name: str):
        self.searched.append(name)
        return None


class _StorageSpotify:
    def __init__(self, storage: Storage, responses: dict[str, dict]) -> None:
        self.storage = storage
        self.responses = responses
        self.searched: list[str] = []

    def search_artist(self, name: str):
        self.searched.append(name)
        return self.responses.get(name)


class _StorageDeezer:
    available = True

    def __init__(self, storage: Storage, search_responses: dict[str, dict], detail_responses: dict[int, dict]) -> None:
        self.storage = storage
        self.search_responses = search_responses
        self.detail_responses = detail_responses
        self.searched: list[str] = []
        self.detailed: list[int] = []

    def search_artist(self, name: str):
        self.searched.append(name)
        return self.search_responses.get(name)

    def artist_details(self, artist_id: int):
        self.detailed.append(artist_id)
        return self.detail_responses.get(artist_id)


if __name__ == "__main__":
    unittest.main()
