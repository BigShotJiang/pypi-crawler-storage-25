"""Tests for mamonia/canonicalization.py — §2 resolution chain."""

from __future__ import annotations

import unittest
import tempfile
from pathlib import Path

from mamonia.canonicalization import (
    CONFIDENCE_ARTIST_ONLY,
    CONFIDENCE_FUZZY,
    CONFIDENCE_ISRC,
    CONFIDENCE_TITLE_DURATION,
    CONFIDENCE_UNRESOLVED,
    CONFIDENCE_UPC,
    resolve_track,
    resolve_tracks,
)
from mamonia.models import CanonicalTrack, InputTrack
from mamonia.storage import Storage


# ---------------------------------------------------------------------------
# Fake providers
# ---------------------------------------------------------------------------

class FakeMB:
    """Minimal MusicBrainz stub covering the three new lookup methods."""

    def lookup_recording_by_isrc(self, isrc: str) -> dict | None:
        if isrc == "GBAYE0601498":
            return {
                "recording_mbid": "rec-mbid-1",
                "release_mbid": "rel-mbid-1",
                "release_group_mbid": "rg-mbid-1",
                "artist_mbid": "artist-mbid-1",
                "artist_name": "Massive Attack",
            }
        return None

    def lookup_release_by_upc(self, upc: str) -> dict | None:
        if upc == "724384960025":
            return {
                "release_mbid": "rel-mbid-2",
                "release_group_mbid": "rg-mbid-2",
                "artist_mbid": "artist-mbid-2",
                "artist_name": "Portishead",
            }
        return None

    def search_recording(self, artist: str, title: str, duration_ms: int | None = None) -> dict | None:
        if artist == "Burial" and title == "Archangel":
            return {
                "recording_mbid": "rec-mbid-3",
                "release_mbid": "rel-mbid-3",
                "release_group_mbid": "rg-mbid-3",
                "artist_mbid": "artist-mbid-3",
                "artist_name": "Burial",
                "duration_ms": 290000,
            }
        if artist == "Ghost" and title == "Unknown":
            return {
                "recording_mbid": "rec-mbid-4",
                "release_mbid": None,
                "release_group_mbid": None,
                "artist_mbid": "artist-mbid-ghost",
                "artist_name": "Ghost",
                "duration_ms": 200000,
            }
        return None

    def search_releases(self, query: str, limit: int = 25) -> list[dict]:
        return []

    def search_artist(self, name: str) -> dict | None:
        if name == "Tricky":
            return {"id": "tricky-mbid", "name": "Tricky"}
        return None


class EmptyMB:
    """Provider that returns nothing — simulates unresolved track."""
    def lookup_recording_by_isrc(self, isrc): return None
    def lookup_release_by_upc(self, upc): return None
    def search_recording(self, artist, title, duration_ms=None): return None
    def search_releases(self, query, limit=25): return []
    def search_artist(self, name): return None


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestResolveTrackISRC(unittest.TestCase):

    def test_isrc_resolution_sets_mbids_and_confidence(self):
        track = InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498")
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.resolution_method, "isrc")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_ISRC)
        self.assertEqual(result.recording_mbid, "rec-mbid-1")
        self.assertEqual(result.release_group_mbid, "rg-mbid-1")
        self.assertEqual(result.artist_mbid, "artist-mbid-1")
        self.assertEqual(result.artist_name_canonical, "Massive Attack")

    def test_isrc_preserves_input_fields(self):
        track = InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498", source_platform="spotify")
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.input_artist, "Massive Attack")
        self.assertEqual(result.input_track, "Teardrop")
        self.assertEqual(result.source_platform, "spotify")
        self.assertEqual(result.isrc, "GBAYE0601498")


class TestResolveTrackUPC(unittest.TestCase):

    def test_upc_resolution_when_no_isrc(self):
        track = InputTrack(artist="Portishead", track="Sour Times", upc="724384960025")
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.resolution_method, "upc")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_UPC)
        self.assertEqual(result.release_group_mbid, "rg-mbid-2")
        self.assertEqual(result.artist_name_canonical, "Portishead")

    def test_isrc_takes_priority_over_upc(self):
        track = InputTrack(
            artist="Massive Attack", track="Teardrop",
            isrc="GBAYE0601498", upc="724384960025"
        )
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.resolution_method, "isrc")
        self.assertEqual(result.recording_mbid, "rec-mbid-1")


class TestResolveTrackTitleDuration(unittest.TestCase):

    def test_title_plus_duration_within_window(self):
        track = InputTrack(artist="Burial", track="Archangel", duration_ms=291000)  # 1 s off
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.resolution_method, "title_duration")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_TITLE_DURATION)
        self.assertEqual(result.recording_mbid, "rec-mbid-3")

    def test_title_duration_rejected_when_delta_exceeds_5s(self):
        track = InputTrack(artist="Burial", track="Archangel", duration_ms=200000)  # 90 s off
        result = resolve_track(track, musicbrainz=FakeMB())
        # Falls through to fuzzy (no album, no UPC, no ISRC)
        self.assertIn(result.resolution_method, ("fuzzy", "artist_only", "unresolved"))
        self.assertLess(result.match_confidence, CONFIDENCE_TITLE_DURATION)


class TestResolveTrackFuzzy(unittest.TestCase):

    def test_fuzzy_fallback_when_no_duration(self):
        track = InputTrack(artist="Burial", track="Archangel")
        result = resolve_track(track, musicbrainz=FakeMB())
        # No ISRC, no UPC, no duration → falls to fuzzy
        self.assertEqual(result.resolution_method, "fuzzy")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_FUZZY)


class TestResolveTrackArtistOnly(unittest.TestCase):

    def test_artist_only_when_track_unresolvable(self):
        track = InputTrack(artist="Tricky", track="")
        result = resolve_track(track, musicbrainz=FakeMB())
        self.assertEqual(result.resolution_method, "artist_only")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_ARTIST_ONLY)
        self.assertEqual(result.artist_mbid, "tricky-mbid")
        self.assertEqual(result.artist_name_canonical, "Tricky")


class TestResolveTrackUnresolved(unittest.TestCase):

    def test_unresolved_track_is_kept_not_dropped(self):
        track = InputTrack(artist="Unknown Artist", track="Unknown Track")
        result = resolve_track(track, musicbrainz=EmptyMB())
        self.assertEqual(result.resolution_method, "unresolved")
        self.assertAlmostEqual(result.match_confidence, CONFIDENCE_UNRESOLVED)
        self.assertIsInstance(result, CanonicalTrack)

    def test_unresolved_without_providers(self):
        track = InputTrack(artist="Some Artist", track="Some Track", isrc="FAKE0000001")
        result = resolve_track(track, musicbrainz=None)
        self.assertEqual(result.resolution_method, "unresolved")


class TestResolveTracks(unittest.TestCase):

    def test_resolve_list_preserves_order(self):
        tracks = [
            InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498"),
            InputTrack(artist="Unknown Artist", track="Unknown Track"),
        ]
        results = resolve_tracks(tracks, musicbrainz=FakeMB())
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0].resolution_method, "isrc")
        self.assertEqual(results[1].resolution_method, "unresolved")

    def test_cache_miss_resolves_and_persists(self):
        track = InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498")
        stats = {}
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            results = resolve_tracks([track], musicbrainz=FakeMB(), storage=storage, cache_stats=stats)
            cached = storage.get_canonical_track(track)
            storage.close()

        self.assertEqual(stats["misses"], 1)
        self.assertEqual(stats.get("hits", 0), 0)
        self.assertEqual(results[0].recording_mbid, "rec-mbid-1")
        self.assertIsNotNone(cached)
        self.assertEqual(cached.recording_mbid, "rec-mbid-1")

    def test_cache_hit_avoids_provider_calls(self):
        track = InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498")
        stats = {}
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            resolve_tracks([track], musicbrainz=FakeMB(), storage=storage)
            results = resolve_tracks([track], musicbrainz=EmptyMB(), storage=storage, cache_stats=stats)
            storage.close()

        self.assertEqual(stats["hits"], 1)
        self.assertEqual(stats.get("misses", 0), 0)
        self.assertEqual(results[0].resolution_method, "isrc")
        self.assertEqual(results[0].recording_mbid, "rec-mbid-1")

    def test_force_refresh_bypasses_cache_and_updates_entry(self):
        track = InputTrack(artist="Massive Attack", track="Teardrop", isrc="GBAYE0601498")
        stats = {}
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            resolve_tracks([track], musicbrainz=FakeMB(), storage=storage)
            results = resolve_tracks(
                [track],
                musicbrainz=EmptyMB(),
                storage=storage,
                force_refresh=True,
                cache_stats=stats,
            )
            cached = storage.get_canonical_track(track)
            storage.close()

        self.assertEqual(stats["misses"], 1)
        self.assertEqual(stats.get("hits", 0), 0)
        self.assertEqual(results[0].resolution_method, "unresolved")
        self.assertEqual(cached.resolution_method, "unresolved")

    def test_multi_artist_tracks_use_one_cached_result_per_artist(self):
        track = InputTrack(
            artist="Massive Attack",
            track="Teardrop",
            artists=["Massive Attack", "Tricky"],
            isrc="GBAYE0601498",
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            results = resolve_tracks([track], musicbrainz=FakeMB(), storage=storage)
            storage.close()

        self.assertEqual(len(results), 2)
        self.assertEqual([result.input_artist for result in results], ["Massive Attack", "Tricky"])


class TestCanonicalTrackModel(unittest.TestCase):

    def test_platform_ids_populated_from_input(self):
        track = InputTrack(
            artist="Artist", track="Track",
            spotify_track_id="spotify123",
            tidal_track_id="tidal456",
        )
        result = resolve_track(track, musicbrainz=EmptyMB())
        self.assertEqual(result.platform_ids.get("spotify"), "spotify123")
        self.assertEqual(result.platform_ids.get("tidal"), "tidal456")

    def test_confidence_ordering(self):
        self.assertGreater(CONFIDENCE_ISRC, CONFIDENCE_UPC)
        self.assertGreaterEqual(CONFIDENCE_UPC, CONFIDENCE_TITLE_DURATION)
        self.assertGreater(CONFIDENCE_TITLE_DURATION, CONFIDENCE_FUZZY)
        self.assertGreater(CONFIDENCE_FUZZY, CONFIDENCE_ARTIST_ONLY)
        self.assertGreater(CONFIDENCE_ARTIST_ONLY, CONFIDENCE_UNRESOLVED)


if __name__ == "__main__":
    unittest.main()
