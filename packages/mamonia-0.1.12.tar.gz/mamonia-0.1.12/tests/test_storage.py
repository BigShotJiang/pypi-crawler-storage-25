from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from mamonia.discovery import track_keys_from_input
from mamonia.models import ArtistProfile, CanonicalTrack, InputTrack, ReleaseRecommendation, ReleaseTrack, TasteProfile
from mamonia.storage import SCHEMA_VERSION, Storage, artist_enrichment_key, canonical_release_key, canonical_track_cache_key, track_enrichment_key


class StorageTests(unittest.TestCase):
    def test_canonical_release_key_prefers_stable_ids(self) -> None:
        self.assertEqual(
            canonical_release_key("A", "B", "2026-01-01", mb_release_group_id="mbid", spotify_album_id="spid"),
            "mb-release-group:mbid",
        )
        self.assertEqual(
            canonical_release_key("A", "B", "2026-01-01", spotify_album_id="spid"),
            "spotify-album:spid",
        )
        self.assertEqual(canonical_release_key("The Artist", "New Album!", "2026-01-01"), "the artist new album 2026")
        self.assertEqual(
            canonical_release_key("The Artist", "New Album (Deluxe Edition)", "2026-01-01"),
            "the artist new album 2026",
        )

    def test_heard_matching_by_mbid_spotify_id_and_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist", "Release", "2026-02-03", mb_release_group_id="rg-1")
            self.assertTrue(storage.is_heard("Different", "Different", mb_release_group_id="rg-1"))

            storage.add_heard("Other Artist", "Other Release", "2026", spotify_album_id="sp-1")
            self.assertTrue(storage.is_heard("Different", "Different", spotify_album_id="sp-1"))

            storage.add_heard("Młody Artist", "Zażółć Release", "2026-04")
            self.assertTrue(storage.is_heard("Mlody Artist", "Zazolc Release", "2026-04"))
            storage.add_heard("Artist", "Album (Deluxe Edition)", "2026-04-01")
            self.assertTrue(storage.is_heard("Artist", "Album", "2026-04-01"))
            self.assertTrue(storage.is_heard("Artist", "Album - Remastered 2026", "2026-04-01"))
            self.assertTrue(storage.is_heard("Artist", "Album (20th Anniversary Edition)", "2026-04-01"))
            self.assertTrue(storage.is_heard("Artist", "Album [Japanese Edition]", "2026-04-01"))
            self.assertTrue(storage.is_heard("Artist", "Album (US Version)", "2026-04-01"))
            self.assertFalse(storage.is_heard("Artist", "Another Album", "2026-04-01"))
            self.assertFalse(storage.is_heard("Artist", "Album", "2025-04-01"))
            storage.close()

    def test_heard_fallback_matches_when_one_side_has_unknown_year(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist", "Album", release_date=None)
            self.assertTrue(storage.is_heard("Artist", "Album", "2026-04-01"))

            storage.add_heard("Artist 2", "Album 2", "2026-04-01")
            self.assertTrue(storage.is_heard("Artist 2", "Album 2", None))
            storage.close()

    def test_add_heard_backfills_missing_metadata_on_existing_entry(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")

            # Simulate an early heard insert with sparse metadata.
            entry_id = storage.add_heard(
                "Artist",
                "Release",
                release_date=None,
                spotify_album_id="sp-1",
            )

            # Later stage knows the date/type for the same canonical key.
            same_entry_id = storage.add_heard(
                "Artist",
                "Release",
                release_date="2026-04-22",
                release_type="single",
                spotify_album_id="sp-1",
            )

            self.assertEqual(entry_id, same_entry_id)
            row = storage.conn.execute(
                """
                SELECT release_date, release_year, release_type, mb_release_group_id, spotify_album_id
                FROM heard_releases
                WHERE id = ?
                """,
                (entry_id,),
            ).fetchone()
            storage.close()

            self.assertEqual(row["release_date"], "2026-04-22")
            self.assertEqual(row["release_year"], 2026)
            self.assertEqual(row["release_type"], "single")
            self.assertIsNone(row["mb_release_group_id"])
            self.assertEqual(row["spotify_album_id"], "sp-1")

    def test_backfill_heard_recommendation_updates_existing_spotify_match(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            entry_id = storage.add_heard(
                "Artist",
                "Release",
                release_date=None,
                spotify_album_id="sp-1",
            )
            rec = type(
                "Rec",
                (),
                {
                    "artist": "Artist",
                    "title": "Release",
                    "release_date": "2026-04-22",
                    "release_type": "single",
                    "mb_release_group_id": "rg-1",
                    "spotify_album_id": "sp-1",
                },
            )()

            updated = storage.backfill_heard_recommendation(rec)  # type: ignore[arg-type]
            row = storage.conn.execute(
                """
                SELECT release_date, release_year, release_type, mb_release_group_id, spotify_album_id
                FROM heard_releases
                WHERE id = ?
                """,
                (entry_id,),
            ).fetchone()
            storage.close()

            self.assertGreaterEqual(updated, 1)
            self.assertEqual(row["release_date"], "2026-04-22")
            self.assertEqual(row["release_year"], 2026)
            self.assertEqual(row["release_type"], "single")
            self.assertEqual(row["mb_release_group_id"], "rg-1")
            self.assertEqual(row["spotify_album_id"], "sp-1")

    def test_heard_match_reason_reports_mbid_spotify_and_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist", "Release", "2026-02-03", mb_release_group_id="rg-1")
            storage.add_heard("Artist", "Release 2", "2026-02-03", spotify_album_id="sp-1")
            storage.add_heard("Artist", "Release 3 (Deluxe Edition)", "2026-02-03")
            self.assertEqual(
                storage.heard_match_reason("Different", "Different", mb_release_group_id="rg-1"),
                "mbid",
            )
            self.assertEqual(
                storage.heard_match_reason("Different", "Different", spotify_album_id="sp-1"),
                "spotify_album",
            )
            self.assertEqual(
                storage.heard_match_reason("Artist", "Release 3", "2026-02-03"),
                "fallback_title",
            )
            storage.close()

    def test_heard_recommendation_matches_by_track_isrc_even_across_different_release_title(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            prior = ReleaseRecommendation(
                artist="Puscifer",
                title="Self Evident",
                release_date="2026-05-01",
                tracks=[ReleaseTrack(title="Self Evident", artists="Puscifer", isrc="QMRSZ2501716")],
            )
            storage.add_heard_recommendation(prior)

            incoming = ReleaseRecommendation(
                artist="Puscifer",
                title="ImpetuoUs",
                release_date="2026-05-01",
                tracks=[ReleaseTrack(title="Self Evident", artists="Puscifer", isrc="QMRSZ2501716")],
            )
            reason = storage.heard_match_reason_recommendation(incoming)
            storage.close()

            self.assertEqual(reason, "track_isrc")

    def test_heard_recommendation_track_identity_does_not_fallback_to_title(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            prior = ReleaseRecommendation(
                artist="Puscifer",
                title="Self Evident",
                release_date="2026-05-01",
                tracks=[ReleaseTrack(title="Self Evident", artists="Puscifer")],
            )
            storage.add_heard_recommendation(prior)

            incoming = ReleaseRecommendation(
                artist="Puscifer",
                title="ImpetuoUs",
                release_date="2026-05-01",
                tracks=[ReleaseTrack(title="Self Evident", artists="Puscifer")],
            )
            reason = storage.heard_match_reason_recommendation(incoming)
            storage.close()

            self.assertIsNone(reason)

    def test_repair_heard_identity_bridges_backfills_ids_for_same_canonical_key(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist", "Release", release_date=None, spotify_album_id="sp-1")
            storage.add_heard("Artist", "Release", release_date=None, mb_release_group_id="rg-1")
            updated = storage._repair_heard_identity_bridges()
            row = storage.conn.execute(
                """
                SELECT mb_release_group_id, spotify_album_id
                FROM heard_releases
                WHERE normalized_artist = ? AND normalized_title = ?
                ORDER BY id ASC
                LIMIT 1
                """,
                ("artist", "release"),
            ).fetchone()
            storage.close()

            self.assertGreaterEqual(updated, 1)
            self.assertEqual(row["mb_release_group_id"], "rg-1")
            self.assertEqual(row["spotify_album_id"], "sp-1")

    def test_remove_heard(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            entry_id = storage.add_heard("Artist", "Release", "2026")
            self.assertTrue(storage.remove_heard(entry_id))
            self.assertFalse(storage.is_heard("Artist", "Release", "2026"))
            storage.close()

    def test_clear_heard(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist One", "Release One", "2026")
            storage.add_heard("Artist Two", "Release Two", "2026")
            storage.add_heard("Artist Three", "Release Three", "2026")
            count = storage.clear_heard()
            self.assertEqual(count, 3)
            self.assertEqual(len(storage.list_heard()), 0)
            storage.close()

    def test_import_heard_file_csv_uses_album_as_release_title(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            csv_path = Path(tmp) / "heard.csv"
            csv_path.write_text(
                "\n".join(
                    [
                        "Track name,Artist name,Album",
                        "Song A,Artist A,Album A",
                        "Song B,Artist B,",
                    ]
                ),
                encoding="utf-8",
            )

            imported = storage.import_heard_file(csv_path)
            rows = storage.list_heard()
            storage.close()

            self.assertEqual(imported, 2)
            by_artist = {row["artist"]: row["title"] for row in rows}
            self.assertEqual(by_artist["Artist A"], "Album A")
            self.assertEqual(by_artist["Artist B"], "Song B")

    def test_storage_context_manager_closes_connection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "mamonia.sqlite"
            with Storage(db_path) as storage:
                storage.add_heard("Artist", "Release", "2026")

            with self.assertRaises(Exception):
                storage.list_heard()

    def test_diagnostic_counts_reports_local_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.add_heard("Artist", "Release", "2026")
            storage.set_cache("provider", "key", {"ok": True}, ttl_seconds=60)
            counts = storage.diagnostic_counts()
            storage.close()

        self.assertEqual(counts["quick_check"], "ok")
        self.assertEqual(counts["schema_version"], SCHEMA_VERSION)
        self.assertEqual(counts["heard_releases"], 1)
        self.assertEqual(counts["api_cache_entries"], 1)
        self.assertEqual(counts["artist_enrichment_entries"], 0)
        self.assertEqual(counts["track_enrichment_entries"], 0)

    def test_cache_diagnostics_tracks_hits_and_misses_per_provider(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache("spotify", "present", {"ok": True}, ttl_seconds=60)

            self.assertEqual(storage.get_cache("spotify", "present"), {"ok": True})
            self.assertIsNone(storage.get_cache("spotify", "missing"))
            stats = storage.cache_diagnostics()
            storage.close()

        self.assertEqual(stats["spotify"]["entries"], 1)
        self.assertEqual(stats["spotify"]["hits"], 1)
        self.assertEqual(stats["spotify"]["misses"], 1)
        self.assertEqual(stats["musicbrainz"]["hits"], 0)

    def test_clear_cache_removes_entries_and_cache_stats(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache("spotify", "present", {"ok": True}, ttl_seconds=60)
            storage.get_cache("spotify", "present")
            storage.get_cache("spotify", "missing")

            count = storage.clear_cache()
            stats = storage.cache_diagnostics()
            counts = storage.diagnostic_counts()
            storage.close()

        self.assertEqual(count, 1)
        self.assertEqual(counts["api_cache_entries"], 0)
        self.assertEqual(stats["spotify"]["entries"], 0)
        self.assertEqual(stats["spotify"]["hits"], 0)
        self.assertEqual(stats["spotify"]["misses"], 0)

    def test_clear_provider_cache_removes_only_provider_entries_and_stats(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.set_cache("spotify", "present", {"ok": True}, ttl_seconds=60)
            storage.set_cache("lastfm", "present", {"ok": True}, ttl_seconds=60)
            storage.get_cache("spotify", "present")
            storage.get_cache("lastfm", "present")

            count = storage.clear_provider_cache("spotify")
            stats = storage.cache_diagnostics()
            counts = storage.diagnostic_counts()
            storage.close()

        self.assertEqual(count, 1)
        self.assertEqual(counts["api_cache_entries"], 1)
        self.assertEqual(stats["spotify"]["entries"], 0)
        self.assertEqual(stats["spotify"]["hits"], 0)
        self.assertEqual(stats["lastfm"]["entries"], 1)
        self.assertEqual(stats["lastfm"]["hits"], 1)

    def test_artist_enrichment_key_prefers_name_with_provider_id_fallback(self) -> None:
        self.assertEqual(
            artist_enrichment_key(artist_name="Młody Artist", provider_artist_id="sp-artist"),
            "artist:mlody artist",
        )
        self.assertEqual(
            artist_enrichment_key(provider_artist_id="sp-artist"),
            "provider-artist:sp-artist",
        )

    def test_track_enrichment_key_prefers_stable_ids(self) -> None:
        self.assertEqual(
            track_enrichment_key(
                artist="Artist",
                title="Song",
                isrc="US-ABC-26-00001",
                spotify_track_id="sp-track",
                tidal_track_id="td-track",
            ),
            "isrc:us abc 26 00001",
        )
        self.assertEqual(track_enrichment_key(artist="Artist", title="Song", spotify_track_id="sp-track"), "spotify:track:sp-track")
        self.assertEqual(track_enrichment_key(artist="Artist", title="Song", tidal_track_id="td-track"), "tidal:track:td-track")
        self.assertEqual(track_enrichment_key(artist="Młody Artist", title="Zażółć Song"), "metadata:mlody artist|zazolc song")

    def test_canonical_track_cache_key_uses_album_metadata_fallback(self) -> None:
        first = InputTrack(artist="Młody Artist", track="Zażółć Song", album="Blue Album")
        second = InputTrack(artist="Mlody Artist", track="Zazolc Song", album="Blue Album")
        other_album = InputTrack(artist="Mlody Artist", track="Zazolc Song", album="Red Album")

        self.assertEqual(canonical_track_cache_key(first), canonical_track_cache_key(second))
        self.assertNotEqual(canonical_track_cache_key(first), canonical_track_cache_key(other_album))
        self.assertTrue(canonical_track_cache_key(first).startswith("canonical-track-v1:metadata:"))

    def test_canonical_track_save_load_roundtrip(self) -> None:
        track = InputTrack(artist="Artist", track="Song", album="Album", spotify_track_id="sp-track")
        canonical = CanonicalTrack(
            recording_mbid="rec-1",
            release_mbid="rel-1",
            release_group_mbid="rg-1",
            artist_mbid="artist-1",
            artist_name_canonical="Artist",
            input_artist="Artist",
            input_track="Song",
            input_album="Album",
            source_platform="spotify",
            duration_ms=123000,
            isrc="USABC2600001",
            upc="1234567890",
            playlist_position=4,
            match_confidence=1.0,
            resolution_method="isrc",
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_canonical_track(track, canonical)
            loaded = storage.get_canonical_track(track)
            storage.close()

        self.assertEqual(saved["provider"], "canonical")
        self.assertEqual(saved["payload"]["cache_version"], "canonical-track-v1")
        self.assertEqual(loaded.recording_mbid, "rec-1")
        self.assertEqual(loaded.resolution_method, "isrc")

    def test_artist_enrichment_save_update_load_and_negative_status(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_artist_enrichment(
                provider="spotify",
                artist_name="Artist",
                provider_artist_id="sp-artist",
                payload={"id": "sp-artist", "genres": ["ambient"]},
            )
            loaded_by_id = storage.get_artist_enrichment(provider="spotify", provider_artist_id="sp-artist")
            loaded_by_name = storage.get_artist_enrichment(provider="spotify", artist_name="Artist")
            missed = storage.upsert_artist_enrichment(
                provider="lastfm",
                artist_name="Missing Artist",
                status="miss",
                error="not found",
            )
            counts = storage.diagnostic_counts()
            storage.close()

        self.assertEqual(saved["status"], "success")
        self.assertEqual(saved["payload"]["genres"], ["ambient"])
        self.assertEqual(loaded_by_id["id"], saved["id"])
        self.assertEqual(loaded_by_name["id"], saved["id"])
        self.assertEqual(missed["status"], "miss")
        self.assertIsNone(missed["fetched_at"])
        self.assertEqual(counts["artist_enrichment_entries"], 2)

    def test_track_enrichment_save_load_and_rate_limited_status(self) -> None:
        track = InputTrack(
            artist="Artist",
            track="Song",
            album="Album",
            spotify_track_id="sp-track",
            spotify_album_id="sp-album",
            isrc="USABC2600001",
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_track_enrichment(
                provider="spotify",
                track=track,
                payload={"id": "sp-track", "isrc": "USABC2600001"},
            )
            loaded_by_track = storage.get_track_enrichment(provider="spotify", track=track)
            limited = storage.upsert_track_enrichment(
                provider="spotify",
                artist="Other Artist",
                title="Other Song",
                status="rate_limited",
                error="retry after 60",
            )
            counts = storage.diagnostic_counts()
            storage.close()

        self.assertEqual(saved["track_key"], "isrc:usabc2600001")
        self.assertEqual(saved["spotify_track_id"], "sp-track")
        self.assertEqual(saved["spotify_album_id"], "sp-album")
        self.assertEqual(saved["payload"]["id"], "sp-track")
        self.assertEqual(loaded_by_track["id"], saved["id"])
        self.assertEqual(limited["track_key"], "metadata:other artist|other song")
        self.assertEqual(limited["status"], "rate_limited")
        self.assertIsNone(limited["fetched_at"])
        self.assertEqual(counts["track_enrichment_entries"], 2)

    def test_track_enrichment_can_load_id_keyed_row_by_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_track_enrichment(
                provider="tidal",
                artist="Artist",
                title="Song",
                album="Album",
                tidal_track_id="td-track",
                payload={"tidal_track_id": "td-track"},
            )
            loaded = storage.get_track_enrichment(provider="tidal", artist="Artist", title="Song")
            storage.close()

        self.assertEqual(saved["track_key"], "tidal:track:td-track")
        self.assertEqual(loaded["id"], saved["id"])

    def test_enrichment_completeness_uses_successful_durable_rows(self) -> None:
        artists = [
            ArtistProfile(name="Artist One", spotify_id="sp-artist-1"),
            ArtistProfile(name="Artist Two"),
        ]
        tracks = [
            InputTrack(artist="Artist One", track="Song One", spotify_track_id="sp-track-1"),
            InputTrack(artist="Artist Two", track="Song Two"),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            incomplete = storage.enrichment_completeness(artists=artists, tracks=tracks)
            storage.upsert_artist_enrichment(
                provider="spotify",
                artist_name="Artist One",
                provider_artist_id="sp-artist-1",
                payload={"id": "sp-artist-1"},
            )
            storage.upsert_artist_enrichment(
                provider="lastfm",
                artist_name="Artist Two",
                payload={"tags": ["dream pop"]},
            )
            storage.upsert_track_enrichment(
                provider="spotify",
                track=tracks[0],
                payload={"id": "sp-track-1"},
            )
            storage.upsert_track_enrichment(
                provider="input",
                track=tracks[1],
                status="miss",
                error="metadata-only row is not complete",
            )
            partial = storage.enrichment_completeness(artists=artists, tracks=tracks)
            storage.upsert_track_enrichment(
                provider="input",
                track=tracks[1],
                payload={"artist": "Artist Two", "track": "Song Two"},
            )
            complete = storage.enrichment_completeness(artists=artists, tracks=tracks)
            storage.close()

        self.assertFalse(incomplete.complete)
        self.assertEqual(incomplete.artist_enriched, 0)
        self.assertEqual(incomplete.track_enriched, 0)
        self.assertFalse(partial.complete)
        self.assertEqual(partial.artist_enriched, 2)
        self.assertEqual(partial.track_enriched, 1)
        self.assertTrue(complete.complete)

    def test_taste_profile_save_update_list_load_delete(self) -> None:
        tracks = [InputTrack(artist="Artist", track="Song", artists=["Artist"])]
        profile = TasteProfile(
            artists=[ArtistProfile(name="Artist", playlist_count=1, affinity_score=2)],
            top_artists=[ArtistProfile(name="Artist", playlist_count=1, affinity_score=2)],
            n_artists=1,
        )

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            first = storage.upsert_taste_profile(
                name="first-name",
                source_type="txt",
                source_ref="/tmp/source.txt",
                source_key="txt:abc",
                source_hash="abc",
                track_count=1,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            second = storage.upsert_taste_profile(
                name="updated-name",
                source_type="txt",
                source_ref="/tmp/source.txt",
                source_key="txt:abc",
                source_hash="abc",
                track_count=2,
                artist_count=1,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )

            self.assertEqual(first["id"], second["id"])
            self.assertEqual(storage.list_taste_profiles()[0]["name"], "updated-name")
            self.assertEqual(storage.get_taste_profile("updated-name")["track_count"], 2)
            self.assertEqual(storage.get_taste_profile("txt:abc")["id"], first["id"])
            self.assertTrue(storage.delete_taste_profile(first["id"]))
            self.assertIsNone(storage.get_taste_profile("txt:abc"))
            storage.close()

    def test_all_seed_track_keys_combines_saved_profiles(self) -> None:
        profile = TasteProfile(n_artists=0)
        first_tracks = [InputTrack(artist="Artist One", track="Song One", artists=["Artist One"])]
        second_tracks = [InputTrack(artist="Artist Two", track="Song Two", artists=["Artist Two"])]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            storage.upsert_taste_profile(
                name="first",
                source_type="txt",
                source_ref="/tmp/first.txt",
                source_key="txt:first",
                source_hash="first",
                track_count=1,
                artist_count=0,
                profile=profile,
                seed_tracks=first_tracks,
                seed_track_keys=track_keys_from_input(first_tracks),
            )
            storage.upsert_taste_profile(
                name="second",
                source_type="txt",
                source_ref="/tmp/second.txt",
                source_key="txt:second",
                source_hash="second",
                track_count=1,
                artist_count=0,
                profile=profile,
                seed_tracks=second_tracks,
                seed_track_keys=track_keys_from_input(second_tracks),
            )

            keys = storage.all_seed_track_keys()
            storage.close()

        self.assertEqual(keys, {"metadata:artist one|song one", "metadata:artist two|song two"})

    def test_find_taste_profile_for_source_falls_back_to_source_ref(self) -> None:
        profile = TasteProfile(n_artists=0)
        tracks = [InputTrack(artist="Artist", track="Song")]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_taste_profile(
                name="playlist",
                source_type="txt",
                source_ref="/tmp/playlist.txt",
                source_key="txt:old-content-hash",
                source_hash="old-content-hash",
                track_count=1,
                artist_count=0,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )

            found = storage.find_taste_profile_for_source(
                {
                    "name": "playlist",
                    "source_type": "txt",
                    "source_ref": "/tmp/playlist.txt",
                    "source_key": "txt:new-content-hash",
                    "source_hash": "new-content-hash",
                }
            )
            storage.close()

        self.assertEqual(found["id"], saved["id"])

    def test_profile_expansion_memories_toggle_list_remove_and_clear(self) -> None:
        profile = TasteProfile(n_artists=0)
        tracks = [InputTrack(artist="Artist", track="Song")]

        with tempfile.TemporaryDirectory() as tmp:
            storage = Storage(Path(tmp) / "mamonia.sqlite")
            saved = storage.upsert_taste_profile(
                name="playlist",
                source_type="txt",
                source_ref="/tmp/playlist.txt",
                source_key="txt:profile",
                source_hash="hash",
                track_count=1,
                artist_count=0,
                profile=profile,
                seed_tracks=tracks,
                seed_track_keys=track_keys_from_input(tracks),
            )
            self.assertFalse(storage.profile_use_expansion_memories(saved["id"]))
            self.assertTrue(storage.set_profile_use_expansion_memories(saved["id"], True))
            self.assertTrue(storage.profile_use_expansion_memories(saved["id"]))

            storage.upsert_profile_expansion_memory(
                saved["id"],
                artist_name="Dario Marianelli",
                provider="lastfm",
                tier="Tier 3",
                confidence=82.0,
                score=0.12,
                evidence={"reason": "listen overlap"},
            )
            storage.upsert_profile_expansion_memory(
                saved["id"],
                artist_name="Thomas Newman",
                provider="listenbrainz",
                tier="Tier 3",
                confidence=80.0,
                score=0.11,
                evidence={"reason": "community similar"},
            )
            memories = storage.list_profile_expansion_memories(saved["id"])
            self.assertEqual(len(memories), 2)

            removed_one = storage.delete_profile_expansion_memory(memories[0]["id"])
            self.assertTrue(removed_one)
            self.assertEqual(len(storage.list_profile_expansion_memories(saved["id"])), 1)

            removed_all = storage.clear_profile_expansion_memories(saved["id"])
            self.assertEqual(removed_all, 1)
            self.assertEqual(len(storage.list_profile_expansion_memories(saved["id"])), 0)
            storage.close()


if __name__ == "__main__":
    unittest.main()
