"""Tests for mamonia/explanation.py — §11 explanation builder."""

from __future__ import annotations

import pytest

from mamonia.explanation import (
    build_explanation,
    build_fallback_notice,
    scored_to_recommendation,
)
from mamonia.graph_expansion import TIER_1, TIER_2A, TIER_3, TIER_4
from mamonia.models import ReleaseRecommendation
from mamonia.release_discovery import CandidateRelease
from mamonia.scoring_v2 import ScoredRelease

RG_MBID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"


def _candidate(tier: str = TIER_2A, possible_reissue: bool = False, label: str | None = None) -> CandidateRelease:
    return CandidateRelease(
        release_group_mbid=RG_MBID,
        artist_mbid="b2c3d4e5-f6a7-8901-bcde-f12345678901",
        artist_name="Portishead",
        title="Dummy",
        release_date="2025-03-01",
        primary_type="album",
        label=label,
        tier=tier,
        possible_reissue=possible_reissue,
    )


def _scored(
    tier: str = TIER_2A,
    score_normalized: float = 85.0,
    confidence_label: str = "High",
    seed_artists: list[str] | None = None,
    connection_types: list[str] | None = None,
    label: str | None = None,
) -> ScoredRelease:
    return ScoredRelease(
        candidate=_candidate(tier=tier, label=label),
        base_score=0.7,
        final_score=0.7,
        score_normalized=score_normalized,
        confidence_label=confidence_label,
        explanation={
            "seed_artists": seed_artists or ["Massive Attack"],
            "connection_types": connection_types or ["collaboration"],
            "tier": tier,
            "source_reliabilities": [1.0],
        },
    )


# ---------------------------------------------------------------------------
# build_explanation
# ---------------------------------------------------------------------------

class TestBuildExplanation:

    def test_required_keys_present(self):
        exp = build_explanation(_scored())
        for key in ("seed_artists", "connection_types", "tier", "confidence", "rationale", "tier_description"):
            assert key in exp

    def test_seed_artists_passed_through(self):
        exp = build_explanation(_scored(seed_artists=["Massive Attack", "Portishead"]))
        assert exp["seed_artists"] == ["Massive Attack", "Portishead"]

    def test_connection_types_passed_through(self):
        exp = build_explanation(_scored(connection_types=["listenbrainz_similar"]))
        assert exp["connection_types"] == ["listenbrainz_similar"]

    def test_connection_labels_human_readable(self):
        exp = build_explanation(_scored(connection_types=["collaboration"]))
        assert "collaborated" in exp["connection_labels"][0].lower()

    def test_tier_description_populated(self):
        exp = build_explanation(_scored(tier=TIER_1))
        assert "favorite" in exp["tier_description"].lower()

    def test_tier4_description_populated(self):
        exp = build_explanation(_scored(tier=TIER_4))
        assert "weak" in exp["tier_description"].lower()

    def test_confidence_matches_scored(self):
        exp = build_explanation(_scored(confidence_label="Medium"))
        assert exp["confidence"] == "Medium"

    def test_score_normalized_in_explanation(self):
        exp = build_explanation(_scored(score_normalized=72.5))
        assert exp["score_normalized"] == pytest.approx(72.5)

    def test_rationale_includes_seed_name(self):
        exp = build_explanation(_scored(seed_artists=["Burial"]))
        assert "Burial" in exp["rationale"]

    def test_unknown_connection_type_uses_fallback(self):
        exp = build_explanation(_scored(connection_types=["some_unknown_relation"]))
        assert "some unknown relation" in exp["connection_labels"][0]

    def test_label_affinity_connection_label(self):
        exp = build_explanation(_scored(connection_types=["label_affinity"]))
        assert "label connected" in exp["connection_labels"][0]

    def test_empty_seeds_and_connections(self):
        sr = _scored(seed_artists=[], connection_types=[])
        exp = build_explanation(sr)
        assert isinstance(exp["rationale"], str)
        assert len(exp["rationale"]) > 0


# ---------------------------------------------------------------------------
# scored_to_recommendation
# ---------------------------------------------------------------------------

class TestScoredToRecommendation:

    def test_returns_release_recommendation(self):
        rec = scored_to_recommendation(_scored())
        assert isinstance(rec, ReleaseRecommendation)

    def test_roundtrip_preserves_all_fields(self):
        """Single roundtrip test replacing 8 trivial pass-through tests."""
        rec = scored_to_recommendation(_scored(
            tier=TIER_3,
            score_normalized=60.0,
            confidence_label="Low",
            label="Important Label",
        ))
        assert rec.artist == "Portishead"
        assert rec.title == "Dummy"
        assert rec.tier == TIER_3
        assert rec.score_normalized == pytest.approx(60.0)
        assert rec.confidence_label == "Low"
        assert rec.mb_release_group_id == RG_MBID
        assert rec.release_type == "album"
        assert rec.label == "Important Label"
        assert isinstance(rec.explanation, dict)
        assert "seed_artists" in rec.explanation

    def test_rationale_strings_built(self):
        rec = scored_to_recommendation(_scored(
            seed_artists=["Massive Attack"], connection_types=["collaboration"],
        ))
        assert any("collaboration" in r for r in rec.rationale)


# ---------------------------------------------------------------------------
# build_fallback_notice
# ---------------------------------------------------------------------------

class TestFallbackNotice:

    def test_notice_contains_count(self):
        notice = build_fallback_notice(5)
        assert "5" in notice

    def test_notice_mentions_medium_confidence(self):
        notice = build_fallback_notice(1)
        assert "Medium" in notice
