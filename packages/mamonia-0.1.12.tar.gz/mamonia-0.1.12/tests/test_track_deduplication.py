import unittest

from mamonia.deduplication import _passes_plausibility_gate, deduplicate_recommendation_tracks
from mamonia.models import ReleaseRecommendation, ReleaseTrack


class TrackDeduplicationTests(unittest.TestCase):
    def _rec(self, release_title: str, track_title: str, artists: str) -> ReleaseRecommendation:
        return ReleaseRecommendation(
            artist=artists,
            title=release_title,
            tracks=[ReleaseTrack(title=track_title, artists=artists)],
        )

    def test_unrelated_title_and_artist_do_not_enter_fuzzy_review_band(self) -> None:
        recommendations = [
            self._rec("Out of Place", "Out of Place", "Tricky & Marta"),
            self._rec('The Lake / Wrong Flower (from "The Bride!")', "The Lake", "Fever Ray"),
        ]

        out = deduplicate_recommendation_tracks(
            recommendations,
            auto_threshold=75,
            review_min=50,
            review_max=74,
            emit=lambda *_: None,
        )

        self.assertEqual(len(out[0].tracks), 1)
        self.assertEqual(len(out[1].tracks), 1)

    def test_close_title_and_artist_can_still_auto_deduplicate(self) -> None:
        recommendations = [
            self._rec("Album A", "Nareszcie", "Meskie Granie Orkiestra, Igor Herbut"),
            self._rec("Album B", "Nareszcie", "Meskie Granie Orkiestra Igor Herbut"),
        ]

        out = deduplicate_recommendation_tracks(
            recommendations,
            auto_threshold=75,
            review_min=50,
            review_max=74,
            emit=lambda *_: None,
        )

        total_tracks = sum(len(r.tracks) for r in out)
        self.assertEqual(total_tracks, 1)

    def test_same_artist_album_but_different_titles_do_not_force_review(self) -> None:
        recommendations = [
            self._rec("Mind Scenes", "The Inside of Our Mind", "HELMUT"),
            self._rec("Mind Scenes", "Unordinary", "HELMUT"),
        ]

        out = deduplicate_recommendation_tracks(
            recommendations,
            auto_threshold=75,
            review_min=50,
            review_max=74,
            emit=lambda *_: None,
        )

        self.assertEqual(len(out[0].tracks), 1)
        self.assertEqual(len(out[1].tracks), 1)

    def test_same_artist_album_variant_titles_can_still_review(self) -> None:
        r1 = self._rec("The Lake / Wrong Flower (from \"The Bride!\")", "The Lake (Cinematic)", "Fever Ray")
        r2 = self._rec("The Lake / Wrong Flower (from \"The Bride!\")", "The Lake", "Fever Ray")
        t1 = r1.tracks[0]
        t2 = r2.tracks[0]

        self.assertTrue(
            _passes_plausibility_gate(
                t1, r1.title, t2, r2.title, for_auto=False
            )
        )

    def test_same_isrc_from_different_artist_format_is_deduplicated(self) -> None:
        recommendations = [
            ReleaseRecommendation(
                artist="Massive Attack, Tom Waits",
                title="Boots on the Ground",
                tracks=[
                    ReleaseTrack(
                        title="Boots on the Ground",
                        artists="Massive Attack, Tom Waits",
                        isrc="GBENL2604763",
                    )
                ],
            ),
            ReleaseRecommendation(
                artist="Massive Attack & Tom Waits",
                title="Boots on the Ground",
                tracks=[
                    ReleaseTrack(
                        title="Boots on the Ground",
                        artists="Massive Attack & Tom Waits",
                        isrc="GBENL2604763",
                    )
                ],
            ),
        ]

        out = deduplicate_recommendation_tracks(recommendations, emit=lambda *_: None)
        total_tracks = sum(len(r.tracks) for r in out)
        self.assertEqual(total_tracks, 1)

    def test_same_title_artist_tokens_with_different_credit_format_is_deduplicated(self) -> None:
        recommendations = [
            ReleaseRecommendation(
                artist="Marta, Tricky, Marcela Rybska",
                title="Way Up In",
                tracks=[ReleaseTrack(title="Way Up In", artists="Marta, Tricky, Marcela Rybska")],
            ),
            ReleaseRecommendation(
                artist="Marta feat. Marcela Rybska",
                title="Way Up In",
                tracks=[ReleaseTrack(title="Way Up In", artists="Marta feat. Marcela Rybska")],
            ),
        ]

        out = deduplicate_recommendation_tracks(recommendations, emit=lambda *_: None)
        total_tracks = sum(len(r.tracks) for r in out)
        self.assertEqual(total_tracks, 1)

    def test_same_track_with_title_case_variant_is_deduplicated(self) -> None:
        recommendations = [
            ReleaseRecommendation(
                artist="Marta, Tricky",
                title="Out The Way",
                tracks=[ReleaseTrack(title="Out The Way", artists="Marta, Tricky", isrc="NL8RL2528857")],
            ),
            ReleaseRecommendation(
                artist="Marta & Tricky",
                title="Out the Way",
                tracks=[ReleaseTrack(title="Out the Way", artists="Marta & Tricky", isrc="NL8RL2528857")],
            ),
        ]

        out = deduplicate_recommendation_tracks(recommendations, emit=lambda *_: None)
        total_tracks = sum(len(r.tracks) for r in out)
        self.assertEqual(total_tracks, 1)

    def test_same_isrc_is_authoritative_even_with_low_fuzzy_similarity_and_different_sources(self) -> None:
        recommendations = [
            ReleaseRecommendation(
                artist="Alpha Artist",
                title="Release A",
                tracks=[
                    ReleaseTrack(
                        title="Completely Different Title One",
                        artists="Artist One",
                        isrc="USABC1234567",
                        isrc_source="musicbrainz",
                    )
                ],
            ),
            ReleaseRecommendation(
                artist="Beta Artist",
                title="Release B",
                tracks=[
                    ReleaseTrack(
                        title="Unrelated Song Name Two",
                        artists="Artist Two",
                        isrc="US-ABC-1234567",
                        isrc_source="tidal",
                    )
                ],
            ),
        ]

        out = deduplicate_recommendation_tracks(recommendations, emit=lambda *_: None)
        total_tracks = sum(len(r.tracks) for r in out)
        self.assertEqual(total_tracks, 1)


if __name__ == "__main__":
    unittest.main()
