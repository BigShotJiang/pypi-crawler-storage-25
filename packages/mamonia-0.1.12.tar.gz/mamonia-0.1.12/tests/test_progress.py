from __future__ import annotations

import io
import unittest
import warnings
from unittest.mock import patch

from mamonia.models import CandidateArtist, ReleaseRecommendation
from mamonia.progress import (
    CompactProgressReporter,
    LegacyProgressAdapter,
    NoOpProgressReporter,
    PlainTextProgressReporter,
    ProgressDisplayDriver,
    ProgressEtaModel,
    ProgressStageRegistry,
    ProgressStateEngine,
    RichBusyStatusReporter,
    RichProgressReporter,
    choose_busy_status_reporter,
    choose_progress_reporter,
    format_duration,
    progress_percent,
    render_progress_block,
    wait_line_for_tick,
)


class ProgressTests(unittest.TestCase):
    def test_noop_progress_collects_summary_without_emitting(self) -> None:
        reporter = NoOpProgressReporter()
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
        recommendation = ReleaseRecommendation(artist="Seed Artist", title="Fresh Release")

        reporter.candidate_started(candidate, processed=1, total=2)
        reporter.release_group_checked(candidate, {"title": "Fresh Release"})
        reporter.release_group_skipped("heard")
        reporter.spotify_lookup_missed(recommendation)
        reporter.release_accepted(recommendation)

        summary = reporter.summary()

        self.assertEqual(summary.candidates_processed, 1)
        self.assertEqual(summary.total_candidates, 2)
        self.assertEqual(summary.release_groups_checked, 1)
        self.assertEqual(summary.accepted, 1)
        self.assertEqual(summary.spotify_misses, 1)
        self.assertEqual(summary.elapsed_seconds, 0)
        self.assertEqual(summary.skips, {"heard": 1})

    def test_noop_progress_estimates_remaining_time_from_candidates(self) -> None:
        reporter = NoOpProgressReporter()
        reporter.started_at -= 20
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)

        reporter.candidate_started(candidate, processed=2, total=10)
        summary = reporter.summary()

        self.assertEqual(summary.estimated_remaining_seconds, 80)

    def test_choose_progress_reporter_uses_plain_text_for_non_tty(self) -> None:
        reporter = choose_progress_reporter(is_tty=False, emit=lambda message: None)
        self.assertNotIsInstance(reporter, LegacyProgressAdapter)

    def test_plain_text_progress_emits_candidate_status_without_acceptance_spam(self) -> None:
        lines: list[str] = []
        reporter = PlainTextProgressReporter(emit=lines.append, every_candidates=1)
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
        recommendation = ReleaseRecommendation(artist="Seed Artist", title="Fresh Release")

        reporter.stage_started("Fetching candidate releases", processed=0, total=3)
        reporter.candidate_started(candidate, processed=1, total=3)
        reporter.release_group_checked(candidate, {"title": "Fresh Release"})
        reporter.release_accepted(recommendation)

        self.assertTrue(any("elapsed=" in line and "Seed Artist" in line for line in lines))

    def test_progress_percent_clamps_and_handles_unknown_totals(self) -> None:
        self.assertIsNone(progress_percent(1, None))
        self.assertIsNone(progress_percent(1, 0))
        self.assertEqual(progress_percent(0, 10), 0)
        self.assertEqual(progress_percent(2, 5), 40)
        self.assertEqual(progress_percent(12, 10), 100)

    def test_render_progress_block_formats_known_candidate_progress(self) -> None:
        block = render_progress_block(
            processed=2,
            total=5,
            current_artist="Current Artist",
            elapsed_seconds=123,
            estimated_remaining_seconds=184,
        )

        self.assertEqual(
            block,
            "[####################------------------------------] 40%\n"
            "Time elapsed: 123 s  Estimated time left: 184 s\n"
            "\n"
            "Currently working on:\n"
            "2 / 5 - Current Artist",
        )

    def test_render_progress_block_formats_unknown_total_without_eta(self) -> None:
        block = render_progress_block(
            processed=2,
            total=None,
            current_artist="Current Artist",
            elapsed_seconds=123,
            estimated_remaining_seconds=None,
        )

        self.assertEqual(
            block,
            "[--------------------------------------------------] --%\n"
            "Time elapsed: 123 s\n"
            "\n"
            "Currently working on:\n"
            "2 / ? - Current Artist",
        )

    def test_format_duration_formats_eta_values(self) -> None:
        self.assertEqual(format_duration(None), "unknown")
        self.assertEqual(format_duration(42), "42s")
        self.assertEqual(format_duration(120), "2m")
        self.assertEqual(format_duration(3660), "1h 1m")

    def test_choose_progress_reporter_uses_legacy_adapter_for_tty(self) -> None:
        reporter = choose_progress_reporter(is_tty=True, emit=lambda message: None)
        self.assertNotIsInstance(reporter, LegacyProgressAdapter)

    def test_rich_progress_collects_summary(self) -> None:
        try:
            from rich.console import Console
        except ImportError:
            self.skipTest("rich library not available")

        console = Console(file=io.StringIO(), force_terminal=True)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            reporter = RichProgressReporter(emit=lambda message: None, console=console)
        self.assertTrue(any("deprecated" in str(w.message).lower() for w in caught))
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
        recommendation = ReleaseRecommendation(artist="Seed Artist", title="Fresh Release")

        reporter.candidate_started(candidate, processed=1, total=2)
        reporter.release_group_checked(candidate, {"title": "Fresh Release"})
        reporter.release_group_skipped("heard")
        reporter.spotify_lookup_missed(recommendation)
        reporter.release_accepted(recommendation)

        summary = reporter.summary()

        self.assertEqual(summary.candidates_processed, 1)
        self.assertEqual(summary.total_candidates, 2)
        self.assertEqual(summary.release_groups_checked, 1)
        self.assertEqual(summary.accepted, 1)
        self.assertEqual(summary.spotify_misses, 1)
        self.assertEqual(summary.elapsed_seconds, 0)
        self.assertEqual(summary.skips, {"heard": 1})
        self.assertIsNone(reporter._live)

    def test_choose_progress_reporter_tty_returns_supported_reporter(self) -> None:
        reporter = choose_progress_reporter(is_tty=True, emit=lambda message: None)
        self.assertNotIsInstance(reporter, LegacyProgressAdapter)

    def test_compact_progress_pause_resume_finish_are_idempotent(self) -> None:
        lines: list[str] = []
        reporter = CompactProgressReporter(emit=lines.append)
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
        reporter.stage_started("Fetching candidate releases", processed=0, total=3)
        reporter.pause()
        reporter.pause()
        reporter.candidate_started(candidate, processed=1, total=3)
        paused_count = len(lines)
        reporter.resume()
        reporter.resume()
        reporter.candidate_started(candidate, processed=2, total=3)
        _ = reporter.summary()
        self.assertGreaterEqual(len(lines), paused_count)

    def test_compact_progress_non_tty_emits_compact_single_line(self) -> None:
        lines: list[str] = []
        reporter = CompactProgressReporter(emit=lines.append, min_refresh_seconds=0.0)
        candidate = CandidateArtist(name="Seed Artist", source="seed-artist", score=1)
        reporter.stage_started("Fetching candidate releases", processed=0, total=2)
        reporter.candidate_started(candidate, processed=1, total=2)
        self.assertTrue(any("elapsed=" in line and "Seed Artist" in line for line in lines))

    def test_v2_state_engine_weighted_progress_does_not_hit_100_early(self) -> None:
        registry = ProgressStageRegistry()
        engine = ProgressStateEngine(registry=registry)
        engine.enter_stage("candidate_fetch", total_units=10)
        engine.update_stage(processed_units=10, total_units=10, active_item="Artist")
        self.assertLess(engine.overall_percent(), 100)
        engine.complete_all()
        self.assertEqual(engine.overall_percent(), 100)

    def test_v2_eta_model_uses_first_twenty_for_high_volume(self) -> None:
        eta = ProgressEtaModel()
        for _ in range(25):
            eta.observe_call_latency(100.0)
        self.assertIsNone(eta.estimate_remaining(total=500, processed=100, elapsed_seconds=999))

    def test_v2_driver_non_tty_coalesces_identical_frames(self) -> None:
        lines: list[str] = []
        registry = ProgressStageRegistry()
        engine = ProgressStateEngine(registry=registry)
        driver = ProgressDisplayDriver(emit=lines.append, is_tty=False)
        engine.enter_stage("canonicalization", total_units=10)
        engine.update_stage(processed_units=1, total_units=10, active_item="A")
        driver.refresh(engine, force=True)
        before = len(lines)
        driver.refresh(engine, force=True)
        self.assertEqual(before, len(lines))

    def test_legacy_adapter_summary_does_not_force_100_percent(self) -> None:
        registry = ProgressStageRegistry()
        engine = ProgressStateEngine(registry=registry)
        driver = ProgressDisplayDriver(emit=lambda _m: None, is_tty=False)
        reporter = LegacyProgressAdapter(engine=engine, driver=driver)
        reporter.stage_started("Fetching candidate releases", processed=0, total=100)
        reporter.candidate_started(CandidateArtist(name="X", source="s", score=0.0), processed=89, total=100)
        _ = reporter.summary()
        self.assertLess(engine.overall_percent(), 100)

    def test_wait_line_for_tick_cycles_deterministically(self) -> None:
        lines = ["one", "two", "three"]
        self.assertEqual(wait_line_for_tick(lines, 0), "one")
        self.assertEqual(wait_line_for_tick(lines, 1), "two")
        self.assertEqual(wait_line_for_tick(lines, 4), "two")

    def test_choose_busy_status_reporter_non_tty_is_noop(self) -> None:
        reporter = choose_busy_status_reporter(is_tty=False)
        with reporter.phase("Loading", ["line"]):
            pass

    def test_rich_busy_status_starts_and_stops_live(self) -> None:
        class _LiveStub:
            def __init__(self, *args, **kwargs):
                self.started = False
                self.stopped = False
                self.updated = 0

            def start(self):
                self.started = True

            def stop(self):
                self.stopped = True

            def update(self, *_args, **_kwargs):
                self.updated += 1

        live_stub = _LiveStub()
        reporter = RichBusyStatusReporter(console=object(), refresh_interval_seconds=0.01, line_rotate_seconds=0.01)
        with patch("rich.live.Live", return_value=live_stub):
            with reporter.phase("Loading", ["a", "b"]):
                pass

        self.assertTrue(live_stub.started)
        self.assertTrue(live_stub.stopped)


if __name__ == "__main__":
    unittest.main()
