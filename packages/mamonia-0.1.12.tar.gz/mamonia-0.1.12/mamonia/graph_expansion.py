"""
Tier assignment and graph expansion engine — §5–6 of the Human Logic Proposal.

Starting from Tier 1 seed artists, this module expands outward using
MusicBrainz relations, ListenBrainz similar-artist data, and Last.fm
similarity/tag data.  Each discovered artist is assigned to a tier:

    Tier 1  — directly present in imported source data             factor 1.00
    Tier 2A — strong adjacent (alias, side project, member,
               direct collaborator) + strong tag-cluster match     factor 0.80
    Tier 2B — medium adjacent (producer, label/scene, feature)
               + genre/tag match                                   factor 0.60
    Tier 3  — discovery similarity (LB similar, Last.fm similar)
               + strong tag/genre match                            factor 0.45
    Tier 4  — weak discovery (genre/tag-only, low listener overlap) factor 0.25

Expansion rules (§6):
    Tier 1  → expand to depth 2
    Tier 2A → expand depth 1 only
    Tier 2B → expand depth 1 only
    Tier 3  → do not expand further
    Tier 4  → do not expand further

Hard caps per seed:
    max similar artists : 6
    max collaborators   : 6
    max total expanded  : dynamic (5x seed count, max 150)
"""

from __future__ import annotations

import concurrent.futures
from dataclasses import dataclass, field
from typing import Any

from .models import ArtistSeed, GraphEdge
from .models import CandidateArtist

# ---------------------------------------------------------------------------
# Tier constants
# ---------------------------------------------------------------------------

TIER_1 = "Tier 1"
TIER_2A = "Tier 2A"
TIER_2B = "Tier 2B"
TIER_3 = "Tier 3"
TIER_4 = "Tier 4"

TIER_FACTORS: dict[str, float] = {
    TIER_1: 1.00,
    TIER_2A: 0.80,
    TIER_2B: 0.60,
    TIER_3: 0.45,
    TIER_4: 0.25,
}

# Relation types that can qualify for Tier 2A (with strong tag match)
_STRONG_ADJACENT_RELATIONS = {
    "alias", "member of band", "collaboration", "founded by",
    "is collaboration", "member", "side project",
}

# Relation types that can qualify for Tier 2B (with genre/tag match)
_MEDIUM_ADJACENT_RELATIONS = {
    "producer", "remix producer", "label", "scene", "featured artist",
    "arranger", "engineer",
}

# Source reliability values (§9 SourceReliability)
SOURCE_RELIABILITY: dict[str, float] = {
    "musicbrainz": 1.00,
    "listenbrainz": 0.85,
    "lastfm_similar": 0.81,
    "lastfm_tag": 0.50,
    "fuzzy": 0.40,
}

# Hard caps
_MAX_SIMILAR_PER_SEED = 6
_MAX_COLLABORATORS_PER_SEED = 6
# Dynamic cap: 5x seed count, max 150 to prevent API spam on huge playlists
_MAX_TOTAL_EXPANDED_BASE = 250


@dataclass
class ExpandedGraph:
    """Result of expanding the seed artist graph."""
    edges: list[GraphEdge] = field(default_factory=list)
    # artist_mbid → tier string for every artist in the graph (including seeds)
    artist_tiers: dict[str, str] = field(default_factory=dict)
    # artist_mbid → canonical name
    artist_names: dict[str, str] = field(default_factory=dict)


def assign_tier_1(seeds: list[ArtistSeed]) -> ExpandedGraph:
    """Mark all seed artists as Tier 1 — no expansion yet."""
    graph = ExpandedGraph()
    for seed in seeds:
        key = seed.artist_mbid or seed.canonical_name.lower()
        graph.artist_tiers[key] = TIER_1
        graph.artist_names[key] = seed.canonical_name
    return graph


def expand_graph(
    seeds: list[ArtistSeed],
    musicbrainz: Any | None = None,
    listenbrainz: Any | None = None,
    lastfm: Any | None = None,
    seed_tags: dict[str, set[str]] | None = None,
    emit: Any = None,
    progress: Any | None = None,
    debug: bool = False,
) -> ExpandedGraph:
    """
    Expand the artist graph from Tier 1 seeds using available data sources.

    Args:
        seeds: Tier 1 seed artists (from build_artist_seeds).
        musicbrainz: MusicBrainz provider (optional).
        listenbrainz: ListenBrainz provider (optional).
        lastfm: Last.fm provider (optional).
        seed_tags: Mapping of artist key → set of genre/tag strings.
                   Used to compute tag-cluster match for tier assignment.

    Returns:
        ExpandedGraph with edges, artist_tiers, and artist_names populated.
    """
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)
    graph = assign_tier_1(seeds)
    seed_tags = seed_tags or {}

    # Aggregate tags only from Tier 1 seeds (not expanded artists)
    all_seed_tags: set[str] = set()
    for seed in seeds:
        seed_key = seed.artist_mbid or seed.canonical_name.lower()
        all_seed_tags.update(seed_tags.get(seed_key, set()))

    # Track per-seed caps
    similar_counts: dict[str, int] = {}   # seed_key → count of similar expansions
    collab_counts: dict[str, int] = {}    # seed_key → count of collaborator expansions
    edge_keys: set[tuple[str, str, str]] = set()
    listenbrainz_result_count = 0
    lastfm_result_count = 0
    total_expanded = 0
    max_total = min(len(seeds) * 5, _MAX_TOTAL_EXPANDED_BASE)
    provider_settings = (
        getattr(listenbrainz, "settings", None)
        or getattr(lastfm, "settings", None)
        or None
    )
    graph_interleave_enabled = bool(getattr(provider_settings, "graph_interleave_enabled", True))
    graph_interleave_mode = str(getattr(provider_settings, "graph_interleave_mode", "per_seed_round_robin") or "per_seed_round_robin")
    lastfm_tag_budget_per_run = int(getattr(provider_settings, "lastfm_tag_budget_per_run", 0) or 0)
    lastfm_tag_budget_used = 0
    lastfm_tag_budget_exhausted = False
    diagnostic_counts: dict[str, int] = {
        "lb_missing_provider": 0,
        "lb_missing_seed_mbid": 0,
        "lb_empty": 0,
        "lb_duplicate_or_tier1": 0,
        "lf_missing_provider": 0,
        "lf_quota_full": 0,
        "lf_empty": 0,
        "lf_duplicate_or_tier1": 0,
        "global_cap_reached": 0,
    }
    stage_stats: dict[str, Any] = {
        "cap": {"max_total": max_total, "used": 0},
        "providers": {
            "listenbrainz": {
                "seeds_total": len(seeds_sorted) if "seeds_sorted" in locals() else len(seeds),
                "invoked": 0,
                "skipped_provider": 0,
                "skipped_missing_seed_mbid": 0,
                "skipped_global_cap": 0,
                "raw_candidates": 0,
                "added": 0,
                "rejected_duplicate_or_tier1": 0,
                "rejected_seed_quota": 0,
                "rejected_global_cap": 0,
            },
            "lastfm": {
                "seeds_total": len(seeds_sorted) if "seeds_sorted" in locals() else len(seeds),
                "invoked": 0,
                "skipped_provider": 0,
                "skipped_quota_full": 0,
                "skipped_global_cap": 0,
                "raw_candidates": 0,
                "added": 0,
                "rejected_duplicate_or_tier1": 0,
                "rejected_seed_quota": 0,
                "rejected_global_cap": 0,
            },
        },
        "phase_caps": {},
        "interleave": {
            "enabled": graph_interleave_enabled,
            "mode": graph_interleave_mode,
            "lb_attempt_cycles": 0,
            "lf_attempt_cycles": 0,
        },
        "budgets": {
            "lastfm_tag_budget_per_run": lastfm_tag_budget_per_run,
            "lastfm_tag_budget_used": 0,
            "lastfm_tag_budget_exhausted": False,
        },
    }

    def _can_expand_similar(seed_key: str) -> bool:
        return similar_counts.get(seed_key, 0) < _MAX_SIMILAR_PER_SEED

    def _can_expand_collab(seed_key: str) -> bool:
        return collab_counts.get(seed_key, 0) < _MAX_COLLABORATORS_PER_SEED

    def _under_total_cap() -> bool:
        nonlocal total_expanded
        # Dynamic cap: 5x seed count, max 150
        # Count only non-Tier-1 artists
        return total_expanded < max_total

    def _tag_overlap(artist_key: str) -> float:
        """Fraction of seed tags that appear in this artist's tags."""
        if not all_seed_tags:
            return 0.0
        artist_tags = seed_tags.get(artist_key, set())
        if not artist_tags:
            return 0.0
        return len(all_seed_tags & artist_tags) / len(all_seed_tags)

    def _seed_tag_overlap(seed_key: str, artist_key: str) -> float:
        """Fraction of one seed's tags matched by the target artist."""
        seed_tag_set = seed_tags.get(seed_key, set())
        artist_tags = seed_tags.get(artist_key, set())
        if not seed_tag_set or not artist_tags:
            return 0.0
        return len(seed_tag_set & artist_tags) / len(seed_tag_set)

    def _similarity_tier(seed_key: str, target_key: str) -> str:
        """Tier similarity candidates using explicit metadata alignment."""
        if not seed_tags.get(target_key):
            return TIER_4
        pairwise_overlap = _seed_tag_overlap(seed_key, target_key)
        profile_overlap = _tag_overlap(target_key)
        if pairwise_overlap >= 0.25 or profile_overlap >= 0.15:
            return TIER_3
        return TIER_4

    def _stronger_tier(current: str, candidate: str) -> str:
        current_factor = TIER_FACTORS.get(current, 0.0)
        candidate_factor = TIER_FACTORS.get(candidate, 0.0)
        return candidate if candidate_factor > current_factor else current

    def _add_edge(
        source_key: str,
        source_name: str,
        target_mbid: str | None,
        target_name: str,
        relation_type: str,
        confidence: float,
        depth: int,
        connection_strength: float,
        tier: str,
        source_reliability: str = "musicbrainz",
    ) -> bool:
        nonlocal total_expanded
        target_key = target_mbid or target_name.lower()
        if graph.artist_tiers.get(target_key) == TIER_1:
            return False
        edge_key = (source_key, target_key, relation_type)
        if edge_key in edge_keys:
            return False
        is_new_artist = target_key not in graph.artist_tiers
        if is_new_artist and not _under_total_cap():
            return False
        graph.edges.append(GraphEdge(
            source_artist_mbid=source_key if _looks_like_mbid(source_key) else None,
            source_artist_name=source_name,
            target_artist_mbid=target_mbid,
            target_artist_name=target_name,
            relation_type=relation_type,
            confidence=confidence,
            depth=depth,
            connection_strength=connection_strength,
            tier=tier,
        ))
        edge_keys.add(edge_key)
        graph.artist_tiers[target_key] = (
            tier if is_new_artist else _stronger_tier(graph.artist_tiers[target_key], tier)
        )
        graph.artist_names[target_key] = target_name
        if is_new_artist:
            total_expanded += 1
        return True

    # Seeds ordered by weight — highest-weight artists drive discovery first.
    # Critical for large playlists where the expansion cap fires before all
    # seeds are processed: the most-listened-to artists claim their slots.
    seeds_sorted = sorted(seeds, key=lambda s: s.seed_weight, reverse=True)
    seed_keys: set[str] = {s.artist_mbid or s.canonical_name.lower() for s in seeds_sorted}

    def _hydrate_tags_from_lastfm(target_key: str, target_name: str) -> None:
        nonlocal lastfm_tag_budget_used, lastfm_tag_budget_exhausted
        if target_key in seed_tags or not lastfm or not target_name:
            return
        apply_budget = lastfm_tag_budget_per_run > 0 and target_key not in seed_keys
        if apply_budget and lastfm_tag_budget_used >= lastfm_tag_budget_per_run:
            lastfm_tag_budget_exhausted = True
            seed_tags[target_key] = set()
            return
        try:
            lf_tags = lastfm.top_tags(target_name) or []
            seed_tags[target_key] = {t.lower().strip() for t in lf_tags if t}
        except Exception:
            seed_tags[target_key] = set()
        if apply_budget:
            lastfm_tag_budget_used += 1

    # -----------------------------------------------------------------------
    # Phase 1 — MusicBrainz relations (fast: 1 API call per seed)
    # Direct collaborators → Tier 2A/2B. Runs first so structural connections
    # are captured before the cap can be consumed by similarity-based artists.
    # All seeds are eligible; the inner cap check stops additions once full.
    # -----------------------------------------------------------------------
    for seed in seeds_sorted:
        seed_key = seed.artist_mbid or seed.canonical_name.lower()
        if not musicbrainz or not seed.artist_mbid:
            continue
        if not _under_total_cap():
            break
        mb_relations = _fetch_mb_artist_relations(musicbrainz, seed.artist_mbid)
        _mb_added = 0
        for rel in mb_relations:
            if not _under_total_cap():
                break
            rel_type = rel.get("type", "").lower()
            target_mbid = rel.get("artist_mbid")
            target_name = rel.get("artist_name", "")
            if not target_name:
                continue

            target_key = target_mbid or target_name.lower()
            _hydrate_tags_from_lastfm(target_key, target_name)
            overlap = _tag_overlap(target_key)

            if rel_type in _STRONG_ADJACENT_RELATIONS:
                if not _can_expand_collab(seed_key):
                    continue
                has_tags = bool(seed_tags.get(target_key))
                tier = TIER_2B if (has_tags and overlap < 0.2) else TIER_2A
                cs = 0.90 if tier == TIER_2A else 0.70
                if _add_edge(seed_key, seed.canonical_name, target_mbid, target_name,
                             rel_type, confidence=0.95, depth=1,
                             connection_strength=cs, tier=tier):
                    collab_counts[seed_key] = collab_counts.get(seed_key, 0) + 1
                    _mb_added += 1

            elif rel_type in _MEDIUM_ADJACENT_RELATIONS:
                if not _can_expand_collab(seed_key):
                    continue
                if overlap >= 0.05:
                    if _add_edge(seed_key, seed.canonical_name, target_mbid, target_name,
                                 rel_type, confidence=0.80, depth=1,
                                 connection_strength=0.60, tier=TIER_2B):
                        collab_counts[seed_key] = collab_counts.get(seed_key, 0) + 1
                        _mb_added += 1
                elif overlap >= 0.02:
                    # Lower threshold for medium relations — add anyway if no tag match
                    if _add_edge(seed_key, seed.canonical_name, target_mbid, target_name,
                                 rel_type, confidence=0.70, depth=1,
                                 connection_strength=0.50, tier=TIER_2B):
                        collab_counts[seed_key] = collab_counts.get(seed_key, 0) + 1
                        _mb_added += 1
        if mb_relations:
            _v2_emit(f"[v2] {seed.canonical_name}: MB relations={len(mb_relations)}, added={_mb_added}")
    stage_stats["phase_caps"]["after_mb"] = total_expanded

    lb_per_seed_added: dict[str, int] = {}
    lf_per_seed_added: dict[str, int] = {}
    lb_buffers: dict[str, list[dict]] = {}
    lf_buffers: dict[str, list[dict]] = {}
    lb_index: dict[str, int] = {}
    lf_index: dict[str, int] = {}
    lb_max_score: dict[str, float] = {}

    # -----------------------------------------------------------------------
    # Pre-fetch ListenBrainz and Last.fm similar artists concurrently
    # before the round-robin expansion loop to overlap I/O wait time.
    # -----------------------------------------------------------------------
    if graph_interleave_enabled and graph_interleave_mode == "per_seed_round_robin":
        if listenbrainz:
            def _prefetch_lb(seed: ArtistSeed) -> tuple[str, list[dict]]:
                if not seed.artist_mbid:
                    return seed.artist_mbid or seed.canonical_name.lower(), []
                try:
                    results = _fetch_lb_similar(listenbrainz, seed.artist_mbid)
                    return seed.artist_mbid or seed.canonical_name.lower(), results
                except Exception:
                    return seed.artist_mbid or seed.canonical_name.lower(), []

            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                futures = {executor.submit(_prefetch_lb, seed): seed for seed in seeds_sorted}
                for future in concurrent.futures.as_completed(futures):
                    seed_key, results = future.result()
                    lb_buffers[seed_key] = results
                    lb_index[seed_key] = 0
                    lb_max_score[seed_key] = max(
                        (_safe_float(a.get("score"), 0.0) for a in results), default=0.0
                    )
                    listenbrainz_result_count += len(results)
                    stage_stats["providers"]["listenbrainz"]["raw_candidates"] += len(results)
                    stage_stats["providers"]["listenbrainz"]["invoked"] += 1
                    if not results:
                        diagnostic_counts["lb_empty"] += 1

        if lastfm:
            def _prefetch_lf(seed: ArtistSeed) -> tuple[str, list[dict]]:
                try:
                    results = _fetch_lastfm_similar(lastfm, seed.canonical_name)
                    return seed.artist_mbid or seed.canonical_name.lower(), results
                except Exception:
                    return seed.artist_mbid or seed.canonical_name.lower(), []

            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                futures = {executor.submit(_prefetch_lf, seed): seed for seed in seeds_sorted}
                for future in concurrent.futures.as_completed(futures):
                    seed_key, results = future.result()
                    lf_buffers[seed_key] = results
                    lf_index[seed_key] = 0
                    lastfm_result_count += len(results)
                    stage_stats["providers"]["lastfm"]["raw_candidates"] += len(results)
                    stage_stats["providers"]["lastfm"]["invoked"] += 1
                    if not results:
                        diagnostic_counts["lf_empty"] += 1

    if graph_interleave_enabled and graph_interleave_mode == "per_seed_round_robin":
        progressed: set[str] = set()
        while _under_total_cap():
            advanced = False
            for seed in seeds_sorted:
                if not _under_total_cap():
                    diagnostic_counts["global_cap_reached"] += 1
                    break
                seed_key = seed.artist_mbid or seed.canonical_name.lower()
                if progress is not None and seed_key not in progressed:
                    progress.candidate_started(
                        CandidateArtist(name=seed.canonical_name, source="v2:graph", score=seed.seed_weight),
                        len(progressed) + 1,
                        len(seeds_sorted),
                    )
                    progressed.add(seed_key)

                if _can_expand_similar(seed_key):
                    stage_stats["interleave"]["lb_attempt_cycles"] += 1
                    if not listenbrainz:
                        diagnostic_counts["lb_missing_provider"] += 1
                        stage_stats["providers"]["listenbrainz"]["skipped_provider"] += 1
                    elif not seed.artist_mbid:
                        diagnostic_counts["lb_missing_seed_mbid"] += 1
                        stage_stats["providers"]["listenbrainz"]["skipped_missing_seed_mbid"] += 1
                    else:
                        if seed_key not in lb_buffers:
                            stage_stats["providers"]["listenbrainz"]["invoked"] += 1
                            lb_similar = _fetch_lb_similar(listenbrainz, seed.artist_mbid)
                            lb_buffers[seed_key] = lb_similar
                            lb_index[seed_key] = 0
                            lb_max_score[seed_key] = max((_safe_float(a.get("score"), 0.0) for a in lb_similar), default=0.0)
                            listenbrainz_result_count += len(lb_similar)
                            stage_stats["providers"]["listenbrainz"]["raw_candidates"] += len(lb_similar)
                            if not lb_similar:
                                diagnostic_counts["lb_empty"] += 1
                        idx = lb_index.get(seed_key, 0)
                        items = lb_buffers.get(seed_key, [])
                        while idx < len(items) and _can_expand_similar(seed_key) and _under_total_cap():
                            artist = items[idx]
                            idx += 1
                            target_mbid = artist.get("artist_mbid")
                            target_name = artist.get("artist_name", "")
                            if not target_name:
                                continue
                            target_key = target_mbid or target_name.lower()
                            _hydrate_tags_from_lastfm(target_key, target_name)
                            tier = _similarity_tier(seed_key, target_key)
                            cs = _listenbrainz_connection_strength(
                                score=_safe_float(artist.get("score"), 0.0),
                                share=_safe_float(artist.get("share"), 0.0),
                                max_score=lb_max_score.get(seed_key, 0.0),
                            )
                            if _add_edge(
                                seed_key,
                                seed.canonical_name,
                                target_mbid,
                                target_name,
                                "listenbrainz_similar",
                                confidence=0.85,
                                depth=1,
                                connection_strength=cs,
                                tier=tier,
                                source_reliability="listenbrainz",
                            ):
                                similar_counts[seed_key] = similar_counts.get(seed_key, 0) + 1
                                lb_per_seed_added[seed_key] = lb_per_seed_added.get(seed_key, 0) + 1
                                stage_stats["providers"]["listenbrainz"]["added"] += 1
                                advanced = True
                                break
                            diagnostic_counts["lb_duplicate_or_tier1"] += 1
                            stage_stats["providers"]["listenbrainz"]["rejected_duplicate_or_tier1"] += 1
                        lb_index[seed_key] = idx

                if not _under_total_cap() or not _can_expand_similar(seed_key):
                    continue
                stage_stats["interleave"]["lf_attempt_cycles"] += 1
                if not lastfm:
                    diagnostic_counts["lf_missing_provider"] += 1
                    stage_stats["providers"]["lastfm"]["skipped_provider"] += 1
                    continue
                if seed_key not in lf_buffers:
                    stage_stats["providers"]["lastfm"]["invoked"] += 1
                    lf_similar = _fetch_lastfm_similar(lastfm, seed.canonical_name)
                    lf_buffers[seed_key] = lf_similar
                    lf_index[seed_key] = 0
                    lastfm_result_count += len(lf_similar)
                    stage_stats["providers"]["lastfm"]["raw_candidates"] += len(lf_similar)
                    if not lf_similar:
                        diagnostic_counts["lf_empty"] += 1
                idx = lf_index.get(seed_key, 0)
                items = lf_buffers.get(seed_key, [])
                while idx < len(items) and _can_expand_similar(seed_key) and _under_total_cap():
                    artist = items[idx]
                    idx += 1
                    target_name = artist.get("artist_name", "")
                    target_mbid = artist.get("artist_mbid")
                    if not target_name:
                        continue
                    target_key = target_mbid or target_name.lower()
                    _hydrate_tags_from_lastfm(target_key, target_name)
                    tier = _similarity_tier(seed_key, target_key)
                    cs = float(artist.get("match", 0.5))
                    if _add_edge(
                        seed_key,
                        seed.canonical_name,
                        target_mbid,
                        target_name,
                        "lastfm_similar",
                        confidence=0.81,
                        depth=1,
                        connection_strength=_clamp(cs, 0.25, 1.0),
                        tier=tier,
                        source_reliability="lastfm_similar",
                    ):
                        similar_counts[seed_key] = similar_counts.get(seed_key, 0) + 1
                        lf_per_seed_added[seed_key] = lf_per_seed_added.get(seed_key, 0) + 1
                        stage_stats["providers"]["lastfm"]["added"] += 1
                        advanced = True
                        break
                    diagnostic_counts["lf_duplicate_or_tier1"] += 1
                    stage_stats["providers"]["lastfm"]["rejected_duplicate_or_tier1"] += 1
                lf_index[seed_key] = idx
            if not advanced:
                break
    else:
        # DEPRECATED: Legacy non-interleaved behavior — remove once interleaved mode is confirmed stable
        # This sequential processing exhausts ListenBrainz quota before Last.fm gets a chance.
        # Kept for now to allow rollback if interleaved mode has issues.
        for processed, seed in enumerate(seeds_sorted, start=1):
            if progress is not None:
                progress.candidate_started(
                    CandidateArtist(name=seed.canonical_name, source="v2:graph", score=seed.seed_weight),
                    processed,
                    len(seeds_sorted),
                )
            if not _under_total_cap():
                diagnostic_counts["global_cap_reached"] += 1
                stage_stats["providers"]["listenbrainz"]["skipped_global_cap"] += 1
                break
            seed_key = seed.artist_mbid or seed.canonical_name.lower()
            if not listenbrainz:
                diagnostic_counts["lb_missing_provider"] += 1
                stage_stats["providers"]["listenbrainz"]["skipped_provider"] += 1
                _v2_emit(f"[v2] {seed.canonical_name}: LB skipped=provider_unavailable")
                continue
            if not seed.artist_mbid:
                diagnostic_counts["lb_missing_seed_mbid"] += 1
                stage_stats["providers"]["listenbrainz"]["skipped_missing_seed_mbid"] += 1
                _v2_emit(f"[v2] {seed.canonical_name}: LB skipped=missing_seed_mbid")
                continue
            stage_stats["providers"]["listenbrainz"]["invoked"] += 1
            lb_similar = _fetch_lb_similar(listenbrainz, seed.artist_mbid)
            listenbrainz_result_count += len(lb_similar)
            stage_stats["providers"]["listenbrainz"]["raw_candidates"] += len(lb_similar)
            if not lb_similar:
                diagnostic_counts["lb_empty"] += 1
            max_lb_score = max((_safe_float(a.get("score"), 0.0) for a in lb_similar), default=0.0)
            for artist in lb_similar:
                if not _under_total_cap() or not _can_expand_similar(seed_key):
                    break
                target_mbid = artist.get("artist_mbid")
                target_name = artist.get("artist_name", "")
                if not target_name:
                    continue
                target_key = target_mbid or target_name.lower()
                _hydrate_tags_from_lastfm(target_key, target_name)
                tier = _similarity_tier(seed_key, target_key)
                cs = _listenbrainz_connection_strength(
                    score=_safe_float(artist.get("score"), 0.0),
                    share=_safe_float(artist.get("share"), 0.0),
                    max_score=max_lb_score,
                )
                if _add_edge(seed_key, seed.canonical_name, target_mbid, target_name,
                             "listenbrainz_similar", confidence=0.85, depth=1,
                             connection_strength=cs, tier=tier,
                             source_reliability="listenbrainz"):
                    similar_counts[seed_key] = similar_counts.get(seed_key, 0) + 1
                    lb_per_seed_added[seed_key] = lb_per_seed_added.get(seed_key, 0) + 1
                    stage_stats["providers"]["listenbrainz"]["added"] += 1
                else:
                    diagnostic_counts["lb_duplicate_or_tier1"] += 1
                    stage_stats["providers"]["listenbrainz"]["rejected_duplicate_or_tier1"] += 1

        for seed in seeds_sorted:
            if not _under_total_cap():
                diagnostic_counts["global_cap_reached"] += 1
                stage_stats["providers"]["lastfm"]["skipped_global_cap"] += 1
                break
            seed_key = seed.artist_mbid or seed.canonical_name.lower()
            if not lastfm:
                diagnostic_counts["lf_missing_provider"] += 1
                stage_stats["providers"]["lastfm"]["skipped_provider"] += 1
                _v2_emit(f"[v2] {seed.canonical_name}: Last.fm skipped=provider_unavailable")
                continue
            if similar_counts.get(seed_key, 0) >= _MAX_SIMILAR_PER_SEED:
                diagnostic_counts["lf_quota_full"] += 1
                stage_stats["providers"]["lastfm"]["skipped_quota_full"] += 1
                continue
            stage_stats["providers"]["lastfm"]["invoked"] += 1
            lf_similar = _fetch_lastfm_similar(lastfm, seed.canonical_name)
            lastfm_result_count += len(lf_similar)
            stage_stats["providers"]["lastfm"]["raw_candidates"] += len(lf_similar)
            if not lf_similar:
                diagnostic_counts["lf_empty"] += 1
            for artist in lf_similar:
                if not _under_total_cap() or not _can_expand_similar(seed_key):
                    break
                target_name = artist.get("artist_name", "")
                target_mbid = artist.get("artist_mbid")
                if not target_name:
                    continue
                target_key = target_mbid or target_name.lower()
                _hydrate_tags_from_lastfm(target_key, target_name)
                tier = _similarity_tier(seed_key, target_key)
                cs = float(artist.get("match", 0.5))
                if _add_edge(seed_key, seed.canonical_name, target_mbid, target_name,
                             "lastfm_similar", confidence=0.81, depth=1,
                             connection_strength=_clamp(cs, 0.25, 1.0), tier=tier,
                             source_reliability="lastfm_similar"):
                    similar_counts[seed_key] = similar_counts.get(seed_key, 0) + 1
                    lf_per_seed_added[seed_key] = lf_per_seed_added.get(seed_key, 0) + 1
                    stage_stats["providers"]["lastfm"]["added"] += 1
                else:
                    diagnostic_counts["lf_duplicate_or_tier1"] += 1
                    stage_stats["providers"]["lastfm"]["rejected_duplicate_or_tier1"] += 1
    # END DEPRECATED: Legacy non-interleaved block — remove after confirming interleaved stability
    stage_stats["phase_caps"]["after_lb"] = total_expanded
    stage_stats["phase_caps"]["after_lastfm"] = total_expanded

    # --- Depth-2 expansion from Tier 2A/2B artists ---
    # Only via MusicBrainz relations (depth 1 → 2)
    if musicbrainz:
        tier2_artists = [
            (key, name)
            for key, name in list(graph.artist_names.items())
            if graph.artist_tiers.get(key) in (TIER_2A, TIER_2B)
        ]
        for t2_key, t2_name in tier2_artists:
            mbid = t2_key if _looks_like_mbid(t2_key) else None
            if not mbid:
                continue
            mb_relations = _fetch_mb_artist_relations(musicbrainz, mbid)
            for rel in mb_relations:
                if not _under_total_cap():
                    break
                rel_type = rel.get("type", "").lower()
                target_mbid = rel.get("artist_mbid")
                target_name = rel.get("artist_name", "")
                if not target_name:
                    continue
                target_key = target_mbid or target_name.lower()
                if target_key in graph.artist_tiers:
                    continue
                if rel_type in _STRONG_ADJACENT_RELATIONS:
                    _add_edge(t2_key, t2_name, target_mbid, target_name,
                              rel_type, confidence=0.80, depth=2,
                              connection_strength=0.70, tier=TIER_3)
                elif rel_type in _MEDIUM_ADJACENT_RELATIONS:
                    _add_edge(t2_key, t2_name, target_mbid, target_name,
                              rel_type, confidence=0.65, depth=2,
                              connection_strength=0.50, tier=TIER_4)
    stage_stats["phase_caps"]["after_depth2_mb"] = total_expanded

    _v2_emit(
        "[v2] Graph provider results: "
        f"ListenBrainz={listenbrainz_result_count}, Last.fm={lastfm_result_count}"
    )
    _v2_emit(f"[v2] Graph diagnostics: {diagnostic_counts}")
    stage_stats["cap"]["used"] = total_expanded
    stage_stats["budgets"]["lastfm_tag_budget_used"] = lastfm_tag_budget_used
    stage_stats["budgets"]["lastfm_tag_budget_exhausted"] = lastfm_tag_budget_exhausted
    _v2_emit(f"[v2] Graph stage stats: {stage_stats}")
    return graph


# ---------------------------------------------------------------------------
# Internal helpers that call provider APIs
# ---------------------------------------------------------------------------

def _fetch_mb_artist_relations(mb: Any, artist_mbid: str) -> list[dict]:
    """Fetch artist-artist relations from MusicBrainz."""
    try:
        return mb.get_artist_relations(artist_mbid) or []
    except Exception:
        return []


def _fetch_lb_similar(lb: Any, artist_mbid: str) -> list[dict]:
    """Fetch similar artists from ListenBrainz, capped at _MAX_SIMILAR_PER_SEED."""
    try:
        results = lb.get_similar_artists(artist_mbid) or []
        return results[:_MAX_SIMILAR_PER_SEED]
    except Exception:
        return []


def _fetch_lastfm_similar(lf: Any, artist_name: str) -> list[dict]:
    """Fetch similar artists from Last.fm, capped at _MAX_SIMILAR_PER_SEED."""
    try:
        results = lf.get_similar_artists(artist_name) or []
        return results[:_MAX_SIMILAR_PER_SEED]
    except Exception:
        return []


def _looks_like_mbid(s: str) -> bool:
    """Heuristic: MBIDs are 36-char UUIDs."""
    return len(s) == 36 and s.count("-") == 4


def _listenbrainz_connection_strength(score: float, share: float, max_score: float) -> float:
    """Blend relative LB rank and listener share into a bounded edge strength."""
    normalized_score = score / max_score if max_score > 0 else 0.0
    strength = 0.65 * normalized_score + 0.35 * _clamp(share, 0.0, 1.0)
    return _clamp(strength, 0.25, 1.0)


def _safe_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(value, maximum))
