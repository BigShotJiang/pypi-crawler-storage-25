#!/usr/bin/env python3
"""
liquid_pulse.py
Pixel-art ASCII heartbeat. Slow, calm, abstract.
Strict standard ASCII (0x20-0x7E) only. Cross-platform.
"""

import sys
import time
import shutil
import os

# ---------------------------------------------------------------------------
# Pixel-art design
# ---------------------------------------------------------------------------
#
# The animation is a small fixed sequence of hand-tuned "pixel" frames.
# Each frame is one of a handful of discrete shapes -- no interpolation,
# no falloff, no procedural shading. Like a sprite animation.
#
# Reading the loop:
#     .       <- rest
#     o       <- inhale
#     O       <- beat
#    (O)      <- bloom
#     O       <- settle
#     o       <- exhale
#     .       <- rest (held)
#
# The (O) frame is the only "wide" frame: a tiny burst around the core.
# Everything else is a single character on the center column. That
# asymmetry -- one frame of bloom against many frames of stillness --
# is what makes it read as a heartbeat instead of a wobble.
# ---------------------------------------------------------------------------

# Each entry: (frame_string, hold_duration_seconds)
# Holds are uneven on purpose: long rests, quick beat, longer bloom.
SEQUENCE = [
    (".",     0.55),   # rest
    ("o",     0.18),   # inhale
    ("O",     0.10),   # beat
    ("(O)",   0.22),   # bloom -- the moment that sells it
    ("O",     0.10),   # settle
    ("o",     0.16),   # exhale
    (".",     0.45),   # rest
    (".",     0.50),   # rest held -- breathing room before next cycle
]


def render_centered(frame: str, width: int) -> str:
    """Center the frame string on a line of given width."""
    pad = (width - len(frame)) // 2
    return " " * pad + frame


def create_animation_frames(duration: float, width: int):
    """
    Generator that yields (frame_string, display_duration) tuples for the given total duration.
    Repeats the sequence, with gentle fade on the final repetition.
    """
    sequence_total = sum(hold for _, hold in SEQUENCE)
    cycles_wanted = duration / sequence_total
    full_cycles = int(cycles_wanted)
    remainder = duration - (full_cycles * sequence_total)

    # Play full cycles at normal speed
    for _ in range(full_cycles):
        for frame, hold in SEQUENCE:
            yield render_centered(frame, width), hold

    # Final partial cycle with fade: reduce hold times near the end
    elapsed_in_final = 0.0
    for frame, hold in SEQUENCE:
        if elapsed_in_final + hold > remainder:
            # Truncate this frame to fit remaining duration
            final_hold = remainder - elapsed_in_final
            if final_hold > 0.01:
                # Gentle fade: show frame but with shorter hold at the end
                yield render_centered(frame, width), final_hold
            break
        else:
            # Reduce hold times in the final cycle for gentle fade effect
            faded_hold = hold * 0.7
            yield render_centered(frame, width), faded_hold
            elapsed_in_final += faded_hold


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def get_width(default: int = 40) -> int:
    try:
        cols = shutil.get_terminal_size((default, 20)).columns
        return max(10, min(cols - 1, 60))
    except Exception:
        return default


def hide_cursor():
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()


def show_cursor():
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()


def main():
    # On Windows, enable ANSI escape codes if possible.
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass

    width = get_width()

    hide_cursor()
    try:
        sys.stdout.write("\n")
        while True:
            for frame, hold in SEQUENCE:
                line = render_centered(frame, width)
                # \r = back to line start, \033[K = clear to end of line
                sys.stdout.write("\r\033[K" + line)
                sys.stdout.flush()
                time.sleep(hold)
    except KeyboardInterrupt:
        sys.stdout.write("\n")
    finally:
        show_cursor()


if __name__ == "__main__":
    main()
