"""Internationalization module for Mamonia guided mode.

Provides translation support for Polish/English localization in guided mode only.
CLI commands, exports, and diagnostics remain in English.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

# Supported languages
SUPPORTED_LANGUAGES = ["en", "pl"]
DEFAULT_LANGUAGE = "en"

# Locale directory
LOCALE_DIR = Path(__file__).parent / "locales"


class I18nError(Exception):
    """Internationalization error."""


def load_locale(language: str) -> dict[str, Any]:
    """Load locale JSON file for the specified language.
    
    Args:
        language: Language code (e.g., "en", "pl")
        
    Returns:
        Dictionary with translation strings
        
    Raises:
        I18nError: If locale file cannot be loaded
    """
    locale_path = LOCALE_DIR / f"{language}.json"
    try:
        with open(locale_path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise I18nError(f"Locale file not found: {locale_path}")
    except json.JSONDecodeError as e:
        raise I18nError(f"Invalid JSON in locale file {locale_path}: {e}")


def get_translator(language: str) -> callable:
    """Get a translator function for the specified language.
    
    Args:
        language: Language code (e.g., "en", "pl")
        
    Returns:
        Function that takes a key and returns translated string
    """
    try:
        locale = load_locale(language)
    except I18nError:
        # Fall back to English if locale loading fails
        locale = load_locale(DEFAULT_LANGUAGE)
    
    def translate(key: str, **kwargs: Any) -> str:
        """Translate a key using the loaded locale.
        
        Args:
            key: Translation key (dot-separated path in JSON)
            **kwargs: Values for format placeholders
            
        Returns:
            Translated string with placeholders filled
        """
        # Navigate to the key in the locale dict
        parts = key.split(".")
        value = locale
        for part in parts:
            if isinstance(value, dict) and part in value:
                value = value[part]
            else:
                # Key not found, return the key itself as fallback
                return key
        
        if not isinstance(value, str):
            return key
        
        # Fill in placeholders
        if kwargs:
            try:
                return value.format(**kwargs)
            except (KeyError, ValueError):
                # Placeholder formatting failed, return untranslated
                return value
        
        return value
    
    return translate


def get_language_from_env() -> str | None:
    """Get language from MAMONIA_LANG environment variable.
    
    Returns:
        Language code if set and supported, None otherwise
    """
    lang = os.environ.get("MAMONIA_LANG", "").lower()
    if lang in SUPPORTED_LANGUAGES:
        return lang
    return None


def get_saved_language_preference(home_dir: Path) -> str | None:
    """Get saved language preference from preferences.json.
    
    Args:
        home_dir: Mamonia home directory
        
    Returns:
        Language code if preference exists and is supported, None otherwise
    """
    prefs_path = home_dir / "preferences.json"
    if not prefs_path.exists():
        return None
    
    try:
        with open(prefs_path, encoding="utf-8") as f:
            prefs = json.load(f)
        lang = prefs.get("language", "").lower()
        if lang in SUPPORTED_LANGUAGES:
            return lang
    except (json.JSONDecodeError, IOError):
        pass
    
    return None


def save_language_preference(home_dir: Path, language: str) -> None:
    """Save language preference to preferences.json.
    
    Args:
        home_dir: Mamonia home directory
        language: Language code to save
        
    Raises:
        I18nError: If preference cannot be saved
    """
    if language not in SUPPORTED_LANGUAGES:
        raise I18nError(f"Unsupported language: {language}")
    
    home_dir.mkdir(parents=True, exist_ok=True)
    prefs_path = home_dir / "preferences.json"
    
    # Load existing prefs or create new
    prefs = {}
    if prefs_path.exists():
        try:
            with open(prefs_path, encoding="utf-8") as f:
                prefs = json.load(f)
        except (json.JSONDecodeError, IOError):
            prefs = {}
    
    prefs["language"] = language
    
    try:
        with open(prefs_path, "w", encoding="utf-8") as f:
            json.dump(prefs, f, indent=2)
    except IOError as e:
        raise I18nError(f"Failed to save language preference: {e}")


def get_guided_language(home_dir: Path, from_cli: bool = False) -> str:
    """Determine the language to use for guided mode.
    
    Priority:
    1. MAMONIA_LANG environment variable
    2. Saved preference (if not from CLI)
    3. DEFAULT_LANGUAGE
    
    Args:
        home_dir: Mamonia home directory
        from_cli: Whether this is from an explicit CLI command (skip saved pref)
        
    Returns:
        Language code to use
    """
    # Check environment variable first
    env_lang = get_language_from_env()
    if env_lang:
        return env_lang
    
    # Check saved preference (only for bare guided mode)
    if not from_cli:
        saved_lang = get_saved_language_preference(home_dir)
        if saved_lang:
            return saved_lang
    
    return DEFAULT_LANGUAGE
