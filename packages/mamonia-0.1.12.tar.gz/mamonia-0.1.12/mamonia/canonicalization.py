"""
Canonical track resolution engine — §2 of the Human Logic Proposal.

Resolution priority (highest confidence first):
  1. ISRC  → MusicBrainz recording MBID             (confidence 1.00)
  2. UPC   → MusicBrainz release / release-group MBID (confidence 0.90)
  3. Artist + track title + duration               (confidence 0.90)
  4. Artist + album title + track title             (confidence 0.80)
  5. Fuzzy artist + track title                    (confidence 0.50)
  6. Artist-only (no track match)                  (confidence 0.30)
  7. Unresolved                                    (confidence 0.00)

Low-confidence items are kept but down-weighted; nothing is discarded.
"""

from __future__ import annotations

from typing import Any

from .models import CanonicalTrack, InputTrack
from .utils import normalize_key

# Match-confidence constants per §2 and §3
CONFIDENCE_ISRC = 1.00
CONFIDENCE_UPC = 0.90
CONFIDENCE_TITLE_DURATION = 0.90
CONFIDENCE_TITLE_ALBUM = 0.80
CONFIDENCE_FUZZY = 0.50
CONFIDENCE_ARTIST_ONLY = 0.30
CONFIDENCE_UNRESOLVED = 0.00


def resolve_track(
    track: InputTrack,
    musicbrainz: Any | None = None,
    spotify: Any | None = None,
    deezer: Any | None = None,
) -> CanonicalTrack:
    """Resolve an InputTrack to a CanonicalTrack through the 7-level priority chain."""
    base = CanonicalTrack(
        input_artist=track.artist,
        input_track=track.track,
        input_album=track.album,
        source_platform=track.source_platform,
        duration_ms=track.duration_ms,
        isrc=track.isrc,
        upc=track.upc,
        platform_ids=_collect_platform_ids(track),
        playlist_position=track.playlist_position,
    )

    # 1. ISRC → MusicBrainz recording MBID
    if track.isrc and musicbrainz:
        result = _try_isrc(track.isrc, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "isrc", "match_confidence": CONFIDENCE_ISRC})

    # 2. UPC/barcode → MB release / release-group
    if track.upc and musicbrainz:
        result = _try_upc(track.upc, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "upc", "match_confidence": CONFIDENCE_UPC})

    # 3. Artist + track title + duration
    if track.artist and track.track and track.duration_ms and musicbrainz:
        result = _try_title_duration(track.artist, track.track, track.duration_ms, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "title_duration", "match_confidence": CONFIDENCE_TITLE_DURATION})

    # 4. Artist + album title + track title
    if track.artist and track.track and track.album and musicbrainz:
        result = _try_title_album(track.artist, track.track, track.album, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "title_album", "match_confidence": CONFIDENCE_TITLE_ALBUM})

    # 5. Fuzzy artist + track title (no duration / album confirmation)
    if track.artist and track.track and musicbrainz:
        result = _try_fuzzy(track.artist, track.track, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "fuzzy", "match_confidence": CONFIDENCE_FUZZY})

    # 6. Artist-only — resolve just the artist MBID, no recording
    if track.artist and musicbrainz:
        result = _try_artist_only(track.artist, musicbrainz)
        if result:
            return base.model_copy(update={**result, "resolution_method": "artist_only", "match_confidence": CONFIDENCE_ARTIST_ONLY})

    # 7. Unresolved — keep the track with zero confidence; never discard
    return base.model_copy(update={
        "artist_name_canonical": track.artist,
        "resolution_method": "unresolved",
        "match_confidence": CONFIDENCE_UNRESOLVED,
    })


def resolve_tracks(
    tracks: list[InputTrack],
    musicbrainz: Any | None = None,
    spotify: Any | None = None,
    deezer: Any | None = None,
    storage: Any | None = None,
    force_refresh: bool = False,
    cache_stats: dict[str, int] | None = None,
    progress_callback: Any | None = None,
) -> list[CanonicalTrack]:
    """Resolve a list of InputTracks. Returns one CanonicalTrack per input, preserving order.
    
    If an InputTrack has multiple artists (in the artists list), each artist is resolved
    separately and a separate CanonicalTrack is created for each artist.
    """
    result: list[CanonicalTrack] = []
    processed = 0
    total = sum(max(1, len(track.all_artist_names())) for track in tracks)
    for track in tracks:
        # Get all artists from the track (primary artist + additional artists)
        all_artists = track.all_artist_names()
        for artist in all_artists:
            # Create a copy of the track with the current artist as the primary artist
            track_copy = track.model_copy(update={"artist": artist})
            processed += 1
            if callable(progress_callback):
                try:
                    progress_callback(track_copy, processed, total)
                except Exception:
                    pass
            canonical = _resolve_track_cached(
                track_copy,
                musicbrainz=musicbrainz,
                spotify=spotify,
                deezer=deezer,
                storage=storage,
                force_refresh=force_refresh,
                cache_stats=cache_stats,
            )
            result.append(canonical)
    return result


def _resolve_track_cached(
    track: InputTrack,
    *,
    musicbrainz: Any | None = None,
    spotify: Any | None = None,
    deezer: Any | None = None,
    storage: Any | None = None,
    force_refresh: bool = False,
    cache_stats: dict[str, int] | None = None,
) -> CanonicalTrack:
    if storage is None:
        return resolve_track(track, musicbrainz=musicbrainz, spotify=spotify, deezer=deezer)
    if not force_refresh:
        get_cached = getattr(storage, "get_canonical_track", None)
        if callable(get_cached):
            cached = get_cached(track)
            if cached is not None:
                _increment_cache_stat(cache_stats, "hits")
                return _with_current_input(cached, track)
    _increment_cache_stat(cache_stats, "misses")
    canonical = resolve_track(track, musicbrainz=musicbrainz, spotify=spotify, deezer=deezer)
    save_cached = getattr(storage, "upsert_canonical_track", None)
    if callable(save_cached):
        save_cached(track, canonical)
    return canonical


def _increment_cache_stat(stats: dict[str, int] | None, name: str) -> None:
    if stats is not None:
        stats[name] = stats.get(name, 0) + 1


def _with_current_input(canonical: CanonicalTrack, track: InputTrack) -> CanonicalTrack:
    return canonical.model_copy(update={
        "input_artist": track.artist,
        "input_track": track.track,
        "input_album": track.album,
        "source_platform": track.source_platform,
        "duration_ms": track.duration_ms,
        "isrc": track.isrc,
        "upc": track.upc,
        "platform_ids": _collect_platform_ids(track),
        "playlist_position": track.playlist_position,
    })


# ---------------------------------------------------------------------------
# Internal resolution helpers
# ---------------------------------------------------------------------------

def _try_isrc(isrc: str, mb: Any) -> dict | None:
    lookup = getattr(mb, "lookup_recording_by_isrc", None)
    if not callable(lookup):
        return None
    data = lookup(isrc)
    if not data:
        return None
    return {
        "recording_mbid": data.get("recording_mbid"),
        "release_mbid": data.get("release_mbid"),
        "release_group_mbid": data.get("release_group_mbid"),
        "artist_mbid": data.get("artist_mbid"),
        "artist_name_canonical": data.get("artist_name", ""),
    }


def _try_upc(upc: str, mb: Any) -> dict | None:
    lookup = getattr(mb, "lookup_release_by_upc", None)
    if not callable(lookup):
        return None
    data = lookup(upc)
    if not data:
        return None
    return {
        "release_mbid": data.get("release_mbid"),
        "release_group_mbid": data.get("release_group_mbid"),
        "artist_mbid": data.get("artist_mbid"),
        "artist_name_canonical": data.get("artist_name", ""),
    }


def _try_title_duration(artist: str, title: str, duration_ms: int, mb: Any) -> dict | None:
    fn = getattr(mb, "search_recording", None)
    if not callable(fn):
        return None
    data = fn(artist, title, duration_ms=duration_ms)
    if not data:
        return None
    # Accept only if duration delta is within 5 seconds
    mb_dur = data.get("duration_ms") or 0
    if mb_dur and abs(mb_dur - duration_ms) > 5000:
        return None
    return _recording_result(data)


def _try_title_album(artist: str, title: str, album: str, mb: Any) -> dict | None:
    fn = getattr(mb, "search_recording", None)
    if not callable(fn):
        return None
    # Search without duration; validate by album title match
    data = fn(artist, title)
    if not data:
        return None
    # Cross-check: search releases and confirm album association
    search_fn = getattr(mb, "search_releases", None)
    if callable(search_fn):
        releases = search_fn(f'artist:"{artist}" AND release:"{album}"', limit=5)
        release_ids = {r.get("id") for r in releases if r.get("id")}
        if data.get("release_mbid") and data["release_mbid"] not in release_ids:
            return None
    return _recording_result(data)


def _try_fuzzy(artist: str, title: str, mb: Any) -> dict | None:
    fn = getattr(mb, "search_recording", None)
    if not callable(fn):
        return None
    # Lowercase both sides for fuzzy matching
    data = fn(artist, title)
    if not data:
        return None
    # Require at least the artist name to roughly match
    mb_artist = normalize_key(data.get("artist_name", ""))
    input_artist = normalize_key(artist)
    if mb_artist and input_artist and mb_artist not in input_artist and input_artist not in mb_artist:
        return None
    return _recording_result(data)


def _try_artist_only(artist: str, mb: Any) -> dict | None:
    fn = getattr(mb, "search_artist", None)
    if not callable(fn):
        return None
    data = fn(artist)
    if not data or not data.get("id"):
        return None
    return {
        "artist_mbid": data["id"],
        "artist_name_canonical": data.get("name", artist),
    }


def _recording_result(data: dict) -> dict:
    return {
        "recording_mbid": data.get("recording_mbid"),
        "release_mbid": data.get("release_mbid"),
        "release_group_mbid": data.get("release_group_mbid"),
        "artist_mbid": data.get("artist_mbid"),
        "artist_name_canonical": data.get("artist_name", ""),
    }


def _collect_platform_ids(track: InputTrack) -> dict[str, str]:
    ids: dict[str, str] = {}
    if track.spotify_track_id:
        ids["spotify"] = track.spotify_track_id
    if track.tidal_track_id:
        ids["tidal"] = track.tidal_track_id
    return ids
