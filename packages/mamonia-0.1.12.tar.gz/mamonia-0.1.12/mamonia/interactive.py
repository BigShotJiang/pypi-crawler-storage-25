from __future__ import annotations

import dataclasses
import datetime as dt
import json
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Callable, Any

from rich.console import Console
from rich.text import Text

from .analysis import build_taste_profile
from .config import canonical_env_path, load_settings, save_env_credential
from .discovery import track_keys_from_input
from .discovery_window import DiscoveryWindow, parse_discovery_window_input
from .i18n import (
    SUPPORTED_LANGUAGES,
    get_guided_language,
    get_language_from_env,
    get_saved_language_preference,
    get_translator,
    save_language_preference,
)
from .progress import choose_busy_status_reporter
from .input import looks_like_apple_music_playlist, looks_like_spotify_playlist, looks_like_tidal_playlist, parse_text_file
from .models import TasteProfile
from .profiles import seed_tracks_from_payload, source_identity_from_tracks
from .providers import ProviderRateLimit, ProviderUnavailable
from .providers.deezer import DeezerProvider
from .providers.lastfm import LastFMProvider
from .providers.listenbrainz import ListenBrainzProvider
from .providers.musicbrainz import MusicBrainzProvider
from .providers.apple_music import AppleMusicProvider
from .providers.spotify import SpotifyProvider
from .providers.tidal import TidalProvider
from .storage import Storage, artist_enrichment_key
from .workflow import (
    DiscoverOptions,
    PlaylistConfigCallback,
    ProfileDecisionContext,
    WorkflowAbort,
    consume_pending_availability_notice_rows,
    enrich_source_name,
    profile_summary_line,
    run_discover,
    _save_latest_profile,
    _store_input_track_enrichment,
)
from .liquid_pulse import create_animation_frames, get_width as _lp_get_width, hide_cursor as _lp_hide_cursor, show_cursor as _lp_show_cursor

Emitter = Callable[[str], None]

# CLI styling constants
GUIDED_DEFAULT_OUTPUT = "csv"
GUIDED_DEFAULT_SOURCE = "Spotify"
GUIDED_ACCENT = "#ff5a5a"
GUIDED_QMARK_COLOR = "#6b7280"
_M_PRE_ROLL = 0.4
_M_FADE_STEP = 0.08
_M_FADE_HOLD = 0.35
_M_TYPE_TITLE = 0.025
_M_TYPE_SUBTITLE = 0.035
_M_POST_SUBTITLE = 0.65
_M_SETTLE = 0.85
_M_CURSOR = "|"
_M_TYPING_WAIT = 2.9
_M_SPINNER_FRAME = 0.17

_PROVIDERS = [
    ("MusicBrainz API", "mb_contact_configured", "musicbrainz", [
        ("MB_CONTACT_EMAIL", "menu.cache.musicbrainz_email_optional"),
    ]),
    ("Spotify API", "spotify_configured", "spotify", [
        ("SPOTIPY_CLIENT_ID", "menu.cache.spotify_client_id"),
        ("SPOTIPY_CLIENT_SECRET", "menu.cache.spotify_client_secret"),
    ]),
    ("LastFM API", "lastfm_configured", "lastfm", [
        ("LASTFM_API_KEY", "menu.cache.lastfm_api_key"),
    ]),
    ("Tidal API", "tidal_configured", "tidal", [
        ("TIDAL_CLIENT_ID", "menu.cache.tidal_client_id"),
        ("TIDAL_CLIENT_SECRET", "menu.cache.tidal_client_secret"),
    ]),
    ("Apple Music API", "apple_music_configured", "apple_music", [
        ("APPLE_MUSIC_DEVELOPER_TOKEN", "menu.cache.apple_music_developer_token"),
        ("APPLE_MUSIC_USER_TOKEN", "menu.cache.apple_music_user_token"),
    ]),
    ("ListenBrainz", "listenbrainz_configured", "listenbrainz", [
        ("LISTENBRAINZ_USER_TOKEN", "menu.cache.listenbrainz_token"),
    ]),
]


class _StyledPrompts:
    def __init__(self, prompts: object, style: object, ctrl_c_hint: str = None):
        self.prompts = prompts
        self.style = style
        self.ctrl_c_hint = ctrl_c_hint
        self._default_hint = "Press CTRL+C to go back"

    def select(self, *args, **kwargs):
        print()
        kwargs.setdefault("style", self.style)
        hint = self.ctrl_c_hint if self.ctrl_c_hint is not None else self._default_hint
        if args and isinstance(args[0], str) and hint:
            message = args[0]
            if hint not in message:
                if message.endswith("\n"):
                    message = f"{message[:-1]}  {hint}\n"
                else:
                    message = f"{message}  {hint}"
            args = (message, *args[1:])
        kwargs.setdefault("instruction", "")
        return _BackOnInterruptPrompt(self.prompts.select(*args, **kwargs))

    def text(self, *args, **kwargs):
        print()
        kwargs.setdefault("style", self.style)
        hint = self.ctrl_c_hint if self.ctrl_c_hint is not None else self._default_hint
        kwargs.setdefault("instruction", hint)
        return _BackOnInterruptPrompt(self.prompts.text(*args, **kwargs))

    def confirm(self, *args, **kwargs):
        print()
        kwargs.setdefault("style", self.style)
        return _BackOnInterruptPrompt(self.prompts.confirm(*args, **kwargs))


class _BackOnInterruptPrompt:
    def __init__(self, prompt: object):
        self.prompt = prompt

    def ask(self):
        try:
            return self.prompt.ask()
        except KeyboardInterrupt:
            return None


def _questionary(ctrl_c_hint: str = None) -> object:
    try:
        import questionary
    except Exception as exc:
        raise RuntimeError("questionary is not installed. Run: pip install -e .") from exc
    return _StyledPrompts(questionary, _guided_style(questionary), ctrl_c_hint)


def _guided_style(questionary: object) -> object:
    return questionary.Style(
        [
            ("qmark", f"fg:{GUIDED_QMARK_COLOR}"),
            ("question", "bold"),
            ("answer", f"fg:{GUIDED_ACCENT} bold"),
            ("pointer", f"fg:{GUIDED_ACCENT} bold"),
            ("highlighted", f"fg:{GUIDED_ACCENT} bold"),
            ("selected", f"fg:{GUIDED_ACCENT}"),
        ]
    )



def _type_with_glitch(console: Console, text: str, style: str = "", delay: float = 0.0, is_text: bool = False) -> None:
    """Print styled text immediately."""
    is_tty = bool(getattr(console, "is_terminal", False))
    if not is_tty:
        if is_text:
            console.print(Text(text, style=style))
        else:
            console.print(f"[{style}]{text}[/]")
        return

    from rich.text import Text
    if is_text:
        console.print(Text(text, style=style))
    else:
        console.print(f"[{style}]{text}[/]")


def _typing_indicator(console: Console, duration: float = _M_TYPING_WAIT, color: str = GUIDED_ACCENT) -> None:
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass
    width = _lp_get_width()
    _lp_hide_cursor()
    try:
        for line, hold in create_animation_frames(duration, width):
            sys.stdout.write("\r\033[K" + line)
            sys.stdout.flush()
            time.sleep(hold)
    except Exception:
        pass
    finally:
        _lp_show_cursor()


def _render_guided_intro(console: Console, t: callable) -> None:
    is_tty = bool(getattr(console, "is_terminal", False))
    presented_by = t("intro.presented_by", brand="heartless.one")
    title = t("title.main")
    subtitle = t("title.subtitle")

    if not is_tty:
        console.print(f"[bold {GUIDED_ACCENT}]{title}[/]")
        console.print(Text(subtitle, style="italic dim"))
        return

    time.sleep(_M_PRE_ROLL)
    _typing_indicator(console, duration=4.5, color=GUIDED_ACCENT)
    console.print()
    console.print(f"[dim]{presented_by}[/dim]")
    time.sleep(_M_SETTLE)
    console.print()

    _type_with_glitch(console, title, style=f"bold {GUIDED_ACCENT}")
    time.sleep(_M_SETTLE)

    _type_with_glitch(console, subtitle, style="italic dim", is_text=True)
    time.sleep(_M_POST_SUBTITLE)


def launch_guided(emit: Emitter = print, emit_error: Emitter = print) -> None:
    """Run Mamonia's guided terminal entrypoint with beautiful intro and CLI menus."""
    settings = load_settings()
    home_dir = Path(settings.data_dir)

    # Determine language
    language = get_guided_language(home_dir, from_cli=False)

    # Prompt for language if no preference exists
    if get_language_from_env() is None and get_saved_language_preference(home_dir) is None:
        prompts = _questionary()
        lang_choice = prompts.select(
            "Select language / Wybierz język",
            choices=["English", "Polski"],
            default="English",
        ).ask()
        if lang_choice == "Polski":
            language = "pl"
        else:
            language = "en"
        save_language_preference(home_dir, language)

    # Get translator
    t = get_translator(language)

    # Get locale-dependent ctrl+c hint
    ctrl_c_hint = t("prompt.back_hint")

    print()
    console = Console(force_terminal=True, soft_wrap=True)
    _render_guided_intro(console, t)
    print()
    prompts = _questionary(ctrl_c_hint)

    guard_lang_changed = _initial_configuration_guard(prompts, emit, console, t, home_dir)
    if guard_lang_changed:
        language = get_guided_language(home_dir, from_cli=False)
        t = get_translator(language)
        ctrl_c_hint = t("prompt.back_hint")
        prompts = _questionary(ctrl_c_hint)

    while True:
        choice = prompts.select(
            t("menu.root.title"),
            choices=[
                t("menu.root.discover"),
                t("menu.root.manage_library"),
                t("menu.root.system_settings"),
                t("menu.root.exit"),
            ],
            default=t("menu.root.discover"),
        ).ask()
        if choice in {None, t("menu.root.exit")}:
            print()
            emit("Bye.")
            return
        if choice == t("menu.root.discover"):
            _discover_menu(prompts, emit, emit_error, t, language)
        elif choice == t("menu.root.manage_library"):
            _manage_library_menu(prompts, emit, t, home_dir)
        elif choice == t("menu.root.system_settings"):
            language_changed = _system_settings_menu(prompts, emit, t, home_dir)
            if language_changed:
                language = get_guided_language(home_dir, from_cli=False)
                t = get_translator(language)
                ctrl_c_hint = t("prompt.back_hint")
                prompts = _questionary(ctrl_c_hint)




def _discover_menu(prompts: object, emit: Emitter, emit_error: Emitter, t: callable, language: str) -> None:
    saved_profile_choice = t("menu.discovery.saved_profile")
    source_choice = prompts.select(
        t("menu.discovery.source"),
        choices=[
            t("menu.discovery.spotify_playlist"),
            t("menu.discovery.tidal_playlist"),
            t("menu.discovery.apple_music_playlist"),
            t("menu.discovery.text_file"),
            saved_profile_choice,
            t("menu.discovery.back"),
        ],
        default=t("menu.discovery.spotify_playlist"),
    ).ask()
    if source_choice in {None, t("menu.discovery.back")}:
        return

    playlist: str | None = None
    profile_ref: str | None = None
    if source_choice == saved_profile_choice:
        with _storage() as storage:
            profiles = storage.list_taste_profiles()
        if not profiles:
            emit(t("error.no_saved_profiles"))
            return
        default_profile = _profile_choice_label(profiles[0]) if profiles else "Back"
        answer = prompts.select(
            "Choose saved profile",
            choices=[_profile_choice_label(item) for item in profiles] + ["Back"],
            default=default_profile,
        ).ask()
        if answer in {None, "Back"}:
            return
        profile_id = _profile_id_from_choice(str(answer))
        if profile_id is None:
            return
        profile_ref = str(profile_id)
    elif source_choice == t("menu.discovery.spotify_playlist"):
        # Sub-menu for Spotify playlist source
        spotify_action = prompts.select(
            t("menu.discovery.spotify_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_spotify_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if spotify_action in {None, t("menu.discovery.back")}:
            return
        if spotify_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            spotify = SpotifyProvider(settings)
            try:
                playlists = spotify.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks} {track_label(p.tracks)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        # Find the playlist ID from the selected choice
                        for p in playlists:
                            if f"{p.name} ({p.tracks} {track_label(p.tracks)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Spotify playlist URL or ID")
            except ProviderUnavailable as e:
                emit_error(str(e))
                playlist = _ask_text(prompts, "Spotify playlist URL or ID")
            except ProviderRateLimit as e:
                emit_error(str(e))
                playlist = _ask_text(prompts, "Spotify playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Spotify playlist URL or ID")
        if not playlist:
            return
    elif source_choice == t("menu.discovery.tidal_playlist"):
        tidal_action = prompts.select(
            t("menu.discovery.tidal_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_tidal_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if tidal_action in {None, t("menu.discovery.back")}:
            return
        if tidal_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            tidal = TidalProvider(settings)
            try:
                playlists = tidal.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        for p in playlists:
                            if f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Tidal playlist URL or ID")
            except (ProviderRateLimit, ProviderUnavailable):
                playlist = _ask_text(prompts, "Tidal playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Tidal playlist URL or ID")
        if not playlist:
            return
    elif source_choice == t("menu.discovery.apple_music_playlist"):
        apple_action = prompts.select(
            t("menu.discovery.apple_music_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_apple_music_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if apple_action in {None, t("menu.discovery.back")}:
            return
        if apple_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            apple_music = AppleMusicProvider(settings)
            try:
                playlists = apple_music.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        for p in playlists:
                            if f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
            except (ProviderRateLimit, ProviderUnavailable):
                playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
        if not playlist:
            return
    else:
        playlist = _ask_text(prompts, "Text file path (.txt or .csv)")
        if not playlist:
            return

    # Check Spotify credentials before proceeding with playlist creation
    settings = load_settings()
    spotify = SpotifyProvider(settings)

    options = DiscoverOptions(
        playlist=playlist,
        profile_ref=profile_ref,
        profile_decision_callback=_guided_profile_decision(prompts) if playlist else None,
        output=GUIDED_DEFAULT_OUTPUT,
        create_spotify_playlist=False,
        create_tidal_playlist=False,
        create_apple_playlist=False,
        language=language,
    )
    advanced = prompts.confirm(t("prompt.advanced_settings.title"), default=False).ask()
    if advanced is None:
        return
    if advanced:
        options = _advanced_discover_options(prompts, options, t, emit=emit)
        if options is None:
            return
    else:
        # When skipping Advanced, use default CSV output (playlist config asked later)
        options = DiscoverOptions(
            playlist=options.playlist,
            profile_ref=options.profile_ref,
            profile_decision_callback=options.profile_decision_callback,
            output="csv",
            output_path=None,
            limit=40,
            max_candidates=0,
            discovery_mode="balanced",
            dry_run=False,
            verbose=False,
            create_spotify_playlist=False,
            spotify_playlist_name=None,
            reuse_profile=options.reuse_profile if hasattr(options, "reuse_profile") else False,
            months=options.months if hasattr(options, "months") else 6,
            discovery_window=options.discovery_window if hasattr(options, "discovery_window") else None,
            max_tracks=options.max_tracks if hasattr(options, "max_tracks") else 3,
            force_refresh=options.force_refresh if hasattr(options, "force_refresh") else False,
            enrichment_only=options.enrichment_only if hasattr(options, "enrichment_only") else False,
            penalize_frequent_artists=options.penalize_frequent_artists if hasattr(options, "penalize_frequent_artists") else False,
            shuffle_releases=options.shuffle_releases if hasattr(options, "shuffle_releases") else False,
            create_tidal_playlist=False,
            tidal_playlist_name=None,
            create_apple_playlist=False,
            apple_playlist_name=None,
            apple_target_playlist=None,
            save_selection_logic=options.save_selection_logic if hasattr(options, "save_selection_logic") else False,
            selection_logic_path=options.selection_logic_path if hasattr(options, "selection_logic_path") else None,
            language=language,
        )

    dedup_choice = prompts.confirm(t("prompt.deduplication.ask"), default=True).ask()
    if dedup_choice is None:
        return
    options = dataclasses.replace(options, run_deduplication=bool(dedup_choice))

    options = dataclasses.replace(
        options,
        playlist_config_callback=_make_playlist_config_callback(prompts, t),
        expansion_memory_save_callback=_make_expansion_memory_save_callback(prompts, t),
        shortage_refill_continue_callback=_make_shortage_refill_continue_callback(prompts, t),
    )

    try:
        # Clear any stale rows before a new discovery run.
        consume_pending_availability_notice_rows()
        run_discover(options, emit=emit, emit_error=emit_error)
        print()
    except KeyboardInterrupt:
        emit_error(t("error.canceled"))
        print()
    except ProviderRateLimit as exc:
        if exc.provider == "Spotify" and exc.action == "RECONNECT_SPOTIFY":
            emit_error(f"Error: {exc}")
            emit_error("Spotify authorization expired. Run: mamonia spotify-auth")
        elif exc.provider == "Spotify" and exc.action == "CONNECT_SPOTIFY":
            emit_error(f"Error: {exc}")
            emit_error("No Spotify account linked. Run: mamonia spotify-auth")
        else:
            emit_error(f"Error: {exc}")
        print()
    except WorkflowAbort as exc:
        emit_error(f"Error: {exc.message}")
        print()
    except Exception:
        traceback.print_exc()
        # Add spacer lines so traceback tail is not hidden by live progress UI.
        emit_error("")
        emit_error("")
        emit_error("")
        print()


def _advanced_discover_options(prompts: object, options: DiscoverOptions, t: callable, emit: Emitter = print) -> DiscoverOptions | None:
    state = {
        "months": options.months,
        "discovery_window": options.discovery_window,
        "max_tracks": options.max_tracks,
        "limit": options.limit,
        "max_candidates": options.max_candidates,
        "penalize_frequent_artists": options.penalize_frequent_artists,
        "discovery_mode": options.discovery_mode,
        "shuffle_releases": options.shuffle_releases,
        "use_streaming_providers": options.use_streaming_providers,
        "use_profile_expansion_memory": options.use_profile_expansion_memory,
        "verbose": options.verbose,
        "output": options.output,
        "output_path": str(options.output_path) if options.output_path else "",
        "save_selection_logic": options.save_selection_logic,
        "selection_logic_path": str(options.selection_logic_path) if options.selection_logic_path else "",
    }

    header = t("prompt.advanced_settings.header")
    description = t("prompt.advanced_settings.description")
    category_count = t("prompt.advanced_settings.category_track_count")
    category_algo = t("prompt.advanced_settings.category_algorithm")
    category_output = t("prompt.advanced_settings.category_output")
    done_choice = t("prompt.advanced_settings.done")
    back_choice = t("menu.discovery.back")

    menu_prompt = f"{header}\n{description}"

    while True:
        section = prompts.select(
            menu_prompt,
            choices=[category_count, category_algo, category_output, done_choice, back_choice],
            default=category_count,
        ).ask()
        if section in {None, back_choice}:
            return None
        if section == done_choice:
            break
        if section == category_count:
            mode_choice = prompts.select(
                t("prompt.advanced_settings.time_range_mode"),
                choices=[
                    t("prompt.advanced_settings.time_range_mode_months"),
                    t("prompt.advanced_settings.time_range_mode_specific"),
                ],
                default=t("prompt.advanced_settings.time_range_mode_months"),
            ).ask()
            if mode_choice is None:
                continue
            if mode_choice == t("prompt.advanced_settings.time_range_mode_months"):
                months = _ask_int(prompts, t("prompt.advanced_settings.months"), int(state["months"]), minimum=1)
                if months is None:
                    continue
                state["months"] = months
                state["discovery_window"] = None
            else:
                discovery_window = _ask_discovery_window(
                    prompts,
                    t("prompt.advanced_settings.discovery_window"),
                    default=t("prompt.advanced_settings.discovery_window_placeholder"),
                )
                if discovery_window is None:
                    continue
                state["discovery_window"] = discovery_window
            max_tracks = _ask_int(prompts, t("prompt.advanced_settings.max_tracks"), int(state["max_tracks"]), minimum=0)
            if max_tracks is None:
                continue
            limit = _ask_int(prompts, t("prompt.advanced_settings.limit"), int(state["limit"]), minimum=1)
            if limit is None:
                continue
            max_candidates = _ask_int(prompts, t("prompt.advanced_settings.max_candidates"), int(state["max_candidates"]), minimum=0)
            if max_candidates is None:
                continue
            if 0 < max_candidates <= 10:
                penalize_choice = False
                emit(t("prompt.advanced_settings.penalize_frequent_artists_skipped"))
            else:
                penalize_choice = prompts.confirm(
                    t("prompt.advanced_settings.penalize_frequent_artists"),
                    default=bool(state["penalize_frequent_artists"]),
                ).ask()
                if penalize_choice is None:
                    continue
            state["max_tracks"] = max_tracks
            state["limit"] = limit
            state["max_candidates"] = max_candidates
            state["penalize_frequent_artists"] = bool(penalize_choice)
            continue
        if section == category_algo:
            discovery_mode_choice = prompts.select(
                t("prompt.advanced_settings.discovery_mode"),
                choices=[
                    t("prompt.advanced_settings.discovery_mode_balanced"),
                    t("prompt.advanced_settings.discovery_mode_standard"),
                    t("prompt.advanced_settings.discovery_mode_deep_cuts"),
                    t("prompt.advanced_settings.discovery_mode_deep_diverse"),
                ],
                default={
                    "standard": t("prompt.advanced_settings.discovery_mode_standard"),
                    "top_first": t("prompt.advanced_settings.discovery_mode_standard"),
                    "deep_cuts": t("prompt.advanced_settings.discovery_mode_deep_cuts"),
                    "deep_diverse": t("prompt.advanced_settings.discovery_mode_deep_diverse"),
                }.get(str(state["discovery_mode"]), t("prompt.advanced_settings.discovery_mode_balanced")),
            ).ask()
            if discovery_mode_choice is None:
                continue
            mode_map = {
                t("prompt.advanced_settings.discovery_mode_standard"): "standard",
                t("prompt.advanced_settings.discovery_mode_deep_cuts"): "deep_cuts",
                t("prompt.advanced_settings.discovery_mode_balanced"): "balanced",
                t("prompt.advanced_settings.discovery_mode_deep_diverse"): "deep_diverse",
            }
            shuffle_choice = prompts.confirm(
                t("prompt.advanced_settings.shuffle_releases"),
                default=bool(state["shuffle_releases"]),
            ).ask()
            if shuffle_choice is None:
                continue
            streaming_choice = prompts.confirm(
                t("prompt.advanced_settings.use_streaming_providers"),
                default=bool(state["use_streaming_providers"]),
            ).ask()
            if streaming_choice is None:
                continue
            verbose_choice = prompts.confirm(
                t("prompt.advanced_settings.verbose"),
                default=bool(state["verbose"]),
            ).ask()
            if verbose_choice is None:
                continue
            memory_choice = prompts.confirm(
                t("prompt.advanced_settings.use_profile_expansion_memory"),
                default=bool(state["use_profile_expansion_memory"]),
            ).ask()
            if memory_choice is None:
                continue
            state["discovery_mode"] = mode_map.get(discovery_mode_choice, "balanced")
            state["shuffle_releases"] = bool(shuffle_choice)
            state["use_streaming_providers"] = bool(streaming_choice)
            state["verbose"] = bool(verbose_choice)
            state["use_profile_expansion_memory"] = bool(memory_choice)
            continue
        if section == category_output:
            output_choice = prompts.select(
                t("prompt.advanced_settings.output_format"),
                choices=["csv", "txt", "json"],
                default=str(state["output"]),
            ).ask()
            if output_choice is None:
                continue
            output_path_value = _ask_text(prompts, t("prompt.advanced_settings.output_path"), default=str(state["output_path"]))
            if output_path_value is None:
                continue
            save_selection_logic_choice = prompts.confirm(
                t("prompt.advanced_settings.save_selection_logic"),
                default=bool(state["save_selection_logic"]),
            ).ask()
            if save_selection_logic_choice is None:
                continue
            selection_logic_path_value = str(state["selection_logic_path"])
            if save_selection_logic_choice:
                selection_logic_path_prompt = _ask_text(
                    prompts,
                    t("prompt.advanced_settings.selection_logic_path"),
                    default=selection_logic_path_value,
                )
                if selection_logic_path_prompt is None:
                    continue
                selection_logic_path_value = selection_logic_path_prompt
            else:
                selection_logic_path_value = ""
            state["output"] = output_choice or "csv"
            state["output_path"] = output_path_value
            state["save_selection_logic"] = bool(save_selection_logic_choice)
            state["selection_logic_path"] = selection_logic_path_value
            continue

    options_result = DiscoverOptions(
        playlist=options.playlist,
        profile_ref=options.profile_ref,
        reuse_profile=options.reuse_profile,
        months=int(state["months"]),
        discovery_window=state["discovery_window"] if isinstance(state["discovery_window"], DiscoveryWindow) else None,
        max_tracks=int(state["max_tracks"]),
        output=str(state["output"]),
        output_path=Path(str(state["output_path"])).expanduser() if state["output_path"] else None,
        limit=int(state["limit"]),
        max_candidates=int(state["max_candidates"]),
        discovery_mode=str(state["discovery_mode"]),
        dry_run=options.dry_run,
        verbose=bool(state["verbose"]),
        global_memory=True,
        create_spotify_playlist=False,
        spotify_playlist_name=None,
        create_tidal_playlist=False,
        tidal_playlist_name=None,
        save_selection_logic=bool(state["save_selection_logic"]),
        selection_logic_path=Path(str(state["selection_logic_path"])).expanduser() if state["selection_logic_path"] else None,
        profile_decision_callback=options.profile_decision_callback,
        enrichment_only=options.enrichment_only,
        penalize_frequent_artists=bool(state["penalize_frequent_artists"]),
        shuffle_releases=bool(state["shuffle_releases"]),
        use_streaming_providers=bool(state["use_streaming_providers"]),
        use_profile_expansion_memory=state["use_profile_expansion_memory"],
        run_deduplication=True,
        language=options.language,
    )
    return options_result


def _guided_profile_decision(prompts: object) -> Callable[[ProfileDecisionContext], str | None]:
    def choose(context: ProfileDecisionContext) -> str | None:
        if context.changed and context.enrichment_complete:
            choices = [
                "Update profile with playlist changes",
                "Reuse saved profile unchanged",
                "Refresh enrichment and rebuild from current playlist",
                "Build fresh profile",
            ]
            default = "Update profile with playlist changes"
        elif context.changed:
            choices = [
                "Update profile with playlist changes",
                "Refresh incomplete enrichment from current playlist",
                "Reuse saved profile unchanged",
                "Build fresh profile",
            ]
            default = "Update profile with playlist changes"
        elif context.enrichment_complete:
            choices = [
                "Reuse saved profile",
                "Refresh enrichment anyway",
                "Build fresh profile",
            ]
            default = "Reuse saved profile"
        else:
            choices = [
                "Refresh incomplete enrichment from current playlist",
                "Reuse saved profile",
                "Build fresh profile",
            ]
            default = "Refresh incomplete enrichment from current playlist"
        answer = prompts.select(
            f"Saved profile #{context.profile_id}: {context.profile_name}",
            choices=choices,
            default=default,
        ).ask()
        decision = {
            "Reuse saved profile": "reuse",
            "Reuse saved profile unchanged": "reuse",
            "Update profile with playlist changes": "delta_update",
            "Refresh enrichment and rebuild from current playlist": "refresh_enrichment",
            "Refresh incomplete enrichment from current playlist": "refresh_enrichment",
            "Refresh enrichment anyway": "refresh_enrichment",
            "Build fresh profile": "fresh_rebuild",
        }.get(str(answer)) if answer is not None else None
        if decision == "fresh_rebuild" and not prompts.confirm(
            "Replace the saved profile with a fresh rebuild?",
            default=False,
        ).ask():
            return "reuse"
        return decision

    return choose


# ---------------------------------------------------------------------------
# Manage Library
# ---------------------------------------------------------------------------

def _manage_library_menu(prompts: object, emit: Emitter, t: callable, home_dir: Path) -> None:
    _BACK = t("menu.library.back")
    while True:
        choice = prompts.select(
            t("menu.manage_library.title"),
            choices=[
                t("menu.manage_library.profiles"),
                t("menu.manage_library.heard_releases"),
                t("menu.manage_library.excluded_artists"),
                t("menu.manage_library.clear_all"),
                _BACK,
            ],
        ).ask()
        if choice in {None, _BACK}:
            return
        if choice == t("menu.manage_library.profiles"):
            _profiles_submenu(prompts, emit, t)
        elif choice == t("menu.manage_library.heard_releases"):
            _heard_menu(prompts, emit, t)
        elif choice == t("menu.manage_library.excluded_artists"):
            _excluded_artists_view_manage(prompts, emit, t)
        elif choice == t("menu.manage_library.clear_all"):
            destructive_db = _active_db_path()
            confirm_choice = prompts.select(
                t("menu.manage_library.clear_all_confirm", db_path=destructive_db),
                choices=["No", "Yes"],
                default="No",
            ).ask()
            if confirm_choice in {None, "No"}:
                continue
            with _storage_destructive() as storage:
                profiles_count = storage.clear_profiles()
                heard_count = storage.clear_heard()
                excluded_count = storage.clear_excluded_artists()
            prefs_path = home_dir / "preferences.json"
            prefs_path.unlink(missing_ok=True)
            heard_suffix = "y" if heard_count == 1 else "ies"
            emit(
                t(
                    "status.clear_all_deleted",
                    profiles=profiles_count,
                    heard=heard_count,
                    heard_suffix=heard_suffix,
                    excluded=excluded_count,
                    db_path=destructive_db,
                )
            )


def _profiles_submenu(prompts: object, emit: Emitter, t: callable) -> None:
    _BACK = t("menu.library.back")
    while True:
        choice = prompts.select(
            t("menu.profiles.title"),
            choices=[
                t("menu.profiles.view_manage"),
                t("menu.profiles.rebuild"),
                t("menu.profiles.import_backup"),
                _BACK,
            ],
        ).ask()
        if choice in {None, _BACK}:
            return
        with _storage() as storage:
            if choice == t("menu.profiles.view_manage"):
                _profile_overview_menu(prompts, storage, emit, t)
            elif choice == t("menu.profiles.rebuild"):
                playlist = _rebuild_source_menu(prompts, emit, t)
                if playlist:
                    _refresh_profile(storage, playlist, emit)
            elif choice == t("menu.profiles.import_backup"):
                path_value = _ask_text(prompts, "Source .json path")
                if path_value:
                    _import_profile_backup(storage, Path(path_value).expanduser(), emit)


def _rebuild_source_menu(prompts: object, emit: Emitter, t: callable) -> str | None:
    """Menu for selecting source when rebuilding a profile."""
    source_choice = prompts.select(
        t("menu.discovery.source"),
        choices=[
            t("menu.discovery.spotify_playlist"),
            t("menu.discovery.tidal_playlist"),
            t("menu.discovery.apple_music_playlist"),
            t("menu.discovery.text_file"),
            t("menu.discovery.back"),
        ],
        default=t("menu.discovery.spotify_playlist"),
    ).ask()
    if source_choice in {None, t("menu.discovery.back")}:
        return None

    playlist: str | None = None
    if source_choice == t("menu.discovery.spotify_playlist"):
        # Sub-menu for Spotify playlist source
        spotify_action = prompts.select(
            t("menu.discovery.spotify_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_spotify_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if spotify_action in {None, t("menu.discovery.back")}:
            return None
        if spotify_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            spotify = SpotifyProvider(settings)
            try:
                playlists = spotify.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks} {track_label(p.tracks)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        for p in playlists:
                            if f"{p.name} ({p.tracks} {track_label(p.tracks)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return None
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Spotify playlist URL or ID")
            except (ProviderRateLimit, ProviderUnavailable):
                playlist = _ask_text(prompts, "Spotify playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Spotify playlist URL or ID")
        if not playlist:
            return None
    elif source_choice == t("menu.discovery.tidal_playlist"):
        tidal_action = prompts.select(
            t("menu.discovery.tidal_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_tidal_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if tidal_action in {None, t("menu.discovery.back")}:
            return None
        if tidal_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            tidal = TidalProvider(settings)
            try:
                playlists = tidal.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        for p in playlists:
                            if f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return None
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Tidal playlist URL or ID")
            except (ProviderRateLimit, ProviderUnavailable):
                playlist = _ask_text(prompts, "Tidal playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Tidal playlist URL or ID")
        if not playlist:
            return None
    elif source_choice == t("menu.discovery.apple_music_playlist"):
        apple_action = prompts.select(
            t("menu.discovery.apple_music_action"),
            choices=[
                t("menu.discovery.choose_from_profile"),
                t("menu.discovery.new_apple_music_url"),
            ],
            default=t("menu.discovery.choose_from_profile"),
        ).ask()
        if apple_action in {None, t("menu.discovery.back")}:
            return None
        if apple_action == t("menu.discovery.choose_from_profile"):
            settings = load_settings()
            apple_music = AppleMusicProvider(settings)
            try:
                playlists = apple_music.fetch_user_playlists()
                if playlists:
                    track_label = lambda n: t("spotify.tracks") if n != 1 else t("spotify.track")
                    choices = [f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" for p in playlists]
                    answer = prompts.select(
                        t("menu.discovery.choose_playlist"),
                        choices=choices,
                    ).ask()
                    if answer:
                        for p in playlists:
                            if f"{p.name} ({p.tracks if p.tracks is not None else '?'} {track_label(p.tracks or 0)})" == answer:
                                playlist = p.id
                                break
                    else:
                        return None
                else:
                    emit(t("error.no_playlists_found"))
                    playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
            except (ProviderRateLimit, ProviderUnavailable):
                playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
        else:
            playlist = _ask_text(prompts, "Apple Music playlist URL or ID")
        if not playlist:
            return None
    else:
        playlist = _ask_text(prompts, "Text file path (.txt or .csv)")
        if not playlist:
            return None

    return playlist


def _profile_overview_menu(prompts: object, storage: Storage, emit: Emitter, t: callable) -> None:
    default = None
    while True:
        profiles = storage.list_taste_profiles()
        if not profiles:
            emit(t("error.no_saved_profiles"))
            return
        choices = [_profile_choice_label(item) for item in profiles] + [t("menu.library.back")]
        if default not in choices:
            default = choices[0]
        answer = prompts.select("Saved profile details", choices=choices, default=default).ask()
        if answer in {None, t("menu.library.back")}:
            return
        default = answer
        profile_id = _profile_id_from_choice(str(answer))
        if profile_id is None:
            continue
        _profile_detail_actions(prompts, storage, profile_id, emit, t)


def _profile_detail_actions(prompts: object, storage: Storage, profile_ref: str | int, emit: Emitter, t: callable) -> None:
    _emit_profile_show(storage, profile_ref, emit)
    default = t("menu.profile_detail.run_enrichment")
    while True:
        action = prompts.select(
            "Profile actions",
            choices=[
                t("menu.profile_detail.run_enrichment"),
                t("menu.profile_detail.expansion_memories"),
                t("menu.profile_detail.export_backup"),
                t("menu.profile_detail.delete_profile"),
                t("menu.library.back"),
            ],
            default=default,
        ).ask()
        if action in {None, t("menu.library.back")}:
            return
        default = action
        if action == t("menu.profile_detail.run_enrichment"):
            confirm_message = (
                f"{t('menu.profile_detail.enrichment_warning')}\n"
                f"{t('menu.profile_detail.enrichment_warning_confirm')}"
            )
            if not prompts.confirm(confirm_message, default=False).ask():
                continue
            profile_record = storage.get_taste_profile(profile_ref)
            if profile_record:
                _try_improve_profile_metadata(storage, profile_record, emit, t)
        elif action == t("menu.profile_detail.expansion_memories"):
            _profile_expansion_memories_menu(prompts, storage, profile_ref, emit, t)
        elif action == t("menu.profile_detail.export_backup"):
            path_value = _ask_text(prompts, "Destination .json path")
            if path_value:
                _export_profile_backup(storage, profile_ref, Path(path_value).expanduser(), emit)
        elif action == t("menu.profile_detail.delete_profile"):
            destructive_db = _active_db_path()
            if not prompts.confirm("Are you sure you want to permanently delete this saved profile?", default=False).ask():
                continue
            with _storage_destructive() as destructive_storage:
                deleted = destructive_storage.delete_taste_profile(profile_ref)
            emit(f"Deleted profile {profile_ref} from {destructive_db}." if deleted else f"No saved profile found for {profile_ref!r}.")
            return


def _profile_expansion_memories_menu(
    prompts: object,
    storage: Storage,
    profile_ref: str | int,
    emit: Emitter,
    t: callable,
) -> None:
    default_key = "view_all"
    while True:
        is_enabled = storage.profile_use_expansion_memories(profile_ref)
        status_label = t("menu.cache.active") if is_enabled else t("menu.cache.inactive")
        toggle_label = f"{t('menu.profile_memories.always_use')} [{status_label}]"
        choices = [
            t("menu.profile_memories.view_all"),
            toggle_label,
            t("menu.profile_memories.clear_all"),
            t("menu.library.back"),
        ]
        default_map = {
            "view_all": t("menu.profile_memories.view_all"),
            "toggle": toggle_label,
            "clear_all": t("menu.profile_memories.clear_all"),
            "back": t("menu.library.back"),
        }
        default = default_map.get(default_key, t("menu.profile_memories.view_all"))
        if default not in choices:
            default = t("menu.profile_memories.view_all")
        choice = prompts.select(
            t("menu.profile_detail.expansion_memories"),
            choices=choices,
            default=default,
        ).ask()
        if choice in {None, t("menu.library.back")}:
            return
        if choice == t("menu.profile_memories.view_all"):
            default_key = "view_all"
            _profile_expansion_memories_view_all(prompts, storage, profile_ref, emit, t)
        elif choice == toggle_label:
            default_key = "toggle"
            storage.set_profile_use_expansion_memories(profile_ref, not is_enabled)
            new_status = t("menu.cache.active") if (not is_enabled) else t("menu.cache.inactive")
            emit(t("status.profile_memories_toggle", status=new_status))
        elif choice == t("menu.profile_memories.clear_all"):
            default_key = "clear_all"
            if not prompts.confirm(t("prompt.profile_memories.clear_confirm"), default=False).ask():
                continue
            removed = storage.clear_profile_expansion_memories(profile_ref)
            emit(t("status.profile_memories_cleared", count=removed))


def _profile_expansion_memories_view_all(
    prompts: object,
    storage: Storage,
    profile_ref: str | int,
    emit: Emitter,
    t: callable,
) -> None:
    while True:
        memories = storage.list_profile_expansion_memories(profile_ref)
        if not memories:
            emit(t("status.profile_memories_empty"))
            return
        choices = []
        for row in memories:
            provider = str(row.get("provider") or "?")
            tier = str(row.get("tier") or "?")
            confidence = row.get("confidence")
            conf_txt = "?" if confidence is None else f"{float(confidence):.1f}"
            choices.append(f"#{row['id']} {row['artist_name']} [{provider}; {tier}; {conf_txt}]")
        choices.append(t("menu.library.back"))
        selected = prompts.select(
            t("menu.profile_memories.view_all"),
            choices=choices,
            default=choices[0],
        ).ask()
        if selected in {None, t("menu.library.back")}:
            return
        memory_id = _profile_memory_id_from_choice(str(selected))
        if memory_id is None:
            continue
        if not prompts.confirm(t("prompt.profile_memories.remove_one_confirm"), default=False).ask():
            continue
        deleted = storage.delete_profile_expansion_memory(memory_id)
        if deleted:
            emit(t("status.profile_memory_removed", id=memory_id))


def _profile_memory_id_from_choice(choice: str) -> int | None:
    # Format: "#123 Artist Name [provider; tier; confidence]"
    if not choice.startswith("#"):
        return None
    token = choice.split(" ", 1)[0][1:]
    try:
        return int(token)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Heard Releases
# ---------------------------------------------------------------------------

def _heard_menu(prompts: object, emit: Emitter, t: callable) -> None:
    _BACK = t("menu.library.back")
    default = t("menu.heard.view_manage")
    while True:
        choice = prompts.select(
            t("menu.heard.title"),
            choices=[
                t("menu.heard.view_manage"),
                t("menu.heard.export"),
                t("menu.heard.import"),
                _BACK,
            ],
            default=default,
        ).ask()
        if choice in {None, _BACK}:
            return
        default = choice
        if choice == t("menu.heard.view_manage"):
            _heard_view_manage(prompts, emit, t)
        elif choice == t("menu.heard.export"):
            path_value = _ask_text(prompts, "Destination .json path")
            if path_value:
                with _storage() as storage:
                    path = Path(path_value).expanduser()
                    storage.export_heard_json(path)
                emit(f"Exported heard list to {path}")
        elif choice == t("menu.heard.import"):
            path_value = _ask_text(prompts, "Source .json or .csv path")
            if path_value:
                path = Path(path_value).expanduser()
                try:
                    with _storage() as storage:
                        count = storage.import_heard_file(path)
                except Exception as exc:
                    emit(f"Could not import heard list: {_safe_error(exc)}")
                else:
                    emit(f"Imported {count} heard-list entr{'y' if count == 1 else 'ies'}.")


def _parse_timestamp_from_session_id(session_id: str | None) -> str:
    """Extract timestamp from session_id format: name_DDMMYYYY_HHMM."""
    if not session_id:
        return ""
    parts = session_id.rsplit("_", 2)
    if len(parts) != 3:
        return ""
    date_part, time_part = parts[1], parts[2]
    # Convert DDMMYYYY + HHMM to unified display format: HH:MM  |  DD-MM-YYYY
    try:
        day, month, year = date_part[:2], date_part[2:4], date_part[4:8]
        hour, minute = time_part[:2], time_part[2:4]
        return f"{hour}:{minute}  |  {day}-{month}-{year}"
    except (IndexError, ValueError):
        return ""


def _heard_view_manage(prompts: object, emit: Emitter, t: callable) -> None:
    _ADD = t("menu.heard.add")
    _SEARCH = t("menu.heard.search")
    _REMOVE_ALL = t("menu.heard.remove_all")
    _REMOVE_FILTERED = t("menu.heard.remove_filtered")
    _BACK = t("menu.library.back")
    _INPUT_RELEASES = t("menu.heard.input_releases")
    _OUTPUT_RELEASES = t("menu.heard.output_releases")
    _INPUT_RELEASES_COLLAPSE = t("menu.heard.input_releases_collapse")
    _OUTPUT_RELEASES_COLLAPSE = t("menu.heard.output_releases_collapse")
    _EXPAND_COLLAPSE = t("menu.heard.expand_collapse")
    _REMOVE_ALL_ABOVE = t("menu.heard.remove_all_above")
    _REMOVE_ALL_INPUT = t("menu.heard.remove_all_input")
    _REMOVE_ALL_OUTPUT = t("menu.heard.remove_all_output")
    showed_empty_notice = False
    search_query = ""
    expanded: set[str] = set()  # Track which (session_id, category) pairs are expanded
    default_choice: str | None = None
    pending_expand_key: tuple | None = None  # expand_key just toggled; resolved to label after rebuild

    while True:
        with _storage() as storage:
            grouped = storage.list_heard_grouped()

        flat_entries = [e for g in grouped for e in g.get("input_releases", []) + g.get("output_releases", [])]
        if not flat_entries and not showed_empty_notice:
            emit("Heard releases list is empty. Nothing to show here.")
            showed_empty_notice = True
        elif flat_entries:
            showed_empty_notice = False

        # Build filtered grouped list
        is_filtered = False
        if search_query.strip():
            query = search_query.casefold()
            filtered_grouped = []
            for session_group in grouped:
                input_filtered = [
                    e for e in session_group.get("input_releases", [])
                    if query in _heard_release_text(e).casefold()
                ]
                output_filtered = [
                    e for e in session_group.get("output_releases", [])
                    if query in _heard_release_text(e).casefold()
                ]
                if input_filtered or output_filtered:
                    filtered_group = dict(session_group)
                    filtered_group["input_releases"] = input_filtered
                    filtered_group["output_releases"] = output_filtered
                    filtered_grouped.append(filtered_group)
            visible_grouped = filtered_grouped
            is_filtered = True
            # Recalculate flat_entries for filtered view
            flat_entries = [e for g in visible_grouped for e in g.get("input_releases", []) + g.get("output_releases", [])]
        else:
            visible_grouped = grouped

        # Build choice list
        choice_map = {}
        choices = []
        expanded_visible_entries = []

        if is_filtered:
            # For filtered view, skip headers and show entries directly
            for session_group in visible_grouped:
                session_id = session_group.get("session_id")
                profile_name = session_group.get("profile_name", "Unknown")
                timestamp = _parse_timestamp_from_session_id(session_id)
                
                input_releases = session_group.get("input_releases", [])
                output_releases = session_group.get("output_releases", [])
                
                for entry in input_releases:
                    choice_label = _heard_choice_label_with_session(entry, "input", profile_name, timestamp)
                    choices.append(choice_label)
                    choice_map[choice_label] = ("entry", session_id, "input", entry["id"])
                
                for entry in output_releases:
                    choice_label = _heard_choice_label_with_session(entry, "output", profile_name, timestamp)
                    choices.append(choice_label)
                    choice_map[choice_label] = ("entry", session_id, "output", entry["id"])
        else:
            # Build choice list with collapsed categories by default
            separator_cls = getattr(getattr(prompts, "prompts", None), "Separator", None)
            for idx, session_group in enumerate(visible_grouped):
                if idx > 0:
                    if separator_cls is not None:
                        choices.append(separator_cls(""))
                    else:
                        spacer = " "
                        choices.append(spacer)
                        choice_map[spacer] = ("noop",)
                session_id = session_group.get("session_id")
                profile_name = session_group.get("profile_name", "Unknown")
                timestamp = _parse_timestamp_from_session_id(session_id)
                profile_col = f"  {profile_name:<50}"
                header = f"{profile_col}{timestamp}" if timestamp else f"  {profile_name}"
                choices.append(header)

                input_releases = session_group.get("input_releases", [])
                output_releases = session_group.get("output_releases", [])

                if input_releases:
                    input_count = len(input_releases)
                    expand_key = (session_id, "input")
                    if expand_key in expanded:
                        input_header = f"{f'    [{_INPUT_RELEASES}: {input_count}]':<52}{_INPUT_RELEASES_COLLAPSE}"
                        choices.append(input_header)
                        choice_map[input_header] = ("toggle_expand", expand_key)
                        for entry in input_releases:
                            choice_label = _heard_choice_label_with_session(entry, "input", profile_name, timestamp)
                            choices.append(choice_label)
                            choice_map[choice_label] = ("entry", session_id, "input", entry["id"])
                            expanded_visible_entries.append(entry)
                    else:
                        input_header = f"    [{_INPUT_RELEASES}: {input_count}]"
                        choices.append(input_header)
                        choice_map[input_header] = ("expand_directly", expand_key)

                if output_releases:
                    output_count = len(output_releases)
                    expand_key = (session_id, "output")
                    if expand_key in expanded:
                        output_header = f"{f'    [{_OUTPUT_RELEASES}: {output_count}]':<52}{_OUTPUT_RELEASES_COLLAPSE}"
                        choices.append(output_header)
                        choice_map[output_header] = ("toggle_expand", expand_key)
                        for entry in output_releases:
                            choice_label = _heard_choice_label_with_session(entry, "output", profile_name, timestamp)
                            choices.append(choice_label)
                            choice_map[choice_label] = ("entry", session_id, "output", entry["id"])
                            expanded_visible_entries.append(entry)
                    else:
                        output_header = f"    [{_OUTPUT_RELEASES}: {output_count}]"
                        choices.append(output_header)
                        choice_map[output_header] = ("expand_directly", expand_key)

        search_choice = f"{_SEARCH}: {search_query}" if search_query else _SEARCH
        if is_filtered:
            # Count total filtered entries (use already-calculated flat_entries)
            filtered_count = len(flat_entries)
            choices.extend([_ADD, search_choice, f"Remove {filtered_count} filtered entries", _BACK])
        elif expanded_visible_entries:
            remove_all_above_label = f"{_REMOVE_ALL_ABOVE} ({len(expanded_visible_entries)})"
            choices.extend([_ADD, search_choice, remove_all_above_label, _BACK])
        else:
            choices.extend([_ADD, search_choice, _REMOVE_ALL, _BACK])

        if pending_expand_key is not None:
            for label, action in choice_map.items():
                if action[0] in ("toggle_expand", "expand_directly") and action[1] == pending_expand_key:
                    default_choice = label
                    break
            pending_expand_key = None
        if default_choice not in choices:
            default_choice = choices[0] if choices else _BACK

        choice = prompts.select(
            f"{t('menu.heard.view_manage')}\n",
            choices=choices,
            default=default_choice,
        ).ask()

        if choice in {None, _BACK}:
            return
        default_choice = choice
        if choice == _ADD:
            artist = _ask_text(prompts, "Artist name")
            if not artist:
                continue
            release = _ask_text(prompts, "Release title")
            if not release:
                continue
            release_date = _ask_text(prompts, "Release date (optional)", default="") or None
            with _storage() as storage:
                entry_id = storage.add_heard(artist=artist, title=release, release_date=release_date)
            emit(f"Marked heard #{entry_id}: {artist} - {release}")
        elif choice == search_choice:
            search_query = _ask_text(prompts, "Search entries (blank to clear)", default=search_query) or ""
        elif choice == _REMOVE_ALL:
            if not flat_entries:
                emit("Heard list is empty.")
                continue
            if not prompts.confirm(
                f"Are you sure you want to permanently delete all {len(flat_entries)} heard-list entries?",
                default=False,
            ).ask():
                continue
            with _storage_destructive() as storage:
                count = storage.clear_heard()
            emit(f"Removed {count} heard-list entr{'y' if count == 1 else 'ies'} from {_active_db_path()}.")
        elif expanded_visible_entries and choice == remove_all_above_label:
            n = len(expanded_visible_entries)
            if not prompts.confirm(
                f"Are you sure you want to permanently delete {n} expanded entr{'y' if n == 1 else 'ies'}?",
                default=False,
            ).ask():
                continue
            with _storage_destructive() as storage:
                for entry in expanded_visible_entries:
                    storage.remove_heard(entry["id"])
            expanded.clear()
            emit(f"Removed {n} heard-list entr{'y' if n == 1 else 'ies'} from {_active_db_path()}.")
        elif choice.startswith("Remove") and "filtered" in choice:
            # Remove filtered entries
            if not prompts.confirm(
                f"Are you sure you want to permanently delete all {len(flat_entries)} filtered entries?",
                default=False,
            ).ask():
                continue
            # Get all entry IDs from visible_grouped
            entry_ids = []
            for session_group in visible_grouped:
                for entry in session_group.get("input_releases", []):
                    entry_ids.append(entry["id"])
                for entry in session_group.get("output_releases", []):
                    entry_ids.append(entry["id"])
            with _storage_destructive() as storage:
                for entry_id in entry_ids:
                    storage.remove_heard(entry_id)
            emit(f"Removed {len(entry_ids)} filtered entries from {_active_db_path()}.")
        elif choice in choice_map:
            action = choice_map[choice]
            if action[0] == "expand_directly":
                _, expand_key = action
                expanded.add(expand_key)
                pending_expand_key = expand_key
            elif action[0] == "toggle_expand":
                _, expand_key = action
                expanded.discard(expand_key)
                pending_expand_key = expand_key
            elif action[0] == "entry":
                _, session_id, category, entry_id = action
                sub_action = prompts.select(
                    choice,
                    choices=["Delete entry", _BACK],
                    default=_BACK,
                ).ask()
                if sub_action == "Delete entry":
                    if not prompts.confirm(
                        "Are you sure you want to permanently delete this entry?",
                        default=False,
                    ).ask():
                        continue
                    with _storage_destructive() as storage:
                        removed = storage.remove_heard(entry_id)
                    if removed:
                        emit(f"Removed heard-list entry #{entry_id} from {_active_db_path()}.")
                    else:
                        emit(f"No heard-list entry found with id {entry_id}.")
            elif action[0] == "noop":
                continue


def _excluded_artists_view_manage(prompts: object, emit: Emitter, t: callable) -> None:
    _ADD = t("menu.excluded_artists.add")
    _SEARCH = t("menu.excluded_artists.search")
    _REMOVE_FILTERED = t("menu.excluded_artists.remove_filtered")
    _REMOVE_ALL = t("menu.excluded_artists.remove_all")
    _BACK = t("menu.library.back")
    showed_empty_notice = False
    search_query = ""
    default_choice: str | None = None
    while True:
        with _storage() as storage:
            entries = storage.list_excluded_artists()
        if not entries and not showed_empty_notice:
            emit("Excluded artists list is empty. Nothing to show here.")
            showed_empty_notice = True
        elif entries:
            showed_empty_notice = False
        if search_query.strip():
            query = search_query.casefold()
            visible_entries = [
                entry for entry in entries
                if query in entry["display_name"].casefold() or query in entry["normalized_name"].casefold()
            ]
        else:
            visible_entries = entries
        search_choice = f"{_SEARCH}: {search_query}" if search_query else _SEARCH
        choices = [f"#{entry['id']}  {entry['display_name']}" for entry in visible_entries] + [_ADD, search_choice]
        if search_query.strip():
            choices.append(_REMOVE_FILTERED)
        else:
            choices.append(_REMOVE_ALL)
        choices.append(_BACK)
        if default_choice not in choices:
            default_choice = choices[0] if choices else _BACK
        choice = prompts.select(
            t("menu.excluded_artists.view_manage"),
            choices=choices,
            default=default_choice,
        ).ask()
        if choice in {None, _BACK}:
            return
        default_choice = choice
        if choice == _ADD:
            artist_name = _ask_text(prompts, "Artist name")
            if not artist_name:
                continue
            with _storage() as storage:
                entry_id = storage.add_excluded_artist(artist=artist_name)
            emit(f"Added exclusion #{entry_id}: {artist_name}")
        elif choice == search_choice:
            search_query = _ask_text(prompts, "Search entries (blank to clear)", default=search_query) or ""
        elif choice == _REMOVE_FILTERED:
            if not search_query.strip():
                continue
            if not visible_entries:
                emit(f"No entries match search: {search_query}")
                continue
            if not prompts.confirm(
                f"Are you sure you want to permanently delete {len(visible_entries)} filtered entr{'y' if len(visible_entries) == 1 else 'ies'} for search '{search_query}'?",
                default=False,
            ).ask():
                continue
            removed_count = 0
            with _storage_destructive() as storage:
                for entry in visible_entries:
                    entry_id = int(entry.get("id", 0))
                    if entry_id and storage.remove_excluded_artist(entry_id):
                        removed_count += 1
            emit(
                f"Removed {removed_count} filtered entr{'y' if removed_count == 1 else 'ies'} "
                f"from {_active_db_path()}."
            )
        elif choice == _REMOVE_ALL:
            if not entries:
                emit("Excluded artists list is empty.")
                continue
            if not prompts.confirm(
                f"Are you sure you want to permanently delete all {len(entries)} excluded artist(s)?",
                default=False,
            ).ask():
                continue
            with _storage_destructive() as storage:
                count = storage.clear_excluded_artists()
            emit(f"Removed {count} excluded artist(s) from {_active_db_path()}.")
        else:
            entry_id = _entry_id_from_choice(str(choice))
            if entry_id is None:
                continue
            action = prompts.select(
                choice,
                choices=["Delete entry", _BACK],
                default=_BACK,
            ).ask()
            if action == "Delete entry":
                if not prompts.confirm(
                    "Are you sure you want to permanently delete this entry?",
                    default=False,
                ).ask():
                    continue
                with _storage_destructive() as storage:
                    removed = storage.remove_excluded_artist(entry_id)
                if removed:
                    emit(f"Removed excluded artist #{entry_id} from {_active_db_path()}.")
                else:
                    emit(f"No excluded artist entry found with id {entry_id}.")


# ---------------------------------------------------------------------------
# System Settings
# ---------------------------------------------------------------------------

def _initial_configuration_guard(
    prompts: object, emit: Emitter, console: "Console", t: callable, home_dir: Path
) -> bool:
    settings = load_settings()
    if any([
        settings.spotify_configured,
        settings.tidal_configured,
        settings.lastfm_configured,
        settings.mb_contact_configured,
    ]):
        return False

    console.print()
    console.print(f"[bold {GUIDED_ACCENT}]{t('setup.guard.title')}[/bold {GUIDED_ACCENT}]")
    console.print()
    console.print(t("setup.guard.body"))
    console.print()

    action = prompts.select(
        "",
        choices=[t("setup.guard.action_settings"), t("setup.guard.action_continue")],
    ).ask()

    if action is None or action != t("setup.guard.action_settings"):
        return False

    return _system_settings_menu(prompts, emit, t, home_dir)


def _system_settings_menu(prompts: object, emit: Emitter, t: callable, home_dir: Path) -> bool:
    _BACK = t("menu.library.back")
    while True:
        choice = prompts.select(
            t("menu.system.title"),
            choices=[
                t("menu.system.manage_cache"),
                t("menu.system.language"),
                _BACK,
            ],
        ).ask()
        if choice in {None, _BACK}:
            return False
        if choice == t("menu.system.manage_cache"):
            _provider_cache_menu(prompts, emit, t)
        elif choice == t("menu.system.language"):
            if _language_menu(prompts, emit, t, home_dir):
                return True


def _provider_cache_menu(prompts: object, emit: Emitter, t: callable) -> None:
    _BACK = t("menu.library.back")
    while True:
        settings = load_settings()
        if settings.mb_contact_is_placeholder:
            emit(
                "Warning: MB_CONTACT_EMAIL is still a placeholder; set it to your email for polite MusicBrainz usage."
            )
        provider_choices = []
        for name, config_attr, _, _ in _PROVIDERS:
            active = getattr(settings, config_attr)
            status = t("menu.cache.active") if active else t("menu.cache.inactive")
            indicator = "●" if active else "○"
            provider_choices.append(_provider_status_label(name, indicator, status))
        choice = prompts.select(
            t("menu.cache.title"),
            choices=[*provider_choices, t("menu.cache.clear_all"), _BACK],
        ).ask()
        if choice in {None, _BACK}:
            return
        if choice == t("menu.cache.clear_all"):
            destructive_db = _active_db_path()
            if not prompts.confirm(
                f"Are you sure you want to permanently delete all cached provider responses from {destructive_db}?",
                default=False,
            ).ask():
                continue
            with _storage_destructive() as storage:
                count = storage.clear_cache()
            emit(
                f"Cleared {count} cached API response(s) from {destructive_db}. "
                "Saved profiles, heard releases, and durable enrichment were not deleted."
            )
            continue
        for name, config_attr, provider_key, cred_list in _PROVIDERS:
            active = getattr(settings, config_attr)
            status = t("menu.cache.active") if active else t("menu.cache.inactive")
            indicator = "●" if active else "○"
            label = _provider_status_label(name, indicator, status)
            if choice == label:
                _provider_detail_menu(prompts, emit, t, name, provider_key, cred_list)
                break


def _provider_status_menu(prompts: object, emit: Emitter, t: callable) -> None:
    _BACK = t("menu.library.back")
    default_choice = None
    while True:
        settings = load_settings()
        choices = []
        for name, config_attr, provider_key, _ in _PROVIDERS:
            active = getattr(settings, config_attr)
            status = t("menu.cache.active") if active else t("menu.cache.inactive")
            indicator = "●" if active else "○"
            choices.append(_provider_status_label(name, indicator, status))
        choices.append(_BACK)
        if default_choice not in choices:
            default_choice = choices[0] if choices else _BACK
        choice = prompts.select(
            t("menu.cache.status_title"),
            choices=choices,
            default=default_choice,
        ).ask()
        if choice in {None, _BACK}:
            return
        default_choice = choice
        for name, config_attr, provider_key, cred_list in _PROVIDERS:
            active = getattr(settings, config_attr)
            status = t("menu.cache.active") if active else t("menu.cache.inactive")
            indicator = "●" if active else "○"
            label = _provider_status_label(name, indicator, status)
            if choice == label:
                _provider_detail_menu(prompts, emit, t, name, provider_key, cred_list)
                break


def _provider_detail_menu(
    prompts: object,
    emit: Emitter,
    t: callable,
    name: str,
    provider_key: str,
    cred_list: list[tuple[str, str]],
) -> None:
    _BACK = t("menu.library.back")
    settings = load_settings()
    env_path = canonical_env_path()
    fallback_env_path = Path(settings.data_dir) / ".env"
    while True:
        choices = []
        for env_key, label_key in cred_list:
            current_value = os.getenv(env_key, "")
            label = t(label_key) if label_key.startswith("menu.cache.") else label_key
            choices.append(f"{label}")
        choices.extend([t("menu.cache.delete_cache"), _BACK])
        choice = prompts.select(
            name,
            choices=choices,
            default=choices[0],
        ).ask()
        if choice in {None, _BACK}:
            return
        if choice == t("menu.cache.delete_cache"):
            destructive_db = _active_db_path()
            if not prompts.confirm(
                f"Delete all cached responses for {name}?",
                default=False,
            ).ask():
                continue
            with _storage_destructive() as storage:
                count = storage.clear_provider_cache(provider_key)
            emit(f"Cleared {count} cached {name} response(s) from {destructive_db}.")
            continue
        # Find which credential was selected
        for env_key, label_key in cred_list:
            label = t(label_key) if label_key.startswith("menu.cache.") else label_key
            full_label = f"{label}"
            if choice == full_label:
                current = os.getenv(env_key, "")
                prompt_label = f"{env_key} (leave blank to keep current)" if current else env_key
                value = _ask_text(prompts, prompt_label, default="")
                if value is None:
                    break
                if value == "" and current:
                    emit(f"Kept existing {env_key}.")
                    break
                try:
                    save_env_credential(env_path, env_key, value)
                    emit(f"Saved {env_key}. Path: {env_path}")
                    time.sleep(_M_SETTLE)
                except Exception:
                    save_env_credential(fallback_env_path, env_key, value)
                    emit(f"Saved {env_key}. Path: {fallback_env_path} (fallback)")
                    time.sleep(_M_SETTLE)
                break


def _language_menu(prompts: object, emit: Emitter, t: callable, home_dir: Path) -> bool:
    choices = [t("prompt.language_selection.english"), t("prompt.language_selection.polish")]
    default = t("prompt.language_selection.english") if get_saved_language_preference(home_dir) != "pl" else t("prompt.language_selection.polish")
    lang_choice = prompts.select(
        t("prompt.language_selection.title"),
        choices=choices,
        default=default,
    ).ask()
    if lang_choice is None:
        return False
    if lang_choice == t("prompt.language_selection.polish"):
        language = "pl"
    else:
        language = "en"
    save_language_preference(home_dir, language)
    emit(f"Language changed to {lang_choice}.")
    return True


# ---------------------------------------------------------------------------
# Profile helpers
# ---------------------------------------------------------------------------

def _emit_profile_list(storage: Storage, emit: Emitter) -> list[dict]:
    profiles = storage.list_taste_profiles()
    if not profiles:
        emit("No saved taste profiles yet.")
        return []
    for item in profiles:
        emit(profile_summary_line(storage, item))
    return profiles


def _emit_profile_show(storage: Storage, profile_ref: str | int | None, emit: Emitter) -> None:
    if profile_ref in (None, ""):
        return
    profile_record = storage.get_taste_profile(profile_ref)
    if not profile_record:
        emit(f"No saved profile found for {profile_ref!r}.")
        return
    profile = TasteProfile.model_validate_json(profile_record["profile_json"])
    seed_tracks = seed_tracks_from_payload(json.loads(profile_record["seed_tracks_json"]))
    emit("")
    emit(f"Profile #{profile_record['id']}: {profile_record['name']}")
    emit("")
    source_name = str(profile_record["source_type"]).replace("_", " ").title()
    emit(_format_profile_two_col("Source:", source_name, f"ID: {profile_record['source_ref']}"))
    emit(_format_profile_two_col("# of artists and tracks:", str(profile_record["artist_count"]), str(profile_record["track_count"])))
    completeness = storage.enrichment_completeness(artists=profile.artists, tracks=seed_tracks)
    artist_part = f"{completeness.artist_enriched}/{completeness.artist_total}"
    track_part = f"{completeness.track_enriched}/{completeness.track_total}"
    emit(_format_profile_two_col("Enrichment:", artist_part, track_part))
    updated_time, updated_date = _format_profile_updated_at_parts(profile_record["updated_at"])
    emit(_format_profile_two_col("Last updated:", updated_time, updated_date))
    emit("")
    emit("Top artists:")
    for artist in profile.top_artists[:10]:
        emit(f"  - {artist.name} ({artist.playlist_count} tracks, score {artist.affinity_score:g})")


def _format_profile_updated_at_parts(value: str | None) -> tuple[str, str]:
    if not value:
        return ("unknown", "unknown")
    try:
        parsed = dt.datetime.fromisoformat(str(value))
    except ValueError:
        return (str(value), "")
    return (parsed.strftime("%H:%M"), parsed.strftime("%d-%m-%Y"))


def _format_profile_two_col(label: str, left_value: str, right_value: str) -> str:
    return f"{label:<29}{left_value:>10}     |        {right_value}"


def _export_profile_backup(storage: Storage, profile_ref: str | int, path: Path, emit: Emitter) -> None:
    profile_record = storage.get_taste_profile(profile_ref)
    if not profile_record:
        emit(f"No saved profile found for {profile_ref!r}.")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": "mamonia.saved_profile_backup.v1",
        "profile": {
            "name": profile_record["name"],
            "source_type": profile_record["source_type"],
            "source_ref": profile_record["source_ref"],
            "source_key": profile_record["source_key"],
            "source_hash": profile_record["source_hash"],
            "track_count": profile_record["track_count"],
            "artist_count": profile_record["artist_count"],
            "profile": json.loads(profile_record["profile_json"]),
            "seed_tracks": json.loads(profile_record["seed_tracks_json"]),
            "seed_track_keys": json.loads(profile_record["seed_track_keys_json"]),
            "created_at": profile_record.get("created_at"),
            "updated_at": profile_record.get("updated_at"),
            "last_used_at": profile_record.get("last_used_at"),
        },
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    emit(f"Exported saved profile backup #{profile_record['id']} to {path}")


def _import_profile_backup(storage: Storage, path: Path, emit: Emitter) -> None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        data = payload["profile"] if payload.get("format") == "mamonia.saved_profile_backup.v1" else None
        if not isinstance(data, dict):
            raise ValueError("not a Mamonia saved profile backup")
        profile = TasteProfile.model_validate(data["profile"])
        seed_tracks = seed_tracks_from_payload(data["seed_tracks"])
        seed_track_keys = {str(item) for item in data["seed_track_keys"] if item}
        required = ("name", "source_type", "source_ref", "source_key", "source_hash")
        if any(not data.get(key) for key in required):
            raise ValueError("backup is missing source metadata")
    except Exception as exc:
        emit(f"Could not import saved profile backup: {_safe_error(exc)}")
        return

    profile_record = storage.upsert_taste_profile(
        name=str(data["name"]),
        source_type=str(data["source_type"]),
        source_ref=str(data["source_ref"]),
        source_key=str(data["source_key"]),
        source_hash=str(data["source_hash"]),
        track_count=int(data.get("track_count") or len(seed_tracks)),
        artist_count=int(data.get("artist_count") or profile.n_artists),
        profile=profile,
        seed_tracks=seed_tracks,
        seed_track_keys=seed_track_keys,
    )
    emit(f"Imported saved profile backup #{profile_record['id']}: {profile_record['name']}")


def _refresh_profile(storage: Storage, playlist: str, emit: Emitter) -> None:
    settings = load_settings()
    busy = choose_busy_status_reporter(is_tty=sys.stdout.isatty())

    with busy.phase("Loading playlist"):
        spotify = SpotifyProvider(settings, storage)
        tidal = TidalProvider(settings)
        try:
            tracks = _load_playlist_tracks(playlist, spotify, tidal, AppleMusicProvider(settings))
        except WorkflowAbort as exc:
            emit(f"Error: {exc.message}")
            return

    if not tracks:
        emit("No input tracks found.")
        return

    source = source_identity_from_tracks(playlist, tracks)
    source = enrich_source_name(source, playlist, spotify, tidal, AppleMusicProvider(settings))

    with busy.phase("Building taste profile"):
        musicbrainz = MusicBrainzProvider(settings, storage)
        lastfm = LastFMProvider(settings, storage)
        listenbrainz = ListenBrainzProvider(settings, storage)
        deezer = DeezerProvider(settings, storage)
        profile = build_taste_profile(
            tracks,
            spotify=spotify if spotify.available else None,
            musicbrainz=musicbrainz,
            lastfm=lastfm,
            listenbrainz=listenbrainz if listenbrainz.available else None,
            deezer=deezer,
            spotify_artist_metadata=spotify.artist_metadata_from_tracks(tracks) if spotify.available else {},
        )

    with busy.phase("Saving profile"):
        profile_record = storage.upsert_taste_profile(
            name=source["name"],
            source_type=source["source_type"],
            source_ref=source["source_ref"],
            source_key=source["source_key"],
            source_hash=source["source_hash"],
            track_count=len(tracks),
            artist_count=profile.n_artists,
            profile=profile,
            seed_tracks=tracks,
            seed_track_keys=track_keys_from_input(tracks),
        )

    with busy.phase("Enriching with provider data"):
        _store_input_track_enrichment(storage, tracks, spotify=spotify)
        _save_latest_profile(settings.data_dir / "last_profile.json", profile.model_dump(mode="json"))

    emit(
        f"Refreshed profile #{profile_record['id']} {profile_record['name']} "
        f"with {profile_record['track_count']} tracks and {profile_record['artist_count']} artists."
    )


def _try_improve_profile_metadata(storage: Storage, profile_record: dict, emit: Emitter, t: callable) -> None:
    settings = load_settings()
    spotify = SpotifyProvider(settings, storage)
    musicbrainz = MusicBrainzProvider(settings, storage)
    lastfm = LastFMProvider(settings, storage)
    listenbrainz = ListenBrainzProvider(settings, storage)
    deezer = DeezerProvider(settings, storage)
    if not spotify.available:
        emit("Spotify is unavailable right now; trying other providers with fallbacks.")
    profile = TasteProfile.model_validate_json(profile_record["profile_json"])
    tracks = seed_tracks_from_payload(json.loads(profile_record["seed_tracks_json"]))
    before = storage.enrichment_completeness(artists=profile.artists, tracks=tracks)
    before_provider_counts = _artist_enrichment_success_counts(
        storage,
        providers=("spotify", "musicbrainz", "lastfm", "listenbrainz", "deezer"),
    )
    cleared_misses = _clear_artist_enrichment_misses_for_profile(
        storage,
        artists=profile.artists,
        providers=("musicbrainz", "lastfm", "listenbrainz", "deezer"),
    )
    if cleared_misses > 0:
        emit(f"Cleared {cleared_misses} cached artist miss(es) to force fallback re-checks.")
    busy = choose_busy_status_reporter(is_tty=sys.stdout.isatty())
    spotify_artist_metadata: dict[str, dict[str, Any]] = {}
    spotify_for_run = spotify if spotify.available else None
    try:
        with busy.phase(
            "[1/4] Spotify track enrichment",
            wait_lines=[
                "Please wait while we enrich metadata from all available providers.",
                "If one provider is unavailable or rate-limited, fallbacks continue automatically.",
            ],
        ):
            if hasattr(busy, "update"):
                busy.update(
                    label="[1/4] Spotify track enrichment",
                    wait_lines=[
                        "[1/4] Spotify: enrich track metadata and IDs",
                        "Fallbacks stay enabled if Spotify is unavailable.",
                    ],
                )
            try:
                _store_input_track_enrichment(storage, tracks, spotify=spotify_for_run)
            except ProviderRateLimit:
                emit("Spotify track enrichment hit a rate limit; continuing with fallbacks.")
                _store_input_track_enrichment(storage, tracks, spotify=None)
                spotify_for_run = None

            if hasattr(busy, "update"):
                busy.update(
                    label="[2/4] Spotify artist enrichment",
                    wait_lines=[
                        "[2/4] Spotify: enrich artist metadata",
                        "If rate-limited, continuing with Last.fm and MusicBrainz.",
                    ],
                )
            if spotify_for_run is not None:
                try:
                    spotify_artist_metadata = spotify.artist_metadata_from_tracks(tracks)
                    _store_spotify_artist_enrichment_from_tracks(storage, spotify, tracks)
                except ProviderRateLimit:
                    emit("Spotify artist enrichment hit a rate limit; continuing with Last.fm and MusicBrainz.")
                    spotify_for_run = None
                except Exception as exc:
                    emit(f"Spotify artist enrichment failed; continuing with other providers: {_safe_error(exc)}")
                    spotify_for_run = None

            if hasattr(busy, "update"):
                busy.update(
                    label="[3/4] Cross-provider fallback enrichment",
                    wait_lines=[
                        "[3/4] MusicBrainz + Last.fm + ListenBrainz + Deezer",
                        "Building refreshed profile metadata from all available providers.",
                    ],
                )
            refreshed_profile = build_taste_profile(
                tracks,
                spotify=spotify_for_run,
                musicbrainz=musicbrainz,
                lastfm=lastfm,
                listenbrainz=listenbrainz if listenbrainz.available else None,
                deezer=deezer,
                max_artists=max(1, len(profile.artists)),
                spotify_artist_metadata=spotify_artist_metadata,
            )
            if hasattr(busy, "update"):
                busy.update(
                    label="[4/4] Saving refreshed profile",
                    wait_lines=[
                        "[4/4] Persisting updated profile and enrichment state",
                    ],
                )
            storage.upsert_taste_profile(
                name=str(profile_record["name"]),
                source_type=str(profile_record["source_type"]),
                source_ref=str(profile_record["source_ref"]),
                source_key=str(profile_record["source_key"]),
                source_hash=str(profile_record["source_hash"]),
                track_count=int(profile_record["track_count"]),
                artist_count=refreshed_profile.n_artists,
                profile=refreshed_profile,
                seed_tracks=tracks,
                seed_track_keys={str(item) for item in json.loads(profile_record["seed_track_keys_json"])},
            )
    except Exception as exc:
        emit(f"Metadata improvement was interrupted due to provider error: {_safe_error(exc)}")
        return
    refreshed_profile_record = storage.get_taste_profile(profile_record["id"])
    refreshed_profile = profile
    if refreshed_profile_record:
        refreshed_profile = TasteProfile.model_validate_json(refreshed_profile_record["profile_json"])
    after = storage.enrichment_completeness(artists=refreshed_profile.artists, tracks=tracks)
    after_provider_counts = _artist_enrichment_success_counts(
        storage,
        providers=("spotify", "musicbrainz", "lastfm", "listenbrainz", "deezer"),
    )
    artist_delta = after.artist_enriched - before.artist_enriched
    track_delta = after.track_enriched - before.track_enriched
    emit(f"Checked saved profile #{profile_record['id']}: {profile_record['name']}.")
    emit(
        _format_unique_artist_enrichment_summary(
            t=t,
            unique_artist_delta=artist_delta,
            provider_deltas={
                provider: after_provider_counts.get(provider, 0) - before_provider_counts.get(provider, 0)
                for provider in ("spotify", "musicbrainz", "lastfm", "listenbrainz", "deezer")
            },
        )
    )
    if artist_delta <= 0 and track_delta <= 0:
        emit("No additional provider enrichment was found.")
        return
    emit(f"Metadata enrichment updated {track_delta} track(s) and {artist_delta} artist(s).")


def _store_spotify_artist_enrichment_from_tracks(
    storage: Storage,
    spotify: SpotifyProvider,
    tracks: list,
) -> None:
    metadata_by_name = spotify.artist_metadata_from_tracks(tracks)
    for artist_name, payload in metadata_by_name.items():
        if not payload:
            continue
        names = {str(artist_name)}
        if payload.get("name"):
            names.add(str(payload["name"]))
        for name in names:
            storage.upsert_artist_enrichment(
                provider="spotify",
                artist_name=name,
                provider_artist_id=payload.get("id"),
                payload=payload,
            )


def _artist_enrichment_success_counts(storage: Storage, providers: tuple[str, ...]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for provider in providers:
        row = storage.conn.execute(
            """
            SELECT COUNT(*) AS c
            FROM artist_enrichment
            WHERE provider = ? AND status = 'success'
            """,
            (provider,),
        ).fetchone()
        counts[provider] = int((row["c"] if row else 0) or 0)
    return counts


def _clear_artist_enrichment_misses_for_profile(
    storage: Storage,
    *,
    artists: list,
    providers: tuple[str, ...],
) -> int:
    removed = 0
    for artist in artists:
        artist_name = str(getattr(artist, "name", "") or "").strip()
        if not artist_name:
            continue
        key = artist_enrichment_key(artist_name=artist_name, provider_artist_id=None)
        for provider in providers:
            cursor = storage.conn.execute(
                """
                DELETE FROM artist_enrichment
                WHERE provider = ? AND artist_key = ? AND status = 'miss'
                """,
                (provider, key),
            )
            removed += int(cursor.rowcount or 0)
    if removed:
        storage._commit_with_retry()
    return removed


def _format_unique_artist_enrichment_summary(
    *,
    t: callable,
    unique_artist_delta: int,
    provider_deltas: dict[str, int],
) -> str:
    return t(
        "status.unique_artists_enriched_this_run",
        unique=max(0, int(unique_artist_delta)),
        spotify=f"{int(provider_deltas.get('spotify', 0)):+d}",
        musicbrainz=f"{int(provider_deltas.get('musicbrainz', 0)):+d}",
        lastfm=f"{int(provider_deltas.get('lastfm', 0)):+d}",
        listenbrainz=f"{int(provider_deltas.get('listenbrainz', 0)):+d}",
        deezer=f"{int(provider_deltas.get('deezer', 0)):+d}",
    )


def _make_playlist_config_callback(prompts, t):
    """Create a callback that prompts for Spotify/Tidal/Apple playlist creation after discovery completes."""
    def _callback():
        settings = load_settings()

        create_spotify = False
        spotify_name = None
        if settings.spotify_playlist_configured:
            create_spotify = prompts.confirm(
                t("prompt.advanced_settings.spotify_playlist"), default=True
            ).ask()
            if create_spotify is None:
                return None
            if create_spotify:
                raw = _ask_text(prompts, t("prompt.advanced_settings.spotify_playlist_name"), default="")
                if raw is None:
                    return None
                spotify_name = raw or None

        create_tidal = False
        tidal_name = None
        if settings.tidal_configured:
            create_tidal = prompts.confirm(
                t("prompt.advanced_settings.tidal_playlist"), default=False
            ).ask()
            if create_tidal is None:
                return None
            if create_tidal:
                raw = _ask_text(prompts, t("prompt.advanced_settings.tidal_playlist_name"), default="")
                if raw is None:
                    return None
                tidal_name = raw or None

        create_apple = False
        apple_name = None
        apple_target = None
        if settings.apple_music_configured:
            create_apple = prompts.confirm(
                t("prompt.advanced_settings.apple_music_playlist"), default=False
            ).ask()
            if create_apple is None:
                return None
            if create_apple:
                raw = _ask_text(prompts, t("prompt.advanced_settings.apple_music_playlist_name"), default="")
                if raw is None:
                    return None
                apple_name = raw or None
        return (
            bool(create_spotify),
            spotify_name,
            bool(create_tidal),
            tidal_name,
            bool(create_apple),
            apple_name,
            apple_target,
        )
    return _callback


def _make_expansion_memory_save_callback(prompts, t):
    def _callback(profile_id: int, profile_name: str) -> bool | None:
        question = t("prompt.profile_memories.save_after_shortage", profile_id=profile_id, profile_name=profile_name)
        return prompts.confirm(question, default=False).ask()

    return _callback


def _make_shortage_refill_continue_callback(prompts, t):
    def _callback(round_idx: int, current_count: int, target_limit: int) -> bool | None:
        question = t(
            "prompt.profile_memories.continue_shortage_refill",
            round=round_idx,
            current=current_count,
            limit=target_limit,
        )
        return prompts.confirm(question, default=True).ask()

    return _callback


def _load_playlist_tracks(
    playlist: str,
    spotify: SpotifyProvider,
    tidal: TidalProvider,
    apple_music: AppleMusicProvider | None = None,
):
    source_path = Path(playlist).expanduser()
    if source_path.exists():
        return parse_text_file(source_path)
    if looks_like_spotify_playlist(playlist):
        spotify_playlist_ready = bool(getattr(spotify, "playlist_auth_available", getattr(spotify, "available", False)))
        if not spotify_playlist_ready:
            raise WorkflowAbort(
                "Spotify credentials are required for Spotify playlist input. "
                "Set SPOTIPY_CLIENT_ID and SPOTIPY_REDIRECT_URI, use a saved profile instead, or use a local .txt playlist."
            )
        try:
            return spotify.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(str(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(str(exc).splitlines()[0][:160]) from exc
    if looks_like_tidal_playlist(playlist):
        if not tidal.available:
            raise WorkflowAbort(
                "Tidal credentials are required for Tidal playlist input. "
                "Set TIDAL_CLIENT_ID and TIDAL_CLIENT_SECRET, or use a local .txt playlist or TuneMyMusic-style .csv export file."
            )
        try:
            return tidal.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(str(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(str(exc).splitlines()[0][:160]) from exc
    if looks_like_apple_music_playlist(playlist):
        provider = apple_music or AppleMusicProvider(load_settings())
        if not provider.available:
            raise WorkflowAbort(
                "Apple Music credentials are required for Apple Music playlist input. "
                "Set APPLE_MUSIC_DEVELOPER_TOKEN and APPLE_MUSIC_USER_TOKEN, or use a local .txt playlist."
            )
        try:
            return provider.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(str(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(str(exc).splitlines()[0][:160]) from exc
    raise WorkflowAbort(f"Input is neither an existing text file nor a Spotify/Tidal/Apple Music playlist: {playlist}")


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _storage() -> Storage:
    settings = load_settings()
    return Storage(settings.db_path)


def _storage_destructive() -> Storage:
    # Destructive operations must target the same active DB as read operations.
    return _storage()


def _active_db_path() -> Path:
    return load_settings().db_path


def _ask_text(prompts: object, message: str, default: str = "") -> str | None:
    value = prompts.text(message, default=default).ask()
    return None if value is None else str(value).strip()


def _ask_int(
    prompts: object,
    message: str,
    default: int,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int | None:
    while True:
        raw = _ask_text(prompts, message, default=str(default))
        if raw is None:
            return None
        try:
            value = int(raw)
        except ValueError:
            print(f"Enter a whole number for: {message}")
            continue
        if minimum is not None and value < minimum:
            print(f"Value must be at least {minimum}.")
            continue
        if maximum is not None and value > maximum:
            print(f"Value must be at most {maximum}.")
            continue
        return value


def _ask_discovery_window(
    prompts: object,
    message: str,
    default: str = "DD.MM.YYYY - DD.MM.YYYY",
) -> DiscoveryWindow | None:
    while True:
        raw = _ask_text(prompts, message, default=default)
        if raw is None:
            return None
        try:
            return parse_discovery_window_input(raw)
        except ValueError:
            print("Enter a valid date or range: YYYY, MM.YYYY, DD.MM.YYYY, DD-MM-YYYY, YYYY-MM-DD, or X - Y.")
            continue


def _heard_choice_label(entry: dict) -> str:
    return _format_heard_entry_choice_label(entry)


def _heard_choice_label_with_session(entry: dict, category: str, profile_name: str, timestamp: str) -> str:
    """Format entry label without repeating group metadata already visible above."""
    return _format_heard_entry_choice_label(entry)


def _heard_release_text(entry: dict) -> str:
    return f"{entry['artist']} - {entry['title']}"


def _format_heard_entry_choice_label(entry: dict) -> str:
    entry_id = str(entry.get("id", ""))
    artist = str(entry.get("artist", "") or "")
    title = str(entry.get("title", "") or "")
    date_text = _format_release_date_for_menu(entry.get("release_date"))

    # Fixed-width columns for readability in long lists.
    left_pad = "    "
    id_col = f"{entry_id:>5}. "
    artist_col_width = 24
    title_col_width = 44
    gap = "   "
    date_col = f"{date_text:>10}" if date_text else ""

    artist_col = artist[:artist_col_width].ljust(artist_col_width)
    title_col = title
    if len(title_col) > title_col_width:
        title_col = title_col[: title_col_width - 3].rstrip() + "..."
    title_col = title_col.ljust(title_col_width)

    if date_col:
        return f"{left_pad}{id_col}{artist_col} - {title_col}{gap}{date_col}"
    return f"{left_pad}{id_col}{artist_col} - {title_col}".rstrip()


def _format_release_date_for_menu(value: str | None) -> str:
    if not value:
        return ""
    raw = str(value).strip()
    if not raw:
        return ""
    try:
        parsed = dt.date.fromisoformat(raw[:10])
    except ValueError:
        return raw
    return parsed.strftime("%d-%m-%Y")


def _format_session_header(profile_name: str) -> str:
    """Format a session group header."""
    return f"  {profile_name}"


def _session_category_header(category: str) -> str:
    """Format a session category sub-header."""
    label = "Input Releases" if category == "input" else "Output Releases"
    return f"    [{label}]"


def _entry_id_from_choice(choice: str) -> int | None:
    if not isinstance(choice, str):
        return None
    stripped = choice.strip()
    if stripped.startswith("#"):
        token = stripped[1:].split(None, 1)[0]
        try:
            return int(token)
        except ValueError:
            return None
    try:
        return int(choice.split(".", 1)[0].strip())
    except (TypeError, ValueError):
        return None


def _profile_choice_label(profile_summary: dict) -> str:
    profile_id = str(profile_summary.get("id", ""))
    name = str(profile_summary.get("name", "") or "")
    provider = str(profile_summary.get("source_type", "") or "").replace("_", " ").title()

    name_col_width = 40
    if len(name) > name_col_width:
        name = name[: name_col_width - 3].rstrip() + "..."

    return f"{profile_id:>2}. {name:<{name_col_width}}   {provider}"


def _provider_status_label(name: str, indicator: str, status: str) -> str:
    provider_col_width = 22
    return f"{name:<{provider_col_width}}   {indicator} {status}"


def _profile_id_from_choice(choice: str) -> int | None:
    try:
        return int(choice.split(".", 1)[0].strip())
    except (TypeError, ValueError):
        return None


def _safe_error(exc: Exception) -> str:
    return str(exc).splitlines()[0][:160]
