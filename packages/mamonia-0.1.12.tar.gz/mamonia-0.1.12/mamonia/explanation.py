"""
Explanation builder — §11 of the Human Logic Proposal.

Converts a ScoredRelease (output of scoring_v2.py) into:
  - a structured explanation dict suitable for JSON export
  - a ReleaseRecommendation instance for the existing output pipeline

Explanation fields:
    seed_artists    — canonical names of seeds this release connects to
    connection_types — relation types along the path (collaborator, similar, …)
    tier            — Tier 1–4 string
    confidence      — High | Medium | Low (from normalized score)
    rationale_text  — human-readable one-line summary
    source_reliabilities — per-path reliability values (for debugging)
"""

from __future__ import annotations

from .models import ReleaseRecommendation
from .scoring_v2 import ScoredRelease

# Maps relation_type strings to plain-English descriptions
_RELATION_LABELS: dict[str, str] = {
    "direct_seed": "directly in your collection",
    "alias": "alias of a seed artist",
    "member of band": "member of a seed artist's band",
    "collaboration": "collaborated with a seed artist",
    "is collaboration": "collaborative project with seed artists",
    "side project": "side project of a seed artist",
    "founded by": "founded by a seed artist",
    "member": "member of a seed group",
    "producer": "produced by someone connected to your seeds",
    "remix producer": "remixed work connected to your seeds",
    "featured artist": "featured alongside a seed artist",
    "arranger": "arranged music for a seed artist",
    "engineer": "engineered recordings for a seed artist",
    "listenbrainz_similar": "similar listener patterns on ListenBrainz",
    "lastfm_similar": "similar on Last.fm",
    "lastfm_tag": "shares genre/tag with your seeds",
    "label_affinity": "released on a label connected to your seeds",
    "tag_only": "genre/tag match only",
}

_TIER_DESCRIPTIONS: dict[str, str] = {
    "Tier 1": "Known favorite — directly in your collection",
    "Tier 2A": "Strong adjacent — closely connected to your seeds",
    "Tier 2B": "Medium adjacent — somewhat connected to your seeds",
    "Tier 3": "Discovery — similar listening patterns",
    "Tier 4": "Weak discovery — genre or tag match only",
}


def build_explanation(scored: ScoredRelease) -> dict:
    """
    Build a complete structured explanation dict from a ScoredRelease.

    This enriches the raw explanation dict produced by the scoring engine
    with human-readable labels, rationale text, and tier description.
    """
    raw = scored.explanation
    seed_artists: list[str] = raw.get("seed_artists", [])
    connection_types: list[str] = raw.get("connection_types", [])
    tier: str = raw.get("tier", scored.candidate.tier)

    connection_labels = [
        _RELATION_LABELS.get(ct, ct.replace("_", " "))
        for ct in connection_types
    ]
    rationale_text = _build_rationale(seed_artists, connection_labels, tier)

    return {
        "seed_artists": seed_artists,
        "connection_types": connection_types,
        "connection_labels": connection_labels,
        "tier": tier,
        "tier_description": _TIER_DESCRIPTIONS.get(tier, tier),
        "confidence": scored.confidence_label,
        "score_normalized": scored.score_normalized,
        "rationale": rationale_text,
        "source_reliabilities": raw.get("source_reliabilities", []),
    }


def scored_to_recommendation(scored: ScoredRelease) -> ReleaseRecommendation:
    """
    Convert a ScoredRelease into a ReleaseRecommendation for the existing output pipeline.

    Bridges the v2 scoring world to the legacy ReleaseRecommendation model so
    that write_plain_text / write_tunemymusic_csv / write_json all work unchanged.
    """
    candidate = scored.candidate
    explanation = build_explanation(scored)

    rationale_strings = _build_rationale_strings(scored)

    return ReleaseRecommendation(
        artist=candidate.artist_name,
        title=candidate.title,
        release_date=candidate.release_date,
        release_type=candidate.primary_type,
        label=candidate.label,
        score=scored.final_score,
        mb_release_group_id=candidate.release_group_mbid,
        rationale=rationale_strings,
        tier=candidate.tier,
        score_normalized=scored.score_normalized,
        confidence_label=scored.confidence_label,
        explanation=explanation,
        artist_window_release_count=candidate.artist_window_release_count,
    )


def build_fallback_notice(count: int) -> str:
    """
    Return a human-readable notice when falling back from high-score to medium-score results.

    Per the Human Logic Proposal: high-score results (≥75) are shown first; if
    they don't fill the limit, medium-score results (40–74) are appended with a
    clear notice.
    """
    return (
        f"--- Note: the following {count} recommendation(s) are Medium-confidence "
        f"(score 40–74). High-confidence results did not fill your requested limit. ---"
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_rationale(seed_artists: list[str], connection_labels: list[str], tier: str) -> str:
    if not seed_artists and not connection_labels:
        return _TIER_DESCRIPTIONS.get(tier, "Genre/tag match")
    seeds_str = ", ".join(seed_artists[:3])
    if len(seed_artists) > 3:
        seeds_str += f" and {len(seed_artists) - 3} more"
    if connection_labels:
        label = connection_labels[0]
        return f"{label.capitalize()} — connected to {seeds_str}"
    return f"Connected to {seeds_str}"


def _build_rationale_strings(scored: ScoredRelease) -> list[str]:
    """Build legacy rationale string list for ReleaseRecommendation.rationale."""
    raw = scored.explanation
    seed_artists = raw.get("seed_artists", [])
    connection_types = raw.get("connection_types", [])
    strings: list[str] = []
    for ct in connection_types:
        for seed in seed_artists:
            strings.append(f"{ct}:{seed}")
    if not strings:
        strings.append(scored.candidate.tier.lower().replace(" ", "-"))
    return strings
