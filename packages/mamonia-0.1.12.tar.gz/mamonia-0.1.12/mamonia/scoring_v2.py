"""
Scoring engine v2 — §9–10 of the Human Logic Proposal.

Core formula (§9):
    CandidateScore = Σ over all paths to seed artists of:
        SeedWeight × TierFactor × ConnectionStrength × MatchConfidence × SourceReliability

Multi-seed diminishing returns (§9):
    best connection    → 100%
    second connection  → +70%
    third connection   → +40%
    fourth and later   → +20% each (capped)

Modifiers (§10):
    FinalScore = BaseConnectionScore + MultiSeedBonus
               - DuplicatePenalty
               - ConfidencePenalty
               - WeakTagPenalty

Normalized to 0–100.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .graph_expansion import TIER_FACTORS, SOURCE_RELIABILITY
from .models import ArtistSeed, GraphEdge
from .release_discovery import CandidateRelease

# ---------------------------------------------------------------------------
# Modifiers
# ---------------------------------------------------------------------------
_PENALTY_POSSIBLE_DUPLICATE = -0.15
_PENALTY_LOW_CONFIDENCE = -0.20
_PENALTY_UNCERTAIN_TYPE = -0.10

# Multi-seed diminishing-returns multipliers
_MULTISEED_MULTIPLIERS = [1.00, 0.70, 0.40]
_MULTISEED_TAIL = 0.20  # fourth and later connections


@dataclass
class ScoredRelease:
    """A candidate release with its computed scores and explanation."""
    candidate: CandidateRelease
    base_score: float = 0.0
    final_score: float = 0.0
    score_normalized: float = 0.0     # 0–100
    confidence_label: str = "Low"     # High | Medium | Low
    explanation: dict = field(default_factory=dict)


def score_candidates(
    candidates: list[CandidateRelease],
    seeds: list[ArtistSeed],
    edges: list[GraphEdge],
    platform_available: dict[str, set[str]] | None = None,
    emit: Any = None,
) -> list[ScoredRelease]:
    """
    Score all candidate releases and return them sorted by score descending.

    Args:
        candidates: Output of release_discovery.fetch_candidates().
        seeds: Tier 1 ArtistSeed objects from seed_weights.build_artist_seeds().
        edges: GraphEdge objects from graph_expansion.expand_graph().
        platform_available: Optional mapping of release_group_mbid → set of
                            platform names it was found on (for bonus points).

    Returns:
        List of ScoredRelease sorted by score_normalized descending.
    """
    platform_available = platform_available or {}
    _emit = emit or (lambda *_: None)

    # Build lookup structures
    seed_by_key: dict[str, ArtistSeed] = {}
    for s in seeds:
        k = s.artist_mbid or s.canonical_name.lower()
        seed_by_key[k] = s

    # artist_key → list of (seed_key, edge) paths that connect to that artist
    paths_to_artist = _build_paths(edges, seed_by_key)

    scored: list[ScoredRelease] = []
    for candidate in candidates:
        sr = _score_one(candidate, seed_by_key, paths_to_artist, platform_available)
        scored.append(sr)

    # Normalize to 0–100
    if scored:
        max_final = max(s.final_score for s in scored)
        if max_final > 0:
            # Small-pool adjustment: don't let the reference drop too low,
            # otherwise a single dominant candidate compresses everyone else
            # below the Medium threshold.
            # For very small pools (≤5), use max(max_final, 0.35) to avoid
            # compressing scores too much. For pools with only 3 items,
            # this ensures even low raw scores get normalized to a visible range.
            reference = max(max_final, 0.35) if len(scored) <= 5 else max_final
            for sr in scored:
                sr.score_normalized = round((sr.final_score / reference) * 100, 2)
                sr.confidence_label = _confidence_label(sr.score_normalized)
        else:
            # Edge case: all scores are zero - set all to 0 with Low confidence
            for sr in scored:
                sr.score_normalized = 0.0
                sr.confidence_label = "Low"

    scored.sort(key=lambda s: s.score_normalized, reverse=True)
    return scored


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_paths(
    edges: list[GraphEdge],
    seed_by_key: dict[str, ArtistSeed],
) -> dict[str, list[tuple[str, GraphEdge]]]:
    """
    For each expanded artist, collect all GraphEdges that connect back to a seed.
    Returns: artist_key → [(seed_key, edge), ...]
    """
    paths: dict[str, list[tuple[str, GraphEdge]]] = {}
    for edge in edges:
        src_key = edge.source_artist_mbid or edge.source_artist_name.lower()
        tgt_key = edge.target_artist_mbid or edge.target_artist_name.lower()
        if src_key in seed_by_key:
            if tgt_key not in paths:
                paths[tgt_key] = []
            paths[tgt_key].append((src_key, edge))
    return paths


def _score_one(
    candidate: CandidateRelease,
    seed_by_key: dict[str, ArtistSeed],
    paths_to_artist: dict[str, list[tuple[str, GraphEdge]]],
    platform_available: dict[str, set[str]],
) -> ScoredRelease:
    artist_key = candidate.artist_mbid or candidate.artist_name.lower()
    tier = candidate.tier

    # Tier 1 artists are seeds themselves — score via direct seed weight
    if tier == "Tier 1" and artist_key in seed_by_key:
        seed = seed_by_key[artist_key]
        tier_factor = TIER_FACTORS.get(tier, 1.0)
        path_score = seed.seed_weight * tier_factor * 1.0 * seed.match_confidence_avg * 1.0
        connection_scores = [path_score]
        connecting_seeds = [seed.canonical_name]
        connection_types = ["direct_seed"]
        source_reliabilities = [1.0]
    else:
        # LB-similar artists enter the graph keyed by name (LB returns no MBIDs),
        # but fetch_candidates resolves them to MBIDs via MB search. Try the
        # MBID key first, then fall back to the name key used in _build_paths.
        paths = paths_to_artist.get(artist_key) or paths_to_artist.get(
            candidate.artist_name.lower(), []
        )
        connection_scores = []
        connecting_seeds = []
        connection_types = []
        source_reliabilities = []

        for seed_key, edge in paths:
            seed = seed_by_key.get(seed_key)
            if not seed:
                continue
            tier_factor = TIER_FACTORS.get(edge.tier, 0.25)
            source_rel = _source_reliability_for_edge(edge)
            path_score = (
                seed.seed_weight
                * tier_factor
                * edge.connection_strength
                * seed.match_confidence_avg
                * source_rel
            )
            connection_scores.append(path_score)
            connecting_seeds.append(seed.canonical_name)
            connection_types.append(edge.relation_type)
            source_reliabilities.append(source_rel)

    if not connection_scores:
        # Tier 4 artists with no traceable path still get a minimum score
        tier_factor = TIER_FACTORS.get(tier, 0.25)
        connection_scores = [0.05 * tier_factor]
        connecting_seeds = []
        connection_types = ["tag_only"]
        source_reliabilities = [0.40]

    # Multi-seed diminishing returns
    connection_scores_sorted = sorted(connection_scores, reverse=True)
    base_score = _apply_diminishing_returns(connection_scores_sorted)

    # Modifiers
    modifier = 0.0
    if candidate.possible_reissue:
        modifier += _PENALTY_POSSIBLE_DUPLICATE
    if candidate.uncertain_release_type:
        modifier += _PENALTY_UNCERTAIN_TYPE

    # Low-confidence candidates (tier 4 with tag-only) get a confidence penalty
    if tier == "Tier 4" and "tag_only" in connection_types:
        modifier += _PENALTY_LOW_CONFIDENCE

    final_score = max(0.0, base_score + modifier)

    explanation = {
        "seed_artists": list(dict.fromkeys(connecting_seeds)),  # dedup, preserve order
        "connection_types": list(dict.fromkeys(connection_types)),
        "tier": tier,
        "source_reliabilities": [round(r, 2) for r in source_reliabilities[:3]],
    }

    return ScoredRelease(
        candidate=candidate,
        base_score=round(base_score, 6),
        final_score=round(final_score, 6),
        explanation=explanation,
    )


def _apply_diminishing_returns(scores: list[float]) -> float:
    """Apply 100% / 70% / 40% / 20% diminishing returns across multiple seed connections."""
    total = 0.0
    for i, score in enumerate(scores):
        if i < len(_MULTISEED_MULTIPLIERS):
            total += score * _MULTISEED_MULTIPLIERS[i]
        else:
            total += score * _MULTISEED_TAIL
    return total


def _source_reliability_for_edge(edge: GraphEdge) -> float:
    """Map edge relation_type to a SourceReliability value."""
    rtype = edge.relation_type.lower()
    if rtype in ("label_affinity",):
        return 0.70
    if rtype in ("listenbrainz_similar",):
        return SOURCE_RELIABILITY["listenbrainz"]
    if rtype in ("lastfm_similar",):
        return SOURCE_RELIABILITY["lastfm_similar"]
    if rtype in ("lastfm_tag", "tag_only"):
        return SOURCE_RELIABILITY["lastfm_tag"]
    if rtype in ("fuzzy",):
        return SOURCE_RELIABILITY["fuzzy"]
    # All MusicBrainz relations (member_of, collaboration, producer, etc.)
    return SOURCE_RELIABILITY["musicbrainz"]


def _confidence_label(score_normalized: float) -> str:
    if score_normalized >= 75:
        return "High"
    if score_normalized >= 40:
        return "Medium"
    return "Low"
