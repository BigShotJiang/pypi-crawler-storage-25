from __future__ import annotations

import datetime as dt
from typing import Any

from .enrichment import (
    _cap_tracks,
    _attach_musicbrainz_tracks,
    _attach_spotify_tracks,
    _backfill_isrc_from_fallbacks,
    _backfill_musicbrainz_tracks,
    _enrich_tracks_with_musicbrainz,
    _track_resolution_score,
    _track_source_priority,
    enrich_recommendation_tracks_lightweight,
    filter_seed_tracks,
    track_key,
)
from .filtering.community_artists import CommunityArtistsFilter
from .models import CandidateArtist, InputTrack, ReleaseRecommendation, ReleaseTrack, TasteProfile
from .progress import NoOpProgressReporter, ProgressReporter
from .storage import Storage, canonical_release_key
from .utils import (
    artist_credits_match,
    clamp,
    normalize_key,
    normalize_variant_title,
    parse_date,
    release_title_match,
    release_year,
    safe_get,
    split_artist_names,
    variant_score,
    within_month_window,
)


PRIMARY_TYPES = {"Album", "EP", "Single"}
SECONDARY_BLOCKLIST = {"Live", "Compilation", "Remix", "DJ-mix", "Soundtrack", "Interview"}
SOUNDTRACK_PROFILE_TERMS = {
    "cinematic classical",
    "film composer",
    "game music",
    "score",
    "soundtrack",
    "video game music",
}


def candidate_artists_from_profile(
    profile: TasteProfile,
    max_candidates: int | None = None,
    settings: Any | None = None,
    deep_cuts: bool = False,
) -> list[CandidateArtist]:
    candidates: list[CandidateArtist] = []
    artists = profile.artists or profile.top_artists
    for artist in artists:
        seed_multiplier = 1.0 if artist.playlist_count >= 3 else 0.75 if artist.playlist_count == 2 else 0.45
        network_multiplier = 1.0 if artist.playlist_count >= 3 else 0.55 if artist.playlist_count == 2 else 0.2
        candidates.append(
            CandidateArtist(
                name=artist.name,
                source="seed-artist",
                score=max(0.5, artist.affinity_score * seed_multiplier),
                mbid=artist.mbid,
            )
        )
        for name in artist.related_acts[:8]:
            candidates.append(
                CandidateArtist(
                    name=name,
                    source=f"related-act:{artist.name}",
                    score=artist.affinity_score * 0.75 * network_multiplier,
                )
            )
        for name in artist.collaborator_artists[:8]:
            candidates.append(
                CandidateArtist(
                    name=name,
                    source=f"collaborator:{artist.name}",
                    score=artist.affinity_score * 0.65 * network_multiplier,
                )
            )
        for name in artist.similar_artists[:8]:
            candidates.append(
                CandidateArtist(
                    name=name,
                    source=f"lastfm-similar:{artist.name}",
                    score=artist.affinity_score * 0.55 * network_multiplier,
            )
        )

    for term in profile.network_artists[:40]:
        candidates.append(
            CandidateArtist(
                name=term.name,
                source="profile-network",
                score=max(0.5, term.weight * 0.6),
            )
        )

    # Use filtered community artists if available
    if profile.filtered_community_artists:
        for artist_name, fca in profile.filtered_community_artists.items():
            # Handle both legacy float and new FilteredCommunityArtist
            if isinstance(fca, (int, float)):
                relevance = float(fca)
                seed_artists = []
                rescue_reason = "none"
            else:
                relevance = fca.relevance
                seed_artists = fca.seed_artists
                rescue_reason = fca.rescue_reason or "none"

            # Gate LB-only candidates: suppress in standard mode, allow in deep_cuts.
            if rescue_reason.startswith("lb-only:"):
                if not deep_cuts:
                    continue
                # deep_cuts: apply the soft listener-share floor
                try:
                    share = float(rescue_reason.split(":")[-1])
                except (ValueError, IndexError):
                    share = 0.0
                min_share = getattr(settings, "listenbrainz_min_share_for_deep_cuts", 0.2) if settings else 0.2
                if share < min_share:
                    continue

            if relevance > 0.2:
                # Build honest source string from rescue_reason
                seeds_label = ",".join(seed_artists[:3])
                if rescue_reason.startswith("cross-verified:"):
                    source = f"lb-community:{rescue_reason}:{seeds_label}"
                elif rescue_reason.startswith("lb-density:"):
                    source = f"lb-community:{rescue_reason}:{seeds_label}"
                elif rescue_reason.startswith("deep-cuts:") or rescue_reason.startswith("lb-only:"):
                    source = f"lb-community:deep-cuts-only:{seeds_label}"
                elif rescue_reason not in ("none", ""):
                    source = f"lb-community:rescued:{rescue_reason}:{seeds_label}"
                else:
                    source = f"lb-community:ubiquitous({relevance:.2f}):{seeds_label}"

                candidates.append(
                    CandidateArtist(
                        name=artist_name,
                        source=source,
                        score=max(0.5, relevance * 0.6),
                    )
                )
    else:
        # Fallback to original behavior - add community artists from profiles
        for artist in artists:
            for name in artist.community_artists[:10]:
                candidates.append(
                    CandidateArtist(
                        name=name,
                        source=f"community:{artist.name}",
                        score=artist.affinity_score * 0.4,
                    )
                )

    merged: dict[str, CandidateArtist] = {}
    for candidate in candidates:
        key = normalize_key(candidate.name)
        if key in merged:
            merged[key].score += candidate.score
            if not merged[key].mbid and candidate.mbid:
                merged[key].mbid = candidate.mbid
            if candidate.source not in merged[key].source:
                merged[key].source = f"{merged[key].source}; {candidate.source}"
        else:
            merged[key] = candidate
    sorted_candidates = sorted(merged.values(), key=lambda item: item.score, reverse=True)
    return _apply_candidate_limit(sorted_candidates, max_candidates)


def discover_releases(
    profile: TasteProfile,
    storage: Storage,
    musicbrainz: Any,
    spotify: Any | None = None,
    seed_tracks: list[InputTrack] | None = None,
    seed_track_keys: set[str] | None = None,
    months: int = 6,
    max_tracks: int = 3,
    limit: int = 40,
    max_candidates: int | None = None,
    deep_cuts: bool = False,
    tiered_results: bool = False,
    today: dt.date | None = None,
    progress: ProgressReporter | None = None,
    settings: Any | None = None,
    isrc_resolver: Any | None = None,
) -> list[ReleaseRecommendation]:
    max_tracks = max(0, max_tracks)
    today = today or dt.date.today()
    progress = progress or NoOpProgressReporter()
    merged: dict[str, ReleaseRecommendation] = {}
    seed_track_keys = seed_track_keys or track_keys_from_input(seed_tracks or [])
    source_release_keys = source_release_keys_from_input(seed_tracks or [])
    allow_soundtracks = profile_allows_soundtracks(profile)
    candidates = candidate_artists_from_profile(profile, max_candidates=max_candidates, settings=settings, deep_cuts=deep_cuts)
    
    # Cache for release group tracks to avoid re-enriching the same MB release group
    release_group_tracks_cache: dict[str, list[ReleaseTrack]] = {}
    # Pre-fetch heard MBIDs for quick filtering
    heard_mbids = storage.all_heard_release_group_mbids()
    heard_diag: dict[str, int] = {
        "excluded_by_mbid": 0,
        "excluded_by_spotify_album": 0,
        "excluded_by_track_identity": 0,
        "excluded_by_fallback_title": 0,
        "not_excluded": 0,
    }

    for processed, candidate in enumerate(candidates, start=1):
        progress.candidate_started(candidate, processed, len(candidates))
        mbid = candidate.mbid or _candidate_mbid(candidate, musicbrainz)
        if not mbid:
            progress.release_group_skipped("artist-mbid-missing")
            continue
        for release_group in musicbrainz.browse_release_groups(mbid):
            progress.release_group_checked(candidate, release_group)
            if not is_allowed_release_group(
                release_group,
                months=months,
                today=today,
                allow_soundtracks=allow_soundtracks,
            ):
                progress.release_group_skipped("date-or-type-filter")
                continue
            rec = recommendation_from_release_group(release_group, candidate)
            
            # Skip if MBID is already in heard list
            if rec.mb_release_group_id and rec.mb_release_group_id in heard_mbids:
                heard_diag["excluded_by_mbid"] += 1
                progress.release_group_skipped("heard")
                continue
                
            _consider_recommendation(
                merged=merged,
                rec=rec,
                storage=storage,
                musicbrainz=musicbrainz,
                spotify=spotify,
                seed_track_keys=seed_track_keys,
                source_release_keys=source_release_keys,
                max_tracks=max_tracks,
                candidate_score=candidate.score,
                progress=progress,
                deep_cuts=deep_cuts,
                months=months,
                today=today,
                isrc_resolver=isrc_resolver,
                release_group_tracks_cache=release_group_tracks_cache,
                heard_diag=heard_diag,
            )

    for label_term in profile.top_labels[:5]:
        for rec in label_affinity_recommendations(
            musicbrainz=musicbrainz,
            label_name=label_term.name,
            weight=label_term.weight,
            months=months,
            today=today,
            allow_soundtracks=allow_soundtracks,
        ):
            _consider_recommendation(
                merged=merged,
                rec=rec,
                storage=storage,
                musicbrainz=musicbrainz,
                spotify=spotify,
                seed_track_keys=seed_track_keys,
                source_release_keys=source_release_keys,
                max_tracks=max_tracks,
                candidate_score=rec.score,
                progress=progress,
                deep_cuts=deep_cuts,
                months=months,
                today=today,
                isrc_resolver=isrc_resolver,
                heard_diag=heard_diag,
            )

    setattr(storage, "_last_heard_discovery_diagnostics", heard_diag)
    sparsity = getattr(storage, "heard_row_sparsity", None)
    if callable(sparsity):
        setattr(storage, "_last_heard_row_sparsity", sparsity())

    results = sorted(
        merged.values(),
        key=lambda rec: (rec.score, parse_date(rec.release_date) or dt.date.min),
        reverse=True,
    )
    if tiered_results:
        return tiered_sample_recommendations(results, limit=limit)
    return results[:limit]


def _apply_candidate_limit(
    candidates: list[CandidateArtist],
    max_candidates: int | None,
) -> list[CandidateArtist]:
    if max_candidates is None or max_candidates <= 0 or len(candidates) <= max_candidates:
        return candidates

    seed_candidates = [candidate for candidate in candidates if "seed-artist" in candidate.source]
    seed_keys = {normalize_key(candidate.name) for candidate in seed_candidates}
    remaining_slots = max(0, max_candidates - len(seed_candidates))
    selected = seed_candidates + [
        candidate
        for candidate in candidates
        if normalize_key(candidate.name) not in seed_keys
    ][:remaining_slots]
    return sorted(selected, key=lambda item: item.score, reverse=True)


def is_allowed_release_group(
    release_group: dict[str, Any],
    months: int,
    today: dt.date | None = None,
    allow_soundtracks: bool = False,
) -> bool:
    primary = release_group.get("primary-type")
    secondary = set(release_group.get("secondary-types", []) or [])
    date = release_group.get("first-release-date")
    secondary_blocklist = SECONDARY_BLOCKLIST if not allow_soundtracks else SECONDARY_BLOCKLIST - {"Soundtrack"}
    if primary not in PRIMARY_TYPES:
        return False
    if secondary & secondary_blocklist:
        return False
    return within_month_window(date, months, today=today)


def profile_allows_soundtracks(profile: TasteProfile) -> bool:
    terms = profile.top_tags + profile.top_genres
    return any(normalize_key(term.name) in SOUNDTRACK_PROFILE_TERMS for term in terms[:20])


def recommendation_from_release_group(
    release_group: dict[str, Any],
    candidate: CandidateArtist,
) -> ReleaseRecommendation:
    artist_credit = release_group.get("artist-credit", []) or []
    artist_name = safe_get(artist_credit, 0, "name", default=candidate.name) or candidate.name
    artist_credits = [item.get("name") or safe_get(item, "artist", "name") for item in artist_credit]
    return ReleaseRecommendation(
        artist=artist_name,
        artist_credits=[name for name in artist_credits if name],
        title=release_group.get("title", ""),
        release_date=release_group.get("first-release-date", ""),
        release_type=(release_group.get("primary-type") or "Release").lower(),
        label=release_group.get("label"),
        score=candidate.score,
        rationale=[candidate.source],
        mb_release_group_id=release_group.get("id"),
    )


def label_affinity_recommendations(
    *,
    musicbrainz: Any,
    label_name: str,
    weight: float,
    months: int,
    today: dt.date,
    allow_soundtracks: bool,
) -> list[ReleaseRecommendation]:
    releases = getattr(musicbrainz, "search_releases_by_label", lambda *_args, **_kwargs: [])(label_name, limit=25)
    recommendations: list[ReleaseRecommendation] = []
    seen_group_ids: set[str] = set()
    for release in releases:
        release_group = release.get("release-group") or {}
        release_group_id = release_group.get("id")
        if release_group_id and release_group_id in seen_group_ids:
            continue
        candidate = CandidateArtist(
            name=safe_get(release, "artist-credit", 0, "name", default="") or "",
            source=f"label-affinity:{label_name}",
            score=max(0.5, weight * 0.35),
        )
        normalized_group = {
            "id": release_group_id,
            "title": release_group.get("title") or release.get("title", ""),
            "primary-type": release_group.get("primary-type") or release.get("release-group", {}).get("primary-type") or "Album",
            "secondary-types": release_group.get("secondary-types") or [],
            "first-release-date": release_group.get("first-release-date") or release.get("date", ""),
            "artist-credit": release.get("artist-credit", []) or release_group.get("artist-credit", []) or [],
            "label": safe_get(release, "label-info", 0, "label", "name") or label_name,
        }
        if not is_allowed_release_group(normalized_group, months=months, today=today, allow_soundtracks=allow_soundtracks):
            continue
        rec = recommendation_from_release_group(normalized_group, candidate)
        rec.label = rec.label or label_name
        recommendations.append(rec)
        if release_group_id:
            seen_group_ids.add(release_group_id)
    return recommendations


def _candidate_mbid(candidate: CandidateArtist, musicbrainz: Any) -> str | None:
    try:
        artist = musicbrainz.search_artist(candidate.name)
    except Exception:
        return None
    candidate.mbid = artist.get("id") if artist else None
    return candidate.mbid


def track_keys_from_input(tracks: list[InputTrack]) -> set[str]:
    keys: set[str] = set()
    for track in tracks:
        keys.update(track_identity_keys(track))
    return keys


def track_key_for_diff(track: InputTrack) -> str:
    if track.isrc:
        return f"isrc:{normalize_key(track.isrc)}"
    if track.spotify_track_id:
        return f"spotify:track:{track.spotify_track_id}"
    if track.tidal_track_id:
        return f"tidal:track:{track.tidal_track_id}"
    key = track_key(track.artist, track.track)
    return f"metadata:{key}" if key else ""


def track_identity_keys(track: InputTrack) -> set[str]:
    keys: set[str] = set()
    if track.isrc:
        keys.add(f"isrc:{normalize_key(track.isrc)}")
    if track.spotify_track_id:
        keys.add(f"spotify:track:{track.spotify_track_id}")
    if track.tidal_track_id:
        keys.add(f"tidal:track:{track.tidal_track_id}")
    key = track_key(track.artist, track.track)
    if key:
        keys.add(f"metadata:{key}")
    return keys


def source_release_keys_from_input(tracks: list[InputTrack]) -> set[str]:
    keys: set[str] = set()
    for track in tracks:
        if not track.album:
            continue
        artist_names = track.all_artist_names() or [track.artist]
        for artist_name in artist_names:
            key = _release_memory_key(artist_name, track.album)
            if key:
                keys.add(key)
    return keys


def recommendation_matches_source_memory(rec: ReleaseRecommendation, source_release_keys: set[str]) -> bool:
    if not source_release_keys:
        return False
    if _release_memory_key(rec.artist, rec.title) in source_release_keys:
        return True
    for artist_name in rec.artist_credits:
        if _release_memory_key(artist_name, rec.title) in source_release_keys:
            return True
    return False


def average_track_popularity(rec: ReleaseRecommendation) -> float | None:
    popularities = [track.popularity for track in rec.tracks if track.popularity > 0]
    if not popularities:
        return None
    return sum(popularities) / len(popularities)


def passes_popularity_filter(rec: ReleaseRecommendation, *, deep_cuts: bool) -> bool:
    if not deep_cuts:
        return True
    popularity = average_track_popularity(rec)
    if popularity is None:
        return True
    return popularity <= 65




def recommendation_identity_key(rec: ReleaseRecommendation) -> str:
    return canonical_release_key(
        artist=rec.artist,
        title=rec.title,
        release_date=rec.release_date,
        mb_release_group_id=rec.mb_release_group_id,
        spotify_album_id=rec.spotify_album_id,
        label=rec.label,
    )


def _find_matching_recommendation_key(
    merged: dict[str, ReleaseRecommendation],
    rec: ReleaseRecommendation,
) -> str | None:
    direct_key = recommendation_identity_key(rec)
    if direct_key in merged:
        return direct_key
    for key, existing in merged.items():
        if _recommendations_match(existing, rec):
            return key
    return None


def _recommendations_match(left: ReleaseRecommendation, right: ReleaseRecommendation) -> bool:
    if left.mb_release_group_id and right.mb_release_group_id and left.mb_release_group_id == right.mb_release_group_id:
        return True
    if left.spotify_album_id and right.spotify_album_id and left.spotify_album_id == right.spotify_album_id:
        return True
    if normalize_key(left.label) and normalize_key(right.label) and normalize_key(left.label) != normalize_key(right.label):
        return False
    if left.fallback_key == right.fallback_key and bool(left.fallback_key):
        return True
    left_year = release_year(left.release_date)
    right_year = release_year(right.release_date)
    if left_year and right_year and left_year != right_year:
        return False
    return release_title_match(left.title, right.title) and artist_credits_match(
        left.artist_credits or left.artist,
        right.artist_credits or right.artist,
    )


def _merge_recommendation(existing: ReleaseRecommendation, incoming: ReleaseRecommendation, candidate_score: float) -> None:
    existing.score += candidate_score * 0.2
    for reason in incoming.rationale:
        if reason not in existing.rationale:
            existing.rationale.append(reason)
    if not existing.mb_release_group_id and incoming.mb_release_group_id:
        existing.mb_release_group_id = incoming.mb_release_group_id
    if not existing.spotify_album_id and incoming.spotify_album_id:
        existing.spotify_album_id = incoming.spotify_album_id
        existing.spotify_album_uri = incoming.spotify_album_uri
    if _track_resolution_score(incoming.tracks) > _track_resolution_score(existing.tracks):
        existing.tracks = incoming.tracks
    # Prefer higher variant score (remastered > deluxe > original)
    if variant_score(incoming.title) > variant_score(existing.title):
        existing.title = incoming.title
        existing.release_date = incoming.release_date
        existing.release_type = incoming.release_type
        existing.label = incoming.label
        if incoming.tracks:
            existing.tracks = incoming.tracks
    existing.score = _apply_serendipity_weight(existing)


def _track_resolution_score(tracks: list[ReleaseTrack]) -> tuple[int, int]:
    spotify_resolved = sum(1 for track in tracks if track.spotify_track_id)
    priority = max((_track_source_priority(track) for track in tracks), default=0)
    return spotify_resolved, priority


def _track_source_priority(track: ReleaseTrack) -> int:
    source = track.resolution_source or ""
    if source == "spotify_album_tracklist":
        return 3
    if source.startswith("spotify_track_search_") or source == "spotify_cached_track":
        return 2
    if source == "musicbrainz_tracklist":
        return 1
    return 0


def _release_memory_key(artist: str | None, title: str | None) -> str:
    artist_key = normalize_key(artist)
    title_key = normalize_variant_title(title)
    return f"{artist_key}|{title_key}" if artist_key and title_key else ""


def _consider_recommendation(
    *,
    merged: dict[str, ReleaseRecommendation],
    rec: ReleaseRecommendation,
    storage: Storage,
    musicbrainz: Any,
    spotify: Any | None,
    seed_track_keys: set[str],
    source_release_keys: set[str],
    max_tracks: int,
    candidate_score: float,
    progress: ProgressReporter,
    deep_cuts: bool,
    months: int,
    today: dt.date,
    isrc_resolver: Any | None = None,
    release_group_tracks_cache: dict[str, list[ReleaseTrack]] | None = None,
    heard_diag: dict[str, int] | None = None,
) -> None:
    match_reason = getattr(storage, "heard_match_reason_recommendation", None)
    initial_reason = match_reason(rec) if callable(match_reason) else ("fallback_title" if storage.is_heard_recommendation(rec) else None)
    if initial_reason:
        if heard_diag is not None:
            if initial_reason == "mbid":
                heard_diag["excluded_by_mbid"] += 1
            elif initial_reason == "spotify_album":
                heard_diag["excluded_by_spotify_album"] += 1
            elif initial_reason.startswith("track_"):
                heard_diag["excluded_by_track_identity"] += 1
            else:
                heard_diag["excluded_by_fallback_title"] += 1
        progress.release_group_skipped("heard")
        return
    if recommendation_matches_source_memory(rec, source_release_keys):
        progress.release_group_skipped("source-memory-duplicate")
        return

    # Use cache if available for this MB release group
    cached_tracks = None
    if release_group_tracks_cache is not None and rec.mb_release_group_id:
        cached_tracks = release_group_tracks_cache.get(rec.mb_release_group_id)
    
    if cached_tracks is not None:
        # Apply cached tracks (filter seed tracks)
        rec.tracks = _cap_tracks(filter_seed_tracks(cached_tracks, seed_track_keys), max_tracks)
    else:
        # Lightweight discovery enrichment: MusicBrainz first, then ISRC fallback.
        # Spotify-heavy enrichment is deferred to later stages.
        enrich_recommendation_tracks_lightweight(
            rec,
            musicbrainz=musicbrainz,
            isrc_resolver=isrc_resolver,
            max_tracks=max_tracks,
            seed_track_keys=seed_track_keys,
        )
        # Store in cache for future use
        if release_group_tracks_cache is not None and rec.mb_release_group_id and rec.tracks:
            release_group_tracks_cache[rec.mb_release_group_id] = rec.tracks.copy()

    # ISRC source tracking: ISRC_source now contains provider name or failure code (s_nF, m_nF, t_nF, d_nF)
    # Success: "input", "spotify", "musicbrainz", "tidal", "deezer"
    # Failure: "s_nF", "m_nF", "t_nF", "d_nF" (or semicolon-separated combinations)
    # DEBUG: Uncomment to see ISRC lookup results:
    # for track in rec.tracks:
    #     if track.isrc:
    #         progress.log_debug(f"✅ ISRC found: {track.isrc} | {track.artists} - {track.title} | source: {track.isrc_source}")
    #     else:
    #         progress.log_debug(f"⚠️  NO ISRC: {track.artists} - {track.title} | source: {track.isrc_source}")
    post_reason = match_reason(rec) if callable(match_reason) else ("fallback_title" if storage.is_heard_recommendation(rec) else None)
    if post_reason:
        if heard_diag is not None:
            if post_reason == "mbid":
                heard_diag["excluded_by_mbid"] += 1
            elif post_reason == "spotify_album":
                heard_diag["excluded_by_spotify_album"] += 1
            elif post_reason.startswith("track_"):
                heard_diag["excluded_by_track_identity"] += 1
            else:
                heard_diag["excluded_by_fallback_title"] += 1
        progress.release_group_skipped(f"heard-after-spotify-resolution-{post_reason}")
        return
    if heard_diag is not None:
        heard_diag["not_excluded"] += 1

    # Track which lookups succeeded
    spotify_found = bool(rec.tracks) and any(
        t.resolution_source and "spotify" in t.resolution_source.lower()
        for t in rec.tracks
    )
    musicbrainz_found = bool(rec.tracks) and any(
        t.resolution_source and "musicbrainz" in t.resolution_source.lower()
        for t in rec.tracks
    )

    # Build granular rationale
    if not rec.tracks:
        if spotify is not None and not spotify_found:
            rec.rationale.append("spotify-lookup-missed")
            progress.spotify_lookup_missed(rec)
        if not musicbrainz_found and rec.mb_release_group_id:
            rec.rationale.append("musicbrainz-no-tracks")
            progress.musicbrainz_lookup_missed(rec)
    if not passes_popularity_filter(rec, deep_cuts=deep_cuts):
        progress.release_group_skipped("deep-cuts-popularity-filter")
        return
    rec.score = _apply_serendipity_weight(rec)
    key = _find_matching_recommendation_key(merged, rec)
    if key is not None:
        _merge_recommendation(merged[key], rec, candidate_score)
        updated_key = recommendation_identity_key(merged[key])
        if updated_key != key:
            merged[updated_key] = merged.pop(key)
        return
    merged[recommendation_identity_key(rec)] = rec
    progress.release_accepted(rec)


def _apply_serendipity_weight(rec: ReleaseRecommendation) -> float:
    popularity = average_track_popularity(rec)
    if popularity is None:
        return rec.score
    bonus = max(-1.5, min(2.5, (55.0 - popularity) / 20.0))
    return rec.score + bonus


def tiered_sample_recommendations(results: list[ReleaseRecommendation], *, limit: int) -> list[ReleaseRecommendation]:
    if limit <= 0 or len(results) <= limit or len(results) < 6:
        return results[:limit]
    bucket_size = max(1, len(results) // 3)
    high = results[:bucket_size]
    mid = results[bucket_size : bucket_size * 2]
    low = results[bucket_size * 2 :]
    high_quota = max(1, round(limit * 0.4))
    low_quota = 1 if limit >= 3 and low else 0
    mid_quota = max(0, limit - high_quota - low_quota)
    quotas = [
        (high, high_quota),
        (mid, mid_quota),
        (low, low_quota),
    ]
    selected: list[ReleaseRecommendation] = []
    seen_keys: set[str] = set()
    for bucket, quota in quotas:
        taken = 0
        for rec in bucket:
            if taken >= quota:
                break
            key = recommendation_identity_key(rec)
            if key in seen_keys:
                continue
            selected.append(rec)
            seen_keys.add(key)
            taken += 1
            if len(selected) >= limit:
                return selected[:limit]
    for rec in results:
        if len(selected) >= limit:
            break
        key = recommendation_identity_key(rec)
        if key in seen_keys:
            continue
        selected.append(rec)
        seen_keys.add(key)
    return selected[:limit]
