"""
Seed weight computation — §3–4 of the Human Logic Proposal.

Takes a list of CanonicalTrack objects (output of canonicalization.py) and
produces one ArtistSeed per unique artist, with a normalized seed_weight in 0–1.

Formula (§4, adapted — playlist position and platform presence excluded;
position is unreliable in shuffled playlists, platform presence is not a
signal of user preference):
    SeedWeight =
        0.40 × frequency_score
      + 0.30 × unique_track_score
      + 0.10 × match_confidence_avg
    → normalize to 0–1

frequency_score      = log1p(artist_tracks) / log1p(max_artist_tracks_in_profile)
unique_track_score   = unique_tracks_by_artist / max_unique_tracks_by_artist
match_confidence_avg = mean of per-track match_confidence values
"""

from __future__ import annotations

import math
from collections import defaultdict

from .models import ArtistSeed, CanonicalTrack

# Weight coefficients (sum to 1.0)
# playlist_position excluded — shuffled playlists carry no position signal
# platform_presence excluded — not a signal of user preference
_W_FREQ = 0.40
_W_UNIQUE = 0.30
_W_CONFIDENCE = 0.10


def build_artist_seeds(canonical_tracks: list[CanonicalTrack]) -> list[ArtistSeed]:
    """Compute one ArtistSeed per artist from a list of CanonicalTracks.

    Artists are keyed by artist_mbid when available, falling back to
    lower-cased artist_name_canonical to avoid duplicates.
    Returns seeds sorted by seed_weight descending.
    """
    if not canonical_tracks:
        return []

    # Group tracks by artist key
    artist_tracks: dict[str, list[CanonicalTrack]] = defaultdict(list)
    for ct in canonical_tracks:
        key = ct.artist_mbid or ct.artist_name_canonical.lower().strip()
        if key:
            artist_tracks[key].append(ct)

    # First pass: gather raw counts for normalization denominators
    freq_counts: dict[str, int] = {}
    unique_counts: dict[str, int] = {}

    for key, tracks in artist_tracks.items():
        freq_counts[key] = len(tracks)
        unique_titles = {(ct.input_track or "").lower().strip() for ct in tracks if ct.input_track}
        unique_counts[key] = len(unique_titles) if unique_titles else 1

    max_freq = max(freq_counts.values(), default=1)
    max_unique = max(unique_counts.values(), default=1)

    # Second pass: compute per-artist ArtistSeed
    seeds: list[ArtistSeed] = []
    for key, tracks in artist_tracks.items():
        canonical_name = _best_canonical_name(tracks)
        artist_mbid = next((ct.artist_mbid for ct in tracks if ct.artist_mbid), None)

        # Ensure string fields are actual strings (defensive against MagicMock in tests)
        if not isinstance(canonical_name, str):
            canonical_name = str(canonical_name) if canonical_name else ""
        if artist_mbid is not None and not isinstance(artist_mbid, str):
            artist_mbid = str(artist_mbid) if artist_mbid else None

        frequency_score = math.log1p(freq_counts[key]) / math.log1p(max_freq)
        unique_track_score = unique_counts[key] / max_unique

        confidence_values = [ct.match_confidence for ct in tracks]
        match_confidence_avg = sum(confidence_values) / len(confidence_values)

        raw_weight = (
            _W_FREQ * frequency_score
            + _W_UNIQUE * unique_track_score
            + _W_CONFIDENCE * match_confidence_avg
        )

        unique_release_count = len({ct.release_group_mbid for ct in tracks if ct.release_group_mbid})

        seeds.append(ArtistSeed(
            artist_mbid=artist_mbid,
            canonical_name=canonical_name,
            source_frequency=freq_counts[key],
            unique_track_count=unique_counts[key],
            unique_release_count=unique_release_count,
            match_confidence_avg=match_confidence_avg,
            seed_weight=raw_weight,  # normalized below
        ))

    # Normalize seed_weight to [0, 1] across all seeds
    max_weight = max((s.seed_weight for s in seeds), default=1.0)
    if max_weight > 0:
        for seed in seeds:
            seed.seed_weight = round(seed.seed_weight / max_weight, 6)

    seeds.sort(key=lambda s: s.seed_weight, reverse=True)
    return seeds


def _best_canonical_name(tracks: list[CanonicalTrack]) -> str:
    """Pick the most-used canonical name for an artist across their tracks."""
    name_counts: dict[str, int] = defaultdict(int)
    for ct in tracks:
        name = ct.artist_name_canonical.strip()
        if name:
            name_counts[name] += 1
    if not name_counts:
        return tracks[0].input_artist if tracks else ""
    return max(name_counts, key=lambda n: name_counts[n])
