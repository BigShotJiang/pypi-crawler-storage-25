"""
End-to-end v2 discovery pipeline orchestrator.

Implements the full Human Logic Proposal flow in a single function:

    InputTrack list
    → canonicalize (§2–3)
    → build seed weights (§4)
    → expand artist graph (§5–6)
    → fetch & filter candidate releases (§7–8)
    → score candidates (§9–10)
    → enrich tracks (Spotify + MusicBrainz + ISRC fallback)
    → build explanations (§11)
    → return list[ReleaseRecommendation] ready for existing output pipeline

Called from workflow.run_discover() as the default and only discovery pipeline.
"""

from __future__ import annotations

import concurrent.futures
import math
from typing import Any

from .canonicalization import resolve_tracks
from .deduplication import deduplicate_recommendation_tracks, deduplicate_recommendations
from .enrichment import enrich_recommendation_tracks
from .explanation import build_fallback_notice, scored_to_recommendation
from .graph_expansion import ExpandedGraph, TIER_FACTORS, expand_graph
from .models import ArtistSeed, CandidateArtist, GraphEdge, InputTrack, ReleaseRecommendation, TasteProfile
from .progress import NoOpProgressReporter, ProgressReporter
from .discovery_window import DiscoveryWindow
from .release_discovery import (
    CandidateRelease,
    annotate_artist_window_release_counts,
    fetch_candidates,
    fetch_label_affinity_candidates,
)
from .scoring_v2 import score_candidates
from .utils import normalize_key, normalize_variant_title
from .seed_weights import build_artist_seeds

HIGH_PRIORITY_TIERS = {"Tier 1", "Tier 2A", "Tier 2B"}
LOW_PRIORITY_TIERS = {"Tier 3", "Tier 4"}
MAX_TIER4_SHARE = 0.25


def run_v2_pipeline(
    input_tracks: list[InputTrack],
    musicbrainz: Any | None = None,
    listenbrainz: Any | None = None,
    lastfm: Any | None = None,
    spotify: Any | None = None,
    deezer: Any | None = None,
    tidal: Any | None = None,
    heard_release_group_mbids: set[str] | None = None,
    window_days: int = 183,
    limit: int = 100,
    deep_cuts: bool = False,
    tiered_results: bool = False,
    allow_compilations: bool = False,
    allow_live: bool = False,
    emit: Any = None,
    isrc_resolver: Any | None = None,
    max_tracks: int = 3,
    seed_track_keys: set[str] | None = None,
    profile: TasteProfile | None = None,
    storage: Any | None = None,
    force_refresh: bool = False,
    penalize_frequent_artists: bool = False,
    max_candidates: int = 0,
    min_seed_weight: float = 0.20,
    progress: ProgressReporter | None = None,
    discovery_window: DiscoveryWindow | None = None,
    run_deduplication: bool = True,
    excluded_artist_keys: set[str] | None = None,
    use_streaming_providers: bool = False,
    debug: bool = False,
    adaptive_small_seed_mode: bool = True,
    refill_after_heard: bool = True,
    expansion_memory_seeds: list[dict[str, Any]] | None = None,
    shortage_refill_continue_callback: Any | None = None,
) -> list[ReleaseRecommendation]:
    """
    Run the full v2 discovery pipeline.

    Args:
        input_tracks: Raw input tracks (from mamonia.input parsers).
        musicbrainz: MusicBrainzProvider instance.
        listenbrainz: ListenBrainzProvider instance.
        lastfm: LastFmProvider instance.
        spotify: SpotifyProvider instance (used in canonicalization).
        deezer: DeezerProvider instance (used in canonicalization).
        tidal: TidalProvider instance (used for streaming fallback discovery).
        heard_release_group_mbids: MBIDs of already-heard releases to exclude.
        window_days: Temporal filter window (default 183 ≈ 6 months).
        limit: Maximum number of recommendations to return.
        deep_cuts: If True, include low-score Tier 4 / tag-only recommendations.
        tiered_results: If True, apply balanced/diverse sampling.
        allow_compilations: Pass through to fetch_candidates.
        allow_live: Pass through to fetch_candidates.
        emit: Optional callable for progress messages (e.g. print).
        isrc_resolver: ISRCResolver instance for ISRC resolution via Tidal/Deezer.
        max_tracks: Maximum number of tracks per release (default 3).
        seed_track_keys: Set of track keys to exclude from recommendations.
        profile: Optional saved taste profile. Used only for Tier 3 label affinity.
        storage: Optional durable storage for canonical-track cache.
        force_refresh: If True, bypass canonical cache and rewrite entries.
        penalize_frequent_artists: If True, reduce tracks per release for artists
            with many recent EPs/singles in the active window.
        max_candidates: Maximum graph artists to consider for release discovery.
            0 means unlimited; Tier 1 seed artists are always retained.
        min_seed_weight: Minimum normalized seed weight required to remain
            Tier 1. Range is clamped to [0.0, 1.0]. If every seed is filtered,
            the top seed is retained as a safety fallback.
        progress: Optional progress reporter used to show the default stopwatch.

    Returns:
        List of ReleaseRecommendation objects sorted by score descending.
    """
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)
    progress = progress or NoOpProgressReporter()
    heard_diag: dict[str, int] = {
        "excluded_by_mbid": 0,
        "excluded_by_spotify_album": 0,
        "excluded_by_fallback_title": 0,
        "not_excluded": 0,
    }
    reason_key_map = {
        "mbid": "excluded_by_mbid",
        "spotify_album": "excluded_by_spotify_album",
        "fallback_title": "excluded_by_fallback_title",
    }

    # --- Step 1: Canonicalize input tracks ---
    canonical_total = sum(max(1, len(track.all_artist_names())) for track in input_tracks)
    progress.stage_started("Canonicalizing input tracks", processed=0, total=canonical_total)
    _emit("Canonicalizing input tracks…")
    canonical_cache_stats = {"hits": 0, "misses": 0}
    canonical_tracks = resolve_tracks(
        input_tracks,
        musicbrainz=musicbrainz,
        spotify=spotify,
        deezer=deezer,
        storage=storage,
        force_refresh=force_refresh,
        cache_stats=canonical_cache_stats,
        progress_callback=lambda track, processed, total: progress.candidate_started(
            CandidateArtist(name=track.artist or track.track or "Unknown", source="canonicalization", score=0.0),
            processed,
            total,
        ),
    )
    _with_mbids = sum(1 for ct in canonical_tracks if ct.artist_mbid)
    _v2_emit(f"[v2] Canonicalized {len(canonical_tracks)} tracks ({_with_mbids} with artist MBID).")
    if storage is not None:
        _v2_emit(
            "[v2] Canonical cache: "
            f"hits={canonical_cache_stats['hits']} misses={canonical_cache_stats['misses']}"
        )
    for ct in canonical_tracks:
        _v2_emit(f"[v2]   track='{ct.input_track}' artist='{ct.input_artist}' mbid={ct.artist_mbid} method={ct.resolution_method}")
    if not canonical_tracks:
        return []

    # --- Step 2: Build seed weights ---
    progress.stage_started("Computing seed weights")
    _emit("Computing seed weights…")
    all_seeds = build_artist_seeds(canonical_tracks)
    seeds = all_seeds
    min_seed_weight = max(0.0, min(1.0, float(min_seed_weight)))
    original_seed_count = len(all_seeds)
    if min_seed_weight > 0:
        seeds = [s for s in all_seeds if s.seed_weight >= min_seed_weight]
        if not seeds and original_seed_count > 0:
            fallback_seed = max(all_seeds, key=lambda s: s.seed_weight)
            seeds = [fallback_seed]
        if len(seeds) != original_seed_count:
            _v2_emit(
                "[v2] Seed threshold: "
                f"kept {len(seeds)}/{original_seed_count} seed(s) "
                f"(min_seed_weight={min_seed_weight:.3f})."
            )
    _seeds_with_mbids = sum(1 for s in seeds if s.artist_mbid)
    _v2_emit(f"[v2] Built {len(seeds)} seed(s) ({_seeds_with_mbids} with artist MBID).")
    for s in seeds:
        _v2_emit(f"[v2]   seed='{s.canonical_name}' mbid={s.artist_mbid} weight={s.seed_weight:.3f}")
    if not seeds:
        return []

    if expansion_memory_seeds:
        for mem in expansion_memory_seeds:
            name = str(mem.get("artist_name") or "").strip()
            if not name:
                continue
            key = normalize_key(name)
            if any(normalize_key(s.canonical_name) == key for s in seeds):
                continue
            seeds.append(
                ArtistSeed(
                    canonical_name=name,
                    artist_mbid=None,
                    seed_weight=0.18,
                    source_frequency=1,
                    unique_track_count=1,
                    unique_release_count=1,
                    match_confidence_avg=0.7,
                )
            )

    # --- Step 3: Fetch seed tags for tier assignment ---
    progress.stage_started("Fetching seed tags", processed=0, total=len(seeds))
    seed_tags = _fetch_seed_tags(seeds, lastfm=lastfm, musicbrainz=musicbrainz)
    _tagged = sum(1 for t in seed_tags.values() if t)
    _total_tags = sum(len(t) for t in seed_tags.values())
    _v2_emit(f"[v2] Seed tags: {_tagged}/{len(seeds)} seeds with tags ({_total_tags} total).")

    # --- Step 4: Expand artist graph ---
    progress.stage_started("Expanding artist graph", processed=0, total=len(seeds))
    _emit(f"Expanding graph from {len(seeds)} seed artist(s)…")
    graph = expand_graph(
        seeds,
        musicbrainz=musicbrainz,
        listenbrainz=listenbrainz,
        lastfm=lastfm,
        seed_tags=seed_tags,
        emit=_emit,
        progress=progress,
        debug=debug,
    )

    if max_candidates > 0:
        before_artists = len(graph.artist_tiers)
        graph = _limit_graph_artists(graph, seeds=seeds, max_artists=max_candidates)
        after_artists = len(graph.artist_tiers)
        if after_artists < before_artists:
            _emit(f"Limited graph artists from {before_artists} to {after_artists}.")

    if excluded_artist_keys:
        before_artists = len(graph.artist_tiers)
        filtered_tiers = {artist: tier for artist, tier in graph.artist_tiers.items() if normalize_key(artist) not in excluded_artist_keys}
        filtered_names = {artist: name for artist, name in graph.artist_names.items() if artist in filtered_tiers}
        filtered_edges = [edge for edge in graph.edges if (edge.source_artist_mbid or edge.source_artist_name.lower()) in filtered_tiers and (edge.target_artist_mbid or edge.target_artist_name.lower()) in filtered_tiers]
        graph.artist_tiers = filtered_tiers
        graph.artist_names = filtered_names
        graph.edges = filtered_edges
        after_artists = len(graph.artist_tiers)
        if after_artists < before_artists:
            _emit(f"Filtered excluded artists: {before_artists} → {after_artists} artists in graph.")

    _tier_counts_raw = {}
    for t in graph.artist_tiers.values():
        _tier_counts_raw[t] = _tier_counts_raw.get(t, 0) + 1
    tier_order = ("Tier 1", "Tier 2A", "Tier 2B", "Tier 3", "Tier 4")
    _tier_counts = {tier: _tier_counts_raw[tier] for tier in tier_order if tier in _tier_counts_raw}
    for tier, count in _tier_counts_raw.items():
        if tier not in _tier_counts:
            _tier_counts[tier] = count
    _v2_emit(f"[v2] Graph tiers: {_tier_counts}")

    # --- Step 5: Fetch and filter candidate releases ---
    progress.stage_started(
        "Fetching candidate releases",
        processed=0,
        total=len(graph.artist_tiers),
    )
    _emit(f"Fetching candidate releases ({len(graph.artist_tiers)} artists in graph)…")
    is_tiny_seed = adaptive_small_seed_mode and len(input_tracks) <= 3
    phase_a_artist_scan_cap = 0
    if is_tiny_seed:
        phase_a_artist_scan_cap = min(max(12, limit * 2), 40)
    phase_a_artist_tiers = {key: tier for key, tier in graph.artist_tiers.items() if tier in HIGH_PRIORITY_TIERS}
    phase_a_artist_names = {key: name for key, name in graph.artist_names.items() if key in phase_a_artist_tiers}
    candidates = fetch_candidates(
        artist_tiers=phase_a_artist_tiers,
        artist_names=phase_a_artist_names,
        musicbrainz=musicbrainz,
        heard_release_group_mbids=heard_release_group_mbids,
        window_days=window_days,
        allow_compilations=allow_compilations,
        allow_live=allow_live,
        emit=_emit,
        progress=progress,
        debug=debug,
        window_start_date=discovery_window.start_date if discovery_window else None,
        window_end_date=discovery_window.end_date if discovery_window else None,
        allowed_tiers=HIGH_PRIORITY_TIERS,
        max_artists_to_scan=phase_a_artist_scan_cap,
    )
    _tier_cand_counts = {}
    for c in candidates:
        _tier_cand_counts[c.tier] = _tier_cand_counts.get(c.tier, 0) + 1
    _v2_emit(f"[v2] Fetched {len(candidates)} candidate(s) by tier: {_tier_cand_counts}")

    deezer_available = bool(deezer and getattr(deezer, "available", False))
    tidal_available = bool(tidal and getattr(tidal, "available", False))
    effective_use_streaming = bool(use_streaming_providers) or is_tiny_seed
    if not effective_use_streaming:
        _emit("[Streaming] Skipped: --use-streaming-providers not enabled")
    elif not (deezer_available or tidal_available):
        _emit(
            "[Streaming] Skipped: no providers available "
            f"(deezer={deezer_available}, tidal={tidal_available})"
        )
    else:
        _emit("Searching streaming providers for artists not found in MusicBrainz…")
        streaming_candidates = _fetch_streaming_provider_candidates(
            artist_tiers=phase_a_artist_tiers,
            artist_names=phase_a_artist_names,
            deezer=deezer,
            tidal=tidal,
            window_days=window_days,
            window_start_date=discovery_window.start_date if discovery_window else None,
            window_end_date=discovery_window.end_date if discovery_window else None,
            emit=_emit,
            debug=debug,
        )
        if streaming_candidates:
            candidates.extend(streaming_candidates)
            _emit(f"Added {len(streaming_candidates)} candidate(s) via streaming provider fallback.")

    # Shortage expansion: provider-budgeted rounds (MB/LB/Last.fm) with
    # spillover enabled only after first provider pass.
    shortage_target = max(limit + max(2, int(limit * 0.2)), limit)
    shortage_round_stats: list[dict[str, Any]] = []
    if len(candidates) < shortage_target:
        shortage_added, shortage_round_stats = _run_provider_budgeted_shortage_expansion(
            existing_candidates=candidates,
            graph=graph,
            seeds=seeds,
            musicbrainz=musicbrainz,
            listenbrainz=listenbrainz,
            lastfm=lastfm,
            heard_release_group_mbids=heard_release_group_mbids,
            window_days=window_days,
            allow_compilations=allow_compilations,
            allow_live=allow_live,
            discovery_window=discovery_window,
            emit=_emit,
            debug=debug,
            shortage_target=shortage_target,
            max_rounds=3,
            provider_weights={"musicbrainz": 0.30, "listenbrainz": 0.30, "lastfm": 0.40},
            per_artist_round_cap=2,
            tiny_seed_mode=is_tiny_seed,
            include_tier4=True,
        )
        if shortage_added:
            by_key: dict[tuple[str, str, str], CandidateRelease] = {
                (c.release_group_mbid, c.artist_name, c.release_date): c for c in candidates
            }
            added_unique = 0
            for candidate in shortage_added:
                key = (candidate.release_group_mbid, candidate.artist_name, candidate.release_date)
                if key in by_key:
                    continue
                by_key[key] = candidate
                added_unique += 1
            if added_unique:
                candidates = list(by_key.values())
                annotate_artist_window_release_counts(candidates)
                _emit(f"Shortage expansion added {added_unique} candidate(s).")

    label_candidates = _fetch_label_affinity_candidates(
        profile=profile,
        seeds=seeds,
        musicbrainz=musicbrainz,
        heard_release_group_mbids=heard_release_group_mbids,
        existing_release_group_mbids={c.release_group_mbid for c in candidates},
        window_days=window_days,
        allow_compilations=allow_compilations,
        allow_live=allow_live,
        emit=_emit,
        discovery_window=discovery_window,
    )
    if label_candidates:
        label_edges = _label_affinity_edges(label_candidates, seeds=seeds, profile=profile)
        candidates.extend(label_candidates)
        annotate_artist_window_release_counts(candidates)
        graph.edges.extend(label_edges)
        _emit(f"Added {len(label_candidates)} Tier 3 label-affinity candidate(s).")
        _v2_emit(f"[v2] Label affinity: candidates={len(label_candidates)}, edges={len(label_edges)}")
    else:
        _v2_emit("[v2] Label affinity: candidates=0")

    if not candidates:
        return []

    # --- Step 6: Score candidates ---
    progress.stage_started("Scoring candidate releases", processed=0, total=len(candidates))
    scored = score_candidates(
        candidates=candidates,
        seeds=seeds,
        edges=graph.edges,
        emit=_emit,
    )
    scored_before_lb_guard = len(scored)
    scored = [sr for sr in scored if _passes_listenbrainz_evidence_guard(sr)]
    if debug and len(scored) != scored_before_lb_guard:
        _v2_emit(
            f"[v2] listenbrainz evidence guard filtered "
            f"{scored_before_lb_guard - len(scored)} candidate(s)."
        )
    scored_candidates = len(scored)
    # Per-artist score summary
    _artist_score_summary: dict[str, dict] = {}
    for sr in scored:
        artist = sr.candidate.artist_name
        if artist not in _artist_score_summary:
            _artist_score_summary[artist] = {"count": 0, "best_norm": 0.0, "best_raw": 0.0}
        _artist_score_summary[artist]["count"] += 1
        _artist_score_summary[artist]["best_norm"] = max(_artist_score_summary[artist]["best_norm"], sr.score_normalized)
        _artist_score_summary[artist]["best_raw"] = max(_artist_score_summary[artist]["best_raw"], sr.final_score)
    for artist in sorted(_artist_score_summary.keys()):
        s = _artist_score_summary[artist]
        _v2_emit(f"[v2] scored: artist='{artist}' candidates={s['count']} best_norm={s['best_norm']:.1f} best_raw={s['best_raw']:.4f}")
    # --- Step 7: Apply limit/selection mode ---
    recommendations = _select_scored_releases(
        scored,
        limit=limit,
        deep_cuts=deep_cuts,
        balanced=tiered_results,
        emit=_emit,
    )
    recommendations = _enforce_tier4_share_cap(
        selected=recommendations,
        all_scored=scored,
        limit=limit,
        max_share=MAX_TIER4_SHARE,
    )
    if tiered_results:
        recommendations = _enforce_tier1_share_cap(
            selected=recommendations,
            all_scored=scored,
            limit=limit,
            max_share=0.65,
        )
    recommendations = _enforce_artist_share_cap(
        selected=recommendations,
        all_scored=scored,
        limit=limit,
        balanced=tiered_results,
    )
    _rec_artist_counts: dict[str, int] = {}
    for rec in recommendations:
        _rec_artist_counts[rec.artist] = _rec_artist_counts.get(rec.artist, 0) + 1
    _v2_emit(f"[v2] selected: {_rec_artist_counts}")
    selected_before_heard = len(recommendations)
    # Capture a stable snapshot before enrichment mutates progress counters.
    if hasattr(progress, "summary"):
        try:
            setattr(progress, "_mamonia_discovery_summary", progress.summary())
        except Exception:
            pass

    # --- Step 8: Enrich recommendations with tracks (Spotify + MusicBrainz + ISRC fallback) ---
    # Note: This runs AFTER candidate selection, so we only enrich the selected recommendations
    progress.stage_started(
        "Enriching recommendation tracks",
        processed=0,
        total=len(recommendations),
    )
    _emit(f"Enriching {len(recommendations)} recommendation(s) with tracks…")
    heard_filtered_recommendations: list[ReleaseRecommendation] = []
    heard_excluded_keys: set[tuple[str, str, str]] = set()
    dropped_by_heard = 0
    for processed, rec in enumerate(recommendations, start=1):
        heard_reason_before = (
            storage.heard_match_reason_recommendation(rec)
            if storage is not None and hasattr(storage, "heard_match_reason_recommendation")
            else None
        )
        if heard_reason_before:
            reason_key = reason_key_map.get(heard_reason_before)
            if reason_key:
                heard_diag[reason_key] += 1
            progress.release_group_skipped(f"heard-{heard_reason_before}")
            _v2_emit(
                f"[v2] heard excluded before enrich: {rec.artist} - {rec.title} "
                f"(reason={heard_reason_before})"
            )
            heard_excluded_keys.add((normalize_key(rec.artist), normalize_key(rec.title), rec.release_date))
            dropped_by_heard += 1
            continue
        progress.candidate_started(
            CandidateArtist(name=rec.artist, source="v2-recommendation", score=rec.score),
            processed,
            len(recommendations),
        )
        effective_max_tracks = _effective_max_tracks(
            max_tracks,
            release_count=rec.artist_window_release_count,
            penalize_frequent_artists=penalize_frequent_artists,
        )
        enrich_recommendation_tracks(
            rec,
            spotify=spotify if spotify and spotify.available else None,
            musicbrainz=musicbrainz,
            listenbrainz=listenbrainz if listenbrainz and getattr(listenbrainz, "available", False) else None,
            lastfm=lastfm if lastfm and getattr(lastfm, "available", False) else None,
            isrc_resolver=isrc_resolver,
            max_tracks=effective_max_tracks,
            seed_track_keys=seed_track_keys,
        )
        heard_reason_after = (
            storage.heard_match_reason_recommendation(rec)
            if storage is not None and hasattr(storage, "heard_match_reason_recommendation")
            else None
        )
        if heard_reason_after:
            reason_key = reason_key_map.get(heard_reason_after)
            if reason_key:
                heard_diag[reason_key] += 1
            progress.release_group_skipped(f"heard-after-enrichment-{heard_reason_after}")
            _v2_emit(
                f"[v2] heard excluded after enrich: {rec.artist} - {rec.title} "
                f"(reason={heard_reason_after})"
            )
            heard_excluded_keys.add((normalize_key(rec.artist), normalize_key(rec.title), rec.release_date))
            dropped_by_heard += 1
            continue
        heard_diag["not_excluded"] += 1
        _v2_emit(f"[v2] heard pass: {rec.artist} - {rec.title}")
        heard_filtered_recommendations.append(rec)
        progress.release_accepted(rec)
    if storage is not None:
        setattr(storage, "_last_heard_discovery_diagnostics", heard_diag)
        sparsity = getattr(storage, "heard_row_sparsity", None)
        if callable(sparsity):
            setattr(storage, "_last_heard_row_sparsity", sparsity())
    if debug:
        _emit(
            "[Heard] excluded_total={total} (mbid={mbid}, spotify={spotify}, fallback={fallback}); passed={passed}".format(
                total=heard_diag["excluded_by_mbid"] + heard_diag["excluded_by_spotify_album"] + heard_diag["excluded_by_fallback_title"],
                mbid=heard_diag["excluded_by_mbid"],
                spotify=heard_diag["excluded_by_spotify_album"],
                fallback=heard_diag["excluded_by_fallback_title"],
                passed=heard_diag["not_excluded"],
            )
        )
    recommendations = heard_filtered_recommendations
    if spotify and hasattr(spotify, "_mamonia_enrichment_state"):
        enrich_state = getattr(spotify, "_mamonia_enrichment_state") or {}
        _v2_emit(
        "[v2] Enrichment budgets: "
            f"spotify_used={enrich_state.get('used', 0)} "
            f"spotify_budget={enrich_state.get('budget', 0)} "
            f"spotify_budget_exhausted={bool(enrich_state.get('budget_exhausted', False))} "
            f"rescue_disabled_due_to_429={bool(enrich_state.get('rescue_disabled_due_to_429', False))}"
        )

    # --- Step 9: Deduplicate tracks across recommendations ---
    if run_deduplication:
        progress.stage_started(
            "Deduplicating recommendation tracks",
            processed=len(recommendations),
            total=len(recommendations),
        )
        _emit(f"Deduplicating tracks across {len(recommendations)} recommendation(s)…")
        before_dedup_count = len(recommendations)
        recommendations = deduplicate_recommendation_tracks(recommendations, emit=_emit, progress_reporter=progress, debug=debug)
        dropped_by_track_dedup = max(0, before_dedup_count - len(recommendations))
    else:
        dropped_by_track_dedup = 0

    # --- Step 10: Deduplicate releases (same artist/title/month with >95% track overlap) ---
    if len(recommendations) > 1:
        # Diagnostic: dump track keys before release dedup
        if debug:
            import json
            from pathlib import Path
            from datetime import datetime
            try:
                diag_data = []
                for i, rec in enumerate(recommendations):
                    tracks_data = []
                    for t in rec.tracks:
                        tracks_data.append({
                            "title": t.title,
                            "spotify_track_id": t.spotify_track_id,
                            "isrc": t.isrc
                        })
                    diag_data.append({
                        "index": i,
                        "artist": rec.artist,
                        "album": rec.title,
                        "release_date": rec.release_date,
                        "track_count": len(rec.tracks),
                        "tracks": tracks_data
                    })
                diag_file = Path(f"dedup_diagnostics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
                with open(diag_file, "w", encoding="utf-8") as f:
                    json.dump(diag_data, f, indent=2, ensure_ascii=False)
                _v2_emit(f"[v2] Diagnostic track keys dumped to {diag_file}")
            except Exception as e:
                _v2_emit(f"[v2] Diagnostic track dump failed: {e}")

        recommendations = deduplicate_recommendations(recommendations, emit=_emit, debug=debug)

    refill_attempted = 0
    refill_added = 0
    refill_exhausted = False
    shortage_fallback_triggered = False
    fallback_memory_candidates: list[dict[str, Any]] = []
    if refill_after_heard and len(recommendations) < limit:
        shortage_fallback_triggered = True
        selected_keys = {(normalize_key(rec.artist), normalize_key(rec.title), rec.release_date) for rec in recommendations}
        refill_pool = []
        refill_pool_scored = []
        for sr in scored:
            rec = scored_to_recommendation(sr)
            key = (normalize_key(rec.artist), normalize_key(rec.title), rec.release_date)
            if key in selected_keys:
                continue
            if key in heard_excluded_keys:
                continue
            refill_pool.append(rec)
            refill_pool_scored.append(sr)
        refill_attempted = len(refill_pool)
        for sr in refill_pool_scored:
            conn_types = [str(v) for v in (sr.explanation.get("connection_types") or []) if v]
            provider = "unknown"
            if any("lastfm" in v.lower() for v in conn_types):
                provider = "lastfm"
            elif any("listenbrainz" in v.lower() for v in conn_types):
                provider = "listenbrainz"
            elif any("musicbrainz" in v.lower() for v in conn_types):
                provider = "musicbrainz"
            fallback_memory_candidates.append(
                {
                    "artist_name": sr.candidate.artist_name,
                    "provider": provider,
                    "tier": sr.candidate.tier,
                    "confidence": float(sr.score_normalized),
                    "score": float(sr.final_score),
                    "evidence": {
                        "connection_types": conn_types[:5],
                        "seed_artists": [str(v) for v in (sr.explanation.get("seed_artists") or [])[:5] if v],
                    },
                }
            )
        for rec in _diversity_order_refill_pool(refill_pool, recommendations):
            if len(recommendations) >= limit:
                break
            if storage is not None and hasattr(storage, "heard_match_reason_recommendation"):
                heard_reason = storage.heard_match_reason_recommendation(rec)
                if heard_reason:
                    continue
            recommendations.append(rec)
            selected_keys.add((normalize_key(rec.artist), normalize_key(rec.title), rec.release_date))
            refill_added += 1
        refill_exhausted = len(recommendations) < limit

    # Iterative broaden-and-refill fallback: keep going until we fill or exhaust.
    if len(recommendations) < limit:
        shortage_fallback_triggered = True
        selected_keys = {(normalize_key(rec.artist), normalize_key(rec.title), rec.release_date) for rec in recommendations}
        for broaden_round in range(1, 4):
            if len(recommendations) >= limit:
                break
            broaden_candidates = _fetch_iterative_broaden_candidates(
                seeds=seeds,
                seed_tags=seed_tags,
                musicbrainz=musicbrainz,
                listenbrainz=listenbrainz,
                lastfm=lastfm,
                heard_release_group_mbids=heard_release_group_mbids,
                window_days=window_days,
                allow_compilations=allow_compilations,
                allow_live=allow_live,
                discovery_window=discovery_window,
                emit=_emit,
                debug=debug,
                round_idx=broaden_round,
                include_tier4=True,
            )
            if not broaden_candidates:
                continue
            extra_scored = score_candidates(
                candidates=broaden_candidates,
                seeds=seeds,
                edges=graph.edges,
                emit=_emit,
            )
            extra_attempted = 0
            extra_added = 0
            for sr in extra_scored:
                if len(recommendations) >= limit:
                    break
                rec = scored_to_recommendation(sr)
                key = (normalize_key(rec.artist), normalize_key(rec.title), rec.release_date)
                if key in selected_keys or key in heard_excluded_keys:
                    continue
                extra_attempted += 1
                enrich_recommendation_tracks(
                    rec,
                    spotify=spotify if spotify and spotify.available else None,
                    musicbrainz=musicbrainz,
                    listenbrainz=listenbrainz if listenbrainz and getattr(listenbrainz, "available", False) else None,
                    lastfm=lastfm if lastfm and getattr(lastfm, "available", False) else None,
                    isrc_resolver=isrc_resolver,
                    max_tracks=max_tracks,
                    seed_track_keys=seed_track_keys,
                )
                if storage is not None and hasattr(storage, "heard_match_reason_recommendation"):
                    heard_reason = storage.heard_match_reason_recommendation(rec)
                    if heard_reason:
                        continue
                recommendations.append(rec)
                selected_keys.add(key)
                extra_added += 1
                fallback_memory_candidates.append(
                    {
                        "artist_name": sr.candidate.artist_name,
                        "provider": str(sr.candidate.streaming_provider or "broaden"),
                        "tier": sr.candidate.tier,
                        "confidence": float(sr.score_normalized),
                        "score": float(sr.final_score),
                        "evidence": {
                            "connection_types": [f"iterative-broaden-round:{broaden_round}"],
                            "seed_artists": [str(v) for v in (sr.explanation.get("seed_artists") or [])[:5] if v],
                        },
                    }
                )
            refill_attempted += extra_attempted
            refill_added += extra_added
            if extra_added == 0:
                continue
            if len(recommendations) < limit and shortage_refill_continue_callback is not None:
                try:
                    proceed = shortage_refill_continue_callback(broaden_round, len(recommendations), limit)
                except Exception:
                    proceed = True
                if proceed is False:
                    break
        refill_exhausted = len(recommendations) < limit

    # Final normalized release dedup safety pass (handles artist/title casing variants).
    recommendations = _final_normalized_release_dedup(recommendations)

    if storage is not None:
        setattr(
            storage,
            "_last_pipeline_counters",
            {
                "scored_candidates": scored_candidates,
                "selected_before_heard": selected_before_heard,
                "dropped_by_heard": dropped_by_heard,
                "dropped_by_track_dedup": dropped_by_track_dedup,
                "refill_attempted": refill_attempted,
                "refill_added": refill_added,
                "refill_exhausted": refill_exhausted,
                "shortage_fallback_triggered": shortage_fallback_triggered,
                "fallback_memory_candidates": fallback_memory_candidates,
                "shortage_round_stats": shortage_round_stats,
                "shortage_target": shortage_target,
                "shortage_rounds_used": len(shortage_round_stats),
            },
        )

    if debug and len(recommendations) < limit:
        _emit(
            f"[v2] low-output diagnostics: returned={len(recommendations)}/{limit}; "
            f"selected_before_heard={selected_before_heard}; dropped_by_heard={dropped_by_heard}; "
            f"dropped_by_track_dedup={dropped_by_track_dedup}; refill_added={refill_added}/{refill_attempted}"
        )

    _emit(f"Returning {len(recommendations)} recommendation(s).")
    return recommendations


def _diversity_order_refill_pool(
    refill_pool: list[ReleaseRecommendation],
    existing: list[ReleaseRecommendation],
) -> list[ReleaseRecommendation]:
    """Order refill candidates to prefer underrepresented artists first.

    Preserves recommendation integrity while reducing over-concentration around a
    tiny artist cluster in Balanced refill scenarios.
    """
    if not refill_pool:
        return refill_pool
    counts: dict[str, int] = {}
    for rec in existing:
        key = normalize_key(rec.artist or "")
        counts[key] = counts.get(key, 0) + 1
    indexed = list(enumerate(refill_pool))
    ordered: list[ReleaseRecommendation] = []
    while indexed:
        best_idx = 0
        best_tuple = None
        for i, (orig_idx, rec) in enumerate(indexed):
            key = normalize_key(rec.artist or "")
            rank = (counts.get(key, 0), orig_idx)
            if best_tuple is None or rank < best_tuple:
                best_tuple = rank
                best_idx = i
        orig_idx, chosen = indexed.pop(best_idx)
        ordered.append(chosen)
        key = normalize_key(chosen.artist or "")
        counts[key] = counts.get(key, 0) + 1
    return ordered


def _fetch_streaming_provider_candidates(
    artist_tiers: dict[str, str],
    artist_names: dict[str, str],
    deezer: Any | None = None,
    tidal: Any | None = None,
    window_days: int = 0,
    window_start_date: Any = None,
    window_end_date: Any = None,
    emit: Any = None,
    debug: bool = False,
) -> list[CandidateRelease]:
    """Fetch candidates from Deezer and Tidal, then cross-check the results.

    Both providers run independently per artist — a failure in one must not
    suppress the other. After collection, releases that appear from both
    providers are merged into a single candidate; Tidal wins ties because it
    is treated as the source of truth for catalogue completeness.
    """
    _emit = emit or (lambda *_: None)
    _debug_emit = _emit if debug else (lambda *_: None)
    deezer_available = bool(deezer and getattr(deezer, "available", False))
    tidal_available = bool(tidal and getattr(tidal, "available", False))

    if not (deezer_available or tidal_available):
        _emit("[Streaming] No available streaming providers for fallback")
        return []

    _emit(
        f"[Streaming] Searching {len(artist_names)} artist(s) on "
        f"{'Deezer+Tidal' if deezer_available and tidal_available else ('Deezer' if deezer_available else 'Tidal')}"
    )

    deezer_hits: dict[tuple[str, str, str], CandidateRelease] = {}
    tidal_hits: dict[tuple[str, str, str], CandidateRelease] = {}

    for artist_key, artist_name in artist_names.items():
        tier = artist_tiers.get(artist_key, "Tier 3")

        if deezer_available:
            try:
                _collect_deezer_artist_releases(
                    artist_key=artist_key,
                    artist_name=artist_name,
                    tier=tier,
                    deezer=deezer,
                    window_start_date=window_start_date,
                    window_end_date=window_end_date,
                    out=deezer_hits,
                    emit=_debug_emit,
                )
            except Exception as exc:
                _emit(f"[Deezer] Error while searching '{artist_name}': {exc}")

        if tidal_available:
            try:
                _collect_tidal_artist_releases(
                    artist_key=artist_key,
                    artist_name=artist_name,
                    tier=tier,
                    tidal=tidal,
                    window_start_date=window_start_date,
                    window_end_date=window_end_date,
                    out=tidal_hits,
                    emit=_debug_emit,
                )
            except Exception as exc:
                _emit(f"[Tidal] Error while searching '{artist_name}': {exc}")

    candidates, corroborated = _merge_streaming_provider_hits(deezer_hits, tidal_hits)
    _emit(
        f"[Streaming] Complete: {len(candidates)} fallback candidate(s) added "
        f"(deezer={len(deezer_hits)}, tidal={len(tidal_hits)}, corroborated={corroborated})"
    )
    return candidates


def _collect_deezer_artist_releases(
    *,
    artist_key: str,
    artist_name: str,
    tier: str,
    deezer: Any,
    window_start_date: Any,
    window_end_date: Any,
    out: dict[tuple[str, str, str], CandidateRelease],
    emit: Any,
) -> None:
    from datetime import date

    deezer_artist = deezer.search_artist(artist_name)
    if not deezer_artist:
        return
    deezer_artist_id = deezer_artist.get("id")
    emit(f"[Deezer] Found '{artist_name}' in Deezer (ID: {deezer_artist_id})")
    albums = deezer.browse_artist_albums(deezer_artist_id) or []
    for album in albums:
        record_type = (album.get("record_type") or "album").lower()
        if record_type not in {"album", "ep", "single"}:
            continue
        release_date_str = album.get("release_date") or ""
        if not release_date_str:
            continue
        try:
            # Handle both date-only (2008-01-01) and datetime (2008-01-01 00:00:00) formats
            if ' ' in release_date_str:
                # Datetime format: extract date part
                date_part = release_date_str.split(' ')[0]
                release_date = date.fromisoformat(date_part)
                # Normalize release_date_str to date-only format for consistency
                release_date_str = date_part
            else:
                release_date = date.fromisoformat(release_date_str)
        except (ValueError, TypeError):
            continue
        if window_start_date and release_date < window_start_date:
            continue
        if window_end_date and release_date > window_end_date:
            continue

        title = album.get("title") or "Unknown"
        cross_key = (artist_key, normalize_key(title), release_date_str)
        if cross_key in out:
            continue

        candidate = CandidateRelease(
            release_group_mbid="",
            artist_mbid=None,
            artist_name=artist_name,
            title=title,
            release_date=release_date_str,
            primary_type=record_type,
            secondary_types=[],
            label=None,
            tier=tier,
        )
        candidate.streaming_only_id = f"deezer-album:{album.get('id', '')}"
        candidate.streaming_provider = "deezer"
        out[cross_key] = candidate


def _collect_tidal_artist_releases(
    *,
    artist_key: str,
    artist_name: str,
    tier: str,
    tidal: Any,
    window_start_date: Any,
    window_end_date: Any,
    out: dict[tuple[str, str, str], CandidateRelease],
    emit: Any,
) -> None:
    from datetime import date

    tidal_albums = tidal.search_artist_albums(artist_name) or []
    if not tidal_albums:
        emit(f"[Tidal] 0 album(s) found for '{artist_name}'")
        return
    emit(f"[Tidal] Found {len(tidal_albums)} album(s) for '{artist_name}' in Tidal")
    added = 0
    for album in tidal_albums:
        release_date_str = album.get("release_date") or ""
        title = album.get("title") or "Unknown"
        if not release_date_str:
            emit(f"[Tidal]   {title}: skipped (no date)")
            continue
        try:
            # Handle both date-only (2008-01-01) and datetime (2008-01-01 00:00:00) formats
            if ' ' in release_date_str:
                # Datetime format: extract date part
                date_part = release_date_str.split(' ')[0]
                release_date = date.fromisoformat(date_part)
                # Normalize release_date_str to date-only format for consistency
                release_date_str = date_part
            else:
                release_date = date.fromisoformat(release_date_str)
        except (ValueError, TypeError):
            emit(f"[Tidal]   {title} ({release_date_str}): skipped (invalid date)")
            continue
        if window_start_date and release_date < window_start_date:
            emit(f"[Tidal]   {title} ({release_date_str}): skipped (before window)")
            continue
        if window_end_date and release_date > window_end_date:
            emit(f"[Tidal]   {title} ({release_date_str}): skipped (after window)")
            continue

        cross_key = (artist_key, normalize_key(title), release_date_str)
        if cross_key in out:
            emit(f"[Tidal]   {title} ({release_date_str}): skipped (duplicate key)")
            continue

        primary_type = (album.get("type") or "album").lower()
        if primary_type not in {"album", "ep", "single"}:
            primary_type = "album"

        candidate = CandidateRelease(
            release_group_mbid="",
            artist_mbid=None,
            artist_name=artist_name,
            title=title,
            release_date=release_date_str,
            primary_type=primary_type,
            secondary_types=[],
            label=None,
            tier=tier,
        )
        candidate.streaming_only_id = f"tidal-album:{album.get('id', '')}"
        candidate.streaming_provider = "tidal"
        out[cross_key] = candidate
        added += 1
        emit(f"[Tidal]   {title} ({release_date_str}): added")
    emit(f"[Tidal] {artist_name}: {added}/{len(tidal_albums)} albums added to candidates")


def _merge_streaming_provider_hits(
    deezer_hits: dict[tuple[str, str, str], CandidateRelease],
    tidal_hits: dict[tuple[str, str, str], CandidateRelease],
) -> tuple[list[CandidateRelease], int]:
    """Cross-check Deezer and Tidal hits; prefer Tidal when both have the same release.

    Releases corroborated by both providers receive a small score nudge via the
    ``streaming_corroborated`` attribute, which the scoring layer can read to
    boost confidence.
    """
    merged: list[CandidateRelease] = []
    corroborated = 0
    seen_keys: set[tuple[str, str, str]] = set()

    for key, tidal_candidate in tidal_hits.items():
        if key in deezer_hits:
            tidal_candidate.streaming_corroborated = True
            corroborated += 1
        merged.append(tidal_candidate)
        seen_keys.add(key)

    for key, deezer_candidate in deezer_hits.items():
        if key in seen_keys:
            continue
        merged.append(deezer_candidate)

    return merged, corroborated


def _effective_max_tracks(
    max_tracks: int,
    *,
    release_count: int,
    penalize_frequent_artists: bool,
) -> int:
    """Return per-release track cap after frequent short-form release penalty."""
    if max_tracks <= 0:
        return 0
    if not penalize_frequent_artists:
        return max_tracks
    if release_count >= 5:
        return max(1, max_tracks - 2)
    if release_count >= 3:
        return max(1, max_tracks - 1)
    return max_tracks


def _limit_graph_artists(graph: ExpandedGraph, *, seeds: list[ArtistSeed], max_artists: int) -> ExpandedGraph:
    """Limit graph artists for expensive v2 runs while always retaining seeds."""
    if max_artists <= 0 or len(graph.artist_tiers) <= max_artists:
        return graph

    seed_keys = {
        seed.artist_mbid or seed.canonical_name.lower()
        for seed in seeds
    }
    retained: set[str] = set(seed_keys)
    remaining_slots = max(0, max_artists - len(retained))

    edge_counts: dict[str, int] = {}
    for edge in graph.edges:
        key = edge.target_artist_mbid or edge.target_artist_name.lower()
        edge_counts[key] = edge_counts.get(key, 0) + 1

    candidates = [
        key for key in graph.artist_tiers
        if key not in retained
    ]
    candidates.sort(
        key=lambda key: (
            -TIER_FACTORS.get(graph.artist_tiers.get(key, ""), 0.0),
            -edge_counts.get(key, 0),
            graph.artist_names.get(key, key).lower(),
        )
    )
    retained.update(candidates[:remaining_slots])

    return ExpandedGraph(
        edges=[
            edge for edge in graph.edges
            if (edge.source_artist_mbid or edge.source_artist_name.lower()) in retained
            and (edge.target_artist_mbid or edge.target_artist_name.lower()) in retained
        ],
        artist_tiers={key: tier for key, tier in graph.artist_tiers.items() if key in retained},
        artist_names={key: name for key, name in graph.artist_names.items() if key in retained},
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fetch_seed_tags(seeds: list, lastfm: Any, musicbrainz: Any) -> dict[str, set[str]]:
    """
    Fetch genre/tag sets for each seed artist.

    Returns mapping of artist_key → set of normalized tag strings.
    Uses Last.fm top tags when available; falls back to MB genres.
    Empty sets are returned for artists with no tag data.
    """
    def _tags_for_seed(seed: Any) -> tuple[str, set[str]]:
        key = seed.artist_mbid or seed.canonical_name.lower()
        tags: set[str] = set()

        if lastfm:
            try:
                lf_tags = lastfm.top_tags(seed.canonical_name) or []
                for tag in lf_tags[:20]:
                    if tag:
                        tags.add(tag.lower().strip())
            except Exception:
                pass

        if not tags and musicbrainz and seed.artist_mbid:
            try:
                artist_data = musicbrainz.lookup_artist(seed.artist_mbid) or {}
                for genre in artist_data.get("genres", []):
                    name = (genre.get("name") or "").lower().strip()
                    if name:
                        tags.add(name)
                for tag in artist_data.get("tags", []):
                    name = (tag.get("name") or "").lower().strip()
                    if name:
                        tags.add(name)
            except Exception:
                pass

        return key, tags

    seed_tags: dict[str, set[str]] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(_tags_for_seed, seed) for seed in seeds]
        for future in concurrent.futures.as_completed(futures):
            key, tags = future.result()
            seed_tags[key] = tags

    return seed_tags


def _apply_limit_with_fallback(
    scored: list,
    limit: int,
    deep_cuts: bool,
    emit: Any,
) -> list[ReleaseRecommendation]:
    """
    Apply the --limit with tiered fallback:
      1. Fill from High-confidence results (score ≥ 75).
      2. If limit not met, append Medium-confidence results (40–74) with notice.
      3. Low-confidence (< 40) only in deep_cuts mode.

    Returns a list of ReleaseRecommendation up to `limit` items.
    """
    high = [s for s in scored if s.score_normalized >= 75]
    medium = [s for s in scored if 40 <= s.score_normalized < 75]
    low = [s for s in scored if s.score_normalized < 40]

    selected = high[:limit]
    remaining = limit - len(selected)

    if remaining > 0 and medium:
        medium_to_add = medium[:remaining]
        if selected:  # only emit notice if high results were already added
            emit(build_fallback_notice(len(medium_to_add)))
        selected.extend(medium_to_add)
        remaining = limit - len(selected)

    if remaining > 0 and low and deep_cuts:
        selected.extend(low[:remaining])

    return [scored_to_recommendation(s) for s in selected]


def _select_scored_releases(
    scored: list,
    limit: int,
    deep_cuts: bool,
    balanced: bool,
    emit: Any,
) -> list[ReleaseRecommendation]:
    """Select scored releases according to the requested discovery mode."""
    if not balanced:
        return _apply_limit_with_fallback(scored, limit=limit, deep_cuts=deep_cuts, emit=emit)
    selected = _balanced_select_scored(scored, limit=limit, deep_cuts=deep_cuts)
    return [scored_to_recommendation(s) for s in selected]


def _enforce_tier4_share_cap(
    *,
    selected: list[ReleaseRecommendation],
    all_scored: list[Any],
    limit: int,
    max_share: float,
) -> list[ReleaseRecommendation]:
    if not selected or limit <= 0:
        return selected
    max_share = max(0.0, min(1.0, float(max_share)))
    max_tier4 = max(0, int(limit * max_share))
    if max_tier4 <= 0:
        max_tier4 = 1
    tier4_count = sum(1 for rec in selected if str(rec.tier or "").strip().lower() == "tier 4")
    if tier4_count <= max_tier4:
        return selected

    kept: list[ReleaseRecommendation] = []
    kept_keys: set[tuple[str, str, str]] = set()
    kept_tier4 = 0
    for rec in selected:
        is_tier4 = str(rec.tier or "").strip().lower() == "tier 4"
        if is_tier4 and kept_tier4 >= max_tier4:
            continue
        if is_tier4:
            kept_tier4 += 1
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in kept_keys:
            continue
        kept_keys.add(key)
        kept.append(rec)

    # Refill only with non-Tier-4 scored candidates.
    for sr in all_scored:
        if len(kept) >= limit:
            break
        tier = str(sr.candidate.tier or "").strip().lower()
        if tier == "tier 4":
            continue
        rec = scored_to_recommendation(sr)
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in kept_keys:
            continue
        kept_keys.add(key)
        kept.append(rec)
    return kept


def _balanced_select_scored(scored: list, limit: int, deep_cuts: bool) -> list:
    """Select a confidence-balanced, diversity-aware subset of scored releases."""
    if limit <= 0:
        return []

    high = [s for s in scored if s.score_normalized >= 75]
    medium = [s for s in scored if 40 <= s.score_normalized < 75]
    low = [s for s in scored if s.score_normalized < 40]
    high_quota, medium_quota, low_quota = _balanced_confidence_quotas(limit)

    selected: list = []
    seen_keys: set[str] = set()
    diversity_counts: dict[tuple[str, str], int] = {}

    def take(pool: list, quota: int) -> None:
        nonlocal selected
        if quota <= 0 or len(selected) >= limit:
            return
        picks = _take_diverse(pool, quota=min(quota, limit - len(selected)), seen_keys=seen_keys, counts=diversity_counts)
        selected.extend(picks)

    take(high, high_quota)
    take(medium, medium_quota)
    take(low, low_quota)

    remaining = limit - len(selected)
    if remaining > 0:
        # First refill from any unused high/medium slots (preferred quality).
        upper_fill = [s for s in high + medium if _scored_identity_key(s) not in seen_keys]
        take(upper_fill, remaining)

        # If quality slots still leave the user short of the requested limit:
        # - deep_cuts: any low-confidence candidates are eligible.
        # - non-deep-cuts: only qualified Tier-4 exceptions are eligible.
        remaining = limit - len(selected)
        if remaining > 0:
            if deep_cuts:
                low_fill = [s for s in low if _scored_identity_key(s) not in seen_keys]
            else:
                low_fill = [
                    s
                    for s in low
                    if _scored_identity_key(s) not in seen_keys and _allows_tier4_exception_without_deep_cuts(s)
                ]
            take(low_fill, remaining)

    return selected[:limit]


def _balanced_confidence_quotas(limit: int) -> tuple[int, int, int]:
    """Return target High/Medium/Low quotas for balanced mode."""
    if limit <= 0:
        return (0, 0, 0)
    high = min(limit, round(limit * 0.81))
    medium = min(limit - high, round(limit * 0.13))
    low = max(0, limit - high - medium)
    return high, medium, low


def _take_diverse(pool: list, quota: int, *, seen_keys: set[str], counts: dict[tuple[str, str], int]) -> list:
    """Greedily take high-scoring items while softly penalizing repeated evidence."""
    chosen: list = []
    remaining = [s for s in pool if _scored_identity_key(s) not in seen_keys]
    while remaining and len(chosen) < quota:
        best = max(remaining, key=lambda s: (_diversity_adjusted_score(s, counts), s.score_normalized))
        remaining.remove(best)
        seen_keys.add(_scored_identity_key(best))
        for key in _diversity_keys(best):
            counts[key] = counts.get(key, 0) + 1
        chosen.append(best)
    return chosen


def _diversity_adjusted_score(scored: Any, counts: dict[tuple[str, str], int]) -> float:
    penalty = 0.0
    for key in _diversity_keys(scored):
        penalty += counts.get(key, 0)
    return scored.score_normalized - (penalty * 4.0)


def _diversity_keys(scored: Any) -> list[tuple[str, str]]:
    candidate = scored.candidate
    keys: list[tuple[str, str]] = []
    artist_key = normalize_key(candidate.artist_name)
    if artist_key:
        keys.append(("artist", artist_key))
    for seed in (scored.explanation.get("seed_artists") or [])[:3]:
        if seed:
            keys.append(("seed", normalize_key(seed)))
    if candidate.tier:
        keys.append(("tier", candidate.tier))
    for relation_type in (scored.explanation.get("connection_types") or [])[:3]:
        if relation_type:
            keys.append(("relation", normalize_key(relation_type)))
    if candidate.label:
        keys.append(("label", normalize_key(candidate.label)))
    return keys


def _scored_identity_key(scored: Any) -> str:
    candidate = scored.candidate
    if candidate.release_group_mbid:
        return f"rg:{candidate.release_group_mbid}"
    return f"fallback:{normalize_key(candidate.artist_name)}|{normalize_key(candidate.title)}|{candidate.release_date}"


def _passes_listenbrainz_evidence_guard(scored: Any) -> bool:
    """Require extra evidence for ListenBrainz-only single-seed links.

    Reject cases where the only connection is `listenbrainz_similar` to exactly
    one seed artist *and* there's no strong genre/tag alignment signal.
    """
    raw_types = [str(v).strip().lower() for v in (scored.explanation.get("connection_types") or []) if v]
    if not raw_types:
        return True
    unique_types = set(raw_types)
    if unique_types != {"listenbrainz_similar"}:
        return True

    seed_count = len({normalize_key(s) for s in (scored.explanation.get("seed_artists") or []) if s})
    if seed_count >= 2:
        return True

    # In this pipeline, Tier 3 similarity assignments come from explicit
    # tag/genre overlap checks, while Tier 4 is weak/no overlap.
    tier = str(getattr(scored.candidate, "tier", "") or "").strip().lower()
    return tier == "tier 3"


def _allows_tier4_exception_without_deep_cuts(scored: Any) -> bool:
    """Allow Tier-4 only when it shows both similarity and genre/tag overlap."""
    tier = str(getattr(scored.candidate, "tier", "") or "").strip().lower()
    if tier != "tier 4":
        return False
    conn_types = {str(v).strip().lower() for v in (scored.explanation.get("connection_types") or []) if v}
    has_similarity = bool(conn_types & {"listenbrainz_similar", "lastfm_similar"})
    has_genre_or_tag_match = bool(conn_types & {"lastfm_tag"})
    return has_similarity and has_genre_or_tag_match


def _enforce_artist_share_cap(
    *,
    selected: list[ReleaseRecommendation],
    all_scored: list[Any],
    limit: int,
    balanced: bool = False,
) -> list[ReleaseRecommendation]:
    """Cap per-artist domination while preserving quality and target list size."""
    if not selected or limit <= 0:
        return selected

    # Keep at least 2 per artist; balanced mode uses a stricter cap to force spread.
    base_cap = max(2, int(math.ceil(limit * (0.08 if balanced else 0.12))))

    def _apply_cap(candidates: list[ReleaseRecommendation], cap: int) -> list[ReleaseRecommendation]:
        kept: list[ReleaseRecommendation] = []
        counts: dict[str, int] = {}
        seen_keys: set[tuple[str, str, str]] = set()
        for rec in candidates:
            artist_key = normalize_key(rec.artist)
            if counts.get(artist_key, 0) >= cap:
                continue
            key = (artist_key, normalize_variant_title(rec.title), rec.release_date or "")
            if key in seen_keys:
                continue
            seen_keys.add(key)
            counts[artist_key] = counts.get(artist_key, 0) + 1
            kept.append(rec)

        for sr in all_scored:
            if len(kept) >= limit:
                break
            rec = scored_to_recommendation(sr)
            artist_key = normalize_key(rec.artist)
            if counts.get(artist_key, 0) >= cap:
                continue
            key = (artist_key, normalize_variant_title(rec.title), rec.release_date or "")
            if key in seen_keys:
                continue
            seen_keys.add(key)
            counts[artist_key] = counts.get(artist_key, 0) + 1
            kept.append(rec)
        return kept

    # Adaptive relax: only loosen when needed to avoid unnecessary underfill.
    for cap in (base_cap, base_cap + 1, base_cap + 2):
        capped = _apply_cap(selected, cap)
        if len(capped) >= limit:
            return capped[:limit]
    return _apply_cap(selected, base_cap + 3)[:limit]


def _enforce_tier1_share_cap(
    *,
    selected: list[ReleaseRecommendation],
    all_scored: list[Any],
    limit: int,
    max_share: float,
) -> list[ReleaseRecommendation]:
    """In balanced mode, prevent Tier 1/direct-seed dominance."""
    if not selected or limit <= 0:
        return selected

    max_share = max(0.0, min(1.0, float(max_share)))
    max_tier1 = max(1, int(math.floor(limit * max_share)))
    tier1_count = sum(1 for rec in selected if str(rec.tier or "").strip().lower() == "tier 1")
    if tier1_count <= max_tier1:
        return selected

    kept: list[ReleaseRecommendation] = []
    kept_keys: set[tuple[str, str, str]] = set()
    kept_tier1 = 0
    for rec in selected:
        is_tier1 = str(rec.tier or "").strip().lower() == "tier 1"
        if is_tier1 and kept_tier1 >= max_tier1:
            continue
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in kept_keys:
            continue
        kept_keys.add(key)
        kept.append(rec)
        if is_tier1:
            kept_tier1 += 1

    # Refill with non-tier1 scored candidates first.
    for sr in all_scored:
        if len(kept) >= limit:
            break
        if str(sr.candidate.tier or "").strip().lower() == "tier 1":
            continue
        rec = scored_to_recommendation(sr)
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in kept_keys:
            continue
        kept_keys.add(key)
        kept.append(rec)

    # If still short, allow tier1 back in by score order to avoid unnecessary underfill.
    for sr in all_scored:
        if len(kept) >= limit:
            break
        rec = scored_to_recommendation(sr)
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in kept_keys:
            continue
        kept_keys.add(key)
        kept.append(rec)
    return kept[:limit]


def _fetch_label_affinity_candidates(
    *,
    profile: TasteProfile | None,
    seeds: list[ArtistSeed],
    musicbrainz: Any | None,
    heard_release_group_mbids: set[str] | None,
    existing_release_group_mbids: set[str],
    window_days: int,
    allow_compilations: bool,
    allow_live: bool,
    emit: Any,
    debug: bool = False,
    discovery_window: DiscoveryWindow | None = None,
) -> list[CandidateRelease]:
    if profile is None or musicbrainz is None or not seeds:
        return []
    labels = [(term.name, term.weight) for term in profile.top_labels[:5] if term.name]
    if not labels:
        return []
    return fetch_label_affinity_candidates(
        labels=labels,
        musicbrainz=musicbrainz,
        heard_release_group_mbids=heard_release_group_mbids,
        existing_release_group_mbids=existing_release_group_mbids,
        window_days=window_days,
        allow_compilations=allow_compilations,
        allow_live=allow_live,
        emit=emit,
        debug=debug,
        window_start_date=discovery_window.start_date if discovery_window else None,
        window_end_date=discovery_window.end_date if discovery_window else None,
    )


def _run_provider_budgeted_shortage_expansion(
    *,
    existing_candidates: list[CandidateRelease],
    graph: ExpandedGraph,
    seeds: list[ArtistSeed],
    musicbrainz: Any | None,
    listenbrainz: Any | None,
    lastfm: Any | None,
    heard_release_group_mbids: set[str] | None,
    window_days: int,
    allow_compilations: bool,
    allow_live: bool,
    discovery_window: DiscoveryWindow | None,
    emit: Any,
    debug: bool,
    shortage_target: int,
    max_rounds: int,
    provider_weights: dict[str, float],
    per_artist_round_cap: int,
    tiny_seed_mode: bool,
    include_tier4: bool,
) -> tuple[list[CandidateRelease], list[dict[str, Any]]]:
    if musicbrainz is None:
        return ([], [])
    _emit = emit or (lambda *_: None)
    existing_keys = {(c.release_group_mbid, c.artist_name, c.release_date) for c in existing_candidates}
    provider_pools = _provider_artist_pools_from_graph(graph)
    provider_used: dict[str, set[str]] = {k: set() for k in provider_pools}
    round_stats: list[dict[str, Any]] = []
    accumulated: list[CandidateRelease] = []

    remaining_needed = max(0, shortage_target - len(existing_candidates))
    if remaining_needed <= 0:
        return ([], [])
    _emit(f"[v2] shortage expansion: target={shortage_target}, current={len(existing_candidates)}")

    for round_idx in range(1, max_rounds + 1):
        if len(existing_candidates) + len(accumulated) >= shortage_target:
            break
        round_allowed_tiers = _round_allowed_tiers(round_idx, include_tier4=include_tier4)
        round_scan_budget = min(max(12, remaining_needed * 2), 36 if tiny_seed_mode else 80)
        quotas = _allocate_provider_quotas(round_scan_budget, provider_weights)
        stats = {
            "round": round_idx,
            "allowed_tiers": sorted(round_allowed_tiers),
            "scan_budget": round_scan_budget,
            "providers": {},
            "spillover_used": 0,
        }
        round_added = 0

        # First chance pass: each provider gets its reservation before spillover.
        for provider in ("musicbrainz", "listenbrainz", "lastfm"):
            quota = quotas.get(provider, 0)
            added, fetched, artist_used = _shortage_provider_fetch(
                provider=provider,
                quota=quota,
                provider_pools=provider_pools,
                provider_used=provider_used,
                graph=graph,
                seeds=seeds,
                musicbrainz=musicbrainz,
                lastfm=lastfm,
                heard_release_group_mbids=heard_release_group_mbids,
                window_days=window_days,
                allow_compilations=allow_compilations,
                allow_live=allow_live,
                discovery_window=discovery_window,
                allowed_tiers=round_allowed_tiers,
                per_artist_round_cap=per_artist_round_cap,
                existing_keys=existing_keys,
                debug=debug,
            )
            accumulated.extend(added)
            for item in added:
                existing_keys.add((item.release_group_mbid, item.artist_name, item.release_date))
            round_added += len(added)
            stats["providers"][provider] = {
                "quota": quota,
                "artists_used": artist_used,
                "fetched": fetched,
                "accepted": len(added),
            }

        # Spillover pass: redistribute unused budget after first chance.
        unmet = max(0, min(round_scan_budget, remaining_needed * 2) - round_added)
        if unmet > 0:
            for provider in ("lastfm", "listenbrainz", "musicbrainz"):
                if unmet <= 0:
                    break
                added, fetched, artist_used = _shortage_provider_fetch(
                    provider=provider,
                    quota=unmet,
                    provider_pools=provider_pools,
                    provider_used=provider_used,
                    graph=graph,
                    seeds=seeds,
                    musicbrainz=musicbrainz,
                    lastfm=lastfm,
                    heard_release_group_mbids=heard_release_group_mbids,
                    window_days=window_days,
                    allow_compilations=allow_compilations,
                    allow_live=allow_live,
                    discovery_window=discovery_window,
                    allowed_tiers=round_allowed_tiers,
                    per_artist_round_cap=per_artist_round_cap,
                    existing_keys=existing_keys,
                    debug=debug,
                )
                accumulated.extend(added)
                for item in added:
                    existing_keys.add((item.release_group_mbid, item.artist_name, item.release_date))
                round_added += len(added)
                stats["spillover_used"] += len(added)
                block = stats["providers"].setdefault(provider, {"quota": 0, "artists_used": 0, "fetched": 0, "accepted": 0})
                block["artists_used"] += artist_used
                block["fetched"] += fetched
                block["accepted"] += len(added)
                unmet -= len(added)

        remaining_needed = max(0, shortage_target - (len(existing_candidates) + len(accumulated)))
        stats["round_added"] = round_added
        stats["remaining_needed"] = remaining_needed
        round_stats.append(stats)
        _emit(f"[v2] shortage round {round_idx}: added={round_added}, remaining={remaining_needed}")
        if round_added == 0:
            break

    return (accumulated, round_stats)


def _provider_artist_pools_from_graph(graph: ExpandedGraph) -> dict[str, list[str]]:
    lb_targets: set[str] = set()
    lf_targets: set[str] = set()
    for edge in graph.edges:
        key = edge.target_artist_mbid or normalize_key(edge.target_artist_name)
        rel = normalize_key(edge.relation_type)
        if not key:
            continue
        if "listenbrainz" in rel:
            lb_targets.add(key)
        if "lastfm" in rel:
            lf_targets.add(key)
    mb_targets = {k for k in graph.artist_tiers if graph.artist_tiers.get(k) in LOW_PRIORITY_TIERS}
    mb_targets = mb_targets - lb_targets - lf_targets
    return {
        "musicbrainz": sorted(mb_targets),
        "listenbrainz": sorted(lb_targets),
        "lastfm": sorted(lf_targets),
    }


def _round_allowed_tiers(round_idx: int, *, include_tier4: bool) -> set[str]:
    if round_idx <= 1:
        return {"Tier 3"}
    if round_idx == 2:
        return {"Tier 2B", "Tier 3", "Tier 4"} if include_tier4 else {"Tier 2B", "Tier 3"}
    return {"Tier 2A", "Tier 2B", "Tier 3", "Tier 4"} if include_tier4 else {"Tier 2A", "Tier 2B", "Tier 3"}


def _allocate_provider_quotas(total: int, weights: dict[str, float]) -> dict[str, int]:
    if total <= 0:
        return {"musicbrainz": 0, "listenbrainz": 0, "lastfm": 0}
    providers = ("musicbrainz", "listenbrainz", "lastfm")
    quotas = {p: max(0, int(total * float(weights.get(p, 0.0)))) for p in providers}
    used = sum(quotas.values())
    for p in providers:
        if used >= total:
            break
        quotas[p] += 1
        used += 1
    return quotas


def _shortage_provider_fetch(
    *,
    provider: str,
    quota: int,
    provider_pools: dict[str, list[str]],
    provider_used: dict[str, set[str]],
    graph: ExpandedGraph,
    seeds: list[ArtistSeed],
    musicbrainz: Any,
    lastfm: Any | None,
    heard_release_group_mbids: set[str] | None,
    window_days: int,
    allow_compilations: bool,
    allow_live: bool,
    discovery_window: DiscoveryWindow | None,
    allowed_tiers: set[str],
    per_artist_round_cap: int,
    existing_keys: set[tuple[str, str, str]],
    debug: bool,
) -> tuple[list[CandidateRelease], int, int]:
    if quota <= 0:
        return ([], 0, 0)
    selected_keys: list[str] = []
    for key in provider_pools.get(provider, []):
        if key in provider_used.get(provider, set()):
            continue
        if graph.artist_tiers.get(key) not in allowed_tiers:
            continue
        selected_keys.append(key)
        if len(selected_keys) >= quota:
            break
    fetched: list[CandidateRelease] = []
    if selected_keys:
        artist_tiers = {k: graph.artist_tiers[k] for k in selected_keys if k in graph.artist_tiers}
        artist_names = {k: graph.artist_names.get(k, k) for k in selected_keys}
        fetched = fetch_candidates(
            artist_tiers=artist_tiers,
            artist_names=artist_names,
            musicbrainz=musicbrainz,
            heard_release_group_mbids=heard_release_group_mbids,
            window_days=window_days,
            allow_compilations=allow_compilations,
            allow_live=allow_live,
            emit=(lambda *_: None),
            progress=None,
            debug=debug,
            window_start_date=discovery_window.start_date if discovery_window else None,
            window_end_date=discovery_window.end_date if discovery_window else None,
            allowed_tiers=allowed_tiers,
            max_artists_to_scan=len(selected_keys),
        )
    if provider == "lastfm" and len(selected_keys) < quota and lastfm is not None:
        sparse = _fetch_lastfm_sparse_supply_candidates(
            seeds=seeds,
            musicbrainz=musicbrainz,
            lastfm=lastfm,
            heard_release_group_mbids=heard_release_group_mbids,
            window_days=window_days,
            allow_compilations=allow_compilations,
            allow_live=allow_live,
            discovery_window=discovery_window,
            emit=(lambda *_: None),
            debug=debug,
        )
        fetched.extend(sparse)

    for key in selected_keys:
        provider_used.setdefault(provider, set()).add(key)

    accepted: list[CandidateRelease] = []
    per_artist_counts: dict[str, int] = {}
    for candidate in fetched:
        ckey = (candidate.release_group_mbid, candidate.artist_name, candidate.release_date)
        if ckey in existing_keys:
            continue
        artist_key = normalize_key(candidate.artist_name)
        count = per_artist_counts.get(artist_key, 0)
        if count >= per_artist_round_cap:
            continue
        per_artist_counts[artist_key] = count + 1
        accepted.append(candidate)
    return (accepted, len(fetched), len(selected_keys))


def _fetch_lastfm_sparse_supply_candidates(
    *,
    seeds: list[ArtistSeed],
    musicbrainz: Any | None,
    lastfm: Any | None,
    heard_release_group_mbids: set[str] | None,
    window_days: int,
    allow_compilations: bool,
    allow_live: bool,
    discovery_window: DiscoveryWindow | None,
    emit: Any,
    debug: bool = False,
) -> list[CandidateRelease]:
    if not seeds or musicbrainz is None or lastfm is None:
        return []
    _emit = emit or (lambda *_: None)
    _debug_emit = _emit if debug else (lambda *_: None)
    names: list[str] = []
    seen: set[str] = set()
    for seed in seeds[:5]:
        try:
            similar = list(lastfm.similar_artists(seed.canonical_name, limit=15) or [])
        except Exception:
            similar = []
        for name in similar:
            norm = normalize_key(name)
            if not norm or norm == normalize_key(seed.canonical_name):
                continue
            if norm in seen:
                continue
            seen.add(norm)
            names.append(name)
            if len(names) >= 15:
                break
        if len(names) >= 15:
            break
    if not names:
        return []
    _debug_emit(f"[v2] Sparse Last.fm fallback artists: {len(names)}")
    artist_tiers = {normalize_key(name): "Tier 2B" for name in names}
    artist_names = {normalize_key(name): name for name in names}
    return fetch_candidates(
        artist_tiers=artist_tiers,
        artist_names=artist_names,
        musicbrainz=musicbrainz,
        heard_release_group_mbids=heard_release_group_mbids,
        window_days=window_days,
        allow_compilations=allow_compilations,
        allow_live=allow_live,
        emit=_emit,
        progress=None,
        window_start_date=discovery_window.start_date if discovery_window else None,
        window_end_date=discovery_window.end_date if discovery_window else None,
        debug=debug,
        allowed_tiers={"Tier 2B"},
        max_artists_to_scan=15,
    )


def _fetch_iterative_broaden_candidates(
    *,
    seeds: list[ArtistSeed],
    seed_tags: dict[str, set[str]],
    musicbrainz: Any | None,
    listenbrainz: Any | None,
    lastfm: Any | None,
    heard_release_group_mbids: set[str] | None,
    window_days: int,
    allow_compilations: bool,
    allow_live: bool,
    discovery_window: DiscoveryWindow | None,
    emit: Any,
    debug: bool = False,
    round_idx: int = 1,
    include_tier4: bool = False,
) -> list[CandidateRelease]:
    if not seeds or musicbrainz is None:
        return []
    _emit = emit or (lambda *_: None)
    names: list[str] = []
    seen: set[str] = set()
    seed_tag_universe: set[str] = set()
    for key, tags in (seed_tags or {}).items():
        if not key:
            continue
        seed_tag_universe.update({str(tag).lower().strip() for tag in tags if tag})
    tag_cache: dict[str, set[str]] = {}
    lb_limit = 6 + (round_idx * 2)
    lf_limit = 8 + (round_idx * 3)
    depth2_limit = 4 + (round_idx * 2)

    for seed in seeds[:6]:
        seed_name = seed.canonical_name
        seed_key = normalize_key(seed_name)
        if seed_key and seed_key not in seen:
            seen.add(seed_key)
            names.append(seed_name)
        if lastfm is not None:
            try:
                lf = list(lastfm.similar_artists(seed_name, limit=lf_limit) or [])
            except Exception:
                lf = []
            for name in lf:
                key = normalize_key(name)
                if not key or key in seen:
                    continue
                if not _passes_broaden_tag_guard(
                    artist_name=name,
                    round_idx=round_idx,
                    seed_tag_universe=seed_tag_universe,
                    lastfm=lastfm,
                    cache=tag_cache,
                ):
                    continue
                seen.add(key)
                names.append(name)
        if listenbrainz is not None and seed.artist_mbid:
            try:
                lb = list(listenbrainz.get_similar_artists(seed.artist_mbid) or [])
            except Exception:
                lb = []
            for item in lb[:lb_limit]:
                name = str(item.get("artist_name") or "").strip()
                key = normalize_key(name)
                if not key or key in seen:
                    continue
                if not _passes_broaden_tag_guard(
                    artist_name=name,
                    round_idx=round_idx,
                    seed_tag_universe=seed_tag_universe,
                    lastfm=lastfm,
                    cache=tag_cache,
                ):
                    continue
                seen.add(key)
                names.append(name)

    # Similar-of-similar on Last.fm for additional breadth when scarce.
    if lastfm is not None:
        for name in names[:depth2_limit]:
            try:
                lf2 = list(lastfm.similar_artists(name, limit=max(3, round_idx + 2)) or [])
            except Exception:
                lf2 = []
            for sub in lf2:
                key = normalize_key(sub)
                if not key or key in seen:
                    continue
                if not _passes_broaden_tag_guard(
                    artist_name=sub,
                    round_idx=round_idx,
                    seed_tag_universe=seed_tag_universe,
                    lastfm=lastfm,
                    cache=tag_cache,
                ):
                    continue
                seen.add(key)
                names.append(sub)

    if not names:
        return []
    max_scan = min(max(20, len(names)), 70 if round_idx >= 3 else 45)
    selected = names[:max_scan]
    default_tier = "Tier 4" if include_tier4 else "Tier 3"
    artist_tiers = {normalize_key(name): default_tier for name in selected}
    artist_names = {normalize_key(name): name for name in selected}
    _emit(f"[v2] broaden round {round_idx}: artists={len(selected)}")
    return fetch_candidates(
        artist_tiers=artist_tiers,
        artist_names=artist_names,
        musicbrainz=musicbrainz,
        heard_release_group_mbids=heard_release_group_mbids,
        window_days=window_days,
        allow_compilations=allow_compilations,
        allow_live=allow_live,
        emit=(lambda *_: None),
        progress=None,
        debug=debug,
        window_start_date=discovery_window.start_date if discovery_window else None,
        window_end_date=discovery_window.end_date if discovery_window else None,
        allowed_tiers={"Tier 2B", "Tier 3", "Tier 4"} if include_tier4 else {"Tier 2B", "Tier 3"},
        max_artists_to_scan=len(selected),
    )


def _passes_broaden_tag_guard(
    *,
    artist_name: str,
    round_idx: int,
    seed_tag_universe: set[str],
    lastfm: Any | None,
    cache: dict[str, set[str]],
) -> bool:
    # Round 1-2: require at least one shared tag when we have a seed tag baseline.
    # Round 3: allow broader exploration, but keep guard if tags are known and disjoint.
    if not seed_tag_universe or lastfm is None:
        return True
    key = normalize_key(artist_name)
    if key in cache:
        artist_tags = cache[key]
    else:
        try:
            raw_tags = list(lastfm.top_tags(artist_name) or [])
        except Exception:
            raw_tags = []
        artist_tags = {str(tag).lower().strip() for tag in raw_tags if tag}
        cache[key] = artist_tags
    if not artist_tags:
        return round_idx >= 3
    overlap = len(seed_tag_universe & artist_tags)
    if round_idx <= 2:
        return overlap >= 1
    return overlap >= 1 or len(artist_tags) <= 3


def _final_normalized_release_dedup(
    recommendations: list[ReleaseRecommendation],
) -> list[ReleaseRecommendation]:
    if len(recommendations) <= 1:
        return recommendations
    merged: dict[tuple[str, str, str], ReleaseRecommendation] = {}
    ordered: list[ReleaseRecommendation] = []
    for rec in recommendations:
        key = (normalize_key(rec.artist), normalize_variant_title(rec.title), rec.release_date or "")
        if key in merged:
            continue
        merged[key] = rec
        ordered.append(rec)
    return ordered


def _label_affinity_edges(
    candidates: list[CandidateRelease],
    *,
    seeds: list[ArtistSeed],
    profile: TasteProfile | None,
) -> list[GraphEdge]:
    seed_by_name = {normalize_key(seed.canonical_name): seed for seed in seeds}
    labels_by_seed: dict[str, set[str]] = {}
    if profile is not None:
        for artist in profile.artists or profile.top_artists:
            seed = seed_by_name.get(normalize_key(artist.name))
            if not seed:
                continue
            labels_by_seed[seed.canonical_name] = {normalize_key(label) for label in artist.labels if label}

    fallback_seeds = seeds[:3]
    edges: list[GraphEdge] = []
    seen: set[tuple[str, str, str]] = set()
    for candidate in candidates:
        label_key = normalize_key(candidate.label)
        if label_key:
            connected_seeds = [
                seed
                for seed in seeds
                if label_key in labels_by_seed.get(seed.canonical_name, set())
            ]
            connection_strength = 0.95
        else:
            connected_seeds = []
            connection_strength = 0.25

        if not connected_seeds:
            connected_seeds = fallback_seeds
            connection_strength = 0.25

        target_key = candidate.artist_mbid or normalize_key(candidate.artist_name)
        if not target_key:
            continue
        for seed in connected_seeds[:3]:
            source_key = seed.artist_mbid or normalize_key(seed.canonical_name)
            key = (source_key, target_key, candidate.label or "")
            if key in seen:
                continue
            seen.add(key)
            edges.append(
                GraphEdge(
                    source_artist_mbid=seed.artist_mbid,
                    source_artist_name=seed.canonical_name,
                    target_artist_mbid=candidate.artist_mbid,
                    target_artist_name=candidate.artist_name,
                    relation_type="label_affinity",
                    confidence=0.75,
                    depth=1,
                    connection_strength=connection_strength,
                    tier="Tier 3",
                )
            )
    return edges
