from __future__ import annotations

import time
from typing import Any

import httpx

from mamonia.config import Settings
from mamonia.models import ReleaseTrack
from mamonia.providers import (
    ProviderRateLimit,
    ProviderUnavailable,
    format_network_error,
    httpx_timeout_from_settings,
    is_network_error,
    is_timeout_error,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import dedupe, normalize_key, normalized_cache_key, safe_get


MUSICBRAINZ_BASE = "https://musicbrainz.org/ws/2"
class MusicBrainzProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None):
        self.settings = settings
        self.storage = storage
        self._last_request_at = 0.0
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self.api_calls = 0
        self.retry_count = 0
        self.request_time_seconds = 0.0
        self.timeout_events = 0
        self.client = httpx.Client(
            timeout=httpx_timeout_from_settings(settings),
            trust_env=False,
            headers={
                "User-Agent": f"{settings.app_name}/{settings.app_version} ({settings.mb_contact})"
            },
        )

    def _record_rate_limit(self, rate_limit: ProviderRateLimit) -> None:
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True

    def search_artist(self, name: str) -> dict[str, Any] | None:
        name = (name or "").strip()
        if not name:
            return None
        cache_key = normalized_cache_key("artist-search-v2", artist=name)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        artists: list[dict[str, Any]] = []
        for query in _artist_query_variants(name):
            data = self._get("/artist", {"query": query, "fmt": "json", "limit": 5})
            artists = data.get("artists", []) if data else []
            if artists:
                break
        if not artists:
            # Fallback: search recordings to find artists
            artists = self._fallback_artist_search_via_recordings(name)
        if not artists:
            # Fallback: direct database lookup by name (bypasses Lucene index)
            artists = self._direct_artist_lookup(name)
        if not artists:
            self._cache_set(cache_key, None)
            return None
        target = normalize_key(name)
        best = max(
            artists,
            key=lambda artist: int(artist.get("score", 0)) + (25 if normalize_key(artist.get("name")) == target else 0),
        )
        result = {
            "id": best.get("id"),
            "name": best.get("name", name),
            "country": best.get("country", ""),
            "type": best.get("type", ""),
            "tags": [tag.get("name") for tag in best.get("tags", []) if tag.get("name")],
        }
        self._cache_set(cache_key, result)
        return result

    def lookup_artist(self, mbid: str) -> dict[str, Any] | None:
        cache_key = normalized_cache_key("artist-lookup-v2", artist_id=mbid)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            f"/artist/{mbid}",
            {"fmt": "json", "inc": "artist-rels+label-rels+release-group-rels+url-rels+tags+genres+aliases"},
        )
        self._cache_set(cache_key, data)
        return data

    def get_artist_relations(self, mbid: str) -> list[dict[str, Any]]:
        """Fetch artist-artist relations from MusicBrainz.

        Returns a list of dicts with keys:
            type: str          # relation type, e.g. "member of band"
            artist_mbid: str   # the *other* artist's MBID
            artist_name: str   # the *other* artist's name
        """
        cache_key = normalized_cache_key("artist-relations-v1", artist_id=mbid)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            f"/artist/{mbid}",
            {"fmt": "json", "inc": "artist-rels"},
        )
        if data is None:
            return []
        relations: list[dict[str, Any]] = []
        for rel in data.get("relations", []) or []:
            if rel.get("direction") == "backward":
                continue
            other = rel.get("artist", {})
            if not other:
                continue
            relations.append({
                "type": rel.get("type", ""),
                "artist_mbid": other.get("id"),
                "artist_name": other.get("name", ""),
            })
        self._cache_set(cache_key, relations)
        return relations

    def browse_release_groups(self, mbid: str) -> list[dict[str, Any]]:
        cache_key = normalized_cache_key("release-groups-v3", artist_id=mbid)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            "/release-group",
            {"artist": mbid, "fmt": "json", "limit": 100, "offset": 0, "inc": "artist-credits+tags+genres"},
        )
        if data is None:
            return []
        groups = data.get("release-groups", [])
        self._cache_set(cache_key, groups)
        return groups

    def search_releases_by_label(self, label_name: str, limit: int = 25) -> list[dict[str, Any]]:
        label_name = (label_name or "").strip()
        if not label_name:
            return []
        cache_key = normalized_cache_key("label-releases-v1", label=label_name, limit=limit)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            "/release",
            {
                "query": f'label:"{_mb_query_escape(label_name)}"',
                "fmt": "json",
                "limit": min(max(limit, 1), 100),
            },
        )
        if data is None:
            return []
        releases = data.get("releases", []) or []
        self._cache_set(cache_key, releases)
        return releases

    def lookup_recording_by_isrc(self, isrc: str) -> dict[str, Any] | None:
        """Resolve an ISRC to a MusicBrainz recording, release, release-group, and artist."""
        isrc = (isrc or "").strip()
        if not isrc:
            return None
        cache_key = normalized_cache_key("isrc-lookup-v1", isrc=isrc.upper())
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            f"/isrc/{isrc.upper()}",
            {"fmt": "json", "inc": "releases+artist-credits"},
        )
        recordings = (data or {}).get("recordings", [])
        if not recordings:
            self._cache_set(cache_key, None)
            return None
        # Pick the recording with the most releases as the canonical one
        best = max(recordings, key=lambda r: len(r.get("releases", [])), default=recordings[0])
        releases = best.get("releases", [])
        release = releases[0] if releases else {}
        credits = best.get("artist-credit", [])
        artist_credit = credits[0] if credits else {}
        artist = artist_credit.get("artist", {})
        rg = release.get("release-group", {})
        result = {
            "recording_mbid": best.get("id"),
            "release_mbid": release.get("id"),
            "release_group_mbid": rg.get("id"),
            "artist_mbid": artist.get("id"),
            "artist_name": artist.get("name", ""),
        }
        self._cache_set(cache_key, result)
        return result

    def lookup_release_by_upc(self, upc: str) -> dict[str, Any] | None:
        """Resolve a UPC/barcode to a MusicBrainz release and release-group."""
        upc = (upc or "").strip()
        if not upc:
            return None
        cache_key = normalized_cache_key("upc-lookup-v1", upc=upc)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            "/release",
            {"barcode": upc, "fmt": "json", "inc": "release-groups+artist-credits"},
        )
        releases = (data or {}).get("releases", [])
        if not releases:
            self._cache_set(cache_key, None)
            return None
        release = releases[0]
        rg = release.get("release-group", {})
        credits = release.get("artist-credit", [])
        artist_credit = credits[0] if credits else {}
        artist = artist_credit.get("artist", {})
        result = {
            "release_mbid": release.get("id"),
            "release_group_mbid": rg.get("id"),
            "artist_mbid": artist.get("id"),
            "artist_name": artist.get("name", ""),
        }
        self._cache_set(cache_key, result)
        return result

    def search_recording(self, artist: str, title: str, duration_ms: int | None = None) -> dict[str, Any] | None:
        """Resolve by artist + track title, with optional duration confirmation."""
        artist = (artist or "").strip()
        title = (title or "").strip()
        if not artist or not title:
            return None
        cache_key = normalized_cache_key("recording-search-v1", artist=artist, title=title, duration_ms=duration_ms)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        query = f'recording:"{_mb_query_escape(title)}" AND artist:"{_mb_query_escape(artist)}"'
        data = self._get("/recording", {"query": query, "fmt": "json", "limit": 5})
        recordings = (data or {}).get("recordings", [])
        if not recordings:
            self._cache_set(cache_key, None)
            return None
        # If duration provided, prefer recordings within 5 seconds
        if duration_ms is not None:
            def _dur_delta(r: dict) -> int:
                return abs((r.get("length") or 0) - duration_ms)
            within = [r for r in recordings if abs((r.get("length") or 0) - duration_ms) <= 5000]
            best = min(within, key=_dur_delta) if within else recordings[0]
        else:
            best = recordings[0]
        releases = best.get("releases", [])
        release = releases[0] if releases else {}
        rg = release.get("release-group", {})
        credits = best.get("artist-credit", [])
        artist_credit = credits[0] if credits else {}
        mb_artist = artist_credit.get("artist", {})
        result = {
            "recording_mbid": best.get("id"),
            "release_mbid": release.get("id"),
            "release_group_mbid": rg.get("id"),
            "artist_mbid": mb_artist.get("id"),
            "artist_name": mb_artist.get("name", artist),
            "duration_ms": best.get("length"),
        }
        self._cache_set(cache_key, result)
        return result

    def search_releases(self, query: str, limit: int = 25) -> list[dict[str, Any]]:
        """Search for releases by query string.
        
        Args:
            query: MusicBrainz search query string.
            limit: Maximum number of results to return.
            
        Returns:
            List of release search results.
        """
        cache_key = normalized_cache_key("release-search-v1", query=query, limit=limit)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        data = self._get(
            "/release",
            {
                "query": query,
                "fmt": "json",
                "limit": min(max(limit, 1), 100),
            },
        )
        if data is None:
            return []
        releases = data.get("releases", []) or []
        self._cache_set(cache_key, releases)
        return releases

    def release_tracks_for_group(self, release_group_id: str, cap: int = 10) -> list[ReleaseTrack]:
        cache_key = normalized_cache_key("release-tracks-v2", release_group_id=release_group_id)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return [ReleaseTrack.model_validate(item) for item in cached]
        data = self._get(
            "/release",
            {
                "release-group": release_group_id,
                "fmt": "json",
                "limit": 10,
                "inc": "media+recordings+artist-credits+isrcs",
            },
        )
        if data is None:
            return []
        release = _best_release_with_tracks(data.get("releases", []) or [])
        tracks = _tracks_from_release(release, cap=cap) if release else []
        # Always extract ISRCs directly from MusicBrainz results
        for track in tracks:
            if not track.resolution_source:
                track.resolution_source = "musicbrainz_tracklist"
            if not track.resolution_note:
                track.resolution_note = "Resolved directly from MusicBrainz release data."
        self._cache_set(cache_key, [track.model_dump(mode="json") for track in tracks])
        return tracks

    def parse_relationships(self, artist_data: dict[str, Any]) -> tuple[list[str], list[str], list[str], list[str]]:
        related_acts: list[str] = []
        collaborators: list[str] = []
        labels: list[str] = []
        notes: list[str] = []
        for rel in artist_data.get("relations", []) or []:
            rel_type = rel.get("type", "")
            other_name = safe_get(rel, "artist", "name")
            if other_name:
                if rel_type in {
                    "member of band",
                    "collaboration",
                    "subgroup",
                    "founder",
                    "instrumental supporting musician",
                    "vocal supporting musician",
                }:
                    collaborators.append(other_name)
                elif rel_type in {"member of", "tribute to", "support act", "split", "renamed into"}:
                    related_acts.append(other_name)
                else:
                    notes.append(f"{rel_type}: {other_name}")
            label_name = safe_get(rel, "label", "name")
            if label_name:
                labels.append(label_name)
        return dedupe(related_acts), dedupe(collaborators), dedupe(labels), dedupe(notes)

    def _get(self, path: str, params: dict[str, Any]) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        self._respect_rate_limit()
        try:
            started = time.monotonic()
            self.api_calls = getattr(self, "api_calls", 0) + 1
            response = self.client.get(f"{MUSICBRAINZ_BASE}{path}", params=params)
            self.request_time_seconds = float(getattr(self, "request_time_seconds", 0.0) or 0.0) + (time.monotonic() - started)
            if response.status_code in {429, 503}:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="MusicBrainz",
                        operation=path,
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            return response.json()
        except Exception as exc:
            if is_timeout_error(exc):
                self.timeout_events = int(getattr(self, "timeout_events", 0) or 0) + 1
            if is_network_error(exc):
                self._disabled_by_rate_limit = True
                issue = ProviderRateLimit(
                    provider="MusicBrainz",
                    operation=path,
                    retry_after_seconds=None,
                    recoverable=False,
                    error_message=format_network_error("MusicBrainz", path),
                    error_kind="network_error",
                )
                self.rate_limit_warnings.append(issue)
                return None
            rate_limit = rate_limit_from_exception("MusicBrainz", path, exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def _respect_rate_limit(self) -> None:
        elapsed = time.monotonic() - self._last_request_at
        if elapsed < 1.1:
            time.sleep(1.1 - elapsed)
        self._last_request_at = time.monotonic()

    def _cache_get(self, cache_key: str) -> Any | None:
        if not self.storage:
            return None
        if getattr(self.settings, "force_refresh", False):
            return None
        return self.storage.get_cache("musicbrainz", cache_key)

    def _cache_set(self, cache_key: str, value: Any) -> None:
        if self.storage:
            self.storage.set_cache("musicbrainz", cache_key, value, self.settings.musicbrainz_cache_ttl_seconds)

    def _fallback_artist_search_via_recordings(self, name: str) -> list[dict[str, Any]]:
        """Fallback search for artists by searching recordings and extracting artist info."""
        escaped = _mb_query_escape(name)
        query = f'artist:"{escaped}"'
        data = self._get("/recording", {"query": query, "fmt": "json", "limit": 10})
        recordings = (data or {}).get("recordings", [])
        artists: list[dict[str, Any]] = []
        seen_ids = set()
        for recording in recordings:
            for credit in recording.get("artist-credit", []):
                artist = credit.get("artist", {})
                if artist and artist.get("id") not in seen_ids:
                    seen_ids.add(artist.get("id"))
                    # Simulate artist search result format
                    artists.append({
                        "id": artist.get("id"),
                        "name": artist.get("name", name),
                        "score": 80,  # Lower score for fallback
                        "country": artist.get("country", ""),
                        "type": artist.get("type", ""),
                        "tags": artist.get("tags", []),
                    })
                    if len(artists) >= 5:  # Limit to 5 artists
                        break
            if len(artists) >= 5:
                break
        return artists

    def _direct_artist_lookup(self, name: str) -> list[dict[str, Any]]:
        """Direct database lookup by name (bypasses Lucene index).
        
        This method performs a direct lookup using the MusicBrainz API's
        artist endpoint with exact name matching. This is useful when
        Lucene-indexed searches fail for specific artists.
        
        Args:
            name: The artist name to look up.
            
        Returns:
            List of artist dictionaries matching the exact name, or empty list if not found.
        """
        escaped = _mb_query_escape(name)
        # Use exact name match query - this queries the database directly
        # rather than relying on the Lucene index
        query = f'artist:"{escaped}"'
        data = self._get("/artist", {"query": query, "fmt": "json", "limit": 10})
        artists = (data or {}).get("artists", [])
        if not artists:
            # Try without quotes for direct database lookup
            query = f'name:{escaped}'
            data = self._get("/artist", {"query": query, "fmt": "json", "limit": 10})
            artists = (data or {}).get("artists", [])
        if not artists:
            # Try searching by sortname as a last resort
            query = f'sortname:"{escaped}"'
            data = self._get("/artist", {"query": query, "fmt": "json", "limit": 10})
            artists = (data or {}).get("artists", [])
        # Format results to match search_artist expected format
        result: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for artist in artists:
            artist_id = artist.get("id", "")
            if artist_id and artist_id not in seen_ids:
                seen_ids.add(artist_id)
                result.append({
                    "id": artist.get("id"),
                    "name": artist.get("name", name),
                    "score": 100 if normalize_key(artist.get("name", "")) == normalize_key(name) else 50,
                    "country": artist.get("country", ""),
                    "type": artist.get("type", ""),
                    "tags": artist.get("tags", []),
                })
        return result[:10]  # Limit to 10 results


def _retry_after(response: httpx.Response) -> int | None:
    value = response.headers.get("Retry-After")
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None


def _best_release_with_tracks(releases: list[dict[str, Any]]) -> dict[str, Any] | None:
    releases_with_tracks = [
        release
        for release in releases
        if any((medium.get("tracks") or []) for medium in release.get("media", []) or [])
    ]
    if not releases_with_tracks:
        return None

    def sort_key(release: dict[str, Any]) -> tuple[int, str, str]:
        status_score = 0 if release.get("status") == "Official" else 1
        date = release.get("date") or "9999"
        country = release.get("country") or "ZZ"
        return status_score, date, country

    return sorted(releases_with_tracks, key=sort_key)[0]


def _tracks_from_release(release: dict[str, Any], cap: int) -> list[ReleaseTrack]:
    tracks: list[ReleaseTrack] = []
    release_date = release.get("date") or None
    for medium in release.get("media", []) or []:
        for item in medium.get("tracks", []) or []:
            recording = item.get("recording") or {}
            title = item.get("title") or recording.get("title") or ""
            artists = _artist_credit_name(recording.get("artist-credit") or item.get("artist-credit") or [])
            isrcs = recording.get("isrcs") or []
            isrc = isrcs[0] if isrcs else None
            track = ReleaseTrack(
                title=title,
                artists=artists,
                track_number=_track_number(item),
                release_date=release_date,
                isrc=isrc,
                isrc_source="musicbrainz" if isrc else "m_nF",
            )
            if track.title and track.artists:
                tracks.append(track)
            if len(tracks) >= cap:
                return tracks
    return tracks


def _mb_query_escape(value: str) -> str:
    """Escape special characters for MusicBrainz Lucene query parser.
    
    This function handles edge cases for names with special characters,
    diacritics, and other characters that might affect query parsing.
    
    Args:
        value: The string to escape.
        
    Returns:
        The escaped string safe for use in MusicBrainz queries.
    """
    if not value:
        return ""
    # Escape backslash first to avoid double escaping
    escaped = value.replace("\\", "\\\\")
    # Escape double quotes
    escaped = escaped.replace('"', '\\"')
    # Escape Lucene special characters
    for ch in ["+", "-", "&&", "||", "!", "(", ")", "{", "}", "[", "]", "^", "~", "*", "?", ":", "/"]:
        escaped = escaped.replace(ch, f"\\{ch}")
    return escaped


def _artist_query_variants(name: str) -> list[str]:
    escaped = _mb_query_escape(name)
    # Generate query variants with increasing specificity to handle edge cases
    # where common names might be filtered out by the standard index
    variants: list[str] = []
    
    # 1. Exact artist name match (quoted)
    variants.append(f'artist:"{escaped}"')
    
    # 2. Fuzzy match on artist name (handles typos)
    variants.append(f'artist:"{escaped}"~')
    
    # 3. Prefix match on artist name
    variants.append(f'artist:{escaped}*')
    
    # 4. Alias search (handles stage names and aliases)
    variants.append(f'alias:"{escaped}"')
    
    # 5. Sortname search (handles sorting variations)
    variants.append(f'sortname:"{escaped}"')
    
    # 6. Fuzzy alias search
    variants.append(f'alias:"{escaped}"~')
    
    # 7. Fuzzy sortname search
    variants.append(f'sortname:"{escaped}"~')
    
    # 8. Combined field search (OR across all name fields)
    variants.append(f'artist:({escaped}) OR alias:({escaped}) OR sortname:({escaped})')
    
    # 9. Name field search (direct database lookup)
    variants.append(f'name:{escaped}')
    
    # 10. Sortname field search (direct database lookup)
    variants.append(f'sortname:{escaped}')
    
    # 11. Fuzzy sortname field search
    variants.append(f'sortname:{escaped}~')
    
    # 12. Name field with fuzzy matching
    variants.append(f'name:{escaped}~')
    
    # 13. Combined name and sortname search
    variants.append(f'name:({escaped}) OR sortname:({escaped})')
    
    # 14. Fuzzy search on name (handles typos and variations)
    variants.append(f'name:"{escaped}"~')
    
    # 15. Exact phrase search across all fields (last resort)
    variants.append(f'"{escaped}"')
    
    return variants


def _artist_credit_name(artist_credit: list[dict[str, Any]]) -> str:
    names: list[str] = []
    for item in artist_credit:
        name = item.get("name") or safe_get(item, "artist", "name")
        joinphrase = item.get("joinphrase") or ""
        if name:
            names.append(f"{name}{joinphrase}")
    return "".join(names).strip()


def _track_number(track: dict[str, Any]) -> int | None:
    for key in ("position", "number"):
        try:
            return int(track.get(key))
        except (TypeError, ValueError):
            continue
    return None
