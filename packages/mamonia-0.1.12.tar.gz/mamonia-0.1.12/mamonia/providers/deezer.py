from __future__ import annotations

import time
from typing import Any

import httpx

from mamonia.config import Settings
from mamonia.providers import (
    ProviderRateLimit,
    format_network_error,
    httpx_timeout_from_settings,
    is_network_error,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import normalized_cache_key, safe_get


DEEZER_BASE = "https://api.deezer.com/"


class DeezerProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None):
        self.settings = settings
        self.storage = storage
        self.client = httpx.Client(timeout=httpx_timeout_from_settings(settings), trust_env=False)
        self._last_request_at = 0.0
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings: list[ProviderRateLimit] = []

    @property
    def available(self) -> bool:
        return True

    def search_artist(self, name: str) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("artist-search-v1", artist=name)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{DEEZER_BASE}search/artist", params={"q": name, "limit": 5})
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist search",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            artists = safe_get(data, "data", default=[]) or []
            if not artists:
                self._cache_set(cache_key, None)
                return None
            result = artists[0]
            if self.storage:
                self.storage.set_cache("deezer", cache_key, result, self.settings.deezer_cache_ttl_seconds)
            return result
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist search",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("Deezer", "artist search"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("Deezer", "artist search", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def artist_details(self, artist_id: int) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("artist-details-v1", artist_id=artist_id)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{DEEZER_BASE}artist/{artist_id}")
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist details",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            if self.storage:
                self.storage.set_cache("deezer", cache_key, data, self.settings.deezer_cache_ttl_seconds)
            return data
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist details",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("Deezer", "artist details"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("Deezer", "artist details", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def search_track(self, query: str) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("track-search-v1", query=query)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{DEEZER_BASE}search/track", params={"q": query, "limit": 10})
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="track search",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            if self.storage:
                self.storage.set_cache("deezer", cache_key, data, self.settings.deezer_cache_ttl_seconds)
            return data
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="track search",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("Deezer", "track search"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("Deezer", "track search", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def _respect_rate_limit(self) -> None:
        elapsed = time.monotonic() - self._last_request_at
        if elapsed < 0.2:
            time.sleep(0.2 - elapsed)
        self._last_request_at = time.monotonic()

    def _cache_get(self, cache_key: str) -> Any | None:
        if not self.storage:
            return None
        if getattr(self.settings, "force_refresh", False):
            return None
        return self.storage.get_cache("deezer", cache_key)

    def _cache_set(self, cache_key: str, value: Any) -> None:
        if self.storage:
            self.storage.set_cache("deezer", cache_key, value, self.settings.deezer_cache_ttl_seconds)

    def browse_artist_albums(self, artist_id: int) -> list[dict[str, Any]]:
        if self._disabled_by_rate_limit:
            return []
        cache_key = normalized_cache_key("artist-albums-v1", artist_id=artist_id)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{DEEZER_BASE}artist/{artist_id}/albums")
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist albums",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return []
            response.raise_for_status()
            data = response.json()
            albums = safe_get(data, "data", default=[]) or []
            if self.storage:
                self.storage.set_cache("deezer", cache_key, albums, self.settings.deezer_cache_ttl_seconds)
            return albums
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Deezer",
                        operation="artist albums",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("Deezer", "artist albums"),
                        error_kind="network_error",
                    )
                )
                return []
            rate_limit = rate_limit_from_exception("Deezer", "artist albums", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return []

    def _record_rate_limit(self, rate_limit: ProviderRateLimit) -> None:
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True


def _retry_after(response: httpx.Response) -> int | None:
    value = response.headers.get("Retry-After")
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None
