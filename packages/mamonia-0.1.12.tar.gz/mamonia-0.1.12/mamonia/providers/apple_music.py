from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import httpx

from mamonia.config import Settings
from mamonia.input import extract_apple_music_playlist_id
from mamonia.models import InputTrack
from mamonia.providers import ProviderRateLimit, ProviderUnavailable, rate_limit_from_exception
from mamonia.providers import httpx_timeout_from_settings


APPLE_MUSIC_BASE = "https://api.music.apple.com/v1"


@dataclass(frozen=True)
class AppleMusicUserPlaylist:
    id: str
    name: str
    tracks: int | None = None


@dataclass(frozen=True)
class AppleMusicPlaylistCreationResult:
    created: bool
    url: str | None = None
    reason: str | None = None
    playlist_id: str | None = None


class AppleMusicProvider:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = httpx.Client(timeout=httpx_timeout_from_settings(settings), trust_env=False)
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self._disabled_by_rate_limit = False

    @property
    def available(self) -> bool:
        return bool(self.settings.apple_music_configured)

    def _headers(self) -> dict[str, str]:
        if not self.available:
            raise ProviderUnavailable(
                "Apple Music credentials are missing. Set APPLE_MUSIC_DEVELOPER_TOKEN and APPLE_MUSIC_USER_TOKEN."
            )
        return {
            "Authorization": f"Bearer {self.settings.apple_music_developer_token}",
            "Music-User-Token": self.settings.apple_music_user_token,
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        operation: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        if self._disabled_by_rate_limit:
            raise ProviderUnavailable("Apple Music API is paused for this run due to a previous rate limit.")
        url = f"{APPLE_MUSIC_BASE}{path}"
        response = self.client.request(method, url, headers=self._headers(), params=params, json=json)
        try:
            response.raise_for_status()
        except Exception as exc:
            issue = rate_limit_from_exception("Apple Music", operation, exc)
            if issue:
                self.rate_limit_warnings.append(issue)
                if not issue.should_auto_wait:
                    self._disabled_by_rate_limit = True
                if issue.error_kind == "rate_limited":
                    raise issue
                if issue.error_kind in {"auth_failed", "insufficient_scope", "forbidden_access", "permission_denied"}:
                    raise ProviderUnavailable(str(issue)) from exc
            raise ProviderUnavailable(f"Apple Music {operation} failed: {exc}") from exc
        return response

    def fetch_user_playlists(self) -> list[AppleMusicUserPlaylist]:
        playlists: list[AppleMusicUserPlaylist] = []
        next_url = f"{APPLE_MUSIC_BASE}/me/library/playlists"
        while next_url:
            response = self.client.get(next_url, headers=self._headers())
            try:
                response.raise_for_status()
            except Exception as exc:
                issue = rate_limit_from_exception("Apple Music", "fetching user playlists", exc)
                if issue:
                    self.rate_limit_warnings.append(issue)
                    if issue.error_kind == "rate_limited":
                        raise issue
                raise ProviderUnavailable(f"Failed to fetch Apple Music playlists: {exc}") from exc
            payload = response.json()
            for item in payload.get("data", []) or []:
                attributes = item.get("attributes", {}) or {}
                tracks_rel = (item.get("relationships", {}) or {}).get("tracks", {}) or {}
                tracks_meta = tracks_rel.get("meta", {}) if isinstance(tracks_rel, dict) else {}
                playlists.append(
                    AppleMusicUserPlaylist(
                        id=str(item.get("id") or ""),
                        name=str(attributes.get("name") or item.get("id") or ""),
                        tracks=tracks_meta.get("total"),
                    )
                )
            next_url = ((payload.get("next") or "") or "").strip()
            if next_url and next_url.startswith("/"):
                next_url = f"{APPLE_MUSIC_BASE}{next_url}"
            elif not next_url:
                next_url = ""
        return [p for p in playlists if p.id]

    def fetch_playlist_name(self, playlist_url_or_id: str) -> str | None:
        playlist_id = extract_apple_music_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            response = self._request("GET", f"/me/library/playlists/{quote(playlist_id)}", operation="fetching playlist")
            payload = response.json()
            data = payload.get("data", []) or []
            if not data:
                return None
            attributes = (data[0] or {}).get("attributes", {}) or {}
            name = attributes.get("name")
            return str(name) if name else None
        except Exception:
            return None

    def fetch_playlist_tracks(self, playlist_url_or_id: str) -> list[InputTrack]:
        playlist_id = extract_apple_music_playlist_id(playlist_url_or_id) or playlist_url_or_id
        tracks: list[InputTrack] = []
        next_url = f"{APPLE_MUSIC_BASE}/me/library/playlists/{quote(playlist_id)}/tracks"
        while next_url:
            response = self.client.get(next_url, headers=self._headers())
            try:
                response.raise_for_status()
            except Exception as exc:
                issue = rate_limit_from_exception("Apple Music", "reading playlist", exc)
                if issue:
                    self.rate_limit_warnings.append(issue)
                    if issue.error_kind == "rate_limited":
                        raise issue
                raise ProviderUnavailable(f"Failed to fetch Apple Music playlist tracks: {exc}") from exc
            payload = response.json()
            for item in payload.get("data", []) or []:
                attributes = item.get("attributes", {}) or {}
                artist = str(attributes.get("artistName") or "").strip()
                if not artist:
                    continue
                title = str(attributes.get("name") or "").strip()
                album = str(attributes.get("albumName") or "").strip() or None
                track_id = str(item.get("id") or "").strip() or None
                isrc = str(attributes.get("isrc") or "").strip() or None
                tracks.append(
                    InputTrack(
                        artist=artist,
                        artists=[artist],
                        track=title,
                        album=album,
                        apple_music_track_id=track_id,
                        isrc=isrc,
                    )
                )
            next_url = ((payload.get("next") or "") or "").strip()
            if next_url and next_url.startswith("/"):
                next_url = f"{APPLE_MUSIC_BASE}{next_url}"
            elif not next_url:
                next_url = ""
        return tracks

    def create_playlist(self, name: str, description: str, track_ids: list[str]) -> AppleMusicPlaylistCreationResult:
        clean_ids = [str(i).strip() for i in dict.fromkeys(track_ids) if str(i).strip()]
        if not clean_ids:
            return AppleMusicPlaylistCreationResult(created=False, reason="no_ids")
        body = {
            "attributes": {"name": name, "description": description},
            "relationships": {"tracks": {"data": [{"id": tid, "type": "songs"} for tid in clean_ids]}},
        }
        try:
            response = self._request(
                "POST",
                "/me/library/playlists",
                operation="creating playlist",
                json=body,
            )
            data = (response.json().get("data", []) or [{}])[0]
            playlist_id = str(data.get("id") or "").strip() or None
            return AppleMusicPlaylistCreationResult(
                created=True,
                playlist_id=playlist_id,
                url=f"https://music.apple.com/library/playlist/{playlist_id}" if playlist_id else None,
            )
        except ProviderRateLimit:
            return AppleMusicPlaylistCreationResult(created=False, reason="rate_limited")
        except Exception as exc:
            return AppleMusicPlaylistCreationResult(created=False, reason=str(exc))

    def add_tracks_to_playlist(self, playlist_id: str, track_ids: list[str]) -> AppleMusicPlaylistCreationResult:
        clean_ids = [str(i).strip() for i in dict.fromkeys(track_ids) if str(i).strip()]
        if not clean_ids:
            return AppleMusicPlaylistCreationResult(created=False, reason="no_ids")
        body = {"data": [{"id": tid, "type": "songs"} for tid in clean_ids]}
        try:
            self._request(
                "POST",
                f"/me/library/playlists/{quote(playlist_id)}/tracks",
                operation="adding tracks to playlist",
                json=body,
            )
            return AppleMusicPlaylistCreationResult(
                created=True,
                playlist_id=playlist_id,
                url=f"https://music.apple.com/library/playlist/{playlist_id}",
            )
        except ProviderRateLimit:
            return AppleMusicPlaylistCreationResult(created=False, reason="rate_limited")
        except Exception as exc:
            return AppleMusicPlaylistCreationResult(created=False, reason=str(exc))

    def lookup_track_id(self, artist: str, title: str, isrc: str | None = None) -> str | None:
        if self._disabled_by_rate_limit:
            return None
        params = {"types": "songs", "limit": "5"}
        if self.settings.apple_music_storefront:
            params["l"] = self.settings.apple_music_storefront
        try:
            if isrc:
                response = self._request(
                    "GET",
                    "/catalog/us/songs",
                    operation="ISRC track lookup",
                    params={"filter[isrc]": isrc, "limit": "2"},
                )
                items = (response.json().get("data", []) or [])
                if items:
                    return str(items[0].get("id") or "") or None
        except Exception:
            pass

        try:
            query = f"{artist} {title}".strip()
            response = self._request(
                "GET",
                "/catalog/us/search",
                operation="track search",
                params={**params, "term": query},
            )
            songs = (((response.json().get("results", {}) or {}).get("songs", {}) or {}).get("data", []) or [])
            if songs:
                return str(songs[0].get("id") or "") or None
        except Exception:
            return None
        return None

    def lookup_track_ids_by_isrc(self, isrc_values: list[str]) -> dict[str, str]:
        """Batch-resolve Apple Music song IDs for up to 25 ISRC values per request."""
        if self._disabled_by_rate_limit:
            return {}
        normalized = [str(value).strip().upper() for value in isrc_values if str(value).strip()]
        unique = list(dict.fromkeys(normalized))
        if not unique:
            return {}
        resolved: dict[str, str] = {}
        storefront = self.settings.apple_music_storefront or "us"
        for idx in range(0, len(unique), 25):
            chunk = unique[idx:idx + 25]
            try:
                response = self._request(
                    "GET",
                    f"/catalog/{storefront}/songs",
                    operation="batch ISRC track lookup",
                    params={
                        "filter[isrc]": ",".join(chunk),
                        "limit": "25",
                    },
                )
            except Exception:
                continue
            payload = response.json() or {}
            for item in payload.get("data", []) or []:
                if not isinstance(item, dict):
                    continue
                song_id = str(item.get("id") or "").strip()
                attributes = item.get("attributes") or {}
                isrc = str(attributes.get("isrc") or "").strip().upper()
                if song_id and isrc and isrc not in resolved:
                    resolved[isrc] = song_id
        return resolved
