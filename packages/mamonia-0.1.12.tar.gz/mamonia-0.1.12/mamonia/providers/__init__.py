from __future__ import annotations

import re
import socket
import time
from dataclasses import dataclass
from typing import Any

import httpx


class ProviderUnavailable(RuntimeError):
    """Raised when an optional provider dependency or credential is unavailable."""


MAX_AUTO_RETRY_SECONDS = 60


@dataclass
class ProviderRateLimit(RuntimeError):
    """Raised or recorded when a provider asks Mamonia to slow down."""

    provider: str
    operation: str
    retry_after_seconds: int | None = None
    recoverable: bool = True
    is_permission_error: bool = False
    error_message: str | None = None
    status_code: int | None = None
    error_kind: str | None = None
    action: str | None = None  # e.g., "RECONNECT_SPOTIFY", "CONNECT_SPOTIFY", "CHECK_PLAYLIST_ACCESS"

    @property
    def should_auto_wait(self) -> bool:
        return self.retry_after_seconds is not None and self.retry_after_seconds <= MAX_AUTO_RETRY_SECONDS

    def __str__(self) -> str:
        if self.error_kind == "network_error":
            return self.error_message or f"{self.provider} network error while {self.operation}."
        if self.error_kind == "auth_failed":
            msg = f"{self.provider} authentication failed while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "insufficient_scope":
            msg = f"{self.provider} token is missing required scope while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "forbidden_access":
            msg = f"{self.provider} denied access while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.is_permission_error:
            msg = f"{self.provider} permission denied while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "content_unavailable":
            msg = f"{self.provider} content unavailable while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "invalid_request":
            msg = f"{self.provider} rejected the request while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "not_found":
            msg = f"{self.provider} resource not found while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        if self.error_kind == "server_error":
            msg = f"{self.provider} server error while {self.operation}."
            if self.error_message:
                msg += f" {self.error_message}"
            return msg
        retry = ""
        if self.retry_after_seconds is not None:
            retry = f" Retry after about {format_retry_after(self.retry_after_seconds)}."
        msg = f"{self.provider} rate limit while {self.operation}.{retry}"
        if self.error_message:
            msg += f" {self.error_message}"
        return msg


def format_retry_after(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {sec}s" if sec else f"{minutes}m"
    hours, minute = divmod(minutes, 60)
    return f"{hours}h {minute}m" if minute else f"{hours}h"


def retry_after_from_headers(headers: Any) -> int | None:
    if not headers:
        return None
    value = None
    for key in ("Retry-After", "retry-after"):
        try:
            value = headers.get(key)
        except Exception:
            value = None
        if value:
            break
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def extract_error_message(exc: Exception) -> str | None:
    """Extract error message from provider exception response."""
    response = getattr(exc, "response", None)
    if response:
        try:
            data = response.json() if hasattr(response, "json") else None
            if data:
                error = data.get("error", {})
                if isinstance(error, dict):
                    return error.get("message")
                elif isinstance(error, str):
                    return error
        except Exception:
            pass
    return None


def rate_limit_from_exception(provider: str, operation: str, exc: Exception) -> ProviderRateLimit | None:
    response = getattr(exc, "response", None)
    status = getattr(exc, "http_status", None) or getattr(response, "status_code", None)
    headers = getattr(exc, "headers", None) or getattr(response, "headers", None)
    retry_after = retry_after_from_headers(headers)
    message = str(exc)
    error_message = extract_error_message(exc)
    if retry_after is None:
        match = re.search(r"after:\s*(\d+)\s*s", message, flags=re.IGNORECASE)
        if match:
            retry_after = int(match.group(1))
    
    error_text = (error_message or message or "").lower()

    # Handle specific HTTP error codes
    if status == 400:
        error_kind = "content_unavailable" if any(
            token in error_text
            for token in ("market", "country", "not available", "content unavailable")
        ) else "invalid_request"
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=None,
            recoverable=False,
            error_message=error_message or "Invalid request parameters",
            status_code=status,
            error_kind=error_kind,
        )
    if status == 401:
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=None,
            recoverable=False,
            error_message=error_message or "Authentication failed - token may be expired",
            status_code=status,
            error_kind="auth_failed",
        )
    if status == 403:
        error_kind = "permission_denied"
        if "insufficient client scope" in error_text or "scope" in error_text:
            error_kind = "insufficient_scope"
        elif "playlist" in operation and any(
            token in error_text
            for token in ("forbidden", "private", "not accessible", "owner", "collaborative", "permission")
        ):
            error_kind = "forbidden_access"
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=retry_after,
            is_permission_error=True,
            error_message=error_message,
            status_code=status,
            error_kind=error_kind,
        )
    if status == 404:
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=None,
            recoverable=False,
            error_message=error_message or "Resource not found",
            status_code=status,
            error_kind="not_found",
        )
    if status == 429 or "rate/request limit" in message.lower() or "rate limit" in message.lower():
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=retry_after,
            error_message=error_message,
            status_code=status or 429,
            error_kind="rate_limited",
        )
    if status in (500, 502, 503, 504):
        return ProviderRateLimit(
            provider=provider,
            operation=operation,
            retry_after_seconds=retry_after or 5,
            error_message=error_message or f"Server error ({status})",
            status_code=status,
            error_kind="server_error",
        )
    return None


def exponential_backoff_with_retry_after(retry_after: int | None, attempt: int) -> int:
    """
    Calculate delay using exponential backoff with Retry-After as primary source.
    If Retry-After is provided, use it. Otherwise, use exponential backoff.
    """
    if retry_after is not None:
        return retry_after
    # Exponential backoff: 1s, 2s, 4s, 8s, 16s, 32s, 60s max
    backoff = min(2 ** attempt, 60)
    return backoff


def retry_with_exponential_backoff(
    func,
    max_retries: int = 5,
    provider: str = "Provider",
    operation: str = "operation",
) -> Any:
    """
    Retry a function with exponential backoff on rate limit errors.
    """
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as exc:
            rate_limit = rate_limit_from_exception(provider, operation, exc)
            if rate_limit and rate_limit.retry_after_seconds is not None:
                if attempt == max_retries - 1:
                    raise
                delay = exponential_backoff_with_retry_after(rate_limit.retry_after_seconds, attempt)
                time.sleep(delay)
                continue
            raise
    return None


def is_network_error(exc: Exception) -> bool:
    """Check if exception is a network/connectivity error."""
    exc_name = exc.__class__.__name__
    return any(
        match in exc_name.lower()
        for match in (
            "nameresolution",
            "connectionerror",
            "gaierror",
            "timeout",
            "networkerror",
            "connectionrefused",
            "connectionreset",
        )
    ) or (
        isinstance(exc, OSError)
        and hasattr(exc, "errno")
        and exc.errno in (
            11001,  # Windows: WSAHOST_NOT_FOUND
            -2,     # gethostbyname failed
        )
    )


def format_network_error(provider: str, operation: str) -> str:
    """Format a user-friendly network error message."""
    return (
        f"Could not reach {provider} ({operation}). "
        "Check your internet connection and firewall settings."
    )


def is_timeout_error(exc: Exception) -> bool:
    """Detect connect/read/write/pool timeout exceptions."""
    if isinstance(exc, TimeoutError):
        return True
    if isinstance(exc, httpx.TimeoutException):
        return True
    return "timeout" in exc.__class__.__name__.lower()


def httpx_timeout_from_settings(settings: Any) -> httpx.Timeout:
    """Build split timeout values from Settings with safe fallbacks."""
    connect = max(1.0, float(getattr(settings, "provider_http_connect_timeout_seconds", 5.0) or 5.0))
    read = max(1.0, float(getattr(settings, "provider_http_read_timeout_seconds", 10.0) or 10.0))
    write = max(1.0, float(getattr(settings, "provider_http_write_timeout_seconds", 10.0) or 10.0))
    pool = max(0.5, float(getattr(settings, "provider_http_pool_timeout_seconds", 5.0) or 5.0))
    return httpx.Timeout(connect=connect, read=read, write=write, pool=pool)
