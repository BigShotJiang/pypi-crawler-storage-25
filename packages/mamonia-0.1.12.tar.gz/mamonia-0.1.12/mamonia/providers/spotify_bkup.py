from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
import re
import random
import threading
import time
from typing import Any

from mamonia.config import Settings, is_valid_spotify_redirect_uri
from mamonia.input import extract_spotify_playlist_id
from mamonia.models import InputTrack, ReleaseTrack
from mamonia.providers import (
    ProviderRateLimit,
    ProviderUnavailable,
    exponential_backoff_with_retry_after,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import (
    chunked,
    keyword_query_variants,
    normalize_key,
    normalized_cache_key,
    normalize_variant_title,
    safe_get,
    split_artist_names,
)


# Keep user-scoped auth narrow and use client credentials for public catalog lookups.
SPOTIFY_READ_SCOPES = "playlist-read-private playlist-read-collaborative"
SPOTIFY_WRITE_SCOPES = "playlist-modify-private"
MISS_SENTINEL = {"__mamonia_miss": True}
REQUIRED_OPERATION_MAX_RETRIES = 3
CATALOG_OPERATION_MAX_RETRIES = 3
SPOTIFY_CATALOG_MAX_WORKERS = 4
SPOTIFY_CATALOG_MIN_INTERVAL_SECONDS = 0.05
_SPOTIFY_CATALOG_SEMAPHORE = threading.BoundedSemaphore(SPOTIFY_CATALOG_MAX_WORKERS)
_SPOTIFY_CATALOG_PACE_LOCK = threading.Lock()
_SPOTIFY_LAST_CATALOG_REQUEST_AT = 0.0


@dataclass(frozen=True)
class SpotifyOperationSpec:
    operation: str
    endpoint: str
    auth_mode: str
    scopes: str = ""
    user_specific: bool = False
    deprecated: bool = False


SPOTIFY_OPERATION_SPECS: dict[str, SpotifyOperationSpec] = {
    "read_playlist": SpotifyOperationSpec(
        operation="read_playlist",
        endpoint="GET /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_READ_SCOPES,
        user_specific=True,
    ),
    "check_playlist_access": SpotifyOperationSpec(
        operation="check_playlist_access",
        endpoint="GET /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_READ_SCOPES,
        user_specific=True,
    ),
    "search_artist": SpotifyOperationSpec(
        operation="search_artist",
        endpoint="GET /search?type=artist",
        auth_mode="client_credentials",
    ),
    "read_artist_details": SpotifyOperationSpec(
        operation="read_artist_details",
        endpoint="GET /artists/{id}",
        auth_mode="client_credentials",
    ),
    "search_album": SpotifyOperationSpec(
        operation="search_album",
        endpoint="GET /search?type=album",
        auth_mode="client_credentials",
    ),
    "read_album_tracks": SpotifyOperationSpec(
        operation="read_album_tracks",
        endpoint="GET /albums/{id}/tracks",
        auth_mode="client_credentials",
    ),
    "read_track_details": SpotifyOperationSpec(
        operation="read_track_details",
        endpoint="GET /tracks/{id}",
        auth_mode="client_credentials",
    ),
    "search_track": SpotifyOperationSpec(
        operation="search_track",
        endpoint="GET /search?type=track",
        auth_mode="client_credentials",
    ),
    "create_playlist": SpotifyOperationSpec(
        operation="create_playlist",
        endpoint="POST /me/playlists + POST /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_WRITE_SCOPES,
        user_specific=True,
    ),
}


@dataclass(frozen=True)
class SpotifyPlaylistCreationResult:
    created: bool
    url: str | None = None
    reason: str | None = None


class SpotifyProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None, progress=None):
        self.settings = settings
        self.storage = storage
        self.progress = progress
        self._client: Any | None = None
        self._user_clients: dict[str, Any] = {}
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self._disabled_by_rate_limit = False
        self.cache_hits = 0
        self.cache_misses = 0
        self.api_calls = 0
        self._isrc_lookups = 0
        self._isrc_misses = 0

    @property
    def available(self) -> bool:
        return bool(self.settings.spotify_client_id and self.settings.spotify_client_secret)

    def operation_spec(self, operation: str) -> SpotifyOperationSpec:
        return SPOTIFY_OPERATION_SPECS[operation]

    def client(self) -> Any:
        if self._client is not None:
            return self._client
        if not self.available:
            raise ProviderUnavailable(
                "Spotify credentials are missing. Set SPOTIPY_CLIENT_ID and SPOTIPY_CLIENT_SECRET."
            )
        try:
            import spotipy
            from spotipy.cache_handler import MemoryCacheHandler
            from spotipy.oauth2 import SpotifyClientCredentials
        except Exception as exc:
            raise ProviderUnavailable("spotipy is not installed. Run: pip install -e .") from exc

        auth = SpotifyClientCredentials(
            client_id=self.settings.spotify_client_id,
            client_secret=self.settings.spotify_client_secret,
            cache_handler=MemoryCacheHandler(),
        )
        timeout = max(1.0, float(getattr(self.settings, "provider_http_read_timeout_seconds", 10.0) or 10.0))
        self._client = spotipy.Spotify(
            auth_manager=auth,
            requests_timeout=timeout,
            retries=0,
            status_retries=0,
            status_forcelist=(500, 502, 503, 504),
        )
        return self._client

    def user_client(self, scopes: str) -> Any:
        cached = self._user_clients.get(scopes)
        if cached is not None:
            return cached
        if not self.settings.spotify_client_id:
            raise ProviderUnavailable(
                "Spotify client ID is missing. Set SPOTIPY_CLIENT_ID for Spotify playlist access."
            )
        if not is_valid_spotify_redirect_uri(self.settings.spotify_redirect_uri):
            raise ProviderUnavailable(
                "Spotify redirect URI must use HTTPS unless it is http://127.0.0.1 for local development."
            )
        try:
            import spotipy
            from spotipy.cache_handler import CacheFileHandler
            from spotipy.oauth2 import SpotifyPKCE
        except Exception as exc:
            raise ProviderUnavailable("spotipy is not installed. Run: pip install -e .") from exc

        auth = SpotifyPKCE(
            client_id=self.settings.spotify_client_id,
            redirect_uri=self.settings.spotify_redirect_uri,
            scope=scopes,
            cache_handler=CacheFileHandler(cache_path=str(self._scope_cache_path(scopes))),
            open_browser=True,
        )
        timeout = max(1.0, float(getattr(self.settings, "provider_http_read_timeout_seconds", 10.0) or 10.0))
        client = spotipy.Spotify(
            auth_manager=auth,
            requests_timeout=timeout,
            retries=0,
            status_retries=0,
            status_forcelist=(500, 502, 503, 504),
        )
        self._user_clients[scopes] = client
        return client

    def permission_guidance(self, operation: str) -> str:
        if "creating playlist" in operation:
            cache_path = self._scope_cache_path(self.operation_spec("create_playlist").scopes)
            return (
                "Re-authorize Spotify with playlist-modify access. "
                f"If you recently changed scopes, delete {cache_path} and rerun so Mamonia can request a fresh token."
            )
        if "playlist" in operation:
            cache_path = self._scope_cache_path(self.operation_spec("read_playlist").scopes)
            return (
                "Re-authorize Spotify with playlist-read access. "
                f"If you recently changed scopes, delete {cache_path} and rerun so Mamonia can request a fresh token."
            )
        return (
            "Spotify catalog lookups now use client credentials. "
            "If this keeps failing, re-check the app credentials and app restrictions in the Spotify developer dashboard."
        )

    def issue_guidance(self, issue: ProviderRateLimit) -> str:
        if issue.error_kind == "insufficient_scope":
            return self.permission_guidance(issue.operation)
        if issue.error_kind == "auth_failed":
            if "playlist" in issue.operation:
                cache_path = self._scope_cache_path(self.operation_spec("read_playlist").scopes)
                if "creating playlist" in issue.operation:
                    cache_path = self._scope_cache_path(self.operation_spec("create_playlist").scopes)
                return (
                    "Spotify authorization has expired or is invalid. "
                    f"Delete {cache_path} and rerun so Mamonia can request a fresh token."
                )
            return (
                "Spotify catalog lookups use client credentials. "
                "Re-check SPOTIPY_CLIENT_ID, SPOTIPY_CLIENT_SECRET, and any app restrictions in the Spotify developer dashboard."
            )
        if issue.error_kind == "forbidden_access" and "playlist" in issue.operation:
            return (
                "Make sure the authorized Spotify account can actually view this playlist. "
                "Private or restricted playlists must be accessible to the same Spotify user that just authorized Mamonia."
            )
        if issue.error_kind == "content_unavailable":
            return (
                "If you set SPOTIFY_MARKET or MAMONIA_SPOTIFY_MARKET, use a valid two-letter market code such as PL or US. "
                "Leave it unset to avoid market filtering."
            )
        if issue.error_kind == "invalid_request":
            return (
                "Spotify rejected the request parameters. "
                "If this persists, re-check the configured market code and update to the latest Mamonia build."
            )
        if issue.is_permission_error:
            return self.permission_guidance(issue.operation)
        return ""

    def fetch_playlist_tracks(self, playlist_url_or_id: str) -> list[InputTrack]:
        sp = self.user_client(self.operation_spec("read_playlist").scopes)
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        tracks: list[InputTrack] = []
        offset = 0
        while True:
            try:
                response = self._call_required_operation(
                    "reading playlist",
                    lambda: sp.playlist_items(playlist_id, limit=100, offset=offset, additional_types=("track",)),
                )
            except ProviderRateLimit:
                raise
            except Exception as exc:
                rate_limit = rate_limit_from_exception("Spotify", "reading playlist", exc)
                if rate_limit:
                    raise rate_limit from exc
                raise
            for item in response.get("items", []):
                track = playlist_item_track(item)
                if track.get("type") != "track":
                    continue
                artists = track.get("artists") or []
                if not artists:
                    continue
                artist_names = [artist.get("name", "") for artist in artists if artist.get("name")]
                tracks.append(
                    InputTrack(
                        artist=artist_names[0],
                        artists=artist_names,
                        track=track.get("name", ""),
                        album=safe_get(track, "album", "name"),
                        spotify_track_id=track.get("id"),
                        spotify_artist_ids=[artist["id"] for artist in artists if artist.get("id")],
                        spotify_album_id=safe_get(track, "album", "id"),
                    )
                )
            if not response.get("next"):
                break
            offset += response.get("limit", 100)
        return tracks

    def fetch_playlist_name(self, playlist_url_or_id: str) -> str | None:
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            sp = self.user_client(self.operation_spec("read_playlist").scopes)
            response = self._call_required_operation(
                "fetching playlist name",
                lambda: sp.playlist(playlist_id, fields="name"),
            )
            return response.get("name") or None
        except Exception:
            return None

    def check_playlist_access(self, playlist_url_or_id: str) -> int | None:
        sp = self.user_client(self.operation_spec("check_playlist_access").scopes)
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            response = self._call_required_operation(
                "checking playlist access",
                lambda: sp.playlist_items(playlist_id, limit=1, offset=0, additional_types=("track",)),
            )
        except ProviderRateLimit:
            raise
        except Exception as exc:
            rate_limit = rate_limit_from_exception("Spotify", "checking playlist access", exc)
            if rate_limit:
                raise rate_limit from exc
            raise
        return response.get("total")

    def search_artist(self, artist_name: str) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("artist-name-v2", artist=artist_name)
        cached, value = self._cache_lookup(cache_key)
        if cached:
            return value
        try:
            response = self._search_request(q=f'artist:"{artist_name}"', type_="artist", limit=5)
        except Exception as exc:
            if self._handle_catalog_exception("searching artists", exc):
                return None
            return None
        items = safe_get(response, "artists", "items", default=[]) or []
        if not items:
            self._cache_miss(cache_key)
            return None
        target = normalize_key(artist_name)
        for item in items:
            if normalize_key(item.get("name")) == target:
                self._cache_artist(item, name_key=cache_key)
                return item
        self._cache_artist(items[0], name_key=cache_key)
        return items[0]

    def artists_bulk(self, artist_ids: list[str]) -> list[dict[str, Any]]:
        """Resolve artist details with cache-first dedupe and bounded single-ID requests."""
        if self._disabled_by_rate_limit:
            return []
        out: list[dict[str, Any]] = []
        missing_ids: list[str] = []
        for artist_id in dict.fromkeys(artist_ids):
            cache_key = normalized_cache_key("artist-id-v2", artist_id=artist_id)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                if value:
                    out.append(value)
                continue
            missing_ids.append(artist_id)

        for artist_id, artist in self._fetch_single_resources(missing_ids, self._artist_request, "reading artist details"):
            cache_key = normalized_cache_key("artist-id-v2", artist_id=artist_id)
            if not artist:
                self._cache_miss(cache_key)
                continue
            self._cache_artist(artist)
            out.append(artist)

        return out

    def artist_metadata_from_tracks(self, tracks: list[InputTrack]) -> dict[str, dict[str, Any]]:
        names_by_id: dict[str, set[str]] = {}
        for track in tracks:
            for artist_name, artist_id in zip(track.all_artist_names(), track.spotify_artist_ids):
                if artist_id:
                    names_by_id.setdefault(artist_id, set()).add(artist_name)
        artists = self.artists_bulk(list(names_by_id))
        by_name: dict[str, dict[str, Any]] = {}
        for artist in artists:
            artist_id = artist.get("id")
            if artist.get("name"):
                by_name[normalize_key(artist["name"])] = artist
            for original_name in names_by_id.get(artist_id, set()):
                by_name[normalize_key(original_name)] = artist
        return by_name

    def search_album(self, artist_name: str, album_name: str, allow_album_only: bool = True) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        queries = [
            ("artist-album", f'artist:"{artist_name}" album:"{album_name}"'),
        ]
        if allow_album_only:
            queries.append(("album", f'album:"{album_name}"'))
        items: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for kind, query in queries:
            if kind == "artist-album":
                cache_key = normalized_cache_key("album-search-v2", kind=kind, artist=artist_name, album=album_name)
            else:
                cache_key = normalized_cache_key("album-search-v2", kind=kind, album=album_name)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                query_items = value or []
            else:
                try:
                    response = self._search_request(q=query, type_="album", limit=10)
                except Exception as exc:
                    if self._handle_catalog_exception("searching albums", exc):
                        return None
                    continue
                query_items = safe_get(response, "albums", "items", default=[]) or []
                if query_items:
                    self._cache_set(cache_key, query_items, self._cache_ttl_seconds())
                else:
                    self._cache_miss(cache_key)
            for item in query_items:
                item_id = item.get("id")
                if item_id and item_id in seen_ids:
                    continue
                if item_id:
                    seen_ids.add(item_id)
                items.append(item)
        if not items:
            return None
        ranked = [(_album_match_score(item, artist_name, album_name), item) for item in items]
        ranked.sort(key=lambda pair: pair[0], reverse=True)
        return ranked[0][1]

    def album_tracks(self, album_id: str) -> list[dict[str, Any]]:
        if self._disabled_by_rate_limit:
            return []
        cached, value = self._cache_lookup(f"album-tracks-v1:{album_id}")
        if cached:
            return value or []
        tracks: list[dict[str, Any]] = []
        offset = 0
        while True:
            try:
                self._record_api_call()
                kwargs: dict[str, Any] = {"limit": 50, "offset": offset}
                market = self._catalog_market()
                if market:
                    kwargs["market"] = market
                response = self.client().album_tracks(album_id, **kwargs)
            except Exception as exc:
                if self._handle_catalog_exception("reading album tracks", exc):
                    return tracks
                return tracks
            tracks.extend(response.get("items", []))
            if not response.get("next"):
                break
            offset += response.get("limit", 50)
        self._cache_set(f"album-tracks-v1:{album_id}", tracks, self._cache_ttl_seconds())
        return tracks

    def backfill_release_tracks(
        self,
        album_name: str,
        tracks: list[ReleaseTrack],
        *,
        artist_name: str | None = None,
    ) -> list[ReleaseTrack]:
        if self._disabled_by_rate_limit:
            return tracks
        resolved: list[ReleaseTrack] = []
        for track in tracks:
            if track.spotify_track_id:
                if not track.resolution_source:
                    track.resolution_source = "spotify_album_tracklist"
                if not track.resolution_note:
                    track.resolution_note = "Resolved from Spotify album tracklist."
                resolved.append(track)
                continue

            cached = self._cached_track_match(track, album_name=album_name)
            if cached:
                resolved.append(
                    _apply_track_match(
                        track,
                        cached,
                        source="spotify_cached_track",
                        note="Reused cached Spotify track match.",
                    )
                )
                continue

            primary_artist = _primary_artist_name(track.artists or artist_name or "")
            match = None
            if track.isrc:
                match = self._search_track_match(
                    cache_key=normalized_cache_key("track-search-v2", mode="isrc", isrc=track.isrc),
                    query=f"isrc:{track.isrc}",
                    track=track,
                    album_name=album_name,
                    primary_artist=primary_artist,
                    source="spotify_track_search_isrc",
                    note="Matched via Spotify ISRC search.",
                )
            if not match:
                match = self._search_track_match(
                    cache_key=normalized_cache_key(
                        "track-search-v2",
                        mode="strict",
                        artist=primary_artist,
                        track=track.title,
                        album=album_name,
                    ),
                    query=_strict_track_query(primary_artist=primary_artist, track_title=track.title, album_name=album_name),
                    track=track,
                    album_name=album_name,
                    primary_artist=primary_artist,
                    source="spotify_track_search_strict",
                    note="Matched exact title/artist/album context.",
                )
            if not match:
                for query in keyword_query_variants(primary_artist, track.title, album_name, max_queries=3):
                    match = self._search_track_match(
                        cache_key=normalized_cache_key(
                            "track-search-v2",
                            mode="keyword",
                            query=query,
                            track=track.title,
                            album=album_name,
                        ),
                        query=query,
                        track=track,
                        album_name=album_name,
                        primary_artist=primary_artist,
                        source="spotify_track_search_keywords",
                        note="Matched via normalized keyword fallback.",
                    )
                    if match:
                        break
            if match:
                resolved.append(_apply_track_match(track, match, source=match["resolution_source"], note=match["resolution_note"]))
                continue

            if not track.resolution_source:
                track.resolution_source = "musicbrainz_tracklist"
            if not track.resolution_note:
                track.resolution_note = "Spotify unresolved; using MusicBrainz tracklist."
            resolved.append(track)
        return resolved

    def tracks_bulk(self, track_ids: list[str]) -> list[dict[str, Any]]:
        if self._disabled_by_rate_limit:
            return []
        out: list[dict[str, Any]] = []
        missing_ids: list[str] = []
        for track_id in dict.fromkeys(track_ids):
            cache_key = normalized_cache_key("track-id-v2", track_id=track_id)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                if value:
                    out.append(value)
                continue
            missing_ids.append(track_id)
        for track_id, track in self._fetch_single_resources(missing_ids, self._track_request, "reading track details"):
            cache_key = normalized_cache_key("track-id-v2", track_id=track_id)
            if not track:
                self._cache_miss(cache_key)
                continue
            self._cache_set(cache_key, track, self._cache_ttl_seconds())
            out.append(track)
        return out

    def backfill_track_enrichment(self, tracks: list[InputTrack], limit: int = 50) -> int:
        if not self.available or self._disabled_by_rate_limit or not self.storage:
            return 0
        by_id: dict[str, InputTrack] = {}
        for track in tracks:
            if not track.spotify_track_id or track.spotify_track_id in by_id:
                continue
            existing = self.storage.get_track_enrichment(provider="spotify", spotify_track_id=track.spotify_track_id)
            if existing and existing.get("status") == "success" and existing.get("payload", {}).get("source") == "spotify_track_details":
                continue
            if existing and existing.get("status") == "miss":
                continue
            by_id[track.spotify_track_id] = track
            if len(by_id) >= limit:
                break
        if not by_id:
            return 0

        raw_tracks = self.tracks_bulk(list(by_id))
        returned_by_id = {item.get("id"): item for item in raw_tracks if item and item.get("id")}
        saved = 0
        for track_id, raw in returned_by_id.items():
            original = by_id[track_id]
            artist_names = [artist.get("name", "") for artist in raw.get("artists", []) if artist.get("name")]
            album_artists = safe_get(raw, "album", "artists", default=[]) or []
            payload = {
                "source": "spotify_track_details",
                "id": track_id,
                "name": raw.get("name"),
                "album": safe_get(raw, "album", "name"),
                "spotify_album_id": safe_get(raw, "album", "id"),
                "artists": artist_names,
                "artist_ids": [artist.get("id") for artist in raw.get("artists", []) if artist.get("id")],
                "album_artist_ids": [artist.get("id") for artist in album_artists if artist.get("id")],
                "isrc": safe_get(raw, "external_ids", "isrc"),
                "uri": raw.get("uri"),
                "popularity": raw.get("popularity"),
            }
            self.storage.upsert_track_enrichment(
                provider="spotify",
                track=original,
                artist=artist_names[0] if artist_names else original.artist,
                title=raw.get("name") or original.track,
                album=safe_get(raw, "album", "name") or original.album,
                isrc=safe_get(raw, "external_ids", "isrc") or original.isrc,
                spotify_track_id=track_id,
                spotify_album_id=safe_get(raw, "album", "id") or original.spotify_album_id,
                payload={key: value for key, value in payload.items() if value not in (None, "", [])},
            )
            saved += 1

        missing_ids = set(by_id) - set(returned_by_id)
        status = "rate_limited" if self._disabled_by_rate_limit else "miss"
        for track_id in missing_ids:
            self.storage.upsert_track_enrichment(
                provider="spotify",
                track=by_id[track_id],
                status=status,
                payload={"source": "spotify_track_details"},
            )
        return saved

    def representative_tracks(
        self,
        artist_name: str,
        album_name: str,
        cap: int,
        allow_broad_search: bool = True,
    ) -> tuple[str | None, str | None, list[ReleaseTrack]]:
        try:
            album = self.search_album(artist_name, album_name, allow_album_only=allow_broad_search)
        except TypeError:
            album = self.search_album(artist_name, album_name)
        if album:
            album_id = album.get("id")
            album_uri = album.get("uri")
            raw_tracks = self.album_tracks(album_id)
            # Album tracklists already contain enough data to build a shareable mix.
            # Avoid the optional bulk track-details endpoint because some Spotify
            # accounts return 403 there even after playlist/album calls succeed.
            selected = select_representative_tracks(raw_tracks, {}, cap)
            return album_id, album_uri, selected
        return self._representative_tracks_from_track_search(
            artist_name=artist_name,
            album_name=album_name,
            cap=cap,
            allow_broad_search=allow_broad_search,
        )

    def create_playlist(self, name: str, description: str, uris: list[str]) -> SpotifyPlaylistCreationResult:
        if not uris:
            return SpotifyPlaylistCreationResult(created=False, reason="no_uris")
        if self._disabled_by_rate_limit:
            return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
        sp = self.user_client(self.operation_spec("create_playlist").scopes)
        try:
            playlist = self._call_required_operation(
                "creating playlist",
                lambda: self._create_playlist_request(sp, name=name, description=description),
            )
            playlist_id = playlist["id"]
            for batch in chunked(uris, 100):
                self._call_required_operation(
                    "adding playlist items",
                    lambda batch=batch: sp.playlist_add_items(playlist_id, batch),
                )
            return SpotifyPlaylistCreationResult(
                created=True,
                url=playlist.get("external_urls", {}).get("spotify"),
            )
        except ProviderRateLimit as issue:
            if issue.error_kind == "rate_limited":
                return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
            return SpotifyPlaylistCreationResult(created=False, reason=str(issue).splitlines()[0][:160])
        except Exception as exc:
            issue = self._provider_issue("creating playlist", exc)
            if issue:
                self.rate_limit_warnings.append(issue)
                if not issue.should_auto_wait:
                    self._disabled_by_rate_limit = True
                if issue.error_kind == "rate_limited":
                    return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
                if issue.is_permission_error or issue.error_kind in {"auth_failed", "invalid_request", "content_unavailable", "forbidden_access"}:
                    return SpotifyPlaylistCreationResult(
                        created=False,
                        reason=str(issue).splitlines()[0][:160],
                    )
                return SpotifyPlaylistCreationResult(created=False, reason=str(issue).splitlines()[0][:160])
            return SpotifyPlaylistCreationResult(created=False, reason=str(exc).splitlines()[0][:160])

    def _record_rate_limit(self, operation: str, exc: Exception) -> bool:
        rate_limit = self._provider_issue(operation, exc)
        if not rate_limit:
            return False
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True
        return True

    def _call_required_operation(self, operation: str, func):
        last_issue: ProviderRateLimit | None = None
        for attempt in range(REQUIRED_OPERATION_MAX_RETRIES):
            try:
                self._record_api_call()
                return func()
            except Exception as exc:
                issue = self._provider_issue(operation, exc)
                if not issue:
                    raise
                if issue.error_kind != "rate_limited":
                    raise issue from exc
                last_issue = issue
                if issue.retry_after_seconds is not None and not issue.should_auto_wait:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                if attempt == REQUIRED_OPERATION_MAX_RETRIES - 1:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                delay = exponential_backoff_with_retry_after(issue.retry_after_seconds, attempt)
                self._sleep_for_retry(delay)
        if last_issue is not None:
            raise last_issue
        raise RuntimeError(f"Spotify operation failed unexpectedly: {operation}")

    def _sleep_for_retry(self, seconds: int) -> None:
        time.sleep(seconds)

    def _call_catalog_operation(self, operation: str, func):
        last_issue: ProviderRateLimit | None = None
        for attempt in range(CATALOG_OPERATION_MAX_RETRIES):
            try:
                with _SPOTIFY_CATALOG_SEMAPHORE:
                    self._pace_catalog_request()
                    self._record_api_call()
                    return func()
            except Exception as exc:
                issue = self._provider_issue(operation, exc)
                if not issue:
                    raise
                if issue.error_kind != "rate_limited":
                    raise issue from exc
                last_issue = issue
                if issue.retry_after_seconds is not None and not issue.should_auto_wait:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                if attempt == CATALOG_OPERATION_MAX_RETRIES - 1:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                delay = exponential_backoff_with_retry_after(issue.retry_after_seconds, attempt)
                delay += random.uniform(0, max(0.0, delay * 0.25))
                self._sleep_for_retry(int(delay) if delay >= 1 else delay)
        if last_issue is not None:
            raise last_issue
        raise RuntimeError(f"Spotify catalog operation failed unexpectedly: {operation}")

    def _pace_catalog_request(self) -> None:
        global _SPOTIFY_LAST_CATALOG_REQUEST_AT
        with _SPOTIFY_CATALOG_PACE_LOCK:
            now = time.monotonic()
            wait_for = SPOTIFY_CATALOG_MIN_INTERVAL_SECONDS - (now - _SPOTIFY_LAST_CATALOG_REQUEST_AT)
            if wait_for > 0:
                self._sleep_for_retry(wait_for)
            _SPOTIFY_LAST_CATALOG_REQUEST_AT = time.monotonic()

    def _fetch_single_resources(self, ids: list[str], request, operation: str) -> list[tuple[str, dict[str, Any] | None]]:
        unique_ids = list(dict.fromkeys(ids))
        if not unique_ids:
            return []
        results: list[tuple[str, dict[str, Any] | None]] = []
        max_workers = min(SPOTIFY_CATALOG_MAX_WORKERS, len(unique_ids))
        for batch in chunked(unique_ids, max_workers):
            stop = False
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self._call_catalog_operation, operation, lambda item_id=item_id: request(item_id)): item_id
                    for item_id in batch
                }
                for future in as_completed(futures):
                    item_id = futures[future]
                    try:
                        results.append((item_id, future.result()))
                    except Exception as exc:
                        if self._handle_catalog_exception(operation, exc):
                            stop = True
            if stop:
                break
        return results

    def _create_playlist_request(self, client: Any, *, name: str, description: str) -> dict[str, Any]:
        if hasattr(client, "current_user_playlist_create"):
            return client.current_user_playlist_create(name=name, public=False, description=description)
        if hasattr(client, "_post") and callable(getattr(client, "_post")):
            return client._post(
                "me/playlists",
                payload={
                    "name": name,
                    "public": False,
                    "collaborative": False,
                    "description": description,
                },
            )
        raise RuntimeError("Spotify client cannot create playlists with /me/playlists.")

    def _provider_issue(self, operation: str, exc: Exception) -> ProviderRateLimit | None:
        if isinstance(exc, ProviderRateLimit):
            return exc
        issue = rate_limit_from_exception("Spotify", operation, exc)
        if not issue:
            return None
        if issue.error_kind == "permission_denied" and "playlist" in operation:
            issue.error_kind = "forbidden_access"
        if issue.error_kind == "invalid_request":
            detail = (issue.error_message or str(exc) or "").lower()
            if any(token in detail for token in ("market", "country", "not available")):
                issue.error_kind = "content_unavailable"
        return issue

    def _handle_catalog_exception(self, operation: str, exc: Exception) -> bool:
        issue = self._provider_issue(operation, exc)
        if not issue:
            return False
        if not any(
            existing.operation == issue.operation
            and existing.status_code == issue.status_code
            and existing.error_kind == issue.error_kind
            for existing in self.rate_limit_warnings
        ):
            self.rate_limit_warnings.append(issue)
        if not issue.should_auto_wait:
            self._disabled_by_rate_limit = True
        return True

    def _catalog_market(self) -> str | None:
        settings = getattr(self, "settings", None)
        raw = (getattr(settings, "spotify_market", "") or "").strip().upper()
        if len(raw) == 2 and raw.isalpha():
            return raw
        return None

    def _catalog_request_kwargs(self, *, limit: int) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"limit": limit}
        market = self._catalog_market()
        if market:
            kwargs["market"] = market
        return kwargs

    def _search_request(self, *, q: str, type_: str, limit: int, offset: int = 0) -> dict[str, Any]:
        """
        Search Spotify catalog for items matching the query.

        NOTE: The spotipy library's internal _get method may have issues with parameter
        handling for the search endpoint. We use the public search() method which is
        more stable and better maintained.
        """
        return self._call_catalog_operation(
            f"searching {type_}s",
            lambda: self._search_request_once(q=q, type_=type_, limit=limit, offset=offset),
        )

    def _search_request_once(self, *, q: str, type_: str, limit: int, offset: int = 0) -> dict[str, Any]:
        client = self.client()
        kwargs = {"q": q, "type": type_, "limit": limit, "offset": offset}
        market = self._catalog_market()
        if market:
            kwargs["market"] = market
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            return client._get("search", **kwargs)
        return client.search(**kwargs)

    def _artist_request(self, artist_id: str) -> dict[str, Any] | None:
        client = self.client()
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            return client._get(f"artists/{artist_id}")
        return client.artist(artist_id)

    def _track_request(self, track_id: str) -> dict[str, Any] | None:
        client = self.client()
        market = self._catalog_market()
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            kwargs: dict[str, Any] = {}
            if market:
                kwargs["market"] = market
            return client._get(f"tracks/{track_id}", **kwargs)
        if market:
            return client.track(track_id, market=market)
        return client.track(track_id)

    def _scope_cache_path(self, scopes: str) -> Path:
        scope_slug = normalize_key(scopes).replace(" ", "_") or "user"
        return self.settings.data_dir / f".spotipy_token_cache_{scope_slug}"

    def _cache_lookup(self, key: str) -> tuple[bool, Any | None]:
        storage = getattr(self, "storage", None)
        if not storage:
            return False, None
        settings = getattr(self, "settings", None)
        if getattr(settings, "force_refresh", False):
            return False, None
        value = storage.get_cache("spotify", key)
        if value is None:
            self.cache_misses = getattr(self, "cache_misses", 0) + 1
            return False, None
        self.cache_hits = getattr(self, "cache_hits", 0) + 1
        if value == MISS_SENTINEL:
            return True, None
        return True, value

    def _record_api_call(self) -> None:
        self.api_calls = getattr(self, "api_calls", 0) + 1

    def _cache_set(self, key: str, value: Any, ttl_seconds: int) -> None:
        storage = getattr(self, "storage", None)
        if storage:
            storage.set_cache("spotify", key, value, ttl_seconds)

    def _cache_miss(self, key: str) -> None:
        self._cache_set(key, MISS_SENTINEL, self._cache_miss_ttl_seconds())

    def _cache_artist(self, artist: dict[str, Any], name_key: str | None = None) -> None:
        artist_id = artist.get("id")
        if artist_id:
            self._cache_set(
                normalized_cache_key("artist-id-v2", artist_id=artist_id),
                artist,
                self._cache_ttl_seconds(),
            )
        if name_key:
            self._cache_set(name_key, artist, self._cache_ttl_seconds())
        if artist.get("name"):
            self._cache_set(
                normalized_cache_key("artist-name-v2", artist=artist.get("name")),
                artist,
                self._cache_ttl_seconds(),
            )

    def _cached_track_match(self, track: ReleaseTrack, *, album_name: str) -> dict[str, Any] | None:
        cache_keys: list[str] = []
        if track.isrc:
            cache_keys.append(normalized_cache_key("track-search-v2", mode="isrc", isrc=track.isrc))
        primary_artist = _primary_artist_name(track.artists)
        cache_keys.append(
            normalized_cache_key(
                "track-search-v2",
                mode="strict",
                artist=primary_artist,
                track=track.title,
                album=album_name,
            )
        )
        for cache_key in cache_keys:
            cached, value = self._cache_lookup(cache_key)
            if cached and value:
                return value
        storage = getattr(self, "storage", None)
        if not storage:
            return None
        row = storage.get_track_enrichment(
            provider="spotify",
            artist=primary_artist or track.artists,
            title=track.title,
            isrc=track.isrc,
        )
        if not row or row["status"] != "success":
            return None
        album_key = normalize_variant_title(album_name)
        row_album_key = normalize_variant_title(row.get("album"))
        if album_key and row_album_key and album_key != row_album_key:
            return None
        payload = dict(row.get("payload", {}))
        spotify_track_id = row.get("spotify_track_id") or payload.get("spotify_track_id") or payload.get("id")
        if not spotify_track_id:
            return None
        artists = payload.get("artists") or split_artist_names(track.artists or primary_artist)
        return {
            "id": spotify_track_id,
            "uri": payload.get("uri"),
            "name": payload.get("name") or row.get("title") or track.title,
            "album": {"id": row.get("spotify_album_id"), "name": row.get("album") or album_name},
            "artists": [{"name": name} for name in artists if name],
            "external_ids": {"isrc": row.get("isrc") or payload.get("isrc") or track.isrc},
            "popularity": payload.get("popularity") or 0,
        }

    def _search_track_match(
        self,
        *,
        cache_key: str,
        query: str,
        track: ReleaseTrack,
        album_name: str,
        primary_artist: str,
        source: str,
        note: str,
    ) -> dict[str, Any] | None:
        cached, value = self._cache_lookup(cache_key)
        if cached:
            return value
        try:
            response = self._search_request(q=query, type_="track", limit=10)
        except Exception as exc:
            if self._handle_catalog_exception("searching tracks", exc):
                return None
            return None
        items = safe_get(response, "tracks", "items", default=[]) or []
        target = {
            "album_name": album_name,
            "isrc": track.isrc,
            "primary_artist": primary_artist,
            "track_title": track.title,
        }
        ranked: list[tuple[int, dict[str, Any]]] = []
        for item in items:
            accepted, score = _track_candidate_score(item, target=target, query_source=source)
            if accepted:
                ranked.append((score, item))
        if not ranked:
            self._cache_miss(cache_key)
            return None
        ranked.sort(key=lambda pair: pair[0], reverse=True)
        best = _track_payload(ranked[0][1], resolution_source=source, resolution_note=note)
        self._cache_set(cache_key, best, self._cache_ttl_seconds())
        storage = getattr(self, "storage", None)
        if storage:
            storage.upsert_track_enrichment(
                provider="spotify",
                artist=primary_artist or track.artists,
                title=track.title,
                album=album_name,
                isrc=track.isrc,
                spotify_track_id=best.get("id"),
                spotify_album_id=safe_get(best, "album", "id"),
                payload={
                    "source": source,
                    "name": best.get("name"),
                    "uri": best.get("uri"),
                    "isrc": safe_get(best, "external_ids", "isrc"),
                    "spotify_track_id": best.get("id"),
                    "spotify_album_id": safe_get(best, "album", "id"),
                    "artists": [artist.get("name") for artist in best.get("artists", []) if artist.get("name")],
                    "album": safe_get(best, "album", "name"),
                    "popularity": best.get("popularity"),
                    "resolution_source": source,
                    "resolution_note": note,
                },
            )
        return best

    def _representative_tracks_from_track_search(
        self,
        *,
        artist_name: str,
        album_name: str,
        cap: int,
        allow_broad_search: bool,
    ) -> tuple[str | None, str | None, list[ReleaseTrack]]:
        queries = [('artist_album', f'artist:"{artist_name}" album:"{album_name}"')]
        if allow_broad_search:
            queries.append(("album_only", f'album:"{album_name}"'))
        candidates: list[dict[str, Any]] = []
        seen_track_ids: set[str] = set()
        for mode, query in queries:
            cache_key = normalized_cache_key("track-album-search-v1", mode=mode, artist=artist_name, album=album_name)
            if mode == "album_only":
                cache_key = normalized_cache_key("track-album-search-v1", mode=mode, album=album_name)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                items = value or []
            else:
                try:
                    page1 = self._search_request(q=query, type_="track", limit=10, offset=0)
                    page1_items = safe_get(page1, "tracks", "items", default=[]) or []
                    page2_items: list[dict[str, Any]] = []
                    if len(page1_items) == 10:
                        page2 = self._search_request(q=query, type_="track", limit=10, offset=10)
                        page2_items = safe_get(page2, "tracks", "items", default=[]) or []
                    items = page1_items + page2_items
                except Exception as exc:
                    if self._handle_catalog_exception("searching tracks", exc):
                        return None, None, []
                    continue
                if items:
                    self._cache_set(cache_key, items, self._cache_ttl_seconds())
                else:
                    self._cache_miss(cache_key)
            for item in items:
                track_id = item.get("id")
                if track_id and track_id in seen_track_ids:
                    continue
                if track_id:
                    seen_track_ids.add(track_id)
                candidates.append(item)
            clustered = _best_track_search_album_cluster(candidates, artist_name=artist_name, album_name=album_name)
            if clustered:
                album_id = safe_get(clustered[0], "album", "id")
                album_uri = safe_get(clustered[0], "album", "uri") or (f"spotify:album:{album_id}" if album_id else None)
                selected = select_representative_tracks(
                    clustered,
                    {},
                    cap,
                    resolution_source="spotify_track_search_album_context",
                    resolution_note="Resolved from Spotify track search after album lookup missed.",
                )
                return album_id, album_uri, selected
        return None, None, []

    def cache_summary(self) -> dict[str, int | bool]:
        return {
            "cache_hits": getattr(self, "cache_hits", 0),
            "cache_misses": getattr(self, "cache_misses", 0),
            "api_calls": getattr(self, "api_calls", 0),
            "disabled_by_rate_limit": getattr(self, "_disabled_by_rate_limit", False),
        }

    def _cache_ttl_seconds(self) -> int:
        settings = getattr(self, "settings", None)
        return int(getattr(settings, "spotify_cache_ttl_seconds", 30 * 24 * 60 * 60))

    def _cache_miss_ttl_seconds(self) -> int:
        settings = getattr(self, "settings", None)
        return int(getattr(settings, "spotify_cache_miss_ttl_seconds", 7 * 24 * 60 * 60))


def select_representative_tracks(
    raw_tracks: list[dict[str, Any]],
    track_details: dict[str, dict[str, Any]],
    cap: int,
    *,
    resolution_source: str = "spotify_album_tracklist",
    resolution_note: str = "Resolved from Spotify album tracklist.",
) -> list[ReleaseTrack]:
    enriched: list[tuple[float, int, ReleaseTrack]] = []
    total = len(raw_tracks)
    for idx, track in enumerate(raw_tracks, start=1):
        track_id = track.get("id")
        details = track_details.get(track_id, {})
        popularity = int(details.get("popularity") or 0)
        track_number = int(track.get("track_number") or idx)
        score = popularity + representative_position_bonus(track_number, total)
        artists = ", ".join(artist.get("name", "") for artist in track.get("artists", []) if artist.get("name"))
        isrc = safe_get(track, "external_ids", "isrc") or safe_get(details, "external_ids", "isrc")
        enriched.append(
            (
                score,
                track_number,
                ReleaseTrack(
                    title=track.get("name", ""),
                    artists=artists,
                    track_number=track_number,
                    spotify_track_id=track_id,
                    spotify_uri=track.get("uri"),
                    isrc=isrc,
                    isrc_source="spotify" if isrc else None,
                    popularity=popularity,
                    resolution_source=resolution_source,
                    resolution_note=resolution_note,
                ),
            )
        )
    enriched.sort(key=lambda item: (item[0], -item[1]), reverse=True)
    selected = [item[2] for item in enriched[:cap]]
    return sorted(selected, key=lambda track: track.track_number or 0)


def _album_match_score(item: dict[str, Any], artist_name: str, album_name: str) -> int:
    target_artist = normalize_key(artist_name)
    target_album = normalize_key(album_name)
    album_key = normalize_key(item.get("name"))
    artist_keys = {
        normalize_key(artist.get("name"))
        for artist in item.get("artists", [])
        if artist.get("name")
    }

    score = 0
    if album_key == target_album:
        score += 10
    elif target_album and (target_album in album_key or album_key in target_album):
        score += 4
    target_artist_parts = {
        normalize_key(part.strip())
        for part in re.split(r"[&,]", artist_name)
        if part.strip()
    }
    if target_artist in artist_keys or bool(target_artist_parts & artist_keys):
        score += 5
    if item.get("album_type") == "album":
        score += 1
    return score


def playlist_item_track(item: dict[str, Any]) -> dict[str, Any]:
    """Return the track payload from old (`track`), current (`item`), or nested item shapes."""
    track = item.get("track") or item.get("item") or {}
    if isinstance(track, dict) and isinstance(track.get("track"), dict):
        track = track["track"]
    return track if isinstance(track, dict) else {}


def representative_position_bonus(index: int, total: int) -> float:
    if total <= 1:
        return 1.0
    first_bonus = max(0.0, 1.4 - (index - 1) * 0.18)
    mid = (total + 1) / 2.0
    mid_bonus = max(0.0, 1.0 - abs(index - mid) / max(1.0, total / 4.0))
    return first_bonus + mid_bonus


def _apply_track_match(track: ReleaseTrack, payload: dict[str, Any], *, source: str, note: str) -> ReleaseTrack:
    track.spotify_track_id = payload.get("id") or track.spotify_track_id
    track.spotify_uri = payload.get("uri") or track.spotify_uri
    track.isrc = safe_get(payload, "external_ids", "isrc") or track.isrc
    track.popularity = int(payload.get("popularity") or track.popularity or 0)
    track.resolution_source = source
    track.resolution_note = note
    return track


def _primary_artist_name(value: str) -> str:
    artists = split_artist_names(value)
    return artists[0] if artists else value


def _strict_track_query(*, primary_artist: str, track_title: str, album_name: str) -> str:
    if album_name:
        return f'track:"{track_title}" artist:"{primary_artist}" album:"{album_name}"'
    return f'track:"{track_title}" artist:"{primary_artist}"'


def _track_candidate_score(
    item: dict[str, Any],
    *,
    target: dict[str, Any],
    query_source: str,
) -> tuple[bool, int]:
    title_key = normalize_variant_title(item.get("name"))
    target_title_key = normalize_variant_title(target.get("track_title"))
    title_exact = bool(title_key and target_title_key and title_key == target_title_key)

    candidate_artists = {
        normalize_key(artist.get("name"))
        for artist in item.get("artists", []) or []
        if artist.get("name")
    }
    target_artists = {normalize_key(name) for name in split_artist_names(target.get("primary_artist")) if normalize_key(name)}
    artist_overlap = len(candidate_artists & target_artists)

    album_key = normalize_variant_title(safe_get(item, "album", "name"))
    target_album_key = normalize_variant_title(target.get("album_name"))
    album_overlap = _keys_overlap(album_key, target_album_key)

    item_isrc = normalize_key(safe_get(item, "external_ids", "isrc"))
    target_isrc = normalize_key(target.get("isrc"))
    isrc_match = bool(target_isrc and item_isrc and item_isrc == target_isrc)

    if isrc_match:
        accepted = True
    else:
        accepted = title_exact and artist_overlap > 0 and (not target_album_key or album_overlap)
        if query_source == "spotify_track_search_isrc" and not accepted:
            accepted = title_exact and artist_overlap > 0

    score = 0
    if isrc_match:
        score += 500
    if title_exact:
        score += 120
    if artist_overlap:
        score += 50 + artist_overlap * 10
    if album_overlap:
        score += 40
    score += min(int(item.get("popularity") or 0), 100) // 5
    return accepted, score


def _keys_overlap(left: str, right: str) -> bool:
    if not left or not right:
        return False
    return left == right or left in right or right in left


def _track_payload(item: dict[str, Any], *, resolution_source: str, resolution_note: str) -> dict[str, Any]:
    return {
        "id": item.get("id"),
        "uri": item.get("uri"),
        "name": item.get("name"),
        "album": {
            "id": safe_get(item, "album", "id"),
            "name": safe_get(item, "album", "name"),
        },
        "artists": [{"name": artist.get("name")} for artist in item.get("artists", []) or [] if artist.get("name")],
        "external_ids": {"isrc": safe_get(item, "external_ids", "isrc")},
        "popularity": int(item.get("popularity") or 0),
        "resolution_source": resolution_source,
        "resolution_note": resolution_note,
    }


def _best_track_search_album_cluster(
    items: list[dict[str, Any]],
    *,
    artist_name: str,
    album_name: str,
) -> list[dict[str, Any]]:
    clusters: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        album_id = safe_get(item, "album", "id")
        album_label = safe_get(item, "album", "name")
        cluster_key = album_id or normalize_variant_title(album_label)
        if not cluster_key:
            continue
        clusters.setdefault(cluster_key, []).append(item)
    if not clusters:
        return []
    ranked = sorted(
        clusters.values(),
        key=lambda cluster: _track_search_album_cluster_score(cluster, artist_name=artist_name, album_name=album_name),
        reverse=True,
    )
    best = ranked[0]
    best_score = _track_search_album_cluster_score(best, artist_name=artist_name, album_name=album_name)
    if best_score < 12:
        return []
    return best


def _track_search_album_cluster_score(
    cluster: list[dict[str, Any]],
    *,
    artist_name: str,
    album_name: str,
) -> int:
    if not cluster:
        return 0
    album = safe_get(cluster[0], "album", "name")
    album_score = _album_match_score({"name": album, "artists": safe_get(cluster[0], "album", "artists", default=[]) or []}, artist_name, album_name)
    track_count_bonus = min(len(cluster), 5) * 2
    popularity_bonus = max(int(item.get("popularity") or 0) for item in cluster) // 20
    return album_score + track_count_bonus + popularity_bonus
