from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
import datetime as dt
import os
from pathlib import Path
import random
import re
import socket
import threading
import time
from typing import Any

from mamonia.config import Settings, harden_secret_file_permissions, is_valid_spotify_redirect_uri
from mamonia.discovery_window import DiscoveryWindow, resolve_effective_window
from mamonia.input import extract_spotify_playlist_id
from mamonia.matching import MatchCandidate, select_staged_candidate
from mamonia.models import InputTrack, ReleaseTrack
from mamonia.providers import (
    ProviderRateLimit,
    ProviderUnavailable,
    exponential_backoff_with_retry_after,
    format_network_error,
    is_network_error,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import (
    chunked,
    keyword_query_variants,
    normalize_key,
    normalized_cache_key,
    normalize_variant_title,
    parse_date,
    safe_get,
    split_artist_names,
)


# Keep user-scoped auth narrow and use client credentials for public catalog lookups.
SPOTIFY_READ_SCOPES = "playlist-read-private playlist-read-collaborative"
SPOTIFY_WRITE_SCOPES = "playlist-modify-private"
MISS_SENTINEL = {"__mamonia_miss": True}
REQUIRED_OPERATION_MAX_RETRIES = 3
CATALOG_OPERATION_MAX_RETRIES = 3
SPOTIFY_CATALOG_MAX_WORKERS = 1
SPOTIFY_CATALOG_MIN_INTERVAL_SECONDS = 1.5
SPOTIFY_CATALOG_MAX_JITTER_SECONDS = 0.5
_SPOTIFY_CATALOG_SEMAPHORE = threading.BoundedSemaphore(SPOTIFY_CATALOG_MAX_WORKERS)
_SPOTIFY_CATALOG_PACE_LOCK = threading.Lock()
_SPOTIFY_LAST_CATALOG_REQUEST_AT = 0.0


@dataclass(frozen=True)
class SpotifyOperationSpec:
    operation: str
    endpoint: str
    auth_mode: str
    scopes: str = ""
    user_specific: bool = False
    deprecated: bool = False


SPOTIFY_OPERATION_SPECS: dict[str, SpotifyOperationSpec] = {
    "read_playlist": SpotifyOperationSpec(
        operation="read_playlist",
        endpoint="GET /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_READ_SCOPES,
        user_specific=True,
    ),
    "check_playlist_access": SpotifyOperationSpec(
        operation="check_playlist_access",
        endpoint="GET /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_READ_SCOPES,
        user_specific=True,
    ),
    "search_artist": SpotifyOperationSpec(
        operation="search_artist",
        endpoint="GET /search?type=artist",
        auth_mode="client_credentials",
    ),
    "read_artist_details": SpotifyOperationSpec(
        operation="read_artist_details",
        endpoint="GET /artists/{id}",
        auth_mode="client_credentials",
    ),
    "search_album": SpotifyOperationSpec(
        operation="search_album",
        endpoint="GET /search?type=album",
        auth_mode="client_credentials",
    ),
    "read_album_tracks": SpotifyOperationSpec(
        operation="read_album_tracks",
        endpoint="GET /albums/{id}/tracks",
        auth_mode="client_credentials",
    ),
    "read_track_details": SpotifyOperationSpec(
        operation="read_track_details",
        endpoint="GET /tracks/{id}",
        auth_mode="client_credentials",
    ),
    "search_track": SpotifyOperationSpec(
        operation="search_track",
        endpoint="GET /search?type=track",
        auth_mode="client_credentials",
    ),
    "create_playlist": SpotifyOperationSpec(
        operation="create_playlist",
        endpoint="POST /me/playlists + POST /playlists/{playlist_id}/items",
        auth_mode="pkce",
        scopes=SPOTIFY_WRITE_SCOPES,
        user_specific=True,
    ),
    "fetch_user_playlists": SpotifyOperationSpec(
        operation="fetch_user_playlists",
        endpoint="GET /me/playlists",
        auth_mode="pkce",
        scopes=SPOTIFY_READ_SCOPES,
        user_specific=True,
    ),
}


@dataclass(frozen=True)
class SpotifyUserPlaylist:
    id: str
    name: str
    tracks: int


@dataclass(frozen=True)
class SpotifyPlaylistCreationResult:
    created: bool
    url: str | None = None
    reason: str | None = None


class SpotifyProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None, progress=None):
        self.settings = settings
        self.storage = storage
        self.progress = progress
        self._client: Any | None = None
        self._user_clients: dict[str, Any] = {}
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self.__disabled_by_rate_limit = False
        self.__catalog_cooldown_until: float = 0.0
        self.__catalog_cooldown_lock = threading.Lock()
        self.cache_hits = 0
        self.cache_misses = 0
        self.api_calls = 0
        self.retry_count = 0
        self._isrc_lookups = 0
        self._isrc_misses = 0

    @property
    def _disabled_by_rate_limit(self) -> bool:
        try:
            return self.__disabled_by_rate_limit or time.monotonic() < self.__catalog_cooldown_until
        except AttributeError:
            return False

    @_disabled_by_rate_limit.setter
    def _disabled_by_rate_limit(self, value: bool) -> None:
        if not hasattr(self, '_SpotifyProvider__catalog_cooldown_until'):
            self.__catalog_cooldown_until = 0.0
            self.__catalog_cooldown_lock = threading.Lock()
        self.__disabled_by_rate_limit = value

    @property
    def available(self) -> bool:
        return bool(self.settings.spotify_client_id and self.settings.spotify_client_secret)

    @property
    def playlist_auth_available(self) -> bool:
        return bool(
            self.settings.spotify_client_id
            and is_valid_spotify_redirect_uri(self.settings.spotify_redirect_uri)
        )

    def operation_spec(self, operation: str) -> SpotifyOperationSpec:
        return SPOTIFY_OPERATION_SPECS[operation]

    def client(self) -> Any:
        if self._client is not None:
            return self._client
        if not self.available:
            raise ProviderUnavailable(
                "Spotify credentials are missing. Set SPOTIPY_CLIENT_ID and SPOTIPY_CLIENT_SECRET."
            )
        try:
            import spotipy
            from spotipy.cache_handler import MemoryCacheHandler
            from spotipy.oauth2 import SpotifyClientCredentials
        except Exception as exc:
            raise ProviderUnavailable("spotipy is not installed. Run: pip install -e .") from exc

        auth = SpotifyClientCredentials(
            client_id=self.settings.spotify_client_id,
            client_secret=self.settings.spotify_client_secret,
            cache_handler=MemoryCacheHandler(),
        )
        timeout = max(1.0, float(getattr(self.settings, "provider_http_read_timeout_seconds", 10.0) or 10.0))
        self._client = spotipy.Spotify(
            auth_manager=auth,
            requests_timeout=timeout,
            retries=0,
            status_retries=0,
            status_forcelist=(500, 502, 503, 504),
        )
        return self._client

    def user_client(self, scopes: str) -> Any:
        cached = self._user_clients.get(scopes)
        if cached is not None:
            return cached
        if not self.settings.spotify_client_id:
            raise ProviderUnavailable(
                "Spotify client ID is missing. Set SPOTIPY_CLIENT_ID for Spotify playlist access."
            )
        if not is_valid_spotify_redirect_uri(self.settings.spotify_redirect_uri):
            raise ProviderUnavailable(
                "Spotify redirect URI must use HTTPS unless it is http://127.0.0.1 for local development."
            )
        try:
            import spotipy
            from spotipy.cache_handler import CacheFileHandler
            from spotipy.oauth2 import SpotifyPKCE
        except Exception as exc:
            raise ProviderUnavailable("spotipy is not installed. Run: pip install -e .") from exc

        cache_path = self._scope_cache_path(scopes)
        harden_secret_file_permissions(cache_path)

        def _new_client() -> Any:
            auth = SpotifyPKCE(
                client_id=self.settings.spotify_client_id,
                redirect_uri=self.settings.spotify_redirect_uri,
                scope=scopes,
                cache_handler=CacheFileHandler(cache_path=str(cache_path)),
                open_browser=True,
            )
            timeout = max(1.0, float(getattr(self.settings, "provider_http_read_timeout_seconds", 10.0) or 10.0))
            return spotipy.Spotify(
                auth_manager=auth,
                requests_timeout=timeout,
                retries=0,
                status_retries=0,
                status_forcelist=(500, 502, 503, 504),
            )

        client = _new_client()
        self._user_clients[scopes] = client
        harden_secret_file_permissions(cache_path)
        return client

    def permission_guidance(self, operation: str) -> str:
        if "creating playlist" in operation:
            cache_path = self._scope_cache_path(self.operation_spec("create_playlist").scopes)
            return (
                "Re-authorize Spotify with playlist-modify access. "
                f"If you recently changed scopes, delete {cache_path} and rerun so Mamonia can request a fresh token."
            )
        if "playlist" in operation:
            cache_path = self._scope_cache_path(self.operation_spec("read_playlist").scopes)
            return (
                "Re-authorize Spotify with playlist-read access. "
                f"If you recently changed scopes, delete {cache_path} and rerun so Mamonia can request a fresh token."
            )
        return (
            "Spotify catalog lookups now use client credentials. "
            "If this keeps failing, re-check the app credentials and app restrictions in the Spotify developer dashboard."
        )

    def issue_guidance(self, issue: ProviderRateLimit) -> str:
        if issue.error_kind == "insufficient_scope":
            return self.permission_guidance(issue.operation)
        if issue.error_kind == "auth_failed":
            if "playlist" in issue.operation:
                cache_path = self._scope_cache_path(self.operation_spec("read_playlist").scopes)
                if "creating playlist" in issue.operation:
                    cache_path = self._scope_cache_path(self.operation_spec("create_playlist").scopes)
                return (
                    "Spotify authorization has expired or is invalid. "
                    f"Delete {cache_path} and rerun so Mamonia can request a fresh token."
                )
            return (
                "Spotify catalog lookups use client credentials. "
                "Re-check SPOTIPY_CLIENT_ID, SPOTIPY_CLIENT_SECRET, and any app restrictions in the Spotify developer dashboard."
            )
        if issue.error_kind == "forbidden_access" and "playlist" in issue.operation:
            return (
                "Make sure the authorized Spotify account can actually view this playlist. "
                "Private or restricted playlists must be accessible to the same Spotify user that just authorized Mamonia."
            )
        if issue.error_kind == "content_unavailable":
            return (
                "If you set SPOTIFY_MARKET or MAMONIA_SPOTIFY_MARKET, use a valid two-letter market code such as PL or US. "
                "Leave it unset to avoid market filtering."
            )
        if issue.error_kind == "invalid_request":
            return (
                "Spotify rejected the request parameters. "
                "If this persists, re-check the configured market code and update to the latest Mamonia build."
            )
        if issue.is_permission_error:
            return self.permission_guidance(issue.operation)
        return ""

    def fetch_playlist_tracks(self, playlist_url_or_id: str) -> list[InputTrack]:
        sp = self.user_client(self.operation_spec("read_playlist").scopes)
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        tracks: list[InputTrack] = []
        offset = 0
        while True:
            try:
                response = self._call_required_operation(
                    "reading playlist",
                    lambda: sp.playlist_items(playlist_id, limit=100, offset=offset, additional_types=("track",)),
                )
            except ProviderRateLimit:
                raise
            except Exception as exc:
                rate_limit = rate_limit_from_exception("Spotify", "reading playlist", exc)
                if rate_limit:
                    raise rate_limit from exc
                raise
            for item in response.get("items", []):
                track = playlist_item_track(item)
                if track.get("type") != "track":
                    continue
                artists = track.get("artists") or []
                if not artists:
                    continue
                artist_names = [artist.get("name", "") for artist in artists if artist.get("name")]
                tracks.append(
                    InputTrack(
                        artist=artist_names[0],
                        artists=artist_names,
                        track=track.get("name", ""),
                        album=safe_get(track, "album", "name"),
                        spotify_track_id=track.get("id"),
                        spotify_artist_ids=[artist["id"] for artist in artists if artist.get("id")],
                        spotify_album_id=safe_get(track, "album", "id"),
                    )
                )
            if not response.get("next"):
                break
            offset += response.get("limit", 100)
        return tracks

    def fetch_playlist_name(self, playlist_url_or_id: str) -> str | None:
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            sp = self.user_client(self.operation_spec("read_playlist").scopes)
            response = self._call_required_operation(
                "fetching playlist name",
                lambda: sp.playlist(playlist_id, fields="name"),
            )
            return response.get("name") or None
        except Exception:
            return None

    def check_playlist_access(self, playlist_url_or_id: str) -> int | None:
        sp = self.user_client(self.operation_spec("check_playlist_access").scopes)
        playlist_id = extract_spotify_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            response = self._call_required_operation(
                "checking playlist access",
                lambda: sp.playlist_items(playlist_id, limit=1, offset=0, additional_types=("track",)),
            )
        except ProviderRateLimit:
            raise
        except Exception as exc:
            rate_limit = rate_limit_from_exception("Spotify", "checking playlist access", exc)
            if rate_limit:
                raise rate_limit from exc
            raise
        return response.get("total")

    def fetch_user_playlists(self) -> list[SpotifyUserPlaylist]:
        """Fetch the authenticated user's Spotify playlists."""
        scopes = self.operation_spec("fetch_user_playlists").scopes
        sp = self.user_client(scopes)
        playlists: list[SpotifyUserPlaylist] = []
        offset = 0
        attempted_cache_recovery = False
        while True:
            try:
                response = self._call_required_operation(
                    "fetching user playlists",
                    lambda: sp.current_user_playlists(limit=50, offset=offset),
                )
            except Exception as exc:
                issue = exc if isinstance(exc, ProviderRateLimit) else self._provider_issue("fetching user playlists", exc)
                issue_message = (getattr(issue, "error_message", "") or "").lower() if issue else ""
                if (
                    not attempted_cache_recovery
                    and issue
                    and issue.error_kind == "auth_failed"
                    and (self._is_invalid_client_error(exc) or "invalid client" in issue_message)
                ):
                    attempted_cache_recovery = True
                    self._delete_scope_cache_file(self._scope_cache_path(scopes))
                    self._user_clients.pop(scopes, None)
                    sp = self.user_client(scopes)
                    continue
                if issue:
                    raise issue from exc
                raise
            for item in response.get("items", []):
                # Handle possible Spotify API response structures for track count:
                # 1. {"items": {"total": 11}} - new structure (current)
                # 2. {"tracks": {"total": 11}} - deprecated structure (fallback)
                # 3. {"items": 11} - direct integer (less common)
                # 4. {"items": {}} or {"items": null} - no tracks
                tracks_raw = item.get("items")
                tracks = 0
                if isinstance(tracks_raw, dict):
                    tracks = tracks_raw.get("total", 0)
                elif isinstance(tracks_raw, int):
                    tracks = tracks_raw
                else:
                    # Fallback to deprecated tracks field if items is not present
                    tracks_raw = item.get("tracks")
                    if isinstance(tracks_raw, dict):
                        tracks = tracks_raw.get("total", 0)
                    elif isinstance(tracks_raw, int):
                        tracks = tracks_raw
                    else:
                        tracks = item.get("track_count", 0)
                # Ensure tracks is an integer
                if not isinstance(tracks, int):
                    try:
                        tracks = int(tracks)
                    except (TypeError, ValueError):
                        tracks = 0
                playlists.append(
                    SpotifyUserPlaylist(
                        id=item.get("id", ""),
                        name=item.get("name", ""),
                        tracks=tracks,
                    )
                )
            if not response.get("next"):
                break
            offset += response.get("limit", 50)
        return playlists

    def search_artist(self, artist_name: str) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("artist-name-v2", artist=artist_name)
        cached, value = self._cache_lookup(cache_key)
        if cached:
            return value
        try:
            response = self._search_request(q=f'artist:"{artist_name}"', type_="artist", limit=5, use_global_session=True)
        except Exception as exc:
            if self._handle_catalog_exception("searching artists", exc):
                return None
            return None
        items = safe_get(response, "artists", "items", default=[]) or []
        if not items:
            self._cache_miss(cache_key)
            return None
        target = normalize_key(artist_name)
        for item in items:
            if normalize_key(item.get("name")) == target:
                self._cache_artist(item, name_key=cache_key)
                return item
        self._cache_artist(items[0], name_key=cache_key)
        return items[0]

    def artists_bulk(self, artist_ids: list[str]) -> list[dict[str, Any]]:
        """Resolve artist details with cache-first dedupe and bounded single-ID requests."""
        if self._disabled_by_rate_limit:
            return []
        out: list[dict[str, Any]] = []
        missing_ids: list[str] = []
        for artist_id in dict.fromkeys(artist_ids):
            cache_key = normalized_cache_key("artist-id-v2", artist_id=artist_id)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                if value:
                    out.append(value)
                continue
            missing_ids.append(artist_id)

        for artist_id, artist in self._fetch_single_resources(missing_ids, self._artist_request, "reading artist details"):
            cache_key = normalized_cache_key("artist-id-v2", artist_id=artist_id)
            if not artist:
                self._cache_miss(cache_key)
                continue
            self._cache_artist(artist)
            out.append(artist)

        return out

    def artist_metadata_from_tracks(
        self,
        tracks: list[InputTrack],
        *,
        max_artists: int | None = None,
    ) -> dict[str, dict[str, Any]]:
        names_by_id: dict[str, set[str]] = {}
        counts_by_id: dict[str, int] = {}
        for track in tracks:
            for artist_name, artist_id in zip(track.all_artist_names(), track.spotify_artist_ids):
                if artist_id:
                    names_by_id.setdefault(artist_id, set()).add(artist_name)
                    counts_by_id[artist_id] = counts_by_id.get(artist_id, 0) + 1
        ordered_artist_ids = sorted(
            names_by_id,
            key=lambda artist_id: (-counts_by_id.get(artist_id, 0), artist_id),
        )
        if max_artists is not None and max_artists > 0:
            ordered_artist_ids = ordered_artist_ids[:max_artists]
        artists = self.artists_bulk(ordered_artist_ids)
        by_name: dict[str, dict[str, Any]] = {}
        for artist in artists:
            artist_id = artist.get("id")
            if artist.get("name"):
                by_name[normalize_key(artist["name"])] = artist
            for original_name in names_by_id.get(artist_id, set()):
                by_name[normalize_key(original_name)] = artist
        return by_name

    def search_album(self, artist_name: str, album_name: str, allow_album_only: bool = True) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        queries = [
            ("artist-album", f'artist:"{artist_name}" album:"{album_name}"'),
        ]
        if allow_album_only:
            queries.append(("album", f'album:"{album_name}"'))
        items: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for kind, query in queries:
            if kind == "artist-album":
                cache_key = normalized_cache_key("album-search-v2", kind=kind, artist=artist_name, album=album_name)
            else:
                cache_key = normalized_cache_key("album-search-v2", kind=kind, album=album_name)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                query_items = value or []
            else:
                try:
                    response = self._search_request(q=query, type_="album", limit=10, use_global_session=True)
                except Exception as exc:
                    if self._handle_catalog_exception("searching albums", exc):
                        return None
                    continue
                query_items = safe_get(response, "albums", "items", default=[]) or []
                if query_items:
                    self._cache_set(cache_key, query_items, self._cache_ttl_seconds())
                else:
                    self._cache_miss(cache_key)
            for item in query_items:
                item_id = item.get("id")
                if item_id and item_id in seen_ids:
                    continue
                if item_id:
                    seen_ids.add(item_id)
                items.append(item)
        if not items:
            return None
        ranked = [(_album_match_score(item, artist_name, album_name), item) for item in items]
        ranked.sort(key=lambda pair: pair[0], reverse=True)
        return ranked[0][1]

    def album_tracks(self, album_id: str) -> list[dict[str, Any]]:
        if self._disabled_by_rate_limit:
            return []
        cached, value = self._cache_lookup(f"album-tracks-v1:{album_id}")
        if cached:
            return value or []
        tracks: list[dict[str, Any]] = []
        offset = 0
        while True:
            try:
                response = self._call_catalog_operation(
                    "reading album tracks",
                    lambda offset=offset: self._album_tracks_request(album_id, offset=offset),
                )
            except Exception as exc:
                if self._handle_catalog_exception("reading album tracks", exc):
                    return tracks
                return tracks
            tracks.extend(response.get("items", []))
            if not response.get("next"):
                break
            offset += response.get("limit", 50)
        self._cache_set(f"album-tracks-v1:{album_id}", tracks, self._cache_ttl_seconds())
        return tracks

    def _match_tracks_to_album(
        self,
        tracks: list[ReleaseTrack],
        album_tracks: list[dict[str, Any]],
        primary_artist: str,
        album_name: str,
    ) -> list[ReleaseTrack]:
        """Match release tracks to album tracks by normalized title, track number, and artist.
        
        Returns a list of tracks with spotify_track_id populated from album tracklist.
        
        This method is conservative: it only matches when there's a clear match on
        title, track number, AND artist. If any of these don't match, the track
        remains unmatched and will fall back to track-by-track search.
        """
        # Build index of album tracks by normalized title + track number + artist
        # This prevents matching tracks with the same title but different artists
        album_by_key: dict[tuple[str, int | None, str], dict[str, Any]] = {}
        for raw in album_tracks:
            title_key = normalize_variant_title(raw.get("name", ""))
            track_number = raw.get("track_number")
            # Get artist names from the album track
            album_artists = [artist.get("name", "") for artist in raw.get("artists", []) if artist.get("name")]
            album_artist_key = normalize_key(",".join(album_artists)) if album_artists else ""
            if title_key:
                album_by_key[(title_key, track_number, album_artist_key)] = raw
        
        matched: list[ReleaseTrack] = []
        for track in tracks:
            title_key = normalize_variant_title(track.title)
            track_number = track.track_number
            # Get artist key from the input track
            track_artists = [a.strip() for a in track.artists.split(",") if a.strip()]
            track_artist_key = normalize_key(",".join(track_artists)) if track_artists else ""
            
            # Try exact match with track number and artist
            # This is the most conservative approach - we require all three to match
            key = (title_key, track_number, track_artist_key)
            raw = album_by_key.get(key)
            
            # If no exact match, try with empty artist key (album track has no artist info)
            # This handles cases where album tracks don't have artist data but input does
            if not raw and track_artist_key:
                key = (title_key, track_number, "")
                raw = album_by_key.get(key)
            
            # Only match if we have a clear match on all three criteria
            # Don't fall back to title-only or track-number-only matches
            # This prevents matching "Boots on the Ground" by Frank Foster when
            # we're looking for "Boots on the Ground" by Massive Attack & Tom Waits
            if raw:
                # If both have artist info, verify it matches
                if track_artist_key:
                    raw_artists = [artist.get("name", "") for artist in raw.get("artists", []) if artist.get("name")]
                    raw_artist_key = normalize_key(",".join(raw_artists)) if raw_artists else ""
                    if raw_artist_key and raw_artist_key != track_artist_key:
                        # Artist mismatch - don't match
                        continue
                # Artist matches or one side has no artist info - apply match
                track.spotify_track_id = raw.get("id")
                track.spotify_uri = raw.get("uri")
                track.isrc = safe_get(raw, "external_ids", "isrc") or track.isrc
                if track.isrc:
                    if not track.isrc_source:
                        track.isrc_source = "input"
                elif not track.isrc_source:
                    track.isrc_source = "s_nF"
                track.popularity = int(raw.get("popularity") or track.popularity or 0)
                if not track.resolution_source:
                    track.resolution_source = "spotify_album_tracklist"
                if not track.resolution_note:
                    track.resolution_note = "Resolved from Spotify album tracklist via backfill."
                matched.append(track)
        return matched

    def backfill_release_tracks(
        self,
        album_name: str,
        tracks: list[ReleaseTrack],
        *,
        artist_name: str | None = None,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_window: DiscoveryWindow | None = None,
        discovery_today: dt.date | None = None,
    ) -> list[ReleaseTrack]:
        if self._disabled_by_rate_limit:
            return tracks
        
        # --- Album-first matching: try to find the album and match all tracks at once ---
        primary_artist = _primary_artist_name(artist_name or "")
        if primary_artist and album_name:
            cache_key = normalized_cache_key("album-track-match-v1", artist=primary_artist, album=album_name)
            cached, value = self._cache_lookup(cache_key)
            if cached and value:
                # Use cached match result - apply with strict artist and title verification
                matched_tracks = [
                    item if isinstance(item, ReleaseTrack) else ReleaseTrack.model_validate(item)
                    for item in value
                ]
                for track in tracks:
                    if track.spotify_track_id:
                        # Already matched
                        continue
                    for mt in matched_tracks:
                        # Strict match: title + artist must match
                        if mt.title != track.title:
                            continue
                        track_artists = [a.strip() for a in track.artists.split(",") if a.strip()]
                        mt_artists = [a.strip() for a in mt.artists.split(",") if a.strip()]
                        # Check if any artist matches (case-insensitive)
                        artist_match = any(
                            normalize_key(ta) == normalize_key(ma)
                            for ta in track_artists
                            for ma in mt_artists
                        )
                        # Only apply match if artist matches - don't allow fallback to title-only
                        if artist_match:
                            track.spotify_track_id = mt.spotify_track_id
                            track.spotify_uri = mt.spotify_uri
                            track.isrc = mt.isrc or track.isrc
                            if track.isrc and not track.isrc_source:
                                track.isrc_source = "input"
                            if not track.isrc or (mt.isrc and not track.isrc_source):
                                track.isrc_source = mt.isrc_source or track.isrc_source
                            track.popularity = mt.popularity or track.popularity
                            track.resolution_source = mt.resolution_source or track.resolution_source
                            track.resolution_note = mt.resolution_note or track.resolution_note
                            break
            else:
                # Perform album search and tracklist fetch
                album = self.search_album(primary_artist, album_name, allow_album_only=True)
                if album:
                    if not _candidate_release_within_discovery_window(
                        {"album": {"release_date": safe_get(album, "release_date")}},
                        release_date=release_date,
                        discovery_months=discovery_months,
                        discovery_window=discovery_window,
                        discovery_today=discovery_today,
                    ):
                        album = None
                if album:
                    album_id = album.get("id")
                    if album_id:
                        raw_tracks = self.album_tracks(album_id)
                        matched_tracks = self._match_tracks_to_album(tracks, raw_tracks, primary_artist, album_name)
                        # Cache the match result
                        self._cache_set(
                            cache_key,
                            [track.model_dump(mode="json") for track in matched_tracks],
                            self._cache_ttl_seconds(),
                        )
                        # Apply matches to input tracks - strict artist and title verification
                        for track in tracks:
                            if track.spotify_track_id:
                                continue
                            for mt in matched_tracks:
                                # Strict match: title + artist must match
                                if mt.title != track.title:
                                    continue
                                track_artists = [a.strip() for a in track.artists.split(",") if a.strip()]
                                mt_artists = [a.strip() for a in mt.artists.split(",") if a.strip()]
                                # Check if any artist matches (case-insensitive)
                                artist_match = any(
                                    normalize_key(ta) == normalize_key(ma)
                                    for ta in track_artists
                                    for ma in mt_artists
                                )
                                # Only apply match if artist matches - don't allow fallback to title-only
                                if artist_match:
                                    track.spotify_track_id = mt.spotify_track_id
                                    track.spotify_uri = mt.spotify_uri
                                    track.isrc = mt.isrc or track.isrc
                                    if track.isrc and not track.isrc_source:
                                        track.isrc_source = "input"
                                    if mt.isrc and not track.isrc_source:
                                        track.isrc_source = mt.isrc_source or track.isrc_source
                                    track.popularity = mt.popularity or track.popularity
                                    track.resolution_source = mt.resolution_source or track.resolution_source
                                    track.resolution_note = mt.resolution_note or track.resolution_note
                                    break
        
        # --- Track-by-track fallback for unmatched tracks ---
        resolved: list[ReleaseTrack] = []
        for track in tracks:
            if track.spotify_track_id:
                if not track.resolution_source:
                    track.resolution_source = "spotify_album_tracklist"
                if not track.resolution_note:
                    track.resolution_note = "Resolved from Spotify album tracklist."
                resolved.append(track)
                continue

            cached = self._cached_track_match(track, album_name=album_name)
            if cached:
                resolved.append(
                    _apply_track_match(
                        track,
                        cached,
                        source="spotify_cached_track",
                        note="Reused cached Spotify track match.",
                    )
                )
                continue

            primary_artist = _primary_artist_name(track.artists or artist_name or "")
            match = None
            if track.isrc:
                match = self._search_track_match_compat(
                    cache_key=normalized_cache_key("track-search-v2", mode="isrc", isrc=track.isrc),
                    query=f"isrc:{track.isrc}",
                    track=track,
                    album_name=album_name,
                    primary_artist=primary_artist,
                    source="spotify_track_search_isrc",
                    note="Matched via Spotify ISRC search.",
                    release_date=release_date,
                    discovery_months=discovery_months,
                    discovery_window=discovery_window,
                    discovery_today=discovery_today,
                )
            if not match:
                match = self._search_track_match_compat(
                    cache_key=normalized_cache_key(
                        "track-search-v2",
                        mode="strict",
                        artist=primary_artist,
                        track=track.title,
                        album=album_name,
                    ),
                    query=_strict_track_query(primary_artist=primary_artist, track_title=track.title, album_name=album_name),
                    track=track,
                    album_name=album_name,
                    primary_artist=primary_artist,
                    source="spotify_track_search_strict",
                    note="Matched exact title/artist/album context.",
                    release_date=release_date,
                    discovery_months=discovery_months,
                    discovery_window=discovery_window,
                    discovery_today=discovery_today,
                )
            if not match:
                for query in keyword_query_variants(primary_artist, track.title, album_name, max_queries=3):
                    match = self._search_track_match_compat(
                        cache_key=normalized_cache_key(
                            "track-search-v2",
                            mode="keyword",
                            query=query,
                            track=track.title,
                            album=album_name,
                        ),
                        query=query,
                        track=track,
                        album_name=album_name,
                        primary_artist=primary_artist,
                        source="spotify_track_search_keywords",
                        note="Matched via normalized keyword fallback.",
                        release_date=release_date,
                        discovery_months=discovery_months,
                        discovery_window=discovery_window,
                        discovery_today=discovery_today,
                    )
                    if match:
                        break
            if match:
                resolved.append(_apply_track_match(track, match, source=match["resolution_source"], note=match["resolution_note"]))
                continue

            if not track.resolution_source:
                track.resolution_source = "musicbrainz_tracklist"
            if not track.resolution_note:
                track.resolution_note = "Spotify unresolved; using MusicBrainz tracklist."
            resolved.append(track)
        return resolved

    def _search_track_match_compat(self, **kwargs) -> dict[str, Any] | None:
        try:
            return self._search_track_match(**kwargs)
        except TypeError:
            kwargs.pop("release_date", None)
            kwargs.pop("discovery_months", None)
            kwargs.pop("discovery_window", None)
            kwargs.pop("discovery_today", None)
            return self._search_track_match(**kwargs)

    def tracks_bulk(self, track_ids: list[str]) -> list[dict[str, Any]]:
        if self._disabled_by_rate_limit:
            return []
        out: list[dict[str, Any]] = []
        missing_ids: list[str] = []
        for track_id in dict.fromkeys(track_ids):
            cache_key = normalized_cache_key("track-id-v2", track_id=track_id)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                if value:
                    out.append(value)
                continue
            missing_ids.append(track_id)
        for track_id, track in self._fetch_single_resources(missing_ids, self._track_request, "reading track details"):
            cache_key = normalized_cache_key("track-id-v2", track_id=track_id)
            if not track:
                self._cache_miss(cache_key)
                continue
            self._cache_set(cache_key, track, self._cache_ttl_seconds())
            out.append(track)
        return out

    def backfill_track_enrichment(self, tracks: list[InputTrack], limit: int = 50) -> int:
        if not self.available or self._disabled_by_rate_limit or not self.storage:
            return 0
        by_id: dict[str, InputTrack] = {}
        for track in tracks:
            if not track.spotify_track_id or track.spotify_track_id in by_id:
                continue
            existing = self.storage.get_track_enrichment(provider="spotify", spotify_track_id=track.spotify_track_id)
            if existing and existing.get("status") == "success" and existing.get("payload", {}).get("source") == "spotify_track_details":
                continue
            if existing and existing.get("status") == "miss":
                continue
            by_id[track.spotify_track_id] = track
            if len(by_id) >= limit:
                break
        if not by_id:
            return 0

        raw_tracks = self.tracks_bulk(list(by_id))
        returned_by_id = {item.get("id"): item for item in raw_tracks if item and item.get("id")}
        saved = 0
        for track_id, raw in returned_by_id.items():
            original = by_id[track_id]
            artist_names = [artist.get("name", "") for artist in raw.get("artists", []) if artist.get("name")]
            album_artists = safe_get(raw, "album", "artists", default=[]) or []
            payload = {
                "source": "spotify_track_details",
                "id": track_id,
                "name": raw.get("name"),
                "album": safe_get(raw, "album", "name"),
                "spotify_album_id": safe_get(raw, "album", "id"),
                "artists": artist_names,
                "artist_ids": [artist.get("id") for artist in raw.get("artists", []) if artist.get("id")],
                "album_artist_ids": [artist.get("id") for artist in album_artists if artist.get("id")],
                "isrc": safe_get(raw, "external_ids", "isrc"),
                "uri": raw.get("uri"),
                "popularity": raw.get("popularity"),
            }
            self.storage.upsert_track_enrichment(
                provider="spotify",
                track=original,
                artist=artist_names[0] if artist_names else original.artist,
                title=raw.get("name") or original.track,
                album=safe_get(raw, "album", "name") or original.album,
                isrc=safe_get(raw, "external_ids", "isrc") or original.isrc,
                spotify_track_id=track_id,
                spotify_album_id=safe_get(raw, "album", "id") or original.spotify_album_id,
                payload={key: value for key, value in payload.items() if value not in (None, "", [])},
            )
            saved += 1

        missing_ids = set(by_id) - set(returned_by_id)
        status = "rate_limited" if self._disabled_by_rate_limit else "miss"
        for track_id in missing_ids:
            existing = self.storage.get_track_enrichment(provider="spotify", spotify_track_id=track_id)
            if existing and existing.get("status") == "success" and existing.get("payload", {}).get("source") == "input":
                continue
            self.storage.upsert_track_enrichment(
                provider="spotify",
                track=by_id[track_id],
                status=status,
                payload={"source": "spotify_track_details"},
            )
        return saved

    def representative_tracks(
        self,
        artist_name: str,
        album_name: str,
        cap: int,
        allow_broad_search: bool = True,
        *,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_window: DiscoveryWindow | None = None,
        discovery_today: dt.date | None = None,
    ) -> tuple[str | None, str | None, list[ReleaseTrack]]:
        if self._disabled_by_rate_limit:
            return None, None, []
        try:
            album = self.search_album(artist_name, album_name, allow_album_only=allow_broad_search)
        except TypeError:
            album = self.search_album(artist_name, album_name)
        if album:
            album_id = album.get("id")
            album_uri = album.get("uri")
            # Check discovery window for album
            album_release_date = safe_get(album, "release_date")
            if not _candidate_release_within_discovery_window(
                {"album": {"release_date": album_release_date}},
                release_date=release_date,
                discovery_months=discovery_months,
                discovery_window=discovery_window,
                discovery_today=discovery_today,
            ):
                return None, None, []
            raw_tracks = self.album_tracks(album_id)
            # Album tracklists already contain enough data to build a shareable mix.
            # Avoid the optional bulk track-details endpoint because some Spotify
            # accounts return 403 there even after playlist/album calls succeed.
            selected = select_representative_tracks(raw_tracks, {}, cap)
            return album_id, album_uri, selected
        return self._representative_tracks_from_track_search(
            artist_name=artist_name,
            album_name=album_name,
            cap=cap,
            allow_broad_search=allow_broad_search,
            release_date=release_date,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )

    def create_playlist(self, name: str, description: str, uris: list[str]) -> SpotifyPlaylistCreationResult:
        if not uris:
            return SpotifyPlaylistCreationResult(created=False, reason="no_uris")
        if self._disabled_by_rate_limit:
            return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
        sp = self.user_client(self.operation_spec("create_playlist").scopes)
        try:
            playlist = self._call_required_operation(
                "creating playlist",
                lambda: self._create_playlist_request(sp, name=name, description=description),
            )
            playlist_id = playlist["id"]
            for batch in chunked(uris, 100):
                self._call_required_operation(
                    "adding playlist items",
                    lambda batch=batch: sp.playlist_add_items(playlist_id, batch),
                )
            return SpotifyPlaylistCreationResult(
                created=True,
                url=playlist.get("external_urls", {}).get("spotify"),
            )
        except ProviderRateLimit as issue:
            if issue.error_kind == "rate_limited":
                return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
            return SpotifyPlaylistCreationResult(created=False, reason=str(issue).splitlines()[0][:160])
        except Exception as exc:
            issue = self._provider_issue("creating playlist", exc)
            if issue:
                self.rate_limit_warnings.append(issue)
                if not issue.should_auto_wait:
                    self._disabled_by_rate_limit = True
                if issue.error_kind == "rate_limited":
                    return SpotifyPlaylistCreationResult(created=False, reason="rate_limited")
                if issue.is_permission_error or issue.error_kind in {"auth_failed", "invalid_request", "content_unavailable", "forbidden_access"}:
                    return SpotifyPlaylistCreationResult(
                        created=False,
                        reason=str(issue).splitlines()[0][:160],
                    )
                return SpotifyPlaylistCreationResult(created=False, reason=str(issue).splitlines()[0][:160])
            return SpotifyPlaylistCreationResult(created=False, reason=str(exc).splitlines()[0][:160])

    def _record_rate_limit(self, operation: str, exc: Exception) -> bool:
        rate_limit = self._provider_issue(operation, exc)
        if not rate_limit:
            return False
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True
        return True

    def _call_required_operation(self, operation: str, func):
        last_issue: ProviderRateLimit | None = None
        for attempt in range(REQUIRED_OPERATION_MAX_RETRIES):
            try:
                self._record_api_call()
                return func()
            except Exception as exc:
                if is_network_error(exc):
                    raise ProviderUnavailable(format_network_error("Spotify", operation)) from exc
                issue = self._provider_issue(operation, exc)
                if not issue:
                    raise
                if issue.error_kind != "rate_limited":
                    raise issue from exc
                last_issue = issue
                if issue.retry_after_seconds is not None and not issue.should_auto_wait:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                if attempt == REQUIRED_OPERATION_MAX_RETRIES - 1:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                self.retry_count = getattr(self, "retry_count", 0) + 1
                delay = exponential_backoff_with_retry_after(issue.retry_after_seconds, attempt)
                self._sleep_for_retry(delay)
        if last_issue is not None:
            raise last_issue
        raise RuntimeError(f"Spotify operation failed unexpectedly: {operation}")

    def _sleep_for_retry(self, seconds: int) -> None:
        time.sleep(seconds)

    def _call_catalog_operation(self, operation: str, func):
        last_issue: ProviderRateLimit | None = None
        for attempt in range(CATALOG_OPERATION_MAX_RETRIES):
            try:
                with _SPOTIFY_CATALOG_SEMAPHORE:
                    self._pace_catalog_request()
                    self._record_api_call()
                    return func()
            except Exception as exc:
                if is_network_error(exc):
                    raise ProviderUnavailable(format_network_error("Spotify", operation)) from exc
                issue = self._provider_issue(operation, exc)
                if not issue:
                    raise
                if issue.error_kind != "rate_limited":
                    raise issue from exc
                last_issue = issue
                if issue.retry_after_seconds is not None and not issue.should_auto_wait:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                if attempt == CATALOG_OPERATION_MAX_RETRIES - 1:
                    self.rate_limit_warnings.append(issue)
                    raise issue from exc
                self.retry_count = getattr(self, "retry_count", 0) + 1
                delay = exponential_backoff_with_retry_after(issue.retry_after_seconds, attempt)
                delay += random.uniform(0, max(0.0, delay * 0.25))
                self._sleep_for_retry(int(delay) if delay >= 1 else delay)
        if last_issue is not None:
            raise last_issue
        raise RuntimeError(f"Spotify catalog operation failed unexpectedly: {operation}")

    def _pace_catalog_request(self) -> None:
        global _SPOTIFY_LAST_CATALOG_REQUEST_AT
        with _SPOTIFY_CATALOG_PACE_LOCK:
            now = time.monotonic()
            base_wait = SPOTIFY_CATALOG_MIN_INTERVAL_SECONDS - (now - _SPOTIFY_LAST_CATALOG_REQUEST_AT)
            if base_wait > 0:
                # Add random jitter to prevent thundering herd pattern
                jitter = random.uniform(0, SPOTIFY_CATALOG_MAX_JITTER_SECONDS)
                total_wait = base_wait + jitter
                self._sleep_for_retry(total_wait)
            _SPOTIFY_LAST_CATALOG_REQUEST_AT = time.monotonic()

    def _fetch_single_resources(self, ids: list[str], request, operation: str) -> list[tuple[str, dict[str, Any] | None]]:
        unique_ids = list(dict.fromkeys(ids))
        if not unique_ids:
            return []
        results: list[tuple[str, dict[str, Any] | None]] = []
        max_workers = min(SPOTIFY_CATALOG_MAX_WORKERS, len(unique_ids))
        for batch in chunked(unique_ids, max_workers):
            stop = False
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self._call_catalog_operation, operation, lambda item_id=item_id: request(item_id)): item_id
                    for item_id in batch
                }
                for future in as_completed(futures):
                    item_id = futures[future]
                    try:
                        results.append((item_id, future.result()))
                    except Exception as exc:
                        if self._handle_catalog_exception(operation, exc):
                            stop = True
            if stop:
                break
        return results

    def _create_playlist_request(self, client: Any, *, name: str, description: str) -> dict[str, Any]:
        if hasattr(client, "current_user_playlist_create"):
            return client.current_user_playlist_create(name=name, public=False, description=description)
        if hasattr(client, "_post") and callable(getattr(client, "_post")):
            return client._post(
                "me/playlists",
                payload={
                    "name": name,
                    "public": False,
                    "collaborative": False,
                    "description": description,
                },
            )
        raise RuntimeError("Spotify client cannot create playlists with /me/playlists.")

    _ACTION_MAP: dict[tuple[str, str], str] = {
        ("auth_failed", "playlist"): "RECONNECT_SPOTIFY",
        ("insufficient_scope", "playlist"): "RECONNECT_SPOTIFY",
        ("forbidden_access", "playlist"): "CHECK_PLAYLIST_ACCESS",
        ("auth_failed", "creating playlist"): "RECONNECT_SPOTIFY",
        ("insufficient_scope", "creating playlist"): "RECONNECT_SPOTIFY",
    }

    def _action_for_issue(self, issue: ProviderRateLimit) -> str | None:
        key = (issue.error_kind or "", issue.operation)
        action = self._ACTION_MAP.get(key)
        if action:
            return action
        if "playlist" in issue.operation:
            generic_key = (issue.error_kind or "", "playlist")
            return self._ACTION_MAP.get(generic_key)
        return None

    def _provider_issue(self, operation: str, exc: Exception) -> ProviderRateLimit | None:
        if isinstance(exc, ProviderRateLimit):
            return exc
        issue = rate_limit_from_exception("Spotify", operation, exc)
        if not issue:
            issue = self._oauth_issue_from_exception(operation, exc)
            if not issue:
                return None
        if issue.error_kind == "permission_denied" and "playlist" in operation:
            issue.error_kind = "forbidden_access"
        if issue.error_kind == "invalid_request":
            detail = (issue.error_message or str(exc) or "").lower()
            if any(token in detail for token in ("market", "country", "not available")):
                issue.error_kind = "content_unavailable"
        issue.action = self._action_for_issue(issue)
        return issue

    def _oauth_issue_from_exception(self, operation: str, exc: Exception) -> ProviderRateLimit | None:
        is_oauth_exception = (
            hasattr(exc, "error")
            or hasattr(exc, "error_description")
            or "spotifyoautherror" in exc.__class__.__name__.lower()
        )
        if not is_oauth_exception:
            return None
        error_code = (getattr(exc, "error", "") or "").strip().lower()
        description = (getattr(exc, "error_description", "") or "").strip()
        message = (description or str(exc) or "").strip()
        detail = message.lower()
        if not error_code and not description and not message:
            return None
        if error_code == "invalid_client":
            return ProviderRateLimit(
                provider="Spotify",
                operation=operation,
                retry_after_seconds=None,
                recoverable=False,
                error_message=message or "Invalid Spotify client ID for PKCE token refresh",
                status_code=401,
                error_kind="auth_failed",
            )
        if error_code == "invalid_grant" or any(
            token in detail for token in ("expired", "revoked", "token is invalid", "invalid grant")
        ):
            return ProviderRateLimit(
                provider="Spotify",
                operation=operation,
                retry_after_seconds=None,
                recoverable=False,
                error_message=message or "Spotify token is expired or invalid",
                status_code=401,
                error_kind="auth_failed",
            )
        if "scope" in detail or error_code in {"insufficient_scope", "invalid_scope"}:
            return ProviderRateLimit(
                provider="Spotify",
                operation=operation,
                retry_after_seconds=None,
                recoverable=False,
                is_permission_error=True,
                error_message=message or "Insufficient Spotify scope",
                status_code=403,
                error_kind="insufficient_scope",
            )
        return None

    def _is_invalid_client_error(self, exc: Exception) -> bool:
        error_code = (getattr(exc, "error", "") or "").strip().lower()
        description = (getattr(exc, "error_description", "") or "").strip().lower()
        message = (str(exc) or "").strip().lower()
        return error_code == "invalid_client" or "invalid client" in description or "invalid_client" in message

    def _delete_scope_cache_file(self, cache_path: Path) -> None:
        try:
            os.remove(cache_path)
        except FileNotFoundError:
            return
        except OSError:
            return

    def _handle_catalog_exception(self, operation: str, exc: Exception) -> bool:
        if is_network_error(exc):
            issue = ProviderRateLimit(
                provider="Spotify",
                operation=operation,
                retry_after_seconds=None,
                recoverable=False,
                error_message=format_network_error("Spotify", operation),
                error_kind="network_error",
            )
            if not any(
                existing.operation == issue.operation
                and existing.error_kind == issue.error_kind
                for existing in self.rate_limit_warnings
            ):
                self.rate_limit_warnings.append(issue)
            self.__disabled_by_rate_limit = True
            return True
        issue = self._provider_issue(operation, exc)
        if not issue:
            return False
        if not any(
            existing.operation == issue.operation
            and existing.status_code == issue.status_code
            and existing.error_kind == issue.error_kind
            for existing in self.rate_limit_warnings
        ):
            self.rate_limit_warnings.append(issue)
        if issue.error_kind == "rate_limited":
            cooldown = issue.retry_after_seconds if issue.retry_after_seconds is not None else 60
            deadline = time.monotonic() + cooldown
            with self.__catalog_cooldown_lock:
                if deadline > self.__catalog_cooldown_until:
                    self.__catalog_cooldown_until = deadline
                    retry_at = time.strftime("%H:%M:%S", time.localtime(time.time() + cooldown))
                    print(f"Spotify rate limit - {cooldown}s cooldown, try again at {retry_at}", flush=True)
        elif issue.is_permission_error or issue.error_kind in {"auth_failed", "insufficient_scope", "forbidden_access"}:
            self.__disabled_by_rate_limit = True
        return True

    def _catalog_market(self) -> str | None:
        settings = getattr(self, "settings", None)
        raw = (getattr(settings, "spotify_market", "") or "").strip().upper()
        if len(raw) == 2 and raw.isalpha():
            return raw
        return None

    def _catalog_request_kwargs(self, *, limit: int) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"limit": limit}
        market = self._catalog_market()
        if market:
            kwargs["market"] = market
        return kwargs

    def _search_request(self, *, q: str, type_: str, limit: int, offset: int = 0, use_global_session: bool = False) -> dict[str, Any]:
        """
        Search Spotify catalog for items matching the query.

        NOTE: The spotipy library's internal _get method may have issues with parameter
        handling for the search endpoint. We use the public search() method which is
        more stable and better maintained.
        """
        return self._call_catalog_operation(
            f"searching {type_}s",
            lambda: self._search_request_once(q=q, type_=type_, limit=limit, offset=offset, use_global_session=use_global_session),
        )

    def _search_request_once(self, *, q: str, type_: str, limit: int, offset: int = 0, use_global_session: bool = False) -> dict[str, Any]:
        client = self.client()
        kwargs = {"q": q, "type": type_, "limit": limit, "offset": offset}
        market = self._catalog_market()
        if market:
            kwargs["market"] = market
        # Filter out any None values that spotipy might reject
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        return client.search(**kwargs)

    def _artist_request(self, artist_id: str) -> dict[str, Any] | None:
        client = self.client()
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            return client._get(f"artists/{artist_id}")
        return client.artist(artist_id)

    def _track_request(self, track_id: str) -> dict[str, Any] | None:
        client = self.client()
        market = self._catalog_market()
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            kwargs: dict[str, Any] = {}
            if market:
                kwargs["market"] = market
            return client._get(f"tracks/{track_id}", **kwargs)
        if market:
            return client.track(track_id, market=market)
        return client.track(track_id)

    def _album_tracks_request(self, album_id: str, *, offset: int) -> dict[str, Any]:
        client = self.client()
        kwargs: dict[str, Any] = {"limit": 50, "offset": offset}
        market = self._catalog_market()
        if market:
            kwargs["market"] = market
        if hasattr(client, "_get") and callable(getattr(client, "_get")):
            return client._get(f"albums/{album_id}/tracks", **kwargs)
        return client.album_tracks(album_id, **kwargs)

    def _scope_cache_path(self, scopes: str) -> Path:
        scope_slug = normalize_key(scopes).replace(" ", "_") or "user"
        return self.settings.data_dir / f".spotipy_token_cache_{scope_slug}"

    def _cache_lookup(self, key: str) -> tuple[bool, Any | None]:
        storage = getattr(self, "storage", None)
        if not storage:
            return False, None
        settings = getattr(self, "settings", None)
        if getattr(settings, "force_refresh", False):
            return False, None
        value = storage.get_cache("spotify", key)
        if value is None:
            self.cache_misses = getattr(self, "cache_misses", 0) + 1
            return False, None
        self.cache_hits = getattr(self, "cache_hits", 0) + 1
        if value == MISS_SENTINEL:
            return True, None
        return True, value

    def _record_api_call(self) -> None:
        self.api_calls = getattr(self, "api_calls", 0) + 1

    def _cache_set(self, key: str, value: Any, ttl_seconds: int) -> None:
        storage = getattr(self, "storage", None)
        if storage:
            storage.set_cache("spotify", key, value, ttl_seconds)

    def _cache_miss(self, key: str) -> None:
        self._cache_set(key, MISS_SENTINEL, self._cache_miss_ttl_seconds())

    def _cache_artist(self, artist: dict[str, Any], name_key: str | None = None) -> None:
        artist_id = artist.get("id")
        if artist_id:
            self._cache_set(
                normalized_cache_key("artist-id-v2", artist_id=artist_id),
                artist,
                self._cache_ttl_seconds(),
            )
        if name_key:
            self._cache_set(name_key, artist, self._cache_ttl_seconds())
        if artist.get("name"):
            self._cache_set(
                normalized_cache_key("artist-name-v2", artist=artist.get("name")),
                artist,
                self._cache_ttl_seconds(),
            )

    def _cached_track_match(self, track: ReleaseTrack, *, album_name: str) -> dict[str, Any] | None:
        cache_keys: list[str] = []
        if track.isrc:
            cache_keys.append(normalized_cache_key("track-search-v2", mode="isrc", isrc=track.isrc))
        primary_artist = _primary_artist_name(track.artists)
        cache_keys.append(
            normalized_cache_key(
                "track-search-v2",
                mode="strict",
                artist=primary_artist,
                track=track.title,
                album=album_name,
            )
        )
        for cache_key in cache_keys:
            cached, value = self._cache_lookup(cache_key)
            if cached and value:
                return value
        storage = getattr(self, "storage", None)
        if not storage:
            return None
        row = storage.get_track_enrichment(
            provider="spotify",
            artist=primary_artist or track.artists,
            title=track.title,
            isrc=track.isrc,
        )
        if not row or row["status"] != "success":
            return None
        album_key = normalize_variant_title(album_name)
        row_album_key = normalize_variant_title(row.get("album"))
        if album_key and row_album_key and album_key != row_album_key:
            return None
        payload = dict(row.get("payload", {}))
        spotify_track_id = row.get("spotify_track_id") or payload.get("spotify_track_id") or payload.get("id")
        if not spotify_track_id:
            return None
        artists = payload.get("artists") or split_artist_names(track.artists or primary_artist)
        return {
            "id": spotify_track_id,
            "uri": payload.get("uri"),
            "name": payload.get("name") or row.get("title") or track.title,
            "album": {"id": row.get("spotify_album_id"), "name": row.get("album") or album_name},
            "artists": [{"name": name} for name in artists if name],
            "external_ids": {"isrc": row.get("isrc") or payload.get("isrc") or track.isrc},
            "popularity": payload.get("popularity") or 0,
        }

    def _search_track_match(
        self,
        *,
        cache_key: str,
        query: str,
        track: ReleaseTrack,
        album_name: str,
        primary_artist: str,
        source: str,
        note: str,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_window: DiscoveryWindow | None = None,
        discovery_today: dt.date | None = None,
    ) -> dict[str, Any] | None:
        if self._disabled_by_rate_limit:
            return None
        cached, value = self._cache_lookup(cache_key)
        if cached:
            return value
        # Caller controls fallback fan-out order (ISRC -> strict -> keywords).
        # This helper must execute only the provided query.
        items = self._search_track_items_resilient([query], limit=10, use_global_session=True)
        if not items and source == "spotify_track_search_strict":
            narrow_artist = _primary_artist_name(primary_artist)
            strict_narrow = _strict_track_query(
                primary_artist=narrow_artist,
                track_title=track.title,
                album_name=album_name,
            )
            if strict_narrow and strict_narrow != query:
                items = self._search_track_items_resilient([strict_narrow], limit=10, use_global_session=True)
        target = {
            "album_name": album_name,
            "isrc": track.isrc,
            "primary_artist": primary_artist,
            "track_title": track.title,
        }
        candidates = _spotify_match_candidates(
            items,
            target=target,
            query_source=source,
            allow_relaxed_title_overlap=False,
        )
        if not candidates:
            # Controlled relaxed pass only when strict matching yielded nothing.
            candidates = _spotify_match_candidates(
                items,
                target=target,
                query_source=source,
                allow_relaxed_title_overlap=True,
            )
        if not candidates:
            self._cache_miss(cache_key)
            return None
        selection = select_staged_candidate(
            candidates,
            target_isrc=track.isrc,
            mb_release_date=release_date,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )
        if selection is None:
            self._cache_miss(cache_key)
            return None
        stage_note = f"{note} [stage:{selection.stage}]"
        best = _track_payload(
            selection.candidate.raw_payload,
            resolution_source=source,
            resolution_note=stage_note,
        )
        self._cache_set(cache_key, best, self._cache_ttl_seconds())
        storage = getattr(self, "storage", None)
        if storage:
            storage.upsert_track_enrichment(
                provider="spotify",
                artist=primary_artist or track.artists,
                title=track.title,
                album=album_name,
                isrc=track.isrc,
                spotify_track_id=best.get("id"),
                spotify_album_id=safe_get(best, "album", "id"),
                payload={
                    "source": source,
                    "name": best.get("name"),
                    "uri": best.get("uri"),
                    "isrc": safe_get(best, "external_ids", "isrc"),
                    "spotify_track_id": best.get("id"),
                    "spotify_album_id": safe_get(best, "album", "id"),
                    "artists": [artist.get("name") for artist in best.get("artists", []) if artist.get("name")],
                    "album": safe_get(best, "album", "name"),
                    "popularity": best.get("popularity"),
                    "resolution_source": source,
                    "resolution_note": stage_note,
                    "match_stage": selection.stage,
                },
            )
        return best

    def _search_track_items_resilient(self, queries: list[str], *, limit: int, use_global_session: bool = False) -> list[dict[str, Any]]:
        seen_ids: set[str] = set()
        merged: list[dict[str, Any]] = []
        for query in queries:
            if not query:
                continue
            cache_key = normalized_cache_key("track-search-items-v1", query=query, limit=limit, use_global_session=use_global_session)
            cached, value = self._cache_lookup(cache_key)
            if cached:
                items = value or []
            else:
                try:
                    response = self._search_request(q=query, type_="track", limit=limit, use_global_session=use_global_session)
                except Exception as exc:
                    if self._handle_catalog_exception("searching tracks", exc):
                        continue
                    continue
                items = safe_get(response, "tracks", "items", default=[]) or []
                if items:
                    self._cache_set(cache_key, items, self._cache_ttl_seconds())
                else:
                    self._cache_miss(cache_key)
            for item in items:
                track_id = item.get("id")
                if track_id and track_id in seen_ids:
                    continue
                if track_id:
                    seen_ids.add(track_id)
                merged.append(item)
        return merged

    def _representative_tracks_from_track_search(
        self,
        *,
        artist_name: str,
        album_name: str,
        cap: int,
        allow_broad_search: bool,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_window: DiscoveryWindow | None = None,
        discovery_today: dt.date | None = None,
    ) -> tuple[str | None, str | None, list[ReleaseTrack]]:
        if self._disabled_by_rate_limit:
            return None, None, []
        queries = [f'artist:"{artist_name}" album:"{album_name}"']
        if allow_broad_search:
            queries.append(f'album:"{album_name}"')
        candidates: list[dict[str, Any]] = []
        seen_track_ids: set[str] = set()
        for query in queries:
            items = self._search_track_items_resilient([query], limit=10, use_global_session=True)
            for item in items:
                track_id = item.get("id")
                if track_id and track_id in seen_track_ids:
                    continue
                if track_id:
                    seen_track_ids.add(track_id)
                candidates.append(item)
            clustered = _best_track_search_album_cluster(candidates, artist_name=artist_name, album_name=album_name)
            if clustered:
                album_id = safe_get(clustered[0], "album", "id")
                album_uri = safe_get(clustered[0], "album", "uri") or (f"spotify:album:{album_id}" if album_id else None)
                # Filter clustered tracks by discovery window
                filtered_clustered = []
                for item in clustered:
                    if _candidate_release_within_discovery_window(
                        item,
                        release_date=release_date,
                        discovery_months=discovery_months,
                        discovery_window=discovery_window,
                        discovery_today=discovery_today,
                    ):
                        filtered_clustered.append(item)
                if not filtered_clustered:
                    continue
                selected = select_representative_tracks(
                    filtered_clustered,
                    {},
                    cap,
                    resolution_source="spotify_track_search_album_context",
                    resolution_note="Resolved from Spotify track search after album lookup missed.",
                )
                return album_id, album_uri, selected
        return None, None, []

    def cache_summary(self) -> dict[str, int | bool]:
        return {
            "cache_hits": getattr(self, "cache_hits", 0),
            "cache_misses": getattr(self, "cache_misses", 0),
            "api_calls": getattr(self, "api_calls", 0),
            "retry_count": getattr(self, "retry_count", 0),
            "disabled_by_rate_limit": self._disabled_by_rate_limit,
            "catalog_cooldown_remaining_seconds": max(0.0, getattr(self, '_SpotifyProvider__catalog_cooldown_until', 0.0) - time.monotonic()),
        }

    def catalog_cooldown_remaining_seconds(self) -> float:
        return max(0.0, getattr(self, "_SpotifyProvider__catalog_cooldown_until", 0.0) - time.monotonic())

    def _cache_ttl_seconds(self) -> int:
        settings = getattr(self, "settings", None)
        return int(getattr(settings, "spotify_cache_ttl_seconds", 30 * 24 * 60 * 60))

    def _cache_miss_ttl_seconds(self) -> int:
        settings = getattr(self, "settings", None)
        return int(getattr(settings, "spotify_cache_miss_ttl_seconds", 30 * 24 * 60 * 60))


def select_representative_tracks(
    raw_tracks: list[dict[str, Any]],
    track_details: dict[str, dict[str, Any]],
    cap: int,
    *,
    resolution_source: str = "spotify_album_tracklist",
    resolution_note: str = "Resolved from Spotify album tracklist.",
) -> list[ReleaseTrack]:
    enriched: list[tuple[float, int, ReleaseTrack]] = []
    total = len(raw_tracks)
    for idx, track in enumerate(raw_tracks, start=1):
        track_id = track.get("id")
        details = track_details.get(track_id, {})
        popularity = 0
        track_number = int(track.get("track_number") or idx)
        score = representative_position_bonus(track_number, total)
        artists = ", ".join(artist.get("name", "") for artist in track.get("artists", []) if artist.get("name"))
        isrc = safe_get(track, "external_ids", "isrc") or safe_get(details, "external_ids", "isrc")
        enriched.append(
            (
                score,
                track_number,
                ReleaseTrack(
                    title=track.get("name", ""),
                    artists=artists,
                    track_number=track_number,
                    spotify_track_id=track_id,
                    spotify_uri=track.get("uri"),
                    isrc=isrc,
                    isrc_source="spotify" if isrc else "s_nF",
                    popularity=popularity,
                    popularity_value=None,
                    popularity_provider=None,
                    popularity_metric=None,
                    resolution_source=resolution_source,
                    resolution_note=resolution_note,
                ),
            )
        )
    enriched.sort(key=lambda item: (item[0], -item[1]), reverse=True)
    selected = [item[2] for item in enriched[:cap]]
    return sorted(selected, key=lambda track: track.track_number or 0)


def _album_match_score(item: dict[str, Any], artist_name: str, album_name: str) -> int:
    target_artist = normalize_key(artist_name)
    target_album = normalize_key(album_name)
    album_key = normalize_key(item.get("name"))
    artist_keys = {
        normalize_key(artist.get("name"))
        for artist in item.get("artists", [])
        if artist.get("name")
    }

    score = 0
    if album_key == target_album:
        score += 10
    elif target_album and (target_album in album_key or album_key in target_album):
        score += 4
    target_artist_parts = {
        normalize_key(part.strip())
        for part in re.split(r"[&,]", artist_name)
        if part.strip()
    }
    if target_artist in artist_keys or bool(target_artist_parts & artist_keys):
        score += 5
    if item.get("album_type") == "album":
        score += 1
    return score


def playlist_item_track(item: dict[str, Any]) -> dict[str, Any]:
    """Return the track payload from old (`track`), current (`item`), or nested item shapes."""
    track = item.get("track") or item.get("item") or {}
    if isinstance(track, dict) and isinstance(track.get("track"), dict):
        track = track["track"]
    return track if isinstance(track, dict) else {}


def representative_position_bonus(index: int, total: int) -> float:
    if total <= 1:
        return 1.0
    first_bonus = max(0.0, 1.4 - (index - 1) * 0.18)
    mid = (total + 1) / 2.0
    mid_bonus = max(0.0, 1.0 - abs(index - mid) / max(1.0, total / 4.0))
    return first_bonus + mid_bonus


def _apply_track_match(track: ReleaseTrack, payload: dict[str, Any], *, source: str, note: str) -> ReleaseTrack:
    track.spotify_track_id = payload.get("id") or track.spotify_track_id
    track.spotify_uri = payload.get("uri") or track.spotify_uri
    isrc = safe_get(payload, "external_ids", "isrc")
    if isrc and not track.isrc:
        track.isrc = isrc
        track.isrc_source = "spotify"
    elif not isrc and not track.isrc_source:
        track.isrc_source = "s_nF"
    # Preserve input ISRC source if track already has ISRC from input
    if track.isrc and not track.isrc_source:
        track.isrc_source = "input"
    track.popularity = int(payload.get("popularity") or track.popularity or 0)
    track.resolution_source = source
    track.resolution_note = note
    return track


def _primary_artist_name(value: str) -> str:
    artists = split_artist_names(value)
    return artists[0] if artists else value


def _strict_track_query(*, primary_artist: str, track_title: str, album_name: str) -> str:
    if album_name:
        return f'track:"{track_title}" artist:"{primary_artist}" album:"{album_name}"'
    return f'track:"{track_title}" artist:"{primary_artist}"'


def _spotify_candidate_search_queries(*, artist: str, title: str, album: str, preferred_query: str | None = None) -> list[str]:
    primary_artist = _primary_artist_name(artist or "")
    normalized_title = normalize_variant_title(title)
    normalized_album = normalize_variant_title(album)
    variants = [
        preferred_query or "",
        f'artist:"{artist}" track:"{title}" album:"{album}"' if artist and title and album else "",
        f'artist:"{primary_artist}" track:"{title}" album:"{album}"' if primary_artist and title and album else "",
        f'artist:"{artist}" track:"{title}"' if artist and title else "",
        f'artist:"{primary_artist}" track:"{title}"' if primary_artist and title else "",
        f'track:"{title}" album:"{album}"' if title and album else "",
        f'track:"{title}"' if title else "",
        f"{primary_artist} {normalized_title} {normalized_album}".strip(),
        f"{normalized_title} {normalized_album}".strip(),
        normalized_title,
    ]
    out: list[str] = []
    for variant in variants:
        value = (variant or "").strip()
        if value and value not in out:
            out.append(value)
    return out


def _track_candidate_score(
    item: dict[str, Any],
    *,
    target: dict[str, Any],
    query_source: str,
    allow_relaxed_title_overlap: bool = True,
    release_date: str | None = None,
    discovery_months: int | None = None,
    discovery_today: dt.date | None = None,
) -> tuple[bool, int]:
    title_key = normalize_variant_title(item.get("name"))
    target_title_key = normalize_variant_title(target.get("track_title"))
    title_exact = bool(title_key and target_title_key and title_key == target_title_key)
    title_overlap = _keys_overlap(title_key, target_title_key)
    if not title_overlap and title_key and target_title_key:
        left_tokens = set(title_key.split())
        right_tokens = set(target_title_key.split())
        if left_tokens and right_tokens:
            overlap = len(left_tokens & right_tokens)
            title_overlap = overlap >= 2 and overlap >= min(len(left_tokens), len(right_tokens)) - 1

    candidate_artists = {
        normalize_key(artist.get("name"))
        for artist in item.get("artists", []) or []
        if artist.get("name")
    }
    target_artists = {normalize_key(name) for name in split_artist_names(target.get("primary_artist")) if normalize_key(name)}
    artist_overlap = len(candidate_artists & target_artists)

    album_key = normalize_variant_title(safe_get(item, "album", "name"))
    target_album_key = normalize_variant_title(target.get("album_name"))
    album_overlap = _keys_overlap(album_key, target_album_key)

    item_isrc = normalize_key(safe_get(item, "external_ids", "isrc"))
    target_isrc = normalize_key(target.get("isrc"))
    isrc_match = bool(target_isrc and item_isrc and item_isrc == target_isrc)

    # Check discovery window for non-ISRC matches
    # ISRC is unique - if matched, accept regardless of window
    # If ISRC doesn't match, enforce discovery window
    within_window = True  # Default: accept if ISRC matches
    if not isrc_match:
        within_window = _candidate_release_within_discovery_window(
            item,
            release_date=release_date,
            discovery_months=discovery_months,
            discovery_today=discovery_today,
        )

    if isrc_match:
        accepted = True
    else:
        title_ok = title_exact or (allow_relaxed_title_overlap and title_overlap)
        accepted = within_window and (title_ok and artist_overlap > 0 and (not target_album_key or album_overlap))
        if query_source == "spotify_track_search_isrc" and not accepted:
            accepted = within_window and (title_ok and artist_overlap > 0)

    score = 0
    if isrc_match:
        score += 500
    if title_exact:
        score += 120
    elif title_overlap and allow_relaxed_title_overlap:
        score += 70
    if artist_overlap:
        score += 50 + artist_overlap * 10
    if album_overlap:
        score += 40
    score += min(int(item.get("popularity") or 0), 100) // 5
    return accepted, score


def _spotify_match_candidates(
    items: list[dict[str, Any]],
    *,
    target: dict[str, Any],
    query_source: str,
    allow_relaxed_title_overlap: bool,
) -> list[MatchCandidate]:
    candidates: list[MatchCandidate] = []
    for item in items:
        accepted, fit_score = _track_candidate_score(
            item,
            target=target,
            query_source=query_source,
            allow_relaxed_title_overlap=allow_relaxed_title_overlap,
            release_date=None,
            discovery_months=None,
            discovery_today=None,
        )
        if not accepted:
            continue
        track_id = item.get("id")
        if not track_id:
            continue
        candidate_artists = [
            artist.get("name", "")
            for artist in item.get("artists", []) or []
            if artist.get("name")
        ]
        candidates.append(
            MatchCandidate(
                provider="spotify",
                track_id=track_id,
                album_id=safe_get(item, "album", "id"),
                title=item.get("name"),
                artists=candidate_artists,
                album_title=safe_get(item, "album", "name"),
                album_release_date=safe_get(item, "album", "release_date"),
                isrc=safe_get(item, "external_ids", "isrc"),
                fit_score=fit_score,
                raw_payload=item,
            )
        )
    return candidates


def _keys_overlap(left: str, right: str) -> bool:
    if not left or not right:
        return False
    return left == right or left in right or right in left


def _track_payload(item: dict[str, Any], *, resolution_source: str, resolution_note: str) -> dict[str, Any]:
    return {
        "id": item.get("id"),
        "uri": item.get("uri"),
        "name": item.get("name"),
        "album": {
            "id": safe_get(item, "album", "id"),
            "name": safe_get(item, "album", "name"),
            "release_date": safe_get(item, "album", "release_date"),
        },
        "artists": [{"name": artist.get("name")} for artist in item.get("artists", []) or [] if artist.get("name")],
        "external_ids": {"isrc": safe_get(item, "external_ids", "isrc")},
        "popularity": int(item.get("popularity") or 0),
        "resolution_source": resolution_source,
        "resolution_note": resolution_note,
    }


def _candidate_release_within_discovery_window(
    item: dict[str, Any],
    *,
    release_date: str | None,
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> bool:
    target_date = parse_date(release_date)
    candidate_date = parse_date(safe_get(item, "album", "release_date"))
    if candidate_date is None:
        return target_date is None and (not discovery_months or discovery_months <= 0)

    # If MusicBrainz gave us a release date, prefer an explicit date match.
    # If that fails, still allow the candidate when the Spotify album falls
    # inside the user's requested discovery window.
    if target_date is not None:
        if _release_dates_match(release_date, safe_get(item, "album", "release_date")):
            return True

    if discovery_window is None and (not discovery_months or discovery_months <= 0):
        return target_date is None
    window = resolve_effective_window(
        discovery_window=discovery_window,
        months=discovery_months,
        today=discovery_today or dt.date.today(),
    )
    return window.start_date <= candidate_date <= window.end_date


def _release_dates_match(left: str | None, right: str | None) -> bool:
    if not left or not right:
        return False
    left = left.strip()
    right = right.strip()
    left_parsed = parse_date(left)
    right_parsed = parse_date(right)
    if left_parsed is None or right_parsed is None:
        return False
    shorter = left if len(left) <= len(right) else right
    longer = right if shorter == left else left
    return longer.startswith(shorter)


def _best_track_search_album_cluster(
    items: list[dict[str, Any]],
    *,
    artist_name: str,
    album_name: str,
) -> list[dict[str, Any]]:
    clusters: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        album_id = safe_get(item, "album", "id")
        album_label = safe_get(item, "album", "name")
        cluster_key = album_id or normalize_variant_title(album_label)
        if not cluster_key:
            continue
        clusters.setdefault(cluster_key, []).append(item)
    if not clusters:
        return []
    ranked = sorted(
        clusters.values(),
        key=lambda cluster: _track_search_album_cluster_score(cluster, artist_name=artist_name, album_name=album_name),
        reverse=True,
    )
    best = ranked[0]
    best_score = _track_search_album_cluster_score(best, artist_name=artist_name, album_name=album_name)
    if best_score < 12:
        return []
    return best


def _track_search_album_cluster_score(
    cluster: list[dict[str, Any]],
    *,
    artist_name: str,
    album_name: str,
) -> int:
    if not cluster:
        return 0
    album = safe_get(cluster[0], "album", "name")
    album_score = _album_match_score({"name": album, "artists": safe_get(cluster[0], "album", "artists", default=[]) or []}, artist_name, album_name)
    track_count_bonus = min(len(cluster), 5) * 2
    popularity_bonus = max(int(item.get("popularity") or 0) for item in cluster) // 20
    return album_score + track_count_bonus + popularity_bonus
