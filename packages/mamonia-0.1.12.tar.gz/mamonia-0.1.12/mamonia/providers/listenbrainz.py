from __future__ import annotations

import time
from typing import Any

import httpx

from mamonia.config import Settings
from mamonia.providers import (
    ProviderRateLimit,
    format_network_error,
    httpx_timeout_from_settings,
    is_network_error,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import normalized_cache_key, safe_get


LISTENBRAINZ_BASE = "https://api.listenbrainz.org/1/"


class ListenBrainzProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None):
        self.settings = settings
        self.storage = storage
        self.client = httpx.Client(timeout=httpx_timeout_from_settings(settings), trust_env=False)
        self._last_request_at = 0.0
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self._my_username: str | None = None  # None = not yet fetched, "" = unavailable
        self._top_artists_cache: dict[str, int] | None = None

    @property
    def available(self) -> bool:
        return bool(self.settings.listenbrainz_user_token)

    def validate_token(self) -> dict[str, Any] | None:
        """Validate the configured token and return user info including user_name."""
        if not self.available:
            return None
        headers = {"Authorization": f"Token {self.settings.listenbrainz_user_token}"}
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{LISTENBRAINZ_BASE}validate-token", headers=headers)
            response.raise_for_status()
            return response.json()
        except Exception:
            return None

    @property
    def my_username(self) -> str | None:
        """Return the ListenBrainz username for the configured token, or None if unavailable."""
        if self._my_username is None:
            result = self.validate_token()
            self._my_username = (result.get("user_name") or "") if (result and result.get("valid")) else ""
        return self._my_username or None

    def artist_listeners(self, mbid: str, count: int | None = None) -> dict[str, Any] | None:
        """GET /stats/artist/{mbid}/listeners — returns {listeners: [...], total_listen_count: N}."""
        if not self.available or self._disabled_by_rate_limit:
            return None
        effective_count = count if count is not None else getattr(self.settings, "listenbrainz_listeners_count", 10)
        cache_key = normalized_cache_key("artist-listeners-v1", mbid=mbid, count=effective_count)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(
                f"{LISTENBRAINZ_BASE}stats/artist/{mbid}/listeners",
                params={"range": "all_time", "count": effective_count},
            )
            if response.status_code == 204:
                result: dict[str, Any] = {"listeners": [], "total_listen_count": 0}
                if self.storage:
                    self.storage.set_cache("listenbrainz", cache_key, result, self.settings.listenbrainz_cache_ttl_seconds)
                return result
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="artist listeners",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            payload = response.json().get("payload", {})
            result = {
                "listeners": payload.get("listeners", []) or [],
                "total_listen_count": payload.get("total_listen_count", 0),
            }
            if self.storage:
                self.storage.set_cache("listenbrainz", cache_key, result, self.settings.listenbrainz_cache_ttl_seconds)
            return result
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="artist listeners",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("ListenBrainz", "artist listeners"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("ListenBrainz", "artist listeners", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def community_similar_artists(self, mbid: str) -> tuple[int, list[dict[str, Any]]]:
        """
        Collaborative filtering: find top listeners of this artist, aggregate their top artists.
        Returns (total_listen_count, community_entries) where each entry is
        {"name": str, "score": int, "share": float}.
        share = fraction of the top-N listeners who played this artist.
        Uses listenbrainz_listeners_count and listenbrainz_listener_artists_count from settings.
        """
        if not self.available or self._disabled_by_rate_limit:
            return 0, []
        listeners_count = getattr(self.settings, "listenbrainz_listeners_count", 10)
        artist_count = getattr(self.settings, "listenbrainz_listener_artists_count", 50)
        cache_key = normalized_cache_key(
            "community-similar-v2", mbid=mbid,
            listeners=listeners_count, artists=artist_count,
        )
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached.get("total_listen_count", 0), list(cached.get("community", []))

        listeners_data = self.artist_listeners(mbid, count=listeners_count)
        if listeners_data is None:
            return 0, []

        total_listen_count: int = listeners_data.get("total_listen_count", 0)
        listeners: list[dict[str, Any]] = listeners_data.get("listeners", []) or []
        n_listeners = len(listeners)

        co_scores: dict[str, int] = {}
        for listener in listeners[:listeners_count]:
            username = listener.get("user_name")
            if not username:
                continue
            top = self.user_top_artists(username, count=artist_count) or {}
            for artist_name, cnt in top.items():
                co_scores[artist_name] = co_scores.get(artist_name, 0) + cnt

        community = [
            {"name": name, "score": cnt, "share": cnt / max(1, n_listeners)}
            for name, cnt in sorted(co_scores.items(), key=lambda x: x[1], reverse=True)
        ][:artist_count]

        result: dict[str, Any] = {"total_listen_count": total_listen_count, "community": community}
        if self.storage:
            self.storage.set_cache("listenbrainz", cache_key, result, self.settings.listenbrainz_cache_ttl_seconds)
        return total_listen_count, community

    def user_top_artists(self, username: str, count: int = 200) -> dict[str, int] | None:
        """Fetch user's top artists. Returns {lowercase_artist_name: listen_count}."""
        if not self.available or self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("user-top-artists-v1", user=username, count=count)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        headers = {"Authorization": f"Token {self.settings.listenbrainz_user_token}"}
        try:
            self._respect_rate_limit()
            response = self.client.get(
                f"{LISTENBRAINZ_BASE}stats/user/{username}/artists",
                params={"range": "all_time", "count": count},
                headers=headers,
            )
            if response.status_code == 204:
                result_d: dict[str, int] = {}
                if self.storage:
                    self.storage.set_cache("listenbrainz", cache_key, result_d, self.settings.listenbrainz_cache_ttl_seconds)
                return result_d
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="user top artists",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            payload = response.json().get("payload", {})
            artists = payload.get("artists", []) or []
            result_d = {
                a["artist_name"].lower(): a.get("listen_count", 0)
                for a in artists
                if a.get("artist_name")
            }
            if self.storage:
                self.storage.set_cache("listenbrainz", cache_key, result_d, self.settings.listenbrainz_cache_ttl_seconds)
            return result_d
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="user top artists",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("ListenBrainz", "user top artists"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("ListenBrainz", "user top artists", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def artist_listen_count_for_user(self, artist_name: str) -> int | None:
        """Return how many times the authenticated user has listened to this artist."""
        username = self.my_username
        if not username:
            return None
        if self._top_artists_cache is None:
            self._top_artists_cache = self.user_top_artists(username) or {}
        return self._top_artists_cache.get(artist_name.lower())

    def user_listen_history(self, user_name: str, count: int = 100) -> dict[str, Any] | None:
        if not self.available or self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("user-listens-v1", user=user_name, count=count)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        headers = {"Authorization": f"Token {self.settings.listenbrainz_user_token}"}
        try:
            self._respect_rate_limit()
            response = self.client.get(
                f"{LISTENBRAINZ_BASE}user/{user_name}/listens",
                params={"count": count},
                headers=headers,
            )
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="user listen history",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            if self.storage:
                self.storage.set_cache("listenbrainz", cache_key, data, self.settings.listenbrainz_cache_ttl_seconds)
            return data
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="user listen history",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("ListenBrainz", "user listen history"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("ListenBrainz", "user listen history", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def artist_lookup(self, mbid: str) -> dict[str, Any] | None:
        if not self.available or self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key("artist-lookup-v1", mbid=mbid)
        cached = self._cache_get(cache_key)
        if cached is not None:
            return cached
        try:
            self._respect_rate_limit()
            response = self.client.get(f"{LISTENBRAINZ_BASE}metadata/artist/{mbid}")
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="artist lookup",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            if self.storage:
                self.storage.set_cache("listenbrainz", cache_key, data, self.settings.listenbrainz_cache_ttl_seconds)
            return data
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="artist lookup",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("ListenBrainz", "artist lookup"),
                        error_kind="network_error",
                    )
                )
                return None
            rate_limit = rate_limit_from_exception("ListenBrainz", "artist lookup", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None

    def get_similar_artists(self, mbid: str) -> list[dict[str, Any]]:
        """Fetch similar artists from ListenBrainz community data.

        Returns a list of dicts with keys: artist_name, artist_mbid, score, share.
        Compatible with the graph_expansion._fetch_lb_similar helper.
        """
        total_listen_count, community = self.community_similar_artists(mbid)
        results: list[dict[str, Any]] = []
        for entry in community:
            name = entry.get("name", "")
            if not name:
                continue
            results.append({
                "artist_name": name,
                "artist_mbid": None,  # ListenBrainz community data doesn't provide MBIDs
                "score": entry.get("score", 0),
                "share": entry.get("share", 0.0),
            })
        return results

    def recording_popularity(self, recording_mbids: list[str]) -> dict[str, dict[str, int | None]]:
        """POST /popularity/recording — returns listen/user counts keyed by recording MBID."""
        if not self.available or self._disabled_by_rate_limit or not recording_mbids:
            return {}
        unique_mbids = [mbid for mbid in dict.fromkeys(recording_mbids) if mbid]
        if not unique_mbids:
            return {}
        cache_key = normalized_cache_key("recording-popularity-v1", mbids="|".join(sorted(unique_mbids)))
        cached = self._cache_get(cache_key)
        if isinstance(cached, dict):
            return cached
        headers = {"Authorization": f"Token {self.settings.listenbrainz_user_token}"}
        try:
            self._respect_rate_limit()
            response = self.client.post(
                f"{LISTENBRAINZ_BASE}popularity/recording",
                headers=headers,
                json={"recording_mbids": unique_mbids},
            )
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="recording popularity",
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return {}
            response.raise_for_status()
            payload = response.json()
            result: dict[str, dict[str, int | None]] = {}
            if isinstance(payload, list):
                for row in payload:
                    if not isinstance(row, dict):
                        continue
                    mbid = row.get("recording_mbid")
                    if not mbid:
                        continue
                    result[str(mbid)] = {
                        "total_listen_count": row.get("total_listen_count"),
                        "total_user_count": row.get("total_user_count"),
                    }
            if self.storage:
                self.storage.set_cache("listenbrainz", cache_key, result, self.settings.listenbrainz_cache_ttl_seconds)
            return result
        except Exception as exc:
            if is_network_error(exc):
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="ListenBrainz",
                        operation="recording popularity",
                        retry_after_seconds=None,
                        recoverable=False,
                        error_message=format_network_error("ListenBrainz", "recording popularity"),
                        error_kind="network_error",
                    )
                )
                return {}
            rate_limit = rate_limit_from_exception("ListenBrainz", "recording popularity", exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return {}

    def _respect_rate_limit(self) -> None:
        elapsed = time.monotonic() - self._last_request_at
        if elapsed < 0.5:
            time.sleep(0.5 - elapsed)
        self._last_request_at = time.monotonic()

    def _cache_get(self, cache_key: str) -> Any | None:
        if not self.storage:
            return None
        if getattr(self.settings, "force_refresh", False):
            return None
        return self.storage.get_cache("listenbrainz", cache_key)

    def _record_rate_limit(self, rate_limit: ProviderRateLimit) -> None:
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True


def _retry_after(response: httpx.Response) -> int | None:
    value = response.headers.get("Retry-After")
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None
