from __future__ import annotations

import time
from typing import Any

import httpx

from mamonia.config import Settings
from mamonia.providers import (
    ProviderRateLimit,
    format_network_error,
    httpx_timeout_from_settings,
    is_network_error,
    is_timeout_error,
    rate_limit_from_exception,
)
from mamonia.storage import Storage
from mamonia.utils import normalized_cache_key, safe_get


LASTFM_BASE = "https://ws.audioscrobbler.com/2.0/"
class LastFMProvider:
    def __init__(self, settings: Settings, storage: Storage | None = None):
        self.settings = settings
        self.storage = storage
        self.client = httpx.Client(timeout=httpx_timeout_from_settings(settings), trust_env=False)
        self._last_request_at = 0.0
        self._disabled_by_rate_limit = False
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self.api_calls = 0
        self.request_time_seconds = 0.0
        self.timeout_events = 0

    @property
    def available(self) -> bool:
        return bool(self.settings.lastfm_api_key)

    def top_tags(self, artist_name: str, limit: int = 8) -> list[str]:
        data = self._call("artist.getTopTags", artist=artist_name, autocorrect=1)
        tags = safe_get(data, "toptags", "tag", default=[]) or []
        if isinstance(tags, dict):
            tags = [tags]
        return [tag["name"] for tag in tags[:limit] if tag.get("name")]

    def similar_artists(self, artist_name: str, limit: int = 10) -> list[str]:
        data = self._call("artist.getSimilar", artist=artist_name, autocorrect=1, limit=limit)
        artists = safe_get(data, "similarartists", "artist", default=[]) or []
        if isinstance(artists, dict):
            artists = [artists]
        return [artist["name"] for artist in artists[:limit] if artist.get("name")]

    def get_similar_artists(self, artist_name: str, limit: int = 10) -> list[dict[str, Any]]:
        """Fetch similar artists from Last.fm.

        Returns a list of dicts with keys: artist_name, artist_mbid, match.
        Compatible with the graph_expansion._fetch_lastfm_similar helper.
        """
        data = self._call("artist.getSimilar", artist=artist_name, autocorrect=1, limit=limit)
        if not data:
            return []
        artists = safe_get(data, "similarartists", "artist", default=[]) or []
        if isinstance(artists, dict):
            artists = [artists]
        results: list[dict[str, Any]] = []
        for artist in artists[:limit]:
            name = artist.get("name", "")
            if not name:
                continue
            results.append({
                "artist_name": name,
                "artist_mbid": artist.get("mbid"),
                "match": artist.get("match", "0"),
            })
        return results

    def track_popularity(self, artist_name: str, track_title: str) -> dict[str, int] | None:
        """Return Last.fm popularity counters for a track."""
        data = self._call("track.getInfo", artist=artist_name, track=track_title, autocorrect=1)
        if not data:
            return None
        track = data.get("track") or {}
        try:
            listeners = int(track.get("listeners") or 0)
        except (TypeError, ValueError):
            listeners = 0
        try:
            playcount = int(track.get("playcount") or 0)
        except (TypeError, ValueError):
            playcount = 0
        if listeners <= 0 and playcount <= 0:
            return None
        return {"listeners": listeners, "playcount": playcount}

    def _call(self, method: str, **params: Any) -> dict[str, Any] | None:
        if not self.available or self._disabled_by_rate_limit:
            return None
        cache_key = normalized_cache_key(f"lastfm-v2:{method}", **params)
        cached = None
        if self.storage and not getattr(self.settings, "force_refresh", False):
            cached = self.storage.get_cache("lastfm", cache_key)
        if cached is not None:
            return cached
        query = {"method": method, "api_key": self.settings.lastfm_api_key, "format": "json", **params}
        try:
            self._respect_rate_limit()
            started = time.monotonic()
            self.api_calls = getattr(self, "api_calls", 0) + 1
            response = self.client.get(LASTFM_BASE, params=query)
            self.request_time_seconds = float(getattr(self, "request_time_seconds", 0.0) or 0.0) + (time.monotonic() - started)
            if response.status_code == 429:
                self._record_rate_limit(
                    ProviderRateLimit(
                        provider="Last.fm",
                        operation=method,
                        retry_after_seconds=_retry_after(response),
                    )
                )
                return None
            response.raise_for_status()
            data = response.json()
            if "error" in data:
                if _lastfm_error_code(data) == 29 or "rate limit" in str(data.get("message", "")).lower():
                    self._record_rate_limit(ProviderRateLimit(provider="Last.fm", operation=method))
                return None
        except Exception as exc:
            if is_timeout_error(exc):
                self.timeout_events = int(getattr(self, "timeout_events", 0) or 0) + 1
            if is_network_error(exc):
                self._disabled_by_rate_limit = True
                issue = ProviderRateLimit(
                    provider="Last.fm",
                    operation=method,
                    retry_after_seconds=None,
                    recoverable=False,
                    error_message=format_network_error("Last.fm", method),
                    error_kind="network_error",
                )
                self.rate_limit_warnings.append(issue)
                return None
            rate_limit = rate_limit_from_exception("Last.fm", method, exc)
            if rate_limit:
                self._record_rate_limit(rate_limit)
            return None
        if self.storage:
            self.storage.set_cache("lastfm", cache_key, data, self.settings.lastfm_cache_ttl_seconds)
        return data

    def _respect_rate_limit(self) -> None:
        min_interval = float(getattr(self.settings, "lastfm_min_interval_seconds", 0.25) or 0.25)
        if min_interval < 0:
            min_interval = 0.0
        elapsed = time.monotonic() - self._last_request_at
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        self._last_request_at = time.monotonic()

    def _record_rate_limit(self, rate_limit: ProviderRateLimit) -> None:
        self.rate_limit_warnings.append(rate_limit)
        if not rate_limit.should_auto_wait:
            self._disabled_by_rate_limit = True


def _retry_after(response: httpx.Response) -> int | None:
    value = response.headers.get("Retry-After")
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None


def _lastfm_error_code(data: dict[str, Any]) -> int:
    try:
        return int(data.get("error") or 0)
    except (TypeError, ValueError):
        return 0
