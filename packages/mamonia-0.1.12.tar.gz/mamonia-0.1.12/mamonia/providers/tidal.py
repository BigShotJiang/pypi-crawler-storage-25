from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
import re
import time
from urllib.parse import quote
from typing import Any

from mamonia.config import Settings, harden_secret_file_permissions
from mamonia.discovery_window import DiscoveryWindow, resolve_effective_window
from mamonia.i18n import DEFAULT_LANGUAGE, get_guided_language, get_translator
from mamonia.input import extract_tidal_playlist_id
from mamonia.matching import MatchCandidate, select_staged_candidate
from mamonia.models import InputTrack
from mamonia.providers import (
    ProviderRateLimit,
    ProviderUnavailable,
    format_network_error,
    is_network_error,
)
from mamonia.utils import normalize_key, normalized_artist_credit, normalize_variant_title, normalized_token_set, parse_date

TIDAL_PLAYLIST_PAGE_SIZE = 100
TIDAL_PLAYLIST_PAGE_RETRIES = 2
TIDAL_PLAYLIST_RETRY_BACKOFF_SECONDS = 0.35
TIDAL_PLAYLIST_MAX_PAGES = 500


@dataclass(frozen=True)
class TidalUserPlaylist:
    id: str
    name: str
    tracks: int | None = None


@dataclass(frozen=True)
class TidalPlaylistCreationResult:
    created: bool
    url: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class TidalTrackMatch:
    track_id: str
    album_id: str | None = None
    isrc: str | None = None
    title: str | None = None
    artists: list[str] | None = None
    stage: str | None = None


class TidalProvider:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._session: Any | None = None
        self.rate_limit_warnings: list[ProviderRateLimit] = []
        self._disabled_by_rate_limit = False
        self.last_lookup_error: str | None = None

    @property
    def available(self) -> bool:
        try:
            import tidalapi
        except Exception:
            return False
        return True

    def diagnostic_summary(self) -> dict[str, str]:
        if not self.settings.tidal_configured:
            provider_status = "not configured; importer-friendly export fallback only"
        elif not self.available:
            provider_status = "credentials present but tidalapi is not installed; importer-friendly export fallback only"
        else:
            provider_status = "ready for playlist analysis and native playlist creation (experimental)"
        return {
            "provider_status": provider_status,
            "auth_flow": _describe_auth_flow(_detect_auth_flow(_session_type())),
            "native_playlist_creation": "experimental; verify with `mamonia tidal-smoke` before relying on it",
        }

    def ensure_session(self) -> bool:
        """Attempt to establish a Tidal session early, returning success status.

        This lets the workflow surface authentication problems up-front instead
        of in the middle of ISRC resolution where the user cannot interact.

        Note: The session() method now creates an unauthenticated session if authentication fails,
        so this will return True even if user authentication didn't succeed. Authenticated operations
        like ISRC lookup will still fail, but public API operations like artist search will work.
        """
        if self._session is not None:
            return True
        if not self.available:
            return False
        try:
            self.session()
            return True
        except ProviderUnavailable:
            return False

    def session(self) -> Any:
        if self._session is not None:
            return self._session
        if not self.available:
            raise ProviderUnavailable(
                "tidalapi is not installed. Install with: pip install -e '.[tidal]'."
            )
        try:
            import tidalapi
        except Exception as exc:
            raise ProviderUnavailable("tidalapi is not installed. Run: pip install -e '.[tidal]'") from exc

        try:
            session = tidalapi.Session()
            _configure_client(session, self.settings)
        except Exception as exc:
            # Session creation or client config failed — this is a fatal error
            self.last_lookup_error = str(exc)
            raise ProviderUnavailable(f"Tidal session creation failed: {exc}") from exc

        # Try to authenticate, but don't fail if it doesn't work.
        # Public API operations (artist search, discography browse) can work without authentication.
        try:
            language = get_guided_language(self.settings.data_dir, from_cli=False)
            _authenticate_session(session, self.settings.data_dir / "tidal_session.json", language)
        except Exception as exc:
            # Authentication failed, but log it and continue with unauthenticated session
            self.last_lookup_error = f"Tidal authentication failed: {exc}"

        self._session = session
        return self._session

    def fetch_playlist_tracks(self, playlist_url_or_id: str) -> list[InputTrack]:
        session = self.session()
        playlist_id = extract_tidal_playlist_id(playlist_url_or_id) or playlist_url_or_id
        tracks: list[InputTrack] = []
        seen_track_ids: set[str] = set()

        try:
            playlist = session.playlist(playlist_id)
        except Exception as exc:
            raise ProviderUnavailable(f"Failed to fetch Tidal playlist: {exc}") from exc

        for item in _iter_playlist_items_paginated(session, playlist, playlist_id):
            track = _playlist_item_track(item)
            if not track:
                continue
            artists = _field(track, "artists") or []
            if not artists:
                continue
            artist_names = [str(name) for artist in artists if (name := _field(artist, "name"))]
            if not artist_names:
                continue
            album = _field(track, "album")
            track_id = _string_or_none(_field(track, "id"))
            if track_id:
                if track_id in seen_track_ids:
                    continue
                seen_track_ids.add(track_id)

            tracks.append(
                InputTrack(
                    artist=artist_names[0],
                    artists=artist_names,
                    track=str(_field(track, "name") or ""),
                    album=_string_or_none(_field(album, "name")),
                    tidal_track_id=track_id,
                    tidal_artist_ids=[str(artist_id) for artist in artists if (artist_id := _field(artist, "id"))],
                    tidal_album_id=_string_or_none(_field(album, "id")),
                    isrc=_string_or_none(_field(track, "isrc")),
                )
            )

        return tracks

    def fetch_playlist_name(self, playlist_url_or_id: str) -> str | None:
        playlist_id = extract_tidal_playlist_id(playlist_url_or_id) or playlist_url_or_id
        try:
            session = self.session()
            playlist_obj = session.playlist(playlist_id)
            return _string_or_none(_field(playlist_obj, "name"))
        except Exception:
            return None

    def fetch_user_playlists(self) -> list[TidalUserPlaylist]:
        session = self.session()
        user = _field(session, "user")
        candidates: Any = None
        if user is not None:
            playlists_attr = _field(user, "playlists")
            candidates = playlists_attr() if callable(playlists_attr) else playlists_attr
        if candidates is None:
            method = getattr(session, "user_playlists", None)
            candidates = method() if callable(method) else None
        if candidates is None:
            raise ProviderUnavailable("Installed tidalapi version does not expose user playlist listing.")

        out: list[TidalUserPlaylist] = []
        for playlist in candidates or []:
            playlist_id = _string_or_none(_field(playlist, "id") or _field(playlist, "uuid"))
            if not playlist_id:
                continue
            out.append(
                TidalUserPlaylist(
                    id=playlist_id,
                    name=_string_or_none(_field(playlist, "name") or _field(playlist, "title")) or playlist_id,
                    tracks=_int_or_none(
                        _field(playlist, "num_tracks")
                        or _field(playlist, "number_of_tracks")
                        or _field(playlist, "tracks_count")
                    ),
                )
            )
        return out

    def create_playlist(
        self,
        name: str,
        description: str,
        track_ids: list[str],
    ) -> TidalPlaylistCreationResult:
        clean_ids = list(dict.fromkeys(
            normalized for track_id in track_ids if (normalized := _normalize_tidal_track_id(track_id))
        ))
        if not clean_ids:
            return TidalPlaylistCreationResult(created=False, reason="no_ids")
        try:
            session = self.session()
            playlist = _create_tidal_playlist(session, name=name, description=description)
            _add_tidal_playlist_items(playlist, clean_ids)
            playlist_id = _string_or_none(_field(playlist, "id") or _field(playlist, "uuid"))
            return TidalPlaylistCreationResult(
                created=True,
                url=f"https://tidal.com/browse/playlist/{playlist_id}" if playlist_id else None,
            )
        except ProviderUnavailable as exc:
            return TidalPlaylistCreationResult(created=False, reason=str(exc))
        except Exception as exc:
            return TidalPlaylistCreationResult(created=False, reason=str(exc))

    def check_playlist_access(self, playlist_url_or_id: str) -> int | None:
        try:
            tracks = self.fetch_playlist_tracks(playlist_url_or_id)
            return len(tracks)
        except Exception:
            return None

    def fetch_album(self, album_url_or_id: str) -> Any | None:
        album_id = _normalize_tidal_album_id(album_url_or_id)
        if not album_id:
            return None
        try:
            session = self.session()
            return session.album(album_id)
        except Exception:
            return None

    def lookup_isrc(self, artist: str, title: str) -> str | None:
        self.last_lookup_error = None
        try:
            session = self.session()
        except ProviderUnavailable:
            return None
        try:
            tracks = _search_tracks_current_or_legacy(session, f"{artist} {title}", limit=5)
            for track in (tracks or []):
                track_title = (_field(track, "name") or "").lower()
                track_artist = (_field(_field(track, "artist"), "name") or "").lower()
                title_l = title.lower()
                artist_l = artist.lower()
                if (title_l in track_title or track_title in title_l) and \
                   (artist_l in track_artist or track_artist in artist_l):
                    isrc = _field(track, "isrc")
                    if isrc:
                        return str(isrc)
            return None
        except Exception as exc:
            if is_network_error(exc):
                self.last_lookup_error = format_network_error("Tidal", "ISRC lookup")
            else:
                self.last_lookup_error = str(exc)
            return None

    def lookup_track_by_isrc(self, isrc: str) -> TidalTrackMatch | None:
        self.last_lookup_error = None
        if not isrc:
            return None
        try:
            session = self.session()
        except ProviderUnavailable:
            return None
        try:
            track = None
            openapi_error: Exception | None = None
            try:
                track = _openapi_first_track_by_isrc(session, isrc)
            except Exception as exc:
                openapi_error = exc
                track = None
            if not track:
                track = _search_first_track(session, f"isrc:{isrc}", limit=5)
            if not track and openapi_error is not None:
                raise openapi_error
            if not track:
                return None
            track_isrc = _string_or_none(_field(track, "isrc"))
            if track_isrc and track_isrc.upper() != isrc.upper():
                return None
            return _track_match(track)
        except Exception as exc:
            if is_network_error(exc):
                self.last_lookup_error = format_network_error("Tidal", "track lookup")
            else:
                self.last_lookup_error = str(exc)
            return None

    def search_tracks(self, query: str, limit: int = 25) -> list[Any]:
        if self._disabled_by_rate_limit:
            return []
        if not query:
            return []
        try:
            session = self.session()
        except ProviderUnavailable:
            return []
        try:
            return _search_tracks_current_or_legacy(session, query, limit=limit)
        except Exception as exc:
            if is_network_error(exc):
                self.last_lookup_error = format_network_error("Tidal", "track search")
            else:
                self.last_lookup_error = str(exc)
            return []

    def search_artist_albums(self, artist_name: str, limit: int = 50) -> list[dict[str, Any]]:
        """Return a discography (albums + EP/singles) for the best name match on Tidal.

        Uses the documented tidalapi signature
        ``session.search(query, models=[Artist], limit=N)`` and the
        ``Artist.get_albums`` / ``Artist.get_ep_singles`` methods to assemble a
        full discography. Falls back to track-search album extraction only if
        the discography path produces no usable result.
        """
        if self._disabled_by_rate_limit:
            return []
        if not artist_name:
            return []
        try:
            session = self.session()
        except ProviderUnavailable:
            return []

        try:
            import tidalapi
        except Exception:
            tidalapi = None  # type: ignore[assignment]

        # Primary path: search artists, pick best name match, then assemble
        # discography from the artist's own album/EP-single endpoints.
        try:
            artist_models = [tidalapi.Artist] if tidalapi is not None else None
            search_results = session.search(artist_name, models=artist_models, limit=10)
            artists_list = (
                search_results.get("artists")
                if isinstance(search_results, dict)
                else getattr(search_results, "artists", None)
            ) or []
            best_artist = _pick_best_artist_match(artists_list, artist_name)
            if best_artist is not None and getattr(best_artist, "id", None):
                bound_artist = session.artist(best_artist.id)
                albums = _collect_artist_discography(bound_artist, limit=limit)
                if albums:
                    return albums
        except Exception as exc:
            if is_network_error(exc):
                self.last_lookup_error = format_network_error("Tidal", "artist search")
            else:
                self.last_lookup_error = str(exc)

        # Fallback: derive albums from a track search on the artist name.
        try:
            tracks = self.search_tracks(artist_name, limit=limit)
            albums: dict[str, dict[str, Any]] = {}
            for track in tracks:
                album = _field(track, "album")
                if album is None:
                    continue
                album_id = _string_or_none(_field(album, "id"))
                if not album_id:
                    continue
                title = _string_or_none(_field(album, "title")) or _string_or_none(_field(album, "name"))
                release_date = _string_or_none(_field(album, "release_date")) or _string_or_none(_field(album, "releaseDate"))
                if not title or not release_date:
                    continue
                if album_id not in albums:
                    albums[album_id] = {
                        "id": album_id,
                        "title": title,
                        "release_date": release_date,
                        "type": "album",
                    }
            return list(albums.values())
        except Exception as exc:
            if is_network_error(exc):
                self.last_lookup_error = format_network_error("Tidal", "discography lookup")
            else:
                self.last_lookup_error = str(exc)
            return []

    def lookup_track(self, artist: str, title: str, album: str | None = None, isrc: str | None = None) -> TidalTrackMatch | None:
        self.last_lookup_error = None
        if isrc:
            match = self.lookup_track_by_isrc(isrc)
            if match:
                return match
            if self.last_lookup_error:
                return None
        try:
            session = self.session()
        except ProviderUnavailable:
            return None
        query = " ".join(part for part in (artist, title, album) if part)
        try:
            strict_candidates: list[tuple[int, Any]] = []
            relaxed_candidates: list[tuple[int, Any]] = []
            tracks = _search_tracks_resilient(session, artist=artist, title=title, album=album, limit=10)
            for track in tracks:
                if _track_matches_lookup_target(
                    track,
                    target_artist=artist,
                    target_title=title,
                    target_album=album,
                    allow_relaxed_title_overlap=False,
                ):
                    strict_candidates.append((_track_match_score(track, target_title=title), track))
                    continue
                if _track_matches_lookup_target(
                    track,
                    target_artist=artist,
                    target_title=title,
                    target_album=album,
                    allow_relaxed_title_overlap=True,
                ):
                    relaxed_candidates.append((_track_match_score(track, target_title=title), track))
            candidates = strict_candidates or relaxed_candidates
            if not candidates:
                return None
            candidates.sort(key=lambda item: item[0], reverse=True)
            return _track_match(candidates[0][1])
        except Exception as exc:
            self.last_lookup_error = str(exc)
            return None

    def lookup_track_with_window(
        self,
        artist: str,
        title: str,
        album: str | None = None,
        isrc: str | None = None,
        *,
        release_date: str | None = None,
        discovery_months: int | None = None,
        discovery_window: DiscoveryWindow | None = None,
        discovery_today: dt.date | None = None,
    ) -> TidalTrackMatch | None:
        """Unified staged lookup with ISRC + MB date + discovery-window ranking."""
        self.last_lookup_error = None
        try:
            session = self.session()
        except ProviderUnavailable:
            return None
        query = " ".join(part for part in (artist, title, album) if part)
        try:
            tracks = _search_tracks_resilient(session, artist=artist, title=title, album=album, limit=10)
            if isrc:
                tracks = _extend_with_isrc_candidates(session, tracks, isrc)
            candidates: list[MatchCandidate] = []
            for track in tracks:
                strict_ok = _track_matches_lookup_target(
                    track,
                    target_artist=artist,
                    target_title=title,
                    target_album=album,
                    allow_relaxed_title_overlap=False,
                )
                relaxed_ok = strict_ok or _track_matches_lookup_target(
                    track,
                    target_artist=artist,
                    target_title=title,
                    target_album=album,
                    allow_relaxed_title_overlap=True,
                )
                if not relaxed_ok:
                    continue
                fit_score = _track_match_score(track, target_title=title)
                if strict_ok:
                    fit_score += 100
                if _album_matches_target(track, album):
                    fit_score += 25
                if _artists_overlap(track, artist):
                    fit_score += 20
                candidate_artists_raw = _field(track, "artists") or []
                candidate_artists = [str(value) for artist_obj in candidate_artists_raw if (value := _field(artist_obj, "name"))]
                candidates.append(
                    MatchCandidate(
                        provider="tidal",
                        track_id=_string_or_none(_field(track, "id")) or "",
                        album_id=_string_or_none(_field(_field(track, "album"), "id")),
                        title=_string_or_none(_field(track, "name")),
                        artists=candidate_artists,
                        album_title=_string_or_none(_field(_field(track, "album"), "name")),
                        album_release_date=_string_or_none(_field(_field(track, "album"), "release_date")),
                        isrc=_string_or_none(_field(track, "isrc")),
                        fit_score=fit_score,
                        raw_payload=track,
                    )
                )
            selection = select_staged_candidate(
                candidates,
                target_isrc=isrc,
                mb_release_date=release_date,
                discovery_months=discovery_months,
                discovery_window=discovery_window,
                discovery_today=discovery_today,
            )
            if selection is None:
                return None
            match = _track_match(selection.candidate.raw_payload)
            if match:
                return TidalTrackMatch(
                    track_id=match.track_id,
                    album_id=match.album_id,
                    isrc=match.isrc,
                    title=match.title,
                    artists=match.artists,
                    stage=selection.stage,
                )
            return None
        except Exception as exc:
            self.last_lookup_error = str(exc)
            return None


def _search_tracks_resilient(
    session: Any,
    *,
    artist: str,
    title: str,
    album: str | None,
    limit: int,
) -> list[Any]:
    """Search using progressively broader query variants and merge results."""
    seen: set[str] = set()
    merged: list[Any] = []
    last_error: Exception | None = None
    for query in _candidate_search_queries(artist=artist, title=title, album=album):
        if not query:
            continue
        try:
            tracks = _search_tracks_current_or_legacy(session, query, limit=limit)
        except Exception as exc:
            last_error = exc
            continue
        for track in tracks:
            track_id = _string_or_none(_field(track, "id"))
            if track_id and track_id in seen:
                continue
            if track_id:
                seen.add(track_id)
            merged.append(track)
    if merged:
        return merged
    if last_error is not None:
        raise last_error
    return []


def _candidate_search_queries(*, artist: str, title: str, album: str | None) -> list[str]:
    primary_artist = _primary_artist_name(artist)
    normalized_title = normalize_variant_title(title)
    normalized_album = normalize_variant_title(album) if album else ""
    artist_with_title = " ".join(part for part in (artist, title) if part).strip()
    primary_with_title = " ".join(part for part in (primary_artist, title) if part).strip()
    full = " ".join(part for part in (artist, title, album) if part).strip()
    primary_full = " ".join(part for part in (primary_artist, title, album) if part).strip()
    title_album = " ".join(part for part in (title, album) if part).strip()
    normalized_title_album = " ".join(part for part in (normalized_title, normalized_album) if part).strip()
    normalized_primary = " ".join(part for part in (primary_artist, normalized_title, normalized_album) if part).strip()
    variants = [
        full,
        primary_full,
        artist_with_title,
        primary_with_title,
        title_album,
        title.strip(),
        normalized_primary,
        normalized_title_album,
        normalized_title,
    ]
    out: list[str] = []
    for variant in variants:
        if variant and variant not in out:
            out.append(variant)
    return out


def _primary_artist_name(value: str) -> str:
    if not value:
        return ""
    # Prefer the first credited artist before common separators.
    parts = re.split(r",|&| feat\\.? | featuring | and ", value, maxsplit=1, flags=re.IGNORECASE)
    return (parts[0] if parts else value).strip()


def _extend_with_isrc_candidates(session: Any, tracks: list[Any], isrc: str) -> list[Any]:
    out = list(tracks or [])
    seen = {_string_or_none(_field(track, "id")) for track in out if _string_or_none(_field(track, "id"))}
    for candidate in _openapi_tracks_by_isrc(session, isrc):
        track_id = _string_or_none(_field(candidate, "id"))
        if track_id and track_id not in seen:
            out.append(candidate)
            seen.add(track_id)
    for candidate in _search_tracks(session, f"isrc:{isrc}", limit=10):
        track_id = _string_or_none(_field(candidate, "id"))
        if track_id and track_id not in seen:
            out.append(candidate)
            seen.add(track_id)
    return out


def _openapi_tracks_by_isrc(session: Any, isrc: str) -> list[Any]:
    return _openapi_get_tracks(
        session,
        {
            "filter[isrc]": isrc,
            "include": "artists,albums",
        },
    )


def _artists_overlap(track: Any, target_artist: str) -> bool:
    target_set = set(normalized_artist_credit(target_artist))
    if not target_set:
        return False
    track_artists = _field(track, "artists") or []
    candidate_artists = [str(name) for artist in track_artists if (name := _field(artist, "name"))]
    if not candidate_artists:
        primary_artist = _field(_field(track, "artist"), "name")
        if primary_artist:
            candidate_artists = [str(primary_artist)]
    return bool(set(normalized_artist_credit(candidate_artists)) & target_set)


def _configure_client(session: Any, settings: Settings) -> None:
    config = getattr(session, "config", None)
    if config is None:
        return
    if settings.tidal_client_id:
        config.client_id = settings.tidal_client_id
    if settings.tidal_client_secret:
        config.client_secret = settings.tidal_client_secret


def _authenticate_session(session: Any, session_file: Any, language: str = DEFAULT_LANGUAGE) -> None:
    printer = _make_tidal_auth_printer(language)
    if hasattr(session, "login_session_file"):
        ok = session.login_session_file(session_file, do_pkce=True, fn_print=printer)
        if not ok:
            raise ProviderUnavailable("Tidal PKCE login did not complete.")
        harden_secret_file_permissions(session_file)
        return
    if hasattr(session, "login"):
        t = get_translator(language)
        print(f"\n{t('tidal.auth_preamble')}\n")
        session.login()
        return
    raise ProviderUnavailable("Installed tidalapi version does not expose a supported login method.")


def _session_type() -> Any | None:
    try:
        import tidalapi
    except Exception:
        return None
    return getattr(tidalapi, "Session", None)


def _detect_auth_flow(session_type: Any | None) -> str:
    if session_type is None:
        return "unavailable"
    if hasattr(session_type, "login_session_file"):
        return "pkce-session-file"
    if hasattr(session_type, "login"):
        return "legacy-login"
    return "unsupported"


def _describe_auth_flow(auth_flow: str) -> str:
    if auth_flow == "pkce-session-file":
        return "PKCE session-file login"
    if auth_flow == "legacy-login":
        return "legacy interactive login"
    if auth_flow == "unsupported":
        return "unsupported by installed tidalapi"
    return "unavailable (tidalapi not installed)"


def _make_tidal_auth_printer(language: str = DEFAULT_LANGUAGE) -> callable:
    """Return a stateful callback for tidalapi's fn_print hook.

    The first time tidalapi calls the returned function, the locale-dependent
    preamble is printed before the message. All subsequent calls format the
    message normally.
    """
    t = get_translator(language)
    printed_preamble = False

    def _print(message: str) -> None:
        nonlocal printed_preamble
        if not printed_preamble:
            print(f"\n{t('tidal.auth_preamble')}\n")
            printed_preamble = True
        clean_message = message.replace("\n", " ").replace("\r", "")
        print(f"Tidal authentication: {clean_message}")

    return _print


def _create_tidal_playlist(session: Any, *, name: str, description: str) -> Any:
    user = _field(session, "user")
    for owner in (user, session):
        if owner is None:
            continue
        method = getattr(owner, "create_playlist", None)
        if callable(method):
            try:
                return method(name, description)
            except TypeError:
                return method(name=name, description=description)
    raise ProviderUnavailable("Installed tidalapi version does not expose playlist creation.")


def _add_tidal_playlist_items(playlist: Any, track_ids: list[str]) -> None:
    for method_name in ("add", "add_tracks", "add_track_ids"):
        method = getattr(playlist, method_name, None)
        if callable(method):
            method(track_ids)
            return
    raise ProviderUnavailable("Installed tidalapi version does not expose playlist item insertion.")


def _pick_best_artist_match(artists: list[Any], target_name: str) -> Any | None:
    """Choose the artist result whose normalized name matches the query best.

    Tidal's search ranks by popularity, not exact name match, so picking
    ``artists[0]`` blindly can land on a same-named-but-different act. We
    prefer exact normalized matches first, then a partial-token overlap.
    """
    if not artists:
        return None
    target = normalize_key(target_name)
    if not target:
        return artists[0]
    target_tokens = set(target.split())

    def score(candidate: Any) -> tuple[int, int]:
        candidate_name = _string_or_none(getattr(candidate, "name", None)) or ""
        normalized = normalize_key(candidate_name)
        if not normalized:
            return (0, 0)
        if normalized == target:
            return (3, 0)
        candidate_tokens = set(normalized.split())
        if target_tokens and target_tokens.issubset(candidate_tokens):
            return (2, -len(candidate_tokens))
        overlap = len(target_tokens & candidate_tokens)
        return (1, overlap) if overlap else (0, 0)

    ranked = sorted(artists, key=score, reverse=True)
    best = ranked[0]
    return best if score(best)[0] > 0 else artists[0]


def _collect_artist_discography(bound_artist: Any, *, limit: int) -> list[dict[str, Any]]:
    """Fetch albums + EP/singles for a Tidal Artist and dedupe by id.

    Uses the documented ``Artist.get_albums`` and ``Artist.get_ep_singles``
    methods (the latter replaces the deprecated ``get_albums_ep_singles``).
    Falls back to the older ``albums()`` accessor for tidalapi versions that
    have not adopted the renamed methods yet.
    """
    per_call_limit = max(1, min(limit, 300))  # Tidal caps page size at 300
    sources: list[Any] = []
    for method_name in ("get_albums", "get_ep_singles", "get_albums_ep_singles", "albums"):
        method = getattr(bound_artist, method_name, None)
        if not callable(method):
            continue
        try:
            result = method(limit=per_call_limit)
        except TypeError:
            try:
                result = method()
            except Exception:
                continue
        except Exception:
            continue
        if result:
            sources.append(result)
        # `albums()` is the legacy alias for `get_albums()`; if both exist we
        # only need one of them, so stop after the modern names succeed.
        if method_name in {"get_ep_singles", "get_albums_ep_singles"}:
            # Only one of the EP/single accessors is needed.
            break

    albums: dict[str, dict[str, Any]] = {}
    for result in sources:
        for album in result or []:
            album_id = _string_or_none(getattr(album, "id", None))
            if not album_id or album_id in albums:
                continue
            title = (
                _string_or_none(getattr(album, "title", None))
                or _string_or_none(getattr(album, "name", None))
            )
            release_date = (
                _string_or_none(getattr(album, "release_date", None))
                or _string_or_none(getattr(album, "releaseDate", None))
            )
            if not title or not release_date:
                continue
            release_type = _string_or_none(getattr(album, "type", None)) or "album"
            albums[album_id] = {
                "id": album_id,
                "title": title,
                "release_date": release_date,
                "type": release_type.lower(),
            }
    return list(albums.values())


def _search_tracks(session: Any, query: str, *, limit: int) -> list[Any]:
    try:
        import tidalapi
        results = session.search(query, models=[tidalapi.Track], limit=limit)
    except Exception:
        results = session.search(query, limit=limit)
    tracks = results.get("tracks") if isinstance(results, dict) else getattr(results, "tracks", [])
    return list(tracks or [])


def _search_first_track(session: Any, query: str, *, limit: int) -> Any | None:
    tracks = _search_tracks(session, query, limit=limit)
    return tracks[0] if tracks else None


def _search_tracks_current_or_legacy(session: Any, query: str, *, limit: int) -> list[Any]:
    openapi_error: Exception | None = None
    try:
        tracks = _openapi_search_tracks(session, query, limit=limit)
    except Exception as exc:
        openapi_error = exc
        tracks = []
    if tracks:
        return tracks
    legacy_tracks = _search_tracks(session, query, limit=limit)
    if legacy_tracks:
        return legacy_tracks
    if openapi_error is not None:
        raise openapi_error
    return []


def _openapi_first_track_by_isrc(session: Any, isrc: str) -> Any | None:
    tracks = _openapi_get_tracks(
        session,
        {
            "filter[isrc]": isrc,
            "include": "artists,albums",
        },
    )
    return tracks[0] if tracks else None


def _openapi_search_tracks(session: Any, query: str, *, limit: int) -> list[Any]:
    if not query.strip():
        return []
    payload = _openapi_get_json(
        session,
        f"searchResults/{quote(query, safe='')}/relationships/tracks",
        params={
            "countryCode": _session_country_code(session),
            "explicitFilter": "INCLUDE",
            "include": "tracks",
        },
    )
    track_ids: list[str] = []
    for ref in payload.get("data") or []:
        if not isinstance(ref, dict) or ref.get("type") != "tracks":
            continue
        track_id = _string_or_none(ref.get("id"))
        if track_id:
            track_ids.append(track_id)
        if len(track_ids) >= limit:
            break
    if not track_ids:
        return []
    return _openapi_get_tracks(
        session,
        {
            "filter[id]": ",".join(track_ids),
            "include": "artists,albums",
        },
    )


def _openapi_get_tracks(session: Any, params: dict[str, Any]) -> list[Any]:
    payload = _openapi_get_json(
        session,
        "tracks",
        params={
            "countryCode": _session_country_code(session),
            **params,
        },
    )
    included = _jsonapi_included(payload)
    tracks: list[Any] = []
    for item in payload.get("data") or []:
        if isinstance(item, dict) and item.get("type") == "tracks":
            tracks.append(_jsonapi_track_to_legacy(item, included))
    return tracks


def _openapi_get_json(session: Any, path: str, *, params: dict[str, Any]) -> dict[str, Any]:
    request = getattr(session, "request", None)
    method = getattr(request, "request", None)
    config = getattr(session, "config", None)
    base_url = getattr(config, "openapi_v2_location", "https://openapi.tidal.com/v2/")
    if not callable(method):
        raise ProviderUnavailable("Installed tidalapi version does not expose request access.")
    response = method("GET", path, params={key: value for key, value in params.items() if value}, base_url=base_url)
    return response.json()


def _iter_playlist_items_paginated(
    session: Any,
    playlist: Any,
    playlist_id: str,
    *,
    page_size: int = TIDAL_PLAYLIST_PAGE_SIZE,
) -> list[Any]:
    items: list[Any] = []
    offset = 0
    page_index = 0
    while True:
        if page_index >= TIDAL_PLAYLIST_MAX_PAGES:
            raise ProviderUnavailable(
                "Failed to fetch Tidal playlist pagination: safety stop reached "
                f"({TIDAL_PLAYLIST_MAX_PAGES} pages, fetched {len(items)} item(s))."
            )
        page = _fetch_playlist_items_page_with_retry(
            session=session,
            playlist=playlist,
            playlist_id=playlist_id,
            offset=offset,
            page_size=page_size,
            fetched_so_far=len(items),
            page_index=page_index,
        )
        if not page:
            break
        items.extend(page)
        if len(page) < page_size:
            break
        next_offset = offset + len(page)
        if next_offset <= offset:
            raise ProviderUnavailable(
                "Failed to fetch Tidal playlist pagination: offset did not advance "
                f"(offset={offset}, page={page_index + 1}, fetched={len(items)})."
            )
        offset = next_offset
        page_index += 1
    return items


def _fetch_playlist_items_page_with_retry(
    *,
    session: Any,
    playlist: Any,
    playlist_id: str,
    offset: int,
    page_size: int,
    fetched_so_far: int,
    page_index: int,
) -> list[Any]:
    attempts = TIDAL_PLAYLIST_PAGE_RETRIES + 1
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return _fetch_playlist_items_page(
                session=session,
                playlist=playlist,
                playlist_id=playlist_id,
                offset=offset,
                page_size=page_size,
            )
        except Exception as exc:
            last_error = exc
            if attempt < attempts:
                time.sleep(TIDAL_PLAYLIST_RETRY_BACKOFF_SECONDS * attempt)
    assert last_error is not None
    raise ProviderUnavailable(
        "Failed to fetch Tidal playlist pagination: "
        f"page={page_index + 1}, offset={offset}, fetched_so_far={fetched_so_far}, "
        f"retries={TIDAL_PLAYLIST_PAGE_RETRIES}, last_error={last_error}"
    ) from last_error


def _fetch_playlist_items_page(
    *,
    session: Any,
    playlist: Any,
    playlist_id: str,
    offset: int,
    page_size: int,
) -> list[Any]:
    native_page = _playlist_items_native_page(playlist, offset=offset, page_size=page_size)
    if native_page is not None:
        return native_page
    return _openapi_playlist_items_page(session, playlist_id=playlist_id, offset=offset, page_size=page_size)


def _playlist_items_native_page(playlist: Any, *, offset: int, page_size: int) -> list[Any] | None:
    items_method = getattr(playlist, "items", None)
    if not callable(items_method):
        return None
    try:
        page = items_method(limit=page_size, offset=offset)
        return list(page or [])
    except TypeError:
        if offset > 0:
            return None
        page = items_method()
        return list(page or [])


def _openapi_playlist_items_page(session: Any, *, playlist_id: str, offset: int, page_size: int) -> list[Any]:
    payload = _openapi_get_json(
        session,
        f"playlists/{quote(str(playlist_id), safe='')}/relationships/items",
        params={
            "countryCode": _session_country_code(session),
            "include": "items",
            "limit": page_size,
            "offset": offset,
        },
    )
    included = _jsonapi_included(payload)
    out: list[Any] = []
    for ref in payload.get("data") or []:
        if not isinstance(ref, dict):
            continue
        item_type = _string_or_none(ref.get("type"))
        item_id = _string_or_none(ref.get("id"))
        if not item_type or not item_id:
            continue
        source = included.get((item_type, item_id))
        if source is None:
            continue
        if item_type == "tracks":
            out.append(_jsonapi_track_to_legacy(source, included))
    return out


def _jsonapi_included(payload: dict[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    included: dict[tuple[str, str], dict[str, Any]] = {}
    for item in payload.get("included") or []:
        if isinstance(item, dict) and item.get("type") and item.get("id") is not None:
            included[(str(item["type"]), str(item["id"]))] = item
    return included


def _jsonapi_track_to_legacy(track: dict[str, Any], included: dict[tuple[str, str], dict[str, Any]]) -> dict[str, Any]:
    attrs = track.get("attributes") or {}
    relationships = track.get("relationships") or {}
    title = attrs.get("title") or ""
    version = attrs.get("version")
    if version and str(version).lower() not in str(title).lower():
        title = f"{title} ({version})"

    artist_refs = _relationship_refs(relationships.get("artists"))
    artists = []
    for ref in artist_refs:
        artist = included.get(("artists", ref))
        artist_attrs = artist.get("attributes") if isinstance(artist, dict) else {}
        artists.append({"id": ref, "name": (artist_attrs or {}).get("name") or ref})

    album_refs = _relationship_refs(relationships.get("albums"))
    album = None
    if album_refs:
        album_item = included.get(("albums", album_refs[0]))
        album_attrs = album_item.get("attributes") if isinstance(album_item, dict) else {}
        album = {
            "id": album_refs[0],
            "name": (album_attrs or {}).get("title"),
            "release_date": (album_attrs or {}).get("releaseDate"),
        }

    return {
        "id": track.get("id"),
        "name": title,
        "isrc": attrs.get("isrc"),
        "artists": artists,
        "artist": artists[0] if artists else None,
        "album": album,
    }


def _relationship_refs(relationship: Any) -> list[str]:
    data = _field(relationship, "data")
    if isinstance(data, dict):
        data = [data]
    refs: list[str] = []
    for item in data or []:
        if isinstance(item, dict) and item.get("id") is not None:
            refs.append(str(item["id"]))
    return refs


def _session_country_code(session: Any) -> str | None:
    return _string_or_none(_field(session, "country_code") or _field(getattr(session, "config", None), "country_code"))


def _track_matches_lookup_target(
    track: Any,
    *,
    target_artist: str,
    target_title: str,
    target_album: str | None,
    allow_relaxed_title_overlap: bool = False,
) -> bool:
    track_title = _field(track, "name")
    track_title_key = normalize_variant_title(track_title)
    target_title_key = normalize_variant_title(target_title)
    if not track_title_key or not target_title_key:
        return False
    title_match = track_title_key == target_title_key
    if not title_match and allow_relaxed_title_overlap:
        track_tokens = normalized_token_set(track_title_key)
        target_tokens = normalized_token_set(target_title_key)
        overlap = len(track_tokens & target_tokens)
        # Conservative fuzzy match for punctuation/variant drift.
        # Requires substantial token overlap, not just one common word.
        title_match = bool(
            track_tokens
            and target_tokens
            and overlap >= 2
            and overlap >= min(len(track_tokens), len(target_tokens)) - 1
        )
        if not title_match:
            # Qualifier-aware fallback:
            # allow base-title matches like "Fard" vs "Fard (piano voix)".
            shorter, longer = (target_tokens, track_tokens) if len(target_tokens) <= len(track_tokens) else (track_tokens, target_tokens)
            title_match = bool(shorter and shorter.issubset(longer) and len(shorter) <= 2 and overlap >= 1)
    if not title_match:
        return False
    album_match = _album_matches_target(track, target_album)
    track_artists = _field(track, "artists") or []
    candidate_artists = [str(name) for artist in track_artists if (name := _field(artist, "name"))]
    if not candidate_artists:
        primary_artist = _field(_field(track, "artist"), "name")
        candidate_artists = [str(primary_artist)] if primary_artist else []
    if not candidate_artists:
        return bool(album_match)
    if not (set(normalized_artist_credit(candidate_artists)) & set(normalized_artist_credit(target_artist))):
        # Script/transliteration fallback: if album + title align strongly, accept.
        if not album_match:
            return False
    return True


def _track_match_score(
    track: Any,
    *,
    target_title: str,
) -> int:
    track_title = _field(track, "name")
    track_key = normalize_key(track_title)
    target_key = normalize_key(target_title)
    if track_key and target_key and track_key == target_key:
        return 3
    track_variant_key = normalize_variant_title(track_title)
    target_variant_key = normalize_variant_title(target_title)
    if track_variant_key and target_variant_key and track_variant_key == target_variant_key:
        return 2
    return 1


def _tidal_candidate_within_discovery_window(
    track: Any,
    *,
    release_date: str | None,
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
    allow_missing_album_date: bool = False,
) -> bool:
    if discovery_window is None and (not discovery_months or discovery_months <= 0):
        return True
    window = resolve_effective_window(
        discovery_window=discovery_window,
        months=discovery_months,
        today=discovery_today or dt.date.today(),
    )
    target_date = parse_date(release_date)
    album_date = parse_date(_field(_field(track, "album"), "release_date"))
    if album_date is None:
        return bool(allow_missing_album_date)
    if not (window.start_date <= album_date <= window.end_date):
        return False
    if target_date is not None and abs(album_date.year - target_date.year) > 1:
        return False
    return True


def _album_matches_target(track: Any, target_album: str | None) -> bool:
    if not target_album:
        return False
    candidate_album = _field(_field(track, "album"), "name")
    candidate_key = normalize_variant_title(candidate_album)
    target_key = normalize_variant_title(target_album)
    if not candidate_key or not target_key:
        return False
    if candidate_key == target_key:
        return True
    candidate_tokens = normalized_token_set(candidate_key)
    target_tokens = normalized_token_set(target_key)
    overlap = len(candidate_tokens & target_tokens)
    if overlap >= max(2, min(len(candidate_tokens), len(target_tokens)) - 1):
        return True
    return False


def _track_match(track: Any) -> TidalTrackMatch | None:
    track_id = _string_or_none(_field(track, "id"))
    if not track_id:
        return None
    album = _field(track, "album")
    artists = _field(track, "artists") or []
    artist_names = [str(name) for artist in artists if (name := _field(artist, "name"))]
    if not artist_names:
        artist_name = _field(_field(track, "artist"), "name")
        artist_names = [str(artist_name)] if artist_name else []
    return TidalTrackMatch(
        track_id=track_id,
        album_id=_string_or_none(_field(album, "id")),
        isrc=_string_or_none(_field(track, "isrc")),
        title=_string_or_none(_field(track, "name")),
        artists=artist_names,
    )


def _playlist_item_track(item: Any) -> Any | None:
    track = _field(item, "track")
    return track if track is not None else item


def _field(payload: Any, name: str) -> Any:
    if payload is None:
        return None
    if isinstance(payload, dict):
        return payload.get(name)
    return getattr(payload, name, None)


def _string_or_none(value: Any) -> str | None:
    return str(value) if value is not None else None


def _int_or_none(value: Any) -> int | None:
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _normalize_tidal_track_id(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    # Accept shell-style placeholders like <123456789>.
    if text.startswith("<") and text.endswith(">"):
        text = text[1:-1].strip()
    # Accept track URLs/URIs and extract terminal identifier.
    for token in ("tidal.com/browse/track/", "tidal.com/track/", "tidal:track:"):
        if token in text:
            text = text.split(token, 1)[1]
            break
    text = text.split("?", 1)[0].split("/", 1)[0].strip()
    # Keep simple ID-safe characters.
    text = re.sub(r"[^A-Za-z0-9_-]", "", text)
    return text or None


def _normalize_tidal_album_id(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.startswith("<") and text.endswith(">"):
        text = text[1:-1].strip()
    for token in ("tidal.com/browse/album/", "tidal.com/album/", "tidal:album:"):
        if token in text:
            text = text.split(token, 1)[1]
            break
    text = text.split("?", 1)[0].split("/", 1)[0].strip()
    text = re.sub(r"[^A-Za-z0-9_-]", "", text)
    return text or None
