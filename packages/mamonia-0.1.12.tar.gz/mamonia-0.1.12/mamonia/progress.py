from __future__ import annotations

from collections import Counter
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field
import os
import sys
import threading
import time
import warnings
from typing import Callable, Protocol

from .i18n import DEFAULT_LANGUAGE, get_translator
from .models import CandidateArtist, ReleaseRecommendation

Emitter = Callable[[str], None]
PROGRESS_BAR_WIDTH = 50
PROGRESS_ACCENT = "#ff5a5a"
PROGRESS_SECONDARY = "white"
SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")


@dataclass(frozen=True)
class ProgressStageDefinition:
    stage_id: str
    label_key: str
    weight: float
    legacy_labels: tuple[str, ...] = ()


@dataclass
class ProgressStageRuntime:
    stage: ProgressStageDefinition
    status: str = "pending"
    processed: int = 0
    total: int | None = None
    active_item: str = ""
    bottleneck: str = ""


class ProgressStageRegistry:
    def __init__(self, locale: str = DEFAULT_LANGUAGE):
        self.locale = locale
        self._translate = get_translator(locale)
        self.stages: list[ProgressStageDefinition] = [
            ProgressStageDefinition(
                stage_id="canonicalization",
                label_key="progress_v2.stage.canonicalization",
                weight=0.05,
                legacy_labels=("Canonicalizing input tracks",),
            ),
            ProgressStageDefinition(
                stage_id="graph_prep",
                label_key="progress_v2.stage.graph_prep",
                weight=0.15,
                legacy_labels=("Computing seed weights", "Fetching seed tags", "Expanding artist graph"),
            ),
            ProgressStageDefinition(
                stage_id="candidate_fetch",
                label_key="progress_v2.stage.candidate_fetch",
                weight=0.70,
                legacy_labels=("Fetching candidate releases",),
            ),
            ProgressStageDefinition(
                stage_id="finalization",
                label_key="progress_v2.stage.finalization",
                weight=0.10,
                legacy_labels=(
                    "Scoring candidate releases",
                    "Enriching recommendation tracks",
                    "Deduplicating recommendation tracks",
                    "Resolving platform ID gaps",
                    "Resolving Tidal track IDs",
                    "[1/5] Preparing profile inputs",
                ),
            ),
        ]
        self._by_id = {stage.stage_id: stage for stage in self.stages}
        self._legacy_map = {label: stage.stage_id for stage in self.stages for label in stage.legacy_labels}

    def stage_for_legacy_label(self, label: str) -> ProgressStageDefinition:
        return self._by_id[self._legacy_map.get(label, "finalization")]

    def stage_label(self, stage_id: str) -> str:
        stage = self._by_id.get(stage_id)
        return self._translate(stage.label_key) if stage else stage_id


class ProgressEtaModel:
    def __init__(self) -> None:
        self._latency_samples_ms: list[float] = []

    def observe_call_latency(self, latency_sample_ms: float) -> None:
        if latency_sample_ms > 0:
            self._latency_samples_ms.append(float(latency_sample_ms))

    def estimate_remaining(self, *, total: int | None, processed: int, elapsed_seconds: int) -> int | None:
        return None


@dataclass(frozen=True)
class DiscoverySummary:
    candidates_processed: int = 0
    total_candidates: int | None = None
    release_groups_checked: int = 0
    accepted: int = 0
    spotify_misses: int = 0
    musicbrainz_misses: int = 0
    elapsed_seconds: int = 0
    estimated_remaining_seconds: int | None = None
    skips: dict[str, int] = field(default_factory=dict)


class ProgressReporter(Protocol):
    def stage_started(self, label: str, processed: int = 0, total: int | None = None) -> None: ...
    def candidate_started(self, candidate: CandidateArtist, processed: int, total: int | None) -> None: ...
    def release_group_checked(self, candidate: CandidateArtist, release_group: dict) -> None: ...
    def release_group_skipped(self, reason: str) -> None: ...
    def release_accepted(self, recommendation: ReleaseRecommendation) -> None: ...
    def spotify_lookup_missed(self, recommendation: ReleaseRecommendation) -> None: ...
    def musicbrainz_lookup_missed(self, recommendation: ReleaseRecommendation) -> None: ...
    def summary(self) -> DiscoverySummary: ...


class BusyStatusReporter(Protocol):
    def phase(self, label: str, wait_lines: list[str] | None = None): ...


@dataclass
class NoOpProgressReporter:
    started_at: float = field(default_factory=time.monotonic)
    candidates_processed: int = 0
    total_candidates: int | None = None
    release_groups_checked: int = 0
    accepted: int = 0
    spotify_misses: int = 0
    musicbrainz_misses: int = 0
    skips: Counter[str] = field(default_factory=Counter)
    current_stage: str = ""

    def stage_started(self, label: str, processed: int = 0, total: int | None = None) -> None:
        self.current_stage = label
        self.candidates_processed = processed
        self.total_candidates = total

    def candidate_started(self, candidate: CandidateArtist, processed: int, total: int | None) -> None:
        self.candidates_processed = processed
        self.total_candidates = total

    def release_group_checked(self, candidate: CandidateArtist, release_group: dict) -> None:
        self.release_groups_checked += 1

    def release_group_skipped(self, reason: str) -> None:
        self.skips[reason] += 1

    def release_accepted(self, recommendation: ReleaseRecommendation) -> None:
        self.accepted += 1

    def spotify_lookup_missed(self, recommendation: ReleaseRecommendation) -> None:
        self.spotify_misses += 1

    def musicbrainz_lookup_missed(self, recommendation: ReleaseRecommendation) -> None:
        self.musicbrainz_misses += 1

    def isrc_lookup(self, provider: str, hit: bool) -> None:
        _ = provider
        _ = hit

    def log_debug(self, message: str) -> None:
        _ = message

    def _elapsed(self) -> int:
        return int(time.monotonic() - self.started_at)

    def _estimated_remaining_seconds(self) -> int | None:
        if not self.total_candidates or self.candidates_processed <= 0:
            return None
        remaining = max(0, self.total_candidates - self.candidates_processed)
        if remaining == 0:
            return 0
        elapsed = time.monotonic() - self.started_at
        if elapsed <= 0:
            return None
        return int((elapsed / self.candidates_processed) * remaining)

    def summary(self) -> DiscoverySummary:
        return DiscoverySummary(
            candidates_processed=self.candidates_processed,
            total_candidates=self.total_candidates,
            release_groups_checked=self.release_groups_checked,
            accepted=self.accepted,
            spotify_misses=self.spotify_misses,
            musicbrainz_misses=self.musicbrainz_misses,
            elapsed_seconds=self._elapsed(),
            estimated_remaining_seconds=self._estimated_remaining_seconds(),
            skips=dict(self.skips),
        )


class ProgressStateEngine:
    def __init__(self, *, registry: ProgressStageRegistry, locale: str = DEFAULT_LANGUAGE):
        self.registry = registry
        self.locale = locale
        self.started_at = time.monotonic()
        self.runtimes: dict[str, ProgressStageRuntime] = {
            stage.stage_id: ProgressStageRuntime(stage=stage) for stage in registry.stages
        }
        self.current_stage_id: str | None = None

    def elapsed_seconds(self) -> int:
        return int(time.monotonic() - self.started_at)

    def enter_stage(self, stage_id: str, total_units: int | None = None) -> None:
        if self.current_stage_id and self.current_stage_id != stage_id:
            self.complete_stage(self.current_stage_id)
        rt = self.runtimes[stage_id]
        rt.status = "active"
        rt.processed = 0
        rt.total = total_units
        rt.active_item = ""
        rt.bottleneck = ""
        self.current_stage_id = stage_id

    def update_stage(
        self,
        *,
        processed_units: int | None = None,
        total_units: int | None = None,
        active_item: str | None = None,
        bottleneck: str | None = None,
        latency_sample_ms: float | None = None,
    ) -> None:
        _ = latency_sample_ms
        if not self.current_stage_id:
            return
        rt = self.runtimes[self.current_stage_id]
        if processed_units is not None:
            rt.processed = max(0, processed_units)
        if total_units is not None:
            rt.total = total_units
        if active_item is not None:
            rt.active_item = active_item
        if bottleneck is not None:
            rt.bottleneck = bottleneck

    def complete_stage(self, stage_id: str | None = None) -> None:
        sid = stage_id or self.current_stage_id
        if not sid:
            return
        rt = self.runtimes[sid]
        rt.status = "complete"
        if rt.total is not None:
            rt.processed = max(rt.processed, rt.total)
        if self.current_stage_id == sid:
            self.current_stage_id = None

    def complete_all(self) -> None:
        for stage in self.registry.stages:
            self.complete_stage(stage.stage_id)

    def stage_progress(self, runtime: ProgressStageRuntime) -> float:
        if runtime.status == "complete":
            return 1.0
        if runtime.total and runtime.total > 0:
            raw = max(0.0, min(1.0, runtime.processed / runtime.total))
            # Avoid visual "stuck at 100%" while a stage is still active.
            if runtime.status != "complete" and raw >= 1.0:
                return 0.99
            return raw
        return 0.0

    def overall_percent(self) -> int:
        total_weight = sum(stage.weight for stage in self.registry.stages)
        if total_weight <= 0:
            return 0
        weighted = 0.0
        all_complete = True
        for stage in self.registry.stages:
            rt = self.runtimes[stage.stage_id]
            weighted += stage.weight * self.stage_progress(rt)
            if rt.status != "complete":
                all_complete = False
        pct = int((weighted / total_weight) * 100)
        return 100 if all_complete else min(pct, 99)


class UnifiedProgressReporter(NoOpProgressReporter):
    def __init__(
        self,
        *,
        emit: Emitter,
        is_tty: bool,
        locale: str = DEFAULT_LANGUAGE,
        wait_lines: list[str] | None = None,
        console=None,
        every_candidates: int = 1,
        min_refresh_seconds: float = 0.0,
        line_rotate_seconds: float = 6.5,
    ) -> None:
        super().__init__()
        self.emit = emit
        self.is_tty = is_tty
        self.locale = locale
        self._t = get_translator(locale)
        self.registry = ProgressStageRegistry(locale=locale)
        self.engine = ProgressStateEngine(registry=self.registry, locale=locale)
        self.wait_lines = [line for line in (wait_lines or []) if line]
        self.every_candidates = max(1, every_candidates)
        self.min_refresh_seconds = max(0.0, float(min_refresh_seconds))
        self.line_rotate_seconds = max(0.0, float(line_rotate_seconds))
        self.phase_label = ""
        self._paused = False
        self._finished = False
        self._last_fallback = ""
        self._fallback_tick = 0
        self._fallback_stream = sys.stderr if is_tty else None
        self._last_render_at = 0.0
        self._use_live = console is not None
        self._console = console
        self._live = None
        self._overall = None
        self._stage = None
        self._overall_task = None
        self._stage_task = None
        # Candidate-fetch estimator state
        self._cf_total_candidates = 0
        self._cf_last_started_candidate = 0
        self._cf_release_groups_at_candidate_start = 0
        self._cf_ewma_release_groups_per_candidate = 10.0
        self._finalization_segments = {
            "Scoring candidate releases": (0.00, 0.40),
            "Enriching recommendation tracks": (0.40, 0.78),
            "Deduplicating recommendation tracks": (0.78, 1.00),
        }
        self._finalization_active_label: str | None = None
        self._finalization_sub_total = 0
        self._finalization_sub_processed = 0
        self._last_progress_event_at = time.monotonic()
        self._finalization_started_at = 0.0

    @property
    def live_enabled(self) -> bool:
        return self._use_live

    def emit_message(self, message: str, *, err: bool = False) -> None:
        _ = err
        if self._use_live and self._console is not None:
            # Keep non-progress output subdued and monochrome.
            from rich.text import Text
            self._console.print(Text(message, style="grey70"), markup=False, highlight=False)
            return
        self.emit(message)

    def start_session(self) -> None:
        if self._use_live:
            self._start_live()

    def enter_phase(self, label: str) -> None:
        self.phase_label = label
        self._render(force=True)

    def update_phase(self, detail: str | None = None) -> None:
        if detail:
            if self.engine.current_stage_id:
                self.engine.update_stage(active_item=detail)
        self._render()

    def finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        if self._live is not None:
            self._live.stop()
            self._live = None
            if hasattr(self._console, "print"):
                self._console.print("")
        if self._fallback_stream is not None and self._last_fallback:
            self._fallback_stream.write("\n")
            self._fallback_stream.flush()

    def _start_live(self) -> None:
        from rich.live import Live
        from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn

        self._overall = Progress(
            SpinnerColumn(style=PROGRESS_ACCENT),
            TextColumn("[bold white]{task.description}[/bold white]"),
            BarColumn(bar_width=None, complete_style=PROGRESS_ACCENT, finished_style=PROGRESS_ACCENT, pulse_style="grey35"),
            TextColumn("[white]{task.percentage:>3.0f}%[/white]"),
            TextColumn("   [grey70]Elapsed: {task.elapsed:>4.0f} s[/grey70]"),
            console=self._console,
        )
        self._stage = Progress(
            TextColumn("[bold white]{task.description}[/bold white]"),
            BarColumn(bar_width=None, complete_style=PROGRESS_ACCENT, finished_style=PROGRESS_ACCENT, pulse_style="grey35"),
            TextColumn("[white]{task.percentage:>3.0f}%[/white]"),
            console=self._console,
        )
        self._overall_task = self._overall.add_task(self._t("progress_v2.panel_title_overall"), total=100, completed=0)
        self._stage_task = self._stage.add_task(self._t("progress_v2.panel_title_stage"), total=1, completed=0)
        self._live = Live(self._build_live_group(), console=self._console, refresh_per_second=8, transient=True)
        self._live.start()

    def _build_live_group(self):
        from rich.console import Group
        from rich.panel import Panel
        from rich.table import Table
        from rich.text import Text

        metrics_table = Table.grid(expand=True)
        metrics_table.add_column(justify="left")
        metrics = (
            f"active: {self._active_item()} | rg: {self.release_groups_checked} | accepted: {self.accepted} | "
            f"spotify_miss: {self.spotify_misses} | mb_miss: {self.musicbrainz_misses}"
        )
        metrics_table.add_row(Text(metrics, style="grey70"))
        if self.skips:
            skip_text = ", ".join(f"{k}:{v}" for k, v in sorted(self.skips.items()))
            metrics_table.add_row(Text(f"skips: {skip_text}", style="grey70"))
        if self.wait_lines:
            if self.line_rotate_seconds > 0:
                tick = int(self._elapsed() / self.line_rotate_seconds) % len(self.wait_lines)
            else:
                tick = int(self._elapsed()) % len(self.wait_lines)
            metrics_table.add_row(Text(self.wait_lines[tick], style="grey70"))

        return Group(
            Panel(
                self._overall,
                title=f"[{PROGRESS_ACCENT}]{self._t('progress_v2.panel_title_app')}[/]",
                border_style=PROGRESS_ACCENT,
                title_align="left",
            ),
            Panel(
                self._stage,
                title=f"[white]{self._t('progress_v2.panel_title_stage')}[/white]",
                border_style="grey50",
                title_align="left",
            ),
            metrics_table,
        )

    def _current_stage_label(self) -> str:
        sid = self.engine.current_stage_id
        return self.registry.stage_label(sid) if sid else "-"

    def _active_item(self) -> str:
        sid = self.engine.current_stage_id
        if not sid:
            return "-"
        rt = self.engine.runtimes[sid]
        return rt.active_item or rt.bottleneck or "-"

    def _is_candidate_fetch_stage(self) -> bool:
        return self.engine.current_stage_id == "candidate_fetch"

    def _is_finalization_stage(self) -> bool:
        return self.engine.current_stage_id == "finalization"

    def _finalization_overall_cap(self) -> int:
        """Cap overall percent during active finalization to avoid fake 'almost done' plateaus."""
        if not self._is_finalization_stage():
            return 99
        # Map by active sub-stage first.
        label = self._finalization_active_label or ""
        if label == "Scoring candidate releases":
            return 90
        if label == "Enriching recommendation tracks":
            return 94
        if label == "Deduplicating recommendation tracks":
            # Start conservatively and only allow higher cap as real time passes.
            elapsed = max(0.0, time.monotonic() - self._finalization_started_at)
            if elapsed < 30:
                return 95
            if elapsed < 90:
                return 96
            return 97
        return 95

    def _recompute_candidate_fetch_units(self) -> None:
        if not self._is_candidate_fetch_stage():
            return
        total = max(1.0, float(self._cf_total_candidates or self.total_candidates or 1))
        completed_candidates = max(0.0, float(self._cf_last_started_candidate - 1))
        release_groups_in_current = max(0.0, float(self.release_groups_checked - self._cf_release_groups_at_candidate_start))
        expected_release_groups = max(1.0, float(self._cf_ewma_release_groups_per_candidate))
        intra_candidate = min(0.98, release_groups_in_current / expected_release_groups)
        synthetic_units = min(max(0.0, total - 0.01), completed_candidates + intra_candidate)
        self.engine.update_stage(processed_units=synthetic_units, total_units=total)

    def _recompute_finalization_units(self, *, with_time_tail: bool = False) -> None:
        if not self._is_finalization_stage():
            return
        seg = self._finalization_segments.get(self._finalization_active_label or "")
        if seg is None:
            return
        seg_start, seg_end = seg
        span = max(0.001, seg_end - seg_start)
        frac = 0.0
        if self._finalization_sub_total > 0:
            frac = max(0.0, min(1.0, self._finalization_sub_processed / self._finalization_sub_total))
        frac_capped = min(frac, 0.90)
        if with_time_tail:
            idle = max(0.0, time.monotonic() - self._last_progress_event_at)
            frac_capped = max(frac_capped, min(0.97, 0.90 + (idle / 300.0)))
        virtual_fraction = seg_start + (frac_capped * span)
        self.engine.update_stage(processed_units=virtual_fraction * 1000.0, total_units=1000.0)

    def _render(self, *, force: bool = False) -> None:
        if self._paused or self._finished:
            return
        now = time.monotonic()
        if not force and self.min_refresh_seconds > 0 and (now - self._last_render_at) < self.min_refresh_seconds:
            return
        self._last_render_at = now
        if self._use_live:
            if self._is_finalization_stage():
                self._recompute_finalization_units(with_time_tail=True)
            stage_total = 1.0
            stage_done = 0.0
            sid = self.engine.current_stage_id
            if sid:
                rt = self.engine.runtimes[sid]
                if rt.total and rt.total > 0:
                    stage_total = float(rt.total)
                    if rt.status == "complete":
                        stage_done = stage_total
                    else:
                        # Keep active stage below 100% until complete.
                        stage_done = min(float(rt.processed), max(0.0, stage_total - 0.01))
                elif rt.status == "complete":
                    stage_done = stage_total
            overall_percent = self.engine.overall_percent()
            if self._is_finalization_stage():
                overall_percent = min(overall_percent, self._finalization_overall_cap())
            self._overall.update(self._overall_task, description=f"{self.phase_label or 'Run'}", completed=overall_percent)
            self._stage.update(self._stage_task, description=self._current_stage_label(), total=stage_total, completed=stage_done)
            if self._live is not None:
                self._live.update(self._build_live_group(), refresh=True)
            return

        # strict fallback: spinner + one mutable line
        stage = self._current_stage_label()
        spin = SPINNER_FRAMES[self._fallback_tick % len(SPINNER_FRAMES)]
        self._fallback_tick += 1
        overall_percent = self.engine.overall_percent()
        if self._is_finalization_stage():
            overall_percent = min(overall_percent, self._finalization_overall_cap())
        line = (
            f"{spin} {self.phase_label or '-'} | {overall_percent:3d}% | "
            f"{stage} | elapsed={self._elapsed()}s | {self._active_item()}"
        )
        if not force and line == self._last_fallback:
            return
        self._last_fallback = line
        if self._fallback_stream is not None:
            self._fallback_stream.write("\r\x1b[2K" + line)
            self._fallback_stream.flush()
        else:
            self.emit(line)

    def stage_started(self, label: str, processed: int = 0, total: int | None = None) -> None:
        super().stage_started(label, processed, total)
        stage = self.registry.stage_for_legacy_label(label)
        self._last_progress_event_at = time.monotonic()
        if stage.stage_id == "finalization":
            self.engine.enter_stage(stage.stage_id, total_units=1000.0)
            self._finalization_started_at = time.monotonic()
            self._finalization_active_label = label
            self._finalization_sub_total = int(total or 0)
            self._finalization_sub_processed = int(processed or 0)
            self._recompute_finalization_units()
            self.engine.update_stage(active_item=label)
        else:
            self.engine.enter_stage(stage.stage_id, total_units=total)
            self.engine.update_stage(processed_units=processed, total_units=total, active_item=label)
        if stage.stage_id == "candidate_fetch":
            self._cf_total_candidates = int(total or 0)
            self._cf_last_started_candidate = 0
            self._cf_release_groups_at_candidate_start = self.release_groups_checked
        self._render(force=True)

    def candidate_started(self, candidate: CandidateArtist, processed: int, total: int | None) -> None:
        super().candidate_started(candidate, processed, total)
        self._last_progress_event_at = time.monotonic()
        if self._is_finalization_stage() and self._finalization_active_label in self._finalization_segments:
            self._finalization_sub_processed = int(processed or 0)
            if total is not None:
                self._finalization_sub_total = int(total or 0)
            self._recompute_finalization_units()
            self.engine.update_stage(active_item=candidate.name)
        else:
            self.engine.update_stage(processed_units=processed, total_units=total, active_item=candidate.name)
        if self._is_candidate_fetch_stage():
            if self._cf_last_started_candidate > 0 and processed > self._cf_last_started_candidate:
                completed_rg = max(0, self.release_groups_checked - self._cf_release_groups_at_candidate_start)
                alpha = 0.25
                self._cf_ewma_release_groups_per_candidate = max(
                    1.0,
                    (alpha * float(completed_rg))
                    + ((1.0 - alpha) * float(self._cf_ewma_release_groups_per_candidate)),
                )
            self._cf_last_started_candidate = max(self._cf_last_started_candidate, int(processed))
            self._cf_release_groups_at_candidate_start = self.release_groups_checked
            if total is not None:
                self._cf_total_candidates = int(total)
            self._recompute_candidate_fetch_units()
        if processed == 1 or processed % self.every_candidates == 0:
            self._render()

    def release_group_checked(self, candidate: CandidateArtist, release_group: dict) -> None:
        super().release_group_checked(candidate, release_group)
        self._last_progress_event_at = time.monotonic()
        self.engine.update_stage(bottleneck=str(release_group.get("title") or candidate.name))
        self._recompute_candidate_fetch_units()
        self._recompute_finalization_units()
        self._render()

    def release_group_skipped(self, reason: str) -> None:
        super().release_group_skipped(reason)
        self._last_progress_event_at = time.monotonic()
        self.engine.update_stage(bottleneck=reason)
        self._recompute_candidate_fetch_units()
        self._recompute_finalization_units()
        self._render()

    def release_accepted(self, recommendation: ReleaseRecommendation) -> None:
        super().release_accepted(recommendation)
        self._last_progress_event_at = time.monotonic()
        self.engine.update_stage(active_item=recommendation.artist)
        self._recompute_finalization_units()
        self._render()

    def spotify_lookup_missed(self, recommendation: ReleaseRecommendation) -> None:
        super().spotify_lookup_missed(recommendation)
        self._render()

    def musicbrainz_lookup_missed(self, recommendation: ReleaseRecommendation) -> None:
        super().musicbrainz_lookup_missed(recommendation)
        self._render()

    def pause(self) -> None:
        self._paused = True
        if self._live is not None:
            self._live.stop()
            self._live = None

    def resume(self) -> None:
        self._paused = False
        if self._use_live and self._live is None and not self._finished:
            self._start_live()
        self._render(force=True)

    def summary(self) -> DiscoverySummary:
        return super().summary()


class ProgressDisplayDriver:
    """Deprecated compatibility wrapper; scheduled for removal."""

    def __init__(self, *, emit: Emitter, is_tty: bool, locale: str = DEFAULT_LANGUAGE, refresh_hz: float = 10.0) -> None:
        warnings.warn("ProgressDisplayDriver is deprecated and scheduled for removal.", DeprecationWarning, stacklevel=2)
        self.emit = emit
        self.is_tty = is_tty
        self.locale = locale
        self.refresh_interval = 1.0 / max(1.0, refresh_hz)
        self._last_line = ""
        self._last_refresh = 0.0

    def pause(self) -> None:
        return None

    def resume(self) -> None:
        return None

    def finish(self) -> None:
        return None

    def refresh(self, state: ProgressStateEngine, *, force: bool = False) -> None:
        now = time.monotonic()
        if not force and (now - self._last_refresh) < self.refresh_interval:
            return
        self._last_refresh = now
        label = state.registry.stage_label(state.current_stage_id) if state.current_stage_id else "-"
        line = f"[{state.overall_percent():3d}%] {label} | elapsed={state.elapsed_seconds()}s"
        if line != self._last_line:
            self.emit(line)
            self._last_line = line


class LegacyProgressAdapter(NoOpProgressReporter):
    """Deprecated compatibility bridge; scheduled for removal."""

    def __init__(self, *, engine: ProgressStateEngine, driver: ProgressDisplayDriver):
        warnings.warn("LegacyProgressAdapter is deprecated and scheduled for removal.", DeprecationWarning, stacklevel=2)
        super().__init__()
        self.engine = engine
        self.registry = engine.registry
        self.driver = driver

    def stage_started(self, label: str, processed: int = 0, total: int | None = None) -> None:
        super().stage_started(label, processed, total)
        stage = self.registry.stage_for_legacy_label(label)
        self.engine.enter_stage(stage.stage_id, total_units=total)
        self.engine.update_stage(processed_units=processed, total_units=total, active_item=label)
        self.driver.refresh(self.engine, force=True)

    def candidate_started(self, candidate: CandidateArtist, processed: int, total: int | None) -> None:
        super().candidate_started(candidate, processed, total)
        self.engine.update_stage(processed_units=processed, total_units=total, active_item=candidate.name)
        self.driver.refresh(self.engine)

    def release_group_checked(self, candidate: CandidateArtist, release_group: dict) -> None:
        super().release_group_checked(candidate, release_group)
        self.engine.update_stage(bottleneck=str(release_group.get("title") or candidate.name))
        self.driver.refresh(self.engine)

    def release_group_skipped(self, reason: str) -> None:
        super().release_group_skipped(reason)
        self.engine.update_stage(bottleneck=reason)
        self.driver.refresh(self.engine)

    def release_accepted(self, recommendation: ReleaseRecommendation) -> None:
        super().release_accepted(recommendation)
        self.engine.update_stage(active_item=recommendation.artist)
        self.driver.refresh(self.engine)

    def pause(self) -> None:
        self.driver.pause()

    def resume(self) -> None:
        self.driver.resume()

    def summary(self) -> DiscoverySummary:
        self.driver.finish()
        return super().summary()


class CompactProgressReporter(UnifiedProgressReporter):
    def __init__(
        self,
        emit: Emitter,
        locale: str = DEFAULT_LANGUAGE,
        min_refresh_seconds: float = 0.2,
        every_candidates: int = 1,
    ) -> None:
        super().__init__(
            emit=emit,
            is_tty=False,
            locale=locale,
            min_refresh_seconds=min_refresh_seconds,
            every_candidates=every_candidates,
        )


class PlainTextProgressReporter(UnifiedProgressReporter):
    def __init__(
        self,
        emit: Emitter,
        every_candidates: int = 10,
        wait_lines: list[str] | None = None,
        line_rotate_seconds: float = 6.5,
        locale: str = DEFAULT_LANGUAGE,
    ) -> None:
        super().__init__(
            emit=emit,
            is_tty=False,
            locale=locale,
            wait_lines=wait_lines,
            every_candidates=every_candidates,
            line_rotate_seconds=line_rotate_seconds,
        )


class RichProgressReporter(UnifiedProgressReporter):
    def __init__(
        self,
        emit: Emitter,
        console,
        wait_lines: list[str] | None = None,
        line_rotate_seconds: float = 6.5,
        refresh_interval_seconds: float = 0.2,
        locale: str = DEFAULT_LANGUAGE,
    ) -> None:
        warnings.warn(
            "RichProgressReporter is deprecated. Use UnifiedProgressReporter instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(
            emit=emit,
            is_tty=True,
            locale=locale,
            wait_lines=wait_lines,
            console=console,
            line_rotate_seconds=line_rotate_seconds,
            min_refresh_seconds=refresh_interval_seconds,
        )
        self.start_session()

    def summary(self) -> DiscoverySummary:
        self.finish()
        return super().summary()


class NoOpBusyStatusReporter:
    def phase(self, label: str, wait_lines: list[str] | None = None):
        _ = label
        _ = wait_lines
        return nullcontext()

    def update(self, label: str | None = None, wait_lines: list[str] | None = None) -> None:
        _ = label
        _ = wait_lines
        return None

    def clear(self) -> None:
        return None


class RichBusyStatusReporter:
    def __init__(
        self,
        *,
        console,
        refresh_interval_seconds: float = 0.2,
        line_rotate_seconds: float = 6.5,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.console = console
        self.refresh_interval_seconds = refresh_interval_seconds
        self.line_rotate_seconds = line_rotate_seconds
        self.clock = clock
        self._live = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._label = ""
        self._wait_lines: list[str] = []
        self._started_at = 0.0

    @contextmanager
    def phase(self, label: str, wait_lines: list[str] | None = None):
        self._label = label
        self._wait_lines = [line for line in (wait_lines or []) if line]
        self._started_at = self.clock()
        self._start()
        try:
            yield
        finally:
            self._stop_live()

    def update(self, label: str | None = None, wait_lines: list[str] | None = None) -> None:
        if label is not None:
            self._label = label
        if wait_lines is not None:
            self._wait_lines = [line for line in wait_lines if line]
        if self._live is not None:
            self._live.update(self._render(), refresh=True)

    def _start(self) -> None:
        from rich.live import Live

        self._stop.clear()
        self._live = Live(self._render(), console=self.console, refresh_per_second=10, transient=True)
        self._live.start()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(self.refresh_interval_seconds):
            if self._live is None:
                return
            self._live.update(self._render(), refresh=True)

    def _stop_live(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
        if self._live is not None:
            self._live.stop()
            self._live = None
            if hasattr(self.console, "print"):
                self.console.print("")

    def _render(self):
        from rich.console import Group
        from rich.spinner import Spinner
        from rich.table import Table
        from rich.text import Text

        elapsed = max(0.0, self.clock() - self._started_at)
        tick = int(elapsed / self.line_rotate_seconds) if self.line_rotate_seconds > 0 else 0
        wait_line = wait_line_for_tick(self._wait_lines, tick)
        top = Table.grid(padding=(0, 1))
        top.add_row(Spinner("dots", style=PROGRESS_ACCENT), Text(self._label, style=PROGRESS_ACCENT))
        elapsed_line = Text(f"   elapsed: {int(elapsed)}s", style="dim")
        wait_text = Text("   " + wait_line, style="dim") if wait_line else Text("")
        return Group(top, elapsed_line, wait_text)

    def clear(self) -> None:
        self._stop_live()


def choose_busy_status_reporter(*, is_tty: bool) -> BusyStatusReporter:
    if not is_tty:
        return NoOpBusyStatusReporter()
    try:
        from rich.console import Console

        console = Console()
        if not getattr(console, "is_terminal", False) or not getattr(console, "is_interactive", False):
            return NoOpBusyStatusReporter()
        return RichBusyStatusReporter(console=console)
    except Exception:
        return NoOpBusyStatusReporter()


def choose_progress_reporter(
    *,
    is_tty: bool,
    emit: Emitter,
    discovery_wait_lines: list[str] | None = None,
    locale: str = DEFAULT_LANGUAGE,
) -> ProgressReporter:
    force_live = os.getenv("MAMONIA_FORCE_LIVE_PROGRESS", "").strip().lower() in {"1", "true", "yes", "on"}
    disable_live = os.getenv("MAMONIA_DISABLE_RICH_LIVE", "").strip().lower() in {"1", "true", "yes", "on"}
    console = None
    use_live = False
    if is_tty:
        try:
            from rich.console import Console

            c = Console(stderr=True)
            safe_auto_live = (
                getattr(c, "is_terminal", False)
                and getattr(c, "is_interactive", False)
                and not getattr(c, "is_dumb_terminal", False)
                and getattr(sys.stderr, "isatty", lambda: False)()
                and (os.getenv("TERM", "").lower() not in {"", "dumb"})
                and not os.getenv("CODEX_CI")
                and not os.getenv("CODEX_SHELL")
            )
            use_live = force_live or (safe_auto_live and not disable_live)
            if use_live:
                console = c
        except Exception:
            console = None
            use_live = False
    reporter = UnifiedProgressReporter(
        emit=emit,
        is_tty=is_tty,
        locale=locale,
        wait_lines=discovery_wait_lines,
        console=(console if use_live else None),
    )
    reporter.start_session()
    return reporter


def wait_line_for_tick(lines: list[str], tick: int) -> str:
    if not lines:
        return ""
    return lines[max(0, tick) % len(lines)]


def progress_percent(processed: int, total: int | None) -> int | None:
    if total is None or total <= 0:
        return None
    return max(0, min(100, int((processed / total) * 100)))


def render_progress_block(
    *,
    processed: int,
    total: int | None,
    current_artist: str,
    elapsed_seconds: int,
    estimated_remaining_seconds: int | None,
    wait_line: str = "",
    wait_line_style: str = "dim italic",
    rich: bool = False,
    locale: str = DEFAULT_LANGUAGE,
) -> object:
    _ = wait_line_style
    _ = rich
    _ = locale
    percent = progress_percent(processed, total)
    filled = int(PROGRESS_BAR_WIDTH * (percent or 0) / 100)
    empty = PROGRESS_BAR_WIDTH - filled
    percent_label = f"{percent}%" if percent is not None else "--%"
    current_total = str(total) if total is not None else "?"
    lines = [
        f"[{'#' * filled}{'-' * empty}] {percent_label}",
        _time_line(percent_label, elapsed_seconds, estimated_remaining_seconds, percent is not None, locale=locale),
    ]
    if wait_line:
        lines.append(wait_line)
    lines.extend(["", "Currently working on:", f"{processed} / {current_total} - {current_artist}"])
    return "\n".join(lines)


def _time_line(
    percent_label: str,
    elapsed_seconds: int,
    estimated_remaining_seconds: int | None,
    show_percent_and_eta: bool,
    locale: str = DEFAULT_LANGUAGE,
) -> str:
    _ = percent_label
    translate = get_translator(locale)
    if not show_percent_and_eta:
        return translate("progress.time_elapsed", elapsed=elapsed_seconds)
    eta = translate("progress.unknown_duration") if estimated_remaining_seconds is None else str(estimated_remaining_seconds)
    return translate("progress.time_elapsed_eta", elapsed=elapsed_seconds, eta=eta)


def format_duration(seconds: int | None, locale: str = DEFAULT_LANGUAGE) -> str:
    translate = get_translator(locale)
    if seconds is None:
        return translate("progress.unknown_duration")
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {sec}s" if sec else f"{minutes}m"
    hours, minute = divmod(minutes, 60)
    return f"{hours}h {minute}m" if minute else f"{hours}h"


def stage_divider_for_stage(stage_label: str, locale: str = DEFAULT_LANGUAGE) -> str:
    _ = stage_label
    _ = locale
    return ""
