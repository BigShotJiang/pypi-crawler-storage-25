"""
Release discovery and filtering — §7–8 of the Human Logic Proposal.

For every artist in the expanded graph, fetches release-groups from
MusicBrainz and applies the following filter chain in order:

    1. Type filter  — keep albums, EPs, singles only
    2. Secondary type exclusion — drop compilations, live, bootleg, karaoke,
                                  tribute (configurable)
    3. Temporal filter — release date must fall within the configured window
                         (default: 365 days back from today)
    4. Deduplication — collapse identical release_group_mbids
    5. Heard exclusion — drop releases already in heard_input or heard_output

Returns a list of CandidateRelease dataclasses ready for the scoring engine.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any

from .models import CandidateArtist
from .progress import ProgressReporter


# ---------------------------------------------------------------------------
# Primary release-group types we accept
# ---------------------------------------------------------------------------
_ACCEPTED_PRIMARY_TYPES = {"album", "ep", "single"}

# Secondary types that are excluded by default
_EXCLUDED_SECONDARY_TYPES = {"compilation", "live", "bootleg", "remix", "karaoke", "tribute", "mixtape/street"}

# Patterns that hint at a remaster/deluxe/reissue in the title
_REISSUE_PATTERNS = [
    re.compile(r"\b(remaster(ed)?|reissue|deluxe|anniversary edition|expanded|special edition)\b", re.I),
]

# Default lookback window in days
DEFAULT_WINDOW_DAYS = 365

# Early stopping: once we have this many candidates, skip remaining low-tier artists
TARGET_CANDIDATES_BEFORE_STOPPING = 150

# Tier priority for release discovery ordering (lower = higher priority)
_TIER_PRIORITY: dict[str, int] = {
    "Tier 1": 0,
    "Tier 2A": 1,
    "Tier 2B": 2,
    "Tier 3": 3,
    "Tier 4": 4,
}


@dataclass
class CandidateRelease:
    """A release-group candidate ready for scoring."""
    release_group_mbid: str
    artist_mbid: str | None
    artist_name: str
    title: str
    release_date: str          # ISO date string, may be partial ("2025" or "2025-04")
    primary_type: str          # album | ep | single
    secondary_types: list[str] = field(default_factory=list)
    label: str | None = None
    streaming_provider: str | None = None
    streaming_only_id: str | None = None
    streaming_corroborated: bool = False  # True when the same release was found by both Deezer and Tidal
    tier: str = ""             # Tier 1–4 from graph expansion
    # Penalty flags set during filtering
    possible_reissue: bool = False
    uncertain_release_type: bool = False
    # Populated later by scoring engine
    score: float = 0.0
    score_normalized: float = 0.0
    # Count of this artist's accepted short-form releases in the active window.
    # Used by v2 enrichment to reduce tracks per release for very frequent EP/single releasers.
    artist_window_release_count: int = 1


def fetch_candidates(
    artist_tiers: dict[str, str],
    artist_names: dict[str, str],
    musicbrainz: Any,
    heard_release_group_mbids: set[str] | None = None,
    window_days: int = DEFAULT_WINDOW_DAYS,
    allow_compilations: bool = False,
    allow_live: bool = False,
    emit: Any = None,
    progress: ProgressReporter | None = None,
    window_start_date: date | None = None,
    window_end_date: date | None = None,
    debug: bool = False,
    allowed_tiers: set[str] | None = None,
    early_stop_target: int = TARGET_CANDIDATES_BEFORE_STOPPING,
    max_artists_to_scan: int = 0,
) -> list[CandidateRelease]:
    """
    Fetch and filter release-group candidates for all artists in the expanded graph.

    Args:
        artist_tiers: Mapping of artist key → tier string (from ExpandedGraph).
        artist_names: Mapping of artist key → canonical name (from ExpandedGraph).
        musicbrainz: MusicBrainzProvider instance.
        heard_release_group_mbids: Set of already-heard release group MBIDs to exclude.
        window_days: Look-back window in days (default 365).
        allow_compilations: If True, compilations survive the secondary-type filter.
        allow_live: If True, live albums survive the secondary-type filter.
        progress: Optional progress reporter for the default stopwatch/progress display.
        window_start_date: Optional specific start date for release filtering.
        window_end_date: Optional specific end date for release filtering.

    Returns:
        Deduplicated list of CandidateRelease objects, oldest → newest.
    """
    heard = heard_release_group_mbids or set()
    if window_start_date is not None and window_end_date is not None:
        cutoff = window_start_date
        ceiling = window_end_date
    else:
        cutoff = date.today() - timedelta(days=window_days)
        ceiling = date.today()
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)

    excluded_secondary = set(_EXCLUDED_SECONDARY_TYPES)
    if allow_compilations:
        excluded_secondary.discard("compilation")
    if allow_live:
        excluded_secondary.discard("live")

    seen_mbids: set[str] = set()
    candidates: list[CandidateRelease] = []
    _filter_log: dict[str, int] = {"no_mbid": 0, "heard": 0, "type": 0, "secondary": 0, "no_date": 0, "cutoff": 0}
    # Cache for name → MBID lookups to avoid repeated searches
    _name_to_mbid: dict[str, str | None] = {}

    # Sort artists by tier priority so high-tier artists are processed first.
    # This lets us apply early stopping once we have enough candidates.
    sorted_artists = sorted(
        artist_tiers.items(),
        key=lambda item: _TIER_PRIORITY.get(item[1], 99),
    )
    if max_artists_to_scan > 0:
        sorted_artists = sorted_artists[:max_artists_to_scan]
    total_artists = len(sorted_artists)
    # Track new (not previously heard) candidates for early stopping logic
    new_candidates_count = 0
    for processed, (artist_key, tier) in enumerate(sorted_artists, start=1):
        if allowed_tiers is not None and tier not in allowed_tiers:
            continue
        artist_name = artist_names.get(artist_key, "")
        if progress is not None:
            progress.candidate_started(
                CandidateArtist(name=artist_name or artist_key, source=f"v2:{tier}", score=0),
                processed,
                total_artists,
            )
        artist_mbid = artist_key if _looks_like_mbid(artist_key) else None

        # Try to resolve name-only artists to MBIDs via MusicBrainz search
        if not artist_mbid and artist_name and musicbrainz:
            cached = _name_to_mbid.get(artist_name.lower())
            if cached is not None:
                artist_mbid = cached
            else:
                try:
                    search_result = musicbrainz.search_artist(artist_name)
                    if search_result and search_result.get("id"):
                        artist_mbid = search_result["id"]
                        _name_to_mbid[artist_name.lower()] = artist_mbid
                    else:
                        _name_to_mbid[artist_name.lower()] = None
                except Exception:
                    _name_to_mbid[artist_name.lower()] = None

        if not artist_mbid:
            _filter_log["no_mbid"] += 1
            if progress is not None:
                progress.release_group_skipped("artist-mbid-missing")
            continue  # need MBID to browse release groups

        rgs = _safe_fetch_release_groups(musicbrainz, artist_mbid)
        for rg in rgs:
            if progress is not None:
                progress.release_group_checked(
                    CandidateArtist(name=artist_name or artist_key, source=f"v2:{tier}", score=0),
                    rg,
                )
            rg_mbid = rg.get("id", "")
            if not rg_mbid or rg_mbid in seen_mbids or rg_mbid in heard:
                if rg_mbid in heard:
                    _filter_log["heard"] += 1
                    if progress is not None:
                        progress.release_group_skipped("heard")
                continue

            primary_type = (rg.get("primary-type") or "").lower()
            if primary_type not in _ACCEPTED_PRIMARY_TYPES:
                _filter_log["type"] += 1
                if progress is not None:
                    progress.release_group_skipped("type")
                continue

            secondary_types = [s.lower() for s in (rg.get("secondary-types") or [])]
            if any(s in excluded_secondary for s in secondary_types):
                _filter_log["secondary"] += 1
                if progress is not None:
                    progress.release_group_skipped("secondary-type")
                continue

            release_date = _best_release_date(rg)
            if not release_date:
                _filter_log["no_date"] += 1
                if progress is not None:
                    progress.release_group_skipped("no-date")
                continue

            parsed_date = _parse_date(release_date)
            if parsed_date is None or parsed_date < cutoff or parsed_date > ceiling:
                _filter_log["cutoff"] += 1
                if progress is not None:
                    progress.release_group_skipped("cutoff")
                continue

            title = rg.get("title", "")
            possible_reissue = _is_reissue(title, secondary_types)
            uncertain_type = not primary_type  # edge case: MB omits type

            seen_mbids.add(rg_mbid)
            # Track new (unheard) candidates separately for early stopping
            is_new_candidate = rg_mbid not in heard
            if is_new_candidate:
                new_candidates_count += 1
            # Early stopping: skip adding low-tier candidates once we have enough new ones,
            # but still process all artists to check heard status. This ensures Tier 3/4
            # artists get discovered in future runs once Tier 1/2 releases are heard.
            if new_candidates_count >= early_stop_target and _TIER_PRIORITY.get(tier, 99) >= 3:
                _v2_emit(f"[v2] Early stopping: {new_candidates_count} new candidates reached, skipping {tier} candidate addition.")
                continue
            candidates.append(CandidateRelease(
                release_group_mbid=rg_mbid,
                artist_mbid=artist_mbid,
                artist_name=artist_name,
                title=title,
                release_date=release_date,
                primary_type=primary_type,
                secondary_types=secondary_types,
                tier=tier,
                possible_reissue=possible_reissue,
                uncertain_release_type=uncertain_type,
            ))

    candidates.sort(key=lambda c: c.release_date)
    annotate_artist_window_release_counts(candidates)
    _v2_emit(f"[v2] Release filters: {_filter_log}")
    return candidates


def fetch_label_affinity_candidates(
    *,
    labels: list[tuple[str, float]],
    musicbrainz: Any,
    heard_release_group_mbids: set[str] | None = None,
    existing_release_group_mbids: set[str] | None = None,
    window_days: int = DEFAULT_WINDOW_DAYS,
    allow_compilations: bool = False,
    allow_live: bool = False,
    emit: Any = None,
    window_start_date: date | None = None,
    window_end_date: date | None = None,
    debug: bool = False,
) -> list[CandidateRelease]:
    """
    Fetch recent releases from labels connected to the user's profile.

    Label affinity is discovery evidence, so candidates are always emitted as
    Tier 3 and scored through synthetic graph edges in pipeline_v2.
    """
    heard = heard_release_group_mbids or set()
    seen_mbids = set(existing_release_group_mbids or set())
    if window_start_date is not None and window_end_date is not None:
        cutoff = window_start_date
        ceiling = window_end_date
    else:
        cutoff = date.today() - timedelta(days=window_days)
        ceiling = date.today()
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)

    excluded_secondary = set(_EXCLUDED_SECONDARY_TYPES)
    if allow_compilations:
        excluded_secondary.discard("compilation")
    if allow_live:
        excluded_secondary.discard("live")

    candidates: list[CandidateRelease] = []
    filter_log: dict[str, int] = {"heard": 0, "duplicate": 0, "type": 0, "secondary": 0, "no_date": 0, "cutoff": 0}

    search = getattr(musicbrainz, "search_releases_by_label", None)
    if not callable(search):
        return []

    for label_name, _weight in labels:
        try:
            releases = search(label_name, limit=25) or []
        except Exception:
            continue
        for release in releases:
            rg = release.get("release-group") or {}
            rg_mbid = rg.get("id") or release.get("release-group-id") or ""
            if not rg_mbid:
                filter_log["duplicate"] += 1
                continue
            if rg_mbid in heard:
                filter_log["heard"] += 1
                continue
            if rg_mbid in seen_mbids:
                filter_log["duplicate"] += 1
                continue

            primary_type = (rg.get("primary-type") or release.get("primary-type") or "Album").lower()
            if primary_type not in _ACCEPTED_PRIMARY_TYPES:
                filter_log["type"] += 1
                continue

            secondary_types = [s.lower() for s in (rg.get("secondary-types") or release.get("secondary-types") or [])]
            if any(s in excluded_secondary for s in secondary_types):
                filter_log["secondary"] += 1
                continue

            release_date = _best_release_date(
                {
                    "first-release-date": rg.get("first-release-date") or release.get("date", ""),
                    "releases": release.get("releases", []),
                }
            )
            if not release_date:
                filter_log["no_date"] += 1
                continue

            parsed_date = _parse_date(release_date)
            if parsed_date is None or parsed_date < cutoff or parsed_date > ceiling:
                filter_log["cutoff"] += 1
                continue

            artist_name, artist_mbid = _artist_from_release(release, fallback="")
            title = rg.get("title") or release.get("title", "")
            seen_mbids.add(rg_mbid)
            candidates.append(
                CandidateRelease(
                    release_group_mbid=rg_mbid,
                    artist_mbid=artist_mbid,
                    artist_name=artist_name,
                    title=title,
                    release_date=release_date,
                    primary_type=primary_type,
                    secondary_types=secondary_types,
                    label=label_name,
                    tier="Tier 3",
                    possible_reissue=_is_reissue(title, secondary_types),
                    uncertain_release_type=not primary_type,
                )
            )

    candidates.sort(key=lambda c: c.release_date)
    annotate_artist_window_release_counts(candidates)
    _v2_emit(f"[v2] Label affinity filters: {filter_log}")
    return candidates


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_fetch_release_groups(mb: Any, artist_mbid: str) -> list[dict]:
    try:
        return mb.browse_release_groups(artist_mbid) or []
    except Exception:
        return []


def _artist_from_release(release: dict, fallback: str = "") -> tuple[str, str | None]:
    artist_credit = release.get("artist-credit") or []
    if not artist_credit:
        return fallback, None
    first = artist_credit[0] or {}
    name = first.get("name") or (first.get("artist") or {}).get("name") or fallback
    mbid = first.get("id") or (first.get("artist") or {}).get("id")
    return name, mbid


def _best_release_date(rg: dict) -> str:
    """Return the earliest release date we can find for this release-group."""
    # MB may provide first-release-date directly
    frd = rg.get("first-release-date") or rg.get("first_release_date") or ""
    if frd:
        return frd
    # Fall back to checking releases list if present
    for release in rg.get("releases", []):
        d = release.get("date", "")
        if d:
            return d
    return ""


def _parse_date(date_str: str) -> date | None:
    """Parse a partial or full ISO date string. Returns None if unparseable."""
    if not date_str:
        return None
    # Strip to first 10 chars to handle "2025-04-01T00:00:00Z" etc.
    date_str = date_str[:10]
    parts = date_str.split("-")
    try:
        if len(parts) == 3:
            return date(int(parts[0]), int(parts[1]), int(parts[2]))
        if len(parts) == 2:
            return date(int(parts[0]), int(parts[1]), 1)
        if len(parts) == 1 and len(parts[0]) == 4:
            return date(int(parts[0]), 1, 1)
    except (ValueError, IndexError):
        pass
    return None


def _is_reissue(title: str, secondary_types: list[str]) -> bool:
    if "compilation" in secondary_types:
        return True
    return any(p.search(title) for p in _REISSUE_PATTERNS)


def _looks_like_mbid(s: str) -> bool:
    return len(s) == 36 and s.count("-") == 4


def _artist_count_key(candidate: CandidateRelease) -> str:
    return candidate.artist_mbid or candidate.artist_name.lower()


def annotate_artist_window_release_counts(candidates: list[CandidateRelease]) -> None:
    """Annotate candidates with per-artist short-form release counts."""
    counts: dict[str, int] = {}
    for candidate in candidates:
        if candidate.primary_type.lower() not in {"ep", "single"}:
            continue
        key = _artist_count_key(candidate)
        if key:
            counts[key] = counts.get(key, 0) + 1
    for candidate in candidates:
        key = _artist_count_key(candidate)
        candidate.artist_window_release_count = max(1, counts.get(key, 1))
