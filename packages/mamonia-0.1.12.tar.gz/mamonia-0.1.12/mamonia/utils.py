from __future__ import annotations

import datetime as dt
import re
import unicodedata
from collections.abc import Iterable
from typing import Any


POLISH_FOLD = str.maketrans(
    {
        "ą": "a",
        "ć": "c",
        "ę": "e",
        "ł": "l",
        "ń": "n",
        "ó": "o",
        "ś": "s",
        "ż": "z",
        "ź": "z",
        "Ą": "A",
        "Ć": "C",
        "Ę": "E",
        "Ł": "L",
        "Ń": "N",
        "Ó": "O",
        "Ś": "S",
        "Ż": "Z",
        "Ź": "Z",
    }
)

VARIANT_STRONG_TOKENS = {
    "alt",
    "alternate",
    "anniversary",
    "bonus",
    "collector",
    "deluxe",
    "digital",
    "expanded",
    "explicit",
    "international",
    "japan",
    "japanese",
    "limited",
    "reissue",
    "reissued",
    "remaster",
    "remastered",
    "re-recorded",
    "rerecorded",
    "regional",
    "special",
    "stereo",
    "uk",
    "us",
    "version",
}
VARIANT_CONTEXT_TOKENS = {
    "aka",
    "audio",
    "clean",
    "disc",
    "discs",
    "edition",
    "instrumental",
    "mix",
    "mono",
    "track",
    "tracks",
    "version",
}
ARTIST_SPLIT_RE = re.compile(r"\s*(?:,| feat\.? | featuring | ft\.? | & | and )\s*", re.IGNORECASE)


def normalize_key(value: str | None) -> str:
    """Normalize human music metadata for fuzzy-but-stable matching."""
    if not value:
        return ""
    value = value.translate(POLISH_FOLD)
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value.lower())).strip()


def dedupe(items: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = normalize_key(item)
        if key and key not in seen:
            seen.add(key)
            out.append(item)
    return out


def normalize_variant_title(value: str | None) -> str:
    stripped = strip_variant_suffixes(value)
    return normalize_key(stripped or value)


def release_match_key(artist: str | None, title: str | None, release_date: str | None = None) -> str:
    artist_key = normalize_key(artist)
    title_key = normalize_variant_title(title)
    year = release_year(release_date) or ""
    return normalize_key(f"{artist_key}|{title_key}|{year}") if artist_key and title_key else ""


def titles_match(left: str | None, right: str | None) -> bool:
    left_key = normalize_variant_title(left)
    right_key = normalize_variant_title(right)
    return bool(left_key and right_key and left_key == right_key)


def release_title_match(left: str | None, right: str | None) -> bool:
    left_key = normalize_variant_title(left)
    right_key = normalize_variant_title(right)
    if not left_key or not right_key:
        return False
    if left_key == right_key:
        return True
    left_tokens = set(left_key.split())
    right_tokens = set(right_key.split())
    return bool(left_tokens and right_tokens and (left_tokens <= right_tokens or right_tokens <= left_tokens))


def split_artist_names(value: str | None) -> list[str]:
    if not value:
        return []
    parts = [part.strip() for part in ARTIST_SPLIT_RE.split(value) if part and part.strip()]
    return parts or [value.strip()]


def normalized_artist_credit(value: str | list[str] | None) -> tuple[str, ...]:
    if value is None:
        return ()
    values = value if isinstance(value, list) else split_artist_names(value)
    normalized = sorted({normalize_key(item) for item in values if normalize_key(item)})
    return tuple(normalized)


def artist_credits_match(left: str | list[str] | None, right: str | list[str] | None) -> bool:
    left_credit = set(normalized_artist_credit(left))
    right_credit = set(normalized_artist_credit(right))
    if not left_credit or not right_credit:
        return False
    return bool(left_credit & right_credit) and (left_credit <= right_credit or right_credit <= left_credit or left_credit == right_credit)


def normalized_token_set(value: str | None, *, min_length: int = 1) -> set[str]:
    return {token for token in normalize_key(value).split() if len(token) >= min_length}


def keyword_query_variants(*parts: str | None, max_queries: int = 4) -> list[str]:
    words: list[str] = []
    seen: set[str] = set()
    for part in parts:
        for token in normalize_key(part).split():
            if len(token) < 3 or token in seen:
                continue
            seen.add(token)
            words.append(token)
    if not words:
        return []
    queries = [" ".join(words)]
    if len(words) <= 3:
        return queries
    for index in range(len(words)):
        subset = words[:index] + words[index + 1 :]
        if len(subset) < 3:
            continue
        queries.append(" ".join(subset))
        if len(queries) >= max_queries:
            break
    return queries


def normalized_cache_key(namespace: str, /, **parts: Any) -> str:
    tokens = []
    for key, value in sorted(parts.items()):
        normalized = _normalize_cache_value(value)
        if not normalized:
            continue
        tokens.append(f"{normalize_key(key)}={normalized}")
    suffix = "|".join(tokens)
    return f"{namespace}:{suffix}" if suffix else namespace


def strip_variant_suffixes(value: str | None) -> str:
    current = (value or "").strip()
    if not current:
        return ""
    while True:
        updated = _strip_single_variant_suffix(current)
        if updated == current:
            return updated.strip()
        current = updated.strip()


def variant_score(title: str | None) -> int:
    """Score a release title based on variant preference.

    Higher score = more preferred variant.
    Priority: remastered > deluxe > original.

    Args:
        title: Release title to score

    Returns:
        int: Variant score (2=remastered, 1=deluxe, 0=original)
    """
    if not title:
        return 0
    normalized = normalize_key(title)
    if "remaster" in normalized or "remastered" in normalized:
        return 2
    if "deluxe" in normalized:
        return 1
    return 0


def content_variant_type(title: str | None) -> str | None:
    """Detect explicit/clean content variant in a release title.

    Args:
        title: Release title to check

    Returns:
        str | None: "explicit", "clean", or None if no content variant detected
    """
    if not title:
        return None
    normalized = normalize_key(title)
    if "explicit" in normalized:
        return "explicit"
    if "clean" in normalized:
        return "clean"
    return None


def _strip_single_variant_suffix(value: str) -> str:
    bracket_match = re.match(r"^(?P<base>.+?)\s*[\(\[](?P<fragment>[^()\[\]]+)[\)\]]\s*$", value)
    if bracket_match and _is_variant_fragment(bracket_match.group("fragment")):
        return bracket_match.group("base")
    separator_match = re.match(r"^(?P<base>.+?)\s*(?:-|:|–|—)\s*(?P<fragment>[^-:–—]+)\s*$", value)
    if separator_match and _is_variant_fragment(separator_match.group("fragment")):
        return separator_match.group("base")
    return value


def _is_variant_fragment(fragment: str) -> bool:
    tokens = normalize_key(fragment).split()
    if not tokens:
        return False
    token_set = set(tokens)
    if not (token_set & VARIANT_STRONG_TOKENS):
        return False
    for token in token_set:
        if token in VARIANT_STRONG_TOKENS or token in VARIANT_CONTEXT_TOKENS:
            continue
        if token.isdigit():
            continue
        if re.fullmatch(r"\d+(?:st|nd|rd|th)", token):
            continue
        return False
    return True


def parse_date(value: str | None) -> dt.date | None:
    if not value:
        return None
    value = value.strip()
    for fmt in ("%Y-%m-%d", "%Y-%m", "%Y"):
        try:
            parsed = dt.datetime.strptime(value, fmt)
        except ValueError:
            continue
        if fmt == "%Y":
            return dt.date(parsed.year, 1, 1)
        if fmt == "%Y-%m":
            return dt.date(parsed.year, parsed.month, 1)
        return parsed.date()
    return None


def release_year(value: str | None) -> int | None:
    parsed = parse_date(value)
    return parsed.year if parsed else None


def within_month_window(value: str | None, months: int, today: dt.date | None = None) -> bool:
    parsed = parse_date(value)
    if parsed is None:
        return False
    today = today or dt.date.today()
    cutoff = today - dt.timedelta(days=max(1, months) * 30)
    return cutoff <= parsed <= today


def clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


def safe_get(data: Any, *path: Any, default: Any = None) -> Any:
    current = data
    for part in path:
        try:
            current = current[part] if isinstance(current, list) else current.get(part)
        except Exception:
            return default
        if current is None:
            return default
    return current


def chunked[T](items: list[T], size: int) -> Iterable[list[T]]:
    for idx in range(0, len(items), size):
        yield items[idx : idx + size]


def _normalize_cache_value(value: Any) -> str:
    if value in (None, "", [], {}, ()):
        return ""
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        tokens = [
            f"{normalize_key(str(key))}:{_normalize_cache_value(inner)}"
            for key, inner in sorted(value.items())
            if _normalize_cache_value(inner)
        ]
        return ",".join(tokens)
    if isinstance(value, (list, tuple, set)):
        tokens = [_normalize_cache_value(item) for item in value]
        return ",".join(token for token in tokens if token)
    normalized = normalize_key(str(value))
    return normalized or str(value).strip().lower()


def extract_artist_track_from_title(title: str) -> tuple[str, str] | None:
    """Extract (artist, track) from a free-form title string.

    Tries multiple separators and strips common video/audio noise suffixes.
    Returns None if no separator is found and the title is too ambiguous.

    This function is inspired by the parseYouTubeTitle logic from convert.ts
    and is useful for parsing track metadata from YouTube video titles or
    copy-pasted tracklists that don't follow strict formatting.
    """
    if not title:
        return None

    # Try multiple separators in order of preference
    separators = [" - ", " – ", " — ", " | ", ": ", " by "]
    for sep in separators:
        if sep in title:
            parts = title.split(sep, 1)
            if len(parts) >= 2:
                artist = parts[0].strip()
                track = parts[1].strip()
                if artist and track:
                    # Strip noise suffixes from track
                    track = _strip_youtube_noise(track)
                    return (artist, track)

    # No separator found - try to clean the title and return as track with Unknown Artist
    cleaned = _strip_youtube_noise(title)
    if cleaned and cleaned != title.strip():
        return ("Unknown Artist", cleaned)
    return None


def _strip_youtube_noise(value: str) -> str:
    """Strip common YouTube video/audio noise suffixes from a track title.

    Removes patterns like:
    - (official video), [audio], (lyric video), etc.
    - HD, 4K, 1080p, etc.
    - live, acoustic, remix, cover, mv, etc.
    """
    if not value:
        return ""

    # Pattern to match common YouTube noise in brackets/parentheses
    noise_patterns = [
        r"\s*[\(\[](?:official\s*)?(?:video|audio|lyric|lyrics|remix|cover|live|acoustic|mv|hd|4k|1080p|720p|studio|version)\s*[\)\]]",
        r"\s*[\(\[](?:from|in)\s+.*?[\)\]]",
        r"\s*[\(\[](?:ft\.?|feat\.?|featuring|ft)\s+.*?[\)\]]",
        r"\s*-\s*(?:official\s*)?(?:video|audio|lyric|remix|cover|live|acoustic|mv|hd|4k|1080p|720p)\s*",
    ]

    result = value
    for pattern in noise_patterns:
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)

    # Clean up extra spaces
    result = re.sub(r"\s+", " ", result).strip()

    return result
