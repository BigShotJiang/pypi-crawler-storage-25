from __future__ import annotations

import datetime as dt
import re
from calendar import monthrange
from dataclasses import dataclass


@dataclass(frozen=True)
class DiscoveryWindow:
    start_date: dt.date
    end_date: dt.date


_RANGE_SPLIT = re.compile(r"\s+-\s+")
_MONTH_YEAR = re.compile(r"^(0[1-9]|1[0-2])\.(\d{4})$")
_DATE_DOT = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4})$")
_DATE_DASH = re.compile(r"^(\d{2})-(\d{2})-(\d{4})$")


def normalize_window(start_date: dt.date, end_date: dt.date) -> DiscoveryWindow:
    if start_date <= end_date:
        return DiscoveryWindow(start_date=start_date, end_date=end_date)
    return DiscoveryWindow(start_date=end_date, end_date=start_date)


def resolve_effective_window(
    *,
    discovery_window: DiscoveryWindow | None,
    months: int | None,
    today: dt.date | None = None,
) -> DiscoveryWindow:
    if discovery_window is not None:
        return normalize_window(discovery_window.start_date, discovery_window.end_date)
    current = today or dt.date.today()
    if months is None or int(months) <= 0:
        return DiscoveryWindow(start_date=dt.date.min, end_date=current)
    lookback_months = max(1, int(months))
    cutoff = current - dt.timedelta(days=lookback_months * 30)
    return DiscoveryWindow(start_date=cutoff, end_date=current)


def parse_window_component(value: str) -> DiscoveryWindow:
    raw = (value or "").strip()
    if not raw:
        raise ValueError("empty")
    if re.fullmatch(r"\d{4}", raw):
        year = int(raw)
        return DiscoveryWindow(dt.date(year, 1, 1), dt.date(year, 12, 31))
    month_match = _MONTH_YEAR.fullmatch(raw)
    if month_match:
        month = int(month_match.group(1))
        year = int(month_match.group(2))
        last_day = monthrange(year, month)[1]
        return DiscoveryWindow(dt.date(year, month, 1), dt.date(year, month, last_day))
    dot_match = _DATE_DOT.fullmatch(raw)
    if dot_match:
        day = int(dot_match.group(1))
        month = int(dot_match.group(2))
        year = int(dot_match.group(3))
        parsed = dt.date(year, month, day)
        return DiscoveryWindow(parsed, parsed)
    dash_match = _DATE_DASH.fullmatch(raw)
    if dash_match:
        day = int(dash_match.group(1))
        month = int(dash_match.group(2))
        year = int(dash_match.group(3))
        parsed = dt.date(year, month, day)
        return DiscoveryWindow(parsed, parsed)
    try:
        parsed = dt.date.fromisoformat(raw)
        return DiscoveryWindow(parsed, parsed)
    except ValueError as exc:
        raise ValueError("unsupported") from exc


def parse_discovery_window_input(raw_value: str) -> DiscoveryWindow:
    raw = (raw_value or "").strip()
    if not raw:
        raise ValueError("empty")
    if " - " in raw:
        parts = _RANGE_SPLIT.split(raw)
        if len(parts) != 2:
            raise ValueError("range")
        left = parse_window_component(parts[0])
        right = parse_window_component(parts[1])
        start_date = min(left.start_date, right.start_date)
        end_date = max(left.end_date, right.end_date)
        return normalize_window(start_date, end_date)
    component = parse_window_component(raw)
    return normalize_window(component.start_date, component.end_date)
