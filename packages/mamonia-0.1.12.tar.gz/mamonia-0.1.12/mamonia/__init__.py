"""Mamonia: local-first music discovery inspired by Prawo Mamonia."""

from .isrc import (
    ISRCResolver,
    ISRCEnrichmentPipeline,
    ISRCResolution,
    ISRCBatchResult,
    create_isrc_resolver,
    create_isrc_enrichment_pipeline,
)

__all__ = [
    "__version__",
    "ISRCResolver",
    "ISRCEnrichmentPipeline",
    "ISRCResolution",
    "ISRCBatchResult",
    "create_isrc_resolver",
    "create_isrc_enrichment_pipeline",
]

__version__ = "0.1.12"