from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path
from platform import system
from urllib.parse import urlparse

from pydantic import BaseModel


def _clamp_int(value: int, minimum: int, maximum: int) -> int:
    return max(minimum, min(maximum, value))


def _absolute_path(value: str | Path) -> Path:
    raw = str(value)
    # Preserve explicit Windows drive paths during cross-platform tests.
    if len(raw) >= 2 and raw[1] == ":" and raw[0].isalpha():
        return Path(raw)
    return Path(raw).expanduser().absolute()


def _default_mamonia_home() -> Path:
    os_name = system()
    if os_name == "Windows":
        local_app_data = os.getenv("LOCALAPPDATA", "").strip()
        if local_app_data:
            return Path(local_app_data) / "Mamonia"
    if os_name == "Linux":
        xdg_state_home = os.getenv("XDG_STATE_HOME", "").strip()
        if xdg_state_home:
            return Path(xdg_state_home) / "mamonia"
    user_home_raw = os.getenv("HOME", "").strip() or os.getenv("USERPROFILE", "").strip()
    user_home = Path(user_home_raw).expanduser() if user_home_raw else None
    if user_home is None:
        try:
            user_home = Path.home()
        except RuntimeError:
            return Path(".mamonia")
    if os_name == "Darwin":
        return user_home / "Library" / "Application Support" / "Mamonia"
    if os_name == "Linux":
        return user_home / ".local" / "state" / "mamonia"
    return user_home / ".mamonia"


def canonical_data_dir_for_os() -> Path:
    """Canonical per-user Mamonia state root, independent of runtime overrides."""
    return _absolute_path(_default_mamonia_home())


def canonical_db_path_for_os() -> Path:
    """Canonical SQLite path for destructive operations."""
    return canonical_data_dir_for_os() / "mamonia.sqlite"


def _resolve_data_dir() -> Path:
    configured = os.getenv("MAMONIA_HOME")
    if configured:
        return _absolute_path(configured)
    return _absolute_path(_default_mamonia_home())


def _assert_writable_directory(path: Path) -> None:
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Mamonia data directory is not writable: {path}") from exc
    try:
        with tempfile.NamedTemporaryFile(prefix=".mamonia_write_test_", dir=path, delete=True):
            pass
    except OSError as exc:
        raise RuntimeError(f"Mamonia data directory is not writable: {path}") from exc


def canonical_env_path() -> Path:
    """Return the canonical .env path inside the platform-specific data directory."""
    return _resolve_data_dir() / ".env"


def _load_dotenv_if_available() -> None:
    """Load .env from the canonical data directory (primary, does not override)."""
    env_path = canonical_env_path()
    harden_secret_file_permissions(env_path)
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv(str(env_path), override=False)


def _load_dotenv_from_path(env_path: Path) -> None:
    if not env_path.exists():
        return
    harden_secret_file_permissions(env_path)
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv(str(env_path), override=False)


def _ensure_env_file(env_path: Path) -> None:
    """Create .env from .env.example if .env does not exist."""
    if env_path.exists():
        harden_secret_file_permissions(env_path)
        return
    env_path.parent.mkdir(parents=True, exist_ok=True)
    # Try to find .env.example in candidate locations
    candidates = [
        env_path.parent / ".env.example",              # managed config dir
        Path(__file__).parent.parent / ".env.example",  # repo root
        Path(__file__).parent / ".env.example",          # package dir
        Path.cwd() / ".env.example",                     # cwd
    ]
    for src in candidates:
        if src.exists():
            env_path.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            harden_secret_file_permissions(env_path)
            return
    # Fallback: create empty file
    env_path.write_text("", encoding="utf-8")
    harden_secret_file_permissions(env_path)


def save_env_credential(env_path: Path, key: str, value: str) -> None:
    """Write or update a credential in the given .env file and set it in the current process."""
    _ensure_env_file(env_path)
    env_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        from dotenv import set_key
        set_key(str(env_path), key, value, quote_mode="never")
    except Exception:
        lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
        prefix = f"{key}="
        updated = False
        for i, line in enumerate(lines):
            if line.startswith(prefix):
                lines[i] = f"{key}={value}"
                updated = True
                break
        if not updated:
            lines.append(f"{key}={value}")
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    harden_secret_file_permissions(env_path)
    os.environ[key] = value


def harden_secret_file_permissions(path: Path) -> bool:
    """Best-effort owner-only permissions for local credential/session files."""
    if os.name == "nt" or not path.exists() or not path.is_file():
        return False
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        return True
    except OSError:
        return False


def credential_file_permission_status(path: Path) -> str:
    if not path.exists():
        return "missing"
    if os.name == "nt":
        return "not checked"
    try:
        mode = stat.S_IMODE(path.stat().st_mode)
    except OSError:
        return "unknown"
    return "OK" if mode & (stat.S_IRWXG | stat.S_IRWXO) == 0 else "too broad"


def is_valid_spotify_redirect_uri(value: str) -> bool:
    parsed = urlparse(value)
    if not parsed.scheme or not parsed.netloc or "*" in value:
        return False
    if parsed.hostname == "localhost":
        return False
    if parsed.scheme == "https":
        return True
    return parsed.scheme == "http" and parsed.hostname == "127.0.0.1"


class Settings(BaseModel):
    app_name: str = "Mamonia"
    app_version: str = "0.1.0"
    data_dir: Path
    db_path: Path
    spotify_client_id: str = ""
    spotify_client_secret: str = ""
    spotify_redirect_uri: str = "http://127.0.0.1:8888/callback"
    spotify_market: str = ""
    lastfm_api_key: str = ""
    mb_contact: str = "mamonia-local@example.com"
    tidal_client_id: str = ""
    tidal_client_secret: str = ""
    apple_music_developer_token: str = ""
    apple_music_user_token: str = ""
    apple_music_storefront: str = "us"
    listenbrainz_user_token: str = ""
    # Community artists filtering settings
    ubiquitous_artist_threshold: float = 0.3  # 0.0-1.0, lower = more strict
    genre_overlap_minimum: float = 0.2  # Minimum genre Jaccard similarity to rescue
    use_global_ubiquity_cache: bool = False  # Cache ubiquity scores across profiles
    enable_community_filtering: bool = True  # Master switch
    listenbrainz_min_share_for_solo: float = 0.6    # Fraction of top-N listeners required to pass LB-only in standard mode
    listenbrainz_min_share_for_deep_cuts: float = 0.2  # Softer floor for LB-only when deep_cuts mode is active
    spotify_cache_ttl_days: int = 60
    spotify_cache_miss_ttl_days: int = 60
    musicbrainz_cache_ttl_days: int = 90
    lastfm_cache_ttl_days: int = 60
    listenbrainz_cache_ttl_days: int = 60
    listenbrainz_listeners_count: int = 10
    listenbrainz_listener_artists_count: int = 50
    deezer_cache_ttl_days: int = 60
    provider_http_timeout_seconds: float = 10.0
    provider_http_connect_timeout_seconds: float = 5.0
    provider_http_read_timeout_seconds: float = 10.0
    provider_http_write_timeout_seconds: float = 10.0
    provider_http_pool_timeout_seconds: float = 5.0
    graph_interleave_enabled: bool = True
    graph_interleave_mode: str = "per_seed_round_robin"
    lastfm_tag_budget_per_run: int = 0
    lastfm_min_interval_seconds: float = 0.25
    spotify_enrichment_budget_per_run: int = 0
    spotify_disable_rescue_after_429: bool = False
    force_refresh: bool = False

    @property
    def spotify_configured(self) -> bool:
        return bool(self.spotify_client_id and self.spotify_client_secret)

    @property
    def spotify_playlist_configured(self) -> bool:
        return bool(self.spotify_client_id and is_valid_spotify_redirect_uri(self.spotify_redirect_uri))

    @property
    def tidal_configured(self) -> bool:
        return bool(self.tidal_client_id and self.tidal_client_secret)

    @property
    def apple_music_configured(self) -> bool:
        return bool(self.apple_music_developer_token and self.apple_music_user_token)

    @property
    def lastfm_configured(self) -> bool:
        return bool(self.lastfm_api_key)

    @property
    def listenbrainz_configured(self) -> bool:
        return bool(self.listenbrainz_user_token)

    @property
    def mb_contact_is_placeholder(self) -> bool:
        return self.mb_contact in {"", "mamonia-local@example.com", "you@example.com", "user@example.com"}

    @property
    def mb_contact_configured(self) -> bool:
        return not self.mb_contact_is_placeholder

    @property
    def spotify_cache_ttl_seconds(self) -> int:
        return _clamp_int(self.spotify_cache_ttl_days, 1, 365) * 24 * 60 * 60

    @property
    def spotify_cache_miss_ttl_seconds(self) -> int:
        return _clamp_int(self.spotify_cache_miss_ttl_days, 1, 365) * 24 * 60 * 60

    @property
    def musicbrainz_cache_ttl_seconds(self) -> int:
        return _clamp_int(self.musicbrainz_cache_ttl_days, 1, 365) * 24 * 60 * 60

    @property
    def lastfm_cache_ttl_seconds(self) -> int:
        return _clamp_int(self.lastfm_cache_ttl_days, 1, 365) * 24 * 60 * 60

    @property
    def listenbrainz_cache_ttl_seconds(self) -> int:
        return _clamp_int(self.listenbrainz_cache_ttl_days, 1, 365) * 24 * 60 * 60

    @property
    def deezer_cache_ttl_seconds(self) -> int:
        return _clamp_int(self.deezer_cache_ttl_days, 1, 365) * 24 * 60 * 60

    def warnings(self) -> list[str]:
        out: list[str] = []
        if self.mb_contact_is_placeholder:
            out.append("MB_CONTACT_EMAIL is still a placeholder; set it to your email for polite MusicBrainz usage.")
        if self.spotify_client_id and not is_valid_spotify_redirect_uri(self.spotify_redirect_uri):
            out.append("SPOTIPY_REDIRECT_URI must use HTTPS, unless it is http://127.0.0.1 for local development.")
        return out


def load_settings(*, force_refresh: bool = False) -> Settings:
    legacy_cwd_env_fallback = os.getenv("MAMONIA_LEGACY_CWD_ENV_FALLBACK", "false").strip().lower() == "true"
    if legacy_cwd_env_fallback:
        _load_dotenv_from_path(Path.cwd() / ".env")
    data_dir = _resolve_data_dir()
    # Canonical .env in managed data_dir is the primary source by default.
    _load_dotenv_from_path(data_dir / ".env")
    if legacy_cwd_env_fallback:
        _load_dotenv_from_path(Path.cwd() / ".env")
    _assert_writable_directory(data_dir)
    db_path = _absolute_path(os.getenv("MAMONIA_DB", data_dir / "mamonia.sqlite"))
    return Settings(
        data_dir=data_dir,
        db_path=db_path,
        spotify_client_id=os.getenv("SPOTIPY_CLIENT_ID", os.getenv("SPOTIFY_CLIENT_ID", "")),
        spotify_client_secret=os.getenv("SPOTIPY_CLIENT_SECRET", os.getenv("SPOTIFY_CLIENT_SECRET", "")),
        spotify_redirect_uri=os.getenv(
            "SPOTIPY_REDIRECT_URI",
            os.getenv("SPOTIFY_REDIRECT_URI", "http://127.0.0.1:8888/callback"),
        ),
        spotify_market=os.getenv("SPOTIFY_MARKET", os.getenv("MAMONIA_SPOTIFY_MARKET", "")),
        lastfm_api_key=os.getenv("LASTFM_API_KEY", ""),
        mb_contact=os.getenv("MB_CONTACT_EMAIL", "mamonia-local@example.com"),
        tidal_client_id=os.getenv("TIDAL_CLIENT_ID", ""),
        tidal_client_secret=os.getenv("TIDAL_CLIENT_SECRET", ""),
        apple_music_developer_token=os.getenv("APPLE_MUSIC_DEVELOPER_TOKEN", ""),
        apple_music_user_token=os.getenv("APPLE_MUSIC_USER_TOKEN", ""),
        apple_music_storefront=os.getenv("APPLE_MUSIC_STOREFRONT", "us"),
        listenbrainz_user_token=os.getenv("LISTENBRAINZ_USER_TOKEN", ""),
        ubiquitous_artist_threshold=float(os.getenv("MAMONIA_UBIQUITOUS_ARTIST_THRESHOLD", "0.3")),
        genre_overlap_minimum=float(os.getenv("MAMONIA_GENRE_OVERLAP_MINIMUM", "0.2")),
        use_global_ubiquity_cache=os.getenv("MAMONIA_USE_GLOBAL_UBIQUITY_CACHE", "false").lower() == "true",
        enable_community_filtering=os.getenv("MAMONIA_ENABLE_COMMUNITY_FILTERING", "true").lower() != "false",
        listenbrainz_min_share_for_solo=float(os.getenv("MAMONIA_LB_MIN_SHARE_SOLO", "0.6")),
        listenbrainz_min_share_for_deep_cuts=float(os.getenv("MAMONIA_LB_MIN_SHARE_DEEP_CUTS", "0.2")),
        spotify_cache_ttl_days=int(os.getenv("MAMONIA_SPOTIFY_CACHE_TTL_DAYS", "90")),
        spotify_cache_miss_ttl_days=int(os.getenv("MAMONIA_SPOTIFY_MISS_TTL_DAYS", "60")),
        musicbrainz_cache_ttl_days=int(os.getenv("MAMONIA_MUSICBRAINZ_CACHE_TTL_DAYS", "90")),
        lastfm_cache_ttl_days=int(os.getenv("MAMONIA_LASTFM_CACHE_TTL_DAYS", "60")),
        listenbrainz_cache_ttl_days=int(os.getenv("MAMONIA_LISTENBRAINZ_CACHE_TTL_DAYS", "60")),
        listenbrainz_listeners_count=int(os.getenv("MAMONIA_LB_LISTENERS_COUNT", "10")),
        listenbrainz_listener_artists_count=int(os.getenv("MAMONIA_LB_LISTENER_ARTISTS_COUNT", "50")),
        deezer_cache_ttl_days=int(os.getenv("MAMONIA_DEEZER_CACHE_TTL_DAYS", "60")),
        provider_http_timeout_seconds=float(os.getenv("MAMONIA_PROVIDER_HTTP_TIMEOUT_SECONDS", "10")),
        provider_http_connect_timeout_seconds=float(os.getenv("MAMONIA_PROVIDER_HTTP_CONNECT_TIMEOUT_SECONDS", "5")),
        provider_http_read_timeout_seconds=float(os.getenv("MAMONIA_PROVIDER_HTTP_READ_TIMEOUT_SECONDS", "10")),
        provider_http_write_timeout_seconds=float(os.getenv("MAMONIA_PROVIDER_HTTP_WRITE_TIMEOUT_SECONDS", "10")),
        provider_http_pool_timeout_seconds=float(os.getenv("MAMONIA_PROVIDER_HTTP_POOL_TIMEOUT_SECONDS", "5")),
        graph_interleave_enabled=os.getenv("MAMONIA_GRAPH_INTERLEAVE_ENABLED", "true").lower() == "true",
        graph_interleave_mode=os.getenv("MAMONIA_GRAPH_INTERLEAVE_MODE", "per_seed_round_robin"),
        lastfm_tag_budget_per_run=int(os.getenv("MAMONIA_LASTFM_TAG_BUDGET_PER_RUN", "0")),
        lastfm_min_interval_seconds=float(os.getenv("MAMONIA_LASTFM_MIN_INTERVAL_SECONDS", "0.25")),
        spotify_enrichment_budget_per_run=int(os.getenv("MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN", "0")),
        spotify_disable_rescue_after_429=os.getenv("MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429", "false").lower() == "true",
        force_refresh=force_refresh,
    )
