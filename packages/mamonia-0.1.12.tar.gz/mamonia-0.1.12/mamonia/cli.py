from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Annotated

import typer

from .analysis import build_taste_profile
from .config import canonical_db_path_for_os, credential_file_permission_status, load_settings
from .discovery import track_keys_from_input
from .interactive import launch_guided
from .input import looks_like_apple_music_playlist, looks_like_spotify_playlist, looks_like_tidal_playlist, parse_text_file
from .models import InputTrack, TasteProfile
from .profiles import seed_tracks_from_payload, source_identity, source_identity_from_tracks
from .providers import ProviderRateLimit, ProviderUnavailable
from .providers.lastfm import LastFMProvider
from .providers.musicbrainz import MusicBrainzProvider
from .providers.apple_music import AppleMusicProvider
from .providers.spotify import SpotifyProvider
from .providers.tidal import TidalProvider
from .storage import Storage
from .state_runtime import (
    detect_db_path_change,
    detect_legacy_cwd_artifacts,
    get_last_active_db_path,
    migrate_state_to_managed,
    update_last_active_db_path,
)
from .workflow import (
    DiscoverOptions,
    WorkflowAbort,
    _default_output_path,
    auto_mark_exported_releases,
    enrich_source_name,
    profile_summary_line,
    run_discover,
)


app = typer.Typer(help="Mamonia: local-first music discovery inspired by Prawo Mamonia.")
heard_app = typer.Typer(help="Manage the permanent already-heard release list.")
cache_app = typer.Typer(help="Manage local API cache.")
profile_app = typer.Typer(help="Manage reusable playlist-scoped taste profiles.")
db_app = typer.Typer(help="Inspect and maintain local SQLite state.")

app.add_typer(heard_app, name="heard")
app.add_typer(cache_app, name="cache")
app.add_typer(profile_app, name="profile")
app.add_typer(db_app, name="db")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        try:
            launch_guided(emit=typer.echo, emit_error=lambda message: typer.echo(message, err=True))
        except KeyboardInterrupt:
            typer.echo("Canceled.", err=True)
            raise typer.Exit(130) from None
        except RuntimeError as exc:
            raise typer.Exit(_error(str(exc))) from exc


@app.command()
def discover(
    playlist: Annotated[
        str | None,
        typer.Option("--playlist", "-p", help="Spotify/Tidal/Apple Music playlist URL/ID or local .txt/.csv path."),
    ] = None,
    profile_ref: Annotated[
        str | None,
        typer.Option("--profile", help="Saved profile ID, name, or source key to use without rereading a playlist."),
    ] = None,
    reuse_profile: Annotated[
        bool,
        typer.Option("--reuse-profile", help="Use the saved profile for this playlist if it exists."),
    ] = False,
    months: Annotated[int, typer.Option("--months", "-m", min=1, help="Release lookback window in months.")] = 6,
    max_tracks: Annotated[int, typer.Option("--max-tracks", "-t", help="Max tracks per release; 0 means unlimited (all tracks in original release order).")] = 3,
    output: Annotated[str, typer.Option("--output", "-o", help="Output format: txt, csv, json.")] = "txt",
    output_path: Annotated[Path | None, typer.Option("--output-path", help="Where to write the output file.")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Maximum number of release recommendations.")] = 40,
    max_candidates: Annotated[
        int,
        typer.Option(
            "--max-candidates",
            min=0,
            help="Limit candidate artists for expensive runs; 0 means unlimited and seed artists are always kept.",
        ),
    ] = 0,
    min_seed_weight: Annotated[
        float,
        typer.Option(
            "--min-seed-weight",
            min=0.0,
            max=1.0,
            help="Minimum normalized seed weight required for Tier 1 membership (0.0-1.0).",
        ),
    ] = 0.20,
    discovery_mode: Annotated[
        str,
        typer.Option(
            "--discovery-mode",
            help="Discovery mode: balanced (default), top_first, deep_cuts, deep_diverse; standard is accepted as top_first",
        ),
    ] = "balanced",
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview recommendations without exporting, marking heard, or creating playlists."),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Show debug output (provider warnings and pipeline diagnostics).")] = False,
    global_memory: Annotated[
        bool,
        typer.Option(
            "--global-memory/--no-global-memory",
            help="Exclude tracks remembered from every saved profile, not only the active source profile.",
        ),
    ] = True,
    create_spotify_playlist: Annotated[
        bool,
        typer.Option("--create-spotify-playlist", help="Also create a private Spotify playlist from resolved tracks."),
    ] = False,
    create_tidal_playlist: Annotated[
        bool,
        typer.Option("--create-tidal-playlist", help="Also create a private Tidal playlist from resolved tracks."),
    ] = False,
    create_apple_playlist: Annotated[
        bool,
        typer.Option("--create-apple-playlist", help="Also create an Apple Music library playlist from resolved tracks."),
    ] = False,
    force_refresh: Annotated[
        bool,
        typer.Option("--force-refresh", help="Bypass provider cache reads for this run and refresh cached data."),
    ] = False,
    spotify_playlist_name: Annotated[
        str | None,
        typer.Option("--spotify-playlist-name", help="Name for the created Spotify playlist."),
    ] = None,
    tidal_playlist_name: Annotated[
        str | None,
        typer.Option("--tidal-playlist-name", help="Name for the created Tidal playlist."),
    ] = None,
    apple_playlist_name: Annotated[
        str | None,
        typer.Option("--apple-playlist-name", help="Name for the created Apple Music playlist."),
    ] = None,
    apple_target_playlist: Annotated[
        str | None,
        typer.Option("--apple-target-playlist", help="Existing Apple Music library playlist ID to append tracks to."),
    ] = None,
    save_selection_logic: Annotated[
        bool,
        typer.Option("--save-selection-logic", help="Write a local sidecar explaining why each release was selected (Markdown by default)."),
    ] = False,
    selection_logic_path: Annotated[
        Path | None,
        typer.Option("--selection-logic-path", help="Where to write the selection logic sidecar (.md for Markdown, .json for JSON)."),
    ] = None,
    penalize_frequent_artists: Annotated[
        bool,
        typer.Option("--penalize-frequent-artists", help="Reduce tracks per release for artists with many recent EPs/singles."),
    ] = False,
    shuffle_releases: Annotated[
        bool,
        typer.Option("--shuffle-releases", help="Shuffle whole release recommendations after v2 scoring."),
    ] = False,
) -> None:
    options = DiscoverOptions(
        playlist=playlist,
        profile_ref=profile_ref,
        reuse_profile=reuse_profile,
        months=months,
        max_tracks=max_tracks,
        output=output,
        output_path=output_path,
        limit=limit,
        max_candidates=max_candidates,
        min_seed_weight=min_seed_weight,
        discovery_mode=discovery_mode,
        dry_run=dry_run,
        verbose=verbose,
        global_memory=global_memory,
        create_spotify_playlist=create_spotify_playlist,
        create_tidal_playlist=create_tidal_playlist,
        create_apple_playlist=create_apple_playlist,
        force_refresh=force_refresh,
        spotify_playlist_name=spotify_playlist_name,
        tidal_playlist_name=tidal_playlist_name,
        apple_playlist_name=apple_playlist_name,
        apple_target_playlist=apple_target_playlist,
        save_selection_logic=save_selection_logic,
        selection_logic_path=selection_logic_path,
        penalize_frequent_artists=penalize_frequent_artists,
        shuffle_releases=shuffle_releases,
    )
    try:
        run_discover(options, emit=typer.echo, emit_error=lambda message: typer.echo(message, err=True))
    except KeyboardInterrupt:
        typer.echo("Canceled.", err=True)
        raise typer.Exit(130) from None
    except WorkflowAbort as exc:
        raise typer.Exit(_error(exc.message)) from exc


@app.command()
def diagnose(
    playlist: Annotated[str | None, typer.Option("--playlist", "-p", help="Optional playlist or text file to check.")] = None,
) -> None:
    settings, storage = _boot()
    try:
        tidal = TidalProvider(settings)
        typer.echo("Mamonia diagnosis")
        managed_env = settings.data_dir / ".env"
        cwd_env = Path(".env").absolute()
        legacy_fallback = os.getenv("MAMONIA_LEGACY_CWD_ENV_FALLBACK", "false").lower() == "true"
        typer.echo(f"Managed state root: {settings.data_dir}")
        typer.echo(f"Managed env source: {managed_env}")
        typer.echo(f"Managed .env: {managed_env} ({'OK' if managed_env.exists() else 'missing'})")
        typer.echo(f"CWD .env: {cwd_env} ({'OK' if cwd_env.exists() else 'missing'})")
        typer.echo(f"SQLite: {settings.db_path}")
        typer.echo(
            "Overrides: "
            f"MAMONIA_HOME={'set' if os.getenv('MAMONIA_HOME') else 'unset'}, "
            f"MAMONIA_DB={'set' if os.getenv('MAMONIA_DB') else 'unset'}, "
            f"MAMONIA_LEGACY_CWD_ENV_FALLBACK={'on' if legacy_fallback else 'off'}"
        )
        previous_db = get_last_active_db_path(settings.data_dir)
        typer.echo(f"Previous active DB: {previous_db if previous_db else 'none'}")
        credential_paths = {
            "managed .env": managed_env,
            "cwd .env": cwd_env,
            "Spotify read token cache": settings.data_dir / ".spotipy_token_cache_playlist_read_private_playlist_read_collaborative",
            "Spotify write token cache": settings.data_dir / ".spotipy_token_cache_playlist_modify_private",
            "Tidal session": settings.data_dir / "tidal_session.json",
        }
        typer.echo(
            "Credential file permissions: "
            + ", ".join(f"{label} {credential_file_permission_status(path)}" for label, path in credential_paths.items())
        )
        counts = storage.diagnostic_counts()
        typer.echo(f"SQLite quick check: {counts['quick_check']}")
        typer.echo(f"SQLite schema version: {counts['schema_version']}")
        typer.echo(
            "Local state: "
            f"{counts['taste_profiles']} profile(s), "
            f"{counts['heard_releases']} heard release(s), "
            f"{counts['api_cache_entries']} cache entr{'y' if counts['api_cache_entries'] == 1 else 'ies'}, "
            f"{counts['artist_enrichment_entries']} artist enrichment row(s), "
            f"{counts['track_enrichment_entries']} track enrichment row(s), "
            f"{counts['recommendation_runs']} recorded run(s)"
        )
        typer.echo(
            "Cache TTLs: "
            f"Spotify {settings.spotify_cache_ttl_seconds // 86400}d, "
            f"MusicBrainz {settings.musicbrainz_cache_ttl_seconds // 86400}d, "
            f"Last.fm {settings.lastfm_cache_ttl_seconds // 86400}d, "
            f"Deezer {settings.deezer_cache_ttl_seconds // 86400}d"
        )
        cache_stats = storage.cache_diagnostics()
        typer.echo(
            "Cache stats: "
            + ", ".join(
                f"{label} {stats.get('entries', 0)} entr{'y' if stats.get('entries', 0) == 1 else 'ies'}, "
                f"{stats.get('hits', 0)} hit(s), {stats.get('misses', 0)} miss(es)"
                for label, stats in (
                    ("Spotify", cache_stats.get("spotify", {})),
                    ("MusicBrainz", cache_stats.get("musicbrainz", {})),
                    ("Last.fm", cache_stats.get("lastfm", {})),
                    ("Deezer", cache_stats.get("deezer", {})),
                )
            )
        )
        typer.echo(f"Spotify credentials: {'OK' if settings.spotify_configured else 'missing'}")
        typer.echo(
            "Optimization status: "
            f"force_refresh={'active' if settings.force_refresh else 'inactive'}, "
            f"spotify_enrichment_budget={'active' if settings.spotify_enrichment_budget_per_run > 0 else 'inactive'}"
            f"({settings.spotify_enrichment_budget_per_run}), "
            f"spotify_disable_rescue_after_429={'active' if settings.spotify_disable_rescue_after_429 else 'inactive'}"
        )
        typer.echo(f"Spotify provider: {'ready for playlist I/O' if settings.spotify_configured else 'not configured'}")
        typer.echo(f"Spotify callback: {settings.spotify_redirect_uri}")
        typer.echo(f"Last.fm API key: {'OK' if settings.lastfm_configured else 'missing'}")
        typer.echo(f"Last.fm provider: {'ready for enrichment' if settings.lastfm_configured else 'optional; disabled'}")
        typer.echo("Deezer provider: ready for metadata backup enrichment")
        mb_status = "warning: placeholder" if settings.mb_contact_is_placeholder else "OK"
        typer.echo(f"MusicBrainz contact: {mb_status}")
        typer.echo("MusicBrainz provider: ready for metadata lookup")
        typer.echo(f"Tidal credentials: {'OK' if settings.tidal_configured else 'missing'}")
        if not settings.tidal_configured:
            typer.echo("Tidal session not checked")
        tidal_summary = tidal.diagnostic_summary()
        typer.echo(f"Tidal provider: {tidal_summary['provider_status']}")
        typer.echo(f"Apple Music credentials: {'OK' if settings.apple_music_configured else 'missing'}")
        typer.echo(
            "Apple Music provider: "
            + (
                "ready for playlist import/export"
                if settings.apple_music_configured
                else "not configured; set APPLE_MUSIC_DEVELOPER_TOKEN and APPLE_MUSIC_USER_TOKEN"
            )
        )
        typer.echo(f"Tidal auth flow: {tidal_summary['auth_flow']}")
        typer.echo(f"Tidal native playlist creation: {tidal_summary['native_playlist_creation']}")

        if playlist:
            spotify = SpotifyProvider(settings)
            source_path = Path(playlist).expanduser()
            if source_path.exists():
                tracks = parse_text_file(source_path)
                typer.echo(f"Input file: OK ({len(tracks)} parsed track(s))")
            elif looks_like_spotify_playlist(playlist):
                if not spotify.available:
                    typer.echo("Spotify playlist: missing credentials")
                else:
                    try:
                        total = spotify.check_playlist_access(playlist)
                    except ProviderRateLimit as exc:
                        typer.echo(f"Spotify playlist: rate-limited ({_provider_rate_limit_message(exc)})")
                    except Exception as exc:
                        typer.echo(f"Spotify playlist: unavailable ({_safe_error(exc)})")
                    else:
                        label = f"{total} item(s)" if total is not None else "accessible"
                        typer.echo(f"Spotify playlist: OK ({label})")
            elif looks_like_tidal_playlist(playlist):
                if not tidal.available:
                    typer.echo("Tidal playlist: missing credentials or tidalapi not installed")
                else:
                    try:
                        total = tidal.check_playlist_access(playlist)
                    except ProviderRateLimit as exc:
                        typer.echo(f"Tidal playlist: rate-limited ({_provider_rate_limit_message(exc)})")
                    except Exception as exc:
                        typer.echo(f"Tidal playlist: unavailable ({_safe_error(exc)})")
                    else:
                        label = f"{total} item(s)" if total is not None else "accessible"
                        typer.echo(f"Tidal playlist: OK ({label})")
            else:
                typer.echo("Playlist/input: not an existing file or Spotify/Tidal playlist")
    finally:
        storage.close()


@heard_app.command("list")
def heard_list() -> None:
    _, storage = _boot()
    try:
        grouped = storage.list_heard_grouped()
        if not grouped:
            typer.echo("Heard list is empty.")
            return
        for session_group in grouped:
            profile_name = session_group.get("profile_name", "Unknown")
            typer.echo(f"{profile_name}")
            input_releases = session_group.get("input_releases", [])
            if input_releases:
                typer.echo("  Input Releases:")
                for entry in input_releases:
                    date = f" ({entry['release_date']})" if entry.get("release_date") else ""
                    typer.echo(f"    {entry['id']:4}. {entry['artist']} - {entry['title']}{date}")
            output_releases = session_group.get("output_releases", [])
            if output_releases:
                typer.echo("  Output Releases:")
                for entry in output_releases:
                    date = f" ({entry['release_date']})" if entry.get("release_date") else ""
                    typer.echo(f"    {entry['id']:4}. {entry['artist']} - {entry['title']}{date}")
            typer.echo()
    finally:
        storage.close()


@heard_app.command("add")
def heard_add(
    artist: Annotated[str, typer.Option("--artist", "-a")],
    release: Annotated[str, typer.Option("--release", "-r")],
    release_date: Annotated[str | None, typer.Option("--release-date")] = None,
    mb_release_group_id: Annotated[str | None, typer.Option("--mb-release-group-id")] = None,
    spotify_album_id: Annotated[str | None, typer.Option("--spotify-album-id")] = None,
) -> None:
    _, storage = _boot()
    try:
        entry_id = storage.add_heard(
            artist=artist,
            title=release,
            release_date=release_date,
            mb_release_group_id=mb_release_group_id,
            spotify_album_id=spotify_album_id,
        )
        typer.echo(f"Marked heard #{entry_id}: {artist} - {release}")
    finally:
        storage.close()


@heard_app.command("remove")
def heard_remove(entry_id: Annotated[int, typer.Option("--id", help="Heard-list entry ID.")]) -> None:
    _, storage = _boot_destructive()
    try:
        if storage.remove_heard(entry_id):
            typer.echo(f"Removed heard-list entry #{entry_id} from {storage.db_path}.")
        else:
            raise typer.Exit(_error(f"No heard-list entry found with id {entry_id}."))
    finally:
        storage.close()


@heard_app.command("export-json")
def heard_export_json(path: Annotated[Path, typer.Option("--path", help="Destination JSON path.")]) -> None:
    _, storage = _boot()
    try:
        storage.export_heard_json(path)
        typer.echo(f"Exported heard list to {path}")
    finally:
        storage.close()


@heard_app.command("import-json")
def heard_import_json(path: Annotated[Path, typer.Option("--path", help="Source JSON path.")]) -> None:
    _, storage = _boot()
    try:
        count = storage.import_heard_json(path)
        typer.echo(f"Imported {count} heard-list entr{'y' if count == 1 else 'ies'}.")
    finally:
        storage.close()


@cache_app.command("clear")
def cache_clear() -> None:
    _, storage = _boot_destructive()
    try:
        count = storage.clear_cache()
        typer.echo(f"Cleared {count} cached response(s) from {storage.db_path}.")
    finally:
        storage.close()


@profile_app.command("export")
def profile_export(
    path: Annotated[Path | None, typer.Option("--path", help="Destination path. Defaults to stdout.")] = None,
    profile_ref: Annotated[
        str | None,
        typer.Option("--profile", help="Saved profile ID, name, or source key. Defaults to latest profile JSON."),
    ] = None,
) -> None:
    settings, storage = _boot()
    try:
        if profile_ref:
            profile_record = storage.get_taste_profile(profile_ref)
            if not profile_record:
                raise typer.Exit(_error(f"No saved profile found for {profile_ref!r}."))
            payload = json.dumps(json.loads(profile_record["profile_json"]), indent=2, ensure_ascii=False)
            label = f"profile #{profile_record['id']}"
        else:
            latest = settings.data_dir / "last_profile.json"
            if not latest.exists():
                raise typer.Exit(_error("No saved profile found yet. Run `mamonia discover` first."))
            payload = latest.read_text(encoding="utf-8")
            label = "latest profile"
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(payload, encoding="utf-8")
            typer.echo(f"Exported {label} to {path}")
        else:
            typer.echo(payload)
    finally:
        storage.close()


@profile_app.command("list")
def profile_list() -> None:
    _, storage = _boot()
    try:
        profiles = storage.list_taste_profiles()
        if not profiles:
            typer.echo("No saved taste profiles yet.")
            return
        for item in profiles:
            typer.echo(profile_summary_line(storage, item))
    finally:
        storage.close()


@profile_app.command("show")
def profile_show(profile_ref: Annotated[str, typer.Argument(help="Profile ID, name, or source key.")]) -> None:
    _, storage = _boot()
    try:
        profile_record = storage.get_taste_profile(profile_ref)
        if not profile_record:
            raise typer.Exit(_error(f"No saved profile found for {profile_ref!r}."))
        profile, seed_tracks, _ = _profile_from_record(profile_record)
        typer.echo("")
        typer.echo(f"Profile #{profile_record['id']}: {profile_record['name']}")
        typer.echo("")
        source_name = str(profile_record["source_type"]).replace("_", " ").title()
        typer.echo(_format_profile_two_col("Source:", source_name, f"ID: {profile_record['source_ref']}"))
        typer.echo(_format_profile_two_col("# of artists and tracks:", str(profile_record["artist_count"]), str(profile_record["track_count"])))
        completeness = storage.enrichment_completeness(artists=profile.artists, tracks=seed_tracks)
        artist_part = f"{completeness.artist_enriched}/{completeness.artist_total}"
        track_part = f"{completeness.track_enriched}/{completeness.track_total}"
        typer.echo(_format_profile_two_col("Enrichment:", artist_part, track_part))
        updated_time, updated_date = _format_profile_updated_at_parts(profile_record["updated_at"])
        typer.echo(_format_profile_two_col("Last updated:", updated_time, updated_date))
        typer.echo("")
        typer.echo("Top artists:")
        for artist in profile.top_artists[:10]:
            typer.echo(f"  - {artist.name} ({artist.playlist_count} tracks, score {artist.affinity_score:g})")
    finally:
        storage.close()

@profile_app.command("refresh")
def profile_refresh(
    playlist: Annotated[str, typer.Option("--playlist", "-p", help="Spotify/Tidal playlist URL/ID or local .txt/.csv path.")],
) -> None:
    settings, storage = _boot()
    spotify = SpotifyProvider(settings, storage)
    tidal = TidalProvider(settings)
    apple_music = AppleMusicProvider(settings)
    try:
        tracks = _load_playlist_tracks(playlist, spotify, tidal, apple_music)
        if not tracks:
            raise typer.Exit(_error("No input tracks found."))
        source = source_identity_from_tracks(playlist, tracks)
        source = enrich_source_name(source, playlist, spotify, tidal, apple_music)
        profile = build_taste_profile(
            tracks,
            spotify=spotify if spotify.available else None,
            musicbrainz=MusicBrainzProvider(settings, storage),
            lastfm=LastFMProvider(settings, storage),
            spotify_artist_metadata=spotify.artist_metadata_from_tracks(tracks) if spotify.available else {},
        )
        _print_provider_warnings([spotify, MusicBrainzProvider(settings, storage), LastFMProvider(settings, storage)])
        profile_record = storage.upsert_taste_profile(
            name=source["name"],
            source_type=source["source_type"],
            source_ref=source["source_ref"],
            source_key=source["source_key"],
            source_hash=source["source_hash"],
            track_count=len(tracks),
            artist_count=profile.n_artists,
            profile=profile,
            seed_tracks=tracks,
            seed_track_keys=track_keys_from_input(tracks),
        )
        _save_latest_profile(settings.data_dir / "last_profile.json", profile.model_dump(mode="json"))
        typer.echo(
            f"Refreshed profile #{profile_record['id']} {profile_record['name']} "
            f"with {profile_record['track_count']} tracks and {profile_record['artist_count']} artists."
        )
    finally:
        storage.close()


@profile_app.command("delete")
def profile_delete(profile_ref: Annotated[str, typer.Argument(help="Profile ID, name, or source key.")]) -> None:
    _, storage = _boot_destructive()
    try:
        if storage.delete_taste_profile(profile_ref):
            typer.echo(f"Deleted profile {profile_ref} from {storage.db_path}.")
        else:
            raise typer.Exit(_error(f"No saved profile found for {profile_ref!r}."))
    finally:
        storage.close()


@app.command("migrate-state-to-managed")
def migrate_state_to_managed_command(
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview migration without writing files.")] = False,
    force: Annotated[bool, typer.Option("--force", help="Allow replacing managed DB when managed is empty.")] = False,
) -> None:
    settings = load_settings()
    report = migrate_state_to_managed(settings=settings, cwd=Path.cwd(), dry_run=dry_run, force=force)
    typer.echo("State migration report:")
    typer.echo(json.dumps(report, indent=2, ensure_ascii=False))
    copied = report.get("copied_files", [])
    warnings = report.get("warnings", [])
    typer.echo(
        f"Summary: {len(copied)} file action(s), {len(warnings)} warning(s), "
        f"merge rows={report.get('merge_summary', {})}"
    )


@db_app.command("health")
def db_health() -> None:
    settings, storage = _boot()
    try:
        report = storage.health_report()
        typer.echo(f"Active DB path: {settings.db_path}")
        typer.echo(json.dumps(report, indent=2, ensure_ascii=False))
    finally:
        storage.close()


@db_app.command("backup")
def db_backup(
    output: Annotated[Path | None, typer.Option("--output", help="Path to write the SQLite backup file.")] = None,
) -> None:
    settings, storage = _boot()
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = output or (settings.data_dir / "backups" / f"mamonia_{timestamp}.sqlite")
        target.parent.mkdir(parents=True, exist_ok=True)
        storage.backup_to(target)
        typer.echo(f"Backup created: {target}")
    finally:
        storage.close()


@db_app.command("vacuum")
def db_vacuum() -> None:
    _, storage = _boot()
    try:
        storage.vacuum()
        typer.echo("VACUUM completed.")
    finally:
        storage.close()


@db_app.command("diagnostics-bundle")
def db_diagnostics_bundle(
    output: Annotated[Path | None, typer.Option("--output", help="Path to write diagnostics JSON.")] = None,
) -> None:
    settings, storage = _boot()
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = output or (settings.data_dir / "diagnostics" / f"db_diagnostics_{timestamp}.json")
        target.parent.mkdir(parents=True, exist_ok=True)
        bundle = {
            "generated_at": datetime.now().isoformat(),
            "active_db_path": str(settings.db_path),
            "managed_data_dir": str(settings.data_dir),
            "overrides": {
                "MAMONIA_HOME": bool(os.getenv("MAMONIA_HOME")),
                "MAMONIA_DB": bool(os.getenv("MAMONIA_DB")),
                "MAMONIA_DB_ENGINE": os.getenv("MAMONIA_DB_ENGINE", "v1"),
                "MAMONIA_LEGACY_CWD_ENV_FALLBACK": os.getenv("MAMONIA_LEGACY_CWD_ENV_FALLBACK", "false"),
            },
            "previous_active_db": str(get_last_active_db_path(settings.data_dir) or ""),
            "health": storage.health_report(),
            "legacy_cwd_artifacts": [str(p) for p in detect_legacy_cwd_artifacts(Path.cwd()).existing()],
        }
        target.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
        typer.echo(f"Diagnostics bundle written: {target}")
    finally:
        storage.close()


def _boot() -> tuple[object, Storage]:
    settings = load_settings()
    warning = detect_db_path_change(settings)
    if warning:
        typer.echo(warning, err=True)
    legacy = detect_legacy_cwd_artifacts(Path.cwd())
    if legacy.existing():
        typer.echo(
            "Warning: legacy Mamonia files were detected in CWD; managed app state is primary.",
            err=True,
        )
    if os.getenv("MAMONIA_DB_HEALTHCHECK_ON_START", "false").lower() == "true":
        with Storage(settings.db_path) as health_storage:
            status = health_storage.health_report()
            if status.get("integrity_check") != "ok":
                raise typer.Exit(_error("Database integrity check failed. Run `mamonia db backup` and inspect `mamonia db health`."))
    update_last_active_db_path(settings)
    return settings, Storage(settings.db_path)


def _boot_destructive() -> tuple[object, Storage]:
    return _boot()


def _providers(settings: object, storage: Storage) -> tuple[SpotifyProvider, MusicBrainzProvider, LastFMProvider]:
    return SpotifyProvider(settings, storage), MusicBrainzProvider(settings, storage), LastFMProvider(settings, storage)


def _load_playlist_tracks(
    playlist: str,
    spotify: SpotifyProvider,
    tidal: TidalProvider | None = None,
    apple_music: AppleMusicProvider | None = None,
) -> list[InputTrack]:
    source_path = Path(playlist).expanduser()
    if source_path.exists():
        return parse_text_file(source_path)
    if looks_like_spotify_playlist(playlist):
        if not spotify.available:
            raise typer.Exit(
                _error(
                    "Spotify credentials are required for Spotify playlist input. "
                    "Set SPOTIPY_CLIENT_ID and SPOTIPY_CLIENT_SECRET, or use a local .txt playlist."
                )
            )
        try:
            return spotify.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise typer.Exit(_error(_provider_rate_limit_message(exc))) from exc
        except ProviderUnavailable as exc:
            raise typer.Exit(_error(str(exc))) from exc
        except Exception as exc:
            raise typer.Exit(_error(f"Spotify playlist unavailable: {_safe_error(exc)}")) from exc
    if looks_like_tidal_playlist(playlist):
        if tidal is None:
            tidal = TidalProvider(load_settings())
        if not tidal.available:
            raise typer.Exit(
                _error(
                    "Tidal credentials are required for Tidal playlist input. "
                    "Set TIDAL_CLIENT_ID and TIDAL_CLIENT_SECRET, or use a local .txt playlist or TuneMyMusic-style .csv export file."
                )
            )
        try:
            return tidal.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise typer.Exit(_error(_provider_rate_limit_message(exc))) from exc
        except ProviderUnavailable as exc:
            raise typer.Exit(_error(str(exc))) from exc
        except Exception as exc:
            raise typer.Exit(_error(f"Tidal playlist unavailable: {_safe_error(exc)}")) from exc
    if looks_like_apple_music_playlist(playlist):
        if apple_music is None:
            apple_music = AppleMusicProvider(load_settings())
        if not apple_music.available:
            raise typer.Exit(
                _error(
                    "Apple Music credentials are required for Apple Music playlist input. "
                    "Set APPLE_MUSIC_DEVELOPER_TOKEN and APPLE_MUSIC_USER_TOKEN, or use a local .txt playlist."
                )
            )
        try:
            return apple_music.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise typer.Exit(_error(_provider_rate_limit_message(exc))) from exc
        except ProviderUnavailable as exc:
            raise typer.Exit(_error(str(exc))) from exc
        except Exception as exc:
            raise typer.Exit(_error(f"Apple Music playlist unavailable: {_safe_error(exc)}")) from exc
    raise typer.Exit(_error(f"Input is neither an existing text file nor a Spotify/Tidal/Apple Music playlist: {playlist}"))


def _profile_from_record(profile_record: dict) -> tuple[TasteProfile, list[InputTrack], set[str]]:
    profile = TasteProfile.model_validate(json.loads(profile_record["profile_json"]))
    seed_tracks = seed_tracks_from_payload(json.loads(profile_record["seed_tracks_json"]))
    seed_track_keys = set(json.loads(profile_record["seed_track_keys_json"]))
    return profile, seed_tracks, seed_track_keys


def _save_latest_profile(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _print_settings_warnings(settings: object) -> None:
    warnings = getattr(settings, "warnings", lambda: [])()
    for warning in warnings:
        typer.echo(f"Warning: {warning}", err=True)


def _print_provider_warnings(providers: list[object], verbose: bool = False) -> None:
    seen: set[tuple[str, str]] = set()
    for provider in providers:
        for warning in getattr(provider, "rate_limit_warnings", []):
            key = (warning.provider, warning.operation)
            if key in seen:
                continue
            seen.add(key)
            message = _provider_rate_limit_message(warning)
            guidance_text = ""
            issue_guidance = getattr(provider, "issue_guidance", None)
            if callable(issue_guidance):
                guidance_text = issue_guidance(warning)
            elif warning.is_permission_error:
                guidance = getattr(provider, "permission_guidance", None)
                if callable(guidance):
                    guidance_text = guidance(warning.operation)
            if guidance_text:
                message = f"{message} {guidance_text}"
            if not verbose and warning.retry_after_seconds is not None:
                message = f"{warning.provider} rate limit while {warning.operation}; skipping provider where possible."
            typer.echo(f"Warning: {message}", err=True)


def _provider_rate_limit_message(exc: ProviderRateLimit) -> str:
    message = str(exc)
    if exc.retry_after_seconds is not None and not exc.should_auto_wait:
        message += " Mamonia will not wait automatically for a long retry window."
    if exc.provider == "Spotify" and "playlist" in exc.operation:
        message += " Try later, or use --reuse-profile/--profile if a saved profile already exists."
    if exc.action == "RECONNECT_SPOTIFY":
        message += " Run: mamonia spotify-auth"
    elif exc.action == "CONNECT_SPOTIFY":
        message += " Run: mamonia spotify-auth"
    return message


def _safe_error(exc: Exception) -> str:
    return str(exc).splitlines()[0][:160]


def _abort_with_storage_close(storage: Storage, message: str) -> None:
    storage.close()
    raise typer.Exit(_error(message))


def _error(message: str) -> int:
    typer.echo(f"Error: {message}", err=True)
    return 1


def _format_profile_updated_at_parts(value: str | None) -> tuple[str, str]:
    if not value:
        return ("unknown", "unknown")
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return (str(value), "")
    return (parsed.strftime("%H:%M"), parsed.strftime("%d-%m-%Y"))


def _format_profile_two_col(label: str, left_value: str, right_value: str) -> str:
    return f"{label:<29}{left_value:>10}     |        {right_value}"


@app.command(name="spotify-playlists")
def list_spotify_playlists() -> None:
    """List your Spotify playlists with IDs for use with --playlist."""
    settings = load_settings()
    spotify = SpotifyProvider(settings)
    try:
        playlists = spotify.fetch_user_playlists()
    except ProviderUnavailable as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc
    except ProviderRateLimit as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc
    if not playlists:
        typer.echo("No playlists found.")
        return
    for p in playlists:
        typer.echo(f"{p.id}\t{p.tracks}\t{p.name}")


@app.command(name="tidal-playlists")
def list_tidal_playlists() -> None:
    """List your Tidal playlists with IDs for use with --playlist."""
    settings = load_settings()
    tidal = TidalProvider(settings)
    try:
        playlists = tidal.fetch_user_playlists()
    except ProviderUnavailable as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc
    except ProviderRateLimit as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc
    if not playlists:
        typer.echo("No playlists found.")
        return
    for p in playlists:
        tracks = "?" if p.tracks is None else str(p.tracks)
        typer.echo(f"{p.id}\t{tracks}\t{p.name}")


@app.command(name="tidal-smoke")
def tidal_smoke(
    playlist: Annotated[
        str | None,
        typer.Option("--playlist", "-p", help="Optional Tidal playlist URL/ID to verify read access."),
    ] = None,
    isrc: Annotated[
        str | None,
        typer.Option("--isrc", help="Optional ISRC to verify Tidal catalog lookup."),
    ] = None,
    track_id: Annotated[
        str | None,
        typer.Option("--track-id", help="Optional Tidal track ID to use for explicit playlist creation smoke."),
    ] = None,
    create_playlist_name: Annotated[
        str | None,
        typer.Option(
            "--create-playlist-name",
            help="Explicitly create a Tidal playlist with this name. No playlist is created unless this is set.",
        ),
    ] = None,
) -> None:
    """Run a focused Tidal integration smoke check."""
    settings = load_settings()
    tidal = TidalProvider(settings)
    typer.echo("Tidal smoke check")
    typer.echo(f"Credentials: {'OK' if settings.tidal_configured else 'missing'}")
    summary = tidal.diagnostic_summary()
    typer.echo(f"Provider: {summary['provider_status']}")
    typer.echo(f"Auth flow: {summary['auth_flow']}")
    typer.echo(f"Native playlist creation: {summary['native_playlist_creation']}")

    if not settings.tidal_configured:
        raise typer.Exit(_error("Set TIDAL_CLIENT_ID and TIDAL_CLIENT_SECRET before running the Tidal smoke check."))
    if not tidal.available:
        raise typer.Exit(_error("tidalapi is not installed. Install with: pip install -e '.[tidal]'"))

    try:
        session_ok = tidal.ensure_session()
    except ProviderUnavailable as exc:
        raise typer.Exit(_error(str(exc))) from exc
    typer.echo(f"Session: {'OK' if session_ok else 'failed'}")
    if not session_ok:
        raise typer.Exit(1)

    try:
        playlists = tidal.fetch_user_playlists()
    except Exception as exc:
        typer.echo(f"User playlists: unavailable ({_safe_error(exc)})")
        playlists = []
    else:
        typer.echo(f"User playlists: OK ({len(playlists)} found)")

    if playlist:
        try:
            total = tidal.check_playlist_access(playlist)
        except Exception as exc:
            typer.echo(f"Playlist read: unavailable ({_safe_error(exc)})")
        else:
            label = f"{total} item(s)" if total is not None else "accessible"
            typer.echo(f"Playlist read: OK ({label})")

    match_track_id: str | None = track_id
    if track_id:
        typer.echo(f"Track ID: using provided Tidal track ID {track_id}")
    if isrc:
        match = tidal.lookup_track_by_isrc(isrc)
        if match:
            match_track_id = match.track_id
            typer.echo(f"ISRC lookup: OK (track {match.track_id})")
        else:
            typer.echo("ISRC lookup: no match")

    if create_playlist_name:
        track_ids = [match_track_id] if match_track_id else []
        result = tidal.create_playlist(create_playlist_name, "Generated by Mamonia Tidal smoke check.", track_ids)
        if result.created:
            typer.echo(f"Playlist create: OK ({result.url or 'URL unavailable'})")
        elif result.reason == "no_ids":
            typer.echo("Playlist create: skipped because neither --track-id nor a resolved --isrc supplied a Tidal track ID.")
        else:
            typer.echo(f"Playlist create: failed ({result.reason or 'unknown error'})")
