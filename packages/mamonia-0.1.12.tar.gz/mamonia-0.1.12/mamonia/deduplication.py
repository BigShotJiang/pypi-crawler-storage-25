"""
Track-level deduplication for ReleaseRecommendation lists.

Removes duplicate tracks that appear across multiple recommendations.
Three passes:
  1. ISRC exact match
  2. Spotify track ID exact match
  3. Fuzzy title+artist+album similarity
       - auto-remove at >= 75%
       - interactive review at 50–74%

In every auto pass: keep the track with more non-None fields, fill any empty
fields on the winner from the loser, then remove the loser. Interactive pairs
are presented to the user as "Keep 1 / Keep 2 / Keep both".
"""

from __future__ import annotations

import re
import sys
from typing import Any

from rapidfuzz import fuzz

from .models import ReleaseRecommendation, ReleaseTrack

_AUTO_THRESHOLD = 75
_REVIEW_MIN = 50
_REVIEW_MAX = 74

_ACCENT = "#ff5a5a"
_QMARK_COLOR = "#6b7280"

_QUESTIONARY_AVAILABLE = False
try:
    import questionary  # type: ignore[import-untyped]
    _QUESTIONARY_AVAILABLE = True
except Exception:
    pass

# Fields eligible for merge (title/artists are always present; skip them)
_MERGE_FIELDS = (
    "spotify_track_id",
    "spotify_uri",
    "isrc",
    "isrc_source",
    "track_number",
    "resolution_source",
    "resolution_note",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_STOPWORDS = {"the", "a", "an", "in", "on", "at", "to", "for", "of", "with", "by", "from", "up", "down", "out", "over", "into"}
_MIN_TITLE_SIM_REVIEW = 70.0
_MIN_ARTIST_SIM_REVIEW = 45.0
_MIN_SINGLE_FIELD_SIM_REVIEW = 85.0
_MIN_TITLE_SIM_AUTO = 75.0
_MIN_ARTIST_SIM_AUTO = 60.0
_MIN_TITLE_SIM_REVIEW_ALT = 40.0
_MIN_ARTIST_SIM_REVIEW_ALT = 55.0
_MIN_ALBUM_SIM_REVIEW_ALT = 90.0
_STRICT_MATCH_ARTIST_MIN = 90.0
_STRICT_MATCH_ALBUM_MIN = 90.0
_STRICT_MATCH_TITLE_REVIEW_MIN = 70.0

def _normalize(text: str | None) -> str:
    if not isinstance(text, str) or not text:
        return ""
    return re.sub(r"\s+", " ", text.lower().strip())


def _remove_stopwords(text: str) -> str:
    """Remove common stopwords from text for more meaningful similarity comparison."""
    words = text.split()
    return " ".join(w for w in words if w not in _STOPWORDS)


_TITLE_VARIANT_WORDS = {
    "acoustic", "instrumental", "cinematic", "live", "radio", "edit", "mix",
    "remix", "remaster", "remastered", "version", "mono", "stereo",
    "explicit", "clean", "extended", "deluxe", "anniversary", "demo",
    "alt", "alternate", "original", "motion", "picture", "soundtrack", "ost",
    "session", "sessions", "take", "bonus", "karaoke", "reprise", "intro", "outro",
    "official", "video", "audio", "lyrics", "lyric", "visualizer", "hq", "hd", "4k", "1080p", "720p",
    "unplugged",
}

_ARTIST_SPLIT_RE = re.compile(
    r"\s*(?:,|&|\+|/|;|\bx\b|\bfeat\.?\b|\bft\.?\b|\bfeaturing\b)\s*",
    flags=re.IGNORECASE,
)


def _normalize_title_for_similarity(text: str | None) -> str:
    """Normalize titles while removing common variant suffix noise."""
    base = _normalize(text)
    if not base:
        return ""
    base = re.sub(r"\([^)]*\)", " ", base)
    base = re.sub(r"\[[^\]]*\]", " ", base)
    words = [w for w in base.split() if w not in _TITLE_VARIANT_WORDS]
    return " ".join(words)


def _canonical_title_key(text: str | None) -> str:
    """Stable key for exact-ish matching across minor punctuation/case variants."""
    base = _normalize_title_for_similarity(text)
    if not base:
        return ""
    base = re.sub(r"[^a-z0-9\s]", " ", base)
    base = re.sub(r"\s+", " ", base).strip()
    return base


def _extract_artist_names(artists: str | None) -> list[str]:
    raw = _normalize(artists)
    if not raw:
        return []
    parts = [p.strip() for p in _ARTIST_SPLIT_RE.split(raw) if p.strip()]
    out: list[str] = []
    seen: set[str] = set()
    for p in parts:
        p = re.sub(r"\s+", " ", p).strip()
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def _canonical_artist_key(artists: str | None) -> str:
    names = _extract_artist_names(artists)
    if not names:
        return _normalize(artists)
    uniq_sorted = sorted(set(names))
    return " | ".join(uniq_sorted)


def _artist_similarity(a1: str | None, a2: str | None) -> float:
    left = _normalize(a1)
    right = _normalize(a2)
    if not left or not right:
        return 0.0
    raw = float(fuzz.ratio(left, right))
    names1 = _extract_artist_names(a1)
    names2 = _extract_artist_names(a2)
    if not names1 or not names2:
        return raw

    overlap = set(names1) & set(names2)
    token_based = float(fuzz.token_set_ratio(" ".join(names1), " ".join(names2)))

    if overlap:
        # Shared explicit artist name should count as high similarity.
        return max(raw, token_based, 90.0)
    return max(raw, token_based)


def _safe_ratio(left: str, right: str) -> float:
    if not left or not right:
        return 0.0
    return float(fuzz.ratio(left, right))


def _non_null_count(track: ReleaseTrack) -> int:
    return sum(1 for f in ReleaseTrack.model_fields if getattr(track, f) is not None)


def _canonical_isrc(isrc: str | None) -> str:
    """Normalize ISRC for strict equality checks across source formatting differences."""
    raw = _normalize(isrc)
    if not raw:
        return ""
    return re.sub(r"[^a-z0-9]", "", raw).upper()


def _merge_into(keep: ReleaseTrack, discard: ReleaseTrack) -> None:
    """Copy non-None fields from discard into keep where keep has None."""
    for field in _MERGE_FIELDS:
        if getattr(keep, field) is None and getattr(discard, field) is not None:
            setattr(keep, field, getattr(discard, field))
    if discard.popularity > keep.popularity:
        keep.popularity = discard.popularity


def _track_similarity(t1: ReleaseTrack, t2: ReleaseTrack) -> float:
    """Weighted fuzzy similarity: title (3.0) + artists (1.0) + album (1.0). Returns 0–100."""
    title1 = _normalize(t1.title)
    title2 = _normalize(t2.title)
    art1 = _normalize(t1.artists)
    art2 = _normalize(t2.artists)
    album1 = _normalize(getattr(t1, 'album', None) or "")
    album2 = _normalize(getattr(t2, 'album', None) or "")

    sims: list[float] = []
    weights: list[float] = []

    if title1 and title2:
        # Remove stopwords for more meaningful title comparison
        title1_no_sw = _remove_stopwords(title1)
        title2_no_sw = _remove_stopwords(title2)
        sims.append(fuzz.ratio(title1_no_sw, title2_no_sw))
        weights.append(3.0)
    if art1 and art2:
        # Use ratio instead of token_sort_ratio for stricter artist matching
        sims.append(fuzz.ratio(art1, art2))
        weights.append(1.0)
    if album1 and album2:
        # Use token_set_ratio for album comparison, but only if there's actual word overlap
        album1_no_sw = _remove_stopwords(album1)
        album2_no_sw = _remove_stopwords(album2)
        words1 = set(album1_no_sw.split())
        words2 = set(album2_no_sw.split())
        if words1 & words2:  # Check for word overlap
            sims.append(fuzz.token_set_ratio(album1_no_sw, album2_no_sw))
            weights.append(1.0)

    if not sims:
        return 0.0
    return sum(s * w for s, w in zip(sims, weights)) / sum(weights)


def _component_similarity(t1: ReleaseTrack, t2: ReleaseTrack) -> tuple[float, float]:
    """Return per-field similarities: (title_sim, artist_sim)."""
    title1 = _remove_stopwords(_normalize_title_for_similarity(t1.title))
    title2 = _remove_stopwords(_normalize_title_for_similarity(t2.title))
    return _safe_ratio(title1, title2), _artist_similarity(t1.artists, t2.artists)


def _album_similarity(t1: ReleaseTrack, album1: str, t2: ReleaseTrack, album2: str) -> float:
    a1 = _remove_stopwords(_normalize(getattr(t1, "album", None) or album1 or ""))
    a2 = _remove_stopwords(_normalize(getattr(t2, "album", None) or album2 or ""))
    if not a1 or not a2:
        return 0.0
    w1 = set(a1.split())
    w2 = set(a2.split())
    if not (w1 & w2):
        return 0.0
    return float(fuzz.token_set_ratio(a1, a2))


def _passes_plausibility_gate(
    t1: ReleaseTrack,
    album1: str,
    t2: ReleaseTrack,
    album2: str,
    *,
    for_auto: bool,
) -> bool:
    """
    Block absurd fuzzy pairs where title+artist are clearly unrelated.
    """
    title_sim, artist_sim = _component_similarity(t1, t2)
    album_sim = _album_similarity(t1, album1, t2, album2)
    title_present = bool(_normalize(t1.title) and _normalize(t2.title))
    artist_present = bool(_normalize(t1.artists) and _normalize(t2.artists))

    if for_auto and title_present and artist_present:
        return title_sim >= _MIN_TITLE_SIM_AUTO and artist_sim >= _MIN_ARTIST_SIM_AUTO

    if title_present and artist_present:
        # Check if artists actually overlap (share same artist name)
        # If not, require very high title similarity to flag as duplicate
        names1 = _extract_artist_names(t1.artists)
        names2 = _extract_artist_names(t2.artists)
        overlap = set(names1) & set(names2)

        if not overlap:
            # Artists are demonstrably different. Require very high title match.
            return title_sim >= 95.0

        # Extra strict lane: if artist+album are effectively the same entity,
        # rely on title-only similarity to avoid false-positive review spam.
        if artist_sim >= _STRICT_MATCH_ARTIST_MIN and album_sim >= _STRICT_MATCH_ALBUM_MIN:
            return title_sim >= _STRICT_MATCH_TITLE_REVIEW_MIN
        return (
            (title_sim >= _MIN_TITLE_SIM_REVIEW and artist_sim >= _MIN_ARTIST_SIM_REVIEW)
            or (
                title_sim >= _MIN_TITLE_SIM_REVIEW_ALT
                and artist_sim >= _MIN_ARTIST_SIM_REVIEW_ALT
                and album_sim >= _MIN_ALBUM_SIM_REVIEW_ALT
            )
        )

    if title_present:
        return title_sim >= _MIN_SINGLE_FIELD_SIM_REVIEW
    if artist_present:
        return artist_sim >= _MIN_SINGLE_FIELD_SIM_REVIEW
    return False


def _resolve_pair(
    t1: ReleaseTrack,
    t2: ReleaseTrack,
    removed_ids: set[int],
) -> None:
    """Merge-and-remove the weaker of t1/t2 based on non-null field count."""
    if _non_null_count(t1) >= _non_null_count(t2):
        _merge_into(t1, t2)
        removed_ids.add(id(t2))
    else:
        _merge_into(t2, t1)
        removed_ids.add(id(t1))


def _interactive_prompt(
    t1: ReleaseTrack,
    album1: str,
    t2: ReleaseTrack,
    album2: str,
    similarity: float,
    emit: Any = print,
    progress_reporter: Any = None,
) -> str:
    """Present a duplicate pair and return '1', '2', or 'both'."""
    def _label(t: ReleaseTrack, album: str) -> str:
        parts = [f"'{t.title}'", t.artists]
        if album:
            parts.append(album)
        return "  /  ".join(p for p in parts if p)

    emit(f"\n  {_label(t1, album1)}  | vs |  {_label(t2, album2)}  [{similarity:.0f}%]")

    diffs: list[tuple[str, str, str]] = []
    for field, label in [
        ("title", "Title"),
        ("artists", "Artists"),
        ("isrc", "ISRC"),
        ("spotify_uri", "Spotify URI"),
    ]:
        v1 = str(getattr(t1, field) or "—")
        v2 = str(getattr(t2, field) or "—")
        if v1 != v2:
            diffs.append((label, v1, v2))

    if diffs:
        emit("  Differences:")
        for label, v1, v2 in diffs:
            emit(f"    {label}: '{v1}'  vs  '{v2}'")

    if _QUESTIONARY_AVAILABLE:
        style = questionary.Style([
            ("qmark", f"fg:{_QMARK_COLOR}"),
            ("answer", f"fg:{_ACCENT} bold"),
            ("pointer", f"fg:{_ACCENT} bold"),
            ("highlighted", f"fg:{_ACCENT} bold"),
            ("selected", f"fg:{_ACCENT}"),
        ])
        choices = [
            f"Keep 1  ('{t1.title}' / {t1.artists})",
            f"Keep 2  ('{t2.title}' / {t2.artists})",
            "Keep both",
        ]
        while True:
            if progress_reporter is not None:
                progress_reporter.pause()
            try:
                result = questionary.select(
                    "  Which to keep?",
                    choices=choices,
                    style=style,
                    instruction="Choose an option to continue",
                ).ask()
            finally:
                if progress_reporter is not None:
                    progress_reporter.resume()
            if result is None:
                raise RuntimeError("Manual deduplication requires an explicit choice.")
            if result.startswith("Keep 1"):
                return "1"
            if result.startswith("Keep 2"):
                return "2"
            if result == "Keep both":
                return "both"
    else:
        if not (sys.stdin and sys.stdin.isatty()):
            raise RuntimeError(
                "Manual deduplication requires interactive input, but stdin is not a TTY."
            )
        while True:
            try:
                if progress_reporter is not None:
                    progress_reporter.pause()
                answer = input("  Keep which? (1 / 2 / both): ").strip().lower()
            finally:
                if progress_reporter is not None:
                    progress_reporter.resume()
            if answer in ("1",):
                return "1"
            if answer in ("2",):
                return "2"
            if answer == "both":
                return "both"
            emit("  Please type exactly: 1, 2, or both.")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def deduplicate_recommendation_tracks(
    recommendations: list[ReleaseRecommendation],
    auto_threshold: int = _AUTO_THRESHOLD,
    review_min: int = _REVIEW_MIN,
    review_max: int = _REVIEW_MAX,
    emit: Any = None,
    progress_reporter: Any = None,
    debug: bool = False,
) -> list[ReleaseRecommendation]:
    """Remove duplicate tracks that appear across multiple recommendations.

    Modifies track lists in-place on the given recommendations and returns the
    same list. Recommendations with all tracks deduplicated away keep their
    release-level metadata (score, rationale, etc.) and are not removed.

    Args:
        recommendations: List of ReleaseRecommendation objects, sorted by score
            descending (as returned by run_v2_pipeline).
        auto_threshold: Similarity % at or above which a pair is auto-removed.
        review_min: Lower bound of the interactive-review similarity band.
        review_max: Upper bound of the interactive-review similarity band.
        emit: Optional callable for progress messages.
    """
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)

    if not recommendations:
        return recommendations

    # id(track) → album title, for display in interactive prompts
    track_album: dict[int, str] = {
        id(track): rec.title
        for rec in recommendations
        for track in rec.tracks
    }

    removed_ids: set[int] = set()
    auto_removed = 0

    # --- Pass -1: ISRC exact match (authoritative, regardless of source/fuzzy) ---
    isrc_map: dict[str, ReleaseTrack] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if id(track) in removed_ids:
                continue
            key = _canonical_isrc(track.isrc)
            if not key:
                continue
            if key in isrc_map:
                _resolve_pair(isrc_map[key], track, removed_ids)
                if id(isrc_map[key]) in removed_ids:
                    isrc_map[key] = track
                auto_removed += 1
            else:
                isrc_map[key] = track

    # --- Pass 0: Exact title+artist match (obvious duplicates) ---
    # Group by normalized (artist, title) to catch tracks that are identical
    exact_key_map: dict[tuple[str, str], tuple[ReleaseTrack, str]] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if id(track) in removed_ids:
                continue
            # Normalize for exact comparison — use recommendation artist + track title
            artists_norm = _canonical_artist_key(track.artists or rec.artist)
            title_norm = _canonical_title_key(track.title)
            key = (artists_norm, title_norm)
            if key in exact_key_map:
                existing_track, existing_album = exact_key_map[key]
                _resolve_pair(existing_track, track, removed_ids)
                if id(existing_track) in removed_ids:
                    exact_key_map[key] = (track, rec.title)
                auto_removed += 1
            else:
                exact_key_map[key] = (track, rec.title)

    # --- Pass 1: ISRC exact match (defensive second pass) ---
    isrc_map: dict[str, ReleaseTrack] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if id(track) in removed_ids:
                continue
            key = _canonical_isrc(track.isrc)
            if not key:
                continue
            if key in isrc_map:
                _resolve_pair(isrc_map[key], track, removed_ids)
                # If the existing winner was replaced, update the map
                if id(isrc_map[key]) in removed_ids:
                    isrc_map[key] = track
                auto_removed += 1
            else:
                isrc_map[key] = track

    # --- Pass 2: Spotify track ID exact match ---
    spotify_map: dict[str, ReleaseTrack] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if id(track) in removed_ids or not track.spotify_track_id:
                continue
            key = track.spotify_track_id.strip()
            if key in spotify_map:
                _resolve_pair(spotify_map[key], track, removed_ids)
                if id(spotify_map[key]) in removed_ids:
                    spotify_map[key] = track
                auto_removed += 1
            else:
                spotify_map[key] = track

    # --- Pass 2b: Tidal track ID exact match ---
    tidal_map: dict[str, ReleaseTrack] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if id(track) in removed_ids or not track.tidal_track_id:
                continue
            key = track.tidal_track_id.strip()
            if key in tidal_map:
                _resolve_pair(tidal_map[key], track, removed_ids)
                if id(tidal_map[key]) in removed_ids:
                    tidal_map[key] = track
                auto_removed += 1
            else:
                tidal_map[key] = track

    # --- Pass 3: Fuzzy matching ---
    active: list[tuple[ReleaseTrack, str]] = [
        (track, track_album[id(track)])
        for rec in recommendations
        for track in rec.tracks
        if id(track) not in removed_ids
    ]

    fuzzy_review: list[tuple[ReleaseTrack, str, ReleaseTrack, str, float]] = []

    for i in range(len(active)):
        ti, alb_i = active[i]
        if id(ti) in removed_ids:
            continue
        for j in range(i + 1, len(active)):
            tj, alb_j = active[j]
            if id(tj) in removed_ids:
                continue
            # Authoritative key: identical ISRC means duplicate regardless of fuzzy score.
            if _canonical_isrc(ti.isrc) and _canonical_isrc(ti.isrc) == _canonical_isrc(tj.isrc):
                _resolve_pair(ti, tj, removed_ids)
                auto_removed += 1
                continue
            # Skip fuzzy matching if both tracks have ISRCs that differ
            if _canonical_isrc(ti.isrc) and _canonical_isrc(tj.isrc) and _canonical_isrc(ti.isrc) != _canonical_isrc(tj.isrc):
                continue
            # Skip fuzzy matching if both tracks have Spotify URIs that differ
            if ti.spotify_uri and tj.spotify_uri and ti.spotify_uri.strip() != tj.spotify_uri.strip():
                continue
            sim = _track_similarity(ti, tj)
            if sim >= auto_threshold:
                if not _passes_plausibility_gate(ti, alb_i, tj, alb_j, for_auto=True):
                    continue
                _resolve_pair(ti, tj, removed_ids)
                auto_removed += 1
            elif review_min <= sim <= review_max:
                if not _passes_plausibility_gate(ti, alb_i, tj, alb_j, for_auto=False):
                    continue
                fuzzy_review.append((ti, alb_i, tj, alb_j, sim))

    # Sort highest similarity first for a natural review order
    fuzzy_review.sort(key=lambda x: x[4], reverse=True)

    # --- Pass 4: Interactive review ---
    review_removed = 0
    if fuzzy_review:
        _emit(
            f"\n  [dedup] {len(fuzzy_review)} borderline pair(s) need manual review "
            f"({review_min}–{review_max}% similarity)."
        )
        for ti, alb_i, tj, alb_j, sim in fuzzy_review:
            if id(ti) in removed_ids or id(tj) in removed_ids:
                continue
            choice = _interactive_prompt(ti, alb_i, tj, alb_j, sim, emit=_emit, progress_reporter=progress_reporter)
            if choice == "1":
                _merge_into(ti, tj)
                removed_ids.add(id(tj))
                review_removed += 1
            elif choice == "2":
                _merge_into(tj, ti)
                removed_ids.add(id(ti))
                review_removed += 1

    # --- Apply removals ---
    for rec in recommendations:
        rec.tracks = [t for t in rec.tracks if id(t) not in removed_ids]

    total = auto_removed + review_removed
    if total > 0:
        _v2_emit(
            f"  [v2] Dedup: removed {total} duplicate track(s) "
            f"({auto_removed} auto, {review_removed} via manual review)."
        )

    return recommendations


def deduplicate_recommendations(
    recommendations: list[ReleaseRecommendation],
    emit: Any = None,
    debug: bool = False,
) -> list[ReleaseRecommendation]:
    """Remove duplicate releases with same artist, title, and month (YYYY-MM).

    Operates at the release level after track deduplication. Groups recommendations
    by (artist, normalized title, YYYY-MM) and prompts for manual review if multiple
    releases in the same group have >95% track-set similarity (by ISRC/Spotify ID overlap).

    Modifies the list in-place and returns it.
    """
    _emit = emit or (lambda *_: None)
    _v2_emit = _emit if debug else (lambda *_: None)

    if not recommendations:
        return recommendations

    import datetime

    def extract_year_month(date_str: str | None) -> str | None:
        """Extract YYYY-MM from date string (ISO format or partial)."""
        if not date_str:
            return None
        try:
            if len(date_str) >= 7:
                return date_str[:7]  # YYYY-MM
            return None
        except Exception:
            return None

    def track_set_keys(rec: ReleaseRecommendation) -> set[str]:
        """Return set of (ISRC, spotify_id) keys for tracks in recommendation."""
        keys: set[str] = set()
        for track in rec.tracks:
            if track.isrc:
                keys.add(f"isrc:{track.isrc.upper()}")
            if track.spotify_track_id:
                keys.add(f"spotify:{track.spotify_track_id}")
        return keys

    def similarity(rec_a: ReleaseRecommendation, rec_b: ReleaseRecommendation) -> float:
        """Compute Jaccard similarity of track sets."""
        keys_a = track_set_keys(rec_a)
        keys_b = track_set_keys(rec_b)
        if not keys_a and not keys_b:
            return 1.0
        if not keys_a or not keys_b:
            return 0.0
        overlap = len(keys_a & keys_b)
        union = len(keys_a | keys_b)
        return overlap / union if union > 0 else 0.0

    # Group by (artist, normalized_title, YYYY-MM)
    groups: dict[tuple[str, str, str], list[int]] = {}
    for i, rec in enumerate(recommendations):
        artist = _normalize(rec.artist)
        title = _normalize_title_for_similarity(rec.title)
        ym = extract_year_month(rec.release_date) or "0000-00"
        key = (artist, title, ym)
        if key not in groups:
            groups[key] = []
        groups[key].append(i)

    # For each group with duplicates, check similarity
    removed_indices: set[int] = set()
    review_count = 0

    for (artist, title, ym), indices in groups.items():
        if len(indices) < 2:
            continue

        # Check all pairs in the group
        for i in range(len(indices)):
            if indices[i] in removed_indices:
                continue
            for j in range(i + 1, len(indices)):
                if indices[j] in removed_indices:
                    continue

                rec_i = recommendations[indices[i]]
                rec_j = recommendations[indices[j]]
                sim = similarity(rec_i, rec_j)

                if sim >= 0.95:
                    # Prompt for manual review
                    choice = _interactive_prompt_release(rec_i, rec_j, sim, emit=_emit)
                    if choice == "1":
                        removed_indices.add(indices[j])
                        review_count += 1
                    elif choice == "2":
                        removed_indices.add(indices[i])
                        review_count += 1
                    break  # Only check first match per release

    # Apply removals
    result = [rec for i, rec in enumerate(recommendations) if i not in removed_indices]

    if review_count > 0:
        _v2_emit(f"  [v2] Release dedup: removed {review_count} duplicate release(s) via manual review.")

    return result


def _interactive_prompt_release(
    rec_a: ReleaseRecommendation,
    rec_b: ReleaseRecommendation,
    similarity: float,
    emit: Any,
) -> str:
    """Prompt user to choose between two similar releases."""
    if not _QUESTIONARY_AVAILABLE:
        return "1"  # Default: keep first

    lines = [
        f"\n  '{rec_a.title}'  /  {rec_a.artist}  /  {rec_a.release_date}",
        f"    | vs |",
        f"  '{rec_b.title}'  /  {rec_b.artist}  /  {rec_b.release_date}",
        f"  [{similarity:.0%} track overlap]",
    ]

    emit("".join(lines))

    try:
        choice = questionary.select(
            "Which to keep?",
            choices=[
                ("Keep 1 (first)", "1"),
                ("Keep 2 (second)", "2"),
                ("Keep both", "both"),
            ],
            use_shortcuts=True,
            style=questionary.Style(
                [
                    ("qmark", f"fg:{_QMARK_COLOR} bold"),
                    ("question", "bold"),
                    ("answer", f"fg:{_ACCENT} bold"),
                    ("highlighted", f"fg:{_ACCENT} bold"),
                    ("pointer", f"fg:{_ACCENT} bold"),
                    ("selected", f"fg:{_ACCENT}"),
                ]
            ),
        ).ask()
        return choice or "both"
    except Exception:
        return "both"
