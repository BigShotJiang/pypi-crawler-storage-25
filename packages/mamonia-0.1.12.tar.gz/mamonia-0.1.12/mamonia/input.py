from __future__ import annotations

import csv
import re
from pathlib import Path

from .models import InputTrack


SPOTIFY_PLAYLIST_RE = re.compile(r"(?:spotify:playlist:|open\.spotify\.com/playlist/)([A-Za-z0-9]+)")
RAW_SPOTIFY_ID_RE = re.compile(r"^[A-Za-z0-9]{16,}$")
TIDAL_PLAYLIST_RE = re.compile(r"(?:listen\.tidal\.com/playlist/|tidal\.com/playlist/|tidal:playlist:)([0-9a-f-]+)")
RAW_TIDAL_ID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")

# YouTube Music playlist URL patterns (for detection only, not fetching)
YOUTUBE_PLAYLIST_RE = re.compile(
    r"(?:music\.youtube\.com/playlist|youtube\.com/playlist).*?[?&]list=([A-Za-z0-9_-]+)"
)
# Apple Music playlist URL patterns (for detection only)
APPLE_MUSIC_PLAYLIST_RE = re.compile(r"music\.apple\.com/")
APPLE_MUSIC_PLAYLIST_ID_RE = re.compile(r"music\.apple\.com\/[^\/]+\/playlist\/[^\/]+\/(pl\.[A-Za-z0-9._-]+)")
RAW_APPLE_MUSIC_ID_RE = re.compile(r"^pl\.[A-Za-z0-9._-]+$")

# YouTube-style title parsing noise patterns (for input parsing)
YOUTUBE_NOISE_PATTERNS = [
    r"\s*[\(\[](?:official\s*)?(?:video|audio|lyric|lyrics|remix|cover|live|acoustic|mv|hd|4k|1080p|720p|studio|version)\s*[\)\]]",
    r"\s*[\(\[](?:from|in)\s+.*?[\)\]]",
    r"\s*[\(\[](?:ft\.?|feat\.?|featuring|ft)\s+.*?[\)\]]",
    r"\s*-\s*(?:official\s*)?(?:video|audio|lyric|remix|cover|live|acoustic|mv|hd|4k|1080p|720p)\s*",
]


def extract_spotify_playlist_id(value: str) -> str | None:
    normalized = _normalize_playlist_hint(value)
    match = SPOTIFY_PLAYLIST_RE.search(normalized)
    if match:
        return match.group(1)
    stripped = normalized.strip()
    if RAW_SPOTIFY_ID_RE.fullmatch(stripped):
        return stripped
    return None


def looks_like_spotify_playlist(value: str) -> bool:
    return extract_spotify_playlist_id(value) is not None


def extract_tidal_playlist_id(value: str) -> str | None:
    normalized = _normalize_playlist_hint(value)
    match = TIDAL_PLAYLIST_RE.search(normalized)
    if match:
        return match.group(1)
    stripped = normalized.strip()
    if RAW_TIDAL_ID_RE.fullmatch(stripped):
        return stripped
    return None


def looks_like_tidal_playlist(value: str) -> bool:
    return extract_tidal_playlist_id(value) is not None


def _normalize_playlist_hint(value: str) -> str:
    text = (value or "").strip()
    if text.startswith("<") and text.endswith(">"):
        text = text[1:-1].strip()
    return text


def looks_like_youtube_playlist(value: str) -> bool:
    """Check if value looks like a YouTube Music playlist URL."""
    return bool(YOUTUBE_PLAYLIST_RE.search(value))


def looks_like_apple_music_playlist(value: str) -> bool:
    """Check if value looks like an Apple Music playlist URL."""
    return extract_apple_music_playlist_id(value) is not None or bool(APPLE_MUSIC_PLAYLIST_RE.search(value))


def extract_apple_music_playlist_id(value: str) -> str | None:
    normalized = _normalize_playlist_hint(value)
    match = APPLE_MUSIC_PLAYLIST_ID_RE.search(normalized)
    if match:
        return match.group(1)
    stripped = normalized.strip()
    if RAW_APPLE_MUSIC_ID_RE.fullmatch(stripped):
        return stripped
    return None


def _strip_youtube_noise_from_input(value: str) -> str:
    """Strip common YouTube video/audio noise suffixes from a track title.

    This is a simplified version of the utility function for use in input parsing.
    """
    if not value:
        return ""
    result = value
    for pattern in YOUTUBE_NOISE_PATTERNS:
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)
    result = re.sub(r"\s+", " ", result).strip()
    return result


def parse_csv_file(path: Path) -> list[InputTrack]:
    tracks: list[InputTrack] = []
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Try multiple column names for track and artist
            track_name = row.get("Track name", "").strip() or row.get("Title", "").strip()
            artist_name = row.get("Artist name", "").strip() or row.get("Artist", "").strip()

            album = row.get("Album", "").strip() or None
            spotify_id = row.get("Spotify - id", "").strip() or None
            isrc = row.get("ISRC", "").strip() or None

            # Fallback: if Artist name is missing but Track exists, try YouTube-style parsing
            if not artist_name and track_name:
                parsed = extract_artist_track_from_title(track_name)
                if parsed:
                    artist_name, track_name = parsed
                    artist_name = artist_name.strip()
                    track_name = track_name.strip()

            if not artist_name:
                continue

            tracks.append(
                InputTrack(
                    artist=artist_name,
                    track=track_name,
                    album=album,
                    artists=[artist_name],
                    spotify_track_id=spotify_id,
                    isrc=isrc,
                    source_platform="csv",
                    playlist_position=len(tracks),
                )
            )
    return tracks


def parse_text_file(path: Path) -> list[InputTrack]:
    if path.suffix.lower() == ".csv":
        return parse_csv_file(path)
    tracks: list[InputTrack] = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parsed = parse_track_line(line)
        if parsed:
            tracks.append(parsed)
    return tracks


def parse_track_line(line: str) -> InputTrack | None:
    if "|" in line:
        parts = [part.strip() for part in line.split("|")]
        if not parts or not parts[0]:
            return None
        track = parts[1] if len(parts) > 1 else ""
        album = parts[2] if len(parts) > 2 and parts[2] else None
        # Strip YouTube-style noise from track name
        track = _strip_youtube_noise_from_input(track)
        if album:
            album = _strip_youtube_noise_from_input(album)
        return InputTrack(
            artist=parts[0],
            track=track,
            album=album,
            artists=[parts[0]],
            source_platform="txt",
        )
    if " - " in line:
        artist, track = line.split(" - ", 1)
        artist = artist.strip()
        if not artist:
            return None
        # Strip YouTube-style noise from track name
        track = _strip_youtube_noise_from_input(track.strip())
        return InputTrack(artist=artist, track=track, artists=[artist], source_platform="txt")
    # Fallback: try YouTube-style title parsing (e.g., "Artist - Track (Official Video)")
    parsed = extract_artist_track_from_title(line)
    if parsed:
        artist, track = parsed
        return InputTrack(artist=artist, track=track, artists=[artist])
    return InputTrack(artist=line, track="", artists=[line])


def extract_artist_track_from_title(title: str) -> tuple[str, str] | None:
    """Extract (artist, track) from a free-form title string.

    Tries multiple separators and strips common video/audio noise suffixes.
    Returns None if no separator is found and the title is too ambiguous.

    This function is inspired by the parseYouTubeTitle logic from convert.ts
    and is useful for parsing track metadata from YouTube video titles or
    copy-pasted tracklists that don't follow strict formatting.
    """
    if not title:
        return None

    # Try multiple separators in order of preference
    separators = [" - ", " – ", " — ", " | ", ": ", " by "]
    for sep in separators:
        if sep in title:
            parts = title.split(sep, 1)
            if len(parts) >= 2:
                artist = parts[0].strip()
                track = parts[1].strip()
                if artist and track:
                    # Strip noise suffixes from track
                    track = _strip_youtube_noise_from_input(track)
                    return (artist, track)

    # No separator found - try to clean the title and return as track with Unknown Artist
    cleaned = _strip_youtube_noise_from_input(title)
    if cleaned and cleaned != title.strip():
        return ("Unknown Artist", cleaned)
    return None
