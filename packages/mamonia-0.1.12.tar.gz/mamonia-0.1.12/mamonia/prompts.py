from __future__ import annotations


def prompt_delta_update(added_count: int, removed_count: int, last_seen_date: str) -> bool:
    prompt = (
        "I see that the playlist changed a little. "
        f"Last time I saw it was {last_seen_date}. "
        f"Since then you seem to have added {added_count} tracks / removed {removed_count} tracks. "
        "Do you want me to update your taste profile connected to this playlist? (y/n)"
    )
    try:
        answer = input(prompt + " ")
    except EOFError:
        return False
    return answer.strip().lower() in {"y", "yes"}
