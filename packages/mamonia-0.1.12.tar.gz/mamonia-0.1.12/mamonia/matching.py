from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Any

from .discovery_window import DiscoveryWindow, resolve_effective_window
from .utils import parse_date


@dataclass(frozen=True)
class MatchCandidate:
    provider: str
    track_id: str
    album_id: str | None
    title: str | None
    artists: list[str]
    album_title: str | None
    album_release_date: str | None
    isrc: str | None
    fit_score: int
    raw_payload: Any


@dataclass(frozen=True)
class MatchSelection:
    candidate: MatchCandidate
    stage: str


def select_staged_candidate(
    candidates: list[MatchCandidate],
    *,
    target_isrc: str | None,
    mb_release_date: str | None,
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> MatchSelection | None:
    if not candidates:
        return None
    today = discovery_today or dt.date.today()
    normalized_isrc = _normalize_isrc(target_isrc)

    stage1 = [
        candidate for candidate in candidates
        if normalized_isrc
        and _normalize_isrc(candidate.isrc) == normalized_isrc
        and _in_window(
            candidate.album_release_date,
            discovery_months,
            discovery_window,
            today,
        )
    ]
    if stage1:
        return MatchSelection(candidate=_rank(stage1, mb_release_date)[0], stage="isrc_in_window")

    stage2 = [
        candidate for candidate in candidates
        if normalized_isrc and _normalize_isrc(candidate.isrc) == normalized_isrc
    ]
    if stage2:
        return MatchSelection(candidate=_rank(stage2, mb_release_date)[0], stage="isrc_anywhere")

    stage3 = [
        candidate for candidate in candidates
        if _dates_match_precision(candidate.album_release_date, mb_release_date)
    ]
    if stage3:
        return MatchSelection(candidate=_rank(stage3, mb_release_date)[0], stage="mb_exact_date")

    stage4 = [
        candidate for candidate in candidates
        if _in_window(candidate.album_release_date, discovery_months, discovery_window, today)
    ]
    if stage4:
        return MatchSelection(candidate=_rank(stage4, mb_release_date)[0], stage="metadata_in_window")
    return None


def _normalize_isrc(value: str | None) -> str:
    return (value or "").strip().upper()


def _in_window(
    value: str | None,
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None,
    today: dt.date,
) -> bool:
    parsed = parse_date(value)
    if parsed is None and discovery_window is None and (discovery_months is None or discovery_months <= 0):
        return True
    if parsed is None:
        return False
    window = resolve_effective_window(discovery_window=discovery_window, months=discovery_months, today=today)
    return window.start_date <= parsed <= window.end_date


def _dates_match_precision(left: str | None, right: str | None) -> bool:
    if not left or not right:
        return False
    left = left.strip()
    right = right.strip()
    left_parsed = parse_date(left)
    right_parsed = parse_date(right)
    if left_parsed is None or right_parsed is None:
        return False
    shorter = left if len(left) <= len(right) else right
    longer = right if shorter == left else left
    return longer.startswith(shorter)


def _rank(candidates: list[MatchCandidate], mb_release_date: str | None) -> list[MatchCandidate]:
    target_date = parse_date(mb_release_date)

    def _sort_key(candidate: MatchCandidate) -> tuple[int, int, dt.date, str]:
        candidate_date = parse_date(candidate.album_release_date) or dt.date.min
        if target_date is None:
            date_distance = 10**9
        else:
            date_distance = abs((candidate_date - target_date).days)
        return (
            candidate.fit_score,
            -date_distance,
            candidate_date,
            candidate.track_id,
        )

    return sorted(candidates, key=_sort_key, reverse=True)
