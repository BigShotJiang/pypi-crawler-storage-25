from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import select
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

from .analysis import build_taste_profile, build_taste_profile_reusing_artists
from .config import load_settings
from .delta import diff_playlist_tracks
from .discovery import track_keys_from_input
from .discovery_window import DiscoveryWindow, resolve_effective_window
from .enrichment import enrich_recommendation_tracks
from .input import (
    extract_apple_music_playlist_id,
    extract_spotify_playlist_id,
    extract_tidal_playlist_id,
    looks_like_apple_music_playlist,
    looks_like_spotify_playlist,
    looks_like_tidal_playlist,
    parse_text_file,
)
from .i18n import DEFAULT_LANGUAGE, SUPPORTED_LANGUAGES, load_locale, get_translator
from .models import CandidateArtist, InputTrack, ReleaseRecommendation, ReleaseTrack, TasteProfile
from .output import _platform_availability_rows, platform_availability_notice, write_recommendations, write_selection_logic
from .progress import DiscoverySummary, choose_busy_status_reporter, choose_progress_reporter
from .profiles import portable_track_key, portable_track_set_hash, seed_tracks_from_payload, source_identity, source_identity_from_tracks
from .prompts import prompt_delta_update
from .providers import ProviderRateLimit, ProviderUnavailable, format_retry_after
from .providers.deezer import DeezerProvider
from .providers.lastfm import LastFMProvider
from .providers.listenbrainz import ListenBrainzProvider
from .providers.musicbrainz import MusicBrainzProvider
from .providers.apple_music import AppleMusicProvider
from .providers.spotify import SpotifyProvider
from .providers.tidal import TidalProvider
from .isrc import ISRCResolver
from .storage import Storage
from .utils import clamp, normalize_key


Emitter = Callable[[str], None]
ProfileDecisionAction = Literal["reuse", "delta_update", "refresh_enrichment", "fresh_rebuild"]
ProfileDecisionChooser = Callable[["ProfileDecisionContext"], ProfileDecisionAction | None]
PlaylistConfigCallback = Callable[
    [],
    tuple[bool, str | None, bool, str | None, bool, str | None, str | None] | None,
]
ExpansionMemorySaveCallback = Callable[[int, str], bool | None]
ShortageRefillContinueCallback = Callable[[int, int, int], bool | None]
SPOTIFY_PROFILE_ARTIST_METADATA_CAP = 50
SPOTIFY_PROFILE_TRACK_BACKFILL_CAP = 75
# Rollout gate for legacy Spotify profile-stage track backfill.
# Keep default at 0% to effectively disable this expensive call path.
SPOTIFY_PROFILE_TRACK_BACKFILL_ROLLOUT_PERCENT = 0
TIDAL_TRACK_LOOKUP_CACHE_VERSION = "tidal-track-lookup-v2-openapi"
_PENDING_AVAILABILITY_NOTICE_ROWS: list[dict[str, str]] = []
_TIER_STRENGTH = {"tier 1": 4, "tier 2a": 3, "tier 2b": 2, "tier 3": 1, "tier 4": 0}


@dataclass(frozen=True)
class ProfileDecisionContext:
    profile_id: int
    profile_name: str
    source_type: str
    changed: bool
    added_count: int = 0
    removed_count: int = 0
    saved_track_count: int = 0
    current_track_count: int = 0
    enrichment_complete: bool = True


@dataclass(frozen=True)
class DiscoverOptions:
    playlist: str | None = None
    profile_ref: str | None = None
    reuse_profile: bool = False
    months: int = 6
    discovery_window: DiscoveryWindow | None = None
    max_tracks: int = 3
    output: str = "txt"
    output_path: Path | None = None
    limit: int = 50
    max_candidates: int = 0
    min_seed_weight: float = 0.20
    deep_cuts: bool = False
    tiered_results: bool = False
    discovery_mode: Literal["top_first", "standard", "deep_cuts", "balanced", "deep_diverse"] = "balanced"
    dry_run: bool = False
    verbose: bool = False
    global_memory: bool = True
    create_spotify_playlist: bool = False
    spotify_playlist_name: str | None = None
    create_tidal_playlist: bool = False
    tidal_playlist_name: str | None = None
    create_apple_playlist: bool = False
    apple_playlist_name: str | None = None
    apple_target_playlist: str | None = None
    save_selection_logic: bool = False
    selection_logic_path: Path | None = None
    force_refresh: bool = False
    profile_decision_callback: ProfileDecisionChooser | None = None
    enrichment_only: bool = False
    penalize_frequent_artists: bool = False
    shuffle_releases: bool = False
    run_deduplication: bool = True
    use_streaming_providers: bool = False
    language: str | None = None
    playlist_config_callback: PlaylistConfigCallback | None = None
    adaptive_small_seed_mode: bool = True
    refill_after_heard: bool = True
    defer_platform_backfill: bool = True
    use_profile_expansion_memory: bool | None = None
    prompt_to_save_expansion_memory: bool = True
    expansion_memory_save_callback: ExpansionMemorySaveCallback | None = None
    shortage_refill_continue_callback: ShortageRefillContinueCallback | None = None


class WorkflowAbort(RuntimeError):
    def __init__(self, message: str, code: int = 1):
        super().__init__(message)
        self.message = message
        self.code = code


def consume_pending_availability_notice_rows() -> list[dict[str, str]]:
    global _PENDING_AVAILABILITY_NOTICE_ROWS
    rows = list(_PENDING_AVAILABILITY_NOTICE_ROWS)
    _PENDING_AVAILABILITY_NOTICE_ROWS = []
    return rows


def emit_collapsible_availability_notice(
    recommendations: list[ReleaseRecommendation],
    emit: Emitter,
    locale: str | None = None,
) -> bool:
    """Emit availability notice summary and optional detail expansion prompt."""
    global _PENDING_AVAILABILITY_NOTICE_ROWS
    rows = _platform_availability_rows(recommendations)
    _PENDING_AVAILABILITY_NOTICE_ROWS = list(rows)
    if not rows:
        return False

    notice = platform_availability_notice(recommendations)
    summary_lines = []
    for line in notice.splitlines():
        summary_lines.append(line)
        if line.strip() == "Review these songs:":
            break
    for line in summary_lines:
        emit(line)

    return prompt_expand_availability_rows(rows, emit)


def _read_single_key(timeout_seconds: float = 0.0) -> str:
    """Read a single keypress from stdin without requiring Enter.

    Returns the character pressed, or empty string on failure.
    """
    if not (sys.stdin and sys.stdin.isatty()):
        return ""
    try:
        if sys.platform == "win32":
            import msvcrt

            ch = msvcrt.getch()
            try:
                return ch.decode("utf-8", errors="replace")
            except (UnicodeDecodeError, AttributeError):
                return str(ch)
        else:
            import termios
            import tty

            fd = sys.stdin.fileno()
            if timeout_seconds > 0:
                readable, _, _ = select.select([sys.stdin], [], [], timeout_seconds)
                if not readable:
                    return ""
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            return ch
    except Exception:
        return ""


def prompt_expand_availability_rows(rows: list[dict[str, str]], emit: Emitter, locale: str = DEFAULT_LANGUAGE) -> bool:
    """Prompt user to expand hidden availability row details.

    Reads a single keypress immediately (no Enter required):
        E / e → expand detail view
        Any other key → proceed
    """
    if not rows:
        return False
    emit(_translate_key(locale, "status.press_e_for_details"))
    if not (sys.stdin and sys.stdin.isatty()):
        return False
    try:
        # Wait for explicit user input so the prompt is actionable.
        key = _read_single_key(timeout_seconds=0.0)
    except (EOFError, KeyboardInterrupt):
        return False
    if key.strip().lower() != "e":
        return False
    for row in rows:
        emit(row["message"])
    return True


def _merge_expansion_memory_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Merge profile expansion memories by artist across providers."""
    if not items:
        return []
    merged: dict[str, dict[str, Any]] = {}
    for item in items:
        artist_name = str(item.get("artist_name") or "").strip()
        artist_key = normalize_key(artist_name)
        if not artist_key:
            continue
        provider = str(item.get("provider") or "unknown").strip() or "unknown"
        tier = str(item.get("tier") or "").strip()
        confidence = float(item.get("confidence") or 0.0)
        score = float(item.get("score") or 0.0)
        evidence = item.get("evidence") if isinstance(item.get("evidence"), dict) else {}
        if artist_key not in merged:
            merged[artist_key] = {
                "artist_name": artist_name,
                "provider_set": {provider},
                "tier": tier,
                "confidence": confidence,
                "score": score,
                "evidence": dict(evidence),
            }
            continue
        row = merged[artist_key]
        row["provider_set"].add(provider)
        if confidence > float(row.get("confidence") or 0.0):
            row["confidence"] = confidence
        if score > float(row.get("score") or 0.0):
            row["score"] = score
        current_tier = str(row.get("tier") or "")
        if _TIER_STRENGTH.get(tier.lower(), -1) > _TIER_STRENGTH.get(current_tier.lower(), -1):
            row["tier"] = tier
        row_evidence = row.get("evidence") if isinstance(row.get("evidence"), dict) else {}
        for key in ("connection_types", "seed_artists"):
            existing = [str(v) for v in (row_evidence.get(key) or []) if v]
            incoming = [str(v) for v in (evidence.get(key) or []) if v]
            if incoming:
                row_evidence[key] = list(dict.fromkeys(existing + incoming))
        row["evidence"] = row_evidence

    out: list[dict[str, Any]] = []
    for row in merged.values():
        providers = sorted({str(v).strip() for v in row.pop("provider_set", set()) if str(v).strip()})
        provider_label = "+".join(providers) if providers else "unknown"
        evidence = row.get("evidence") if isinstance(row.get("evidence"), dict) else {}
        evidence["providers"] = providers
        row["provider"] = provider_label
        row["evidence"] = evidence
        out.append(row)
    out.sort(key=lambda item: (float(item.get("confidence") or 0.0), float(item.get("score") or 0.0)), reverse=True)
    return out


def discovery_mode_to_flags(mode: str) -> tuple[bool, bool]:
    """Convert discovery_mode string to deep_cuts and tiered_results flags.

    Args:
        mode: One of "top_first", "standard", "deep_cuts", "balanced", "deep_diverse"

    Returns:
        tuple[bool, bool]: (deep_cuts, tiered_results)
    """
    mode_map = {
        "top_first": (False, False),
        "standard": (False, False),
        "deep_cuts": (True, False),
        "balanced": (False, True),
        "deep_diverse": (True, True),
    }
    return mode_map.get(mode, (False, False))


def run_config_seed(options: DiscoverOptions) -> str:
    """Return stable run-config material for deterministic release shuffling."""
    return json.dumps(
        {
            "months": options.months,
            "max_tracks": options.max_tracks,
            "limit": options.limit,
            "max_candidates": options.max_candidates,
            "min_seed_weight": options.min_seed_weight,
            "discovery_mode": options.discovery_mode,
            "global_memory": options.global_memory,
            "penalize_frequent_artists": options.penalize_frequent_artists,
        },
        sort_keys=True,
    )


def discover_releases(
    *,
    input_tracks: list[InputTrack],
    musicbrainz: Any | None,
    listenbrainz: Any | None,
    lastfm: Any | None,
    spotify: Any | None,
    deezer: Any | None,
    tidal: Any | None,
    heard_release_group_mbids: set[str] | None,
    months: int,
    discovery_window: DiscoveryWindow | None,
    limit: int,
    deep_cuts: bool,
    tiered_results: bool,
    emit: Emitter,
    isrc_resolver: ISRCResolver,
    max_tracks: int,
    seed_track_keys: set[str],
    profile: TasteProfile,
    storage: Storage,
    force_refresh: bool,
    penalize_frequent_artists: bool,
    max_candidates: int,
    min_seed_weight: float,
    progress: Any,
    run_deduplication: bool = True,
    excluded_artist_keys: set[str] | None = None,
    use_streaming_providers: bool = False,
    debug: bool = False,
    adaptive_small_seed_mode: bool = True,
    refill_after_heard: bool = True,
    expansion_memory_seeds: list[dict[str, Any]] | None = None,
    shortage_refill_continue_callback: ShortageRefillContinueCallback | None = None,
) -> list[ReleaseRecommendation]:
    """Compatibility wrapper: discovery always routes through pipeline_v2."""
    from .pipeline_v2 import run_v2_pipeline

    effective_window = resolve_effective_window(discovery_window=discovery_window, months=months)
    window_days = max(1, (effective_window.end_date - effective_window.start_date).days + 1)
    return run_v2_pipeline(
        input_tracks=input_tracks,
        musicbrainz=musicbrainz,
        listenbrainz=listenbrainz,
        lastfm=lastfm,
        spotify=spotify,
        deezer=deezer,
        tidal=tidal,
        heard_release_group_mbids=heard_release_group_mbids,
        window_days=window_days,
        limit=limit,
        deep_cuts=deep_cuts,
        tiered_results=tiered_results,
        emit=emit,
        isrc_resolver=isrc_resolver,
        max_tracks=max_tracks,
        seed_track_keys=seed_track_keys,
        profile=profile,
        storage=storage,
        force_refresh=force_refresh,
        penalize_frequent_artists=penalize_frequent_artists,
        max_candidates=max_candidates,
        min_seed_weight=min_seed_weight,
        progress=progress,
        discovery_window=effective_window,
        run_deduplication=run_deduplication,
        excluded_artist_keys=excluded_artist_keys,
        use_streaming_providers=use_streaming_providers,
        debug=debug,
        adaptive_small_seed_mode=adaptive_small_seed_mode,
        refill_after_heard=refill_after_heard,
        expansion_memory_seeds=expansion_memory_seeds,
        shortage_refill_continue_callback=shortage_refill_continue_callback,
    )


def _resolve_locale(options: DiscoverOptions) -> str:
    if options.language in SUPPORTED_LANGUAGES:
        return str(options.language)
    env_lang = os.environ.get("MAMONIA_LANG", "").lower()
    if env_lang in SUPPORTED_LANGUAGES:
        return env_lang
    # Fall back to the process locale when guided-language hints are absent.
    # Accept values like "pl_PL.UTF-8" or "en_US".
    for locale_var in ("LC_ALL", "LANG"):
        raw = os.environ.get(locale_var, "").strip().lower()
        if not raw:
            continue
        base = raw.split(".", 1)[0]
        candidate = base.split("_", 1)[0]
        if candidate in SUPPORTED_LANGUAGES:
            return candidate
    return DEFAULT_LANGUAGE


def _workflow_wait_texts(locale: str) -> dict[str, list[str]]:
    try:
        root = load_locale(locale)
    except Exception:
        root = load_locale(DEFAULT_LANGUAGE)
    wait = root.get("status", {}).get("wait", {})
    common = wait.get("common", [])
    return {
        "load_profile": wait.get("load_profile", common),
        "load_input": wait.get("load_input", common),
        "metadata": wait.get("metadata", common),
        "profile_decision": wait.get("profile_decision", common),
        "profile_build": wait.get("profile_build", common),
        "discovery": wait.get("discovery", common),
        "platform_lookup": wait.get("platform_lookup", common),
        "enrichment": wait.get("enrichment", common),
        "write_output": wait.get("write_output", common),
    }



def _translate_key(locale: str, key: str, **kwargs) -> str:
    """Translate a key using the given locale with optional format placeholders."""
    try:
        translate = get_translator(locale)
        return translate(key, **kwargs)
    except Exception:
        # Fallback: return the key itself or a default English string
        return key


def _translate_profile_state(state: str, locale: str) -> str:
    """Translate profile state using locale."""
    try:
        root = load_locale(locale)
    except Exception:
        root = load_locale(DEFAULT_LANGUAGE)
    states = root.get("status", {}).get("profile_state", {})
    # Convert state key to use underscore instead of hyphen for lookup
    state_key = state.replace("-", "_")
    return states.get(state_key, state)


def _shuffle_seed(source_hash: str | None, config_seed: str) -> int:
    material = f"{source_hash or ''}|{config_seed}"
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()
    return int(digest[:16], 16)


def shuffle_recommendations(
    recommendations: list[ReleaseRecommendation],
    *,
    seed: int,
) -> list[ReleaseRecommendation]:
    """Shuffle whole release recommendations while preserving each release's tracks."""
    shuffled = list(recommendations)
    random.Random(seed).shuffle(shuffled)
    return shuffled


def run_discover(
    options: DiscoverOptions,
    emit: Emitter = print,
    emit_error: Emitter = print,
) -> None:
    locale = _resolve_locale(options)
    wait_texts = _workflow_wait_texts(locale)
    interactive_tty = sys.stderr.isatty()
    # Unified progress renderer owns runtime liveness UI; keep busy phases no-op.
    busy = choose_busy_status_reporter(is_tty=False)

    def _phase_progress_reporter() -> Any:
        return choose_progress_reporter(
            is_tty=interactive_tty,
            emit=emit_error,
            discovery_wait_lines=wait_texts["platform_lookup"],
            locale=locale,
        )
    settings = load_settings(force_refresh=options.force_refresh)
    with Storage(settings.db_path) as storage:
        _print_settings_warnings(settings, emit_error)
        output_format = options.output.lower()
        if output_format not in {"txt", "csv", "json"}:
            raise WorkflowAbort(_translate_key(locale, "error.output_format"))
        max_tracks = max(0, options.max_tracks)
        if options.profile_ref and options.playlist:
            raise WorkflowAbort(_translate_key(locale, "error.either_playlist_or_profile"))
        if not options.profile_ref and not options.playlist:
            raise WorkflowAbort(_translate_key(locale, "error.provide_playlist_or_profile"))
        if options.reuse_profile and options.profile_ref:
            raise WorkflowAbort(_translate_key(locale, "error.reuse_profile_valid"))

        providers_tuple = _providers(settings, storage)
        if len(providers_tuple) == 6:
            spotify, musicbrainz, lastfm, tidal, apple_music, listenbrainz = providers_tuple
            deezer = DeezerProvider(settings, storage=storage)
        else:
            spotify, musicbrainz, lastfm, tidal, apple_music, listenbrainz, deezer = providers_tuple
        if options.create_spotify_playlist and not options.dry_run and not spotify.available:
            raise WorkflowAbort(_translate_key(locale, "error.spotify_credentials_required"))
        if options.create_tidal_playlist and not options.dry_run and not (tidal and tidal.available):
            raise WorkflowAbort(_translate_key(locale, "error.tidal_credentials_required"))
        if (options.create_apple_playlist or options.apple_target_playlist) and not options.dry_run and not apple_music.available:
            raise WorkflowAbort(_translate_key(locale, "error.apple_music_credentials_required"))

        # Early Tidal session check to surface auth issues before ISRC resolution
        if tidal and tidal.available and not options.dry_run:
            if not tidal.ensure_session():
                emit_error(_translate_key(locale, "status.tidal_auth_required"))
                emit_error(_translate_key(locale, "status.tidal_isrc_disabled"))
                emit_error(_translate_key(locale, "status.tidal_set_credentials"))
                emit_error(_translate_key(locale, "status.tidal_use_local"))
                tidal = None

        _start_time = None
        stage_timings_seconds: dict[str, float] = {}
        phase1_started_at = time.monotonic()
        phase1_progress = _phase_progress_reporter()
        _base_emit = emit
        _base_emit_error = emit_error

        def _emit_via_progress(message: str) -> None:
            if hasattr(phase1_progress, "emit_message"):
                phase1_progress.emit_message(message, err=False)
            else:
                _base_emit(message)

        def _emit_error_via_progress(message: str) -> None:
            if hasattr(phase1_progress, "emit_message"):
                phase1_progress.emit_message(message, err=True)
            else:
                _base_emit_error(message)

        emit = _emit_via_progress
        emit_error = _emit_error_via_progress
        if hasattr(phase1_progress, "enter_phase"):
            phase1_progress.enter_phase("[1/5] Preparing profile inputs")
        phase1_total_steps = 5
        phase1_step = 0

        def _phase1_tick(step_label: str) -> None:
            nonlocal phase1_step
            phase1_step = min(phase1_total_steps, phase1_step + 1)
            if hasattr(phase1_progress, "stage_started"):
                phase1_progress.stage_started("[1/5] Preparing profile inputs", processed=0, total=phase1_total_steps)
            if hasattr(phase1_progress, "candidate_started"):
                phase1_progress.candidate_started(
                    CandidateArtist(name=step_label, source="phase-1", score=0.0),
                    processed=phase1_step,
                    total=phase1_total_steps,
                )

        if options.profile_ref:
            profile_record = storage.get_taste_profile(options.profile_ref)
            if not profile_record:
                raise WorkflowAbort(_translate_key(locale, "error.no_saved_profile", ref=options.profile_ref))
            _start_time = time.monotonic()
            stage_started_at = _start_time
            with busy.phase("[1/5] Loading saved profile", wait_texts["load_profile"]):
                profile, tracks, seed_track_keys = _profile_from_record(profile_record)
                storage.touch_taste_profile(profile_record["id"])
                profile_state = "reused"
            _phase1_tick("Loading saved profile")
            emit(_translate_key(locale, "status.loading_profile", count=len(tracks)))
            emit("")
        else:
            assert options.playlist is not None
            source = source_identity(options.playlist)
            profile_record = storage.find_taste_profile_for_source(source) if options.reuse_profile else None
            if profile_record:
                if _start_time is None:
                    _start_time = time.monotonic()
                stage_started_at = _start_time
                with busy.phase("[1/5] Loading saved profile", wait_texts["load_profile"]):
                    profile, tracks, seed_track_keys = _profile_from_record(profile_record)
                    storage.touch_taste_profile(profile_record["id"])
                    profile_state = "reused"
                _phase1_tick("Loading saved profile")
                emit(_translate_key(locale, "status.loading_profile", count=len(tracks)))
                emit("")
            else:
                stage_started_at = time.monotonic()
                with busy.phase("[1/5] Loading input tracks", wait_texts["load_input"]):
                    tracks = _load_playlist_tracks(options.playlist, spotify, tidal, apple_music)
                _phase1_tick("Loading input tracks")
                if not tracks:
                    raise WorkflowAbort(_translate_key(locale, "error.no_input_tracks"))
                with busy.phase("[1/5] Preparing track metadata", wait_texts["metadata"]):
                    _store_input_track_enrichment(storage, tracks, spotify=spotify)
                _phase1_tick("Preparing track metadata")
                source = source_identity_from_tracks(options.playlist, tracks)
                source = enrich_source_name(source, options.playlist, spotify, tidal, apple_music)
                emit(_translate_key(locale, "status.loading_input", count=len(tracks)))
                if _start_time is None:
                    _start_time = time.monotonic()
                emit("")
                matched_profile = storage.find_taste_profile_for_source(source)
                if matched_profile:
                    with busy.phase("[1/5] Checking saved profile", wait_texts["profile_decision"]):
                        profile, tracks, seed_track_keys, profile_record, profile_state = _maybe_delta_update_profile(
                            storage=storage,
                            settings=settings,
                            source=source,
                            profile_record=matched_profile,
                            current_tracks=tracks,
                            spotify=spotify,
                            musicbrainz=musicbrainz,
                            lastfm=lastfm,
                            listenbrainz=listenbrainz,
                            deezer=deezer,
                            tidal=tidal,
                            decision_callback=options.profile_decision_callback,
                            emit=emit,
                            emit_error=emit_error,
                            verbose=options.verbose,
                            locale=locale,
                        )
                    _phase1_tick("Checking saved profile")
                else:
                    equivalent_profile = _find_equivalent_profile(storage, tracks)
                    if equivalent_profile:
                        profile, saved_tracks, saved_seed_track_keys = _profile_from_record(equivalent_profile)
                        completed_tracks = _merge_seed_track_metadata(saved_tracks, tracks)
                        current_seed_track_keys = track_keys_from_input(tracks)
                        seed_track_keys = saved_seed_track_keys | current_seed_track_keys
                        profile_record = equivalent_profile
                        profile_record = storage.upsert_taste_profile(
                            name=profile_record["name"],
                            source_type=profile_record["source_type"],
                            source_ref=profile_record["source_ref"],
                            source_key=profile_record["source_key"],
                            source_hash=profile_record["source_hash"],
                            track_count=len(completed_tracks),
                            artist_count=profile.n_artists,
                            profile=profile,
                            seed_tracks=completed_tracks,
                            seed_track_keys=seed_track_keys,
                        )
                        profile_state = "equivalent-reused"
                        _phase1_tick("Reusing equivalent profile")
                        emit(
                            _translate_key(locale, "status.equivalent_reused_message",
                                source_type=profile_record['source_type'], count=len(saved_tracks))
                        )
                    else:
                        with busy.phase("[1/5] Building profile", wait_texts["profile_build"]):
                            profile, seed_track_keys, profile_record = _build_and_store_profile(
                                storage=storage,
                                settings=settings,
                                source=source,
                                tracks=tracks,
                                spotify=spotify,
                                musicbrainz=musicbrainz,
                                lastfm=lastfm,
                                listenbrainz=listenbrainz,
                                deezer=deezer,
                                tidal=tidal,
                                emit=emit,
                                emit_error=emit_error,
                                verbose=options.verbose,
                            )
                        _phase1_tick("Building profile")
                        profile_state = "refreshed"

        stage_timings_seconds["phase_1_setup"] = round(time.monotonic() - phase1_started_at, 3)
        emit(
            _translate_key(
                locale,
                "status.phase_time",
                phase="[1/5]",
                elapsed=f"{stage_timings_seconds['phase_1_setup']:.2f}",
            )
        )

        # Generate session_id for grouping heard releases
        profile_name = str(profile_record["name"])
        session_timestamp = dt.datetime.now()
        session_id = f"{profile_name}_{session_timestamp.strftime('%d%m%Y_%H%M')}"

        translated_state = profile_state
        stage_timings_seconds["profile_build"] = round(time.monotonic() - stage_started_at, 3)
        emit(
            _translate_key(locale, "status.profile_loaded",
                id=profile_record['id'], name=profile_record['name'], type=profile_record['source_type'],
                state=translated_state, track_count=profile_record['track_count'],
                artist_count=profile_record['artist_count'])
        )
        emit(
            _translate_key(locale, "status.top_artists",
                artists=(", ".join(artist.name for artist in profile.top_artists[:5]) if profile.top_artists else _translate_key(locale, "status.none", default="none")))
        )
        emit("")
        if options.enrichment_only:
            emit(_translate_key(locale, "status.enrichment_refreshed"))
            emit(_translate_key(locale, "status.no_recommendation_file"))
            emit("[5/5] Done.")
            emit(_translate_key(locale, "status.done"))
            return
        discovery_seed_track_keys = set(seed_track_keys)
        effective_global_memory = options.global_memory and profile_state != "fresh-rebuilt"
        if options.global_memory and not effective_global_memory:
            emit(_translate_key(locale, "status.global_memory_off"))
        if effective_global_memory:
            global_seed_track_keys = storage.all_seed_track_keys()
            before_count = len(discovery_seed_track_keys)
            discovery_seed_track_keys.update(global_seed_track_keys)
            added_count = len(discovery_seed_track_keys) - before_count
            emit(
                _translate_key(locale, "status.global_memory_summary",
                    count=len(discovery_seed_track_keys), added=added_count)
            )

        excluded_artist_keys = storage.all_excluded_artist_keys()
        if excluded_artist_keys:
            excluded_tracks_before = len(tracks)
            tracks = [t for t in tracks if normalize_key(t.artist) not in excluded_artist_keys]
            excluded_tracks_removed = excluded_tracks_before - len(tracks)
            if excluded_tracks_removed:
                emit(_translate_key(locale, "status.excluded_tracks", count=excluded_tracks_removed))
        if options.verbose:
            _emit_profile_stage_diagnostics(
                emit=emit,
                locale=locale,
                settings=settings,
                spotify=spotify,
                musicbrainz=musicbrainz,
                lastfm=lastfm,
                listenbrainz=listenbrainz,
                deezer=deezer,
                tidal=tidal,
                apple_music=apple_music,
            )

        # Defensive cleanup: ensure no stale busy-phase header lingers into discovery output.
        if hasattr(busy, "clear"):
            try:
                busy.clear()
            except Exception:
                pass

        progress = phase1_progress
        if hasattr(progress, "enter_phase"):
            progress.enter_phase("[2/5] Running discovery")

        def _emit_prompt_spacer() -> None:
            # High-visibility spacer before any interactive prompt that may
            # appear while rich-live progress rendering is active.
            for _ in range(2):
                emit("")

        def _run_prompt_with_live_pause(prompt_fn: Callable[[], Any]) -> Any:
            paused = False
            if hasattr(progress, "pause"):
                try:
                    progress.pause()
                    paused = True
                except Exception:
                    paused = False
            try:
                _emit_prompt_spacer()
                return prompt_fn()
            finally:
                if paused and hasattr(progress, "resume"):
                    try:
                        progress.resume()
                    except Exception:
                        pass

        isrc_resolver = ISRCResolver(
            settings,
            storage,
            tidal=tidal if tidal and tidal.available else None,
            progress=progress,
        )
        deep_cuts, tiered_results = discovery_mode_to_flags(options.discovery_mode)
        emit(_translate_key(locale, "status.running_discovery"))
        emit("")

        heard_mbids = storage.all_heard_release_group_mbids() if hasattr(storage, "all_heard_release_group_mbids") else set()
        seed_keys = discovery_seed_track_keys or set()
        shortage_refill_continue_callback = options.shortage_refill_continue_callback
        if shortage_refill_continue_callback is not None:
            def _shortage_refill_continue_prompt(round_idx: int, current_count: int, target_limit: int) -> bool | None:
                def _ask() -> bool | None:
                    emit(
                        _translate_key(
                            locale,
                            "status.shortage_refill_prompt_context",
                            round=round_idx,
                            current=current_count,
                            limit=target_limit,
                        )
                    )
                    return shortage_refill_continue_callback(round_idx, current_count, target_limit)
                return _run_prompt_with_live_pause(_ask)
        else:
            _shortage_refill_continue_prompt = None
        if options.use_profile_expansion_memory is None:
            profile_memory_enabled = storage.profile_use_expansion_memories(profile_record["id"])
        else:
            profile_memory_enabled = bool(options.use_profile_expansion_memory)
        expansion_memory_seeds = (
            _merge_expansion_memory_items(storage.list_profile_expansion_memories(profile_record["id"]))
            if profile_memory_enabled
            else []
        )
        recommendations: list[ReleaseRecommendation] = []
        discovery_summary = DiscoverySummary()
        discovery_started_at = time.monotonic()
        try:
            effective_window = resolve_effective_window(
                discovery_window=options.discovery_window,
                months=options.months,
                today=dt.date.today(),
            )
            recommendations = discover_releases(
                input_tracks=tracks,
                musicbrainz=musicbrainz,
                listenbrainz=listenbrainz,
                lastfm=lastfm,
                spotify=spotify if spotify.available else None,
                deezer=deezer,
                tidal=tidal,
                heard_release_group_mbids=heard_mbids,
                months=options.months,
                discovery_window=options.discovery_window,
                limit=max(1, options.limit),
                deep_cuts=deep_cuts,
                tiered_results=tiered_results,
                emit=emit,
                isrc_resolver=isrc_resolver,
                max_tracks=max_tracks,
                seed_track_keys=seed_keys,
                profile=profile,
                storage=storage,
                force_refresh=options.force_refresh,
                penalize_frequent_artists=options.penalize_frequent_artists,
                max_candidates=options.max_candidates,
                min_seed_weight=options.min_seed_weight,
                progress=progress,
                run_deduplication=options.run_deduplication,
                excluded_artist_keys=excluded_artist_keys,
                use_streaming_providers=options.use_streaming_providers,
                debug=options.verbose,
                adaptive_small_seed_mode=options.adaptive_small_seed_mode,
                refill_after_heard=options.refill_after_heard,
                expansion_memory_seeds=expansion_memory_seeds,
                shortage_refill_continue_callback=_shortage_refill_continue_prompt,
            )
            recommendations = _filter_recommendations_by_window(recommendations, effective_window)
        finally:
            try:
                discovery_summary = getattr(progress, "_mamonia_discovery_summary", None) or progress.summary()
            except Exception:
                discovery_summary = DiscoverySummary()
        stage_timings_seconds["discovery_pipeline"] = round(time.monotonic() - discovery_started_at, 3)
        if options.verbose:
            counters_for_diag = getattr(storage, "_last_pipeline_counters", {}) or {}
            diag_candidates = counters_for_diag.get("selected_before_heard", discovery_summary.candidates_processed)
            diag_total = counters_for_diag.get("scored_candidates", discovery_summary.total_candidates)
            emit(
                _translate_key(locale, "status.v2_diagnostics",
                    candidates=diag_candidates,
                    total=(diag_total if diag_total is not None else '?'),
                    release_groups=discovery_summary.release_groups_checked,
                    accepted=discovery_summary.accepted,
                    spotify_misses=discovery_summary.spotify_misses,
                    musicbrainz_misses=discovery_summary.musicbrainz_misses)
            )
            if discovery_summary.skips:
                skip_text = ", ".join(
                    f"{reason}:{count}" for reason, count in sorted(discovery_summary.skips.items())
                )
                emit(_translate_key(locale, "status.v2_diagnostics_skips", skips=skip_text))
            if recommendations and len(recommendations) < options.limit:
                counters = getattr(storage, "_last_pipeline_counters", {}) or {}
                emit(
                    _translate_key(
                        locale,
                        "status.v2_low_output",
                        returned=len(recommendations),
                        limit=options.limit,
                        selected_before_heard=counters.get("selected_before_heard", 0),
                        dropped_by_heard=counters.get("dropped_by_heard", 0),
                        dropped_by_track_dedup=counters.get("dropped_by_track_dedup", 0),
                        refill_added=counters.get("refill_added", 0),
                        refill_attempted=counters.get("refill_attempted", 0),
                    )
                )
        if options.shuffle_releases and recommendations:
            recommendations = shuffle_recommendations(
                recommendations,
                seed=_shuffle_seed(profile_record["source_hash"], run_config_seed(options)),
            )
        memory_saved_count = 0
        counters_for_memory = getattr(storage, "_last_pipeline_counters", {}) or {}
        fallback_candidates = _merge_expansion_memory_items(
            list(counters_for_memory.get("fallback_memory_candidates", []) or [])
        )
        shortage_triggered = bool(counters_for_memory.get("shortage_fallback_triggered", False))
        should_prompt_save = bool(
            options.prompt_to_save_expansion_memory
            and options.expansion_memory_save_callback is not None
            and shortage_triggered
            and fallback_candidates
        )
        memory_save_accepted = False
        if should_prompt_save:
            def _ask_memory_save() -> bool | None:
                emit(
                    _translate_key(
                        locale,
                        "status.expansion_memories_prompt_context",
                        profile_id=profile_record["id"],
                        profile_name=profile_record["name"],
                    )
                )
                return options.expansion_memory_save_callback(int(profile_record["id"]), str(profile_record["name"]))
            response = _run_prompt_with_live_pause(_ask_memory_save)
            memory_save_accepted = bool(response)
            if memory_save_accepted:
                ranked = list(fallback_candidates)
                keep_n = max(1, len(ranked) // 2)
                for item in ranked[:keep_n]:
                    if storage.upsert_profile_expansion_memory(
                        profile_record["id"],
                        artist_name=str(item.get("artist_name") or ""),
                        provider=str(item.get("provider") or "unknown"),
                        tier=str(item.get("tier") or ""),
                        confidence=float(item.get("confidence") or 0.0),
                        score=float(item.get("score") or 0.0),
                        evidence=item.get("evidence") if isinstance(item.get("evidence"), dict) else {},
                        memory_version=1,
                    ):
                        memory_saved_count += 1
                if options.verbose:
                    emit(_translate_key(locale, "status.expansion_memories_saved", saved=memory_saved_count, total=keep_n))
        stage_timings_seconds["platform_id_backfill"] = 0.0
        if options.defer_platform_backfill:
            platform_backfill_started_at = time.monotonic()
            backfill_counters: dict[str, int | bool] = {}
            recovery_progress = progress
            if hasattr(recovery_progress, "enter_phase"):
                recovery_progress.enter_phase("[3/5] Resolving platform IDs")
            with busy.phase("[3/5] Resolving platform IDs", wait_texts["platform_lookup"]):
                if not options.dry_run and recommendations:
                    recovery_progress.stage_started("Resolving platform ID gaps", processed=0, total=len(recommendations))
                    backfill_counters = _recover_empty_recommendation_tracks(
                        recommendations,
                        spotify=spotify if spotify and spotify.available else None,
                        tidal=tidal if tidal and tidal.available else None,
                        musicbrainz=musicbrainz,
                        max_tracks=max_tracks,
                        seed_track_keys=seed_keys,
                        discovery_months=options.months,
                        discovery_window=options.discovery_window,
                        discovery_today=dt.date.today(),
                        attempts_state={},
                        progress_callback=lambda rec, processed, total: recovery_progress.candidate_started(
                            CandidateArtist(name=rec.artist, source="platform-backfill", score=0.0),
                            processed=processed,
                            total=total,
                        ),
                    )
                    setattr(storage, "_last_platform_backfill_counters", dict(backfill_counters))
            tidal_backfill_targets = 0
            tidal_backfill_matched = 0
            apple_backfill_targets = 0
            apple_backfill_matched = 0
            if not options.dry_run and recommendations:
                tidal_backfill_targets = sum(1 for rec in recommendations for track in rec.tracks if not track.tidal_track_id)
                tidal_progress = progress
                if hasattr(tidal_progress, "enter_phase"):
                    tidal_progress.enter_phase("[3/5] Resolving platform IDs")
                with busy.phase("[3/5] Resolving platform IDs", wait_texts["platform_lookup"]):
                    tidal_progress.stage_started("Resolving Tidal track IDs", processed=0, total=tidal_backfill_targets)
                    tidal_backfill_matched = _backfill_tidal_track_ids(
                        recommendations,
                        tidal if tidal and tidal.available else None,
                        storage=storage,
                        discovery_months=options.months,
                        discovery_window=options.discovery_window,
                        discovery_today=dt.date.today(),
                        progress_callback=lambda track, processed, total: tidal_progress.candidate_started(
                            CandidateArtist(name=f"{track.artists} - {track.title}", source="tidal-backfill", score=0.0),
                            processed=processed,
                            total=total,
                        ),
                    )
                if tidal_backfill_targets:
                    emit(_translate_key(locale, "status.tidal_backfill", matched=tidal_backfill_matched, targets=tidal_backfill_targets))
            stage_timings_seconds["platform_id_backfill"] = round(time.monotonic() - platform_backfill_started_at, 3)
            emit(
                _translate_key(
                    locale,
                    "status.phase_time",
                    phase="[3/5]",
                    elapsed=f"{stage_timings_seconds['platform_id_backfill']:.2f}",
                )
            )
            if options.verbose and backfill_counters:
                emit(
                    _translate_key(
                        locale,
                        "status.platform_backfill_diag",
                        attempted=backfill_counters.get("empty_track_recovery_attempted", 0),
                        reenrich=backfill_counters.get("recovered_via_reenrich", 0),
                        tidal_rescue=backfill_counters.get("recovered_via_tidal_release_rescue", 0),
                        spotify_rescue=backfill_counters.get("recovered_via_spotify_release_rescue", 0),
                        no_tracklist=backfill_counters.get("recovery_no_tracklist_after_recovery", 0),
                        budget_exhausted=("yes" if backfill_counters.get("recovery_budget_exhausted") else "no"),
                    )
                )
        
        # Full enrichment runs in run_v2_pipeline for selected recommendations.
        recommendations, dropped_post_backfill_heard = _drop_heard_recommendations(storage, recommendations)
        if dropped_post_backfill_heard and options.verbose:
            emit(
                f"[v2] Post-backfill heard exclusion removed {dropped_post_backfill_heard} recommendation(s)."
            )
        
        _print_provider_warnings(
            [spotify, musicbrainz, lastfm, listenbrainz, deezer],
            emit_error,
            verbose=options.verbose,
            stage="discovery",
            locale=locale,
        )
        
        # Print detailed enrichment summary
        total = len(recommendations)
        spotify_resolved = sum(1 for rec in recommendations for track in rec.tracks if track.spotify_track_id)
        deezer_resolved = sum(1 for rec in recommendations for track in rec.tracks if hasattr(track, 'deezer_track_id') and track.deezer_track_id)
        tidal_resolved = sum(1 for rec in recommendations for track in rec.tracks if hasattr(track, 'tidal_track_id') and track.tidal_track_id)
        apple_resolved = sum(1 for rec in recommendations for track in rec.tracks if getattr(track, "apple_music_track_id", None))
        musicbrainz_resolved = sum(1 for rec in recommendations for track in rec.tracks if track.resolution_source == "musicbrainz_tracklist")
        with_isrc = sum(1 for rec in recommendations for track in rec.tracks if track.isrc)
        total_tracks = sum(len(rec.tracks) for rec in recommendations)
        
        emit("")
        emit(_translate_key(locale, "status.enrichment_summary"))
        emit(_translate_key(locale, "status.total_releases", total=total))
        emit(_translate_key(locale, "status.total_tracks", total_tracks=total_tracks))
        emit(_translate_key(locale, "status.resolved_spotify", count=spotify_resolved))
        emit(_translate_key(locale, "status.resolved_deezer", count=deezer_resolved))
        emit(_translate_key(locale, "status.resolved_tidal", count=tidal_resolved))
        emit(_translate_key(locale, "status.resolved_apple_music", count=apple_resolved))
        emit(_translate_key(locale, "status.resolved_musicbrainz", count=musicbrainz_resolved))
        emit(_translate_key(locale, "status.tracks_with_isrc", count=with_isrc))
        if total_tracks > 0:
            emit(_translate_key(locale, "status.isrc_coverage", percent=round(with_isrc * 100 / total_tracks)))
        
        emit(_translate_key(locale, "status.found_recommendations", count=len(recommendations)))
        emit("")

        run_config = {
            "months": options.months,
            "discovery_window_start": options.discovery_window.start_date.isoformat() if options.discovery_window else None,
            "discovery_window_end": options.discovery_window.end_date.isoformat() if options.discovery_window else None,
            "max_tracks": max_tracks,
            "output": output_format,
            "limit": options.limit,
            "max_candidates": options.max_candidates,
            "discovery_mode": options.discovery_mode,
            "deep_cuts": deep_cuts,
            "tiered_results": tiered_results,
            "profile_id": profile_record["id"],
            "profile_state": profile_state,
            "dry_run": options.dry_run,
            "global_memory": effective_global_memory,
            "penalize_frequent_artists": options.penalize_frequent_artists,
            "shuffle_releases": options.shuffle_releases,
            "use_streaming_providers": options.use_streaming_providers,
            "create_spotify_playlist": options.create_spotify_playlist,
            "create_tidal_playlist": options.create_tidal_playlist,
            "create_apple_playlist": options.create_apple_playlist,
            "apple_target_playlist": options.apple_target_playlist,
            "save_selection_logic": options.save_selection_logic,
            "discovery_summary": _summary_payload(discovery_summary),
            "spotify_cache": _spotify_cache_summary(spotify),
            "stage_timings_seconds": dict(stage_timings_seconds),
            "provider_metrics": _provider_metrics_summary(
                spotify=spotify,
                musicbrainz=musicbrainz,
                lastfm=lastfm,
                listenbrainz=listenbrainz,
                deezer=deezer,
                tidal=tidal,
                storage=storage,
            ),
            "optimization_status": _optimization_status(
                options=options,
                spotify=spotify,
                tracks=tracks,
                settings=settings,
            ),
            "adaptive_small_seed_mode": options.adaptive_small_seed_mode,
            "refill_after_heard": options.refill_after_heard,
            "defer_platform_backfill": options.defer_platform_backfill,
            "use_profile_expansion_memory": profile_memory_enabled,
            "use_profile_expansion_memory_override": options.use_profile_expansion_memory,
            "shortage_fallback_triggered": shortage_triggered,
            "fallback_candidates_total": len(fallback_candidates),
            "memory_prompt_shown": should_prompt_save,
            "memory_save_accepted": memory_save_accepted,
            "memory_saved_count": memory_saved_count,
            "memory_used_count": len(expansion_memory_seeds),
        }
        heard_diag = getattr(storage, "_last_heard_discovery_diagnostics", None)
        if isinstance(heard_diag, dict):
            run_config["heard_exclusion_summary"] = dict(heard_diag)
        heard_sparsity = getattr(storage, "_last_heard_row_sparsity", None)
        if isinstance(heard_sparsity, dict):
            run_config["heard_row_sparsity"] = dict(heard_sparsity)
        pipeline_counters = getattr(storage, "_last_pipeline_counters", None)
        if isinstance(pipeline_counters, dict):
            run_config["pipeline_counters"] = dict(pipeline_counters)
        platform_backfill_counters = getattr(storage, "_last_platform_backfill_counters", None)
        if isinstance(platform_backfill_counters, dict):
            run_config["platform_backfill_counters"] = dict(platform_backfill_counters)
        if not recommendations:
            storage.record_run(recommendations, config=run_config, source_hash=profile_record["source_hash"])
            if hasattr(progress, "finish"):
                progress.finish()
            emit(_translate_key(locale, "status.no_output"))
            if options.dry_run:
                _print_discovery_summary(discovery_summary, emit, locale)
            emit(_translate_key(locale, "status.done"))
            emit("")
            _print_recommendations(recommendations, emit, locale)
            return

        destination = options.output_path or _default_output_path(output_format, source_name=profile_record["name"])
        if options.dry_run:
            storage.record_run(recommendations, config=run_config, source_hash=profile_record["source_hash"])
            if hasattr(progress, "finish"):
                progress.finish()
            emit(_translate_key(locale, "status.dry_run"))
            _print_discovery_summary(discovery_summary, emit, locale)
            emit(_translate_key(locale, "status.done"))
            emit("")
            _elapsed = time.monotonic() - _start_time
            emit(_translate_key(locale, "status.total_time", elapsed=f"{_elapsed:.2f}"))
            _print_recommendations(recommendations, emit, locale)
            return

        # Persist output recommendations to heard memory before writing files so a late
        # export failure does not leave this run untracked for future dedup/exclusion.
        heard_count = auto_mark_exported_releases(
            storage,
            recommendations,
            session_id=session_id,
            profile_name=profile_name,
        )
        with busy.phase("[4/5] Writing output", wait_texts["write_output"]):
            if hasattr(progress, "enter_phase"):
                progress.enter_phase("[4/5] Writing output")
            write_recommendations(recommendations, output_format, destination)
            storage.record_run(recommendations, config=run_config, source_hash=profile_record["source_hash"])
        # Freeze the stopwatch at export completion so post-write prompts
        # (e.g. expandable availability details) do not inflate run time.
        _elapsed_after_write = time.monotonic() - _start_time
        emit(_translate_key(locale, "status.wrote_output", destination=str(destination)))
        emit(_translate_key(locale, "status.total_time", elapsed=f"{_elapsed_after_write:.2f}"))
        if output_format == "csv":
            if hasattr(progress, "pause"):
                progress.pause()
            try:
                emit_collapsible_availability_notice(recommendations, emit, locale)
            finally:
                if hasattr(progress, "resume"):
                    progress.resume()
        if recommendations:
            emit(_translate_key(locale, "status.added_heard", count=heard_count))
        emit("")
        emit(_translate_key(locale, "status.done"))
        if hasattr(progress, "finish"):
            progress.finish()
        _print_recommendations(recommendations, emit, locale)

        # Resolve effective playlist config (interactive callback overrides options fields)
        _eff_create_spotify = options.create_spotify_playlist
        _eff_spotify_name = options.spotify_playlist_name
        _eff_create_tidal = options.create_tidal_playlist
        _eff_tidal_name = options.tidal_playlist_name
        _eff_create_apple = options.create_apple_playlist
        _eff_apple_name = options.apple_playlist_name
        _eff_apple_target = options.apple_target_playlist
        if options.playlist_config_callback is not None:
            _cb_result = _run_prompt_with_live_pause(options.playlist_config_callback)
            if _cb_result is not None:
                (
                    _eff_create_spotify,
                    _eff_spotify_name,
                    _eff_create_tidal,
                    _eff_tidal_name,
                    _eff_create_apple,
                    _eff_apple_name,
                    _eff_apple_target,
                ) = _cb_result
            else:
                _eff_create_spotify = False
                _eff_create_tidal = False
                _eff_create_apple = False

        playlist_results: dict[str, dict[str, str | bool | None]] = {}
        if _eff_create_spotify:
            uris = [track.spotify_uri for rec in recommendations for track in rec.tracks if track.spotify_uri]
            name = _eff_spotify_name or _spotify_playlist_name(profile_record["name"])
            playlist_result = spotify.create_playlist(name, _translate_key(locale, "status.generated_by_mamonia"), uris)
            playlist_results["spotify"] = {
                "created": playlist_result.created,
                "url": playlist_result.url,
                "reason": playlist_result.reason,
                "name": name,
            }
            _print_provider_warnings([spotify], emit_error, verbose=options.verbose, stage="playlist_creation", locale=locale)
            if playlist_result.created:
                emit(_translate_key(locale, "status.spotify_playlist_created", url=playlist_result.url or '(URL unavailable)'))
            elif playlist_result.reason == "no_uris":
                emit(_translate_key(locale, "status.spotify_playlist_no_uris"))
            elif playlist_result.reason == "rate_limited":
                emit(_translate_key(locale, "status.spotify_playlist_rate_limited"))
            else:
                reason = _safe_error(Exception(playlist_result.reason or "unknown Spotify error"))
                if any(token in reason for token in ("playlist-modify", "Insufficient client scope", "authentication failed", "denied access")):
                    guidance = getattr(spotify, "permission_guidance", None)
                    if callable(guidance):
                        reason = f"{reason}. {guidance('creating playlist')}"
                emit(_translate_key(locale, "status.spotify_playlist_error", reason=reason))

        if _eff_create_tidal:
            tidal_ids = [track.tidal_track_id for rec in recommendations for track in rec.tracks if track.tidal_track_id]
            unique_tidal_ids = list(dict.fromkeys(tidal_ids))
            duplicates_dropped = len(tidal_ids) - len(unique_tidal_ids)
            emit(_translate_key(locale, "status.tidal_unique_ids", count=len(unique_tidal_ids)))
            emit(_translate_key(locale, "status.tidal_duplicates_dropped", count=duplicates_dropped))
            name = _eff_tidal_name or _tidal_playlist_name(profile_record["name"])
            creator = getattr(tidal, "create_playlist", None)
            if not callable(creator):
                playlist_results["tidal"] = {
                    "created": False,
                    "url": None,
                    "reason": "unsupported",
                    "name": name,
                }
                emit(_translate_key(locale, "status.tidal_playlist_unsupported"))
            else:
                playlist_result = creator(name, _translate_key(locale, "status.generated_by_mamonia"), unique_tidal_ids)
                playlist_results["tidal"] = {
                    "created": bool(getattr(playlist_result, "created", False)),
                    "url": getattr(playlist_result, "url", None),
                    "reason": getattr(playlist_result, "reason", None),
                    "name": name,
                }
                if getattr(playlist_result, "created", False):
                    emit(_translate_key(locale, "status.tidal_playlist_created", url=getattr(playlist_result, 'url', None) or '(URL unavailable)'))
                elif getattr(playlist_result, "reason", None) == "no_ids":
                    emit(_translate_key(locale, "status.tidal_playlist_no_ids"))
                elif getattr(playlist_result, "reason", None) == "unsupported":
                    emit(_translate_key(locale, "status.tidal_playlist_unsupported_version"))
                else:
                    reason = _safe_error(Exception(getattr(playlist_result, "reason", None) or "unknown Tidal error"))
                    emit(_translate_key(locale, "status.tidal_playlist_error", reason=reason))

        if _eff_create_apple or _eff_apple_target:
            apple_backfill_targets = sum(1 for rec in recommendations for track in rec.tracks if not track.apple_music_track_id)
            if apple_backfill_targets:
                apple_backfill_matched = _backfill_apple_music_track_ids(
                    recommendations,
                    apple_music if apple_music and apple_music.available else None,
                )
                emit(_translate_key(locale, "status.apple_music_backfill", matched=apple_backfill_matched, targets=apple_backfill_targets))
            apple_ids = [track.apple_music_track_id for rec in recommendations for track in rec.tracks if track.apple_music_track_id]
            unique_apple_ids = list(dict.fromkeys(apple_ids))
            name = _eff_apple_name or _apple_music_playlist_name(profile_record["name"])
            if _eff_apple_target:
                playlist_result = apple_music.add_tracks_to_playlist(_eff_apple_target, unique_apple_ids)
                playlist_results["apple_music"] = {
                    "created": bool(getattr(playlist_result, "created", False)),
                    "url": getattr(playlist_result, "url", None),
                    "reason": getattr(playlist_result, "reason", None),
                    "name": name,
                    "target_playlist": _eff_apple_target,
                }
                if getattr(playlist_result, "created", False):
                    emit(_translate_key(locale, "status.apple_music_playlist_appended", url=getattr(playlist_result, 'url', None) or '(URL unavailable)'))
                elif getattr(playlist_result, "reason", None) == "no_ids":
                    emit(_translate_key(locale, "status.apple_music_playlist_no_ids"))
                elif getattr(playlist_result, "reason", None) == "rate_limited":
                    emit(_translate_key(locale, "status.apple_music_playlist_rate_limited"))
                else:
                    reason = _safe_error(Exception(getattr(playlist_result, "reason", None) or "unknown Apple Music error"))
                    emit(_translate_key(locale, "status.apple_music_playlist_error", reason=reason))
            elif _eff_create_apple:
                playlist_result = apple_music.create_playlist(name, _translate_key(locale, "status.generated_by_mamonia"), unique_apple_ids)
                playlist_results["apple_music"] = {
                    "created": bool(getattr(playlist_result, "created", False)),
                    "url": getattr(playlist_result, "url", None),
                    "reason": getattr(playlist_result, "reason", None),
                    "name": name,
                }
                if getattr(playlist_result, "created", False):
                    emit(_translate_key(locale, "status.apple_music_playlist_created", url=getattr(playlist_result, 'url', None) or '(URL unavailable)'))
                elif getattr(playlist_result, "reason", None) == "no_ids":
                    emit(_translate_key(locale, "status.apple_music_playlist_no_ids"))
                elif getattr(playlist_result, "reason", None) == "rate_limited":
                    emit(_translate_key(locale, "status.apple_music_playlist_rate_limited"))
                else:
                    reason = _safe_error(Exception(getattr(playlist_result, "reason", None) or "unknown Apple Music error"))
                    emit(_translate_key(locale, "status.apple_music_playlist_error", reason=reason))

        if options.save_selection_logic:
            logic_destination = options.selection_logic_path or _default_selection_logic_path(profile_record["name"])
            write_selection_logic(
                recommendations,
                logic_destination,
                run_config=run_config,
                profile={
                    "id": profile_record["id"],
                    "name": profile_record["name"],
                    "source_type": profile_record["source_type"],
                    "profile_state": profile_state,
                    "track_count": profile_record["track_count"],
                    "artist_count": profile_record["artist_count"],
                },
                output={
                    "format": output_format,
                    "path": str(destination),
                    "heard_count": heard_count,
                },
                playlist_results=playlist_results,
            )
            emit(_translate_key(locale, "status.selection_logic_written", destination=str(logic_destination)))


def _maybe_delta_update_profile(
    *,
    storage: Storage,
    settings: object,
    source: dict[str, str],
    profile_record: dict,
    current_tracks: list[InputTrack],
    spotify: SpotifyProvider,
    musicbrainz: MusicBrainzProvider,
    lastfm: LastFMProvider,
    listenbrainz: ListenBrainzProvider,
    deezer: DeezerProvider,
    tidal: TidalProvider | None = None,
    decision_callback: ProfileDecisionChooser | None = None,
    emit: Emitter,
    emit_error: Emitter,
    verbose: bool = False,
    locale: str = DEFAULT_LANGUAGE,
) -> tuple[TasteProfile, list[InputTrack], set[str], dict, str]:
    previous_profile, previous_tracks, previous_seed_track_keys = _profile_from_record(profile_record)
    diff = diff_playlist_tracks(previous_tracks, current_tracks)
    decision = _choose_profile_decision(
        storage=storage,
        profile_record=profile_record,
        profile=previous_profile,
        previous_tracks=previous_tracks,
        current_tracks=current_tracks,
        changed=diff.changed,
        added_count=diff.added_count,
        removed_count=diff.removed_count,
        decision_callback=decision_callback,
        emit=emit,
    )
    if decision == "reuse":
        storage.touch_taste_profile(profile_record["id"])
        emit(_translate_key(locale, "status.keeping_profile"))
        return previous_profile, previous_tracks, previous_seed_track_keys, profile_record, "reused"
    if decision == "refresh_enrichment":
        profile, seed_track_keys, profile_record = _refresh_profile_enrichment(
            storage=storage,
            settings=settings,
            source=source,
            previous_profile=previous_profile,
            tracks=current_tracks,
            spotify=spotify,
            musicbrainz=musicbrainz,
            lastfm=lastfm,
            listenbrainz=listenbrainz,
            deezer=deezer,
            tidal=tidal,
            emit=emit,
            emit_error=emit_error,
            verbose=verbose,
            locale=locale,
        )
        emit(_translate_key(locale, "status.refreshed_enrichment"))
        return profile, current_tracks, seed_track_keys, profile_record, "enrichment-refreshed"
    if decision == "fresh_rebuild":
        profile, seed_track_keys, profile_record = _build_and_store_profile(
            storage=storage,
            settings=settings,
            source=source,
            tracks=current_tracks,
            spotify=spotify,
            musicbrainz=musicbrainz,
            lastfm=lastfm,
            listenbrainz=listenbrainz,
            deezer=deezer,
            tidal=tidal,
            emit=emit,
            emit_error=emit_error,
            verbose=verbose,
            locale=locale,
        )
        emit(_translate_key(locale, "status.rebuilt_profile"))
        return profile, current_tracks, seed_track_keys, profile_record, "fresh-rebuilt"
    if not diff.changed:
        current_seed_track_keys = track_keys_from_input(current_tracks)
        _store_input_track_enrichment(storage, current_tracks, spotify=spotify)
        profile_record = storage.upsert_taste_profile(
            name=source["name"],
            source_type=source["source_type"],
            source_ref=source["source_ref"],
            source_key=profile_record["source_key"],
            source_hash=source["source_hash"],
            track_count=len(current_tracks),
            artist_count=previous_profile.n_artists,
            profile=previous_profile,
            seed_tracks=current_tracks,
            seed_track_keys=current_seed_track_keys,
        )
        _save_latest_profile(settings.data_dir / "last_profile.json", previous_profile.model_dump(mode="json"))
        emit(_translate_key(locale, "status.no_delta"))
        return previous_profile, current_tracks, current_seed_track_keys, profile_record, "unchanged"

    if decision != "delta_update" and not prompt_delta_update(diff.added_count, diff.removed_count, _format_last_seen(profile_record.get("updated_at"))):
        storage.touch_taste_profile(profile_record["id"])
        emit(_translate_key(locale, "status.keeping_profile"))
        return previous_profile, previous_tracks, previous_seed_track_keys, profile_record, "reused"

    added_tracks = diff.added
    spotify_artist_metadata = (
        _spotify_profile_artist_metadata(spotify, added_tracks)
        if spotify.available and added_tracks
        else {}
    )
    profile = build_taste_profile_reusing_artists(
        current_tracks,
        existing_profile=previous_profile,
        spotify=spotify if spotify.available else None,
        musicbrainz=musicbrainz,
        lastfm=lastfm,
        listenbrainz=listenbrainz if listenbrainz.available else None,
        deezer=deezer,
        spotify_artist_metadata=spotify_artist_metadata,
        settings=settings,
    )
    _print_provider_warnings(
        [spotify, musicbrainz, lastfm, listenbrainz, deezer],
        emit_error,
        verbose=verbose,
        stage="profile",
    )
    seed_track_keys = track_keys_from_input(current_tracks)
    _store_input_track_enrichment(storage, current_tracks, spotify=spotify)
    profile_record = storage.upsert_taste_profile(
        name=source["name"],
        source_type=source["source_type"],
        source_ref=source["source_ref"],
        source_key=profile_record["source_key"],
        source_hash=source["source_hash"],
        track_count=len(current_tracks),
        artist_count=profile.n_artists,
        profile=profile,
        seed_tracks=current_tracks,
        seed_track_keys=seed_track_keys,
    )
    _save_latest_profile(settings.data_dir / "last_profile.json", profile.model_dump(mode="json"))
    emit(
        _translate_key(locale, "status.delta_applied", added=diff.added_count, removed=diff.removed_count)
    )
    return profile, current_tracks, seed_track_keys, profile_record, "delta-updated"


def _build_and_store_profile(
    *,
    storage: Storage,
    settings: object,
    source: dict[str, str],
    tracks: list[InputTrack],
    spotify: SpotifyProvider,
    musicbrainz: MusicBrainzProvider,
    lastfm: LastFMProvider,
    listenbrainz: ListenBrainzProvider,
    deezer: DeezerProvider,
    tidal: TidalProvider | None = None,
    emit: Emitter = print,
    emit_error: Emitter,
    verbose: bool = False,
    locale: str = DEFAULT_LANGUAGE,
) -> tuple[TasteProfile, set[str], dict]:
    spotify_artist_metadata = _spotify_profile_artist_metadata(spotify, tracks) if spotify.available else {}
    profile = build_taste_profile(
        tracks,
        spotify=spotify if spotify.available else None,
        musicbrainz=musicbrainz,
        lastfm=lastfm,
        listenbrainz=listenbrainz if listenbrainz.available else None,
        deezer=deezer,
        spotify_artist_metadata=spotify_artist_metadata,
        settings=settings,
    )
    _print_provider_warnings(
        [spotify, musicbrainz, lastfm, listenbrainz, deezer],
        emit_error,
        verbose=verbose,
        stage="profile",
        locale=locale,
    )
    seed_track_keys = track_keys_from_input(tracks)
    _store_input_track_enrichment(storage, tracks, spotify=spotify)
    profile_record = storage.upsert_taste_profile(
        name=source["name"],
        source_type=source["source_type"],
        source_ref=source["source_ref"],
        source_key=source["source_key"],
        source_hash=source["source_hash"],
        track_count=len(tracks),
        artist_count=profile.n_artists,
        profile=profile,
        seed_tracks=tracks,
        seed_track_keys=seed_track_keys,
    )
    profile_name = str(source["name"])
    session_timestamp = dt.datetime.now()
    session_id = f"{profile_name}_{session_timestamp.strftime('%d%m%Y_%H%M')}"
    # Mark input releases as heard to prevent them from being recommended
    marked = _mark_input_releases_as_heard(
        storage, tracks, spotify=spotify, musicbrainz=musicbrainz, tidal=tidal,
        session_id=session_id, profile_name=profile_name
    )
    if marked > 0:
        emit(_translate_key(locale, "status.marked_input", count=marked))
    _save_latest_profile(settings.data_dir / "last_profile.json", profile.model_dump(mode="json"))
    return profile, seed_track_keys, profile_record


def _refresh_profile_enrichment(
    *,
    storage: Storage,
    settings: object,
    source: dict[str, str],
    previous_profile: TasteProfile,
    tracks: list[InputTrack],
    spotify: SpotifyProvider,
    musicbrainz: MusicBrainzProvider,
    lastfm: LastFMProvider,
    listenbrainz: ListenBrainzProvider,
    deezer: DeezerProvider,
    tidal: TidalProvider | None = None,
    emit: Emitter = print,
    emit_error: Emitter,
    verbose: bool = False,
    locale: str = DEFAULT_LANGUAGE,
) -> tuple[TasteProfile, set[str], dict]:
    spotify_artist_metadata = _spotify_profile_artist_metadata(spotify, tracks) if spotify.available else {}
    profile = build_taste_profile_reusing_artists(
        tracks,
        existing_profile=previous_profile,
        spotify=spotify if spotify.available else None,
        musicbrainz=musicbrainz,
        lastfm=lastfm,
        listenbrainz=listenbrainz if listenbrainz.available else None,
        deezer=deezer,
        spotify_artist_metadata=spotify_artist_metadata,
        settings=settings,
    )
    _print_provider_warnings(
        [spotify, musicbrainz, lastfm, listenbrainz, deezer],
        emit_error,
        verbose=verbose,
        stage="profile",
        locale=locale,
    )
    seed_track_keys = track_keys_from_input(tracks)
    _store_input_track_enrichment(storage, tracks, spotify=spotify)
    profile_record = storage.upsert_taste_profile(
        name=source["name"],
        source_type=source["source_type"],
        source_ref=source["source_ref"],
        source_key=source["source_key"],
        source_hash=source["source_hash"],
        track_count=len(tracks),
        artist_count=profile.n_artists,
        profile=profile,
        seed_tracks=tracks,
        seed_track_keys=seed_track_keys,
    )
    profile_name = str(source["name"])
    session_timestamp = dt.datetime.now()
    session_id = f"{profile_name}_{session_timestamp.strftime('%d%m%Y_%H%M')}"
    # Mark input releases as heard to prevent them from being recommended
    marked = _mark_input_releases_as_heard(
        storage, tracks, spotify=spotify, musicbrainz=musicbrainz, tidal=tidal,
        session_id=session_id, profile_name=profile_name
    )
    if marked > 0:
        emit(_translate_key(locale, "status.marked_input", count=marked))
    _save_latest_profile(settings.data_dir / "last_profile.json", profile.model_dump(mode="json"))
    return profile, seed_track_keys, profile_record


def _choose_profile_decision(
    *,
    storage: Storage,
    profile_record: dict,
    profile: TasteProfile,
    previous_tracks: list[InputTrack],
    current_tracks: list[InputTrack],
    changed: bool,
    added_count: int,
    removed_count: int,
    decision_callback: ProfileDecisionChooser | None,
    emit: Emitter | None = None,
) -> ProfileDecisionAction | None:
    if decision_callback is None:
        return None
    if emit is not None:
        for _ in range(8):
            emit("")
    decision = decision_callback(
        ProfileDecisionContext(
            profile_id=int(profile_record["id"]),
            profile_name=str(profile_record["name"]),
            source_type=str(profile_record["source_type"]),
            changed=changed,
            added_count=added_count,
            removed_count=removed_count,
            saved_track_count=len(previous_tracks),
            current_track_count=len(current_tracks),
            enrichment_complete=_profile_enrichment_complete(storage, profile, previous_tracks),
        )
    )
    if decision not in {None, "reuse", "delta_update", "refresh_enrichment", "fresh_rebuild"}:
        raise WorkflowAbort(f"Unknown profile decision: {decision}")
    return decision


def _profile_enrichment_complete(storage: Storage, profile: TasteProfile, tracks: list[InputTrack]) -> bool:
    return storage.enrichment_completeness(artists=profile.artists, tracks=tracks).complete


def _find_equivalent_profile(storage: Storage, tracks: list[InputTrack]) -> dict | None:
    fingerprint = portable_track_set_hash(tracks)
    if not fingerprint:
        return None
    current_count = len(tracks)
    for profile_summary in storage.list_taste_profiles():
        profile_record = storage.get_taste_profile(profile_summary["id"])
        if not profile_record:
            continue
        _, saved_tracks, _ = _profile_from_record(profile_record)
        if len(saved_tracks) != current_count:
            continue
        if portable_track_set_hash(saved_tracks) == fingerprint:
            return storage.get_taste_profile(profile_record["id"])
    return None


def _merge_seed_track_metadata(saved_tracks: list[InputTrack], current_tracks: list[InputTrack]) -> list[InputTrack]:
    current_by_key: dict[str, list[InputTrack]] = {}
    for track in current_tracks:
        current_by_key.setdefault(portable_track_key(track), []).append(track)

    merged: list[InputTrack] = []
    for saved in saved_tracks:
        candidates = current_by_key.get(portable_track_key(saved), [])
        current = candidates.pop(0) if candidates else None
        merged.append(_merge_input_track(saved, current) if current else saved)
    return merged


def _merge_input_track(saved: InputTrack, current: InputTrack) -> InputTrack:
    saved_data = saved.model_dump(mode="python")
    current_data = current.model_dump(mode="python")
    for key, value in current_data.items():
        if value in (None, "", []):
            continue
        existing = saved_data.get(key)
        if isinstance(existing, list) or isinstance(value, list):
            saved_data[key] = _merge_lists(existing if isinstance(existing, list) else [], value if isinstance(value, list) else [])
            continue
        if existing in (None, ""):
            saved_data[key] = value
    return InputTrack.model_validate(saved_data)


def _filter_recommendations_by_window(
    recommendations: list[ReleaseRecommendation],
    window: DiscoveryWindow,
) -> list[ReleaseRecommendation]:
    out: list[ReleaseRecommendation] = []
    for rec in recommendations:
        parsed = dt.date.fromisoformat(rec.release_date[:10]) if rec.release_date and len(rec.release_date) >= 10 else None
        if parsed is None:
            # Fall back to legacy parse logic for partial dates.
            from .utils import parse_date

            parsed = parse_date(rec.release_date)
        if parsed is None:
            continue
        if window.start_date <= parsed <= window.end_date:
            out.append(rec)
    return out


def _backfill_tidal_track_ids(
    recommendations: list[ReleaseRecommendation],
    tidal: TidalProvider | None,
    *,
    storage: Storage | None = None,
    discovery_months: int | None = None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
    progress_callback: Callable[[ReleaseTrack, int, int], None] | None = None,
) -> int:
    if tidal is None:
        return 0
    lookup_with_window = getattr(tidal, "lookup_track_with_window", None)
    lookup = getattr(tidal, "lookup_track", None)
    if not callable(lookup) and not callable(lookup_with_window):
        return 0
    resolved = 0
    total_missing = sum(1 for rec in recommendations for track in rec.tracks if not track.tidal_track_id)
    processed_missing = 0
    staged_lookup_cache: dict[tuple[str, str, str, str, str], dict | None] = {}
    isrc_lookup_cache: dict[str, dict | None] = {}
    album_payload_cache: dict[str, Any | None] = {}
    for rec in recommendations:
        for track in rec.tracks:
            if track.tidal_track_id:
                continue
            processed_missing += 1
            if progress_callback is not None:
                progress_callback(track, processed_missing, total_missing)
            cached = _cached_tidal_track_match(storage, track, rec.title)
            if cached is not None:
                if _apply_tidal_track_payload(track, cached):
                    resolved += 1
                continue
            isrc_key = (track.isrc or "").strip().upper()
            lookup_by_isrc = getattr(tidal, "lookup_track_by_isrc", None)
            if isrc_key and callable(lookup_by_isrc):
                if isrc_key in isrc_lookup_cache:
                    isrc_payload = isrc_lookup_cache[isrc_key]
                else:
                    by_isrc = lookup_by_isrc(isrc_key)
                    isrc_payload = (
                        {
                            "tidal_track_id": getattr(by_isrc, "track_id", None),
                            "tidal_album_id": getattr(by_isrc, "album_id", None),
                            "isrc": getattr(by_isrc, "isrc", None),
                            "title": getattr(by_isrc, "title", None),
                            "artists": getattr(by_isrc, "artists", None),
                            "match_stage": getattr(by_isrc, "stage", None) or "isrc",
                            "source": "recommendation_lookup_isrc",
                            "lookup_version": TIDAL_TRACK_LOOKUP_CACHE_VERSION,
                        }
                        if by_isrc
                        else None
                    )
                    isrc_lookup_cache[isrc_key] = isrc_payload
                if isrc_payload and _apply_tidal_track_payload(track, isrc_payload):
                    resolved += 1
                    if storage is not None:
                        storage.upsert_track_enrichment(
                            provider="tidal",
                            artist=track.artists,
                            title=track.title,
                            album=rec.title,
                            isrc=track.isrc,
                            tidal_track_id=track.tidal_track_id,
                            tidal_album_id=track.tidal_album_id,
                            payload=isrc_payload,
                        )
                    continue
            match = None
            lookup_key = (
                normalize_key(track.artists or ""),
                normalize_key(track.title or ""),
                normalize_key(rec.title or ""),
                normalize_key(track.isrc or ""),
                normalize_key(rec.release_date or ""),
            )
            if callable(lookup_with_window):
                if lookup_key in staged_lookup_cache:
                    cached_payload = staged_lookup_cache[lookup_key]
                    if cached_payload:
                        match = type("_TidalCachedMatch", (), {
                            "track_id": cached_payload.get("tidal_track_id"),
                            "album_id": cached_payload.get("tidal_album_id"),
                            "isrc": cached_payload.get("isrc"),
                            "title": cached_payload.get("title"),
                            "artists": cached_payload.get("artists"),
                            "stage": cached_payload.get("match_stage"),
                        })()
                else:
                    try:
                        match = lookup_with_window(
                            track.artists,
                            track.title,
                            rec.title,
                            track.isrc,
                            release_date=rec.release_date,
                            discovery_months=discovery_months,
                            discovery_window=discovery_window,
                            discovery_today=discovery_today,
                        )
                    except TypeError:
                        match = lookup_with_window(
                            track.artists,
                            track.title,
                            rec.title,
                            track.isrc,
                            release_date=rec.release_date,
                            discovery_months=discovery_months,
                            discovery_today=discovery_today,
                        )
                    staged_lookup_cache[lookup_key] = (
                        {
                            "tidal_track_id": getattr(match, "track_id", None),
                            "tidal_album_id": getattr(match, "album_id", None),
                            "isrc": getattr(match, "isrc", None),
                            "title": getattr(match, "title", None),
                            "artists": getattr(match, "artists", None),
                            "match_stage": getattr(match, "stage", None) or "metadata_in_window",
                        }
                        if match
                        else None
                    )
            elif callable(lookup):
                match = lookup(track.artists, track.title, rec.title, track.isrc)
            if not match:
                # Retry without album constraint in case release title metadata
                # diverges across providers (common for singles/OST variants),
                # even when release title is plain text (e.g., "On Time").
                if callable(lookup_with_window):
                    fallback_lookup_key = (
                        normalize_key(track.artists or ""),
                        normalize_key(track.title or ""),
                        "",
                        normalize_key(track.isrc or ""),
                        normalize_key(rec.release_date or ""),
                    )
                    if fallback_lookup_key in staged_lookup_cache:
                        cached_payload = staged_lookup_cache[fallback_lookup_key]
                        if cached_payload:
                            match = type("_TidalCachedMatch", (), {
                                "track_id": cached_payload.get("tidal_track_id"),
                                "album_id": cached_payload.get("tidal_album_id"),
                                "isrc": cached_payload.get("isrc"),
                                "title": cached_payload.get("title"),
                                "artists": cached_payload.get("artists"),
                                "stage": cached_payload.get("match_stage"),
                            })()
                    else:
                        try:
                            match = lookup_with_window(
                                track.artists,
                                track.title,
                                None,
                                track.isrc,
                                release_date=rec.release_date,
                                discovery_months=discovery_months,
                                discovery_window=discovery_window,
                                discovery_today=discovery_today,
                            )
                        except TypeError:
                            match = lookup_with_window(
                                track.artists,
                                track.title,
                                None,
                                track.isrc,
                                release_date=rec.release_date,
                                discovery_months=discovery_months,
                                discovery_today=discovery_today,
                            )
                        staged_lookup_cache[fallback_lookup_key] = (
                            {
                                "tidal_track_id": getattr(match, "track_id", None),
                                "tidal_album_id": getattr(match, "album_id", None),
                                "isrc": getattr(match, "isrc", None),
                                "title": getattr(match, "title", None),
                                "artists": getattr(match, "artists", None),
                                "match_stage": getattr(match, "stage", None) or "metadata_in_window",
                            }
                            if match
                            else None
                        )
                elif callable(lookup):
                    match = lookup(track.artists, track.title, None, track.isrc)
            if not match:
                album_match_payload = _tidal_match_from_release_album(tidal, rec, track, album_cache=album_payload_cache)
                if _apply_tidal_track_payload(track, album_match_payload):
                    resolved += 1
                    if storage is not None:
                        storage.upsert_track_enrichment(
                            provider="tidal",
                            artist=track.artists,
                            title=track.title,
                            album=rec.title,
                            isrc=track.isrc,
                            tidal_track_id=track.tidal_track_id,
                            tidal_album_id=track.tidal_album_id,
                            payload={
                                "source": "recommendation_album_tracklist",
                                "lookup_version": TIDAL_TRACK_LOOKUP_CACHE_VERSION,
                                **album_match_payload,
                            },
                        )
                    continue
                lookup_error = _tidal_lookup_error(tidal)
                if storage is not None and not lookup_error:
                    storage.upsert_track_enrichment(
                        provider="tidal",
                        artist=track.artists,
                        title=track.title,
                        album=rec.title,
                        isrc=track.isrc,
                        status="miss",
                        payload={
                            "source": "recommendation_lookup",
                            "lookup_version": TIDAL_TRACK_LOOKUP_CACHE_VERSION,
                        },
                        error="not found",
                    )
                continue
            payload = {
                "source": "recommendation_lookup",
                "lookup_version": TIDAL_TRACK_LOOKUP_CACHE_VERSION,
                "tidal_track_id": getattr(match, "track_id", None),
                "tidal_album_id": getattr(match, "album_id", None),
                "isrc": getattr(match, "isrc", None),
                "title": getattr(match, "title", None),
                "artists": getattr(match, "artists", None),
                "match_stage": getattr(match, "stage", None) or "metadata_in_window",
            }
            if _apply_tidal_track_payload(track, payload):
                resolved += 1
                if storage is not None:
                    storage.upsert_track_enrichment(
                        provider="tidal",
                        artist=track.artists,
                        title=track.title,
                        album=rec.title,
                        isrc=track.isrc,
                        tidal_track_id=track.tidal_track_id,
                        tidal_album_id=track.tidal_album_id,
                        payload=payload,
                    )
    return resolved


def _backfill_apple_music_track_ids(
    recommendations: list[ReleaseRecommendation],
    apple_music: AppleMusicProvider | None,
) -> int:
    if apple_music is None or not apple_music.available:
        return 0
    resolved = 0
    tracks_missing = [track for rec in recommendations for track in rec.tracks if not track.apple_music_track_id]
    if not tracks_missing:
        return 0
    batch_lookup = getattr(apple_music, "lookup_track_ids_by_isrc", None)
    if callable(batch_lookup):
        isrc_values = [str(track.isrc).strip().upper() for track in tracks_missing if track.isrc]
        if isrc_values:
            by_isrc = batch_lookup(isrc_values)
            for track in tracks_missing:
                if track.apple_music_track_id or not track.isrc:
                    continue
                apple_track_id = by_isrc.get(str(track.isrc).strip().upper())
                if not apple_track_id:
                    continue
                track.apple_music_track_id = apple_track_id
                track.apple_music_url = f"https://music.apple.com/us/song/{apple_track_id}"
                resolved += 1
    for rec in recommendations:
        for track in rec.tracks:
            if track.apple_music_track_id:
                continue
            apple_track_id = apple_music.lookup_track_id(
                artist=track.artists,
                title=track.title,
                isrc=track.isrc,
            )
            if not apple_track_id:
                continue
            track.apple_music_track_id = apple_track_id
            track.apple_music_url = f"https://music.apple.com/us/song/{apple_track_id}"
            resolved += 1
    return resolved


def _recover_empty_recommendation_tracks(
    recommendations: list[ReleaseRecommendation],
    *,
    spotify: SpotifyProvider | None,
    tidal: TidalProvider | None,
    musicbrainz: MusicBrainzProvider | None,
    max_tracks: int,
    seed_track_keys: set[str],
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
    attempts_state: dict[str, int] | None = None,
    progress_callback: Callable[[ReleaseRecommendation, int, int], None] | None = None,
) -> dict[str, int | bool]:
    state = attempts_state if attempts_state is not None else {}
    counters: dict[str, int | bool] = {
        "empty_track_recovery_attempted": 0,
        "recovered_via_reenrich": 0,
        "recovered_via_tidal_release_rescue": 0,
        "recovered_via_spotify_release_rescue": 0,
        "recovery_no_tracklist_after_recovery": 0,
        "recovery_budget_exhausted": False,
    }
    recovery_budget = 12 if len(recommendations) <= 60 else 24
    total_recommendations = len(recommendations)
    for idx, rec in enumerate(recommendations, start=1):
        if progress_callback is not None:
            progress_callback(rec, idx, total_recommendations)
        if rec.tracks:
            continue
        if int(counters["empty_track_recovery_attempted"]) >= recovery_budget:
            counters["recovery_budget_exhausted"] = True
            rec.rationale.append("recovery-result:budget_exhausted")
            continue
        attempt = _next_empty_track_recovery_attempt(state, rec)
        rec.rationale.append(f"empty-track-recovery-attempt:{attempt}")
        if attempt > 3:
            rec.rationale.append("recovery-result:max_attempts_exhausted")
            continue
        counters["empty_track_recovery_attempted"] = int(counters["empty_track_recovery_attempted"]) + 1
        rec.rationale.append("empty-track-recovery-attempted")
        enrich_recommendation_tracks(
            rec,
            spotify=spotify,
            musicbrainz=musicbrainz,
            isrc_resolver=None,
            max_tracks=max_tracks,
            seed_track_keys=seed_track_keys,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )
        if rec.tracks:
            rec.rationale.append("recovery-result:reenrich_tracks")
            counters["recovered_via_reenrich"] = int(counters["recovered_via_reenrich"]) + 1
            continue
        recovered = _recover_track_from_provider_release_metadata(
            rec,
            spotify=spotify,
            tidal=tidal,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )
        if recovered is not None:
            rec.tracks = [recovered]
            rec.rationale.append(f"recovery-result:{recovered.resolution_source or 'provider_release_rescue'}")
            source = recovered.resolution_source or ""
            if source == "tidal_release_rescue":
                counters["recovered_via_tidal_release_rescue"] = int(counters["recovered_via_tidal_release_rescue"]) + 1
            elif source == "spotify_release_rescue":
                counters["recovered_via_spotify_release_rescue"] = int(counters["recovered_via_spotify_release_rescue"]) + 1
        else:
            rec.rationale.append("recovery-result:no_tracklist_after_recovery")
            counters["recovery_no_tracklist_after_recovery"] = int(counters["recovery_no_tracklist_after_recovery"]) + 1
    return counters


def _next_empty_track_recovery_attempt(state: dict[str, int], rec: ReleaseRecommendation) -> int:
    key = "|".join(
        [
            normalize_key(rec.artist),
            normalize_key(rec.title),
            normalize_key(rec.release_date),
            normalize_key(rec.mb_release_group_id or ""),
        ]
    )
    previous = int(state.get(key, 0) or 0)
    current = previous + 1
    state[key] = current
    return current


def _recover_track_from_provider_release_metadata(
    rec: ReleaseRecommendation,
    *,
    spotify: SpotifyProvider | None,
    tidal: TidalProvider | None,
    discovery_months: int | None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> ReleaseTrack | None:
    if spotify is not None:
        try:
            _, _, tracks = spotify.representative_tracks(
                rec.artist,
                rec.title,
                1,
                allow_broad_search=True,
                release_date=rec.release_date,
                discovery_months=discovery_months,
                discovery_window=discovery_window,
                discovery_today=discovery_today,
            )
            if tracks:
                track = tracks[0]
                track.resolution_source = track.resolution_source or "spotify_release_rescue"
                track.resolution_note = track.resolution_note or "Recovered from provider release-level rescue."
                return track
        except Exception:
            pass
    if tidal is not None:
        try:
            try:
                match = tidal.lookup_track_with_window(
                    rec.artist,
                    rec.title,
                    rec.title,
                    None,
                    release_date=rec.release_date,
                    discovery_months=discovery_months,
                    discovery_window=discovery_window,
                    discovery_today=discovery_today,
                )
            except TypeError:
                match = tidal.lookup_track_with_window(
                    rec.artist,
                    rec.title,
                    rec.title,
                    None,
                    release_date=rec.release_date,
                    discovery_months=discovery_months,
                    discovery_today=discovery_today,
                )
            if not match:
                try:
                    match = tidal.lookup_track_with_window(
                        rec.artist,
                        rec.title,
                        None,
                        None,
                        release_date=rec.release_date,
                        discovery_months=discovery_months,
                        discovery_window=discovery_window,
                        discovery_today=discovery_today,
                    )
                except TypeError:
                    match = tidal.lookup_track_with_window(
                        rec.artist,
                        rec.title,
                        None,
                        None,
                        release_date=rec.release_date,
                        discovery_months=discovery_months,
                        discovery_today=discovery_today,
                    )
            if match:
                return ReleaseTrack(
                    title=match.title or rec.title,
                    artists=", ".join(match.artists or [rec.artist]),
                    tidal_track_id=match.track_id,
                    tidal_album_id=match.album_id,
                    isrc=match.isrc,
                    isrc_source="tidal" if match.isrc else "t_nF",
                    resolution_source="tidal_release_rescue",
                    resolution_note=f"Recovered from provider release-level rescue [stage:{match.stage or 'unknown'}].",
                    release_date=rec.release_date,
                )
        except Exception:
            pass
    return None


def _cached_tidal_track_match(
    storage: Storage | None,
    track: ReleaseTrack,
    album: str,
) -> dict | None:
    if storage is None:
        return None
    row = storage.get_track_enrichment(
        provider="tidal",
        artist=track.artists,
        title=track.title,
        isrc=track.isrc,
        tidal_track_id=track.tidal_track_id,
    )
    if not row:
        return None
    if row["status"] == "miss":
        payload = row.get("payload") or {}
        if payload.get("lookup_version") != TIDAL_TRACK_LOOKUP_CACHE_VERSION:
            return None
        return {}
    if row["status"] != "success":
        return None
    payload = row.get("payload") or {}
    return {
        "tidal_track_id": row.get("tidal_track_id") or payload.get("tidal_track_id") or payload.get("track_id"),
        "tidal_album_id": row.get("tidal_album_id") or payload.get("tidal_album_id") or payload.get("album_id"),
        "isrc": row.get("isrc") or payload.get("isrc"),
    }


def _tidal_lookup_error(tidal: TidalProvider | None) -> str | None:
    if tidal is None:
        return None
    value = getattr(tidal, "last_lookup_error", None)
    return str(value) if value else None


def _tidal_match_from_release_album(
    tidal: TidalProvider | None,
    rec: ReleaseRecommendation,
    track: ReleaseTrack,
    *,
    album_cache: dict[str, Any | None] | None = None,
) -> dict[str, str] | None:
    if tidal is None or not rec.tidal_album_id:
        return None
    fetch_album = getattr(tidal, "fetch_album", None)
    if not callable(fetch_album):
        return None
    cache_key = str(rec.tidal_album_id)
    if album_cache is not None and cache_key in album_cache:
        album = album_cache[cache_key]
    else:
        try:
            album = fetch_album(rec.tidal_album_id)
        except Exception:
            if album_cache is not None:
                album_cache[cache_key] = None
            return None
        if album_cache is not None:
            album_cache[cache_key] = album
    if not album:
        return None
    tracks_attr = getattr(album, "tracks", None)
    if callable(tracks_attr):
        try:
            album_tracks = list(tracks_attr())
        except Exception:
            return None
    else:
        album_tracks = []
    target_title = normalize_key(track.title)
    target_artist = normalize_key(track.artists)
    for album_track in album_tracks:
        album_title = normalize_key(getattr(album_track, "name", None) or getattr(album_track, "title", None) or "")
        if not album_title or album_title != target_title:
            continue
        artists_attr = getattr(album_track, "artists", None) or []
        artist_names = [str(getattr(artist, "name", "")) for artist in artists_attr if getattr(artist, "name", None)]
        if artist_names and target_artist:
            normalized_artists = {normalize_key(name) for name in artist_names if normalize_key(name)}
            if target_artist not in normalized_artists:
                continue
        match_track_id = getattr(album_track, "id", None)
        if not match_track_id:
            continue
        return {
            "tidal_track_id": str(match_track_id),
            "tidal_album_id": str(rec.tidal_album_id),
            "isrc": str(getattr(album_track, "isrc")) if getattr(album_track, "isrc", None) else "",
        }
    return None


def _apply_tidal_track_payload(track: ReleaseTrack, payload: dict) -> bool:
    if not payload:
        return False
    tidal_track_id = payload.get("tidal_track_id") or payload.get("track_id")
    if not tidal_track_id:
        return False
    track.tidal_track_id = str(tidal_track_id)
    tidal_album_id = payload.get("tidal_album_id") or payload.get("album_id")
    if tidal_album_id and not track.tidal_album_id:
        track.tidal_album_id = str(tidal_album_id)
    if payload.get("isrc") and not track.isrc:
        track.isrc = str(payload["isrc"])
        track.isrc_source = "tidal"
    if not track.resolution_source:
        track.resolution_source = "tidal_track_search_strict"
    return True


def _merge_lists(first: list[str], second: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in first + second:
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _store_input_track_enrichment(storage: Storage, tracks: list[InputTrack], spotify: SpotifyProvider | None = None) -> None:
    for track in tracks:
        payload = {
            key: value
            for key, value in track.model_dump(mode="json").items()
            if value not in (None, "", [])
        }
        if not payload:
            continue
        if track.spotify_track_id or track.spotify_album_id:
            storage.upsert_track_enrichment(
                provider="spotify",
                track=track,
                payload={**payload, "source": "input"},
            )
        if track.tidal_track_id or track.tidal_album_id:
            storage.upsert_track_enrichment(
                provider="tidal",
                track=track,
                payload={**payload, "source": "input"},
            )
        if track.apple_music_track_id:
            storage.upsert_track_enrichment(
                provider="apple_music",
                track=track,
                payload={**payload, "source": "input"},
            )
        storage.upsert_track_enrichment(
            provider="input",
            track=track,
            payload=payload,
        )


def _spotify_profile_artist_metadata(
    spotify: SpotifyProvider,
    tracks: list[InputTrack],
) -> dict[str, dict]:
    """Use a lightweight-first Spotify enrichment strategy for profile stage.

    1) Optionally backfill a bounded number of track enrichments (hash-gated rollout).
    2) Fetch artist metadata only for top frequent artist IDs from input tracks.
    """
    backfill = getattr(spotify, "backfill_track_enrichment", None)
    if callable(backfill) and _should_run_profile_track_backfill(tracks):
        try:
            backfill(tracks, limit=SPOTIFY_PROFILE_TRACK_BACKFILL_CAP)
        except Exception:
            pass
    artist_metadata = getattr(spotify, "artist_metadata_from_tracks", None)
    if not callable(artist_metadata):
        return {}
    try:
        return artist_metadata(
            tracks,
            max_artists=SPOTIFY_PROFILE_ARTIST_METADATA_CAP,
        )
    except TypeError:
        return artist_metadata(tracks)


def _should_run_profile_track_backfill(tracks: list[InputTrack]) -> bool:
    """Hash-gate legacy profile-stage track backfill for safe rollback experiments."""
    percent = int(clamp(SPOTIFY_PROFILE_TRACK_BACKFILL_ROLLOUT_PERCENT, 0, 100))
    if percent <= 0:
        return False
    if percent >= 100:
        return True

    # Stable identity based on input track IDs when possible, with safe fallbacks.
    identity_parts = [
        track.spotify_track_id or track.id or f"{track.artist}|{track.track}"
        for track in tracks[:25]
    ]
    identity = "|".join(identity_parts) or "empty"
    bucket = int(hashlib.sha256(identity.encode("utf-8")).hexdigest()[:8], 16) % 100
    return bucket < percent


def _mark_input_releases_as_heard(
    storage: Storage,
    tracks: list[InputTrack],
    spotify: SpotifyProvider | None = None,
    musicbrainz: MusicBrainzProvider | None = None,
    tidal: TidalProvider | None = None,
    session_id: str | None = None,
    profile_name: str | None = None,
) -> int:
    """Mark albums from input tracks as heard releases.

    This ensures that releases already in the input playlist are excluded
    from discovery recommendations.

    Returns:
        Number of releases marked as heard.
    """
    marked_count = 0
    seen_albums: set[str] = set()

    for track in tracks:
        if not track.album:
            continue

        # Create unique key for album to avoid duplicates
        album_key = f"{track.artist}|{track.album}"
        if album_key in seen_albums:
            continue
        seen_albums.add(album_key)

        storage.add_heard(
            artist=track.artist,
            title=track.album,
            spotify_album_id=track.spotify_album_id,
            session_id=session_id,
            profile_name=profile_name,
            category="input",
        )
        marked_count += 1

    return marked_count


def _format_last_seen(value: object) -> str:
    if not value:
        return "unknown"
    try:
        parsed = dt.datetime.fromisoformat(str(value))
    except ValueError:
        return str(value)
    return parsed.strftime("%Y-%m-%d %H:%M:%S")


def enrich_source_name(
    source: dict,
    playlist: str,
    spotify: SpotifyProvider,
    tidal: TidalProvider,
    apple_music: AppleMusicProvider | None = None,
) -> dict:
    """Replace auto-generated source name with the actual playlist title from the provider."""
    spotify_playlist_ready = bool(getattr(spotify, "playlist_auth_available", getattr(spotify, "available", False)))
    if source.get("source_type") == "spotify" and spotify_playlist_ready:
        name = spotify.fetch_playlist_name(playlist)
        if name:
            return {**source, "name": name}
    elif source.get("source_type") == "tidal" and tidal is not None and tidal.available:
        name = tidal.fetch_playlist_name(playlist)
        if name:
            return {**source, "name": name}
    elif source.get("source_type") == "apple_music" and apple_music is not None and apple_music.available:
        name = apple_music.fetch_playlist_name(playlist)
        if name:
            return {**source, "name": name}
    return source


def _providers(
    settings: object,
    storage: Storage,
) -> tuple[SpotifyProvider, MusicBrainzProvider, LastFMProvider, TidalProvider, AppleMusicProvider, ListenBrainzProvider, DeezerProvider]:
    return (
        SpotifyProvider(settings, storage),
        MusicBrainzProvider(settings, storage),
        LastFMProvider(settings, storage),
        TidalProvider(settings),
        AppleMusicProvider(settings),
        ListenBrainzProvider(settings, storage),
        DeezerProvider(settings, storage),
    )


def _load_playlist_tracks(
    playlist: str,
    spotify: SpotifyProvider,
    tidal: TidalProvider | None = None,
    apple_music: AppleMusicProvider | None = None,
) -> list[InputTrack]:
    source_path = Path(playlist).expanduser()
    if source_path.exists():
        return parse_text_file(source_path)
    if looks_like_spotify_playlist(playlist):
        spotify_playlist_ready = bool(getattr(spotify, "playlist_auth_available", getattr(spotify, "available", False)))
        if not spotify_playlist_ready:
            raise WorkflowAbort(
                "Spotify credentials are required for Spotify playlist input. "
                "Set SPOTIPY_CLIENT_ID and SPOTIPY_REDIRECT_URI, use --reuse-profile/--profile if you already saved this source, or use a local .txt playlist."
            )
        try:
            return spotify.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(_provider_rate_limit_message(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(f"Spotify playlist unavailable: {_safe_error(exc)}") from exc
    if looks_like_tidal_playlist(playlist):
        if tidal is None:
            tidal = TidalProvider(load_settings())
        if not tidal.available:
            raise WorkflowAbort(
                "Tidal credentials are required for Tidal playlist input. "
                "Set TIDAL_CLIENT_ID and TIDAL_CLIENT_SECRET, or use a local .txt playlist or TuneMyMusic-style .csv export file."
            )
        try:
            return tidal.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(_provider_rate_limit_message(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(f"Tidal playlist unavailable: {_safe_error(exc)}") from exc
    if looks_like_apple_music_playlist(playlist):
        if apple_music is None:
            apple_music = AppleMusicProvider(load_settings())
        if not apple_music.available:
            raise WorkflowAbort(
                "Apple Music credentials are required for Apple Music playlist input. "
                "Set APPLE_MUSIC_DEVELOPER_TOKEN and APPLE_MUSIC_USER_TOKEN, or use a local .txt playlist."
            )
        try:
            return apple_music.fetch_playlist_tracks(playlist)
        except ProviderRateLimit as exc:
            raise WorkflowAbort(_provider_rate_limit_message(exc)) from exc
        except ProviderUnavailable as exc:
            raise WorkflowAbort(str(exc)) from exc
        except Exception as exc:
            raise WorkflowAbort(f"Apple Music playlist unavailable: {_safe_error(exc)}") from exc
    raise WorkflowAbort(f"Input is neither an existing text file nor a Spotify/Tidal/Apple Music playlist: {playlist}")


def _profile_from_record(profile_record: dict) -> tuple[TasteProfile, list[InputTrack], set[str]]:
    profile = TasteProfile.model_validate(json.loads(profile_record["profile_json"]))
    seed_tracks = seed_tracks_from_payload(json.loads(profile_record["seed_tracks_json"]))
    seed_track_keys = set(json.loads(profile_record["seed_track_keys_json"]))
    return profile, seed_tracks, seed_track_keys


def profile_enrichment_status_line(storage: Storage, profile_record: dict) -> str:
    profile, seed_tracks, _ = _profile_from_record(profile_record)
    completeness = storage.enrichment_completeness(artists=profile.artists, tracks=seed_tracks)
    status = "complete" if completeness.complete else "incomplete"
    return (
        "Enrichment: "
        f"{status}; artists {completeness.artist_enriched}/{completeness.artist_total}, "
        f"tracks {completeness.track_enriched}/{completeness.track_total}"
    )


def profile_summary_line(storage: Storage, profile_summary: dict) -> str:
    profile_record = storage.get_taste_profile(profile_summary["id"])
    enrichment = ""
    if profile_record:
        profile, seed_tracks, _ = _profile_from_record(profile_record)
        completeness = storage.enrichment_completeness(artists=profile.artists, tracks=seed_tracks)
        enrichment = (
            f"; enrichment {completeness.artist_enriched}/{completeness.artist_total} artists, "
            f"{completeness.track_enriched}/{completeness.track_total} tracks"
        )
    used = profile_summary.get("last_used_at") or "never"
    return (
        f"{profile_summary['id']:4}. {profile_summary['name']} [{profile_summary['source_type']}] "
        f"{profile_summary['track_count']} tracks, {profile_summary['artist_count']} artists"
        f"{enrichment}; updated {profile_summary['updated_at']}; used {used}"
    )


def _default_output_path(
    output_format: str,
    source_name: str | None = None,
    now: dt.datetime | None = None,
) -> Path:
    suffix = output_format if output_format in {"csv", "json"} else "txt"
    date_label = (now or dt.datetime.now()).strftime("%d_%m_%y")
    source_slug = _filename_slug(source_name, max_length=12)
    stem = f"{source_slug}_{date_label}" if source_slug else date_label
    return _unique_output_path(Path.cwd() / f"{stem}.{suffix}")


def _filename_slug(value: str | None, max_length: int = 40) -> str:
    slug = "-".join(normalize_key(value).split())
    return slug[:max_length].strip("-")


def _spotify_playlist_name(source_name: str) -> str:
    """Format playlist name for Spotify: mmn_playlistname (max 100 chars)."""
    # Preserve original case - just sanitize spaces and special chars for Spotify compatibility
    cleaned = (source_name or "").strip()
    # Replace spaces with underscores for Spotify playlist name format
    result = cleaned.replace(" ", "_").replace("--", "-").strip("_-")
    # Truncate to 96 chars to leave room for 'mmn_' prefix (Spotify max is 100 chars)
    result = result[:96]
    # Prepend 'mmn_' prefix and preserve original case
    return f"mmn_{result}" if result else "mmn"


def _tidal_playlist_name(source_name: str) -> str:
    return _spotify_playlist_name(source_name)


def _apple_music_playlist_name(source_name: str) -> str:
    return _spotify_playlist_name(source_name)


def _default_selection_logic_path(source_name: str | None = None, now: dt.datetime | None = None) -> Path:
    date_label = (now or dt.datetime.now()).strftime("%d_%m_%y_%H%M%S")
    source_slug = _filename_slug(source_name, max_length=12)
    stem = f"{source_slug}_selection_logic_{date_label}" if source_slug else f"selection_logic_{date_label}"
    return _unique_output_path(Path.cwd() / f"{stem}.md")


def _unique_output_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for idx in range(2, 1000):
        candidate = path.with_name(f"{stem}_{idx}{suffix}")
        if not candidate.exists():
            return candidate
    raise WorkflowAbort(f"Could not choose a unique output path near {path}")


def _print_recommendations(recommendations: list[ReleaseRecommendation], emit: Emitter = print, locale: str = DEFAULT_LANGUAGE) -> None:
    if not recommendations:
        emit(_translate_key(locale, "output.no_recent_matching_releases"))
        return
    emit("")
    for idx, rec in enumerate(recommendations, start=1):
        emit(_translate_key(locale, "output.recommendation_line", idx=f"{idx:2}", artist=rec.artist, title=rec.title, release_type=rec.release_type, release_date=rec.release_date))
        emit(_translate_key(locale, "output.recommendation_rationale", rationale=', '.join(rec.rationale)))
        for track in rec.tracks:
            emit(_translate_key(locale, "output.track_line", artists=track.artists, title=track.title))
        if not rec.tracks:
            emit(_translate_key(locale, "output.track_unavailable"))


def _print_discovery_summary(summary: DiscoverySummary, emit: Emitter = print, locale: str = DEFAULT_LANGUAGE) -> None:
    total = f"/{summary.total_candidates}" if summary.total_candidates is not None else ""
    emit(_translate_key(locale, "output.discovery_summary", candidates=summary.candidates_processed, total=total, release_groups=summary.release_groups_checked, accepted=summary.accepted))
    if summary.spotify_misses:
        emit(_translate_key(locale, "output.spotify_lookup_misses", misses=summary.spotify_misses))
    if summary.musicbrainz_misses:
        emit(_translate_key(locale, "output.musicbrainz_lookup_misses", misses=summary.musicbrainz_misses))
    if summary.skips:
        skip_text = ", ".join(f"{reason}: {count}" for reason, count in sorted(summary.skips.items()))
        emit(_translate_key(locale, "output.skipped_release_groups", skips=skip_text))


def _summary_payload(summary: DiscoverySummary) -> dict:
    return {
        "candidates_processed": summary.candidates_processed,
        "total_candidates": summary.total_candidates,
        "release_groups_checked": summary.release_groups_checked,
        "accepted": summary.accepted,
        "spotify_misses": summary.spotify_misses,
        "musicbrainz_misses": summary.musicbrainz_misses,
        "elapsed_seconds": summary.elapsed_seconds,
        "estimated_remaining_seconds": summary.estimated_remaining_seconds,
        "skips": summary.skips,
    }


def _spotify_cache_summary(spotify: object) -> dict:
    summary = getattr(spotify, "cache_summary", None)
    return summary() if callable(summary) else {}


def _provider_metrics_summary(
    *,
    spotify: object | None,
    musicbrainz: object | None,
    lastfm: object | None,
    listenbrainz: object | None,
    deezer: object | None,
    tidal: object | None,
    storage: Storage,
) -> dict[str, dict[str, int | float | bool]]:
    cache_stats = storage.cache_diagnostics()

    def _provider_block(name: str, provider: object | None) -> dict[str, int | float | bool]:
        metrics: dict[str, int | float | bool] = {}
        cache = cache_stats.get(name, {})
        metrics["cache_entries"] = int(cache.get("entries", 0))
        metrics["cache_hits"] = int(cache.get("hits", 0))
        metrics["cache_misses"] = int(cache.get("misses", 0))
        if provider is None:
            metrics["configured"] = False
            return metrics
        metrics["configured"] = bool(getattr(provider, "available", True))
        metrics["api_calls"] = int(getattr(provider, "api_calls", 0) or 0)
        metrics["rate_limit_events"] = len(getattr(provider, "rate_limit_warnings", []) or [])
        metrics["retry_count"] = int(getattr(provider, "retry_count", 0) or 0)
        metrics["request_time_seconds"] = round(float(getattr(provider, "request_time_seconds", 0.0) or 0.0), 3)
        metrics["timeout_events"] = int(getattr(provider, "timeout_events", 0) or 0)
        cooldown = float(getattr(provider, "catalog_cooldown_remaining_seconds", lambda: 0.0)() if hasattr(provider, "catalog_cooldown_remaining_seconds") else 0.0)
        if cooldown > 0:
            metrics["cooldown_seconds"] = round(cooldown, 3)
        return metrics

    return {
        "spotify": _provider_block("spotify", spotify),
        "musicbrainz": _provider_block("musicbrainz", musicbrainz),
        "lastfm": _provider_block("lastfm", lastfm),
        "listenbrainz": _provider_block("listenbrainz", listenbrainz),
        "deezer": _provider_block("deezer", deezer),
        "tidal": _provider_block("tidal", tidal),
    }


def _emit_profile_stage_diagnostics(
    *,
    emit: Emitter,
    locale: str,
    settings: Any,
    spotify: object | None,
    musicbrainz: object | None,
    lastfm: object | None,
    listenbrainz: object | None,
    deezer: object | None,
    tidal: object | None,
    apple_music: object | None,
) -> None:
    emit(
        _translate_key(
            locale,
            "status.profile_diag_timeouts",
            connect=round(float(getattr(settings, "provider_http_connect_timeout_seconds", 0.0) or 0.0), 2),
            read=round(float(getattr(settings, "provider_http_read_timeout_seconds", 0.0) or 0.0), 2),
            write=round(float(getattr(settings, "provider_http_write_timeout_seconds", 0.0) or 0.0), 2),
            pool=round(float(getattr(settings, "provider_http_pool_timeout_seconds", 0.0) or 0.0), 2),
        )
    )
    providers = [
        ("spotify", spotify),
        ("musicbrainz", musicbrainz),
        ("lastfm", lastfm),
        ("listenbrainz", listenbrainz),
        ("deezer", deezer),
        ("tidal", tidal),
        ("apple_music", apple_music),
    ]
    for name, provider in providers:
        if provider is None:
            continue
        emit(
            _translate_key(
                locale,
                "status.profile_diag_provider",
                provider=name,
                calls=int(getattr(provider, "api_calls", 0) or 0),
                request_seconds=round(float(getattr(provider, "request_time_seconds", 0.0) or 0.0), 3),
                timeouts=int(getattr(provider, "timeout_events", 0) or 0),
                retries=int(getattr(provider, "retry_count", 0) or 0),
            )
        )


def _optimization_status(
    *,
    options: DiscoverOptions,
    spotify: SpotifyProvider | None,
    tracks: list[InputTrack],
    settings: Any | None = None,
) -> dict[str, str | bool | int]:
    spotify_state = getattr(spotify, "_mamonia_enrichment_state", {}) if spotify is not None else {}
    return {
        "force_refresh": bool(options.force_refresh),
        "spotify_enrichment_budget_active": bool(spotify_state.get("budget", 0)),
        "spotify_enrichment_budget_used": int(spotify_state.get("used", 0) or 0),
        "spotify_rescue_disabled_due_to_429": bool(spotify_state.get("rescue_disabled_due_to_429", False)),
        "profile_track_backfill_rollout_percent": int(SPOTIFY_PROFILE_TRACK_BACKFILL_ROLLOUT_PERCENT),
        "profile_track_backfill_active_for_run": bool(_should_run_profile_track_backfill(tracks)),
        "two_phase_discovery": True,
        "http_timeout_connect_s": round(float(getattr(settings, "provider_http_connect_timeout_seconds", 0.0) or 0.0), 2),
        "http_timeout_read_s": round(float(getattr(settings, "provider_http_read_timeout_seconds", 0.0) or 0.0), 2),
        "http_timeout_write_s": round(float(getattr(settings, "provider_http_write_timeout_seconds", 0.0) or 0.0), 2),
        "http_timeout_pool_s": round(float(getattr(settings, "provider_http_pool_timeout_seconds", 0.0) or 0.0), 2),
    }


def auto_mark_exported_releases(
    storage: Storage,
    recommendations: list[ReleaseRecommendation],
    session_id: str | None = None,
    profile_name: str | None = None,
) -> int:
    count = 0
    for rec in recommendations:
        if storage.is_heard_recommendation(rec):
            backfill = getattr(storage, "backfill_heard_recommendation", None)
            if callable(backfill):
                backfill(rec)
            continue
        storage.add_heard_recommendation(
            rec,
            session_id=session_id,
            profile_name=profile_name,
            category="output",
        )
        count += 1
    return count


def _drop_heard_recommendations(
    storage: Storage,
    recommendations: list[ReleaseRecommendation],
) -> tuple[list[ReleaseRecommendation], int]:
    kept: list[ReleaseRecommendation] = []
    dropped = 0
    for rec in recommendations:
        if storage.is_heard_recommendation(rec):
            backfill = getattr(storage, "backfill_heard_recommendation", None)
            if callable(backfill):
                backfill(rec)
            dropped += 1
            continue
        kept.append(rec)
    return kept, dropped


def _save_latest_profile(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _print_settings_warnings(settings: object, emit_error: Emitter, locale: str = DEFAULT_LANGUAGE) -> None:
    warnings = getattr(settings, "warnings", lambda: [])()
    for warning in warnings:
        emit_error(_translate_key(locale, "output.settings_warning", warning=warning))


def _print_provider_warnings(
    providers: list[object],
    emit_error: Emitter,
    verbose: bool = False,
    stage: str = "generic",
    locale: str = DEFAULT_LANGUAGE,
) -> None:
    seen: set[tuple[str, str]] = set()
    for provider in providers:
        warnings = list(getattr(provider, "rate_limit_warnings", []))
        spotify_profile_warnings: list[ProviderRateLimit] = []
        for warning in warnings:
            key = (warning.provider, warning.operation)
            if key in seen:
                continue
            seen.add(key)
            if stage == "profile" and _is_spotify_enrichment_warning(warning):
                spotify_profile_warnings.append(warning)
                continue
            message = _provider_rate_limit_message(warning)
            guidance_text = ""
            issue_guidance = getattr(provider, "issue_guidance", None)
            if callable(issue_guidance):
                guidance_text = issue_guidance(warning)
            elif warning.is_permission_error:
                guidance = getattr(provider, "permission_guidance", None)
                if callable(guidance):
                    guidance_text = guidance(warning.operation)
            if guidance_text:
                message = f"{message} {guidance_text}"
            if not verbose and warning.retry_after_seconds is not None:
                if not warning.should_auto_wait:
                    retry_at = (dt.datetime.now() + dt.timedelta(seconds=warning.retry_after_seconds)).strftime("%H:%M:%S")
                    retry_hint = f" Retry-After: {warning.retry_after_seconds}s — try again at {retry_at}."
                else:
                    retry_hint = ""
                message = f"{warning.provider} rate limit while {warning.operation}; skipping provider where possible.{retry_hint}"
            emit_error(_translate_key(locale, "output.provider_warning", message=message))
        if spotify_profile_warnings:
            _print_spotify_enrichment_warning(provider, spotify_profile_warnings, emit_error, verbose=verbose, locale=locale)
        if warnings and hasattr(provider, "rate_limit_warnings"):
            provider.rate_limit_warnings.clear()


def _is_spotify_enrichment_warning(warning: ProviderRateLimit) -> bool:
    return warning.provider == "Spotify" and warning.operation in {
        "searching artists",
        "searching albums",
        "reading album tracks",
        "reading track details",
    }


def _print_spotify_enrichment_warning(
    provider: object,
    warnings: list[ProviderRateLimit],
    emit_error: Emitter,
    verbose: bool = False,
    locale: str = DEFAULT_LANGUAGE,
) -> None:
    emit_error(_translate_key(locale, "error.spotify_enrichment.header"))
    for warning in warnings:
        guidance_text = ""
        issue_guidance = getattr(provider, "issue_guidance", None)
        if callable(issue_guidance):
            guidance_text = issue_guidance(warning)
        if verbose:
            message = _provider_rate_limit_message(warning, locale=locale)
            if guidance_text:
                message = f"{message} {guidance_text}"
            emit_error(message)
            continue
        if warning.error_kind != "rate_limited":
            message = _provider_rate_limit_message(warning, locale=locale)
            if guidance_text:
                message = f"{message} {guidance_text}"
            emit_error(message)
            continue
        if warning.retry_after_seconds is None:
            emit_error(_translate_key(locale, "error.spotify_enrichment.rate_limit_operation", operation=warning.operation))
        else:
            retry = format_retry_after(warning.retry_after_seconds)
            emit_error(_translate_key(locale, "error.spotify_enrichment.rate_limit_retry", operation=warning.operation, retry=retry))
    emit_error("")
    emit_error(_translate_key(locale, "error.spotify_enrichment.cached_enrichment"))
    emit_error(_translate_key(locale, "error.spotify_enrichment.enrichment_paused"))
    emit_error(_translate_key(locale, "error.spotify_enrichment.discovery_continues"))


def _provider_rate_limit_message(exc: ProviderRateLimit, locale: str = DEFAULT_LANGUAGE) -> str:
    message = str(exc)
    if exc.retry_after_seconds is not None and not exc.should_auto_wait:
        retry_at = (dt.datetime.now() + dt.timedelta(seconds=exc.retry_after_seconds)).strftime("%H:%M:%S")
        message += f" Retry-After: {exc.retry_after_seconds}s — try again at {retry_at}."
    if exc.provider == "Spotify" and "playlist" in exc.operation:
        message += " " + _translate_key(locale, "error.spotify_playlist_hint")
    return message


def _safe_error(exc: Exception) -> str:
    return str(exc).splitlines()[0][:160]
