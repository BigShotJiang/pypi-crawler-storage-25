from __future__ import annotations

import hashlib
from pathlib import Path

from .discovery import track_key_for_diff
from .input import extract_apple_music_playlist_id, extract_spotify_playlist_id, extract_tidal_playlist_id
from .models import InputTrack
from .utils import normalize_key


def source_identity(source: str) -> dict[str, str]:
    path = Path(source).expanduser()
    if path.exists():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        extension = path.suffix.lower()
        source_type = "csv" if extension == ".csv" else "txt"
        return {
            "source_type": source_type,
            "source_ref": str(path.resolve()),
            "source_hash": digest,
            "source_key": f"{source_type}:{digest}",
            "name": path.stem or digest[:12],
        }

    playlist_id = extract_spotify_playlist_id(source)
    if playlist_id:
        return {
            "source_type": "spotify",
            "source_ref": source,
            "source_hash": playlist_id,
            "source_key": f"spotify:playlist:{playlist_id}",
            "name": f"spotify-{playlist_id}",
        }

    tidal_playlist_id = extract_tidal_playlist_id(source)
    if tidal_playlist_id:
        return {
            "source_type": "tidal",
            "source_ref": source,
            "source_hash": tidal_playlist_id,
            "source_key": f"tidal:playlist:{tidal_playlist_id}",
            "name": f"tidal-{tidal_playlist_id}",
        }

    apple_playlist_id = extract_apple_music_playlist_id(source)
    if apple_playlist_id:
        return {
            "source_type": "apple_music",
            "source_ref": source,
            "source_hash": apple_playlist_id,
            "source_key": f"apple_music:playlist:{apple_playlist_id}",
            "name": f"apple-{apple_playlist_id}",
        }

    key = normalize_key(source)
    return {
        "source_type": "unknown",
        "source_ref": source,
        "source_hash": key,
        "source_key": f"unknown:{key}",
        "name": key or "unknown",
    }


def source_identity_from_tracks(source: str, tracks: list[InputTrack]) -> dict[str, str]:
    identity = source_identity(source)
    if identity["source_type"] not in {"txt", "csv"}:
        return identity
    digest = track_set_hash(tracks)
    return {
        **identity,
        "source_hash": digest,
        "source_key": f"{identity['source_type']}:{digest}",
    }


def track_set_hash(tracks: list[InputTrack]) -> str:
    keys = sorted(key for track in tracks if (key := track_key_for_diff(track)))
    payload = "\n".join(keys).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def portable_track_key(track: InputTrack) -> str:
    artist_key = normalize_key(track.artist)
    title_key = normalize_key(track.track)
    return f"metadata:{artist_key}|{title_key}" if artist_key and title_key else ""


def portable_track_set_hash(tracks: list[InputTrack]) -> str:
    keys = sorted(key for track in tracks if (key := portable_track_key(track)))
    payload = "\n".join(keys).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def seed_tracks_from_payload(payload: list[dict]) -> list[InputTrack]:
    return [InputTrack.model_validate(item) for item in payload]
