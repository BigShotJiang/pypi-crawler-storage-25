from __future__ import annotations

import datetime as dt
import csv
import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import ArtistProfile, CanonicalTrack, InputTrack, ReleaseRecommendation, TasteProfile
from .utils import normalize_key, normalize_variant_title, release_match_key, release_year, titles_match


SCHEMA_VERSION = 6
ENRICHMENT_STATUSES = {"success", "miss", "skipped", "rate_limited"}
CANONICAL_TRACK_PROVIDER = "canonical"
CANONICAL_TRACK_CACHE_VERSION = "canonical-track-v1"


@dataclass(frozen=True)
class EnrichmentCompleteness:
    artist_total: int
    artist_enriched: int
    track_total: int
    track_enriched: int

    @property
    def complete(self) -> bool:
        return self.artist_enriched >= self.artist_total and self.track_enriched >= self.track_total


class Storage:
    """Small SQLite repository for Mamonia's durable local state."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = os.getenv("MAMONIA_DB_ENGINE", "v1").strip().lower()
        self._retry_lock_ms = max(0, int(os.getenv("MAMONIA_DB_RETRY_LOCK_MS", "1500") or "1500"))
        self._thread_local = threading.local()
        self._conn = self._connect(check_same_thread=(self.engine != "v1"))
        self._conn.isolation_level = "DEFERRED"
        self._lock = threading.Lock()
        self._conn.row_factory = sqlite3.Row
        self.initialize()

    def close(self) -> None:
        conn = getattr(self, "_conn", None)
        if conn is not None:
            conn.close()
        thread_conn = getattr(self._thread_local, "conn", None)
        if thread_conn is not None and thread_conn is not conn:
            thread_conn.close()
            self._thread_local.conn = None

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    @property
    def conn(self) -> sqlite3.Connection:
        if self.engine != "v2":
            return self._conn
        existing = getattr(self._thread_local, "conn", None)
        if existing is not None:
            return existing
        conn = self._connect(check_same_thread=True)
        conn.isolation_level = "DEFERRED"
        conn.row_factory = sqlite3.Row
        self._thread_local.conn = conn
        return conn

    @conn.setter
    def conn(self, value: sqlite3.Connection) -> None:
        self._conn = value

    def _connect(self, *, check_same_thread: bool) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30, check_same_thread=check_same_thread)
        conn.execute("PRAGMA busy_timeout = 30000;")
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _commit_with_retry(self) -> None:
        deadline = time.time() + (self._retry_lock_ms / 1000.0)
        while True:
            try:
                self.conn.commit()
                return
            except sqlite3.OperationalError as exc:
                message = str(exc).lower()
                if "locked" not in message and "busy" not in message:
                    raise
                if time.time() >= deadline:
                    raise
                time.sleep(0.05)

    @contextmanager
    def _write_transaction(self) -> Any:
        deadline = time.time() + (self._retry_lock_ms / 1000.0)
        while True:
            try:
                # Escalate writes to an immediate transaction to reduce lock races.
                self.conn.execute("BEGIN IMMEDIATE")
                break
            except sqlite3.OperationalError as exc:
                message = str(exc).lower()
                if "locked" not in message and "busy" not in message:
                    raise
                if time.time() >= deadline:
                    raise
                time.sleep(0.05)
        try:
            yield
            self._commit_with_retry()
        except Exception:
            try:
                self.conn.rollback()
            except sqlite3.Error:
                pass
            raise

    def initialize(self) -> None:
        self.conn.executescript(
            """
            PRAGMA busy_timeout = 30000;
            PRAGMA journal_mode = WAL;
            PRAGMA foreign_keys = ON;

            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS heard_releases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                canonical_key TEXT NOT NULL UNIQUE,
                artist TEXT NOT NULL,
                title TEXT NOT NULL,
                normalized_artist TEXT NOT NULL,
                normalized_title TEXT NOT NULL,
                release_year INTEGER,
                mb_release_group_id TEXT,
                spotify_album_id TEXT,
                release_date TEXT,
                release_type TEXT,
                marked_at TEXT NOT NULL,
                session_id TEXT,
                profile_name TEXT,
                category TEXT DEFAULT 'input'
            );

            CREATE INDEX IF NOT EXISTS idx_heard_mb_release_group
                ON heard_releases(mb_release_group_id);
            CREATE INDEX IF NOT EXISTS idx_heard_spotify_album
                ON heard_releases(spotify_album_id);
            CREATE INDEX IF NOT EXISTS idx_heard_fallback
                ON heard_releases(normalized_artist, normalized_title, release_year);

            CREATE TABLE IF NOT EXISTS heard_release_tracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                heard_release_id INTEGER NOT NULL REFERENCES heard_releases(id) ON DELETE CASCADE,
                isrc TEXT,
                spotify_track_id TEXT,
                tidal_track_id TEXT,
                apple_music_track_id TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_heard_track_isrc
                ON heard_release_tracks(isrc);
            CREATE INDEX IF NOT EXISTS idx_heard_track_spotify
                ON heard_release_tracks(spotify_track_id);
            CREATE INDEX IF NOT EXISTS idx_heard_track_tidal
                ON heard_release_tracks(tidal_track_id);
            CREATE INDEX IF NOT EXISTS idx_heard_track_apple
                ON heard_release_tracks(apple_music_track_id);

            CREATE TABLE IF NOT EXISTS api_cache (
                provider TEXT NOT NULL,
                cache_key TEXT NOT NULL,
                response_json TEXT NOT NULL,
                fetched_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                PRIMARY KEY (provider, cache_key)
            );

            CREATE TABLE IF NOT EXISTS cache_stats (
                provider TEXT NOT NULL,
                stat_name TEXT NOT NULL,
                stat_value INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (provider, stat_name)
            );

            CREATE TABLE IF NOT EXISTS artist_enrichment (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                provider TEXT NOT NULL,
                artist_key TEXT NOT NULL,
                artist_name TEXT NOT NULL,
                provider_artist_id TEXT,
                status TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                attempted_at TEXT NOT NULL,
                fetched_at TEXT,
                error TEXT,
                UNIQUE(provider, artist_key)
            );

            CREATE INDEX IF NOT EXISTS idx_artist_enrichment_provider_id
                ON artist_enrichment(provider, provider_artist_id);
            CREATE INDEX IF NOT EXISTS idx_artist_enrichment_status
                ON artist_enrichment(provider, status);

            CREATE TABLE IF NOT EXISTS track_enrichment (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                provider TEXT NOT NULL,
                track_key TEXT NOT NULL,
                artist TEXT NOT NULL,
                title TEXT NOT NULL,
                album TEXT,
                isrc TEXT,
                spotify_track_id TEXT,
                tidal_track_id TEXT,
                spotify_album_id TEXT,
                tidal_album_id TEXT,
                status TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                attempted_at TEXT NOT NULL,
                fetched_at TEXT,
                error TEXT,
                UNIQUE(provider, track_key)
            );

            CREATE INDEX IF NOT EXISTS idx_track_enrichment_spotify_track
                ON track_enrichment(provider, spotify_track_id);
            CREATE INDEX IF NOT EXISTS idx_track_enrichment_tidal_track
                ON track_enrichment(provider, tidal_track_id);
            CREATE INDEX IF NOT EXISTS idx_track_enrichment_isrc
                ON track_enrichment(provider, isrc);
            CREATE INDEX IF NOT EXISTS idx_track_enrichment_status
                ON track_enrichment(provider, status);

            CREATE TABLE IF NOT EXISTS recommendation_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_hash TEXT,
                config_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS recommendation_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id INTEGER NOT NULL REFERENCES recommendation_runs(id) ON DELETE CASCADE,
                release_key TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                score REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS artists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                normalized_name TEXT NOT NULL UNIQUE,
                mbid TEXT,
                spotify_id TEXT,
                country TEXT
            );

            CREATE TABLE IF NOT EXISTS releases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                normalized_title TEXT NOT NULL,
                artist_name TEXT NOT NULL,
                normalized_artist TEXT NOT NULL,
                mb_release_group_id TEXT,
                spotify_album_id TEXT,
                release_date TEXT,
                release_type TEXT,
                label TEXT
            );

            CREATE TABLE IF NOT EXISTS release_tracks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                release_id INTEGER NOT NULL REFERENCES releases(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                track_number INTEGER,
                spotify_track_id TEXT,
                isrc TEXT,
                popularity INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS taste_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                source_type TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                source_key TEXT NOT NULL UNIQUE,
                source_hash TEXT NOT NULL,
                track_count INTEGER NOT NULL,
                artist_count INTEGER NOT NULL,
                profile_json TEXT NOT NULL,
                seed_tracks_json TEXT NOT NULL,
                seed_track_keys_json TEXT NOT NULL,
                use_expansion_memories INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_used_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_taste_profiles_name
                ON taste_profiles(name);
            CREATE INDEX IF NOT EXISTS idx_taste_profiles_source_key
                ON taste_profiles(source_key);

            CREATE TABLE IF NOT EXISTS profile_expansion_memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                profile_id INTEGER NOT NULL REFERENCES taste_profiles(id) ON DELETE CASCADE,
                artist_key TEXT NOT NULL,
                artist_name TEXT NOT NULL,
                provider TEXT NOT NULL,
                tier TEXT,
                confidence REAL,
                score REAL,
                evidence_json TEXT NOT NULL,
                memory_version INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(profile_id, artist_key, provider)
            );

            CREATE INDEX IF NOT EXISTS idx_profile_expansion_memories_profile
                ON profile_expansion_memories(profile_id);

            CREATE TABLE IF NOT EXISTS excluded_artists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                normalized_name TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                added_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_excluded_artist_name
                ON excluded_artists(normalized_name);
            """
        )
        self.conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (SCHEMA_VERSION, _now()),
        )
        self._commit_with_retry()
        self._apply_migrations()

    def _apply_migrations(self) -> None:
        """Apply any pending schema migrations for new columns."""
        try:
            # Check if migration is needed
            cur = self.conn.execute("PRAGMA table_info(heard_releases)")
            columns = {row[1] for row in cur.fetchall()}

            if "session_id" not in columns:
                self.conn.execute("ALTER TABLE heard_releases ADD COLUMN session_id TEXT")
            if "profile_name" not in columns:
                self.conn.execute("ALTER TABLE heard_releases ADD COLUMN profile_name TEXT")
            if "category" not in columns:
                self.conn.execute("ALTER TABLE heard_releases ADD COLUMN category TEXT DEFAULT 'input'")

            profile_columns = {
                row[1] for row in self.conn.execute("PRAGMA table_info(taste_profiles)").fetchall()
            }
            if "use_expansion_memories" not in profile_columns:
                self.conn.execute(
                    "ALTER TABLE taste_profiles ADD COLUMN use_expansion_memories INTEGER NOT NULL DEFAULT 0"
                )

            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_session_id ON heard_releases(session_id)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_session_category ON heard_releases(session_id, category)")
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS heard_release_tracks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    heard_release_id INTEGER NOT NULL REFERENCES heard_releases(id) ON DELETE CASCADE,
                    isrc TEXT,
                    spotify_track_id TEXT,
                    tidal_track_id TEXT,
                    apple_music_track_id TEXT
                )
                """
            )
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_track_isrc ON heard_release_tracks(isrc)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_track_spotify ON heard_release_tracks(spotify_track_id)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_track_tidal ON heard_release_tracks(tidal_track_id)")
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_heard_track_apple ON heard_release_tracks(apple_music_track_id)")
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS profile_expansion_memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    profile_id INTEGER NOT NULL REFERENCES taste_profiles(id) ON DELETE CASCADE,
                    artist_key TEXT NOT NULL,
                    artist_name TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    tier TEXT,
                    confidence REAL,
                    score REAL,
                    evidence_json TEXT NOT NULL,
                    memory_version INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(profile_id, artist_key, provider)
                )
                """
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_profile_expansion_memories_profile ON profile_expansion_memories(profile_id)"
            )
            self._repair_heard_identity_bridges()
            self._commit_with_retry()
        except Exception as e:
            # Migration may have already been applied in a previous run
            pass

    def add_heard(
        self,
        artist: str,
        title: str,
        release_date: str | None = None,
        release_type: str | None = None,
        mb_release_group_id: str | None = None,
        spotify_album_id: str | None = None,
        label: str | None = None,
        session_id: str | None = None,
        profile_name: str | None = None,
        category: str = "input",
    ) -> int:
        canonical_key = canonical_release_key(
            artist=artist,
            title=title,
            release_date=release_date,
            mb_release_group_id=mb_release_group_id,
            spotify_album_id=spotify_album_id,
            label=label,
        )
        with self._write_transaction():
            self.conn.execute(
                """
                INSERT OR IGNORE INTO heard_releases (
                    canonical_key, artist, title, normalized_artist, normalized_title,
                    release_year, mb_release_group_id, spotify_album_id,
                    release_date, release_type, marked_at, session_id, profile_name, category
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    canonical_key,
                    artist,
                    title,
                    normalize_key(artist),
                    normalize_variant_title(title),
                    release_year(release_date),
                    mb_release_group_id,
                    spotify_album_id,
                    release_date or "",
                    release_type or "",
                    _now(),
                    session_id,
                    profile_name,
                    category,
                ),
            )
            # If the row already exists (INSERT OR IGNORE), opportunistically
            # backfill missing metadata from the newer payload.
            self.conn.execute(
                """
                UPDATE heard_releases
                SET
                    release_date = CASE
                        WHEN COALESCE(release_date, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_date
                    END,
                    release_year = CASE
                        WHEN COALESCE(release_year, -1) = -1 AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_year
                    END,
                    release_type = CASE
                        WHEN COALESCE(release_type, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_type
                    END,
                    mb_release_group_id = CASE
                        WHEN COALESCE(mb_release_group_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE mb_release_group_id
                    END,
                    spotify_album_id = CASE
                        WHEN COALESCE(spotify_album_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE spotify_album_id
                    END
                WHERE canonical_key = ?
                """,
                (
                    release_date,
                    release_date,
                    release_date,
                    release_year(release_date),
                    release_type,
                    release_type,
                    mb_release_group_id,
                    mb_release_group_id,
                    spotify_album_id,
                    spotify_album_id,
                    canonical_key,
                ),
            )
        row = self.conn.execute(
            "SELECT id FROM heard_releases WHERE canonical_key = ?",
            (canonical_key,),
        ).fetchone()
        return int(row["id"])

    def add_heard_recommendation(
        self,
        release: ReleaseRecommendation,
        session_id: str | None = None,
        profile_name: str | None = None,
        category: str = "output",
    ) -> int:
        heard_id = self.add_heard(
            artist=release.artist,
            title=release.title,
            release_date=release.release_date,
            release_type=release.release_type,
            mb_release_group_id=release.mb_release_group_id,
            spotify_album_id=release.spotify_album_id,
            session_id=session_id,
            profile_name=profile_name,
            category=category,
        )
        self._upsert_heard_release_tracks(heard_id, release.tracks)
        self._commit_with_retry()
        return heard_id

    def backfill_heard_recommendation(self, release: ReleaseRecommendation) -> int:
        """Backfill missing metadata on existing heard entries for this release."""
        updated = 0
        if release.mb_release_group_id:
            cur = self.conn.execute(
                """
                UPDATE heard_releases
                SET
                    release_date = CASE
                        WHEN COALESCE(release_date, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_date
                    END,
                    release_year = CASE
                        WHEN COALESCE(release_year, -1) = -1 AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_year
                    END,
                    release_type = CASE
                        WHEN COALESCE(release_type, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_type
                    END,
                    spotify_album_id = CASE
                        WHEN COALESCE(spotify_album_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE spotify_album_id
                    END
                WHERE mb_release_group_id = ?
                """,
                (
                    release.release_date,
                    release.release_date,
                    release.release_date,
                    release_year(release.release_date),
                    release.release_type,
                    release.release_type,
                    release.spotify_album_id,
                    release.spotify_album_id,
                    release.mb_release_group_id,
                ),
            )
            updated += max(0, cur.rowcount)
        if release.spotify_album_id:
            cur = self.conn.execute(
                """
                UPDATE heard_releases
                SET
                    release_date = CASE
                        WHEN COALESCE(release_date, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_date
                    END,
                    release_year = CASE
                        WHEN COALESCE(release_year, -1) = -1 AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_year
                    END,
                    release_type = CASE
                        WHEN COALESCE(release_type, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE release_type
                    END,
                    mb_release_group_id = CASE
                        WHEN COALESCE(mb_release_group_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE mb_release_group_id
                    END
                WHERE spotify_album_id = ?
                """,
                (
                    release.release_date,
                    release.release_date,
                    release.release_date,
                    release_year(release.release_date),
                    release.release_type,
                    release.release_type,
                    release.mb_release_group_id,
                    release.mb_release_group_id,
                    release.spotify_album_id,
                ),
            )
            updated += max(0, cur.rowcount)
        self._commit_with_retry()
        return updated

    def is_heard(
        self,
        artist: str,
        title: str,
        release_date: str | None = None,
        mb_release_group_id: str | None = None,
        spotify_album_id: str | None = None,
        label: str | None = None,
    ) -> bool:
        return self.heard_match_reason(
            artist=artist,
            title=title,
            release_date=release_date,
            mb_release_group_id=mb_release_group_id,
            spotify_album_id=spotify_album_id,
            label=label,
        ) is not None

    def heard_match_reason(
        self,
        artist: str,
        title: str,
        release_date: str | None = None,
        mb_release_group_id: str | None = None,
        spotify_album_id: str | None = None,
        label: str | None = None,
    ) -> str | None:
        if mb_release_group_id:
            row = self.conn.execute(
                "SELECT 1 FROM heard_releases WHERE mb_release_group_id = ? LIMIT 1",
                (mb_release_group_id,),
            ).fetchone()
            if row:
                return "mbid"
        if spotify_album_id:
            row = self.conn.execute(
                "SELECT 1 FROM heard_releases WHERE spotify_album_id = ? LIMIT 1",
                (spotify_album_id,),
            ).fetchone()
            if row:
                return "spotify_album"
        target_artist = normalize_key(artist)
        target_title = normalize_variant_title(title)
        target_label = normalize_key(label) if label else None
        target_year = release_year(release_date)
        if target_label:
            rows = self.conn.execute(
                """
                SELECT title, normalized_title, release_year
                FROM heard_releases
                WHERE normalized_artist = ?
                  AND normalized_title = ?
                """,
                (target_artist, target_title),
            ).fetchall()
        else:
            rows = self.conn.execute(
                """
                SELECT title, normalized_title, release_year
                FROM heard_releases
                WHERE normalized_artist = ?
                """,
                (target_artist,),
            ).fetchall()
        for row in rows:
            stored_title_key = row["normalized_title"] or normalize_variant_title(row["title"])
            if not (stored_title_key == target_title or titles_match(row["title"], title)):
                continue
            stored_year = row["release_year"]
            # Treat unknown release years as a wildcard for fallback matches.
            # This prevents "same release, one run missing date metadata" from bypassing heard exclusion.
            if target_year is None or stored_year is None or int(stored_year) == int(target_year):
                return "fallback_title"
        return None

    def is_heard_recommendation(self, release: ReleaseRecommendation) -> bool:
        return self.heard_match_reason_recommendation(release) is not None

    def heard_match_reason_recommendation(self, release: ReleaseRecommendation) -> str | None:
        reason = self.heard_match_reason(
            artist=release.artist,
            title=release.title,
            release_date=release.release_date,
            mb_release_group_id=release.mb_release_group_id,
            spotify_album_id=release.spotify_album_id,
            label=release.label,
        )
        if reason:
            return reason
        for track in release.tracks:
            isrc = _canonical_isrc(track.isrc)
            if isrc:
                row = self.conn.execute(
                    "SELECT 1 FROM heard_release_tracks WHERE isrc = ? LIMIT 1",
                    (isrc,),
                ).fetchone()
                if row:
                    return "track_isrc"
            if track.spotify_track_id:
                row = self.conn.execute(
                    "SELECT 1 FROM heard_release_tracks WHERE spotify_track_id = ? LIMIT 1",
                    (str(track.spotify_track_id),),
                ).fetchone()
                if row:
                    return "track_spotify"
            if track.tidal_track_id:
                row = self.conn.execute(
                    "SELECT 1 FROM heard_release_tracks WHERE tidal_track_id = ? LIMIT 1",
                    (str(track.tidal_track_id),),
                ).fetchone()
                if row:
                    return "track_tidal"
            if track.apple_music_track_id:
                row = self.conn.execute(
                    "SELECT 1 FROM heard_release_tracks WHERE apple_music_track_id = ? LIMIT 1",
                    (str(track.apple_music_track_id),),
                ).fetchone()
                if row:
                    return "track_apple"
        return None

    def heard_row_sparsity(self) -> dict[str, int]:
        row = self.conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN COALESCE(mb_release_group_id, '') <> '' THEN 1 ELSE 0 END) AS with_mbid,
                SUM(CASE WHEN COALESCE(spotify_album_id, '') <> '' THEN 1 ELSE 0 END) AS with_spotify_album,
                SUM(CASE WHEN release_year IS NOT NULL THEN 1 ELSE 0 END) AS with_release_year
            FROM heard_releases
            """
        ).fetchone()
        if not row:
            return {"total": 0, "with_mbid": 0, "with_spotify_album": 0, "with_release_year": 0}
        return {
            "total": int(row["total"] or 0),
            "with_mbid": int(row["with_mbid"] or 0),
            "with_spotify_album": int(row["with_spotify_album"] or 0),
            "with_release_year": int(row["with_release_year"] or 0),
        }

    def _repair_heard_identity_bridges(self) -> int:
        """Backfill missing MBID/Spotify IDs for deterministically matching heard rows."""
        rows = self.conn.execute(
            """
            SELECT
                id,
                canonical_key,
                normalized_artist,
                normalized_title,
                release_year,
                mb_release_group_id,
                spotify_album_id
            FROM heard_releases
            """
        ).fetchall()
        if not rows:
            return 0

        by_key: dict[str, dict[str, str | None]] = {}
        for row in rows:
            canonical_key = str(row["canonical_key"] or "")
            if not canonical_key:
                continue
            agg = by_key.setdefault(canonical_key, {"mbid": None, "spotify": None})
            if not agg["mbid"] and row["mb_release_group_id"]:
                agg["mbid"] = str(row["mb_release_group_id"])
            if not agg["spotify"] and row["spotify_album_id"]:
                agg["spotify"] = str(row["spotify_album_id"])

        updates = 0
        for canonical_key, ids in by_key.items():
            if not ids["mbid"] and not ids["spotify"]:
                continue
            cur = self.conn.execute(
                """
                UPDATE heard_releases
                SET
                    mb_release_group_id = CASE
                        WHEN COALESCE(mb_release_group_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE mb_release_group_id
                    END,
                    spotify_album_id = CASE
                        WHEN COALESCE(spotify_album_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                        ELSE spotify_album_id
                    END
                WHERE canonical_key = ?
                """,
                (
                    ids["mbid"],
                    ids["mbid"],
                    ids["spotify"],
                    ids["spotify"],
                    canonical_key,
                ),
            )
            updates += max(0, cur.rowcount)

        # Secondary bridge: same normalized artist/title (and usually same year),
        # but different canonical keys due to sparse historical metadata.
        grouped: dict[str, list[sqlite3.Row]] = {}
        for row in rows:
            artist_key = str(row["normalized_artist"] or "")
            title_key = str(row["normalized_title"] or "")
            if not artist_key or not title_key:
                continue
            group_key = f"{artist_key}|{title_key}"
            grouped.setdefault(group_key, []).append(row)

        for cluster in grouped.values():
            mbids = {str(row["mb_release_group_id"]) for row in cluster if row["mb_release_group_id"]}
            spotify_ids = {str(row["spotify_album_id"]) for row in cluster if row["spotify_album_id"]}
            if len(mbids) > 1 or len(spotify_ids) > 1:
                continue
            mbid = next(iter(mbids), None)
            spotify_id = next(iter(spotify_ids), None)
            if not mbid and not spotify_id:
                continue
            for row in cluster:
                cur = self.conn.execute(
                    """
                    UPDATE heard_releases
                    SET
                        mb_release_group_id = CASE
                            WHEN COALESCE(mb_release_group_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                            ELSE mb_release_group_id
                        END,
                        spotify_album_id = CASE
                            WHEN COALESCE(spotify_album_id, '') = '' AND COALESCE(?, '') <> '' THEN ?
                            ELSE spotify_album_id
                        END
                    WHERE id = ?
                    """,
                    (mbid, mbid, spotify_id, spotify_id, int(row["id"])),
                )
                updates += max(0, cur.rowcount)
        return updates

    def list_heard(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT id, artist, title, release_date, release_type,
                   mb_release_group_id, spotify_album_id, marked_at
            FROM heard_releases
            ORDER BY marked_at DESC, id DESC
            """
        ).fetchall()
        return [dict(row) for row in rows]

    def _upsert_heard_release_tracks(self, heard_release_id: int, tracks: list[Any]) -> int:
        inserted = 0
        for track in tracks:
            isrc = _canonical_isrc(getattr(track, "isrc", None))
            spotify_track_id = _norm_optional_str(getattr(track, "spotify_track_id", None))
            tidal_track_id = _norm_optional_str(getattr(track, "tidal_track_id", None))
            apple_music_track_id = _norm_optional_str(getattr(track, "apple_music_track_id", None))
            if not any((isrc, spotify_track_id, tidal_track_id, apple_music_track_id)):
                continue
            cur = self.conn.execute(
                """
                INSERT INTO heard_release_tracks (
                    heard_release_id,
                    isrc,
                    spotify_track_id,
                    tidal_track_id,
                    apple_music_track_id
                )
                SELECT ?, ?, ?, ?, ?
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM heard_release_tracks
                    WHERE heard_release_id = ?
                      AND COALESCE(isrc, '') = COALESCE(?, '')
                      AND COALESCE(spotify_track_id, '') = COALESCE(?, '')
                      AND COALESCE(tidal_track_id, '') = COALESCE(?, '')
                      AND COALESCE(apple_music_track_id, '') = COALESCE(?, '')
                )
                """,
                (
                    heard_release_id,
                    isrc,
                    spotify_track_id,
                    tidal_track_id,
                    apple_music_track_id,
                    heard_release_id,
                    isrc,
                    spotify_track_id,
                    tidal_track_id,
                    apple_music_track_id,
                ),
            )
            inserted += max(0, cur.rowcount)
        return inserted

    def all_heard_release_group_mbids(self) -> set[str]:
        """Return all unique MB release-group IDs from heard releases."""
        rows = self.conn.execute(
            "SELECT DISTINCT mb_release_group_id FROM heard_releases WHERE mb_release_group_id IS NOT NULL"
        ).fetchall()
        return {row["mb_release_group_id"] for row in rows if row["mb_release_group_id"]}

    def remove_heard(self, entry_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM heard_releases WHERE id = ?", (entry_id,))
        self._commit_with_retry()
        return cur.rowcount > 0

    def clear_heard(self) -> int:
        cur = self.conn.execute("DELETE FROM heard_releases")
        self._commit_with_retry()
        return cur.rowcount

    def list_heard_grouped(self) -> list[dict[str, Any]]:
        """Return heard releases grouped by session, with subcategories for input/output."""
        rows = self.conn.execute(
            """
            SELECT id, artist, title, release_date, release_type,
                   session_id, profile_name, category, marked_at
            FROM heard_releases
            ORDER BY COALESCE(session_id, 'zzz') DESC, marked_at DESC, id DESC
            """
        ).fetchall()

        grouped: dict[str, dict] = {}
        legacy_entries = []

        for row in rows:
            entry_dict = dict(row)
            session_id = entry_dict.get("session_id")

            if not session_id:
                legacy_entries.append(entry_dict)
                continue

            if session_id not in grouped:
                grouped[session_id] = {
                    "session_id": session_id,
                    "profile_name": entry_dict.get("profile_name"),
                    "timestamp": None,
                    "input_releases": [],
                    "output_releases": [],
                }

            category = entry_dict.get("category", "input")
            if category == "output":
                grouped[session_id]["output_releases"].append(entry_dict)
            else:
                grouped[session_id]["input_releases"].append(entry_dict)

        # Build result with legacy first, then grouped sessions
        result = []
        if legacy_entries:
            result.append({
                "session_id": None,
                "profile_name": "Ungrouped (Legacy)",
                "timestamp": None,
                "input_releases": legacy_entries,
                "output_releases": [],
            })

        # Add grouped sessions in reverse chronological order
        for session_id in sorted(grouped.keys(), reverse=True):
            result.append(grouped[session_id])

        return result

    def remove_heard_by_session(self, session_id: str) -> int:
        """Remove all heard releases for a specific session."""
        cur = self.conn.execute(
            "DELETE FROM heard_releases WHERE session_id = ?",
            (session_id,),
        )
        self._commit_with_retry()
        return cur.rowcount

    def remove_heard_by_category(self, session_id: str, category: str) -> int:
        """Remove heard releases for a specific session and category (input/output)."""
        cur = self.conn.execute(
            "DELETE FROM heard_releases WHERE session_id = ? AND category = ?",
            (session_id, category),
        )
        self._commit_with_retry()
        return cur.rowcount

    def export_heard_json(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        grouped = self.list_heard_grouped()
        payload = {"heard_grouped": grouped, "heard": self.list_heard()}
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    def import_heard_json(self, path: Path) -> int:
        payload = json.loads(path.read_text(encoding="utf-8"))
        count = 0

        # Try new grouped format first
        if "heard_grouped" in payload:
            for session_group in payload["heard_grouped"]:
                session_id = session_group.get("session_id")
                profile_name = session_group.get("profile_name")

                for item in session_group.get("input_releases", []):
                    self.add_heard(
                        artist=item["artist"],
                        title=item.get("title") or item.get("release") or item.get("album") or "",
                        release_date=item.get("release_date"),
                        release_type=item.get("release_type"),
                        mb_release_group_id=item.get("mb_release_group_id"),
                        spotify_album_id=item.get("spotify_album_id"),
                        session_id=session_id,
                        profile_name=profile_name,
                        category="input",
                    )
                    count += 1

                for item in session_group.get("output_releases", []):
                    self.add_heard(
                        artist=item["artist"],
                        title=item.get("title") or item.get("release") or item.get("album") or "",
                        release_date=item.get("release_date"),
                        release_type=item.get("release_type"),
                        mb_release_group_id=item.get("mb_release_group_id"),
                        spotify_album_id=item.get("spotify_album_id"),
                        session_id=session_id,
                        profile_name=profile_name,
                        category="output",
                    )
                    count += 1
        else:
            # Fallback to old flat format
            for item in payload.get("heard", []):
                self.add_heard(
                    artist=item["artist"],
                    title=item.get("title") or item.get("release") or item.get("album") or "",
                    release_date=item.get("release_date"),
                    release_type=item.get("release_type"),
                    mb_release_group_id=item.get("mb_release_group_id"),
                    spotify_album_id=item.get("spotify_album_id"),
                )
                count += 1
        return count

    def import_heard_csv(self, path: Path) -> int:
        count = 0
        with path.open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                artist = str(
                    row.get("Artist name")
                    or row.get("Artist")
                    or row.get("artist")
                    or ""
                ).strip()
                if not artist:
                    continue

                title = str(
                    row.get("Album")
                    or row.get("album")
                    or row.get("Title")
                    or row.get("Track name")
                    or row.get("track")
                    or ""
                ).strip()
                if not title:
                    continue

                self.add_heard(
                    artist=artist,
                    title=title,
                    release_date=str(row.get("Release date") or row.get("release_date") or "").strip() or None,
                    mb_release_group_id=str(row.get("MB Release Group ID") or row.get("mb_release_group_id") or "").strip() or None,
                    spotify_album_id=str(row.get("Spotify album ID") or row.get("spotify_album_id") or "").strip() or None,
                )
                count += 1
        return count

    def import_heard_file(self, path: Path) -> int:
        suffix = path.suffix.lower()
        if suffix == ".csv":
            return self.import_heard_csv(path)
        return self.import_heard_json(path)

    # ------------------------------------------------------------------
    # Excluded artists
    # ------------------------------------------------------------------

    def add_excluded_artist(self, artist: str) -> int:
        normalized = normalize_key(artist)
        if not normalized:
            raise ValueError("Artist name must not be empty.")
        self.conn.execute(
            "INSERT OR IGNORE INTO excluded_artists (normalized_name, display_name, added_at) VALUES (?, ?, ?)",
            (normalized, artist.strip(), _now()),
        )
        self._commit_with_retry()
        row = self.conn.execute(
            "SELECT id FROM excluded_artists WHERE normalized_name = ?", (normalized,)
        ).fetchone()
        return int(row["id"]) if row else 0

    def list_excluded_artists(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT id, normalized_name, display_name, added_at FROM excluded_artists ORDER BY display_name COLLATE NOCASE"
        ).fetchall()
        return [dict(r) for r in rows]

    def remove_excluded_artist(self, entry_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM excluded_artists WHERE id = ?", (entry_id,))
        self._commit_with_retry()
        return cur.rowcount > 0

    def clear_excluded_artists(self) -> int:
        cur = self.conn.execute("DELETE FROM excluded_artists")
        self._commit_with_retry()
        return cur.rowcount

    def all_excluded_artist_keys(self) -> set[str]:
        rows = self.conn.execute("SELECT normalized_name FROM excluded_artists").fetchall()
        return {row["normalized_name"] for row in rows}

    def get_cache(self, provider: str, cache_key: str) -> Any | None:
        row = self.conn.execute(
            "SELECT response_json, expires_at FROM api_cache WHERE provider = ? AND cache_key = ?",
            (provider, cache_key),
        ).fetchone()
        if not row:
            self._record_cache_stat(provider, "miss")
            return None
        expires_at = dt.datetime.fromisoformat(row["expires_at"])
        if expires_at <= dt.datetime.now():
            self.conn.execute(
                "DELETE FROM api_cache WHERE provider = ? AND cache_key = ?",
                (provider, cache_key),
            )
            self._record_cache_stat(provider, "miss")
            self._commit_with_retry()
            return None
        self._record_cache_stat(provider, "hit")
        return json.loads(row["response_json"])

    def set_cache(self, provider: str, cache_key: str, value: Any, ttl_seconds: int) -> None:
        now = dt.datetime.now()
        expires_at = now + dt.timedelta(seconds=ttl_seconds)
        with self._write_transaction():
            self.conn.execute(
                """
                INSERT OR REPLACE INTO api_cache(provider, cache_key, response_json, fetched_at, expires_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    provider,
                    cache_key,
                    json.dumps(value, ensure_ascii=False),
                    now.isoformat(),
                    expires_at.isoformat(),
                ),
            )

    def clear_cache(self) -> int:
        cur = self.conn.execute("DELETE FROM api_cache")
        self.conn.execute("DELETE FROM cache_stats")
        self._commit_with_retry()
        return cur.rowcount

    def clear_provider_cache(self, provider: str) -> int:
        cur = self.conn.execute("DELETE FROM api_cache WHERE provider = ?", (provider,))
        self.conn.execute("DELETE FROM cache_stats WHERE provider = ?", (provider,))
        self._commit_with_retry()
        return cur.rowcount

    def diagnostic_counts(self) -> dict[str, int | str]:
        quick_check = self.conn.execute("PRAGMA quick_check").fetchone()
        return {
            "schema_version": SCHEMA_VERSION,
            "quick_check": quick_check[0] if quick_check else "unknown",
            "heard_releases": self._table_count("heard_releases"),
            "taste_profiles": self._table_count("taste_profiles"),
            "api_cache_entries": self._table_count("api_cache"),
            "artist_enrichment_entries": self._table_count("artist_enrichment"),
            "track_enrichment_entries": self._table_count("track_enrichment"),
            "recommendation_runs": self._table_count("recommendation_runs"),
        }

    def health_report(self) -> dict[str, Any]:
        quick_row = self.conn.execute("PRAGMA quick_check").fetchone()
        integrity_row = self.conn.execute("PRAGMA integrity_check").fetchone()
        journal_mode = self.conn.execute("PRAGMA journal_mode").fetchone()
        wal_checkpoint = self.conn.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
        return {
            "db_path": str(self.db_path),
            "engine": self.engine,
            "quick_check": quick_row[0] if quick_row else "unknown",
            "integrity_check": integrity_row[0] if integrity_row else "unknown",
            "journal_mode": journal_mode[0] if journal_mode else "unknown",
            "wal_checkpoint": list(wal_checkpoint) if wal_checkpoint else [],
            "counts": self.diagnostic_counts(),
        }

    def backup_to(self, output_path: Path) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        dst = sqlite3.connect(output_path)
        try:
            self.conn.backup(dst)
        finally:
            dst.close()

    def vacuum(self) -> None:
        self.conn.execute("VACUUM")
        self._commit_with_retry()

    def cache_diagnostics(self) -> dict[str, dict[str, int]]:
        providers = ("spotify", "musicbrainz", "lastfm", "deezer")
        entries_by_provider = {
            row["provider"]: int(row["count"])
            for row in self.conn.execute(
                """
                SELECT provider, COUNT(*) AS count
                FROM api_cache
                GROUP BY provider
                """
            ).fetchall()
        }
        stats_by_provider: dict[str, dict[str, int]] = {
            provider: {"entries": entries_by_provider.get(provider, 0), "hits": 0, "misses": 0}
            for provider in providers
        }
        for row in self.conn.execute("SELECT provider, stat_name, stat_value FROM cache_stats").fetchall():
            provider = row["provider"]
            if provider not in stats_by_provider:
                stats_by_provider[provider] = {
                    "entries": entries_by_provider.get(provider, 0),
                    "hits": 0,
                    "misses": 0,
                }
            stat_name = row["stat_name"]
            if stat_name == "hit":
                stats_by_provider[provider]["hits"] = int(row["stat_value"])
            elif stat_name == "miss":
                stats_by_provider[provider]["misses"] = int(row["stat_value"])
        return stats_by_provider

    def _table_count(self, table_name: str) -> int:
        row = self.conn.execute(f"SELECT COUNT(*) AS count FROM {table_name}").fetchone()
        return int(row["count"])

    def _record_cache_stat(self, provider: str, stat_name: str) -> None:
        self.conn.execute(
            """
            INSERT INTO cache_stats(provider, stat_name, stat_value, updated_at)
            VALUES (?, ?, 1, ?)
            ON CONFLICT(provider, stat_name) DO UPDATE SET
                stat_value = cache_stats.stat_value + 1,
                updated_at = excluded.updated_at
            """,
            (provider, stat_name, _now()),
        )
        self._commit_with_retry()

    def record_run(
        self,
        recommendations: list[ReleaseRecommendation],
        config: dict[str, Any],
        source_hash: str | None = None,
    ) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO recommendation_runs(source_hash, config_json, created_at)
            VALUES (?, ?, ?)
            """,
            (source_hash, json.dumps(config, sort_keys=True), _now()),
        )
        run_id = int(cur.lastrowid)
        for rec in recommendations:
            self.conn.execute(
                """
                INSERT INTO recommendation_items(run_id, release_key, payload_json, score)
                VALUES (?, ?, ?, ?)
                """,
                (run_id, rec.fallback_key, json.dumps(rec.export_dict()), rec.score),
            )
        self._commit_with_retry()
        return run_id

    def upsert_artist_enrichment(
        self,
        *,
        provider: str,
        artist_name: str,
        provider_artist_id: str | None = None,
        status: str = "success",
        payload: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        _validate_enrichment_status(status)
        artist_key = artist_enrichment_key(artist_name=artist_name, provider_artist_id=provider_artist_id)
        if not artist_key:
            raise ValueError("artist enrichment needs an artist name or provider artist id")
        now = _now()
        fetched_at = now if status == "success" else None
        with self._lock:
            self.conn.execute(
                """
                INSERT INTO artist_enrichment (
                    provider, artist_key, artist_name, provider_artist_id, status,
                    payload_json, attempted_at, fetched_at, error
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(provider, artist_key) DO UPDATE SET
                    artist_name = excluded.artist_name,
                    provider_artist_id = excluded.provider_artist_id,
                    status = excluded.status,
                    payload_json = excluded.payload_json,
                    attempted_at = excluded.attempted_at,
                    fetched_at = excluded.fetched_at,
                    error = excluded.error
                """,
                (
                    provider,
                    artist_key,
                    artist_name,
                    provider_artist_id,
                    status,
                    json.dumps(payload or {}, ensure_ascii=False, sort_keys=True),
                    now,
                    fetched_at,
                    error,
                ),
            )
            self._commit_with_retry()
        row = self.get_artist_enrichment(
            provider=provider,
            artist_name=artist_name,
            provider_artist_id=provider_artist_id,
        )
        assert row is not None
        return row

    def get_artist_enrichment(
        self,
        *,
        provider: str,
        artist_name: str | None = None,
        provider_artist_id: str | None = None,
    ) -> dict[str, Any] | None:
        with self._lock:
            if provider_artist_id:
                row = self.conn.execute(
                    """
                    SELECT * FROM artist_enrichment
                    WHERE provider = ? AND provider_artist_id = ?
                    ORDER BY attempted_at DESC, id DESC
                    LIMIT 1
                    """,
                    (provider, provider_artist_id),
                ).fetchone()
                if row:
                    return _enrichment_row(row)
            artist_key = artist_enrichment_key(artist_name=artist_name, provider_artist_id=None)
            if not artist_key:
                return None
            row = self.conn.execute(
                """
                SELECT * FROM artist_enrichment
                WHERE provider = ? AND artist_key = ?
                LIMIT 1
                """,
                (provider, artist_key),
            ).fetchone()
            return _enrichment_row(row) if row else None

    def upsert_track_enrichment(
        self,
        *,
        provider: str,
        track: InputTrack | None = None,
        artist: str | None = None,
        title: str | None = None,
        album: str | None = None,
        isrc: str | None = None,
        spotify_track_id: str | None = None,
        tidal_track_id: str | None = None,
        spotify_album_id: str | None = None,
        tidal_album_id: str | None = None,
        status: str = "success",
        payload: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> dict[str, Any]:
        _validate_enrichment_status(status)
        if track is not None:
            artist = artist or track.artist
            title = title or track.track
            album = album if album is not None else track.album
            isrc = isrc or track.isrc
            spotify_track_id = spotify_track_id or track.spotify_track_id
            tidal_track_id = tidal_track_id or track.tidal_track_id
            spotify_album_id = spotify_album_id or track.spotify_album_id
            tidal_album_id = tidal_album_id or track.tidal_album_id
        track_key = track_enrichment_key(
            artist=artist,
            title=title,
            isrc=isrc,
            spotify_track_id=spotify_track_id,
            tidal_track_id=tidal_track_id,
        )
        if not track_key:
            raise ValueError("track enrichment needs a stable id or artist/title metadata")
        now = _now()
        fetched_at = now if status == "success" else None
        self.conn.execute(
            """
            INSERT INTO track_enrichment (
                provider, track_key, artist, title, album, isrc,
                spotify_track_id, tidal_track_id, spotify_album_id, tidal_album_id,
                status, payload_json, attempted_at, fetched_at, error
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(provider, track_key) DO UPDATE SET
                artist = excluded.artist,
                title = excluded.title,
                album = excluded.album,
                isrc = excluded.isrc,
                spotify_track_id = excluded.spotify_track_id,
                tidal_track_id = excluded.tidal_track_id,
                spotify_album_id = excluded.spotify_album_id,
                tidal_album_id = excluded.tidal_album_id,
                status = excluded.status,
                payload_json = excluded.payload_json,
                attempted_at = excluded.attempted_at,
                fetched_at = excluded.fetched_at,
                error = excluded.error
            """,
            (
                provider,
                track_key,
                artist or "",
                title or "",
                album,
                isrc,
                spotify_track_id,
                tidal_track_id,
                spotify_album_id,
                tidal_album_id,
                status,
                json.dumps(payload or {}, ensure_ascii=False, sort_keys=True),
                now,
                fetched_at,
                error,
            ),
        )
        self._commit_with_retry()
        row = self.get_track_enrichment(
            provider=provider,
            artist=artist,
            title=title,
            isrc=isrc,
            spotify_track_id=spotify_track_id,
            tidal_track_id=tidal_track_id,
        )
        assert row is not None
        return row

    def get_track_enrichment(
        self,
        *,
        provider: str,
        track: InputTrack | None = None,
        artist: str | None = None,
        title: str | None = None,
        isrc: str | None = None,
        spotify_track_id: str | None = None,
        tidal_track_id: str | None = None,
    ) -> dict[str, Any] | None:
        if track is not None:
            artist = artist or track.artist
            title = title or track.track
            isrc = isrc or track.isrc
            spotify_track_id = spotify_track_id or track.spotify_track_id
            tidal_track_id = tidal_track_id or track.tidal_track_id
        for column, value in (
            ("isrc", isrc),
            ("spotify_track_id", spotify_track_id),
            ("tidal_track_id", tidal_track_id),
        ):
            if not value:
                continue
            row = self.conn.execute(
                f"""
                SELECT * FROM track_enrichment
                WHERE provider = ? AND {column} = ?
                ORDER BY attempted_at DESC, id DESC
                LIMIT 1
                """,
                (provider, value),
            ).fetchone()
            if row:
                return _enrichment_row(row)
        track_key = track_enrichment_key(
            artist=artist,
            title=title,
            isrc=None,
            spotify_track_id=None,
            tidal_track_id=None,
        )
        if not track_key:
            return None
        row = self.conn.execute(
            """
            SELECT * FROM track_enrichment
            WHERE provider = ? AND track_key = ?
            LIMIT 1
            """,
            (provider, track_key),
        ).fetchone()
        if row:
            return _enrichment_row(row)
        if artist and title:
            row = self.conn.execute(
                """
                SELECT * FROM track_enrichment
                WHERE provider = ? AND artist = ? AND title = ?
                ORDER BY attempted_at DESC, id DESC
                LIMIT 1
                """,
                (provider, artist, title),
            ).fetchone()
            if row:
                return _enrichment_row(row)
        return None

    def get_canonical_track(self, track: InputTrack) -> CanonicalTrack | None:
        for track_key in canonical_track_cache_keys(track):
            row_data = self.conn.execute(
                """
                SELECT * FROM track_enrichment
                WHERE provider = ? AND track_key = ?
                LIMIT 1
                """,
                (CANONICAL_TRACK_PROVIDER, track_key),
            ).fetchone()
            row = _enrichment_row(row_data) if row_data else None
            if not row or row["status"] != "success":
                continue
            payload = row.get("payload") or {}
            if payload.get("cache_version") != CANONICAL_TRACK_CACHE_VERSION:
                continue
            canonical_payload = payload.get("canonical_track")
            if not isinstance(canonical_payload, dict):
                continue
            return CanonicalTrack.model_validate(canonical_payload)
        return None

    def upsert_canonical_track(self, track: InputTrack, canonical: CanonicalTrack) -> dict[str, Any]:
        track_key = canonical_track_cache_key(track)
        if not track_key:
            raise ValueError("canonical track cache needs a stable id or artist/title/album metadata")
        payload = {
            "cache_version": CANONICAL_TRACK_CACHE_VERSION,
            "canonical_track": canonical.model_dump(mode="json"),
        }
        now = _now()
        self.conn.execute(
            """
            INSERT INTO track_enrichment (
                provider, track_key, artist, title, album, isrc,
                spotify_track_id, tidal_track_id, spotify_album_id, tidal_album_id,
                status, payload_json, attempted_at, fetched_at, error
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(provider, track_key) DO UPDATE SET
                artist = excluded.artist,
                title = excluded.title,
                album = excluded.album,
                isrc = excluded.isrc,
                spotify_track_id = excluded.spotify_track_id,
                tidal_track_id = excluded.tidal_track_id,
                spotify_album_id = excluded.spotify_album_id,
                tidal_album_id = excluded.tidal_album_id,
                status = excluded.status,
                payload_json = excluded.payload_json,
                attempted_at = excluded.attempted_at,
                fetched_at = excluded.fetched_at,
                error = excluded.error
            """,
            (
                CANONICAL_TRACK_PROVIDER,
                track_key,
                track.artist,
                track.track,
                track.album,
                track.isrc,
                track.spotify_track_id,
                track.tidal_track_id,
                track.spotify_album_id,
                track.tidal_album_id,
                "success",
                json.dumps(payload, ensure_ascii=False, sort_keys=True),
                now,
                now,
                None,
            ),
        )
        self._commit_with_retry()
        row = self.conn.execute(
            """
            SELECT * FROM track_enrichment
            WHERE provider = ? AND track_key = ?
            LIMIT 1
            """,
            (CANONICAL_TRACK_PROVIDER, track_key),
        ).fetchone()
        assert row is not None
        return _enrichment_row(row)

    def enrichment_completeness(
        self,
        *,
        artists: list[ArtistProfile],
        tracks: list[InputTrack],
    ) -> EnrichmentCompleteness:
        return EnrichmentCompleteness(
            artist_total=len(artists),
            artist_enriched=sum(1 for artist in artists if self._artist_has_successful_enrichment(artist)),
            track_total=len(tracks),
            track_enriched=sum(1 for track in tracks if self._track_has_successful_enrichment(track)),
        )

    def _artist_has_successful_enrichment(self, artist: ArtistProfile) -> bool:
        for provider, provider_artist_id in (
            ("spotify", artist.spotify_id),
            ("musicbrainz", artist.mbid),
            ("lastfm", None),
        ):
            row = self.get_artist_enrichment(
                provider=provider,
                artist_name=artist.name,
                provider_artist_id=provider_artist_id,
            )
            if row and row["status"] == "success":
                return True
        return False

    def _track_has_successful_enrichment(self, track: InputTrack) -> bool:
        for provider in ("spotify", "tidal", "input"):
            row = self.get_track_enrichment(provider=provider, track=track)
            if row and row["status"] == "success":
                return True
        return False

    def upsert_taste_profile(
        self,
        *,
        name: str,
        source_type: str,
        source_ref: str,
        source_key: str,
        source_hash: str,
        track_count: int,
        artist_count: int,
        profile: TasteProfile,
        seed_tracks: list[InputTrack],
        seed_track_keys: set[str],
    ) -> dict[str, Any]:
        now = _now()
        with self._write_transaction():
            self.conn.execute(
                """
                INSERT INTO taste_profiles (
                    name, source_type, source_ref, source_key, source_hash,
                    track_count, artist_count, profile_json, seed_tracks_json,
                    seed_track_keys_json, created_at, updated_at, last_used_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(source_key) DO UPDATE SET
                    name = excluded.name,
                    source_type = excluded.source_type,
                    source_ref = excluded.source_ref,
                    source_hash = excluded.source_hash,
                    track_count = excluded.track_count,
                    artist_count = excluded.artist_count,
                    profile_json = excluded.profile_json,
                    seed_tracks_json = excluded.seed_tracks_json,
                    seed_track_keys_json = excluded.seed_track_keys_json,
                    updated_at = excluded.updated_at,
                    last_used_at = excluded.last_used_at
                """,
                (
                    name,
                    source_type,
                    source_ref,
                    source_key,
                    source_hash,
                    track_count,
                    artist_count,
                    json.dumps(profile.model_dump(mode="json"), ensure_ascii=False),
                    json.dumps([track.model_dump(mode="json") for track in seed_tracks], ensure_ascii=False),
                    json.dumps(sorted(seed_track_keys), ensure_ascii=False),
                    now,
                    now,
                    now,
                ),
            )
        row = self.get_taste_profile(source_key)
        assert row is not None
        return row

    def get_taste_profile(self, identifier: str | int) -> dict[str, Any] | None:
        if isinstance(identifier, int) or str(identifier).isdigit():
            row = self.conn.execute(
                "SELECT * FROM taste_profiles WHERE id = ?",
                (int(identifier),),
            ).fetchone()
            if row:
                return dict(row)

        row = self.conn.execute(
            """
            SELECT * FROM taste_profiles
            WHERE source_key = ? OR name = ?
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            (str(identifier), str(identifier)),
        ).fetchone()
        return dict(row) if row else None

    def find_taste_profile_for_source(self, source: dict[str, str]) -> dict[str, Any] | None:
        profile = self.get_taste_profile(source["source_key"])
        if profile:
            return profile

        row = self.conn.execute(
            """
            SELECT * FROM taste_profiles
            WHERE source_type = ? AND source_ref = ?
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            (source["source_type"], source["source_ref"]),
        ).fetchone()
        if row:
            return dict(row)

        row = self.conn.execute(
            """
            SELECT * FROM taste_profiles
            WHERE source_type = ? AND name = ?
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            (source["source_type"], source["name"]),
        ).fetchone()
        return dict(row) if row else None

    def list_taste_profiles(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT id, name, source_type, source_ref, source_key, source_hash,
                   track_count, artist_count, created_at, updated_at, last_used_at
            FROM taste_profiles
            ORDER BY updated_at DESC, id DESC
            """
        ).fetchall()
        return [dict(row) for row in rows]

    def all_seed_track_keys(self) -> set[str]:
        rows = self.conn.execute("SELECT seed_track_keys_json FROM taste_profiles").fetchall()
        keys: set[str] = set()
        for row in rows:
            try:
                payload = json.loads(row["seed_track_keys_json"])
            except (TypeError, json.JSONDecodeError):
                continue
            keys.update(str(item) for item in payload if item)
        return keys

    def clear_profiles(self) -> int:
        cur = self.conn.execute("DELETE FROM taste_profiles")
        self._commit_with_retry()
        return cur.rowcount

    def delete_taste_profile(self, identifier: str | int) -> bool:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return False
        cur = self.conn.execute("DELETE FROM taste_profiles WHERE id = ?", (profile["id"],))
        self._commit_with_retry()
        return cur.rowcount > 0

    def touch_taste_profile(self, identifier: str | int) -> None:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return
        self.conn.execute("UPDATE taste_profiles SET last_used_at = ? WHERE id = ?", (_now(), profile["id"]))
        self._commit_with_retry()

    def set_profile_use_expansion_memories(self, identifier: str | int, enabled: bool) -> bool:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return False
        self.conn.execute(
            "UPDATE taste_profiles SET use_expansion_memories = ?, updated_at = ? WHERE id = ?",
            (1 if enabled else 0, _now(), profile["id"]),
        )
        self._commit_with_retry()
        return True

    def profile_use_expansion_memories(self, identifier: str | int) -> bool:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return False
        return bool(profile.get("use_expansion_memories", 0))

    def list_profile_expansion_memories(self, identifier: str | int) -> list[dict[str, Any]]:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return []
        rows = self.conn.execute(
            """
            SELECT id, profile_id, artist_key, artist_name, provider, tier, confidence, score,
                   evidence_json, memory_version, created_at, updated_at
            FROM profile_expansion_memories
            WHERE profile_id = ?
            ORDER BY confidence DESC, score DESC, updated_at DESC, id DESC
            """,
            (int(profile["id"]),),
        ).fetchall()
        return [dict(row) for row in rows]

    def upsert_profile_expansion_memory(
        self,
        identifier: str | int,
        *,
        artist_name: str,
        provider: str,
        tier: str | None = None,
        confidence: float | None = None,
        score: float | None = None,
        evidence: dict[str, Any] | None = None,
        memory_version: int = 1,
    ) -> bool:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return False
        artist_key = normalize_key(artist_name)
        if not artist_key:
            return False
        now = _now()
        self.conn.execute(
            """
            INSERT INTO profile_expansion_memories (
                profile_id, artist_key, artist_name, provider, tier, confidence, score,
                evidence_json, memory_version, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(profile_id, artist_key, provider) DO UPDATE SET
                artist_name = excluded.artist_name,
                tier = excluded.tier,
                confidence = excluded.confidence,
                score = excluded.score,
                evidence_json = excluded.evidence_json,
                memory_version = excluded.memory_version,
                updated_at = excluded.updated_at
            """,
            (
                int(profile["id"]),
                artist_key,
                artist_name,
                provider,
                tier or "",
                confidence,
                score,
                json.dumps(evidence or {}, ensure_ascii=False),
                int(memory_version),
                now,
                now,
            ),
        )
        self._commit_with_retry()
        return True

    def delete_profile_expansion_memory(self, memory_id: int) -> bool:
        cur = self.conn.execute("DELETE FROM profile_expansion_memories WHERE id = ?", (int(memory_id),))
        self._commit_with_retry()
        return cur.rowcount > 0

    def clear_profile_expansion_memories(self, identifier: str | int) -> int:
        profile = self.get_taste_profile(identifier)
        if not profile:
            return 0
        cur = self.conn.execute(
            "DELETE FROM profile_expansion_memories WHERE profile_id = ?",
            (int(profile["id"]),),
        )
        self._commit_with_retry()
        return int(cur.rowcount or 0)


def canonical_release_key(
    artist: str,
    title: str,
    release_date: str | None = None,
    mb_release_group_id: str | None = None,
    spotify_album_id: str | None = None,
    label: str | None = None,
    catalog_number: str | None = None,
    streaming_only_id: str | None = None,
) -> str:
    if mb_release_group_id:
        return f"mb-release-group:{mb_release_group_id}"
    if streaming_only_id:
        return streaming_only_id
    if spotify_album_id:
        return f"spotify-album:{spotify_album_id}"
    base_key = release_match_key(artist, title, release_date)
    if label and catalog_number:
        label_key = normalize_key(label)
        catalog_key = normalize_key(catalog_number)
        return f"{base_key}|label:{label_key}|catalog:{catalog_key}"
    if label:
        label_key = normalize_key(label)
        return f"{base_key}|label:{label_key}"
    return base_key


def artist_enrichment_key(
    *,
    artist_name: str | None = None,
    provider_artist_id: str | None = None,
) -> str:
    name_key = normalize_key(artist_name)
    if name_key:
        return f"artist:{name_key}"
    if provider_artist_id:
        return f"provider-artist:{provider_artist_id}"
    return ""


def track_enrichment_key(
    *,
    artist: str | None = None,
    title: str | None = None,
    isrc: str | None = None,
    spotify_track_id: str | None = None,
    tidal_track_id: str | None = None,
) -> str:
    if isrc:
        return f"isrc:{normalize_key(isrc)}"
    if spotify_track_id:
        return f"spotify:track:{spotify_track_id}"
    if tidal_track_id:
        return f"tidal:track:{tidal_track_id}"
    artist_key = normalize_key(artist)
    title_key = normalize_key(title)
    if artist_key and title_key:
        return f"metadata:{artist_key}|{title_key}"
    if title_key:
        return f"metadata:{title_key}"
    if artist_key:
        return f"metadata:{artist_key}"
    return ""


def canonical_track_cache_key(track: InputTrack) -> str:
    keys = canonical_track_cache_keys(track)
    return keys[0] if keys else ""


def canonical_track_cache_keys(track: InputTrack) -> list[str]:
    keys: list[str] = []

    if track.isrc:
        keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:isrc:{normalize_key(track.isrc)}")
    if track.spotify_track_id:
        # Include artist name for multi-artist tracks to avoid cache collisions
        if len(track.artists) > 1:
            keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:spotify:track:{track.spotify_track_id}:artist:{normalize_key(track.artist)}")
        else:
            keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:spotify:track:{track.spotify_track_id}")
    if track.tidal_track_id:
        keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:tidal:track:{track.tidal_track_id}")
    artist_key = normalize_key(track.artist)
    title_key = normalize_key(track.track)
    album_key = normalize_key(track.album)
    if artist_key and title_key:
        keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:metadata:{artist_key}|{title_key}|{album_key}")
        # Fallback key helps cache reuse when album metadata changes between runs.
        keys.append(f"{CANONICAL_TRACK_CACHE_VERSION}:metadata:{artist_key}|{title_key}|")

    deduped: list[str] = []
    seen: set[str] = set()
    for key in keys:
        if key and key not in seen:
            seen.add(key)
            deduped.append(key)
    return deduped


def _validate_enrichment_status(status: str) -> None:
    if status not in ENRICHMENT_STATUSES:
        allowed = ", ".join(sorted(ENRICHMENT_STATUSES))
        raise ValueError(f"enrichment status must be one of: {allowed}")


def _enrichment_row(row: sqlite3.Row) -> dict[str, Any]:
    item = dict(row)
    item["payload"] = json.loads(item.pop("payload_json"))
    return item


def _canonical_isrc(value: str | None) -> str | None:
    raw = (value or "").strip()
    if not raw:
        return None
    compact = "".join(ch for ch in raw.upper() if ch.isalnum())
    return compact or None


def _norm_optional_str(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")
