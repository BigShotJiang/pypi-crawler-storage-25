from __future__ import annotations

import datetime as dt
from typing import Any

from pydantic import BaseModel, Field, model_validator
from typing import Union

from .utils import normalize_key, release_match_key, release_year


class FilteredCommunityArtist(BaseModel):
    """Represents a community artist with enriched filtering metadata."""
    relevance: float
    ubiquity_score: float
    penalty: float
    contextual_score: float
    genre_overlap: float
    matching_genres: list[str]
    tag_overlap: float
    matching_tags: list[str]
    collaborated: bool
    label_overlap: float
    matching_labels: list[str]
    seed_artists: list[str]
    rescued: bool
    rescue_reason: str


class InputTrack(BaseModel):
    id: str | None = None  # Track ID for matching and deduplication
    artist: str
    track: str = ""
    album: str | None = None
    artists: list[str] = Field(default_factory=list)
    spotify_track_id: str | None = None
    spotify_artist_ids: list[str] = Field(default_factory=list)
    spotify_album_id: str | None = None
    tidal_track_id: str | None = None
    tidal_artist_ids: list[str] = Field(default_factory=list)
    tidal_album_id: str | None = None
    apple_music_track_id: str | None = None
    isrc: str | None = None
    # Extended fields per Human Logic Proposal §1
    source_platform: str = "unknown"   # spotify | tidal | csv | txt | unknown
    duration_ms: int | None = None
    upc: str | None = None             # UPC / barcode for release-level matching
    playlist_name: str | None = None
    playlist_position: int | None = None  # 0-based position in source playlist

    def all_artist_names(self) -> list[str]:
        return self.artists or [self.artist]


class CanonicalTrack(BaseModel):
    """A resolved canonical entity from MusicBrainz. §2 of the Human Logic Proposal."""
    recording_mbid: str | None = None
    release_mbid: str | None = None
    release_group_mbid: str | None = None
    artist_mbid: str | None = None
    artist_name_canonical: str = ""
    # Original input preserved for debugging/display
    input_artist: str = ""
    input_track: str = ""
    input_album: str | None = None
    # Platform IDs across providers
    platform_ids: dict[str, str] = Field(default_factory=dict)  # {"spotify": id, "tidal": id, ...}
    # Resolution outcome
    match_confidence: float = 0.0  # 1.00 / 0.90 / 0.50 / 0.30 per §2
    resolution_method: str = "unresolved"  # isrc | upc | title_duration | title_album | fuzzy | artist_only | unresolved
    source_platform: str = "unknown"
    duration_ms: int | None = None
    isrc: str | None = None
    upc: str | None = None
    playlist_position: int | None = None  # 0-based position in the source playlist


class ArtistSeed(BaseModel):
    """Per-artist aggregation from the taste profile. §3–4 of the Human Logic Proposal."""
    artist_mbid: str | None = None
    canonical_name: str
    source_frequency: int = 0          # total track count including duplicates
    unique_track_count: int = 0
    unique_release_count: int = 0
    match_confidence_avg: float = 1.0
    seed_weight: float = 0.0              # final normalized 0–1 weight


class GraphEdge(BaseModel):
    """A directional edge in the expanded artist graph. §6 of the Human Logic Proposal."""
    source_artist_mbid: str | None = None
    source_artist_name: str = ""
    target_artist_mbid: str | None = None
    target_artist_name: str = ""
    relation_type: str = ""            # collaborator | similar | tag_neighbor | member_of | alias | ...
    confidence: float = 1.0
    depth: int = 1
    connection_strength: float = 1.0  # see §6 suggested connection strengths
    tier: str = "Tier 1"              # Tier 1 | Tier 2A | Tier 2B | Tier 3 | Tier 4


class ArtistProfile(BaseModel):
    name: str
    playlist_count: int = 0
    cluster_score: float = 0.0
    affinity_score: float = 0.0
    listen_count: int | None = None
    spotify_id: str | None = None
    mbid: str | None = None
    genres: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    similar_artists: list[str] = Field(default_factory=list)
    community_artists: list[str] = Field(default_factory=list)
    related_acts: list[str] = Field(default_factory=list)
    collaborator_artists: list[str] = Field(default_factory=list)
    labels: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    community_artists_meta: dict[str, float] = Field(default_factory=dict)  # name → listener-share fraction
    genres_by_source: dict[str, list[str]] = Field(default_factory=dict)    # provider → genres
    tags_by_source: dict[str, list[str]] = Field(default_factory=dict)      # provider → tags


class WeightedTerm(BaseModel):
    name: str
    weight: float


class TasteProfile(BaseModel):
    generated_at: dt.datetime = Field(default_factory=dt.datetime.now)
    artists: list[ArtistProfile] = Field(default_factory=list)
    top_artists: list[ArtistProfile] = Field(default_factory=list)
    top_genres: list[WeightedTerm] = Field(default_factory=list)
    top_tags: list[WeightedTerm] = Field(default_factory=list)
    top_labels: list[WeightedTerm] = Field(default_factory=list)
    network_artists: list[WeightedTerm] = Field(default_factory=list)
    filtered_community_artists: dict[str, Union[FilteredCommunityArtist, float]] = Field(default_factory=dict)
    n_artists: int = 0

    @model_validator(mode="before")
    @classmethod
    def _normalize_filtered_community_artists(cls, data: Any) -> Any:
        """Backward compatibility: convert legacy float values to FilteredCommunityArtist."""
        if not isinstance(data, dict):
            return data
        fca = data.get("filtered_community_artists")
        if fca is None:
            return data
        if not isinstance(fca, dict):
            return data
        normalized = {}
        for key, value in fca.items():
            if isinstance(value, (int, float)):
                # Legacy format: just a float score
                normalized[key] = {
                    "relevance": float(value),
                    "ubiquity_score": 1.0,
                    "penalty": 0.0,
                    "contextual_score": 0.0,
                    "genre_overlap": 0.0,
                    "matching_genres": [],
                    "tag_overlap": 0.0,
                    "matching_tags": [],
                    "collaborated": False,
                    "label_overlap": 0.0,
                    "matching_labels": [],
                    "seed_artists": [],
                    "rescued": False,
                    "rescue_reason": "none",
                }
            else:
                normalized[key] = value
        data = data.copy()
        data["filtered_community_artists"] = normalized
        return data


class CandidateArtist(BaseModel):
    name: str
    source: str
    score: float
    mbid: str | None = None


class ReleaseTrack(BaseModel):
    title: str
    artists: str
    track_number: int | None = None
    release_date: str | None = None
    spotify_track_id: str | None = None
    spotify_uri: str | None = None
    tidal_track_id: str | None = None
    tidal_album_id: str | None = None
    apple_music_track_id: str | None = None
    apple_music_url: str | None = None
    isrc: str | None = None
    isrc_source: str | None = None
    popularity: int = 0
    popularity_value: int | None = None
    popularity_provider: str | None = None
    popularity_metric: str | None = None
    resolution_source: str | None = None
    resolution_note: str | None = None


class ReleaseRecommendation(BaseModel):
    artist: str
    artist_credits: list[str] = Field(default_factory=list)
    title: str
    release_date: str = ""
    release_type: str = "release"
    label: str | None = None
    score: float = 0.0
    rationale: list[str] = Field(default_factory=list)
    mb_release_group_id: str | None = None
    streaming_only_id: str | None = None
    spotify_album_id: str | None = None
    spotify_album_uri: str | None = None
    tidal_album_id: str | None = None
    tracks: list[ReleaseTrack] = Field(default_factory=list)
    # §10–11: structured tier + normalized score (0–100) + explanation
    tier: str = ""                # Tier 1 | Tier 2A | Tier 2B | Tier 3 | Tier 4
    score_normalized: float = 0.0  # 0–100 normalized final score
    confidence_label: str = ""    # High | Medium | Low
    explanation: dict[str, Any] = Field(default_factory=dict)
    artist_window_release_count: int = 1

    @property
    def fallback_key(self) -> str:
        return release_match_key(self.artist, self.title, self.release_date)

    def export_dict(self) -> dict[str, Any]:
        payload = self.model_dump(mode="json")
        payload["spotify_album_url"] = spotify_uri_to_url(self.spotify_album_uri, fallback_id=self.spotify_album_id, kind="album")
        payload["tracks"] = [
            {
                **track.model_dump(mode="json"),
                "spotify_url": spotify_uri_to_url(track.spotify_uri, fallback_id=track.spotify_track_id, kind="track"),
                "tidal_url": tidal_id_to_url(track.tidal_track_id, kind="track"),
            }
            for track in self.tracks
        ]
        payload["attribution"] = self._attribution_payload()
        payload["explain"] = {
            "candidate_sources": self._candidate_sources(),
            "provider_evidence": self._provider_evidence(),
            "filter_context": self._filter_context(),
            "tracklist_derivation": self._tracklist_derivation(),
            "track_resolution_sources": self._track_resolution_sources(),
            "track_resolution_notes": self._track_resolution_notes(),
            # §11: Human Logic Proposal structured explanation
            "tier": self.tier or None,
            "score_normalized": self.score_normalized or None,
            "confidence": self.confidence_label or None,
            "tier_explanation": self.explanation if self.explanation else None,
            "picked_tracks_reason": self.explanation.get("picked_tracks_reason") if self.explanation else None,
            "popularity_provider": self.explanation.get("popularity_provider") if self.explanation else None,
        }
        return payload

    def _candidate_sources(self) -> list[dict[str, str]]:
        sources: list[dict[str, str]] = []
        _DIAGNOSTIC_FLAGS = {
            "spotify-track-lookup-missed-or-seed-tracks-filtered",
            "musicbrainz-tracklist-fallback",
            "spotify-lookup-missed",
            "musicbrainz-no-tracks",
        }
        for reason in self.rationale:
            if reason in _DIAGNOSTIC_FLAGS:
                continue
            if ":" in reason:
                source, seed = reason.split(":", 1)
                item = {"source": source, "matched_seed": seed}
            else:
                item = {"source": reason}
                if reason == "seed-artist":
                    item["matched_seed"] = self.artist
            if item not in sources:
                sources.append(item)
        return sources

    def _provider_evidence(self) -> dict[str, Any]:
        return {
            "artist_credits": self.artist_credits,
            "label": self.label,
            "release_date": self.release_date,
            "release_type": self.release_type,
            "musicbrainz_release_group_id": self.mb_release_group_id,
            "spotify_album_id": self.spotify_album_id,
            "spotify_album_uri": self.spotify_album_uri,
            "tidal_album_id": self.tidal_album_id,
        }

    def _filter_context(self) -> list[str]:
        out: list[str] = []
        if "musicbrainz-tracklist-fallback" in self.rationale:
            out.append("musicbrainz_tracklist_fallback_used")
        if "spotify-track-lookup-missed-or-seed-tracks-filtered" in self.rationale:
            out.append("spotify_lookup_missed_or_seed_track_filtered")
        if "spotify-lookup-missed" in self.rationale:
            out.append("spotify_lookup_missed")
        if "musicbrainz-no-tracks" in self.rationale:
            out.append("musicbrainz_no_tracks")
        return out

    def _tracklist_derivation(self) -> str:
        sources = {track.resolution_source or "" for track in self.tracks if track.resolution_source}
        if not self.tracks:
            return "unresolved"
        if not sources:
            return "metadata-only"
        if all(source == "musicbrainz_tracklist" for source in sources):
            return "musicbrainz-derived"
        if all(source == "spotify_album_tracklist" or source.startswith("spotify_") for source in sources):
            return "spotify-derived"
        return "mixed"

    def _track_resolution_sources(self) -> list[str]:
        return list(dict.fromkeys(track.resolution_source for track in self.tracks if track.resolution_source))

    def _track_resolution_notes(self) -> list[str]:
        return list(dict.fromkeys(track.resolution_note for track in self.tracks if track.resolution_note))

    def _attribution_payload(self) -> dict[str, Any]:
        album_url = spotify_uri_to_url(self.spotify_album_uri, fallback_id=self.spotify_album_id, kind="album")
        track_urls = list(
            dict.fromkeys(
                spotify_uri_to_url(track.spotify_uri, fallback_id=track.spotify_track_id, kind="track")
                for track in self.tracks
                if spotify_uri_to_url(track.spotify_uri, fallback_id=track.spotify_track_id, kind="track")
            )
        )
        tidal_album_url = tidal_id_to_url(self.tidal_album_id, kind="album")
        tidal_track_urls = list(
            dict.fromkeys(
                tidal_id_to_url(track.tidal_track_id, kind="track")
                for track in self.tracks
                if tidal_id_to_url(track.tidal_track_id, kind="track")
            )
        )
        present = bool(album_url or track_urls)
        return {
            "spotify": {
                "present": present,
                "note": "Spotify metadata/URIs should link back to Spotify." if present else "",
                "album_url": album_url,
                "track_urls": track_urls,
            },
            "tidal": {
                "present": bool(tidal_album_url or tidal_track_urls),
                "note": "Tidal metadata/IDs should link back to Tidal." if tidal_album_url or tidal_track_urls else "",
                "album_url": tidal_album_url,
                "track_urls": tidal_track_urls,
            }
        }


def spotify_uri_to_url(uri: str | None, *, fallback_id: str | None = None, kind: str | None = None) -> str | None:
    if uri and uri.startswith("spotify:"):
        parts = uri.split(":")
        if len(parts) == 3 and parts[1] and parts[2]:
            return f"https://open.spotify.com/{parts[1]}/{parts[2]}"
    if fallback_id and kind:
        return f"https://open.spotify.com/{kind}/{fallback_id}"
    return None


def tidal_id_to_url(tidal_id: str | None, *, kind: str) -> str | None:
    if not tidal_id:
        return None
    return f"https://tidal.com/browse/{kind}/{tidal_id}"
