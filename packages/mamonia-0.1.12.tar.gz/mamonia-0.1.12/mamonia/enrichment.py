# enrichment.py
"""Track enrichment functions for ReleaseRecommendation objects.

This module provides functions to enrich release recommendations with:
- Spotify album tracklists
- MusicBrainz tracklists (fallback)
- Spotify backfill for MusicBrainz tracks
- ISRC resolution via Tidal/Deezer fallbacks

Resolution order (same as old discovery.py):
1. Spotify album tracklist (best — gives IDs, URIs, ISRCs, popularity)
2. MusicBrainz tracklist fallback (gives titles, track numbers, ISRCs)
3. Spotify backfill on MB tracks (adds IDs to MB-resolved tracks)
4. ISRC fallback via Tidal/Deezer (for tracks still missing ISRC)
"""

from __future__ import annotations

import datetime as dt
import os
import sys
from typing import Any

from .discovery_window import DiscoveryWindow
from .models import InputTrack, ReleaseRecommendation, ReleaseTrack
from .utils import normalize_key, normalize_variant_title, split_artist_names


def _cap_tracks(tracks: list[ReleaseTrack], max_tracks: int) -> list[ReleaseTrack]:
    """Apply max_tracks cap; non-positive means unlimited."""
    if max_tracks <= 0:
        return list(tracks)
    return tracks[:max_tracks]


def _enrich_debug_enabled() -> bool:
    value = os.getenv("MAMONIA_ENRICH_DEBUG", "")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _log_enrich_debug(message: str) -> None:
    if _enrich_debug_enabled():
        sys.stderr.write(f"{message}\n")


def _env_int(name: str, default: int = 0) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _spotify_enrichment_state(spotify: Any) -> dict[str, Any]:
    state = getattr(spotify, "__dict__", {}).get("_mamonia_enrichment_state")
    if state is None:
        budget = _env_int("MAMONIA_SPOTIFY_ENRICHMENT_BUDGET_PER_RUN", 0)
        state = {
            "budget": budget if budget > 0 else 0,
            "used": 0,
            "budget_exhausted": False,
            "rescue_disabled_due_to_429": False,
            "disabled_by_budget": False,
        }
        setattr(spotify, "_mamonia_enrichment_state", state)
    return state


def _spotify_budget_allows(spotify: Any, *, operation: str) -> bool:
    state = _spotify_enrichment_state(spotify)
    budget = state.get("budget", 0)
    if budget <= 0:
        return True
    if state["used"] >= budget:
        state["budget_exhausted"] = True
        state["disabled_by_budget"] = True
        _log_enrich_debug(f"[ENRICH DEBUG] spotify budget exhausted before {operation}")
        return False
    state["used"] += 1
    return True


def _spotify_trip_rescue_on_429(spotify: Any) -> None:
    if not _env_bool("MAMONIA_SPOTIFY_DISABLE_RESCUE_AFTER_429", False):
        return
    warnings = getattr(spotify, "rate_limit_warnings", None) or []
    for warning in reversed(warnings):
        if getattr(warning, "error_kind", "") == "rate_limited":
            state = _spotify_enrichment_state(spotify)
            state["rescue_disabled_due_to_429"] = True
            return


def _spotify_rescue_allowed(spotify: Any) -> bool:
    state = _spotify_enrichment_state(spotify)
    return not state.get("rescue_disabled_due_to_429", False)


def enrich_recommendation_tracks(
    rec: ReleaseRecommendation,
    *,
    spotify: Any | None = None,
    musicbrainz: Any | None = None,
    listenbrainz: Any | None = None,
    lastfm: Any | None = None,
    isrc_resolver: Any | None = None,
    max_tracks: int = 3,
    seed_track_keys: set[str] | None = None,
    discovery_months: int | None = None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> None:
    """Enrich a single ReleaseRecommendation with resolved tracks.

    Resolution order (same as old discovery.py):
    1. Spotify album tracklist (best — gives IDs, URIs, ISRCs, popularity)
    2. MusicBrainz tracklist fallback (gives titles, track numbers, ISRCs)
    3. Spotify backfill on MB tracks (adds IDs to MB-resolved tracks)
    4. ISRC fallback via Tidal/Deezer (for tracks still missing ISRC)
    5. Broad Spotify search (last resort when album lookup missed)
    """
    # Step 1: Try Spotify album tracklist
    _log_enrich_debug(f"[ENRICH DEBUG] {rec.artist} - {rec.title}: Starting enrichment")
    _attach_spotify_tracks(
        rec,
        spotify,
        max_tracks,
        seed_track_keys=seed_track_keys,
        allow_broad_search=False,
        release_date=rec.release_date,
        discovery_months=discovery_months,
        discovery_window=discovery_window,
        discovery_today=discovery_today,
    )

    # Step 2: Always call MusicBrainz for enrichment (mandatory)
    _attach_musicbrainz_tracks(rec, musicbrainz, max_tracks, seed_track_keys=seed_track_keys)

    # Step 3: Backfill MusicBrainz tracks with Spotify IDs if available
    _backfill_musicbrainz_tracks(
        rec,
        spotify,
        discovery_months=discovery_months,
        discovery_window=discovery_window,
        discovery_today=discovery_today,
    )

    # Step 3b: If we still have MB tracks but no Spotify IDs, retry with broader album-track search.
    _rescue_spotify_matches(
        rec,
        spotify,
        max_tracks=max_tracks,
        seed_track_keys=seed_track_keys,
        discovery_months=discovery_months,
        discovery_window=discovery_window,
        discovery_today=discovery_today,
    )

    # Step 4: Fallback ISRC lookup via Tidal/Deezer for tracks still missing an ISRC
    _backfill_isrc_from_fallbacks(rec, isrc_resolver)

    # Step 5: Broad Spotify search as last resort if no tracks yet
    if not rec.tracks:
        _attach_spotify_tracks(
            rec,
            spotify,
            max_tracks,
            seed_track_keys=seed_track_keys,
            allow_broad_search=True,
            release_date=rec.release_date,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )

    # Step 6: Final filter — remove any seed tracks that remain
    if seed_track_keys and rec.tracks:
        rec.tracks = _cap_tracks(filter_seed_tracks(rec.tracks, seed_track_keys), max_tracks)

    # Step 7: Post-selection track picking (title match first, then popularity)
    _select_tracks_post_enrichment(
        rec,
        musicbrainz=musicbrainz,
        listenbrainz=listenbrainz,
        lastfm=lastfm,
        max_tracks=max_tracks,
    )


def enrich_recommendation_tracks_lightweight(
    rec: ReleaseRecommendation,
    *,
    musicbrainz: Any | None = None,
    isrc_resolver: Any | None = None,
    max_tracks: int = 3,
    seed_track_keys: set[str] | None = None,
) -> None:
    """Lightweight enrichment for candidate filtering stage.
    
    Only uses MusicBrainz and ISRC resolver (Tidal/Deezer), no Spotify calls.
    Used during discovery phase to avoid expensive Spotify API calls for releases
    that will be filtered out later.
    """
    # Step 1: MusicBrainz tracklist (no Spotify)
    _attach_musicbrainz_tracks(rec, musicbrainz, max_tracks, seed_track_keys=seed_track_keys)
    
    # Step 2: ISRC fallback via Tidal/Deezer (no Spotify)
    _backfill_isrc_from_fallbacks(rec, isrc_resolver)
    
    # Step 3: Filter seed tracks
    if seed_track_keys and rec.tracks:
        rec.tracks = _cap_tracks(filter_seed_tracks(rec.tracks, seed_track_keys), max_tracks)


def _attach_spotify_tracks(
    rec: ReleaseRecommendation,
    spotify: Any | None,
    max_tracks: int,
    seed_track_keys: set[str] | None = None,
    allow_broad_search: bool = True,
    *,
    release_date: str | None = None,
    discovery_months: int | None = None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> None:
    """Resolve tracks via Spotify album tracklist lookup.

    Attempts to find the album and extract its tracklist. If broad_search
    is enabled and initial lookup fails, falls back to broad search.
    """
    if spotify is None:
        return
    if not _spotify_budget_allows(spotify, operation="representative_tracks"):
        return
    try:
        request_cap = max(max_tracks, 10) if seed_track_keys else max_tracks
        try:
            album_id, album_uri, tracks = spotify.representative_tracks(
                rec.artist,
                rec.title,
                request_cap,
                allow_broad_search=allow_broad_search,
                release_date=release_date,
                discovery_months=discovery_months,
                discovery_window=discovery_window,
                discovery_today=discovery_today,
            )
        except TypeError:
            album_id, album_uri, tracks = spotify.representative_tracks(rec.artist, rec.title, request_cap)
    except Exception as e:
        _spotify_trip_rescue_on_429(spotify)
        _log_enrich_debug(f"[ENRICH DEBUG] {rec.artist} - {rec.title}: Spotify lookup failed: {e}")
        return
    _log_enrich_debug(f"[ENRICH DEBUG] {rec.artist} - {rec.title}: Spotify album found: {album_id}, tracks={len(tracks)}")
    rec.spotify_album_id = album_id
    rec.spotify_album_uri = album_uri
    rec.tracks = _cap_tracks(filter_seed_tracks(tracks, seed_track_keys or set()), max_tracks)


def _enrich_tracks_with_musicbrainz(
    spotify_tracks: list[ReleaseTrack],
    mb_tracks: list[ReleaseTrack],
) -> list[ReleaseTrack]:
    """Merge MusicBrainz tracks with Spotify tracks, preferring Spotify data.

    Matches tracks by track number first, then by title. When a match is found,
    copies ISRC from MusicBrainz if Spotify track lacks one. Tracks without
    matches are appended from MusicBrainz.
    """
    by_number: dict[int, ReleaseTrack] = {
        t.track_number: t for t in spotify_tracks if t.track_number is not None
    }
    by_title: dict[str, ReleaseTrack] = {normalize_key(t.title): t for t in spotify_tracks}
    appended: list[ReleaseTrack] = []
    for mb in mb_tracks:
        match: ReleaseTrack | None = None
        if mb.track_number is not None:
            match = by_number.get(mb.track_number)
        if match is None:
            match = by_title.get(normalize_key(mb.title))
        if match is not None:
            if not match.isrc and mb.isrc:
                match.isrc = mb.isrc
                match.isrc_source = "musicbrainz"
            elif not match.isrc and not match.isrc_source:
                match.isrc_source = "m_nF"
            elif match.isrc and not match.isrc_source:
                match.isrc_source = "input"
        else:
            appended.append(mb)
    result = list(spotify_tracks) + appended
    result.sort(key=lambda t: t.track_number or 0)
    return result


def _attach_musicbrainz_tracks(
    rec: ReleaseRecommendation,
    musicbrainz: Any,
    max_tracks: int,
    seed_track_keys: set[str] | None = None,
) -> None:
    """Get MusicBrainz tracklist as fallback when Spotify lookup fails.

    If the release has a MusicBrainz release-group ID, fetches its tracklist.
    Merges with existing Spotify tracks if available, otherwise sets as main
    tracklist with resolution source tracking.
    """
    if not rec.mb_release_group_id:
        return
    try:
        request_cap = max(max_tracks, 10) if seed_track_keys else max_tracks
        mb_tracks = musicbrainz.release_tracks_for_group(rec.mb_release_group_id, cap=request_cap)
    except Exception:
        return
    if not mb_tracks:
        return
    if rec.tracks:
        merged = _enrich_tracks_with_musicbrainz(rec.tracks, mb_tracks)
        rec.tracks = _cap_tracks(filter_seed_tracks(merged, seed_track_keys or set()), max_tracks)
    else:
        rec.tracks = _cap_tracks(filter_seed_tracks(mb_tracks, seed_track_keys or set()), max_tracks)
        for track in rec.tracks:
            if not track.resolution_source:
                track.resolution_source = "musicbrainz_tracklist"
            if not track.resolution_note:
                track.resolution_note = "Spotify unresolved; using MusicBrainz tracklist."


def _backfill_musicbrainz_tracks(
    rec: ReleaseRecommendation,
    spotify: Any | None,
    *,
    discovery_months: int | None = None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> None:
    """Enrich MusicBrainz-resolved tracks with Spotify IDs.

    Calls Spotify's backfill_release_tracks to add Spotify track IDs to
    tracks that were resolved via MusicBrainz tracklist lookup.
    """
    if spotify is None or not rec.tracks:
        return
    if not _spotify_budget_allows(spotify, operation="backfill_release_tracks"):
        return
    backfill = getattr(spotify, "backfill_release_tracks", None)
    if not callable(backfill):
        return
    preferred_release_date = next((track.release_date for track in rec.tracks if getattr(track, "release_date", None)), None)
    try:
        try:
            rec.tracks = backfill(
                rec.title,
                rec.tracks,
                artist_name=rec.artist,
                release_date=preferred_release_date or rec.release_date,
                discovery_months=discovery_months,
                discovery_window=discovery_window,
                discovery_today=discovery_today,
            )
        except TypeError:
            rec.tracks = backfill(rec.title, rec.tracks, artist_name=rec.artist)
    except Exception:
        _spotify_trip_rescue_on_429(spotify)
        return


def _backfill_isrc_from_fallbacks(rec: ReleaseRecommendation, isrc_resolver: Any | None) -> None:
    """Resolve ISRCs via Tidal/Deezer for tracks still missing an ISRC.

    Iterates through tracks without an ISRC and attempts resolution via
    the ISRCResolver, which tries Tidal first, then Deezer.
    """
    if isrc_resolver is None or not rec.tracks:
        return
    for track in rec.tracks:
        if track.isrc:
            continue
        stub = InputTrack(artist=track.artists, track=track.title)
        resolution = isrc_resolver.resolve_track(stub)
        if resolution.resolved and resolution.isrc:
            track.isrc = resolution.isrc
            track.isrc_source = resolution.provider
        # When resolution fails, those failure codes provide valuable info
        # into isrc_source — even though it looks ugly; don't remove it
        elif resolution.attempts:
            if track.isrc_source:
                track.isrc_source = ";".join([track.isrc_source] + resolution.attempts)
            else:
                track.isrc_source = ";".join(resolution.attempts)
        # DEBUG: log ISRC resolution outcome
        # print(f"[ISRC DEBUG] {track.artists} - {track.title}: isrc={track.isrc}, source={track.isrc_source}, attempts={resolution.attempts}")


def _rescue_spotify_matches(
    rec: ReleaseRecommendation,
    spotify: Any | None,
    *,
    max_tracks: int,
    seed_track_keys: set[str] | None,
    discovery_months: int | None = None,
    discovery_window: DiscoveryWindow | None = None,
    discovery_today: dt.date | None = None,
) -> None:
    if spotify is None or not rec.tracks:
        return
    if not _spotify_rescue_allowed(spotify):
        return
    if not _spotify_budget_allows(spotify, operation="rescue_representative_tracks"):
        return
    if any(track.spotify_track_id for track in rec.tracks):
        return
    preferred_release_date = next((track.release_date for track in rec.tracks if getattr(track, "release_date", None)), None)
    try:
        request_cap = max(max_tracks, len(rec.tracks), 10)
        _, _, broad_tracks = spotify.representative_tracks(
            rec.artist,
            rec.title,
            request_cap,
            allow_broad_search=True,
            release_date=preferred_release_date or rec.release_date,
            discovery_months=discovery_months,
            discovery_window=discovery_window,
            discovery_today=discovery_today,
        )
    except TypeError:
        try:
            _, _, broad_tracks = spotify.representative_tracks(rec.artist, rec.title, max(max_tracks, len(rec.tracks), 10))
        except Exception:
            return
    except Exception:
        _spotify_trip_rescue_on_429(spotify)
        return
    if not broad_tracks:
        return

    by_title: dict[str, list[ReleaseTrack]] = {}
    for candidate in broad_tracks:
        key = normalize_variant_title(candidate.title)
        if not key:
            continue
        by_title.setdefault(key, []).append(candidate)

    for track in rec.tracks:
        if track.spotify_track_id:
            continue
        title_key = normalize_variant_title(track.title)
        matches = by_title.get(title_key, [])
        if not matches:
            continue
        target_artists = {normalize_key(name) for name in split_artist_names(track.artists) if normalize_key(name)}
        for match in matches:
            candidate_artists = {normalize_key(name) for name in split_artist_names(match.artists) if normalize_key(name)}
            if target_artists and candidate_artists and not (target_artists & candidate_artists):
                continue
            # Check discovery window for non-ISRC matches
            match_release_date = getattr(match, "release_date", None) or getattr(track, "release_date", None)
            if not track.isrc and match_release_date:
                from mamonia.providers.spotify import _candidate_release_within_discovery_window
                if not _candidate_release_within_discovery_window(
                    {"album": {"release_date": match_release_date}},
                    release_date=getattr(track, "release_date", None) or getattr(rec, "release_date", None),
                    discovery_months=discovery_months,
                    discovery_window=discovery_window,
                    discovery_today=discovery_today,
                ):
                    continue
            track.spotify_track_id = match.spotify_track_id or track.spotify_track_id
            track.spotify_uri = match.spotify_uri or track.spotify_uri
            if match.isrc and not track.isrc:
                track.isrc = match.isrc
                track.isrc_source = match.isrc_source or "spotify"
            track.popularity = match.popularity or track.popularity
            track.resolution_source = "spotify_track_search_album_context"
            track.resolution_note = "Recovered via broad Spotify album-track search."
            break

    if seed_track_keys and rec.tracks:
        rec.tracks = _cap_tracks(filter_seed_tracks(rec.tracks, seed_track_keys), max_tracks)


def _select_tracks_post_enrichment(
    rec: ReleaseRecommendation,
    *,
    musicbrainz: Any | None,
    listenbrainz: Any | None,
    lastfm: Any | None,
    max_tracks: int,
) -> None:
    if not rec.tracks:
        return

    _annotate_track_popularity(rec.tracks, musicbrainz=musicbrainz, listenbrainz=listenbrainz, lastfm=lastfm)

    # When max_tracks >= total tracks, preserve original order exactly
    if max_tracks <= 0 or max_tracks >= len(rec.tracks):
        _set_track_pick_summary(rec, release_key=normalize_variant_title(rec.title))
        return

    release_key = normalize_variant_title(rec.title)
    title_matches = [track for track in rec.tracks if normalize_variant_title(track.title) == release_key]
    title_matches = sorted(title_matches, key=lambda t: ((t.track_number or 9999), normalize_key(t.title)))
    selected: list[ReleaseTrack] = []
    for track in title_matches:
        if len(selected) >= max_tracks:
            break
        selected.append(track)
    remaining = [track for track in rec.tracks if track not in selected]
    remaining.sort(
        key=lambda t: (
            -int(t.popularity_value or 0),
            (t.track_number or 9999),
            normalize_key(t.title),
        ),
    )
    for track in remaining:
        if len(selected) >= max_tracks:
            break
        selected.append(track)
    selected.sort(key=lambda t: (t.track_number or 9999, normalize_key(t.title)))
    rec.tracks = _cap_tracks(selected, max_tracks)
    _set_track_pick_summary(rec, release_key=release_key)


def _annotate_track_popularity(
    tracks: list[ReleaseTrack],
    *,
    musicbrainz: Any | None,
    listenbrainz: Any | None,
    lastfm: Any | None,
) -> None:
    for track in tracks:
        track.popularity_value = None
        track.popularity_provider = "none"
        track.popularity_metric = "none"

    lb_map: dict[int, int] = {}
    if listenbrainz is not None and getattr(listenbrainz, "available", False):
        mbids_by_idx: dict[int, str] = {}
        for idx, track in enumerate(tracks):
            recording_mbid = _resolve_recording_mbid(track, musicbrainz)
            if recording_mbid:
                mbids_by_idx[idx] = recording_mbid
        if mbids_by_idx:
            try:
                popularity_rows = listenbrainz.recording_popularity(list(mbids_by_idx.values()))
            except Exception:
                popularity_rows = {}
            reverse_idx = {mbid: idx for idx, mbid in mbids_by_idx.items()}
            for mbid, row in popularity_rows.items():
                idx = reverse_idx.get(mbid)
                if idx is None:
                    continue
                try:
                    listen_count = int((row or {}).get("total_listen_count") or 0)
                except (TypeError, ValueError):
                    listen_count = 0
                if listen_count > 0:
                    lb_map[idx] = listen_count

    for idx, track in enumerate(tracks):
        if idx in lb_map:
            track.popularity_value = lb_map[idx]
            track.popularity = lb_map[idx]
            track.popularity_provider = "listenbrainz"
            track.popularity_metric = "total_listen_count"
            continue
        if lastfm is not None and getattr(lastfm, "available", False):
            try:
                stats = lastfm.track_popularity(track.artists or "", track.title or "")
            except Exception:
                stats = None
            if stats:
                listeners = int(stats.get("listeners") or 0)
                playcount = int(stats.get("playcount") or 0)
                value = max(listeners, playcount)
                if value > 0:
                    track.popularity_value = value
                    track.popularity = value
                    track.popularity_provider = "lastfm"
                    track.popularity_metric = "listeners_playcount"


def _resolve_recording_mbid(track: ReleaseTrack, musicbrainz: Any | None) -> str | None:
    if musicbrainz is None:
        return None
    if track.isrc and hasattr(musicbrainz, "lookup_recording_by_isrc"):
        try:
            payload = musicbrainz.lookup_recording_by_isrc(track.isrc)
        except Exception:
            payload = None
        recording_mbid = (payload or {}).get("recording_mbid")
        if recording_mbid:
            return str(recording_mbid)
    if hasattr(musicbrainz, "search_recording"):
        primary_artist = split_artist_names(track.artists)[0] if track.artists else ""
        if primary_artist and track.title:
            try:
                payload = musicbrainz.search_recording(primary_artist, track.title, duration_ms=None)
            except Exception:
                payload = None
            recording_mbid = (payload or {}).get("recording_mbid")
            if recording_mbid:
                return str(recording_mbid)
    return None


def _set_track_pick_summary(rec: ReleaseRecommendation, *, release_key: str) -> None:
    if not rec.explanation:
        rec.explanation = {}
    has_title = any(normalize_variant_title(track.title) == release_key for track in rec.tracks)
    has_pop = any((track.popularity_value or 0) > 0 for track in rec.tracks)
    if has_title and has_pop:
        reason = "title-match+popularity"
    elif has_title:
        reason = "title-match"
    elif has_pop:
        reason = "popularity"
    else:
        reason = "deterministic-order"
    providers = [track.popularity_provider for track in rec.tracks if track.popularity_provider and track.popularity_provider != "none"]
    provider = providers[0] if providers else "none"
    rec.explanation["picked_tracks_reason"] = reason
    rec.explanation["popularity_provider"] = provider


def filter_seed_tracks(
    tracks: list[ReleaseTrack],
    seed_track_keys: set[str],
) -> list[ReleaseTrack]:
    """Filter out tracks that match seed/input tracks.

    Excludes tracks from recommendations if they match the user's input tracks
    (to avoid recommending tracks the user already knows).
    """
    if not seed_track_keys:
        return tracks
    out: list[ReleaseTrack] = []
    for track in tracks:
        artists = [artist.strip() for artist in track.artists.split(",") if artist.strip()]
        if not artists:
            artists = [track.artists]
        keys = {track_key(artist, track.title) for artist in artists}
        keys.update({f"metadata:{key}" for key in list(keys) if key})
        if track.spotify_track_id:
            keys.add(f"spotify:track:{track.spotify_track_id}")
        if track.isrc:
            keys.add(f"isrc:{normalize_key(track.isrc)}")
        if keys.isdisjoint(seed_track_keys):
            out.append(track)
    return out


def track_key(artist: str | None, title: str | None) -> str:
    """Create a normalized key for a track for comparison."""
    artist_key = normalize_key(artist) if artist else ""
    title_key = normalize_key(title) if title else ""
    if artist_key and title_key:
        return f"{artist_key}|{title_key}"
    if title_key:
        return title_key
    return artist_key or ""


def _track_key(artist: str | None, title: str | None) -> str:
    """Deprecated: Use track_key instead."""
    return track_key(artist, title)


def _track_resolution_score(tracks: list[ReleaseTrack]) -> tuple[int, int]:
    """Score tracks by Spotify resolution and source priority.

    Returns (spotify_resolved_count, max_source_priority).
    Higher scores indicate better-resolved tracklists.
    """
    spotify_resolved = sum(1 for track in tracks if track.spotify_track_id)
    priority = max((_track_source_priority(track) for track in tracks), default=0)
    return spotify_resolved, priority


def _track_source_priority(track: ReleaseTrack) -> int:
    """Return priority score for a track's resolution source.

    Higher numbers indicate better resolution sources:
    - 3: Spotify album tracklist (best)
    - 2: Spotify track search / cached track
    - 1: MusicBrainz tracklist
    - 0: Unknown / fallback
    """
    source = track.resolution_source or ""
    if source == "spotify_album_tracklist":
        return 3
    if source.startswith("spotify_track_search_") or source == "spotify_cached_track":
        return 2
    if source == "musicbrainz_tracklist":
        return 1
    return 0
