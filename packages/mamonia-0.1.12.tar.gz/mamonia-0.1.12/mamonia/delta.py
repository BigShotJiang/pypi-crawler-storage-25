from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from .discovery import track_key_for_diff
from .models import InputTrack


@dataclass(frozen=True)
class PlaylistDiff:
    added: list[InputTrack]
    removed: list[InputTrack]
    unchanged_count: int = 0

    @property
    def changed(self) -> bool:
        return bool(self.added or self.removed)

    @property
    def added_count(self) -> int:
        return len(self.added)

    @property
    def removed_count(self) -> int:
        return len(self.removed)


def diff_playlist_tracks(previous: list[InputTrack], current: list[InputTrack]) -> PlaylistDiff:
    """Compare playlist membership as a multiset, ignoring track order."""
    previous_keys = Counter(track_key_for_diff(track) for track in previous)
    current_keys = Counter(track_key_for_diff(track) for track in current)

    added_counts = current_keys - previous_keys
    removed_counts = previous_keys - current_keys
    unchanged_count = sum((previous_keys & current_keys).values())

    return PlaylistDiff(
        added=_tracks_for_counts(current, added_counts),
        removed=_tracks_for_counts(previous, removed_counts),
        unchanged_count=unchanged_count,
    )


def _tracks_for_counts(tracks: list[InputTrack], counts: Counter[str]) -> list[InputTrack]:
    out: list[InputTrack] = []
    remaining = counts.copy()
    for track in tracks:
        key = track_key_for_diff(track)
        if remaining[key] <= 0:
            continue
        out.append(track)
        remaining[key] -= 1
    return out
