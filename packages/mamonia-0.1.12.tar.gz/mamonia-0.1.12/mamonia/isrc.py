from __future__ import annotations

from typing import Any
from dataclasses import dataclass
from functools import lru_cache

from .models import InputTrack, ReleaseTrack
from .config import Settings
from .storage import Storage
from .utils import normalized_cache_key


@dataclass
class ISRCResolution:
    """Result of ISRC resolution for a track."""
    track_id: str
    isrc: str | None
    provider: str | None
    confidence: float
    resolved: bool
    metadata: dict[str, Any] | None = None
    attempts: list[str] = None

    def __post_init__(self):
        if self.attempts is None:
            self.attempts = []


@dataclass
class ISRCBatchResult:
    """Result of batch ISRC resolution."""
    total: int
    resolved: int
    failed: int
    skipped: int
    resolutions: list[ISRCResolution]


class ISRCResolver:
    """
    Centralized ISRC resolution service for Mamonia.
    
    Resolves ISRC codes for tracks by querying multiple providers in order
    of reliability and coverage. Uses caching and batch operations to handle
    rate limits efficiently.
    """
    
    def __init__(self, settings: Settings, storage: Storage | None = None, progress=None, tidal: Any | None = None):
        self.settings = settings
        self.storage = storage
        self.progress = progress
        self.tidal = tidal
        self._cache_ttl_seconds = 30 * 24 * 60 * 60  # 30 days for ISRCs
        self._cache_miss_ttl_seconds = 7 * 24 * 60 * 60  # 7 days for failures
        
    def _cache_lookup(self, cache_key: str) -> tuple[bool, Any]:
        """Check if result is cached."""
        if not self.storage:
            return False, None
        if getattr(self.settings, "force_refresh", False):
            return False, None
        value = self.storage.get_cache("isrc_resolver", cache_key)
        return value is not None, value
    
    def _cache_set(self, cache_key: str, value: Any, ttl: int) -> None:
        """Cache a result."""
        if self.storage:
            self.storage.set_cache("isrc_resolver", cache_key, value, ttl)
    
    def _cache_miss(self, cache_key: str) -> None:
        """Cache a negative result (no match found)."""
        if self.storage:
            self.storage.set_cache(
                "isrc_resolver", 
                cache_key, 
                None, 
                self._cache_miss_ttl_seconds
            )
    
    def resolve_track(self, track: InputTrack) -> ISRCResolution:
        """
        Resolve ISRC for a single input track via Tidal then Deezer.

        Called only when Spotify and MusicBrainz have already been tried upstream
        and returned no ISRC. Per-provider caches (30-day hits, 7-day misses) avoid
        redundant API calls across runs.
        """
        if track.isrc:
            return ISRCResolution(
                track_id=track.id or "",
                isrc=track.isrc,
                provider="input",
                confidence=1.0,
                resolved=True,
            )

        # Track which providers were attempted
        attempts = []

        # Try Tidal
        tidal_result = self._try_tidal_isrc(track)
        if tidal_result:
            if tidal_result.resolved:
                return tidal_result
            # Tidal tried but failed - continue to Deezer
            attempts.extend(tidal_result.attempts)
        else:
            # Tidal unavailable or returned None
            attempts.append("t_nF")

        # Try Deezer
        deezer_result = self._try_deezer_isrc(track)
        if deezer_result:
            if deezer_result.resolved:
                return deezer_result
            # Deezer tried but failed
            attempts.extend(deezer_result.attempts)
        else:
            # Deezer unavailable or returned None
            attempts.append("d_nF")

        # Return resolution with attempts tracked even when no ISRC found
        return ISRCResolution(
            track_id=track.id or "",
            isrc=None,
            provider=None,
            confidence=0.0,
            resolved=False,
            attempts=attempts,
        )

    def _try_tidal_isrc(self, track: InputTrack) -> ISRCResolution | None:
        """Try to resolve ISRC using Tidal search."""
        if self.tidal is None:
            return None

        cache_key = normalized_cache_key("tidal-isrc-v1", artist=track.artist, title=track.track)
        cached, value = self._cache_lookup(cache_key)
        if cached:
            if not value:
                return ISRCResolution(
                    track_id=track.id or "",
                    isrc=None,
                    provider=None,
                    confidence=0.0,
                    resolved=False,
                    attempts=["t_nF"],
                )
            return ISRCResolution(
                track_id=track.id or "",
                isrc=value,
                provider="tidal",
                confidence=0.85,
                resolved=True,
            )

        try:
            isrc = self.tidal.lookup_isrc(track.artist, track.track)
            if isrc:
                self._cache_set(cache_key, isrc, self._cache_ttl_seconds)
                if self.progress:
                    self.progress.isrc_lookup("tidal", True)
                return ISRCResolution(
                    track_id=track.id or "",
                    isrc=isrc,
                    provider="tidal",
                    confidence=0.85,
                    resolved=True,
                )
            self._cache_set(cache_key, None, self._cache_miss_ttl_seconds)
            if self.progress:
                self.progress.isrc_lookup("tidal", False)
            return ISRCResolution(
                track_id=track.id or "",
                isrc=None,
                provider=None,
                confidence=0.0,
                resolved=False,
                attempts=["t_nF"],
            )
        except Exception:
            self._cache_set(cache_key, None, self._cache_miss_ttl_seconds)
            return ISRCResolution(
                track_id=track.id or "",
                isrc=None,
                provider=None,
                confidence=0.0,
                resolved=False,
                attempts=["t_nF"],
            )
    
    def _try_deezer_isrc(self, track: InputTrack) -> ISRCResolution | None:
        """Try to resolve ISRC using Deezer API."""
        cache_key = normalized_cache_key("deezer-isrc-v1", artist=track.artist, title=track.track)
        cached, value = self._cache_lookup(cache_key)
        if cached:
            if not value:
                return ISRCResolution(
                    track_id=track.id or "",
                    isrc=None,
                    provider=None,
                    confidence=0.0,
                    resolved=False,
                    attempts=["d_nF"],
                )
            return ISRCResolution(
                track_id=track.id or "",
                isrc=value,
                provider="deezer",
                confidence=0.8,
                resolved=True,
            )

        try:
            from .providers.deezer import DeezerProvider
            provider = DeezerProvider(self.settings, self.storage, progress=self.progress)
            result = provider.search_track(f"{track.artist} {track.track}")

            if result and "data" in result:
                for item in result["data"]:
                    item_title = item.get("title", "").lower()
                    item_artist = item.get("artist", {}).get("name", "").lower()
                    title_l = track.track.lower()
                    artist_l = track.artist.lower()
                    if (title_l in item_title or item_title in title_l) and \
                       (artist_l in item_artist or item_artist in artist_l):
                        isrc = item.get("isrc")
                        if isrc:
                            self._cache_set(cache_key, isrc, self._cache_ttl_seconds)
                            if self.progress:
                                self.progress.isrc_lookup("deezer", True)
                            return ISRCResolution(
                                track_id=track.id or "",
                                isrc=isrc,
                                provider="deezer",
                                confidence=0.8,
                                resolved=True,
                            )

            self._cache_set(cache_key, None, self._cache_miss_ttl_seconds)
            if self.progress:
                self.progress.isrc_lookup("deezer", False)
            return ISRCResolution(
                track_id=track.id or "",
                isrc=None,
                provider=None,
                confidence=0.0,
                resolved=False,
                attempts=["d_nF"],
            )

        except Exception:
            self._cache_set(cache_key, None, self._cache_miss_ttl_seconds)
            return ISRCResolution(
                track_id=track.id or "",
                isrc=None,
                provider=None,
                confidence=0.0,
                resolved=False,
                attempts=["d_nF"],
            )
    
    def enrich_track_with_isrc(self, track: ReleaseTrack, providers: dict[str, Any]) -> ReleaseTrack:
        """
        Enrich a ReleaseTrack with ISRC from provider data.
        
        Providers is a dict of {provider_name: provider_data} where provider_data
        contains track information that may include ISRC.
        """
        # Check if track already has ISRC - set source if not already set
        if track.isrc:
            if not track.isrc_source:
                track.isrc_source = "input"
            return track
        
        # Try each provider for ISRC
        for provider_name, provider_data in providers.items():
            isrc = self._extract_isrc_from_provider_data(provider_name, provider_data)
            if isrc:
                track.isrc = isrc
                track.isrc_source = provider_name
                return track
        
        return track
    
    def _extract_isrc_from_provider_data(self, provider: str, data: dict[str, Any]) -> str | None:
        """Extract ISRC from provider response data."""
        if not data or not isinstance(data, dict):
            return None
        
        # Spotify: external_ids.isrc
        if provider == "spotify":
            return data.get("external_ids", {}).get("isrc")
        
        # MusicBrainz: recording.isrcs array
        if provider == "musicbrainz":
            recording = data.get("recording", {})
            if isinstance(recording, dict):
                isrcs = recording.get("isrcs", [])
                if isinstance(isrcs, list) and isrcs:
                    return isrcs[0]
            return None
        
        # Deezer: isrc field directly on track objects
        if provider == "deezer":
            return data.get("isrc")
        
        # Tidal: isrc field directly on track objects, or nested under external_ids
        if provider == "tidal":
            return data.get("isrc") or data.get("external_ids", {}).get("isrc")
        
        return None
    
    def batch_resolve(self, tracks: list[InputTrack]) -> ISRCBatchResult:
        """
        Resolve ISRCs for multiple tracks efficiently.
        
        Implements rate limit management and bulk operations where possible.
        """
        resolutions: list[ISRCResolution] = []
        resolved_count = 0
        failed_count = 0
        skipped_count = 0
        
        for track in tracks:
            result = self.resolve_track(track)
            resolutions.append(result)
            
            if result.resolved:
                resolved_count += 1
            elif result.isrc is None and result.provider == "cached_miss":
                skipped_count += 1
            else:
                failed_count += 1
        
        return ISRCBatchResult(
            total=len(tracks),
            resolved=resolved_count,
            failed=failed_count,
            skipped=skipped_count,
            resolutions=resolutions
        )
    
    def bulk_update_track_enrichment(
        self, 
        track: ReleaseTrack, 
        provider: str, 
        payload: dict[str, Any]
    ) -> None:
        """
        Update track enrichment with ISRC in storage.
        
        This is called by providers to store enriched track data.
        """
        if not self.storage:
            return
        
        # Ensure ISRC is extracted and stored
        isrc = self._extract_isrc_from_provider_data(provider, payload)
        if isrc:
            track.isrc = isrc
        
        self.storage.upsert_track_enrichment(
            provider=provider,
            artist=track.artists or "",
            title=track.title or "",
            album=track.album or "",
            isrc=track.isrc,
            spotify_track_id=track.spotify_track_id,
            tidal_track_id=track.tidal_track_id,
            payload=payload
        )
    
    def get_track_by_isrc(self, isrc: str) -> dict[str, Any] | None:
        """
        Lookup a track by its ISRC across all providers.
        
        This enables reverse lookup of tracks by their ISRC for matching
        and deduplication purposes.
        """
        if not isrc or not self.storage:
            return None
        
        cache_key = normalized_cache_key("isrc-lookup-v1", isrc=isrc)
        cached, value = self._cache_lookup(cache_key)
        if cached:
            return value
        
        # Query providers for ISRC (implementation deferred to Phase 2)
        # For now, cache miss as no match
        self._cache_miss(cache_key)
        return None


class ISRCEnrichmentPipeline:
    """
    Pipeline for enriching tracks with ISRC during workflow execution.
    
    Integrates with the existing discovery workflow to ensure all tracks
    have ISRC codes before matching and recommendation generation.
    """
    
    def __init__(self, resolver: ISRCResolver):
        self.resolver = resolver
    
    def enrich_input_tracks(self, tracks: list[InputTrack]) -> list[InputTrack]:
        """
        Enrich input tracks with ISRC codes.
        
        Called during profile building to ensure tracks have ISRCs
        for better matching.
        """
        batch_result = self.resolver.batch_resolve(tracks)
        return tracks  # ISRCs may be populated in place for some tracks
    
    def enrich_release_tracks(
        self, 
        tracks: list[ReleaseTrack], 
        providers_data: dict[str, Any]
    ) -> list[ReleaseTrack]:
        """
        Enrich release tracks with ISRC codes from provider data.
        
        Called after track resolution from providers.
        """
        for track in tracks:
            self.resolver.enrich_track_with_isrc(track, providers_data)
        return tracks
    
    def get_matching_priority(self) -> list[str]:
        """
        Return canonical track key matching priority.
        
        ISRC > Spotify ID > Tidal ID > artist+title
        """
        return ["isrc", "spotify_track_id", "tidal_track_id", "normalized_artist_title"]


def create_isrc_resolver(settings: Settings, storage: Storage | None = None, progress=None) -> ISRCResolver:
    """Factory function to create an ISRC resolver."""
    return ISRCResolver(settings, storage, progress)


def create_isrc_enrichment_pipeline(settings: Settings, storage: Storage | None = None, progress=None) -> ISRCEnrichmentPipeline:
    """Factory function to create an ISRC enrichment pipeline."""
    resolver = create_isrc_resolver(settings, storage, progress)
    return ISRCEnrichmentPipeline(resolver)