from __future__ import annotations

import collections
import concurrent.futures
import math
import sqlite3
import threading
import warnings
from typing import Any

from .filtering.community_artists import CommunityArtistsFilter
from .models import ArtistProfile, InputTrack, TasteProfile, WeightedTerm
from .utils import dedupe, normalize_key, safe_get


MAX_ENRICHED_ARTISTS = 30
MAX_SEED_ARTISTS = 20

# MusicBrainz rate limit: ~1 req/sec per IP. Serialize all MB calls.
_MB_RATE_LIMIT_LOCK = threading.Lock()


class _LockedProvider:
    """Wraps a provider so that every method call is protected by a lock."""

    def __init__(self, provider: Any) -> None:
        self._provider = provider

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._provider, name)
        if not callable(attr):
            return attr

        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with _MB_RATE_LIMIT_LOCK:
                return attr(*args, **kwargs)

        return wrapper


def infer_artist_counts_and_clusters(tracks: list[InputTrack], window: int = 3) -> dict[str, tuple[str, int, float]]:
    canonical: dict[str, str] = {}
    counts: collections.Counter[str] = collections.Counter()
    for track in tracks:
        for artist in track.all_artist_names():
            key = normalize_key(artist)
            if not key:
                continue
            canonical.setdefault(key, artist)
            counts[key] += 1

    cluster_scores: collections.defaultdict[str, float] = collections.defaultdict(float)
    primary_keys = [normalize_key(track.artist) for track in tracks]
    for idx, key in enumerate(primary_keys):
        if not key:
            continue
        for near_idx in range(max(0, idx - window), min(len(primary_keys), idx + window + 1)):
            if near_idx == idx:
                continue
            if primary_keys[near_idx] == key:
                cluster_scores[key] += 1.0 / (abs(near_idx - idx) + 0.5)

    return {
        key: (canonical[key], count, cluster_scores.get(key, 0.0))
        for key, count in counts.items()
    }


def _enrich_single_artist(
    idx: int,
    name: str,
    count: int,
    cluster_score: float,
    *,
    max_artists: int,
    spotify: Any | None,
    musicbrainz: Any | None,
    lastfm: Any | None,
    listenbrainz: Any | None,
    deezer: Any | None,
    spotify_artist_metadata: dict[str, dict[str, Any]],
) -> ArtistProfile:
    """Build and enrich a single ArtistProfile from provider data."""
    profile = ArtistProfile(
        name=name,
        playlist_count=count,
        cluster_score=cluster_score,
        affinity_score=round(count * 2.0 + math.log2(cluster_score + 1.0), 4),
    )

    if idx >= max_artists:
        return profile

    spotify_artist = _spotify_artist_for_profile(name, spotify, spotify_artist_metadata)
    if spotify_artist:
        profile.spotify_id = spotify_artist.get("id")
        spotify_genres = dedupe(spotify_artist.get("genres", []) or [])
        profile.genres = dedupe(profile.genres + spotify_genres)[:10]
        if spotify_genres:
            profile.genres_by_source["spotify"] = spotify_genres[:10]

    tags, similar = _lastfm_artist_for_profile(name, lastfm)
    profile.tags = dedupe(tags)[:10]
    profile.similar_artists = dedupe(similar)[:10]
    if tags:
        profile.tags_by_source["lastfm"] = list(tags)[:10]

    deezer_genres = _deezer_artist_for_profile(name, deezer)
    if deezer_genres:
        profile.genres = dedupe(profile.genres + deezer_genres)[:10]
        profile.genres_by_source["deezer"] = deezer_genres[:10]

    mb_artist, artist_data, relationships = _musicbrainz_artist_for_profile(name, musicbrainz)
    mb_mbid: str | None = None
    if mb_artist:
        mb_mbid = mb_artist.get("id")
        profile.mbid = mb_mbid
        profile.tags = dedupe(profile.tags + (mb_artist.get("tags") or []))[:10]
        if artist_data:
            genres = [item["name"] for item in artist_data.get("genres", []) or [] if item.get("name")]
            mb_tags = [item["name"] for item in artist_data.get("tags", []) or [] if item.get("name")]
            profile.genres = dedupe(profile.genres + genres)[:10]
            profile.tags = dedupe(profile.tags + mb_tags)[:10]
            if genres:
                profile.genres_by_source["musicbrainz"] = genres[:10]
            if mb_tags:
                profile.tags_by_source["musicbrainz"] = mb_tags[:10]
            if relationships:
                related, collaborators, labels, notes = relationships
                profile.related_acts = related[:15]
                profile.collaborator_artists = collaborators[:15]
                profile.labels = labels[:10]
                profile.notes = notes[:10]

    lb_listen_count, lb_similar, lb_community, lb_community_meta = _listenbrainz_artist_for_profile(
        name, listenbrainz, mbid=mb_mbid
    )
    if lb_listen_count is not None:
        profile.listen_count = lb_listen_count
    if lb_similar:
        profile.similar_artists = dedupe(profile.similar_artists + lb_similar)[:10]
    if lb_community:
        profile.community_artists = dedupe(lb_community)[:20]
        included = set(profile.community_artists)
        profile.community_artists_meta = {
            ca: s for ca, s in lb_community_meta.items() if ca in included
        }

    return profile


def build_taste_profile(
    tracks: list[InputTrack],
    spotify: Any | None = None,
    musicbrainz: Any | None = None,
    lastfm: Any | None = None,
    listenbrainz: Any | None = None,
    deezer: Any | None = None,
    max_artists: int = MAX_ENRICHED_ARTISTS,
    spotify_artist_metadata: dict[str, dict[str, Any]] | None = None,
    settings: Any | None = None,
) -> TasteProfile:
    artist_stats = infer_artist_counts_and_clusters(tracks)
    ranked_stats = sorted(artist_stats.values(), key=lambda item: (item[1], item[2]), reverse=True)
    spotify_artist_metadata = spotify_artist_metadata or {}

    locked_mb = _LockedProvider(musicbrainz) if musicbrainz else None

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [
                executor.submit(
                    _enrich_single_artist,
                    idx,
                    name,
                    count,
                    cluster_score,
                    max_artists=max_artists,
                    spotify=spotify,
                    musicbrainz=locked_mb,
                    lastfm=lastfm,
                    listenbrainz=listenbrainz,
                    deezer=deezer,
                    spotify_artist_metadata=spotify_artist_metadata,
                )
                for idx, (name, count, cluster_score) in enumerate(ranked_stats)
            ]
            profiles = [f.result() for f in futures]
    except Exception as exc:
        warnings.warn(
            f"Parallel artist enrichment failed ({exc!r}); retrying sequentially.",
            RuntimeWarning,
            stacklevel=2,
        )
        profiles = []
        for idx, (name, count, cluster_score) in enumerate(ranked_stats):
            profiles.append(
                _enrich_single_artist(
                    idx,
                    name,
                    count,
                    cluster_score,
                    max_artists=max_artists,
                    spotify=spotify,
                    musicbrainz=locked_mb,
                    lastfm=lastfm,
                    listenbrainz=listenbrainz,
                    deezer=deezer,
                    spotify_artist_metadata=spotify_artist_metadata,
                )
            )

    return aggregate_taste_profile(profiles, settings=settings, musicbrainz=musicbrainz, spotify=spotify)


def build_taste_profile_reusing_artists(
    tracks: list[InputTrack],
    existing_profile: TasteProfile,
    spotify: Any | None = None,
    musicbrainz: Any | None = None,
    lastfm: Any | None = None,
    listenbrainz: Any | None = None,
    deezer: Any | None = None,
    max_artists: int = MAX_ENRICHED_ARTISTS,
    spotify_artist_metadata: dict[str, dict[str, Any]] | None = None,
    settings: Any | None = None,
) -> TasteProfile:
    """Rebuild counts from the current playlist while reusing saved artist enrichment."""
    artist_stats = infer_artist_counts_and_clusters(tracks)
    ranked_stats = sorted(artist_stats.values(), key=lambda item: (item[1], item[2]), reverse=True)
    saved_by_key = {normalize_key(artist.name): artist for artist in existing_profile.artists}
    profiles: list[ArtistProfile] = []
    spotify_artist_metadata = spotify_artist_metadata or {}

    locked_mb = _LockedProvider(musicbrainz) if musicbrainz else None

    # First pass: reuse saved artists directly (no I/O needed)
    base_profiles: list[ArtistProfile | None] = []
    enrich_indices: list[int] = []
    for idx, (name, count, cluster_score) in enumerate(ranked_stats):
        key = normalize_key(name)
        saved = saved_by_key.get(key)
        if saved:
            profile = saved.model_copy(deep=True)
            profile.name = name
            profile.playlist_count = count
            profile.cluster_score = cluster_score
            profile.affinity_score = round(count * 2.0 + math.log2(cluster_score + 1.0), 4)
            base_profiles.append(profile)
        else:
            base_profiles.append(None)
            enrich_indices.append(idx)

    # Second pass: enrich new artists in parallel
    if enrich_indices:
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
                futures = {
                    idx: executor.submit(
                        _enrich_single_artist,
                        idx,
                        ranked_stats[idx][0],
                        ranked_stats[idx][1],
                        ranked_stats[idx][2],
                        max_artists=max_artists,
                        spotify=spotify,
                        musicbrainz=locked_mb,
                        lastfm=lastfm,
                        listenbrainz=listenbrainz,
                        deezer=deezer,
                        spotify_artist_metadata=spotify_artist_metadata,
                    )
                    for idx in enrich_indices
                }
                for idx, future in futures.items():
                    base_profiles[idx] = future.result()
        except Exception as exc:
            warnings.warn(
                f"Parallel artist enrichment failed ({exc!r}); retrying sequentially.",
                RuntimeWarning,
                stacklevel=2,
            )
            for idx in enrich_indices:
                base_profiles[idx] = _enrich_single_artist(
                    idx,
                    ranked_stats[idx][0],
                    ranked_stats[idx][1],
                    ranked_stats[idx][2],
                    max_artists=max_artists,
                    spotify=spotify,
                    musicbrainz=locked_mb,
                    lastfm=lastfm,
                    listenbrainz=listenbrainz,
                    deezer=deezer,
                    spotify_artist_metadata=spotify_artist_metadata,
                )

    profiles = [p for p in base_profiles if p is not None]
    return aggregate_taste_profile(profiles, settings=settings, musicbrainz=musicbrainz, spotify=spotify)


def aggregate_taste_profile(
    profiles: list[ArtistProfile],
    settings: Any | None = None,
    musicbrainz: Any | None = None,
    spotify: Any | None = None,
) -> TasteProfile:
    genre_weights: collections.defaultdict[str, float] = collections.defaultdict(float)
    tag_weights: collections.defaultdict[str, float] = collections.defaultdict(float)
    label_weights: collections.defaultdict[str, float] = collections.defaultdict(float)
    network_weights: collections.defaultdict[str, float] = collections.defaultdict(float)

    for profile in profiles:
        weight = profile.affinity_score
        for genre in profile.genres:
            genre_weights[genre] += weight
        for tag in profile.tags:
            tag_weights[tag] += weight
        for label in profile.labels:
            label_weights[label] += weight
        for artist in profile.related_acts + profile.collaborator_artists + profile.similar_artists + profile.community_artists:
            network_weights[artist] += weight * 0.4

    ranked = sorted(profiles, key=lambda item: item.affinity_score, reverse=True)
    
    # Create base profile
    base_profile = TasteProfile(
        artists=ranked,
        top_artists=ranked[:MAX_SEED_ARTISTS],
        top_genres=_top_weighted(genre_weights, 20),
        top_tags=_top_weighted(tag_weights, 25),
        top_labels=_top_weighted(label_weights, 15),
        network_artists=_top_weighted(network_weights, 40),
        n_artists=len(profiles),
    )
    
    # Apply community artists filtering if enabled
    if settings:
        filter_instance = CommunityArtistsFilter(settings)
        if filter_instance.enable_filtering:
            filtered_scores = filter_instance.filter_community_artists(
                base_profile, musicbrainz=musicbrainz, spotify=spotify
            )
            base_profile.filtered_community_artists = filtered_scores
    
    return base_profile


def _top_weighted(weights: dict[str, float], limit: int) -> list[WeightedTerm]:
    return [
        WeightedTerm(name=name, weight=round(weight, 4))
        for name, weight in sorted(weights.items(), key=lambda item: item[1], reverse=True)[:limit]
    ]


def _spotify_artist_for_profile(
    name: str,
    spotify: Any | None,
    spotify_artist_metadata: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    storage = _provider_storage(spotify)
    metadata = spotify_artist_metadata.get(normalize_key(name))
    if metadata:
        _store_artist_enrichment(
            storage,
            provider="spotify",
            artist_name=name,
            provider_artist_id=metadata.get("id"),
            payload=metadata,
        )
        return metadata

    cached = _cached_artist_enrichment(storage, provider="spotify", artist_name=name)
    if cached is not None:
        return cached
    if not _provider_can_call(spotify):
        return None

    artist = _maybe_call(spotify, "search_artist", name)
    _store_artist_enrichment(
        storage,
        provider="spotify",
        artist_name=name,
        provider_artist_id=artist.get("id") if artist else None,
        payload=artist,
    )
    return artist


def _lastfm_artist_for_profile(name: str, lastfm: Any | None) -> tuple[list[str], list[str]]:
    storage = _provider_storage(lastfm)
    cached = _cached_artist_enrichment(storage, provider="lastfm", artist_name=name)
    if cached is not None:
        return list(cached.get("tags") or []), list(cached.get("similar_artists") or [])
    if not _provider_can_call(lastfm):
        return [], []

    tags = _maybe_call(lastfm, "top_tags", name, 8) or []
    similar = _maybe_call(lastfm, "similar_artists", name, 10) or []
    payload = {"tags": list(tags), "similar_artists": list(similar)}
    _store_artist_enrichment(
        storage,
        provider="lastfm",
        artist_name=name,
        payload=payload if tags or similar else None,
    )
    return list(tags), list(similar)


def _musicbrainz_artist_for_profile(
    name: str,
    musicbrainz: Any | None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, tuple[list[str], list[str], list[str], list[str]] | None]:
    storage = _provider_storage(musicbrainz)
    cached = _cached_artist_enrichment(storage, provider="musicbrainz", artist_name=name)
    if cached is not None:
        relationships = cached.get("relationships")
        if relationships is not None:
            relationships = tuple(relationships)
        return cached.get("artist"), cached.get("lookup"), relationships
    if not _provider_can_call(musicbrainz):
        return None, None, None

    mb_artist = _maybe_call(musicbrainz, "search_artist", name)
    artist_data = _maybe_call(musicbrainz, "lookup_artist", mb_artist.get("id")) if mb_artist and mb_artist.get("id") else None
    relationships = _maybe_call(musicbrainz, "parse_relationships", artist_data) if artist_data else None
    payload = {
        "artist": mb_artist,
        "lookup": artist_data,
        "relationships": list(relationships) if relationships else None,
    }
    _store_artist_enrichment(
        storage,
        provider="musicbrainz",
        artist_name=name,
        provider_artist_id=mb_artist.get("id") if mb_artist else None,
        payload=payload if mb_artist else None,
    )
    return mb_artist, artist_data, relationships


def _cached_artist_enrichment(storage: Any | None, *, provider: str, artist_name: str) -> dict[str, Any] | None:
    if storage is None:
        return None
    row = storage.get_artist_enrichment(provider=provider, artist_name=artist_name)
    if not row:
        return None
    if row.get("status") == "success":
        return row.get("payload") or {}
    if row.get("status") == "miss":
        return {}
    return None


def _store_artist_enrichment(
    storage: Any | None,
    *,
    provider: str,
    artist_name: str,
    provider_artist_id: str | None = None,
    payload: dict[str, Any] | None = None,
) -> None:
    if storage is None:
        return
    storage.upsert_artist_enrichment(
        provider=provider,
        artist_name=artist_name,
        provider_artist_id=provider_artist_id,
        status="success" if payload else "miss",
        payload=payload or {},
    )


def _provider_storage(provider: Any | None) -> Any | None:
    return getattr(provider, "storage", None) if provider is not None else None


def _provider_can_call(provider: Any | None) -> bool:
    if provider is None:
        return False
    available = getattr(provider, "available", True)
    return bool(available)


def _maybe_call(provider: Any | None, method_name: str, *args: Any) -> Any | None:
    if provider is None:
        return None
    method = getattr(provider, method_name, None)
    if method is None:
        return None
    try:
        return method(*args)
    except Exception:
        return None


def _listenbrainz_artist_for_profile(name: str, listenbrainz: Any | None, mbid: str | None = None) -> tuple[int | None, list[str], list[str], dict[str, float]]:
    storage = _provider_storage(listenbrainz)
    cached = _cached_artist_enrichment(storage, provider="listenbrainz", artist_name=name)
    if cached is not None:
        community_names = list(cached.get("community_artists") or [])
        community_meta = dict(cached.get("community_artists_share") or {})
        return cached.get("listen_count"), list(cached.get("similar_artists") or []), community_names, community_meta
    if not _provider_can_call(listenbrainz):
        return None, [], [], {}

    listen_count: int | None = None
    community_artists: list[str] = []
    community_share: dict[str, float] = {}
    if mbid:
        result = _maybe_call(listenbrainz, "community_similar_artists", mbid)
        if result:
            listen_count, community_entries = result
            community_artists = [entry["name"] for entry in community_entries]
            community_share = {entry["name"]: entry["share"] for entry in community_entries}

    payload = {
        "listen_count": listen_count,
        "similar_artists": [],
        "community_artists": community_artists,
        "community_artists_share": community_share,
    }
    _store_artist_enrichment(
        storage,
        provider="listenbrainz",
        artist_name=name,
        payload=payload if (listen_count is not None or community_artists) else None,
    )
    return listen_count, [], community_artists, community_share


def _deezer_artist_for_profile(name: str, deezer: Any | None) -> list[str]:
    storage = _provider_storage(deezer)
    cached = _cached_artist_enrichment(storage, provider="deezer", artist_name=name)
    if cached is not None:
        return list(cached.get("genres") or [])
    if not _provider_can_call(deezer):
        return []

    genres = []
    artist = _maybe_call(deezer, "search_artist", name)
    if artist:
        genres = safe_get(artist, "genres", default=[]) or []
        if not genres:
            artist_id = artist.get("id")
            if artist_id:
                details = _maybe_call(deezer, "artist_details", artist_id)
                if details:
                    genres = safe_get(details, "genres", default=[]) or []

    payload = {"genres": list(genres)}
    _store_artist_enrichment(
        storage,
        provider="deezer",
        artist_name=name,
        provider_artist_id=str(artist.get("id")) if artist else None,
        payload=payload if genres else None,
    )
    return genres
