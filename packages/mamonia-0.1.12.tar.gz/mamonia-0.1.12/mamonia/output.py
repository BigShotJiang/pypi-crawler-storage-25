from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .models import ReleaseRecommendation, spotify_uri_to_url

NOTICE_NAME_MAX_LEN = 25


def missing_spotify_uri_notice(recommendations: list[ReleaseRecommendation]) -> str:
    return platform_availability_notice(recommendations)


def platform_availability_notice(recommendations: list[ReleaseRecommendation]) -> str:
    missing = _platform_availability_rows(recommendations)
    if not missing:
        return ""

    spotify_missing_count = sum(1 for row in missing if row["kind"] in {"tidal_fallback", "unavailable"})
    spotify_noun = "song" if spotify_missing_count == 1 else "songs"
    spotify_verb = "is" if spotify_missing_count == 1 else "are"
    tidal_missing_count = sum(1 for row in missing if row["kind"] == "unavailable")
    tidal_noun = "song" if tidal_missing_count == 1 else "songs"
    tidal_verb = "is" if tidal_missing_count == 1 else "are"
    lines = [
        "Please note:",
        (
            f"{spotify_missing_count} {spotify_noun} {spotify_verb} missing Spotify URI. "
            "Playlist export may have failed, or they may be unavailable on Spotify."
        ),
        (
            f"{tidal_missing_count} {tidal_noun} {tidal_verb} missing Tidal ID. "
            "Playlist export may have failed, or they may be unavailable on Tidal."
        ),
        "Review these songs:",
    ]
    lines.extend(row["message"] for row in missing)
    return "\n".join(lines)


def _missing_spotify_uri_rows(recommendations: list[ReleaseRecommendation]) -> list[str]:
    return [row["legacy"] for row in _platform_availability_rows(recommendations)]


def _platform_availability_rows(recommendations: list[ReleaseRecommendation]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for rec in recommendations:
        if rec.tracks:
            for track in rec.tracks:
                if not track.spotify_uri:
                    rows.append(
                        _availability_row(
                            track.title,
                            track.artists,
                            rec.title,
                            rec.release_date,
                            tidal_track_id=track.tidal_track_id,
                        )
                    )
        else:
            spotify_value = spotify_uri_to_url(rec.spotify_album_uri, fallback_id=rec.spotify_album_id, kind="album")
            if not spotify_value:
                reason = _unresolved_reason_tag(rec)
                rows.append(
                    _availability_row(
                        rec.title,
                        rec.artist,
                        rec.title,
                        rec.release_date,
                        tidal_track_id=rec.tidal_album_id,
                        reason_tag=reason,
                    )
                )
    return rows


def _availability_row(
    track_name: str,
    artist_name: str,
    album_name: str,
    release_date: str,
    *,
    tidal_track_id: str | None,
    reason_tag: str | None = None,
) -> dict[str, str]:
    legacy = _missing_spotify_uri_row(track_name, artist_name, album_name, release_date)
    if tidal_track_id:
        return {
            "kind": "tidal_fallback",
            "legacy": legacy,
            "message": (
                f"Track {legacy} lacks a Spotify URI and may be unavailable there, "
                "but it is accessible on Tidal."
            ),
        }
    return {
        "kind": "unavailable",
        "legacy": legacy,
        "message": (
            f"Track {legacy} lacks both a Spotify URI and a Tidal ID; "
            f"it may be unavailable on these platforms{f' [{reason_tag}]' if reason_tag else ''}."
        ),
    }


def _missing_spotify_uri_row(track_name: str, artist_name: str, album_name: str, release_date: str) -> str:
    date = release_date or "Unknown release date"
    track_label = _truncate_notice_name(track_name)
    artist_label = _truncate_notice_name(artist_name)
    album_label = _truncate_notice_name(album_name)
    return f"{track_label} by {artist_label} from {album_label} [{date}]"


def _truncate_notice_name(value: str, limit: int = NOTICE_NAME_MAX_LEN) -> str:
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 3)].rstrip() + "..."


def _unresolved_reason_tag(rec: ReleaseRecommendation) -> str | None:
    for reason in rec.rationale:
        if reason.startswith("recovery-result:"):
            return reason.split(":", 1)[1]
    if "empty-track-recovery-attempted" in rec.rationale:
        return "provider_query_exhausted"
    return None


def _release_level_isrc_source(rec: ReleaseRecommendation) -> str:
    reason = _unresolved_reason_tag(rec)
    return reason or ""


def write_recommendations(
    recommendations: list[ReleaseRecommendation],
    output_format: str,
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_format == "json":
        write_json(recommendations, output_path)
    elif output_format == "csv":
        write_tunemymusic_csv(recommendations, output_path)
    else:
        write_plain_text(recommendations, output_path)


def write_plain_text(recommendations: list[ReleaseRecommendation], output_path: Path) -> None:
    lines: list[str] = ["# Spotify attribution: when Spotify metadata is present, link back to Spotify."]
    for rec in recommendations:
        tier_tag = f" [{rec.tier}]" if rec.tier else ""
        score_tag = f" score={rec.score_normalized:.0f}" if rec.score_normalized else ""
        meta = f"{tier_tag}{score_tag}"
        if rec.tracks:
            for track in rec.tracks:
                spotify_url = spotify_uri_to_url(track.spotify_uri, fallback_id=track.spotify_track_id, kind="track")
                suffix = f" | Spotify: {spotify_url}" if spotify_url else ""
                lines.append(f"{track.artists} | {track.title} | {rec.title} | {rec.release_date}{meta}{suffix}")
        else:
            album_url = spotify_uri_to_url(rec.spotify_album_uri, fallback_id=rec.spotify_album_id, kind="album")
            suffix = f" | Spotify: {album_url}" if album_url else ""
            lines.append(f"{rec.artist} | [release] {rec.title} | {rec.title} | {rec.release_date}{meta}{suffix}")
    output_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def write_tunemymusic_csv(recommendations: list[ReleaseRecommendation], output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "Track name",
                "Artist name",
                "Album",
                "ISRC",
                "ISRC_source",
                "Spotify URI",
                "Tidal ID",
                "Apple Music ID",
            ],
        )
        writer.writeheader()
        for rec in recommendations:
            if rec.tracks:
                for track in rec.tracks:
                    writer.writerow(
                        {
                            "Track name": track.title,
                            "Artist name": track.artists,
                            "Album": rec.title,
                            "ISRC": track.isrc or "",
                            "ISRC_source": track.isrc_source or "",
                            "Spotify URI": track.spotify_uri or "",
                            "Tidal ID": track.tidal_track_id or "",
                            "Apple Music ID": track.apple_music_track_id or "",
                        }
                    )
            else:
                writer.writerow(
                    {
                        "Track name": rec.title,
                        "Artist name": rec.artist,
                        "Album": rec.title,
                        "ISRC": "",
                        "ISRC_source": _release_level_isrc_source(rec),
                        "Spotify URI": spotify_uri_to_url(rec.spotify_album_uri, fallback_id=rec.spotify_album_id, kind="album") or "",
                        "Tidal ID": rec.tidal_album_id or "",
                        "Apple Music ID": "",
                    }
                )


def write_json(recommendations: list[ReleaseRecommendation], output_path: Path) -> None:
    payload = [rec.export_dict() for rec in recommendations]
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def write_selection_logic(
    recommendations: list[ReleaseRecommendation],
    output_path: Path,
    *,
    run_config: dict[str, Any],
    profile: dict[str, Any],
    output: dict[str, Any],
    playlist_results: dict[str, Any] | None = None,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "run_config": _safe_json(run_config),
        "profile": _safe_json(profile),
        "output": _safe_json(output),
        "playlist_results": _safe_json(playlist_results or {}),
        "recommendations": [_selection_logic_recommendation(rec) for rec in recommendations],
    }
    if output_path.suffix.lower() == ".md":
        output_path.write_text(_selection_logic_markdown(payload), encoding="utf-8")
        return
    output_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _selection_logic_recommendation(rec: ReleaseRecommendation) -> dict[str, Any]:
    exported = rec.export_dict()
    explain = exported.get("explain", {})
    return {
        "artist": rec.artist,
        "title": rec.title,
        "release_date": rec.release_date,
        "release_type": rec.release_type,
        "score": rec.score,
        "score_normalized": rec.score_normalized,
        "tier": rec.tier,
        "confidence": rec.confidence_label,
        "rationale": rec.rationale,
        "structured_explanation": rec.explanation,
        "candidate_sources": explain.get("candidate_sources", []),
        "provider_evidence": explain.get("provider_evidence", {}),
        "filter_context": explain.get("filter_context", []),
        "tracklist_derivation": explain.get("tracklist_derivation"),
        "track_resolution_sources": explain.get("track_resolution_sources", []),
        "track_resolution_notes": explain.get("track_resolution_notes", []),
        "picked_tracks_reason": rec.explanation.get("picked_tracks_reason"),
        "popularity_provider": rec.explanation.get("popularity_provider"),
        "tracks": exported.get("tracks", []),
    }


def _safe_json(value: Any) -> Any:
    return json.loads(json.dumps(value, default=str, ensure_ascii=False))


def _selection_logic_markdown(payload: dict[str, Any]) -> str:
    lines: list[str] = ["# Selection Logic", ""]
    run_config = payload.get("run_config") or {}
    profile = payload.get("profile") or {}
    output = payload.get("output") or {}
    playlist_results = payload.get("playlist_results") or {}
    recommendations = payload.get("recommendations") or []
    score_view = _selection_logic_score_view(recommendations)

    lines.append("## Session")
    lines.append(f"**Profile:** {profile.get('name', 'unknown')} (#{profile.get('id', 'n/a')})")
    lines.append(f"**Output:** {output.get('format', 'n/a').upper()} → {output.get('path', 'n/a')}")
    lines.append(f"**New tracks marked as heard:** {output.get('heard_count', 0)}")

    if run_config:
        lines.append("")
        lines.append("## Discovery Settings")
        window_start = run_config.get('discovery_window_start')
        window_end = run_config.get('discovery_window_end')
        if window_start and window_end:
            start_year = window_start.split('-')[0] if window_start else '?'
            end_year = window_end.split('-')[0] if window_end else '?'
            time_range = f"**Time window:** {start_year} – {end_year}"
        else:
            months = run_config.get('months', 'n/a')
            time_range = f"**Time range:** Last {months} months"

        discovery_mode = run_config.get('discovery_mode', 'n/a')
        mode_friendly = _friendly_discovery_mode(discovery_mode)

        lines.append(time_range)
        lines.append(f"**Discovery mode:** {mode_friendly}")
        lines.append(f"**Result limit:** {run_config.get('limit', 'n/a')} releases")

        max_tracks = run_config.get('max_tracks')
        if max_tracks is not None:
            max_tracks_label = "unlimited (all tracks, original release order)" if int(max_tracks) <= 0 else str(max_tracks)
            lines.append(f"**Max tracks per release:** {max_tracks_label}")

        max_candidates = run_config.get('max_candidates')
        if max_candidates and max_candidates > 0:
            lines.append(f"**Max candidates per seed:** {max_candidates}")

        if run_config.get('penalize_frequent_artists'):
            lines.append("**Penalize frequent artists:** Yes")

        if run_config.get('shuffle_releases'):
            lines.append("**Shuffle releases:** Yes")

        global_memory = run_config.get('global_memory')
        if global_memory is not None:
            memory_label = "All saved profiles" if global_memory else "Current profile only"
            lines.append(f"**Exclude heard from:** {memory_label}")

        if run_config.get('dry_run'):
            lines.append("⚠️ **Dry run mode** (no data saved)")
    if playlist_results:
        lines.append("")
        lines.append("## Playlists Created")
        for provider, result in sorted(playlist_results.items()):
            created = "✓" if result.get('created') else "✗"
            url = result.get('url') or "N/A"
            lines.append(f"**{provider.capitalize()}:** {created}")
            if result.get('url'):
                lines.append(f"  {url}")

    lines.append("")
    lines.append(f"## Recommendations ({len(recommendations)} releases)")
    lines.append("")

    for idx, rec in enumerate(recommendations, start=1):
        display = score_view[idx - 1] if idx - 1 < len(score_view) else _selection_logic_display_fields(rec, score_floor=0.0, score_span=1.0)
        artist = rec.get('artist', 'Unknown Artist')
        title = rec.get('title', 'Unknown Title')
        release_date = rec.get('release_date', '?')
        release_type = rec.get('release_type', '?').upper()

        lines.append(f"### {idx}. {artist} – {title}")
        lines.append(f"**Release:** {release_date} ({release_type})")
        lines.append(
            f"**Score:** {display['normalized']}% ({display['tier']}, {display['confidence']} confidence)"
        )

        rationale = rec.get("rationale") or []
        if rationale:
            rationale_text = " → ".join(str(item) for item in rationale)
            lines.append(f"**Why picked:** {rationale_text}")

        provider_evidence = rec.get("provider_evidence") or {}
        if provider_evidence:
            evidence_items = []
            for key in ("musicbrainz_release_group_id", "spotify_album_id", "tidal_album_id", "label"):
                value = provider_evidence.get(key)
                if value:
                    key_friendly = key.replace("_", " ").title()
                    evidence_items.append(f"{key_friendly}: {value}")
            if evidence_items:
                lines.append("**Provider info:** " + " • ".join(evidence_items))

        track_notes = rec.get("track_resolution_notes") or []
        if track_notes:
            notes_text = " → ".join(str(note) for note in track_notes)
            lines.append(f"**Track info:** {notes_text}")

        picked_reason = rec.get("picked_tracks_reason")
        if picked_reason:
            lines.append(f"**Track selection:** {picked_reason}")

        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _friendly_discovery_mode(mode: str) -> str:
    """Convert internal mode name to user-friendly label."""
    mode_map = {
        "standard": "Top first – Highest scoring recommendations",
        "balanced": "Balanced – Mix of high, mid, and low-scored recommendations",
        "deep_cuts": "Prefer less popular releases",
        "deep_diverse": "Less popular releases with diverse scoring",
    }
    return mode_map.get(str(mode), str(mode))


def _selection_logic_score_view(recommendations: list[dict[str, Any]]) -> list[dict[str, str]]:
    raw_scores = []
    for rec in recommendations:
        score = rec.get("score")
        if isinstance(score, (int, float)):
            raw_scores.append(float(score))
    if not raw_scores:
        return [_selection_logic_display_fields(rec, score_floor=0.0, score_span=1.0) for rec in recommendations]
    floor = min(raw_scores)
    span = max(raw_scores) - floor
    if span <= 0:
        span = 1.0
    return [_selection_logic_display_fields(rec, score_floor=floor, score_span=span) for rec in recommendations]


def _selection_logic_display_fields(rec: dict[str, Any], *, score_floor: float, score_span: float) -> dict[str, str]:
    raw = rec.get("score")
    raw_value = float(raw) if isinstance(raw, (int, float)) else 0.0
    normalized = rec.get("score_normalized")
    normalized_value = float(normalized) if isinstance(normalized, (int, float)) else 0.0
    tier = str(rec.get("tier") or "").strip()
    confidence = str(rec.get("confidence") or "").strip()

    if normalized_value <= 0 and raw is not None:
        normalized_value = ((raw_value - score_floor) / score_span) * 100.0
        normalized_value = max(0.0, min(100.0, normalized_value))
    if not tier:
        if normalized_value >= 75:
            tier = "Tier 1"
        elif normalized_value >= 50:
            tier = "Tier 2"
        elif normalized_value >= 25:
            tier = "Tier 3"
        else:
            tier = "Tier 4"
    if not confidence:
        if normalized_value >= 70:
            confidence = "High"
        elif normalized_value >= 40:
            confidence = "Medium"
        else:
            confidence = "Low"
    return {
        "raw": f"{raw_value:.6g}",
        "normalized": f"{normalized_value:.2f}",
        "tier": tier,
        "confidence": confidence,
    }


def _playlist_name(rec: ReleaseRecommendation) -> str:
    date = f" ({rec.release_date})" if rec.release_date else ""
    return f"Mamonia - {rec.artist} - {rec.title}{date}"
