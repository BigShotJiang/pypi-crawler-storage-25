from __future__ import annotations

from dataclasses import dataclass, field

from ..models import TasteProfile
from ..utils import normalize_key


@dataclass
class ProfileIndex:
    """Denormalized, in-memory view of seed-artist enrichment built once per filter run.

    All name keys are normalized via normalize_key() so lookups are case-insensitive.

    DEPRECATED: This module is legacy code from the old pipeline. It is retained for
    backward compatibility with `mamonia/filtering/community_artists.py`. The v2 pipeline
    (`mamonia/pipeline_v2.py`) bypasses community filtering entirely, using tier-based
    graph expansion instead.

    TODO: Remove this module after making v2 the sole pipeline.
    """

    # Forward maps: normalized seed name → set of normalized attribute values
    seed_genres: dict[str, set[str]] = field(default_factory=dict)
    seed_tags: dict[str, set[str]] = field(default_factory=dict)
    seed_labels: dict[str, set[str]] = field(default_factory=dict)
    seed_collaborators: dict[str, set[str]] = field(default_factory=dict)
    seed_related: dict[str, set[str]] = field(default_factory=dict)
    seed_similar_lastfm: dict[str, set[str]] = field(default_factory=dict)

    # Reverse maps: normalized community-artist name → set of normalized seed names that reference it
    collaborator_to_seeds: dict[str, set[str]] = field(default_factory=dict)
    related_to_seeds: dict[str, set[str]] = field(default_factory=dict)
    similar_lastfm_to_seeds: dict[str, set[str]] = field(default_factory=dict)

    # ListenBrainz listener-share: normalized community-artist name → max share across seeds
    lb_listener_share: dict[str, float] = field(default_factory=dict)


def build_profile_index(profile: TasteProfile) -> ProfileIndex:
    """Build a ProfileIndex from a TasteProfile in a single pass — zero new provider calls."""
    index = ProfileIndex()

    for artist in profile.artists:
        nk = normalize_key(artist.name)
        if not nk:
            continue

        index.seed_genres[nk] = {normalize_key(g) for g in artist.genres if g}
        index.seed_tags[nk] = {normalize_key(t) for t in artist.tags if t}
        index.seed_labels[nk] = {normalize_key(lb) for lb in artist.labels if lb}
        index.seed_collaborators[nk] = {normalize_key(c) for c in artist.collaborator_artists if c}
        index.seed_related[nk] = {normalize_key(r) for r in artist.related_acts if r}
        index.seed_similar_lastfm[nk] = {normalize_key(s) for s in artist.similar_artists if s}

        # Reverse: collaborator/related/similar → seed names that list them
        for collab in artist.collaborator_artists:
            ck = normalize_key(collab)
            if ck:
                index.collaborator_to_seeds.setdefault(ck, set()).add(nk)
        for related in artist.related_acts:
            rk = normalize_key(related)
            if rk:
                index.related_to_seeds.setdefault(rk, set()).add(nk)
        for similar in artist.similar_artists:
            sk = normalize_key(similar)
            if sk:
                index.similar_lastfm_to_seeds.setdefault(sk, set()).add(nk)

        # LB share: keep the highest share seen across all seeds for each community artist
        for ca_name, share in artist.community_artists_meta.items():
            ck = normalize_key(ca_name)
            if ck and share > index.lb_listener_share.get(ck, 0.0):
                index.lb_listener_share[ck] = share

    return index
