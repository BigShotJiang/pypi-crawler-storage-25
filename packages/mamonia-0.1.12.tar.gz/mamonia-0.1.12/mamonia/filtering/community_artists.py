from __future__ import annotations

import math
from collections import defaultdict
from typing import Any

from ..config import Settings
from ..models import ArtistProfile, TasteProfile, FilteredCommunityArtist
from ..utils import normalize_key
from .profile_index import ProfileIndex, build_profile_index


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    union = a | b
    return len(a & b) / len(union)


class CommunityArtistsFilter:
    """
    Filter community artists to reduce ListenBrainz-sourced noise.

    DEPRECATED: This module is legacy code from the old pipeline. It is retained for
    backward compatibility with `mamonia/analysis.py` which still uses it in
    `build_taste_profile()` and `aggregate_taste_profile()`. The v2 pipeline
    (`mamonia/pipeline_v2.py`) bypasses community filtering entirely, using tier-based
    graph expansion instead.

    Core guarantees:
    - Ubiquitous artists (appearing across many seeds) require metadata overlap to survive.
    - Specific/niche artists (few seeds) require cross-source verification (Last.fm similar,
      MusicBrainz collaborator/related, or genre/tag overlap).  Artists that are LB-only without
      cross-verification are stored with rescue_reason="lb-only:X.XX" and low relevance so that
      discovery.py can gate them by the user's discovery_mode (deep_cuts vs standard).
    - All seed-side data is read from ArtistProfile via ProfileIndex — zero re-fetching for seeds.
    - Community artist enrichment is fetched at most once per artist per filter run (memoized).

    TODO: Remove this module after making v2 the sole pipeline (requires removing
    `CommunityArtistsFilter` usage from `mamonia/analysis.py`).
    """

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or Settings()
        self.ubiquity_threshold: float = getattr(self.settings, "ubiquitous_artist_threshold", 0.3)
        self.min_genre_overlap: float = getattr(self.settings, "genre_overlap_minimum", 0.2)
        self.use_global_cache: bool = getattr(self.settings, "use_global_ubiquity_cache", False)
        self.enable_filtering: bool = getattr(self.settings, "enable_community_filtering", True)
        self._min_share_solo: float = getattr(self.settings, "listenbrainz_min_share_for_solo", 0.6)
        self._min_share_deep_cuts: float = getattr(self.settings, "listenbrainz_min_share_for_deep_cuts", 0.2)

    def filter_community_artists(
        self,
        profile: TasteProfile,
        storage: Any | None = None,
        musicbrainz: Any | None = None,
        spotify: Any | None = None,
    ) -> dict[str, FilteredCommunityArtist]:
        if not self.enable_filtering:
            return self._get_original_community_scores(profile)

        all_community = self._collect_community_artists(profile)
        if not all_community:
            return {}

        index = build_profile_index(profile)
        ubiquity_scores = self._compute_ubiquity_scores(profile, all_community)

        # Per-run memoization: community artist name (normalized) → enrichment dict
        enrichment_cache: dict[str, dict[str, list[str]]] = {}

        result: dict[str, FilteredCommunityArtist] = {}
        for artist_name, ubiquity_score in ubiquity_scores.items():
            seed_artists = list(all_community[artist_name]["seed_artists"])
            ca_key = normalize_key(artist_name)

            if ubiquity_score < self.ubiquity_threshold:
                # Ubiquitous artist — must prove a legitimate connection to survive.
                fca = self._evaluate_ubiquitous(
                    artist_name, ca_key, ubiquity_score, seed_artists, index, musicbrainz, spotify, enrichment_cache
                )
            else:
                # Specific/niche artist — require cross-source verification.
                fca = self._evaluate_specific(
                    artist_name, ca_key, ubiquity_score, seed_artists, index, musicbrainz, spotify, enrichment_cache
                )

            if fca is not None:
                result[artist_name] = fca

        return result

    # ------------------------------------------------------------------
    # Internal: per-artist evaluation
    # ------------------------------------------------------------------

    def _evaluate_ubiquitous(
        self,
        artist_name: str,
        ca_key: str,
        ubiquity_score: float,
        seed_artists: list[str],
        index: ProfileIndex,
        musicbrainz: Any | None,
        spotify: Any | None,
        enrichment_cache: dict[str, dict[str, list[str]]],
    ) -> FilteredCommunityArtist:
        ca_enr = self._fetch_enrichment(artist_name, musicbrainz, spotify, enrichment_cache)
        ca_genres = {normalize_key(g) for g in ca_enr.get("genres", []) if g}
        ca_tags = {normalize_key(t) for t in ca_enr.get("tags", []) if t}
        ca_labels = {normalize_key(lb) for lb in ca_enr.get("labels", []) if lb}

        # Collaboration via ProfileIndex (no provider call)
        collaborated = ca_key in index.collaborator_to_seeds or ca_key in index.related_to_seeds

        # Best genre overlap across seeds
        best_genre_overlap = 0.0
        best_matching_genres: list[str] = []
        if ca_genres:
            for seed_nk, seed_genres in index.seed_genres.items():
                intersection = seed_genres & ca_genres
                score = _jaccard(seed_genres, ca_genres)
                if score > best_genre_overlap:
                    best_genre_overlap = score
                    best_matching_genres = [g for g in intersection]

        # Best tag overlap
        best_tag_overlap = 0.0
        best_matching_tags: list[str] = []
        if ca_tags:
            for seed_nk, seed_tags in index.seed_tags.items():
                intersection = seed_tags & ca_tags
                score = _jaccard(seed_tags, ca_tags)
                if score > best_tag_overlap:
                    best_tag_overlap = score
                    best_matching_tags = [t for t in intersection]

        # Best label overlap
        best_label_overlap = 0.0
        best_matching_labels: list[str] = []
        if ca_labels:
            for seed_nk, seed_labels in index.seed_labels.items():
                intersection = seed_labels & ca_labels
                score = _jaccard(seed_labels, ca_labels)
                if score > best_label_overlap:
                    best_label_overlap = score
                    best_matching_labels = [lb for lb in intersection]

        if collaborated:
            max_overlap, best_reason = 1.0, "collaboration"
        elif best_genre_overlap >= self.min_genre_overlap:
            max_overlap, best_reason = best_genre_overlap, "genre-match"
        elif best_tag_overlap >= self.min_genre_overlap:
            max_overlap, best_reason = best_tag_overlap, "tag-match"
        elif best_label_overlap >= self.min_genre_overlap:
            max_overlap, best_reason = best_label_overlap, "label-match"
        else:
            max_overlap, best_reason = 0.0, "none"

        penalty = self._ubiquity_penalty(ubiquity_score)

        if max_overlap > self.min_genre_overlap or collaborated:
            boost = 1.0 + max_overlap
            relevance = (1 - penalty) * boost
            rescued = True
        else:
            relevance = 0.1
            best_reason = "none"
            best_matching_genres = best_matching_tags = best_matching_labels = []
            rescued = False

        return FilteredCommunityArtist(
            relevance=relevance,
            ubiquity_score=ubiquity_score,
            penalty=penalty,
            contextual_score=max_overlap,
            genre_overlap=best_genre_overlap if best_reason == "genre-match" else 0.0,
            matching_genres=best_matching_genres,
            tag_overlap=best_tag_overlap if best_reason == "tag-match" else 0.0,
            matching_tags=best_matching_tags,
            collaborated=collaborated,
            label_overlap=best_label_overlap if best_reason == "label-match" else 0.0,
            matching_labels=best_matching_labels,
            seed_artists=seed_artists,
            rescued=rescued,
            rescue_reason=best_reason,
        )

    def _evaluate_specific(
        self,
        artist_name: str,
        ca_key: str,
        ubiquity_score: float,
        seed_artists: list[str],
        index: ProfileIndex,
        musicbrainz: Any | None,
        spotify: Any | None,
        enrichment_cache: dict[str, dict[str, list[str]]],
    ) -> FilteredCommunityArtist | None:
        # Check cheap structural cross-references first (ProfileIndex, no API call).
        verifications: list[str] = []
        collaborated = False

        if ca_key in index.collaborator_to_seeds:
            verifications.append("mb-collaborator")
            collaborated = True
        if ca_key in index.related_to_seeds:
            verifications.append("mb-related")
        if ca_key in index.similar_lastfm_to_seeds:
            verifications.append("lastfm-similar")

        # Genre/tag overlap against seeds (one provider call for community artist, seeds are free).
        genre_overlap = 0.0
        matching_genres: list[str] = []
        tag_overlap = 0.0
        matching_tags: list[str] = []

        if not verifications:
            ca_enr = self._fetch_enrichment(artist_name, musicbrainz, spotify, enrichment_cache)
            ca_genres = {normalize_key(g) for g in ca_enr.get("genres", []) if g}
            ca_tags = {normalize_key(t) for t in ca_enr.get("tags", []) if t}

            if ca_genres:
                for seed_nk, seed_genres in index.seed_genres.items():
                    intersection = seed_genres & ca_genres
                    score = _jaccard(seed_genres, ca_genres)
                    if score > genre_overlap:
                        genre_overlap = score
                        matching_genres = list(intersection)
                if genre_overlap >= self.min_genre_overlap:
                    verifications.append("metadata-overlap")

            if not verifications and ca_tags:
                for seed_nk, seed_tags in index.seed_tags.items():
                    intersection = seed_tags & ca_tags
                    score = _jaccard(seed_tags, ca_tags)
                    if score > tag_overlap:
                        tag_overlap = score
                        matching_tags = list(intersection)
                if tag_overlap >= self.min_genre_overlap:
                    verifications.append("tag-overlap")

        share = index.lb_listener_share.get(ca_key, 0.0)

        if verifications:
            relevance = 1.0
            rescue_reason = "cross-verified:" + ",".join(verifications)
            rescued = True
        elif share >= self._min_share_solo:
            relevance = 0.7
            rescue_reason = f"lb-density:{share:.2f}"
            rescued = True
        else:
            # LB-only with insufficient share.  Keep in filtered_community_artists with low
            # relevance and rescue_reason="lb-only:..." so discovery.py can gate by deep_cuts.
            relevance = 0.3
            rescue_reason = f"lb-only:{share:.2f}"
            rescued = False

        return FilteredCommunityArtist(
            relevance=relevance,
            ubiquity_score=ubiquity_score,
            penalty=0.0,
            contextual_score=genre_overlap or tag_overlap,
            genre_overlap=genre_overlap,
            matching_genres=matching_genres,
            tag_overlap=tag_overlap,
            matching_tags=matching_tags,
            collaborated=collaborated,
            label_overlap=0.0,
            matching_labels=[],
            seed_artists=seed_artists,
            rescued=rescued,
            rescue_reason=rescue_reason,
        )

    # ------------------------------------------------------------------
    # Memoized enrichment fetch for community artists
    # ------------------------------------------------------------------

    def _fetch_enrichment(
        self,
        artist_name: str,
        musicbrainz: Any | None,
        spotify: Any | None,
        cache: dict[str, dict[str, list[str]]],
    ) -> dict[str, list[str]]:
        key = normalize_key(artist_name)
        if key in cache:
            return cache[key]

        result: dict[str, list[str]] = {"genres": [], "tags": [], "labels": []}

        if spotify:
            try:
                search = getattr(spotify, "search_artist", None)
                if callable(search):
                    data = search(artist_name)
                    if data:
                        result["genres"].extend(data.get("genres") or [])
            except Exception:
                pass

        if musicbrainz:
            try:
                search_fn = getattr(musicbrainz, "search_artist", None)
                lookup_fn = getattr(musicbrainz, "lookup_artist", None)
                parse_fn = getattr(musicbrainz, "parse_relationships", None)
                if callable(search_fn):
                    mb = search_fn(artist_name)
                    if mb and mb.get("id") and callable(lookup_fn):
                        data = lookup_fn(mb["id"])
                        if data:
                            result["genres"].extend(
                                g["name"] for g in (data.get("genres") or []) if g.get("name")
                            )
                            result["tags"].extend(
                                t["name"] for t in (data.get("tags") or []) if t.get("name")
                            )
                            if callable(parse_fn):
                                _related, _collabs, labels, _notes = parse_fn(data)
                                result["labels"].extend(labels)
            except Exception:
                pass

        cache[key] = result
        return result

    # ------------------------------------------------------------------
    # Helpers unchanged from original design
    # ------------------------------------------------------------------

    def _get_original_community_scores(self, profile: TasteProfile) -> dict[str, FilteredCommunityArtist]:
        result: dict[str, FilteredCommunityArtist] = {}
        for artist in profile.artists:
            for community_artist in artist.community_artists:
                result[community_artist] = FilteredCommunityArtist(
                    relevance=1.0,
                    ubiquity_score=1.0,
                    penalty=0.0,
                    contextual_score=0.0,
                    genre_overlap=0.0,
                    matching_genres=[],
                    tag_overlap=0.0,
                    matching_tags=[],
                    collaborated=False,
                    label_overlap=0.0,
                    matching_labels=[],
                    seed_artists=[artist.name],
                    rescued=False,
                    rescue_reason="none",
                )
        return result

    def _collect_community_artists(
        self, profile: TasteProfile
    ) -> dict[str, dict[str, Any]]:
        all_community: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"count": 0, "seed_artists": set()}
        )
        for artist in profile.artists:
            for community_artist in artist.community_artists:
                all_community[community_artist]["count"] += 1
                all_community[community_artist]["seed_artists"].add(artist.name)
        return dict(all_community)

    def _compute_ubiquity_scores(
        self, profile: TasteProfile, all_community: dict[str, dict[str, Any]]
    ) -> dict[str, float]:
        n_seed_artists = len(profile.artists)
        if n_seed_artists == 0:
            return {}
        df = {artist: len(data["seed_artists"]) for artist, data in all_community.items()}
        idf = {artist: math.log(n_seed_artists / df_count) for artist, df_count in df.items()}
        max_score = max(idf.values()) if idf else 1.0
        return {
            artist: idf.get(artist, 0.0) / max_score if max_score > 0 else 0.0
            for artist in all_community
        }

    def _ubiquity_penalty(self, ubiquity_score: float) -> float:
        scaled = (ubiquity_score - 0.5) * 10
        return 1.0 / (1.0 + math.exp(-scaled))
