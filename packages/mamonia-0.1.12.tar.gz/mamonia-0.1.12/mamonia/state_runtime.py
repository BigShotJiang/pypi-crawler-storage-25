from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import Settings


def preferences_path(data_dir: Path) -> Path:
    return data_dir / "preferences.json"


def load_preferences(data_dir: Path) -> dict[str, Any]:
    path = preferences_path(data_dir)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_preferences(data_dir: Path, prefs: dict[str, Any]) -> None:
    path = preferences_path(data_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(prefs, indent=2, ensure_ascii=False), encoding="utf-8")


def get_last_active_db_path(data_dir: Path) -> Path | None:
    prefs = load_preferences(data_dir)
    raw = str(prefs.get("last_active_db_path", "")).strip()
    if not raw:
        return None
    return Path(raw).expanduser().absolute()


def set_last_active_db_path(data_dir: Path, db_path: Path) -> None:
    prefs = load_preferences(data_dir)
    prefs["last_active_db_path"] = str(db_path.absolute())
    save_preferences(data_dir, prefs)


def detect_db_path_change(settings: Settings) -> str | None:
    previous = get_last_active_db_path(settings.data_dir)
    current = settings.db_path.absolute()
    if previous is None or previous == current:
        return None
    return (
        "WARNING: active database path changed since last run.\n"
        f"Previous: {previous}\n"
        f"Current:  {current}"
    )


def update_last_active_db_path(settings: Settings) -> None:
    set_last_active_db_path(settings.data_dir, settings.db_path)


@dataclass(frozen=True)
class LegacyArtifacts:
    cwd_env: Path
    cwd_db: Path
    cwd_home: Path
    cwd_token_files: list[Path]

    def existing(self) -> list[Path]:
        out: list[Path] = []
        for path in [self.cwd_env, self.cwd_db, self.cwd_home, *self.cwd_token_files]:
            if path.exists():
                out.append(path)
        return out


def detect_legacy_cwd_artifacts(cwd: Path) -> LegacyArtifacts:
    token_candidates = [
        cwd / ".spotipy_token_cache_playlist_read_private_playlist_read_collaborative",
        cwd / ".spotipy_token_cache_playlist_modify_private",
        cwd / "tidal_session.json",
    ]
    return LegacyArtifacts(
        cwd_env=cwd / ".env",
        cwd_db=cwd / "mamonia.sqlite",
        cwd_home=cwd / ".mamonia",
        cwd_token_files=token_candidates,
    )


def _copy_file_if_missing(src: Path, dst: Path) -> bool:
    if not src.exists() or dst.exists():
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True


def _table_count(path: Path, table: str) -> int:
    if not path.exists():
        return 0
    conn = sqlite3.connect(path)
    try:
        row = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
        return int(row[0]) if row else 0
    except sqlite3.Error:
        return 0
    finally:
        conn.close()


def _merge_table_rows(src_conn: sqlite3.Connection, dst_conn: sqlite3.Connection, table: str, conflict_cols: list[str]) -> int:
    rows = src_conn.execute(f"SELECT * FROM {table}").fetchall()
    if not rows:
        return 0
    col_names = [d[0] for d in src_conn.execute(f"SELECT * FROM {table} LIMIT 1").description or []]
    if not col_names:
        return 0
    insert_cols = [c for c in col_names if c != "id"]
    placeholders = ", ".join("?" for _ in insert_cols)
    cols_sql = ", ".join(insert_cols)
    conflict_sql = ", ".join(conflict_cols)
    update_cols = [c for c in insert_cols if c not in conflict_cols]
    update_sql = ", ".join(f"{c}=excluded.{c}" for c in update_cols)
    sql = (
        f"INSERT INTO {table} ({cols_sql}) VALUES ({placeholders}) "
        f"ON CONFLICT({conflict_sql}) DO UPDATE SET {update_sql}"
    )
    inserted = 0
    for row in rows:
        values = [row[col_names.index(c)] for c in insert_cols]
        dst_conn.execute(sql, values)
        inserted += 1
    return inserted


def merge_legacy_db_into_managed(legacy_db: Path, managed_db: Path) -> dict[str, int]:
    summary = {"taste_profiles": 0, "heard_releases": 0, "api_cache": 0}
    if not legacy_db.exists() or not managed_db.exists():
        return summary
    src_conn = sqlite3.connect(legacy_db)
    dst_conn = sqlite3.connect(managed_db)
    try:
        dst_conn.execute("PRAGMA foreign_keys=ON")
        summary["taste_profiles"] = _merge_table_rows(src_conn, dst_conn, "taste_profiles", ["source_key"])
        summary["heard_releases"] = _merge_table_rows(src_conn, dst_conn, "heard_releases", ["canonical_key"])
        summary["api_cache"] = _merge_table_rows(src_conn, dst_conn, "api_cache", ["provider", "cache_key"])
        dst_conn.commit()
    finally:
        src_conn.close()
        dst_conn.close()
    return summary


def migrate_state_to_managed(*, settings: Settings, cwd: Path, dry_run: bool, force: bool) -> dict[str, Any]:
    artifacts = detect_legacy_cwd_artifacts(cwd)
    report: dict[str, Any] = {
        "managed_data_dir": str(settings.data_dir),
        "managed_db_path": str(settings.db_path),
        "dry_run": dry_run,
        "copied_files": [],
        "warnings": [],
        "merge_summary": {"taste_profiles": 0, "heard_releases": 0, "api_cache": 0},
    }

    existing = artifacts.existing()
    report["legacy_artifacts"] = [str(p) for p in existing]
    if not existing:
        return report

    if artifacts.cwd_env.exists():
        dst = settings.data_dir / ".env"
        if dry_run:
            if not dst.exists():
                report["copied_files"].append({"src": str(artifacts.cwd_env), "dst": str(dst)})
        elif _copy_file_if_missing(artifacts.cwd_env, dst):
            report["copied_files"].append({"src": str(artifacts.cwd_env), "dst": str(dst)})

    for src in artifacts.cwd_token_files:
        dst = settings.data_dir / src.name
        if dry_run:
            if src.exists() and not dst.exists():
                report["copied_files"].append({"src": str(src), "dst": str(dst)})
            continue
        if _copy_file_if_missing(src, dst):
            report["copied_files"].append({"src": str(src), "dst": str(dst)})

    managed_count = _table_count(settings.db_path, "taste_profiles") + _table_count(settings.db_path, "heard_releases")
    legacy_count = _table_count(artifacts.cwd_db, "taste_profiles") + _table_count(artifacts.cwd_db, "heard_releases")

    if artifacts.cwd_db.exists():
        if managed_count == 0 and legacy_count > 0:
            if dry_run:
                report["copied_files"].append({"src": str(artifacts.cwd_db), "dst": str(settings.db_path)})
            else:
                settings.data_dir.mkdir(parents=True, exist_ok=True)
                if not settings.db_path.exists() or force:
                    shutil.copy2(artifacts.cwd_db, settings.db_path)
                    report["copied_files"].append({"src": str(artifacts.cwd_db), "dst": str(settings.db_path)})
        elif managed_count > 0 and legacy_count > 0:
            if dry_run:
                report["warnings"].append("Both managed and legacy databases are non-empty; merge would be executed.")
            else:
                report["merge_summary"] = merge_legacy_db_into_managed(artifacts.cwd_db, settings.db_path)
        elif managed_count > 0 and legacy_count == 0:
            report["warnings"].append("Managed database is authoritative (legacy DB is empty).")

    return report
