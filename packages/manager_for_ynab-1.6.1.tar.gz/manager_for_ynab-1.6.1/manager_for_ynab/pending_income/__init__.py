import argparse
import asyncio
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from importlib.resources import files
from pathlib import Path
from typing import TYPE_CHECKING

import aiosqlite
import rich
import ynab
from rich.progress import Progress
from rich.table import Table
from sqlite_export_for_ynab import default_db_path
from sqlite_export_for_ynab import sync

from manager_for_ynab._auth import resolve_token

if TYPE_CHECKING:
    from collections.abc import Sequence


_PACKAGE = "manager-for-ynab pending-income"
_PENDING_INCOME_SQL = (
    files("manager_for_ynab.pending_income").joinpath("pending_income.sql").read_text()
)


@dataclass(frozen=True)
class Transaction:
    id: str
    plan_id: str
    account_name: str
    payee_name: str
    amount_formatted: str
    date: str


@dataclass(frozen=True)
class PendingIncomeResult:
    transactions: list[Transaction]
    updated_count: int


async def run(
    argv: Sequence[str] | None = None, *, token_override: str | None = None
) -> int:
    parser = argparse.ArgumentParser(prog=_PACKAGE)
    parser.add_argument(
        "--sqlite-export-for-ynab-db", type=Path, default=default_db_path()
    )
    parser.add_argument("--sqlite-export-for-ynab-full-refresh", action="store_true")
    parser.add_argument("--sync", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--for-real", action="store_true")
    parser.add_argument("--skip-matched", action="store_true")
    parser.add_argument("--quiet", action="store_true")

    args = parser.parse_args(argv)
    db: Path = args.sqlite_export_for_ynab_db
    full_refresh: bool = args.sqlite_export_for_ynab_full_refresh
    should_sync: bool = args.sync
    for_real: bool = args.for_real
    skip_matched: bool = args.skip_matched
    quiet: bool = args.quiet

    result = await pending_income(
        db=db,
        full_refresh=full_refresh,
        should_sync=should_sync,
        for_real=for_real,
        skip_matched=skip_matched,
        token_override=token_override,
        quiet=quiet,
    )

    if len(result.transactions) and not for_real:
        _print("Use --for-real to actually update transactions.", quiet=quiet)
        return 0

    return 0


async def pending_income(
    *,
    db: Path,
    full_refresh: bool,
    should_sync: bool = True,
    for_real: bool,
    skip_matched: bool,
    token_override: str | None,
    quiet: bool,
) -> PendingIncomeResult:
    token = resolve_token(token_override)

    if should_sync:
        _print("** Refreshing SQLite DB **", quiet=quiet)
        await sync(token, db, full_refresh, quiet=quiet)
        _print("** Done **", quiet=quiet)

    async with aiosqlite.connect(db) as con:
        con.row_factory = aiosqlite.Row
        txns_by_plan = await fetch_pending_income(con, skip_matched=skip_matched)

    found_txns = [txn for txns in txns_by_plan.values() for txn in txns]
    total_txns = len(found_txns)

    _print(f"Found {total_txns} income transaction(s) to update.", quiet=quiet)
    if found_txns:
        print_found_txns(found_txns, quiet=quiet)

        if for_real:
            grouped = build_updates(txns_by_plan, date.today())
            api_client = ynab.TransactionsApi(
                ynab.ApiClient(ynab.Configuration(access_token=token))
            )

            with Progress(disable=quiet or not sys.stderr.isatty()) as progress:
                task_id = progress.add_task(
                    f"Updating {total_txns} transaction(s)", total=total_txns
                )
                for plan_id, txns in grouped.items():
                    await asyncio.to_thread(
                        api_client.update_transactions,
                        plan_id,
                        ynab.PatchTransactionsWrapper(transactions=txns),
                    )
                    progress.update(task_id, advance=len(txns))
            _print("Done", quiet=quiet)

    return PendingIncomeResult(
        transactions=found_txns,
        updated_count=total_txns if for_real else 0,
    )


def _print(message: str, *, quiet: bool) -> None:
    if not quiet:
        print(message)


def build_updates(
    txns_by_plan: dict[str, list[Transaction]], today: date
) -> dict[str, list[ynab.SaveTransactionWithIdOrImportId]]:
    grouped: dict[str, list[ynab.SaveTransactionWithIdOrImportId]] = defaultdict(list)
    for plan_id, txns in txns_by_plan.items():
        grouped[plan_id].extend(
            ynab.SaveTransactionWithIdOrImportId(id=txn.id, date=today) for txn in txns
        )
    return grouped


async def fetch_pending_income(
    con: aiosqlite.Connection, *, skip_matched: bool = False
) -> dict[str, list[Transaction]]:
    async with con.execute(
        _PENDING_INCOME_SQL, {"skip_matched": int(skip_matched)}
    ) as cur:
        txns = await cur.fetchall()

    txns_by_plan: dict[str, list[Transaction]] = defaultdict(list)
    for txn in txns:
        txns_by_plan[txn["plan_id"]].append(
            Transaction(
                id=txn["id"],
                plan_id=txn["plan_id"],
                account_name=txn["account_name"],
                payee_name=txn["payee_name"],
                amount_formatted=txn["amount_formatted"],
                date=txn["date"],
            )
        )

    return txns_by_plan


def print_found_txns(found_txns: list[Transaction], *, quiet: bool) -> None:
    if quiet:
        return

    table = Table(title="Pending Income Transactions")
    table.add_column("Date")
    table.add_column("Account")
    table.add_column("Payee")
    table.add_column("Amount", justify="right")

    for txn in found_txns:
        table.add_row(
            txn.date, txn.account_name, txn.payee_name or "", txn.amount_formatted
        )

    rich.print(table)


__all__ = [PendingIncomeResult.__name__, pending_income.__name__, run.__name__]
