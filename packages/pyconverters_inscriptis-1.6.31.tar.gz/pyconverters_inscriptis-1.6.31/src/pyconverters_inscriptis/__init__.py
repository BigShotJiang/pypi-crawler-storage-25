"""Sherpa HTML inscriptis converter"""

__version__ = "1.6.31"
