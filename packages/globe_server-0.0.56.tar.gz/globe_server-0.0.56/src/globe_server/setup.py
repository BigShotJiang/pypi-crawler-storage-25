"""
Setup script for Globe Server.

This script handles first-time setup including:
- Creating .env configuration file
- Setting up earth-viz static images
- Initializing the database
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path


def prompt_for_config() -> dict:
    """Interactively prompt user for configuration values."""
    print("\n=== Globe Server Setup ===\n")
    print("Please provide the following configuration values.")
    print("Press Enter to use default values where available.\n")

    config = {}

    # ESP32 Configuration
    print("--- ESP32 Device Configuration ---")
    while True:
        config['ESP32_API_KEY'] = input("ESP32 API Key (required): ").strip()
        if config['ESP32_API_KEY']:
            break
        print("ESP32 API Key is required. Please enter a value.")

    while True:
        config['ESP32_HOSTNAME'] = input("ESP32 Hostname (e.g., globe-71183C, required): ").strip()
        if config['ESP32_HOSTNAME']:
            break
        print("ESP32 Hostname is required. Please enter a value.")

    # WiFi Access Point Configuration
    print("\n--- WiFi Access Point Configuration ---")
    while True:
        config['AP_PASSWORD'] = input("Access Point Password (min 8 chars, required): ").strip()
        if len(config['AP_PASSWORD']) >= 8:
            break
        print("Access Point Password must be at least 8 characters.")

    # Network Configuration
    print("\n--- Network Configuration ---")
    config['NETWORK_SSID'] = input("Default Network SSID (optional): ").strip()
    config['NETWORK_PASSWORD'] = input("Default Network Password (optional): ").strip()

    return config


def write_env_file(config: dict, output_path: Path):
    """Write configuration to .env file."""
    env_content = """# ESP32 Device Communication API Key
ESP32_API_KEY={ESP32_API_KEY}

# ESP32 Device Hostname
ESP32_HOSTNAME={ESP32_HOSTNAME}

# WiFi Access Point Settings (fallback when no network available)
AP_PASSWORD={AP_PASSWORD}

# Current Network Configuration (last known working network)
NETWORK_SSID={NETWORK_SSID}
NETWORK_PASSWORD={NETWORK_PASSWORD}
""".format(**config)

    output_path.write_text(env_content)
    print(f"\n✓ Configuration written to: {output_path}")


def setup_earth_viz():
    """Setup earth-viz by calling its setup script."""
    print("\n--- Setting up Earth-Viz ---")
    try:
        from earth_viz_backend.setup import setup as earth_viz_setup
        print("Running earth-viz setup (will use GLOBE_DATA_DIR env var)...")
        earth_viz_setup()
        print("✓ Earth-Viz setup complete")
    except ImportError:
        print("⚠ Warning: earth-viz-backend not installed, skipping earth-viz setup")
    except Exception as e:
        print(f"⚠ Warning: Earth-Viz setup failed: {e}")


def install_service():
    """Install the startup script and systemd service, then enable it."""
    data_dir = Path.home() / ".globe-server"
    data_dir.mkdir(parents=True, exist_ok=True)

    # Locate bundled deploy files
    deploy_dir = Path(__file__).parent / "deploy"
    startup_src = deploy_dir / "globe-server-startup.sh"
    service_src = deploy_dir / "globe-server.service"

    # Copy startup script
    startup_dst = data_dir / "globe-server-startup.sh"
    shutil.copy2(startup_src, startup_dst)
    startup_dst.chmod(0o755)
    print(f"✓ Startup script installed to: {startup_dst}")

    # Copy service file (requires sudo)
    service_dst = Path("/etc/systemd/system/globe-server.service")
    try:
        shutil.copy2(service_src, service_dst)
        print(f"✓ Service file installed to: {service_dst}")
    except PermissionError:
        print(f"✗ Permission denied writing to {service_dst}")
        raise

    # Reload systemd and enable
    for cmd in [
        ["systemctl", "daemon-reload"],
        ["systemctl", "enable", "globe-server"],
        ["systemctl", "start", "globe-server"],
    ]:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"✗ Failed: {' '.join(cmd)}")
            print(result.stderr)
            sys.exit(1)
        print(f"✓ {' '.join(cmd)}")

    print("\n✓ Globe Server service installed and started.")
    print("  Check status with: sudo systemctl status globe-server")
    print("  Follow logs with:  journalctl -u globe-server -f")


def setup():
    """Main setup function."""
    # Globe Server data directory - always use home directory
    data_dir = Path.home() / ".globe-server"

    # Set env var so earth-viz uses the same location
    os.environ['GLOBE_DATA_DIR'] = str(data_dir)

    print(f"\nGlobe Server data directory: {data_dir}")

    # Create data directory structure
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "media" / "Images").mkdir(parents=True, exist_ok=True)
    (data_dir / "media" / "Videos").mkdir(parents=True, exist_ok=True)
    (data_dir / "updates" / "FPGA").mkdir(parents=True, exist_ok=True)
    (data_dir / "updates" / "ESP32").mkdir(parents=True, exist_ok=True)
    (data_dir / "updates" / "server").mkdir(parents=True, exist_ok=True)
    (data_dir / "logs").mkdir(exist_ok=True)
    (data_dir / "static-images").mkdir(exist_ok=True)
    print("✓ Created directory structure")

    # Interactive config
    env_path = data_dir / ".env"
    config = prompt_for_config()
    write_env_file(config, env_path)

    # Setup earth-viz
    setup_earth_viz()

    # Install systemd service
    print("\n--- Installing systemd service ---")
    try:
        install_service()
    except (SystemExit, PermissionError):
        print("\n  To install the service manually, run:")
        print("  sudo globe-server-setup --install-service")

    print("\n" + "=" * 50)
    print("✓ Globe Server setup complete!")
    print("=" * 50)
    print(f"\nData directory: {data_dir}")
    print(f"Configuration file: {env_path}")
    print()


def main():
    """Entry point for globe-server-setup command."""
    try:
        setup()
    except KeyboardInterrupt:
        print("\n\nSetup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Setup failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
