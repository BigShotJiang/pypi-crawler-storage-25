from prompt_toolkit.completion import Completion

from work_tracker.command.command_handler import CommandHandlerResult, CommandHandler
from work_tracker.command.common import CommandArgument, CompletionCandidate
from work_tracker.common import Date, ReadonlyAppState, Mode, find_first_not_fulfilling, DayType
from work_tracker.config import Config
from work_tracker.error import CommandErrorInvalidArgumentCount, CommandErrorInvalidDate, CommandErrorInvalidMode


class ClearHandler(CommandHandler):
    @classmethod
    def get_completions(cls, typed_words: list[str], last_word: str, in_subcommand_mode: bool) -> list[Completion | CompletionCandidate]:
        return []

    def handle(self, dates: list[Date], date_count: int, arguments: list[CommandArgument], argument_count: int, state: ReadonlyAppState) -> CommandHandlerResult:
        if date_count == 0 and argument_count == 0:
            match state.mode:
                case Mode.Today | Mode.Day:
                    self._handle_day(state.active_date)
                case Mode.Month:
                    self._handle_month(state.active_date)
                case _:
                    return CommandHandlerResult(undoable=False, error=CommandErrorInvalidMode(self.command_name, mode=state.mode))
            return CommandHandlerResult(undoable=True)
        elif date_count != 0 and argument_count == 0:
            if invalid_date := find_first_not_fulfilling(dates, lambda date: date.is_day_date() or date.is_month_date()):
                return CommandHandlerResult(undoable=False, error=CommandErrorInvalidDate(self.command_name, received_date=invalid_date))

            for date in dates:
                if date.is_day_date():
                    self._handle_day(date.fill_with(state.active_date))
                elif date.is_month_date():
                    self._handle_month(date.fill_with(state.active_date))
            return CommandHandlerResult(undoable=True)
        else: # argument_count != 0
            return CommandHandlerResult(undoable=False, error=CommandErrorInvalidArgumentCount(self.command_name, received_argument_count=argument_count))

    def _handle_day(self, date: Date):
        date = date.fill_with_today().to_day_date()
        if self.data.calendar.is_working_day(date.to_datetime()):
            day_type = DayType.WORKDAY
        elif self.data.calendar.is_holiday(date.to_datetime()):
            day_type = DayType.HOLIDAY
        else:
            day_type = DayType.WEEKEND
        self.data.day[date].reset(day_type=day_type)

    def _handle_month(self, date: Date):
        date = date.fill_with_today().to_month_date()
        for day in date.days_in_a_month():
            self._handle_day(day)
        self.data.month[date].fte = Config.data.command.fte.default_value
        self.data.month[date].remote_work_ratio = Config.data.command.rwr.default_value
        new_target_minutes_total: int = sum([480 * self.data.month[date].fte if self.data.day[day].day_type == DayType.WORKDAY else 0 for day in date.days_in_a_month()])
        self.data.month[date].target_minutes = new_target_minutes_total
