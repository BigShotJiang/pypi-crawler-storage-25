import datetime

from prompt_toolkit.completion import Completion

from work_tracker.command.command_handler import CommandHandlerResult, CommandHandler
from work_tracker.command.common import CommandArgument, TimeArgument, CompletionCandidate, CompletionHint
from work_tracker.common import Date, ReadonlyAppState, DayData, Time, Mode, find_first_not_fulfilling
from work_tracker.error import CommandErrorInvalidArgumentCount, CommandErrorInvalidMode, CommandErrorInvalidDate


class StartHandler(CommandHandler):
    @classmethod
    def get_completions(cls, typed_words: list[str], last_word: str, in_subcommand_mode: bool) -> list[Completion | CompletionCandidate]:
        if len(typed_words) == 0:
            return cls.get_fitting_completions([CompletionCandidate("8:00", "example start hour"), CompletionCandidate("9:00", "example start hour"), CompletionCandidate(CompletionHint.Chain)], last_word)
        return []

    def handle(self, dates: list[Date], date_count: int, arguments: list[CommandArgument], argument_count: int, state: ReadonlyAppState) -> CommandHandlerResult:
        if date_count == 0 and argument_count == 0:
            match state.mode:
                case Mode.Today | Mode.Day:
                    pass
                case _:
                    return CommandHandlerResult(undoable=False, error=CommandErrorInvalidMode(self.command_name, mode=state.mode))

            self._handle_day(state.active_date)
            return CommandHandlerResult(undoable=True)
        elif date_count == 0 and argument_count == 1: # TODO handle if end time is before start time
            match state.mode:
                case Mode.Today | Mode.Day:
                    pass
                case _:
                    return CommandHandlerResult(undoable=False, error=CommandErrorInvalidMode(self.command_name, mode=state.mode))

            self._handle_day(state.active_date, arguments[0])
            return CommandHandlerResult(undoable=True)
        elif date_count != 0 and argument_count == 0:
            if invalid_date := find_first_not_fulfilling(dates, lambda date: date.is_day_date()):
                return CommandHandlerResult(undoable=False, error=CommandErrorInvalidDate(self.command_name, received_date=invalid_date))
            for date in dates:
                self._handle_day(date.fill_with(state.active_date))
            return CommandHandlerResult(undoable=True)
        elif date_count != 0 and argument_count == 1:
            if invalid_date := find_first_not_fulfilling(dates, lambda date: date.is_day_date()):
                return CommandHandlerResult(undoable=False, error=CommandErrorInvalidDate(self.command_name, received_date=invalid_date))
            for date in dates:
                self._handle_day(date.fill_with(state.active_date), arguments[0])
            return CommandHandlerResult(undoable=True)
        else: # argument_count > 1
            return CommandHandlerResult(undoable=False, error=CommandErrorInvalidArgumentCount(self.command_name, received_argument_count=argument_count))

    def _handle_day(self, date: Date, time: TimeArgument | None = None):
        date = date.fill_with_today().to_day_date()
        day: DayData = self.data.day[date]
        if time is not None:
            time_start: Time = Time(
                minutes_since_midnight=time.minutes
            )
        else:
            time_now: datetime.datetime = datetime.datetime.now()
            time_start: Time = Time(
                minutes_since_midnight=time_now.hour * 60 + time_now.minute
            )
        day.work_start = time_start

        if day.work_end is not None and day.work_start.minutes_since_midnight > day.work_end.minutes_since_midnight:
            day.work_end = time_start
            day.minutes_at_work = 0
        elif day.work_end is not None:
            day.minutes_at_work = day.work_end.minutes_since_midnight - day.work_start.minutes_since_midnight

        return CommandHandlerResult(undoable=True)
