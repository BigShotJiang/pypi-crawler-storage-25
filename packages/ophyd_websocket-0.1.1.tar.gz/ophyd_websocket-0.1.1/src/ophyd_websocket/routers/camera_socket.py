import asyncio
import json
import time
import numpy as np
import io
import base64
import logging
from PIL import Image

from ophyd import EpicsSignalRO
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
#from fastapi.testclient import TestClient

# Set up logger
logger = logging.getLogger(__name__)

dtype_map = {
    'Int8': np.int8,
    'UInt8': np.uint8,
    'Int16': np.int16,
    'UInt16': np.uint16,
    'Int32': np.int32,
    'UInt32': np.uint32,
    'Int64': np.int64,
    'UInt64': np.uint64,
    'Float32': np.float32,
    'Float64': np.float64 
}

color_mode_enum_list = ['Mono', 'RGB1', 'RGB2', 'RGB3']
data_type_enum_list = ['Int8', 'UInt8', 'Int16', 'UInt16', 'Int32', 'UInt32', 'Int64', 'UInt64', 'Float32', 'Float64']
max_dimension = 2500 #maximum pixel width or height to be sent out. TO DO set this with env var or client message through socket
use_log_normalization = True #default that can be changed by client message through socket

#Defaults correspond to the pvs from ADSimDetector, often the first detector to be tested with new EPICS installations. Allows user to connect to websocket with no args
default_settings_list = [
    {'name': 'startX', 'defaultPV': '13SIM1:cam1:MinX'},
    {'name': 'startY', 'defaultPV': '13SIM1:cam1:MinY'},
    {'name': 'sizeX', 'defaultPV': '13SIM1:cam1:SizeX'},
    {'name': 'sizeY', 'defaultPV': '13SIM1:cam1:SizeY'},
    {'name': 'colorMode', 'defaultPV': '13SIM1:cam1:ColorMode'},
    {'name': 'dataType', 'defaultPV': '13SIM1:cam1:DataType'},
    {'name': 'binX', 'defaultPV': '13SIM1:cam1:BinX'},
    {'name': 'binY', 'defaultPV': '13SIM1:cam1:BinY'}
]
default_image_array_pv = "13SIM1:image1:ArrayData"



router = APIRouter()


@router.websocket("/camera-socket")
async def websocket_endpoint(websocket: WebSocket, num: int | None = None):
    await websocket.accept()

    buffer = asyncio.Queue(maxsize=1000)
    settings_list, image_array_pv = await initialize_settings(websocket)
    logger.debug(f"Initialized settings list: {settings_list}, image array PV: {image_array_pv}")
    settingSignals = await setup_signals(settings_list, websocket)
    if settingSignals == False:
        return
    if not await check_settings_connections(settingSignals, websocket):
        return

    # Reassign the updated enum lists
    global color_mode_enum_list, data_type_enum_list
    color_mode_enum_list, data_type_enum_list = update_enum_lists(settingSignals, color_mode_enum_list, data_type_enum_list)

    def array_cb(value, timestamp, **kwargs):
        if buffer.qsize() >= buffer.maxsize:
            buffer.get_nowait()
        try:
            buffer.put_nowait((value, timestamp, False))
        except asyncio.QueueFull:
            logger.warning("Buffer full, dropping frame")

    def settings_cb(value, timestamp, **kwargs):
        update_dimensions(settingSignals, buffer)


    for key in settingSignals:
        settingSignals[key].subscribe(settings_cb)

    try:
        array_signal = EpicsSignalRO(image_array_pv, name='array_signal')
        array_signal.get()
    except Exception as e:
        await websocket.send_text(json.dumps({'error': str(e)}))
        await websocket.close()
        return

    if not await check_array_connection(array_signal, image_array_pv, websocket):
        return
    array_signal.subscribe(array_cb)

    settings_cb(None, None) #call once to initialize all dimensions prior to loading images
    buffer.put_nowait((array_signal.get(), time.time(), False)) #call once to load the current frame


    await handle_streaming(websocket, buffer)

# Setup and initialization functions

async def initialize_settings(websocket):
    try:
        data = await websocket.receive_text()
        message = json.loads(data)
        logger.info(f"Received initialization message: {message}")
        settings_list = default_settings_list.copy()
        image_array_pv = message.get("imageArray_PV", default_image_array_pv)
        if len(image_array_pv) == 0:
            image_array_pv = default_image_array_pv
            logger.info("Using Defaults for 13SIM1")
            for item in settings_list:
                item['pv'] = message.get(item['name'], item['defaultPV'])
                if len(item['pv']) == 0:
                    item['pv'] = item['defaultPV']
        else:
            #If user provides additional value for startX, startY, etc. then subscribe to those
            #Otherwise if user only provides the imageArray_PV, concatenate the Prefix to default suffixes
            prefix = image_array_pv.split(":")[0]
            for item in settings_list:
                suffix = ":" + item['defaultPV'].split(":")[1] + ":" + item['defaultPV'].split(":")[2]
                logger.debug(f"Using PV: {prefix}{suffix}")
                item['pv'] = message.get(item['name'], prefix+suffix)
                if len(item['pv']) == 0:
                    item['pv'] = item['defaultPV']
        return settings_list, image_array_pv
    except Exception as e:
        await websocket.send_text(json.dumps({'error': str(e)}))
        await websocket.close()
        return None, None

async def setup_signals(settings_list, websocket):
    settingSignals = {}
    try:
        for item in settings_list:
            signal = EpicsSignalRO(item['pv'], name=item['name'])
            signal.get()
            settingSignals[item['name']] = signal
    except Exception as e:
        logger.error(f"Error setting up signals: {e}")
        await websocket.send_text(json.dumps({'error': str(e)}))
        await websocket.close()
        return False
    return settingSignals

async def check_settings_connections(settingSignals, websocket):
    for key, signal in settingSignals.items():
        if not signal.connected:
            logger.error(f"Setting PV {key} not connected")
            await websocket.send_text(json.dumps({'error': f"{key} pv could not connect"}))
            await websocket.close()
            return False
    return True

async def check_array_connection(signal, name, websocket):
    if not signal.connected:
        logger.error(f"Array data PV not connected, exiting")
        await websocket.send_text(json.dumps({'error': f"The {name} pv could not connect"}))
        await websocket.close()
        return False
    return True

def update_enum_lists(settingSignals, color_mode_enum_list, data_type_enum_list):
    #ColorMode and DataType should have an enum_strs attribute containing an array of
    #strings whose index corresponds to the value held by the pv
    #Overwrite the defaults with the actual values, if values don't exist than accept default
    color_mode_enum_list = getattr(settingSignals['colorMode'], 'enum_strs', color_mode_enum_list)
    data_type_enum_list = getattr(settingSignals['dataType'], 'enum_strs', data_type_enum_list)
    return color_mode_enum_list, data_type_enum_list

def update_dimensions(settingSignals, buffer):
    color_mode_value = settingSignals['colorMode'].get()
    data_type_value = settingSignals['dataType'].get()
    tempDimensions = {
        # TO DO: test if this rounding function works to match up with the exact size of array data in bytes
        'x': round((settingSignals['sizeX'].get() - settingSignals['startX'].get())/1),
        'y': round((settingSignals['sizeY'].get() - settingSignals['startY'].get())/1),
        #'x': round((settingSignals['sizeX'].get() - settingSignals['startX'].get())/settingSignals['binX'].get()),
        #'y': round((settingSignals['sizeY'].get() - settingSignals['startY'].get())/settingSignals['binY'].get()),
        'colorMode': color_mode_enum_list[color_mode_value],
        'dataType': data_type_enum_list[data_type_value]
    }
    logger.debug(f"Updated image dimensions: {tempDimensions}")
    buffer.put_nowait((None, time.time(), tempDimensions))

# Main loop for streaming images
async def handle_streaming(websocket, buffer):
    global use_log_normalization  # Use the global variable to toggle normalization
    try:

        # Start a background task to listen for client messages
        async def listen_for_client_messages():
            global use_log_normalization
            while True:
                try:
                    message = await websocket.receive_text()
                    data = json.loads(message)
                    if "toggleLogNormalization" in data:
                        use_log_normalization = data["toggleLogNormalization"]
                        logger.info(f"Log normalization toggled to: {use_log_normalization}")
                        await websocket.send_text(json.dumps({"logNormalization": use_log_normalization}))
                except WebSocketDisconnect:
                    break
                except Exception as e:
                    logger.error(f"Error processing client message: {e}")

        # Run the listener in the background
        asyncio.create_task(listen_for_client_messages())

        while True:
            rawImageArray, timestamp, updatedSettings = await buffer.get()

            if updatedSettings:
                currentSettings = updatedSettings
                await websocket.send_text(json.dumps(currentSettings))
                continue

            height, width, colorMode, dataType = currentSettings['y'], currentSettings['x'], currentSettings['colorMode'], currentSettings['dataType']

            bufferedResult = await asyncio.to_thread(get_buffer, rawImageArray, height, width, colorMode, dataType)
            if isinstance(bufferedResult, Exception):
                logger.warning('Skipping image due to error')
                continue
            else:
                await websocket.send_bytes(bufferedResult.getvalue())

    except WebSocketDisconnect:
        await websocket.close()

def normalize_array_data(array_data, dataType):
    global use_log_normalization
    if not use_log_normalization:
        max_val = array_data.max() if array_data.max() > 0 else 1
        return (array_data / max_val * 255).astype(np.uint8)
    else:
        return log_normalize_to_255(array_data)


def log_normalize_to_255(data: np.ndarray) -> np.ndarray:
    if np.any(data < 0):
        raise ValueError("Input data must be non-negative for log normalization.")
    
    # Avoid log(0) by shifting
    data = data + 1.0

    # Apply logarithm
    log_data = np.log(data)

    # Normalize to 0–255
    log_min = np.min(log_data)
    log_max = np.max(log_data)
    if log_max == log_min:
        normalized = np.zeros_like(log_data)
    else:
        normalized = (log_data - log_min) / (log_max - log_min) * 255

    return normalized.astype(np.uint8)

def reshape_array(array_data, height, width, colorMode):
    if colorMode == 'Mono':
        reshaped_data = array_data.reshape((height, width))
        mode = 'L'  # Grayscale
    elif colorMode == 'RGB1':
        reshaped_data = array_data.reshape((height, width, 3))
        mode = 'RGB'
    elif colorMode == 'RGB2':
        # Reshape to (height, width * 3) and split each row into R, G, B channels
        array_data = array_data.reshape((height, width * 3))
        red = array_data[:, 0:width]
        green = array_data[:, width:2*width]
        blue = array_data[:, 2*width:3*width]
        reshaped_data = np.stack((red, green, blue), axis=-1)
        mode = 'RGB'
    elif colorMode == 'RGB3':
        red = array_data[0:height * width].reshape((height, width))
        green = array_data[height * width:2 * height * width].reshape((height, width))
        blue = array_data[2 * height * width:3 * height * width].reshape((height, width))
        reshaped_data = np.stack((red, green, blue), axis=-1)
        mode = 'RGB'
    else:
        raise ValueError(f"Unsupported color mode: {colorMode}")
    
    return reshaped_data, mode

def get_buffer(rawImageArray, height, width, colorMode, dataType):
    try:
        array_data = np.array(rawImageArray, dtype=dtype_map[dataType])
        array_data = normalize_array_data(array_data, dataType)
        array_data, mode = reshape_array(array_data, height, width, colorMode)
    except Exception as e:
        logger.error(f"Error formatting array data: {e}")
        return e

    try:
        if array_data.shape[0] > max_dimension or array_data.shape[1] > max_dimension:
            new_size = (min(array_data.shape[1], max_dimension), min(array_data.shape[0], max_dimension))
            img = Image.fromarray(array_data, mode).resize(new_size, Image.LANCZOS)
        else:
            img = Image.fromarray(array_data, mode)
        buffered = io.BytesIO()
        img.save(buffered, format="JPEG", quality=100)
        return buffered
    except Exception as e:
        logger.error(f"Error creating image buffer: {e}")
        return e