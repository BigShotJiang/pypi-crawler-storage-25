"""
Fabric workspace items.

Provides base classes and all workspace item types
(Pipeline, Lakehouse, Notebook, Environment, Libraries).

Organization:
- _shared/: Base classes (Item, ItemAccessor) and utilities
- permissions/: OneLake data access security (ABAC)
- Individual modules: Specific item types
"""

# Base classes and factory
# Enums for permissions
from .._shared.enums import ItemAccess, MemberType, ReadWrite
from ._shared import Item, ItemAccessor, fromJson
from .environment import Environment, EnvironmentAccessor
from .lakehouse import Lakehouse, LakehouseAccessor
from .libraries import Libraries
from .notebook import Notebook, NotebookAccessor
from .permissions.members import EntraMember, FabricItem, Member

# OneLake data access security (ABAC)
from .permissions.roles import Role, RoleAccessor
from .permissions.rules import ColumnLevelSecurity, RowLevelSecurity, Rule

# Item types
from .pipeline import Pipeline, PipelineAccessor
from .variablelibrary import (
    ItemReference,
    Variable,
    VariableAccessor,
    VariableLibrary,
    VariableLibraryAccessor,
)

__all__ = [
    # Base infrastructure
    "Item",
    "ItemAccessor",
    "fromJson",
    # Item types
    "Pipeline",
    "PipelineAccessor",
    "Lakehouse",
    "LakehouseAccessor",
    "Notebook",
    "NotebookAccessor",
    "Environment",
    "EnvironmentAccessor",
    "VariableLibrary",
    "VariableLibraryAccessor",
    "VariableAccessor",
    "Variable",
    "ItemReference",
    "Libraries",
    # OneLake data access security (ABAC)
    "Role",
    "RoleAccessor",
    "Rule",
    "RowLevelSecurity",
    "ColumnLevelSecurity",
    "Member",
    "EntraMember",
    "FabricItem",
    # Enums for permissions
    "ReadWrite",
    "ItemAccess",
    "MemberType",
]
