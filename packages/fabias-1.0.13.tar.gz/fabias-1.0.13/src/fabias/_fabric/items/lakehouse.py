"""
Fabric Lakehouse item.

Provides the Lakehouse class for accessing Lakehouse metadata and OneLake data access security.
"""

from typing import TYPE_CHECKING, List, Optional, Union, cast, overload

from ._shared import Item, ItemAccessor

if TYPE_CHECKING:
    pass


class LakehouseAccessor(ItemAccessor):
    """Accessor for lakehouse operations."""

    ITEM_TYPE = "Lakehouse"
    ITEM_CLASS: Optional[type] = None  # Set after Lakehouse definition

    @overload
    def __call__(self, identifier: str) -> "Lakehouse": ...

    @overload
    def __call__(self, identifier: None = None) -> List["Lakehouse"]: ...

    def __call__(self, identifier: Optional[str] = None) -> Union["Lakehouse", List["Lakehouse"]]:
        """Get lakehouse by name/ID or list all lakehouses."""
        result = super().__call__(identifier)
        if isinstance(result, list):
            return cast(List["Lakehouse"], result)
        return cast("Lakehouse", result)

    def add(
        self, name: str, description: Optional[str] = None, folder_id: Optional[str] = None
    ) -> "Lakehouse":
        """Create new lakehouse."""
        return cast("Lakehouse", super().add(name, description, folder_id))


class Lakehouse(Item):
    """
    Represents a Microsoft Fabric Lakehouse.

    Provides access to lakehouse metadata and OneLake data access security (ABAC).
    Lakehouses are Delta Lake storage containers used for analytics workloads.

    Examples:
        >>> lakehouse = workspace.lakehouse("Analytics")
        >>> print(f"Lakehouse ID: {lakehouse.id}")
        >>>
        >>> # Manage data access roles (ABAC)
        >>> roles = lakehouse.accessRoles()
        >>> role = lakehouse.accessRole("DefaultReader")
    """

    ITEM_TYPE = "Lakehouse"
    ITEM_TYPE_DISPLAY = "Lakehouse"

    def __repr__(self) -> str:
        return f"Lakehouse(id={self.id}, name={self.name!r})"


# Set class reference after definition
LakehouseAccessor.ITEM_CLASS = Lakehouse
