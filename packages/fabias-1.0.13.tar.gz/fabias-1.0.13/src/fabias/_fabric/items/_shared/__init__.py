"""
Shared infrastructure for workspace items.

This module contains base classes and utilities used by all workspace item types.
"""

from .base import Item, ItemAccessor, fromJson

__all__ = [
    "Item",
    "ItemAccessor",
    "fromJson",
]
