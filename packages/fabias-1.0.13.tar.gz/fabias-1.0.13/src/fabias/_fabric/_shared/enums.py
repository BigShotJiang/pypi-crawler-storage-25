"""
Enums for Fabric API values.

Provides type-safe enums for API parameters while maintaining
string compatibility for flexibility.

All enums follow Microsoft's official API documentation:
https://learn.microsoft.com/en-us/rest/api/fabric/
"""

from enum import Enum

# ============================================================================
# Git Enums
# ============================================================================


class GitProviderType(str, Enum):
    """
    Git provider type enumeration.

    Used when connecting a workspace to a Git repository.
    Additional provider types may be added over time.

    Attributes:
        AZURE_DEVOPS: Azure DevOps provider
        GITHUB: GitHub provider
    """

    AZURE_DEVOPS = "AzureDevOps"
    GITHUB = "GitHub"


class GitCredentialsSource(str, Enum):
    """
    Git credentials source enumeration.

    Specifies how Git credentials are obtained.
    Additional sources may be added over time.

    Attributes:
        CONFIGURED_CONNECTION: Credentials obtained through a configured connection
        AUTOMATIC: Credentials automatically obtained by the system
        NONE: No credentials configured
    """

    CONFIGURED_CONNECTION = "ConfiguredConnection"
    AUTOMATIC = "Automatic"
    NONE = "None"


class InitializationStrategy(str, Enum):
    """
    Git initialization strategy when content exists on both remote and workspace sides.

    Used in Git.initialize() to determine conflict resolution strategy.
    """

    NONE = "None"
    PREFER_REMOTE = "PreferRemote"
    PREFER_WORKSPACE = "PreferWorkspace"


class RequiredAction(str, Enum):
    """
    Required action after Git initialization completes.

    Indicates what sync operation should be performed next.
    """

    NONE = "None"
    UPDATE_FROM_GIT = "UpdateFromGit"
    COMMIT_TO_GIT = "CommitToGit"


class WorkspaceRole(str, Enum):
    """
    Workspace role assignment types.

    Used when managing workspace role assignments.
    """

    ADMIN = "Admin"
    MEMBER = "Member"
    CONTRIBUTOR = "Contributor"
    VIEWER = "Viewer"


class ConnectionRole(str, Enum):
    """
    Connection role assignment types.

    Used when managing connection role assignments.
    """

    USER = "User"
    USER_WITH_RESHARE = "UserWithReshare"
    OWNER = "Owner"


class PrincipalType(str, Enum):
    """
    Principal types for role assignments.

    Identifies the type of security principal being assigned a role.
    """

    USER = "User"
    GROUP = "Group"
    SERVICE_PRINCIPAL = "ServicePrincipal"


# ============================================================================
# Connection Enums
# ============================================================================


class ConnectivityType(str, Enum):
    """
    Connection connectivity type enumeration.

    Specifies how a connection connects to data sources.
    Additional connectivity types may be added over time.

    Attributes:
        SHAREABLE_CLOUD: Connection through the cloud that can be shared
        PERSONAL_CLOUD: Connection through the cloud that cannot be shared
        ON_PREMISES_GATEWAY: Connection through an on-premises data gateway
        ON_PREMISES_GATEWAY_PERSONAL: Connection through a personal on-premises data gateway
        VIRTUAL_NETWORK_GATEWAY: Connection through a virtual network data gateway
        AUTOMATIC: Connection through the cloud using implicit data connection (SSO scenarios)
        NONE: Connection is not bound
    """

    SHAREABLE_CLOUD = "ShareableCloud"
    PERSONAL_CLOUD = "PersonalCloud"
    ON_PREMISES_GATEWAY = "OnPremisesGateway"
    ON_PREMISES_GATEWAY_PERSONAL = "OnPremisesGatewayPersonal"
    VIRTUAL_NETWORK_GATEWAY = "VirtualNetworkGateway"
    AUTOMATIC = "Automatic"
    NONE = "None"


class PrivacyLevel(str, Enum):
    """
    Connection privacy level enumeration.

    Specifies the privacy level setting of a connection.
    Additional privacy levels may be added over time.

    Attributes:
        NONE: No privacy level configured
        PRIVATE: Sensitive/confidential data, restricted to authorized users
        ORGANIZATIONAL: Can fold into private and other organizational connections
        PUBLIC: Files, internet, workbook data - visible to everyone
    """

    NONE = "None"
    PRIVATE = "Private"
    ORGANIZATIONAL = "Organizational"
    PUBLIC = "Public"


class ConnectionEncryption(str, Enum):
    """
    Connection encryption type enumeration.

    Specifies the encryption setting used during connection.
    Additional encryption values may be added over time.

    Attributes:
        ENCRYPTED: Connection uses encryption
        ANY: Tries encrypted first, falls back to unencrypted
        NOT_ENCRYPTED: Connection does not use encryption
    """

    ENCRYPTED = "Encrypted"
    ANY = "Any"
    NOT_ENCRYPTED = "NotEncrypted"


class SingleSignOnType(str, Enum):
    """
    Single sign-on type enumeration.

    Specifies the SSO authentication method.
    Additional SSO types may be added over time.

    Attributes:
        NONE: No single sign-on
        KERBEROS: Kerberos SSO
        MICROSOFT_ENTRA_ID: Microsoft Entra ID SSO
        SAML: Security Assertion Markup Language SSO
        KERBEROS_DIRECT_QUERY_AND_REFRESH: Kerberos DirectQuery and Refresh SSO
    """

    NONE = "None"
    KERBEROS = "Kerberos"
    MICROSOFT_ENTRA_ID = "MicrosoftEntraID"
    SAML = "SecurityAssertionMarkupLanguage"
    KERBEROS_DIRECT_QUERY_AND_REFRESH = "KerberosDirectQueryAndRefresh"


# ============================================================================
# Operation Enums
# ============================================================================


class OperationStatus(str, Enum):
    """
    Long-running operation status enumeration.

    Represents the current state of an operation.
    Additional statuses may be added over time.

    Attributes:
        UNDEFINED: Status is undefined
        NOT_STARTED: Operation not started
        RUNNING: Operation is running
        SUCCEEDED: Operation completed successfully
        FAILED: Operation failed
    """

    UNDEFINED = "Undefined"
    NOT_STARTED = "NotStarted"
    RUNNING = "Running"
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"


# ============================================================================
# Item Type Enums
# ============================================================================


class ItemType(str, Enum):
    """
    Workspace item type enumeration.

    Specifies the type of item in a workspace.
    Additional item types may be added over time.

    Attributes:
        DASHBOARD: PowerBI dashboard
        REPORT: PowerBI report
        SEMANTIC_MODEL: PowerBI semantic model
        PAGINATED_REPORT: PowerBI paginated report
        DATAMART: PowerBI datamart
        LAKEHOUSE: A lakehouse
        EVENTHOUSE: An eventhouse
        ENVIRONMENT: An environment
        KQL_DATABASE: A KQL database
        KQL_QUERYSET: A KQL queryset
        KQL_DASHBOARD: A KQL dashboard
        DATA_PIPELINE: A data pipeline
        NOTEBOOK: A notebook
        SPARK_JOB_DEFINITION: A spark job definition
        ML_EXPERIMENT: A machine learning experiment
        ML_MODEL: A machine learning model
        WAREHOUSE: A warehouse
        EVENTSTREAM: An eventstream
        SQL_ENDPOINT: An SQL endpoint
        MIRRORED_WAREHOUSE: A mirrored warehouse
        MIRRORED_DATABASE: A mirrored database
        REFLEX: A Reflex
        GRAPHQL_API: An API for GraphQL item
        MOUNTED_DATA_FACTORY: A MountedDataFactory
        SQL_DATABASE: A SQLDatabase
        COPY_JOB: A Copy job
        VARIABLE_LIBRARY: A VariableLibrary
        DATAFLOW: A Dataflow
        APACHE_AIRFLOW_JOB: An ApacheAirflowJob
        WAREHOUSE_SNAPSHOT: A Warehouse snapshot
        DIGITAL_TWIN_BUILDER: A DigitalTwinBuilder
        DIGITAL_TWIN_BUILDER_FLOW: A Digital Twin Builder Flow
        MIRRORED_AZURE_DATABRICKS_CATALOG: A mirrored azure databricks catalog
        MAP: A Map
        ANOMALY_DETECTOR: An Anomaly Detector
        USER_DATA_FUNCTION: A User Data Function
        GRAPH_MODEL: A GraphModel
        GRAPH_QUERY_SET: A Graph QuerySet
        SNOWFLAKE_DATABASE: A Snowflake Database
        OPERATIONS_AGENT: A OperationsAgent
        COSMOS_DB_DATABASE: A Cosmos DB Database
        ONTOLOGY: An Ontology
        EVENT_SCHEMA_SET: An EventSchemaSet
    """

    DASHBOARD = "Dashboard"
    REPORT = "Report"
    SEMANTIC_MODEL = "SemanticModel"
    PAGINATED_REPORT = "PaginatedReport"
    DATAMART = "Datamart"
    LAKEHOUSE = "Lakehouse"
    EVENTHOUSE = "Eventhouse"
    ENVIRONMENT = "Environment"
    KQL_DATABASE = "KQLDatabase"
    KQL_QUERYSET = "KQLQueryset"
    KQL_DASHBOARD = "KQLDashboard"
    DATA_PIPELINE = "DataPipeline"
    NOTEBOOK = "Notebook"
    SPARK_JOB_DEFINITION = "SparkJobDefinition"
    ML_EXPERIMENT = "MLExperiment"
    ML_MODEL = "MLModel"
    WAREHOUSE = "Warehouse"
    EVENTSTREAM = "Eventstream"
    SQL_ENDPOINT = "SQLEndpoint"
    MIRRORED_WAREHOUSE = "MirroredWarehouse"
    MIRRORED_DATABASE = "MirroredDatabase"
    REFLEX = "Reflex"
    GRAPHQL_API = "GraphQLApi"
    MOUNTED_DATA_FACTORY = "MountedDataFactory"
    SQL_DATABASE = "SQLDatabase"
    COPY_JOB = "CopyJob"
    VARIABLE_LIBRARY = "VariableLibrary"
    DATAFLOW = "Dataflow"
    APACHE_AIRFLOW_JOB = "ApacheAirflowJob"
    WAREHOUSE_SNAPSHOT = "WarehouseSnapshot"
    DIGITAL_TWIN_BUILDER = "DigitalTwinBuilder"
    DIGITAL_TWIN_BUILDER_FLOW = "DigitalTwinBuilderFlow"
    MIRRORED_AZURE_DATABRICKS_CATALOG = "MirroredAzureDatabricksCatalog"
    MAP = "Map"
    ANOMALY_DETECTOR = "AnomalyDetector"
    USER_DATA_FUNCTION = "UserDataFunction"
    GRAPH_MODEL = "GraphModel"
    GRAPH_QUERY_SET = "GraphQuerySet"
    SNOWFLAKE_DATABASE = "SnowflakeDatabase"
    OPERATIONS_AGENT = "OperationsAgent"
    COSMOS_DB_DATABASE = "CosmosDBDatabase"
    ONTOLOGY = "Ontology"
    EVENT_SCHEMA_SET = "EventSchemaSet"


# ============================================================================
# Permission Enums
# ============================================================================
class ReadWrite(str, Enum):
    """
    ReadWrite type enumeration.

    Specifies the level of permissions to an item.
    Additional item types may be added over time.

    Attributes:
        READ: read-only access
        READWRITE: Read and write access
    """

    READ = "Read"
    READWRITE = "ReadWrite"


class ItemAccess(str, Enum):
    """
    Item access permission enumeration.

    Specifies individual access permissions that can be combined in lists.
    Use in List[ItemAccess] for members that can have multiple permissions.

    Attributes:
        READ: Item Access Read
        WRITE: Item Access Write
        RESHARE: Item Access Reshare
        EXPLORE: Item Access Explore
        EXECUTE: Item Access Execute
        READALL: Item Access ReadAll

    Examples:
        >>> # Single permission
        >>> member = Member(memberType=MemberType.ENTRA, access=[ItemAccess.READ])
        >>>
        >>> # Multiple permissions
        >>> member = Member(
        ...     memberType=MemberType.ENTRA,
        ...     access=[ItemAccess.READ, ItemAccess.WRITE, ItemAccess.EXECUTE]
        ... )
    """

    READ = "Read"
    WRITE = "Write"
    RESHARE = "Reshare"
    EXPLORE = "Explore"
    EXECUTE = "Execute"
    READALL = "ReadAll"


class MemberType(str, Enum):
    """
    Member type enumeration.

    Specifies the type of member for permissions.
    Additional member types may be added over time.

    Attributes:
        ENTRA: microsoftEntraMember Type
        FABRIC: fabricItemMember type
    """

    ENTRA = "Entra"
    FABRIC = "Fabric"


# ============================================================================
# Spark Enums
# ============================================================================


class PoolType(str, Enum):
    """
    Spark pool type enumeration.

    Identifies the type of Spark pool assigned as the default for a workspace.

    Attributes:
        WORKSPACE: Starter pool provisioned at the workspace level
        CAPACITY: Custom pool provisioned at the capacity level
    """

    WORKSPACE = "Workspace"
    CAPACITY = "Capacity"


# ============================================================================
# Notebook Enums
# ============================================================================
class NotebookFormat(str, Enum):
    """
    Notebook format enumeration.

    Specifies the format of a notebook.
    Additional formats may be added over time.

    Attributes:
        IPYN: Databricks notebook format
        GITSOURCE: Fabric Git source format
    """

    IPYN = "ipynb"
    GITSOURCE = "fabricGitSource"
