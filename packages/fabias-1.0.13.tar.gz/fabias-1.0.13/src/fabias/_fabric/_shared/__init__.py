"""
Base/supporting modules for Fabric API.

Provides shared functionality used across Fabric resources:
- Enums: Type-safe enumerations
- RoleAssignments: Base classes for RBAC patterns

Note: Job (long-running operation tracking) is now in fabias.core
"""

from .enums import (
    ConnectionEncryption,
    ConnectionRole,
    # Connection enums
    ConnectivityType,
    GitCredentialsSource,
    # Git enums
    GitProviderType,
    InitializationStrategy,
    ItemAccess,
    # Item enums
    ItemType,
    MemberType,
    NotebookFormat,
    # Operation enums
    OperationStatus,
    PoolType,
    PrincipalType,
    PrivacyLevel,
    # Permissions
    ReadWrite,
    RequiredAction,
    SingleSignOnType,
    # Spark enums
    # Role assignment enums
    WorkspaceRole,
)
from .role_assignments import BaseRoleAssignment, BaseRoleAssignmentAccessor

__all__ = [
    # Classes
    "BaseRoleAssignment",
    "BaseRoleAssignmentAccessor",
    # Git enums
    "GitProviderType",
    "GitCredentialsSource",
    "InitializationStrategy",
    "RequiredAction",
    # Role assignment enums
    "WorkspaceRole",
    "ConnectionRole",
    "PrincipalType",
    # Connection enums
    "ConnectivityType",
    "PrivacyLevel",
    "ConnectionEncryption",
    "SingleSignOnType",
    # Operation enums
    "OperationStatus",
    # Item enums
    "ItemType",
    # Permissions
    "ReadWrite",
    "ItemAccess",
    "MemberType",
    # Notebook formats
    "NotebookFormat",
    # Spark enums
    "PoolType",
]
