"""
Admin-level Fabric resources.

Provides access to tenant-wide and admin-level resources:
- Capacity: Capacity management and workspace assignments
- Tenant: Tenant settings and configurations

Note: These resources require elevated permissions (Fabric Administrator).
"""

from .capacity import CapacitiesAccessor, Capacity
from .tenant import ActivityEvent, Tenant

__all__ = [
    "ActivityEvent",
    "Capacity",
    "CapacitiesAccessor",
    "Tenant",
]
