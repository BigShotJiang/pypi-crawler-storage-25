"""
Adaptive Card container class.

Provides the main Adaptive class that wraps card body, actions,
and metadata for Microsoft Adaptive Cards.
"""

import json
from typing import Any, Dict, List, Optional

from .elements import CardElement


class Adaptive(CardElement):
    """
    Represents a Microsoft Adaptive Card.

    Adaptive Cards are platform-agnostic UI snippets that can be
    rendered in Microsoft Teams, Outlook, and other Microsoft 365 apps.

    Attributes:
        type (str): Always "AdaptiveCard"
        version (str): Adaptive Card schema version
        body (list): List of card elements to display
        actions (list): List of interactive actions
        speak (str): Text-to-speech content for accessibility

    Examples:
        Simple card:

        >>> from fabias.cards import Adaptive, TextBlock
        >>> card = Adaptive(body=[
        ...     TextBlock("Hello!", weight="Bolder", size="Large"),
        ...     TextBlock("Welcome to fabias!")
        ... ])

        Card with actions:

        >>> from fabias.cards import Adaptive, TextBlock, ActionOpenUrl
        >>> card = Adaptive(
        ...     body=[TextBlock("Check out our docs")],
        ...     actions=[ActionOpenUrl("icon:Book", "Docs", "https://docs.example.com")]
        ... )

        Send via Teams:

        >>> client = GraphClient()
        >>> channel = client.team().channel()
        >>> channel.message(card)
    """

    def __init__(
        self,
        body: Optional[List] = None,
        actions: Optional[List] = None,
        speak: Optional[str] = None,
        version: str = "1.5",
    ):
        """
        Initialize an Adaptive Card.

        Args:
            body: List of card elements to display
            actions: List of actions available on the card
            speak: Text to be spoken for accessibility
            version: Adaptive Card schema version (default "1.5")
        """
        self.type = "AdaptiveCard"
        self.version = version
        self.body = body if body is not None else []
        self.actions = actions if actions is not None else []
        if speak:
            self.speak = speak

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert card to dictionary, adding the $schema field.

        Returns:
            dict: Dictionary representation with schema URL
        """
        result = super().to_dict()
        result["$schema"] = "https://adaptivecards.io/schemas/adaptive-card.json"
        return result

    def content(self) -> str:
        """
        Return JSON string representation of the card.

        This is used when sending cards via the Graph API, which
        expects the card content as a JSON string.

        Returns:
            str: JSON-serialized card content
        """
        return json.dumps(self.toDict())

    def addElement(self, element: CardElement) -> "Adaptive":
        """
        Add an element to the card body.

        Args:
            element: Card element to add

        Returns:
            Adaptive: Self for method chaining
        """
        self.body.append(element)
        return self

    def addAction(self, action: CardElement) -> "Adaptive":
        """
        Add an action to the card.

        Args:
            action: Action element to add

        Returns:
            Adaptive: Self for method chaining
        """
        self.actions.append(action)
        return self

    def __repr__(self) -> str:
        return f"Adaptive(body={len(self.body)} elements, actions={len(self.actions)})"
