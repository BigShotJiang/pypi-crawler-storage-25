"""
Adaptive Card action classes.

Provides action elements that can be added to Adaptive Cards
for interactivity.
"""

from typing import Optional

from .cards import Adaptive
from .elements import CardElement


class ActionElement(CardElement):
    """
    Base class for action elements.

    All action types inherit from this class which provides
    common properties like type, title, and icon.
    """

    def __init__(self, action_type: str, icon: str, title: str):
        """
        Initialize an action element.

        Args:
            action_type: Action type string (e.g., "Action.OpenUrl")
            icon: Icon URL or icon reference
            title: Action button title
        """
        self.type = action_type
        self.title = title
        self.iconUrl = icon


class ActionShowCard(ActionElement):
    """
    Action that shows a nested card when clicked.

    Useful for progressive disclosure of information, allowing
    users to expand additional details on demand.

    Examples:
        >>> details_card = Adaptive(body=[
        ...     TextBlock("Additional details here...")
        ... ])
        >>> action = ActionShowCard(
        ...     icon="icon:Info",
        ...     title="Show Details",
        ...     card=details_card
        ... )
    """

    def __init__(self, icon: str, title: str, card: Adaptive):
        """
        Initialize a ShowCard action.

        Args:
            icon: Icon URL or icon reference (e.g., "icon:Info")
            title: Action button title
            card: Adaptive card to show when clicked
        """
        super().__init__("Action.ShowCard", icon, title)
        self.card = card


class ActionOpenUrl(ActionElement):
    """
    Action that opens a URL when clicked.

    Opens the specified URL in a new browser tab or the
    platform's default handler.

    Examples:
        >>> action = ActionOpenUrl(
        ...     icon="icon:Link",
        ...     title="Learn More",
        ...     url="https://example.com/docs"
        ... )
    """

    def __init__(self, icon: str, title: str, url: str, icon_url: Optional[str] = None):
        """
        Initialize an OpenUrl action.

        Args:
            icon: Icon URL or icon reference (e.g., "icon:Link")
            title: Action button title
            url: URL to open when clicked
            icon_url: Deprecated - use icon parameter
        """
        super().__init__("Action.OpenUrl", icon, title)
        self.url = url


class ActionSubmit(ActionElement):
    """
    Action that submits data when clicked.

    Sends the card's input values to the message handler.
    Typically used with input elements.

    Examples:
        >>> action = ActionSubmit(
        ...     icon="icon:Send",
        ...     title="Submit",
        ...     data={"action": "approve"}
        ... )
    """

    def __init__(self, icon: str, title: str, data: Optional[dict] = None):
        """
        Initialize a Submit action.

        Args:
            icon: Icon URL or icon reference
            title: Action button title
            data: Data to submit (merged with input values)
        """
        super().__init__("Action.Submit", icon, title)
        if data:
            self.data = data


class ActionExecute(ActionElement):
    """
    Action that invokes a bot or function.

    Similar to Submit but designed for Universal Actions
    that can work across different clients.

    Examples:
        >>> action = ActionExecute(
        ...     icon="icon:Play",
        ...     title="Run",
        ...     verb="runProcess",
        ...     data={"processId": "123"}
        ... )
    """

    def __init__(self, icon: str, title: str, verb: str, data: Optional[dict] = None):
        """
        Initialize an Execute action.

        Args:
            icon: Icon URL or icon reference
            title: Action button title
            verb: Action verb for the handler
            data: Data to send with the action
        """
        super().__init__("Action.Execute", icon, title)
        self.verb = verb
        if data:
            self.data = data
