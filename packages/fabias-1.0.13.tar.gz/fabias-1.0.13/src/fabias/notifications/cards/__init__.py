"""
Microsoft Adaptive Cards module.

Provides classes for building Adaptive Cards that can be sent via Teams
or other Microsoft 365 services.

Classes:
- Adaptive: Main card container
- TextBlock: Text display element
- Image: Image display element
- Column/ColumnSet: Multi-column layouts
- Table: Tabular data display
- ActionShowCard/ActionOpenUrl: Interactive actions
"""

from .actions import ActionOpenUrl, ActionShowCard
from .cards import Adaptive
from .elements import Badge, CardElement, Column, ColumnSet, Image, Table, TextBlock

__all__ = [
    "CardElement",
    "TextBlock",
    "Image",
    "Badge",
    "Column",
    "ColumnSet",
    "Table",
    "Adaptive",
    "ActionShowCard",
    "ActionOpenUrl",
]
