"""
Notifications module for fabias.

Provides interfaces for sending alerts and notifications to various channels.

Available modules:
    - teams: Microsoft Teams channel messaging
    - cards: Adaptive Card formatting for rich notifications

Usage:
    >>> from fabias.notifications import teams
    >>> from fabias.notifications.cards import Adaptive, TextBlock
    >>>
    >>> teams.client(team_id="...", channel_id="...", auth=my_auth)
    >>> teams.send("Pipeline completed!")
    >>>
    >>> # Or with rich formatting
    >>> card = Adaptive(body=[TextBlock("Important!", weight="Bolder")])
    >>> teams.send(card)
"""

from . import teams
from .cards import Adaptive, Column, ColumnSet, Image, Table, TextBlock

__all__ = [
    "teams",
    # Cards
    "Adaptive",
    "TextBlock",
    "Image",
    "ColumnSet",
    "Column",
    "Table",
]
