"""
Core module for fabias - provides runtime detection, authentication, and base client functionality.
"""

from .auth import AuthProvider, FabricAuth, RefreshTokenAuth, ServicePrincipalAuth
from .client import BaseClient
from .exceptions import ApiError, AuthenticationError, FabiasError, NotFoundError
from .response import AzResponse, Job
from .runtime import runtime

__all__ = [
    "runtime",
    "FabiasError",
    "AuthenticationError",
    "ApiError",
    "NotFoundError",
    "AuthProvider",
    "ServicePrincipalAuth",
    "RefreshTokenAuth",
    "FabricAuth",
    "BaseClient",
    "AzResponse",
    "Job",
]
