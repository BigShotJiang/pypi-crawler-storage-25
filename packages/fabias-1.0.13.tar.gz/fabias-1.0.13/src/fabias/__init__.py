"""
fabias - Fabric Infrastructure and Security.

A Python SDK for Microsoft Fabric focusing on OneLake security and workspace
automation. Works both inside Microsoft Fabric notebooks (leveraging notebookutils)
and as a standalone library.

Features:
    - OneLake ABAC security (table/row/column-level permissions)
    - Workspace management (create, configure, role assignments)
    - Pipeline execution and monitoring
    - Git synchronization for Fabric workspaces
    - Spark settings and pool configuration

Usage:
    # Fabric IS the root - no redundant namespace
    >>> import fabias
    >>>
    >>> # Inside Fabric (auth is automatic)
    >>> ws = fabias.workspace()
    >>> pipeline = ws.pipeline("Daily ETL")
    >>> job = pipeline.run()
    >>> job.wait()
    >>>
    >>> # OneLake security as code
    >>> from fabias import Role, Rule, EntraMember, ReadWrite
    >>> lakehouse = ws.lakehouse("Gold")
    >>> lakehouse.accessRoles.replace([
    ...     Role(
    ...         name="Analysts",
    ...         rules=[Rule(path=["tables"], access=ReadWrite.READ)],
    ...         members=[EntraMember("analysts-group-guid")]
    ...     )
    ... ])

    # Integrations (data platform services)
    >>> from fabias.integrations import adf, keyvault
    >>> adf.client(subscription_id="...", resource_group="...", factory="...", auth=...)
    >>> keyvault.client(vault_url="https://my-vault.vault.azure.net/")

    # Notifications (alerting)
    >>> from fabias.notifications import teams
    >>> from fabias.notifications.cards import Adaptive, TextBlock
    >>> teams.client(team_id="...", channel_id="...", auth=...)
    >>> teams.send(Adaptive([TextBlock("Pipeline complete!")]))
"""

__version__ = "1.0.0"
__author__ = "Daniel Davis"

# =============================================================================
# FABRIC (Root-level exports - fabias IS Fabric)
# =============================================================================

# Re-export everything from internal fabric module at root
# =============================================================================
# INTEGRATIONS (Data platform services)
# =============================================================================
# Available via: from fabias.integrations import adf, keyvault
# =============================================================================
# NOTIFICATIONS (Alerting)
# =============================================================================
# Available via: from fabias.notifications import teams
# Cards via: from fabias.notifications.cards import Adaptive, TextBlock
from . import integrations, notifications
from ._fabric import (
    Capacity,
    Connection,
    ConnectionEncryption,
    ConnectionRole,
    Connections,
    ConnectivityType,
    Environment,
    EnvironmentItem,
    # Classes
    FabricClient,
    Folder,
    FolderAccessor,
    Git,
    GitCredentialsSource,
    GitProviderType,
    InitializationStrategy,
    ItemAccess,
    ItemReference,
    ItemType,
    Lakehouse,
    Libraries,
    MemberType,
    Notebook,
    NotebookFormat,
    OperationStatus,
    Pipeline,
    PrincipalType,
    PrivacyLevel,
    ReadWrite,
    RequiredAction,
    SingleSignOnType,
    Tenant,
    Variable,
    VariableAccessor,
    VariableLibrary,
    Workspace,
    WorkspaceRole,
    capacities,
    capacity,
    # Configuration
    client,
    connection,
    connections,
    # Enums
    enums,
    reset,
    tenant,
    # Module-level functions
    workspace,
    workspaces,
)

# PoolType is not in fabric's lazy-loaded enums, import directly
from ._fabric._shared.enums import PoolType

# OneLake Security (ABAC)
from ._fabric.items.permissions import (
    ColumnLevelSecurity,
    EntraMember,
    FabricItem,
    Member,
    Role,
    RoleAccessor,
    RowLevelSecurity,
    Rule,
)

# Spark Settings (import directly from spark module)
from ._fabric.spark import (
    DefaultPoolSettings,
    HighConcurrencySettings,
    JobSettings,
    PoolSettings,
    Spark,
    SparkEnvironment,
    SparkSettings,
    StarterPoolSettings,
)

# =============================================================================
# SHARED UTILITIES
# =============================================================================
# Authentication
from ._shared.auth import (
    AuthProvider,
    AutoAuth,
    FabricAuth,
    RefreshTokenAuth,
    ServicePrincipalAuth,
)

# Exceptions
from ._shared.exceptions import ApiError, AuthenticationError, FabiasError, NotFoundError

# Response handling
from ._shared.response import AzResponse, Job

# Runtime detection
from ._shared.runtime import runtime

# =============================================================================

__all__ = [
    # Version
    "__version__",
    # Configuration
    "client",
    "reset",
    # Core Fabric functions
    "workspace",
    "workspaces",
    "connection",
    "connections",
    "capacity",
    "capacities",
    "tenant",
    # Classes
    "FabricClient",
    "Workspace",
    "Pipeline",
    "Lakehouse",
    "Notebook",
    "Environment",
    "EnvironmentItem",
    "Git",
    "Connection",
    "Connections",
    "Libraries",
    "VariableLibrary",
    "VariableAccessor",
    "Variable",
    "ItemReference",
    "Folder",
    "FolderAccessor",
    "Capacity",
    "Tenant",
    # OneLake Security
    "Role",
    "RoleAccessor",
    "Rule",
    "RowLevelSecurity",
    "ColumnLevelSecurity",
    "Member",
    "EntraMember",
    "FabricItem",
    # Spark Settings
    "Spark",
    "SparkSettings",
    "SparkEnvironment",
    "HighConcurrencySettings",
    "PoolSettings",
    "StarterPoolSettings",
    "DefaultPoolSettings",
    "JobSettings",
    # Enums module
    "enums",
    # Git enums
    "GitProviderType",
    "GitCredentialsSource",
    "InitializationStrategy",
    "RequiredAction",
    # Role assignment enums
    "WorkspaceRole",
    "ConnectionRole",
    "PrincipalType",
    # Connection enums
    "ConnectivityType",
    "PrivacyLevel",
    "ConnectionEncryption",
    "SingleSignOnType",
    # Operation enums
    "OperationStatus",
    # Item enums
    "ItemType",
    # Permissions
    "ReadWrite",
    "ItemAccess",
    "MemberType",
    # Pool type
    "PoolType",
    # Notebook formats
    "NotebookFormat",
    # Runtime
    "runtime",
    # Exceptions
    "FabiasError",
    "AuthenticationError",
    "ApiError",
    "NotFoundError",
    # Auth
    "AuthProvider",
    "ServicePrincipalAuth",
    "RefreshTokenAuth",
    "FabricAuth",
    "AutoAuth",
    # Response
    "AzResponse",
    "Job",
    # Sub-packages
    "integrations",
    "notifications",
]
