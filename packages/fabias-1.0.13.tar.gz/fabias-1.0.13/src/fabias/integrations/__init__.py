"""
Non-Fabric Azure service integrations.

This module contains integrations with Azure services that are outside
of Microsoft Fabric:

- **adf**: Azure Data Factory - pipeline execution and monitoring
- **keyvault**: Azure Key Vault - secret management

For notifications (Teams, email), see fabias.notifications.

Usage:
    >>> from fabias.integrations import adf, keyvault
    >>>
    >>> # Azure Data Factory
    >>> adf.client(subscription_id="...", resource_group="...", factory="...", auth=...)
    >>> adf.pipeline("ETL").run()
    >>>
    >>> # Key Vault
    >>> keyvault.client(vault_url="https://my-vault.vault.azure.net/")
    >>> password = keyvault.get("database-password")
"""

from . import adf, keyvault

__all__ = ["adf", "keyvault"]
