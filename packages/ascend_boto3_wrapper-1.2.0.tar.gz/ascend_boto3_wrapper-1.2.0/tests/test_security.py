"""
Tests for SEC-096 Security Fixes
==================================

Covers SEC-001 through SEC-004:
  - API key masking
  - TLS enforcement
  - Retry with jittered backoff
  - Input validation on fallback path
"""

import pytest
import logging
from unittest.mock import patch, MagicMock

from ascend_boto3.wrapper import (
    GovernanceConfig,
    _mask_api_key,
    _evaluate_via_api,
)
from ascend_boto3.risk_classifier import RiskLevel


# ---------------------------------------------------------------------------
# SEC-001: API key masking
# ---------------------------------------------------------------------------

class TestApiKeyMasking:
    """SEC-001: Verify API key masking utility."""

    def test_mask_normal_key(self):
        """First 6 chars visible, rest masked."""
        masked = _mask_api_key("ascend_prod_abc123xyz")
        assert masked.startswith("ascend")
        assert "*" in masked
        assert "prod_abc123xyz" not in masked
        assert len(masked) == len("ascend_prod_abc123xyz")

    def test_mask_short_key(self):
        """Keys <= 6 chars return '***'."""
        assert _mask_api_key("short") == "***"
        assert _mask_api_key("123456") == "***"

    def test_mask_empty_key(self):
        """Empty or None returns '***'."""
        assert _mask_api_key("") == "***"

    def test_error_logging_does_not_expose_key(self, caplog):
        """Exception logging must not contain raw API key."""
        api_key = "ascend_prod_SUPERSECRET999"
        config = GovernanceConfig(
            api_key=api_key,
            agent_id="test-agent",
            agent_name="Test Agent",
            base_url="https://localhost",
        )

        mock_resp = MagicMock()
        mock_resp.status_code = 400

        with patch("ascend_boto3.wrapper.requests.post", return_value=mock_resp):
            with caplog.at_level(logging.ERROR):
                with pytest.raises(Exception):
                    _evaluate_via_api(
                        "s3", "list_buckets", {}, config, 10, RiskLevel.LOW
                    )
        # The raw key must never appear in logs
        full_log = caplog.text
        assert "SUPERSECRET999" not in full_log


# ---------------------------------------------------------------------------
# SEC-002: TLS enforcement
# ---------------------------------------------------------------------------

class TestTlsEnforcement:
    """SEC-002: Reject insecure http:// base_url except localhost."""

    def test_http_non_localhost_rejected(self):
        """http:// to non-localhost host raises ValueError."""
        with pytest.raises(ValueError, match="Insecure base_url rejected"):
            GovernanceConfig(
                api_key="ascend_test_key",
                base_url="http://evil.example.com",
            )

    def test_https_accepted(self):
        """https:// is always accepted."""
        config = GovernanceConfig(
            api_key="ascend_test_key",
            base_url="https://pilot.owkai.app",
        )
        assert config.base_url == "https://pilot.owkai.app"

    def test_http_localhost_accepted(self):
        """http://localhost is allowed for development."""
        config = GovernanceConfig(
            api_key="ascend_test_key",
            base_url="http://localhost:8000",
        )
        assert config.base_url == "http://localhost:8000"

    def test_http_127_accepted(self):
        """http://127.0.0.1 is allowed for development."""
        config = GovernanceConfig(
            api_key="ascend_test_key",
            base_url="http://127.0.0.1:8000",
        )
        assert config.base_url == "http://127.0.0.1:8000"


# ---------------------------------------------------------------------------
# SEC-003: Retry with jittered backoff
# ---------------------------------------------------------------------------

class TestRetryWithBackoff:
    """SEC-003: Transient HTTP errors trigger retries with jittered backoff."""

    def test_retry_on_transient_errors(self):
        """429/503 responses trigger retries; delays are not identical (jitter)."""
        mock_resp_503 = MagicMock()
        mock_resp_503.status_code = 503

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.json.return_value = {"status": "approved", "id": "act-1"}

        config = GovernanceConfig(
            api_key="ascend_test_key_1234567",
            agent_id="test-agent",
            agent_name="Test Agent",
            base_url="https://pilot.owkai.app",
        )

        delays_recorded = []
        original_sleep = __import__("time").sleep

        def mock_sleep(duration):
            delays_recorded.append(duration)

        with patch("ascend_boto3.wrapper.requests.post",
                    side_effect=[mock_resp_503, mock_resp_503, mock_resp_ok]):
            with patch("ascend_boto3.wrapper.time.sleep", side_effect=mock_sleep):
                result = _evaluate_via_api(
                    "s3", "list_buckets", {}, config, 10, RiskLevel.LOW
                )

        assert result["approved"] is True
        assert len(delays_recorded) == 2
        # Jitter means delays should not be exactly equal
        # (astronomically unlikely with random.uniform)
        assert delays_recorded[0] != delays_recorded[1]

    def test_retry_exhaustion_raises(self):
        """After max retries, the exception propagates."""
        mock_resp_429 = MagicMock()
        mock_resp_429.status_code = 429

        config = GovernanceConfig(
            api_key="ascend_test_key_1234567",
            agent_id="test-agent",
            agent_name="Test Agent",
            base_url="https://pilot.owkai.app",
        )

        with patch("ascend_boto3.wrapper.requests.post", return_value=mock_resp_429):
            with patch("ascend_boto3.wrapper.time.sleep"):
                with pytest.raises(Exception, match="429"):
                    _evaluate_via_api(
                        "s3", "list_buckets", {}, config, 10, RiskLevel.LOW
                    )


# ---------------------------------------------------------------------------
# SEC-004: Input validation on fallback path
# ---------------------------------------------------------------------------

class TestInputValidation:
    """SEC-004: Validate inputs before API call in _evaluate_via_api."""

    def _make_config(self, **overrides):
        defaults = dict(
            api_key="ascend_test_key_1234567",
            agent_id="test-agent",
            agent_name="Test Agent",
            base_url="https://pilot.owkai.app",
        )
        defaults.update(overrides)
        return GovernanceConfig(**defaults)

    def test_empty_agent_id_rejected(self):
        """Empty agent_id raises ValueError."""
        config = self._make_config()
        config.agent_id = ""  # bypass __post_init__ auto-gen
        with pytest.raises(ValueError, match="agent_id"):
            _evaluate_via_api("s3", "list_buckets", {}, config, 10, RiskLevel.LOW)

    def test_empty_agent_name_rejected(self):
        """Empty agent_name raises ValueError."""
        config = self._make_config()
        config.agent_name = ""
        with pytest.raises(ValueError, match="agent_name"):
            _evaluate_via_api("s3", "list_buckets", {}, config, 10, RiskLevel.LOW)

    def test_empty_service_rejected(self):
        """Empty service raises ValueError."""
        config = self._make_config()
        with pytest.raises(ValueError, match="service"):
            _evaluate_via_api("", "list_buckets", {}, config, 10, RiskLevel.LOW)

    def test_empty_operation_rejected(self):
        """Empty operation raises ValueError."""
        config = self._make_config()
        with pytest.raises(ValueError, match="operation"):
            _evaluate_via_api("s3", "", {}, config, 10, RiskLevel.LOW)

    def test_risk_score_below_zero_rejected(self):
        """risk_score < 0 raises ValueError."""
        config = self._make_config()
        with pytest.raises(ValueError, match="risk_score"):
            _evaluate_via_api("s3", "list_buckets", {}, config, -1, RiskLevel.LOW)

    def test_risk_score_above_100_rejected(self):
        """risk_score > 100 raises ValueError."""
        config = self._make_config()
        with pytest.raises(ValueError, match="risk_score"):
            _evaluate_via_api("s3", "list_buckets", {}, config, 101, RiskLevel.LOW)

    def test_valid_inputs_accepted(self):
        """Valid inputs pass validation and reach the API call."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "approved", "id": "act-1"}

        config = self._make_config()
        with patch("ascend_boto3.wrapper.requests.post", return_value=mock_resp):
            result = _evaluate_via_api(
                "s3", "list_buckets", {}, config, 50, RiskLevel.MEDIUM
            )
        assert result["approved"] is True
