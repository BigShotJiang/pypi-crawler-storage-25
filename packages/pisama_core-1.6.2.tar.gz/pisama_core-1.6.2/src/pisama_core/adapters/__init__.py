"""Platform adapters for Pisama.

Adapters provide the interface between pisama-core and specific
agent platforms (Claude Code, LangGraph, etc.).
"""

from pisama_core.adapters.base import (
    PlatformAdapter,
    InjectionResult,
    InjectionMethod,
)
from pisama_core.adapters.openai import (
    parse_assistants_run as parse_openai_assistants_run,
    parse_response as parse_openai_response,
)
from pisama_core.adapters.bedrock import parse_invoke_agent as parse_bedrock_invoke_agent
from pisama_core.adapters.deep_agents import DeepAgentsAdapter, parse_deep_agents_trace

__all__ = [
    "PlatformAdapter",
    "InjectionResult",
    "InjectionMethod",
    "parse_openai_assistants_run",
    "parse_openai_response",
    "parse_bedrock_invoke_agent",
    "DeepAgentsAdapter",
    "parse_deep_agents_trace",
]
