"""
rust_pyfunc - 高性能Python函数库
=================================

基于Rust实现的高性能Python函数库，提供数学计算、时间序列分析、
文本处理、并行计算等功能。

主要模块：
- core_functions: 核心数学和统计函数
- time_series: 时间序列分析函数
- text_analysis: 文本处理函数
- parallel_computing: 并行计算和备份管理
- pandas_extensions: Pandas扩展函数
- tree_structures: 树结构相关类
"""

from typing import List, Tuple

# 导入所有类型声明
from .core_functions import *
from .time_series import *
from .text_analysis import *
from .parallel_computing import *
from .pandas_extensions import *
from .pandas_correlation import *
from .tree_structures import *
from .trading_analysis import *
from .agent_trading_daily import *
from .agent_simulator import *
from .statistical_analysis import *
from .web_manager import *
from .copula import *
from .theme_cluster_factors import *
from .theme_feature_expansion import *
from .theme_feature_expansion_data import *
from .trading_data_utils import *



def personalized_meeting_feature_names() -> Tuple[List[str], List[str]]:
    ...


def personalized_meeting_features(
    date: int,
    symbol: str,
    universe_size: int = 100,
    selection_method: str = "code",
) -> Tuple[List[float], List[str], List[List[float]], List[str]]:
    ...


def orderbook_volume_cov_factors(
    bid_volumes: object,  # numpy.ndarray (n, 10)
    ask_volumes: object,  # numpy.ndarray (n, 10)
    window_size: int,
) -> Tuple[List[str], object]:
    ...


def illusion_liquidity_distance_factors(
    price: object,  # numpy.ndarray (n,)
    volume: object,  # numpy.ndarray (n,)
    turnover: object,  # numpy.ndarray (n,)
    timestamps_ns: object,  # numpy.ndarray (n,) of int64
    window: int,
) -> Tuple[List[str], object]:
    ...


def compute_corr_diff_features(
    large_corr: object,  # numpy.ndarray (n*ratio, n*ratio)
    small_corr: object,  # numpy.ndarray (n, n)
    ratio: int,
) -> Tuple[List[float], object]:
    ...


# 版本信息
__version__ = "0.18.0"
__author__ = "chenzongwei"
__email__ = "noreply@example.com"

# 所有公开的函数和类
__all__ = [
    # 核心函数
    "trend",
    "trend_fast",
    "compute_integer_small_peak_features",
    "identify_segments",
    "find_max_range_product",
    "ols",
    "ols_predict",
    "ols_residuals",
    "max_range_loop",
    "min_range_loop",
    "rolling_volatility",
    "rolling_cv",
    "rolling_qcv",
    "compute_max_eigenvalue",
    "sum_as_string",
    "test_simple_function",
    "test_function",
    # 时间序列函数
    "dtw_distance",
    "fast_dtw_distance",
    "super_dtw_distance",
    "transfer_entropy",
    "rolling_dtw_distance",
    "find_local_peaks_within_window",
    "find_half_energy_time",
    "rolling_window_stat",
    "find_half_extreme_time",
    "fast_find_half_extreme_time",
    "super_find_half_extreme_time",
    "brachistochrone_curve",
    "brachistochrone_curve_v2",
    "rolling_lagged_regression",
    "rolling_lagged_regression_ridge_fast",
    "rolling_lagged_regression_ridge_simd",
    "rolling_lagged_regression_ridge_incremental",
    # 文本分析函数
    "vectorize_sentences",
    "jaccard_similarity",
    "min_word_edit_distance",
    "vectorize_sentences_list",
    # 并行计算函数
    "run_pools_queue",
    "query_backup",
    "query_backup_fast",
    "build_backup_column_block_cache_single_thread",
    "query_backup_single_column_compact_cached",
    "query_backup_single_column_compact_cached_from_cache_dir",
    "query_backup_codebook_cached",
    "query_backup_codebook_cached_from_cache_dir",
    # Pandas扩展函数
    "dataframe_corrwith",
    "dataframe_corrwith_single_thread",
    "rank_axis1",
    "fast_merge",
    "fast_merge_mixed",
    "fast_inner_join_dataframes",
    # 树结构类
    "PriceTree",
    "RollingFutureAccessor",
    "PriceTreeViz",
    # 交易分析函数
    "find_follow_volume_sum_same_price",
    "find_follow_volume_sum_same_price_and_flag",
    "mark_follow_groups",
    "mark_follow_groups_with_flag",
    "analyze_retreat_advance",
    "analyze_retreat_advance_v2",
    "calculate_large_order_nearby_small_order_time_gap",
    "order_contamination",
    "order_contamination_parallel",
    "order_contamination_bilateral",
    "trade_peak_analysis",
    "order_neighborhood_analysis",
    "calculate_trade_time_gap_and_price_percentile_ultra_sorted",
    "calculate_order_time_gap_and_price_percentile_ultra_sorted",
    "analyze_asks",
    "compute_non_breakthrough_stats",
    "compute_price_cycle_features",
    "compute_price_cycle_features_b_segments",
    "compute_price_cycle_features_b_segments_enhanced",
    "analyze_long_orders",
    "analyze_long_orders_python",
    "calculate_passive_order_features",
    "fit_hawkes_process",
    "hawkes_event_indicators",
    "analyze_hawkes_indicators",
    "compute_allo_microstructure_features",
    "reconstruct_limit_order_lifecycle",
    "reconstruct_limit_order_lifecycle_v2",
    "aggregate_agent_feature_triplets_to_daily_table",
    "get_agent_daily_feature_column_groups_for_get_features_factors",
    "pack_agent_daily_feature_table_for_get_features_factors",
    "compute_agent_trading_daily_feature_table",
    "compute_agent_trading_daily_feature_table_multi",
    "compute_agent_trading_daily_feature_table_for_get_features_factors",
    "compute_agent_trading_daily_feature_table_multi_for_get_features_factors",
    # 统计分析函数
    "calculate_base_entropy",
    "calculate_shannon_entropy_change",
    "calculate_shannon_entropy_change_at_low",
    "calculate_window_entropy",
    "factor_correlation_by_date",
    "factor_grouping",
    "tail_v2_backtest_block",
    "tail_v2_backtest_block_f32",
    "tail_v2_neutralize_block",
    "tail_v2_neutralize_block_f32",
    "tail_v2_neutralize_block_f32_out",
    "tail_v4_neutralize_block_f32_out_legacy",
    "tail_v4_neutralize_block_exact",
    "TailV4LegacyStyleData",
    "tail_v2_rank_roll_factor_f32",
    "tail_v3_rank_roll_block_f32",
    "tail_v2_select_by_ic_corr_abs_f32",
    "tail_v4_run_candidates",
    "tail_v4_run_fulltest_queue",
    "segment_and_correlate",
    "lz_complexity",
    "lz_complexity_detailed",
    "mutual_information_knn",
    "mutual_information_knn_chebyshev",
    "mutual_information_2d_knn",
    "mutual_information_2d_knn_chebyshev",
    # Python定义的pandas扩展函数
    "corrwith",
    "rank_axis1_df",
    "rank_axis0_df",
    "fast_rank",
    "fast_rank_axis1",
    "fast_rank_axis0",
    "fast_merge_df",
    "fast_inner_join_df",
    "fast_left_join_df",
    "fast_right_join_df",
    "fast_outer_join_df",
    "fast_join",
    "fast_merge_dataframe",
    # pandas相关性矩阵函数
    "fast_correlation_matrix_v2_df",
    "fast_corr_df",
    "correlation_matrix_df",
    # 因子中性化函数
    "batch_factor_neutralization",
    "batch_factor_neutralization_optimized",
    "batch_factor_neutralization_io_optimized",
    "batch_factor_neutralization_simple_math_optimized",
    "batch_factor_neutralization_parallel_optimized",
    "batch_factor_neutralization_ultimate_optimized",
    "batch_factor_neutralization_simple_fallback",
    # Web管理器
    "BackupWebManager",
    "check_port_available",
    "find_available_port",
    "start_web_manager",
    # 测试函数
    "haha",
    # Agent模拟器函数
    "simulate_momentum_agents_py",
    "simulate_buy_ratio_agents_py",
    "simulate_thematic_agents_py",
    "simulate_bottom_fishing_agents_py",
    "simulate_follow_flow_agents_py",
    "simulate_acceleration_follow_agents_py",
    "simulate_exhaustion_reversal_agents_py",
    "compute_theme_feature_expansion_from_minute",
    "prepare_minute_data_for_theme_feature_expansion",
    "compute_theme_feature_expansion_from_minute_raw",
    "compute_theme_feature_expansion_from_date",
    "get_theme_cluster_scatter_3d",
    "adjust_afternoon",
    "read_trade",
    "read_market",
    "read_market_pair",
    "get_features_factors_single",
    "get_features_factors",
    "get_features_names",
    "dct_1d",
    "dct_2d",
    "personalized_meeting_feature_names",
    "personalized_meeting_features",
    "orderbook_volume_cov_factors",
    "illusion_liquidity_distance_factors",
    "compute_corr_diff_features",
]
