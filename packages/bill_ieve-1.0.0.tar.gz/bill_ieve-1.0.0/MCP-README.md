# Bill-ieve MCP Server

한국·미국·유럽연합 3개국 의회 법안을 AI로 분석하는 MCP 서버.

## 설치 (1줄)

```bash
claude mcp add bill-ieve -- uvx --from git+https://github.com/Tess-Jung/billieve bill-ieve
```

DB 설정이나 API 키가 필요 없습니다. Bill-ieve 공개 API를 자동으로 호출합니다.

## 사용 예시

Claude Code에서 자연어로 질문하면 됩니다:

```
"한국 반도체 관련 법안 찾아줘"
"미국에서 최근 통과된 AI 법안 알려줘"
"EU의 전기차 관련 규정 검색해줘"
"이 법안 요약해줘"
```

## 도구 목록

### Free (인증 불필요)

| 도구 | 설명 |
|------|------|
| `search-bills` | 3개국 법안 검색 (country: KR/US/EU) |
| `get-bill-detail` | 법안 상세 조회 |
| `search-members` | 한국 국회의원 검색 |
| `get-member-detail` | 의원 상세 조회 |
| `search-minutes` | 회의록 검색 |
| `get-meeting-context` | 회의록 상세 |
| `search-petitions` | 청원 검색 |
| `get-bill-categories` | 카테고리별 통계 |
| `get-countries` | 지원 국가 목록 |

### Pro

| 도구 | 설명 |
|------|------|
| `summarize-bill` | AI 법안 요약 |
| `get-bill-impact` | AI 영향 분석 |

## 데이터 현황

| 국가 | 법안 수 | 소스 |
|------|---------|------|
| 🇰🇷 한국 | 16,289건 | 열린국회정보 API |
| 🇺🇸 미국 | 14,235건 | Congress.gov API v3 |
| 🇪🇺 유럽연합 | 408건 | CELLAR SPARQL |

## 라이선스

MIT
