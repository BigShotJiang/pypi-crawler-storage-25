"""Bill-ieve scheduled jobs -- APScheduler based cron runner."""

from __future__ import annotations

import asyncio
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

logger = logging.getLogger(__name__)


async def job_collect_bills() -> None:
    """4시간 간격 -- 최근 7일 법안 수집."""
    from cnews.collectors.collect_bills import collect_bills

    logger.info("Starting scheduled collect_bills...")
    result = await collect_bills(days=7)
    logger.info("collect_bills completed: %s", result)


async def job_collect_summaries() -> None:
    """4시간 간격 (법안 수집 10분 후) -- 신규 법안 제안이유 수집."""
    from cnews.collectors.collect_summaries import collect_summaries

    logger.info("Starting scheduled collect_summaries...")
    result = await collect_summaries()
    logger.info("collect_summaries completed: %s", result)


async def job_create_daily_briefing() -> None:
    """4시간 간격 (발언 수집 10분 후) -- 일일 입법 브리핑 자동 생성."""
    from cnews.services.briefing import create_daily_briefing

    logger.info("Starting scheduled create_daily_briefing...")
    result = await create_daily_briefing()
    if result:
        logger.info("Daily briefing created: %s (%d bills)", result.title, result.bill_count)
    else:
        logger.info("Daily briefing skipped (already exists or no bills)")


async def job_collect_minutes() -> None:
    """4시간 간격 (제안이유 수집 10분 후) -- 회의록 수집."""
    from cnews.collectors.collect_minutes import collect_minutes

    logger.info("Starting scheduled collect_minutes...")
    result = await collect_minutes()
    logger.info("collect_minutes completed: %s", result)


async def job_collect_speeches() -> None:
    """4시간 간격 (회의록 수집 10분 후) -- 신규 회의록 PDF에서 발언 수집."""
    from cnews.collectors.collect_speeches import collect_speeches

    logger.info("Starting scheduled collect_speeches...")
    result = await collect_speeches()
    logger.info("collect_speeches completed: %s", result)


async def job_generate_minute_summaries() -> None:
    """4시간 간격 (발언 수집 40분 후) -- 회의록 AI 요약 생성."""
    import sys

    sys.path.insert(0, "scripts")
    from generate_minute_summaries import main as generate_summaries

    logger.info("Starting scheduled generate_minute_summaries (AI mode)...")
    await generate_summaries(dry_run=False, use_ai=True, force=False)
    logger.info("generate_minute_summaries completed.")


async def job_reprocess_missing_summaries() -> None:
    """주간 1회 (일요일 03:00 KST) -- summary_ai 누락 법안 재처리."""
    from cnews.ai.reprocess_missing_summaries import reprocess_summaries

    logger.info("Starting scheduled reprocess_missing_summaries...")
    result = await reprocess_summaries()
    logger.info("reprocess_missing_summaries completed: %s", result)


def create_scheduler() -> AsyncIOScheduler:
    """Create and configure the scheduler with all cron jobs."""
    scheduler = AsyncIOScheduler(timezone="Asia/Seoul")

    # 4시간 간격 -- 법안 수집 (00:00, 04:00, 08:00, 12:00, 16:00, 20:00)
    scheduler.add_job(
        job_collect_bills,
        CronTrigger(hour="*/4", minute=0),
        id="collect_bills",
        name="법안 수집 (4시간 간격)",
        replace_existing=True,
    )

    # 4시간 간격 + 10분 후 -- 제안이유 수집
    scheduler.add_job(
        job_collect_summaries,
        CronTrigger(hour="*/4", minute=10),
        id="collect_summaries",
        name="제안이유 수집 (4시간 간격, +10분)",
        replace_existing=True,
    )

    # 4시간 간격 + 20분 후 -- 회의록 수집
    scheduler.add_job(
        job_collect_minutes,
        CronTrigger(hour="*/4", minute=20),
        id="collect_minutes",
        name="회의록 수집 (4시간 간격, +20분)",
        replace_existing=True,
    )

    # 4시간 간격 + 30분 후 -- 신규 회의록 PDF에서 발언(Speech) 수집
    scheduler.add_job(
        job_collect_speeches,
        CronTrigger(hour="*/4", minute=30),
        id="collect_speeches",
        name="발언 수집 (4시간 간격, +30분)",
        replace_existing=True,
    )

    # 4시간 간격 + 40분 후 -- 일일 입법 브리핑 자동 생성
    scheduler.add_job(
        job_create_daily_briefing,
        CronTrigger(hour="*/4", minute=40),
        id="create_daily_briefing",
        name="브리핑 생성 (4시간 간격, +40분)",
        replace_existing=True,
    )

    # 4시간 간격 + 50분 후 -- 회의록 AI 요약 (발언 수집 후)
    scheduler.add_job(
        job_generate_minute_summaries,
        CronTrigger(hour="*/4", minute=50),
        id="generate_minute_summaries",
        name="회의록 AI 요약 (4시간 간격, +50분)",
        replace_existing=True,
    )

    # 주간 1회 -- 일요일 03:00 KST, summary_ai 누락 법안 재처리
    scheduler.add_job(
        job_reprocess_missing_summaries,
        CronTrigger(day_of_week="sun", hour=3, minute=0),
        id="reprocess_missing_summaries",
        name="AI 요약 누락 재처리 (주간, 일요일 03:00)",
        replace_existing=True,
    )

    return scheduler


def start_scheduler() -> None:
    """Start the scheduler (blocking)."""
    async def _run() -> None:
        scheduler = create_scheduler()
        scheduler.start()
        logger.info("Scheduler started with %d jobs", len(scheduler.get_jobs()))
        for job in scheduler.get_jobs():
            logger.info("  %s: next run at %s", job.name, job.next_run_time)

        try:
            while True:
                await asyncio.sleep(3600)
        except (KeyboardInterrupt, SystemExit):
            scheduler.shutdown()
            logger.info("Scheduler stopped.")

    asyncio.run(_run())


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    start_scheduler()
