"""bill-ieve MCP server — FastMCP entry point.

Local stdio transport. Calls Bill-ieve public API (no DB required).

Install:
  claude mcp add bill-ieve -- uvx bill-ieve
  # or
  claude mcp add bill-ieve -- uv run --from git+https://github.com/Tess-Jung/billieve bill-ieve
"""

from mcp.server.fastmcp import FastMCP

from cnews.tools.bills import register_tools as register_bill_tools
from cnews.tools.members import register_tools as register_member_tools
from cnews.tools.minutes import register_tools as register_minute_tools
from cnews.tools.analysis import register_tools as register_analysis_tools
from cnews.tools.petitions import register_tools as register_petition_tools
from cnews.tools.resources import register_resources

mcp = FastMCP(
    "bill-ieve",
    instructions=(
        "Bill-ieve는 한국·미국·유럽연합 3개국 의회 법안을 "
        "AI로 분석하는 입법 인텔리전스 MCP 서버입니다. "
        "법안 검색, 상세 조회, AI 요약, 의원 정보, 회의록을 제공합니다. "
        "country 파라미터로 국가를 지정하세요 (KR/US/EU, 기본값 KR)."
    ),
)

register_bill_tools(mcp)
register_member_tools(mcp)
register_minute_tools(mcp)
register_analysis_tools(mcp)
register_petition_tools(mcp)
register_resources(mcp)


def main():
    """CLI entry point for bill-ieve MCP server."""
    mcp.run()  # stdio transport (default)


if __name__ == "__main__":
    main()
