from sqlalchemy import URL
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from dotenv import load_dotenv
import os

load_dotenv()


def _build_url() -> URL:
    """Build asyncpg URL from individual env vars (avoids # parsing issues)."""
    return URL.create(
        drivername="postgresql+asyncpg",
        username=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", ""),
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        database=os.getenv("DB_NAME", "postgres"),
    )


engine = create_async_engine(
    _build_url(),
    echo=False,
    pool_size=2,
    max_overflow=3,
    pool_recycle=1800,
    pool_pre_ping=True,
    pool_timeout=10,
    connect_args={
        "server_settings": {"statement_timeout": "15000"},  # 15s
        "command_timeout": 20,
        "prepared_statement_cache_size": 0,  # Transaction Pooler 호환
    },
)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)


async def get_session() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session
