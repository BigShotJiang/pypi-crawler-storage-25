"""Daily Briefing generator — creates "오늘의 입법 브리핑" from recent bills.

No external AI API calls — uses existing headline_ai and bullet_summary data.

Usage::

    from cnews.services.briefing import create_daily_briefing
    briefing = await create_daily_briefing()
"""

from __future__ import annotations

import logging
from collections import Counter
from datetime import date, datetime, timedelta

from sqlalchemy import select, func, case
from sqlalchemy.orm import selectinload

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill
from cnews.models.category import Category
from cnews.models.daily_briefing import DailyBriefing
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

TOP_BILL_COUNT = 5


async def _get_category_stats(
    session, cutoff: datetime
) -> dict[str, int]:
    """Return bill counts per category for recent bills."""
    stmt = (
        select(
            Category.name_ko,
            func.count(Bill.id).label("cnt"),
        )
        .join(Category, Bill.category_id == Category.id, isouter=True)
        .where((Bill.updated_at >= cutoff) | (Bill.collected_at >= cutoff))
        .group_by(Category.name_ko)
    )
    result = await session.execute(stmt)
    return {row.name_ko or "미분류": row.cnt for row in result.all()}


async def _get_new_bill_count(
    session, target_date: date
) -> int:
    """Return count of bills proposed today."""
    day_start = datetime.combine(target_date, datetime.min.time())
    day_end = day_start + timedelta(days=1)
    stmt = select(func.count(Bill.id)).where(
        Bill.proposed_date >= day_start,
        Bill.proposed_date < day_end,
    )
    result = await session.execute(stmt)
    return result.scalar() or 0


async def _get_total_recent_count(
    session, cutoff: datetime
) -> int:
    """Return total count of recently updated/collected bills."""
    stmt = select(func.count(Bill.id)).where(
        (Bill.updated_at >= cutoff) | (Bill.collected_at >= cutoff)
    )
    result = await session.execute(stmt)
    return result.scalar() or 0


async def create_daily_briefing(
    target_date: date | None = None,
) -> DailyBriefing | None:
    """Generate a daily briefing for *target_date* (default: today).

    Steps:
    1. Query bills created/updated in the last 24 hours
    2. Select top 5 by importance_score
    3. Build enriched briefing body with headline_ai, bullet_summary,
       category stats, and new bill count
    4. Save to DailyBriefing table (skip if already exists)

    Returns:
        The created DailyBriefing, or None if already exists or no bills.
    """
    if target_date is None:
        target_date = date.today()

    async with AsyncSessionLocal() as session:
        # Check if briefing already exists for this date
        existing = await session.execute(
            select(DailyBriefing).where(
                DailyBriefing.briefing_date == target_date
            )
        )
        if existing.scalar_one_or_none() is not None:
            logger.info(
                "Daily briefing for %s already exists, skipping.", target_date
            )
            return None

        # Fetch recent bills (last 24h based on collected_at or updated_at)
        cutoff = datetime.combine(target_date, datetime.min.time()) - timedelta(
            hours=24
        )
        stmt = (
            select(Bill)
            .options(selectinload(Bill.category))
            .where(
                (Bill.updated_at >= cutoff) | (Bill.collected_at >= cutoff)
            )
            .order_by(
                Bill.importance_score.desc().nullslast(),
                Bill.proposed_date.desc(),
            )
            .limit(TOP_BILL_COUNT)
        )
        result = await session.execute(stmt)
        bills = list(result.scalars().all())

        if not bills:
            logger.info("No recent bills found for briefing on %s", target_date)
            return None

        # Gather statistics
        category_stats = await _get_category_stats(session, cutoff)
        new_bill_count = await _get_new_bill_count(session, target_date)
        total_recent = await _get_total_recent_count(session, cutoff)

        # Build briefing header with stats
        date_str = target_date.strftime("%Y년 %m월 %d일")
        header_parts: list[str] = [
            f"📋 {date_str} 입법 브리핑",
            "",
        ]

        # Summary line
        header_parts.append(
            f"오늘 신규 발의 {new_bill_count}건 | "
            f"최근 24시간 변동 {total_recent}건"
        )
        header_parts.append("")

        # Category breakdown
        if category_stats:
            sorted_cats = sorted(
                category_stats.items(), key=lambda x: x[1], reverse=True
            )
            cat_parts = [f"{name} {cnt}건" for name, cnt in sorted_cats]
            header_parts.append("카테고리별: " + " · ".join(cat_parts))
            header_parts.append("")

        header_parts.append("─" * 40)
        header_parts.append("")

        # Build per-bill content
        body_parts: list[str] = list(header_parts)
        top_bills_json: list[dict] = []

        for i, bill in enumerate(bills, 1):
            headline = bill.headline_ai or bill.title_original
            bullets = bill.bullet_summary or ""
            summary = bill.summary_ai or ""
            category_name = bill.category.name_ko if bill.category else "미분류"
            score = bill.importance_score or 0

            # Build rich bill entry
            entry_parts: list[str] = [
                f"{i}. [{category_name}] {headline}",
                f"   중요도: {score}/10",
            ]

            # Add bullet summary if available
            if bullets:
                for line in bullets.strip().splitlines():
                    entry_parts.append(f"   {line}")

            # Add AI summary excerpt if available and different from bullets
            if summary and summary != bullets:
                # Take first 200 chars as excerpt
                excerpt = summary[:200].strip()
                if len(summary) > 200:
                    excerpt += "..."
                entry_parts.append(f"   요약: {excerpt}")

            entry_parts.append("")
            body_parts.append("\n".join(entry_parts))

            top_bills_json.append(
                {
                    "rank": i,
                    "source_id": bill.source_id,
                    "title": bill.title_original,
                    "headline": headline,
                    "bullet_summary": bullets,
                    "category": category_name,
                    "importance_score": score,
                    "proposed_date": (
                        bill.proposed_date.strftime("%Y-%m-%d")
                        if bill.proposed_date
                        else None
                    ),
                }
            )

        title = f"{date_str} 입법 브리핑"
        body = "\n".join(body_parts)

        # Save briefing
        briefing = DailyBriefing(
            id=generate_cuid(),
            briefing_date=target_date,
            title=title,
            body=body,
            top_bills=top_bills_json,
            bill_count=len(bills),
        )

        session.add(briefing)
        await session.commit()

        logger.info(
            "Created daily briefing for %s with %d bills "
            "(new today: %d, total recent: %d)",
            target_date,
            len(bills),
            new_bill_count,
            total_recent,
        )
        return briefing
