"""Fix misclassified industry tags using rule-based keyword matching.

The original AI-based industry tagging had ~20% accuracy. This script
applies keyword-based corrections to reassign bills to more appropriate
industry tags based on their titles.

Usage::

    python -m cnews.services.fix_industry_tags
    python -m cnews.services.fix_industry_tags --dry-run
"""

from __future__ import annotations

import asyncio
import logging
import time

from sqlalchemy import select, text, delete

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill
from cnews.models.bill_industry import BillIndustry
from cnews.models.industry_tag import IndustryTag
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

# Keyword → industry code mapping (KSIC-based)
# Order matters: first match wins
KEYWORD_RULES: list[tuple[list[str], str]] = [
    # K: 금융·보험업 — strict financial/tax only
    (["세법", "금융", "보험법", "은행법", "증권", "자본시장", "예산", "재정",
      "신용", "대출법", "투자", "펀드", "채권", "관세", "조세", "소득세",
      "법인세", "부가가치세", "상속세", "증여세", "지방세", "종합부동산",
      "세특", "세제", "국세", "특례제한법", "조특"], "K"),
    # Q: 보건·사회복지
    (["복지", "건강보험", "의료", "보건", "장애인", "노인", "아동복지",
      "간호", "병원", "약사법", "의약", "감염병", "질병", "정신건강",
      "장애", "어린이", "출산", "모자보건", "영유아", "보육",
      "국민연금", "기초연금", "사회보장", "사회서비스", "돌봄",
      "장기요양", "응급의료", "의사", "치과", "한의", "약국"], "Q"),
    # P: 교육서비스업
    (["교육", "학교", "대학", "학원", "유아교육", "유치원", "교원",
      "교사", "입학", "학생", "학력", "학점", "장학", "학술",
      "평생교육", "직업교육"], "P"),
    # H: 운수·창고업
    (["운송", "교통", "항공", "철도", "해운", "물류", "택시", "버스",
      "항만", "선박", "자동차관리", "도로법", "도로교통", "고속도로",
      "공항", "궤도", "해양교통", "선원", "화물"], "H"),
    # J: 정보통신업
    (["방송법", "방송통신", "통신법", "인터넷", "미디어", "전파법",
      "정보보호", "소프트웨어", "데이터", "개인정보", "전기통신",
      "전자정부", "정보화", "클라우드", "AI", "인공지능",
      "지능정보화"], "J"),
    # D: 전기·가스·수도
    (["전기사업", "가스사업", "수도법", "에너지", "전력", "기후",
      "탄소", "온실가스", "발전소", "송전", "신재생", "태양광",
      "풍력", "원자력", "핵"], "D"),
    # F: 건설업
    (["건설", "건축", "주택법", "아파트", "도시개발", "부동산",
      "토지", "국토", "시설안전", "하수도", "상수도", "재건축",
      "재개발", "도시정비"], "F"),
    # A: 농업·임업·어업
    (["농업", "농촌", "농산물", "축산", "수산", "어업", "어촌",
      "임업", "산림", "식품", "양곡", "종자", "비료", "농지",
      "양식", "어선", "해양수산"], "A"),
    # C: 제조업
    (["제조", "공장", "산업단지", "중소기업", "대기업", "벤처",
      "반도체", "배터리", "자동차산업", "조선", "방위산업",
      "화학물질", "위험물", "의약품제조", "의료기기"], "C"),
    # G: 도소매업
    (["소비자", "유통", "전자상거래", "소매", "도매", "시장정비",
      "상거래", "할부거래", "방문판매", "통신판매"], "G"),
    # M: 전문·과학·기술
    (["과학기술", "연구개발", "특허", "발명", "우주", "원자력연구",
      "기초과학", "나노", "바이오", "생명공학"], "M"),
    # N: 사업시설·지원 — only for actual facility/support services
    (["경비업", "청소", "시설관리", "인력파견", "용역"], "N"),
]

# Bills that should NOT have industry tags (purely political/procedural)
NO_INDUSTRY_KEYWORDS = [
    "국회법", "국회의원", "헌법", "공직선거", "선거법", "정당법",
    "국민투표", "탄핵", "인사청문", "주민소환", "주민투표",
    "주민조례", "형법", "형사소송", "민법", "민사소송",
    "군사법원", "군형법", "계엄법", "비상계엄", "특별검사",
    "특검", "진상규명", "국정조사", "감사원",
]


def classify_bill_industry(title: str) -> str | None:
    """Classify a bill title into an industry code.

    Returns:
        Industry code (e.g., 'K', 'Q') or None if no industry tag applies.
    """
    # Check if this is a non-industry bill
    for kw in NO_INDUSTRY_KEYWORDS:
        if kw in title:
            return None  # No industry tag for this bill

    # Try keyword rules
    for keywords, code in KEYWORD_RULES:
        for kw in keywords:
            if kw in title:
                return code

    # No clear match — return None (keep existing or leave untagged)
    return None


async def fix_industry_tags(dry_run: bool = False) -> dict:
    """Re-classify industry tags using keyword rules.

    Returns:
        Summary dict with total checked, corrected, removed, unchanged.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    corrected = 0
    removed = 0
    unchanged = 0
    total = 0

    async with AsyncSessionLocal() as session:
        # Load industry tag map
        tag_result = await session.execute(select(IndustryTag))
        tags = {t.code: t for t in tag_result.scalars().all()}
        tag_by_id = {t.id: t for t in tags.values()}

        # Get all bills with industry tags (group by bill)
        stmt = text("""
            SELECT b.id, b.title_original,
                   array_agg(bi.id) as bi_ids,
                   array_agg(bi.industry_tag_id) as tag_ids
            FROM bills b
            JOIN bill_industries bi ON bi.bill_id = b.id
            GROUP BY b.id, b.title_original
        """)
        result = await session.execute(stmt)
        rows = result.fetchall()
        total = len(rows)

        # For each bill, decide: delete all tags, replace with correct one, or keep
        delete_bi_ids: list[str] = []
        replace_records: list[tuple[str, str, str]] = []  # (bill_id, old_bi_ids_to_delete, new_tag_id)

        for bill_id, title, bi_ids, tag_ids in rows:
            current_codes = set()
            for tid in tag_ids:
                t = tag_by_id.get(tid)
                if t:
                    current_codes.add(t.code)

            new_code = classify_bill_industry(title)

            if new_code is None:
                # Remove all industry tags for this bill
                delete_bi_ids.extend(bi_ids)
                removed += 1
            elif new_code not in current_codes and new_code in tags:
                # Need to change: delete existing, create new
                delete_bi_ids.extend(bi_ids)
                replace_records.append((bill_id, new_code, tags[new_code].id))
                corrected += 1
            else:
                unchanged += 1

        if not dry_run:
            # Delete all identified entries
            if delete_bi_ids:
                for i in range(0, len(delete_bi_ids), 500):
                    batch = delete_bi_ids[i:i+500]
                    await session.execute(
                        delete(BillIndustry).where(BillIndustry.id.in_(batch))
                    )

            # Insert correct tags
            if replace_records:
                new_rows = []
                for bill_id, code, tag_id in replace_records:
                    new_rows.append({
                        "id": generate_cuid(),
                        "bill_id": bill_id,
                        "industry_tag_id": tag_id,
                        "relevance_score": 1.0,
                    })
                # Batch insert
                for i in range(0, len(new_rows), 500):
                    batch = new_rows[i:i+500]
                    from sqlalchemy.dialects.postgresql import insert as pg_insert
                    stmt = pg_insert(BillIndustry).values(batch)
                    stmt = stmt.on_conflict_do_nothing(
                        constraint="uq_bill_industries_bill_industry"
                    )
                    await session.execute(stmt)

            await session.commit()

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "total_checked": total,
        "corrected": corrected,
        "removed_no_industry": removed,
        "unchanged": unchanged,
        "dry_run": dry_run,
        "duration_ms": duration_ms,
    }
    logger.info("fix_industry_tags result: %s", result)
    return result


if __name__ == "__main__":
    import argparse
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="Fix misclassified industry tags")
    parser.add_argument("--dry-run", action="store_true", help="Check only, no DB changes")
    args = parser.parse_args()

    result = asyncio.run(fix_industry_tags(dry_run=args.dry_run))
    print(result)
