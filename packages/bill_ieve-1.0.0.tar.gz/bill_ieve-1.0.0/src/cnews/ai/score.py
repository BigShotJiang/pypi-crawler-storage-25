"""Importance scoring using Anthropic Claude + rule-based bonuses."""

from __future__ import annotations

import logging
import re

from . import sanitize_for_prompt
from .client import MODEL, get_anthropic_client
from .usage_tracker import tracker

logger = logging.getLogger(__name__)

BUDGET_COMMITTEES = frozenset(["기획재정위원회"])


def _parse_proposer_count(proposer: str | None) -> int:
    """Extract proposer count from strings like '홍길동의원 등 12인'.

    Returns 1 if parsing fails.
    """
    if not proposer:
        return 1
    match = re.search(r"(\d+)\s*인", proposer)
    if match:
        return int(match.group(1))
    return 1


def score_importance(
    title: str,
    summary: str | None,
    proposer: str | None,
    committee: str | None,
    bill_id: str = "",
) -> int | None:
    """Compute hybrid importance score (AI 70% + rule 30%).

    Returns an integer 1-10, or None on failure.
    """
    summary_text = summary or "요약 없음"
    safe_title = sanitize_for_prompt(title)
    safe_summary = sanitize_for_prompt(summary_text)
    proposer_count = _parse_proposer_count(proposer)
    committee_name = committee or "미정"

    prompt = (
        "아래 법안의 사회적 중요도를 1~10점으로 채점하세요. "
        "기준: 영향 범위(국민 전체 vs 특정 집단), 경제적 규모, "
        "언론 관심도 예상, 기존 법체계 변경 폭. 숫자만 응답하세요.\n\n"
        f"법안 제목: {safe_title}\n"
        f"요약: {safe_summary}\n"
        f"발의자 수: {proposer_count}명\n"
        f"소관 위원회: {committee_name}"
    )

    try:
        client = get_anthropic_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=10,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}],
        )

        tracker.record(
            task_type="score",
            bill_id=bill_id,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            model=MODEL,
        )

        text = response.content[0].text.strip()
        match = re.search(r"(\d+)", text)
        if not match:
            logger.warning("Could not parse AI score from: %s", text)
            return None

        ai_score = int(match.group(1))
        ai_score = max(1, min(10, ai_score))

    except Exception:
        logger.exception("Failed to call Anthropic API for scoring")
        return None

    # Rule-based bonuses
    rule_score = 0.0
    bonuses = 0.0

    if proposer_count >= 10:
        bonuses += 1.0

    if committee_name in BUDGET_COMMITTEES:
        bonuses += 0.5

    # Base rule score is the sum of bonuses (max ~2.5 without industry info)
    rule_score = bonuses

    final = ai_score * 0.7 + rule_score * 0.3 + bonuses
    final = max(1, min(10, round(final)))

    return final
