"""AI module for bill analysis."""


def sanitize_for_prompt(text: str) -> str:
    """프롬프트 인젝션 방어용 입력 정제."""
    if not text:
        return ""
    # 프롬프트 분할 문자 중립화
    sanitized = text.replace("\\", "\\\\")
    sanitized = sanitized.replace('"', '\\"')
    sanitized = sanitized.replace("\n\n", "\n")  # 이중 개행 방지
    # 위험 패턴 제거
    for pattern in ["ignore above", "you are now", "system prompt", "forget previous"]:
        sanitized = sanitized.replace(pattern, "[FILTERED]")
    return sanitized
