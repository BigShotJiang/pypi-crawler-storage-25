"""Bill summarization using Anthropic Claude.

v2: 뉴스 기사 스타일 plain text 요약으로 변경 (2026-03-26).
기존 JSON 구조 (background/keyContent/expectedEffect) → 자연스러운 뉴스 문체 plain text.
"""

from __future__ import annotations

import logging

from . import sanitize_for_prompt
from .client import MODEL, get_anthropic_client
from .usage_tracker import tracker

logger = logging.getLogger(__name__)


def summarize_bill(title: str, summary: str | None, bill_id: str = "") -> str | None:
    """Generate a news-style plain text summary for a bill.

    Returns a plain text string (news article style).
    Returns None on API failure.
    """
    summary_text = summary or "요약 없음"
    safe_title = sanitize_for_prompt(title)
    safe_summary = sanitize_for_prompt(summary_text)

    prompt = (
        "다음 법안을 뉴스 기사 형식으로 요약하세요.\n\n"
        f"법안명: {safe_title}\n"
        f"제안이유: {safe_summary}\n\n"
        "요구사항:\n"
        "- 첫 문장은 핵심을 요약하는 뉴스 리드(lead)로 작성하세요.\n"
        "- 이어서 제안 배경, 주요 내용, 기대 효과를 자연스러운 흐름으로 서술하세요.\n"
        "- 전체 3~5문장으로 간결하게 작성하세요.\n"
        "- 뉴스 기사처럼 객관적이고 간결한 문체를 사용하세요.\n"
        "- 전문 용어는 최소화하고, 일반 독자가 이해할 수 있게 쓰세요.\n"
        "- 찬성과 반대 양측 의견이 있는 경우 균형 있게 포함하세요.\n"
        "- JSON이나 태그 없이 순수한 텍스트만 반환하세요.\n"
    )

    try:
        client = get_anthropic_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=500,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}],
        )

        tracker.record(
            task_type="summarize",
            bill_id=bill_id,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            model=MODEL,
        )

        return response.content[0].text.strip()

    except Exception:
        logger.exception("Failed to call Anthropic API for summarization")
        return None
