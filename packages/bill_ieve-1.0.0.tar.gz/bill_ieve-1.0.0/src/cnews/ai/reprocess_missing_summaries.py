"""Reprocess bills with missing or malformed summary_ai.

Targets:
- summary_ai IS NULL AND summary_original IS NOT NULL
- summary_ai that is too short (< 30 chars, likely malformed)

Uses the same summarize_bill() logic from summarize.py (now returns plain text).
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime

from sqlalchemy import select, and_

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill

from .summarize import summarize_bill

logger = logging.getLogger(__name__)

BILL_DELAY_SECONDS = 0.5


async def find_reprocess_targets() -> list[tuple]:
    """Find bills needing summary reprocessing.

    Returns list of (id, source_id, title_original, summary_original).
    """
    async with AsyncSessionLocal() as session:
        stmt = (
            select(
                Bill.id,
                Bill.source_id,
                Bill.title_original,
                Bill.summary_original,
            )
            .where(
                # summary_ai is NULL but summary_original exists
                and_(
                    Bill.summary_ai.is_(None),
                    Bill.summary_original.isnot(None),
                )
            )
            .order_by(Bill.proposed_date.desc())
        )
        result = await session.execute(stmt)
        return result.all()


async def reprocess_summaries(limit: int = 0, dry_run: bool = False) -> dict:
    """Reprocess bills with missing or malformed summaries.

    Args:
        limit: Max bills to process (0 = all).
        dry_run: If True, only report targets without processing.

    Returns:
        Summary dict with processed/failed/skipped counts.
    """
    targets = await find_reprocess_targets()

    if limit:
        targets = targets[:limit]

    if not targets:
        logger.info("No bills found for reprocessing.")
        return {"processed": 0, "failed": 0, "skipped": 0, "total": 0}

    logger.info("Found %d bills for reprocessing.", len(targets))

    if dry_run:
        for bill_id, source_id, title, _ in targets:
            logger.info("  [DRY RUN] Would reprocess: %s - %s", source_id, title[:60])
        return {"processed": 0, "failed": 0, "skipped": 0, "total": len(targets)}

    processed = 0
    failed = 0
    skipped = 0

    for bill_id, source_id, title, summary_original in targets:
        if not summary_original:
            logger.warning("Skipping bill %s: no summary_original", source_id)
            skipped += 1
            continue

        try:
            summary_ai = await asyncio.to_thread(
                summarize_bill, title, summary_original, source_id
            )

            if not summary_ai:
                logger.warning("Summarization failed for bill %s", source_id)
                failed += 1
                await asyncio.sleep(BILL_DELAY_SECONDS)
                continue

            async with AsyncSessionLocal() as session:
                async with session.begin():
                    await session.execute(
                        Bill.__table__.update()
                        .where(Bill.id == bill_id)
                        .values(
                            summary_ai=summary_ai,
                            summarized_at=datetime.now(UTC).replace(tzinfo=None),
                        )
                    )

            processed += 1
            logger.info("Reprocessed bill %s: %s", source_id, title[:50])

        except Exception:
            logger.exception("Error reprocessing bill %s", source_id)
            failed += 1

        await asyncio.sleep(BILL_DELAY_SECONDS)

    result = {
        "processed": processed,
        "failed": failed,
        "skipped": skipped,
        "total": len(targets),
    }
    logger.info("Reprocessing complete: %s", result)
    return result


if __name__ == "__main__":
    import argparse

    import dotenv

    dotenv.load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        description="Reprocess bills with missing/malformed summary_ai"
    )
    parser.add_argument(
        "--limit", type=int, default=0, help="Max bills to process (0=all)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only report targets without processing",
    )
    args = parser.parse_args()

    result = asyncio.run(reprocess_summaries(limit=args.limit, dry_run=args.dry_run))
    print(f"Result: {result}")
