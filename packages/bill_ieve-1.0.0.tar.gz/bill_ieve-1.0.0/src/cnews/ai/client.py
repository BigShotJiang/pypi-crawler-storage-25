"""Anthropic client wrapper for cnews AI pipeline."""

from __future__ import annotations

import os

import anthropic


def get_anthropic_client() -> anthropic.Anthropic:
    """Return a configured Anthropic client.

    Raises:
        ValueError: If ANTHROPIC_API_KEY is not set.
    """
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not set")
    return anthropic.Anthropic(api_key=api_key)


MODEL = "claude-haiku-4-5-20251001"  # Claude Haiku 4.5
