"""Batch processing script — fetch unprocessed bills from DB and run AI pipeline."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime

from sqlalchemy import select, text

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill
from cnews.models.bill_industry import BillIndustry
from cnews.models.category import Category
from cnews.models.impact_report import ImpactReport
from cnews.models.industry_tag import IndustryTag

from .categorize import categorize_bill
from .impact import analyze_impact
from .industry import tag_industries
from .score import score_importance
from .summarize import summarize_bill

logger = logging.getLogger(__name__)

BILL_DELAY_SECONDS = 0.5


async def process_bills(limit: int = 50) -> dict:
    """Process unprocessed bills through the AI pipeline.

    Steps for each bill:
    1. summarize_bill -> summary_ai
    2. categorize_bill -> category_id
    3. score_importance -> importance_score
    4. tag_industries -> bill_industries
    5. analyze_impact -> impact_reports

    Returns a summary dict with processed/skipped/failed counts.
    """
    processed = 0
    skipped = 0
    failed = 0

    # Fetch bill IDs first
    async with AsyncSessionLocal() as session:
        stmt = (
            select(Bill.id, Bill.title_original, Bill.summary_original,
                   Bill.proposer, Bill.committee_name)
            .where(Bill.summary_ai.is_(None))
            .order_by(Bill.proposed_date.desc())
            .limit(limit)
        )
        result = await session.execute(stmt)
        bill_rows = result.all()

    if not bill_rows:
        logger.info("No unprocessed bills found.")
        return {"processed": 0, "skipped": 0, "failed": 0, "total": 0}

    logger.info("Found %d unprocessed bills.", len(bill_rows))

    for bill_id, title, summary, proposer, committee in bill_rows:
        try:
            # 1. Summarize
            summary_ai = await asyncio.to_thread(
                summarize_bill, title, summary
            )
            if not summary_ai:
                logger.warning("Summarization failed for bill %s, skipping.", bill_id)
                skipped += 1
                await asyncio.sleep(BILL_DELAY_SECONDS)
                continue

            # 2. Categorize
            category_code = await asyncio.to_thread(categorize_bill, title, summary)

            # 3. Score importance
            score = await asyncio.to_thread(
                score_importance, title, summary, proposer, committee
            )

            # 4. Tag industries
            industry_codes = await asyncio.to_thread(tag_industries, title, summary)

            # 5. Analyze impact
            impact = await asyncio.to_thread(
                analyze_impact, title, summary, industry_codes
            )

            # Write all results in a single transaction per bill
            async with AsyncSessionLocal() as session:
                async with session.begin():
                    # Update bill fields
                    update_stmt = (
                        Bill.__table__.update()
                        .where(Bill.id == bill_id)
                        .values(
                            summary_ai=summary_ai,
                            summarized_at=datetime.utcnow(),
                            importance_score=score,
                            importance_scored_at=datetime.utcnow() if score else None,
                        )
                    )
                    await session.execute(update_stmt)

                    # Category
                    if category_code:
                        cat_result = await session.execute(
                            select(Category.id).where(Category.code == category_code)
                        )
                        cat_id = cat_result.scalar_one_or_none()
                        if cat_id:
                            await session.execute(
                                Bill.__table__.update()
                                .where(Bill.id == bill_id)
                                .values(category_id=cat_id)
                            )

                    # Industry tags
                    for code in industry_codes:
                        tag_result = await session.execute(
                            select(IndustryTag.id).where(IndustryTag.code == code)
                        )
                        tag_id = tag_result.scalar_one_or_none()
                        if tag_id:
                            session.add(BillIndustry(
                                bill_id=bill_id,
                                industry_tag_id=tag_id,
                                relevance_score=1.0,
                            ))

                    # Impact report
                    if impact:
                        session.add(ImpactReport(
                            bill_id=bill_id,
                            financial_impact=impact["financial_impact"],
                            social_impact=impact["social_impact"],
                            impact_score=impact["impact_score"],
                            affected_industries=industry_codes,
                            model_version="claude-haiku-4-5-20251001",
                        ))

            processed += 1
            logger.info("Processed bill %s: %s", bill_id, title[:50])

        except Exception:
            logger.exception("Error processing bill %s", bill_id)
            failed += 1

        await asyncio.sleep(BILL_DELAY_SECONDS)

    return {
        "processed": processed,
        "skipped": skipped,
        "failed": failed,
        "total": len(bill_rows),
    }


if __name__ == "__main__":
    import dotenv

    dotenv.load_dotenv()
    logging.basicConfig(level=logging.INFO)
    result = asyncio.run(process_bills(limit=10))
    print(f"Result: {result}")
