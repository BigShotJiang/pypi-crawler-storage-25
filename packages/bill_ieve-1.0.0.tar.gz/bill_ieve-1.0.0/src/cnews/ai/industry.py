"""Industry tagging using Anthropic Claude."""

from __future__ import annotations

import json
import logging
import re

from . import sanitize_for_prompt
from .client import MODEL, get_anthropic_client
from .usage_tracker import tracker

logger = logging.getLogger(__name__)

VALID_INDUSTRY_CODES = frozenset(
    ["A", "C", "D", "F", "G", "H", "J", "K", "M", "N", "P", "Q"]
)


def tag_industries(title: str, summary: str | None, bill_id: str = "") -> list[str]:
    """Tag a bill with up to 3 related industry codes.

    Returns a list of valid industry code strings, or empty list on failure.
    """
    summary_text = summary or "요약 없음"
    safe_title = sanitize_for_prompt(title)
    safe_summary = sanitize_for_prompt(summary_text)

    prompt = (
        "아래 법안과 관련된 산업을 최대 3개까지 선택하세요: "
        "A(농업), C(제조), D(전기가스), F(건설), G(도소매), H(운수), "
        "J(IT), K(금융), M(전문과학), N(사업시설), P(교육), Q(보건복지). "
        f"법안 제목: {safe_title}, 요약: {safe_summary}. "
        '코드만 JSON 배열로 응답하세요. 예: ["J", "K"]'
    )

    try:
        client = get_anthropic_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=50,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}],
        )

        tracker.record(
            task_type="industry",
            bill_id=bill_id,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            model=MODEL,
        )

        raw = response.content[0].text.strip()
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        text = m.group(1).strip() if m else raw

        try:
            codes = json.loads(text)
            if not isinstance(codes, list):
                logger.warning("Industry tagging response is not a list: %s", text)
                return []
            # Filter to valid codes and limit to 3
            valid = [c for c in codes if isinstance(c, str) and c.upper() in VALID_INDUSTRY_CODES]
            return [c.upper() for c in valid[:3]]
        except json.JSONDecodeError:
            logger.warning("Failed to parse industry tagging response: %s", text)
            return []

    except Exception:
        logger.exception("Failed to call Anthropic API for industry tagging")
        return []
