"""Impact analysis using Anthropic Claude."""

from __future__ import annotations

import json
import logging
import re

from . import sanitize_for_prompt
from .client import MODEL, get_anthropic_client
from .usage_tracker import tracker

logger = logging.getLogger(__name__)


def analyze_impact(
    title: str,
    summary: str | None,
    industries: list[str],
    bill_id: str = "",
) -> dict | None:
    """Analyze financial and social impact of a bill.

    Returns a dict with keys: financial_impact, social_impact, impact_score.
    Returns None on API failure.
    """
    summary_text = summary or "요약 없음"
    safe_title = sanitize_for_prompt(title)
    safe_summary = sanitize_for_prompt(summary_text)
    industries_text = ", ".join(industries) if industries else "없음"

    prompt = (
        "다음 법안의 영향을 간략히 분석하세요.\n\n"
        f"법안 제목: {safe_title}\n"
        f"요약: {safe_summary}\n"
        f"영향 산업: {industries_text}\n\n"
        "요구사항:\n"
        "- 재정 영향: 이 법안이 관련 산업과 경제에 미치는 재정적 영향을 1~2문장으로 안내하세요.\n"
        "- 사회 영향: 이 법안이 국민 생활과 사회에 미치는 영향을 1~2문장으로 안내하세요.\n"
        '- "~할 것으로 보인다" 같은 추측 표현 금지. 사실 기반 서술만 허용.\n'
        "- 원문에 명시된 수치가 있으면 그대로 인용하세요.\n"
        "- 원문에 없는 수치를 추정하지 마세요.\n"
        "- 각 영향 항목의 강도를 1~5점으로 채점하세요 (Impact Radar 용).\n\n"
        "JSON 출력 형식:\n"
        "{\n"
        '  "financialImpact": "재정 영향 안내문 (1~2문장)",\n'
        '  "socialImpact": "사회 영향 안내문 (1~2문장)",\n'
        '  "radar": {\n'
        '    "economic": 4,\n'
        '    "industrial": 5,\n'
        '    "employment": 3,\n'
        '    "social": 2\n'
        "  }\n"
        "}\n\n"
        "JSON만 반환하세요. 추가 설명 없이."
    )

    try:
        client = get_anthropic_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=500,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}],
        )

        tracker.record(
            task_type="impact",
            bill_id=bill_id,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            model=MODEL,
        )

        raw = response.content[0].text.strip()
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        text = m.group(1).strip() if m else raw

        try:
            data = json.loads(text)
            radar = data.get("radar", {})
            # Compute average impact score from radar values
            radar_values = [
                radar.get("economic", 3),
                radar.get("industrial", 3),
                radar.get("employment", 3),
                radar.get("social", 3),
            ]
            impact_score = round(sum(radar_values) / len(radar_values))

            return {
                "financial_impact": data.get("financialImpact", ""),
                "social_impact": data.get("socialImpact", ""),
                "impact_score": max(1, min(5, impact_score)),
            }
        except (json.JSONDecodeError, KeyError):
            logger.warning("Failed to parse impact analysis response as JSON")
            return None

    except Exception:
        logger.exception("Failed to call Anthropic API for impact analysis")
        return None
