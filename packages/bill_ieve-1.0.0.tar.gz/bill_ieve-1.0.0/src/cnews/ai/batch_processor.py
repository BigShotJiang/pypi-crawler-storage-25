"""Anthropic Batch API processor for bulk bill AI analysis.

Submits batches per task type (summarize, categorize, score, industry, impact),
polls for completion, and writes results back to the database.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import UTC, datetime

from sqlalchemy import select

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill
from cnews.models.bill_industry import BillIndustry
from cnews.models.category import Category
from cnews.models.impact_report import ImpactReport
from cnews.models.industry_tag import IndustryTag

from . import sanitize_for_prompt
from .categorize import VALID_CATEGORIES
from .client import MODEL, get_anthropic_client
from .industry import VALID_INDUSTRY_CODES
from .usage_tracker import tracker

logger = logging.getLogger(__name__)

TASK_TYPES = ("summarize", "categorize", "score", "industry", "impact", "translate")

# Max tokens per task type
_MAX_TOKENS: dict[str, int] = {
    "summarize": 500,
    "categorize": 20,
    "score": 10,
    "industry": 50,
    "impact": 500,
    "translate": 600,
}


# ---------------------------------------------------------------------------
# Prompt builders (reuse exact prompts from individual modules)
# ---------------------------------------------------------------------------

def _build_prompt(task_type: str, bill: Bill) -> str:
    """Build the prompt string for a given task type and bill."""
    title = sanitize_for_prompt(bill.title_original)
    summary_text = sanitize_for_prompt(bill.summary_original or "요약 없음")

    if task_type == "summarize":
        return (
            "다음 법안을 뉴스 기사 형식으로 요약하세요.\n\n"
            f"법안명: {title}\n"
            f"제안이유: {summary_text}\n\n"
            "요구사항:\n"
            "- 첫 문장은 핵심 변경사항을 요약하는 뉴스 리드(lead)로 작성하세요.\n"
            "- 이어서 배경과 주요 내용을 자연스러운 흐름으로 서술하세요.\n"
            "- 전체 3~5문장, 200자 이내로 간결하게 작성하세요.\n"
            "- 뉴스 기사 문체: '~한다', '~했다', '~된다' 체를 사용하세요.\n"
            "- 금지: [배경], [주요내용], [기대효과] 같은 섹션 태그 사용 금지.\n"
            "- 금지: '~것임', '~있음', '~필요함', '~하려는 것이다', '~있는바' 같은 관료/법률 문체 사용 금지.\n"
            "- 금지: 제안이유 원문을 그대로 복사하지 마세요. 재구성하세요.\n"
            "- 전문 용어는 최소화하고, 일반 독자가 이해할 수 있게 쓰세요.\n"
            "- 순수한 텍스트만 반환하세요. JSON, 태그, 마크다운 금지.\n"
        )

    if task_type == "categorize":
        return (
            "아래 법안을 다음 카테고리 중 하나로 분류하세요: "
            "economy, tech, environment, security, welfare, justice, politics, industry. "
            f"법안 제목: {title}, 요약: {summary_text}. "
            "카테고리 코드만 응답하세요."
        )

    if task_type == "score":
        proposer_count = 1
        if bill.proposer:
            m = re.search(r"(\d+)\s*인", bill.proposer)
            if m:
                proposer_count = int(m.group(1))
        committee_name = bill.committee_name or "미정"
        return (
            "아래 법안의 사회적 중요도를 1~10점으로 채점하세요. "
            "기준: 영향 범위(국민 전체 vs 특정 집단), 경제적 규모, "
            "언론 관심도 예상, 기존 법체계 변경 폭. 숫자만 응답하세요.\n\n"
            f"법안 제목: {title}\n"
            f"요약: {summary_text}\n"
            f"발의자 수: {proposer_count}명\n"
            f"소관 위원회: {committee_name}"
        )

    if task_type == "industry":
        return (
            "아래 법안과 관련된 산업을 최대 3개까지 선택하세요: "
            "A(농업), C(제조), D(전기가스), F(건설), G(도소매), H(운수), "
            "J(IT), K(금융), M(전문과학), N(사업시설), P(교육), Q(보건복지). "
            f"법안 제목: {title}, 요약: {summary_text}. "
            '코드만 JSON 배열로 응답하세요. 예: ["J", "K"]\n'
            "코드 펜스(```)나 마크다운 없이 JSON 배열만 반환하세요."
        )

    if task_type == "impact":
        # impact needs industries — stored as comma-sep in custom_id is not ideal,
        # so we pass "없음" by default. Caller can enrich if needed.
        return (
            "다음 법안의 영향을 간략히 분석하세요.\n\n"
            f"법안 제목: {title}\n"
            f"요약: {summary_text}\n"
            f"영향 산업: 없음\n\n"
            "요구사항:\n"
            "- 재정 영향: 이 법안이 관련 산업과 경제에 미치는 재정적 영향을 1~2문장으로 안내하세요.\n"
            "- 사회 영향: 이 법안이 국민 생활과 사회에 미치는 영향을 1~2문장으로 안내하세요.\n"
            '- "~할 것으로 보인다" 같은 추측 표현 금지. 사실 기반 서술만 허용.\n'
            "- 원문에 명시된 수치가 있으면 그대로 인용하세요.\n"
            "- 원문에 없는 수치를 추정하지 마세요.\n"
            "- 각 영향 항목의 강도를 1~5점으로 채점하세요 (Impact Radar 용).\n\n"
            "JSON 출력 형식:\n"
            "{\n"
            '  "financialImpact": "재정 영향 안내문 (1~2문장)",\n'
            '  "socialImpact": "사회 영향 안내문 (1~2문장)",\n'
            '  "radar": {\n'
            '    "economic": 4,\n'
            '    "industrial": 5,\n'
            '    "employment": 3,\n'
            '    "social": 2\n'
            "  }\n"
            "}\n\n"
            "JSON만 반환하세요. 추가 설명 없이."
        )

    if task_type == "translate":
        return (
            "Translate and summarize the following legislation for Korean readers.\n\n"
            f"Title: {title}\n\n"
            "Requirements:\n"
            "1. Translate the title into natural Korean (한국어 제목).\n"
            "2. Write a 2-3 sentence news-style summary in Korean explaining what this law does.\n"
            "   - Use '~한다', '~했다', '~된다' style (뉴스 기사체).\n"
            "   - First sentence: core change. Second: context/impact.\n"
            "   - No bureaucratic language. No section tags.\n"
            "3. Classify into ONE category: economy, tech, environment, security, welfare, justice, politics, industry.\n\n"
            "Return JSON only (no markdown, no code fences):\n"
            '{"title_ko": "한국어 제목", "summary_ko": "한국어 요약 2-3문장", "category": "카테고리코드"}'
        )

    raise ValueError(f"Unknown task_type: {task_type}")


# ---------------------------------------------------------------------------
# Result parsers (mirror logic from individual modules)
# ---------------------------------------------------------------------------

def _extract_json(text: str) -> str:
    """Strip markdown code fences if present."""
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        return m.group(1).strip()
    return text.strip()


def _parse_summary(text: str) -> str | None:
    """Parse summarize response — now returns plain text directly."""
    cleaned = text.strip()
    if not cleaned:
        return None
    return cleaned


def _parse_category(text: str) -> str | None:
    """Extract a valid category code from response."""
    cleaned = text.strip().lower()
    if cleaned in VALID_CATEGORIES:
        return cleaned
    for cat in VALID_CATEGORIES:
        if cat in cleaned:
            return cat
    logger.warning("Invalid category response: %s", cleaned)
    return None


def _parse_score(text: str) -> int | None:
    """Extract numeric score from response."""
    m = re.search(r"(\d+)", text.strip())
    if not m:
        logger.warning("Could not parse AI score from: %s", text)
        return None
    score = int(m.group(1))
    return max(1, min(10, score))


def _parse_industries(text: str) -> list[str]:
    """Parse industry codes from JSON array response."""
    cleaned = _extract_json(text)
    try:
        codes = json.loads(cleaned)
        if not isinstance(codes, list):
            logger.warning("Industry response is not a list: %s", cleaned)
            return []
        valid = [c for c in codes if isinstance(c, str) and c.upper() in VALID_INDUSTRY_CODES]
        return [c.upper() for c in valid[:3]]
    except json.JSONDecodeError:
        logger.warning("Failed to parse industry response: %s", cleaned)
        return []


def _parse_translate(text: str) -> dict | None:
    """Parse translate response — expects JSON with title_ko, summary_ko, category."""
    cleaned = _extract_json(text)
    try:
        data = json.loads(cleaned)
        title_ko = data.get("title_ko", "").strip()
        summary_ko = data.get("summary_ko", "").strip()
        category = data.get("category", "").strip().lower()
        if not title_ko:
            logger.warning("Empty title_ko in translate response")
            return None
        result = {"title_ko": title_ko, "summary_ko": summary_ko}
        if category in VALID_CATEGORIES:
            result["category"] = category
        return result
    except json.JSONDecodeError:
        logger.warning("Failed to parse translate response: %s", cleaned[:100])
        return None


def _parse_impact(text: str) -> dict | None:
    """Parse impact analysis response."""
    cleaned = _extract_json(text)
    try:
        data = json.loads(cleaned)
        radar = data.get("radar", {})
        radar_values = [
            radar.get("economic", 3),
            radar.get("industrial", 3),
            radar.get("employment", 3),
            radar.get("social", 3),
        ]
        impact_score = round(sum(radar_values) / len(radar_values))
        return {
            "financial_impact": data.get("financialImpact", ""),
            "social_impact": data.get("socialImpact", ""),
            "impact_score": max(1, min(5, impact_score)),
        }
    except (json.JSONDecodeError, KeyError):
        logger.warning("Failed to parse impact response as JSON")
        return None


# ---------------------------------------------------------------------------
# Batch request creation
# ---------------------------------------------------------------------------

async def create_batch_requests(task_type: str, limit: int = 0) -> list[dict]:
    """Query DB for unprocessed bills and build batch request payloads.

    Filtering logic per task_type:
    - summarize: summary_ai IS NULL
    - categorize: category_id IS NULL
    - score: importance_score IS NULL OR importance_score = 0
    - industry: bills with no entries in bill_industries
    - impact: bills with no impact_report
    """
    async with AsyncSessionLocal() as session:
        if task_type == "summarize":
            stmt = select(Bill).where(Bill.summary_ai.is_(None))
        elif task_type == "categorize":
            stmt = select(Bill).where(Bill.category_id.is_(None))
        elif task_type == "score":
            stmt = select(Bill).where(
                (Bill.importance_score.is_(None)) | (Bill.importance_score == 0)
            )
        elif task_type == "industry":
            stmt = (
                select(Bill)
                .outerjoin(BillIndustry, Bill.id == BillIndustry.bill_id)
                .where(BillIndustry.id.is_(None))
            )
        elif task_type == "impact":
            stmt = (
                select(Bill)
                .outerjoin(ImpactReport, Bill.id == ImpactReport.bill_id)
                .where(ImpactReport.id.is_(None))
            )
        elif task_type == "translate":
            stmt = (
                select(Bill)
                .where(Bill.country.in_(["US", "EU"]))
                .where(Bill.headline_ai.is_(None))
            )
        else:
            raise ValueError(f"Unknown task_type: {task_type}")

        if limit:
            stmt = stmt.limit(limit)

        result = await session.execute(stmt)
        bills = result.scalars().all()

    requests = []
    for bill in bills:
        prompt = _build_prompt(task_type, bill)
        requests.append({
            "custom_id": f"{bill.source_id}__{task_type}",
            "params": {
                "model": MODEL,
                "max_tokens": _MAX_TOKENS[task_type],
                "temperature": 0.3,
                "messages": [{"role": "user", "content": prompt}],
            },
        })
    return requests


# ---------------------------------------------------------------------------
# Batch submission / status / results
# ---------------------------------------------------------------------------

def submit_batch(requests: list[dict]) -> str:
    """Submit a batch to Anthropic Batch API. Returns batch_id."""
    client = get_anthropic_client()
    batch = client.messages.batches.create(requests=requests)
    logger.info("Batch submitted: %s (%d requests)", batch.id, len(requests))
    return batch.id


def check_batch_status(batch_id: str) -> dict:
    """Retrieve current status of a batch."""
    client = get_anthropic_client()
    batch = client.messages.batches.retrieve(batch_id)
    return {
        "id": batch.id,
        "status": batch.processing_status,
        "request_counts": {
            "processing": batch.request_counts.processing,
            "succeeded": batch.request_counts.succeeded,
            "errored": batch.request_counts.errored,
        },
    }


async def process_batch_results(batch_id: str, task_type: str) -> dict:
    """Fetch completed batch results and write to DB.

    Returns dict with updated/failed counts.
    """
    client = get_anthropic_client()
    updated = 0
    failed = 0

    for result in client.messages.batches.results(batch_id):
        source_id = result.custom_id.split("__")[0]

        if result.result.type != "succeeded":
            logger.warning("Batch result failed for %s: %s", source_id, result.result.type)
            failed += 1
            continue

        text = result.result.message.content[0].text.strip()
        usage = result.result.message.usage

        # Track usage
        tracker.record(
            task_type=task_type,
            bill_id=source_id,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            model=MODEL,
        )

        try:
            if task_type == "summarize":
                summary_text = _parse_summary(text)
                if summary_text:
                    await _update_bill_field(
                        source_id,
                        summary_ai=summary_text,
                        summarized_at=datetime.now(UTC).replace(tzinfo=None),
                    )
                    updated += 1
                else:
                    failed += 1

            elif task_type == "categorize":
                code = _parse_category(text)
                if code:
                    await _update_bill_category(source_id, code)
                    updated += 1
                else:
                    failed += 1

            elif task_type == "score":
                ai_score = _parse_score(text)
                if ai_score is not None:
                    await _update_bill_field(
                        source_id,
                        importance_score=ai_score,
                        importance_scored_at=datetime.now(UTC).replace(tzinfo=None),
                    )
                    updated += 1
                else:
                    failed += 1

            elif task_type == "industry":
                codes = _parse_industries(text)
                if codes:
                    await _insert_bill_industries(source_id, codes)
                    updated += 1
                else:
                    failed += 1

            elif task_type == "impact":
                parsed = _parse_impact(text)
                if parsed:
                    await _insert_impact_report(source_id, parsed)
                    updated += 1
                else:
                    failed += 1

            elif task_type == "translate":
                parsed = _parse_translate(text)
                if parsed:
                    update_kwargs = {
                        "headline_ai": parsed["title_ko"],
                        "summary_ai": parsed["summary_ko"],
                        "summarized_at": datetime.now(UTC).replace(tzinfo=None),
                    }
                    await _update_bill_field(source_id, **update_kwargs)
                    # Also update category if present
                    if parsed.get("category"):
                        await _update_bill_category(source_id, parsed["category"])
                    updated += 1
                else:
                    failed += 1

        except Exception:
            logger.exception("Error processing result for %s/%s", source_id, task_type)
            failed += 1

    return {"updated": updated, "failed": failed}


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

async def _update_bill_field(source_id: str, **kwargs) -> None:
    """Update bill fields by source_id."""
    async with AsyncSessionLocal() as session:
        async with session.begin():
            result = await session.execute(
                select(Bill.id).where(Bill.source_id == source_id)
            )
            bill_id = result.scalar_one_or_none()
            if not bill_id:
                logger.warning("Bill not found for source_id: %s", source_id)
                return
            await session.execute(
                Bill.__table__.update().where(Bill.id == bill_id).values(**kwargs)
            )


async def _update_bill_category(source_id: str, category_code: str) -> None:
    """Look up category by code and set bill.category_id."""
    async with AsyncSessionLocal() as session:
        async with session.begin():
            bill_result = await session.execute(
                select(Bill.id).where(Bill.source_id == source_id)
            )
            bill_id = bill_result.scalar_one_or_none()
            if not bill_id:
                return

            cat_result = await session.execute(
                select(Category.id).where(Category.code == category_code)
            )
            cat_id = cat_result.scalar_one_or_none()
            if not cat_id:
                logger.warning("Category not found: %s", category_code)
                return

            await session.execute(
                Bill.__table__.update().where(Bill.id == bill_id).values(category_id=cat_id)
            )


async def _insert_bill_industries(source_id: str, codes: list[str]) -> None:
    """Insert bill_industries rows for the given industry codes."""
    async with AsyncSessionLocal() as session:
        async with session.begin():
            bill_result = await session.execute(
                select(Bill.id).where(Bill.source_id == source_id)
            )
            bill_id = bill_result.scalar_one_or_none()
            if not bill_id:
                return

            for code in codes:
                tag_result = await session.execute(
                    select(IndustryTag.id).where(IndustryTag.code == code)
                )
                tag_id = tag_result.scalar_one_or_none()
                if tag_id:
                    session.add(BillIndustry(
                        bill_id=bill_id,
                        industry_tag_id=tag_id,
                        relevance_score=1.0,
                    ))


async def _insert_impact_report(source_id: str, parsed: dict) -> None:
    """Insert an impact_report row for the bill."""
    async with AsyncSessionLocal() as session:
        async with session.begin():
            bill_result = await session.execute(
                select(Bill.id).where(Bill.source_id == source_id)
            )
            bill_id = bill_result.scalar_one_or_none()
            if not bill_id:
                return

            session.add(ImpactReport(
                bill_id=bill_id,
                financial_impact=parsed["financial_impact"],
                social_impact=parsed["social_impact"],
                impact_score=parsed["impact_score"],
                affected_industries=[],
                model_version=MODEL,
            ))


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

async def run_all_batches(limit: int = 0) -> dict:
    """Create and submit batches for all 5 task types.

    Returns a dict keyed by task_type with submission info.
    Does NOT wait for completion — use check_batch_status / process_batch_results
    separately (or a polling loop).
    """
    results = {}

    for task_type in TASK_TYPES:
        logger.info("Creating batch for: %s", task_type)
        requests = await create_batch_requests(task_type, limit)

        if not requests:
            logger.info("No pending bills for %s", task_type)
            results[task_type] = {"status": "skipped", "count": 0}
            continue

        batch_id = submit_batch(requests)
        results[task_type] = {
            "status": "submitted",
            "batch_id": batch_id,
            "count": len(requests),
        }
        logger.info(
            "Submitted %s batch: %s (%d requests)",
            task_type, batch_id, len(requests),
        )

    # Save usage report
    tracker.save_to_file("ai_batch_usage_report.json")
    logger.info(tracker.report())

    return results


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    import dotenv

    dotenv.load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="Anthropic Batch API processor")
    parser.add_argument(
        "--action",
        choices=["submit", "status", "results"],
        required=True,
        help="Action to perform",
    )
    parser.add_argument("--batch-id", help="Batch ID (for status/results)")
    parser.add_argument("--task-type", help="Task type (for results processing)")
    parser.add_argument("--limit", type=int, default=0, help="Limit bills per task (0=all)")
    args = parser.parse_args()

    if args.action == "submit":
        result = asyncio.run(run_all_batches(args.limit))
        print(json.dumps(result, indent=2))

    elif args.action == "status":
        if not args.batch_id:
            parser.error("--batch-id required for status action")
        status = check_batch_status(args.batch_id)
        print(json.dumps(status, indent=2))

    elif args.action == "results":
        if not args.batch_id or not args.task_type:
            parser.error("--batch-id and --task-type required for results action")
        result = asyncio.run(process_batch_results(args.batch_id, args.task_type))
        print(json.dumps(result, indent=2))
