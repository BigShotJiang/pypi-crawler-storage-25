"""Bill categorization using Anthropic Claude."""

from __future__ import annotations

import logging

from . import sanitize_for_prompt
from .client import MODEL, get_anthropic_client
from .usage_tracker import tracker

logger = logging.getLogger(__name__)

VALID_CATEGORIES = frozenset(
    ["economy", "tech", "environment", "security", "welfare", "justice", "politics", "industry"]
)


def categorize_bill(title: str, summary: str | None, bill_id: str = "") -> str | None:
    """Classify a bill into one of 8 categories.

    Returns the category code string, or None on failure / invalid response.
    """
    summary_text = summary or "요약 없음"
    safe_title = sanitize_for_prompt(title)
    safe_summary = sanitize_for_prompt(summary_text)

    prompt = (
        "아래 법안을 다음 카테고리 중 하나로 분류하세요: "
        "economy, tech, environment, security, welfare, justice, politics, industry. "
        f"법안 제목: {safe_title}, 요약: {safe_summary}. "
        "카테고리 코드만 응답하세요."
    )

    try:
        client = get_anthropic_client()
        response = client.messages.create(
            model=MODEL,
            max_tokens=20,
            temperature=0.3,
            messages=[{"role": "user", "content": prompt}],
        )

        tracker.record(
            task_type="categorize",
            bill_id=bill_id,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            model=MODEL,
        )

        text = response.content[0].text.strip().lower()

        if text in VALID_CATEGORIES:
            return text

        # Try to extract a valid category from the response
        for cat in VALID_CATEGORIES:
            if cat in text:
                return cat

        logger.warning("Invalid category response: %s", text)
        return None

    except Exception:
        logger.exception("Failed to call Anthropic API for categorization")
        return None
