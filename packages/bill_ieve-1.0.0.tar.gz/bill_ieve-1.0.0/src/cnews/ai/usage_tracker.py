"""AI API usage tracking for cost monitoring."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime

logger = logging.getLogger(__name__)

# Anthropic pricing (Batch API — 50% discount)
PRICING = {
    "claude-haiku-4-5-20251001": {
        "input_per_m": 0.40,   # $0.40/M input (batch: 50% of $0.80)
        "output_per_m": 2.00,  # $2.00/M output (batch: 50% of $4.00)
    },
}


@dataclass
class UsageRecord:
    """Single API call usage record."""

    task_type: str  # summarize, categorize, score, industry, impact
    bill_id: str
    input_tokens: int
    output_tokens: int
    model: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class UsageTracker:
    """Tracks API usage across multiple calls."""

    records: list[UsageRecord] = field(default_factory=list)

    def record(
        self,
        task_type: str,
        bill_id: str,
        input_tokens: int,
        output_tokens: int,
        model: str,
    ) -> None:
        """Record a single API call."""
        self.records.append(
            UsageRecord(
                task_type=task_type,
                bill_id=bill_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                model=model,
            )
        )

    def total_input_tokens(self) -> int:
        """Return total input tokens across all records."""
        return sum(r.input_tokens for r in self.records)

    def total_output_tokens(self) -> int:
        """Return total output tokens across all records."""
        return sum(r.output_tokens for r in self.records)

    def total_calls(self) -> int:
        """Return total number of API calls."""
        return len(self.records)

    def cost_usd(self, batch: bool = True) -> float:
        """Calculate total cost in USD.

        Args:
            batch: If True, use batch pricing (50% discount). Otherwise standard.
        """
        total = 0.0
        for r in self.records:
            pricing = PRICING.get(r.model)
            if not pricing:
                continue
            if batch:
                input_cost = (r.input_tokens / 1_000_000) * pricing["input_per_m"]
                output_cost = (r.output_tokens / 1_000_000) * pricing["output_per_m"]
            else:
                input_cost = (r.input_tokens / 1_000_000) * pricing["input_per_m"] * 2
                output_cost = (r.output_tokens / 1_000_000) * pricing["output_per_m"] * 2
            total += input_cost + output_cost
        return round(total, 4)

    def by_task_type(self) -> dict[str, dict]:
        """Group usage by task type."""
        groups: dict[str, dict] = {}
        for r in self.records:
            if r.task_type not in groups:
                groups[r.task_type] = {"calls": 0, "input_tokens": 0, "output_tokens": 0}
            groups[r.task_type]["calls"] += 1
            groups[r.task_type]["input_tokens"] += r.input_tokens
            groups[r.task_type]["output_tokens"] += r.output_tokens
        return groups

    def report(self, batch: bool = True) -> str:
        """Generate a human-readable cost report."""
        lines = [
            "=" * 50,
            "AI API Usage Report",
            "=" * 50,
            f"Total calls: {self.total_calls():,}",
            f"Input tokens: {self.total_input_tokens():,}",
            f"Output tokens: {self.total_output_tokens():,}",
            f"Pricing: {'Batch (50% off)' if batch else 'Standard'}",
            f"Total cost: ${self.cost_usd(batch):.4f}",
            "",
            "By task type:",
        ]
        for task, stats in self.by_task_type().items():
            lines.append(
                f"  {task}: {stats['calls']} calls, "
                f"{stats['input_tokens']:,} in / {stats['output_tokens']:,} out"
            )
        lines.append("=" * 50)
        return "\n".join(lines)

    def save_to_file(self, path: str = "ai_usage_report.json") -> None:
        """Save usage records to a JSON file."""
        data = {
            "generated_at": datetime.now(UTC).isoformat(),
            "total_calls": self.total_calls(),
            "total_input_tokens": self.total_input_tokens(),
            "total_output_tokens": self.total_output_tokens(),
            "cost_usd_batch": self.cost_usd(batch=True),
            "cost_usd_standard": self.cost_usd(batch=False),
            "by_task_type": self.by_task_type(),
            "records": [
                {
                    "task_type": r.task_type,
                    "bill_id": r.bill_id,
                    "input_tokens": r.input_tokens,
                    "output_tokens": r.output_tokens,
                    "model": r.model,
                    "timestamp": r.timestamp.isoformat(),
                }
                for r in self.records
            ],
        }
        with open(path, "w") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def reset(self) -> None:
        """Clear all records."""
        self.records.clear()


# Global tracker instance
tracker = UsageTracker()
