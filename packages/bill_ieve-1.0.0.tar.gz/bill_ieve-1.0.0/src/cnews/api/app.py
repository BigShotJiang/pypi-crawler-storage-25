"""Bill-ieve REST API — FastAPI application."""

from __future__ import annotations

import asyncio
import json
import os
import re
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from time import time

import logging

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import case, func, select, update
from sqlalchemy.orm import selectinload

from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill
from cnews.models.bill_industry import BillIndustry
from cnews.models.bill_minute import BillMinute
from cnews.models.bill_status_history import BillStatusHistory
from cnews.models.category import Category
from cnews.models.collection_log import CollectionLog
from cnews.models.daily_briefing import DailyBriefing
from cnews.models.enums import BillStatus, VoteResult
from cnews.models.impact_report import ImpactReport
from cnews.models.industry_tag import IndustryTag
from cnews.models.minute import Minute
from cnews.models.petition import Petition
from cnews.models.speech import Speech
from cnews.models.vote import Vote
from cnews.models.member import Member


logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan — start/stop APScheduler if enabled."""
    scheduler = None
    enable = os.getenv("ENABLE_SCHEDULER", "true").lower() in ("true", "1", "yes")

    if enable:
        from cnews.scheduler import create_scheduler

        scheduler = create_scheduler()
        scheduler.start()
        jobs = scheduler.get_jobs()
        logger.info("Scheduler started with %d jobs", len(jobs))
        for job in jobs:
            logger.info("  %s: next run at %s", job.name, job.next_run_time)
    else:
        logger.info("Scheduler disabled (ENABLE_SCHEDULER=%s)", os.getenv("ENABLE_SCHEDULER"))

    yield

    if scheduler is not None:
        scheduler.shutdown()
        logger.info("Scheduler stopped.")


app = FastAPI(title="Bill-ieve API", version="0.1.0", lifespan=lifespan)

# MCP server: 별도 프로세스로 실행 (uv run bill-ieve)
# Railway에 마운트하면 ASGI 충돌 발생 → 추후 별도 서비스로 배포 예정

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://dev.bill-ieve.com",
        "https://bill-ieve.com",
        "https://www.bill-ieve.com",
        "http://localhost:3000",
        "http://localhost:3001",
    ],
    allow_credentials=True,
    allow_methods=["GET", "OPTIONS"],
    allow_headers=["content-type", "accept"],
)

_rate_limit_store: dict[str, list[float]] = defaultdict(list)
RATE_LIMIT = 100  # requests per minute
RATE_WINDOW = 60  # seconds


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    now = time()
    # Clean old entries
    _rate_limit_store[client_ip] = [t for t in _rate_limit_store[client_ip] if now - t < RATE_WINDOW]
    if len(_rate_limit_store[client_ip]) >= RATE_LIMIT:
        return JSONResponse(status_code=429, content={
            "success": False,
            "error": {"code": "RATE_LIMITED", "message": "요청 한도를 초과했습니다. 1분 후 다시 시도해주세요."},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
    _rate_limit_store[client_ip].append(now)
    return await call_next(request)


@app.middleware("http")
async def timeout_middleware(request: Request, call_next):
    try:
        return await asyncio.wait_for(call_next(request), timeout=30.0)
    except asyncio.TimeoutError:
        return JSONResponse(status_code=504, content={
            "success": False,
            "error": {"code": "TIMEOUT", "message": "요청 처리 시간이 초과되었습니다"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })


def _serialize(obj: object) -> str:
    """Default serializer for json.dumps (handles datetime etc.)."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    return str(obj)


def success_response(data: dict) -> dict:
    """Wrap data in standard success envelope."""
    return {
        "success": True,
        "data": data,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def error_response(code: str, message: str, status_code: int = 500):
    """Raise HTTPException with standard error envelope."""
    raise HTTPException(
        status_code=status_code,
        detail={
            "success": False,
            "error": {"code": code, "message": message},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    )


def _escape_like(value: str) -> str:
    """Escape LIKE wildcard characters to prevent wildcard injection."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _bill_summary(
    bill: Bill,
    status_date: str | None = None,
    vote_counts: dict | None = None,
    industry_tags: list[dict] | None = None,
) -> dict:
    result = {
        "id": bill.source_id,
        "title": bill.title_original,
        "proposer": bill.proposer,
        "proposed_date": bill.proposed_date.strftime("%Y-%m-%d") if bill.proposed_date else None,
        "status": bill.status.value if isinstance(bill.status, BillStatus) else str(bill.status),
        "status_date": status_date,
        "committee": bill.committee_name,
        "link": bill.source_url,
        "category_code": bill.category.code if bill.category else None,
        "category_name": bill.category.name_ko if bill.category else None,
        "summary_ai": bill.summary_ai,
        "headline_ai": bill.headline_ai,
        "bullet_summary": bill.bullet_summary,
        "importance_score": bill.importance_score,
        "view_count": bill.view_count,
        "industry_tags": industry_tags or [],
    }
    if vote_counts:
        result["has_vote"] = True
        result["vote_yes"] = vote_counts.get("YES", 0)
        result["vote_no"] = vote_counts.get("NO", 0)
        result["vote_abstain"] = vote_counts.get("ABSTAIN", 0)
    else:
        result["has_vote"] = False
    return result


def _bill_detail(bill: Bill) -> dict:
    return {
        "id": bill.source_id,
        "title": bill.title_original,
        "summary": bill.summary_original,
        "proposer": bill.proposer,
        "proposed_date": bill.proposed_date.strftime("%Y-%m-%d") if bill.proposed_date else None,
        "status": bill.status.value if isinstance(bill.status, BillStatus) else str(bill.status),
        "committee_id": bill.committee_id,
        "committee": bill.committee_name,
        "link": bill.source_url,
        "category_id": bill.category_id,
        "category_code": bill.category.code if bill.category else None,
        "category_name": bill.category.name_ko if bill.category else None,
        "summary_ai": bill.summary_ai,
        "headline_ai": bill.headline_ai,
        "bullet_summary": bill.bullet_summary,
        "importance_score": bill.importance_score,
        "view_count": bill.view_count,
        "collected_at": bill.collected_at.isoformat() if bill.collected_at else None,
        "updated_at": bill.updated_at.isoformat() if bill.updated_at else None,
    }


@app.get("/api/health")
async def health():
    """헬스 체크"""
    return {"status": "ok"}


@app.get("/api/stats/summary")
async def stats_summary():
    """통계 요약 — KPI 4종 + 카테고리별 분포 + 오늘의 입법 활동"""
    try:
        async with AsyncSessionLocal() as session:
            from datetime import timedelta

            # 1) Status-based counts
            status_counts_stmt = (
                select(Bill.status, func.count().label("cnt"))
                .group_by(Bill.status)
            )
            status_result = await session.execute(status_counts_stmt)
            status_map: dict[str, int] = {}
            total_bills = 0
            for row in status_result:
                status_val = row.status.value if isinstance(row.status, BillStatus) else str(row.status)
                status_map[status_val] = row.cnt
                total_bills += row.cnt

            passed_bills = status_map.get("PASSED", 0)
            in_committee = status_map.get("COMMITTEE", 0)

            # 2) proposed_today: bills with proposed_date = today (KST)
            now_utc = datetime.now(timezone.utc)
            kst_now = now_utc + timedelta(hours=9)
            today_kst = kst_now.date()
            proposed_today_stmt = (
                select(func.count())
                .select_from(Bill)
                .where(func.date(Bill.proposed_date) == today_kst)
            )
            proposed_today_result = await session.execute(proposed_today_stmt)
            proposed_today = proposed_today_result.scalar() or 0

            # 3) Category distribution
            cat_stmt = (
                select(Category.code, Category.name_ko, func.count().label("cnt"))
                .join(Bill, Bill.category_id == Category.id)
                .group_by(Category.code, Category.name_ko)
                .order_by(func.count().desc())
            )
            cat_result = await session.execute(cat_stmt)
            categories = [
                {"code": row.code, "name": row.name_ko, "count": row.cnt}
                for row in cat_result
            ]

            # 4) Passed-only category distribution
            passed_cat_stmt = (
                select(Category.code, Category.name_ko, func.count().label("cnt"))
                .join(Bill, Bill.category_id == Category.id)
                .where(Bill.status == BillStatus.PASSED)
                .group_by(Category.code, Category.name_ko)
                .order_by(func.count().desc())
            )
            passed_cat_result = await session.execute(passed_cat_stmt)
            passed_categories = [
                {"code": row.code, "name": row.name_ko, "count": row.cnt}
                for row in passed_cat_result
            ]

            # 5) Today's activity — separate try to avoid breaking stats
            try:
                cutoff_24h = datetime.now(timezone.utc) - timedelta(hours=24)
                activity_stmt = (
                    select(
                        func.coalesce(func.sum(CollectionLog.new_bills_count), 0).label("new_bills"),
                        func.coalesce(func.sum(CollectionLog.updated_bills_count), 0).label("updated_bills"),
                    )
                    .where(CollectionLog.collected_at >= cutoff_24h)
                    .where(CollectionLog.status == "success")
                )
                activity_result = await session.execute(activity_stmt)
                activity_row = activity_result.one()
                today_activity = {"new_bills": activity_row.new_bills, "updated_bills": activity_row.updated_bills}
            except Exception:
                today_activity = {"new_bills": 0, "updated_bills": 0}

            return success_response({
                "total_bills": total_bills,
                "passed_bills": passed_bills,
                "in_committee": in_committee,
                "proposed_today": proposed_today,
                "status_distribution": status_map,
                "categories": categories,
                "passed_categories": passed_categories,
                "today_activity": today_activity,
            })
    except Exception as exc:
        logger.exception("REST API stats_summary error")
        error_response("INTERNAL_ERROR", "통계 조회 중 오류가 발생했습니다", 500)


@app.get("/api/stats/categories")
async def stats_categories():
    """카테고리별 법안 수 + 통과 법안 수 집계"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = (
                select(
                    Category.code,
                    Category.name_ko,
                    func.count(Bill.id).label("total"),
                    func.count(case((Bill.status == "PASSED", 1))).label("passed"),
                )
                .join(Bill, Bill.category_id == Category.id)
                .group_by(Category.code, Category.name_ko)
                .order_by(func.count(Bill.id).desc())
            )
            result = await session.execute(stmt)
            rows = result.all()

            return success_response({
                "categories": [
                    {
                        "code": r.code,
                        "name": r.name_ko,
                        "total": r.total,
                        "passed": r.passed,
                    }
                    for r in rows
                ]
            })
    except Exception as exc:
        logger.exception("stats_categories error")
        error_response("INTERNAL_ERROR", "카테고리 통계 조회 중 오류가 발생했습니다", 500)


@app.get("/api/bills")
async def search_bills(
    query: str = Query(default="", max_length=200, description="검색어"),
    status: str = Query(default="all", description="법안 상태 필터"),
    category: str = Query(default="all", description="카테고리 코드 필터"),
    since: str = Query(default="", description="이 날짜 이후 법안만 (YYYY-MM-DD)"),
    sort: str = Query(default="proposed_date", description="정렬 기준 (proposed_date | status_date | view_count)"),
    country: str = Query(default="KR", description="국가 필터 (KR | US | EU)"),
    limit: int = Query(default=10, ge=1, le=100, description="반환 건수"),
    offset: int = Query(default=0, ge=0, description="오프셋"),
):
    """법안 검색"""
    allowed_sorts = {"proposed_date", "status_date", "view_count"}
    if sort not in allowed_sorts:
        error_response("BAD_REQUEST", "유효하지 않은 정렬 기준입니다", 400)

    try:
        async with AsyncSessionLocal() as session:
            conditions = [Bill.country == country.upper()]

            if query:
                escaped = _escape_like(query)
                conditions.append(
                    (Bill.title_original.ilike(f"%{escaped}%", escape="\\"))
                    | (Bill.proposer.ilike(f"%{escaped}%", escape="\\"))
                )

            if status != "all":
                try:
                    bill_status = BillStatus(status.upper())
                except ValueError:
                    error_response("BAD_REQUEST", "유효하지 않은 상태 값입니다", 400)
                conditions.append(Bill.status == bill_status)

            if since:
                try:
                    since_date = datetime.strptime(since, "%Y-%m-%d")
                    conditions.append(Bill.proposed_date >= since_date)
                except ValueError:
                    error_response("BAD_REQUEST", "유효하지 않은 날짜 형식입니다", 400)

            if category != "all":
                # Join with Category to filter by code
                cat_subquery = select(Category.id).where(Category.code == category).scalar_subquery()
                conditions.append(Bill.category_id == cat_subquery)

            count_stmt = select(func.count()).select_from(Bill)
            if conditions:
                count_stmt = count_stmt.where(*conditions)
            total_result = await session.execute(count_stmt)
            total = total_result.scalar() or 0

            if sort == "status_date":
                # Sort by latest status history date (status_date) descending
                latest_status_subq = (
                    select(
                        BillStatusHistory.bill_id,
                        func.max(BillStatusHistory.changed_at).label("latest_status_date"),
                    )
                    .group_by(BillStatusHistory.bill_id)
                    .subquery()
                )
                stmt = (
                    select(Bill)
                    .options(selectinload(Bill.category))
                    .outerjoin(latest_status_subq, Bill.id == latest_status_subq.c.bill_id)
                    .order_by(latest_status_subq.c.latest_status_date.desc().nulls_last())
                    .limit(limit)
                    .offset(offset)
                )
            elif sort == "view_count":
                stmt = (
                    select(Bill)
                    .options(selectinload(Bill.category))
                    .order_by(Bill.view_count.desc())
                    .limit(limit)
                    .offset(offset)
                )
            else:
                stmt = (
                    select(Bill)
                    .options(selectinload(Bill.category))
                    .order_by(Bill.proposed_date.desc())
                    .limit(limit)
                    .offset(offset)
                )
            if conditions:
                stmt = stmt.where(*conditions)
            result = await session.execute(stmt)
            bills = result.scalars().all()

            # Batch-fetch latest status history date for each bill
            status_dates: dict[str, str] = {}
            vote_counts_map: dict[str, dict] = {}
            if bills:
                bill_ids = [b.id for b in bills]
                latest_history_stmt = (
                    select(
                        BillStatusHistory.bill_id,
                        func.max(BillStatusHistory.changed_at).label("latest_date"),
                    )
                    .where(BillStatusHistory.bill_id.in_(bill_ids))
                    .group_by(BillStatusHistory.bill_id)
                )
                history_result = await session.execute(latest_history_stmt)
                for row in history_result:
                    if row.latest_date:
                        status_dates[row.bill_id] = row.latest_date.strftime("%Y-%m-%d")

                # Batch-fetch vote counts per bill
                vote_count_stmt = (
                    select(
                        Vote.bill_id,
                        Vote.vote_result,
                        func.count().label("cnt"),
                    )
                    .where(Vote.bill_id.in_(bill_ids))
                    .group_by(Vote.bill_id, Vote.vote_result)
                )
                vote_result = await session.execute(vote_count_stmt)
                for row in vote_result:
                    if row.bill_id not in vote_counts_map:
                        vote_counts_map[row.bill_id] = {}
                    vote_counts_map[row.bill_id][row.vote_result.value] = row.cnt

                # Batch-fetch industry tags per bill
                industry_stmt = (
                    select(
                        BillIndustry.bill_id,
                        IndustryTag.code,
                        IndustryTag.name,
                    )
                    .join(IndustryTag, BillIndustry.industry_tag_id == IndustryTag.id)
                    .where(BillIndustry.bill_id.in_(bill_ids))
                    .order_by(BillIndustry.relevance_score.desc())
                )
                industry_result = await session.execute(industry_stmt)
                industry_tags_map: dict[str, list[dict]] = {}
                for row in industry_result:
                    if row.bill_id not in industry_tags_map:
                        industry_tags_map[row.bill_id] = []
                    industry_tags_map[row.bill_id].append(
                        {"code": row.code, "name": row.name}
                    )

            return success_response({
                "bills": [
                    _bill_summary(
                        b,
                        status_date=status_dates.get(b.id),
                        vote_counts=vote_counts_map.get(b.id),
                        industry_tags=industry_tags_map.get(b.id),
                    )
                    for b in bills
                ],
                "total": total,
                "has_more": (offset + limit) < total,
            })
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("REST API search_bills error")
        error_response("INTERNAL_ERROR", "검색 중 오류가 발생했습니다", 500)


@app.get("/api/bills/popular")
async def get_popular_bills(
    limit: int = Query(default=5, ge=1, le=20, description="반환 건수"),
    country: str = Query(default="KR", description="국가 필터 (KR | US | EU)"),
):
    """조회수 기준 인기 법안 (PASSED 상태만)"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = (
                select(Bill)
                .options(selectinload(Bill.category))
                .where(Bill.country == country.upper())
                .where(Bill.status == BillStatus.PASSED)
                .order_by(Bill.view_count.desc())
                .limit(limit)
            )
            result = await session.execute(stmt)
            bills = result.scalars().all()

            return success_response({
                "bills": [
                    {
                        "id": b.source_id,
                        "title": b.title_original,
                        "headline_ai": b.headline_ai,
                        "category_code": b.category.code if b.category else None,
                        "category_name": b.category.name_ko if b.category else None,
                        "view_count": b.view_count,
                    }
                    for b in bills
                ],
            })
    except Exception as exc:
        logger.exception("REST API get_popular_bills error")
        error_response("INTERNAL_ERROR", "인기 법안 조회 중 오류가 발생했습니다", 500)


@app.get("/api/bills/headlines")
async def bill_headlines(
    country: str = Query(default="KR", description="국가 필터 (KR | US | EU)"),
):
    """뉴스홈 헤드라인 5개 — 다양한 기준으로 선정"""
    try:
        async with AsyncSessionLocal() as session:
            country_upper = country.upper()
            used_ids: set[str] = set()
            headlines: list[dict] = []

            async def pick_one(stmt, tag: str):
                """쿼리에서 중복 제외 후 1건 선택, status_date 포함"""
                stmt = stmt.where(Bill.country == country_upper).where(Bill.summary_ai.isnot(None))
                if used_ids:
                    stmt = stmt.where(Bill.source_id.notin_(used_ids))
                result = await session.execute(stmt.limit(1))
                bill = result.scalar_one_or_none()
                if bill:
                    used_ids.add(bill.source_id)
                    # status_date 조회
                    sd_result = await session.execute(
                        select(func.max(BillStatusHistory.changed_at))
                        .where(BillStatusHistory.bill_id == bill.id)
                    )
                    sd = sd_result.scalar()
                    sd_str = sd.strftime("%Y-%m-%d") if sd else None
                    headlines.append({"bill": _bill_summary(bill, status_date=sd_str), "tag": tag})

            # 1. 최신 법안
            await pick_one(
                select(Bill).options(selectinload(Bill.category))
                .order_by(Bill.proposed_date.desc()),
                "최신",
            )

            # 2. 조회수 최다 (통과 법안)
            await pick_one(
                select(Bill).options(selectinload(Bill.category))
                .where(Bill.status == BillStatus.PASSED)
                .order_by(Bill.view_count.desc()),
                "인기",
            )

            # 3. 표결 있는 최신
            await pick_one(
                select(Bill).options(selectinload(Bill.category))
                .where(Bill.id.in_(select(Vote.bill_id).distinct()))
                .order_by(Bill.proposed_date.desc()),
                "표결",
            )

            # 4. 공동발의 최다 — proposer에서 "등 N인" 추출
            # SQL로 하기 어려우므로, 최근 200건에서 Python으로 추출
            recent_stmt = (
                select(Bill).options(selectinload(Bill.category))
                .where(Bill.country == country_upper)
                .where(Bill.summary_ai.isnot(None))
                .order_by(Bill.proposed_date.desc())
                .limit(200)
            )
            if used_ids:
                recent_stmt = recent_stmt.where(Bill.source_id.notin_(used_ids))
            recent_result = await session.execute(recent_stmt)
            recent_bills = recent_result.scalars().all()

            max_count = 0
            best_bill = None
            for b in recent_bills:
                if b.proposer:
                    m = re.search(r"(\d+)\s*인", b.proposer)
                    if m and int(m.group(1)) > max_count:
                        max_count = int(m.group(1))
                        best_bill = b
            if best_bill:
                used_ids.add(best_bill.source_id)
                sd_result = await session.execute(
                    select(func.max(BillStatusHistory.changed_at))
                    .where(BillStatusHistory.bill_id == best_bill.id)
                )
                sd = sd_result.scalar()
                sd_str = sd.strftime("%Y-%m-%d") if sd else None
                headlines.append({"bill": _bill_summary(best_bill, status_date=sd_str), "tag": "공동발의"})

            # 5. 최신 발의 (미통과)
            await pick_one(
                select(Bill).options(selectinload(Bill.category))
                .where(Bill.status != BillStatus.PASSED)
                .order_by(Bill.proposed_date.desc()),
                "새 발의",
            )

            return success_response({"headlines": headlines})
    except Exception:
        logger.exception("bill_headlines error")
        error_response("INTERNAL_ERROR", "헤드라인 조회 중 오류가 발생했습니다", 500)


@app.get("/api/bills/news-feed")
async def bills_news_feed(
    limit: int = Query(default=10, ge=1, le=50),
    country: str = Query(default="KR", description="국가 필터 (KR | US | EU)"),
):
    """뉴스홈 카드뉴스용 — 동일 법명 그루핑, 대표 1건 + 유사 건수"""
    try:
        async with AsyncSessionLocal() as session:
            # 1) DB에서 그루핑 + 카운트 (단일 쿼리)
            group_stmt = (
                select(
                    Bill.title_original,
                    func.count().label("cnt"),
                    func.max(Bill.id).label("rep_id"),
                )
                .where(Bill.country == country.upper())
                .where(Bill.status == BillStatus.PASSED)
                .where(Bill.summary_ai.isnot(None))
                .group_by(Bill.title_original)
                .order_by(func.max(Bill.proposed_date).desc())
                .limit(limit)
            )
            group_result = await session.execute(group_stmt)
            groups = group_result.all()

            if not groups:
                return success_response({"bills": [], "total": 0})

            # 2) 대표 법안만 조회 (N건, selectinload 1회)
            rep_ids = [g.rep_id for g in groups]
            bill_stmt = (
                select(Bill)
                .options(selectinload(Bill.category))
                .where(Bill.id.in_(rep_ids))
            )
            bill_result = await session.execute(bill_stmt)
            bill_map = {b.id: b for b in bill_result.scalars().all()}

            # 3) 순서 유지하며 결과 조립
            feed = []
            for g in groups:
                bill = bill_map.get(g.rep_id)
                if bill:
                    bill_data = _bill_summary(bill)
                    bill_data["similar_count"] = g.cnt - 1
                    feed.append(bill_data)

            return success_response({"bills": feed, "total": len(groups)})
    except Exception:
        logger.exception("bills_news_feed error")
        error_response("INTERNAL_ERROR", "뉴스 피드 조회 중 오류가 발생했습니다", 500)


@app.get("/api/bills/{source_id}")
async def get_bill_detail(source_id: str):
    """법안 상세 조회"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = select(Bill).options(selectinload(Bill.category)).where(Bill.source_id == source_id)
            result = await session.execute(stmt)
            bill = result.scalar_one_or_none()

            if bill is None:
                error_response("NOT_FOUND", "해당 법안을 찾을 수 없습니다", 404)

            # Build detail BEFORE commit to avoid lazy-load after expire
            detail = _bill_detail(bill)

            # Increment view count (atomic DB-level to avoid race condition)
            await session.execute(
                update(Bill).where(Bill.id == bill.id).values(view_count=Bill.view_count + 1)
            )
            await session.commit()

            # Fetch status history
            history_stmt = (
                select(BillStatusHistory)
                .where(BillStatusHistory.bill_id == bill.id)
                .order_by(BillStatusHistory.changed_at.desc())
            )
            history_result = await session.execute(history_stmt)
            history_rows = history_result.scalars().all()

            detail["status_history"] = [
                {
                    "status": h.status.value if isinstance(h.status, BillStatus) else str(h.status),
                    "changed_at": h.changed_at.isoformat() if h.changed_at else None,
                    "description": h.description,
                }
                for h in history_rows
            ]

            # Fetch vote data
            vote_stmt = (
                select(Vote, Member.name, Member.party)
                .join(Member, Vote.member_id == Member.id)
                .where(Vote.bill_id == bill.id)
                .order_by(Member.party, Member.name)
            )
            vote_result = await session.execute(vote_stmt)
            vote_rows = vote_result.all()

            if vote_rows:
                yes_count = sum(1 for v, _, _ in vote_rows if v.vote_result == VoteResult.YES)
                no_count = sum(1 for v, _, _ in vote_rows if v.vote_result == VoteResult.NO)
                abstain_count = sum(1 for v, _, _ in vote_rows if v.vote_result == VoteResult.ABSTAIN)
                absent_count = sum(1 for v, _, _ in vote_rows if v.vote_result == VoteResult.ABSENT)
                total_votes = len(vote_rows)

                # vote_date from the first vote
                first_vote = vote_rows[0][0]
                vote_date_str = first_vote.vote_date.isoformat() if first_vote.vote_date else None

                # 가결 = 찬성이 재적(total)의 과반
                is_passed = yes_count > (total_votes / 2)

                detail["vote_summary"] = {
                    "total": total_votes,
                    "yes": yes_count,
                    "no": no_count,
                    "abstain": abstain_count,
                    "absent": absent_count,
                    "vote_date": vote_date_str,
                    "result": "가결" if is_passed else "부결",
                }
                detail["votes"] = [
                    {
                        "member_name": member_name,
                        "party": party,
                        "vote_result": v.vote_result.value,
                        "vote_date": v.vote_date.isoformat() if v.vote_date else None,
                    }
                    for v, member_name, party in vote_rows
                ]

            # Fetch impact report
            impact_stmt = (
                select(ImpactReport)
                .where(ImpactReport.bill_id == bill.id)
            )
            impact_result = await session.execute(impact_stmt)
            impact = impact_result.scalar_one_or_none()

            if impact:
                detail["impact_report"] = {
                    "impact_score": impact.impact_score,
                    "affected_industries": impact.affected_industries or [],
                    "financial_impact": impact.financial_impact,
                    "social_impact": impact.social_impact,
                }

            # Fetch industry tags via bill_industries join
            industry_stmt = (
                select(IndustryTag.code, IndustryTag.name)
                .join(BillIndustry, BillIndustry.industry_tag_id == IndustryTag.id)
                .where(BillIndustry.bill_id == bill.id)
                .order_by(BillIndustry.relevance_score.desc())
            )
            industry_result = await session.execute(industry_stmt)
            industry_rows = industry_result.all()

            if industry_rows:
                detail["industry_tags"] = [
                    {"code": row.code, "name": row.name}
                    for row in industry_rows
                ]

            # Fetch related minutes via bill_minutes join
            bm_stmt = (
                select(BillMinute)
                .where(BillMinute.bill_id == bill.id)
            )
            bm_result = await session.execute(bm_stmt)
            bill_minutes_rows = bm_result.scalars().all()

            if bill_minutes_rows:
                minute_ids = [bm.minute_id for bm in bill_minutes_rows]
                minutes_stmt = (
                    select(Minute)
                    .where(Minute.id.in_(minute_ids))
                    .order_by(Minute.meeting_date.desc())
                )
                minutes_result = await session.execute(minutes_stmt)
                related_minutes_list = minutes_result.scalars().all()
                detail["related_minutes"] = [
                    {
                        "id": m.minute_id,
                        "title": m.title,
                        "meeting_date": m.meeting_date.strftime("%Y-%m-%d") if m.meeting_date else None,
                        "committee_name": m.committee_name,
                        "meeting_type": m.meeting_type,
                    }
                    for m in related_minutes_list
                ]
            elif bill.committee_name:
                # Fallback: same committee, most recent 5
                fallback_stmt = (
                    select(Minute)
                    .where(Minute.committee_name == bill.committee_name)
                    .order_by(Minute.meeting_date.desc())
                    .limit(5)
                )
                fallback_result = await session.execute(fallback_stmt)
                fallback_minutes = fallback_result.scalars().all()
                if fallback_minutes:
                    detail["related_minutes"] = [
                        {
                            "id": m.minute_id,
                            "title": m.title,
                            "meeting_date": m.meeting_date.strftime("%Y-%m-%d") if m.meeting_date else None,
                            "committee_name": m.committee_name,
                            "meeting_type": m.meeting_type,
                        }
                        for m in fallback_minutes
                    ]

            # Fetch related petitions (same committee, top 3 by agree_count)
            if bill.committee_name:
                petition_stmt = (
                    select(Petition)
                    .where(Petition.committee_name == bill.committee_name)
                    .order_by(Petition.agree_count.desc())
                    .limit(3)
                )
                petition_result = await session.execute(petition_stmt)
                related_petitions = petition_result.scalars().all()

                if related_petitions:
                    detail["related_petitions"] = [
                        {
                            "id": p.id,
                            "title": p.title,
                            "agree_count": p.agree_count,
                            "petition_kind": p.petition_kind,
                            "source_url": p.source_url,
                            "petition_date": (
                                p.petition_date.strftime("%Y-%m-%d")
                                if p.petition_date
                                else None
                            ),
                        }
                        for p in related_petitions
                    ]

            return success_response(detail)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("REST API get_bill_detail error")
        error_response("INTERNAL_ERROR", "조회 중 오류가 발생했습니다", 500)


# ── Petition endpoints (removable) ────────────────────────────────────────


@app.get("/api/petitions")
async def list_petitions():
    """청원 목록 — 동의 수 내림차순 정렬"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = select(Petition).order_by(Petition.agree_count.desc())
            result = await session.execute(stmt)
            petitions = result.scalars().all()

            return success_response({
                "petitions": [
                    {
                        "id": p.id,
                        "title": p.title,
                        "agree_count": p.agree_count,
                        "target_count": p.target_count,
                        "status": p.status,
                        "petition_date": (
                            p.petition_date.strftime("%Y-%m-%d")
                            if p.petition_date
                            else None
                        ),
                        "source_url": p.source_url,
                        "committee_name": p.committee_name,
                        "petitioner": p.petitioner,
                        "progress": (
                            round(p.agree_count / p.target_count * 100, 1)
                            if p.target_count and p.target_count > 0
                            else None
                        ),
                    }
                    for p in petitions
                ],
                "total": len(petitions),
            })
    except Exception as exc:
        logger.exception("REST API list_petitions error")
        error_response("INTERNAL_ERROR", "청원 조회 중 오류가 발생했습니다", 500)


# ── Minutes endpoints ──────────────────────────────────────────────────


@app.get("/api/minutes/recent")
async def recent_minutes(
    days: int = Query(default=7, ge=1, le=30, description="최근 N일"),
    limit: int = Query(default=10, ge=1, le=50, description="반환 건수"),
):
    """최근 N일 회의록 조회 — 최신순 정렬"""
    try:
        async with AsyncSessionLocal() as session:
            from datetime import timedelta

            cutoff = datetime.now(timezone.utc) - timedelta(days=days)
            stmt = (
                select(Minute)
                .where(Minute.meeting_date >= cutoff)
                .order_by(Minute.meeting_date.desc())
                .limit(limit)
            )
            result = await session.execute(stmt)
            minutes = result.scalars().all()

            return success_response({
                "minutes": [
                    {
                        "id": m.minute_id,
                        "title": m.title,
                        "meeting_date": m.meeting_date.strftime("%Y-%m-%d") if m.meeting_date else None,
                        "committee_name": m.committee_name,
                        "meeting_type": m.meeting_type,
                        "speaker_count": m.speaker_count,
                    }
                    for m in minutes
                ],
                "total": len(minutes),
            })
    except Exception as exc:
        logger.exception("REST API recent_minutes error")
        error_response("INTERNAL_ERROR", "회의록 조회 중 오류가 발생했습니다", 500)


@app.get("/api/minutes")
async def search_minutes(
    page: int = Query(default=1, ge=1, description="페이지 번호"),
    limit: int = Query(default=20, ge=1, le=50, description="반환 건수"),
    committee: str = Query(default="", description="위원회명 필터"),
    type: str = Query(default="", description="회의 유형 필터"),
    q: str = Query(default="", max_length=200, description="제목 검색어"),
):
    """회의록 검색 — 필터 + 페이지네이션"""
    try:
        async with AsyncSessionLocal() as session:
            conditions = []

            if committee:
                conditions.append(Minute.committee_name == committee)

            if type:
                conditions.append(Minute.meeting_type == type)

            if q:
                escaped = _escape_like(q)
                conditions.append(
                    Minute.title.ilike(f"%{escaped}%", escape="\\")
                )

            # Count
            count_stmt = select(func.count()).select_from(Minute)
            if conditions:
                count_stmt = count_stmt.where(*conditions)
            total_result = await session.execute(count_stmt)
            total = total_result.scalar() or 0

            # Fetch
            offset = (page - 1) * limit
            stmt = (
                select(Minute)
                .order_by(Minute.meeting_date.desc())
                .limit(limit)
                .offset(offset)
            )
            if conditions:
                stmt = stmt.where(*conditions)
            result = await session.execute(stmt)
            minutes = result.scalars().all()

            return success_response({
                "minutes": [
                    {
                        "id": m.minute_id,
                        "title": m.title,
                        "meeting_date": m.meeting_date.strftime("%Y-%m-%d") if m.meeting_date else None,
                        "committee_name": m.committee_name,
                        "meeting_type": m.meeting_type,
                        "speaker_count": m.speaker_count,
                        "congress_number": m.congress_number,
                    }
                    for m in minutes
                ],
                "total": total,
                "page": page,
                "limit": limit,
            })
    except Exception as exc:
        logger.exception("REST API search_minutes error")
        error_response("INTERNAL_ERROR", "회의록 검색 중 오류가 발생했습니다", 500)


@app.get("/api/minutes/{minute_id}")
async def get_minute_detail(minute_id: str):
    """회의록 상세 조회 — speeches + 관련 법안"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = (
                select(Minute)
                .options(selectinload(Minute.speeches), selectinload(Minute.bills))
                .where(Minute.minute_id == minute_id)
            )
            result = await session.execute(stmt)
            minute = result.scalar_one_or_none()

            if minute is None:
                error_response("NOT_FOUND", "해당 회의록을 찾을 수 없습니다", 404)

            # Sort speeches by speech_order
            speeches_sorted = sorted(minute.speeches, key=lambda s: s.speech_order)

            # Fetch related bills via bill_minutes
            related_bills = []
            if minute.bills:
                bill_ids = [bm.bill_id for bm in minute.bills]
                bills_stmt = (
                    select(Bill)
                    .where(Bill.id.in_(bill_ids))
                    .order_by(Bill.proposed_date.desc())
                )
                bills_result = await session.execute(bills_stmt)
                bills_list = bills_result.scalars().all()
                related_bills = [
                    {
                        "id": b.source_id,
                        "title": b.title_original,
                        "proposer": b.proposer,
                        "proposed_date": b.proposed_date.strftime("%Y-%m-%d") if b.proposed_date else None,
                        "status": b.status.value if isinstance(b.status, BillStatus) else str(b.status),
                        "committee": b.committee_name,
                    }
                    for b in bills_list
                ]

            return success_response({
                "id": minute.minute_id,
                "title": minute.title,
                "meeting_date": minute.meeting_date.strftime("%Y-%m-%d") if minute.meeting_date else None,
                "committee_name": minute.committee_name,
                "meeting_type": minute.meeting_type,
                "congress_number": minute.congress_number,
                "speaker_count": minute.speaker_count,
                "summary": minute.summary,
                "detail_link": minute.detail_link,
                "pdf_available": minute.pdf_link_url is not None,
                "agenda_items": minute.agenda_items,
                "speeches": [
                    {
                        "speaker_name": s.speaker_name,
                        "speaker_role": s.speaker_role,
                        "content": s.content,
                        "speech_order": s.speech_order,
                    }
                    for s in speeches_sorted
                ],
                "related_bills": related_bills,
            })
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("REST API get_minute_detail error")
        error_response("INTERNAL_ERROR", "회의록 조회 중 오류가 발생했습니다", 500)


# ── Briefing endpoints ──────────────────────────────────────────────────


@app.get("/api/briefings")
async def list_briefings(
    limit: int = Query(default=7, ge=1, le=30, description="반환 건수"),
):
    """최근 일일 브리핑 목록 — 최신순 정렬"""
    try:
        async with AsyncSessionLocal() as session:
            stmt = (
                select(DailyBriefing)
                .order_by(DailyBriefing.briefing_date.desc())
                .limit(limit)
            )
            result = await session.execute(stmt)
            briefings = result.scalars().all()

            return success_response({
                "briefings": [
                    {
                        "id": b.id,
                        "briefing_date": b.briefing_date.strftime("%Y-%m-%d"),
                        "title": b.title,
                        "body": b.body,
                        "top_bills": b.top_bills,
                        "bill_count": b.bill_count,
                        "created_at": b.created_at.isoformat() if b.created_at else None,
                    }
                    for b in briefings
                ],
                "total": len(briefings),
            })
    except Exception as exc:
        logger.exception("REST API list_briefings error")
        error_response("INTERNAL_ERROR", "브리핑 조회 중 오류가 발생했습니다", 500)


# ── Member endpoints ──────────────────────────────────────────────────

from cnews.models.bill_sponsor import BillSponsor


@app.get("/api/members")
async def search_members(
    page: int = Query(default=1, ge=1, description="페이지 번호"),
    limit: int = Query(default=20, ge=1, le=50, description="반환 건수"),
    party: str = Query(default="", description="정당 필터"),
    q: str = Query(default="", max_length=100, description="이름 검색어"),
    congress_number: int = Query(default=22, ge=0, description="국회 대수 필터 (기본값: 22대)"),
    include_inactive: bool = Query(default=False, description="비활성 의원 포함 여부"),
):
    """의원 목록 검색 — 대수/정당 필터 + 이름 검색 + 페이지네이션"""
    try:
        async with AsyncSessionLocal() as session:
            conditions = []

            if not include_inactive:
                conditions.append(Member.is_active == True)  # noqa: E712

            if congress_number > 0:
                conditions.append(Member.congress_number == congress_number)

            if party:
                conditions.append(Member.party == party)

            if q:
                escaped = _escape_like(q)
                conditions.append(
                    Member.name.ilike(f"%{escaped}%", escape="\\")
                )

            # Count
            count_stmt = select(func.count()).select_from(Member)
            if conditions:
                count_stmt = count_stmt.where(*conditions)
            total_result = await session.execute(count_stmt)
            total = total_result.scalar() or 0

            # Fetch
            offset = (page - 1) * limit
            stmt = (
                select(Member)
                .order_by(Member.name)
                .limit(limit)
                .offset(offset)
            )
            if conditions:
                stmt = stmt.where(*conditions)
            result = await session.execute(stmt)
            members = result.scalars().all()

            return success_response({
                "members": [
                    {
                        "id": m.member_id,
                        "name": m.name,
                        "party": m.party,
                        "district": m.district,
                        "election_count": m.election_count,
                        "congress_number": m.congress_number,
                        "profile_image_url": m.profile_image_url,
                    }
                    for m in members
                ],
                "total": total,
                "page": page,
                "limit": limit,
            })
    except Exception as exc:
        logger.exception("REST API search_members error")
        error_response("INTERNAL_ERROR", "의원 검색 중 오류가 발생했습니다", 500)


@app.get("/api/members/{member_id}")
async def get_member_detail(member_id: str, bills_page: int = 1, bills_limit: int = 20):
    """의원 상세 조회 — 소개 법안 수, 표결 참여 수 포함 (법안 페이지네이션 지원)"""
    if bills_page < 1:
        bills_page = 1
    if bills_limit < 1 or bills_limit > 100:
        bills_limit = 20
    try:
        async with AsyncSessionLocal() as session:
            stmt = select(Member).where(Member.member_id == member_id)
            result = await session.execute(stmt)
            member = result.scalar_one_or_none()

            if member is None:
                error_response("NOT_FOUND", "해당 의원을 찾을 수 없습니다", 404)

            # 비22대 의원: 기본 정보만 반환, 법안/표결 데이터 미제공
            is_current_congress = member.congress_number == 22

            if is_current_congress:
                # Sponsored bills count
                sponsor_count_stmt = (
                    select(func.count())
                    .select_from(BillSponsor)
                    .where(BillSponsor.member_id == member.id)
                )
                sponsor_result = await session.execute(sponsor_count_stmt)
                sponsored_bills_count = sponsor_result.scalar() or 0

                # Vote count
                vote_count_stmt = (
                    select(func.count())
                    .select_from(Vote)
                    .where(Vote.member_id == member.id)
                )
                vote_result = await session.execute(vote_count_stmt)
                vote_count = vote_result.scalar() or 0

                # Sponsored bills with pagination
                offset = (bills_page - 1) * bills_limit
                sponsored_stmt = (
                    select(Bill)
                    .join(BillSponsor, BillSponsor.bill_id == Bill.id)
                    .where(BillSponsor.member_id == member.id)
                    .order_by(Bill.proposed_date.desc())
                    .offset(offset)
                    .limit(bills_limit)
                )
                sponsored_result = await session.execute(sponsored_stmt)
                sponsored_bills = sponsored_result.scalars().all()
            else:
                sponsored_bills_count = 0
                vote_count = 0
                sponsored_bills = []

            # Calculate pagination metadata
            bills_has_more = (bills_page * bills_limit) < sponsored_bills_count

            response = {
                "id": member.member_id,
                "name": member.name,
                "party": member.party,
                "district": member.district,
                "election_count": member.election_count,
                "congress_number": member.congress_number,
                "profile_image_url": member.profile_image_url,
                "email": member.email,
                "term_start_date": member.term_start_date.strftime("%Y-%m-%d") if member.term_start_date else None,
                "term_end_date": member.term_end_date.strftime("%Y-%m-%d") if member.term_end_date else None,
                "sponsored_bills_count": sponsored_bills_count,
                "vote_count": vote_count,
                "sponsored_bills": [
                    {
                        "id": b.source_id,
                        "title": b.title_original,
                        "proposed_date": b.proposed_date.strftime("%Y-%m-%d") if b.proposed_date else None,
                        "status": b.status.value if isinstance(b.status, BillStatus) else str(b.status),
                    }
                    for b in sponsored_bills
                ],
                "sponsored_bills_page": bills_page,
                "sponsored_bills_limit": bills_limit,
                "sponsored_bills_has_more": bills_has_more,
            }

            if not is_current_congress:
                response["data_notice"] = "제22대 국회 데이터만 제공됩니다. 해당 의원의 법안·표결 정보는 제공되지 않습니다."

            return success_response(response)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("REST API get_member_detail error")
        error_response("INTERNAL_ERROR", "의원 조회 중 오류가 발생했습니다", 500)


# ── Admin auth ─────────────────────────────────────────────────────────────


async def verify_admin_key(
    x_admin_key: str = Header(..., alias="X-Admin-Key"),
):
    """Validate the admin API key from request header."""
    expected = os.getenv("ADMIN_API_KEY", "")
    if not expected or x_admin_key != expected:
        error_response("FORBIDDEN", "Invalid admin key", 403)


# ── Admin batch endpoints ──────────────────────────────────────────────────


@app.post("/api/admin/batch/categorize")
async def trigger_categorize_batch(
    limit: int = Query(default=100, ge=1, le=500, description="처리할 최대 법안 수"),
    _admin: None = Depends(verify_admin_key),
):
    """수동으로 카테고리 분류 배치를 트리거합니다.

    category_id가 NULL인 법안을 찾아 Anthropic Batch API로 분류 요청을 제출합니다.
    """
    try:
        from cnews.ai.batch_processor import create_batch_requests, submit_batch

        requests = await create_batch_requests("categorize", limit=limit)

        if not requests:
            return success_response({
                "submitted": 0,
                "message": "카테고리 미분류 법안이 없습니다.",
            })

        batch_id = submit_batch(requests)
        logger.info(
            "Admin triggered categorize batch: %s (%d requests)",
            batch_id,
            len(requests),
        )

        return success_response({
            "submitted": len(requests),
            "batch_id": batch_id,
            "message": f"카테고리 분류 배치가 제출되었습니다 ({len(requests)}건).",
        })
    except Exception as exc:
        logger.exception("Admin batch categorize error")
        error_response("INTERNAL_ERROR", "배치 제출 중 오류가 발생했습니다.", 500)


@app.post("/api/admin/batch/all")
async def trigger_all_batches(
    limit: int = Query(default=100, ge=1, le=500, description="태스크별 최대 법안 수"),
    _admin: None = Depends(verify_admin_key),
):
    """모든 AI 배치 작업(summarize, categorize, score, industry, impact)을 트리거합니다."""
    try:
        from cnews.ai.batch_processor import run_all_batches

        results = await run_all_batches(limit=limit)
        total_submitted = sum(
            v.get("count", 0) for v in results.values() if v.get("status") == "submitted"
        )

        return success_response({
            "submitted": total_submitted,
            "details": results,
            "message": f"전체 배치가 제출되었습니다 (총 {total_submitted}건).",
        })
    except Exception as exc:
        logger.exception("Admin batch all error")
        error_response("INTERNAL_ERROR", "배치 제출 중 오류가 발생했습니다.", 500)


@app.get("/api/admin/batch/status/{batch_id}")
async def get_batch_status(batch_id: str, _admin: None = Depends(verify_admin_key)):
    """배치 상태를 조회합니다."""
    try:
        from cnews.ai.batch_processor import check_batch_status

        status = check_batch_status(batch_id)
        return success_response(status)
    except Exception as exc:
        logger.exception("Admin batch status error")
        error_response("INTERNAL_ERROR", "배치 상태 조회 중 오류가 발생했습니다.", 500)


@app.post("/api/admin/batch/results/{batch_id}")
async def process_batch_results_endpoint(
    batch_id: str,
    task_type: str = Query(description="태스크 유형 (summarize, categorize, score, industry, impact)"),
    _admin: None = Depends(verify_admin_key),
):
    """완료된 배치의 결과를 DB에 반영합니다."""
    try:
        from cnews.ai.batch_processor import TASK_TYPES, process_batch_results

        if task_type not in TASK_TYPES:
            error_response("BAD_REQUEST", "유효하지 않은 태스크 유형입니다", 400)

        result = await process_batch_results(batch_id, task_type)
        return success_response({
            "batch_id": batch_id,
            "task_type": task_type,
            "updated": result["updated"],
            "failed": result["failed"],
            "message": f"결과 반영 완료 (성공: {result['updated']}, 실패: {result['failed']}).",
        })
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Admin batch results error")
        error_response("INTERNAL_ERROR", "배치 결과 처리 중 오류가 발생했습니다.", 500)
