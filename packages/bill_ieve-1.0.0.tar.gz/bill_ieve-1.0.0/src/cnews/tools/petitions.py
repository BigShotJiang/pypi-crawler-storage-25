"""MCP tools for petition search — API proxy version."""

from __future__ import annotations

import json

from pydantic import Field

from .api_client import api_get


def register_tools(mcp):  # noqa: ANN001
    """Register petition-related MCP tools."""

    @mcp.tool(name="search-petitions")
    async def search_petitions(
        query: str = Field(default="", description="청원 검색어"),
        limit: int = Field(default=10, ge=1, le=50, description="반환 건수"),
    ) -> str:
        """한국 국회 청원을 검색합니다."""
        try:
            params = {"limit": limit}
            if query:
                params["query"] = query
            data = await api_get("/api/petitions", **params)
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"청원 검색 중 오류: {e!s}"}, ensure_ascii=False)
