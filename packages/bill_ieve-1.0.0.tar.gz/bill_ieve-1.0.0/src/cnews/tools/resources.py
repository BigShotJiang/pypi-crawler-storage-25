"""MCP resources for bill-ieve — API proxy version."""

from __future__ import annotations

import json

from .api_client import api_get


def register_resources(mcp):  # noqa: ANN001
    """Register MCP resources."""

    @mcp.resource("bill-ieve://stats")
    async def stats_resource() -> str:
        """Bill-ieve 전체 통계 — 국가별 법안 수, 카테고리별 분포 등."""
        try:
            data = await api_get("/api/stats/summary")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": str(e)}, ensure_ascii=False)

    @mcp.resource("bill-ieve://briefing/today")
    async def briefing_resource() -> str:
        """오늘의 법안 브리핑 — 최신 주요 법안 5건 요약."""
        try:
            data = await api_get("/api/bills/headlines")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": str(e)}, ensure_ascii=False)
