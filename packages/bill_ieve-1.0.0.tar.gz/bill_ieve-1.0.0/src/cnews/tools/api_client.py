"""HTTP client for MCP tools — proxies requests to Bill-ieve REST API."""

from __future__ import annotations

import os
from typing import Any

import httpx

# Public API URL — MCP server runs locally, calls public API
API_BASE = os.getenv("BILLIEVE_API_URL", "https://dev-api.bill-ieve.com")
_client: httpx.AsyncClient | None = None


async def get_client() -> httpx.AsyncClient:
    """Get or create a shared async HTTP client."""
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(base_url=API_BASE, timeout=15.0)
    return _client


async def api_get(path: str, **params: Any) -> dict:
    """GET request to Bill-ieve API."""
    client = await get_client()
    resp = await client.get(path, params={k: v for k, v in params.items() if v is not None})
    resp.raise_for_status()
    data = resp.json()
    # Unwrap success_response wrapper if present
    if isinstance(data, dict) and "data" in data:
        return data["data"]
    return data
