"""MCP tools for member search — API proxy version."""

from __future__ import annotations

import json

from pydantic import Field

from .api_client import api_get


def register_tools(mcp):  # noqa: ANN001
    """Register member-related MCP tools."""

    @mcp.tool(name="search-members")
    async def search_members(
        query: str = Field(default="", description="의원 이름 또는 정당명"),
        party: str = Field(default="", description="정당 필터"),
        limit: int = Field(default=20, ge=1, le=100, description="반환 건수"),
    ) -> str:
        """한국 국회의원을 이름, 정당으로 검색합니다."""
        try:
            params = {"limit": limit}
            if query:
                params["query"] = query
            if party:
                params["party"] = party
            data = await api_get("/api/members", **params)
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"의원 검색 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-member-detail")
    async def get_member_detail(
        member_id: str = Field(description="의원 ID (search-members 결과의 id)"),
    ) -> str:
        """의원 상세 정보를 조회합니다."""
        try:
            data = await api_get(f"/api/members/{member_id}")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"의원 조회 중 오류: {e!s}"}, ensure_ascii=False)
