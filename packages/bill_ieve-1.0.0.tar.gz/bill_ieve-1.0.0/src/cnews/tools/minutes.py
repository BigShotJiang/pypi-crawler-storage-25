"""MCP tools for minutes and meeting context — API proxy version."""

from __future__ import annotations

import json

from pydantic import Field

from .api_client import api_get


def register_tools(mcp):  # noqa: ANN001
    """Register minute-related MCP tools."""

    @mcp.tool(name="search-minutes")
    async def search_minutes(
        query: str = Field(default="", description="회의록 검색어 (위원회명, 키워드)"),
        limit: int = Field(default=10, ge=1, le=50, description="반환 건수"),
        offset: int = Field(default=0, ge=0, description="오프셋"),
    ) -> str:
        """한국 국회 회의록을 검색합니다."""
        try:
            params = {"limit": limit, "offset": offset}
            if query:
                params["query"] = query
            data = await api_get("/api/minutes", **params)
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"회의록 검색 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-meeting-context")
    async def get_meeting_context(
        minute_id: str = Field(description="회의록 ID (search-minutes 결과의 id)"),
    ) -> str:
        """회의록 상세 및 발언 내용을 조회합니다."""
        try:
            data = await api_get(f"/api/minutes/{minute_id}")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"회의록 조회 중 오류: {e!s}"}, ensure_ascii=False)
