"""MCP tools for AI bill analysis (Pro tier) — API proxy version."""

from __future__ import annotations

import json

from pydantic import Field

from .api_client import api_get


def register_tools(mcp):  # noqa: ANN001
    """Register analysis-related MCP tools (Pro tier)."""

    @mcp.tool(name="summarize-bill")
    async def summarize_bill(
        bill_id: str = Field(description="법안 source_id"),
    ) -> str:
        """법안을 AI가 뉴스 기사 형식으로 요약합니다. 이미 요약이 있으면 기존 요약을 반환합니다."""
        try:
            data = await api_get(f"/api/bills/{bill_id}")
            bill = data.get("bill", data)
            summary = bill.get("summary_ai")
            headline = bill.get("headline_ai")
            if summary:
                return json.dumps({
                    "bill_id": bill_id,
                    "headline": headline,
                    "summary": summary,
                    "source": "cached",
                }, ensure_ascii=False)
            return json.dumps({
                "bill_id": bill_id,
                "headline": bill.get("title", ""),
                "summary": "AI 요약이 아직 생성되지 않았습니다.",
                "source": "pending",
            }, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": f"요약 조회 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-bill-impact")
    async def get_bill_impact(
        bill_id: str = Field(description="법안 source_id"),
    ) -> str:
        """법안의 AI 영향 분석을 조회합니다. 재정 영향, 사회 영향, 영향 레이더를 반환합니다."""
        try:
            data = await api_get(f"/api/bills/{bill_id}")
            bill = data.get("bill", data)
            return json.dumps({
                "bill_id": bill_id,
                "title": bill.get("title", ""),
                "importance_score": bill.get("importance_score", 0),
                "impact_report": bill.get("impact_report"),
            }, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"영향 분석 조회 중 오류: {e!s}"}, ensure_ascii=False)
