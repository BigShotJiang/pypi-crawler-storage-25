"""MCP tools for bill search and retrieval — API proxy version."""

from __future__ import annotations

import json

from pydantic import Field

from .api_client import api_get


def register_tools(mcp):  # noqa: ANN001
    """Register bill-related MCP tools on the given FastMCP server."""

    @mcp.tool(name="search-bills")
    async def search_bills(
        query: str = Field(min_length=1, description="검색어 (법안 제목, 키워드, 의원 이름)"),
        country: str = Field(default="KR", description="국가 코드 (KR: 한국, US: 미국, EU: 유럽연합)"),
        status: str = Field(default="all", description="법안 상태 필터 (all/proposed/committee/plenary/passed/rejected)"),
        sort: str = Field(default="proposed_date", description="정렬 기준 (proposed_date/status_date/view_count)"),
        limit: int = Field(default=10, ge=1, le=50, description="반환 건수"),
        offset: int = Field(default=0, ge=0, description="오프셋"),
    ) -> str:
        """3개국(한국/미국/EU) 법안을 검색합니다. 제목, 키워드, 의원 이름으로 검색할 수 있습니다."""
        try:
            data = await api_get(
                "/api/bills",
                query=query,
                country=country.upper(),
                status=status if status != "all" else None,
                sort=sort,
                limit=limit,
                offset=offset,
            )
            return json.dumps(data, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": f"검색 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-bill-detail")
    async def get_bill_detail(
        bill_id: str = Field(description="법안 source_id (search-bills 결과의 id)"),
    ) -> str:
        """법안 상세 정보를 조회합니다. search-bills로 얻은 법안 ID를 입력하세요."""
        try:
            data = await api_get(f"/api/bills/{bill_id}")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as e:
            return json.dumps({"error": f"조회 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-bill-categories")
    async def get_bill_categories(
        country: str = Field(default="KR", description="국가 코드 (KR/US/EU)"),
    ) -> str:
        """카테고리별 법안 통계를 조회합니다."""
        try:
            data = await api_get("/api/stats/categories", country=country.upper())
            return json.dumps(data, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": f"통계 조회 중 오류: {e!s}"}, ensure_ascii=False)

    @mcp.tool(name="get-countries")
    async def get_countries() -> str:
        """Bill-ieve가 지원하는 국가 목록과 현황을 반환합니다."""
        return json.dumps({
            "countries": [
                {"code": "KR", "name": "대한민국", "name_en": "South Korea", "source": "열린국회정보 API"},
                {"code": "US", "name": "미국", "name_en": "United States", "source": "Congress.gov API v3"},
                {"code": "EU", "name": "유럽연합", "name_en": "European Union", "source": "CELLAR SPARQL + EUR-Lex"},
            ]
        }, ensure_ascii=False)
