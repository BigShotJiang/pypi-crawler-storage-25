"""Seed data for categories and industry tags."""

from cnews.models.base import generate_cuid

# 8 categories (DB-SCHEMA.md §5.1)
CATEGORY_SEEDS = [
    {
        "id": generate_cuid(),
        "code": "economy",
        "name_ko": "경제·재정",
        "name_en": "Economy & Finance",
        "description": "경제, 금융, 세제, 예산 관련",
    },
    {
        "id": generate_cuid(),
        "code": "tech",
        "name_ko": "IT·AI·과학",
        "name_en": "Tech & AI",
        "description": "IT, 인공지능, 과학기술, 디지털 관련",
    },
    {
        "id": generate_cuid(),
        "code": "environment",
        "name_ko": "환경·에너지",
        "name_en": "Environment & Energy",
        "description": "환경, 에너지, 기후변화 관련",
    },
    {
        "id": generate_cuid(),
        "code": "security",
        "name_ko": "외교·안보",
        "name_en": "Foreign Affairs & Security",
        "description": "외교, 국방, 안보 관련",
    },
    {
        "id": generate_cuid(),
        "code": "welfare",
        "name_ko": "사회·복지",
        "name_en": "Social Welfare",
        "description": "사회복지, 보건, 의료, 교육 관련",
    },
    {
        "id": generate_cuid(),
        "code": "justice",
        "name_ko": "법무·사법",
        "name_en": "Justice & Law",
        "description": "법무, 사법, 인권 관련",
    },
    {
        "id": generate_cuid(),
        "code": "politics",
        "name_ko": "정치·행정",
        "name_en": "Politics & Administration",
        "description": "정치, 행정, 선거, 지방자치 관련",
    },
    {
        "id": generate_cuid(),
        "code": "industry",
        "name_ko": "산업·노동",
        "name_en": "Industry & Labor",
        "description": "산업, 노동, 고용, 중소기업 관련",
    },
]

# 12 industry tags (DB-SCHEMA.md §5.3 - KSIC-based)
INDUSTRY_TAG_SEEDS = [
    {"id": generate_cuid(), "code": "A", "name": "농업·임업·어업", "keywords": ["농업", "수산업", "축산", "식량"]},
    {"id": generate_cuid(), "code": "C", "name": "제조업", "keywords": ["반도체", "자동차", "철강", "조선", "배터리"]},
    {"id": generate_cuid(), "code": "D", "name": "전기·가스·수도", "keywords": ["전력", "에너지", "가스", "수도"]},
    {"id": generate_cuid(), "code": "F", "name": "건설업", "keywords": ["건설", "부동산", "주택", "재개발"]},
    {"id": generate_cuid(), "code": "G", "name": "도소매업", "keywords": ["유통", "소매", "전자상거래"]},
    {"id": generate_cuid(), "code": "H", "name": "운수·창고업", "keywords": ["물류", "항공", "해운", "택배"]},
    {"id": generate_cuid(), "code": "J", "name": "정보통신업", "keywords": ["IT", "AI", "소프트웨어", "플랫폼", "데이터"]},
    {"id": generate_cuid(), "code": "K", "name": "금융·보험업", "keywords": ["금융", "은행", "보험", "증권", "가상자산"]},
    {"id": generate_cuid(), "code": "M", "name": "전문·과학·기술", "keywords": ["연구개발", "바이오", "특허", "컨설팅"]},
    {"id": generate_cuid(), "code": "N", "name": "사업시설·지원", "keywords": ["인력파견", "보안", "청소"]},
    {"id": generate_cuid(), "code": "P", "name": "교육서비스업", "keywords": ["교육", "학원", "대학", "직업훈련"]},
    {"id": generate_cuid(), "code": "Q", "name": "보건·사회복지", "keywords": ["의료", "병원", "요양", "사회복지"]},
]


async def seed_all():
    """Insert seed data into database."""
    from sqlalchemy import select
    from cnews.db import AsyncSessionLocal
    from cnews.models import Category, IndustryTag

    async with AsyncSessionLocal() as session:
        # Seed categories
        existing = await session.execute(select(Category.code))
        existing_codes = {row[0] for row in existing}
        for cat_data in CATEGORY_SEEDS:
            if cat_data["code"] not in existing_codes:
                session.add(Category(**cat_data))

        # Seed industry tags
        existing = await session.execute(select(IndustryTag.code))
        existing_codes = {row[0] for row in existing}
        for tag_data in INDUSTRY_TAG_SEEDS:
            if tag_data["code"] not in existing_codes:
                session.add(IndustryTag(**tag_data))

        await session.commit()


if __name__ == "__main__":
    import asyncio
    asyncio.run(seed_all())
