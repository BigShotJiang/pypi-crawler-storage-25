"""Async client for the Korean National Assembly Open API.

Usage::

    async with AssemblyClient() as client:
        rows = await client.fetch_all_bills("nzmimeepazxkubdpn", AGE="22")
"""

from __future__ import annotations

import asyncio
import itertools
import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------


class AssemblyApiError(Exception):
    """Raised when the Assembly API returns a non-success result code."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Assembly API error {code}: {message}")


# ---------------------------------------------------------------------------
# Key loader
# ---------------------------------------------------------------------------


def _load_api_keys() -> list[str]:
    """Load API keys from environment variables.

    Checks ``ASSEMBLY_API_KEY`` (single) first, then
    ``ASSEMBLY_API_KEY_1`` … ``ASSEMBLY_API_KEY_10`` (multi-key rotation).
    """
    single = os.getenv("ASSEMBLY_API_KEY")
    if single:
        keys = [single]
    else:
        keys = []

    # Collect numbered keys (1-10)
    for i in range(1, 11):
        key = os.getenv(f"ASSEMBLY_API_KEY_{i}")
        if key:
            keys.append(key)

    if not keys:
        raise ValueError(
            "No Assembly API keys found. "
            "Set ASSEMBLY_API_KEY or ASSEMBLY_API_KEY_1..10 in the environment."
        )

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for k in keys:
        if k not in seen:
            seen.add(k)
            unique.append(k)

    logger.info("Loaded %d Assembly API key(s)", len(unique))
    return unique


# ---------------------------------------------------------------------------
# AssemblyClient
# ---------------------------------------------------------------------------


class AssemblyClient:
    """Async HTTP client for ``open.assembly.go.kr``."""

    BASE_URL = "https://open.assembly.go.kr/portal/openapi/"

    def __init__(
        self,
        *,
        timeout: float = 10.0,
        max_concurrent: int = 10,
        max_retries: int = 3,
        page_size: int = 100,
        api_keys: list[str] | None = None,
    ) -> None:
        self._keys = api_keys or _load_api_keys()
        self._key_cycle = itertools.cycle(self._keys)
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_retries = max_retries
        self._page_size = page_size
        self._client = httpx.AsyncClient(timeout=timeout)
        self._call_count = 0

    # -- context manager -----------------------------------------------------

    async def __aenter__(self) -> "AssemblyClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    # -- internal helpers ----------------------------------------------------

    def _next_key(self) -> str:
        return next(self._key_cycle)

    def _build_url(self, endpoint_id: str) -> str:
        return f"{self.BASE_URL}{endpoint_id}"

    @staticmethod
    def _parse_response(data: dict, endpoint_id: str) -> tuple[int, list[dict]]:
        """Parse the Assembly JSON envelope and return ``(total_count, rows)``.

        Raises :class:`AssemblyApiError` on API-level errors.
        """
        wrapper = data.get(endpoint_id)
        if not wrapper or not isinstance(wrapper, list):
            raise AssemblyApiError("PARSE_ERROR", f"Unexpected top-level structure for {endpoint_id}")

        head_block: dict = {}
        rows: list[dict] = []

        for item in wrapper:
            if "head" in item:
                for entry in item["head"]:
                    head_block.update(entry)
            if "row" in item:
                rows = item["row"]

        # Check result code
        result_info = head_block.get("RESULT", {})
        result_code = result_info.get("CODE", "")
        if not result_code:
            raise AssemblyApiError("MISSING_CODE", "API response missing result code")
        if result_code != "INFO-000":
            raise AssemblyApiError(result_code, result_info.get("MESSAGE", ""))

        total_count = int(head_block.get("list_total_count", 0))
        return total_count, rows

    async def _request_with_retry(self, url: str, params: dict[str, Any]) -> httpx.Response:
        """Execute a GET request with exponential-backoff retry."""
        last_exc: Exception | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                async with self._semaphore:
                    response = await self._client.get(url, params=params)
                    response.raise_for_status()
                    return response
            except (httpx.HTTPStatusError, httpx.TransportError) as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    wait = 2 ** (attempt - 1)  # 1s, 2s, 4s
                    logger.warning(
                        "Request failed (attempt %d/%d): %s — retrying in %ds",
                        attempt,
                        self._max_retries,
                        exc,
                        wait,
                    )
                    await asyncio.sleep(wait)
                else:
                    logger.error(
                        "Request failed after %d attempts: %s",
                        self._max_retries,
                        exc,
                    )
        raise last_exc  # type: ignore[misc]

    # -- public API ----------------------------------------------------------

    async def fetch_bills(
        self,
        endpoint_id: str,
        *,
        page_index: int = 1,
        page_size: int | None = None,
        **params: Any,
    ) -> tuple[int, list[dict]]:
        """Fetch a single page of bills from *endpoint_id*.

        Returns ``(total_count, rows)``.
        """
        p_size = page_size or self._page_size
        request_params: dict[str, Any] = {
            "Key": self._next_key(),
            "Type": "json",
            "pIndex": page_index,
            "pSize": p_size,
            **params,
        }

        url = self._build_url(endpoint_id)
        logger.debug("GET %s pIndex=%d pSize=%d", url, page_index, p_size)

        response = await self._request_with_retry(url, request_params)
        self._call_count += 1
        if self._call_count >= 800:
            logger.warning("API call count %d — approaching daily limit 1000", self._call_count)
        data = response.json()
        return self._parse_response(data, endpoint_id)

    async def fetch_all_bills(
        self,
        endpoint_id: str,
        **params: Any,
    ) -> list[dict]:
        """Fetch **all** pages for *endpoint_id* and return combined rows."""
        all_rows: list[dict] = []
        page_index = 1

        while True:
            total_count, rows = await self.fetch_bills(
                endpoint_id, page_index=page_index, **params
            )
            all_rows.extend(rows)
            logger.info(
                "Fetched page %d — %d rows (total so far: %d / %d)",
                page_index,
                len(rows),
                len(all_rows),
                total_count,
            )

            # Stop conditions:
            # 1. No rows returned (empty page)
            # 2. Reached total_count
            # 3. Page returned fewer rows than page_size (last page)
            if not rows or len(all_rows) >= total_count or len(rows) < self._page_size:
                break
            page_index += 1

        return all_rows
