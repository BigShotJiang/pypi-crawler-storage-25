"""Field normalizers for Assembly API responses.

Transforms raw API row dicts into the internal bill schema used by cnews.
"""

from __future__ import annotations

import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# PROC_RESULT -> BillStatus mapping
# ---------------------------------------------------------------------------
PROC_RESULT_MAPPING: dict[str, str] = {
    "원안가결": "PASSED",
    "수정가결": "PASSED",
    "대안반영폐기": "PASSED",
    "수정안반영폐기": "PASSED",
    "수정의결": "PASSED",
    "채택": "PASSED",
    "경과보고서채택": "PASSED",
    "부결": "REJECTED",
    "폐기": "REJECTED",
    "철회": "WITHDRAWN",
    "임기만료폐기": "EXPIRED",
    "회기불계속폐기": "EXPIRED",
    "심사미료": "EXPIRED",
    "위원회 심사": "COMMITTEE",
    "체계자구심사": "COMMITTEE",
    "회송": "COMMITTEE",
    "본회의 부의": "PLENARY",
    "본회의 의결": "PLENARY",
}


def map_proc_result_to_bill_status(proc_result: str | None) -> str:
    """Map a raw PROC_RESULT value to a BillStatus enum value.

    Returns ``'PROPOSED'`` for empty / ``None`` / unrecognised values.
    """
    if not proc_result or not proc_result.strip():
        return "PROPOSED"

    cleaned = proc_result.strip()
    status = PROC_RESULT_MAPPING.get(cleaned)
    if status is None:
        logger.warning("Unrecognised PROC_RESULT value: %r -> defaulting to PROPOSED", cleaned)
        return "PROPOSED"
    return status


def parse_assembly_date(date_str: str | None) -> datetime | None:
    """Parse date strings from the Assembly API.

    Supports ``YYYY-MM-DD`` and ``YYYYMMDD`` formats.  Returns ``None`` for
    empty / unparseable values.
    """
    if not date_str or not date_str.strip():
        return None

    cleaned = date_str.strip()
    for fmt in ("%Y-%m-%d", "%Y%m%d"):
        try:
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            continue

    logger.warning("Unparseable date string: %r", cleaned)
    return None


# ---------------------------------------------------------------------------
# nzmimeepazxkubdpn normalizer
# ---------------------------------------------------------------------------
def normalize_bill_from_nzmimeep(raw: dict) -> dict:
    """Normalize a row from the *nzmimeepazxkubdpn* endpoint.

    Field mapping:
        BILL_ID       -> source_id
        BILL_NAME     -> title_original
        PROPOSER      -> proposer
        PROPOSE_DT    -> proposed_date
        PROC_RESULT   -> status  (via map_proc_result_to_bill_status)
        COMMITTEE     -> committee_name
        COMMITTEE_ID  -> committee_id
        DETAIL_LINK   -> source_url
    """
    proc_result_raw = raw.get("PROC_RESULT")

    return {
        "source_id": raw.get("BILL_ID", ""),
        "title_original": raw.get("BILL_NAME", ""),
        "proposer": raw.get("PROPOSER") or None,
        "proposed_date": parse_assembly_date(raw.get("PROPOSE_DT")),
        "status": map_proc_result_to_bill_status(proc_result_raw),
        "committee_name": raw.get("COMMITTEE") or None,
        "committee_id": raw.get("COMMITTEE_ID") or None,
        "source_url": raw.get("DETAIL_LINK", ""),
        "proc_result_raw": proc_result_raw or None,
    }


# ---------------------------------------------------------------------------
# TVBPMBILL11 normalizer
# ---------------------------------------------------------------------------
def normalize_bill_from_tvbpmbill11(raw: dict) -> dict:
    """Normalize a row from the *TVBPMBILL11* endpoint.

    Field mapping:
        BILL_ID            -> source_id
        BILL_NAME          -> title_original
        PROPOSER           -> proposer
        PROPOSE_DT         -> proposed_date
        PROC_RESULT_CD     -> status  (via map_proc_result_to_bill_status)
        CURR_COMMITTEE     -> committee_name
        CURR_COMMITTEE_ID  -> committee_id
        LINK_URL           -> source_url
    """
    proc_result_raw = raw.get("PROC_RESULT_CD")

    return {
        "source_id": raw.get("BILL_ID", ""),
        "title_original": raw.get("BILL_NAME", ""),
        "proposer": raw.get("PROPOSER") or None,
        "proposed_date": parse_assembly_date(raw.get("PROPOSE_DT")),
        "status": map_proc_result_to_bill_status(proc_result_raw),
        "committee_name": raw.get("CURR_COMMITTEE") or None,
        "committee_id": raw.get("CURR_COMMITTEE_ID") or None,
        "source_url": raw.get("LINK_URL", ""),
        "proc_result_raw": proc_result_raw or None,
    }
