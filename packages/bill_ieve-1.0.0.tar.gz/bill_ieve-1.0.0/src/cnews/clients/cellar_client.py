"""Async client for the EU Publications Office CELLAR SPARQL endpoint.

Usage::

    async with CellarClient() as client:
        directives = await client.fetch_legislation("DIR", from_date="2025-03-27")
        regulations = await client.fetch_legislation("REG", from_date="2025-03-27")
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

SPARQL_ENDPOINT = "https://publications.europa.eu/webapi/rdf/sparql"

# EU legislation resource types
EU_RESOURCE_TYPES = {
    "DIR": "Directive",
    "REG": "Regulation",
    "PROP_DIR": "Proposed Directive",
    "PROP_REG": "Proposed Regulation",
}


class CellarClient:
    """Async SPARQL client for EU CELLAR."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "CellarClient":
        self._client = httpx.AsyncClient(timeout=30.0)
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._client:
            await self._client.aclose()

    async def _query(self, sparql: str) -> list[dict]:
        """Execute SPARQL query and return bindings."""
        resp = await self._client.get(
            SPARQL_ENDPOINT,
            params={"query": sparql, "format": "application/json"},
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("results", {}).get("bindings", [])

    async def fetch_legislation(
        self,
        resource_type: str = "DIR",
        from_date: str | None = None,
        limit: int = 500,
    ) -> list[dict]:
        """Fetch EU legislation of a given type.

        Args:
            resource_type: DIR, REG, PROP_DIR, or PROP_REG
            from_date: ISO date string (YYYY-MM-DD) to filter from
            limit: Max results

        Returns:
            List of dicts with keys: cellar_id, title, date, resource_type
        """
        date_filter = ""
        if from_date:
            date_filter = f'FILTER(?date >= "{from_date}"^^xsd:date)'

        sparql = f"""
        PREFIX cdm: <http://publications.europa.eu/ontology/cdm#>
        SELECT DISTINCT ?work ?title ?date
        WHERE {{
          ?work cdm:work_has_resource-type
            <http://publications.europa.eu/resource/authority/resource-type/{resource_type}> .
          ?work cdm:work_date_document ?date .
          ?exp cdm:expression_belongs_to_work ?work .
          ?exp cdm:expression_uses_language
            <http://publications.europa.eu/resource/authority/language/ENG> .
          ?exp cdm:expression_title ?title .
          {date_filter}
        }}
        ORDER BY DESC(?date)
        LIMIT {limit}
        """

        bindings = await self._query(sparql)
        results = []
        for b in bindings:
            cellar_uri = b.get("work", {}).get("value", "")
            cellar_id = cellar_uri.split("/")[-1] if cellar_uri else ""
            results.append({
                "cellar_id": cellar_id,
                "cellar_uri": cellar_uri,
                "title": b.get("title", {}).get("value", ""),
                "date": b.get("date", {}).get("value", ""),
                "resource_type": resource_type,
                "resource_type_label": EU_RESOURCE_TYPES.get(resource_type, resource_type),
            })
        return results

    async def fetch_all_legislation(
        self, from_date: str | None = None, limit: int = 500
    ) -> list[dict]:
        """Fetch all EU legislation types (DIR + REG + proposals)."""
        all_results = []
        for rtype in EU_RESOURCE_TYPES:
            results = await self.fetch_legislation(rtype, from_date, limit)
            all_results.extend(results)
            logger.info("EU %s: %d results", rtype, len(results))
        return all_results
