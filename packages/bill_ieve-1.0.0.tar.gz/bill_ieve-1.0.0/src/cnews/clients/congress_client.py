"""Async client for the US Congress.gov API v3.

Usage::

    async with CongressClient() as client:
        bills = await client.fetch_bills(congress=119, limit=20)
        detail = await client.fetch_bill_detail(congress=119, bill_type="hr", number="144")
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)

BASE_URL = "https://api.congress.gov/v3"

# US policyArea → Bill-ieve 8-category mapping
POLICY_AREA_MAP: dict[str, str] = {
    "Economics and Public Finance": "economy",
    "Finance and Financial Sector": "economy",
    "Taxation": "economy",
    "Foreign Trade and International Finance": "economy",
    "Government Operations and Politics": "politics",
    "Congress": "politics",
    "Public Lands and Natural Resources": "environment",
    "Energy": "environment",
    "Environmental Protection": "environment",
    "Water Resources Development": "environment",
    "Animals": "environment",
    "Commerce": "industry",
    "Labor and Employment": "industry",
    "Transportation and Public Works": "industry",
    "Agriculture and Food": "industry",
    "Crime and Law Enforcement": "justice",
    "Law": "justice",
    "Civil Rights and Liberties, Minority Issues": "justice",
    "Immigration": "justice",
    "Armed Forces and National Security": "security",
    "International Affairs": "security",
    "Emergency Management": "security",
    "Science, Technology, Communications": "tech",
    "Health": "welfare",
    "Education": "welfare",
    "Social Welfare": "welfare",
    "Housing and Community Development": "welfare",
    "Families": "welfare",
    "Native Americans": "welfare",
    "Sports and Recreation": "welfare",
    "Arts, Culture, Religion": "welfare",
}


def _get_api_key() -> str:
    key = os.getenv("CONGRESS_API_KEY", "")
    if not key:
        raise RuntimeError("CONGRESS_API_KEY environment variable is required")
    return key


class CongressClient:
    """Thin async wrapper around Congress.gov API v3."""

    def __init__(self) -> None:
        self._api_key = _get_api_key()
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "CongressClient":
        self._client = httpx.AsyncClient(timeout=30.0)
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._client:
            await self._client.aclose()

    async def _get(self, path: str, **params: Any) -> dict:
        """GET request with API key injection."""
        params["api_key"] = self._api_key
        params.setdefault("format", "json")
        url = f"{BASE_URL}{path}"
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def fetch_bills(
        self,
        congress: int = 119,
        from_date: str | None = None,
        to_date: str | None = None,
        limit: int = 250,
        offset: int = 0,
    ) -> dict:
        """Fetch bill list for a congress."""
        params: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "sort": "updateDate desc",
        }
        if from_date:
            params["fromDateTime"] = f"{from_date}T00:00:00Z"
        if to_date:
            params["toDateTime"] = f"{to_date}T23:59:59Z"
        return await self._get(f"/bill/{congress}", **params)

    async def fetch_bill_detail(
        self, congress: int, bill_type: str, number: str
    ) -> dict:
        """Fetch single bill detail."""
        return await self._get(f"/bill/{congress}/{bill_type.lower()}/{number}")

    async def fetch_bill_summaries(
        self, congress: int, bill_type: str, number: str
    ) -> list[dict]:
        """Fetch CRS summaries for a bill."""
        try:
            data = await self._get(
                f"/bill/{congress}/{bill_type.lower()}/{number}/summaries"
            )
            return data.get("summaries", [])
        except Exception:
            return []

    async def fetch_bill_actions(
        self, congress: int, bill_type: str, number: str
    ) -> list[dict]:
        """Fetch action history for a bill."""
        try:
            data = await self._get(
                f"/bill/{congress}/{bill_type.lower()}/{number}/actions"
            )
            return data.get("actions", [])
        except Exception:
            return []

    async def fetch_laws(self, congress: int = 119, limit: int = 250) -> dict:
        """Fetch enacted laws for a congress."""
        return await self._get(f"/law/{congress}", limit=limit)

    @staticmethod
    def map_category(policy_area: str | None) -> str | None:
        """Map US policyArea to Bill-ieve category code."""
        if not policy_area:
            return None
        return POLICY_AREA_MAP.get(policy_area)

    @staticmethod
    def map_status(latest_action_text: str) -> str:
        """Map US latest action text to BillStatus enum value."""
        text = (latest_action_text or "").lower()
        if "became public law" in text or "signed by president" in text:
            return "PASSED"
        if "passed house" in text or "passed senate" in text:
            return "PLENARY"
        if "referred to" in text or "committee" in text:
            return "COMMITTEE"
        if "vetoed" in text or "failed" in text:
            return "REJECTED"
        return "PROPOSED"
