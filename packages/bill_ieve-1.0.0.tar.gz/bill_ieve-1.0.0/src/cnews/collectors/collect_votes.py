"""Collect vote data from the National Assembly Open API.

Two-phase collection:
  Phase 1: Vote summaries per bill (ncocpgfiaoituanbr)
  Phase 2: Individual member votes per bill (nojepdqqaweusdfbi)

Usage::

    # As a module
    from cnews.collectors.collect_votes import collect_votes
    result = await collect_votes()

    # As a CLI script
    python -m cnews.collectors.collect_votes
    python -m cnews.collectors.collect_votes --dry-run
    python -m cnews.collectors.collect_votes --phase 1  # Phase 1 only
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import time
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models import Bill, CollectionLog, Member, Vote
from cnews.models.base import generate_cuid
from cnews.models.enums import VoteResult

logger = logging.getLogger(__name__)

# Endpoint IDs
VOTE_SUMMARY_ENDPOINT = "ncocpgfiaoituanbr"
MEMBER_VOTE_ENDPOINT = "nojepdqqaweusdfbi"

PAGE_SIZE = 1000
UPSERT_BATCH_SIZE = 500

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VOTE_RESULT_MAP: dict[str, VoteResult] = {
    "찬성": VoteResult.YES,
    "반대": VoteResult.NO,
    "기권": VoteResult.ABSTAIN,
    "불참": VoteResult.ABSENT,
}


def _parse_vote_datetime(date_str: str | None) -> datetime | None:
    """Parse VOTE_DATE from the Assembly API.

    Handles formats:
      - "20260312 150747" (datetime with space)
      - "20260312" (date only)
      - "2026-03-12" (ISO date)
    """
    if not date_str or not date_str.strip():
        return None

    cleaned = date_str.strip()
    for fmt in ("%Y%m%d %H%M%S", "%Y%m%d", "%Y-%m-%d"):
        try:
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            continue

    logger.warning("Unparseable vote date: %r", cleaned)
    return None


def _map_vote_result(result_str: str | None) -> VoteResult | None:
    """Map RESULT_VOTE_MOD to VoteResult enum."""
    if not result_str or not result_str.strip():
        return None
    return VOTE_RESULT_MAP.get(result_str.strip())


# ---------------------------------------------------------------------------
# DB loaders
# ---------------------------------------------------------------------------

async def _load_bill_source_id_map() -> dict[str, str]:
    """Load mapping: source_id (API BILL_ID) -> bills.id (DB PK)."""
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Bill.id, Bill.source_id))
        return {row.source_id: row.id for row in result.fetchall()}


async def _load_member_mona_cd_map() -> dict[str, str]:
    """Load mapping: member_id (MONA_CD) -> members.id (DB PK)."""
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Member.id, Member.member_id))
        return {row.member_id: row.id for row in result.fetchall()}


# ---------------------------------------------------------------------------
# Phase 1: Vote summaries (bill-level vote results)
# ---------------------------------------------------------------------------

async def _fetch_vote_summaries(
    client: AssemblyClient,
) -> tuple[list[dict[str, Any]], int]:
    """Fetch all vote summary rows from the API.

    Returns (rows, api_call_count).
    """
    logger.info("Phase 1: Fetching vote summaries (AGE=22)...")
    all_rows = await client.fetch_all_bills(
        VOTE_SUMMARY_ENDPOINT,
        AGE="22",
    )
    total = len(all_rows)
    api_calls = max(1, (total // PAGE_SIZE) + (1 if total % PAGE_SIZE else 0))
    logger.info("Phase 1: Fetched %d vote summary rows in ~%d API calls", total, api_calls)
    return all_rows, api_calls


# ---------------------------------------------------------------------------
# Phase 2: Member-level votes
# ---------------------------------------------------------------------------

async def _fetch_member_votes_for_bill(
    client: AssemblyClient,
    bill_id_api: str,
) -> list[dict[str, Any]]:
    """Fetch individual member votes for a single bill.

    Uses BILL_ID parameter to filter by bill.
    """
    rows = await client.fetch_all_bills(
        MEMBER_VOTE_ENDPOINT,
        BILL_ID=bill_id_api,
        AGE="22",
    )
    return rows


# ---------------------------------------------------------------------------
# Upsert logic
# ---------------------------------------------------------------------------

async def _upsert_votes(records: list[dict[str, Any]]) -> tuple[int, int]:
    """Bulk upsert vote records using INSERT ... ON CONFLICT DO NOTHING.

    Uses the (bill_id, member_id) uniqueness constraint for dedup.

    Returns:
        (new_count, skipped_count)
    """
    total_new = 0
    total_records = len(records)

    for i in range(0, total_records, UPSERT_BATCH_SIZE):
        batch = records[i : i + UPSERT_BATCH_SIZE]

        values = [
            {
                "id": generate_cuid(),
                "bill_id": rec["bill_id"],
                "member_id": rec["member_id"],
                "vote_date": rec["vote_date"],
                "vote_result": rec["vote_result"],
            }
            for rec in batch
        ]

        async with AsyncSessionLocal() as session:
            async with session.begin():
                stmt = insert(Vote.__table__).values(values)
                stmt = stmt.on_conflict_do_nothing(
                    constraint="uq_votes_bill_member"
                )
                result = await session.execute(stmt)
                total_new += result.rowcount

        logger.info(
            "Upsert batch %d-%d: inserted %d",
            i,
            min(i + UPSERT_BATCH_SIZE, total_records),
            result.rowcount,
        )

    skipped = total_records - total_new
    return total_new, skipped


# ---------------------------------------------------------------------------
# Main collection function
# ---------------------------------------------------------------------------

async def collect_votes(
    *,
    dry_run: bool = False,
    phase: int | None = None,
) -> dict[str, Any]:
    """Collect vote data from the National Assembly API.

    Args:
        dry_run: Fetch and parse without writing to DB.
        phase: Run only phase 1 or 2 (None = both).

    Returns:
        Dict with collection statistics.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    stats: dict[str, Any] = {
        "phase1_rows": 0,
        "phase2_rows": 0,
        "phase2_bills_queried": 0,
        "matched_bills": 0,
        "unmatched_bills": 0,
        "matched_members": 0,
        "unmatched_members": 0,
        "new_votes": 0,
        "skipped_votes": 0,
        "api_calls": 0,
        "status": "success",
        "error_message": None,
    }

    try:
        # Load DB mappings
        bill_map = await _load_bill_source_id_map()
        member_map = await _load_member_mona_cd_map()
        logger.info("Loaded %d bills and %d members from DB", len(bill_map), len(member_map))

        async with AssemblyClient(page_size=PAGE_SIZE) as client:

            # =============================================================
            # Phase 1: Vote summaries — collect BILL_IDs that have votes
            # =============================================================
            vote_summary_bill_ids: list[str] = []

            if phase is None or phase == 1:
                summaries, p1_calls = await _fetch_vote_summaries(client)
                stats["phase1_rows"] = len(summaries)
                stats["api_calls"] += p1_calls

                for row in summaries:
                    bill_id_api = row.get("BILL_ID", "")
                    if bill_id_api:
                        vote_summary_bill_ids.append(bill_id_api)

                # Deduplicate
                vote_summary_bill_ids = list(dict.fromkeys(vote_summary_bill_ids))
                logger.info(
                    "Phase 1: Found %d unique bills with votes",
                    len(vote_summary_bill_ids),
                )

                # Log phase 1 summary info
                for row in summaries:
                    bill_id_api = row.get("BILL_ID", "")
                    if bill_id_api in bill_map:
                        stats["matched_bills"] += 1
                    else:
                        stats["unmatched_bills"] += 1

                if phase == 1:
                    logger.info("Phase 1 only mode — skipping phase 2")

            # =============================================================
            # Phase 2: Member-level votes for each bill
            # =============================================================
            if phase is None or phase == 2:
                # If phase 2 only, we need to get bill IDs from phase 1 first
                if phase == 2 and not vote_summary_bill_ids:
                    summaries, p1_calls = await _fetch_vote_summaries(client)
                    stats["phase1_rows"] = len(summaries)
                    stats["api_calls"] += p1_calls
                    for row in summaries:
                        bill_id_api = row.get("BILL_ID", "")
                        if bill_id_api:
                            vote_summary_bill_ids.append(bill_id_api)
                    vote_summary_bill_ids = list(dict.fromkeys(vote_summary_bill_ids))

                # Filter to only bills that exist in our DB
                bills_to_query = [
                    bid for bid in vote_summary_bill_ids if bid in bill_map
                ]
                logger.info(
                    "Phase 2: Will query member votes for %d bills (out of %d)",
                    len(bills_to_query),
                    len(vote_summary_bill_ids),
                )
                stats["phase2_bills_queried"] = len(bills_to_query)

                all_vote_records: list[dict[str, Any]] = []
                member_match_count = 0
                member_unmatch_count = 0

                for idx, bill_id_api in enumerate(bills_to_query, 1):
                    db_bill_id = bill_map[bill_id_api]

                    try:
                        member_rows = await _fetch_member_votes_for_bill(
                            client, bill_id_api
                        )
                        stats["api_calls"] += 1
                        stats["phase2_rows"] += len(member_rows)
                    except Exception as exc:
                        logger.warning(
                            "Failed to fetch member votes for bill %s: %s",
                            bill_id_api,
                            exc,
                        )
                        continue

                    for mrow in member_rows:
                        mona_cd = mrow.get("MONA_CD", "")
                        db_member_id = member_map.get(mona_cd)

                        if not db_member_id:
                            member_unmatch_count += 1
                            continue

                        member_match_count += 1
                        vote_result = _map_vote_result(mrow.get("RESULT_VOTE_MOD"))
                        if vote_result is None:
                            logger.warning(
                                "Unknown vote result %r for bill %s member %s",
                                mrow.get("RESULT_VOTE_MOD"),
                                bill_id_api,
                                mona_cd,
                            )
                            continue

                        vote_date = _parse_vote_datetime(mrow.get("VOTE_DATE"))
                        if vote_date is None:
                            logger.warning(
                                "No vote_date for bill %s member %s",
                                bill_id_api,
                                mona_cd,
                            )
                            continue

                        all_vote_records.append({
                            "bill_id": db_bill_id,
                            "member_id": db_member_id,
                            "vote_date": vote_date,
                            "vote_result": vote_result,
                        })

                    if idx % 100 == 0:
                        logger.info(
                            "Phase 2 progress: %d/%d bills processed",
                            idx,
                            len(bills_to_query),
                        )

                stats["matched_members"] = member_match_count
                stats["unmatched_members"] = member_unmatch_count

                logger.info(
                    "Phase 2: Collected %d vote records "
                    "(matched members: %d, unmatched: %d)",
                    len(all_vote_records),
                    member_match_count,
                    member_unmatch_count,
                )

                # Upsert to DB
                if not dry_run and all_vote_records:
                    new_count, skipped_count = await _upsert_votes(all_vote_records)
                    stats["new_votes"] = new_count
                    stats["skipped_votes"] = skipped_count
                    logger.info(
                        "Phase 2: Inserted %d new votes, skipped %d duplicates",
                        new_count,
                        skipped_count,
                    )
                elif dry_run:
                    logger.info(
                        "[DRY RUN] Would insert %d vote records",
                        len(all_vote_records),
                    )

    except Exception as exc:
        stats["status"] = "failed"
        stats["error_message"] = str(exc)[:2000]
        logger.exception("collect_votes failed: %s", exc)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms
    stats["duration_ms"] = duration_ms

    # Write collection log
    if not dry_run:
        try:
            async with AsyncSessionLocal() as session:
                async with session.begin():
                    log = CollectionLog(
                        id=generate_cuid(),
                        bills_count=stats["phase2_rows"],
                        new_bills_count=stats["new_votes"],
                        updated_bills_count=stats["skipped_votes"],
                        status=stats["status"],
                        error_message=stats.get("error_message"),
                        duration_ms=duration_ms,
                    )
                    session.add(log)
        except Exception:
            logger.exception("Failed to write CollectionLog for votes")

    logger.info("collect_votes result: %s", stats)
    return stats


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        description="Collect vote data from the National Assembly API"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fetch and parse data without writing to DB",
    )
    parser.add_argument(
        "--phase",
        type=int,
        choices=[1, 2],
        default=None,
        help="Run only phase 1 (summaries) or phase 2 (member votes)",
    )
    args = parser.parse_args()

    result = asyncio.run(collect_votes(dry_run=args.dry_run, phase=args.phase))
    print(result)
