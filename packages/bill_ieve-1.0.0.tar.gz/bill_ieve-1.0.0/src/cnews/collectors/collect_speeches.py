"""Collect speeches from committee minute PDFs (scheduler-friendly).

Targets only *new* minutes -- minutes rows that do not yet have any
associated speeches.  Keeps the scheduled 06:30 KST run fast and
incremental.

Re-implements the core logic from ``scripts/collect_speeches_from_pdf.py``
to avoid ``sys.path`` hacks (``scripts/`` is not a Python package).
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import tempfile

import httpx
import opendataloader_pdf
from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.base import generate_cuid
from cnews.models.minute import Minute
from cnews.models.speech import Speech

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COMMITTEE_MINUTES_ENDPOINT = "ncwgseseafwbuheph"
COMMITTEE_MINUTES_YEARS = ["2024", "2025", "2026"]
PDF_DOWNLOAD_URL = (
    "https://record.assembly.go.kr/assembly/viewer/minutes/download/pdf.do"
)
PDF_DIR = Path(__file__).resolve().parent.parent.parent.parent / "data" / "minutes_pdf"
DOWNLOAD_CONCURRENCY = 5
DOWNLOAD_DELAY = 0.5
DOWNLOAD_MAX_RETRIES = 3
UPSERT_BATCH_SIZE = 500

# Speech parsing patterns
SPEAKER_PATTERN = re.compile(r"◯(\S+(?:\s+\S+)?)\s+(.*?)(?=◯|\Z)", re.DOTALL)
SKIP_PATTERNS = re.compile(r"출석\s*위원\s*\(\d+인\)|청가\s*위원\s*\(\d+인\)")

TITLE_KEYWORDS = sorted(
    [
        "위원장", "소위원장", "부위원장", "간사", "의장", "부의장",
        "국무총리", "국무위원", "장관", "차관", "처장", "청장",
        "위원", "의원", "전문위원", "수석전문위원",
        "참고인", "진술인", "증인", "감정인",
        "비서관", "비서실장", "수석비서관",
        "사무총장", "사무차장",
        "총재", "총장", "원장", "이사장", "이사",
        "검찰총장", "경찰청장", "국세청장",
    ],
    key=len,
    reverse=True,
)


# ---------------------------------------------------------------------------
# PDF Download helpers
# ---------------------------------------------------------------------------


def _extract_pdf_id_from_link(pdf_link_url: str) -> str:
    parsed = urlparse(pdf_link_url)
    params = parse_qs(parsed.query)
    ids = params.get("id", [])
    return ids[0] if ids else ""


async def _download_pdf(
    client: httpx.AsyncClient,
    pdf_file_id: str,
    semaphore: asyncio.Semaphore,
) -> bool:
    pdf_path = PDF_DIR / f"{pdf_file_id}.pdf"
    if pdf_path.exists() and pdf_path.stat().st_size > 0:
        return False

    for attempt in range(1, DOWNLOAD_MAX_RETRIES + 1):
        try:
            async with semaphore:
                await asyncio.sleep(DOWNLOAD_DELAY)
                response = await client.get(
                    PDF_DOWNLOAD_URL,
                    params={"id": pdf_file_id},
                    follow_redirects=True,
                    timeout=60.0,
                )
                response.raise_for_status()

                content_type = response.headers.get("content-type", "")
                if "pdf" not in content_type.lower() and len(response.content) < 1000:
                    logger.warning(
                        "PDF %s: unexpected content-type %s (size=%d), skipping",
                        pdf_file_id, content_type, len(response.content),
                    )
                    return False

                pdf_path.write_bytes(response.content)
                logger.info("Downloaded PDF %s (%d bytes)", pdf_file_id, len(response.content))
                return True

        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            if attempt < DOWNLOAD_MAX_RETRIES:
                wait = 2 ** attempt
                logger.warning(
                    "Download %s failed (attempt %d/%d): %s -- retrying in %ds",
                    pdf_file_id, attempt, DOWNLOAD_MAX_RETRIES, exc, wait,
                )
                await asyncio.sleep(wait)
            else:
                logger.error(
                    "Download %s failed after %d attempts: %s",
                    pdf_file_id, DOWNLOAD_MAX_RETRIES, exc,
                )
    return False


async def _download_all_pdfs(pdf_file_ids: list[str]) -> dict[str, int]:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
    semaphore = asyncio.Semaphore(DOWNLOAD_CONCURRENCY)
    downloaded = 0
    skipped = 0
    total = len(pdf_file_ids)

    async with httpx.AsyncClient() as client:
        for i, pdf_id in enumerate(pdf_file_ids):
            result = await _download_pdf(client, pdf_id, semaphore)
            if result:
                downloaded += 1
            else:
                skipped += 1

            if (i + 1) % 50 == 0 or (i + 1) == total:
                logger.info(
                    "Download progress: %d/%d (downloaded=%d, skipped=%d)",
                    i + 1, total, downloaded, skipped,
                )

    return {"downloaded": downloaded, "skipped": skipped, "total": total}


# ---------------------------------------------------------------------------
# PDF Parsing helpers
# ---------------------------------------------------------------------------


def _split_title_name(raw_speaker: str) -> tuple[str | None, str]:
    raw_speaker = raw_speaker.strip()
    for title in TITLE_KEYWORDS:
        if raw_speaker.startswith(title):
            remainder = raw_speaker[len(title):].strip()
            if remainder and len(remainder) >= 2:
                return title, remainder
    return None, raw_speaker


def _parse_speeches_from_pdf(pdf_path: Path) -> list[dict[str, Any]]:
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            opendataloader_pdf.convert(
                input_path=[str(pdf_path)],
                output_dir=tmpdir,
                format="markdown",
            )
            md_files = list(Path(tmpdir).glob("*.md"))
            full_text = md_files[0].read_text(encoding="utf-8") if md_files else ""
    except Exception as exc:
        logger.error("Failed to read PDF %s: %s", pdf_path.name, exc)
        return []

    if not full_text.strip():
        logger.warning("PDF %s: empty text extraction", pdf_path.name)
        return []

    matches = SPEAKER_PATTERN.findall(full_text)
    speeches: list[dict[str, Any]] = []
    order = 0

    for raw_speaker, raw_content in matches:
        raw_speaker = raw_speaker.strip()
        raw_content = raw_content.strip()

        if SKIP_PATTERNS.search(raw_speaker):
            continue
        if len(raw_speaker) < 3:
            continue
        if not raw_content:
            continue

        title, name = _split_title_name(raw_speaker)
        order += 1

        speeches.append({
            "speaker_name": name,
            "speaker_role": title,
            "content": raw_content,
            "speech_order": order,
        })

    return speeches


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


async def _upsert_speeches(speeches: list[dict[str, Any]]) -> int:
    if not speeches:
        return 0

    total_new = 0

    for i in range(0, len(speeches), UPSERT_BATCH_SIZE):
        batch = speeches[i: i + UPSERT_BATCH_SIZE]

        for d in batch:
            d["id"] = generate_cuid()

        async with AsyncSessionLocal() as session:
            async with session.begin():
                stmt = insert(Speech).values(batch)
                stmt = stmt.on_conflict_do_nothing()
                result = await session.execute(stmt)
                total_new += result.rowcount  # type: ignore[assignment]

        logger.info(
            "Upserted speech batch %d-%d (batch_size=%d)",
            i, min(i + UPSERT_BATCH_SIZE, len(speeches)), len(batch),
        )

    return total_new


async def _get_minutes_without_speeches() -> list[Minute]:
    """Return Minute rows that have **no** associated Speech rows."""
    async with AsyncSessionLocal() as session:
        stmt = (
            select(Minute)
            .outerjoin(Speech, Minute.id == Speech.minute_id)
            .where(Speech.id.is_(None))
        )
        result = await session.execute(stmt)
        return list(result.scalars().all())


async def _collect_pdf_file_ids() -> list[dict[str, str]]:
    """Fetch PDF download IDs and CONF_ID from the committee minutes API."""
    records: list[dict[str, str]] = []
    seen: set[str] = set()

    async with AssemblyClient() as client:
        for year in COMMITTEE_MINUTES_YEARS:
            try:
                rows = await client.fetch_all_bills(
                    COMMITTEE_MINUTES_ENDPOINT,
                    DAE_NUM="22",
                    CONF_DATE=year,
                )
                logger.info("API: year=%s, rows=%d", year, len(rows))

                for raw in rows:
                    pdf_link_url = raw.get("PDF_LINK_URL", "")
                    conf_id = raw.get("CONF_ID", "")

                    pdf_download_id = (
                        _extract_pdf_id_from_link(pdf_link_url) if pdf_link_url else ""
                    )

                    if not pdf_download_id:
                        continue

                    if pdf_download_id not in seen:
                        seen.add(pdf_download_id)
                        records.append({
                            "pdf_file_id": pdf_download_id,
                            "conf_id": conf_id,
                        })

            except Exception as exc:
                logger.error("Failed to fetch year %s: %s", year, exc)

    logger.info("Total unique PDF download IDs collected: %d", len(records))
    return records


async def _refresh_missing_pdf_urls() -> int:
    """Re-fetch PDF URLs from the Assembly API for minutes that have pdf_link_url IS NULL.

    When minutes are first collected, the PDF may not yet be published by the
    National Assembly.  This function re-queries the same API used by
    ``_collect_pdf_file_ids()`` and updates the ``pdf_link_url`` column for
    any minutes whose CONF_ID now has a PDF available.

    Returns the number of minutes rows updated.
    """
    # 1. Get minute_ids (= CONF_ID) where pdf_link_url is NULL
    async with AsyncSessionLocal() as session:
        stmt = select(Minute.minute_id).where(Minute.pdf_link_url.is_(None))
        result = await session.execute(stmt)
        null_minute_ids: set[str] = {row[0] for row in result.fetchall()}

    if not null_minute_ids:
        logger.info("_refresh_missing_pdf_urls: no minutes with NULL pdf_link_url")
        return 0

    logger.info(
        "_refresh_missing_pdf_urls: %d minutes with NULL pdf_link_url, querying API...",
        len(null_minute_ids),
    )

    # 2. Query Assembly API for PDF URLs (same logic as _collect_pdf_file_ids)
    conf_to_pdf_url: dict[str, str] = {}

    async with AssemblyClient() as client:
        for year in COMMITTEE_MINUTES_YEARS:
            try:
                rows = await client.fetch_all_bills(
                    COMMITTEE_MINUTES_ENDPOINT,
                    DAE_NUM="22",
                    CONF_DATE=year,
                )
                for raw in rows:
                    conf_id = raw.get("CONF_ID", "")
                    pdf_link_url = raw.get("PDF_LINK_URL", "")

                    if conf_id and pdf_link_url and conf_id in null_minute_ids:
                        conf_to_pdf_url[conf_id] = pdf_link_url

            except Exception as exc:
                logger.error(
                    "_refresh_missing_pdf_urls: failed to fetch year %s: %s",
                    year, exc,
                )

    if not conf_to_pdf_url:
        logger.info("_refresh_missing_pdf_urls: no new PDF URLs found from API")
        return 0

    # 3. Update minutes table
    updated = 0
    async with AsyncSessionLocal() as session:
        async with session.begin():
            for conf_id, pdf_url in conf_to_pdf_url.items():
                stmt = (
                    update(Minute)
                    .where(Minute.minute_id == conf_id)
                    .where(Minute.pdf_link_url.is_(None))
                    .values(pdf_link_url=pdf_url)
                )
                result = await session.execute(stmt)
                updated += result.rowcount  # type: ignore[assignment]

    logger.info(
        "_refresh_missing_pdf_urls: updated %d / %d minutes with new PDF URLs",
        updated, len(conf_to_pdf_url),
    )
    return updated


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def collect_speeches() -> dict[str, Any]:
    """Collect speeches for new (unprocessed) minutes only.

    Flow:
    1. Find minutes that have no speeches yet.
    2. Fetch PDF download IDs via the Assembly API for those minutes.
    3. Download missing PDFs.
    4. Parse speeches from PDFs.
    5. Upsert into the ``speeches`` table.

    Returns a stats dict.
    """
    start = time.monotonic()
    stats: dict[str, Any] = {}

    # Step 0 -- refresh PDF URLs for minutes that were missing them
    refreshed = await _refresh_missing_pdf_urls()
    stats["pdf_urls_refreshed"] = refreshed

    # Step 1 -- identify new minutes
    new_minutes = await _get_minutes_without_speeches()
    stats["new_minutes"] = len(new_minutes)

    if not new_minutes:
        logger.info("No new minutes to process for speeches.")
        return {"status": "no_new_minutes", **stats}

    logger.info(
        "Found %d minutes without speeches -- starting collection",
        len(new_minutes),
    )

    # Build minute_id -> Minute mapping (minute_id is the external CONF_ID)
    minute_map: dict[str, Minute] = {m.minute_id: m for m in new_minutes}

    # Step 2 -- get PDF download IDs from API (only for target minutes)
    all_pdf_records = await _collect_pdf_file_ids()

    # Filter to only records whose conf_id is in our target set
    target_records = [
        r for r in all_pdf_records if r["conf_id"] in minute_map
    ]
    stats["target_pdfs"] = len(target_records)

    if not target_records:
        logger.info("No PDF records match the new minutes.")
        return {"status": "no_matching_pdfs", **stats}

    logger.info(
        "Filtered to %d PDF records for new minutes (from %d total API records)",
        len(target_records),
        len(all_pdf_records),
    )

    # Step 3 -- download missing PDFs
    pdf_file_ids = [r["pdf_file_id"] for r in target_records]
    download_stats = await _download_all_pdfs(pdf_file_ids)
    stats["download"] = download_stats

    # Step 4 -- parse speeches
    pdf_to_conf: dict[str, str] = {
        r["pdf_file_id"]: r["conf_id"] for r in target_records
    }

    all_speeches: list[dict[str, Any]] = []
    parse_errors = 0

    for pdf_id in pdf_file_ids:
        pdf_path = PDF_DIR / f"{pdf_id}.pdf"
        if not pdf_path.exists():
            continue

        conf_id = pdf_to_conf.get(pdf_id, "")
        minute = minute_map.get(conf_id)
        if not minute:
            continue

        speeches = _parse_speeches_from_pdf(pdf_path)
        if not speeches:
            parse_errors += 1
            continue

        for speech in speeches:
            speech["minute_id"] = minute.id

        all_speeches.extend(speeches)

    stats["parsing"] = {
        "total_speeches": len(all_speeches),
        "parse_errors": parse_errors,
    }

    logger.info(
        "Parsed %d speeches from %d PDFs (%d errors)",
        len(all_speeches),
        len(pdf_file_ids),
        parse_errors,
    )

    # Step 5 -- upsert
    new_count = await _upsert_speeches(all_speeches)
    stats["db_insert"] = {"inserted": new_count, "total": len(all_speeches)}

    elapsed = time.monotonic() - start
    stats["elapsed_seconds"] = round(elapsed, 1)
    stats["status"] = "success"

    logger.info(
        "collect_speeches done: %d new speeches inserted in %.1fs",
        new_count,
        elapsed,
    )
    return stats
