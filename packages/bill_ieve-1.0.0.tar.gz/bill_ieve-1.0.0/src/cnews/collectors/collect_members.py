"""Collect member data from the National Assembly API and upsert into the database.

Usage::

    # As a module
    from cnews.collectors.collect_members import collect_members
    result = await collect_members()

    # As a CLI script
    python -m cnews.collectors.collect_members
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.base import generate_cuid
from cnews.models.member import Member

logger = logging.getLogger(__name__)

ENDPOINT_ID = "nwvrqwxyaytdsfvhu"
CONGRESS_NUMBER = 22
TERM_START_DATE = datetime(2024, 5, 30)

# Korean ordinal election count labels
_ELECTION_COUNT_MAP: dict[str, int] = {
    "초선": 1,
    "재선": 2,
    "3선": 3,
    "4선": 4,
    "5선": 5,
    "6선": 6,
    "7선": 7,
    "8선": 8,
    "9선": 9,
}


def parse_election_count(text: str | None) -> int:
    """Parse Korean election count text to an integer.

    Examples:
        "초선" -> 1, "재선" -> 2, "3선" -> 3, None -> 1
    """
    if not text:
        return 1
    return _ELECTION_COUNT_MAP.get(text.strip(), 1)


def _normalize_member(raw: dict) -> dict:
    """Normalize a raw API row into a dict matching the Member model columns."""
    return {
        "id": generate_cuid(),
        "member_id": raw.get("MONA_CD", ""),
        "name": raw.get("HG_NM", ""),
        "party": raw.get("POLY_NM", ""),
        "district": raw.get("ORIG_NM", ""),
        "election_count": parse_election_count(raw.get("REELE_GBN_NM")),
        "email": raw.get("E_MAIL") or None,
        "congress_number": CONGRESS_NUMBER,
        "term_start_date": TERM_START_DATE,
        "is_active": True,
    }


async def _upsert_members(member_dicts: list[dict]) -> tuple[int, int]:
    """Upsert members using INSERT ... ON CONFLICT DO UPDATE.

    Returns:
        (new_count, updated_count)
    """
    async with AsyncSessionLocal() as session:
        async with session.begin():
            member_ids = [d["member_id"] for d in member_dicts]
            existing_result = await session.execute(
                select(Member.member_id).where(Member.member_id.in_(member_ids))
            )
            existing_ids = {row[0] for row in existing_result.fetchall()}

            stmt = insert(Member).values(member_dicts)
            stmt = stmt.on_conflict_do_update(
                index_elements=["member_id"],
                set_={
                    "name": stmt.excluded.name,
                    "party": stmt.excluded.party,
                    "district": stmt.excluded.district,
                    "election_count": stmt.excluded.election_count,
                    "email": stmt.excluded.email,
                    "congress_number": stmt.excluded.congress_number,
                    "term_start_date": stmt.excluded.term_start_date,
                    "is_active": stmt.excluded.is_active,
                },
            )
            await session.execute(stmt)

    new_count = len(member_ids) - len(existing_ids)
    updated_count = len(existing_ids)
    return new_count, updated_count


async def collect_members() -> dict:
    """Fetch all current 22nd assembly members and upsert into DB.

    Returns:
        A dict with keys: total, new, updated, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    total = 0
    new_count = 0
    updated_count = 0
    status = "success"

    try:
        async with AssemblyClient(page_size=300) as client:
            _total_count, raw_rows = await client.fetch_bills(
                ENDPOINT_ID,
                page_size=300,
            )

        total = len(raw_rows)
        logger.info("Fetched %d members from API", total)

        if total > 0:
            normalized = []
            for raw in raw_rows:
                row = _normalize_member(raw)
                if not row["member_id"]:
                    logger.warning("Skipping row with missing MONA_CD: %s", raw)
                    total -= 1
                    continue
                normalized.append(row)

            if normalized:
                new_count, updated_count = await _upsert_members(normalized)

                # API에 없는 의원 비활성화
                api_member_ids = {d["member_id"] for d in normalized}
                async with AsyncSessionLocal() as session:
                    async with session.begin():
                        # 22대 의원 중 API에 없는 사람 비활성화
                        deactivate_result = await session.execute(
                            update(Member)
                            .where(Member.congress_number == CONGRESS_NUMBER)
                            .where(Member.member_id.notin_(api_member_ids))
                            .values(is_active=False)
                        )
                        deactivated = deactivate_result.rowcount
                        # API에 있는 사람은 활성화
                        await session.execute(
                            update(Member)
                            .where(Member.member_id.in_(api_member_ids))
                            .values(is_active=True)
                        )
                if deactivated:
                    logger.info("Deactivated %d members not in API response", deactivated)

    except Exception as exc:
        status = "failed"
        logger.exception("collect_members failed: %s", exc)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "total": total,
        "new": new_count,
        "updated": updated_count,
        "status": status,
        "duration_ms": duration_ms,
    }
    logger.info("collect_members result: %s", result)
    return result


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    result = asyncio.run(collect_members())
    print(result)
