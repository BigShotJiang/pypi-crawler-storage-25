"""Collect bills from the National Assembly API and upsert into the database.

Usage::

    # As a module
    from cnews.collectors.collect_bills import collect_bills
    result = await collect_bills(days=7)

    # As a CLI script
    python -m cnews.collectors.collect_bills
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import date, timedelta

from sqlalchemy import func
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.clients.normalizers import normalize_bill_from_nzmimeep
from cnews.db import AsyncSessionLocal
from cnews.models import Bill, CollectionLog
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

ENDPOINT_ID = "nzmimeepazxkubdpn"
ASSEMBLY_AGE = "22"


async def collect_bills(days: int = 7) -> dict:
    """Fetch recent bills and upsert them into the database.

    Args:
        days: Number of days to look back from today.

    Returns:
        A dict with keys: total, new, updated, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    end_dt = date.today()
    start_dt = end_dt - timedelta(days=days)

    total = 0
    new_count = 0
    updated_count = 0
    status = "success"
    error_message = None

    try:
        async with AssemblyClient() as client:
            raw_rows = await client.fetch_all_bills(
                ENDPOINT_ID,
                AGE=ASSEMBLY_AGE,
                PROPOSE_DT_START=start_dt.strftime("%Y-%m-%d"),
                PROPOSE_DT_END=end_dt.strftime("%Y-%m-%d"),
            )

        total = len(raw_rows)
        if total == 0:
            logger.warning("No bills returned for %s ~ %s — possible API issue", start_dt, end_dt)
            status = "failed"
            error_message = "Zero bills returned (possible API quota or connectivity issue)"
        else:
            normalized = []
            for raw in raw_rows:
                row = normalize_bill_from_nzmimeep(raw)
                # Skip rows without a valid source_id or proposed_date
                if not row["source_id"] or row["proposed_date"] is None:
                    logger.warning("Skipping row with missing source_id or proposed_date: %s", raw)
                    total -= 1
                    continue
                row["id"] = generate_cuid()
                normalized.append(row)

            if normalized:
                new_count, updated_count = await _upsert_bills(normalized)

    except Exception as exc:
        status = "failed"
        error_message = f"[{type(exc).__name__}] {exc}"[:2000]
        logger.exception("collect_bills failed: %s", exc)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    await _write_collection_log(
        bills_count=total,
        new_bills_count=new_count,
        updated_bills_count=updated_count,
        status=status,
        error_message=error_message,
        duration_ms=duration_ms,
    )

    result = {
        "total": total,
        "new": new_count,
        "updated": updated_count,
        "status": status,
    }
    logger.info("collect_bills result: %s", result)
    return result


UPSERT_BATCH_SIZE = 500


async def _upsert_bills(bill_dicts: list[dict]) -> tuple[int, int]:
    """Upsert bills using INSERT ... ON CONFLICT DO UPDATE.

    Processes in batches of UPSERT_BATCH_SIZE to stay within asyncpg's
    32,767 query-parameter limit.

    Returns:
        (new_count, updated_count)
    """
    from sqlalchemy import select

    # Remove proc_result_raw — not a column on the Bill model
    clean_dicts = []
    for d in bill_dicts:
        row = {k: v for k, v in d.items() if k != "proc_result_raw"}
        clean_dicts.append(row)

    total_new = 0
    total_updated = 0

    for i in range(0, len(clean_dicts), UPSERT_BATCH_SIZE):
        batch = clean_dicts[i : i + UPSERT_BATCH_SIZE]

        async with AsyncSessionLocal() as session:
            async with session.begin():
                source_ids = [d["source_id"] for d in batch]
                existing_result = await session.execute(
                    select(Bill.source_id).where(Bill.source_id.in_(source_ids))
                )
                existing_ids = {row[0] for row in existing_result.fetchall()}

                stmt = insert(Bill).values(batch)
                stmt = stmt.on_conflict_do_update(
                    index_elements=["source_id"],
                    set_={
                        "status": stmt.excluded.status,
                        "committee_id": stmt.excluded.committee_id,
                        "committee_name": stmt.excluded.committee_name,
                        "source_url": stmt.excluded.source_url,
                        "updated_at": func.now(),
                    },
                )
                await session.execute(stmt)

        total_new += len(source_ids) - len(existing_ids)
        total_updated += len(existing_ids)

    return total_new, total_updated


async def _write_collection_log(
    *,
    bills_count: int,
    new_bills_count: int,
    updated_bills_count: int,
    status: str,
    error_message: str | None,
    duration_ms: int,
) -> None:
    """Write a CollectionLog entry."""
    try:
        async with AsyncSessionLocal() as session:
            async with session.begin():
                log = CollectionLog(
                    id=generate_cuid(),
                    bills_count=bills_count,
                    new_bills_count=new_bills_count,
                    updated_bills_count=updated_bills_count,
                    status=status,
                    error_message=error_message,
                    duration_ms=duration_ms,
                )
                session.add(log)
    except Exception:
        logger.exception("Failed to write CollectionLog")


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    result = asyncio.run(collect_bills())
    print(result)
