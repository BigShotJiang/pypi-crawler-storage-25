"""Backfill bills from the National Assembly API over a date range.

Splits the range into monthly chunks and calls the same upsert logic
used by ``collect_bills``.

Usage::

    python -m cnews.collectors.backfill --start 2024-01-01 --end 2024-12-31 --chunk 1
"""

from __future__ import annotations

import argparse
import asyncio
import calendar
import logging
import time
from datetime import date, timedelta

from cnews.clients.assembly_client import AssemblyClient
from cnews.clients.normalizers import normalize_bill_from_nzmimeep
from cnews.db import AsyncSessionLocal
from cnews.models import CollectionLog
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

ENDPOINT_ID = "nzmimeepazxkubdpn"
ASSEMBLY_AGE = "22"
MAX_CONSECUTIVE_FAILURES = 3
CHUNK_DELAY_SECONDS = 1.0


def split_date_range_by_months(
    start_date: date, end_date: date, chunk_months: int = 1
) -> list[tuple[date, date]]:
    """Split a date range into monthly chunks.

    Args:
        start_date: Inclusive start.
        end_date: Inclusive end.
        chunk_months: Number of months per chunk.

    Returns:
        List of (chunk_start, chunk_end) tuples.
    """
    chunks: list[tuple[date, date]] = []
    current = start_date

    while current <= end_date:
        # Advance by chunk_months
        month = current.month - 1 + chunk_months
        year = current.year + month // 12
        month = month % 12 + 1
        last_day = calendar.monthrange(year, month)[1]
        chunk_end = date(year, month, min(last_day, 28))

        # Clamp the chunk_end to the actual end of the period
        # The chunk_end should be the day before the next chunk starts,
        # or end_date, whichever is earlier.
        # Actually, we want the last day of the chunk period.
        # Simpler: chunk ends at (start of next chunk - 1 day) or end_date
        next_chunk_start_month = current.month - 1 + chunk_months
        next_year = current.year + next_chunk_start_month // 12
        next_month = next_chunk_start_month % 12 + 1
        next_chunk_start = date(next_year, next_month, 1)
        chunk_end = min(next_chunk_start - timedelta(days=1), end_date)

        chunks.append((current, chunk_end))
        current = next_chunk_start

    return chunks


async def _fetch_and_upsert_chunk(
    client: AssemblyClient, chunk_start: date, chunk_end: date
) -> dict:
    """Fetch bills for a single date chunk and upsert.

    Returns:
        Dict with total, new, updated counts.
    """
    raw_rows = await client.fetch_all_bills(
        ENDPOINT_ID,
        AGE=ASSEMBLY_AGE,
        PROPOSE_DT_START=chunk_start.strftime("%Y-%m-%d"),
        PROPOSE_DT_END=chunk_end.strftime("%Y-%m-%d"),
    )

    total = len(raw_rows)
    if total == 0:
        return {"total": 0, "new": 0, "updated": 0}

    normalized = []
    for raw in raw_rows:
        row = normalize_bill_from_nzmimeep(raw)
        if not row["source_id"] or row["proposed_date"] is None:
            total -= 1
            continue
        row["id"] = generate_cuid()
        normalized.append(row)

    if not normalized:
        return {"total": 0, "new": 0, "updated": 0}

    # Reuse shared upsert logic from collect_bills
    from cnews.collectors.collect_bills import _upsert_bills

    new_count, updated_count = await _upsert_bills(normalized)
    return {"total": total, "new": new_count, "updated": updated_count}


async def backfill(
    start_date: date, end_date: date, chunk_months: int = 1
) -> dict:
    """Backfill bills from start_date to end_date in monthly chunks.

    Args:
        start_date: Inclusive start date.
        end_date: Inclusive end date.
        chunk_months: Months per API call chunk.

    Returns:
        Aggregated result dict with total, new, updated, status, chunks_processed.
    """
    start_ms = time.monotonic_ns() // 1_000_000
    chunks = split_date_range_by_months(start_date, end_date, chunk_months)
    logger.info(
        "Backfill: %s ~ %s, %d chunks (%d month(s) each)",
        start_date, end_date, len(chunks), chunk_months,
    )

    total = 0
    new_total = 0
    updated_total = 0
    consecutive_failures = 0
    chunks_processed = 0
    status = "success"
    error_message = None

    async with AssemblyClient() as client:
        for i, (chunk_start, chunk_end) in enumerate(chunks):
            logger.info(
                "Chunk %d/%d: %s ~ %s", i + 1, len(chunks), chunk_start, chunk_end
            )
            try:
                result = await _fetch_and_upsert_chunk(client, chunk_start, chunk_end)
                total += result["total"]
                new_total += result["new"]
                updated_total += result["updated"]
                consecutive_failures = 0
                chunks_processed += 1
            except Exception as exc:
                consecutive_failures += 1
                logger.error(
                    "Chunk %d failed (%d consecutive): %s",
                    i + 1, consecutive_failures, exc,
                )
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    status = "failed"
                    error_message = (
                        f"Stopped after {MAX_CONSECUTIVE_FAILURES} consecutive "
                        f"failures. Last error: {exc}"
                    )[:2000]
                    logger.error("Backfill aborted: %s", error_message)
                    break

            # Delay between chunks (except the last)
            if i < len(chunks) - 1:
                await asyncio.sleep(CHUNK_DELAY_SECONDS)

    # If we had some failures but didn't hit max, mark partial
    if status == "success" and chunks_processed < len(chunks):
        status = "partial"

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    # Write collection log
    try:
        async with AsyncSessionLocal() as session:
            async with session.begin():
                log = CollectionLog(
                    id=generate_cuid(),
                    bills_count=total,
                    new_bills_count=new_total,
                    updated_bills_count=updated_total,
                    status=status,
                    error_message=error_message,
                    duration_ms=duration_ms,
                )
                session.add(log)
    except Exception:
        logger.exception("Failed to write CollectionLog for backfill")

    result = {
        "total": total,
        "new": new_total,
        "updated": updated_total,
        "status": status,
        "chunks_processed": chunks_processed,
        "chunks_total": len(chunks),
    }
    logger.info("Backfill result: %s", result)
    return result


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description="Backfill bills from Assembly API")
    parser.add_argument("--start", required=True, help="YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="YYYY-MM-DD")
    parser.add_argument("--chunk", type=int, default=1, help="Months per chunk")
    args = parser.parse_args()
    asyncio.run(
        backfill(
            date.fromisoformat(args.start),
            date.fromisoformat(args.end),
            args.chunk,
        )
    )
