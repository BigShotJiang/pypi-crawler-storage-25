"""Collect committee/plenary/special/subcommittee/hearing minutes from the National Assembly API.

Discovered endpoints (2026-03-18):
- VCONFPHCONFLIST     : 공청회 회의록 (46건, 22대)
- VCONFBUDGETCONFLIST : 예결산특별위원회 회의록 (32건, 22대)
- VCONFSUBCCONFLIST   : 소위원회 회의록 (23건, 22대)
- VCONFAPIGCONFLIST   : 국정감사 회의록 (317건, 22대)
- VCONFSPCCONFLIST    : 특별위원회 회의록 (60건, 22대)
- VCONFDETAIL         : 회의록별 상세정보 (CONF_ID 필수)
- nkimylolanvseqagq   : 회의록 대별 위원회 목록
- ncwgseseafwbuheph   : 위원회 회의록 (2,569건, 22대) ← 주 수집 소스
- nzbyfwhwaoanttzje   : 본회의 회의록 (349건, 22대)

Usage::

    python -m cnews.collectors.collect_minutes
    python -m cnews.collectors.collect_minutes --source plenary
    python -m cnews.collectors.collect_minutes --dry-run
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import time
from datetime import datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.minute import Minute
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

# 회의록 유형별 엔드포인트
MINUTE_ENDPOINTS: dict[str, str] = {
    "VCONFPHCONFLIST": "공청회",
    "VCONFBUDGETCONFLIST": "예결산특별위원회",
    "VCONFSUBCCONFLIST": "소위원회",
    "VCONFAPIGCONFLIST": "국정감사",
    "VCONFSPCCONFLIST": "특별위원회",
}

ASSEMBLY_ERA = "제22대"
UPSERT_BATCH_SIZE = 100

# 위원회 회의록 API (주 수집 소스, 22대 2,569건)
COMMITTEE_MINUTES_ENDPOINT = "ncwgseseafwbuheph"
# 22대 연도 범위: 2024 ~ 2026
COMMITTEE_MINUTES_YEARS = ["2024", "2025", "2026"]

# 본회의 회의록 API (22대 349건)
PLENARY_MINUTES_ENDPOINT = "nzbyfwhwaoanttzje"
PLENARY_MINUTES_YEARS = ["2024", "2025", "2026"]


def _normalize_minute(raw: dict[str, Any], meeting_type: str) -> dict[str, Any]:
    """Normalize a raw API row from VCONF* endpoints into a Minute-compatible dict."""
    conf_dt = raw.get("CONF_DT", "")
    meeting_date: datetime | None = None
    if conf_dt:
        try:
            meeting_date = datetime.strptime(conf_dt.strip(), "%Y-%m-%d")
        except ValueError:
            try:
                meeting_date = datetime.strptime(conf_dt.strip(), "%Y%m%d")
            except ValueError:
                logger.warning("Cannot parse CONF_DT: %r", conf_dt)

    title_parts = []
    sess = raw.get("SESS", "")
    dgr = raw.get("DGR", "")
    conf_knd = raw.get("CONF_KND", meeting_type)
    if sess:
        title_parts.append(str(sess))
    if dgr:
        title_parts.append(str(dgr))
    if conf_knd:
        title_parts.append(str(conf_knd))
    title = " ".join(title_parts) if title_parts else meeting_type

    return {
        "minute_id": raw.get("CONF_ID", ""),
        "meeting_type": meeting_type,
        "committee_id": raw.get("CMIT_CD"),
        "committee_name": raw.get("CMIT_NM"),
        "meeting_date": meeting_date or datetime(2000, 1, 1),
        "congress_number": 22,
        "title": title,
        "detail_link": raw.get("DOWN_URL"),
    }


def _normalize_committee_minute(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize a raw API row from ncwgseseafwbuheph into a Minute-compatible dict.

    API fields: CONFER_NUM, TITLE, CLASS_NAME, DAE_NUM, COMM_NAME,
    VODCOMM_CODE, CONF_DATE, SUB_NAME, VOD_LINK_URL, CONF_LINK_URL,
    PDF_LINK_URL, PDF_FILE_ID, DEPT_CD, CONF_ID
    """
    conf_date = raw.get("CONF_DATE", "")
    meeting_date: datetime | None = None
    if conf_date:
        try:
            meeting_date = datetime.strptime(conf_date.strip(), "%Y-%m-%d")
        except ValueError:
            try:
                meeting_date = datetime.strptime(conf_date.strip(), "%Y%m%d")
            except ValueError:
                logger.warning("Cannot parse CONF_DATE: %r", conf_date)

    # Use CONF_ID as primary key; fall back to CONFER_NUM
    conf_id = raw.get("CONF_ID", "") or raw.get("CONFER_NUM", "")

    # CLASS_NAME is the meeting type (e.g. "상임위원회 회의록")
    meeting_type = raw.get("CLASS_NAME", "위원회")

    return {
        "minute_id": conf_id,
        "meeting_type": meeting_type,
        "committee_id": raw.get("VODCOMM_CODE") or raw.get("DEPT_CD"),
        "committee_name": raw.get("COMM_NAME"),
        "meeting_date": meeting_date or datetime(2000, 1, 1),
        "congress_number": int(raw.get("DAE_NUM", 22)),
        "title": raw.get("TITLE", ""),
        "detail_link": raw.get("CONF_LINK_URL"),
        "pdf_link_url": raw.get("PDF_LINK_URL"),
        "vod_link_url": raw.get("VOD_LINK_URL"),
        "conf_link_url": raw.get("CONF_LINK_URL"),
        "sub_name": raw.get("SUB_NAME"),
    }


def _normalize_plenary_minute(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize a raw API row from nzbyfwhwaoanttzje (본회의 회의록) into a Minute-compatible dict.

    API fields are identical to committee minutes (ncwgseseafwbuheph):
    CONFER_NUM, TITLE, CLASS_NAME, DAE_NUM, CONF_DATE, SUB_NAME,
    VOD_LINK_URL, CONF_LINK_URL, PDF_LINK_URL, PDF_FILE_ID, CONF_ID
    """
    conf_date = raw.get("CONF_DATE", "")
    meeting_date: datetime | None = None
    if conf_date:
        try:
            meeting_date = datetime.strptime(conf_date.strip(), "%Y-%m-%d")
        except ValueError:
            try:
                meeting_date = datetime.strptime(conf_date.strip(), "%Y%m%d")
            except ValueError:
                logger.warning("Cannot parse CONF_DATE: %r", conf_date)

    conf_id = raw.get("CONF_ID", "") or raw.get("CONFER_NUM", "")

    return {
        "minute_id": conf_id,
        "meeting_type": "본회의",
        "committee_id": raw.get("VODCOMM_CODE") or raw.get("DEPT_CD"),
        "committee_name": raw.get("COMM_NAME"),
        "meeting_date": meeting_date or datetime(2000, 1, 1),
        "congress_number": int(raw.get("DAE_NUM", 22)),
        "title": raw.get("TITLE", ""),
        "detail_link": raw.get("CONF_LINK_URL"),
        "pdf_link_url": raw.get("PDF_LINK_URL"),
        "vod_link_url": raw.get("VOD_LINK_URL"),
        "conf_link_url": raw.get("CONF_LINK_URL"),
        "sub_name": raw.get("SUB_NAME"),
    }


async def collect_plenary_minutes(dry_run: bool = False) -> dict[str, Any]:
    """Fetch plenary session minutes from nzbyfwhwaoanttzje API and upsert into DB.

    This collects 본회의 (plenary session) minutes for the 22nd National Assembly (~349건).
    Fetches by year (CONF_DATE param) for 2024-2026.

    Returns:
        Summary dict with total, new, per-year counts, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000
    results: dict[str, int] = {}
    all_minutes: list[dict[str, Any]] = []
    status = "success"
    error_message = None

    try:
        async with AssemblyClient() as client:
            for year in PLENARY_MINUTES_YEARS:
                try:
                    rows = await client.fetch_all_bills(
                        PLENARY_MINUTES_ENDPOINT,
                        DAE_NUM="22",
                        CONF_DATE=year,
                    )
                    logger.info(
                        "Fetched %d plenary minute rows for year %s",
                        len(rows), year,
                    )
                    results[f"본회의_{year}"] = len(rows)

                    for raw in rows:
                        minute = _normalize_plenary_minute(raw)
                        if minute["minute_id"]:
                            all_minutes.append(minute)
                        else:
                            logger.warning(
                                "Skipping row without CONF_ID from %s year=%s",
                                PLENARY_MINUTES_ENDPOINT, year,
                            )

                except Exception as exc:
                    logger.error(
                        "Error fetching %s year=%s: %s",
                        PLENARY_MINUTES_ENDPOINT, year, exc,
                    )
                    results[f"본회의_{year}"] = 0

    except Exception as exc:
        status = "failed"
        error_message = str(exc)[:2000]
        logger.exception("collect_plenary_minutes failed: %s", exc)

    # Deduplicate by CONF_ID
    seen: set[str] = set()
    unique_minutes: list[dict[str, Any]] = []
    for m in all_minutes:
        if m["minute_id"] not in seen:
            seen.add(m["minute_id"])
            unique_minutes.append(m)

    total = len(unique_minutes)
    new_count = 0

    if not dry_run and unique_minutes:
        new_count = await _upsert_minutes(unique_minutes)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "source": PLENARY_MINUTES_ENDPOINT,
        "total": total,
        "new": new_count,
        "per_year": results,
        "status": status,
        "duration_ms": duration_ms,
    }
    if error_message:
        result["error"] = error_message

    logger.info("collect_plenary_minutes result: %s", result)
    return result


async def collect_committee_minutes(dry_run: bool = False) -> dict[str, Any]:
    """Fetch committee minutes from ncwgseseafwbuheph API and upsert into DB.

    This is the primary collection source for committee minutes (22대, ~2,569건).
    Fetches by year (CONF_DATE param) for 2024-2026.

    Returns:
        Summary dict with total, new, per-year counts, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000
    results: dict[str, int] = {}
    all_minutes: list[dict[str, Any]] = []
    status = "success"
    error_message = None

    try:
        async with AssemblyClient() as client:
            for year in COMMITTEE_MINUTES_YEARS:
                try:
                    rows = await client.fetch_all_bills(
                        COMMITTEE_MINUTES_ENDPOINT,
                        DAE_NUM="22",
                        CONF_DATE=year,
                    )
                    logger.info(
                        "Fetched %d committee minute rows for year %s",
                        len(rows), year,
                    )
                    results[f"위원회_{year}"] = len(rows)

                    for raw in rows:
                        minute = _normalize_committee_minute(raw)
                        if minute["minute_id"]:
                            all_minutes.append(minute)
                        else:
                            logger.warning(
                                "Skipping row without CONF_ID from %s year=%s",
                                COMMITTEE_MINUTES_ENDPOINT, year,
                            )

                except Exception as exc:
                    logger.error(
                        "Error fetching %s year=%s: %s",
                        COMMITTEE_MINUTES_ENDPOINT, year, exc,
                    )
                    results[f"위원회_{year}"] = 0

    except Exception as exc:
        status = "failed"
        error_message = str(exc)[:2000]
        logger.exception("collect_committee_minutes failed: %s", exc)

    # Deduplicate
    seen: set[str] = set()
    unique_minutes: list[dict[str, Any]] = []
    for m in all_minutes:
        if m["minute_id"] not in seen:
            seen.add(m["minute_id"])
            unique_minutes.append(m)

    total = len(unique_minutes)
    new_count = 0

    if not dry_run and unique_minutes:
        new_count = await _upsert_minutes(unique_minutes)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "source": COMMITTEE_MINUTES_ENDPOINT,
        "total": total,
        "new": new_count,
        "per_year": results,
        "status": status,
        "duration_ms": duration_ms,
    }
    if error_message:
        result["error"] = error_message

    logger.info("collect_committee_minutes result: %s", result)
    return result


async def collect_minutes(dry_run: bool = False) -> dict[str, Any]:
    """Fetch minutes from all 5 VCONF endpoint types and upsert into DB.

    Returns:
        Summary dict with total, new, per-endpoint counts, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000
    results: dict[str, int] = {}
    all_minutes: list[dict[str, Any]] = []
    status = "success"
    error_message = None

    try:
        async with AssemblyClient() as client:
            for endpoint_id, meeting_type in MINUTE_ENDPOINTS.items():
                try:
                    rows = await client.fetch_all_bills(
                        endpoint_id, ERACO=ASSEMBLY_ERA
                    )
                    logger.info(
                        "Fetched %d rows from %s (%s)",
                        len(rows), endpoint_id, meeting_type,
                    )
                    results[meeting_type] = len(rows)

                    for raw in rows:
                        minute = _normalize_minute(raw, meeting_type)
                        if minute["minute_id"]:
                            all_minutes.append(minute)
                        else:
                            logger.warning(
                                "Skipping row without CONF_ID from %s", endpoint_id
                            )

                except Exception as exc:
                    logger.error(
                        "Error fetching %s (%s): %s", endpoint_id, meeting_type, exc
                    )
                    results[meeting_type] = 0

    except Exception as exc:
        status = "failed"
        error_message = str(exc)[:2000]
        logger.exception("collect_minutes failed: %s", exc)

    # Deduplicate by minute_id (same CONF_ID may appear across endpoints)
    seen: set[str] = set()
    unique_minutes: list[dict[str, Any]] = []
    for m in all_minutes:
        if m["minute_id"] not in seen:
            seen.add(m["minute_id"])
            unique_minutes.append(m)

    total = len(unique_minutes)
    new_count = 0

    if not dry_run and unique_minutes:
        new_count = await _upsert_minutes(unique_minutes)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "total": total,
        "new": new_count,
        "per_type": results,
        "status": status,
        "duration_ms": duration_ms,
    }
    if error_message:
        result["error"] = error_message

    logger.info("collect_minutes result: %s", result)
    return result


async def _upsert_minutes(minute_dicts: list[dict]) -> int:
    """Upsert minutes using INSERT ... ON CONFLICT DO UPDATE for link fields.

    New rows are inserted normally.  For existing rows whose ``pdf_link_url``,
    ``vod_link_url``, or ``conf_link_url`` are currently NULL in the DB, the
    value from the API is back-filled.  This handles the common case where a
    minute was first collected before the National Assembly published its PDF.

    Returns:
        Number of newly inserted rows.
    """
    total_new = 0

    for i in range(0, len(minute_dicts), UPSERT_BATCH_SIZE):
        batch = minute_dicts[i: i + UPSERT_BATCH_SIZE]

        # Add IDs
        for d in batch:
            d["id"] = generate_cuid()

        async with AsyncSessionLocal() as session:
            async with session.begin():
                # Check existing
                minute_ids = [d["minute_id"] for d in batch]
                existing_result = await session.execute(
                    select(Minute.minute_id).where(
                        Minute.minute_id.in_(minute_ids)
                    )
                )
                existing_ids = {row[0] for row in existing_result.fetchall()}

                stmt = insert(Minute).values(batch)
                # On conflict: back-fill link columns only when the DB value
                # is NULL (COALESCE keeps the existing non-NULL value).
                stmt = stmt.on_conflict_do_update(
                    index_elements=["minute_id"],
                    set_={
                        "pdf_link_url": func.coalesce(
                            Minute.__table__.c.pdf_link_url,
                            stmt.excluded.pdf_link_url,
                        ),
                        "vod_link_url": func.coalesce(
                            Minute.__table__.c.vod_link_url,
                            stmt.excluded.vod_link_url,
                        ),
                        "conf_link_url": func.coalesce(
                            Minute.__table__.c.conf_link_url,
                            stmt.excluded.conf_link_url,
                        ),
                    },
                )
                await session.execute(stmt)

                batch_new = len(minute_ids) - len(existing_ids)
                total_new += batch_new

    return total_new


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="Collect minutes from Assembly API")
    parser.add_argument("--dry-run", action="store_true", help="Fetch only, no DB write")
    parser.add_argument(
        "--source",
        choices=["all", "vconf", "committee", "plenary"],
        default="all",
        help="Which endpoints to collect from (default: all)",
    )
    args = parser.parse_args()

    async def _main() -> None:
        if args.source in ("all", "plenary"):
            print("=== 본회의 회의록 (nzbyfwhwaoanttzje) ===")
            plenary_result = await collect_plenary_minutes(dry_run=args.dry_run)
            print(plenary_result)

        if args.source in ("all", "committee"):
            print("=== 위원회 회의록 (ncwgseseafwbuheph) ===")
            committee_result = await collect_committee_minutes(dry_run=args.dry_run)
            print(committee_result)

        if args.source in ("all", "vconf"):
            print("=== VCONF 회의록 ===")
            vconf_result = await collect_minutes(dry_run=args.dry_run)
            print(vconf_result)

    asyncio.run(_main())
