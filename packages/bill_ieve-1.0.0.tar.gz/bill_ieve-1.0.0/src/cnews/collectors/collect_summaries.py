"""Collect bill summaries from BPMBILLSUMMARY API and update bills.summary_original.

Two-step approach:
1. Fetch BILL_ID → BILL_NO mapping from nzmimeepazxkubdpn (bulk)
2. For each BILL_NO, call BPMBILLSUMMARY individually (no rate limit)

Usage::

    python -m cnews.collectors.collect_summaries
"""

from __future__ import annotations

import asyncio
import logging
import time

import httpx
from sqlalchemy import select, update

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill

logger = logging.getLogger(__name__)

BILLS_ENDPOINT = "nzmimeepazxkubdpn"
SUMMARY_ENDPOINT = "BPMBILLSUMMARY"
SUMMARY_BASE_URL = "https://open.assembly.go.kr/portal/openapi/BPMBILLSUMMARY"
ASSEMBLY_AGE = "22"
UPDATE_BATCH_SIZE = 500
REQUEST_DELAY = 0.1  # 100ms between individual calls


async def collect_summaries(limit: int = 0) -> dict:
    """Fetch summaries and update bills.summary_original.

    Args:
        limit: Max bills to process. 0 = all.

    Returns:
        Result dict with counts and status.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    total_bills = 0
    fetched = 0
    updated = 0
    skipped_null = 0
    skipped_not_found = 0

    try:
        # Step 1: Get bills that need summaries (summary_original IS NULL)
        async with AsyncSessionLocal() as session:
            stmt = (
                select(Bill.source_id)
                .where(Bill.summary_original.is_(None))
                .order_by(Bill.proposed_date.desc())
            )
            if limit:
                stmt = stmt.limit(limit)
            result = await session.execute(stmt)
            bill_ids_needing_summary = {row[0] for row in result.all()}

        total_bills = len(bill_ids_needing_summary)
        if total_bills == 0:
            logger.info("No bills need summary collection.")
            return _result(0, 0, 0, 0, 0, "success", start_ms)

        logger.info("Found %d bills needing summaries.", total_bills)

        # Step 2: Fetch BILL_ID → BILL_NO mapping from nzmimeepazxkubdpn
        async with AssemblyClient() as client:
            raw_rows = await client.fetch_all_bills(BILLS_ENDPOINT, AGE=ASSEMBLY_AGE)

        id_to_no: dict[str, str] = {}
        for row in raw_rows:
            bill_id = row.get("BILL_ID", "")
            bill_no = row.get("BILL_NO", "")
            if bill_id and bill_no and bill_id in bill_ids_needing_summary:
                id_to_no[bill_id] = bill_no

        logger.info("Mapped %d/%d bills to BILL_NO.", len(id_to_no), total_bills)

        # Step 3: Fetch summaries individually via BPMBILLSUMMARY
        import os
        api_key = os.getenv("ASSEMBLY_API_KEY", "")

        summaries: list[tuple[str, str]] = []

        async with httpx.AsyncClient(timeout=10.0) as http:
            for i, (bill_id, bill_no) in enumerate(id_to_no.items()):
                try:
                    resp = await http.get(SUMMARY_BASE_URL, params={
                        "Key": api_key,
                        "Type": "json",
                        "pSize": 1,
                        "BILL_NO": bill_no,
                    })
                    data = resp.json()

                    summary_text = None
                    if SUMMARY_ENDPOINT in data:
                        for item in data[SUMMARY_ENDPOINT]:
                            if "row" in item and item["row"]:
                                summary_text = item["row"][0].get("SUMMARY")

                    if summary_text:
                        summaries.append((bill_id, summary_text))
                        fetched += 1
                    else:
                        skipped_null += 1

                except Exception:
                    logger.warning("Failed to fetch summary for BILL_NO=%s", bill_no)
                    skipped_null += 1

                if (i + 1) % 100 == 0:
                    logger.info("Progress: %d/%d fetched, %d summaries found", i + 1, len(id_to_no), fetched)

                await asyncio.sleep(REQUEST_DELAY)

        logger.info("Fetched %d summaries (%d null-skipped).", fetched, skipped_null)

        # Step 4: Batch update DB
        for i in range(0, len(summaries), UPDATE_BATCH_SIZE):
            batch = summaries[i : i + UPDATE_BATCH_SIZE]
            not_found = await _update_batch(batch)
            skipped_not_found += not_found
            updated += len(batch) - not_found

    except Exception as exc:
        logger.exception("collect_summaries failed: %s", exc)
        return _result(total_bills, fetched, updated, skipped_null, skipped_not_found, "failed", start_ms, str(exc)[:2000])

    return _result(total_bills, fetched, updated, skipped_null, skipped_not_found, "success", start_ms)


def _result(total: int, fetched: int, updated: int, null: int, not_found: int, status: str, start_ms: int, error: str | None = None) -> dict:
    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms
    r = {
        "total_bills": total,
        "total_fetched": fetched,
        "updated": updated,
        "skipped_null": null,
        "skipped_not_found": not_found,
        "status": status,
        "duration_ms": duration_ms,
    }
    if error:
        r["error"] = error
    logger.info("collect_summaries result: %s", r)
    return r


async def _update_batch(summaries: list[tuple[str, str]]) -> int:
    """Update summary_original for a batch. Returns not_found count."""
    not_found = 0
    async with AsyncSessionLocal() as session:
        async with session.begin():
            for bill_id, summary_text in summaries:
                stmt = (
                    update(Bill)
                    .where(Bill.source_id == bill_id)
                    .values(summary_original=summary_text)
                )
                result = await session.execute(stmt)
                if result.rowcount == 0:
                    not_found += 1
    return not_found


if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    result = asyncio.run(collect_summaries())
    print(f"Result: {result}")
