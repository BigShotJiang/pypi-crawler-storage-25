"""US Congress bill collector — fetches bills from Congress.gov API v3.

Fast list-only collection with status mapping from latestAction.
All statuses stored: PROPOSED, COMMITTEE, PLENARY, PASSED, REJECTED.

Usage:
    from cnews.collectors.us_collect_bills import collect_us_bills
    stats = await collect_us_bills(days=365)
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from cnews.clients.congress_client import CongressClient
from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill

logger = logging.getLogger(__name__)

CONGRESS = 119


async def collect_us_bills(days: int = 365) -> dict:
    """Collect US bills from Congress.gov API (fast, list-only).

    Args:
        days: Fetch bills updated in the last N days.

    Returns:
        Dict with collection stats.
    """
    from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")
    to_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    stats = {"fetched": 0, "new": 0, "skipped": 0, "errors": 0}

    async with CongressClient() as client:
        offset = 0
        all_bills: list[dict] = []

        while True:
            data = await client.fetch_bills(
                congress=CONGRESS,
                from_date=from_date,
                to_date=to_date,
                limit=250,
                offset=offset,
            )
            bills = data.get("bills", [])
            if not bills:
                break
            all_bills.extend(bills)
            offset += len(bills)
            total = data.get("pagination", {}).get("count", 0)
            logger.info("Fetched %d/%d US bills", len(all_bills), total)
            if len(all_bills) >= total:
                break
            await asyncio.sleep(0.5)

        stats["fetched"] = len(all_bills)
        logger.info("Total US bills fetched: %d", len(all_bills))

    # Batch insert
    async with AsyncSessionLocal() as session:
        existing_result = await session.execute(
            select(Bill.source_id).where(Bill.country == "US")
        )
        existing_ids = {row[0] for row in existing_result}
        logger.info("Existing US bills in DB: %d", len(existing_ids))

        batch: list[Bill] = []
        for bill_data in all_bills:
            try:
                bill = _build_bill(bill_data)
                if bill.source_id in existing_ids:
                    stats["skipped"] += 1
                    continue
                batch.append(bill)
                existing_ids.add(bill.source_id)
                stats["new"] += 1
            except Exception as e:
                logger.error("Error building bill %s: %s", bill_data.get("number"), e)
                stats["errors"] += 1

        if batch:
            session.add_all(batch)
            await session.commit()
            logger.info("Inserted %d new US bills", len(batch))

    logger.info("US collection done: %s", stats)
    return stats


def _build_bill(bill_data: dict) -> Bill:
    """Build a Bill object from Congress.gov list response with status mapping."""
    congress = bill_data.get("congress", CONGRESS)
    bill_type = bill_data.get("type", "HR").lower()
    number = bill_data.get("number", "")
    source_id = f"US-{congress}-{bill_type}-{number}"

    title = bill_data.get("title", "")
    latest_action = bill_data.get("latestAction", {})
    action_text = latest_action.get("text", "")
    action_date = latest_action.get("actionDate", "")

    # Use action date as proposed_date
    try:
        proposed_date = datetime.strptime(action_date[:10], "%Y-%m-%d")
    except (ValueError, TypeError):
        update_date = bill_data.get("updateDate", "")
        try:
            proposed_date = datetime.strptime(update_date[:10], "%Y-%m-%d")
        except (ValueError, TypeError):
            proposed_date = datetime.now(timezone.utc)

    # Status mapping from latestAction text
    status = CongressClient.map_status(action_text)

    # Source URL
    origin_chamber = bill_data.get("originChamberCode", "H").lower()
    chamber_name = "house-bill" if origin_chamber == "h" else "senate-bill"
    source_url = f"https://www.congress.gov/bill/{congress}th-congress/{chamber_name}/{number}"

    # Law number if passed
    laws = bill_data.get("laws", [])
    summary = None
    if laws:
        law_num = laws[0].get("number", "")
        summary = f"Public Law {law_num}" if law_num else None

    return Bill(
        country="US",
        source_id=source_id,
        title_original=title,
        summary_original=summary,
        proposer=None,
        proposed_date=proposed_date,
        status=status,
        committee_name=None,
        source_url=source_url,
        category_id=None,
    )
