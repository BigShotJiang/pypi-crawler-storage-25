"""EU legislation collector — fetches Directives & Regulations from CELLAR SPARQL.

Collects legislation metadata and stores in DB with country='EU'.
AI translation (EN→KR) and category classification handled separately.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from cnews.clients.cellar_client import CellarClient
from cnews.db import AsyncSessionLocal
from cnews.models.bill import Bill

logger = logging.getLogger(__name__)

# EU status mapping based on resource type
EU_STATUS_MAP = {
    "DIR": "PASSED",       # Adopted Directive
    "REG": "PASSED",       # Adopted Regulation
    "PROP_DIR": "PROPOSED", # Proposed Directive
    "PROP_REG": "PROPOSED", # Proposed Regulation
}


async def collect_eu_bills(days: int = 365) -> dict:
    """Collect recent EU legislation from CELLAR SPARQL.

    Args:
        days: Fetch legislation from the last N days.

    Returns:
        Dict with collection stats.
    """
    from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")

    stats = {"fetched": 0, "new": 0, "skipped": 0, "errors": 0}

    async with CellarClient() as client:
        all_legislation = await client.fetch_all_legislation(from_date=from_date)
        stats["fetched"] = len(all_legislation)
        logger.info("Total EU legislation fetched: %d", len(all_legislation))

        async with AsyncSessionLocal() as session:
            for item in all_legislation:
                try:
                    created = await _upsert_eu_bill(session, item)
                    if created:
                        stats["new"] += 1
                    else:
                        stats["skipped"] += 1
                except Exception as e:
                    logger.error("Error processing EU item %s: %s", item.get("cellar_id"), e)
                    stats["errors"] += 1

            await session.commit()

    logger.info("EU collection done: %s", stats)
    return stats


async def _upsert_eu_bill(session, item: dict) -> bool:
    """Insert a single EU legislation item. Returns True if new."""
    cellar_id = item.get("cellar_id", "")
    source_id = f"EU-{cellar_id}"

    # Check if already exists
    existing = await session.execute(
        select(Bill).where(Bill.source_id == source_id)
    )
    if existing.scalar_one_or_none():
        return False

    title = item.get("title", "")
    date_str = item.get("date", "")
    resource_type = item.get("resource_type", "")
    resource_label = item.get("resource_type_label", "")

    try:
        proposed_date = datetime.strptime(date_str[:10], "%Y-%m-%d")
    except (ValueError, TypeError):
        proposed_date = datetime.now(timezone.utc)

    status = EU_STATUS_MAP.get(resource_type, "PROPOSED")

    # EUR-Lex URL from CELLAR URI
    source_url = f"https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:{cellar_id}"

    bill = Bill(
        country="EU",
        source_id=source_id,
        title_original=title,
        summary_original=None,  # EUR-Lex SOAP needed for full text
        proposer=resource_label,  # Store type as proposer for now
        proposed_date=proposed_date,
        status=status,
        source_url=source_url,
        category_id=None,  # AI classification needed
    )
    session.add(bill)
    return True
