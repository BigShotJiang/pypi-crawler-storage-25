"""Collect petition data from the National Assembly Open API (PTTRCP endpoint).

Replaces the previous hardcoded sample seeder. Fetches all petitions for
the 22nd National Assembly (제22대) from the PTTRCP endpoint.

Usage::

    python -m cnews.collectors.collect_petitions
    python -m cnews.collectors.collect_petitions --dry-run
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import time
from datetime import datetime
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.petition import Petition
from cnews.models.base import generate_cuid

logger = logging.getLogger(__name__)

# Endpoint ID for petition data
PETITION_ENDPOINT = "PTTRCP"
PAGE_SIZE = 100
UPSERT_BATCH_SIZE = 100


def _parse_agree_count(raw: Any) -> int:
    """Parse CITZN_AGM_CNT — may contain commas or be None."""
    if raw is None:
        return 0
    if isinstance(raw, int):
        return raw
    cleaned = str(raw).replace(",", "").strip()
    if not cleaned:
        return 0
    try:
        return int(cleaned)
    except ValueError:
        logger.warning("Unparseable agree_count: %r", raw)
        return 0


def _parse_date(raw: Any) -> datetime | None:
    """Parse RCP_DT — formats like '2024-06-01', '20240601'."""
    if not raw:
        return None
    cleaned = str(raw).strip()
    for fmt in ("%Y-%m-%d", "%Y%m%d"):
        try:
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            continue
    logger.warning("Unparseable petition date: %r", cleaned)
    return None


def _map_row(row: dict[str, Any]) -> dict[str, Any]:
    """Map a single PTTRCP API row to Petition model fields."""
    return {
        "source_id": str(row.get("PTT_ID", "")).strip() or None,
        "title": str(row.get("PTT_NM", "")).strip(),
        "agree_count": _parse_agree_count(row.get("CITZN_AGM_CNT")),
        "target_count": None,  # Not available from API
        "status": str(row.get("PTT_KIND", "")).strip() or "UNKNOWN",
        "petition_date": _parse_date(row.get("RCP_DT")),
        "source_url": str(row.get("LINK_URL", "")).strip() or "",
        "petitioner": str(row.get("PTTR_NM", "")).strip() or None,
        "petition_no": str(row.get("PTT_NO", "")).strip() or None,
        "petition_kind": str(row.get("PTT_KIND", "")).strip() or None,
        "introducer": str(row.get("INTD_ASBLM_NM", "")).strip() or None,
        "committee_name": None,  # Not directly available from PTTRCP
    }


async def collect_petitions(*, dry_run: bool = False) -> dict[str, Any]:
    """Collect petition data from the PTTRCP endpoint.

    Args:
        dry_run: Fetch and parse without writing to DB.

    Returns:
        Dict with collection statistics.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    stats: dict[str, Any] = {
        "fetched_rows": 0,
        "new_count": 0,
        "updated_count": 0,
        "deleted_old": 0,
        "api_calls": 0,
        "status": "success",
        "error_message": None,
        "top3": [],
    }

    try:
        async with AssemblyClient(page_size=PAGE_SIZE) as client:
            logger.info("Fetching petitions from PTTRCP (ERACO=제22대)...")
            all_rows = await client.fetch_all_bills(
                PETITION_ENDPOINT,
                ERACO="제22대",
            )
            stats["fetched_rows"] = len(all_rows)
            stats["api_calls"] = max(
                1, (len(all_rows) // PAGE_SIZE) + (1 if len(all_rows) % PAGE_SIZE else 0)
            )
            logger.info("Fetched %d petition rows", len(all_rows))

            # Map rows
            mapped = [_map_row(r) for r in all_rows]

            # Filter out rows without title
            mapped = [m for m in mapped if m["title"]]

            # Sort by agree_count desc for top 3 reporting
            sorted_by_agree = sorted(mapped, key=lambda x: x["agree_count"], reverse=True)
            stats["top3"] = [
                {"title": p["title"], "agree_count": p["agree_count"]}
                for p in sorted_by_agree[:3]
            ]

            if dry_run:
                logger.info("[DRY RUN] Would upsert %d petitions", len(mapped))
                for i, p in enumerate(stats["top3"], 1):
                    logger.info(
                        "  TOP %d: %s (동의 %s건)",
                        i,
                        p["title"][:60],
                        f"{p['agree_count']:,}",
                    )
                stats["duration_ms"] = (time.monotonic_ns() // 1_000_000) - start_ms
                return stats

            # Delete old hardcoded data that doesn't have source_id
            async with AsyncSessionLocal() as session:
                async with session.begin():
                    del_stmt = delete(Petition).where(Petition.source_id.is_(None))
                    del_result = await session.execute(del_stmt)
                    stats["deleted_old"] = del_result.rowcount
                    if stats["deleted_old"]:
                        logger.info(
                            "Deleted %d old petitions without source_id",
                            stats["deleted_old"],
                        )

            # Upsert in batches
            total_new = 0
            total_updated = 0

            for i in range(0, len(mapped), UPSERT_BATCH_SIZE):
                batch = mapped[i : i + UPSERT_BATCH_SIZE]
                values = [
                    {
                        "id": generate_cuid(),
                        **rec,
                    }
                    for rec in batch
                ]

                async with AsyncSessionLocal() as session:
                    async with session.begin():
                        stmt = insert(Petition.__table__).values(values)
                        stmt = stmt.on_conflict_do_update(
                            index_elements=["source_id"],
                            set_={
                                "title": stmt.excluded.title,
                                "agree_count": stmt.excluded.agree_count,
                                "status": stmt.excluded.status,
                                "petition_date": stmt.excluded.petition_date,
                                "source_url": stmt.excluded.source_url,
                                "petitioner": stmt.excluded.petitioner,
                                "petition_no": stmt.excluded.petition_no,
                                "petition_kind": stmt.excluded.petition_kind,
                                "introducer": stmt.excluded.introducer,
                            },
                        )
                        result = await session.execute(stmt)
                        # rowcount for INSERT ON CONFLICT: new rows count as 1
                        batch_affected = result.rowcount
                        total_new += batch_affected

                logger.info(
                    "Upsert batch %d-%d: %d rows affected",
                    i,
                    min(i + UPSERT_BATCH_SIZE, len(mapped)),
                    batch_affected,
                )

            stats["new_count"] = total_new
            stats["updated_count"] = total_updated

    except Exception as exc:
        stats["status"] = "failed"
        stats["error_message"] = str(exc)[:2000]
        logger.exception("collect_petitions failed: %s", exc)

    stats["duration_ms"] = (time.monotonic_ns() // 1_000_000) - start_ms
    logger.info("collect_petitions result: %s", stats)
    return stats


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        description="Collect petition data from the National Assembly PTTRCP API"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fetch and parse data without writing to DB",
    )
    args = parser.parse_args()

    result = asyncio.run(collect_petitions(dry_run=args.dry_run))
    print(f"\n{'='*60}")
    print(f"수집 결과: {result['fetched_rows']}건 수집, {result['new_count']}건 upsert")
    print(f"상태: {result['status']}")
    if result.get("top3"):
        print("\n동의 수 TOP 3:")
        for i, p in enumerate(result["top3"], 1):
            print(f"  {i}. {p['title'][:70]} — 동의 {p['agree_count']:,}건")
    if result.get("error_message"):
        print(f"오류: {result['error_message']}")
    print(f"소요시간: {result.get('duration_ms', 0):,}ms")
