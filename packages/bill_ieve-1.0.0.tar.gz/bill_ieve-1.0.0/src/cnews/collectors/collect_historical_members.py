"""Collect historical member data from the ALLNAMEMBER API and upsert into the database.

Collects all-time National Assembly members (역대 국회의원).
Skips members who already exist (by member_id) to avoid overwriting current 22nd members.

Usage::

    python -m cnews.collectors.collect_historical_members
    python -m cnews.collectors.collect_historical_members --dry-run
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.db import AsyncSessionLocal
from cnews.models.base import generate_cuid
from cnews.models.member import Member

logger = logging.getLogger(__name__)

ENDPOINT_ID = "ALLNAMEMBER"
UPSERT_BATCH_SIZE = 200


def _parse_congress_numbers(eraco_str: str | None) -> list[int]:
    """Parse GTELT_ERACO like '제9대, 제10대' into [9, 10]."""
    if not eraco_str:
        return []
    nums = re.findall(r"(\d+)", eraco_str)
    return [int(n) for n in nums]


def _parse_election_count(rlct_div: str | None, eraco_str: str | None) -> int:
    """Parse election count from RLCT_DIV_NM ('재선') or GTELT_ERACO count."""
    _map = {
        "초선": 1, "재선": 2, "3선": 3, "4선": 4, "5선": 5,
        "6선": 6, "7선": 7, "8선": 8, "9선": 9,
    }
    if rlct_div and rlct_div.strip() in _map:
        return _map[rlct_div.strip()]
    # Fallback: count congress numbers
    nums = _parse_congress_numbers(eraco_str)
    return len(nums) if nums else 1


def _normalize_historical_member(raw: dict) -> dict | None:
    """Normalize an ALLNAMEMBER API row into a dict matching the Member model.

    Returns None if the row is missing the required member_id (NAAS_CD).
    """
    member_id = (raw.get("NAAS_CD") or "").strip()
    if not member_id:
        return None

    name = (raw.get("NAAS_NM") or "").strip()
    if not name:
        return None

    # Parse party — may contain slashes for multi-term parties
    party_raw = raw.get("PLPT_NM") or ""
    # Take first party if slash-separated
    party = party_raw.split("/")[0].strip() if party_raw else "무소속"

    # Parse district — may contain slashes
    district_raw = raw.get("ELECD_NM") or ""
    district = district_raw.split("/")[0].strip() if district_raw else "비례대표"

    # Congress number: take the latest (highest) from GTELT_ERACO
    congress_numbers = _parse_congress_numbers(raw.get("GTELT_ERACO"))
    congress_number = max(congress_numbers) if congress_numbers else 1

    # Election count
    election_count = _parse_election_count(
        raw.get("RLCT_DIV_NM"), raw.get("GTELT_ERACO")
    )

    # Term start date: approximate from congress number
    # Korean congress terms: roughly every 4 years since 1948
    # 1대: 1948, 2대: 1950, ... 22대: 2024
    # Use a rough estimate; exact dates are not in the API
    _term_starts = {
        1: 1948, 2: 1950, 3: 1954, 4: 1958, 5: 1960, 6: 1963,
        7: 1967, 8: 1971, 9: 1973, 10: 1978, 11: 1981, 12: 1985,
        13: 1988, 14: 1992, 15: 1996, 16: 2000, 17: 2004, 18: 2008,
        19: 2012, 20: 2016, 21: 2020, 22: 2024,
    }
    start_year = _term_starts.get(congress_number, 2000)
    term_start_date = datetime(start_year, 5, 30)

    email = (raw.get("NAAS_EMAIL_ADDR") or "").strip() or None
    pic = (raw.get("NAAS_PIC") or "").strip() or None

    return {
        "id": generate_cuid(),
        "member_id": member_id,
        "name": name,
        "party": party,
        "district": district,
        "congress_number": congress_number,
        "election_count": election_count,
        "term_start_date": term_start_date,
        "email": email,
        "profile_image_url": pic,
    }


async def _upsert_historical_members(
    member_dicts: list[dict],
) -> tuple[int, int]:
    """Upsert members using INSERT ... ON CONFLICT DO NOTHING.

    Only inserts members whose member_id does not already exist
    (preserving existing 22nd congress current member data).

    Returns:
        (new_count, skipped_count)
    """
    total_new = 0
    total_skipped = 0

    for i in range(0, len(member_dicts), UPSERT_BATCH_SIZE):
        batch = member_dicts[i : i + UPSERT_BATCH_SIZE]

        async with AsyncSessionLocal() as session:
            async with session.begin():
                member_ids = [d["member_id"] for d in batch]
                existing_result = await session.execute(
                    select(Member.member_id).where(
                        Member.member_id.in_(member_ids)
                    )
                )
                existing_ids = {row[0] for row in existing_result.fetchall()}

                # Only insert new members (skip existing)
                new_batch = [d for d in batch if d["member_id"] not in existing_ids]
                if new_batch:
                    stmt = insert(Member).values(new_batch)
                    stmt = stmt.on_conflict_do_nothing(
                        index_elements=["member_id"],
                    )
                    await session.execute(stmt)

                batch_new = len(new_batch)
                batch_skipped = len(batch) - batch_new
                total_new += batch_new
                total_skipped += batch_skipped

    return total_new, total_skipped


async def collect_historical_members(dry_run: bool = False) -> dict:
    """Fetch all historical members from ALLNAMEMBER and insert new ones into DB.

    Existing members (e.g. 22nd congress current members) are preserved.

    Returns:
        Summary dict with total, new, skipped, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    total_api = 0
    normalized_count = 0
    new_count = 0
    skipped_count = 0
    status = "success"

    try:
        async with AssemblyClient(page_size=100) as client:
            raw_rows = await client.fetch_all_bills(ENDPOINT_ID)

        total_api = len(raw_rows)
        logger.info("Fetched %d historical members from ALLNAMEMBER API", total_api)

        # Normalize
        normalized: list[dict] = []
        for raw in raw_rows:
            row = _normalize_historical_member(raw)
            if row:
                normalized.append(row)
            else:
                logger.debug(
                    "Skipping row with missing NAAS_CD/NAAS_NM: %s",
                    raw.get("NAAS_CD"),
                )

        normalized_count = len(normalized)
        logger.info("Normalized %d members from %d API rows", normalized_count, total_api)

        # Deduplicate by member_id (take first occurrence)
        seen: set[str] = set()
        unique: list[dict] = []
        for m in normalized:
            if m["member_id"] not in seen:
                seen.add(m["member_id"])
                unique.append(m)

        if not dry_run and unique:
            new_count, skipped_count = await _upsert_historical_members(unique)

    except Exception as exc:
        status = "failed"
        logger.exception("collect_historical_members failed: %s", exc)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    result = {
        "total_api": total_api,
        "normalized": normalized_count,
        "new": new_count,
        "skipped_existing": skipped_count,
        "status": status,
        "duration_ms": duration_ms,
    }
    logger.info("collect_historical_members result: %s", result)
    return result


if __name__ == "__main__":
    import argparse
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        description="Collect historical members from ALLNAMEMBER API"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Fetch + normalize only, no DB write"
    )
    args = parser.parse_args()

    result = asyncio.run(collect_historical_members(dry_run=args.dry_run))
    print(result)
