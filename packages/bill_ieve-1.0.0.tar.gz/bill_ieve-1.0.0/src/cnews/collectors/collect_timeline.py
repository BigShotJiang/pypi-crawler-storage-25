"""Collect bill timeline (심사 이력) from the BILLJUDGE API.

Fetches judgment/review history for bills and stores them in the
``bill_status_history`` table.

Usage::

    # As a module
    from cnews.collectors.collect_timeline import collect_timeline
    result = await collect_timeline()

    # As a CLI script
    python -m cnews.collectors.collect_timeline
    python -m cnews.collectors.collect_timeline --dry-run
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import time
from typing import Any

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert

from cnews.clients.assembly_client import AssemblyClient
from cnews.clients.normalizers import map_proc_result_to_bill_status, parse_assembly_date
from cnews.db import AsyncSessionLocal
from cnews.models import Bill, BillStatusHistory, CollectionLog
from cnews.models.base import generate_cuid
from cnews.models.enums import BillStatus

logger = logging.getLogger(__name__)

ENDPOINT_ID = "BILLJUDGE"
PAGE_SIZE = 1000
UPSERT_BATCH_SIZE = 500


# ---------------------------------------------------------------------------
# BILLJUDGE row -> BillStatusHistory records
# ---------------------------------------------------------------------------

def _build_timeline_events(raw: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract timeline events from a single BILLJUDGE API row.

    Each row may contain multiple date fields representing different stages:
      - BDG_CMMT_DT: 위원회 회부일 (committee referral)
      - JRCMIT_PRSNT_DT: 소위 상정일 (subcommittee presentation)
      - JRCMIT_PROC_DT: 소위 처리일 (subcommittee processing)
      - JRCMIT_PROC_RSLT: 처리결과 (processing result)

    Returns a list of dicts suitable for BillStatusHistory insertion.
    """
    bill_source_id = raw.get("BILL_ID", "")
    if not bill_source_id:
        return []

    events: list[dict[str, Any]] = []

    # Event 1: 위원회 회부 (committee referral)
    bdg_cmmt_dt = parse_assembly_date(raw.get("BDG_CMMT_DT"))
    if bdg_cmmt_dt:
        events.append({
            "source_id": bill_source_id,
            "status": BillStatus.COMMITTEE,
            "changed_at": bdg_cmmt_dt,
            "description": "소관위원회 회부",
        })

    # Event 2: 소위 상정 (subcommittee presentation)
    jrcmit_prsnt_dt = parse_assembly_date(raw.get("JRCMIT_PRSNT_DT"))
    if jrcmit_prsnt_dt:
        events.append({
            "source_id": bill_source_id,
            "status": BillStatus.COMMITTEE,
            "changed_at": jrcmit_prsnt_dt,
            "description": "소위원회 상정",
        })

    # Event 3: 소위 처리 (subcommittee processing)
    jrcmit_proc_dt = parse_assembly_date(raw.get("JRCMIT_PROC_DT"))
    proc_rslt = raw.get("JRCMIT_PROC_RSLT", "")
    if jrcmit_proc_dt:
        # Map the result to a status if meaningful
        mapped_status = map_proc_result_to_bill_status(proc_rslt)
        status_enum = BillStatus(mapped_status) if mapped_status != "PROPOSED" else BillStatus.COMMITTEE
        desc = f"소위원회 처리: {proc_rslt}" if proc_rslt else "소위원회 처리"
        events.append({
            "source_id": bill_source_id,
            "status": status_enum,
            "changed_at": jrcmit_proc_dt,
            "description": desc,
        })

    return events


# ---------------------------------------------------------------------------
# DB operations
# ---------------------------------------------------------------------------

async def _load_bill_source_id_map() -> dict[str, str]:
    """Load a mapping of source_id -> bill.id from the bills table."""
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Bill.id, Bill.source_id))
        return {row.source_id: row.id for row in result.fetchall()}


async def _upsert_timeline(records: list[dict[str, Any]]) -> tuple[int, int]:
    """Upsert timeline records into bill_status_history.

    Uses bill_id + changed_at + status as the dedup key (checks for existence
    before inserting to avoid duplicates).

    Returns:
        (new_count, skipped_count)
    """
    new_count = 0
    skipped_count = 0

    for i in range(0, len(records), UPSERT_BATCH_SIZE):
        batch = records[i: i + UPSERT_BATCH_SIZE]

        async with AsyncSessionLocal() as session:
            async with session.begin():
                for rec in batch:
                    # Check for existing record with same bill_id + changed_at + status
                    existing = await session.execute(
                        select(BillStatusHistory.id).where(
                            BillStatusHistory.bill_id == rec["bill_id"],
                            BillStatusHistory.changed_at == rec["changed_at"],
                            BillStatusHistory.status == rec["status"],
                        ).limit(1)
                    )
                    if existing.scalar_one_or_none() is not None:
                        skipped_count += 1
                        continue

                    history = BillStatusHistory(
                        id=generate_cuid(),
                        bill_id=rec["bill_id"],
                        status=rec["status"],
                        changed_at=rec["changed_at"],
                        description=rec["description"],
                    )
                    session.add(history)
                    new_count += 1

    return new_count, skipped_count


# ---------------------------------------------------------------------------
# Main collection function
# ---------------------------------------------------------------------------

async def collect_timeline(*, dry_run: bool = False) -> dict[str, Any]:
    """Fetch BILLJUDGE data and populate bill_status_history.

    Args:
        dry_run: If True, fetch and parse data but do not write to DB.

    Returns:
        A dict with keys: total_rows, events_parsed, matched, new, skipped,
        unmatched, api_calls, status.
    """
    start_ms = time.monotonic_ns() // 1_000_000

    total_rows = 0
    events_parsed = 0
    matched = 0
    unmatched = 0
    new_count = 0
    skipped_count = 0
    api_calls = 0
    status = "success"
    error_message = None

    try:
        # 1. Fetch all BILLJUDGE rows (22대: ERACO parameter)
        logger.info("Fetching BILLJUDGE data (22대, page_size=%d)...", PAGE_SIZE)
        async with AssemblyClient(page_size=PAGE_SIZE) as client:
            all_rows = await client.fetch_all_bills(
                ENDPOINT_ID,
                ERACO="제22대",
            )
        total_rows = len(all_rows)
        # Estimate API calls based on page size
        api_calls = (total_rows // PAGE_SIZE) + (1 if total_rows % PAGE_SIZE else 0)
        if api_calls == 0:
            api_calls = 1  # At least one call was made
        logger.info("Fetched %d BILLJUDGE rows in ~%d API calls", total_rows, api_calls)

        # 2. Parse timeline events from raw rows
        all_events: list[dict[str, Any]] = []
        for raw in all_rows:
            events = _build_timeline_events(raw)
            all_events.extend(events)
        events_parsed = len(all_events)
        logger.info("Parsed %d timeline events from %d rows", events_parsed, total_rows)

        if dry_run:
            # In dry-run mode, just report what we found
            logger.info("[DRY RUN] Would load bill source_id map and insert events")
            # Still try to count matches
            bill_map = await _load_bill_source_id_map()
            for ev in all_events:
                if ev["source_id"] in bill_map:
                    matched += 1
                else:
                    unmatched += 1
            logger.info(
                "[DRY RUN] Matched: %d, Unmatched: %d (out of %d events)",
                matched, unmatched, events_parsed,
            )
        else:
            # 3. Load bill source_id -> id mapping
            bill_map = await _load_bill_source_id_map()
            logger.info("Loaded %d bills from DB for source_id matching", len(bill_map))

            # 4. Map source_id to bill_id and filter unmatched
            records_to_insert: list[dict[str, Any]] = []
            for ev in all_events:
                bill_id = bill_map.get(ev["source_id"])
                if bill_id:
                    records_to_insert.append({
                        "bill_id": bill_id,
                        "status": ev["status"],
                        "changed_at": ev["changed_at"],
                        "description": ev["description"],
                    })
                    matched += 1
                else:
                    unmatched += 1

            logger.info(
                "Matched %d events to bills, %d unmatched",
                matched, unmatched,
            )

            # 5. Upsert into bill_status_history
            if records_to_insert:
                new_count, skipped_count = await _upsert_timeline(records_to_insert)
                logger.info(
                    "Inserted %d new records, skipped %d duplicates",
                    new_count, skipped_count,
                )

    except Exception as exc:
        status = "failed"
        error_message = str(exc)[:2000]
        logger.exception("collect_timeline failed: %s", exc)

    duration_ms = (time.monotonic_ns() // 1_000_000) - start_ms

    # Write collection log (unless dry run)
    if not dry_run:
        try:
            async with AsyncSessionLocal() as session:
                async with session.begin():
                    log = CollectionLog(
                        id=generate_cuid(),
                        bills_count=events_parsed,
                        new_bills_count=new_count,
                        updated_bills_count=skipped_count,
                        status=status,
                        error_message=error_message,
                        duration_ms=duration_ms,
                    )
                    session.add(log)
        except Exception:
            logger.exception("Failed to write CollectionLog for timeline")

    result = {
        "total_rows": total_rows,
        "events_parsed": events_parsed,
        "matched": matched,
        "new": new_count,
        "skipped": skipped_count,
        "unmatched": unmatched,
        "api_calls": api_calls,
        "status": status,
        "duration_ms": duration_ms,
    }
    logger.info("collect_timeline result: %s", result)
    return result


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        description="Collect bill timeline data from BILLJUDGE API"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Fetch and parse data without writing to DB",
    )
    args = parser.parse_args()

    result = asyncio.run(collect_timeline(dry_run=args.dry_run))
    print(result)
