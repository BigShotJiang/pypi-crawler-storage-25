from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, Index, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid
from .enums import VoteResult

if TYPE_CHECKING:
    from .bill import Bill
    from .member import Member


class Vote(Base):
    __tablename__ = "votes"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id", ondelete="CASCADE"), nullable=False)
    vote_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    vote_result: Mapped[VoteResult] = mapped_column(nullable=False)

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="votes")
    member: Mapped["Member"] = relationship(back_populates="votes")

    __table_args__ = (
        UniqueConstraint("bill_id", "member_id", name="uq_votes_bill_member"),
        Index("idx_votes_bill_result", "bill_id", "vote_result"),
    )
