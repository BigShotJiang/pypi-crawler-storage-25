from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import ARRAY, DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill_industry import BillIndustry


class IndustryTag(Base):
    __tablename__ = "industry_tags"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    keywords: Mapped[list[str]] = mapped_column(
        ARRAY(String), server_default="{}", nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    bills: Mapped[list["BillIndustry"]] = relationship(
        back_populates="industry_tag", cascade="all, delete-orphan"
    )
