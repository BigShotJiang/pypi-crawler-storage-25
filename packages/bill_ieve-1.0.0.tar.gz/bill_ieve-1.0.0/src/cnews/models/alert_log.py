from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid
from .enums import AlertChannel

if TYPE_CHECKING:
    from .bill import Bill
    from .keyword_alert import KeywordAlert


class AlertLog(Base):
    __tablename__ = "alert_logs"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    alert_id: Mapped[str] = mapped_column(ForeignKey("keyword_alerts.id", ondelete="CASCADE"), nullable=False)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    sent_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    channel: Mapped[AlertChannel] = mapped_column(nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    alert: Mapped["KeywordAlert"] = relationship(back_populates="alert_logs")
    bill: Mapped["Bill"] = relationship(back_populates="alert_logs")

    __table_args__ = (
        Index("idx_alert_logs_alert_sent", "alert_id", sent_at.desc()),
    )
