from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, SmallInteger, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .member import Member


class Committee(Base):
    __tablename__ = "committees"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    committee_id: Mapped[str] = mapped_column(
        String(20), unique=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    committee_type: Mapped[str] = mapped_column(String(20), nullable=False)
    chairperson_id: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    member_count: Mapped[Optional[int]] = mapped_column(SmallInteger, nullable=True)
    jurisdiction: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    members: Mapped[list["Member"]] = relationship(back_populates="committee")
