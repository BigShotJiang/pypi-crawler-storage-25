from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, Float, ForeignKey, Index, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill import Bill
    from .industry_tag import IndustryTag


class BillIndustry(Base):
    __tablename__ = "bill_industries"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    industry_tag_id: Mapped[str] = mapped_column(ForeignKey("industry_tags.id", ondelete="CASCADE"), nullable=False)
    relevance_score: Mapped[float] = mapped_column(Float, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="industries")
    industry_tag: Mapped["IndustryTag"] = relationship(back_populates="bills")

    __table_args__ = (
        UniqueConstraint(
            "bill_id", "industry_tag_id", name="uq_bill_industries_bill_industry"
        ),
        Index("idx_bill_industry_bill_id", "bill_id"),
        Index("idx_bill_industry_industry_id", "industry_tag_id"),
    )
