from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, SmallInteger, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill_sponsor import BillSponsor
    from .committee import Committee
    from .vote import Vote


class Member(Base):
    __tablename__ = "members"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    member_id: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    party: Mapped[str] = mapped_column(String(50), nullable=False)
    district: Mapped[str] = mapped_column(String(50), nullable=False)
    congress_number: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    election_count: Mapped[Optional[int]] = mapped_column(
        SmallInteger, default=1, nullable=True
    )
    term_start_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    term_end_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    committee_id: Mapped[Optional[str]] = mapped_column(ForeignKey("committees.id", ondelete="SET NULL"), nullable=True)
    profile_image_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    committee: Mapped[Optional["Committee"]] = relationship(back_populates="members")
    sponsors: Mapped[list["BillSponsor"]] = relationship(back_populates="member")
    votes: Mapped[list["Vote"]] = relationship(back_populates="member")

    __table_args__ = (
        Index("idx_members_party", "party"),
        Index(
            "idx_members_name_trgm",
            "name",
            postgresql_using="gin",
            postgresql_ops={"name": "gin_trgm_ops"},
        ),
        Index("idx_members_congress", "congress_number"),
    )
