from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid
from .enums import BillStatus

if TYPE_CHECKING:
    from .bill import Bill


class BillStatusHistory(Base):
    __tablename__ = "bill_status_history"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    status: Mapped[BillStatus] = mapped_column(nullable=False)
    changed_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="status_history")

    __table_args__ = (
        Index("idx_status_history_bill_date", "bill_id", changed_at.desc()),
    )
