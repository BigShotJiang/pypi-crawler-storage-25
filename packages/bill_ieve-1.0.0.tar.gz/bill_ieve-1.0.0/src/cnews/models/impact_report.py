from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from sqlalchemy import DateTime, ForeignKey, Index, JSON, SmallInteger, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill import Bill


class ImpactReport(Base):
    __tablename__ = "impact_reports"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), unique=True, nullable=False)
    financial_impact: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    social_impact: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    impact_score: Mapped[Optional[int]] = mapped_column(SmallInteger, nullable=True)
    affected_industries: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    analyzed_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
    model_version: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="impact_report")

    __table_args__ = (
        Index("idx_impact_reports_bill_id", "bill_id"),
    )
