from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from sqlalchemy import DateTime, Index, Integer, JSON, SmallInteger, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill_minute import BillMinute
    from .speech import Speech


class Minute(Base):
    __tablename__ = "minutes"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    minute_id: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    meeting_type: Mapped[str] = mapped_column(String(30), nullable=False)
    committee_id: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    committee_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    meeting_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    congress_number: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    title: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    agenda_items: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    speaker_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    full_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    detail_link: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    pdf_link_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    vod_link_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    conf_link_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sub_name: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    speeches: Mapped[list["Speech"]] = relationship(
        back_populates="minute", cascade="all, delete-orphan"
    )
    bills: Mapped[list["BillMinute"]] = relationship(
        back_populates="minute", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("idx_minutes_meeting_date", meeting_date.desc()),
    )
