from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from sqlalchemy import ForeignKey, Index, SmallInteger, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill import Bill
    from .member import Member


class BillSponsor(Base):
    __tablename__ = "bill_sponsors"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id", ondelete="CASCADE"), nullable=False)
    sponsor_type: Mapped[str] = mapped_column(String(20), nullable=False)
    sponsor_order: Mapped[Optional[int]] = mapped_column(SmallInteger, nullable=True)

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="sponsors")
    member: Mapped["Member"] = relationship(back_populates="sponsors")

    __table_args__ = (
        UniqueConstraint("bill_id", "member_id", name="uq_bill_sponsors_bill_member"),
        Index("idx_bill_sponsors_member", "member_id"),
    )
