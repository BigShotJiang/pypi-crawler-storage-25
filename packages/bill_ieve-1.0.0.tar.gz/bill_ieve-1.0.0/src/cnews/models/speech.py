from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .minute import Minute


class Speech(Base):
    __tablename__ = "speeches"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    minute_id: Mapped[str] = mapped_column(ForeignKey("minutes.id", ondelete="CASCADE"), nullable=False)
    speaker_name: Mapped[str] = mapped_column(String(50), nullable=False)
    speaker_role: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    agenda_id: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    speech_order: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    minute: Mapped["Minute"] = relationship(back_populates="speeches")

    __table_args__ = (
        Index("idx_speeches_minute", "minute_id"),
        Index("idx_speeches_speaker", "speaker_name"),
    )
