import enum


class BillStatus(str, enum.Enum):
    PROPOSED = "PROPOSED"
    COMMITTEE = "COMMITTEE"
    PLENARY = "PLENARY"
    PASSED = "PASSED"
    REJECTED = "REJECTED"
    WITHDRAWN = "WITHDRAWN"
    EXPIRED = "EXPIRED"


class VoteResult(str, enum.Enum):
    YES = "YES"
    NO = "NO"
    ABSTAIN = "ABSTAIN"
    ABSENT = "ABSENT"


class AlertChannel(str, enum.Enum):
    EMAIL = "EMAIL"
    WEBHOOK = "WEBHOOK"
    TELEGRAM = "TELEGRAM"


class ApiTier(str, enum.Enum):
    FREE = "FREE"
    PAID = "PAID"
