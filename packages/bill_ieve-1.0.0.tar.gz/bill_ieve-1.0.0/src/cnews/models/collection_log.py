from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Index, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, generate_cuid


class CollectionLog(Base):
    __tablename__ = "collection_logs"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    collected_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
    bills_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    new_bills_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    updated_bills_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    __table_args__ = (
        Index("idx_collection_logs_collected_at", collected_at.desc()),
    )
