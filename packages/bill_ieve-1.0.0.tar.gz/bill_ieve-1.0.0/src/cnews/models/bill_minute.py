from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import DateTime, ForeignKey, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill import Bill
    from .minute import Minute


class BillMinute(Base):
    __tablename__ = "bill_minutes"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    minute_id: Mapped[str] = mapped_column(ForeignKey("minutes.id", ondelete="CASCADE"), nullable=False)
    agenda_title: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="minutes")
    minute: Mapped["Minute"] = relationship(back_populates="bills")

    __table_args__ = (
        UniqueConstraint("bill_id", "minute_id", name="uq_bill_minutes_bill_minute"),
    )
