from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import DateTime, ForeignKey, Index, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, generate_cuid

if TYPE_CHECKING:
    from .bill import Bill
    from .tag import Tag


class BillTag(Base):
    __tablename__ = "bill_tags"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), nullable=False)
    tag_id: Mapped[str] = mapped_column(ForeignKey("tags.id", ondelete="CASCADE"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    # Relationships
    bill: Mapped["Bill"] = relationship(back_populates="bill_tags")
    tag: Mapped["Tag"] = relationship(back_populates="bill_tags")

    __table_args__ = (
        UniqueConstraint("bill_id", "tag_id", name="uq_bill_tags_bill_tag"),
        Index("idx_bill_tags_tag", "tag_id"),
    )
