"""Petition model — citizen petition data (국민동의청원).

Data source: National Assembly Open API — PTTRCP endpoint.
  https://open.assembly.go.kr/portal/openapi/PTTRCP

Designed for easy removal: delete this file + remove from __init__.py +
drop alembic migration + remove API endpoint + remove UI section.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base, TimestampMixin, generate_cuid


class Petition(TimestampMixin, Base):
    __tablename__ = "petitions"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)

    # API source identifier (PTT_ID from PTTRCP endpoint) — used for upsert dedup
    source_id: Mapped[Optional[str]] = mapped_column(
        String(100), unique=True, nullable=True, index=True
    )

    # Core fields
    title: Mapped[str] = mapped_column(Text, nullable=False)
    agree_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    target_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(
        String(50), default="ACTIVE", nullable=False
    )  # ACTIVE, EXPIRED, REFERRED, CLOSED

    # Metadata
    petition_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    source_url: Mapped[str] = mapped_column(Text, nullable=False)
    committee_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    petitioner: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    petition_no: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    petition_kind: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    introducer: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    # Timestamps
    collected_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
