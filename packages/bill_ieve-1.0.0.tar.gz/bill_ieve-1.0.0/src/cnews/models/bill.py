from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import (
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, TimestampMixin, generate_cuid
from .enums import BillStatus

if TYPE_CHECKING:
    from .alert_log import AlertLog
    from .bill_industry import BillIndustry
    from .bill_minute import BillMinute
    from .bill_sponsor import BillSponsor
    from .bill_status_history import BillStatusHistory
    from .bill_tag import BillTag
    from .category import Category
    from .impact_report import ImpactReport
    from .vote import Vote


class Bill(TimestampMixin, Base):
    __tablename__ = "bills"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=generate_cuid)

    # Category FK
    category_id: Mapped[Optional[str]] = mapped_column(
        ForeignKey("categories.id", ondelete="SET NULL"), nullable=True
    )

    # Country identifier (KR, US, EU)
    country: Mapped[str] = mapped_column(
        String(2), default="KR", server_default="KR", nullable=False, index=True
    )

    # Source data (from parliament API)
    source_id: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    title_original: Mapped[str] = mapped_column(Text, nullable=False)
    summary_original: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    proposer: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    proposed_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    status: Mapped[BillStatus] = mapped_column(
        default=BillStatus.PROPOSED, nullable=False
    )
    committee_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    committee_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # External link
    source_url: Mapped[str] = mapped_column(Text, nullable=False)

    # AI-generated content (Phase 2)
    summary_ai: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    summary_ai_long: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    summarized_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    importance_score: Mapped[Optional[int]] = mapped_column(
        Integer, default=0, nullable=True
    )
    importance_scored_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )

    # AI-generated headlines & bullet summary
    headline_ai: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    bullet_summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # View count (incremented on detail page visit)
    view_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0", nullable=False)

    # Metadata
    collected_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    category: Mapped[Optional["Category"]] = relationship(
        back_populates="bills"
    )
    status_history: Mapped[list["BillStatusHistory"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    bill_tags: Mapped[list["BillTag"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    alert_logs: Mapped[list["AlertLog"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    minutes: Mapped[list["BillMinute"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    sponsors: Mapped[list["BillSponsor"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    votes: Mapped[list["Vote"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    industries: Mapped[list["BillIndustry"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )
    impact_report: Mapped[Optional["ImpactReport"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan", uselist=False
    )

    __table_args__ = (
        Index("idx_bills_proposed_date", proposed_date.desc()),
        Index("idx_bills_category", "category_id"),
        Index("idx_bills_status", "status"),
        Index(
            "idx_bills_title_trgm",
            "title_original",
            postgresql_using="gin",
            postgresql_ops={"title_original": "gin_trgm_ops"},
        ),
    )
