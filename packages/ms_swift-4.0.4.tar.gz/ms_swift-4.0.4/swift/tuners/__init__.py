# Copyright (c) ModelScope Contributors. All rights reserved.
from typing import TYPE_CHECKING

from swift.utils.import_utils import _LazyModule

if TYPE_CHECKING:
    from .adapter import Adapter, AdapterConfig, AdapterModule
    from .base import Swift, SwiftModel
    from .llamapro import LLaMAPro, LLaMAProConfig
    from .longlora.longlora import LongLoRA, LongLoRAConfig, LongLoRAModelType
    from .lora import LoRA, LoRAConfig
    from .mapping import SWIFT_MAPPING, SwiftTuners
    from .neftune import NEFTune, NEFTuneConfig
    from .peft import (AdaLoraConfig, BOFTConfig, LoftQConfig, LoHaConfig, LoKrConfig, LoraConfig, OFTConfig,
                       PeftConfig, PeftModel, PeftModelForCausalLM, PeftModelForSeq2SeqLM,
                       PeftModelForSequenceClassification, PeftModelForTokenClassification, PrefixTuningConfig,
                       PromptEncoderConfig, PromptLearningConfig, PromptTuningConfig, VeraConfig, get_peft_config,
                       get_peft_model, get_peft_model_state_dict)
    from .prompt import Prompt, PromptConfig, PromptModule
    from .reft import Reft, ReftConfig
    from .restuning import ResTuning, ResTuningBypassModule, ResTuningConfig
    from .scetuning.scetuning import SCETuning, SCETuningConfig
    from .side import Side, SideConfig, SideModule
    from .utils import SwiftConfig, SwiftOutput, swift_to_peft_format
else:
    _import_structure = {
        'adapter': ['Adapter', 'AdapterConfig', 'AdapterModule'],
        'base': ['SwiftModel', 'Swift'],
        'lora': ['LoRA', 'LoRAConfig'],
        'longlora.longlora': ['LongLoRAModelType', 'LongLoRAConfig', 'LongLoRA'],
        'mapping': ['SWIFT_MAPPING', 'SwiftTuners'],
        'side': ['Side', 'SideConfig', 'SideModule'],
        'reft': ['Reft', 'ReftConfig'],
        'llamapro': ['LLaMAPro', 'LLaMAProConfig'],
        'neftune': ['NEFTune', 'NEFTuneConfig'],
        'restuning': ['ResTuning', 'ResTuningConfig', 'ResTuningBypassModule'],
        'peft': [
            'AdaLoraConfig', 'LoftQConfig', 'LoHaConfig', 'LoKrConfig', 'LoraConfig', 'VeraConfig', 'BOFTConfig',
            'OFTConfig', 'PeftConfig', 'PeftModel', 'PeftModelForCausalLM', 'PeftModelForSeq2SeqLM',
            'PeftModelForSequenceClassification', 'PeftModelForTokenClassification', 'PrefixTuningConfig',
            'PromptEncoderConfig', 'PromptLearningConfig', 'PromptTuningConfig', 'get_peft_config', 'get_peft_model',
            'get_peft_model_state_dict'
        ],
        'prompt': ['Prompt', 'PromptConfig', 'PromptModule'],
        'scetuning': ['SCETuning', 'SCETuningConfig'],
        'utils': ['SwiftConfig', 'SwiftOutput', 'swift_to_peft_format'],
    }

    import sys

    sys.modules[__name__] = _LazyModule(
        __name__,
        globals()['__file__'],
        _import_structure,
        module_spec=__spec__,
        extra_objects={},
    )
