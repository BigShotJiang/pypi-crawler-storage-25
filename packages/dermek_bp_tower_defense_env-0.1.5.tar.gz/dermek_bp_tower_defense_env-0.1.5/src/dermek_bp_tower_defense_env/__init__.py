from gymnasium.envs.registration import register, registry

from .environment import TowerDefenseEnv

ENV_ID = "DermekBPTowerDefense-v0"

if ENV_ID not in registry:
    register(
        id=ENV_ID,
        entry_point="dermek_bp_tower_defense_env.environment:TowerDefenseEnv"
    )

__all__ = ["TowerDefenseEnv"]
