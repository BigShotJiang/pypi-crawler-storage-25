# anumiti-netra

Official Python SDK for **Anumiti NETRA** — India's AI document intelligence API.

Extract structured data from GST invoices, contracts, identity documents, court orders, employment records, and MCA filings with a single function call.

## Installation

```bash
pip install anumiti-netra
# or with uv
uv add anumiti-netra
# or with poetry
poetry add anumiti-netra
```

## Quick Start

```python
from anumiti_netra import NeTraClient

client = NeTraClient(api_key="anm_ntr_live_...")

# Extract a GST invoice
with open("invoice.pdf", "rb") as f:
    result = client.extract_gst_invoice(f, "invoice.pdf")

print(f"Trust Score: {result.trust_score}")
print(f"Seller GSTIN: {result.seller.gstin} (verified: {result.seller.gstin_verified})")
print(f"Grand Total: ₹{result.totals.grand_total:,.2f}")
print(f"ITC Eligible: {result.compliance_flags.itc_eligible}")
```

## Async Usage

```python
import asyncio
from anumiti_netra import AsyncNeTraClient

async def main():
    async with AsyncNeTraClient(api_key="anm_ntr_live_...") as client:
        with open("invoice.pdf", "rb") as f:
            result = await client.extract_gst_invoice(f, "invoice.pdf")
            print(f"Trust score: {result.trust_score}")

asyncio.run(main())
```

## Supported Document Types

| Method | Document Type | Indian Law Coverage |
|--------|--------------|---------------------|
| `extract_gst_invoice()` | GST Tax Invoice | CGST/SGST/IGST Act, Section 17(5), HSN validation |
| `extract_gst_credit_note()` | GST Credit Note | Rule 53, CDN reconciliation |
| `extract_gst_eway_bill()` | GST E-Way Bill | Rule 138, expiry detection |
| `extract_contract()` | Legal Contract | Indian Contract Act 1872, Stamp Act |
| `extract_identity()` | Aadhaar/PAN/Passport/DL/VoterID | DPDP Act 2023 (masked output) |
| `extract_employment()` | Salary Slip/Offer Letter/Form 16 | Labour Codes, PF Act, ESI Act |
| `extract_court_order()` | Court Orders (HC/SC/District) | CPC, CrPC, civil/criminal orders |
| `extract_company_filing()` | MCA ROC Filings | Companies Act 2013 |
| `verify_gstin()` | Standalone GSTIN check | GSTN registry via Sandbox.co.in |
| `verify_pan()` | Standalone PAN check | Income Tax registry |

## All Methods

```python
# GST Documents
invoice = client.extract_gst_invoice(file, "invoice.pdf")
credit_note = client.extract_gst_credit_note(file, "credit-note.pdf")
eway_bill = client.extract_gst_eway_bill(file, "eway-bill.pdf")

# Legal
contract = client.extract_contract(file, "agreement.pdf")
court_order = client.extract_court_order(file, "order.pdf")

# Identity (DPDP-compliant — Aadhaar last 4 only, PAN masked)
identity = client.extract_identity(file, "aadhaar.jpg")
print(identity.id_number_masked)  # XXXX XXXX 1234
print(identity.dpdp_redacted)     # True

# Employment
employment = client.extract_employment(file, "salary-slip.pdf")
print(employment.minimum_wage_compliant)

# Corporate
filing = client.extract_company_filing(file, "mgt7.pdf")

# Verification (no file needed)
gstin_result = client.verify_gstin("27AAACR5055K1Z5")
pan_result = client.verify_pan("ABCDE1234F")
```

## Async Processing (Large Documents)

```python
# Submit and return immediately
job = client.submit_document(file, "large.pdf", document_type="contract")
print(f"Job ID: {job.id}")

# Poll status
status = client.get_document_status(job.id)
print(f"Status: {status.status}")

# Or block until complete
completed = client.wait_for_document(job.id, poll_interval=2.0, max_wait=300.0)
if completed.status == "completed":
    result = client.get_document_result(job.id)
```

## Error Handling

```python
from anumiti_netra import (
    NeTraClient,
    AuthenticationError,
    RateLimitError,
    DocumentTooLargeError,
    OCRFailedError,
    PollingTimeoutError,
)

try:
    result = client.extract_gst_invoice(file, "invoice.pdf")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after: {e.retry_after_ms}ms")
except DocumentTooLargeError:
    print("File too large (max 50MB)")
except OCRFailedError:
    print("OCR failed — try a higher resolution scan")
except PollingTimeoutError as e:
    print(f"Timed out waiting for document {e.document_id}")
```

## Configuration

```python
client = NeTraClient(
    api_key="anm_ntr_live_...",
    base_url="https://netra.anumiti.in",  # default
    timeout=60.0,                          # 60s default
    max_retries=3,                         # default
    retry_delay=1.0,                       # 1s base, exponential backoff
)
```

## Context Manager

```python
# Sync
with NeTraClient(api_key="anm_ntr_live_...") as client:
    result = client.extract_gst_invoice(file, "invoice.pdf")

# Async
async with AsyncNeTraClient(api_key="anm_ntr_live_...") as client:
    result = await client.extract_gst_invoice(file, "invoice.pdf")
```

## Type Safety

All responses are Pydantic v2 models — full IDE autocompletion:

```python
from anumiti_netra.models import GSTInvoiceResult, ContractResult

def process_invoice(result: GSTInvoiceResult) -> float:
    if result.compliance_flags.itc_eligible:
        return result.totals.total_igst or 0.0
    return 0.0
```

## Requirements

- Python 3.9+
- httpx >= 0.27.0
- pydantic >= 2.5.0

## License

MIT — © Anumiti Technologies Pvt Ltd
