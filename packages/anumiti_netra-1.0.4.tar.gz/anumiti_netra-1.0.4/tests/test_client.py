"""
anumiti-netra — Test Suite
Uses pytest-httpx to mock HTTP responses without hitting the real API.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest
from pytest_httpx import HTTPXMock

from anumiti_netra import (
    AuthenticationError,
    DocumentTooLargeError,
    GSTInvoiceResult,
    NeTraClient,
    RateLimitError,
)
from anumiti_netra.exceptions import NetworkError


FAKE_API_KEY = "anm_ntr_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
FAKE_GST_INVOICE_RESPONSE = {
    "success": True,
    "request_id": "req_test_001",
    "data": {
        "document_type": "gst_invoice",
        "extraction_confidence": 0.97,
        "invoice_number": "INV-2024-001",
        "invoice_date": "2024-03-15",
        "invoice_type": "B2B",
        "seller": {
            "gstin": "27AAACR5055K1Z5",
            "gstin_verified": True,
            "legal_name": "Test Seller Pvt Ltd",
            "trade_name": "Test Seller",
            "pan": "AAACR5055K",
            "address": "Mumbai, Maharashtra",
        },
        "buyer": {
            "gstin": "29AABCT1332L1ZA",
            "gstin_verified": True,
            "legal_name": "Test Buyer Pvt Ltd",
            "trade_name": None,
            "pan": "AABCT1332L",
            "address": "Bengaluru, Karnataka",
        },
        "irn": None,
        "ack_number": None,
        "ack_date": None,
        "line_items": [
            {
                "sl_no": 1,
                "description": "Software Services",
                "hsn_code": "998314",
                "hsn_valid": True,
                "quantity": 1.0,
                "unit": "Unit",
                "unit_price": 100000.0,
                "discount": None,
                "taxable_value": 100000.0,
                "igst_rate": 18.0,
                "igst_amount": 18000.0,
                "total": 118000.0,
            }
        ],
        "totals": {
            "taxable_value": 100000.0,
            "total_cgst": None,
            "total_sgst": None,
            "total_igst": 18000.0,
            "total_cess": None,
            "total_tax": 18000.0,
            "round_off": 0.0,
            "grand_total": 118000.0,
            "total_in_words": "One Lakh Eighteen Thousand Rupees Only",
            "computation_verified": True,
            "computation_discrepancy": None,
        },
        "bank_details": {},
        "compliance_flags": {
            "mandatory_fields_present": True,
            "e_invoicing_applicable": True,
            "irn_present": False,
            "irn_valid": None,
            "reverse_charge": False,
            "place_of_supply_valid": True,
            "hsn_rates_valid": True,
            "section_17_5_blocked_items": [],
            "itc_eligible": True,
        },
        "trust_score": 0.93,
        "trust_components": {
            "ocr_confidence": 0.97,
            "verification_score": 0.95,
            "compliance_score": 0.92,
            "consistency_score": 0.88,
        },
    },
}


@pytest.fixture
def client() -> NeTraClient:
    return NeTraClient(api_key=FAKE_API_KEY)


def test_client_rejects_empty_api_key() -> None:
    with pytest.raises(ValueError, match="API key is required"):
        NeTraClient(api_key="")


def test_extract_gst_invoice_success(httpx_mock: HTTPXMock, client: NeTraClient) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.anumiti.com/api/v1/extract/gst-invoice",
        json=FAKE_GST_INVOICE_RESPONSE,
        status_code=200,
    )
    result = client.extract_gst_invoice(b"%PDF-1.4 fake content", "invoice.pdf")
    assert isinstance(result, GSTInvoiceResult)
    assert result.trust_score == 0.93
    assert result.seller.gstin == "27AAACR5055K1Z5"
    assert result.seller.gstin_verified is True
    assert result.totals.grand_total == 118000.0
    assert result.compliance_flags.itc_eligible is True


def test_authentication_error(httpx_mock: HTTPXMock, client: NeTraClient) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.anumiti.com/api/v1/extract/gst-invoice",
        json={
            "success": False,
            "request_id": "req_001",
            "error": {"code": "COMMON_UNAUTHORIZED", "message": "Invalid API key"},
        },
        status_code=401,
    )
    with pytest.raises(AuthenticationError):
        client.extract_gst_invoice(b"fake", "invoice.pdf")


def test_rate_limit_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.anumiti.com/api/v1/extract/gst-invoice",
        json={
            "success": False,
            "request_id": "req_002",
            "error": {"code": "COMMON_RATE_LIMITED", "message": "Rate limit exceeded"},
        },
        status_code=429,
    )
    fast_client = NeTraClient(api_key=FAKE_API_KEY, max_retries=0)
    with pytest.raises(RateLimitError):
        fast_client.extract_gst_invoice(b"fake", "invoice.pdf")


def test_document_too_large(client: NeTraClient) -> None:
    oversized = b"x" * (51 * 1024 * 1024)  # 51MB
    with pytest.raises(DocumentTooLargeError):
        client.extract_gst_invoice(oversized, "huge.pdf")


def test_verify_gstin(httpx_mock: HTTPXMock, client: NeTraClient) -> None:
    httpx_mock.add_response(
        method="POST",
        url="https://api.anumiti.com/api/v1/verify/gstin",
        json={
            "success": True,
            "request_id": "req_003",
            "data": {
                "gstin": "27AAACR5055K1Z5",
                "valid": True,
                "legal_name": "Test Company Pvt Ltd",
                "trade_name": None,
                "status": "Active",
                "registration_type": "Regular",
                "state_code": "27",
                "pan_derived": "AAACR5055K",
                "address": None,
                "verified_at": "2024-03-15T10:30:00Z",
            },
        },
        status_code=200,
    )
    result = client.verify_gstin("27AAACR5055K1Z5")
    assert result.valid is True
    assert result.state_code == "27"
    assert result.status == "Active"
