"""
anumiti-netra — Official Python SDK for Anumiti NETRA
India's AI document intelligence API.

Quick start::

    from anumiti_netra import NeTraClient

    client = NeTraClient(api_key="anm_ntr_live_...")

    with open("invoice.pdf", "rb") as f:
        result = client.extract_gst_invoice(f, "invoice.pdf")
        print(f"Trust score: {result.trust_score}")
        print(f"GSTIN verified: {result.seller.gstin_verified}")
        print(f"Grand total: ₹{result.totals.grand_total:,.2f}")

For async usage::

    from anumiti_netra import AsyncNeTraClient
    import asyncio

    async def main():
        async with AsyncNeTraClient(api_key="anm_ntr_live_...") as client:
            with open("invoice.pdf", "rb") as f:
                result = await client.extract_gst_invoice(f, "invoice.pdf")

    asyncio.run(main())
"""

from .client import AsyncNeTraClient, NeTraClient
from .webhooks import WebhookEvent, verify_webhook
from .exceptions import (
    AuthenticationError,
    DocumentTooLargeError,
    NetworkError,
    NeTraError,
    NotFoundError,
    OCRFailedError,
    PermissionError,
    PollingTimeoutError,
    ProcessingError,
    ProcessingTimeoutError,
    RateLimitError,
    ServerError,
    UnsupportedFormatError,
    ValidationError,
)
from .models import (
    BankVerificationResult,
    BatchCreateResult,
    BatchResultItem,
    BatchResults,
    BatchStatusResult,
    BatchUploadResult,
    CINVerificationResult,
    CompanyFilingResult,
    ContractClause,
    ContractParty,
    ContractResult,
    CourtOrderResult,
    DINCompany,
    DINVerificationResult,
    DocumentStatusResult,
    EInvoiceIRNResult,
    EmploymentResult,
    EWayBillVerificationResult,
    GSTCreditNoteResult,
    GSTEWayBillResult,
    GSTINVerificationResult,
    GSTInvoiceResult,
    GSTLineItem,
    GSTParty,
    GSTTotals,
    IdentityResult,
    PANVerificationResult,
    SubmitDocumentResult,
)

__version__ = "1.0.0"
__all__ = [
    # Clients
    "NeTraClient",
    "AsyncNeTraClient",
    # Exceptions
    "NeTraError",
    "AuthenticationError",
    "PermissionError",
    "RateLimitError",
    "DocumentTooLargeError",
    "UnsupportedFormatError",
    "OCRFailedError",
    "ProcessingTimeoutError",
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "NetworkError",
    "PollingTimeoutError",
    "ProcessingError",
    # Models
    "SubmitDocumentResult",
    "DocumentStatusResult",
    "GSTLineItem",
    "GSTParty",
    "GSTTotals",
    "GSTInvoiceResult",
    "GSTCreditNoteResult",
    "GSTEWayBillResult",
    "ContractParty",
    "ContractClause",
    "ContractResult",
    "IdentityResult",
    "EmploymentResult",
    "CourtOrderResult",
    "CompanyFilingResult",
    "GSTINVerificationResult",
    "PANVerificationResult",
    # Batch models
    "BatchCreateResult",
    "BatchUploadResult",
    "BatchStatusResult",
    "BatchResultItem",
    "BatchResults",
    # Additional verification models
    "CINVerificationResult",
    "DINCompany",
    "DINVerificationResult",
    "BankVerificationResult",
    "EInvoiceIRNResult",
    "EWayBillVerificationResult",
    # Webhooks
    "verify_webhook",
    "WebhookEvent",
]
