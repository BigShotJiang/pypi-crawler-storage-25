"""
anumiti-netra — NeTraClient
Sync and async HTTP client for the NETRA document intelligence API.
"""

from __future__ import annotations

import asyncio
import mimetypes
import random
import re
import time
import uuid
from pathlib import Path
from collections.abc import Callable
from typing import Any, BinaryIO

import httpx

from .exceptions import (
    AuthenticationError,
    NetworkError,
    NeTraError,
    PollingTimeoutError,
    ProcessingError,
    RateLimitError,
    ValidationError,
    create_error,
)
from .models import (
    BankVerificationResult,
    BatchCreateResult,
    BatchResults,
    BatchStatusResult,
    BatchUploadResult,
    CINVerificationResult,
    CompanyFilingResult,
    ContractResult,
    CourtOrderResult,
    DINVerificationResult,
    DocumentStatusResult,
    EmploymentResult,
    GSTCreditNoteResult,
    GSTEWayBillResult,
    GSTINVerificationResult,
    GSTInvoiceResult,
    IdentityResult,
    PANVerificationResult,
    SubmitDocumentResult,
)

DEFAULT_BASE_URL = "https://api.anumiti.com"
DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0
SDK_VERSION = "1.0.0"

SUPPORTED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".tif", ".webp"}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB


def _guess_mime(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    mime_map = {
        ".pdf": "application/pdf",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".tiff": "image/tiff",
        ".tif": "image/tiff",
        ".webp": "image/webp",
    }
    return mime_map.get(ext, "application/octet-stream")


def _build_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": f"anumiti-netra/{SDK_VERSION} python-httpx",
        "Accept": "application/json",
        "X-Request-ID": str(uuid.uuid4()),
    }


def _handle_response(response: httpx.Response) -> Any:
    """Parse response JSON and raise typed errors for non-success."""
    try:
        data = response.json()
    except Exception:
        raise create_error(
            "COMMON_INTERNAL_ERROR",
            f"Unexpected non-JSON response (status {response.status_code})",
            response.status_code,
        )

    if not data.get("success"):
        error = data.get("error", {})
        raise create_error(
            code=error.get("code", "COMMON_INTERNAL_ERROR"),
            message=error.get("message", "Unknown error"),
            status_code=response.status_code,
            request_id=data.get("request_id"),
            details=error.get("details"),
        )

    return data.get("data")


# ─────────────────────────────────────────────────────────────────────────────
# Synchronous Client
# ─────────────────────────────────────────────────────────────────────────────

class NeTraClient:
    """
    Synchronous NETRA client.

    Usage::

        from anumiti_netra import NeTraClient

        client = NeTraClient(api_key="anm_ntr_live_...")

        with open("invoice.pdf", "rb") as f:
            result = client.extract_gst_invoice(f, "invoice.pdf")
            print(result.trust_score)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        if not api_key:
            raise ValueError(
                "NETRA API key is required. "
                "Get your key at https://app.anumiti.com/keys"
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._http = httpx.Client(
            base_url=self._base_url,
            headers=_build_headers(api_key),
            timeout=httpx.Timeout(timeout),
        )

    def __enter__(self) -> NeTraClient:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        idempotency_key: str | None = None
        if method == "POST":
            idempotency_key = str(uuid.uuid4())
        for attempt in range(self._max_retries + 1):
            try:
                extra_headers: dict[str, str] = {"X-Request-ID": str(uuid.uuid4())}
                if idempotency_key is not None:
                    extra_headers["X-Idempotency-Key"] = idempotency_key
                response = self._http.request(method, path, headers=extra_headers, **kwargs)
            except httpx.RequestError as exc:
                raise NetworkError(f"Network error: {exc}", exc) from exc

            if response.status_code == 429 or response.status_code >= 500:
                if attempt < self._max_retries:
                    retry_after = response.headers.get("Retry-After")
                    base_delay = (
                        float(retry_after)
                        if retry_after
                        else self._retry_delay * (2 ** attempt)
                    )
                    delay = base_delay * (0.5 + random.random())
                    time.sleep(delay)
                    continue

            return _handle_response(response)

        raise NetworkError("Max retries exceeded")

    # ─── Document lifecycle ────────────────────────────────────────────────────

    def submit_document(
        self,
        file: BinaryIO | bytes,
        file_name: str,
        *,
        document_type: str = "auto_detect",
        language_hint: str | None = None,
        verify_entities: bool = True,
        webhook_url: str | None = None,
        external_id: str | None = None,
    ) -> SubmitDocumentResult:
        """Submit a document for async processing. Returns document ID."""
        content = file if isinstance(file, bytes) else file.read()
        if len(content) > MAX_FILE_SIZE:
            from .exceptions import DocumentTooLargeError
            raise DocumentTooLargeError()

        metadata: dict[str, Any] = {
            "document_type": document_type,
            "options": {"verify_entities": verify_entities},
        }
        if language_hint:
            metadata["language_hint"] = language_hint
        if webhook_url:
            metadata["webhook_url"] = webhook_url
        if external_id:
            metadata["external_id"] = external_id

        files = {"file": (file_name, content, _guess_mime(file_name))}
        data = {"metadata": __import__("json").dumps(metadata)}

        result = self._request("POST", "/api/v1/documents/process-sync", files=files, data=data)
        return SubmitDocumentResult.model_validate(result)

    def get_document_status(self, document_id: str) -> DocumentStatusResult:
        """Poll document status by ID."""
        result = self._request("GET", f"/api/v1/documents/{document_id}/status")
        return DocumentStatusResult.model_validate(result)

    def get_document_result(self, document_id: str) -> dict[str, Any]:
        """Fetch full extraction result for a completed document."""
        return self._request("GET", f"/api/v1/documents/{document_id}/result")  # type: ignore[return-value]

    def wait_for_document(
        self,
        document_id: str,
        *,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> DocumentStatusResult:
        """Block until document processing is complete or fails."""
        start = time.monotonic()
        while True:
            status = self.get_document_status(document_id)
            if status.status in ("completed", "failed"):
                return status
            elapsed = time.monotonic() - start
            if elapsed + poll_interval > max_wait:
                raise PollingTimeoutError(document_id, elapsed)
            time.sleep(poll_interval)

    # ─── Synchronous Extractors ──────────────────────────────────────────────

    def _extract(self, endpoint: str, file: BinaryIO | bytes, file_name: str) -> Any:
        content = file if isinstance(file, bytes) else file.read()
        if len(content) > MAX_FILE_SIZE:
            from .exceptions import DocumentTooLargeError
            raise DocumentTooLargeError()
        files = {"file": (file_name, content, _guess_mime(file_name))}
        return self._request("POST", endpoint, files=files)

    def extract_gst_invoice(self, file: BinaryIO | bytes, file_name: str) -> GSTInvoiceResult:
        """Extract structured data from a GST Tax Invoice (CGST/SGST/IGST)."""
        result = self._extract("/api/v1/extract/gst-invoice", file, file_name)
        return GSTInvoiceResult.model_validate(result)

    def extract_gst_credit_note(self, file: BinaryIO | bytes, file_name: str) -> GSTCreditNoteResult:
        """Extract structured data from a GST Credit Note."""
        result = self._extract("/api/v1/extract/gst-credit-note", file, file_name)
        return GSTCreditNoteResult.model_validate(result)

    def extract_gst_eway_bill(self, file: BinaryIO | bytes, file_name: str) -> GSTEWayBillResult:
        """Extract structured data from a GST E-Way Bill. Includes expiry check."""
        result = self._extract("/api/v1/extract/gst-eway-bill", file, file_name)
        return GSTEWayBillResult.model_validate(result)

    def extract_contract(self, file: BinaryIO | bytes, file_name: str) -> ContractResult:
        """Extract and risk-score a legal contract under Indian Contract Act, 1872."""
        result = self._extract("/api/v1/extract/contract", file, file_name)
        return ContractResult.model_validate(result)

    def extract_identity(self, file: BinaryIO | bytes, file_name: str) -> IdentityResult:
        """
        Extract identity document data with DPDP-compliant masking.
        Aadhaar → last 4 digits only. PAN → masked (ABCDE****F).
        """
        result = self._extract("/api/v1/extract/identity", file, file_name)
        return IdentityResult.model_validate(result)

    def extract_employment(self, file: BinaryIO | bytes, file_name: str) -> EmploymentResult:
        """Extract employment doc data. Validates PF/ESI rates, minimum wage by state."""
        result = self._extract("/api/v1/extract/employment", file, file_name)
        return EmploymentResult.model_validate(result)

    def extract_court_order(self, file: BinaryIO | bytes, file_name: str) -> CourtOrderResult:
        """Extract structured data from Indian court orders (HC/SC/District)."""
        result = self._extract("/api/v1/extract/court-order", file, file_name)
        return CourtOrderResult.model_validate(result)

    def extract_company_filing(self, file: BinaryIO | bytes, file_name: str) -> CompanyFilingResult:
        """Extract company/director data from MCA ROC filings."""
        result = self._extract("/api/v1/extract/company-filing", file, file_name)
        return CompanyFilingResult.model_validate(result)

    # ─── Verification ─────────────────────────────────────────────────────────

    def verify_gstin(self, gstin: str) -> GSTINVerificationResult:
        """Verify a GSTIN number against GSTN registry via Sandbox.co.in."""
        if not gstin or not isinstance(gstin, str):
            raise ValidationError("GSTIN is required")
        gstin = gstin.strip().upper()
        if not re.match(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9]$', gstin):
            raise ValidationError("Invalid GSTIN format. Expected: 15-char (e.g. 27AAACR5055K1Z5)")
        result = self._request("POST", "/api/v1/verify/gstin", json={"gstin": gstin})
        return GSTINVerificationResult.model_validate(result)

    def verify_pan(
        self,
        pan: str,
        *,
        name: str | None = None,
        date_of_birth: str | None = None,
    ) -> PANVerificationResult:
        """Verify a PAN number against income tax registry via Sandbox.co.in."""
        if not pan or not isinstance(pan, str):
            raise ValidationError("PAN is required")
        pan = pan.strip().upper()
        if not re.match(r'^[A-Z]{5}[0-9]{4}[A-Z]$', pan):
            raise ValidationError("Invalid PAN format. Expected: 10-char (e.g. ABCDE1234F)")
        payload: dict[str, Any] = {"pan": pan}
        if name is not None:
            payload["name"] = name
        if date_of_birth is not None:
            payload["date_of_birth"] = date_of_birth
        result = self._request("POST", "/api/v1/verify/pan", json=payload)
        return PANVerificationResult.model_validate(result)

    def verify_cin(self, cin: str) -> CINVerificationResult:
        """Verify a CIN (Corporate Identity Number) against MCA registry."""
        if not cin or not isinstance(cin, str):
            raise ValidationError("CIN is required")
        cin = cin.strip().upper()
        if not re.match(r'^[A-Z]\d{5}[A-Z]{2}\d{4}[A-Z]{3}\d{6}$', cin):
            raise ValidationError("Invalid CIN format. Expected: 21-char (e.g. U74999MH2013PTC123456)")
        result = self._request("POST", "/api/v1/verify/cin", json={"cin": cin})
        return CINVerificationResult.model_validate(result)

    def verify_din(self, din: str) -> DINVerificationResult:
        """Verify a DIN (Director Identification Number) against MCA registry."""
        if not din or not isinstance(din, str):
            raise ValidationError("DIN is required")
        din = din.strip()
        if not re.match(r'^\d{8}$', din):
            raise ValidationError("Invalid DIN format. Expected: 8-digit number (e.g. 00012345)")
        result = self._request("POST", "/api/v1/verify/din", json={"din": din})
        return DINVerificationResult.model_validate(result)

    def verify_bank_account(self, account_number: str, ifsc: str, name: str) -> BankVerificationResult:
        """Verify a bank account number and IFSC code via penny-drop verification."""
        if not account_number or not isinstance(account_number, str) or not account_number.strip():
            raise ValidationError("Bank account number is required")
        if not name or not isinstance(name, str) or not name.strip():
            raise ValidationError("Account holder name is required")
        if not ifsc or not isinstance(ifsc, str):
            raise ValidationError("IFSC code is required")
        ifsc = ifsc.strip().upper()
        if not re.match(r'^[A-Z]{4}0[A-Z0-9]{6}$', ifsc):
            raise ValidationError("Invalid IFSC format. Expected: 11-char code (e.g. SBIN0001234)")
        result = self._request(
            "POST",
            "/api/v1/verify/bank-account",
            json={"account_number": account_number.strip(), "ifsc": ifsc, "name": name.strip()},
        )
        return BankVerificationResult.model_validate(result)

    # ─── Batch Processing ─────────────────────────────────────────────────────

    def create_batch(
        self,
        *,
        name: str | None = None,
        document_type: str | None = None,
        webhook_url: str | None = None,
    ) -> BatchCreateResult:
        """Create a new batch for bulk document processing."""
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if document_type is not None:
            payload["document_type"] = document_type
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        result = self._request("POST", "/api/v1/batch", json=payload)
        return BatchCreateResult.model_validate(result)

    def upload_to_batch(
        self,
        batch_id: str,
        file: BinaryIO | bytes,
        file_name: str,
    ) -> BatchUploadResult:
        """Upload a document to an existing batch."""
        content = file if isinstance(file, bytes) else file.read()
        if len(content) > MAX_FILE_SIZE:
            from .exceptions import DocumentTooLargeError
            raise DocumentTooLargeError()
        files = {"file": (file_name, content, _guess_mime(file_name))}
        result = self._request("POST", f"/api/v1/batch/{batch_id}/upload", files=files)
        return BatchUploadResult.model_validate(result)

    def get_batch_status(self, batch_id: str) -> BatchStatusResult:
        """Get the processing status of a batch."""
        result = self._request("GET", f"/api/v1/batch/{batch_id}/status")
        return BatchStatusResult.model_validate(result)

    def get_batch_results(self, batch_id: str) -> BatchResults:
        """Fetch extraction results for all documents in a completed batch."""
        result = self._request("GET", f"/api/v1/batch/{batch_id}/results")
        return BatchResults.model_validate(result)

    def wait_for_batch(
        self,
        batch_id: str,
        *,
        poll_interval: float = 5.0,
        max_wait: float = 600.0,
    ) -> BatchStatusResult:
        """Block until batch processing is complete or fails."""
        start = time.monotonic()
        while True:
            status = self.get_batch_status(batch_id)
            if status.status in ("completed", "failed"):
                return status
            elapsed = time.monotonic() - start
            if elapsed + poll_interval > max_wait:
                raise PollingTimeoutError(batch_id, elapsed)
            time.sleep(poll_interval)

    def upload_many(
        self,
        batch_id: str,
        files: list[tuple[str, bytes]],  # [(filename, content), ...]
        concurrency: int = 5,
        on_progress: Callable[[int, int], None] | None = None,
    ) -> list[BatchUploadResult]:
        """Upload multiple files to a batch with concurrency control."""
        results: list[BatchUploadResult] = []
        total = len(files)
        for i in range(0, total, concurrency):
            chunk = files[i:i + concurrency]
            # Python sync client processes chunk sequentially
            for filename, content in chunk:
                r = self.upload_to_batch(batch_id, content, filename)
                results.append(r)
            if on_progress:
                on_progress(min(i + concurrency, total), total)
        return results


# ─────────────────────────────────────────────────────────────────────────────
# Async Client
# ─────────────────────────────────────────────────────────────────────────────

class AsyncNeTraClient:
    """
    Async NETRA client for use with asyncio.

    Usage::

        from anumiti_netra import AsyncNeTraClient

        async def main():
            async with AsyncNeTraClient(api_key="anm_ntr_live_...") as client:
                with open("invoice.pdf", "rb") as f:
                    result = await client.extract_gst_invoice(f, "invoice.pdf")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        if not api_key:
            raise ValueError(
                "NETRA API key is required. "
                "Get your key at https://app.anumiti.com/keys"
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers=_build_headers(api_key),
            timeout=httpx.Timeout(timeout),
        )

    async def __aenter__(self) -> AsyncNeTraClient:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        idempotency_key: str | None = None
        if method == "POST":
            idempotency_key = str(uuid.uuid4())
        for attempt in range(self._max_retries + 1):
            try:
                extra_headers: dict[str, str] = {"X-Request-ID": str(uuid.uuid4())}
                if idempotency_key is not None:
                    extra_headers["X-Idempotency-Key"] = idempotency_key
                response = await self._http.request(method, path, headers=extra_headers, **kwargs)
            except httpx.RequestError as exc:
                raise NetworkError(f"Network error: {exc}", exc) from exc

            if response.status_code == 429 or response.status_code >= 500:
                if attempt < self._max_retries:
                    retry_after = response.headers.get("Retry-After")
                    base_delay = (
                        float(retry_after)
                        if retry_after
                        else self._retry_delay * (2 ** attempt)
                    )
                    delay = base_delay * (0.5 + random.random())
                    await asyncio.sleep(delay)
                    continue

            return _handle_response(response)

        raise NetworkError("Max retries exceeded")

    async def _extract(self, endpoint: str, file: BinaryIO | bytes, file_name: str) -> Any:
        content = file if isinstance(file, bytes) else file.read()
        if len(content) > MAX_FILE_SIZE:
            from .exceptions import DocumentTooLargeError
            raise DocumentTooLargeError()
        files = {"file": (file_name, content, _guess_mime(file_name))}
        return await self._request("POST", endpoint, files=files)

    async def extract_gst_invoice(self, file: BinaryIO | bytes, file_name: str) -> GSTInvoiceResult:
        result = await self._extract("/api/v1/extract/gst-invoice", file, file_name)
        return GSTInvoiceResult.model_validate(result)

    async def extract_gst_credit_note(self, file: BinaryIO | bytes, file_name: str) -> GSTCreditNoteResult:
        result = await self._extract("/api/v1/extract/gst-credit-note", file, file_name)
        return GSTCreditNoteResult.model_validate(result)

    async def extract_gst_eway_bill(self, file: BinaryIO | bytes, file_name: str) -> GSTEWayBillResult:
        result = await self._extract("/api/v1/extract/gst-eway-bill", file, file_name)
        return GSTEWayBillResult.model_validate(result)

    async def extract_contract(self, file: BinaryIO | bytes, file_name: str) -> ContractResult:
        result = await self._extract("/api/v1/extract/contract", file, file_name)
        return ContractResult.model_validate(result)

    async def extract_identity(self, file: BinaryIO | bytes, file_name: str) -> IdentityResult:
        result = await self._extract("/api/v1/extract/identity", file, file_name)
        return IdentityResult.model_validate(result)

    async def extract_employment(self, file: BinaryIO | bytes, file_name: str) -> EmploymentResult:
        result = await self._extract("/api/v1/extract/employment", file, file_name)
        return EmploymentResult.model_validate(result)

    async def extract_court_order(self, file: BinaryIO | bytes, file_name: str) -> CourtOrderResult:
        result = await self._extract("/api/v1/extract/court-order", file, file_name)
        return CourtOrderResult.model_validate(result)

    async def extract_company_filing(self, file: BinaryIO | bytes, file_name: str) -> CompanyFilingResult:
        result = await self._extract("/api/v1/extract/company-filing", file, file_name)
        return CompanyFilingResult.model_validate(result)

    async def verify_gstin(self, gstin: str) -> GSTINVerificationResult:
        if not gstin or not isinstance(gstin, str):
            raise ValidationError("GSTIN is required")
        gstin = gstin.strip().upper()
        if not re.match(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9]$', gstin):
            raise ValidationError("Invalid GSTIN format. Expected: 15-char (e.g. 27AAACR5055K1Z5)")
        result = await self._request("POST", "/api/v1/verify/gstin", json={"gstin": gstin})
        return GSTINVerificationResult.model_validate(result)

    async def verify_pan(
        self,
        pan: str,
        *,
        name: str | None = None,
        date_of_birth: str | None = None,
    ) -> PANVerificationResult:
        if not pan or not isinstance(pan, str):
            raise ValidationError("PAN is required")
        pan = pan.strip().upper()
        if not re.match(r'^[A-Z]{5}[0-9]{4}[A-Z]$', pan):
            raise ValidationError("Invalid PAN format. Expected: 10-char (e.g. ABCDE1234F)")
        payload: dict[str, Any] = {"pan": pan}
        if name is not None:
            payload["name"] = name
        if date_of_birth is not None:
            payload["date_of_birth"] = date_of_birth
        result = await self._request("POST", "/api/v1/verify/pan", json=payload)
        return PANVerificationResult.model_validate(result)

    async def verify_cin(self, cin: str) -> CINVerificationResult:
        """Verify a CIN (Corporate Identity Number) against MCA registry."""
        if not cin or not isinstance(cin, str):
            raise ValidationError("CIN is required")
        cin = cin.strip().upper()
        if not re.match(r'^[A-Z]\d{5}[A-Z]{2}\d{4}[A-Z]{3}\d{6}$', cin):
            raise ValidationError("Invalid CIN format. Expected: 21-char (e.g. U74999MH2013PTC123456)")
        result = await self._request("POST", "/api/v1/verify/cin", json={"cin": cin})
        return CINVerificationResult.model_validate(result)

    async def verify_din(self, din: str) -> DINVerificationResult:
        """Verify a DIN (Director Identification Number) against MCA registry."""
        if not din or not isinstance(din, str):
            raise ValidationError("DIN is required")
        din = din.strip()
        if not re.match(r'^\d{8}$', din):
            raise ValidationError("Invalid DIN format. Expected: 8-digit number (e.g. 00012345)")
        result = await self._request("POST", "/api/v1/verify/din", json={"din": din})
        return DINVerificationResult.model_validate(result)

    async def verify_bank_account(self, account_number: str, ifsc: str, name: str) -> BankVerificationResult:
        """Verify a bank account number and IFSC code via penny-drop verification."""
        if not account_number or not isinstance(account_number, str) or not account_number.strip():
            raise ValidationError("Bank account number is required")
        if not name or not isinstance(name, str) or not name.strip():
            raise ValidationError("Account holder name is required")
        if not ifsc or not isinstance(ifsc, str):
            raise ValidationError("IFSC code is required")
        ifsc = ifsc.strip().upper()
        if not re.match(r'^[A-Z]{4}0[A-Z0-9]{6}$', ifsc):
            raise ValidationError("Invalid IFSC format. Expected: 11-char code (e.g. SBIN0001234)")
        result = await self._request(
            "POST",
            "/api/v1/verify/bank-account",
            json={"account_number": account_number.strip(), "ifsc": ifsc, "name": name.strip()},
        )
        return BankVerificationResult.model_validate(result)

    # ─── Batch Processing ─────────────────────────────────────────────────────

    async def create_batch(
        self,
        *,
        name: str | None = None,
        document_type: str | None = None,
        webhook_url: str | None = None,
    ) -> BatchCreateResult:
        """Create a new batch for bulk document processing."""
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if document_type is not None:
            payload["document_type"] = document_type
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        result = await self._request("POST", "/api/v1/batch", json=payload)
        return BatchCreateResult.model_validate(result)

    async def upload_to_batch(
        self,
        batch_id: str,
        file: BinaryIO | bytes,
        file_name: str,
    ) -> BatchUploadResult:
        """Upload a document to an existing batch."""
        content = file if isinstance(file, bytes) else file.read()
        if len(content) > MAX_FILE_SIZE:
            from .exceptions import DocumentTooLargeError
            raise DocumentTooLargeError()
        files = {"file": (file_name, content, _guess_mime(file_name))}
        result = await self._request("POST", f"/api/v1/batch/{batch_id}/upload", files=files)
        return BatchUploadResult.model_validate(result)

    async def get_batch_status(self, batch_id: str) -> BatchStatusResult:
        """Get the processing status of a batch."""
        result = await self._request("GET", f"/api/v1/batch/{batch_id}/status")
        return BatchStatusResult.model_validate(result)

    async def get_batch_results(self, batch_id: str) -> BatchResults:
        """Fetch extraction results for all documents in a completed batch."""
        result = await self._request("GET", f"/api/v1/batch/{batch_id}/results")
        return BatchResults.model_validate(result)

    async def wait_for_batch(
        self,
        batch_id: str,
        *,
        poll_interval: float = 5.0,
        max_wait: float = 600.0,
    ) -> BatchStatusResult:
        """Block until batch processing is complete or fails."""
        start = asyncio.get_event_loop().time()
        while True:
            status = await self.get_batch_status(batch_id)
            if status.status in ("completed", "failed"):
                return status
            elapsed = asyncio.get_event_loop().time() - start
            if elapsed + poll_interval > max_wait:
                raise PollingTimeoutError(batch_id, elapsed)
            await asyncio.sleep(poll_interval)

    async def upload_many(
        self,
        batch_id: str,
        files: list[tuple[str, bytes]],  # [(filename, content), ...]
        concurrency: int = 5,
        on_progress: Callable[[int, int], None] | None = None,
    ) -> list[BatchUploadResult]:
        """Upload multiple files to a batch with actual async concurrency."""
        results: list[BatchUploadResult] = []
        total = len(files)
        for i in range(0, total, concurrency):
            chunk = files[i:i + concurrency]
            chunk_results = await asyncio.gather(
                *(self.upload_to_batch(batch_id, content, filename) for filename, content in chunk)
            )
            results.extend(chunk_results)
            if on_progress:
                on_progress(min(i + concurrency, total), total)
        return results

    async def submit_document(
        self,
        file: BinaryIO | bytes,
        file_name: str,
        *,
        document_type: str = "auto_detect",
        verify_entities: bool = True,
        webhook_url: str | None = None,
    ) -> SubmitDocumentResult:
        content = file if isinstance(file, bytes) else file.read()
        metadata: dict[str, Any] = {
            "document_type": document_type,
            "options": {"verify_entities": verify_entities},
        }
        if webhook_url:
            metadata["webhook_url"] = webhook_url
        files = {"file": (file_name, content, _guess_mime(file_name))}
        data = {"metadata": __import__("json").dumps(metadata)}
        result = await self._request("POST", "/api/v1/documents/process-sync", files=files, data=data)
        return SubmitDocumentResult.model_validate(result)

    async def get_document_status(self, document_id: str) -> DocumentStatusResult:
        result = await self._request("GET", f"/api/v1/documents/{document_id}/status")
        return DocumentStatusResult.model_validate(result)

    async def wait_for_document(
        self,
        document_id: str,
        *,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> DocumentStatusResult:
        start = asyncio.get_event_loop().time()
        while True:
            status = await self.get_document_status(document_id)
            if status.status in ("completed", "failed"):
                return status
            elapsed = asyncio.get_event_loop().time() - start
            if elapsed + poll_interval > max_wait:
                raise PollingTimeoutError(document_id, elapsed)
            await asyncio.sleep(poll_interval)
