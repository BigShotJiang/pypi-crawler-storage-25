"""
anumiti-netra — Exception Classes
All SDK errors inherit from NeTraError.
"""

from __future__ import annotations

from typing import Any


class NeTraError(Exception):
    """Base class for all NETRA SDK errors."""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int,
        request_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        self.details = details or {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r}, status_code={self.status_code})"


class AuthenticationError(NeTraError):
    """HTTP 401 — Invalid or missing API key."""

    def __init__(self, message: str = "Invalid or missing API key", request_id: str | None = None) -> None:
        super().__init__("COMMON_UNAUTHORIZED", message, 401, request_id)


class PermissionError(NeTraError):
    """HTTP 403 — API key valid but lacks permission."""

    def __init__(self, message: str = "Permission denied", request_id: str | None = None) -> None:
        super().__init__("COMMON_FORBIDDEN", message, 403, request_id)


class RateLimitError(NeTraError):
    """HTTP 429 — Rate limit exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after_ms: int | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__("COMMON_RATE_LIMITED", message, 429, request_id)
        self.retry_after_ms = retry_after_ms


class DocumentTooLargeError(NeTraError):
    """HTTP 413 — Document exceeds 50MB limit."""

    def __init__(self, message: str = "Document exceeds 50MB limit", request_id: str | None = None) -> None:
        super().__init__("NETRA_DOCUMENT_TOO_LARGE", message, 413, request_id)


class UnsupportedFormatError(NeTraError):
    """HTTP 400 — Unsupported file format."""

    def __init__(self, message: str = "Unsupported document format", request_id: str | None = None) -> None:
        super().__init__("NETRA_UNSUPPORTED_FORMAT", message, 400, request_id)


class OCRFailedError(NeTraError):
    """HTTP 422 — OCR processing failed."""

    def __init__(self, message: str = "OCR processing failed", request_id: str | None = None) -> None:
        super().__init__("NETRA_OCR_FAILED", message, 422, request_id)


class ProcessingTimeoutError(NeTraError):
    """HTTP 408 — Document processing timed out."""

    def __init__(self, message: str = "Document processing timed out", request_id: str | None = None) -> None:
        super().__init__("NETRA_PROCESSING_TIMEOUT", message, 408, request_id)


class NotFoundError(NeTraError):
    """HTTP 404 — Document or entity not found."""

    def __init__(self, message: str = "Not found", request_id: str | None = None) -> None:
        super().__init__("COMMON_NOT_FOUND", message, 404, request_id)


class ValidationError(NeTraError):
    """HTTP 422 — Input validation failed."""

    def __init__(
        self,
        message: str,
        request_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__("COMMON_VALIDATION_FAILED", message, 422, request_id, details)


class ProcessingError(NeTraError):
    """Document processing failed."""

    def __init__(self, message: str = "Document processing failed", request_id: str | None = None) -> None:
        super().__init__("NETRA_PROCESSING_FAILED", message, 422, request_id)


class ServerError(NeTraError):
    """HTTP 5xx — Server-side error."""

    def __init__(self, message: str = "Internal server error", status_code: int = 500, request_id: str | None = None) -> None:
        super().__init__("COMMON_INTERNAL_ERROR", message, status_code, request_id)


class NetworkError(NeTraError):
    """No HTTP response received (connection error, DNS failure, etc.)."""

    def __init__(self, message: str, cause: Exception | None = None) -> None:
        super().__init__("NETWORK_ERROR", message, 0)
        self.__cause__ = cause


class PollingTimeoutError(NeTraError):
    """Polling for document completion exceeded max_wait_seconds."""

    def __init__(self, document_id: str, waited_seconds: float) -> None:
        super().__init__(
            "POLLING_TIMEOUT",
            f"Document {document_id} did not complete within {waited_seconds:.0f}s",
            408,
        )
        self.document_id = document_id
        self.waited_seconds = waited_seconds


# ─── Factory ──────────────────────────────────────────────────────────────────

_CODE_MAP: dict[str, type[NeTraError]] = {
    "COMMON_UNAUTHORIZED": AuthenticationError,
    "COMMON_FORBIDDEN": PermissionError,
    "COMMON_RATE_LIMITED": RateLimitError,
    "NETRA_DOCUMENT_TOO_LARGE": DocumentTooLargeError,
    "NETRA_UNSUPPORTED_FORMAT": UnsupportedFormatError,
    "NETRA_OCR_FAILED": OCRFailedError,
    "NETRA_PROCESSING_TIMEOUT": ProcessingTimeoutError,
    "COMMON_NOT_FOUND": NotFoundError,
    "COMMON_VALIDATION_FAILED": ValidationError,
}


def create_error(
    code: str,
    message: str,
    status_code: int,
    request_id: str | None = None,
    details: dict[str, Any] | None = None,
) -> NeTraError:
    cls = _CODE_MAP.get(code)
    if cls is None:
        if status_code == 400:
            return ValidationError(message=message, request_id=request_id, details=details)
        return ServerError(message=message, status_code=status_code, request_id=request_id)
    if cls is ValidationError:
        return cls(message=message, request_id=request_id, details=details)
    return cls(message=message, request_id=request_id)  # type: ignore[call-arg]
