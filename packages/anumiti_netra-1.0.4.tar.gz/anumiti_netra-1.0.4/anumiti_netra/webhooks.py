from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any


@dataclass
class WebhookEvent:
    id: str
    type: str
    created_at: str
    data: dict[str, Any]
    api_version: str | None = None


def verify_webhook(
    body: str | bytes,
    signature: str | None,
    secret: str,
    tolerance_seconds: int = 300,
) -> WebhookEvent:
    """Verify webhook signature from Anumiti. Raises ValueError on failure."""
    if not signature:
        raise ValueError("Missing webhook signature header")
    if not secret:
        raise ValueError("Webhook secret is required")

    payload = body if isinstance(body, str) else body.decode("utf-8")

    # Parse signature: t=timestamp,v1=hash
    parts = dict(p.split("=", 1) for p in signature.split(",") if "=" in p)
    timestamp = parts.get("t")
    hash_value = parts.get("v1")

    if not timestamp or not hash_value:
        raise ValueError("Invalid signature format")

    ts = int(timestamp)
    age = time.time() - ts
    if age > tolerance_seconds:
        raise ValueError(f"Webhook too old ({int(age)}s)")
    if age < -tolerance_seconds:
        raise ValueError("Webhook timestamp is in the future")

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.{payload}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(hash_value, expected):
        raise ValueError("Invalid webhook signature")

    data = json.loads(payload)
    return WebhookEvent(
        id=data["id"],
        type=data["type"],
        created_at=data["created_at"],
        data=data.get("data", {}),
        api_version=data.get("api_version"),
    )
