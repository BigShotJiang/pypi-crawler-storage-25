"""
anumiti-netra — Pydantic Response Models
All API responses are validated against these models before being returned.
"""

from __future__ import annotations


from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


# ─── Core ─────────────────────────────────────────────────────────────────────

class SuccessResponse(BaseModel, Generic[T]):
    success: Literal[True]
    data: T
    request_id: str


class ErrorDetail(BaseModel):
    code: str
    message: str
    details: dict[str, Any] | None = None


class ErrorResponse(BaseModel):
    success: Literal[False]
    error: ErrorDetail
    request_id: str


# ─── Document Lifecycle ───────────────────────────────────────────────────────

class SubmitDocumentResult(BaseModel):
    id: str
    status: str
    file_name: str
    file_size_bytes: int
    estimated_processing_time_ms: float
    poll_url: str
    result_url: str


class DocumentStatusResult(BaseModel):
    id: str
    status: str
    document_type: str | None = None
    document_type_confidence: float | None = None
    language_detected: str | None = None
    file_name: str
    page_count: int | None = None
    processing_started_at: str | None = None
    processing_completed_at: str | None = None
    processing_duration_ms: int | None = None
    error_message: str | None = None


# ─── GST Models ───────────────────────────────────────────────────────────────

class GSTLineItem(BaseModel):
    sl_no: int | None = None
    description: str
    hsn_code: str | None = None
    hsn_valid: bool | None = None
    quantity: float | None = None
    unit: str | None = None
    unit_price: float | None = None
    discount: float | None = None
    taxable_value: float
    cgst_rate: float | None = None
    cgst_amount: float | None = None
    sgst_rate: float | None = None
    sgst_amount: float | None = None
    igst_rate: float | None = None
    igst_amount: float | None = None
    cess_rate: float | None = None
    cess_amount: float | None = None
    total: float


class GSTParty(BaseModel):
    gstin: str | None = None
    gstin_verified: bool | None = None
    legal_name: str | None = None
    trade_name: str | None = None
    pan: str | None = None
    address: str | None = None


class GSTTotals(BaseModel):
    taxable_value: float | None = None
    total_cgst: float | None = None
    total_sgst: float | None = None
    total_igst: float | None = None
    total_cess: float | None = None
    total_tax: float | None = None
    round_off: float | None = None
    grand_total: float | None = None
    total_in_words: str | None = None
    computation_verified: bool
    computation_discrepancy: float | None = None


class GSTComplianceFlags(BaseModel):
    mandatory_fields_present: bool
    e_invoicing_applicable: bool
    irn_present: bool | None = None
    irn_valid: bool | None = None
    reverse_charge: bool | None = None
    place_of_supply_valid: bool | None = None
    hsn_rates_valid: bool | None = None
    section_17_5_blocked_items: list[str] = Field(default_factory=list)
    itc_eligible: bool | None = None


class TrustComponents(BaseModel):
    ocr_confidence: float
    verification_score: float
    compliance_score: float
    consistency_score: float


class GSTInvoiceResult(BaseModel):
    document_type: Literal["gst_invoice"]
    extraction_confidence: float
    invoice_number: str | None = None
    invoice_date: str | None = None
    invoice_type: str | None = None
    seller: GSTParty
    buyer: GSTParty
    ship_to: GSTParty | None = None
    irn: str | None = None
    ack_number: str | None = None
    ack_date: str | None = None
    line_items: list[GSTLineItem] = Field(default_factory=list)
    totals: GSTTotals
    bank_details: dict[str, str | None] = Field(default_factory=dict)
    compliance_flags: GSTComplianceFlags
    trust_score: float
    trust_components: TrustComponents


class GSTCreditNoteResult(BaseModel):
    document_type: Literal["gst_credit_note"]
    extraction_confidence: float
    note_number: str | None = None
    note_date: str | None = None
    original_invoice_number: str | None = None
    original_invoice_date: str | None = None
    reason: str | None = None
    seller: GSTParty
    buyer: GSTParty
    line_items: list[GSTLineItem] = Field(default_factory=list)
    totals: GSTTotals
    trust_score: float


class GSTEWayBillResult(BaseModel):
    document_type: Literal["gst_eway_bill"]
    extraction_confidence: float
    eway_bill_number: str | None = None
    generated_date: str | None = None
    valid_upto: str | None = None
    expired: bool
    consignor: GSTParty
    consignee: GSTParty
    invoice_number: str | None = None
    invoice_date: str | None = None
    invoice_value: float | None = None
    goods_description: str | None = None
    hsn_code: str | None = None
    transport_mode: str | None = None
    vehicle_number: str | None = None
    transporter_id: str | None = None
    trust_score: float


# ─── Contract ─────────────────────────────────────────────────────────────────

class ContractParty(BaseModel):
    name: str | None = None
    designation: str | None = None
    company: str | None = None
    address: str | None = None
    gstin: str | None = None
    pan: str | None = None


class ContractClause(BaseModel):
    clause_number: str | None = None
    title: str | None = None
    content: str
    risk_level: Literal["low", "medium", "high", "critical"]
    risk_flags: list[str] = Field(default_factory=list)
    indian_law_references: list[str] = Field(default_factory=list)


class PaymentTerms(BaseModel):
    amount: float | None = None
    currency: str
    schedule: str | None = None
    due_date: str | None = None


class ContractResult(BaseModel):
    document_type: Literal["contract"]
    extraction_confidence: float
    contract_title: str | None = None
    contract_type: str | None = None
    effective_date: str | None = None
    expiry_date: str | None = None
    governing_law: str | None = None
    jurisdiction: str | None = None
    parties: list[ContractParty] = Field(default_factory=list)
    clauses: list[ContractClause] = Field(default_factory=list)
    obligations: list[dict[str, str | None]] = Field(default_factory=list)
    payment_terms: PaymentTerms | None = None
    stamp_duty_amount: float | None = None
    stamp_duty_state: str | None = None
    stamp_duty_valid: bool | None = None
    notarized: bool | None = None
    registered: bool | None = None
    overall_risk_level: Literal["low", "medium", "high", "critical"]
    trust_score: float


# ─── Identity ─────────────────────────────────────────────────────────────────

class IdentityVerification(BaseModel):
    pan_verified: bool | None = None
    aadhaar_linked_to_pan: bool | None = None
    verified_at: str | None = None


class IdentityResult(BaseModel):
    document_type: Literal["identity"]
    extraction_confidence: float
    id_type: str
    name: str | None = None
    id_number_masked: str | None = None
    date_of_birth: str | None = None
    age_derived: int | None = None
    gender: str | None = None
    address: str | None = None
    pan_masked: str | None = None
    issued_by: str | None = None
    issue_date: str | None = None
    expiry_date: str | None = None
    is_expired: bool | None = None
    face_present: bool
    dpdp_redacted: bool
    verification: IdentityVerification | None = None
    trust_score: float


# ─── Employment ───────────────────────────────────────────────────────────────

class EmploymentResult(BaseModel):
    document_type: Literal["employment"]
    extraction_confidence: float
    document_subtype: str
    employee_name: str | None = None
    employee_id: str | None = None
    employer_name: str | None = None
    employer_pan: str | None = None
    designation: str | None = None
    department: str | None = None
    date_of_joining: str | None = None
    date_of_leaving: str | None = None
    salary_month: str | None = None
    basic_salary: float | None = None
    hra: float | None = None
    special_allowance: float | None = None
    total_ctc: float | None = None
    gross_salary: float | None = None
    net_take_home: float | None = None
    pf_employee: float | None = None
    pf_employer: float | None = None
    esi_employee: float | None = None
    esi_employer: float | None = None
    professional_tax: float | None = None
    tds: float | None = None
    pf_uan: str | None = None
    esi_number: str | None = None
    pan_masked: str | None = None
    gratuity_applicable: bool | None = None
    minimum_wage_compliant: bool | None = None
    applicable_state: str | None = None
    trust_score: float


# ─── Court Order ──────────────────────────────────────────────────────────────

class ActSection(BaseModel):
    act: str
    section: str
    description: str


class CourtOrderResult(BaseModel):
    document_type: Literal["court_order"]
    extraction_confidence: float
    order_type: str | None = None
    case_number: str | None = None
    court_name: str | None = None
    court_type: str | None = None
    bench: str | None = None
    judges: list[str] = Field(default_factory=list)
    petitioner: str | None = None
    respondent: str | None = None
    order_date: str | None = None
    pronounced_at: str | None = None
    act_sections: list[ActSection] = Field(default_factory=list)
    operative_para: str | None = None
    relief_granted: str | None = None
    next_hearing_date: str | None = None
    complied_by_date: str | None = None
    fine_amount: float | None = None
    imprisonment_period: str | None = None
    authenticated: bool
    trust_score: float


# ─── Company Filing ───────────────────────────────────────────────────────────

class Director(BaseModel):
    name: str
    din: str | None = None
    designation: str | None = None


class Shareholder(BaseModel):
    name: str
    shares: int | None = None
    percentage: float | None = None


class CompanyFilingResult(BaseModel):
    document_type: Literal["company_filing"]
    extraction_confidence: float
    form_type: str | None = None
    cin: str | None = None
    company_name: str | None = None
    incorporation_date: str | None = None
    registered_address: str | None = None
    authorized_capital: float | None = None
    paid_up_capital: float | None = None
    directors: list[Director] = Field(default_factory=list)
    shareholders: list[Shareholder] = Field(default_factory=list)
    financial_year: str | None = None
    turnover: float | None = None
    net_profit: float | None = None
    filing_date: str | None = None
    status: str | None = None
    charge_holder: str | None = None
    charge_amount: float | None = None
    trust_score: float


# ─── Verification ─────────────────────────────────────────────────────────────

class GSTINVerificationResult(BaseModel):
    gstin: str
    valid: bool
    legal_name: str | None = None
    trade_name: str | None = None
    status: str | None = None
    registration_type: str | None = None
    state_code: str | None = None
    pan_derived: str | None = None
    address: str | None = None
    verified_at: str | None = None
    provider: str | None = None


class PANVerificationResult(BaseModel):
    pan: str
    valid: bool
    name: str | None = None
    status: str | None = None
    category: str | None = None
    name_match: bool | None = None
    aadhaar_seeding_status: str | None = None
    type: str | None = None
    verified_at: str | None = None
    provider: str | None = None


# ─── Batch Processing ────────────────────────────────────────────────────────

class BatchCreateResult(BaseModel):
    batch_id: str = Field(alias="batch_id")
    status: str
    name: str | None = None
    document_type: str | None = None
    created_at: str | None = None

    model_config = {"populate_by_name": True}


class BatchUploadResult(BaseModel):
    document_id: str
    file_name: str | None = None
    queued_at: str | None = None


class BatchStatusResult(BaseModel):
    batch_id: str = Field(alias="batch_id")
    status: str
    total_documents: int = 0
    completed: int = 0
    failed: int = 0
    processing: int = 0
    progress_percentage: float = 0.0

    model_config = {"populate_by_name": True}


class BatchResultItem(BaseModel):
    document_id: str
    status: str
    document_type: str | None = None
    extraction: dict[str, Any] | None = None
    trust_score: float | None = None
    error_message: str | None = None


class BatchResults(BaseModel):
    batch_id: str
    documents: list[BatchResultItem] = Field(default_factory=list)


# ─── CIN Verification ────────────────────────────────────────────────────────

class CINVerificationResult(BaseModel):
    cin: str
    valid: bool
    company_name: str | None = None
    status: str
    incorporation_date: str | None = None
    roc: str | None = None
    authorized_capital: float | None = None
    verified_at: str


# ─── DIN Verification ────────────────────────────────────────────────────────

class DINCompany(BaseModel):
    cin: str
    name: str
    designation: str


class DINVerificationResult(BaseModel):
    din: str
    valid: bool
    director_name: str | None = None
    status: str
    companies: list[DINCompany] = Field(default_factory=list)
    verified_at: str


# ─── Bank Account Verification ───────────────────────────────────────────────

class BankVerificationResult(BaseModel):
    account_exists: bool
    name_at_bank: str | None = None
    bank_name: str | None = None
    branch: str | None = None
    ifsc: str
    verified_at: str


# ─── E-Invoice IRN Verification ──────────────────────────────────────────────

class EInvoiceIRNResult(BaseModel):
    irn: str
    valid: bool
    invoice_number: str | None = None
    seller_gstin: str | None = None
    buyer_gstin: str | None = None
    invoice_value: float | None = None
    status: str
    verified_at: str


# ─── E-Way Bill Verification ─────────────────────────────────────────────────

class EWayBillVerificationResult(BaseModel):
    eway_bill_number: str
    valid: bool
    from_gstin: str | None = None
    to_gstin: str | None = None
    invoice_value: float | None = None
    valid_upto: str | None = None
    vehicle_number: str | None = None
    status: str
    verified_at: str
