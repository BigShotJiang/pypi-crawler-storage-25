"""
跨 sub_db 原子写事务

LMDB 同一 env 下的多个 named database 可以共享一个 write transaction。
本模块把这个能力暴露给 FlaxKV 用户，支持跨 sub_db 的原子写。

API:
    with cross_db_txn(todos, inbox) as txn:
        txn.put(todos, todo_id, todo_dict)
        txn.put(inbox, inbox_id, inbox_dict)

要么全提交，要么全回滚。block 内抛异常 → 全部回滚。

约束：
    - 所有 db 必须共享同一 LMDB env（同一 path）
    - 不支持同一线程嵌套
    - 不支持 auto_nested 的 dict/list 值（嵌套写多 entry，超出单事务原子语义）
    - put 走 db 自身的 key/value 编解码，与常规 db[key]=value 二进制兼容

实现策略：
    block 内只收集 ops，__exit__ 时统一在 LMDB write txn 中执行。
    遇到 MapFullError 自动 resize 并重试整批（与 LmdbDatabase._write_with_retry 一致）。
    提交后 invalidate 涉及的缓存条目，避免脏读。
"""

import threading
from contextlib import contextmanager
from typing import Any, Optional

import lmdb

from flaxkv2.core.nested_structures import NestedDBDict, NestedDBList
from flaxkv2.utils.log import get_logger

logger = get_logger(__name__)

_thread_state = threading.local()


class CrossDbTxn:
    """事务对象：收集 put/delete 操作，由 cross_db_txn 在退出时统一应用。"""

    def __init__(self, dbs: tuple):
        self._dbs = dbs
        self._db_ids = {id(d) for d in dbs}
        self._ops: list = []

    def _check_db(self, db) -> None:
        if id(db) not in self._db_ids:
            raise ValueError(
                f"db {getattr(db, 'name', db)!r} (sub_db={getattr(db, '_sub_db', None)!r}) "
                f"is not part of this cross_db_txn"
            )

    def _check_value(self, db, value) -> None:
        if isinstance(value, (NestedDBDict, NestedDBList)):
            raise ValueError(
                "cross_db_txn does not accept NestedDBDict/NestedDBList values; "
                "convert via .to_dict()/.to_list() and use auto_nested=False keys."
            )
        if getattr(db, "_auto_nested", False) and isinstance(value, (dict, list)):
            raise ValueError(
                f"cross_db_txn cannot atomically write a {type(value).__name__} into "
                f"an auto_nested db (it would expand to multiple entries). "
                f"Disable auto_nested for the dbs participating in cross_db_txn."
            )

    def put(self, db, key: Any, value: Any, ttl: Optional[int] = None) -> None:
        """暂存一次 put。ttl=None 时使用 db.default_ttl。"""
        self._check_db(db)
        self._check_value(db, value)
        if ttl is None:
            ttl = getattr(db, "_default_ttl", None)
        self._ops.append(("put", db, key, value, ttl))

    def delete(self, db, key: Any) -> None:
        """暂存一次 delete。"""
        self._check_db(db)
        self._ops.append(("delete", db, key))

    def get(self, db, key: Any, default: Any = None) -> Any:
        """读取 db 当前已提交状态（看不到本事务尚未提交的写）。"""
        self._check_db(db)
        try:
            return db[key]
        except KeyError:
            return default

    def __len__(self) -> int:
        return len(self._ops)


def _validate_shared_env(dbs: tuple) -> lmdb.Environment:
    """校验所有 db 共享同一 env，返回该 env。"""
    if not dbs:
        raise ValueError("cross_db_txn requires at least one db")

    envs = []
    paths = []
    for d in dbs:
        if not hasattr(d, "_db") or d._db is None or getattr(d, "_closed", False):
            raise ValueError(
                f"db {getattr(d, 'name', d)!r} is closed or not initialized"
            )
        env = d._db._env
        if env is None:
            raise ValueError(
                f"db {getattr(d, 'name', d)!r} has no LMDB env (already closed?)"
            )
        envs.append(env)
        paths.append(d._db._path)

    if len({id(e) for e in envs}) > 1:
        raise ValueError(
            f"All dbs must share the same LMDB env. Got distinct paths: {sorted(set(paths))}. "
            f"For cross_db_txn to work, dbs must be opened with the same root_path "
            f"and the same db_name (only sub_db differs)."
        )
    return envs[0]


def _flush_buffers(dbs: tuple) -> None:
    """flush 每个 db 的写缓冲区，确保 commit 前看到最新状态。"""
    for d in dbs:
        flush = getattr(d, "flush", None)
        if callable(flush):
            try:
                flush()
            except Exception as exc:
                logger.warning(f"flush before cross_db_txn commit failed: {exc}")


def _acquire_write_locks(dbs: tuple) -> list:
    """对每个 CachedLmdbDict 持有写锁（按 id 排序避免死锁）。"""
    locks = []
    sorted_dbs = sorted(dbs, key=id)
    for d in sorted_dbs:
        lock = getattr(d, "_db_lock", None)
        if lock is not None:
            cm = lock.write_lock()
            cm.__enter__()
            locks.append(cm)
    return locks


def _release_locks(locks: list) -> None:
    for cm in reversed(locks):
        try:
            cm.__exit__(None, None, None)
        except Exception as exc:
            logger.error(f"Error releasing lock: {exc}")


def _apply_ops(env: lmdb.Environment, ops: list) -> None:
    """在一个 LMDB write txn 中应用所有 ops。MapFullError 时整批重试。"""
    if not ops:
        return

    # 预编码（在 txn 外做，减少事务持有时间）
    encoded = []
    for op in ops:
        if op[0] == "put":
            _, db, key, value, ttl = op
            key_bytes = db._encode_key(key)
            value_bytes = db._encode_value(value, ttl_seconds=ttl)
            encoded.append(("put", db._db._db_handle, key_bytes, value_bytes))
        else:  # delete
            _, db, key = op
            key_bytes = db._encode_key(key)
            encoded.append(("delete", db._db._db_handle, key_bytes))

    while True:
        try:
            with env.begin(write=True) as txn:
                for entry in encoded:
                    if entry[0] == "put":
                        _, handle, k, v = entry
                        txn.put(k, v, db=handle)
                    else:
                        _, handle, k = entry
                        txn.delete(k, db=handle)
            return
        except lmdb.MapFullError:
            current = env.info()["map_size"]
            new_size = current * 2
            env.set_mapsize(new_size)
            logger.warning(
                f"cross_db_txn hit MapFullError, doubled map_size to {new_size / (1024 * 1024):.0f} MB"
            )
            # 同步每个 LmdbDatabase 内部记录的 map_size，避免后续 _write_with_retry 误判
            seen = set()
            for op in ops:
                db = op[1]
                lmdb_db = db._db
                if id(lmdb_db) in seen:
                    continue
                seen.add(id(lmdb_db))
                try:
                    lmdb_db._map_size = new_size
                except Exception:
                    pass


def _invalidate_caches(ops: list) -> None:
    """提交后失效缓存：从缓存条目中移除涉及的 key，让下次读走 LMDB。"""
    # 按 db 聚合
    keys_per_db: dict = {}
    for op in ops:
        db = op[1]
        if not getattr(db, "_cache_enabled", False):
            continue
        cache = getattr(db, "_cache", None)
        if cache is None:
            continue
        keys_per_db.setdefault(id(db), (cache, []))[1].append(op[2])

    for cache, keys in keys_per_db.values():
        try:
            with cache._lock:
                for k in keys:
                    cache._cache.pop(k, None)
                    cache._dirty_keys.discard(k)
                    cache._delete_keys.discard(k)
        except Exception as exc:
            logger.warning(f"cache invalidation after cross_db_txn failed: {exc}")


@contextmanager
def cross_db_txn(*dbs):
    """跨 sub_db 原子写事务。

    Args:
        *dbs: 一个或多个 FlaxKV 实例（必须共享同一 LMDB env）。

    Yields:
        CrossDbTxn: 通过 txn.put(db, key, value, ttl=None) 暂存写操作。

    Raises:
        ValueError: dbs 为空、不共享同一 env、或包含 auto_nested + dict/list 值。
        RuntimeError: 同一线程嵌套调用。
        lmdb.Error: LMDB 写入失败（非 MapFullError）。

    Examples:
        >>> todos = FlaxKV("main", "/db", sub_db="todos")
        >>> inbox = FlaxKV("main", "/db", sub_db="inbox")
        >>> with cross_db_txn(todos, inbox) as txn:
        ...     txn.put(todos, "t1", {"title": "buy milk"})
        ...     txn.put(inbox, "i1", {"status": "promoted", "todo_id": "t1"})
    """
    if getattr(_thread_state, "active", False):
        raise RuntimeError(
            "cross_db_txn cannot be nested in the same thread "
            "(LMDB allows only one write transaction per env at a time)"
        )

    env = _validate_shared_env(dbs)
    txn_obj = CrossDbTxn(tuple(dbs))

    _thread_state.active = True
    user_raised = False
    try:
        try:
            yield txn_obj
        except BaseException:
            user_raised = True
            raise

        if user_raised or not txn_obj._ops:
            return

        _flush_buffers(dbs)
        locks = _acquire_write_locks(dbs)
        try:
            _apply_ops(env, txn_obj._ops)
        finally:
            _release_locks(locks)

        _invalidate_caches(txn_obj._ops)
    finally:
        _thread_state.active = False
