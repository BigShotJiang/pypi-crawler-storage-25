---
name: flaxkv2
description: >
  高性能持久化键值存储。基于 LMDB，替代 sqlite/redis/pickle/shelve 做本地或远程 KV 存储。

  **何时用**：要做本地或远程的持久化键值存储 —— 缓存计算结果、存配置、存 embedding 向量、
  跨进程/跨机器共享小到中型数据。字典式 API：`db["key"] = value`。

  **核心心智**：
  - `FlaxKV(name, path)` —— 类字典 KV，自动序列化几乎所有 Python 类型
  - 同一 path 多个 `sub_db` 共享一个 LMDB env，可用 `cross_db_txn` 跨 sub_db 原子写
  - `FlaxList` / `FlaxQueue` / `FlaxTimeSeries` / `RotatingFlaxList` —— 持久化数据结构
    （LMDB 后端，统一接口风格）
  - 远程访问：`FlaxKV("name", "tcp://host:port")` 客户端 + `flaxkv2 run` 启服务
  - 性能档：默认无缓存简单可靠；加 `read_cache_size`/`write_buffer_size` 切到 `CachedLmdbDict`，
    热数据读取 10x+

  **不要用于**：结构化数据文件（jsonl/parquet/csv）→ 用 dtflow；LLM API 调用 → 用 flexllm；
  文本嵌入/向量检索 → 用 maque。
---

# flaxkv2 - 持久化键值存储

## 何时用 flaxkv2

| 任务 | 用什么 |
|---|---|
| 持久化 KV、缓存计算结果、存配置/状态/embedding | **flaxkv2** |
| 跨进程或跨机器共享 KV 数据 | **flaxkv2**（多进程直接读写同一 path；远程 ZMQ） |
| 持久化列表 / 队列 / 时间序列 | **flaxkv2**（FlaxList / FlaxQueue / FlaxTimeSeries） |
| 处理 jsonl/parquet/csv 文件 | dtflow |
| 调 LLM | flexllm |
| 文本嵌入 / 向量检索 | maque |

flaxkv2 是基于 LMDB 的字典式存储。**多进程并发读写直接走文件，无需 server**；要跨机器才需要起远程服务。

## Agent 探索入口

```bash
flaxkv2 --help                       # 命令列表
flaxkv2 inspect keys mydb            # 看一个数据库里有哪些 key
flaxkv2 inspect stats mydb           # 数据库统计
flaxkv2 inspect get mydb <key>       # 看某个 key 的值
flaxkv2 version
```

源码：`~/github/flaxkv2`，CLI 入口 `flaxkv2/cli.py`，核心实现 `flaxkv2/core/`。

## 心智模型

### 后端选择（自动）

```
FlaxKV("name", path_or_url, **kw)
       │
       ├─ url 以 "tcp://" 开头         → RemoteDBDict（远程客户端，要先启 server）
       ├─ kw 含 read_cache_size 或     → CachedLmdbDict（缓存 + 写缓冲，性能档）
       │  write_buffer_size
       └─ 其他                         → RawLmdbDict（默认，简单可靠）
```

不传缓存参数就是简单模式；要性能就传缓存参数。**不要为了"安全"过度配缓存**，写多读少时 `RawLmdbDict` 已经够。

### 数据结构家族

| 类 | 何时用 |
|---|---|
| `FlaxKV` | 普通 KV：`db[key] = value` |
| `FlaxList` | 持久化列表：append、按下标访问、可选 sorted 模式、`max_size` 自动裁剪 |
| `FlaxQueue` | 持久化 FIFO 队列：O(1) 入队/出队、`max_size` 满了自动丢最旧 |
| `FlaxTimeSeries` | 时间序列：自动时间戳、范围查询 O(log n)、`stats`/`downsample`/滑动窗口 |
| `RotatingFlaxList` | 时间分片日志：按 hour/day 分片，自动清理过期分片 |

**统一签名**：所有数据结构第一个参数都是 `name`，第二个 `path`，可选 `sub_db` 与其他结构共享同一 LMDB env。

### sub_db 与跨表事务

同一 `path + db_name` 下可开多个 `sub_db`，它们**共享同一个 LMDB env**：

```python
todos = FlaxKV("app", "/data", sub_db="todos")
inbox = FlaxKV("app", "/data", sub_db="inbox")
ts    = FlaxTimeSeries("app", "/data", sub_db="metrics")
```

跨 sub_db 要原子写（要么都成、要么都不成）→ `cross_db_txn`：

```python
from flaxkv2 import cross_db_txn

with cross_db_txn(todos, inbox) as txn:
    txn.put(todos, todo_id, {"title": "buy milk"})
    txn.put(inbox, inbox_id, {"status": "promoted", "todo_id": todo_id})
# 任一异常 → 全部回滚
```

走的是 FlaxKV 同一套编解码（**不要**绕过 FlaxKV 直接捅 lmdb env，会导致字节不兼容）。

## 典型 Python 用法

### 基本

```python
from flaxkv2 import FlaxKV

with FlaxKV("mydb", "./data") as db:
    db["key"] = "value"
    db["config"] = {"host": "localhost", "port": 8080}   # dict/list/numpy/pandas 都自动序列化
    print(db.get("missing", "default"))
    db.update({"k1": 1, "k2": 2})
    for k, v in db.items():
        ...
```

### TTL（缓存场景）

```python
db = FlaxKV("cache", "./data", default_ttl=300)   # 所有新 key 5 分钟过期
db["session"] = "token"
db.set_ttl("session", 3600)                       # 单独覆盖
```

### 性能档（读多写少）

```python
db = FlaxKV("hot", "./data",
            read_cache_size=10000,
            write_buffer_size=500)
# 默认 async_flush=True 极致性能；生产慎用，进程崩溃会丢缓冲区
# 生产建议 async_flush=False
```

### 远程

```python
# 服务端先起：
#   flaxkv2 run --host 0.0.0.0 --port 5555 --data-dir ./data
db = FlaxKV("shared", "tcp://server:5555")
db["k"] = "v"
```

## 何时转向直接读源码

SKILL 不堆全 API。要看完整列表去：

- 主入口与参数：`flaxkv2/__init__.py` 的 `FlaxKV.__new__` docstring
- 数据结构：`flaxkv2/core/flax_list.py` / `flax_queue.py` / `flax_timeseries.py` / `rotating_flax_list.py`
- 跨表事务：`flaxkv2/core/cross_db_txn.py`
- CLI：`flaxkv2/cli.py`、Inspector `flaxkv2/inspector/cli.py`
- 性能预设：`flaxkv2/config.py`（balanced / read_optimized / write_optimized / memory_constrained / large_database / ml_workload）

## 注意事项

- **始终关闭** —— 用 `with` 或显式 `close()`，启用缓存时尤其重要（缓冲区要 flush）
- **多进程读写** —— LMDB 原生支持，直接打开同一 path 即可，不需要远程服务
- **远程加密** —— 公网部署用 `--enable-encryption --password ...`
- **不要存大对象** —— LMDB 单 value 有限制，超过几 MB 考虑外存（如对象存储）只把元数据放 KV
- **Pickle 风险** —— 复杂自定义对象走 pickle，仅用于可信环境
