"""Claude Code Skill 安装命令

将 flaxkv2/SKILL.md 安装到 ~/.claude/skills/flaxkv2/SKILL.md，
让 Claude Code 在合适场景自动加载本 skill。
"""

import shutil
from pathlib import Path

from rich.console import Console

console = Console()


def _source_path() -> Path:
    """SKILL.md 源文件（与本 cli_skill.py 同包目录下）。"""
    return Path(__file__).parent / "SKILL.md"


def _target_dir() -> Path:
    return Path.home() / ".claude" / "skills" / "flaxkv2"


def install_skill() -> None:
    """安装 flaxkv2 skill 到 Claude Code（全局）。"""
    source = _source_path()
    if not source.exists():
        console.print("[red]错误: SKILL.md 源文件不存在[/red]")
        console.print(f"  [dim]期望路径: {source}[/dim]")
        console.print(
            "  [dim]如果通过 pip install 安装，请升级到包含 SKILL.md 的版本[/dim]"
        )
        raise SystemExit(1)

    target_dir = _target_dir()
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "SKILL.md"
    shutil.copy2(source, target)

    console.print("[green]✓[/green] 已安装 flaxkv2 skill 到 Claude Code（全局）")
    console.print(f"  [dim]{target}[/dim]")
    console.print()
    console.print("[dim]在 Claude Code 中通过提及 flaxkv2 / 键值存储 等关键词触发[/dim]")


def uninstall_skill() -> None:
    """卸载 flaxkv2 skill（全局）。"""
    target = _target_dir() / "SKILL.md"
    if not target.exists():
        console.print("[yellow]flaxkv2 skill 未安装[/yellow]")
        return

    target.unlink()
    target_dir = _target_dir()
    if target_dir.exists() and not any(target_dir.iterdir()):
        target_dir.rmdir()

    console.print("[green]✓[/green] 已卸载 flaxkv2 skill（全局）")


def skill_status() -> None:
    """显示 skill 安装状态。"""
    target = _target_dir() / "SKILL.md"
    if target.exists():
        console.print("[green]✓[/green] 全局 skill 已安装")
        console.print(f"  [dim]{target}[/dim]")
    else:
        console.print("[yellow]✗[/yellow] 全局 skill 未安装")
        console.print("  [dim]运行 flaxkv2 install-skill 安装[/dim]")
