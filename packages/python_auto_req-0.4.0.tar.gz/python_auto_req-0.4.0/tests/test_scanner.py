"""Tests for req_scanner.scanner (import extraction and file collection)."""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from auto_req.scanner import (
    imports_from_source,
    imports_from_notebook,
    collect_imports,
    stdlib_module_names,
    _EXCLUDE_DIRS,
)


# ---------------------------------------------------------------------------
# imports_from_source
# ---------------------------------------------------------------------------


def test_simple_import():
    assert imports_from_source("import numpy") == {"numpy"}


def test_from_import():
    assert imports_from_source("from pandas import DataFrame") == {"pandas"}


def test_submodule_import_returns_top_level():
    assert imports_from_source("import os.path") == {"os"}


def test_relative_import_ignored():
    assert imports_from_source("from .utils import helper") == set()


def test_multiple_imports():
    src = textwrap.dedent("""\
        import os
        import sys
        import numpy as np
        from pandas import DataFrame
        from sklearn.linear_model import LinearRegression
    """)
    result = imports_from_source(src)
    assert "numpy" in result
    assert "pandas" in result
    assert "sklearn" in result
    # stdlib included at extraction stage (filtered later)
    assert "os" in result
    assert "sys" in result


def test_syntax_error_returns_empty():
    assert imports_from_source("def (broken syntax!!!") == set()


def test_empty_source():
    assert imports_from_source("") == set()


# ---------------------------------------------------------------------------
# imports_from_notebook
# ---------------------------------------------------------------------------

FIXTURES = Path(__file__).parent / "fixtures"


def test_notebook_extracts_imports():
    nb_path = FIXTURES / "sample.ipynb"
    result = imports_from_notebook(nb_path)
    assert "yfinance" in result
    assert "statsmodels" in result
    assert "matplotlib" in result
    assert "pandas" in result
    assert "seaborn" in result


def test_notebook_ignores_magics_and_shell(tmp_path):
    """Magic lines and ! commands must not cause SyntaxError or false positives."""
    nb = {
        "cells": [
            {
                "cell_type": "code",
                "source": [
                    "%matplotlib inline\n",
                    "!pip install something\n",
                    "import requests\n",
                ],
            }
        ]
    }
    nb_file = tmp_path / "test.ipynb"
    nb_file.write_text(json.dumps(nb), encoding="utf-8")
    result = imports_from_notebook(nb_file)
    assert "requests" in result


def test_notebook_skips_markdown_cells(tmp_path):
    nb = {
        "cells": [
            {"cell_type": "markdown", "source": ["import os\n"]},
            {"cell_type": "code", "source": ["import sys\n"]},
        ]
    }
    nb_file = tmp_path / "test.ipynb"
    nb_file.write_text(json.dumps(nb), encoding="utf-8")
    result = imports_from_notebook(nb_file)
    assert "os" not in result
    assert "sys" in result


def test_malformed_notebook_returns_empty(tmp_path):
    nb_file = tmp_path / "bad.ipynb"
    nb_file.write_text("not json", encoding="utf-8")
    assert imports_from_notebook(nb_file) == set()


# ---------------------------------------------------------------------------
# collect_imports
# ---------------------------------------------------------------------------


def test_collect_imports_from_fixture_dir():
    result = collect_imports(FIXTURES)
    # From sample.py
    assert "numpy" in result
    assert "pandas" in result
    assert "sklearn" in result
    assert "matplotlib" in result
    # From sample.ipynb
    assert "yfinance" in result
    assert "statsmodels" in result
    assert "seaborn" in result


def test_collect_imports_excludes_venv(tmp_path):
    """Packages imported only inside .venv must not appear."""
    venv_file = tmp_path / ".venv" / "lib" / "site-packages" / "somelib" / "code.py"
    venv_file.parent.mkdir(parents=True)
    venv_file.write_text("import secret_package\n", encoding="utf-8")

    project_file = tmp_path / "main.py"
    project_file.write_text("import requests\n", encoding="utf-8")

    result = collect_imports(tmp_path)
    assert "requests" in result
    assert "secret_package" not in result


def test_collect_imports_excludes_pycache(tmp_path):
    cache_file = tmp_path / "__pycache__" / "cached.py"
    cache_file.parent.mkdir()
    cache_file.write_text("import hidden_dep\n", encoding="utf-8")

    result = collect_imports(tmp_path)
    assert "hidden_dep" not in result


def test_collect_imports_skips_self(tmp_path):
    self_file = tmp_path / "req_scanner_script.py"
    self_file.write_text("import special_internal\n", encoding="utf-8")

    result = collect_imports(tmp_path, self_path=self_file.resolve())
    assert "special_internal" not in result


# ---------------------------------------------------------------------------
# stdlib_module_names
# ---------------------------------------------------------------------------


def test_stdlib_contains_common_modules():
    stdlib = stdlib_module_names()
    for mod in ("os", "sys", "json", "re", "pathlib", "itertools"):
        assert mod in stdlib, f"{mod} expected in stdlib"


def test_exclude_dirs_set():
    assert ".venv" in _EXCLUDE_DIRS
    assert "__pycache__" in _EXCLUDE_DIRS
    assert "node_modules" in _EXCLUDE_DIRS
