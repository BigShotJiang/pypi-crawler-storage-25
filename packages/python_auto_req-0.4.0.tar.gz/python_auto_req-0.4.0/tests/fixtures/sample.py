"""Fixture: a sample Python file with third-party and stdlib imports."""
import os
import sys
import json

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
from PIL import Image


def do_something():
    pass
