"""Tests for auto_req.resolver (ngram scoring, resolution pipeline)."""
from __future__ import annotations

import sys
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest

from auto_req.resolver import (
    StopResolution,
    _prompt,
    ngram_score,
    rank_candidates,
    resolve_all,
    resolve_from_env,
    search_pypi,
)


# ---------------------------------------------------------------------------
# ngram_score
# ---------------------------------------------------------------------------


def test_identical_strings_score_one():
    assert ngram_score("numpy", "numpy") == pytest.approx(1.0)


def test_completely_different_strings_score_low():
    assert ngram_score("numpy", "zzzzz") < 0.2


def test_empty_string_returns_zero():
    assert ngram_score("", "numpy") == 0.0
    assert ngram_score("numpy", "") == 0.0


def test_similar_strings_score_higher_than_dissimilar():
    similar = ngram_score("yfinance", "yfinance-cache")
    dissimilar = ngram_score("yfinance", "abcdefghij")
    assert similar > dissimilar


# ---------------------------------------------------------------------------
# rank_candidates
# ---------------------------------------------------------------------------


def test_rank_puts_best_match_first():
    candidates = ["yfinance-cache", "yfinance", "something-else"]
    ranked = rank_candidates("yfinance", candidates)
    assert ranked[0] == "yfinance"


def test_rank_empty_list():
    assert rank_candidates("numpy", []) == []


# ---------------------------------------------------------------------------
# resolve_from_env
# ---------------------------------------------------------------------------


def test_resolve_from_env_finds_installed_package():
    # 'pytest' should be installed since we're running in a test env
    result = resolve_from_env("pytest")
    assert result is not None
    assert isinstance(result, str)


def test_resolve_from_env_returns_none_for_unknown():
    result = resolve_from_env("__definitely_not_a_real_module_xyz__")
    assert result is None


# ---------------------------------------------------------------------------
# search_pypi  (mocked)
# ---------------------------------------------------------------------------


def _mock_pypi_response(names: list[str]) -> str:
    """Build a minimal HTML fragment matching the PyPI search result format."""
    items = "".join(
        f'<span class="package-snippet__name">{n}</span>' for n in names
    )
    return f"<html>{items}</html>"


@patch("urllib.request.urlopen")
def test_search_pypi_parses_results(mock_urlopen):
    html = _mock_pypi_response(["numpy", "numpy-financial", "numpydoc"])
    mock_resp = MagicMock()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_resp.read.return_value = html.encode()
    mock_urlopen.return_value = mock_resp

    result = search_pypi("numpy", n=5)
    assert "numpy" in result


@patch("urllib.request.urlopen", side_effect=OSError("network error"))
def test_search_pypi_returns_empty_on_failure(mock_urlopen):
    result = search_pypi("numpy")
    assert result == []


# ---------------------------------------------------------------------------
# _prompt
# ---------------------------------------------------------------------------


def test_prompt_auto_session_picks_first_candidate():
    dist, new_auto = _prompt("yfinance", ["yfinance", "yfinance-cache"], auto_session=True)
    assert dist == "yfinance"
    assert new_auto is True


def test_prompt_auto_session_falls_back_to_module_name_when_no_candidates():
    dist, new_auto = _prompt("mymodule", [], auto_session=True)
    assert dist == "mymodule"
    assert new_auto is True


def test_prompt_numeric_choice(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "2")
    dist, new_auto = _prompt("something", ["alpha", "beta", "gamma"], auto_session=False)
    assert dist == "beta"
    assert new_auto is False


def test_prompt_skip(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "s")
    dist, new_auto = _prompt("something", ["alpha"], auto_session=False)
    assert dist is None
    assert new_auto is False


def test_prompt_quit_raises(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "q")
    with pytest.raises(StopResolution):
        _prompt("something", ["alpha"], auto_session=False)


def test_prompt_manual_entry(monkeypatch):
    responses = iter(["m", "my-custom-dist"])
    monkeypatch.setattr("builtins.input", lambda _: next(responses))
    dist, _ = _prompt("something", ["alpha"], auto_session=False)
    assert dist == "my-custom-dist"


def test_prompt_enable_auto_mid_session(monkeypatch):
    monkeypatch.setattr("builtins.input", lambda _: "a")
    dist, new_auto = _prompt("something", ["best-match", "other"], auto_session=False)
    assert dist == "best-match"
    assert new_auto is True  # auto enabled for rest of session


def test_prompt_invalid_then_valid(monkeypatch, capsys):
    responses = iter(["99", "1"])
    monkeypatch.setattr("builtins.input", lambda _: next(responses))
    dist, _ = _prompt("something", ["alpha"], auto_session=False)
    assert dist == "alpha"


# ---------------------------------------------------------------------------
# resolve_all
# ---------------------------------------------------------------------------


def test_resolve_all_filters_stdlib():
    stdlib = {"os", "sys", "json", "re", "pathlib"}
    packages, skipped = resolve_all({"os", "sys", "json"}, stdlib, auto_mode=True)
    assert packages == {}
    assert skipped == []


def test_resolve_all_auto_mode_resolves_installed(monkeypatch):
    """Modules installed in the test env should resolve without PyPI search."""
    stdlib = set()
    # 'pytest' is definitely installed
    with patch("auto_req.resolver.search_pypi") as mock_search:
        packages, skipped = resolve_all({"pytest"}, stdlib, auto_mode=True)
    # Should resolve via env, search_pypi should not be called
    mock_search.assert_not_called()
    assert "pytest" in packages


def test_resolve_all_unknown_module_auto(monkeypatch):
    """Unknown module with auto=True should call PyPI search and pick the top-ranked result."""
    stdlib = set()
    candidates = ["my-dist", "other"]
    with patch("auto_req.resolver.search_pypi", return_value=candidates):
        packages, skipped = resolve_all(
            {"__totally_unknown_xyz__"}, stdlib, auto_mode=True
        )
    top_ranked = rank_candidates("__totally_unknown_xyz__", candidates)[0]
    assert top_ranked in packages


def test_resolve_all_stop_resolution(monkeypatch):
    """User pressing [q] must stop processing without raising to caller."""
    stdlib = set()
    with patch("auto_req.resolver.resolve_via_pypi", side_effect=StopResolution):
        packages, skipped = resolve_all(
            {"__unknown1__", "__unknown2__"}, stdlib, auto_mode=False
        )
    # Nothing resolved, nothing skipped – loop stopped cleanly
    assert packages == {}
    assert skipped == []
