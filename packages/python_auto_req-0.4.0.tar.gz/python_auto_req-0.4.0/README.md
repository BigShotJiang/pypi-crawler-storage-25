# python-auto-req

Scan your Python project's `.py` and `.ipynb` files, discover every third-party
package that is actually **imported**, and add them to `requirements.txt`.

> **Only packages explicitly referenced in your source files are considered.**
> Packages installed in `.venv` but never imported are ignored.

---

## Features

- Recursively scans `.py` and `.ipynb` files (skips `.venv`, `.git`, `__pycache__`, etc.)
- Uses the active Python environment to resolve module → distribution name + version
- Falls back to a **live PyPI search** for unknown modules with an interactive menu:
  - Pick from top-5 results ranked by n-gram similarity
  - Auto-select top match (`[a]` or `--auto`)
  - Enter a name manually (`[m]`)
  - Skip (`[s]`) or quit (`[q]`)
- Offers to run `pip install -r requirements.txt` after writing

---

## Installation

```bash
pip install python-auto-req
```

Or from source:

```bash
git clone https://github.com/Amit-Roy/python-auto-req
cd python-auto-req
pip install -e .
```

---

## Usage

```bash
# Preview what would be added (dry-run, interactive)
auto-req

# Write requirements.txt
auto-req --dry-run 0

# Write requirements.txt, auto-pick top PyPI match for unknowns
auto-req --dry-run 0 --auto

# Scan a specific directory
auto-req --dir /path/to/project --dry-run 0
```

Or via Python:

```bash
python -m auto_req --dry-run 0
```

### CLI options

| Option | Default | Description |
|---|---|---|
| `--dry-run 0\|1` | `1` | `1` = preview only; `0` = write to file |
| `--auto` | off | Always pick the top PyPI match (no prompts) |
| `--dir DIR` | `.` | Project root to scan |
| `--requirements FILE` | `./requirements.txt` | Path to requirements.txt |

---

## Interactive resolution example

```
  Unrecognised module: 'yfinance'
  Searching PyPI for 'yfinance'... 5 result(s).
  Top PyPI matches:
    [1] yfinance       (similarity 1.00)
    [2] yfinance-cache (similarity 0.78)
    [3] yfinance-ez    (similarity 0.72)
    ...

  [1-5] select a match above
  [a]   auto-select top match for ALL remaining unknowns
  [m]   enter the correct dist name manually
  [s]   skip  (omit from requirements, continue)
  [q]   quit  (stop resolution now)

  Your choice: 1
```

---

## Development

```bash
pip install -e ".[dev]"
pytest
```

---

[MIT License](LICENSE)
