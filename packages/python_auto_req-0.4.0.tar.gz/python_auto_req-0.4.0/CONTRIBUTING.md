# Contributing

Contributions are welcome and appreciated. By submitting a pull request you agree to release your contribution under the [MIT License](LICENSE).

## How to contribute

1. Fork the repository and create a branch from `main`.
2. Install the project in development mode:
   ```bash
   pip install -e ".[dev]"
   ```
3. Make your changes and add tests where appropriate.
4. Run the test suite:
   ```bash
   pytest
   ```
5. Open a pull request describing what you changed and why.

## Guidelines

- Keep changes focused — one fix or feature per pull request.
- There is no formal style guide; just match the surrounding code.
- All contributions, including bug reports and feature requests via issues, are welcome.
