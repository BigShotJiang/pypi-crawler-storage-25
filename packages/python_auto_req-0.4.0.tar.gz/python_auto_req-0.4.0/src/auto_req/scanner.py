"""
scanner.py – stdlib detection and import extraction from .py / .ipynb files.

Only imports that are explicitly referenced in project source files are
collected.  The virtual-environment directory (and other non-project paths)
are excluded so that installed-but-unreferenced packages are never surfaced.
"""

from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path

# Directories that are never part of project source code.
_EXCLUDE_DIRS: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "env",
        "__pycache__",
        ".git",
        ".hg",
        ".tox",
        ".nox",
        "node_modules",
        "dist",
        "build",
        "site-packages",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
    }
)


# ---------------------------------------------------------------------------
# stdlib detection
# ---------------------------------------------------------------------------


def stdlib_module_names() -> set[str]:
    """Return the set of top-level stdlib module names for the running Python."""
    if hasattr(sys, "stdlib_module_names"):  # Python 3.10+
        return set(sys.stdlib_module_names)  # type: ignore[attr-defined]
    # Fallback for older Python
    import sysconfig

    names: set[str] = set()
    for key in ("stdlib", "platstdlib"):
        p = sysconfig.get_paths().get(key, "")
        if not p:
            continue
        for item in Path(p).iterdir():
            names.add(item.stem if item.is_file() else item.name)
    return names


# ---------------------------------------------------------------------------
# Import extraction
# ---------------------------------------------------------------------------


def imports_from_source(source: str) -> set[str]:
    """
    Parse *source* as Python and return every top-level imported module name.

    Only absolute imports are considered (relative imports are project-internal).
    Returns an empty set on SyntaxError rather than raising.
    """
    names: set[str] = set()
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return names

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:
                names.add(node.module.split(".")[0])

    return names


def imports_from_notebook(path: Path) -> set[str]:
    """
    Parse a Jupyter notebook and return every top-level imported module name
    across all code cells.
    """
    names: set[str] = set()
    try:
        nb = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return names

    for cell in nb.get("cells", []):
        if cell.get("cell_type") != "code":
            continue
        source = "".join(cell.get("source", []))
        # Strip IPython line/cell magics and shell commands before parsing
        source = re.sub(r"^\s*%%?\w+.*$", "", source, flags=re.MULTILINE)
        source = re.sub(r"^\s*!.*$", "", source, flags=re.MULTILINE)
        names |= imports_from_source(source)

    return names


# ---------------------------------------------------------------------------
# Directory walker
# ---------------------------------------------------------------------------


def _is_excluded(path: Path) -> bool:
    """Return True if *path* lives inside an excluded directory."""
    return any(part in _EXCLUDE_DIRS for part in path.parts)


def collect_imports(root: Path, self_path: Path | None = None) -> set[str]:
    """
    Recursively walk *root* and collect every top-level imported module name
    from .py and .ipynb files, skipping excluded directories.

    Parameters
    ----------
    root:
        Directory to scan.
    self_path:
        Absolute path of this script/package – excluded from scanning so the
        tool doesn't try to resolve its own imports.
    """
    names: set[str] = set()

    for py in root.rglob("*.py"):
        if _is_excluded(py.relative_to(root)):
            continue
        if self_path and py.resolve() == self_path:
            continue
        try:
            names |= imports_from_source(py.read_text(encoding="utf-8", errors="ignore"))
        except OSError:
            pass

    for nb in root.rglob("*.ipynb"):
        if _is_excluded(nb.relative_to(root)):
            continue
        names |= imports_from_notebook(nb)

    return names
