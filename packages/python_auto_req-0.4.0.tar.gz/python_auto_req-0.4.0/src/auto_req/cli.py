"""
cli.py – command-line interface for python-auto-req.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

from .scanner import collect_imports, stdlib_module_names
from .resolver import resolve_all


# ---------------------------------------------------------------------------
# requirements.txt helpers
# ---------------------------------------------------------------------------


def read_existing_requirements(path: Path) -> set[str]:
    """Return lower-cased dist names already present in *path*."""
    if not path.exists():
        return set()
    existing: set[str] = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name = re.split(r"[=<>!~\s\[;]", line)[0].lower()
        existing.add(name)
    return existing


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """
    Run the scanner and optionally write requirements.txt.

    Returns 0 on success, 1 on error.
    """
    parser = argparse.ArgumentParser(
        prog="auto-req",
        description=(
            "Scan .py / .ipynb project files and add discovered third-party "
            "packages to requirements.txt.\n\n"
            "Only packages explicitly imported in your source files are considered.\n"
            "Packages installed in .venv but never imported are ignored."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--dry-run",
        type=int,
        default=1,
        metavar="0|1",
        help="1 = preview only (default);  0 = write requirements.txt",
    )
    parser.add_argument(
        "--auto",
        action="store_true",
        help="Always pick the top PyPI match for unknown modules (no prompts)",
    )
    parser.add_argument(
        "--dir",
        type=Path,
        default=Path("."),
        metavar="DIR",
        help="Project root to scan  (default: current directory)",
    )
    parser.add_argument(
        "--requirements",
        type=Path,
        default=Path("requirements.txt"),
        metavar="FILE",
        help="Path to requirements.txt  (default: ./requirements.txt)",
    )
    args = parser.parse_args(argv)

    dry_run: bool = bool(args.dry_run)
    root: Path = args.dir.resolve()
    req_path: Path = args.requirements

    print(f"Scanning : {root}")
    print(f"Dry-run  : {dry_run}  (pass --dry-run 0 to write)")
    print(f"Mode     : {'auto' if args.auto else 'interactive'}\n")

    # ---- scan source files (excludes .venv and other non-project dirs) ----
    stdlib = stdlib_module_names()
    all_imports = collect_imports(root)

    if not all_imports:
        print("No imports detected.")
        return 0

    print(f"Imports found in project files: {len(all_imports)}")

    # ---- resolve module names → dist names --------------------------------
    resolved, skipped = resolve_all(all_imports, stdlib, args.auto)

    # ---- compare against existing requirements.txt ------------------------
    existing = read_existing_requirements(req_path)
    new_pkgs = {
        dist: ver
        for dist, ver in resolved.items()
        if dist.lower() not in existing
    }

    print(f"\nPackages resolved : {len(resolved)}")
    print(f"Already in req    : {len(resolved) - len(new_pkgs)}")
    print(f"New to add        : {len(new_pkgs)}")
    if skipped:
        print(f"Skipped (manual)  : {len(skipped)}  -> {', '.join(skipped)}")

    if not new_pkgs:
        print("\nrequirements.txt is already up-to-date.")
        return 0

    lines_to_add = [
        f"{dist}=={ver}" if ver else dist
        for dist, ver in sorted(new_pkgs.items())
    ]

    print("\nPackages to add:")
    for line in lines_to_add:
        print(f"  + {line}")

    if dry_run:
        print("\n[dry-run] No files were modified. Pass --dry-run 0 to apply.")
        return 0

    # ---- write ------------------------------------------------------------
    with req_path.open("a", encoding="utf-8") as fh:
        if req_path.exists() and req_path.stat().st_size > 0:
            fh.write("\n")
        fh.write("\n".join(lines_to_add) + "\n")

    print(f"\nWritten to {req_path}  ({len(lines_to_add)} package(s) added).")

    # ---- offer pip install ------------------------------------------------
    try:
        answer = input(f"\nRun 'pip install -r {req_path}' now? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    if answer == "y":
        print()
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", str(req_path)],
            check=False,
        )
        return result.returncode
    else:
        print("Skipped. Run it manually when ready.")

    return 0
