"""
resolver.py – map imported module names to PyPI distribution names.

Resolution order for each module:
  1. Installed packages in the active Python environment  (no I/O)
  2. PyPI search + interactive prompt  (or --auto for unattended use)
"""

from __future__ import annotations

import sys
import urllib.parse
import urllib.request
import re
from importlib.metadata import PackageNotFoundError, packages_distributions
from importlib.metadata import version as pkg_version


# ---------------------------------------------------------------------------
# Confident resolution: installed env only
# ---------------------------------------------------------------------------


def resolve_from_env(module: str) -> str | None:
    """
    Return the distribution name for *module* if it is installed in the
    current environment, else None.

    This uses only packages that are actually importable – it never surfaces
    packages that happen to be in .venv but aren't referenced in project files.
    The caller is responsible for only passing modules that were found by
    scanning source files.
    """
    dists = packages_distributions().get(module)
    return dists[0] if dists else None


def installed_version(dist: str) -> str:
    """Return the installed version of *dist*, or '' if not installed."""
    try:
        return pkg_version(dist)
    except PackageNotFoundError:
        return ""


# ---------------------------------------------------------------------------
# PyPI search + n-gram ranking
# ---------------------------------------------------------------------------


def search_pypi(query: str, n: int = 5) -> list[str]:
    """
    Return up to *n* package names from a PyPI simple search for *query*.
    Returns an empty list on any network/parse failure.
    """
    url = "https://pypi.org/search/?" + urllib.parse.urlencode({"q": query})
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": "python-auto-req/1.0 (github.com/Amit-Roy/python-auto-req)"}
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
    except Exception as exc:
        print(f"      [warn] PyPI search failed: {exc}")
        return []

    names = re.findall(
        r'class="package-snippet__name"[^>]*>\s*([^\s<]+)\s*<', html
    )
    return names[:n]


def ngram_score(a: str, b: str, n: int = 2) -> float:
    """
    Character n-gram Jaccard similarity in [0, 1].
    Higher = more similar.
    """
    a, b = a.lower(), b.lower()
    if not a or not b:
        return 0.0

    def ngrams(s: str) -> set[str]:
        return {s[i : i + n] for i in range(len(s) - n + 1)} if len(s) >= n else {s}

    sa, sb = ngrams(a), ngrams(b)
    union = sa | sb
    return len(sa & sb) / len(union) if union else 0.0


def rank_candidates(module: str, candidates: list[str]) -> list[str]:
    """Re-rank *candidates* by n-gram similarity to *module*, best first."""
    return sorted(candidates, key=lambda c: -ngram_score(module, c))


# ---------------------------------------------------------------------------
# Interactive / auto prompt
# ---------------------------------------------------------------------------


class StopResolution(Exception):
    """Raised when the user chooses to abort the resolution loop."""


def _prompt(
    module: str,
    candidates: list[str],
    auto_session: bool,
) -> tuple[str | None, bool]:
    """
    Present the resolution menu for one unknown *module*.

    Returns
    -------
    (dist_name, new_auto_session)
        dist_name is None  → skip this module
    Raises StopResolution when user presses [q].
    """
    if auto_session:
        pick = candidates[0] if candidates else module
        print(f"      [auto] '{module}' -> '{pick}'")
        return pick, True

    print(f"\n  Unrecognised module: '{module}'")
    if candidates:
        print("  Top PyPI matches:")
        for i, name in enumerate(candidates, 1):
            print(f"    [{i}] {name}  (similarity {ngram_score(module, name):.2f})")
    else:
        print("  No PyPI results found.")

    print()
    print("  [1-5] select a match above")
    print("  [a]   auto-select top match for ALL remaining unknowns")
    print("  [m]   enter the correct dist name manually")
    print("  [s]   skip  (omit from requirements, continue)")
    print("  [q]   quit  (stop resolution now)")
    print()

    while True:
        try:
            choice = input("  Your choice: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            raise StopResolution

        if choice == "q":
            raise StopResolution

        if choice == "s":
            return None, False

        if choice == "m":
            try:
                name = input("  Dist name: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                raise StopResolution
            return (name or None), False

        if choice == "a":
            pick = candidates[0] if candidates else module
            print(f"  [auto] '{module}' -> '{pick}'")
            return pick, True

        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(candidates):
                return candidates[idx], False
            print(f"  Invalid number. Pick 1–{len(candidates)}.")
            continue

        print("  Unknown choice. Try again.")


def resolve_via_pypi(
    module: str,
    auto_mode: bool,
) -> tuple[str | None, bool]:
    """
    Search PyPI for *module* and resolve via prompt (or auto).

    Returns
    -------
    (dist_name, updated_auto_mode)
        dist_name is None → user chose to skip
    Raises StopResolution on quit.
    """
    if not auto_mode:
        print(f"\n  Searching PyPI for '{module}'...", end=" ", flush=True)

    raw = search_pypi(module)
    candidates = rank_candidates(module, raw) if raw else []

    if not auto_mode:
        print(f"{len(candidates)} result(s)." if candidates else "no results.")

    return _prompt(module, candidates, auto_mode)


# ---------------------------------------------------------------------------
# Full resolution pipeline
# ---------------------------------------------------------------------------


def resolve_all(
    module_names: set[str],
    stdlib: set[str],
    auto_mode: bool,
) -> tuple[dict[str, str], list[str]]:
    """
    Resolve *module_names* (found by scanning project files) to a dict of
    ``{dist_name: version}``.

    Modules that are part of the stdlib or Python builtins are silently
    ignored.  Unknown modules go through PyPI search + user interaction.

    Parameters
    ----------
    module_names:
        Top-level module names collected from project source files only.
    stdlib:
        Set of stdlib module names (from ``scanner.stdlib_module_names()``).
    auto_mode:
        When True, always pick the top PyPI result without prompting.

    Returns
    -------
    packages:
        ``{dist_name: installed_version_or_empty}``
    skipped:
        Module names the user chose to skip or that couldn't be resolved.
    """
    packages: dict[str, str] = {}
    skipped: list[str] = []
    auto_session = auto_mode

    for module in sorted(module_names):
        if module in stdlib or module in sys.builtin_module_names:
            continue

        # Fast path: installed in current env → confident mapping
        dist = resolve_from_env(module)

        if dist is None:
            # Slow path: PyPI search + user input
            try:
                dist, auto_session = resolve_via_pypi(module, auto_session)
            except StopResolution:
                print("\n  Resolution stopped. Remaining modules skipped.")
                break

        if dist is None:
            skipped.append(module)
            continue

        packages[dist] = installed_version(dist)

    return packages, skipped
