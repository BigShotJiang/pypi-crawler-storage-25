"""Allow running as: python -m auto_req"""
from .cli import main
import sys

sys.exit(main())
