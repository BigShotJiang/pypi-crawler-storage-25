"""Kernel-ready compressed KV page layout research utilities.

v0.8.0 introduces a stable packed-page representation that is meant to
prepare tiny-turboquant for future fused dequant + attention kernels.  The
reference paths in this module are intentionally PyTorch implementations: they
validate layout, memory accounting, and rotate-Q correctness, but they do not
claim production inference acceleration.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import torch

from .attention import attention_similarity, dense_attention, streaming_paged_attention
from .attention_perf import _resolve_device, _resolve_dtype, _runtime_warnings, _sync
from .bitpack import pack_indices, tensor_nbytes, unpack_indices
from .kv_presets import resolve_kv_cache_preset
from .quantizer import TurboQuantMSE


@dataclass
class CompressedKVPage:
    """A single compressed K/V page.

    The packed tensors are flat uint8 byte streams. ``key_index_shape`` and
    ``value_index_shape`` describe the low-bit index tensors before packing.
    K indices represent *rotated* K values, so a future attention kernel can
    rotate Q once and consume K codebook values directly.
    """

    layer_id: int
    page_id: int
    page_start: int
    page_length: int
    key_packed: torch.Tensor
    value_packed: torch.Tensor
    key_index_shape: Tuple[int, ...]
    value_index_shape: Tuple[int, ...]
    key_bits: int
    value_bits: int

    @property
    def payload_bytes(self) -> int:
        return int(tensor_nbytes(self.key_packed) + tensor_nbytes(self.value_packed))

    @property
    def key_payload_bytes(self) -> int:
        return int(tensor_nbytes(self.key_packed))

    @property
    def value_payload_bytes(self) -> int:
        return int(tensor_nbytes(self.value_packed))

    def to_dict(self, include_payload_tensors: bool = False) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "layer_id": self.layer_id,
            "page_id": self.page_id,
            "page_start": self.page_start,
            "page_length": self.page_length,
            "key_index_shape": list(self.key_index_shape),
            "value_index_shape": list(self.value_index_shape),
            "key_bits": self.key_bits,
            "value_bits": self.value_bits,
            "key_payload_bytes": self.key_payload_bytes,
            "value_payload_bytes": self.value_payload_bytes,
            "payload_bytes": self.payload_bytes,
        }
        if include_payload_tensors:
            d["key_packed"] = self.key_packed.detach().cpu().tolist()
            d["value_packed"] = self.value_packed.detach().cpu().tolist()
        return d


@dataclass
class LayoutMemoryReport:
    """Memory accounting for a compressed KV page layout."""

    fp16_kv_bytes: int
    compressed_payload_bytes: int
    key_payload_bytes: int
    value_payload_bytes: int
    codebook_bytes: int
    rotation_metadata_bytes: int
    page_table_bytes: int
    actual_total_bytes: int
    effective_compression_ratio: float
    payload_compression_ratio: float
    effective_memory_saved_pct: float
    payload_memory_saved_pct: float
    page_count: int
    page_size: int
    note: str = (
        "Effective memory includes payload, codebooks, rotation metadata, and a conservative page-table estimate. "
        "This is layout accounting, not a production allocator measurement."
    )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CompressedKVPageTable:
    """Kernel-ready compressed page table for one layer of K/V tensors."""

    pages: List[CompressedKVPage]
    key_quantizer: TurboQuantMSE
    value_quantizer: TurboQuantMSE
    dense_shape: Tuple[int, int, int, int]
    page_size: int
    layer_id: int = 0
    dtype_bytes: int = 2
    frozen_calibration: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dense(
        cls,
        key: torch.Tensor,
        value: torch.Tensor,
        *,
        key_bits: int = 6,
        value_bits: int = 4,
        page_size: int = 128,
        layer_id: int = 0,
        seed: int = 0,
        dtype_bytes: int = 2,
    ) -> "CompressedKVPageTable":
        if key.shape != value.shape:
            raise ValueError("key and value must have the same shape")
        if key.ndim != 4:
            raise ValueError("key/value must be shaped (B, H, S, D)")
        page_size = int(max(1, page_size))
        b, h, s, d = [int(x) for x in key.shape]
        q_key = TurboQuantMSE.build(d, bits=key_bits, device=key.device, seed=seed, dtype=torch.float32)
        q_value = TurboQuantMSE.build(d, bits=value_bits, device=value.device, seed=seed + 997, dtype=torch.float32)

        # Quantizers operate in float; retain original device and convert views safely.
        key_f = key.float()
        value_f = value.float()
        pages: List[CompressedKVPage] = []
        for page_id, start in enumerate(range(0, s, page_size)):
            end = min(start + page_size, s)
            k_page = key_f[:, :, start:end, :].contiguous()
            v_page = value_f[:, :, start:end, :].contiguous()
            k_idx = q_key.quant(k_page)
            v_idx = q_value.quant(v_page)
            k_packed, k_shape = pack_indices(k_idx, key_bits)
            v_packed, v_shape = pack_indices(v_idx, value_bits)
            pages.append(
                CompressedKVPage(
                    layer_id=layer_id,
                    page_id=page_id,
                    page_start=start,
                    page_length=end - start,
                    key_packed=k_packed.contiguous(),
                    value_packed=v_packed.contiguous(),
                    key_index_shape=tuple(k_shape),
                    value_index_shape=tuple(v_shape),
                    key_bits=int(key_bits),
                    value_bits=int(value_bits),
                )
            )
        return cls(
            pages=pages,
            key_quantizer=q_key,
            value_quantizer=q_value,
            dense_shape=(b, h, s, d),
            page_size=page_size,
            layer_id=int(layer_id),
            dtype_bytes=int(dtype_bytes),
            frozen_calibration=True,
            metadata={
                "layout": "rotated-key-packed-pages",
                "key_bits": int(key_bits),
                "value_bits": int(value_bits),
                "seed": int(seed),
            },
        )

    @property
    def page_count(self) -> int:
        return len(self.pages)

    @property
    def seq_len(self) -> int:
        return int(self.dense_shape[2])

    @property
    def head_dim(self) -> int:
        return int(self.dense_shape[3])

    def freeze_calibration(self) -> None:
        self.frozen_calibration = True

    def calibrate_prefill(self, key: torch.Tensor, value: torch.Tensor) -> None:
        """Compatibility hook for future calibration flows.

        v0.8.0 uses deterministic TurboQuantMSE codebooks, so this marks the
        calibration frozen rather than mutating decode-time state.
        """
        if key.shape[-1] != self.head_dim or value.shape[-1] != self.head_dim:
            raise ValueError("prefill tensors must match the page-table head dimension")
        self.frozen_calibration = True

    def _unpack_indices(self, page: CompressedKVPage, kind: str) -> torch.Tensor:
        if kind == "key":
            return unpack_indices(page.key_packed, page.key_bits, page.key_index_shape)
        if kind == "value":
            return unpack_indices(page.value_packed, page.value_bits, page.value_index_shape)
        raise ValueError("kind must be 'key' or 'value'")

    def dequant_key_page(self, page: CompressedKVPage, *, rotated: bool = False) -> torch.Tensor:
        idx = self._unpack_indices(page, "key")
        if rotated:
            return self.key_quantizer.centroids[idx.long()]
        return self.key_quantizer.dequant(idx)

    def dequant_value_page(self, page: CompressedKVPage) -> torch.Tensor:
        idx = self._unpack_indices(page, "value")
        return self.value_quantizer.dequant(idx)

    def iter_dequantized_pages(self, *, rotated_keys: bool = False) -> Iterator[Tuple[torch.Tensor, torch.Tensor]]:
        for page in self.pages:
            yield self.dequant_key_page(page, rotated=rotated_keys), self.dequant_value_page(page)

    def to_dense(self) -> Tuple[torch.Tensor, torch.Tensor]:
        ks, vs = [], []
        for k, v in self.iter_dequantized_pages(rotated_keys=False):
            ks.append(k)
            vs.append(v)
        return torch.cat(ks, dim=2), torch.cat(vs, dim=2)

    def rotate_query(self, query: torch.Tensor) -> torch.Tensor:
        return self.key_quantizer.rotation.apply(query.float()).to(query.dtype)

    def memory_report(self) -> LayoutMemoryReport:
        b, h, s, d = self.dense_shape
        fp16_kv_bytes = int(b * h * s * d * 2 * self.dtype_bytes)
        key_payload = int(sum(p.key_payload_bytes for p in self.pages))
        value_payload = int(sum(p.value_payload_bytes for p in self.pages))
        payload = key_payload + value_payload
        qk = self.key_quantizer
        qv = self.value_quantizer
        codebook = int(
            tensor_nbytes(qk.centroids)
            + tensor_nbytes(qk.boundaries)
            + tensor_nbytes(qv.centroids)
            + tensor_nbytes(qv.boundaries)
        )
        rotation = int(
            tensor_nbytes(qk.rotation.s1)
            + tensor_nbytes(qk.rotation.s2)
            + tensor_nbytes(qk.rotation.perm)
            + tensor_nbytes(qk.rotation.inv_perm)
            + tensor_nbytes(qv.rotation.s1)
            + tensor_nbytes(qv.rotation.s2)
            + tensor_nbytes(qv.rotation.perm)
            + tensor_nbytes(qv.rotation.inv_perm)
        )
        # Conservative page-table metadata estimate: offsets, lengths, ids, byte pointers.
        page_table = int(len(self.pages) * 64)
        actual = int(payload + codebook + rotation + page_table)
        return LayoutMemoryReport(
            fp16_kv_bytes=fp16_kv_bytes,
            compressed_payload_bytes=payload,
            key_payload_bytes=key_payload,
            value_payload_bytes=value_payload,
            codebook_bytes=codebook,
            rotation_metadata_bytes=rotation,
            page_table_bytes=page_table,
            actual_total_bytes=actual,
            effective_compression_ratio=fp16_kv_bytes / max(actual, 1),
            payload_compression_ratio=fp16_kv_bytes / max(payload, 1),
            effective_memory_saved_pct=(1.0 - actual / max(fp16_kv_bytes, 1)) * 100.0,
            payload_memory_saved_pct=(1.0 - payload / max(fp16_kv_bytes, 1)) * 100.0,
            page_count=len(self.pages),
            page_size=int(self.page_size),
        )

    def to_dict(self, include_pages: bool = False) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "dense_shape": list(self.dense_shape),
            "page_size": self.page_size,
            "page_count": self.page_count,
            "layer_id": self.layer_id,
            "frozen_calibration": self.frozen_calibration,
            "metadata": dict(self.metadata),
            "memory": self.memory_report().to_dict(),
        }
        if include_pages:
            d["pages"] = [p.to_dict() for p in self.pages]
        return d


class RotatedCompressedKVCache:
    """Minimal prefill/freeze wrapper around the v0.8 compressed page table."""

    def __init__(
        self,
        *,
        key_bits: int = 6,
        value_bits: int = 4,
        page_size: int = 128,
        preset: Optional[str] = None,
        seed: int = 0,
    ) -> None:
        if preset is not None:
            cfg = resolve_kv_cache_preset(preset)
            key_bits = int(cfg.get("key_bits", key_bits))
            value_bits = int(cfg.get("value_bits", value_bits))
        self.key_bits = int(key_bits)
        self.value_bits = int(value_bits)
        self.page_size = int(page_size)
        self.seed = int(seed)
        self.tables: Dict[int, CompressedKVPageTable] = {}
        self._frozen = False

    @classmethod
    def from_preset(cls, preset: str = "balanced", **overrides: Any) -> "RotatedCompressedKVCache":
        cfg = resolve_kv_cache_preset(preset)
        return cls(
            key_bits=int(overrides.get("key_bits", cfg["key_bits"])),
            value_bits=int(overrides.get("value_bits", cfg["value_bits"])),
            page_size=int(overrides.get("page_size", 128)),
            preset=None,
            seed=int(overrides.get("seed", 0)),
        )

    def calibrate_prefill(self, key: torch.Tensor, value: torch.Tensor, layer_idx: int = 0) -> CompressedKVPageTable:
        if self._frozen and layer_idx in self.tables:
            raise RuntimeError("cache calibration is frozen; allocate a new cache or call before freeze_calibration")
        table = CompressedKVPageTable.from_dense(
            key,
            value,
            key_bits=self.key_bits,
            value_bits=self.value_bits,
            page_size=self.page_size,
            layer_id=layer_idx,
            seed=self.seed + layer_idx * 1009,
            dtype_bytes=2 if key.dtype in {torch.float16, torch.bfloat16} else key.element_size(),
        )
        self.tables[int(layer_idx)] = table
        return table

    def freeze_calibration(self) -> None:
        self._frozen = True
        for table in self.tables.values():
            table.freeze_calibration()

    def table(self, layer_idx: int = 0) -> CompressedKVPageTable:
        return self.tables[int(layer_idx)]

    def memory_report(self, layer_idx: int = 0) -> LayoutMemoryReport:
        return self.table(layer_idx).memory_report()

    def attention(self, query: torch.Tensor, layer_idx: int = 0) -> torch.Tensor:
        return compressed_page_attention_reference(query, self.table(layer_idx), rotate_query=True)


@dataclass
class LayoutBenchConfig:
    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_len: int = 1024
    head_dim: int = 64
    page_size: int = 128
    key_bits: int = 6
    value_bits: int = 4
    preset: Optional[str] = None
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    iters: Optional[int] = None
    seed: int = 123

    def __post_init__(self) -> None:
        if self.iters is not None:
            self.repeats = int(self.iters)
        if self.preset:
            cfg = resolve_kv_cache_preset(self.preset)
            self.key_bits = int(cfg["key_bits"])
            self.value_bits = int(cfg["value_bits"])


def _time_call(fn, *, device: str, warmup: int, repeats: int) -> Tuple[torch.Tensor, float]:
    out = None
    for _ in range(max(0, warmup)):
        out = fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(max(1, repeats)):
        out = fn()
    _sync(device)
    elapsed = (time.perf_counter() - t0) / max(1, repeats)
    assert out is not None
    return out, float(elapsed)


def compressed_page_attention_reference(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    rotate_query: bool = True,
) -> torch.Tensor:
    """Reference attention over the compressed page layout.

    When ``rotate_query=True``, keys are consumed in their rotated/codebook
    domain and Q is rotated once. This validates the intended read path for a
    future fused kernel. V is dequantized page-by-page in this reference path.
    """
    if rotate_query:
        q = page_table.rotate_query(query)
        pages = list(page_table.iter_dequantized_pages(rotated_keys=True))
        return streaming_paged_attention(q, pages)
    pages = list(page_table.iter_dequantized_pages(rotated_keys=False))
    return streaming_paged_attention(query, pages)


def rotate_q_attention_reference(query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, *, seed: int = 0) -> torch.Tensor:
    """Dense rotate-Q equivalence path without quantization.

    This validates: <Q, K> == <R Q, R K> for the package rotation.
    """
    d = int(key.shape[-1])
    rot = TurboQuantMSE.build(d, bits=8, device=key.device, seed=seed, dtype=torch.float32).rotation
    q_rot = rot.apply(query.float()).to(query.dtype)
    k_rot = rot.apply(key.float()).to(key.dtype)
    return dense_attention(q_rot, k_rot, value)


def run_rotate_q_check(
    *,
    batch_size: int = 1,
    heads: int = 8,
    query_len: int = 1,
    seq_len: int = 1024,
    head_dim: int = 64,
    device: str = "auto",
    dtype: str = "auto",
    seed: int = 123,
) -> Dict[str, Any]:
    requested_device = device
    requested_dtype = dtype
    resolved_device = _resolve_device(device)
    resolved_dtype = _resolve_dtype(dtype, resolved_device)
    warnings = _runtime_warnings(requested_device, resolved_device, requested_dtype, resolved_dtype)
    torch.manual_seed(int(seed))
    q = torch.randn(batch_size, heads, query_len, head_dim, device=resolved_device, dtype=resolved_dtype)
    k = torch.randn(batch_size, heads, seq_len, head_dim, device=resolved_device, dtype=resolved_dtype)
    v = torch.randn_like(k)
    dense = dense_attention(q, k, v)
    rotated = rotate_q_attention_reference(q, k, v, seed=seed)
    return {
        "version": "rotate-q-check",
        "config": {
            "batch_size": batch_size,
            "heads": heads,
            "query_len": query_len,
            "seq_len": seq_len,
            "head_dim": head_dim,
            "requested_device": requested_device,
            "device": resolved_device,
            "requested_dtype": requested_dtype,
            "dtype": str(resolved_dtype).replace("torch.", ""),
            "seed": seed,
        },
        "warnings": warnings,
        "quality": attention_similarity(dense, rotated),
        "interpretation": "Rotate-Q validates that K can be stored in rotated form and Q rotated once before attention.",
    }


def run_layout_benchmark(config: LayoutBenchConfig) -> Dict[str, Any]:
    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)
    torch.manual_seed(int(config.seed))
    q = torch.randn(config.batch_size, config.heads, config.query_len, config.head_dim, device=device, dtype=dtype)
    k = torch.randn(config.batch_size, config.heads, config.seq_len, config.head_dim, device=device, dtype=dtype)
    v = torch.randn_like(k)

    t0 = time.perf_counter()
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=config.key_bits,
        value_bits=config.value_bits,
        page_size=config.page_size,
        seed=config.seed,
        dtype_bytes=torch.empty((), dtype=dtype).element_size(),
    )
    build_seconds = time.perf_counter() - t0

    dense_out, dense_seconds = _time_call(
        lambda: dense_attention(q, k, v),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )
    ref_out, ref_seconds = _time_call(
        lambda: compressed_page_attention_reference(q, table, rotate_query=True),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )
    nonrot_out, nonrot_seconds = _time_call(
        lambda: compressed_page_attention_reference(q, table, rotate_query=False),
        device=device,
        warmup=0,
        repeats=1,
    )
    rotate_check = run_rotate_q_check(
        batch_size=config.batch_size,
        heads=config.heads,
        query_len=config.query_len,
        seq_len=config.seq_len,
        head_dim=config.head_dim,
        device=device,
        dtype=str(dtype).replace("torch.", ""),
        seed=config.seed,
    )
    mem = table.memory_report().to_dict()
    return {
        "config": {
            **asdict(config),
            "device": device,
            "dtype": str(dtype).replace("torch.", ""),
            "requested_device": requested_device,
            "requested_dtype": requested_dtype,
            "iters": int(config.repeats),
        },
        "warnings": warnings,
        "layout": table.to_dict(include_pages=False),
        "memory": mem,
        "timing": {
            "layout_build_seconds": float(build_seconds),
            "dense_attention_seconds": float(dense_seconds),
            "compressed_page_reference_seconds": float(ref_seconds),
            "compressed_page_nonrot_reference_seconds": float(nonrot_seconds),
            "note": "Reference path is Python/PyTorch and is expected to be slower than dense attention until fused kernels exist.",
        },
        "quality": {
            "compressed_page_vs_dense": attention_similarity(dense_out, ref_out),
            "nonrot_compressed_page_vs_dense": attention_similarity(dense_out, nonrot_out),
            "rotate_q_dense_equivalence": rotate_check["quality"],
        },
        "interpretation": (
            "v0.8.0 validates a kernel-ready compressed page layout and rotate-Q reference path. "
            "It prepares for fused compressed attention but does not claim production inference acceleration."
        ),
    }


def layout_markdown_report(report: Dict[str, Any]) -> str:
    mem = report["memory"]
    timing = report["timing"]
    quality = report["quality"]
    lines = [
        "# tiny-turboquant layout benchmark report",
        "",
        "## Memory",
        f"- FP16 K/V bytes: {mem['fp16_kv_bytes']}",
        f"- Compressed payload bytes: {mem['compressed_payload_bytes']}",
        f"- Actual total bytes: {mem['actual_total_bytes']}",
        f"- Payload compression ratio: {mem['payload_compression_ratio']:.4f}x",
        f"- Effective compression ratio: {mem['effective_compression_ratio']:.4f}x",
        f"- Effective memory saved: {mem['effective_memory_saved_pct']:.2f}%",
        "",
        "## Timing",
        f"- Layout build seconds: {timing['layout_build_seconds']:.6f}",
        f"- Dense attention seconds: {timing['dense_attention_seconds']:.6f}",
        f"- Compressed page reference seconds: {timing['compressed_page_reference_seconds']:.6f}",
        "",
        "## Quality",
        f"- Compressed page vs dense: {quality['compressed_page_vs_dense']}",
        f"- Rotate-Q dense equivalence: {quality['rotate_q_dense_equivalence']}",
        "",
        "## Boundary",
        "This report validates layout and correctness for future fused kernels. It does not claim production inference acceleration.",
    ]
    return "\n".join(lines) + "\n"


def save_layout_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_layout_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(layout_markdown_report(report), encoding="utf-8")
