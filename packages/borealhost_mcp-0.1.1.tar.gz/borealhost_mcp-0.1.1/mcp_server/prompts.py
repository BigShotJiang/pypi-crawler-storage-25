"""MCP prompts — guided workflow templates for agents."""

from mcp.server.fastmcp.prompts import base as prompt_base


def register(mcp):
    """Register all MCP prompts on the server instance."""

    @mcp.prompt(
        name="purchase_hosting",
        description="Step-by-step guide to purchase a BorealHost hosting plan, from plan discovery through payment to site provisioning",
    )
    def purchase_hosting(plan_slug: str = "", billing: str = "monthly") -> list[prompt_base.Message]:
        plan_hint = f'The user wants plan "{plan_slug}" with {billing} billing.' if plan_slug else "Help the user choose a plan."
        sku_hint = f'`bh_{plan_slug}_{billing}`' if plan_slug else '`bh_{{plan_slug}}_{billing}`'

        return [prompt_base.Message(
            role="user",
            content=prompt_base.TextContent(
                type="text",
                text=f"""Guide me through purchasing BorealHost hosting.

{plan_hint}

Follow these steps exactly:

1. **Discover plans**: Call `list_plans()` to show available plans with pricing.
   - Plans are in CAD. Annual billing is significantly cheaper.
   - Help me compare features: max_sites, ai_modules, free_domain, hosting_type.

2. **Create checkout**: Call `create_checkout(sku={sku_hint})`.
   - SKU format: `bh_{{plan_slug}}_{{monthly|annual}}`
   - Save the `checkout_id` and `checkout_secret` from the response.

3. **Set site slug**: Call `update_checkout(checkout_id, requested_slug="...")`.
   - Ask me what I want my site to be called.
   - Slug rules: 3-50 chars, lowercase, alphanumeric + hyphens, no leading/trailing hyphen.
   - If the slug is taken (VALIDATION_ERROR), suggest alternatives and retry.
   - Optionally set buyer_email if I want account notifications.

4. **Complete payment**: Call `complete_checkout(checkout_id)`.
   - Default: "stripe_checkout" returns a Stripe payment URL — show it to me.
   - Alternative: "stripe_payment_method" for direct card charge.

5. **Poll for completion**: Call `get_checkout_status(checkout_id)` repeatedly.
   - Poll every 5 seconds for the first minute, then every 15 seconds.
   - Stop after 10 minutes.
   - When status is "completed", the response includes an API key.

6. **CRITICAL — Save the API key**: The `api_key` field appears ONCE in the poll response.
   - Tell me the key immediately so I can store it.
   - Format: `bh_{{48 hex chars}}`
   - This key is needed for all subsequent site management.

7. **Verify**: Call `get_site_status(slug)` to confirm the site is provisioned and ready.
""",
            ),
        )]

    @mcp.prompt(
        name="setup_site",
        description="Post-purchase site setup guide: configure DNS, deploy, enable AI modules",
    )
    def setup_site(slug: str) -> list[prompt_base.Message]:
        return [prompt_base.Message(
            role="user",
            content=prompt_base.TextContent(
                type="text",
                text=f"""Help me set up my newly provisioned BorealHost site "{slug}".

Follow these steps:

1. **Check site status**: Call `get_site_status("{slug}")`.
   - Confirm the site is active and note the default domain (slug.borealhost.ai).
   - Review the plan features and available modules.

2. **Configure DNS** (if I have a custom domain):
   - Call `manage_dns("{slug}", "create", "A", "", "{{ip}}")` for the apex domain.
   - Call `manage_dns("{slug}", "create", "CNAME", "www", "{{slug}}.borealhost.ai")` for www.
   - If I need email: `manage_dns("{slug}", "create", "MX", "", "{{mail_server}}", ttl=3600)`.
   - If I need SPF: `manage_dns("{slug}", "create", "TXT", "", "v=spf1 include:... ~all")`.

3. **Deploy**: Call `deploy("{slug}")` to trigger the initial deployment.
   - This may take up to 60 seconds.

4. **Enable AI modules**: Call `list_modules("{slug}")` to see what's available.
   - Available modules: chatbot, seo, translation, content.
   - For each module I want, call `toggle_module("{slug}", "module_name")`.

5. **SSH access** (VPS/dedicated plans only):
   - Call `get_ssh_info("{slug}")` for connection details.
   - If I have an SSH key: `add_ssh_key("{slug}", "ssh-ed25519 AAAA...")`.

6. **Verify everything**: Check `get_site_status("{slug}")` one final time to confirm
   all DNS records, modules, and deployment status are correct.
""",
            ),
        )]

    @mcp.prompt(
        name="manage_dns",
        description="Guide for common DNS operations: A records, CNAME, MX, TXT/SPF, with examples",
    )
    def manage_dns_prompt(slug: str) -> list[prompt_base.Message]:
        return [prompt_base.Message(
            role="user",
            content=prompt_base.TextContent(
                type="text",
                text=f"""Help me manage DNS records for my site "{slug}".

Common operations:

**Point domain to site (A record)**:
  `manage_dns("{slug}", "create", "A", "", "IP_ADDRESS")`

**Add www subdomain (CNAME)**:
  `manage_dns("{slug}", "create", "CNAME", "www", "{slug}.borealhost.ai")`

**Set up email (MX record)**:
  `manage_dns("{slug}", "create", "MX", "", "mail.example.com", ttl=3600)`

**Add SPF for email delivery (TXT record)**:
  `manage_dns("{slug}", "create", "TXT", "", "v=spf1 include:_spf.google.com ~all")`

**Add domain verification (TXT record)**:
  `manage_dns("{slug}", "create", "TXT", "", "google-site-verification=...")`

**Add a subdomain (A or CNAME)**:
  `manage_dns("{slug}", "create", "A", "blog", "IP_ADDRESS")`
  `manage_dns("{slug}", "create", "CNAME", "shop", "shops.myplatform.com")`

**Delete a record**:
  `manage_dns("{slug}", "delete", "A", "old-subdomain")`

Supported record types: A, AAAA, CNAME, MX, TXT, SRV.

Ask me what DNS changes I need and I'll guide you through the right tool calls.
""",
            ),
        )]

    @mcp.prompt(
        name="register_domain",
        description="Domain registration guide with required WHOIS contact fields and .ca specifics",
    )
    def register_domain_prompt(domain: str = "") -> list[prompt_base.Message]:
        domain_hint = f'for "{domain}"' if domain else ""
        return [prompt_base.Message(
            role="user",
            content=prompt_base.TextContent(
                type="text",
                text=f"""Help me register a domain {domain_hint} through BorealHost.

**Step 1 — Check availability**:
  {"Call `search_domain(\"" + domain + "\")` to check if it's available and see pricing." if domain else "Ask me which domain I want, then call `search_domain(domain)`."}

**Step 2 — Collect WHOIS contact info** (all fields required):
  - first_name, last_name
  - email (registrant contact email)
  - phone (E.164 format: "+1.5145551234")
  - address1 (street address)
  - city
  - state (province/state code, e.g. "QC", "ON")
  - postal_code (e.g. "H2X 1Y4")
  - country (ISO code, default "CA")

**Step 3 — For .ca domains**, also need `ca_legal_type`:
  - "CCO" — Canadian citizen
  - "RES" — Permanent resident
  - "CCT" — Corporation (Canadian)
  - "GOV" — Government entity
  - "EDU" — Educational institution
  - "ASS" — Unincorporated association
  - "HOP" — Hospital
  - "PRT" — Partnership
  - "TDM" — Trademark holder
  - "TRD" — Trade union
  - "PLT" — Political party
  - "LAM" — Library, archive, or museum
  - "MAJ" — Her Majesty the Queen
  - "INB" — Indian band
  - "ABO" — Aboriginal peoples
  - "LGR" — Legal representative of a Canadian citizen or permanent resident

**Step 4 — Register**:
  Call `register_domain(domain, first_name, last_name, email, phone, address1, city, state, postal_code, country, period, ca_legal_type)`.

**Step 5 — Verify**:
  Call `domain_detail(domain)` to confirm registration and check DNS status.

**Pricing notes**:
  - Domain cost is charged to the active subscription.
  - Some plans include a free domain with annual billing (first domain only).
  - Standard .ca domains are ~$15 CAD/year. Prices vary by TLD.
""",
            ),
        )]

    @mcp.prompt(
        name="claim_site_key",
        description="Get an API key by proving you're running on a BorealHost container (challenge-response flow)",
    )
    def claim_site_key(site_slug: str) -> list[prompt_base.Message]:
        return [prompt_base.Message(
            role="user",
            content=prompt_base.TextContent(
                type="text",
                text=f"""I need an API key for my BorealHost site "{site_slug}". I'm running on the container.

Follow these steps exactly:

1. **Request a claim token**: Call `request_api_key("{site_slug}")`.
   - This writes a single-use claim token to the container at ~/.borealhost/.claim_token
   - The token expires in 1 hour

2. **Read the claim token from the container**:
   - Run: `cat ~/.borealhost/.claim_token`
   - This file is mode 600, owner admin — only readable from the container
   - This is the proof that you're actually running on this container

3. **Claim the API key**: Call `claim_api_key("<token-from-step-2>")`.
   - The API key is returned and automatically activated for this MCP session
   - The claim token is consumed (single-use) and the file is cleaned up
   - Store the API key securely — it is shown only once

4. **Verify**: Call `whoami()` to confirm the key is working.

After this, all authenticated tools (get_site_status, manage_dns, deploy, etc.)
will work automatically for the rest of this session.
""",
            ),
        )]
