"""MCP resources — structured reference data for agents."""

import json

from . import api_client


def register(mcp):
    """Register all MCP resources on the server instance."""

    @mcp.resource(
        "borealhost://api/errors",
        name="Error Codes",
        description="All API error codes with HTTP status, meaning, and recovery guidance",
    )
    def error_catalog() -> str:
        return json.dumps({
            "NOT_FOUND": {
                "http_status": 404,
                "meaning": "The requested resource does not exist or is not owned by this account",
                "recovery": "Check the identifier (slug, domain, key ID). Call list_subscriptions() or list_domains() to find valid identifiers.",
            },
            "FORBIDDEN": {
                "http_status": 403,
                "meaning": "Insufficient permissions — wrong scope, wrong owner, or missing checkout_secret",
                "recovery": "Check that your API key has the required scope (read/write/admin). For checkout endpoints, include the checkout_secret from the create_checkout response.",
            },
            "UNAUTHORIZED": {
                "http_status": 401,
                "meaning": "Missing or invalid API key",
                "recovery": "Set the BOREALHOST_API_KEY environment variable. If you don't have a key, call register() first. If the key was rotated, use the new key.",
            },
            "VALIDATION_ERROR": {
                "http_status": 422,
                "meaning": "Invalid input — bad email, slug format, SKU, phone number, etc.",
                "recovery": "Check the 'param' field in the error response for which field is invalid. Fix the value and retry.",
            },
            "RATE_LIMITED": {
                "http_status": 429,
                "meaning": "Too many requests from this IP or API key",
                "recovery": "Wait for the number of seconds in the Retry-After response header, then retry. Do not retry immediately.",
                "limits": {
                    "per_key": "60 requests/minute, 10,000 requests/day",
                    "registration": "5 per IP per hour",
                    "checkout_create": "10 per IP per hour",
                    "checkout_update": "30 per IP per hour",
                    "checkout_complete": "10 per IP per hour",
                    "checkout_poll": "60 per IP per minute",
                },
            },
            "INTERNAL_ERROR": {
                "http_status": 500,
                "meaning": "Server-side error",
                "recovery": "Retry with exponential backoff: wait 1s, then 2s, then 4s. Max 3 retries. If it persists, the platform may be experiencing an outage — check /api/v1/status/.",
            },
        }, indent=2)

    @mcp.resource(
        "borealhost://api/scopes",
        name="API Key Scopes",
        description="API key scope hierarchy and which tools require which scope",
    )
    def scope_catalog() -> str:
        return json.dumps({
            "read": {
                "level": 0,
                "description": "View data only — cannot modify anything",
                "tools": [
                    "whoami", "list_plans", "get_checkout_status",
                    "get_site_status", "get_metrics", "list_subscriptions",
                    "get_billing_portal", "get_ssh_info", "list_files",
                    "read_file", "get_logs", "list_domains", "search_domain",
                    "domain_detail", "list_modules",
                ],
            },
            "write": {
                "level": 1,
                "description": "Modify resources — includes all read permissions",
                "tools": [
                    "register", "manage_dns", "deploy", "create_snapshot",
                    "update_account", "rotate_key", "add_ssh_key",
                    "write_file", "upload_file", "delete_file",
                    "register_domain", "toggle_module",
                ],
            },
            "admin": {
                "level": 2,
                "description": "Destructive operations — includes all read+write permissions",
                "tools": [
                    "scale", "decommission", "delete_account",
                ],
            },
            "none": {
                "level": -1,
                "description": "No authentication required",
                "tools": [
                    "list_plans", "create_checkout", "update_checkout",
                    "complete_checkout", "get_checkout_status",
                ],
            },
        }, indent=2)

    @mcp.resource(
        "borealhost://api/enums",
        name="Enum Values",
        description="All valid enum values for API parameters (checkout status, DNS types, log types, plan tracks, etc.)",
    )
    def enum_catalog() -> str:
        return json.dumps({
            "checkout_status": {
                "values": ["not_ready", "ready", "awaiting_payment", "in_progress", "completed", "canceled", "failed"],
                "terminal": ["completed", "canceled", "failed"],
                "description": "Checkout session lifecycle states",
            },
            "dns_record_type": {
                "values": ["A", "AAAA", "CNAME", "MX", "TXT", "SRV"],
                "description": "Supported DNS record types",
            },
            "dns_action": {
                "values": ["create", "delete"],
                "description": "DNS record operations",
            },
            "log_type": {
                "values": ["error", "access", "php"],
                "description": "Container log types. 'php' is only available for WordPress sites.",
            },
            "plan_track": {
                "values": ["single_site", "agency"],
                "description": "Plan categories. Use as filter in list_plans(track=...)",
            },
            "language": {
                "values": ["en", "fr"],
                "description": "Supported UI languages (English, French)",
            },
            "payment_method": {
                "values": ["stripe_checkout", "stripe_payment_method"],
                "description": "Payment methods for complete_checkout()",
            },
            "billing_period": {
                "values": ["monthly", "annual"],
                "description": "Billing cycle options. Annual is cheaper per month.",
            },
            "api_key_scope": {
                "values": ["read", "write", "admin"],
                "description": "API key permission levels. Higher includes lower.",
            },
            "module_name": {
                "values": ["chatbot", "seo", "translation", "content"],
                "description": "Available AI modules for toggle_module()",
            },
            "ssh_key_type": {
                "values": ["ssh-ed25519", "ssh-rsa", "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521"],
                "description": "Supported SSH public key types for add_ssh_key()",
            },
            "billing_portal_flow": {
                "values": ["", "payment_method_update"],
                "description": "Optional flow parameter for get_billing_portal(). Empty for default portal.",
            },
            "ca_legal_type": {
                "values": ["CCO", "RES", "CCT", "GOV", "EDU", "ASS", "HOP", "PRT", "TDM", "TRD", "PLT", "LAM", "MAJ", "INB", "ABO", "LGR"],
                "description": "CIRA legal types for .ca domain registration. CCO=citizen, RES=resident, CCT=corporation, etc.",
            },
        }, indent=2)

    @mcp.resource(
        "borealhost://api/response-format",
        name="Response Format",
        description="API response envelope format documentation",
    )
    def response_format() -> str:
        return json.dumps({
            "envelope": {
                "success": {
                    "ok": True,
                    "data": "object or array — the actual response payload",
                    "meta": {
                        "request_id": "uuid — unique per request, useful for support",
                        "timestamp": "iso8601 — server time when response was generated",
                    },
                },
                "error": {
                    "ok": False,
                    "error": {
                        "code": "ERROR_CODE — machine-readable (see borealhost://api/errors)",
                        "message": "Human-readable description of what went wrong",
                        "param": "field_name or null — which input field caused the error",
                    },
                    "meta": {
                        "request_id": "uuid",
                        "timestamp": "iso8601",
                    },
                },
            },
            "notes": [
                "MCP tools unwrap the envelope automatically — you receive 'data' directly on success",
                "On API error, tools raise an exception with the error code and message",
                "The request_id is useful when contacting support about a specific error",
                "Rate limit responses include Retry-After header with seconds to wait",
            ],
            "rate_limit_headers": {
                "X-RateLimit-Limit": "Maximum requests per window",
                "X-RateLimit-Remaining": "Requests remaining in current window",
                "X-RateLimit-Reset": "Unix timestamp when the window resets",
            },
        }, indent=2)

    @mcp.resource(
        "borealhost://plans",
        name="Plan Catalog",
        description="Live plan catalog with current pricing — fetched from the BorealHost API",
    )
    def plan_catalog() -> str:
        try:
            plans = api_client.list_plans()
            return json.dumps(plans, indent=2)
        except Exception as e:
            return json.dumps({
                "error": f"Could not fetch plans: {e}",
                "fallback": "Use the list_plans() tool instead, which provides the same data.",
            })
