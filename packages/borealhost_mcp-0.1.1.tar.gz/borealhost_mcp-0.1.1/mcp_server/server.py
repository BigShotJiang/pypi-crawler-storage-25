"""BorealHost MCP server — FastMCP implementation.

Exposes BorealHost hosting operations as MCP tools for AI agents.
Full self-service: register → explore plans → checkout → provision → manage.
"""

from pathlib import Path

from mcp.server.fastmcp import FastMCP

from . import api_client

_INSTRUCTIONS = (Path(__file__).parent / "instructions.md").read_text()

mcp = FastMCP(
    "BorealHost",
    instructions=_INSTRUCTIONS,
    host="0.0.0.0",
    port=8100,
)


# ── Registration & Identity ──

@mcp.tool()
def register(name: str = "Agent Key", email: str = "") -> dict:
    """Register a new agent account and get an API key.

    No authentication needed. The returned API key grants read+write access
    to all BorealHost API endpoints. Store it securely — it cannot be
    retrieved again.

    The key is automatically activated for this session — all subsequent
    tool calls will use it. No extra configuration needed.

    If no email is provided, a synthetic agent identity is created
    (agent-{uuid}@api.borealhost.ai). If an email is provided, it links
    to an existing or new human account.

    Args:
        name: Human-readable name for this API key (default: "Agent Key")
        email: Optional email to link to a human account

    Returns:
        {"api_key": "bh_...", "key_id": "uuid", "prefix": "bh_...",
         "scopes": ["read", "write"], "account_id": "uuid",
         "message": "Store this API key securely..."}

    Errors:
        RATE_LIMITED: Max 5 registrations per IP per hour
        VALIDATION_ERROR: Invalid email format
    """
    result = api_client.register(email=email or None, name=name)
    # Auto-activate the key for this session
    if result and result.get('api_key'):
        api_client.set_session_key(result['api_key'])
    return result


@mcp.tool()
def set_api_key(api_key: str) -> dict:
    """Set your BorealHost API key for this session.

    Call this if you already have an API key (from a previous registration,
    checkout completion, or the BorealHost panel). All subsequent tool calls
    will use this key for authentication.

    No need to call this after register() — the key is set automatically.

    Args:
        api_key: Your BorealHost API key (format: bh_<48 hex chars>)

    Returns:
        {"success": true, "message": "API key set for this session",
         "key_prefix": "bh_..."}
    """
    if not api_key or not api_key.startswith('bh_'):
        return {"success": False, "error": "Invalid key format. Keys start with 'bh_'."}
    api_client.set_session_key(api_key)
    # Verify the key works
    try:
        info = api_client.whoami()
        return {
            "success": True,
            "message": "API key set and verified for this session",
            "key_prefix": api_key[:10] + "...",
            "account": info.get("account", {}),
        }
    except Exception:
        # Key is set even if verification fails — might be a network issue
        return {
            "success": True,
            "message": "API key set for this session (verification skipped)",
            "key_prefix": api_key[:10] + "...",
        }


@mcp.tool()
def whoami() -> dict:
    """Check the current API key's account info, scopes, and site count.

    Requires: BOREALHOST_API_KEY env var (read scope).

    Returns:
        {"user": {"id": "uuid", "email": "...", "date_joined": "iso8601"},
         "api_key": {"id": "uuid", "name": "...", "prefix": "bh_...",
                     "scopes": ["read", "write"], "created_at": "iso8601"},
         "account": {"sites": 2, "active_subscriptions": 1}}

    Errors:
        UNAUTHORIZED: Missing or invalid API key
    """
    return api_client.whoami()


@mcp.tool()
def request_api_key(site_slug: str) -> dict:
    """Request an API key for a site you are running on (challenge-response).

    This starts a two-step verification flow:
    1. A claim token is written to your container at ~/.borealhost/.claim_token
       (mode 600, owner admin — only readable if you're on the container)
    2. Read that file and call claim_api_key(token) within 1 hour

    This proves you have access to the container without storing any secrets
    on disk permanently. The claim token is single-use and ephemeral.

    No authentication needed — the proof is reading the file from the container.

    Args:
        site_slug: The site identifier (your BorealHost site slug)

    Returns:
        {"status": "pending", "site_slug": "my-site",
         "expires_in_seconds": 3600, "claim_path": "~/.borealhost/.claim_token",
         "instructions": "Read the claim token and call claim_api_key()..."}

    Errors:
        VALIDATION_ERROR: Unknown site slug or no active subscription
        RATE_LIMITED: Too many pending claim tokens
    """
    return api_client.request_api_key(site_slug)


@mcp.tool()
def claim_api_key(claim_token: str) -> dict:
    """Claim an API key using a claim token from the container.

    After calling request_api_key(), read the claim token from
    ~/.borealhost/.claim_token on your container and pass it here.

    The token is single-use — once claimed, it cannot be used again.
    The API key is automatically activated for this MCP session.

    Args:
        claim_token: The claim token string read from the container file

    Returns:
        {"api_key": "bh_...", "key_prefix": "bh_...",
         "site_slug": "my-site", "scopes": ["read", "write"],
         "message": "API key created and activated..."}

    Errors:
        VALIDATION_ERROR: Invalid, expired, or already-claimed token
    """
    result = api_client.claim_api_key(claim_token)
    # Auto-activate the key for this session
    if result and result.get('api_key'):
        api_client.set_session_key(result['api_key'])
    return result


# ── Plan Discovery ──

@mcp.tool()
def list_plans(track: str = "", include_deprecated: bool = False) -> list:
    """List available hosting plans with pricing and resources.

    No authentication needed.

    Args:
        track: Filter by plan track. Valid values: "single_site", "agency".
               Leave empty to list all tracks.
        include_deprecated: Include deprecated plans (default: false)

    Returns:
        [{"slug": "site_starter", "name": "Starter", "track": "single_site",
          "hosting_type": "shared", "price": {"monthly": 5, "annual": 2, "currency": "CAD"},
          "resources": null, "features": {"max_sites": 1, "ai_modules": [...],
          "ai_agents": [], "free_domain_annual": false}}, ...]
    """
    return api_client.list_plans(include_deprecated=include_deprecated, track=track or None)


# ── ACP Checkout (Purchase Flow) ──

@mcp.tool()
def create_checkout(sku: str) -> dict:
    """Start a new checkout session to purchase a hosting plan.

    No authentication needed. After creating, call update_checkout to set
    buyer info, then complete_checkout to pay.

    Args:
        sku: Plan SKU in format bh_{plan_slug}_{monthly|annual}.
             Examples: "bh_site_starter_monthly", "bh_site_pro_annual",
             "bh_site_managed_monthly", "bh_site_business_annual".
             Call list_plans() to discover all available plan slugs.

    Returns:
        {"id": "uuid", "sku": "bh_site_starter_monthly",
         "plan_slug": "site_starter", "billing_period": "monthly",
         "status": "not_ready", "buyer_email": "", "requested_slug": "",
         "created_at": "iso8601", "checkout_secret": "base64-token"}

    Errors:
        VALIDATION_ERROR: Invalid SKU format or unknown plan
        RATE_LIMITED: Max 10 checkouts per IP per hour
    """
    return api_client.create_checkout(sku)


@mcp.tool()
def update_checkout(checkout_id: str, buyer_email: str = "", requested_slug: str = "") -> dict:
    """Set buyer email and desired site slug on a checkout session.

    The checkout must be in "not_ready" status. Setting requested_slug
    transitions status to "ready" (required before completing).

    Args:
        checkout_id: Checkout session ID from create_checkout
        buyer_email: Optional email — if omitted, a synthetic agent identity
                     (agent-{uuid}@api.borealhost.ai) is created at completion
        requested_slug: Desired site identifier. Must be 3-50 chars, lowercase
                        alphanumeric + hyphens, cannot start/end with hyphen.
                        Must be globally unique.

    Returns:
        {"id": "uuid", "sku": "...", "plan_slug": "...",
         "billing_period": "monthly", "status": "ready",
         "buyer_email": "...", "requested_slug": "my-site",
         "created_at": "iso8601"}

    Errors:
        VALIDATION_ERROR: Invalid slug format or slug already taken
        FORBIDDEN: Missing checkout_secret
        NOT_FOUND: Unknown checkout_id
    """
    return api_client.update_checkout(checkout_id, buyer_email or None, requested_slug or None)


@mcp.tool()
def complete_checkout(checkout_id: str, payment_method: str = "stripe_checkout", payment_method_id: str = "") -> dict:
    """Complete checkout with payment and start site provisioning.

    The checkout must be in "ready" status.

    Two payment methods:
    - "stripe_checkout" (default): Returns a Stripe-hosted payment URL.
      Present this URL to the human user. Then poll get_checkout_status()
      until status becomes "completed". The API key appears in the first
      poll after payment (shown once, then cleared).
    - "stripe_payment_method": Charges a Stripe PaymentMethod directly.
      Requires payment_method_id. On success, returns the API key immediately.

    Args:
        checkout_id: Checkout session ID
        payment_method: "stripe_checkout" or "stripe_payment_method"
        payment_method_id: Stripe PaymentMethod ID (pm_...). Required only
                           for "stripe_payment_method".

    Returns (stripe_checkout):
        {"id": "uuid", "status": "awaiting_payment",
         "stripe_checkout_url": "https://checkout.stripe.com/c/pay/...",
         "message": "Open the stripe_checkout_url to complete payment..."}

    Returns (stripe_payment_method):
        {"id": "uuid", "status": "completed", "api_key": "bh_...",
         "api_key_message": "Store this API key securely...",
         "subscription_id": "uuid", "provisioning_job_id": "uuid"}

    Errors:
        VALIDATION_ERROR: Missing payment_method_id for stripe_payment_method
        FORBIDDEN: Checkout not in "ready" status
    """
    result = api_client.complete_checkout(checkout_id, payment_method, payment_method_id or None)
    # Auto-activate key if direct payment succeeded
    if result and result.get('api_key'):
        api_client.set_session_key(result['api_key'])
    return result


@mcp.tool()
def get_checkout_status(checkout_id: str) -> dict:
    """Poll a checkout session for status updates.

    Call this after complete_checkout to track payment and provisioning.

    Polling strategy:
    - First 60 seconds: every 5 seconds
    - After 60 seconds: every 15 seconds
    - Stop after 10 minutes if not completed

    Checkout statuses (in order):
    - "not_ready": Missing required fields (slug)
    - "ready": All fields set, awaiting payment
    - "awaiting_payment": Stripe checkout page opened, waiting for human
    - "in_progress": Payment received, site being provisioned
    - "completed": Site ready — API key included (shown once, then cleared)
    - "canceled": Checkout was abandoned
    - "failed": Payment or provisioning failed

    Terminal statuses: "completed", "canceled", "failed".

    Args:
        checkout_id: Checkout session ID

    Returns (when completed):
        {"id": "uuid", "status": "completed", "api_key": "bh_...",
         "api_key_message": "Store this API key securely...",
         "subscription_id": "uuid", "completed_at": "iso8601"}

    Note: The api_key field appears ONCE in the first poll after completion,
    then is permanently cleared. Store it immediately.
    """
    result = api_client.get_checkout(checkout_id)
    # Auto-activate key if checkout completed and key is present
    if result and result.get('api_key'):
        api_client.set_session_key(result['api_key'])
    return result


# ── Site Management ──

@mcp.tool()
def get_site_status(slug: str) -> dict:
    """Get detailed status of a hosted site including resources, domains, and modules.

    Requires: API key with read scope.

    Args:
        slug: Site identifier (the slug chosen during checkout)

    Returns:
        {"slug": "my-site", "plan": "site_starter", "status": "active",
         "domains": ["my-site.borealhost.ai"], "modules": {...},
         "resources": {"memory_mb": 512, "cpu_cores": 1, "disk_gb": 10},
         "created_at": "iso8601"}

    Errors:
        NOT_FOUND: Unknown slug or not owned by this account
    """
    return api_client.get_site(slug)


@mcp.tool()
def manage_dns(slug: str, action: str, record_type: str, subdomain: str = "", value: str = "", ttl: int = 3600) -> dict:
    """Create or delete DNS records for a site.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        action: "create" or "delete"
        record_type: "A", "AAAA", "CNAME", "MX", "TXT", or "SRV"
        subdomain: Subdomain part (e.g. "www", "mail"). Leave empty for
                   the apex/root domain.
        value: Record value. Required for "create". Examples:
               A: "1.2.3.4", CNAME: "example.com", MX: "mail.example.com",
               TXT: "v=spf1 include:_spf.google.com ~all"
        ttl: Time to live in seconds (default: 3600)

    Returns:
        {"success": true, "record": {"type": "A", "subdomain": "www",
         "value": "1.2.3.4", "ttl": 3600}}

    Errors:
        VALIDATION_ERROR: Missing value for create, invalid record type
        NOT_FOUND: Unknown slug
    """
    return api_client.manage_dns(slug, action, record_type, subdomain, value, ttl)


@mcp.tool()
def deploy(slug: str) -> dict:
    """Trigger a deployment for a site.

    Requires: API key with write scope. This may take up to 60 seconds.

    Args:
        slug: Site identifier

    Returns:
        {"success": true, "message": "Deployment triggered"}

    Errors:
        NOT_FOUND: Unknown slug
    """
    return api_client.deploy(slug)


@mcp.tool()
def install_app(slug: str, template: str, app_name: str, db_type: str = "none", domain: str = "", display_name: str = "") -> dict:
    """Install an app template on a VPS/Cloud site.

    Starts a background installation. Poll get_app_status() for progress.

    Requires: API key with write scope. VPS or Cloud plan only.

    Args:
        slug: Site identifier
        template: App template slug. Available: django, laravel, nextjs, nodejs,
                  nuxtjs, rails, static, forge
        app_name: Short name for the app (2-50 chars, lowercase alphanumeric + hyphens).
                  Used as subdomain: {app_name}.{site_domain}
        db_type: Database type. "none", "mysql", or "postgresql" (depends on template)
        domain: Custom domain override (default: {app_name}.{site_domain})
        display_name: Human-friendly name (default: derived from app_name)

    Returns:
        {"id": "uuid", "app_name": "forge", "status": "installing",
         "message": "Installation started. Poll for progress."}

    Errors:
        FORBIDDEN: Plan does not support apps (shared plans)
        VALIDATION_ERROR: Invalid template, app_name, or duplicate name
    """
    return api_client.install_app(slug, template, app_name, db_type, domain, display_name)


@mcp.tool()
def get_app_status(slug: str, app_id: str) -> dict:
    """Get app installation status and log.

    Poll this after install_app() to track progress.

    Requires: API key with read scope.

    Args:
        slug: Site identifier
        app_id: App ID from install_app() response

    Returns:
        {"id": "uuid", "app_name": "forge", "status": "running"|"installing"|"failed",
         "install_log": "..."}

    Statuses: "installing", "running", "stopped", "failed", "uninstalled"
    """
    return api_client.get_app(slug, app_id)


@mcp.tool()
def list_apps(slug: str) -> dict:
    """List installed apps on a site.

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        {"apps": [{"id": "uuid", "app_name": "forge", "template_slug": "forge",
         "status": "running", "domain": "forge.mysite.borealhost.ai"}]}
    """
    return api_client.list_apps(slug)


@mcp.tool()
def list_snapshots(slug: str) -> dict:
    """List all snapshots and scheduled snapshots for a site.

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        {"snapshots": [{"id": "uuid", "name": "snap-...", "status": "completed",
         "storage_type": "local"|"b2", "size_bytes": 1234, "size_display": "1.2 Mo",
         "created_at": "iso8601"}], "scheduled": [...]}
    """
    return api_client.list_snapshots(slug)


@mcp.tool()
def create_snapshot(slug: str, description: str = "") -> dict:
    """Create a local container snapshot (async).

    Runs in background — returns immediately with status "creating".
    Poll list_snapshots() to check when status becomes "completed" or "failed".

    Available for VPS, dedicated, and cloud plans (any plan with max_snapshots > 0).
    Local snapshots are stored on the host disk and count against disk quota.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        description: Optional description (max 200 chars)

    Returns:
        {"id": "uuid", "name": "snap-...", "status": "creating",
         "storage_type": "local",
         "message": "Snapshot started. Poll list_snapshots() to check status."}

    Errors:
        VALIDATION_ERROR: Max snapshots reached or insufficient disk quota
    """
    return api_client.create_snapshot(slug, description)


@mcp.tool()
def create_b2_snapshot(slug: str, description: str = "") -> dict:
    """Create a B2 cloud-backed snapshot (zero local disk, async).

    Streams container data directly to Backblaze B2 via restic.
    No local disk impact — billed separately at cost+5%.
    Runs in background — returns immediately with status "creating".
    Poll list_snapshots() to check when status becomes "completed".
    Only available for VPS plans.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        description: Optional description (max 200 chars)

    Returns:
        {"id": "uuid", "name": "...", "status": "creating",
         "storage_type": "b2",
         "message": "B2 cloud snapshot started. Poll list_snapshots()..."}

    Errors:
        VALIDATION_ERROR: Not a VPS plan or max snapshots reached
    """
    return api_client.create_b2_snapshot(slug, description)


@mcp.tool()
def delete_snapshot(slug: str, snapshot_id: str) -> dict:
    """Delete a snapshot (local or B2).

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        snapshot_id: UUID of the snapshot to delete

    Returns:
        {"success": true, "message": "Snapshot deleted"}

    Errors:
        NOT_FOUND: Snapshot not found
    """
    return api_client.delete_snapshot(slug, snapshot_id)


@mcp.tool()
def rollback_snapshot(slug: str, snapshot_id: str) -> dict:
    """Rollback a site to a previous snapshot.

    WARNING: This is destructive. The current state of the container will be
    replaced with the snapshot contents.

    Requires: API key with admin scope.

    Args:
        slug: Site identifier
        snapshot_id: UUID of the snapshot to rollback to

    Returns:
        {"success": true, "message": "Rolled back to snapshot ..."}

    Errors:
        NOT_FOUND: Snapshot not found or not in completed state
    """
    return api_client.rollback_snapshot(slug, snapshot_id)


@mcp.tool()
def get_snapshot_usage(slug: str) -> dict:
    """Get snapshot disk usage and quota info for a site.

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        {"disk_quota_gb": 200, "max_snapshots": 5, "snapshot_count": 2,
         "local_snapshot_bytes": 1234, "b2_snapshot_bytes": 5678,
         "can_create": true}
    """
    return api_client.get_snapshot_usage(slug)


@mcp.tool()
def schedule_snapshot(slug: str, scheduled_at: str, description: str = "") -> dict:
    """Schedule a snapshot for future execution.

    Requires: API key with write scope. Max 3 pending schedules per site.

    Args:
        slug: Site identifier
        scheduled_at: ISO 8601 datetime (must be in the future)
        description: Optional description (max 200 chars)

    Returns:
        {"id": "uuid", "scheduled_at": "iso8601", "status": "scheduled"}

    Errors:
        VALIDATION_ERROR: Invalid datetime, not in future, or too many pending
    """
    return api_client.schedule_snapshot(slug, scheduled_at, description)


@mcp.tool()
def cancel_scheduled_snapshot(slug: str, schedule_id: str) -> dict:
    """Cancel a scheduled snapshot.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        schedule_id: UUID of the scheduled snapshot to cancel

    Returns:
        {"success": true, "message": "Scheduled snapshot cancelled"}

    Errors:
        NOT_FOUND: Schedule not found or already executed
    """
    return api_client.cancel_scheduled_snapshot(slug, schedule_id)


@mcp.tool()
def list_backups(slug: str) -> list:
    """List all backups for a site (automatic and manual).

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        [{"id": "uuid", "backup_type": "auto"|"manual", "status": "completed",
         "size_bytes": 1234, "size_display": "1.2 Mo",
         "timestamp": "iso8601", "notes": "..."}]
    """
    return api_client.list_backups(slug)


@mcp.tool()
def create_backup(slug: str) -> dict:
    """Create a manual backup (runs asynchronously).

    The backup starts in the background. Poll list_backups() to check status.

    Requires: API key with write scope.

    Args:
        slug: Site identifier

    Returns:
        {"id": "uuid", "status": "pending",
         "message": "Backup started. Poll list_backups() to check status."}
    """
    return api_client.create_backup(slug)


@mcp.tool()
def restore_backup(slug: str, backup_id: str) -> dict:
    """Restore a site from a backup.

    WARNING: This is destructive. The current state of the site will be
    replaced. Runs asynchronously — may take several minutes.

    Requires: API key with admin scope.

    Args:
        slug: Site identifier
        backup_id: UUID of the backup to restore from

    Returns:
        {"success": true, "message": "Restore started..."}

    Errors:
        VALIDATION_ERROR: Backup not found or not in completed state
    """
    return api_client.restore_backup(slug, backup_id)


@mcp.tool()
def get_metrics(slug: str, days: int = 7) -> dict:
    """Get traffic and performance metrics for a site.

    Requires: API key with read scope.

    Args:
        slug: Site identifier
        days: Number of days of history (1–90, default: 7)

    Returns:
        {"requests": [...], "bandwidth": [...], "errors": [...],
         "period": {"start": "iso8601", "end": "iso8601"}}

    Errors:
        NOT_FOUND: Unknown slug
        VALIDATION_ERROR: days out of range
    """
    return api_client.get_metrics(slug, days)


@mcp.tool()
def scale(slug: str, new_plan: str) -> dict:
    """Change a site's hosting plan (upgrade or downgrade).

    Requires: API key with admin scope. Best practice: create a snapshot
    before downgrading.

    Args:
        slug: Site identifier
        new_plan: Target plan slug (e.g. "site_pro", "site_managed").
                  Call list_plans() to see available plans.

    Returns:
        {"success": true, "old_plan": "site_starter", "new_plan": "site_pro",
         "message": "Plan changed successfully"}

    Errors:
        NOT_FOUND: Unknown slug
        VALIDATION_ERROR: Invalid plan slug or same plan
    """
    return api_client.scale(slug, new_plan)


@mcp.tool()
def decommission(slug: str) -> dict:
    """Delete a site and schedule resource cleanup (7-day grace period).

    WARNING: This is destructive. The site will be inaccessible immediately
    but data is retained for 7 days before permanent deletion.

    Best practice: create a snapshot before decommissioning.

    Requires: API key with admin scope.

    Args:
        slug: Site identifier

    Returns:
        {"success": true, "message": "Site scheduled for deletion",
         "grace_period_days": 7}

    Errors:
        NOT_FOUND: Unknown slug
    """
    return api_client.decommission(slug)


# ── Account Management ──

@mcp.tool()
def update_account(email: str = "", language: str = "", first_name: str = "", last_name: str = "") -> dict:
    """Update account profile fields (email, language, name).

    Requires: API key with write scope.
    Only provided (non-empty) fields are updated.

    Args:
        email: New email address
        language: Language preference — "fr" (French) or "en" (English)
        first_name: First name
        last_name: Last name

    Returns:
        {"success": true, "account": {"email": "...", "language": "fr",
         "first_name": "...", "last_name": "..."}}

    Errors:
        VALIDATION_ERROR: Invalid email format or language code
    """
    return api_client.update_account(
        email=email or None,
        language=language or None,
        first_name=first_name or None,
        last_name=last_name or None,
    )


@mcp.tool()
def delete_account() -> dict:
    """Permanently anonymize the account. Cancels subscriptions, deactivates keys.

    WARNING: This is irreversible. The account will be soft-deleted and all
    personal data anonymized. All sites will be decommissioned.

    Requires: API key with admin scope.

    Returns:
        {"success": true, "message": "Account anonymized"}
    """
    return api_client.delete_account()


@mcp.tool()
def list_subscriptions() -> list:
    """List all subscriptions with plan details, pricing, status, and site slug.

    Requires: API key with read scope.

    Returns:
        [{"id": "uuid", "plan_slug": "site_starter", "plan_name": "Starter",
          "status": "active", "billing_period": "monthly",
          "price": {"amount": 500, "currency": "cad"},
          "site_slug": "my-site", "created_at": "iso8601"}]
    """
    return api_client.list_subscriptions()


@mcp.tool()
def get_billing_portal(flow: str = "") -> dict:
    """Get a Stripe billing portal URL for managing payment methods and invoices.

    Returns a URL (not a redirect) that the human can open in a browser.

    Requires: API key with read scope.

    Args:
        flow: Optional. Set to "payment_method_update" to go directly
              to the payment method update page.

    Returns:
        {"url": "https://billing.stripe.com/p/session/..."}
    """
    return api_client.get_billing_portal(flow=flow or None)


@mcp.tool()
def rotate_key(key_id: str) -> dict:
    """Atomically rotate an API key. Old key is immediately invalidated.

    Creates a new key with the same name, scopes, and rate limits.
    The new key is returned once — store it immediately.

    Requires: API key with write scope.

    Args:
        key_id: UUID of the API key to rotate (get from whoami())

    Returns:
        {"api_key": "bh_...", "key_id": "uuid", "prefix": "bh_...",
         "scopes": ["read", "write"], "message": "Key rotated. Store securely."}

    Note: The old key stops working immediately. Update BOREALHOST_API_KEY
    right away.
    """
    return api_client.rotate_key(key_id)


# ── SSH Access ──

@mcp.tool()
def get_ssh_info(slug: str) -> dict:
    """Get SSH connection info for a VPS/dedicated site.

    Only available for VPS/dedicated plans (not shared hosting).

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        {"host": "184.107.x.x", "port": 22, "username": "admin",
         "ssh_command": "ssh admin@184.107.x.x"}

    Errors:
        NOT_FOUND: Unknown slug
        FORBIDDEN: Plan does not support SSH (shared plans)
    """
    return api_client.get_ssh_info(slug)


@mcp.tool()
def add_ssh_key(slug: str, public_key: str) -> dict:
    """Inject your SSH public key into a site's container for direct SSH access.

    The key is appended to /home/admin/.ssh/authorized_keys.
    Only available for VPS/dedicated plans.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        public_key: SSH public key string. Supported types:
                    ssh-ed25519, ssh-rsa, ecdsa-sha2-nistp256/384/521

    Returns:
        {"success": true, "message": "SSH key added",
         "ssh_command": "ssh admin@184.107.x.x"}

    Errors:
        VALIDATION_ERROR: Invalid or unsupported key format
        FORBIDDEN: Plan does not support SSH
    """
    return api_client.add_ssh_key(slug, public_key)


# ── File Management ──

@mcp.tool()
def list_files(slug: str, path: str = "") -> dict:
    """List files and directories in a site's container.

    Path scoping depends on the plan:
    - Shared plans: rooted at wp-content/ (WordPress content directory)
    - VPS/dedicated plans: full filesystem access

    Requires: API key with read scope.

    Args:
        slug: Site identifier
        path: Relative path to list (empty for root of accessible area)

    Returns:
        {"path": "/", "entries": [{"name": "index.php", "type": "file",
         "size": 1234, "modified": "iso8601"}, {"name": "uploads",
         "type": "directory", "modified": "iso8601"}]}

    Errors:
        NOT_FOUND: Unknown slug or path doesn't exist
    """
    return api_client.list_files(slug, path)


@mcp.tool()
def read_file(slug: str, path: str) -> dict:
    """Read the contents of a file from a site's container.

    Max file size: 512KB. Binary files are rejected — use the site's
    file manager or SSH for binary files.

    Requires: API key with read scope.

    Args:
        slug: Site identifier
        path: Relative path to the file

    Returns:
        {"path": "wp-config.php", "content": "<?php ...",
         "size": 1234, "encoding": "utf-8"}

    Errors:
        NOT_FOUND: File doesn't exist
        VALIDATION_ERROR: File is binary or exceeds 512KB
    """
    return api_client.read_file(slug, path)


@mcp.tool()
def write_file(slug: str, path: str, content: str) -> dict:
    """Write or overwrite a text file in a site's container.

    Creates parent directories if they don't exist.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        path: Relative path to the file
        content: File content as a UTF-8 string

    Returns:
        {"success": true, "path": "...", "size": 1234}

    Errors:
        NOT_FOUND: Unknown slug
        FORBIDDEN: Protected system path
    """
    return api_client.write_file(slug, path, content)


@mcp.tool()
def upload_file(slug: str, path: str, content_b64: str) -> dict:
    """Upload a base64-encoded file to a site's container.

    Use this for binary files (images, archives, fonts, etc.).
    For text files, prefer write_file().

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        path: Relative path including filename (e.g. "images/logo.png")
        content_b64: Base64-encoded file content

    Returns:
        {"success": true, "path": "images/logo.png", "size": 45678}

    Errors:
        VALIDATION_ERROR: Invalid base64 encoding
        FORBIDDEN: Protected system path
    """
    return api_client.upload_file(slug, path, content_b64)


@mcp.tool()
def delete_file(slug: str, path: str) -> dict:
    """Delete a file or directory from a site's container.

    Directories are deleted recursively. Protected system paths
    (e.g. /etc, /usr) cannot be deleted.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        path: Relative path to delete

    Returns:
        {"success": true, "path": "...", "message": "Deleted"}

    Errors:
        NOT_FOUND: Path doesn't exist
        FORBIDDEN: Protected system path
    """
    return api_client.delete_file(slug, path)


# ── Logs ──

@mcp.tool()
def get_logs(slug: str, log_type: str = "error", lines: int = 100, search: str = "") -> dict:
    """Retrieve container logs (error, access, or PHP).

    Requires: API key with read scope.

    Args:
        slug: Site identifier
        log_type: "error" (Nginx/Apache errors), "access" (HTTP request log),
                  or "php" (PHP-FPM errors, WordPress sites only)
        lines: Number of lines to retrieve (1–500, default: 100)
        search: Optional keyword filter — only lines containing this string

    Returns:
        {"log_type": "error", "lines": ["2024-01-15 ... error ...", ...],
         "count": 42, "truncated": false}

    Errors:
        NOT_FOUND: Unknown slug
        VALIDATION_ERROR: Invalid log_type or lines out of range
    """
    return api_client.get_logs(slug, log_type, lines, search or None)


# ── Domains ──

@mcp.tool()
def list_domains() -> list:
    """List all domains owned by the authenticated user.

    Requires: API key with read scope.

    Returns:
        [{"domain": "example.com", "status": "active",
          "expires_at": "iso8601", "auto_renew": true,
          "linked_site": "my-site"}]
    """
    return api_client.list_domains()


@mcp.tool()
def search_domain(domain: str) -> dict:
    """Check domain availability and get pricing.

    Requires: API key with read scope.

    Args:
        domain: Full domain name (e.g. "example.com", "mybiz.ca")

    Returns:
        {"domain": "example.com", "available": true,
         "price": {"amount": 15.99, "currency": "CAD", "period": "1 year"},
         "premium": false}

    Note: .ca domains require ca_legal_type when registering.
    """
    return api_client.search_domain(domain)


@mcp.tool()
def register_domain(
    domain: str,
    first_name: str,
    last_name: str,
    email: str,
    phone: str,
    address1: str,
    city: str,
    state: str,
    postal_code: str,
    country: str = "CA",
    period: int = 1,
    ca_legal_type: str = "",
) -> dict:
    """Register a new domain with WHOIS contact info and Stripe billing.

    The domain cost is charged to the user's active subscription.
    Free domain if plan includes free_domain_annual + annual billing + first domain.

    Requires: API key with write scope.

    Args:
        domain: Full domain name (e.g. "example.ca", "mybusiness.com")
        first_name: Registrant first name
        last_name: Registrant last name
        email: Registrant email address
        phone: Phone number in E.164 format: "+1.5145551234"
        address1: Street address (e.g. "123 Rue Principale")
        city: City (e.g. "Montreal")
        state: Province/state code (e.g. "QC", "ON", "BC")
        postal_code: Postal/ZIP code (e.g. "H2X 1Y4")
        country: ISO 3166-1 alpha-2 country code (default: "CA")
        period: Registration period in years (1–10, default: 1)
        ca_legal_type: Required for .ca domains. CIRA legal types:
                       "CCO" (Canadian citizen), "RES" (permanent resident),
                       "CCT" (corporation), "GOV" (government), "EDU" (education),
                       "ASS" (association), "HOP" (hospital), "PRT" (partnership),
                       "TDM" (trademark), "TRD" (trade union), "PLT" (political party),
                       "LAM" (library/archive/museum), "MAJ" (Her Majesty),
                       "INB" (Indian band), "ABO" (Aboriginal peoples),
                       "LGR" (legal representative)

    Returns:
        {"domain": "example.ca", "status": "registered",
         "expires_at": "iso8601", "message": "Domain registered successfully"}

    Errors:
        VALIDATION_ERROR: Missing required fields, invalid phone format,
                          missing ca_legal_type for .ca domains
        NOT_FOUND: Domain not available (already registered by someone else)
    """
    contact = {
        'first_name': first_name,
        'last_name': last_name,
        'email': email,
        'phone': phone,
        'address1': address1,
        'city': city,
        'state': state,
        'postal_code': postal_code,
        'country': country,
    }
    return api_client.register_domain(
        domain, contact, period,
        ca_legal_type=ca_legal_type or None,
    )


@mcp.tool()
def domain_detail(domain_name: str) -> dict:
    """Get full domain details including DNS and infrastructure status.

    Requires: API key with read scope.

    Args:
        domain_name: Full domain name (e.g. "example.com")

    Returns:
        {"domain": "example.com", "status": "active",
         "expires_at": "iso8601", "auto_renew": true,
         "nameservers": ["ns1.borealhost.ai", "ns2.borealhost.ai"],
         "dns_records": [...], "linked_site": "my-site"}

    Errors:
        NOT_FOUND: Domain not owned by this account
    """
    return api_client.get_domain_detail(domain_name)


# ── Modules ──

@mcp.tool()
def list_modules(slug: str) -> dict:
    """List AI modules and their enabled/disabled state for a site.

    Also returns the list of modules available for the site's plan.

    Requires: API key with read scope.

    Args:
        slug: Site identifier

    Returns:
        {"modules": {"chatbot": true, "seo": false, "translation": false,
         "content": false}, "available": ["chatbot", "seo", "translation", "content"]}

    Errors:
        NOT_FOUND: Unknown slug
    """
    return api_client.list_modules(slug)


@mcp.tool()
def toggle_module(slug: str, module_name: str) -> dict:
    """Enable or disable an AI module on a site.

    The module must be in the plan's available module list.

    Requires: API key with write scope.

    Args:
        slug: Site identifier
        module_name: Module to toggle. Available modules:
                     "chatbot" (AI chat widget), "seo" (SEO optimization),
                     "translation" (content translation), "content" (AI content generation)

    Returns:
        {"module": "chatbot", "enabled": true, "message": "Module enabled"}

    Errors:
        NOT_FOUND: Unknown slug or module not in plan
        VALIDATION_ERROR: Invalid module name
    """
    return api_client.toggle_module(slug, module_name)


# ── Resources & Prompts (imported from submodules) ──

from . import resources as _resources  # noqa: E402
_resources.register(mcp)

from . import prompts as _prompts  # noqa: E402
_prompts.register(mcp)


def main():
    """Run the MCP server."""
    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()
