"""Configuration for the BorealHost MCP server."""

import os

BASE_URL = os.environ.get('BOREALHOST_BASE_URL', 'https://borealhost.ai')
API_KEY = os.environ.get('BOREALHOST_API_KEY', '')
API_BASE = f'{BASE_URL}/api/v1'
