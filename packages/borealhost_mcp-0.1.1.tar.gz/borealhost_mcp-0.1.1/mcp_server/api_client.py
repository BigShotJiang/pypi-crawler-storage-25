"""HTTP client wrapping the BorealHost REST API."""

import httpx

from .config import API_BASE, API_KEY

# Session-level API key — set by register() or set_api_key() at runtime.
# Falls back to BOREALHOST_API_KEY env var if not set.
_session_key = None

# Checkout secrets — keyed by checkout_id, auto-stored on create_checkout.
_checkout_secrets = {}


def set_session_key(key):
    """Store an API key for this session (used by all subsequent calls)."""
    global _session_key
    _session_key = key


def get_session_key():
    """Get the current session key (or env var fallback)."""
    return _session_key or API_KEY


def _headers(api_key=None):
    h = {'Content-Type': 'application/json'}
    key = api_key or get_session_key()
    if key:
        h['Authorization'] = f'Bearer {key}'
    return h


def _handle(resp):
    """Parse API response envelope."""
    data = resp.json()
    if not data.get('ok', False):
        error = data.get('error', {})
        raise Exception(f"API error: {error.get('code', 'UNKNOWN')}: {error.get('message', 'Unknown error')}")
    return data.get('data')


# ── Auth (unauthenticated) ──

def register(email=None, name='Agent Key'):
    """Register an agent account and get an API key."""
    body = {'name': name}
    if email:
        body['email'] = email
    resp = httpx.post(
        f'{API_BASE}/auth/register/',
        headers={'Content-Type': 'application/json'},
        json=body,
        timeout=30,
    )
    return _handle(resp)


def whoami():
    """Get current account info from API key."""
    resp = httpx.get(f'{API_BASE}/auth/whoami/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── Plans (unauthenticated) ──

def list_plans(include_deprecated=False, track=None):
    params = {}
    if include_deprecated:
        params['include_deprecated'] = 'true'
    if track:
        params['track'] = track
    resp = httpx.get(f'{API_BASE}/plans/', headers=_headers(), params=params, timeout=30)
    return _handle(resp)


def get_plan(slug):
    resp = httpx.get(f'{API_BASE}/plans/{slug}/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── ACP Checkout (unauthenticated) ──

def create_checkout(sku):
    """Create an ACP checkout session for a plan SKU."""
    resp = httpx.post(
        f'{API_BASE}/acp/checkouts/',
        headers={'Content-Type': 'application/json'},
        json={'sku': sku},
        timeout=30,
    )
    result = _handle(resp)
    # Store checkout_secret for subsequent update/complete calls
    if result and result.get('checkout_secret'):
        _checkout_secrets[result['id']] = result['checkout_secret']
    return result


def get_checkout(checkout_id):
    """Get ACP checkout session status."""
    resp = httpx.get(f'{API_BASE}/acp/checkouts/{checkout_id}/', timeout=30)
    return _handle(resp)


def _checkout_headers(checkout_id):
    """Build headers with checkout_secret if available."""
    h = {'Content-Type': 'application/json'}
    secret = _checkout_secrets.get(checkout_id)
    if secret:
        h['X-Checkout-Secret'] = secret
    return h


def update_checkout(checkout_id, buyer_email=None, requested_slug=None):
    """Update ACP checkout with buyer info."""
    body = {}
    if buyer_email:
        body['buyer_email'] = buyer_email
    if requested_slug:
        body['requested_slug'] = requested_slug
    resp = httpx.post(
        f'{API_BASE}/acp/checkouts/{checkout_id}/update/',
        headers=_checkout_headers(checkout_id),
        json=body,
        timeout=30,
    )
    return _handle(resp)


def complete_checkout(checkout_id, payment_method='stripe_checkout', payment_method_id=None):
    """Complete ACP checkout with payment."""
    body = {'payment_method': payment_method}
    if payment_method_id:
        body['payment_method_id'] = payment_method_id
    # admin_bypass needs auth header; others use checkout_secret
    headers = _headers() if payment_method == 'admin_bypass' else _checkout_headers(checkout_id)
    resp = httpx.post(
        f'{API_BASE}/acp/checkouts/{checkout_id}/complete/',
        headers=headers,
        json=body,
        timeout=60,
    )
    return _handle(resp)


# ── Sites (authenticated) ──

def create_site(checkout_id):
    """Create a site from a completed ACP checkout."""
    resp = httpx.post(
        f'{API_BASE}/sites/create/',
        headers=_headers(),
        json={'checkout_id': checkout_id},
        timeout=60,
    )
    return _handle(resp)


def list_sites():
    resp = httpx.get(f'{API_BASE}/sites/', headers=_headers(), timeout=30)
    return _handle(resp)


def get_site(slug):
    resp = httpx.get(f'{API_BASE}/sites/{slug}/', headers=_headers(), timeout=30)
    return _handle(resp)


def manage_dns(slug, action, record_type, subdomain='', value='', ttl=3600, priority=None):
    body = {'action': action, 'type': record_type, 'subdomain': subdomain, 'value': value, 'ttl': ttl}
    if priority is not None:
        body['priority'] = priority
    resp = httpx.post(f'{API_BASE}/sites/{slug}/dns/', headers=_headers(), json=body, timeout=30)
    return _handle(resp)


def deploy(slug):
    resp = httpx.post(f'{API_BASE}/sites/{slug}/deploy/', headers=_headers(), json={}, timeout=120)
    return _handle(resp)


def create_snapshot(slug, description=''):
    body = {'description': description} if description else {}
    resp = httpx.post(f'{API_BASE}/sites/{slug}/snapshots/create/', headers=_headers(), json=body, timeout=180)
    return _handle(resp)


def list_snapshots(slug):
    resp = httpx.get(f'{API_BASE}/sites/{slug}/snapshots/', headers=_headers(), timeout=30)
    return _handle(resp)


def create_b2_snapshot(slug, description=''):
    body = {'description': description} if description else {}
    resp = httpx.post(f'{API_BASE}/sites/{slug}/snapshots/b2/', headers=_headers(), json=body, timeout=1800)
    return _handle(resp)


def delete_snapshot(slug, snapshot_id):
    resp = httpx.delete(f'{API_BASE}/sites/{slug}/snapshots/{snapshot_id}/', headers=_headers(), timeout=60)
    return _handle(resp)


def rollback_snapshot(slug, snapshot_id):
    resp = httpx.post(f'{API_BASE}/sites/{slug}/snapshots/{snapshot_id}/rollback/', headers=_headers(), json={}, timeout=300)
    return _handle(resp)


def get_snapshot_usage(slug):
    resp = httpx.get(f'{API_BASE}/sites/{slug}/snapshots/usage/', headers=_headers(), timeout=30)
    return _handle(resp)


def schedule_snapshot(slug, scheduled_at, description=''):
    body = {'scheduled_at': scheduled_at, 'description': description}
    resp = httpx.post(f'{API_BASE}/sites/{slug}/snapshots/schedule/', headers=_headers(), json=body, timeout=30)
    return _handle(resp)


def cancel_scheduled_snapshot(slug, schedule_id):
    resp = httpx.delete(f'{API_BASE}/sites/{slug}/snapshots/schedule/{schedule_id}/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── Backups (authenticated) ──

def list_backups(slug):
    resp = httpx.get(f'{API_BASE}/sites/{slug}/backups/', headers=_headers(), timeout=30)
    return _handle(resp)


def create_backup(slug):
    resp = httpx.post(f'{API_BASE}/sites/{slug}/backups/create/', headers=_headers(), json={}, timeout=30)
    return _handle(resp)


def restore_backup(slug, backup_id):
    resp = httpx.post(f'{API_BASE}/sites/{slug}/backups/{backup_id}/restore/', headers=_headers(), json={}, timeout=30)
    return _handle(resp)


def get_metrics(slug, days=7):
    resp = httpx.get(f'{API_BASE}/sites/{slug}/metrics/', headers=_headers(), params={'days': days}, timeout=30)
    return _handle(resp)


def scale(slug, new_plan):
    resp = httpx.post(f'{API_BASE}/sites/{slug}/scale/', headers=_headers(), json={'new_plan': new_plan}, timeout=30)
    return _handle(resp)


def decommission(slug):
    resp = httpx.delete(f'{API_BASE}/sites/{slug}/delete/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── Account Management (authenticated) ──

def update_account(email=None, language=None, first_name=None, last_name=None):
    """Update account profile fields."""
    body = {}
    if email is not None:
        body['email'] = email
    if language is not None:
        body['language'] = language
    if first_name is not None:
        body['first_name'] = first_name
    if last_name is not None:
        body['last_name'] = last_name
    resp = httpx.post(f'{API_BASE}/account/update/', headers=_headers(), json=body, timeout=30)
    return _handle(resp)


def delete_account():
    """Soft-delete (anonymize) the account. Irreversible."""
    resp = httpx.request(
        'DELETE', f'{API_BASE}/account/delete/',
        headers=_headers(), json={'confirm': 'DELETE'}, timeout=30,
    )
    return _handle(resp)


def list_subscriptions():
    """List all subscriptions for the account."""
    resp = httpx.get(f'{API_BASE}/account/subscriptions/', headers=_headers(), timeout=30)
    return _handle(resp)


def get_billing_portal(flow=None):
    """Get Stripe billing portal URL."""
    params = {}
    if flow:
        params['flow'] = flow
    resp = httpx.get(f'{API_BASE}/account/billing-portal/', headers=_headers(), params=params, timeout=30)
    return _handle(resp)


def rotate_key(key_id):
    """Atomically rotate an API key."""
    resp = httpx.post(f'{API_BASE}/keys/{key_id}/rotate/', headers=_headers(), json={}, timeout=30)
    return _handle(resp)


# ── File Management (authenticated) ──

def list_files(slug, path=''):
    """List directory contents for a site."""
    params = {'path': path} if path else {}
    resp = httpx.get(f'{API_BASE}/sites/{slug}/files/', headers=_headers(), params=params, timeout=30)
    return _handle(resp)


def read_file(slug, path):
    """Read a file from a site."""
    resp = httpx.get(f'{API_BASE}/sites/{slug}/files/read/', headers=_headers(), params={'path': path}, timeout=30)
    return _handle(resp)


def write_file(slug, path, content):
    """Write content to a file on a site."""
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/files/write/',
        headers=_headers(), json={'path': path, 'content': content}, timeout=30,
    )
    return _handle(resp)


def upload_file(slug, path, content_b64):
    """Upload a base64-encoded file to a site."""
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/files/upload/',
        headers=_headers(), json={'path': path, 'content_b64': content_b64}, timeout=30,
    )
    return _handle(resp)


def delete_file(slug, path):
    """Delete a file or directory on a site."""
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/files/delete/',
        headers=_headers(), json={'path': path}, timeout=30,
    )
    return _handle(resp)


# ── Apps (authenticated, VPS only) ──

def list_apps(slug):
    """List installed apps on a site."""
    resp = httpx.get(f'{API_BASE}/sites/{slug}/apps/', headers=_headers(), timeout=30)
    return _handle(resp)


def install_app(slug, template, app_name, db_type='none', domain='', display_name=''):
    """Install an app template on a VPS site."""
    body = {'template': template, 'app_name': app_name, 'db_type': db_type}
    if domain:
        body['domain'] = domain
    if display_name:
        body['display_name'] = display_name
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/apps/install/',
        headers=_headers(),
        json=body,
        timeout=60,
    )
    return _handle(resp)


def get_app(slug, app_id):
    """Get app status and install log."""
    resp = httpx.get(f'{API_BASE}/sites/{slug}/apps/{app_id}/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── Logs (authenticated) ──

def get_logs(slug, log_type='error', lines=100, search=None):
    """Get container logs for a site."""
    params = {'type': log_type, 'lines': lines}
    if search:
        params['search'] = search
    resp = httpx.get(f'{API_BASE}/sites/{slug}/logs/', headers=_headers(), params=params, timeout=30)
    return _handle(resp)


# ── Modules (authenticated) ──

def list_modules(slug):
    """List modules and availability for a site."""
    resp = httpx.get(f'{API_BASE}/sites/{slug}/modules/', headers=_headers(), timeout=30)
    return _handle(resp)


def toggle_module(slug, module_name):
    """Toggle a module on/off for a site."""
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/modules/{module_name}/toggle/',
        headers=_headers(), json={}, timeout=30,
    )
    return _handle(resp)


# ── Domains (authenticated) ──

def list_domains():
    """List all domains owned by the user."""
    resp = httpx.get(f'{API_BASE}/domains/', headers=_headers(), timeout=30)
    return _handle(resp)


def search_domain(domain):
    """Check domain availability and pricing."""
    resp = httpx.get(f'{API_BASE}/domains/search/', headers=_headers(), params={'domain': domain}, timeout=30)
    return _handle(resp)


def register_domain(domain, contact, period=1, subscription_id=None, ca_legal_type=None):
    """Register a domain with contact info and Stripe billing."""
    body = {'domain': domain, 'period': period, 'contact': contact}
    if subscription_id:
        body['subscription_id'] = subscription_id
    if ca_legal_type:
        body['ca_legal_type'] = ca_legal_type
    resp = httpx.post(
        f'{API_BASE}/domains/register/',
        headers=_headers(), json=body, timeout=60,
    )
    return _handle(resp)


def get_domain_detail(domain_name):
    """Get domain detail with infrastructure status."""
    resp = httpx.get(f'{API_BASE}/domains/{domain_name}/', headers=_headers(), timeout=30)
    return _handle(resp)


# ── SSH Access (authenticated) ──

def get_ssh_info(slug):
    """Get SSH connection info for a site."""
    resp = httpx.get(f'{API_BASE}/sites/{slug}/ssh/', headers=_headers(), timeout=30)
    return _handle(resp)


def add_ssh_key(slug, public_key):
    """Inject an SSH public key into a site's container."""
    resp = httpx.post(
        f'{API_BASE}/sites/{slug}/ssh/keys/',
        headers=_headers(), json={'public_key': public_key}, timeout=30,
    )
    return _handle(resp)


# ── Key Claim (challenge-response) ──

def request_api_key(site_slug):
    """Request a claim token for challenge-response key provisioning."""
    resp = httpx.post(
        f'{API_BASE}/keys/claim/request/',
        headers={'Content-Type': 'application/json'},
        json={'site_slug': site_slug},
        timeout=15,
    )
    return _handle(resp)


def claim_api_key(claim_token):
    """Claim an API key using a claim token from the container."""
    resp = httpx.post(
        f'{API_BASE}/keys/claim/',
        headers={'Content-Type': 'application/json'},
        json={'claim_token': claim_token},
        timeout=15,
    )
    return _handle(resp)
