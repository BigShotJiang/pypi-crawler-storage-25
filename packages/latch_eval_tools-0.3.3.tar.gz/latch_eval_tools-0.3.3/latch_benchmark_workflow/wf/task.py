import json
import os
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import traceback
from uuid import uuid4
from latch.functions.secrets import get_secret
from latch.ldata.path import LPath
from latch.resources.tasks import custom_task, small_task
from latch.types.directory import LatchDir, LatchOutputDir

from latch_eval_tools import EvalRunner
from latch_eval_tools.harness import (
    get_project_root,
    load_trajectory_identifier,
    run_claudecode_task,
    run_minisweagent_task,
    run_openaicodex_task,
    run_plotsagent_task,
)
from latch_eval_tools.types import TestCase
from wf.models import  Harness

SECRET_KEYS = [
    "LATCH_ANTHROPIC_API_KEY",
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "XAI_API_KEY",
]
DEFAULT_EVAL_TIMEOUT_SECONDS = 600
MINISWE_PULL_TIMEOUT_SECONDS = 600
MINISWE_STARTUP_MAX_BACKOFFS = 3
MINISWE_INITIAL_BACKOFF_SECONDS = 10
WORKSPACE_NAME = "eval_workspace"
TOP_LEVEL_WORKSPACE_ARTIFACTS = {
    "agent_output.log",
    "eval_answer.json",
    "eval_output.json",
    "trajectory.json",
}
WORKSPACE_HIDDEN_STATE_DIRS = {".claude", ".codex"}


@dataclass
class EvalRunInput:
    task_spec: str
    eval_output_parent_directory: str
    model_name: str
    harness: str
    agent_timeout_seconds: int
    trial_index: int
    n_trials: int

def parse_eval_run_input(model_harness_task_trial: str,agent_timeout_seconds: int,eval_output_parent_directory: str) -> list[EvalRunInput]:
    if not model_harness_task_trial.strip():
        return []
    eval_run_inputs = []
    for line in model_harness_task_trial.splitlines():
        line = line.strip()
        if not line:
            continue
        model, harness, task_path, n_trials = line.split()
        harness = Harness(harness)
        task_file_lpath = LPath(task_path)
        assert task_file_lpath.exists(load_if_missing=True), f"Task file {task_path} does not exist"
        assert not task_file_lpath.is_dir(), f"Task file {task_path} is a directory"
        n_trials = int(n_trials)
        assert n_trials > 0, f"Number of trials must be > 0, got {n_trials}"
        for i in range(1, n_trials + 1):
            eval_run_inputs.append(EvalRunInput(
                task_spec=task_file_lpath.path,
                eval_output_parent_directory=eval_output_parent_directory,
                model_name=model,
                harness=harness.value,
                agent_timeout_seconds=agent_timeout_seconds,
                trial_index=i,
                n_trials=n_trials,
            ))
    return eval_run_inputs

def _jsonable(value):
    if hasattr(value, "__dataclass_fields__"):
        return {
            key: _jsonable(getattr(value, key))
            for key in value.__dataclass_fields__
        }
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value

def collect_harness_outputs(harness: str, result: dict, agent_output_dir: Path, output_dir: Path):
    try:
        destination_root = output_dir / "harness_outputs"
        destination_root.mkdir(parents=True, exist_ok=True)

        def copy_harness_output(source: Path, relative_path: Path | None = None):
            if not source.exists() or source.is_dir() or source.is_symlink():
                return
            destination = destination_root / (
                relative_path if relative_path is not None else Path(source.name)
            )
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            print(f"Copied {source} to {destination}")

        match Harness(harness):
            case Harness.claude_code:
                identifier_key = load_trajectory_identifier(
                    agent_output_dir / "trajectory.json",
                    "session_id",
                )
                if identifier_key is None:
                    return
                source_root = agent_output_dir / ".claude"
                if not source_root.exists():
                    print("No workspace-local .claude directory found")
                    return
                for source in source_root.rglob("*"):
                    if source.is_dir() or source.is_symlink():
                        continue
                    if identifier_key in source.name:
                        copy_harness_output(source)
            case Harness.openai_codex:
                identifier_key = load_trajectory_identifier(
                    agent_output_dir / "trajectory.json",
                    "thread_id",
                )
                if identifier_key is None:
                    return
                source_root = agent_output_dir / ".codex"
                if not source_root.exists():
                    print("No workspace-local .codex directory found")
                    return
                for source in source_root.rglob("*"):
                    if source.is_dir() or source.is_symlink():
                        continue
                    if identifier_key in source.name:
                        copy_harness_output(source)
            case Harness.plots_agent:
                copy_harness_output(agent_output_dir / "eval_output.json")
                workspaces_root = agent_output_dir / "workspaces"
                if not workspaces_root.exists():
                    print("No plots-agent workspaces directory found")
                    return
                for source in sorted(workspaces_root.rglob("*")):
                    if source.is_dir() or source.is_symlink():
                        continue
                    copy_harness_output(source, source.relative_to(agent_output_dir))
            case _:
                print("No harness outputs to collect for ", harness)
                return
    except Exception as e:
        print(f"Error collecting harness outputs: {e}")
        return


def get_all_task_paths(task_path: LPath) -> list[LPath]:
    input_task_paths: list[LPath] = []
    if not task_path.is_dir():
        task_name = task_path.name()
        if task_name is None or not task_name.endswith(".json"):
            raise ValueError(f"Expected a JSON task spec, got {task_path.path}")
        input_task_paths.append(task_path)
    else:
        for child in sorted(task_path.iterdir(), key=lambda path: path.path):
            if not child.is_dir():
                child_name = child.name()
                if child_name is not None and child_name.endswith(".json"):
                    input_task_paths.append(child)
            else:
                input_task_paths.extend(get_all_task_paths(child))

    return input_task_paths


@small_task
def write_params_manifest(
    model_harness_task_trial: str,
    output_directory: LatchOutputDir,
    agent_timeout_seconds: int,
    run_prefix: str,
) -> list[EvalRunInput]:
    try:
        if output_directory.remote_path is None:
            raise ValueError("Output directory must have a remote path")
        
        run_group_id = f"{run_prefix}_{datetime.now(timezone.utc).strftime('%Y_%m_%d_%H_%M')}_{uuid4().hex[:4]}"
        execution_output_directory = os.path.join(output_directory.remote_path, run_group_id)
        eval_run_inputs = parse_eval_run_input(model_harness_task_trial,agent_timeout_seconds,execution_output_directory)
        manifest = {
            "datetime_utc": datetime.now(timezone.utc).isoformat(),
            "params": {
                "eval_run_inputs" : [asdict(eval_run_input) for eval_run_input in eval_run_inputs],
                "output_directory": output_directory.remote_path,
                "execution_output_directory": execution_output_directory,
                "agent_timeout_seconds": agent_timeout_seconds,
            },
        }

        temp_dir = Path(tempfile.mkdtemp(prefix="benchmark_wf_params_"))
        try:
            (temp_dir / "params.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))
            LPath(execution_output_directory).upload_from(temp_dir)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

        return eval_run_inputs
    except Exception as exc:
        traceback.print_exc()
        raise ValueError(f"Error writing params manifest: {exc}") from exc

def slugify(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")


CACHED_AGENT_IMAGE_TAR = Path("/opt/agent-image.tar")

_image_loaded = False


def preload_cached_docker_image() -> None:
    """Load the pre-cached agent image tar into the local Docker daemon.

    No-ops if the tar doesn't exist (local dev) or was already loaded this process.
    """
    global _image_loaded
    if _image_loaded or not CACHED_AGENT_IMAGE_TAR.exists():
        return
    print(f"Loading cached Docker image from {CACHED_AGENT_IMAGE_TAR} ...")
    subprocess.run(
        ["docker", "load", "-i", str(CACHED_AGENT_IMAGE_TAR)],
        check=True,
    )
    _image_loaded = True
    print("Cached Docker image loaded successfully")


def _run_minisweagent_with_backoff(
    task_prompt: str,
    work_dir: Path,
    *,
    model_name: str,
    eval_timeout: int,
) -> dict:
    backoff_seconds = MINISWE_INITIAL_BACKOFF_SECONDS
    max_attempts = MINISWE_STARTUP_MAX_BACKOFFS + 1
    env_config = {"pull_timeout": MINISWE_PULL_TIMEOUT_SECONDS}

    for attempt in range(1, max_attempts + 1):
        try:
            return run_minisweagent_task(
                task_prompt,
                work_dir,
                model_name=model_name,
                eval_timeout=eval_timeout,
                env_config=env_config,
            )
        except subprocess.TimeoutExpired:
            if attempt >= max_attempts:
                print(
                    "mini-swe-agent Docker startup timed out after "
                    f"{attempt} attempts with pull_timeout="
                    f"{MINISWE_PULL_TIMEOUT_SECONDS}s"
                )
                raise
            print(
                "mini-swe-agent Docker startup timed out on attempt "
                f"{attempt}/{max_attempts}; retrying in {backoff_seconds}s"
            )
            time.sleep(backoff_seconds)
            backoff_seconds *= 2

@custom_task(4,32,storage_gib=100)
def run_task(
    task_run_input: EvalRunInput,
) -> LatchDir:
    print(f"Running task {task_run_input}")
    task_spec = task_run_input.task_spec
    model_name = task_run_input.model_name
    harness = task_run_input.harness
    trial_index = task_run_input.trial_index
    try:
        preload_cached_docker_image()
        for key in SECRET_KEYS:
            try:
                value = get_secret(key)
                assert value is not None
                if key == "LATCH_ANTHROPIC_API_KEY":
                    os.environ["ANTHROPIC_API_KEY"] = value
                else:
                    os.environ[key] = value
            except Exception:
                print(f"Could not fetch secret {key}")

        if os.environ.get("OPENAI_API_KEY"):
            os.environ["CODEX_API_KEY"] = os.environ["OPENAI_API_KEY"]

        task_json_path = LPath(task_spec).download()
       
        test_case = TestCase(**json.loads(task_json_path.read_text()))
        eval_timeout_seconds = task_run_input.agent_timeout_seconds
        if eval_timeout_seconds <= 0:
            eval_timeout_seconds = DEFAULT_EVAL_TIMEOUT_SECONDS

        match Harness(harness):
            case Harness.mini_swe_agent:
                agent_runner = _run_minisweagent_with_backoff
            case Harness.claude_code:
                agent_runner = run_claudecode_task
            case Harness.openai_codex:
                agent_runner = run_openaicodex_task
            case Harness.plots_agent:
                agent_runner = run_plotsagent_task
            case _:
                raise ValueError(f"Unsupported harness: {harness}")
        
        
        safe_eval_id = slugify(test_case.id)
        safe_model_name = slugify(model_name)
        safe_harness = slugify(harness)
        run_artifact_name = f"{safe_model_name}_{safe_harness}_{safe_eval_id}_r{trial_index}"
    
        print(
            f"Running eval {test_case.id} with model {model_name} using harness {harness} "
            f"(trial={trial_index}/{task_run_input.n_trials}, "
            f"timeout={eval_timeout_seconds}s)"
        )

        runner = EvalRunner(
            eval_path=task_json_path,
            keep_workspace=True,
            run_id=None,
            workspace_name=WORKSPACE_NAME,
        )
        agent_run_started_at_utc = datetime.now(timezone.utc)
        try:
            result = runner.run(
                agent_function=lambda task_prompt, work_dir: agent_runner(
                    task_prompt,
                    work_dir,
                    model_name=model_name,
                    eval_timeout=eval_timeout_seconds,
                )
            )
        finally:
            agent_run_ended_at_utc = datetime.now(timezone.utc)
        project_root = get_project_root()
        agent_output_dir = project_root / WORKSPACE_NAME / "workspace"  / test_case.id
        output_dir = project_root / "output" / run_artifact_name
        output_dir.mkdir(parents=True, exist_ok=True)
        for source in sorted(agent_output_dir.rglob("*")):
            # avoid copying directories and symlinked input data
            source_path = Path(source)
            relative_path = source.relative_to(agent_output_dir)
            if (
                source_path.is_dir()
                or source_path.is_symlink()
                or source_path.suffix in [".h5ad",".pkl"]
                or "__pycache__" in source_path.parts
                or ".venv" in source_path.parts
                or (relative_path.parts and relative_path.parts[0] in WORKSPACE_HIDDEN_STATE_DIRS)
            ):
                continue
            destination = output_dir / "agent_output" / relative_path
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        collect_harness_outputs(harness, result, agent_output_dir, output_dir)

        serializable_result = {
            "task_spec": task_spec,
            "model_name": model_name,
            "harness": harness,
            "eval_timeout_seconds": eval_timeout_seconds,
            "n_trials": task_run_input.n_trials,
            "trial_index": trial_index,
            "task" : test_case.id,
            "agent_runtime_seconds": (agent_run_ended_at_utc - agent_run_started_at_utc).seconds,
            "result": _jsonable(result),
        }
        (output_dir / "result.json").write_text(json.dumps(serializable_result, indent=2, sort_keys=True))
        output_directory = os.path.join(task_run_input.eval_output_parent_directory, run_artifact_name)
        print(f"Uploading eval artifacts from {output_dir} to {output_directory}")
        LPath(output_directory).upload_from(output_dir)
        return LatchDir(output_directory)
    except Exception as exc:
        traceback.print_exc()
        raise ValueError(f"Error running task {task_spec}: {exc}") from exc
