from __future__ import annotations

from enum import Enum


class Harness(Enum):
    mini_swe_agent = "mini-swe-agent"
    claude_code = "claude-code"
    openai_codex = "openai-codex"
    plots_agent = "plots-agent"
