from latch.resources.map_tasks import map_task 
from latch.resources.workflow import workflow
from latch.types.directory import LatchDir, LatchOutputDir
from latch.types.metadata import (
    LatchAppearanceEnum,
    LatchAuthor,
    LatchMetadata,
    LatchParameter,
)

from wf.task import run_task, write_params_manifest

MAX_CONCURRENCY = 20

metadata = LatchMetadata(
    display_name="benchmark_code_agent",
    author=LatchAuthor(
        name="AnirudhNarsipur",
    ),
    parameters={
        "model_harness_task_trial": LatchParameter(
            display_name="Model+Harness File",
            description="Each line is <model> <harness> <remote_task_path> <n_trials>",
            appearance_type=LatchAppearanceEnum.paragraph,
        ),
        "output_directory": LatchParameter(
            display_name="Output Directory",
            description="Output directory for task results and trajectory files",
            batch_table_column=True,
        ),
        "agent_timeout_seconds": LatchParameter(
            display_name="Agent Timeout (seconds)",
            description="Per-run agent timeout in seconds.",
        ),
        "run_prefix": LatchParameter(
            display_name="Run Prefix",
            description="Prefix for the run group id.",
        ),
    },
)


@workflow(metadata)
def benchmark_code_agent(
    model_harness_task_trial: str,
    output_directory: LatchOutputDir,
    agent_timeout_seconds: int = 600,
    run_prefix: str = "run",
) -> list[LatchDir]:
    task_specs = write_params_manifest(
        model_harness_task_trial=model_harness_task_trial,
        output_directory=output_directory,
        agent_timeout_seconds=agent_timeout_seconds,
        run_prefix=run_prefix,
    )

    return map_task(
        run_task,
        concurrency=MAX_CONCURRENCY,
        min_success_ratio=0.8,
    )(task_run_input=task_specs)  # type: ignore[reportUnknownReturnType]
