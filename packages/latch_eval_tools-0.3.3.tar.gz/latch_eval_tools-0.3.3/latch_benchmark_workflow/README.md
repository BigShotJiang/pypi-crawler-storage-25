# benchmark-code-agent

Latch workflow for running benchmark evals through `latch-eval-tools` harnesses.
