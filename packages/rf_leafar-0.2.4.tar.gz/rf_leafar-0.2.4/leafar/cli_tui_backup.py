"""CLI entry points for Leafar."""

import os
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

import click
from prompt_toolkit import Application
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.filters import Condition
from prompt_toolkit.formatted_text import ANSI
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Float, FloatContainer, HSplit, Window
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.menus import CompletionsMenu
from prompt_toolkit.styles import Style
from rich.console import Console

from .agent import LeafarAgent
from .config import Config, create_env_file

console = Console()

def _print_logo() -> None:
    """Logo grande — usada no rf chat."""
    console.print("      /\\        /\\", style="cyan")
    console.print("     /  \\      /  \\", style="cyan")
    console.print(
        "[cyan] ╔═══════════════════════╗[/cyan]\n"
        "[cyan] ║  [/cyan][bold white]◉[/bold white][cyan]               [/cyan][bold white]◉[/bold white][cyan]  ║[/cyan]\n"
        "[cyan] ╠═══════════════════════╣[/cyan]\n"
        "[cyan] ║  [/cyan][bold white]▸ rf[/bold white][cyan]  ·  [/cyan][bold white]leafar[/bold white][cyan]      ║[/cyan]\n"
        "[cyan] ║  [/cyan][dim]android  ai  agent[/dim][cyan]   ║[/cyan]\n"
        "[cyan] ╚═══════════════════════╝[/cyan]\n"
        "[dim]  powered by Rafael Alves[/dim]\n"
    )


def _print_header() -> None:
    """Header compacto inspirado no logo — aparece em todo comando."""
    # As duas linhas com \ usam style= para evitar que \[ seja interpretado
    # como escape de colchete pelo Rich.
    console.print("      /\\      /\\", style="cyan")
    console.print("     /  \\    /  \\", style="cyan")
    console.print(
        "[cyan] ╔═══════════════════╗[/cyan]\n"
        "[cyan] ║ [/cyan][bold white]◉[/bold white][cyan]           [/cyan][bold white]◉[/bold white][cyan] ║[/cyan]\n"
        "[cyan] ╠═══════════════════╣[/cyan]\n"
        "[cyan] ║ [/cyan][bold white]▸ rf  ·  leafar[/bold white][cyan]   ║[/cyan]\n"
        "[cyan] ║ [/cyan][dim]android  ai  agent[/dim][cyan] ║[/cyan]\n"
        "[cyan] ╚═══════════════════╝[/cyan]\n"
        "[dim]   powered by Rafael Alves[/dim]\n"
    )


def _print_active_mcps(figma_started: bool, out: "Console | None" = None) -> None:
    """Mostra os servidores MCP que serão carregados nesta sessão."""
    import json as _json
    out = out or console

    icons = {
        "figma": "🎨",
        "github": "🐙",
        "azure-devops": "☁️",
    }
    labels = {
        "figma": "Figma",
        "github": "GitHub",
        "azure-devops": "Azure DevOps",
    }

    active = []

    if figma_started:
        active.append(("figma", "local :3333"))

    claude_json = Path.home() / ".claude.json"
    if claude_json.exists():
        try:
            data = _json.loads(claude_json.read_text())
            for name, cfg in data.get("mcpServers", {}).items():
                if name == "figma" and figma_started:
                    continue
                active.append((name, cfg.get("type", "stdio")))
        except Exception:
            pass

    mcps_line = "[dim cyan]▸ MCPs:[/dim cyan]"
    parts = ["[dim]leafar[/dim] [dim](tools)[/dim]"]
    for name, transport in active:
        icon = icons.get(name, "🔌")
        label = labels.get(name, name)
        parts.append(f"[dim]{icon} {label}[/dim]")

    out.print(f"{mcps_line} {' [dim cyan]·[/dim cyan] '.join(parts)}\n")


def _handle_github_login(config: "Config") -> None:
    """Pede o GitHub PAT e salva no .env e em ~/.claude.json."""
    import getpass
    import json as _json

    current = config.github_token
    if current:
        console.print(f"[yellow]GitHub token já configurado[/yellow] [dim](termina em ...{current[-6:]})[/dim]")
        console.print("[dim]Para substituir, cole o novo token abaixo (Enter para manter o atual):[/dim]")

    try:
        token = getpass.getpass("GitHub Personal Access Token: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelado.[/dim]\n")
        return

    if not token:
        if current:
            console.print("[dim]Token mantido.[/dim]\n")
        return

    # Salva no .env
    env_locations = [
        Path(".") / ".env",
        Path.home() / ".leafar" / ".env",
    ]
    env_path = next((p for p in env_locations if p.exists()), Path(".") / ".env")
    env_text = env_path.read_text() if env_path.exists() else ""
    if "GITHUB_PERSONAL_ACCESS_TOKEN" in env_text:
        import re as _re
        env_text = _re.sub(
            r"^GITHUB_PERSONAL_ACCESS_TOKEN=.*$",
            f"GITHUB_PERSONAL_ACCESS_TOKEN={token}",
            env_text,
            flags=_re.MULTILINE,
        )
    else:
        env_text += f"\nGITHUB_PERSONAL_ACCESS_TOKEN={token}\n"
    env_path.write_text(env_text)

    # Atualiza ~/.claude.json com o servidor MCP GitHub
    claude_json_path = Path.home() / ".claude.json"
    try:
        claude_data = _json.loads(claude_json_path.read_text()) if claude_json_path.exists() else {}
    except Exception:
        claude_data = {}

    claude_data.setdefault("mcpServers", {})["github"] = {
        "type": "stdio",
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "env": {"GITHUB_PERSONAL_ACCESS_TOKEN": token},
    }
    claude_json_path.write_text(_json.dumps(claude_data, indent=2))

    # Atualiza o env em runtime
    import os as _os
    _os.environ["GITHUB_PERSONAL_ACCESS_TOKEN"] = token
    config.github_token = token

    console.print("[green]✓ GitHub token salvo![/green]")
    console.print("[dim]  Reinicie o rf chat para ativar o MCP do GitHub.[/dim]\n")


def _handle_azure_login(config: "Config") -> None:
    """Pede o Azure DevOps PAT e org, salva no .env e em ~/.claude.json."""
    import getpass
    import json as _json
    import re as _re

    current = os.environ.get("AZURE_DEVOPS_PAT", "")
    if current:
        console.print(f"[yellow]Azure token já configurado[/yellow] [dim](termina em ...{current[-6:]})[/dim]")
        console.print("[dim]Para substituir, cole o novo token abaixo (Enter para manter o atual):[/dim]")

    try:
        token = getpass.getpass("Azure DevOps PAT: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelado.[/dim]\n")
        return

    if not token:
        if current:
            console.print("[dim]Token mantido.[/dim]\n")
        return

    try:
        org = input("URL da organização (ex: https://dev.azure.com/faelmg18): ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelado.[/dim]\n")
        return

    if not org:
        console.print("[red]URL da organização é obrigatória.[/red]\n")
        return

    # Salva no .env
    env_locations = [Path(".") / ".env", Path.home() / ".leafar" / ".env"]
    env_path = next((p for p in env_locations if p.exists()), Path(".") / ".env")
    env_text = env_path.read_text() if env_path.exists() else ""

    for key, val in [("AZURE_DEVOPS_PAT", token), ("AZURE_DEVOPS_ORG", org)]:
        if key in env_text:
            env_text = _re.sub(f"^{key}=.*$", f"{key}={val}", env_text, flags=_re.MULTILINE)
        else:
            env_text += f"\n{key}={val}\n"
    env_path.write_text(env_text)

    # Atualiza ~/.claude.json com o servidor MCP Azure DevOps
    claude_json_path = Path.home() / ".claude.json"
    try:
        claude_data = _json.loads(claude_json_path.read_text()) if claude_json_path.exists() else {}
    except Exception:
        claude_data = {}

    claude_data.setdefault("mcpServers", {})["azure-devops"] = {
        "type": "stdio",
        "command": "npx",
        "args": ["-y", "@tiberriver256/mcp-server-azure-devops"],
        "env": {
            "AZURE_DEVOPS_ORG_URL": org,
            "AZURE_DEVOPS_AUTH_METHOD": "pat",
            "AZURE_DEVOPS_PAT": token,
        },
    }
    claude_json_path.write_text(_json.dumps(claude_data, indent=2))

    os.environ["AZURE_DEVOPS_PAT"] = token
    os.environ["AZURE_DEVOPS_ORG"] = org

    console.print("[green]✓ Azure DevOps configurado![/green]")
    console.print("[dim]  Reinicie o rf chat para ativar o MCP do Azure DevOps.[/dim]\n")


def _start_figma_mcp(token: str) -> "subprocess.Popen | None":
    """Inicia figma-developer-mcp em background na porta 3333. Retorna o processo ou None."""
    if not token:
        return None

    # Já rodando?
    try:
        with socket.create_connection(("127.0.0.1", 3333), timeout=0.5):
            return None
    except OSError:
        pass

    env = {**os.environ, "FIGMA_API_KEY": token, "DO_NOT_TRACK": "1"}
    try:
        proc = subprocess.Popen(
            ["npx", "-y", "figma-developer-mcp"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None

    # Aguarda até 6s para o servidor subir
    for _ in range(20):
        time.sleep(0.3)
        try:
            with socket.create_connection(("127.0.0.1", 3333), timeout=0.5):
                return proc
        except OSError:
            pass

    return proc


def _make_agent(project: str, header: bool = True) -> LeafarAgent:
    if header:
        _print_header()
    config = Config(project_path=project)
    errors = config.validate()
    if errors:
        for err in errors:
            console.print(f"[red]Config error:[/red] {err}")
        sys.exit(1)
    return LeafarAgent(config, project_path=project)


# ---------------------------------------------------------------------------
# Smart group — unknown subcommands become natural-language prompts
# ---------------------------------------------------------------------------

_SHELL_COMMANDS = {
    # zsh/bash builtins
    "source", "export", "cd", "alias", "unalias", "echo", "printf", "read",
    "set", "unset", "exec", "eval", "exit", "return", "shift", "test",
    "builtin", "command", "type", "which", "hash", "bind", "trap",
    # common system commands that should never go to the agent
    "ls", "cat", "grep", "find", "mv", "cp", "rm", "mkdir", "touch",
    "git", "python", "python3", "pip", "pip3", "brew", "curl", "wget",
    "ssh", "scp", "rsync", "tar", "zip", "unzip", "open", "sudo",
    "adb", "gradle", "gradlew", "java", "javac", "kotlin", "kotlinc",
}


class _SmartGroup(click.Group):
    """A Click Group that routes unrecognised commands to the agent as
    natural-language prompts instead of raising an error.

    Example:
        leafar rode o app e me fala o que tem na primeira tela
        → same as: leafar ask "rode o app e me fala o que tem na primeira tela"
    """

    def resolve_command(
        self, ctx: click.Context, args: list[str]
    ) -> tuple[str | None, click.Command | None, list[str]]:
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            # Se o primeiro token é um comando de shell conhecido, não encaminha
            # para o agente — deixa o Click levantar o UsageError normalmente.
            first = args[0].split()[0] if args else ""
            if first in _SHELL_COMMANDS:
                raise

            # Primeiro token não reconhecido → trata como linguagem natural.
            project = ctx.params.get("project", ".")
            forwarded = ["ask", "--project", project] + list(args)
            return super().resolve_command(ctx, forwarded)


# ---------------------------------------------------------------------------
# Root group
# ---------------------------------------------------------------------------

@click.group(cls=_SmartGroup, invoke_without_command=True)
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
@click.option("--version", is_flag=True, is_eager=True, help="Show version and exit.")
@click.pass_context
def main(ctx: click.Context, project: str, version: bool) -> None:
    """Leafar — Intelligent Android Development CLI powered by Rafael Alves.

    \b
    You can use natural language directly, without subcommands:

    \b
      leafar rode o app e me fala o que você vê na primeira tela
      leafar cria uma tela de login baseada nesse Figma: https://...
      leafar tem um bug na tela de perfil, a data tá errada — corrige
    """
    if version:
        from . import __version__
        console.print(f"leafar {__version__}")
        return
    ctx.ensure_object(dict)
    ctx.obj["project"] = project
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())


# ---------------------------------------------------------------------------
# ask — main natural-language command
# ---------------------------------------------------------------------------

@main.command()
@click.argument("prompt", nargs=-1, required=True)
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
@click.option("--no-stream", is_flag=True, help="Disable streaming output.")
def ask(prompt: tuple[str, ...], project: str, no_stream: bool) -> None:
    """Ask Leafar anything about your Android project.

    \b
    Examples:
      leafar ask "create a login screen from https://figma.com/file/..."
      leafar ask "navigate to the profile screen and check the date format"
      leafar ask "why is the RecyclerView flickering in HomeFragment?"
    """
    _make_agent(project).run(" ".join(prompt), stream_output=not no_stream)


# ---------------------------------------------------------------------------
# chat — interactive REPL
# ---------------------------------------------------------------------------

_SLASH_COMMANDS = [
    # ── Skills / modos ───────────────────────────────────────────────
    ("/emulador",    "Ativa modo emulador — screenshots e interação com ADB"),
    ("/build",       "Ativa modo build — compila, instala e testa o app"),
    ("/figma",       "Ativa modo Figma — gera UI Android a partir de designs"),
    ("/debug",       "Ativa modo debug — rastreia e corrige bugs visualmente"),
    ("/review",      "Ativa modo review — analisa o código com boas práticas Android"),
    ("/testes",      "Ativa modo testes — escreve e roda testes unitários e de UI"),
    ("/arquitetura", "Ativa modo arquitetura — mapeia módulos, camadas e dependências"),
    # ── Configuração da CLI ──────────────────────────────────────────
    ("/reset",        "Limpa o histórico da sessão e começa do zero"),
    ("/tokens",       "Mostra o total de tokens usados na sessão"),
    ("/contexto",     "Mostra o resumo do projeto salvo pelo agente"),
    ("/projeto",      "Muda o caminho do projeto Android ativo"),
    ("/figma-json",    "Usa um JSON local do Figma em vez da API (evita rate limit)"),
    ("/github-login",  "Salva o GitHub Personal Access Token para integração MCP"),
    ("/azure-login",   "Salva o Azure DevOps PAT para integração MCP"),
    ("/claude-login",  "Faz login no Claude Code (abre browser para autenticação)"),
    ("/clear",        "Limpa a tela do terminal"),
    ("/sair",         "Encerra o chat"),
]

_SKILL_NAMES = {"emulador", "build", "figma", "debug", "review", "testes", "arquitetura"}


class _SlashCompleter(Completer):
    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        word = text.lstrip("/").lower()
        for cmd, desc in _SLASH_COMMANDS:
            if cmd.lstrip("/").startswith(word):
                yield Completion(
                    cmd,
                    start_position=-len(text),
                    display=cmd,
                    display_meta=desc,
                )



@main.command()
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def chat(project: str) -> None:
    """Sessão interativa — TUI tela-cheia."""
    import difflib as _difflib
    import json as _json

    config = Config(project_path=project)
    agent = LeafarAgent(config, project_path=project, chat_mode=True)
    figma_proc = _start_figma_mcp(config.figma_access_token)

    # ── Buffer de output (ANSI acumulado) ────────────────────────────────
    _raw: list[str] = []
    _lock = threading.Lock()
    _app_ref: list["Application | None"] = [None]
    _line_count: list[int] = [0]  # contador de \n em _raw — sempre atualizado

    def _push(text: str) -> None:
        with _lock:
            _raw.append(text)
            _line_count[0] += text.count("\n")
        app = _app_ref[0]
        if app:
            try:
                app.invalidate()
            except Exception:
                pass

    class _Out:
        """File-like que acumula ANSI e invalida o app."""
        def write(self, text: str) -> int:
            if text:
                _push(text)
            return len(text)
        def flush(self) -> None:
            pass

    cc = Console(file=_Out(), force_terminal=True, highlight=False)
    agent.chat_console = cc

    # Estado do spinner — atualizado pelo agent em tempo real
    _toolbar: dict = {"spinner": ""}
    agent.toolbar_state = _toolbar

    # _scroll: posição manual (só ativo quando _auto_scroll=False)
    # _auto_scroll: True = sempre mostra o fundo; False = usuário está rolando manualmente
    _scroll: list[int] = [0]
    _auto_scroll: list[bool] = [True]

    def _get_output() -> ANSI:
        with _lock:
            return ANSI("".join(_raw))

    # ── Confirmação de escrita via TUI (substitui _arrow_select) ─────────
    _confirm_evt = threading.Event()
    _confirm_val: list[bool] = [False]
    _waiting_confirm: list[bool] = [False]

    def _tui_confirm(path: str, new_content: str) -> "tuple[bool, str]":
        p = Path(path)
        if p.exists():
            old_text = p.read_text(errors="replace")
            if old_text == new_content:
                return True, "sem alterações"
            cc.print(f"\n[bold yellow]── {path} ──[/bold yellow]")
            old_l, new_l = old_text.splitlines(), new_content.splitlines()
            for line in list(_difflib.unified_diff(old_l, new_l, n=3, lineterm=""))[:120]:
                if line.startswith(("---", "+++")):
                    continue
                if line.startswith("+"):
                    cc.print(f"[green]{line}[/green]")
                elif line.startswith("-"):
                    cc.print(f"[red]{line}[/red]")
                elif line.startswith("@@"):
                    cc.print(f"[cyan]{line}[/cyan]")
                else:
                    cc.print(f"[dim]{line}[/dim]")
        else:
            cc.print(f"\n[bold yellow]── novo arquivo: {path} ──[/bold yellow]")
            for line in new_content.splitlines()[:80]:
                cc.print(f"[green]+{line}[/green]")
        cc.print("\n[bold]  [A] Aceitar    [R] Rejeitar[/bold]\n")
        _waiting_confirm[0] = True
        _confirm_evt.clear()
        _confirm_evt.wait(timeout=300)
        _waiting_confirm[0] = False
        ok = _confirm_val[0]
        cc.print(f"[dim]{'✓ Aceito' if ok else '✗ Rejeitado'}[/dim]\n")
        return ok, "aceito" if ok else "rejeitado"

    agent._confirm_write = _tui_confirm  # type: ignore[method-assign]

    # ── Input buffer com slash-completion ────────────────────────────────
    _QUIT = {"/sair", "/exit", "sair", "exit", "quit", "q"}
    _processing: list[bool] = [False]

    in_buf = Buffer(
        name="leafar",
        multiline=False,
        completer=_SlashCompleter(),
        complete_while_typing=True,
    )

    # ── Key bindings ─────────────────────────────────────────────────────
    kb = KeyBindings()
    _is_confirming = Condition(lambda: bool(_waiting_confirm[0]))
    _is_free = Condition(lambda: not _waiting_confirm[0] and not _processing[0])

    @kb.add("a", filter=_is_confirming)
    def _accept(event: object) -> None:
        _confirm_val[0] = True
        _confirm_evt.set()

    @kb.add("r", filter=_is_confirming)
    def _reject(event: object) -> None:
        _confirm_val[0] = False
        _confirm_evt.set()

    @kb.add("enter", filter=_is_free)
    def _on_enter(event: object) -> None:  # type: ignore[override]
        text = in_buf.text.strip()
        if not text:
            return
        in_buf.reset()
        if text.lower() in _QUIT:
            _push("\n\x1b[2mAté mais!\x1b[0m\n")
            _app_ref[0].exit()  # type: ignore[union-attr]
            return
        # Exibe a mensagem do usuário na área de output
        _push(f"\n\x1b[36m│\x1b[0m \x1b[1m{text}\x1b[0m\n")
        _processing[0] = True

        def _run() -> None:
            try:
                _dispatch(text)
            finally:
                _processing[0] = False
                app = _app_ref[0]
                if app:
                    try:
                        app.invalidate()
                    except Exception:
                        pass

        threading.Thread(target=_run, daemon=True).start()

    # Scroll do output — eager=True garante prioridade sobre o BufferControl
    # Setas ↑↓ ficam para histórico do input; PgUp/PgDn rolam o output.
    @kb.add("pageup", eager=True)
    def _scroll_up(event: object) -> None:
        if _auto_scroll[0]:
            _scroll[0] = max(0, _line_count[0] - _win_h())
        _auto_scroll[0] = False
        _scroll[0] = max(0, _scroll[0] - 10)
        app = _app_ref[0]
        if app:
            app.invalidate()

    @kb.add("pagedown", eager=True)
    def _scroll_down(event: object) -> None:
        if not _auto_scroll[0]:
            max_s = max(0, _line_count[0] - _win_h())
            _scroll[0] = min(_scroll[0] + 10, max_s)
            if _scroll[0] >= max_s:
                _auto_scroll[0] = True
        app = _app_ref[0]
        if app:
            app.invalidate()

    @kb.add("c-c", filter=_is_free)
    @kb.add("c-d", filter=_is_free)
    def _on_quit(event: object) -> None:
        _push("\n\x1b[2mAté mais!\x1b[0m\n")
        _app_ref[0].exit()  # type: ignore[union-attr]

    # ── Dispatch de comandos ─────────────────────────────────────────────
    def _dispatch(text: str) -> None:
        nonlocal agent
        cmd = text.lower().strip()

        if cmd in ("/reset", "reset"):
            agent.reset()
            cc.print("[yellow]Histórico limpo.[/yellow]\n")
            return
        if cmd in ("/clear", "clear", "cls"):
            with _lock:
                _raw.clear()
                _line_count[0] = 0
            _scroll[0] = 0
            _auto_scroll[0] = True
            app = _app_ref[0]
            if app:
                app.invalidate()
            return
        if cmd == "/screenshot":
            text = "Tira um screenshot da tela atual do emulador e descreve o que vê."
        skill_name = cmd.lstrip("/")
        if skill_name in _SKILL_NAMES:
            from .agent import SKILLS
            agent.set_skill(skill_name)
            desc = SKILLS[skill_name]["description"]
            cc.print(f"\n[cyan]▸ Skill ativa: [bold]{skill_name}[/bold][/cyan] [dim]— {desc}[/dim]\n")
            return
        if cmd.startswith("/projeto"):
            parts = text.split(maxsplit=1)
            if len(parts) == 2:
                agent = _make_agent(parts[1], header=False)
                cc.print(f"[green]Projeto alterado para: {parts[1]}[/green]\n")
            else:
                cc.print(f"[dim]Projeto atual: {agent.project_path}[/dim]\n")
            return
        if cmd == "/contexto":
            ctx = agent.project_context or "(nenhum contexto salvo ainda)"
            cc.print(f"\n[bold]Contexto do projeto:[/bold]\n[dim]{ctx}[/dim]\n")
            return
        if cmd == "/tokens":
            t = agent._session_tokens
            cc.print(f"\n[dim]Tokens na sessão: {t:,} (~${t/1_000_000*3:.4f} USD)[/dim]\n")
            return
        if cmd == "/github-login":
            _handle_github_login(config)
            return
        if cmd == "/azure-login":
            _handle_azure_login(config)
            return
        if cmd == "/claude-login":
            cc.print("[dim]Abrindo login do Claude Code...[/dim]\n")
            subprocess.run([str(Path.home() / ".npm-global" / "bin" / "claude"), "/login"])
            return
        if cmd.startswith("/figma-json"):
            parts = text.split(maxsplit=1)
            if len(parts) < 2:
                cc.print("[dim]Uso: /figma-json <caminho>[/dim]\n")
            else:
                json_path = parts[1].strip()
                text = (
                    f"Use load_figma_json com o arquivo '{json_path}' "
                    "para analisar o design e gerar o código Android correspondente."
                )
                cc.print(f"[dim]Carregando: {json_path}[/dim]\n")
                cc.print("\n[bold blue]Leafar:[/bold blue]")
                agent.run(text)
                cc.print()
            return
        if text.startswith("!"):
            result = subprocess.run(text[1:].strip(), shell=True, capture_output=True, text=True)
            cc.print(result.stdout or result.stderr or "")
            return

        cc.print("\n[bold blue]Leafar:[/bold blue]")
        agent.run(text)
        cc.print()

    # ── Layout ───────────────────────────────────────────────────────────
    import shutil as _shutil

    def _win_h() -> int:
        """Altura real do output window = linhas do terminal - 2 (sep + input)."""
        return max(1, _shutil.get_terminal_size().lines - 2)

    def _get_scroll(w: "Window") -> int:
        """Auto-scroll baseado no tamanho real do terminal (sem depender de render_info)."""
        if _auto_scroll[0]:
            return max(0, _line_count[0] - _win_h())
        return _scroll[0]

    out_window = Window(
        content=FormattedTextControl(text=_get_output, focusable=False),
        wrap_lines=True,
        always_hide_cursor=True,
        get_vertical_scroll=_get_scroll,
    )

    def _sep_text() -> list:
        spin = _toolbar.get("spinner", "")
        if spin:
            return [
                ("class:sep", "─ "),
                ("class:sep.hint", spin),
                ("class:sep", " " + "─" * 180),
            ]
        if not _auto_scroll[0]:
            return [
                ("class:sep", "─── "),
                ("class:sep.hint", "↑↓ PgUp/PgDn · PgDn no fim = volta ao vivo"),
                ("class:sep", " ───"),
            ]
        # Avisa que tem conteúdo acima quando overflow
        if _line_count[0] > _win_h():
            return [
                ("class:sep", "─── "),
                ("class:sep.hint", "↑ PgUp para ver histórico"),
                ("class:sep", " ───"),
            ]
        return [("class:sep", "─" * 200)]

    sep = Window(
        content=FormattedTextControl(text=_sep_text),
        height=1,
        style="class:sep",
    )

    in_window = Window(
        content=BufferControl(buffer=in_buf, focusable=True),
        height=1,
        get_line_prefix=lambda _lineno, _wrap: [("class:prompt", "▸ ")],
    )

    layout = Layout(
        FloatContainer(
            content=HSplit([out_window, sep, in_window]),
            floats=[
                Float(
                    xcursor=True,
                    ycursor=True,
                    content=CompletionsMenu(max_height=12, scroll_offset=2),
                ),
            ],
        ),
        focused_element=in_window,
    )

    style = Style.from_dict({
        "prompt":   "bold cyan",
        "sep":      "#555555",
        "sep.hint": "#888888 italic",
    })

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=True,
        mouse_support=False,
    )
    _app_ref[0] = app
    agent._chat_app = app  # type: ignore[attr-defined]

    # ── Loop de refresh: garante re-render mesmo quando invalidate() falha ───
    def _refresh_loop() -> None:
        while True:
            time.sleep(0.1)
            a = _app_ref[0]
            if a is None:
                break
            try:
                a.invalidate()
            except Exception:
                pass

    threading.Thread(target=_refresh_loop, daemon=True).start()

    # ── Conteúdo inicial (vai aparecer na primeira renderização) ──────────
    # Nota: usar style= nas linhas com \ para evitar que \[ vire [ literal no Rich
    cc.print("      /\\        /\\", style="bold cyan")
    cc.print("     /  \\      /  \\", style="bold cyan")
    cc.print(
        "[cyan] ╔═══════════════════════╗[/cyan]\n"
        "[cyan] ║  [/cyan][bold white]◉[/bold white][cyan]               [/cyan][bold white]◉[/bold white][cyan]  ║[/cyan]\n"
        "[cyan] ╠═══════════════════════╣[/cyan]\n"
        "[cyan] ║  [/cyan][bold white]▸ rf[/bold white][cyan]  ·  [/cyan][bold white]leafar[/bold white][cyan]      ║[/cyan]\n"
        "[cyan] ║  [/cyan][dim]android  ai  agent[/dim][cyan]   ║[/cyan]\n"
        "[cyan] ╚═══════════════════════╝[/cyan]\n"
        "[dim]   powered by Rafael Alves[/dim]\n"
    )
    cc.print(f"[dim]projeto: {project}  ·  / para comandos  ·  sair para encerrar[/dim]\n")

    if agent._session_id:
        try:
            sp = Path(project).resolve() / ".rf_session.json"
            updated = _json.loads(sp.read_text()).get("updated_at", "")[:16] if sp.exists() else ""
        except Exception:
            updated = ""
        cc.print(f"[dim]↩ sessão retomada{f' ({updated})' if updated else ''} — /reset para começar do zero[/dim]")

    _print_active_mcps(figma_proc is not None, cc)

    # Força render inicial após o event loop subir (resolve o "precisa de resize")
    def _initial_render() -> None:
        time.sleep(0.05)
        a = _app_ref[0]
        if a:
            try:
                a.invalidate()
            except Exception:
                pass

    threading.Thread(target=_initial_render, daemon=True).start()

    try:
        app.run()
    finally:
        _app_ref[0] = None  # Para o _refresh_loop
        if figma_proc is not None:
            figma_proc.terminate()


# ---------------------------------------------------------------------------
# Shortcut commands
# ---------------------------------------------------------------------------

@main.command()
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def run(project: str) -> None:
    """Build, install, and launch the app in the emulator."""
    _make_agent(project).run(
        "Build the project, install it on the connected emulator/device, "
        "launch the app, and take a screenshot to confirm it started."
    )


@main.command()
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def screenshot(project: str) -> None:
    """Take a screenshot of the current emulator screen."""
    _make_agent(project).run(
        "Take a screenshot of the current emulator screen and describe what you see."
    )


@main.command()
@click.argument("screen")
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def navigate(screen: str, project: str) -> None:
    """Navigate to a specific screen in the running app.

    \b
    Example:
      leafar navigate ProfileScreen
    """
    _make_agent(project).run(
        f"Navigate to the '{screen}' screen in the running app. "
        "Take a screenshot before and after navigation."
    )


@main.command()
@click.argument("description")
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def debug(description: str, project: str) -> None:
    """Debug an issue in the app.

    \b
    Example:
      leafar debug "the date on the profile screen shows the wrong format"
    """
    _make_agent(project).run(
        f"Debug this issue: {description}\n\n"
        "Steps: navigate to the relevant screen, visually confirm the bug, "
        "trace it to the source code, fix it, then verify the fix visually."
    )


@main.command()
@click.argument("figma_url")
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
@click.option("--output", "-o", default=None, help="Output file path for generated code.")
def codegen(figma_url: str, project: str, output: str | None) -> None:
    """Generate Android UI code from a Figma design URL.

    \b
    Example:
      leafar codegen "https://www.figma.com/file/ABC123/..."
    """
    prompt = (
        f"Fetch this Figma design and generate the corresponding Android UI code: {figma_url}\n"
        "Analyse the design carefully (layout, spacing, colours, typography) and produce "
        "idiomatic Kotlin code that matches the project's existing architecture and UI toolkit."
    )
    if output:
        prompt += f"\nSave the generated code to: {output}"
    _make_agent(project).run(prompt)


# ---------------------------------------------------------------------------
# init — setup wizard
# ---------------------------------------------------------------------------

@main.command("figma-login")
def figma_login() -> None:
    """Autentica com o Figma via OAuth (MCP). Abre o browser para login."""
    from .config import Config
    from .figma_auth import login, is_logged_in

    if is_logged_in():
        console.print("[yellow]Você já está autenticado no Figma.[/yellow]")
        console.print("Para fazer login com outra conta: [bold]rf figma-logout[/bold]")
        return

    cfg = Config()
    if not cfg.figma_client_id or not cfg.figma_client_secret:
        console.print(
            "[red]FIGMA_CLIENT_ID e FIGMA_CLIENT_SECRET não encontrados no .env[/red]\n"
            "Adicione ao .env do projeto:\n"
            "  FIGMA_CLIENT_ID=...\n"
            "  FIGMA_CLIENT_SECRET=..."
        )
        return

    login(cfg.figma_client_id, cfg.figma_client_secret)


@main.command("figma-logout")
def figma_logout() -> None:
    """Remove a autenticação Figma salva localmente."""
    from .figma_auth import logout, is_logged_in
    if not is_logged_in():
        console.print("[dim]Nenhuma sessão Figma ativa.[/dim]")
        return
    logout()
    console.print("[green]Sessão Figma removida.[/green]")


@main.command("figma-status")
def figma_status() -> None:
    """Mostra o status da integração Figma MCP."""
    from .agent import _figma_local_available, _find_claude_cli
    local_ok = _figma_local_available()
    cli = _find_claude_cli()
    if local_ok:
        console.print("[green]✓ Figma desktop MCP ativo[/green] [dim](localhost:3845)[/dim]")
        console.print("[dim]  O agente usará o Figma MCP automaticamente.[/dim]")
    elif cli and "npm-global" in cli:
        console.print("[green]✓ Plugin figma@claude-plugins-official instalado[/green]")
        console.print(f"[dim]  claude: {cli}[/dim]")
        console.print("[dim]  Para autenticar no Figma, rode: rf ou pergunte 'autentique meu figma'[/dim]")
    else:
        console.print("[yellow]Plugin figma não encontrado.[/yellow]")
        console.print(
            "\nInstale com:\n"
            "  [bold]npm install -g @anthropic-ai/claude-code --prefix ~/.npm-global[/bold]\n"
            "  [bold]~/.npm-global/bin/claude plugin marketplace add anthropics/claude-plugins-official[/bold]\n"
            "  [bold]~/.npm-global/bin/claude plugin install figma@claude-plugins-official[/bold]"
        )


@main.command()
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def init(project: str) -> None:
    """Create a .env configuration file for this project."""
    create_env_file(project)


@main.command()
@click.option("--project", "-p", default=".", show_default=True, help="Android project path.")
def reset(project: str) -> None:
    """Apaga o histórico da sessão e começa do zero."""
    agent = _make_agent(project)
    agent.reset()
    console.print("[yellow]Sessão apagada.[/yellow] Próximo comando começa do zero.")


# ---------------------------------------------------------------------------
# hook — instala/remove o command_not_found_handler no zsh
# ---------------------------------------------------------------------------

_HOOK_START = "# >>> rf hook start <<<"
_HOOK_END   = "# >>> rf hook end <<<"
_HOOK_BODY  = """\
# >>> rf hook start <<<

# ── Logo no lado direito do prompt quando em projeto rf ──────────────────
function _rf_update_rprompt() {
    if [[ -f ".env" ]] && grep -q "ANTHROPIC_API_KEY" ".env" 2>/dev/null; then
        RPROMPT="%F{cyan}/\\ /\\%f %F{cyan}╔%f%F{white}◉%f%F{cyan}═%f%F{white}◉%f%F{cyan}╗%f %F{cyan}▸rf%f  "
    else
        RPROMPT=""
    fi
}
precmd_functions+=(_rf_update_rprompt)

# ── ZLE widget: intercepta Enter e redireciona linguagem natural pro rf ──
# Comandos de shell que NUNCA devem ir pro rf (builtins + comuns)
_rf_shell_cmds=(
    source . export cd alias unalias echo printf read set unset exec eval
    exit return shift test builtin command type which hash bind trap
    ls cat grep find mv cp rm mkdir touch git python python3 pip pip3
    brew curl wget ssh scp rsync tar zip unzip open sudo env
    adb gradle gradlew java javac kotlin kotlinc noglob
)

function _rf_smart_enter() {
    local input="$BUFFER"
    local first="${input%% *}"

    if [[ -f ".env" ]] && grep -q "ANTHROPIC_API_KEY" ".env" 2>/dev/null; then
        if [[ "$first" == "rf" ]]; then
            # Usuário digitou rf explicitamente — usa noglob pra evitar
            # expansão de ? * [] no resto da frase
            BUFFER="noglob ${input}"
        elif ! (( $+commands[$first] )) \\
            && ! (( $+aliases[$first] )) \\
            && ! (( $+functions[$first] )) \\
            && ! (( $+builtins[$first] )) \\
            && ! (( $_rf_shell_cmds[(Ie)$first] )); then
            # Linguagem natural — redireciona pro rf com args entre aspas
            BUFFER="noglob rf ${(q)input}"
        fi
    fi
    zle accept-line
}
zle -N _rf_smart_enter
bindkey "^M" _rf_smart_enter
bindkey "^J" _rf_smart_enter

# >>> rf hook end <<<"""


@main.command()
def hook() -> None:
    """Instala o hook no zsh para dispensar o prefixo 'rf'.

    \b
    Após instalar, dentro de qualquer projeto configurado com 'rf init'
    você pode digitar diretamente no terminal:

    \b
      você consegue criar um mock de compra no billing?
      roda o app e me fala o que você vê na primeira tela
      tem um bug na tela de checkout — corrige

    Para remover o hook: rf unhook
    """
    zshrc = Path.home() / ".zshrc"
    content = zshrc.read_text() if zshrc.exists() else ""

    if _HOOK_START in content:
        console.print("[yellow]Hook já está instalado em ~/.zshrc[/yellow]")
        console.print("Para remover: [bold]rf unhook[/bold]")
        return

    with zshrc.open("a") as f:
        f.write(f"\n{_HOOK_BODY}\n")

    console.print("[green]Hook instalado em ~/.zshrc[/green]")
    console.print(
        "\nRoda o comando abaixo para ativar na sessão atual:\n"
        "[bold cyan]source ~/.zshrc[/bold cyan]"
    )
    console.print(
        "\nDepois é só digitar direto no terminal dentro do projeto — sem 'rf'."
    )


@main.command()
def unhook() -> None:
    """Remove o hook do zsh instalado por 'rf hook'."""
    zshrc = Path.home() / ".zshrc"
    if not zshrc.exists() or _HOOK_START not in zshrc.read_text():
        console.print("[dim]Hook não encontrado em ~/.zshrc[/dim]")
        return

    lines = zshrc.read_text().splitlines(keepends=True)
    inside = False
    cleaned = []
    for line in lines:
        if _HOOK_START in line:
            inside = True
        if not inside:
            cleaned.append(line)
        if _HOOK_END in line:
            inside = False

    zshrc.write_text("".join(cleaned))
    console.print("[green]Hook removido de ~/.zshrc[/green]")
    console.print("Rode [bold cyan]source ~/.zshrc[/bold cyan] para aplicar.")
