"""Leafar - Intelligent Android Development CLI powered by Rafael Alves."""

__version__ = "0.2.4"
