# sage_setup: distribution = sagemath-environment
r"""
Feature for testing the presence of ``jmol``
"""
import os

from . import StaticFile


class JmolDataJar(StaticFile):
    r"""
    A :class:`~sage.features.Feature` which describes the presence of
    JmolData.jar in a few standard locations.

    EXAMPLES::

        sage: from sage.features.jmol import JmolDataJar
        sage: bool(JmolDataJar().is_present())  # needs jmol
        True
    """

    def __init__(self):
        r"""
        TESTS::

            sage: from sage.features.jmol import JmolDataJar
            sage: isinstance(JmolDataJar(), JmolDataJar)
            True
        """
        from sage.env import sage_data_paths, JMOL_DIR

        jmol_search_path = JMOL_DIR or list(sage_data_paths('jmol'))

        StaticFile.__init__(
            self, name='jmol',
            filename='JmolData.jar',
            search_path=jmol_search_path,
            spkg='jmol',
            type='optional',
            description="Java viewer for chemical structures in 3D")


def all_features():
    return [JmolDataJar()]
