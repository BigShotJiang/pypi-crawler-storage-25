//! RSGI `response_bytes` / `response_str` / `response_empty` helpers (Granian RSGI spec).

use pyo3::prelude::*;
use pyo3::types::{PyList, PyString, PyTuple};

pub async fn send_text(
    protocol: &Py<PyAny>,
    status: u16,
    text: &str,
    content_type: &str,
) -> PyResult<PyObject> {
    if text.is_empty() {
        return send_empty(protocol, status, Some(content_type)).await;
    }
    send_str(protocol, status, text, content_type).await
}

pub async fn send_str(
    protocol: &Py<PyAny>,
    status: u16,
    text: &str,
    content_type: &str,
) -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let p = protocol.bind(py);
        let h = build_headers_ct(py, Some(content_type))?;
        p.getattr("response_str")?.call1((status, h, text))?;
        Ok(Py::from(pyo3::types::PyNone::get(py)).into_any())
    })
}

pub async fn send_empty(
    protocol: &Py<PyAny>,
    status: u16,
    content_type: Option<&str>,
) -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let p = protocol.bind(py);
        let h = build_headers_ct(py, content_type)?;
        p.getattr("response_empty")?.call1((status, h))?;
        Ok(Py::from(pyo3::types::PyNone::get(py)).into_any())
    })
}

pub async fn send_bytes(
    protocol: &Py<PyAny>,
    status: u16,
    body: &[u8],
    content_type: &str,
) -> PyResult<PyObject> {
    if body.is_empty() {
        return send_empty(protocol, status, Some(content_type)).await;
    }
    Python::with_gil(|py| {
        let p = protocol.bind(py);
        let h = build_headers_ct(py, Some(content_type))?;
        p.getattr("response_bytes")?.call1((status, h, body))?;
        Ok(Py::from(pyo3::types::PyNone::get(py)).into_any())
    })
}

/// 405 with [`Allow`][1] and a small plain body (RFC 9110 §15.5.6).
///
/// [1]: https://www.rfc-editor.org/rfc/rfc9110#name-allow
pub async fn send_405_method_not_allowed(
    protocol: &Py<PyAny>,
    allow: &[String],
) -> PyResult<PyObject> {
    let headers = vec![
        ("allow".to_string(), allow.join(", ")),
        (
            "content-type".to_string(),
            "text/plain; charset=utf-8".to_string(),
        ),
    ];
    send_with_headers(protocol, 405, b"Method Not Allowed", headers).await
}

/// RSGI `response_bytes` / `response_empty` with a full `[(name, value), ...]` header list.
pub async fn send_with_headers(
    protocol: &Py<PyAny>,
    status: u16,
    body: &[u8],
    headers: Vec<(String, String)>,
) -> PyResult<PyObject> {
    if body.is_empty() {
        return send_empty_with_header_pairs(protocol, status, headers).await;
    }
    Python::with_gil(|py| {
        let p = protocol.bind(py);
        let h = build_header_list_from_pairs(py, &headers)?;
        p.getattr("response_bytes")?.call1((status, h, body))?;
        Ok(Py::from(pyo3::types::PyNone::get(py)).into_any())
    })
}

async fn send_empty_with_header_pairs(
    protocol: &Py<PyAny>,
    status: u16,
    headers: Vec<(String, String)>,
) -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let p = protocol.bind(py);
        let h = build_header_list_from_pairs(py, &headers)?;
        p.getattr("response_empty")?.call1((status, h))?;
        Ok(Py::from(pyo3::types::PyNone::get(py)).into_any())
    })
}

/// HEAD: no message body, `Content-Length` as if a GET returned `full_body_len` (RFC 9110).
pub async fn send_head_simple(
    protocol: &Py<PyAny>,
    status: u16,
    full_body_len: usize,
    content_type: &str,
) -> PyResult<PyObject> {
    let headers = vec![
        ("content-type".to_string(), content_type.to_string()),
        ("content-length".to_string(), full_body_len.to_string()),
    ];
    send_empty_with_header_pairs(protocol, status, headers).await
}

/// Same as [`send_head_simple`] for structured responses: strip body, set `content-length` from `body.len()`.
pub async fn send_head_with_headers(
    protocol: &Py<PyAny>,
    status: u16,
    full_body: &[u8],
    mut headers: Vec<(String, String)>,
) -> PyResult<PyObject> {
    let len = full_body.len();
    headers.retain(|(k, _)| !k.eq_ignore_ascii_case("content-length"));
    headers.push(("content-length".to_string(), len.to_string()));
    send_empty_with_header_pairs(protocol, status, headers).await
}

fn build_header_list_from_pairs<'py>(
    py: Python<'py>,
    pairs: &[(String, String)],
) -> PyResult<Bound<'py, PyList>> {
    let out = PyList::empty(py);
    for (k, v) in pairs {
        let name: String = if k.eq_ignore_ascii_case("set-cookie") {
            "set-cookie".to_string()
        } else {
            k.to_ascii_lowercase()
        };
        let pair = PyTuple::new(
            py,
            [PyString::new(py, &name), PyString::new(py, v.as_str())],
        )?;
        out.append(pair)?;
    }
    Ok(out)
}

fn build_headers_ct<'py>(
    py: Python<'py>,
    content_type: Option<&str>,
) -> PyResult<Bound<'py, PyList>> {
    match content_type {
        None => Ok(PyList::empty(py)),
        Some(ct) => {
            let pair = PyTuple::new(
                py,
                [PyString::new(py, "content-type"), PyString::new(py, ct)],
            )?;
            Ok(PyList::new(py, [pair])?)
        }
    }
}
