/**
 * RecalibrateButton -- Settings -> Voice surface for triggering a
 * fresh calibration run on the current daemon (per spec §8.5).
 *
 * Operator clicks -> confirm dialog -> POST /api/voice/calibration/start
 * with the resolved active ``mind_id`` -> on HTTP 202, emit a toast
 * pointing the operator at the onboarding wizard step (where progress
 * is rendered).
 *
 * Returns 409 Conflict when a calibration is already in flight; the
 * UI surfaces the conflict gracefully without queuing.
 *
 * History: introduced in v0.30.24 as T3.10/§8.5 wire-up of mission
 * `MISSION-voice-self-calibrating-system-2026-05-05.md`. v0.31.7 T2.2
 * (paranoid round 2 M2 closure) made ``mindId`` a REQUIRED prop —
 * pre-v0.31.7 the default value was ``"default"`` (anti-pattern #35,
 * 5th occurrence of the sentinel-mind-id bug class). Page mounts MUST
 * thread the resolved active mind id from ``/api/onboarding/state`` so
 * the calibration profile lands at ``<data_dir>/<mind_id>/`` — not at
 * the orphan ``<data_dir>/default/`` slot.
 */

import { useCallback, useState } from "react";
import { useTranslation } from "react-i18next";
import { Loader2Icon, RefreshCcwIcon } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useDashboardStore } from "@/stores/dashboard";

export interface RecalibrateButtonProps {
  /**
   * Resolved active ``mind_id`` of the daemon. REQUIRED — never default
   * to ``"default"`` (anti-pattern #35). The page mount is responsible
   * for fetching ``/api/onboarding/state`` and threading the resolved
   * value here. The backend's ``_shared.resolve_active_mind_id_for_request``
   * remains a safety net but should never need to fire on this path.
   */
  mindId: string;
}

export function RecalibrateButton({ mindId }: RecalibrateButtonProps) {
  const { t } = useTranslation(["settings"]);
  const startCalibration = useDashboardStore((s) => s.startCalibration);
  const featureFlag = useDashboardStore((s) => s.calibrationFeatureFlag);
  const [busy, setBusy] = useState(false);
  const [confirming, setConfirming] = useState(false);

  const handleStart = useCallback(async () => {
    setBusy(true);
    try {
      const jobId = await startCalibration({ mind_id: mindId });
      if (jobId !== null) {
        toast.success(t("settings:recalibrate.startSuccess"));
      } else {
        toast.error(t("settings:recalibrate.startFailed"));
      }
    } finally {
      setBusy(false);
      setConfirming(false);
    }
  }, [startCalibration, mindId, t]);

  // P6 (v0.30.34) — Mission §10.2 #12: the recalibrate button stays
  // visible regardless of the wizard-mount flag. When the flag is
  // OFF the button is disabled with a tooltip pointing at the
  // CalibrationWizardCard sibling toggle, so operators see the
  // surface exists + understand what gates it (instead of guessing
  // why a section disappeared).
  //
  // rc.13 (closes the rc.11 EIXO 2 bug-class miss): also gate on
  // ``platform_supported``. Pre-rc.13 the Win/macOS operator could
  // see the button enabled (because flag.enabled is True by default)
  // and click it, only to have the wizard mount, click Start, and
  // silently fall through to FALLBACK from
  // ``DiagPrerequisiteError`` (Linux-only bash diag). Same exact
  // bug class as rc.11 EIXO 2 in ``VoiceStep.tsx``, missed on this
  // sibling surface. Pre-rc.12 daemons that don't ship
  // ``platform_supported`` default to True via the zod schema —
  // backward compat preserved.
  const platformSupported = featureFlag?.platform_supported ?? true;
  const flagEnabled =
    featureFlag !== null && featureFlag.enabled && platformSupported;
  const tooltip = (() => {
    if (featureFlag === null || !featureFlag.enabled) {
      return t("settings:recalibrate.flagOffTooltip");
    }
    if (!platformSupported) {
      return t("settings:recalibrate.platformUnsupportedTooltip");
    }
    return undefined;
  })();

  return (
    <section
      data-testid="settings-recalibrate-card"
      className="rounded-[var(--svx-radius-lg)] border border-[var(--svx-color-border-default)] bg-[var(--svx-color-bg-surface)] p-4"
    >
      <header className="flex items-start gap-3">
        <RefreshCcwIcon className="size-5 shrink-0 text-[var(--svx-color-text-secondary)]" />
        <div className="flex-1">
          <h2 className="text-sm font-semibold text-[var(--svx-color-text-primary)]">
            {t("settings:recalibrate.title")}
          </h2>
          <p className="mt-1 text-xs text-[var(--svx-color-text-tertiary)]">
            {t("settings:recalibrate.description")}
          </p>
        </div>
      </header>

      <div className="mt-4 flex items-center justify-end gap-2">
        {confirming ? (
          <>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setConfirming(false)}
              data-testid="settings-recalibrate-cancel"
            >
              {t("settings:recalibrate.cancelButton")}
            </Button>
            <Button
              type="button"
              variant="default"
              disabled={busy}
              onClick={() => void handleStart()}
              data-testid="settings-recalibrate-confirm"
            >
              {busy ? (
                <Loader2Icon className="size-4 animate-spin" />
              ) : (
                t("settings:recalibrate.confirmButton")
              )}
            </Button>
          </>
        ) : (
          <Button
            type="button"
            variant="outline"
            onClick={() => setConfirming(true)}
            disabled={!flagEnabled}
            title={tooltip}
            aria-disabled={!flagEnabled}
            data-testid="settings-recalibrate-toggle"
          >
            {t("settings:recalibrate.button")}
          </Button>
        )}
      </div>

      <p className="mt-3 text-[11px] text-[var(--svx-color-text-tertiary)]">
        {flagEnabled
          ? t("settings:recalibrate.note")
          : !platformSupported && featureFlag?.enabled
            ? t("settings:recalibrate.platformUnsupportedNote")
            : t("settings:recalibrate.flagOffNote")}
      </p>
    </section>
  );
}
