import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import {
  AlertTriangleIcon,
  DollarSignIcon,
  BrainIcon,
  MessageSquareIcon,
  ActivityIcon,
  WifiOffIcon,
  RefreshCwIcon,
  XIcon,
} from "lucide-react";
import { useDashboardStore } from "@/stores/dashboard";
import { StatCard, StatCardSkeleton, HealthGrid, ActivityFeed, MetricChart, CognitiveTimeline, CostByPhaseCard } from "@/components/dashboard";
import { UsageCard } from "@/components/dashboard/usage-card";
import { formatUptime, formatCost, formatNumber } from "@/lib/format";

import { WelcomeBanner } from "@/components/dashboard/welcome-banner";
import { MindAliveCard } from "@/components/dashboard/mind-alive-card";
import { ChannelStatusCard } from "@/components/dashboard/channel-status";
import { useOnboardingProgress } from "@/hooks/use-onboarding";
import { useOnboardingState } from "@/hooks/use-resolved-mind-id";

/**
 * Smart stat value display.
 *
 * - value > 0 → formatted value
 * - value === 0 + has lifetime activity → "0" (day reset, not "never used")
 * - value === 0 + no lifetime activity → neverUsedLabel ("—" / setup hint)
 */
function smartValue(
  value: number,
  formatter: (n: number) => string,
  neverUsedLabel: string,
  hasLifetimeActivity: boolean,
): string {
  if (value > 0) return formatter(value);
  if (hasLifetimeActivity) return formatter(0);
  return neverUsedLabel;
}

export default function OverviewPage() {
  const { t } = useTranslation(["overview", "common"]);
  const navigate = useNavigate();
  const status = useDashboardStore((s) => s.status);
  const healthChecks = useDashboardStore((s) => s.healthChecks);
  const connected = useDashboardStore((s) => s.connected);
  const recentEvents = useDashboardStore((s) => s.recentEvents);
  const costData = useDashboardStore((s) => s.costData);
  // v0.31.6 T3.2 (M3.c): voice-configuration warning surfaced when the
  // daemon's defensive ``voice_configured: false`` signal landed during
  // /api/onboarding/complete. ``null`` when no warning is pending.
  const voiceWarning = useDashboardStore((s) => s.voiceWarning);
  const clearVoiceWarning = useDashboardStore((s) => s.clearVoiceWarning);
  const {
    step1, step2, step3, completedCount, allDone,
    showBanner, showAliveCard, setDismissed,
  } = useOnboardingProgress();

  // v0.32.0 BT.B.1 — read /api/onboarding/state via the shared
  // singleton hook instead of a page-local lazy ``api.get`` import.
  // The brief constraint: ``ZERO api.get(...).then(...) for
  // onboarding state should remain in pages/`` — only the hook
  // implementation reads it. The hook's snapshot is reused across
  // every consumer on the page (settings, onboarding, overview),
  // so the redirect check costs at most one ``state.complete``
  // read once the hook resolves.
  const { state: onboardingPayload } = useOnboardingState();
  useEffect(() => {
    if (!status) return;
    if (onboardingPayload === null) return;
    const noProvider =
      !status.llm_calls_today &&
      !status.llm_cost_today &&
      !status.memory_concepts &&
      !status.messages_today;
    if (noProvider && step1 === "pending" && !onboardingPayload.complete) {
      navigate("/onboarding", { replace: true });
    }
  }, [status, step1, navigate, onboardingPayload]);

  // ── Transition: WelcomeBanner → MindAliveCard (Cenário A vs B) ──
  // Cenário A: user WITNESSES allDone becoming true → animated transition
  // Cenário B: allDone already true on mount → show MindAliveCard directly, no animation
  const wasAllDoneOnMount = useRef(allDone);
  const [transitioning, setTransitioning] = useState(false);
  const [showExiting, setShowExiting] = useState(false);
  const [animateAlive, setAnimateAlive] = useState(false);

  // ── Connection timeout: show error state if no data after 10s ──
  const [timedOut, setTimedOut] = useState(false);
  useEffect(() => {
    if (status || connected) {
      setTimedOut(false);
      return;
    }
    const timer = setTimeout(() => setTimedOut(true), 10_000);
    return () => clearTimeout(timer);
  }, [status, connected]);

  useEffect(() => {
    // Only trigger transition if allDone CHANGED to true (not on mount)
    if (allDone && !wasAllDoneOnMount.current && !transitioning) {
      // Step 1: Show completed state for 1.5s
      setTransitioning(true);
      const exitTimer = setTimeout(() => {
        setShowExiting(true);
        // Step 2: After exit animation (400ms), show alive card
        const enterTimer = setTimeout(() => {
          setShowExiting(false);
          setTransitioning(false);
          setAnimateAlive(true);
        }, 400);
        return () => clearTimeout(enterTimer);
      }, 1500);
      return () => clearTimeout(exitTimer);
    }
  }, [allDone, transitioning]);

  // ── Immediate refresh when onboarding banner is visible ──
  // Default health poll is 10s — too slow for onboarding responsiveness.
  // Trigger immediate status + health refresh on mount when banner shows.
  useEffect(() => {
    if (showBanner && connected) {
      void import("@/hooks/use-websocket").then(({ refreshStatus, refreshHealth }) => {
        void refreshStatus();
        void refreshHealth();
      });
    }
    // Only on mount + when showBanner/connected change
  }, [showBanner, connected]);

  /** True when engine just started with no activity */
  const isFresh = status
    ? status.messages_today === 0 && status.memory_concepts === 0 && status.llm_calls_today === 0
    : false;

  // Determine what to show in the onboarding slot
  const showBannerNow = (showBanner || transitioning) && !showExiting;
  const showAliveNow = (showAliveCard && !transitioning) || false;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">{t("title")}</h1>
        <p className="text-sm text-[var(--svx-color-text-secondary)]">
          {allDone
            ? t("subtitle")
            : isFresh
              ? t("subtitleFresh")
              : t("subtitleProgress")}
        </p>
      </div>

      {/* Voice-not-configured warning — surfaced from POST /api/onboarding/complete
        * when the daemon reports voice was requested but the pipeline is not
        * registered. Operator-actionable; links to /voice for troubleshooting. */}
      {voiceWarning?.kind === "voice_not_configured" && (
        <div
          role="alert"
          data-testid="voice-warning-banner"
          className="flex items-start gap-3 rounded-[var(--svx-radius-lg)] border border-yellow-500/40 bg-yellow-500/10 p-4 text-sm text-[var(--svx-color-text-primary)]"
        >
          <AlertTriangleIcon
            aria-hidden="true"
            className="mt-0.5 size-4 shrink-0 text-yellow-600 dark:text-yellow-500"
          />
          <div className="flex-1 space-y-1">
            <div className="font-medium">{t("voice_warning.title")}</div>
            <div className="text-[var(--svx-color-text-secondary)]">
              {t("voice_warning.body")}
            </div>
            <Link
              to="/voice"
              className="inline-block pt-1 text-xs font-medium text-[var(--svx-color-brand-primary)] hover:underline"
            >
              {t("voice_warning.troubleshoot_cta")}
            </Link>
          </div>
          <button
            type="button"
            onClick={clearVoiceWarning}
            aria-label={t("voice_warning.dismiss")}
            className="rounded p-1 text-[var(--svx-color-text-tertiary)] transition-colors hover:bg-[var(--svx-color-bg-surface-hover)] hover:text-[var(--svx-color-text-primary)]"
          >
            <XIcon aria-hidden="true" className="size-4" />
          </button>
        </div>
      )}

      {/* Onboarding slot — WelcomeBanner or MindAliveCard with animated transition */}
      {showBannerNow && connected && (
        <div
          className={showExiting ? "animate-[onboarding-exit_400ms_ease-out_forwards]" : ""}
          style={{ minHeight: transitioning ? "200px" : undefined }}
        >
          <WelcomeBanner
            step1={step1}
            step2={step2}
            step3={step3}
            completedCount={completedCount}
            onDismiss={() => setDismissed(true)}
          />
        </div>
      )}
      {showAliveNow && connected && (
        <div className={animateAlive ? "animate-[onboarding-enter_400ms_ease-out_both]" : ""}>
          <MindAliveCard
            animate={animateAlive}
            onDismiss={() => setDismissed(true)}
          />
        </div>
      )}

      {/* Connection error — shown after 10s timeout with no data */}
      {timedOut && !status && (
        <div className="flex flex-col items-center justify-center gap-3 rounded-[var(--svx-radius-lg)] border border-dashed border-[var(--svx-color-border-default)] bg-[var(--svx-color-bg-surface)] p-8 text-center">
          <WifiOffIcon className="size-8 text-[var(--svx-color-text-disabled)]" />
          <h3 className="text-sm font-medium text-[var(--svx-color-text-primary)]">
            {t("connectionError.title")}
          </h3>
          <p className="max-w-sm text-xs text-[var(--svx-color-text-secondary)]">
            {t("connectionError.subtitle")}
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-1 inline-flex items-center gap-1.5 rounded-md bg-[var(--svx-color-brand-primary)] px-3 py-1.5 text-xs font-medium text-[var(--svx-color-text-inverse)] transition-opacity hover:opacity-90"
          >
            <RefreshCwIcon className="size-3" />
            {t("connectionError.retry")}
          </button>
        </div>
      )}

      {/* 4 Stat Cards — skeleton while loading */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {!status ? (
          <>
            <StatCardSkeleton />
            <StatCardSkeleton />
            <StatCardSkeleton />
            <StatCardSkeleton />
          </>
        ) : (
          <>
            {/* Engine Status */}
            <StatCard
              title={t("cards.engineStatus")}
              value={connected ? t("common:status.online") : t("common:status.offline")}
              subtitle={
                isFresh && connected
                  ? t("cards.justBooted")
                  : t("cards.uptime", { duration: formatUptime(status.uptime_seconds) })
              }
              status={connected ? "green" : "red"}
              icon={<ActivityIcon className="size-4" />}
            />

            {/* Messages */}
            <StatCard
              title={t("cards.messages")}
              value={smartValue(status.messages_today, formatNumber, t("cards.messagesFresh"), status.has_lifetime_activity ?? false)}
              subtitle={
                status.active_conversations > 0
                  ? t("cards.activeCount", { count: formatNumber(status.active_conversations) })
                  : t("cards.messagesHint")
              }
              icon={<MessageSquareIcon className="size-4" />}
            />

            {/* Brain */}
            <StatCard
              title={t("cards.brainConcepts")}
              value={smartValue(status.memory_concepts, formatNumber, t("cards.brainFresh"), status.has_lifetime_activity ?? false)}
              subtitle={
                status.memory_concepts > 0
                  ? t("cards.episodeCount", { count: status.memory_episodes })
                  : t("cards.brainHint")
              }
              icon={<BrainIcon className="size-4" />}
            />

            {/* LLM Cost */}
            <StatCard
              title={t("cards.llmCost")}
              value={smartValue(status.llm_cost_today, formatCost, t("cards.costFresh"), status.has_lifetime_activity ?? false)}
              subtitle={
                status.llm_calls_today > 0
                  ? t("cards.costSubtitle", { calls: formatNumber(status.llm_calls_today), tokens: formatNumber(status.tokens_today) })
                  : t("cards.costHint")
              }
              icon={<DollarSignIcon className="size-4" />}
            />
          </>
        )}
      </div>

      {/* Usage + Health — side by side for compact layout */}
      <div className="grid gap-4 lg:grid-cols-2">
        {status && <UsageCard />}
        <HealthGrid checks={healthChecks} />
      </div>

      {/* Cost Chart + Phase breakdown side by side on desktop */}
      <div className="grid gap-4 lg:grid-cols-2">
        <MetricChart
          title={t("chart.costTitle")}
          data={costData}
          color="var(--chart-1)"
          unit="$"
          label={t("chart.costLabel")}
        />
        <CostByPhaseCard />
      </div>

      {/* Channel Status + Live Feed (left) | Cognitive Timeline (right) */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex flex-col gap-4 lg:col-span-1">
          <ChannelStatusCard />
          <ActivityFeed events={recentEvents} />
        </div>
        <div className="lg:col-span-2">
          <CognitiveTimeline className="h-full" />
        </div>
      </div>


    </div>
  );
}
