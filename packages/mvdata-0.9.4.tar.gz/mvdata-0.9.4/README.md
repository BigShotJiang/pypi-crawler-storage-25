# mvdata

Python library for working with Gracia multi-view video datasets.

The package provides readers, writers, conversion tools, and GPU-aware video
decode helpers for the dataset layouts documented in the `docs` directory.

## Release

Prepare the next release with the local helper script:

```bash
UV_PROJECT_ENVIRONMENT=.venv312 uv run python scripts/release.py patch --dry-run
UV_PROJECT_ENVIRONMENT=.venv312 uv run python scripts/release.py patch --push
```

Use `minor` or `major` instead of `patch` for larger version bumps, or pass an
explicit version with `--version 1.2.3`. The script updates `pyproject.toml` and
`uv.lock` through `uv`, runs the tests and build, creates a `Release vX.Y.Z`
commit, creates an annotated `vX.Y.Z` tag, and pushes the branch and tag when
`--push` is set.

Pushing the tag triggers the GitHub Actions build, PyPI publish, and GitHub
Release workflow.
