from typing import Optional, List
from pathlib import Path
import shutil
import numpy as np
from PIL import Image

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
    # Fallback: simple wrapper that does nothing
    def tqdm(iterable, **kwargs):
        return iterable

from .writer_base import DatasetWriter
from .dataset_base import Dataset
from .per_frame import LegacyDataset


class LegacyDatasetWriter(DatasetWriter):
    """Writer for Legacy dataset convention (per-frame images)."""
    
    def __init__(self,
                 input_dataset: Dataset,
                 output_path: Path,
                 copy_meta: bool = True,
                 stash_policy: str = "copy",
                 stash_num_frames: int = 10,
                 max_workers: Optional[int] = None,
                 stream_ids: Optional[List[int]] = None,
                 streams_per_batch: int = 4,
                 maintain_frame_numbers: bool = True,
                 start_frame: Optional[int] = None,
                 end_frame: Optional[int] = None,
                 image_format: str = "png",
                 image_quality: int = 95):
        """
        Initialize Legacy dataset writer.
        
        Args:
            input_dataset: Source dataset to read from
            output_path: Path where the new dataset will be written
            copy_meta: Whether to copy meta folder from source dataset
            stash_policy: "generate", "copy", or "ignore"
            stash_num_frames: Number of stash frames to generate when policy is "generate"
            max_workers: Number of parallel workers for decoding input dataset
            stream_ids: List of stream IDs to write, or None for all streams
            streams_per_batch: Number of streams to process simultaneously (default: 4)
            maintain_frame_numbers: If True, keep original frame numbers; if False, start from 0
            start_frame: Start frame from source dataset (inclusive), or None for dataset start
            end_frame: End frame from source dataset (inclusive), or None for dataset end
            image_format: Output image format: "png", "jpg", or "tiff" (default: "png")
            image_quality: Quality for JPEG compression (1-100, default: 95, ignored for PNG/TIFF)
        """
        super().__init__(
            input_dataset,
            output_path,
            copy_meta,
            stash_policy,
            stash_num_frames,
            max_workers,
        )
        
        self.stream_ids = stream_ids
        self.streams_per_batch = streams_per_batch
        self.maintain_frame_numbers = maintain_frame_numbers
        self.start_frame = start_frame
        self.end_frame = end_frame
        
        # Validate image format
        if image_format.lower() not in ["png", "jpg", "jpeg", "tiff", "tif"]:
            raise ValueError(
                f"Unsupported image format: {image_format}. "
                f"Supported formats: png, jpg, jpeg, tiff, tif"
            )
        self.image_format = image_format.lower()
        
        # Normalize JPEG format names
        if self.image_format in ["jpg", "jpeg"]:
            self.image_format = "jpg"
            self.image_ext = ".jpg"
        elif self.image_format in ["tiff", "tif"]:
            self.image_format = "tiff"
            self.image_ext = ".tiff"
        else:  # png
            self.image_ext = ".png"
        
        self.image_quality = max(1, min(100, image_quality))

    def _resumable_config(self):
        return {
            "stream_ids": self.stream_ids,
            "start_frame": self.start_frame,
            "end_frame": self.end_frame,
            "maintain_frame_numbers": self.maintain_frame_numbers,
            "image_format": self.image_format,
            "image_quality": self.image_quality,
        }

    def _format_frame_name(self, frame_number: int) -> str:
        """Format frame folder name with 8-digit zero padding."""
        return f"{frame_number:08d}"
    
    def _format_stream_name(self, stream_id: int) -> str:
        """Format stream filename with 3-digit zero padding."""
        return f"{stream_id:03d}{self.image_ext}"
    
    def _split_streams_into_batches(self, stream_ids: List[int]) -> List[List[int]]:
        """
        Split stream IDs into batches for processing.
        
        Args:
            stream_ids: List of all stream IDs to write
            
        Returns:
            List of stream ID batches
        """
        batches = []
        for i in range(0, len(stream_ids), self.streams_per_batch):
            batch = stream_ids[i:i + self.streams_per_batch]
            batches.append(batch)
        return batches
    
    def _copy_meta_folder(self):
        super()._copy_meta_folder()
    
    def _save_image(self, image_array: np.ndarray, output_path: Path):
        """
        Save numpy array as image file.
        
        Args:
            image_array: Numpy array in HWC format
            output_path: Path to save the image
        """
        # Convert numpy array to PIL Image
        if image_array.dtype == np.uint16:
            # 16-bit image
            if self.image_format == "png":
                # PNG supports 16-bit
                img = Image.fromarray(image_array, mode='RGB')
            elif self.image_format == "tiff":
                # TIFF supports 16-bit
                img = Image.fromarray(image_array, mode='RGB')
            else:
                # JPEG doesn't support 16-bit, convert to 8-bit
                image_array = (image_array / 256).astype(np.uint8)
                img = Image.fromarray(image_array, mode='RGB')
        else:
            # 8-bit or other
            img = Image.fromarray(image_array, mode='RGB')
        
        # Save with appropriate options
        if self.image_format == "jpg":
            img.save(output_path, format="JPEG", quality=self.image_quality, optimize=True)
        elif self.image_format == "png":
            img.save(output_path, format="PNG", compress_level=6)
        elif self.image_format == "tiff":
            img.save(output_path, format="TIFF", compression="lzw")
    
    def write(self) -> LegacyDataset:
        """
        Write the dataset in Legacy convention format.
        
        Returns:
            Instance of the newly created LegacyDataset
        """
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Get all available frame ranges from input dataset
        input_ranges = self.input_dataset.get_frame_ranges()
        if not input_ranges:
            raise ValueError("Input dataset has no frame ranges")
        
        # Determine dataset bounds
        dataset_min_frame = input_ranges[0][0]
        dataset_max_frame = input_ranges[-1][1]
        
        # Determine actual range to process
        actual_start = self.start_frame if self.start_frame is not None else dataset_min_frame
        actual_end = self.end_frame if self.end_frame is not None else dataset_max_frame
        
        # Validate range
        if actual_start < dataset_min_frame or actual_end > dataset_max_frame:
            raise ValueError(
                f"Requested range [{actual_start}, {actual_end}] outside "
                f"dataset range [{dataset_min_frame}, {dataset_max_frame}]"
            )
        
        if actual_start > actual_end:
            raise ValueError(
                f"Invalid range: start_frame ({actual_start}) > end_frame ({actual_end})"
            )
        
        total_frames = actual_end - actual_start + 1
        
        print(f"Input dataset frame range: [{dataset_min_frame}, {dataset_max_frame}]")
        print(f"Processing frame range: [{actual_start}, {actual_end}] ({total_frames} frames)")
        print(f"Frame numbering: {'maintain original' if self.maintain_frame_numbers else 'start from 0'}")
        print(f"Output format: {self.image_format.upper()}")
        
        # Get stream IDs to write
        if self.stream_ids is None:
            self.stream_ids = self.input_dataset.stream_ids
        
        print(f"Writing {len(self.stream_ids)} streams: {self.stream_ids}")
        
        # Split streams into batches
        stream_batches = self._split_streams_into_batches(self.stream_ids)
        print(f"Processing {len(stream_batches)} stream batches of up to {self.streams_per_batch} streams each")
        
        # Process each stream batch
        for stream_batch_idx, stream_batch in enumerate(stream_batches, 1):
            print(f"\nProcessing stream batch {stream_batch_idx}/{len(stream_batches)}: {stream_batch}")
            
            # For datasets that may span multiple ranges (like Ranged datasets),
            # we need to check if we can read the entire range at once or need to split
            try:
                # Try to create a single reader for the entire range
                reader = self.input_dataset.create_frame_reader(
                    stream_ids=stream_batch,
                    start_frame=actual_start,
                    end_frame=actual_end,
                    max_workers=self.max_workers,
                )
                try:
                    # Process all frames for this stream batch
                    for abs_frame_idx, frame_data in tqdm(
                        reader,
                        desc=f"  Writing frames for streams {stream_batch}",
                        total=total_frames
                    ):
                        # Calculate output frame number
                        if self.maintain_frame_numbers:
                            output_frame_num = abs_frame_idx
                        else:
                            output_frame_num = abs_frame_idx - actual_start
                        
                        # Write frames for streams in this batch
                        self._write_frame_for_stream_batch(
                            stream_batch, abs_frame_idx, output_frame_num, frame_data
                        )
                finally:
                    reader.close()
                    
            except NotImplementedError as e:
                # If reading across multiple ranges is not supported,
                # we need to process each range separately
                if "multiple ranges" in str(e):
                    print(f"  Note: Processing ranges separately (multi-range reading not supported)")
                    self._process_stream_batch_across_ranges(
                        stream_batch, actual_start, actual_end, total_frames
                    )
                else:
                    raise
        
        # Copy meta and stash folders if requested
        if self.copy_meta:
            self._copy_meta_folder()
        
        if self.stash_policy == "copy":
            self._copy_stash_folder(
                stream_ids=self.stream_ids,
                start_frame=actual_start,
                end_frame=actual_end,
                maintain_frame_numbers=self.maintain_frame_numbers,
            )
        elif self.stash_policy == "generate":
            self._generate_stash_from_reader(
                stream_ids=self.stream_ids,
                start_frame=actual_start,
                end_frame=actual_end,
                maintain_frame_numbers=self.maintain_frame_numbers,
            )
        
        print(f"\nSuccessfully created Legacy dataset at {self.output_path}")
        
        # Return instance of the created dataset
        return LegacyDataset(self.output_path, max_workers=self.max_workers)
    
    def _process_stream_batch_across_ranges(self, stream_batch: List[int],
                                             actual_start: int, actual_end: int,
                                             total_frames: int):
        """
        Process a stream batch across multiple ranges.
        
        This is used when the input dataset doesn't support reading across
        multiple range boundaries (e.g., RangedDataset).
        
        Args:
            stream_batch: List of stream IDs to process
            actual_start: Absolute start frame
            actual_end: Absolute end frame
            total_frames: Total number of frames to process
        """
        # Get all ranges from the input dataset
        all_ranges = self.input_dataset.get_frame_ranges()
        
        # Find ranges that overlap with our requested range
        overlapping_ranges = []
        for range_start, range_end, range_metadata in all_ranges:
            if range_end >= actual_start and range_start <= actual_end:
                # Calculate the overlap
                overlap_start = max(range_start, actual_start)
                overlap_end = min(range_end, actual_end)
                overlapping_ranges.append((overlap_start, overlap_end, range_metadata))
        
        if not overlapping_ranges:
            raise ValueError(f"No ranges found overlapping [{actual_start}, {actual_end}]")
        
        # Process each overlapping range separately
        for overlap_start, overlap_end, _ in overlapping_ranges:
            # Create reader for this specific range
            reader = self.input_dataset.create_frame_reader(
                stream_ids=stream_batch,
                start_frame=overlap_start,
                end_frame=overlap_end,
                max_workers=self.max_workers,
            )
            try:
                # Process frames in this range
                for abs_frame_idx, frame_data in reader:
                    # Calculate output frame number
                    if self.maintain_frame_numbers:
                        output_frame_num = abs_frame_idx
                    else:
                        output_frame_num = abs_frame_idx - actual_start
                    
                    # Write frames for streams in this batch
                    self._write_frame_for_stream_batch(
                        stream_batch, abs_frame_idx, output_frame_num, frame_data
                    )
            finally:
                reader.close()
    
    def _write_frame_for_stream_batch(self, stream_batch: List[int], 
                                       abs_frame_idx: int, output_frame_num: int,
                                       frame_data: dict):
        """
        Write images for a specific frame for a batch of streams.
        
        Args:
            stream_batch: List of stream IDs to process in this batch
            abs_frame_idx: Absolute frame index from input dataset
            output_frame_num: Output frame number
            frame_data: Dictionary mapping stream_id -> numpy array
        """
        # Create frame directory
        frame_name = self._format_frame_name(output_frame_num)
        frame_dir = self.output_path / frame_name / "rgb"
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Save each stream's image
        for stream_id in stream_batch:
            if stream_id not in frame_data:
                raise ValueError(
                    f"Stream {stream_id} not found in frame {abs_frame_idx}. "
                    f"Available streams: {list(frame_data.keys())}"
                )
            
            image_array = frame_data[stream_id]
            
            # Ensure image is in the right format (HWC numpy array)
            if not isinstance(image_array, np.ndarray):
                raise ValueError(f"Expected numpy array, got {type(image_array)}")
            
            # Save image
            stream_filename = self._format_stream_name(stream_id)
            output_path = frame_dir / stream_filename
            self._save_image(image_array, output_path)
