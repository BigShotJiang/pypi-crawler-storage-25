"""Environment-driven toggles for optional GPU encode/decode paths."""

from __future__ import annotations

import os

_GPU_USAGE_OVERRIDE: bool | None = None


def _truthy(val: str | None) -> bool:
    if val is None:
        return False
    return val.strip().lower() in ("1", "true", "yes", "on")


def _set_gpu_override(enabled: bool | None) -> None:
    global _GPU_USAGE_OVERRIDE
    _GPU_USAGE_OVERRIDE = enabled


class _GpuEnabledContext:
    def __init__(self, previous: bool | None):
        self._previous = previous

    def __enter__(self) -> None:
        return None

    def __exit__(self, exc_type, exc, tb) -> bool:
        _set_gpu_override(self._previous)
        return False


def gpu_enabled(enabled: bool | None) -> _GpuEnabledContext:
    """Set a process-wide GPU policy override and return a restoring context manager.

    ``False`` forbids all GPU use inside mvdata regardless of codec support.
    ``True`` clears a prior forced-disable but does not override environment
    variables such as ``MVDATA_DISABLE_GPU``.
    ``None`` removes the programmatic override entirely.

    This can be used either as a setter:

    ``gpu_enabled(False)``

    or as a scoped override:

    ``with gpu_enabled(False): ...``
    """
    previous = gpu_enabled_override()
    _set_gpu_override(enabled)
    return _GpuEnabledContext(previous)


def set_gpu_enabled(enabled: bool | None) -> None:
    """Compatibility alias for ``gpu_enabled``."""
    _set_gpu_override(enabled)


def disable_gpu() -> None:
    """Forbid all GPU use inside mvdata for the current process."""
    gpu_enabled(False)


def enable_gpu() -> None:
    """Allow GPU use again unless environment policy still disables it."""
    gpu_enabled(True)


def clear_gpu_override() -> None:
    """Remove any programmatic GPU policy override."""
    _set_gpu_override(None)


def gpu_enabled_override() -> bool | None:
    """Return the current process-wide GPU policy override."""
    return _GPU_USAGE_OVERRIDE


def gpu_usage_allowed() -> bool:
    """Return whether mvdata is currently allowed to use GPU paths."""
    return not gpu_nvenc_disabled_globally()


def gpu_disabled():
    """Temporarily forbid all mvdata GPU use within the context."""
    return gpu_enabled(False)


def gpu_nvenc_disabled_globally() -> bool:
    """If true, library must not use NVENC/NVDEC (encoding or decoding)."""
    return _GPU_USAGE_OVERRIDE is False or _truthy(os.environ.get("MVDATA_DISABLE_GPU"))


def nvenc_encode_disabled() -> bool:
    """Explicit opt-out for NVENC encoding only (decode may still use GPU if enabled)."""
    return gpu_nvenc_disabled_globally() or _truthy(os.environ.get("MVDATA_DISABLE_NVENC_ENCODE"))


def nvdec_decode_disabled() -> bool:
    """Explicit opt-out for NVDEC / PyNv SimpleDecoder paths."""
    return gpu_nvenc_disabled_globally() or _truthy(os.environ.get("MVDATA_DISABLE_NVDEC_DECODE"))


def nvenc_encode_allowed() -> bool:
    return not nvenc_encode_disabled()


def nvdec_decode_allowed() -> bool:
    return not nvdec_decode_disabled()


def pynvvideocodec_importable() -> bool:
    try:
        import PyNvVideoCodec  # noqa: F401

        return True
    except ImportError:
        return False


def nvenc_encoding_usable() -> bool:
    """Encoding may proceed when policy allows and the wheel is installed."""
    return nvenc_encode_allowed() and pynvvideocodec_importable()


def nvdec_decoding_usable() -> bool:
    """NVDEC decode may proceed when policy allows and the wheel is installed."""
    return nvdec_decode_allowed() and pynvvideocodec_importable()
