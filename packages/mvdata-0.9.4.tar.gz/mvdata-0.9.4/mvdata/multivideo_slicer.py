from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from .multivideo import MultiVideoDataset
from .multivideo_slicer_models import (
    DEFAULT_MAX_FRAMES_PER_RANGED_MP4,
    SUPPORTED_SLICE_CODECS,
    MultiVideoSliceEligibility,
    MultiVideoSliceEligibilityMetadata,
    MultiVideoSliceError,
    MultiVideoSlicePlan,
    MultiVideoSliceRange,
    MultiVideoStreamEligibility,
    MultiVideoStreamSliceInfo,
)
from .multivideo_slicer_plan import (
    _build_ranges,
    _choose_legal_step,
    _common_keyframes,
    _constant_keyframe_interval,
    _degenerate_range_plan_error,
)
from .multivideo_slicer_packets import (
    _PacketCopyPlan,
    _VideoPacketRecord,
    _check_av_available,
    _copy_packet_for_mux,
    _count_decoded_video_frames,
    _count_visible_video_packets,
    _is_content_packet,
    _packet_copy_plans,
    _packet_copy_plans_from_records,
    _scan_video_for_slicing,
)
from .ranged import RANGED_MP4_SLICE_METADATA_FILENAME, RangedDataset
from .writer_base import DatasetWriter

try:
    import av

except ImportError:  # pragma: no cover - exercised only without optional dependency
    av = None


def _format_stream_filename(stream_id: int) -> str:
    return f"{stream_id:03d}.mp4"


def _discover_multivideo_paths(dataset: MultiVideoDataset) -> dict[int, Path]:
    discover = getattr(dataset, "_discover_video_files", None)
    if callable(discover):
        return dict(discover())
    return {stream_id: dataset.get_video_path(stream_id) for stream_id in dataset.stream_ids}


def _has_numbered_stash(dataset: MultiVideoDataset) -> bool:
    try:
        return bool(dataset.get_stash_frames())
    except Exception:
        return False


def _resolve_stash_policy(input_dataset: MultiVideoDataset, stash_policy: str) -> tuple[str, str]:
    requested = stash_policy.lower()
    if requested != "auto":
        return requested, requested
    if _has_numbered_stash(input_dataset):
        return "auto", "copy"
    return "auto", "generate"


def _stream_from_template(output_container: Any, input_stream: Any) -> Any:
    if hasattr(output_container, "add_stream_from_template"):
        return output_container.add_stream_from_template(input_stream, opaque=True)
    return output_container.add_stream(template=input_stream)


def _write_mp4_slice_metadata(
    output_path: Path,
    range_info: MultiVideoSliceRange,
    stream_id: int,
    packet_plan: _PacketCopyPlan,
) -> None:
    metadata_path = (
        output_path
        / range_info.output_name
        / "rgb"
        / RANGED_MP4_SLICE_METADATA_FILENAME
    )
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    if metadata_path.exists():
        with metadata_path.open("r", encoding="utf-8") as fh:
            payload = json.load(fh)
    else:
        payload = {"version": 1, "streams": {}}

    payload.setdefault("streams", {})[str(stream_id)] = {
        "source_start_frame": range_info.source_start_frame,
        "source_end_frame": range_info.source_end_frame,
        "dependency_start_frame": packet_plan.dependency_start_frame,
        "presentation_frame_offset": packet_plan.presentation_frame_offset,
        "packet_start": packet_plan.packet_start,
        "packet_end": packet_plan.packet_end,
    }
    with metadata_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, sort_keys=True, indent=2)
        fh.write("\n")


def _slice_video_to_ranged_mp4s(
    video_path: Path,
    output_path: Path,
    ranges: tuple[MultiVideoSliceRange, ...],
    stream_id: int,
) -> None:
    _check_av_available()

    if not ranges:
        return

    packet_plans = _packet_copy_plans(video_path, ranges, stream_id)
    packet_targets: dict[int, list[MultiVideoSliceRange]] = {}
    for range_info in ranges:
        for packet_index in packet_plans[range_info].packet_indices:
            packet_targets.setdefault(packet_index, []).append(range_info)

    last_packet_end = max(packet_plans[range_info].packet_end for range_info in ranges)
    packets_written = {range_info: 0 for range_info in ranges}
    output_files: dict[MultiVideoSliceRange, Path] = {}
    output_containers: dict[MultiVideoSliceRange, Any] = {}
    output_streams: dict[MultiVideoSliceRange, Any] = {}

    input_container = av.open(str(video_path))
    try:
        if not input_container.streams.video:
            raise MultiVideoSliceError(f"Stream {stream_id} has no video stream: {video_path}")

        input_stream = input_container.streams.video[0]

        def open_output(range_info: MultiVideoSliceRange) -> tuple[Any, Any]:
            if range_info not in output_containers:
                range_dir = output_path / range_info.output_name / "rgb"
                range_dir.mkdir(parents=True, exist_ok=True)
                output_file = range_dir / _format_stream_filename(stream_id)
                output_container = av.open(str(output_file), mode="w", format="mp4")
                output_containers[range_info] = output_container
                output_streams[range_info] = _stream_from_template(output_container, input_stream)
                output_files[range_info] = output_file
            return output_containers[range_info], output_streams[range_info]

        def close_finished_outputs(packet_index: int) -> None:
            for range_info in list(output_containers):
                if packet_index > packet_plans[range_info].packet_end:
                    output_containers.pop(range_info).close()
                    output_streams.pop(range_info, None)

        def mux_packet(range_info: MultiVideoSliceRange, packet: Any) -> None:
            output_container, output_stream = open_output(range_info)
            packet_plan = packet_plans[range_info]
            original_pts = packet.pts
            original_dts = packet.dts
            original_stream = packet.stream
            try:
                packet.pts = packet.pts - packet_plan.timestamp_offset
                packet.dts = packet.dts - packet_plan.timestamp_offset
                packet.stream = output_stream
                output_container.mux(packet)
            finally:
                packet.pts = original_pts
                packet.dts = original_dts
                if original_stream is not None:
                    packet.stream = original_stream

        packet_index = 0
        for packet in input_container.demux(input_stream):
            if not _is_content_packet(packet):
                continue

            if packet_index > last_packet_end:
                break
            close_finished_outputs(packet_index)

            targets = packet_targets.get(packet_index)
            if not targets:
                packet_index += 1
                continue
            target_packets = (
                [_copy_packet_for_mux(packet) for _ in targets]
                if len(targets) > 1
                else [packet]
            )
            for range_info, target_packet in zip(targets, target_packets):
                mux_packet(range_info, target_packet)
                packets_written[range_info] += 1
            packet_index += 1
    finally:
        for output_container in output_containers.values():
            output_container.close()
        input_container.close()

    for range_info in ranges:
        expected = range_info.frame_count
        expected_with_preroll = expected + packet_plans[range_info].presentation_frame_offset
        if packets_written[range_info] < expected:
            raise MultiVideoSliceError(
                f"Expected at least {expected} packets for stream {stream_id} range "
                f"{range_info.output_name}, wrote {packets_written[range_info]}"
            )
        output_file = output_files[range_info]
        visible_packets = _count_visible_video_packets(output_file)
        if visible_packets < expected_with_preroll:
            raise MultiVideoSliceError(
                f"Expected at least {expected_with_preroll} visible packets for stream {stream_id} range "
                f"{range_info.output_name}, found {visible_packets}."
            )
        decoded_frames = _count_decoded_video_frames(output_file)
        if decoded_frames < expected_with_preroll:
            raise MultiVideoSliceError(
                f"Expected at least {expected_with_preroll} decoded frames for stream {stream_id} range "
                f"{range_info.output_name}, found {decoded_frames}."
            )
        _write_mp4_slice_metadata(
            output_path,
            range_info,
            stream_id,
            packet_plans[range_info],
        )


class MultiVideoToRangedSlicer(DatasetWriter):
    """Packet-copy converter from MultiVideo datasets to Ranged MP4 chunks.

    The conversion is intentionally two-stage:
    1. :meth:`check_eligibility` scans packet/keyframe metadata and returns a
       machine-readable plan without writing output files.
    2. :meth:`write` remuxes eligible packet ranges into ``range/rgb/*.mp4`` and
       then applies the usual metadata/stash policy.

    The main slicing path does not decode or re-encode video frames.
    """

    def __init__(
        self,
        input_dataset: MultiVideoDataset,
        output_path: Path,
        target_frames: int = 125,
        tail_tolerance_frames: Optional[int] = None,
        prefer_larger_chunk: bool = False,
        copy_meta: bool = True,
        stash_policy: str = "auto",
        stash_num_frames: int = 10,
        max_workers: Optional[int] = None,
        stream_ids: Optional[list[int]] = None,
        max_frames_per_range: int = DEFAULT_MAX_FRAMES_PER_RANGED_MP4,
        verbose: bool = True,
    ):
        _check_av_available()
        if target_frames <= 0:
            raise ValueError(f"target_frames must be positive, got {target_frames}")
        if tail_tolerance_frames is None:
            tail_tolerance_frames = target_frames
        if tail_tolerance_frames < 0:
            raise ValueError(
                f"tail_tolerance_frames must be >= 0, got {tail_tolerance_frames}"
            )
        if max_frames_per_range <= 0:
            raise ValueError(f"max_frames_per_range must be positive, got {max_frames_per_range}")

        requested_stash_policy, effective_stash_policy = _resolve_stash_policy(
            input_dataset,
            stash_policy,
        )
        super().__init__(
            input_dataset=input_dataset,
            output_path=output_path,
            copy_meta=copy_meta,
            stash_policy=effective_stash_policy,
            stash_num_frames=stash_num_frames,
            max_workers=max_workers,
        )
        self.requested_stash_policy = requested_stash_policy
        self.target_frames = int(target_frames)
        self.tail_tolerance_frames = int(tail_tolerance_frames)
        self.prefer_larger_chunk = bool(prefer_larger_chunk)
        self.stream_ids = stream_ids
        self.max_frames_per_range = int(max_frames_per_range)
        self.verbose = verbose
        self._eligibility: Optional[MultiVideoSliceEligibility] = None

    def _resumable_config(self) -> dict[str, Any]:
        return {
            **super()._resumable_config(),
            "requested_stash_policy": self.requested_stash_policy,
            "target_frames": self.target_frames,
            "tail_tolerance_frames": self.tail_tolerance_frames,
            "prefer_larger_chunk": self.prefer_larger_chunk,
            "stream_ids": self.stream_ids,
            "max_frames_per_range": self.max_frames_per_range,
        }

    def _resolve_stream_ids(self, video_paths: dict[int, Path]) -> tuple[int, ...]:
        if self.stream_ids is None:
            return tuple(sorted(video_paths))

        available = set(video_paths)
        missing = [stream_id for stream_id in self.stream_ids if stream_id not in available]
        if missing:
            raise MultiVideoSliceError(
                f"Requested stream IDs are not in the input dataset: {missing}. "
                f"Available stream IDs: {sorted(available)}"
            )
        return tuple(self.stream_ids)

    def check_eligibility(self, *, refresh: bool = False) -> MultiVideoSliceEligibility:
        if self._eligibility is not None and not refresh:
            return self._eligibility

        errors: list[str] = []
        warnings: list[str] = []
        video_paths: dict[int, Path] = {}
        stream_ids: tuple[int, ...] = tuple()
        videos: list[MultiVideoStreamSliceInfo] = []
        stream_errors: dict[int, list[str]] = {}
        scanned_infos: dict[int, MultiVideoStreamSliceInfo] = {}
        min_frames: Optional[int] = None
        max_frames: Optional[int] = None
        keyframe_interval: Optional[int] = None
        chosen_step: Optional[int] = None
        ranges: tuple[MultiVideoSliceRange, ...] = tuple()
        discarded_tail_frames: dict[int, int] = {}

        def _record_stream_error(stream_id: int, message: str) -> None:
            stream_errors.setdefault(stream_id, []).append(message)

        def _stream_results() -> tuple[MultiVideoStreamEligibility, ...]:
            results = []
            for stream_id in stream_ids:
                path = video_paths.get(stream_id)
                results.append(
                    MultiVideoStreamEligibility(
                        stream_id=stream_id,
                        path=str(path) if path is not None else None,
                        info=scanned_infos.get(stream_id),
                        errors=tuple(stream_errors.get(stream_id, ())),
                    )
                )
            return tuple(results)

        def _metadata() -> MultiVideoSliceEligibilityMetadata:
            stream_results = _stream_results()
            passed_stream_ids = tuple(result.stream_id for result in stream_results if result.passed)
            failed_stream_ids = tuple(result.stream_id for result in stream_results if result.errors)
            resulting_start = 0 if ranges else None
            resulting_end = ranges[-1].output_end_frame if ranges else None
            resulting_count = (
                resulting_end - resulting_start + 1
                if resulting_start is not None and resulting_end is not None
                else None
            )
            return MultiVideoSliceEligibilityMetadata(
                dataset_type=type(self.input_dataset).__name__,
                requested_stash_policy=self.requested_stash_policy,
                effective_stash_policy=self.stash_policy,
                target_frames=self.target_frames,
                tail_tolerance_frames=self.tail_tolerance_frames,
                requested_stream_ids=(
                    tuple(self.stream_ids) if self.stream_ids is not None else None
                ),
                discovered_stream_ids=tuple(sorted(video_paths)),
                selected_stream_ids=stream_ids,
                passed_stream_ids=passed_stream_ids,
                failed_stream_ids=failed_stream_ids,
                stream_results=stream_results,
                min_frames=min_frames,
                max_frames=max_frames,
                common_frame_count=min_frames,
                resulting_dataset_start_frame=resulting_start,
                resulting_dataset_end_frame=resulting_end,
                resulting_dataset_frame_count=resulting_count,
                keyframe_interval_frames=keyframe_interval,
                chosen_step_frames=chosen_step,
                range_count=len(ranges) if ranges else None,
                first_ranges=tuple(range_info.output_name for range_info in ranges[:5]),
                discarded_tail_frames=discarded_tail_frames,
            )

        def _finish(plan: Optional[MultiVideoSlicePlan] = None) -> MultiVideoSliceEligibility:
            self._eligibility = MultiVideoSliceEligibility(
                plan=plan,
                errors=tuple(errors),
                warnings=tuple(warnings),
                metadata=_metadata(),
            )
            return self._eligibility

        if not isinstance(self.input_dataset, MultiVideoDataset):
            errors.append(
                "MultiVideoToRangedSlicer requires a MultiVideoDataset input, "
                f"got {type(self.input_dataset).__name__}"
            )

        if getattr(self.input_dataset, "respect_timestamps", False):
            errors.append(
                "Timestamp-synchronized MultiVideo datasets are not eligible for packet slicing; "
                "use frame-index synchronization instead"
            )

        if not errors:
            try:
                video_paths = _discover_multivideo_paths(self.input_dataset)
                if not video_paths:
                    errors.append(f"No video files found in {self.input_dataset.dataset_path}")
            except Exception as exc:
                errors.append(str(exc))

        try:
            stream_ids = self._resolve_stream_ids(video_paths)
        except Exception as exc:
            errors.append(str(exc))
            stream_ids = tuple()

        for stream_id in stream_ids:
            try:
                info = _scan_video_for_slicing(stream_id, video_paths[stream_id])
                videos.append(info)
                scanned_infos[stream_id] = info
            except Exception as exc:
                message = str(exc)
                errors.append(message)
                _record_stream_error(stream_id, message)

        if errors:
            return _finish()

        for video in videos:
            if video.codec not in SUPPORTED_SLICE_CODECS:
                message = (
                    f"Stream {video.stream_id} uses unsupported codec {video.codec!r}; "
                    f"supported codecs are {sorted(SUPPORTED_SLICE_CODECS)}"
                )
                errors.append(message)
                _record_stream_error(video.stream_id, message)
            if not video.keyframe_indices or video.keyframe_indices[0] != 0:
                message = (
                    f"Stream {video.stream_id} is not independently sliceable from frame 0; "
                    "the first packet must be a keyframe"
                )
                errors.append(message)
                _record_stream_error(video.stream_id, message)

        fps_values = {video.fps for video in videos}
        if len(fps_values) > 1:
            fps_by_stream = ", ".join(f"{video.stream_id}={video.fps}" for video in videos)
            message = (
                "Frame-based packet slicing requires common CFR inputs, but FPS differs: "
                f"{fps_by_stream}"
            )
            errors.append(message)
            reference_fps = videos[0].fps
            for video in videos:
                if video.fps != reference_fps:
                    _record_stream_error(video.stream_id, message)

        min_frames = min(video.visible_frame_count for video in videos)
        max_frames = max(video.visible_frame_count for video in videos)
        tail_spread = max_frames - min_frames
        if tail_spread > self.tail_tolerance_frames:
            counts = ", ".join(
                f"{video.stream_id}={video.visible_frame_count}"
                for video in sorted(videos, key=lambda v: v.stream_id)
            )
            message = (
                f"Tail frame-count spread exceeds tolerance: spread={tail_spread}, "
                f"tolerance={self.tail_tolerance_frames}; counts: {counts}"
            )
            errors.append(message)
            for video in videos:
                if video.visible_frame_count != min_frames:
                    _record_stream_error(video.stream_id, message)
        elif tail_spread:
            warnings.append(
                f"Input streams differ by {tail_spread} tail frame(s); "
                "only the common frame region will be written to the Ranged dataset"
            )

        if min_frames <= 0:
            errors.append("Input dataset has no common video frames to slice")

        reference_common_keyframes = _common_keyframes(videos[0], min_frames)
        if not reference_common_keyframes or reference_common_keyframes[0] != 0:
            message = "Common keyframe schedule must start at frame 0"
            errors.append(message)
            _record_stream_error(videos[0].stream_id, message)

        for video in videos[1:]:
            common_keyframes = _common_keyframes(video, min_frames)
            if common_keyframes != reference_common_keyframes:
                message = (
                    "Keyframe schedule mismatch in common region between stream "
                    f"{videos[0].stream_id} and stream {video.stream_id}"
                )
                errors.append(message)
                _record_stream_error(video.stream_id, message)
                break

        chosen_step = min(self.target_frames, min_frames)

        if not errors:
            try:
                keyframe_interval = _constant_keyframe_interval(reference_common_keyframes)
            except MultiVideoSliceError as exc:
                errors.append(str(exc))

        if not errors:
            if keyframe_interval is None:
                if min_frames > self.target_frames:
                    errors.append(
                        "Cannot choose multiple packet-copy ranges because the common region "
                        "does not contain a second keyframe"
                    )
                else:
                    chosen_step = min_frames
            else:
                try:
                    chosen_step = _choose_legal_step(
                        self.target_frames,
                        keyframe_interval,
                        prefer_larger_chunk=self.prefer_larger_chunk,
                        max_frames_per_range=self.max_frames_per_range,
                    )
                except MultiVideoSliceError as exc:
                    errors.append(str(exc))

        if chosen_step > self.max_frames_per_range:
            errors.append(
                f"Chosen range size {chosen_step} exceeds Ranged convention maximum "
                f"{self.max_frames_per_range}"
            )

        if errors:
            return _finish()

        ranges = _build_ranges(min_frames, chosen_step)
        boundary_keyframes = set(reference_common_keyframes)
        for range_info in ranges:
            is_first_frame = range_info.source_start_frame == 0
            if not is_first_frame and range_info.source_start_frame not in boundary_keyframes:
                errors.append(
                    f"Range {range_info.output_name} starts at frame "
                    f"{range_info.source_start_frame}, which is not a keyframe boundary"
                )

        degenerate_error = _degenerate_range_plan_error(ranges, min_frames)
        if degenerate_error is not None:
            errors.append(degenerate_error)

        if errors:
            return _finish()

        if self.target_frames > self.max_frames_per_range and chosen_step < self.target_frames:
            warnings.append(
                f"Requested target_frames={self.target_frames} exceeds "
                f"max_frames_per_range={self.max_frames_per_range}; using {chosen_step}"
            )

        discarded_tail_frames = {
            video.stream_id: video.visible_frame_count - min_frames
            for video in videos
            if video.visible_frame_count > min_frames
        }
        plan = MultiVideoSlicePlan(
            version=1,
            mode="multivideo-to-ranged-pyav-packet-copy",
            target_frames=self.target_frames,
            chosen_step_frames=chosen_step,
            exact_target=chosen_step == self.target_frames,
            keyframe_interval_frames=keyframe_interval,
            tail_tolerance_frames=self.tail_tolerance_frames,
            common_frame_count=min_frames,
            min_frames=min_frames,
            max_frames=max_frames,
            stream_ids=stream_ids,
            videos=tuple(videos),
            ranges=ranges,
            discarded_tail_frames=discarded_tail_frames,
            warnings=tuple(warnings),
        )
        return _finish(plan)

    def write(self) -> RangedDataset:
        eligibility = self.check_eligibility()
        plan = eligibility.raise_if_ineligible()

        self.output_path.mkdir(parents=True, exist_ok=True)

        if self.verbose:
            print(
                "Slicing MultiVideo dataset with PyAV packet copy: "
                f"{len(plan.stream_ids)} stream(s), {len(plan.ranges)} range(s), "
                f"{plan.chosen_step_frames} frames/range target"
            )
            for warning in plan.warnings:
                print(f"Warning: {warning}")

        video_by_stream_id = {video.stream_id: video for video in plan.videos}
        for stream_id in plan.stream_ids:
            video = video_by_stream_id[stream_id]
            if self.verbose:
                print(f"  Slicing stream {stream_id} from {video.path}")
            _slice_video_to_ranged_mp4s(
                video_path=Path(video.path),
                output_path=self.output_path,
                ranges=plan.ranges,
                stream_id=stream_id,
            )

        start_frame = 0
        end_frame = plan.common_frame_count - 1

        if self.copy_meta:
            self._copy_meta_folder()

        ranged_dataset = RangedDataset(self.output_path, max_workers=self.max_workers)

        if self.stash_policy == "copy":
            self._copy_stash_folder(
                stream_ids=list(plan.stream_ids),
                start_frame=start_frame,
                end_frame=end_frame,
                maintain_frame_numbers=True,
            )
        elif self.stash_policy == "generate":
            self._generate_stash_from_dataset(
                source=ranged_dataset,
                stream_ids=list(plan.stream_ids),
                start_frame=start_frame,
                end_frame=end_frame,
                maintain_frame_numbers=True,
            )

        if self.verbose:
            print(f"Successfully created sliced Ranged dataset at {self.output_path}")

        return ranged_dataset
