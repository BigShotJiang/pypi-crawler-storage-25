from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from time import perf_counter
from typing import Any, Callable, Dict, Literal, Optional

import numpy as np

from .dataset_base import FrameReader
from .codec.nvdec import (
    _close_nvdec_decoder,
    _NvdecOrdinalRawFrameSource,
    _NvdecPtsRawFrameSource,
    _nvdec_scanned_presentation_pts,
)
from .nvdec_parallel import (
    NvdecParallelismPlan,
    detect_gpu_name,
    resolve_nvdec_parallelism,
)

Device = Literal["cpu", "cuda"]


@dataclass
class VideoDecodeSessionMetrics:
    backend: str | None = None
    frames_served: int = 0
    read_wall_time_s: float = 0.0
    nvdec_open_failures: int = 0
    fallback_to_pyav_count: int = 0
    read_errors: int = 0
    sequential_reads: int = 0
    indexed_reads: int = 0
    repeated_reads: int = 0


def _is_uint16_array(frame) -> bool:
    """True for both numpy and cupy HWC arrays with uint16 dtype."""
    return getattr(frame, "dtype", None) == np.uint16


def _frame_cache_key(device: Device, cuda_stream: int | None) -> tuple[Device, int | None]:
    if device == "cpu":
        return device, None
    return device, None if cuda_stream is None else int(cuda_stream)


class _VideoNvdecFrameSource:
    def __init__(self, path: Path, gpu_id: int, num_frames: int, bit_depth: int):
        from . import nvenc_codec

        self._path = path
        self._gpu_id = gpu_id
        self._num_frames = num_frames
        self._bit_depth = bit_depth
        self._nvenc_codec = nvenc_codec
        self._torch_mod = nvenc_codec.try_import_torch()
        self._native_high_bit = self._bit_depth > 8
        self._color_metadata = (
            nvenc_codec.probe_video_color_metadata_pyav(path) if self._native_high_bit else {}
        )
        if self._native_high_bit and nvenc_codec.try_import_cupy() is None:
            raise RuntimeError("Native high-bit-depth NVDEC conversion requires CuPy")
        has_dlpack = self._torch_mod is not None or nvenc_codec.try_import_cupy() is not None
        use_dev_options = [True] if self._native_high_bit else ([True, False] if has_dlpack else [False])
        self._nvc = None
        self._use_device_memory = False
        self._output_color_type = None
        self._raw_source = None

        nvc = nvenc_codec.try_import_pynvvideocodec()
        issue = nvenc_codec.nvdec_decode_compatibility_issue_for_path(nvc, path, gpu_id)
        if issue is not None:
            raise RuntimeError(f"NVDEC unsupported for {path}: {issue}")

        metadata_decoder = None
        for use_dev in use_dev_options:
            if self._native_high_bit:
                output_color_type = nvc.OutputColorType.NATIVE
                metadata_decoder = nvenc_codec._try_open_nvdec(
                    nvc,
                    str(path),
                    gpu_id,
                    use_dev,
                    output_color_type=output_color_type,
                )
            else:
                output_color_type = nvc.OutputColorType.RGB
                metadata_decoder = nvenc_codec._try_open_nvdec(
                    nvc,
                    str(path),
                    gpu_id,
                    use_dev,
                    output_color_type=output_color_type,
                )
            if metadata_decoder is not None:
                self._nvc = nvc
                self._use_device_memory = use_dev
                self._output_color_type = output_color_type
                break
        if metadata_decoder is None or self._nvc is None:
            raise RuntimeError(f"NVDEC could not open {path}")

        presentation_pts = _nvdec_scanned_presentation_pts(metadata_decoder, num_frames)
        if presentation_pts is None:
            self._raw_source = _NvdecOrdinalRawFrameSource(metadata_decoder, path)
        else:
            _close_nvdec_decoder(metadata_decoder)
            if len(presentation_pts) < num_frames:
                raise RuntimeError(
                    f"{path}: NVDEC scanned metadata has {len(presentation_pts)} "
                    f"presentation timestamps for {num_frames} requested frames"
                )
            self._raw_source = _NvdecPtsRawFrameSource(
                self._nvc,
                path,
                gpu_id=self._gpu_id,
                use_device_memory=self._use_device_memory,
                output_color_type=self._output_color_type,
                presentation_pts=presentation_pts,
            )

        self._last_index: int | None = None
        self._last_frame: Any | None = None
        self._last_cache_key: tuple[Device, int | None] | None = None

    def _materialize(self, raw, *, device: Device, cuda_stream: int | None):
        if self._native_high_bit:
            kwargs = {
                "bit_depth": self._bit_depth,
                "cuda_stream": cuda_stream,
                **self._color_metadata,
            }
            if device == "cuda":
                return self._nvenc_codec.native_nvdec_to_rgb_cupy(raw, **kwargs)
            return self._nvenc_codec.native_nvdec_to_rgb_numpy(raw, **kwargs)
        if device == "cuda":
            return self._nvenc_codec._decoded_frame_to_rgb_cupy(
                raw,
                bit_depth=self._bit_depth,
                gpu_id=self._gpu_id,
                cuda_stream=cuda_stream,
            )
        return self._nvenc_codec._decoded_frame_to_rgb_numpy(
            raw, self._torch_mod, bit_depth=self._bit_depth
        )

    def frame(
        self, index: int, *, device: Device = "cpu", cuda_stream: int | None = None
    ) -> tuple[Any, str]:
        if index < 0 or index >= self._num_frames:
            raise IndexError(index)
        cache_key = _frame_cache_key(device, cuda_stream)
        if (
            self._last_index == index
            and self._last_frame is not None
            and self._last_cache_key == cache_key
        ):
            return self._last_frame, "repeat"

        mode = (
            "sequential"
            if self._last_index is None or index == self._last_index + 1
            else "indexed"
        )
        if self._last_index == index and self._last_cache_key != cache_key:
            mode = "indexed"
            if isinstance(self._raw_source, _NvdecPtsRawFrameSource):
                self._raw_source.reset()

        assert self._raw_source is not None
        if isinstance(self._raw_source, _NvdecOrdinalRawFrameSource):
            raw, mode = self._raw_source.frame(index)
        else:
            raw = self._raw_source.frame(index)

        out = self._materialize(raw, device=device, cuda_stream=cuda_stream)
        self._last_index = index
        self._last_frame = out
        self._last_cache_key = cache_key
        return out, mode

    def close(self) -> None:
        if self._raw_source is not None:
            self._raw_source.close()
            self._raw_source = None


class _VideoPyavFrameSource:
    def __init__(self, path: Path, num_frames: int, bit_depth: int, gpu_id: int = 0):
        from . import nvenc_codec

        self._path = path
        self._num_frames = num_frames
        self._bit_depth = bit_depth
        self._gpu_id = gpu_id
        self._nvenc_codec = nvenc_codec
        self._av = nvenc_codec.try_import_av()
        if self._av is None:
            raise RuntimeError("PyAV is required for CPU decode.")
        self._container = None
        self._stream = None
        self._iterator = None
        self._next_index = 0
        self._last_index: Optional[int] = None
        self._last_frame: Optional[np.ndarray] = None
        self._reset()

    def _reset(self) -> None:
        self.close()
        self._container = self._av.open(str(self._path))
        if not self._container.streams.video:
            raise RuntimeError(f"No video stream in {self._path}")
        self._stream = self._container.streams.video[0]
        self._iterator = iter(self._container.decode(self._stream))
        self._next_index = 0
        self._last_index = None
        self._last_frame = None

    def frame(
        self, index: int, *, device: Device = "cpu", cuda_stream: int | None = None
    ) -> tuple[Any, str]:
        rgb, mode = self._frame_cpu(index)
        if device == "cuda":
            return (
                self._nvenc_codec.numpy_to_cupy_rgb(
                    rgb,
                    gpu_id=self._gpu_id,
                    cuda_stream=cuda_stream,
                ),
                mode,
            )
        return rgb, mode

    def _frame_cpu(self, index: int) -> tuple[np.ndarray, str]:
        if index < 0 or index >= self._num_frames:
            raise IndexError(index)
        if self._last_index == index and self._last_frame is not None:
            return self._last_frame, "repeat"
        if self._iterator is None or index < self._next_index:
            self._reset()
            mode = "indexed"
        else:
            mode = "sequential"

        while self._next_index <= index:
            try:
                frame = next(self._iterator)
            except StopIteration as exc:
                raise RuntimeError(
                    f"{self._path}: expected at least {index + 1} frames, "
                    f"decoded {self._next_index}"
                ) from exc
            rgb = self._nvenc_codec._pyav_frame_to_rgb(frame, bit_depth=self._bit_depth)
            current_index = self._next_index
            self._next_index += 1
            if current_index == index:
                self._last_index = current_index
                self._last_frame = rgb
                return rgb, mode

        raise AssertionError("unreachable")

    def close(self) -> None:
        if self._container is not None:
            self._container.close()
            self._container = None
        self._stream = None
        self._iterator = None


class VideoPerStreamReader:
    """One reusable per-session video decode worker."""

    def __init__(self, path: Path, num_frames: int, *, gpu_id: int = 0, bit_depth: int = 8):
        self._path = path
        self._num_frames = num_frames
        self._gpu_id = gpu_id
        self._bit_depth = bit_depth
        self._backend = None
        self._backend_name: Optional[str] = None
        self._lock = Lock()
        self._metrics = VideoDecodeSessionMetrics()

    def _open_pyav(self, reason: str) -> None:
        if self._backend is not None:
            self._backend.close()
        self._backend = _VideoPyavFrameSource(
            self._path,
            self._num_frames,
            self._bit_depth,
            gpu_id=self._gpu_id,
        )
        self._backend_name = "pyav"
        self._metrics.backend = self._backend_name
        if reason == "fallback":
            self._metrics.fallback_to_pyav_count += 1

    def _ensure_backend(self) -> None:
        if self._backend is not None:
            return

        from .gpu_policy import nvdec_decoding_usable

        if nvdec_decoding_usable():
            try:
                self._backend = _VideoNvdecFrameSource(
                    self._path, self._gpu_id, self._num_frames, self._bit_depth
                )
                self._backend_name = "nvdec"
                self._metrics.backend = self._backend_name
                return
            except Exception as exc:
                self._metrics.nvdec_open_failures += 1
                raise RuntimeError(f"Could not open NVDEC reader for {self._path}") from exc

        self._open_pyav(reason="init")

    def _needs_precision_fallback(self, frame) -> bool:
        return (
            self._backend_name == "nvdec"
            and self._bit_depth > 8
            and not _is_uint16_array(frame)
        )

    def frame(
        self, index: int, *, device: Device = "cpu", cuda_stream: int | None = None
    ) -> Any:
        with self._lock:
            started = perf_counter()
            self._ensure_backend()
            assert self._backend is not None

            try:
                frame, mode = self._backend.frame(index, device=device, cuda_stream=cuda_stream)
            except Exception:
                self._metrics.read_errors += 1
                raise

            if self._needs_precision_fallback(frame):
                raise RuntimeError(
                    f"{self._path}: NVDEC returned uint8 for {self._bit_depth}-bit source"
                )

            self._metrics.frames_served += 1
            self._metrics.read_wall_time_s += perf_counter() - started
            if mode == "sequential":
                self._metrics.sequential_reads += 1
            elif mode == "indexed":
                self._metrics.indexed_reads += 1
            elif mode == "repeat":
                self._metrics.repeated_reads += 1
            return frame

    @property
    def metrics(self) -> VideoDecodeSessionMetrics:
        with self._lock:
            return VideoDecodeSessionMetrics(**self._metrics.__dict__)

    @property
    def backend_name(self) -> str | None:
        return self._backend_name

    def close(self) -> None:
        if self._backend is not None:
            self._backend.close()
            self._backend = None
        self._backend_name = None

    def __del__(self):
        self.close()


class ParallelVideoFrameReader(FrameReader):
    """Shared reader that schedules one per-stream video worker per source file."""

    def __init__(
        self,
        stream_files: Dict[int, Path],
        frame_counts: Dict[int, int],
        start_frame: int,
        end_frame: int,
        *,
        decoder_max_workers: int = 4,
        gpu_id: int = 0,
        bit_depths: Dict[int, int] | None = None,
        index_resolver: Callable[[int, int], int],
    ):
        super().__init__(start_frame, end_frame)

        self.stream_files = stream_files
        self.stream_ids = sorted(stream_files.keys())
        self._frame_counts = frame_counts
        self._gpu_id = gpu_id
        self._index_resolver = index_resolver
        self._bit_depths = {
            sid: int((bit_depths or {}).get(sid, 8))
            for sid in self.stream_ids
        }
        self._caches = {
            sid: VideoPerStreamReader(
                stream_files[sid],
                frame_counts[sid],
                gpu_id=gpu_id,
                bit_depth=self._bit_depths[sid],
            )
            for sid in self.stream_ids
        }
        self._executor: Optional[ThreadPoolExecutor] = None
        from .gpu_policy import nvdec_decoding_usable

        self._nvdec_usable = nvdec_decoding_usable()

        if self._nvdec_usable:
            self._parallelism_plan = resolve_nvdec_parallelism(
                gpu_id=gpu_id,
                session_count=len(self.stream_ids),
                requested_max_workers=decoder_max_workers,
            )
        else:
            planned_sessions = max(1, min(decoder_max_workers, len(self.stream_ids)))
            self._parallelism_plan = NvdecParallelismPlan(
                gpu_id=gpu_id,
                gpu_name=detect_gpu_name(gpu_id),
                budget_sessions=planned_sessions,
                planned_sessions=planned_sessions,
                reason="cpu-only",
                configured_limit=None,
            )
        self._executor_max_workers = self._parallelism_plan.planned_sessions
        self._use_threadpool = self._executor_max_workers > 1

    def _ensure_executor(self) -> Optional[ThreadPoolExecutor]:
        if not self._use_threadpool:
            return None
        if self._executor is None:
            self._executor = ThreadPoolExecutor(max_workers=self._executor_max_workers)
        return self._executor

    def _read_one_stream(
        self, stream_id: int, frame_index: int, *, device: Device, cuda_stream: int | None
    ):
        local_index = self._index_resolver(stream_id, frame_index)
        return self._caches[stream_id].frame(
            local_index, device=device, cuda_stream=cuda_stream
        )

    def _should_read_sequentially(
        self, *, device: Device, cuda_stream: int | None = None
    ) -> bool:
        del cuda_stream
        if not self._use_threadpool:
            return True
        # CUDA reads share device context/stream state; keep scheduling in the
        # caller thread and let the decoder sessions do their own pipelining.
        return device == "cuda"

    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: int | None = None,
    ) -> tuple[int, Dict[int, Any]]:
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range [{self.start_frame}, {self.end_frame}]"
            )

        if self._should_read_sequentially(device=device, cuda_stream=cuda_stream):
            result = {
                sid: self._read_one_stream(
                    sid, frame_index, device=device, cuda_stream=cuda_stream
                )
                for sid in self.stream_ids
            }
            return frame_index, result

        executor = self._ensure_executor()
        assert executor is not None

        futures = {
            sid: executor.submit(
                self._read_one_stream,
                sid,
                frame_index,
                device=device,
                cuda_stream=cuda_stream,
            )
            for sid in self.stream_ids
        }
        result: Dict[int, Any] = {}
        try:
            for sid in self.stream_ids:
                result[sid] = futures[sid].result()
        except Exception:
            for future in futures.values():
                future.cancel()
            raise
        return frame_index, result

    def prepare_next_frame(self):
        pass

    @property
    def supports_random_access(self) -> bool:
        return True

    @property
    def decode_parallelism_plan(self) -> NvdecParallelismPlan:
        return self._parallelism_plan

    @property
    def decode_backend_names(self) -> Dict[int, str | None]:
        return {sid: cache.backend_name for sid, cache in self._caches.items()}

    @property
    def decode_session_metrics(self) -> Dict[int, VideoDecodeSessionMetrics]:
        return {sid: cache.metrics for sid, cache in self._caches.items()}

    def close(self) -> None:
        executor = getattr(self, "_executor", None)
        if executor is not None:
            executor.shutdown(wait=True)
            self._executor = None
        for cache in getattr(self, "_caches", {}).values():
            cache.close()

    def __del__(self):
        self.close()
