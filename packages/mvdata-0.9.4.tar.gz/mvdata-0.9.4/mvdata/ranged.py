from functools import lru_cache
import json
from typing import List, Tuple, Dict, Any, Optional
from pathlib import Path
import numpy as np
import re
import shutil
from PIL import Image

from .dataset_base import Dataset, Device, FrameReader
from .stash_utils import save_stash_image
from .video_stream_reader import ParallelVideoFrameReader, VideoPerStreamReader
from pyavif import BatchDecoder, Decoder

RANGED_STREAM_VIDEO_EXTENSIONS = (".avif", ".mp4")
RANGED_MP4_SLICE_METADATA_FILENAME = "_mvdata_mp4_slice.json"


def _stream_id_from_media_stem_plain(stem: str) -> Optional[int]:
    match = re.search(r"\d+", stem)
    return int(match.group()) if match else None


def _discover_stream_files_in_dir(search_dir: Path) -> Dict[int, Path]:
    """Return all ranged stream files in ``search_dir`` keyed by stream id."""
    stream_map: Dict[int, Path] = {}
    for f in search_dir.iterdir():
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        if ext not in RANGED_STREAM_VIDEO_EXTENSIONS:
            continue
        stream_id = _stream_id_from_media_stem_plain(f.stem)
        if stream_id is None:
            continue
        if stream_id in stream_map:
            raise ValueError(
                f"Multiple ranged stream files found for stream {stream_id} in {search_dir}: "
                f"{stream_map[stream_id].name}, {f.name}"
            )
        stream_map[stream_id] = f
    return stream_map


@lru_cache(maxsize=4096)
def _probe_mp4_visible_frame_count_cached(path_str: str, mtime_ns: int, size: int) -> int:
    del mtime_ns, size
    import av

    with av.open(path_str) as container:
        if not container.streams.video:
            raise ValueError(f"No video stream in ranged MP4: {path_str}")
        video_stream = container.streams.video[0]
        return sum(
            1
            for packet in container.demux(video_stream)
            if getattr(packet, "size", 0) > 0 and not bool(packet.is_discard)
        )


def _probe_mp4_visible_frame_count(media_path: Path) -> int:
    stat = media_path.stat()
    return _probe_mp4_visible_frame_count_cached(
        str(media_path),
        int(stat.st_mtime_ns),
        int(stat.st_size),
    )


def _load_mp4_slice_frame_offsets(range_dir: Path) -> dict[int, int]:
    metadata_path = range_dir / "rgb" / RANGED_MP4_SLICE_METADATA_FILENAME
    if not metadata_path.exists():
        metadata_path = range_dir / RANGED_MP4_SLICE_METADATA_FILENAME
    if not metadata_path.exists():
        return {}

    with metadata_path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    streams = payload.get("streams", {})
    offsets: dict[int, int] = {}
    for stream_id_str, stream_meta in streams.items():
        offsets[int(stream_id_str)] = int(stream_meta.get("presentation_frame_offset", 0))
    return offsets


class RangedDataset(Dataset):
    """Ranged convention: batched per-stream containers (AVIF or H.264/HEVC MP4)."""

    def __init__(self, dataset_path: Path, max_workers: Optional[int] = None, gpu_id: int = 0):
        super().__init__(dataset_path, max_workers)

        self._gpu_id = gpu_id

        # Cache for discovered structure
        self._stream_to_raw_name: Dict[int, str] = {}  # Cache of stream_id -> raw filename
        self._initialized = False
        self._frame_ranges_cache: Optional[List[Tuple[int, int, Any]]] = None
        self._stream_subfolder: Optional[str] = None  # Cache for 'rgb', 'images', or '' (root)

    def _extract_first_digit_sequence(self, name: str) -> Optional[int]:
        """Extract first sequence of digits from a string."""
        match = re.search(r"\d+", name)
        if match:
            return int(match.group())
        return None

    def _extract_stream_id_from_filename(self, filename: str) -> Optional[int]:
        """Extract stream ID from a filename (implements base class method)."""
        return self._extract_first_digit_sequence(filename)

    def _get_stash_image_extensions(self) -> List[str]:
        """Get supported image extensions for stash frames."""
        return [".png", ".tiff", ".tif", ".exr", ".jpg"]

    def _find_stash_images_subfolder(self, directory: Path) -> Optional[str]:
        """
        Determine where images are stored in a stash frame directory.
        Checks in order: 'rgb', 'images', then root (None).
        """
        if (directory / "rgb").exists() and (directory / "rgb").is_dir():
            return "rgb"
        elif (directory / "images").exists() and (directory / "images").is_dir():
            return "images"
        else:
            return None  # Images in root

    def _parse_range_folder(self, folder_name: str) -> Optional[Tuple[int, int]]:
        """
        Parse range folder name to extract start and end frame numbers.

        Expected format: {start_frame}_{end_frame}
        We extract the first digit sequence from each part after splitting by underscore.

        Args:
            folder_name: Name of the range folder

        Returns:
            Tuple of (start_frame, end_frame) or None if not a valid range folder
        """
        # Split by underscore
        parts = folder_name.split("_")

        # We need exactly 2 parts
        if len(parts) != 2:
            return None

        # Extract first digit sequence from each part
        start = self._extract_first_digit_sequence(parts[0])
        end = self._extract_first_digit_sequence(parts[1])

        if start is not None and end is not None:
            return (start, end)

        return None

    def _discover_range_directories(self) -> List[Tuple[int, int, Path]]:
        """
        Discover all range directories and extract their frame ranges.

        Returns:
            List of (start_frame, end_frame, directory_path) sorted by start_frame
        """
        range_dirs = []
        for item in self.dataset_path.iterdir():
            # Skip special folders
            if item.name in ["stash", "meta"]:
                continue

            if item.is_dir():
                range_info = self._parse_range_folder(item.name)
                if range_info is not None:
                    start, end = range_info
                    range_dirs.append((start, end, item))

        if not range_dirs:
            raise ValueError(f"No valid range directories found in {self.dataset_path}")

        # Sort by start frame
        range_dirs.sort(key=lambda x: x[0])
        return range_dirs

    def _get_streams_from_range(
        self, range_dir: Path, subfolder: Optional[str] = None
    ) -> Dict[int, Path]:
        """
        Get all per-stream video batches from a range directory (``.avif`` or ``.mp4``).

        Args:
            range_dir: Path to range directory
            subfolder: Specific subfolder to use ('rgb', 'images', or '' for root).
                      If None, will search in order: rgb -> images -> root

        Returns:
            Dict mapping stream_id -> file path
        """
        if subfolder is not None:
            if subfolder == "":
                search_dir = range_dir
            else:
                search_dir = range_dir / subfolder
                if not search_dir.exists():
                    raise ValueError(f"Expected subfolder '{subfolder}' not found in {range_dir}")
        else:
            search_dir = None
            for candidate in ["rgb", "images", ""]:
                if candidate == "":
                    candidate_dir = range_dir
                else:
                    candidate_dir = range_dir / candidate

                if candidate_dir.exists():
                    stream_files = _discover_stream_files_in_dir(candidate_dir)
                    if stream_files:
                        search_dir = candidate_dir
                        break

            if search_dir is None:
                raise ValueError(
                    f"No {RANGED_STREAM_VIDEO_EXTENSIONS} stream files found in {range_dir}. "
                    f"Checked: rgb/, images/, and root directory"
                )

        stream_map = _discover_stream_files_in_dir(search_dir)
        if not stream_map:
            raise ValueError(f"No ranged stream files in {search_dir}")

        return stream_map

    def _probe_stream_file_bit_depth(self, media_path: Path) -> int:
        suffix = media_path.suffix.lower()
        if suffix == ".mp4":
            from . import nvenc_codec

            return int(nvenc_codec.probe_video_bit_depth(media_path))
        if suffix == ".avif":
            decoder = Decoder()
            decoder.init(str(media_path))
            return int(decoder.get_depth())
        raise ValueError(f"Unsupported ranged stream file for bit-depth probe: {media_path}")

    def _probe_stream_map_bit_depth(self, stream_map: Dict[int, Path]) -> int:
        if not stream_map:
            raise ValueError("No streams found in dataset")
        return max(self._probe_stream_file_bit_depth(path) for path in stream_map.values())

    def _initialize_structure(self):
        """
        Initialize dataset structure by scanning the first range.
        This populates caches for stream IDs, etc.
        """
        if self._initialized:
            return

        range_dirs = self._discover_range_directories()
        if not range_dirs:
            raise ValueError(f"No range directories found in {self.dataset_path}")

        # Check first range to establish structure
        start, end, first_range_dir = range_dirs[0]

        # Auto-discover which subfolder contains the streams
        # Try rgb -> images -> root
        stream_map = None
        for candidate in ["rgb", "images", ""]:
            if candidate == "":
                candidate_dir = first_range_dir
            else:
                candidate_dir = first_range_dir / candidate

            if candidate_dir.exists():
                stream_map = _discover_stream_files_in_dir(candidate_dir)
                if stream_map:
                    self._stream_subfolder = candidate
                    break

        if stream_map is None or not stream_map:
            raise ValueError(
                f"No {RANGED_STREAM_VIDEO_EXTENSIONS} files found in {first_range_dir}. "
                f"Checked: rgb/, images/, and root directory"
            )

        for stream_id, avif_path in stream_map.items():
            # Store the raw filename (without path, with extension)
            self._stream_to_raw_name[stream_id] = avif_path.name

        # Cache stream IDs (sorted)
        self._stream_ids_cache = sorted(self._stream_to_raw_name.keys())

        self._initialized = True

    @property
    def stream_ids(self) -> List[int]:
        """
        Get list of all stream IDs available in the dataset.

        Returns:
            Sorted list of stream IDs
        """
        if not self._initialized:
            self._initialize_structure()
        return self._stream_ids_cache

    def stream_name(self, stream_id: int) -> str:
        """
        Get the raw dataset-specific name for a stream ID.

        Args:
            stream_id: Stream ID to get name for

        Returns:
            Raw stream name as it appears in the dataset (e.g., "001.avif", "001.mp4")

        Raises:
            ValueError: If stream_id is not found in dataset
        """
        if not self._initialized:
            self._initialize_structure()

        if stream_id not in self._stream_to_raw_name:
            raise ValueError(
                f"Stream ID {stream_id} not found in dataset. "
                f"Available IDs: {self._stream_ids_cache}"
            )

        return self._stream_to_raw_name[stream_id]

    def get_frame_ranges(self) -> List[Tuple[int, int, Any]]:
        """
        Get available frame ranges from directory structure.

        Returns:
            List of (start_frame, end_frame, range_dir_path) tuples
        """
        if self._frame_ranges_cache is not None:
            return self._frame_ranges_cache

        range_dirs = self._discover_range_directories()

        # Return ranges with their directory paths as metadata
        self._frame_ranges_cache = [(start, end, range_dir) for start, end, range_dir in range_dirs]

        return self._frame_ranges_cache

    def create_frame_reader(
        self,
        stream_ids: Optional[List[int]] = None,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        max_workers: Optional[int] = None,
    ) -> FrameReader:
        """
        Create ranged frame reader.

        Args:
            stream_ids: List of stream IDs to read, or None for all streams
            start_frame: Start frame number, or None for dataset start
            end_frame: End frame number, or None for dataset end
            max_workers: Number of parallel workers for decoding, or None to use dataset default

        Returns:
            RangedFrameReader instance

        Raises:
            ValueError: If requested frames or streams are not available
        """
        # Ensure dataset structure is initialized
        if not self._initialized:
            self._initialize_structure()

        # Use all streams if not specified
        if stream_ids is None:
            stream_ids = self._stream_ids_cache.copy()

        # Validate requested streams exist
        for stream_id in stream_ids:
            if stream_id not in self._stream_ids_cache:
                raise ValueError(
                    f"Stream ID {stream_id} not found in dataset. "
                    f"Available IDs: {self._stream_ids_cache}"
                )

        # Get available frame ranges
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        # Determine dataset bounds
        dataset_start = ranges[0][0]
        dataset_end = ranges[-1][1]

        # Determine actual frame range
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        # Validate frame range
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        # Find which range(s) contain the requested frames
        # For simplicity, we'll find the single range that contains this request
        # If request spans multiple ranges, we need a different reader approach

        selected_ranges = []
        for range_start, range_end, range_dir in ranges:
            # Check if this range overlaps with requested range
            if range_end >= start_frame and range_start <= end_frame:
                selected_ranges.append((range_start, range_end, range_dir))

        if not selected_ranges:
            raise ValueError(
                f"No ranges found for requested frame range [{start_frame}, {end_frame}]"
            )

        # For now, we'll support only reading from a single range
        # Multi-range reading would require a more complex reader
        if len(selected_ranges) > 1:
            raise NotImplementedError(
                f"Reading across multiple ranges not yet implemented. "
                f"Requested range [{start_frame}, {end_frame}] spans {len(selected_ranges)} ranges"
            )

        range_start, range_end, range_dir = selected_ranges[0]

        # Get stream files for this range using the cached subfolder pattern
        stream_files = {}
        for stream_id in stream_ids:
            stream_name = self._stream_to_raw_name[stream_id]
            # Use the cached subfolder pattern ('' means root)
            if self._stream_subfolder == "":
                stream_path = range_dir / stream_name
            else:
                stream_path = range_dir / self._stream_subfolder / stream_name

            if not stream_path.exists():
                raise FileNotFoundError(
                    f"Stream file not found: {stream_path}. "
                    f"Expected pattern: {self._stream_subfolder or 'root'}"
                )
            stream_files[stream_id] = stream_path

        decoder_workers = max_workers if max_workers is not None else self.max_workers
        avif_streams = {
            sid: path for sid, path in stream_files.items() if path.suffix.lower() == ".avif"
        }
        mp4_streams = {
            sid: path for sid, path in stream_files.items() if path.suffix.lower() == ".mp4"
        }

        if avif_streams and not mp4_streams:
            return RangedFrameReader(
                range_dir,
                range_start,
                range_end,
                avif_streams,
                start_frame,
                end_frame,
                decoder_workers,
            )
        if mp4_streams and not avif_streams:
            return RangedMp4FrameReader(
                range_dir,
                range_start,
                range_end,
                mp4_streams,
                start_frame,
                end_frame,
                decoder_max_workers=decoder_workers,
                gpu_id=self._gpu_id,
            )
        if avif_streams and mp4_streams:
            return MixedRangedFrameReader(
                range_dir,
                range_start,
                range_end,
                avif_streams,
                mp4_streams,
                start_frame,
                end_frame,
                decoder_max_workers=decoder_workers,
                gpu_id=self._gpu_id,
            )
        raise ValueError(
            "Unsupported ranged stream containers; expected files ending in "
            f"{RANGED_STREAM_VIDEO_EXTENSIONS}"
        )

    def valid_file_hierarchy(self) -> List[str]:
        """
        Get all valid files in the dataset based on discovered structure.

        This uses the dataset's knowledge of its own structure to build
        the file list, ensuring only valid dataset files are included.

        Returns:
            Sorted list of relative file paths (strings)

        Raises:
            FileNotFoundError: If expected files are missing
        """
        # Ensure structure is initialized
        if not self._initialized:
            self._initialize_structure()

        valid_files = []

        # 1. Add batched stream files from all range directories
        range_dirs = self._discover_range_directories()

        for start, end, range_dir in range_dirs:
            metadata_path = range_dir / "rgb" / RANGED_MP4_SLICE_METADATA_FILENAME
            if metadata_path.exists():
                valid_files.append(str(metadata_path.relative_to(self.dataset_path)))

            # Get streams for this range using the discovered structure
            stream_map = self._get_streams_from_range(range_dir, subfolder=self._stream_subfolder)

            for stream_id, media_path in stream_map.items():
                if not media_path.exists():
                    raise FileNotFoundError(f"Expected stream file not found: {media_path}")

                rel_path = media_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))

        # 2. Add stash frames if they exist
        stash_frames = self.get_stash_frames()
        for frame_num, stream_map in stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(f"Expected stash image file not found: {img_path}")

                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))

        # 3. Add extra stash frames if they exist
        extra_stash_frames = self.get_extra_stash_frames()
        for folder_name, stream_map in extra_stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(
                        f"Expected extra stash image file not found: {img_path}"
                    )

                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))

        # 4. Add meta folder contents (filtered)
        meta_files = self._get_meta_files()
        valid_files.extend(meta_files)

        # Sort and return
        return sorted(valid_files)

    def generate_stash_frames(
        self,
        num_frames: int,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        delete_existing_stash: bool = False,
        overwrite_existing: bool = False,
        verbose: bool = True,
    ) -> List[int]:
        """
        Generate stash frames by extracting frames from AVIF files.

        Frames are saved as:
        - 8-bit PNG for 8-bit AVIF sources
        - 16-bit PNG for >8-bit AVIF sources

        Args:
            num_frames: Number of stash frames to generate
            start_frame: Start frame for selection range (None = dataset start)
            end_frame: End frame for selection range (None = dataset end)
            delete_existing_stash: If True, delete existing numbered stash frames
            overwrite_existing: If True, overwrite existing stash frames with same numbers
            verbose: If True, print progress information

        Returns:
            List of frame numbers that were converted to stash frames
        """
        if num_frames <= 0:
            raise ValueError(f"num_frames must be positive, got {num_frames}")

        # Ensure structure is initialized
        if not self._initialized:
            self._initialize_structure()

        # Get available frame ranges
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        dataset_start = ranges[0][0]
        dataset_end = ranges[-1][1]

        # Determine actual frame range
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        # Validate frame range
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        # Calculate total available frames in range
        total_frames = end_frame - start_frame + 1

        if num_frames > total_frames:
            raise ValueError(
                f"Requested {num_frames} stash frames, but only {total_frames} "
                f"frames available in range [{start_frame}, {end_frame}]"
            )

        # Select evenly spaced frames
        if num_frames == total_frames:
            selected_frames = list(range(start_frame, end_frame + 1))
        else:
            indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
            selected_frames = [start_frame + i for i in indices]

        if verbose:
            print(f"Generating {num_frames} stash frames from ranged dataset...")
            print(f"Selected frames: {selected_frames}")

        # Handle delete existing stash
        stash_dir = self.dataset_path / "stash"
        if delete_existing_stash:
            if verbose:
                print("Deleting existing numbered stash frames...")

            if stash_dir.exists():
                # Only delete numbered frame directories
                for item in stash_dir.iterdir():
                    if item.is_dir():
                        frame_num = self._extract_first_digit_sequence(item.name)
                        if frame_num is not None:
                            if verbose:
                                print(f"  Deleting stash/{item.name}")
                            shutil.rmtree(item)

            # Clear cache
            self._stash_frames_cache = None

        # Create stash directory if it doesn't exist
        stash_dir.mkdir(exist_ok=True)

        # Check for collisions if not overwriting
        if not overwrite_existing and not delete_existing_stash:
            existing_stash = self.get_stash_frames()
            existing_frame_nums = {fn for fn, _ in existing_stash}

            collisions = [fn for fn in selected_frames if fn in existing_frame_nums]
            if collisions:
                raise ValueError(
                    f"Stash frames already exist for frames {collisions}. "
                    f"Use overwrite_existing=True or delete_existing_stash=True to overwrite."
                )

        ranges = self.get_frame_ranges()
        first_range_dir = ranges[0][2]
        stream_map = self._get_streams_from_range(first_range_dir, subfolder=self._stream_subfolder)

        if not stream_map:
            raise ValueError("No streams found in dataset")

        bit_depth = self._probe_stream_map_bit_depth(stream_map)

        if verbose:
            print(f"Detected bit depth: {bit_depth}")
            print(f"Will save as {'16-bit' if bit_depth > 8 else '8-bit'} PNG")

        # Process each selected frame
        for frame_num in selected_frames:
            if verbose:
                print(f"Extracting frame {frame_num} to stash...")

            # Create destination directory
            dest_dir = stash_dir / f"{frame_num:08d}"

            # If overwriting, delete existing first
            if dest_dir.exists():
                if overwrite_existing:
                    shutil.rmtree(dest_dir)
                else:
                    raise ValueError(
                        f"Stash frame {frame_num} already exists. "
                        f"Use overwrite_existing=True to overwrite."
                    )

            # Create directory structure matching dataset convention
            # Use the same subfolder structure as the dataset
            if self._stream_subfolder and self._stream_subfolder != "":
                images_dir = dest_dir / self._stream_subfolder
            else:
                images_dir = dest_dir

            images_dir.mkdir(parents=True, exist_ok=True)

            # Create frame reader for this single frame
            reader = self.create_frame_reader(
                stream_ids=self.stream_ids, start_frame=frame_num, end_frame=frame_num
            )
            try:
                # Read the frame
                _, frame_data = reader.read_frame(frame_num)
            finally:
                reader.close()

            # Save each stream as PNG
            for stream_id in sorted(frame_data.keys()):
                array = frame_data[stream_id]

                # Determine output filename (use same naming as dataset)
                stream_name = self._stream_to_raw_name[stream_id]
                output_name = f"{Path(stream_name).stem}.png"
                output_path = images_dir / output_name
                save_stash_image(array, output_path)

        if verbose:
            print(f"Successfully generated {num_frames} stash frames")

        # Clear cache
        self._stash_frames_cache = None

        return selected_frames

    def _get_dataset_info(self) -> Dict[str, Any]:
        """Get dataset info including ranged-specific details."""
        info = super()._get_dataset_info()

        ranges = self.get_frame_ranges()
        info["num_ranges"] = len(ranges)

        if not self._initialized:
            self._initialize_structure()

        if self._stream_to_raw_name:
            first_range = ranges[0][2] if ranges else None
            if first_range:
                stream_map = self._get_streams_from_range(
                    first_range, subfolder=self._stream_subfolder
                )
                if stream_map:
                    info["bit_depth"] = self._probe_stream_map_bit_depth(stream_map)

        return info

    def _get_extra_repr_lines(self, info: Dict[str, Any]) -> List[str]:
        """Add ranged-specific info to repr."""
        lines = []
        if info.get("num_ranges", 1) > 1:
            lines.append(f"  Ranges: {info['num_ranges']}")
        if "bit_depth" in info:
            lines.append(f"  Bit Depth: {info['bit_depth']}")
        return lines

    def validate(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Validate dataset against Ranged convention specification.

        This checks:
        - Range folder naming convention (8-digit zero-padded)
        - Stream ID consistency across ranges
        - No range overlap
        - Stream naming convention (3-digit zero-padded)
        - Stash frame naming convention (8-digit zero-padded absolute frame numbers)
        - Meta folder structure
        - File format compliance

        Args:
            verbose: If True, print validation progress

        Returns:
            Dictionary with validation results:
            - 'valid': bool indicating if dataset is valid
            - 'errors': list of error messages
            - 'warnings': list of warning messages
            - 'stats': dict with dataset statistics
        """
        errors = []
        warnings = []
        stats = {
            "total_ranges": 0,
            "total_frames": 0,
            "stream_ids": set(),
            "stream_count": 0,
            "bit_depth": None,
            "has_stash": False,
            "stash_frames": 0,
            "has_extra_stash": False,
            "extra_stash_count": 0,
            "has_meta": False,
            "has_audio": False,
            "has_calibration": False,
        }

        if verbose:
            print("Validating Ranged dataset...")

        # 1. Validate range folder naming and structure
        if verbose:
            print("  Checking range folders...")

        try:
            range_dirs = self._discover_range_directories()
        except ValueError as e:
            errors.append(f"Failed to discover range directories: {e}")
            return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

        if not range_dirs:
            errors.append("No valid range directories found")
            return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

        stats["total_ranges"] = len(range_dirs)
        stats["total_frames"] = sum(end - start + 1 for start, end, _ in range_dirs)

        # Check range folder naming convention
        for start, end, range_dir in range_dirs:
            folder_name = range_dir.name

            # Verify 8-digit zero padding
            expected_name = f"{start:08d}_{end:08d}"
            if folder_name != expected_name:
                errors.append(
                    f"Range folder '{folder_name}' does not follow naming convention. "
                    f"Expected: '{expected_name}'"
                )

        # 2. Check for range overlaps and gaps
        if verbose:
            print("  Checking for range overlaps and gaps...")

        for i in range(len(range_dirs) - 1):
            curr_start, curr_end, curr_dir = range_dirs[i]
            next_start, next_end, next_dir = range_dirs[i + 1]

            if curr_end >= next_start:
                errors.append(
                    f"Range overlap detected: {curr_dir.name} (ends at {curr_end}) "
                    f"overlaps with {next_dir.name} (starts at {next_start})"
                )
            elif curr_end + 1 < next_start:
                # There's a gap in the ranges
                gap_size = next_start - curr_end - 1
                warnings.append(
                    f"Gap detected: {gap_size} frame(s) missing between "
                    f"{curr_dir.name} and {next_dir.name}"
                )

        # 3. Validate stream consistency across ranges
        if verbose:
            print("  Checking stream consistency...")

        try:
            if not self._initialized:
                self._initialize_structure()
        except Exception as e:
            errors.append(f"Failed to initialize dataset structure: {e}")
            return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

        # Get streams from first range as reference
        first_range_streams = set(self._stream_ids_cache)
        stats["stream_ids"] = first_range_streams.copy()
        stats["stream_count"] = len(first_range_streams)

        # Check each range has the same streams
        for start, end, range_dir in range_dirs:
            try:
                stream_map = self._get_streams_from_range(
                    range_dir, subfolder=self._stream_subfolder
                )
                range_streams = set(stream_map.keys())

                if range_streams != first_range_streams:
                    missing = first_range_streams - range_streams
                    extra = range_streams - first_range_streams

                    msg = f"Stream mismatch in {range_dir.name}:"
                    if missing:
                        msg += f" missing streams {sorted(missing)},"
                    if extra:
                        msg += f" extra streams {sorted(extra)},"
                    errors.append(msg.rstrip(","))

                # Verify stream filenames match across ranges
                for stream_id in range_streams:
                    expected_name = self._stream_to_raw_name[stream_id]
                    actual_path = stream_map[stream_id]
                    actual_name = actual_path.name

                    if actual_name != expected_name:
                        errors.append(
                            f"Stream {stream_id} filename mismatch in {range_dir.name}: "
                            f"expected '{expected_name}', got '{actual_name}'"
                        )

            except Exception as e:
                errors.append(f"Failed to validate streams in {range_dir.name}: {e}")

        # 4. Validate stream naming convention (3-digit zero padding)
        if verbose:
            print("  Checking stream naming convention...")

        for stream_id, stream_name in self._stream_to_raw_name.items():
            # Extract the numeric part (before extension)
            stem = Path(stream_name).stem

            if not re.match(r"^\d{3}$", stem):
                errors.append(
                    f"Stream '{stream_name}' does not follow 3-digit zero-padding convention. "
                    f"Expected format: '###.avif' or '###.mp4' (e.g., '001.avif')"
                )
            sfx = Path(stream_name).suffix.lower()
            if sfx not in RANGED_STREAM_VIDEO_EXTENSIONS:
                errors.append(
                    f"Stream '{stream_name}' must use extension in {RANGED_STREAM_VIDEO_EXTENSIONS}"
                )

            # Verify stream ID matches the filename
            extracted_id = self._extract_first_digit_sequence(stem)
            if extracted_id != stream_id:
                errors.append(
                    f"Stream ID mismatch: filename '{stream_name}' suggests ID {extracted_id}, "
                    f"but dataset uses ID {stream_id}"
                )

        # 5. Validate stash folder structure
        if verbose:
            print("  Checking stash folder...")

        stash_dir = self.dataset_path / "stash"
        if stash_dir.exists():
            stats["has_stash"] = True
            try:
                stash_frames = self.get_stash_frames()
                stats["stash_frames"] = len(stash_frames)

                for frame_num, stream_map in stash_frames:
                    # Verify 8-digit zero padding for frame directories
                    expected_dir_name = f"{frame_num:08d}"
                    frame_dir = stash_dir / expected_dir_name

                    if not frame_dir.exists():
                        errors.append(
                            f"Stash frame directory naming issue: expected '{expected_dir_name}' "
                            f"for frame {frame_num}"
                        )

                    # Check that stash has same streams as dataset
                    stash_stream_ids = set(stream_map.keys())
                    if stash_stream_ids != first_range_streams:
                        missing = first_range_streams - stash_stream_ids
                        extra = stash_stream_ids - first_range_streams

                        msg = f"Stream mismatch in stash frame {frame_num}:"
                        if missing:
                            msg += f" missing streams {sorted(missing)},"
                        if extra:
                            msg += f" extra streams {sorted(extra)},"
                        errors.append(msg.rstrip(","))

            except Exception as e:
                errors.append(f"Failed to validate stash folder: {e}")

        # 6. Validate extra stash frames
        if verbose:
            print("  Checking extra stash frames...")

        if stash_dir.exists():
            try:
                extra_stash = self.get_extra_stash_frames()
                if extra_stash:
                    stats["has_extra_stash"] = True
                    stats["extra_stash_count"] = len(extra_stash)

                for folder_name, stream_map in extra_stash:
                    # Extra stash frames should follow same stream consistency
                    stash_stream_ids = set(stream_map.keys())
                    if stash_stream_ids != first_range_streams:
                        missing = first_range_streams - stash_stream_ids
                        extra = stash_stream_ids - first_range_streams

                        msg = f"Stream mismatch in extra stash '{folder_name}':"
                        if missing:
                            msg += f" missing streams {sorted(missing)},"
                        if extra:
                            msg += f" extra streams {sorted(extra)},"
                        errors.append(msg.rstrip(","))

            except Exception as e:
                errors.append(f"Failed to validate extra stash frames: {e}")

        # 7. Validate meta folder
        if verbose:
            print("  Checking meta folder...")

        meta_dir = self.dataset_path / "meta"
        if meta_dir.exists():
            stats["has_meta"] = True

            # Check for audio files
            audio_extensions = {".wav", ".mp3"}
            audio_files = []

            for ext in audio_extensions:
                audio_files.extend(meta_dir.rglob(f"*{ext}"))

            if audio_files:
                stats["has_audio"] = True
                if verbose:
                    print(f"    Found {len(audio_files)} audio file(s)")

            # Check for calibration data (optional but should follow structure if present)
            calibration_dir = meta_dir / "calibration" / "sparse" / "0"
            if calibration_dir.exists():
                stats["has_calibration"] = True
                if verbose:
                    print("    Found calibration data")

        # 8. Validate stream container (AVIF or MP4)
        if verbose:
            print("  Checking ranged stream file format...")

        if range_dirs:
            first_range = range_dirs[0][2]
            try:
                stream_map = self._get_streams_from_range(
                    first_range, subfolder=self._stream_subfolder
                )

                if stream_map:
                    try:
                        bit_depth = self._probe_stream_map_bit_depth(stream_map)
                        stats["bit_depth"] = bit_depth

                        if verbose:
                            print(f"    Stream bit depth: {bit_depth}")

                    except Exception as e:
                        first_name = next(iter(stream_map.values())).name
                        errors.append(f"Failed to decode stream file '{first_name}': {e}")

            except Exception as e:
                errors.append(f"Failed to validate stream format: {e}")

        # 9. Check for invalid files in dataset root
        if verbose:
            print("  Checking for unexpected files...")

        valid_root_items = {"stash", "meta"}

        for item in self.dataset_path.iterdir():
            if item.name.startswith("."):
                continue  # Skip hidden files

            if item.is_file():
                errors.append(
                    f"Unexpected file in dataset root: '{item.name}'. "
                    f"Only directories are expected in dataset root."
                )
            elif item.is_dir():
                # Check if it's a range directory
                range_info = self._parse_range_folder(item.name)
                if range_info is None and item.name not in valid_root_items:
                    errors.append(
                        f"Unexpected directory in dataset root: '{item.name}'. "
                        f"Expected range folders or 'stash'/'meta' directories."
                    )

        # Summary
        is_valid = len(errors) == 0

        if verbose:
            print(f"\nValidation Summary:")
            print(f"  Ranges: {stats['total_ranges']}")
            print(f"  Total Frames: {stats['total_frames']}")
            print(f"  Streams: {stats['stream_count']} (IDs: {sorted(stats['stream_ids'])})")
            if stats["bit_depth"]:
                print(f"  Bit Depth: {stats['bit_depth']}")
            if stats["has_stash"]:
                print(f"  Stash Frames: {stats['stash_frames']}")
            if stats["has_extra_stash"]:
                print(f"  Extra Stash: {stats['extra_stash_count']}")
            if stats["has_audio"]:
                print(f"  Audio: Yes")
            if stats["has_calibration"]:
                print(f"  Calibration: Yes")

            if warnings:
                print(f"\nWARN: {len(warnings)} warning(s)")
                for i, warning in enumerate(warnings, 1):
                    print(f"  {i}. {warning}")

            if errors:
                print(f"\nERROR: {len(errors)} error(s)")
                for i, error in enumerate(errors, 1):
                    print(f"  {i}. {error}")
                print("\nValidation FAILED")
            else:
                print("\nValidation PASSED - Dataset is valid")

        return {"valid": is_valid, "errors": errors, "warnings": warnings, "stats": stats}


_Mp4PerStreamReader = VideoPerStreamReader


class RangedMp4FrameReader(ParallelVideoFrameReader):
    """Frame reader for ranged per-stream MP4 batches (e.g. NVENC-encoded ranges).

    Uses NVDEC for GPU-accelerated decode when ``PyNvVideoCodec`` is
    available and not disabled via environment policy.  B-frame streams are
    served by presentation timestamp rather than decoder ordinal.
    """

    def __init__(
        self,
        range_dir: Path,
        range_start: int,
        range_end: int,
        stream_files: Dict[int, Path],
        start_frame: int,
        end_frame: int,
        *,
        decoder_max_workers: int = 4,
        gpu_id: int = 0,
    ):
        self.range_dir = range_dir
        self.range_start = range_start
        self.range_end = range_end
        self.stream_files = stream_files

        if start_frame < range_start or end_frame > range_end:
            raise ValueError(
                f"Requested frames [{start_frame}, {end_frame}] outside "
                f"range [{range_start}, {range_end}]"
            )

        self.stream_ids = sorted(stream_files.keys())
        n_local = range_end - range_start + 1
        from . import nvenc_codec

        bit_depths = {
            sid: int(nvenc_codec.probe_video_bit_depth(stream_files[sid]))
            for sid in self.stream_ids
        }
        self._bit_depth = max(bit_depths.values(), default=8)
        frame_offsets = _load_mp4_slice_frame_offsets(range_dir)
        frame_counts = {
            sid: _probe_mp4_visible_frame_count(stream_files[sid])
            for sid in self.stream_ids
        }
        short_counts = {
            sid: count
            for sid, count in frame_counts.items()
            if count < n_local + int(frame_offsets.get(sid, 0))
        }
        if short_counts:
            details = ", ".join(
                f"{stream_files[sid].name}: {count}" for sid, count in sorted(short_counts.items())
            )
            raise ValueError(
                f"Ranged MP4 range {range_dir.name} declares {n_local} frames "
                f"({range_start}-{range_end}), but decoded visible frame counts are too short: "
                f"{details}. Re-slice or rewrite this ranged dataset; reading it with "
                "NVDEC can otherwise return packet-indexed, shifted frames."
            )
        super().__init__(
            stream_files=stream_files,
            frame_counts=frame_counts,
            start_frame=start_frame,
            end_frame=end_frame,
            decoder_max_workers=decoder_max_workers,
            gpu_id=gpu_id,
            bit_depths=bit_depths,
            index_resolver=lambda sid, frame_index: (
                frame_index - self.range_start + int(frame_offsets.get(sid, 0))
            ),
        )

    def get_bit_depth(self) -> int:
        return self._bit_depth


class MixedRangedFrameReader(FrameReader):
    """Frame reader for ranges containing a mix of AVIF and MP4 per-stream files."""

    def __init__(
        self,
        range_dir: Path,
        range_start: int,
        range_end: int,
        avif_stream_files: Dict[int, Path],
        mp4_stream_files: Dict[int, Path],
        start_frame: int,
        end_frame: int,
        *,
        decoder_max_workers: int = 4,
        gpu_id: int = 0,
    ):
        super().__init__(start_frame, end_frame)

        self._avif_reader = (
            RangedFrameReader(
                range_dir,
                range_start,
                range_end,
                avif_stream_files,
                start_frame,
                end_frame,
                decoder_max_workers,
            )
            if avif_stream_files
            else None
        )
        self._mp4_reader = (
            RangedMp4FrameReader(
                range_dir,
                range_start,
                range_end,
                mp4_stream_files,
                start_frame,
                end_frame,
                decoder_max_workers=decoder_max_workers,
                gpu_id=gpu_id,
            )
            if mp4_stream_files
            else None
        )
        self._bit_depth = 8
        if self._avif_reader is not None:
            self._bit_depth = max(self._bit_depth, self._avif_reader.get_bit_depth())
        if self._mp4_reader is not None:
            self._bit_depth = max(self._bit_depth, self._mp4_reader.get_bit_depth())

    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        result: Dict[int, Any] = {}
        if self._avif_reader is not None:
            _, avif_frames = self._avif_reader.read_frame(
                frame_index, device=device, cuda_stream=cuda_stream
            )
            result.update(avif_frames)
        if self._mp4_reader is not None:
            _, mp4_frames = self._mp4_reader.read_frame(
                frame_index, device=device, cuda_stream=cuda_stream
            )
            result.update(mp4_frames)
        return frame_index, result

    def get_bit_depth(self) -> int:
        return self._bit_depth

    def prepare_next_frame(self):
        if self._avif_reader is not None:
            self._avif_reader.prepare_next_frame()
        if self._mp4_reader is not None:
            self._mp4_reader.prepare_next_frame()

    def close(self) -> None:
        if self._avif_reader is not None:
            self._avif_reader.close()
        if self._mp4_reader is not None:
            self._mp4_reader.close()

    @property
    def supports_random_access(self) -> bool:
        return True


class RangedFrameReader(FrameReader):
    """Frame reader for ranged AVIF dataset format."""

    def __init__(
        self,
        range_dir: Path,
        range_start: int,
        range_end: int,
        stream_files: Dict[int, Path],
        start_frame: int,
        end_frame: int,
        decoder_max_workers: int = 4,
    ):
        """
        Initialize frame reader for a single range.

        Args:
            range_dir: Path to the range directory
            range_start: First frame number in this range
            range_end: Last frame number in this range
            stream_files: Dict mapping stream_id -> Path to AVIF file
            start_frame: First frame to read
            end_frame: Last frame to read
            decoder_max_workers: Number of decoder threads
        """
        super().__init__(start_frame, end_frame)

        self.range_dir = range_dir
        self.range_start = range_start
        self.range_end = range_end
        self.stream_files = stream_files
        self.decoder_max_workers = decoder_max_workers

        # Validate that requested frames are within range
        if start_frame < range_start or end_frame > range_end:
            raise ValueError(
                f"Requested frames [{start_frame}, {end_frame}] outside "
                f"range [{range_start}, {range_end}]"
            )

        # Create list of stream IDs and their corresponding file paths
        # We need to maintain order for consistent mapping
        self.stream_ids = sorted(stream_files.keys())
        avif_files = [str(stream_files[sid]) for sid in self.stream_ids]

        # Create batch decoder with all AVIF files
        # max_workers: number of files to decode concurrently
        # decoder_threads: libavif threads per file (1 recommended to avoid oversubscription)
        self.batch_decoder = BatchDecoder(
            avif_files, max_workers=decoder_max_workers, decoder_threads=1
        )

        # Cache bit depth by reading it from the first file
        self._bit_depth = None
        if avif_files:
            # Create a temporary single decoder to get metadata
            temp_decoder = Decoder()
            temp_decoder.init(avif_files[0])
            self._bit_depth = temp_decoder.get_depth()

    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        """Decode a single AVIF frame from each stream.

        AVIF decode is CPU-only; ``device='cuda'`` returns dlpack-capable
        ``cupy.ndarray`` values produced by an explicit H2D copy.
        """
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range [{self.start_frame}, {self.end_frame}]"
            )

        index_in_range = frame_index - self.range_start
        batch_index, tensors = self.batch_decoder.get_batch_at(index_in_range)
        if batch_index != index_in_range:
            raise RuntimeError(f"Index mismatch: requested {index_in_range}, got {batch_index}")

        result: Dict[int, Any] = {}
        for stream_id in self.stream_ids:
            file_path = str(self.stream_files[stream_id])
            if file_path in tensors:
                result[stream_id] = tensors[file_path]

        missing_streams = [stream_id for stream_id in self.stream_ids if stream_id not in result]
        if missing_streams:
            raise RuntimeError(
                f"Missing decoded tensors for streams {missing_streams} at frame {frame_index}"
            )

        if device == "cuda":
            from . import nvenc_codec

            result = {
                sid: nvenc_codec.numpy_to_cupy_rgb(arr, cuda_stream=cuda_stream)
                for sid, arr in result.items()
            }
        return frame_index, result

    def get_bit_depth(self) -> int:
        """Get bit depth of the images."""
        return self._bit_depth if self._bit_depth is not None else 8

    def prepare_next_frame(self):
        """
        Prepare for reading the next frame.

        Note: This is a no-op in the current implementation as the new
        BatchDecoder API doesn't expose explicit prefetching controls.
        """
        pass

    def close(self) -> None:
        close_fn = getattr(self.batch_decoder, "close", None)
        if callable(close_fn):
            close_fn()

    @property
    def supports_random_access(self) -> bool:
        """Ranged AVIF reader supports random access."""
        return True
