from typing import List, Tuple, Dict, Any, Optional
from pathlib import Path
from PIL import Image
import numpy as np
from concurrent.futures import ThreadPoolExecutor
import re
import os
import shutil

from .dataset_base import Dataset, Device, FrameReader


class LegacyDataset(Dataset):
    """Implementation for Legacy dataset convention."""

    # Supported image extensions (case insensitive)
    SUPPORTED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".tiff", ".tif", ".avif"]

    def __init__(self, dataset_path: Path, per_camera: bool = False, max_workers: Optional[int] = None):
        super().__init__(dataset_path, max_workers)
        self.per_camera = per_camera

        # Cache for discovered structure
        self._images_subfolder = None  # Will be 'rgb', 'images', or None (root)
        self._stream_to_raw_name: Dict[int, str] = {}  # stream_id -> raw filename or camera dir
        self._camera_frame_map: Dict[int, Dict[int, Path]] = {}
        self._common_frame_numbers: List[int] = []
        self._initialized = False
        self._frame_ranges_cache: Optional[List[Tuple[int, int, Any]]] = None
        self._frame_dirs_cache: Optional[List[Tuple[int, Path]]] = None

    def _extract_first_digit_sequence(self, name: str) -> Optional[int]:
        """Extract first sequence of digits from a string."""
        match = re.search(r"\d+", name)
        if match:
            return int(match.group())
        return None

    def _extract_stream_id_from_filename(self, filename: str) -> Optional[int]:
        """Extract stream ID from a filename (implements base class method)."""
        return self._extract_first_digit_sequence(filename)

    def _get_stash_image_extensions(self) -> List[str]:
        """Get supported image extensions for stash frames (same as main dataset)."""
        return self.SUPPORTED_EXTENSIONS

    def _find_stash_images_subfolder(self, directory: Path) -> Optional[str]:
        """
        Determine where images are stored in a stash frame directory.
        Reuses the existing _find_images_subfolder method.
        """
        return self._find_images_subfolder(directory)

    def _find_images_subfolder(self, directory: Path) -> Optional[str]:
        """
        Determine where images are stored according to spec deviations:
        1. First try 'rgb' subfolder (if it contains images)
        2. Then try 'images' subfolder (if it contains images)
        3. Finally try root of directory

        Returns: 'rgb', 'images', or None (for root)
        """
        rgb_dir = directory / "rgb"
        if rgb_dir.exists() and rgb_dir.is_dir() and self._get_image_files_in_dir(rgb_dir):
            return "rgb"

        images_dir = directory / "images"
        if images_dir.exists() and images_dir.is_dir() and self._get_image_files_in_dir(images_dir):
            return "images"

        return None  # Images in root

    def _get_image_files_in_dir(self, directory: Path) -> List[Path]:
        """Get all supported image files in a directory."""
        image_files = []
        for item in directory.iterdir():
            if item.is_file() and item.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                image_files.append(item)
        return image_files

    def _discover_frame_directories(self) -> List[Tuple[int, Path]]:
        """
        Discover all frame directories and extract their frame numbers.
        Returns list of (frame_number, directory_path) sorted by frame_number.
        Results are cached for efficiency.
        """
        if self._frame_dirs_cache is not None:
            return self._frame_dirs_cache

        frame_dirs = []
        for item in self.dataset_path.iterdir():
            # Skip special folders
            if item.name in ["stash", "meta"]:
                continue

            if item.is_dir():
                frame_num = self._extract_first_digit_sequence(item.name)
                if frame_num is not None:
                    frame_dirs.append((frame_num, item))

        if not frame_dirs:
            raise ValueError(f"No frame directories found in {self.dataset_path}")

        # Sort by frame number
        frame_dirs.sort(key=lambda x: x[0])
        self._frame_dirs_cache = frame_dirs
        return frame_dirs

    def _discover_camera_directories(self) -> List[Tuple[int, Path]]:
        """
        Discover all camera directories and extract their stream IDs.

        Returns list of (stream_id, directory_path) sorted by stream_id.
        """
        camera_dirs = []
        for item in self.dataset_path.iterdir():
            if item.name in ["stash", "meta"]:
                continue

            if item.is_dir():
                stream_id = self._extract_first_digit_sequence(item.name)
                if stream_id is not None:
                    camera_dirs.append((stream_id, item))

        if not camera_dirs:
            raise ValueError(f"No camera directories found in {self.dataset_path}")

        camera_dirs.sort(key=lambda x: x[0])
        return camera_dirs

    def _get_frame_files_for_camera(
        self, camera_dir: Path
    ) -> Tuple[Optional[str], Dict[int, Path]]:
        """
        Get all frame image files for a camera directory.

        Returns:
            Tuple of (subfolder, frame_map) where frame_map maps frame_id -> image_path
        """
        subfolder = self._find_images_subfolder(camera_dir)

        if subfolder:
            images_dir = camera_dir / subfolder
        else:
            images_dir = camera_dir

        frame_map = {}
        for img_path in self._get_image_files_in_dir(images_dir):
            frame_id = self._extract_first_digit_sequence(img_path.stem)
            if frame_id is not None:
                frame_map[frame_id] = img_path

        return subfolder, frame_map

    def _frames_to_ranges(self, frame_numbers: List[int]) -> List[Tuple[int, int]]:
        """
        Convert list of frame numbers to list of continuous ranges.

        Args:
            frame_numbers: Sorted list of frame numbers

        Returns:
            List of (start, end) tuples representing inclusive ranges
        """
        if not frame_numbers:
            return []

        ranges = []
        start = frame_numbers[0]
        end = frame_numbers[0]

        for i in range(1, len(frame_numbers)):
            if frame_numbers[i] == end + 1:
                # Continuous, extend current range
                end = frame_numbers[i]
            else:
                # Gap found, save current range and start new one
                ranges.append((start, end))
                start = frame_numbers[i]
                end = frame_numbers[i]

        # Add final range
        ranges.append((start, end))
        return ranges

    def _is_frame_complete(self, frame_dir: Path, canonical_streams: set) -> bool:
        """Check if a frame directory has all canonical streams."""
        frame_streams = set(self._get_streams_from_directory(frame_dir).keys())
        return canonical_streams <= frame_streams

    def get_frame_ranges(self) -> List[Tuple[int, int, Any]]:
        """
        Get available frame ranges from directory structure.

        Returns single range from min to max frame, with metadata containing
        the actual continuous ranges and frame paths. Validates boundary frames
        have all streams from the canonical first frame; incomplete frames at
        boundaries are trimmed, while gaps in the middle are handled during iteration.
        """
        if self._frame_ranges_cache is not None:
            return self._frame_ranges_cache

        if self.per_camera:
            if not self._initialized:
                self._initialize_structure()

            if not self._common_frame_numbers:
                raise ValueError("No common frames available across cameras")

            continuous_ranges = self._frames_to_ranges(self._common_frame_numbers)
            range_metadata = {
                "valid_ranges": continuous_ranges,
            }

            self._frame_ranges_cache = [
                (
                    min(self._common_frame_numbers),
                    max(self._common_frame_numbers),
                    range_metadata,
                )
            ]
            return self._frame_ranges_cache

        frame_dirs = self._discover_frame_directories()

        # Get canonical stream IDs from first frame
        first_frame_num, first_frame_dir = frame_dirs[0]
        canonical_streams = set(self._get_streams_from_directory(first_frame_dir).keys())
        if not canonical_streams:
            raise ValueError(
                f"No image streams found in first frame directory: {first_frame_dir}"
            )

        # Scan backward from the end to find last valid frame
        # This is much faster than checking all frames when only the tail is incomplete
        last_valid_idx = len(frame_dirs) - 1
        while last_valid_idx >= 0:
            _, frame_dir = frame_dirs[last_valid_idx]
            if self._is_frame_complete(frame_dir, canonical_streams):
                break
            last_valid_idx -= 1

        if last_valid_idx < 0:
            raise ValueError(f"No valid frames found with all {len(canonical_streams)} canonical streams")

        # Scan forward from the start to find first valid frame (usually index 0)
        first_valid_idx = 0
        while first_valid_idx <= last_valid_idx:
            _, frame_dir = frame_dirs[first_valid_idx]
            if self._is_frame_complete(frame_dir, canonical_streams):
                break
            first_valid_idx += 1

        # Trim to valid range
        valid_frame_dirs = frame_dirs[first_valid_idx:last_valid_idx + 1]

        # Extract frame numbers and create mapping
        frame_numbers = [fn for fn, _ in valid_frame_dirs]
        frame_number_to_path = {fn: path for fn, path in valid_frame_dirs}

        # Convert frame numbers to continuous ranges for efficient lookup
        # Note: gaps in the middle are handled during iteration (IncompleteFrameError)
        continuous_ranges = self._frames_to_ranges(frame_numbers)

        # For legacy format, we return the entire span as one chunk
        # range_metadata contains the continuous ranges and paths to handle gaps
        range_metadata = {
            "valid_ranges": continuous_ranges,  # List of (start, end) tuples
            "frame_to_path": frame_number_to_path,
        }

        self._frame_ranges_cache = [(min(frame_numbers), max(frame_numbers), range_metadata)]
        return self._frame_ranges_cache

    def _get_streams_from_directory(self, directory: Path) -> Dict[int, Path]:
        """
        Get all image streams from a directory.
        Returns dict mapping stream_id -> image_path
        """
        # Determine where images are located
        subfolder = self._find_images_subfolder(directory)

        if subfolder:
            images_dir = directory / subfolder
        else:
            images_dir = directory

        # Get all image files
        image_files = self._get_image_files_in_dir(images_dir)

        # Extract stream IDs
        stream_map = {}
        for img_path in image_files:
            stream_id = self._extract_first_digit_sequence(img_path.stem)
            if stream_id is not None:
                stream_map[stream_id] = img_path

        return stream_map

    def _initialize_structure(self):
        """
        Initialize dataset structure by scanning the first frame.
        This populates caches for stream IDs, subfolder structure, etc.
        """
        if self._initialized:
            return

        if self.per_camera:
            self._initialize_camera_structure()
            return

        frame_dirs = self._discover_frame_directories()
        if not frame_dirs:
            raise ValueError(f"No frame directories found in {self.dataset_path}")

        # Check first frame to establish structure
        first_frame_num, first_frame_dir = frame_dirs[0]

        # Discover and cache the images subfolder structure
        self._images_subfolder = self._find_images_subfolder(first_frame_dir)

        # Get streams and cache their raw names
        stream_map = self._get_streams_from_directory(first_frame_dir)

        for stream_id, img_path in stream_map.items():
            # Store the raw filename (without path, with extension)
            self._stream_to_raw_name[stream_id] = img_path.name

        # Cache stream IDs (sorted)
        self._stream_ids_cache = sorted(self._stream_to_raw_name.keys())

        self._initialized = True

    def _initialize_camera_structure(self) -> None:
        """
        Initialize dataset structure by scanning camera directories.
        This populates caches for stream IDs, per-camera frames, and shared ranges.
        """
        camera_dirs = self._discover_camera_directories()
        if not camera_dirs:
            raise ValueError(f"No camera directories found in {self.dataset_path}")

        first_stream_id, first_camera_dir = camera_dirs[0]
        first_subfolder, first_frame_map = self._get_frame_files_for_camera(first_camera_dir)

        if not first_frame_map:
            raise ValueError(f"No frame images found in {first_camera_dir}")

        self._images_subfolder = first_subfolder
        common_frames = set(first_frame_map.keys())

        for stream_id, camera_dir in camera_dirs:
            subfolder, frame_map = self._get_frame_files_for_camera(camera_dir)
            if not frame_map:
                raise ValueError(f"No frame images found in {camera_dir}")

            if subfolder != self._images_subfolder:
                raise ValueError(
                    "Inconsistent camera folder structure: "
                    f"expected '{self._images_subfolder}', found '{subfolder}' in {camera_dir}"
                )

            self._stream_to_raw_name[stream_id] = camera_dir.name
            self._camera_frame_map[stream_id] = frame_map
            common_frames &= set(frame_map.keys())

        if not common_frames:
            raise ValueError("No common frames found across cameras")

        self._common_frame_numbers = sorted(common_frames)
        self._stream_ids_cache = sorted(self._stream_to_raw_name.keys())
        self._initialized = True

    @property
    def stream_ids(self) -> List[int]:
        """
        Get list of all stream IDs available in the dataset.

        Returns:
            Sorted list of stream IDs
        """
        if not self._initialized:
            self._initialize_structure()
        return self._stream_ids_cache or []

    def stream_name(self, stream_id: int) -> str:
        """
        Get the raw dataset-specific name for a stream ID.

        Args:
            stream_id: Stream ID to get name for

        Returns:
            Raw stream name as it appears in the dataset

        Raises:
            ValueError: If stream_id is not found in dataset
        """
        if not self._initialized:
            self._initialize_structure()

        if stream_id not in self._stream_to_raw_name:
            raise ValueError(
                f"Stream ID {stream_id} not found in dataset. "
                f"Available IDs: {self._stream_ids_cache}"
            )

        return self._stream_to_raw_name[stream_id]

    def _get_dataset_info(self) -> Dict[str, Any]:
        """Get dataset info including legacy-specific details."""
        info = super()._get_dataset_info()

        if not self._initialized:
            self._initialize_structure()

        info["per_camera"] = self.per_camera
        info["images_location"] = self._images_subfolder if self._images_subfolder else "root"

        return info

    def _get_extra_repr_lines(self, info: Dict[str, Any]) -> List[str]:
        """Add legacy-specific info to repr."""
        lines = []
        if info.get("per_camera"):
            lines.append("  Layout: per-camera")
        if info.get("images_location") and info["images_location"] != "root":
            lines.append(f"  Images: {info['images_location']}/")
        return lines

    def _get_metadata_for_range(self, start_frame: int, end_frame: int) -> Dict[str, Any]:
        """
        Get metadata for a specific frame range.

        Args:
            start_frame: Start frame number
            end_frame: End frame number

        Returns:
            Metadata dict with valid_ranges and frame_to_path filtered for the range
        """
        # Get full dataset ranges
        ranges = self.get_frame_ranges()

        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        # For legacy, we have a single range covering everything
        _, _, full_metadata = ranges[0]

        # Filter valid_ranges to only include those intersecting with requested range
        all_valid_ranges = full_metadata.get("valid_ranges", [])
        filtered_ranges = []

        for range_start, range_end in all_valid_ranges:
            # Check if this range intersects with [start_frame, end_frame]
            if range_end >= start_frame and range_start <= end_frame:
                # Clip to requested bounds
                clipped_start = max(range_start, start_frame)
                clipped_end = min(range_end, end_frame)
                filtered_ranges.append((clipped_start, clipped_end))

        if not filtered_ranges:
            raise ValueError(f"No valid frames in requested range [{start_frame}, {end_frame}]")

        # Use the same frame_to_path (it's a dict, so lookup is O(1))
        metadata = {"valid_ranges": filtered_ranges}
        if "frame_to_path" in full_metadata:
            metadata["frame_to_path"] = full_metadata.get("frame_to_path", {})
        return metadata

    def create_frame_reader(
        self,
        stream_ids: Optional[List[int]] = None,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        max_workers: Optional[int] = None,
    ) -> FrameReader:
        """
        Create legacy frame reader.

        Args:
            stream_ids: List of stream IDs to read, or None for all streams
            start_frame: Start frame number, or None for dataset start
            end_frame: End frame number, or None for dataset end
            max_workers: Number of parallel workers for decoding, or None to use dataset default

        Returns:
            LegacyFrameReader instance

        Raises:
            ValueError: If requested frames or streams are not available
        """
        # Ensure dataset structure is initialized
        if not self._initialized:
            self._initialize_structure()

        # Use all streams if not specified
        if stream_ids is None:
            stream_ids = list(self._stream_ids_cache or [])

        available_stream_ids = self._stream_ids_cache or []

        # Validate requested streams exist
        for stream_id in stream_ids:
            if stream_id not in available_stream_ids:
                raise ValueError(
                    f"Stream ID {stream_id} not found in dataset. "
                    f"Available IDs: {available_stream_ids}"
                )

        # Get available frame ranges
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        dataset_start, dataset_end, _ = ranges[0]

        # Determine actual frame range
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        # Validate frame range
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        # Get metadata for this specific range
        metadata = self._get_metadata_for_range(start_frame, end_frame)
        decoder_workers = max_workers if max_workers is not None else self.max_workers
        if self.per_camera:
            return PerCameraFrameReader(
                stream_ids,
                self._camera_frame_map,
                start_frame,
                end_frame,
                decoder_workers,
                metadata["valid_ranges"],
            )

        return LegacyFrameReader(
            self.dataset_path,
            stream_ids,
            start_frame,
            end_frame,
            decoder_workers,
            self._images_subfolder,
            metadata["valid_ranges"],
            metadata.get("frame_to_path", {}),
            stream_name_map=self._stream_to_raw_name,
        )

    def valid_file_hierarchy(self) -> List[str]:
        """
        Get all valid files in the dataset based on discovered structure.

        This uses the dataset's knowledge of its own structure to build
        the file list, ensuring only valid dataset files are included.

        Returns:
            Sorted list of relative file paths (strings)

        Raises:
            FileNotFoundError: If expected files are missing
        """
        # Ensure structure is initialized
        if not self._initialized:
            self._initialize_structure()

        valid_files = []

        if self.per_camera:
            # 1. Add camera directory image files
            for stream_id, frame_map in self._camera_frame_map.items():
                for img_path in frame_map.values():
                    if not img_path.exists():
                        raise FileNotFoundError(f"Expected image file not found: {img_path}")

                    rel_path = img_path.relative_to(self.dataset_path)
                    valid_files.append(str(rel_path))
        else:
            # 1. Add frame directory image files
            frame_dirs = self._discover_frame_directories()

            for frame_num, frame_dir in frame_dirs:
                # Get streams for this frame using the discovered structure
                stream_map = self._get_streams_from_directory(frame_dir)

                # Add each image file
                for stream_id, img_path in stream_map.items():
                    if not img_path.exists():
                        raise FileNotFoundError(f"Expected image file not found: {img_path}")

                    rel_path = img_path.relative_to(self.dataset_path)
                    valid_files.append(str(rel_path))

        # 2. Add stash frames if they exist
        stash_frames = self.get_stash_frames()
        for frame_num, stream_map in stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(f"Expected stash image file not found: {img_path}")

                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))

        # 3. Add extra stash frames if they exist
        extra_stash_frames = self.get_extra_stash_frames()
        for folder_name, stream_map in extra_stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(
                        f"Expected extra stash image file not found: {img_path}"
                    )

                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))

        # 4. Add meta folder contents (filtered)
        meta_files = self._get_meta_files()
        valid_files.extend(meta_files)

        # Sort and return
        return sorted(valid_files)

    def _get_image_resolution(self, image_path: Path) -> Tuple[int, int]:
        """
        Get image resolution without loading the entire image.

        Args:
            image_path: Path to image file

        Returns:
            Tuple of (width, height)
        """
        with Image.open(image_path) as img:
            return img.size  # Returns (width, height)

    def _validate_per_camera(self, verbose: bool = True) -> Dict[str, Any]:
        errors = []
        warnings = []
        stats = {
            "total_frames": 0,
            "total_streams": 0,
            "stream_ids": set(),
            "images_location": None,
            "frame_counts": {},
            "common_frames": 0,
            "stash_validation": {"has_stash": False, "stash_frames": 0, "issues": []},
        }

        if verbose:
            print("Validating per-camera legacy dataset...")

        try:
            if not self._initialized:
                self._initialize_structure()
        except Exception as e:
            errors.append(f"Failed to initialize dataset: {e}")
            return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

        stream_ids = self._stream_ids_cache or []
        stats["total_streams"] = len(stream_ids)
        stats["stream_ids"] = set(stream_ids)
        stats["images_location"] = self._images_subfolder if self._images_subfolder else "root"

        frame_counts = {}
        for stream_id in stream_ids:
            frame_counts[stream_id] = len(self._camera_frame_map.get(stream_id, {}))
        stats["frame_counts"] = frame_counts

        if not self._common_frame_numbers:
            errors.append("No common frames available across cameras")
        else:
            stats["common_frames"] = len(self._common_frame_numbers)
            stats["total_frames"] = len(self._common_frame_numbers)

        if frame_counts:
            min_count = min(frame_counts.values())
            max_count = max(frame_counts.values())
            if max_count != min_count:
                warnings.append(
                    "Frame count mismatch across cameras: "
                    f"min={min_count}, max={max_count}. Using {stats['common_frames']} common frames."
                )

        if verbose:
            print("Baseline from per-camera layout:")
            print(f"  - Images location: {stats['images_location']}")
            print(f"  - Streams: {sorted(stats['stream_ids'])}")
            if stats["common_frames"]:
                print(f"  - Common frames: {stats['common_frames']}")

        stash_frames = self.get_stash_frames()
        if stash_frames:
            stats["stash_validation"]["has_stash"] = True
            stats["stash_validation"]["stash_frames"] = len(stash_frames)

            if verbose:
                print("\nValidating stash frames...")

            if not self._common_frame_numbers:
                errors.append("Cannot validate stash frames without common frames")
            else:
                anchor_frame_num = self._common_frame_numbers[0]
                anchor_stream_ids = set(stream_ids)
                anchor_resolutions = {}
                for stream_id in anchor_stream_ids:
                    frame_map = self._camera_frame_map.get(stream_id, {})
                    anchor_path = frame_map.get(anchor_frame_num)
                    if anchor_path is None:
                        warnings.append(
                            f"Anchor frame {anchor_frame_num} missing for stream {stream_id}"
                        )
                        continue
                    try:
                        anchor_resolutions[stream_id] = self._get_image_resolution(anchor_path)
                    except Exception as e:
                        warnings.append(
                            f"Could not read resolution for anchor stream {stream_id}: {e}"
                        )

                for stash_frame_num, stash_stream_map in stash_frames:
                    stash_stream_ids = set(stash_stream_map.keys())
                    stash_issues = []

                    if len(stash_stream_ids) != len(anchor_stream_ids):
                        issue = (
                            f"Stash frame {stash_frame_num}: Expected {len(anchor_stream_ids)} "
                            f"streams, found {len(stash_stream_ids)}"
                        )
                        stash_issues.append(issue)
                        stats["stash_validation"]["issues"].append(issue)

                    if stash_stream_ids != anchor_stream_ids:
                        missing = anchor_stream_ids - stash_stream_ids
                        extra = stash_stream_ids - anchor_stream_ids
                        if missing:
                            issue = (
                                f"Stash frame {stash_frame_num}: Missing streams {sorted(missing)}"
                            )
                            stash_issues.append(issue)
                            stats["stash_validation"]["issues"].append(issue)
                        if extra:
                            issue = f"Stash frame {stash_frame_num}: Extra streams {sorted(extra)}"
                            stash_issues.append(issue)
                            stats["stash_validation"]["issues"].append(issue)

                    for stream_id in stash_stream_ids:
                        if stream_id in anchor_resolutions:
                            stash_img_path = stash_stream_map[stream_id]
                            try:
                                stash_res = self._get_image_resolution(stash_img_path)
                                anchor_res = anchor_resolutions[stream_id]
                                if stash_res != anchor_res:
                                    issue = (
                                        f"Stash frame {stash_frame_num}, stream {stream_id}: "
                                        f"Resolution {stash_res} != anchor resolution {anchor_res}"
                                    )
                                    stash_issues.append(issue)
                                    stats["stash_validation"]["issues"].append(issue)
                            except Exception as e:
                                warnings.append(
                                    f"Stash frame {stash_frame_num}, stream {stream_id}: "
                                    f"Could not read resolution: {e}"
                                )

                    if verbose and stash_issues:
                        print(f"\n  Stash frame {stash_frame_num} issues:")
                        for issue in stash_issues:
                            print(f"    - {issue}")

        if stats["stash_validation"]["issues"]:
            errors.append(
                f"Stash validation failed: {len(stats['stash_validation']['issues'])} issues found"
            )

        is_valid = len(errors) == 0

        if verbose:
            print(f"\n{'=' * 60}")
            print(f"Validation {'PASSED' if is_valid else 'FAILED'}")
            print(f"Total frames: {stats['total_frames']}")
            print(f"Total streams: {stats['total_streams']}")
            if stats["stash_validation"]["has_stash"]:
                print(f"Stash frames: {stats['stash_validation']['stash_frames']}")
                print(f"Stash issues: {len(stats['stash_validation']['issues'])}")
            if not is_valid:
                print("\nErrors:")
                for err in errors:
                    print(f"  - {err}")
            if warnings:
                print("\nWarnings:")
                for warn in warnings:
                    print(f"  - {warn}")

        return {"valid": is_valid, "errors": errors, "warnings": warnings, "stats": stats}

    def get_frame_source_paths(
        self, frame_idx: int, stream_ids: Optional[List[int]] = None
    ) -> Optional[Dict[int, Path]]:
        """
        Get source file paths for a frame.

        Legacy datasets store frames as individual image files, so we can
        return the paths directly for efficient copying.

        Args:
            frame_idx: Frame index to get paths for
            stream_ids: Optional list of stream IDs to include (None = all)

        Returns:
            Dict mapping stream_id -> Path to source image file
        """
        if not self._initialized:
            self._initialize_structure()

        if self.per_camera:
            result = {}
            target_streams = stream_ids if stream_ids else self._stream_ids_cache
            for stream_id in target_streams:
                frame_map = self._camera_frame_map.get(stream_id, {})
                if frame_idx in frame_map:
                    result[stream_id] = frame_map[frame_idx]
            return result if result else None

        # Frame-based layout
        frame_dirs = self._discover_frame_directories()
        frame_to_path = {fn: path for fn, path in frame_dirs}

        if frame_idx not in frame_to_path:
            return None

        frame_dir = frame_to_path[frame_idx]
        stream_map = self._get_streams_from_directory(frame_dir)

        if stream_ids:
            stream_map = {sid: path for sid, path in stream_map.items() if sid in stream_ids}

        return stream_map if stream_map else None

    def validate(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Validate dataset structure and consistency.

        Checks (frame-based):
        1. All frames have the same number of images
        2. All frames use the same subfolder structure (rgb/images/root)
        3. All frames have the same set of stream IDs
        4. Stash frames have same streams as anchor frame
        5. Stash streams have same resolution as anchor frame

        Checks (per-camera):
        1. All cameras use the same subfolder structure (rgb/images/root)
        2. Frames are aligned across cameras (common frame set)
        3. Stash frames match stream IDs and resolutions

        Returns:
            Dictionary with validation results:
            - 'valid': bool indicating if dataset is valid
            - 'errors': list of error messages
            - 'warnings': list of warning messages
            - 'stats': dict with dataset statistics
        """
        if self.per_camera:
            return self._validate_per_camera(verbose)

        errors = []
        warnings = []
        stats = {
            "total_frames": 0,
            "expected_streams": None,
            "stream_ids": set(),
            "images_location": None,
            "inconsistent_frames": [],
            "stash_validation": {"has_stash": False, "stash_frames": 0, "issues": []},
        }

        try:
            frame_dirs = self._discover_frame_directories()
            stats["total_frames"] = len(frame_dirs)

            if not frame_dirs:
                errors.append("No frame directories found")
                return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

            # Check first frame to establish baseline
            first_frame_num, first_frame_dir = frame_dirs[0]
            first_subfolder = self._find_images_subfolder(first_frame_dir)
            first_streams = self._get_streams_from_directory(first_frame_dir)

            stats["images_location"] = first_subfolder if first_subfolder else "root"
            stats["expected_streams"] = len(first_streams)
            stats["stream_ids"] = set(first_streams.keys())

            if verbose:
                print(f"Baseline from frame {first_frame_num}:")
                print(f"  - Images location: {stats['images_location']}")
                print(f"  - Number of streams: {stats['expected_streams']}")
                print(f"  - Stream IDs: {sorted(stats['stream_ids'])}")

            # Validate all other frames
            for frame_num, frame_dir in frame_dirs[1:]:
                frame_errors = []

                # Check subfolder structure consistency
                subfolder = self._find_images_subfolder(frame_dir)
                if subfolder != first_subfolder:
                    frame_errors.append(
                        f"Inconsistent structure: expected '{first_subfolder}', found '{subfolder}'"
                    )

                # Check streams
                streams = self._get_streams_from_directory(frame_dir)

                # Check stream count
                if len(streams) != stats["expected_streams"]:
                    frame_errors.append(
                        f"Expected {stats['expected_streams']} streams, found {len(streams)}"
                    )

                # Check stream IDs match
                stream_ids = set(streams.keys())
                if stream_ids != stats["stream_ids"]:
                    missing = stats["stream_ids"] - stream_ids
                    extra = stream_ids - stats["stream_ids"]
                    if missing:
                        frame_errors.append(f"Missing stream IDs: {sorted(missing)}")
                    if extra:
                        frame_errors.append(f"Extra stream IDs: {sorted(extra)}")

                if frame_errors:
                    stats["inconsistent_frames"].append((frame_num, frame_errors))
                    if verbose:
                        print(f"\nFrame {frame_num} issues:")
                        for err in frame_errors:
                            print(f"  - {err}")

            # Compile errors
            if stats["inconsistent_frames"]:
                errors.append(f"{len(stats['inconsistent_frames'])} frames have inconsistencies")

            # Validate stash if it exists
            stash_frames = self.get_stash_frames()
            if stash_frames:
                stats["stash_validation"]["has_stash"] = True
                stats["stash_validation"]["stash_frames"] = len(stash_frames)

                if verbose:
                    print(f"\nValidating stash frames...")

                # Get anchor frame info (first frame streams and resolutions)
                anchor_frame_num, anchor_frame_dir = frame_dirs[0]
                anchor_streams = self._get_streams_from_directory(anchor_frame_dir)
                anchor_stream_ids = set(anchor_streams.keys())

                # Get resolutions of anchor streams
                anchor_resolutions = {}
                for stream_id, img_path in anchor_streams.items():
                    try:
                        anchor_resolutions[stream_id] = self._get_image_resolution(img_path)
                    except Exception as e:
                        warnings.append(
                            f"Could not read resolution for anchor stream {stream_id}: {e}"
                        )

                # Validate each stash frame
                for stash_frame_num, stash_stream_map in stash_frames:
                    stash_stream_ids = set(stash_stream_map.keys())
                    stash_issues = []

                    # Check 1: Same number of streams
                    if len(stash_stream_ids) != len(anchor_stream_ids):
                        issue = (
                            f"Stash frame {stash_frame_num}: Expected {len(anchor_stream_ids)} "
                            f"streams, found {len(stash_stream_ids)}"
                        )
                        stash_issues.append(issue)
                        stats["stash_validation"]["issues"].append(issue)

                    # Check 2: Same stream IDs
                    if stash_stream_ids != anchor_stream_ids:
                        missing = anchor_stream_ids - stash_stream_ids
                        extra = stash_stream_ids - anchor_stream_ids
                        if missing:
                            issue = (
                                f"Stash frame {stash_frame_num}: Missing streams {sorted(missing)}"
                            )
                            stash_issues.append(issue)
                            stats["stash_validation"]["issues"].append(issue)
                        if extra:
                            issue = f"Stash frame {stash_frame_num}: Extra streams {sorted(extra)}"
                            stash_issues.append(issue)
                            stats["stash_validation"]["issues"].append(issue)

                    # Check 3: Same resolutions
                    for stream_id in stash_stream_ids:
                        if stream_id in anchor_resolutions:
                            stash_img_path = stash_stream_map[stream_id]
                            try:
                                stash_res = self._get_image_resolution(stash_img_path)
                                anchor_res = anchor_resolutions[stream_id]

                                if stash_res != anchor_res:
                                    issue = (
                                        f"Stash frame {stash_frame_num}, stream {stream_id}: "
                                        f"Resolution {stash_res} != anchor resolution {anchor_res}"
                                    )
                                    stash_issues.append(issue)
                                    stats["stash_validation"]["issues"].append(issue)
                            except Exception as e:
                                warning = (
                                    f"Stash frame {stash_frame_num}, stream {stream_id}: "
                                    f"Could not read resolution: {e}"
                                )
                                warnings.append(warning)

                    if verbose and stash_issues:
                        print(f"\n  Stash frame {stash_frame_num} issues:")
                        for issue in stash_issues:
                            print(f"    - {issue}")

                # Add errors if stash has issues
                if stats["stash_validation"]["issues"]:
                    errors.append(
                        f"Stash validation failed: {len(stats['stash_validation']['issues'])} issues found"
                    )

            # Generate summary
            is_valid = len(errors) == 0

            if verbose:
                print(f"\n{'=' * 60}")
                print(f"Validation {'PASSED' if is_valid else 'FAILED'}")
                print(f"Total frames: {stats['total_frames']}")
                print(f"Inconsistent frames: {len(stats['inconsistent_frames'])}")
                if stats["stash_validation"]["has_stash"]:
                    print(f"Stash frames: {stats['stash_validation']['stash_frames']}")
                    print(f"Stash issues: {len(stats['stash_validation']['issues'])}")
                if not is_valid:
                    print(f"\nErrors:")
                    for err in errors:
                        print(f"  - {err}")
                if warnings:
                    print(f"\nWarnings:")
                    for warn in warnings:
                        print(f"  - {warn}")

            return {"valid": is_valid, "errors": errors, "warnings": warnings, "stats": stats}

        except Exception as e:
            errors.append(f"Validation failed with exception: {str(e)}")
            return {"valid": False, "errors": errors, "warnings": warnings, "stats": stats}

    def generate_stash_frames(
        self,
        num_frames: int,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        delete_existing_stash: bool = False,
        overwrite_existing: bool = False,
        verbose: bool = True,
    ) -> List[int]:
        """
        Generate stash frames by copying existing frames from the legacy dataset.

        Args:
            num_frames: Number of stash frames to generate
            start_frame: Start frame for selection range (None = dataset start)
            end_frame: End frame for selection range (None = dataset end)
            delete_existing_stash: If True, delete existing numbered stash frames
            overwrite_existing: If True, overwrite existing stash frames with same numbers
            verbose: If True, print progress information

        Returns:
            List of frame numbers that were converted to stash frames
        """
        if self.per_camera:
            return self._generate_stash_frames_for_cameras(
                num_frames,
                start_frame=start_frame,
                end_frame=end_frame,
                delete_existing_stash=delete_existing_stash,
                overwrite_existing=overwrite_existing,
                verbose=verbose,
            )

        if num_frames <= 0:
            raise ValueError(f"num_frames must be positive, got {num_frames}")

        # Ensure structure is initialized
        if not self._initialized:
            self._initialize_structure()

        # Get available frame ranges
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        dataset_start, dataset_end, _ = ranges[0]

        # Determine actual frame range
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        # Validate frame range
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        # Get available frame directories
        frame_dirs = self._discover_frame_directories()
        frame_numbers = [fn for fn, _ in frame_dirs]

        # Filter to requested range
        available_frames = [fn for fn in frame_numbers if start_frame <= fn <= end_frame]

        if not available_frames:
            raise ValueError(f"No frames available in requested range [{start_frame}, {end_frame}]")

        if num_frames > len(available_frames):
            raise ValueError(
                f"Requested {num_frames} stash frames, but only {len(available_frames)} "
                f"frames available in range [{start_frame}, {end_frame}]"
            )

        # Select evenly spaced frames
        if num_frames == len(available_frames):
            selected_frames = available_frames
        else:
            indices = np.linspace(0, len(available_frames) - 1, num_frames, dtype=int)
            selected_frames = [available_frames[i] for i in indices]

        if verbose:
            print(f"Generating {num_frames} stash frames from legacy dataset...")
            print(f"Selected frames: {selected_frames}")

        # Handle delete existing stash
        stash_dir = self.dataset_path / "stash"
        if delete_existing_stash:
            if verbose:
                print("Deleting existing numbered stash frames...")

            if stash_dir.exists():
                # Only delete numbered frame directories
                for item in stash_dir.iterdir():
                    if item.is_dir():
                        frame_num = self._extract_first_digit_sequence(item.name)
                        if frame_num is not None:
                            if verbose:
                                print(f"  Deleting stash/{item.name}")
                            shutil.rmtree(item)

            # Clear cache
            self._stash_frames_cache = None

        # Create stash directory if it doesn't exist
        stash_dir.mkdir(exist_ok=True)

        # Check for collisions if not overwriting
        if not overwrite_existing and not delete_existing_stash:
            existing_stash = self.get_stash_frames()
            existing_frame_nums = {fn for fn, _ in existing_stash}

            collisions = [fn for fn in selected_frames if fn in existing_frame_nums]
            if collisions:
                raise ValueError(
                    f"Stash frames already exist for frames {collisions}. "
                    f"Use overwrite_existing=True or delete_existing_stash=True to overwrite."
                )

        # Copy frames to stash
        frame_to_dir = {fn: path for fn, path in frame_dirs}

        for frame_num in selected_frames:
            if verbose:
                print(f"Copying frame {frame_num} to stash...")

            source_dir = frame_to_dir[frame_num]
            dest_dir = stash_dir / f"{frame_num:08d}"

            # If overwriting, delete existing first
            if dest_dir.exists():
                if overwrite_existing:
                    shutil.rmtree(dest_dir)
                else:
                    raise ValueError(
                        f"Stash frame {frame_num} already exists. "
                        f"Use overwrite_existing=True to overwrite."
                    )

            # Copy the entire directory structure
            shutil.copytree(source_dir, dest_dir)

        if verbose:
            print(f"Successfully generated {num_frames} stash frames")

        # Clear cache
        self._stash_frames_cache = None

        return selected_frames

    def _generate_stash_frames_for_cameras(
        self,
        num_frames: int,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        delete_existing_stash: bool = False,
        overwrite_existing: bool = False,
        verbose: bool = True,
    ) -> List[int]:
        if num_frames <= 0:
            raise ValueError(f"num_frames must be positive, got {num_frames}")

        if not self._initialized:
            self._initialize_structure()

        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        dataset_start, dataset_end, _ = ranges[0]

        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        if not self._common_frame_numbers:
            raise ValueError("No common frames available across cameras")

        available_frames = [
            frame_num
            for frame_num in self._common_frame_numbers
            if start_frame <= frame_num <= end_frame
        ]

        if not available_frames:
            raise ValueError(f"No frames available in requested range [{start_frame}, {end_frame}]")

        if num_frames > len(available_frames):
            raise ValueError(
                f"Requested {num_frames} stash frames, but only {len(available_frames)} "
                f"frames available in range [{start_frame}, {end_frame}]"
            )

        if num_frames == len(available_frames):
            selected_frames = available_frames
        else:
            indices = np.linspace(0, len(available_frames) - 1, num_frames, dtype=int)
            selected_frames = [available_frames[i] for i in indices]

        if verbose:
            print("Generating stash frames from per-camera legacy dataset...")
            print(f"Selected frames: {selected_frames}")

        stash_dir = self.dataset_path / "stash"
        if delete_existing_stash:
            if verbose:
                print("Deleting existing numbered stash frames...")

            if stash_dir.exists():
                for item in stash_dir.iterdir():
                    if item.is_dir():
                        frame_num = self._extract_first_digit_sequence(item.name)
                        if frame_num is not None:
                            if verbose:
                                print(f"  Deleting stash/{item.name}")
                            shutil.rmtree(item)

            self._stash_frames_cache = None

        stash_dir.mkdir(exist_ok=True)

        if not overwrite_existing and not delete_existing_stash:
            existing_stash = self.get_stash_frames()
            existing_frame_nums = {fn for fn, _ in existing_stash}

            collisions = [fn for fn in selected_frames if fn in existing_frame_nums]
            if collisions:
                raise ValueError(
                    f"Stash frames already exist for frames {collisions}. "
                    "Use overwrite_existing=True or delete_existing_stash=True to overwrite."
                )

        for frame_num in selected_frames:
            if verbose:
                print(f"Copying frame {frame_num} to stash...")

            dest_dir = stash_dir / f"{frame_num:08d}"

            if dest_dir.exists():
                if overwrite_existing:
                    shutil.rmtree(dest_dir)
                else:
                    raise ValueError(
                        f"Stash frame {frame_num} already exists. "
                        "Use overwrite_existing=True to overwrite."
                    )

            images_dir = dest_dir / "rgb"
            images_dir.mkdir(parents=True, exist_ok=True)

            for stream_id in self.stream_ids:
                frame_map = self._camera_frame_map.get(stream_id, {})
                source_path = frame_map.get(frame_num)
                if source_path is None:
                    raise FileNotFoundError(
                        f"Frame {frame_num} not found for stream {stream_id} in per-camera dataset"
                    )

                source_ext = source_path.suffix.lower()
                output_ext = ".tiff" if source_ext == ".tif" else source_ext
                output_name = f"{stream_id:03d}{output_ext}"
                output_path = images_dir / output_name

                shutil.copy2(source_path, output_path)

        if verbose:
            print(f"Successfully generated {num_frames} stash frames")

        self._stash_frames_cache = None
        return selected_frames


class PerCameraFrameReader(FrameReader):
    """Frame reader for per-camera legacy datasets."""

    SUPPORTED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".tiff", ".tif", ".avif"]

    def __init__(
        self,
        stream_ids: List[int],
        camera_frame_map: Dict[int, Dict[int, Path]],
        start_frame: int,
        end_frame: int,
        decoder_max_workers: int = 4,
        valid_ranges: Optional[List[Tuple[int, int]]] = None,
    ):
        super().__init__(start_frame, end_frame)

        self.stream_ids = stream_ids
        self.camera_frame_map = {stream_id: camera_frame_map[stream_id] for stream_id in stream_ids}
        self.decoder_max_workers = decoder_max_workers
        self.valid_ranges = valid_ranges if valid_ranges is not None else []
        self._executor = None
        self._executor_max_workers = max(1, min(self.decoder_max_workers, len(self.stream_ids)))
        self._use_threadpool = self._executor_max_workers > 1

    def _ensure_executor(self) -> Optional[ThreadPoolExecutor]:
        if not self._use_threadpool:
            return None
        if self._executor is None:
            self._executor = ThreadPoolExecutor(max_workers=self._executor_max_workers)
        return self._executor

    def _is_frame_valid(self, frame_index: int) -> bool:
        if not self.valid_ranges:
            return True

        for start, end in self.valid_ranges:
            if start <= frame_index <= end:
                return True
        return False

    def _get_next_valid_frame(self, current: int) -> Optional[int]:
        if not self.valid_ranges:
            next_frame = current + 1
            return next_frame if next_frame <= self.end_frame else None

        for start, end in self.valid_ranges:
            if end <= current:
                continue

            if start <= current <= end:
                next_frame = current + 1
                if next_frame <= end and next_frame <= self.end_frame:
                    return next_frame
                continue

            if start <= self.end_frame:
                return start
            break

        return None

    def _load_image(self, image_path: Path, stream_id: int) -> Tuple[int, np.ndarray]:
        with Image.open(image_path) as img:
            if img.mode != "RGB":
                img = img.convert("RGB")
            array = np.array(img, dtype=np.uint8)

        return stream_id, array

    def next_frame(
        self, *, device: Device = "cpu", cuda_stream: Optional[int] = None
    ) -> Tuple[int, Dict[int, Any]]:
        next_valid = self._get_next_valid_frame(self.current_frame - 1)

        if next_valid is None or next_valid > self.end_frame:
            raise StopIteration("No more frames")

        self.current_frame = next_valid
        result = self.read_frame(self.current_frame, device=device, cuda_stream=cuda_stream)
        self.last_returned_index = self.current_frame - self.start_frame
        self.current_frame += 1
        return result

    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range {self.start_frame}-{self.end_frame}"
            )

        if not self._is_frame_valid(frame_index):
            raise FileNotFoundError(
                f"Frame {frame_index} does not exist in dataset (gap in frame sequence)"
            )

        paths = {}
        for stream_id in self.stream_ids:
            frame_map = self.camera_frame_map.get(stream_id, {})
            image_path = frame_map.get(frame_index)
            if image_path is None:
                raise FileNotFoundError(
                    f"Frame {frame_index} not found for stream {stream_id} in per-camera dataset"
                )
            paths[stream_id] = image_path

        result: Dict[int, Any] = {}
        if self._use_threadpool:
            executor = self._ensure_executor()
            futures = {
                executor.submit(self._load_image, image_path, stream_id): stream_id
                for stream_id, image_path in paths.items()
            }
            for future, stream_id in futures.items():
                try:
                    loaded_stream_id, array = future.result()
                    result[loaded_stream_id] = array
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to load stream {stream_id} at frame {frame_index}"
                    ) from e
        else:
            for stream_id, image_path in paths.items():
                try:
                    loaded_stream_id, array = self._load_image(image_path, stream_id)
                    result[loaded_stream_id] = array
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to load stream {stream_id} at frame {frame_index}"
                    ) from e

        if device == "cuda":
            from . import nvenc_codec

            result = {
                sid: nvenc_codec.numpy_to_cupy_rgb(arr, cuda_stream=cuda_stream)
                for sid, arr in result.items()
            }
        return frame_index, result

    def prepare_next_frame(self):
        pass

    @property
    def supports_random_access(self) -> bool:
        return True

    def close(self) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=True)
            self._executor = None


class IncompleteFrameError(Exception):
    """Raised when a frame is missing required streams."""
    pass


class LegacyFrameReader(FrameReader):
    """Frame reader for legacy dataset format."""

    SUPPORTED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".tiff", ".tif", ".avif"]

    def __init__(
        self,
        dataset_path: Path,
        stream_ids: List[int],
        start_frame: int,
        end_frame: int,
        decoder_max_workers: int = None,
        images_subfolder: Optional[str] = None,
        valid_ranges: Optional[List[Tuple[int, int]]] = None,
        frame_to_path: Optional[Dict[int, Path]] = None,
        stream_name_map: Optional[Dict[int, str]] = None,
    ):
        super().__init__(start_frame, end_frame)

        self.dataset_path = dataset_path
        self.stream_ids = stream_ids  # List of stream IDs to read
        self.decoder_max_workers = decoder_max_workers if decoder_max_workers is not None else os.cpu_count() or 1
        self.images_subfolder = images_subfolder  # 'rgb', 'images', or None (root)
        self.valid_ranges = valid_ranges if valid_ranges is not None else []
        self.frame_to_path = frame_to_path if frame_to_path is not None else {}
        self._stream_name_map = stream_name_map if stream_name_map is not None else {}
        self._executor = None
        self._executor_max_workers = max(1, min(self.decoder_max_workers, len(self.stream_ids)))
        self._use_threadpool = self._executor_max_workers > 1
        self._skipped_frames: List[int] = []

    def _ensure_executor(self) -> Optional[ThreadPoolExecutor]:
        if not self._use_threadpool:
            return None
        if self._executor is None:
            self._executor = ThreadPoolExecutor(max_workers=self._executor_max_workers)
        return self._executor

    def _extract_first_digit_sequence(self, name: str) -> Optional[int]:
        """Extract first sequence of digits from a string."""
        match = re.search(r"\d+", name)
        if match:
            return int(match.group())
        return None

    def _is_frame_valid(self, frame_index: int) -> bool:
        """
        Check if a frame index is within valid ranges.

        Args:
            frame_index: Frame index to check

        Returns:
            True if frame exists, False otherwise
        """
        if not self.valid_ranges:
            # No range information, assume all frames in [start, end] exist
            return True

        # Check if frame is in any of the valid ranges
        for start, end in self.valid_ranges:
            if start <= frame_index <= end:
                return True
        return False

    def _find_frame_directory(self, frame_index: int) -> Path:
        """Find the directory for a given frame index."""
        # First check if we have it in our mapping (handles gaps efficiently)
        if frame_index in self.frame_to_path:
            return self.frame_to_path[frame_index]

        # Fallback: try exact 8-digit padding
        frame_dir = self.dataset_path / f"{frame_index:08d}"
        if frame_dir.exists():
            return frame_dir

        # Otherwise search for any directory with this frame number
        for item in self.dataset_path.iterdir():
            if item.is_dir():
                extracted_num = self._extract_first_digit_sequence(item.name)
                if extracted_num == frame_index:
                    return item

        raise FileNotFoundError(f"Frame directory for frame {frame_index} not found")

    def _get_images_directory(self, frame_dir: Path) -> Path:
        """Get the directory containing images for a frame."""
        if self.images_subfolder:
            return frame_dir / self.images_subfolder
        else:
            return frame_dir

    def _scan_images_dir(self, images_dir: Path) -> Dict[int, Path]:
        """Scan directory once and build stream_id -> image path map."""
        stream_map = {}
        for item in images_dir.iterdir():
            if item.is_file() and item.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                file_stream_id = self._extract_first_digit_sequence(item.stem)
                if file_stream_id is not None:
                    stream_map[file_stream_id] = item
        return stream_map

    def _get_stream_paths_for_frame(self, images_dir: Path) -> Dict[int, Path]:
        if not self._stream_name_map:
            return self._scan_images_dir(images_dir)

        stream_map = {}
        missing = []
        for stream_id in self.stream_ids:
            raw_name = self._stream_name_map.get(stream_id)
            if raw_name:
                candidate = images_dir / raw_name
                if candidate.exists():
                    stream_map[stream_id] = candidate
                else:
                    missing.append(stream_id)
            else:
                missing.append(stream_id)

        if not missing:
            return stream_map

        scanned = self._scan_images_dir(images_dir)
        for stream_id in missing:
            path = scanned.get(stream_id)
            if path is not None:
                stream_map[stream_id] = path
        return stream_map

    def _load_image(self, image_path: Path, stream_id: int) -> Tuple[int, np.ndarray]:
        """Load a single image file for a given stream."""
        # Load image
        with Image.open(image_path) as img:
            if img.mode != "RGB":
                img = img.convert("RGB")

            # Convert to numpy array (HWC format, uint8)
            array = np.array(img, dtype=np.uint8)

        return stream_id, array

    def _get_next_valid_frame(self, current: int) -> Optional[int]:
        """
        Get the next valid frame number after current.

        Args:
            current: Current frame number

        Returns:
            Next valid frame number, or None if no more frames
        """
        if not self.valid_ranges:
            # No range information, assume continuous
            next_frame = current + 1
            return next_frame if next_frame <= self.end_frame else None

        # Find next valid frame using ranges
        for start, end in self.valid_ranges:
            if end <= current:
                # This range is before current, skip
                continue

            if start <= current <= end:
                # Current is in this range, next is current + 1
                next_frame = current + 1
                if next_frame <= end and next_frame <= self.end_frame:
                    return next_frame
                # Current is at end of range, continue to next range
                continue

            # start > current, this is the next range
            if start <= self.end_frame:
                return start
            break

        return None

    def next_frame(
        self, *, device: Device = "cpu", cuda_stream: Optional[int] = None
    ) -> Tuple[int, Dict[int, Any]]:
        """Read the next frame in sequence, skipping gaps and incomplete frames."""
        while True:
            next_valid = self._get_next_valid_frame(self.current_frame - 1)
            if next_valid is None or next_valid > self.end_frame:
                raise StopIteration("No more frames")

            self.current_frame = next_valid
            try:
                result = self.read_frame(
                    self.current_frame, device=device, cuda_stream=cuda_stream
                )
                self.last_returned_index = self.current_frame - self.start_frame
                self.current_frame += 1
                return result
            except IncompleteFrameError as e:
                import warnings

                warnings.warn(str(e), UserWarning)
                self._skipped_frames.append(self.current_frame)
                self.current_frame += 1
                continue

    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        """Read a specific frame from individual image files."""
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range {self.start_frame}-{self.end_frame}"
            )

        if not self._is_frame_valid(frame_index):
            raise FileNotFoundError(
                f"Frame {frame_index} does not exist in dataset (gap in frame sequence)"
            )

        frame_dir = self._find_frame_directory(frame_index)
        images_dir = self._get_images_directory(frame_dir)
        stream_paths = self._get_stream_paths_for_frame(images_dir)

        missing = [sid for sid in self.stream_ids if sid not in stream_paths]
        if missing:
            raise IncompleteFrameError(
                f"Skipping frame {frame_index}: missing streams {missing} in {images_dir}"
            )

        result: Dict[int, Any] = {}
        if self._use_threadpool:
            executor = self._ensure_executor()
            futures = {
                executor.submit(self._load_image, stream_paths[sid], sid): sid
                for sid in self.stream_ids
            }
            for future, stream_id in futures.items():
                try:
                    loaded_stream_id, array = future.result()
                    result[loaded_stream_id] = array
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to load stream {stream_id} at frame {frame_index}"
                    ) from e
        else:
            for stream_id in self.stream_ids:
                try:
                    loaded_stream_id, array = self._load_image(stream_paths[stream_id], stream_id)
                    result[loaded_stream_id] = array
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to load stream {stream_id} at frame {frame_index}"
                    ) from e

        if device == "cuda":
            from . import nvenc_codec

            result = {
                sid: nvenc_codec.numpy_to_cupy_rgb(arr, cuda_stream=cuda_stream)
                for sid, arr in result.items()
            }
        return frame_index, result

    def prepare_next_frame(self):
        """No preparation needed for legacy format."""
        # Legacy format doesn't support pre-loading
        pass

    @property
    def supports_random_access(self) -> bool:
        """Legacy reader supports random access."""
        return True

    @property
    def skipped_frames(self) -> List[int]:
        """Get list of frame numbers that were skipped due to missing streams."""
        return self._skipped_frames.copy()

    def close(self) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=True)
            self._executor = None
