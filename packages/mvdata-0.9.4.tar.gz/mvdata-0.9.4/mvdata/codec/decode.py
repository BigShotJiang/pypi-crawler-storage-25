"""NVDEC / PyAV decode paths for MP4 files."""

from __future__ import annotations

from pathlib import Path
from typing import Any, List

import numpy as np

from ..gpu_policy import nvdec_decode_allowed
from ._imports import try_import_av, try_import_cupy, try_import_pynvvideocodec, try_import_torch
from .frames import _decoded_frame_to_rgb_numpy, _pyav_frame_to_rgb
from .native_yuv import native_nvdec_to_rgb_numpy
from .nvdec import (
    _close_nvdec_decoder,
    _NvdecOrdinalRawFrameSource,
    _NvdecPtsRawFrameSource,
    _nvdec_scanned_presentation_pts,
    _try_open_nvdec,
)
from .probe import (
    infer_video_bit_depth_from_stream,
    nvdec_decode_compatibility_issue_for_path,
    probe_video_color_metadata_pyav,
    probe_video_bit_depth,
    probe_video_stream_metadata,
)


def _nvdec_raw_to_rgb_numpy(
    raw,
    *,
    source_bit_depth: int,
    color_metadata: dict[str, Any],
    torch_mod: Any,
) -> np.ndarray:
    if source_bit_depth > 8:
        return native_nvdec_to_rgb_numpy(
            raw,
            bit_depth=source_bit_depth,
            **color_metadata,
        )
    return _decoded_frame_to_rgb_numpy(raw, torch_mod, bit_depth=source_bit_depth)


def _decode_simple_nvdec_by_ordinal(
    decoder: Any,
    path: Path,
    expect_count: int,
    *,
    source_bit_depth: int,
    color_metadata: dict[str, Any],
    torch_mod: Any,
) -> list[np.ndarray]:
    raw_source = _NvdecOrdinalRawFrameSource(decoder, path)

    try:
        try:
            frame_count = min(len(decoder), expect_count)
        except Exception:
            frame_count = expect_count

        frames: list[np.ndarray] = []
        for index in range(frame_count):
            raw, _ = raw_source.frame_by_index(index)
            frames.append(
                _nvdec_raw_to_rgb_numpy(
                    raw,
                    source_bit_depth=source_bit_depth,
                    color_metadata=color_metadata,
                    torch_mod=torch_mod,
                )
            )
        return frames
    finally:
        raw_source.close()


def _decode_nvdec_by_presentation_pts(
    nvc: Any,
    mp4_path: Path,
    *,
    gpu_id: int,
    use_device_memory: bool,
    output_color_type: Any,
    presentation_pts: list[int],
    expect_count: int,
    source_bit_depth: int,
    color_metadata: dict[str, Any],
    torch_mod: Any,
) -> list[np.ndarray]:
    raw_source = _NvdecPtsRawFrameSource(
        nvc,
        mp4_path,
        gpu_id=gpu_id,
        use_device_memory=use_device_memory,
        output_color_type=output_color_type,
        presentation_pts=presentation_pts,
    )
    try:
        return [
            _nvdec_raw_to_rgb_numpy(
                raw_source.frame(index),
                source_bit_depth=source_bit_depth,
                color_metadata=color_metadata,
                torch_mod=torch_mod,
            )
            for index in range(expect_count)
        ]
    finally:
        raw_source.close()


def decode_mp4_to_rgb_pyav(mp4_path: Path, expect_count: int) -> List[np.ndarray]:
    av = try_import_av()
    if av is None:
        raise RuntimeError("PyAV is required for CPU decode.")
    out: List[np.ndarray] = []
    with av.open(str(mp4_path)) as container:
        stream = container.streams.video[0]
        bit_depth = infer_video_bit_depth_from_stream(stream)
        for frame in container.decode(stream):
            out.append(_pyav_frame_to_rgb(frame, bit_depth=bit_depth))
            if len(out) >= expect_count:
                break
    return out


def decode_mp4_to_rgb_nvdec(nvc, mp4_path: Path, gpu_id: int, expect_count: int) -> List[np.ndarray]:
    """Decode MP4 to RGB uint8/uint16 HWC frames via NVDEC SimpleDecoder."""
    if not nvdec_decode_allowed():
        raise RuntimeError(
            "NVDEC decode disabled by MVDATA_DISABLE_GPU / MVDATA_DISABLE_NVDEC_DECODE"
        )
    meta = probe_video_stream_metadata(nvc, mp4_path)
    bit_depth = int(meta.get("bitdepth", 8))
    issue = nvdec_decode_compatibility_issue_for_path(nvc, mp4_path, gpu_id)
    if issue is not None:
        raise RuntimeError(f"NVDEC decode unsupported for {mp4_path}: {issue}")
    source_bit_depth = probe_video_bit_depth(mp4_path, nvc=nvc)
    color_metadata = probe_video_color_metadata_pyav(mp4_path)

    torch_mod = try_import_torch()
    has_dlpack = torch_mod is not None or try_import_cupy() is not None
    path_str = str(mp4_path)
    output_color_type = nvc.OutputColorType.NATIVE if source_bit_depth > 8 else nvc.OutputColorType.RGB
    use_dev_options = [True] if source_bit_depth > 8 else ([True, False] if has_dlpack else [False])

    last_err: Exception | None = None
    for use_dev in use_dev_options:
        if source_bit_depth > 8:
            metadata_decoder = _try_open_nvdec(
                nvc,
                path_str,
                gpu_id,
                use_dev,
                output_color_type=output_color_type,
            )
        else:
            metadata_decoder = _try_open_nvdec(nvc, path_str, gpu_id, use_dev)
        if metadata_decoder is None:
            continue
        try:
            presentation_pts = _nvdec_scanned_presentation_pts(metadata_decoder, expect_count)
            if presentation_pts is None:
                return _decode_simple_nvdec_by_ordinal(
                    metadata_decoder,
                    mp4_path,
                    expect_count,
                    source_bit_depth=source_bit_depth,
                    color_metadata=color_metadata,
                    torch_mod=torch_mod,
                )

            _close_nvdec_decoder(metadata_decoder)
            if len(presentation_pts) < expect_count:
                raise RuntimeError(
                    f"NVDEC scanned metadata has {len(presentation_pts)} timestamps, "
                    f"expected at least {expect_count}"
                )
            return _decode_nvdec_by_presentation_pts(
                nvc,
                mp4_path,
                gpu_id=gpu_id,
                use_device_memory=use_dev,
                output_color_type=output_color_type,
                presentation_pts=presentation_pts,
                expect_count=expect_count,
                source_bit_depth=source_bit_depth,
                color_metadata=color_metadata,
                torch_mod=torch_mod,
            )
        except Exception as e:
            last_err = e

    raise RuntimeError(
        "NVDEC SimpleDecoder could not produce RGB numpy frames. "
        f"Install PyTorch or CuPy for DLPack, or decode with PyAV. Last error: {last_err}"
    )


def decode_mp4_to_rgb(
    mp4_path: Path,
    expect_count: int,
    *,
    decoder: str = "pyav",
    nvc: Any | None = None,
    gpu_id: int = 0,
) -> List[np.ndarray]:
    if decoder == "pyav":
        return decode_mp4_to_rgb_pyav(mp4_path, expect_count)
    if decoder == "nvidia":
        if nvc is None:
            nvc = try_import_pynvvideocodec()
        return decode_mp4_to_rgb_nvdec(nvc, mp4_path, gpu_id, expect_count)
    raise ValueError(f"Unknown decoder: {decoder}")


def preferred_decoder_for_mp4(nvc, mp4_path: Path, *, gpu_id: int = 0) -> tuple[str, str | None]:
    issue = nvdec_decode_compatibility_issue_for_path(nvc, mp4_path, gpu_id)
    if issue is None:
        return "nvidia", None
    if try_import_av() is not None:
        return "pyav", issue
    raise RuntimeError(
        f"NVDEC decode unsupported for {mp4_path}: {issue}. PyAV is not installed for CPU fallback."
    )
