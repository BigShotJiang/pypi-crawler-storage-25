"""NVENC / NVDEC / PyAV codec helpers for mvdata.

This subpackage is split into small modules:

- :mod:`mvdata.codec._imports` – lazy optional-dep imports and constants
- :mod:`mvdata.codec.probe`    – bit-depth probing and GPU capability checks
- :mod:`mvdata.codec.frames`   – decoded-frame → HWC RGB (numpy and cupy)
- :mod:`mvdata.codec.native_yuv` – native high-bit-depth NVDEC YUV → RGB
- :mod:`mvdata.codec.encode`   – RGB → NVENC elementary stream → MP4
- :mod:`mvdata.codec.decode`   – NVDEC / PyAV decode of MP4
- :mod:`mvdata.codec.select`   – round-trip PSNR and auto codec selection

The flat namespace here is preserved for backward compatibility with callers
that use ``from mvdata.codec import X`` or the top-level ``mvdata.nvenc_codec``
shim.
"""

from ._imports import (
    AUTO_NVENC_CHROMA_SUBSAMPLING,
    AUTO_NVENC_CODEC_CANDIDATES,
    AUTO_NVENC_MIN_PSNR_DB,
    AUTO_NVENC_PRESET,
    AUTO_NVENC_RANGE_MODE,
    _PYNVC_API_REF,
    normalize_codec_name,
    try_import_av,
    try_import_cupy,
    try_import_pynvvideocodec,
    try_import_torch,
)
from .decode import (
    decode_mp4_to_rgb,
    decode_mp4_to_rgb_nvdec,
    decode_mp4_to_rgb_pyav,
    preferred_decoder_for_mp4,
)
from .encode import (
    assert_yuv444_encode_supported,
    best_quality_extra_kwargs,
    create_nvenc_encoder,
    encode_rgb_frames_to_elementary_stream,
    encode_rgb_iter_to_elementary_stream,
    encode_rgb_iter_to_mp4,
    encode_rgb_sequence_to_mp4,
    ffmpeg_executable,
    mux_elementary_to_mp4,
    pad_rgb_for_nvenc,
    resolve_nvenc_bitrate_bps,
    rgb_hwc_to_nvenc_bgra_hwc4,
    rgb_hwc_to_yuv444_planar,
    suggest_nvenc_vbr_bitrate_bps,
)
from .frames import (
    _decoded_frame_to_rgb_cupy,
    _decoded_frame_to_rgb_numpy,
    _normalize_rgb_numpy_output,
    _pyav_frame_to_rgb,
    numpy_to_cupy_rgb,
)
from .native_yuv import native_nvdec_to_rgb_cupy, native_nvdec_to_rgb_numpy
from .nvdec import _try_open_nvdec
from .probe import (
    infer_video_bit_depth_from_frame,
    infer_video_bit_depth_from_pixel_format_name,
    infer_video_bit_depth_from_stream,
    infer_video_bit_depth_from_video_format,
    nvdec_decode_compatibility_issue,
    nvdec_decode_compatibility_issue_for_path,
    nvenc_encode_compatibility_issue,
    nvenc_encode_compatibility_issue_for_rgb,
    probe_video_color_metadata_pyav,
    probe_video_bit_depth,
    probe_video_bit_depth_pyav,
    probe_video_stream_metadata,
    pynvc_chroma_format,
    pynvc_codec_enum,
    safe_get_decoder_caps,
    safe_get_encoder_caps,
)
from .select import roundtrip_nvenc_stream_psnr, select_auto_nvenc_candidate_for_rgb

__all__ = [
    "AUTO_NVENC_CHROMA_SUBSAMPLING",
    "AUTO_NVENC_CODEC_CANDIDATES",
    "AUTO_NVENC_MIN_PSNR_DB",
    "AUTO_NVENC_PRESET",
    "AUTO_NVENC_RANGE_MODE",
    "assert_yuv444_encode_supported",
    "best_quality_extra_kwargs",
    "create_nvenc_encoder",
    "decode_mp4_to_rgb",
    "decode_mp4_to_rgb_nvdec",
    "decode_mp4_to_rgb_pyav",
    "encode_rgb_frames_to_elementary_stream",
    "encode_rgb_iter_to_elementary_stream",
    "encode_rgb_iter_to_mp4",
    "encode_rgb_sequence_to_mp4",
    "ffmpeg_executable",
    "infer_video_bit_depth_from_frame",
    "infer_video_bit_depth_from_pixel_format_name",
    "infer_video_bit_depth_from_stream",
    "infer_video_bit_depth_from_video_format",
    "mux_elementary_to_mp4",
    "normalize_codec_name",
    "native_nvdec_to_rgb_cupy",
    "native_nvdec_to_rgb_numpy",
    "numpy_to_cupy_rgb",
    "nvdec_decode_compatibility_issue",
    "nvdec_decode_compatibility_issue_for_path",
    "nvenc_encode_compatibility_issue",
    "nvenc_encode_compatibility_issue_for_rgb",
    "pad_rgb_for_nvenc",
    "preferred_decoder_for_mp4",
    "probe_video_color_metadata_pyav",
    "probe_video_bit_depth",
    "probe_video_bit_depth_pyav",
    "probe_video_stream_metadata",
    "pynvc_chroma_format",
    "pynvc_codec_enum",
    "resolve_nvenc_bitrate_bps",
    "rgb_hwc_to_nvenc_bgra_hwc4",
    "rgb_hwc_to_yuv444_planar",
    "roundtrip_nvenc_stream_psnr",
    "safe_get_decoder_caps",
    "safe_get_encoder_caps",
    "select_auto_nvenc_candidate_for_rgb",
    "suggest_nvenc_vbr_bitrate_bps",
    "try_import_av",
    "try_import_cupy",
    "try_import_pynvvideocodec",
    "try_import_torch",
]
