"""Shared NVDEC / PyNvVideoCodec helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def _try_open_nvdec(
    nvc,
    path_str: str,
    gpu_id: int,
    use_device_memory: bool,
    *,
    output_color_type=None,
):
    """Open a SimpleDecoder, tolerating API-version differences in the kwarg surface."""
    base = dict(
        gpu_id=gpu_id,
        use_device_memory=use_device_memory,
        output_color_type=output_color_type or nvc.OutputColorType.RGB,
    )
    for extra in ({"need_scanned_stream_metadata": True}, {}):
        try:
            return nvc.SimpleDecoder(path_str, **base, **extra)
        except TypeError:
            if extra:
                try:
                    return nvc.SimpleDecoder(path_str, **base)
                except Exception:
                    pass
        except Exception:
            pass
    return None


def _nvdec_frame_pts(frame: Any) -> int | None:
    get_pts = getattr(frame, "getPTS", None)
    if callable(get_pts):
        pts = get_pts()
        if pts is not None:
            return int(pts)
    pts = getattr(frame, "timestamp", None)
    if pts is not None:
        return int(pts)
    return None


def _nvdec_scanned_presentation_pts(decoder: Any, expect_count: int) -> list[int] | None:
    del expect_count
    get_scanned = getattr(decoder, "get_scanned_stream_metadata", None)
    if not callable(get_scanned):
        return None

    metadata = get_scanned()
    pts_values = getattr(metadata, "pts", None)
    if pts_values is None:
        return None

    pts = [int(value) for value in pts_values]
    if not pts:
        return None
    return pts


def _create_low_level_nvdec(
    nvc: Any,
    path: Path | str,
    *,
    gpu_id: int,
    use_device_memory: bool,
    output_color_type: Any,
) -> tuple[Any, Any]:
    demuxer = nvc.CreateDemuxer(str(path))
    decoder = nvc.CreateDecoder(
        gpuid=gpu_id,
        codec=demuxer.GetNvCodecId(),
        usedevicememory=use_device_memory,
        outputColorType=output_color_type,
        latency=nvc.DisplayDecodeLatencyType.NATIVE,
    )
    return demuxer, decoder


def _close_nvdec_decoder(decoder: Any) -> None:
    if decoder is None:
        return
    for close_name in ("close", "stop"):
        close_fn = getattr(decoder, close_name, None)
        if callable(close_fn):
            try:
                close_fn()
            except Exception:
                pass
            return


class _NvdecOrdinalRawFrameSource:
    def __init__(self, decoder: Any, path: Path | str):
        self._decoder = decoder
        self._path = path
        self._get_batch_frames = getattr(decoder, "get_batch_frames", None)
        self._get_batch_frames_by_index = getattr(decoder, "get_batch_frames_by_index", None)
        self._seek_to_index = getattr(decoder, "seek_to_index", None)
        if not callable(self._get_batch_frames_by_index) and not callable(self._get_batch_frames):
            self.close()
            raise RuntimeError(
                f"{path}: NVDEC SimpleDecoder has no scanned metadata or ordinal frame API"
            )
        self._next_sequential_index: int | None = (
            0 if callable(self._get_batch_frames) else None
        )

    def _decode_sequential(self, index: int):
        if not callable(self._get_batch_frames):
            raise RuntimeError("Sequential NVDEC batch API is unavailable")
        batch = self._get_batch_frames(1)
        if not batch:
            raise RuntimeError(f"NVDEC returned no frame for {self._path} at index {index}")
        self._next_sequential_index = index + 1
        return batch[0]

    def _decode_indexed(self, index: int):
        if callable(self._get_batch_frames_by_index):
            self._next_sequential_index = None
            batch = self._get_batch_frames_by_index([index])
            if not batch:
                raise RuntimeError(f"NVDEC returned no frame for {self._path} at index {index}")
            return batch[0]

        if not callable(self._seek_to_index) or not callable(self._get_batch_frames):
            raise RuntimeError("Indexed NVDEC access API is unavailable")
        self._seek_to_index(index)
        self._next_sequential_index = index
        return self._decode_sequential(index)

    def frame(self, index: int) -> tuple[Any, str]:
        if self._next_sequential_index == index:
            return self._decode_sequential(index), "sequential"
        return self._decode_indexed(index), "indexed"

    def frame_by_index(self, index: int) -> tuple[Any, str]:
        if callable(self._get_batch_frames_by_index) or callable(self._seek_to_index):
            return self._decode_indexed(index), "indexed"
        return self.frame(index)

    def reset(self) -> None:
        self._next_sequential_index = 0 if callable(self._get_batch_frames) else None

    def close(self) -> None:
        _close_nvdec_decoder(self._decoder)
        self._decoder = None


class _NvdecPtsRawFrameSource:
    def __init__(
        self,
        nvc: Any,
        path: Path | str,
        *,
        gpu_id: int,
        use_device_memory: bool,
        output_color_type: Any,
        presentation_pts: list[int],
    ):
        self._nvc = nvc
        self._path = path
        self._gpu_id = gpu_id
        self._use_device_memory = use_device_memory
        self._output_color_type = output_color_type
        self._presentation_pts = presentation_pts
        self._pts_to_index = {
            pts: index
            for index, pts in enumerate(self._presentation_pts)
        }
        if len(self._pts_to_index) != len(self._presentation_pts):
            raise RuntimeError(f"{path}: duplicate presentation timestamps in NVDEC metadata")
        self._demuxer = None
        self._decoder = None
        self._eos = False
        self._last_decoded_index: int | None = None
        self._pending_raw_by_index: dict[int, Any] = {}

    def reset(self) -> None:
        _close_nvdec_decoder(self._decoder)
        self._demuxer, self._decoder = _create_low_level_nvdec(
            self._nvc,
            self._path,
            gpu_id=self._gpu_id,
            use_device_memory=self._use_device_memory,
            output_color_type=self._output_color_type,
        )
        self._eos = False
        self._last_decoded_index = None
        self._pending_raw_by_index.clear()

    def _ensure_decoder(self) -> None:
        if self._decoder is None or self._demuxer is None:
            self.reset()

    def frame(self, index: int):
        pending = self._pending_raw_by_index.pop(index, None)
        if pending is not None:
            return pending

        if self._last_decoded_index is not None and index <= self._last_decoded_index:
            self.reset()
        else:
            self._ensure_decoder()

        assert self._decoder is not None
        assert self._demuxer is not None

        while not self._eos:
            packet = self._demuxer.Demux()
            outputs = self._decoder.Decode(packet)
            if getattr(packet, "bsl", 0) == 0:
                self._eos = True
            target_raw = None
            for raw in outputs:
                pts = _nvdec_frame_pts(raw)
                if pts is None:
                    raise RuntimeError(
                        f"{self._path}: NVDEC returned a frame without presentation timestamp"
                    )
                decoded_index = self._pts_to_index.get(pts)
                if decoded_index is None:
                    raise RuntimeError(
                        f"{self._path}: NVDEC returned unknown presentation timestamp {pts}"
                    )
                self._last_decoded_index = decoded_index
                if decoded_index > index:
                    if target_raw is None:
                        expected_pts = self._presentation_pts[index]
                        raise RuntimeError(
                            f"{self._path}: NVDEC skipped requested presentation frame "
                            f"{index} (pts={expected_pts}); first later frame was "
                            f"{decoded_index} (pts={pts}). The MP4 slice is missing "
                            "decode dependencies before the requested frame."
                        )
                    self._pending_raw_by_index[decoded_index] = raw
                if decoded_index == index:
                    target_raw = raw
            if target_raw is not None:
                return target_raw

        expected_pts = self._presentation_pts[index]
        raise RuntimeError(
            f"{self._path}: NVDEC reached end of stream before presentation frame "
            f"{index} (pts={expected_pts})"
        )

    def close(self) -> None:
        _close_nvdec_decoder(self._decoder)
        self._decoder = None
        self._demuxer = None
