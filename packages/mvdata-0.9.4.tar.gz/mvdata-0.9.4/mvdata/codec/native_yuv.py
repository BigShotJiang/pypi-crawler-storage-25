"""Native NVDEC YUV surface conversion helpers."""

from __future__ import annotations

from typing import Any

import numpy as np

from ._imports import try_import_cupy


class _CaiView:
    def __init__(self, view: Any, *, data_offset_bytes: int = 0):
        self._view = view
        self._data_offset_bytes = int(data_offset_bytes)

    @property
    def __cuda_array_interface__(self):
        cai = dict(self._view.__cuda_array_interface__)
        cai["shape"] = tuple(cai["shape"])

        typestr = str(cai.get("typestr", ""))
        itemsize = np.dtype(typestr).itemsize if typestr else 1
        # PyNvVideoCodec reports these strides in samples for native planes.
        cai["strides"] = tuple(int(stride) * itemsize for stride in cai["strides"])
        if self._data_offset_bytes:
            ptr, readonly = cai["data"]
            cai["data"] = (int(ptr) + self._data_offset_bytes, readonly)
        return cai


def _cupy_or_raise():
    cp = try_import_cupy()
    if cp is None:
        raise RuntimeError(
            "Native high-bit-depth NVDEC conversion requires CuPy. "
            "Install mvdata[cuda] or use the PyAV fallback."
        )
    return cp


def _format_name(frame: Any) -> str:
    return str(getattr(frame, "format", "")).split(".")[-1]


def _coefficients(color_space: Any) -> tuple[float, float]:
    text = str(color_space).lower()
    if "2020" in text or text == "9":
        return 0.2627, 0.0593
    if "709" in text or text == "1":
        return 0.2126, 0.0722
    return 0.299, 0.114


def _is_limited_range(color_range: Any) -> bool:
    text = str(color_range).lower()
    return "mpeg" in text or text == "1"


def _native_planes(frame: Any):
    return [_CaiView(view) for view in frame.cuda()]


def _native_yuv444_planes(frame: Any):
    views = frame.cuda()
    if len(views) != 3:
        raise ValueError(f"Expected 3 native YUV444 planes, got {len(views)}")
    cai = dict(views[0].__cuda_array_interface__)
    shape = tuple(cai["shape"])
    strides = tuple(cai["strides"])
    itemsize = np.dtype(cai.get("typestr", "|u2")).itemsize
    plane_bytes = int(shape[0]) * int(strides[0]) * itemsize
    return [_CaiView(views[0], data_offset_bytes=i * plane_bytes) for i in range(3)]


def _plane_to_source_float(cp, plane, *, bit_depth: int):
    shift = 16 - int(bit_depth)
    values = cp.asarray(plane)
    if shift > 0:
        values = cp.right_shift(values, shift)
    return values.astype(cp.float32, copy=False)


def _single_channel(values):
    return values[..., 0] if values.ndim == 3 and values.shape[-1] == 1 else values


def _yuv_to_rgb(cp, y, cb, cr, *, bit_depth: int, color_range: Any, color_space: Any):
    source_max = float((1 << int(bit_depth)) - 1)
    if _is_limited_range(color_range):
        scale = 1 << (int(bit_depth) - 8)
        y = (y - 16.0 * scale) * (source_max / (219.0 * scale))
        center = 128.0 * scale
        chroma_scale = ((source_max + 1.0) / 2.0) / (112.0 * scale)
        cb = (cb - center) * chroma_scale
        cr = (cr - center) * chroma_scale
    else:
        center = (source_max + 1.0) / 2.0
        cb = cb - center
        cr = cr - center

    kr, kb = _coefficients(color_space)
    kg = 1.0 - kr - kb
    r_cr = 2.0 * (1.0 - kr)
    b_cb = 2.0 * (1.0 - kb)
    g_cb = 2.0 * kb * (1.0 - kb) / kg
    g_cr = 2.0 * kr * (1.0 - kr) / kg

    r = y + r_cr * cr
    g = y - g_cb * cb - g_cr * cr
    b = y + b_cb * cb
    rgb = cp.stack([r, g, b], axis=-1)
    return cp.clip(rgb + 0.5, 0, source_max).astype(cp.uint16)


def native_nvdec_to_rgb_cupy(
    frame: Any,
    *,
    bit_depth: int,
    color_range: Any = None,
    color_space: Any = None,
    cuda_stream: int | None = None,
):
    """Convert a native high-bit-depth NVDEC frame to HWC RGB on the GPU."""
    if int(bit_depth) <= 8:
        raise ValueError("Native high-bit-depth conversion requires bit_depth > 8")

    cp = _cupy_or_raise()
    stream_ctx = (
        cp.cuda.ExternalStream(int(cuda_stream))
        if cuda_stream is not None and int(cuda_stream) != 0
        else None
    )

    def _convert():
        fmt = _format_name(frame)
        planes = _native_planes(frame)
        if fmt in {"P016", "P010"}:
            y_view, uv_view = planes
            y = _single_channel(_plane_to_source_float(cp, y_view, bit_depth=bit_depth))
            uv = _plane_to_source_float(cp, uv_view, bit_depth=bit_depth)
            cb = cp.repeat(cp.repeat(uv[..., 0], 2, axis=0), 2, axis=1)[: y.shape[0], : y.shape[1]]
            cr = cp.repeat(cp.repeat(uv[..., 1], 2, axis=0), 2, axis=1)[: y.shape[0], : y.shape[1]]
        elif fmt == "YUV444_16Bit":
            y_view, cb_view, cr_view = _native_yuv444_planes(frame)
            y = _single_channel(_plane_to_source_float(cp, y_view, bit_depth=bit_depth))
            cb = _single_channel(_plane_to_source_float(cp, cb_view, bit_depth=bit_depth))
            cr = _single_channel(_plane_to_source_float(cp, cr_view, bit_depth=bit_depth))
        else:
            raise ValueError(f"Unsupported native NVDEC format for high-bit RGB: {fmt}")

        return _yuv_to_rgb(
            cp,
            y,
            cb,
            cr,
            bit_depth=bit_depth,
            color_range=color_range,
            color_space=color_space,
        )

    if stream_ctx is None:
        return _convert()
    with stream_ctx:
        return _convert()


def native_nvdec_to_rgb_numpy(frame: Any, **kwargs) -> np.ndarray:
    return native_nvdec_to_rgb_cupy(frame, **kwargs).get()
