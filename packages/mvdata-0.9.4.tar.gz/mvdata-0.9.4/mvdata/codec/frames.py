"""Conversion helpers that turn decoded frames into canonical HWC RGB arrays.

The public surface here is deliberately small:

``_decoded_frame_to_rgb_numpy``
    Takes a decoder output (numpy, dlpack-capable, or torch/cupy tensor) and
    returns a contiguous HWC numpy array owned by the caller.
``_decoded_frame_to_rgb_cupy``
    Same, but returns a fresh ``cupy.ndarray`` that stays on the GPU. Uses
    DLPack to view decoder device memory, then copies into a new buffer so the
    decoder is free to reuse its pool slot. Accepts an optional raw CUDA stream
    pointer to order the copy with user work.
``numpy_to_cupy_rgb``
    H2D helper used for streams that can only be produced on the CPU (pyavif,
    PyAV CPU fallback).
``_pyav_frame_to_rgb``
    PyAV → HWC RGB with correct handling of full-range yuv444 and high bit
    depths.
"""

from __future__ import annotations

from contextlib import ExitStack
from typing import Any

import numpy as np

from ._imports import try_import_cupy, try_import_torch
from .probe import infer_video_bit_depth_from_frame


def _cupy_or_raise():
    cp = try_import_cupy()
    if cp is None:
        raise RuntimeError(
            "device='cuda' requires CuPy. Install it with `pip install mvdata[cuda]` "
            "(or `pip install cupy-cuda12x`)."
        )
    return cp


def _device_and_stream_ctx(
    cp, *, gpu_id: int | None = None, cuda_stream: int | None = None
):
    stack = ExitStack()
    if gpu_id is not None:
        stack.enter_context(cp.cuda.Device(int(gpu_id)))
    if cuda_stream is not None and int(cuda_stream) != 0:
        stack.enter_context(cp.cuda.ExternalStream(int(cuda_stream)))
    return stack


def _target_dtype_for(arr_dtype, *, bit_depth: int | None):
    if arr_dtype == np.uint8:
        if (bit_depth or 8) > 8:
            raise ValueError(
                f"High-bit-depth decode returned uint8 output for {bit_depth}-bit source"
            )
        return np.uint8
    if arr_dtype == np.uint16:
        return np.uint16
    if np.issubdtype(arr_dtype, np.integer):
        if (bit_depth or 8) > 8 or arr_dtype.itemsize > 1:
            return np.uint16
        return np.uint8
    raise TypeError(f"Cannot convert decoded frame to HWC RGB: dtype={arr_dtype}")


def _ensure_hwc(arr):
    """Transpose 3×H×W to H×W×3 when needed. Returns (arr, needs_copy)."""
    if arr.ndim == 3 and arr.shape[0] == 3 and arr.shape[-1] != 3:
        return arr.transpose(1, 2, 0), True
    if not (arr.ndim == 3 and arr.shape[-1] == 3):
        raise TypeError(f"Cannot convert decoded frame to HWC RGB: shape={arr.shape}")
    return arr, False


def _normalize_rgb_numpy_output(
    arr: np.ndarray, *, bit_depth: int | None = None, copy_result: bool = False
) -> np.ndarray:
    arr = np.asarray(arr)
    arr, transposed = _ensure_hwc(arr)
    copy_result = copy_result or transposed

    target = _target_dtype_for(arr.dtype, bit_depth=bit_depth)
    if arr.dtype != target:
        arr = arr.astype(target, copy=False)
        copy_result = True

    arr, scaled = _normalize_uint16_source_depth_scale(arr, bit_depth=bit_depth)
    copy_result = copy_result or scaled

    if copy_result:
        return np.array(arr, copy=True, order="C")
    if not arr.flags.c_contiguous:
        return np.ascontiguousarray(arr)
    return arr


def _decoded_frame_to_rgb_numpy(frame, torch_mod, *, bit_depth: int | None = None):
    """Return a contiguous HWC RGB numpy array owned by the caller."""
    if hasattr(frame, "__dlpack__"):
        try:
            arr = np.from_dlpack(frame)
        except Exception:
            pass
        else:
            return _normalize_rgb_numpy_output(arr, bit_depth=bit_depth, copy_result=True)
        if torch_mod is not None:
            try:
                arr = torch_mod.from_dlpack(frame).detach().cpu().numpy()
            except Exception:
                pass
            else:
                return _normalize_rgb_numpy_output(arr, bit_depth=bit_depth)
        cp = try_import_cupy()
        if cp is not None:
            arr = cp.asnumpy(cp.from_dlpack(frame))
            return _normalize_rgb_numpy_output(arr, bit_depth=bit_depth)
    # Host-memory decode outputs may alias decoder-managed buffers that get
    # reused on the next decode call, so take ownership here.
    return _normalize_rgb_numpy_output(frame, bit_depth=bit_depth, copy_result=True)


def _decoded_frame_to_rgb_cupy(
    frame: Any,
    *,
    bit_depth: int | None = None,
    gpu_id: int | None = None,
    cuda_stream: int | None = None,
):
    """Produce a fresh contiguous HWC RGB ``cupy.ndarray`` from a decoder output.

    Resulting array is always a new device allocation: the caller owns it and
    the decoder is free to overwrite its pool slot immediately after return.
    The GPU→GPU copy (or H2D copy, if ``frame`` is a host array) is issued on
    ``cuda_stream`` when provided, otherwise on CuPy's current stream.
    """
    cp = _cupy_or_raise()

    def _as_cupy(src):
        if hasattr(src, "__dlpack__"):
            return cp.from_dlpack(src)
        return cp.asarray(np.ascontiguousarray(np.asarray(src)))

    with _device_and_stream_ctx(cp, gpu_id=gpu_id, cuda_stream=cuda_stream):
        src = _as_cupy(frame)
        src, _ = _ensure_hwc(src)
        target = _target_dtype_for(src.dtype, bit_depth=bit_depth)
        out = cp.empty(src.shape, dtype=target, order="C")
        if src.dtype == target:
            cp.copyto(out, src)
        else:
            out[...] = src.astype(target, copy=False)
    return out


def numpy_to_cupy_rgb(
    arr: np.ndarray,
    *,
    gpu_id: int | None = None,
    cuda_stream: int | None = None,
):
    """Copy a host HWC RGB array to a fresh ``cupy.ndarray`` on ``cuda_stream``."""
    cp = _cupy_or_raise()
    arr = np.ascontiguousarray(arr)
    with _device_and_stream_ctx(cp, gpu_id=gpu_id, cuda_stream=cuda_stream):
        out = cp.empty(arr.shape, dtype=arr.dtype)
        out.set(arr)
    return out


def _source_depth_rgb_format(depth: int) -> str:
    return "rgb24" if depth <= 8 else f"gbrp{depth}le"


def _pyav_source_color_range(frame):
    color_range = getattr(frame, "color_range", None)
    text = str(color_range)
    try:
        from av.video.reformatter import ColorRange
    except Exception:
        return color_range
    if text in {"2", "JPEG", "jpeg", "pc"}:
        return ColorRange.JPEG
    if text in {"1", "MPEG", "mpeg", "tv"}:
        return ColorRange.MPEG
    return color_range


def _pyav_to_source_depth_rgb(frame, *, bit_depth: int):
    fmt = _source_depth_rgb_format(bit_depth)
    reformat = getattr(frame, "reformat", None)
    if callable(reformat):
        try:
            return reformat(
                format=fmt,
                src_color_range=_pyav_source_color_range(frame),
            ).to_ndarray()
        except Exception:
            pass
    return frame.to_ndarray(format=fmt)


def _normalize_uint16_source_depth_scale(
    arr: np.ndarray, *, bit_depth: int | None
) -> tuple[np.ndarray, bool]:
    if bit_depth is None or bit_depth <= 8 or bit_depth >= 16 or arr.dtype != np.uint16:
        return arr, False

    source_max = (1 << bit_depth) - 1
    if arr.size == 0 or int(arr.max()) <= source_max:
        return arr, False

    shift = 16 - bit_depth
    out = np.right_shift(arr, shift)
    return np.clip(out, 0, source_max).astype(np.uint16, copy=False), True


def _rgb48_to_source_depth(arr: np.ndarray, *, bit_depth: int) -> np.ndarray:
    arr = np.asarray(arr)
    arr, _ = _ensure_hwc(arr)
    if bit_depth >= 16:
        return _normalize_rgb_numpy_output(arr, bit_depth=bit_depth, copy_result=True)

    shift = 16 - bit_depth
    source_max = (1 << bit_depth) - 1
    out = np.right_shift(arr, shift)
    return np.clip(out, 0, source_max).astype(np.uint16, copy=False)


def _pyav_frame_to_rgb(frame, *, bit_depth: int | None = None) -> np.ndarray:
    """Convert a PyAV VideoFrame to an HWC RGB numpy array.

    Full-range yuv444p streams are converted manually to dodge swscale's
    limited-range default when VUI is unspecified. High-bit-depth outputs use
    source-depth scale, matching pyavif: 10-bit values are 0..1023, 12-bit
    values are 0..4095, stored in uint16 arrays.
    """
    pf = str(frame.format.name)
    depth = int(bit_depth) if bit_depth is not None else infer_video_bit_depth_from_frame(frame)
    cr = getattr(frame, "color_range", None)
    cr_text = str(cr) if cr is not None else ""
    is_full = cr is not None and cr_text in ("2", "JPEG", "jpeg", "pc")

    if pf.startswith("yuv444p") and (
        is_full or cr is None or cr_text in ("0", "UNSPECIFIED", "unspecified")
    ):
        try:
            yuv = frame.to_ndarray(format=pf)
        except ValueError:
            yuv = None
        if yuv is not None:
            y = yuv[0].astype(np.float32)
            max_value = float((1 << depth) - 1)
            center = (max_value + 1.0) / 2.0
            cb = yuv[1].astype(np.float32) - center
            crv = yuv[2].astype(np.float32) - center

            max_out = max_value
            target_dtype = np.uint16 if depth > 8 else np.uint8
            scale = max_out / max_value

            r = np.clip((y + 1.402 * crv) * scale + 0.5, 0, max_out).astype(target_dtype)
            g = np.clip((y - 0.344136 * cb - 0.714136 * crv) * scale + 0.5, 0, max_out).astype(target_dtype)
            b = np.clip((y + 1.772 * cb) * scale + 0.5, 0, max_out).astype(target_dtype)
            return np.stack([r, g, b], axis=-1)

    if depth <= 8:
        return frame.to_ndarray(format="rgb24")

    try:
        return _normalize_rgb_numpy_output(
            _pyav_to_source_depth_rgb(frame, bit_depth=depth),
            bit_depth=depth,
            copy_result=True,
        )
    except ValueError:
        return _rgb48_to_source_depth(frame.to_ndarray(format="rgb48le"), bit_depth=depth)
