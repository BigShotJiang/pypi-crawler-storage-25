"""Bit-depth probing and NVENC/NVDEC capability / compatibility checks."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from ._imports import normalize_codec_name, try_import_av, try_import_pynvvideocodec


def infer_video_bit_depth_from_pixel_format_name(pixel_format_name: str | None) -> int | None:
    if pixel_format_name is None:
        return None
    name = str(pixel_format_name).strip().lower()
    if not name:
        return None

    match = re.search(r"p(\d+)(?:le|be)?$", name)
    if match:
        return int(match.group(1))

    match = re.search(r"gray(\d+)(?:le|be)?$", name)
    if match:
        return int(match.group(1))

    match = re.search(r"(?:rgb|bgr)(\d+)(?:le|be)?$", name)
    if match:
        total = int(match.group(1))
        if total % 3 == 0:
            return total // 3

    if any(tag in name for tag in ("yuv", "rgb", "bgr", "gbr", "gray")):
        return 8
    return None


def infer_video_bit_depth_from_video_format(video_format: Any) -> int | None:
    if video_format is None:
        return None
    components = getattr(video_format, "components", None)
    if components:
        bits = [int(getattr(c, "bits", 0)) for c in components]
        bits = [b for b in bits if b > 0]
        if bits:
            return max(bits)
    return infer_video_bit_depth_from_pixel_format_name(getattr(video_format, "name", None))


def infer_video_bit_depth_from_stream(video_stream: Any) -> int:
    ctx = getattr(video_stream, "codec_context", None)
    for value in (
        getattr(ctx, "bits_per_raw_sample", None),
        getattr(video_stream, "bits_per_raw_sample", None),
    ):
        if isinstance(value, int) and value > 0:
            return value
    for fmt in (getattr(ctx, "format", None), getattr(video_stream, "format", None)):
        depth = infer_video_bit_depth_from_video_format(fmt)
        if depth is not None:
            return depth
    for pf in (getattr(ctx, "pix_fmt", None), getattr(video_stream, "pix_fmt", None)):
        depth = infer_video_bit_depth_from_pixel_format_name(pf)
        if depth is not None:
            return depth
    return 8


def infer_video_bit_depth_from_frame(frame: Any) -> int:
    return infer_video_bit_depth_from_video_format(getattr(frame, "format", None)) or 8


def probe_video_bit_depth_pyav(path: Path) -> int:
    av = try_import_av()
    if av is None:
        raise RuntimeError("PyAV is required to probe video bit depth.")
    with av.open(str(path)) as container:
        if not container.streams.video:
            raise RuntimeError(f"No video stream in {path}")
        return infer_video_bit_depth_from_stream(container.streams.video[0])


def probe_video_color_metadata_pyav(path: Path) -> dict[str, Any]:
    av = try_import_av()
    if av is None:
        return {"color_range": None, "color_space": None}
    try:
        with av.open(str(path)) as container:
            if not container.streams.video:
                return {"color_range": None, "color_space": None}
            stream = container.streams.video[0]
            return {
                "color_range": getattr(stream, "color_range", None),
                "color_space": getattr(stream, "colorspace", None),
            }
    except Exception:
        return {"color_range": None, "color_space": None}


def probe_video_bit_depth(path: Path, nvc: Any | None = None) -> int:
    pyav_error: Exception | None = None
    try:
        return probe_video_bit_depth_pyav(path)
    except Exception as exc:
        pyav_error = exc

    if nvc is None:
        try:
            nvc = try_import_pynvvideocodec()
        except Exception:
            nvc = None
    if nvc is not None:
        try:
            return int(probe_video_stream_metadata(nvc, path)["bitdepth"])
        except Exception:
            pass

    raise RuntimeError(f"Could not probe video bit depth for {path}") from pyav_error


def probe_video_stream_metadata(nvc, path: Path | str) -> dict[str, Any]:
    demux = nvc.CreateDemuxer(filename=str(path))
    codec_id = demux.GetNvCodecId()
    codec_name = str(codec_id).split(".")[-1].lower()
    if codec_name == "h265":
        codec_name = "hevc"
    return {
        "codec": codec_name,
        "width": int(demux.Width()),
        "height": int(demux.Height()),
        "bitdepth": int(demux.BitDepth()),
        "chroma_subsampling": str(demux.ChromaFormat()).split(".")[-1],
        "color_space": str(demux.ColorSpace()),
        "color_range": str(demux.ColorRange()),
    }


def pynvc_codec_enum(nvc, codec: str):
    mapping = {"h264": "H264", "hevc": "HEVC", "av1": "AV1"}
    name = mapping.get(normalize_codec_name(codec))
    if name is None:
        raise ValueError(f"Unsupported codec for NVDEC capability checks: {codec!r}")
    return getattr(nvc.cudaVideoCodec, name)


def pynvc_chroma_format(nvc, subsampling: str):
    s = subsampling.strip()
    if s in ("420", "444"):
        return getattr(nvc.cudaVideoChromaFormat, s)
    raise ValueError('chroma subsampling must be "420" or "444"')


def safe_get_encoder_caps(nvc, gpu_id: int, codec: str) -> dict[str, Any] | None:
    try:
        return nvc.GetEncoderCaps(gpu_id, normalize_codec_name(codec))
    except Exception:
        return None


def safe_get_decoder_caps(
    nvc, gpu_id: int, codec: str, chroma_subsampling: str, bitdepth: int
) -> dict[str, Any] | None:
    try:
        return nvc.GetDecoderCaps(
            gpu_id,
            pynvc_codec_enum(nvc, codec),
            pynvc_chroma_format(nvc, chroma_subsampling),
            int(bitdepth),
        )
    except Exception:
        return None


def _check_size_caps(caps: dict[str, Any], width: int, height: int, *, role: str) -> str | None:
    w_min = caps.get("width_min", 0)
    h_min = caps.get("height_min", 0)
    if width < w_min or height < h_min:
        return f"{role} requires at least {w_min}x{h_min} but got {width}x{height}"
    w_max = caps.get("width_max")
    h_max = caps.get("height_max")
    if w_max and width > w_max:
        return f"{role} width limit is {w_max} but got {width}"
    if h_max and height > h_max:
        return f"{role} height limit is {h_max} but got {height}"
    return None


def nvdec_decode_compatibility_issue(
    nvc,
    width: int,
    height: int,
    *,
    gpu_id: int,
    codec: str,
    chroma_subsampling: str,
    bitdepth: int = 8,
) -> str | None:
    caps = safe_get_decoder_caps(nvc, gpu_id, codec, chroma_subsampling, bitdepth)
    if not caps or not caps.get("supported"):
        return (
            f"GPU decoder does not support codec={normalize_codec_name(codec)!r} "
            f"chroma={chroma_subsampling} bitdepth={bitdepth}"
        )
    return _check_size_caps(caps, width, height, role="decoder")


def nvdec_decode_compatibility_issue_for_path(nvc, path: Path | str, gpu_id: int) -> str | None:
    meta = probe_video_stream_metadata(nvc, path)
    return nvdec_decode_compatibility_issue(
        nvc,
        meta["width"],
        meta["height"],
        gpu_id=gpu_id,
        codec=meta["codec"],
        chroma_subsampling=meta["chroma_subsampling"],
        bitdepth=meta["bitdepth"],
    )


def nvenc_encode_compatibility_issue(
    nvc,
    width: int,
    height: int,
    *,
    gpu_id: int,
    codec: str = "h264",
    chroma_subsampling: str = "444",
) -> str | None:
    codec = normalize_codec_name(codec)
    if width < height:
        return (
            f"portrait frames ({width}x{height}) require padding for NVENC, "
            "and ranged writing falls back to AVIF instead"
        )
    caps = safe_get_encoder_caps(nvc, gpu_id, codec)
    if caps is None:
        return f"GPU reports no encoder support for codec={codec!r}"
    if chroma_subsampling == "444" and not caps.get("support_yuv444_encode"):
        return (
            f"GPU reports no 4:4:4 encode for codec={codec!r} "
            "(support_yuv444_encode=0)"
        )
    return _check_size_caps(caps, width, height, role="encoder")


def nvenc_encode_compatibility_issue_for_rgb(
    nvc,
    rgb,
    *,
    gpu_id: int,
    codec: str = "h264",
    chroma_subsampling: str = "444",
) -> str | None:
    if rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("expected RGB HWC")
    return nvenc_encode_compatibility_issue(
        nvc,
        int(rgb.shape[1]),
        int(rgb.shape[0]),
        gpu_id=gpu_id,
        codec=codec,
        chroma_subsampling=chroma_subsampling,
    )
