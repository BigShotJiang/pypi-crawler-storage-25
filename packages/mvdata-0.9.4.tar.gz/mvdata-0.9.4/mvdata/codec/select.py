"""Round-trip quality evaluation and auto codec selection."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any, Sequence, Tuple

import numpy as np

from ._imports import (
    AUTO_NVENC_CHROMA_SUBSAMPLING,
    AUTO_NVENC_CODEC_CANDIDATES,
    AUTO_NVENC_MIN_PSNR_DB,
    AUTO_NVENC_PRESET,
    normalize_codec_name,
    try_import_av,
)
from .decode import decode_mp4_to_rgb
from .encode import (
    encode_rgb_frames_to_elementary_stream,
    mux_elementary_to_mp4,
    pad_rgb_for_nvenc,
    resolve_nvenc_bitrate_bps,
)
from .probe import (
    nvdec_decode_compatibility_issue,
    nvenc_encode_compatibility_issue_for_rgb,
)


def roundtrip_nvenc_stream_psnr(
    frames: Sequence[np.ndarray],
    *,
    workdir: Path,
    stream_tag: str,
    nvc,
    gpu_id: int,
    fps: int,
    bitrate: int,
    decoder: str = "pyav",
    codec: str = "h264",
    full_range: bool = True,
    chroma_subsampling: str = "444",
    preset: str = "P7",
) -> Tuple[float, float, float]:
    """Encode → MP4 → decode; crop pad; return (mean_psnr, min_psnr, mse_vs_mean)."""
    from ..image_metrics import calculate_psnr

    codec = normalize_codec_name(codec)
    frames_list = list(frames)
    _, crop = pad_rgb_for_nvenc(frames_list[0])
    y0, y1, x0, x1 = crop
    elementary = encode_rgb_frames_to_elementary_stream(
        nvc, frames_list, gpu_id, fps, bitrate,
        codec=codec, full_range=full_range,
        chroma_subsampling=chroma_subsampling, preset=preset,
    )
    mp4_path = workdir / f"roundtrip_{stream_tag}.mp4"
    demux = "hevc" if codec in ("hevc", "h265") else "h264"
    mux_elementary_to_mp4(elementary, mp4_path, float(fps), demux_format=demux)
    dec = decode_mp4_to_rgb(mp4_path, len(frames_list), decoder=decoder, nvc=nvc, gpu_id=gpu_id)
    dec_cropped = [d[y0:y1, x0:x1].copy() for d in dec]

    m = min(len(dec_cropped), len(frames_list))
    psnrs = [calculate_psnr(frames_list[i], dec_cropped[i]) for i in range(m)]
    mean_psnr = float(np.mean(psnrs)) if psnrs else float("nan")
    min_psnr = float(np.min(psnrs)) if psnrs else float("nan")
    mse = float(
        np.mean(
            [
                np.mean(
                    (frames_list[i].astype(np.float64) - dec_cropped[i].astype(np.float64)) ** 2
                )
                for i in range(m)
            ]
        )
    )
    return mean_psnr, min_psnr, mse


def select_auto_nvenc_candidate_for_rgb(
    nvc,
    probe_rgb: np.ndarray,
    *,
    gpu_id: int,
    fps: int,
    bitrate_arg: int = 0,
    preset: str = AUTO_NVENC_PRESET,
    codec_candidates: Sequence[str] = AUTO_NVENC_CODEC_CANDIDATES,
    chroma_subsampling: str = AUTO_NVENC_CHROMA_SUBSAMPLING,
    full_range: bool = True,
    min_psnr_db: float = AUTO_NVENC_MIN_PSNR_DB,
) -> dict[str, Any] | None:
    if probe_rgb.ndim != 3 or probe_rgb.shape[2] != 3:
        raise ValueError("probe_rgb must be RGB HWC")

    width = int(probe_rgb.shape[1])
    height = int(probe_rgb.shape[0])
    preset_use = preset or AUTO_NVENC_PRESET

    for raw_codec in codec_candidates:
        codec = normalize_codec_name(raw_codec)
        if nvenc_encode_compatibility_issue_for_rgb(
            nvc, probe_rgb, gpu_id=gpu_id, codec=codec, chroma_subsampling=chroma_subsampling
        ) is not None:
            continue

        decode_issue = nvdec_decode_compatibility_issue(
            nvc, width, height,
            gpu_id=gpu_id, codec=codec,
            chroma_subsampling=chroma_subsampling, bitdepth=8,
        )
        if decode_issue is None:
            decoder = "nvidia"
        elif try_import_av() is not None:
            decoder = "pyav"
        else:
            continue

        bitrate_bps = resolve_nvenc_bitrate_bps(
            bitrate_arg, width, height, fps, chroma_subsampling=chroma_subsampling
        )

        try:
            with tempfile.TemporaryDirectory(prefix="mvdata_nvenc_probe_") as tmpdir:
                mean_psnr, min_psnr, mse = roundtrip_nvenc_stream_psnr(
                    [probe_rgb],
                    workdir=Path(tmpdir),
                    stream_tag=f"{codec}_{chroma_subsampling}_{'full' if full_range else 'limited'}",
                    nvc=nvc, gpu_id=gpu_id, fps=fps, bitrate=bitrate_bps,
                    decoder=decoder, codec=codec, full_range=full_range,
                    chroma_subsampling=chroma_subsampling, preset=preset_use,
                )
        except Exception:
            continue

        if mean_psnr < float(min_psnr_db):
            continue

        return {
            "codec": codec,
            "chroma_subsampling": chroma_subsampling,
            "full_range": bool(full_range),
            "preset": preset_use,
            "bitrate_bps": bitrate_bps,
            "decoder": decoder,
            "mean_psnr": float(mean_psnr),
            "min_psnr": float(min_psnr),
            "mse": float(mse),
        }

    return None
