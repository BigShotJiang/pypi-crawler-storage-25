"""Lazy optional-dependency imports and codec name normalisation."""

from __future__ import annotations

import importlib
from typing import Any

_PYNVC_API_REF = "PyNvVideoCodec_API_Reference.pdf"

AUTO_NVENC_CODEC_CANDIDATES = ("av1", "hevc", "h264")
AUTO_NVENC_CHROMA_SUBSAMPLING = "444"
AUTO_NVENC_PRESET = "P7"
AUTO_NVENC_RANGE_MODE = "full"
AUTO_NVENC_MIN_PSNR_DB = 38.0


def try_import_pynvvideocodec() -> Any:
    return importlib.import_module("PyNvVideoCodec")


def _try_import(name: str) -> Any | None:
    try:
        return importlib.import_module(name)
    except ImportError:
        return None


def try_import_av() -> Any | None:
    return _try_import("av")


def try_import_torch() -> Any | None:
    return _try_import("torch")


def try_import_cupy() -> Any | None:
    return _try_import("cupy")


def normalize_codec_name(codec: str) -> str:
    c = codec.strip().lower()
    return "hevc" if c == "h265" else c
