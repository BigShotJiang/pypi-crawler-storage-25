from __future__ import annotations

from typing import Optional

from .multivideo_slicer_models import (
    DEGENERATE_RANGE_MAX_SHARE,
    MultiVideoSliceError,
    MultiVideoSliceRange,
    MultiVideoStreamSliceInfo,
)


def _choose_legal_step(
    target_frames: int,
    keyframe_interval_frames: int,
    *,
    prefer_larger_chunk: bool,
    max_frames_per_range: int,
) -> int:
    max_multiple = max_frames_per_range // keyframe_interval_frames
    if max_multiple < 1:
        raise MultiVideoSliceError(
            "Keyframe interval exceeds the maximum ranged MP4 size: "
            f"keyframe_interval_frames={keyframe_interval_frames}, "
            f"max_frames_per_range={max_frames_per_range}"
        )

    lower_multiple = max(1, min(max_multiple, target_frames // keyframe_interval_frames))
    if target_frames % keyframe_interval_frames == 0:
        upper_multiple = lower_multiple
    else:
        upper_multiple = min(max_multiple, lower_multiple + 1)

    candidates = {
        lower_multiple * keyframe_interval_frames,
        upper_multiple * keyframe_interval_frames,
    }

    def sort_key(candidate: int) -> tuple[int, int]:
        tie_break = -candidate if prefer_larger_chunk else candidate
        return (abs(candidate - target_frames), tie_break)

    return min(candidates, key=sort_key)


def _build_ranges(common_frame_count: int, step_frames: int) -> tuple[MultiVideoSliceRange, ...]:
    ranges: list[MultiVideoSliceRange] = []
    source_start = 0
    while source_start < common_frame_count:
        source_end = min(source_start + step_frames, common_frame_count) - 1
        ranges.append(
            MultiVideoSliceRange(
                source_start_frame=source_start,
                source_end_frame=source_end,
                output_start_frame=source_start,
                output_end_frame=source_end,
            )
        )
        source_start = source_end + 1
    return tuple(ranges)


def _degenerate_range_plan_error(
    ranges: tuple[MultiVideoSliceRange, ...],
    common_frame_count: int,
) -> Optional[str]:
    if not ranges or len(ranges) > 2 or common_frame_count <= 0:
        return None

    largest_range = max(ranges, key=lambda range_info: range_info.frame_count)
    largest_share = largest_range.frame_count / common_frame_count
    if largest_share < DEGENERATE_RANGE_MAX_SHARE:
        return None

    return (
        "Slicing would produce a degenerate ranged dataset: "
        f"{len(ranges)} range(s), with range {largest_range.output_name} covering "
        f"{largest_share:.1%} of the common frame region. "
        "Use a smaller target_frames value to create more balanced ranges."
    )


def _common_keyframes(video: MultiVideoStreamSliceInfo, min_frames: int) -> tuple[int, ...]:
    return tuple(index for index in video.keyframe_indices if index < min_frames)


def _constant_keyframe_interval(common_keyframes: tuple[int, ...]) -> Optional[int]:
    if len(common_keyframes) < 2:
        return None
    intervals = [
        next_index - prev_index
        for prev_index, next_index in zip(common_keyframes, common_keyframes[1:])
    ]
    first = intervals[0]
    if any(interval != first for interval in intervals):
        raise MultiVideoSliceError(
            "Variable GOP interval in common region: "
            f"observed intervals start with {intervals[:8]}"
        )
    return first
