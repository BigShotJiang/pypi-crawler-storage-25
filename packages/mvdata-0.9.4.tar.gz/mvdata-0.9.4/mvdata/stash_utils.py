"""Shared utilities for stash frame management.

This module contains functions used by both DatasetWriter (during conversion)
and Dataset.regenerate_stash() (for post-conversion stash management).
"""

import binascii
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import re
import shutil
import struct
from typing import List, Dict, Optional, TYPE_CHECKING
import zlib

import numpy as np
from PIL import Image

if TYPE_CHECKING:
    from .dataset_base import Dataset

# Extensions that can be copied directly without re-encoding
SUPPORTED_STASH_EXTENSIONS = ['.png', '.tiff', '.tif', '.exr', '.jpg', '.jpeg']


def _png_chunk(chunk_type: bytes, payload: bytes) -> bytes:
    return (
        struct.pack(">I", len(payload))
        + chunk_type
        + payload
        + struct.pack(">I", binascii.crc32(chunk_type + payload) & 0xFFFFFFFF)
    )


def _save_rgb_uint16_png(image_array: np.ndarray, output_path: Path) -> None:
    if image_array.dtype != np.uint16 or image_array.ndim != 3 or image_array.shape[2] != 3:
        raise ValueError("Expected uint16 HWC RGB image")

    height, width, _ = image_array.shape
    # PNG stores 16-bit samples in big-endian byte order.
    big_endian = image_array.astype(">u2", copy=False)
    row_bytes = width * 3 * 2
    data_view = memoryview(big_endian).cast("B")

    raw = bytearray((row_bytes + 1) * height)
    for row in range(height):
        row_start = row * (row_bytes + 1)
        raw[row_start] = 0  # filter type 0 (None)
        src_start = row * row_bytes
        raw[row_start + 1 : row_start + 1 + row_bytes] = data_view[src_start : src_start + row_bytes]

    ihdr = struct.pack(">IIBBBBB", width, height, 16, 2, 0, 0, 0)
    payload = bytearray(b"\x89PNG\r\n\x1a\n")
    payload.extend(_png_chunk(b"IHDR", ihdr))
    payload.extend(_png_chunk(b"IDAT", zlib.compress(bytes(raw), level=6)))
    payload.extend(_png_chunk(b"IEND", b""))
    output_path.write_bytes(payload)


def select_stash_frames(start_frame: int, end_frame: int, num_frames: int) -> List[int]:
    """
    Select evenly distributed frame numbers for stash generation.

    Args:
        start_frame: First frame in range
        end_frame: Last frame in range (inclusive)
        num_frames: Desired number of frames

    Returns:
        List of selected frame numbers, evenly distributed
    """
    total_frames = end_frame - start_frame + 1
    if total_frames <= 0 or num_frames <= 0:
        return []

    num_frames = min(num_frames, total_frames)
    if num_frames == total_frames:
        return list(range(start_frame, end_frame + 1))

    indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
    return [start_frame + int(i) for i in indices]


def normalize_extension(ext: str) -> str:
    """Normalize file extension (e.g., .tif -> .tiff)."""
    if ext == '.tif':
        return '.tiff'
    return ext


def save_stash_image(image_array: np.ndarray, output_path: Path) -> None:
    """
    Save numpy array as stash image file.

    Handles both 8-bit and 16-bit images, saving as PNG.

    Args:
        image_array: Image data as numpy array (HWC format)
        output_path: Path to save the image
    """
    if image_array.dtype == np.uint16:
        _save_rgb_uint16_png(image_array, output_path)
        return

    if image_array.dtype != np.uint8:
        image_array = np.clip(image_array, 0, 255).astype(np.uint8)

    img = Image.fromarray(image_array, mode="RGB")
    img.save(output_path, format="PNG", compress_level=6)


def delete_numbered_stash(stash_dir: Path, verbose: bool = False) -> int:
    """
    Delete all numbered stash frame directories.

    Only deletes directories whose names are digit sequences (numbered frames).
    Preserves non-numbered directories (extra stash like 'reference').

    Args:
        stash_dir: Path to the stash directory
        verbose: If True, print deleted directories

    Returns:
        Number of deleted frame directories
    """
    if not stash_dir.exists():
        return 0

    deleted_count = 0
    for item in stash_dir.iterdir():
        if item.is_dir():
            # Check if directory name is a number (stash frame)
            if re.match(r'^\d+$', item.name):
                if verbose:
                    print(f"  Deleting stash/{item.name}")
                shutil.rmtree(item)
                deleted_count += 1

    return deleted_count


def generate_stash_frame(
    source: "Dataset",
    frame_idx: int,
    output_frame_dir: Path,
    stream_ids: List[int],
    supported_exts: Optional[List[str]] = None,
    max_workers: int = 4,
) -> None:
    """
    Generate a single stash frame from source dataset.

    Uses agnostic approach:
    - If source provides direct file paths (e.g., Legacy), copies files directly
    - Otherwise, decodes and saves as PNG

    Args:
        source: Source dataset to read from
        frame_idx: Frame index to generate
        output_frame_dir: Directory to save frame (e.g., stash/00000000/rgb)
        stream_ids: List of stream IDs to include
        supported_exts: Extensions that can be copied directly (default: SUPPORTED_STASH_EXTENSIONS)
        max_workers: Number of workers for frame decoding
    """
    if supported_exts is None:
        supported_exts = SUPPORTED_STASH_EXTENSIONS

    output_frame_dir.mkdir(parents=True, exist_ok=True)

    # Try agnostic direct copy first (works for Legacy datasets)
    source_paths = source.get_frame_source_paths(frame_idx, stream_ids)

    if source_paths:
        # Direct copy with normalization
        for stream_id, source_path in source_paths.items():
            source_ext = source_path.suffix.lower()
            if source_ext in supported_exts:
                output_ext = normalize_extension(source_ext)
                output_name = f"{stream_id:03d}{output_ext}"
                output_path = output_frame_dir / output_name
                shutil.copy2(source_path, output_path)
            else:
                # Convert unsupported format to PNG
                output_name = f"{stream_id:03d}.png"
                output_path = output_frame_dir / output_name
                img = Image.open(source_path)
                img_array = np.array(img)
                save_stash_image(img_array, output_path)
    else:
        # Decode from compressed source (Ranged/MultiVideo)
        reader = source.create_frame_reader(
            stream_ids=stream_ids,
            start_frame=frame_idx,
            end_frame=frame_idx,
            max_workers=max_workers,
        )
        try:
            _, frame_data = reader.read_frame(frame_idx)
        finally:
            reader.close()

        _save_decoded_stash_frame(
            frame_idx,
            frame_data,
            output_frame_dir,
            stream_ids,
            max_workers,
        )


def _save_decoded_stash_stream(
    frame_idx: int,
    stream_id: int,
    frame_data: Dict[int, np.ndarray],
    output_frame_dir: Path,
) -> None:
    if stream_id not in frame_data:
        raise ValueError(
            f"Stream {stream_id} not found in frame {frame_idx}. "
            f"Available streams: {list(frame_data.keys())}"
        )

    image_array = frame_data[stream_id]
    if not isinstance(image_array, np.ndarray):
        raise ValueError(f"Expected numpy array, got {type(image_array)}")

    save_stash_image(image_array, output_frame_dir / f"{stream_id:03d}.png")


def _save_decoded_stash_frame(
    frame_idx: int,
    frame_data: Dict[int, np.ndarray],
    output_frame_dir: Path,
    stream_ids: List[int],
    max_workers: int,
) -> None:
    if max_workers <= 1 or len(stream_ids) <= 1:
        for stream_id in stream_ids:
            _save_decoded_stash_stream(frame_idx, stream_id, frame_data, output_frame_dir)
        return

    with ThreadPoolExecutor(max_workers=min(max_workers, len(stream_ids))) as executor:
        futures = [
            executor.submit(
                _save_decoded_stash_stream,
                frame_idx,
                stream_id,
                frame_data,
                output_frame_dir,
            )
            for stream_id in stream_ids
        ]
        for future in futures:
            future.result()


def _decode_stash_frames_to_path(
    source: "Dataset",
    target_stash_dir: Path,
    frame_indices: List[int],
    stream_ids: List[int],
    output_frame_numbers: List[int],
    max_workers: int,
) -> None:
    ranges = source.get_frame_ranges()
    pairs = list(zip(frame_indices, output_frame_numbers))
    handled_frames = set()

    for range_start, range_end, _ in ranges:
        range_pairs = [
            (frame_idx, output_num)
            for frame_idx, output_num in pairs
            if range_start <= frame_idx <= range_end
        ]
        if not range_pairs:
            continue

        reader = source.create_frame_reader(
            stream_ids=stream_ids,
            start_frame=min(frame_idx for frame_idx, _ in range_pairs),
            end_frame=max(frame_idx for frame_idx, _ in range_pairs),
            max_workers=max_workers,
        )
        try:
            for frame_idx, output_num in range_pairs:
                output_frame_dir = target_stash_dir / f"{output_num:08d}" / "rgb"
                output_frame_dir.mkdir(parents=True, exist_ok=True)
                _, frame_data = reader.read_frame(frame_idx)
                _save_decoded_stash_frame(
                    frame_idx,
                    frame_data,
                    output_frame_dir,
                    stream_ids,
                    max_workers,
                )
        finally:
            reader.close()
        handled_frames.update(frame_idx for frame_idx, _ in range_pairs)

    missing_frames = [frame_idx for frame_idx in frame_indices if frame_idx not in handled_frames]
    if missing_frames:
        raise ValueError(f"Stash frame(s) outside source ranges: {missing_frames}")


def generate_stash_to_path(
    source: "Dataset",
    target_stash_dir: Path,
    frame_indices: List[int],
    stream_ids: List[int],
    output_frame_numbers: Optional[List[int]] = None,
    supported_exts: Optional[List[str]] = None,
    max_workers: int = 4,
    verbose: bool = False,
) -> List[int]:
    """
    Generate multiple stash frames to a target directory.

    Args:
        source: Source dataset to read from
        target_stash_dir: Target stash directory (e.g., dataset/stash)
        frame_indices: List of frame indices to generate (in source dataset)
        stream_ids: List of stream IDs to include
        output_frame_numbers: Output frame numbers (default: same as frame_indices)
        supported_exts: Extensions that can be copied directly
        max_workers: Number of workers for frame decoding
        verbose: Print progress information

    Returns:
        List of output frame numbers that were generated
    """
    if not frame_indices:
        return []

    if output_frame_numbers is None:
        output_frame_numbers = frame_indices

    if len(frame_indices) != len(output_frame_numbers):
        raise ValueError(
            f"frame_indices ({len(frame_indices)}) and output_frame_numbers "
            f"({len(output_frame_numbers)}) must have same length"
        )

    target_stash_dir.mkdir(parents=True, exist_ok=True)

    pairs = list(zip(frame_indices, output_frame_numbers))
    for frame_idx, output_num in pairs:
        if verbose:
            print(f"  Generating stash frame {output_num} (from source frame {frame_idx})")

    first_source_paths = source.get_frame_source_paths(frame_indices[0], stream_ids)
    if first_source_paths:
        generated = []
        for frame_idx, output_num in pairs:
            output_frame_dir = target_stash_dir / f"{output_num:08d}" / "rgb"
            generate_stash_frame(
                source=source,
                frame_idx=frame_idx,
                output_frame_dir=output_frame_dir,
                stream_ids=stream_ids,
                supported_exts=supported_exts,
                max_workers=max_workers,
            )
            generated.append(output_num)
        return generated

    _decode_stash_frames_to_path(
        source=source,
        target_stash_dir=target_stash_dir,
        frame_indices=frame_indices,
        stream_ids=stream_ids,
        output_frame_numbers=output_frame_numbers,
        max_workers=max_workers,
    )
    return list(output_frame_numbers)


def copy_stash_frames(
    source: "Dataset",
    target_stash_dir: Path,
    stream_ids: List[int],
    start_frame: int,
    end_frame: int,
    output_offset: int = 0,
    supported_exts: Optional[List[str]] = None,
    verbose: bool = False,
) -> List[int]:
    """
    Copy existing stash frames from source dataset to target directory.

    Args:
        source: Source dataset with existing stash
        target_stash_dir: Target stash directory
        stream_ids: List of stream IDs to copy
        start_frame: Start of frame range filter
        end_frame: End of frame range filter
        output_offset: Offset to subtract from frame numbers (for renumbering)
        supported_exts: Extensions that can be copied directly
        verbose: Print progress information

    Returns:
        List of output frame numbers that were copied

    Raises:
        ValueError: If source has no stash frames
    """
    if supported_exts is None:
        supported_exts = SUPPORTED_STASH_EXTENSIONS

    stash_frames = source.get_stash_frames()
    if not stash_frames:
        raise ValueError(
            "Cannot copy stash: source dataset has no stash frames. "
            "Use generate mode to create new stash frames."
        )

    # Filter stash frames that intersect with our range
    intersecting_frames = [
        (frame_num, stream_map)
        for frame_num, stream_map in stash_frames
        if start_frame <= frame_num <= end_frame
    ]

    if not intersecting_frames:
        return []

    target_stash_dir.mkdir(parents=True, exist_ok=True)
    copied = []

    for frame_num, stream_map in intersecting_frames:
        output_frame_num = frame_num - output_offset

        if verbose:
            print(f"  Copying stash frame {output_frame_num} (from source frame {frame_num})")

        output_frame_dir = target_stash_dir / f"{output_frame_num:08d}" / "rgb"
        output_frame_dir.mkdir(parents=True, exist_ok=True)

        for stream_id, source_path in stream_map.items():
            if stream_ids and stream_id not in stream_ids:
                continue

            source_ext = source_path.suffix.lower()

            if source_ext in supported_exts:
                output_ext = normalize_extension(source_ext)
                output_name = f"{stream_id:03d}{output_ext}"
                output_path = output_frame_dir / output_name
                shutil.copy2(source_path, output_path)
            else:
                # Convert unsupported format to PNG
                output_name = f"{stream_id:03d}.png"
                output_path = output_frame_dir / output_name
                img = Image.open(source_path)
                img_array = np.array(img)
                save_stash_image(img_array, output_path)

        copied.append(output_frame_num)

    return copied
