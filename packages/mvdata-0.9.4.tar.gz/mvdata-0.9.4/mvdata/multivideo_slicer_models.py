from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Optional


SUPPORTED_SLICE_CODECS = {"h264", "hevc", "av1"}
DEFAULT_MAX_FRAMES_PER_RANGED_MP4 = 1000
DEGENERATE_RANGE_MAX_SHARE = 0.90


class MultiVideoSliceError(ValueError):
    """Raised when a MultiVideo dataset cannot be packet-sliced safely."""


@dataclass(frozen=True)
class MultiVideoStreamSliceInfo:
    stream_id: int
    path: str
    codec: str
    fps: str
    width: int
    height: int
    packet_count: int
    visible_frame_count: int
    keyframe_indices: tuple[int, ...]
    sync_frame_indices: tuple[int, ...]
    packet_duration_ticks: Optional[int]

    @property
    def first_keyframes(self) -> tuple[int, ...]:
        return self.keyframe_indices[:8]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["first_keyframes"] = list(self.first_keyframes)
        return data


@dataclass(frozen=True)
class MultiVideoStreamEligibility:
    stream_id: int
    path: Optional[str]
    info: Optional[MultiVideoStreamSliceInfo]
    errors: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.info is not None and not self.errors

    def to_dict(self) -> dict[str, Any]:
        return {
            "stream_id": self.stream_id,
            "path": self.path,
            "passed": self.passed,
            "errors": list(self.errors),
            "info": self.info.to_dict() if self.info is not None else None,
        }


@dataclass(frozen=True)
class MultiVideoSliceRange:
    source_start_frame: int
    source_end_frame: int
    output_start_frame: int
    output_end_frame: int

    @property
    def frame_count(self) -> int:
        return self.source_end_frame - self.source_start_frame + 1

    @property
    def output_name(self) -> str:
        return f"{self.output_start_frame:08d}_{self.output_end_frame:08d}"

    def to_dict(self) -> dict[str, int | str]:
        return {
            "source_start_frame": self.source_start_frame,
            "source_end_frame": self.source_end_frame,
            "output_start_frame": self.output_start_frame,
            "output_end_frame": self.output_end_frame,
            "frame_count": self.frame_count,
            "output_name": self.output_name,
        }


@dataclass(frozen=True)
class MultiVideoSlicePlan:
    version: int
    mode: str
    target_frames: int
    chosen_step_frames: int
    exact_target: bool
    keyframe_interval_frames: Optional[int]
    tail_tolerance_frames: int
    common_frame_count: int
    min_frames: int
    max_frames: int
    stream_ids: tuple[int, ...]
    videos: tuple[MultiVideoStreamSliceInfo, ...]
    ranges: tuple[MultiVideoSliceRange, ...]
    discarded_tail_frames: dict[int, int]
    warnings: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "mode": self.mode,
            "target_frames": self.target_frames,
            "chosen_step_frames": self.chosen_step_frames,
            "exact_target": self.exact_target,
            "keyframe_interval_frames": self.keyframe_interval_frames,
            "tail_tolerance_frames": self.tail_tolerance_frames,
            "common_frame_count": self.common_frame_count,
            "min_frames": self.min_frames,
            "max_frames": self.max_frames,
            "stream_ids": list(self.stream_ids),
            "videos": [video.to_dict() for video in self.videos],
            "ranges": [range_info.to_dict() for range_info in self.ranges],
            "discarded_tail_frames": {
                str(stream_id): frames
                for stream_id, frames in sorted(self.discarded_tail_frames.items())
            },
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True)
class MultiVideoSliceEligibilityMetadata:
    dataset_type: str
    requested_stash_policy: str
    effective_stash_policy: str
    target_frames: int
    tail_tolerance_frames: int
    requested_stream_ids: Optional[tuple[int, ...]]
    discovered_stream_ids: tuple[int, ...]
    selected_stream_ids: tuple[int, ...]
    passed_stream_ids: tuple[int, ...]
    failed_stream_ids: tuple[int, ...]
    stream_results: tuple[MultiVideoStreamEligibility, ...]
    min_frames: Optional[int]
    max_frames: Optional[int]
    common_frame_count: Optional[int]
    resulting_dataset_start_frame: Optional[int]
    resulting_dataset_end_frame: Optional[int]
    resulting_dataset_frame_count: Optional[int]
    keyframe_interval_frames: Optional[int]
    chosen_step_frames: Optional[int]
    range_count: Optional[int]
    first_ranges: tuple[str, ...]
    discarded_tail_frames: dict[int, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_type": self.dataset_type,
            "requested_stash_policy": self.requested_stash_policy,
            "effective_stash_policy": self.effective_stash_policy,
            "target_frames": self.target_frames,
            "tail_tolerance_frames": self.tail_tolerance_frames,
            "requested_stream_ids": (
                list(self.requested_stream_ids)
                if self.requested_stream_ids is not None
                else None
            ),
            "discovered_stream_ids": list(self.discovered_stream_ids),
            "selected_stream_ids": list(self.selected_stream_ids),
            "passed_stream_ids": list(self.passed_stream_ids),
            "failed_stream_ids": list(self.failed_stream_ids),
            "stream_results": [result.to_dict() for result in self.stream_results],
            "min_frames": self.min_frames,
            "max_frames": self.max_frames,
            "common_frame_count": self.common_frame_count,
            "resulting_dataset_start_frame": self.resulting_dataset_start_frame,
            "resulting_dataset_end_frame": self.resulting_dataset_end_frame,
            "resulting_dataset_frame_count": self.resulting_dataset_frame_count,
            "keyframe_interval_frames": self.keyframe_interval_frames,
            "chosen_step_frames": self.chosen_step_frames,
            "range_count": self.range_count,
            "first_ranges": list(self.first_ranges),
            "discarded_tail_frames": {
                str(stream_id): frames
                for stream_id, frames in sorted(self.discarded_tail_frames.items())
            },
        }


@dataclass(frozen=True)
class MultiVideoSliceEligibility:
    plan: Optional[MultiVideoSlicePlan]
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    metadata: MultiVideoSliceEligibilityMetadata

    @property
    def eligible(self) -> bool:
        return self.plan is not None and not self.errors

    def raise_if_ineligible(self) -> MultiVideoSlicePlan:
        if self.plan is not None and not self.errors:
            return self.plan
        detail = "\n".join(f"- {error}" for error in self.errors)
        raise MultiVideoSliceError(f"MultiVideo dataset is not eligible for slicing:\n{detail}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "eligible": self.eligible,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "metadata": self.metadata.to_dict(),
            "plan": self.plan.to_dict() if self.plan is not None else None,
        }
