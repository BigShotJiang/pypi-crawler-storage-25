"""
Gracia Dataset Convention - Python library for working with multi-view video datasets.
"""

from typing import Any

from .cloud_storage import CloudStorageProviderType, CloudStorageUrl
from .dataset_base import Dataset, FrameReader, auto_detect_dataset
from .downloader import (
    DatasetDownloader,
    LegacyDatasetDownloader,
    MultiVideoDatasetDownloader,
    RangedDatasetDownloader,
    infer_and_download_dataset,
    register_downloader,
)
from .legacy_writer import LegacyDatasetWriter
from .per_frame import LegacyDataset, LegacyFrameReader
from .writer_base import DatasetWriter
from .gpu_policy import (
    clear_gpu_override,
    gpu_disabled,
    gpu_enabled,
    gpu_enabled_override,
    gpu_usage_allowed,
    gpu_nvenc_disabled_globally,
    nvdec_decode_allowed,
    nvdec_decoding_usable,
    nvenc_encode_allowed,
    nvenc_encoding_usable,
    pynvvideocodec_importable,
)
from .gpu_support import (
    GpuDecodeMediaSupport,
    GpuDecodeSupportReport,
    gpu_decode_support,
    supports_gpu_decode,
)
from .image_metrics import calculate_psnr


def _build_missing_class(class_name: str, install_hint: str, import_error: Exception):
    """Create a placeholder class that raises a clear dependency error when instantiated."""

    def _raise_missing(self, *args: Any, **kwargs: Any) -> None:
        raise ImportError(
            f"{class_name} is unavailable because an optional dependency is missing. "
            f"Install it with: {install_hint}"
        ) from import_error

    missing_class = type(class_name, (), {"__init__": _raise_missing})
    missing_class.__module__ = __name__
    return missing_class


try:
    from .ranged import RangedDataset, RangedFrameReader, RangedMp4FrameReader
    from .ranged_writer import RangedDatasetWriter, RangedNvencSettings
except Exception as exc:  # pragma: no cover - exercised in environments without pyavif
    RangedDataset = _build_missing_class("RangedDataset", "pip install pyavif", exc)
    RangedFrameReader = _build_missing_class("RangedFrameReader", "pip install pyavif", exc)
    RangedMp4FrameReader = _build_missing_class("RangedMp4FrameReader", "pip install pyavif", exc)
    RangedDatasetWriter = _build_missing_class("RangedDatasetWriter", "pip install pyavif", exc)
    RangedNvencSettings = _build_missing_class("RangedNvencSettings", "pip install pyavif", exc)

try:
    from .multivideo import MultiVideoDataset, MultiVideoFrameReader
    from .multivideo_writer import MultiVideoDatasetWriter
except Exception as exc:  # pragma: no cover - exercised in environments without av/ffmpeg
    MultiVideoDataset = _build_missing_class("MultiVideoDataset", "pip install av", exc)
    MultiVideoFrameReader = _build_missing_class("MultiVideoFrameReader", "pip install av", exc)
    MultiVideoDatasetWriter = _build_missing_class("MultiVideoDatasetWriter", "pip install av", exc)

try:
    from .multivideo_slicer import (
        MultiVideoSliceEligibility,
        MultiVideoSliceEligibilityMetadata,
        MultiVideoSliceError,
        MultiVideoSlicePlan,
        MultiVideoSliceRange,
        MultiVideoStreamEligibility,
        MultiVideoStreamSliceInfo,
        MultiVideoToRangedSlicer,
    )
except Exception as exc:  # pragma: no cover - exercised in environments without av/pyavif
    MultiVideoToRangedSlicer = _build_missing_class(
        "MultiVideoToRangedSlicer", "pip install av pyavif", exc
    )
    MultiVideoSliceEligibility = _build_missing_class(
        "MultiVideoSliceEligibility", "pip install av pyavif", exc
    )
    MultiVideoSliceEligibilityMetadata = _build_missing_class(
        "MultiVideoSliceEligibilityMetadata", "pip install av pyavif", exc
    )
    MultiVideoSliceError = _build_missing_class(
        "MultiVideoSliceError", "pip install av pyavif", exc
    )
    MultiVideoSlicePlan = _build_missing_class("MultiVideoSlicePlan", "pip install av pyavif", exc)
    MultiVideoSliceRange = _build_missing_class(
        "MultiVideoSliceRange", "pip install av pyavif", exc
    )
    MultiVideoStreamEligibility = _build_missing_class(
        "MultiVideoStreamEligibility", "pip install av pyavif", exc
    )
    MultiVideoStreamSliceInfo = _build_missing_class(
        "MultiVideoStreamSliceInfo", "pip install av pyavif", exc
    )

__all__ = [
    'Dataset',
    'FrameReader',
    'auto_detect_dataset',
    'LegacyDataset',
    'LegacyFrameReader',
    'RangedDataset',
    'RangedFrameReader',
    'RangedMp4FrameReader',
    'MultiVideoDataset',
    'MultiVideoFrameReader',
    'DatasetWriter',
    'RangedDatasetWriter',
    'RangedNvencSettings',
    'LegacyDatasetWriter',
    'MultiVideoDatasetWriter',
    'MultiVideoToRangedSlicer',
    'MultiVideoSliceEligibility',
    'MultiVideoSliceEligibilityMetadata',
    'MultiVideoSliceError',
    'MultiVideoSlicePlan',
    'MultiVideoSliceRange',
    'MultiVideoStreamEligibility',
    'MultiVideoStreamSliceInfo',
    'calculate_psnr',
    'GpuDecodeMediaSupport',
    'GpuDecodeSupportReport',
    'gpu_decode_support',
    'supports_gpu_decode',
    'gpu_enabled',
    'clear_gpu_override',
    'gpu_disabled',
    'gpu_enabled_override',
    'gpu_usage_allowed',
    'gpu_nvenc_disabled_globally',
    'nvdec_decode_allowed',
    'nvenc_encode_allowed',
    'nvdec_decoding_usable',
    'nvenc_encoding_usable',
    'pynvvideocodec_importable',
    'DatasetDownloader',
    'RangedDatasetDownloader',
    'LegacyDatasetDownloader',
    'MultiVideoDatasetDownloader',
    'infer_and_download_dataset',
    'register_downloader',
    'CloudStorageUrl',
    'CloudStorageProviderType',
]
