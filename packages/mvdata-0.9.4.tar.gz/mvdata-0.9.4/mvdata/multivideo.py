from typing import List, Tuple, Dict, Any, Optional
from pathlib import Path
import numpy as np
import re
import shutil
from PIL import Image

from .dataset_base import Dataset, Device, FrameReader
from .stash_utils import save_stash_image
from .video_stream_reader import ParallelVideoFrameReader

try:
    import av
    HAS_AV = True
except ImportError:
    HAS_AV = False


SUPPORTED_VIDEO_EXTENSIONS = ['.mov', '.mp4', '.avi']
SUPPORTED_CODECS = ['h264', 'hevc', 'av1']


def _is_content_packet(packet: Any) -> bool:
    return getattr(packet, "size", 0) > 0


def _count_visible_video_packets_if_discard_preroll_detected(
    container: Any,
    video_stream: Any,
    *,
    probe_packets: int = 64,
) -> Optional[int]:
    if not _may_include_discard_preroll(video_stream):
        return None

    demux = getattr(container, "demux", None)
    if not callable(demux):
        return None

    visible_packets = 0
    content_packets = 0
    found_discard = False
    packets = demux(video_stream)

    for packet in packets:
        if not _is_content_packet(packet):
            continue
        content_packets += 1
        if packet.is_discard:
            found_discard = True
            break
        visible_packets += 1
        if content_packets >= probe_packets:
            return None

    if not found_discard:
        return visible_packets

    for packet in packets:
        if _is_content_packet(packet) and not packet.is_discard:
            visible_packets += 1

    return visible_packets


def _may_include_discard_preroll(video_stream: Any) -> bool:
    if getattr(video_stream, "frames", 0) <= 0:
        return False
    codec_context = getattr(video_stream, "codec_context", None)
    if bool(getattr(codec_context, "has_b_frames", False)):
        return True
    start_time = getattr(video_stream, "start_time", None)
    return start_time not in (None, 0)


def _check_av_available():
    if not HAS_AV:
        raise ImportError(
            "PyAV is required for MultiVideo support. "
            "Install it with: pip install av"
        )


class MultiVideoDataset(Dataset):
    """Implementation for MultiVideo dataset convention (video files)."""

    def __init__(
        self,
        dataset_path: Path,
        max_workers: Optional[int] = None,
        respect_timestamps: bool = False,
        gpu_id: int = 0,
    ):
        """
        Initialize MultiVideo dataset.
        
        Args:
            dataset_path: Path to dataset root containing video files
            max_workers: Max per-reader decode workers for parallel video sessions
            respect_timestamps: If True, synchronize streams using embedded video timestamps
            gpu_id: GPU id for NVDEC decode when frame-index synchronization is used
        """
        _check_av_available()
        super().__init__(dataset_path, max_workers)
        
        self.respect_timestamps = respect_timestamps
        self._gpu_id = gpu_id
        
        self._stream_to_raw_name: Dict[int, str] = {}
        self._stream_to_video_path: Dict[int, Path] = {}
        self._initialized = False
        self._frame_ranges_cache: Optional[List[Tuple[int, int, Any]]] = None
        self._video_info_cache: Dict[int, Dict[str, Any]] = {}
        
    def _extract_first_digit_sequence(self, name: str) -> Optional[int]:
        """Extract first sequence of digits from a string."""
        match = re.search(r'\d+', name)
        if match:
            return int(match.group())
        return None
    
    def _extract_stream_id_from_filename(self, filename: str) -> Optional[int]:
        """Extract stream ID from a filename (implements base class method)."""
        return self._extract_first_digit_sequence(filename)
    
    def _get_stash_image_extensions(self) -> List[str]:
        """Get supported image extensions for stash frames."""
        return ['.png', '.tiff', '.tif', '.exr', '.jpg']
    
    def _find_stash_images_subfolder(self, directory: Path) -> Optional[str]:
        """
        Determine where images are stored in a stash frame directory.
        Checks in order: 'rgb', 'images', then root (None).
        """
        if (directory / 'rgb').exists() and (directory / 'rgb').is_dir():
            return 'rgb'
        elif (directory / 'images').exists() and (directory / 'images').is_dir():
            return 'images'
        else:
            return None
    
    def _discover_video_files(self) -> Dict[int, Path]:
        """
        Discover all video files in the dataset root.
        
        Returns:
            Dict mapping stream_id -> video file path
        """
        video_map = {}
        
        for item in self.dataset_path.iterdir():
            if item.name in ['stash', 'meta']:
                continue
            
            if item.is_file() and item.suffix.lower() in SUPPORTED_VIDEO_EXTENSIONS:
                stream_id = self._extract_first_digit_sequence(item.stem)
                if stream_id is not None:
                    video_map[stream_id] = item
        
        return video_map
    
    def _get_video_info(self, video_path: Path) -> Dict[str, Any]:
        """
        Get video metadata using PyAV.
        
        Returns:
            Dict with: frame_count, fps, duration, codec, width, height, bit_depth, start_time
        """
        from . import nvenc_codec

        container = av.open(str(video_path))
        try:
            video_stream = container.streams.video[0]
            
            frame_count = video_stream.frames
            visible_packet_count = _count_visible_video_packets_if_discard_preroll_detected(
                container,
                video_stream,
            )
            if visible_packet_count is not None and visible_packet_count > 0:
                frame_count = visible_packet_count
            elif frame_count == 0:
                seek = getattr(container, "seek", None)
                if callable(seek):
                    seek(0)
                frame_count = sum(1 for _ in container.decode(video=0))
            
            fps = float(video_stream.average_rate) if video_stream.average_rate else 30.0
            duration = float(video_stream.duration * video_stream.time_base) if video_stream.duration else 0.0
            
            start_time = 0.0
            if video_stream.start_time is not None:
                start_time = float(video_stream.start_time * video_stream.time_base)
            
            return {
                'frame_count': frame_count,
                'fps': fps,
                'duration': duration,
                'codec': video_stream.codec_context.name,
                'width': video_stream.width,
                'height': video_stream.height,
                'bit_depth': nvenc_codec.infer_video_bit_depth_from_stream(video_stream),
                'start_time': start_time,
                'time_base': video_stream.time_base
            }
        finally:
            container.close()
    
    def _initialize_structure(self):
        """
        Initialize dataset structure by scanning video files.
        This populates caches for stream IDs, video info, etc.
        """
        if self._initialized:
            return
        
        video_map = self._discover_video_files()
        
        if not video_map:
            raise ValueError(f"No video files found in {self.dataset_path}")
        
        for stream_id, video_path in video_map.items():
            self._stream_to_raw_name[stream_id] = video_path.name
            self._stream_to_video_path[stream_id] = video_path
            self._video_info_cache[stream_id] = self._get_video_info(video_path)
        
        self._stream_ids_cache = sorted(self._stream_to_raw_name.keys())
        self._initialized = True
    
    @property
    def stream_ids(self) -> List[int]:
        """
        Get list of all stream IDs available in the dataset.
        
        Returns:
            Sorted list of stream IDs
        """
        if not self._initialized:
            self._initialize_structure()
        return self._stream_ids_cache
    
    def stream_name(self, stream_id: int) -> str:
        """
        Get the raw dataset-specific name for a stream ID.
        
        Args:
            stream_id: Stream ID to get name for
            
        Returns:
            Raw stream name as it appears in the dataset (e.g., "001.mp4")
            
        Raises:
            ValueError: If stream_id is not found in dataset
        """
        if not self._initialized:
            self._initialize_structure()
        
        if stream_id not in self._stream_to_raw_name:
            raise ValueError(
                f"Stream ID {stream_id} not found in dataset. "
                f"Available IDs: {self._stream_ids_cache}"
            )
        
        return self._stream_to_raw_name[stream_id]
    
    def get_video_path(self, stream_id: int) -> Path:
        """
        Get the path to the video file for a stream.
        
        Args:
            stream_id: Stream ID
            
        Returns:
            Path to video file
        """
        if not self._initialized:
            self._initialize_structure()
        
        if stream_id not in self._stream_to_video_path:
            raise ValueError(f"Stream ID {stream_id} not found")
        
        return self._stream_to_video_path[stream_id]
    
    def get_video_info(self, stream_id: int) -> Dict[str, Any]:
        """
        Get video metadata for a stream.
        
        Args:
            stream_id: Stream ID
            
        Returns:
            Dict with video info (frame_count, fps, duration, codec, etc.)
        """
        if not self._initialized:
            self._initialize_structure()
        
        if stream_id not in self._video_info_cache:
            raise ValueError(f"Stream ID {stream_id} not found")
        
        return self._video_info_cache[stream_id].copy()
    
    def get_frame_ranges(self) -> List[Tuple[int, int, Any]]:
        """
        Get available frame ranges from video files.
        
        Returns:
            List of (start_frame, end_frame, metadata) tuples.
            For multivideo, this is typically one range covering all frames.
        """
        if self._frame_ranges_cache is not None:
            return self._frame_ranges_cache
        
        if not self._initialized:
            self._initialize_structure()
        
        if not self._video_info_cache:
            raise ValueError("No video files found in dataset")
        
        if self.respect_timestamps:
            start_times = []
            end_times = []
            for stream_id, info in self._video_info_cache.items():
                start_times.append(info['start_time'])
                end_times.append(info['start_time'] + info['duration'])
            
            global_start = max(start_times)
            global_end = min(end_times)
            
            if global_start >= global_end:
                raise ValueError(
                    "Videos do not have overlapping time ranges. "
                    "Cannot synchronize using timestamps."
                )
            
            reference_fps = list(self._video_info_cache.values())[0]['fps']
            total_frames = int((global_end - global_start) * reference_fps)
            
            metadata = {
                'sync_mode': 'timestamp',
                'global_start_time': global_start,
                'global_end_time': global_end,
                'reference_fps': reference_fps
            }
            
            self._frame_ranges_cache = [(0, total_frames - 1, metadata)]
        else:
            min_frames = min(info['frame_count'] for info in self._video_info_cache.values())
            
            metadata = {
                'sync_mode': 'frame_index',
                'min_frame_count': min_frames
            }
            
            self._frame_ranges_cache = [(0, min_frames - 1, metadata)]
        
        return self._frame_ranges_cache
    
    def create_frame_reader(self,
                          stream_ids: Optional[List[int]] = None,
                          start_frame: Optional[int] = None,
                          end_frame: Optional[int] = None,
                          max_workers: Optional[int] = None) -> FrameReader:
        """
        Create multivideo frame reader.
        
        Args:
            stream_ids: List of stream IDs to read, or None for all streams
            start_frame: Start frame number, or None for dataset start
            end_frame: End frame number, or None for dataset end
            max_workers: Max per-reader decode workers for parallel video sessions
            
        Returns:
            MultiVideoFrameReader instance
            
        Raises:
            ValueError: If requested frames or streams are not available
        """
        if not self._initialized:
            self._initialize_structure()
        
        if stream_ids is None:
            stream_ids = self._stream_ids_cache.copy()
        
        for stream_id in stream_ids:
            if stream_id not in self._stream_ids_cache:
                raise ValueError(
                    f"Stream ID {stream_id} not found in dataset. "
                    f"Available IDs: {self._stream_ids_cache}"
                )
        
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")
        
        dataset_start = ranges[0][0]
        dataset_end = ranges[0][1]
        metadata = ranges[0][2]
        
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end
        
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )
        
        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )
        
        video_paths = {sid: self._stream_to_video_path[sid] for sid in stream_ids}
        video_infos = {sid: self._video_info_cache[sid] for sid in stream_ids}
        
        decoder_workers = max_workers if max_workers is not None else self.max_workers
        if self.respect_timestamps:
            return _TimestampSyncMultiVideoFrameReader(
                video_paths,
                video_infos,
                start_frame,
                end_frame,
                self.respect_timestamps,
                metadata,
            )

        return MultiVideoFrameReader(
            video_paths,
            video_infos,
            start_frame,
            end_frame,
            decoder_max_workers=decoder_workers,
            gpu_id=self._gpu_id,
        )
    
    def _get_dataset_info(self) -> Dict[str, Any]:
        """Get dataset info including multivideo-specific details."""
        info = super()._get_dataset_info()

        if not self._initialized:
            self._initialize_structure()

        if self._video_info_cache:
            first_info = next(iter(self._video_info_cache.values()))
            info["codec"] = first_info.get("codec")
            info["fps"] = first_info.get("fps")
            info["resolution"] = (first_info.get("width"), first_info.get("height"))
            info["bit_depth"] = first_info.get("bit_depth")

        return info

    def _get_extra_repr_lines(self, info: Dict[str, Any]) -> List[str]:
        """Add multivideo-specific info to repr."""
        lines = []
        parts = []
        if info.get("codec"):
            parts.append(info["codec"])
        if info.get("fps"):
            parts.append(f"{info['fps']:.1f}fps")
        if info.get("resolution"):
            w, h = info["resolution"]
            parts.append(f"{w}x{h}")
        if info.get("bit_depth"):
            parts.append(f"{int(info['bit_depth'])}-bit")
        if parts:
            lines.append(f"  Video: {', '.join(parts)}")
        return lines

    def valid_file_hierarchy(self) -> List[str]:
        """
        Get all valid files in the dataset based on discovered structure.
        
        Returns:
            Sorted list of relative file paths (strings)
        """
        if not self._initialized:
            self._initialize_structure()
        
        valid_files = []
        
        for stream_id in self._stream_ids_cache:
            video_path = self._stream_to_video_path[stream_id]
            if not video_path.exists():
                raise FileNotFoundError(f"Expected video file not found: {video_path}")
            
            rel_path = video_path.relative_to(self.dataset_path)
            valid_files.append(str(rel_path))
        
        stash_frames = self.get_stash_frames()
        for frame_num, stream_map in stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(f"Expected stash image file not found: {img_path}")
                
                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))
        
        extra_stash_frames = self.get_extra_stash_frames()
        for folder_name, stream_map in extra_stash_frames:
            for stream_id, img_path in stream_map.items():
                if not img_path.exists():
                    raise FileNotFoundError(f"Expected extra stash image file not found: {img_path}")
                
                rel_path = img_path.relative_to(self.dataset_path)
                valid_files.append(str(rel_path))
        
        meta_files = self._get_meta_files()
        valid_files.extend(meta_files)
        
        return sorted(valid_files)
    
    def generate_stash_frames(self,
                             num_frames: int,
                             start_frame: Optional[int] = None,
                             end_frame: Optional[int] = None,
                             delete_existing_stash: bool = False,
                             overwrite_existing: bool = False,
                             verbose: bool = True) -> List[int]:
        """
        Generate stash frames by extracting frames from video files.
        
        Frames are saved as PNG files.
        
        Args:
            num_frames: Number of stash frames to generate
            start_frame: Start frame for selection range (None = dataset start)
            end_frame: End frame for selection range (None = dataset end)
            delete_existing_stash: If True, delete existing numbered stash frames
            overwrite_existing: If True, overwrite existing stash frames with same numbers
            verbose: If True, print progress information
            
        Returns:
            List of frame numbers that were converted to stash frames
        """
        if num_frames <= 0:
            raise ValueError(f"num_frames must be positive, got {num_frames}")
        
        if not self._initialized:
            self._initialize_structure()
        
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")
        
        dataset_start = ranges[0][0]
        dataset_end = ranges[0][1]
        
        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end
        
        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )
        
        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )
        
        total_frames = end_frame - start_frame + 1
        
        if num_frames > total_frames:
            raise ValueError(
                f"Requested {num_frames} stash frames, but only {total_frames} "
                f"frames available in range [{start_frame}, {end_frame}]"
            )
        
        if num_frames == total_frames:
            selected_frames = list(range(start_frame, end_frame + 1))
        else:
            indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
            selected_frames = [start_frame + i for i in indices]
        
        if verbose:
            print(f"Generating {num_frames} stash frames from multivideo dataset...")
            print(f"Selected frames: {selected_frames}")
        
        stash_dir = self.dataset_path / "stash"
        if delete_existing_stash:
            if verbose:
                print("Deleting existing numbered stash frames...")
            
            if stash_dir.exists():
                for item in stash_dir.iterdir():
                    if item.is_dir():
                        frame_num = self._extract_first_digit_sequence(item.name)
                        if frame_num is not None:
                            if verbose:
                                print(f"  Deleting stash/{item.name}")
                            shutil.rmtree(item)
            
            self._stash_frames_cache = None
        
        stash_dir.mkdir(exist_ok=True)
        
        if not overwrite_existing and not delete_existing_stash:
            existing_stash = self.get_stash_frames()
            existing_frame_nums = {fn for fn, _ in existing_stash}
            
            collisions = [fn for fn in selected_frames if fn in existing_frame_nums]
            if collisions:
                raise ValueError(
                    f"Stash frames already exist for frames {collisions}. "
                    f"Use overwrite_existing=True or delete_existing_stash=True to overwrite."
                )
        
        for frame_num in selected_frames:
            if verbose:
                print(f"Extracting frame {frame_num} to stash...")
            
            dest_dir = stash_dir / f"{frame_num:08d}"
            
            if dest_dir.exists():
                if overwrite_existing:
                    shutil.rmtree(dest_dir)
                else:
                    raise ValueError(
                        f"Stash frame {frame_num} already exists. "
                        f"Use overwrite_existing=True to overwrite."
                    )
            
            images_dir = dest_dir / "rgb"
            images_dir.mkdir(parents=True, exist_ok=True)
            
            reader = self.create_frame_reader(
                stream_ids=self.stream_ids,
                start_frame=frame_num,
                end_frame=frame_num
            )
            try:
                _, frame_data = reader.read_frame(frame_num)
            finally:
                reader.close()
            
            for stream_id in sorted(frame_data.keys()):
                array = frame_data[stream_id]
                
                output_name = f"{stream_id:03d}.png"
                output_path = images_dir / output_name
                save_stash_image(array, output_path)
        
        if verbose:
            print(f"Successfully generated {num_frames} stash frames")
        
        self._stash_frames_cache = None
        
        return selected_frames
    
    def validate(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Validate dataset against MultiVideo convention specification.
        
        Checks:
        - Video files exist and are readable
        - Codec compatibility (h264, h265/hevc, av1)
        - Stream consistency (resolution, fps across videos)
        - Stash frame structure
        - Meta folder structure
        
        Returns:
            Dictionary with validation results
        """
        errors = []
        warnings = []
        stats = {
            'total_streams': 0,
            'stream_ids': set(),
            'frame_count': 0,
            'resolutions': {},
            'codecs': {},
            'bit_depths': {},
            'bit_depth': None,
            'fps_values': {},
            'has_stash': False,
            'stash_frames': 0,
            'has_meta': False,
            'has_audio': False,
        }
        
        if verbose:
            print("Validating MultiVideo dataset...")
        
        if verbose:
            print("  Checking video files...")
        
        try:
            if not self._initialized:
                self._initialize_structure()
        except Exception as e:
            errors.append(f"Failed to initialize dataset: {e}")
            return {
                'valid': False,
                'errors': errors,
                'warnings': warnings,
                'stats': stats
            }
        
        stats['total_streams'] = len(self._stream_ids_cache)
        stats['stream_ids'] = set(self._stream_ids_cache)
        
        if verbose:
            print("  Checking video properties...")
        
        resolutions = {}
        fps_values = {}
        codecs = {}
        bit_depths = {}
        frame_counts = []
        
        for stream_id in self._stream_ids_cache:
            info = self._video_info_cache[stream_id]
            
            res = (info['width'], info['height'])
            resolutions[stream_id] = res
            fps_values[stream_id] = info['fps']
            codecs[stream_id] = info['codec']
            bit_depths[stream_id] = int(info.get('bit_depth', 8))
            frame_counts.append(info['frame_count'])
            
            if info['codec'] not in SUPPORTED_CODECS:
                warnings.append(
                    f"Stream {stream_id}: Codec '{info['codec']}' may not be fully supported. "
                    f"Recommended codecs: {SUPPORTED_CODECS}"
                )
        
        stats['resolutions'] = resolutions
        stats['fps_values'] = fps_values
        stats['codecs'] = codecs
        stats['bit_depths'] = bit_depths
        stats['bit_depth'] = max(bit_depths.values()) if bit_depths else None
        stats['frame_count'] = min(frame_counts) if frame_counts else 0
        
        unique_resolutions = set(resolutions.values())
        if len(unique_resolutions) > 1:
            warnings.append(
                f"Multiple resolutions detected: {unique_resolutions}. "
                f"This may cause issues during processing."
            )
        
        unique_fps = set(round(fps, 2) for fps in fps_values.values())
        if len(unique_fps) > 1:
            warnings.append(
                f"Multiple FPS values detected: {unique_fps}. "
                f"Videos may not be properly synchronized."
            )

        unique_bit_depths = set(bit_depths.values())
        if len(unique_bit_depths) > 1:
            warnings.append(
                f"Multiple bit depths detected: {unique_bit_depths}. "
                f"Decoded frame dtypes may vary across streams."
            )
        
        if verbose:
            print("  Checking stream naming convention...")
        
        for stream_id, stream_name in self._stream_to_raw_name.items():
            stem = Path(stream_name).stem
            if not re.match(r'^\d{3}$', stem):
                warnings.append(
                    f"Stream '{stream_name}' does not follow 3-digit zero-padding convention. "
                    f"Expected format: '###.ext' (e.g., '001.mp4')"
                )
        
        if verbose:
            print("  Checking stash folder...")
        
        stash_dir = self.dataset_path / "stash"
        if stash_dir.exists():
            stats['has_stash'] = True
            try:
                stash_frames = self.get_stash_frames()
                stats['stash_frames'] = len(stash_frames)
                
                for frame_num, stream_map in stash_frames:
                    stash_stream_ids = set(stream_map.keys())
                    if stash_stream_ids != stats['stream_ids']:
                        missing = stats['stream_ids'] - stash_stream_ids
                        extra = stash_stream_ids - stats['stream_ids']
                        
                        msg = f"Stream mismatch in stash frame {frame_num}:"
                        if missing:
                            msg += f" missing streams {sorted(missing)},"
                        if extra:
                            msg += f" extra streams {sorted(extra)},"
                        errors.append(msg.rstrip(','))
                
            except Exception as e:
                errors.append(f"Failed to validate stash folder: {e}")
        
        if verbose:
            print("  Checking meta folder...")
        
        meta_dir = self.dataset_path / "meta"
        if meta_dir.exists():
            stats['has_meta'] = True
            
            audio_extensions = {'.wav', '.mp3'}
            audio_files = []
            for ext in audio_extensions:
                audio_files.extend(meta_dir.rglob(f"*{ext}"))
            
            if audio_files:
                stats['has_audio'] = True
                if verbose:
                    print(f"    Found {len(audio_files)} audio file(s)")
        
        if verbose:
            print("  Checking for unexpected files...")
        
        valid_root_items = {'stash', 'meta'}
        
        for item in self.dataset_path.iterdir():
            if item.name.startswith('.'):
                continue
            
            if item.is_dir():
                if item.name not in valid_root_items:
                    errors.append(
                        f"Unexpected directory in dataset root: '{item.name}'. "
                        f"Expected only video files and 'stash'/'meta' directories."
                    )
            elif item.is_file():
                if item.suffix.lower() not in SUPPORTED_VIDEO_EXTENSIONS:
                    warnings.append(
                        f"Unexpected file in dataset root: '{item.name}'. "
                        f"Supported extensions: {SUPPORTED_VIDEO_EXTENSIONS}"
                    )
        
        is_valid = len(errors) == 0
        
        if verbose:
            print(f"\nValidation Summary:")
            print(f"  Streams: {stats['total_streams']} (IDs: {sorted(stats['stream_ids'])})")
            print(f"  Frame Count: {stats['frame_count']}")
            print(f"  Resolutions: {set(stats['resolutions'].values())}")
            print(f"  Codecs: {set(stats['codecs'].values())}")
            if stats['bit_depth']:
                print(f"  Bit Depth: {stats['bit_depth']}")
            if stats['has_stash']:
                print(f"  Stash Frames: {stats['stash_frames']}")
            if stats['has_audio']:
                print(f"  Audio: Yes")
            
            if warnings:
                print(f"\nWARN: {len(warnings)} warning(s)")
                for i, warning in enumerate(warnings, 1):
                    print(f"  {i}. {warning}")
            
            if errors:
                print(f"\nERROR: {len(errors)} error(s)")
                for i, error in enumerate(errors, 1):
                    print(f"  {i}. {error}")
                print("\nValidation FAILED")
            else:
                print("\nValidation PASSED - Dataset is valid")
        
        return {
            'valid': is_valid,
            'errors': errors,
            'warnings': warnings,
            'stats': stats
        }


class MultiVideoFrameReader(ParallelVideoFrameReader):
    """Frame reader for frame-index-synchronized multi-video datasets."""

    def __init__(
        self,
        video_paths: Dict[int, Path],
        video_infos: Dict[int, Dict[str, Any]],
        start_frame: int,
        end_frame: int,
        *,
        decoder_max_workers: int = 4,
        gpu_id: int = 0,
    ):
        """
        Initialize frame reader for frame-index synchronized multi-video datasets.
        """
        self.video_paths = video_paths
        self.video_infos = video_infos
        self.stream_ids = sorted(video_paths.keys())
        frame_counts = {sid: int(video_infos[sid]["frame_count"]) for sid in self.stream_ids}
        bit_depths = {sid: int(video_infos[sid].get("bit_depth", 8)) for sid in self.stream_ids}
        self._bit_depth = max(bit_depths.values(), default=8)
        super().__init__(
            stream_files=video_paths,
            frame_counts=frame_counts,
            start_frame=start_frame,
            end_frame=end_frame,
            decoder_max_workers=decoder_max_workers,
            gpu_id=gpu_id,
            bit_depths=bit_depths,
            index_resolver=lambda _sid, frame_index: frame_index,
        )

    def get_bit_depth(self) -> int:
        return self._bit_depth


class _TimestampSyncMultiVideoFrameReader(FrameReader):
    """Timestamp-synchronized multi-video reader using PyAV seek semantics."""

    def __init__(
        self,
        video_paths: Dict[int, Path],
        video_infos: Dict[int, Dict[str, Any]],
        start_frame: int,
        end_frame: int,
        respect_timestamps: bool = False,
        sync_metadata: Optional[Dict[str, Any]] = None,
    ):
        _check_av_available()
        super().__init__(start_frame, end_frame)

        self.video_paths = video_paths
        self.video_infos = video_infos
        self.stream_ids = sorted(video_paths.keys())
        self.respect_timestamps = respect_timestamps
        self.sync_metadata = sync_metadata or {}

        self._containers: Dict[int, av.container.InputContainer] = {}
        self._decoders: Dict[int, av.video.stream.VideoStream] = {}
        self._frame_generators: Dict[int, Any] = {}
        self._frame_indices: Dict[int, int] = {}

        self._init_containers()

    def _init_containers(self):
        """Initialize video containers and decoders for all streams."""
        for stream_id, video_path in self.video_paths.items():
            container = av.open(str(video_path))
            self._containers[stream_id] = container
            self._decoders[stream_id] = container.streams.video[0]
            self._frame_indices[stream_id] = -1
    
    def _seek_to_frame(self, stream_id: int, target_frame: int):
        """Seek to a specific frame in a video stream."""
        container = self._containers[stream_id]
        video_stream = self._decoders[stream_id]
        
        if self.respect_timestamps and 'global_start_time' in self.sync_metadata:
            reference_fps = self.sync_metadata['reference_fps']
            global_start = self.sync_metadata['global_start_time']
            
            target_time = global_start + (target_frame / reference_fps)
            target_pts = int(target_time / video_stream.time_base)
            
            container.seek(target_pts, stream=video_stream)
        else:
            fps = float(video_stream.average_rate) if video_stream.average_rate else 30.0
            target_time = target_frame / fps
            target_pts = int(target_time / video_stream.time_base)
            
            container.seek(target_pts, stream=video_stream)
        
        self._frame_generators[stream_id] = container.decode(video=0)
        self._frame_indices[stream_id] = target_frame - 1
    
    def _get_frame_at_index(self, stream_id: int, target_frame: int) -> np.ndarray:
        """Get frame at specific index from a stream."""
        from . import nvenc_codec

        current_idx = self._frame_indices[stream_id]
        
        if current_idx != target_frame - 1:
            self._seek_to_frame(stream_id, target_frame)
        
        if stream_id not in self._frame_generators:
            self._frame_generators[stream_id] = self._containers[stream_id].decode(video=0)
        
        try:
            frame = next(self._frame_generators[stream_id])
            self._frame_indices[stream_id] = target_frame
            bit_depth = int(self.video_infos[stream_id].get("bit_depth", 8))
            return nvenc_codec._pyav_frame_to_rgb(frame, bit_depth=bit_depth)
            
        except StopIteration:
            raise ValueError(f"No more frames available in stream {stream_id}")
    
    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        """Decode one timestamp-synchronised frame from every stream via PyAV.

        PyAV decode is CPU-only; ``device='cuda'`` H2D-copies each frame into
        a fresh ``cupy.ndarray``.
        """
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range "
                f"[{self.start_frame}, {self.end_frame}]"
            )

        result: Dict[int, Any] = {
            sid: self._get_frame_at_index(sid, frame_index) for sid in self.stream_ids
        }
        if device == "cuda":
            from . import nvenc_codec

            result = {
                sid: nvenc_codec.numpy_to_cupy_rgb(arr, cuda_stream=cuda_stream)
                for sid, arr in result.items()
            }
        return frame_index, result
    
    def prepare_next_frame(self):
        """
        Prepare for reading the next frame.
        Video containers handle buffering internally, so this is a no-op.
        """
        pass
    
    @property
    def supports_random_access(self) -> bool:
        """MultiVideo reader supports random access via seeking."""
        return True

    def close(self) -> None:
        for container in self._containers.values():
            try:
                container.close()
            except Exception:
                pass
        self._containers = {}
        self._frame_generators = {}
        self._frame_indices = {}

    def __del__(self):
        """Clean up video containers."""
        self.close()
