from abc import ABC, abstractmethod
from typing import Optional, Type, List, Tuple
from pathlib import Path
import re
from concurrent.futures import ThreadPoolExecutor

from .cloud_storage import (
    CloudStorageUrl,
    CloudStorageProvider,
)
from .utils import is_system_file
from .dataset_base import Dataset


class DatasetDownloader(ABC):
    """Base class for dataset downloaders from remote sources."""

    def __init__(self, source_uri: str):
        """
        Initialize downloader with source URI.

        Args:
            source_uri: Source URI (e.g., "s3://bucket/path/to/dataset" or "gs://bucket/path/to/dataset")
        """
        self.source_uri = source_uri
        self.parsed_source_uri = CloudStorageUrl(source_uri)

    @abstractmethod
    def infer_dataset_type(self) -> bool:
        """
        Check if this downloader can handle the dataset at source_uri.

        Returns:
            True if this downloader recognizes the dataset structure
        """
        pass

    @abstractmethod
    def download(
        self,
        local_path: Path,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        stream_ids: Optional[List[int]] = None,
        include_stash: bool = True,
        include_meta: bool = True,
        include_mvx: bool = True,
        max_workers: int = 8,
    ) -> Dataset:
        """
        Download dataset from remote source to local path.

        Args:
            local_path: Local directory to download to
            start_frame: Optional start frame for partial download
            end_frame: Optional end frame for partial download
            stream_ids: List of stream IDs to download, or None for all streams
            include_stash: Whether to download stash folder
            include_meta: Whether to download meta folder
            include_mvx: Whether to download mvx folder contents
            max_workers: Number of parallel download workers

        Returns:
            Dataset instance pointing to the downloaded data

        Raises:
            ValueError: If frame range is invalid
            RuntimeError: If download fails
        """
        pass

    def _download_files(
        self, files_to_download: List[Tuple[str, Path]], max_workers: int = 8, verbose: bool = True
    ) -> None:
        """
        Download multiple files in parallel.

        Args:
            files_to_download: List of (key, local_path) tuples
            max_workers: Number of parallel workers
            verbose: Whether to print progress
        """
        if not files_to_download:
            return

        if verbose:
            print(f"Downloading {len(files_to_download)} files...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for key, local_path in files_to_download:
                file_url = CloudStorageUrl.from_parts(
                    self.parsed_source_uri.schema, self.parsed_source_uri.bucket, key
                )
                future = executor.submit(CloudStorageProvider.download_file, file_url, local_path)
                futures.append((future, key))

            completed = 0
            for future, key in futures:
                try:
                    future.result()
                    completed += 1
                    if verbose and completed % 10 == 0:
                        print(f"  Downloaded {completed}/{len(files_to_download)} files...")
                except Exception as e:
                    raise RuntimeError(f"Failed to download {key}: {e}")

        if verbose:
            print(f"Download complete: {completed} files")

    def _extract_first_digit_sequence(self, name: str) -> Optional[int]:
        """Extract first sequence of digits from a string."""
        match = re.search(r"\d+", name)
        if match:
            return int(match.group())
        return None


RANGED_STREAM_EXTENSIONS = (".avif", ".mp4")


class RangedDatasetDownloader(DatasetDownloader):
    """Downloader for ranged dataset format."""

    def _parse_range_folder(self, folder_name: str) -> Optional[Tuple[int, int]]:
        """Parse range folder name to extract start and end frame numbers."""
        parts = folder_name.split("_")
        if len(parts) != 2:
            return None

        match_start = re.search(r"\d+", parts[0])
        match_end = re.search(r"\d+", parts[1])

        if match_start and match_end:
            return (int(match_start.group()), int(match_end.group()))

        return None

    def infer_dataset_type(self) -> bool:
        """Check if source contains ranged dataset structure."""
        try:
            _, common_prefixes = CloudStorageProvider.list_objects(
                self.parsed_source_uri, delimiter="/"
            )

            for prefix in common_prefixes:
                folder_name = prefix.rstrip("/").split("/")[-1]

                if folder_name in ["stash", "meta"]:
                    continue

                if self._parse_range_folder(folder_name) is not None:
                    return True

            return False
        except Exception:
            return False

    def _discover_ranges(self) -> List[Tuple[int, int, str]]:
        """
        Discover all range folders in the S3 dataset.

        Returns:
            List of (start_frame, end_frame, folder_name) sorted by start_frame
        """
        _, common_prefixes = CloudStorageProvider.list_objects(
            self.parsed_source_uri, delimiter="/"
        )

        ranges = []
        for prefix in common_prefixes:
            folder_name = prefix.rstrip("/").split("/")[-1]

            if folder_name in ["stash", "meta"]:
                continue

            range_info = self._parse_range_folder(folder_name)
            if range_info is not None:
                start, end = range_info
                ranges.append((start, end, folder_name))

        ranges.sort(key=lambda x: x[0])
        return ranges

    def download(
        self,
        local_path: Path,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        stream_ids: Optional[List[int]] = None,
        include_stash: bool = True,
        include_meta: bool = True,
        include_mvx: bool = True,
        max_workers: int = 8,
    ) -> Dataset:
        """Download ranged dataset with optional frame range filtering."""
        from .ranged import RangedDataset

        local_path = Path(local_path)
        local_path.mkdir(parents=True, exist_ok=True)

        print(f"Discovering dataset structure at {self.source_uri}...")
        ranges = self._discover_ranges()

        if not ranges:
            raise ValueError(f"No valid range directories found in {self.source_uri}")

        print(f"Streams to download: {stream_ids if stream_ids else 'all'}")

        dataset_start = ranges[0][0]
        dataset_end = ranges[-1][1]

        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        selected_ranges = []
        for range_start, range_end, folder_name in ranges:
            if range_end >= start_frame and range_start <= end_frame:
                selected_ranges.append((range_start, range_end, folder_name))

        if not selected_ranges:
            raise ValueError(
                f"No ranges found for requested frame range [{start_frame}, {end_frame}]"
            )

        print(f"Selected {len(selected_ranges)} range(s) to download:")
        for range_start, range_end, folder_name in selected_ranges:
            print(f"  - {folder_name}: frames [{range_start}, {range_end}]")

        stream_ids_set = set(stream_ids) if stream_ids else None
        files_to_download = []

        for range_start, range_end, folder_name in selected_ranges:
            range_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + folder_name,
            )
            objects, _ = CloudStorageProvider.list_objects(range_url)

            for obj_key in objects:
                rel_path = obj_key[len(self.parsed_source_uri.path) :]

                if not include_mvx and "/mvx/" in rel_path:
                    continue

                local_file = local_path / rel_path

                rel_path_wrapped = Path(rel_path)
                if is_system_file(rel_path_wrapped):
                    continue

                if rel_path_wrapped.suffix.lower() not in RANGED_STREAM_EXTENSIONS:
                    files_to_download.append((obj_key, local_file))
                    continue

                stream_id = self._extract_first_digit_sequence(rel_path_wrapped.stem)
                if stream_id is None or stream_ids_set is None or stream_id in stream_ids_set:
                    files_to_download.append((obj_key, local_file))

        if include_stash:
            stash_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "stash",
            )
            try:
                stash_objects, _ = CloudStorageProvider.list_objects(stash_url)
                stash_count = 0

                for obj_key in stash_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path
                    rel_path_wrapped = Path(rel_path)

                    if is_system_file(rel_path_wrapped):
                        continue

                    stream_id = self._extract_first_digit_sequence(rel_path_wrapped.stem)
                    if stream_id is None or stream_ids_set is None or stream_id in stream_ids_set:
                        files_to_download.append((obj_key, local_file))
                        stash_count += 1

                if stash_count > 0:
                    print(f"Including stash folder ({stash_count} files)")
            except Exception:
                pass

        if include_meta:
            meta_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "meta",
            )
            try:
                meta_objects, _ = CloudStorageProvider.list_objects(meta_url)

                for obj_key in meta_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path

                    if is_system_file(Path(rel_path)):
                        continue

                    files_to_download.append((obj_key, local_file))

                if meta_objects:
                    print(f"Including meta folder ({len(meta_objects)} files)")
            except Exception:
                pass

        self._download_files(files_to_download, max_workers=max_workers)

        return RangedDataset(local_path, max_workers=max_workers)


class LegacyDatasetDownloader(DatasetDownloader):
    """Downloader for per-frame (legacy) dataset format."""

    SUPPORTED_IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".tiff", ".tif", ".avif"]

    def infer_dataset_type(self) -> bool:
        """Check if source contains legacy per-frame dataset structure."""
        try:
            _, common_prefixes = CloudStorageProvider.list_objects(
                self.parsed_source_uri, delimiter="/"
            )

            for prefix in common_prefixes:
                folder_name = prefix.rstrip("/").split("/")[-1]

                if folder_name in ["stash", "meta"]:
                    continue

                if self._extract_first_digit_sequence(folder_name) is not None:
                    parts = folder_name.split("_")
                    if len(parts) == 2:
                        continue
                    return True

            return False
        except Exception:
            return False

    def _discover_frames(self) -> List[Tuple[int, str]]:
        """
        Discover all frame folders in the S3 dataset.

        Returns:
            List of (frame_number, folder_name) sorted by frame_number
        """
        _, common_prefixes = CloudStorageProvider.list_objects(
            self.parsed_source_uri, delimiter="/"
        )

        frames = []
        for prefix in common_prefixes:
            folder_name = prefix.rstrip("/").split("/")[-1]

            if folder_name in ["stash", "meta"]:
                continue

            frame_num = self._extract_first_digit_sequence(folder_name)
            if frame_num is not None:
                parts = folder_name.split("_")
                if len(parts) != 2:
                    frames.append((frame_num, folder_name))

        frames.sort(key=lambda x: x[0])
        return frames

    def download(
        self,
        local_path: Path,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        stream_ids: Optional[List[int]] = None,
        include_stash: bool = True,
        include_meta: bool = True,
        include_mvx: bool = True,
        max_workers: int = 8,
    ) -> Dataset:
        """Download legacy per-frame dataset with optional frame range filtering."""
        from .per_frame import LegacyDataset

        local_path = Path(local_path)
        local_path.mkdir(parents=True, exist_ok=True)

        print(f"Discovering dataset structure at {self.source_uri}...")
        frames = self._discover_frames()

        if not frames:
            raise ValueError(f"No valid frame directories found in {self.source_uri}")

        print(f"Streams to download: {stream_ids if stream_ids else 'all'}")

        dataset_start = frames[0][0]
        dataset_end = frames[-1][0]

        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        selected_frames = [
            (frame_num, folder_name)
            for frame_num, folder_name in frames
            if start_frame <= frame_num <= end_frame
        ]

        if not selected_frames:
            raise ValueError(f"No frames found for requested range [{start_frame}, {end_frame}]")

        print(
            f"Selected {len(selected_frames)} frame(s) to download: "
            f"[{selected_frames[0][0]}, {selected_frames[-1][0]}]"
        )

        stream_ids_set = set(stream_ids) if stream_ids else None
        files_to_download = []

        for frame_num, folder_name in selected_frames:
            frame_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + folder_name,
            )
            objects, _ = CloudStorageProvider.list_objects(frame_url)

            for obj_key in objects:
                rel_path = obj_key[len(self.parsed_source_uri.path) :]

                if not include_mvx and "/mvx/" in rel_path:
                    continue

                local_file = local_path / rel_path

                rel_path_wrapped = Path(rel_path)
                if is_system_file(rel_path_wrapped):
                    continue

                if rel_path_wrapped.suffix.lower() not in self.SUPPORTED_IMAGE_EXTENSIONS:
                    files_to_download.append((obj_key, local_file))
                    continue

                stream_id = self._extract_first_digit_sequence(rel_path_wrapped.stem)
                if stream_id is None or stream_ids_set is None or stream_id in stream_ids_set:
                    files_to_download.append((obj_key, local_file))

        if include_stash:
            stash_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "stash",
            )
            try:
                stash_objects, _ = CloudStorageProvider.list_objects(stash_url)
                stash_count = 0

                for obj_key in stash_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path
                    rel_path_wrapped = Path(rel_path)

                    if is_system_file(rel_path_wrapped):
                        continue

                    stream_id = self._extract_first_digit_sequence(rel_path_wrapped.stem)
                    if stream_id is None or stream_ids_set is None or stream_id in stream_ids_set:
                        files_to_download.append((obj_key, local_file))
                        stash_count += 1

                if stash_count > 0:
                    print(f"Including stash folder ({stash_count} files)")
            except Exception:
                pass

        if include_meta:
            meta_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "meta",
            )
            try:
                meta_objects, _ = CloudStorageProvider.list_objects(meta_url)

                for obj_key in meta_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path

                    if is_system_file(Path(rel_path)):
                        continue

                    files_to_download.append((obj_key, local_file))

                if meta_objects:
                    print(f"Including meta folder ({len(meta_objects)} files)")
            except Exception:
                pass

        self._download_files(files_to_download, max_workers=max_workers)

        return LegacyDataset(local_path, max_workers=max_workers)


class MultiVideoDatasetDownloader(DatasetDownloader):
    """Downloader for multi-video dataset format."""

    SUPPORTED_VIDEO_EXTENSIONS = [".mov", ".mp4", ".avi"]

    def infer_dataset_type(self) -> bool:
        """Check if source contains multi-video dataset structure (video files in root)."""
        try:
            objects, common_prefixes = CloudStorageProvider.list_objects(
                self.parsed_source_uri, delimiter="/"
            )

            # Check for video files in the root
            video_files = []
            for obj_key in objects:
                # Get relative path from prefix
                rel_path = (
                    obj_key[len(self.parsed_source_uri.path) :]
                    if self.parsed_source_uri.path
                    else obj_key
                )

                # Skip if it's in a subdirectory
                if "/" in rel_path:
                    continue

                # Check extension
                ext = "." + rel_path.rsplit(".", 1)[-1].lower() if "." in rel_path else ""
                if ext in self.SUPPORTED_VIDEO_EXTENSIONS:
                    video_files.append(rel_path)

            # Need at least one video file to be a multivideo dataset
            return len(video_files) > 0

        except Exception:
            return False

    def _discover_video_files(self) -> List[Tuple[int, str]]:
        """
        Discover all video files in the S3 dataset root.

        Returns:
            List of (stream_id, filename) sorted by stream_id
        """
        objects, _ = CloudStorageProvider.list_objects(self.parsed_source_uri, delimiter="/")

        videos = []
        for obj_key in objects:
            rel_path = (
                obj_key[len(self.parsed_source_uri.path) :]
                if self.parsed_source_uri.path
                else obj_key
            )

            # Skip if it's in a subdirectory
            if "/" in rel_path:
                continue

            # Check extension
            ext = "." + rel_path.rsplit(".", 1)[-1].lower() if "." in rel_path else ""
            if ext in self.SUPPORTED_VIDEO_EXTENSIONS:
                # Extract stream ID from filename
                stem = rel_path.rsplit(".", 1)[0]
                stream_id = self._extract_first_digit_sequence(stem)
                if stream_id is not None:
                    videos.append((stream_id, rel_path))

        videos.sort(key=lambda x: x[0])
        return videos

    def download(
        self,
        local_path: Path,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        stream_ids: Optional[List[int]] = None,
        include_stash: bool = True,
        include_meta: bool = True,
        include_mvx: bool = True,
        max_workers: int = 8,
    ) -> Dataset:
        """
        Download multi-video dataset.

        Note: For video datasets, frame range filtering is not applied during download
        since video files cannot be easily split. The entire video files are downloaded
        and frame range can be specified when reading.
        """
        from .multivideo import MultiVideoDataset

        local_path = Path(local_path)
        local_path.mkdir(parents=True, exist_ok=True)

        print(f"Discovering dataset structure at {self.source_uri}...")
        videos = self._discover_video_files()

        if not videos:
            raise ValueError(f"No video files found in {self.source_uri}")

        print(f"Streams to download: {stream_ids if stream_ids else 'all'}")

        stream_ids_set = set(stream_ids) if stream_ids else None

        selected_videos = []
        for vid_stream_id, filename in videos:
            if stream_ids_set is None:
                selected_videos.append((vid_stream_id, filename))
            elif vid_stream_id in stream_ids_set:
                selected_videos.append((vid_stream_id, filename))

        print(f"Found {len(selected_videos)} video stream(s) to download:")
        for vid_stream_id, filename in selected_videos:
            print(f"  - Stream {vid_stream_id}: {filename}")

        if start_frame is not None or end_frame is not None:
            print(
                f"Note: Frame range [{start_frame}, {end_frame}] will be applied during reading, "
                f"not during download. Full video files are downloaded."
            )

        files_to_download = []

        for stream_id, filename in selected_videos:
            obj_key = self.parsed_source_uri.path + filename
            local_file = local_path / filename
            files_to_download.append((obj_key, local_file))

        # Download stash if requested
        if include_stash:
            stash_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "stash",
            )
            try:
                stash_objects, _ = CloudStorageProvider.list_objects(stash_url)
                stash_count = 0

                for obj_key in stash_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path
                    rel_path_wrapped = Path(rel_path)

                    if is_system_file(rel_path_wrapped):
                        continue

                    stream_id = self._extract_first_digit_sequence(rel_path_wrapped.stem)
                    if stream_id is None or stream_ids_set is None or stream_id in stream_ids_set:
                        files_to_download.append((obj_key, local_file))
                        stash_count += 1

                if stash_count > 0:
                    print(f"Including stash folder ({stash_count} files)")
            except Exception:
                pass

        # Download meta if requested
        if include_meta:
            meta_url = CloudStorageUrl.from_parts(
                self.parsed_source_uri.schema,
                self.parsed_source_uri.bucket,
                self.parsed_source_uri.path + "meta",
            )
            try:
                meta_objects, _ = CloudStorageProvider.list_objects(meta_url)

                for obj_key in meta_objects:
                    rel_path = obj_key[len(self.parsed_source_uri.path) :]

                    if not include_mvx and "/mvx/" in rel_path:
                        continue

                    local_file = local_path / rel_path

                    if is_system_file(Path(rel_path)):
                        continue

                    files_to_download.append((obj_key, local_file))

                if meta_objects:
                    print(f"Including meta folder ({len(meta_objects)} files)")
            except Exception:
                pass

        self._download_files(files_to_download, max_workers=max_workers)

        return MultiVideoDataset(local_path, max_workers=max_workers)


_DOWNLOADER_REGISTRY: List[Type[DatasetDownloader]] = [
    RangedDatasetDownloader,
    LegacyDatasetDownloader,
    MultiVideoDatasetDownloader,
]


def infer_and_download_dataset(
    source_uri: str,
    local_path: Path,
    start_frame: Optional[int] = None,
    end_frame: Optional[int] = None,
    stream_ids: Optional[List[int]] = None,
    include_stash: bool = True,
    include_meta: bool = True,
    include_mvx: bool = True,
    max_workers: int = 8,
) -> Dataset:
    """
    Automatically infer dataset type and download from remote source.

    Args:
        source_uri: Source URI (e.g., "s3://bucket/path/to/dataset")
        local_path: Local directory to download to
        start_frame: Optional start frame for partial download
        end_frame: Optional end frame for partial download
        stream_ids: List of stream IDs to download, or None for all streams
        include_stash: Whether to download stash folder (default: True)
        include_meta: Whether to download meta folder (default: True)
        include_mvx: Whether to download mvx folder contents (default: True)
        max_workers: Number of parallel download workers

    Returns:
        Dataset instance pointing to the downloaded data

    Raises:
        ValueError: If dataset type cannot be inferred or frame range is invalid
        RuntimeError: If download fails
    """
    print(f"Inferring dataset type from {source_uri}...")

    for downloader_class in _DOWNLOADER_REGISTRY:
        downloader = downloader_class(source_uri)
        if downloader.infer_dataset_type():
            print(f"Detected dataset type: {downloader_class.__name__}")
            return downloader.download(
                local_path,
                start_frame=start_frame,
                end_frame=end_frame,
                stream_ids=stream_ids,
                include_stash=include_stash,
                include_meta=include_meta,
                include_mvx=include_mvx,
                max_workers=max_workers,
            )

    raise ValueError(
        f"Could not infer dataset type from {source_uri}. "
        f"Please ensure the dataset follows Gracia convention."
    )


def register_downloader(downloader_class: Type[DatasetDownloader]) -> None:
    """
    Register a custom dataset downloader.

    Args:
        downloader_class: Downloader class to register
    """
    if downloader_class not in _DOWNLOADER_REGISTRY:
        _DOWNLOADER_REGISTRY.insert(0, downloader_class)
