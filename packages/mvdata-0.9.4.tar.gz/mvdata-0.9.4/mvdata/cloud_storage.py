from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import List, Optional, Tuple
from urllib.parse import urlparse


class CloudStorageProviderType(Enum):
    AWS_S3 = 's3'
    GOOGLE_STORAGE = 'gs'


class CloudStorageUrl:
    def __init__(self, url: str):
        parsed = urlparse(url)
        if parsed.scheme not in ("s3", "gs"):
            raise ValueError(f"Invalid cloud URI scheme: {parsed.scheme}. Expected 's3' or 'gs'")

        if not parsed.netloc:
            raise ValueError(f"Invalid cloud URI: missing bucket name in {url}")

        self.schema: str = parsed.scheme
        self.bucket: str = parsed.netloc
        path = parsed.path.lstrip("/")
        if path and not path.endswith('/'):
            path += "/"
        self.path: str = path
        self.cloud: CloudStorageProviderType = (
            CloudStorageProviderType.AWS_S3
            if parsed.scheme == "s3"
            else CloudStorageProviderType.GOOGLE_STORAGE
        )

    @staticmethod
    def from_parts(schema: str, bucket: str, path: str = "") -> "CloudStorageUrl":
        path = path.lstrip("/")
        return CloudStorageUrl(f"{schema}://{bucket}/{path}")


class BaseCloudStorageProvider(ABC):
    @abstractmethod
    def list_objects(self, bucket: str, prefix: str, delimiter: Optional[str] = None) -> Tuple[List[str], List[str]]:
        pass

    @abstractmethod
    def download_file(self, bucket: str, key: str, local_path: Path) -> None:
        pass


class AwsS3CloudStorageProvider(BaseCloudStorageProvider):
    def __init__(self):
        try:
            import boto3
            from botocore.exceptions import ClientError, NoCredentialsError
        except ImportError as exc:
            raise ImportError(
                "boto3 is required for S3 support. "
                "Install it with: pip install mvdata[s3]"
            ) from exc

        self._ClientError = ClientError

        try:
            self._client = boto3.client("s3")
        except NoCredentialsError as exc:
            raise RuntimeError(
                "AWS credentials not found. Configure credentials using AWS CLI, "
                "environment variables, or IAM role."
            ) from exc

    def list_objects(self, bucket: str, prefix: str, delimiter: Optional[str] = None) -> Tuple[List[str], List[str]]:
        objects = []
        common_prefixes = []

        try:
            paginator = self._client.get_paginator("list_objects_v2")

            page_kwargs = {
                "Bucket": bucket,
                "Prefix": prefix,
            }
            if delimiter:
                page_kwargs["Delimiter"] = delimiter

            for page in paginator.paginate(**page_kwargs):
                if "Contents" in page:
                    objects.extend([obj["Key"] for obj in page["Contents"]])

                if delimiter and "CommonPrefixes" in page:
                    common_prefixes.extend([cp["Prefix"] for cp in page["CommonPrefixes"]])

            return objects, common_prefixes

        except self._ClientError as e:
            raise RuntimeError(f"S3 access error: {e}") from e

    def download_file(self, bucket: str, key: str, local_path: Path) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            self._client.download_file(bucket, key, str(local_path))
        except self._ClientError as e:
            raise RuntimeError(f"S3 download error for {key}: {e}") from e


class GoogleStorageCloudStorageProvider(BaseCloudStorageProvider):
    def __init__(self):
        try:
            from google.cloud import storage
        except ImportError as exc:
            raise ImportError(
                "google-cloud-storage is required for GCS support. "
                "Install it with: pip install mvdata[gcs]"
            ) from exc

        from google.api_core.exceptions import Forbidden, NotFound, GoogleAPICallError  # type: ignore[import-untyped]
        from google.auth.exceptions import DefaultCredentialsError  # type: ignore[import-untyped]

        self._Forbidden = Forbidden
        self._NotFound = NotFound
        self._GoogleAPICallError = GoogleAPICallError

        try:
            self._client = storage.Client()
        except DefaultCredentialsError as exc:
            raise RuntimeError(
                "GCS credentials not found. Configure credentials using "
                "GOOGLE_APPLICATION_CREDENTIALS environment variable, "
                "gcloud auth, or service account."
            ) from exc

    def list_objects(self, bucket: str, prefix: str, delimiter: Optional[str] = None) -> Tuple[List[str], List[str]]:
        objects = []
        common_prefixes = []

        try:
            bucket_obj = self._client.bucket(bucket)
            blobs = self._client.list_blobs(bucket_obj, prefix=prefix, delimiter=delimiter)

            for blob in blobs:
                objects.append(blob.name)

            if delimiter:
                common_prefixes = list(blobs.prefixes)

            return objects, common_prefixes

        except (self._Forbidden, self._NotFound) as e:
            raise RuntimeError(f"GCS access error: {e}") from e
        except self._GoogleAPICallError as e:
            raise RuntimeError(f"GCS access error: {e}") from e

    def download_file(self, bucket: str, key: str, local_path: Path) -> None:
        local_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            bucket_obj = self._client.bucket(bucket)
            blob = bucket_obj.blob(key)
            blob.download_to_filename(str(local_path))
        except (self._Forbidden, self._NotFound) as e:
            raise RuntimeError(f"GCS download error for {key}: {e}") from e
        except self._GoogleAPICallError as e:
            raise RuntimeError(f"GCS download error for {key}: {e}") from e


class CloudStorageProvider:
    _providers: dict[CloudStorageProviderType, BaseCloudStorageProvider] = {}

    @classmethod
    def _get_provider(cls, provider_type: CloudStorageProviderType) -> BaseCloudStorageProvider:
        if provider_type not in cls._providers:
            if provider_type == CloudStorageProviderType.AWS_S3:
                cls._providers[provider_type] = AwsS3CloudStorageProvider()
            else:
                cls._providers[provider_type] = GoogleStorageCloudStorageProvider()
        return cls._providers[provider_type]

    @classmethod
    def list_objects(cls, url: CloudStorageUrl, delimiter: Optional[str] = None) -> Tuple[List[str], List[str]]:
        """
        List objects in cloud storage bucket with given prefix.

        Args:
            url: CloudStorageUrl with schema, bucket, and path prefix
            delimiter: Optional delimiter for hierarchical listing (e.g., '/')

        Returns:
            Tuple of (object_keys, common_prefixes)
        """
        provider = cls._get_provider(url.cloud)
        return provider.list_objects(url.bucket, url.path, delimiter)

    @classmethod
    def download_file(cls, url: CloudStorageUrl, local_path: Path) -> None:
        """
        Download a single file from cloud storage.

        Args:
            url: CloudStorageUrl with schema, bucket, and path to the object
            local_path: Local file path to save to
        """
        key = url.path.rstrip("/")
        provider = cls._get_provider(url.cloud)
        provider.download_file(url.bucket, key, local_path)
