from abc import ABC, abstractmethod
import inspect
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple
import os
import re
import shutil

import numpy as np

from .utils import is_system_file

Device = Literal["cpu", "cuda"]


class Dataset(ABC):
    """Abstract base class for dataset implementations."""

    DEFAULT_STASH_IMAGE_EXTENSIONS = [".png", ".tiff", ".tif", ".exr", ".jpg", ".jpeg"]

    def __init__(self, dataset_path: Path, max_workers: Optional[int] = None):
        self.dataset_path = dataset_path
        self.normalization_constant = 2.0**8 - 1.0
        if max_workers is None:
            max_workers = os.cpu_count() or 1
        self.max_workers = max_workers  # For parallel decoding/loading operations
        self._stream_ids_cache: Optional[List[int]] = None
        self._stash_frames_cache: Optional[List[Tuple[int, Dict[int, Path]]]] = None
        self._extra_stash_frames_cache: Optional[List[Tuple[str, Dict[int, Path]]]] = None
        self._audio_files_cache: Optional[List[Path]] = None

    def _get_dataset_info(self) -> Dict[str, Any]:
        """
        Get dataset information for display. Subclasses can override to add
        type-specific info by calling super() and extending the dict.
        """
        ranges = self.get_frame_ranges()
        if ranges:
            start_frame = ranges[0][0]
            end_frame = ranges[-1][1]
            total_frames = sum(end - start + 1 for start, end, _ in ranges)
        else:
            start_frame = end_frame = total_frames = 0

        stash_frames = self.get_stash_frames()
        extra_stash = self.get_extra_stash_frames()

        return {
            "type": self.__class__.__name__,
            "path": str(self.dataset_path),
            "streams": len(self.stream_ids),
            "stream_ids": self.stream_ids,
            "frame_range": (start_frame, end_frame),
            "total_frames": total_frames,
            "has_stash": len(stash_frames) > 0,
            "stash_frames": len(stash_frames),
            "has_extra_stash": len(extra_stash) > 0,
            "extra_stash_count": len(extra_stash),
            "has_audio": self.has_audio,
        }

    def __repr__(self) -> str:
        """Return a formatted string representation of the dataset."""
        try:
            info = self._get_dataset_info()
        except Exception as e:
            return f"<{self.__class__.__name__} at {self.dataset_path} (error: {e})>"

        lines = [f"{info['type']}"]
        lines.append(f"  Path: {info['path']}")
        lines.append(f"  Streams: {info['streams']} {info['stream_ids']}")
        lines.append(f"  Frames: {info['frame_range'][0]}-{info['frame_range'][1]} ({info['total_frames']} total)")

        if info.get("has_stash"):
            stash_str = f"  Stash: {info['stash_frames']} frame(s)"
            if info.get("has_extra_stash"):
                stash_str += f" + {info['extra_stash_count']} extra"
            lines.append(stash_str)

        if info.get("has_audio"):
            lines.append("  Audio: Yes")

        extra_lines = self._get_extra_repr_lines(info)
        lines.extend(extra_lines)

        return "\n".join(lines)

    def _get_extra_repr_lines(self, info: Dict[str, Any]) -> List[str]:
        """Override in subclasses to add extra lines to repr. Returns list of strings."""
        return []

    @property
    @abstractmethod
    def stream_ids(self) -> List[int]:
        """
        Get list of all stream IDs available in the dataset.

        Stream IDs are integers extracted from the dataset structure.
        This should be cached after first call for performance.

        Returns:
            Sorted list of stream IDs
        """
        pass

    def stream_name(self, stream_id: int) -> str:
        """
        Get the raw dataset-specific name for a stream ID.

        This is the original name as it appears in the dataset,
        before conversion to intermediate format.

        Args:
            stream_id: Stream ID to get name for

        Returns:
            Raw stream name (e.g., "001", "cam_3", etc.)

        Raises:
            ValueError: If stream_id is not found in dataset
        """
        if stream_id not in self.stream_ids:
            raise ValueError(
                f"Stream ID {stream_id} not found in dataset. "
                f"Available IDs: {self.stream_ids}"
            )
        return str(stream_id)

    @property
    def num_streams(self) -> int:
        """
        Get the number of streams in the dataset.

        Returns:
            Number of streams
        """
        return len(self.stream_ids)

    @abstractmethod
    def get_frame_ranges(self) -> List[Tuple[int, int, Any]]:
        """
        Returns list of (start_frame, end_frame, range_metadata) tuples.

        range_metadata is dataset-specific data needed to access frames in this range.
        For AVIF_V1: this would be the range directory path
        For Legacy: this would be None (as all frames are in root)
        """
        pass

    @abstractmethod
    def create_frame_reader(
        self,
        stream_ids: Optional[List[int]] = None,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        max_workers: Optional[int] = None,
    ) -> "FrameReader":
        """
        Create a frame reader for the given streams and frame range.

        The dataset will automatically determine the appropriate internal
        metadata based on the requested frame range.

        Args:
            stream_ids: List of stream IDs to read, or None for all streams
            start_frame: Start frame number, or None for dataset start
            end_frame: End frame number, or None for dataset end
            max_workers: Number of parallel workers for decoding, or None to use dataset default

        Returns:
            FrameReader instance

        Raises:
            ValueError: If requested frames or streams are not available
        """
        pass

    def _get_stash_image_extensions(self) -> List[str]:
        """
        Get list of supported image extensions for stash frames.

        Returns:
            List of file extensions (e.g., ['.png', '.tiff', '.tif', '.exr'])
            Extensions should be lowercase and include the dot.
        """
        return self.DEFAULT_STASH_IMAGE_EXTENSIONS.copy()

    def _extract_stream_id_from_filename(self, filename: str) -> Optional[int]:
        """
        Extract stream ID from a filename.

        Args:
            filename: The filename (without extension)

        Returns:
            Stream ID as integer, or None if not found
        """
        match = re.search(r"\d+", filename)
        return int(match.group()) if match else None

    def _find_stash_images_subfolder(self, directory: Path) -> Optional[str]:
        """
        Determine where images are stored in a stash frame directory.

        Should check in order: 'rgb', 'images', then root (None).

        Args:
            directory: The stash frame directory to check

        Returns:
            'rgb', 'images', or None (for root)
        """
        for subfolder in ("rgb", "images"):
            images_dir = directory / subfolder
            if images_dir.exists() and images_dir.is_dir():
                if self._get_image_files_in_stash_dir(images_dir):
                    return subfolder
        return None

    def _get_image_files_in_stash_dir(self, directory: Path) -> List[Path]:
        """
        Get all supported stash image files in a directory.

        Args:
            directory: Directory to search for images

        Returns:
            List of image file paths
        """
        image_files = []
        extensions = self._get_stash_image_extensions()

        for item in directory.iterdir():
            if item.is_file() and item.suffix.lower() in extensions:
                image_files.append(item)

        return image_files

    def _build_stream_map_for_stash_dir(self, directory: Path) -> Dict[int, Path]:
        """
        Build a stream map for a stash frame directory.

        Args:
            directory: The directory containing stash images

        Returns:
            Dict mapping stream_id -> Path to image file
        """
        # Find where images are stored (rgb/images/root)
        subfolder = self._find_stash_images_subfolder(directory)
        if subfolder:
            images_dir = directory / subfolder
        else:
            images_dir = directory

        # Get all image files
        image_files = self._get_image_files_in_stash_dir(images_dir)

        # Build stream map
        stream_map = {}
        for img_path in image_files:
            stream_id = self._extract_stream_id_from_filename(img_path.stem)
            if stream_id is not None:
                stream_map[stream_id] = img_path

        return stream_map

    def get_stash_frames(self) -> List[Tuple[int, Dict[int, Path]]]:
        """
        Get list of stash frames available in the dataset.

        Stash frames are high-quality images (often high-bit-depth) used for
        alignment and high-quality single-frame trainings.

        Returns:
            List of (frame_number, stream_map) tuples where:
            - frame_number: The frame number (e.g., 0)
            - stream_map: Dict mapping stream_id -> Path to high-quality image file

        The images in stash may have different extensions than the main dataset
        (e.g., 16-bit PNG, 32-bit TIFF).
        """
        if self._stash_frames_cache is not None:
            return self._stash_frames_cache

        stash_dir = self.dataset_path / "stash"
        if not stash_dir.exists() or not stash_dir.is_dir():
            self._stash_frames_cache = []
            return self._stash_frames_cache

        stash_frames = []

        # Discover frame directories in stash (numbered directories)
        frame_dirs = []
        for item in stash_dir.iterdir():
            if item.is_dir():
                frame_num = self._extract_stream_id_from_filename(item.name)
                if frame_num is not None:
                    frame_dirs.append((frame_num, item))

        # Sort by frame number
        frame_dirs.sort(key=lambda x: x[0])

        # For each frame, discover streams
        for frame_num, frame_dir in frame_dirs:
            stream_map = self._build_stream_map_for_stash_dir(frame_dir)

            if stream_map:
                stash_frames.append((frame_num, stream_map))

        self._stash_frames_cache = stash_frames
        return self._stash_frames_cache

    def get_extra_stash_frames(self) -> List[Tuple[str, Dict[int, Path]]]:
        """
        Get list of extra (non-numbered) stash frames available in the dataset.

        Extra stash frames are stored in named subfolders within the stash directory
        (e.g., stash/reference/) and follow the same convention as the dataset.
        These are used for augmenting the dataset with reference frames that don't
        correspond to any specific frame number in the dataset.

        Returns:
            List of (folder_name, stream_map) tuples where:
            - folder_name: The name of the subfolder (e.g., "reference")
            - stream_map: Dict mapping stream_id -> Path to high-quality image file

        The images in extra stash frames may have different extensions than the
        main dataset (e.g., 16-bit PNG, 32-bit TIFF).
        """
        if self._extra_stash_frames_cache is not None:
            return self._extra_stash_frames_cache

        stash_dir = self.dataset_path / "stash"
        if not stash_dir.exists() or not stash_dir.is_dir():
            self._extra_stash_frames_cache = []
            return self._extra_stash_frames_cache

        extra_stash_frames = []

        # Discover non-numbered directories in stash
        extra_dirs = []
        for item in stash_dir.iterdir():
            if item.is_dir():
                # Check if it's NOT a numbered folder
                frame_num = self._extract_stream_id_from_filename(item.name)
                if frame_num is None:
                    extra_dirs.append(item)

        # Sort by folder name for consistency
        extra_dirs.sort(key=lambda x: x.name)

        # For each extra directory, discover streams
        for extra_dir in extra_dirs:
            stream_map = self._build_stream_map_for_stash_dir(extra_dir)

            if stream_map:
                extra_stash_frames.append((extra_dir.name, stream_map))

        self._extra_stash_frames_cache = extra_stash_frames
        return self._extra_stash_frames_cache

    @property
    def has_stash(self) -> bool:
        """
        Check if dataset has stash frames (numbered or extra).

        Returns:
            True if stash frames are available, False otherwise
        """
        return len(self.get_stash_frames()) > 0 or len(self.get_extra_stash_frames()) > 0

    @property
    def has_extra_stash(self) -> bool:
        """
        Check if dataset has extra (non-numbered) stash frames.

        Returns:
            True if extra stash frames are available, False otherwise
        """
        return len(self.get_extra_stash_frames()) > 0

    def get_audio_files(self) -> List[Path]:
        """
        Get list of all audio files in the dataset.

        Recursively searches the 'meta' folder for .wav and .mp3 files.
        All audio sources are assumed to be in sync with frame 0.

        Returns:
            List of Path objects pointing to audio files, sorted by name
        """
        if self._audio_files_cache is not None:
            return self._audio_files_cache

        audio_files = []
        meta_dir = self.dataset_path / "meta"

        if not meta_dir.exists():
            self._audio_files_cache = []
            return self._audio_files_cache

        # Use specific glob patterns instead of scanning all files
        for pattern in ["**/*.wav", "**/*.mp3", "**/*.WAV", "**/*.MP3"]:
            audio_files.extend(meta_dir.glob(pattern))

        # Sort for consistent ordering and remove duplicates
        audio_files = sorted(set(audio_files))
        self._audio_files_cache = audio_files
        return audio_files

    @property
    def has_audio(self) -> bool:
        """
        Check if dataset has audio files.

        Returns:
            True if audio files are available, False otherwise
        """
        return len(self.get_audio_files()) > 0

    def get_frame_source_paths(
        self, frame_idx: int, stream_ids: Optional[List[int]] = None
    ) -> Optional[Dict[int, Path]]:
        """
        Get source file paths for a frame, if available without decoding.

        This method enables agnostic stash generation: datasets that store
        frames as individual files (like Legacy) can return paths for direct
        copy, while datasets requiring decoding (like Ranged, MultiVideo)
        return None.

        Args:
            frame_idx: Frame index to get paths for
            stream_ids: Optional list of stream IDs to include (None = all)

        Returns:
            Dict mapping stream_id -> Path to source file, or None if
            decoding is required (e.g., video-based datasets)
        """
        return None

    @staticmethod
    def _remove_output_path(path: Path) -> None:
        if not path.exists():
            return
        if path.is_dir():
            shutil.rmtree(path)
            return
        path.unlink()

    def copy_meta_to(self, output_dataset_path: Path) -> bool:
        """
        Copy dataset metadata into ``output_dataset_path / "meta"``.

        The default implementation mirrors the on-disk ``meta/`` directory under
        ``dataset_path``. Datasets with virtual metadata or non-standard storage
        can override this hook.

        Returns:
            True if metadata was copied, False if no source meta directory exists.
        """
        input_meta = self.dataset_path / "meta"
        if not input_meta.exists() or not input_meta.is_dir():
            return False

        output_meta = Path(output_dataset_path) / "meta"
        self._remove_output_path(output_meta)
        print(f"Copying meta folder from {input_meta} to {output_meta}")
        shutil.copytree(input_meta, output_meta)
        return True

    def gpu_decode_support(self, gpu_id: int = 0):
        """Return a report describing whether this dataset can use GPU video decode."""
        from .gpu_support import gpu_decode_support

        return gpu_decode_support(self, gpu_id=gpu_id)

    def supports_gpu_decode(self, gpu_id: int = 0) -> bool:
        """Return ``True`` when the whole dataset can use GPU video decode right now."""
        return self.gpu_decode_support(gpu_id=gpu_id).fully_supported

    def delete_stash(self, verbose: bool = True) -> int:
        """
        Delete all numbered stash frames from the dataset.

        Preserves non-numbered directories (extra stash like 'reference').

        Args:
            verbose: If True, print deleted directories

        Returns:
            Number of deleted stash frame directories
        """
        from .stash_utils import delete_numbered_stash

        stash_dir = self.dataset_path / "stash"
        deleted = delete_numbered_stash(stash_dir, verbose=verbose)

        # Clear cache since stash has changed
        self._stash_frames_cache = None

        if verbose:
            print(f"Deleted {deleted} stash frame(s)")

        return deleted

    def regenerate_stash(
        self,
        num_frames: int = 10,
        source: Optional["Dataset"] = None,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        stream_ids: Optional[List[int]] = None,
        delete_existing: bool = True,
        verbose: bool = True,
    ) -> List[int]:
        """
        Regenerate stash frames, optionally from a different source dataset.

        This method allows regenerating stash independently from conversion,
        which is useful when:
        - You want to regenerate stash from the original high-quality source
          after a long conversion
        - You need different stash frames than originally generated
        - You want to update stash without re-converting the entire dataset

        Args:
            num_frames: Number of stash frames to generate
            source: Source dataset to generate from. If None, generates from self.
                   Using the original source (e.g., Legacy) preserves higher quality
                   and uses direct file copy when possible.
            start_frame: Start frame for selection (None = dataset start)
            end_frame: End frame for selection (None = dataset end)
            stream_ids: Stream IDs to include (None = all streams from self)
            delete_existing: If True, delete existing numbered stash first
            verbose: Print progress information

        Returns:
            List of frame numbers that were generated

        Example:
            # After conversion, regenerate stash from original source
            output_dataset.regenerate_stash(
                num_frames=10,
                source=input_dataset,  # Original Legacy dataset
            )

            # Or regenerate from self (decodes from converted format)
            output_dataset.regenerate_stash(num_frames=5)
        """
        from .stash_utils import (
            select_stash_frames,
            generate_stash_to_path,
            delete_numbered_stash,
        )

        # Use self as source if not specified
        if source is None:
            source = self

        # Get frame ranges from self (target dataset)
        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("Dataset has no frame ranges")

        dataset_start = ranges[0][0]
        dataset_end = ranges[-1][1]

        # Determine actual range
        actual_start = start_frame if start_frame is not None else dataset_start
        actual_end = end_frame if end_frame is not None else dataset_end

        # Validate range against self
        if actual_start < dataset_start or actual_end > dataset_end:
            raise ValueError(
                f"Requested range [{actual_start}, {actual_end}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        # If source is different, also validate against source range
        if source is not self:
            source_ranges = source.get_frame_ranges()
            if source_ranges:
                source_start = source_ranges[0][0]
                source_end = source_ranges[-1][1]
                if actual_start < source_start or actual_end > source_end:
                    raise ValueError(
                        f"Requested range [{actual_start}, {actual_end}] outside "
                        f"source dataset range [{source_start}, {source_end}]"
                    )

        # Use stream IDs from self if not specified
        if stream_ids is None:
            stream_ids = self.stream_ids

        if verbose:
            source_desc = "self" if source is self else f"source ({type(source).__name__})"
            print(f"Regenerating stash from {source_desc}")
            print(f"  Frame range: [{actual_start}, {actual_end}]")
            print(f"  Streams: {stream_ids}")
            print(f"  Requested frames: {num_frames}")

        # Delete existing stash if requested
        stash_dir = self.dataset_path / "stash"
        if delete_existing:
            deleted = delete_numbered_stash(stash_dir, verbose=verbose)
            if verbose and deleted > 0:
                print(f"  Deleted {deleted} existing stash frame(s)")

        # Select frames
        selected_frames = select_stash_frames(actual_start, actual_end, num_frames)
        if not selected_frames:
            if verbose:
                print("  No frames to generate")
            return []

        if verbose:
            print(f"  Selected frames: {selected_frames}")

        # Generate stash
        generated = generate_stash_to_path(
            source=source,
            target_stash_dir=stash_dir,
            frame_indices=selected_frames,
            stream_ids=stream_ids,
            output_frame_numbers=selected_frames,  # Same as input (absolute frame numbers)
            max_workers=self.max_workers,
            verbose=verbose,
        )

        # Clear cache since stash has changed
        self._stash_frames_cache = None

        if verbose:
            print(f"Generated {len(generated)} stash frame(s)")

        return generated

    def validate(self, verbose: bool = True) -> Dict[str, Any]:
        """
        Validate dataset structure and consistency.

        This method should check dataset-specific invariants such as:
        - Consistent structure across all frames
        - Same number of cameras/streams in each frame
        - Proper file naming conventions

        Args:
            verbose: If True, print detailed validation information

        Returns:
            Dictionary with validation results:
            - 'valid': bool indicating if dataset is valid
            - 'errors': list of error messages
            - 'warnings': list of warning messages
            - 'stats': dict with dataset statistics
        """
        # Default implementation - subclasses can override
        return {
            "valid": True,
            "errors": [],
            "warnings": ["Validation not implemented for this dataset type"],
            "stats": {},
        }

    def valid_file_hierarchy(self) -> List[str]:
        """
        Get all valid files in the dataset for uploading.

        Returns a sorted list of relative file paths based on the dataset's
        known structure. This ensures only files that constitute a valid dataset
        are included. The meta folder is included entirely (excluding system files).

        This validates that nothing has been changed since dataset initialization.

        Returns:
            Sorted list of relative file paths (strings)

        Raises:
            FileNotFoundError: If expected files are missing from the dataset
        """
        valid_files = []

        if not self.dataset_path.exists():
            return valid_files

        for item in self.dataset_path.rglob("*"):
            if not item.is_file():
                continue
            if is_system_file(item):
                continue
            rel_path = item.relative_to(self.dataset_path)
            valid_files.append(str(rel_path))

        return sorted(valid_files)

    def _get_meta_files(self) -> List[str]:
        """
        Get all valid files from the meta folder, excluding system files.

        Returns:
            List of relative file paths in the meta folder
        """
        meta_files = []
        meta_dir = self.dataset_path / "meta"

        if not meta_dir.exists():
            return meta_files

        # Recursively get all files in meta folder
        for item in meta_dir.rglob("*"):
            if not item.is_file():
                continue

            # Skip system files
            if is_system_file(item):
                continue

            # Get relative path from dataset root
            rel_path = item.relative_to(self.dataset_path)
            meta_files.append(str(rel_path))

        return meta_files

    def generate_stash_frames(
        self,
        num_frames: int,
        start_frame: Optional[int] = None,
        end_frame: Optional[int] = None,
        delete_existing_stash: bool = False,
        overwrite_existing: bool = False,
        verbose: bool = True,
    ) -> List[int]:
        """
        Generate stash frames from the dataset.

        Stash frames are high-quality reference images used for alignment
        and high-quality single-frame trainings.

        Args:
            num_frames: Number of stash frames to generate
            start_frame: Start frame for selection range (None = dataset start)
            end_frame: End frame for selection range (None = dataset end)
            delete_existing_stash: If True, delete existing numbered stash frames
                                   before generating new ones (does not delete extra_stash)
            overwrite_existing: If True, overwrite existing stash frames with same numbers.
                               If False and collision occurs, raises error.
            verbose: If True, print progress information

        Returns:
            List of frame numbers that were converted to stash frames

        Raises:
            ValueError: If parameters are invalid or if collision occurs with overwrite_existing=False
            FileNotFoundError: If requested frames don't exist in dataset
        """
        from .stash_utils import (
            SUPPORTED_STASH_EXTENSIONS,
            delete_numbered_stash,
            generate_stash_to_path,
            select_stash_frames,
        )

        if num_frames <= 0:
            raise ValueError(f"num_frames must be positive, got {num_frames}")

        ranges = self.get_frame_ranges()
        if not ranges:
            raise ValueError("No frame ranges available in dataset")

        dataset_start = ranges[0][0]
        dataset_end = ranges[-1][1]

        if start_frame is None:
            start_frame = dataset_start
        if end_frame is None:
            end_frame = dataset_end

        if start_frame < dataset_start or end_frame > dataset_end:
            raise ValueError(
                f"Requested range [{start_frame}, {end_frame}] outside "
                f"dataset range [{dataset_start}, {dataset_end}]"
            )

        if start_frame > end_frame:
            raise ValueError(
                f"Invalid range: start_frame ({start_frame}) > end_frame ({end_frame})"
            )

        total_frames = end_frame - start_frame + 1
        if num_frames > total_frames:
            raise ValueError(
                f"Requested {num_frames} stash frames, but only {total_frames} "
                f"frames available in range [{start_frame}, {end_frame}]"
            )

        selected_frames = select_stash_frames(start_frame, end_frame, num_frames)

        if verbose:
            print(f"Generating {num_frames} stash frames from {type(self).__name__}...")
            print(f"Selected frames: {selected_frames}")

        stash_dir = self.dataset_path / "stash"
        if delete_existing_stash:
            if verbose:
                print("Deleting existing numbered stash frames...")
            delete_numbered_stash(stash_dir, verbose=verbose)
            self._stash_frames_cache = None

        stash_dir.mkdir(exist_ok=True)

        if not overwrite_existing and not delete_existing_stash:
            existing_stash = self.get_stash_frames()
            existing_frame_nums = {fn for fn, _ in existing_stash}
            collisions = [fn for fn in selected_frames if fn in existing_frame_nums]
            if collisions:
                raise ValueError(
                    f"Stash frames already exist for frames {collisions}. "
                    "Use overwrite_existing=True or delete_existing_stash=True to overwrite."
                )

        for frame_num in selected_frames:
            dest_dir = stash_dir / f"{frame_num:08d}"
            if dest_dir.exists():
                if overwrite_existing:
                    shutil.rmtree(dest_dir)
                else:
                    raise ValueError(
                        f"Stash frame {frame_num} already exists. "
                        "Use overwrite_existing=True to overwrite."
                    )

        generated = generate_stash_to_path(
            source=self,
            target_stash_dir=stash_dir,
            frame_indices=selected_frames,
            stream_ids=self.stream_ids,
            output_frame_numbers=selected_frames,
            supported_exts=SUPPORTED_STASH_EXTENSIONS,
            max_workers=self.max_workers,
            verbose=verbose,
        )

        self._stash_frames_cache = None
        return generated


class FrameReader(ABC):
    """Abstract frame reader interface."""

    def __init__(self, start_frame: int, end_frame: int):
        self.start_frame = start_frame
        self.end_frame = end_frame
        self.current_frame = start_frame
        self.last_returned_index = -1

    @abstractmethod
    def read_frame(
        self,
        frame_index: int,
        *,
        device: Device = "cpu",
        cuda_stream: Optional[int] = None,
    ) -> Tuple[int, Dict[int, Any]]:
        """
        Read a specific frame.

        Args:
            frame_index: Absolute frame number.
            device: ``"cpu"`` (default) returns a dict of ``numpy.ndarray``.
                ``"cuda"`` returns dict of ``cupy.ndarray`` (dlpack-capable);
                readers that decode on the CPU H2D-copy to preserve a uniform
                GPU-resident return type.
            cuda_stream: Optional raw CUDA stream pointer
                (e.g. ``torch.cuda.current_stream().cuda_stream`` or
                ``cupy.cuda.Stream.null.ptr``) used to order the GPU→GPU or
                H2D copy. Ignored for ``device='cpu'``.

        Returns:
            Tuple of (frame_index, dict of stream_id -> HWC RGB array,
            uint8 or uint16 depending on the source bit depth).
        """
        pass

    def next_frame(
        self, *, device: Device = "cpu", cuda_stream: Optional[int] = None
    ) -> Tuple[int, Dict[int, Any]]:
        """Read the next frame in sequence (see :meth:`read_frame` for kwargs)."""
        if self.current_frame > self.end_frame:
            raise StopIteration("No more frames")

        result = self._call_read_frame(
            self.current_frame, device=device, cuda_stream=cuda_stream
        )
        self.last_returned_index = self.current_frame - self.start_frame
        self.current_frame += 1
        return result

    def _call_read_frame(
        self,
        frame_index: int,
        *,
        device: Device,
        cuda_stream: Optional[int],
    ) -> Tuple[int, Dict[int, Any]]:
        try:
            params = inspect.signature(self.read_frame).parameters
        except (TypeError, ValueError):
            params = {}

        accepts_transport_kwargs = (
            ("device" in params and "cuda_stream" in params)
            or any(
                param.kind == inspect.Parameter.VAR_KEYWORD
                for param in params.values()
            )
        )
        if accepts_transport_kwargs:
            return self.read_frame(frame_index, device=device, cuda_stream=cuda_stream)
        if device != "cpu" or cuda_stream is not None:
            raise TypeError(
                f"{self.__class__.__name__}.read_frame() does not accept device/cuda_stream; "
                "override it with the newer signature to enable CUDA reads."
            )
        return self.read_frame(frame_index)

    @abstractmethod
    def prepare_next_frame(self):
        """
        Prepare for reading the next frame (for performance optimization).
        This method can be used to start loading the next frame in advance.
        """
        pass

    @property
    @abstractmethod
    def supports_random_access(self) -> bool:
        """Whether this reader supports random frame access."""
        pass

    def __iter__(self):
        """Iterator interface."""
        self.current_frame = self.start_frame
        return self

    def __next__(self) -> Tuple[int, Dict[int, np.ndarray]]:
        """Iterator interface."""
        return self.next_frame()

    def close(self) -> None:
        """
        Release any resources held by the reader.

        Subclasses may override if they manage executors, file handles, etc.
        """
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


def auto_detect_dataset(
    dataset_path: Path, max_workers: Optional[int] = None, respect_timestamps: bool = False
) -> Dataset:
    """
    Auto-detect dataset type and return appropriate Dataset instance.

    Detection logic:
    - If dataset has video files (.mov, .mp4, .avi) in root, it's MultiVideoDataset
    - If dataset has range folders (e.g., 00000000_00000499), it's RangedDataset
    - Otherwise, it's LegacyDataset (per-frame format)

    Args:
        dataset_path: Path to the dataset
        max_workers: Number of parallel workers for decoding
        respect_timestamps: For MultiVideoDataset, whether to use timestamp-based sync

    Returns:
        Dataset instance (MultiVideoDataset, RangedDataset, or LegacyDataset)

    Raises:
        ValueError: If dataset type cannot be detected
    """
    from .per_frame import LegacyDataset

    try:
        from .multivideo import MultiVideoDataset, SUPPORTED_VIDEO_EXTENSIONS
    except ImportError as exc:
        MultiVideoDataset = None
        SUPPORTED_VIDEO_EXTENSIONS = [".mov", ".mp4", ".avi"]
        multivideo_import_error = exc
    else:
        multivideo_import_error = None

    dataset_path = Path(dataset_path)

    if not dataset_path.exists():
        raise ValueError(f"Dataset path does not exist: {dataset_path}")

    if not dataset_path.is_dir():
        raise ValueError(f"Dataset path is not a directory: {dataset_path}")

    # Check for video files in root (MultiVideoDataset)
    video_files = []
    for item in dataset_path.iterdir():
        if item.is_file() and item.suffix.lower() in SUPPORTED_VIDEO_EXTENSIONS:
            video_files.append(item)

    if video_files:
        if MultiVideoDataset is None:
            raise ImportError(
                "Detected a MultiVideo dataset, but MultiVideo support is unavailable. "
                "Install with: pip install av"
            ) from multivideo_import_error
        return MultiVideoDataset(
            dataset_path, max_workers=max_workers, respect_timestamps=respect_timestamps
        )

    # Check for range folders (format: 00000000_00000499)
    has_range_folders = False
    for item in dataset_path.iterdir():
        if item.is_dir() and item.name not in ["stash", "meta"]:
            # Try to parse as range folder
            parts = item.name.split("_")
            if len(parts) == 2:
                try:
                    int(parts[0])
                    int(parts[1])
                    has_range_folders = True
                    break
                except ValueError:
                    pass

    if has_range_folders:
        try:
            from .ranged import RangedDataset
        except ImportError as exc:
            raise ImportError(
                "Detected a Ranged dataset, but Ranged support is unavailable. "
                "Install with: pip install pyavif"
            ) from exc
        return RangedDataset(dataset_path, max_workers=max_workers)
    else:
        return LegacyDataset(dataset_path, max_workers=max_workers)
