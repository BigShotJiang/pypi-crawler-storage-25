"""Helpers for inspecting dataset GPU decode compatibility."""

from __future__ import annotations

from dataclasses import dataclass
from os import PathLike
from pathlib import Path
from typing import Any

from .dataset_base import Dataset, auto_detect_dataset
from . import gpu_policy, nvenc_codec


def _path_to_str(path: Path | None) -> str | None:
    if path is None:
        return None
    return str(path)


def _policy_block_reason() -> str:
    return (
        "GPU decode is disabled by policy "
        "(MVDATA_DISABLE_GPU / MVDATA_DISABLE_NVDEC_DECODE or gpu_enabled(False))."
    )


def _runtime_block_reason() -> str:
    return "PyNvVideoCodec is not installed, so NVDEC decode is unavailable."


@dataclass(frozen=True)
class GpuDecodeMediaSupport:
    path: Path
    container: str
    stream_id: int | None = None
    range_name: str | None = None
    codec: str | None = None
    chroma_subsampling: str | None = None
    bitdepth: int | None = None
    width: int | None = None
    height: int | None = None
    hardware_compatible: bool | None = None
    will_use_gpu_decode: bool = False
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "container": self.container,
            "stream_id": self.stream_id,
            "range_name": self.range_name,
            "codec": self.codec,
            "chroma_subsampling": self.chroma_subsampling,
            "bitdepth": self.bitdepth,
            "width": self.width,
            "height": self.height,
            "hardware_compatible": self.hardware_compatible,
            "will_use_gpu_decode": self.will_use_gpu_decode,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class GpuDecodeSupportReport:
    dataset_type: str
    dataset_path: Path
    gpu_id: int
    policy_allows_gpu: bool
    pynvvideocodec_importable: bool
    nvdec_usable_now: bool
    items: tuple[GpuDecodeMediaSupport, ...]
    note: str | None = None

    @property
    def media_count(self) -> int:
        return len(self.items)

    @property
    def supported_media_count(self) -> int:
        return sum(1 for item in self.items if item.will_use_gpu_decode)

    @property
    def fully_supported(self) -> bool:
        return self.media_count > 0 and self.supports_gpu_decode(require_all=True)

    @property
    def partially_supported(self) -> bool:
        return self.media_count > 0 and self.supported_media_count > 0 and not self.fully_supported

    @property
    def fully_hardware_compatible(self) -> bool | None:
        return self.is_hardware_compatible(require_all=True)

    @property
    def partially_hardware_compatible(self) -> bool | None:
        return self.is_hardware_compatible(require_all=False)

    def supports_gpu_decode(self, *, require_all: bool = True) -> bool:
        if not self.items:
            return False
        if require_all:
            return all(item.will_use_gpu_decode for item in self.items)
        return any(item.will_use_gpu_decode for item in self.items)

    def is_hardware_compatible(self, *, require_all: bool = True) -> bool | None:
        if not self.items:
            return False
        known = [item.hardware_compatible for item in self.items]
        if any(value is None for value in known):
            return None
        if require_all:
            return all(bool(value) for value in known)
        return any(bool(value) for value in known)

    def to_dict(self) -> dict[str, Any]:
        return {
            "dataset_type": self.dataset_type,
            "dataset_path": str(self.dataset_path),
            "gpu_id": self.gpu_id,
            "policy_allows_gpu": self.policy_allows_gpu,
            "pynvvideocodec_importable": self.pynvvideocodec_importable,
            "nvdec_usable_now": self.nvdec_usable_now,
            "media_count": self.media_count,
            "supported_media_count": self.supported_media_count,
            "fully_supported": self.fully_supported,
            "partially_supported": self.partially_supported,
            "fully_hardware_compatible": self.fully_hardware_compatible,
            "partially_hardware_compatible": self.partially_hardware_compatible,
            "note": self.note,
            "items": [item.to_dict() for item in self.items],
        }


def _coerce_dataset(
    dataset_or_path: Dataset | str | PathLike[str],
    *,
    respect_timestamps: bool = False,
) -> Dataset:
    if isinstance(dataset_or_path, Dataset):
        return dataset_or_path
    return auto_detect_dataset(Path(dataset_or_path), respect_timestamps=respect_timestamps)


def _inspect_video_media(
    path: Path,
    *,
    stream_id: int | None,
    range_name: str | None,
    gpu_id: int,
    nvc: Any,
    policy_allows_gpu: bool,
    metadata_hint: dict[str, Any] | None = None,
) -> GpuDecodeMediaSupport:
    container = path.suffix.lower().lstrip(".")
    codec = None
    chroma_subsampling = None
    bitdepth = None
    width = None
    height = None

    if metadata_hint:
        codec_hint = metadata_hint.get("codec")
        if isinstance(codec_hint, str):
            codec = nvenc_codec.normalize_codec_name(codec_hint)
        width = metadata_hint.get("width")
        height = metadata_hint.get("height")
        bitdepth_hint = metadata_hint.get("bit_depth")
        if isinstance(bitdepth_hint, int):
            bitdepth = bitdepth_hint

    if nvc is None:
        reason = _policy_block_reason() if not policy_allows_gpu else _runtime_block_reason()
        return GpuDecodeMediaSupport(
            path=path,
            container=container,
            stream_id=stream_id,
            range_name=range_name,
            codec=codec,
            chroma_subsampling=chroma_subsampling,
            bitdepth=bitdepth,
            width=width,
            height=height,
            hardware_compatible=None,
            will_use_gpu_decode=False,
            reason=reason,
        )

    meta = nvenc_codec.probe_video_stream_metadata(nvc, path)
    codec = meta.get("codec")
    chroma_subsampling = meta.get("chroma_subsampling")
    bitdepth = meta.get("bitdepth")
    width = meta.get("width")
    height = meta.get("height")

    issue = nvenc_codec.nvdec_decode_compatibility_issue_for_path(nvc, path, gpu_id)
    hardware_compatible = issue is None
    if not policy_allows_gpu:
        reason = _policy_block_reason()
        will_use_gpu_decode = False
    elif issue is not None:
        reason = issue
        will_use_gpu_decode = False
    else:
        reason = None
        will_use_gpu_decode = True

    return GpuDecodeMediaSupport(
        path=path,
        container=container,
        stream_id=stream_id,
        range_name=range_name,
        codec=codec,
        chroma_subsampling=chroma_subsampling,
        bitdepth=bitdepth,
        width=width,
        height=height,
        hardware_compatible=hardware_compatible,
        will_use_gpu_decode=will_use_gpu_decode,
        reason=reason,
    )


def _inspect_non_nvdec_media(
    path: Path,
    *,
    stream_id: int | None,
    range_name: str | None,
    reason: str,
) -> GpuDecodeMediaSupport:
    return GpuDecodeMediaSupport(
        path=path,
        container=path.suffix.lower().lstrip("."),
        stream_id=stream_id,
        range_name=range_name,
        hardware_compatible=False,
        will_use_gpu_decode=False,
        reason=reason,
    )


def _sort_items(items: list[GpuDecodeMediaSupport]) -> tuple[GpuDecodeMediaSupport, ...]:
    return tuple(
        sorted(
            items,
            key=lambda item: (
                item.range_name or "",
                -1 if item.stream_id is None else item.stream_id,
                str(item.path),
            ),
        )
    )


def _report_for_legacy(dataset: Dataset, *, gpu_id: int) -> GpuDecodeSupportReport:
    return GpuDecodeSupportReport(
        dataset_type=type(dataset).__name__,
        dataset_path=dataset.dataset_path,
        gpu_id=gpu_id,
        policy_allows_gpu=gpu_policy.nvdec_decode_allowed(),
        pynvvideocodec_importable=gpu_policy.pynvvideocodec_importable(),
        nvdec_usable_now=gpu_policy.nvdec_decoding_usable(),
        items=(),
        note="Legacy datasets store individual image files; NVDEC video decode is not applicable.",
    )


def _report_for_ranged(dataset: Dataset, *, gpu_id: int) -> GpuDecodeSupportReport:
    policy_allows_gpu = gpu_policy.nvdec_decode_allowed()
    pynvc_ok = gpu_policy.pynvvideocodec_importable()
    nvc = nvenc_codec.try_import_pynvvideocodec() if pynvc_ok else None
    items: list[GpuDecodeMediaSupport] = []

    dataset.stream_ids
    subfolder = getattr(dataset, "_stream_subfolder", None)
    for _, _, range_dir in dataset.get_frame_ranges():
        stream_map = dataset._get_streams_from_range(range_dir, subfolder=subfolder)
        for stream_id, path in sorted(stream_map.items()):
            if path.suffix.lower() == ".mp4":
                items.append(
                    _inspect_video_media(
                        path,
                        stream_id=stream_id,
                        range_name=range_dir.name,
                        gpu_id=gpu_id,
                        nvc=nvc,
                        policy_allows_gpu=policy_allows_gpu,
                    )
                )
                continue
            items.append(
                _inspect_non_nvdec_media(
                    path,
                    stream_id=stream_id,
                    range_name=range_dir.name,
                    reason="AVIF batches do not use NVDEC; they decode on the CPU/libavif path.",
                )
            )

    return GpuDecodeSupportReport(
        dataset_type=type(dataset).__name__,
        dataset_path=dataset.dataset_path,
        gpu_id=gpu_id,
        policy_allows_gpu=policy_allows_gpu,
        pynvvideocodec_importable=pynvc_ok,
        nvdec_usable_now=gpu_policy.nvdec_decoding_usable(),
        items=_sort_items(items),
    )


def _report_for_multivideo(dataset: Dataset, *, gpu_id: int) -> GpuDecodeSupportReport:
    policy_allows_gpu = gpu_policy.nvdec_decode_allowed()
    pynvc_ok = gpu_policy.pynvvideocodec_importable()
    nvc = nvenc_codec.try_import_pynvvideocodec() if pynvc_ok else None
    items: list[GpuDecodeMediaSupport] = []

    for stream_id in dataset.stream_ids:
        video_path = dataset.get_video_path(stream_id)
        info = dataset.get_video_info(stream_id)
        items.append(
            _inspect_video_media(
                video_path,
                stream_id=stream_id,
                range_name=None,
                gpu_id=gpu_id,
                nvc=nvc,
                policy_allows_gpu=policy_allows_gpu,
                metadata_hint=info,
            )
        )

    return GpuDecodeSupportReport(
        dataset_type=type(dataset).__name__,
        dataset_path=dataset.dataset_path,
        gpu_id=gpu_id,
        policy_allows_gpu=policy_allows_gpu,
        pynvvideocodec_importable=pynvc_ok,
        nvdec_usable_now=gpu_policy.nvdec_decoding_usable(),
        items=_sort_items(items),
    )


def gpu_decode_support(
    dataset_or_path: Dataset | str | PathLike[str],
    *,
    gpu_id: int = 0,
    respect_timestamps: bool = False,
) -> GpuDecodeSupportReport:
    dataset = _coerce_dataset(dataset_or_path, respect_timestamps=respect_timestamps)

    try:
        from .per_frame import LegacyDataset
    except Exception:
        LegacyDataset = ()

    try:
        from .ranged import RangedDataset
    except Exception:
        RangedDataset = ()

    try:
        from .multivideo import MultiVideoDataset
    except Exception:
        MultiVideoDataset = ()

    if isinstance(dataset, LegacyDataset):
        return _report_for_legacy(dataset, gpu_id=gpu_id)
    if isinstance(dataset, RangedDataset):
        return _report_for_ranged(dataset, gpu_id=gpu_id)
    if isinstance(dataset, MultiVideoDataset):
        return _report_for_multivideo(dataset, gpu_id=gpu_id)
    raise TypeError(f"Unsupported dataset type for GPU decode support: {type(dataset)!r}")


def supports_gpu_decode(
    dataset_or_path: Dataset | str | PathLike[str],
    *,
    gpu_id: int = 0,
    respect_timestamps: bool = False,
) -> bool:
    return gpu_decode_support(
        dataset_or_path,
        gpu_id=gpu_id,
        respect_timestamps=respect_timestamps,
    ).fully_supported
