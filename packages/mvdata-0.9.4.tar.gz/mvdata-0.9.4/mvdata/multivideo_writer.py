from typing import Optional, List, Dict, Any
from pathlib import Path
from fractions import Fraction
import shutil
import numpy as np

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
    def tqdm(iterable, **kwargs):
        return iterable

try:
    import av
    HAS_AV = True
except ImportError:
    HAS_AV = False

from .writer_base import DatasetWriter
from .dataset_base import Dataset
from .multivideo import MultiVideoDataset


def _check_av_available():
    if not HAS_AV:
        raise ImportError(
            "PyAV is required for MultiVideo support. "
            "Install it with: pip install av"
        )


SUPPORTED_CODECS = {
    'h264': {'codec': 'libx264', 'pix_fmt': 'yuv420p'},
    'h265': {'codec': 'libx265', 'pix_fmt': 'yuv420p'},
    'hevc': {'codec': 'libx265', 'pix_fmt': 'yuv420p'},
    'av1': {'codec': 'libsvtav1', 'pix_fmt': 'yuv420p'},
}

SUPPORTED_CONTAINERS = {
    'mp4': 'mp4',
    'mov': 'mov',
    'avi': 'avi',
}


class MultiVideoDatasetWriter(DatasetWriter):
    """Writer for MultiVideo dataset convention (video files)."""
    
    def __init__(self,
                 input_dataset: Dataset,
                 output_path: Path,
                 copy_meta: bool = True,
                 stash_policy: str = "copy",
                 stash_num_frames: int = 10,
                 max_workers: Optional[int] = None,
                 stream_ids: Optional[List[int]] = None,
                 maintain_frame_numbers: bool = True,
                 start_frame: Optional[int] = None,
                 end_frame: Optional[int] = None,
                 video_codec: str = 'h264',
                 container_format: str = 'mp4',
                 fps: float = 30.0,
                 crf: int = 18,
                 preset: str = 'medium',
                 extra_options: Optional[Dict[str, str]] = None):
        """
        Initialize MultiVideo dataset writer.
        
        Args:
            input_dataset: Source dataset to read from
            output_path: Path where the new dataset will be written
            copy_meta: Whether to copy meta folder from source dataset
            stash_policy: "generate", "copy", or "ignore"
            stash_num_frames: Number of stash frames to generate when policy is "generate"
            max_workers: Number of parallel workers for decoding input dataset
            stream_ids: List of stream IDs to write, or None for all streams
            maintain_frame_numbers: If True, keep original frame numbers; if False, start from 0
                                   (Note: only affects stash frame numbering for video output)
            start_frame: Start frame from source dataset (inclusive), or None for dataset start
            end_frame: End frame from source dataset (inclusive), or None for dataset end
            video_codec: Video codec to use ('h264', 'h265', 'hevc', 'av1')
            container_format: Container format ('mp4', 'mov', 'avi')
            fps: Output video frame rate
            crf: Constant Rate Factor for quality (0-51, lower = better quality, ~18 is visually lossless)
            preset: Encoding preset ('ultrafast', 'fast', 'medium', 'slow', 'veryslow')
            extra_options: Additional FFmpeg options as dict
        """
        _check_av_available()
        super().__init__(
            input_dataset,
            output_path,
            copy_meta,
            stash_policy,
            stash_num_frames,
            max_workers,
        )
        
        self.stream_ids = stream_ids
        self.maintain_frame_numbers = maintain_frame_numbers
        self.start_frame = start_frame
        self.end_frame = end_frame
        self.fps = fps
        self.crf = max(0, min(51, crf))
        self.preset = preset
        self.extra_options = extra_options or {}
        
        video_codec = video_codec.lower()
        if video_codec not in SUPPORTED_CODECS:
            raise ValueError(
                f"Unsupported video codec: {video_codec}. "
                f"Supported codecs: {list(SUPPORTED_CODECS.keys())}"
            )
        self.video_codec = video_codec
        self.codec_config = SUPPORTED_CODECS[video_codec]
        
        container_format = container_format.lower()
        if container_format not in SUPPORTED_CONTAINERS:
            raise ValueError(
                f"Unsupported container format: {container_format}. "
                f"Supported formats: {list(SUPPORTED_CONTAINERS.keys())}"
            )
        self.container_format = container_format
        self.file_extension = f".{container_format}"

    def _resumable_config(self):
        return {
            "stream_ids": self.stream_ids,
            "start_frame": self.start_frame,
            "end_frame": self.end_frame,
            "maintain_frame_numbers": self.maintain_frame_numbers,
            "video_codec": self.video_codec,
            "container_format": self.container_format,
            "fps": self.fps,
            "crf": self.crf,
            "preset": self.preset,
        }

    def _format_stream_name(self, stream_id: int) -> str:
        """Format stream filename with 3-digit zero padding."""
        return f"{stream_id:03d}{self.file_extension}"
    
    def _format_frame_name(self, frame_num: int) -> str:
        """Format frame folder name with 8-digit zero padding."""
        return f"{frame_num:08d}"
    
    def _copy_meta_folder(self):
        super()._copy_meta_folder()
    
    def _create_video_encoder(self, output_path: Path, width: int, height: int) -> tuple:
        """
        Create a video encoder for a single stream.
        
        Returns:
            Tuple of (container, stream)
        """
        container = av.open(str(output_path), mode='w')
        
        stream = container.add_stream(self.codec_config['codec'], rate=Fraction(self.fps).limit_denominator())
        stream.width = width
        stream.height = height
        stream.pix_fmt = self.codec_config['pix_fmt']
        
        if self.video_codec in ['h264', 'h265', 'hevc']:
            stream.options = {
                'crf': str(self.crf),
                'preset': self.preset,
            }
        elif self.video_codec == 'av1':
            stream.options = {
                'crf': str(self.crf),
                'preset': '6',  # SVT-AV1 preset (0-13, lower = slower/better)
            }
        
        stream.options.update(self.extra_options)
        
        return container, stream
    
    def _encode_frame(self, stream: Any, frame_array: np.ndarray, pts: int):
        """
        Encode a single frame.
        
        Args:
            stream: PyAV video stream
            frame_array: RGB numpy array (HWC format)
            pts: Presentation timestamp
        """
        frame = av.VideoFrame.from_ndarray(frame_array, format='rgb24')
        frame.pts = pts
        
        for packet in stream.encode(frame):
            yield packet
    
    def write(self) -> MultiVideoDataset:
        """
        Write the dataset in MultiVideo convention format.
        
        Returns:
            Instance of the newly created MultiVideoDataset
        """
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        input_ranges = self.input_dataset.get_frame_ranges()
        if not input_ranges:
            raise ValueError("Input dataset has no frame ranges")
        
        dataset_min_frame = input_ranges[0][0]
        dataset_max_frame = input_ranges[-1][1]
        
        actual_start = self.start_frame if self.start_frame is not None else dataset_min_frame
        actual_end = self.end_frame if self.end_frame is not None else dataset_max_frame
        
        if actual_start < dataset_min_frame or actual_end > dataset_max_frame:
            raise ValueError(
                f"Requested range [{actual_start}, {actual_end}] outside "
                f"dataset range [{dataset_min_frame}, {dataset_max_frame}]"
            )
        
        if actual_start > actual_end:
            raise ValueError(
                f"Invalid range: start_frame ({actual_start}) > end_frame ({actual_end})"
            )
        
        total_frames = actual_end - actual_start + 1
        
        print(f"Input dataset frame range: [{dataset_min_frame}, {dataset_max_frame}]")
        print(f"Processing frame range: [{actual_start}, {actual_end}] ({total_frames} frames)")
        print(f"Output format: {self.video_codec.upper()} in {self.container_format.upper()}")
        print(f"FPS: {self.fps}, CRF: {self.crf}, Preset: {self.preset}")
        
        if self.stream_ids is None:
            self.stream_ids = self.input_dataset.stream_ids
        
        print(f"Writing {len(self.stream_ids)} streams: {self.stream_ids}")
        
        reader = self.input_dataset.create_frame_reader(
            stream_ids=self.stream_ids,
            start_frame=actual_start,
            end_frame=actual_start,
            max_workers=self.max_workers,
        )
        try:
            _, first_frame = reader.read_frame(actual_start)
        finally:
            reader.close()
        
        sample_array = first_frame[self.stream_ids[0]]
        height, width = sample_array.shape[:2]
        
        print(f"Video resolution: {width}x{height}")
        
        containers = {}
        streams = {}
        
        for stream_id in self.stream_ids:
            output_filename = self._format_stream_name(stream_id)
            output_path = self.output_path / output_filename
            
            container, stream = self._create_video_encoder(output_path, width, height)
            containers[stream_id] = container
            streams[stream_id] = stream
        
        print(f"\nEncoding {total_frames} frames...")
        
        try:
            try:
                full_reader = self.input_dataset.create_frame_reader(
                    stream_ids=self.stream_ids,
                    start_frame=actual_start,
                    end_frame=actual_end,
                    max_workers=self.max_workers,
                )
                try:
                    pts = 0
                    for frame_idx, frame_data in tqdm(full_reader, desc="  Encoding", total=total_frames):
                        for stream_id in self.stream_ids:
                            if stream_id not in frame_data:
                                raise ValueError(f"Stream {stream_id} not found in frame {frame_idx}")
                            
                            frame_array = frame_data[stream_id]
                            
                            for packet in self._encode_frame(streams[stream_id], frame_array, pts):
                                containers[stream_id].mux(packet)
                        
                        pts += 1
                finally:
                    full_reader.close()
                    
            except NotImplementedError as e:
                if "multiple ranges" in str(e):
                    print("  Note: Processing ranges separately (multi-range reading not supported)")
                    pts = self._process_across_ranges(
                        actual_start, actual_end, containers, streams
                    )
                else:
                    raise
            
            for stream_id in self.stream_ids:
                for packet in streams[stream_id].encode():
                    containers[stream_id].mux(packet)
        
        finally:
            for container in containers.values():
                container.close()
        
        if self.copy_meta:
            self._copy_meta_folder()
        
        if self.stash_policy == "copy":
            self._copy_stash_folder(
                stream_ids=self.stream_ids,
                start_frame=actual_start,
                end_frame=actual_end,
                maintain_frame_numbers=self.maintain_frame_numbers,
            )
        elif self.stash_policy == "generate":
            self._generate_stash_from_reader(
                stream_ids=self.stream_ids,
                start_frame=actual_start,
                end_frame=actual_end,
                maintain_frame_numbers=self.maintain_frame_numbers,
            )
        
        print(f"\nSuccessfully created MultiVideo dataset at {self.output_path}")
        
        return MultiVideoDataset(self.output_path, max_workers=self.max_workers)
    
    def _process_across_ranges(self,
                               actual_start: int,
                               actual_end: int,
                               containers: Dict[int, Any],
                               streams: Dict[int, Any]) -> int:
        """
        Process frames across multiple ranges.
        
        Returns:
            Final PTS value
        """
        all_ranges = self.input_dataset.get_frame_ranges()
        
        overlapping_ranges = []
        for range_start, range_end, range_metadata in all_ranges:
            if range_end >= actual_start and range_start <= actual_end:
                overlap_start = max(range_start, actual_start)
                overlap_end = min(range_end, actual_end)
                overlapping_ranges.append((overlap_start, overlap_end, range_metadata))
        
        if not overlapping_ranges:
            raise ValueError(f"No ranges found overlapping [{actual_start}, {actual_end}]")
        
        pts = 0
        for overlap_start, overlap_end, _ in overlapping_ranges:
            reader = self.input_dataset.create_frame_reader(
                stream_ids=self.stream_ids,
                start_frame=overlap_start,
                end_frame=overlap_end,
                max_workers=self.max_workers,
            )
            try:
                for frame_idx, frame_data in reader:
                    for stream_id in self.stream_ids:
                        if stream_id not in frame_data:
                            raise ValueError(f"Stream {stream_id} not found in frame {frame_idx}")
                        
                        frame_array = frame_data[stream_id]
                        
                        for packet in self._encode_frame(streams[stream_id], frame_array, pts):
                            containers[stream_id].mux(packet)
                    
                    pts += 1
            finally:
                reader.close()
        
        return pts
