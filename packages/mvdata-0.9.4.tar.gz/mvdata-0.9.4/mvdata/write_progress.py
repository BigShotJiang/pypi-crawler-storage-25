"""
Write progress tracking for crash-safe dataset conversion.

Maintains a single JSON manifest at the dataset root that records structural
config, completed work units, and the currently in-flight unit. If the
process crashes, the manifest survives and lets a subsequent ``resume=True``
run skip already-finished work while re-doing the interrupted unit.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional, Set

PROGRESS_FILENAME = ".mvdata_progress.json"
_VERSION = 1


class WriteProgress:
    """Tracks conversion progress via a JSON manifest on disk."""

    def __init__(
        self,
        path: Path,
        writer_name: str,
        config: Dict[str, Any],
        completed: Optional[Set[str]] = None,
        in_progress: Optional[str] = None,
    ):
        self._path = path
        self._writer_name = writer_name
        self._config = config
        self._completed: Set[str] = completed or set()
        self._in_progress = in_progress
        self._skipped = 0

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def load_or_create(
        cls,
        output_path: Path,
        writer_name: str,
        config: Dict[str, Any],
    ) -> "WriteProgress":
        """Load an existing progress file (validating config) or create a fresh one.

        Raises ``ValueError`` with a human-readable diff when the saved config
        doesn't match the current one. A corrupt/unreadable manifest is treated
        as a resume error so callers fail closed instead of inferring progress
        from partially-written output files.
        """
        path = cls.manifest_path(output_path)
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError) as exc:
                raise ValueError(
                    "Cannot resume: progress manifest is unreadable or corrupt.\n"
                    f"  {path}\n\n"
                    "Refusing to infer progress from on-disk files.\n"
                    "To start fresh, delete the existing output dataset:\n"
                    f"  {path.parent}"
                ) from exc

            saved_config = data.get("config", {})
            if saved_config != config:
                diff_lines = _config_diff(saved_config, config)
                raise ValueError(
                    "Cannot resume: conversion configuration has changed.\n"
                    + "\n".join(diff_lines)
                    + f"\n\nTo start fresh, delete the existing output dataset:\n  {path.parent}"
                )

            completed = set(data.get("completed", []))
            in_progress = data.get("in_progress")
            return cls(path, writer_name, config, completed, in_progress)

        return cls(path, writer_name, config)

    @classmethod
    def create_fresh(
        cls,
        output_path: Path,
        writer_name: str,
        config: Dict[str, Any],
    ) -> "WriteProgress":
        """Create a brand-new progress tracker (no disk read)."""
        path = cls.manifest_path(output_path)
        return cls(path, writer_name, config)

    @staticmethod
    def manifest_path(output_path: Path) -> Path:
        return output_path / PROGRESS_FILENAME

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def is_done(self, unit_id: str) -> bool:
        """Return True if *unit_id* completed in a previous run."""
        done = unit_id in self._completed and unit_id != self._in_progress
        if done:
            self._skipped += 1
        return done

    @property
    def in_progress(self) -> Optional[str]:
        return self._in_progress

    @property
    def completed(self) -> Set[str]:
        return set(self._completed)

    @property
    def skipped(self) -> int:
        """Number of ``is_done()`` calls that returned True."""
        return self._skipped

    # ------------------------------------------------------------------
    # State transitions
    # ------------------------------------------------------------------

    def begin(self, unit_id: str) -> None:
        """Mark *unit_id* as in-flight and flush to disk."""
        self._in_progress = unit_id
        self._save()

    def complete(self, unit_id: str) -> None:
        """Mark *unit_id* as done, clear in-flight, flush to disk."""
        self._completed.add(unit_id)
        self._in_progress = None
        self._save()

    def mark_done(self, unit_id: str) -> None:
        """Record a unit as completed without a begin/complete cycle.

        Useful for bootstrapping from on-disk state when no progress file
        existed from a prior run.
        """
        self._completed.add(unit_id)

    def finish(self) -> None:
        """All work done; persist the completed manifest for future validation."""
        self._in_progress = None
        self._save()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _save(self) -> None:
        payload = json.dumps(
            {
                "version": _VERSION,
                "writer": self._writer_name,
                "config": self._config,
                "in_progress": self._in_progress,
                "completed": sorted(self._completed),
            },
            indent=2,
        )
        fd, tmp_name = tempfile.mkstemp(
            dir=str(self._path.parent),
            prefix=f"{self._path.name}.",
            suffix=".tmp",
        )
        tmp_path = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            # Replace the manifest atomically so crashes never leave a truncated file in place.
            tmp_path.replace(self._path)
        finally:
            if tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass

    def save(self) -> None:
        """Explicitly persist current state (e.g. after ``mark_done`` calls)."""
        self._save()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _config_diff(
    saved: Dict[str, Any],
    current: Dict[str, Any],
    prefix: str = "",
) -> list[str]:
    """Return human-readable lines describing config differences."""
    all_keys = sorted(set(saved) | set(current))
    lines: list[str] = []
    for key in all_keys:
        old = saved.get(key)
        new = current.get(key)
        dotted_key = f"{prefix}{key}"
        if isinstance(old, dict) and isinstance(new, dict):
            lines.extend(_config_diff(old, new, prefix=f"{dotted_key}."))
        elif old != new:
            lines.append(f"  {dotted_key}: {old!r} -> {new!r}")
    return lines
