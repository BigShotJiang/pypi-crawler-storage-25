from pathlib import Path


def is_system_file(path: Path) -> bool:
    """
    Check if a file should be excluded as a system/temporary file.
    
    Args:
        path: Path to check
        
    Returns:
        True if the file should be excluded
    """
    exclude_names = {
        '.DS_Store',
        'Thumbs.db',
        'Desktop.ini',
        '._.DS_Store',
    }
    
    if path.name in exclude_names:
        return True
    
    if path.name.startswith('.'):
        return True
    
    if path.suffix in ['.pyc', '.pyo']:
        return True
    
    if path.name.endswith('~') or path.name.startswith('~'):
        return True
    
    return False
