from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, List
import os

from .dataset_base import Dataset
from .stash_utils import (
    SUPPORTED_STASH_EXTENSIONS,
    select_stash_frames,
    generate_stash_to_path,
    copy_stash_frames,
)


class DatasetWriter(ABC):
    """Base class for dataset writers."""

    def __init__(self, 
                 input_dataset: Dataset,
                 output_path: Path,
                 copy_meta: bool = True,
                 stash_policy: str = "copy",
                 stash_num_frames: int = 10,
                 max_workers: Optional[int] = None,
                 resume: bool = False):
        """
        Initialize dataset writer.
        
        Args:
            input_dataset: Source dataset to read from
            output_path: Path where the new dataset will be written
            copy_meta: Whether to copy meta folder from source dataset
            stash_policy: "generate", "copy", or "ignore"
            stash_num_frames: Number of stash frames to generate when policy is "generate"
            max_workers: Number of parallel workers for encoding
            resume: If True, skip already-completed work and continue from where a
                    previous run left off instead of requiring an empty output directory
        """
        self.input_dataset = input_dataset
        self.output_path = Path(output_path)
        self.copy_meta = copy_meta
        self.stash_policy = stash_policy.lower()
        self.stash_num_frames = stash_num_frames
        self.resume = resume
        if max_workers is None:
            max_workers = os.cpu_count() or 1
        self.max_workers = max_workers

        if self.stash_policy not in {"generate", "copy", "ignore"}:
            raise ValueError(
                f"Invalid stash_policy: {stash_policy}. "
                "Expected one of: generate, copy, ignore"
            )

        if self.stash_num_frames < 0:
            raise ValueError(
                f"stash_num_frames must be >= 0, got {stash_num_frames}"
            )
        
        if not self.resume:
            if self.output_path.exists():
                if any(self.output_path.iterdir()):
                    raise ValueError(f"Output path {self.output_path} already exists and is not empty")
        
    def _resumable_config(self) -> Dict[str, Any]:
        """Return structural config keys that define the output layout.

        Subclasses should override this with all parameters whose change would
        make a previous partial output incompatible with a resumed run.
        The returned dict is stored in the progress manifest and compared on
        resume; a mismatch aborts with a human-readable diff.
        """
        return {
            "copy_meta": self.copy_meta,
            "stash_policy": self.stash_policy,
            "stash_num_frames": self.stash_num_frames,
        }

    @abstractmethod
    def write(self) -> Dataset:
        """
        Write the dataset and return an instance of the newly created dataset.
        
        Returns:
            Instance of the created dataset
        """
        pass

    def _copy_meta_folder(self) -> None:
        """Copy metadata from the source dataset into the output dataset."""
        self.input_dataset.copy_meta_to(self.output_path)

    def _copy_stash_folder(
        self,
        stream_ids: List[int],
        start_frame: int,
        end_frame: int,
        maintain_frame_numbers: bool,
    ) -> None:
        """
        Copy stash folder from input dataset, filtering by frame range.

        Args:
            stream_ids: List of stream IDs to copy
            start_frame: Start frame of the conversion range
            end_frame: End frame of the conversion range
            maintain_frame_numbers: Whether to preserve original frame numbers

        Raises:
            ValueError: If source dataset has no stash frames to copy
        """
        output_offset = 0 if maintain_frame_numbers else start_frame
        stash_dir = self.output_path / "stash"

        copy_stash_frames(
            source=self.input_dataset,
            target_stash_dir=stash_dir,
            stream_ids=stream_ids,
            start_frame=start_frame,
            end_frame=end_frame,
            output_offset=output_offset,
            supported_exts=SUPPORTED_STASH_EXTENSIONS,
        )

    def _generate_stash_from_reader(
        self,
        stream_ids: List[int],
        start_frame: int,
        end_frame: int,
        maintain_frame_numbers: bool,
    ) -> None:
        """
        Generate stash frames from the input dataset.

        Uses an agnostic approach:
        - If source dataset provides direct file paths (e.g., Legacy), copies
          files directly with normalization (much faster, preserves quality)
        - Otherwise, decodes frames and saves as PNG (required for video-based
          formats like Ranged/MultiVideo)
        """
        self._generate_stash_from_dataset(
            source=self.input_dataset,
            stream_ids=stream_ids,
            start_frame=start_frame,
            end_frame=end_frame,
            maintain_frame_numbers=maintain_frame_numbers,
        )

    def _generate_stash_from_dataset(
        self,
        source: Dataset,
        stream_ids: List[int],
        start_frame: int,
        end_frame: int,
        maintain_frame_numbers: bool,
    ) -> None:
        selected_frames = select_stash_frames(start_frame, end_frame, self.stash_num_frames)
        if not selected_frames:
            return

        if maintain_frame_numbers:
            output_frame_numbers = selected_frames
        else:
            output_frame_numbers = [f - start_frame for f in selected_frames]

        stash_dir = self.output_path / "stash"

        generate_stash_to_path(
            source=source,
            target_stash_dir=stash_dir,
            frame_indices=selected_frames,
            stream_ids=stream_ids,
            output_frame_numbers=output_frame_numbers,
            supported_exts=SUPPORTED_STASH_EXTENSIONS,
            max_workers=self.max_workers,
        )
