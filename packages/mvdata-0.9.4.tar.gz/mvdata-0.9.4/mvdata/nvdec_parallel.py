from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import os
import re
import subprocess
from typing import Mapping

MVDATA_NVDEC_MAX_SESSIONS_ENV = "MVDATA_NVDEC_MAX_SESSIONS"

# Snapshot sourced from NVIDIA's current Video Encode and Decode Support Matrix.
# Keep the list deliberately small and focused on server/workstation SKUs that
# are plausible deployment targets for mvdata's ranged MP4 reader.
_NVDEC_TOTAL_BY_GPU_SUBSTRING: tuple[tuple[str, int], ...] = (
    ("nvidia rtx pro 6000 blackwell server edition", 4),
    ("nvidia hgx b200", 7),
    ("nvidia hgx b300", 7),
    ("nvidia gb200", 7),
    ("nvidia gb300", 7),
    ("nvidia h100", 7),
    ("nvidia l40s", 3),
    ("nvidia l40", 3),
    ("nvidia l4", 4),
    ("nvidia a100", 5),
    ("nvidia a40", 2),
    ("nvidia a30", 4),
    ("nvidia a16", 8),
    ("nvidia a10", 2),
    ("nvidia a2", 2),
    ("tesla t4", 2),
    ("nvidia rtx 6000 ada generation", 3),
)


@dataclass(frozen=True)
class NvdecParallelismPlan:
    gpu_id: int
    gpu_name: str | None
    budget_sessions: int
    planned_sessions: int
    reason: str
    configured_limit: int | None


def normalize_gpu_name(name: str) -> str:
    return re.sub(r"\s+", " ", name.strip().lower())


def parse_nvdec_session_override(env: Mapping[str, str] | None = None) -> int | None:
    source = os.environ if env is None else env
    raw = source.get(MVDATA_NVDEC_MAX_SESSIONS_ENV)
    if raw is None:
        return None

    text = raw.strip().lower()
    if text in ("", "auto"):
        return None

    value = int(text)
    if value < 1:
        raise ValueError(
            f"{MVDATA_NVDEC_MAX_SESSIONS_ENV} must be >= 1 or 'auto', got {raw!r}"
        )
    return value


@lru_cache(maxsize=1)
def _query_gpu_names() -> tuple[str, ...]:
    try:
        proc = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
    except (FileNotFoundError, subprocess.SubprocessError, OSError):
        return ()

    names = []
    for line in proc.stdout.splitlines():
        name = line.strip()
        if name:
            names.append(name)
    return tuple(names)


def detect_gpu_name(gpu_id: int) -> str | None:
    names = _query_gpu_names()
    if gpu_id < 0 or gpu_id >= len(names):
        return None
    return names[gpu_id]


def lookup_nvdec_total(gpu_name: str | None) -> int | None:
    if not gpu_name:
        return None

    normalized = normalize_gpu_name(gpu_name)
    for candidate, total in _NVDEC_TOTAL_BY_GPU_SUBSTRING:
        if candidate in normalized:
            return total
    return None


def resolve_nvdec_parallelism(
    *,
    gpu_id: int,
    session_count: int,
    requested_max_workers: int | None = None,
    env: Mapping[str, str] | None = None,
    gpu_name: str | None = None,
) -> NvdecParallelismPlan:
    if session_count < 0:
        raise ValueError(f"session_count must be >= 0, got {session_count}")

    configured_limit = parse_nvdec_session_override(env)
    resolved_gpu_name = gpu_name if gpu_name is not None else detect_gpu_name(gpu_id)

    if configured_limit is not None:
        budget_sessions = configured_limit
        reason = f"env:{MVDATA_NVDEC_MAX_SESSIONS_ENV}"
    else:
        detected_budget = lookup_nvdec_total(resolved_gpu_name)
        if detected_budget is not None:
            budget_sessions = detected_budget
            reason = "support-matrix"
        else:
            budget_sessions = 1
            reason = "fallback:unknown-gpu"

    if requested_max_workers is not None:
        budget_sessions = min(budget_sessions, max(1, int(requested_max_workers)))
        reason = f"{reason}+reader-limit"

    planned_sessions = min(budget_sessions, session_count) if session_count else 0
    return NvdecParallelismPlan(
        gpu_id=gpu_id,
        gpu_name=resolved_gpu_name,
        budget_sessions=budget_sessions,
        planned_sessions=planned_sessions,
        reason=reason,
        configured_limit=configured_limit,
    )
