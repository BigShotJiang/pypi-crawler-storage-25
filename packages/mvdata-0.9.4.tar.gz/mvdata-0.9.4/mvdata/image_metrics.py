"""Image quality helpers (lossy pipeline checks)."""

from __future__ import annotations

import numpy as np


def _default_psnr_peak(img1: np.ndarray, img2: np.ndarray) -> float:
    peak = 255.0
    for img in (img1, img2):
        if np.issubdtype(img.dtype, np.integer):
            peak = max(peak, float(np.iinfo(img.dtype).max))
    return peak


def calculate_psnr(img1: np.ndarray, img2: np.ndarray, *, peak_value: float | None = None) -> float:
    """PSNR for same-shape arrays, using a dtype-aware default peak value."""
    a = img1.astype(np.float64)
    b = img2.astype(np.float64)
    mse = np.mean((a - b) ** 2)
    if mse == 0:
        return float("inf")
    peak = float(peak_value) if peak_value is not None else _default_psnr_peak(img1, img2)
    return float(20 * np.log10(peak / np.sqrt(mse)))
