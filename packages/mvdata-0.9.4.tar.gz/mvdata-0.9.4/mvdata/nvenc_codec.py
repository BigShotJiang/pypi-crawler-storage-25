"""Backward-compatibility shim for :mod:`mvdata.codec`.

The full implementation lives in the :mod:`mvdata.codec` subpackage; this
module re-exports the public surface so existing imports such as
``from mvdata import nvenc_codec`` or ``from mvdata.nvenc_codec import X``
(and monkeypatching in tests) keep working.
"""

from .codec import *  # noqa: F401,F403
from .codec import (  # noqa: F401 -- re-exported private helpers used by callers/tests
    _PYNVC_API_REF,
    _decoded_frame_to_rgb_cupy,
    _decoded_frame_to_rgb_numpy,
    _normalize_rgb_numpy_output,
    _pyav_frame_to_rgb,
    _try_open_nvdec,
)
