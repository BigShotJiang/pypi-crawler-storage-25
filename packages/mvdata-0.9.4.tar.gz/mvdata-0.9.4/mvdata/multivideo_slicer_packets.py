from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Optional

from .multivideo_slicer_models import (
    MultiVideoSliceError,
    MultiVideoSliceRange,
    MultiVideoStreamSliceInfo,
)

try:
    import av

    HAS_AV = True
except ImportError:  # pragma: no cover - exercised only without optional dependency
    av = None
    HAS_AV = False


def _check_av_available() -> None:
    if not HAS_AV:
        raise ImportError("PyAV is required for MultiVideo slicing. Install it with: pip install av")


def _normalize_codec_name(codec_name: str) -> str:
    name = codec_name.lower()
    if name in {"h265", "hevc"}:
        return "hevc"
    return name


def _fraction_to_str(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}"


def _resolve_fraction(value: Any) -> Optional[Fraction]:
    if value is None:
        return None
    fraction = Fraction(value)
    if fraction.numerator == 0 or fraction.denominator == 0:
        return None
    return fraction


@dataclass(frozen=True)
class _VideoPacketRecord:
    packet_index: int
    pts: int
    dts: int
    is_keyframe: bool
    is_discard: bool
    is_sync: bool = False


@dataclass(frozen=True)
class _PacketCopyPlan:
    packet_start: int
    packet_end: int
    timestamp_offset: int
    packet_indices: frozenset[int]
    presentation_frame_offset: int = 0
    dependency_start_frame: int = 0


def _is_content_packet(packet: Any) -> bool:
    return getattr(packet, "size", 0) > 0


def _nal_length_size(codec: str, extradata: bytes) -> int:
    if codec == "h264" and len(extradata) >= 5 and extradata[0] == 1:
        return (extradata[4] & 0x03) + 1
    if codec == "hevc" and len(extradata) >= 22 and extradata[0] == 1:
        return (extradata[21] & 0x03) + 1
    return 4


def _annexb_nal_payloads(data: bytes) -> list[bytes]:
    starts: list[tuple[int, int]] = []
    index = 0
    while index + 3 <= len(data):
        if data[index : index + 3] == b"\x00\x00\x01":
            starts.append((index, 3))
            index += 3
            continue
        if index + 4 <= len(data) and data[index : index + 4] == b"\x00\x00\x00\x01":
            starts.append((index, 4))
            index += 4
            continue
        index += 1

    payloads: list[bytes] = []
    for position, (start, prefix_len) in enumerate(starts):
        payload_start = start + prefix_len
        payload_end = starts[position + 1][0] if position + 1 < len(starts) else len(data)
        if payload_start < payload_end:
            payloads.append(data[payload_start:payload_end])
    return payloads


def _length_prefixed_nal_payloads(data: bytes, length_size: int) -> list[bytes]:
    payloads: list[bytes] = []
    offset = 0
    while offset + length_size <= len(data):
        nal_size = int.from_bytes(data[offset : offset + length_size], "big")
        offset += length_size
        if nal_size <= 0 or offset + nal_size > len(data):
            return []
        payloads.append(data[offset : offset + nal_size])
        offset += nal_size
    return payloads if offset == len(data) else []


def _packet_nal_types(packet: Any, codec: str, nal_length_size: int) -> tuple[int, ...]:
    data = bytes(packet)
    payloads = _length_prefixed_nal_payloads(data, nal_length_size)
    if not payloads:
        payloads = _annexb_nal_payloads(data)

    nal_types: list[int] = []
    for payload in payloads:
        if not payload:
            continue
        if codec == "h264":
            nal_types.append(payload[0] & 0x1F)
        elif codec == "hevc" and len(payload) >= 2:
            nal_types.append((payload[0] >> 1) & 0x3F)
    return tuple(nal_types)


def _is_independent_sync_packet(
    packet: Any,
    *,
    codec: str,
    nal_length_size: int,
) -> bool:
    if not bool(packet.is_keyframe):
        return False
    if codec == "h264":
        return 5 in _packet_nal_types(packet, codec, nal_length_size)
    if codec == "hevc":
        return any(
            16 <= nal_type <= 21
            for nal_type in _packet_nal_types(packet, codec, nal_length_size)
        )
    return True


def _record_packet(
    packet: Any,
    packet_index: int,
    *,
    codec: str,
    nal_length_size: int,
) -> _VideoPacketRecord:
    return _VideoPacketRecord(
        packet_index=packet_index,
        pts=int(packet.pts),
        dts=int(packet.dts),
        is_keyframe=bool(packet.is_keyframe),
        is_discard=bool(packet.is_discard),
        is_sync=_is_independent_sync_packet(
            packet,
            codec=codec,
            nal_length_size=nal_length_size,
        ),
    )


def _presentation_order(records: list[_VideoPacketRecord]) -> list[_VideoPacketRecord]:
    return sorted(
        (record for record in records if not record.is_discard),
        key=lambda record: (record.pts, record.dts, record.packet_index),
    )


def _count_visible_video_packets(video_path: Path) -> int:
    container = av.open(str(video_path))
    try:
        if not container.streams.video:
            raise MultiVideoSliceError(f"No video stream in sliced output: {video_path}")
        video_stream = container.streams.video[0]
        return sum(
            1
            for packet in container.demux(video_stream)
            if _is_content_packet(packet) and not packet.is_discard
        )
    finally:
        container.close()


def _count_decoded_video_frames(video_path: Path) -> int:
    container = av.open(str(video_path))
    try:
        if not container.streams.video:
            raise MultiVideoSliceError(f"No video stream in sliced output: {video_path}")
        video_stream = container.streams.video[0]
        return sum(1 for _ in container.decode(video_stream))
    finally:
        container.close()


def _read_video_packet_records(video_path: Path) -> list[_VideoPacketRecord]:
    container = av.open(str(video_path))
    try:
        if not container.streams.video:
            raise MultiVideoSliceError(f"No video stream: {video_path}")

        records = _scan_packet_records(container, container.streams.video[0])

        if not records:
            raise MultiVideoSliceError(f"No video packets: {video_path}")

        return records
    finally:
        container.close()


def _scan_packet_records(container: Any, video_stream: Any) -> list[_VideoPacketRecord]:
    records: list[_VideoPacketRecord] = []
    packet_index = 0
    missing_timestamps = False
    codec = _normalize_codec_name(video_stream.codec_context.name)
    extradata = bytes(getattr(video_stream.codec_context, "extradata", None) or b"")
    nal_length_size = _nal_length_size(codec, extradata)

    for packet in container.demux(video_stream):
        if not _is_content_packet(packet):
            continue

        if packet.pts is None or packet.dts is None:
            missing_timestamps = True
        else:
            records.append(
                _record_packet(
                    packet,
                    packet_index,
                    codec=codec,
                    nal_length_size=nal_length_size,
                )
            )
        packet_index += 1

    if missing_timestamps:
        raise MultiVideoSliceError(
            "Video is not eligible for frame-based packet-copy slicing: "
            "video packets must have presentation and decode timestamps"
        )

    return records


def _copy_packet_for_mux(packet: Any) -> Any:
    packet_copy = av.Packet(bytes(packet))
    packet_copy.pts = packet.pts
    packet_copy.dts = packet.dts
    packet_copy.duration = packet.duration
    if packet.time_base is not None:
        packet_copy.time_base = packet.time_base
    packet_copy.is_keyframe = bool(packet.is_keyframe)
    packet_copy.is_corrupt = bool(packet.is_corrupt)
    packet_copy.opaque = packet.opaque
    for side_data in packet.iter_sidedata():
        packet_copy.set_sidedata(side_data)
    return packet_copy


def _packet_copy_plans(
    video_path: Path,
    ranges: tuple[MultiVideoSliceRange, ...],
    stream_id: int,
) -> dict[MultiVideoSliceRange, _PacketCopyPlan]:
    return _packet_copy_plans_from_records(
        _read_video_packet_records(video_path),
        ranges,
        stream_id,
    )


def _packet_copy_plans_from_records(
    records: list[_VideoPacketRecord],
    ranges: tuple[MultiVideoSliceRange, ...],
    stream_id: int,
) -> dict[MultiVideoSliceRange, _PacketCopyPlan]:
    presentation = _presentation_order(records)
    visible_frame_by_packet = {
        record.packet_index: frame_index
        for frame_index, record in enumerate(presentation)
    }
    sync_frame_indices = [
        frame_index
        for frame_index, record in enumerate(presentation)
        if record.is_sync
    ]

    plans: dict[MultiVideoSliceRange, _PacketCopyPlan] = {}
    for range_info in ranges:
        if range_info.source_end_frame >= len(presentation):
            raise MultiVideoSliceError(
                f"Stream {stream_id} range {range_info.output_name} ends at frame "
                f"{range_info.source_end_frame}, but only {len(presentation)} visible "
                "frames are available"
            )

        start_record = presentation[range_info.source_start_frame]
        if not start_record.is_keyframe:
            raise MultiVideoSliceError(
                f"Stream {stream_id} range {range_info.output_name} starts at visible "
                f"frame {range_info.source_start_frame}, which is not a keyframe"
            )

        dependency_start_frame = range_info.source_start_frame
        if not start_record.is_sync:
            prior_sync_frames = [
                frame_index
                for frame_index in sync_frame_indices
                if frame_index <= range_info.source_start_frame
            ]
            if not prior_sync_frames:
                if range_info.source_start_frame != 0:
                    raise MultiVideoSliceError(
                        f"Stream {stream_id} range {range_info.output_name} starts at "
                        f"open-GOP keyframe {range_info.source_start_frame}, but no earlier "
                        "independently decodable sync frame is available"
                    )
            else:
                dependency_start_frame = prior_sync_frames[-1]

        dependency_start_record = presentation[dependency_start_frame]
        packet_start = dependency_start_record.packet_index
        packet_end = packet_start
        for frame_index in range(
            range_info.source_start_frame,
            range_info.source_end_frame + 1,
        ):
            packet_end = max(packet_end, presentation[frame_index].packet_index)
        packet_indices = frozenset(
            packet_index
            for packet_index in range(packet_start, packet_end + 1)
            if visible_frame_by_packet.get(packet_index, -1) >= dependency_start_frame
        )
        plans[range_info] = _PacketCopyPlan(
            packet_start,
            packet_end,
            dependency_start_record.pts,
            packet_indices,
            range_info.source_start_frame - dependency_start_frame,
            dependency_start_frame,
        )

    return plans


def _scan_video_for_slicing(stream_id: int, video_path: Path) -> MultiVideoStreamSliceInfo:
    _check_av_available()

    try:
        container = av.open(str(video_path))
    except Exception as exc:
        raise MultiVideoSliceError(
            f"Failed to open stream {stream_id} video {video_path}: {exc}"
        ) from exc

    try:
        if not container.streams.video:
            raise MultiVideoSliceError(f"Stream {stream_id} has no video stream: {video_path}")

        video_stream = container.streams.video[0]
        fps = _resolve_fraction(video_stream.average_rate)
        if fps is None:
            raise MultiVideoSliceError(
                f"Stream {stream_id} has unsupported or missing average frame rate: {video_path}"
            )

        codec = _normalize_codec_name(video_stream.codec_context.name)
        extradata = bytes(getattr(video_stream.codec_context, "extradata", None) or b"")
        nal_length_size = _nal_length_size(codec, extradata)
        packet_count = 0
        first_duration: Optional[int] = None
        records: list[_VideoPacketRecord] = []
        missing_duration = False
        missing_timestamps = False
        variable_duration = False

        for packet in container.demux(video_stream):
            if not _is_content_packet(packet):
                continue

            if packet.pts is None or packet.dts is None:
                missing_timestamps = True

            duration = packet.duration
            if duration is None or duration <= 0:
                missing_duration = True
            elif first_duration is None:
                first_duration = int(duration)
            elif int(duration) != first_duration:
                variable_duration = True

            if packet.pts is not None and packet.dts is not None:
                records.append(
                    _record_packet(
                        packet,
                        packet_count,
                        codec=codec,
                        nal_length_size=nal_length_size,
                    )
                )
            packet_count += 1

        if packet_count == 0:
            raise MultiVideoSliceError(f"Stream {stream_id} has no video packets: {video_path}")
        if missing_timestamps:
            raise MultiVideoSliceError(
                f"Stream {stream_id} is not eligible for frame-based packet-copy slicing: "
                "video packets must have presentation and decode timestamps"
            )
        if missing_duration or variable_duration:
            raise MultiVideoSliceError(
                f"Stream {stream_id} is not eligible for frame-based slicing: "
                "video packets must have a constant non-zero duration"
            )

        presentation = _presentation_order(records)
        if not presentation:
            raise MultiVideoSliceError(
                f"Stream {stream_id} has no visible video frames after discards: {video_path}"
            )
        keyframe_indices = tuple(
            frame_index
            for frame_index, record in enumerate(presentation)
            if record.is_keyframe
        )
        sync_frame_indices = tuple(
            frame_index
            for frame_index, record in enumerate(presentation)
            if record.is_sync
        )

        return MultiVideoStreamSliceInfo(
            stream_id=stream_id,
            path=str(video_path),
            codec=codec,
            fps=_fraction_to_str(fps),
            width=int(video_stream.width),
            height=int(video_stream.height),
            packet_count=packet_count,
            visible_frame_count=len(presentation),
            keyframe_indices=keyframe_indices,
            sync_frame_indices=sync_frame_indices,
            packet_duration_ticks=first_duration,
        )
    finally:
        container.close()
