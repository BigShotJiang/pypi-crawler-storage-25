from enum import Enum
from dataclasses import asdict, dataclass, replace
from typing import Any, Literal, Optional, List
from pathlib import Path
import gc
import shutil
import sys
import numpy as np
import time
from threading import Event, Thread
from queue import Empty, Full, Queue

try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
    # Fallback: simple wrapper that does nothing
    def tqdm(iterable, **kwargs):
        return iterable

from .writer_base import DatasetWriter
from .dataset_base import Dataset
from .ranged import RangedDataset
from .write_progress import WriteProgress
from pyavif import BatchEncoder, EncoderOptions


@dataclass
class RangedNvencSettings:
    """NVENC parameters when ``RangedDatasetWriter(..., ranged_compression='nvenc_h264')``.

    These defaults are concrete overrides. Auto detection is only used when
    ``nvenc_settings`` is omitted entirely from ``RangedDatasetWriter``.
    """

    gpu_id: int = 0
    fps: int = 30
    bitrate_bps: int = 0
    codec: str = "h264"
    chroma_subsampling: str = "444"
    range_mode: str = "full"
    preset: str = "P7"


class RangedDatasetWriter(DatasetWriter):
    """Writer for Ranged dataset convention (AVIF video batches)."""
    
    def __init__(self,
                 input_dataset: Dataset,
                 output_path: Path,
                 frames_per_batch: int = 500,
                 copy_meta: bool = True,
                 stash_policy: str = "copy",
                 stash_num_frames: int = 10,
                 encoder_options: Optional[EncoderOptions] = None,
                 max_workers: Optional[int] = None,
                 stream_ids: Optional[List[int]] = None,
                 streams_per_batch: int = 4,
                 prefetch_frames: int = 2,
                 debug_timing: bool = False,
                 maintain_frame_numbers: bool = True,
                 start_frame: Optional[int] = None,
                 end_frame: Optional[int] = None,
                 ranged_compression: Literal["avif", "nvenc_h264"] = "avif",
                 nvenc_settings: Optional[RangedNvencSettings] = None,
                 resume: bool = False):
        """
        Initialize Ranged dataset writer.
        
        Args:
            input_dataset: Source dataset to read from
            output_path: Path where the new dataset will be written
            frames_per_batch: Number of frames per range batch (default: 500)
            copy_meta: Whether to copy meta folder from source dataset
            stash_policy: "generate", "copy", or "ignore"
            stash_num_frames: Number of stash frames to generate when policy is "generate"
            encoder_options: AVIF encoder options (uses defaults if None; AVIF path only)
            max_workers: Number of parallel workers for decoding input dataset / frame readers
            stream_ids: List of stream IDs to write, or None for all streams
            streams_per_batch: Number of streams to encode simultaneously (default: 4)
            prefetch_frames: Number of frames to prefetch for decode/encode overlap (default: 2)
            debug_timing: Print per-range timing breakdowns (default: False)
            maintain_frame_numbers: If True, keep original frame numbers; if False, start from 0
            start_frame: Start frame from source dataset (inclusive), or None for dataset start
            end_frame: End frame from source dataset (inclusive), or None for dataset end
            ranged_compression: ``avif`` (pyavif) or ``nvenc_h264`` (per-stream MP4 via NVENC)
            nvenc_settings: Used when ``ranged_compression='nvenc_h264'`` (defaults applied if None)
            resume: If True, skip already-completed (stream_batch, range) pairs and
                    continue from where a previous run was interrupted
        """
        super().__init__(
            input_dataset,
            output_path,
            copy_meta,
            stash_policy,
            stash_num_frames,
            max_workers,
            resume=resume,
        )
        
        self.frames_per_batch = frames_per_batch
        self.encoder_options = encoder_options if encoder_options is not None else EncoderOptions()
        self.ranged_compression: Literal["avif", "nvenc_h264"] = ranged_compression
        self.nvenc_settings = nvenc_settings or (
            RangedNvencSettings(
                codec="auto",
                chroma_subsampling="auto",
                range_mode="auto",
                preset="auto",
            ) if ranged_compression == "nvenc_h264" else None
        )
        self.stream_ids = stream_ids
        self.streams_per_batch = streams_per_batch
        self.prefetch_frames = max(0, int(prefetch_frames))
        self.debug_timing = debug_timing
        self.maintain_frame_numbers = maintain_frame_numbers
        self.start_frame = start_frame
        self.end_frame = end_frame
        self._resolved_nvenc_settings: Optional[RangedNvencSettings] = None
        self._nvenc_probe_result: dict[str, Any] | None = None
        self._stream_output_formats: dict[int, Literal["avif", "nvenc_h264"]] = {}
        self._stream_nvenc_bitrates_bps: dict[int, int] = {}
        
    def _format_range_name(self, start: int, end: int) -> str:
        """Format range folder name with 8-digit zero padding."""
        return f"{start:08d}_{end:08d}"

    def _stream_output_format(self, stream_id: int) -> Literal["avif", "nvenc_h264"]:
        return self._stream_output_formats.get(stream_id, self.ranged_compression)
    
    def _format_stream_name(self, stream_id: int) -> str:
        """Format stream filename with 3-digit zero padding."""
        if self._stream_output_format(stream_id) == "nvenc_h264":
            return f"{stream_id:03d}.mp4"
        return f"{stream_id:03d}.avif"

    def _serialize_nvenc_settings(self) -> dict[str, Any] | None:
        if self.nvenc_settings is None:
            return None
        return {
            key: self._serialize_resume_value(value)
            for key, value in sorted(asdict(self.nvenc_settings).items())
        }

    def _serialize_resolved_nvenc_settings(self) -> dict[str, Any] | None:
        if self._resolved_nvenc_settings is None:
            return None
        return {
            key: self._serialize_resume_value(value)
            for key, value in sorted(asdict(self._resolved_nvenc_settings).items())
        }

    @staticmethod
    def _normalize_range_mode(value: str) -> str:
        mode = value.strip().lower()
        if mode not in ("auto", "full", "limited"):
            raise ValueError(f"range_mode must be 'auto', 'full', or 'limited', got {value!r}")
        return mode

    def _resolve_nvenc_settings_for_probe(
        self,
        nvc,
        probe_rgb: np.ndarray,
    ) -> RangedNvencSettings | None:
        from . import nvenc_codec

        cfg = self.nvenc_settings
        if cfg is None:
            raise RuntimeError("nvenc_settings is required for nvenc_h264 compression")

        codec_value = cfg.codec.strip().lower()
        chroma_value = cfg.chroma_subsampling.strip().lower()
        range_value = self._normalize_range_mode(cfg.range_mode)
        preset_value = cfg.preset.strip()

        codec_requested = None if codec_value == "auto" else nvenc_codec.normalize_codec_name(codec_value)
        chroma_requested = None if chroma_value == "auto" else chroma_value
        range_requested = None if range_value == "auto" else range_value

        if chroma_requested is not None and chroma_requested not in ("420", "444"):
            raise ValueError(
                f"chroma_subsampling must be 'auto', '444', or '420', got {cfg.chroma_subsampling!r}"
            )

        if codec_requested is not None and codec_requested not in ("h264", "hevc", "av1"):
            raise ValueError(f"Unsupported NVENC codec override: {cfg.codec!r}")

        chroma_use = chroma_requested or nvenc_codec.AUTO_NVENC_CHROMA_SUBSAMPLING
        range_use = range_requested or nvenc_codec.AUTO_NVENC_RANGE_MODE
        preset_use = preset_value if preset_value and preset_value.lower() != "auto" else nvenc_codec.AUTO_NVENC_PRESET

        needs_auto_probe = (
            codec_requested is None or chroma_requested is None or range_requested is None
        )

        if not needs_auto_probe:
            self._nvenc_probe_result = None
            return replace(
                cfg,
                codec=codec_requested,
                chroma_subsampling=chroma_use,
                range_mode=range_use,
                preset=preset_use,
            )

        candidate = nvenc_codec.select_auto_nvenc_candidate_for_rgb(
            nvc,
            probe_rgb,
            gpu_id=cfg.gpu_id,
            fps=cfg.fps,
            bitrate_arg=cfg.bitrate_bps,
            preset=preset_use,
            codec_candidates=[codec_requested] if codec_requested is not None else nvenc_codec.AUTO_NVENC_CODEC_CANDIDATES,
            chroma_subsampling=chroma_use,
            full_range=(range_use == "full"),
        )
        self._nvenc_probe_result = candidate
        if candidate is None:
            return None

        return replace(
            cfg,
            codec=str(candidate["codec"]),
            chroma_subsampling=str(candidate["chroma_subsampling"]),
            range_mode="full" if bool(candidate["full_range"]) else "limited",
            preset=str(candidate["preset"]),
        )

    def _plan_stream_outputs(self, probe_frame: int) -> None:
        if self.stream_ids is None:
            raise RuntimeError("stream_ids must be resolved before planning output containers")

        if self.ranged_compression != "nvenc_h264":
            self._resolved_nvenc_settings = None
            self._nvenc_probe_result = None
            self._stream_output_formats = {sid: "avif" for sid in self.stream_ids}
            self._stream_nvenc_bitrates_bps = {}
            return

        from .gpu_policy import nvenc_encode_allowed, nvenc_encoding_usable
        from . import nvenc_codec

        if not nvenc_encode_allowed():
            raise RuntimeError(
                "NVENC ranged compression is disabled. Unset MVDATA_DISABLE_GPU / "
                "MVDATA_DISABLE_NVENC_ENCODE, or use ranged_compression='avif'."
            )
        if not nvenc_encoding_usable():
            raise RuntimeError(
                "NVENC encoding requires PyNvVideoCodec on an NVIDIA driver. "
                "Install optional extra `mvdata[pynvc]` or see NVIDIA's PyNvVideoCodec guide."
            )

        if self.nvenc_settings is None:
            raise RuntimeError("nvenc_settings is required for nvenc_h264 compression")

        nvc = nvenc_codec.try_import_pynvvideocodec()
        probe_reader = self.input_dataset.create_frame_reader(
            stream_ids=self.stream_ids,
            start_frame=probe_frame,
            end_frame=probe_frame,
            max_workers=self.max_workers,
        )
        try:
            _, probe_data = probe_reader.read_frame(probe_frame)
        finally:
            probe_reader.close()

        fallback_reasons: dict[int, str] = {}
        output_formats: dict[int, Literal["avif", "nvenc_h264"]] = {}
        bitrate_map: dict[int, int] = {}
        probe_stream_id = self.stream_ids[0]
        if probe_stream_id not in probe_data:
            raise ValueError(f"Stream {probe_stream_id} missing from probe frame {probe_frame}")
        probe_rgb0 = self._frame_to_uint8_rgb_hwc3(probe_data[probe_stream_id])

        resolved_cfg = self._resolve_nvenc_settings_for_probe(nvc, probe_rgb0)
        self._resolved_nvenc_settings = resolved_cfg
        if resolved_cfg is None:
            self._stream_output_formats = {sid: "avif" for sid in self.stream_ids}
            self._stream_nvenc_bitrates_bps = {}
            print(
                "NVENC auto selection found no verified GPU candidate; "
                "all selected streams will use AVIF"
            )
            return

        if self._nvenc_probe_result is not None:
            print(
                "NVENC auto settings: "
                f"codec={resolved_cfg.codec} chroma={resolved_cfg.chroma_subsampling} "
                f"range={resolved_cfg.range_mode} preset={resolved_cfg.preset} "
                f"probe_decoder={self._nvenc_probe_result['decoder']} "
                f"mean_psnr={self._nvenc_probe_result['mean_psnr']:.2f} dB"
            )
        else:
            print(
                "NVENC settings: "
                f"codec={resolved_cfg.codec} chroma={resolved_cfg.chroma_subsampling} "
                f"range={resolved_cfg.range_mode} preset={resolved_cfg.preset}"
            )

        for sid in self.stream_ids:
            if sid not in probe_data:
                raise ValueError(f"Stream {sid} missing from probe frame {probe_frame}")
            probe_rgb = self._frame_to_uint8_rgb_hwc3(probe_data[sid])
            issue = nvenc_codec.nvenc_encode_compatibility_issue_for_rgb(
                nvc,
                probe_rgb,
                gpu_id=resolved_cfg.gpu_id,
                codec=resolved_cfg.codec,
                chroma_subsampling=resolved_cfg.chroma_subsampling,
            )
            if issue is not None:
                output_formats[sid] = "avif"
                fallback_reasons[sid] = issue
                continue

            output_formats[sid] = "nvenc_h264"
            bitrate_map[sid] = nvenc_codec.resolve_nvenc_bitrate_bps(
                resolved_cfg.bitrate_bps,
                int(probe_rgb.shape[1]),
                int(probe_rgb.shape[0]),
                resolved_cfg.fps,
                chroma_subsampling=resolved_cfg.chroma_subsampling,
            )

        self._stream_output_formats = output_formats
        self._stream_nvenc_bitrates_bps = bitrate_map

        if fallback_reasons:
            print(
                f"NVENC fallback: {len(fallback_reasons)} stream(s) will use AVIF "
                "because GPU encoding is incompatible"
            )
            for sid in sorted(fallback_reasons):
                print(f"  stream {sid}: {fallback_reasons[sid]}")
        else:
            print("NVENC compatibility: all selected streams will use MP4")
    
    def _get_frame_ranges_to_write(self, abs_start: int, abs_end: int) -> List[tuple[int, int, int, int]]:
        """
        Calculate frame ranges for batches.
        
        Args:
            abs_start: Absolute start frame in source dataset
            abs_end: Absolute end frame in source dataset
            
        Returns:
            List of (abs_start, abs_end, output_start, output_end) tuples where:
            - abs_start/abs_end are absolute frame numbers in source dataset
            - output_start/output_end are frame numbers in output dataset
        """
        ranges = []
        
        # Calculate output frame numbers
        if self.maintain_frame_numbers:
            # Keep original frame numbers
            output_offset = abs_start
        else:
            # Start from 0
            output_offset = 0
        
        # Create ranges
        current_abs = abs_start
        current_output = output_offset
        
        while current_abs <= abs_end:
            batch_size = min(self.frames_per_batch, abs_end - current_abs + 1)
            ranges.append((
                current_abs,
                current_abs + batch_size - 1,
                current_output,
                current_output + batch_size - 1
            ))
            current_abs += batch_size
            current_output += batch_size
        
        return ranges
    
    def _split_streams_into_batches(self, stream_ids: List[int]) -> List[List[int]]:
        """
        Split stream IDs into batches for processing.
        
        Args:
            stream_ids: List of all stream IDs to write
            
        Returns:
            List of stream ID batches
        """
        batches = []
        for i in range(0, len(stream_ids), self.streams_per_batch):
            batch = stream_ids[i:i + self.streams_per_batch]
            batches.append(batch)
        return batches
    
    def _copy_meta_folder(self):
        super()._copy_meta_folder()

    @staticmethod
    def _remove_output_path(path: Path) -> None:
        if not path.exists():
            return
        if path.is_dir():
            shutil.rmtree(path)
            return
        path.unlink()

    @staticmethod
    def _serialize_resume_value(value: Any) -> Any:
        if isinstance(value, Enum):
            return value.name
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        if isinstance(value, list):
            return [RangedDatasetWriter._serialize_resume_value(item) for item in value]
        if isinstance(value, tuple):
            return [RangedDatasetWriter._serialize_resume_value(item) for item in value]
        if isinstance(value, dict):
            return {
                str(key): RangedDatasetWriter._serialize_resume_value(item)
                for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
            }
        return repr(value)

    def _serialize_encoder_options(self) -> dict[str, Any]:
        serialized: dict[str, Any] = {}
        for name in sorted(dir(self.encoder_options)):
            if name.startswith("_") or name == "max_threads":
                continue
            value = getattr(self.encoder_options, name)
            if callable(value):
                continue
            serialized[name] = self._serialize_resume_value(value)
        return serialized
    
    def _resumable_config(self):
        return {
            **super()._resumable_config(),
            "frames_per_batch": self.frames_per_batch,
            "streams_per_batch": self.streams_per_batch,
            "stream_ids": self.stream_ids,
            "start_frame": self.start_frame,
            "end_frame": self.end_frame,
            "maintain_frame_numbers": self.maintain_frame_numbers,
            "ranged_compression": self.ranged_compression,
            "encoder_options": self._serialize_encoder_options(),
            "nvenc_settings": self._serialize_nvenc_settings(),
            "resolved_nvenc_settings": self._serialize_resolved_nvenc_settings(),
            "stream_output_formats": self._serialize_resume_value(self._stream_output_formats),
            "stream_nvenc_bitrates_bps": self._serialize_resume_value(
                self._stream_nvenc_bitrates_bps
            ),
        }

    @staticmethod
    def _unit_id(batch_idx: int, range_name: str) -> str:
        return f"sb{batch_idx}/{range_name}"

    @staticmethod
    def _meta_unit_id() -> str:
        return "aux/meta"

    def _stash_unit_id(self) -> Optional[str]:
        if self.stash_policy == "copy":
            return "aux/stash-copy"
        if self.stash_policy == "generate":
            return "aux/stash-generate"
        return None

    def _run_resumable_step(
        self,
        progress: WriteProgress,
        unit_id: str,
        action,
    ) -> None:
        if progress.is_done(unit_id):
            return
        progress.begin(unit_id)
        action()
        progress.complete(unit_id)

    def _batch_range_has_all_avifs(
        self, stream_batch: List[int], out_start: int, out_end: int
    ) -> bool:
        """Check if all expected AVIFs exist with non-zero size on disk.

        Used once during bootstrap when resuming without a prior progress file.
        """
        rgb_dir = self.output_path / self._format_range_name(out_start, out_end) / "rgb"
        if not rgb_dir.exists():
            return False
        for stream_id in stream_batch:
            p = rgb_dir / self._format_stream_name(stream_id)
            if not p.exists() or p.stat().st_size == 0:
                return False
        return True

    def _format_frame_name(self, frame_num: int) -> str:
        """Format frame folder name with 8-digit zero padding."""
        return f"{frame_num:08d}"
    
    def write(self) -> RangedDataset:
        """
        Write the dataset in Ranged convention format.
        
        Returns:
            Instance of the newly created RangedDataset
        """
        # Create output directory
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        # Get all available frame ranges from input dataset
        input_ranges = self.input_dataset.get_frame_ranges()
        if not input_ranges:
            raise ValueError("Input dataset has no frame ranges")
        
        # Determine dataset bounds
        dataset_min_frame = input_ranges[0][0]
        dataset_max_frame = input_ranges[-1][1]
        
        # Determine actual range to process
        actual_start = self.start_frame if self.start_frame is not None else dataset_min_frame
        actual_end = self.end_frame if self.end_frame is not None else dataset_max_frame
        
        # Validate range
        if actual_start < dataset_min_frame or actual_end > dataset_max_frame:
            raise ValueError(
                f"Requested range [{actual_start}, {actual_end}] outside "
                f"dataset range [{dataset_min_frame}, {dataset_max_frame}]"
            )
        
        if actual_start > actual_end:
            raise ValueError(
                f"Invalid range: start_frame ({actual_start}) > end_frame ({actual_end})"
            )
        
        total_frames = actual_end - actual_start + 1
        
        print(f"Input dataset frame range: [{dataset_min_frame}, {dataset_max_frame}]")
        print(f"Processing frame range: [{actual_start}, {actual_end}] ({total_frames} frames)")
        print(f"Frame numbering: {'maintain original' if self.maintain_frame_numbers else 'start from 0'}")
        
        # Get stream IDs to write
        if self.stream_ids is None:
            self.stream_ids = self.input_dataset.stream_ids
        
        print(f"Writing {len(self.stream_ids)} streams: {self.stream_ids}")
        self._plan_stream_outputs(actual_start)
        nvenc_streams = [
            sid for sid in self.stream_ids if self._stream_output_format(sid) == "nvenc_h264"
        ]
        avif_streams = [
            sid for sid in self.stream_ids if self._stream_output_format(sid) == "avif"
        ]
        if self.ranged_compression == "nvenc_h264":
            print(
                f"Output containers: {len(nvenc_streams)} MP4 stream(s), "
                f"{len(avif_streams)} AVIF stream(s)"
            )
        
        # Split streams into batches
        stream_batches = self._split_streams_into_batches(self.stream_ids)
        print(f"Processing {len(stream_batches)} stream batches of up to {self.streams_per_batch} streams each")
        
        # Calculate output ranges
        output_ranges = self._get_frame_ranges_to_write(actual_start, actual_end)
        print(f"Will create {len(output_ranges)} range folders of up to {self.frames_per_batch} frames each")
        
        # --- progress tracking ---
        if self.resume:
            manifest_path = WriteProgress.manifest_path(self.output_path)
            if manifest_path.exists():
                progress = WriteProgress.load_or_create(
                    self.output_path,
                    writer_name=type(self).__name__,
                    config=self._resumable_config(),
                )
            elif any(self.output_path.iterdir()):
                raise ValueError(
                    "Cannot resume: progress manifest is missing from a non-empty output dataset.\n"
                    f"  {manifest_path}\n\n"
                    "Refusing to infer progress from existing files because stale range folders "
                    "can silently produce a mixed dataset.\n"
                    "To start fresh, delete the existing output dataset:\n"
                    f"  {self.output_path}"
                )
            else:
                progress = WriteProgress.create_fresh(
                    self.output_path,
                    writer_name=type(self).__name__,
                    config=self._resumable_config(),
                )
        else:
            progress = WriteProgress.create_fresh(
                self.output_path,
                writer_name=type(self).__name__,
                config=self._resumable_config(),
            )

        # Process each stream batch
        for stream_batch_idx, stream_batch in enumerate(stream_batches):
            print(f"\nProcessing stream batch {stream_batch_idx + 1}/{len(stream_batches)}: {stream_batch}")
            
            for abs_start, abs_end, out_start, out_end in tqdm(
                output_ranges,
                desc=f"  Writing ranges for streams {stream_batch}"
            ):
                unit = self._unit_id(stream_batch_idx, self._format_range_name(out_start, out_end))
                if progress.is_done(unit):
                    continue
                progress.begin(unit)
                self._write_stream_batch_for_range(
                    stream_batch, abs_start, abs_end, out_start, out_end
                )
                progress.complete(unit)
        
        if progress.skipped > 0:
            print(f"\nResume: skipped {progress.skipped} already-completed units")
        
        # Copy meta and stash folders if requested.
        # These are tracked as explicit progress units so an interrupted copy
        # or generation reruns from a clean directory on resume.
        if self.copy_meta:
            self._run_resumable_step(progress, self._meta_unit_id(), self._copy_meta_folder)
        
        stash_unit_id = self._stash_unit_id()
        if stash_unit_id is not None:
            def _restore_stash() -> None:
                self._remove_output_path(self.output_path / "stash")
                if self.stash_policy == "copy":
                    self._copy_stash_folder(
                        stream_ids=self.stream_ids,
                        start_frame=actual_start,
                        end_frame=actual_end,
                        maintain_frame_numbers=self.maintain_frame_numbers,
                    )
                else:
                    self._generate_stash_from_reader(
                        stream_ids=self.stream_ids,
                        start_frame=actual_start,
                        end_frame=actual_end,
                        maintain_frame_numbers=self.maintain_frame_numbers,
                    )

            self._run_resumable_step(progress, stash_unit_id, _restore_stash)
        
        progress.finish()
        print(f"\nSuccessfully created Ranged dataset at {self.output_path}")
        
        # Return instance of the created dataset
        return RangedDataset(self.output_path, max_workers=self.max_workers)
    
    def _write_stream_batch_for_range(self, stream_batch: List[int], 
                                       abs_start: int, abs_end: int,
                                       out_start: int, out_end: int):
        mp4_streams = [
            sid for sid in stream_batch if self._stream_output_format(sid) == "nvenc_h264"
        ]
        avif_streams = [
            sid for sid in stream_batch if self._stream_output_format(sid) == "avif"
        ]

        if avif_streams:
            self._write_stream_batch_for_range_avif(
                avif_streams, abs_start, abs_end, out_start, out_end
            )
        if mp4_streams:
            self._write_stream_batch_for_range_nvenc(
                mp4_streams, abs_start, abs_end, out_start, out_end
            )

    def _write_stream_batch_for_range_avif(self, stream_batch: List[int], 
                                           abs_start: int, abs_end: int,
                                           out_start: int, out_end: int):
        """
        Write a batch of streams for a single range.
        
        This processes all frames for a subset of streams, which is more memory-efficient
        than trying to process all streams simultaneously.
        
        Args:
            stream_batch: List of stream IDs to process in this batch
            abs_start: Absolute start frame in input dataset
            abs_end: Absolute end frame in input dataset
            out_start: Output start frame number
            out_end: Output end frame number
        """
        # Create range folder
        range_name = self._format_range_name(out_start, out_end)
        range_dir = self.output_path / range_name
        rgb_dir = range_dir / "rgb"
        rgb_dir.mkdir(parents=True, exist_ok=True)
        
        # Create frame reader for this range
        reader = self.input_dataset.create_frame_reader(
            stream_ids=stream_batch,
            start_frame=abs_start,
            end_frame=abs_end,
            max_workers=self.max_workers,
        )
        
        # Prepare output paths for streams in this batch
        output_paths = []
        for stream_id in stream_batch:
            stream_filename = self._format_stream_name(stream_id)
            stream_path = rgb_dir / stream_filename
            output_paths.append(str(stream_path))
        
        # Create batch encoder for these streams
        batch_encoder = BatchEncoder(
            output_paths,
            self.encoder_options
        )
        
        decode_time = 0.0
        prep_time = 0.0
        encode_time = 0.0
        wait_time = 0.0
        finish_time = 0.0
        total_start = time.perf_counter()
        prefetch_thread = None

        def _encode_frame(frame_idx: int, frame_data: dict):
            nonlocal prep_time, encode_time
            prep_start = time.perf_counter()
            frames = []
            for stream_id in stream_batch:
                if stream_id not in frame_data:
                    raise ValueError(
                        f"Stream {stream_id} not found in frame {frame_idx}. "
                        f"Available streams: {list(frame_data.keys())}"
                    )
                frame = frame_data[stream_id]

                if not isinstance(frame, np.ndarray):
                    raise ValueError(f"Expected numpy array, got {type(frame)}")

                frames.append(frame)
            prep_time += time.perf_counter() - prep_start

            enc_start = time.perf_counter()
            batch_encoder.add_image_batch(frames, duration=1)
            encode_time += time.perf_counter() - enc_start

        try:
            if self.prefetch_frames > 0:
                frame_queue: Queue = Queue(maxsize=self.prefetch_frames)
                decode_time_accum = [0.0]
                error_holder = {}
                stop_event = Event()

                def _queue_put(item) -> bool:
                    while not stop_event.is_set():
                        try:
                            frame_queue.put(item, timeout=0.1)
                            return True
                        except Full:
                            continue
                    return False

                def _producer():
                    local_decode = 0.0
                    try:
                        for frame_idx in range(abs_start, abs_end + 1):
                            if stop_event.is_set():
                                break
                            t0 = time.perf_counter()
                            _, frame_data = reader.read_frame(frame_idx)
                            local_decode += time.perf_counter() - t0
                            if not _queue_put((frame_idx, frame_data)):
                                break
                    except Exception as e:
                        error_holder["error"] = e
                    finally:
                        decode_time_accum[0] += local_decode
                        _queue_put(None)

                prefetch_thread = Thread(
                    target=_producer, name="ranged_writer_prefetch", daemon=True
                )
                prefetch_thread.start()

                while True:
                    wait_start = time.perf_counter()
                    try:
                        item = frame_queue.get(timeout=0.1)
                    except Empty:
                        if "error" in error_holder and not prefetch_thread.is_alive():
                            raise error_holder["error"]
                        continue
                    wait_time += time.perf_counter() - wait_start
                    if item is None:
                        break
                    frame_idx, frame_data = item
                    try:
                        _encode_frame(frame_idx, frame_data)
                    except Exception:
                        stop_event.set()
                        raise

                decode_time = decode_time_accum[0]
                if "error" in error_holder:
                    raise error_holder["error"]
            else:
                for frame_idx in range(abs_start, abs_end + 1):
                    t0 = time.perf_counter()
                    _, frame_data = reader.read_frame(frame_idx)
                    decode_time += time.perf_counter() - t0
                    _encode_frame(frame_idx, frame_data)
        finally:
            stop_event = locals().get("stop_event")
            if stop_event is not None:
                stop_event.set()
            reader.close()
            if prefetch_thread is not None:
                prefetch_thread.join(timeout=2.0)

            finish_error = None
            if batch_encoder is not None:
                finish_start = time.perf_counter()
                try:
                    batch_encoder.finish_all()
                except Exception as e:
                    finish_error = e
                finish_time = time.perf_counter() - finish_start

                close_fn = getattr(batch_encoder, "close", None)
                if callable(close_fn):
                    try:
                        close_fn()
                    except Exception as e:
                        if finish_error is None:
                            finish_error = e

                batch_encoder = None
                gc.collect()

            if finish_error is not None and sys.exc_info()[0] is None:
                raise finish_error

        total_time = time.perf_counter() - total_start

        if self.debug_timing:
            other_time = total_time - (decode_time + prep_time + encode_time + finish_time)
            print(
                f"  Timing {range_name} streams={stream_batch}: "
                f"total={total_time:.3f}s decode={decode_time:.3f}s "
                f"prep={prep_time:.3f}s encode={encode_time:.3f}s "
                f"finish={finish_time:.3f}s wait={wait_time:.3f}s other={other_time:.3f}s"
            )

    @staticmethod
    def _frame_to_uint8_rgb_hwc3(frame: np.ndarray) -> np.ndarray:
        if not isinstance(frame, np.ndarray):
            raise ValueError(f"Expected numpy array, got {type(frame)}")
        if frame.dtype != np.uint8:
            frame = np.clip(frame, 0, 255).astype(np.uint8)
        if frame.ndim == 2:
            raise ValueError("Unexpected 2D frame")
        if frame.shape[2] == 4:
            frame = frame[:, :, :3]
        elif frame.shape[2] != 3:
            raise ValueError(f"Expected 3-channel RGB, got shape {frame.shape}")
        return frame

    def _write_stream_batch_for_range_nvenc(
        self,
        stream_batch: List[int],
        abs_start: int,
        abs_end: int,
        out_start: int,
        out_end: int,
    ) -> None:
        """NVENC path: stream frames one at a time through the encoder.

        Each stream is encoded independently.  Frames are yielded from a
        generator so peak memory is O(H*W*3) instead of O(N*H*W*3).
        """
        from .gpu_policy import nvenc_encode_allowed, nvenc_encoding_usable
        from . import nvenc_codec

        if not nvenc_encode_allowed():
            raise RuntimeError(
                "NVENC ranged compression is disabled. Unset MVDATA_DISABLE_GPU / "
                "MVDATA_DISABLE_NVENC_ENCODE, or use ranged_compression='avif'."
            )
        if not nvenc_encoding_usable():
            raise RuntimeError(
                "NVENC encoding requires PyNvVideoCodec on an NVIDIA driver. "
                "Install optional extra `mvdata[pynvc]` or see NVIDIA's PyNvVideoCodec guide."
            )

        cfg = self._resolved_nvenc_settings or self.nvenc_settings
        if cfg is None:
            raise RuntimeError("nvenc_settings is required for nvenc_h264 compression")
        nvc = nvenc_codec.try_import_pynvvideocodec()
        full_range = self._normalize_range_mode(cfg.range_mode) == "full"

        range_name = self._format_range_name(out_start, out_end)
        range_dir = self.output_path / range_name
        rgb_dir = range_dir / "rgb"
        rgb_dir.mkdir(parents=True, exist_ok=True)

        total_start = time.perf_counter()
        decode_time = 0.0
        n_frames = abs_end - abs_start + 1
        used_bitrates_bps: list[int] = []

        for sid in stream_batch:
            bitrate_use = self._stream_nvenc_bitrates_bps.get(sid)
            if bitrate_use is None:
                raise RuntimeError(f"Missing planned NVENC bitrate for stream {sid}")
            used_bitrates_bps.append(bitrate_use)
            reader = self.input_dataset.create_frame_reader(
                stream_ids=[sid],
                start_frame=abs_start,
                end_frame=abs_end,
                max_workers=self.max_workers,
            )

            def _frame_gen(rd=reader, stream_id=sid):
                nonlocal decode_time
                try:
                    for frame_idx in range(abs_start, abs_end + 1):
                        t0 = time.perf_counter()
                        _, frame_data = rd.read_frame(frame_idx)
                        decode_time += time.perf_counter() - t0
                        if stream_id not in frame_data:
                            raise ValueError(
                                f"Stream {stream_id} not in frame {frame_idx}: "
                                f"{list(frame_data.keys())}"
                            )
                        yield np.ascontiguousarray(
                            self._frame_to_uint8_rgb_hwc3(frame_data[stream_id])
                        )
                finally:
                    rd.close()

            out_mp4 = rgb_dir / self._format_stream_name(sid)
            nvenc_codec.encode_rgb_iter_to_mp4(
                nvc,
                _frame_gen(),
                out_mp4,
                gpu_id=cfg.gpu_id,
                fps=cfg.fps,
                bitrate=bitrate_use,
                codec=cfg.codec,
                full_range=full_range,
                chroma_subsampling=cfg.chroma_subsampling,
                preset=cfg.preset,
            )
            gc.collect()

        if self.debug_timing:
            total_time = time.perf_counter() - total_start
            bitrate_labels = sorted({f"{bps / 1e6:.2f}" for bps in used_bitrates_bps})
            bps_str = ",".join(bitrate_labels) if bitrate_labels else "?"
            print(
                f"  NVENC {range_name} streams={stream_batch}: "
                f"total={total_time:.3f}s decode={decode_time:.3f}s "
                f"frames/stream={n_frames} bitrate={bps_str}Mbps"
            )
