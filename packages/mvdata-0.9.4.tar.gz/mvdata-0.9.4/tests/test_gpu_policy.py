import mvdata.gpu_policy as gpu_policy


def test_gpu_enabled_false_forces_cpu_only_paths():
    gpu_policy.clear_gpu_override()
    try:
        assert gpu_policy.gpu_usage_allowed() is True

        gpu_policy.gpu_enabled(False)

        assert gpu_policy.gpu_enabled_override() is False
        assert gpu_policy.gpu_usage_allowed() is False
        assert gpu_policy.nvenc_encode_allowed() is False
        assert gpu_policy.nvdec_decode_allowed() is False
    finally:
        gpu_policy.clear_gpu_override()


def test_gpu_disabled_context_restores_previous_override():
    gpu_policy.clear_gpu_override()
    try:
        gpu_policy.gpu_enabled(True)
        assert gpu_policy.gpu_enabled_override() is True

        with gpu_policy.gpu_enabled(False):
            assert gpu_policy.gpu_enabled_override() is False
            assert gpu_policy.gpu_usage_allowed() is False

        assert gpu_policy.gpu_enabled_override() is True
        assert gpu_policy.gpu_usage_allowed() is True
    finally:
        gpu_policy.clear_gpu_override()


def test_gpu_disabled_helper_still_restores_previous_override():
    gpu_policy.clear_gpu_override()
    try:
        gpu_policy.gpu_enabled(True)

        with gpu_policy.gpu_disabled():
            assert gpu_policy.gpu_enabled_override() is False
            assert gpu_policy.gpu_usage_allowed() is False

        assert gpu_policy.gpu_enabled_override() is True
        assert gpu_policy.gpu_usage_allowed() is True
    finally:
        gpu_policy.clear_gpu_override()


def test_gpu_enabled_true_does_not_override_env_disable(monkeypatch):
    monkeypatch.setenv("MVDATA_DISABLE_GPU", "1")
    gpu_policy.clear_gpu_override()
    try:
        gpu_policy.gpu_enabled(True)

        assert gpu_policy.gpu_enabled_override() is True
        assert gpu_policy.gpu_usage_allowed() is False
        assert gpu_policy.gpu_nvenc_disabled_globally() is True
        assert gpu_policy.nvenc_encode_allowed() is False
        assert gpu_policy.nvdec_decode_allowed() is False
    finally:
        gpu_policy.clear_gpu_override()
