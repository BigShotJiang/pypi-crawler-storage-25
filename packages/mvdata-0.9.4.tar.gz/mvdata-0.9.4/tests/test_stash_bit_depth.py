from __future__ import annotations

from pathlib import Path

import av
import numpy as np
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for ranged stash tests")

from mvdata.dataset_base import FrameReader
import mvdata.multivideo as multivideo_mod
import mvdata.nvenc_codec as nvenc_codec
import mvdata.ranged as ranged_mod


class _SingleFrameReader(FrameReader):
    def __init__(self, frame_data: dict[int, np.ndarray], bit_depth: int):
        super().__init__(0, 0)
        self._frame_data = frame_data
        self._bit_depth = bit_depth

    def read_frame(self, frame_index: int):
        return frame_index, self._frame_data

    def prepare_next_frame(self):
        pass

    def close(self) -> None:
        pass

    def get_bit_depth(self) -> int:
        return self._bit_depth

    @property
    def supports_random_access(self) -> bool:
        return True


def _read_png_rgb48le(path: Path) -> np.ndarray:
    with av.open(str(path)) as container:
        frame = next(container.decode(video=0))
        return frame.to_ndarray(format="rgb48le")


def test_multivideo_generate_stash_frames_preserves_uint16_png(monkeypatch, tmp_path):
    dataset_path = tmp_path / "multivideo"
    dataset_path.mkdir()

    dataset = multivideo_mod.MultiVideoDataset(dataset_path, respect_timestamps=False)
    dataset._initialized = True
    dataset._stream_ids_cache = [1]
    dataset._stream_to_raw_name = {1: "001.mp4"}
    dataset._stream_to_video_path = {1: dataset_path / "001.mp4"}
    dataset._video_info_cache = {
        1: {
            "frame_count": 1,
            "fps": 30.0,
            "duration": 1 / 30,
            "codec": "hevc",
            "width": 2,
            "height": 2,
            "bit_depth": 10,
            "start_time": 0.0,
            "time_base": 1 / 30,
        }
    }
    dataset._frame_ranges_cache = [(0, 0, {"sync_mode": "frame_index", "min_frame_count": 1})]

    frame = np.zeros((2, 2, 3), dtype=np.uint16)
    frame[0, 0] = [65535, 12345, 0]

    monkeypatch.setattr(
        dataset,
        "create_frame_reader",
        lambda **kwargs: _SingleFrameReader({1: frame}, bit_depth=10),
    )

    generated = dataset.generate_stash_frames(1, verbose=False)

    assert generated == [0]
    output_path = dataset_path / "stash" / "00000000" / "rgb" / "001.png"
    decoded = _read_png_rgb48le(output_path)
    assert decoded.dtype == np.uint16
    assert decoded.shape == frame.shape
    assert np.array_equal(decoded, frame)


def test_ranged_generate_stash_frames_preserves_uint16_mp4_png(monkeypatch, tmp_path):
    dataset_path = tmp_path / "ranged"
    rgb_dir = dataset_path / "00000000_00000000" / "rgb"
    rgb_dir.mkdir(parents=True)
    (rgb_dir / "000.mp4").write_bytes(b"fake mp4")

    dataset = ranged_mod.RangedDataset(dataset_path)

    frame = np.zeros((2, 2, 3), dtype=np.uint16)
    frame[0, 0] = [65535, 22222, 11111]

    monkeypatch.setattr(nvenc_codec, "probe_video_bit_depth", lambda path: 10)
    monkeypatch.setattr(
        dataset,
        "create_frame_reader",
        lambda **kwargs: _SingleFrameReader({0: frame}, bit_depth=10),
    )

    generated = dataset.generate_stash_frames(1, verbose=False)

    assert generated == [0]
    output_path = dataset_path / "stash" / "00000000" / "rgb" / "000.png"
    decoded = _read_png_rgb48le(output_path)
    assert decoded.dtype == np.uint16
    assert decoded.shape == frame.shape
    assert np.array_equal(decoded, frame)
