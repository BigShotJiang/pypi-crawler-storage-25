from __future__ import annotations

import math

import numpy as np

from mvdata.image_metrics import calculate_psnr


def test_calculate_psnr_uses_uint16_peak_by_default():
    a = np.zeros((2, 2, 3), dtype=np.uint16)
    b = a.copy()
    b[0, 0, 0] = 1

    psnr = calculate_psnr(a, b)

    expected = 20.0 * math.log10(65535.0 / math.sqrt((1.0 / 12.0)))
    assert math.isclose(psnr, expected)
