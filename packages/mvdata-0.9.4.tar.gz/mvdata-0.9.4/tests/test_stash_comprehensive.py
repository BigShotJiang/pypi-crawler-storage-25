"""Comprehensive tests for stash policy handling.

Tests cover:
- stash_policy="ignore": all source datasets, with/without existing stash
- stash_policy="copy": error on absent stash, naming normalization
- stash_policy="generate": agnostic file copy for Legacy, decode for others
"""

import filecmp
import numpy as np
from pathlib import Path
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for stash tests")
pytest.importorskip("av", reason="PyAV is required for stash tests")

from mvdata import (
    LegacyDataset,
    LegacyDatasetWriter,
    RangedDataset,
    RangedDatasetWriter,
    MultiVideoDataset,
    MultiVideoDatasetWriter,
)


# =============================================================================
# Test Data Generators
# =============================================================================


def create_test_image(width: int = 32, height: int = 32, seed: int = 0) -> np.ndarray:
    """Create a deterministic test image."""
    rng = np.random.default_rng(seed)
    return rng.integers(0, 256, (height, width, 3), dtype=np.uint8)


def create_legacy_dataset(
    path: Path,
    num_frames: int = 5,
    num_streams: int = 2,
    image_format: str = "png",
    use_rgb_subfolder: bool = True,
) -> Path:
    """Create a Legacy dataset with customizable structure."""
    for frame_idx in range(num_frames):
        if use_rgb_subfolder:
            frame_dir = path / f"{frame_idx:08d}" / "rgb"
        else:
            frame_dir = path / f"{frame_idx:08d}"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            img = create_test_image(seed=frame_idx * 100 + stream_id)
            img_pil = Image.fromarray(img, mode="RGB")
            img_pil.save(frame_dir / f"{stream_id:03d}.{image_format}")

    return path


def create_legacy_stash(
    dataset_path: Path,
    frame_numbers: list,
    num_streams: int = 2,
    image_format: str = "png",
    use_rgb_subfolder: bool = True,
    use_canonical_naming: bool = True,
) -> None:
    """Create stash frames with customizable structure and naming."""
    stash_dir = dataset_path / "stash"

    for frame_num in frame_numbers:
        if use_rgb_subfolder:
            frame_dir = stash_dir / f"{frame_num:08d}" / "rgb"
        else:
            frame_dir = stash_dir / f"{frame_num:08d}"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            img = create_test_image(seed=frame_num * 1000 + stream_id)
            img_pil = Image.fromarray(img, mode="RGB")

            if use_canonical_naming:
                filename = f"{stream_id:03d}.{image_format}"
            else:
                # Non-canonical naming: cam_X.ext or just X.ext without padding
                filename = f"cam_{stream_id}.{image_format}"

            img_pil.save(frame_dir / filename)


def _make_encoder_options():
    """Create encoder options for ranged dataset."""
    from pyavif import EncoderOptions
    opts = EncoderOptions()
    opts.quality = 80
    opts.speed = 8
    return opts


def create_ranged_dataset(tmp_path: Path, num_frames: int = 5, num_streams: int = 2) -> RangedDataset:
    """Create a Ranged dataset from a temporary Legacy dataset."""
    legacy_path = tmp_path / "legacy_source"
    create_legacy_dataset(legacy_path, num_frames, num_streams)
    legacy_ds = LegacyDataset(legacy_path)

    ranged_path = tmp_path / "ranged_output"
    writer = RangedDatasetWriter(
        legacy_ds,
        ranged_path,
        frames_per_batch=num_frames,
        encoder_options=_make_encoder_options(),
        stash_policy="ignore",
        max_workers=2,
    )
    return writer.write()


def create_multivideo_dataset(tmp_path: Path, num_frames: int = 5, num_streams: int = 2) -> MultiVideoDataset:
    """Create a MultiVideo dataset from a temporary Legacy dataset."""
    legacy_path = tmp_path / "legacy_source"
    create_legacy_dataset(legacy_path, num_frames, num_streams)
    legacy_ds = LegacyDataset(legacy_path)

    mv_path = tmp_path / "multivideo_output"
    writer = MultiVideoDatasetWriter(
        legacy_ds,
        mv_path,
        video_codec="h264",
        fps=30,
        crf=28,
        preset="ultrafast",
        stash_policy="ignore",
        max_workers=2,
    )
    return writer.write()


# =============================================================================
# Tests: stash_policy="ignore"
# =============================================================================


class TestStashIgnore:
    """Tests for stash_policy='ignore' - should never include stash."""

    @pytest.mark.parametrize("has_existing_stash", [True, False])
    def test_legacy_to_legacy_ignore(self, tmp_path, has_existing_stash):
        """Legacy -> Legacy with ignore policy should have no stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        if has_existing_stash:
            create_legacy_stash(input_path, [0, 2])
            assert len(input_ds.get_stash_frames()) > 0

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="ignore",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 0

    @pytest.mark.parametrize("has_existing_stash", [True, False])
    def test_legacy_to_ranged_ignore(self, tmp_path, has_existing_stash):
        """Legacy -> Ranged with ignore policy should have no stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        if has_existing_stash:
            create_legacy_stash(input_path, [0, 2])

        output_path = tmp_path / "output"
        writer = RangedDatasetWriter(
            input_ds, output_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="ignore",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 0

    @pytest.mark.parametrize("has_existing_stash", [True, False])
    def test_legacy_to_multivideo_ignore(self, tmp_path, has_existing_stash):
        """Legacy -> MultiVideo with ignore policy should have no stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        if has_existing_stash:
            create_legacy_stash(input_path, [0, 2])

        output_path = tmp_path / "output"
        writer = MultiVideoDatasetWriter(
            input_ds, output_path,
            video_codec="h264",
            fps=30,
            crf=28,
            preset="ultrafast",
            stash_policy="ignore",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 0

    def test_ranged_to_legacy_ignore(self, tmp_path):
        """Ranged -> Legacy with ignore policy should have no stash."""
        ranged_ds = create_ranged_dataset(tmp_path / "ranged")

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            ranged_ds, output_path,
            stash_policy="ignore",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 0

    def test_multivideo_to_legacy_ignore(self, tmp_path):
        """MultiVideo -> Legacy with ignore policy should have no stash."""
        mv_ds = create_multivideo_dataset(tmp_path / "mv")

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            mv_ds, output_path,
            stash_policy="ignore",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 0


# =============================================================================
# Tests: stash_policy="copy"
# =============================================================================


class TestStashCopy:
    """Tests for stash_policy='copy' - copy existing stash with normalization."""

    def test_copy_raises_error_when_no_stash(self, tmp_path):
        """Copy policy should raise error if source has no stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        assert len(input_ds.get_stash_frames()) == 0

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            image_format="png",
            max_workers=2,
        )

        with pytest.raises(ValueError, match="Cannot copy stash.*no stash frames"):
            writer.write()

    def test_copy_basic(self, tmp_path):
        """Basic copy should preserve stash frame numbers."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)
        create_legacy_stash(input_path, [0, 2, 4])

        input_frames = [fn for fn, _ in input_ds.get_stash_frames()]

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        assert sorted(output_frames) == sorted(input_frames)

    def test_copy_normalizes_non_rgb_subfolder(self, tmp_path):
        """Copy should normalize stash without rgb subfolder to use rgb/."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        # Create stash WITHOUT rgb subfolder (deviation)
        create_legacy_stash(input_path, [0, 2], use_rgb_subfolder=False)

        # Verify source stash images are NOT in rgb subfolder
        src_stash = input_ds.get_stash_frames()
        for _, stream_map in src_stash:
            for _, path in stream_map.items():
                # Parent should be the frame folder, not rgb
                assert path.parent.name != "rgb"

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Verify output stash images ARE in rgb subfolder (normalized)
        out_stash = output_ds.get_stash_frames()
        for _, stream_map in out_stash:
            for _, path in stream_map.items():
                assert path.parent.name == "rgb"

    def test_copy_normalizes_non_canonical_stream_names(self, tmp_path):
        """Copy should normalize non-canonical stream names to 3-digit padding."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        # Create stash with non-canonical naming (cam_X.png instead of XXX.png)
        create_legacy_stash(input_path, [0, 2], use_canonical_naming=False)

        # Verify source has non-canonical names
        src_stash = input_ds.get_stash_frames()
        for _, stream_map in src_stash:
            for _, path in stream_map.items():
                assert "cam_" in path.name

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Verify output has canonical names (3-digit padding)
        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) > 0
        for _, stream_map in out_stash:
            for stream_id, path in stream_map.items():
                expected_name = f"{stream_id:03d}.png"
                assert path.name == expected_name

    def test_copy_normalizes_tif_to_tiff(self, tmp_path):
        """Copy should normalize .tif extension to .tiff."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path)
        input_ds = LegacyDataset(input_path)

        # Create stash with .tif extension
        create_legacy_stash(input_path, [0], image_format="tif")

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Verify output uses .tiff extension
        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) > 0
        for _, stream_map in out_stash:
            for _, path in stream_map.items():
                assert path.suffix == ".tiff"

    def test_copy_preserves_supported_formats(self, tmp_path):
        """Copy should preserve supported image formats (PNG, JPG, TIFF)."""
        for fmt in ["png", "jpg", "tiff"]:
            input_path = tmp_path / f"input_{fmt}"
            create_legacy_dataset(input_path)
            input_ds = LegacyDataset(input_path)
            create_legacy_stash(input_path, [0], image_format=fmt)

            output_path = tmp_path / f"output_{fmt}"
            writer = LegacyDatasetWriter(
                input_ds, output_path,
                stash_policy="copy",
                image_format="png",  # Main dataset format doesn't affect stash
                max_workers=2,
            )
            output_ds = writer.write()

            out_stash = output_ds.get_stash_frames()
            assert len(out_stash) > 0
            for _, stream_map in out_stash:
                for _, path in stream_map.items():
                    assert path.suffix == f".{fmt}"

    def test_copy_filters_by_frame_range(self, tmp_path):
        """Copy should only include stash frames within the conversion range."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=10)
        input_ds = LegacyDataset(input_path)
        create_legacy_stash(input_path, [0, 3, 6, 9])

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            start_frame=2,
            end_frame=7,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Only frames 3 and 6 should be in output (within range 2-7)
        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        assert sorted(output_frames) == [3, 6]

    def test_copy_respects_maintain_frame_numbers(self, tmp_path):
        """Copy with maintain_frame_numbers=False should renumber stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=10)
        input_ds = LegacyDataset(input_path)
        create_legacy_stash(input_path, [5, 7])

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="copy",
            start_frame=5,
            end_frame=9,
            maintain_frame_numbers=False,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Frames should be renumbered: 5->0, 7->2
        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        assert sorted(output_frames) == [0, 2]


# =============================================================================
# Tests: stash_policy="generate"
# =============================================================================


class TestStashGenerate:
    """Tests for stash_policy='generate' - agnostic generation."""

    def test_generate_creates_correct_number_of_frames(self, tmp_path):
        """Generate should create the specified number of stash frames."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=10)
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=3,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        assert len(output_ds.get_stash_frames()) == 3

    def test_generate_evenly_distributed_frames(self, tmp_path):
        """Generate should select evenly distributed frames."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=10)
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=3,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Should be evenly distributed: 0, 4 or 5, 9
        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        assert output_frames[0] == 0
        assert output_frames[-1] == 9

    def test_generate_legacy_uses_direct_copy(self, tmp_path):
        """Generate from Legacy should use direct file copy (agnostic)."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=5, image_format="png")
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=2,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Verify stash was created
        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) == 2

        # Verify files are byte-identical to source (direct copy)
        for frame_num, stream_map in out_stash:
            source_paths = input_ds.get_frame_source_paths(frame_num)
            assert source_paths is not None

            for stream_id, out_path in stream_map.items():
                src_path = source_paths[stream_id]
                assert filecmp.cmp(src_path, out_path, shallow=False), \
                    f"Stash file should be byte-identical to source for Legacy"

    def test_generate_legacy_preserves_source_format(self, tmp_path):
        """Generate from Legacy should preserve source image format."""
        for fmt in ["png", "jpg", "tiff"]:
            input_path = tmp_path / f"input_{fmt}"
            create_legacy_dataset(input_path, num_frames=3, image_format=fmt)
            input_ds = LegacyDataset(input_path)

            output_path = tmp_path / f"output_{fmt}"
            writer = LegacyDatasetWriter(
                input_ds, output_path,
                stash_policy="generate",
                stash_num_frames=1,
                image_format="png",  # Main format shouldn't affect stash
                max_workers=2,
            )
            output_ds = writer.write()

            out_stash = output_ds.get_stash_frames()
            assert len(out_stash) == 1
            for _, stream_map in out_stash:
                for _, path in stream_map.items():
                    assert path.suffix == f".{fmt}"

    def test_generate_ranged_decodes_to_png(self, tmp_path):
        """Generate from Ranged should decode to PNG (not copy AVIF)."""
        ranged_ds = create_ranged_dataset(tmp_path / "ranged", num_frames=5)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            ranged_ds, output_path,
            stash_policy="generate",
            stash_num_frames=2,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) == 2

        # Verify all stash files are PNG (decoded, not AVIF)
        for _, stream_map in out_stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"

    def test_generate_multivideo_decodes_to_png(self, tmp_path):
        """Generate from MultiVideo should decode to PNG."""
        mv_ds = create_multivideo_dataset(tmp_path / "mv", num_frames=5)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            mv_ds, output_path,
            stash_policy="generate",
            stash_num_frames=2,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) == 2

        # Verify all stash files are PNG
        for _, stream_map in out_stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"

    def test_generate_creates_canonical_structure(self, tmp_path):
        """Generate should create canonical stash structure (8-digit frames, 3-digit streams, rgb/)."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=5, num_streams=3)
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=2,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        stash_dir = output_path / "stash"
        assert stash_dir.exists()

        # Check canonical structure
        for frame_dir in stash_dir.iterdir():
            if frame_dir.is_dir():
                # Frame folder should be 8-digit
                assert len(frame_dir.name) == 8
                assert frame_dir.name.isdigit()

                # Should have rgb subfolder
                rgb_dir = frame_dir / "rgb"
                assert rgb_dir.exists()

                # Stream files should be 3-digit
                for stream_file in rgb_dir.iterdir():
                    stem = stream_file.stem
                    assert len(stem) == 3
                    assert stem.isdigit()

    def test_generate_respects_maintain_frame_numbers_false(self, tmp_path):
        """Generate with maintain_frame_numbers=False should renumber stash."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=10)
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=2,
            start_frame=5,
            end_frame=9,
            maintain_frame_numbers=False,
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        # Stash frames should be numbered from 0 (not 5)
        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        assert min(output_frames) == 0

    def test_generate_respects_stream_id_filter(self, tmp_path):
        """Generate should only include specified stream IDs."""
        input_path = tmp_path / "input"
        create_legacy_dataset(input_path, num_frames=5, num_streams=4)
        input_ds = LegacyDataset(input_path)

        output_path = tmp_path / "output"
        writer = LegacyDatasetWriter(
            input_ds, output_path,
            stash_policy="generate",
            stash_num_frames=1,
            stream_ids=[0, 2],  # Only streams 0 and 2
            image_format="png",
            max_workers=2,
        )
        output_ds = writer.write()

        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) == 1

        for _, stream_map in out_stash:
            assert sorted(stream_map.keys()) == [0, 2]


# =============================================================================
# Tests: Cross-format combinations
# =============================================================================


class TestCrossFormatStash:
    """Tests for stash handling across different format combinations."""

    def test_ranged_to_ranged_copy(self, tmp_path):
        """Ranged -> Ranged should copy stash correctly."""
        # Create ranged with stash
        ranged_ds = create_ranged_dataset(tmp_path / "ranged1", num_frames=5)
        ranged_ds.generate_stash_frames(num_frames=2, overwrite_existing=True)

        input_stash = ranged_ds.get_stash_frames()
        assert len(input_stash) > 0

        output_path = tmp_path / "ranged2"
        writer = RangedDatasetWriter(
            ranged_ds, output_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="copy",
            max_workers=2,
        )
        output_ds = writer.write()

        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        input_frames = [fn for fn, _ in input_stash]
        assert sorted(output_frames) == sorted(input_frames)

    def test_multivideo_to_ranged_copy(self, tmp_path):
        """MultiVideo -> Ranged should copy stash correctly."""
        mv_ds = create_multivideo_dataset(tmp_path / "mv", num_frames=5)
        mv_ds.generate_stash_frames(num_frames=2, overwrite_existing=True)

        input_stash = mv_ds.get_stash_frames()
        assert len(input_stash) > 0

        output_path = tmp_path / "ranged"
        writer = RangedDatasetWriter(
            mv_ds, output_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="copy",
            max_workers=2,
        )
        output_ds = writer.write()

        output_frames = [fn for fn, _ in output_ds.get_stash_frames()]
        input_frames = [fn for fn, _ in input_stash]
        assert sorted(output_frames) == sorted(input_frames)

    def test_ranged_to_multivideo_generate(self, tmp_path):
        """Ranged -> MultiVideo generate should decode to PNG."""
        ranged_ds = create_ranged_dataset(tmp_path / "ranged", num_frames=5)

        output_path = tmp_path / "mv"
        writer = MultiVideoDatasetWriter(
            ranged_ds, output_path,
            video_codec="h264",
            fps=30,
            crf=28,
            preset="ultrafast",
            stash_policy="generate",
            stash_num_frames=2,
            max_workers=2,
        )
        output_ds = writer.write()

        out_stash = output_ds.get_stash_frames()
        assert len(out_stash) == 2

        for _, stream_map in out_stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"
