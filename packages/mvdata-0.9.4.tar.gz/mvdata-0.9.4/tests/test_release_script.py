import pytest

from scripts import release


def command(*parts: str) -> tuple[str, ...]:
    return parts


def result(stdout: str = "", returncode: int = 0) -> release.CommandResult:
    return release.CommandResult(stdout=stdout, returncode=returncode)


class FakeRunner:
    def __init__(self, scripted_results: dict[tuple[str, ...], list[release.CommandResult]]):
        self.scripted_results = scripted_results
        self.commands: list[tuple[str, ...]] = []

    def run(
        self,
        args,
        *,
        capture: bool = False,
        check: bool = True,
        dry_run_safe: bool = False,
    ) -> release.CommandResult:
        command_args = tuple(args)
        self.commands.append(command_args)

        queue = self.scripted_results.get(command_args)
        command_result = queue.pop(0) if queue else result()
        if check and command_result.returncode != 0:
            raise release.ReleaseError(f"failed: {release.command_text(command_args)}")
        return command_result


def base_scripted_results(
    target_version: str = "0.9.3",
) -> dict[tuple[str, ...], list[release.CommandResult]]:
    return {
        command("git", "status", "--porcelain"): [result()],
        command("git", "branch", "--show-current"): [result("main\n")],
        command("uv", "version", "--short"): [
            result("0.9.2\n"),
            result(f"{target_version}\n"),
        ],
        command("uv", "version", "--bump", "patch", "--dry-run", "--short"): [
            result(f"{target_version}\n")
        ],
        command("git", "rev-parse", "-q", "--verify", f"refs/tags/v{target_version}"): [
            result(returncode=1)
        ],
        command("git", "remote", "get-url", "origin"): [
            result("git@github.com:gracia-labs/mvdata.git\n")
        ],
        command(
            "git",
            "ls-remote",
            "--exit-code",
            "--tags",
            "origin",
            f"refs/tags/v{target_version}",
        ): [result(returncode=2)],
        command("git", "diff", "--name-only", "--", "pyproject.toml", "uv.lock"): [
            result("pyproject.toml\nuv.lock\n")
        ],
    }


def test_release_bumps_patch_commits_tags_and_pushes():
    request = release.ReleaseRequest(
        bump="patch",
        version=None,
        push=True,
        dry_run=False,
        remote="origin",
        branch=None,
        skip_tests=False,
        skip_build=False,
    )
    runner = FakeRunner(base_scripted_results())

    released_version = release.run_release(request, runner)

    assert released_version == "0.9.3"
    assert command("uv", "version", "0.9.3") in runner.commands
    assert command("uv", "sync", "--locked", "--extra", "dev") in runner.commands
    assert command("uv", "run", "pytest") in runner.commands
    assert command("uv", "build") in runner.commands
    assert command("git", "add", "pyproject.toml", "uv.lock") in runner.commands
    assert command("git", "commit", "-m", "Release v0.9.3") in runner.commands
    assert command("git", "tag", "-a", "v0.9.3", "-m", "v0.9.3") in runner.commands
    assert command("git", "push", "origin", "main") in runner.commands
    assert command("git", "push", "origin", "v0.9.3") in runner.commands


def test_release_dry_run_stops_before_mutating_commands():
    request = release.ReleaseRequest(
        bump="patch",
        version=None,
        push=False,
        dry_run=True,
        remote="origin",
        branch=None,
        skip_tests=False,
        skip_build=False,
    )
    scripted = base_scripted_results()
    scripted[command("uv", "version", "--short")] = [result("0.9.2\n")]
    runner = FakeRunner(scripted)

    released_version = release.run_release(request, runner)

    assert released_version == "0.9.3"
    assert command("uv", "version", "0.9.3") not in runner.commands
    assert command("git", "commit", "-m", "Release v0.9.3") not in runner.commands
    assert command("git", "tag", "-a", "v0.9.3", "-m", "v0.9.3") not in runner.commands


def test_release_refuses_dirty_worktree():
    request = release.ReleaseRequest(
        bump="patch",
        version=None,
        push=False,
        dry_run=False,
        remote="origin",
        branch=None,
        skip_tests=False,
        skip_build=False,
    )
    runner = FakeRunner(
        {
            command("git", "status", "--porcelain"): [
                result(" M pyproject.toml\n?? scripts/release.py\n")
            ]
        }
    )

    with pytest.raises(release.ReleaseError, match="Working tree is not clean"):
        release.run_release(request, runner)


def test_release_dry_run_allows_dirty_worktree_preview():
    request = release.ReleaseRequest(
        bump="patch",
        version=None,
        push=False,
        dry_run=True,
        remote="origin",
        branch=None,
        skip_tests=False,
        skip_build=False,
    )
    scripted = base_scripted_results()
    scripted[command("git", "status", "--porcelain")] = [result(" M README.md\n")]
    scripted[command("uv", "version", "--short")] = [result("0.9.2\n")]
    runner = FakeRunner(scripted)

    released_version = release.run_release(request, runner)

    assert released_version == "0.9.3"
    assert command("uv", "version", "0.9.3") not in runner.commands


def test_release_refuses_existing_local_tag():
    request = release.ReleaseRequest(
        bump="patch",
        version=None,
        push=False,
        dry_run=False,
        remote="origin",
        branch=None,
        skip_tests=False,
        skip_build=False,
    )
    scripted = base_scripted_results()
    scripted[command("git", "rev-parse", "-q", "--verify", "refs/tags/v0.9.3")] = [
        result("deadbeef\n", returncode=0)
    ]
    runner = FakeRunner(scripted)

    with pytest.raises(release.ReleaseError, match="Local tag already exists"):
        release.run_release(request, runner)


def test_release_commands_can_skip_tests_and_build():
    request = release.ReleaseRequest(
        bump=None,
        version="1.0.0",
        push=False,
        dry_run=False,
        remote="origin",
        branch="main",
        skip_tests=True,
        skip_build=True,
    )

    commands = [
        tuple(command_args) for command_args in release.release_commands(request, "1.0.0", "main")
    ]

    assert command("uv", "run", "pytest") not in commands
    assert command("uv", "build") not in commands
    assert command("git", "tag", "-a", "v1.0.0", "-m", "v1.0.0") in commands


def test_parse_args_requires_one_release_target():
    with pytest.raises(SystemExit):
        release.parse_args([])

    with pytest.raises(SystemExit):
        release.parse_args(["patch", "--version", "1.0.0"])


def test_parse_args_cleans_v_prefix_from_explicit_version():
    request = release.parse_args(["--version", "v1.0.0", "--push", "--branch", "main"])

    assert request.version == "1.0.0"
    assert request.push is True
    assert request.branch == "main"
