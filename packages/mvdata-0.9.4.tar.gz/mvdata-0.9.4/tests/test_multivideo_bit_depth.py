from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import numpy as np

from mvdata.nvdec_parallel import NvdecParallelismPlan
import mvdata.multivideo as multivideo_mod
import mvdata.video_stream_reader as video_stream_reader


def test_get_video_info_includes_bit_depth(monkeypatch, tmp_path):
    class FakeContainer:
        def __init__(self):
            fmt = SimpleNamespace(name="yuv420p10le", components=(SimpleNamespace(bits=10),))
            codec_context = SimpleNamespace(
                name="hevc",
                format=fmt,
                pix_fmt="yuv420p10le",
                bits_per_raw_sample=None,
            )
            stream = SimpleNamespace(
                frames=12,
                average_rate=30.0,
                duration=90,
                time_base=1 / 30,
                start_time=0,
                width=128,
                height=72,
                codec_context=codec_context,
                format=fmt,
            )
            self.streams = SimpleNamespace(video=[stream])

        def decode(self, video=0):
            return iter(())

        def seek(self, offset):
            return None

        def close(self):
            return None

    monkeypatch.setattr(multivideo_mod.av, "open", lambda path: FakeContainer())

    dataset = multivideo_mod.MultiVideoDataset(tmp_path)
    info = dataset._get_video_info(tmp_path / "000.mp4")

    assert info["bit_depth"] == 10
    assert info["frame_count"] == 12


def test_get_video_info_counts_visible_packets_for_preroll(monkeypatch, tmp_path):
    class FakePacket:
        def __init__(self, is_discard: bool):
            self.size = 1
            self.is_discard = is_discard

    class FakeContainer:
        def __init__(self):
            fmt = SimpleNamespace(name="yuv420p", components=(SimpleNamespace(bits=8),))
            codec_context = SimpleNamespace(
                name="h264",
                format=fmt,
                pix_fmt="yuv420p",
                bits_per_raw_sample=None,
                has_b_frames=True,
            )
            stream = SimpleNamespace(
                frames=3,
                average_rate=30.0,
                duration=90,
                time_base=1 / 30,
                start_time=30,
                width=128,
                height=72,
                codec_context=codec_context,
                format=fmt,
            )
            self.streams = SimpleNamespace(video=[stream])
            self.demux_calls = 0

        def demux(self, stream):
            self.demux_calls += 1
            return iter([FakePacket(False), FakePacket(True), FakePacket(False)])

        def close(self):
            return None

    container = FakeContainer()
    monkeypatch.setattr(multivideo_mod.av, "open", lambda path: container)

    dataset = multivideo_mod.MultiVideoDataset(tmp_path)
    info = dataset._get_video_info(tmp_path / "000.mp4")

    assert info["frame_count"] == 2
    assert container.demux_calls == 1


def test_multivideo_frame_reader_passes_stream_bit_depths(monkeypatch):
    seen: dict[str, int] = {}

    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            seen[path.stem] = bit_depth
            self._value = int(path.stem)

        def frame(self, index, *, device="cpu", cuda_stream=None):
            return np.full((2, 2, 3), self._value + index, dtype=np.uint8)

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="NVIDIA L40S",
            budget_sessions=3,
            planned_sessions=1,
            reason="support-matrix",
            configured_limit=None,
        ),
    )

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={
            0: Path("000.mp4"),
            1: Path("001.mp4"),
        },
        video_infos={
            0: {"frame_count": 4, "bit_depth": 10},
            1: {"frame_count": 4, "bit_depth": 8},
        },
        start_frame=0,
        end_frame=3,
        decoder_max_workers=1,
    )
    try:
        _, frame_data = reader.read_frame(0)
    finally:
        reader.close()

    assert seen == {"000": 10, "001": 8}
    assert reader.get_bit_depth() == 10
    assert int(frame_data[0][0, 0, 0]) == 0
    assert int(frame_data[1][0, 0, 0]) == 1
