import json
import shutil
import uuid
from pathlib import Path

import numpy as np
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for ranged resume tests")

from mvdata import LegacyDataset, RangedDatasetWriter, RangedNvencSettings
from mvdata.write_progress import PROGRESS_FILENAME


@pytest.fixture
def workspace() -> Path:
    base_dir = Path.cwd() / ".pytest-work"
    base_dir.mkdir(parents=True, exist_ok=True)
    path = base_dir / f"ranged-resume-{uuid.uuid4().hex}"
    path.mkdir(parents=True)
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


def create_legacy_dataset(path: Path, num_frames: int = 5, num_streams: int = 2) -> Path:
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            img = np.zeros((32, 32, 3), dtype=np.uint8)
            img[:, :, 0] = (frame_idx * 25) % 256
            img[:, :, 1] = (stream_id * 60) % 256
            img[:, :, 2] = (frame_idx * 10 + stream_id * 15) % 256
            Image.fromarray(img, mode="RGB").save(frame_dir / f"{stream_id:03d}.png")

    return path


def create_meta_folder(path: Path) -> None:
    meta_dir = path / "meta"
    meta_dir.mkdir(parents=True)
    (meta_dir / "calibration.json").write_text('{"fx": 1.23}\n', encoding="utf-8")
    nested_dir = meta_dir / "audio"
    nested_dir.mkdir()
    (nested_dir / "notes.txt").write_text("example audio metadata\n", encoding="utf-8")


def make_encoder_options(**overrides):
    from pyavif import EncoderOptions

    opts = EncoderOptions()
    opts.quality = 80
    opts.speed = 8
    for name, value in overrides.items():
        setattr(opts, name, value)
    return opts


class FakeNvencWriter(RangedDatasetWriter):
    def _plan_stream_outputs(self, probe_frame: int) -> None:
        assert self.stream_ids is not None
        self._stream_output_formats = {sid: "nvenc_h264" for sid in self.stream_ids}
        self._stream_nvenc_bitrates_bps = {sid: 12_345_678 for sid in self.stream_ids}

    def _write_stream_batch_for_range(
        self,
        stream_batch: list[int],
        abs_start: int,
        abs_end: int,
        out_start: int,
        out_end: int,
    ) -> None:
        rgb_dir = self.output_path / self._format_range_name(out_start, out_end) / "rgb"
        rgb_dir.mkdir(parents=True, exist_ok=True)
        for stream_id in stream_batch:
            (rgb_dir / self._format_stream_name(stream_id)).write_bytes(b"fake mp4")


def select_expected_frames(start_frame: int, end_frame: int, num_frames: int) -> list[int]:
    total = end_frame - start_frame + 1
    if total <= 0 or num_frames <= 0:
        return []

    num_frames = min(num_frames, total)
    if num_frames == total:
        return list(range(start_frame, end_frame + 1))

    indices = np.linspace(0, total - 1, num_frames, dtype=int)
    return [start_frame + int(i) for i in indices]


def list_relative_files(path: Path) -> set[str]:
    return {
        str(item.relative_to(path))
        for item in path.rglob("*")
        if item.is_file()
    }


def assert_tree_matches(source: Path, target: Path) -> None:
    source_files = list_relative_files(source)
    target_files = list_relative_files(target)
    assert target_files == source_files
    for rel_path in source_files:
        assert (source / rel_path).read_bytes() == (target / rel_path).read_bytes()


def test_resume_rejects_changed_encoder_options_after_success(workspace):
    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(timescale=30),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
    )
    writer.write()

    progress_path = output_path / PROGRESS_FILENAME
    assert progress_path.exists()

    saved = json.loads(progress_path.read_text(encoding="utf-8"))
    assert saved["config"]["encoder_options"]["timescale"] == 30

    resumed_writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(timescale=60),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )

    with pytest.raises(ValueError, match=r"encoder_options\.timescale"):
        resumed_writer.write()


def test_resume_rejects_changed_ranged_compression_after_success(workspace):
    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = FakeNvencWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(fps=30, chroma_subsampling="420"),
    )
    writer.write()

    saved = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert saved["config"]["ranged_compression"] == "nvenc_h264"

    resumed_writer = FakeNvencWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )

    with pytest.raises(ValueError, match=r"ranged_compression"):
        resumed_writer.write()


def test_resume_rejects_changed_nvenc_settings_after_success(workspace):
    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = FakeNvencWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(fps=30, chroma_subsampling="420"),
    )
    writer.write()

    saved = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert saved["config"]["nvenc_settings"]["fps"] == 30

    resumed_writer = FakeNvencWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(fps=60, chroma_subsampling="420"),
        resume=True,
    )

    with pytest.raises(ValueError, match=r"nvenc_settings\.fps"):
        resumed_writer.write()


def test_resume_rejects_corrupt_manifest(workspace):
    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
    )
    writer.write()

    progress_path = output_path / PROGRESS_FILENAME
    progress_path.write_text('{"completed": [', encoding="utf-8")

    resumed_writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )

    with pytest.raises(ValueError, match="progress manifest is unreadable or corrupt"):
        resumed_writer.write()


def test_resume_rejects_missing_manifest_in_non_empty_output(workspace):
    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"
    stale_rgb = output_path / "99999998_99999999" / "rgb"
    stale_rgb.mkdir(parents=True)
    (stale_rgb / "000.avif").write_bytes(b"stale")

    writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )

    with pytest.raises(ValueError, match="progress manifest is missing from a non-empty output dataset"):
        writer.write()


def test_resume_rebuilds_meta_after_interrupted_copy(workspace):
    class InterruptingMetaCopyWriter(RangedDatasetWriter):
        def _copy_meta_folder(self):
            input_meta = self.input_dataset.dataset_path / "meta"
            output_meta = self.output_path / "meta"
            self._remove_output_path(output_meta)
            output_meta.mkdir(parents=True, exist_ok=True)
            shutil.copy2(input_meta / "calibration.json", output_meta / "calibration.json")
            raise RuntimeError("meta copy interrupted")

    input_path = create_legacy_dataset(workspace / "input")
    create_meta_folder(input_path)
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = InterruptingMetaCopyWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=True,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )

    with pytest.raises(RuntimeError, match="meta copy interrupted"):
        writer.write()

    progress = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert progress["in_progress"] == "aux/meta"
    assert list_relative_files(output_path / "meta") == {"calibration.json"}

    resumed_writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=True,
        stash_policy="ignore",
        max_workers=2,
        resume=True,
    )
    resumed_writer.write()

    assert_tree_matches(input_path / "meta", output_path / "meta")


def test_resume_rebuilds_copied_stash_after_interruption(workspace):
    class InterruptingCopiedStashWriter(RangedDatasetWriter):
        def _copy_stash_folder(self, stream_ids, start_frame, end_frame, maintain_frame_numbers):
            output_stash = self.output_path / "stash"
            self._remove_output_path(output_stash)

            source_frame_num, source_stream_map = self.input_dataset.get_stash_frames()[0]
            output_frame_num = source_frame_num if maintain_frame_numbers else source_frame_num - start_frame
            partial_dir = output_stash / f"{output_frame_num:08d}" / "rgb"
            partial_dir.mkdir(parents=True, exist_ok=True)
            stream_id = stream_ids[0]
            source_path = source_stream_map[stream_id]
            shutil.copy2(source_path, partial_dir / source_path.name)
            raise RuntimeError("stash copy interrupted")

    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    input_dataset.generate_stash_frames(num_frames=2, overwrite_existing=True)
    expected_frames = [frame_num for frame_num, _ in input_dataset.get_stash_frames()]
    output_path = workspace / "output"

    writer = InterruptingCopiedStashWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="copy",
        stash_num_frames=2,
        max_workers=2,
        resume=True,
    )

    with pytest.raises(RuntimeError, match="stash copy interrupted"):
        writer.write()

    progress = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert progress["in_progress"] == "aux/stash-copy"
    assert len(list((output_path / "stash").rglob("*.png"))) == 1

    resumed_writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="copy",
        stash_num_frames=2,
        max_workers=2,
        resume=True,
    )
    output_dataset = resumed_writer.write()

    stash_frames = output_dataset.get_stash_frames()
    assert [frame_num for frame_num, _ in stash_frames] == expected_frames
    assert all(len(stream_map) == len(input_dataset.stream_ids) for _, stream_map in stash_frames)


def test_resume_rebuilds_generated_stash_after_interruption(workspace):
    class InterruptingGeneratedStashWriter(RangedDatasetWriter):
        def _generate_stash_from_reader(self, stream_ids, start_frame, end_frame, maintain_frame_numbers):
            output_stash = self.output_path / "stash"
            self._remove_output_path(output_stash)

            output_frame_num = start_frame if maintain_frame_numbers else 0
            partial_dir = output_stash / f"{output_frame_num:08d}" / "rgb"
            partial_dir.mkdir(parents=True, exist_ok=True)
            source_paths = self.input_dataset.get_frame_source_paths(start_frame, [stream_ids[0]])
            source_path = source_paths[stream_ids[0]]
            shutil.copy2(source_path, partial_dir / f"{stream_ids[0]:03d}.png")
            raise RuntimeError("stash generate interrupted")

    input_path = create_legacy_dataset(workspace / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = workspace / "output"

    writer = InterruptingGeneratedStashWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="generate",
        stash_num_frames=3,
        max_workers=2,
        resume=True,
    )

    with pytest.raises(RuntimeError, match="stash generate interrupted"):
        writer.write()

    progress = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert progress["in_progress"] == "aux/stash-generate"
    assert len(list((output_path / "stash").rglob("*.png"))) == 1

    resumed_writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=3,
        streams_per_batch=2,
        encoder_options=make_encoder_options(),
        copy_meta=False,
        stash_policy="generate",
        stash_num_frames=3,
        max_workers=2,
        resume=True,
    )
    output_dataset = resumed_writer.write()

    stash_frames = output_dataset.get_stash_frames()
    assert [frame_num for frame_num, _ in stash_frames] == select_expected_frames(0, 4, 3)
    assert all(len(stream_map) == len(input_dataset.stream_ids) for _, stream_map in stash_frames)
