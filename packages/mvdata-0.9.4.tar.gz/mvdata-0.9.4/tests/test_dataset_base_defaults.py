from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from mvdata import Dataset, DatasetWriter, FrameReader


class MinimalFrameReader(FrameReader):
    def __init__(
        self,
        frames: dict[int, dict[int, np.ndarray]],
        stream_ids: list[int],
        start_frame: int,
        end_frame: int,
    ):
        super().__init__(start_frame, end_frame)
        self._frames = frames
        self._stream_ids = list(stream_ids)

    def read_frame(self, frame_index: int):
        if frame_index < self.start_frame or frame_index > self.end_frame:
            raise ValueError(
                f"Frame {frame_index} outside reader range "
                f"[{self.start_frame}, {self.end_frame}]"
            )

        frame_data = self._frames[frame_index]
        return frame_index, {
            stream_id: frame_data[stream_id].copy() for stream_id in self._stream_ids
        }

    def prepare_next_frame(self):
        pass

    @property
    def supports_random_access(self) -> bool:
        return True


class MinimalDataset(Dataset):
    def __init__(self, dataset_path: Path, frames: dict[int, dict[int, np.ndarray]]):
        super().__init__(dataset_path)
        self._frames = frames
        self._frame_numbers = sorted(frames)
        self._stream_ids_cache = sorted(frames[self._frame_numbers[0]].keys())
        self.reader_requests = []

    @property
    def stream_ids(self):
        return list(self._stream_ids_cache or [])

    def get_frame_ranges(self):
        return [(self._frame_numbers[0], self._frame_numbers[-1], None)]

    def create_frame_reader(
        self,
        stream_ids=None,
        start_frame=None,
        end_frame=None,
        max_workers=None,
    ) -> FrameReader:
        if stream_ids is None:
            stream_ids = self.stream_ids
        if start_frame is None:
            start_frame = self._frame_numbers[0]
        if end_frame is None:
            end_frame = self._frame_numbers[-1]
        self.reader_requests.append((list(stream_ids), start_frame, end_frame, max_workers))
        return MinimalFrameReader(self._frames, stream_ids, start_frame, end_frame)


class TrackingDataset(MinimalDataset):
    def __init__(self, dataset_path: Path, frames: dict[int, dict[int, np.ndarray]]):
        super().__init__(dataset_path, frames)
        self.meta_copy_calls = 0

    def copy_meta_to(self, output_dataset_path: Path) -> bool:
        self.meta_copy_calls += 1
        output_meta = output_dataset_path / "meta"
        output_meta.mkdir(parents=True, exist_ok=True)
        (output_meta / "custom.txt").write_text("copied via hook", encoding="utf-8")
        return True


class DummyWriter(DatasetWriter):
    def write(self):
        return self.input_dataset


def _make_frames(num_frames: int = 3, num_streams: int = 2) -> dict[int, dict[int, np.ndarray]]:
    frames = {}
    for frame_idx in range(num_frames):
        stream_map = {}
        for stream_id in range(num_streams):
            value = frame_idx * 40 + stream_id * 10
            stream_map[stream_id] = np.full((8, 8, 3), value, dtype=np.uint8)
        frames[frame_idx] = stream_map
    return frames


def test_minimal_dataset_inherits_default_optional_hooks(tmp_path):
    dataset_path = tmp_path / "dataset"
    (dataset_path / "meta").mkdir(parents=True)
    (dataset_path / "meta" / "info.txt").write_text("meta", encoding="utf-8")
    (dataset_path / "raw").mkdir()
    (dataset_path / "raw" / "payload.bin").write_bytes(b"payload")
    (dataset_path / ".hidden").write_text("skip", encoding="utf-8")

    dataset = MinimalDataset(dataset_path, _make_frames())

    assert dataset.stream_name(1) == "1"
    with pytest.raises(ValueError, match="Stream ID 9"):
        dataset.stream_name(9)

    assert dataset.get_frame_source_paths(0) is None

    files = {Path(path) for path in dataset.valid_file_hierarchy()}
    assert Path("meta") / "info.txt" in files
    assert Path("raw") / "payload.bin" in files
    assert Path(".hidden") not in files


def test_default_copy_meta_to_copies_dataset_meta(tmp_path):
    source_path = tmp_path / "source"
    (source_path / "meta").mkdir(parents=True)
    (source_path / "meta" / "config.json").write_text('{"ok": true}', encoding="utf-8")

    dataset = MinimalDataset(source_path, _make_frames())
    target_path = tmp_path / "target"
    target_path.mkdir()

    copied = dataset.copy_meta_to(target_path)

    assert copied is True
    assert (target_path / "meta" / "config.json").read_text(encoding="utf-8") == '{"ok": true}'


def test_default_generate_stash_frames_decodes_via_reader(tmp_path):
    dataset_path = tmp_path / "dataset"
    dataset_path.mkdir()
    dataset = MinimalDataset(dataset_path, _make_frames(num_frames=4, num_streams=2))

    generated = dataset.generate_stash_frames(
        num_frames=2,
        overwrite_existing=True,
        verbose=False,
    )

    assert generated == [0, 3]
    assert dataset.reader_requests == [([0, 1], 0, 3, dataset.max_workers)]

    stash = dataset.get_stash_frames()
    assert [frame_num for frame_num, _ in stash] == [0, 3]

    for frame_num, stream_map in stash:
        assert sorted(stream_map) == [0, 1]
        for stream_id, image_path in stream_map.items():
            assert image_path.suffix == ".png"
            with Image.open(image_path) as img:
                saved = np.array(img)
            expected = dataset._frames[frame_num][stream_id]
            np.testing.assert_array_equal(saved, expected)


def test_frame_reader_next_frame_supports_legacy_read_frame_signature():
    frames = _make_frames(num_frames=2, num_streams=1)
    reader = MinimalFrameReader(frames, [0], start_frame=0, end_frame=1)

    first_index, first_data = reader.next_frame()
    reader_iter = iter(reader)
    second_index, second_data = next(reader_iter)

    assert first_index == 0
    np.testing.assert_array_equal(first_data[0], frames[0][0])
    assert second_index == 0
    np.testing.assert_array_equal(second_data[0], frames[0][0])


def test_frame_reader_next_frame_requires_updated_signature_for_cuda_requests():
    frames = _make_frames(num_frames=1, num_streams=1)
    reader = MinimalFrameReader(frames, [0], start_frame=0, end_frame=0)

    with pytest.raises(TypeError, match="does not accept device/cuda_stream"):
        reader.next_frame(device="cuda")


def test_writer_meta_copy_uses_dataset_hook(tmp_path):
    dataset_path = tmp_path / "dataset"
    dataset_path.mkdir()
    dataset = TrackingDataset(dataset_path, _make_frames())
    output_path = tmp_path / "output"
    output_path.mkdir()

    writer = DummyWriter(
        input_dataset=dataset,
        output_path=output_path,
        copy_meta=True,
        stash_policy="ignore",
    )

    writer._copy_meta_folder()

    assert dataset.meta_copy_calls == 1
    assert (output_path / "meta" / "custom.txt").read_text(encoding="utf-8") == "copied via hook"
