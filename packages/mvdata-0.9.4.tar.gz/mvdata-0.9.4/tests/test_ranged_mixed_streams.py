from __future__ import annotations

import json
from pathlib import Path
import threading
import time
from types import SimpleNamespace

import numpy as np
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for ranged tests")

from mvdata import LegacyDataset, RangedDataset, RangedDatasetWriter, RangedNvencSettings
from mvdata.dataset_base import FrameReader
from mvdata.nvdec_parallel import NvdecParallelismPlan
from mvdata.write_progress import PROGRESS_FILENAME
import mvdata.gpu_policy as gpu_policy
import mvdata.nvenc_codec as nvenc_codec
import mvdata.ranged as ranged_mod
import mvdata.video_stream_reader as video_stream_reader


def _create_mixed_orientation_legacy_dataset(path: Path, num_frames: int = 2) -> Path:
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        landscape = np.zeros((72, 128, 3), dtype=np.uint8)
        landscape[:, :, 0] = (frame_idx * 17) % 255
        landscape[:, :, 1] = np.tile(np.arange(128, dtype=np.uint8), (72, 1))
        Image.fromarray(landscape, mode="RGB").save(frame_dir / "000.png")

        portrait = np.zeros((128, 72, 3), dtype=np.uint8)
        portrait[:, :, 1] = (frame_idx * 29) % 255
        portrait[:, :, 2] = np.tile(np.arange(128, dtype=np.uint8).reshape(-1, 1), (1, 72))
        Image.fromarray(portrait, mode="RGB").save(frame_dir / "001.png")

    return path


def _create_landscape_legacy_dataset(
    path: Path,
    num_frames: int = 2,
    num_streams: int = 2,
    *,
    height: int = 72,
    width: int = 128,
) -> Path:
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            frame[:, :, 0] = (frame_idx * 17 + stream_id * 13) % 255
            frame[:, :, 1] = np.tile(np.arange(width, dtype=np.uint8), (height, 1))
            frame[:, :, 2] = np.tile(
                np.arange(height, dtype=np.uint8).reshape(-1, 1), (1, width)
            )
            Image.fromarray(frame, mode="RGB").save(frame_dir / f"{stream_id:03d}.png")

    return path


def test_nvenc_writer_falls_back_per_stream_to_avif_for_portrait(tmp_path, monkeypatch):
    class FakeNvc:
        @staticmethod
        def GetEncoderCaps(gpu_id, codec):
            return {
                "width_min": 1,
                "height_min": 1,
                "support_yuv444_encode": 1,
            }

    def fake_encode_rgb_iter_to_mp4(nvc, frames, mp4_path, **kwargs):
        consumed = list(frames)
        assert consumed
        assert all(frame.shape[1] >= frame.shape[0] for frame in consumed)
        mp4_path.write_bytes(b"fake mp4")

    monkeypatch.setattr(gpu_policy, "nvenc_encode_allowed", lambda: True)
    monkeypatch.setattr(gpu_policy, "nvenc_encoding_usable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: FakeNvc())
    monkeypatch.setattr(nvenc_codec, "encode_rgb_iter_to_mp4", fake_encode_rgb_iter_to_mp4)

    input_path = _create_mixed_orientation_legacy_dataset(tmp_path / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = tmp_path / "output"

    writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=2,
        streams_per_batch=2,
        copy_meta=False,
        stash_policy="ignore",
        prefetch_frames=0,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(chroma_subsampling="420"),
    )
    writer.write()

    rgb_dir = output_path / "00000000_00000001" / "rgb"
    assert (rgb_dir / "000.mp4").exists()
    assert (rgb_dir / "001.avif").exists()

    saved = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert saved["config"]["stream_output_formats"] == {"0": "nvenc_h264", "1": "avif"}


def test_nvenc_writer_auto_selects_verified_codec_when_settings_omitted(tmp_path, monkeypatch):
    class FakeNvc:
        pass

    encoded = []

    def fake_select_auto(*args, **kwargs):
        return {
            "codec": "hevc",
            "chroma_subsampling": "444",
            "full_range": True,
            "preset": "P7",
            "bitrate_bps": 12_345_678,
            "decoder": "pyav",
            "mean_psnr": 42.5,
            "min_psnr": 42.5,
            "mse": 0.0,
        }

    def fake_encode_rgb_iter_to_mp4(nvc, frames, mp4_path, **kwargs):
        consumed = list(frames)
        assert consumed
        encoded.append(kwargs.copy())
        mp4_path.write_bytes(b"fake mp4")

    monkeypatch.setattr(gpu_policy, "nvenc_encode_allowed", lambda: True)
    monkeypatch.setattr(gpu_policy, "nvenc_encoding_usable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: FakeNvc())
    monkeypatch.setattr(
        nvenc_codec,
        "select_auto_nvenc_candidate_for_rgb",
        fake_select_auto,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "nvenc_encode_compatibility_issue_for_rgb",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(nvenc_codec, "encode_rgb_iter_to_mp4", fake_encode_rgb_iter_to_mp4)

    input_path = _create_landscape_legacy_dataset(tmp_path / "input")
    input_dataset = LegacyDataset(input_path)
    output_path = tmp_path / "output"

    writer = RangedDatasetWriter(
        input_dataset=input_dataset,
        output_path=output_path,
        frames_per_batch=2,
        streams_per_batch=2,
        copy_meta=False,
        stash_policy="ignore",
        prefetch_frames=0,
        ranged_compression="nvenc_h264",
    )
    writer.write()

    assert writer._resolved_nvenc_settings is not None
    assert writer._resolved_nvenc_settings.codec == "hevc"
    assert writer._resolved_nvenc_settings.chroma_subsampling == "444"
    assert writer._resolved_nvenc_settings.range_mode == "full"
    assert encoded
    assert all(item["codec"] == "hevc" for item in encoded)
    assert all(item["full_range"] is True for item in encoded)

    saved = json.loads((output_path / PROGRESS_FILENAME).read_text(encoding="utf-8"))
    assert saved["config"]["resolved_nvenc_settings"]["codec"] == "hevc"
    assert saved["config"]["stream_output_formats"] == {"0": "nvenc_h264", "1": "nvenc_h264"}


def test_ranged_dataset_reader_supports_mixed_stream_containers(tmp_path, monkeypatch):
    class FakeAvifReader(FrameReader):
        def __init__(
            self,
            range_dir,
            range_start,
            range_end,
            stream_files,
            start_frame,
            end_frame,
            decoder_max_workers=4,
        ):
            super().__init__(start_frame, end_frame)
            self.stream_ids = sorted(stream_files)

        def read_frame(self, frame_index, *, device="cpu", cuda_stream=None):
            return frame_index, {
                sid: np.full((1, 1, 3), sid, dtype=np.uint8) for sid in self.stream_ids
            }

        def get_bit_depth(self):
            return 8

        def prepare_next_frame(self):
            pass

        @property
        def supports_random_access(self):
            return True

    class FakeMp4Reader(FrameReader):
        def __init__(
            self,
            range_dir,
            range_start,
            range_end,
            stream_files,
            start_frame,
            end_frame,
            decoder_max_workers=4,
            gpu_id=0,
        ):
            super().__init__(start_frame, end_frame)
            self.stream_ids = sorted(stream_files)

        def read_frame(self, frame_index, *, device="cpu", cuda_stream=None):
            return frame_index, {
                sid: np.full((1, 1, 3), sid + 10, dtype=np.uint8) for sid in self.stream_ids
            }

        def get_bit_depth(self):
            return 8

        def prepare_next_frame(self):
            pass

        @property
        def supports_random_access(self):
            return True

    monkeypatch.setattr(ranged_mod, "RangedFrameReader", FakeAvifReader)
    monkeypatch.setattr(ranged_mod, "RangedMp4FrameReader", FakeMp4Reader)

    rgb_dir = tmp_path / "mixed" / "00000000_00000000" / "rgb"
    rgb_dir.mkdir(parents=True)
    (rgb_dir / "000.avif").write_bytes(b"avif")
    (rgb_dir / "001.mp4").write_bytes(b"mp4")

    dataset = RangedDataset(tmp_path / "mixed")
    reader = dataset.create_frame_reader(start_frame=0, end_frame=0)
    try:
        _, frame_data = reader.read_frame(0)
    finally:
        reader.close()

    assert dataset.stream_name(0) == "000.avif"
    assert dataset.stream_name(1) == "001.mp4"
    assert int(frame_data[0][0, 0, 0]) == 0
    assert int(frame_data[1][0, 0, 0]) == 11


def test_mixed_ranged_reader_bit_depth_includes_mp4_streams(tmp_path, monkeypatch):
    class FakeAvifReader(FrameReader):
        def __init__(self, *args, **kwargs):
            super().__init__(0, 0)

        def read_frame(self, frame_index, *, device="cpu", cuda_stream=None):
            return frame_index, {}

        def get_bit_depth(self):
            return 8

        def prepare_next_frame(self):
            pass

        def close(self):
            return None

        @property
        def supports_random_access(self):
            return True

    class FakeMp4Reader(FrameReader):
        def __init__(self, *args, **kwargs):
            super().__init__(0, 0)

        def read_frame(self, frame_index, *, device="cpu", cuda_stream=None):
            return frame_index, {}

        def get_bit_depth(self):
            return 10

        def prepare_next_frame(self):
            pass

        def close(self):
            return None

        @property
        def supports_random_access(self):
            return True

    monkeypatch.setattr(ranged_mod, "RangedFrameReader", FakeAvifReader)
    monkeypatch.setattr(ranged_mod, "RangedMp4FrameReader", FakeMp4Reader)

    reader = ranged_mod.MixedRangedFrameReader(
        range_dir=tmp_path,
        range_start=0,
        range_end=0,
        avif_stream_files={0: tmp_path / "000.avif"},
        mp4_stream_files={1: tmp_path / "001.mp4"},
        start_frame=0,
        end_frame=0,
    )
    try:
        assert reader.get_bit_depth() == 10
    finally:
        reader.close()


def test_mp4_stream_reader_decodes_only_requested_frames(monkeypatch):
    decoded_indices: list[int] = []

    class FakeFrame:
        def __init__(self, idx: int):
            self.idx = idx

    class FakeContainer:
        def __init__(self):
            self.streams = SimpleNamespace(video=[object()])

        def decode(self, stream):
            for idx in range(10):
                decoded_indices.append(idx)
                yield FakeFrame(idx)

        def close(self):
            return None

    fake_av = SimpleNamespace(open=lambda path: FakeContainer())

    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: False)
    monkeypatch.setattr(nvenc_codec, "try_import_av", lambda: fake_av)
    monkeypatch.setattr(
        nvenc_codec,
        "_pyav_frame_to_rgb",
        lambda frame, **kwargs: np.full((2, 2, 3), frame.idx, dtype=np.uint8),
    )

    reader = ranged_mod._Mp4PerStreamReader(Path("fake.mp4"), num_frames=10, gpu_id=0)
    try:
        frame2 = reader.frame(2)
        frame4 = reader.frame(4)
    finally:
        reader.close()

    assert int(frame2[0, 0, 0]) == 2
    assert int(frame4[0, 0, 0]) == 4
    assert decoded_indices == [0, 1, 2, 3, 4]


def test_mp4_stream_reader_errors_on_unsupported_nvdec_when_gpu_is_enabled(monkeypatch):
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: object())
    monkeypatch.setattr(
        nvenc_codec,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: "GPU decoder does not support codec='hevc' chroma=444 bitdepth=8",
    )

    reader = ranged_mod._Mp4PerStreamReader(Path("fake.mp4"), num_frames=4, gpu_id=0)
    try:
        with pytest.raises(RuntimeError, match="Could not open NVDEC reader"):
            reader.frame(1)
    finally:
        reader.close()


def test_ranged_mp4_reader_uses_parallel_budget_for_known_multi_nvdec_gpu(monkeypatch):
    active = 0
    peak = 0
    active_lock = threading.Lock()

    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self._value = int(path.stem)

        def frame(self, index, *, device="cpu", cuda_stream=None):
            nonlocal active, peak
            with active_lock:
                active += 1
                peak = max(peak, active)
            try:
                time.sleep(0.05)
                return np.full((2, 2, 3), self._value + index, dtype=np.uint8)
            finally:
                with active_lock:
                    active -= 1

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="NVIDIA L40S",
            budget_sessions=3,
            planned_sessions=2,
            reason="support-matrix+reader-limit",
            configured_limit=None,
        ),
    )
    monkeypatch.setattr(nvenc_codec, "probe_video_bit_depth", lambda path: 10 if path.stem == "000" else 8)
    monkeypatch.setattr(ranged_mod, "_probe_mp4_visible_frame_count", lambda path: 1)

    reader = ranged_mod.RangedMp4FrameReader(
        range_dir=Path("fake-range"),
        range_start=0,
        range_end=0,
        stream_files={
            0: Path("000.mp4"),
            1: Path("001.mp4"),
        },
        start_frame=0,
        end_frame=0,
        decoder_max_workers=2,
        gpu_id=0,
    )
    try:
        _, frame_data = reader.read_frame(0)
    finally:
        reader.close()

    assert reader.decode_parallelism_plan.planned_sessions == 2
    assert reader.get_bit_depth() == 10
    assert peak >= 2
    assert int(frame_data[0][0, 0, 0]) == 0
    assert int(frame_data[1][0, 0, 0]) == 1


def test_ranged_mp4_reader_allows_extra_visible_dependency_frames(monkeypatch):
    class FakeSessionWorker:
        def __init__(self, *args, **kwargs):
            pass

        def close(self):
            pass

    monkeypatch.setattr(nvenc_codec, "probe_video_bit_depth", lambda path: 8)
    monkeypatch.setattr(ranged_mod, "_probe_mp4_visible_frame_count", lambda path: 121)
    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)

    reader = ranged_mod.RangedMp4FrameReader(
        range_dir=Path("00000000_00000119"),
        range_start=0,
        range_end=119,
        stream_files={1: Path("001.mp4")},
        start_frame=0,
        end_frame=119,
        decoder_max_workers=1,
        gpu_id=0,
    )
    try:
        assert reader._frame_counts[1] == 121
    finally:
        reader.close()


def test_ranged_mp4_reader_rejects_declared_range_visible_count_too_short(monkeypatch):
    monkeypatch.setattr(nvenc_codec, "probe_video_bit_depth", lambda path: 8)
    monkeypatch.setattr(ranged_mod, "_probe_mp4_visible_frame_count", lambda path: 118)

    with pytest.raises(ValueError, match="too short"):
        ranged_mod.RangedMp4FrameReader(
            range_dir=Path("00000000_00000119"),
            range_start=0,
            range_end=119,
            stream_files={1: Path("001.mp4")},
            start_frame=0,
            end_frame=119,
            decoder_max_workers=1,
            gpu_id=0,
        )
