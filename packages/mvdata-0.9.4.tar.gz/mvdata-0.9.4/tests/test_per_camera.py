from pathlib import Path

import numpy as np
from PIL import Image

from mvdata import LegacyDataset


def create_per_camera_dataset(path: Path, num_frames: int = 4, num_streams: int = 2) -> Path:
    for stream_id in range(num_streams):
        camera_dir = path / f"{stream_id:03d}" / "rgb"
        camera_dir.mkdir(parents=True, exist_ok=True)

        for frame_idx in range(num_frames):
            img = np.zeros((32, 32, 3), dtype=np.uint8)
            img[:, :, 0] = frame_idx * 20
            img[:, :, 1] = stream_id * 40
            img[:, :, 2] = (frame_idx + stream_id) * 10
            Image.fromarray(img, mode="RGB").save(camera_dir / f"{frame_idx:08d}.png")

    return path


def test_per_camera_reader(tmp_path: Path) -> None:
    dataset_path = tmp_path / "per_camera"
    create_per_camera_dataset(dataset_path, num_frames=3, num_streams=2)

    dataset = LegacyDataset(dataset_path, per_camera=True)
    assert dataset.stream_ids == [0, 1]

    ranges = dataset.get_frame_ranges()
    assert ranges[0][0] == 0
    assert ranges[0][1] == 2

    reader = dataset.create_frame_reader()
    frame_idx, frame_data = reader.read_frame(0)

    assert frame_idx == 0
    assert set(frame_data.keys()) == {0, 1}
    assert frame_data[0].shape == (32, 32, 3)
    assert frame_data[1].shape == (32, 32, 3)

    result = dataset.validate(verbose=False)
    assert result["valid"]
