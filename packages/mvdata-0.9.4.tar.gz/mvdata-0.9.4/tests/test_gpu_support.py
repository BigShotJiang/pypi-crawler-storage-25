from pathlib import Path

import numpy as np
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for ranged dataset support tests")

import mvdata
from mvdata import LegacyDataset, RangedDataset
import mvdata.gpu_policy as gpu_policy
import mvdata.nvenc_codec as nvenc_codec


def _create_legacy_dataset(path: Path, num_frames: int = 2, num_streams: int = 1) -> Path:
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            frame = np.zeros((24, 32, 3), dtype=np.uint8)
            frame[:, :, 0] = (frame_idx * 17 + stream_id * 13) % 255
            frame[:, :, 1] = 64
            frame[:, :, 2] = 128
            Image.fromarray(frame, mode="RGB").save(frame_dir / f"{stream_id:03d}.png")

    return path


def _create_ranged_dataset(path: Path, filenames: list[str]) -> Path:
    rgb_dir = path / "00000000_00000000" / "rgb"
    rgb_dir.mkdir(parents=True)
    for filename in filenames:
        (rgb_dir / filename).write_bytes(b"fake media")
    return path


def test_legacy_gpu_decode_support_is_not_applicable(tmp_path):
    dataset_path = _create_legacy_dataset(tmp_path / "legacy")

    report = mvdata.gpu_decode_support(dataset_path)

    assert report.dataset_type == "LegacyDataset"
    assert report.media_count == 0
    assert report.fully_supported is False
    assert report.partially_supported is False
    assert "not applicable" in (report.note or "").lower()

    dataset = LegacyDataset(dataset_path)
    assert dataset.supports_gpu_decode() is False


def test_ranged_gpu_decode_support_reports_partial_support(tmp_path, monkeypatch):
    dataset_path = _create_ranged_dataset(tmp_path / "ranged", ["000.mp4", "001.avif"])

    monkeypatch.setattr(gpu_policy, "nvdec_decode_allowed", lambda: True)
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(gpu_policy, "pynvvideocodec_importable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: object())
    monkeypatch.setattr(
        nvenc_codec,
        "probe_video_stream_metadata",
        lambda nvc, path: {
            "codec": "hevc",
            "width": 128,
            "height": 72,
            "bitdepth": 8,
            "chroma_subsampling": "444",
        },
    )
    monkeypatch.setattr(
        nvenc_codec,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )

    report = RangedDataset(dataset_path).gpu_decode_support()
    items = {item.stream_id: item for item in report.items}

    assert report.media_count == 2
    assert report.fully_supported is False
    assert report.partially_supported is True
    assert report.fully_hardware_compatible is False
    assert report.partially_hardware_compatible is True
    assert items[0].will_use_gpu_decode is True
    assert items[0].hardware_compatible is True
    assert items[0].codec == "hevc"
    assert items[1].will_use_gpu_decode is False
    assert items[1].hardware_compatible is False
    assert "AVIF batches do not use NVDEC" in (items[1].reason or "")


def test_ranged_gpu_decode_support_respects_disable_policy(tmp_path, monkeypatch):
    dataset_path = _create_ranged_dataset(tmp_path / "ranged", ["000.mp4"])

    monkeypatch.setattr(gpu_policy, "nvdec_decode_allowed", lambda: False)
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: False)
    monkeypatch.setattr(gpu_policy, "pynvvideocodec_importable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: object())
    monkeypatch.setattr(
        nvenc_codec,
        "probe_video_stream_metadata",
        lambda nvc, path: {
            "codec": "h264",
            "width": 128,
            "height": 72,
            "bitdepth": 8,
            "chroma_subsampling": "444",
        },
    )
    monkeypatch.setattr(
        nvenc_codec,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )

    report = mvdata.gpu_decode_support(RangedDataset(dataset_path))

    assert report.fully_supported is False
    assert mvdata.supports_gpu_decode(RangedDataset(dataset_path)) is False
    assert report.fully_hardware_compatible is True
    assert report.partially_hardware_compatible is True
    assert len(report.items) == 1
    assert report.items[0].will_use_gpu_decode is False
    assert report.items[0].hardware_compatible is True
    assert "disabled by policy" in (report.items[0].reason or "").lower()
