from __future__ import annotations

import pytest

from mvdata.nvdec_parallel import (
    MVDATA_NVDEC_MAX_SESSIONS_ENV,
    lookup_nvdec_total,
    parse_nvdec_session_override,
    resolve_nvdec_parallelism,
)


def test_lookup_nvdec_total_uses_support_matrix_snapshot_for_l40s():
    assert lookup_nvdec_total("NVIDIA L40S") == 3


def test_resolve_nvdec_parallelism_prefers_explicit_env_override():
    plan = resolve_nvdec_parallelism(
        gpu_id=0,
        session_count=8,
        env={MVDATA_NVDEC_MAX_SESSIONS_ENV: "6"},
        gpu_name="NVIDIA GeForce RTX 3090",
    )

    assert plan.budget_sessions == 6
    assert plan.planned_sessions == 6
    assert plan.reason == f"env:{MVDATA_NVDEC_MAX_SESSIONS_ENV}"


def test_resolve_nvdec_parallelism_caps_matrix_budget_with_reader_limit():
    plan = resolve_nvdec_parallelism(
        gpu_id=0,
        session_count=8,
        requested_max_workers=2,
        gpu_name="NVIDIA L40S",
    )

    assert plan.budget_sessions == 2
    assert plan.planned_sessions == 2
    assert plan.reason == "support-matrix+reader-limit"


def test_resolve_nvdec_parallelism_falls_back_to_one_for_unknown_gpu():
    plan = resolve_nvdec_parallelism(
        gpu_id=0,
        session_count=8,
        gpu_name="Mystery GPU 1234",
    )

    assert plan.budget_sessions == 1
    assert plan.planned_sessions == 1
    assert plan.reason == "fallback:unknown-gpu"


def test_parse_nvdec_session_override_rejects_non_positive_values():
    with pytest.raises(ValueError):
        parse_nvdec_session_override({MVDATA_NVDEC_MAX_SESSIONS_ENV: "0"})
