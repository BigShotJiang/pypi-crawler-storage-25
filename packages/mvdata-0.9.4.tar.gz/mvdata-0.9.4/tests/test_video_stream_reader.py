from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import threading
import time
from types import SimpleNamespace

import numpy as np
import pytest

import mvdata.codec.probe as probe_mod
import mvdata.codec.decode as decode_mod
from mvdata.nvdec_parallel import NvdecParallelismPlan
import mvdata.gpu_policy as gpu_policy
import mvdata.multivideo as multivideo_mod
import mvdata.nvenc_codec as nvenc_codec
import mvdata.video_stream_reader as video_stream_reader


def _write_hevc10_fixture(
    tmp_path: Path,
    *,
    pix_fmt: str,
    width: int,
    height: int,
    planes: tuple[np.ndarray, ...],
) -> Path:
    if shutil.which("ffmpeg") is None:
        pytest.skip("ffmpeg is required to generate the high-bit-depth fixture")

    raw = tmp_path / f"{pix_fmt}.yuv"
    mp4 = tmp_path / f"{pix_fmt}.mp4"
    raw.write_bytes(b"".join(plane.astype("<u2").tobytes() for plane in planes))

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        pix_fmt,
        "-s",
        f"{width}x{height}",
        "-r",
        "1",
        "-i",
        str(raw),
        "-frames:v",
        "1",
        "-c:v",
        "libx265",
        "-preset",
        "ultrafast",
        "-x265-params",
        "lossless=1:range=full",
        "-pix_fmt",
        pix_fmt,
        str(mp4),
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        pytest.skip(f"could not generate HEVC 10-bit fixture: {exc}")
    return mp4


class _FakeNvdecFrame:
    def __init__(self, idx: int, pts: int | None = None):
        self.idx = idx
        self.timestamp = idx if pts is None else pts

    def getPTS(self):
        return self.timestamp


class _FakeNvdecPacket:
    def __init__(self, outputs=None, bsl: int = 1):
        self.outputs = list(outputs or [])
        self.bsl = bsl


class _FakeNvdecMetadataDecoder:
    def __init__(self, pts: list[int]):
        self._pts = pts

    def get_scanned_stream_metadata(self):
        return SimpleNamespace(pts=self._pts)

    def close(self):
        return None


class _FakeNvdecOrdinalDecoder:
    def __init__(self, frames: list[_FakeNvdecFrame], calls: list):
        self._frames = list(frames)
        self._cursor = 0
        self._calls = calls

    def __len__(self):
        return len(self._frames)

    def get_batch_frames(self, batch_size: int):
        start = self._cursor
        self._calls.append(("batch", start))
        batch = self._frames[start : start + batch_size]
        self._cursor += len(batch)
        return batch

    def get_batch_frames_by_index(self, indices):
        index = int(indices[0])
        self._calls.append(("indexed", index))
        return [self._frames[index]]

    def close(self):
        self._calls.append(("close", None))


class _FakeNvdecDemuxer:
    def __init__(
        self,
        decoded_frames: list[_FakeNvdecFrame | list[_FakeNvdecFrame]],
        calls: list,
    ):
        self._decoded_frames = list(decoded_frames)
        self._cursor = 0
        self._calls = calls

    def GetNvCodecId(self):
        return "h264"

    def Demux(self):
        if self._cursor >= len(self._decoded_frames):
            self._calls.append(("demux", "eos"))
            return _FakeNvdecPacket(bsl=0)
        item = self._decoded_frames[self._cursor]
        self._cursor += 1
        if isinstance(item, list):
            self._calls.append(("demux", tuple(frame.idx for frame in item)))
            return _FakeNvdecPacket(item)
        self._calls.append(("demux", item.idx))
        return _FakeNvdecPacket([item])


class _FakeNvdecLowLevelDecoder:
    def __init__(self, calls: list):
        self._calls = calls

    def Decode(self, packet):
        self._calls.append(("decode", getattr(packet, "bsl", None)))
        return packet.outputs

    def stop(self):
        self._calls.append(("stop", None))


def _patch_fake_nvdec(
    monkeypatch,
    decoded_frames: list[_FakeNvdecFrame | list[_FakeNvdecFrame]],
    *,
    num_frames: int,
    calls: list | None = None,
):
    calls = [] if calls is None else calls
    presentation_pts = list(range(num_frames))

    fake_nvc = SimpleNamespace(
        OutputColorType=SimpleNamespace(RGB="rgb", NATIVE="native"),
        DisplayDecodeLatencyType=SimpleNamespace(NATIVE="native"),
        CreateDemuxer=lambda path: _FakeNvdecDemuxer(decoded_frames, calls),
        CreateDecoder=lambda **kwargs: _FakeNvdecLowLevelDecoder(calls),
    )

    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_torch", lambda: None)
    monkeypatch.setattr(nvenc_codec, "try_import_cupy", lambda: None)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: fake_nvc)
    monkeypatch.setattr(
        nvenc_codec,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_try_open_nvdec",
        lambda nvc, path_str, gpu_id, use_device_memory, **kwargs: _FakeNvdecMetadataDecoder(
            presentation_pts
        ),
    )
    return calls


def test_nvdec_reader_uses_pts_ordered_decode_for_consecutive_frames(monkeypatch):
    calls: list[tuple[str, int | str | None]] = []
    _patch_fake_nvdec(
        monkeypatch,
        [_FakeNvdecFrame(idx) for idx in range(8)],
        num_frames=8,
        calls=calls,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    reader = video_stream_reader.VideoPerStreamReader(Path("fake.mp4"), num_frames=8, gpu_id=0)
    try:
        frame0 = reader.frame(0)
        frame1 = reader.frame(1)
        frame5 = reader.frame(5)
    finally:
        reader.close()

    assert int(frame0[0, 0, 0]) == 0
    assert int(frame1[0, 0, 0]) == 1
    assert int(frame5[0, 0, 0]) == 5
    assert [call for call in calls if call[0] == "demux"] == [
        ("demux", 0),
        ("demux", 1),
        ("demux", 2),
        ("demux", 3),
        ("demux", 4),
        ("demux", 5),
    ]


def test_nvdec_reader_uses_pending_frames_before_resetting(monkeypatch):
    calls: list[tuple[str, int | tuple[int, ...] | None]] = []
    _patch_fake_nvdec(
        monkeypatch,
        [[_FakeNvdecFrame(0), _FakeNvdecFrame(1)], _FakeNvdecFrame(2)],
        num_frames=3,
        calls=calls,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    reader = video_stream_reader.VideoPerStreamReader(Path("fake.mp4"), num_frames=3, gpu_id=0)
    try:
        frame0 = reader.frame(0)
        frame1 = reader.frame(1)
    finally:
        reader.close()

    assert int(frame0[0, 0, 0]) == 0
    assert int(frame1[0, 0, 0]) == 1
    assert [call for call in calls if call[0] == "demux"] == [("demux", (0, 1))]


def test_nvdec_reader_uses_ordinal_api_without_scanned_metadata(monkeypatch):
    calls: list[tuple[str, int | None]] = []
    ordinal_decoder = _FakeNvdecOrdinalDecoder(
        [
            _FakeNvdecFrame(0, pts=0),
            _FakeNvdecFrame(1, pts=1001),
            _FakeNvdecFrame(2, pts=2002),
        ],
        calls,
    )

    def unexpected_create_demuxer(path):
        raise AssertionError("low-level NVDEC should not be used without scanned metadata")

    fake_nvc = SimpleNamespace(
        OutputColorType=SimpleNamespace(RGB="rgb", NATIVE="native"),
        CreateDemuxer=unexpected_create_demuxer,
    )

    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(nvenc_codec, "try_import_torch", lambda: None)
    monkeypatch.setattr(nvenc_codec, "try_import_cupy", lambda: None)
    monkeypatch.setattr(nvenc_codec, "try_import_pynvvideocodec", lambda: fake_nvc)
    monkeypatch.setattr(
        nvenc_codec,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_try_open_nvdec",
        lambda nvc, path_str, gpu_id, use_device_memory, **kwargs: ordinal_decoder,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    reader = video_stream_reader.VideoPerStreamReader(Path("fake.mp4"), num_frames=3, gpu_id=0)
    try:
        frame0 = reader.frame(0)
        frame1 = reader.frame(1)
    finally:
        reader.close()

    assert int(frame0[0, 0, 0]) == 0
    assert int(frame1[0, 0, 0]) == 1
    assert calls[:2] == [("batch", 0), ("batch", 1)]


def test_decode_mp4_to_rgb_nvdec_uses_ordinal_api_without_scanned_metadata(monkeypatch):
    calls: list[tuple[str, int | bool | None]] = []
    frames = [
        _FakeNvdecFrame(0, pts=0),
        _FakeNvdecFrame(1, pts=1001),
        _FakeNvdecFrame(2, pts=2002),
    ]

    class FakeNvc:
        OutputColorType = SimpleNamespace(RGB="rgb", NATIVE="native")

        def SimpleDecoder(self, path_str, *, gpu_id, use_device_memory, output_color_type):
            calls.append(("open", bool(use_device_memory)))
            return _FakeNvdecOrdinalDecoder(frames, calls)

    monkeypatch.setattr(decode_mod, "nvdec_decode_allowed", lambda: True)
    monkeypatch.setattr(
        decode_mod,
        "probe_video_stream_metadata",
        lambda nvc, path: {"bitdepth": 8},
    )
    monkeypatch.setattr(
        decode_mod,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )
    monkeypatch.setattr(decode_mod, "probe_video_bit_depth", lambda path, nvc=None: 8)
    monkeypatch.setattr(decode_mod, "probe_video_color_metadata_pyav", lambda path: {})
    monkeypatch.setattr(decode_mod, "try_import_torch", lambda: None)
    monkeypatch.setattr(decode_mod, "try_import_cupy", lambda: None)
    monkeypatch.setattr(
        decode_mod,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    decoded = decode_mod.decode_mp4_to_rgb_nvdec(
        FakeNvc(),
        Path("fake.mp4"),
        gpu_id=0,
        expect_count=3,
    )

    assert [int(frame[0, 0, 0]) for frame in decoded] == [0, 1, 2]
    assert [call for call in calls if call[0] == "indexed"] == [
        ("indexed", 0),
        ("indexed", 1),
        ("indexed", 2),
    ]


def test_decode_mp4_to_rgb_nvdec_keeps_later_pts_for_prefix_decode(monkeypatch):
    calls: list[tuple[str, int | bool | tuple[int, ...] | None]] = []

    class FakeNvc:
        OutputColorType = SimpleNamespace(RGB="rgb", NATIVE="native")
        DisplayDecodeLatencyType = SimpleNamespace(NATIVE="native")

        def SimpleDecoder(self, path_str, **kwargs):
            calls.append(("open", bool(kwargs.get("need_scanned_stream_metadata"))))
            return _FakeNvdecMetadataDecoder([0, 1001, 2002])

        def CreateDemuxer(self, path):
            return _FakeNvdecDemuxer(
                [[_FakeNvdecFrame(0, pts=0), _FakeNvdecFrame(2, pts=2002)]],
                calls,
            )

        def CreateDecoder(self, **kwargs):
            return _FakeNvdecLowLevelDecoder(calls)

    monkeypatch.setattr(decode_mod, "nvdec_decode_allowed", lambda: True)
    monkeypatch.setattr(
        decode_mod,
        "probe_video_stream_metadata",
        lambda nvc, path: {"bitdepth": 8},
    )
    monkeypatch.setattr(
        decode_mod,
        "nvdec_decode_compatibility_issue_for_path",
        lambda nvc, path, gpu_id: None,
    )
    monkeypatch.setattr(decode_mod, "probe_video_bit_depth", lambda path, nvc=None: 8)
    monkeypatch.setattr(decode_mod, "probe_video_color_metadata_pyav", lambda path: {})
    monkeypatch.setattr(decode_mod, "try_import_torch", lambda: None)
    monkeypatch.setattr(decode_mod, "try_import_cupy", lambda: None)
    monkeypatch.setattr(
        decode_mod,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    decoded = decode_mod.decode_mp4_to_rgb_nvdec(
        FakeNvc(),
        Path("fake.mp4"),
        gpu_id=0,
        expect_count=1,
    )

    assert [int(frame[0, 0, 0]) for frame in decoded] == [0]
    assert [call for call in calls if call[0] == "demux"] == [("demux", (0, 2))]


def test_nvdec_reader_raises_when_requested_pts_was_not_decoded(monkeypatch):
    _patch_fake_nvdec(
        monkeypatch,
        [_FakeNvdecFrame(13, pts=13)],
        num_frames=16,
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_numpy",
        lambda frame, torch_mod, **kwargs: np.full((1, 1, 3), frame.idx, dtype=np.uint8),
    )

    reader = video_stream_reader.VideoPerStreamReader(Path("fake.mp4"), num_frames=16, gpu_id=0)
    try:
        with pytest.raises(RuntimeError, match="skipped requested presentation frame 0"):
            reader.frame(0)
    finally:
        reader.close()


def test_decoded_frame_to_rgb_numpy_takes_ownership_of_host_buffers():
    raw = np.arange(12, dtype=np.uint8).reshape(2, 2, 3)
    out = nvenc_codec._decoded_frame_to_rgb_numpy(raw, torch_mod=None)

    assert np.array_equal(out, raw)
    assert out is not raw


def test_decoded_frame_to_rgb_numpy_accepts_dlpack_only_host_frames():
    raw = np.arange(12, dtype=np.uint8).reshape(2, 2, 3)

    class DlpackOnlyFrame:
        def __dlpack__(self, *args, **kwargs):
            return raw.__dlpack__(*args, **kwargs)

    out = nvenc_codec._decoded_frame_to_rgb_numpy(DlpackOnlyFrame(), torch_mod=None)

    assert np.array_equal(out, raw)
    assert out.flags.c_contiguous is True


def test_decoded_frame_to_rgb_numpy_preserves_uint16_host_buffers():
    raw = np.arange(12, dtype=np.uint16).reshape(2, 2, 3)
    out = nvenc_codec._decoded_frame_to_rgb_numpy(raw, torch_mod=None, bit_depth=10)

    assert np.array_equal(out, raw)
    assert out.dtype == np.uint16
    assert out is not raw


def test_decoded_frame_to_rgb_numpy_downscales_uint16_full_range_for_source_depth():
    raw = np.array([[[0, 32768, 65472]]], dtype=np.uint16)
    out = nvenc_codec._decoded_frame_to_rgb_numpy(raw, torch_mod=None, bit_depth=10)

    assert out.dtype == np.uint16
    assert out.tolist() == [[[0, 512, 1023]]]


def test_decoded_frame_to_rgb_numpy_rejects_uint8_for_high_bit_depth():
    raw = np.full((1, 1, 3), 255, dtype=np.uint8)

    with pytest.raises(ValueError, match="uint8 output"):
        nvenc_codec._decoded_frame_to_rgb_numpy(raw, torch_mod=None, bit_depth=10)


def test_probe_video_bit_depth_prefers_pyav_over_nvdec_metadata(monkeypatch):
    monkeypatch.setattr(probe_mod, "probe_video_bit_depth_pyav", lambda path: 10)
    monkeypatch.setattr(
        probe_mod,
        "probe_video_stream_metadata",
        lambda nvc, path: {"bitdepth": 8},
    )

    assert probe_mod.probe_video_bit_depth(Path("fake10.mp4"), nvc=object()) == 10


def test_nvdec_path_compatibility_allows_b_frame_streams(monkeypatch):
    monkeypatch.setattr(
        probe_mod,
        "probe_video_stream_metadata",
        lambda nvc, path: {
            "codec": "h264",
            "width": 128,
            "height": 72,
            "bitdepth": 8,
            "chroma_subsampling": "420",
        },
    )
    monkeypatch.setattr(
        probe_mod,
        "safe_get_decoder_caps",
        lambda nvc, gpu_id, codec, chroma_subsampling, bitdepth: {"supported": True},
    )

    issue = probe_mod.nvdec_decode_compatibility_issue_for_path(
        object(),
        Path("bframes.mp4"),
        gpu_id=0,
    )

    assert issue is None


def test_high_bit_depth_nvdec_reader_errors_if_precision_is_lost(monkeypatch):
    class FakeNvdecSource:
        def __init__(self, path, gpu_id, num_frames, bit_depth):
            self._value = 17

        def frame(self, index, *, device="cpu", cuda_stream=None):
            return np.full((2, 2, 3), self._value + index, dtype=np.uint8), "indexed"

        def close(self):
            return None

    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(video_stream_reader, "_VideoNvdecFrameSource", FakeNvdecSource)

    reader = video_stream_reader.VideoPerStreamReader(
        Path("fake10.mp4"),
        num_frames=8,
        gpu_id=0,
        bit_depth=10,
    )
    try:
        with pytest.raises(RuntimeError, match="NVDEC returned uint8"):
            reader.frame(3)
        metrics = reader.metrics
    finally:
        reader.close()

    assert metrics.fallback_to_pyav_count == 0


def test_pyav_frame_to_rgb_uses_source_depth_rgb_for_high_bit_depth():
    calls: list[str] = []

    class FakeFormat:
        name = "yuv420p10le"
        components = (SimpleNamespace(bits=10),)

    class FakeFrame:
        format = FakeFormat()
        color_range = None

        def to_ndarray(self, *, format):
            calls.append(format)
            return np.full((2, 2, 3), 1023, dtype=np.uint16)

    arr = nvenc_codec._pyav_frame_to_rgb(FakeFrame(), bit_depth=10)

    assert arr.dtype == np.uint16
    assert int(arr.max()) == 1023
    assert calls == ["gbrp10le"]


def test_pyav_frame_to_rgb_downshifts_rgb48_fallback_to_source_depth():
    calls: list[str] = []

    class FakeFormat:
        name = "yuv420p10le"
        components = (SimpleNamespace(bits=10),)

    class FakeFrame:
        format = FakeFormat()
        color_range = None

        def to_ndarray(self, *, format):
            calls.append(format)
            if format == "gbrp10le":
                raise ValueError("format unsupported")
            assert format == "rgb48le"
            return np.array([[[0, 32768, 65472]]], dtype=np.uint16)

    arr = nvenc_codec._pyav_frame_to_rgb(FakeFrame(), bit_depth=10)

    assert arr.dtype == np.uint16
    assert arr.tolist() == [[[0, 512, 1023]]]
    assert calls == ["gbrp10le", "rgb48le"]


def test_pyav_full_range_yuv444_manual_path_uses_source_depth_scale():
    class FakeFormat:
        name = "yuv444p10le"
        components = (SimpleNamespace(bits=10),)

    class FakeFrame:
        format = FakeFormat()
        color_range = "pc"

        def to_ndarray(self, *, format):
            assert format == "yuv444p10le"
            y = np.full((1, 1), 1023, dtype=np.uint16)
            cb = np.full((1, 1), 512, dtype=np.uint16)
            cr = np.full((1, 1), 512, dtype=np.uint16)
            return np.stack([y, cb, cr])

    arr = nvenc_codec._pyav_frame_to_rgb(FakeFrame(), bit_depth=10)

    assert arr.dtype == np.uint16
    assert arr.tolist() == [[[1023, 1023, 1023]]]


def test_multivideo_reader_uses_parallel_video_workers(monkeypatch):
    active = 0
    peak = 0
    active_lock = threading.Lock()

    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self._value = int(path.stem)

        def frame(self, index, *, device="cpu", cuda_stream=None):
            nonlocal active, peak
            with active_lock:
                active += 1
                peak = max(peak, active)
            try:
                time.sleep(0.05)
                return np.full((2, 2, 3), self._value + index, dtype=np.uint8)
            finally:
                with active_lock:
                    active -= 1

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="NVIDIA L40S",
            budget_sessions=3,
            planned_sessions=2,
            reason="support-matrix+reader-limit",
            configured_limit=None,
        ),
    )

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={
            0: Path("000.mp4"),
            1: Path("001.mp4"),
        },
        video_infos={
            0: {"frame_count": 4},
            1: {"frame_count": 4},
        },
        start_frame=0,
        end_frame=3,
        decoder_max_workers=2,
    )
    try:
        _, frame_data = reader.read_frame(0)
    finally:
        reader.close()

    assert reader.decode_parallelism_plan.planned_sessions == 2
    assert peak >= 2
    assert int(frame_data[0][0, 0, 0]) == 0
    assert int(frame_data[1][0, 0, 0]) == 1


def test_parallel_reader_exposes_backend_names_and_session_metrics(monkeypatch):
    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self.backend_name = f"backend-{path.stem}"
            self._metrics = video_stream_reader.VideoDecodeSessionMetrics(
                backend=self.backend_name
            )

        def frame(self, index, *, device="cpu", cuda_stream=None):
            self._metrics.frames_served += 1
            return np.full((1, 1, 3), index, dtype=np.uint8)

        @property
        def metrics(self):
            return video_stream_reader.VideoDecodeSessionMetrics(**self._metrics.__dict__)

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="NVIDIA L40S",
            budget_sessions=3,
            planned_sessions=2,
            reason="support-matrix+reader-limit",
            configured_limit=None,
        ),
    )

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={
            0: Path("000.mp4"),
            1: Path("001.mp4"),
        },
        video_infos={
            0: {"frame_count": 4},
            1: {"frame_count": 4},
        },
        start_frame=0,
        end_frame=1,
        decoder_max_workers=2,
    )
    try:
        reader.read_frame(0)
        backends = reader.decode_backend_names
        metrics = reader.decode_session_metrics
    finally:
        reader.close()

    assert backends == {0: "backend-000", 1: "backend-001"}
    assert metrics[0].frames_served == 1
    assert metrics[1].frames_served == 1


def test_multivideo_reader_uses_requested_workers_when_nvdec_is_unavailable(monkeypatch):
    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self.backend_name = "pyav"

        def frame(self, index, *, device="cpu", cuda_stream=None):
            return np.full((1, 1, 3), index, dtype=np.uint8)

        @property
        def metrics(self):
            return video_stream_reader.VideoDecodeSessionMetrics(backend="pyav")

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: False)

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={
            0: Path("000.mp4"),
            1: Path("001.mp4"),
        },
        video_infos={
            0: {"frame_count": 4},
            1: {"frame_count": 4},
        },
        start_frame=0,
        end_frame=1,
        decoder_max_workers=8,
    )
    try:
        assert reader.decode_parallelism_plan.planned_sessions == 2
        assert reader.decode_parallelism_plan.reason == "cpu-only"
    finally:
        reader.close()


# ---------------------------------------------------------------------------
# device='cuda' / cuda_stream plumbing (cupy is monkeypatched to stay unit-only)
# ---------------------------------------------------------------------------


class _FakeCupyArray:
    """Minimal stand-in for cupy.ndarray: HWC tensor backed by a numpy buffer."""

    def __init__(self, data):
        self.data = np.ascontiguousarray(data)

    @property
    def dtype(self):
        return self.data.dtype

    @property
    def shape(self):
        return self.data.shape

    @property
    def ndim(self):
        return self.data.ndim

    def __dlpack__(self, *args, **kwargs):
        return self.data.__dlpack__(*args, **kwargs)

    def transpose(self, *axes):
        return _FakeCupyArray(self.data.transpose(*axes))

    def astype(self, dtype, copy=False):
        return _FakeCupyArray(self.data.astype(dtype))

    def set(self, arr):
        self.data[...] = np.asarray(arr)

    def __setitem__(self, key, value):
        self.data[key] = value.data if isinstance(value, _FakeCupyArray) else value


class _FakeExternalStream:
    captured: list[int] = []

    def __init__(self, ptr):
        self.ptr = int(ptr)
        _FakeExternalStream.captured.append(self.ptr)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _FakeDevice:
    captured: list[int] = []

    def __init__(self, device_id):
        self.device_id = int(device_id)
        _FakeDevice.captured.append(self.device_id)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _FakeCupy:
    """A module-shaped fake exposing only what mvdata.codec.frames touches."""

    uint8 = np.uint8
    uint16 = np.uint16

    class cuda:
        Device = _FakeDevice
        ExternalStream = _FakeExternalStream

    @staticmethod
    def from_dlpack(obj):
        return _FakeCupyArray(np.from_dlpack(obj))

    @staticmethod
    def asarray(arr):
        return _FakeCupyArray(np.asarray(arr))

    @staticmethod
    def empty(shape, dtype, order="C"):
        return _FakeCupyArray(np.empty(shape, dtype=dtype, order=order))

    @staticmethod
    def copyto(dst, src):
        dst.data[...] = src.data

    @staticmethod
    def issubdtype(a, b):
        return np.issubdtype(a, b)


def _patch_fake_cupy(monkeypatch):
    """Install the fake cupy on every entry point used by the codec package."""
    import mvdata.codec.frames as frames_mod

    _FakeDevice.captured.clear()
    _FakeExternalStream.captured.clear()
    monkeypatch.setattr(frames_mod, "try_import_cupy", lambda: _FakeCupy)
    return frames_mod


def test_decoded_frame_to_rgb_cupy_copies_on_requested_gpu_and_stream(monkeypatch):
    _patch_fake_cupy(monkeypatch)

    raw = np.arange(12, dtype=np.uint8).reshape(2, 2, 3)
    out = nvenc_codec._decoded_frame_to_rgb_cupy(
        raw,
        bit_depth=8,
        gpu_id=3,
        cuda_stream=0xDEADBEEF,
    )

    assert isinstance(out, _FakeCupyArray)
    assert out.shape == (2, 2, 3) and out.dtype == np.uint8
    assert np.array_equal(out.data, raw)
    # decoder buffer is owned separately from the returned tensor
    assert out.data is not raw
    assert _FakeDevice.captured == [3]
    # user-supplied stream was forwarded to cupy.cuda.ExternalStream
    assert _FakeExternalStream.captured == [0xDEADBEEF]


def test_decoded_frame_to_rgb_cupy_normalizes_chw_and_high_bit_depth(monkeypatch):
    _patch_fake_cupy(monkeypatch)

    chw = np.arange(12, dtype=np.uint16).reshape(3, 2, 2)
    out = nvenc_codec._decoded_frame_to_rgb_cupy(chw, bit_depth=10)

    assert out.shape == (2, 2, 3)
    assert out.dtype == np.uint16
    assert np.array_equal(out.data, chw.transpose(1, 2, 0))


def test_numpy_to_cupy_rgb_uses_requested_gpu_and_stream(monkeypatch):
    _patch_fake_cupy(monkeypatch)

    src = np.arange(12, dtype=np.uint8).reshape(2, 2, 3)
    out = nvenc_codec.numpy_to_cupy_rgb(src, gpu_id=2, cuda_stream=0x1234)

    assert isinstance(out, _FakeCupyArray)
    assert np.array_equal(out.data, src)
    assert _FakeDevice.captured == [2]
    assert _FakeExternalStream.captured == [0x1234]


def test_nvdec_source_forwards_gpu_id_to_cuda_materialization(monkeypatch):
    captured: list[tuple[int | None, int | None, int]] = []

    _patch_fake_nvdec(monkeypatch, [_FakeNvdecFrame(4, pts=0)], num_frames=8)
    monkeypatch.setattr(nvenc_codec, "try_import_cupy", lambda: object())
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_cupy",
        lambda raw, *, bit_depth, gpu_id=None, cuda_stream=None: captured.append(
            (gpu_id, cuda_stream, raw.idx)
        )
        or np.full((1, 1, 3), raw.idx, dtype=np.uint8),
    )

    source = video_stream_reader._VideoNvdecFrameSource(
        Path("fake.mp4"), gpu_id=3, num_frames=8, bit_depth=8
    )
    try:
        out, mode = source.frame(0, device="cuda", cuda_stream=0xABC)
    finally:
        source.close()

    assert mode == "sequential"
    assert int(out[0, 0, 0]) == 4
    assert captured == [(3, 0xABC, 4)]


def test_nvdec_source_repeats_only_on_same_cuda_stream(monkeypatch):
    materialized: list[int | None] = []

    _patch_fake_nvdec(monkeypatch, [_FakeNvdecFrame(0)], num_frames=8)
    monkeypatch.setattr(nvenc_codec, "try_import_cupy", lambda: object())
    monkeypatch.setattr(
        nvenc_codec,
        "_decoded_frame_to_rgb_cupy",
        lambda raw, *, bit_depth, gpu_id=None, cuda_stream=None: materialized.append(
            cuda_stream
        )
        or {"index": raw.idx, "cuda_stream": cuda_stream},
    )

    source = video_stream_reader._VideoNvdecFrameSource(
        Path("fake.mp4"), gpu_id=1, num_frames=8, bit_depth=8
    )
    try:
        first, first_mode = source.frame(0, device="cuda", cuda_stream=0xAAA)
        repeat, repeat_mode = source.frame(0, device="cuda", cuda_stream=0xAAA)
        second_stream, second_mode = source.frame(0, device="cuda", cuda_stream=0xBBB)
    finally:
        source.close()

    assert first_mode == "sequential"
    assert repeat_mode == "repeat"
    assert second_mode == "indexed"
    assert first == repeat
    assert second_stream["cuda_stream"] == 0xBBB
    assert materialized == [0xAAA, 0xBBB]


def test_pyav_source_forwards_gpu_id_to_h2d_copy(monkeypatch):
    captured: list[tuple[int | None, int | None, tuple[int, ...]]] = []

    class FakeContainer:
        def __init__(self):
            self.streams = SimpleNamespace(video=[object()])

        def decode(self, stream):
            yield object()

        def close(self):
            return None

    fake_container = FakeContainer()

    monkeypatch.setattr(
        nvenc_codec,
        "try_import_av",
        lambda: SimpleNamespace(open=lambda path: fake_container),
    )
    monkeypatch.setattr(
        nvenc_codec,
        "_pyav_frame_to_rgb",
        lambda frame, *, bit_depth=None: np.full((1, 1, 3), 8, dtype=np.uint8),
    )
    monkeypatch.setattr(
        nvenc_codec,
        "numpy_to_cupy_rgb",
        lambda arr, *, gpu_id=None, cuda_stream=None: captured.append(
            (gpu_id, cuda_stream, arr.shape)
        )
        or ("cupy", gpu_id, cuda_stream),
    )

    source = video_stream_reader._VideoPyavFrameSource(
        Path("fake.mp4"), num_frames=1, bit_depth=8, gpu_id=2
    )
    try:
        out, mode = source.frame(0, device="cuda", cuda_stream=0x777)
    finally:
        source.close()

    assert mode == "sequential"
    assert out == ("cupy", 2, 0x777)
    assert captured == [(2, 0x777, (1, 1, 3))]


def test_nvdec_source_routes_to_cupy_path_in_cuda_mode(monkeypatch):
    raw_marker = object()

    class FakeNvdecSource:
        def __init__(self, path, gpu_id, num_frames, bit_depth):
            self._nvenc_codec = nvenc_codec
            self._torch_mod = None
            self._bit_depth = bit_depth
            self._last_index = None
            self._last_frame = None
            self._last_device = None

        def frame(self, index, *, device="cpu", cuda_stream=None):
            if device == "cuda":
                return (
                    nvenc_codec._decoded_frame_to_rgb_cupy(
                        np.full((1, 1, 3), index, dtype=np.uint8),
                        bit_depth=self._bit_depth,
                        cuda_stream=cuda_stream,
                    ),
                    "indexed",
                )
            return np.full((1, 1, 3), index, dtype=np.uint8), "indexed"

        def close(self):
            return None

    _patch_fake_cupy(monkeypatch)
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(video_stream_reader, "_VideoNvdecFrameSource", FakeNvdecSource)

    reader = video_stream_reader.VideoPerStreamReader(
        Path("fake.mp4"), num_frames=4, gpu_id=0, bit_depth=8
    )
    try:
        out = reader.frame(2, device="cuda", cuda_stream=0xABC)
    finally:
        reader.close()

    assert isinstance(out, _FakeCupyArray)
    assert np.array_equal(out.data, np.full((1, 1, 3), 2, dtype=np.uint8))
    assert _FakeExternalStream.captured == [0xABC]
    _ = raw_marker  # silence unused


def test_pyav_source_h2d_copies_in_cuda_mode(monkeypatch):
    class FakePyavSource:
        def __init__(self, path, num_frames, bit_depth, gpu_id=0):
            self._nvenc_codec = nvenc_codec
            self._bit_depth = bit_depth
            self._gpu_id = gpu_id

        def _frame_cpu(self, index):
            return np.full((1, 1, 3), index + 7, dtype=np.uint8), "sequential"

        def frame(self, index, *, device="cpu", cuda_stream=None):
            rgb, mode = self._frame_cpu(index)
            if device == "cuda":
                return (
                    nvenc_codec.numpy_to_cupy_rgb(
                        rgb,
                        gpu_id=self._gpu_id,
                        cuda_stream=cuda_stream,
                    ),
                    mode,
                )
            return rgb, mode

        def close(self):
            return None

    _patch_fake_cupy(monkeypatch)
    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: False)
    monkeypatch.setattr(video_stream_reader, "_VideoPyavFrameSource", FakePyavSource)

    reader = video_stream_reader.VideoPerStreamReader(
        Path("fake.mp4"), num_frames=4, gpu_id=0
    )
    try:
        out = reader.frame(1, device="cuda", cuda_stream=0x777)
    finally:
        reader.close()

    assert isinstance(out, _FakeCupyArray)
    assert np.array_equal(out.data, np.full((1, 1, 3), 8, dtype=np.uint8))
    assert _FakeExternalStream.captured == [0x777]


def test_parallel_reader_forwards_device_and_stream(monkeypatch):
    captured: list[tuple[int, int, str, int | None]] = []

    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self._sid = int(path.stem)

        def frame(self, index, *, device="cpu", cuda_stream=None):
            captured.append((self._sid, index, device, cuda_stream))
            return np.full((1, 1, 3), self._sid, dtype=np.uint8)

        @property
        def metrics(self):
            return video_stream_reader.VideoDecodeSessionMetrics(backend="fake")

        def close(self):
            return None

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="fake",
            budget_sessions=2,
            planned_sessions=1,
            reason="test",
            configured_limit=None,
        ),
    )

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={0: Path("000.mp4"), 1: Path("001.mp4")},
        video_infos={0: {"frame_count": 4}, 1: {"frame_count": 4}},
        start_frame=0,
        end_frame=1,
        decoder_max_workers=1,
    )
    try:
        reader.read_frame(0, device="cuda", cuda_stream=0x555)
    finally:
        reader.close()

    assert {(sid, dev, stream) for sid, _, dev, stream in captured} == {
        (0, "cuda", 0x555),
        (1, "cuda", 0x555),
    }


def test_parallel_reader_avoids_threadpool_for_cuda_nvdec_reads(monkeypatch):
    captured: list[tuple[int, int, str, int | None]] = []

    class FakeSessionWorker:
        def __init__(self, path, num_frames, *, gpu_id=0, bit_depth=8):
            self._sid = int(path.stem)

        def frame(self, index, *, device="cpu", cuda_stream=None):
            captured.append((self._sid, index, device, cuda_stream))
            return np.full((1, 1, 3), self._sid + index, dtype=np.uint8)

        @property
        def metrics(self):
            return video_stream_reader.VideoDecodeSessionMetrics(backend="nvdec")

        def close(self):
            return None

    def fail_executor(*args, **kwargs):
        raise AssertionError("ThreadPoolExecutor should not be created for CUDA NVDEC reads")

    monkeypatch.setattr(video_stream_reader, "VideoPerStreamReader", FakeSessionWorker)
    monkeypatch.setattr(video_stream_reader, "ThreadPoolExecutor", fail_executor)
    monkeypatch.setattr(
        video_stream_reader,
        "resolve_nvdec_parallelism",
        lambda **kwargs: NvdecParallelismPlan(
            gpu_id=kwargs["gpu_id"],
            gpu_name="NVIDIA L40S",
            budget_sessions=3,
            planned_sessions=3,
            reason="support-matrix+reader-limit",
            configured_limit=None,
        ),
    )

    reader = multivideo_mod.MultiVideoFrameReader(
        video_paths={0: Path("000.mp4"), 1: Path("001.mp4"), 2: Path("002.mp4")},
        video_infos={
            0: {"frame_count": 4},
            1: {"frame_count": 4},
            2: {"frame_count": 4},
        },
        start_frame=0,
        end_frame=1,
        decoder_max_workers=3,
    )
    try:
        _, frame_data = reader.read_frame(0, device="cuda", cuda_stream=0x999)
    finally:
        reader.close()

    assert captured == [
        (0, 0, "cuda", 0x999),
        (1, 0, "cuda", 0x999),
        (2, 0, "cuda", 0x999),
    ]
    assert int(frame_data[2][0, 0, 0]) == 2


def test_cuda_mode_errors_on_high_bit_depth_precision_loss(monkeypatch):
    """NVDEC returning uint8 for a 10-bit source must not silently use PyAV."""
    calls: list[str] = []

    class FakeNvdecSource:
        def __init__(self, path, gpu_id, num_frames, bit_depth):
            pass

        def frame(self, index, *, device="cpu", cuda_stream=None):
            calls.append("nvdec")
            return _FakeCupyArray(np.full((1, 1, 3), 7, dtype=np.uint8)), "indexed"

        def close(self):
            return None

    monkeypatch.setattr(gpu_policy, "nvdec_decoding_usable", lambda: True)
    monkeypatch.setattr(video_stream_reader, "_VideoNvdecFrameSource", FakeNvdecSource)

    reader = video_stream_reader.VideoPerStreamReader(
        Path("fake10.mp4"), num_frames=4, gpu_id=0, bit_depth=10
    )
    try:
        with pytest.raises(RuntimeError, match="NVDEC returned uint8"):
            reader.frame(0, device="cuda", cuda_stream=0)
        metrics = reader.metrics
        backend = reader.backend_name
    finally:
        reader.close()

    assert calls == ["nvdec"]
    assert backend == "nvdec"
    assert metrics.fallback_to_pyav_count == 0


def test_native_high_bit_nvdec_matches_pyav_for_p016(tmp_path):
    pytest.importorskip("cupy", reason="native NVDEC conversion uses CuPy")
    if not gpu_policy.nvdec_decoding_usable():
        pytest.skip("NVDEC path unavailable")

    width = height = 160
    y = np.tile(np.linspace(0, 1023, width, dtype=np.uint16), (height, 1))
    cb = np.full((height // 2, width // 2), 512, dtype=np.uint16)
    cr = np.full((height // 2, width // 2), 512, dtype=np.uint16)
    mp4 = _write_hevc10_fixture(
        tmp_path,
        pix_fmt="yuv420p10le",
        width=width,
        height=height,
        planes=(y, cb, cr),
    )

    pyav = nvenc_codec.decode_mp4_to_rgb_pyav(mp4, 1)[0]
    reader = video_stream_reader.VideoPerStreamReader(
        mp4, num_frames=1, gpu_id=0, bit_depth=10
    )
    try:
        nvdec = reader.frame(0)
        metrics = reader.metrics
        backend = reader.backend_name
    finally:
        reader.close()

    max_diff = int(np.abs(pyav.astype(np.int32) - nvdec.astype(np.int32)).max())
    assert backend == "nvdec"
    assert metrics.fallback_to_pyav_count == 0
    assert nvdec.dtype == np.uint16
    assert int(nvdec.max()) <= 1023
    assert max_diff <= 3


def test_native_high_bit_nvdec_matches_pyav_for_yuv444_16bit(tmp_path):
    pytest.importorskip("cupy", reason="native NVDEC conversion uses CuPy")
    if not gpu_policy.nvdec_decoding_usable():
        pytest.skip("NVDEC path unavailable")

    width = height = 160
    x = np.tile(np.linspace(64, 960, width, dtype=np.uint16), (height, 1))
    y = np.tile(np.linspace(96, 912, height, dtype=np.uint16)[:, None], (1, width))
    luma = ((x.astype(np.uint32) + y.astype(np.uint32)) // 2).astype(np.uint16)
    cb = np.tile(np.linspace(256, 768, width, dtype=np.uint16), (height, 1))
    cr = np.tile(np.linspace(768, 256, height, dtype=np.uint16)[:, None], (1, width))
    mp4 = _write_hevc10_fixture(
        tmp_path,
        pix_fmt="yuv444p10le",
        width=width,
        height=height,
        planes=(luma, cb, cr),
    )

    pyav = nvenc_codec.decode_mp4_to_rgb_pyav(mp4, 1)[0]
    reader = video_stream_reader.VideoPerStreamReader(
        mp4, num_frames=1, gpu_id=0, bit_depth=10
    )
    try:
        nvdec = reader.frame(0)
        metrics = reader.metrics
        backend = reader.backend_name
    finally:
        reader.close()

    max_diff = int(np.abs(pyav.astype(np.int32) - nvdec.astype(np.int32)).max())
    assert backend == "nvdec"
    assert metrics.fallback_to_pyav_count == 0
    assert nvdec.dtype == np.uint16
    assert int(nvdec.max()) <= 1023
    assert max_diff <= 3
