"""
Round-trip test: Legacy -> Ranged -> MultiVideo -> compare with original.

This test creates a procedural legacy dataset, converts through all formats,
and verifies quality is preserved (high PSNR despite video compression).

Set KEEP_TEST_ARTIFACTS=1 environment variable or DEBUG=True to preserve
intermediate datasets in playgrounds/test_artifacts/ for manual inspection.
"""

import tempfile
import numpy as np
from pathlib import Path
from PIL import Image
import pytest
import os
import shutil

pytest.importorskip("pyavif", reason="pyavif native extension is required for round-trip tests")
pytest.importorskip("av", reason="PyAV is required for round-trip tests")

# Debug flag: set to True to keep artifacts for manual inspection
DEBUG = os.environ.get('KEEP_TEST_ARTIFACTS', '0') == '1'
ARTIFACTS_DIR = Path(__file__).parent.parent / "playgrounds" / "test_artifacts"


def create_procedural_legacy_dataset(path: Path, num_frames: int = 7, num_streams: int = 3):
    """
    Create a procedural legacy per-frame dataset with deterministic content.
    
    Each frame has a unique pattern based on frame index and stream ID,
    making it easy to verify content preservation after round-trip.
    """
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)
        
        for stream_id in range(num_streams):
            # Create a deterministic pattern based on frame and stream
            img = np.zeros((128, 128, 3), dtype=np.uint8)
            
            # Red channel: gradient based on x position + frame offset
            img[:, :, 0] = np.tile(
                np.linspace(0, 200, 128, dtype=np.uint8),
                (128, 1)
            ) + frame_idx * 5
            
            # Green channel: gradient based on y position + stream offset
            img[:, :, 1] = np.tile(
                np.linspace(0, 200, 128, dtype=np.uint8).reshape(-1, 1),
                (1, 128)
            ) + stream_id * 30
            
            # Blue channel: checkerboard pattern varying by frame
            checker_size = 16
            for y in range(0, 128, checker_size):
                for x in range(0, 128, checker_size):
                    if ((x // checker_size) + (y // checker_size) + frame_idx) % 2 == 0:
                        img[y:y+checker_size, x:x+checker_size, 2] = 180
                    else:
                        img[y:y+checker_size, x:x+checker_size, 2] = 80
            
            # Clip values to valid range
            img = np.clip(img, 0, 255).astype(np.uint8)
            
            # Save as PNG (lossless)
            img_pil = Image.fromarray(img, mode='RGB')
            img_pil.save(frame_dir / f"{stream_id:03d}.png")
    
    return path


def calculate_psnr(img1: np.ndarray, img2: np.ndarray) -> float:
    """Calculate Peak Signal-to-Noise Ratio between two images."""
    mse = np.mean((img1.astype(np.float64) - img2.astype(np.float64)) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr


def read_all_frames(dataset) -> dict:
    """Read all frames from a dataset into a dict[frame_idx][stream_id] -> array."""
    frames = {}
    ranges = dataset.get_frame_ranges()
    start_frame = ranges[0][0]
    end_frame = ranges[-1][1]
    
    reader = dataset.create_frame_reader(start_frame=start_frame, end_frame=end_frame)
    
    for frame_idx, frame_data in reader:
        frames[frame_idx] = {}
        for stream_id, array in frame_data.items():
            frames[frame_idx][stream_id] = array.copy()
    
    return frames


@pytest.fixture
def temp_workspace():
    """
    Create a temporary workspace for the test.
    
    If DEBUG=True or KEEP_TEST_ARTIFACTS=1, artifacts will be saved to
    playgrounds/test_artifacts/ for manual inspection.
    """
    if DEBUG:
        # Use persistent directory for debugging
        workspace = ARTIFACTS_DIR
        if workspace.exists():
            shutil.rmtree(workspace)
        workspace.mkdir(parents=True, exist_ok=True)
        print(f"\n{'='*60}")
        print(f"DEBUG MODE: Artifacts will be saved to:")
        print(f"  {workspace.absolute()}")
        print(f"{'='*60}\n")
        yield workspace
    else:
        # Use temporary directory that gets cleaned up
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)


class TestRoundTrip:
    """Test round-trip conversion: Legacy -> Ranged -> MultiVideo."""
    
    def test_legacy_to_ranged_to_multivideo_roundtrip(self, temp_workspace):
        """
        Full round-trip test:
        1. Create procedural legacy dataset
        2. Convert to ranged (AVIF)
        3. Convert ranged to multivideo
        4. Compare PSNR with original
        """
        from mvdata import (
            LegacyDataset, 
            RangedDataset,
            MultiVideoDataset,
            RangedDatasetWriter,
            MultiVideoDatasetWriter
        )
        
        num_frames = 7
        num_streams = 3
        
        # Step 1: Create procedural legacy dataset
        legacy_path = temp_workspace / "legacy_dataset"
        create_procedural_legacy_dataset(legacy_path, num_frames, num_streams)
        
        legacy_dataset = LegacyDataset(legacy_path)
        assert len(legacy_dataset.stream_ids) == num_streams
        
        # Read original frames for comparison
        original_frames = read_all_frames(legacy_dataset)
        assert len(original_frames) == num_frames
        
        print(f"\nCreated legacy dataset: {num_frames} frames, {num_streams} streams")
        if DEBUG:
            print(f"   Location: {legacy_path.absolute()}")
        
        # Step 2: Convert to ranged (AVIF)
        ranged_path = temp_workspace / "ranged_dataset"
        
        # Import encoder options
        from pyavif import EncoderOptions
        
        # Use high quality settings to minimize loss
        encoder_options = EncoderOptions()
        encoder_options.quality = 90  # High quality
        encoder_options.speed = 6     # Balanced speed
        
        ranged_writer = RangedDatasetWriter(
            input_dataset=legacy_dataset,
            output_path=ranged_path,
            frames_per_batch=500,  # All frames in one batch
            encoder_options=encoder_options,
            copy_meta=False,
            stash_policy="ignore",
            max_workers=4
        )
        
        ranged_dataset = ranged_writer.write()
        assert isinstance(ranged_dataset, RangedDataset)
        assert len(ranged_dataset.stream_ids) == num_streams
        
        # Read ranged frames
        ranged_frames = read_all_frames(ranged_dataset)
        assert len(ranged_frames) == num_frames
        
        print("Converted to ranged dataset")
        if DEBUG:
            print(f"   Location: {ranged_path.absolute()}")
        
        # Calculate PSNR after AVIF conversion
        psnr_after_avif = []
        for frame_idx in original_frames:
            for stream_id in original_frames[frame_idx]:
                orig = original_frames[frame_idx][stream_id]
                ranged = ranged_frames[frame_idx][stream_id]
                psnr = calculate_psnr(orig, ranged)
                psnr_after_avif.append(psnr)
        
        avg_psnr_avif = np.mean(psnr_after_avif)
        min_psnr_avif = np.min(psnr_after_avif)
        print(f"   PSNR after AVIF: avg={avg_psnr_avif:.2f} dB, min={min_psnr_avif:.2f} dB")
        
        # AVIF at quality 90 should maintain high PSNR (>35 dB typically)
        assert min_psnr_avif > 30, f"AVIF quality too low: min PSNR {min_psnr_avif:.2f} dB"
        
        # Step 3: Convert ranged to multivideo
        multivideo_path = temp_workspace / "multivideo_dataset"
        
        multivideo_writer = MultiVideoDatasetWriter(
            input_dataset=ranged_dataset,
            output_path=multivideo_path,
            video_codec='h264',
            fps=30,
            crf=18,  # High quality (lower CRF = better quality)
            preset='medium',
            copy_meta=False,
            stash_policy="ignore"
        )
        
        multivideo_dataset = multivideo_writer.write()
        assert isinstance(multivideo_dataset, MultiVideoDataset)
        assert len(multivideo_dataset.stream_ids) == num_streams
        
        # Read multivideo frames
        multivideo_frames = read_all_frames(multivideo_dataset)
        assert len(multivideo_frames) == num_frames
        
        print(f"Converted to multivideo dataset")
        if DEBUG:
            print(f"   Location: {multivideo_path.absolute()}")
        
        # Step 4: Calculate PSNR between original and final multivideo
        psnr_final = []
        for frame_idx in original_frames:
            for stream_id in original_frames[frame_idx]:
                orig = original_frames[frame_idx][stream_id]
                final = multivideo_frames[frame_idx][stream_id]
                psnr = calculate_psnr(orig, final)
                psnr_final.append(psnr)
        
        avg_psnr_final = np.mean(psnr_final)
        min_psnr_final = np.min(psnr_final)
        print(f"   PSNR final (vs original): avg={avg_psnr_final:.2f} dB, min={min_psnr_final:.2f} dB")
        
        # After two lossy conversions (AVIF + H.264), expect some degradation
        # but quality should still be reasonable (>25 dB is typically acceptable)
        assert min_psnr_final > 25, f"Final quality too low: min PSNR {min_psnr_final:.2f} dB"
        
        # Also verify that degradation from AVIF to video isn't too severe
        psnr_video_vs_avif = []
        for frame_idx in ranged_frames:
            for stream_id in ranged_frames[frame_idx]:
                avif_frame = ranged_frames[frame_idx][stream_id]
                video_frame = multivideo_frames[frame_idx][stream_id]
                psnr = calculate_psnr(avif_frame, video_frame)
                psnr_video_vs_avif.append(psnr)
        
        avg_psnr_video_step = np.mean(psnr_video_vs_avif)
        min_psnr_video_step = np.min(psnr_video_vs_avif)
        print(f"   PSNR video step (AVIF->Video): avg={avg_psnr_video_step:.2f} dB, min={min_psnr_video_step:.2f} dB")
        
        print("\nRound-trip test passed")
        print("   Quality preserved through: Legacy -> Ranged (AVIF) -> MultiVideo (H.264)")
        print(f"   Final PSNR: {avg_psnr_final:.2f} dB average, {min_psnr_final:.2f} dB minimum")
        
        if DEBUG:
            print(f"\n{'='*60}")
            print(f"Artifacts saved for inspection:")
            print(f"  Legacy:      {legacy_path.absolute()}")
            print(f"  Ranged:      {ranged_path.absolute()}")
            print(f"  MultiVideo:  {multivideo_path.absolute()}")
            print(f"{'='*60}")
    
    def test_multivideo_validation(self, temp_workspace):
        """Test that the final multivideo dataset passes validation."""
        from mvdata import LegacyDataset, RangedDatasetWriter, MultiVideoDatasetWriter
        from pyavif import EncoderOptions
        
        # Create and convert
        legacy_path = temp_workspace / "legacy"
        create_procedural_legacy_dataset(legacy_path, num_frames=5, num_streams=2)
        legacy = LegacyDataset(legacy_path)
        
        # To ranged
        ranged_path = temp_workspace / "ranged"
        encoder_options = EncoderOptions()
        encoder_options.quality = 85
        
        ranged_writer = RangedDatasetWriter(
            legacy, ranged_path,
            encoder_options=encoder_options,
            copy_meta=False, stash_policy="ignore"
        )
        ranged = ranged_writer.write()
        
        # To multivideo
        mv_path = temp_workspace / "multivideo"
        mv_writer = MultiVideoDatasetWriter(
            ranged, mv_path,
            video_codec='h264', fps=30, crf=20,
            copy_meta=False, stash_policy="ignore"
        )
        mv = mv_writer.write()
        
        # Validate
        result = mv.validate(verbose=False)
        
        assert result['valid'], f"Validation failed: {result['errors']}"
        assert result['stats']['total_streams'] == 2
        assert result['stats']['frame_count'] == 5
        
        print("\nMultivideo validation passed")


class TestAutoDetect:
    """Test auto_detect_dataset for all formats."""
    
    def test_auto_detect_legacy(self, temp_workspace):
        """Test auto-detection of legacy dataset."""
        from mvdata import auto_detect_dataset, LegacyDataset
        
        legacy_path = temp_workspace / "legacy"
        create_procedural_legacy_dataset(legacy_path, num_frames=3, num_streams=2)
        
        detected = auto_detect_dataset(legacy_path)
        assert isinstance(detected, LegacyDataset)
        print("\nAuto-detected Legacy dataset correctly")
    
    def test_auto_detect_ranged(self, temp_workspace):
        """Test auto-detection of ranged dataset."""
        from mvdata import auto_detect_dataset, LegacyDataset, RangedDataset, RangedDatasetWriter
        from pyavif import EncoderOptions
        
        # Create legacy first
        legacy_path = temp_workspace / "legacy"
        create_procedural_legacy_dataset(legacy_path, num_frames=3, num_streams=2)
        legacy = LegacyDataset(legacy_path)
        
        # Convert to ranged
        ranged_path = temp_workspace / "ranged"
        encoder_options = EncoderOptions()
        encoder_options.quality = 80
        
        writer = RangedDatasetWriter(
            legacy, ranged_path,
            encoder_options=encoder_options,
            copy_meta=False, stash_policy="ignore"
        )
        writer.write()
        
        # Auto-detect
        detected = auto_detect_dataset(ranged_path)
        assert isinstance(detected, RangedDataset)
        print("\nAuto-detected Ranged dataset correctly")
    
    def test_auto_detect_multivideo(self, temp_workspace):
        """Test auto-detection of multivideo dataset."""
        from mvdata import auto_detect_dataset, LegacyDataset, MultiVideoDataset, MultiVideoDatasetWriter
        
        # Create legacy first
        legacy_path = temp_workspace / "legacy"
        create_procedural_legacy_dataset(legacy_path, num_frames=3, num_streams=2)
        legacy = LegacyDataset(legacy_path)
        
        # Convert to multivideo
        mv_path = temp_workspace / "multivideo"
        writer = MultiVideoDatasetWriter(
            legacy, mv_path,
            video_codec='h264', fps=30, crf=23,
            copy_meta=False, stash_policy="ignore"
        )
        writer.write()
        
        # Auto-detect
        detected = auto_detect_dataset(mv_path)
        assert isinstance(detected, MultiVideoDataset)
        print("\nAuto-detected MultiVideo dataset correctly")



