"""Regression: ranged rgb/ discovery must ignore non-stream media files."""

from __future__ import annotations

from pathlib import Path

import pytest

from mvdata.ranged import _discover_stream_files_in_dir


def test_stray_mp4_without_digits_in_stem_does_not_break_avif_discovery(tmp_path: Path):
    rgb = tmp_path / "rgb"
    rgb.mkdir()
    (rgb / "001.avif").touch()
    (rgb / "notes.mp4").touch()
    stream_map = _discover_stream_files_in_dir(rgb)
    assert stream_map == {1: rgb / "001.avif"}


def test_both_stream_avif_and_stream_mp4_still_rejected(tmp_path: Path):
    rgb = tmp_path / "rgb"
    rgb.mkdir()
    (rgb / "001.avif").touch()
    (rgb / "001.mp4").touch()
    with pytest.raises(ValueError, match="Multiple ranged stream files found"):
        _discover_stream_files_in_dir(rgb)
