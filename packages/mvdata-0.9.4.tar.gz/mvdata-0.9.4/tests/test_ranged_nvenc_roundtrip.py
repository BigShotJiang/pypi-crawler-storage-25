"""
Legacy (JPEG) → Ranged (NVENC MP4) → read back → PSNR.

- Procedural legacy uses ``.jpg`` files (small dataset).
- Requires ``mvdata[pynvc]`` plus an NVIDIA stack; skipped when PyNvVideoCodec is missing
  or ``MVDATA_DISABLE_GPU`` is set.

Optional integration: set ``MVDATA_TEST_LEGACY_URL`` to the **same HTTPS URL** your team uses
for a cached legacy sample (e.g. CI artifact or internal mirror of the dataset referenced from
``playgrounds/convert.ipynb``). The test downloads a ``.zip`` that unpacks so the **dataset root**
is the first ``Path`` under the extract dir containing an ``00000000/rgb`` layout.
"""

from __future__ import annotations

import os
import zipfile
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

pytest.importorskip("av", reason="PyAV is required")

from mvdata import (
    LegacyDataset,
    RangedDataset,
    RangedDatasetWriter,
    RangedNvencSettings,
    calculate_psnr,
    nvdec_decoding_usable,
    nvenc_encode_allowed,
    nvenc_encoding_usable,
)


def _create_legacy_jpg_dataset(
    path: Path, num_frames: int = 5, num_streams: int = 2,
    height: int = 128, width: int = 192,
) -> None:
    """Create a minimal Legacy dataset with procedural JPEG frames.

    Default dimensions (128×192) are above NVENC's typical minimum encode
    size (width_min=145 on many GPUs).
    """
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True, exist_ok=True)
        for stream_id in range(1, num_streams + 1):
            img = np.zeros((height, width, 3), dtype=np.uint8)
            img[:, :, 0] = np.tile(np.linspace(0, 220, width, dtype=np.uint8), (height, 1)) + frame_idx * 4
            img[:, :, 1] = np.tile(
                np.linspace(0, 220, height, dtype=np.uint8).reshape(-1, 1), (1, width)
            ) + stream_id * 20
            c = 14
            for y in range(0, height, c):
                for x in range(0, width, c):
                    if ((x // c) + (y // c) + frame_idx) % 2 == 0:
                        img[y : y + c, x : x + c, 2] = 200
                    else:
                        img[y : y + c, x : x + c, 2] = 70
            img = np.clip(img, 0, 255).astype(np.uint8)
            Image.fromarray(img, mode="RGB").save(
                frame_dir / f"{stream_id:03d}.jpg", quality=92, subsampling=1
            )


def _read_all_frames_map(dataset) -> dict:
    ranges = dataset.get_frame_ranges()
    start_frame = ranges[0][0]
    end_frame = ranges[-1][1]
    out = {}
    reader = dataset.create_frame_reader(start_frame=start_frame, end_frame=end_frame)
    try:
        for frame_idx, frame_data in reader:
            out[frame_idx] = {sid: arr.copy() for sid, arr in frame_data.items()}
    finally:
        reader.close()
    return out


requires_nvenc = pytest.mark.skipif(
    not nvenc_encoding_usable() or not nvenc_encode_allowed(),
    reason="NVENC path skipped (no PyNvVideoCodec, or MVDATA_DISABLE_* / NVENC disabled)",
)


@requires_nvenc
def test_legacy_jpg_to_ranged_mp4_roundtrip_psnr(tmp_path):
    legacy_dir = tmp_path / "legacy"
    _create_legacy_jpg_dataset(legacy_dir, num_frames=5, num_streams=3)
    legacy = LegacyDataset(legacy_dir)

    ranged_dir = tmp_path / "ranged_nvenc"
    writer = RangedDatasetWriter(
        legacy,
        ranged_dir,
        frames_per_batch=500,
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        prefetch_frames=0,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(
            gpu_id=0,
            fps=30,
            bitrate_bps=0,
            codec="h264",
            chroma_subsampling="420",
            preset="P7",
        ),
    )
    ranged = writer.write()
    assert isinstance(ranged, RangedDataset)

    orig = _read_all_frames_map(legacy)
    dec = _read_all_frames_map(ranged)
    assert set(orig.keys()) == set(dec.keys())

    psnrs = []
    for fidx in sorted(orig.keys()):
        for sid in sorted(orig[fidx].keys()):
            psnrs.append(calculate_psnr(orig[fidx][sid], dec[fidx][sid]))

    min_p = float(np.min(psnrs))
    mean_p = float(np.mean(psnrs))
    assert min_p > 24.0, f"min PSNR {min_p:.2f} dB (mean {mean_p:.2f})"
    assert mean_p > 28.0


def test_nvenc_writer_errors_when_encode_disabled(tmp_path, monkeypatch):
    monkeypatch.setenv("MVDATA_DISABLE_NVENC_ENCODE", "1")
    assert not nvenc_encode_allowed()

    legacy_dir = tmp_path / "leg"
    _create_legacy_jpg_dataset(legacy_dir, num_frames=2, num_streams=1)
    legacy = LegacyDataset(legacy_dir)

    writer = RangedDatasetWriter(
        legacy,
        tmp_path / "out",
        copy_meta=False,
        stash_policy="ignore",
        ranged_compression="nvenc_h264",
        prefetch_frames=0,
    )
    with pytest.raises(RuntimeError, match="NVENC ranged compression is disabled"):
        writer.write()


def _find_legacy_root_under(extract_root: Path) -> Path | None:
    for p in extract_root.rglob("*"):
        if not p.is_dir():
            continue
        rgb = p / "rgb"
        if not rgb.is_dir():
            continue
        jpgs = list(rgb.glob("*.jpg")) + list(rgb.glob("*.jpeg"))
        if jpgs:
            return p
    return None


@pytest.mark.skipif(
    not os.environ.get("MVDATA_TEST_LEGACY_URL", "").strip(),
    reason="Set MVDATA_TEST_LEGACY_URL to an HTTPS URL of a .zip Legacy sample (optional)",
)
def test_legacy_url_nvenc_roundtrip_optional(tmp_path):
    if not nvenc_encoding_usable() or not nvenc_encode_allowed():
        pytest.skip("NVENC not available")

    import urllib.request

    url = os.environ["MVDATA_TEST_LEGACY_URL"].strip()
    zpath = tmp_path / "legacy_sample.zip"
    urllib.request.urlretrieve(url, zpath)
    extract_dir = tmp_path / "extracted"
    extract_dir.mkdir()
    with zipfile.ZipFile(zpath) as zf:
        zf.extractall(extract_dir)

    leg_root = _find_legacy_root_under(extract_dir)
    assert leg_root is not None, "Unpacked zip has no */rgb/*.jpg Legacy layout"

    legacy = LegacyDataset(leg_root)
    ranges = legacy.get_frame_ranges()
    start = ranges[0][0]
    frame_ids = [start, start + 1, start + 2]
    streams = sorted(legacy.stream_ids)[:2]

    reader = legacy.create_frame_reader(
        stream_ids=streams, start_frame=frame_ids[0], end_frame=frame_ids[-1]
    )
    orig = {}
    try:
        for fi, data in reader:
            if fi in frame_ids:
                orig[fi] = {s: data[s].copy() for s in streams}
    finally:
        reader.close()

    ranged_dir = tmp_path / "ranged_nvenc_url"
    writer = RangedDatasetWriter(
        legacy,
        ranged_dir,
        start_frame=frame_ids[0],
        end_frame=frame_ids[-1],
        stream_ids=streams,
        frames_per_batch=64,
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        prefetch_frames=0,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(
            gpu_id=0,
            fps=30,
            chroma_subsampling="420",
            preset="P7",
        ),
    )
    ranged = writer.write()
    dec_reader = ranged.create_frame_reader(
        stream_ids=streams, start_frame=frame_ids[0], end_frame=frame_ids[-1]
    )
    try:
        for fi in frame_ids:
            _, got = dec_reader.read_frame(fi)
            for s in streams:
                p = calculate_psnr(orig[fi][s], got[s])
                assert p > 22.0, f"stream {s} frame {fi} PSNR={p:.2f}"
    finally:
        dec_reader.close()


# ---------------------------------------------------------------------------
# NVDEC decode tests
# ---------------------------------------------------------------------------

requires_nvdec = pytest.mark.skipif(
    not nvdec_decoding_usable(),
    reason="NVDEC path skipped (no PyNvVideoCodec or MVDATA_DISABLE_*)",
)


def _encode_test_mp4(
    tmp_path: Path,
    height: int = 128,
    width: int = 192,
    num_frames: int = 3,
    *,
    codec: str = "h264",
    chroma_subsampling: str = "444",
    full_range: bool = True,
):
    """Encode a small procedural MP4 and return (mp4_path, source_frames)."""
    from mvdata.nvenc_codec import (
        encode_rgb_sequence_to_mp4,
        pad_rgb_for_nvenc,
        resolve_nvenc_bitrate_bps,
        try_import_pynvvideocodec,
    )

    nvc = try_import_pynvvideocodec()
    frames = []
    for i in range(num_frames):
        img = np.zeros((height, width, 3), dtype=np.uint8)
        img[:, :, 0] = np.tile(np.linspace(5, 250, width, dtype=np.uint8), (height, 1))
        img[:, :, 1] = np.tile(
            np.linspace(5, 250, height, dtype=np.uint8).reshape(-1, 1), (1, width)
        )
        img[:, :, 2] = (128 + i * 30) % 256
        frames.append(img)

    padded, _ = pad_rgb_for_nvenc(frames[0])
    eh, ew, _ = padded.shape
    bitrate = resolve_nvenc_bitrate_bps(0, ew, eh, 30, chroma_subsampling=chroma_subsampling)

    mp4 = tmp_path / f"test_{codec}_{chroma_subsampling}_{int(full_range)}.mp4"
    encode_rgb_sequence_to_mp4(
        nvc, frames, mp4,
        gpu_id=0, fps=30, bitrate=bitrate,
        codec=codec,
        full_range=full_range,
        chroma_subsampling=chroma_subsampling,
        preset="P7",
    )
    return mp4, frames


@requires_nvenc
@requires_nvdec
def test_nvdec_vs_pyav_decode_agreement(tmp_path):
    """NVDEC and PyAV should produce nearly identical RGB output."""
    from mvdata.nvenc_codec import (
        decode_mp4_to_rgb_nvdec,
        decode_mp4_to_rgb_pyav,
        try_import_pynvvideocodec,
    )

    mp4, source = _encode_test_mp4(tmp_path)
    n = len(source)

    pyav_frames = decode_mp4_to_rgb_pyav(mp4, n)
    nvc = try_import_pynvvideocodec()
    try:
        nvdec_frames = decode_mp4_to_rgb_nvdec(nvc, mp4, gpu_id=0, expect_count=n)
    except RuntimeError as e:
        msg = str(e).lower()
        if "not supported" in msg or "does not support" in msg or "unsupported" in msg or "801" in msg:
            pytest.skip("NVDEC does not support H.264 High 4:4:4 on this GPU")
        raise

    assert len(pyav_frames) == n
    assert len(nvdec_frames) == n

    for i in range(n):
        assert pyav_frames[i].shape == nvdec_frames[i].shape, (
            f"Frame {i}: shape mismatch {pyav_frames[i].shape} vs {nvdec_frames[i].shape}"
        )
        psnr = calculate_psnr(pyav_frames[i], nvdec_frames[i])
        max_diff = int(np.max(np.abs(
            pyav_frames[i].astype(np.int16) - nvdec_frames[i].astype(np.int16)
        )))
        assert psnr > 40.0, (
            f"Frame {i}: NVDEC vs PyAV PSNR={psnr:.2f} dB, max_diff={max_diff}. "
            f"Decoders disagree too much — possible color range / YUV conversion mismatch."
        )


@requires_nvenc
@requires_nvdec
def test_nvdec_roundtrip_color_fidelity(tmp_path):
    """NVENC encode → NVDEC decode round-trip must preserve colors (PSNR > 30 dB)."""
    from mvdata.nvenc_codec import (
        decode_mp4_to_rgb_nvdec,
        pad_rgb_for_nvenc,
        try_import_pynvvideocodec,
    )

    mp4, source = _encode_test_mp4(tmp_path)
    n = len(source)
    _, crop = pad_rgb_for_nvenc(source[0])
    y0, y1, x0, x1 = crop

    nvc = try_import_pynvvideocodec()
    try:
        decoded = decode_mp4_to_rgb_nvdec(nvc, mp4, gpu_id=0, expect_count=n)
    except RuntimeError as e:
        msg = str(e).lower()
        if "not supported" in msg or "does not support" in msg or "unsupported" in msg or "801" in msg:
            pytest.skip("NVDEC does not support H.264 High 4:4:4 on this GPU")
        raise
    decoded_cropped = [d[y0:y1, x0:x1] for d in decoded]

    psnrs = [calculate_psnr(source[i], decoded_cropped[i]) for i in range(n)]
    mean_psnr = float(np.mean(psnrs))
    min_psnr = float(np.min(psnrs))

    assert min_psnr > 30.0, (
        f"NVDEC round-trip min PSNR {min_psnr:.2f} dB — colour degradation "
        f"beyond acceptable compression artefacts"
    )
    assert mean_psnr > 34.0, f"NVDEC round-trip mean PSNR {mean_psnr:.2f} dB"


@requires_nvenc
def test_pyav_hevc_444_limited_range_roundtrip_color_fidelity(tmp_path):
    """PyAV decode should preserve HEVC 4:4:4 limited-range round-trips."""
    from mvdata.nvenc_codec import decode_mp4_to_rgb_pyav

    mp4, source = _encode_test_mp4(
        tmp_path,
        height=192,
        width=256,
        codec="hevc",
        chroma_subsampling="444",
        full_range=False,
    )
    decoded = decode_mp4_to_rgb_pyav(mp4, len(source))

    psnrs = [calculate_psnr(source[i], decoded[i]) for i in range(len(source))]
    mean_psnr = float(np.mean(psnrs))
    min_psnr = float(np.min(psnrs))

    assert min_psnr > 40.0, f"PyAV HEVC 4:4:4 limited-range min PSNR {min_psnr:.2f} dB"
    assert mean_psnr > 44.0, f"PyAV HEVC 4:4:4 limited-range mean PSNR {mean_psnr:.2f} dB"


@requires_nvenc
@requires_nvdec
def test_nvdec_hevc_444_limited_range_roundtrip_color_fidelity(tmp_path):
    """HEVC 4:4:4 limited-range should round-trip cleanly through NVDEC."""
    from mvdata.nvenc_codec import (
        decode_mp4_to_rgb_nvdec,
        try_import_pynvvideocodec,
    )

    mp4, source = _encode_test_mp4(
        tmp_path,
        height=192,
        width=256,
        codec="hevc",
        chroma_subsampling="444",
        full_range=False,
    )
    nvc = try_import_pynvvideocodec()
    try:
        decoded = decode_mp4_to_rgb_nvdec(nvc, mp4, gpu_id=0, expect_count=len(source))
    except RuntimeError as e:
        msg = str(e).lower()
        if "not supported" in msg or "does not support" in msg or "unsupported" in msg or "801" in msg:
            pytest.skip("NVDEC does not support HEVC 4:4:4 on this GPU")
        raise

    psnrs = [calculate_psnr(source[i], decoded[i]) for i in range(len(source))]
    mean_psnr = float(np.mean(psnrs))
    min_psnr = float(np.min(psnrs))

    assert min_psnr > 40.0, f"NVDEC HEVC 4:4:4 limited-range min PSNR {min_psnr:.2f} dB"
    assert mean_psnr > 44.0, f"NVDEC HEVC 4:4:4 limited-range mean PSNR {mean_psnr:.2f} dB"


@requires_nvenc
@requires_nvdec
def test_ranged_reader_uses_nvdec(tmp_path):
    """RangedDataset MP4 reader should use NVDEC and still produce correct colours."""
    legacy_dir = tmp_path / "legacy"
    _create_legacy_jpg_dataset(legacy_dir, num_frames=4, num_streams=2)
    legacy = LegacyDataset(legacy_dir)

    ranged_dir = tmp_path / "ranged_nvdec"
    writer = RangedDatasetWriter(
        legacy,
        ranged_dir,
        frames_per_batch=500,
        copy_meta=False,
        stash_policy="ignore",
        max_workers=2,
        prefetch_frames=0,
        ranged_compression="nvenc_h264",
        nvenc_settings=RangedNvencSettings(
            gpu_id=0,
            fps=30,
            bitrate_bps=0,
            codec="h264",
            chroma_subsampling="444",
            preset="P7",
        ),
    )
    ranged = writer.write()

    orig = _read_all_frames_map(legacy)
    dec = _read_all_frames_map(ranged)
    assert set(orig.keys()) == set(dec.keys())

    psnrs = []
    for fidx in sorted(orig.keys()):
        for sid in sorted(orig[fidx].keys()):
            psnrs.append(calculate_psnr(orig[fidx][sid], dec[fidx][sid]))

    min_p = float(np.min(psnrs))
    mean_p = float(np.mean(psnrs))
    # Double-lossy pipeline (JPEG source → NVENC → decode) so thresholds
    # match the existing PyAV-decode test, not the single-step NVDEC test.
    assert min_p > 24.0, f"NVDEC reader min PSNR {min_p:.2f} dB (mean {mean_p:.2f})"
    assert mean_p > 28.0, f"NVDEC reader mean PSNR {mean_p:.2f} dB"
