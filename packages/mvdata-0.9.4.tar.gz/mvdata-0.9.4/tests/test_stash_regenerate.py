"""Tests for stash regeneration API (regenerate_stash, delete_stash).

These tests cover:
- regenerate_stash() from self (default)
- regenerate_stash() from a different source dataset
- delete_stash() functionality
- Edge cases and error handling
"""

import filecmp
import numpy as np
from pathlib import Path
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for stash regeneration tests")
pytest.importorskip("av", reason="PyAV is required for stash regeneration tests")

from mvdata import (
    LegacyDataset,
    RangedDataset,
    RangedDatasetWriter,
    MultiVideoDataset,
    MultiVideoDatasetWriter,
)


# =============================================================================
# Test Data Generators
# =============================================================================


def create_test_image(width: int = 32, height: int = 32, seed: int = 0) -> np.ndarray:
    """Create a deterministic test image."""
    rng = np.random.default_rng(seed)
    return rng.integers(0, 256, (height, width, 3), dtype=np.uint8)


def create_legacy_dataset(
    path: Path,
    num_frames: int = 5,
    num_streams: int = 2,
    image_format: str = "png",
) -> LegacyDataset:
    """Create a Legacy dataset with test data."""
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            img = create_test_image(seed=frame_idx * 100 + stream_id)
            img_pil = Image.fromarray(img, mode="RGB")
            img_pil.save(frame_dir / f"{stream_id:03d}.{image_format}")

    return LegacyDataset(path)


def _make_encoder_options():
    """Create encoder options for ranged dataset."""
    from pyavif import EncoderOptions
    opts = EncoderOptions()
    opts.quality = 80
    opts.speed = 8
    return opts


def create_ranged_dataset(tmp_path: Path, num_frames: int = 5, num_streams: int = 2) -> RangedDataset:
    """Create a Ranged dataset from a temporary Legacy dataset."""
    legacy_path = tmp_path / "legacy_source"
    create_legacy_dataset(legacy_path, num_frames, num_streams)
    legacy_ds = LegacyDataset(legacy_path)

    ranged_path = tmp_path / "ranged_output"
    writer = RangedDatasetWriter(
        legacy_ds,
        ranged_path,
        frames_per_batch=num_frames,
        encoder_options=_make_encoder_options(),
        stash_policy="ignore",
        max_workers=2,
    )
    return writer.write()


def create_multivideo_dataset(tmp_path: Path, num_frames: int = 5, num_streams: int = 2) -> MultiVideoDataset:
    """Create a MultiVideo dataset from a temporary Legacy dataset."""
    legacy_path = tmp_path / "legacy_source"
    create_legacy_dataset(legacy_path, num_frames, num_streams)
    legacy_ds = LegacyDataset(legacy_path)

    mv_path = tmp_path / "multivideo_output"
    writer = MultiVideoDatasetWriter(
        legacy_ds,
        mv_path,
        video_codec="h264",
        fps=30,
        crf=28,
        preset="ultrafast",
        stash_policy="ignore",
        max_workers=2,
    )
    return writer.write()


# =============================================================================
# Tests: delete_stash()
# =============================================================================


class TestDeleteStash:
    """Tests for delete_stash() method."""

    def test_delete_stash_removes_numbered_frames(self, tmp_path):
        """delete_stash should remove all numbered stash frames."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5)
        ds.generate_stash_frames(num_frames=3, overwrite_existing=True)

        assert len(ds.get_stash_frames()) == 3

        deleted = ds.delete_stash(verbose=False)

        assert deleted == 3
        assert len(ds.get_stash_frames()) == 0

    def test_delete_stash_preserves_extra_stash(self, tmp_path):
        """delete_stash should preserve non-numbered (extra) stash directories."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5)
        ds.generate_stash_frames(num_frames=2, overwrite_existing=True)

        # Create extra stash (non-numbered)
        extra_dir = tmp_path / "dataset" / "stash" / "reference" / "rgb"
        extra_dir.mkdir(parents=True)
        img = create_test_image(seed=999)
        img_pil = Image.fromarray(img, mode="RGB")
        img_pil.save(extra_dir / "000.png")

        # Verify both exist
        assert len(ds.get_stash_frames()) == 2
        ds._extra_stash_frames_cache = None  # Clear cache
        assert len(ds.get_extra_stash_frames()) == 1

        # Delete numbered stash
        deleted = ds.delete_stash(verbose=False)

        assert deleted == 2
        assert len(ds.get_stash_frames()) == 0
        # Extra stash should still exist
        ds._extra_stash_frames_cache = None
        assert len(ds.get_extra_stash_frames()) == 1

    def test_delete_stash_on_empty_stash(self, tmp_path):
        """delete_stash should return 0 when no stash exists."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5)

        assert len(ds.get_stash_frames()) == 0

        deleted = ds.delete_stash(verbose=False)

        assert deleted == 0


# =============================================================================
# Tests: regenerate_stash() from self
# =============================================================================


class TestRegenerateStashFromSelf:
    """Tests for regenerate_stash() when source is not specified (uses self)."""

    def test_regenerate_from_self_legacy(self, tmp_path):
        """Legacy dataset can regenerate stash from itself."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=10)

        generated = ds.regenerate_stash(num_frames=3, verbose=False)

        assert len(generated) == 3
        assert len(ds.get_stash_frames()) == 3

    def test_regenerate_from_self_ranged(self, tmp_path):
        """Ranged dataset can regenerate stash from itself (decodes from AVIF)."""
        ds = create_ranged_dataset(tmp_path / "ranged", num_frames=5)

        generated = ds.regenerate_stash(num_frames=2, verbose=False)

        assert len(generated) == 2
        stash = ds.get_stash_frames()
        assert len(stash) == 2

        # Should be PNG (decoded from AVIF)
        for _, stream_map in stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"

    def test_regenerate_from_self_multivideo(self, tmp_path):
        """MultiVideo dataset can regenerate stash from itself (decodes from video)."""
        ds = create_multivideo_dataset(tmp_path / "mv", num_frames=5)

        generated = ds.regenerate_stash(num_frames=2, verbose=False)

        assert len(generated) == 2
        stash = ds.get_stash_frames()
        assert len(stash) == 2

        # Should be PNG (decoded from video)
        for _, stream_map in stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"

    def test_regenerate_deletes_existing_by_default(self, tmp_path):
        """regenerate_stash should delete existing stash by default."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=10)
        ds.generate_stash_frames(num_frames=5, overwrite_existing=True)

        assert len(ds.get_stash_frames()) == 5

        # Regenerate with fewer frames
        generated = ds.regenerate_stash(num_frames=2, verbose=False)

        assert len(generated) == 2
        assert len(ds.get_stash_frames()) == 2

    def test_regenerate_preserves_existing_when_requested(self, tmp_path):
        """regenerate_stash with delete_existing=False should add to existing."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=10)

        # First generation: frames 0 and 9
        ds.regenerate_stash(num_frames=2, delete_existing=True, verbose=False)
        first_frames = [fn for fn, _ in ds.get_stash_frames()]
        assert len(first_frames) == 2

        # Second generation with delete_existing=False
        # This will try to generate the same frames, which may overwrite
        ds.regenerate_stash(num_frames=3, delete_existing=False, verbose=False)
        
        # Should have stash frames
        assert len(ds.get_stash_frames()) >= 2


# =============================================================================
# Tests: regenerate_stash() from different source
# =============================================================================


class TestRegenerateStashFromSource:
    """Tests for regenerate_stash() when using a different source dataset."""

    def test_regenerate_ranged_from_legacy_source(self, tmp_path):
        """Ranged dataset can regenerate stash from original Legacy source."""
        # Create Legacy source
        legacy_path = tmp_path / "legacy"
        legacy_ds = create_legacy_dataset(legacy_path, num_frames=5, image_format="png")

        # Convert to Ranged (without stash)
        ranged_path = tmp_path / "ranged"
        writer = RangedDatasetWriter(
            legacy_ds,
            ranged_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="ignore",
            max_workers=2,
        )
        ranged_ds = writer.write()

        assert len(ranged_ds.get_stash_frames()) == 0

        # Regenerate stash from Legacy source
        generated = ranged_ds.regenerate_stash(
            num_frames=2,
            source=legacy_ds,
            verbose=False,
        )

        assert len(generated) == 2
        stash = ranged_ds.get_stash_frames()
        assert len(stash) == 2

        # Should preserve source format (PNG from Legacy)
        for _, stream_map in stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"

    def test_regenerate_from_legacy_uses_direct_copy(self, tmp_path):
        """Regenerating from Legacy source should use direct file copy."""
        # Create Legacy source
        legacy_path = tmp_path / "legacy"
        legacy_ds = create_legacy_dataset(legacy_path, num_frames=5, image_format="png")

        # Convert to Ranged
        ranged_path = tmp_path / "ranged"
        writer = RangedDatasetWriter(
            legacy_ds,
            ranged_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="ignore",
            max_workers=2,
        )
        ranged_ds = writer.write()

        # Regenerate from Legacy
        ranged_ds.regenerate_stash(num_frames=2, source=legacy_ds, verbose=False)

        # Verify files are byte-identical (direct copy)
        stash = ranged_ds.get_stash_frames()
        for frame_num, stream_map in stash:
            source_paths = legacy_ds.get_frame_source_paths(frame_num)
            assert source_paths is not None

            for stream_id, stash_path in stream_map.items():
                src_path = source_paths[stream_id]
                assert filecmp.cmp(src_path, stash_path, shallow=False), \
                    "Stash from Legacy should be byte-identical (direct copy)"

    def test_regenerate_multivideo_from_legacy_source(self, tmp_path):
        """MultiVideo dataset can regenerate stash from Legacy source."""
        # Create Legacy source
        legacy_path = tmp_path / "legacy"
        legacy_ds = create_legacy_dataset(legacy_path, num_frames=5)

        # Convert to MultiVideo
        mv_path = tmp_path / "mv"
        writer = MultiVideoDatasetWriter(
            legacy_ds,
            mv_path,
            video_codec="h264",
            fps=30,
            crf=28,
            preset="ultrafast",
            stash_policy="ignore",
            max_workers=2,
        )
        mv_ds = writer.write()

        # Regenerate from Legacy
        generated = mv_ds.regenerate_stash(
            num_frames=2,
            source=legacy_ds,
            verbose=False,
        )

        assert len(generated) == 2
        assert len(mv_ds.get_stash_frames()) == 2

    def test_regenerate_legacy_from_ranged_source(self, tmp_path):
        """Legacy dataset can regenerate stash from Ranged source (decodes)."""
        # Create Ranged source
        ranged_ds = create_ranged_dataset(tmp_path / "ranged", num_frames=5)

        # Create empty Legacy target
        legacy_path = tmp_path / "legacy"
        legacy_path.mkdir()
        for i in range(5):
            frame_dir = legacy_path / f"{i:08d}" / "rgb"
            frame_dir.mkdir(parents=True)
            img = create_test_image(seed=i * 100)
            img_pil = Image.fromarray(img, mode="RGB")
            img_pil.save(frame_dir / "000.png")

        legacy_ds = LegacyDataset(legacy_path)

        # Regenerate from Ranged source
        generated = legacy_ds.regenerate_stash(
            num_frames=2,
            source=ranged_ds,
            verbose=False,
        )

        assert len(generated) == 2
        stash = legacy_ds.get_stash_frames()
        assert len(stash) == 2

        # Should be PNG (decoded from AVIF)
        for _, stream_map in stash:
            for _, path in stream_map.items():
                assert path.suffix == ".png"


# =============================================================================
# Tests: Edge cases and error handling
# =============================================================================


class TestRegenerateStashEdgeCases:
    """Tests for edge cases and error handling in regenerate_stash()."""

    def test_regenerate_with_frame_range(self, tmp_path):
        """regenerate_stash should respect start_frame and end_frame."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=10)

        generated = ds.regenerate_stash(
            num_frames=3,
            start_frame=2,
            end_frame=7,
            verbose=False,
        )

        assert len(generated) == 3
        # All frames should be within [2, 7]
        for frame_num in generated:
            assert 2 <= frame_num <= 7

    def test_regenerate_with_stream_filter(self, tmp_path):
        """regenerate_stash should respect stream_ids filter."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5, num_streams=4)

        generated = ds.regenerate_stash(
            num_frames=2,
            stream_ids=[0, 2],
            verbose=False,
        )

        assert len(generated) == 2
        stash = ds.get_stash_frames()

        for _, stream_map in stash:
            assert sorted(stream_map.keys()) == [0, 2]

    def test_regenerate_raises_on_invalid_range(self, tmp_path):
        """regenerate_stash should raise ValueError for invalid frame range."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5)

        with pytest.raises(ValueError, match="outside.*range"):
            ds.regenerate_stash(
                num_frames=2,
                start_frame=10,  # Invalid: beyond dataset
                end_frame=15,
                verbose=False,
            )

    def test_regenerate_raises_on_source_range_mismatch(self, tmp_path):
        """regenerate_stash should raise if requested range is outside source."""
        # Create Legacy with frames 0-4
        legacy_path = tmp_path / "legacy"
        legacy_ds = create_legacy_dataset(legacy_path, num_frames=5)

        # Create Ranged with frames 0-9 (larger)
        ranged_path = tmp_path / "ranged"
        for i in range(10):
            frame_dir = ranged_path / f"{i:08d}" / "rgb"
            frame_dir.mkdir(parents=True)
            img = create_test_image(seed=i * 100)
            img_pil = Image.fromarray(img, mode="RGB")
            img_pil.save(frame_dir / "000.png")

        target_ds = LegacyDataset(ranged_path)

        # Try to regenerate frames 6-9 from Legacy (which only has 0-4)
        with pytest.raises(ValueError, match="outside.*source"):
            target_ds.regenerate_stash(
                num_frames=2,
                source=legacy_ds,
                start_frame=6,
                end_frame=9,
                verbose=False,
            )

    def test_regenerate_zero_frames(self, tmp_path):
        """regenerate_stash with num_frames=0 should generate nothing."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=5)

        generated = ds.regenerate_stash(num_frames=0, verbose=False)

        assert generated == []
        assert len(ds.get_stash_frames()) == 0


# =============================================================================
# Tests: Integration with converted datasets
# =============================================================================


class TestRegenerateStashIntegration:
    """Integration tests simulating real-world usage patterns."""

    def test_workflow_convert_then_regenerate(self, tmp_path):
        """Simulate: convert dataset, then regenerate stash from original."""
        # Step 1: Create original Legacy dataset
        original_path = tmp_path / "original"
        original_ds = create_legacy_dataset(original_path, num_frames=5)

        # Step 2: Convert to Ranged with no stash (stash_policy="ignore")
        converted_path = tmp_path / "converted"
        writer = RangedDatasetWriter(
            original_ds,
            converted_path,
            frames_per_batch=5,
            encoder_options=_make_encoder_options(),
            stash_policy="ignore",
            max_workers=2,
        )
        converted_ds = writer.write()

        assert len(converted_ds.get_stash_frames()) == 0

        # Step 3: Later, regenerate stash from original (high quality)
        generated = converted_ds.regenerate_stash(
            num_frames=3,
            source=original_ds,
            verbose=False,
        )

        assert len(generated) == 3
        assert len(converted_ds.get_stash_frames()) == 3

    def test_workflow_regenerate_with_different_num_frames(self, tmp_path):
        """Simulate: regenerate stash multiple times with different counts."""
        ds = create_legacy_dataset(tmp_path / "dataset", num_frames=10)

        # First: generate 2 frames
        ds.regenerate_stash(num_frames=2, verbose=False)
        assert len(ds.get_stash_frames()) == 2

        # Second: regenerate with 5 frames
        ds.regenerate_stash(num_frames=5, verbose=False)
        assert len(ds.get_stash_frames()) == 5

        # Third: regenerate with 3 frames
        ds.regenerate_stash(num_frames=3, verbose=False)
        assert len(ds.get_stash_frames()) == 3
