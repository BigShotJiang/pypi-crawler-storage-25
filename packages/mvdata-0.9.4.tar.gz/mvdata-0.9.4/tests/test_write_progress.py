import json

import pytest

from mvdata.write_progress import PROGRESS_FILENAME, WriteProgress


def test_load_or_create_rejects_corrupt_manifest(tmp_path):
    progress_path = tmp_path / PROGRESS_FILENAME
    progress_path.write_text('{"completed": [', encoding="utf-8")

    with pytest.raises(ValueError, match="progress manifest is unreadable or corrupt"):
        WriteProgress.load_or_create(
            tmp_path,
            writer_name="TestWriter",
            config={"frames_per_batch": 3},
        )


def test_save_leaves_no_temp_manifest_files(tmp_path):
    progress = WriteProgress.create_fresh(
        tmp_path,
        writer_name="TestWriter",
        config={"frames_per_batch": 3},
    )

    progress.begin("sb0/00000000_00000002")

    progress_path = tmp_path / PROGRESS_FILENAME
    saved = json.loads(progress_path.read_text(encoding="utf-8"))

    assert saved["in_progress"] == "sb0/00000000_00000002"
    assert not list(tmp_path.glob(f"{PROGRESS_FILENAME}.*.tmp"))
