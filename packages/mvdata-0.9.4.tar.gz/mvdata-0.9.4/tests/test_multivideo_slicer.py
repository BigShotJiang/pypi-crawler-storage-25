from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess

import numpy as np
from PIL import Image
import pytest

av = pytest.importorskip("av")

from mvdata import MultiVideoDataset, MultiVideoSliceError, MultiVideoToRangedSlicer, RangedDataset
import mvdata.multivideo_slicer as slicer_mod
from mvdata.multivideo_slicer import (
    MultiVideoSliceRange,
    _VideoPacketRecord,
    _packet_copy_plans_from_records,
)


def _write_h264_test_video(path, *, num_frames: int, keyint: int, stream_offset: int = 0) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        container = av.open(str(path), mode="w")
        stream = container.add_stream("libx264", rate=Fraction(30, 1))
    except Exception as exc:
        pytest.skip(f"libx264 is unavailable in this PyAV build: {exc}")

    stream.width = 64
    stream.height = 48
    stream.pix_fmt = "yuv420p"
    stream.gop_size = keyint
    stream.options = {
        "preset": "ultrafast",
        "crf": "18",
        "x264-params": f"keyint={keyint}:min-keyint={keyint}:scenecut=0",
    }

    try:
        for frame_index in range(num_frames):
            frame_array = np.empty((48, 64, 3), dtype=np.uint8)
            frame_array[:, :, 0] = (frame_index * 17 + stream_offset) % 255
            frame_array[:, :, 1] = np.arange(64, dtype=np.uint8)
            frame_array[:, :, 2] = np.arange(48, dtype=np.uint8).reshape(48, 1)

            frame = av.VideoFrame.from_ndarray(frame_array, format="rgb24")
            frame.pts = frame_index
            for packet in stream.encode(frame):
                container.mux(packet)

        for packet in stream.encode():
            container.mux(packet)
    finally:
        container.close()


def _write_preroll_h264_test_video(
    path, *, num_frames: int, keyint: int, stream_offset: int = 0
) -> None:
    if shutil.which("ffmpeg") is None:
        pytest.skip("ffmpeg is required to generate the preroll fixture")

    base_path = path.with_name(f"{path.stem}_base{path.suffix}")
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        container = av.open(str(base_path), mode="w")
        stream = container.add_stream("libx264", rate=Fraction(30000, 1001))
    except Exception as exc:
        pytest.skip(f"libx264 is unavailable in this PyAV build: {exc}")

    stream.width = 64
    stream.height = 48
    stream.pix_fmt = "yuv420p"
    stream.gop_size = keyint
    stream.options = {
        "preset": "medium",
        "crf": "18",
        "x264-params": f"keyint={keyint}:min-keyint={keyint}:scenecut=0:bframes=2:open-gop=1",
    }

    try:
        for frame_index in range(num_frames):
            frame_array = np.empty((48, 64, 3), dtype=np.uint8)
            frame_array[:, :, 0] = (frame_index * 17 + stream_offset) % 255
            frame_array[:, :, 1] = np.arange(64, dtype=np.uint8)
            frame_array[:, :, 2] = np.arange(48, dtype=np.uint8).reshape(48, 1)

            frame = av.VideoFrame.from_ndarray(frame_array, format="rgb24")
            frame.pts = frame_index
            for packet in stream.encode(frame):
                container.mux(packet)

        for packet in stream.encode():
            container.mux(packet)
    finally:
        container.close()

    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-loglevel",
            "error",
            "-ss",
            "0.100",
            "-i",
            str(base_path),
            "-c",
            "copy",
            "-avoid_negative_ts",
            "disabled",
            str(path),
        ],
        check=True,
    )
    base_path.unlink()


def _write_open_gop_h264_test_video(
    path, *, num_frames: int, keyint: int, stream_offset: int = 0
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    try:
        container = av.open(str(path), mode="w")
        stream = container.add_stream("libx264", rate=Fraction(30000, 1001))
    except Exception as exc:
        pytest.skip(f"libx264 is unavailable in this PyAV build: {exc}")

    stream.width = 64
    stream.height = 48
    stream.pix_fmt = "yuv420p"
    stream.gop_size = keyint
    stream.options = {
        "preset": "medium",
        "crf": "18",
        "x264-params": f"keyint={keyint}:min-keyint={keyint}:scenecut=0:bframes=2:open-gop=1",
    }

    try:
        for frame_index in range(num_frames):
            frame_array = np.empty((48, 64, 3), dtype=np.uint8)
            frame_array[:, :, 0] = (frame_index * 17 + stream_offset) % 255
            frame_array[:, :, 1] = np.arange(64, dtype=np.uint8)
            frame_array[:, :, 2] = np.arange(48, dtype=np.uint8).reshape(48, 1)

            frame = av.VideoFrame.from_ndarray(frame_array, format="rgb24")
            frame.pts = frame_index
            for packet in stream.encode(frame):
                container.mux(packet)

        for packet in stream.encode():
            container.mux(packet)
    finally:
        container.close()


def _decode_rgb_frame(path, frame_index: int) -> np.ndarray:
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        for index, frame in enumerate(container.decode(stream)):
            if index == frame_index:
                return frame.to_ndarray(format="rgb24")
    raise AssertionError(f"frame {frame_index} not decoded from {path}")


def _decoded_frame_count(path) -> int:
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        return sum(1 for _ in container.decode(stream))


def _video_start_time(path) -> Fraction:
    with av.open(str(path)) as container:
        stream = container.streams.video[0]
        if stream.start_time is None:
            return Fraction(0)
        return Fraction(stream.start_time) * stream.time_base


def test_copy_packet_for_mux_preserves_mux_metadata():
    packet = av.Packet(b"packet-bytes")
    packet.pts = 101
    packet.dts = 99
    packet.duration = 3
    packet.time_base = Fraction(1, 30000)
    packet.is_keyframe = True
    packet.is_corrupt = False
    packet.opaque = {"source": "test"}

    packet_copy = slicer_mod._copy_packet_for_mux(packet)

    assert packet_copy is not packet
    assert bytes(packet_copy) == bytes(packet)
    assert packet_copy.pts == packet.pts
    assert packet_copy.dts == packet.dts
    assert packet_copy.duration == packet.duration
    assert packet_copy.time_base == packet.time_base
    assert packet_copy.is_keyframe == packet.is_keyframe
    assert packet_copy.is_corrupt == packet.is_corrupt
    assert packet_copy.opaque == packet.opaque


def test_multivideo_to_ranged_slicer_checks_eligibility_then_writes(tmp_path):
    source_path = tmp_path / "source"
    _write_h264_test_video(source_path / "000.mp4", num_frames=12, keyint=4)
    _write_h264_test_video(source_path / "001.mp4", num_frames=13, keyint=4, stream_offset=50)

    dataset = MultiVideoDataset(source_path)
    output_path = tmp_path / "ranged"
    slicer = MultiVideoToRangedSlicer(
        dataset,
        output_path,
        target_frames=5,
        tail_tolerance_frames=1,
        stash_policy="generate",
        stash_num_frames=2,
        verbose=False,
    )

    eligibility = slicer.check_eligibility()

    assert eligibility.eligible
    assert output_path.exists() is False
    assert eligibility.plan is not None
    assert eligibility.metadata.selected_stream_ids == (0, 1)
    assert eligibility.metadata.passed_stream_ids == (0, 1)
    assert eligibility.metadata.failed_stream_ids == ()
    assert eligibility.metadata.resulting_dataset_frame_count == 12
    assert eligibility.metadata.resulting_dataset_start_frame == 0
    assert eligibility.metadata.resulting_dataset_end_frame == 11
    assert eligibility.metadata.range_count == 3
    assert eligibility.metadata.first_ranges == (
        "00000000_00000003",
        "00000004_00000007",
        "00000008_00000011",
    )
    assert eligibility.plan.chosen_step_frames == 4
    assert eligibility.plan.discarded_tail_frames == {1: 1}
    assert eligibility.metadata.discarded_tail_frames == {1: 1}
    assert eligibility.to_dict()["metadata"]["resulting_dataset_frame_count"] == 12
    assert [range_info.output_name for range_info in eligibility.plan.ranges] == [
        "00000000_00000003",
        "00000004_00000007",
        "00000008_00000011",
    ]

    ranged = slicer.write()

    assert isinstance(ranged, RangedDataset)
    assert ranged.get_frame_ranges() == [
        (0, 3, output_path / "00000000_00000003"),
        (4, 7, output_path / "00000004_00000007"),
        (8, 11, output_path / "00000008_00000011"),
    ]
    assert (output_path / "00000004_00000007" / "rgb" / "000.mp4").stat().st_size > 0
    assert (output_path / "00000004_00000007" / "rgb" / "001.mp4").stat().st_size > 0
    assert _video_start_time(output_path / "00000004_00000007" / "rgb" / "000.mp4") == 0
    assert _video_start_time(output_path / "00000008_00000011" / "rgb" / "000.mp4") == 0
    assert len(ranged.get_stash_frames()) == 2
    for range_start, range_end, range_dir in ranged.get_frame_ranges():
        expected_frames = range_end - range_start + 1
        assert _decoded_frame_count(range_dir / "rgb" / "000.mp4") == expected_frames
        assert _decoded_frame_count(range_dir / "rgb" / "001.mp4") == expected_frames

    reader = ranged.create_frame_reader(start_frame=4, end_frame=4)
    try:
        frame_index, frame_data = reader.read_frame(4)
    finally:
        reader.close()

    assert frame_index == 4
    assert sorted(frame_data) == [0, 1]
    assert frame_data[0].shape == (48, 64, 3)


def test_multivideo_to_ranged_slicer_auto_stash_copies_when_present(tmp_path):
    source_path = tmp_path / "source"
    _write_h264_test_video(source_path / "000.mp4", num_frames=12, keyint=4)
    _write_h264_test_video(source_path / "001.mp4", num_frames=12, keyint=4, stream_offset=50)
    stash_rgb = source_path / "stash" / "00000000" / "rgb"
    stash_rgb.mkdir(parents=True)
    Image.fromarray(np.full((8, 8, 3), 25, dtype=np.uint8), mode="RGB").save(
        stash_rgb / "000.png"
    )
    Image.fromarray(np.full((8, 8, 3), 50, dtype=np.uint8), mode="RGB").save(
        stash_rgb / "001.png"
    )

    dataset = MultiVideoDataset(source_path)
    output_path = tmp_path / "ranged"
    slicer = MultiVideoToRangedSlicer(
        dataset,
        output_path,
        target_frames=4,
        verbose=False,
    )

    assert slicer.requested_stash_policy == "auto"
    assert slicer.stash_policy == "copy"

    ranged = slicer.write()

    assert len(ranged.get_stash_frames()) == 1
    assert (output_path / "stash" / "00000000" / "rgb" / "000.png").read_bytes() == (
        stash_rgb / "000.png"
    ).read_bytes()


def test_multivideo_to_ranged_slicer_auto_stash_generates_when_absent(tmp_path):
    source_path = tmp_path / "source"
    _write_h264_test_video(source_path / "000.mp4", num_frames=12, keyint=4)
    _write_h264_test_video(source_path / "001.mp4", num_frames=12, keyint=4, stream_offset=50)

    dataset = MultiVideoDataset(source_path)
    output_path = tmp_path / "ranged"
    slicer = MultiVideoToRangedSlicer(
        dataset,
        output_path,
        target_frames=4,
        stash_num_frames=1,
        verbose=False,
    )

    assert slicer.requested_stash_policy == "auto"
    assert slicer.stash_policy == "generate"

    ranged = slicer.write()

    assert len(ranged.get_stash_frames()) == 1


def test_multivideo_to_ranged_slicer_reports_keyframe_mismatch(tmp_path):
    source_path = tmp_path / "source"
    _write_h264_test_video(source_path / "000.mp4", num_frames=12, keyint=4)
    _write_h264_test_video(source_path / "001.mp4", num_frames=12, keyint=5, stream_offset=50)

    dataset = MultiVideoDataset(source_path)
    slicer = MultiVideoToRangedSlicer(
        dataset,
        tmp_path / "ranged",
        target_frames=4,
        tail_tolerance_frames=0,
        stash_policy="ignore",
        verbose=False,
    )

    eligibility = slicer.check_eligibility()

    assert not eligibility.eligible
    assert any("Keyframe schedule mismatch" in error for error in eligibility.errors)
    assert eligibility.metadata.selected_stream_ids == (0, 1)
    assert eligibility.metadata.passed_stream_ids == (0,)
    assert eligibility.metadata.failed_stream_ids == (1,)
    assert eligibility.metadata.stream_results[1].errors
    with pytest.raises(MultiVideoSliceError, match="not eligible"):
        slicer.write()


def test_multivideo_to_ranged_slicer_rejects_degenerate_ranges(tmp_path):
    source_path = tmp_path / "source"
    _write_h264_test_video(source_path / "000.mp4", num_frames=100, keyint=10)
    _write_h264_test_video(source_path / "001.mp4", num_frames=100, keyint=10, stream_offset=50)

    dataset = MultiVideoDataset(source_path)
    slicer = MultiVideoToRangedSlicer(
        dataset,
        tmp_path / "ranged",
        target_frames=90,
        stash_policy="ignore",
        verbose=False,
    )

    eligibility = slicer.check_eligibility()

    assert not eligibility.eligible
    assert any("degenerate ranged dataset" in error for error in eligibility.errors)
    assert eligibility.metadata.resulting_dataset_frame_count == 100
    assert eligibility.metadata.range_count == 2
    assert eligibility.metadata.first_ranges == (
        "00000000_00000089",
        "00000090_00000099",
    )
    assert eligibility.metadata.failed_stream_ids == ()


def test_packet_copy_plan_excludes_pre_boundary_b_frames():
    def record(
        packet_index,
        visible_index,
        *,
        keyframe=False,
        sync=None,
        discard=False,
        dts_index=None,
    ):
        if dts_index is None:
            dts_index = visible_index
        return _VideoPacketRecord(
            packet_index,
            pts=3000 + visible_index * 1001,
            dts=3000 + dts_index * 1001,
            is_keyframe=keyframe,
            is_discard=discard,
            is_sync=keyframe if sync is None else sync,
        )

    records = [
        record(0, 0, keyframe=True, dts_index=-3),
        record(1, -2, discard=True),
        record(2, -1, discard=True),
    ]
    for packet_index in range(3, 120):
        records.append(record(packet_index, packet_index - 2))
    records.extend(
        [
            record(120, 120, keyframe=True, dts_index=118),
            record(121, 118, dts_index=119),
            record(122, 119, dts_index=120),
            record(123, 121),
        ]
    )

    ranges = (
        MultiVideoSliceRange(0, 119, 0, 119),
        MultiVideoSliceRange(120, 121, 120, 121),
    )

    plans = _packet_copy_plans_from_records(list(records), ranges, stream_id=0)

    assert plans[ranges[0]].packet_start == 0
    assert plans[ranges[0]].packet_end == 122
    assert plans[ranges[0]].packet_indices.issuperset({120, 121, 122})
    assert plans[ranges[1]].packet_start == 120
    assert plans[ranges[1]].packet_end == 123
    assert plans[ranges[1]].packet_indices == frozenset({120, 123})
    assert plans[ranges[1]].presentation_frame_offset == 0


def test_packet_copy_plan_carries_preroll_from_previous_sync_for_open_gop_boundary():
    def record(packet_index, visible_index, *, keyframe=False, sync=False):
        return _VideoPacketRecord(
            packet_index,
            pts=visible_index * 1001,
            dts=(visible_index - 2) * 1001,
            is_keyframe=keyframe,
            is_discard=False,
            is_sync=sync,
        )

    records = [record(0, 0, keyframe=True, sync=True)]
    for packet_index in range(1, 120):
        records.append(record(packet_index, packet_index))
    records.extend(
        [
            record(120, 120, keyframe=True, sync=False),
            record(121, 121),
            record(122, 122),
        ]
    )

    ranges = (MultiVideoSliceRange(120, 121, 120, 121),)

    plans = _packet_copy_plans_from_records(records, ranges, stream_id=0)
    plan = plans[ranges[0]]

    assert plan.packet_start == 0
    assert plan.dependency_start_frame == 0
    assert plan.presentation_frame_offset == 120
    assert 0 in plan.packet_indices
    assert 120 in plan.packet_indices


def test_slice_video_demuxes_source_once_for_overlapping_ranges(monkeypatch, tmp_path):
    class FakePacket:
        def __init__(self, packet_index):
            self.packet_index = packet_index
            self.pts = packet_index * 100
            self.dts = packet_index * 100
            self.size = 1
            self.stream = None
            self.consumed = False

        def clone(self):
            packet = FakePacket(self.packet_index)
            packet.pts = self.pts
            packet.dts = self.dts
            packet.stream = self.stream
            return packet

    class FakeInputContainer:
        def __init__(self):
            self.streams = type("Streams", (), {"video": [object()]})()
            self.demux_calls = 0
            self.closed = False

        def demux(self, stream):
            self.demux_calls += 1
            for packet_index in range(4):
                yield FakePacket(packet_index)

        def close(self):
            self.closed = True

    class FakeOutputContainer:
        def __init__(self, path):
            self.path = path
            self.muxed_packets = []
            self.muxed_packet_objects = []
            self.muxed_timestamps = []
            self.closed = False

        def add_stream_from_template(self, input_stream, opaque=True):
            return object()

        def mux(self, packet):
            if packet.consumed:
                raise AssertionError("packet was muxed more than once")
            packet.consumed = True
            self.muxed_packets.append(packet.packet_index)
            self.muxed_packet_objects.append(packet)
            self.muxed_timestamps.append((packet.pts, packet.dts))

        def close(self):
            self.closed = True

    ranges = (
        MultiVideoSliceRange(0, 1, 0, 1),
        MultiVideoSliceRange(2, 3, 2, 3),
    )
    packet_plans = {
        ranges[0]: slicer_mod._PacketCopyPlan(0, 2, 0, frozenset({0, 1, 2})),
        ranges[1]: slicer_mod._PacketCopyPlan(2, 3, 200, frozenset({2, 3})),
    }
    input_containers = []
    output_containers = []

    def fake_open(path, mode=None, format=None):
        if mode == "w":
            output = FakeOutputContainer(path)
            output_containers.append(output)
            return output
        input_container = FakeInputContainer()
        input_containers.append(input_container)
        return input_container

    monkeypatch.setattr(slicer_mod, "_packet_copy_plans", lambda *args: packet_plans)
    monkeypatch.setattr(slicer_mod, "_copy_packet_for_mux", lambda packet: packet.clone())
    monkeypatch.setattr(slicer_mod, "_count_visible_video_packets", lambda path: 99)
    monkeypatch.setattr(slicer_mod, "_count_decoded_video_frames", lambda path: 2)
    monkeypatch.setattr(slicer_mod.av, "open", fake_open)

    slicer_mod._slice_video_to_ranged_mp4s(
        tmp_path / "source.mp4",
        tmp_path / "ranged",
        ranges,
        stream_id=0,
    )

    assert len(input_containers) == 1
    assert input_containers[0].demux_calls == 1
    muxed_by_range = {
        Path(output.path).parent.parent.name: output.muxed_packets
        for output in output_containers
    }
    assert muxed_by_range == {
        "00000000_00000001": [0, 1, 2],
        "00000002_00000003": [2, 3],
    }
    timestamps_by_range = {
        Path(output.path).parent.parent.name: output.muxed_timestamps
        for output in output_containers
    }
    assert timestamps_by_range == {
        "00000000_00000001": [(0, 0), (100, 100), (200, 200)],
        "00000002_00000003": [(0, 0), (100, 100)],
    }
    muxed_objects_by_packet = {}
    for output in output_containers:
        for packet in output.muxed_packet_objects:
            muxed_objects_by_packet.setdefault(packet.packet_index, []).append(packet)
    assert len({id(packet) for packet in muxed_objects_by_packet[2]}) == 2
    assert all(output.closed for output in output_containers)
    assert input_containers[0].closed


def test_slice_video_validates_decoded_frame_count(monkeypatch, tmp_path):
    source_path = tmp_path / "source" / "000.mp4"
    _write_h264_test_video(source_path, num_frames=2, keyint=1)

    ranges = (MultiVideoSliceRange(0, 0, 0, 0),)
    monkeypatch.setattr(slicer_mod, "_count_visible_video_packets", lambda path: 1)
    monkeypatch.setattr(slicer_mod, "_count_decoded_video_frames", lambda path: 0)

    with pytest.raises(MultiVideoSliceError, match="decoded frames"):
        slicer_mod._slice_video_to_ranged_mp4s(
            source_path,
            tmp_path / "ranged",
            ranges,
            stream_id=0,
        )


def test_multivideo_to_ranged_slicer_rejects_non_keyframe_visible_start(tmp_path):
    source_path = tmp_path / "source"
    _write_preroll_h264_test_video(source_path / "000.mp4", num_frames=80, keyint=15)
    _write_preroll_h264_test_video(
        source_path / "001.mp4", num_frames=80, keyint=15, stream_offset=50
    )

    dataset = MultiVideoDataset(source_path)
    source_frame_count = _decoded_frame_count(source_path / "000.mp4")
    assert dataset.get_frame_ranges()[0][1] + 1 == source_frame_count

    output_path = tmp_path / "ranged"
    slicer = MultiVideoToRangedSlicer(
        dataset,
        output_path,
        target_frames=15,
        stash_policy="ignore",
        verbose=False,
    )

    eligibility = slicer.check_eligibility()

    assert not eligibility.eligible
    assert any("first packet must be a keyframe" in error for error in eligibility.errors)
    with pytest.raises(MultiVideoSliceError, match="not eligible"):
        slicer.write()


def test_open_gop_slice_carries_previous_sync_and_reader_skips_preroll(tmp_path):
    source_path = tmp_path / "source"
    source_video = source_path / "000.mp4"
    _write_open_gop_h264_test_video(source_video, num_frames=130, keyint=60)

    dataset = MultiVideoDataset(source_path)
    output_path = tmp_path / "ranged"
    slicer = MultiVideoToRangedSlicer(
        dataset,
        output_path,
        target_frames=60,
        stash_policy="ignore",
        verbose=False,
    )

    eligibility = slicer.check_eligibility()

    assert eligibility.eligible
    ranged = slicer.write()
    metadata_path = (
        output_path
        / "00000060_00000119"
        / "rgb"
        / slicer_mod.RANGED_MP4_SLICE_METADATA_FILENAME
    )
    metadata = json.loads(metadata_path.read_text())
    stream_meta = metadata["streams"]["0"]
    assert stream_meta["dependency_start_frame"] == 0
    assert stream_meta["presentation_frame_offset"] == 60

    reader = ranged.create_frame_reader(start_frame=60, end_frame=60)
    try:
        _, frame_data = reader.read_frame(60)
    finally:
        reader.close()

    assert np.array_equal(frame_data[0], _decode_rgb_frame(source_video, 60))
