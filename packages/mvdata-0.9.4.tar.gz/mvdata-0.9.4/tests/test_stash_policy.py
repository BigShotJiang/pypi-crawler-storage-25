import numpy as np
from pathlib import Path
from PIL import Image
import pytest

pytest.importorskip("pyavif", reason="pyavif native extension is required for stash policy tests")
pytest.importorskip("av", reason="PyAV is required for stash policy tests")

from mvdata import (
    LegacyDataset,
    LegacyDatasetWriter,
    RangedDatasetWriter,
    MultiVideoDatasetWriter,
    RangedDataset,
    MultiVideoDataset,
)


def create_legacy_dataset(path: Path, num_frames: int = 5, num_streams: int = 2):
    for frame_idx in range(num_frames):
        frame_dir = path / f"{frame_idx:08d}" / "rgb"
        frame_dir.mkdir(parents=True)

        for stream_id in range(num_streams):
            img = np.zeros((32, 32, 3), dtype=np.uint8)
            img[:, :, 0] = (frame_idx * 20) % 256
            img[:, :, 1] = (stream_id * 40) % 256
            img[:, :, 2] = (frame_idx * 30 + stream_id * 10) % 256

            img_pil = Image.fromarray(img, mode="RGB")
            img_pil.save(frame_dir / f"{stream_id:03d}.png")

    return path


def select_expected_frames(start_frame: int, end_frame: int, num_frames: int):
    total = end_frame - start_frame + 1
    if total <= 0 or num_frames <= 0:
        return []

    num_frames = min(num_frames, total)
    if num_frames == total:
        return list(range(start_frame, end_frame + 1))

    indices = np.linspace(0, total - 1, num_frames, dtype=int)
    return [start_frame + i for i in indices]


def _make_encoder_options():
    from pyavif import EncoderOptions

    opts = EncoderOptions()
    opts.quality = 80
    opts.speed = 8
    return opts


WRITER_CASES = [
    (
        "legacy",
        LegacyDatasetWriter,
        LegacyDataset,
        {
            "image_format": "png",
            "max_workers": 2,
        },
    ),
    (
        "ranged",
        RangedDatasetWriter,
        RangedDataset,
        {
            "frames_per_batch": 5,
            "streams_per_batch": 2,
            "encoder_options": _make_encoder_options(),
            "max_workers": 2,
        },
    ),
    (
        "multivideo",
        MultiVideoDatasetWriter,
        MultiVideoDataset,
        {
            "video_codec": "h264",
            "fps": 30,
            "crf": 28,
            "preset": "ultrafast",
            "max_workers": 2,
        },
    ),
]


@pytest.mark.parametrize("writer_name, writer_cls, output_cls, writer_kwargs", WRITER_CASES)
def test_stash_policy_ignore(tmp_path, writer_name, writer_cls, output_cls, writer_kwargs):
    input_path = tmp_path / f"input_{writer_name}_ignore"
    create_legacy_dataset(input_path)
    input_dataset = LegacyDataset(input_path)
    input_dataset.generate_stash_frames(num_frames=2, overwrite_existing=True)

    output_path = tmp_path / f"output_{writer_name}_ignore"
    writer = writer_cls(
        input_dataset,
        output_path,
        stash_policy="ignore",
        stash_num_frames=3,
        **writer_kwargs,
    )
    output_dataset = writer.write()
    assert isinstance(output_dataset, output_cls)
    assert len(output_dataset.get_stash_frames()) == 0


@pytest.mark.parametrize("writer_name, writer_cls, output_cls, writer_kwargs", WRITER_CASES)
def test_stash_policy_copy(tmp_path, writer_name, writer_cls, output_cls, writer_kwargs):
    input_path = tmp_path / f"input_{writer_name}_copy"
    create_legacy_dataset(input_path)
    input_dataset = LegacyDataset(input_path)
    input_dataset.generate_stash_frames(num_frames=2, overwrite_existing=True)

    input_frames = [fn for fn, _ in input_dataset.get_stash_frames()]
    assert input_frames

    output_path = tmp_path / f"output_{writer_name}_copy"
    writer = writer_cls(
        input_dataset,
        output_path,
        stash_policy="copy",
        stash_num_frames=3,
        **writer_kwargs,
    )
    output_dataset = writer.write()
    assert isinstance(output_dataset, output_cls)

    output_frames = [fn for fn, _ in output_dataset.get_stash_frames()]
    assert sorted(output_frames) == sorted(input_frames)


@pytest.mark.parametrize("writer_name, writer_cls, output_cls, writer_kwargs", WRITER_CASES)
def test_stash_policy_generate(tmp_path, writer_name, writer_cls, output_cls, writer_kwargs):
    input_path = tmp_path / f"input_{writer_name}_generate"
    create_legacy_dataset(input_path)
    input_dataset = LegacyDataset(input_path)

    output_path = tmp_path / f"output_{writer_name}_generate"
    writer = writer_cls(
        input_dataset,
        output_path,
        stash_policy="generate",
        stash_num_frames=3,
        **writer_kwargs,
    )
    output_dataset = writer.write()
    assert isinstance(output_dataset, output_cls)

    expected_frames = select_expected_frames(0, 4, 3)
    output_frames = [fn for fn, _ in output_dataset.get_stash_frames()]
    assert sorted(output_frames) == expected_frames
