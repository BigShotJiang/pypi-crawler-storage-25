"""
Tests for S3 dataset downloader functionality.

These tests use mocking to avoid requiring actual S3 access.
"""

from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from mvdata.cloud_storage import CloudStorageProviderType, CloudStorageUrl

try:
    from mvdata.downloader import (
        RangedDatasetDownloader,
        LegacyDatasetDownloader,
        infer_and_download_dataset,
    )

    HAS_DOWNLOADER_DEPS = True
except ImportError:
    HAS_DOWNLOADER_DEPS = False

requires_downloader_deps = pytest.mark.skipif(
    not HAS_DOWNLOADER_DEPS, reason="Downloader dependencies not available"
)


class TestCloudStorageUrl:
    """Test CloudStorageUrl class."""

    def test_s3_url_parsing(self):
        """Test parsing S3 URLs."""
        url = CloudStorageUrl("s3://my-bucket/path/to/data")
        assert url.schema == "s3"
        assert url.bucket == "my-bucket"
        assert url.path == "path/to/data/"
        assert url.cloud == CloudStorageProviderType.AWS_S3

    def test_gs_url_parsing(self):
        """Test parsing GCS URLs."""
        url = CloudStorageUrl("gs://gcs-bucket/some/path")
        assert url.schema == "gs"
        assert url.bucket == "gcs-bucket"
        assert url.path == "some/path/"
        assert url.cloud == CloudStorageProviderType.GOOGLE_STORAGE

    def test_root_path(self):
        """Test URL with no path (bucket only)."""
        url = CloudStorageUrl("s3://bucket-only")
        assert url.schema == "s3"
        assert url.bucket == "bucket-only"
        assert url.path == ""
        assert url.cloud == CloudStorageProviderType.AWS_S3

    def test_root_path_with_slash(self):
        """Test URL with trailing slash."""
        url = CloudStorageUrl("gs://bucket/")
        assert url.schema == "gs"
        assert url.bucket == "bucket"
        assert url.path == ""
        assert url.cloud == CloudStorageProviderType.GOOGLE_STORAGE

    def test_invalid_scheme(self):
        """Test URL with invalid scheme raises ValueError."""
        with pytest.raises(ValueError, match="Invalid cloud URI scheme"):
            CloudStorageUrl("http://bucket/path")

        with pytest.raises(ValueError, match="Invalid cloud URI scheme"):
            CloudStorageUrl("https://bucket/path")

        with pytest.raises(ValueError, match="Invalid cloud URI scheme"):
            CloudStorageUrl("ftp://bucket/path")

    def test_missing_bucket(self):
        """Test URL without bucket raises ValueError."""
        with pytest.raises(ValueError, match="missing bucket name"):
            CloudStorageUrl("s3:///path/to/data")

    def test_cloud_provider_enum(self):
        """Test CloudStorageProviderType enum values."""
        assert CloudStorageProviderType.AWS_S3.value == "s3"
        assert CloudStorageProviderType.GOOGLE_STORAGE.value == "gs"

    def test_from_parts_s3(self):
        """Test creating CloudStorageUrl from parts for S3."""
        url = CloudStorageUrl.from_parts("s3", "my-bucket", "path/to/data")
        assert url.schema == "s3"
        assert url.bucket == "my-bucket"
        assert url.path == "path/to/data/"
        assert url.cloud == CloudStorageProviderType.AWS_S3

    def test_from_parts_gs(self):
        """Test creating CloudStorageUrl from parts for GCS."""
        url = CloudStorageUrl.from_parts("gs", "gcs-bucket", "some/path")
        assert url.schema == "gs"
        assert url.bucket == "gcs-bucket"
        assert url.path == "some/path/"
        assert url.cloud == CloudStorageProviderType.GOOGLE_STORAGE

    def test_from_parts_empty_path(self):
        """Test creating CloudStorageUrl from parts with empty path."""
        url = CloudStorageUrl.from_parts("s3", "bucket-only")
        assert url.schema == "s3"
        assert url.bucket == "bucket-only"
        assert url.path == ""
        assert url.cloud == CloudStorageProviderType.AWS_S3


@requires_downloader_deps
class TestRangedDatasetDownloader:
    """Test RangedDatasetDownloader."""

    def test_parse_range_folder(self):
        """Test parsing range folder names."""
        downloader = RangedDatasetDownloader("s3://bucket/dataset")

        assert downloader._parse_range_folder("00000000_00000499") == (0, 499)
        assert downloader._parse_range_folder("00000500_00000999") == (500, 999)
        assert downloader._parse_range_folder("frame00000_frame00099") == (0, 99)

        assert downloader._parse_range_folder("00000000") is None
        assert downloader._parse_range_folder("stash") is None
        assert downloader._parse_range_folder("00000000_00000499_extra") is None

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_infer_ranged_dataset(self, mock_list_objects):
        """Test inferring ranged dataset structure."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000_00000499/",
                "dataset/00000500_00000999/",
                "dataset/stash/",
                "dataset/meta/",
            ],
        )

        downloader = RangedDatasetDownloader("s3://bucket/dataset")
        assert downloader.infer_dataset_type() is True

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_infer_not_ranged_dataset(self, mock_list_objects):
        """Test inferring non-ranged dataset structure."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000/",
                "dataset/00000001/",
                "dataset/stash/",
            ],
        )

        downloader = RangedDatasetDownloader("s3://bucket/dataset")
        assert downloader.infer_dataset_type() is False

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_discover_ranges(self, mock_list_objects):
        """Test discovering range directories."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000_00000499/",
                "dataset/00000500_00000999/",
                "dataset/00001000_00001499/",
                "dataset/stash/",
                "dataset/meta/",
            ],
        )

        downloader = RangedDatasetDownloader("s3://bucket/dataset")
        ranges = downloader._discover_ranges()

        assert len(ranges) == 3
        assert ranges[0] == (0, 499, "00000000_00000499")
        assert ranges[1] == (500, 999, "00000500_00000999")
        assert ranges[2] == (1000, 1499, "00001000_00001499")

    @patch("mvdata.downloader.RangedDatasetDownloader._download_files")
    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_download_filters_mp4_streams(
        self, mock_list_objects, mock_download_files, tmp_path
    ):
        """Ranged MP4 stream files should honor the stream_ids filter."""

        def list_objects_side_effect(url, delimiter=None):
            if delimiter == "/":
                return ([], ["dataset/00000000_00000119/"])
            return (
                [
                    "dataset/00000000_00000119/rgb/001.mp4",
                    "dataset/00000000_00000119/rgb/002.mp4",
                    "dataset/00000000_00000119/rgb/003.mp4",
                    "dataset/00000000_00000119/notes.json",
                ],
                [],
            )

        mock_list_objects.side_effect = list_objects_side_effect
        downloader = RangedDatasetDownloader("s3://bucket/dataset")

        downloader.download(
            tmp_path,
            start_frame=0,
            end_frame=119,
            stream_ids=[2],
            include_stash=False,
            include_meta=False,
            include_mvx=False,
        )

        files_to_download = mock_download_files.call_args.args[0]
        keys = [key for key, _ in files_to_download]
        assert keys == [
            "dataset/00000000_00000119/rgb/002.mp4",
            "dataset/00000000_00000119/notes.json",
        ]


@requires_downloader_deps
class TestLegacyDatasetDownloader:
    """Test LegacyDatasetDownloader."""

    def test_extract_first_digit_sequence(self):
        """Test extracting digit sequences from folder names."""
        downloader = LegacyDatasetDownloader("s3://bucket/dataset")

        assert downloader._extract_first_digit_sequence("00000000") == 0
        assert downloader._extract_first_digit_sequence("00000042") == 42
        assert downloader._extract_first_digit_sequence("frame123") == 123
        assert downloader._extract_first_digit_sequence("stash") is None

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_infer_legacy_dataset(self, mock_list_objects):
        """Test inferring legacy dataset structure."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000/",
                "dataset/00000001/",
                "dataset/00000002/",
                "dataset/stash/",
            ],
        )

        downloader = LegacyDatasetDownloader("s3://bucket/dataset")
        assert downloader.infer_dataset_type() is True

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_infer_not_legacy_dataset(self, mock_list_objects):
        """Test inferring non-legacy dataset structure."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000_00000499/",
                "dataset/00000500_00000999/",
            ],
        )

        downloader = LegacyDatasetDownloader("s3://bucket/dataset")
        assert downloader.infer_dataset_type() is False

    @patch("mvdata.downloader.CloudStorageProvider.list_objects")
    def test_discover_frames(self, mock_list_objects):
        """Test discovering frame directories."""
        mock_list_objects.return_value = (
            [],
            [
                "dataset/00000000/",
                "dataset/00000001/",
                "dataset/00000002/",
                "dataset/stash/",
                "dataset/meta/",
            ],
        )

        downloader = LegacyDatasetDownloader("s3://bucket/dataset")
        frames = downloader._discover_frames()

        assert len(frames) == 3
        assert frames[0] == (0, "00000000")
        assert frames[1] == (1, "00000001")
        assert frames[2] == (2, "00000002")


@requires_downloader_deps
class TestInferAndDownload:
    """Test automatic dataset type inference."""

    @patch("mvdata.downloader.RangedDatasetDownloader.download")
    @patch("mvdata.downloader.RangedDatasetDownloader.infer_dataset_type")
    @patch("mvdata.downloader.LegacyDatasetDownloader.infer_dataset_type")
    def test_infer_ranged(self, mock_legacy_infer, mock_ranged_infer, mock_download):
        """Test automatic inference of ranged dataset."""
        mock_ranged_infer.return_value = True
        mock_legacy_infer.return_value = False
        mock_download.return_value = Mock()

        infer_and_download_dataset("s3://bucket/dataset", Path("/tmp/dataset"))

        assert mock_ranged_infer.called
        assert mock_download.called

    @patch("mvdata.downloader.LegacyDatasetDownloader.download")
    @patch("mvdata.downloader.RangedDatasetDownloader.infer_dataset_type")
    @patch("mvdata.downloader.LegacyDatasetDownloader.infer_dataset_type")
    def test_infer_legacy(self, mock_legacy_infer, mock_ranged_infer, mock_download):
        """Test automatic inference of legacy dataset."""
        mock_ranged_infer.return_value = False
        mock_legacy_infer.return_value = True
        mock_download.return_value = Mock()

        infer_and_download_dataset("s3://bucket/dataset", Path("/tmp/dataset"))

        assert mock_legacy_infer.called
        assert mock_download.called

    @patch("mvdata.downloader.RangedDatasetDownloader.infer_dataset_type")
    @patch("mvdata.downloader.LegacyDatasetDownloader.infer_dataset_type")
    def test_infer_unknown(self, mock_legacy_infer, mock_ranged_infer):
        """Test failure when dataset type cannot be inferred."""
        mock_ranged_infer.return_value = False
        mock_legacy_infer.return_value = False

        with pytest.raises(ValueError, match="Could not infer dataset type"):
            infer_and_download_dataset("s3://bucket/dataset", Path("/tmp/dataset"))
