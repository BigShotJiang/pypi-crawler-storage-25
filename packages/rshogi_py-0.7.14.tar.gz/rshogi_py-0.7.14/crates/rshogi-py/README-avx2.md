# rshogi-py-avx2

Python bindings for the `rshogi` Rust crate.

This package provides an AVX2-optimized build of the same `rshogi` Python module.
If you want the standard build, use
[`rshogi-py`](https://pypi.org/project/rshogi-py/).

## Installation

```bash
python -m pip install rshogi-py-avx2
```

## Notes

- `rshogi-py` and `rshogi-py-avx2` are mutually exclusive; install only one.
- This build requires an AVX2-capable CPU on x86_64.
