use thiserror::Error;

/// 共通の棋譜エラー型。
#[derive(Debug, Error)]
pub enum RecordError {
    /// 初期局面 SFEN が空。
    #[error("initial position SFEN cannot be empty")]
    EmptyInitPosition,
}
