// パフォーマンス上の理由で、一部のホットパスに限定して `unsafe` を許可する。
// 使用箇所には SAFETY コメントを付与し、テストで妥当性を担保する。
#![allow(unsafe_code)]
#![allow(clippy::doc_markdown)]
#![allow(
    clippy::unreadable_literal,
    clippy::similar_names,
    clippy::if_not_else,
    clippy::map_unwrap_or,
    clippy::redundant_closure_for_method_calls,
    clippy::missing_const_for_fn,
    clippy::cast_possible_truncation,
    clippy::cast_sign_loss,
    clippy::cognitive_complexity,
    clippy::too_many_lines,
    clippy::redundant_pub_crate,
    clippy::match_same_arms,
    clippy::filter_map_next,
    clippy::bool_to_int_with_if,
    clippy::unnecessary_wraps,
    clippy::single_match_else,
    clippy::branches_sharing_code,
    clippy::cast_possible_wrap,
    clippy::use_self,
    clippy::unnecessary_to_owned,
    clippy::cast_precision_loss,
    clippy::float_cmp
)]
#![doc = include_str!("../README.md")]

pub mod board;
pub mod book;
pub mod labels;
pub mod mate;
pub(crate) mod simd;
pub mod types;
pub mod records;

// Re-export movegen types at crate root for easier access
pub use board::movegen;
