use std::fmt;

/// 定跡操作で発生するエラー。
#[derive(Debug)]
pub enum BookError {
    /// I/O エラー（ファイル読み書き時）。
    Io(std::io::Error),
    /// 定跡ファイルのフォーマットが不正。
    InvalidFormat(&'static str),
    /// 定跡データの内容が不正。
    InvalidData(String),
    /// 未サポートの機能。
    Unsupported(&'static str),
}

impl fmt::Display for BookError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Io(err) => write!(f, "io error: {err}"),
            Self::InvalidFormat(msg) => write!(f, "invalid book format: {msg}"),
            Self::InvalidData(msg) => write!(f, "invalid data: {msg}"),
            Self::Unsupported(msg) => write!(f, "unsupported feature: {msg}"),
        }
    }
}

impl std::error::Error for BookError {}

impl From<std::io::Error> for BookError {
    fn from(value: std::io::Error) -> Self {
        Self::Io(value)
    }
}
