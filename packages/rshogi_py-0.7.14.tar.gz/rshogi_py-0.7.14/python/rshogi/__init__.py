"""rshogi: Python bindings for shogi library.

This package provides structured imports through submodules:

Core primitives:
    >>> from rshogi.core import Board, Move32, Move

Core primitives:
    >>> from rshogi.core import Board, Move32, Move

Types and Constants:
    >>> from rshogi.types import Color, PieceType, Piece, Square

Initial Positions:
    >>> from rshogi.initial_positions import InitialPosition

Records:
    >>> from rshogi.record import GameRecord, GameRecordMetadata, GameResult

Record conversion:
    >>> record = GameRecord.from_kif_str(kif_text)
    >>> kif_text = record.to_kif()

Record file I/O:
    >>> record = GameRecord.from_kif_file("example.kif")
    >>> record.write_kif("example_out.kif")

Book (Opening Book):
    >>> from rshogi.book import StaticBook, MemoryBook, BookBuilder
    >>> from rshogi.book import book_key_from_position, book_key_after

Policy labels:
    >>> from rshogi.policy import move_label, compact_move_label

NumPy:
    >>> from rshogi.numpy import PackedSfen, PackedSfenValue
"""

# Import all submodules
from . import book, core, initial_positions, numpy, policy, record, svg, types

# Version
__version__ = "0.7.14"

__all__ = [
    # Submodules
    "types",
    "core",
    "record",
    "book",
    "policy",
    "numpy",
    "svg",
    "initial_positions",
]
