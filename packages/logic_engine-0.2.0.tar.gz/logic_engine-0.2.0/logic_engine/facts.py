"""Core data types for facts and queries."""
from dataclasses import dataclass
from typing import FrozenSet


@dataclass(frozen=True, order=True)
class Fact:
    """A directed relationship: source > target."""
    source: str
    target: str

    def __str__(self) -> str:
        return f"{self.source} > {self.target}"

    @classmethod
    def parse(cls, text: str) -> "Fact":
        if ">" not in text:
            raise ValueError(f"Invalid fact format (missing '>'): {text!r}")
        parts = text.split(">")
        if len(parts) != 2:
            raise ValueError(f"Invalid fact format (expected exactly one '>'): {text!r}")
        left, right = parts[0].strip(), parts[1].strip()
        if not left or not right:
            raise ValueError(f"Fact contains empty node name: {text!r}")
        return cls(left, right)


@dataclass(frozen=True, order=True)
class Query:
    """A reachability question: can source reach target?"""
    source: str
    target: str

    def __str__(self) -> str:
        return f"{self.source} > {self.target}"

    @classmethod
    def parse(cls, text: str) -> "Query":
        if ">" not in text:
            raise ValueError(f"Invalid query format (missing '>'): {text!r}")
        parts = text.split(">")
        if len(parts) != 2:
            raise ValueError(f"Invalid query format (expected exactly one '>'): {text!r}")
        left, right = parts[0].strip(), parts[1].strip()
        if not left or not right:
            raise ValueError(f"Query contains empty node name: {text!r}")
        return cls(left, right)


def parse_facts(items) -> FrozenSet[Fact]:
    """Parse a list of strings (or Facts) into a frozen set of Facts."""
    out = set()
    for item in items:
        if isinstance(item, Fact):
            out.add(item)
        else:
            out.add(Fact.parse(item))
    return frozenset(out)