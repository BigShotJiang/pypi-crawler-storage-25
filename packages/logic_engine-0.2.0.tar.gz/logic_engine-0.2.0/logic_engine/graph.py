"""Graph operations: reachability and entailment closure."""
from typing import Dict, FrozenSet, Set, Tuple, Iterable
from .facts import Fact

Entailment = Tuple[str, str]
EntailmentSet = FrozenSet[Entailment]


def build_adjacency(facts: Iterable[Fact]) -> Dict[str, Set[str]]:
    adj: Dict[str, Set[str]] = {}
    for f in facts:
        adj.setdefault(f.source, set()).add(f.target)
        adj.setdefault(f.target, set())
    return adj


def reachable_from(adj: Dict[str, Set[str]], start: str) -> Set[str]:
    visited: Set[str] = set()
    stack = [start]
    while stack:
        curr = stack.pop()
        for n in adj.get(curr, ()):
            if n not in visited:
                visited.add(n)
                stack.append(n)
    return visited


def is_reachable(facts: FrozenSet[Fact], source: str, target: str) -> bool:
    if source == target:
        return True
    adj = build_adjacency(facts)
    return target in reachable_from(adj, source)


def find_path(facts: FrozenSet[Fact], source: str, target: str):
    if source == target:
        return [source]
    adj = build_adjacency(facts)
    parent = {source: None}
    stack = [source]
    while stack:
        curr = stack.pop()
        if curr == target:
            path = []
            while curr is not None:
                path.append(curr)
                curr = parent[curr]
            return list(reversed(path))
        for n in adj.get(curr, ()):
            if n not in parent:
                parent[n] = curr
                stack.append(n)
    return None


def compute_closure(facts: FrozenSet[Fact], universe: Set[str] = None) -> EntailmentSet:
    """Every (source, target) pair where source can reach target.

    If `universe` is given, reflexive entailments are computed over those nodes
    rather than only nodes appearing in `facts`. Keeps the closure stable when
    comparing before/after fact-set edits.
    """
    adj = build_adjacency(facts)
    nodes = set(adj.keys())
    if universe is not None:
        nodes |= universe
    entailments: Set[Entailment] = set()
    for start in nodes:
        entailments.add((start, start))
        for reached in reachable_from(adj, start):
            entailments.add((start, reached))
    return frozenset(entailments)


def edges_on_paths(facts: FrozenSet[Fact], source: str, target: str) -> FrozenSet[Fact]:
    adj = build_adjacency(facts)
    radj: Dict[str, Set[str]] = {}
    for f in facts:
        radj.setdefault(f.target, set()).add(f.source)
        radj.setdefault(f.source, set())
    fwd = reachable_from(adj, source) | {source}
    bwd = reachable_from(radj, target) | {target}
    on_path = fwd & bwd
    return frozenset(f for f in facts if f.source in on_path and f.target in on_path)
