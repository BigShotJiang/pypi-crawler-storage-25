"""Minimum belief revision: smallest edits to flip a query's truth value."""
from dataclasses import dataclass
from itertools import combinations
from typing import FrozenSet, List, Optional, Set

from .facts import Fact, Query
from .graph import compute_closure, edges_on_paths


@dataclass(frozen=True)
class Revision:
    edits_removed: FrozenSet[Fact]
    edits_added: FrozenSet[Fact]
    entailments_lost: FrozenSet
    entailments_gained: FrozenSet
    target_query: Query
    target_truth: bool

    @property
    def cost(self) -> int:
        return len(self.edits_removed) + len(self.edits_added)

    @property
    def collateral(self) -> int:
        total_changed = len(self.entailments_lost) + len(self.entailments_gained)
        return max(0, total_changed - 1)

    def _sort_key(self):
        return (self.cost, self.collateral)

    def __lt__(self, other: "Revision") -> bool:
        return self._sort_key() < other._sort_key()


def _universe(facts: FrozenSet[Fact], query: Query) -> Set[str]:
    nodes = {f.source for f in facts} | {f.target for f in facts}
    nodes |= {query.source, query.target}
    return nodes


def revise_to_falsify(
    facts: FrozenSet[Fact],
    query: Query,
    max_edits: int = 4,
) -> List[Revision]:
    universe = _universe(facts, query)
    original = compute_closure(facts, universe=universe)
    target = (query.source, query.target)
    if target not in original:
        return []

    relevant = list(edges_on_paths(facts, query.source, query.target))
    revisions: List[Revision] = []
    found_at_size: Optional[int] = None

    for size in range(1, max_edits + 1):
        if found_at_size is not None and size > found_at_size + 1:
            break
        for edit_set in combinations(relevant, size):
            removed = frozenset(edit_set)
            new_closure = compute_closure(facts - removed, universe=universe)
            if target not in new_closure:
                lost = original - new_closure
                revisions.append(Revision(
                    edits_removed=removed,
                    edits_added=frozenset(),
                    entailments_lost=lost,
                    entailments_gained=frozenset(),
                    target_query=query,
                    target_truth=False,
                ))
                if found_at_size is None:
                    found_at_size = size

    return _pareto_filter(sorted(revisions))


def revise_to_satisfy(
    facts: FrozenSet[Fact],
    query: Query,
    candidate_nodes: Optional[Set[str]] = None,
    max_edits: int = 3,
) -> List[Revision]:
    universe = _universe(facts, query)
    original = compute_closure(facts, universe=universe)
    target = (query.source, query.target)
    if target in original:
        return []

    if candidate_nodes is None:
        candidate_nodes = set(universe)

    existing = set(facts)
    candidates = [
        Fact(s, t)
        for s in candidate_nodes
        for t in candidate_nodes
        if s != t and Fact(s, t) not in existing
    ]

    revisions: List[Revision] = []
    found_at_size: Optional[int] = None

    for size in range(1, max_edits + 1):
        if found_at_size is not None and size > found_at_size + 1:
            break
        for edit_set in combinations(candidates, size):
            added = frozenset(edit_set)
            new_closure = compute_closure(facts | added, universe=universe)
            if target in new_closure:
                gained = new_closure - original
                revisions.append(Revision(
                    edits_removed=frozenset(),
                    edits_added=added,
                    entailments_lost=frozenset(),
                    entailments_gained=gained,
                    target_query=query,
                    target_truth=True,
                ))
                if found_at_size is None:
                    found_at_size = size

    return _pareto_filter(sorted(revisions))


def _pareto_filter(revisions: List[Revision]) -> List[Revision]:
    keep: List[Revision] = []
    for r in revisions:
        dominated = False
        for other in revisions:
            if other is r:
                continue
            if (other.cost <= r.cost and other.collateral <= r.collateral
                    and (other.cost, other.collateral) != (r.cost, r.collateral)):
                dominated = True
                break
        if not dominated:
            keep.append(r)
    return keep
