"""
Logic Engine — reachability with belief revision.

Public API:
    parse_facts, Fact, Query
    is_reachable, find_path, compute_closure
    revise_to_falsify, revise_to_satisfy, Revision
    explain_revision, explain_all
"""
from .facts import Fact, Query, parse_facts
from .graph import is_reachable, find_path, compute_closure
from .revision import revise_to_falsify, revise_to_satisfy, Revision
from .explain import explain_revision, explain_all

__version__ = "0.2.0"

__all__ = [
    "__version__",
    "Fact", "Query", "parse_facts",
    "is_reachable", "find_path", "compute_closure",
    "revise_to_falsify", "revise_to_satisfy", "Revision",
    "explain_revision", "explain_all",
]
