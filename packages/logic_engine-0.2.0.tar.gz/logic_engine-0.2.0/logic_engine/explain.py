"""Human-readable explanations of revisions."""
from typing import List
from .revision import Revision
from .facts import Query


def explain_revision(revision: Revision, max_collateral_shown: int = 10) -> str:
    q = revision.target_query
    verb = "satisfy" if revision.target_truth else "falsify"
    lines = [f"To {verb} '{q}', the proposed edit (cost={revision.cost}):"]

    if revision.edits_removed:
        lines.append("")
        lines.append("  Remove:")
        for f in sorted(revision.edits_removed, key=str):
            lines.append(f"    − {f}")

    if revision.edits_added:
        lines.append("")
        lines.append("  Add:")
        for f in sorted(revision.edits_added, key=str):
            lines.append(f"    + {f}")

    target_pair = (q.source, q.target)
    if revision.target_truth:
        side_effects = sorted(revision.entailments_gained - {target_pair})
        label = "New entailments introduced"
    else:
        side_effects = sorted(revision.entailments_lost - {target_pair})
        label = "Other entailments lost"

    lines.append("")
    lines.append(f"  Collateral: {len(side_effects)}")
    if side_effects:
        lines.append(f"  {label}:")
        for s, t in side_effects[:max_collateral_shown]:
            lines.append(f"    · {s} > {t}")
        if len(side_effects) > max_collateral_shown:
            lines.append(f"    · ... and {len(side_effects) - max_collateral_shown} more")
    return "\n".join(lines)


def explain_all(revisions: List[Revision]) -> str:
    if not revisions:
        return "No revision needed — query already has the desired truth value."
    blocks = []
    for i, r in enumerate(revisions, 1):
        header = f"=== Option {i} (cost={r.cost}, collateral={r.collateral}) ==="
        blocks.append(header + "\n" + explain_revision(r))
    return "\n\n".join(blocks)