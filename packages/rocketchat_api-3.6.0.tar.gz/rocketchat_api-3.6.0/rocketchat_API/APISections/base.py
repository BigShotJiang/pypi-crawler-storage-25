import itertools
import re
from functools import wraps
from json import JSONDecodeError
from typing import Any, Callable, Generator

import requests

from rocketchat_API.APIExceptions.RocketExceptions import (
    RocketAuthenticationException,
    RocketConnectionException,
    RocketBadStatusCodeException,
    RocketApiException,
)


def _paginated_generator(
    self,
    func: Callable[..., dict[str, Any]],
    data_key: str,
    first_data: dict[str, Any],
    offset: int,
    count: int,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> Generator[dict[str, Any], None, None]:
    """Inner generator that yields items from paginated API responses."""
    data = first_data
    while True:
        items = data.get(data_key, [])
        if not items:
            break

        yield from items

        # If we got fewer items than requested, we've reached the end
        if len(items) < count:
            break

        offset += count
        # Call the original function with pagination parameters
        data = func(self, *args, offset=offset, count=count, **kwargs)


def paginated(
    data_key: str,
) -> Callable[
    [Callable[..., dict[str, Any]]],
    Callable[..., Generator[dict[str, Any], None, None]],
]:
    """
    Decorator that converts a paginated API method into an iterator.

    Args:
        data_key: The key in the API response that contains the list of items
                  (e.g., 'groups', 'channels', 'users')

    Returns:
        A decorator that wraps the original method to yield items one by one,
        automatically handling pagination with offset and count parameters.

    Kwargs (handled by the wrapper):
        offset: Starting offset for pagination (default: 0)
        count: Number of items per page (default: 50)
        max_count: Maximum total number of items to return (default: None, returns all)

    Example:
        @paginated('groups')
        def groups_list_all(self, **kwargs):
            return self.call_api_get("groups.listAll", kwargs=kwargs)

        # Get all groups
        list(rocket.groups_list_all())

        # Get at most 100 groups
        list(rocket.groups_list_all(max_count=100))
    """

    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            offset = kwargs.pop("offset", 0)
            count = kwargs.pop("count", 50)
            max_count = kwargs.pop("max_count", None)

            # Call the original function eagerly to propagate any exceptions
            first_data = func(self, *args, offset=offset, count=count, **kwargs)

            items_gen = _paginated_generator(
                self, func, data_key, first_data, offset, count, args, kwargs
            )

            if max_count is not None:
                return itertools.islice(items_gen, max_count)

            return items_gen

        return wrapper

    return decorator


def json_or_error(r: requests.Response) -> Any:
    if r.status_code > 399 or r.status_code < 200:
        try:
            response_json = r.json()
            if (
                isinstance(response_json, dict)
                and response_json.get("success") is False
            ):
                raise RocketApiException(r.status_code, r.text, response_json)
        except JSONDecodeError:
            pass
        raise RocketBadStatusCodeException(r.status_code, r.text)

    try:
        result = r.json()
    except JSONDecodeError:
        return r.text

    return result


class RocketChatBase:
    api_path = "/api/v1/"

    def __init__(
        self,
        user=None,
        password=None,
        auth_token=None,
        user_id=None,
        server_url="http://127.0.0.1:3000",
        ssl_verify=True,
        proxies=None,
        timeout=30,
        session=None,
        client_certs=None,
    ):
        """Creates a RocketChat object and does login on the specified server"""
        self.headers = {}
        self.server_url = server_url
        self.proxies = proxies
        self.ssl_verify = ssl_verify
        self.cert = client_certs
        self.timeout = timeout
        self.session = session or requests.Session()
        if user and password:
            self.login(user, password)  # skipcq: PTC-W1006
        if auth_token and user_id:
            self.headers["X-Auth-Token"] = auth_token
            self.headers["X-User-Id"] = user_id

    @staticmethod
    def __reduce_kwargs(kwargs):
        if "kwargs" in kwargs:
            for arg in kwargs["kwargs"].keys():
                kwargs[arg] = kwargs["kwargs"][arg]

            del kwargs["kwargs"]
        return kwargs

    def call_api_delete(self, method):
        url = self.server_url + self.api_path + method

        return json_or_error(
            self.session.delete(
                url,
                headers=self.headers,
                verify=self.ssl_verify,
                cert=self.cert,
                proxies=self.proxies,
                timeout=self.timeout,
            )
        )

    def call_api_get(self, method, api_path=None, **kwargs):
        args = self.__reduce_kwargs(kwargs)
        if not api_path:
            api_path = self.api_path
        url = self.server_url + api_path + method
        # convert to key[]=val1&key[]=val2 for args like key=[val1, val2], else key=val
        params = "&".join(
            (
                "&".join(i + "[]=" + j for j in args[i])
                if isinstance(args[i], list)
                else i + "=" + str(args[i])
            )
            for i in args
        )

        return json_or_error(
            self.session.get(
                "%s?%s" % (url, params),
                headers=self.headers,
                verify=self.ssl_verify,
                cert=self.cert,
                proxies=self.proxies,
                timeout=self.timeout,
            )
        )

    def call_api_post(self, method, body=None, files=None, use_json=None, **kwargs):
        """Send a POST request to the API.

        There are two modes of operation:

        1. **Raw body** — pass ``body`` directly. The value is serialized as-is
           via ``json=body``, which supports any JSON-serializable structure
           (lists, dicts, etc.). ``kwargs`` are ignored in this mode.

        2. **Keyword arguments** (default) — individual kwargs are collected
           into a dict and sent as the request payload.  By default the payload
           is sent as JSON (``json=``), but when ``files`` are provided it
           falls back to form-encoded ``data=`` because requests ignores the
           ``json`` parameter when ``files`` is set.  You can override this
           with ``use_json=True/False``.

        :param method:   API method path, appended to ``self.api_path``.
        :param body:     A raw JSON-serializable payload (e.g. a list).
                         When provided, ``kwargs``, ``files``, and ``use_json``
                         are ignored.
        :param files:    Files to upload (passed to ``requests``).
        :param use_json: Force JSON (True) or form-encoded (False) encoding.
                         Defaults to JSON when no files are attached.
        """
        url = self.server_url + self.api_path + method

        if body is not None:
            return json_or_error(
                self.session.post(
                    url,
                    json=body,
                    headers=self.headers,
                    verify=self.ssl_verify,
                    cert=self.cert,
                    proxies=self.proxies,
                    timeout=self.timeout,
                )
            )

        reduced_args = self.__reduce_kwargs(kwargs)

        # "pass" is a Python reserved word, but some endpoints (e.g.
        # users.register) expect it instead of "password".
        if "password" in reduced_args and method != "users.create":
            reduced_args["pass"] = reduced_args.pop("password")

        if use_json is None:
            use_json = files is None

        return json_or_error(
            self.session.post(
                url,
                json=reduced_args if use_json else None,
                data=None if use_json else reduced_args,
                files=files,
                headers=self.headers,
                verify=self.ssl_verify,
                cert=self.cert,
                proxies=self.proxies,
                timeout=self.timeout,
            )
        )

    def call_api_put(self, method, files=None, use_json=None, **kwargs):
        reduced_args = self.__reduce_kwargs(kwargs)
        if use_json is None:
            # see https://requests.readthedocs.io/en/master/user/quickstart/#more-complicated-post-requests
            # > The json parameter is ignored if either data or files is passed.
            # If files are sent, json should not be used
            use_json = files is None
        if use_json:
            return json_or_error(
                self.session.put(
                    self.server_url + self.api_path + method,
                    json=reduced_args,
                    files=files,
                    headers=self.headers,
                    verify=self.ssl_verify,
                    cert=self.cert,
                    proxies=self.proxies,
                    timeout=self.timeout,
                )
            )

        return json_or_error(
            self.session.put(
                self.server_url + self.api_path + method,
                data=reduced_args,
                files=files,
                headers=self.headers,
                verify=self.ssl_verify,
                cert=self.cert,
                proxies=self.proxies,
                timeout=self.timeout,
            )
        )

    # Authentication

    def login(self, user, password):
        request_data = {"password": password}
        if re.match(
            r"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$",
            user,
        ):
            request_data["user"] = user
        else:
            request_data["username"] = user
        login_request = self.session.post(
            self.server_url + self.api_path + "login",
            json=request_data,
            verify=self.ssl_verify,
            proxies=self.proxies,
            cert=self.cert,
            timeout=self.timeout,
        )
        if login_request.status_code == 401:
            raise RocketAuthenticationException()

        if (
            login_request.status_code == 200
            and login_request.json().get("status") == "success"
        ):
            self.headers["X-Auth-Token"] = (
                login_request.json().get("data").get("authToken")
            )
            self.headers["X-User-Id"] = login_request.json().get("data").get("userId")
            return login_request.json()

        raise RocketConnectionException()

    def logout(self, **kwargs):
        """Invalidate your REST rocketchat_API authentication token."""
        return self.call_api_post("logout", kwargs=kwargs)

    def info(self, **kwargs):
        """Information about the Rocket.Chat server."""
        return self.call_api_get("info", api_path="/api/", kwargs=kwargs)
