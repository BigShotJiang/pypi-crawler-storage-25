"""
Y*Defuse setup configuration
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

setup(
    name="ystar-defuse",
    version="0.1.0",
    author="Y* Bridge Labs",
    author_email="team@ystar.ai",
    description="AI Bomb Disposal - 100% guaranteed protection against delayed injection attacks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/liuhaotian2024-prog/ystar-defuse",
    project_urls={
        "Bug Tracker": "https://github.com/liuhaotian2024-prog/ystar-defuse/issues",
        "Documentation": "https://ystar-defuse.dev",
        "Source Code": "https://github.com/liuhaotian2024-prog/ystar-defuse",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries :: Python Modules",

        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        # No external dependencies - only stdlib
    ],

    entry_points={
        "console_scripts": [
            "ystar-defuse=ystar_defuse.cli:main",
        ],
    },
    keywords="ai security prompt-injection agent governance runtime-protection",
    # license defined in pyproject.toml
)
