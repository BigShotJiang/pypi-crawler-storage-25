"""
Tests for CIEU Logger
"""
import pytest
from datetime import datetime

from ystar_defuse.core.cieu_logger import CIEULogger
from ystar_defuse.db import get_event_stats


class TestCIEULogging:
    """Test CIEU event logging"""

    def test_log_blocked_event(self, logger):
        event_id = logger.log_blocked(
            action_type="read_file",
            target=".env",
            rule_id="L1_SENSITIVE_FILE",
            details={"tool_name": "Read"}
        )

        assert event_id
        assert len(event_id) == 24  # SHA256 truncated to 24 chars

        # Verify event was recorded
        events = logger.get_recent_events(limit=1)
        assert len(events) == 1
        assert events[0]['event_type'] == 'blocked'
        assert events[0]['action_type'] == 'read_file'
        assert events[0]['target'] == '.env'

    def test_log_allowed_event(self, logger):
        event_id = logger.log_allowed(
            action_type="read_file",
            target="README.md",
            details={"tool_name": "Read"}
        )

        assert event_id

        events = logger.get_recent_events(limit=1)
        assert len(events) == 1
        assert events[0]['event_type'] == 'allowed'

    def test_log_alert_event(self, logger):
        event_id = logger.log_alert(
            action_type="network",
            target="suspicious.com",
            rule_id="L2_NEW_BEHAVIOR",
            details={"reason": "First time seeing this domain"}
        )

        assert event_id

        events = logger.get_recent_events(limit=1)
        assert len(events) == 1
        assert events[0]['event_type'] == 'alert'

    def test_log_hook_failure(self, logger):
        error = ValueError("Test error")
        event_id = logger.log_hook_failure(error, tool_name="Bash")

        assert event_id

        events = logger.get_recent_events(limit=1, event_type='hook_failure')
        assert len(events) == 1
        assert events[0]['event_type'] == 'hook_failure'

    def test_log_hook_timeout(self, logger):
        event_id = logger.log_hook_timeout(elapsed_ms=150, tool_name="Read")

        assert event_id

        events = logger.get_recent_events(limit=1, event_type='hook_timeout')
        assert len(events) == 1
        assert events[0]['event_type'] == 'hook_timeout'


class TestSessionSequencing:
    """Test session sequencing and uniqueness"""

    def test_session_seq_increments(self, logger):
        logger.log_allowed("read_file", "file1.txt")
        logger.log_allowed("read_file", "file2.txt")
        logger.log_allowed("read_file", "file3.txt")

        events = logger.get_recent_events(limit=3)
        assert events[0]['session_seq'] == 3
        assert events[1]['session_seq'] == 2
        assert events[2]['session_seq'] == 1

    def test_session_id_consistent(self, logger):
        logger.log_allowed("read_file", "file1.txt")
        logger.log_allowed("read_file", "file2.txt")

        events = logger.get_recent_events(limit=2)
        assert events[0]['session_id'] == events[1]['session_id']

    def test_event_id_unique(self, logger):
        event_id_1 = logger.log_allowed("read_file", "file1.txt")
        event_id_2 = logger.log_allowed("read_file", "file2.txt")

        assert event_id_1 != event_id_2


class TestTimeWindowQueries:
    """Test time window event queries"""

    def test_get_events_in_window(self, logger):
        # Log 3 events
        logger.log_allowed("read_file", "file1.txt")
        logger.log_allowed("read_file", "file2.txt")
        logger.log_allowed("read_file", "file3.txt")

        # Get events within 60 second window from seq 1
        events = logger.get_events_in_window(start_seq=1, window_seconds=60.0)

        # Should get all 3 events (they were logged within milliseconds)
        assert len(events) >= 1

    def test_empty_window(self, logger):
        logger.log_allowed("read_file", "file1.txt")

        # Query for non-existent sequence
        events = logger.get_events_in_window(start_seq=999, window_seconds=60.0)
        assert len(events) == 0


class TestEventStats:
    """Test event statistics"""

    def test_event_stats(self, logger):
        logger.log_blocked("read_file", ".env", "L1_SENSITIVE_FILE")
        logger.log_blocked("execute", "rm -rf /", "L1_DANGEROUS_CMD")
        logger.log_allowed("read_file", "README.md")
        logger.log_allowed("read_file", "main.py")
        logger.log_alert("network", "new-domain.com", "L2_NEW_BEHAVIOR")

        stats = logger.get_stats()

        assert stats['blocked'] == 2
        assert stats['allowed'] == 2
        assert stats['alert'] == 1


class TestCIEUFormatCompatibility:
    """Test Y*gov CIEU format compatibility"""

    def test_required_fields_present(self, logger):
        logger.log_blocked("read_file", ".env", "L1_SENSITIVE_FILE")

        events = logger.get_recent_events(limit=1)
        event = events[0]

        # Check all required fields for Y*gov compatibility
        required_fields = [
            'event_id',
            'session_id',
            'session_seq',
            'timestamp',
            'event_type',
            'action_type',
        ]

        for field in required_fields:
            assert field in event
            assert event[field] is not None

    def test_timestamp_format(self, logger):
        logger.log_allowed("read_file", "test.txt")

        events = logger.get_recent_events(limit=1)
        timestamp = events[0]['timestamp']

        # Should be Unix timestamp (float)
        assert isinstance(timestamp, float)
        assert timestamp > 0

        # Should be recent (within last minute)
        now = datetime.now().timestamp()
        assert abs(now - timestamp) < 60
