"""
Test path normalization for whitelist rules
Ensures macOS symlink handling works correctly
"""
import pytest
import tempfile
from pathlib import Path

from ystar_defuse.core.cieu_logger import CIEULogger
from ystar_defuse.db import insert_whitelist_rule, set_learning_metadata
from ystar_defuse.hook import pre_tool_use


def test_macos_symlink_normalization():
    """
    Test that /var and /private/var paths are handled correctly
    This is critical for macOS where /var -> /private/var
    """
    import hashlib

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)

        # Get both the raw path and resolved path
        test_file = tmp_path / "test.txt"
        raw_path = str(test_file)
        resolved_path = str(test_file.resolve())

        # They might be different on macOS
        print(f"Raw: {raw_path}")
        print(f"Resolved: {resolved_path}")

        logger = CIEULogger()
        set_learning_metadata(logger.conn, "learning_mode", "enforce")

        # Generate unique rule_id
        rule_id = f"TEST_NORM_{hashlib.sha256(resolved_path.encode()).hexdigest()[:12]}"

        # Insert rule with resolved path (correct way)
        try:
            insert_whitelist_rule(
                logger.conn,
                rule_id=rule_id,
                rule_type="path_prefix",
                pattern=resolved_path,
                created_by="manual"
            )
        except Exception:
            pass  # Rule might exist from previous run

        logger.close()

        # Test should pass regardless of which path format is used
        result1 = pre_tool_use(
            tool_name="Read",
            tool_args={"file_path": raw_path}
        )
        result2 = pre_tool_use(
            tool_name="Read",
            tool_args={"file_path": resolved_path}
        )

        assert result1["allowed"], f"Raw path should be allowed: {raw_path}"
        assert result2["allowed"], f"Resolved path should be allowed: {resolved_path}"


def test_whitelist_rule_path_prefix_matching():
    """
    Test that path_prefix matching works correctly for directories
    """
    import hashlib

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir).resolve()

        logger = CIEULogger()
        set_learning_metadata(logger.conn, "learning_mode", "enforce")

        # Generate unique rule_id
        rule_id = f"TEST_DIR_{hashlib.sha256(str(tmp_path).encode()).hexdigest()[:12]}"

        # Add directory prefix
        try:
            insert_whitelist_rule(
                logger.conn,
                rule_id=rule_id,
                rule_type="path_prefix",
                pattern=str(tmp_path),
                created_by="manual"
            )
        except Exception:
            pass  # Rule might exist from previous run

        logger.close()

        # Files under this directory should be allowed
        file1 = tmp_path / "file1.txt"
        file2 = tmp_path / "subdir" / "file2.txt"

        result1 = pre_tool_use(
            tool_name="Read",
            tool_args={"file_path": str(file1)}
        )
        result2 = pre_tool_use(
            tool_name="Read",
            tool_args={"file_path": str(file2)}
        )

        assert result1["allowed"], f"File in whitelisted dir should be allowed: {file1}"
        assert result2["allowed"], f"File in whitelisted subdir should be allowed: {file2}"

        # File outside should be blocked
        outside = Path("/tmp/outside.txt")
        result3 = pre_tool_use(
            tool_name="Read",
            tool_args={"file_path": str(outside)}
        )

        assert not result3["allowed"], "File outside whitelist should be blocked"
