"""
CIEU Logger - Lightweight event recording
Compatible with Y*gov CIEU format for zero-migration upgrade path
"""
import hashlib
import os
import json
import sqlite3
from datetime import datetime
from typing import Optional, Dict, Any
from pathlib import Path

from ..db import (
    init_db,
    insert_cieu_event,
    get_recent_events,
    get_events_in_window,
    get_event_stats,
)


class CIEULogger:
    """
    Lightweight CIEU event logger
    Format compatible with Y*gov for seamless upgrade
    """

    def __init__(self, db_path: Optional[Path] = None):
        """
        Args:
            db_path: Path to SQLite database (default: ~/.ystar_defuse/defuse.db)
        """
        self.db_path = db_path
        self.conn = init_db(db_path)

        # Generate session ID (immutable for this process)
        self.session_id = self._generate_session_id()
        self.session_seq = 0

    def _generate_session_id(self) -> str:
        """Generate unique session ID: hash(timestamp + PID + random salt)"""
        timestamp = str(datetime.now().timestamp())
        pid = str(os.getpid())
        salt = os.urandom(16).hex()

        session_data = f"{timestamp}:{pid}:{salt}"
        return hashlib.sha256(session_data.encode()).hexdigest()[:16]

    def _generate_event_id(self, session_seq: int) -> str:
        """Generate non-repudiable event ID"""
        timestamp = str(datetime.now().timestamp())
        event_data = f"{self.session_id}:{session_seq}:{timestamp}"
        return hashlib.sha256(event_data.encode()).hexdigest()[:24]

    def _next_seq(self) -> int:
        """Get next sequence number"""
        self.session_seq += 1
        return self.session_seq

    def log_blocked(
        self,
        action_type: str,
        target: str,
        rule_id: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Log a blocked action

        Returns:
            event_id
        """
        seq = self._next_seq()
        event_id = self._generate_event_id(seq)

        details_json = json.dumps(details) if details else None

        insert_cieu_event(
            self.conn,
            event_id=event_id,
            session_id=self.session_id,
            session_seq=seq,
            event_type="blocked",
            action_type=action_type,
            target=target,
            rule_id=rule_id,
            details=details_json,
        )

        return event_id

    def log_allowed(
        self,
        action_type: str,
        target: str,
        rule_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Log an allowed action

        Returns:
            event_id
        """
        seq = self._next_seq()
        event_id = self._generate_event_id(seq)

        details_json = json.dumps(details) if details else None

        insert_cieu_event(
            self.conn,
            event_id=event_id,
            session_id=self.session_id,
            session_seq=seq,
            event_type="allowed",
            action_type=action_type,
            target=target,
            rule_id=rule_id,
            details=details_json,
        )

        return event_id

    def log_alert(
        self,
        action_type: str,
        target: str,
        rule_id: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Log an alert (suspicious but not blocked)

        Returns:
            event_id
        """
        seq = self._next_seq()
        event_id = self._generate_event_id(seq)

        details_json = json.dumps(details) if details else None

        insert_cieu_event(
            self.conn,
            event_id=event_id,
            session_id=self.session_id,
            session_seq=seq,
            event_type="alert",
            action_type=action_type,
            target=target,
            rule_id=rule_id,
            details=details_json,
        )

        return event_id

    def log_hook_failure(
        self,
        error: Exception,
        tool_name: Optional[str] = None,
    ) -> str:
        """
        Log hook failure (fail-closed)

        Returns:
            event_id
        """
        seq = self._next_seq()
        event_id = self._generate_event_id(seq)

        details = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "tool_name": tool_name,
        }

        insert_cieu_event(
            self.conn,
            event_id=event_id,
            session_id=self.session_id,
            session_seq=seq,
            event_type="hook_failure",
            action_type="internal",
            target="hook",
            rule_id="HOOK_FAILURE",
            details=json.dumps(details),
        )

        return event_id

    def log_hook_timeout(
        self,
        elapsed_ms: float,
        tool_name: Optional[str] = None,
    ) -> str:
        """
        Log hook timeout (>100ms)

        Returns:
            event_id
        """
        seq = self._next_seq()
        event_id = self._generate_event_id(seq)

        details = {
            "elapsed_ms": elapsed_ms,
            "threshold_ms": 100,
            "tool_name": tool_name,
        }

        insert_cieu_event(
            self.conn,
            event_id=event_id,
            session_id=self.session_id,
            session_seq=seq,
            event_type="hook_timeout",
            action_type="internal",
            target="hook",
            rule_id="HOOK_TIMEOUT",
            details=json.dumps(details),
        )

        return event_id

    def get_recent_events(self, limit: int = 100, event_type: Optional[str] = None):
        """Get recent events"""
        return get_recent_events(self.conn, limit, event_type)

    def get_events_in_window(
        self,
        start_seq: int,
        window_seconds: float = 60.0,
    ):
        """Get events within time window from a starting sequence"""
        return get_events_in_window(
            self.conn, self.session_id, start_seq, window_seconds
        )

    def get_stats(self) -> Dict[str, int]:
        """Get event statistics"""
        return get_event_stats(self.conn)

    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()

    def __enter__(self):
        """Context manager entry"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
