"""
Level 2 Enforcer - Learned Whitelist
These rules are automatically learned from agent's normal behavior
"""
import re
import json
from typing import Tuple, Optional, Dict, Any, List
from pathlib import Path
from datetime import datetime
import sqlite3


class Level2Enforcer:
    """
    Enforces learned whitelist rules
    Only allows actions that match known-good patterns
    """

    RULE_PREFIX = "L2_"

    def __init__(self, db_conn: sqlite3.Connection):
        """
        Args:
            db_conn: Database connection to read/write whitelist rules
        """
        self.conn = db_conn
        self._load_whitelist()

    def _load_whitelist(self):
        """Load active whitelist rules from database"""
        from ..db import get_active_whitelist_rules

        self.rules = get_active_whitelist_rules(self.conn)

        # Organize rules by type for fast lookup
        self.path_prefixes = []
        self.command_patterns = []
        self.domains = []

        for rule in self.rules:
            rule_type = rule['rule_type']
            pattern = rule['pattern']

            if rule_type == 'path_prefix':
                self.path_prefixes.append({
                    'pattern': pattern,
                    'rule_id': rule['rule_id'],
                })
            elif rule_type == 'command_pattern':
                # Compile regex for command patterns
                try:
                    compiled = re.compile(pattern)
                    self.command_patterns.append({
                        'pattern': pattern,
                        'compiled': compiled,
                        'rule_id': rule['rule_id'],
                    })
                except re.error:
                    # Invalid regex, skip
                    pass
            elif rule_type == 'domain':
                self.domains.append({
                    'pattern': pattern,
                    'rule_id': rule['rule_id'],
                })

    def check_file_access(self, path: str, action: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if file access is whitelisted

        Args:
            path: File path
            action: 'read' or 'write'

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        # Normalize path
        normalized = str(Path(path).resolve())

        # Check path prefixes
        for rule in self.path_prefixes:
            prefix = rule['pattern']
            if normalized.startswith(prefix):
                # Update usage
                from ..db import update_rule_usage
                update_rule_usage(self.conn, rule['rule_id'])
                return True, None, rule['rule_id']

        # No match
        return (
            False,
            f"Path not in whitelist: {path}",
            f"{self.RULE_PREFIX}UNKNOWN_PATH"
        )

    def check_command(self, cmd: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if command matches learned patterns

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        # Check against command patterns
        for rule in self.command_patterns:
            if rule['compiled'].search(cmd):
                # Update usage
                from ..db import update_rule_usage
                update_rule_usage(self.conn, rule['rule_id'])
                return True, None, rule['rule_id']

        # No match
        return (
            False,
            f"Command not in whitelist: {cmd[:100]}",
            f"{self.RULE_PREFIX}UNKNOWN_COMMAND"
        )

    def check_domain(self, url: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if domain is whitelisted

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        from urllib.parse import urlparse

        try:
            parsed = urlparse(url)
            domain = parsed.netloc or parsed.path.split('/')[0]
        except Exception:
            return False, "Invalid URL format", f"{self.RULE_PREFIX}INVALID_URL"

        # Check whitelisted domains
        for rule in self.domains:
            allowed_domain = rule['pattern']
            if domain.endswith(allowed_domain) or domain == allowed_domain:
                # Update usage
                from ..db import update_rule_usage
                update_rule_usage(self.conn, rule['rule_id'])
                return True, None, rule['rule_id']

        # No match
        return (
            False,
            f"Domain not in whitelist: {domain}",
            f"{self.RULE_PREFIX}UNKNOWN_DOMAIN"
        )

    def check_tool_call(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
    ) -> Tuple[bool, Optional[str], str]:
        """
        Unified Level 2 check for any tool call

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        # File read/write operations
        if tool_name.lower() in ('read', 'read_file', 'readfile'):
            path = tool_args.get('file_path') or tool_args.get('path') or tool_args.get('file')
            if path:
                return self.check_file_access(path, 'read')

        elif tool_name.lower() in ('write', 'write_file', 'writefile', 'edit', 'edit_file'):
            path = tool_args.get('file_path') or tool_args.get('path') or tool_args.get('file')
            if path:
                return self.check_file_access(path, 'write')

        # Command execution
        elif tool_name.lower() in ('bash', 'shell', 'execute', 'run_command'):
            cmd = tool_args.get('command') or tool_args.get('cmd')
            if cmd:
                return self.check_command(cmd)

        # Network requests
        elif tool_name.lower() in ('http', 'request', 'fetch', 'curl', 'websearch'):
            url = tool_args.get('url') or tool_args.get('uri')
            if url:
                return self.check_domain(url)

        # Unknown tool type - allow by default (Level 1 will catch hard violations)
        return True, None, ""

    def get_stats(self) -> Dict[str, Any]:
        """Get enforcer statistics"""
        return {
            "total_rules": len(self.rules),
            "path_prefixes": len(self.path_prefixes),
            "command_patterns": len(self.command_patterns),
            "domains": len(self.domains),
        }


class WhitelistLearner:
    """
    Learns whitelist rules from observed behavior
    """

    def __init__(self, db_conn: sqlite3.Connection):
        self.conn = db_conn

    def analyze_learning_period(self, hours: int = 24) -> Dict[str, List[str]]:
        """
        Analyze CIEU events from learning period and generate whitelist rules

        Args:
            hours: Number of hours to look back (default: 24)

        Returns:
            {
                'path_prefixes': [...],
                'command_patterns': [...],
                'domains': [...],
            }
        """
        from ..db import get_recent_events

        # Get all allowed events from learning period
        cutoff_time = datetime.now().timestamp() - (hours * 3600)

        cursor = self.conn.execute("""
            SELECT action_type, target, details
            FROM cieu_events
            WHERE event_type = 'allowed'
              AND timestamp >= ?
            ORDER BY timestamp ASC
        """, (cutoff_time,))

        events = [dict(row) for row in cursor.fetchall()]

        # Aggregate patterns
        paths_read = set()
        paths_write = set()
        commands = []
        domains = set()

        for event in events:
            action_type = event['action_type']
            target = event['target']

            if action_type == 'read_file':
                if target and not self._is_temp_path(target):
                    paths_read.add(target)
            elif action_type == 'write_file':
                if target and not self._is_temp_path(target):
                    paths_write.add(target)
            elif action_type == 'execute':
                if target:
                    commands.append(target)
            elif action_type == 'network':
                # Extract domain from URL
                from urllib.parse import urlparse
                try:
                    parsed = urlparse(target)
                    domain = parsed.netloc or parsed.path.split('/')[0]
                    if domain:
                        domains.add(domain)
                except:
                    pass

        # Generate rules
        path_prefixes = self._extract_path_prefixes(paths_read | paths_write)
        command_patterns = self._extract_command_patterns(commands)

        return {
            'path_prefixes': path_prefixes,
            'command_patterns': command_patterns,
            'domains': list(domains),
        }

    def _is_temp_path(self, path: str) -> bool:
        """Check if path is temporary (session-specific, should not be in whitelist)"""
        temp_indicators = [
            '/tmp/', '/var/tmp/', '/.cache/', '/temp/',
            '.pytest_cache', '__pycache__', '.pyc',
        ]
        return any(indicator in path for indicator in temp_indicators)

    def _extract_path_prefixes(self, paths: set) -> List[str]:
        """
        Extract common path prefixes

        Strategy:
        - Group by directory
        - Keep prefixes that cover multiple files
        - Individual files become exact path rules
        """
        prefixes = set()

        for path in paths:
            try:
                p = Path(path).resolve()
                # Add parent directories up to 3 levels
                parent = p.parent
                for _ in range(3):
                    if parent != parent.parent:
                        prefixes.add(str(parent))
                        parent = parent.parent
                    else:
                        break
            except:
                pass

        return sorted(prefixes)

    def _extract_command_patterns(self, commands: List[str]) -> List[str]:
        """
        Extract command patterns

        Strategy:
        - Common CLI tools → exact match patterns
        - Scripts with varying args → regex patterns
        """
        patterns = set()

        for cmd in commands:
            # Extract base command (first word)
            parts = cmd.split()
            if not parts:
                continue

            base_cmd = parts[0]

            # Common safe commands - exact match
            safe_commands = [
                'ls', 'cat', 'grep', 'find', 'echo', 'pwd', 'cd',
                'git', 'python', 'python3', 'pip', 'npm', 'node',
                'make', 'cargo', 'go', 'javac', 'java',
            ]

            if any(base_cmd.endswith(safe) for safe in safe_commands):
                # Regex: allow this command with any args
                pattern = re.escape(base_cmd) + r'\b.*'
                patterns.add(pattern)
            else:
                # Unknown command - allow exact match only
                patterns.add(re.escape(cmd))

        return sorted(patterns)

    def save_whitelist(self, rules: Dict[str, List[str]]) -> int:
        """
        Save learned whitelist rules to database

        Returns:
            Number of rules saved
        """
        from ..db import insert_whitelist_rule
        import hashlib

        count = 0

        # Path prefixes
        for pattern in rules['path_prefixes']:
            rule_id = f"L2_PATH_{hashlib.sha256(pattern.encode()).hexdigest()[:12]}"
            try:
                insert_whitelist_rule(
                    self.conn,
                    rule_id=rule_id,
                    rule_type='path_prefix',
                    pattern=pattern,
                    created_by='auto',
                )
                count += 1
            except sqlite3.IntegrityError:
                # Rule already exists
                pass

        # Command patterns
        for pattern in rules['command_patterns']:
            rule_id = f"L2_CMD_{hashlib.sha256(pattern.encode()).hexdigest()[:12]}"
            try:
                insert_whitelist_rule(
                    self.conn,
                    rule_id=rule_id,
                    rule_type='command_pattern',
                    pattern=pattern,
                    created_by='auto',
                )
                count += 1
            except sqlite3.IntegrityError:
                pass

        # Domains
        for pattern in rules['domains']:
            rule_id = f"L2_DOMAIN_{hashlib.sha256(pattern.encode()).hexdigest()[:12]}"
            try:
                insert_whitelist_rule(
                    self.conn,
                    rule_id=rule_id,
                    rule_type='domain',
                    pattern=pattern,
                    created_by='auto',
                )
                count += 1
            except sqlite3.IntegrityError:
                pass

        return count
