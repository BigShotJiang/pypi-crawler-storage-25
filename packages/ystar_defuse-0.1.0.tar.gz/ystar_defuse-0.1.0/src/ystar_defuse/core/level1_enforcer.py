"""
Level 1 Enforcer - Hard bottom line rules
These rules CANNOT be overridden by user whitelist
"""
import json
from typing import Tuple, Optional, Dict, Any
from urllib.parse import urlparse

from ..rules.sensitive_paths import is_sensitive_path
from ..rules.dangerous_cmds import is_dangerous_command
from ..rules.secret_patterns import sanitize_output, contains_secrets


class Level1Enforcer:
    """
    Enforces hard bottom line security rules
    All checks return (is_allowed, reason, modified_args)
    """

    RULE_PREFIX = "L1_"

    def __init__(self, allowed_domains: Optional[list] = None):
        """
        Args:
            allowed_domains: List of explicitly allowed domains for network requests
        """
        self.allowed_domains = allowed_domains or []

    def check_file_read(self, path: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if reading a file is allowed

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        is_sensitive, reason = is_sensitive_path(path)
        if is_sensitive:
            return False, reason, f"{self.RULE_PREFIX}SENSITIVE_FILE"

        return True, None, ""

    def check_file_write(self, path: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if writing to a file is allowed

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        is_sensitive, reason = is_sensitive_path(path)
        if is_sensitive:
            return False, reason, f"{self.RULE_PREFIX}SENSITIVE_FILE"

        return True, None, ""

    def check_command(self, cmd: str) -> Tuple[bool, Optional[str], str]:
        """
        Check if executing a command is allowed

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        is_dangerous, reason = is_dangerous_command(cmd)
        if is_dangerous:
            return False, reason, f"{self.RULE_PREFIX}DANGEROUS_CMD"

        return True, None, ""

    def check_network_request(
        self,
        url: str,
        payload: Optional[str] = None,
    ) -> Tuple[bool, Optional[str], str]:
        """
        Check if network request is allowed

        Returns:
            (is_allowed, violation_reason, rule_id)
        """
        # Parse domain
        try:
            parsed = urlparse(url)
            domain = parsed.netloc or parsed.path.split('/')[0]
        except Exception:
            return False, "Invalid URL format", f"{self.RULE_PREFIX}INVALID_URL"

        # Check if domain is in whitelist
        if self.allowed_domains:
            if not any(domain.endswith(allowed) for allowed in self.allowed_domains):
                return (
                    False,
                    f"Network request to unknown domain: {domain}",
                    f"{self.RULE_PREFIX}UNKNOWN_DOMAIN"
                )

        # Check if payload contains secrets
        if payload and contains_secrets(payload):
            return (
                False,
                "Network request payload contains secrets",
                f"{self.RULE_PREFIX}SECRET_EXFILTRATION"
            )

        return True, None, ""

    def sanitize_tool_output(self, output: str) -> Tuple[str, list]:
        """
        Sanitize tool output by masking secrets

        Returns:
            (sanitized_output, detected_secret_types)
        """
        return sanitize_output(output)

    def check_tool_call(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
    ) -> Tuple[bool, Optional[str], str, Dict[str, Any]]:
        """
        Unified check for any tool call

        Returns:
            (is_allowed, violation_reason, rule_id, modified_args)
        """
        modified_args = tool_args.copy()

        # File read operations
        if tool_name.lower() in ('read', 'read_file', 'readfile'):
            path = tool_args.get('file_path') or tool_args.get('path') or tool_args.get('file')
            if path:
                allowed, reason, rule_id = self.check_file_read(path)
                if not allowed:
                    return False, reason, rule_id, modified_args

        # File write operations
        elif tool_name.lower() in ('write', 'write_file', 'writefile', 'edit', 'edit_file'):
            path = tool_args.get('file_path') or tool_args.get('path') or tool_args.get('file')
            if path:
                allowed, reason, rule_id = self.check_file_write(path)
                if not allowed:
                    return False, reason, rule_id, modified_args

        # Command execution
        elif tool_name.lower() in ('bash', 'shell', 'execute', 'run_command'):
            cmd = tool_args.get('command') or tool_args.get('cmd')
            if cmd:
                allowed, reason, rule_id = self.check_command(cmd)
                if not allowed:
                    return False, reason, rule_id, modified_args

        # Network requests
        elif tool_name.lower() in ('http', 'request', 'fetch', 'curl', 'websearch'):
            url = tool_args.get('url') or tool_args.get('uri')
            payload = tool_args.get('data') or tool_args.get('body') or tool_args.get('payload')
            if isinstance(payload, dict):
                payload = json.dumps(payload)

            if url:
                allowed, reason, rule_id = self.check_network_request(url, payload)
                if not allowed:
                    return False, reason, rule_id, modified_args

        return True, None, "", modified_args

    def get_stats(self) -> Dict[str, Any]:
        """Get enforcer statistics"""
        from ..rules.sensitive_paths import get_sensitive_pattern_count
        from ..rules.dangerous_cmds import get_dangerous_pattern_count
        from ..rules.secret_patterns import get_secret_pattern_count

        return {
            "sensitive_file_patterns": get_sensitive_pattern_count(),
            "dangerous_command_patterns": get_dangerous_pattern_count(),
            "secret_patterns": get_secret_pattern_count(),
            "allowed_domains": len(self.allowed_domains),
        }
