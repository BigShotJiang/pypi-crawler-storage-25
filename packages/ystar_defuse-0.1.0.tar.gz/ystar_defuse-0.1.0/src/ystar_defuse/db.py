"""
ystar-defuse Database Schema and Operations
CIEU lightweight version - compatible with Y*gov format
"""
import sqlite3
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

# Database location
DB_PATH = Path.home() / ".ystar_defuse" / "defuse.db"


def get_db_path() -> Path:
    """Get database path, create directory if needed"""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return DB_PATH


def init_db(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Initialize database with schema"""
    if db_path is None:
        db_path = get_db_path()

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row  # Return rows as dicts

    # Enable WAL mode for better concurrency
    conn.execute("PRAGMA journal_mode=WAL")

    # Create CIEU events table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cieu_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT UNIQUE NOT NULL,
            session_id TEXT NOT NULL,
            session_seq INTEGER NOT NULL,
            timestamp REAL NOT NULL,
            event_type TEXT NOT NULL,  -- blocked|allowed|alert|hook_failure|hook_timeout
            action_type TEXT NOT NULL, -- read_file|write_file|execute|network|output
            target TEXT,               -- file path, domain, or command
            rule_id TEXT,              -- which rule was triggered
            details TEXT,              -- JSON for additional context
            UNIQUE(session_id, session_seq)
        )
    """)

    # Create whitelist rules table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS whitelist_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_id TEXT UNIQUE NOT NULL,
            rule_type TEXT NOT NULL,   -- path_prefix|command_pattern|domain|output_pattern
            pattern TEXT NOT NULL,
            learned_at REAL NOT NULL,
            last_used REAL,
            use_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active', -- active|dormant|pending
            created_by TEXT DEFAULT 'auto' -- auto|manual
        )
    """)

    # Create learning mode metadata table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS learning_metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at REAL NOT NULL
        )
    """)

    # Create indexes for common queries
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cieu_session ON cieu_events(session_id, session_seq)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cieu_timestamp ON cieu_events(timestamp)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_cieu_event_type ON cieu_events(event_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_whitelist_status ON whitelist_rules(status)")

    conn.commit()
    return conn


def insert_cieu_event(
    conn: sqlite3.Connection,
    event_id: str,
    session_id: str,
    session_seq: int,
    event_type: str,
    action_type: str,
    target: Optional[str] = None,
    rule_id: Optional[str] = None,
    details: Optional[str] = None,
) -> int:
    """Insert a CIEU event, return row id"""
    timestamp = datetime.now().timestamp()

    cursor = conn.execute("""
        INSERT INTO cieu_events (
            event_id, session_id, session_seq, timestamp,
            event_type, action_type, target, rule_id, details
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (event_id, session_id, session_seq, timestamp,
          event_type, action_type, target, rule_id, details))

    conn.commit()
    return cursor.lastrowid


def get_recent_events(
    conn: sqlite3.Connection,
    limit: int = 100,
    event_type: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Get recent CIEU events"""
    if event_type:
        cursor = conn.execute("""
            SELECT * FROM cieu_events
            WHERE event_type = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """, (event_type, limit))
    else:
        cursor = conn.execute("""
            SELECT * FROM cieu_events
            ORDER BY timestamp DESC
            LIMIT ?
        """, (limit,))

    return [dict(row) for row in cursor.fetchall()]


def get_events_in_window(
    conn: sqlite3.Connection,
    session_id: str,
    start_seq: int,
    window_seconds: float = 60.0,
) -> List[Dict[str, Any]]:
    """Get events within a time window from a starting sequence"""
    # Get timestamp of the starting event
    row = conn.execute("""
        SELECT timestamp FROM cieu_events
        WHERE session_id = ? AND session_seq = ?
    """, (session_id, start_seq)).fetchone()

    if not row:
        return []

    start_time = row[0]
    end_time = start_time + window_seconds

    cursor = conn.execute("""
        SELECT * FROM cieu_events
        WHERE session_id = ?
          AND session_seq >= ?
          AND timestamp BETWEEN ? AND ?
        ORDER BY session_seq
    """, (session_id, start_seq, start_time, end_time))

    return [dict(row) for row in cursor.fetchall()]


def insert_whitelist_rule(
    conn: sqlite3.Connection,
    rule_id: str,
    rule_type: str,
    pattern: str,
    created_by: str = 'auto',
) -> int:
    """
    Insert a whitelist rule

    Args:
        conn: Database connection
        rule_id: Unique rule identifier
        rule_type: One of 'path_prefix', 'command_pattern', 'domain', 'output_pattern'
        pattern: The pattern to match
                 IMPORTANT: For path_prefix rules, you MUST resolve the path first
                 to handle OS-specific symlinks (e.g., macOS /var -> /private/var):
                 pattern = str(Path(your_path).resolve())
        created_by: 'auto' for learned rules, 'manual' for user-added rules

    Returns:
        Row id of inserted rule
    """
    learned_at = datetime.now().timestamp()

    cursor = conn.execute("""
        INSERT INTO whitelist_rules (
            rule_id, rule_type, pattern, learned_at, created_by
        ) VALUES (?, ?, ?, ?, ?)
    """, (rule_id, rule_type, pattern, learned_at, created_by))

    conn.commit()
    return cursor.lastrowid


def get_active_whitelist_rules(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """Get all active whitelist rules"""
    cursor = conn.execute("""
        SELECT * FROM whitelist_rules
        WHERE status = 'active'
        ORDER BY learned_at
    """)
    return [dict(row) for row in cursor.fetchall()]


def update_rule_usage(conn: sqlite3.Connection, rule_id: str):
    """Update rule usage timestamp and count"""
    now = datetime.now().timestamp()
    conn.execute("""
        UPDATE whitelist_rules
        SET last_used = ?, use_count = use_count + 1
        WHERE rule_id = ?
    """, (now, rule_id))
    conn.commit()


def decay_dormant_permissions(
    conn: sqlite3.Connection,
    high_freq_days: int = 30,
    low_freq_days: int = 7,
):
    """Mark permissions as dormant if unused for too long"""
    now = datetime.now().timestamp()
    high_freq_threshold = now - (high_freq_days * 24 * 3600)
    low_freq_threshold = now - (low_freq_days * 24 * 3600)

    # High-frequency rules: used >10 times
    conn.execute("""
        UPDATE whitelist_rules
        SET status = 'dormant'
        WHERE status = 'active'
          AND use_count > 10
          AND (last_used IS NULL OR last_used < ?)
    """, (high_freq_threshold,))

    # Low-frequency rules: used <=10 times
    conn.execute("""
        UPDATE whitelist_rules
        SET status = 'dormant'
        WHERE status = 'active'
          AND use_count <= 10
          AND (last_used IS NULL OR last_used < ?)
    """, (low_freq_threshold,))

    conn.commit()


def get_learning_metadata(conn: sqlite3.Connection, key: str) -> Optional[str]:
    """Get learning mode metadata"""
    row = conn.execute(
        "SELECT value FROM learning_metadata WHERE key = ?", (key,)
    ).fetchone()
    return row[0] if row else None


def set_learning_metadata(conn: sqlite3.Connection, key: str, value: str):
    """Set learning mode metadata"""
    now = datetime.now().timestamp()
    conn.execute("""
        INSERT OR REPLACE INTO learning_metadata (key, value, updated_at)
        VALUES (?, ?, ?)
    """, (key, value, now))
    conn.commit()


def get_event_stats(conn: sqlite3.Connection) -> Dict[str, int]:
    """Get event statistics"""
    cursor = conn.execute("""
        SELECT event_type, COUNT(*) as count
        FROM cieu_events
        GROUP BY event_type
    """)
    return {row[0]: row[1] for row in cursor.fetchall()}
