#!/usr/bin/env python3
"""
Y*Defuse CLI

Commands:
    ystar-defuse start    - Start protection (install hook)
    ystar-defuse stop     - Stop protection (uninstall hook)
    ystar-defuse report   - Show recent events
    ystar-defuse stats    - Show statistics
    ystar-defuse config   - Show configuration
"""
import sys
import argparse
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

from ystar_defuse import __version__
from ystar_defuse.core.cieu_logger import CIEULogger
from ystar_defuse.core.level1_enforcer import Level1Enforcer
from ystar_defuse.db import get_db_path, get_learning_metadata, set_learning_metadata


# Claude Code settings.json path
CLAUDE_SETTINGS_PATH = Path.home() / ".claude" / "settings.json"


def cmd_start(args):
    """Start ystar-defuse protection"""
    print("Starting Y*Defuse protection...")

    # Check if already started
    db_path = get_db_path()
    if db_path.exists():
        print(f"Database already exists at: {db_path}")
    else:
        print(f"Creating database at: {db_path}")

    # Initialize database
    logger = CIEULogger()

    # Set learning mode (24 hours by default)
    learning_start = str(datetime.now().timestamp())
    set_learning_metadata(logger.conn, "learning_mode", "active")
    set_learning_metadata(logger.conn, "learning_start", learning_start)

    logger.close()

    print("\n[Learning Mode Activated]")
    print("Y*Defuse will now observe your agent's behavior for 24 hours.")
    print("After that, you'll be asked to confirm the auto-generated whitelist.")
    print("\nDuring learning mode:")
    print("  - All actions are monitored")
    print("  - Level 1 hard rules are enforced")
    print("  - Level 2 whitelist is being learned")
    print("\nTo integrate with Claude Code, add this to ~/.claude/settings.json:")
    print("\n{")
    print('  "hooks": {')
    hook_path = Path(__file__).parent / "hook.py"
    print(f'    "preToolUse": "python {hook_path}"')
    print('  }')
    print("}\n")

    print("Start successful!")


def cmd_stop(args):
    """Stop ystar-defuse protection"""
    print("Stopping Y*Defuse protection...")

    # Update learning metadata
    logger = CIEULogger()
    set_learning_metadata(logger.conn, "learning_mode", "stopped")
    logger.close()

    print("\nTo fully disable, remove the hook from ~/.claude/settings.json")
    print("Stop successful!")


def cmd_report(args):
    """Show recent events"""
    logger = CIEULogger()

    limit = args.limit or 50
    event_type = args.type

    events = logger.get_recent_events(limit, event_type)
    logger.close()

    if not events:
        print("No events found.")
        return

    print(f"\n{'='*80}")
    print(f"Recent Events (limit={limit})")
    if event_type:
        print(f"Filtered by: {event_type}")
    print(f"{'='*80}\n")

    for event in events:
        timestamp = datetime.fromtimestamp(event['timestamp']).strftime("%Y-%m-%d %H:%M:%S")
        event_type_display = event['event_type'].upper()

        # Color coding
        if event['event_type'] == 'blocked':
            color = '\033[91m'  # Red
        elif event['event_type'] == 'alert':
            color = '\033[93m'  # Yellow
        elif event['event_type'] == 'allowed':
            color = '\033[92m'  # Green
        else:
            color = '\033[0m'   # Default

        reset = '\033[0m'

        print(f"{color}[{event_type_display}]{reset} {timestamp}")
        print(f"  Action: {event['action_type']}")
        print(f"  Target: {event['target']}")
        if event['rule_id']:
            print(f"  Rule: {event['rule_id']}")
        if event['details']:
            try:
                details = json.loads(event['details'])
                print(f"  Details: {json.dumps(details, indent=4)}")
            except:
                print(f"  Details: {event['details']}")
        print()


def cmd_stats(args):
    """Show statistics"""
    logger = CIEULogger()
    enforcer = Level1Enforcer()

    # Event stats
    event_stats = logger.get_stats()

    # Enforcer stats
    enforcer_stats = enforcer.get_stats()

    # Learning metadata
    learning_mode = get_learning_metadata(logger.conn, "learning_mode")
    learning_start = get_learning_metadata(logger.conn, "learning_start")

    logger.close()

    print(f"\n{'='*80}")
    print("Y*Defuse Statistics")
    print(f"{'='*80}\n")

    print("Event Counts:")
    for event_type, count in event_stats.items():
        print(f"  {event_type}: {count}")

    print("\nLevel 1 Protection:")
    print(f"  Sensitive file patterns: {enforcer_stats['sensitive_file_patterns']}")
    print(f"  Dangerous command patterns: {enforcer_stats['dangerous_command_patterns']}")
    print(f"  Secret patterns: {enforcer_stats['secret_patterns']}")
    print(f"  Allowed domains: {enforcer_stats['allowed_domains']}")

    print("\nLearning Mode:")
    print(f"  Status: {learning_mode or 'not started'}")
    if learning_start:
        start_time = datetime.fromtimestamp(float(learning_start))
        print(f"  Started: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        elapsed_hours = (datetime.now() - start_time).total_seconds() / 3600
        print(f"  Elapsed: {elapsed_hours:.1f} hours")

    print()


def cmd_learn(args):
    """Show learned whitelist or generate new one"""
    logger = CIEULogger()

    learning_mode = get_learning_metadata(logger.conn, "learning_mode")
    learning_start = get_learning_metadata(logger.conn, "learning_start")

    if not learning_start:
        print("Learning mode has not been started.")
        print("Run 'ystar-defuse start' first.")
        logger.close()
        return

    start_time = datetime.fromtimestamp(float(learning_start))
    elapsed_hours = (datetime.now() - start_time).total_seconds() / 3600

    print(f"\n{'='*80}")
    print("Learning Period Analysis")
    print(f"{'='*80}\n")

    print(f"Started: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Elapsed: {elapsed_hours:.1f} hours")

    if elapsed_hours < 24:
        print(f"\nRecommendation: Wait {24 - elapsed_hours:.1f} more hours for better patterns")
        print("(You can proceed now, but more data = better whitelist)")

    # Generate whitelist
    from ystar_defuse.core.level2_enforcer import WhitelistLearner

    learner = WhitelistLearner(logger.conn)
    rules = learner.analyze_learning_period(hours=int(elapsed_hours) + 1)

    print(f"\n{'='*80}")
    print("Learned Whitelist Rules")
    print(f"{'='*80}\n")

    print(f"Path Prefixes ({len(rules['path_prefixes'])}):")
    for prefix in rules['path_prefixes'][:10]:
        print(f"  {prefix}")
    if len(rules['path_prefixes']) > 10:
        print(f"  ... and {len(rules['path_prefixes']) - 10} more")

    print(f"\nCommand Patterns ({len(rules['command_patterns'])}):")
    for pattern in rules['command_patterns'][:10]:
        print(f"  {pattern}")
    if len(rules['command_patterns']) > 10:
        print(f"  ... and {len(rules['command_patterns']) - 10} more")

    print(f"\nDomains ({len(rules['domains'])}):")
    for domain in rules['domains'][:10]:
        print(f"  {domain}")
    if len(rules['domains']) > 10:
        print(f"  ... and {len(rules['domains']) - 10} more")

    print(f"\nTotal Rules: {len(rules['path_prefixes']) + len(rules['command_patterns']) + len(rules['domains'])}")
    print("\nNext step: Run 'ystar-defuse confirm' to save and activate these rules")

    logger.close()


def cmd_confirm(args):
    """Confirm and activate learned whitelist"""
    logger = CIEULogger()

    learning_start = get_learning_metadata(logger.conn, "learning_start")
    if not learning_start:
        print("No learning period found. Run 'ystar-defuse start' first.")
        logger.close()
        return

    # Generate whitelist
    from ystar_defuse.core.level2_enforcer import WhitelistLearner

    start_time = datetime.fromtimestamp(float(learning_start))
    elapsed_hours = (datetime.now() - start_time).total_seconds() / 3600

    learner = WhitelistLearner(logger.conn)
    rules = learner.analyze_learning_period(hours=int(elapsed_hours) + 1)

    # Save to database
    count = learner.save_whitelist(rules)

    # Activate enforce mode
    set_learning_metadata(logger.conn, "learning_mode", "enforce")

    print(f"\n{'='*80}")
    print("Whitelist Confirmed and Activated")
    print(f"{'='*80}\n")

    print(f"Saved {count} rules to database")
    print("Enforcement mode: ACTIVE")
    print("\nY*Defuse will now block any action not in the whitelist.")
    print("\nTo add new rules, run 'ystar-defuse stop' then 'ystar-defuse start' to re-learn.")

    logger.close()


def cmd_config(args):
    """Show configuration"""
    db_path = get_db_path()

    print(f"\n{'='*80}")
    print("Y*Defuse Configuration")
    print(f"{'='*80}\n")

    print(f"Version: {__version__}")
    print(f"Database: {db_path}")
    print(f"Hook script: {Path(__file__).parent / 'hook.py'}")

    # Check Claude Code settings
    if CLAUDE_SETTINGS_PATH.exists():
        try:
            with open(CLAUDE_SETTINGS_PATH) as f:
                settings = json.load(f)
                hooks = settings.get("hooks", {})
                pre_tool_use = hooks.get("preToolUse")

                print(f"\nClaude Code Integration:")
                if pre_tool_use:
                    print(f"  Installed: YES")
                    print(f"  Hook: {pre_tool_use}")
                else:
                    print(f"  Installed: NO")
                    print(f"  (Add hook to ~/.claude/settings.json to activate)")
        except Exception as e:
            print(f"\nClaude Code settings: Error reading - {e}")
    else:
        print(f"\nClaude Code settings: Not found at {CLAUDE_SETTINGS_PATH}")

    print()


def main():
    """CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Y*Defuse - AI Bomb Disposal",
        epilog="We don't detect the bomb. We defuse it."
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"ystar-defuse {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # start
    parser_start = subparsers.add_parser("start", help="Start protection")

    # stop
    parser_stop = subparsers.add_parser("stop", help="Stop protection")

    # report
    parser_report = subparsers.add_parser("report", help="Show recent events")
    parser_report.add_argument(
        "--limit", "-n",
        type=int,
        default=50,
        help="Number of events to show (default: 50)"
    )
    parser_report.add_argument(
        "--type", "-t",
        choices=["blocked", "allowed", "alert", "hook_failure", "hook_timeout"],
        help="Filter by event type"
    )

    # stats
    parser_stats = subparsers.add_parser("stats", help="Show statistics")

    # config
    parser_config = subparsers.add_parser("config", help="Show configuration")

    # learn
    parser_learn = subparsers.add_parser("learn", help="Show learned whitelist")

    # confirm
    parser_confirm = subparsers.add_parser("confirm", help="Confirm and activate whitelist")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Dispatch to command handler
    commands = {
        "start": cmd_start,
        "stop": cmd_stop,
        "report": cmd_report,
        "stats": cmd_stats,
        "config": cmd_config,
        "learn": cmd_learn,
        "confirm": cmd_confirm,
    }

    handler = commands.get(args.command)
    if handler:
        handler(args)
    else:
        print(f"Unknown command: {args.command}")
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
