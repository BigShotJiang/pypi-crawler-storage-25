#!/usr/bin/env python3
"""
Y*Defuse PreToolUse Hook

This hook is called before every tool execution in Claude Code.
It enforces Level 1 + Level 2 protection rules.

Failure mode: FAIL-CLOSED (any error = DENY)
Timeout threshold: 100ms
"""
import sys
import json
import time
import traceback
from typing import Dict, Any

from ystar_defuse.core.cieu_logger import CIEULogger
from ystar_defuse.core.level1_enforcer import Level1Enforcer
from ystar_defuse.core.level2_enforcer import Level2Enforcer
from ystar_defuse.db import get_learning_metadata


TIMEOUT_MS = 100


def pre_tool_use(tool_name: str, tool_args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Hook entry point called before every tool execution

    Returns:
        {
            "allowed": bool,
            "reason": str (if blocked),
            "modified_args": dict (if args were modified)
        }
    """
    start_time = time.time()

    try:
        # Initialize logger and enforcer
        logger = CIEULogger()
        enforcer = Level1Enforcer()

        # Level 1 check (hard bottom line)
        allowed, reason, rule_id, modified_args = enforcer.check_tool_call(
            tool_name, tool_args
        )

        # Check elapsed time
        elapsed_ms = (time.time() - start_time) * 1000
        if elapsed_ms > TIMEOUT_MS:
            # Log timeout
            logger.log_hook_timeout(elapsed_ms, tool_name)
            logger.close()
            return {
                "allowed": False,
                "reason": f"Hook timeout: {elapsed_ms:.1f}ms > {TIMEOUT_MS}ms"
            }

        if not allowed:
            # Log blocked event
            action_type = _infer_action_type(tool_name)
            target = _extract_target(tool_args)

            logger.log_blocked(
                action_type=action_type,
                target=target,
                rule_id=rule_id,
                details={
                    "tool_name": tool_name,
                    "reason": reason,
                }
            )
            logger.close()

            return {
                "allowed": False,
                "reason": reason,
            }

        # Level 2 check (learned whitelist)
        learning_mode = get_learning_metadata(logger.conn, "learning_mode")

        if learning_mode == "enforce":
            # Whitelist enforcement is active
            level2 = Level2Enforcer(logger.conn)
            l2_allowed, l2_reason, l2_rule_id = level2.check_tool_call(tool_name, tool_args)

            if not l2_allowed:
                # Not in whitelist
                action_type = _infer_action_type(tool_name)
                target = _extract_target(tool_args)

                logger.log_blocked(
                    action_type=action_type,
                    target=target,
                    rule_id=l2_rule_id,
                    details={
                        "tool_name": tool_name,
                        "reason": l2_reason,
                    }
                )
                logger.close()

                return {
                    "allowed": False,
                    "reason": l2_reason,
                }

            # Update rule_id for logging
            rule_id = l2_rule_id

        # Passed all checks - log and allow
        action_type = _infer_action_type(tool_name)
        target = _extract_target(tool_args)

        logger.log_allowed(
            action_type=action_type,
            target=target,
            rule_id=rule_id,
            details={
                "tool_name": tool_name,
            }
        )
        logger.close()

        return {
            "allowed": True,
            "modified_args": modified_args if modified_args != tool_args else None,
        }

    except Exception as e:
        # Fail-closed on any error
        try:
            logger = CIEULogger()
            logger.log_hook_failure(e, tool_name)
            logger.close()
        except:
            # Double failure, write to stderr
            print(f"[ystar-defuse] CRITICAL: Hook failure + logging failure", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)

        return {
            "allowed": False,
            "reason": f"Hook internal error: {type(e).__name__}",
        }


def _infer_action_type(tool_name: str) -> str:
    """Infer action type from tool name"""
    tool_lower = tool_name.lower()

    if any(x in tool_lower for x in ['read', 'cat', 'view', 'grep']):
        return "read_file"
    elif any(x in tool_lower for x in ['write', 'edit', 'save']):
        return "write_file"
    elif any(x in tool_lower for x in ['bash', 'shell', 'execute', 'run']):
        return "execute"
    elif any(x in tool_lower for x in ['http', 'request', 'fetch', 'curl', 'web']):
        return "network"
    else:
        return "other"


def _extract_target(tool_args: Dict[str, Any]) -> str:
    """Extract target (file path, command, URL) from tool args"""
    # Try common parameter names
    for key in ['file_path', 'path', 'file', 'command', 'cmd', 'url', 'uri']:
        if key in tool_args:
            value = tool_args[key]
            if isinstance(value, str):
                return value[:200]  # Truncate long values

    # Fallback: JSON dump first 200 chars
    return json.dumps(tool_args)[:200]


def main():
    """
    CLI entry point for hook

    Usage:
        python hook.py '{"tool_name": "Read", "tool_args": {...}}'
    """
    if len(sys.argv) != 2:
        print(json.dumps({
            "allowed": False,
            "reason": "Invalid hook invocation: expected JSON argument"
        }))
        sys.exit(1)

    try:
        hook_input = json.loads(sys.argv[1])
        tool_name = hook_input.get("tool_name")
        tool_args = hook_input.get("tool_args", {})

        if not tool_name:
            print(json.dumps({
                "allowed": False,
                "reason": "Missing tool_name in hook input"
            }))
            sys.exit(1)

        result = pre_tool_use(tool_name, tool_args)
        print(json.dumps(result))

    except json.JSONDecodeError as e:
        print(json.dumps({
            "allowed": False,
            "reason": f"Invalid JSON input: {e}"
        }))
        sys.exit(1)

    except Exception as e:
        print(json.dumps({
            "allowed": False,
            "reason": f"Hook error: {type(e).__name__}: {e}"
        }))
        sys.exit(1)


if __name__ == "__main__":
    main()
