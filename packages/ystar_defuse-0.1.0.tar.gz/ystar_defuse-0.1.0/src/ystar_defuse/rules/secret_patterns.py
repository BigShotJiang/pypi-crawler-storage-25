"""
Secret patterns for output sanitization (Level 1 enforcement)
Automatically mask secrets in agent output
"""
import re
from typing import List, Tuple

# Secret patterns: (regex, secret_type, mask_char)
SECRET_PATTERNS = [
    # OpenAI API keys (various lengths)
    (r'sk-proj-[A-Za-z0-9_-]{20,}', 'OPENAI_PROJECT_KEY', '*'),
    (r'sk-[A-Za-z0-9]{20,}', 'OPENAI_API_KEY', '*'),

    # Anthropic API keys
    (r'sk-ant-api[0-9]{2}-[A-Za-z0-9_-]{95}', 'ANTHROPIC_API_KEY', '*'),

    # GitHub tokens
    (r'ghp_[A-Za-z0-9]{36}', 'GITHUB_PAT', '*'),
    (r'gho_[A-Za-z0-9]{36}', 'GITHUB_OAUTH', '*'),
    (r'ghu_[A-Za-z0-9]{36}', 'GITHUB_USER_TOKEN', '*'),
    (r'ghs_[A-Za-z0-9]{36}', 'GITHUB_SERVER_TOKEN', '*'),
    (r'ghr_[A-Za-z0-9]{36}', 'GITHUB_REFRESH_TOKEN', '*'),

    # Slack tokens
    (r'xox[baprs]-[A-Za-z0-9-]+', 'SLACK_TOKEN', '*'),

    # AWS keys
    (r'AKIA[0-9A-Z]{16}', 'AWS_ACCESS_KEY_ID', '*'),
    (r'(?:aws_secret_access_key\s*=\s*)[A-Za-z0-9/+=]{40}', 'AWS_SECRET_ACCESS_KEY', '*'),

    # Google API keys
    (r'AIza[0-9A-Za-z_-]{35}', 'GOOGLE_API_KEY', '*'),

    # Generic private keys
    (r'-----BEGIN PRIVATE KEY-----[A-Za-z0-9+/=\s]+-----END PRIVATE KEY-----',
     'PRIVATE_KEY', '*'),
    (r'-----BEGIN RSA PRIVATE KEY-----[A-Za-z0-9+/=\s]+-----END RSA PRIVATE KEY-----',
     'RSA_PRIVATE_KEY', '*'),
    (r'-----BEGIN OPENSSH PRIVATE KEY-----[A-Za-z0-9+/=\s]+-----END OPENSSH PRIVATE KEY-----',
     'SSH_PRIVATE_KEY', '*'),

    # JWT tokens
    (r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', 'JWT_TOKEN', '*'),

    # Generic password patterns (in common formats)
    (r'(?:password|passwd|pwd)\s*[:=]\s*["\']?([^"\'\s]{8,})["\']?',
     'PASSWORD', '*'),

    # Database connection strings
    (r'(?:postgres|mysql|mongodb)://[^:]+:([^@]+)@',
     'DB_PASSWORD', '*'),

    # Generic API key patterns
    (r'api[_-]?key\s*[:=]\s*["\']?([A-Za-z0-9_-]{32,})["\']?',
     'API_KEY', '*'),

    # SSH private key fingerprints
    (r'[0-9a-f]{2}(:[0-9a-f]{2}){15}', 'SSH_FINGERPRINT', '*'),

    # Credit card numbers (basic pattern)
    (r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b',
     'CREDIT_CARD', '*'),
]

# Compile patterns for efficiency
COMPILED_PATTERNS = [
    (re.compile(pattern), secret_type, mask_char)
    for pattern, secret_type, mask_char in SECRET_PATTERNS
]


def sanitize_output(text: str) -> Tuple[str, List[str]]:
    """
    Sanitize output by masking secrets

    Returns:
        (sanitized_text, list_of_detected_secret_types)
    """
    sanitized = text
    detected_types = []

    for pattern, secret_type, mask_char in COMPILED_PATTERNS:
        if pattern.search(sanitized):
            mask = f"[{secret_type}:{mask_char * 8}]"
            sanitized = pattern.sub(mask, sanitized)
            if secret_type not in detected_types:
                detected_types.append(secret_type)

    return sanitized, detected_types


def contains_secrets(text: str) -> bool:
    """Quick check if text contains any secrets"""
    for pattern, _, _ in COMPILED_PATTERNS:
        if pattern.search(text):
            return True
    return False


def get_secret_pattern_count() -> int:
    """Return number of secret patterns defined"""
    return len(SECRET_PATTERNS)
