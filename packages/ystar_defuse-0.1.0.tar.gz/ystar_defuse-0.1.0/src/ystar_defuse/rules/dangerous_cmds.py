"""
Dangerous command patterns for Level 1 enforcement
These commands are ALWAYS blocked, user cannot override
"""
import re
from typing import Tuple, Optional

# Dangerous command patterns (regex)
DANGEROUS_COMMANDS = [
    # Recursive deletion with force
    (r'^rm\s+.*-[rf]{2}.*\s+/', 'Recursive force delete from root'),
    (r'^rm\s+-rf\s+/', 'Recursive force delete from root'),
    (r'^rm\s+-fr\s+/', 'Recursive force delete from root'),
    (r'^rm\s+.*-[rf]{2}.*\s+~', 'Recursive force delete from home'),
    (r'^rm\s+.*-[rf]{2}.*\s+\*', 'Recursive force delete with wildcard'),

    # Permission changes that compromise security
    (r'^chmod\s+777', 'Setting world-writable permissions'),
    (r'^chmod\s+-R\s+777', 'Recursive world-writable permissions'),
    (r'^chown\s+.*\s+/', 'Changing ownership of root directory'),

    # Direct disk writes
    (r'>\s*/dev/sd[a-z]', 'Direct write to disk device'),
    (r'>\s*/dev/hd[a-z]', 'Direct write to disk device'),
    (r'>\s*/dev/nvme', 'Direct write to disk device'),
    (r'^dd\s+.*of=/dev/', 'Direct disk overwrite with dd'),

    # Fork bombs and resource exhaustion
    (r':\(\)\s*\{\s*:\|:&\s*\}', 'Fork bomb detected'),
    (r'while\s+true.*do.*done', 'Infinite loop (potential resource exhaustion)'),

    # Download and execute patterns
    (r'curl\s+.*\|\s*bash', 'Download and execute from curl'),
    (r'wget\s+.*\|\s*bash', 'Download and execute from wget'),
    (r'curl\s+.*\|\s*sh', 'Download and execute from curl'),
    (r'wget\s+.*\|\s*sh', 'Download and execute from wget'),

    # Crypto mining patterns
    (r'xmrig', 'Cryptocurrency miner'),
    (r'minerd', 'Cryptocurrency miner'),
    (r'cpuminer', 'Cryptocurrency miner'),

    # Known malicious tools
    (r'nc\s+.*-e\s*/bin/', 'Netcat reverse shell'),
    (r'ncat\s+.*-e\s*/bin/', 'Netcat reverse shell'),

    # System critical file modifications
    (r'^echo.*>>\s*/etc/passwd', 'Modifying user database'),
    (r'^echo.*>>\s*/etc/shadow', 'Modifying password database'),
    (r'^echo.*>>\s*/etc/sudoers', 'Modifying sudo configuration'),

    # Package manager abuse
    (r'pip\s+install.*--break-system-packages', 'Breaking system packages'),
    (r'npm\s+install.*--unsafe-perm', 'Unsafe npm install'),

    # Process killing patterns that could affect system stability
    (r'^kill\s+-9\s+1$', 'Killing init process'),
    (r'^killall\s+-9\s+.*', 'Force killing all processes of a type'),

    # SELinux/AppArmor disabling
    (r'setenforce\s+0', 'Disabling SELinux'),
    (r'systemctl\s+stop\s+apparmor', 'Stopping AppArmor'),

    # Command substitution with sensitive files
    (r'\$\(cat\s+\.env', 'Command substitution reading .env file'),
    (r'\$\(cat\s+.*\.env', 'Command substitution reading env file'),
    (r'\$\(grep\s+.*\.env', 'Command substitution grepping env file'),
    (r'`cat\s+\.env', 'Backtick substitution reading .env file'),

    # Base64 decode and execute patterns
    (r'base64\s+-d.*\|\s*bash', 'Base64 decode and execute'),
    (r'base64\s+-d.*\|\s*sh', 'Base64 decode and execute'),
    (r'base64\s+--decode.*\|\s*bash', 'Base64 decode and execute'),

    # Subshell with command execution
    (r'bash\s+-c\s+"\$\(cat', 'Subshell executing file contents'),
    (r'sh\s+-c\s+"\$\(cat', 'Subshell executing file contents'),
]

# Compile patterns for efficiency
COMPILED_PATTERNS = [(re.compile(pattern, re.IGNORECASE), desc) for pattern, desc in DANGEROUS_COMMANDS]


def is_dangerous_command(cmd: str) -> Tuple[bool, Optional[str]]:
    """
    Check if a command matches dangerous command patterns

    Returns:
        (is_dangerous, reason)
    """
    # Normalize whitespace
    normalized = ' '.join(cmd.split())

    for pattern, description in COMPILED_PATTERNS:
        if pattern.search(normalized):
            return True, f"Dangerous command detected: {description}"

    return False, None


def get_dangerous_pattern_count() -> int:
    """Return number of dangerous command patterns defined"""
    return len(DANGEROUS_COMMANDS)
