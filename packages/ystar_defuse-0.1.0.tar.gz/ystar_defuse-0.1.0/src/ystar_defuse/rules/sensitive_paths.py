"""
Sensitive file path patterns for Level 1 enforcement
These paths are ALWAYS blocked, user cannot override
"""
import re
from pathlib import Path
from typing import Tuple, Optional

# Sensitive file patterns (regex)
SENSITIVE_PATTERNS = [
    # Environment files
    (r'\.env$', 'Environment configuration file'),
    (r'\.env\..*', 'Environment configuration file'),
    (r'\.envrc$', 'Direnv configuration'),

    # SSH keys and configs
    (r'\.ssh/id_rsa$', 'SSH private key'),
    (r'\.ssh/id_ed25519$', 'SSH private key'),
    (r'\.ssh/id_ecdsa$', 'SSH private key'),
    (r'\.ssh/.*\.pem$', 'SSH private key'),
    (r'\.ssh/config$', 'SSH configuration'),

    # Cloud provider credentials
    (r'\.aws/credentials$', 'AWS credentials'),
    (r'\.aws/config$', 'AWS configuration'),
    (r'\.azure/credentials$', 'Azure credentials'),
    (r'\.config/gcloud/credentials\.db$', 'Google Cloud credentials'),

    # Kubernetes and Docker
    (r'\.kube/config$', 'Kubernetes configuration'),
    (r'\.docker/config\.json$', 'Docker credentials'),

    # Generic credential patterns
    (r'credentials$', 'Credentials file'),
    (r'credentials\.json$', 'Credentials file'),
    (r'credentials\.yaml$', 'Credentials file'),
    (r'credentials\.yml$', 'Credentials file'),
    (r'secrets\.json$', 'Secrets file'),
    (r'secrets\.yaml$', 'Secrets file'),

    # Database credentials
    (r'\.pgpass$', 'PostgreSQL password file'),
    (r'\.my\.cnf$', 'MySQL configuration with credentials'),

    # API keys and tokens
    (r'\.netrc$', 'Network credentials'),
    (r'\.git-credentials$', 'Git credentials'),
    (r'\.npmrc$', 'NPM credentials (may contain tokens)'),

    # Private keys (generic)
    (r'.*private.*\.key$', 'Private key file'),
    (r'.*private.*\.pem$', 'Private key file'),
    (r'\.*.p12$', 'PKCS12 certificate with private key'),
    (r'\.*.pfx$', 'PFX certificate with private key'),
]

# Compile patterns for efficiency
COMPILED_PATTERNS = [(re.compile(pattern), desc) for pattern, desc in SENSITIVE_PATTERNS]


def is_sensitive_path(path: str) -> Tuple[bool, Optional[str]]:
    """
    Check if a path matches sensitive file patterns

    Returns:
        (is_sensitive, reason)
    """
    # Normalize path
    normalized = Path(path).as_posix()

    for pattern, description in COMPILED_PATTERNS:
        if pattern.search(normalized):
            return True, f"Sensitive file detected: {description}"

    return False, None


def get_sensitive_pattern_count() -> int:
    """Return number of sensitive patterns defined"""
    return len(SENSITIVE_PATTERNS)
