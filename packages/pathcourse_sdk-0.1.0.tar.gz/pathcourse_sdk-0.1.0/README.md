# pathcourse-sdk

Official Python SDK for the [PathCourse Health](https://pathcoursehealth.com) AI gateway.

15 inference tokens. USDC micropayments on Base L2 via x402. ERC-8004 agent identity. No accounts required.

## Install

```bash
pip install pathcourse-sdk
```

## Quick Start

```python
from pathcourse import PathCourseClient, PCH_FAST, PCH_PRO

client = PathCourseClient(api_key="your-pch-api-key")

response = client.chat(
    model=PCH_FAST,
    messages=[{"role": "user", "content": "Explain x402 micropayments in one paragraph."}]
)
print(response.text)
```

## Embeddings

```python
from pathcourse import PathCourseClient, PCH_EMBED

client = PathCourseClient(api_key="your-pch-api-key")
result = client.embed("The quick brown fox jumps over the lazy dog.")
print(f"Embedding dimension: {len(result.embeddings[0])}")
```

## Translation

```python
result = client.translate("Bonjour le monde", target_language="en")
print(result["translated_text"])  # "Hello world"
```

## Models

| Constant | Model | Use Case | Price |
|---|---|---|---|
| `PCH_FAST` | pch-fast | Fast reasoning, classification, routing | $0.44/M tokens |
| `PCH_PRO` | pch-pro | Deep reasoning, multi-step planning | $1.96/M tokens |
| `PCH_CODER` | pch-coder | Code generation, debugging | $3.50/M tokens |
| `PCH_IMAGE` | pch-image | Text-to-image generation | $0.028/image |
| `PCH_AUDIO` | pch-audio | Text-to-speech (standard) | $1.85/M chars |
| `PCH_AUDIO_PREMIUM` | pch-audio-premium | Text-to-speech (premium) | $37.00/M chars |
| `PCH_DOCUMENTS` | pch-documents | Document parsing, OCR | $0.26/$1.48 per M tokens |
| `PCH_TALK` | pch-talk | Voice conversation | $0.001/min |
| `CLAUDE_HAIKU` | claude-haiku | Third-party (Silver+ tier) | Markup over provider cost |
| `CLAUDE_SONNET` | claude-sonnet | Third-party (Gold tier) | Markup over provider cost |
| `PCH_EMBED` | pch-embed | Text embeddings | $0.015/M tokens |
| `PCH_TRANSCRIBE` | pch-transcribe | Speech-to-text | $0.0008/min |
| `PCH_TRANSLATE` | pch-translate | Translation (109 languages) | $0.08/M chars |
| `PCH_EXTRACT` | pch-extract | Named entity extraction (zero-shot) | $0.012/M tokens |
| `PCH_RERANK` | pch-rerank | Retrieval reranking | $0.025/M tokens |

## Environment Variables

- `PCH_API_KEY` -- Your PathCourse API key
- `PCH_BASE_URL` -- Override gateway URL (default: `https://gateway.pathcoursehealth.com`)

## Settlement

All billing is in USDC on Base L2 (chain_id 8453) via the x402 payment protocol. Deposit USDC to the PCH treasury wallet to receive an API key. No accounts, no credit cards, no KYC.

## Links

- [PathCourse Platform](https://pathcoursehealth.com)
- [API Documentation](https://gateway.pathcoursehealth.com/docs)
- [Agent Card](https://gateway.pathcoursehealth.com/.well-known/agent.json)
- [GitHub](https://github.com/pathcourse-health/pathcourse-sdk)
