# mi_crypto_lib 

Biblioteca educativa de criptografía desarrollada en Python puro (sin dependencias externas).

## Estructura

```
mi_crypto_lib/
├── __init__.py                  # Fachada: import mi_crypto_lib as cripto
│
├── teoria_numeros/              # Ejercicios 1–4: Teoría de números
│   ├── __init__.py
│   ├── utilidades.py            # mcd, es_primo, phi, factorizar_entero (compartido)
│   ├── crr.py                   # Ej 1: Conjunto Reducido de Residuos
│   ├── ejercicio_rsa_base.py    # Ej 2: Primos seguros para RSA
│   ├── n_generico.py            # Ej 3: Factorización y φ(n) genérico
│   └── inversos.py              # Ej 4: Inversos multiplicativos (Euler / Euclides ext.)
│
├── cifrados_clasicos/           # Ejercicios 5–6: Cifrados y criptoanálisis
│   ├── __init__.py
│   ├── auto_clave.py            # Ej 5: Cifrado Autoclave (Vigenère clave continua) + Kasiski
│   └── ataque_hill.py           # Ej 6: Cifrado Hill + ataque Gauss-Jordan
│
├── setup.py
├── pyproject.toml
├── README.md
└── LICENSE
```

## Instalación

```bash
# Desde el directorio raíz del proyecto:
pip install -e .
```

## Uso rápido

La librería expone **todas** las funciones con un solo import:

```python
import mi_crypto_lib as cripto

# ── Ej 1: Conjunto Reducido de Residuos ──
print(cripto.calcular_crr(10))       # [1, 3, 7, 9]
print(cripto.phi(10))                # 4

# ── Ej 2: Primos seguros (RSA) ──
p = cripto.generar_primo_seguro(10)  # 11

# ── Ej 3: Factorización genérica ──
print(cripto.factorizar(60))         # {2: 2, 3: 1, 5: 1}
print(cripto.euler_phi(60))          # 16

# ── Ej 4: Inversos multiplicativos ──
print(cripto.inverso_euler(3, 26))       # {'inverso': 9, ...}
print(cripto.inverso_extendido(3, 26))   # {'inverso': 9, ...}

# ── Ej 5: Cifrado Autoclave + Kasiski ──
cifrado = cripto.cifrar_autoclave("HOLAMUNDO", "KEY")
plano   = cripto.descifrar_autoclave(cifrado, "KEY")
analisis = cripto.kasiski(cifrado)

# ── Ej 6: Ataque Hill (Gauss-Jordan) ──
clave = cripto.CifradoMatriz.recuperar_clave("TEXTO", "CIFRA", 2)
```

## Requisitos

- Python ≥ 3.8
- Sin dependencias externas (solo librería estándar)

## Licencia

MIT License — ver [LICENSE](LICENSE)
