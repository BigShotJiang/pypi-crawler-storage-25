"""
cifrados_clasicos — Cifrados clásicos y criptoanálisis
=======================================================

Módulos:
    5. auto_clave   : Cifrado Autoclave (Vigenère clave continua) + Kasiski
    6. ataque_hill  : Cifrado Hill + ataque Gauss-Jordan
"""

# 5. Autoclave
from .auto_clave import cifrar_autoclave, descifrar_autoclave, kasiski

# 6. Ataque Hill
from .ataque_hill import Matriz, CifradoMatriz
