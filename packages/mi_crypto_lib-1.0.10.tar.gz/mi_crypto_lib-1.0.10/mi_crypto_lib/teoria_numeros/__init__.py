"""
teoria_numeros — Herramientas de teoría de números para criptografía
====================================================================

Funciones:
    1. CRR              : crr, phi
    2. RSA              : generar_primo_seguro
    3. n Genérico       : factorizar, euler_phi
    4. Inversos         : inverso_euler, inverso_extendido
"""

# Utilidades base
from .utilidades import mcd, phi, es_primo

# 1. CRR
from .crr import crr

# 2. RSA
from .ejercicio_rsa_base import generar_primo_seguro

# 3. n Genérico
from .n_generico import factorizar, euler_phi

# 4. Inversos Multiplicativos
from .inversos import inverso_euler, inverso_multiplicativo as inverso_extendido
