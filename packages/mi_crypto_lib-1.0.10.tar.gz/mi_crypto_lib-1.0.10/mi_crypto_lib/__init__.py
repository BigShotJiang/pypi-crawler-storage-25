"""
mi_crypto_lib — Biblioteca de criptografía educativa
=====================================================

Módulos disponibles:
    - teoria_numeros    : φ de Euler, CRR, inversos, primos seguros, factorización
    - cifrados_clasicos : Autoclave (Vigenère clave continua), Hill + Gauss-Jordan
"""

__version__ = "1.0.10"
__author__ = "Raúl"

# Exponemos las funciones principales — fachada única

# 1. CRR
from .teoria_numeros import crr as calcular_crr, phi
# 2. RSA
from .teoria_numeros import generar_primo_seguro
# 3. n Genérico
from .teoria_numeros import factorizar, euler_phi
# 4. Inversos Multiplicativos
from .teoria_numeros import inverso_euler, inverso_extendido
# 5. Autoclave
from .cifrados_clasicos import cifrar_autoclave, descifrar_autoclave, kasiski
# 6. Ataque Hill (Gauss-Jordan)
from .cifrados_clasicos import Matriz, CifradoMatriz
