# Third-Party Notices

## Laravel Boost

Python Pop is heavily inspired by Laravel Boost's agent-aware framework tooling model, install flow, and polished CLI presentation.

Laravel Boost package metadata declares the package license as MIT:

- Package: `laravel/boost`
- Homepage: `https://github.com/laravel/boost`
- License: `MIT`

While Python Pop draws inspiration from Laravel Boost, it does not import Laravel Boost source files or assets directly. Python Pop's implementation and package assets are authored for Python projects and distributed under Apache-2.0 licensing.
