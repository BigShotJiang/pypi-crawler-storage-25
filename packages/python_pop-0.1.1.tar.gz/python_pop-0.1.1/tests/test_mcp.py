from __future__ import annotations

import json
import os
import tempfile
import unittest
from unittest.mock import patch

from python_pop.mcp.server import StdioMcpServer
from python_pop.mcp.tool_registry import ToolRegistry
from python_pop.support.security import INSPECTION_ALLOWED_ROOT_ENV
from tests import FIXTURES


FIXTURE = FIXTURES / "sample_flask_app"
DJANGO_FIXTURE = FIXTURES / "sample_django_project"


class McpTests(unittest.TestCase):
    def test_tool_registry_contains_expected_tools(self) -> None:
        names = ToolRegistry().names()
        self.assertIn("inspect_project", names)
        self.assertIn("inspect_django_project", names)
        self.assertIn("list_modules", names)
        self.assertIn("list_flask_routes", names)
        self.assertIn("list_flask_blueprints", names)
        self.assertIn("list_flask_extensions", names)
        self.assertIn("inspect_flask_config", names)
        self.assertIn("list_django_routes", names)
        self.assertIn("list_django_management_commands", names)

    def test_server_handles_initialize_and_tool_call(self) -> None:
        server = StdioMcpServer()
        initialize = server._handle_message({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        self.assertEqual(initialize["result"]["serverInfo"]["name"], "python-pop")

        tool_call = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/call",
                "params": {"name": "inspect_project", "arguments": {"project_root": str(FIXTURE)}},
            }
        )
        self.assertEqual(tool_call["result"]["isError"], False)
        text = tool_call["result"]["content"][0]["text"]
        payload = json.loads(text)
        self.assertEqual(payload["framework"], "flask")

    def test_server_returns_extended_flask_tool_results(self) -> None:
        server = StdioMcpServer()

        blueprints = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "tools/call",
                "params": {"name": "list_flask_blueprints", "arguments": {"project_root": str(FIXTURE)}},
            }
        )
        extensions = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 5,
                "method": "tools/call",
                "params": {"name": "list_flask_extensions", "arguments": {"project_root": str(FIXTURE)}},
            }
        )
        config = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 6,
                "method": "tools/call",
                "params": {"name": "inspect_flask_config", "arguments": {"project_root": str(FIXTURE)}},
            }
        )

        blueprint_payload = json.loads(blueprints["result"]["content"][0]["text"])
        extension_payload = json.loads(extensions["result"]["content"][0]["text"])
        config_payload = json.loads(config["result"]["content"][0]["text"])

        self.assertEqual(blueprint_payload["blueprints"][0]["name"], "api")
        self.assertTrue(any(item["class_name"] == "SQLAlchemy" for item in extension_payload["extensions"]))
        self.assertIn("JWT_SECRET_KEY", config_payload["config_keys"])

    def test_server_returns_django_tool_results(self) -> None:
        server = StdioMcpServer()
        inspect_response = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 7,
                "method": "tools/call",
                "params": {"name": "inspect_django_project", "arguments": {"project_root": str(DJANGO_FIXTURE)}},
            }
        )
        routes_response = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 8,
                "method": "tools/call",
                "params": {"name": "list_django_routes", "arguments": {"project_root": str(DJANGO_FIXTURE)}},
            }
        )
        commands_response = server._handle_message(
            {
                "jsonrpc": "2.0",
                "id": 9,
                "method": "tools/call",
                "params": {"name": "list_django_management_commands", "arguments": {"project_root": str(DJANGO_FIXTURE)}},
            }
        )

        inspect_payload = json.loads(inspect_response["result"]["content"][0]["text"])
        routes_payload = json.loads(routes_response["result"]["content"][0]["text"])
        commands_payload = json.loads(commands_response["result"]["content"][0]["text"])

        self.assertEqual(inspect_payload["framework"], "django")
        self.assertTrue(any(route["pattern"] == "api/" for route in routes_payload["routes"]))
        self.assertTrue(any(command["name"] == "reindex_posts" for command in commands_payload["commands"]))

    def test_server_returns_protocol_error_for_invalid_json_line(self) -> None:
        server = StdioMcpServer()
        payload = server._handle_line("{invalid")

        self.assertEqual(payload["error"]["message"], "Invalid JSON payload.")

    def test_server_rejects_project_root_outside_allowed_boundary(self) -> None:
        server = StdioMcpServer()
        with tempfile.TemporaryDirectory() as tmpdir:
            boundary = str(FIXTURE)
            outside = tmpdir
            with patch.dict(os.environ, {INSPECTION_ALLOWED_ROOT_ENV: boundary}, clear=False):
                response = server._handle_message(
                    {
                        "jsonrpc": "2.0",
                        "id": 3,
                        "method": "tools/call",
                        "params": {"name": "inspect_project", "arguments": {"project_root": outside}},
                    }
                )

        self.assertIn("error", response)
        self.assertIn("must stay within", response["error"]["message"])


if __name__ == "__main__":
    unittest.main()
