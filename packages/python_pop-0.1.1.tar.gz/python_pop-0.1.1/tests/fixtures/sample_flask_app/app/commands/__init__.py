from app import app


@app.cli.command("example")
def example():
    return None

