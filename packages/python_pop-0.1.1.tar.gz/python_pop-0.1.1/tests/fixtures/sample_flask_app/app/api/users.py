from app.api import api


@api.route("/users", methods=["GET"])
def list_users():
    return {"users": []}

