from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from flask.json.provider import DefaultJSONProvider
from flask_mail import Mail
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

from app.api import api


class CustomJsonProvider(DefaultJSONProvider):
    pass


db = SQLAlchemy()
jwt = JWTManager()
mail = Mail()
migrate = Migrate()

app = Flask(__name__)
app.json = CustomJsonProvider(app)
app.config["JWT_SECRET_KEY"] = "development-secret"
app.config.from_mapping(
    SQLALCHEMY_DATABASE_URI="sqlite://",
    MAIL_DEFAULT_SENDER="noreply@example.com",
)
app.config.from_envvar("APP_SETTINGS", silent=True)
db.init_app(app)
jwt.init_app(app)
mail.init_app(app)
migrate.init_app(app, db)
CORS(app)
app.register_blueprint(api)
