# Blog app fixture for Django tests.
