from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Reindex blog posts."

    def handle(self, *args, **options):
        return None
