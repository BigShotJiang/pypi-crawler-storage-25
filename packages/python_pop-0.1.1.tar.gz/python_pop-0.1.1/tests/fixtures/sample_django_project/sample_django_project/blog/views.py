from django.http import HttpResponse, JsonResponse


def home(request):
    return HttpResponse("home")


def user_list(request):
    return JsonResponse({"users": []})
