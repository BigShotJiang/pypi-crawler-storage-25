# Management package fixture.
