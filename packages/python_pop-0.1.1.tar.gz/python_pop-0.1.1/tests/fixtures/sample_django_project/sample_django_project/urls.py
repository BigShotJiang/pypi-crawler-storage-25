from django.urls import include, path

from sample_django_project.blog import views


urlpatterns = [
    path("", views.home, name="home"),
    path("api/", include("sample_django_project.api_urls")),
]
