# Sample Django project fixture for Python Pop tests.
