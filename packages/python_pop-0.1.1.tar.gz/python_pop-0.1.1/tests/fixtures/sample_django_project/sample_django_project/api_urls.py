from django.urls import path

from sample_django_project.blog import views


urlpatterns = [
    path("users/", views.user_list, name="user-list"),
]
