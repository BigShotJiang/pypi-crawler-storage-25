from __future__ import annotations

import json
import io
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
import shutil
import unittest

from python_pop.console.install import execute_install
from python_pop.console.main import main
from python_pop.frameworks.detector import inspect_project
from python_pop.install.agents.codex import Codex
from python_pop.install.guideline_composer import GuidelineComposer
from python_pop.install.guideline_writer import GuidelineWriter
from python_pop.install.skill_composer import SkillComposer
from python_pop.install.skill_writer import SkillWriter
from python_pop.support.config import ConfigStore, PythonPopConfig
from python_pop.support.security import INSPECTION_ALLOWED_ROOT_ENV
from tests import FIXTURES


FIXTURE = FIXTURES / "sample_flask_app"


class InstallTests(unittest.TestCase):
    def test_config_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = ConfigStore(tmpdir)
            store.save(
                PythonPopConfig(
                    agents=["codex"],
                    framework="flask",
                    guidelines=True,
                    mcp=True,
                    packages=["demo-module"],
                    skills=["flask-development"],
                )
            )

            payload = json.loads((Path(tmpdir) / "python-pop.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["framework"], "flask")
            self.assertEqual(store.load().skills, ["flask-development"])

    def test_guideline_writer_updates_agent_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            shutil.copytree(FIXTURE, project_root)
            inspection = inspect_project(project_root)
            composed = GuidelineComposer(inspection).compose()
            writer = GuidelineWriter(Codex())
            writer.write(project_root, composed.content)
            content = (project_root / "AGENTS.md").read_text(encoding="utf-8")

            self.assertIn("<python-pop-guidelines>", content)
            self.assertIn("Flask", content)

    def test_skill_writer_syncs_builtin_skills(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            shutil.copytree(FIXTURE, project_root)
            inspection = inspect_project(project_root)
            skills = SkillComposer(inspection).skills()
            SkillWriter(Codex()).sync(project_root, skills, [])

            self.assertTrue((project_root / ".agents/skills/flask-development/SKILL.md").exists())
            self.assertTrue((project_root / ".agents/skills/python-best-practices/SKILL.md").exists())

    def test_codex_mcp_config_is_written(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()
            agent = Codex()
            agent.install_mcp(
                project_root,
                "python-pop",
                "python",
                ["-m", "python_pop", "mcp"],
                {INSPECTION_ALLOWED_ROOT_ENV: str(project_root)},
            )
            content = (project_root / ".codex/config.toml").read_text(encoding="utf-8")

            self.assertIn("[mcp_servers.python-pop]", content)
            self.assertIn('command = "python"', content)
            self.assertIn(INSPECTION_ALLOWED_ROOT_ENV, content)

    def test_install_writes_portable_mcp_launcher_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            project_root.mkdir()

            execute_install(
                project_root=project_root,
                guidelines_enabled=False,
                skills_enabled=False,
                mcp_enabled=True,
                include_planned=False,
                force=False,
                dry_run=False,
                agents=[Codex()],
                selected_packages=[],
            )

            content = (project_root / ".codex/config.toml").read_text(encoding="utf-8")
            self.assertTrue((project_root / ".python-pop/mcp-launcher.py").exists())
            self.assertIn('command = "python3"', content)
            self.assertIn('args = [".python-pop/mcp-launcher.py"]', content)
            self.assertIn('cwd = "."', content)
            self.assertIn(f'{INSPECTION_ALLOWED_ROOT_ENV} = "."', content)
            self.assertNotIn(str(project_root), content)

    def test_fresh_install_defaults_to_opencode_and_claude(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            shutil.copytree(FIXTURE, project_root)

            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "install",
                        "--project-root",
                        str(project_root),
                        "--dry-run",
                        "--no-interaction",
                    ]
                )

            self.assertEqual(exit_code, 0, msg=output.getvalue())
            text = output.getvalue()
            self.assertIn("AGENTS.md", text)
            self.assertIn("CLAUDE.md", text)
            self.assertIn("opencode.json", text)
            self.assertIn(".mcp.json", text)
            self.assertNotIn(".codex/config.toml", text)

    def test_non_interactive_install_requires_force_for_multi_framework_projects(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            (project_root / "app").mkdir(parents=True)
            (project_root / "requirements.txt").write_text("Flask==2.3.3\ndjango==4.2.0\n", encoding="utf-8")
            (project_root / "app" / "__init__.py").write_text(
                "from flask import Flask\nfrom django.http import HttpResponse\napp = Flask(__name__)\n",
                encoding="utf-8",
            )

            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "install",
                        "--project-root",
                        str(project_root),
                        "--agent",
                        "codex",
                        "--guidelines",
                        "--no-interaction",
                    ]
                )

            self.assertEqual(exit_code, 1)
            self.assertIn("Multiple Python frameworks were detected", output.getvalue())
            self.assertFalse((project_root / "python-pop.json").exists())

    def test_force_allows_non_interactive_multi_framework_install(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            (project_root / "app").mkdir(parents=True)
            (project_root / "requirements.txt").write_text("Flask==2.3.3\ndjango==4.2.0\n", encoding="utf-8")
            (project_root / "app" / "__init__.py").write_text(
                "from flask import Flask\nfrom django.http import HttpResponse\napp = Flask(__name__)\n",
                encoding="utf-8",
            )

            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "install",
                        "--project-root",
                        str(project_root),
                        "--agent",
                        "codex",
                        "--guidelines",
                        "--no-interaction",
                        "--force",
                    ]
                )

            self.assertEqual(exit_code, 0, msg=output.getvalue())
            payload = json.loads((project_root / "python-pop.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["framework"], "flask")
            self.assertEqual(payload["frameworks"], ["flask", "django"])


if __name__ == "__main__":
    unittest.main()
