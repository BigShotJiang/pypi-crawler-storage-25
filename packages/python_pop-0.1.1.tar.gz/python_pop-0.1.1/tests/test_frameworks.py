from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from python_pop.frameworks.base import FrameworkModule, ModuleAsset, ModuleSelection
from python_pop.frameworks.detector import inspect_project
from python_pop.install.guideline_composer import GuidelineComposer
from python_pop.install.skill_composer import SkillComposer
from tests import FIXTURES


FIXTURE = FIXTURES / "sample_flask_app"
DJANGO_FIXTURE = FIXTURES / "sample_django_project"


FRAMEWORK_SOURCES = {
    "django": "from django.http import HttpResponse\n",
    "fastapi": "from fastapi import FastAPI\napp = FastAPI()\n",
    "flask": "from flask import Flask\napp = Flask(__name__)\n",
    "masonite": "from masonite.routes import Route\n",
}


def _write_virtualenv_framework_sources(root: Path, excluded_frameworks: list[str]) -> None:
    site_packages = root / "Envs" / "python-pop" / "lib" / "python3.13" / "site-packages"
    site_packages.mkdir(parents=True)
    (root / "Envs" / "python-pop" / "pyvenv.cfg").write_text("home = /usr/bin\n", encoding="utf-8")
    for framework in excluded_frameworks:
        package_root = site_packages / framework
        package_root.mkdir(parents=True)
        (package_root / "__init__.py").write_text(FRAMEWORK_SOURCES[framework], encoding="utf-8")


class FrameworkDetectionTests(unittest.TestCase):
    def test_detects_flask_modules_from_fixture(self) -> None:
        inspection = inspect_project(FIXTURE)
        module_slugs = [module.slug for module in inspection.modules]

        self.assertEqual(inspection.framework, "flask")
        self.assertIn("foundation", module_slugs)
        self.assertIn("python-pop", module_slugs)
        self.assertIn("python", module_slugs)
        self.assertIn("flask", module_slugs)
        self.assertIn("flask-sqlalchemy", module_slugs)
        self.assertIn("sqlalchemy", module_slugs)
        self.assertIn("pytest", module_slugs)

    def test_detector_ignores_virtualenv_sources_for_all_frameworks(self) -> None:
        scenarios = [
            ("django", "django==4.2.0\n", "project/settings.py"),
            ("fastapi", "fastapi==0.110.0\n", "app/main.py"),
            ("flask", "Flask==2.3.3\npytest==8.0.0\n", "app/__init__.py"),
            ("masonite", "masonite==4.20.0\n", "app/__init__.py"),
        ]

        for expected, requirements, source_path in scenarios:
            with self.subTest(expected=expected):
                with tempfile.TemporaryDirectory() as tmpdir:
                    root = Path(tmpdir) / "project"
                    app_file = root / source_path
                    app_file.parent.mkdir(parents=True)
                    app_file.write_text(FRAMEWORK_SOURCES[expected], encoding="utf-8")
                    (root / "requirements.txt").write_text(requirements, encoding="utf-8")
                    _write_virtualenv_framework_sources(
                        root,
                        [framework for framework in FRAMEWORK_SOURCES if framework != expected],
                    )

                    inspection = inspect_project(root)
                    module_slugs = [module.slug for module in inspection.modules]

                    self.assertEqual(inspection.framework, expected)
                    self.assertIn(expected, module_slugs)
                    for unexpected in FRAMEWORK_SOURCES:
                        if unexpected != expected:
                            self.assertNotIn(unexpected, module_slugs)

    def test_detects_rich_django_modules_from_fixture(self) -> None:
        inspection = inspect_project(DJANGO_FIXTURE)
        module_slugs = [module.slug for module in inspection.modules]

        self.assertEqual(inspection.framework, "django")
        self.assertEqual(inspection.application_style, "Django project with manage.py entrypoint and settings module")
        self.assertIn("django", module_slugs)
        self.assertIn("django-rest-framework", module_slugs)
        self.assertIn("pytest-django", module_slugs)
        self.assertIn("pytest", module_slugs)

    def test_composes_django_guidelines_and_skills(self) -> None:
        inspection = inspect_project(DJANGO_FIXTURE)
        guidelines = GuidelineComposer(inspection).compose().content
        skills = SkillComposer(inspection).skills()

        self.assertIn("Django 4.2", guidelines)
        self.assertIn("Django REST Framework", guidelines)
        self.assertIn("django-development", skills)

    def test_detects_stub_frameworks(self) -> None:
        scenarios = [
            ("django", "from django.http import HttpResponse\n"),
            ("fastapi", "from fastapi import FastAPI\napp = FastAPI()\n"),
            ("masonite", "from masonite.routes import Route\n"),
        ]

        for expected, source in scenarios:
            with self.subTest(expected=expected):
                with tempfile.TemporaryDirectory() as tmpdir:
                    root = Path(tmpdir) / "project"
                    (root / "app").mkdir(parents=True)
                    (root / "requirements.txt").write_text(f"{expected}==1.0.0\n", encoding="utf-8")
                    (root / "app" / "__init__.py").write_text(source, encoding="utf-8")
                    inspection = inspect_project(root)
                    self.assertEqual(inspection.framework, expected)

    def test_planned_guideline_assets_are_excluded_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "project"
            (root / "app").mkdir(parents=True)
            (root / "requirements.txt").write_text("Flask==3.0.2\n", encoding="utf-8")
            (root / "app" / "__init__.py").write_text("from flask import Flask\napp = Flask(__name__)\n", encoding="utf-8")
            inspection = inspect_project(root)
            default_guidelines = GuidelineComposer(inspection).compose().content
            planned_guidelines = GuidelineComposer(inspection, include_planned=True).compose().content

            self.assertNotIn("Flask 3 Placeholder", default_guidelines)
            self.assertIn("Flask 3 Placeholder", planned_guidelines)

    def test_selected_external_entry_point_module_is_composed(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "project"
            asset = Path(tmpdir) / "external-guideline.md"
            asset.write_text("# External Module\n\nLoaded from an entry point.\n", encoding="utf-8")
            (root / "app").mkdir(parents=True)
            (root / "requirements.txt").write_text("Flask==2.3.2\n", encoding="utf-8")
            (root / "app" / "__init__.py").write_text("from flask import Flask\napp = Flask(__name__)\n", encoding="utf-8")

            @dataclass
            class DemoExternalModule(FrameworkModule):
                slug: str = "demo-external"
                display_name: str = "Demo External"
                category: str = "package"
                source: str = "external"

                def matches(self, project) -> bool:
                    return True

                def select(self, project) -> ModuleSelection | None:
                    return ModuleSelection(
                        slug=self.slug,
                        display_name=self.display_name,
                        category=self.category,
                        source=self.source,
                        assets=(ModuleAsset(str(asset)),),
                    )

            entry_point = SimpleNamespace(load=lambda: DemoExternalModule)
            with patch("python_pop.frameworks.registry._load_entry_points", return_value=[entry_point]):
                inspection = inspect_project(root, selected_external=["demo-external"])
                guidelines = GuidelineComposer(inspection).compose()

            self.assertIn("demo-external", [module.slug for module in inspection.modules])
            self.assertIn("Loaded from an entry point.", guidelines.content)


if __name__ == "__main__":
    unittest.main()
