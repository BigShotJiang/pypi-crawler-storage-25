from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from python_pop.skills.remote import GitHubRepository, GitHubSkillProvider, SkillAuditor


class _FakeResponse:
    def __init__(self, payload: bytes):
        self.payload = payload

    def read(self) -> bytes:
        return self.payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class RemoteSkillTests(unittest.TestCase):
    def test_github_repository_parsing(self) -> None:
        repo = GitHubRepository.from_input("https://github.com/acme/demo/skills")
        self.assertEqual(repo.owner, "acme")
        self.assertEqual(repo.repo, "demo")
        self.assertEqual(repo.path, "skills")

    def test_provider_discovers_and_downloads_skills(self) -> None:
        resolved_ref = "abc123def456"
        responses = [
            json.dumps({"default_branch": "trunk"}).encode("utf-8"),
            json.dumps({"commit": {"sha": resolved_ref}}).encode("utf-8"),
            json.dumps(
                {
                    "tree": [
                        {"path": "skills/debug-helper/SKILL.md", "type": "blob"},
                        {"path": "skills/debug-helper/rules.txt", "type": "blob"},
                    ]
                }
            ).encode("utf-8"),
            b"---\nname: debug-helper\ndescription: Debug helper\n---\n\n# Debug Helper\n",
            b"rules",
        ]
        requested_urls: list[str] = []

        def fake_urlopen(request_obj, timeout=30):  # noqa: ARG001
            requested_urls.append(request_obj.full_url)
            return _FakeResponse(responses.pop(0))

        provider = GitHubSkillProvider(GitHubRepository("acme", "demo", "skills"))
        with patch("python_pop.skills.remote.github_skill_provider.request.urlopen", side_effect=fake_urlopen):
            skills = provider.discover_skills()
            self.assertIn("debug-helper", skills)
            with tempfile.TemporaryDirectory() as tmpdir:
                target = Path(tmpdir) / "debug-helper"
                self.assertTrue(provider.download_skill(skills["debug-helper"], target))
                self.assertTrue((target / "SKILL.md").exists())
                provenance = json.loads((target / provider.PROVENANCE_FILE).read_text(encoding="utf-8"))
                self.assertEqual(provenance["ref"], resolved_ref)

        self.assertIn(f"/branches/trunk", "\n".join(requested_urls))
        self.assertIn(f"/git/trees/{resolved_ref}?recursive=1", "\n".join(requested_urls))
        self.assertIn(f"/{resolved_ref}/skills/debug-helper/SKILL.md", "\n".join(requested_urls))

    def test_skill_auditor_rejects_invalid_skill(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "Bad Skill"
            root.mkdir()
            (root / "SKILL.md").write_text("# missing frontmatter\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                SkillAuditor().audit_directory(root)

    def test_skill_auditor_rejects_binary_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "debug-helper"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: debug-helper\n---\n", encoding="utf-8")
            (root / "payload.bin").write_bytes(b"\x00\x01unsafe")
            with self.assertRaises(ValueError):
                SkillAuditor().audit_directory(root)

    def test_skill_auditor_rejects_oversized_content(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "debug-helper"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: debug-helper\n---\n", encoding="utf-8")
            (root / "notes.txt").write_text("a" * (SkillAuditor.MAX_FILE_BYTES + 1), encoding="utf-8")
            with self.assertRaises(ValueError):
                SkillAuditor().audit_directory(root)

    def test_skill_auditor_rejects_symlinks(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "debug-helper"
            root.mkdir()
            (root / "SKILL.md").write_text("---\nname: debug-helper\n---\n", encoding="utf-8")
            target = Path(tmpdir) / "external.txt"
            target.write_text("external", encoding="utf-8")
            os.symlink(target, root / "external.txt")
            with self.assertRaises(ValueError):
                SkillAuditor().audit_directory(root)

    def test_provider_rejects_path_escape(self) -> None:
        responses = [
            json.dumps({"default_branch": "trunk"}).encode("utf-8"),
            json.dumps({"commit": {"sha": "abc123def456"}}).encode("utf-8"),
            json.dumps(
                {
                    "tree": [
                        {"path": "skills/debug-helper/SKILL.md", "type": "blob"},
                        {"path": "skills/debug-helper/../../escape.txt", "type": "blob"},
                    ]
                }
            ).encode("utf-8"),
            b"---\nname: debug-helper\ndescription: Debug helper\n---\n\n# Debug Helper\n",
        ]

        def fake_urlopen(request_obj, timeout=30):  # noqa: ARG001
            return _FakeResponse(responses.pop(0))

        provider = GitHubSkillProvider(GitHubRepository("acme", "demo", "skills"))
        with patch("python_pop.skills.remote.github_skill_provider.request.urlopen", side_effect=fake_urlopen):
            skills = provider.discover_skills()
            with tempfile.TemporaryDirectory() as tmpdir:
                with self.assertRaises(ValueError):
                    provider.download_skill(skills["debug-helper"], Path(tmpdir) / "debug-helper")


if __name__ == "__main__":
    unittest.main()
