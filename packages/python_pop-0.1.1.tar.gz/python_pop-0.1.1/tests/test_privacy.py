from __future__ import annotations

from pathlib import Path
import re
import unittest

from tests import ROOT


LOCAL_PRIVACY_FILE = ROOT / "tests" / "privacy" / "local-privacy.txt"
COMMON_PRIVATE_PATTERNS = [
    re.compile(r"/Users/[A-Za-z0-9._-]+/(?!code/python pop\b)"),
    re.compile(r"/home/[A-Za-z0-9._-]+/"),
    re.compile(r"/mnt/c/Users/[A-Za-z0-9._-]+/"),
    re.compile(r"[A-Za-z]:\\Users\\[A-Za-z0-9._-]+\\"),
]
SEARCH_ROOTS = [
    ROOT / ".ai",
    ROOT / "docs",
    ROOT / "src" / "python_pop",
    ROOT / "CHANGELOG.md",
    ROOT / "README.md",
    ROOT / "THIRD_PARTY_NOTICES.md",
    ROOT / "pyproject.toml",
    ROOT / "MANIFEST.in",
    ROOT / "setup.py",
]
TEXT_SUFFIXES = {".py", ".md", ".toml", ".json", ".yml", ".yaml", ".txt"}


def _iter_search_files() -> list[Path]:
    files: list[Path] = []
    for entry in SEARCH_ROOTS:
        if entry.is_file():
            files.append(entry)
            continue
        for path in entry.rglob("*"):
            if path.is_file() and path.suffix in TEXT_SUFFIXES:
                files.append(path)
    return files


def _load_local_forbidden_strings() -> list[str]:
    if not LOCAL_PRIVACY_FILE.exists():
        return []
    values = []
    for line in LOCAL_PRIVACY_FILE.read_text(encoding="utf-8").splitlines():
        value = line.strip()
        if value and not value.startswith("#"):
            values.append(value)
    return values


class PrivacyTests(unittest.TestCase):
    def test_no_common_local_paths_are_shipped(self) -> None:
        for path in _iter_search_files():
            content = path.read_text(encoding="utf-8")
            for pattern in COMMON_PRIVATE_PATTERNS:
                with self.subTest(path=path.relative_to(ROOT), pattern=pattern.pattern):
                    self.assertIsNone(pattern.search(content))

    def test_no_local_privacy_strings_are_shipped(self) -> None:
        forbidden = _load_local_forbidden_strings()
        if not forbidden:
            self.skipTest("No local privacy denylist configured.")
        corpus = "\n".join(path.read_text(encoding="utf-8") for path in _iter_search_files())
        for needle in forbidden:
            with self.subTest(needle=needle):
                self.assertNotIn(needle, corpus)


if __name__ == "__main__":
    unittest.main()
