from __future__ import annotations

import os
from pathlib import Path
import tempfile
import unittest

from python_pop.frameworks.detector import inspect_project
from python_pop.python_pop_manager import PythonPopManager


class SecurityTests(unittest.TestCase):
    def test_builtin_agents_use_structured_binary_detection(self) -> None:
        manager = PythonPopManager()
        for agent_class in manager.get_agents().values():
            config = agent_class().system_detection_config()
            self.assertNotIn("command", config)
            self.assertTrue(any(key in config for key in ("binary", "binaries", "paths")))

    def test_inspection_skips_symlinked_python_sources(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_root = Path(tmpdir)
            project_root = tmp_root / "project"
            external_root = tmp_root / "external"
            project_root.mkdir()
            external_root.mkdir()

            (external_root / "linked_app.py").write_text("from flask import Flask\napp = Flask(__name__)\n", encoding="utf-8")
            os.symlink(external_root / "linked_app.py", project_root / "linked_app.py")

            inspection = inspect_project(project_root)
            self.assertIsNone(inspection.framework)


if __name__ == "__main__":
    unittest.main()
