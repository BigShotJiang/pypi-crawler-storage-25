from __future__ import annotations

import base64
import io
import json
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
import unittest

from python_pop.console.main import main
from tests import FIXTURES


FIXTURE = FIXTURES / "sample_flask_app"
DJANGO_FIXTURE = FIXTURES / "sample_django_project"


class CliTests(unittest.TestCase):
    def test_inspect_json_outputs_framework_and_modules(self) -> None:
        output = io.StringIO()
        with redirect_stdout(output):
            exit_code = main(["inspect", "--project-root", str(FIXTURE), "--json"])

        self.assertEqual(exit_code, 0, msg=output.getvalue())
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["project_name"], "sample_flask_app")
        self.assertEqual(payload["framework"], "flask")
        self.assertTrue(any(module["slug"] == "flask" for module in payload["modules"]))

    def test_inspect_json_outputs_django_modules(self) -> None:
        output = io.StringIO()
        with redirect_stdout(output):
            exit_code = main(["inspect", "--project-root", str(DJANGO_FIXTURE), "--json"])

        self.assertEqual(exit_code, 0, msg=output.getvalue())
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["framework"], "django")
        self.assertTrue(any(module["slug"] == "django-rest-framework" for module in payload["modules"]))

    def test_install_dry_run_lists_agent_outputs_and_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir) / "project"
            import shutil
            shutil.copytree(FIXTURE, project_root)
            output = io.StringIO()
            with redirect_stdout(output):
                exit_code = main(
                    [
                        "install",
                        "--project-root",
                        str(project_root),
                        "--agent",
                        "codex",
                        "--guidelines",
                        "--skills",
                        "--mcp",
                        "--dry-run",
                        "--no-interaction",
                    ]
                )

            self.assertEqual(exit_code, 0, msg=output.getvalue())
            text = output.getvalue()
            self.assertIn("Python Pop :: Install Preview :: Just Ship It", text)
            self.assertIn("Give project a Pop", text)
            self.assertIn("Summary", text)
            self.assertIn("Planned Writes", text)
            self.assertIn("AGENTS.md", text)
            self.assertIn(".agents/skills/flask-development", text)
            self.assertIn(".codex/config.toml", text)
            self.assertIn("python-pop.json", text)

    def test_execute_tool_outputs_json_payload(self) -> None:
        args = base64.b64encode(json.dumps({"project_root": str(FIXTURE)}).encode("utf-8")).decode("utf-8")
        output = io.StringIO()
        with redirect_stdout(output):
            exit_code = main(["execute-tool", "inspect_project", args])

        self.assertEqual(exit_code, 0, msg=output.getvalue())
        payload = json.loads(output.getvalue())
        self.assertFalse(payload["isError"])


if __name__ == "__main__":
    unittest.main()
