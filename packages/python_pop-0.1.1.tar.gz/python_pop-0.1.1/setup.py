from __future__ import annotations

from pathlib import Path
import shutil

from setuptools import setup
from setuptools.command.build_py import build_py as _build_py


class build_py(_build_py):
    def run(self) -> None:
        super().run()

        source = Path(__file__).resolve().parent / ".ai"
        if not source.exists():
            return

        target = Path(self.build_lib) / "python_pop" / "_vendor_ai" / ".ai"
        if target.exists():
            shutil.rmtree(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target)


setup(
    cmdclass={"build_py": build_py},
)
