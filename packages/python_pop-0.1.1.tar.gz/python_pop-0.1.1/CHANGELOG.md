# Changelog

Notable release history for `python pop` will be documented in this file.

This project follows Semantic Versioning. Breaking changes require a major version increment, new public features increment the minor version, and fixes or internal corrections increment the patch version.

## [0.1.1] - 2026-04-27

### Fixed

- Updated GitHub Actions workflow dependencies to Node 24-compatible action versions.

## [0.1.0] - 2026-04-27

Initial public release.

### Added

- Core AI tooling for Python framework inspection, install, update, MCP, and remote skill workflows.
- Rich Flask guidance and MCP support for routes, blueprints, CLI commands, config, and extensions.
- Rich Django guidance and read-only MCP support for project inspection, routes, and management commands.
- FastAPI and Masonite framework detection with expansion-ready stub module structure.
- Package-managed `.ai` asset tree, agent-aware install flow, and `python-pop.json` state management.
- Release workflow, changelog, publish checklist, and SemVer policy for the first public release.
- Apache-2.0 licensing, package metadata cleanup, and third-party attribution notes.
- Polished CLI install display and README logo assets.

### Security

- Hardened agent detection, remote skill auditing, and MCP filesystem boundaries.
- Added portable MCP launcher behavior for consumer repositories that install Python Pop in a project-local environment.
