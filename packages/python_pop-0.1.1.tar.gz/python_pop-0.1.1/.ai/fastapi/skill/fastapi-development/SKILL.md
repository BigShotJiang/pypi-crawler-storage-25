---
name: fastapi-development
description: Placeholder Python Pop guidance for working in FastAPI projects.
---

# FastAPI Development Placeholder

- Inspect routers, dependency functions, and model validation patterns before making changes.
- Treat this as starter guidance until richer FastAPI support lands.

