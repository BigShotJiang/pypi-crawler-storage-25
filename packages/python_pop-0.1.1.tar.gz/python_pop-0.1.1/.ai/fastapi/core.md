# FastAPI Placeholder

- Python Pop can detect FastAPI projects, but FastAPI-specific guidance is still a placeholder in this version.
- Preserve the project’s existing router, dependency-injection, and startup conventions while richer FastAPI guidance is developed.

