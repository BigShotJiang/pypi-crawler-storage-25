# Django 4.2

- Use Django 4.2-compatible APIs, settings names, and management command assumptions.
- Preserve the project’s current URL configuration, app registration, and startup flow unless the task is explicitly a migration.
- Avoid introducing Django 5-only behavior into a Django 4.2 codebase during routine feature work.
