# Django

- Follow the inspected Django project’s current app layout, settings organization, URL configuration style, and management command patterns.
- Keep view, serializer, form, and admin changes aligned with the project’s existing conventions instead of introducing a parallel architecture.
- Treat settings, middleware, authentication, and database configuration as regression-sensitive surfaces that need targeted validation.
