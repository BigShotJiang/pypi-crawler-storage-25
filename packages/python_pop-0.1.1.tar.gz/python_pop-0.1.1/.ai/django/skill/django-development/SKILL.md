---
name: django-development
description: Python Pop guidance for working in Django projects.
---

# Django Development

- Inspect the current app layout, settings modules, URL configuration, and management commands before making framework changes.
- Follow existing Django conventions for views, serializers, forms, admin configuration, and command structure.
- Treat settings, auth, and ORM-adjacent changes as regression-sensitive and pair them with targeted tests.
