# pytest

- Prefer targeted, readable tests with clear fixtures and explicit assertions.
- Avoid deleting tests without an explicit reason.
- When behavior changes, add coverage around the changed path rather than relying on broad smoke tests alone.

