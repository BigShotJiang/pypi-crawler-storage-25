---
name: pytest-testing
description: Write focused pytest coverage that matches the project’s existing testing style.
---

# pytest Testing

- Keep tests small and behavior-oriented.
- Prefer reusable fixtures over repeated setup.
- Add coverage for changed code paths and failure modes.

