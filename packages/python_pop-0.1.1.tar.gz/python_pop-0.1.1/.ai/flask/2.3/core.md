# Flask 2.3

- Use Flask 2.3-era APIs and compatibility expectations.
- Preserve the current JSON provider, request handling, and CLI behavior unless the task is explicitly a migration.
- Avoid mixing in Flask 3-only assumptions during normal feature work.

