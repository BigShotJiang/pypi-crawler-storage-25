# Flask

- Follow the inspected Flask project’s existing startup style, routing conventions, and extension registration order.
- Prefer Blueprints and the project’s current CLI patterns instead of introducing a new application shape by default.
- Treat auth, database setup, sessions, mail, and background integrations as high-risk surfaces that need careful regression testing.

