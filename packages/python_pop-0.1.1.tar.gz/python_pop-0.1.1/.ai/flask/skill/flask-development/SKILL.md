---
name: flask-development
description: Work effectively in Flask projects using Python Pop’s framework-aware guidance.
---

# Flask Development

- Read the existing Flask app bootstrap before changing routing or extension setup.
- Keep new endpoints aligned with the project’s established Blueprint and view patterns.
- Treat configuration and import-time side effects as important design constraints.
- Add focused tests when changing request handling, auth, DB integration, or CLI behavior.

