# Flask-CORS 6 Placeholder

- This module is a planned placeholder for future Flask-CORS 6 support.

