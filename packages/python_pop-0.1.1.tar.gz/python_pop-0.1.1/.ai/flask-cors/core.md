# Flask-CORS

- Treat global or broad CORS changes as behaviorally significant.
- Re-test wildcard, credentials, and environment-specific origin handling when changing CORS configuration.

