# Flask-CORS 5.0

- Keep compatibility with Flask-CORS 5.0 behavior and the project’s existing CORS initialization style.

