# SQLAlchemy

- Preserve the project’s existing session and query patterns unless the task is an intentional ORM migration.
- ORM changes should be paired with tests around data loading, write behavior, and transaction boundaries.

