# SQLAlchemy 1.4

- Stay compatible with SQLAlchemy 1.4 semantics.
- Be cautious about introducing SQLAlchemy 2-style APIs into a 1.4 project without a migration plan.

