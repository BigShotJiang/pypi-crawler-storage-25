# SQLAlchemy 2 Placeholder

- This module is a planned placeholder for SQLAlchemy 2 support.
- Confirm query APIs, session patterns, and declarative mappings before treating SQLAlchemy 2 as fully supported.

