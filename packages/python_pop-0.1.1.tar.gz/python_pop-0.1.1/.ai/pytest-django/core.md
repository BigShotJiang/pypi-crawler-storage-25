# pytest-django

- Keep test setup aligned with the project’s existing Django settings, database fixtures, and request/response test style.
- Prefer targeted tests around views, serializers, and management commands instead of broad end-to-end coverage by default.
