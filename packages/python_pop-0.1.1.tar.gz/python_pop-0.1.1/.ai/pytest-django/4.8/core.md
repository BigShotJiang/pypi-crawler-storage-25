# pytest-django 4.8

- Use pytest-django 4.8-compatible patterns for settings overrides, database access markers, and Django test configuration.
