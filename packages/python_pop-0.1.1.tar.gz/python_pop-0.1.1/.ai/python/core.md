# Python

- Prefer explicit, readable Python over clever abstractions.
- Use type hints on public functions and dataclass-based records where they improve clarity.
- Keep file I/O and shell integration conservative and easy to test.
- Avoid hidden mutation and prefer pure helpers for detection and composition logic.

