---
name: python-best-practices
description: Apply portable Python practices across framework and tooling code.
---

# Python Best Practices

- Prefer standard-library solutions unless a dependency is clearly justified.
- Keep public interfaces small and stable.
- Use focused tests with clear fixtures and minimal setup.
- Normalize file content and JSON output for predictable diffs.

