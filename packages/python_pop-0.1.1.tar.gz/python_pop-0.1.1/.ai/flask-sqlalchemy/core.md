# Flask-SQLAlchemy

- Keep ORM integration aligned with the existing Flask extension lifecycle.
- Avoid introducing SQLAlchemy 2-only patterns into Flask-SQLAlchemy projects unless the migration is explicit.

