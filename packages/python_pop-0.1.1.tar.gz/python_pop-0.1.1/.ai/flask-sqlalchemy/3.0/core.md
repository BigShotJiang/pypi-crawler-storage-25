# Flask-SQLAlchemy 3.0

- Treat the current project as using Flask-SQLAlchemy 3.0 conventions.
- Preserve the project’s existing `SQLAlchemy()` extension setup and model registration patterns.

