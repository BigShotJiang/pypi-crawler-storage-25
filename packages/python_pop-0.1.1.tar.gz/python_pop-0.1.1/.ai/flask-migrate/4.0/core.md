# Flask-Migrate 4 Placeholder

- This module is a planned placeholder for future Flask-Migrate 4 support.

