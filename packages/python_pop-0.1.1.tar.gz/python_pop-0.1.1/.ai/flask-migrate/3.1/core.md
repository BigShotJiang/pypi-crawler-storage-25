# Flask-Migrate 3.1

- Align migration workflow assumptions with Flask-Migrate 3.1 and the project’s current operational style.

