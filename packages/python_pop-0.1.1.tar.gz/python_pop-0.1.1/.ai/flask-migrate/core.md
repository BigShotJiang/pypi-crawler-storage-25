# Flask-Migrate

- Treat migration behavior as part of the project’s deployment contract.
- Keep schema changes and migration command changes deliberate and reviewable.

