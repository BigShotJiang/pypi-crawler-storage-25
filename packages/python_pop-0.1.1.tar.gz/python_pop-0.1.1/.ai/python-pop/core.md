# Python Pop

- Python Pop composes framework and package guidance from the inspected project.
- Treat `python-pop.json` as the package-managed configuration for selected agents, framework modules, and skills.
- Keep repo-specific memory and private implementation details in the consumer repository, not in Python Pop itself.
- Prefer agent-specific outputs such as `AGENTS.md`, `CLAUDE.md`, `GEMINI.md`, and agent skill directories over ad hoc one-off files.

