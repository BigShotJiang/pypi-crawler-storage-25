---
name: python-pop-development
description: Work effectively with the Python Pop install, update, MCP, and skill synchronization model.
---

# Python Pop Development

- Treat the top-level `.ai/` tree as the authored source of built-in modules and skills.
- Keep command behavior aligned with `install`, `update`, `mcp`, `execute-tool`, `add-skill`, and `inspect`.
- Preserve privacy: package assets must not contain private project names, proprietary paths, or repo-specific memory.
- Prefer framework-module detection and composition over project-specific hardcoding.

