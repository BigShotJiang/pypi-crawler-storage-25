# Foundational Context

- Follow the existing project architecture instead of rewriting the application around a preferred pattern.
- Prefer small, verifiable changes over broad framework rewrites.
- Keep generated guidance generic and portable. Do not assume private repository names, local paths, or proprietary services unless the inspected project itself exposes them.
- Add or update targeted tests when behavior changes.

