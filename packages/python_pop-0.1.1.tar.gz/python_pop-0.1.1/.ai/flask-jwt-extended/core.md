# Flask-JWT-Extended

- Treat token creation, current-user loading, and request guards as regression-sensitive code paths.
- Keep auth changes consistent with the project’s current JWT header and decode patterns.

