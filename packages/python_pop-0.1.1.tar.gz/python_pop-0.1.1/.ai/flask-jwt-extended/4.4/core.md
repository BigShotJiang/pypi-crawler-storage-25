# Flask-JWT-Extended 4.4

- Align auth changes with Flask-JWT-Extended 4.4 behavior.
- Re-test auth decorators and token parsing whenever changing request auth flow.

