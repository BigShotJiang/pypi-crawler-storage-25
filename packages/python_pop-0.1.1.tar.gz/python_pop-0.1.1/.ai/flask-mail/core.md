# Flask-Mail

- Treat mail delivery flows as integration-sensitive behavior.
- Keep message construction and app-context assumptions aligned with the current project.

