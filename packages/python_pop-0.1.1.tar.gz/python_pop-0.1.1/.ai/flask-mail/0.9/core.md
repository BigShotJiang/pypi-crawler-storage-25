# Flask-Mail 0.9

- Keep compatibility with Flask-Mail 0.9 initialization and message-sending patterns.

