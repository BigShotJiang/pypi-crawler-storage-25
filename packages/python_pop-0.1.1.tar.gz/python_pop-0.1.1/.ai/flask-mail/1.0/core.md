# Flask-Mail 1 Placeholder

- This module is a planned placeholder for future Flask-Mail 1.x support.

