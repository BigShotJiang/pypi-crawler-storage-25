# Masonite Placeholder

- Python Pop can detect Masonite projects, but Masonite-specific guidance is still a placeholder in this version.
- Preserve the project’s current service provider, routing, and IoC container conventions while richer Masonite guidance is developed.

