---
name: masonite-development
description: Placeholder Python Pop guidance for working in Masonite projects.
---

# Masonite Development Placeholder

- Inspect routes, providers, and container bindings before making changes.
- Treat this as starter guidance until richer Masonite support lands.
