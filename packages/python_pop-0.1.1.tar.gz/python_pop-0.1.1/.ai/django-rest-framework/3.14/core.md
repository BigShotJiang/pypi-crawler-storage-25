# Django REST Framework 3.14

- Keep compatibility with Django REST Framework 3.14 serializers, viewsets, routers, and authentication behavior.
- Avoid introducing newer DRF assumptions unless the project is explicitly being upgraded.
