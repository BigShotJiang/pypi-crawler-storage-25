# Django REST Framework 3.15 Placeholder

- Django REST Framework 3.15 guidance is bundled as a planned asset for future compatibility work.
