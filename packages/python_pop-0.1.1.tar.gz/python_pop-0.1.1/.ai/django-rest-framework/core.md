# Django REST Framework

- Preserve the project’s current API layering, serializer patterns, authentication classes, and pagination conventions.
- API behavior changes should be paired with tests for request validation, auth, and serialized response shape.
