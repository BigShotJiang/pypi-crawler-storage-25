# Publish Checklist

## Before cutting a release

- Confirm the version bump matches Semantic Versioning.
- Update `CHANGELOG.md`.
- Confirm release work is based on `trunk`.
- Ensure the working tree is clean.
- Run `python3 -m unittest discover -s tests -t . -q`.
- Run `bash scripts/release-check.sh`.
- Confirm `dist/` contains both an sdist and a wheel.
- Confirm the built metadata includes the expected name, version, license, and README content.

## Before publishing

- Confirm the release tag matches the version, for example `v0.1.0` for the first public release.
- Confirm release candidate tags use the `RC--X.Y.Z-A` format with an uppercase candidate letter.
- Confirm the GitHub default branch is `trunk`.
- Confirm the GitHub Actions release workflow is green.
- Confirm PyPI trusted publishing is configured for this repository.
- Confirm no private consumer-repo details were introduced into packaged assets, docs, or defaults.

## After publishing

- Verify the release is visible on PyPI.
- Install the published wheel into a fresh virtual environment.
- Smoke-test `python-pop --help` and `python-pop inspect`.
