# Releasing Python Pop

`python pop` uses a release-only toolchain for package validation. The package runtime does not depend on `build` or `twine`.

The primary development branch is `trunk`.

## Versioning policy

`python pop` follows Semantic Versioning:

- Major: any intentionally breaking change in CLI behavior, MCP interfaces, managed output formats, or packaged framework guidance contracts.
- Minor: new public features such as new framework modules, new MCP tools, or additive release tooling.
- Patch: fixes, metadata corrections, documentation updates, or internal changes that preserve public behavior.

## Local release check

Run the release check in an isolated environment:

```bash
bash scripts/release-check.sh
```

The release check will:

- create or refresh `.venv-release`
- install `build` and `twine` into that isolated environment
- rebuild `dist/`
- run `python -m build`
- run `twine check dist/*`

## Tagging

Use final release tags in the form `vX.Y.Z`, for example:

```bash
git tag v0.1.0
git push origin v0.1.0
```

The first public release is `0.1.0`. The release workflow is designed around version tags and PyPI publishing.

Use release candidate tags in the form `RC--X.Y.Z-A`, where `A` is an uppercase candidate letter, for example:

```bash
git tag RC--0.1.0-A
git push origin RC--0.1.0-A
```

Release candidate tags build and validate distribution artifacts but do not publish to PyPI.

## PyPI publishing

GitHub Actions should be configured to use PyPI trusted publishing for this repository.

Before enabling publish jobs:

- configure the PyPI project
- register the GitHub repository as a trusted publisher
- confirm the release workflow has access to `id-token: write`

If trusted publishing is not configured yet, the release workflow should still build and validate the distribution artifacts without publishing them.
