from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class GuidelineConfig:
    framework: str | None = None
    include_planned: bool = False
    selected_packages: list[str] = field(default_factory=list)
    selected_skills: list[str] = field(default_factory=list)

