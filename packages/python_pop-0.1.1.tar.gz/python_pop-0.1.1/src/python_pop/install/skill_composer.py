from __future__ import annotations

from pathlib import Path
import re

from ..frameworks.detector import ProjectInspection
from ..support.assets import resolve_ai_path
from .skill import Skill


class SkillComposer:
    def __init__(self, inspection: ProjectInspection):
        self.inspection = inspection

    def skills(self) -> dict[str, Skill]:
        built_in = self._discover_builtin_skills()
        custom = self._discover_custom_skills()
        merged = {**built_in, **custom}
        return merged

    def _discover_builtin_skills(self) -> dict[str, Skill]:
        skills: dict[str, Skill] = {}
        for module in self.inspection.modules:
            for relative_dir in module.skill_directories:
                skill = self._parse_skill_directory(self._resolve_dir(relative_dir), module.slug, custom=False)
                if skill:
                    skills[skill.name] = skill
        return skills

    def _discover_custom_skills(self) -> dict[str, Skill]:
        root = self.inspection.project_root / ".ai" / "skills"
        if not root.exists():
            return {}
        skills: dict[str, Skill] = {}
        for path in sorted(root.iterdir()):
            if not path.is_dir():
                continue
            skill = self._parse_skill_directory(path, "user", custom=True)
            if skill:
                skills[skill.name] = skill
        return skills

    def _resolve_dir(self, relative_dir: str) -> Path:
        path = Path(relative_dir)
        if path.is_absolute():
            return path
        return resolve_ai_path(relative_dir)

    def _parse_skill_directory(self, path: Path, package: str, custom: bool) -> Skill | None:
        if not path.exists():
            return None
        skill_file = None
        for candidate in ("SKILL.md", "SKILL.blade.php"):
            current = path / candidate
            if current.exists():
                skill_file = current
                break
        if skill_file is None:
            return None

        content = skill_file.read_text(encoding="utf-8")
        frontmatter_match = re.search(r"^\s*---\s*\n(.*?)\n---\s*\n", content, re.DOTALL)
        if frontmatter_match is None:
            return None

        metadata: dict[str, str] = {}
        for line in frontmatter_match.group(1).splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip().strip('"').strip("'")

        name = metadata.get("name") or path.name
        description = metadata.get("description") or ""
        return Skill(name=name, package=package, path=path, description=description, custom=custom)

