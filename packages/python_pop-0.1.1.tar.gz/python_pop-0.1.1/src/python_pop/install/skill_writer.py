from __future__ import annotations

import shutil
from pathlib import Path

from ..contracts import SupportsSkills
from .skill import Skill


class SkillWriter:
    SUCCESS = 0
    UPDATED = 1
    FAILED = 2

    def __init__(self, agent: SupportsSkills):
        self.agent = agent

    def write(self, project_root: str | Path, skill: Skill) -> int:
        root = Path(project_root).resolve()
        target = root / self.agent.skills_path() / skill.name
        existed = target.exists()
        if target.exists():
            shutil.rmtree(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(skill.path, target)
        return self.UPDATED if existed else self.SUCCESS

    def write_all(self, project_root: str | Path, skills: dict[str, Skill]) -> dict[str, int]:
        return {name: self.write(project_root, skill) for name, skill in skills.items()}

    def sync(self, project_root: str | Path, skills: dict[str, Skill], previous_names: list[str]) -> dict[str, int]:
        results = self.write_all(project_root, skills)
        for stale in sorted(set(previous_names) - set(skills)):
            self.remove(project_root, stale)
        return results

    def remove(self, project_root: str | Path, skill_name: str) -> bool:
        target = Path(project_root).resolve() / self.agent.skills_path() / skill_name
        if not target.exists():
            return True
        shutil.rmtree(target)
        return not target.exists()

