from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..frameworks.detector import ProjectInspection
from ..support.assets import resolve_ai_path


@dataclass(frozen=True)
class ComposedGuidelines:
    content: str
    asset_paths: list[str]
    used_modules: list[str]


class GuidelineComposer:
    def __init__(self, inspection: ProjectInspection, include_planned: bool = False):
        self.inspection = inspection
        self.include_planned = include_planned

    def compose(self) -> ComposedGuidelines:
        sections: list[str] = []
        asset_paths: list[str] = []
        used_modules: list[str] = []

        for module in self.inspection.modules:
            module_chunks: list[str] = []
            for asset in module.assets:
                if asset.planned and not self.include_planned:
                    continue
                path = self._resolve_asset_path(asset.relative_path)
                if not path.exists():
                    continue
                module_chunks.append(path.read_text(encoding="utf-8").strip())
                asset_paths.append(asset.relative_path)
            if not module_chunks:
                continue
            used_modules.append(module.slug)
            sections.append(f"=== {module.slug} rules ===\n\n" + "\n\n".join(chunk for chunk in module_chunks if chunk))

        content = "\n\n".join(section.strip() for section in sections if section.strip()).strip()
        if content and not content.endswith("\n"):
            content += "\n"

        return ComposedGuidelines(
            content=content,
            asset_paths=asset_paths,
            used_modules=used_modules,
        )

    def _resolve_asset_path(self, relative_path: str) -> Path:
        path = Path(relative_path)
        if path.is_absolute():
            return path
        return resolve_ai_path(relative_path)

