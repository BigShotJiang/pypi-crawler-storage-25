from __future__ import annotations

from pathlib import Path


MCP_LAUNCHER_PATH = ".python-pop/mcp-launcher.py"


MCP_LAUNCHER_CONTENT = '''#!/usr/bin/env python3
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys


def _python_executable(env_root: Path) -> Path:
    if os.name == "nt":
        return env_root / "Scripts" / "python.exe"
    return env_root / "bin" / "python"


def _can_import_python_pop(python: Path) -> bool:
    try:
        completed = subprocess.run(
            [str(python), "-c", "import python_pop"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return completed.returncode == 0


def _candidate_commands(project_root: Path) -> list[list[str]]:
    commands: list[list[str]] = []

    configured_python = os.environ.get("PYTHON_POP_PYTHON", "").strip()
    if configured_python:
        commands.append([configured_python, "-m", "python_pop", "mcp"])

    for relative_env in (
        "Envs/python-pop",
        "Envs/python_pop",
        ".python-pop/venv",
        ".venv",
        "venv",
        "env",
    ):
        python = _python_executable(project_root / relative_env)
        if python.exists() and _can_import_python_pop(python):
            commands.append([str(python), "-m", "python_pop", "mcp"])

    python_pop = shutil.which("python-pop")
    if python_pop:
        commands.append([python_pop, "mcp"])

    for executable in ("python3", "python"):
        python_path = shutil.which(executable)
        if not python_path:
            continue
        python = Path(python_path)
        if _can_import_python_pop(python):
            commands.append([str(python), "-m", "python_pop", "mcp"])

    return commands


def main() -> int:
    project_root = Path(os.environ.get("PYTHON_POP_PROJECT_ROOT", os.getcwd())).resolve()
    os.environ.setdefault("PYTHON_POP_ALLOWED_ROOT", ".")

    commands = _candidate_commands(project_root)
    if not commands:
        print(
            "Python Pop MCP launcher could not find an installed python-pop runtime. "
            "Set PYTHON_POP_PYTHON or install python-pop in a project-local environment.",
            file=sys.stderr,
        )
        return 127

    command = commands[0]
    os.execvpe(command[0], command, os.environ.copy())
    return 127


if __name__ == "__main__":
    raise SystemExit(main())
'''


def mcp_launcher_command() -> tuple[str, list[str]]:
    return "python3", [MCP_LAUNCHER_PATH]


def write_mcp_launcher(project_root: str | Path) -> Path:
    root = Path(project_root).resolve()
    target = root / MCP_LAUNCHER_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(MCP_LAUNCHER_CONTENT, encoding="utf-8")
    target.chmod(0o755)
    return target
