from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import shutil


def _expand_path(path: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(path)))


@dataclass
class BinaryDetectionStrategy:
    def detect(self, config: dict[str, object], base_path: str | None = None) -> bool:
        binary = config.get("binary")
        binaries = list(config.get("binaries", []))
        candidates = ([str(binary)] if binary else []) + [str(item) for item in binaries]
        return any(shutil.which(candidate) is not None for candidate in candidates)


@dataclass
class FileDetectionStrategy:
    def detect(self, config: dict[str, object], base_path: str | None = None) -> bool:
        files = list(config.get("files", []))
        root = Path(base_path) if base_path else Path.cwd()
        return any((root / file_path).exists() for file_path in files)


@dataclass
class DirectoryDetectionStrategy:
    def detect(self, config: dict[str, object], base_path: str | None = None) -> bool:
        paths = list(config.get("paths", []))
        root = Path(base_path) if base_path else None

        for path_text in paths:
            path = _expand_path(str(path_text))
            candidate = path if path.is_absolute() or root is None else root / path
            if candidate.exists():
                return True
        return False


class CompositeDetectionStrategy:
    def __init__(self, strategies: list[object]):
        self.strategies = strategies

    def detect(self, config: dict[str, object], base_path: str | None = None) -> bool:
        if not self.strategies:
            return False
        return any(strategy.detect(config, base_path=base_path) for strategy in self.strategies)


class DetectionStrategyFactory:
    def make_from_config(self, config: dict[str, object]) -> CompositeDetectionStrategy:
        strategies: list[object] = []
        if config.get("binary") or config.get("binaries"):
            strategies.append(BinaryDetectionStrategy())
        if config.get("files"):
            strategies.append(FileDetectionStrategy())
        if config.get("paths"):
            strategies.append(DirectoryDetectionStrategy())
        return CompositeDetectionStrategy(strategies)
