from __future__ import annotations

from pathlib import Path

from ..python_pop_manager import PythonPopManager
from .agents.agent import Agent


class AgentsDetector:
    def __init__(self, manager: PythonPopManager | None = None):
        self.manager = manager or PythonPopManager()

    def get_agents(self) -> list[Agent]:
        return [agent_class() for agent_class in self.manager.get_agents().values()]

    def discover_system_installed_agents(self) -> list[str]:
        return [agent.name() for agent in self.get_agents() if agent.detect_on_system()]

    def discover_project_installed_agents(self, base_path: str | Path) -> list[str]:
        base_path = Path(base_path).resolve()
        return [agent.name() for agent in self.get_agents() if agent.detect_in_project(base_path)]
