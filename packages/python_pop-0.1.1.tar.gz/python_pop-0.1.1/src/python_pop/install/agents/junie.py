from __future__ import annotations

from .agent import Agent


class Junie(Agent):
    def name(self) -> str:
        return "junie"

    def display_name(self) -> str:
        return "Junie"

    def system_detection_config(self) -> dict[str, object]:
        return {
            "binary": "phpstorm",
            "paths": ["/Applications/PhpStorm.app", "/opt/phpstorm", "~/.local/share/JetBrains/Toolbox/apps/PhpStorm"],
        }

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".idea", ".junie"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".junie/skills"

    def mcp_config_path(self) -> str | None:
        return ".junie/mcp/mcp.json"

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"command": "npx", "args": ["-y", "mcp-remote", url]}
