from __future__ import annotations

from .agent import Agent


class OpenCode(Agent):
    def name(self) -> str:
        return "opencode"

    def display_name(self) -> str:
        return "OpenCode"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "opencode"}

    def project_detection_config(self) -> dict[str, object]:
        return {"files": ["AGENTS.md", "opencode.json"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".agents/skills"

    def mcp_config_path(self) -> str | None:
        return "opencode.json"

    def mcp_config_key(self) -> str:
        return "mcp"

    def default_mcp_config(self) -> dict[str, object]:
        return {"$schema": "https://opencode.ai/config.json"}

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"type": "remote", "enabled": True, "url": url, "oauth": {}}

    def mcp_server_config(self, command: str, args: list[str], env: dict[str, str], project_root: str) -> dict[str, object]:
        return {
            "type": "local",
            "enabled": True,
            "command": [command, *args],
            "environment": env,
        }
