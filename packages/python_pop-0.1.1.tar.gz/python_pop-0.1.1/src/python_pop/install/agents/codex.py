from __future__ import annotations

from .agent import Agent


class Codex(Agent):
    def name(self) -> str:
        return "codex"

    def display_name(self) -> str:
        return "Codex"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "codex"}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".codex"], "files": ["AGENTS.md", ".codex/config.toml"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".agents/skills"

    def mcp_config_path(self) -> str | None:
        return ".codex/config.toml"

    def mcp_config_key(self) -> str:
        return "mcp_servers"

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"command": "npx", "args": ["-y", "mcp-remote", url]}

    def mcp_server_config(self, command: str, args: list[str], env: dict[str, str], project_root: str) -> dict[str, object]:
        payload: dict[str, object] = {"command": command, "args": args, "cwd": project_root}
        if env:
            payload["env"] = env
        return payload
