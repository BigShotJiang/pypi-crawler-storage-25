from __future__ import annotations

from .agent import Agent


class Cursor(Agent):
    def name(self) -> str:
        return "cursor"

    def display_name(self) -> str:
        return "Cursor"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "cursor", "paths": ["/Applications/Cursor.app", "/opt/cursor", "~/.local/bin/cursor"]}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".cursor"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".cursor/skills"

    def mcp_config_path(self) -> str | None:
        return ".cursor/mcp.json"

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"command": "npx", "args": ["-y", "mcp-remote", url]}
