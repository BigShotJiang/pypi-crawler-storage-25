from __future__ import annotations

from .agent import Agent


class ClaudeCode(Agent):
    def name(self) -> str:
        return "claude_code"

    def display_name(self) -> str:
        return "Claude Code"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "claude"}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".claude"], "files": ["CLAUDE.md"]}

    def guidelines_path(self) -> str:
        return "CLAUDE.md"

    def skills_path(self) -> str:
        return ".claude/skills"

    def mcp_config_path(self) -> str | None:
        return ".mcp.json"
