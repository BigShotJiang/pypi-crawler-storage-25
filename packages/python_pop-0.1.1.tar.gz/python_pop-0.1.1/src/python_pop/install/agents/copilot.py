from __future__ import annotations

from .agent import Agent


class Copilot(Agent):
    def name(self) -> str:
        return "copilot"

    def display_name(self) -> str:
        return "GitHub Copilot"

    def system_detection_config(self) -> dict[str, object]:
        return {"binaries": ["code", "code-insiders"], "paths": ["/Applications/Visual Studio Code.app", "~/.vscode"]}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".vscode"], "files": [".github/copilot-instructions.md"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".github/skills"

    def mcp_config_path(self) -> str | None:
        return ".vscode/mcp.json"

    def mcp_config_key(self) -> str:
        return "servers"
