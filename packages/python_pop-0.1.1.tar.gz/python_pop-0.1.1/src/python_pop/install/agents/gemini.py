from __future__ import annotations

import re

from .agent import Agent


class Gemini(Agent):
    def name(self) -> str:
        return "gemini"

    def display_name(self) -> str:
        return "Gemini CLI"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "gemini"}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".gemini"], "files": ["GEMINI.md"]}

    def guidelines_path(self) -> str:
        return "GEMINI.md"

    def skills_path(self) -> str:
        return ".agents/skills"

    def mcp_config_path(self) -> str | None:
        return ".gemini/settings.json"

    def transform_guidelines(self, markdown: str) -> str:
        return re.sub(r"(?<!\\)@([a-z0-9_.-]+/[a-z0-9_.-]+)", r"\\@\1", markdown, flags=re.IGNORECASE)

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"command": "npx", "args": ["-y", "mcp-remote", url]}
