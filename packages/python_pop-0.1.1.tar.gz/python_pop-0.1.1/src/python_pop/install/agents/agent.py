from __future__ import annotations

from abc import ABC, abstractmethod
import json
from pathlib import Path
import sys
from typing import TYPE_CHECKING

from ...contracts import SupportsGuidelines, SupportsMcp, SupportsSkills
from ..detection import DetectionStrategyFactory

if TYPE_CHECKING:
    from ...python_pop_manager import PythonPopManager


class Agent(ABC, SupportsGuidelines, SupportsMcp, SupportsSkills):
    def __init__(self, strategy_factory: DetectionStrategyFactory | None = None):
        self.strategy_factory = strategy_factory or DetectionStrategyFactory()

    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def display_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def system_detection_config(self) -> dict[str, object]:
        raise NotImplementedError

    @abstractmethod
    def project_detection_config(self) -> dict[str, object]:
        raise NotImplementedError

    def detect_on_system(self) -> bool:
        return self.strategy_factory.make_from_config(self.system_detection_config()).detect(self.system_detection_config())

    def detect_in_project(self, base_path: str | Path) -> bool:
        config = dict(self.project_detection_config())
        return self.strategy_factory.make_from_config(config).detect(config, base_path=str(Path(base_path).resolve()))

    def frontmatter(self) -> bool:
        return False

    def transform_guidelines(self, markdown: str) -> str:
        return markdown

    def mcp_config_path(self) -> str | None:
        return None

    def mcp_config_key(self) -> str:
        return "mcpServers"

    def default_mcp_config(self) -> dict[str, object]:
        return {}

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"type": "http", "url": url}

    def mcp_server_config(self, command: str, args: list[str], env: dict[str, str], project_root: str) -> dict[str, object]:
        payload: dict[str, object] = {"command": command, "args": args}
        if env:
            payload["env"] = env
        return payload

    def install_mcp(
        self,
        project_root: str | Path,
        key: str,
        command: str,
        args: list[str],
        env: dict[str, str],
        server_project_root: str | None = None,
    ) -> bool:
        path_text = self.mcp_config_path()
        if not path_text:
            return False

        project_root = Path(project_root).resolve()
        target = project_root / path_text
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = self.default_mcp_config()
        if target.exists():
            payload = self._load_existing(target)
        self._insert_server_config(
            payload,
            key,
            self.mcp_server_config(command, args, env, server_project_root or str(project_root)),
        )
        self._write_config(target, payload)
        return True

    def install_http_mcp(self, project_root: str | Path, key: str, url: str) -> bool:
        path_text = self.mcp_config_path()
        if not path_text:
            return False

        project_root = Path(project_root).resolve()
        target = project_root / path_text
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = self.default_mcp_config()
        if target.exists():
            payload = self._load_existing(target)
        self._insert_server_config(payload, key, self.http_mcp_server_config(url))
        self._write_config(target, payload)
        return True

    @classmethod
    def from_name(cls, manager: "PythonPopManager", name: str) -> "Agent | None":
        agent_class = manager.get_agents().get(name)
        return None if agent_class is None else agent_class()

    def _insert_server_config(self, payload: dict[str, object], key: str, config: dict[str, object]) -> None:
        pointer = payload
        keys = self.mcp_config_key().split(".")
        for chunk in keys[:-1]:
            next_value = pointer.setdefault(chunk, {})
            if not isinstance(next_value, dict):
                next_value = {}
                pointer[chunk] = next_value
            pointer = next_value
        final = keys[-1]
        servers = pointer.setdefault(final, {})
        if not isinstance(servers, dict):
            servers = {}
            pointer[final] = servers
        servers[key] = config

    def _load_existing(self, path: Path) -> dict[str, object]:
        if path.suffix == ".toml":
            return self._load_toml(path)
        return json.loads(path.read_text(encoding="utf-8"))

    def _write_config(self, path: Path, payload: dict[str, object]) -> None:
        if path.suffix == ".toml":
            path.write_text(self._to_toml(payload).rstrip() + "\n", encoding="utf-8")
            return
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def _load_toml(self, path: Path) -> dict[str, object]:
        # Minimal TOML reader for the MCP config shapes Python Pop writes.
        result: dict[str, object] = {}
        current = result
        stack: list[str] = []

        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("[") and line.endswith("]"):
                stack = [part.strip() for part in line[1:-1].split(".") if part.strip()]
                current = result
                for part in stack:
                    next_value = current.setdefault(part, {})
                    if not isinstance(next_value, dict):
                        next_value = {}
                        current[part] = next_value
                    current = next_value
                continue

            if "=" not in line:
                continue
            key, value = [item.strip() for item in line.split("=", 1)]
            current[key] = self._parse_toml_value(value)

        return result

    def _parse_toml_value(self, value: str) -> object:
        if value.startswith('"') and value.endswith('"'):
            return value[1:-1]
        if value in {"true", "false"}:
            return value == "true"
        if value.startswith("[") and value.endswith("]"):
            inner = value[1:-1].strip()
            if inner == "":
                return []
            return [self._parse_toml_value(item.strip()) for item in inner.split(",")]
        return value

    def _to_toml(self, payload: dict[str, object], prefix: str = "") -> str:
        lines: list[str] = []
        simple_keys: list[tuple[str, object]] = []
        nested_keys: list[tuple[str, dict[str, object]]] = []

        for key, value in payload.items():
            if isinstance(value, dict):
                nested_keys.append((key, value))
            else:
                simple_keys.append((key, value))

        for key, value in simple_keys:
            lines.append(f"{key} = {self._toml_value(value)}")

        for key, value in nested_keys:
            table = f"{prefix}.{key}" if prefix else key
            if lines:
                lines.append("")
            lines.append(f"[{table}]")
            nested_block = self._to_toml(value, table)
            if nested_block:
                lines.append(nested_block)

        return "\n".join(line for line in lines if line is not None)

    def _toml_value(self, value: object) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, list):
            return "[" + ", ".join(self._toml_value(item) for item in value) + "]"
        text = str(value).replace("\\", "\\\\").replace('"', '\\"')
        return f'"{text}"'

    def python_command(self) -> str:
        return sys.executable
