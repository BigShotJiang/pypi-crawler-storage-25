from __future__ import annotations

from .agent import Agent


class Amp(Agent):
    def name(self) -> str:
        return "amp"

    def display_name(self) -> str:
        return "Amp"

    def system_detection_config(self) -> dict[str, object]:
        return {"binary": "amp", "paths": ["~/.amp", "~/.config/amp"]}

    def project_detection_config(self) -> dict[str, object]:
        return {"paths": [".amp"]}

    def guidelines_path(self) -> str:
        return "AGENTS.md"

    def skills_path(self) -> str:
        return ".agents/skills"

    def mcp_config_path(self) -> str | None:
        return ".amp/settings.json"

    def mcp_config_key(self) -> str:
        return "amp.mcpServers"

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        return {"url": url}
