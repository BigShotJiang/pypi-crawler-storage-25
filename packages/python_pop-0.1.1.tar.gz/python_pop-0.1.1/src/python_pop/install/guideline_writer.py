from __future__ import annotations

from pathlib import Path
import re

from ..contracts import SupportsGuidelines


class GuidelineWriter:
    NEW = 0
    REPLACED = 1
    NOOP = 2

    def __init__(self, agent: SupportsGuidelines):
        self.agent = agent

    def write(self, project_root: str | Path, guidelines: str) -> int:
        if not guidelines.strip():
            return self.NOOP

        target = Path(project_root).resolve() / self.agent.guidelines_path()
        target.parent.mkdir(parents=True, exist_ok=True)

        replacement = "<python-pop-guidelines>\n" + self.agent.transform_guidelines(guidelines.strip()) + "\n</python-pop-guidelines>\n"
        existing = target.read_text(encoding="utf-8") if target.exists() else ""
        pattern = re.compile(r"<python-pop-guidelines>.*?</python-pop-guidelines>\n?", re.DOTALL)

        if pattern.search(existing):
            updated = pattern.sub(replacement, existing, count=1)
            target.write_text(self._normalize(updated), encoding="utf-8")
            return self.REPLACED

        frontmatter = ""
        if self.agent.frontmatter() and "\n---\n" not in existing:
            frontmatter = "---\nalwaysApply: true\n---\n"

        body = existing.rstrip()
        separator = "\n\n===\n\n" if body else ""
        target.write_text(self._normalize(frontmatter + body + separator + replacement), encoding="utf-8")
        return self.NEW

    def _normalize(self, content: str) -> str:
        normalized = re.sub(r"\n{3,}", "\n\n", content).rstrip() + "\n"
        return normalized

