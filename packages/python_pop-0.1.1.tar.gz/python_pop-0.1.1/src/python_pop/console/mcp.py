from __future__ import annotations

from ..mcp.server import StdioMcpServer


def run_mcp(args) -> int:
    return StdioMcpServer().serve()

