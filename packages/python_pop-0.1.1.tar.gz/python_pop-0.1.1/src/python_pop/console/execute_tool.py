from __future__ import annotations

import base64
import json

from ..mcp.tool_registry import ToolRegistry


def run_execute_tool(args) -> int:
    registry = ToolRegistry()
    tool = registry.get(args.tool)
    if tool is None:
        print(json.dumps({"isError": True, "content": [{"type": "text", "text": f"Unknown tool: {args.tool}"}]}))
        return 1

    try:
        arguments = json.loads(base64.b64decode(args.arguments).decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"isError": True, "content": [{"type": "text", "text": f"Invalid arguments: {exc}"}]}))
        return 1

    try:
        result = tool.execute(arguments)
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"isError": True, "content": [{"type": "text", "text": f"Tool execution failed: {exc}"}]}))
        return 1
    print(json.dumps({"isError": False, "content": [{"type": "text", "text": json.dumps(result, sort_keys=True)}]}))
    return 0
