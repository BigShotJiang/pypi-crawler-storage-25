from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from .add_skill import run_add_skill
from .execute_tool import run_execute_tool
from .inspect import run_inspect
from .install import run_install
from .mcp import run_mcp
from .update import run_update


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python-pop", description="AI tooling for Python frameworks.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser("inspect", help="Inspect a Python web project.")
    inspect_parser.add_argument("--project-root", type=Path, default=Path("."), help="Path to the project root.")
    inspect_parser.add_argument("--json", action="store_true", dest="as_json", help="Emit machine-readable JSON.")
    inspect_parser.add_argument("--package", action="append", default=[], help="Enable a specific external module slug.")

    install_parser = subparsers.add_parser("install", help="Install Python Pop guidelines, skills, and MCP configuration.")
    install_parser.add_argument("--project-root", type=Path, default=Path("."), help="Path to the project root.")
    install_parser.add_argument("--guidelines", action="store_true", help="Install guidelines.")
    install_parser.add_argument("--skills", action="store_true", help="Install skills.")
    install_parser.add_argument("--mcp", action="store_true", help="Install MCP configuration.")
    install_parser.add_argument("--agent", action="append", default=[], help="Select an agent by slug.")
    install_parser.add_argument("--package", action="append", default=[], help="Enable a third-party module slug.")
    install_parser.add_argument("--include-planned", action="store_true", help="Include planned guideline assets.")
    install_parser.add_argument("--force", action="store_true", help="Overwrite managed outputs when applicable.")
    install_parser.add_argument("--dry-run", action="store_true", help="Print planned outputs without writing them.")
    install_parser.add_argument("--no-interaction", action="store_true", help="Disable interactive prompts.")

    update_parser = subparsers.add_parser("update", help="Refresh managed guidelines and skills.")
    update_parser.add_argument("--project-root", type=Path, default=Path("."), help="Path to the project root.")
    update_parser.add_argument("--discover", action="store_true", help="Auto-include newly available external modules.")
    update_parser.add_argument("--ignore-skills", action="store_true", help="Skip skill synchronization.")
    update_parser.add_argument("--include-planned", action="store_true", help="Include planned guideline assets.")
    update_parser.add_argument("--dry-run", action="store_true", help="Print planned writes without writing them.")

    add_skill_parser = subparsers.add_parser("add-skill", help="Install skills from a remote GitHub repository.")
    add_skill_parser.add_argument("repo", nargs="?", help="GitHub repository in owner/repo or URL form.")
    add_skill_parser.add_argument("--project-root", type=Path, default=Path("."), help="Path to the project root.")
    add_skill_parser.add_argument("--list", action="store_true", help="List available skills only.")
    add_skill_parser.add_argument("--all", action="store_true", help="Install all discovered skills.")
    add_skill_parser.add_argument("--skill", action="append", default=[], help="Install a specific skill name.")
    add_skill_parser.add_argument("--force", action="store_true", help="Overwrite existing skills.")
    add_skill_parser.add_argument("--skip-audit", action="store_true", help="Skip the local safety audit.")
    add_skill_parser.add_argument("--no-interaction", action="store_true", help="Disable interactive prompts.")

    execute_parser = subparsers.add_parser("execute-tool", help="Execute an MCP tool in isolation.")
    execute_parser.add_argument("tool", help="Tool name.")
    execute_parser.add_argument("arguments", help="Base64-encoded JSON arguments.")

    subparsers.add_parser("mcp", help="Start the Python Pop MCP server.")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.command == "inspect":
        return run_inspect(args.project_root, args.as_json, selected_external=args.package)
    if args.command == "install":
        return run_install(args)
    if args.command == "update":
        return run_update(args)
    if args.command == "add-skill":
        return run_add_skill(args)
    if args.command == "execute-tool":
        return run_execute_tool(args)
    if args.command == "mcp":
        return run_mcp(args)

    parser.error(f"Unknown command: {args.command}")
    return 2
