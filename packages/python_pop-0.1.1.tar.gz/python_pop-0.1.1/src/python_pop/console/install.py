from __future__ import annotations

from pathlib import Path

from ..frameworks.detector import build_project_context, inspect_project
from ..frameworks.registry import ModuleRegistry
from ..install.agents.agent import Agent
from ..install.guideline_composer import GuidelineComposer
from ..install.guideline_writer import GuidelineWriter
from ..install.mcp_launcher import MCP_LAUNCHER_PATH, mcp_launcher_command, write_mcp_launcher
from ..install.skill_composer import SkillComposer
from ..install.skill_writer import SkillWriter
from ..python_pop_manager import PythonPopManager
from ..support.config import ConfigStore, PythonPopConfig
from ..support.display import InstallDisplay
from ..support.prompts import confirm, is_interactive, multiselect
from ..support.security import INSPECTION_ALLOWED_ROOT_ENV


DEFAULT_INSTALL_AGENTS = ["opencode", "claude_code"]


def _default_features(existing: PythonPopConfig | None) -> tuple[bool, bool, bool]:
    if existing and (existing.guidelines or existing.skills or existing.mcp):
        return existing.guidelines, True, existing.mcp
    return True, True, True


def _resolve_features(args, existing: PythonPopConfig | None) -> tuple[bool, bool, bool]:
    explicit = any(value for value in (args.guidelines, args.skills, args.mcp))
    if explicit:
        return bool(args.guidelines), bool(args.skills), bool(args.mcp)
    return _default_features(existing)


def _resolve_agents(project_root: Path, args, existing: PythonPopConfig | None, interactive: bool) -> list[Agent]:
    manager = PythonPopManager()
    chosen_names: list[str]

    if args.agent:
        chosen_names = list(args.agent)
    elif existing and existing.agents:
        chosen_names = list(existing.agents)
    else:
        available = {name: manager.get_agents()[name]().display_name() for name in manager.get_agents()}
        chosen_names = multiselect(
            "Which AI agents should Python Pop configure?",
            available,
            DEFAULT_INSTALL_AGENTS,
            interactive=interactive,
            required=True,
        )

    agents: list[Agent] = []
    for name in chosen_names:
        instance = Agent.from_name(manager, name)
        if instance is not None:
            agents.append(instance)
    return agents


def _resolve_external_packages(project_root: Path, args, existing: PythonPopConfig | None, interactive: bool) -> list[str]:
    registry = ModuleRegistry()
    project = build_project_context(project_root)
    available = registry.discover_available_external_modules(project)
    if not available:
        return list(args.package or (existing.packages if existing else []))

    option_map = {module.slug: module.display_name for module in available}
    if args.package:
        return [name for name in args.package if name in option_map]

    defaults = existing.packages if existing else []
    return multiselect(
        "Which third-party Python Pop modules should be enabled?",
        option_map,
        defaults,
        interactive=interactive,
        required=False,
    )


def _confirm_framework_discovery(inspection, interactive: bool, force: bool) -> bool:
    framework_modules = inspection.framework_modules
    if len(framework_modules) <= 1:
        return True

    names = ", ".join(f"{module.display_name} ({module.slug})" for module in framework_modules)
    print("")
    print("Multiple Python frameworks were detected:")
    print(f"- {names}")
    print("Python Pop will compose guidance and skills for each detected framework.")

    if interactive:
        return confirm("Continue with this multi-framework install?", default=False, interactive=True)

    if force:
        print("Continuing because --force was provided.")
        return True

    print("Run again interactively to confirm, or pass --force for non-interactive installs.")
    return False


def execute_install(
    project_root: Path,
    guidelines_enabled: bool,
    skills_enabled: bool,
    mcp_enabled: bool,
    include_planned: bool,
    force: bool,
    dry_run: bool,
    agents: list[Agent],
    selected_packages: list[str],
    previous_skill_names: list[str] | None = None,
) -> tuple[list[str], list[str], list[str]]:
    inspection = inspect_project(project_root, selected_external=selected_packages)
    guideline_targets: list[str] = []
    skill_targets: list[str] = []
    mcp_targets: list[str] = []

    if guidelines_enabled:
        composed = GuidelineComposer(inspection, include_planned=include_planned).compose()
        for agent in agents:
            guideline_targets.append(str((project_root / agent.guidelines_path()).resolve()))
            if not dry_run:
                GuidelineWriter(agent).write(project_root, composed.content)

    if skills_enabled:
        skills = SkillComposer(inspection).skills()
        for agent in agents:
            for skill_name in sorted(skills):
                skill_targets.append(str((project_root / agent.skills_path() / skill_name).resolve()))
            if not dry_run:
                SkillWriter(agent).sync(project_root, skills, previous_skill_names or [])

    if mcp_enabled:
        mcp_agents = [agent for agent in agents if agent.mcp_config_path() is not None]
        if mcp_agents:
            command, args = mcp_launcher_command()
            if not dry_run:
                write_mcp_launcher(project_root)
            mcp_targets.append(str((project_root / MCP_LAUNCHER_PATH).resolve()))
        for agent in mcp_agents:
            mcp_targets.append(str((project_root / agent.mcp_config_path()).resolve()))
            if not dry_run:
                agent.install_mcp(
                    project_root,
                    "python-pop",
                    command,
                    args,
                    {INSPECTION_ALLOWED_ROOT_ENV: "."},
                    server_project_root=".",
                )

    return guideline_targets, skill_targets, mcp_targets


def run_install(args) -> int:
    project_root = Path(args.project_root).resolve()
    store = ConfigStore(project_root)
    existing = store.load()
    interactive = is_interactive(args.no_interaction)
    display = InstallDisplay()

    display.header("Install Preview" if args.dry_run else "Install", project_root.name)

    guidelines_enabled, skills_enabled, mcp_enabled = _resolve_features(args, existing)
    agents = _resolve_agents(project_root, args, existing, interactive)
    selected_packages = _resolve_external_packages(project_root, args, existing, interactive)
    inspection = inspect_project(project_root, selected_external=selected_packages)

    if not _confirm_framework_discovery(inspection, interactive=interactive, force=args.force):
        return 1

    guideline_targets, skill_targets, mcp_targets = execute_install(
        project_root=project_root,
        guidelines_enabled=guidelines_enabled,
        skills_enabled=skills_enabled,
        mcp_enabled=mcp_enabled,
        include_planned=args.include_planned,
        force=args.force,
        dry_run=args.dry_run,
        agents=agents,
        selected_packages=selected_packages,
        previous_skill_names=existing.skills,
    )

    skill_names = sorted(SkillComposer(inspection).skills()) if skills_enabled else existing.skills
    config = PythonPopConfig(
        agents=[agent.name() for agent in agents],
        framework=inspection.framework,
        frameworks=[module.slug for module in inspection.framework_modules],
        guidelines=guidelines_enabled,
        mcp=mcp_enabled,
        packages=selected_packages,
        skills=skill_names,
    )

    display.summary(
        project_name=project_root.name,
        guideline_targets=guideline_targets,
        skill_targets=skill_targets,
        mcp_targets=mcp_targets,
        dry_run=args.dry_run,
    )

    if args.dry_run:
        display.section("Planned Writes")
        for path in guideline_targets + skill_targets + mcp_targets:
            print(path)
        print(str(store.path))
        return 0

    store.save(config)
    display.section("Complete")
    print(f"Configured Python Pop for {project_root}")
    return 0
