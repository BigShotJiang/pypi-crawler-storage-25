from __future__ import annotations

from pathlib import Path
import tempfile

from ..frameworks.detector import inspect_project
from ..install.skill_composer import SkillComposer
from ..install.skill_writer import SkillWriter
from ..python_pop_manager import PythonPopManager
from ..skills.remote import GitHubRepository, GitHubSkillProvider, SkillAuditor
from ..support.config import ConfigStore
from ..support.prompts import is_interactive, multiselect
from ..install.agents.agent import Agent


def run_add_skill(args) -> int:
    project_root = Path(args.project_root).resolve()
    interactive = is_interactive(args.no_interaction)
    repo_input = args.repo or (input("GitHub repository (owner/repo or URL): ").strip() if interactive else "")
    if not repo_input:
        print("A GitHub repository is required.")
        return 1

    repository = GitHubRepository.from_input(repo_input)
    provider = GitHubSkillProvider(repository)
    available = provider.discover_skills()
    if not available:
        print("No valid skills were found in the repository.")
        return 1

    if args.list:
        for name in sorted(available):
            print(name)
        return 0

    if args.all:
        selected = list(available.keys())
    elif args.skill:
        selected = [name for name in args.skill if name in available]
    else:
        selected = multiselect(
            "Which remote skills should be installed?",
            {name: name for name in available},
            list(available.keys()),
            interactive=interactive,
            required=True,
        )

    if not selected:
        print("No skills selected.")
        return 0

    installed: list[str] = []
    auditor = SkillAuditor()
    skills_root = project_root / ".ai" / "skills"
    skills_root.mkdir(parents=True, exist_ok=True)

    for name in selected:
        target = skills_root / name
        if target.exists() and not args.force:
            print(f"Skipping existing skill: {name}")
            continue
        with tempfile.TemporaryDirectory() as tmpdir:
            staging = Path(tmpdir) / name
            if not provider.download_skill(available[name], staging):
                print(f"Failed to download skill: {name}")
                continue
            if not args.skip_audit:
                auditor.audit_directory(staging)
            if target.exists():
                import shutil
                shutil.rmtree(target)
            import shutil
            shutil.copytree(staging, target)
            installed.append(name)

    if not installed:
        return 0

    print("Installed skills:")
    for name in installed:
        print(f"- {name}")

    store = ConfigStore(project_root)
    if store.exists() and store.is_valid():
        config = store.load()
        previous_names = list(config.skills)
        for name in installed:
            if name not in config.skills:
                config.skills.append(name)
        store.save(config)

        inspection = inspect_project(project_root, selected_external=config.packages)
        skills = SkillComposer(inspection).skills()
        manager = PythonPopManager()
        for agent_name in config.agents:
            agent = Agent.from_name(manager, agent_name)
            if agent is None:
                continue
            SkillWriter(agent).sync(project_root, skills, previous_names)

    return 0
