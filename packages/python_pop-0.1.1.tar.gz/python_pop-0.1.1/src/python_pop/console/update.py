from __future__ import annotations

from pathlib import Path

from ..frameworks.detector import build_project_context, inspect_project
from ..frameworks.registry import ModuleRegistry
from ..install.agents.agent import Agent
from ..install.skill_composer import SkillComposer
from ..python_pop_manager import PythonPopManager
from ..support.config import ConfigStore
from .install import execute_install


def run_update(args) -> int:
    project_root = Path(args.project_root).resolve()
    store = ConfigStore(project_root)
    if not store.is_valid() or not store.exists():
        print("Please run `python-pop install` first.")
        return 1

    config = store.load()
    registry = ModuleRegistry()
    project = build_project_context(project_root)
    selected_packages = list(config.packages)

    if args.discover:
        discovered = registry.discover_available_external_modules(project)
        for module in discovered:
            if module.slug not in selected_packages:
                selected_packages.append(module.slug)

    agents: list[Agent] = []
    manager = PythonPopManager()
    for name in config.agents:
        instance = Agent.from_name(manager, name)
        if instance is not None:
            agents.append(instance)

    execute_install(
        project_root=project_root,
        guidelines_enabled=config.guidelines,
        skills_enabled=not args.ignore_skills,
        mcp_enabled=config.mcp,
        include_planned=args.include_planned,
        force=True,
        dry_run=args.dry_run,
        agents=agents,
        selected_packages=selected_packages,
        previous_skill_names=config.skills,
    )

    config.packages = selected_packages
    if not args.ignore_skills:
        inspection = inspect_project(project_root, selected_external=selected_packages)
        config.skills = sorted(SkillComposer(inspection).skills())
    if not args.dry_run:
        store.save(config)
        print("Python Pop guidelines and skills updated successfully.")
    return 0
