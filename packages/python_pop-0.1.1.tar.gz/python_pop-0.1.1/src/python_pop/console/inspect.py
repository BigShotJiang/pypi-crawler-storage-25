from __future__ import annotations

from pathlib import Path

from ..frameworks.detector import inspect_project


def run_inspect(project_root: Path, as_json: bool, selected_external: list[str] | None = None) -> int:
    inspection = inspect_project(project_root, selected_external=selected_external)
    if as_json:
        print(inspection.to_json())
        return 0

    print(f"Project: {inspection.project_name}")
    print(f"Root: {inspection.project_root}")
    print(f"Framework: {inspection.framework_display_name or 'Unknown'}")
    print(f"Application style: {inspection.application_style}")
    print(f"Blueprint style: {inspection.blueprint_style}")
    print(f"CLI style: {inspection.cli_style}")
    print(f"Custom JSON provider: {'yes' if inspection.custom_json_provider else 'no'}")
    print("")
    print("Selected modules:")
    for module in inspection.modules:
        suffix = f" ({module.version})" if module.version else ""
        print(f"- {module.slug}{suffix} [{module.category}]")
    return 0

