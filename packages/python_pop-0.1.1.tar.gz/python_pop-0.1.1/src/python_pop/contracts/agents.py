from __future__ import annotations

from typing import Protocol


class SupportsGuidelines(Protocol):
    def guidelines_path(self) -> str:
        ...

    def frontmatter(self) -> bool:
        ...

    def transform_guidelines(self, markdown: str) -> str:
        ...


class SupportsSkills(Protocol):
    def skills_path(self) -> str:
        ...


class SupportsMcp(Protocol):
    def mcp_config_path(self) -> str | None:
        ...

    def mcp_config_key(self) -> str:
        ...

    def default_mcp_config(self) -> dict[str, object]:
        ...

    def mcp_server_config(self, command: str, args: list[str], env: dict[str, str], project_root: str) -> dict[str, object]:
        ...

    def http_mcp_server_config(self, url: str) -> dict[str, object]:
        ...

