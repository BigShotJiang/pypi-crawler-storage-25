from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RemoteSkill:
    name: str
    repo: str
    path: str

