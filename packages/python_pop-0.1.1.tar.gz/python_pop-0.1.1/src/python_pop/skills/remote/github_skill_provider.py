from __future__ import annotations

import json
from pathlib import Path
from urllib import request

from ...support.security import path_within_root
from .github_repository import GitHubRepository
from .remote_skill import RemoteSkill


class GitHubSkillProvider:
    PROVENANCE_FILE = ".python-pop-provenance.json"

    def __init__(self, repository: GitHubRepository):
        self.repository = repository
        self._tree_cache: dict[str, object] | None = None
        self._branch_cache: str | None = None
        self._ref_cache: str | None = None

    def discover_skills(self) -> dict[str, RemoteSkill]:
        tree = self._fetch_repository_tree()
        items = tree.get("tree", [])
        prefix = f"{self.repository.path}/" if self.repository.path else ""
        skills: dict[str, RemoteSkill] = {}
        for item in items:
            if item.get("type") != "blob":
                continue
            path = str(item.get("path", ""))
            if prefix and not path.startswith(prefix):
                continue
            if Path(path).name != "SKILL.md":
                continue
            parent = str(Path(path).parent)
            if prefix and "/" in parent[len(prefix) :].strip("/"):
                continue
            skill = RemoteSkill(name=Path(parent).name, repo=self.repository.full_name(), path=parent)
            skills[skill.name] = skill
        return skills

    def download_skill(self, skill: RemoteSkill, target_path: str | Path) -> bool:
        tree = self._fetch_repository_tree()
        items = tree.get("tree", [])
        prefix = skill.path.rstrip("/") + "/"
        files = [item for item in items if str(item.get("path", "")).startswith(prefix) and item.get("type") == "blob"]
        if not files:
            return False

        target = Path(target_path)
        target.mkdir(parents=True, exist_ok=True)
        for item in files:
            full_path = str(item["path"])
            relative = full_path[len(prefix) :]
            destination = self._safe_destination(target, relative)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(self._download_raw_file(full_path))
        self._write_provenance(target, skill)
        return True

    def _fetch_repository_tree(self) -> dict[str, object]:
        if self._tree_cache is not None:
            return self._tree_cache
        ref = self._resolve_ref()
        url = f"https://api.github.com/repos/{self.repository.owner}/{self.repository.repo}/git/trees/{ref}?recursive=1"
        payload = self._read_json(url)
        if not isinstance(payload, dict) or "tree" not in payload:
            raise RuntimeError("Invalid response from GitHub tree API.")
        self._tree_cache = payload
        return payload

    def _resolve_default_branch(self) -> str:
        if self._branch_cache is not None:
            return self._branch_cache
        url = f"https://api.github.com/repos/{self.repository.owner}/{self.repository.repo}"
        payload = self._read_json(url)
        branch = payload.get("default_branch")
        if not isinstance(branch, str) or not branch:
            raise RuntimeError("Failed to resolve default branch from GitHub.")
        self._branch_cache = branch
        return branch

    def _resolve_ref(self) -> str:
        if self._ref_cache is not None:
            return self._ref_cache
        branch = self._resolve_default_branch()
        url = f"https://api.github.com/repos/{self.repository.owner}/{self.repository.repo}/branches/{branch}"
        payload = self._read_json(url)
        commit = payload.get("commit", {}) if isinstance(payload, dict) else {}
        ref = commit.get("sha") if isinstance(commit, dict) else None
        if not isinstance(ref, str) or not ref:
            raise RuntimeError("Failed to resolve immutable ref from GitHub.")
        self._ref_cache = ref
        return ref

    def _download_raw_file(self, path: str) -> bytes:
        url = f"https://raw.githubusercontent.com/{self.repository.owner}/{self.repository.repo}/{self._resolve_ref()}/{path.lstrip('/')}"
        with request.urlopen(self._request(url), timeout=30) as response:  # noqa: S310
            return response.read()

    def _read_json(self, url: str) -> dict[str, object]:
        with request.urlopen(self._request(url), timeout=30) as response:  # noqa: S310
            return json.loads(response.read().decode("utf-8"))

    def _request(self, url: str) -> request.Request:
        return request.Request(url, headers={"Accept": "application/vnd.github.v3+json", "User-Agent": "python-pop"})

    def _safe_destination(self, target_root: Path, relative_path: str) -> Path:
        destination = (target_root.resolve() / relative_path).resolve()
        if not path_within_root(destination, target_root.resolve()):
            raise ValueError("Remote skill file path escapes the skill root.")
        return destination

    def _write_provenance(self, target: Path, skill: RemoteSkill) -> None:
        payload = {
            "provider": "github",
            "repo": self.repository.full_name(),
            "source": self.repository.source(),
            "skill": skill.name,
            "path": skill.path,
            "ref": self._resolve_ref(),
        }
        (target / self.PROVENANCE_FILE).write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
