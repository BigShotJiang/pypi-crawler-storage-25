from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass(frozen=True)
class GitHubRepository:
    owner: str
    repo: str
    path: str = ""

    @classmethod
    def from_input(cls, value: str) -> "GitHubRepository":
        normalized = value.strip()
        if normalized.startswith(("http://", "https://")):
            parsed = urlparse(normalized)
            if parsed.netloc != "github.com":
                raise ValueError("Only GitHub URLs are supported.")
            normalized = parsed.path.strip("/")
            if "/tree/" in normalized:
                normalized = normalized.split("/tree/", 1)[0]

        parts = [chunk for chunk in normalized.split("/") if chunk]
        if len(parts) < 2:
            raise ValueError("Expected owner/repo, owner/repo/path, or GitHub URL.")
        return cls(owner=parts[0], repo=parts[1], path="/".join(parts[2:]))

    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}"

    def source(self) -> str:
        return self.full_name() if not self.path else f"{self.full_name()}/{self.path}"

