from __future__ import annotations

from pathlib import Path
import re

from ...support.security import path_within_root


class SkillAuditor:
    VALID_NAME = re.compile(r"^[a-z0-9][a-z0-9-]*$")
    MAX_FILE_BYTES = 262_144
    MAX_TOTAL_BYTES = 1_048_576

    def audit_directory(self, skill_path: str | Path) -> None:
        path = Path(skill_path).resolve()
        if not path.exists():
            raise ValueError("Skill path does not exist.")
        if not self.VALID_NAME.match(path.name):
            raise ValueError(f"Invalid skill directory name: {path.name}")

        skill_file = path / "SKILL.md"
        if not skill_file.exists():
            raise ValueError("Downloaded skill is missing SKILL.md.")

        content = skill_file.read_text(encoding="utf-8")
        if not content.lstrip().startswith("---"):
            raise ValueError("Downloaded skill is missing frontmatter.")

        total_bytes = 0
        for entry in sorted(path.rglob("*")):
            if entry.is_symlink():
                raise ValueError("Downloaded skill contains symlinks.")
            if entry.is_dir():
                continue
            if not path_within_root(entry.resolve(), path):
                raise ValueError("Downloaded skill contains files outside the skill root.")

            payload = entry.read_bytes()
            total_bytes += len(payload)
            if len(payload) > self.MAX_FILE_BYTES:
                raise ValueError("Downloaded skill contains an oversized file.")
            if total_bytes > self.MAX_TOTAL_BYTES:
                raise ValueError("Downloaded skill exceeds the maximum total size.")
            if b"\x00" in payload:
                raise ValueError("Downloaded skill contains binary content.")
            try:
                payload.decode("utf-8")
            except UnicodeDecodeError as exc:
                raise ValueError("Downloaded skill contains non-text content.") from exc
