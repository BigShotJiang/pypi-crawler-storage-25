from __future__ import annotations

from .tools import (
    InspectDjangoProjectTool,
    InspectFlaskConfigTool,
    FastApiNotImplementedTool,
    InspectProjectTool,
    ListDjangoManagementCommandsTool,
    ListDjangoRoutesTool,
    ListFlaskBlueprintsTool,
    ListFlaskCliCommandsTool,
    ListFlaskExtensionsTool,
    ListFlaskRoutesTool,
    ListGuidelinesTool,
    ListModulesTool,
    MasoniteNotImplementedTool,
)


class ToolRegistry:
    def __init__(self) -> None:
        self._tools = {
            tool.name: tool
            for tool in [
                InspectProjectTool(),
                InspectDjangoProjectTool(),
                ListModulesTool(),
                ListGuidelinesTool(),
                ListFlaskRoutesTool(),
                ListFlaskBlueprintsTool(),
                ListFlaskCliCommandsTool(),
                ListFlaskExtensionsTool(),
                InspectFlaskConfigTool(),
                ListDjangoRoutesTool(),
                ListDjangoManagementCommandsTool(),
                FastApiNotImplementedTool(),
                MasoniteNotImplementedTool(),
            ]
        }

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def get(self, name: str):
        return self._tools.get(name)

    def describe(self) -> list[dict[str, object]]:
        return [tool.describe() for tool in self._tools.values()]
