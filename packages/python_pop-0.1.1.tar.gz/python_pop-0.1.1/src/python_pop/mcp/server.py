from __future__ import annotations

import json
import sys

from .tool_registry import ToolRegistry


class StdioMcpServer:
    def __init__(self, registry: ToolRegistry | None = None):
        self.registry = registry or ToolRegistry()

    def serve(self) -> int:
        for raw_line in sys.stdin:
            response = self._handle_line(raw_line)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()
        return 0

    def _handle_line(self, raw_line: str) -> dict[str, object] | None:
        line = raw_line.strip()
        if not line:
            return None
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            return self._error(None, "Invalid JSON payload.")
        if not isinstance(message, dict):
            return self._error(None, "JSON-RPC message must be an object.")
        try:
            return self._handle_message(message)
        except Exception as exc:  # noqa: BLE001
            return self._error(message.get("id"), f"Internal server error: {exc}")

    def _handle_message(self, message: dict[str, object]) -> dict[str, object] | None:
        method = message.get("method")
        request_id = message.get("id")
        params = message.get("params", {})

        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "python-pop", "version": "0.1.0"},
                },
            }
        if method == "notifications/initialized":
            return None
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": self.registry.describe()}}
        if method == "tools/call":
            if not isinstance(params, dict):
                return self._error(request_id, "Invalid tool call parameters.")
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            tool = self.registry.get(str(tool_name))
            if tool is None:
                return self._error(request_id, f"Unknown tool: {tool_name}")
            try:
                result = tool.execute(arguments if isinstance(arguments, dict) else {})
            except Exception as exc:  # noqa: BLE001
                return self._error(request_id, f"Tool execution failed: {exc}")
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [{"type": "text", "text": json.dumps(result, indent=2, sort_keys=True)}],
                    "isError": False,
                },
            }
        return self._error(request_id, f"Unknown method: {method}")

    def _error(self, request_id: object, message: str) -> dict[str, object]:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32000, "message": message},
        }
