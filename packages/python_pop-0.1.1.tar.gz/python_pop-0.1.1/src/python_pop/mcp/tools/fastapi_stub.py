from __future__ import annotations

from .base import Tool


class FastApiNotImplementedTool(Tool):
    name = "list_fastapi_routes"
    description = "Placeholder tool for future FastAPI route inspection."
    input_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"message": "FastAPI route inspection is not implemented yet."}

