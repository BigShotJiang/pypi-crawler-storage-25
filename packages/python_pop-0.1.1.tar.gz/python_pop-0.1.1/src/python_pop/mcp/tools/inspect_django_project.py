from __future__ import annotations

from ...frameworks.detector import inspect_project
from .base import Tool


class InspectDjangoProjectTool(Tool):
    name = "inspect_django_project"
    description = "Inspect the current Django project and report detected modules and project shape."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        inspection = inspect_project(self.project_root(arguments))
        if inspection.framework != "django":
            raise ValueError("Project is not detected as Django.")
        return inspection.to_dict()
