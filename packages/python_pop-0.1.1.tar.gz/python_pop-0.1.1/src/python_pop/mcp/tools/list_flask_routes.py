from __future__ import annotations

from ...frameworks.detector import discover_flask_routes
from .base import Tool


class ListFlaskRoutesTool(Tool):
    name = "list_flask_routes"
    description = "List statically discovered Flask route decorators in the project."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"routes": discover_flask_routes(self.project_root(arguments))}
