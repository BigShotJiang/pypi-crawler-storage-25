from __future__ import annotations

from .base import Tool


class MasoniteNotImplementedTool(Tool):
    name = "list_masonite_routes"
    description = "Placeholder tool for future Masonite route inspection."
    input_schema = {"type": "object", "properties": {}, "required": []}

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"message": "Masonite route inspection is not implemented yet."}

