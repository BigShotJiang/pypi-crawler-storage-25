from __future__ import annotations

from ...frameworks.detector import inspect_project
from ...install.guideline_composer import GuidelineComposer
from .base import Tool


class ListGuidelinesTool(Tool):
    name = "list_guidelines"
    description = "List the guideline assets and composed modules for the current project."
    input_schema = {
        "type": "object",
        "properties": {
            "project_root": {"type": "string"},
            "include_planned": {"type": "boolean"},
        },
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        inspection = inspect_project(self.project_root(arguments))
        composed = GuidelineComposer(inspection, include_planned=bool(arguments.get("include_planned", False))).compose()
        return {
            "used_modules": composed.used_modules,
            "asset_paths": composed.asset_paths,
        }
