from __future__ import annotations

from ...frameworks.detector import discover_flask_extensions
from .base import Tool


class ListFlaskExtensionsTool(Tool):
    name = "list_flask_extensions"
    description = "Summarize statically discovered Flask extensions and initialization style."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"extensions": discover_flask_extensions(self.project_root(arguments))}
