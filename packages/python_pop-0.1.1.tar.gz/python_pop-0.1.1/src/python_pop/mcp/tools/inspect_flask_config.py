from __future__ import annotations

from ...frameworks.detector import inspect_flask_config
from .base import Tool


class InspectFlaskConfigTool(Tool):
    name = "inspect_flask_config"
    description = "Inspect statically discovered Flask config keys and config loaders."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return inspect_flask_config(self.project_root(arguments))
