from __future__ import annotations

from ...frameworks.detector import inspect_project
from .base import Tool


class InspectProjectTool(Tool):
    name = "inspect_project"
    description = "Inspect the current Python project and report the detected framework and modules."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        inspection = inspect_project(self.project_root(arguments))
        return inspection.to_dict()
