from __future__ import annotations

from ...frameworks.detector import discover_flask_cli_commands
from .base import Tool


class ListFlaskCliCommandsTool(Tool):
    name = "list_flask_cli_commands"
    description = "List statically discovered Flask CLI commands in the project."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"commands": discover_flask_cli_commands(self.project_root(arguments))}
