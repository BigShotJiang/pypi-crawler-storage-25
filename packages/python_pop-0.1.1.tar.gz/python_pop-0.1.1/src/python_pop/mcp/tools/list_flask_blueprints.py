from __future__ import annotations

from ...frameworks.detector import discover_flask_blueprints
from .base import Tool


class ListFlaskBlueprintsTool(Tool):
    name = "list_flask_blueprints"
    description = "List statically discovered Flask blueprints and their registrations."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"blueprints": discover_flask_blueprints(self.project_root(arguments))}
