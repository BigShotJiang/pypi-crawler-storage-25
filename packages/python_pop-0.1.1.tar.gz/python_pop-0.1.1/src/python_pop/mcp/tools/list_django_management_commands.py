from __future__ import annotations

from ...frameworks.detector import discover_django_management_commands
from .base import Tool


class ListDjangoManagementCommandsTool(Tool):
    name = "list_django_management_commands"
    description = "List statically discovered Django management commands in the project."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"commands": discover_django_management_commands(self.project_root(arguments))}
