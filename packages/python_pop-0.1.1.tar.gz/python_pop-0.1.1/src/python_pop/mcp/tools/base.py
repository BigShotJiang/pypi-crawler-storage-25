from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from ...support.security import configured_allowed_root, ensure_within_allowed_root


class Tool(ABC):
    name: str
    description: str
    input_schema: dict[str, object]

    @abstractmethod
    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        raise NotImplementedError

    def describe(self) -> dict[str, object]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }

    def project_root(self, arguments: dict[str, object]) -> Path:
        project_root = arguments.get("project_root")
        if not isinstance(project_root, str) or not project_root.strip():
            raise ValueError("project_root is required.")
        return ensure_within_allowed_root(project_root, allowed_root=configured_allowed_root())
