from __future__ import annotations

from ...frameworks.detector import inspect_project
from .base import Tool


class ListModulesTool(Tool):
    name = "list_modules"
    description = "List the Python Pop modules selected for the current project."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        inspection = inspect_project(self.project_root(arguments))
        return {"modules": [module.to_dict() for module in inspection.modules]}
