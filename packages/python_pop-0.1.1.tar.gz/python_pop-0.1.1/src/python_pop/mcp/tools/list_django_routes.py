from __future__ import annotations

from ...frameworks.detector import discover_django_routes
from .base import Tool


class ListDjangoRoutesTool(Tool):
    name = "list_django_routes"
    description = "List statically discovered Django URL patterns in the project."
    input_schema = {
        "type": "object",
        "properties": {"project_root": {"type": "string"}},
        "required": ["project_root"],
    }

    def execute(self, arguments: dict[str, object]) -> dict[str, object]:
        return {"routes": discover_django_routes(self.project_root(arguments))}
