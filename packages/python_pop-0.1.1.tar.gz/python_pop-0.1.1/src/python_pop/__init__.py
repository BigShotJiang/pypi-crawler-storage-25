"""Python Pop tooling for AI-assisted development in Python web applications."""

from __future__ import annotations

__all__ = ["PythonPop", "PythonPopManager", "init_app", "__version__"]

__version__ = "0.1.0"


def __getattr__(name: str):
    if name in {"PythonPop", "init_app"}:
        from .extension import PythonPop, init_app

        return {"PythonPop": PythonPop, "init_app": init_app}[name]
    if name == "PythonPopManager":
        from .python_pop_manager import PythonPopManager

        return PythonPopManager
    raise AttributeError(name)
