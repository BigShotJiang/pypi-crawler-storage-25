from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from .flask_cli import flask_cli

if TYPE_CHECKING:
    from flask import Flask


class PythonPop:
    def __init__(self, project_root: str | Path | None = None):
        self.project_root = Path(project_root).resolve() if project_root else None

    def init_app(self, app: "Flask") -> None:
        resolved_root = self.project_root or Path(app.root_path).resolve().parent
        app.extensions["python_pop"] = self
        app.config.setdefault("PYTHON_POP_PROJECT_ROOT", str(resolved_root))

        if flask_cli.name not in app.cli.commands:
            app.cli.add_command(flask_cli)


def init_app(app: "Flask", project_root: str | Path | None = None) -> PythonPop:
    extension = PythonPop(project_root=project_root)
    extension.init_app(app)
    return extension
