from __future__ import annotations

from .frameworks.base import ModuleAsset, ModuleSelection

__all__ = ["ModuleAsset", "ModuleSelection"]
