from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .base import FrameworkModule, ModuleAsset, ModuleSelection


def _normalize_package(name: str) -> str:
    return name.lower().replace("_", "-").replace(".", "-")


def _pick_version_asset(version: str | None, mapping: list[tuple[str, str, bool]]) -> tuple[str | None, bool]:
    if not version:
        return None, False
    normalized = version.strip()
    for prefix, asset, planned in mapping:
        if normalized.startswith(prefix):
            return asset, planned
    return None, False


@dataclass
class BuiltinModule(FrameworkModule):
    slug: str
    display_name: str
    category: str
    matcher: Callable[["ProjectContext"], bool]
    selector: Callable[["ProjectContext"], ModuleSelection]
    source: str = "builtin"

    def matches(self, project: "ProjectContext") -> bool:
        return self.matcher(project)

    def select(self, project: "ProjectContext") -> ModuleSelection | None:
        if not self.matches(project):
            return None
        return self.selector(project)


def _static_selection(
    slug: str,
    display_name: str,
    category: str,
    assets: list[ModuleAsset],
    skill_directories: list[str] | None = None,
    version: str | None = None,
) -> ModuleSelection:
    return ModuleSelection(
        slug=slug,
        display_name=display_name,
        category=category,
        version=version,
        assets=tuple(assets),
        skill_directories=tuple(skill_directories or []),
    )


def _framework_selector(slug: str, display_name: str, asset_root: str, version_map: list[tuple[str, str, bool]], skill_dir: str | None = None):
    def select(project: "ProjectContext") -> ModuleSelection:
        assets = [ModuleAsset(f"{asset_root}/core.md")]
        version = project.package_version(slug) or project.package_version(display_name)
        version_asset, planned = _pick_version_asset(version, version_map)
        if version_asset is not None:
            assets.append(ModuleAsset(version_asset, planned=planned))
        skills = [skill_dir] if skill_dir else []
        return _static_selection(slug, display_name, "framework", assets, skills, version)

    return select


def _dependency_selector(slug: str, display_name: str, asset_root: str, package_name: str, version_map: list[tuple[str, str, bool]], skill_dir: str | None = None):
    def select(project: "ProjectContext") -> ModuleSelection:
        assets = [ModuleAsset(f"{asset_root}/core.md")]
        version = project.package_version(package_name)
        version_asset, planned = _pick_version_asset(version, version_map)
        if version_asset is not None:
            assets.append(ModuleAsset(version_asset, planned=planned))
        return ModuleSelection(
            slug=slug,
            display_name=display_name,
            category="package",
            version=version,
            assets=tuple(assets),
            skill_directories=tuple([skill_dir] if skill_dir else []),
            metadata={"package": package_name},
        )

    return select


def builtin_modules() -> list[FrameworkModule]:
    return [
        BuiltinModule(
            slug="foundation",
            display_name="Foundation",
            category="core",
            matcher=lambda project: True,
            selector=lambda project: _static_selection(
                "foundation",
                "Foundation",
                "core",
                [ModuleAsset("foundation.md")],
            ),
        ),
        BuiltinModule(
            slug="python-pop",
            display_name="Python Pop",
            category="core",
            matcher=lambda project: True,
            selector=lambda project: _static_selection(
                "python-pop",
                "Python Pop",
                "core",
                [ModuleAsset("python-pop/core.md")],
                ["python-pop/skill/python-pop-development"],
            ),
        ),
        BuiltinModule(
            slug="python",
            display_name="Python",
            category="core",
            matcher=lambda project: True,
            selector=lambda project: _static_selection(
                "python",
                "Python",
                "core",
                [ModuleAsset("python/core.md")],
                ["python/skill/python-best-practices"],
            ),
        ),
        BuiltinModule(
            slug="flask",
            display_name="Flask",
            category="framework",
            matcher=lambda project: project.has_package("flask") or project.source_contains("Flask(") or project.source_contains("from flask"),
            selector=_framework_selector(
                "flask",
                "Flask",
                "flask",
                [("2.3", "flask/2.3/core.md", False), ("3", "flask/3/core.md", True)],
                "flask/skill/flask-development",
            ),
        ),
        BuiltinModule(
            slug="django",
            display_name="Django",
            category="framework",
            matcher=lambda project: project.has_package("django") or project.source_contains("from django") or project.source_contains("django."),
            selector=_framework_selector(
                "django",
                "Django",
                "django",
                [("4.2", "django/4.2/core.md", False), ("5", "django/5.0/core.md", True)],
                "django/skill/django-development",
            ),
        ),
        BuiltinModule(
            slug="django-rest-framework",
            display_name="Django REST Framework",
            category="package",
            matcher=lambda project: project.has_package("djangorestframework"),
            selector=_dependency_selector(
                "django-rest-framework",
                "Django REST Framework",
                "django-rest-framework",
                "djangorestframework",
                [("3.14", "django-rest-framework/3.14/core.md", False), ("3.15", "django-rest-framework/3.15/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="pytest-django",
            display_name="pytest-django",
            category="testing",
            matcher=lambda project: project.has_package("pytest-django"),
            selector=_dependency_selector(
                "pytest-django",
                "pytest-django",
                "pytest-django",
                "pytest-django",
                [("4.8", "pytest-django/4.8/core.md", False), ("5", "pytest-django/5.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="fastapi",
            display_name="FastAPI",
            category="framework",
            matcher=lambda project: project.has_package("fastapi") or project.source_contains("FastAPI(") or project.source_contains("from fastapi"),
            selector=lambda project: _static_selection(
                "fastapi",
                "FastAPI",
                "framework",
                [ModuleAsset("fastapi/core.md")],
                ["fastapi/skill/fastapi-development"],
                project.package_version("fastapi"),
            ),
        ),
        BuiltinModule(
            slug="masonite",
            display_name="Masonite",
            category="framework",
            matcher=lambda project: project.has_package("masonite") or project.source_contains("from masonite") or project.source_contains("Masonite"),
            selector=lambda project: _static_selection(
                "masonite",
                "Masonite",
                "framework",
                [ModuleAsset("masonite/core.md")],
                ["masonite/skill/masonite-development"],
                project.package_version("masonite"),
            ),
        ),
        BuiltinModule(
            slug="flask-sqlalchemy",
            display_name="Flask-SQLAlchemy",
            category="package",
            matcher=lambda project: project.has_package("flask-sqlalchemy"),
            selector=_dependency_selector(
                "flask-sqlalchemy",
                "Flask-SQLAlchemy",
                "flask-sqlalchemy",
                "flask-sqlalchemy",
                [("3.0", "flask-sqlalchemy/3.0/core.md", False), ("3.1", "flask-sqlalchemy/3.1/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="sqlalchemy",
            display_name="SQLAlchemy",
            category="package",
            matcher=lambda project: project.has_package("sqlalchemy"),
            selector=_dependency_selector(
                "sqlalchemy",
                "SQLAlchemy",
                "sqlalchemy",
                "sqlalchemy",
                [("1.4", "sqlalchemy/1.4/core.md", False), ("2", "sqlalchemy/2.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="flask-jwt-extended",
            display_name="Flask-JWT-Extended",
            category="package",
            matcher=lambda project: project.has_package("flask-jwt-extended"),
            selector=_dependency_selector(
                "flask-jwt-extended",
                "Flask-JWT-Extended",
                "flask-jwt-extended",
                "flask-jwt-extended",
                [("4.4", "flask-jwt-extended/4.4/core.md", False), ("5", "flask-jwt-extended/5.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="flask-migrate",
            display_name="Flask-Migrate",
            category="package",
            matcher=lambda project: project.has_package("flask-migrate"),
            selector=_dependency_selector(
                "flask-migrate",
                "Flask-Migrate",
                "flask-migrate",
                "flask-migrate",
                [("3.1", "flask-migrate/3.1/core.md", False), ("4", "flask-migrate/4.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="flask-cors",
            display_name="Flask-CORS",
            category="package",
            matcher=lambda project: project.has_package("flask-cors"),
            selector=_dependency_selector(
                "flask-cors",
                "Flask-CORS",
                "flask-cors",
                "flask-cors",
                [("5.0", "flask-cors/5.0/core.md", False), ("6", "flask-cors/6.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="flask-mail",
            display_name="Flask-Mail",
            category="package",
            matcher=lambda project: project.has_package("flask-mail"),
            selector=_dependency_selector(
                "flask-mail",
                "Flask-Mail",
                "flask-mail",
                "flask-mail",
                [("0.9", "flask-mail/0.9/core.md", False), ("1", "flask-mail/1.0/core.md", True)],
            ),
        ),
        BuiltinModule(
            slug="pytest",
            display_name="pytest",
            category="testing",
            matcher=lambda project: project.has_package("pytest") or project.path_exists("pytest.ini") or project.path_exists("tests"),
            selector=lambda project: _static_selection(
                "pytest",
                "pytest",
                "testing",
                [ModuleAsset("pytest/core.md")],
                ["pytest/skill/pytest-testing"],
                project.package_version("pytest"),
            ),
        ),
    ]
