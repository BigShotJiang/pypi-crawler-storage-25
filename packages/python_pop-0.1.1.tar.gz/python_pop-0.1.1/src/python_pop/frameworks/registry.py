from __future__ import annotations

from importlib import metadata
import inspect
from typing import Iterable

from .base import FrameworkModule, ModuleSelection
from .builtins import builtin_modules


def _load_entry_points(group: str) -> list[metadata.EntryPoint]:
    entry_points = metadata.entry_points()
    if hasattr(entry_points, "select"):
        return list(entry_points.select(group=group))
    return list(entry_points.get(group, []))


class ModuleRegistry:
    def __init__(self) -> None:
        self._builtins = builtin_modules()
        self._externals: list[FrameworkModule] | None = None

    def builtin_modules(self) -> list[FrameworkModule]:
        return list(self._builtins)

    def external_modules(self) -> list[FrameworkModule]:
        if self._externals is not None:
            return list(self._externals)

        loaded: list[FrameworkModule] = []
        for entry_point in _load_entry_points("python_pop.modules"):
            resolved = entry_point.load()
            candidates: Iterable[object]
            if inspect.isclass(resolved):
                candidates = [resolved()]
            elif callable(resolved) and not isinstance(resolved, FrameworkModule):
                maybe = resolved()
                if isinstance(maybe, FrameworkModule):
                    candidates = [maybe]
                elif isinstance(maybe, Iterable):
                    candidates = list(maybe)
                else:
                    candidates = []
            else:
                candidates = [resolved]

            for candidate in candidates:
                if isinstance(candidate, FrameworkModule):
                    loaded.append(candidate)

        self._externals = loaded
        return list(self._externals)

    def discover_available_external_modules(self, project: "ProjectContext") -> list[FrameworkModule]:
        return [module for module in self.external_modules() if module.matches(project)]

    def selected_modules(self, project: "ProjectContext", selected_external: list[str] | None = None) -> list[ModuleSelection]:
        selections: list[ModuleSelection] = []
        for module in self.builtin_modules():
            selection = module.select(project)
            if selection is not None:
                selections.append(selection)

        chosen = set(selected_external or [])
        for module in self.external_modules():
            if module.slug not in chosen:
                continue
            selection = module.select(project)
            if selection is not None:
                selections.append(selection)

        return selections

