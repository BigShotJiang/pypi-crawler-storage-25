from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .detector import ProjectContext


@dataclass(frozen=True)
class ModuleAsset:
    relative_path: str
    planned: bool = False


@dataclass(frozen=True)
class ModuleSelection:
    slug: str
    display_name: str
    category: str
    source: str = "builtin"
    version: str | None = None
    assets: tuple[ModuleAsset, ...] = ()
    skill_directories: tuple[str, ...] = ()
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "slug": self.slug,
            "display_name": self.display_name,
            "category": self.category,
            "source": self.source,
            "version": self.version,
            "assets": [
                {"relative_path": asset.relative_path, "planned": asset.planned}
                for asset in self.assets
            ],
            "skill_directories": list(self.skill_directories),
            "metadata": dict(self.metadata),
        }


class FrameworkModule(ABC):
    slug: str
    display_name: str
    category: str
    source: str = "builtin"

    @abstractmethod
    def matches(self, project: "ProjectContext") -> bool:
        raise NotImplementedError

    @abstractmethod
    def select(self, project: "ProjectContext") -> ModuleSelection | None:
        raise NotImplementedError

