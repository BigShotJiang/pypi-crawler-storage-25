from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re

from .base import ModuleSelection
from .registry import ModuleRegistry
from ..support.security import ensure_within_allowed_root


REQUIREMENT_RE = re.compile(
    r"^\s*(?P<name>[A-Za-z0-9_.-]+)\s*(?:(?:==|~=|>=|<=|>|<)\s*(?P<version>[^;\s#]+))?"
)


def _normalize_name(package_name: str) -> str:
    return re.sub(r"[-_.]+", "-", package_name).lower()


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


def _iter_python_files(root: Path) -> list[Path]:
    excluded_parts = {
        ".git",
        ".hg",
        ".mypy_cache",
        ".nox",
        ".pytest_cache",
        ".ruff_cache",
        ".tox",
        ".venv",
        "__pycache__",
        "build",
        "dist",
        "env",
        "envs",
        "node_modules",
        "site-packages",
        "venv",
    }
    files: list[Path] = []
    for current_root, dirnames, filenames in os.walk(root, followlinks=False):
        base = Path(current_root)
        dirnames[:] = [
            name
            for name in dirnames
            if name.lower() not in excluded_parts
            and not (base / name).is_symlink()
            and not (base / name / "pyvenv.cfg").exists()
        ]
        for filename in filenames:
            path = base / filename
            if path.suffix != ".py" or path.is_symlink():
                continue
            if any(part.lower() in excluded_parts for part in path.parts):
                continue
            files.append(path)
    return sorted(files)


def _extract_project_dependencies(pyproject_text: str) -> dict[str, str | None]:
    dependencies: dict[str, str | None] = {}

    for match in re.finditer(r'dependencies\s*=\s*\[(.*?)\]', pyproject_text, re.DOTALL):
        for dep in re.findall(r'["\']([A-Za-z0-9_.-]+)([^"\']*)["\']', match.group(1)):
            name, suffix = dep
            version_match = re.search(r'([<>=~!].+)', suffix.strip())
            dependencies[name] = version_match.group(1) if version_match else None

    poetry_match = re.search(r'^\[tool\.poetry\.dependencies\]\s*(.*?)^(?=\[|\Z)', pyproject_text, re.DOTALL | re.MULTILINE)
    if poetry_match:
        for line in poetry_match.group(1).splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or stripped.startswith("python"):
                continue
            if "=" not in stripped:
                continue
            name, raw = [item.strip() for item in stripped.split("=", 1)]
            name = name.strip('"').strip("'")
            raw = raw.split("#", 1)[0].strip()
            if raw.startswith("{"):
                version_match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', raw)
                dependencies[name] = version_match.group(1) if version_match else None
            else:
                dependencies[name] = raw.strip('"').strip("'")

    return dependencies


def _extract_lock_dependencies(root: Path) -> dict[str, str | None]:
    dependencies: dict[str, str | None] = {}

    poetry_lock = root / "poetry.lock"
    if poetry_lock.exists():
        text = poetry_lock.read_text(encoding="utf-8")
        for name, version in re.findall(r'name = "([^"]+)"\s*\nversion = "([^"]+)"', text):
            dependencies[name] = version

    pipfile_lock = root / "Pipfile.lock"
    if pipfile_lock.exists():
        payload = json.loads(pipfile_lock.read_text(encoding="utf-8"))
        for section in ("default", "develop"):
            values = payload.get(section, {})
            if isinstance(values, dict):
                for name, metadata in values.items():
                    if isinstance(metadata, dict):
                        dependencies[name] = str(metadata.get("version", "")).lstrip("=") or None

    return dependencies


def _parse_requirements(root: Path) -> dict[str, str | None]:
    requirements: dict[str, str | None] = {}
    candidates = list(root.glob("requirements*.txt")) + list((root / "requirements").glob("*.txt")) if (root / "requirements").exists() else list(root.glob("requirements*.txt"))

    for requirements_path in candidates:
        for raw_line in requirements_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            match = REQUIREMENT_RE.match(line)
            if not match:
                continue
            requirements[match.group("name")] = match.group("version")

    pyproject_path = root / "pyproject.toml"
    if pyproject_path.exists():
        requirements.update(_extract_project_dependencies(pyproject_path.read_text(encoding="utf-8")))

    requirements.update(_extract_lock_dependencies(root))
    return requirements


@dataclass(frozen=True)
class ProjectContext:
    root: Path
    project_name: str
    requirements: dict[str, str | None]
    python_texts: dict[Path, str]

    def has_package(self, package_name: str) -> bool:
        normalized = _normalize_name(package_name)
        return any(_normalize_name(name) == normalized for name in self.requirements)

    def package_version(self, package_name: str) -> str | None:
        normalized = _normalize_name(package_name)
        for name, version in self.requirements.items():
            if _normalize_name(name) == normalized:
                return version
        return None

    def path_exists(self, relative_path: str) -> bool:
        return (self.root / relative_path).exists()

    def source_contains(self, needle: str) -> bool:
        return any(needle in text for text in self.python_texts.values())


@dataclass(frozen=True)
class ProjectInspection:
    project_root: Path
    project_name: str
    framework: str | None
    framework_display_name: str | None
    modules: list[ModuleSelection]
    requirements: dict[str, str | None]
    application_style: str
    blueprint_style: str
    cli_style: str
    custom_json_provider: bool

    @property
    def framework_modules(self) -> list[ModuleSelection]:
        return [module for module in self.modules if module.category == "framework"]

    def template_context(self) -> dict[str, str]:
        framework = self.framework or "unknown"
        return {
            "project_name": self.project_name,
            "framework": framework,
            "framework_display_name": self.framework_display_name or "Unknown",
            "application_style": self.application_style,
            "blueprint_style": self.blueprint_style,
            "cli_style": self.cli_style,
            "custom_json_provider": "yes" if self.custom_json_provider else "no",
        }

    def to_dict(self) -> dict[str, object]:
        return {
            "project_root": str(self.project_root),
            "project_name": self.project_name,
            "framework": self.framework,
            "framework_display_name": self.framework_display_name,
            "frameworks": [
                {
                    "slug": module.slug,
                    "display_name": module.display_name,
                    "version": module.version,
                    "source": module.source,
                }
                for module in self.framework_modules
            ],
            "application_style": self.application_style,
            "blueprint_style": self.blueprint_style,
            "cli_style": self.cli_style,
            "custom_json_provider": self.custom_json_provider,
            "requirements": self.requirements,
            "modules": [module.to_dict() for module in self.modules],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)


def _select_primary_flask_text(python_texts: dict[Path, str]) -> str:
    best_text = ""
    best_score = -1
    best_depth = 10_000
    for path, text in python_texts.items():
        score = 0
        if "Flask(" in text:
            score += 3
        if "create_app(" in text:
            score += 3
        if "register_blueprint" in text:
            score += 1
        if "DefaultJSONProvider" in text:
            score += 1
        if ".cli.command" in text:
            score += 1
        if score > best_score or (score == best_score and len(path.parts) < best_depth):
            best_score = score
            best_depth = len(path.parts)
            best_text = text
    return best_text


def _aggregate_matching_text(python_texts: dict[Path, str], pattern: str) -> str:
    return "\n".join(text for text in python_texts.values() if pattern in text)


def _detect_application_style(app_init_text: str) -> str:
    if re.search(r"^\s*app\s*=\s*Flask\(", app_init_text, re.MULTILINE):
        return "module-global Flask application"
    if re.search(r"def\s+create_app\s*\(", app_init_text):
        return "application factory"
    if "FastAPI(" in app_init_text:
        return "module-global FastAPI application"
    return "unknown"


def _detect_blueprint_style(api_init_text: str, app_init_text: str) -> str:
    if "Blueprint(" in api_init_text and "register_blueprint" in app_init_text:
        return "blueprint modules detected and registered during application initialization"
    if "Blueprint(" in api_init_text:
        return "blueprint modules detected"
    return "no blueprint pattern detected"


def _detect_cli_style(commands_init_text: str) -> str:
    if "@app.cli.command" in commands_init_text or "app.cli.command(" in commands_init_text:
        return "Flask CLI commands detected"
    return "no CLI registration detected"


def _select_primary_django_text(python_texts: dict[Path, str]) -> str:
    best_text = ""
    best_score = -1
    best_depth = 10_000
    for path, text in python_texts.items():
        score = 0
        if path.name == "manage.py":
            score += 4
        if "DJANGO_SETTINGS_MODULE" in text:
            score += 3
        if "INSTALLED_APPS" in text:
            score += 3
        if "urlpatterns" in text:
            score += 2
        if "get_wsgi_application" in text or "get_asgi_application" in text:
            score += 1
        if score > best_score or (score == best_score and len(path.parts) < best_depth):
            best_score = score
            best_depth = len(path.parts)
            best_text = text
    return best_text


def _detect_django_application_style(project: ProjectContext, django_text: str) -> str:
    if project.path_exists("manage.py") and "DJANGO_SETTINGS_MODULE" in django_text:
        return "Django project with manage.py entrypoint and settings module"
    if project.path_exists("manage.py"):
        return "Django project with manage.py entrypoint"
    if "get_wsgi_application" in django_text or "get_asgi_application" in django_text:
        return "Django project module"
    return "Django project structure detected"


def _detect_django_url_style(python_texts: dict[Path, str]) -> str:
    if any("urlpatterns" in text and ("path(" in text or "re_path(" in text) for text in python_texts.values()):
        return "URL configuration modules detected"
    return "no URL configuration detected"


def _detect_django_cli_style(project: ProjectContext) -> str:
    commands = discover_django_management_commands(project.root, allowed_root=project.root)
    if project.path_exists("manage.py") and commands:
        return "Django manage.py entrypoint and management commands detected"
    if project.path_exists("manage.py"):
        return "Django manage.py entrypoint detected"
    return "no Django management command entrypoint detected"


def build_project_context(project_root: str | Path, allowed_root: str | Path | None = None) -> ProjectContext:
    root = ensure_within_allowed_root(project_root, allowed_root=allowed_root)
    python_texts = {path: _read_text(path) for path in _iter_python_files(root)}
    return ProjectContext(
        root=root,
        project_name=root.name,
        requirements=_parse_requirements(root),
        python_texts=python_texts,
    )


def inspect_project(
    project_root: str | Path,
    selected_external: list[str] | None = None,
    registry: ModuleRegistry | None = None,
    allowed_root: str | Path | None = None,
) -> ProjectInspection:
    registry = registry or ModuleRegistry()
    project = build_project_context(project_root, allowed_root=allowed_root)
    modules = registry.selected_modules(project, selected_external=selected_external)
    framework_modules = [module for module in modules if module.category == "framework"]
    framework_module = framework_modules[0] if framework_modules else None
    framework_slug = framework_module.slug if framework_module else None

    if framework_slug == "django":
        primary_text = _select_primary_django_text(project.python_texts)
        application_style = _detect_django_application_style(project, primary_text)
        blueprint_style = _detect_django_url_style(project.python_texts)
        cli_style = _detect_django_cli_style(project)
        custom_json_provider = False
    else:
        primary_text = _select_primary_flask_text(project.python_texts)
        api_init_text = _aggregate_matching_text(project.python_texts, "Blueprint(")
        commands_init_text = _aggregate_matching_text(project.python_texts, ".cli.command")
        application_style = _detect_application_style(primary_text)
        blueprint_style = _detect_blueprint_style(api_init_text, primary_text)
        cli_style = _detect_cli_style(commands_init_text)
        custom_json_provider = "DefaultJSONProvider" in primary_text

    return ProjectInspection(
        project_root=project.root,
        project_name=project.project_name,
        framework=framework_slug,
        framework_display_name=framework_module.display_name if framework_module else None,
        modules=modules,
        requirements=project.requirements,
        application_style=application_style,
        blueprint_style=blueprint_style,
        cli_style=cli_style,
        custom_json_provider=custom_json_provider,
    )


def discover_flask_routes(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    routes: list[dict[str, object]] = []
    decorator_pattern = re.compile(r"@(?P<decorator>[A-Za-z0-9_.]+)\.route\((?P<args>.*?)\)", re.DOTALL)

    for path, text in project.python_texts.items():
        for match in decorator_pattern.finditer(text):
            args = match.group("args")
            rule_match = re.search(r"['\"]([^'\"]+)['\"]", args)
            methods_match = re.search(r"methods\s*=\s*\[([^\]]+)\]", args)
            routes.append(
                {
                    "file": str(path.relative_to(project.root)),
                    "decorator": match.group("decorator"),
                    "rule": rule_match.group(1) if rule_match else None,
                    "methods": [item.strip().strip("'\"") for item in methods_match.group(1).split(",")] if methods_match else [],
                }
            )

    return routes


def discover_flask_cli_commands(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    commands: list[dict[str, object]] = []

    for path, text in project.python_texts.items():
        for match in re.finditer(r"@app\.cli\.command\((?:name\s*=\s*)?['\"]([^'\"]+)['\"]", text):
            commands.append({"file": str(path.relative_to(project.root)), "name": match.group(1)})
        for match in re.finditer(r"app\.cli\.command\(['\"]([^'\"]+)['\"]\)\(", text):
            commands.append({"file": str(path.relative_to(project.root)), "name": match.group(1)})

    deduped: list[dict[str, object]] = []
    seen: set[tuple[str, str]] = set()
    for command in commands:
        key = (str(command["file"]), str(command["name"]))
        if key not in seen:
            seen.add(key)
            deduped.append(command)
    return deduped


def discover_flask_blueprints(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    declarations: dict[str, dict[str, object]] = {}
    declaration_re = re.compile(
        r"(?P<variable>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*Blueprint\(\s*['\"](?P<name>[^'\"]+)['\"](?P<args>.*?)\)",
        re.DOTALL,
    )
    registration_re = re.compile(
        r"(?P<owner>[A-Za-z0-9_.]+)\.register_blueprint\(\s*(?P<variable>[A-Za-z_][A-Za-z0-9_]*)(?P<args>.*?)\)",
        re.DOTALL,
    )

    for path, text in project.python_texts.items():
        relative = str(path.relative_to(project.root))
        for match in declaration_re.finditer(text):
            args = match.group("args")
            declarations[match.group("variable")] = {
                "name": match.group("name"),
                "variable": match.group("variable"),
                "file": relative,
                "declared_url_prefix": (re.search(r"url_prefix\s*=\s*['\"]([^'\"]+)['\"]", args) or [None, None])[1],
                "registrations": [],
            }

    for path, text in project.python_texts.items():
        relative = str(path.relative_to(project.root))
        for match in registration_re.finditer(text):
            variable = match.group("variable")
            if variable not in declarations:
                declarations[variable] = {
                    "name": variable,
                    "variable": variable,
                    "file": relative,
                    "declared_url_prefix": None,
                    "registrations": [],
                }
            args = match.group("args")
            url_prefix = None
            prefix_match = re.search(r"url_prefix\s*=\s*['\"]([^'\"]+)['\"]", args)
            if prefix_match:
                url_prefix = prefix_match.group(1)
            declarations[variable]["registrations"].append(
                {"file": relative, "owner": match.group("owner"), "url_prefix": url_prefix}
            )

    return [declarations[key] for key in sorted(declarations)]


def discover_flask_extensions(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    extension_classes = (
        "SQLAlchemy",
        "Migrate",
        "JWTManager",
        "Mail",
        "CORS",
        "LoginManager",
        "Bcrypt",
        "CSRFProtect",
        "Marshmallow",
        "Cache",
    )
    class_pattern = "|".join(extension_classes)
    assignment_re = re.compile(
        rf"(?P<variable>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<class_name>{class_pattern})\((?P<args>.*?)\)",
        re.DOTALL,
    )
    direct_call_re = re.compile(rf"(?P<class_name>{class_pattern})\((?P<args>.*?)\)", re.DOTALL)
    extensions: list[dict[str, object]] = []

    for path, text in project.python_texts.items():
        relative = str(path.relative_to(project.root))
        for match in assignment_re.finditer(text):
            variable = match.group("variable")
            init_app_calls = [
                str(candidate.relative_to(project.root))
                for candidate, candidate_text in project.python_texts.items()
                if re.search(rf"\b{re.escape(variable)}\.init_app\(", candidate_text)
            ]
            extensions.append(
                {
                    "file": relative,
                    "variable": variable,
                    "class_name": match.group("class_name"),
                    "constructed_with_app": bool(match.group("args").strip()),
                    "init_app_files": init_app_calls,
                }
            )
        for match in direct_call_re.finditer(text):
            if re.search(rf"(?P<variable>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*{match.group('class_name')}\(", text[match.start() - 40 : match.end() + 1]):
                continue
            args = match.group("args")
            if not args.strip():
                continue
            extensions.append(
                {
                    "file": relative,
                    "variable": None,
                    "class_name": match.group("class_name"),
                    "constructed_with_app": True,
                    "init_app_files": [],
                }
            )

    deduped: list[dict[str, object]] = []
    seen: set[tuple[str, str, str | None]] = set()
    for extension in extensions:
        key = (str(extension["file"]), str(extension["class_name"]), extension["variable"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(extension)
    return deduped


def inspect_flask_config(project_root: str | Path, allowed_root: str | Path | None = None) -> dict[str, object]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    config_keys: set[str] = set()
    env_keys: set[str] = set()
    loaders: list[dict[str, str | None]] = []

    for path, text in project.python_texts.items():
        relative = str(path.relative_to(project.root))
        for match in re.finditer(r"app\.config\[['\"]([^'\"]+)['\"]\]", text):
            config_keys.add(match.group(1))
        for match in re.finditer(r"app\.config\.get\(\s*['\"]([^'\"]+)['\"]", text):
            config_keys.add(match.group(1))
        for match in re.finditer(r"app\.config\.setdefault\(\s*['\"]([^'\"]+)['\"]", text):
            config_keys.add(match.group(1))
        for match in re.finditer(r"app\.config\.from_object\(\s*([^)]+)\)", text):
            loaders.append({"file": relative, "loader": "from_object", "value": match.group(1).strip()})
        for match in re.finditer(r"app\.config\.from_envvar\(\s*['\"]([^'\"]+)['\"]", text):
            env_keys.add(match.group(1))
            loaders.append({"file": relative, "loader": "from_envvar", "value": match.group(1)})
        for match in re.finditer(r"app\.config\.from_mapping\((?P<args>.*?)\)", text, re.DOTALL):
            for key_match in re.finditer(r"([A-Z][A-Z0-9_]+)\s*=", match.group("args")):
                config_keys.add(key_match.group(1))
            loaders.append({"file": relative, "loader": "from_mapping", "value": None})

    return {
        "config_keys": sorted(config_keys),
        "env_keys": sorted(env_keys),
        "loaders": loaders,
    }


def discover_django_routes(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    project = build_project_context(project_root, allowed_root=allowed_root)
    routes: list[dict[str, object]] = []

    for path, text in project.python_texts.items():
        relative = str(path.relative_to(project.root))
        for raw_line in text.splitlines():
            line = raw_line.strip()
            kind = None
            if "path(" in line:
                kind = "path"
            elif "re_path(" in line:
                kind = "re_path"
            if kind is None:
                continue
            args = line.split(f"{kind}(", 1)[1].rsplit(")", 1)[0]
            pattern_match = re.search(r"(?:r)?['\"]([^'\"]*)['\"]", args)
            target = None
            include_target = None
            parts = [part.strip() for part in args.split(",")]
            if len(parts) > 1:
                target = parts[1]
            include_match = re.search(r"include\(\s*['\"]([^'\"]+)['\"]", args)
            if include_match:
                include_target = include_match.group(1)
                target = "include"
            name_match = re.search(r"name\s*=\s*['\"]([^'\"]+)['\"]", args)
            routes.append(
                {
                    "file": relative,
                    "kind": kind,
                    "pattern": pattern_match.group(1) if pattern_match else None,
                    "target": target,
                    "included_urlconf": include_target,
                    "name": name_match.group(1) if name_match else None,
                }
            )

    return routes


def discover_django_management_commands(project_root: str | Path, allowed_root: str | Path | None = None) -> list[dict[str, object]]:
    root = ensure_within_allowed_root(project_root, allowed_root=allowed_root)
    commands: list[dict[str, object]] = []
    for path in sorted(root.rglob("management/commands/*.py")):
        if path.is_symlink() or path.name == "__init__.py":
            continue
        relative = str(path.relative_to(root))
        text = path.read_text(encoding="utf-8")
        help_match = re.search(r"help\s*=\s*['\"]([^'\"]+)['\"]", text)
        commands.append(
            {
                "file": relative,
                "name": path.stem,
                "help": help_match.group(1) if help_match else None,
            }
        )
    return commands
