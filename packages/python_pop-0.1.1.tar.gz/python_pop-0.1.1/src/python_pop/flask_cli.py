from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import click

from .console.add_skill import run_add_skill
from .console.inspect import run_inspect
from .console.install import run_install
from .console.mcp import run_mcp
from .console.update import run_update


@click.group(name="python-pop")
def flask_cli() -> None:
    """Python Pop AI tooling for Flask applications."""


@flask_cli.command("inspect")
@click.option("--project-root", type=click.Path(path_type=Path, file_okay=False, dir_okay=True), default=Path("."))
@click.option("--json", "as_json", is_flag=True)
@click.option("--package", "packages", multiple=True)
def inspect_click(project_root: Path, as_json: bool, packages: tuple[str, ...]) -> None:
    run_inspect(project_root, as_json, selected_external=list(packages))


@flask_cli.command("install")
@click.option("--project-root", type=click.Path(path_type=Path, file_okay=False, dir_okay=True), default=Path("."))
@click.option("--guidelines", is_flag=True)
@click.option("--skills", is_flag=True)
@click.option("--mcp", is_flag=True)
@click.option("--agent", "agents", multiple=True)
@click.option("--package", "packages", multiple=True)
@click.option("--include-planned", is_flag=True)
@click.option("--force", is_flag=True)
@click.option("--dry-run", is_flag=True)
@click.option("--no-interaction", is_flag=True)
def install_click(
    project_root: Path,
    guidelines: bool,
    skills: bool,
    mcp: bool,
    agents: tuple[str, ...],
    packages: tuple[str, ...],
    include_planned: bool,
    force: bool,
    dry_run: bool,
    no_interaction: bool,
) -> None:
    run_install(
        SimpleNamespace(
            project_root=project_root,
            guidelines=guidelines,
            skills=skills,
            mcp=mcp,
            agent=list(agents),
            package=list(packages),
            include_planned=include_planned,
            force=force,
            dry_run=dry_run,
            no_interaction=no_interaction,
        )
    )


@flask_cli.command("update")
@click.option("--project-root", type=click.Path(path_type=Path, file_okay=False, dir_okay=True), default=Path("."))
@click.option("--discover", is_flag=True)
@click.option("--ignore-skills", is_flag=True)
@click.option("--include-planned", is_flag=True)
@click.option("--dry-run", is_flag=True)
def update_click(project_root: Path, discover: bool, ignore_skills: bool, include_planned: bool, dry_run: bool) -> None:
    run_update(
        SimpleNamespace(
            project_root=project_root,
            discover=discover,
            ignore_skills=ignore_skills,
            include_planned=include_planned,
            dry_run=dry_run,
        )
    )


@flask_cli.command("add-skill")
@click.argument("repo", required=False)
@click.option("--project-root", type=click.Path(path_type=Path, file_okay=False, dir_okay=True), default=Path("."))
@click.option("--list", "list_only", is_flag=True)
@click.option("--all", "install_all", is_flag=True)
@click.option("--skill", "skills", multiple=True)
@click.option("--force", is_flag=True)
@click.option("--skip-audit", is_flag=True)
@click.option("--no-interaction", is_flag=True)
def add_skill_click(
    repo: str | None,
    project_root: Path,
    list_only: bool,
    install_all: bool,
    skills: tuple[str, ...],
    force: bool,
    skip_audit: bool,
    no_interaction: bool,
) -> None:
    run_add_skill(
        SimpleNamespace(
            repo=repo,
            project_root=project_root,
            list=list_only,
            all=install_all,
            skill=list(skills),
            force=force,
            skip_audit=skip_audit,
            no_interaction=no_interaction,
        )
    )


@flask_cli.command("mcp")
def mcp_click() -> None:
    run_mcp(SimpleNamespace())
