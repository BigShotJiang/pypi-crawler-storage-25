from __future__ import annotations

from .console.main import main

__all__ = ["main"]
