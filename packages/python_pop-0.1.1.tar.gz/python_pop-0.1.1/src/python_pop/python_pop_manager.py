from __future__ import annotations

from collections import OrderedDict
from typing import TYPE_CHECKING

from .install.agents.amp import Amp
from .install.agents.claude_code import ClaudeCode
from .install.agents.codex import Codex
from .install.agents.copilot import Copilot
from .install.agents.cursor import Cursor
from .install.agents.gemini import Gemini
from .install.agents.junie import Junie
from .install.agents.opencode import OpenCode

if TYPE_CHECKING:
    from .install.agents.agent import Agent


class PythonPopManager:
    def __init__(self) -> None:
        self._agents: "OrderedDict[str, type[Agent]]" = OrderedDict(
            [
                ("amp", Amp),
                ("junie", Junie),
                ("cursor", Cursor),
                ("claude_code", ClaudeCode),
                ("codex", Codex),
                ("copilot", Copilot),
                ("opencode", OpenCode),
                ("gemini", Gemini),
            ]
        )

    def register_agent(self, key: str, agent_class: "type[Agent]") -> None:
        if key in self._agents:
            raise ValueError(f"Agent {key!r} is already registered.")
        self._agents[key] = agent_class

    def get_agents(self) -> dict[str, "type[Agent]"]:
        return dict(self._agents)

