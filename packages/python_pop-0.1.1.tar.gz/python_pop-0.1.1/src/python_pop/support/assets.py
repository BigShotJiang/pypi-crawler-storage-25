from __future__ import annotations

from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def source_ai_root() -> Path:
    return repo_root() / ".ai"


def packaged_ai_root() -> Path:
    return Path(__file__).resolve().parents[1] / "_vendor_ai" / ".ai"


def ai_root() -> Path:
    source = source_ai_root()
    if source.exists():
        return source

    packaged = packaged_ai_root()
    if packaged.exists():
        return packaged

    raise FileNotFoundError("Python Pop AI asset tree was not found.")


def resolve_ai_path(relative_path: str) -> Path:
    return ai_root() / relative_path

