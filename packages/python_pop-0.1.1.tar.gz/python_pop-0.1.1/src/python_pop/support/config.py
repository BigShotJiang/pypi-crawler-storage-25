from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path


CONFIG_FILE = "python-pop.json"


@dataclass
class PythonPopConfig:
    agents: list[str] = field(default_factory=list)
    framework: str | None = None
    frameworks: list[str] = field(default_factory=list)
    guidelines: bool = False
    mcp: bool = False
    packages: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)


class ConfigStore:
    def __init__(self, project_root: str | Path):
        self.project_root = Path(project_root).resolve()
        self.path = self.project_root / CONFIG_FILE

    def exists(self) -> bool:
        return self.path.exists()

    def is_valid(self) -> bool:
        try:
            self.load()
        except (OSError, ValueError, json.JSONDecodeError):
            return False
        return True

    def load(self) -> PythonPopConfig:
        if not self.path.exists():
            return PythonPopConfig()

        payload = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("python-pop.json must contain a JSON object.")

        return PythonPopConfig(
            agents=list(payload.get("agents", [])),
            framework=payload.get("framework"),
            frameworks=list(payload.get("frameworks", [])),
            guidelines=bool(payload.get("guidelines", False)),
            mcp=bool(payload.get("mcp", False)),
            packages=list(payload.get("packages", [])),
            skills=list(payload.get("skills", [])),
        )

    def save(self, config: PythonPopConfig) -> None:
        payload = {key: value for key, value in asdict(config).items() if value not in (None, [], False)}
        self.path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def delete(self) -> None:
        if self.path.exists():
            self.path.unlink()
