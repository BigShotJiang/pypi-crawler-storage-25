from __future__ import annotations

import sys
from typing import TextIO


class InstallDisplay:
    LOGO_LINES = [
        "  ██████╗   ██████╗  ██████╗  ██╗",
        "  ██╔══██╗ ██╔═══██╗ ██╔══██╗ ██║",
        "  ██████╔╝ ██║   ██║ ██████╔╝ ██║",
        "  ██╔═══╝  ██║   ██║ ██╔═══╝  ╚═╝",
        "  ██║      ╚██████╔╝ ██║      ██╗",
        "  ╚═╝       ╚═════╝  ╚═╝      ╚═╝",
    ]
    GRADIENT = ("#6433E5", "#7F40EF", "#A85FFA", "#A85FFA", "#7F40EF", "#6433E5")
    PRIMARY = "#7F40EF"
    TEXT_ON_PRIMARY = "#FFFFFF"
    SUBTLE = 246

    def __init__(self, stream: TextIO | None = None):
        self.stream = stream or sys.stdout
        self.use_color = bool(getattr(self.stream, "isatty", lambda: False)())

    def header(self, feature_name: str, project_name: str) -> None:
        self._line()
        for index, line in enumerate(self.LOGO_LINES):
            self._line(self._fg(self.GRADIENT[index], line))
        self._line()
        self._line("  " + self._badge(f" ✦ Python Pop :: {feature_name} :: Just Ship It ✦ "))
        self._line("  " + self._subtle(f"Give {project_name} a Pop!"))
        self._line()

    def section(self, title: str) -> None:
        self._line(self._subtle(f"  ── {title} " + "─" * max(0, 48 - len(title))))

    def item(self, label: str, value: str) -> None:
        self._line(f"  • {label}: {value}")

    def summary(
        self,
        *,
        project_name: str,
        guideline_targets: list[str],
        skill_targets: list[str],
        mcp_targets: list[str],
        dry_run: bool,
    ) -> None:
        self.section("Summary")
        self.item("Project", project_name)
        self.item("Guidelines", str(len(guideline_targets)))
        self.item("Skills", str(len(skill_targets)))
        self.item("MCP", str(len(mcp_targets)))
        self.item("Mode", "dry run" if dry_run else "install")
        self._line()

    def _line(self, text: str = "") -> None:
        print(text, file=self.stream)

    def _fg(self, color: int | str, text: str) -> str:
        if not self.use_color:
            return text
        if isinstance(color, str):
            red, green, blue = self._hex_to_rgb(color)
            return f"\033[38;2;{red};{green};{blue}m{text}\033[0m"
        return f"\033[38;5;{color}m{text}\033[0m"

    def _badge(self, text: str) -> str:
        if not self.use_color:
            return text
        background = self._bg(self.PRIMARY)
        foreground = self._fg_prefix(self.TEXT_ON_PRIMARY)
        return f"{background}{foreground}\033[1m{text}\033[0m"

    def _subtle(self, text: str) -> str:
        if not self.use_color:
            return text
        return f"\033[38;5;{self.SUBTLE}m{text}\033[0m"

    def _bg(self, color: int | str) -> str:
        if isinstance(color, str):
            red, green, blue = self._hex_to_rgb(color)
            return f"\033[48;2;{red};{green};{blue}m"
        return f"\033[48;5;{color}m"

    def _fg_prefix(self, color: int | str) -> str:
        if isinstance(color, str):
            red, green, blue = self._hex_to_rgb(color)
            return f"\033[38;2;{red};{green};{blue}m"
        return f"\033[38;5;{color}m"

    def _hex_to_rgb(self, color: str) -> tuple[int, int, int]:
        value = color.removeprefix("#")
        return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
