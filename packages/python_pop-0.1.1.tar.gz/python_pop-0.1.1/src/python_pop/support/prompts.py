from __future__ import annotations

import sys
from typing import Mapping


def is_interactive(no_interaction: bool = False) -> bool:
    return (not no_interaction) and sys.stdin.isatty()


def confirm(label: str, default: bool, interactive: bool) -> bool:
    if not interactive:
        return default

    suffix = "Y/n" if default else "y/N"
    raw = input(f"{label} [{suffix}]: ").strip().lower()
    if raw == "":
        return default
    return raw in {"y", "yes"}


def multiselect(
    label: str,
    options: Mapping[str, str],
    default: list[str] | None,
    interactive: bool,
    required: bool = True,
) -> list[str]:
    if not interactive:
        if default is not None:
            return list(default)
        if required:
            return list(options.keys())
        return []

    keys = list(options.keys())
    print(label)
    for index, key in enumerate(keys, start=1):
        print(f"  {index}. {options[key]} ({key})")

    if default:
        print(f"Press Enter for default: {', '.join(default)}")

    raw = input("Select comma-separated numbers or keys: ").strip()
    if raw == "":
        return list(default or ([] if not required else keys))

    selected: list[str] = []
    for chunk in [item.strip() for item in raw.split(",") if item.strip()]:
        if chunk.isdigit():
            position = int(chunk) - 1
            if 0 <= position < len(keys):
                selected.append(keys[position])
                continue
        if chunk in options:
            selected.append(chunk)

    if not selected and required:
        return list(default or keys)

    deduped: list[str] = []
    for item in selected:
        if item not in deduped:
            deduped.append(item)
    return deduped

