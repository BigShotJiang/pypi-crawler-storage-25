from __future__ import annotations

import os
from pathlib import Path


INSPECTION_ALLOWED_ROOT_ENV = "PYTHON_POP_ALLOWED_ROOT"


def configured_allowed_root() -> Path | None:
    value = os.environ.get(INSPECTION_ALLOWED_ROOT_ENV, "").strip()
    if not value:
        return None
    return Path(value).resolve()


def path_within_root(path: str | Path, root: str | Path) -> bool:
    candidate = Path(path).resolve()
    boundary = Path(root).resolve()
    try:
        candidate.relative_to(boundary)
    except ValueError:
        return False
    return True


def ensure_within_allowed_root(
    path: str | Path,
    *,
    allowed_root: str | Path | None = None,
) -> Path:
    candidate = Path(path).resolve()
    boundary = Path(allowed_root).resolve() if allowed_root else configured_allowed_root()
    if boundary is None:
        return candidate
    if not path_within_root(candidate, boundary):
        raise ValueError(f"Project root must stay within {boundary}.")
    return candidate
