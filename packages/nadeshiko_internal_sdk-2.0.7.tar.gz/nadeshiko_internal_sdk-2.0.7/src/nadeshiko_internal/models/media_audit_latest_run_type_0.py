from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="MediaAuditLatestRunType0")


@_attrs_define
class MediaAuditLatestRunType0:
    """Latest run info for this audit

    Attributes:
        id (int):
        result_count (int):
        created_at (datetime.datetime):
    """

    id: int
    result_count: int
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        result_count = self.result_count

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "resultCount": result_count,
                "createdAt": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        _src = dict(src_dict)
        id = _src.pop("id")

        result_count = _src.pop("resultCount")

        created_at = isoparse(_src.pop("createdAt"))

        media_audit_latest_run_type_0 = cls(
            id=id,
            result_count=result_count,
            created_at=created_at,
        )

        media_audit_latest_run_type_0.additional_properties = _src
        return media_audit_latest_run_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
