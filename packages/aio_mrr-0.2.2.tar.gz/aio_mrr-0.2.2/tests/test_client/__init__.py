"""Tests for MRRClient module."""
