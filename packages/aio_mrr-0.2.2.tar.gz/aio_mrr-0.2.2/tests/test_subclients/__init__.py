"""Tests for subclients module."""
