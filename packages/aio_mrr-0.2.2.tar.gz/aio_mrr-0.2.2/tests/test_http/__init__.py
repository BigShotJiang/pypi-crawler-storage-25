"""Tests for http module."""
