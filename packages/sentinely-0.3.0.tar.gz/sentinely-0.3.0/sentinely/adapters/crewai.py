"""CrewAI adapter — coming soon."""

raise NotImplementedError(
    "The CrewAI adapter is not yet implemented. "
    "Use sentinely.protect() directly to wrap your agent. "
    "See https://sentinely.ai/docs for examples."
)
