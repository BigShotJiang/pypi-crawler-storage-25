import os

# Fake key for tests. Only passes the SDK's "do you have a key?" check.
# All API calls are mocked in individual test files — this never hits a real server.
os.environ["SENTINELY_API_KEY"] = "sntnl_test_fake_key_for_tests"
