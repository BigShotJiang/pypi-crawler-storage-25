"""Variant mapping jobs using VRS (Variant Representation Specification).

This module handles the mapping of variants to standardized genomic coordinates
using the VRS mapping service. It includes queue management, retry logic,
and coordination with downstream services like ClinGen and UniProt.
"""

import asyncio
import functools
import logging
from datetime import date
from typing import Any

from sqlalchemy import cast, null, select
from sqlalchemy.dialects.postgresql import JSONB

from mavedb.data_providers.services import vrs_mapper
from mavedb.lib.annotation_status_manager import AnnotationStatusManager
from mavedb.lib.exceptions import (
    NonexistentMappingReferenceError,
    NonexistentMappingResultsError,
    NonexistentMappingScoresError,
)
from mavedb.lib.logging.context import format_raised_exception_info_as_dict
from mavedb.lib.mapping import EXCLUDED_PREMAPPED_ANNOTATION_KEYS
from mavedb.lib.types.workflow import JobExecutionOutcome
from mavedb.lib.variants import get_hgvs_from_post_mapped
from mavedb.models.enums.annotation_layer import AnnotationLayer
from mavedb.models.enums.annotation_type import AnnotationType
from mavedb.models.enums.job_pipeline import AnnotationFailureCategory, AnnotationStatus, FailureCategory
from mavedb.models.enums.mapping_state import MappingState
from mavedb.models.mapped_variant import MappedVariant
from mavedb.models.score_set import ScoreSet
from mavedb.models.target_gene_mapping import TargetGeneMapping
from mavedb.models.user import User
from mavedb.models.variant import Variant
from mavedb.worker.jobs.utils.setup import validate_job_params
from mavedb.worker.lib.decorators.pipeline_management import with_pipeline_management
from mavedb.worker.lib.managers.job_manager import JobManager

logger = logging.getLogger(__name__)


@with_pipeline_management
async def map_variants_for_score_set(ctx: dict, job_id: int, job_manager: JobManager) -> JobExecutionOutcome:
    """Map variants for a given score set using VRS."""
    # Handle everything prior to score set fetch in an outer layer. Any issues prior to
    # fetching the score set should fail the job outright and we will be unable to set
    # a processing state on the score set itself.

    job = job_manager.get_job()

    _job_required_params = [
        "score_set_id",
        "correlation_id",
        "updater_id",
    ]
    validate_job_params(_job_required_params, job)

    # Fetch required resources based on param inputs. Safely ignore mypy warnings here, as they were checked above.
    score_set = job_manager.db.scalars(select(ScoreSet).where(ScoreSet.id == job.job_params["score_set_id"])).one()  # type: ignore

    # Handle everything within try/except to persist appropriate mapping state
    try:
        correlation_id = job.job_params["correlation_id"]  # type: ignore
        updater_id = job.job_params["updater_id"]  # type: ignore
        updated_by = job_manager.db.scalars(select(User).where(User.id == updater_id)).one()

        # Setup initial context and progress
        job_manager.save_to_context(
            {
                "application": "mavedb-worker",
                "function": "map_variants_for_score_set",
                "resource": score_set.urn,
                "correlation_id": correlation_id,
            }
        )
        job_manager.update_progress(0, 100, "Starting variant mapping job.")
        logger.info(msg="Started variant mapping job", extra=job_manager.logging_context())

        # TODO#372: non-nullable URNs
        if not score_set.urn:  # pragma: no cover
            raise ValueError("Score set URN is required for variant mapping.")

        # Setup score set state for mapping
        score_set.mapping_state = MappingState.processing
        score_set.mapping_errors = null()
        score_set.modified_by = updated_by
        score_set.modification_date = date.today()

        job_manager.db.add(score_set)
        job_manager.db.flush()

        job_manager.save_to_context({"mapping_state": score_set.mapping_state.name})
        job_manager.update_progress(10, 100, "Score set prepared for variant mapping.")
        logger.debug(msg="Score set prepared for variant mapping.", extra=job_manager.logging_context())

        # Do not block Worker event loop during mapping, see: https://arq-docs.helpmanual.io/#synchronous-jobs.
        vrs = vrs_mapper()
        blocking = functools.partial(vrs.map_score_set, score_set.urn)
        loop = asyncio.get_running_loop()

        mapping_results = None

        logger.debug(msg="Mapping variants using VRS mapping service.", extra=job_manager.logging_context())
        job_manager.update_progress(30, 100, "Mapping variants using VRS mapping service.")
        mapping_results = await loop.run_in_executor(ctx["pool"], blocking)

        logger.debug(msg="Done mapping variants.", extra=job_manager.logging_context())
        job_manager.update_progress(80, 100, "Processing mapped variants.")

        ## Check our assumptions about mapping results and handle errors appropriately.

        # Ensure we have mapping results
        if not mapping_results:
            raise NonexistentMappingResultsError("Mapping results were not returned from VRS mapping service.")

        # Ensure we have mapped scores
        mapped_scores = mapping_results.get("mapped_scores")
        if not mapped_scores:
            internal_err = mapping_results.get(
                "error_message", "No variants were mapped and no error message was provided."
            )
            raise NonexistentMappingScoresError(internal_err)

        # Ensure we have reference metadata
        reference_metadata = mapping_results.get("reference_sequences")
        if not reference_metadata:
            raise NonexistentMappingReferenceError("Reference metadata missing from mapping results.")

        # Per-(target, alignment_level) QC records produced by the dcd-mapping API.
        # All records share the same tool_version because they come from a single run;
        # we use that as the global ``mapping_api_version`` carried on each MappedVariant.
        target_mappings_payload = mapping_results.get("target_mappings") or []
        tool_version = next(
            (tm.get("tool_version") for tm in target_mappings_payload if tm.get("tool_version")),
            None,
        )
        if not tool_version:
            raise NonexistentMappingResultsError(
                "Mapping results did not include any target_mappings with a tool_version."
            )

        # Process and store mapped variants
        # Index of (target_gene_identifier, alignment_level) -> persisted TargetGeneMapping row,
        # populated as we walk reference_metadata. Used to attach the right QC record to each
        # mapped variant in the score loop below.
        target_gene_mapping_by_key: dict[tuple[str, str], TargetGeneMapping] = {}

        for target_gene_identifier in reference_metadata:
            target_gene = next(
                (target_gene for target_gene in score_set.target_genes if target_gene.name == target_gene_identifier),
                None,
            )

            if not target_gene:
                raise ValueError(
                    f"Target gene {target_gene_identifier} not found in database for score set {score_set.urn}."
                )

            job_manager.save_to_context({"processing_target_gene": target_gene.id})
            logger.debug(f"Processing target gene {target_gene.name}.", extra=job_manager.logging_context())

            # allow for multiple annotation layers
            pre_mapped_metadata: dict[str, Any] = {}
            post_mapped_metadata: dict[str, Any] = {}

            # add gene-level info
            gene_info = reference_metadata[target_gene_identifier].get("gene_info")
            if gene_info:
                target_gene.mapped_hgnc_name = gene_info.get("hgnc_symbol")
                post_mapped_metadata["hgnc_name_selection_method"] = gene_info.get("selection_method")

                job_manager.save_to_context({"mapped_hgnc_name": target_gene.mapped_hgnc_name})
                logger.debug("Added mapped HGNC name to target gene.", extra=job_manager.logging_context())

            # add annotation layer info
            for annotation_layer in reference_metadata[target_gene_identifier]["layers"]:
                # ``annotation_layer`` arrives as a dcd-mapping wire code (``p``/``c``/``g``);
                # we persist metadata under the corresponding full-name enum value.
                layer_name = AnnotationLayer.from_wire(annotation_layer).value
                layer_premapped = reference_metadata[target_gene_identifier]["layers"][annotation_layer].get(
                    "computed_reference_sequence"
                )
                if layer_premapped:
                    pre_mapped_metadata[layer_name] = {
                        k: layer_premapped[k]
                        for k in set(list(layer_premapped.keys())) - EXCLUDED_PREMAPPED_ANNOTATION_KEYS
                    }
                    job_manager.save_to_context({"pre_mapped_layer_exists": True})

                layer_postmapped = reference_metadata[target_gene_identifier]["layers"][annotation_layer].get(
                    "mapped_reference_sequence"
                )
                if layer_postmapped:
                    post_mapped_metadata[layer_name] = layer_postmapped
                    job_manager.save_to_context({"post_mapped_layer_exists": True})

                logger.debug(
                    f"Added annotation layer mapping metadata for {annotation_layer}.",
                    extra=job_manager.logging_context(),
                )

            target_gene.pre_mapped_metadata = cast(pre_mapped_metadata, JSONB)
            target_gene.post_mapped_metadata = cast(post_mapped_metadata, JSONB)
            job_manager.db.add(target_gene)
            logger.debug("Added mapping metadata to target gene.", extra=job_manager.logging_context())

            # Persist a TargetGeneMapping row per (target_gene, alignment_level) reported by
            # the dcd-mapping QC API. The match against ``target_mappings_payload`` is on
            # ``target_gene_identifier`` (must equal target_gene.name) and ``alignment_level``.
            for tm in target_mappings_payload:
                if tm.get("target_gene_identifier") != target_gene_identifier:
                    continue

                level_value = tm.get("alignment_level")
                if not level_value:
                    continue

                target_gene_mapping = TargetGeneMapping(
                    target_gene_id=target_gene.id,
                    alignment_level=AnnotationLayer.from_wire(level_value),
                    preferred=bool(tm.get("preferred", False)),
                    reference_assembly=tm.get("reference_assembly"),
                    reference_accession=tm.get("reference_accession"),
                    reference_sequence_id=tm.get("reference_sequence_id"),
                    alignment_score=tm.get("alignment_score"),  # type: ignore[arg-type]
                    next_best_alignment_score=tm.get("next_best_alignment_score"),  # type: ignore[arg-type]
                    alignment_length=tm.get("alignment_length"),
                    alignment_string=tm.get("alignment_string"),
                    mismatch_count=tm.get("mismatch_count"),
                    gap_count=tm.get("gap_count"),
                    percent_identity=tm.get("percent_identity"),  # type: ignore[arg-type]
                    total_variants=tm.get("total_variants"),
                    variants_failed=tm.get("variants_failed"),
                    variants_with_alignment_warnings=tm.get("variants_with_alignment_warnings"),
                    variants_mapped_cleanly=tm.get("variants_mapped_cleanly"),
                    tool_name=tm.get("tool_name", "dcd-mapping"),
                    tool_version=tm["tool_version"],
                    tool_parameters=tm.get("tool_parameters"),
                    alignment_metadata=tm.get("alignment_metadata"),
                    vrs_version=tm.get("vrs_version"),
                    mapped_date=mapping_results["mapped_date"],
                )
                job_manager.db.add(target_gene_mapping)
                target_gene_mapping_by_key[(target_gene_identifier, level_value)] = target_gene_mapping

        # Flush so freshly inserted TargetGeneMapping rows have ids before we attach FKs
        # to mapped_variants below. We deliberately do NOT call update_progress() between
        # this flush and the mapped_variant loop -- update_progress commits as a checkpoint,
        # and a failure mid-loop would otherwise leave orphaned target_gene_mappings rows
        # committed without any mapped_variants referencing them.
        job_manager.db.flush()

        total_variants = len(mapped_scores)
        job_manager.save_to_context({"total_variants_to_process": total_variants})

        successful_mapped_variants = 0
        logger.info(
            f"Processing {total_variants} mapped variants for score set {score_set.urn}.",
            extra=job_manager.logging_context(),
        )
        annotation_manager = AnnotationStatusManager(job_manager.db, job_run_id=job.id)
        for mapped_score in mapped_scores:
            variant_urn = mapped_score.get("mavedb_id")
            variant = job_manager.db.scalars(select(Variant).where(Variant.urn == variant_urn)).one()

            job_manager.save_to_context({"processing_variant": variant.id})
            logger.debug(f"Processing variant {variant.id}.", extra=job_manager.logging_context())

            # there should only be one current mapped variant per variant id, so update old mapped variant to current = false
            existing_mapped_variant = (
                job_manager.db.query(MappedVariant)
                .filter(MappedVariant.variant_id == variant.id, MappedVariant.current.is_(True))
                .one_or_none()
            )

            if existing_mapped_variant:
                job_manager.save_to_context({"existing_mapped_variant": existing_mapped_variant.id})
                existing_mapped_variant.current = False
                job_manager.db.add(existing_mapped_variant)
                logger.debug(msg="Set existing mapped variant to current = false.", extra=job_manager.logging_context())

            annotation_was_successful = mapped_score.get("pre_mapped") and mapped_score.get("post_mapped")
            if annotation_was_successful:
                successful_mapped_variants += 1
                job_manager.save_to_context({"successful_mapped_variants": successful_mapped_variants})

            # dcd-mapping guarantees both fields are set on every ScoreAnnotation,
            # including failed variants (the annotate step re-attributes failures to
            # preferred_layer_for_target before emitting). Absent fields indicate an
            # older or malformed payload and we fail fast rather than silently drop the FK.
            score_target = mapped_score.get("target_gene_identifier")
            score_alignment_level = mapped_score.get("alignment_level")
            if not score_target or not score_alignment_level:
                raise NonexistentMappingResultsError(
                    f"ScoreAnnotation for variant {variant_urn!r} is missing "
                    f"target_gene_identifier or alignment_level."
                )

            target_gene_mapping_row = target_gene_mapping_by_key.get((score_target, score_alignment_level))
            mapped_variant = MappedVariant(
                pre_mapped=mapped_score.get("pre_mapped", null()),
                post_mapped=mapped_score.get("post_mapped", null()),
                hgvs_assay_level=get_hgvs_from_post_mapped(mapped_score.get("post_mapped", {})),
                variant_id=variant.id,
                modification_date=date.today(),
                mapped_date=mapping_results["mapped_date"],
                vrs_version=mapped_score.get("vrs_version", null()),
                mapping_api_version=tool_version,
                error_message=mapped_score.get("error_message", null()),
                target_gene_mapping_id=target_gene_mapping_row.id if target_gene_mapping_row else None,
                alignment_level=AnnotationLayer.from_wire(score_alignment_level),
                at_mismatched_locus=mapped_score.get("at_mismatched_locus"),
                near_gap=mapped_score.get("near_gap"),
                current=True,
            )

            annotation_manager.add_annotation(
                variant_id=variant.id,  # type: ignore
                annotation_type=AnnotationType.VRS_MAPPING,
                version=tool_version,
                status=AnnotationStatus.SUCCESS if annotation_was_successful else AnnotationStatus.FAILED,
                failure_category=None
                if annotation_was_successful
                else AnnotationFailureCategory.EXTERNAL_SERVICE_REJECTED,
                annotation_data={
                    "error_message": mapped_score.get("error_message", null()),
                    "annotation_metadata": {
                        "mapped_assay_level_hgvs": get_hgvs_from_post_mapped(mapped_score.get("post_mapped", {})),
                    },
                },
                current=True,
            )

            job_manager.db.add(mapped_variant)
            logger.debug(msg="Added new mapped variant to session.", extra=job_manager.logging_context())

        annotation_manager.flush()

        if successful_mapped_variants == 0:
            score_set.mapping_state = MappingState.failed
            score_set.mapping_errors = {"error_message": "All variants failed to map."}
        elif successful_mapped_variants < total_variants:
            score_set.mapping_state = MappingState.incomplete
        else:
            score_set.mapping_state = MappingState.complete

        job_manager.save_to_context(
            {
                "successful_mapped_variants": successful_mapped_variants,
                "mapping_state": score_set.mapping_state.name,
                "mapping_errors": score_set.mapping_errors,
                "inserted_mapped_variants": len(mapped_scores),
            }
        )

        # Flush score set state; the decorator will commit on return via the success/return paths below.
        job_manager.db.add(score_set)
        job_manager.db.flush()

    except (NonexistentMappingResultsError, NonexistentMappingScoresError, NonexistentMappingReferenceError) as e:
        logging_context = {**job_manager.logging_context(), **format_raised_exception_info_as_dict(e)}
        logger.error(msg="Known error during variant mapping.", extra=logging_context)

        job_manager.db.rollback()

        score_set.mapping_state = MappingState.failed
        score_set.mapping_errors = {"error_message": str(e)}

        # Persist score set state to survive any decorator rollback.
        job_manager.db.add(score_set)
        job_manager.db.commit()
        return JobExecutionOutcome.failed(
            reason=str(e),
            data={"score_set_id": score_set.id, "mapped_count": 0, "total_count": 0},
            failure_category=FailureCategory.DATA_ERROR,
        )

    except Exception as e:
        logging_context = {**job_manager.logging_context(), **format_raised_exception_info_as_dict(e)}
        logger.error(msg="Encountered an unexpected error while parsing mapped variants.", extra=logging_context)

        job_manager.db.rollback()

        score_set.mapping_state = MappingState.failed
        if not score_set.mapping_errors:
            score_set.mapping_errors = {
                "error_message": f"Encountered an unexpected error while parsing mapped variants. This job will be retried up to {job.max_retries} times (this was attempt {job.retry_count})."
            }

        # Persist score set state to survive any decorator rollback.
        job_manager.db.add(score_set)
        job_manager.db.commit()

        raise

    logger.info(msg="Inserted mapped variants into db.", extra=job_manager.logging_context())

    if successful_mapped_variants == 0:
        logger.error(msg="No variants were successfully mapped.", extra=job_manager.logging_context())
        job_manager.db.flush()
        return JobExecutionOutcome.failed(
            reason="No variants were successfully mapped.",
            data={
                "score_set_id": score_set.id,
                "mapped_count": 0,
                "unmapped_count": total_variants,
                "total_count": total_variants,
            },
            failure_category=FailureCategory.VRS_MAPPING_FAILED,
        )

    logger.info(msg="Variant mapping job completed successfully.", extra=job_manager.logging_context())
    job_manager.db.flush()
    return JobExecutionOutcome.succeeded(
        data={
            "score_set_id": score_set.id,
            "mapped_count": successful_mapped_variants,
            "unmapped_count": total_variants - successful_mapped_variants,
            "total_count": total_variants,
        }
    )
