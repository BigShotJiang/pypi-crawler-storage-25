from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Optional

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
JOB_ID_RE = re.compile(
    r"^job_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)


class LocalValidationError(Exception):
    """Raised when CLI arguments or local inputs are invalid."""


def require_email(email: str) -> str:
    value = email.strip()
    if not value or not EMAIL_RE.match(value):
        raise LocalValidationError("Invalid email address.")
    return value


def require_job_id(job_id: str) -> str:
    value = job_id.strip()
    if not JOB_ID_RE.match(value):
        raise LocalValidationError("Invalid job_id. Expected job_<uuid4>.")
    return value


def require_model_path(path_value: str) -> Path:
    path = Path(path_value).expanduser()
    if not path.exists():
        raise LocalValidationError(f"Model file does not exist: {path}")
    if not path.is_file():
        raise LocalValidationError(f"Model path is not a file: {path}")
    if path.suffix.lower() != ".onnx":
        raise LocalValidationError("Model file must end with .onnx.")
    return path


def _parse_json_payload(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise LocalValidationError(f"Invalid JSON for --options: {exc.msg}.") from exc


def resolve_options_json(options_value: Optional[str]) -> Optional[str]:
    if options_value is None:
        return None

    raw = options_value.strip()
    if not raw:
        raise LocalValidationError("--options cannot be empty.")

    if raw.startswith("@"):
        if raw == "@":
            raise LocalValidationError("--options file path is empty.")
        file_path = Path(raw[1:]).expanduser()
        if not file_path.exists():
            raise LocalValidationError(f"Options file does not exist: {file_path}")
        if not file_path.is_file():
            raise LocalValidationError(f"Options path is not a file: {file_path}")
        payload_text = file_path.read_text(encoding="utf-8")
    else:
        payload_text = raw

    parsed = _parse_json_payload(payload_text)
    return json.dumps(parsed)


def validate_output_directory(path_value: str) -> Path:
    target = Path(path_value).expanduser()
    if target.exists() and not target.is_dir():
        raise LocalValidationError(f"Output path is not a directory: {target}")
    if target.exists() and any(target.iterdir()):
        raise LocalValidationError(
            f"Output directory must be empty before download: {target}"
        )
    return target


def prepare_output_directory(path_value: str) -> Path:
    target = validate_output_directory(path_value)
    target.mkdir(parents=True, exist_ok=True)
    return target


def default_results_directory(job_id: str) -> Path:
    return Path("./results") / job_id


def safe_artifact_name(name: str) -> str:
    candidate = Path(name)
    if candidate.name != name or not name.strip():
        raise LocalValidationError(f"Invalid artifact name from API: {name!r}")
    return name
