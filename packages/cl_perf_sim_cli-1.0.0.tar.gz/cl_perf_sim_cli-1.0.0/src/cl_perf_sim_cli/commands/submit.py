from __future__ import annotations

from ..api_client import ApiClient
from ..config import build_runtime_config
from ..io import UploadProgressReporter, print_info
from ..validation import require_model_path, resolve_options_json


def handle(args) -> int:
    model_path = require_model_path(args.model)
    options_json = resolve_options_json(args.options)
    config = build_runtime_config(explicit_token=args.token, require_token=True)
    client = ApiClient(config.base_url)
    reporter = UploadProgressReporter(model_path.name, model_path.stat().st_size)
    try:
        payload = client.submit_job(
            model_path,
            config.token,
            options_json,
            progress_callback=reporter.update,
        )
    finally:
        reporter.finish()
    print_info(f"Job queued: {payload['job_id']}")
    print_info(f"Status: {payload['status']}")
    return 0
