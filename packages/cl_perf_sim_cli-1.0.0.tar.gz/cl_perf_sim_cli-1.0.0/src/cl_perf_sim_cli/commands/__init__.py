"""Command handlers for cl-perf-sim-cli."""
