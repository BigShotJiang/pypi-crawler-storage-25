from __future__ import annotations

from ..api_client import ApiClient
from ..config import build_runtime_config
from ..io import print_failure_block, print_info
from ..validation import require_job_id


def handle(args) -> int:
    job_id = require_job_id(args.job_id)
    config = build_runtime_config(explicit_token=args.token, require_token=True)
    client = ApiClient(config.base_url)
    payload = client.get_status(job_id, config.token)

    print_info(f"Job ID: {payload['job_id']}")
    print_info(f"Status: {payload['status']}")

    failure = payload.get("failure") or {}
    print_failure_block(failure.get("code"), failure.get("message"))
    return 0
