from __future__ import annotations

from pathlib import Path

from ..api_client import ApiClient
from ..config import build_runtime_config
from ..io import print_download_summary, print_failure_block, print_info
from ..validation import (
    default_results_directory,
    prepare_output_directory,
    require_job_id,
    safe_artifact_name,
    validate_output_directory,
)


def handle(args) -> int:
    job_id = require_job_id(args.job_id)
    config = build_runtime_config(explicit_token=args.token, require_token=True)
    output_dir_value = args.out or str(default_results_directory(job_id))
    validate_output_directory(output_dir_value)

    client = ApiClient(config.base_url)
    payload = client.get_results(job_id, config.token)

    artifacts = payload.get("artifacts") or {}
    download_count = 0

    if artifacts:
        output_dir = prepare_output_directory(output_dir_value)
        for artifact_name, artifact_ref in artifacts.items():
            safe_name = safe_artifact_name(artifact_name)
            destination = output_dir / safe_name
            client.download_artifact(artifact_ref, config.token, destination)
            download_count += 1
        print_download_summary(payload.get("status", "unknown"), output_dir, download_count)
    else:
        print_info(f"Status: {payload.get('status', 'unknown')}")
        print_info("No artifacts available for download.")

    failure = payload.get("failure") or {}
    print_failure_block(failure.get("code"), failure.get("message"))
    return 0
