from __future__ import annotations

from ..api_client import ApiClient
from ..config import build_runtime_config
from ..io import print_info
from ..validation import require_email


def handle(args) -> int:
    email = require_email(args.email_address)
    config = build_runtime_config(require_token=False)
    client = ApiClient(config.base_url)
    client.request_token(email)
    print_info("Check your email for a verification link.")
    return 0
