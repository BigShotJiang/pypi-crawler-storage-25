from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from .validation import LocalValidationError

DEFAULT_BASE_URL = "https://sim-api.chipletti.com/api/v1"
BASE_URL_ENV = "CL_PERF_SIM_BASE_URL"
TOKEN_ENV = "CL_PERF_SIM_TOKEN"


@dataclass(frozen=True)
class RuntimeConfig:
    base_url: str
    token: Optional[str] = None


def normalize_base_url(value: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise LocalValidationError("Base URL is empty.")
    return cleaned.rstrip("/")


def resolve_base_url(environ: Optional[dict[str, str]] = None) -> str:
    env = environ if environ is not None else os.environ
    return normalize_base_url(env.get(BASE_URL_ENV, DEFAULT_BASE_URL))


def resolve_token(explicit_token: Optional[str], environ: Optional[dict[str, str]] = None) -> str:
    token = (explicit_token or "").strip()
    if token:
        return token
    env = environ if environ is not None else os.environ
    env_token = env.get(TOKEN_ENV, "").strip()
    if env_token:
        return env_token
    raise LocalValidationError(
        "Missing token. Provide --token or set CL_PERF_SIM_TOKEN."
    )


def build_runtime_config(
    explicit_token: Optional[str] = None,
    environ: Optional[dict[str, str]] = None,
    require_token: bool = False,
) -> RuntimeConfig:
    base_url = resolve_base_url(environ=environ)
    token = None
    if require_token:
        token = resolve_token(explicit_token=explicit_token, environ=environ)
    elif explicit_token is not None or (environ or os.environ).get(TOKEN_ENV):
        token = resolve_token(explicit_token=explicit_token, environ=environ)
    return RuntimeConfig(base_url=base_url, token=token)
