"""Customer CLI for the Chipletti performance simulator service."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "cl-perf-sim-cli"


def get_version() -> str:
    """Return the installed CLI distribution version when available."""
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return "0+unknown"


__all__ = ["PACKAGE_NAME", "__version__", "get_version"]
__version__ = get_version()
