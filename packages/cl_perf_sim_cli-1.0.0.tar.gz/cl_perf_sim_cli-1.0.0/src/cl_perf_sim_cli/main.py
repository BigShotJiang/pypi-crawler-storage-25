from __future__ import annotations

import argparse
import sys
from typing import Callable, Optional

from . import get_version
from .api_client import ApiError
from .commands import cancel, get_token, resend_token, results, status, submit
from .io import format_api_error, print_error
from .validation import LocalValidationError

CommandHandler = Callable[[argparse.Namespace], int]


def _add_token_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--token",
        help="Bearer token. If omitted, CL_PERF_SIM_TOKEN is used when set.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cl-perf-sim-cli")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {get_version()}",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    get_token_parser = subparsers.add_parser("get_token", help="Request a verification email.")
    get_token_parser.add_argument("email_address", help="Email address to verify.")
    get_token_parser.set_defaults(handler=get_token.handle)

    resend_token_parser = subparsers.add_parser(
        "resend_token", help="Request that the service resend your token email."
    )
    resend_token_parser.add_argument("email_address", help="Previously verified email address.")
    resend_token_parser.set_defaults(handler=resend_token.handle)

    submit_parser = subparsers.add_parser("submit", help="Upload an ONNX model and queue a job.")
    submit_parser.add_argument("--model", required=True, help="Path to the ONNX model.")
    submit_parser.add_argument(
        "--options",
        help="Inline JSON or @path to a JSON file.",
    )
    _add_token_argument(submit_parser)
    submit_parser.set_defaults(handler=submit.handle)

    status_parser = subparsers.add_parser("status", help="Check the status of a job.")
    status_parser.add_argument("job_id", help="Job identifier in the form job_<uuid4>.")
    _add_token_argument(status_parser)
    status_parser.set_defaults(handler=status.handle)

    results_parser = subparsers.add_parser(
        "results", help="Fetch result metadata and download available artifacts."
    )
    results_parser.add_argument("job_id", help="Job identifier in the form job_<uuid4>.")
    results_parser.add_argument(
        "--out",
        help="Target directory for downloaded artifacts. Defaults to ./results/<job_id>/.",
    )
    _add_token_argument(results_parser)
    results_parser.set_defaults(handler=results.handle)

    cancel_parser = subparsers.add_parser("cancel", help="Cancel a queued or running job.")
    cancel_parser.add_argument("job_id", help="Job identifier in the form job_<uuid4>.")
    _add_token_argument(cancel_parser)
    cancel_parser.set_defaults(handler=cancel.handle)

    return parser


def run(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code or 0)
    handler: CommandHandler = args.handler
    try:
        return int(handler(args))
    except LocalValidationError as exc:
        print_error(str(exc))
        return 2
    except ApiError as exc:
        print_error(format_api_error(exc))
        return 3
    except KeyboardInterrupt:
        print_error("Interrupted.")
        return 1
    except Exception as exc:  # pragma: no cover - defensive fallback
        print_error(f"Unexpected error: {exc}")
        return 1


def main() -> None:
    sys.exit(run())


if __name__ == "__main__":  # pragma: no cover
    main()
