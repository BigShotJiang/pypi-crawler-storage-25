from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urljoin

import requests

from . import get_version

DEFAULT_TIMEOUT: tuple[int, int] = (10, 120)
SUBMIT_TIMEOUT: tuple[int, int] = (300, 600)
UPLOAD_CHUNK_SIZE = 64 * 1024
UploadProgressCallback = Callable[[int, int], None]


@dataclass
class ApiError(Exception):
    code: str
    message: str
    status_code: Optional[int] = None
    details: Optional[dict[str, Any]] = None

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


class MultipartUploadStream:
    """Streaming multipart/form-data body for large model uploads."""

    def __init__(
        self,
        model_path: Path,
        options_json: Optional[str],
        *,
        boundary: Optional[str] = None,
        chunk_size: int = UPLOAD_CHUNK_SIZE,
        progress_callback: Optional[UploadProgressCallback] = None,
    ) -> None:
        self.model_path = model_path
        self.options_json = options_json
        self.boundary = boundary or f"----cl-perf-sim-{uuid.uuid4().hex}"
        self.chunk_size = chunk_size
        self.progress_callback = progress_callback

        self._file_handle = model_path.open("rb")
        self._file_size = model_path.stat().st_size
        self._file_bytes_sent = 0
        self._closed = False

        self._segments: list[bytes | str] = []
        if options_json is not None:
            self._segments.append(self._options_part(options_json))
        self._segments.append(self._model_header_part())
        self._segments.append("__FILE__")
        self._segments.append(b"\r\n")
        self._segments.append(self._closing_part())

        self._segment_index = 0
        self._segment_offset = 0
        self._total_length = self._calculate_total_length()

    @property
    def content_type(self) -> str:
        return f"multipart/form-data; boundary={self.boundary}"

    def __len__(self) -> int:
        return self._total_length

    def __enter__(self) -> MultipartUploadStream:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if not self._closed:
            self._file_handle.close()
            self._closed = True

    def read(self, size: int = -1) -> bytes:
        if self._closed:
            return b""
        if size == 0:
            return b""

        target_size = None if size is None or size < 0 else size
        parts: list[bytes] = []
        total_read = 0

        while target_size is None or total_read < target_size:
            chunk = self._read_next_chunk(target_size, total_read)
            if not chunk:
                break
            parts.append(chunk)
            total_read += len(chunk)

        return b"".join(parts)

    def _read_next_chunk(self, target_size: Optional[int], total_read: int) -> bytes:
        while self._segment_index < len(self._segments):
            segment = self._segments[self._segment_index]
            if segment == "__FILE__":
                remaining = None if target_size is None else target_size - total_read
                read_size = self.chunk_size if remaining is None else max(1, min(self.chunk_size, remaining))
                data = self._file_handle.read(read_size)
                if data:
                    self._file_bytes_sent += len(data)
                    if self.progress_callback is not None:
                        self.progress_callback(self._file_bytes_sent, self._file_size)
                    return data
                self._segment_index += 1
                self._segment_offset = 0
                continue

            assert isinstance(segment, bytes)
            if self._segment_offset >= len(segment):
                self._segment_index += 1
                self._segment_offset = 0
                continue

            remaining_segment = segment[self._segment_offset :]
            if target_size is None:
                chunk = remaining_segment
            else:
                allowed = max(0, target_size - total_read)
                if allowed == 0:
                    return b""
                chunk = remaining_segment[:allowed]
            self._segment_offset += len(chunk)
            return chunk
        return b""

    def _calculate_total_length(self) -> int:
        total = self._file_size
        for segment in self._segments:
            if segment == "__FILE__":
                continue
            assert isinstance(segment, bytes)
            total += len(segment)
        return total

    def _options_part(self, options_json: str) -> bytes:
        return (
            f"--{self.boundary}\r\n"
            'Content-Disposition: form-data; name="options"\r\n\r\n'
            f"{options_json}\r\n"
        ).encode("utf-8")

    def _model_header_part(self) -> bytes:
        return (
            f"--{self.boundary}\r\n"
            f'Content-Disposition: form-data; name="model"; filename="{self.model_path.name}"\r\n'
            "Content-Type: application/octet-stream\r\n\r\n"
        ).encode("utf-8")

    def _closing_part(self) -> bytes:
        return f"--{self.boundary}--\r\n".encode("ascii")


class ApiClient:
    def __init__(
        self,
        base_url: str,
        session: Optional[requests.Session] = None,
        timeout: tuple[int, int] = DEFAULT_TIMEOUT,
        submit_timeout: tuple[int, int] = SUBMIT_TIMEOUT,
        cli_version: Optional[str] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.session = session or requests.Session()
        self.timeout = timeout
        self.submit_timeout = submit_timeout
        self.cli_version = get_version() if cli_version is None else cli_version

    def _headers(self, token: Optional[str] = None) -> dict[str, str]:
        headers: dict[str, str] = {"Accept": "application/json"}
        if self.cli_version:
            headers["X-CLI-Version"] = self.cli_version
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _absolute_artifact_url(self, artifact_ref: str) -> str:
        if artifact_ref.startswith("http://") or artifact_ref.startswith("https://"):
            return artifact_ref
        return urljoin(f"{self.base_url}/", artifact_ref)

    def _request(
        self,
        method: str,
        path: str,
        *,
        token: Optional[str] = None,
        expected_status: Optional[set[int]] = None,
        timeout: Optional[tuple[int, int]] = None,
        **kwargs: Any,
    ) -> requests.Response:
        headers = kwargs.pop("headers", {})
        merged_headers = {**self._headers(token), **headers}
        request_timeout = timeout if timeout is not None else self.timeout
        try:
            response = self.session.request(
                method,
                self._url(path),
                headers=merged_headers,
                timeout=request_timeout,
                **kwargs,
            )
        except requests.RequestException as exc:
            raise ApiError(
                code="network_error",
                message=f"Unable to reach service: {exc}",
                details={},
            ) from exc

        statuses = expected_status if expected_status is not None else {200}
        if response.status_code not in statuses:
            self._raise_api_error(response)
        return response

    def _raise_api_error(self, response: requests.Response) -> None:
        status_code = response.status_code
        try:
            payload = response.json()
        except ValueError:
            payload = None

        if isinstance(payload, dict) and isinstance(payload.get("error"), dict):
            error = payload["error"]
            raise ApiError(
                code=str(error.get("code", "api_error")),
                message=str(error.get("message", "Request failed.")),
                status_code=status_code,
                details=error.get("details") or {},
            )

        raise ApiError(
            code="api_error",
            message=f"Service returned HTTP {status_code}.",
            status_code=status_code,
            details={},
        )

    def request_token(self, email: str) -> dict[str, Any]:
        response = self._request(
            "POST",
            "/token-requests",
            json={"email": email},
            expected_status={202},
        )
        return response.json()

    def resend_token(self, email: str) -> dict[str, Any]:
        response = self._request(
            "POST",
            "/tokens/resend",
            json={"email": email},
            expected_status={202},
        )
        return response.json()

    def submit_job(
        self,
        model_path: Path,
        token: str,
        options_json: Optional[str],
        progress_callback: Optional[UploadProgressCallback] = None,
    ) -> dict[str, Any]:
        with MultipartUploadStream(
            model_path,
            options_json,
            progress_callback=progress_callback,
        ) as body:
            response = self._request(
                "POST",
                "/jobs",
                token=token,
                data=body,
                expected_status={201},
                timeout=self.submit_timeout,
                headers={
                    "Content-Type": body.content_type,
                    "Content-Length": str(len(body)),
                },
            )
        return response.json()

    def get_status(self, job_id: str, token: str) -> dict[str, Any]:
        response = self._request(
            "GET",
            f"/jobs/{job_id}",
            token=token,
            expected_status={200},
        )
        return response.json()

    def get_results(self, job_id: str, token: str) -> dict[str, Any]:
        response = self._request(
            "GET",
            f"/jobs/{job_id}/results",
            token=token,
            expected_status={200},
        )
        return response.json()

    def cancel_job(self, job_id: str, token: str) -> dict[str, Any]:
        response = self._request(
            "DELETE",
            f"/jobs/{job_id}",
            token=token,
            expected_status={200},
        )
        return response.json()

    def download_artifact(self, artifact_ref: str, token: str, destination: Path) -> None:
        url = self._absolute_artifact_url(artifact_ref)
        try:
            response = self.session.get(
                url,
                headers=self._headers(token),
                timeout=self.timeout,
                stream=True,
            )
        except requests.RequestException as exc:
            raise ApiError(
                code="network_error",
                message=f"Unable to download artifact: {exc}",
                details={},
            ) from exc

        if response.status_code != 200:
            self._raise_api_error(response)

        with destination.open("wb") as fh:
            for chunk in response.iter_content(chunk_size=65536):
                if chunk:
                    fh.write(chunk)
