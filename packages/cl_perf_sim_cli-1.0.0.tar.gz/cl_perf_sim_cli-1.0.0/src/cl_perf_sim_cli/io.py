from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from .api_client import ApiError

_PROGRESS_BAR_WIDTH = 24


def print_info(message: str) -> None:
    print(message)


def print_error(message: str) -> None:
    print(f"Error: {message}", file=sys.stderr)


def format_api_error(error: ApiError) -> str:
    message = error.message or "Request failed."
    details = error.details or {}

    if error.code == "token_in_use" and details.get("active_job_id"):
        return f"token_in_use. {message} Active job: {details['active_job_id']}"
    if error.code == "network_error":
        return message
    if error.code == "disposable_email_not_allowed":
        return message
    return f"{error.code}. {message}"


class UploadProgressReporter:
    def __init__(self, filename: str, total_bytes: int, stream=None) -> None:
        self.filename = filename
        self.total_bytes = total_bytes
        self.stream = stream or sys.stderr
        self._finished = False
        self._has_rendered = False
        self._last_bytes = -1

    def update(self, sent_bytes: int, total_bytes: int) -> None:
        total = total_bytes or self.total_bytes
        if total <= 0:
            return
        if sent_bytes == self._last_bytes and self._has_rendered:
            return

        self._last_bytes = sent_bytes
        self._has_rendered = True
        ratio = min(max(sent_bytes / total, 0.0), 1.0)
        filled = int(ratio * _PROGRESS_BAR_WIDTH)
        bar = "#" * filled + "-" * (_PROGRESS_BAR_WIDTH - filled)
        percent = int(ratio * 100)
        message = (
            f"\rUploading {self.filename}: [{bar}] {percent:3d}% "
            f"({self._format_bytes(sent_bytes)} / {self._format_bytes(total)})"
        )
        print(message, end="", file=self.stream, flush=True)
        if sent_bytes >= total:
            self.finish()

    def finish(self) -> None:
        if self._has_rendered and not self._finished:
            print(file=self.stream, flush=True)
            self._finished = True

    @staticmethod
    def _format_bytes(value: int) -> str:
        if value < 1024:
            return f"{value} B"
        if value < 1024 * 1024:
            return f"{value / 1024:.1f} KiB"
        return f"{value / (1024 * 1024):.1f} MiB"


def print_failure_block(code: Optional[str], message: Optional[str]) -> None:
    if code:
        print_info(f"Failure code: {code}")
    if message:
        print_info(f"Failure message: {message}")


def print_download_summary(status: str, output_dir: Path, artifact_count: int) -> None:
    print_info(f"Status: {status}")
    print_info(f"Artifacts downloaded: {artifact_count}")
    print_info(f"Saved to: {output_dir}")
