from __future__ import annotations

import io
import json
from importlib import metadata as importlib_metadata
from pathlib import Path

import pytest

from cl_perf_sim_cli import __version__, config, main, validation
from cl_perf_sim_cli.api_client import ApiClient, ApiError
from cl_perf_sim_cli.io import UploadProgressReporter

VALID_JOB_ID = "job_8f42b1c3-1234-4678-9012-acdeffedcba0"


class FakeResponse:
    def __init__(self, status_code=200, json_data=None, content=b"", chunks=None):
        self.status_code = status_code
        self._json_data = json_data
        self._content = content
        self._chunks = chunks if chunks is not None else [content]

    def json(self):
        if self._json_data is None:
            raise ValueError("No JSON")
        return self._json_data

    def iter_content(self, chunk_size=65536):
        del chunk_size
        for chunk in self._chunks:
            yield chunk


class FakeSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def request(self, method, url, **kwargs):
        if "data" in kwargs and hasattr(kwargs["data"], "read"):
            kwargs["captured_body"] = kwargs["data"].read()
        self.calls.append((method, url, kwargs))
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def get(self, url, **kwargs):
        self.calls.append(("GET", url, kwargs))
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def test_resolve_base_url_env_override(monkeypatch):
    monkeypatch.setenv(config.BASE_URL_ENV, "https://example.com/api/v1/")
    assert config.resolve_base_url() == "https://example.com/api/v1"


def test_resolve_token_prefers_explicit_over_env(monkeypatch):
    monkeypatch.setenv(config.TOKEN_ENV, "env-token")
    assert config.resolve_token("flag-token") == "flag-token"


def test_resolve_token_missing_raises(monkeypatch):
    monkeypatch.delenv(config.TOKEN_ENV, raising=False)
    with pytest.raises(validation.LocalValidationError):
        config.resolve_token(None)


def test_require_email_rejects_invalid():
    with pytest.raises(validation.LocalValidationError):
        validation.require_email("not-an-email")


def test_require_job_id_rejects_invalid():
    with pytest.raises(validation.LocalValidationError):
        validation.require_job_id("job_123")


def test_require_model_path_checks_suffix(tmp_path):
    model = tmp_path / "model.txt"
    model.write_text("x", encoding="utf-8")
    with pytest.raises(validation.LocalValidationError):
        validation.require_model_path(str(model))


def test_resolve_options_json_inline():
    result = validation.resolve_options_json('{"batch": 4}')
    assert json.loads(result) == {"batch": 4}


def test_resolve_options_json_file(tmp_path):
    payload = tmp_path / "options.json"
    payload.write_text('{"batch": 8}', encoding="utf-8")
    result = validation.resolve_options_json(f"@{payload}")
    assert json.loads(result) == {"batch": 8}


def test_prepare_output_directory_rejects_non_empty(tmp_path):
    target = tmp_path / "out"
    target.mkdir()
    (target / "existing.txt").write_text("x", encoding="utf-8")
    with pytest.raises(validation.LocalValidationError):
        validation.validate_output_directory(str(target))


def test_upload_progress_reporter_renders_completion():
    stream = io.StringIO()
    reporter = UploadProgressReporter("model.onnx", 1024, stream=stream)
    reporter.update(512, 1024)
    reporter.update(1024, 1024)
    output = stream.getvalue()
    assert "Uploading model.onnx:" in output
    assert "100%" in output


def test_runtime_package_version_matches_distribution_metadata():
    assert __version__ == importlib_metadata.version("cl-perf-sim-cli")


def test_run_version_prints_cli_version_and_exits_zero(capsys):
    exit_code = main.run(["--version"])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert f"cl-perf-sim-cli {__version__}" in captured.out
    assert captured.err == ""


def test_run_help_still_works_after_version_addition(capsys):
    exit_code = main.run(["-h"])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert "usage:" in captured.out
    assert "--version" in captured.out


def test_api_client_request_token_posts_expected_json_and_cli_version_header():
    session = FakeSession([
        FakeResponse(status_code=202, json_data={"message": "ok"}),
    ])
    client = ApiClient("https://sim-api.chipletti.com/api/v1", session=session)
    payload = client.request_token("alice@example.com")
    assert payload == {"message": "ok"}
    method, url, kwargs = session.calls[0]
    assert method == "POST"
    assert url.endswith("/token-requests")
    assert kwargs["json"] == {"email": "alice@example.com"}
    assert kwargs["headers"]["X-CLI-Version"] == __version__


def test_api_client_submit_sends_streaming_multipart_progress_and_cli_version_header(tmp_path):
    model = tmp_path / "model.onnx"
    model.write_bytes(b"onnx")
    session = FakeSession([
        FakeResponse(status_code=201, json_data={"job_id": VALID_JOB_ID, "status": "queued"}),
    ])
    progress_updates = []

    client = ApiClient("https://sim-api.chipletti.com/api/v1", session=session)
    payload = client.submit_job(
        model,
        "secret-token",
        '{"batch": 4}',
        progress_callback=lambda sent, total: progress_updates.append((sent, total)),
    )
    assert payload["status"] == "queued"
    method, url, kwargs = session.calls[0]
    assert method == "POST"
    assert url.endswith("/jobs")
    assert kwargs["headers"]["Authorization"] == "Bearer secret-token"
    assert kwargs["headers"]["X-CLI-Version"] == __version__
    assert kwargs["headers"]["Content-Type"].startswith("multipart/form-data; boundary=")
    body = kwargs["captured_body"]
    assert b'name="options"' in body
    assert b'{"batch": 4}' in body
    assert b'name="model"; filename="model.onnx"' in body
    assert b"onnx" in body
    assert progress_updates[-1] == (4, 4)


def test_api_client_raises_structured_api_error():
    session = FakeSession([
        FakeResponse(
            status_code=409,
            json_data={
                "error": {
                    "code": "token_in_use",
                    "message": "This email already has an active job.",
                    "details": {"active_job_id": VALID_JOB_ID},
                }
            },
        )
    ])
    client = ApiClient("https://sim-api.chipletti.com/api/v1", session=session)
    with pytest.raises(ApiError) as exc_info:
        client.get_status(VALID_JOB_ID, "secret-token")
    assert exc_info.value.code == "token_in_use"
    assert exc_info.value.details["active_job_id"] == VALID_JOB_ID


def test_api_client_download_artifact_relative_url(tmp_path):
    session = FakeSession([
        FakeResponse(status_code=200, chunks=[b"hello", b"world"]),
    ])
    client = ApiClient("https://sim-api.chipletti.com/api/v1", session=session)
    destination = tmp_path / "metrics.json"
    client.download_artifact("/api/v1/jobs/x/artifacts/metrics.json", "secret-token", destination)
    assert destination.read_bytes() == b"helloworld"
    method, url, kwargs = session.calls[0]
    assert method == "GET"
    assert url == "https://sim-api.chipletti.com/api/v1/jobs/x/artifacts/metrics.json"
    assert kwargs["headers"]["Authorization"] == "Bearer secret-token"
    assert kwargs["headers"]["X-CLI-Version"] == __version__


def test_run_get_token_success(monkeypatch, capsys):
    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def request_token(self, email):
            assert email == "alice@example.com"
            return {"message": "ok"}

    monkeypatch.setattr("cl_perf_sim_cli.commands.get_token.ApiClient", StubClient)
    exit_code = main.run(["get_token", "alice@example.com"])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert "verification link" in captured.out


def test_run_get_token_disposable_email_surfaces_clear_message(monkeypatch, capsys):
    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def request_token(self, email):
            raise ApiError(
                code="disposable_email_not_allowed",
                message="Disposable email addresses are not allowed. Please use a non-disposable email address.",
                status_code=400,
                details={},
            )

    monkeypatch.setattr("cl_perf_sim_cli.commands.get_token.ApiClient", StubClient)
    exit_code = main.run(["get_token", "alice@mailinator.com"])
    captured = capsys.readouterr()
    assert exit_code == 3
    assert captured.out == ""
    assert "Disposable email addresses are not allowed." in captured.err
    assert "disposable_email_not_allowed" not in captured.err


def test_run_resend_token_success(monkeypatch, capsys):
    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def resend_token(self, email):
            assert email == "alice@example.com"
            return {"message": "ok"}

    monkeypatch.setattr("cl_perf_sim_cli.commands.resend_token.ApiClient", StubClient)
    exit_code = main.run(["resend_token", "alice@example.com"])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert "Check your email" in captured.out


def test_run_resend_token_disposable_email_surfaces_clear_message(monkeypatch, capsys):
    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def resend_token(self, email):
            raise ApiError(
                code="disposable_email_not_allowed",
                message="Disposable email addresses are not allowed. Please use a non-disposable email address.",
                status_code=400,
                details={},
            )

    monkeypatch.setattr("cl_perf_sim_cli.commands.resend_token.ApiClient", StubClient)
    exit_code = main.run(["resend_token", "alice@mailinator.com"])
    captured = capsys.readouterr()
    assert exit_code == 3
    assert captured.out == ""
    assert "Disposable email addresses are not allowed." in captured.err
    assert "disposable_email_not_allowed" not in captured.err


def test_run_submit_uses_env_token_and_reports_progress(monkeypatch, tmp_path, capsys):
    model = tmp_path / "model.onnx"
    model.write_bytes(b"onnx")
    monkeypatch.setenv("CL_PERF_SIM_TOKEN", "env-secret")

    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def submit_job(self, model_path, token, options_json, progress_callback=None):
            assert model_path == model
            assert token == "env-secret"
            assert json.loads(options_json) == {"batch": 4}
            assert progress_callback is not None
            progress_callback(2, 4)
            progress_callback(4, 4)
            return {"job_id": VALID_JOB_ID, "status": "queued"}

    monkeypatch.setattr("cl_perf_sim_cli.commands.submit.ApiClient", StubClient)
    exit_code = main.run([
        "submit",
        "--model",
        str(model),
        "--options",
        '{"batch": 4}',
    ])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert VALID_JOB_ID in captured.out
    assert "100%" in captured.err
    assert "env-secret" not in captured.out
    assert "env-secret" not in captured.err


def test_run_submit_invalid_options_returns_exit_2(tmp_path, capsys):
    model = tmp_path / "model.onnx"
    model.write_bytes(b"onnx")
    exit_code = main.run([
        "submit",
        "--model",
        str(model),
        "--options",
        "{bad json}",
        "--token",
        "secret-token",
    ])
    captured = capsys.readouterr()
    assert exit_code == 2
    assert "Invalid JSON" in captured.err
    assert "secret-token" not in captured.err


def test_run_status_failed_state_exits_zero(monkeypatch, capsys):
    class StubClient:
        def __init__(self, base_url):
            self.base_url = base_url

        def get_status(self, job_id, token):
            assert token == "secret-token"
            return {
                "job_id": job_id,
                "status": "failed",
                "failure": {"code": "timeout", "message": "Simulator exceeded timeout."},
            }

    monkeypatch.setattr("cl_perf_sim_cli.commands.status.ApiClient", StubClient)
    exit_code = main.run(["status", VALID_JOB_ID, "--token", "secret-token"])
    captured = capsys.readouterr()
    assert exit_code == 0
    assert "Status: failed" in captured.out
