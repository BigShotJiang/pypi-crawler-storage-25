# cl-perf-sim-cli

`cl-perf-sim-cli` is the user-facing command-line client to access Chipletti's performance simulator hosted on the cloud.

It lets you:
- request and resend an access token by verified email
- submit an ONNX model for simulation
- check job status
- download the plain-text summary result
- cancel a queued or running job

## Install

```bash
pip install cl-perf-sim-cli
```

## Quick start

Request a token:

```bash
cl-perf-sim-cli get_token alice@example.com
```

Disposable email addresses are rejected with a clear error, so use a non-disposable address you can receive email at.

Submit a model after you receive your token:

```bash
export CL_PERF_SIM_TOKEN="<token>"
cl-perf-sim-cli submit --model ./model.onnx
```

Check status:

```bash
cl-perf-sim-cli status job_8f42b1c3-1234-4678-9012-acdeffedcba0
```

Download results:

```bash
cl-perf-sim-cli results job_8f42b1c3-1234-4678-9012-acdeffedcba0
```

## Command summary

- `get_token <email_address>`
- `resend_token <email_address>`
- `submit --model <path-to-onnx> [--token <token>] [--options <json-or-@file>]`
- `status <job_id> [--token <token>]`
- `results <job_id> [--token <token>] [--out <dir>]`
- `cancel <job_id> [--token <token>]`
- `--version`

## Configuration

Environment overrides:
- `CL_PERF_SIM_BASE_URL`
- `CL_PERF_SIM_TOKEN`

## Documentation

Full user documentation is available at https://cl-perf-sim-cli.readthedocs.io
