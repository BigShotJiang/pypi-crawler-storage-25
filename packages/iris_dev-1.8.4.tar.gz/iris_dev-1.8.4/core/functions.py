import re
from pathlib import Path

BRACE_LANGUAGES = [".cs", ".js", ".ts", ".java", ".go", ".c", ".cpp", ".kt"]
INDENT_LANGUAGES = [".py"]


def get_language(filepath):
    ext = Path(filepath).suffix.lower()
    if ext in BRACE_LANGUAGES:
        return "brace"
    if ext in INDENT_LANGUAGES:
        return "indent"
    return "brace"


def get_indent(line):
    return len(line) - len(line.lstrip())


def normalize_indent(new_text, target_indent):
    lines = new_text.split("\n")
    if not lines:
        return new_text

    non_empty = [l for l in lines if l.strip()]
    if not non_empty:
        return new_text

    min_indent = min(get_indent(l) for l in non_empty)

    result = []
    for line in lines:
        if line.strip() == "":
            result.append("")
        else:
            stripped = line[min_indent:]
            result.append(" " * target_indent + stripped)

    return "\n".join(result)


def strip_imports_from_function(text, lang):
    if lang != "indent":
        return text

    lines = text.split("\n")
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("import ") or stripped.startswith("from "):
            continue
        cleaned.append(line)
    return "\n".join(cleaned)


def extract_function_from_model_response(text, func_name, lang):
    if lang == "indent":
        lines = text.split("\n")
        start_line = None
        base_indent = None

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            if stripped.startswith("def " + func_name + "(") or stripped.startswith("async def " + func_name + "("):
                start_line = i
                base_indent = len(line) - len(stripped)
                break

        if start_line is None:
            return text

        end_line = start_line + 1
        while end_line < len(lines):
            line = lines[end_line]
            if line.strip() == "":
                end_line += 1
                continue
            current_indent = len(line) - len(line.lstrip())
            if current_indent <= base_indent and end_line > start_line + 1:
                break
            end_line += 1

        while end_line > start_line + 1 and lines[end_line - 1].strip() == "":
            end_line -= 1

        return "\n".join(lines[start_line:end_line])
    else:
        pattern = re.compile(
            r'((?:(?:public|private|protected|static|async|override|virtual|abstract|internal|readonly|func|fun)\s+)*'
            r'[\w<>\[\]]+\s+' + re.escape(func_name) + r'\s*\([^)]*\)\s*\{)',
            re.MULTILINE
        )
        match = pattern.search(text)
        if not match:
            return text

        start = match.start()
        brace_pos = text.index("{", start)
        depth = 0
        i = brace_pos

        while i < len(text):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
            i += 1

        return text


def extract_function_brace(source, func_name):
    pattern = re.compile(
        r'((?:(?:public|private|protected|static|async|override|virtual|abstract|internal|readonly|func|fun)\s+)*'
        r'[\w<>\[\]]+\s+' + re.escape(func_name) + r'\s*\([^)]*\)\s*\{)',
        re.MULTILINE
    )

    match = pattern.search(source)
    if not match:
        return None, None, None

    start = match.start()
    brace_pos = source.index("{", match.start())
    depth = 0
    i = brace_pos

    while i < len(source):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                return source[start:end], start, end
        i += 1

    return None, None, None


def extract_function_indent(source, func_name):
    lines = source.split("\n")
    start_line = None
    base_indent = None

    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("def " + func_name + "(") or stripped.startswith("async def " + func_name + "("):
            start_line = i
            base_indent = len(line) - len(stripped)
            break

    if start_line is None:
        return None, None, None, None

    end_line = start_line + 1
    while end_line < len(lines):
        line = lines[end_line]
        if line.strip() == "":
            end_line += 1
            continue
        current_indent = len(line) - len(line.lstrip())
        if current_indent <= base_indent and end_line > start_line + 1:
            break
        end_line += 1

    while end_line > start_line + 1 and lines[end_line - 1].strip() == "":
        end_line -= 1

    func_text = "\n".join(lines[start_line:end_line])
    char_start = sum(len(l) + 1 for l in lines[:start_line])
    char_end = char_start + len(func_text)

    return func_text, char_start, char_end, base_indent


def extract_function_brace_with_indent(source, func_name):
    result = extract_function_brace(source, func_name)
    if result[0] is None:
        return None, None, None, 0
    text, start, end = result
    line_start = source.rfind("\n", 0, start)
    line_text = source[line_start + 1:start]
    indent = len(line_text) - len(line_text.lstrip())
    return text, start, end, indent


def extract_function(source, func_name, lang):
    if lang == "indent":
        result = extract_function_indent(source, func_name)
        if result[0] is None:
            return None, None, None
        return result[0], result[1], result[2]
    result = extract_function_brace_with_indent(source, func_name)
    return result[0], result[1], result[2]


def extract_function_with_indent(source, func_name, lang):
    if lang == "indent":
        return extract_function_indent(source, func_name)
    return extract_function_brace_with_indent(source, func_name)


def extract_functions_from_file(source, func_names, filepath):
    lang = get_language(filepath)
    result = {}

    for name in func_names:
        text, start, end, indent = extract_function_with_indent(source, name, lang)
        if text:
            result[name] = {"text": text, "start": start, "end": end, "indent": indent}
        else:
            print("  [WARN] Function not found: " + name + " in " + filepath)

    return result


def inject_functions(original_source, updated_functions, filepath):
    lang = get_language(filepath)
    source = original_source

    func_positions = []
    for func_name, new_text in updated_functions.items():
        result = extract_function_with_indent(source, func_name, lang)
        text, start, end, indent = result
        if start is None:
            print("  [WARN] Could not inject: " + func_name + " — not found in original")
            continue

        cleaned_text = extract_function_from_model_response(new_text, func_name, lang)

        cleaned_text = strip_imports_from_function(cleaned_text, lang)

        func_positions.append((start, end, cleaned_text, indent, func_name))

    func_positions.sort(key=lambda x: x[0], reverse=True)

    for start, end, new_text, indent, func_name in func_positions:
        normalized = normalize_indent(new_text, indent)
        source = source[:start] + normalized + source[end:]
        print("  [INJECTED] " + func_name)

    return source


def build_functions_context(source, func_names, forbidden_funcs, filepath):
    allowed = [f for f in func_names if f not in forbidden_funcs]
    extracted = extract_functions_from_file(source, allowed, filepath)
    return {name: data["text"] for name, data in extracted.items()}