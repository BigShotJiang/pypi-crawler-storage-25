import os
from pathlib import Path
from core.functions import build_functions_context, inject_functions

IGNORE_FILES = [".env", ".env.local", ".env.production"]
IGNORE_EXTENSIONS = [".yaml", ".yml"]


def normalize_path(path):
    return path.replace("\\", "/")


def read_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return None


def get_ignore_dirs():
    try:
        from core.config import get_ignore_dirs as _get
        return _get()
    except Exception:
        return [".git", "node_modules", "__pycache__", "dist", ".venv"]


def collect_project_files(base_path, forbidden):
    ignore_dirs = get_ignore_dirs()
    forbidden_normalized = [normalize_path(f) for f in forbidden]
    files = {}

    for root, dirs, filenames in os.walk(base_path):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]

        for filename in filenames:
            if filename in IGNORE_FILES:
                continue
            if any(filename.endswith(ext) for ext in IGNORE_EXTENSIONS):
                continue

            filepath = Path(root) / filename
            rel = normalize_path(str(filepath.relative_to(base_path)))

            if rel in forbidden_normalized:
                continue

            content = read_file(filepath)
            if content is not None:
                files[rel] = content

    return files


def collect_write_files(base_path, write_list):
    files = {}

    for item in write_list:
        if isinstance(item, dict):
            rel = normalize_path(list(item.keys())[0])
            meta = item[list(item.keys())[0]]
            func_names = meta.get("functions", []) if meta else []
            forbidden_funcs = meta.get("forbidden_functions", []) if meta else []
            filepath = Path(base_path) / rel

            if filepath.exists():
                source = read_file(filepath) or ""
                if func_names:
                    funcs = build_functions_context(source, func_names, forbidden_funcs, rel)
                    files[rel] = {
                        "mode": "functions",
                        "functions": funcs,
                        "forbidden_functions": forbidden_funcs
                    }
                else:
                    files[rel] = {"mode": "full", "content": source}
            else:
                files[rel] = {"mode": "full", "content": ""}
        else:
            rel = normalize_path(item)
            filepath = Path(base_path) / rel
            content = read_file(filepath) if filepath.exists() else ""
            files[rel] = {"mode": "full", "content": content or ""}

    return files


def apply_changes(base_path, changes, forbidden, write_list):
    forbidden_normalized = [normalize_path(f) for f in forbidden]

    write_normalized = {}
    for item in write_list:
        if isinstance(item, dict):
            rel = normalize_path(list(item.keys())[0])
            write_normalized[rel] = item[list(item.keys())[0]]
        else:
            write_normalized[normalize_path(item)] = {}

    changed = []

    for rel_path, content in changes.items():
        rel_normalized = normalize_path(rel_path)

        if rel_normalized not in write_normalized:
            matched = None
            returned_name = Path(rel_normalized).name
            for allowed_path in write_normalized:
                if Path(allowed_path).name == returned_name:
                    matched = allowed_path
                    break

            if matched:
                print("  [FUZZY]    " + rel_normalized + " -> " + matched)
                rel_normalized = matched
            else:
                print("  [BLOCKED]  " + rel_normalized + " (not in write list)")
                continue

        if rel_normalized in forbidden_normalized:
            print("  [BLOCKED]  " + rel_normalized + " (forbidden)")
            continue

        filepath = Path(base_path) / rel_normalized
        filepath.parent.mkdir(parents=True, exist_ok=True)

        item_meta = write_normalized[rel_normalized] or {}
        func_names = item_meta.get("functions", [])

        if func_names and isinstance(content, dict) and filepath.exists():
            original = read_file(filepath) or ""
            final = inject_functions(original, content, rel_normalized)
        else:
            final = content if isinstance(content, str) else ""

        if not final.strip():
            print("  [WARN] Skipping " + rel_normalized + " (empty content)")
            continue

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(final)

        changed.append(rel_normalized)
        print("  [WRITTEN]  " + rel_normalized)

    return changed


def collect_reference_files(base_path, reference_list):
    files = {}
    for rel in reference_list:
        filepath = Path(base_path) / rel
        if filepath.exists():
            content = read_file(filepath)
            if content is not None:
                files[normalize_path(rel)] = content
            else:
                print("  [WARN] Could not read reference file: " + rel)
        else:
            print("  [WARN] Reference file not found: " + rel)
    return files


def collect_read_files(base_path, read_files):
    files = {}
    for rel in read_files:
        filepath = Path(base_path) / rel
        if filepath.exists():
            content = read_file(filepath)
            if content is not None:
                files[normalize_path(rel)] = content
            else:
                print("  [WARN] Could not read file: " + rel)
        else:
            print("  [WARN] Read file not found: " + rel)
    return files