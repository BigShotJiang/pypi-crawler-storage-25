import sys
import yaml
from pathlib import Path


def load_yaml(path):
    if not Path(path).exists():
        print("[ERROR] File not found: " + str(path))
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not data:
        print("[ERROR] YAML file is empty")
        sys.exit(1)

    return data


def validate_config(config):
    if not config.get("task"):
        print("[ERROR] 'task' field is required")
        sys.exit(1)

    if not config.get("access", {}).get("write"):
        print("[ERROR] 'access.write' field is required")
        sys.exit(1)

    if not config.get("instructions"):
        print("[ERROR] 'instructions' field is required")
        sys.exit(1)


def parse_write_list(raw_write):
    result = []

    for item in raw_write:
        if isinstance(item, str):
            result.append(item)
        elif isinstance(item, dict):
            for filepath, meta in item.items():
                entry = {
                    filepath: {
                        "functions": meta.get("functions", []) if meta else [],
                        "forbidden_functions": meta.get("forbidden_functions", []) if meta else []
                    }
                }
                result.append(entry)

    return result


def parse_config(path):
    config = load_yaml(path)
    validate_config(config)

    read_value = config.get("access", {}).get("read", False)

    if isinstance(read_value, list):
        read_all = False
        read_files = read_value
    elif read_value == True:
        read_all = True
        read_files = []
    else:
        read_all = False
        read_files = []

    raw_write = config.get("access", {}).get("write", [])
    write_list = parse_write_list(raw_write)

    return {
        "task": config["task"],
        "instructions": config.get("instructions", ""),
        "read_all": read_all,
        "read_files": read_files,
        "write_list": write_list,
        "forbidden": config.get("access", {}).get("forbidden", []),
        "feedback": config.get("feedback", False),
        "tips": config.get("tips", False),
        "error": config.get("error", ""),
        "reference": config.get("reference", []),
        "backup": config.get("backup", False),
        "model": config.get("model", ""),
        "temperature": config.get("temperature", None),
    }