import sys
import ollama

DEFAULT_MODEL = "qwen2.5-coder:7b"
DEFAULT_TEMPERATURE = 0.1


def build_system_prompt(write_files, forbidden, has_functions, tips, feedback):
    write_paths = list(write_files.keys())
    forbidden_paths = forbidden if forbidden else []

    system = "You are a coding agent. Follow these rules STRICTLY.\n\n"

    system += "== RESPONSE FORMAT ==\n"
    if has_functions:
        system += """You MUST respond using ONLY this exact format for every function:

FILE: path/to/file
FUNCTION: FunctionName
```
full function content here
```

Rules:
- Start your response IMMEDIATELY with FILE:
- Do NOT write any explanation, greeting, or text outside of FILE:/FUNCTION: blocks
- Do NOT skip any function from the list
- Always output the COMPLETE function content
- Do NOT modify anything outside the given functions
"""
    else:
        system += """You MUST respond using ONLY this exact format for every file:

FILE: path/to/file
```
full file content here
```

Rules:
- Start your response IMMEDIATELY with FILE:
- Do NOT write any explanation, greeting, or text outside of FILE: blocks
- Do NOT skip any file from the write list
- Always output the COMPLETE file content
"""

    system += "\n== FILE ACCESS RULES ==\n"
    system += "You are ONLY allowed to write these exact files:\n"
    for path in write_paths:
        system += "  - " + path + "\n"

    system += "\nCRITICAL FILE RULES:\n"
    system += "- Use EXACTLY these file paths. Do NOT rename them.\n"
    system += "- Do NOT create subdirectories or change paths.\n"
    system += "- If you cannot fit all files, write as many as you can and add a TIPS block.\n"

    if forbidden_paths:
        system += "\nYou must NEVER touch these files:\n"
        for path in forbidden_paths:
            system += "  - " + path + "\n"

    if tips or feedback:
        system += "\n== TIPS BLOCK ==\n"
        system += """After all FILE: blocks, add a TIPS block if:
- A file from the write list was skipped due to context length — explain which one and suggest splitting into separate yaml
- There is a missing import or connection between files
- A change in another file is required for this to work
Format:
TIPS
- short advice here (mention exact file if relevant)
"""

    return system


def build_user_prompt(task, instructions, error, reference, read_context, write_files, has_functions):
    prompt = ""

    if task:
        prompt += "Task: " + task + "\n\n"

    if error:
        prompt += "Error to fix:\n" + error + "\n\n"

    if read_context:
        prompt += "Project context (read-only):\n"
        for path, content in read_context.items():
            prompt += "\n--- " + path + " ---\n" + content + "\n"

    if reference:
        prompt += "\nReference files:\n"
        for path, content in reference.items():
            prompt += "\n--- " + path + " ---\n" + content + "\n"

    if has_functions:
        prompt += "\nFiles and functions you are allowed to modify:\n"
        for path, data in write_files.items():
            if isinstance(data, dict) and data.get("mode") == "functions":
                prompt += "\n--- " + path + " ---\n"
                prompt += "Modify ONLY these functions:\n"
                for func_name, func_text in data["functions"].items():
                    prompt += "\nFUNCTION: " + func_name + "\n```\n" + func_text + "\n```\n"
                if data.get("forbidden_functions"):
                    prompt += "\nNEVER touch these functions: " + ", ".join(data["forbidden_functions"]) + "\n"
            else:
                content = data.get("content", "") if isinstance(data, dict) else data
                if content:
                    prompt += "\n--- " + path + " ---\n" + content + "\n"
                else:
                    prompt += "\n--- " + path + " --- (does not exist, create it)\n"
    else:
        prompt += "\nFiles to modify or create:\n"
        for path, data in write_files.items():
            content = data.get("content", "") if isinstance(data, dict) else data
            if content:
                prompt += "\n--- " + path + " ---\n" + content + "\n"
            else:
                prompt += "\n--- " + path + " --- (does not exist, create it)\n"

    if instructions:
        if isinstance(instructions, list):
            prompt += "\nInstructions:\n" + "\n".join("- " + i for i in instructions) + "\n"
        else:
            prompt += "\nInstructions:\n" + instructions + "\n"

    return prompt


def parse_response(response_text):
    results = {}
    current_file = None
    current_function = None
    in_block = False
    block_lines = []

    for line in response_text.split("\n"):
        if line.startswith("FILE:"):
            if current_file and block_lines:
                if current_function:
                    if current_file not in results:
                        results[current_file] = {}
                    if isinstance(results[current_file], dict):
                        results[current_file][current_function] = "\n".join(block_lines)
                else:
                    results[current_file] = "\n".join(block_lines)
            current_file = line.replace("FILE:", "").strip()
            current_function = None
            in_block = False
            block_lines = []

        elif line.startswith("FUNCTION:") and current_file:
            if current_function and block_lines:
                if current_file not in results:
                    results[current_file] = {}
                if isinstance(results[current_file], dict):
                    results[current_file][current_function] = "\n".join(block_lines)
            current_function = line.replace("FUNCTION:", "").strip()
            in_block = False
            block_lines = []

        elif line.startswith("```") and current_file:
            in_block = not in_block

        elif in_block and current_file:
            block_lines.append(line)

    if current_file and block_lines:
        if current_function:
            if current_file not in results:
                results[current_file] = {}
            if isinstance(results[current_file], dict):
                results[current_file][current_function] = "\n".join(block_lines)
        else:
            results[current_file] = "\n".join(block_lines)

    return results


def call_ollama(system_prompt, user_prompt, model, temperature):
    try:
        response = ollama.chat(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            options={"temperature": temperature}
        )
        return response["message"]["content"]
    except Exception as e:
        print("[ERROR] Ollama failed: " + str(e))
        print("[HINT] Make sure Ollama is running: ollama serve")
        print("[HINT] Make sure model is pulled: ollama pull " + model)
        sys.exit(1)


def execute(task, instructions, error, reference, read_context, write_files, tips, model, temperature=None, feedback=False, forbidden=None):
    active_model = model if model else DEFAULT_MODEL
    active_temperature = temperature if temperature is not None else DEFAULT_TEMPERATURE
    print("  [MODEL]    " + active_model)
    print("  [TEMP]     " + str(active_temperature))

    has_functions = any(
        isinstance(v, dict) and v.get("mode") == "functions"
        for v in write_files.values()
    )

    system_prompt = build_system_prompt(write_files, forbidden or [], has_functions, tips, feedback)
    user_prompt = build_user_prompt(task, instructions, error, reference, read_context, write_files, has_functions)

    response_text = call_ollama(system_prompt, user_prompt, active_model, active_temperature)
    changes = parse_response(response_text)

    if not changes:
        print("  [WARN] No FILE: blocks found in response")

    return changes, response_text