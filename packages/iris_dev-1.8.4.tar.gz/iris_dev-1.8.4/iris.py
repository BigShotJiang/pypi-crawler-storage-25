import sys
import json
import ollama
from pathlib import Path
from datetime import datetime

from core.parser import parse_config
from core.access import collect_project_files, collect_write_files, collect_read_files, apply_changes, collect_reference_files
from core.executor import execute, DEFAULT_MODEL
from core.reporter import save_feedback, collect_backup
from core.config import init, get_project_path

if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).parent
else:
    BASE_DIR = Path(__file__).parent

LAST_RUN_FILE = BASE_DIR / "iris_last_run.json"
HISTORY_FILE = BASE_DIR / "iris_history.json"


def load_history():
    if not HISTORY_FILE.exists():
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_history_entry(yaml_path, changed_files, model):
    history = load_history()
    history.append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "yaml": yaml_path,
        "changed_files": changed_files,
        "model": model
    })
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)


def save_last_run(changed_files, backup_data, base_path):
    data = {
        "changed_files": changed_files,
        "backup": backup_data,
        "base_path": str(base_path)
    }
    with open(LAST_RUN_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def load_last_run():
    if not LAST_RUN_FILE.exists():
        return None
    with open(LAST_RUN_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def undo():
    print("\niris — undo\n")

    base_path = get_project_path()
    if not base_path:
        sys.exit(1)

    report_path = base_path / "iris_report.yaml"
    if not report_path.exists():
        print("[ERROR] iris_report.yaml not found in project folder.")
        print("[HINT] Run with feedback: true and backup: true first.")
        sys.exit(1)

    import yaml
    with open(report_path, "r", encoding="utf-8") as f:
        report = yaml.safe_load(f)

    backup = report.get("backup", {})
    if not backup:
        print("[ERROR] No backup found in iris_report.yaml.")
        print("[HINT] Run with backup: true to enable undo.")
        sys.exit(1)

    for rel_path, content in backup.items():
        filepath = base_path / rel_path
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)
        print("  [RESTORED] " + rel_path)

    print("\niris — undo complete\n")


def history():
    print("\niris — history\n")

    entries = load_history()

    if not entries:
        print("  No runs yet.\n")
        return

    for i, entry in enumerate(reversed(entries), 1):
        print("  [" + str(i) + "] " + entry["timestamp"] + " — " + entry["yaml"])
        print("      Model:   " + entry["model"])
        if entry["changed_files"]:
            print("      Changed: " + ", ".join(entry["changed_files"]))
        else:
            print("      Changed: none")
        print()


def status():
    print("\niris — status\n")

    config_path = BASE_DIR / "iris.config.json"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        print("  Project:   " + config.get("project_path", "not set"))
        print("  Profile:   " + config.get("profile", "custom"))
    else:
        print("  Project:   not initialized")

    print("  Model:     " + DEFAULT_MODEL)

    try:
        ollama.list()
        print("  Ollama:    running ✓")
    except Exception:
        print("  Ollama:    not running ✗")

    last_run = load_last_run()
    if last_run:
        files = last_run.get("changed_files", [])
        print("  Last run:  " + str(len(files)) + " file(s) changed")
        if last_run.get("backup"):
            print("  Backup:    available (iris undo to restore)")
        else:
            print("  Backup:    not available")
    else:
        print("  Last run:  none")

    print()


def validate(yaml_path):
    import yaml as pyyaml

    print("\niris — validate " + yaml_path + "\n")

    base_path = get_project_path()
    if not base_path:
        sys.exit(1)

    yaml_full_path = base_path / yaml_path

    if not yaml_full_path.exists():
        print("[ERROR] File not found: " + yaml_path)
        sys.exit(1)

    try:
        with open(yaml_full_path, "r", encoding="utf-8") as f:
            config = pyyaml.safe_load(f)
    except pyyaml.YAMLError as e:
        print("[ERROR] Invalid YAML syntax:\n" + str(e))
        sys.exit(1)

    if not config:
        print("[ERROR] YAML file is empty")
        sys.exit(1)

    errors = []
    warnings = []

    if not config.get("task"):
        errors.append("'task' field is required")

    if not config.get("access", {}).get("write"):
        errors.append("'access.write' field is required")

    if not config.get("instructions"):
        errors.append("'instructions' field is required")

    read_value = config.get("access", {}).get("read", False)
    if isinstance(read_value, list):
        for f in read_value:
            if not (base_path / f).exists():
                warnings.append("read file not found: " + f)

    write_list = config.get("access", {}).get("write", [])
    for item in write_list:
        if isinstance(item, dict):
            f = list(item.keys())[0]
        else:
            f = item
        filepath = base_path / f
        if not filepath.parent.exists():
            warnings.append("directory does not exist for write file: " + str(f))

    for f in config.get("reference", []):
        if not (base_path / f).exists():
            warnings.append("reference file not found: " + f)

    model = config.get("model", DEFAULT_MODEL)
    try:
        available = ollama.list()
        model_names = [m["name"] for m in available.get("models", [])]
        short_names = [n.split(":")[0] for n in model_names]
        if model not in model_names and model.split(":")[0] not in short_names:
            warnings.append("model not found in Ollama: " + model + " (run: ollama pull " + model + ")")
    except Exception:
        warnings.append("Ollama is not running — could not check model")

    if errors:
        for e in errors:
            print("  [ERROR] " + e)
    if warnings:
        for w in warnings:
            print("  [WARN]  " + w)

    if not errors and not warnings:
        print("  [OK] " + yaml_path + " is valid")
    elif not errors:
        print("\n  [OK] No errors. " + str(len(warnings)) + " warning(s).")

    print()


def run(yaml_path):
    base_path = get_project_path()
    if not base_path:
        sys.exit(1)

    print("\niris — running " + yaml_path + "\n")

    yaml_full_path = base_path / yaml_path
    config = parse_config(yaml_full_path)

    task = config["task"]
    instructions = config["instructions"]
    error = config["error"]
    reference_list = config["reference"]
    read_all = config["read_all"]
    read_files = config["read_files"]
    write_list = config["write_list"]
    forbidden = config["forbidden"]
    feedback = config["feedback"]
    tips = config["tips"]
    backup = config["backup"]
    model = config["model"]
    temperature = config["temperature"]

    print("[1/4] Collecting context...")
    if read_all:
        read_context = collect_project_files(base_path, forbidden)
    elif read_files:
        read_context = collect_read_files(base_path, read_files)
    else:
        read_context = {}

    write_files = collect_write_files(base_path, write_list)
    reference = collect_reference_files(base_path, reference_list)

    backup_data = {}
    if backup:
        backup_data = collect_backup(base_path, write_list)

    print("[2/4] Sending request to Ollama...")
    changes, response_text = execute(task, instructions, error, reference, read_context, write_files, tips, model, temperature=config.get("temperature"), feedback=feedback, forbidden=forbidden)

    print("[3/4] Applying changes...\n")
    if not changes:
        print("  [WARN] No file changes found in response")
    changed_files = apply_changes(base_path, changes, forbidden, write_list)

    print("\n[4/4] Finalizing...")
    save_last_run(changed_files, backup_data, base_path)
    save_history_entry(yaml_path, changed_files, model if model else DEFAULT_MODEL)

    if feedback:
        save_feedback(task, changed_files, response_text, base_path, backup_data)

    print("\niris — done (" + str(len(changed_files)) + " file(s) changed)\n")

def main():
    import sys as _sys
    if len(_sys.argv) < 2:
        print("Usage:")
        print("  iris init")
        print("  iris run <file.yaml>")
        print("  iris undo")
        print("  iris status")
        print("  iris history")
        print("  iris validate <file.yaml>")
        print("  iris start")
        _sys.exit(1)

    command = _sys.argv[1]

    if command == "init":
        init()
    elif command == "run":
        if len(_sys.argv) < 3:
            print("[ERROR] Specify a yaml file: iris run <file.yaml>")
            _sys.exit(1)
        yaml_files = _sys.argv[2:]
        for yaml_file in yaml_files:
            run(yaml_file)
    elif command == "undo":
        undo()
    elif command == "status":
        status()
    elif command == "history":
        history()
    elif command == "validate":
        if len(_sys.argv) < 3:
            print("[ERROR] Specify a yaml file: iris validate <file.yaml>")
            _sys.exit(1)
        validate(_sys.argv[2])
    elif command == "start":
        from tui import start
        start()
    else:
        print("[ERROR] Unknown command: " + command)
        _sys.exit(1)

if __name__ == "__main__":
    main()