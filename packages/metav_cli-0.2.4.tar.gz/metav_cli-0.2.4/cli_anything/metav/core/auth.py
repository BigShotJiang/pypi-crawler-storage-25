"""Authentication commands for MetaV CLI."""

import click
from typing import Optional

from ..utils.metav_backend import get_backend, MetaVError
from .session import get_session


@click.group(name="auth")
def auth_group():
    """Authentication management."""
    pass


@auth_group.command(name="login")
@click.option("--username", "-u", required=True, help="Username")
@click.option("--password", "-p", required=True, help="Password")
@click.option("--base-url", help="MetaV server base URL")
@click.option("--save/--no-save", default=True, help="Save session for future use")
def login(username: str, password: str, base_url: Optional[str], save: bool):
    """Login to MetaV server."""
    session = get_session()
    if base_url:
        session.base_url = base_url
        session.save()

    backend = get_backend(base_url=session.base_url, authkey=session.authkey)

    try:
        result = backend.login(username, password)
        # Handle both dict and object responses
        if isinstance(result, dict):
            token_obj = result.get("token", {})
            if isinstance(token_obj, dict):
                token_value = token_obj.get("tokenValue", "")
            else:
                token_value = str(token_obj) if token_obj else ""
            user_info = result.get("userInfo", {})
        else:
            # It's a LoginResponse object
            token_obj = getattr(result, "token", None)
            if token_obj:
                token_value = getattr(token_obj, "tokenValue", "")
            else:
                token_value = ""
            user_info = getattr(result, "userInfo", None)
            if user_info and not isinstance(user_info, dict):
                user_info = {}

        if save:
            session.token = token_value
            session.user_info = user_info if isinstance(user_info, dict) else {}
            if base_url:
                session.base_url = base_url
            session.save()

        click.echo(f"[OK] Logged in as {username}")
        if token_value:
            click.echo(f"  Token: {token_value[:20]}...")
    except MetaVError as e:
        click.echo(f"[ERROR] Login failed: {e}", err=True)
        raise SystemExit(1)


@auth_group.command(name="logout")
def logout():
    """Logout from MetaV server."""
    session = get_session()
    backend = get_backend()
    try:
        backend.logout()
    except MetaVError:
        pass
    session.clear()
    click.echo("[OK] Logged out")


@auth_group.command(name="status")
def auth_status():
    """Show authentication status."""
    session = get_session()
    if not session.is_authenticated:
        click.echo("Not authenticated. Use 'metav auth login' to login.")
        return

    click.echo("[OK] Authenticated")
    if session.token:
        click.echo(f"  Token: {session.token[:20]}...")
    if session.user_info:
        click.echo(f"  User: {session.user_info.get('username', 'unknown')}")
    if session.base_url:
        click.echo(f"  Server: {session.base_url}")


@auth_group.command(name="set-authkey")
@click.argument("authkey")
def set_authkey(authkey: str):
    """Set authentication key."""
    session = get_session()
    session.authkey = authkey
    session.save()
    click.echo(f"[OK] Authkey set")
