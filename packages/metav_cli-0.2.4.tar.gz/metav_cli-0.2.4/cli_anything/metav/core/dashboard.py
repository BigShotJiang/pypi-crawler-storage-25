"""Dashboard operations for MetaV CLI."""

import click
import json
import os
from typing import Optional

from ..utils.metav_backend import get_backend, MetaVError
from .session import get_session


@click.group(name="dashboard")
def dashboard_group():
    """Dashboard operations."""
    pass


@dashboard_group.command(name="create")
@click.option("--app-name", "-a", required=True, help="Application name")
@click.option("--page-name", "-p", default="首页", help="Page name")
@click.option("--schema", "-s", required=True, help="Page schema JSON file or @file:path")
@click.option("--remark", "-r", default="", help="Remark")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def create_dashboard(app_name: str, page_name: str, schema: str, remark: str, output_json: bool):
    """Create a dashboard application with full page schema.

    This is the main command for creating dashboards. It accepts a pageSchema JSON file
    and creates both the application and page in one operation.
    """
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)

    try:
        if schema.startswith("@"):
            schema_file = schema[1:]
        else:
            schema_file = schema

        if not os.path.exists(schema_file):
            try:
                page_schema = json.loads(schema)
            except json.JSONDecodeError:
                click.echo(f"[ERROR] Schema file not found and not valid JSON: {schema}", err=True)
                raise SystemExit(1)
        else:
            with open(schema_file, "r", encoding="utf-8") as f:
                page_schema = json.load(f)

        result = backend.create_dashboard(app_name, page_name, page_schema, remark)

        if output_json:
            click.echo(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            app_id = result.get("appId")
            page_id = result.get("pageId")
            share_link = result.get("shareLink")
            home_page_url = result.get("homePageUrl")

            click.echo(f"[OK] Dashboard created: {app_name}")
            click.echo(f"  App ID: {app_id}")
            click.echo(f"  Page ID: {page_id}")
            if share_link:
                click.echo(f"  Share Link: {share_link}")
            if home_page_url:
                click.echo(f"  Home Page: {home_page_url}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="components")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def list_components(output_json: bool):
    """List available dashboard components."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        components = backend.list_components()

        if output_json:
            click.echo(json.dumps(components, ensure_ascii=False, indent=2))
        else:
            if not components:
                click.echo("No components found.")
                return

            def extract_components(node_list, result=None):
                if result is None:
                    result = []
                if not isinstance(node_list, list):
                    return result
                for node in node_list:
                    comp_name = node.get("componentName")
                    version = node.get("version", "1.0.0")
                    if comp_name:
                        result.append({"name": comp_name, "version": version})
                    children = node.get("children") or node.get("typeChildren", [])
                    extract_components(children, result)
                return result

            comp_list = extract_components(components)
            click.echo(f"{'Component Name':<40} {'Version':<15}")
            click.echo("-" * 57)
            for comp in comp_list:
                click.echo(f"{comp['name']:<40} {comp['version']:<15}")

    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@dashboard_group.command(name="info")
@click.argument("app_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def dashboard_info(app_id: str, output_json: bool):
    """Get dashboard application details."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        app = backend.get_app(app_id)
        if output_json:
            click.echo(json.dumps(app, ensure_ascii=False, indent=2))
        else:
            click.echo(f"Dashboard: {app.get('name', 'unknown')}")
            click.echo(f"ID: {app.get('id', '')}")
            click.echo(f"Status: {app.get('status', 'unknown')}")

            pages = backend.list_pages(app_id)
            if pages:
                click.echo(f"\nPages ({len(pages)}):")
                for page in pages:
                    click.echo(f"  - {page.get('name', 'unknown')} (ID: {page.get('id', '')})")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)
