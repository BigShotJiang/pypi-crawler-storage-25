# MetaV CLI (metav-cli)

Command-line interface for MetaV Visual Dashboard Platform.

## Installation

### Prerequisites

- Python 3.8+
- MetaV server running

### Install CLI

```bash
cd agent-harness
pip install -e .
```

### Configuration

Set environment variables or use command-line options:

```bash
export METAV_BASE_URL=http://localhost:10517/metav
export METAV_AUTHKEY=your_auth_key_here
```

Or use command-line options:

```bash
metav-cli --base-url http://localhost:10517/metav --authkey your_key app list
```

## Usage

### Authentication

```bash
# Login with username/password
metav-cli auth login -u username -p password

# Set authkey
metav-cli auth set-authkey your_auth_key

# Check status
metav-cli auth status

# Logout
metav-cli auth logout
```

### Application Management

```bash
# List applications
metav-cli app list
metav-cli app list --page 1 --page-size 50 --keyword search

# Get application details
metav-cli app get <app_id>

# Create application
metav-cli app create --name "My Dashboard" --remark "Created via CLI"

# Update application
metav-cli app update <app_id> --name "New Name" --remark "Updated"

# Delete application
metav-cli app delete <app_id> --force

# Export/Import
metav-cli app export <app_id> --output myapp.zip
metav-cli app import myapp.zip

# Copy application
metav-cli app copy <app_id> --name "Copy of My Dashboard"

# Release/Publish
metav-cli app release <app_id>
```

### Page Management

```bash
# List pages
metav-cli page list --app-id <app_id>

# Get page details
metav-cli page get <page_id>

# Create page
metav-cli page create --app-id <app_id> --name "New Page"

# Delete page
metav-cli page delete <page_id> --force
```

### DataSource Management

```bash
# List data sources
metav-cli datasource list
metav-cli datasource list --page-size 100

# List all data sources
metav-cli datasource list-all

# Get data source
metav-cli datasource get <datasource_id>

# Create data source
metav-cli datasource create --name "My API" --type restful --config '{"url": "/api/data"}'

# Delete data source
metav-cli datasource delete <datasource_id> --force
```

### Dashboard Operations

```bash
# Create dashboard from pageSchema
metav-cli dashboard create --app-name "My Dashboard" --schema schema.json --remark "AI created"

# List components
metav-cli dashboard components

# Get dashboard info
metav-cli dashboard info <app_id>
```

### Information Commands

```bash
# Current user info
metav-cli info user

# Show configuration
metav-cli info config

# Show session info
metav-cli info session

# Show environment variables
metav-cli info env
```

### JSON Output

Use `--json` flag for machine-readable output:

```bash
metav-cli app list --json
metav-cli app get <app_id> --json
```

### Interactive REPL

```bash
metav-cli repl
```

## REPL Commands

```
metav> app list              # List applications
metav> dashboard components  # List components
metav> auth status           # Show auth status
metav> info config           # Show configuration
metav> exit                  # Exit REPL
```

## Session Management

The CLI stores session data in `~/.metav_session.json`:

- Authentication token
- User info
- Default base URL
- Default app/page IDs

## Exit Codes

- `0`: Success
- `1`: API error
- `2`: Configuration error
