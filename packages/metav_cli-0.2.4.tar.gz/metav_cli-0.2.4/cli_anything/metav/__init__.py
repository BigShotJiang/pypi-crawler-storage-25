"""cli-anything namespace package for metav."""
