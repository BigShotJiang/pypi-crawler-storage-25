# Plumbline

**Write-time verification for AI-generated code.**

This is a name-reservation release (0.0.1). The full 0.1.0 is in active development.

- Homepage: https://plumblinehq.com
- Source: https://github.com/evolvingintelligenceai/plumbline

Built by [Evolving Intelligence AI](https://evolvingintelligence.ai).
