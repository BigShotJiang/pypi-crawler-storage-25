"""Plumbline — write-time verification for AI-generated code.

This is a name-reservation release. The full 0.1.0 is in progress at
https://github.com/evolvingintelligenceai/plumbline
"""

__version__ = "0.0.1"
