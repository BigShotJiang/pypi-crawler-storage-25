use chrono::{DateTime, Local};
use pyo3::prelude::*;
use rayon::prelude::*;
/// 文件操作模块
///
/// 提供高性能的批量文件扫描、路径解析、文件日期/权限操作
use std::fs;
use std::path::Path;
use walkdir::WalkDir;

/// 文件信息
#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct FileInfo {
    #[pyo3(get)]
    pub path: String,
    #[pyo3(get)]
    pub name: String,
    #[pyo3(get)]
    pub size: u64,
    #[pyo3(get)]
    pub is_file: bool,
    #[pyo3(get)]
    pub is_dir: bool,
    #[pyo3(get)]
    pub modified: Option<String>,
}

#[pymethods]
impl FileInfo {
    fn __repr__(&self) -> String {
        format!("FileInfo(path='{}', size={})", self.path, self.size)
    }
}

/// 文件操作器
#[pyclass]
pub struct FileOps;


#[pymethods]
impl FileOps {
    #[new]
    fn new() -> Self {
        Self
    }

    /// 扫描目录，返回所有文件信息
    pub fn scan_directory(
        &self,
        dir_path: &str,
        recursive: Option<bool>,
    ) -> PyResult<Vec<FileInfo>> {
        let path = Path::new(dir_path);
        if !path.exists() {
            return Err(pyo3::exceptions::PyFileNotFoundError::new_err(format!(
                "目录不存在: {}",
                dir_path
            )));
        }

        let recursive = recursive.unwrap_or(true);
        let mut files = Vec::new();

        let walker = if recursive {
            WalkDir::new(path).into_iter()
        } else {
            WalkDir::new(path).max_depth(1).into_iter()
        };

        for entry in walker.filter_entry(|e| e.file_name().to_string_lossy().starts_with('.')) {
            let entry = entry.map_err(|e| {
                pyo3::exceptions::PyIOError::new_err(format!("读取目录失败: {}", e))
            })?;

            let metadata = entry.metadata().map_err(|e| {
                pyo3::exceptions::PyIOError::new_err(format!("读取元数据失败: {}", e))
            })?;

            let modified = metadata.modified().ok().map(|time| {
                let datetime: DateTime<Local> = time.into();
                datetime.format("%Y-%m-%d %H:%M:%S").to_string()
            });

            files.push(FileInfo {
                path: entry.path().to_string_lossy().to_string(),
                name: entry.file_name().to_string_lossy().to_string(),
                size: metadata.len(),
                is_file: metadata.is_file(),
                is_dir: metadata.is_dir(),
                modified,
            });
        }

        Ok(files)
    }

    /// 批量扫描多个目录（使用并行处理）
    pub fn scan_directories_parallel(&self, dir_paths: Vec<String>) -> PyResult<Vec<FileInfo>> {
        let results: PyResult<Vec<Vec<FileInfo>>> = dir_paths
            .par_iter()
            .map(|dir_path| self.scan_directory(dir_path, Some(true)))
            .collect();

        let all_files = results?.into_iter().flatten().collect();
        Ok(all_files)
    }

    /// 规范化路径
    pub fn normalize_path(&self, path: &str) -> PyResult<String> {
        let path = Path::new(path);
        let normalized = path
            .canonicalize()
            .map_err(|e| pyo3::exceptions::PyIOError::new_err(format!("路径规范化失败: {}", e)))?;
        Ok(normalized.to_string_lossy().to_string())
    }

    /// 获取文件修改时间
    pub fn get_file_modified(&self, file_path: &str) -> PyResult<String> {
        let path = Path::new(file_path);
        let metadata = fs::metadata(path).map_err(|e| {
            pyo3::exceptions::PyIOError::new_err(format!("读取文件元数据失败: {}", e))
        })?;

        let modified = metadata.modified().map_err(|e| {
            pyo3::exceptions::PyIOError::new_err(format!("获取修改时间失败: {}", e))
        })?;

        let datetime: DateTime<Local> = modified.into();
        Ok(datetime.format("%Y-%m-%d %H:%M:%S").to_string())
    }

    /// 批量获取文件信息（使用并行处理）
    pub fn get_files_info_parallel(&self, file_paths: Vec<String>) -> PyResult<Vec<FileInfo>> {
        let results: PyResult<Vec<FileInfo>> = file_paths
            .par_iter()
            .map(|path_str| {
                let path = Path::new(path_str);
                let metadata = fs::metadata(path).map_err(|e| {
                    pyo3::exceptions::PyIOError::new_err(format!("读取文件元数据失败: {}", e))
                })?;

                let modified = metadata.modified().ok().map(|time| {
                    let datetime: DateTime<Local> = time.into();
                    datetime.format("%Y-%m-%d %H:%M:%S").to_string()
                });

                Ok(FileInfo {
                    path: path_str.clone(),
                    name: path
                        .file_name()
                        .map(|n| n.to_string_lossy().to_string())
                        .unwrap_or_default(),
                    size: metadata.len(),
                    is_file: metadata.is_file(),
                    is_dir: metadata.is_dir(),
                    modified,
                })
            })
            .collect();

        results
    }
}
