use pyo3::prelude::*;
/// 命令执行模块
///
/// 提供进程管理、流式输出捕获、超时控制
use std::process::{Command, Stdio};
use std::sync::mpsc;
use std::thread;
use std::time::Instant;

/// 命令执行结果
#[derive(Debug, Clone)]
#[pyclass(skip_from_py_object)]
pub struct CommandResult {
    #[pyo3(get)]
    pub returncode: i32,
    #[pyo3(get)]
    pub stdout: String,
    #[pyo3(get)]
    pub stderr: String,
    #[pyo3(get)]
    pub execution_time: f64,
    #[pyo3(get)]
    pub success: bool,
}

#[pymethods]
impl CommandResult {
    fn __repr__(&self) -> String {
        format!(
            "CommandResult(returncode={}, success={}, time={:.2}s)",
            self.returncode, self.success, self.execution_time
        )
    }
}

/// 命令执行器
#[pyclass]
pub struct CommandExecutor;

#[pymethods]
impl CommandExecutor {
    #[new]
    fn new() -> Self {
        Self
    }

    /// 执行命令
    pub fn execute(
        &self,
        cmd: Vec<String>,
        cwd: Option<String>,
        timeout: Option<u64>,
    ) -> PyResult<CommandResult> {
        self.execute_with_input(cmd, cwd, timeout, None)
    }

    /// 执行命令并支持标准输入
    pub fn execute_with_input(
        &self,
        cmd: Vec<String>,
        cwd: Option<String>,
        timeout: Option<u64>,
        input: Option<String>,
    ) -> PyResult<CommandResult> {
        if cmd.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err("命令列表不能为空"));
        }

        let start_time = Instant::now();
        let timeout_secs = timeout.unwrap_or(30);

        let mut command = Command::new(&cmd[0]);
        command.args(&cmd[1..]);
        command.stdout(Stdio::piped());
        command.stderr(Stdio::piped());

        // 如果有 input 参数，设置 stdin 为管道
        if input.is_some() {
            command.stdin(Stdio::piped());
        }

        if let Some(work_dir) = cwd {
            command.current_dir(work_dir);
        }

        let mut child = command
            .spawn()
            .map_err(|e| pyo3::exceptions::PyOSError::new_err(format!("启动进程失败: {}", e)))?;

        // 如果有 input，写入标准输入
        if let Some(input_data) = input {
            if let Some(mut stdin) = child.stdin.take() {
                use std::io::Write;
                if let Err(e) = stdin.write_all(input_data.as_bytes()) {
                    return Err(pyo3::exceptions::PyIOError::new_err(format!(
                        "写入标准输入失败: {}",
                        e
                    )));
                }
            }
        }

        // 创建通道用于接收输出
        let (tx, rx) = mpsc::channel();

        // 读取 stdout
        let stdout = child.stdout.take();
        let tx_stdout = tx.clone();
        let stdout_thread = thread::spawn(move || {
            if let Some(mut stdout) = stdout {
                use std::io::Read;
                let mut buffer = Vec::new();
                if stdout.read_to_end(&mut buffer).is_ok() {
                    let _ =
                        tx_stdout.send(("stdout", String::from_utf8_lossy(&buffer).to_string()));
                }
            }
        });

        // 读取 stderr
        let stderr = child.stderr.take();
        let tx_stderr = tx.clone();
        let stderr_thread = thread::spawn(move || {
            if let Some(mut stderr) = stderr {
                use std::io::Read;
                let mut buffer = Vec::new();
                if stderr.read_to_end(&mut buffer).is_ok() {
                    let _ =
                        tx_stderr.send(("stderr", String::from_utf8_lossy(&buffer).to_string()));
                }
            }
        });

        // 等待进程完成或超时
        let result = child.wait();

        // 等待输出读取完成
        let _ = stdout_thread.join();
        let _ = stderr_thread.join();

        // 收集输出
        let mut stdout_content = String::new();
        let mut stderr_content = String::new();

        for (stream_type, content) in rx.try_iter() {
            match stream_type {
                "stdout" => stdout_content = content,
                "stderr" => stderr_content = content,
                _ => {}
            }
        }

        let returncode = result.map_err(|e| {
            pyo3::exceptions::PyOSError::new_err(format!("等待进程完成失败: {}", e))
        })?;

        let execution_time = start_time.elapsed().as_secs_f64();

        // 检查超时
        if execution_time > timeout_secs as f64 {
            return Err(pyo3::exceptions::PyTimeoutError::new_err(format!(
                "命令执行超时: {:.2}s > {}s",
                execution_time, timeout_secs
            )));
        }

        Ok(CommandResult {
            returncode: returncode.code().unwrap_or(-1),
            stdout: stdout_content,
            stderr: stderr_content,
            execution_time,
            success: returncode.success(),
        })
    }

    /// 批量执行命令（简化版，实际应使用线程池）
    pub fn execute_batch(
        &self,
        commands: Vec<Vec<String>>,
        timeout: Option<u64>,
    ) -> PyResult<Vec<CommandResult>> {
        let mut results = Vec::new();

        for cmd in commands {
            match self.execute(cmd.clone(), None, timeout) {
                Ok(result) => results.push(result),
                Err(e) => {
                    // 记录错误但仍继续执行其他命令
                    results.push(CommandResult {
                        returncode: -1,
                        stdout: String::new(),
                        stderr: format!("{}", e),
                        execution_time: 0.0,
                        success: false,
                    });
                }
            }
        }

        Ok(results)
    }
}
