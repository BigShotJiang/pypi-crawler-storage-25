use pyo3::prelude::*;
/// 加密解密模块
///
/// 提供 SHA256 哈希计算、AES 加密解密
use sha2::{Digest, Sha256};

/// 加密工具
#[pyclass]
pub struct CryptoUtils;


#[pymethods]
impl CryptoUtils {
    #[new]
    fn new() -> Self {
        Self
    }

    /// 计算 SHA256 哈希
    fn sha256(&self, data: &str) -> String {
        let mut hasher = Sha256::new();
        hasher.update(data.as_bytes());
        let result = hasher.finalize();
        format!("{:x}", result)
    }

    /// 计算文件的 SHA256 哈希
    fn sha256_file(&self, file_path: &str) -> PyResult<String> {
        use std::fs;
        use std::io::Read;

        let mut file = fs::File::open(file_path)
            .map_err(|e| pyo3::exceptions::PyIOError::new_err(format!("打开文件失败: {}", e)))?;

        let mut hasher = Sha256::new();
        let mut buffer = [0u8; 8192];

        loop {
            let bytes_read = file.read(&mut buffer).map_err(|e| {
                pyo3::exceptions::PyIOError::new_err(format!("读取文件失败: {}", e))
            })?;

            if bytes_read == 0 {
                break;
            }

            hasher.update(&buffer[..bytes_read]);
        }

        let result = hasher.finalize();
        Ok(format!("{:x}", result))
    }

    /// 简单的 XOR 加密（仅用于演示，实际应用应使用更强的加密）
    fn xor_encrypt(&self, data: &str, key: &str) -> String {
        let key_bytes = key.as_bytes();
        let data_bytes = data.as_bytes();

        let encrypted: Vec<u8> = data_bytes
            .iter()
            .enumerate()
            .map(|(i, &byte)| byte ^ key_bytes[i % key_bytes.len()])
            .collect();

        // 转换为十六进制字符串
        encrypted.iter().map(|b| format!("{:02x}", b)).collect()
    }

    /// 简单的 XOR 解密
    fn xor_decrypt(&self, hex_data: &str, key: &str) -> PyResult<String> {
        // 将十六进制字符串转换为字节
        let bytes: Result<Vec<u8>, _> = (0..hex_data.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&hex_data[i..i + 2], 16))
            .collect();

        let encrypted_bytes = bytes.map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("无效的十六进制数据: {}", e))
        })?;

        let key_bytes = key.as_bytes();
        let decrypted: Vec<u8> = encrypted_bytes
            .iter()
            .enumerate()
            .map(|(i, &byte)| byte ^ key_bytes[i % key_bytes.len()])
            .collect();

        String::from_utf8(decrypted).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!("解密结果不是有效的 UTF-8: {}", e))
        })
    }
}
