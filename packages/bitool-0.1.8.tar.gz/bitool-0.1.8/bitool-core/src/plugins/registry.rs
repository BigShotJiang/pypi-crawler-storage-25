/// 插件注册表
use std::collections::HashMap;

/// 插件信息
pub struct PluginInfo {
    pub name: String,
    pub version: String,
    pub description: String,
}

/// 插件注册表
pub struct PluginRegistry {
    plugins: HashMap<String, PluginInfo>,
}

impl PluginRegistry {
    pub fn new() -> Self {
        Self {
            plugins: HashMap::new(),
        }
    }

    /// 注册插件
    pub fn register_plugin(&mut self, plugin: PluginInfo) -> Result<(), String> {
        if self.plugins.contains_key(&plugin.name) {
            return Err(format!("插件 {} 已注册", plugin.name));
        }
        self.plugins.insert(plugin.name.clone(), plugin);
        Ok(())
    }

    /// 获取插件信息
    pub fn get_plugin(&self, name: &str) -> Option<&PluginInfo> {
        self.plugins.get(name)
    }

    /// 列出所有插件
    pub fn list_plugins(&self) -> Vec<&PluginInfo> {
        self.plugins.values().collect()
    }

    /// 检查插件是否存在
    pub fn has_plugin(&self, name: &str) -> bool {
        self.plugins.contains_key(name)
    }
}
