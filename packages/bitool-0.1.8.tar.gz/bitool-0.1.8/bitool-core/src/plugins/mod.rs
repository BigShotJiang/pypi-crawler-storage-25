pub mod loader;
/// 插件系统核心模块
pub mod registry;
