use crate::core::file_ops::{FileInfo, FileOps};
/// Python 文件操作接口绑定
use pyo3::prelude::*;

/// Python 可用的文件操作类
#[pyclass]
pub struct PyFileOps {
    inner: FileOps,
}

#[pymethods]
impl PyFileOps {
    #[new]
    fn new() -> Self {
        Self { inner: FileOps }
    }

    /// 扫描目录
    fn scan_directory(&self, dir_path: &str, recursive: Option<bool>) -> PyResult<Vec<_FileInfo>> {
        let files = self.inner.scan_directory(dir_path, recursive)?;
        Ok(files.into_iter().map(|f| _FileInfo { inner: f }).collect())
    }

    /// 并行扫描多个目录
    fn scan_directories_parallel(&self, dir_paths: Vec<String>) -> PyResult<Vec<_FileInfo>> {
        let files = self.inner.scan_directories_parallel(dir_paths)?;
        Ok(files.into_iter().map(|f| _FileInfo { inner: f }).collect())
    }

    /// 规范化路径
    fn normalize_path(&self, path: &str) -> PyResult<String> {
        self.inner.normalize_path(path)
    }

    /// 获取文件修改时间
    fn get_file_modified(&self, file_path: &str) -> PyResult<String> {
        self.inner.get_file_modified(file_path)
    }

    /// 批量获取文件信息
    fn get_files_info_parallel(&self, file_paths: Vec<String>) -> PyResult<Vec<_FileInfo>> {
        let files = self.inner.get_files_info_parallel(file_paths)?;
        Ok(files.into_iter().map(|f| _FileInfo { inner: f }).collect())
    }
}

/// Python 可用的文件信息类
#[pyclass]
pub struct _FileInfo {
    inner: FileInfo,
}

#[pymethods]
impl _FileInfo {
    #[getter]
    fn path(&self) -> String {
        self.inner.path.clone()
    }

    #[getter]
    fn name(&self) -> String {
        self.inner.name.clone()
    }

    #[getter]
    fn size(&self) -> u64 {
        self.inner.size
    }

    #[getter]
    fn is_file(&self) -> bool {
        self.inner.is_file
    }

    #[getter]
    fn is_dir(&self) -> bool {
        self.inner.is_dir
    }

    #[getter]
    fn modified(&self) -> Option<String> {
        self.inner.modified.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "FileInfo(path='{}', size={})",
            self.inner.path, self.inner.size
        )
    }
}
