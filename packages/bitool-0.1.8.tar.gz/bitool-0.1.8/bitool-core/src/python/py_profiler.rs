use crate::core::profiler::{PerformanceProfiler, ProfileRecord};
/// Python 性能分析接口绑定
///
/// 将 Rust 性能分析功能暴露给 Python
use pyo3::prelude::*;

/// Python 可用的性能记录类
#[pyclass]
pub struct PyProfileRecord {
    inner: ProfileRecord,
}

#[pymethods]
impl PyProfileRecord {
    #[getter]
    fn name(&self) -> String {
        self.inner.name.clone()
    }

    #[getter]
    fn duration_secs(&self) -> f64 {
        self.inner.duration_secs
    }

    #[getter]
    fn memory_before_mb(&self) -> f64 {
        self.inner.memory_before_mb
    }

    #[getter]
    fn memory_after_mb(&self) -> f64 {
        self.inner.memory_after_mb
    }

    #[getter]
    fn memory_delta_mb(&self) -> f64 {
        self.inner.memory_delta_mb
    }

    #[getter]
    fn timestamp(&self) -> String {
        self.inner.timestamp.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "PyProfileRecord(name='{}', time={:.4}s, memory_delta={:.2}MB)",
            self.inner.name, self.inner.duration_secs, self.inner.memory_delta_mb
        )
    }
}

/// Python 可用的性能分析器
#[pyclass]
pub struct PyPerformanceProfiler {
    inner: PerformanceProfiler,
}

#[pymethods]
impl PyPerformanceProfiler {
    #[new]
    fn new() -> Self {
        Self {
            inner: PerformanceProfiler::new(),
        }
    }

    /// 开始追踪某个函数调用
    fn start_timer(&self, name: &str) {
        self.inner.start_timer(name);
    }

    /// 停止追踪并记录性能数据
    fn stop_timer(&self, name: &str) -> PyResult<Option<PyProfileRecord>> {
        match self.inner.stop_timer(name)? {
            Some(record) => Ok(Some(PyProfileRecord { inner: record })),
            None => Ok(None),
        }
    }

    /// 获取所有性能记录
    fn get_records(&self) -> Vec<PyProfileRecord> {
        self.inner
            .get_records()
            .into_iter()
            .map(|r| PyProfileRecord { inner: r })
            .collect()
    }

    /// 获取特定函数的调用次数
    fn get_call_count(&self, name: &str) -> u64 {
        self.inner.get_call_count(name)
    }

    /// 获取特定函数的总耗时（秒）
    fn get_total_duration(&self, name: &str) -> f64 {
        self.inner.get_total_duration(name)
    }

    /// 获取特定函数的平均调用时间（秒）
    fn get_average_duration(&self, name: &str) -> f64 {
        self.inner.get_average_duration(name)
    }

    /// 清除所有记录
    fn clear(&self) {
        self.inner.clear();
    }

    /// 获取性能摘要
    fn get_summary(&self) -> PyResult<String> {
        self.inner.get_summary()
    }
}
