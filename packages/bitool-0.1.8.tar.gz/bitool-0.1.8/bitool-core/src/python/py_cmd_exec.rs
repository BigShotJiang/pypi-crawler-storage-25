use crate::core::cmd_exec::{CommandExecutor, CommandResult};
/// Python 命令执行接口绑定
use pyo3::prelude::*;

/// Python 可用的命令执行器
#[pyclass]
pub struct PyCommandExecutor {
    inner: CommandExecutor,
}

#[pymethods]
impl PyCommandExecutor {
    #[new]
    fn new() -> Self {
        Self {
            inner: CommandExecutor,
        }
    }

    /// 执行命令
    fn execute(
        &self,
        cmd: Vec<String>,
        cwd: Option<String>,
        timeout: Option<u64>,
    ) -> PyResult<PyCommandResult> {
        let result = self.inner.execute(cmd, cwd, timeout)?;
        Ok(PyCommandResult { inner: result })
    }

    /// 执行命令并支持标准输入
    fn execute_with_input(
        &self,
        cmd: Vec<String>,
        cwd: Option<String>,
        timeout: Option<u64>,
        input: Option<String>,
    ) -> PyResult<PyCommandResult> {
        let result = self.inner.execute_with_input(cmd, cwd, timeout, input)?;
        Ok(PyCommandResult { inner: result })
    }

    /// 批量执行命令
    fn execute_batch(
        &self,
        commands: Vec<Vec<String>>,
        timeout: Option<u64>,
    ) -> PyResult<Vec<PyCommandResult>> {
        let results = self.inner.execute_batch(commands, timeout)?;
        Ok(results
            .into_iter()
            .map(|r| PyCommandResult { inner: r })
            .collect())
    }
}

/// Python 可用的命令执行结果
#[pyclass]
pub struct PyCommandResult {
    inner: CommandResult,
}

#[pymethods]
impl PyCommandResult {
    #[getter]
    fn returncode(&self) -> i32 {
        self.inner.returncode
    }

    #[getter]
    fn stdout(&self) -> String {
        self.inner.stdout.clone()
    }

    #[getter]
    fn stderr(&self) -> String {
        self.inner.stderr.clone()
    }

    #[getter]
    fn execution_time(&self) -> f64 {
        self.inner.execution_time
    }

    #[getter]
    fn success(&self) -> bool {
        self.inner.success
    }

    fn __repr__(&self) -> String {
        format!(
            "CommandResult(returncode={}, success={}, time={:.2}s)",
            self.inner.returncode, self.inner.success, self.inner.execution_time
        )
    }
}
