//! Python PDF操作接口绑定
use crate::core::pdf_ops::PdfOps;
use pyo3::prelude::*;

/// Python可用的PDF操作类
#[pyclass]
pub struct PyPdfOps {
    #[allow(dead_code)]
    inner: PdfOps,
}

#[pymethods]
impl PyPdfOps {
    #[new]
    fn new() -> Self {
        Self {
            inner: PdfOps::new(),
        }
    }

    /// 按页数拆分PDF
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `pages_per_file`: 每个文件的页数
    /// 
    /// # 返回
    /// 生成的文件路径列表
    #[pyo3(text_signature = "($self, input_path, output_dir, pages_per_file)")]
    fn split_pdf(
        &self,
        input_path: &str,
        output_dir: &str,
        pages_per_file: usize,
    ) -> PyResult<Vec<String>> {
        crate::core::pdf_ops::PdfOps::split_pdf(input_path, output_dir, pages_per_file)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 按页码范围拆分PDF
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `ranges`: 页码范围列表，格式如 "1-5,10-15,20"
    /// 
    /// # 返回
    /// 生成的文件路径列表
    #[pyo3(text_signature = "($self, input_path, output_dir, ranges)")]
    fn split_pdf_by_ranges(
        &self,
        input_path: &str,
        output_dir: &str,
        ranges: &str,
    ) -> PyResult<Vec<String>> {
        crate::core::pdf_ops::PdfOps::split_pdf_by_ranges(input_path, output_dir, ranges)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 合并多个PDF文件
    /// 
    /// # 参数
    /// - `input_paths`: 输入PDF文件路径列表
    /// - `output_path`: 输出PDF文件路径
    #[pyo3(text_signature = "($self, input_paths, output_path)")]
    fn merge_pdfs(&self, input_paths: Vec<String>, output_path: &str) -> PyResult<()> {
        PdfOps::merge_pdfs(&input_paths, output_path)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 压缩PDF文件
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_path`: 输出PDF文件路径
    /// - `quality`: 压缩质量 (1-100，值越高质量越好)
    #[pyo3(text_signature = "($self, input_path, output_path, quality)")]
    fn compress_pdf(
        &self,
        input_path: &str,
        output_path: &str,
        quality: u8,
    ) -> PyResult<()> {
        crate::core::pdf_ops::PdfOps::compress_pdf(input_path, output_path, quality)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 将PDF转换为图片
    /// 
    /// # 参数
    /// - `input_path`: 输入PDF文件路径
    /// - `output_dir`: 输出目录
    /// - `format`: 图片格式 ("png" 或 "jpg")
    /// - `dpi`: 分辨率 (dots per inch)
    /// 
    /// # 返回
    /// 生成的图片文件路径列表
    #[pyo3(text_signature = "($self, input_path, output_dir, format, dpi)")]
    fn pdf_to_images(
        &self,
        input_path: &str,
        output_dir: &str,
        fmt: &str,
        dpi: u32,
    ) -> PyResult<Vec<String>> {
        crate::core::pdf_ops::PdfOps::pdf_to_images(input_path, output_dir, fmt, dpi)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 将图片列表转换为PDF
    /// 
    /// # 参数
    /// - `image_paths`: 输入图片文件路径列表
    /// - `output_path`: 输出PDF文件路径
    /// - `page_size`: 页面尺寸 ("A4", "letter" 或 "auto")
    #[pyo3(text_signature = "($self, image_paths, output_path, page_size)")]
    fn images_to_pdf(
        &self,
        image_paths: Vec<String>,
        output_path: &str,
        page_size: &str,
    ) -> PyResult<()> {
        crate::core::pdf_ops::PdfOps::images_to_pdf(&image_paths, output_path, page_size)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))
    }

    /// 返回类的字符串表示
    fn __repr__(&self) -> String {
        "PyPdfOps(Rust PDF操作工具)".to_string()
    }
}
