use crate::core::config::{BitoolConfig, WorkspaceConfig};
/// Python 配置接口绑定
///
/// 将 Rust 配置功能暴露给 Python
use pyo3::prelude::*;

/// Python 可用的配置类
#[pyclass]
pub struct PyBitoolConfig {
    inner: BitoolConfig,
}

#[pymethods]
impl PyBitoolConfig {
    #[new]
    fn new(
        mode: Option<String>,
        log_level: Option<String>,
        plugin_dirs: Option<Vec<String>>,
    ) -> Self {
        Self {
            inner: BitoolConfig::new(mode, log_level, None, plugin_dirs),
        }
    }

    #[getter]
    fn mode(&self) -> String {
        self.inner.mode.clone()
    }

    #[setter]
    fn set_mode(&mut self, value: String) {
        self.inner.mode = value;
    }

    #[getter]
    fn log_level(&self) -> String {
        self.inner.log_level.clone()
    }

    #[setter]
    fn set_log_level(&mut self, value: String) {
        self.inner.log_level = value;
    }

    #[getter]
    fn plugin_dirs(&self) -> Vec<String> {
        self.inner.plugin_dirs.clone()
    }

    #[setter]
    fn set_plugin_dirs(&mut self, value: Vec<String>) {
        self.inner.plugin_dirs = value;
    }

    /// 从文件加载配置
    #[staticmethod]
    fn load_from_file(config_file: &str) -> PyResult<Self> {
        let config = BitoolConfig::load_from_file(config_file)?;
        Ok(Self { inner: config })
    }

    /// 保存配置到文件
    fn save_to_file(&self, config_file: &str) -> PyResult<()> {
        self.inner.save_to_file(config_file)
    }

    /// 展开环境变量
    fn expand_env_vars(&self, value: &str) -> String {
        self.inner.expand_env_vars(value)
    }
}

/// Python 可用的工作空间配置类
#[pyclass]
pub struct PyWorkspaceConfig {
    inner: WorkspaceConfig,
}

#[pymethods]
impl PyWorkspaceConfig {
    #[new]
    fn new(root: Option<String>, env_file: Option<String>) -> Self {
        Self {
            inner: WorkspaceConfig::new(root, env_file),
        }
    }

    #[getter]
    fn root(&self) -> String {
        self.inner.root.clone()
    }

    #[setter]
    fn set_root(&mut self, value: String) {
        self.inner.root = value;
    }

    #[getter]
    fn env_file(&self) -> String {
        self.inner.env_file.clone()
    }

    #[setter]
    fn set_env_file(&mut self, value: String) {
        self.inner.env_file = value;
    }

    fn set_var(&mut self, name: String, value: String) {
        self.inner.set_var(name, value)
    }

    fn get_var(&self, name: &str, default: Option<String>) -> String {
        self.inner.get_var(name, default)
    }

    fn resolve_path(&self, relative_path: &str) -> PyResult<String> {
        self.inner.resolve_path(relative_path)
    }
}
