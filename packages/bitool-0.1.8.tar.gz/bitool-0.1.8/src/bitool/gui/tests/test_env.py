"""PySide2 环境设置模块的测试."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import bitool.gui._env as env_module


def _create_fake_pyside2_dir(tmp_path: Path, with_plugins: bool = True) -> Path:
    """创建模拟的 PySide2 目录结构.

    Args:
        tmp_path: pytest 临时路径.
        with_plugins: 是否创建 plugins 目录.

    Returns:
        PySide2 目录路径.
    """
    fake_pyside2_dir = tmp_path / "PySide2"
    fake_pyside2_dir.mkdir()
    if with_plugins:
        fake_plugins_dir = fake_pyside2_dir / "plugins"
        fake_plugins_dir.mkdir()
    return fake_pyside2_dir


def _create_mock_pyside2_module(pyside2_dir: Path) -> MagicMock:
    """创建模拟的 PySide2 模块.

    Args:
        pyside2_dir: PySide2 目录路径.

    Returns:
        模拟的 PySide2 模块.
    """
    mock_pyside2 = MagicMock()
    mock_pyside2.__file__ = str(pyside2_dir / "__init__.py")
    return mock_pyside2


class TestPySide2EnvClass:
    """测试 _PySide2Env 类."""

    def test_class_attributes_exist(self) -> None:
        """测试类属性是否存在."""
        assert hasattr(env_module._PySide2Env, "_initialized")
        assert hasattr(env_module._PySide2Env, "_chinese_fonts")
        assert isinstance(env_module._PySide2Env._chinese_fonts, list)
        assert len(env_module._PySide2Env._chinese_fonts) > 0

    def test_setup_env_method_exists(self) -> None:
        """测试 setup_env 方法是否存在."""
        assert hasattr(env_module._PySide2Env, "setup_env")
        assert callable(env_module._PySide2Env.setup_env)


class TestSetupPySide2Env:
    """测试 setup_pyside2_env 函数(从 _PySide2Env.setup_env 别名)."""

    def test_setup_pyside2_env_is_callable(self) -> None:
        """测试 setup_pyside2_env 是否可调用."""
        assert callable(env_module.setup_pyside2_env)

    def test_setup_pyside2_env_without_pyside2(self) -> None:
        """测试未安装 PySide2 时的设置."""
        with patch.dict("sys.modules", {"PySide2": None}), patch(
            "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
        ):
            # 不应抛出异常
            env_module.setup_pyside2_env()

    def test_setup_pyside2_env_with_pyside2(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """测试已安装 PySide2 时的设置."""
        # 创建模拟的 PySide2 目录结构
        fake_pyside2_dir = _create_fake_pyside2_dir(tmp_path, with_plugins=True)

        # 模拟 PySide2 模块
        mock_pyside2 = _create_mock_pyside2_module(fake_pyside2_dir)

        with patch.dict("sys.modules", {"PySide2": mock_pyside2}), patch.dict(
            os.environ, {}, clear=False
        ):
            env_module.setup_pyside2_env()

            # 检查环境变量是否已设置
            assert "QT_QPA_PLATFORM_PLUGIN_PATH" in os.environ
            assert "QT_PLUGIN_PATH" in os.environ
            # 验证路径指向插件目录
            assert "plugins" in os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"]

    def test_setup_pyside2_env_plugins_not_found(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """测试插件目录不存在时的设置."""
        # 创建没有插件的模拟 PySide2 目录
        fake_pyside2_dir = _create_fake_pyside2_dir(tmp_path, with_plugins=False)

        mock_pyside2 = _create_mock_pyside2_module(fake_pyside2_dir)

        with patch.dict("sys.modules", {"PySide2": mock_pyside2}):
            env_module.setup_pyside2_env()

    def test_setup_pyside2_env_idempotent(self) -> None:
        """测试 setup_pyside2_env 可以被多次安全调用."""
        # 第一次调用 - 应该初始化
        env_module.setup_pyside2_env()
        assert env_module._PySide2Env._initialized is True

        # 第二次调用 - 应该跳过初始化
        env_module.setup_pyside2_env()
        # 仍然已初始化
        assert env_module._PySide2Env._initialized is True


class TestChineseFontsConfiguration:
    """测试中文字体配置."""

    def test_chinese_fonts_list_not_empty(self) -> None:
        """测试中文字体列表不为空."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert len(fonts) > 0

    @pytest.mark.parametrize(
        "font_name",
        ["Microsoft YaHei", "Microsoft YaHei UI", "Segoe UI", "PingFang SC"],
    )
    def test_chinese_fonts_contains_windows_fonts(self, font_name: str) -> None:
        """测试中文字体列表包含 Windows 字体."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert font_name in fonts

    def test_chinese_fonts_contains_linux_fonts(self) -> None:
        """测试中文字体列表包含 Linux 字体."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert "WenQuanYi Micro Hei" in fonts or "Noto Sans CJK SC" in fonts

    def test_chinese_fonts_order(self) -> None:
        """测试 Windows 字体具有更高优先级."""
        fonts = env_module._PySide2Env._chinese_fonts
        # 第一个字体应该是 Microsoft YaHei (Windows 默认)
        assert fonts[0] == "Microsoft YaHei"


class TestSetupChineseFonts:
    """测试 _setup_chinese_fonts 方法."""

    def test_setup_chinese_fonts_without_qt(self) -> None:
        """测试 Qt 不可用时的字体设置."""
        with patch.dict(
            "sys.modules", {"PySide2.QtGui": None, "PySide2.QtWidgets": None}
        ), patch(
            "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
        ):
            # Should not raise an exception
            env_module._PySide2Env._setup_chinese_fonts()

    def test_setup_chinese_fonts_no_qapplication(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试 QApplication 实例不存在时的字体设置."""
        # 创建 mock 对象
        mock_qapplication_class = MagicMock()
        mock_qapplication_class.instance.return_value = None

        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication = mock_qapplication_class

        mock_qt_gui = MagicMock()

        # 使用 patch.dict 确保导入时使用 mock 对象
        with patch.dict(
            "sys.modules",
            {"PySide2.QtGui": mock_qt_gui, "PySide2.QtWidgets": mock_qt_widgets},
        ), patch.dict(os.environ, {}, clear=False):
            # 清除环境变量以确保测试干净
            if "QT_DEFAULT_FONT_FAMILY" in os.environ:
                del os.environ["QT_DEFAULT_FONT_FAMILY"]

            env_module._PySide2Env._setup_chinese_fonts()

            # 应设置环境变量
            assert "QT_DEFAULT_FONT_FAMILY" in os.environ
            assert (
                os.environ["QT_DEFAULT_FONT_FAMILY"]
                == env_module._PySide2Env._chinese_fonts[0]
            )

    def test_setup_chinese_fonts_with_qapplication(self) -> None:
        """测试 QApplication 实例存在时的字体设置."""
        # 在导入前模拟 Qt 模块
        mock_qt_gui = MagicMock()
        mock_qfont = MagicMock()
        mock_qt_gui.QFont.return_value = mock_qfont

        mock_qapp_instance = MagicMock()
        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication.instance.return_value = mock_qapp_instance
        mock_qt_widgets.QApplication.font.return_value = mock_qfont

        with patch.dict(
            "sys.modules",
            {"PySide2.QtGui": mock_qt_gui, "PySide2.QtWidgets": mock_qt_widgets},
        ):
            env_module._PySide2Env._setup_chinese_fonts()

            # QFont.setFamily 应该至少被调用一次
            assert mock_qfont.setFamily.call_count >= 1
            mock_qt_widgets.QApplication.setFont.assert_called_once()

    def test_setup_chinese_fonts_font_iteration(self) -> None:
        """测试字体设置遍历可用字体."""
        # 在导入前模拟 Qt 模块
        mock_qt_gui = MagicMock()
        mock_qfont = MagicMock()
        mock_qt_gui.QFont.return_value = mock_qfont

        mock_qapp_instance = MagicMock()
        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication.instance.return_value = mock_qapp_instance
        mock_qt_widgets.QApplication.font.return_value = mock_qfont

        with patch.dict(
            "sys.modules",
            {"PySide2.QtGui": mock_qt_gui, "PySide2.QtWidgets": mock_qt_widgets},
        ):
            env_module._PySide2Env._setup_chinese_fonts()

            # 应至少尝试第一个字体
            assert mock_qfont.setFamily.call_count >= 1
            # 第一次调用应该使用列表中的第一个字体
            mock_qfont.setFamily.assert_any_call(
                env_module._PySide2Env._chinese_fonts[0]
            )


class TestModuleExports:
    """测试模块导出."""

    def test_setup_pyside2_env_exported(self) -> None:
        """测试 setup_pyside2_env 是否被导出."""
        assert hasattr(env_module, "setup_pyside2_env")
        # 它们应该在功能上等价(都是 classmethod 引用)
        assert callable(env_module.setup_pyside2_env)
        assert callable(env_module._PySide2Env.setup_env)

    def test_setup_pyside2_env_import_error_handling(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试 setup_env 优雅处理 PySide2 导入错误."""
        # 模拟导入时抛出 ImportError
        with patch.dict("sys.modules", {"PySide2": None}), patch(
            "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
        ):
            # 不应抛出异常
            env_module._PySide2Env.setup_env()

            # 应保持未初始化状态(因为 PySide2 导入失败)
            assert env_module._PySide2Env._initialized is False


class TestSetupCodePath:
    """测试 _setup_code_path 方法."""

    def test_setup_code_path_current_frame_none(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试 inspect.currentframe() 返回 None 时的 _setup_code_path."""
        with patch("inspect.currentframe", return_value=None):
            # Should not raise an exception
            env_module._PySide2Env._setup_code_path()

    def test_setup_code_path_no_valid_callers(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试未找到有效调用者时的 _setup_code_path."""
        mock_frame = MagicMock()
        mock_frame_info = MagicMock()
        mock_frame_info.filename = None  # 无文件名

        with patch("inspect.currentframe", return_value=mock_frame), patch(
            "inspect.getouterframes", return_value=[mock_frame_info]
        ):
            env_module._PySide2Env._setup_code_path()
            # 不应向 sys.path 添加任何内容

    def test_setup_code_path_all_internal_callers(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试所有调用者都是内部调用时的 _setup_code_path."""
        mock_frame = MagicMock()
        mock_frame_info = MagicMock()
        mock_frame_info.filename = (
            "d:\\_dev\\pytola\\pytola-qtstyles\\bitool.gui\\test.py"
        )

        with patch("inspect.currentframe", return_value=mock_frame), patch(
            "inspect.getouterframes", return_value=[mock_frame_info]
        ):
            env_module._PySide2Env._setup_code_path()
            # 不应将内部路径添加到 sys.path

    def test_setup_code_path_adds_caller_directory(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """测试 _setup_code_path 将调用者目录添加到 sys.path."""
        import sys

        original_sys_path = list(sys.path)
        try:
            mock_frame = MagicMock()
            mock_frame_info = MagicMock()
            # 使用 POSIX 风格路径以实现跨平台兼容
            mock_frame_info.filename = str(tmp_path / "unique_test_path/test_script.py")

            with patch("inspect.currentframe", return_value=mock_frame), patch(
                "inspect.getouterframes", return_value=[mock_frame_info]
            ):
                env_module._PySide2Env._setup_code_path()

                # 检查路径是否已添加(使用 'in' 检查成员资格)
                assert str(tmp_path / "unique_test_path") in sys.path
        finally:
            sys.path = original_sys_path

    def test_setup_code_path_exception_handling(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试 _setup_code_path 优雅处理异常."""
        with patch("inspect.currentframe", side_effect=AttributeError("Mock error")):
            # Should not raise an exception
            env_module._PySide2Env._setup_code_path()


class TestIsInternalPath:
    """测试 _is_internal_path 静态方法."""

    @pytest.mark.parametrize(
        "path_str,expected",
        [
            # bitool.gui 内部路径
            ("d:\\_dev\\pytola\\pytola-qtstyles\\bitool.gui\\test.py", True),
            # venv 路径
            ("d:\\_dev\\pytola\\.venv\\Lib\\site-packages\\test.py", True),
            # Python 安装路径
            ("C:\\Python38\\Lib\\test.py", True),
            # conda 路径
            ("C:\\Users\\user\\anaconda3\\Lib\\test.py", True),
            # frozen 路径
            ("<frozen importlib._bootstrap>", True),
            # 外部路径(非内部)
            ("d:\\my_project\\my_script.py", False),
        ],
    )
    def test_is_internal_path_detection(self, path_str: str, expected: bool) -> None:
        """测试内部路径检测."""
        from pathlib import Path

        path = Path(path_str)
        assert env_module._PySide2Env._is_internal_path(path) is expected


class TestSetupEnvEdgeCases:
    """测试 setup_env 方法的边界情况."""

    def test_setup_env_pyside2_no_file_attribute(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """测试 PySide2 没有 __file__ 属性时的 setup_env."""
        mock_pyside2 = MagicMock()
        # 移除 __file__ 属性
        del mock_pyside2.__file__

        with patch.dict("sys.modules", {"PySide2": mock_pyside2}), pytest.raises(
            AttributeError
        ):
            env_module.setup_pyside2_env()

    def test_setup_env_plugins_path_string(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """测试 plugins 路径为字符串时的 setup_env."""
        fake_pyside2_dir = _create_fake_pyside2_dir(tmp_path, with_plugins=True)
        mock_pyside2 = _create_mock_pyside2_module(fake_pyside2_dir)

        with patch.dict("sys.modules", {"PySide2": mock_pyside2}), patch.dict(
            os.environ, {}, clear=False
        ):
            env_module.setup_pyside2_env()

            # 检查环境变量
            assert "QT_QPA_PLATFORM_PLUGIN_PATH" in os.environ
            assert "QT_PLUGIN_PATH" in os.environ
            # 应为 plugins 路径
            fake_plugins_dir = fake_pyside2_dir / "plugins"
            assert os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] == str(
                fake_plugins_dir.absolute()
            )

    def test_setup_code_path_already_in_syspath(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """测试路径已在 sys.path 中时的 _setup_code_path."""
        import sys

        original_sys_path = list(sys.path)
        # 使用 POSIX 风格路径以实现跨平台兼容
        test_path = str(tmp_path / "unique_test_path")

        try:
            # 首先将路径添加到 sys.path
            if test_path not in sys.path:
                sys.path.insert(0, test_path)

            mock_frame = MagicMock()
            mock_frame_info = MagicMock()
            mock_frame_info.filename = str(tmp_path / "unique_test_path/test_script.py")

            initial_path_count = len(sys.path)

            with patch("inspect.currentframe", return_value=mock_frame), patch(
                "inspect.getouterframes", return_value=[mock_frame_info]
            ):
                env_module._PySide2Env._setup_code_path()

                # 不应添加重复项
                assert len(sys.path) == initial_path_count
        finally:
            sys.path = original_sys_path


class TestIsInternalPathEdgeCases:
    """测试 _is_internal_path 方法的边界情况."""

    def test_is_internal_path_with_posix_path(self) -> None:
        """测试 POSIX 风格路径的检测."""
        from pathlib import Path

        path = Path("/home/user/.venv/lib/site-packages/test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_internal_path_python_keyword_case_insensitive(self) -> None:
        """测试 'python' 关键字不区分大小写."""
        from pathlib import Path

        path = Path("C:\\PYTHON38\\Lib\\test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    @pytest.mark.parametrize(
        "path_str",
        [
            "C:\\Users\\user\\anaconda3\\Lib\\test.py",
            "C:\\ProgramData\\Anaconda3\\Lib\\test.py",
        ],
    )
    def test_is_internal_path_anaconda_variants(self, path_str: str) -> None:
        """测试各种 anaconda 路径模式的检测."""
        from pathlib import Path

        # 测试不同的 anaconda 安装
        path = Path(path_str)
        assert env_module._PySide2Env._is_internal_path(path) is True

        # 注意:不含 'anaconda' 关键字的 miniconda3 不会被检测到
        # 这是基于实现的预期行为
