"""Pytest fixtures for GUI test isolation.

此模块提供Qt测试环境的隔离机制,确保每个测试在干净的环境中运行。
主要解决以下问题:
- 单例模式状态污染(_PySide2Env, _HighDPIManager, ThemeManager)
- Qt模块全局状态污染(QApplication实例、环境变量)
- sys.path污染(调用者路径注入)
- 环境变量污染(QT_*系列变量)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Generator
from unittest.mock import MagicMock, patch

import pytest

if TYPE_CHECKING:
    from PySide2.QtWidgets import QApplication

if TYPE_CHECKING:
    from unittest.mock import MagicMock as MagicMockType


def _is_qt_available() -> bool:
    """检查Qt环境是否可用。

    Returns
    -------
        如果PySide2可用返回True,否则返回False
    """
    try:
        import PySide2  # noqa: F401

        return True
    except ImportError:
        return False


@pytest.fixture(autouse=True)
def reset_gui_singletons() -> Generator[None, None, None]:
    """在每个测试前后重置GUI模块的单例状态。

    确保每个测试开始时单例处于未初始化状态,测试结束后恢复原状态。
    此fixture自动应用于所有gui/tests/下的测试。
    """
    import bitool.gui._env as env_module
    import bitool.gui._highdpi as highdpi_module

    # 保存原始状态
    original_env_initialized = env_module._PySide2Env._initialized
    original_highdpi_initialized = highdpi_module._HighDPIManager._initialized
    original_highdpi_scale = highdpi_module._HighDPIManager._scale_factor
    original_highdpi_is_high = highdpi_module._HighDPIManager._is_high_dpi

    # 保存原始环境变量
    original_env_vars = {
        "QT_QPA_PLATFORM_PLUGIN_PATH": os.environ.get("QT_QPA_PLATFORM_PLUGIN_PATH"),
        "QT_PLUGIN_PATH": os.environ.get("QT_PLUGIN_PATH"),
        "QT_DEFAULT_FONT_FAMILY": os.environ.get("QT_DEFAULT_FONT_FAMILY"),
    }

    # 保存原始sys.path
    original_sys_path = list(sys.path)

    try:
        # 测试前:重置单例状态
        env_module._PySide2Env._initialized = False
        highdpi_module._HighDPIManager._initialized = False
        highdpi_module._HighDPIManager._scale_factor = 1.0
        highdpi_module._HighDPIManager._is_high_dpi = False

        # 清除Qt相关环境变量
        for key in [
            "QT_QPA_PLATFORM_PLUGIN_PATH",
            "QT_PLUGIN_PATH",
            "QT_DEFAULT_FONT_FAMILY",
        ]:
            os.environ.pop(key, None)

        yield

    finally:
        # 测试后:恢复原始状态
        env_module._PySide2Env._initialized = original_env_initialized
        highdpi_module._HighDPIManager._initialized = original_highdpi_initialized
        highdpi_module._HighDPIManager._scale_factor = original_highdpi_scale
        highdpi_module._HighDPIManager._is_high_dpi = original_highdpi_is_high

        # 恢复环境变量
        for key, value in original_env_vars.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

        # 恢复sys.path(移除测试中添加的路径)
        sys.path[:] = original_sys_path


@pytest.fixture
def isolated_qt_env(monkeypatch: pytest.MonkeyPatch) -> Generator[None, None, None]:
    """提供完全隔离的Qt测试环境。

    此fixture用于需要完全隔离Qt环境的测试,会:
    - Mock所有PySide2模块
    - 阻止真实的Qt初始化
    - 清理所有Qt相关状态

    Examples
    --------
    >>> def test_something(isolated_qt_env):
    ...     # 测试代码,不会受真实Qt环境影响
    ...     pass
    """
    # Mock PySide2模块
    mock_pyside2 = type(sys)("PySide2")
    mock_pyside2.__file__ = "/fake/PySide2/__init__.py"

    mock_qt_core = type(sys)("PySide2.QtCore")
    mock_qt_gui = type(sys)("PySide2.QtGui")
    mock_qt_widgets = type(sys)("PySide2.QtWidgets")

    # 创建mock类
    from unittest.mock import MagicMock

    mock_qapp = MagicMock()
    mock_qapp.instance.return_value = None
    mock_qt_widgets.QApplication = mock_qapp

    mock_qfont = MagicMock()
    mock_qt_gui.QFont = mock_qfont

    mock_qt = MagicMock()
    mock_qt.AA_EnableHighDpiScaling = 1
    mock_qt.AA_UseHighDpiPixmaps = 2
    mock_qt_core.Qt = mock_qt

    with patch.dict(
        "sys.modules",
        {
            "PySide2": mock_pyside2,
            "PySide2.QtCore": mock_qt_core,
            "PySide2.QtGui": mock_qt_gui,
            "PySide2.QtWidgets": mock_qt_widgets,
        },
    ):
        yield


@pytest.fixture
def themes_dir() -> Path:
    """获取themes目录路径。

    Returns
    -------
        themes目录的Path对象
    """
    return Path(__file__).parent.parent / "stylesheets"


@pytest.fixture
def mock_qapplication(monkeypatch: pytest.MonkeyPatch) -> MagicMockType:
    """创建mock QApplication实例。

    Returns
    -------
        MagicMock对象,模拟QApplication
    """
    mock_app = MagicMock()
    mock_app.instance.return_value = mock_app
    mock_app.font.return_value = MagicMock()
    mock_app.primaryScreen.return_value = None

    import PySide2.QtWidgets

    monkeypatch.setattr(PySide2.QtWidgets.QApplication, "instance", mock_app.instance)
    monkeypatch.setattr(PySide2.QtWidgets.QApplication, "font", mock_app.font)
    monkeypatch.setattr(
        PySide2.QtWidgets.QApplication, "primaryScreen", mock_app.primaryScreen
    )
    monkeypatch.setattr(PySide2.QtWidgets.QApplication, "setAttribute", MagicMock())
    monkeypatch.setattr(PySide2.QtWidgets.QApplication, "setFont", MagicMock())

    return mock_app


@pytest.fixture
def skip_if_no_qt() -> None:
    """如果Qt不可用则跳过测试。

    Examples
    --------
    >>> def test_qt_feature(skip_if_no_qt):
    ...     # 只在Qt可用时运行
    ...     pass
    """
    if not _is_qt_available():
        pytest.skip("PySide2不可用,跳过Qt相关测试")


@pytest.fixture
def qapplication() -> QApplication | None:  # type: ignore[misc]
    """提供QApplication实例用于需要真实Qt环境的测试。

    注意:此fixture会创建真实的QApplication实例,仅在需要真实Qt行为时使用。
    大多数测试应该使用mock_qapplication或isolated_qt_env。

    Yields
    ------
        QApplication实例或None(如果Qt不可用)
    """
    if not _is_qt_available():
        return None

    from PySide2.QtWidgets import QApplication

    # 检查是否已有实例
    app = QApplication.instance()
    if app is not None:
        return app  # type: ignore[return-value]

    # 创建新实例(需要sys.argv)
    import sys

    app = QApplication(sys.argv)
    return app
