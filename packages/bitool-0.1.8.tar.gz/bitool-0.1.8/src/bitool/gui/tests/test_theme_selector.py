"""测试主题选择器对话框."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from bitool.gui.widgets.theme_selector import ThemeSelectorDialog, open_theme_selector

if TYPE_CHECKING:
    from pytestqt.qtbot import QtBot


class TestThemeSelectorDialog:
    """测试主题选择器对话框."""

    @pytest.fixture
    def dialog(self, qtbot: QtBot) -> ThemeSelectorDialog:
        """创建主题选择器对话框."""
        dialog = ThemeSelectorDialog(None, "aqua")
        qtbot.addWidget(dialog)
        return dialog

    def test_dialog_creation(self, dialog: ThemeSelectorDialog) -> None:
        """测试对话框创建."""
        assert dialog.windowTitle() == "选择主题"
        assert dialog.isVisible() is False

    def test_load_themes(self, dialog: ThemeSelectorDialog) -> None:
        """测试加载主题列表."""
        assert dialog.theme_list.count() > 0

        # 检查是否包含一些已知主题
        theme_names = [
            dialog.theme_list.item(i).text() for i in range(dialog.theme_list.count())
        ]
        assert "aqua" in theme_names

    def test_current_theme_selected(self, dialog: ThemeSelectorDialog) -> None:
        """测试当前主题被选中."""
        # 查找当前选中的项目
        selected_items = dialog.theme_list.selectedItems()
        assert len(selected_items) == 1
        assert selected_items[0].text() == "aqua"

    def test_get_selected_theme(self, dialog: ThemeSelectorDialog) -> None:
        """测试获取选中的主题."""
        assert dialog.get_selected_theme() == "aqua"

    def test_theme_selection_change(
        self, dialog: ThemeSelectorDialog, qtbot: QtBot
    ) -> None:
        """测试主题选择变更."""
        # 选择第一个主题
        if dialog.theme_list.count() > 0:
            dialog.theme_list.setCurrentRow(0)
            qtbot.waitUntil(lambda: dialog.theme_list.currentItem() is not None)

            selected_theme = dialog.theme_list.currentItem().text()
            assert dialog.get_selected_theme() == selected_theme

    def test_show_theme_selector_function(self, qtbot: QtBot) -> None:
        """测试 show_theme_selector 函数."""

        # 这个测试会显示对话框，所以我们需要自动关闭它
        def close_dialog() -> None:
            from PySide2.QtWidgets import QApplication

            for widget in QApplication.allWidgets():
                if isinstance(widget, ThemeSelectorDialog):
                    widget.reject()
                    break

        # 在事件循环中关闭对话框
        from PySide2.QtCore import QTimer

        QTimer.singleShot(100, close_dialog)

        result = open_theme_selector(None, "aqua")
        # 因为我们取消了，所以应该返回 None
        assert result is None or isinstance(result, str)

    def test_preview_widgets_exist(self, dialog: ThemeSelectorDialog) -> None:
        """测试预览控件是否存在."""
        assert hasattr(dialog, "preview_button")
        assert hasattr(dialog, "preview_label")
        assert hasattr(dialog, "preview_line_edit")
        assert hasattr(dialog, "preview_checkbox")
        assert hasattr(dialog, "preview_combo")
        assert hasattr(dialog, "preview_slider")

    def test_dialog_accepts_and_returns_theme(self, qtbot: QtBot) -> None:
        """测试对话框接受并返回主题."""
        dialog = ThemeSelectorDialog(None, "aqua")
        qtbot.addWidget(dialog)

        # 选择另一个主题
        if dialog.theme_list.count() > 1:
            dialog.theme_list.setCurrentRow(1)
            qtbot.waitUntil(lambda: dialog.theme_list.currentItem() is not None)
            selected = dialog.theme_list.currentItem().text()

            # 接受对话框
            dialog.accept()

            result = dialog.get_selected_theme()
            assert result == selected

    def test_dialog_rejects_returns_current(self, qtbot: QtBot) -> None:
        """测试对话框拒绝时保持当前主题."""
        dialog = ThemeSelectorDialog(None, "aqua")
        qtbot.addWidget(dialog)

        # 选择另一个主题但不接受
        if dialog.theme_list.count() > 1:
            dialog.theme_list.setCurrentRow(1)
            qtbot.waitUntil(lambda: dialog.theme_list.currentItem() is not None)

        # 拒绝对话框
        dialog.reject()

        # 选中的主题应该是新选择的
        result = dialog.get_selected_theme()
        assert isinstance(result, str)

    def test_open_theme_selector_accepts(self, qtbot: QtBot) -> None:
        """测试 open_theme_selector 接受场景."""
        from PySide2.QtCore import QTimer

        def accept_dialog() -> None:
            from PySide2.QtWidgets import QApplication

            for widget in QApplication.allWidgets():
                if isinstance(widget, ThemeSelectorDialog):
                    widget.accept()
                    break

        # 自动接受对话框
        QTimer.singleShot(100, accept_dialog)

        result = open_theme_selector(None, "aqua")
        # 应该返回选中的主题
        assert result is None or isinstance(result, str)

    def test_theme_selector_with_parent(self, qtbot: QtBot) -> None:
        """测试带父窗口的主题选择器."""
        from PySide2.QtWidgets import QWidget

        parent = QWidget()
        qtbot.addWidget(parent)

        dialog = ThemeSelectorDialog(parent, "aqua")
        qtbot.addWidget(dialog)

        # 验证父窗口设置
        assert dialog.parent() is parent

    def test_theme_selector_empty_current_theme(self, qtbot: QtBot) -> None:
        """测试空当前主题的场景."""
        dialog = ThemeSelectorDialog(None, "")
        qtbot.addWidget(dialog)

        # 应该没有选中项
        selected_items = dialog.theme_list.selectedItems()
        # 可能没有选中项，或者选中第一项
        assert len(selected_items) <= 1

        # get_selected_theme 应该返回空字符串
        assert dialog.get_selected_theme() == ""

    def test_on_theme_selected_none_current(self, dialog: ThemeSelectorDialog) -> None:
        """测试主题选择事件处理 None 当前项."""
        # 模拟调用 _on_theme_selected 带 None 参数
        # 应该不会抛出异常
        dialog._on_theme_selected(None, None)

    def test_apply_preview_theme_empty(self, dialog: ThemeSelectorDialog) -> None:
        """测试应用空主题预览."""
        # 应该不会抛出异常
        dialog._apply_preview_theme("")

    def test_on_accept_no_parent(self, qtbot: QtBot) -> None:
        """测试接受时没有父窗口的场景."""
        dialog = ThemeSelectorDialog(None, "aqua")
        qtbot.addWidget(dialog)

        # 选择新主题
        if dialog.theme_list.count() > 1:
            dialog.theme_list.setCurrentRow(1)
            qtbot.waitUntil(lambda: dialog.theme_list.currentItem() is not None)

        # 调用 _on_accept
        dialog._on_accept()
        # 应该正常完成，不会抛出异常

    def test_on_accept_same_theme(self, qtbot: QtBot) -> None:
        """测试接受时主题未改变的场景."""
        dialog = ThemeSelectorDialog(None, "aqua")
        qtbot.addWidget(dialog)

        # 不改变选择
        dialog._on_accept()
        # 应该正常完成

    def test_dialog_ui_components(self, dialog: ThemeSelectorDialog) -> None:
        """测试对话框UI组件存在性."""
        # 验证主要UI组件存在
        assert dialog.theme_list is not None
        assert dialog._preview_widget is not None

        # 验证预览组件存在
        assert dialog.preview_button is not None
        assert dialog.preview_label is not None
        assert dialog.preview_line_edit is not None
        assert dialog.preview_checkbox is not None
        assert dialog.preview_combo is not None
        assert dialog.preview_slider is not None

    def test_theme_list_sorted(self, dialog: ThemeSelectorDialog) -> None:
        """测试主题列表已排序."""
        theme_names = [
            dialog.theme_list.item(i).text() for i in range(dialog.theme_list.count())
        ]
        assert theme_names == sorted(theme_names)
