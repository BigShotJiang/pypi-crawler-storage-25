#!/usr/bin/env python3
"""Pytola Qt Styles 主题测试演示程序.

展示所有常见 Qt 控件类型,支持实时主题切换.
用于测试和预览所有可用样式表主题的视觉效果.
"""

from __future__ import annotations

import sys

from PySide2.QtCore import Qt
from PySide2.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDoubleSpinBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLCDNumber,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QSlider,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextEdit,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from bitool.core import JsonConfig

from .._themes import apply_theme, list_themes


class ThemeDemoConfig(JsonConfig):
    CURRENT_THEME = "aqua"


conf = ThemeDemoConfig()


class ThemeDemo(QMainWindow):
    """主题测试主窗口."""

    def __init__(self) -> None:
        """初始化主题测试器."""
        super().__init__()

        self._init_ui()
        self._load_themes()

        self._apply_theme(conf.CURRENT_THEME)

    def _init_ui(self) -> None:
        """初始化用户界面."""
        self.setWindowTitle("Pytola Qt Styles - 主题测试器")
        self.setGeometry(100, 100, 1200, 800)

        # 创建菜单栏
        self._create_menu_bar()

        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 主题选择区域
        theme_group = self._create_theme_selector()
        main_layout.addWidget(theme_group)

        # 创建标签页
        tab_widget = QTabWidget()
        tab_widget.addTab(self._create_basic_widgets_tab(), "基础控件")
        tab_widget.addTab(self._create_input_widgets_tab(), "输入控件")
        tab_widget.addTab(self._create_display_widgets_tab(), "显示控件")
        tab_widget.addTab(self._create_complex_widgets_tab(), "复杂控件")
        main_layout.addWidget(tab_widget)

        # 创建状态栏
        self.statusBar().showMessage("就绪 - 请选择主题进行测试")

    def _create_menu_bar(self) -> None:
        """创建菜单栏."""
        menubar = self.menuBar()

        # 文件菜单
        file_menu = menubar.addMenu("文件(&F)")
        file_menu.addAction(
            "新建(&N)", lambda: self.statusBar().showMessage("新建操作")
        )
        file_menu.addAction(
            "打开(&O)", lambda: self.statusBar().showMessage("打开操作")
        )
        file_menu.addAction(
            "保存(&S)", lambda: self.statusBar().showMessage("保存操作")
        )
        file_menu.addSeparator()
        file_menu.addAction("退出(&X)", self.close)

        # 编辑菜单
        edit_menu = menubar.addMenu("编辑(&E)")
        edit_menu.addAction(
            "撤销(&U)", lambda: self.statusBar().showMessage("撤销操作")
        )
        edit_menu.addAction(
            "重做(&R)", lambda: self.statusBar().showMessage("重做操作")
        )
        edit_menu.addSeparator()
        edit_menu.addAction(
            "复制(&C)", lambda: self.statusBar().showMessage("复制操作")
        )
        edit_menu.addAction(
            "粘贴(&V)", lambda: self.statusBar().showMessage("粘贴操作")
        )

        # 帮助菜单
        help_menu = menubar.addMenu("帮助(&H)")
        help_menu.addAction(
            "关于(&A)",
            lambda: self.statusBar().showMessage("Pytola Qt Styles 主题测试器"),
        )

    def _create_theme_selector(self) -> QGroupBox:
        """创建主题选择器.

        Returns
        -------
            包含主题选择控件的分组框
        """
        group = QGroupBox("主题选择")
        layout = QHBoxLayout()

        # 主题标签
        label = QLabel("选择主题:")
        layout.addWidget(label)

        # 主题下拉框
        self.theme_combo = QComboBox()
        self.theme_combo.setMinimumWidth(200)
        layout.addWidget(self.theme_combo)

        # 刷新按钮
        refresh_btn = QPushButton("刷新主题列表")
        refresh_btn.clicked.connect(self._load_themes)
        layout.addWidget(refresh_btn)

        layout.addStretch()
        group.setLayout(layout)
        return group

    def _load_themes(self) -> None:
        """加载可用的主题."""
        self.theme_combo.clear()

        themes = list_themes()
        for theme_name in themes:
            self.theme_combo.addItem(theme_name)

        self.theme_combo.setCurrentText(conf.CURRENT_THEME)
        self.theme_combo.currentTextChanged.connect(self._apply_theme)

    def _apply_theme(self, theme_name: str) -> None:
        """应用选定的主题.

        Args:
            theme_name: 要应用的主题名称
        """
        if not theme_name:
            return

        success = apply_theme(self, theme_name)
        if success:
            conf.CURRENT_THEME = theme_name
            self.statusBar().showMessage(f"已应用主题: {theme_name}")
        else:
            self.statusBar().showMessage(f"应用主题失败: {theme_name}")

    def _create_basic_widgets_tab(self) -> QWidget:
        """创建基础控件标签页.

        Returns
        -------
            包含基础控件的部件
        """
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 标签和按钮
        row1_layout = QHBoxLayout()

        # 标签组
        label_group = QGroupBox("标签")
        label_layout = QVBoxLayout()
        label_layout.addWidget(QLabel("普通标签"))
        label_layout.addWidget(QLabel("这是一个普通文本标签"))
        label_group.setLayout(label_layout)
        row1_layout.addWidget(label_group)

        # 按钮组
        button_group = QGroupBox("按钮")
        button_layout = QVBoxLayout()
        btn1 = QPushButton("普通按钮")
        btn1.clicked.connect(lambda: self.statusBar().showMessage("普通按钮被点击"))
        button_layout.addWidget(btn1)

        btn2 = QPushButton("禁用按钮")
        btn2.setEnabled(False)
        button_layout.addWidget(btn2)

        btn3 = QToolButton()
        btn3.setText("工具按钮")
        btn3.clicked.connect(lambda: self.statusBar().showMessage("工具按钮被点击"))
        button_layout.addWidget(btn3)
        button_group.setLayout(button_layout)
        row1_layout.addWidget(button_group)

        layout.addLayout(row1_layout)

        # 复选框和单选按钮
        row2_layout = QHBoxLayout()

        # 复选框组
        checkbox_group = QGroupBox("复选框")
        checkbox_layout = QVBoxLayout()
        cb1 = QCheckBox("选项 1")
        cb1.setChecked(True)
        checkbox_layout.addWidget(cb1)
        cb2 = QCheckBox("选项 2")
        checkbox_layout.addWidget(cb2)
        cb3 = QCheckBox("禁用选项")
        cb3.setEnabled(False)
        checkbox_layout.addWidget(cb3)
        checkbox_group.setLayout(checkbox_layout)
        row2_layout.addWidget(checkbox_group)

        # 单选按钮组
        radiobutton_group = QGroupBox("单选按钮")
        radiobutton_layout = QVBoxLayout()
        rb1 = QRadioButton("选项 A")
        rb1.setChecked(True)
        radiobutton_layout.addWidget(rb1)
        rb2 = QRadioButton("选项 B")
        radiobutton_layout.addWidget(rb2)
        rb3 = QRadioButton("选项 C")
        radiobutton_layout.addWidget(rb3)
        radiobutton_group.setLayout(radiobutton_layout)
        row2_layout.addWidget(radiobutton_group)

        layout.addLayout(row2_layout)
        layout.addStretch()

        return widget

    def _create_input_widgets_tab(self) -> QWidget:
        """创建输入控件标签页.

        Returns
        -------
            包含输入控件的部件
        """
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 文本输入
        row1_layout = QHBoxLayout()

        # 单行文本框
        lineedit_group = QGroupBox("单行文本框")
        lineedit_layout = QVBoxLayout()
        line_edit = (
            QLineEdit()
            if hasattr(sys.modules.get("PySide2.QtWidgets", None), "QLineEdit")
            else QLabel("QLineEdit需要单独导入")
        )
        from PySide2.QtWidgets import QLineEdit as LE

        line_edit = LE("示例文本")
        line_edit.setPlaceholderText("请输入文本...")
        lineedit_layout.addWidget(line_edit)
        lineedit_group.setLayout(lineedit_layout)
        row1_layout.addWidget(lineedit_group)

        # 下拉框
        combo_group = QGroupBox("下拉框")
        combo_layout = QVBoxLayout()
        combo = QComboBox()
        combo.addItems(["选项 1", "选项 2", "选项 3", "选项 4"])
        combo.setCurrentIndex(0)
        combo_layout.addWidget(combo)
        combo_group.setLayout(combo_layout)
        row1_layout.addWidget(combo_group)

        layout.addLayout(row1_layout)

        # 数值输入
        row2_layout = QHBoxLayout()

        # 整数微调框
        spinbox_group = QGroupBox("整数微调框")
        spinbox_layout = QVBoxLayout()
        spinbox = QSpinBox()
        spinbox.setRange(0, 100)
        spinbox.setValue(50)
        spinbox_layout.addWidget(spinbox)
        spinbox_group.setLayout(spinbox_layout)
        row2_layout.addWidget(spinbox_group)

        # 浮点数微调框
        dspinbox_group = QGroupBox("浮点数微调框")
        dspinbox_layout = QVBoxLayout()
        dspinbox = QDoubleSpinBox()
        dspinbox.setRange(0.0, 100.0)
        dspinbox.setValue(50.5)
        dspinbox.setDecimals(2)
        dspinbox_layout.addWidget(dspinbox)
        dspinbox_group.setLayout(dspinbox_layout)
        row2_layout.addWidget(dspinbox_group)

        # 日期时间编辑
        datetime_group = QGroupBox("日期时间编辑")
        datetime_layout = QVBoxLayout()
        datetime_edit = QDateTimeEdit()
        datetime_edit.setCalendarPopup(True)
        datetime_layout.addWidget(datetime_edit)
        datetime_group.setLayout(datetime_layout)
        row2_layout.addWidget(datetime_group)

        layout.addLayout(row2_layout)

        # 滑块和进度条
        row3_layout = QHBoxLayout()

        # 水平滑块
        slider_h_group = QGroupBox("水平滑块")
        slider_h_layout = QVBoxLayout()
        slider_h = QSlider(Qt.Horizontal)
        slider_h.setRange(0, 100)
        slider_h.setValue(50)
        slider_h_layout.addWidget(slider_h)
        slider_h_group.setLayout(slider_h_layout)
        row3_layout.addWidget(slider_h_group)

        # 垂直滑块
        slider_v_group = QGroupBox("垂直滑块")
        slider_v_layout = QVBoxLayout()
        slider_v = QSlider(Qt.Vertical)
        slider_v.setRange(0, 100)
        slider_v.setValue(50)
        slider_v.setFixedHeight(100)
        slider_v_layout.addWidget(slider_v)
        slider_v_group.setLayout(slider_v_layout)
        row3_layout.addWidget(slider_v_group)

        # 进度条
        progress_group = QGroupBox("进度条")
        progress_layout = QVBoxLayout()
        progress = QProgressBar()
        progress.setRange(0, 100)
        progress.setValue(65)
        progress_layout.addWidget(progress)
        progress_group.setLayout(progress_layout)
        row3_layout.addWidget(progress_group)

        # LCD 数字显示
        lcd_group = QGroupBox("LCD 数字")
        lcd_layout = QVBoxLayout()
        lcd = QLCDNumber()
        lcd.setDigitCount(5)
        lcd.display(12345)
        lcd.setFixedWidth(150)
        lcd_layout.addWidget(lcd)
        lcd_group.setLayout(lcd_layout)
        row3_layout.addWidget(lcd_group)

        layout.addLayout(row3_layout)
        layout.addStretch()

        return widget

    def _create_display_widgets_tab(self) -> QWidget:
        """创建显示控件标签页.

        Returns
        -------
            包含显示控件的部件
        """
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 分组框
        group = QGroupBox("分组框示例")
        group_layout = QVBoxLayout()
        group_layout.addWidget(QLabel("这是分组框内的内容"))
        group_layout.addWidget(QPushButton("分组框内按钮"))
        group.setLayout(group_layout)
        layout.addWidget(group)

        # 多行文本框
        text_edit = QTextEdit()
        text_edit.setPlainText(
            "这是一个 QTextEdit 控件\n支持富文本编辑\n可以显示多行文本"
        )
        text_edit.setMaximumHeight(100)
        layout.addWidget(text_edit)

        # 纯文本框
        plain_text = QPlainTextEdit()
        plain_text.setPlainText(
            "这是一个 QPlainTextEdit 控件\n用于纯文本编辑\n性能更好"
        )
        plain_text.setMaximumHeight(100)
        layout.addWidget(plain_text)

        return widget

    def _create_complex_widgets_tab(self) -> QWidget:
        """创建复杂控件标签页.

        Returns
        -------
            包含复杂控件的部件
        """
        widget = QWidget()
        layout = QVBoxLayout(widget)

        # 树形控件
        tree_group = QGroupBox("树形控件")
        tree_layout = QVBoxLayout()
        tree = QTreeWidget()
        tree.setHeaderLabels(["名称", "值"])

        item1 = QTreeWidgetItem(["项目 1", "值 1"])
        item1.addChild(QTreeWidgetItem(["子项目 1.1", "值 1.1"]))
        item1.addChild(QTreeWidgetItem(["子项目 1.2", "值 1.2"]))
        tree.addTopLevelItem(item1)

        item2 = QTreeWidgetItem(["项目 2", "值 2"])
        item2.addChild(QTreeWidgetItem(["子项目 2.1", "值 2.1"]))
        tree.addTopLevelItem(item2)

        tree.setMaximumHeight(150)
        tree_layout.addWidget(tree)
        tree_group.setLayout(tree_layout)
        layout.addWidget(tree_group)

        # 列表控件
        list_group = QGroupBox("列表控件")
        list_layout = QVBoxLayout()
        list_widget = QListWidget()
        list_widget.addItems([f"列表项 {i + 1}" for i in range(5)])
        list_widget.setMaximumHeight(150)
        list_layout.addWidget(list_widget)
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)

        # 表格控件
        table_group = QGroupBox("表格控件")
        table_layout = QVBoxLayout()
        table = QTableWidget(3, 3)
        table.setHorizontalHeaderLabels(["列 1", "列 2", "列 3"])
        for i in range(3):
            for j in range(3):
                table.setItem(i, j, QTableWidgetItem(f"单元格 {i + 1},{j + 1}"))
        table.setMaximumHeight(150)
        table_layout.addWidget(table)
        table_group.setLayout(table_layout)
        layout.addWidget(table_group)

        return widget


def main() -> None:
    """主函数."""
    app = QApplication(sys.argv)

    window = ThemeDemo()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
