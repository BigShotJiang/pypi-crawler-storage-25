try:
    import tomllib  # ty:ignore[unresolved-import]
except ImportError:
    import tomli as tomllib  # type: ignore[import-not-found, no-redef]


__all__ = ["tomllib"]
