"""Version 模型测试 - 基础功能."""

from __future__ import annotations

import pytest

from bitool.models.version import Version, VersionError, VersionPart


class TestVersionCreation:
    """Version 创建测试."""

    def test_create_basic_version(self) -> None:
        """测试创建基础版本号."""
        v = Version(major=1, minor=2, patch=3)
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
        assert v.prerelease is None
        assert v.buildmetadata is None

    def test_create_version_with_prerelease(self) -> None:
        """测试创建带预发布标识的版本号."""
        v = Version(major=1, minor=0, patch=0, prerelease="alpha")
        assert v.prerelease == "alpha"

    def test_create_version_with_buildmetadata(self) -> None:
        """测试创建带构建元数据的版本号."""
        v = Version(major=1, minor=0, patch=0, buildmetadata="build.123")
        assert v.buildmetadata == "build.123"

    def test_create_version_with_all_fields(self) -> None:
        """测试创建包含所有字段的版本号."""
        v = Version(
            major=2, minor=1, patch=0, prerelease="rc.1", buildmetadata="git.abc123"
        )
        assert str(v) == "2.1.0-rc.1+git.abc123"


class TestVersionString:
    """Version 字符串表示测试."""

    @pytest.mark.parametrize(
        ("major", "minor", "patch", "prerelease", "buildmetadata", "expected"),
        [
            (0, 0, 0, None, None, "0.0.0"),
            (1, 0, 0, None, None, "1.0.0"),
            (1, 2, 3, None, None, "1.2.3"),
            (1, 0, 0, "alpha", None, "1.0.0-alpha"),
            (1, 0, 0, "beta.1", None, "1.0.0-beta.1"),
            (1, 0, 0, None, "build.456", "1.0.0+build.456"),
            (1, 0, 0, "rc.1", "build.789", "1.0.0-rc.1+build.789"),
            (10, 20, 30, None, None, "10.20.30"),
        ],
    )
    def test_version_to_string(
        self,
        major: int,
        minor: int,
        patch: int,
        prerelease: str | None,
        buildmetadata: str | None,
        expected: str,
    ) -> None:
        """测试版本号转字符串."""
        v = Version(
            major=major,
            minor=minor,
            patch=patch,
            prerelease=prerelease,
            buildmetadata=buildmetadata,
        )
        assert str(v) == expected


class TestVersionParse:
    """Version 解析测试."""

    @pytest.mark.parametrize(
        ("version_string", "expected_major", "expected_minor", "expected_patch"),
        [
            ("0.0.0", 0, 0, 0),
            ("1.0.0", 1, 0, 0),
            ("1.2.3", 1, 2, 3),
            ("10.20.30", 10, 20, 30),
            ("999.999.999", 999, 999, 999),
        ],
    )
    def test_parse_basic_version(
        self,
        version_string: str,
        expected_major: int,
        expected_minor: int,
        expected_patch: int,
    ) -> None:
        """测试解析基础版本号."""
        v = Version.parse(version_string)
        assert v.major == expected_major
        assert v.minor == expected_minor
        assert v.patch == expected_patch
        assert v.prerelease is None
        assert v.buildmetadata is None

    @pytest.mark.parametrize(
        ("version_string", "expected_prerelease"),
        [
            ("1.0.0-alpha", "alpha"),
            ("1.0.0-beta.1", "beta.1"),
            ("1.0.0-rc.1", "rc.1"),
            ("1.0.0-alpha.beta.1", "alpha.beta.1"),
            ("2.0.0-SNAPSHOT", "SNAPSHOT"),
        ],
    )
    def test_parse_version_with_prerelease(
        self, version_string: str, expected_prerelease: str
    ) -> None:
        """测试解析带预发布标识的版本号."""
        v = Version.parse(version_string)
        assert v.prerelease == expected_prerelease

    @pytest.mark.parametrize(
        ("version_string", "expected_buildmetadata"),
        [
            ("1.0.0+build.123", "build.123"),
            ("1.0.0+git.abc123", "git.abc123"),
            ("2.0.0+20231001", "20231001"),
        ],
    )
    def test_parse_version_with_buildmetadata(
        self, version_string: str, expected_buildmetadata: str
    ) -> None:
        """测试解析带构建元数据的版本号."""
        v = Version.parse(version_string)
        assert v.buildmetadata == expected_buildmetadata

    def test_parse_version_with_all_fields(self) -> None:
        """测试解析包含所有字段的版本号."""
        v = Version.parse("1.2.3-rc.1+build.456")
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
        assert v.prerelease == "rc.1"
        assert v.buildmetadata == "build.456"

    def test_parse_empty_string_raises(self) -> None:
        """测试解析空字符串抛出异常."""
        with pytest.raises(VersionError, match="版本号字符串不能为空"):
            Version.parse("")

    @pytest.mark.parametrize(
        "invalid_version", ["1.0", "1", "a.b.c", "v1.0.0", " 1.0.0"]
    )
    def test_parse_invalid_version_raises(self, invalid_version: str) -> None:
        """测试解析无效版本号抛出异常."""
        with pytest.raises(VersionError, match="无效的版本号格式"):
            Version.parse(invalid_version)

    def test_parse_caching(self) -> None:
        """测试解析缓存机制."""
        v1 = Version.parse("1.2.3")
        v2 = Version.parse("1.2.3")
        # lru_cache 应该返回同一个对象
        assert v1 is v2


class TestVersionBump:
    """Version 递增测试."""

    def test_bump_major(self) -> None:
        """测试递增主版本号."""
        v = Version(major=1, minor=2, patch=3)
        new_v = v.bump(VersionPart.MAJOR)
        assert new_v.major == 2
        assert new_v.minor == 0
        assert new_v.patch == 0
        assert new_v.prerelease is None
        assert new_v.buildmetadata is None

    def test_bump_minor(self) -> None:
        """测试递增次版本号."""
        v = Version(major=1, minor=2, patch=3)
        new_v = v.bump(VersionPart.MINOR)
        assert new_v.major == 1
        assert new_v.minor == 3
        assert new_v.patch == 0
        assert new_v.prerelease is None

    def test_bump_patch(self) -> None:
        """测试递增补丁号."""
        v = Version(major=1, minor=2, patch=3)
        new_v = v.bump(VersionPart.PATCH)
        assert new_v.major == 1
        assert new_v.minor == 2
        assert new_v.patch == 4
        assert new_v.prerelease is None

    def test_bump_resets_prerelease_by_default(self) -> None:
        """测试递增默认重置预发布标识."""
        v = Version(major=1, minor=0, patch=0, prerelease="alpha")
        new_v = v.bump(VersionPart.PATCH)
        assert new_v.prerelease is None

    def test_bump_keep_prerelease(self) -> None:
        """测试递增保留预发布标识."""
        v = Version(major=1, minor=0, patch=0, prerelease="alpha")
        new_v = v.bump(VersionPart.PATCH, reset_prerelease=False)
        assert new_v.prerelease == "alpha"

    def test_bump_with_new_prerelease(self) -> None:
        """测试递增设置新的预发布标识."""
        v = Version(major=1, minor=0, patch=0)
        new_v = v.bump(VersionPart.MINOR, prerelease="beta")
        assert new_v.minor == 1
        assert new_v.patch == 0
        assert new_v.prerelease == "beta"

    def test_bump_resets_buildmetadata(self) -> None:
        """测试递增重置构建元数据."""
        v = Version(major=1, minor=0, patch=0, buildmetadata="build.123")
        new_v = v.bump(VersionPart.PATCH)
        assert new_v.buildmetadata is None

    @pytest.mark.parametrize(
        ("part", "expected"),
        [
            (VersionPart.MAJOR, "2.0.0"),
            (VersionPart.MINOR, "1.1.0"),
            (VersionPart.PATCH, "1.0.1"),
        ],
    )
    def test_bump_from_zero(self, part: VersionPart, expected: str) -> None:
        """测试从零版本递增."""
        v = Version(major=1, minor=0, patch=0)
        new_v = v.bump(part)
        assert str(new_v) == expected


class TestVersionSetPrerelease:
    """Version 设置预发布标识测试."""

    def test_set_prerelease(self) -> None:
        """测试设置预发布标识."""
        v = Version(major=1, minor=0, patch=0)
        new_v = v.set_prerelease("alpha")
        assert new_v.prerelease == "alpha"
        assert new_v.major == 1
        assert new_v.minor == 0
        assert new_v.patch == 0
        assert new_v.buildmetadata is None

    def test_set_prerelease_replaces_existing(self) -> None:
        """测试设置预发布标识替换已有标识."""
        v = Version(major=1, minor=0, patch=0, prerelease="alpha")
        new_v = v.set_prerelease("beta")
        assert new_v.prerelease == "beta"

    def test_set_prerelease_clears_buildmetadata(self) -> None:
        """测试设置预发布标识清除构建元数据."""
        v = Version(major=1, minor=0, patch=0, buildmetadata="build.123")
        new_v = v.set_prerelease("rc")
        assert new_v.buildmetadata is None

    def test_set_empty_prerelease_raises(self) -> None:
        """测试设置空预发布标识抛出异常."""
        v = Version(major=1, minor=0, patch=0)
        with pytest.raises(VersionError, match="预发布标识不能为空"):
            v.set_prerelease("")


class TestVersionPart:
    """VersionPart 枚举测试."""

    def test_version_part_values(self) -> None:
        """测试 VersionPart 枚举值."""
        assert VersionPart.MAJOR.value == "major"
        assert VersionPart.MINOR.value == "minor"
        assert VersionPart.PATCH.value == "patch"
