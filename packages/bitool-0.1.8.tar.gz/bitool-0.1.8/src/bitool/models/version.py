from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache
from re import Pattern
from typing import Final

VERSION_PATTERN: Final[Pattern[str]] = re.compile(
    r"(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?"
)


class VersionPart(Enum):
    """可更新的版本号部分."""

    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"


class VersionError(Exception):
    """版本号相关异常."""


@dataclass
class Version:
    """语义化版本号, 遵循 SemVer 2.0.0 规范.

    Attributes
    ----------
    major: 主版本号 (破坏性变更时递增)
    minor: 次版本号 (向后兼容的功能新增时递增)
    patch: 补丁号 (向后兼容的 bug 修复时递增)
    prerelease: 预发布标识 (如 "alpha", "beta.1", "rc")
    buildmetadata: 构建元数据 (不参与版本比较)
    """

    major: int
    minor: int
    patch: int
    prerelease: str | None = None
    buildmetadata: str | None = None

    def __str__(self) -> str:
        """返回版本号的字符串表示."""
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            version += f"-{self.prerelease}"
        if self.buildmetadata:
            version += f"+{self.buildmetadata}"
        return version

    @classmethod
    @lru_cache(maxsize=128)
    def parse(cls, version_string: str) -> Version:
        """解析版本号字符串为 Version 对象.

        Parameters
        ----------
        version_string : str
            版本号字符串

        Returns
        -------
        Version
            解析后的 Version 对象

        Raises
        ------
        VersionError
            版本号格式无效时抛出
        """
        if not version_string:
            msg = "版本号字符串不能为空"
            raise VersionError(msg)

        match = VERSION_PATTERN.match(version_string)
        if not match:
            msg = f"无效的版本号格式: {version_string}"
            raise VersionError(msg)

        return cls(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch")),
            prerelease=match.group("prerelease"),
            buildmetadata=match.group("buildmetadata"),
        )

    def bump(
        self,
        part: VersionPart,
        *,
        reset_prerelease: bool = True,
        prerelease: str | None = None,
    ) -> Version:
        """返回递增指定部分后的新版本号.

        Parameters
        ----------
        part : VersionPart
            要递增的版本号部分 (major, minor, patch)
        reset_prerelease : bool
            是否重置预发布标识, 默认是
        prerelease : str | None
            可选的预发布标识, 默认 None

        Returns
        -------
        Version
            递增后的新版本号
        """
        # 确定新的预发布标识值
        new_prerelease = None
        if prerelease is not None:
            new_prerelease = prerelease
        elif not reset_prerelease:
            new_prerelease = self.prerelease

        if part == VersionPart.MAJOR:
            return Version(
                major=self.major + 1,
                minor=0,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,  # 总是重置构建元数据
            )
        if part == VersionPart.MINOR:
            return Version(
                major=self.major,
                minor=self.minor + 1,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,
            )
        if part == VersionPart.PATCH:
            return Version(
                major=self.major,
                minor=self.minor,
                patch=self.patch + 1,
                prerelease=new_prerelease,
                buildmetadata=None,
            )

        msg = f"不支持的版本号部分: {part}"
        raise VersionError(msg)

    def set_prerelease(self, prerelease: str) -> Version:
        """返回设置预发布标识后的新版本号.

        Parameters
        ----------
        prerelease : str
            预发布标识

        Returns
        -------
        Version
            设置预发布标识后的新版本号
        """
        if not prerelease:
            msg = "预发布标识不能为空"
            raise VersionError(msg)

        return Version(
            major=self.major,
            minor=self.minor,
            patch=self.patch,
            prerelease=prerelease,
            buildmetadata=None,
        )
