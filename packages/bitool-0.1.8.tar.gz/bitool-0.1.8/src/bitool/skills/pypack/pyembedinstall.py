"""PyPack 嵌入式 Python 安装 Skill."""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import time
import zipfile
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Final
from urllib.request import Request

from bitool.cmd import BaseCommand, CommandScheduler
from bitool.consts import Constants
from bitool.core import logger, urlopen_safe
from bitool.skills import BaseSkill
from bitool.utils import execute

from .models import PySolutionMixin, conf


@dataclass
class PyEmbedInstallCommand(BaseCommand, PySolutionMixin):
    """嵌入式 Python 安装命令."""

    name: str = "pyembedinstall"
    description: str = "嵌入式 Python 安装命令"

    _USER_AGENT: Final[str] = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    )

    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = conf.DEFAULT_PYTHON_VERSION
    cache_dir: Path | None = None
    offline: bool = False
    timeout: int = 300

    @cached_property
    def dist_embed_dir(self) -> Path:
        """获取嵌入式 Python 目录.

        Returns
        -------
        Path
            嵌入式 Python 目录路径
        """
        return self.required_solution.dist_embed_dir

    def run(self) -> bool:
        """执行安装.

        Returns
        -------
        bool
            是否成功
        """
        logger.info(f"找到 PySolution: {self.solution}")

        logger.info("正在安装嵌入式 Python...")
        start_time = time.perf_counter()

        try:
            # 检查是否已安装且版本匹配
            if (
                self.dist_embed_dir.exists()
                and (self.dist_embed_dir / "python.exe").exists()
            ):
                if self._check_version_matches():
                    logger.info(
                        f"嵌入式 Python 已存在且版本匹配: {self.dist_embed_dir}"
                    )
                    return True
                else:
                    logger.info(
                        f"嵌入式 Python 版本不匹配，正在删除旧版本: {self.dist_embed_dir}"
                    )
                    self._remove_embed_python()

            if not self.download():
                logger.error("下载嵌入式 Python 失败")
                return False

            # 解压
            self._extract(self.cache_file)

            elapsed = time.perf_counter() - start_time
            logger.info(f"嵌入式 Python 安装完成，耗时 {elapsed:.2f}秒")
        except (OSError, zipfile.BadZipFile, ValueError):
            logger.exception("嵌入式 Python 安装失败")
            return False
        else:
            return True

    def download(self) -> bool:
        """执行下载.

        Returns
        -------
        bool
            是否成功
        """
        # 检查缓存
        if self.cache_file.exists() and zipfile.is_zipfile(self.cache_file):
            logger.info(f"使用缓存文件: {self.cache_file}")
            return True

        # 删除损坏的缓存
        if self.cache_file.exists():
            logger.warning("缓存文件损坏，将重新下载")
            self.cache_file.unlink()

        if self.offline:
            logger.error("离线模式：未找到缓存文件")
            return False

        # 尝试从各个 URL 下载
        for i, url in enumerate(self.urls, 1):
            logger.info(f"尝试下载 {i}/{len(self.urls)}: {url}")
            try:
                self._download_from_url(url)
                if zipfile.is_zipfile(self.cache_file):
                    logger.info("下载成功")
                    return True
                logger.warning("下载的文件损坏，尝试下一个 URL")
            except (OSError, ValueError, TimeoutError) as e:
                logger.warning(f"下载失败: {e}")

        logger.error("所有下载源均失败")
        return False

    @cached_property
    def actual_cache_dir(self) -> Path:
        """获取实际的缓存目录.

        Returns
        -------
        Path
            缓存目录路径
        """
        return self.cache_dir or Path(conf.DEFAULT_EMBED_CACHE_DIR)

    @cached_property
    def cache_file(self) -> Path:
        """获取缓存文件路径.

        Returns
        -------
        Path
            缓存文件路径
        """
        return (
            self.actual_cache_dir
            / f"python-{self.python_version}-embed-{Constants.ARCH}.zip"
        )

    @cached_property
    def urls(self) -> list[str]:
        """获取下载 URL 列表.

        Returns
        -------
        list[str]
            URL 列表
        """
        # 处理版本号: 如果是两位版本号(如 3.12),则查找最新版本号
        version = self.full_version
        arch = Constants.ARCH

        return [
            f"{url}{version}/python-{version}-embed-{arch}.zip"
            for url in conf.EMBED_PYTHON_MIRRORS
        ]

    @cached_property
    def full_version(self) -> str:
        """解析完整版本号.

        如果指定的版本号只有两位(如 3.12),则查找映射表中的最新完整版本号.

        Returns
        -------
        str
            完整版本号(如 3.12.6)
        """
        version = self.python_version

        # 检查是否为两位版本号(如 3.12)
        if re.match(r"^\d+\.\d+$", version):
            # 从映射表中获取最新版本号
            full_version = conf.PYTHON_VERSION_MAP.get(version)
            if full_version:
                logger.info(f"将两位版本号 {version} 解析为完整版本号 {full_version}")
                return full_version
            else:
                logger.warning(f"未找到 {version} 的最新版本映射,使用原始版本号")
                return f"{version}.0"

        # 已经是完整版本号,直接返回
        return version

    def _extract(self, zip_file: Path) -> None:
        """解压嵌入式 Python.

        Parameters
        ----------
        zip_file : Path
            ZIP 文件路径
        """
        logger.info(f"正在解压到: {self.dist_embed_dir}")
        self.dist_embed_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(zip_file, "r") as zf:
            zf.extractall(self.dist_embed_dir)

        logger.info(f"解压完成: {self.dist_embed_dir}")

    def _check_version_matches(self) -> bool:
        """检查已安装的 Python 版本是否与请求的版本匹配.

        Returns
        -------
        bool
            版本是否匹配
        """
        try:
            # 通过运行 python.exe --version 来获取已安装的版本

            python_exe = self.dist_embed_dir / "python.exe"
            result = execute(
                [str(python_exe), "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                logger.warning("无法获取已安装 Python 的版本信息")
                return False

            # 解析版本输出，例如 "Python 3.8.10"
            version_output = result.stdout.strip()
            match = re.search(r"Python\s+(\d+\.\d+\.\d+)", version_output)
            if not match:
                logger.warning(f"无法解析版本信息: {version_output}")
                return False

            installed_version = match.group(1)
            matches = installed_version == self.python_version
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
            logger.warning(f"检查 Python 版本时出错: {e}")
            return False
        else:
            return matches

    def _remove_embed_python(self) -> None:
        """删除已安装的嵌入式 Python 目录."""
        try:
            if self.dist_embed_dir.exists():
                shutil.rmtree(self.dist_embed_dir)
                logger.info(f"已删除旧的嵌入式 Python 目录: {self.dist_embed_dir}")
        except OSError as e:
            logger.warning(f"删除嵌入式 Python 目录时出错: {e}")
            # 如果删除失败，尝试创建备份目录名而不是删除
            backup_dir = self.dist_embed_dir.with_name(
                f"{self.dist_embed_dir.name}.old"
            )
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            self.dist_embed_dir.rename(backup_dir)
            logger.info(f"已将旧目录重命名为: {backup_dir}")

    def _download_from_url(self, url: str) -> None:
        """从 URL 下载文件.

        Parameters
        ----------
        url : str
            下载 URL
        """
        req = Request(url, headers={"User-Agent": self._USER_AGENT})  # noqa: S310

        with urlopen_safe(req, timeout=self.timeout) as response:
            if not response.success:
                raise OSError(f"下载失败,HTTP 状态码: {response.status}")

            content_length = response.getheader("content-length", 0)
            total_size = (
                int(content_length) if isinstance(content_length, (str, int)) else 0
            )
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)

            downloaded = 0
            last_progress = 0

            with self.cache_file.open("wb") as f:
                while chunk := response.read(65536):
                    f.write(chunk)
                    downloaded += len(chunk)

                    if total_size > 0:
                        progress = int((downloaded / total_size) * 100)
                        if progress > last_progress:
                            logger.info(
                                f"下载进度: {downloaded / 1024 / 1024:.2f} MB / "
                                f"{total_size / 1024 / 1024:.2f} MB ({progress}%)"
                            )
                            last_progress = progress


class PyEmbedInstallerSkill(BaseSkill):
    """嵌入式 Python 安装 Skill."""

    name = "pyembedinstall"
    description = "PyEmbedInstall 嵌入式 Python 安装工具"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "rootdir", type=Path, nargs="?", default=Path.cwd(), help="项目根目录"
        )
        parser.add_argument(
            "--python-version",
            type=str,
            default=conf.DEFAULT_PYTHON_VERSION,
            help=f"Python 版本 (默认: {conf.DEFAULT_PYTHON_VERSION})",
        )
        parser.add_argument("--cache-dir", type=Path, default=None, help="缓存目录")
        parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
        parser.add_argument(
            "--timeout", type=int, default=300, help="下载超时时间 (默认: 300)"
        )

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建嵌入式 Python 安装调度器."""
        root_dir = args.rootdir or Path.cwd()

        return CommandScheduler(
            commands=[
                PyEmbedInstallCommand(
                    root_dir=root_dir,
                    python_version=args.python_version,
                    cache_dir=args.cache_dir,
                    offline=args.offline,
                    timeout=args.timeout,
                )
            ],
            timeout=600,
        )


def main() -> None:
    """主函数入口."""
    PyEmbedInstallerSkill().run_cli()
