// 自动生成的加载器，用于 $PROJECT_NAME (Unix/Linux/macOS)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <libgen.h>
#include <sys/stat.h>

int main(int argc, char* argv[]) {
    char python_rel_path[] = "$PYTHON_EXE";
    char script_name[] = "$SCRIPT_NAME";
    
    // 获取可执行文件所在目录
    char exe_path[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", exe_path, sizeof(exe_path) - 1);
    
    // Linux 使用 /proc/self/exe, macOS 需要使用 _NSGetExecutablePath
    if (len == -1) {
        // macOS 或其他 Unix 系统的回退方案
        // 这里使用 argv[0] 作为简化处理
        realpath(argv[0], exe_path);
    } else {
        exe_path[len] = '\0';
    }
    
    // 提取目录部分
    char* dir = dirname(exe_path);
    
    // 构建 Python 解释器的完整路径
    char python_path[PATH_MAX];
    snprintf(python_path, sizeof(python_path), "%s/%s", dir, python_rel_path);
    
    // 检查 Python 解释器是否存在且可执行
    if (access(python_path, X_OK) != 0) {
        printf("错误: 找不到 Python 解释器: %s\n", python_path);
        printf("请确保嵌入式 Python 文件存在且具有可执行权限。\n");
        return 1;
    }
    
    // 设置工作目录为可执行文件所在目录
    chdir(dir);
    
    // 尝试在多个位置查找脚本文件
    char script_path[PATH_MAX];
    int found = 0;
    struct stat st;
    
    // 尝试 1: 当前目录 (./main.py)
    snprintf(script_path, sizeof(script_path), "%s", script_name);
    if (stat(script_path, &st) == 0) {
        found = 1;
    }
    
    // 尝试 2: src/$PROJECT_NAME/main.py
    if (!found) {
        snprintf(script_path, sizeof(script_path), "src/$PROJECT_NAME/%s", script_name);
        if (stat(script_path, &st) == 0) {
            found = 1;
        }
    }
    
    // 尝试 3: src/main.py
    if (!found) {
        snprintf(script_path, sizeof(script_path), "src/%s", script_name);
        if (stat(script_path, &st) == 0) {
            found = 1;
        }
    }
    
    if (!found) {
        printf("错误: 找不到脚本文件 %s\n", script_name);
        printf("请确保打包正确。\n");
        return 1;
    }
    
    // 构建参数数组
    char** args = malloc((argc + 2) * sizeof(char*));
    if (!args) {
        printf("错误: 内存分配失败\n");
        return 1;
    }
    
    args[0] = python_path;
    args[1] = script_path;
    for (int i = 1; i < argc; i++) {
        args[i + 1] = argv[i];
    }
    args[argc + 1] = NULL;
    
    // 执行 Python 脚本
    if (execv(python_path, args) == -1) {
        printf("错误: 无法启动 Python 解释器\n");
        printf("Python 路径: %s\n", python_path);
        printf("脚本路径: %s\n", script_path);
        perror("原因");
        free(args);
        return 1;
    }
    
    free(args);
    return 0;
}
