// 自动生成的加载器，用于 $PROJECT_NAME (Windows)
#include <windows.h>
#include <stdio.h>
#include <direct.h>

int main(int argc, char* argv[]) {
    // 设置控制台代码页为 UTF-8，支持中文输出
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    
    char python_rel_path[] = "$PYTHON_EXE";
    char script_name[] = "$SCRIPT_NAME";
    
    // 获取可执行文件所在目录
    char exe_path[MAX_PATH];
    GetModuleFileNameA(NULL, exe_path, MAX_PATH);
    
    // 提取目录部分(兼容正斜杠和反斜杠)
    char* last_slash = strrchr(exe_path, '/');
    if (!last_slash) {
        last_slash = strrchr(exe_path, '\\');
    }
    if (last_slash) {
        *(last_slash + 1) = '\0';
    }
    
    // 构建 Python 解释器的完整路径
    char python_path[MAX_PATH];
    snprintf(python_path, sizeof(python_path), "%s%s", exe_path, python_rel_path);
    
    // 标准化路径: 将所有正斜杠转换为反斜杠 (Windows)
    for (char* p = python_path; *p; p++) {
        if (*p == '/') {
            *p = '\\';
        }
    }
    
    // 检查 Python 解释器是否存在
    if (GetFileAttributesA(python_path) == INVALID_FILE_ATTRIBUTES) {
        printf("错误: 找不到 Python 解释器: %s\n", python_path);
        printf("请确保嵌入式 Python 文件存在且具有可执行权限。\n");
        return 1;
    }
    
    // 设置工作目录为可执行文件所在目录
    SetCurrentDirectoryA(exe_path);
    
    // 尝试在多个位置查找脚本文件(兼容正斜杠和反斜杠)
    char script_path[MAX_PATH];
    BOOL found = FALSE;
    
    // 尝试 1: 当前目录 (./main.py)
    snprintf(script_path, sizeof(script_path), "%s", script_name);
    if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {
        found = TRUE;
    }
    
    // 尝试 2: src/$PROJECT_NAME/main.py
    if (!found) {
        snprintf(script_path, sizeof(script_path), "src/$PROJECT_NAME/$SCRIPT_NAME", script_name);
        if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {
            found = TRUE;
        }
    }
    
    // 尝试 3: src/main.py
    if (!found) {
        snprintf(script_path, sizeof(script_path), "src/%s", script_name);
        if (GetFileAttributesA(script_path) != INVALID_FILE_ATTRIBUTES) {
            found = TRUE;
        }
    }
    
    if (!found) {
        printf("错误: 找不到脚本文件 %s\n", script_name);
        printf("请确保打包正确。\n");
        return 1;
    }
    
    // 标准化脚本路径: 将所有正斜杠转换为反斜杠 (Windows)
    for (char* p = script_path; *p; p++) {
        if (*p == '/') {
            *p = '\\';
        }
    }
    
    // 启动 Python 解释器执行脚本，并传递命令行参数
    char cmd_line[MAX_PATH * 4];
    
    // 构建命令：python.exe main.py [args...]
    int len = snprintf(cmd_line, sizeof(cmd_line), "\"%s\" \"%s\"", python_path, script_path);
    
    // 添加额外的命令行参数（从 argv[1] 开始）
    if (len > 0 && len < (int)sizeof(cmd_line)) {
        for (int i = 1; i < argc; i++) {
            int remaining = sizeof(cmd_line) - len - 1;
            if (remaining > 0) {
                len += snprintf(cmd_line + len, remaining, " \"%s\"", argv[i]);
            }
        }
    }
    
    STARTUPINFO si = {0};
    PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si);
    
    if (CreateProcessA(
        NULL,
        cmd_line,
        NULL,
        NULL,
        FALSE,
        0,
        NULL,
        NULL,
        &si,
        &pi
    )) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD exit_code = 0;
        GetExitCodeProcess(pi.hProcess, &exit_code);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        return (int)exit_code;
    } else {
        DWORD error_code = GetLastError();
        printf("错误: 无法启动 Python 解释器 (错误代码: %lu)\n", error_code);
        
        // 提供详细的错误原因
        switch (error_code) {
            case ERROR_FILE_NOT_FOUND:
                printf("原因: 找不到 Python 解释器文件\n");
                break;
            case ERROR_PATH_NOT_FOUND:
                printf("原因: 路径不存在\n");
                break;
            case ERROR_ACCESS_DENIED:
                printf("原因: 访问被拒绝，检查文件权限\n");
                break;
            case ERROR_BAD_EXE_FORMAT:
                printf("原因: Python 解释器不是有效的 Win32 程序\n");
                break;
            case ERROR_NOT_ENOUGH_MEMORY:
                printf("原因: 内存不足\n");
                break;
            default:
                printf("原因: 系统错误代码 %lu\n", error_code);
                break;
        }
        
        printf("Python 路径: %s\n", python_path);
        printf("脚本路径: %s\n", script_path);
        printf("命令行: %s\n", cmd_line);
        return 1;
    }
}
