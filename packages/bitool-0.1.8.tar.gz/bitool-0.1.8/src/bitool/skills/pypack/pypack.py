"""PyPack 统一打包 Skill.

整合所有 pypack 相关功能，提供完整的打包流程：
- 嵌入式 Python 下载和安装
- 依赖库打包
- 源代码打包
- 加载器生成
- 多格式归档

直接复用已有的 skill 模块，避免重复定义。
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from bitool.cmd import BaseCommand, CommandScheduler
from bitool.core import logger
from bitool.skills._base import BaseSkill
from bitool.skills.pypack.pyarchive import PyArchiveCommand
from bitool.skills.pypack.pyembedinstall import PyEmbedInstallCommand
from bitool.skills.pypack.pylibpack import DownloadDependenciesCommand
from bitool.skills.pypack.pyloadergen import PyLoaderGenSkill
from bitool.skills.pypack.pysourcepack import PySourcePackCommand

from .models import PySolution, conf


class PyPackUnifiedSkill(BaseSkill):
    """PyPack 统一打包技能.

    提供完整的项目打包功能，整合所有 pypack 子功能：
    - pypack-embedpy: 嵌入式 Python 安装
    - pypack-libpack: 依赖库打包
    - pypack-sourcepack: 源码打包
    - pypack-loader: 加载器生成
    - pypack-archive: 归档
    """

    name = "pypack"
    description = "Bitool PyPack - Python项目完整打包工具（统一版）"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        # 操作类型
        parser.add_argument(
            "action",
            nargs="?",
            type=str,
            choices=[
                "build",
                "b",
                "clean",
                "c",
                "list",
                "l",
                "ls",
                "run",
                "r",
                "version",
                "v",
            ],
            help="要执行的操作: build(b), clean(c), list(l), run(r), version(v)",
        )
        parser.add_argument(
            "project",
            nargs="?",
            type=str,
            default=None,
            help="项目名称（用于 run 操作）",
        )
        parser.add_argument(
            "extra_args", nargs="*", default=[], help="传递给打包程序的额外参数"
        )

        # 构建选项
        parser.add_argument(
            "--python-version",
            type=str,
            default=conf.DEFAULT_PYTHON_VERSION,
            help=f"Python 版本（默认: {conf.DEFAULT_PYTHON_VERSION}）",
        )
        parser.add_argument(
            "--mirror",
            type=str,
            choices=conf.LIB_MIRROR_URLS,
            default=conf.DEFAULT_LIB_MIRROR,
            help="PyPI 镜像源",
        )
        parser.add_argument(
            "--archive",
            "-a",
            type=str,
            choices=conf.ARCHIVE_FORMATS,
            default=None,
            help="归档格式",
        )
        parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器."""
        action = args.action

        if action in {"build", "b"}:
            # 直接调用各个 skill 的功能
            return CommandScheduler(
                commands=self._create_build_commands(args), timeout=3600
            )
        elif action in {"clean", "c"}:
            return CommandScheduler(commands=[self._create_clean_command()], timeout=60)
        elif action in {"list", "l", "ls"}:
            return CommandScheduler(commands=[self._create_list_command()], timeout=30)
        elif action in {"run", "r"}:
            project_name = args.project
            if not project_name:
                logger.error("请指定项目名称")
                logger.info("用法: pypack run <project_name>")
                return CommandScheduler(commands=[], timeout=30)

            return CommandScheduler(
                commands=[self._create_run_command(project_name, args.extra_args)],
                timeout=300,
            )
        elif action in {"version", "v"}:
            return CommandScheduler(
                commands=[self._create_version_command()], timeout=10
            )
        else:
            logger.error("请指定操作类型")
            logger.info("可用操作: build(b), clean(c), list(l), run(r), version(v)")
            return CommandScheduler(commands=[], timeout=30)

    def _create_build_commands(self, args: argparse.Namespace) -> list[BaseCommand]:
        """创建构建命令列表.

        使用 DAG 依赖关系优化执行流程，让不相关的任务并行执行：
        - 下载嵌入式Python和下载依赖库可以并行
        - 源码打包和加载器代码生成可以与下载并行
        - 编译加载器需要等待嵌入式Python和代码生成完成
        - 归档需要等待所有任务完成
        """
        commands: list[BaseCommand] = []

        # 1. 嵌入式 Python 安装（网络IO密集型）
        embed_cmd = PyEmbedInstallCommand(
            name="pypack-embed-python",
            root_dir=Path.cwd(),
            python_version=args.python_version,
            offline=args.offline,
        )
        commands.append(embed_cmd)

        # 2. 依赖库下载（网络IO密集型，与步骤1并行）
        libpack_cmd = DownloadDependenciesCommand(
            name="pypack-download-libs", root_dir=Path.cwd(), mirror=args.mirror
        )
        commands.append(libpack_cmd)

        # 3. 源代码打包（本地IO密集型，可与步骤1、2并行）
        sourcepack_cmd = PySourcePackCommand(
            name="pypack-source-pack", root_dir=Path.cwd()
        )
        commands.append(sourcepack_cmd)

        # 4. 加载器生成和编译
        # 4a. 生成脚本文件和C源代码（可与步骤1、2、3并行）
        loader_skill = PyLoaderGenSkill()
        loader_args = argparse.Namespace(rootdir=Path.cwd(), loader_type="console")
        loader_scheduler = loader_skill.create_scheduler(loader_args)

        # 为加载器命令设置依赖关系
        for cmd in loader_scheduler.commands:
            if cmd.name.startswith("write_script_") or cmd.name.startswith(
                "write_c_source_"
            ):
                # 生成脚本和C代码不依赖其他任务，可以立即执行
                pass
            elif cmd.name.startswith("compile_"):
                # 编译需要等待：
                # - 对应的C源代码文件生成完成
                # - 嵌入式Python已安装（因为编译可能需要Python头文件）
                # 通过dependencies字段已经声明了对write_c_source的依赖
                # 这里添加对embed_cmd的依赖
                if "embed_python" not in cmd.dependencies:
                    cmd.dependencies.append("pypack-embed-python")

        commands.extend(loader_scheduler.commands)

        # 5. 归档（可选，依赖所有前面的任务）
        if args.archive:
            archive_cmd = PyArchiveCommand(
                name="pypack-archive", root_dir=Path.cwd(), archive_format=args.archive
            )
            # 归档需要等待所有构建任务完成
            archive_cmd.dependencies = [
                "pypack-embed-python",
                "pypack-download-libs",
                "pypack-source-pack",
            ]
            # 添加所有加载器编译命令作为依赖
            for cmd in loader_scheduler.commands:
                if cmd.name.startswith("compile_"):
                    archive_cmd.dependencies.append(cmd.name)
            commands.append(archive_cmd)

        return commands

    def _create_clean_command(self) -> BaseCommand:
        """创建清理命令."""

        @dataclass
        class CleanCommand(BaseCommand):
            """清理命令."""

            name: str = "pypack-clean"
            description: str = "PyPack 清理构建产物"

            def run(self) -> bool:
                """执行清理."""
                logger.info("正在清理构建产物...")

                dirs_to_clean = [
                    Path.cwd() / ".pypack",
                    Path.cwd() / "dist",
                    Path.cwd() / "build",
                ]

                cleaned = 0
                for dir_path in dirs_to_clean:
                    if dir_path.exists():
                        try:
                            shutil.rmtree(dir_path)
                            logger.info(f"已清理: {dir_path}")
                            cleaned += 1
                        except Exception as e:
                            logger.warning(f"清理失败 {dir_path}: {e}")

                if cleaned == 0:
                    logger.info("未找到需要清理的构建产物")
                else:
                    logger.info(f"已清理 {cleaned} 个目录")

                return True

        return CleanCommand()

    def _create_list_command(self) -> BaseCommand:
        """创建列表命令."""

        @dataclass
        class ListCommand(BaseCommand):
            """列表命令."""

            name: str = "pypack-list"
            description: str = "PyPack 列出项目"

            def run(self) -> bool:
                """执行列表."""
                logger.info(f"正在列出 {Path.cwd()} 中的项目...")

                try:
                    solution = PySolution.from_directory(Path.cwd())
                    if not solution.projects:
                        logger.info("未找到任何项目")
                        return True

                    logger.info(f"找到 {len(solution.projects)} 个项目:")
                    logger.info("=" * 60)

                    for _name, project in sorted(solution.projects.items()):
                        logger.info(f"  {project}")
                        if project.dependencies:
                            logger.info(
                                f"    依赖: {', '.join(project.dependencies[:5])}"
                            )
                            if len(project.dependencies) > 5:
                                logger.info(
                                    f"    ... 及其他 {len(project.dependencies) - 5} 个"
                                )

                    logger.info("=" * 60)
                except Exception as e:
                    logger.error(f"列出项目失败: {e}")
                    return False

                return True

        return ListCommand()

    def _create_run_command(
        self, project_name: str, extra_args: list[str] | None
    ) -> BaseCommand:
        """创建运行命令."""

        @dataclass
        class RunCommand(BaseCommand):
            """运行命令."""

            project_name: str = ""
            extra_args: list[str] | None = None
            name: str = "pypack-run"
            description: str = "PyPack 运行打包的应用"

            def run(self) -> bool:
                """执行运行."""
                # 查找可执行文件
                build_dir = Path.cwd() / ".pypack"
                candidates = [
                    build_dir / f"{self.project_name}.exe",
                    build_dir / self.project_name / f"{self.project_name}.exe",
                    build_dir / "src" / self.project_name / f"{self.project_name}.exe",
                ]

                exe_path = None
                for path in candidates:
                    if path.exists():
                        exe_path = path
                        break

                if exe_path is None:
                    logger.error(f"未找到可执行文件: {self.project_name}")
                    logger.info("请先运行构建命令")
                    return False

                logger.info(f"正在运行: {exe_path}")
                if self.extra_args:
                    logger.info(f"参数: {' '.join(self.extra_args)}")

                try:
                    cmd = [str(exe_path)]
                    if self.extra_args:
                        cmd.extend(self.extra_args)

                    result = subprocess.run(cmd, cwd=str(build_dir))

                    if result.returncode == 0:
                        logger.info("程序执行成功")
                        return True
                    else:
                        logger.warning(f"程序退出，返回码: {result.returncode}")
                        return False

                except Exception as exc:
                    logger.error(f"运行失败: {exc}")
                    return False

        return RunCommand(project_name=project_name, extra_args=extra_args)

    def _create_version_command(self) -> BaseCommand:
        """创建版本命令."""

        @dataclass
        class VersionCommand(BaseCommand):
            """版本命令."""

            name: str = "pypack-version"
            description: str = "PyPack 显示版本"

            def run(self) -> bool:
                """显示版本."""
                logger.info("Bitool PyPack v0.1.0")
                logger.info("Python 项目完整打包工具（统一版）")
                return True

        return VersionCommand()


def main() -> None:
    """主函数入口."""
    exit_code = PyPackUnifiedSkill().run()
    sys.exit(exit_code)
