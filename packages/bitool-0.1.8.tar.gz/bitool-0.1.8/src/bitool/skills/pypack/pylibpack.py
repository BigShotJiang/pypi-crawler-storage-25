"""PyPack 依赖库打包 Skill.

本模块提供自动下载和打包项目依赖库的功能.
通过解析项目中的 pyproject.toml 文件, 收集所有依赖并安装到指定目录.

主要功能:
- 自动扫描项目中的所有 pyproject.toml 文件
- 收集并去重所有依赖项
- 使用 pip download 下载 wheel 文件到全局缓存目录 (~/.bitool/pypack/lib_cache)
- 从缓存的 wheel 文件安装依赖到项目的 .pypack/libs 目录
- 支持缓存复用,避免重复下载
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path

from bitool.cmd import BaseCommand, CommandScheduler, RunCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill
from bitool.skills.pypack.models import conf

from .models import PySolutionMixin


@dataclass
class DownloadDependenciesCommand(BaseCommand, PySolutionMixin):
    """下载依赖命令.

    使用 pip download 下载 wheel 文件到缓存目录, 然后从缓存安装到目标目录.

    Attributes
    ----------
    name : str
        命令名称
    description : str
        命令描述信息
    root_dir : Path
        项目根目录
    dependencies : list[str]
        依赖列表
    mirror : str
        PyPI 镜像源
    lib_dir : Path
        目标库目录
    cache_dir : Path
        全局 wheel 缓存目录
    """

    name: str = "download_dependencies"
    description: str = "下载依赖到指定目录"
    python_version: str = conf.DEFAULT_PYTHON_VERSION

    root_dir: Path = field(default_factory=Path.cwd)
    dependencies: list[str] = field(default_factory=list)
    mirror: str = conf.DEFAULT_LIB_MIRROR
    offline: bool = False

    @cached_property
    def lib_dir(self) -> Path:
        """获取目标库目录.

        Returns
        -------
        Path
            目标库目录路径
        """
        return self.required_solution.dist_libs_dir

    @cached_property
    def cache_dir(self) -> Path:
        """获取全局 wheel 缓存目录.

        Returns
        -------
        Path
            全局缓存目录路径
        """
        return Path(conf.DEFAULT_LIB_CACHE_DIR)

    def run(self) -> bool:
        """执行依赖下载和安装.

        Returns
        -------
        bool
            是否成功
        """
        # 从 solution 获取所有项目的依赖（去重）
        self.dependencies = list(self.required_solution.dependencies)

        if self.dependencies:
            logger.info(
                f"找到 {len(self.dependencies)} 个依赖: {', '.join(self.dependencies)}"
            )
        else:
            logger.info("未找到任何依赖")
            return True

        # 确保缓存目录和目标目录存在
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.lib_dir.mkdir(parents=True, exist_ok=True)

        # 步骤 1: 下载 wheel 文件到缓存目录
        if not self._download_wheels():
            logger.error("下载 wheel 文件失败")
            return False

        # 步骤 2: 从缓存的 wheel 文件安装到目标目录
        if not self._install_from_cache():
            logger.error("从缓存安装依赖失败")
            return False

        logger.info(f"依赖已准备完成: {self.lib_dir}")
        return True

    def _download_wheels(self) -> bool:
        """下载 wheel 文件到缓存目录.

        Returns
        -------
        bool
            是否成功
        """
        # 检查哪些依赖需要下载
        missing_deps = self._get_missing_wheels()
        if not missing_deps:
            logger.info("所有依赖已缓存, 跳过下载")
            return True

        logger.info(f"需要下载 {len(missing_deps)} 个依赖的 wheel 文件")

        # 构建 pip download 命令
        # 注意：不使用 --no-deps，让 pip 下载所有需要的依赖（包括子依赖）
        cmd = ["pip", "download", "--dest", str(self.cache_dir)]

        # 添加镜像源
        if self.mirror in conf.LIB_MIRROR_URLS:
            cmd.extend(["-i", conf.LIB_MIRROR_URLS[self.mirror]])
        else:
            logger.warning(f"无效的镜像源: {self.mirror}")

        cmd.extend(missing_deps)

        logger.info(
            f"正在下载 {len(missing_deps)} 个依赖到缓存目录 {self.cache_dir}..."
        )

        # 执行 pip download 命令
        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("下载 wheel 文件失败")
            return False

        logger.info(f"wheel 文件已缓存到: {self.cache_dir}")
        return True

    def _get_missing_wheels(self) -> list[str]:
        """获取缺失的 wheel 文件对应的依赖.

        Returns
        -------
        list[str]
            缺失的依赖列表
        """
        if not self.cache_dir.exists():
            return self.dependencies

        missing = []
        cached_files = set(self.cache_dir.glob("*.whl"))

        for dep in self.dependencies:
            # 提取包名（去除版本约束）
            pkg_name = (
                dep.split(">=")[0].split("<=")[0].split("==")[0].split("!")[0].strip()
            )
            pkg_name_normalized = pkg_name.lower().replace("-", "_")

            # 检查是否有对应的 wheel 文件
            found = False
            for whl_file in cached_files:
                # wheel 文件名格式: {package}-{version}-{python}-{abi}-{platform}.whl
                # 包名在第一个连字符前
                whl_pkg_name = whl_file.name.split("-")[0].lower()
                if whl_pkg_name == pkg_name_normalized:
                    found = True
                    break

            if not found:
                missing.append(dep)

        return missing

    def _install_from_cache(self) -> bool:
        """从缓存的 wheel 文件安装依赖到目标目录.

        Returns
        -------
        bool
            是否成功
        """
        logger.info(f"正在从缓存安装依赖到: {self.lib_dir}")

        # 去重依赖列表
        unique_deps = list(dict.fromkeys(self.dependencies))

        # 构建 pip install 命令，使用 --no-index --find-links 从本地目录安装
        cmd = [
            "pip",
            "install",
            "--target",
            str(self.lib_dir),
            "--no-compile",
            "--no-warn-script-location",
            "--no-index",  # 不使用 PyPI
            "--find-links",
            str(self.cache_dir),  # 从缓存目录查找
        ]

        cmd.extend(unique_deps)

        logger.info(f"正在从缓存安装 {len(unique_deps)} 个依赖...")

        # 执行 pip install 命令
        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("从缓存安装依赖失败")
            logger.warning("尝试回退到在线安装模式...")
            # 如果缓存安装失败，尝试直接在线安装
            return self._install_online()

        logger.info(f"依赖已从缓存安装到: {self.lib_dir}")
        return True

    def _install_online(self) -> bool:
        """在线安装依赖（缓存失败时的回退方案）.

        Returns
        -------
        bool
            是否成功
        """
        logger.info(f"正在在线安装依赖到: {self.lib_dir}")

        # 去重依赖列表
        unique_deps = list(dict.fromkeys(self.dependencies))

        # 构建 pip install 命令
        cmd = [
            "pip",
            "install",
            "--target",
            str(self.lib_dir),
            "--no-compile",
            "--no-warn-script-location",
        ]

        # 添加镜像源
        if self.mirror in conf.LIB_MIRROR_URLS:
            cmd.extend(["-i", conf.LIB_MIRROR_URLS[self.mirror]])
        else:
            logger.warning(f"无效的镜像源: {self.mirror}")

        cmd.extend(unique_deps)

        logger.info(f"正在在线安装 {len(unique_deps)} 个依赖...")

        # 执行 pip install 命令
        run_cmd = RunCommand(cmd=cmd, timeout=conf.TIMEOUT)
        if not run_cmd.run():
            logger.error("在线安装依赖失败")
            return False

        logger.info(f"依赖已在线安装到: {self.lib_dir}")
        return True


class PyLibPackerSkill(BaseSkill):
    """依赖库打包 Skill.

    提供命令行接口, 解析参数并创建依赖库打包命令.
    支持自动检测项目依赖和使用不同的 PyPI 镜像源.

    Attributes
    ----------
    name : str
        Skill 名称
    description : str
        Skill 描述信息
    """

    name = "pylibpack"
    description = "PyLibPack 依赖库打包工具"
    MIRRORS = ("aliyun", "tsinghua", "pypi")

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "rootdir", type=Path, nargs="?", default=Path.cwd(), help="项目根目录"
        )
        parser.add_argument(
            "--mirror",
            type=str,
            choices=self.MIRRORS,
            default=conf.DEFAULT_LIB_MIRROR,
            help=f"PyPI 镜像源 (默认: {conf.DEFAULT_LIB_MIRROR})",
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建依赖打包调度器."""
        root_dir = args.rootdir

        # 创建下载依赖命令 (内部会自行收集依赖)
        download_cmd = DownloadDependenciesCommand(
            root_dir=root_dir, mirror=args.mirror
        )

        return CommandScheduler(commands=[download_cmd], timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PyLibPackerSkill().run_cli()
