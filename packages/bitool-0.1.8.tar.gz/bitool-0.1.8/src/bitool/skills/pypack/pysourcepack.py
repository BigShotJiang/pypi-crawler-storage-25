"""PyPack 源码打包 Skill.

本模块提供将 Python 项目源代码打包到 root_dir/.pypack/src 目录的功能.
打包后的源代码可用于后续的加载器生成和编译流程.

主要功能:
- 自动扫描项目根目录下的所有 pyproject.toml
- 支持 src layout 和 flat layout 两种项目结构
- 自动忽略缓存、构建产物等无关文件

使用方法:
    $ pysourcepack /path/to/project
"""

from __future__ import annotations

import argparse
import time
from dataclasses import dataclass, field
from pathlib import Path

import tomli as tomllib

from bitool.cmd import BaseCommand, CommandScheduler, FileTreeCopyCommand
from bitool.core import logger
from bitool.skills._base import BaseSkill
from bitool.skills.pypack.models import conf
from bitool.utils.format import format_file_size

from .models import PySolutionMixin


@dataclass
class PyPackProjectCommand(BaseCommand):
    """打包单个项目命令.

    将项目源代码复制到 root_dir/.pypack/src/<project_name> 目录.
    支持 src layout 和 flat layout.

    Attributes
    ----------
    project_dir : Path
        项目目录
    build_dir : Path
        构建目录 (root_dir/.pypack)
    total_size : int
        打包的字节数 (输出)
    """

    name: str = "pack_project"
    description: str = "打包项目源代码"

    project_dir: Path = field(default_factory=Path)
    build_dir: Path = field(default_factory=Path)
    total_size: int = 0

    def run(self) -> bool:
        """执行项目打包."""
        # 从 pyproject.toml 读取项目名称
        pyproject_file = self.project_dir / "pyproject.toml"
        project_name = self.project_dir.name or "root"

        if pyproject_file.exists():
            try:
                content = pyproject_file.read_text(encoding="utf-8")
                data = tomllib.loads(content)
                project_name = data.get("project", {}).get("name", project_name)
            except Exception:
                logger.warning(f"读取 {pyproject_file} 失败, 使用目录名")

        # 创建目标目录
        source_dir = self.build_dir / "src" / project_name
        source_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"正在打包: `{project_name}`")

        # 检查是否为 src layout（代码在 src/ 子目录下）
        src_subdir = self.project_dir / "src"
        if src_subdir.exists() and src_subdir.is_dir():
            # src layout: 复制 src/ 目录下的所有包
            logger.info("检测到 src layout, 复制 src/ 目录")
            target_dir = source_dir / "src"
            target_dir.mkdir(parents=True, exist_ok=True)
            copy_cmd = FileTreeCopyCommand(
                name=f"copy_src_{project_name}",
                description=f"复制 {project_name} 的 src 目录",
                source=src_subdir,
                destination=target_dir,
                ignore_patterns=conf.IGNORE_PATTERNS,
            )
            copy_cmd.run()
        else:
            # flat layout: 复制项目目录内容（排除 .pypack 构建目录）
            logger.info("检测到 flat layout, 复制项目文件")
            import fnmatch
            import shutil

            for item in self.project_dir.iterdir():
                # 跳过 .pypack 构建目录（避免递归）
                if item.name == ".pypack":
                    logger.info(f"跳过构建目录: {item.name}")
                    continue

                # 检查其他忽略模式
                if any(
                    fnmatch.fnmatch(item.name, pattern)
                    for pattern in conf.IGNORE_PATTERNS
                ):
                    continue

                dst_item = source_dir / item.name
                if item.is_dir():
                    shutil.copytree(
                        item,
                        dst_item,
                        ignore=shutil.ignore_patterns(*conf.IGNORE_PATTERNS),
                    )
                else:
                    shutil.copy2(item, dst_item)

        # 计算打包体积
        self.total_size = sum(
            f.stat().st_size for f in source_dir.rglob("*") if f.is_file()
        )
        logger.info(f"已打包: `{project_name}` ({format_file_size(self.total_size)})")

        return True


@dataclass
class PySourcePackCommand(BaseCommand, PySolutionMixin):
    """源码打包总控命令.

    协调项目扫描、源代码复制和入口文件创建.

    Attributes
    ----------
    root_dir : Path
        根目录
    build_dir : Path
        构建目录 (.pypack)
    """

    name: str = "PySourcePack"
    description: str = "PyPack 源码打包"

    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = conf.DEFAULT_PYTHON_VERSION

    def run(self) -> bool:
        """执行源码打包."""
        logger.info("正在打包源代码...")
        start_time = time.perf_counter()

        try:
            projects = list(self.required_solution.projects.values())

            if not projects:
                logger.info("没有找到项目")
                return True

            # 打包每个项目
            total_size = 0
            for project in projects:
                pack_cmd = PyPackProjectCommand(
                    name=f"pack_{project.name}",
                    description=f"打包项目 `{project.name}`",
                    project_dir=project.project_dir,
                    build_dir=self.required_solution.dist_dir,
                )

                if not pack_cmd.run():
                    logger.warning(f"项目 `{project.name}` 打包失败")
                    continue

                total_size += pack_cmd.total_size

            elapsed = time.perf_counter() - start_time
            logger.info(f"源代码打包完成, 耗时 {elapsed:.2f}秒")
            logger.info(f"总打包体积: {format_file_size(total_size)}")
        except Exception:
            logger.exception("源代码打包失败")
            return False
        else:
            return True


class PySourcePackerSkill(BaseSkill):
    """源码打包 Skill.

    提供命令行接口, 解析参数并创建源码打包命令.
    支持自动扫描项目、复制源代码和生成入口文件.

    Attributes
    ----------
    name : str
        Skill 名称
    description : str
        Skill 描述信息
    """

    name = "pypack-sourcepack"
    description = "PyPack 源码打包工具"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "rootdir", type=Path, nargs="?", default=Path.cwd(), help="项目根目录"
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建源码打包调度器."""
        root_dir = args.rootdir or Path.cwd()
        build_dir = root_dir / ".pypack"
        build_dir.mkdir(parents=True, exist_ok=True)

        # 创建总控打包命令
        pack_cmd = PySourcePackCommand(
            name="pack_all_projects", description="打包所有项目", root_dir=root_dir
        )

        return CommandScheduler(commands=[pack_cmd], timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PySourcePackerSkill().run_cli()
