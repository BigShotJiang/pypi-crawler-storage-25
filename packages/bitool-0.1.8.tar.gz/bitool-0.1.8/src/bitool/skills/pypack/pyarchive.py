"""PyPack 归档 Skill."""

from __future__ import annotations

import argparse
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Final

from bitool.cmd import BaseCommand, CommandScheduler
from bitool.core import logger
from bitool.skills import BaseSkill
from bitool.utils import execute


@dataclass
class PyArchiveCommand(BaseCommand):
    """归档命令."""

    root_dir: Path = field(default_factory=Path.cwd)
    archive_format: str = "zip"
    name: str = "pypack-archive"
    description: str = "PyPack 归档工具"
    ARCHIVE_FORMATS: Final[tuple[str, ...]] = (
        "zip",
        "tar",
        "gztar",
        "bztar",
        "xztar",
        "7z",
    )

    def run(self) -> bool:
        """执行归档."""

        archiver = PyArchiver(root_dir=self.root_dir)
        return archiver.run(self.archive_format)


class PyArchiverSkill(BaseSkill):
    """归档 Skill."""

    name = "pypack-archive"
    description = "PyPack 归档工具 - 支持多种归档格式"

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "rootdir", type=Path, nargs="?", default=Path.cwd(), help="项目根目录"
        )
        parser.add_argument(
            "--format",
            "-f",
            type=str,
            choices=("zip", "tar", "gztar", "bztar", "xztar", "7z"),
            default="zip",
            help="归档格式 (默认: zip)",
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建归档调度器."""
        root_dir = args.rootdir or Path.cwd()

        return CommandScheduler(
            commands=[PyArchiveCommand(root_dir=root_dir, archive_format=args.format)],
            timeout=300,
        )


def main() -> None:
    """主函数入口."""
    PyArchiverSkill().run_cli()


@dataclass
class PyArchiver:
    """归档器.

    支持多种归档格式：ZIP、tar.gz、7z 等.

    Attributes
    ----------
    root_dir : Path
        根目录
    build_dir : Path
        构建目录（.pypack）
    """

    root_dir: Path
    build_dir: Path | None = None

    def __post_init__(self) -> None:
        """初始化后设置默认构建目录."""
        if self.build_dir is None:
            self.build_dir = self.root_dir / ".pypack"

    def run(self, archive_format: str = "zip") -> bool:
        """执行归档.

        Parameters
        ----------
        archive_format : str
            归档格式，支持：zip、tar、gztar、bztar、xztar、7z

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 确保 build_dir 已设置
            if self.build_dir is None:
                self.build_dir = self.root_dir / ".pypack"

            build_dir = self.build_dir  # 类型窄化

            if not build_dir.exists():
                logger.warning(f"构建目录不存在: {build_dir}")
                return False

            # 根据格式选择归档方法
            if archive_format == "7z":
                return self._archive_7z(build_dir)
            elif archive_format in {"zip", "tar", "gztar", "bztar", "xztar"}:
                return self._archive_shutil(archive_format, build_dir)
            else:
                logger.error(f"不支持的归档格式: {archive_format}")
                return False

        except Exception as exc:
            logger.error(f"归档失败: {exc}")
            return False

    def _archive_shutil(self, archive_format: str, build_dir: Path) -> bool:
        """使用 shutil 进行归档.

        Parameters
        ----------
        archive_format : str
            归档格式：zip、tar、gztar、bztar、xztar
        build_dir : Path
            构建目录

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 输出文件名（不含扩展名）
            output_name = self.root_dir / f"{self.root_dir.name}_package"

            logger.info(f"正在创建 {archive_format} 归档...")

            # 使用 shutil.make_archive
            archive_path = shutil.make_archive(
                base_name=str(output_name),
                format=archive_format,
                root_dir=str(build_dir),
            )

            logger.info(f"归档完成: {archive_path}")
        except Exception as exc:
            logger.error(f"shutil 归档失败: {exc}")
            return False
        else:
            return True

    def _archive_7z(self, build_dir: Path) -> bool:
        """使用 7-Zip 进行归档.

        Parameters
        ----------
        build_dir : Path
            构建目录

        Returns
        -------
        bool
            是否成功
        """
        try:
            # 检查 7z 是否可用
            if not self._check_7z():
                logger.warning("未找到 7z 命令，回退到 ZIP 格式")
                return self._archive_shutil("zip", build_dir)

            output_file = self.root_dir / f"{self.root_dir.name}_package.7z"

            logger.info("正在创建 7z 归档...")

            # 构建通配符路径
            source_pattern = str(build_dir / "*")

            cmd = [
                "7z",
                "a",
                "-t7z",
                "-mx=9",  # 最高压缩级别
                str(output_file),
                source_pattern,
            ]

            result = execute(cmd, capture_output=True, text=True, timeout=300)

            if result.returncode == 0:
                logger.info(f"7z 归档完成: {output_file}")
                return True
            else:
                logger.error(f"7z 归档失败: {result.stderr}")
                return False

        except Exception as exc:
            logger.error(f"7z 归档失败: {exc}")
            return False

    def _check_7z(self) -> bool:
        """检查 7z 命令是否可用.

        Returns
        -------
        bool
            是否可用
        """
        try:
            result = execute(
                ["7z", "--help"], capture_output=True, text=True, timeout=5
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        else:
            return result.returncode == 0
