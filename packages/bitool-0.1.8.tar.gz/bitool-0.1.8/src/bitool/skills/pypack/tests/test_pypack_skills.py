"""pypack 系列 skills 测试.

测试重点：
- 是否正确生成对应的文件或目录
- 各种边界情况和异常处理
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from bitool.skills.pypack.pyarchive import PyArchiver
from bitool.skills.pypack.pyembedinstall import PyEmbedInstallCommand
from bitool.skills.pypack.pylibpack import DownloadDependenciesCommand


class TestPyArchiver:
    """测试 PyArchiver."""

    def test_archive_zip(self, tmp_path: Path) -> None:
        """测试 ZIP 归档."""
        # 创建构建目录
        build_dir = tmp_path / ".pypack"
        build_dir.mkdir()
        (build_dir / "test.txt").write_text("test", encoding="utf-8")

        archiver = PyArchiver(root_dir=tmp_path)
        result = archiver.run("zip")

        assert result is True
        # 检查是否生成了 zip 文件
        zip_files = list(tmp_path.glob("*_package.zip"))
        assert len(zip_files) == 1

    def test_archive_nonexistent_build_dir(self, tmp_path: Path) -> None:
        """测试构建目录不存在时的归档."""
        archiver = PyArchiver(root_dir=tmp_path)
        result = archiver.run("zip")

        # 应该失败因为目录不存在
        assert result is False

    def test_archive_unsupported_format(self, tmp_path: Path) -> None:
        """测试不支持的归档格式."""
        build_dir = tmp_path / ".pypack"
        build_dir.mkdir()

        archiver = PyArchiver(root_dir=tmp_path)
        result = archiver.run("unsupported")

        assert result is False


class TestEmbedInstaller:
    """测试 PyEmbedInstallCommand."""

    def test_embed_dir_path(self, tmp_path: Path) -> None:
        """测试嵌入式 Python 目录路径."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path)

        # 现在使用 PySolution 的 dist_embed_dir，路径为 .pypack/pyruntime
        expected_dir = tmp_path / ".pypack" / "pyruntime"
        assert installer.dist_embed_dir == expected_dir

    def test_run_already_installed(self, tmp_path: Path) -> None:
        """测试已安装且版本匹配时直接返回成功."""
        # 创建 PySolution 期望的目录结构
        embed_dir = tmp_path / ".pypack" / "pyruntime"
        embed_dir.mkdir(parents=True)
        (embed_dir / "python.exe").touch()

        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.8.10")

        # Mock 版本检查返回匹配
        with patch.object(installer, "_check_version_matches", return_value=True):
            with patch.object(
                PyEmbedInstallCommand, "download", return_value=True
            ) as mock_download:
                result = installer.run()

                assert result is True
                # 不应该调用下载
                mock_download.assert_not_called()

    def test_run_version_mismatch_reinstalls(self, tmp_path: Path) -> None:
        """测试已安装但版本不匹配时删除并重新安装."""
        # 创建 PySolution 期望的目录结构
        embed_dir = tmp_path / ".pypack" / "pyruntime"
        embed_dir.mkdir(parents=True)
        (embed_dir / "python.exe").touch()

        # 请求不同的版本
        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.9.0")

        # Mock 版本检查返回不匹配，下载成功
        with patch.object(installer, "_check_version_matches", return_value=False):
            with patch.object(installer, "_remove_embed_python") as mock_remove:
                with patch.object(PyEmbedInstallCommand, "download", return_value=True):
                    with patch.object(installer, "_extract"):
                        result = installer.run()

                        assert result is True
                        # 应该调用删除旧版本
                        mock_remove.assert_called_once()

    def test_run_version_mismatch_download_fails(self, tmp_path: Path) -> None:
        """测试版本不匹配但下载失败时返回失败."""
        # 创建 PySolution 期望的目录结构
        embed_dir = tmp_path / ".pypack" / "pyruntime"
        embed_dir.mkdir(parents=True)
        (embed_dir / "python.exe").touch()

        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.9.0")

        # Mock 版本检查返回不匹配，下载失败
        with patch.object(installer, "_check_version_matches", return_value=False):
            with patch.object(installer, "_remove_embed_python"):
                with patch.object(
                    PyEmbedInstallCommand, "download", return_value=False
                ):
                    result = installer.run()

                    assert result is False

    def test_actual_cache_dir_default(self, tmp_path: Path) -> None:
        """测试默认缓存目录."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path)

        # 默认缓存目录应该是 ~/.bitool/pypack/embed_cache
        expected = Path.home() / ".bitool" / "pypack" / "embed_cache"
        assert installer.actual_cache_dir == expected

    def test_actual_cache_dir_custom(self, tmp_path: Path) -> None:
        """测试自定义缓存目录."""
        custom_cache = tmp_path / "custom_cache"
        installer = PyEmbedInstallCommand(root_dir=tmp_path, cache_dir=custom_cache)

        assert installer.actual_cache_dir == custom_cache

    def test_cache_file_path(self, tmp_path: Path) -> None:
        """测试缓存文件路径."""
        installer = PyEmbedInstallCommand(
            root_dir=tmp_path, cache_dir=tmp_path / "cache"
        )

        # 缓存文件应该在 cache 目录中
        expected = tmp_path / "cache" / "python-3.8.10-embed-amd64.zip"
        assert installer.cache_file == expected

    def test_download_urls_multiple_mirrors(self, tmp_path: Path) -> None:
        """测试下载 URL 包含多个镜像源."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path)

        urls = installer.urls

        # 应该有多个 URL（镜像 + 官方）
        assert len(urls) >= 2
        # 第一个应该是镜像源
        assert "mirrors" in urls[0] or "aliyun" in urls[0]

    def test_download_uses_cache(self, tmp_path: Path) -> None:
        """测试下载时使用缓存."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()

        # 创建假的缓存文件（需要是有效的zip文件）
        import zipfile

        cache_file = cache_dir / "python-3.8.10-embed-amd64.zip"
        with zipfile.ZipFile(cache_file, "w") as zf:
            zf.writestr("test.txt", "test")

        installer = PyEmbedInstallCommand(root_dir=tmp_path, cache_dir=cache_dir)

        result = installer.download()

        assert result is True

    def test_download_offline_no_cache(self, tmp_path: Path) -> None:
        """测试离线模式且无缓存时失败."""
        installer = PyEmbedInstallCommand(
            root_dir=tmp_path, offline=True, cache_dir=tmp_path / "cache"
        )

        result = installer.download()

        assert result is False

    def test_resolve_full_version_two_digits(self, tmp_path: Path) -> None:
        """测试两位版本号解析为完整版本号."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.12")

        # 应该解析为完整版本号
        full_version = installer.full_version
        assert full_version == "3.12.6"

    def test_resolve_full_version_three_digits(self, tmp_path: Path) -> None:
        """测试三位版本号保持不变."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.12.6")

        # 应该保持原样
        full_version = installer.full_version
        assert full_version == "3.12.6"

    def test_resolve_full_version_unknown_two_digits(self, tmp_path: Path) -> None:
        """测试未知的两位版本号返回原始值."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.99")

        # 映射表中不存在,应该返回原始值
        full_version = installer.full_version
        assert full_version == "3.99.0"

    def test_urls_with_two_digit_version(self, tmp_path: Path) -> None:
        """测试两位版本号生成的 URL 使用完整版本号."""
        installer = PyEmbedInstallCommand(root_dir=tmp_path, python_version="3.12")

        urls = installer.urls

        # 所有 URL 应该包含完整版本号 3.12.6
        for url in urls:
            assert "3.12.6" in url
            assert "3.12/" not in url  # 不应该只有两位版本号


class TestDownloadDependenciesCommand:
    """测试 DownloadDependenciesCommand."""

    def test_get_dependencies_from_pyproject(self, tmp_path: Path) -> None:
        """测试从 pyproject.toml 读取依赖."""
        # 创建项目
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "test-project"\ndependencies = ["requests>=2.0", "click"]',
            encoding="utf-8",
        )

        cmd = DownloadDependenciesCommand(root_dir=tmp_path)
        # 手动调用 run 来触发依赖收集
        with patch("bitool.skills.pypack.pylibpack.RunCommand") as mock_run:
            mock_run.return_value.run.return_value = True
            cmd.run()

        assert "requests>=2.0" in cmd.dependencies
        assert "click" in cmd.dependencies

    def test_get_dependencies_deduplicates(self, tmp_path: Path) -> None:
        """测试依赖去重."""
        # 创建两个项目，有相同依赖
        for idx, name in enumerate(["proj1", "proj2"], 1):
            project_dir = tmp_path / name
            project_dir.mkdir()
            (project_dir / "pyproject.toml").write_text(
                f'[project]\nname = "test-project-{idx}"\ndependencies = ["requests"]',
                encoding="utf-8",
            )

        cmd = DownloadDependenciesCommand(root_dir=tmp_path)
        with patch("bitool.skills.pypack.pylibpack.RunCommand") as mock_run:
            mock_run.return_value.run.return_value = True
            cmd.run()

        # requests 应该只出现一次
        assert cmd.dependencies.count("requests") == 1

    def test_get_dependencies_skips_cbuild(self, tmp_path: Path) -> None:
        """测试跳过 .pypack 目录中的 pyproject.toml."""
        cbuild_project = tmp_path / ".pypack" / "src" / "project"
        cbuild_project.mkdir(parents=True)
        (cbuild_project / "pyproject.toml").write_text(
            '[project]\ndependencies = ["should-not-appear"]', encoding="utf-8"
        )

        cmd = DownloadDependenciesCommand(root_dir=tmp_path)
        with patch("bitool.skills.pypack.pylibpack.RunCommand") as mock_run:
            mock_run.return_value.run.return_value = True
            cmd.run()

        assert "should-not-appear" not in cmd.dependencies

    def test_download_dependencies_creates_lib_dir(self, tmp_path: Path) -> None:
        """测试下载依赖时创建 lib 目录."""
        # 创建项目
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        (project_dir / "pyproject.toml").write_text(
            '[project]\nname = "test-project"\ndependencies = ["requests"]',
            encoding="utf-8",
        )

        cmd = DownloadDependenciesCommand(root_dir=tmp_path)

        # Mock pip install
        with patch("bitool.skills.pypack.pylibpack.RunCommand") as mock_run:
            mock_run.return_value.run.return_value = True
            result = cmd.run()

            assert result is True
            # 检查是否创建了 lib 目录
            assert cmd.lib_dir.exists()
