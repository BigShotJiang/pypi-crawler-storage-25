"""EntryFile 和 Dependency 模型测试."""

from __future__ import annotations

from pathlib import Path

import pytest

from ..models import PyDependency, PyEntryFile


class TestEntryFile:
    """EntryFile 模型测试."""

    def test_entry_file_creation(self, tmp_path: Path) -> None:
        """测试创建 EntryFile."""
        source = tmp_path / "main.py"
        entry = PyEntryFile(
            project_name="my-project", source_file=source, project_root=tmp_path
        )
        assert entry.project_name == "my-project"
        assert entry.source_file == source
        assert entry.project_root == tmp_path

    def test_entry_file_without_project_root(self, tmp_path: Path) -> None:
        """测试不指定项目根目录."""
        source = tmp_path / "main.py"
        entry = PyEntryFile(project_name="my-project", source_file=source)
        assert entry.project_root is None

    def test_entry_file_relative_path(self, tmp_path: Path) -> None:
        """测试相对路径计算."""
        source = tmp_path / "src" / "main.py"
        source.parent.mkdir()
        source.touch()

        entry = PyEntryFile(
            project_name="my-project", source_file=source, project_root=tmp_path
        )
        assert entry.relative_path == Path("src/main.py")

    def test_entry_file_relative_path_without_root(self, tmp_path: Path) -> None:
        """测试没有项目根目录时的相对路径."""
        source = tmp_path / "main.py"
        entry = PyEntryFile(project_name="my-project", source_file=source)
        assert entry.relative_path == "main.py"

    def test_entry_file_output_stem(self, tmp_path: Path) -> None:
        """测试输出文件名."""
        source = tmp_path / "main.py"
        entry = PyEntryFile(project_name="my-project", source_file=source)
        assert entry.output_stem == "main"

    def test_entry_file_to_dict(self, tmp_path: Path) -> None:
        """测试转换为字典."""
        source = tmp_path / "cli.py"
        entry = PyEntryFile(
            project_name="my-project", source_file=source, project_root=tmp_path
        )
        d = entry.to_dict()
        assert d["project_name"] == "my-project"
        assert d["source_file"] == str(source)
        assert d["output_stem"] == "cli"

    def test_entry_file_str(self, tmp_path: Path) -> None:
        """测试字符串表示."""
        source = tmp_path / "app.py"
        entry = PyEntryFile(project_name="my-project", source_file=source)
        assert str(entry) == "my-project:app.py"


class TestDetectEntryFiles:
    """detect_entry_files 函数测试."""

    def test_detect_single_entry_file(self, tmp_path: Path) -> None:
        """测试检测单个入口文件."""
        main_py = tmp_path / "main.py"
        main_py.write_text("def main(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(tmp_path, "my-project")
        assert len(entry_files) == 1
        # 项目名称会被规范化（- 替换为 _）
        assert entry_files[0].project_name == "my_project"
        assert entry_files[0].source_file == main_py

    def test_detect_multiple_entry_files(self, tmp_path: Path) -> None:
        """测试检测多个入口文件."""
        main_py = tmp_path / "main.py"
        main_py.write_text("def main(): pass\n")

        cli_py = tmp_path / "cli.py"
        cli_py.write_text("if __name__ == '__main__': pass\n")

        utils_py = tmp_path / "utils.py"
        utils_py.write_text("def helper(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(tmp_path, "my-project")
        # 项目名称会被规范化
        assert len(entry_files) == 2
        assert all(ef.project_name == "my_project" for ef in entry_files)

    def test_detect_no_entry_files(self, tmp_path: Path) -> None:
        """测试没有入口文件."""
        utils_py = tmp_path / "utils.py"
        utils_py.write_text("def helper(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(tmp_path, "my-project")
        assert len(entry_files) == 0

    def test_detect_normalizes_project_name(self, tmp_path: Path) -> None:
        """测试项目名称规范化."""
        main_py = tmp_path / "main.py"
        main_py.write_text("def main(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(tmp_path, "My-Project")
        assert entry_files[0].project_name == "my_project"

    def test_detect_with_project_root(self, tmp_path: Path) -> None:
        """测试指定项目根目录."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        main_py = src_dir / "main.py"
        main_py.write_text("def main(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(
            src_dir, "my-project", project_root=tmp_path
        )
        assert len(entry_files) == 1
        assert entry_files[0].project_root == tmp_path

    def test_detect_only_py_files(self, tmp_path: Path) -> None:
        """测试只检测 .py 文件."""
        main_py = tmp_path / "main.py"
        main_py.write_text("def main(): pass\n")

        main_txt = tmp_path / "main.txt"
        main_txt.write_text("def main(): pass\n")

        entry_files = PyEntryFile.detect_entry_files(tmp_path, "my-project")
        assert len(entry_files) == 1


class TestDependency:
    """Dependency 模型测试."""

    def test_create_dependency_minimal(self) -> None:
        """测试创建最小化依赖."""
        dep = PyDependency(name="requests")
        assert dep.name == "requests"
        assert dep.version is None
        assert dep.extras == []

    def test_create_dependency_with_version(self) -> None:
        """测试创建带版本的依赖."""
        dep = PyDependency(name="requests", version=">=2.28.0")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"
        assert dep.extras == []

    def test_create_dependency_with_extras(self) -> None:
        """测试创建带额外依赖的依赖."""
        dep = PyDependency(name="requests", extras=["security", "socks"])
        assert dep.name == "requests"
        assert dep.extras == ["security", "socks"]

    def test_create_dependency_full(self) -> None:
        """测试创建完整依赖."""
        dep = PyDependency(
            name="requests", version=">=2.28.0", extras=["security", "socks"]
        )
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"
        assert dep.extras == ["security", "socks"]

    def test_dependency_str_without_version(self) -> None:
        """测试字符串表示（无版本）."""
        dep = PyDependency(name="requests")
        assert str(dep) == "requests"

    def test_dependency_str_with_version(self) -> None:
        """测试字符串表示（有版本）."""
        dep = PyDependency(name="requests", version=">=2.28.0")
        assert str(dep) == "requests>=2.28.0"

    def test_dependency_to_dict(self) -> None:
        """测试转换为字典."""
        dep = PyDependency(name="requests", version=">=2.28.0", extras=["security"])
        d = dep.to_dict()
        assert d["name"] == "requests"
        assert d["version"] == ">=2.28.0"
        assert d["extras"] == ["security"]


class TestDependencyFromString:
    """Dependency.from_string 测试."""

    @pytest.mark.parametrize(
        ("dep_str", "expected_name", "expected_version"),
        [
            ("requests", "requests", None),
            ("requests>=2.28.0", "requests", ">=2.28.0"),
            ("requests==2.28.0", "requests", "==2.28.0"),
            ("requests>=2.28.0,<3.0", "requests", ">=2.28.0,<3.0"),
            ("flask>=2.0", "flask", ">=2.0"),
            ("numpy", "numpy", None),
            ("pandas>=1.5.0", "pandas", ">=1.5.0"),
        ],
    )
    def test_from_string_valid(
        self, dep_str: str, expected_name: str, expected_version: str | None
    ) -> None:
        """测试从有效字符串创建依赖."""
        dep = PyDependency.from_string(dep_str)
        assert dep.name == expected_name
        assert dep.version == expected_version

    def test_from_string_with_whitespace(self) -> None:
        """测试处理空白字符."""
        dep = PyDependency.from_string("  requests>=2.28.0  ")
        assert dep.name == "requests"
        assert dep.version == ">=2.28.0"

    def test_from_string_with_dashes_and_underscores(self) -> None:
        """测试处理带连字符和下划线的包名."""
        dep = PyDependency.from_string("my-package>=1.0.0")
        assert dep.name == "my-package"
        assert dep.version == ">=1.0.0"

        dep2 = PyDependency.from_string("my_package>=1.0.0")
        assert dep2.name == "my_package"
        assert dep2.version == ">=1.0.0"
