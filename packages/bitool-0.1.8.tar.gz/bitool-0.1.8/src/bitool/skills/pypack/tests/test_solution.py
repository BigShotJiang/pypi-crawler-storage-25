"""Solution 模型测试."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from ..models import PyProject, PySolution


class TestSolutionCreation:
    """Solution 创建测试."""

    def test_create_solution(self, tmp_path: Path) -> None:
        """测试创建 Solution."""
        solution = PySolution(root_dir=tmp_path, projects={})
        assert solution.root_dir == tmp_path
        assert solution.projects == {}

    def test_create_solution_with_projects(self, tmp_path: Path) -> None:
        """测试创建带项目的 Solution."""
        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text('[project]\nname = "project1"\nversion = "1.0.0"\n')

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text('[project]\nname = "project2"\nversion = "2.0.0"\n')

        proj1 = PyProject.from_pyproject(pyproject1)
        proj2 = PyProject.from_pyproject(pyproject2)

        assert proj1 is not None
        assert proj2 is not None

        projects = {"project1": proj1, "project2": proj2}
        solution = PySolution(root_dir=tmp_path, projects=projects)

        assert len(solution.projects) == 2
        assert "project1" in solution.projects
        assert "project2" in solution.projects


class TestProjectEntryFile:
    """项目入口文件检测测试."""

    def test_entry_file_detected(self, tmp_path: Path) -> None:
        """测试检测到入口文件."""
        # 创建项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "myproject"\nversion = "1.0.0"\n')

        # 创建入口文件
        main_file = project_dir / "main.py"
        main_file.write_text(
            'def main():\n    print("Hello")\n\nif __name__ == "__main__":\n    main()\n'
        )

        proj = PyProject.from_pyproject(pyproject)
        assert proj is not None

        # 测试 entry_file 属性
        assert proj.entry_file is not None
        assert proj.entry_file.source_file == main_file

        # 测试 entry_file_stem 属性
        assert proj.entry_file_stem == "main"

    def test_entry_file_not_found(self, tmp_path: Path) -> None:
        """测试未找到入口文件时返回默认值."""
        # 创建项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "myproject"\nversion = "1.0.0"\n')

        # 不创建任何 Python 文件

        proj = PyProject.from_pyproject(pyproject)
        assert proj is not None

        # 测试 entry_file 属性
        assert proj.entry_file is None

        # 测试 entry_file_stem 属性 (应该返回默认值)
        assert proj.entry_file_stem == "main"

    def test_entry_file_with_cli_pattern(self, tmp_path: Path) -> None:
        """测试检测包含 cli 入口的文件."""

        # 创建项目
        project_dir = tmp_path / "myproject"
        project_dir.mkdir()
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "myproject"\nversion = "1.0.0"\n')

        # 创建入口文件 (使用 def main( 模式)
        cli_file = project_dir / "cli.py"
        cli_file.write_text('def main(argv=None):\n    print("CLI")\n')

        proj = PyProject.from_pyproject(pyproject)
        assert proj is not None

        # 测试 entry_file 属性
        assert proj.entry_file is not None
        assert proj.entry_file.source_file == cli_file
        assert proj.entry_file_stem == "cli"


class TestSolutionRepr:
    """Solution 字符串表示测试."""

    def test_solution_repr(self, tmp_path: Path) -> None:
        """测试 Solution 的 repr 表示."""
        solution = PySolution(root_dir=tmp_path, projects={})
        repr_str = repr(solution)
        assert "<Solution(" in repr_str
        assert f"root_dir={tmp_path!r}" in repr_str
        # 当 projects 为空时，显示 "projects:\n\t - " 后面没有内容
        assert "projects:" in repr_str
        assert "time_used=" in repr_str


class TestSolutionElapsedTime:
    """Solution 耗时测试."""

    def test_elapsed_time(self, tmp_path: Path) -> None:
        """测试耗时计算."""
        start = time.perf_counter()
        solution = PySolution(root_dir=tmp_path, projects={}, start_time=start)
        elapsed = solution.elapsed_time
        assert elapsed >= 0
        assert isinstance(elapsed, float)


class TestSolutionDependencies:
    """Solution 依赖项测试."""

    def test_dependencies_empty(self, tmp_path: Path) -> None:
        """测试空项目的依赖项."""
        solution = PySolution(root_dir=tmp_path, projects={})
        assert solution.dependencies == set()

    def test_dependencies_from_projects(self, tmp_path: Path) -> None:
        """测试从项目收集依赖项."""

        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text(
            '[project]\nname = "project1"\ndependencies = ["requests", "click"]\n'
        )

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text(
            '[project]\nname = "project2"\ndependencies = ["flask", "requests"]\n'
        )

        proj1 = PyProject.from_pyproject(pyproject1)
        proj2 = PyProject.from_pyproject(pyproject2)

        assert proj1 is not None
        assert proj2 is not None

        solution = PySolution(
            root_dir=tmp_path, projects={"project1": proj1, "project2": proj2}
        )

        # 应该包含所有依赖项（去重）
        assert solution.dependencies == {"requests", "click", "flask"}


class TestSolutionFromDirectory:
    """Solution.from_directory 测试."""

    def test_scan_single_project(self, tmp_path: Path) -> None:
        """测试扫描单个项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "single-project"\nversion = "1.0.0"\n')

        solution = PySolution.from_directory(tmp_path)
        assert len(solution.projects) == 1
        assert "single-project" in solution.projects

    def test_scan_multiple_projects(self, tmp_path: Path) -> None:
        """测试扫描多个项目."""
        # 创建项目 1
        proj1_dir = tmp_path / "project1"
        proj1_dir.mkdir()
        pyproject1 = proj1_dir / "pyproject.toml"
        pyproject1.write_text('[project]\nname = "project1"\nversion = "1.0.0"\n')

        # 创建项目 2
        proj2_dir = tmp_path / "project2"
        proj2_dir.mkdir()
        pyproject2 = proj2_dir / "pyproject.toml"
        pyproject2.write_text('[project]\nname = "project2"\nversion = "2.0.0"\n')

        solution = PySolution.from_directory(tmp_path)
        assert len(solution.projects) == 2
        assert "project1" in solution.projects
        assert "project2" in solution.projects

    def test_scan_nested_projects(self, tmp_path: Path) -> None:
        """测试扫描嵌套项目."""
        # 根项目
        root_pyproject = tmp_path / "pyproject.toml"
        root_pyproject.write_text(
            '[project]\nname = "root-project"\nversion = "1.0.0"\n'
        )

        # 子项目
        sub_dir = tmp_path / "subproject"
        sub_dir.mkdir()
        sub_pyproject = sub_dir / "pyproject.toml"
        sub_pyproject.write_text('[project]\nname = "sub-project"\nversion = "0.1.0"\n')

        solution = PySolution.from_directory(tmp_path)
        assert len(solution.projects) == 2
        assert "root-project" in solution.projects
        assert "sub-project" in solution.projects

    def test_scan_excludes_dist_directory(self, tmp_path: Path) -> None:
        """测试排除 dist 目录."""
        dist_dir = tmp_path / "dist" / "project"
        dist_dir.mkdir(parents=True)
        pyproject = dist_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "dist-project"\n')

        solution = PySolution.from_directory(tmp_path)
        assert "dist-project" not in solution.projects

    def test_scan_excludes_build_directory(self, tmp_path: Path) -> None:
        """测试排除 build 目录."""
        build_dir = tmp_path / "build" / "project"
        build_dir.mkdir(parents=True)
        pyproject = build_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "build-project"\n')

        solution = PySolution.from_directory(tmp_path)
        assert "build-project" not in solution.projects

    def test_scan_excludes_git_directory(self, tmp_path: Path) -> None:
        """测试排除 .git 目录."""
        git_dir = tmp_path / ".git" / "project"
        git_dir.mkdir(parents=True)
        pyproject = git_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "git-project"\n')

        solution = PySolution.from_directory(tmp_path)
        assert "git-project" not in solution.projects

    def test_scan_excludes_node_modules(self, tmp_path: Path) -> None:
        """测试排除 node_modules 目录."""
        node_dir = tmp_path / "node_modules" / "package"
        node_dir.mkdir(parents=True)
        pyproject = node_dir / "pyproject.toml"
        pyproject.write_text('[project]\nname = "node-project"\n')

        solution = PySolution.from_directory(tmp_path)
        assert "node-project" not in solution.projects

    @pytest.mark.parametrize(
        "exclude_dir", ["__pycache__", ".pytest_cache", ".benchmarks", ".idea"]
    )
    def test_scan_excludes_other_directories(
        self, tmp_path: Path, exclude_dir: str
    ) -> None:
        """测试排除其他目录."""
        exclude_path = tmp_path / exclude_dir / "project"
        exclude_path.mkdir(parents=True)
        pyproject = exclude_path / "pyproject.toml"
        pyproject.write_text(f'[project]\nname = "{exclude_dir}-project"\n')

        solution = PySolution.from_directory(tmp_path)
        assert f"{exclude_dir}-project" not in solution.projects

    def test_scan_invalid_pyproject(self, tmp_path: Path) -> None:
        """测试扫描无效的 pyproject.toml."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("invalid toml [[[")

        solution = PySolution.from_directory(tmp_path)
        # 不应该抛出异常，应该跳过无效文件
        assert len(solution.projects) == 0

    def test_scan_pyproject_without_name(self, tmp_path: Path) -> None:
        """测试扫描没有 name 的 pyproject.toml."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nversion = "1.0.0"\n')

        solution = PySolution.from_directory(tmp_path)
        assert len(solution.projects) == 0


class TestSolutionFindMatchingProjects:
    """Solution.find_matching_projects 测试."""

    def test_find_exact_match(self, tmp_path: Path) -> None:
        """测试精确匹配."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "my-project"\n')

        solution = PySolution.from_directory(tmp_path)
        matches = solution.find_matching_projects("my-project")
        assert matches == ["my-project"]

    def test_find_partial_match(self, tmp_path: Path) -> None:
        """测试部分匹配."""
        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text('[project]\nname = "my-project-one"\n')

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text('[project]\nname = "my-project-two"\n')

        solution = PySolution.from_directory(tmp_path)
        matches = solution.find_matching_projects("my-project")
        assert len(matches) == 2
        assert "my-project-one" in matches
        assert "my-project-two" in matches

    def test_find_case_insensitive(self, tmp_path: Path) -> None:
        """测试不区分大小写匹配."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "My-Project"\n')

        solution = PySolution.from_directory(tmp_path)
        matches = solution.find_matching_projects("my-project")
        assert matches == ["My-Project"]

    def test_find_no_match(self, tmp_path: Path) -> None:
        """测试无匹配."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-project"\n')

        solution = PySolution.from_directory(tmp_path)
        matches = solution.find_matching_projects("nonexistent")
        assert matches == []

    def test_find_empty_pattern(self, tmp_path: Path) -> None:
        """测试空模式."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-project"\n')

        solution = PySolution.from_directory(tmp_path)
        matches = solution.find_matching_projects("")
        assert matches == []


class TestSolutionResolveProjectName:
    """Solution.resolve_project_name 测试."""

    def test_resolve_exact_match(self, tmp_path: Path) -> None:
        """测试精确匹配解析."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "my-project"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("my-project")
        assert resolved == "my-project"

    def test_resolve_fuzzy_match_single(self, tmp_path: Path) -> None:
        """测试模糊匹配解析（单个结果）."""
        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text('[project]\nname = "my-project-one"\n')

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text('[project]\nname = "other-project"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("my-project")
        assert resolved == "my-project-one"

    def test_resolve_fuzzy_match_multiple_returns_none(self, tmp_path: Path) -> None:
        """测试模糊匹配多个结果返回 None."""
        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text('[project]\nname = "my-project-one"\n')

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text('[project]\nname = "my-project-two"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("my-project")
        assert resolved is None

    def test_resolve_no_match(self, tmp_path: Path) -> None:
        """测试无匹配返回 None."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "test-project"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name("nonexistent")
        assert resolved is None

    def test_resolve_none_auto_select_single(self, tmp_path: Path) -> None:
        """测试传入 None 时自动选择单个项目."""
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text('[project]\nname = "only-project"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name(None)
        assert resolved == "only-project"

    def test_resolve_none_multiple_returns_none(self, tmp_path: Path) -> None:
        """测试传入 None 时有多个项目返回 None."""
        pyproject1 = tmp_path / "project1" / "pyproject.toml"
        pyproject1.parent.mkdir()
        pyproject1.write_text('[project]\nname = "project-one"\n')

        pyproject2 = tmp_path / "project2" / "pyproject.toml"
        pyproject2.parent.mkdir()
        pyproject2.write_text('[project]\nname = "project-two"\n')

        solution = PySolution.from_directory(tmp_path)
        resolved = solution.resolve_project_name(None)
        assert resolved is None
