"""测试 PySourcePacker Skill."""

from __future__ import annotations

import argparse
from pathlib import Path

from bitool.skills.pypack.pysourcepack import PySourcePackCommand, PySourcePackerSkill


class TestPySourcePackerSkill:
    """测试 PySourcePackerSkill 类."""

    def test_skill_name(self) -> None:
        """测试 Skill 名称."""
        skill = PySourcePackerSkill()
        assert skill.name == "pypack-sourcepack"
        assert skill.description == "PyPack 源码打包工具"

    def test_create_scheduler(self, tmp_path: Path) -> None:
        """测试创建调度器."""
        skill = PySourcePackerSkill()

        # 创建模拟参数
        args = argparse.Namespace(rootdir=tmp_path, debug=False)
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 1
        assert scheduler.commands[0].name == "pack_all_projects"


class TestPySourcePackCommand:
    """测试 PySourcePackCommand 类."""

    def test_run_no_projects(self, tmp_path: Path) -> None:
        """测试没有项目时正常运行."""
        cmd = PySourcePackCommand(
            name="test_pack", description="测试打包", root_dir=tmp_path
        )

        result = cmd.run()
        assert result is True

    def test_run_with_project(self, tmp_path: Path) -> None:
        """测试有项目时正常打包."""
        # 创建一个简单的项目
        project_dir = tmp_path / "test_project"
        project_dir.mkdir()

        # 创建 pyproject.toml
        pyproject = project_dir / "pyproject.toml"
        pyproject.write_text(
            """
[project]
name = "test-project"
version = "0.1.0"

[project.scripts]
test-cli = "test_project.main:main"
""",
            encoding="utf-8",
        )

        # 创建简单的 Python 文件
        src_dir = project_dir / "test_project"
        src_dir.mkdir()
        (src_dir / "__init__.py").write_text("", encoding="utf-8")
        (src_dir / "main.py").write_text(
            "def main():\n    print('Hello')\n", encoding="utf-8"
        )

        build_dir = tmp_path / ".pypack"

        cmd = PySourcePackCommand(
            name="test_pack", description="测试打包", root_dir=tmp_path
        )

        result = cmd.run()
        assert result is True

        # 验证打包结果
        packed_dir = build_dir / "src" / "test-project"
        assert packed_dir.exists()
        assert (packed_dir / "test_project" / "main.py").exists()
