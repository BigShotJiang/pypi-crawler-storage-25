from __future__ import annotations

import datetime
import re
import time
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any

from bitool import Constants
from bitool.compat import tomllib
from bitool.core import JsonConfig, logger


class PypackConfig(JsonConfig):
    """Pypack 配置类."""

    DEFAULT_PYTHON_VERSION: str = "3.8.10"
    DEFAULT_DIST_DIR: str = ".pypack"
    DEFAULT_EMBED_DIR: str = "pyruntime"
    DEFAULT_EMBED_CACHE_DIR: str = str(
        Path.home() / ".bitool" / "pypack" / "embed_cache"
    )
    DEFAULT_LIB_CACHE_DIR: str = str(Path.home() / ".bitool" / "pypack" / "lib_cache")

    EXCLUDE_DIR_PATTERNS: frozenset[str] = frozenset(
        (
            "dist",
            ".pypack",
            "build",
            "__pycache__",
            ".git",
            ".pytest_cache",
            ".benchmarks",
            "node_modules",
            ".vscode",
            ".idea",
        )
    )
    IGNORE_PATTERNS: frozenset[str] = frozenset(
        [
            "__pycache__",
            "*.pyc",
            "*.pyo",
            ".git",
            ".pytest_cache",
            ".coverage",
            "*.egg-info",
            "build",
            "*.log",
            ".ruff_cache",
            ".benchmarks",
            ".pypack",
        ]
    )
    PYTHON_VERSION_MAP: dict[str, str] = {  # noqa: RUF012
        "3.8": "3.8.10",
        "3.9": "3.9.13",
        "3.10": "3.10.11",
        "3.11": "3.11.9",
        "3.12": "3.12.6",
        "3.13": "3.13.11",
        "3.14": "3.14.4",
    }
    EMBED_PYTHON_MIRRORS: tuple[str, ...] = (
        "https://mirrors.huaweicloud.com/python/",
        "https://mirrors.tuna.tsinghua.edu.cn/python/"
        "https://mirrors.ustc.edu.cn/python/",
        "https://mirrors.aliyun.com/python/",
        "https://www.python.org/ftp/python/",
    )
    LIB_MIRROR_URLS: dict[str, str] = {  # noqa: RUF012
        "aliyun": "https://mirrors.aliyun.com/pypi/simple/",
        "tsinghua": "https://pypi.tuna.tsinghua.edu.cn/simple/",
        "pypi": "https://pypi.org/simple/",
    }
    DEFAULT_LIB_MIRROR = "aliyun"

    ARCHIVE_FORMATS: set[str] = {"zip", "tar", "gztar", "bztar", "xztar", "7z", "nsis"}  # noqa: RUF012

    DEFAULT_MAX_WORKERS = 4
    TIMEOUT: int = 300


conf = PypackConfig()


class PySolutionMixin:
    """PySolution 初始化混入类.

    封装 solution 的初始化逻辑，避免在各个 Command 类中重复实现。
    子类需要提供 root_dir 和 python_version 属性。
    自动在 __post_init__ 中调用 _ensure_solution()。
    """

    solution: PySolution | None = None
    root_dir: Path
    python_version: str
    offline: bool = False

    def __init_subclass__(cls, **kwargs: object) -> None:
        """自动包装子类的 __post_init__ 方法."""
        super().__init_subclass__(**kwargs)

        # 保存原有的 __post_init__
        original_post_init = getattr(cls, "__post_init__", None)

        def new_post_init(self: object) -> None:
            """包装后的 __post_init__，自动确保 solution 初始化."""
            # 先调用原有的 __post_init__（如果存在）
            if original_post_init is not None:
                original_post_init(self)
            # 然后确保 solution 已初始化
            self._ensure_solution()  # ty:ignore[unresolved-attribute]

        # 替换为新的 __post_init__
        cls.__post_init__ = new_post_init

    def _ensure_solution(self) -> PySolution:
        """确保 solution 已初始化。

        Returns
        -------
        PySolution
            初始化后的 solution 实例

        Raises
        ------
        ValueError
            如果 solution 初始化失败
        """
        if self.solution is None:
            self.solution = PySolution.from_directory(
                self.root_dir,
                python_version=self.python_version,
                offline=getattr(self, "offline", False),
            )
        return self.solution

    @property
    def required_solution(self) -> PySolution:
        """获取必需的 solution 实例。

        Returns
        -------
        PySolution
            solution 实例

        Raises
        ------
        ValueError
            如果 solution 未初始化
        """
        if self.solution is None:
            raise ValueError("PySolution is not initialized")
        return self.solution


@dataclass(frozen=True)
class PySolution:
    """表示目录中的一组 Python 项目, 根据根目录进行扫描.

    Attributes
    ----------
    root_dir : Path
        根目录
    projects : dict[str, PyProject]
        项目字典
    start_time : float
        开始时间
    time_stamp : datetime.datetime
        时间戳
    """

    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = field(default=conf.DEFAULT_PYTHON_VERSION)
    projects: dict[str, PyProject] = field(default_factory=dict)
    start_time: float = field(default_factory=time.perf_counter)
    time_stamp: datetime.datetime = field(default_factory=datetime.datetime.now)
    offline: bool = field(default=False)

    def __repr__(self) -> str:
        """返回解决方案的字符串表示."""
        return (
            f"<Solution(\n"
            f"  root_dir={self.root_dir!r},\n"
            f"  projects:\n\t - "
            + "\n\t - ".join(repr(project) for project in self.projects.values())
            + "\n"
            f"  time_used={self.elapsed_time:.4f}s\n"
            f")>"
        )

    @cached_property
    def dist_dir(self) -> Path:
        """获取 dist 目录.

        Returns
        -------
        Path
            dist 目录
        """
        return self.root_dir / conf.DEFAULT_DIST_DIR

    @cached_property
    def dist_embed_dir(self) -> Path:
        """获取 embed 目录.

        Returns
        -------
        Path
            embed 目录
        """
        return self.dist_dir / conf.DEFAULT_EMBED_DIR

    @cached_property
    def dist_libs_dir(self) -> Path:
        """获取 libs 目录.

        Returns
        -------
        Path
            libs 目录
        """
        return self.dist_dir / "libs"

    @cached_property
    def dist_python_exe_path(self) -> Path:
        """获取嵌入式 Python 可执行文件路径.

        Returns
        -------
        Path
            嵌入式 Python 可执行文件路径
        """
        return (
            self.dist_embed_dir / "python.exe"
            if Constants.IS_WINDOWS
            else self.dist_embed_dir / "python"
        )

    @cached_property
    def dist_python_exe_relpath(self) -> Path:
        """获取嵌入式 Python 可执行文件相对路径.

        Returns
        -------
        Path
            嵌入式 Python 可执行文件相对路径
        """
        return self.dist_python_exe_path.relative_to(self.dist_dir)

    @cached_property
    def dist_loader_dir(self) -> Path:
        """获取加载器目录.

        Returns
        -------
        Path
            加载器目录
        """
        return self.dist_dir

    @cached_property
    def elapsed_time(self) -> float:
        """计算耗时.

        Returns
        -------
        float
            耗时（秒）
        """
        return time.perf_counter() - self.start_time

    @cached_property
    def dependencies(self) -> set[str]:
        """获取所有项目的依赖项.

        Returns
        -------
        set[str]
            依赖项集合
        """
        return {
            dep for project in self.projects.values() for dep in project.dependencies
        }

    @classmethod
    def from_directory(
        cls,
        root_dir: Path,
        python_version: str = conf.DEFAULT_PYTHON_VERSION,
        *,
        offline: bool = False,
    ) -> PySolution:
        """从目录扫描创建 Solution.

        Parameters
        ----------
        root_dir : Path
            根目录

        Returns
        -------
        PySolution
            Solution 实例
        """
        projects: dict[str, PyProject] = cls._scan_projects(root_dir)
        return cls(
            root_dir=root_dir,
            projects=projects,
            python_version=python_version,
            offline=offline,
        )

    @classmethod
    def _scan_projects(cls, root_dir: Path) -> dict[str, PyProject]:
        """扫描目录中的项目.

        Parameters
        ----------
        root_dir : Path
            根目录

        Returns
        -------
        dict[str, PyProject]
            项目字典
        """
        projects: dict[str, PyProject] = {}

        for pyproject_file in root_dir.rglob("pyproject.toml"):
            # 跳过排除的目录
            if any(part in conf.EXCLUDE_DIR_PATTERNS for part in pyproject_file.parts):
                continue

            try:
                project: PyProject | None = cls._parse_pyproject(pyproject_file)
                if project:
                    projects[project.name] = project
            except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as e:
                logger.warning(f"Failed to parse {pyproject_file}: {e}")

        return projects

    @classmethod
    def _parse_pyproject(cls, pyproject_file: Path) -> PyProject | None:
        """解析 pyproject.toml 文件.

        Parameters
        ----------
        pyproject_file : Path
            pyproject.toml 文件路径

        Returns
        -------
        PyProject | None
            Project 实例或 None
        """
        try:
            content: str = pyproject_file.read_text(encoding="utf-8")
            data: dict[str, Any] = tomllib.loads(content)
        except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as e:
            logger.warning(f"Failed to read {pyproject_file}: {e}")
            return None

        project_data: dict[str, Any] = data.get("project", {})
        name: str | None = project_data.get("name")
        version: str = project_data.get("version", "0.0.0")
        description: str = project_data.get("description", "")
        dependencies: list[str] = project_data.get("dependencies", [])

        if not name:
            return None

        return PyProject(
            name=name,
            version=version,
            description=description,
            pyproject_file=pyproject_file,
            dependencies=dependencies,
        )

    def find_matching_projects(self, pattern: str) -> list[str]:
        """查找匹配的项目.

        Parameters
        ----------
        pattern : str
            匹配模式

        Returns
        -------
        list[str]
            匹配的项目名称列表
        """
        if not pattern:
            return []

        lower_pattern = pattern.lower()
        return [name for name in self.projects if lower_pattern in name.lower()]

    def resolve_project_name(self, project_name: str | None) -> str | None:
        """解析项目名称.

        Parameters
        ----------
        project_name : str | None
            项目名称

        Returns
        -------
        str | None
            解析后的项目名称
        """
        if not project_name:
            # 如果只有一个项目，自动选择
            if len(self.projects) == 1:
                return next(iter(self.projects))
            return None

        # 精确匹配
        if project_name in self.projects:
            return project_name

        # 模糊匹配
        matches = self.find_matching_projects(project_name)
        if len(matches) == 1:
            return matches[0]

        return None


@dataclass(frozen=True)
class PyProject:
    """表示一个 Python 项目.

    从 pyproject.toml 解析项目信息.

    Attributes
    ----------
    name : str
        项目名称
    version : str
        项目版本
    description : str
        项目描述
    project_dir : Path
        项目目录
    pyproject_file : Path
        pyproject.toml 文件路径
    dependencies : list[str]
        依赖项列表
    """

    name: str
    version: str
    description: str
    pyproject_file: Path
    dependencies: list[str] = field(default_factory=list)

    @cached_property
    def project_dir(self) -> Path:
        """获取项目目录.

        Returns
        -------
        Path
            项目目录
        """
        if not self.pyproject_file.exists():
            raise FileNotFoundError(
                f"pyproject.toml file not found: {self.pyproject_file}"
            )

        return self.pyproject_file.parent

    @cached_property
    def resolved_name(self) -> str:
        """获取解析后的项目名称.

        Returns
        -------
        str
            项目名称
        """
        return self.name.replace("-", "_")

    @cached_property
    def entry_file(self) -> PyEntryFile | None:
        """获取项目的入口文件.

        自动检测项目目录中包含 main 函数的 Python 文件.
        如果找到多个入口文件, 返回第一个.

        Returns
        -------
        PyEntryFile | None
            入口文件对象, 如果没有找到则返回 None
        """
        entry_files = PyEntryFile.detect_entry_files(
            self.project_dir, self.name, self.project_dir
        )
        return entry_files[0] if entry_files else None

    @cached_property
    def entry_file_stem(self) -> str:
        """获取入口文件名.

        Returns
        -------
        str
            入口文件名, 如果没有找到则返回 'main'
        """
        if self.entry_file:
            return self.entry_file.source_file.stem
        return "main"

    @classmethod
    def from_pyproject(cls, pyproject_file: Path) -> PyProject | None:
        """从 pyproject.toml 文件解析项目信息.

        Parameters
        ----------
        pyproject_file : Path
            pyproject.toml 文件路径

        Returns
        -------
        PyProject | None
            解析成功返回 Project 实例, 否则返回 None
        """
        try:
            content: str = pyproject_file.read_text(encoding="utf-8")
            data: dict[str, Any] = tomllib.loads(content)
        except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError) as exc:
            logger.warning(f"读取 {pyproject_file} 失败: {exc}")
            return None

        project_data: dict[str, Any] = data.get("project", {})
        name: str | None = project_data.get("name")
        if not name:
            return None

        version: str = project_data.get("version", "0.0.0")
        description: str = project_data.get("description", "")
        dependencies: list[str] = project_data.get("dependencies", [])

        return cls(
            name=name,
            version=version,
            description=description,
            pyproject_file=pyproject_file,
            dependencies=dependencies,
        )

    @staticmethod
    def detect_project_name(project_dir: Path) -> str | None:
        """从项目目录中自动检测项目名称.

        Parameters
        ----------
        project_dir : Path
            项目目录路径

        Returns
        -------
        str | None
            项目名称, 如果未找到则返回 None
        """
        pyproject_file: Path = project_dir / "pyproject.toml"
        if not pyproject_file.exists():
            logger.warning(f"未找到 {pyproject_file}, 无法自动解析项目名称")
            return None

        project: PyProject | None = PyProject.from_pyproject(pyproject_file)
        if project:
            logger.info(f"自动检测到项目名称: {project.name}")
            return project.name

        logger.warning(f"{pyproject_file} 中未找到 project.name 字段")
        return None

    def __repr__(self) -> str:
        """返回项目的字符串表示."""
        return f"<Project({self.name}, v{self.version}, {self.dependencies!r})>"

    def __str__(self) -> str:
        """返回项目的简洁字符串表示."""
        return f"{self.name}=={self.version} - {self.description or 'No description'}"

    @cached_property
    def is_gui_project(self) -> bool:
        """判断是否为 GUI 项目.

        Returns
        -------
        bool
            如果是 GUI 项目返回 True
        """
        gui_keywords = {"gui", "desktop", "qt", "pyside", "pyqt"}
        deps_lower = [d.lower() for d in self.dependencies]
        return any(kw in " ".join(deps_lower) for kw in gui_keywords)

    def get_project_info(self) -> dict[str, Any]:
        """获取项目详细信息.

        Returns
        -------
        dict[str, Any]
            项目信息字典
        """
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "project_dir": str(self.project_dir),
            "dependencies": self.dependencies,
            "is_gui": self.is_gui_project,
        }


@dataclass(frozen=True)
class PyEntryFile:
    """表示一个 Python 入口文件.

    Attributes
    ----------
    project_name : str
        项目名称
    source_file : Path
        源文件路径
    project_root : Path | None
        项目根目录
    """

    project_name: str
    source_file: Path
    project_root: Path | None = None

    @property
    def is_entry_source(self) -> bool:
        if not self.source_file.is_file() or self.source_file.suffix != ".py":
            return False

        try:
            content = self.source_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return False
        else:
            return (
                "def main(" in content
                or "if __name__ == '__main__':" in content
                or 'if __name__ == "__main__":' in content
            )

    @property
    def relative_path(self) -> Path | str:
        """获取相对于项目根目录的路径.

        Returns
        -------
        Path | str
            相对路径或者文件名
        """
        if self.project_root:
            return self.source_file.relative_to(self.project_root)

        return self.source_file.name

    @property
    def output_stem(self) -> str:
        """获取输出文件名（不含扩展名）.

        Returns
        -------
        str
            输出文件名
        """
        return self.source_file.stem

    def to_dict(self) -> dict[str, Any]:
        """转换为字典.

        Returns
        -------
        dict[str, Any]
            入口文件的字典表示
        """
        return {
            "project_name": self.project_name,
            "source_file": str(self.source_file),
            "output_stem": self.output_stem,
        }

    def __str__(self) -> str:
        """返回入口文件的字符串表示."""
        return f"{self.project_name}:{self.source_file.name}"

    @staticmethod
    def detect_entry_files(
        project_dir: Path, project_name: str, project_root: Path | None = None
    ) -> list[PyEntryFile]:
        """检测项目目录中的所有入口文件.

        Parameters
        ----------
        project_dir : Path
            要扫描的目录
        project_name : str
            项目名称
        project_root : Path | None
            项目根目录

        Returns
        -------
        list[PyEntryFile]
            检测到的入口文件列表
        """

        entry_files: list[PyEntryFile] = []
        normalized_name = project_name.lower().replace("-", "_")

        for py_file in project_dir.glob("*.py"):
            entry = PyEntryFile(
                project_name=normalized_name,
                source_file=py_file,
                project_root=project_root,
            )
            if entry.is_entry_source:
                entry_files.append(entry)
                logger.info(f"Found entry file: {entry}")

        return entry_files


@dataclass(frozen=True)
class PyDependency:
    """表示一个项目依赖项.

    Attributes
    ----------
    name : str
        依赖项名称
    version : str | None
        版本号约束
    extras : list[str]
        可选的额外依赖
    """

    name: str
    version: str | None = None
    extras: list[str] | None = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        """初始化后处理."""
        if self.extras is None:
            object.__setattr__(self, "extras", [])

    def __str__(self) -> str:
        """返回依赖项的字符串表示."""
        if self.version:
            return f"{self.name}{self.version}"
        return self.name

    def to_dict(self) -> dict[str, Any]:
        """转换为字典.

        Returns
        -------
        dict[str, Any]
            依赖项的字典表示
        """
        return {"name": self.name, "version": self.version, "extras": self.extras}

    @classmethod
    def from_string(cls, dep_str: str) -> PyDependency:
        """从字符串创建依赖项.

        Parameters
        ----------
        dep_str : str
            依赖项字符串,如 "requests>=2.28.0"

        Returns
        -------
        PyDependency
            依赖项实例
        """

        # 匹配包名和版本约束
        match = re.match(r"^([a-zA-Z0-9_.-]+)\s*(.*)?$", dep_str.strip())
        if not match:
            return cls(name=dep_str.strip())

        name = match.group(1)
        version = match.group(2).strip() if match.group(2) else None
        return cls(name=name, version=version)
