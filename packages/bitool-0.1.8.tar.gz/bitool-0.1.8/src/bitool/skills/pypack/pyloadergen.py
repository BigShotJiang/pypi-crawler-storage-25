"""PyPack 加载器生成 Skill.

本模块提供自动生成 C 语言加载器并编译为可执行文件的功能.
加载器用于启动嵌入式 Python 解释器并执行指定的 Python 脚本.

主要功能:
- 根据项目配置生成 C 语言加载器源代码
- 支持 Windows (MSVC/MinGW) 和 Unix/Linux/macOS (GCC/Clang) 平台编译
- 支持控制台 (console) 和图形界面 (GUI) 两种子系统类型
- 自动检测嵌入式 Python 解释器路径
- 自动解析项目名称和脚本路径
- 使用 CommandScheduler 协调源代码生成、编译和脚本文件创建

使用示例:
    命令行使用:
        $ pyloadergen /path/to/project
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
from string import Template

from bitool import Constants
from bitool.cmd import BaseCommand, CommandScheduler, CompileCommand, WriteFileCommand
from bitool.core import logger
from bitool.skills import BaseSkill
from bitool.skills.pypack.models import conf

from .models import PySolutionMixin

# 常量定义
DEFAULT_LOADER_TYPE: str = "console"

# 模板文件路径
_TEMPLATES_DIR = Path(__file__).parent / "templates"
_SCRIPT_TEMPLATE = _TEMPLATES_DIR / "loader_script.ent"
_C_TEMPLATE = (
    _TEMPLATES_DIR / "loader_windows.c"
    if Constants.IS_WINDOWS
    else _TEMPLATES_DIR / "loader_unix.c"
)


@dataclass
class PyLoaderGenSkill(BaseSkill, PySolutionMixin):
    """加载器生成 Skill.

    提供命令行接口, 解析参数并创建加载器生成命令.
    支持自动检测项目名称和嵌入式 Python 解释器.

    Attributes
    ----------
    name : str
        Skill 名称
    description : str
        Skill 描述信息
    """

    name = "pyloadergen"
    description = "PyLoaderGen Skill，用于生成 PyLoader 加载器"

    root_dir: Path = field(default_factory=Path.cwd)
    python_version: str = conf.DEFAULT_PYTHON_VERSION

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument(
            "rootdir", type=Path, nargs="?", default=Path.cwd(), help="项目根目录"
        )
        parser.add_argument(
            "--loader-type",
            choices=["console", "gui"],
            default=DEFAULT_LOADER_TYPE,
            help="加载器类型: console(控制台) 或 gui(图形界面)",
        )
        parser.add_argument("--debug", "-d", action="store_true", help="调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建加载器生成调度器."""
        self.root_dir = args.rootdir

        logger.info(f"项目解析完成: {self.solution!r}")

        if not self.required_solution.projects:
            logger.error("项目中没有找到有效的 Python 项目")
            return CommandScheduler(timeout=conf.TIMEOUT)

        # 创建所有命令并建立依赖关系
        all_commands: list[BaseCommand] = []

        for p in self.required_solution.projects.values():
            resolved_name = p.resolved_name

            # 创建写入脚本文件命令
            write_script_cmd = WriteFileCommand(
                name=f"write_script_{resolved_name}",
                description=f"写入 {resolved_name} 的启动脚本",
                filepath=self.required_solution.dist_loader_dir
                / f"{resolved_name}.ent",
                content=Template(
                    _SCRIPT_TEMPLATE.read_text(encoding="utf-8")
                ).substitute(
                    PROJECT_NAME=resolved_name,
                    ENTRY_FILE=f"{p.entry_file_stem}",
                    QT_CONFIG="",
                ),
            )

            # 创建写入 C 源代码文件命令
            write_c_source_cmd = WriteFileCommand(
                name=f"write_c_source_{resolved_name}",
                description=f"写入 {resolved_name} 的 C 源代码",
                filepath=self.required_solution.dist_loader_dir / f"{resolved_name}.c",
                content=Template(_C_TEMPLATE.read_text(encoding="utf-8")).substitute(
                    PYTHON_EXE=self.required_solution.dist_python_exe_relpath.as_posix(),
                    PROJECT_NAME=resolved_name,
                    SCRIPT_NAME=f"{resolved_name}.ent",
                    SUBSYSTEM="windows" if args.loader_type == "gui" else "console",
                ),
            )

            # 创建编译命令（依赖 C 源代码文件已生成）
            compile_cmd = CompileCommand(
                name=f"compile_{resolved_name}",
                description=f"编译 {resolved_name} 的加载器",
                source_file=self.required_solution.dist_loader_dir
                / f"{resolved_name}.c",
                output_file=self.required_solution.dist_loader_dir
                / f"{resolved_name}.exe"
                if Constants.IS_WINDOWS
                else self.required_solution.dist_loader_dir / f"{resolved_name}",
                loader_type=args.loader_type,
                dependencies=[f"write_c_source_{resolved_name}"],
            )

            # 按依赖顺序添加命令
            all_commands.extend([write_script_cmd, write_c_source_cmd, compile_cmd])

        return CommandScheduler(commands=all_commands, timeout=conf.TIMEOUT)


def main() -> None:
    """主函数入口."""
    PyLoaderGenSkill().run_cli()
