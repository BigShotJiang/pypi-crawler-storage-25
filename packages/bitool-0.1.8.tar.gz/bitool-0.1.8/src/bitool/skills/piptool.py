"""pip 工具模块.

提供 pip 包管理操作的封装,
支持安装、重新安装和下载功能,
支持在线和离线两种模式.
"""

from __future__ import annotations

import argparse
import fnmatch
from typing import Final

from bitool.cmd import CommandScheduler, RunCommand, RunShellCommand
from bitool.core import JsonConfig
from bitool.skills._registry import MultiCommandSkill
from bitool.utils import execute


class PipToolConfig(JsonConfig):
    """pip工具配置类。"""

    TRUSTED_HOST: Final[list[str]] = [
        "--trusted-host",
        "mirrors.aliyun.com",
        "--index-url",
        "http://mirrors.aliyun.com/pypi/simple/",
    ]
    PACKAGE_DIR: Final[str] = "packages"
    REQUIREMENTS_FILE: Final[str] = "requirements.txt"


conf = PipToolConfig()


class PipTool(MultiCommandSkill):
    """pip 工具技能。"""

    name = "piptool"
    description = "pip包管理操作"
    config = conf

    def __init__(self) -> None:
        """初始化pip工具, 注册所有子命令。"""
        super().__init__()
        # 注意: 这些命令需要在运行时根据参数动态创建
        # 因此这里只注册占位符, 实际在 main 中处理
        self.register("i", self._install, "安装包")
        self.register("r", self._reinstall, "重新安装包")
        self.register("d", self._download, "下载包")
        self.register("f", self._freeze, "冻结依赖")
        self.register("u", self._uninstall, "卸载包")
        self.register("up", self._upgrade_pip, "升级pip")

        # 存储运行时参数
        self._pkg_names: list[str] = []
        self._offline: bool = False
        self._use_requirements: bool = False

    def _set_params(
        self,
        pkg_names: list[str],
        *,
        offline: bool = False,
        use_requirements: bool = False,
    ) -> None:
        """设置运行时参数。"""
        self._pkg_names = pkg_names
        self._offline = offline
        self._use_requirements = use_requirements

    def _get_options(self) -> list[str]:
        """获取pip选项。"""
        options: list[str] = (
            ["--no-index", "--find-links", "."]
            if self._offline
            else conf.TRUSTED_HOST.copy()
        )
        if self._use_requirements:
            options.extend(["-r", conf.REQUIREMENTS_FILE])
        else:
            options.extend(self._pkg_names)
        return options

    def _install(self) -> CommandScheduler:
        """安装包。"""
        return CommandScheduler(
            commands=[RunCommand(cmd=["pip", "install", *self._get_options()])]
        )

    def _reinstall(self) -> CommandScheduler:
        """重新安装包。"""
        return CommandScheduler(
            commands=[
                RunCommand(cmd=["pip", "uninstall", "-y", *self._pkg_names]),
                RunCommand(cmd=["pip", "install", *self._get_options()]),
            ]
        )

    def _download(self) -> CommandScheduler:
        """下载包。"""
        return CommandScheduler(
            commands=[
                RunCommand(
                    cmd=[
                        "pip",
                        "download",
                        *self._get_options(),
                        "-d",
                        conf.PACKAGE_DIR,
                    ]
                )
            ]
        )

    def _freeze(self) -> CommandScheduler:
        """冻结依赖。"""
        return CommandScheduler(
            commands=[
                RunShellCommand(
                    shell_cmd=f"pip freeze --exclude-editable > {conf.REQUIREMENTS_FILE}"
                )
            ]
        )

    def _get_installed_packages(self) -> list[str]:
        """获取当前环境中所有已安装的包名。

        Returns
        -------
        list[str]
            已安装的包名列表
        """
        import subprocess

        try:
            result = execute(
                ["pip", "list", "--format=freeze"],
                capture_output=True,
                text=True,
                check=True,
            )
            # 解析 pip list --format=freeze 的输出，格式为: package==version
            packages = []
            for line in result.stdout.strip().split("\n"):
                if line and "==" in line:
                    pkg_name = line.split("==")[0].strip()
                    packages.append(pkg_name)
        except (subprocess.SubprocessError, OSError):
            return []
        else:
            return packages

    def _expand_wildcard_packages(self, pattern: str) -> list[str]:
        """展开通配符模式为实际的包名列表。

        Parameters
        ----------
        pattern : str
            包名模式，可能包含通配符（如 pytola*）

        Returns
        -------
        list[str]
            匹配的已安装包名列表。如果模式不包含通配符，则返回原始模式
        """
        # 检查是否包含通配符
        if not any(char in pattern for char in ["*", "?", "[", "]"]):
            return [pattern]

        # 获取所有已安装的包
        installed_packages = self._get_installed_packages()

        # 使用 fnmatch 进行模式匹配（不区分大小写）
        matched = [
            pkg
            for pkg in installed_packages
            if fnmatch.fnmatchcase(pkg.lower(), pattern.lower())
        ]

        return matched

    def _uninstall(self) -> CommandScheduler:
        """卸载包，支持通配符模式。"""
        # 展开通配符模式为实际的包名列表
        packages_to_uninstall = []
        for pattern in self._pkg_names:
            packages_to_uninstall.extend(self._expand_wildcard_packages(pattern))

        if not packages_to_uninstall:
            # 如果没有匹配的包，返回空调度器（或者可以抛出异常）
            return CommandScheduler(commands=[])

        return CommandScheduler(
            commands=[
                RunCommand(cmd=["pip", "uninstall", "-y", *packages_to_uninstall])
            ]
        )

    def _upgrade_pip(self) -> CommandScheduler:
        """升级pip。"""
        return CommandScheduler(
            commands=[
                RunCommand(cmd=["python", "-m", "pip", "install", "--upgrade", "pip"])
            ]
        )


def main() -> None:
    """主函数，执行pip工具命令。"""
    tool = PipTool()
    parser = argparse.ArgumentParser(description="pip安装工具")
    parser.add_argument("action", choices=tool.list_commands(), help="要执行的操作")
    parser.add_argument("libnames", nargs="*", help="要安装的库名称")
    parser.add_argument("--offline", "-o", action="store_true", help="离线模式")
    parser.add_argument(
        "--requirements", "-r", action="store_true", help="使用requirements文件"
    )
    args = parser.parse_args()

    # 验证参数：使用requirements模式时不需要指定库名
    if args.action in ["i", "r", "d"] and not args.libnames and not args.requirements:
        raise ValueError("请指定要安装的库名称，或使用 --requirements 参数")

    # 设置运行时参数
    tool._set_params(
        args.libnames, offline=args.offline, use_requirements=args.requirements
    )

    scheduler = tool.get_scheduler(args.action)
    if not scheduler:
        raise ValueError(f"无效的操作: {args.action}")

    scheduler.run()
