"""移除文件日期前缀并替换为创建/修改时间.

自动检测文件名的日期前缀,
并根据文件的实际创建或修改时间重命名文件.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import os
import platform
import re
import time
from dataclasses import dataclass
from functools import cached_property, lru_cache
from pathlib import Path
from re import Pattern
from typing import Final

from bitool.cmd import CommandScheduler
from bitool.core import logger
from bitool.skills._base import BaseSkill


class FileDateConfig:
    """filedate 工具配置类."""

    NAME: str = "filedate"
    DETECT_SEPARATORS: str = "-_#.~"
    SEP: str = "_"
    MAX_RETRY: int = 100
    WINDOWS_RESERVED_NAME_LEN: int = 4


conf = FileDateConfig()


def _is_windows_reserved_name(filename: str) -> bool:
    """检查给定文件名是否为 Windows 保留名称.

    Windows 保留名称包括 CON, PRN, AUX, NUL, 以及 COM1-COM9, LPT1-LPT9.
    这些名称在 Windows 系统上不能用作文件或目录名.

    Returns
    -------
        bool: 如果文件名是 Windows 保留名称则返回 True, 否则返回 False.
    """
    if platform.system().lower() != "windows":
        return False

    # 规范化文件名为大写并去除扩展名
    name = Path(filename).stem.upper()

    # 检查基本保留名称
    if name in {"CON", "PRN", "AUX", "NUL"}:
        return True

    # 检查 COM 和 LPT 设备名称 (COM1-COM9, LPT1-LPT9)
    if (name.startswith(("COM", "LPT"))) and len(
        name
    ) == conf.WINDOWS_RESERVED_NAME_LEN:
        try:
            num = int(name[3])
            if 1 <= num <= 9:
                return True
        except ValueError:
            pass

    return False


# 日期检测模式
DATE_PATTERN: Final[Pattern[str]] = re.compile(
    r"(20|19)\d{2}((0[1-9])|(1[012]))((0[1-9])|([12]\d)|(3[01]))"
)


@dataclass(frozen=True)
class SingleFileRenamer:
    """单个文件重命名器."""

    path: Path

    @staticmethod
    def rename(path: Path) -> None:
        """将带日期前缀的文件重命名为创建/修改时间."""
        renamer = SingleFileRenamer(path)

        dest_path = renamer.filepath_renamed
        sequence = 1
        while dest_path.exists() and sequence <= conf.MAX_RETRY:
            logger.warning(f"{dest_path} 已存在, 添加唯一后缀.")
            dest_path = renamer.filepath_renamed.with_name(
                f"{renamer.filestem_renamed}({sequence}){renamer.file_suffix}"
            )
            sequence += 1

        # 如果达到最大重试次数路径仍存在, 则放弃
        if dest_path.exists() and sequence > conf.MAX_RETRY:
            logger.error(f"已达到最大重试次数, 放弃处理 {renamer.path}.")
            return

        try:
            renamer.path.rename(dest_path)
        except (OSError, PermissionError):
            logger.exception("重命名失败: %s -> %s", renamer.path, dest_path)
            raise
        else:
            logger.info("重命名: %s -> %s", renamer.path, dest_path)

    @cached_property
    def file_suffix(self) -> str:
        """获取文件后缀."""
        return self.path.suffix

    @cached_property
    def filepath_renamed(self) -> Path:
        """获取重命名后的文件路径."""
        return self.path.with_name(self.filename_renamed)

    @cached_property
    def filestem_renamed(self) -> str:
        """获取重命名后的文件名主干."""
        # 从文件名字符串中提取主干
        suffix = self.path.suffix
        return (
            self.filename_renamed[: -len(suffix)]
            if suffix and self.filename_renamed.endswith(suffix)
            else self.filename_renamed
        )

    @cached_property
    def filename_renamed(self) -> str:
        """获取重命名后的文件名."""
        return (
            f"{self.time_mark}{conf.SEP}{self.filestem_without_date}{self.path.suffix}"
        )

    @cached_property
    def filestem_without_date(self) -> str:
        """获取去除日期前缀的文件名主干."""

        @lru_cache(maxsize=1024)
        def remove_date_prefix(filestem: str) -> str:
            """从文件名中移除日期前缀.

            Returns
            -------
                str: 移除了日期前缀的文件名.
            """
            if (
                filestem.startswith(".")
                and not filestem[1:].isdigit()
                and len(filestem) > 1
            ) and not re.search(DATE_PATTERN, filestem):
                return ""

            match = re.search(DATE_PATTERN, filestem)
            if not match:
                logger.debug("未检测到日期前缀: %s", filestem)
                return filestem
            b, e = match.start(), match.end()
            if b >= 1 and filestem[b - 1] in conf.DETECT_SEPARATORS:
                filestem = filestem[: b - 1] + filestem[e:]
            elif e < len(filestem) and filestem[e] in conf.DETECT_SEPARATORS:
                filestem = filestem[:b] + filestem[e + 1 :]
            return remove_date_prefix(filestem)

        return remove_date_prefix(self.filestem)

    @cached_property
    def filestem(self) -> str:
        """获取当前文件名主干."""
        return self.path.stem

    @cached_property
    def filestat(self) -> os.stat_result:
        """获取文件 stat 信息."""
        return self.path.stat()

    @cached_property
    def modified_time(self) -> float:
        """获取修改时间."""
        return self.filestat.st_mtime

    @cached_property
    def created_time(self) -> float:
        """获取创建时间."""
        return self.filestat.st_ctime

    @cached_property
    def time_mark(self) -> str:
        """获取时间标记."""
        return time.strftime(
            "%Y%m%d", time.localtime(max((self.modified_time, self.created_time)))
        )


@dataclass(frozen=True)
class MultiFileRenamer:
    """多文件重命名器."""

    paths: list[str]

    @staticmethod
    def rename_files(paths: list[str]) -> None:
        """将带日期前缀的文件重命名为创建/修改时间."""
        renamer = MultiFileRenamer(paths)
        if not renamer.filtered_paths:
            logger.error("没有有效的文件可处理.")
            return

        t0 = time.perf_counter()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            executor.map(SingleFileRenamer.rename, renamer.filtered_paths)
        logger.info("处理完成, 耗时: %.4fs", time.perf_counter() - t0)

    @cached_property
    def converted_paths(self) -> list[Path]:
        """获取转换后的路径列表."""
        return [Path(p) for p in self.paths]

    @cached_property
    def filtered_paths(self) -> list[Path]:
        """获取过滤后的有效路径列表."""
        return [
            p
            for p in self.converted_paths
            if p.exists() and p.is_file() and not _is_windows_reserved_name(p.name)
        ]

    @cached_property
    def missing_paths(self) -> list[Path]:
        """获取缺失的路径列表."""
        return list(set(self.converted_paths) - set(self.filtered_paths))


class FileDateSkill(BaseSkill):
    """文件日期重命名技能."""

    name = "filedate"
    description = "移除文件日期前缀并替换为创建/修改时间"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument("targets", type=str, nargs="+", help="输入文件列表")
        parser.add_argument("--debug", "-d", action="store_true", help="启用调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建文件日期处理调度器."""
        if args.debug:
            import logging

            logger.setLevel(logging.DEBUG)

        MultiFileRenamer.rename_files(args.targets)

        # 返回空调度器（主要工作已在上面完成）
        return CommandScheduler(commands=[])


def main() -> None:
    """主函数入口."""
    FileDateSkill().run_cli()
