"""Skills 工具模块.

本包提供各种实用工具技能,包括:
- 环境配置 (envpy, envrs)
- Git 工具 (gittool)
- 文件处理 (filedate, img2pdf, pdf2img)
- 系统工具 (which, taskkill, clearscreen)
- 包管理 (piptool, pymake)
- Python 打包 (pypack_archive, pypack_libpack, pypack_loader, pysourcepack, pypack_embedpy)
- 其他工具 (bumpversion, filelevel, sshcopyid)

从 v0.2 开始,所有 Skill 都基于 BaseSkill 基类构建,
提供统一的参数解析、错误处理和执行流程.
"""

from ._base import BaseSkill
from ._registry import MultiCommandSkill, SkillRegistry

__all__ = ["BaseSkill", "MultiCommandSkill", "SkillRegistry"]
