"""Skill 基础类模块.

提供统一的 Skill 基类,封装通用的参数解析、配置管理、命令调度等功能,
减少重复代码,提高可维护性.
"""

from __future__ import annotations

import argparse
import sys
from typing import ClassVar

from bitool.cmd import CommandScheduler
from bitool.core import JsonConfig, logger


class BaseSkill:
    """Skill 抽象基类.

    所有 Skill 应该继承此类,实现必要的方法即可获得:
    - 自动的参数解析
    - 统一的错误处理
    - 标准的执行流程
    - 配置管理支持

    Examples
    --------
    >>> class MySkillConfig(BaseSkillConfig):
    ...     DEFAULT_VALUE: str = "hello"
    ...
    >>> class MySkill(BaseSkill):
    ...     name = "myskill"
    ...     description = "我的技能"
    ...     config = MySkillConfig()
    ...
    ...     def add_arguments(self, parser: argparse.ArgumentParser) -> None:
    ...         parser.add_argument("value", nargs="?", default=self.config.DEFAULT_VALUE)
    ...
    ...     def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
    ...         return CommandScheduler(commands=[])
    """

    # 子类必须覆盖的类属性
    name: ClassVar[str] = "unnamed-skill"
    description: ClassVar[str] = ""
    epilog: ClassVar[str] = ""
    config: ClassVar[JsonConfig | None] = None

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数.

        子类必须实现此方法来定义自己的命令行参数.

        Parameters
        ----------
        parser : argparse.ArgumentParser
            参数解析器实例
        """

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建命令调度器.

        子类必须实现此方法,根据解析后的参数创建命令调度器.

        Parameters
        ----------
        args : argparse.Namespace
            解析后的命令行参数

        Returns
        -------
        CommandScheduler
            配置好的命令调度器
        """
        pass

    def create_parser(self) -> argparse.ArgumentParser:
        """创建参数解析器.

        Returns
        -------
        argparse.ArgumentParser
            配置好的参数解析器
        """
        parser = argparse.ArgumentParser(
            prog=self.name,
            description=self.description,
            epilog=self.epilog,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        self.add_arguments(parser)
        return parser

    def parse_args(self, args: list[str] | None = None) -> argparse.Namespace:
        """解析命令行参数.

        Parameters
        ----------
        args : list[str], optional
            参数列表,默认使用 sys.argv[1:]

        Returns
        -------
        argparse.Namespace
            解析后的参数
        """
        parser = self.create_parser()
        return parser.parse_args(args)

    def run(self, args: list[str] | None = None) -> int:
        """运行 Skill.

        统一的执行流程:
        1. 解析参数
        2. 创建调度器
        3. 执行命令
        4. 处理异常

        Parameters
        ----------
        args : list[str], optional
            参数列表,默认使用 sys.argv[1:]

        Returns
        -------
        int
            退出码 (0 表示成功,非 0 表示失败)
        """
        try:
            # 步骤 1: 解析参数
            parsed_args = self.parse_args(args)
            logger.info(f"解析后的参数: {parsed_args}")

            # 步骤 2: 创建调度器
            scheduler = self.create_scheduler(parsed_args)

            # 步骤 3: 执行命令
            success = scheduler.run()
        except KeyboardInterrupt:
            logger.warning("操作已取消")
            return 130
        except SystemExit:
            # 重新抛出 SystemExit 以保留原始退出码
            raise
        except Exception as e:  # noqa: BLE001
            logger.error(f"{self.name} 执行失败: {e}")
            return 1
        else:
            return 0 if success else 1

    def run_cli(self, args: list[str] | None = None) -> None:
        """运行 Skill 并设置退出码.

        这是作为 CLI 工具运行时的入口点.

        Parameters
        ----------
        args : list[str], optional
            参数列表,默认使用 sys.argv[1:]
        """
        exit_code = self.run(args)
        sys.exit(exit_code)

    @classmethod
    def get_config(cls) -> JsonConfig:
        """获取配置实例.

        Returns
        -------
        JsonConfig
            配置实例
        """
        return cls.config if cls.config is not None else JsonConfig()
