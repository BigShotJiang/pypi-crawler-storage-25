"""BumpVersionSkill 类的功能测试.

测试 BumpVersionSkill 类的命令行参数解析、调度器创建和功能集成.
"""

from __future__ import annotations

import argparse
from unittest.mock import Mock, patch

from bitool.cmd import CommandScheduler
from bitool.skills.bumpversion import BumpVersionSkill


def test_bumpversion_skill_init() -> None:
    """测试 BumpVersionSkill 初始化."""
    skill = BumpVersionSkill()
    assert skill.name == "bumpversion"
    assert skill.description == "版本号自动管理工具 (支持语义化版本和多文件格式)"
    assert hasattr(skill, "config")
    assert hasattr(skill.config, "EXCLUDED_DIRS")


def test_bumpversion_skill_add_arguments() -> None:
    """测试命令行参数添加."""
    skill = BumpVersionSkill()
    parser = argparse.ArgumentParser()
    skill.add_arguments(parser)

    # 解析参数
    args = parser.parse_args(["patch"])
    assert args.action == "patch"
    assert args.tag is False
    assert args.commit is False

    # 测试 -t 参数
    args = parser.parse_args(["minor", "-t"])
    assert args.action == "minor"
    assert args.tag is True
    assert args.commit is False

    # 测试 -c 参数
    args = parser.parse_args(["major", "-c"])
    assert args.action == "major"
    assert args.tag is False
    assert args.commit is True

    # 测试 -t 和 -c 参数
    args = parser.parse_args(["patch-alpha", "-t", "-c"])
    assert args.action == "patch-alpha"
    assert args.tag is True
    assert args.commit is True


def test_bumpversion_skill_create_scheduler() -> None:
    """测试调度器创建."""
    skill = BumpVersionSkill()

    # 测试 patch action
    args = argparse.Namespace(action="patch", tag=False, commit=False)
    scheduler = skill.create_scheduler(args)
    assert isinstance(scheduler, CommandScheduler)
    assert len(scheduler.commands) == 1
    assert scheduler.commands[0].part == "patch"
    assert scheduler.commands[0].tag is False
    assert scheduler.commands[0].commit is False

    # 测试 minor action
    args = argparse.Namespace(action="minor", tag=True, commit=False)
    scheduler = skill.create_scheduler(args)
    assert isinstance(scheduler, CommandScheduler)
    assert len(scheduler.commands) == 1
    assert scheduler.commands[0].part == "minor"
    assert scheduler.commands[0].tag is True
    assert scheduler.commands[0].commit is False

    # 测试 major action
    args = argparse.Namespace(action="major", tag=False, commit=True)
    scheduler = skill.create_scheduler(args)
    assert isinstance(scheduler, CommandScheduler)
    assert len(scheduler.commands) == 1
    assert scheduler.commands[0].part == "major"
    assert scheduler.commands[0].tag is False
    assert scheduler.commands[0].commit is True

    # 测试 patch-alpha action
    args = argparse.Namespace(action="patch-alpha", tag=True, commit=True)
    scheduler = skill.create_scheduler(args)
    assert isinstance(scheduler, CommandScheduler)
    assert len(scheduler.commands) == 1
    assert scheduler.commands[0].part == "patch"
    assert scheduler.commands[0].prerelease == "alpha"
    assert scheduler.commands[0].tag is True
    assert scheduler.commands[0].commit is True


def test_bumpversion_skill_create_scheduler_invalid_action() -> None:
    """测试无效 action 的调度器创建."""
    skill = BumpVersionSkill()
    args = argparse.Namespace(action="invalid", tag=False, commit=False)
    scheduler = skill.create_scheduler(args)
    assert isinstance(scheduler, CommandScheduler)
    assert len(scheduler.commands) == 0


def test_bumpversion_skill_epilog_examples() -> None:
    """测试帮助信息中的示例."""
    skill = BumpVersionSkill()
    assert "bumpversion patch" in skill.epilog
    assert "bumpversion minor" in skill.epilog
    assert "bumpversion major" in skill.epilog
    assert "bumpversion patch-alpha" in skill.epilog
    assert "bumpversion patch -t" in skill.epilog
    assert "bumpversion minor -c -t" in skill.epilog


def test_bumpversion_skill_options() -> None:
    """测试支持的操作选项."""
    skill = BumpVersionSkill()
    assert skill.options == ["patch", "minor", "major", "patch-alpha"]


def test_bumpversion_command_creation() -> None:
    """测试 BumpVersionCommand 的创建和参数传递."""
    from bitool.cmd.version import BumpVersionCommand

    # 测试 patch 创建
    cmd = BumpVersionCommand(part="patch")
    assert cmd.part == "patch"
    assert cmd.prerelease is None

    # 测试 minor 创建
    cmd = BumpVersionCommand(part="minor")
    assert cmd.part == "minor"
    assert cmd.prerelease is None

    # 测试 patch-alpha 创建
    cmd = BumpVersionCommand(part="patch", prerelease="alpha")
    assert cmd.part == "patch"
    assert cmd.prerelease == "alpha"


def test_bumpversion_command_run_with_mock() -> None:
    """测试 BumpVersionCommand.run() 方法（使用 mock）."""
    from bitool.cmd.version import BumpVersionCommand

    # 创建命令实例
    cmd = BumpVersionCommand(part="patch", tag=False, commit=False)

    # 使用 mock 替换依赖
    with patch(
        "bitool.cmd.version.BumpProjectVersionCommand"
    ) as mock_bump_cmd_class, patch(
        "bitool.cmd.version.GitTagCommand"
    ) as mock_git_tag_class, patch(
        "bitool.cmd.version.GitCommitCommand"
    ) as mock_git_commit_class:
        # 配置 mock 返回值
        mock_bump_cmd_instance = Mock()
        mock_bump_cmd_instance.run.return_value = True
        mock_bump_cmd_instance.updated_files = []
        mock_bump_cmd_class.return_value = mock_bump_cmd_instance

        # 执行 run 方法
        result = cmd.run()

        # 验证结果
        assert result is True
        mock_bump_cmd_class.assert_called_once()
        mock_git_tag_class.assert_not_called()
        mock_git_commit_class.assert_not_called()


def test_bumpversion_command_run_with_tag_and_commit() -> None:
    """测试 BumpVersionCommand.run() 方法（带 tag 和 commit）."""
    from bitool.cmd.version import BumpVersionCommand

    # 创建命令实例
    cmd = BumpVersionCommand(part="patch", tag=True, commit=True)

    # 使用 mock 替换依赖
    with patch(
        "bitool.cmd.version.BumpProjectVersionCommand"
    ) as mock_bump_cmd_class, patch(
        "bitool.cmd.version.GitTagCommand"
    ) as mock_git_tag_class, patch(
        "bitool.cmd.version.GitCommitCommand"
    ) as mock_git_commit_class, patch(
        "bitool.cmd.version.BumpVersionCommand._read_version_from_file",
        return_value="1.0.1",
    ):
        # 配置 mock 返回值
        mock_bump_cmd_instance = Mock()
        mock_bump_cmd_instance.run.return_value = True
        mock_bump_cmd_instance.updated_files = [Mock()]
        mock_bump_cmd_class.return_value = mock_bump_cmd_instance

        # 执行 run 方法
        result = cmd.run()

        # 验证结果
        assert result is True
        mock_bump_cmd_class.assert_called_once()

        # 验证 Git 命令类被创建
        mock_git_tag_class.assert_called_once()
        mock_git_commit_class.assert_called_once()


def test_bumpversion_config_excluded_dirs() -> None:
    """测试 BumpversionConfig 的排除目录配置."""
    from bitool.skills.bumpversion import BumpversionConfig

    config = BumpversionConfig()
    assert "__pycache__" in config.EXCLUDED_DIRS
    assert ".venv" in config.EXCLUDED_DIRS
    assert ".git" in config.EXCLUDED_DIRS
    assert "dist" in config.EXCLUDED_DIRS
    assert "build" in config.EXCLUDED_DIRS
