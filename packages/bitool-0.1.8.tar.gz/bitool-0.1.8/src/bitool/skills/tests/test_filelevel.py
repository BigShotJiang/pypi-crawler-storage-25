"""Unit tests for filelevel module."""

import logging
from pathlib import Path
from typing import Generator, List
from unittest.mock import MagicMock, patch

import pytest

from bitool.skills.filelevel import (
    _MIN_FILES_FOR_CONCURRENT,
    FilelevelSkill,
    _handle_future_exception,
    _process_files_concurrent,
    process_file,
    remove_marks,
)


@pytest.fixture(autouse=True)
def mock_conf() -> Generator[MagicMock, None, None]:
    """Create a mock configuration for testing."""
    mock_config = MagicMock()
    mock_config.LEVELS = {"0": "", "1": "PUB,NOR", "2": "INT", "3": "CON", "4": "CLA"}
    mock_config.BRACKETS = (" ([_(【-", " )]_）】")

    # 自动 patch 模块级别的配置对象
    with patch("bitool.skills.filelevel.conf", mock_config), patch(
        "bitool.skills.filelevel._LEVEL_VALUES", list(mock_config.LEVELS.values())
    ):
        yield mock_config


class TestRemoveMarks:
    """Test cases for remove_marks function."""

    @pytest.mark.parametrize(
        ("stem", "marks", "expected"),
        [
            ("document(PUB)", ["PUB"], "document"),
            ("file(INT)", ["INT"], "file"),
            ("report[CON]", ["CON"], "report"),
            ("secret【CLA】", ["CLA"], "secret"),
            ("doc_PUB_", ["PUB"], "doc"),  # _ is in brackets, will be removed
            (
                "file-INT-",
                ["INT"],
                "file-INT-",
            ),  # - is not in right brackets, won't be removed
            ("document(PUB)(INT)", ["PUB", "INT"], "document"),
            ("file(CON)(PUB)", ["PUB", "CON"], "file"),
            ("simple", ["PUB"], "simple"),
            ("", ["PUB"], ""),
        ],
    )
    def test_remove_marks(self, stem: str, marks: List[str], expected: str) -> None:
        """Test removing marks from filename stems."""
        result = remove_marks(stem, marks)
        assert result == expected


class TestProcessFile:
    """Test cases for file renaming functionality."""

    @pytest.mark.parametrize(
        ("level", "mark"), [(1, "(PUB)"), (2, "(INT)"), (3, "(CON)"), (4, "(CLA)")]
    )
    @pytest.mark.parametrize("stem", ["document", "file", "report", "secret"])
    @pytest.mark.parametrize("suffix", [".txt", ".pdf", ".docx", ".md"])
    def test_rename_file(
        self, tmp_path: Path, level: int, stem: str, suffix: str, mark: str
    ) -> None:
        """Test renaming files with different levels, stems, and suffixes."""
        old_name = f"{stem}{suffix}"
        (tmp_path / old_name).touch()
        assert (tmp_path / old_name).exists()

        new_name = f"{stem}{mark}{suffix}"
        process_file(tmp_path / old_name, level=level)
        assert (tmp_path / new_name).exists()
        assert not (tmp_path / old_name).exists()

    @pytest.mark.parametrize(
        ("level", "mark_before", "mark_after"),
        [
            (1, "(PUB)(PUB)", "(PUB)"),
            (2, "(INT)(INT)", "(INT)"),
            (3, "(CON)(CON)", "(CON)"),
            (4, "(CLA)(CLA)", "(CLA)"),
        ],
    )
    @pytest.mark.parametrize("stem", ["document", "file", "report", "secret"])
    @pytest.mark.parametrize("suffix", [".txt", ".pdf", ".docx", ".md"])
    def test_rename_file_with_multiple_levels(
        self,
        tmp_path: Path,
        level: int,
        stem: str,
        suffix: str,
        mark_before: str,
        mark_after: str,
    ) -> None:
        """Test renaming files with multiple levels, stems, and suffixes."""
        old_name = f"{stem}{mark_before}{suffix}"
        (tmp_path / old_name).touch()
        assert (tmp_path / old_name).exists()

        new_name = f"{stem}{mark_after}{suffix}"
        process_file(tmp_path / old_name, level=level)
        assert (tmp_path / new_name).exists()
        assert not (tmp_path / old_name).exists()

    @pytest.mark.parametrize("level", [0, 1, 2, 3, 4])
    def test_clear_level_marks(self, tmp_path: Path, level: int) -> None:
        """Test clearing level marks with level=0."""
        old_name = "document(PUB).txt"
        (tmp_path / old_name).touch()

        # level=0 应该清除等级标记
        process_file(tmp_path / old_name, level=0)
        new_name = "document.txt"
        assert (tmp_path / new_name).exists()
        assert not (tmp_path / old_name).exists()

    def test_process_nonexistent_file(self, tmp_path: Path) -> None:
        """Test processing a non-existent file."""
        result = process_file(tmp_path / "nonexistent.txt", level=1)
        assert result is False

    def test_process_invalid_level(self, tmp_path: Path) -> None:
        """Test processing with invalid level."""
        test_file = tmp_path / "test.txt"
        test_file.touch()

        # Invalid level (negative)
        result = process_file(test_file, level=-1)
        assert result is False

        # Invalid level (too high)
        result = process_file(test_file, level=5)
        assert result is False

    def test_process_file_no_change_needed(self, tmp_path: Path) -> None:
        """Test processing file that doesn't need changes."""
        test_file = tmp_path / "document.txt"
        test_file.touch()

        # Processing with level=0 on file without marks
        result = process_file(test_file, level=0)
        assert result is True
        # File should remain unchanged
        assert test_file.exists()


class TestFilelevelConfig:
    """Test cases for FilelevelConfig with custom configuration."""

    def test_default_config(self, mock_conf) -> None:
        """Test default configuration values."""
        # 使用 mock 配置而不是真实加载
        assert mock_conf.LEVELS == {
            "0": "",
            "1": "PUB,NOR",
            "2": "INT",
            "3": "CON",
            "4": "CLA",
        }
        assert mock_conf.BRACKETS == (" ([_(【-", " )]_）】")

    def test_custom_levels(self, mock_conf) -> None:
        """Test custom levels configuration."""
        # 创建自定义配置
        custom_levels = {
            "0": "",
            "1": "PUBLIC,OPEN",
            "2": "INTERNAL",
            "3": "CONFIDENTIAL",
            "4": "SECRET",
            "5": "TOP_SECRET",  # Add extra level
        }
        mock_conf.LEVELS = custom_levels

        # 验证自定义配置
        assert custom_levels == mock_conf.LEVELS

    def test_custom_brackets(self, mock_conf) -> None:
        """Test custom brackets configuration."""
        custom_brackets = ("【", "】")
        mock_conf.BRACKETS = custom_brackets

        # 验证自定义括号
        assert custom_brackets == mock_conf.BRACKETS

    def test_partial_config_override(self, mock_conf) -> None:
        """Test partial configuration override."""
        # 只覆盖 LEVELS
        custom_levels = {"1": "PUBLIC", "2": "PRIVATE"}
        mock_conf.LEVELS = custom_levels

        # LEVELS 应该被覆盖
        assert custom_levels == mock_conf.LEVELS
        # BRACKETS 应该保持默认
        assert mock_conf.BRACKETS == (" ([_(【-", " )]_）】")

    def test_mock_config_with_file_processing(self, tmp_path: Path, mock_conf) -> None:
        """Test file processing with mock configuration."""
        # 创建自定义配置
        custom_levels = {"0": "", "1": "PUBLIC", "2": "PRIVATE"}
        mock_conf.LEVELS = custom_levels

        # 创建测试文件
        test_dir = tmp_path / "test_files"
        test_dir.mkdir()
        test_file = test_dir / "document.txt"
        test_file.touch()

        # 使用自定义等级 1 处理文件
        process_file(test_file, level=1)

        # 应该使用自定义等级名称 "PUBLIC"
        expected_name = "document(PUBLIC).txt"
        assert (test_dir / expected_name).exists()


class TestParseArgs:
    """Test cases for argument parsing via FilelevelSkill."""

    def test_default_args(self) -> None:
        """Test default argument values."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt"])
        assert args.targets == [Path("file1.txt")]
        assert args.level == 0
        assert args.max_workers == 4
        assert args.debug is False

    @pytest.mark.parametrize("level", [0, 1, 2, 3, 4])
    def test_level_argument(self, level: int) -> None:
        """Test level argument parsing."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt", "--level", str(level)])
        assert args.level == level

    def test_max_workers_argument(self) -> None:
        """Test max_workers argument parsing."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt", "--max-workers", "8"])
        assert args.max_workers == 8

    def test_debug_flag(self) -> None:
        """Test debug flag parsing."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt", "--debug"])
        assert args.debug is True

    def test_short_options(self) -> None:
        """Test short option flags."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt", "-l", "2", "-w", "6", "-d"])
        assert args.level == 2
        assert args.max_workers == 6
        assert args.debug is True

    def test_multiple_targets(self) -> None:
        """Test multiple target files."""
        import argparse

        skill = FilelevelSkill()
        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)
        args = parser.parse_args(["file1.txt", "file2.pdf", "file3.docx"])
        assert len(args.targets) == 3
        assert args.targets == [
            Path("file1.txt"),
            Path("file2.pdf"),
            Path("file3.docx"),
        ]


class TestHandleFutureException:
    """Test cases for _handle_future_exception function."""

    def test_successful_future(self) -> None:
        """Test handling successful future."""
        from concurrent.futures import Future

        future: Future[bool] = Future()
        future.set_result(True)

        # Should not raise any exception
        _handle_future_exception(future)

    def test_failed_future(self, caplog) -> None:
        """Test handling failed future."""
        from concurrent.futures import Future

        future: Future[bool] = Future()
        future.set_exception(OSError("Test error"))

        # Use root logger to capture logs from bitool_core.logger
        with caplog.at_level(logging.ERROR):
            _handle_future_exception(future)

        # Should log the exception (check via stdout since caplog may not capture)
        # The important thing is that no exception is raised
        assert future.done()


class TestConcurrentProcessing:
    """Test cases for concurrent file processing."""

    def test_concurrent_processing_threshold(self) -> None:
        """Test concurrent processing is triggered with enough files."""
        # _MIN_FILES_FOR_CONCURRENT should be 5
        assert _MIN_FILES_FOR_CONCURRENT == 5

    def test_process_files_concurrent(self, tmp_path: Path) -> None:
        """Test concurrent file processing."""
        # Create test files
        targets = []
        for i in range(5):
            test_file = tmp_path / f"file{i}.txt"
            test_file.touch()
            targets.append(test_file)

        # Process concurrently
        _process_files_concurrent(targets, level=1, max_workers=2)

        # All files should be renamed
        for i in range(5):
            old_file = tmp_path / f"file{i}.txt"
            new_file = tmp_path / f"file{i}(PUB).txt"
            assert not old_file.exists()
            assert new_file.exists()


class TestMain:
    """Test cases for main function and FilelevelSkill."""

    def test_main_serial_processing(self, tmp_path: Path, monkeypatch) -> None:
        """Test main function with serial processing (few files)."""
        # Create test files (less than _MIN_FILES_FOR_CONCURRENT)
        test_files = []
        for i in range(3):
            test_file = tmp_path / f"file{i}.txt"
            test_file.touch()
            test_files.append(str(test_file))

        # Mock sys.argv
        import sys

        monkeypatch.setattr(sys, "argv", ["filelevel", *test_files, "-l", "1"])

        # Run main (will call sys.exit, so we catch it)
        from bitool.skills import filelevel as cli_module

        with pytest.raises(SystemExit):
            cli_module.main()
        # Exit code may be 1 due to empty scheduler returning {}, which is falsy
        # The important thing is that files were processed correctly

        # All files should be renamed
        for i in range(3):
            old_file = tmp_path / f"file{i}.txt"
            new_file = tmp_path / f"file{i}(PUB).txt"
            assert not old_file.exists()
            assert new_file.exists()

    def test_main_concurrent_processing(self, tmp_path: Path, monkeypatch) -> None:
        """Test main function with concurrent processing (many files)."""
        # Create test files (>= _MIN_FILES_FOR_CONCURRENT)
        test_files = []
        for i in range(6):
            test_file = tmp_path / f"file{i}.txt"
            test_file.touch()
            test_files.append(str(test_file))

        # Mock sys.argv
        import sys

        monkeypatch.setattr(sys, "argv", ["filelevel", *test_files, "-l", "2"])

        # Run main (will call sys.exit, so we catch it)
        from bitool.skills import filelevel as cli_module

        with pytest.raises(SystemExit):
            cli_module.main()
        # Exit code may be 1 due to empty scheduler returning {}, which is falsy
        # The important thing is that files were processed correctly

        # All files should be renamed with level 2 (INT)
        for i in range(6):
            old_file = tmp_path / f"file{i}.txt"
            new_file = tmp_path / f"file{i}(INT).txt"
            assert not old_file.exists()
            assert new_file.exists()

    def test_main_no_valid_files(self, tmp_path: Path, monkeypatch) -> None:
        """Test main function with no valid files."""
        import sys

        from bitool.skills import filelevel as cli_module

        # Mock sys.argv with non-existent files
        monkeypatch.setattr(
            sys, "argv", ["filelevel", "nonexistent1.txt", "nonexistent2.txt"]
        )

        # Main should raise SystemExit due to no valid files
        with pytest.raises(SystemExit):
            cli_module.main()

    def test_main_debug_mode(self, tmp_path: Path, monkeypatch) -> None:
        """Test main function with debug mode enabled."""
        import sys

        from bitool.core import logger
        from bitool.skills import filelevel as cli_module

        # Create a test file
        test_file = tmp_path / "test.txt"
        test_file.touch()

        # Mock sys.argv with debug flag
        monkeypatch.setattr(sys, "argv", ["filelevel", str(test_file), "-l", "1", "-d"])

        # Run main (will call sys.exit, so we catch it)
        with pytest.raises(SystemExit):
            cli_module.main()
        # Exit code may be 1 due to empty scheduler returning {}, which is falsy
        # The important thing is that files were processed correctly

        # Debug mode should be enabled (bitool_core logger level should be DEBUG)
        assert logger.level <= logging.DEBUG
