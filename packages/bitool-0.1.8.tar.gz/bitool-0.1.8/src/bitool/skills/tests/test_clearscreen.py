"""清屏工具的功能测试。

测试 ClearScreenSkill 类的清屏功能。
"""

from __future__ import annotations

import argparse

import pytest

from bitool.cmd import RunCommand
from bitool.core import JsonConfig
from bitool.skills.clearscreen import ClearScreenSkill


@pytest.fixture
def skill() -> ClearScreenSkill:
    """创建 ClearScreenSkill 实例的 fixture。"""
    return ClearScreenSkill()


class TestClearScreenSkill:
    """ClearScreenSkill 测试。"""

    def test_skill_name(self, skill: ClearScreenSkill) -> None:
        """测试技能名称。"""
        assert skill.name == "clearscreen"

    def test_skill_description(self, skill: ClearScreenSkill) -> None:
        """测试技能描述。"""
        assert skill.description == "跨平台控制台清屏工具"

    def test_add_arguments(self, skill: ClearScreenSkill) -> None:
        """测试参数添加（无参数）。"""
        import argparse

        parser = argparse.ArgumentParser()
        skill.add_arguments(parser)

        # 清屏工具不需要参数，解析应该成功
        args = parser.parse_args([])
        assert args is not None

    def test_create_scheduler(self, skill: ClearScreenSkill) -> None:
        """测试调度器创建。"""
        import argparse

        args = argparse.Namespace()
        scheduler = skill.create_scheduler(args)

        assert scheduler is not None
        assert len(scheduler.commands) == 2  # cls/clear + reset_cursor

    def test_scheduler_commands(self, skill: ClearScreenSkill) -> None:
        """测试调度器命令内容。"""

        args = argparse.Namespace()
        scheduler = skill.create_scheduler(args)

        # 第一个命令应该是清屏命令
        first_cmd = scheduler.commands[0]
        assert isinstance(first_cmd, RunCommand)
        assert first_cmd.cmd is not None
        # 使用类型守卫
        cmd = first_cmd.cmd
        if isinstance(cmd, list):
            # cmd 应该是 ["cls"] 或 ["clear"]
            assert len(cmd) == 1
            assert cmd[0] in ["cls", "clear"]

        # 第二个命令应该是 reset_cursor
        second_cmd = scheduler.commands[1]
        assert isinstance(second_cmd, RunCommand)
        assert second_cmd.cmd == skill._reset_cursor

    def test_run_method(self, skill: ClearScreenSkill, mocker) -> None:
        """测试 run 方法（模拟执行）。"""
        spy_reset_cursor = mocker.spy(skill, "_reset_cursor")

        mock_scheduler = mocker.MagicMock()
        mock_scheduler.run.return_value = True
        mocker.patch.object(skill, "create_scheduler", return_value=mock_scheduler)

        exit_code = skill.run([])
        assert exit_code == 0
        assert spy_reset_cursor.call_count == 0

    def test_run_cli_method(
        self, skill: ClearScreenSkill, capsys: pytest.CaptureFixture, mocker
    ) -> None:
        """测试 run_cli 方法。"""
        # Mock scheduler.run() 避免实际执行清屏命令导致卡死
        mock_scheduler = mocker.MagicMock()
        mock_scheduler.run.return_value = True
        mocker.patch.object(skill, "create_scheduler", return_value=mock_scheduler)

        try:
            skill.run_cli([])
        except SystemExit as e:
            assert e.code == 0


class TestResetCursor:
    """reset_cursor 静态方法测试。"""

    def test_reset_cursor_writes_escape_sequence(self, mocker) -> None:
        """测试 reset_cursor 写入正确的转义序列。"""
        mock_stdout = mocker.patch("sys.stdout")

        ClearScreenSkill._reset_cursor()

        mock_stdout.write.assert_called_once_with("\033[H")
        mock_stdout.flush.assert_called_once()

    def test_reset_cursor_is_static(self) -> None:
        """测试 reset_cursor 是静态方法。"""
        # 可以直接通过类调用，无需实例化
        from unittest.mock import patch

        with patch("sys.stdout"):
            ClearScreenSkill._reset_cursor()


class TestPlatformSpecific:
    """平台特定的清屏命令测试。"""

    def test_windows_clear_command(self, mocker) -> None:
        """测试 Windows 平台使用 cls 命令。"""
        mocker.patch("bitool.skills.clearscreen.Constants.IS_WINDOWS", new=True)

        skill = ClearScreenSkill()
        scheduler = skill.create_scheduler(mocker.MagicMock())

        first_cmd = scheduler.commands[0]
        assert isinstance(first_cmd, RunCommand)
        cmd = first_cmd.cmd
        if isinstance(cmd, list):
            assert cmd == ["cls"]

    def test_unix_clear_command(self, mocker) -> None:
        """测试 Unix 平台使用 clear 命令。"""
        mocker.patch("bitool.skills.clearscreen.Constants.IS_WINDOWS", new=False)

        skill = ClearScreenSkill()
        scheduler = skill.create_scheduler(mocker.MagicMock())

        first_cmd = scheduler.commands[0]
        assert isinstance(first_cmd, RunCommand)
        cmd = first_cmd.cmd
        if isinstance(cmd, list):
            assert cmd == ["clear"]


class TestExceptionHandling:
    """异常处理测试。"""

    def test_run_keyboard_interrupt(self, skill: ClearScreenSkill, mocker) -> None:
        """测试 KeyboardInterrupt 异常处理。"""
        mock_scheduler = mocker.MagicMock()
        mock_scheduler.run.side_effect = KeyboardInterrupt()
        mocker.patch.object(skill, "create_scheduler", return_value=mock_scheduler)

        exit_code = skill.run([])
        assert exit_code == 130

    def test_run_general_exception(self, skill: ClearScreenSkill, mocker) -> None:
        """测试一般异常处理。"""
        mock_scheduler = mocker.MagicMock()
        mock_scheduler.run.side_effect = RuntimeError("测试异常")
        mocker.patch.object(skill, "create_scheduler", return_value=mock_scheduler)

        exit_code = skill.run([])
        assert exit_code == 1

    def test_run_scheduler_failure(self, skill: ClearScreenSkill, mocker) -> None:
        """测试调度器执行失败的情况。"""
        mock_scheduler = mocker.MagicMock()
        mock_scheduler.run.return_value = False
        mocker.patch.object(skill, "create_scheduler", return_value=mock_scheduler)

        exit_code = skill.run([])
        assert exit_code == 1


class TestParserAndArgs:
    """参数解析器测试。"""

    def test_create_parser(self, skill: ClearScreenSkill) -> None:
        """测试 create_parser 方法。"""
        parser = skill.create_parser()

        assert parser is not None
        assert parser.prog == "clearscreen"
        assert parser.description == "跨平台控制台清屏工具"

    def test_parse_args_empty(self, skill: ClearScreenSkill) -> None:
        """测试 parse_args 空参数。"""
        args = skill.parse_args([])
        assert args is not None

    def test_parse_args_with_sys_argv(self, skill: ClearScreenSkill, mocker) -> None:
        """测试 parse_args 使用 sys.argv。"""
        mocker.patch("sys.argv", ["clearscreen"])
        args = skill.parse_args()
        assert args is not None


class TestConfig:
    """配置相关测试。"""

    def test_get_config_class_method(self) -> None:
        """测试 get_config 类方法。"""
        config = ClearScreenSkill.get_config()
        assert config is not None
        assert isinstance(config, JsonConfig)

    def test_config_class_attribute(self, skill: ClearScreenSkill) -> None:
        """测试 config 类属性。"""
        assert skill.config is not None
        assert isinstance(skill.config, JsonConfig)


class TestMainFunction:
    """main 函数测试。"""

    def test_main_function(self, mocker) -> None:
        """测试 main 函数入口。"""
        mock_skill = mocker.MagicMock()
        mocker.patch(
            "bitool.skills.clearscreen.ClearScreenSkill", return_value=mock_skill
        )

        from bitool.skills.clearscreen import main

        main()

        mock_skill.run_cli.assert_called_once()
