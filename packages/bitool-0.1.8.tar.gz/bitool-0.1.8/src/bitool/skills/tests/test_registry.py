"""测试 Skill 注册器模块."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from bitool.cmd import CommandScheduler
from bitool.skills._registry import MultiCommandSkill, SkillRegistry


class TestSkillRegistry:
    """测试 SkillRegistry 注册器."""

    def test_register_skill(self) -> None:
        """测试注册技能."""
        registry = SkillRegistry()
        factory = MagicMock(return_value=CommandScheduler(commands=[]))
        registry.register("test", factory, "测试技能")

        assert registry.has("test") is True
        assert registry.get("test") == factory
        assert registry.get_description("test") == "测试技能"

    def test_register_without_description(self) -> None:
        """测试注册技能(无描述)."""
        registry = SkillRegistry()
        factory = MagicMock(return_value=CommandScheduler(commands=[]))
        registry.register("test", factory)

        assert registry.get_description("test") == ""

    def test_get_existing_skill(self) -> None:
        """测试获取已存在的技能."""
        registry = SkillRegistry()
        factory = MagicMock(return_value=CommandScheduler(commands=[]))
        registry.register("test", factory)

        result = registry.get("test")
        assert result == factory

    def test_get_nonexistent_skill(self) -> None:
        """测试获取不存在的技能."""
        registry = SkillRegistry()
        result = registry.get("nonexistent")
        assert result is None

    def test_list_skills(self) -> None:
        """测试列出所有技能."""
        registry = SkillRegistry()
        registry.register("skill1", MagicMock())
        registry.register("skill2", MagicMock())
        registry.register("skill3", MagicMock())

        skills = registry.list_skills()
        assert len(skills) == 3
        assert "skill1" in skills
        assert "skill2" in skills
        assert "skill3" in skills

    def test_list_skills_empty(self) -> None:
        """测试列出空技能列表."""
        registry = SkillRegistry()
        skills = registry.list_skills()
        assert skills == []

    def test_has_existing_skill(self) -> None:
        """测试检查已存在的技能."""
        registry = SkillRegistry()
        registry.register("test", MagicMock())

        assert registry.has("test") is True

    def test_has_nonexistent_skill(self) -> None:
        """测试检查不存在的技能."""
        registry = SkillRegistry()
        assert registry.has("nonexistent") is False

    def test_create_success(self) -> None:
        """测试成功创建技能实例."""
        registry = SkillRegistry()
        scheduler = CommandScheduler(commands=[])
        factory = MagicMock(return_value=scheduler)
        registry.register("test", factory)

        result = registry.create("test")
        assert result == scheduler
        factory.assert_called_once()

    def test_create_with_kwargs(self) -> None:
        """测试带参数创建技能实例."""
        registry = SkillRegistry()
        scheduler = CommandScheduler(commands=[])
        factory = MagicMock(return_value=scheduler)
        registry.register("test", factory)

        result = registry.create("test", arg1="value1", arg2=42)
        assert result == scheduler
        factory.assert_called_once_with(arg1="value1", arg2=42)

    def test_create_nonexistent_skill(self) -> None:
        """测试创建不存在的技能."""
        registry = SkillRegistry()

        with patch("bitool.skills._registry.logger") as mock_logger:
            result = registry.create("nonexistent")
            assert result is None
            mock_logger.error.assert_called_once()
            assert "nonexistent" in mock_logger.error.call_args[0][0]

    def test_create_factory_exception(self) -> None:
        """测试工厂函数异常."""
        registry = SkillRegistry()
        factory = MagicMock(side_effect=Exception("工厂错误"))
        registry.register("test", factory)

        with patch("bitool.skills._registry.logger") as mock_logger:
            result = registry.create("test")
            assert result is None
            mock_logger.error.assert_called_once()
            assert "工厂错误" in mock_logger.error.call_args[0][0]

    @pytest.mark.parametrize(
        ("name", "description"),
        [
            ("git", "Git 工具"),
            ("pip", "Pip 包管理"),
            ("make", "构建工具"),
            ("", "空名称技能"),
        ],
    )
    def test_register_multiple_skills(self, name: str, description: str) -> None:
        """参数化测试注册多个技能."""
        registry = SkillRegistry()
        factory = MagicMock()
        registry.register(name, factory, description)

        assert registry.has(name) is True
        assert registry.get_description(name) == description


class TestMultiCommandSkillIntegration:
    """测试 MultiCommandSkill 集成."""

    def test_multi_command_skill_registration(self) -> None:
        """测试多命令技能注册."""

        class TestMultiSkill(MultiCommandSkill):
            name = "test-multi"
            description = "测试多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("init", self._create_init, "初始化")
                self.register("build", self._create_build, "构建")

            def _create_init(self) -> CommandScheduler:
                return CommandScheduler(commands=[])

            def _create_build(self) -> CommandScheduler:
                return CommandScheduler(commands=[])

        skill = TestMultiSkill()
        assert skill.list_commands() == ["init", "build"]
        assert skill.get_command_description("init") == "初始化"
        assert skill.get_command_description("build") == "构建"

    def test_multi_command_skill_get_scheduler(self) -> None:
        """测试多命令技能获取调度器."""

        class TestMultiSkill(MultiCommandSkill):
            name = "test-multi"
            description = "测试多命令技能"

            def __init__(self) -> None:
                super().__init__()
                self.register("cmd", self._create_cmd, "命令")

            def _create_cmd(self) -> CommandScheduler:
                return CommandScheduler(commands=[])

        skill = TestMultiSkill()
        scheduler = skill.get_scheduler("cmd")
        assert scheduler is not None
        assert isinstance(scheduler, CommandScheduler)

    def test_multi_command_skill_empty(self) -> None:
        """测试空多命令技能."""

        class EmptyMultiSkill(MultiCommandSkill):
            name = "empty"
            description = "空技能"

            def __init__(self) -> None:
                super().__init__()

        skill = EmptyMultiSkill()
        assert skill.list_commands() == []
        assert skill.get_scheduler("any") is None
