"""Skill 工厂和注册器模块.

提供 Skill 注册、查找和批量执行功能,支持多命令 skill 的管理.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from bitool.cmd import CommandScheduler
from bitool.core import logger


@dataclass
class SkillRegistry:
    """Skill 注册器.

    用于注册和管理多个 Skill,支持按名称查找和执行.

    Examples
    --------
    >>> registry = SkillRegistry()
    >>> registry.register("git", create_git_scheduler)
    >>> registry.register("pip", create_pip_scheduler)
    >>> scheduler = registry.get("git")
    """

    _skills: dict[str, Callable[..., CommandScheduler]] = field(default_factory=dict)
    _descriptions: dict[str, str] = field(default_factory=dict)

    def register(
        self, name: str, factory: Callable[..., CommandScheduler], description: str = ""
    ) -> None:
        """注册一个 Skill.

        Parameters
        ----------
        name : str
            Skill 名称
        factory : Callable[..., CommandScheduler]
            Skill 工厂函数
        description : str
            Skill 描述
        """
        self._skills[name] = factory
        self._descriptions[name] = description

        logger.debug(f"已注册 Skill: {name}")

    def get(self, name: str) -> Callable[..., CommandScheduler] | None:
        """获取 Skill 工厂函数.

        Parameters
        ----------
        name : str
            Skill 名称

        Returns
        -------
        Callable[..., CommandScheduler] | None
            Skill 工厂函数,如果不存在则返回 None
        """
        return self._skills.get(name)

    def get_description(self, name: str) -> str:
        """获取 Skill 描述.

        Parameters
        ----------
        name : str
            Skill 名称

        Returns
        -------
        str
            Skill 描述
        """
        return self._descriptions.get(name, "")

    def list_skills(self) -> list[str]:
        """列出所有已注册的 Skill.

        Returns
        -------
        list[str]
            Skill 名称列表
        """
        return list(self._skills.keys())

    def has(self, name: str) -> bool:
        """检查 Skill 是否已注册.

        Parameters
        ----------
        name : str
            Skill 名称

        Returns
        -------
        bool
            如果已注册则返回 True
        """
        return name in self._skills

    def create(self, name: str, **kwargs: object) -> CommandScheduler | None:
        """创建 Skill 实例.

        Parameters
        ----------
        name : str
            Skill 名称
        **kwargs
            传递给工厂函数的参数

        Returns
        -------
        CommandScheduler | None
            创建的调度器,如果 Skill 不存在则返回 None
        """
        factory = self.get(name)
        if factory is None:
            logger.error(f"未找到 Skill: {name}")
            return None

        try:
            return factory(**kwargs)
        except Exception as e:  # noqa: BLE001
            logger.error(f"创建 Skill '{name}' 失败: {e}")
            return None


@dataclass
class MultiCommandSkill:
    """多命令 Skill 基类.

    用于管理包含多个子命令的 Skill(如 git 工具包含 init/add/commit/push 等).

    Examples
    --------
    >>> class GitTool(MultiCommandSkill):
    ...     name = "git"
    ...     description = "Git 工具"
    ...
    ...     def __init__(self):
    ...         super().__init__()
    ...         self.register("init", self._create_init_scheduler, "初始化仓库")
    ...         self.register("add", self._create_add_scheduler, "添加文件")
    ...
    ...     def _create_init_scheduler(self) -> CommandScheduler:
    ...         return CommandScheduler(commands=[])
    ...
    ...     def _create_add_scheduler(self) -> CommandScheduler:
    ...         return CommandScheduler(commands=[])
    """

    name: str = "multi-command-skill"
    description: str = ""

    _registry: SkillRegistry = field(default_factory=SkillRegistry)

    def register(
        self,
        cmd_name: str,
        factory: Callable[..., CommandScheduler],
        description: str = "",
    ) -> None:
        """注册子命令.

        Parameters
        ----------
        cmd_name : str
            子命令名称
        factory : Callable[..., CommandScheduler]
            子命令工厂函数
        description : str
            子命令描述
        """
        self._registry.register(cmd_name, factory, description)

    def get_scheduler(self, cmd_name: str, **kwargs: object) -> CommandScheduler | None:
        """获取子命令调度器.

        Parameters
        ----------
        cmd_name : str
            子命令名称
        **kwargs
            传递给工厂函数的参数

        Returns
        -------
        CommandScheduler | None
            子命令调度器
        """
        return self._registry.create(cmd_name, **kwargs)

    def list_commands(self) -> list[str]:
        """列出所有子命令.

        Returns
        -------
        list[str]
            子命令名称列表
        """
        return self._registry.list_skills()

    def get_command_description(self, cmd_name: str) -> str:
        """获取子命令描述.

        Parameters
        ----------
        cmd_name : str
            子命令名称

        Returns
        -------
        str
            子命令描述
        """
        return self._registry.get_description(cmd_name)
