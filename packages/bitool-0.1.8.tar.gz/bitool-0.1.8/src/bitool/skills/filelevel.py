"""重命名文件等级后缀.

根据文件等级配置自动重命名文件,
支持多种等级标识和括号格式.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import logging
import os
from pathlib import Path
from typing import Final

from bitool.cmd import CommandScheduler
from bitool.core import JsonConfig, logger
from bitool.skills import BaseSkill


class FilelevelConfig(JsonConfig):
    """文件等级配置."""

    LEVELS: Final[dict[str, str]] = {
        "0": "",
        "1": "PUB,NOR",
        "2": "INT",
        "3": "CON",
        "4": "CLA",
    }
    BRACKETS: Final[tuple[str, str]] = (" ([_(【-", " )]_）】")


conf = FilelevelConfig()

_MAX_LEVELS = len(conf.LEVELS)
_MIN_FILES_FOR_CONCURRENT = 5  # 触发并行处理的最小文件数
_LEVEL_VALUES = list(conf.LEVELS.values())
_LEFT_BRACKETS, _RIGHT_BRACKETS = conf.BRACKETS


def remove_marks(stem: str, marks: list[str]) -> str:
    """从文件名主干中移除所有标记.

    Args:
        stem: 文件名主干
        marks: 要移除的标记列表

    Returns:
        str: 移除了标记的文件名主干
    """
    for mark in marks:
        pos = 0
        while True:
            pos = stem.find(mark, pos)
            if pos == -1:
                break
            b, e = pos - 1, pos + len(mark)
            if (
                b >= 0
                and e < len(stem)
                and stem[b] in _LEFT_BRACKETS
                and stem[e] in _RIGHT_BRACKETS
            ):
                stem = stem[:b] + stem[e + 1 :]
            else:
                pos = e
    return stem


def process_file(target: Path, level: int = 0) -> bool:
    """处理单个文件，使用指定等级.

    Args:
        target: 目标文件路径
        level: 文件等级 (0-4), 0 用于清除等级

    Returns:
        bool: 处理成功返回 True，失败返回 False
    """
    try:
        if not (0 <= level < _MAX_LEVELS):
            logger.error("无效的等级 %d, 必须在 0 和 %d 之间", level, _MAX_LEVELS - 1)
            return False

        if not target.exists() or not os.access(target, os.W_OK):
            logger.error("文件不存在或不可写:%s", target)
            return False

        # 处理文件名
        filestem = target.stem
        original_stem = filestem

        # 移除所有等级标记
        for level_names in _LEVEL_VALUES:
            if level_names:
                filestem = remove_marks(filestem, level_names.split(","))

        # 移除数字标记
        for digit in map(str, range(1, 10)):
            filestem = remove_marks(filestem, [digit])

        # 仅在文件名改变或需要添加标记时进行处理
        if filestem != original_stem or level > 0:
            # 添加等级标记
            if level > 0:
                levelstr = conf.LEVELS.get(str(level), "").split(",")[0]
                if levelstr:
                    filestem = f"{filestem}({levelstr})"

            # 重命名文件
            target_path = target.with_name(filestem + target.suffix)
            if target_path != target:
                logger.info("重命名:%s -> %s", target, target_path)
                target.rename(target_path)
    except (OSError, ValueError, RuntimeError):
        logger.exception("处理文件 %s 时出错", target)
        return False
    else:
        return True


def _handle_future_exception(future: concurrent.futures.Future) -> None:
    """安全地获取 Future 结果，捕获并记录异常.

    Args:
        future: 要检查的 Future 对象
    """
    try:
        future.result()
    except (OSError, ValueError, RuntimeError):
        logger.exception("处理文件时出错")


def _process_files_concurrent(
    targets: list[Path], level: int, max_workers: int
) -> None:
    """使用线程池并行处理多个文件.

    Args:
        targets: 目标文件路径列表
        level: 文件等级 (0-4)
        max_workers: 最大工作线程数
    """
    logger.info("对大量文件使用并行处理")
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_file, target, level) for target in targets]
        for future in concurrent.futures.as_completed(futures):
            _handle_future_exception(future)


class FilelevelSkill(BaseSkill):
    """文件等级重命名技能."""

    name = "filelevel"
    description = "重命名文件等级后缀"
    config = conf

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        """添加命令行参数."""
        parser.add_argument("targets", nargs="+", type=Path, help="要处理的目标文件")
        parser.add_argument(
            "--level",
            "-l",
            type=int,
            default=0,
            choices=range(_MAX_LEVELS),
            help=f"文件等级 (0-{_MAX_LEVELS - 1}), 0 用于清除等级 (默认:0)",
        )
        parser.add_argument(
            "--max-workers",
            "-w",
            type=int,
            default=4,
            help="并行处理的最大工作线程数 (默认:4)",
        )
        parser.add_argument("--debug", "-d", action="store_true", help="启用调试模式")

    def create_scheduler(self, args: argparse.Namespace) -> CommandScheduler:
        """创建文件等级处理调度器."""
        if args.debug:
            logger.setLevel(logging.DEBUG)

        if not any(Path(t).exists() for t in args.targets):
            logger.error("在以下文件中未找到有效文件:%s", args.targets)
            raise SystemExit(1)

        if len(args.targets) >= _MIN_FILES_FOR_CONCURRENT:
            _process_files_concurrent(args.targets, args.level, args.max_workers)
        else:
            logger.info("对小量文件使用串行处理")
            for target in args.targets:
                process_file(target, args.level)

        # 返回空调度器（主要工作已在上面完成）
        return CommandScheduler(commands=[])


def main() -> None:
    """主函数入口."""
    FilelevelSkill().run_cli()
