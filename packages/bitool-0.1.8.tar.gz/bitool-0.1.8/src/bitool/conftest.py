import atexit
from pathlib import Path
from typing import Generator

import pytest

from bitool.core import JsonConfig


@pytest.fixture(scope="session", autouse=True)
def disable_atexit_for_tests() -> Generator[None, None, None]:
    """在测试会话期间禁用atexit, 避免测试配置写入用户目录.

    使用monkeypatch拦截atexit.register, 使所有atexit注册变为no-op.
    这是最优雅的解决方案, 无需修改业务代码.
    """

    def _no_op_register(*args: object, **kwargs: object) -> None:
        """替代的atexit.register, 不做任何事情."""
        pass

    # 使用MonkeyPatch.context()管理器, 自动处理替换和恢复
    with pytest.MonkeyPatch.context() as mp:
        mp.setattr(atexit, "register", _no_op_register)
        yield


@pytest.fixture(scope="session")
def temp_config_dir_session(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """创建会话级临时配置目录, 在所有测试间共享.

    适用于不需要隔离配置的只读测试场景.
    """
    return tmp_path_factory.mktemp("bitool_config")


@pytest.fixture(autouse=True)
def temp_config_dir(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Generator[Path, None, None]:
    """创建临时配置目录, 避免 pytest-xdist 多线程写入冲突.

    每个测试工作进程使用独立的临时配置目录, 避免多个进程同时写入
    C:\\Users\\zhou\\.bitool\\filelevel.json 导致的权限错误.

    测试结束后自动清理临时目录, 确保不留任何测试文件.
    """
    monkeypatch.setattr(JsonConfig, "ROOT_DIR", tmp_path)
    yield tmp_path
    # 测试结束后清理临时目录中的所有JSON文件
    import shutil

    if tmp_path.exists():
        shutil.rmtree(tmp_path, ignore_errors=True)
