"""通用注册表 - Pytola 的通用注册系统.

本模块提供了一个灵活的、类型安全的注册表系统,用于管理
类和组件.它支持多个独立的注册表,不依赖于任何特定模块.

使用示例:
    # 创建模块特定的注册表
    my_registry = Registry("my_module")

    # 注册一个类
    my_registry.register("build", BuildClass, aliases=["b"])

    # 或使用装饰器
    @register("my_module", name="build", aliases=["b"])
    class BuildClass:
        pass

    # 获取已注册的类
    cls = my_registry.get("build")
"""

from __future__ import annotations

import threading
from typing import Any, Callable, ClassVar, Generic, TypeVar

from .logger import logger

__all__ = ["DefaultRegistry", "Registry", "get_registry", "register"]

T = TypeVar("T")


MAX_REGISTRY_NAME_LENGTH = 64


def _validate_registration_name(name: str) -> None:
    """验证注册名称.

    Args:
        name: 要验证的名称

    Raises
    ------
        ValueError: 如果名称为空或超过最大长度
    """
    if not name:
        msg = "注册名称不能为空"
        raise ValueError(msg)
    if len(name) > MAX_REGISTRY_NAME_LENGTH:
        msg = f"注册名称 '{name}' 超过最大长度 {MAX_REGISTRY_NAME_LENGTH}"
        raise ValueError(msg)


def _validate_aliases(aliases: list[str]) -> None:
    """验证别名列表.

    Args:
        aliases: 要验证的别名列表

    Raises
    ------
        ValueError: 如果任何别名为空或超过最大长度
    """
    for alias in aliases:
        if not alias:
            msg = "别名不能为空字符串"
            raise ValueError(msg)
        if len(alias) > MAX_REGISTRY_NAME_LENGTH:
            msg = f"别名 '{alias}' 超过最大长度 {MAX_REGISTRY_NAME_LENGTH}"
            raise ValueError(msg)


class Registry(Generic[T]):
    """用于类注册的通用注册表.

    每个注册表实例都是独立的,通过唯一名称标识.
    这允许不同的模块拥有自己独立的注册表,
    同时共享相同的基础实现.

    Attributes
    ----------
        name: 此注册表的唯一标识符

    示例:
        # 为不同模块创建注册表
        command_registry = Registry[BaseCommand]("commands")
        plugin_registry = Registry[PluginBase]("plugins")

        # 在各自注册表中注册项
        command_registry.register("build", BuildCommand)
        plugin_registry.register("logger", LoggerPlugin)
    """

    _registries: ClassVar[dict[str, Registry]] = {}
    _lock: ClassVar[threading.Lock] = threading.Lock()

    def __new__(cls, name: str) -> Registry[T]:
        """获取或创建命名注册表实例.

        Args:
            name: 注册表的唯一标识符

        Returns
        -------
            注册表实例(如果不存在则创建新的)
        """
        with cls._lock:
            if name not in cls._registries:
                instance = super().__new__(cls)
                instance._name = name
                instance._initialized = False

                cls._registries[name] = instance
            return cls._registries[name]

    def __init__(self, name: str) -> None:
        """初始化注册表(如果尚未初始化)."""
        # 注意: _initialized 在 __new__ 中返回实例前已设置
        # 因此我们可以安全地在这里检查.不需要锁,因为:
        # 1. __new__ 在创建实例时持有锁
        # 2. __new__ 在返回前设置 _initialized=False
        # 3. 此方法是幂等的 - 多次调用是安全的
        if getattr(self, "_initialized", False):
            return

        # 此时我们知道 _initialized 是 False
        # 我们需要获取锁以防止竞争条件
        with self._lock:
            # 双重检查模式:另一个线程可能在我们等待锁时已完成初始化
            if getattr(self, "_initialized", False):
                return

            self._name = name
            self._items: dict[str, type[T]] = {}
            self._aliases: dict[str, str] = {}
            self._metadata: dict[str, dict[str, Any]] = {}
            self._initialized = True
            logger.debug(f"Registry '{name}' initialized")

    @property
    def name(self) -> str:
        """获取注册表名称."""
        return self._name

    def register(
        self,
        name: str,
        item_class: type[T],
        aliases: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """注册一个类.

        Args:
            name: 项的标准名称
            item_class: 要注册的类
            aliases: 可选的短名称/别名列表
            metadata: 可选的元数据字典

        Raises
        ------
            ValueError: 如果名称超过最大长度
        """
        # 验证输入
        _validate_registration_name(name)
        if aliases:
            _validate_aliases(aliases)

        # 检查是否已注册
        if name in self._items:
            logger.warning(f"项 '{name}' 已在 '{self._name}' 中注册.将覆盖.")

        # 注册项
        self._items[name] = item_class
        self._metadata[name] = metadata or {}

        # 注册别名
        if aliases:
            self._register_aliases(aliases, name)

        logger.debug(f"Registered item '{name}' in '{self._name}'")

    def _register_aliases(self, aliases: list[str], name: str) -> None:
        """Register aliases for an item.

        Args:
            aliases: List of aliases to register
            name: The canonical name these aliases point to
        """
        for alias in aliases:
            if alias in self._aliases:
                logger.warning(
                    f"Alias '{alias}' is already registered in '{self._name}'. Overwriting."
                )
            self._aliases[alias] = name
            logger.debug(f"Registered alias '{alias}' -> '{name}' in '{self._name}'")

    def unregister(self, name: str) -> None:
        """Unregister an item by name.

        Args:
            name: The canonical name of the item to remove
        """
        if name not in self._items:
            logger.warning(
                f"Attempted to unregister non-existent item '{name}' in '{self._name}'"
            )
            return

        del self._items[name]

        # 移除关联的别名 - 优化的单次遍历
        for alias in list(self._aliases.keys()):
            if self._aliases[alias] == name:
                del self._aliases[alias]

        if name in self._metadata:
            del self._metadata[name]

        logger.info(f"Unregistered item '{name}' from '{self._name}'")

    def get(self, name_or_alias: str) -> type[T] | None:
        """Get a registered class by name or alias.

        Args:
            name_or_alias: The canonical name or alias

        Returns
        -------
            The registered class, or None if not found
        """
        canonical_name = self._aliases.get(name_or_alias, name_or_alias)
        item_class = self._items.get(canonical_name)
        if item_class is None:
            logger.debug(f"Item '{name_or_alias}' not found in registry '{self._name}'")
        return item_class

    def get_instance(
        self, name_or_alias: str, *args: object, **kwargs: object
    ) -> T | None:
        """Get an instance of a registered class.

        Args:
            name_or_alias: The canonical name or alias
            *args: Positional arguments for instantiation
            **kwargs: Keyword arguments for instantiation

        Returns
        -------
            An instance of the class, or None if not found
        """
        item_class = self.get(name_or_alias)
        if item_class is None:
            return None
        return item_class(*args, **kwargs)

    def get_classes(self) -> list[type[T]]:
        """Get a list of all registered classes.

        Returns
        -------
            List of registered classes
        """
        return list(self._items.values())

    def get_metadata(self, name: str) -> dict[str, Any]:
        """Get metadata for a registered item.

        Args:
            name: The canonical name

        Returns
        -------
            Metadata dictionary (empty if not found).
            Includes both standard fields (name, class_name, description, etc.)
            and any custom metadata fields provided during registration.
        """
        return self._metadata.get(name, {}).copy()

    def list_items(self) -> list[str]:
        """List all registered item names.

        Returns
        -------
            List of canonical names
        """
        return list(self._items.keys())

    def list_all(self) -> dict[str, Any]:
        """List all registered items with metadata.

        Returns
        -------
            Dictionary mapping names to metadata dicts.
            Note: The returned dicts include a 'class' key with the actual class object.
        """
        result = {}
        for name, item_class in self._items.items():
            metadata = self._metadata.get(name, {}).copy()
            metadata["class"] = item_class
            metadata["aliases"] = [
                alias for alias, target in self._aliases.items() if target == name
            ]
            result[name] = metadata
        return result

    def clear(self) -> None:
        """Clear all registered items from this registry."""
        self._items.clear()
        self._aliases.clear()
        self._metadata.clear()
        logger.debug(f"Registry '{self._name}' cleared")

    def __len__(self) -> int:
        """Return the number of registered items.

        Returns
        -------
            int: The count of registered items.
        """
        return len(self._items)

    def __contains__(self, name: str) -> bool:
        """Check if an item is registered.

        Args:
            name (str): The item name to check.

        Returns
        -------
            bool: True if item is registered, False otherwise.
        """
        canonical_name = self._aliases.get(name, name)
        return canonical_name in self._items

    @classmethod
    def get_registry(cls, name: str) -> Registry[Any]:
        """Get a registry by name (convenience method).

        Args:
            name: Registry identifier

        Returns
        -------
            The registry instance
        """
        return cls(name)

    @classmethod
    def list_registries(cls) -> list[str]:
        """List all registered registry names.

        Returns
        -------
            List of registry names
        """
        return list(cls._registries.keys())

    @classmethod
    def clear_all(cls) -> None:
        """Clear all registries (useful for testing)."""
        with cls._lock:
            for registry in cls._registries.values():
                registry.clear()
            cls._registries.clear()
            logger.debug("All registries cleared")


class DefaultRegistry(Registry[Any]):
    """Backward-compatible generic registry.

    This class provides backward compatibility for code using the old
    singleton-based GenericRegistry. It wraps Registry("default") to
    ensure all legacy code shares the same registry instance.

    Note: Use Registry[T] directly for new code.
    """

    def __new__(cls) -> Registry:
        """Return the default registry instance."""
        # 快速路径 - 先不加锁检查
        if "default" in Registry._registries:
            return Registry._registries["default"]

        # 慢速路径 - 获取锁并在需要时创建
        with cls._lock:
            # 获取锁后双重检查
            if "default" not in Registry._registries:
                # 直接调用父类的 __new__ 创建,避免锁竞争
                instance: Registry[Any] = object.__new__(Registry)
                instance._name = "default"
                instance._initialized = False
                instance._items = {}
                instance._aliases = {}
                instance._metadata = {}
                instance._initialized = True
                Registry._registries["default"] = instance

        return Registry._registries["default"]

    def __init__(self) -> None:
        """No-op init - the registry is managed by __new__."""

    @classmethod
    def get_default_registry(cls) -> Registry:
        """Get the default registry instance (backward compatibility).

        Returns
        -------
            Registry: The default registry instance.
        """
        return cls()


def register(
    registry_or_name: str | None = None,
    *,
    name: str | None = None,
    aliases: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    description: str = "",
    help_text: str = "",
    **meta_kwargs: Any,  # noqa: ANN401
) -> Callable[[type[T]], type[T]]:
    """Register a class with a registry.

    This decorator supports two calling conventions:

    1. New style (recommended): Specify registry name as first argument
        @register("commands", name="build", aliases=["b"])
        class BuildCommand: ...

    2. Legacy style (backward compatible): Use default registry
        @register(name="build", aliases=["b"], description="...")
        class BuildCommand: ...

    Args:
        registry_or_name: Name of the registry to use (new style),
                         or None for default registry (legacy style)
        name: Canonical name (defaults to class name in lowercase)
        aliases: Optional list of aliases
        metadata: Optional metadata dictionary
        description: Legacy parameter for description
        help_text: Legacy parameter for help text
        **meta_kwargs: Additional metadata as keyword arguments

    Returns
    -------
        Decorator function
    """

    def decorator(cls: type[T]) -> type[T]:
        # 确定注册表名称和项名称
        reg_name = registry_or_name
        item_name = name

        # 处理装饰器在没有注册表名称但以关键字参数调用的旧情况
        # 例如 @register(name="...", aliases=[...])
        if reg_name is None:
            reg_name = "default"
        elif not isinstance(reg_name, str) or " " in reg_name:
            # First arg is not a valid registry name, treat it as item name (legacy)
            item_name = reg_name
            reg_name = "default"

        final_item_name = item_name or cls.__name__.lower()

        reg = Registry(reg_name)

        # Merge metadata - support both new style and legacy style
        final_metadata = (metadata or {}).copy()
        final_metadata.update(meta_kwargs)
        final_metadata.setdefault("name", final_item_name)
        final_metadata.setdefault("class_name", cls.__name__)

        # Support legacy description/help_text parameters
        if description:
            final_metadata.setdefault("description", description)
        if help_text:
            final_metadata.setdefault("help_text", help_text)

        reg.register(
            name=final_item_name,
            item_class=cls,
            aliases=aliases,
            metadata=final_metadata,
        )

        # Store metadata on class for backward compatibility
        cls._registry_metadata = final_metadata  # type: ignore[attr-defined]
        cls._registry_name = reg_name  # type: ignore[attr-defined]
        cls._action_metadata = final_metadata  # type: ignore[attr-defined]  # Legacy compatibility

        logger.debug(f"Decorated and registered '{final_item_name}' in '{reg_name}'")
        return cls

    return decorator


def get_registry(name: str) -> Registry[Any]:
    """Get a registry by name.

    Args:
        name: Registry identifier

    Returns
    -------
        The registry instance

    Example:
        commands = get_registry("commands")
        build_class = commands.get("build")
    """
    return Registry(name)
