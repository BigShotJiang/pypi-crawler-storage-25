"""测试 JsonConfig 基类隔离功能."""

from pathlib import Path

from bitool.core.config import JsonConfig


class TestJsonConfigBaseIsolation:
    """测试 JsonConfig 基类隔离功能."""

    def test_base_class_no_config_file(self, tmp_path: Path) -> None:
        """验证 JsonConfig 基类本身不创建配置文件."""
        # 实例化基类
        conf = JsonConfig()
        assert conf

        # 验证没有创建配置文件
        # 基类的 NAME 为空，不应该创建任何文件
        assert not (tmp_path / ".json").exists()
        assert not (tmp_path / "json.json").exists()

    def test_base_class_no_attrs_loaded(self) -> None:
        """验证 JsonConfig 基类本身不加载任何属性."""
        config = JsonConfig()

        # 基类不应该有任何配置属性
        assert config._attrs == {}
        assert config._file_attrs == {}

    def test_base_class_no_save_operation(self, tmp_path: Path) -> None:
        """验证 JsonConfig 基类本身不进行保存操作."""
        # 修改 ROOT_DIR 到临时目录
        original_root = JsonConfig.ROOT_DIR
        JsonConfig.ROOT_DIR = tmp_path

        try:
            config = JsonConfig()

            # 设置一些属性
            config._attrs["test_key"] = "test_value"

            # 调用保存方法
            config.save_to_json()

            # 验证没有创建任何配置文件
            # 基类不应该保存任何文件
            assert list(tmp_path.glob("*.json")) == []
        finally:
            # 恢复原始 ROOT_DIR
            JsonConfig.ROOT_DIR = original_root

    def test_base_class_no_load_operation(self, tmp_path: Path) -> None:
        """验证 JsonConfig 基类本身不进行加载操作."""
        # 创建一个配置文件
        config_file = tmp_path / "test.json"
        config_file.write_text('{"key": "value"}', encoding="utf-8")

        # 修改 ROOT_DIR 到临时目录
        original_root = JsonConfig.ROOT_DIR
        JsonConfig.ROOT_DIR = tmp_path

        try:
            config = JsonConfig()

            # 基类不应该加载任何配置
            assert config._attrs == {}
            assert config._file_attrs == {}
            assert not hasattr(config, "key")
        finally:
            # 恢复原始 ROOT_DIR
            JsonConfig.ROOT_DIR = original_root

    def test_subclass_still_works(self, tmp_path: Path) -> None:
        """验证子类仍然正常工作."""

        class TestConfig(JsonConfig):
            NAME = "test_isolation"
            ROOT_DIR = tmp_path

        config = TestConfig()

        # 设置配置值
        config.test_key = "test_value"

        # 保存配置
        config.save_to_json()

        # 验证文件已创建
        config_file = tmp_path / "test_isolation.json"
        assert config_file.exists()

        # 验证可以正确读取
        assert config.test_key == "test_value"
