"""JsonConfig 备份、验证和观察者模式测试."""

import json
from decimal import Decimal
from pathlib import Path
from typing import NoReturn

from bitool.core.config import JsonConfig


class TestJsonConfigBackup:
    """测试配置备份功能."""

    def test_backup_creation(self, tmp_path: Path) -> None:
        """测试备份文件创建."""

        class TestConfig(JsonConfig):
            NAME = "backup_test"

        config = TestConfig()
        config.test_key = "test_value"

        # 保存配置
        config.save_to_json()

        # 验证备份文件存在
        backup_file = tmp_path / "backup_test.json.bak"
        assert backup_file.exists()

        # 验证备份内容
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)

        assert backup_data["test_key"] == "test_value"

    def test_restore_from_backup(self, tmp_path: Path) -> None:
        """测试从备份恢复配置."""

        class TestConfig(JsonConfig):
            NAME = "restore_test"

        # 创建初始配置并保存
        config1 = TestConfig()
        config1.original_key = "original_value"
        config1.save_to_json()

        # 创建备份
        config_file = tmp_path / "restore_test.json"
        backup_file = tmp_path / "restore_test.json.bak"

        # 确保备份文件存在且包含正确的内容
        assert backup_file.exists()
        with open(backup_file, encoding="utf-8") as f:
            backup_data = json.load(f)
        assert backup_data.get("original_key") == "original_value"

        # 破坏配置文件
        with open(config_file, "w", encoding="utf-8") as f:
            f.write("invalid json{{{")

        # 重新加载配置（应触发从备份恢复）
        config2 = TestConfig()

        # 验证备份文件中的内容被恢复到 _file_attrs
        assert config2._file_attrs.get("original_key") == "original_value"


class TestJsonConfigValidation:
    """测试序列化验证逻辑."""

    def test_validate_basic_types(self, tmp_path: Path) -> None:
        """测试基本类型的验证."""

        class TestConfig(JsonConfig):
            NAME = "validate_basic"

        config = TestConfig()

        # 测试各种基本类型
        assert config._is_basic_serializable("string") is True
        assert config._is_basic_serializable(123) is True
        assert config._is_basic_serializable(3.14) is True
        assert config._is_basic_serializable(obj=True) is True
        assert config._is_basic_serializable(None) is True
        assert config._is_basic_serializable(Decimal("1.5")) is True
        assert config._is_basic_serializable(complex(1, 2)) is True
        assert config._is_basic_serializable(b"bytes") is True

    def test_validate_deep_nesting(self, tmp_path: Path) -> None:
        """测试深层嵌套验证."""

        class TestConfig(JsonConfig):
            NAME = "deep_nesting"

        config = TestConfig()

        # 创建超过最大深度的嵌套结构
        deep_obj: dict = {}
        current = deep_obj
        for _i in range(60):  # 超过max_depth=50
            current["level"] = {}
            current = current["level"]

        config.deep = deep_obj

        # 验证应该失败（超过最大深度）
        assert config._validate_serializable(deep_obj) is False

    def test_validate_dict_with_non_string_keys(self, tmp_path: Path) -> None:
        """测试包含非字符串键的字典验证."""

        class TestConfig(JsonConfig):
            NAME = "non_string_keys"

        config = TestConfig()

        # 创建包含非字符串键的字典（虽然Python允许，但JSON不支持）
        invalid_dict = {1: "value1", 2: "value2"}

        # 验证应该失败
        assert config._validate_serializable(invalid_dict) is False

    def test_validate_circular_in_list(self, tmp_path: Path) -> None:
        """测试列表中的循环引用验证."""

        class TestConfig(JsonConfig):
            NAME = "circular_list"

        config = TestConfig()

        # 创建列表中的循环引用
        lst: list = []
        lst.append(lst)

        # 验证应该失败（检测到循环引用）
        assert config._validate_serializable(lst) is False

    def test_remove_circular_refs_in_list(self, tmp_path: Path) -> None:
        """测试_remove_circular_refs处理列表循环引用（覆盖行490-499）."""

        class TestConfig(JsonConfig):
            NAME = "circular_list_remove"

        config = TestConfig()

        # 创建列表中的循环引用
        lst: list = []
        lst.append(lst)
        lst.append("value")

        # _remove_circular_refs应该能检测到循环引用并替换为"<circular reference>"
        result = config._remove_circular_refs(lst)
        assert isinstance(result, list)
        assert result[0] == "<circular reference>"
        assert result[1] == "value"

    def test_remove_circular_refs_in_tuple(self, tmp_path: Path) -> None:
        """测试_remove_circular_refs处理元组循环引用（覆盖行490-499）."""

        class TestConfig(JsonConfig):
            NAME = "circular_tuple_remove"

        config = TestConfig()

        # 创建元组包含循环引用（元组中包含列表，列表引用回元组）
        inner_list: list = []
        tpl: tuple = (inner_list, "value")
        inner_list.append(tpl)

        # _remove_circular_refs应该能处理这种情况（覆盖行490-499的元组分支）
        result = config._remove_circular_refs(tpl)
        assert isinstance(result, list)  # 元组会被转换为列表


class TestJsonConfigObserver:
    """测试配置观察者模式."""

    def test_add_remove_observer(self, tmp_path: Path) -> None:
        """测试添加和移除观察者."""

        class TestConfig(JsonConfig):
            NAME = "observer_test"

        config = TestConfig()
        change_log = []

        def observer(key: str, old_value, new_value) -> None:
            change_log.append((key, old_value, new_value))

        # 添加观察者
        config.add_observer(observer)

        # 修改配置
        config.test_key = "test_value"

        # 验证观察者被调用
        assert len(change_log) == 1
        assert change_log[0] == ("test_key", None, "test_value")

        # 移除观察者
        config.remove_observer(observer)

        # 再次修改配置
        config.test_key = "new_value"

        # 验证观察者不再被调用
        assert len(change_log) == 1  # 仍然只有1条记录

    def test_observer_oserror_exception(self, tmp_path: Path) -> None:
        """测试观察者OSError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_oserror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise OSError("Observer OSError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_runtimeerror_exception(self, tmp_path: Path) -> None:
        """测试观察者RuntimeError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_runtimeerror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise RuntimeError("Observer RuntimeError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_valueerror_exception(self, tmp_path: Path) -> None:
        """测试观察者ValueError异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_valueerror"

        config = TestConfig()

        def failing_observer(key, old, new) -> NoReturn:
            raise ValueError("Observer ValueError")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_observer_exception_handling(self, tmp_path: Path) -> None:
        """测试观察者异常处理."""

        class TestConfig(JsonConfig):
            NAME = "observer_exception"

        config = TestConfig()

        # 创建会抛出异常的观察者（保留原有测试兼容性）
        def failing_observer(key, old, new) -> NoReturn:
            raise OSError("Observer failed")

        config.add_observer(failing_observer)

        # 修改配置，观察者失败不应该影响配置设置
        config.test_key = "test_value"

        # 配置值应该被正确设置
        assert config.test_key == "test_value"

    def test_multiple_observers(self, tmp_path: Path) -> None:
        """测试多个观察者."""

        class TestConfig(JsonConfig):
            NAME = "multi_observers"

        config = TestConfig()
        call_order = []

        def observer1(key, old, new) -> None:
            call_order.append(1)

        def observer2(key, old, new) -> None:
            call_order.append(2)

        def observer3(key, old, new) -> None:
            call_order.append(3)

        config.add_observer(observer1)
        config.add_observer(observer2)
        config.add_observer(observer3)

        # 修改配置
        config.test_key = "value"

        # 所有观察者都应该被调用
        assert call_order == [1, 2, 3]

    def test_duplicate_observer(self, tmp_path: Path) -> None:
        """测试添加重复观察者."""

        class TestConfig(JsonConfig):
            NAME = "duplicate_observer"

        config = TestConfig()
        call_count = [0]

        def observer(key, old, new) -> None:
            call_count[0] += 1

        # 添加两次相同的观察者
        config.add_observer(observer)
        config.add_observer(observer)

        # 修改配置
        config.test_key = "value"

        # 观察者应该只被调用一次（去重）
        assert call_count[0] == 1
