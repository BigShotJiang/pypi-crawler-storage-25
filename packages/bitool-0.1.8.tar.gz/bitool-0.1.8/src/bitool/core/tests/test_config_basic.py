"""JsonConfig 基础功能测试 - 系统配置、隔离、加载保存、线程安全."""

import json
import threading
from pathlib import Path

from bitool.consts import Constants
from bitool.core.config import JsonConfig


class TestSystemConfig:
    """测试系统配置属性（已迁移到 Constants）."""

    def test_system_properties(self, tmp_path: Path) -> None:
        """测试系统属性获取（使用 Constants）。"""

        class TestConfig(JsonConfig):
            NAME = "system_test"

        TestConfig()

        # 测试 Constants 中的系统属性
        assert isinstance(Constants.IS_WINDOWS, bool)
        assert isinstance(Constants.IS_UNIX, bool)
        assert isinstance(Constants.EXTENSION, str)

    def test_is_windows(self, tmp_path: Path) -> None:
        """测试 Windows 检测。"""
        import platform

        # 测试 Constants.IS_WINDOWS
        expected = platform.system() == "Windows"
        assert expected == Constants.IS_WINDOWS

    def test_extension(self, tmp_path: Path) -> None:
        """测试扩展名检测。"""
        import platform

        # 测试 Constants.EXTENSION
        expected = ".exe" if platform.system() == "Windows" else ""
        assert expected == Constants.EXTENSION


class TestJsonConfigIsolation:
    """测试配置隔离功能."""

    def test_config_uses_temp_directory(self, tmp_path: Path) -> None:
        """验证配置使用临时目录而非真实目录."""

        # 创建测试子类
        class TestConfig(JsonConfig):
            NAME = "test_isolation"

        # 实例化时应使用被monkeypatch的ROOT_DIR
        config = TestConfig()

        # 保存配置文件路径用于后续验证
        config_file_path = config._config_file

        # 验证配置文件在临时目录中
        expected_path = tmp_path / "test_isolation.json"
        assert config_file_path == expected_path
        assert not expected_path.exists()  # 首次实例化不应创建文件

    def test_multiple_configs_isolated(self, tmp_path: Path) -> None:
        """验证多个配置实例相互隔离."""

        class ConfigA(JsonConfig):
            NAME = "config_a"

        class ConfigB(JsonConfig):
            NAME = "config_b"

        config_a = ConfigA()
        config_b = ConfigB()

        # 设置不同的值
        config_a.test_key = "value_a"
        config_b.test_key = "value_b"

        # 验证隔离
        assert config_a.test_key == "value_a"
        assert config_b.test_key == "value_b"

        # 验证配置文件路径不同
        assert config_a._config_file != config_b._config_file

    def test_attrs_with_private(self, tmp_path: Path) -> None:
        """测试包含私有属性的attrs."""

        class TestConfig(JsonConfig):
            NAME = "private_attrs_test"

        config = TestConfig()
        config.public_key = "public_value"
        # 直接设置到_attrs避免被__setattr__处理（它会跳过_开头的属性）
        config._attrs["_private_key"] = "private_value"

        # attrs不应该包含私有属性（以_开头的键）
        assert "public_key" in config.attrs
        assert "_private_key" not in config.attrs

        # attrs_with_private应该包含私有属性（以_开头的键）
        assert "public_key" in config.attrs_with_private
        assert "_private_key" in config.attrs_with_private
        assert config.attrs_with_private["_private_key"] == "private_value"


class TestJsonConfigLoadSave:
    """测试配置加载和保存功能."""

    def test_load_nonexistent_config(self, tmp_path: Path) -> None:
        """测试加载不存在的配置文件."""

        class TestConfig(JsonConfig):
            NAME = "nonexistent"

        config = TestConfig()
        # 不应该抛出异常，但会包含NAME类属性
        assert "NAME" in config.attrs or config.attrs == {}

    def test_save_and_load_config(self, tmp_path: Path) -> None:
        """测试保存和加载配置."""

        class TestConfig(JsonConfig):
            NAME = "test_save_load"

        config = TestConfig()

        # 设置配置值
        config.string_key = "test_value"
        config.int_key = 42
        config.float_key = 3.14
        config.bool_key = True

        # 保存配置
        config.save_to_json()

        # 验证文件已创建
        config_file = tmp_path / "test_save_load.json"
        assert config_file.exists()

        # 读取并验证内容
        with open(config_file, encoding="utf-8") as f:
            saved_data = json.load(f)

        assert saved_data["string_key"] == "test_value"
        assert saved_data["int_key"] == 42
        assert saved_data["float_key"] == 3.14
        assert saved_data["bool_key"] is True

    def test_load_from_existing_file(self, tmp_path: Path) -> None:
        """测试从现有文件加载配置."""
        # 创建配置文件
        config_file = tmp_path / "test_load.json"
        test_data = {"existing_key": "existing_value", "number": 123}
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump(test_data, f)

        class TestConfig(JsonConfig):
            NAME = "test_load"

        config = TestConfig()

        # 验证加载了文件中的值
        assert config.existing_key == "existing_value"
        assert config.number == 123


class TestJsonConfigThreadSafety:
    """测试配置的线程安全性."""

    def test_concurrent_attribute_access(self, tmp_path: Path) -> None:
        """测试并发属性访问的线程安全."""

        class TestConfig(JsonConfig):
            NAME = "thread_safety"

        config = TestConfig()
        errors = []

        def write_attributes(thread_id: int) -> None:
            try:
                for i in range(100):
                    setattr(config, f"thread_{thread_id}_key_{i}", f"value_{i}")
            except Exception as e:  # noqa: BLE001
                errors.append(e)

        # 创建多个线程同时写入
        threads = []
        for i in range(5):
            thread = threading.Thread(target=write_attributes, args=(i,))
            threads.append(thread)
            thread.start()

        # 等待所有线程完成
        for thread in threads:
            thread.join()

        # 验证没有错误
        assert len(errors) == 0

        # 验证所有值都被正确设置
        for i in range(5):
            for j in range(100):
                key = f"thread_{i}_key_{j}"
                assert getattr(config, key) == f"value_{j}"
