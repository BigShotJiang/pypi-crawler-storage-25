"""文件IO命令模块.

提供文件读写相关的命令实现和公共文件操作工具.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from bitool.cmd._base import BaseCommand
from bitool.core import logger

__all__ = [
    "BackupFileCommand",
    "CopyFileCommand",
    "DeleteFileCommand",
    "FileTreeCopyCommand",
    "MoveFileCommand",
    "ReadFileCommand",
    "WriteFileCommand",
    "backup_file",
    "ensure_dir_exists",
    "read_file_content",
    "write_file_content",
]


def ensure_dir_exists(filepath: Path) -> bool:
    """确保文件父目录存在.

    参数:
        filepath: 文件路径

    返回:
        目录创建是否成功
    """
    if not filepath.parent.exists():
        try:
            filepath.parent.mkdir(parents=True, exist_ok=True)
            logger.info(msg=f"已创建目录: `{filepath.parent}`")
        except OSError as e:
            logger.error(msg=f"创建目录失败: `{e}`", exc_info=True)
            return False
    return True


def read_file_content(filepath: Path, encoding: str = "utf-8") -> str | None:
    """读取文件内容的公共函数.

    参数:
        filepath: 文件路径
        encoding: 文件编码,默认utf-8

    返回:
        文件内容,失败返回None
    """
    if not filepath.exists():
        logger.warning(msg=f"文件不存在: `{filepath}`")
        return None

    if not filepath.is_file():
        logger.warning(msg=f"路径不是文件: `{filepath}`")
        return None

    try:
        content = filepath.read_text(encoding=encoding)
        logger.info(msg=f"读取`{filepath}` 成功")
    except OSError as e:
        logger.error(msg=f"读取文件时出错: `{e}`", exc_info=True)
        return None
    else:
        return content


def write_file_content(
    filepath: Path,
    content: str,
    *,
    overwrite: bool = True,
    backup: bool = False,
    encoding: str = "utf-8",
) -> bool:
    """写入文件内容的公共函数.

    参数:
        filepath: 文件路径
        content: 文件内容
        overwrite: 是否覆盖已存在的文件
        backup: 写入前是否备份原文件
        encoding: 文件编码,默认utf-8

    返回:
        写入是否成功
    """
    # 确保父目录存在
    if not ensure_dir_exists(filepath):
        return False

    # 处理文件已存在的情况
    if filepath.exists():
        if not overwrite:
            logger.warning(msg=f"文件已存在且不允许覆盖: `{filepath}`")
            return False

        # 如果需要备份,使用辅助函数创建备份文件
        if backup and backup_file(filepath) is None:
            return False

    # 写入文件内容
    try:
        filepath.write_text(data=content, encoding=encoding)
        logger.info(msg=f"写入`{filepath}` 成功")
    except OSError as e:
        logger.error(msg=f"写入文件时出错: `{e}`", exc_info=True)
        return False
    else:
        return True


def backup_file(filepath: Path, backup_path: Path | None = None) -> Path | None:
    """备份文件辅助函数.

    参数:
        filepath: 源文件路径
        backup_path: 备份文件路径,如果为None则自动生成

    返回:
        备份文件路径,如果备份失败则返回None
    """
    # 如果未指定备份路径,自动生成带.bak后缀的路径
    if backup_path is None or str(backup_path) == ".":
        backup_path = filepath.with_suffix(filepath.suffix + ".bak")

    try:
        # 确保备份文件父目录存在
        if not backup_path.parent.exists():
            backup_path.parent.mkdir(parents=True, exist_ok=True)

        shutil.copy2(filepath, backup_path)
        logger.info(msg=f"已备份文件: `{filepath}` -> `{backup_path}`")
    except OSError as e:
        logger.error(msg=f"备份文件时出错: `{e}`", exc_info=True)
        return None
    else:
        return backup_path


@dataclass
class WriteFileCommand(BaseCommand):
    """写入文件命令."""

    name = "write_file"
    description = "写入文件命令"

    filepath: Path = Path()
    content: str = ""
    overwrite: bool = True
    backup: bool = True

    def run(self) -> bool:
        """写入文件."""
        return write_file_content(
            filepath=self.filepath,
            content=self.content,
            overwrite=self.overwrite,
            backup=self.backup,
        )


@dataclass
class ReadFileCommand(BaseCommand):
    """读取文件命令."""

    name = "read_file"
    description = "读取文件命令"

    filepath: Path = Path()
    content: str = ""

    def run(self) -> bool:
        """读取文件内容."""
        result = read_file_content(self.filepath)
        if result is not None:
            self.content = result
            return True
        return False


@dataclass
class BackupFileCommand(BaseCommand):
    """备份文件命令."""

    name = "backup_file"
    description = "备份文件命令"

    filepath: Path = Path()
    backup_path: Path = Path()

    def run(self) -> bool:
        """备份文件."""
        if not self.filepath.exists():
            logger.warning(msg=f"文件不存在: `{self.filepath}`")
            return False

        if not self.filepath.is_file():
            logger.warning(msg=f"路径不是文件: `{self.filepath}`")
            return False

        # 使用辅助函数进行备份
        return backup_file(self.filepath, self.backup_path) is not None


@dataclass
class CopyFileCommand(BaseCommand):
    """复制文件命令."""

    name = "copy_file"
    description = "复制文件命令"

    source: Path = Path()
    destination: Path = Path()
    overwrite: bool = True

    def run(self) -> bool:
        """复制文件."""
        if not self.source.exists():
            logger.warning(msg=f"源文件不存在: `{self.source}`")
            return False

        if not self.source.is_file():
            logger.warning(msg=f"源路径不是文件: `{self.source}`")
            return False

        # 检查目标文件是否已存在
        if self.destination.exists() and not self.overwrite:
            logger.warning(msg=f"目标文件已存在且不允许覆盖: `{self.destination}`")
            return False

        try:
            # 确保目标文件父目录存在
            if not self.destination.parent.exists():
                self.destination.parent.mkdir(parents=True, exist_ok=True)

            shutil.copy2(self.source, self.destination)
            logger.info(msg=f"已复制文件: `{self.source}` -> `{self.destination}`")
        except OSError as e:
            logger.error(msg=f"复制文件时出错: `{e}`", exc_info=True)
            return False
        else:
            return True


@dataclass
class MoveFileCommand(BaseCommand):
    """移动文件命令."""

    name = "move_file"
    description = "移动文件命令"

    source: Path = Path()
    destination: Path = Path()
    overwrite: bool = True

    def run(self) -> bool:
        """移动文件."""
        if not self.source.exists():
            logger.warning(msg=f"源文件不存在: `{self.source}`")
            return False

        if not self.source.is_file():
            logger.warning(msg=f"源路径不是文件: `{self.source}`")
            return False

        # 检查目标文件是否已存在
        if self.destination.exists() and not self.overwrite:
            logger.warning(msg=f"目标文件已存在且不允许覆盖: `{self.destination}`")
            return False

        try:
            # 确保目标文件父目录存在
            if not self.destination.parent.exists():
                self.destination.parent.mkdir(parents=True, exist_ok=True)

            shutil.move(str(self.source), str(self.destination))
            logger.info(msg=f"已移动文件: `{self.source}` -> `{self.destination}`")
        except OSError as e:
            logger.error(msg=f"移动文件时出错: `{e}`", exc_info=True)
            return False
        else:
            return True


@dataclass
class DeleteFileCommand(BaseCommand):
    """删除文件命令."""

    name = "delete_file"
    description = "删除文件命令"

    filepath: Path = Path()
    force: bool = False

    def run(self) -> bool:
        """删除文件."""
        if not self.filepath.exists():
            if self.force:
                logger.info(msg=f"文件不存在, 跳过删除: `{self.filepath}`")
                return True
            else:
                logger.warning(msg=f"文件不存在: `{self.filepath}`")
                return False

        if not self.filepath.is_file():
            logger.warning(msg=f"路径不是文件: `{self.filepath}`")
            return False

        try:
            self.filepath.unlink()
            logger.info(msg=f"已删除文件: `{self.filepath}`")
        except OSError as e:
            logger.error(msg=f"删除文件时出错: `{e}`", exc_info=True)
            return False
        else:
            return True


@dataclass
class FileTreeCopyCommand(BaseCommand):
    """复制目录树命令.

    支持忽略模式、防止递归复制等高级功能.

    Attributes
    ----------
    source : Path
        源目录
    destination : Path
        目标目录
    ignore_patterns : frozenset[str]
        忽略模式集合
    """

    name = "copy_file_tree"
    description = "复制目录树命令"

    source: Path = Path()
    destination: Path = Path()
    ignore_patterns: frozenset[str] = frozenset()

    def run(self) -> bool:
        """复制目录树."""
        if not self.source.exists():
            logger.warning(msg=f"源目录不存在: `{self.source}`")
            return False

        if not self.source.is_dir():
            logger.warning(msg=f"源路径不是目录: `{self.source}`")
            return False

        # 防止递归复制
        try:
            self.destination.relative_to(self.source)
            logger.warning(msg=f"跳过递归目录: `{self.destination}`")
            return False
        except ValueError:
            pass  # 正常情况，destination 不是 source 的子目录

        try:
            # 创建目标目录
            self.destination.mkdir(parents=True, exist_ok=True)

            # 执行复制
            self._copy_tree(self.source, self.destination)
            logger.info(msg=f"已复制目录树: `{self.source}` -> `{self.destination}`")
        except OSError as e:
            logger.error(msg=f"复制目录树时出错: `{e}`", exc_info=True)
            return False
        else:
            return True

    def _copy_tree(self, src: Path, dst: Path) -> None:
        """递归复制目录树.

        Parameters
        ----------
        src : Path
            源目录
        dst : Path
            目标目录
        """
        for item in src.iterdir():
            # 检查是否应该忽略
            if self._should_ignore(item):
                continue

            src_item = src / item.name
            dst_item = dst / item.name

            if item.is_dir():
                dst_item.mkdir(exist_ok=True)
                self._copy_tree(src_item, dst_item)
            else:
                shutil.copy2(src_item, dst_item)

    def _should_ignore(self, path: Path) -> bool:
        """判断是否应该忽略该路径.

        Parameters
        ----------
        path : Path
            路径

        Returns
        -------
        bool
            是否应该忽略
        """
        import fnmatch

        name = path.name

        # 检查是否匹配忽略模式
        return any(fnmatch.fnmatch(name, pattern) for pattern in self.ignore_patterns)
