"""Git命令封装模块.

提供常用的Git操作命令封装, 包括提交、标签、检测等功能.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from bitool.cmd._base import BaseCommand
from bitool.cmd._condition import BuiltinConditions
from bitool.cmd.run import RunCommand
from bitool.core import logger

# Git 条件检查
_GIT_INSTALLED = BuiltinConditions.HAS_APP_INSTALLED("git")
_GIT_IS_REPO = BuiltinConditions.IS_GIT_REPO()


@dataclass
class GitAddCommand(RunCommand):
    """Git add 命令.

    Attributes:
        files: 要添加的文件列表, 默认 None
        all_files: 是否添加所有文件, 默认 False
    """

    name: str = "git-add"
    description: str = "添加文件到 Git 暂存区"
    files: list[Path] | None = None
    all_files: bool = False
    allow_conditions: list = field(default_factory=lambda: [_GIT_INSTALLED])

    def __post_init__(self) -> None:
        """数据类初始化后的处理, 构建 cmd 列表."""
        if self.all_files:
            self.cmd = ["git", "add", "."]
        elif self.files:
            self.cmd = ["git", "add"] + [str(f) for f in self.files]
        else:
            self.cmd = ["git", "add", "."]


@dataclass
class GitCommitCommand(RunCommand):
    """Git commit 命令.

    Attributes:
        message: 提交消息, 默认 "chore: update"
    """

    name: str = "git-commit"
    description: str = "提交 Git 更改"
    message: str = "chore: update"
    allow_conditions: list = field(default_factory=lambda: [_GIT_INSTALLED])

    def __post_init__(self) -> None:
        """数据类初始化后的处理, 构建 cmd 列表."""
        self.cmd = ["git", "commit", "-m", self.message]


@dataclass
class GitTagCommand(RunCommand):
    """Git tag 命令.

    Attributes:
        tag_name: 标签名称
        message: 标签消息, 默认 None (创建轻量标签)
    """

    name: str = "git-tag"
    description: str = "创建 Git 标签"
    tag_name: str = ""
    message: str | None = None
    allow_conditions: list = field(default_factory=lambda: [_GIT_INSTALLED])

    def __post_init__(self) -> None:
        """数据类初始化后的处理, 构建 cmd 列表."""
        if self.message:
            self.cmd = ["git", "tag", "-a", self.tag_name, "-m", self.message]
        else:
            self.cmd = ["git", "tag", self.tag_name]


@dataclass
class GitCheckIsRepoCommand(BaseCommand):
    """检查是否为 Git 仓库的命令."""

    name: str = "git-is-repo"
    description: str = "检查当前目录是否为 Git 仓库"
    allow_conditions: list = field(default_factory=lambda: [_GIT_INSTALLED])

    def run(self) -> bool:
        """执行检查.

        Returns
        -------
        bool
            如果是 Git 仓库返回 True
        """
        # 使用 BuiltinConditions.IS_GIT_REPO() 进行检查
        is_repo_condition = _GIT_IS_REPO
        is_repo = is_repo_condition.func()
        if is_repo:
            logger.info("当前目录是 Git 仓库")
        else:
            logger.warning("当前目录不是 Git 仓库")
        return is_repo
