"""编译命令模块.

提供 C/C++ 源代码编译为可执行文件的命令实现.
"""

from __future__ import annotations

import platform
import subprocess
from dataclasses import dataclass
from pathlib import Path

from bitool.cmd._base import BaseCommand
from bitool.core import logger
from bitool.utils import execute

# 编译超时时间 (秒)
COMPILE_TIMEOUT: int = 30


@dataclass
class CompileCommand(BaseCommand):
    """编译 C 源代码为可执行文件命令.

    支持多平台编译器自动检测:
    - Windows: MSVC (cl) > MinGW (gcc)
    - Unix/Linux/macOS: GCC > Clang

    Attributes
    ----------
    name : str
        命令名称
    description : str
        命令描述信息
    source_file : Path
        C 源代码文件路径
    output_file : Path
        输出可执行文件路径
    loader_type : str
        加载器类型 (console/gui), 影响编译参数
    """

    name: str = "compile"
    description: str = "编译 C 源代码"

    source_file: Path = Path()
    output_file: Path = Path()
    loader_type: str = "console"

    def run(self) -> bool:
        """执行编译.

        Returns
        -------
        bool
            是否编译成功
        """
        if not self.source_file.exists():
            logger.error(f"源代码文件不存在: {self.source_file}")
            return False

        logger.info(f"开始编译: {self.source_file} -> {self.output_file}")

        # 尝试使用平台特定的编译器
        if self._try_platform_compiler():
            logger.info(f"编译成功: {self.output_file}")
            return True

        # 所有编译器都失败
        logger.warning("未找到可用的 C 编译器, 跳过加载器编译")
        if platform.system() == "Windows":
            logger.info("提示: 请安装 MinGW (https://www.mingw-w64.org/) 或 MSVC")
        else:
            logger.info("提示: 请安装 GCC 或 Clang 编译器")
        return False

    def _try_platform_compiler(self) -> bool:
        """尝试使用平台特定的编译器.

        Returns
        -------
        bool
            是否编译成功
        """
        if platform.system() == "Windows":
            # Windows: 优先尝试 MinGW，如果失败再尝试 MSVC
            if self._try_mingw():
                return True
            if self._try_msvc():
                return True
        else:
            # Unix/Linux/macOS: 尝试 GCC 或 Clang
            if self._try_gcc():
                return True
            if self._try_clang():
                return True

        return False

    def _try_msvc(self) -> bool:
        """尝试使用 MSVC 编译.

        Returns
        -------
        bool
            是否编译成功
        """
        try:
            subsystem = (
                "/SUBSYSTEM:WINDOWS"
                if self.loader_type == "gui"
                else "/SUBSYSTEM:CONSOLE"
            )
            cmd = [
                "cl",
                "/nologo",
                "/O2",
                subsystem,
                f"/Fe:{self.output_file}",
                str(self.source_file),
            ]
            result = execute(
                cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT
            )
        except FileNotFoundError:
            # 编译器未安装，静默失败
            return False
        except subprocess.TimeoutExpired:
            # 超时，静默失败
            return False
        except subprocess.SubprocessError as exc:
            logger.debug(f"MSVC 编译异常: {exc}")
            return False
        else:
            return result.returncode == 0

    def _try_mingw(self) -> bool:
        """尝试使用 MinGW 编译.

        Returns
        -------
        bool
            是否编译成功
        """
        try:
            # 构建编译命令，只在 GUI 模式添加 -mwindows
            cmd = ["gcc", "-O2"]
            if self.loader_type == "gui":
                cmd.append("-mwindows")
            cmd.extend(["-o", str(self.output_file), str(self.source_file)])

            result = execute(
                cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT
            )
        except FileNotFoundError:
            # 编译器未安装，静默失败
            return False
        except subprocess.TimeoutExpired:
            # 超时，静默失败
            return False
        except subprocess.SubprocessError as exc:
            logger.debug(f"MinGW 编译异常: {exc}")
            return False
        else:
            return result.returncode == 0

    def _try_gcc(self) -> bool:
        """尝试使用 GCC 编译 (Unix/Linux).

        Returns
        -------
        bool
            是否编译成功
        """
        try:
            cmd = ["gcc", "-O2"]
            if self.loader_type == "gui":
                # GUI 模式需要链接 X11 或其他 GUI 库，这里简单处理
                logger.warning("Unix 系统下 GUI 模式需要额外的 GUI 库支持")
            cmd.extend(["-o", str(self.output_file), str(self.source_file)])

            result = execute(
                cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        except subprocess.SubprocessError as exc:
            logger.debug(f"GCC 编译异常: {exc}")
            return False
        else:
            return result.returncode == 0

    def _try_clang(self) -> bool:
        """尝试使用 Clang 编译 (macOS/Unix).

        Returns
        -------
        bool
            是否编译成功
        """
        try:
            cmd = ["clang", "-O2"]
            if self.loader_type == "gui":
                # macOS GUI 模式需要使用 Cocoa 框架
                cmd.extend(["-framework", "Cocoa"])
            cmd.extend(["-o", str(self.output_file), str(self.source_file)])

            result = execute(
                cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        except subprocess.SubprocessError as exc:
            logger.debug(f"Clang 编译异常: {exc}")
            return False
        else:
            return result.returncode == 0
