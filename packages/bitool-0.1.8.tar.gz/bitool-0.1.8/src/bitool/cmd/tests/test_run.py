"""测试 run 命令模块."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from bitool.cmd.run import RunCommand, RunShellCommand, _parse_shell_command
from bitool.utils.executor import RunResult


class TestParseShellCommand:
    """测试 _parse_shell_command 函数."""

    def test_simple_command(self) -> None:
        """测试简单命令."""
        cmd, redirect, append, has_pipe = _parse_shell_command("echo hello")
        assert cmd == ["echo", "hello"]
        assert redirect is None
        assert append is False
        assert has_pipe is False

    def test_command_with_redirect(self) -> None:
        """测试带重定向的命令."""
        cmd, redirect, append, _has_pipe = _parse_shell_command(
            "echo hello > output.txt"
        )
        assert cmd == ["echo", "hello"]
        assert redirect == "output.txt"
        assert append is False

    def test_command_with_append(self) -> None:
        """测试带追加的命令."""
        cmd, redirect, append, _has_pipe = _parse_shell_command(
            "echo hello >> output.txt"
        )
        assert cmd == ["echo", "hello"]
        assert redirect == "output.txt"
        assert append is True

    def test_command_with_pipe(self) -> None:
        """测试带管道的命令(应抛出异常)."""
        with pytest.raises(ValueError, match="不支持管道"):
            _parse_shell_command("echo hello | grep hello")


class TestRunCommand:
    """测试 RunCommand 类."""

    def test_run_list_command(self) -> None:
        """测试运行列表命令."""
        import platform

        if platform.system() == "Windows":
            cmd = RunCommand(cmd=["cmd", "/c", "echo", "hello"])
        else:
            cmd = RunCommand(cmd=["echo", "hello"])
        result = cmd.run()
        assert result is True

    def test_run_callable_command(self) -> None:
        """测试运行可调用命令."""
        mock_func = MagicMock()
        cmd = RunCommand(cmd=mock_func)
        result = cmd.run()
        assert result is True
        assert mock_func.called

    @patch("bitool.cmd.run.execute")
    def test_run_with_env(self, mock_execute: MagicMock) -> None:
        """测试带环境变量运行."""
        mock_execute.return_value = RunResult(
            returncode=0,
            stdout="",
            stderr="",
            execution_time=0.1,
            cmd=["echo", "hello"],
        )
        cmd = RunCommand(cmd=["echo", "hello"], env={"TEST_VAR": "test_value"})
        result = cmd.run()
        assert result is True
        mock_execute.assert_called_once()

    @patch("bitool.cmd.run.execute")
    def test_run_with_cwd(self, mock_execute: MagicMock, tmp_path: Path) -> None:
        """测试带工作目录运行."""
        mock_execute.return_value = RunResult(
            returncode=0,
            stdout="",
            stderr="",
            execution_time=0.1,
            cmd=["echo", "hello"],
        )
        cmd = RunCommand(cmd=["echo", "hello"], cwd=tmp_path)
        result = cmd.run()
        assert result is True
        mock_execute.assert_called_once()

    @patch("bitool.cmd.run.execute")
    def test_run_with_timeout(self, mock_execute: MagicMock) -> None:
        """测试带超时运行."""
        mock_execute.return_value = RunResult(
            returncode=0,
            stdout="",
            stderr="",
            execution_time=0.1,
            cmd=["echo", "hello"],
        )
        cmd = RunCommand(cmd=["echo", "hello"], timeout=10)
        result = cmd.run()
        assert result is True
        mock_execute.assert_called_once()

    @patch("bitool.cmd.run.execute")
    def test_run_with_check(self, mock_execute: MagicMock) -> None:
        """测试带检查运行."""
        mock_execute.return_value = RunResult(
            returncode=0,
            stdout="",
            stderr="",
            execution_time=0.1,
            cmd=["echo", "hello"],
        )
        cmd = RunCommand(cmd=["echo", "hello"], check=True)
        result = cmd.run()
        assert result is True
        mock_execute.assert_called_once()

    @patch("bitool.cmd.run.execute")
    def test_run_failure(self, mock_execute: MagicMock) -> None:
        """测试运行失败."""
        mock_execute.side_effect = Exception("命令执行失败")
        cmd = RunCommand(cmd=["invalid_command"])
        result = cmd.run()
        assert result is False


class TestRunShellCommand:
    """测试 RunShellCommand 类."""

    def test_run_simple_shell_command(self) -> None:
        """测试运行简单 shell 命令."""
        # Windows 上使用 dir, Unix 上使用 ls
        import platform

        shell_cmd = "cmd /c dir" if platform.system() == "Windows" else "ls"

        cmd = RunShellCommand(shell_cmd=shell_cmd)
        cmd.run()
        # 注意：在某些环境下可能会失败，这是正常的

    def test_run_shell_command_with_redirect(self, tmp_path: Path) -> None:
        """测试运行带重定向的 shell 命令."""
        import platform

        output_file = tmp_path / "output.txt"
        if platform.system() == "Windows":
            shell_cmd = f"dir > {output_file}"
        else:
            shell_cmd = f"ls > {output_file}"

        cmd = RunShellCommand(shell_cmd=shell_cmd)
        cmd.run()
        # 注意：在某些情况下可能会失败，这是正常的
        # 我们只验证命令尝试执行

    def test_run_empty_shell_command(self) -> None:
        """测试运行空 shell 命令."""
        cmd = RunShellCommand(shell_cmd="")
        result = cmd.run()
        assert result is False

    @patch("subprocess.run")
    def test_run_shell_command_timeout(self, mock_run: MagicMock) -> None:
        """测试 shell 命令超时."""
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="test", timeout=1)
        cmd = RunShellCommand(shell_cmd="echo hello", timeout=1)
        result = cmd.run()
        assert result is False

    def test_run_shell_command_with_pipe(self) -> None:
        """测试运行带管道的 shell 命令."""
        cmd = RunShellCommand(shell_cmd="echo hello | grep hello")
        result = cmd.run()
        assert result is False

    @patch("subprocess.run")
    def test_run_shell_command_redirect_success(
        self, mock_run: MagicMock, tmp_path: Path
    ) -> None:
        """测试 shell 命令重定向成功."""
        from unittest.mock import Mock

        output_file = tmp_path / "output.txt"
        mock_result = Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        cmd = RunShellCommand(shell_cmd=f"echo hello > {output_file}")
        result = cmd.run()
        assert result is True

    @patch("subprocess.run")
    def test_run_shell_command_redirect_failure(
        self, mock_run: MagicMock, tmp_path: Path
    ) -> None:
        """测试 shell 命令重定向失败."""
        from unittest.mock import Mock

        output_file = tmp_path / "output.txt"
        mock_result = Mock()
        mock_result.returncode = 1
        mock_result.stderr = "错误信息"
        mock_run.return_value = mock_result

        cmd = RunShellCommand(shell_cmd=f"echo hello > {output_file}")
        result = cmd.run()
        assert result is False

    @patch("subprocess.run")
    def test_run_shell_command_with_output(self, mock_run: MagicMock) -> None:
        """测试 shell 命令有输出."""
        from unittest.mock import Mock

        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stdout = "hello\nworld\n"
        mock_result.stderr = ""
        mock_run.return_value = mock_result

        cmd = RunShellCommand(shell_cmd="echo hello")
        result = cmd.run()
        assert result is True

    @patch("subprocess.run")
    def test_run_shell_command_no_output(self, mock_run: MagicMock) -> None:
        """测试 shell 命令无输出."""
        from unittest.mock import Mock

        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""
        mock_run.return_value = mock_result

        cmd = RunShellCommand(shell_cmd="echo hello")
        result = cmd.run()
        assert result is True

    @patch("subprocess.run")
    def test_run_shell_command_failure(self, mock_run: MagicMock) -> None:
        """测试 shell 命令执行失败."""
        from unittest.mock import Mock

        mock_result = Mock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "错误信息"
        mock_run.return_value = mock_result

        cmd = RunShellCommand(shell_cmd="invalid_command")
        result = cmd.run()
        assert result is False


# 注意: TestRunSequentialCommands、TestRunParallelCommands 和 TestRunDAGCommands 已移除
# 请使用 utils/task_group.py 中的 TaskGroup 测试替代
