"""TOML命令测试."""

from pathlib import Path

import pytest

from bitool.cmd.toml import ReadTomlCommand, WriteTomlCommand


@pytest.fixture
def sample_toml(tmp_path: Path) -> Path:
    """创建测试用的TOML文件."""
    toml_file = tmp_path / "test.toml"
    content = """[project]
name = "test-project"
version = "1.0.0"

[project.dependencies]
python = ">=3.8"
"""
    toml_file.write_text(content, encoding="utf-8")
    return toml_file


class TestReadTomlCommand:
    """测试ReadTomlCommand."""

    def test_read_toml_success(self, sample_toml: Path) -> None:
        """测试成功读取TOML文件."""
        cmd = ReadTomlCommand(filepath=sample_toml)
        assert cmd.run() is True
        assert cmd.data["project"]["name"] == "test-project"
        assert cmd.data["project"]["version"] == "1.0.0"

    def test_read_toml_file_not_exists(self, tmp_path: Path) -> None:
        """测试读取不存在的文件."""
        cmd = ReadTomlCommand(filepath=tmp_path / "nonexistent.toml")
        assert cmd.run() is False


class TestWriteTomlCommand:
    """测试WriteTomlCommand."""

    def test_write_toml_success(self, tmp_path: Path) -> None:
        """测试成功写入TOML文件."""
        toml_file = tmp_path / "output.toml"
        data = {"project": {"name": "new-project", "version": "2.0.0"}}
        cmd = WriteTomlCommand(filepath=toml_file, data=data)
        assert cmd.run() is True
        assert toml_file.exists()

        # 验证内容
        read_cmd = ReadTomlCommand(filepath=toml_file)
        assert read_cmd.run() is True
        assert read_cmd.data["project"]["name"] == "new-project"
        assert read_cmd.data["project"]["version"] == "2.0.0"


# 注意: TestReadTomlVersionCommand 和 TestUpdateTomlVersionCommand 已移除
# 请使用 version.py 中的测试替代
