"""PDF操作模块的单元测试."""

from __future__ import annotations

from pathlib import Path
from typing import Generator
from unittest.mock import MagicMock, patch

import pytest

from bitool.cmd.pdf import (
    CompressPdfCommand,
    ImagesToPdfCommand,
    MergePdfsCommand,
    PdfToImagesCommand,
    SplitPdfCommand,
)


@pytest.fixture(autouse=True)
def mock_pymupdf() -> Generator[MagicMock, None, None]:
    """创建PyMuPDF的模拟对象用于测试."""
    mock_fitz = MagicMock()
    mock_doc = MagicMock()
    mock_page = MagicMock()
    mock_pixmap = MagicMock()

    # 设置模拟文档行为
    mock_doc.__len__ = lambda self: 5  # 模拟5页的PDF
    mock_doc.__getitem__ = lambda self, idx: mock_page
    mock_fitz.open.return_value = mock_doc
    mock_page.get_pixmap.return_value = mock_pixmap

    with patch("bitool.cmd.pdf.fitz", mock_fitz):
        yield mock_fitz


class TestSplitPdfCommand:
    """测试PDF拆分命令."""

    def test_split_pdf_success(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试成功拆分PDF."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        cmd = SplitPdfCommand(
            input_path=input_pdf, output_dir=output_dir, pages_per_file=2
        )

        result = cmd.run()
        assert result is True
        assert len(cmd.output_files) > 0

    def test_split_pdf_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试未安装PyMuPDF时的错误处理."""
        with patch("bitool.cmd.pdf.HAS_PYMUPDF", new=False):
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()

            cmd = SplitPdfCommand(
                input_path=input_pdf, output_dir=tmp_path / "output", pages_per_file=2
            )

            result = cmd.run()
            assert result is False

    def test_split_pdf_invalid_pages(self, tmp_path: Path) -> None:
        """测试无效页数参数."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()

        cmd = SplitPdfCommand(
            input_path=input_pdf,
            output_dir=tmp_path / "output",
            pages_per_file=0,  # 无效值
        )

        result = cmd.run()
        assert result is False

    def test_split_pdf_file_not_exists(self, tmp_path: Path) -> None:
        """测试输入文件不存在."""
        cmd = SplitPdfCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_dir=tmp_path / "output",
            pages_per_file=2,
        )

        result = cmd.run()
        assert result is False

    def test_split_pdf_exception(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试拆分PDF时发生异常."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出异常
        mock_pymupdf.open.side_effect = Exception("PDF打开失败")

        cmd = SplitPdfCommand(
            input_path=input_pdf, output_dir=output_dir, pages_per_file=2
        )

        result = cmd.run()
        assert result is False

    def test_split_pdf_value_error(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试拆分PDF时参数错误."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出 ValueError
        mock_pymupdf.open.side_effect = ValueError("参数错误")

        cmd = SplitPdfCommand(
            input_path=input_pdf, output_dir=output_dir, pages_per_file=2
        )

        result = cmd.run()
        assert result is False

    def test_split_pdf_file_not_found(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试拆分PDF时文件未找到."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出 FileNotFoundError
        mock_pymupdf.open.side_effect = FileNotFoundError("文件不存在")

        cmd = SplitPdfCommand(
            input_path=input_pdf, output_dir=output_dir, pages_per_file=2
        )

        result = cmd.run()
        assert result is False


class TestMergePdfsCommand:
    """测试PDF合并命令."""

    def test_merge_pdfs_success(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试成功合并PDF."""
        input_pdf1 = tmp_path / "input1.pdf"
        input_pdf2 = tmp_path / "input2.pdf"
        input_pdf1.touch()
        input_pdf2.touch()
        output_pdf = tmp_path / "merged.pdf"

        cmd = MergePdfsCommand(
            input_paths=[input_pdf1, input_pdf2], output_path=output_pdf
        )

        result = cmd.run()
        assert result is True

    def test_merge_pdfs_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试未安装PyMuPDF时的错误处理."""
        with patch("bitool.cmd.pdf.HAS_PYMUPDF", new=False):
            input_pdf1 = tmp_path / "input1.pdf"
            input_pdf1.touch()

            cmd = MergePdfsCommand(
                input_paths=[input_pdf1], output_path=tmp_path / "merged.pdf"
            )

            result = cmd.run()
            assert result is False

    def test_merge_pdfs_empty_input(self, tmp_path: Path) -> None:
        """测试空输入列表."""
        cmd = MergePdfsCommand(input_paths=[], output_path=tmp_path / "merged.pdf")

        result = cmd.run()
        assert result is False

    def test_merge_pdfs_file_not_exists(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试输入文件不存在."""
        input_pdf1 = tmp_path / "input1.pdf"
        input_pdf1.touch()
        nonexistent_pdf = tmp_path / "nonexistent.pdf"

        cmd = MergePdfsCommand(
            input_paths=[input_pdf1, nonexistent_pdf],
            output_path=tmp_path / "merged.pdf",
        )

        result = cmd.run()
        assert result is False

    def test_merge_pdfs_exception(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试合并PDF时发生异常."""
        input_pdf1 = tmp_path / "input1.pdf"
        input_pdf1.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出异常
        mock_pymupdf.open.side_effect = Exception("PDF打开失败")

        cmd = MergePdfsCommand(input_paths=[input_pdf1], output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_merge_pdfs_file_not_found(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试合并PDF时文件未找到."""
        input_pdf1 = tmp_path / "input1.pdf"
        input_pdf1.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出 FileNotFoundError
        mock_pymupdf.open.side_effect = FileNotFoundError("文件不存在")

        cmd = MergePdfsCommand(input_paths=[input_pdf1], output_path=output_pdf)

        result = cmd.run()
        assert result is False


class TestCompressPdfCommand:
    """测试PDF压缩命令."""

    def test_compress_pdf_success(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试成功压缩PDF."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_pdf = tmp_path / "compressed.pdf"

        cmd = CompressPdfCommand(
            input_path=input_pdf, output_path=output_pdf, quality=75
        )

        result = cmd.run()
        assert result is True

    def test_compress_pdf_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试未安装PyMuPDF时的错误处理."""
        with patch("bitool.cmd.pdf.HAS_PYMUPDF", new=False):
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()

            cmd = CompressPdfCommand(
                input_path=input_pdf,
                output_path=tmp_path / "compressed.pdf",
                quality=75,
            )

            result = cmd.run()
            assert result is False

    def test_compress_pdf_invalid_quality(self, tmp_path: Path) -> None:
        """测试无效质量参数."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()

        cmd = CompressPdfCommand(
            input_path=input_pdf,
            output_path=tmp_path / "compressed.pdf",
            quality=150,  # 无效值
        )

        result = cmd.run()
        assert result is False

    def test_compress_pdf_exception(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试压缩PDF时发生异常."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出异常
        mock_pymupdf.open.side_effect = Exception("PDF打开失败")

        cmd = CompressPdfCommand(input_path=input_pdf, output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_compress_pdf_value_error(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试压缩PDF时参数错误."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出 ValueError
        mock_pymupdf.open.side_effect = ValueError("参数错误")

        cmd = CompressPdfCommand(input_path=input_pdf, output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_compress_pdf_file_not_found(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试压缩PDF时文件未找到."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出 FileNotFoundError
        mock_pymupdf.open.side_effect = FileNotFoundError("文件不存在")

        cmd = CompressPdfCommand(input_path=input_pdf, output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_compress_pdf_file_not_exists(self, tmp_path: Path) -> None:
        """测试输入文件不存在."""
        cmd = CompressPdfCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_path=tmp_path / "compressed.pdf",
            quality=75,
        )

        result = cmd.run()
        assert result is False


class TestPdfToImagesCommand:
    """测试PDF转图片命令."""

    def test_pdf_to_images_success(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试成功将PDF转为图片."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "images"
        output_dir.mkdir()

        cmd = PdfToImagesCommand(
            input_path=input_pdf, output_dir=output_dir, fmt="png", dpi=150
        )

        result = cmd.run()
        assert result is True
        assert len(cmd.output_files) > 0

    def test_pdf_to_images_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试未安装PyMuPDF时的错误处理."""
        with patch("bitool.cmd.pdf.HAS_PYMUPDF", new=False):
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()

            cmd = PdfToImagesCommand(
                input_path=input_pdf, output_dir=tmp_path / "images", fmt="png", dpi=150
            )

            result = cmd.run()
            assert result is False

    def test_pdf_to_images_file_not_exists(self, tmp_path: Path) -> None:
        """测试输入文件不存在."""
        cmd = PdfToImagesCommand(
            input_path=tmp_path / "nonexistent.pdf",
            output_dir=tmp_path / "images",
            fmt="png",
            dpi=150,
        )

        result = cmd.run()
        assert result is False

    def test_pdf_to_images_exception(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试PDF转图片时发生异常."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出异常
        mock_pymupdf.open.side_effect = Exception("PDF打开失败")

        cmd = PdfToImagesCommand(input_path=input_pdf, output_dir=output_dir)

        result = cmd.run()
        assert result is False

    def test_pdf_to_images_value_error(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试PDF转图片时参数错误."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出 ValueError
        mock_pymupdf.open.side_effect = ValueError("参数错误")

        cmd = PdfToImagesCommand(input_path=input_pdf, output_dir=output_dir)

        result = cmd.run()
        assert result is False

    def test_pdf_to_images_file_not_found(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试PDF转图片时文件未找到."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Mock fitz.open 抛出 FileNotFoundError
        mock_pymupdf.open.side_effect = FileNotFoundError("文件不存在")

        cmd = PdfToImagesCommand(input_path=input_pdf, output_dir=output_dir)

        result = cmd.run()
        assert result is False


class TestImagesToPdfCommand:
    """测试图片转PDF命令."""

    def test_images_to_pdf_success(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试成功将图片转为PDF."""
        img1 = tmp_path / "image1.png"
        img2 = tmp_path / "image2.png"
        img1.touch()
        img2.touch()
        output_pdf = tmp_path / "output.pdf"

        cmd = ImagesToPdfCommand(
            image_paths=[img1, img2], output_path=output_pdf, page_size="auto"
        )

        result = cmd.run()
        assert result is True

    def test_images_to_pdf_pymupdf_not_installed(self, tmp_path: Path) -> None:
        """测试未安装PyMuPDF时的错误处理."""
        with patch("bitool.cmd.pdf.HAS_PYMUPDF", new=False):
            img1 = tmp_path / "image1.png"
            img1.touch()

            cmd = ImagesToPdfCommand(
                image_paths=[img1],
                output_path=tmp_path / "output.pdf",
                page_size="auto",
            )

            result = cmd.run()
            assert result is False

    def test_images_to_pdf_empty_list(self, tmp_path: Path) -> None:
        """测试空图片列表."""
        cmd = ImagesToPdfCommand(
            image_paths=[], output_path=tmp_path / "output.pdf", page_size="auto"
        )

        result = cmd.run()
        assert result is False

    def test_images_to_pdf_file_not_exists(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试图片文件不存在."""
        img1 = tmp_path / "image1.png"
        img1.touch()
        nonexistent_img = tmp_path / "nonexistent.png"

        cmd = ImagesToPdfCommand(
            image_paths=[img1, nonexistent_img],
            output_path=tmp_path / "output.pdf",
            page_size="auto",
        )

        result = cmd.run()
        assert result is False


class TestPdfCommandsParameterized:
    """使用参数化测试PDF命令的不同场景."""

    @pytest.mark.parametrize(
        ("command_class", "kwargs", "expected_result"),
        [
            # 测试不同页数设置
            (SplitPdfCommand, {"pages_per_file": 1}, True),
            (SplitPdfCommand, {"pages_per_file": 3}, True),
            (SplitPdfCommand, {"pages_per_file": 5}, True),
            # 测试不同质量设置
            (CompressPdfCommand, {"quality": 50}, True),
            (CompressPdfCommand, {"quality": 75}, True),
            (CompressPdfCommand, {"quality": 100}, True),
            # 测试不同格式设置
            (PdfToImagesCommand, {"fmt": "png"}, True),
            (PdfToImagesCommand, {"fmt": "jpeg"}, True),
            # 测试不同DPI设置
            (PdfToImagesCommand, {"dpi": 72}, True),
            (PdfToImagesCommand, {"dpi": 150}, True),
            (PdfToImagesCommand, {"dpi": 300}, True),
        ],
    )
    def test_pdf_commands_with_different_params(
        self, tmp_path: Path, mock_pymupdf, command_class, kwargs, expected_result
    ) -> None:
        """使用不同参数测试PDF命令."""
        # 根据命令类型设置不同的输入
        if command_class == SplitPdfCommand:
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()
            cmd = command_class(
                input_path=input_pdf, output_dir=tmp_path / "output", **kwargs
            )
        elif command_class == CompressPdfCommand:
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()
            cmd = command_class(
                input_path=input_pdf, output_path=tmp_path / "output.pdf", **kwargs
            )
        elif command_class == PdfToImagesCommand:
            input_pdf = tmp_path / "input.pdf"
            input_pdf.touch()
            cmd = command_class(
                input_path=input_pdf, output_dir=tmp_path / "output", **kwargs
            )
        else:
            return  # 跳过不支持的命令类型

        result = cmd.run()
        assert result == expected_result

    @pytest.mark.parametrize(
        ("quality", "expected"),
        [
            (0, False),  # 质量太低
            (1, True),  # 最小有效值
            (50, True),  # 中等质量
            (99, True),  # 高质量
            (100, True),  # 最大有效值
            (101, False),  # 质量太高
        ],
    )
    def test_compress_pdf_quality_validation(
        self, tmp_path: Path, quality: int, expected: bool
    ) -> None:
        """测试PDF压缩质量参数验证."""
        input_pdf = tmp_path / "input.pdf"
        input_pdf.touch()

        cmd = CompressPdfCommand(
            input_path=input_pdf, output_path=tmp_path / "output.pdf", quality=quality
        )

        result = cmd.run()
        # 注意：只有当quality在1-100范围内才应该成功
        # 但是由于mock的原因，只要质量有效就会成功
        if 1 <= quality <= 100:
            assert result is True
        else:
            assert result is False

    def test_images_to_pdf_exception(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试图片转PDF时发生异常."""
        img1 = tmp_path / "img1.png"
        img1.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出异常
        mock_pymupdf.open.side_effect = Exception("图片打开失败")

        cmd = ImagesToPdfCommand(image_paths=[img1], output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_images_to_pdf_value_error(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试图片转PDF时参数错误."""
        img1 = tmp_path / "img1.png"
        img1.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出 ValueError
        mock_pymupdf.open.side_effect = ValueError("参数错误")

        cmd = ImagesToPdfCommand(image_paths=[img1], output_path=output_pdf)

        result = cmd.run()
        assert result is False

    def test_images_to_pdf_file_not_found(self, tmp_path: Path, mock_pymupdf) -> None:
        """测试图片转PDF时文件未找到."""
        img1 = tmp_path / "img1.png"
        img1.touch()
        output_pdf = tmp_path / "output.pdf"

        # Mock fitz.open 抛出 FileNotFoundError
        mock_pymupdf.open.side_effect = FileNotFoundError("文件不存在")

        cmd = ImagesToPdfCommand(image_paths=[img1], output_path=output_pdf)

        result = cmd.run()
        assert result is False
