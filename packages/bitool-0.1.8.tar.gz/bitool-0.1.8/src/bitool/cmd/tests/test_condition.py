"""测试 Condition 模块."""

from __future__ import annotations

from pathlib import Path

from bitool.cmd._condition import BuiltinConditions, Condition


class TestCondition:
    """测试 Condition 类."""

    def test_create_condition(self) -> None:
        """测试创建 Condition 实例."""
        func = lambda: True  # noqa: E731
        condition = Condition(func=func, reason="测试原因")
        assert condition.func is func
        assert condition.reason == "测试原因"

    def test_create_condition_default_reason(self) -> None:
        """测试创建 Condition 实例使用默认原因."""
        func = lambda: True  # noqa: E731
        condition = Condition(func=func)
        assert condition.func is func
        assert condition.reason == "未知原因"

    def test_from_data_with_condition(self) -> None:
        """测试从 Condition 对象创建."""
        original = Condition(func=lambda: True, reason="原始原因")
        result = Condition.from_data(original)
        assert result is original

    def test_from_data_with_tuple(self) -> None:
        """测试从 tuple 创建."""
        func = lambda: True  # noqa: E731
        result = Condition.from_data((func, "tuple原因"))
        assert result.func is func
        assert result.reason == "tuple原因"

    def test_condition_func_execution(self) -> None:
        """测试条件函数执行."""
        condition = Condition(func=lambda: True, reason="成功")
        assert condition.func() is True

        condition = Condition(func=lambda: False, reason="失败")
        assert condition.func() is False


class TestBuiltinConditions:
    """测试 BuiltinConditions 类."""

    def test_is_windows(self) -> None:
        """测试 IS_WINDOWS 条件."""
        from bitool.consts import Constants

        condition = BuiltinConditions.IS_WINDOWS
        assert condition.func() == Constants.IS_WINDOWS
        assert "Windows" in condition.reason

    def test_is_unix(self) -> None:
        """测试 IS_UNIX 条件."""
        from bitool.consts import Constants

        condition = BuiltinConditions.IS_UNIX
        assert condition.func() == Constants.IS_UNIX
        assert "Unix" in condition.reason

    def test_has_app_installed_found(self) -> None:
        """测试 HAS_APP_INSTALLED 找到应用."""
        # 使用常见的系统命令进行测试
        # 在 Windows 上测试 cmd, 在 Unix 上测试 ls
        import platform

        app = "cmd" if platform.system() == "Windows" else "ls"
        condition = BuiltinConditions.HAS_APP_INSTALLED(app)
        assert condition.func() is True
        assert app in condition.reason

    def test_has_app_installed_not_found(self) -> None:
        """测试 HAS_APP_INSTALLED 未找到应用."""
        condition = BuiltinConditions.HAS_APP_INSTALLED("nonexistent_app_xyz_123")
        assert condition.func() is False

    def test_has_entry_in_dir_found(self, tmp_path: Path) -> None:
        """测试 HAS_ENTRY_IN_DIR 找到条目."""
        # 创建一个测试文件
        test_file = tmp_path / "test_entry.txt"
        test_file.touch()

        condition = BuiltinConditions.HAS_ENTRY_IN_DIR("test_entry.txt", tmp_path)
        assert condition.func() is True
        assert "test_entry.txt" in condition.reason

    def test_has_entry_in_dir_not_found(self, tmp_path: Path) -> None:
        """测试 HAS_ENTRY_IN_DIR 未找到条目."""
        condition = BuiltinConditions.HAS_ENTRY_IN_DIR("nonexistent.txt", tmp_path)
        assert condition.func() is False

    def test_has_entry_in_dir_case_insensitive(self, tmp_path: Path) -> None:
        """测试 HAS_ENTRY_IN_DIR 大小写不敏感."""
        # 创建一个测试文件
        test_file = tmp_path / "TestFile.TXT"
        test_file.touch()

        # 使用小写查询
        condition = BuiltinConditions.HAS_ENTRY_IN_DIR("testfile.txt", tmp_path)
        assert condition.func() is True

        # 使用大写查询
        condition = BuiltinConditions.HAS_ENTRY_IN_DIR("TESTFILE.TXT", tmp_path)
        assert condition.func() is True

    def test_has_entry_in_dir_empty_directory(self, tmp_path: Path) -> None:
        """测试 HAS_ENTRY_IN_DIR 空目录."""
        condition = BuiltinConditions.HAS_ENTRY_IN_DIR("any.txt", tmp_path)
        assert condition.func() is False
