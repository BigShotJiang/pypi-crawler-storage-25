"""测试 BaseCommand 模块."""

from __future__ import annotations

from typing import Callable
from unittest.mock import patch

import pytest

from bitool.cmd._base import BaseCommand
from bitool.cmd._condition import Condition


class ConcreteCommand(BaseCommand):
    """具体的命令实现, 用于测试."""

    name = "test_command"
    description = "测试命令"

    def run(self) -> bool:
        """运行命令."""
        return True


class ConcreteCommandFailing(BaseCommand):
    """失败的具体命令实现, 用于测试."""

    name = "test_command_failing"
    description = "测试失败命令"

    def run(self) -> bool:
        """运行命令."""
        return False


class TestBaseCommand:
    """测试 BaseCommand 类."""

    def test_default_values(self) -> None:
        """测试默认值."""
        cmd = ConcreteCommand(name="test_command", description="测试命令")
        assert cmd.name == "test_command"
        assert cmd.description == "测试命令"
        assert cmd.allow_conditions == []
        assert cmd.forbid_conditions == []
        assert cmd.dependencies == []

    def test_run_success(self) -> None:
        """测试运行成功."""
        cmd = ConcreteCommand()
        result = cmd.run()
        assert result is True

    def test_run_failure(self) -> None:
        """测试运行失败."""
        cmd = ConcreteCommandFailing()
        result = cmd.run()
        assert result is False

    def test_validate_and_run_success(self) -> None:
        """测试验证并运行成功."""
        cmd = ConcreteCommand()
        result = cmd.validate_and_run()
        assert result is True

    def test_validate_and_run_failure(self) -> None:
        """测试验证并运行失败."""
        cmd = ConcreteCommandFailing()
        result = cmd.validate_and_run()
        assert result is False

    def test_validate_no_conditions(self) -> None:
        """测试无条件时验证通过."""
        cmd = ConcreteCommand()
        result = cmd.validate()
        assert result is True

    def test_validate_allow_conditions_met(self) -> None:
        """测试允许条件满足."""
        condition = Condition(func=lambda: True, reason="条件满足")
        cmd = ConcreteCommand(allow_conditions=[condition])
        result = cmd.validate()
        assert result is True

    def test_validate_allow_conditions_not_met(self) -> None:
        """测试允许条件不满足."""
        condition = Condition(func=lambda: False, reason="条件不满足")
        cmd = ConcreteCommand(allow_conditions=[condition])
        result = cmd.validate()
        assert result is False

    def test_validate_forbid_conditions_not_met(self) -> None:
        """测试禁止条件不满足(应该通过)."""
        condition = Condition(func=lambda: False, reason="禁止条件未触发")
        cmd = ConcreteCommand(forbid_conditions=[condition])
        result = cmd.validate()
        assert result is True

    def test_validate_forbid_conditions_met(self) -> None:
        """测试禁止条件满足(应该失败)."""
        condition = Condition(func=lambda: True, reason="禁止条件触发")
        cmd = ConcreteCommand(forbid_conditions=[condition])
        result = cmd.validate()
        assert result is False

    def test_validate_multiple_allow_conditions(self) -> None:
        """测试多个允许条件全部满足."""
        conditions: list[Condition | tuple[Callable[[], bool], str]] = [
            Condition(func=lambda: True, reason="条件1"),
            Condition(func=lambda: True, reason="条件2"),
            Condition(func=lambda: True, reason="条件3"),
        ]
        cmd = ConcreteCommand(allow_conditions=conditions)
        result = cmd.validate()
        assert result is True

    def test_validate_multiple_allow_conditions_one_failed(self) -> None:
        """测试多个允许条件有一个不满足."""
        conditions: list[Condition | tuple[Callable[[], bool], str]] = [
            Condition(func=lambda: True, reason="条件1"),
            Condition(func=lambda: False, reason="条件2"),
            Condition(func=lambda: True, reason="条件3"),
        ]
        cmd = ConcreteCommand(allow_conditions=conditions)
        result = cmd.validate()
        assert result is False

    def test_validate_tuple_condition(self) -> None:
        """测试 tuple 格式的条件."""
        cmd = ConcreteCommand(allow_conditions=[(lambda: True, "条件满足")])
        result = cmd.validate()
        assert result is True

    def test_dependencies(self) -> None:
        """测试依赖关系."""
        cmd = ConcreteCommand(dependencies=["task1", "task2"])
        assert cmd.dependencies == ["task1", "task2"]

    @patch("bitool.cmd._base.logger")
    def test_validate_log_warning_on_allow_fail(self, mock_logger) -> None:
        """测试允许条件不满足时记录警告日志."""
        condition = Condition(func=lambda: False, reason="条件不满足")
        cmd = ConcreteCommand(allow_conditions=[condition])
        cmd.validate()
        assert mock_logger.warning.called

    @patch("bitool.cmd._base.logger")
    def test_validate_log_warning_on_forbid_fail(self, mock_logger) -> None:
        """测试禁止条件满足时记录警告日志."""
        condition = Condition(func=lambda: True, reason="禁止条件触发")
        cmd = ConcreteCommand(forbid_conditions=[condition])
        cmd.validate()
        assert mock_logger.warning.called

    def test_abstract_run_raises_not_implemented(self) -> None:
        """测试抽象方法 run 抛出 NotImplementedError."""
        with pytest.raises(NotImplementedError):
            # 直接调用 BaseCommand 的 run 方法
            BaseCommand(name="test", description="test").run()

    def test_validate_and_run_when_validate_fails(self) -> None:
        """测试验证失败时 validate_and_run 返回 False."""
        condition = Condition(func=lambda: False, reason="条件不满足")
        cmd = ConcreteCommandFailing(allow_conditions=[condition])
        result = cmd.validate_and_run()
        assert result is False
