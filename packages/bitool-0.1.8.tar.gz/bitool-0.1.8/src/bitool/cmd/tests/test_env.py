"""测试环境变量操作模块."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

from bitool.cmd.env import (
    ExportEnvCommand,
    GetEnvCommand,
    ImportEnvCommand,
    ListEnvCommand,
    SetEnvCommand,
    UnsetEnvCommand,
)


class TestGetEnvCommand:
    """测试 GetEnvCommand 类."""

    def test_get_existing_env(self) -> None:
        """测试获取已存在的环境变量."""
        os.environ["TEST_VAR"] = "test_value"
        try:
            cmd = GetEnvCommand("TEST_VAR")
            result = cmd.run()
            assert result is True
            assert cmd.value == "test_value"
        finally:
            del os.environ["TEST_VAR"]

    def test_get_nonexistent_env(self) -> None:
        """测试获取不存在的环境变量."""
        cmd = GetEnvCommand("NONEXISTENT_VAR_XYZ")
        result = cmd.run()
        assert result is False
        assert cmd.value is None

    def test_get_env_with_default(self) -> None:
        """测试获取环境变量使用默认值."""
        cmd = GetEnvCommand("NONEXISTENT_VAR_XYZ", default="default_value")
        result = cmd.run()
        assert result is True
        assert cmd.value == "default_value"


class TestUnsetEnvCommand:
    """测试 UnsetEnvCommand 类."""

    def test_unset_existing_env(self) -> None:
        """测试删除已存在的环境变量."""
        os.environ["TEST_VAR"] = "test_value"
        cmd = UnsetEnvCommand("TEST_VAR")
        result = cmd.run()
        assert result is True
        assert "TEST_VAR" not in os.environ

    def test_unset_nonexistent_env(self) -> None:
        """测试删除不存在的环境变量."""
        cmd = UnsetEnvCommand("NONEXISTENT_VAR_XYZ")
        result = cmd.run()
        assert result is False


class TestListEnvCommand:
    """测试 ListEnvCommand 类."""

    def test_list_all_env(self) -> None:
        """测试列出所有环境变量."""
        cmd = ListEnvCommand()
        result = cmd.run()
        assert result is True
        assert len(cmd.envs) > 0

    def test_list_env_with_pattern(self) -> None:
        """测试按模式过滤环境变量."""
        os.environ["TEST_VAR1"] = "value1"
        os.environ["TEST_VAR2"] = "value2"
        os.environ["OTHER_VAR"] = "value3"
        try:
            cmd = ListEnvCommand(pattern="TEST")
            result = cmd.run()
            assert result is True
            assert "TEST_VAR1" in cmd.envs
            assert "TEST_VAR2" in cmd.envs
            assert "OTHER_VAR" not in cmd.envs
        finally:
            del os.environ["TEST_VAR1"]
            del os.environ["TEST_VAR2"]
            del os.environ["OTHER_VAR"]

    def test_list_env_no_match(self) -> None:
        """测试无匹配的环境变量."""
        cmd = ListEnvCommand(pattern="NONEXISTENT_PATTERN_XYZ")
        result = cmd.run()
        assert result is False
        assert len(cmd.envs) == 0


class TestExportEnvCommand:
    """测试 ExportEnvCommand 类."""

    def test_export_to_bash(self, tmp_path: Path) -> None:
        """测试导出为 bash 格式."""
        filepath = tmp_path / "env.sh"
        cmd = ExportEnvCommand(str(filepath), shell_type="bash")
        result = cmd.run()
        assert result is True
        assert filepath.exists()
        content = filepath.read_text(encoding="utf-8")
        assert "#!/bin/bash" in content

    def test_export_to_cmd(self, tmp_path: Path) -> None:
        """测试导出为 cmd 格式."""
        filepath = tmp_path / "env.bat"
        cmd = ExportEnvCommand(str(filepath), shell_type="cmd")
        result = cmd.run()
        assert result is True
        assert filepath.exists()
        content = filepath.read_text(encoding="utf-8")
        assert "@echo off" in content

    def test_export_to_powershell(self, tmp_path: Path) -> None:
        """测试导出为 PowerShell 格式."""
        filepath = tmp_path / "env.ps1"
        cmd = ExportEnvCommand(str(filepath), shell_type="powershell")
        result = cmd.run()
        assert result is True
        assert filepath.exists()
        content = filepath.read_text(encoding="utf-8")
        assert "PowerShell" in content

    def test_export_creates_parent_dir(self, tmp_path: Path) -> None:
        """测试导出时创建父目录."""
        filepath = tmp_path / "subdir" / "env.sh"
        cmd = ExportEnvCommand(str(filepath), shell_type="bash")
        result = cmd.run()
        assert result is True
        assert filepath.exists()


class TestImportEnvCommand:
    """测试 ImportEnvCommand 类."""

    def test_import_bash_format(self, tmp_path: Path) -> None:
        """测试导入 bash 格式."""
        filepath = tmp_path / "env.sh"
        filepath.write_text(
            'export TEST_VAR1="value1"\nexport TEST_VAR2="value2"\n', encoding="utf-8"
        )
        cmd = ImportEnvCommand(str(filepath))
        result = cmd.run()
        assert result is True
        assert cmd.count == 2
        assert os.environ.get("TEST_VAR1") == "value1"
        assert os.environ.get("TEST_VAR2") == "value2"
        # 清理
        del os.environ["TEST_VAR1"]
        del os.environ["TEST_VAR2"]

    def test_import_cmd_format(self, tmp_path: Path) -> None:
        """测试导入 cmd 格式."""
        filepath = tmp_path / "env.bat"
        filepath.write_text(
            "set TEST_VAR1=value1\nset TEST_VAR2=value2\n", encoding="utf-8"
        )
        cmd = ImportEnvCommand(str(filepath))
        result = cmd.run()
        assert result is True
        assert cmd.count == 2
        assert os.environ.get("TEST_VAR1") == "value1"
        assert os.environ.get("TEST_VAR2") == "value2"
        # 清理
        del os.environ["TEST_VAR1"]
        del os.environ["TEST_VAR2"]

    def test_import_powershell_format(self, tmp_path: Path) -> None:
        """测试导入 PowerShell 格式."""
        filepath = tmp_path / "env.ps1"
        filepath.write_text(
            '$env:TEST_VAR1="value1"\n$env:TEST_VAR2="value2"\n', encoding="utf-8"
        )
        cmd = ImportEnvCommand(str(filepath))
        result = cmd.run()
        assert result is True
        assert cmd.count == 2
        assert os.environ.get("TEST_VAR1") == "value1"
        assert os.environ.get("TEST_VAR2") == "value2"
        # 清理
        del os.environ["TEST_VAR1"]
        del os.environ["TEST_VAR2"]

    def test_import_file_not_exists(self) -> None:
        """测试导入不存在的文件."""
        cmd = ImportEnvCommand("nonexistent.env")
        result = cmd.run()
        assert result is False

    def test_import_skip_comments(self, tmp_path: Path) -> None:
        """测试导入时跳过注释."""
        filepath = tmp_path / "env.sh"
        filepath.write_text(
            '# 注释\nexport TEST_VAR1="value1"\n\n# 另一个注释\nexport TEST_VAR2="value2"\n',
            encoding="utf-8",
        )
        cmd = ImportEnvCommand(str(filepath))
        result = cmd.run()
        assert result is True
        assert cmd.count == 2
        # 清理
        del os.environ["TEST_VAR1"]
        del os.environ["TEST_VAR2"]


class TestSetEnvCommand:
    """测试 SetEnvCommand 类."""

    @patch("bitool.cmd.env.Constants")
    @patch("bitool.cmd.env.execute")
    def test_set_env_windows(
        self, mock_execute: MagicMock, mock_constants: MagicMock, tmp_path: Path
    ) -> None:
        """测试 Windows 上设置环境变量."""
        mock_constants.IS_WINDOWS = True
        cmd = SetEnvCommand([("TEST_VAR", "test_value")])
        result = cmd.run()
        assert result is True
        assert mock_execute.called

    @patch("bitool.cmd.env.Constants")
    def test_set_env_unix(self, mock_constants: MagicMock, tmp_path: Path) -> None:
        """测试 Unix 上设置环境变量."""
        mock_constants.IS_WINDOWS = False
        bashrc_path = tmp_path / "bashrc"
        bashrc_path.touch()

        with patch("os.path.expanduser", return_value=str(bashrc_path)):
            cmd = SetEnvCommand([("TEST_VAR", "test_value")])
            result = cmd.run()
            assert result is True

        content = bashrc_path.read_text(encoding="utf-8")
        assert "export TEST_VAR=test_value" in content

    def test_set_env_empty(self) -> None:
        """测试设置空环境变量列表."""
        cmd = SetEnvCommand([])
        result = cmd.run()
        assert result is False


# 注意: TestEnvOps 已移除，请使用 core.env.EnvironmentManager 的测试替代
