"""测试任务模型模块."""

from __future__ import annotations

import pytest

from bitool.utils.executor import RunResult
from bitool.utils.task import Task


class TestTask:
    """测试 Task 数据类."""

    def test_create_task_with_cmd(self) -> None:
        """测试创建带命令的任务."""
        task = Task(cmd=["echo", "hello"], name="test")
        assert task.cmd == ["echo", "hello"]
        assert task.name == "test"
        assert task.func is None

    def test_create_task_with_func(self) -> None:
        """测试创建带函数的任务."""

        def my_func() -> RunResult:
            return RunResult(
                returncode=0, stdout="", stderr="", execution_time=0.0, cmd=[]
            )

        task = Task(func=my_func, name="func-task")
        assert task.func == my_func
        assert task.name == "func-task"
        assert task.cmd is None

    def test_task_must_have_cmd_or_func(self) -> None:
        """测试任务必须有 cmd 或 func."""
        with pytest.raises(ValueError, match="必须提供 cmd 或 func 参数"):
            Task()

    def test_task_depends_on_requires_name(self) -> None:
        """测试有依赖的任务必须有名称."""
        with pytest.raises(ValueError, match="必须提供 name 参数"):
            Task(cmd=["echo", "test"], depends_on=["other"])

    def test_task_default_values(self) -> None:
        """测试任务默认值."""
        task = Task(cmd=["test"])
        assert task.description == ""
        assert task.parallel is False
        assert task.depends_on == []
        assert task.name == ""
        assert task.condition is None

    def test_task_with_all_params(self) -> None:
        """测试带所有参数的任务."""

        def my_func() -> RunResult:
            return RunResult(
                returncode=0, stdout="", stderr="", execution_time=0.0, cmd=[]
            )

        def my_condition() -> bool:
            return True

        task = Task(
            cmd=["echo", "hello"],
            func=my_func,
            condition=my_condition,
            description="测试任务",
            parallel=True,
            name="full-task",
            depends_on=["dep1", "dep2"],
        )

        assert task.cmd == ["echo", "hello"]
        assert task.func == my_func
        assert task.condition == my_condition
        assert task.description == "测试任务"
        assert task.parallel is True
        assert task.name == "full-task"
        assert task.depends_on == ["dep1", "dep2"]

    def test_is_executable_no_condition(self) -> None:
        """测试无条件时任务可执行."""
        task = Task(cmd=["test"], name="test")
        assert task.is_executable is True

    def test_is_executable_condition_true(self) -> None:
        """测试条件为 True 时任务可执行."""
        task = Task(cmd=["test"], name="test", condition=lambda: True)
        assert task.is_executable is True

    def test_is_executable_condition_false(self) -> None:
        """测试条件为 False 时任务不可执行."""
        task = Task(cmd=["test"], name="test", condition=lambda: False)
        assert task.is_executable is False

    def test_executable_cmd_returns_cmd(self) -> None:
        """测试可执行对象返回命令."""
        cmd = ["echo", "hello"]
        task = Task(cmd=cmd, name="test")
        assert task.executable_cmd == cmd

    def test_executable_cmd_returns_func(self) -> None:
        """测试可执行对象返回函数."""

        def my_func() -> RunResult:
            return RunResult(
                returncode=0, stdout="", stderr="", execution_time=0.0, cmd=[]
            )

        task = Task(func=my_func, name="test")
        assert task.executable_cmd == my_func

    def test_from_dict_minimal(self) -> None:
        """测试从最小字典创建任务."""
        config = {"cmd": ["echo", "hello"]}
        task = Task.from_dict(config)

        assert task.cmd == ["echo", "hello"]
        assert task.name == ""
        assert task.description == ""
        assert task.parallel is False
        assert task.depends_on == []

    def test_from_dict_full(self) -> None:
        """测试从完整字典创建任务."""

        def my_func() -> RunResult:
            return RunResult(
                returncode=0, stdout="", stderr="", execution_time=0.0, cmd=[]
            )

        config = {
            "name": "dict-task",
            "cmd": ["echo", "hello"],
            "func": my_func,
            "description": "从字典创建",
            "parallel": True,
            "depends_on": ["dep1"],
        }
        task = Task.from_dict(config)

        assert task.name == "dict-task"
        assert task.cmd == ["echo", "hello"]
        assert task.func == my_func
        assert task.description == "从字典创建"
        assert task.parallel is True
        assert task.depends_on == ["dep1"]

    @pytest.mark.parametrize(
        ("cmd", "name", "description", "parallel"),
        [
            (["echo", "hello"], "task1", "任务1", False),
            (["ls", "-l"], "task2", "任务2", True),
            (["pwd"], "task3", "", False),
        ],
    )
    def test_task_variants(
        self, cmd: list[str], name: str, description: str, parallel: bool
    ) -> None:
        """参数化测试不同任务变体."""
        task = Task(cmd=cmd, name=name, description=description, parallel=parallel)

        assert task.cmd == cmd
        assert task.name == name
        assert task.description == description
        assert task.parallel == parallel

    def test_task_repr(self) -> None:
        """测试任务字符串表示."""
        task = Task(cmd=["test"], name="test-task", description="测试")
        repr_str = repr(task)
        assert "test-task" in repr_str

    def test_task_equality(self) -> None:
        """测试任务相等性."""
        task1 = Task(cmd=["test"], name="test")
        task2 = Task(cmd=["test"], name="test")
        # dataclass 自动实现 __eq__
        assert task1 == task2

    def test_task_inequality(self) -> None:
        """测试任务不相等."""
        task1 = Task(cmd=["test1"], name="test1")
        task2 = Task(cmd=["test2"], name="test2")
        assert task1 != task2
