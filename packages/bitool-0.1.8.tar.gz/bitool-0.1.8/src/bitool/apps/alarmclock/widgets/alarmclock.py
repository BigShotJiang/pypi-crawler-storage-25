"""Alarmclock module for widgets."""

from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from functools import partial
from pathlib import Path

from PySide2.QtCore import Qt, QTime, QTimer
from PySide2.QtGui import QMoveEvent, QResizeEvent
from PySide2.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
)

from bitool.core import logger
from bitool.gui import apply_theme, open_theme_selector, setup_ui

__version__ = "0.1.3"

from ..config import conf
from .reminder import Reminder


class AlarmClock(QWidget):
    """数字闹钟 GUI 主窗口."""

    status_label: QLabel
    clock_label: QLabel
    set_button: QPushButton
    alarm_time_spinbox: QTimeEdit
    alarm_timer: QTimer
    theme_button: QPushButton
    repeat_checkbox: QCheckBox
    verticalLayout: QVBoxLayout

    def __init__(self) -> None:
        super().__init__()

        # 动态加载UI文件
        ui_file = Path(__file__).parent / "alarmclock.ui"
        setup_ui(self, ui_file)
        self.setGeometry(*conf.WIN_POS, *conf.WIN_SIZE)
        self.setWindowTitle(f"{conf.ALARM_CLOCK_TITLE} v{__version__}")
        self.status_label.setStyleSheet(
            "color: red; font-weight: bold; text-decoration: underline; font-style: italic;",
        )
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # 初始化数字时钟
        self._init_digital_clock()

        self._init_clock()
        self._init_alarm()
        self._setup_delay_buttons()
        self.set_button.clicked.connect(self.on_toggle_alarm)
        self.alarm_timer.timeout.connect(self.on_check_alarm)
        self.theme_button.clicked.connect(self._open_theme_selector)

        self.resize(self.minimumSize())
        apply_theme(self, conf.THEME)

    def _init_digital_clock(self) -> None:
        """初始化数字时钟显示组件."""
        self._clock_color = conf.DIGITAL_BORDER_COLORS[0]
        self.clock_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.clock_label.resize(*conf.CLOCK_SIZE)

        # 初始化时立即设置样式和当前时间
        current = datetime.now(timezone.utc) + timedelta(hours=8)
        self.clock_label.setStyleSheet(
            f"font: {conf.DIGITAL_FONT}; color: white; background-color: black; "
            f"border: 2px dashed {self._clock_color}; border-radius: 10px; padding: 10px;",
        )
        self.clock_label.setText(current.strftime(conf.DIGITAL_TIMER_FORMAT))

        # 初始化时钟定时器
        self._clock_timer = QTimer()
        self._clock_timer.timeout.connect(self._update_clock_time)
        self._clock_timer.start(conf.DIGITAL_UPDATE_INTERVAL)

    def _update_clock_time(self) -> None:
        """更新当前时间显示并添加闪烁效果."""
        current = datetime.now(timezone.utc) + timedelta(hours=8)

        # 先更新颜色
        self._clock_color = random.choice([c for c in conf.DIGITAL_BORDER_COLORS if c != self._clock_color])  # noqa: S311

        # 先设置样式，再设置文本，确保样式立即生效
        self.clock_label.setStyleSheet(
            f"font: {conf.DIGITAL_FONT}; color: white; background-color: black; "
            f"border: 2px dashed {self._clock_color}; border-radius: 10px; padding: 10px;",
        )

        # 最后设置文本内容
        self.clock_label.setText(current.strftime(conf.DIGITAL_TIMER_FORMAT))

    def _init_clock(self) -> None:
        """初始化闹钟时间设置组件."""
        self.alarm_time_spinbox.setDisplayFormat("HH:mm:ss")
        self.alarm_time_spinbox.setTime(
            QTime.currentTime().addSecs(conf.DELAY_STEPS[0] * 60),
        )

    def _init_alarm(self) -> None:
        """初始化闹钟相关组件和状态."""
        self.alarm_timer = QTimer()
        self.alarm_set = False
        self.alarm_time: QTime = QTime()
        self._alarm_triggered = False

    def _setup_delay_buttons(self) -> None:
        """设置延时按钮."""
        delay_layout = QHBoxLayout()
        delay_layout.addWidget(QLabel("延时 (分钟):"))
        for minutes in conf.DELAY_STEPS:
            button = QPushButton(str(minutes))
            button.clicked.connect(partial(self.set_delay, minutes))
            delay_layout.addWidget(button)
        reset_button = QPushButton("重置")
        reset_button.clicked.connect(self.reset_alarm_time)
        delay_layout.addWidget(reset_button)
        self.verticalLayout.insertLayout(1, delay_layout)

    def _open_theme_selector(self) -> None:
        """打开主题选择器对话框."""
        selected_theme = open_theme_selector(self, conf.THEME)
        if selected_theme:
            conf.THEME = selected_theme
            self.theme_button.setText(f"主题: {selected_theme}")
            apply_theme(self, selected_theme)
            self.status_label.setText(f"已应用主题: {selected_theme}")
            logger.info(f"已应用主题: {selected_theme}")

    def set_delay(self, minutes: int) -> None:
        """设置延时闹钟."""
        current_time = self.alarm_time_spinbox.time()
        new_time = current_time.addSecs(minutes * 60)
        self.alarm_time_spinbox.setTime(new_time)

    def reset_alarm_time(self) -> None:
        """重置闹钟时间为当前时间."""
        self.alarm_time_spinbox.setTime(QTime.currentTime())

    def on_toggle_alarm(self) -> None:
        """切换闹钟状态."""
        if self.alarm_set:
            self.alarm_set = False
            self.alarm_timer.stop()
            self.set_button.setText("设置闹钟")
            self.status_label.setText("闹钟已取消!")
            self._alarm_triggered = False
            return

        self.alarm_set = True
        self.set_button.setText("取消闹钟")
        self.alarm_time = self.alarm_time_spinbox.time()
        self.alarm_timer.start(1000)
        self.status_label.setText(f"闹钟已设置: {self.alarm_time.toString('HH:mm:ss')}")
        self._alarm_triggered = False

    def on_check_alarm(self) -> None:
        """检查是否到达闹钟时间."""
        if not self.alarm_set or self._alarm_triggered:
            return
        current_time = QTime.currentTime()
        secs_until_alarm = current_time.secsTo(self.alarm_time)
        if secs_until_alarm <= 0:
            self._alarm_triggered = True
            self.dialog = Reminder()
            self.dialog.finished.connect(self.on_dialog_closed)
            self.dialog.show()
            self.status_label.setText("⏰ 闹钟响了! ⏰")

    def on_dialog_closed(self) -> None:
        """处理对话框关闭事件."""
        if not self.repeat_checkbox.isChecked():
            self.on_toggle_alarm()
            return
        self._alarm_triggered = False
        self.status_label.setText(f"下次响铃: {self.alarm_time.toString('HH:mm:ss')}")

    def moveEvent(self, event: QMoveEvent) -> None:
        """处理窗口移动事件."""
        super().moveEvent(event)
        conf.WIN_POS = [self.x(), self.y()]

    def resizeEvent(self, event: QResizeEvent) -> None:
        """处理窗口 resize 事件."""
        super().resizeEvent(event)
        conf.WIN_SIZE = [self.width(), self.height()]
        conf.CLOCK_SIZE = [self.clock_label.width(), self.clock_label.height()]
        logger.info(f"更新 WIN_SIZE: {conf.WIN_SIZE}, CLOCK_SIZE: {conf.CLOCK_SIZE}")
