"""Tests for alarmclock module."""
