"""Test configuration for alarmclock tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from bitool.gui import clear_ui_cache

if TYPE_CHECKING:
    from collections.abc import Generator


@pytest.fixture(autouse=True)
def _() -> Generator[None, None, None]:
    """Clear UI loader cache before and after each test to prevent dangling pointer issues.

    This fixes the access violation error (exit code 3221225477) that occurs
    when multiple tests create AlarmClock instances consecutively. The cache
    may hold references to destroyed widgets, causing memory access violations.
    """
    # 测试前清除缓存，确保不使用已销毁的 widget 引用
    clear_ui_cache()
    yield
    # 测试后也清除缓存，保持干净状态
    clear_ui_cache()
