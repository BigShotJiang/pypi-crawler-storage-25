"""Docdiff module for docdiff."""

from __future__ import annotations

import argparse
import platform
import subprocess  # noqa: S404
import time
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Any

from bitool.core import JsonConfig, logger


class DocDiffConfig(JsonConfig):
    """Document comparison configuration."""

    DOC_DIFF_TITLE: str = "Comparison Result"
    OUTPUT_DIR: str = str(Path.home())  # Use current directory if empty
    COMPARE_MODE: str = "original"  # Options: original, revised
    SHOW_CHANGES: bool = True
    TRACK_REVISIONS: bool = True


conf = DocDiffConfig()


@dataclass(frozen=True)
class DiffDocCommand:
    """Document comparison command."""

    old_doc: Path
    new_doc: Path
    output_path: Path | None = None

    def run(self) -> None:
        """Run the document comparison command."""
        if not self._check_platform():
            return
        self._validate_input_files()
        self._validate_environment()
        self._execute_comparison()

    def _check_platform(self) -> bool:
        """Check if the current platform is Windows."""
        if platform.system() != "Windows":
            logger.error("This tool is only available on Windows.")
            return False
        return True

    def _validate_input_files(self) -> None:
        """Validate that input files exist and have correct extensions."""
        if not self.old_doc.exists():
            logger.error(f"Old file does not exist: {self.old_doc}")
            msg = f"Old file does not exist: {self.old_doc}"
            raise FileNotFoundError(msg)

        if not self.new_doc.exists():
            logger.error(f"New file does not exist: {self.new_doc}")
            msg = f"New file does not exist: {self.new_doc}"
            raise FileNotFoundError(msg)

        if not self.validate_files:
            logger.error("Invalid file paths or extensions")
            msg = "Invalid file paths or extensions"
            raise ValueError(msg)

    def _validate_environment(self) -> None:
        """Validate that Word application and comparison data are available."""
        if self.word_app is None:
            logger.error("Word application is not available")
            msg = "Word application is not available"
            raise RuntimeError(msg)

        if self.compare_data is None:
            msg = "Comparison failed"
            raise RuntimeError(msg)

    def _execute_comparison(self) -> None:
        """Execute the comparison and save the result."""
        self.output.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.compare_data.SaveAs2(str(self.output))
            self.compare_data.Close()
        except (OSError, RuntimeError):
            logger.exception("Comparison failed")
            raise
        else:
            logger.info(f"Comparison completed. Saved to: {self.output}")
        finally:
            self._cleanup()

    def _cleanup(self) -> None:
        """Clean up Word application resources."""
        self._close_word_documents()
        self._kill_word_process()

    def _close_word_documents(self) -> None:
        """Close Word documents and quit the application."""
        try:
            self.word_app.Documents.Close(SaveChanges=False)
        except (OSError, RuntimeError):
            logger.exception("Close document failed!")
        else:
            self.word_app.Quit()

    def _kill_word_process(self) -> None:
        """Force kill the WINWORD.EXE process."""
        try:
            subprocess.run(
                ["taskkill", "/f", "/t", "/im", "WINWORD.EXE"],  # noqa: S607 - 使用列表形式且 shell=False 是安全的
                check=False,
                shell=False,
            )
        except (subprocess.SubprocessError, OSError):
            logger.exception("Taskkill failed!")
        else:
            logger.info("Taskkill completed successfully")

    @cached_property
    def word_app(self) -> Any:  # noqa: ANN401
        """Start the Word application for document comparison."""
        try:
            import win32com.client as win32
        except ImportError:
            logger.exception("win32com.client is not installed, exiting.")
            raise
        else:
            logger.info("Started Word application")
            app = win32.gencache.EnsureDispatch("Word.Application")
            app.Visible = False
            app.DisplayAlerts = False

            try:
                app.Options.TrackRevisions = conf.TRACK_REVISIONS
            except AttributeError:
                logger.warning(
                    "TrackRevisions option not available in this Word version",
                )

            return app

    @cached_property
    def validate_files(self) -> bool:
        """Validate the input files for comparison."""
        return all(
            [
                self.old_doc.exists(),
                self.new_doc.exists(),
                self.old_doc.suffix.lower() in {".doc", ".docx"},
                self.new_doc.suffix.lower() in {".doc", ".docx"},
            ],
        )

    @cached_property
    def compare_data(self) -> Any:  # noqa: ANN401
        """Perform document comparison using Word application."""
        try:
            compared = self.word_app.CompareDocuments(
                self.old_doc_data,
                self.new_doc_data,
                0,
                2 if conf.COMPARE_MODE == "revised" else 0,
                True,  # noqa: FBT003
            )
        except (OSError, RuntimeError):
            logger.exception("Comparison failed")
            return None
        else:
            if compared:
                logger.info("Comparison completed successfully")
                compared.ShowRevisions = conf.SHOW_CHANGES
                return compared
            return None

    @cached_property
    def old_doc_data(self) -> Any:  # noqa: ANN401
        """Open the old document for comparison."""
        logger.info(f"Opening old file: {self.old_doc}")
        return self.word_app.Documents.Open(str(self.old_doc.resolve()))

    @cached_property
    def new_doc_data(self) -> Any:  # noqa: ANN401
        """Open the new document for comparison."""
        logger.info(f"Opening new file: {self.new_doc}")
        return self.word_app.Documents.Open(str(self.new_doc.resolve()))

    @cached_property
    def output(self) -> Path:
        """Determine the output directory for the comparison result."""
        output_filename = f"{conf.DOC_DIFF_TITLE}@{time.strftime('%Y%m%d_%H_%M_%S')}.docx"

        if self.output_path is None:
            output_dir = Path(conf.OUTPUT_DIR) if conf.OUTPUT_DIR else self.new_doc.parent
            return output_dir / output_filename

        if self.output_path.is_dir():
            return self.output_path / output_filename
        if self.output_path.is_file():
            return self.output_path
        msg = f"Invalid output path: {self.output_path}"
        raise ValueError(msg)


def parse_args() -> argparse.Namespace:
    """Parse command line arguments for document comparison."""
    parser = argparse.ArgumentParser(description="Compare two doc/docx files.")
    parser.add_argument(
        "files",
        nargs=2,
        help="Two input files to compare (old_file new_file)",
    )
    parser.add_argument(
        "-o",
        "--output",
        dest="output",
        default=".",
        help="Output file path",
    )
    parser.add_argument("--title", help="Title for the comparison result")
    parser.add_argument(
        "--show-changes",
        action="store_true",
        help="Show changes in the comparison",
    )
    parser.add_argument(
        "--hide-changes",
        action="store_true",
        help="Hide changes in the comparison",
    )
    parser.add_argument(
        "--compare-mode",
        choices=["original", "revised"],
        help="Compare mode: original or revised",
    )
    parser.add_argument("--output-dir", help="Output directory for the result file")

    args = parser.parse_args()

    # Update configuration from command line arguments
    if args.title:
        conf.DOC_DIFF_TITLE = args.title
    if args.show_changes:
        conf.SHOW_CHANGES = True
    if args.hide_changes:
        conf.SHOW_CHANGES = False
    if args.compare_mode:
        conf.COMPARE_MODE = args.compare_mode
    if args.output_dir:
        conf.OUTPUT_DIR = args.output_dir

    return args


def main() -> None:
    """Compare two doc/docx files."""
    args = parse_args()

    DiffDocCommand(
        Path(args.files[0]),
        Path(args.files[1]),
        Path(args.output),
    ).run()
