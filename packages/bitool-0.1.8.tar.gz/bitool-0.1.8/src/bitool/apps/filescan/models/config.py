"""文件扫描配置模块."""

from __future__ import annotations

from pathlib import Path
from typing import ClassVar

from bitool.core import JsonConfig

__all__ = ["conf"]

# 获取项目根目录
_ROOT_DIR = Path(__file__).parent


class FilescanConfig(JsonConfig):
    """文件扫描配置类."""

    # 资源目录路径
    _ASSETS_DIR: ClassVar[Path] = _ROOT_DIR / "assets"
    _DATA_DIR: ClassVar[Path] = _ROOT_DIR / "data"
    _STYLE_NAMES: list[str] = []  # noqa: RUF012

    # 数据库配置
    ENABLE_DB_PERSISTENCE: bool = True
    DB_FILENAME: str = "scan_results.db"

    # GUI 配置
    DEFAULT_FONT_FAMILY: str = "Microsoft YaHei"
    DEFAULT_FONT_SIZE: int = 8
    DEFAULT_SMALL_FONT_SIZE: int = 6
    FONT_BOLD: bool = True
    DEFAULT_THEME: str = "aqua"

    # 窗口配置
    WINDOW_SIZE: list[int] = [640, 480]  # noqa: RUF012
    WINDOW_POS: list[int] = [300, 200]  # noqa: RUF012

    # 最近使用的目录
    CURRENT_DIRECTORY: str = ""
    RECENT_DIRECTORIES: list[str] = []  # noqa: RUF012
    MAX_RECENT_DIRS: int = 10
    KEYWORDS: str = ""
    IGNORE_DIRS: list[str] = [  # noqa: RUF012
        "C:/Windows",
        "C:/Program Files",
        "C:/Program Files (x86)",
        "$RECYCLE.BIN",
        "System Volume Information",
        ".venv",
        ".git",
        "node_modules",
        "__pycache__",
        *[f"AutoCAD 20{year:02d}" for year in range(0, 30)],
        "ANSYS Inc",
    ]
    IGNORE_FILE_TYPES: list[str] = [  # noqa: RUF012
        ".tmp",
        ".log",
        ".txt",
        ".ini",
        ".bat",
        ".msi",
        ".exe",
        ".apk",
        ".jar",
        ".dll",
        ".so",
    ]

    # 文件计数线程配置
    MAX_WORKERS: int = 4  # 用于并行计数的最大工作线程数

    # 文档扫描配置
    DOC_FILE_TYPES: str = "pdf,docx,xlsx,pptx,txt,odt,rtf,epub,csv,xml,html,md,jpg,jpeg,png,gif,bmp,tiff"
    USE_ENGINES: list[str] = []  # 启用的解析引擎  # noqa: RUF012
    AVAILABLE_ENGINES: list[str] = []  # 可用的解析引擎  # noqa: RUF012
    USE_PDF_OCR: bool = False
    USE_IAMGE_OCR: bool = False
    USE_PROCESS_POOL: bool = False
    BATCH_SIZE: int = 50
    INCLUDE_IMAGE_FORMATS: bool = False

    # 规则配置
    RULES: dict = {  # noqa: RUF012
        "description": "默认扫描规则",
        "filename_rules": [
            {
                "name": "Public Rule",
                "description": "Public level",
                "patterns": [r"PUB", r"NORMAL"],
                "level": 1,
                "regex": True,
                "case_sensitive": False,
            },
            {
                "name": "INT Rule",
                "description": "Internal level",
                "patterns": [r"INT"],
                "level": 2,
                "regex": True,
                "case_sensitive": False,
            },
            {
                "name": "Conf Rule",
                "description": "Conf level",
                "patterns": [r"CONF"],
                "level": 3,
                "regex": True,
                "case_sensitive": False,
            },
            {
                "name": "Class Rule",
                "description": "Class level",
                "patterns": [r"CLAS"],
                "level": 4,
                "regex": True,
                "case_sensitive": False,
            },
            {
                "name": "SHOULD_NOT_CONTAIN",
                "description": "内容不允许包含指定内容",
                "patterns": [r"商业"],
                "level": 2,
                "regex": True,
                "case_sensitive": False,
            },
        ],
        "content_rules": [
            {
                "name": "SHOULD_NOT_CONTAIN",
                "description": "内容不允许包含指定内容",
                "patterns": [r"XX-\d{1,2}"],
                "level": 4,
                "regex": True,
                "case_sensitive": False,
            },
        ],
        "zipfile_rules": [],
    }


conf = FilescanConfig()
