"""Widgets module for filescan."""

from .. import resource_rc as resource_rc
