"""Filescanner Ui module for widgets."""

# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'filescanner.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from .. import resource_rc

class Ui_FileScanner(object):
    def setupUi(self, FileScanner):
        if not FileScanner.objectName():
            FileScanner.setObjectName(u"FileScanner")
        FileScanner.resize(640, 477)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(FileScanner.sizePolicy().hasHeightForWidth())
        FileScanner.setSizePolicy(sizePolicy)
        FileScanner.setMinimumSize(QSize(640, 300))
        icon = QIcon()
        icon.addFile(u":/assets/icons/filescan.png", QSize(), QIcon.Normal, QIcon.Off)
        FileScanner.setWindowIcon(icon)
        self.verticalLayout = QVBoxLayout(FileScanner)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.directory_groupbox = QGroupBox(FileScanner)
        self.directory_groupbox.setObjectName(u"directory_groupbox")
        self.verticalLayout_3 = QVBoxLayout(self.directory_groupbox)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.directory_combobox = QComboBox(self.directory_groupbox)
        self.directory_combobox.setObjectName(u"directory_combobox")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.directory_combobox.sizePolicy().hasHeightForWidth())
        self.directory_combobox.setSizePolicy(sizePolicy1)

        self.verticalLayout_3.addWidget(self.directory_combobox)

        self.current_file_layout = QHBoxLayout()
        self.current_file_layout.setObjectName(u"current_file_layout")
        self.current_file_label = QLabel(self.directory_groupbox)
        self.current_file_label.setObjectName(u"current_file_label")

        self.current_file_layout.addWidget(self.current_file_label)


        self.verticalLayout_3.addLayout(self.current_file_layout)

        self.progress_hlayout = QHBoxLayout()
        self.progress_hlayout.setObjectName(u"progress_hlayout")
        self.progress_layout = QHBoxLayout()
        self.progress_layout.setObjectName(u"progress_layout")
        self.filecount_label = QLabel(self.directory_groupbox)
        self.filecount_label.setObjectName(u"filecount_label")

        self.progress_layout.addWidget(self.filecount_label)

        self.progress_label = QLabel(self.directory_groupbox)
        self.progress_label.setObjectName(u"progress_label")

        self.progress_layout.addWidget(self.progress_label)

        self.progress_bar = QProgressBar(self.directory_groupbox)
        self.progress_bar.setObjectName(u"progress_bar")
        self.progress_bar.setMinimumSize(QSize(180, 0))
        self.progress_bar.setValue(0)

        self.progress_layout.addWidget(self.progress_bar)


        self.progress_hlayout.addLayout(self.progress_layout)


        self.verticalLayout_3.addLayout(self.progress_hlayout)


        self.verticalLayout.addWidget(self.directory_groupbox)

        self.operate_groupbox = QGroupBox(FileScanner)
        self.operate_groupbox.setObjectName(u"operate_groupbox")
        self.horizontalLayout_2 = QHBoxLayout(self.operate_groupbox)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.open_button = QPushButton(self.operate_groupbox)
        self.open_button.setObjectName(u"open_button")
        sizePolicy2 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.open_button.sizePolicy().hasHeightForWidth())
        self.open_button.setSizePolicy(sizePolicy2)
        self.open_button.setMinimumSize(QSize(0, 64))
        icon1 = QIcon()
        icon1.addFile(u":/assets/icons/folder.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.open_button.setIcon(icon1)
        self.open_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.open_button)

        self.analyse_button = QPushButton(self.operate_groupbox)
        self.analyse_button.setObjectName(u"analyse_button")
        sizePolicy2.setHeightForWidth(self.analyse_button.sizePolicy().hasHeightForWidth())
        self.analyse_button.setSizePolicy(sizePolicy2)
        self.analyse_button.setMinimumSize(QSize(0, 64))
        icon2 = QIcon()
        icon2.addFile(u":/assets/icons/search.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.analyse_button.setIcon(icon2)
        self.analyse_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.analyse_button)

        self.reanalyse_button = QPushButton(self.operate_groupbox)
        self.reanalyse_button.setObjectName(u"reanalyse_button")
        sizePolicy2.setHeightForWidth(self.reanalyse_button.sizePolicy().hasHeightForWidth())
        self.reanalyse_button.setSizePolicy(sizePolicy2)
        self.reanalyse_button.setMinimumSize(QSize(0, 64))
        icon3 = QIcon()
        icon3.addFile(u":/assets/icons/refresh.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.reanalyse_button.setIcon(icon3)
        self.reanalyse_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.reanalyse_button)

        self.stop_button = QPushButton(self.operate_groupbox)
        self.stop_button.setObjectName(u"stop_button")
        sizePolicy2.setHeightForWidth(self.stop_button.sizePolicy().hasHeightForWidth())
        self.stop_button.setSizePolicy(sizePolicy2)
        self.stop_button.setMinimumSize(QSize(0, 64))
        icon4 = QIcon()
        icon4.addFile(u":/assets/icons/stop.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.stop_button.setIcon(icon4)
        self.stop_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.stop_button)

        self.view_db_button = QPushButton(self.operate_groupbox)
        self.view_db_button.setObjectName(u"view_db_button")
        sizePolicy2.setHeightForWidth(self.view_db_button.sizePolicy().hasHeightForWidth())
        self.view_db_button.setSizePolicy(sizePolicy2)
        self.view_db_button.setMinimumSize(QSize(0, 64))
        icon5 = QIcon()
        icon5.addFile(u":/assets/icons/result.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.view_db_button.setIcon(icon5)
        self.view_db_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.view_db_button)

        self.config_button = QPushButton(self.operate_groupbox)
        self.config_button.setObjectName(u"config_button")
        sizePolicy2.setHeightForWidth(self.config_button.sizePolicy().hasHeightForWidth())
        self.config_button.setSizePolicy(sizePolicy2)
        self.config_button.setMinimumSize(QSize(0, 64))
        icon6 = QIcon()
        icon6.addFile(u":/assets/icons/config.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.config_button.setIcon(icon6)
        self.config_button.setIconSize(QSize(32, 32))

        self.horizontalLayout_2.addWidget(self.config_button)


        self.verticalLayout.addWidget(self.operate_groupbox)

        self.message_groupbox = QGroupBox(FileScanner)
        self.message_groupbox.setObjectName(u"message_groupbox")
        self.horizontalLayout = QHBoxLayout(self.message_groupbox)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.message_list_widget = QListWidget(self.message_groupbox)
        self.message_list_widget.setObjectName(u"message_list_widget")
        sizePolicy3 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.message_list_widget.sizePolicy().hasHeightForWidth())
        self.message_list_widget.setSizePolicy(sizePolicy3)

        self.horizontalLayout.addWidget(self.message_list_widget)


        self.verticalLayout.addWidget(self.message_groupbox)

        self.statusbar = QStatusBar(FileScanner)
        self.statusbar.setObjectName(u"statusbar")
        sizePolicy4 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy4.setHorizontalStretch(1)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.statusbar.sizePolicy().hasHeightForWidth())
        self.statusbar.setSizePolicy(sizePolicy4)
        self.statusbar.setMinimumSize(QSize(0, 20))

        self.verticalLayout.addWidget(self.statusbar)


        self.retranslateUi(FileScanner)

        QMetaObject.connectSlotsByName(FileScanner)
    # setupUi

    def retranslateUi(self, FileScanner):
        FileScanner.setWindowTitle(QCoreApplication.translate("FileScanner", u"\u6587\u4ef6\u641c\u7d22", None))
        self.directory_groupbox.setTitle(QCoreApplication.translate("FileScanner", u"\u641c\u7d22\u76ee\u5f55", None))
#if QT_CONFIG(tooltip)
        self.directory_combobox.setToolTip(QCoreApplication.translate("FileScanner", u"\u9009\u62e9\u641c\u7d22\u76ee\u5f55", None))
#endif // QT_CONFIG(tooltip)
        self.current_file_label.setText(QCoreApplication.translate("FileScanner", u"\u5f53\u524d\u6587\u4ef6[\u76ee\u5f55]\uff1a", None))
        self.filecount_label.setText(QCoreApplication.translate("FileScanner", u"\u6587\u4ef6\u603b\u6570\uff1a", None))
        self.progress_label.setText(QCoreApplication.translate("FileScanner", u"\u8fdb\u5ea6\uff1a", None))
        self.operate_groupbox.setTitle(QCoreApplication.translate("FileScanner", u"\u64cd\u4f5c", None))
#if QT_CONFIG(tooltip)
        self.open_button.setToolTip(QCoreApplication.translate("FileScanner", u"\u9009\u62e9\u6587\u4ef6\u5939", None))
#endif // QT_CONFIG(tooltip)
        self.open_button.setText(QCoreApplication.translate("FileScanner", u"\u6253\u5f00", None))
#if QT_CONFIG(tooltip)
        self.analyse_button.setToolTip(QCoreApplication.translate("FileScanner", u"\u5f00\u59cb\u5206\u6790", None))
#endif // QT_CONFIG(tooltip)
        self.analyse_button.setText(QCoreApplication.translate("FileScanner", u"\u5206\u6790", None))
#if QT_CONFIG(tooltip)
        self.reanalyse_button.setToolTip(QCoreApplication.translate("FileScanner", u"\u91cd\u65b0\u5206\u6790", None))
#endif // QT_CONFIG(tooltip)
        self.reanalyse_button.setText(QCoreApplication.translate("FileScanner", u"\u91cd\u65b0\u5206\u6790", None))
        self.stop_button.setText(QCoreApplication.translate("FileScanner", u"\u505c\u6b62", None))
#if QT_CONFIG(tooltip)
        self.view_db_button.setToolTip(QCoreApplication.translate("FileScanner", u"\u67e5\u770b\u6570\u636e\u5e93\u4e2d\u7684\u6587\u4ef6", None))
#endif // QT_CONFIG(tooltip)
        self.view_db_button.setText(QCoreApplication.translate("FileScanner", u"\u67e5\u770b\u6570\u636e\u5e93", None))
#if QT_CONFIG(tooltip)
        self.config_button.setToolTip(QCoreApplication.translate("FileScanner", u"\u914d\u7f6e\u9009\u9879", None))
#endif // QT_CONFIG(tooltip)
        self.config_button.setText(QCoreApplication.translate("FileScanner", u"\u8bbe\u7f6e", None))
        self.message_groupbox.setTitle(QCoreApplication.translate("FileScanner", u"\u6d88\u606f", None))
    # retranslateUi
