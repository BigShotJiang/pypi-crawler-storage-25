"""Tests for llmquantize module."""
