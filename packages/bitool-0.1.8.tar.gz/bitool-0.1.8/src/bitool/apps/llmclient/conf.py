"""Conf module for llmclient."""

from __future__ import annotations

from bitool.core import JsonConfig


class LLMClientConfig(JsonConfig):
    """LLM Chat client configuration with persistence support."""

    TITLE: str = "LLM 聊天客户端 v1.0"
    WIN_SIZE: list[int] = [900, 700]  # noqa: RUF012
    WIN_POS: list[int] = [100, 100]  # noqa: RUF012
    SERVER_URL: str = "http://localhost:8080"
    CONNECTION_TIMEOUT = 5
    MAX_TOKENS: int = 256
    TEMPERATURE: float = 0.7
    TOP_P: float = 0.9
    TOP_K: int = 40
    MAX_TOKENS_RANGE: list[int] = [1, 4096]  # noqa: RUF012
    TEMPERATURE_RANGE: list[float] = [0.0, 2.0]  # noqa: RUF012
    TOP_P_RANGE: list[float] = [0.0, 1.0]  # noqa: RUF012
    TOP_K_RANGE: list[int] = [1, 100]  # noqa: RUF012


conf = LLMClientConfig()
