"""Llmchat module for widgets."""

from __future__ import annotations

from dataclasses import dataclass

from PySide2.QtCore import QObject, Signal
from PySide2.QtGui import QMoveEvent, QResizeEvent
from PySide2.QtWidgets import QDoubleSpinBox, QLabel, QLineEdit, QListWidget, QPushButton, QWidget

from bitool.core import logger
from bitool.gui import load_ui

from ..conf import conf
from ..threads.connect import ConnectionTestWorker
from ..threads.llm import LLMWorker


@dataclass
class LLMRequestConfig:
    """LLM 请求配置"""

    prompt: str
    server_url: str
    max_tokens: int
    temperature: float
    top_p: float
    top_k: int


class LLMChat(QWidget):
    """LLM 聊天组件 包含核心业务逻辑

    提供与 LLM 服务器交互的流式对话功能
    支持实时响应显示和连接测试
    """

    # 自定义信号 用于更好的解耦
    connection_tested = Signal(bool, str)  # success, message
    response_started = Signal()
    response_updated = Signal(str)
    response_finished = Signal()
    error_occurred = Signal(str)

    url_edit: QLineEdit
    max_token_spin: QDoubleSpinBox
    temperature_spin: QDoubleSpinBox
    top_p_spin: QDoubleSpinBox
    top_k_spin: QDoubleSpinBox
    input_edit: QLineEdit
    history_list: QListWidget
    status_label: QLabel
    test_connection_button: QPushButton
    send_button: QPushButton
    stop_button: QPushButton
    clear_button: QPushButton

    def __init__(self) -> None:
        super().__init__()
        load_ui(parent=self)

        # 确保 UI 组件被正确设置为属性
        # 由于 QUiLoader 可能不会自动设置所有子控件为属性,我们手动查找并设置
        for child in self.findChildren(QObject):
            name = child.objectName()
            if name and not name.startswith("_") and not hasattr(self, name):
                setattr(self, name, child)

        self.setWindowTitle("LLM 聊天客户端 v1.0")
        self.setGeometry(*conf.WIN_POS, *conf.WIN_SIZE)

        self.worker_thread: LLMWorker | None = None
        self.test_thread: ConnectionTestWorker | None = None

        self.url_edit.setPlaceholderText("http://localhost:8080")
        self.url_edit.setText(conf.SERVER_URL)

        # 初始化最大令牌数
        self.max_token_spin.setValue(conf.MAX_TOKENS)
        self.max_token_spin.setRange(*conf.MAX_TOKENS_RANGE)
        self.max_token_spin.setSingleStep(1)

        # 初始化温度
        self.temperature_spin.setValue(conf.TEMPERATURE)
        self.temperature_spin.setRange(*conf.TEMPERATURE_RANGE)
        self.temperature_spin.setSingleStep(0.1)

        # 初始化 Top-P
        self.top_p_spin.setValue(conf.TOP_P)
        self.top_p_spin.setRange(*conf.TOP_P_RANGE)
        self.top_p_spin.setSingleStep(0.1)

        # 初始化 Top-K
        self.top_k_spin.setValue(conf.TOP_K)
        self.top_k_spin.setRange(*conf.TOP_K_RANGE)
        self.top_k_spin.setSingleStep(1)

        self.input_edit.setPlaceholderText("请输入问题")

        # 连接 UI 组件事件
        self._connect_ui_signals()

    def _connect_ui_signals(self) -> None:
        """连接 UI 组件事件到槽函数"""
        self.test_connection_button.clicked.connect(self.on_test_connection)
        self.send_button.clicked.connect(self.on_send_prompt)
        self.stop_button.clicked.connect(self.on_stop_generation)
        self.clear_button.clicked.connect(self.on_clear_history)
        self.input_edit.returnPressed.connect(self.on_send_prompt)

        # 连接参数变化事件
        self.max_token_spin.valueChanged.connect(self._on_max_tokens_changed)
        self.temperature_spin.valueChanged.connect(self._on_temperature_changed)
        self.top_p_spin.valueChanged.connect(self._on_top_p_changed)
        self.top_k_spin.valueChanged.connect(self._on_top_k_changed)

        # 连接 URL 变化事件
        self.url_edit.textChanged.connect(self._on_url_changed)

    def _on_url_changed(self, text: str) -> None:
        """处理 URL 变化"""
        conf.SERVER_URL = text.strip()

    def _on_max_tokens_changed(self, value: int) -> None:
        """处理最大令牌数变化"""
        conf.MAX_TOKENS = value

    def _on_temperature_changed(self, value: float) -> None:
        """处理温度变化"""
        conf.TEMPERATURE = value

    def _on_top_p_changed(self, value: float) -> None:
        """处理 Top-P 变化"""
        conf.TOP_P = value

    def _on_top_k_changed(self, value: int) -> None:
        """处理 Top-K 变化"""
        conf.TOP_K = value

    def on_clear_history(self) -> None:
        """清空对话历史"""
        if hasattr(self, "history_list"):
            self.history_list.clear()
        self.status_label.setText("就绪")

    def on_test_connection(self) -> None:
        """测试与 LLM 服务器的连接

        在后台线程中发送健康检查请求 避免阻塞 UI
        """
        server_url = self.url_edit.text().strip()
        if not server_url:
            self.status_label.setText("请输入服务器地址")
            return

        if self.test_thread and self.test_thread.isRunning():
            self.status_label.setText("等待响应...")
            return

        self.test_thread = ConnectionTestWorker(server_url)
        self.test_thread.result_ready.connect(self.on_connection_test_result)
        self.test_thread.finished.connect(self.on_test_connection_finished)

        self.status_label.setText("等待响应...")
        self.test_connection_button.setEnabled(False)

        self.test_thread.start()

    def on_test_connection_finished(self) -> None:
        """处理测试线程完成事件并清理资源"""
        if self.test_thread:
            self.test_thread.quit()
            self.test_thread.wait()
            self.test_thread = None

    def on_connection_test_result(self, success: bool, message: str) -> None:  # noqa: FBT001
        """处理连接测试结果

        Args:
            success: 连接是否成功
            message: 结果消息文本
        """
        if success:
            self.status_label.setText(f"连接成功!{message}")
        else:
            self.status_label.setText("连接失败")
        self.test_connection_button.setEnabled(True)

        # 发射信号供外部观察者使用
        self.connection_tested.emit(success, message)

    def on_stop_generation(self) -> None:
        """停止当前正在进行的响应生成"""
        if self.worker_thread and self.worker_thread.isRunning():
            self.worker_thread.stop()
            self.status_label.setText("生成已停止")

    def on_send_prompt(self) -> None:
        """发送用户提示到 LLM 服务器

        创建工作线程处理流式响应并更新 UI 显示对话
        """
        if self.worker_thread and self.worker_thread.isRunning():
            self.status_label.setText("等待响应...")
            return

        prompt = self.input_edit.text().strip()
        if not prompt:
            self.status_label.setText("请输入提示词")
            return

        server_url = self.url_edit.text().strip()
        max_tokens = int(self.max_token_spin.value())
        temperature = float(self.temperature_spin.value())
        top_p = float(self.top_p_spin.value())
        top_k = int(self.top_k_spin.value())

        self._display_user_input(prompt, server_url)
        self.input_edit.clear()

        logger.info(f"Sending prompt: {prompt}")
        logger.info(f"Parameters: max_tokens={max_tokens}, temperature={temperature}, top_p={top_p}, top_k={top_k}")

        # 创建请求配置
        config = LLMRequestConfig(
            prompt=prompt,
            server_url=server_url,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
        )

        self.worker_thread = LLMWorker(config=config)

        self.worker_thread.response_received.connect(self.update_response)
        self.worker_thread.error_occurred.connect(self.handle_error)
        self.worker_thread.is_finished.connect(self.on_finished)

        self.send_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_label.setText("正在生成响应...")

        self.worker_thread.start()

        # 发射信号供外部观察者使用
        self.response_started.emit()

    def _display_user_input(self, prompt: str, server_url: str) -> None:
        """在聊天区域显示用户输入和目标服务器"""
        # 添加用户消息
        self.history_list.addItem(f"用户: {prompt}")
        # 添加服务器信息
        self.history_list.addItem(f"[发送到 {server_url}]")
        # 不添加空的"AI:"项 - 让 update_response 处理
        self.history_list.scrollToBottom()

    def update_response(self, text: str) -> None:
        """更新聊天区域的 AI 响应内容

        Args:
            text: 完整的 AI 生成响应文本
        """
        # 检查最后一项是否为需要更新的 AI 消息
        if self.history_list.count() > 0:
            last_item = self.history_list.item(self.history_list.count() - 1)
            if last_item and last_item.text().startswith("AI:"):
                # 更新现有 AI 消息
                last_item.setText(f"AI: {text}")
            else:
                # 创建新的 AI 消息项
                self.history_list.addItem(f"AI: {text}")
        else:
            # 还没有项 创建第一条 AI 消息
            self.history_list.addItem(f"AI: {text}")

        self.history_list.scrollToBottom()

        # 发射信号供外部观察者使用
        self.response_updated.emit(text)

    def append_to_chat(self, text: str, *, is_user: bool = False) -> None:
        """追加文本到聊天区域

        Args:
            text: 要追加的文本内容
            is_user: 是否为用户消息 (用于颜色设置)
        """
        if hasattr(self, "history_list"):
            prefix = "用户: " if is_user else "AI: "
            self.history_list.addItem(f"{prefix}{text}")
            self.history_list.scrollToBottom()

    def handle_error(self, error_msg: str) -> None:
        """处理错误消息

        Args:
            error_msg: 错误消息文本
        """
        self.append_to_chat(f"Error: {error_msg}")
        self.status_label.setText(error_msg)

        # 发射信号供外部观察者使用
        self.error_occurred.emit(error_msg)

    def on_finished(self) -> None:
        """处理响应生成完成事件 恢复 UI 状态并清理资源"""
        self.send_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_label.setText("生成完成")

        # 发射信号供外部观察者使用
        self.response_finished.emit()

        if self.worker_thread:
            self.worker_thread.quit()
            self.worker_thread.wait()
            self.worker_thread = None

    def moveEvent(self, event: QMoveEvent) -> None:
        """处理窗口移动事件"""
        top_left = self.geometry().topLeft()
        conf.WIN_POS = [top_left.x(), top_left.y()]
        super().moveEvent(event)

    def resizeEvent(self, event: QResizeEvent) -> None:
        """处理窗口缩放事件"""
        geometry = self.geometry()
        conf.WIN_SIZE = [geometry.width(), geometry.height()]
        super().resizeEvent(event)
