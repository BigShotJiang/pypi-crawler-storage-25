"""Llm module for threads."""

from __future__ import annotations

import json
from codecs import IncrementalDecoder, getincrementaldecoder
from typing import TYPE_CHECKING, Iterable
from urllib.error import URLError
from urllib.request import Request

from PySide2.QtCore import QThread, Signal

from bitool.core import logger, urlopen_safe, validate_url

if TYPE_CHECKING:
    from ..widgets.llmchat import LLMRequestConfig


class LLMWorker(QThread):
    """LLM server communication worker thread.

    Handles HTTP streaming requests in background thread to avoid blocking UI main thread.
    Uses incremental UTF-8 decoder to correctly handle multi-byte characters across lines,
    preventing garbled text from truncated multi-byte characters.

    Signals:
        response_received: Emitted when response content is received, carries response text
        error_occurred: Emitted when error occurs, carries error message
        is_finished: Emitted when request completes
    """

    response_received = Signal(str)
    error_occurred = Signal(str)
    is_finished = Signal()

    def __init__(self, config: LLMRequestConfig) -> None:
        """Initialize LLM worker thread.

        Args:
            config: LLM request configuration containing all parameters
        """
        super().__init__()
        self.prompt = config.prompt
        self.server_url = config.server_url
        self.max_tokens = config.max_tokens
        self.temperature = config.temperature
        self.top_p = config.top_p
        self.top_k = config.top_k
        self._is_running = True

    def _process_streaming_line(self, line: bytes, decoder: IncrementalDecoder, buffer: str) -> tuple[str, bool]:
        """Process a single streaming response line.

        Args:
            line: Raw line bytes from response
            decoder: Incremental UTF-8 decoder object
            buffer: Current content buffer

        Returns
        -------
            Tuple of (updated_buffer, should_continue)
        """
        try:
            decoded_line = decoder.decode(line, final=False).strip()
            if not decoded_line:
                return buffer, True

            if decoded_line.startswith("data: "):
                json_str = decoded_line[6:]
                try:
                    json_data = json.loads(json_str)
                    content = json_data.get("content", "")
                    if content:
                        buffer += content
                        self.response_received.emit(buffer)
                except json.JSONDecodeError as e:
                    logger.debug(f"JSON parsing failed: {json_str}, error: {e}")
        except (UnicodeDecodeError, AttributeError) as e:
            logger.debug(f"Line processing failed: {e}")

        return buffer, True

    def _handle_streaming_response(self, response: Iterable[bytes]) -> None:
        """Handle streaming response content.

        Args:
            response: HTTP response object with streaming content
        """
        decoder = getincrementaldecoder("utf-8")(errors="replace")
        buffer = ""

        for line in response:
            if not self._is_running:
                break

            if line:
                buffer, _ = self._process_streaming_line(line, decoder, buffer)

        decoder.decode(b"", final=True)

    def run(self) -> None:
        """Execute streaming HTTP request and process response.

        Receives streaming response using Server-Sent Events (SSE) format.
        Uses incremental UTF-8 decoder to avoid garbled text from truncated multi-byte characters,
        ensuring full-chain character encoding consistency (request/response both use UTF-8).

        Security: Validates URL scheme before making request to prevent SSRF attacks.
        """
        try:
            # SECURITY: Validate URL scheme to prevent SSRF and local file access (CWE-22)
            # Only http/https schemes are permitted
            if not validate_url(self.server_url):
                self.error_occurred.emit("Invalid URL scheme: Only http/https allowed")
                return

            headers = {"Content-Type": "application/json; charset=utf-8"}
            data = {
                "prompt": self.prompt,
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "top_p": self.top_p,
                "top_k": self.top_k,
                "stream": True,
            }

            # Create Request object with validated URL (safe after validation above)
            request = Request(  # noqa: S310
                f"{self.server_url}/completion",
                data=json.dumps(data, ensure_ascii=False).encode("utf-8"),
                headers=headers,
            )

            # Open URL with validated scheme (double-checked in urlopen_safe)
            with urlopen_safe(request) as url_response:
                if not url_response.success or url_response.response is None:
                    self.error_occurred.emit(f"Error: {url_response.status} - Request failed")
                    return

                if url_response.status != 200:
                    error_text = url_response.response.read().decode("utf-8")
                    self.error_occurred.emit(f"Error: {url_response.status} - {error_text}")
                    return

                # Delegate streaming processing to dedicated method
                self._handle_streaming_response(url_response.response)

        except URLError as e:
            logger.exception(f"Connection error: {e.reason}")
            self.error_occurred.emit(f"Connection error: {e.reason}")
        except (OSError, RuntimeError):
            logger.exception("Request error")
            self.error_occurred.emit("Request error")
        finally:
            self.is_finished.emit()

    def stop(self) -> None:
        """Stop worker thread execution gracefully.

        Sets the internal flag to signal the worker thread to terminate its
        ongoing operations. The thread will complete its current iteration
        and exit cleanly.
        """
        self._is_running = False
