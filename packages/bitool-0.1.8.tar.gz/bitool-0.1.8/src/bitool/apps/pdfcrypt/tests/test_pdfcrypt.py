"""pdfcrypt模块单元测试"""

from pathlib import Path
from typing import Generator
from unittest.mock import Mock, patch

import pytest

from ..cli import (
    _cleanup_resources,
    _handle_output_file_conflict,
    _setup_pdf_writer,
    _validate_password_strength,
    decrypt_pdf,
    encrypt_pdf,
    is_encrypted,
    list_pdf,
)


@pytest.fixture
def sample_pdf(tmp_path: Path) -> Path:
    """创建用于测试的示例PDF文件"""
    from pypdf import PdfWriter

    pdf_path = tmp_path / "sample.pdf"
    writer = PdfWriter()
    writer.add_blank_page(width=200, height=200)
    with Path(pdf_path).open("wb") as f:
        writer.write(f)
    return pdf_path


class TestHelperFunctions:
    """辅助函数测试"""

    @patch("bitool.apps.pdfcrypt.cli.logger")
    def test_validate_password_strength_weak_password(self, mock_logger: Mock) -> None:
        """测试弱密码的密码强度验证"""
        _validate_password_strength("123")
        # 检查是否记录了警告
        mock_logger.warning.assert_called_once()
        call_args = mock_logger.warning.call_args[0][0]
        assert "密码长度小于" in call_args

    @patch("bitool.apps.pdfcrypt.cli.logger")
    def test_validate_password_strength_strong_password(self, mock_logger: Mock) -> None:
        """测试强密码的密码强度验证"""
        _validate_password_strength("strongpassword123")
        # 不应记录任何警告
        mock_logger.warning.assert_not_called()

    @patch("bitool.apps.pdfcrypt.cli.pypdf.PdfReader")
    @patch("bitool.apps.pdfcrypt.cli.pypdf.PdfWriter")
    def test_setup_pdf_writer(self, mock_writer_class: Mock, mock_reader: Mock) -> None:
        """测试PDF写入器设置函数"""
        mock_reader.pages = [Mock(), Mock()]  # Two mock pages
        mock_writer = Mock()
        mock_writer_class.return_value = mock_writer

        writer = _setup_pdf_writer(mock_reader)
        assert writer == mock_writer
        assert mock_writer.add_page.call_count == 2

    @patch("bitool.apps.pdfcrypt.cli.logger")
    def test_handle_output_file_conflict_exists(self, mock_logger: Mock, tmp_path: Path) -> None:
        """测试已存在输出文件的处理"""
        test_file = tmp_path / "test.txt"
        test_file.touch()  # Create the file
        _handle_output_file_conflict(test_file)
        # 检查是否记录了警告
        mock_logger.warning.assert_called_once()
        call_args = mock_logger.warning.call_args[0][0]
        assert "目标文件已存在" in call_args

    @patch("bitool.apps.pdfcrypt.cli.logger")
    def test_handle_output_file_conflict_not_exists(self, mock_logger: Mock, tmp_path: Path) -> None:
        """测试不存在输出文件的处理"""
        test_file = tmp_path / "nonexistent.txt"
        _handle_output_file_conflict(test_file)
        # 不应记录任何警告
        mock_logger.warning.assert_not_called()

    @patch("bitool.apps.pdfcrypt.cli.contextlib.suppress")
    def test_cleanup_resources_with_reader(self, mock_suppress: Mock) -> None:
        """测试读取器的资源清理"""
        mock_reader = Mock()
        mock_reader.stream.close = Mock()
        _cleanup_resources(reader=mock_reader)
        mock_reader.stream.close.assert_called_once()

    @patch("bitool.apps.pdfcrypt.cli.contextlib.suppress")
    def test_cleanup_resources_with_writer(self, mock_suppress: Mock) -> None:
        """测试写入器的资源清理"""
        mock_writer = Mock()
        mock_writer.close = Mock()
        _cleanup_resources(writer=mock_writer)
        mock_writer.close.assert_called_once()


class TestEncryptionDecryption:
    """加密和解密功能测试"""

    def test_is_encrypted_with_unencrypted_file(self, sample_pdf: Path) -> None:
        """测试未加密文件的is_encrypted函数"""
        result = is_encrypted(sample_pdf)
        assert result is False

    def test_encrypt_pdf_success(self, sample_pdf: Path, tmp_path: Path) -> None:
        """测试PDF加密成功"""
        password = "testpassword123"  # noqa: S105
        # 使用临时文件名避免冲突
        test_pdf = tmp_path / "test_sample.pdf"
        test_pdf.write_bytes(sample_pdf.read_bytes())

        original_path, encrypted_path = encrypt_pdf(test_pdf, password)

        assert original_path == test_pdf
        assert encrypted_path is not None
        assert encrypted_path.suffixes == [".enc", ".pdf"] or ".enc.pdf" in encrypted_path.name
        assert encrypted_path.exists()

    @patch("bitool.apps.pdfcrypt.cli.logger")
    def test_encrypt_pdf_weak_password(self, mock_logger: Mock, sample_pdf: Path) -> None:
        """测试弱密码PDF加密记录警告"""
        password = "weak"  # noqa: S105
        encrypt_pdf(sample_pdf, password)
        # Check that warning was logged
        # 查找包含密码消息的警告调用
        warning_calls = [call for call in mock_logger.warning.call_args_list if "密码长度小于" in call[0][0]]
        assert len(warning_calls) == 1

    def test_decrypt_pdf_wrong_password(self, sample_pdf: Path) -> None:
        """测试错误密码的PDF解密"""
        # 首先加密文件
        password = "correctpassword"  # noqa: S105
        _, encrypted_path = encrypt_pdf(sample_pdf, password)

        # 确保加密成功
        assert encrypted_path is not None

        # 尝试使用错误密码解密
        original_path, decrypted_path = decrypt_pdf(encrypted_path, "wrongpassword")
        assert original_path == encrypted_path
        assert decrypted_path is None

    def test_list_pdf_empty_directory(self, tmp_path: Path) -> None:
        """测试空目录中的PDF文件列表"""
        with patch("bitool.apps.pdfcrypt.cli.CWD", tmp_path):
            unencrypted, encrypted = list_pdf()
            assert unencrypted == []
            assert encrypted == []


class TestIntegration:
    """完整工作流集成测试"""

    @pytest.fixture
    def test_directory(self, tmp_path: Path) -> Generator[Path, None, None]:
        """创建包含示例文件的测试目录"""
        # 为测试更改工作目录
        original_cwd = Path.cwd()
        import os

        os.chdir(tmp_path)
        yield tmp_path
        os.chdir(original_cwd)

    def test_complete_encrypt_decrypt_cycle(self, test_directory: Path, sample_pdf: Path) -> None:
        """测试完整的加密解密循环"""
        password = "integrationtest123_example%@@"  # noqa: S105

        # 将示例PDF复制到测试目录
        test_pdf = test_directory / "test_document.pdf"
        test_pdf.write_bytes(sample_pdf.read_bytes())

        # 加密文件
        _original_path, encrypted_path = encrypt_pdf(test_pdf, password)
        assert encrypted_path is not None
        assert encrypted_path.exists()

        # 解密文件
        _decrypted_original, decrypted_path = decrypt_pdf(encrypted_path, password)
        assert decrypted_path is not None
        assert decrypted_path.exists()

        # 验证解密文件存在且有内容
        assert decrypted_path.stat().st_size > 0
