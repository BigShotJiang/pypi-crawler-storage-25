# PDFCrypt - PDF加密解密工具

强大的Python PDF加密解密工具, 具有强安全特性和批量处理能力

## 功能特性

- 🔐 **强加密**: 使用128位AES加密保护PDF安全
- 📚 **批处理**: 并发处理多个PDF文件
- ⚙️ **可配置**: 持久化配置并自动保存
- 🚀 **高性能**: 多线程处理加速操作
- 🛡️ **安全可靠**: 正确的资源清理和错误处理
- 📊 **性能监控**: 内置基准测试和分析

## 安装

```bash
pip install pytola-pdfcrypt
```

或从源码安装:

```bash
cd pytola/pdfcrypt
pip install .
```

## 快速开始

### 命令行使用

```bash
# 加密当前目录中所有未加密的PDF
pdfcrypt encrypt mysecretpassword

# 解密当前目录中所有已加密的PDF
pdfcrypt decrypt mysecretpassword

# 使用自定义工作线程数
pdfcrypt encrypt mypassword --workers 8
```

### Python API

```python
from pytola.office.pdfcrypt.cli import encrypt_pdf, decrypt_pdf, is_encrypted
from pathlib import Path

# 检查PDF是否已加密
pdf_file = Path("document.pdf")
if not is_encrypted(pdf_file):
    # 加密文件
    original, encrypted = encrypt_pdf(pdf_file, "mypassword")
    print(f"加密文件已保存为: {encrypted}")

# 解密文件
encrypted_file = Path("document.enc.pdf")
original, decrypted = decrypt_pdf(encrypted_file, "mypassword")
print(f"解密文件已保存为: {decrypted}")
```

## 配置

PDFCrypt自动将您的偏好设置保存到 `~/.pytola/pdfcrypt.json`:

```json
{
    "max_workers": 4,
    "default_password": "",
    "output_suffix_encrypted": ".enc.pdf",
    "output_suffix_decrypted": ".dec.pdf"
}
```

配置在启动时自动加载, 程序退出时自动保存

## 高级用法

### 自定义配置

```python
from pytola.office.pdfcrypt.cli import PDFCryptConfig, conf

# 修改配置
conf.max_workers = 8
conf.output_suffix_encrypted = ".protected.pdf"

# 访问缓存属性
print(f"配置已加载: {conf.is_configured}")
print(f"配置摘要: {conf.config_summary}")
```

### 批处理

```python
from pytola.office.pdfcrypt.cli import encrypt, decrypt
from pathlib import Path

# 设置密码并处理所有文件
encrypt(ex_pwd)  # 加密所有未加密的PDF
decrypt(ex_pwd)  # 解密所有已加密的PDF
```

## 性能

PDFCrypt针对性能进行了优化:

- **多线程**: 同时处理多个文件
- **内存高效**: 正确的资源清理防止内存泄漏
- **缓存配置**: 频繁访问的属性已缓存
- **基准测试**: 提供内置性能测试

运行基准测试:

```bash
python -m pytest pytola/pdfcrypt/tests/test_benchmark.py --benchmark-only -v
```

## 安全特性

- **强密码验证**: 弱密码警告 (少于6个字符)
- **128位AES加密**: 行业标准加密算法
- **安全资源处理**: 自动清理文件句柄
- **覆盖保护**: 目标文件已存在时警告

## 测试

运行单元测试:

```bash
python -m pytest pytola/pdfcrypt/tests/test_pdfcrypt.py -v
```

运行所有测试包括基准测试:

```bash
python -m pytest pytola/pdfcrypt/tests/ -v
```

## API参考

### 主要函数

- `encrypt_pdf(filepath: Path, password: str) -> tuple[Path, Path | None]`
- `decrypt_pdf(filepath: Path, password: str) -> tuple[Path, Path | None]`
- `is_encrypted(filepath: Path) -> bool`
- `encrypt(password: str) -> None`
- `decrypt(password: str) -> None`

### 配置

- `PDFCryptConfig`: 带缓存属性的配置数据类
- `conf`: 全局配置实例

### 辅助函数

- `_validate_password_strength(password: str) -> None`
- `_setup_pdf_writer(reader: pypdf.PdfReader) -> pypdf.PdfWriter`
- `_handle_output_file_conflict(filepath: Path) -> None`
- `_cleanup_resources(reader=None, writer=None) -> None`

## 依赖要求

- Python >= 3.8
- pypdf >= 3.0.0
- 标准库模块: argparse, logging, pathlib, json

## 贡献指南

1. Fork仓库
2. 创建功能分支
3. 为新功能添加测试
4. 确保所有测试通过
5. 提交拉取请求

## 许可证

MIT许可证 - 详见LICENSE文件

## 更新日志

### v1.0.0

- 初始发布
- 核心加密解密功能
- 批处理支持
- 配置持久化
- 全面的测试套件
- 性能基准测试
