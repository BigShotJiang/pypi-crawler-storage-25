# QuizTrainer 答题系统规范

## 1. 项目概述

**项目名称**: QuizTrainer
**项目类型**: Web 答题训练系统
**核心功能**: 支持判断题、选择题、填空题、问答题的在线练习与测评
**目标用户**: 学生、考生、培训学员

## 2. 技术栈

- **后端框架**: Flask 3.x
- **模板引擎**: Jinja2
- **数据格式**: JSON
- **数据存储**: `~/.quiztrainer/` 目录
- **样式风格**: 参考 pyprofiler 现代卡片式设计

## 3. 界面设计规范

### 3.1 视觉风格

- 参考 pyprofiler 的设计语言
- 主色调: 紫色渐变 (`#667eea` → `#764ba2`)
- 现代卡片式布局
- 支持暗色模式

### 3.2 CSS 设计系统

#### 颜色变量

```css
:root {
    /* 背景色 */
    --bg-body: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --bg-primary: #ffffff;
    --bg-secondary: #f8fafc;
    --bg-card: #ffffff;

    /* 文字颜色 */
    --text-primary: #2c3e50;
    --text-secondary: #4a5568;
    --text-muted: #718096;

    /* 强调色 */
    --accent: #667eea;
    --accent-light: #e8ecf4;

    /* 边框 */
    --border: #e1e8ed;
    --border-light: #f0f0f0;

    /* 阴影 */
    --shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    --shadow-card: 0 2px 8px rgba(0, 0, 0, 0.08);
}
```

### 3.3 组件样式

- **卡片**: 白色背景，圆角 8px，轻微阴影
- **按钮**: 渐变背景，悬停效果
- **输入框**: 浅灰背景，圆角 6px
- **导航栏**: 侧边固定导航

## 4. 数据结构

### 4.1 题库数据 (`~/.quiztrainer/questions/`)

#### 题目 JSON 结构

```json
{
    "id": "q001",
    "type": "choice", // choice | truefalse | fill | essay
    "category": "Python基础",
    "difficulty": "easy", // easy | medium | hard
    "question": "以下哪个是 Python 的列表数据类型？",
    "options": ["{1, 2, 3}", "[1, 2, 3]", "(1, 2, 3)", "<1, 2, 3>"],
    "answer": "B",
    "explanation": "列表使用方括号 [...] 表示"
}
```

#### 判断题结构

```json
{
    "id": "q002",
    "type": "truefalse",
    "question": "Python 是一种编译型语言",
    "answer": false,
    "explanation": "Python 是一种解释型语言"
}
```

#### 填空题结构

```json
{
    "id": "q003",
    "type": "fill",
    "question": "Python 中用于输出内容的函数是 ___()",
    "answer": "print",
    "explanation": "print() 是 Python 的标准输出函数"
}
```

#### 问答题结构

```json
{
    "id": "q004",
    "type": "essay",
    "question": "请简述 Python 列表和元组的区别",
    "answer": "列表是可变的，元组是不可变的",
    "explanation": "列表和元组的主要区别在于是否可变"
}
```

### 4.2 用户数据 (`~/.quiztrainer/user_data/`)

#### 用户答题记录

```json
{
    "user_id": "default",
    "history": [
        {
            "question_id": "q001",
            "answer": "B",
            "is_correct": true,
            "timestamp": "2024-01-15T10:30:00"
        }
    ],
    "statistics": {
        "total_questions": 100,
        "correct_count": 85,
        "category_stats": {
            "Python基础": { "total": 50, "correct": 45 }
        }
    }
}
```

## 5. 功能模块

### 5.1 首页/题库浏览

- 展示所有题库分类
- 显示每个分类的题目数量
- 支持按分类筛选

### 5.2 答题模式

- **练习模式**: 单题练习，即时反馈
- **考试模式**: 限时答题，最后统一提交
- **错题本**: 记录错题，便于复习

### 5.3 答题流程

1. 选择题目类型和分类
2. 显示题目内容
3. 用户作答
4. 即时显示正确答案和解析
5. 记录答题结果

### 5.4 统计面板

- 总答题数、正确率
- 分类统计
- 学习进度可视化

### 5.5 题库导入

- **Word 文档导入**: 支持从 .docx 文件批量导入题目
- **JSON 导入**: 支持从 JSON 文件导入题目
- **智能解析**: 自动识别题型、判断题、选择题、填空题、问答题
- **预览功能**: 导入前预览成功/失败的题目
- **格式容错**: 支持多种题目格式

#### Word 文档格式支持

**选择题格式**:

```
1. 以下哪个是 Python 的列表？
A. {1, 2, 3}
B. [1, 2, 3]
C. (1, 2, 3)
答案: B
```

**判断题格式**:

```
1. Python 是一种编译型语言。（答案：错）
2. [判断] Python 是解释型语言。
   答案: 对
```

**填空题格式**:

```
1. Python 中输出函数是 ___()
答案: print
```

**问答题格式**:

```
1. [问答] 请简述列表和元组的区别。
答案: 列表是可变的，元组是不可变的。
```

## 6. 页面路由

| 路由         | 功能          |
| ------------ | ------------- |
| `/`          | 首页/题库列表 |
| `/quiz`      | 开始答题      |
| `/quiz/<id>` | 单题练习      |
| `/quiz/exam` | 考试模式      |
| `/history`   | 答题历史      |
| `/stats`     | 统计面板      |
| `/admin`     | 题库管理      |

## 7. 文件结构

```text
quiztrainer/
├── pyproject.toml
├── README.md
├── cli.py                 # CLI入口
├── app.py                 # Flask应用
├── models.py              # 数据模型
├── core.py                # 核心业务逻辑
├── templates/
│   ├── base.html          # 基础模板
│   ├── index.html         # 首页
│   ├── quiz.html          # 答题页面
│   ├── result.html        # 结果页面
│   ├── stats.html         # 统计页面
│   └── admin.html         # 管理页面
└── static/
    └── css/
        └── style.css      # 样式文件
```

## 8. 验收标准

- [x] 支持四种题型: 判断题、选择题、填空题、问答题
- [x] 使用 Jinja2 模板引擎
- [x] 数据存储为 JSON 格式
- [x] 数据目录位于 `~/.quiztrainer/`
- [x] 界面风格参考 pyprofiler
- [x] 支持答题记录和统计
- [x] 支持暗色模式
