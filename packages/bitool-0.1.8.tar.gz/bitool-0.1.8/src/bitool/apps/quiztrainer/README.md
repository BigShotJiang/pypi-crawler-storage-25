# QuizTrainer - 在线答题训练系统

基于 Flask + Jinja2 的现代化答题系统，支持多种题型和数据分析。

## 功能特性

- **多种题型支持**: 判断题、选择题、填空题、问答题
- **练习模式**: 即时反馈，附带详细解析
- **考试模式**: 限时答题，模拟考试环境
- **统计分析**: 详细的学习数据统计和进度追踪
- **题库管理**: 便捷的题库导入导出功能
- **Word导入**: 支持从 Word 文档批量导入题目，预览成功/失败内容
- **现代化界面**: 参考 pyprofiler 设计风格，支持暗色模式

## 安装

```bash
pip install flask python-docx
pip install -e .
```

## 使用方法

### 启动 Web 服务

```bash
quiztrainer web
# 或指定端口
quiztrainer web --port 8080
```

### 命令行操作

```bash
# 列出所有题库
quiztrainer list

# 查看学习统计
quiztrainer stats

# 添加题目
quiztrainer add python_basics -q "Python 中 print 函数的作用是？" -a "B" -t choice

# 从 Word 文档导入题库
quiztrainer import-word questions.docx --category "Python基础" --difficulty medium

# 预览 Word 文档内容（不导入）
quiztrainer import-word questions.docx --preview --max-preview 20

# 导入 JSON 题库
quiztrainer import questions.json

# 导出题库
quiztrainer export python_basics backup.json
```

### Web 界面导入

访问 `/import` 页面，可以：

1. 上传 Word 文档或 JSON 文件
2. 设置默认分类和难度
3. 预览解析结果（成功/失败的题目）
4. 确认导入

## 数据存储

所有数据存储在 `~/.quiztrainer/` 目录下:

```
~/.quiztrainer/
├── questions/          # 题库文件
│   └── python_basics.json
└── user_data/          # 用户数据
    └── default.json
```

## 题库格式

### 选择题

```json
{
    "id": "q001",
    "type": "choice",
    "category": "Python基础",
    "difficulty": "easy",
    "question": "以下哪个是 Python 的列表数据类型？",
    "options": ["{1, 2, 3}", "[1, 2, 3]", "(1, 2, 3)", "<1, 2, 3>"],
    "answer": "B",
    "explanation": "列表使用方括号 [] 表示"
}
```

### 判断题

```json
{
    "id": "q002",
    "type": "truefalse",
    "question": "Python 是一种编译型语言",
    "answer": false,
    "explanation": "Python 是一种解释型语言"
}
```

### 填空题

```json
{
    "id": "q003",
    "type": "fill",
    "question": "Python 中用于输出内容的函数是 ___()",
    "answer": "print",
    "explanation": "print() 是 Python 的标准输出函数"
}
```

### 问答题

```json
{
    "id": "q004",
    "type": "essay",
    "question": "请简述 Python 列表和元组的主要区别",
    "answer": "列表是可变的，元组是不可变的",
    "explanation": "列表和元组的主要区别在于是否可变"
}
```

## 技术栈

- **后端**: Flask 3.x
- **模板引擎**: Jinja2
- **数据存储**: JSON
- **样式**: CSS3 (参考 pyprofiler 设计风格)

## License

MIT License
