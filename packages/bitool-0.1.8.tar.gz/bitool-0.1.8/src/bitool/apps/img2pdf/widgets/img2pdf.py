"""图像转 PDF 的图形用户界面."""

from __future__ import annotations

import concurrent.futures
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar

from PIL import Image
from PIL.Image import Resampling
from PySide2.QtCore import QObject, QThread, Signal
from PySide2.QtGui import QCloseEvent, QMoveEvent, QResizeEvent
from PySide2.QtWidgets import (
    QFileDialog,
    QMessageBox,
    QWidget,
)

from bitool.core import JsonConfig, logger
from bitool.gui import apply_theme, setup_ui

if TYPE_CHECKING:
    pass

__version__ = "0.1.0"


@dataclass
class Img2PdfConfig:
    """图像转 PDF GUI 配置(支持持久化)."""

    input_path: str = str(Path.cwd())
    dpi: int = 300
    normalize: bool = True
    win_pos: list[int] = field(default_factory=lambda: [100, 100])
    win_size: list[int] = field(default_factory=lambda: [800, 700])
    recent_input_paths: list[str] = field(default_factory=list)


# 图像格式魔数（模块级常量，避免被 JsonConfig 序列化）
MAGIC_NUMBERS: dict[str, bytes] = {
    "jpg": b"\xff\xd8\xff",
    "jpeg": b"\xff\xd8\xff",
    "png": b"\x89PNG\r\n\x1a\n",
    "gif": b"GIF87a",
    "bmp": b"BM",
    "webp": b"RIFFf\x00\x00\x00WEBP",
    "tiff": b"II*\x00",
    "ico": b"ICON",
    "svg": b"<svg",
}


class ImageToPdfConfig(JsonConfig):
    """图像转 PDF 转换配置."""

    DPI: int = 300
    EXTENSIONS: ClassVar[set[str]] = {
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".bmp",
        ".webp",
        ".tiff",
        ".ico",
    }


conf = ImageToPdfConfig()

# GUI配置
gui_conf = Img2PdfConfig()


def is_valid_image(file_path: Path) -> bool:
    """验证图像文件."""
    try:
        stat_result = file_path.stat()
        if stat_result.st_size == 0:
            logger.debug(f"空文件: {file_path}")
            return False
    except OSError:
        logger.debug(f"文件不存在或无法访问: {file_path}")
        return False

    ext = file_path.suffix.lower()
    if not conf.EXTENSIONS or ext not in conf.EXTENSIONS:
        logger.debug(f"无效的图像扩展名: {ext}, {file_path}")
        return False

    try:
        with file_path.open("rb") as f:
            header = f.read(16)
            if ext == ".webp":
                if not (header.startswith(b"RIFF") and header[8:12] == b"WEBP"):
                    logger.debug(f"无效的 WebP 文件头: {header[:12]}")
                    return False
            else:
                non_webp_magic = {k: v for k, v in MAGIC_NUMBERS.items() if k != "webp"}
                if not any(header.startswith(v) for v in non_webp_magic.values()):
                    logger.debug(f"无效的图像文件头: {header[:8]}")
                    return False
    except OSError:
        logger.debug(f"无法读取文件头: {file_path}")
        return False

    logger.info(f"有效图像: {file_path}")
    return True


@dataclass(frozen=True)
class ImageToPDFRunner:
    """图像转 PDF 转换器."""

    root_dir: Path
    dpi: int
    normalize: bool = True

    def run(self) -> None:
        """执行图像转 PDF 转换流程."""
        logger.info(f"开始转换, 使用 dpi={self.dpi}")
        converted_images = self.converted_images
        if not converted_images:
            logger.error(f"在 {self.root_dir} 中未找到已转换的图像文件")
            return

        converted_images[0].save(
            self.output_pdf,
            "PDF",
            resolution=100.0,
            save_all=True,
            append_images=converted_images[1:],
            optimize=True,
        )
        logger.info(f"已创建 PDF 文件: {self.output_pdf}")

    @cached_property
    def output_pdf(self) -> Path:
        """获取输出 PDF 文件路径."""
        return self.root_dir / f"{self.root_dir.name}.pdf"

    @cached_property
    def page_size(self) -> tuple[int, int]:
        """基于 DPI 设置获取页面尺寸."""
        return (int(8.27 * self.dpi), int(11.69 * self.dpi))

    @cached_property
    def converted_images(self) -> list[Image.Image]:
        """将所有图像文件转换为 PIL Image 对象."""
        batch_size = 10
        all_results = []

        for i in range(0, len(self.image_files), batch_size):
            batch = self.image_files[i : i + batch_size]
            logger.info(
                f"处理批次 {i // batch_size + 1}/{(len(self.image_files) - 1) // batch_size + 1}",
            )

            with concurrent.futures.ThreadPoolExecutor(
                max_workers=min(len(batch), 4),
            ) as executor:
                futures = [executor.submit(self._convert, file, normalize=self.normalize) for file in batch]

                batch_results = []
                for future in futures:
                    result = future.result()
                    if result is not None:
                        batch_results.append(result)

                all_results.extend(batch_results)

        return all_results

    @cached_property
    def image_files(self) -> list[Path]:
        """获取根目录中的有效图像文件列表."""
        all_files = list(self.root_dir.iterdir())
        image_filepath = sorted([file for file in all_files if is_valid_image(file)])

        if not image_filepath:
            logger.warning(f"在 {self.root_dir} 中未找到有效图像文件")
            logger.info(f"目录中的文件总数: {len(all_files)}")
            return []
        logger.info(
            f"找到 {len(image_filepath)} 个有效图像文件, 共 {len(all_files)} 个文件",
        )

        return image_filepath

    def _convert(
        self,
        filepath: Path,
        *,
        normalize: bool = True,
    ) -> Image.Image | None:
        """转换图像为 PDF 格式."""
        try:
            img = Image.open(str(filepath))
            if img.mode in {"RGBA", "LA", "P"}:
                rgb_img = Image.new("RGB", img.size, (255, 255, 255))
                processed_img = img.convert("RGBA") if img.mode == "P" and "transparency" in img.info else img
                if processed_img.mode in {"RGBA", "LA"}:
                    rgb_img.paste(processed_img, mask=processed_img.split()[-1])
                else:
                    rgb_img.paste(processed_img)
                image = rgb_img
            else:
                image = img.convert("RGB")
            img.close()
        except (OSError, RuntimeError, ValueError):
            logger.exception(f"无法打开图像 {filepath}")
            return None

        if normalize:
            logger.info(f"规范化图像: {filepath}")
            rotated_image = self._auto_rotate_image(image)
            scaled_image = self._auto_scale_image(rotated_image)
            scaled_image.thumbnail(self.page_size, Resampling.LANCZOS)

            converted_image = Image.new(
                "RGB",
                self.page_size,
                (255, 255, 255),
            )
            converted_image.paste(
                scaled_image,
                (
                    (self.page_size[0] - scaled_image.size[0]) // 2,
                    (self.page_size[1] - scaled_image.size[1]) // 2,
                ),
            )
            logger.info(f"图像已规范化: {filepath}")
        else:
            converted_image = image

        logger.debug(f"成功转换图像: {filepath}")
        return converted_image

    def _auto_rotate_image(self, image: Image.Image) -> Image.Image:
        """自动旋转图像以校正方向."""
        width, height = image.size
        if width > height:
            image = image.rotate(90, expand=True)
        return image

    def _auto_scale_image(self, image: Image.Image) -> Image.Image:
        """自动缩放图像以适应页面尺寸."""
        if image.size[0] < self.page_size[0] or image.size[1] < self.page_size[1]:
            scale_w = self.page_size[0] / image.size[0]
            scale_h = self.page_size[1] / image.size[1]
            scale = max(scale_w, scale_h)
            new_size = (int(image.size[0] * scale), int(image.size[1] * scale))
            image = image.resize(new_size, Resampling.LANCZOS)
        return image


@dataclass
class Img2PdfConfig:
    """图像转 PDF GUI 配置(支持持久化)."""

    input_path: str = str(Path.cwd())
    dpi: int = 300
    normalize: bool = True
    win_pos: list[int] = field(default_factory=lambda: [100, 100])
    win_size: list[int] = field(default_factory=lambda: [800, 700])
    recent_input_paths: list[str] = field(default_factory=list)


class WorkerSignals(QObject):
    """工作线程信号."""

    progress_message = Signal(str)
    progress_update = Signal(int, int)
    finished = Signal(dict)
    error = Signal(str)


class ConversionWorker(QThread):
    """在后台运行图像转换的工作线程."""

    def __init__(
        self,
        root_dir: Path,
        dpi: int,
        *,
        normalize: bool,
    ) -> None:
        """初始化工作线程."""
        super().__init__()
        self.root_dir = root_dir
        self.dpi = dpi
        self.normalize = normalize
        self.signals = WorkerSignals()

    def run(self) -> None:
        """运行图像转换."""
        try:
            self.signals.progress_message.emit("开始转换...")

            runner = ImageToPDFRunner(
                root_dir=self.root_dir,
                dpi=self.dpi,
                normalize=self.normalize,
            )

            # 获取图像文件列表
            image_files = runner.image_files
            total = len(image_files)

            if total == 0:
                self.signals.error.emit("在目录中未找到有效图像文件")
                return

            self.signals.progress_message.emit(f"找到 {total} 个图像文件")

            # 模拟进度更新(因为转换是批处理的)
            for i in range(total):
                self.signals.progress_update.emit(i + 1, total)
                self.signals.progress_message.emit(f"正在处理图像 {i + 1}/{total}...")

            # 执行转换
            runner.run()

            result = {
                "success": True,
                "files_processed": total,
                "output_path": str(runner.output_pdf),
            }

            self.signals.progress_message.emit("转换完成!")
            self.signals.finished.emit(result)

        except (OSError, ValueError, RuntimeError) as e:
            self.signals.error.emit(str(e))


class Img2PdfConverter(QWidget):
    """图像转 PDF 转换器主窗口."""

    inputEdit: Any
    browseButton: Any
    dpiSpinBox: Any
    normalizeCheckBox: Any
    convertButton: Any
    progressBar: Any
    logTextEdit: Any

    def __init__(self) -> None:
        """初始化 GUI 组件."""
        super().__init__()

        # 动态加载 UI 文件
        ui_file = Path(__file__).parent / "img2pdf.ui"
        setup_ui(self, ui_file)

        self.setGeometry(*gui_conf.win_pos, *gui_conf.win_size)
        self.setWindowTitle(f"图像转 PDF 转换器 v{__version__}")

        # 初始化控件
        self._init_controls()

        # 连接信号
        self.browseButton.clicked.connect(self._browse_input)
        self.convertButton.clicked.connect(self._start_conversion)

        # 应用主题
        apply_theme(self, "aqua")

        self.conversion_worker = None
        self.is_converting = False

        # 加载配置
        self._load_config()

    def _init_controls(self) -> None:
        """初始化控件状态."""
        self.inputEdit.setText(str(Path.cwd()))
        self.dpiSpinBox.setValue(300)
        self.normalizeCheckBox.setChecked(True)
        self.progressBar.setValue(0)

    def _browse_input(self) -> None:
        """浏览选择输入目录."""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "选择图像目录",
            self.inputEdit.text() or str(Path.cwd()),
        )
        if dir_path:
            self.inputEdit.setText(str(Path(dir_path)))

    def _start_conversion(self) -> None:
        """开始图像转换."""
        # 验证输入
        input_path = Path(self.inputEdit.text())
        if not input_path.exists():
            QMessageBox.warning(self, "错误", "目录不存在!")
            return

        if not input_path.is_dir():
            QMessageBox.warning(self, "错误", "路径不是目录!")
            return

        # 获取选项
        dpi = self.dpiSpinBox.value()
        normalize = self.normalizeCheckBox.isChecked()

        # 清除之前的结果
        self.logTextEdit.clear()
        self.progressBar.setValue(0)

        # 禁用转换按钮
        self.is_converting = True
        self.convertButton.setEnabled(False)

        # 创建并启动工作线程
        self.conversion_worker = ConversionWorker(
            input_path,
            dpi,
            normalize=normalize,
        )
        self.conversion_worker.signals.progress_message.connect(self._log_message)
        self.conversion_worker.signals.progress_update.connect(self._update_progress)
        self.conversion_worker.signals.finished.connect(self._conversion_finished)
        self.conversion_worker.signals.error.connect(self._conversion_error)
        self.conversion_worker.start()

    def _conversion_finished(self, result: dict[str, Any]) -> None:
        """处理转换完成."""
        self.is_converting = False
        self.convertButton.setEnabled(True)
        self.progressBar.setValue(100)

        files_count = result.get("files_processed", 0)
        output_path = result.get("output_path", "")

        self._log_message(f"成功转换 {files_count} 个文件")
        self._log_message(f"输出位置: {output_path}")

        QMessageBox.information(
            self,
            "成功",
            f"转换完成!\n{files_count} 个图像已转换为 PDF 格式.",
        )

        # 保存配置
        self._save_config()

    def _conversion_error(self, error_msg: str) -> None:
        """处理转换错误."""
        self.is_converting = False
        self.convertButton.setEnabled(True)
        self._log_message(f"错误: {error_msg}")
        QMessageBox.critical(self, "错误", f"转换失败: {error_msg}")

    def _update_progress(self, current: int, total: int) -> None:
        """更新进度条."""
        if total > 0:
            percentage = int((current / total) * 100)
            self.progressBar.setValue(percentage)

    def _log_message(self, message: str) -> None:
        """添加消息到日志."""
        timestamp = datetime.now(tz=timezone.utc).strftime("%H:%M:%S")
        self.logTextEdit.append(f"[{timestamp}] {message}")

    def _load_config(self) -> None:
        """加载配置."""
        self.inputEdit.setText(gui_conf.input_path)
        self.dpiSpinBox.setValue(gui_conf.dpi)
        self.normalizeCheckBox.setChecked(gui_conf.normalize)

    def _save_config(self) -> None:
        """保存配置."""
        gui_conf.input_path = self.inputEdit.text()
        gui_conf.dpi = self.dpiSpinBox.value()
        gui_conf.normalize = self.normalizeCheckBox.isChecked()

    def moveEvent(self, event: QMoveEvent) -> None:
        """处理窗口移动事件."""
        super().moveEvent(event)
        gui_conf.win_pos = [self.x(), self.y()]

    def resizeEvent(self, event: QResizeEvent) -> None:
        """处理窗口 resize 事件."""
        super().resizeEvent(event)
        gui_conf.win_size = [self.width(), self.height()]

    def closeEvent(self, event: QCloseEvent) -> None:
        """处理窗口关闭事件."""
        self._save_config()
        event.accept()
