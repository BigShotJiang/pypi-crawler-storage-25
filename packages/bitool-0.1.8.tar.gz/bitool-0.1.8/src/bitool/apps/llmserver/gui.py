"""Graphical user interface for llmserver."""

from __future__ import annotations

import sys

from PySide2.QtWidgets import QApplication

from .llmserver import LLMServer


def main() -> None:
    """Run entry point for the GUI application."""
    app = QApplication(sys.argv)
    window = LLMServer()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
