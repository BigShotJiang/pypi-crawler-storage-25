"""Conf module for llmserver."""

from __future__ import annotations

from pathlib import Path

from bitool.core import JsonConfig


class LLMServerConfig(JsonConfig):
    """LLM Server configuration with persistence support."""

    # Application metadata
    TITLE: str = "Llama 本地模型服务器 v1.0"

    # Window configuration
    WIN_SIZE: list[int] = [900, 700]  # noqa: RUF012
    WIN_POS: list[int] = [200, 200]  # noqa: RUF012

    # Server configuration
    MODEL_PATH: str = ""
    URL: str = "http://127.0.0.1"
    LISTEN_PORT: int = 8080
    LISTEN_PORT_RNG: list[int] = [1024, 65535]  # noqa: RUF012
    THREAD_COUNT: int = 4
    THREAD_COUNT_RNG: list[int] = [1, 24]  # noqa: RUF012

    # Configuration file path
    CONFIG_FILE: Path = Path.home() / ".pytola" / "llmserver.json"


conf = LLMServerConfig()
