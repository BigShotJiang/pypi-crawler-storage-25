# Bitool

基于 Maturin 的 Rust + Python 混合架构工具集，将性能瓶颈和共性部分使用 Rust 实现，接口和逻辑部分使用 Python 实现。

## 特性

- **高性能**：核心计算和 I/O 操作使用 Rust 实现
- **易用性**：Python 提供简洁的 API 接口
- **可扩展**：插件系统支持功能扩展
- **跨平台**：支持 Windows、Linux、macOS

## 安装

```bash
pip install bitool
```

## 开发

### 快速开始（推荐）

```bash
# 安装开发环境（自动构建 Rust + Python 双包）
pymake ia

# 验证安装
pymake t
```

### 常用命令

```bash
# 构建所有包（Rust + Python）
pymake ba

# 代码格式化与检查
pymake lint

# 运行测试
pymake t

# 清理所有构建产物
pymake ca

# 查看完整帮助
pymake help
```

### 手动构建（可选）

```bash
# 构建 Rust 核心模块
cd bitool-core && maturin develop

# 构建 Python 主包
cd .. && pip install -e .

# 构建发布包
cd bitool-core && maturin build -r
cd .. && python -m build
```

> 📖 详细文档：[PyMake 使用指南](docs/PYMAKE_GUIDE.md) | [双包构建指南](docs/DUAL_PACKAGE_BUILD.md)

## 项目结构

```bash
bitool/
├── bitool-core/            # Rust 核心模块
│   ├── src/                # Rust 源代码
│   │   ├── core/           # 核心功能模块
│   │   ├── plugins/        # 插件系统核心
│   │   └── python/         # Python 绑定
│   ├── Cargo.toml          # Rust 依赖配置
│   └── pyproject.toml      # Maturin 构建配置
├── src/
│   ├── bitool/             # Python 主包 (src layout)
│   │   ├── apps/           # 应用程序 (alarmclock, pypack)
│   │   ├── cmd/            # 命令系统
│   │   ├── core/           # 核心业务逻辑 (config, logger, env)
│   │   ├── gui/            # GUI 组件和主题
│   │   ├── models/         # 数据模型
│   │   ├── skills/         # CLI 工具集
│   │   ├── utils/          # 工具模块 (executor, profiler, task)
│   │   ├── __init__.py     # 包初始化
│   │   ├── consts.py       # 常量定义
│   │   └── types.py        # 类型定义
│   └── tests/              # 测试代码
│       ├── apps/           # 应用测试
│       ├── cmd/            # 命令系统测试
│       ├── core/           # 核心模块测试
│       ├── skills/         # 技能工具测试
│       └── utils/          # 工具模块测试
├── docs/                   # 项目文档
├── pyproject.toml          # Python 包配置
└── README.md               # 项目说明
```

## 使用示例

```python
from bitool import FileOps, TextProcessor

# 文件操作
file_ops = FileOps()
files = file_ops.scan_directory("/path/to/dir")

# 文本处理
processor = TextProcessor()
result = processor.regex_search(pattern, text)
```

## 许可证

MIT License
