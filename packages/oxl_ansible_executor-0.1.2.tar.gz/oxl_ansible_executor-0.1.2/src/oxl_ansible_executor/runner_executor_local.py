from pathlib import Path
from shutil import which as find_executable

from utils.debug import log
from utils.subps import Process, ProcessArgs

from runner_executor_base import ExecutorBase
from runner_executor_command import AnsibleCommand, wrap_cmd_in_ssh_agent


class ExecutorLocal(ExecutorBase):
    def _engine_init(
            self,
            pipe_ssh_key: Path = None,
            pipe_connect_pass: Path = None,
            pipe_become_pass: Path = None,
            pipe_vault_pass: Path = None,
    ):
        self.engine_executable = self._build_engine_executable()
        self._ansible_command_generator = AnsibleCommand(
            config=self.config,
            pipe_ssh_key=pipe_ssh_key,
            pipe_connect_pass=pipe_connect_pass,
            pipe_become_pass=pipe_become_pass,
            pipe_vault_pass=pipe_vault_pass,
            inventory_files=self.config.inventory_files,
            ssh_known_hosts_file=self.config.ssh_known_hosts_file,
        )
        self.ansible_command = self._ansible_command_generator.generate()

    @staticmethod
    def _build_engine_executable() -> str:
        executable = find_executable('ansible-playbook')
        if executable is not None:
            return executable

        return 'ansible-playbook'

    def generate_engine_command(self) -> list[str]:
        cmd = self.ansible_command.copy()
        cmd[0] = self.engine_executable
        # pylint: disable=W0212
        if self.config._ssh_key is not None:
            return wrap_cmd_in_ssh_agent(cmd=cmd, ssh_key_file=self._pipe_ssh_key)

        if not self.config.silent:
            log(f"Engine command: {cmd}")

        return cmd

    def prepare_engine(self):
        pass

    def _create_process(self, cmd: list[str]):
        process_args = ProcessArgs(
            cwd=self.config.playbook_dir,
            timeout_sec=self.config.timeout_sec_run,
            env=self.config.env_vars,
            env_remove=self.config.env_vars_strip,
            file_stdout=self.config.log_stdout_file,
            file_stderr=self.config.log_stderr_file,
        )
        self.process = Process(cmd=cmd, args=process_args)

    def _send_signal_to_ansible(self, signal: int):
        self.process.send_signal(signal)
