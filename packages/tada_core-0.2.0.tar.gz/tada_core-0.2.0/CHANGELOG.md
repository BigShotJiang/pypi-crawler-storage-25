# Changelog

All notable changes to `tada-core` will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project uses semantic versioning during public releases.

## [Unreleased]

## [0.2.0] - 2026-05-25

### Added

- Public SDK surface for `AgentLoop`, `AnthropicModelClient`, events, session state, compaction strategies, and message schema models.
- Anthropic Messages API `cache_control` support with short/long retention handling.
- Multimodal `ContentBlock` support for image and file blocks.
- SDK install documentation for local editable, Git URL, and future PyPI consumption.
- `tada-core-smoke` echo-only CLI harness for manual event-stream checks.
- Fresh-venv SDK contract verification script.
- `ToolResultPruningConfig` plus active old `tool_result` pruning with audit manifest metadata.
- Stable `ConversationMessage.id` propagation through `CompactionResult.compacted_message_ids`.

### Changed

- Clarified that provider routing belongs to `token-router`; `tada-core` owns the client-side Anthropic wire format.
- Upgraded `StructuredSummaryCompaction` to count system/tools in thresholds, preserve token-budget tails, align tool-use boundaries, and expose richer `CompactionEvent` metadata.

## [0.1.0] - 2026-05-21

### Added

- Initial public SDK baseline.
