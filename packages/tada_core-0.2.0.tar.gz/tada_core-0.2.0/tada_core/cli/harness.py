"""Minimal echo-only CLI harness for manual smoke tests."""

from __future__ import annotations

import asyncio
import sys

from tada_core.contracts.session import SessionState
from tada_core.loop import AgentLoop
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport


def main(argv: list[str] | None = None) -> None:
    import argparse

    p = argparse.ArgumentParser(
        prog="tada-core-smoke",
        description="Manual smoke harness for the tada-core AgentLoop",
    )
    p.add_argument("--text", default="hello", help="user message")
    p.add_argument("--stream", action="store_true", help="use streaming transport")
    args = p.parse_args(argv)

    model = OpenAICompatibleModelClient(make_echo_transport(), streaming=args.stream)
    loop = AgentLoop(model)
    state = SessionState()

    async def _run() -> None:
        async for ev in loop.run_turn(state, args.text):
            print(ev.model_dump_json())

    asyncio.run(_run())


if __name__ == "__main__":
    main(sys.argv[1:])
