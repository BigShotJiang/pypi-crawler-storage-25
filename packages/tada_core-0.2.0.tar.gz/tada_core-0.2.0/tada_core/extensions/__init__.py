"""Optional extensions (not core contracts)."""
