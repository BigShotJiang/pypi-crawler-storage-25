"""
Optional MCP bridge — NOT part of tada-core core contracts.

Providers may implement their own MCP client without implementing this module.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class McpClientBridge(Protocol):
    """Future hook for stdio/HTTP MCP clients if needed."""

    def list_tools(self) -> list[dict[str, Any]]: ...

    def call_tool(self, name: str, arguments: dict[str, Any]) -> str: ...
