"""Pre/post tool hooks: process and function styles.

Hooks are first-class runtime participants. They may observe, deny, fail,
cancel, or rewrite tool execution. The most important rule is that
`HookResult.updated_input` has priority over the original tool payload when a
runtime continues to execute the tool.

Hook phases (in lifecycle order):
  ON_SESSION_START      — once when a session is initialised
  ON_TURN_START         — entry of run_turn(); may inject a system hint
  PRE_LLM_CALL          — before every LLM call; may rewrite the message list
                          (primary hook point for memory compaction)
  POST_LLM_CALL         — after every LLM response; may observe model output
  PRE_TOOL_USE          — before each tool call; may rewrite input or deny
  POST_TOOL_USE         — after a successful tool call; may set exit_loop=True
                          to request graceful loop exit (e.g. ask_user pattern)
  POST_TOOL_USE_FAILURE — after a failed tool call
  ON_TURN_END           — exit of run_turn(); for audit / logging

All hook methods are async to allow awaiting user interaction (e.g. approval
dialogs, ask_user) without blocking the event loop.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Coroutine, Protocol, runtime_checkable

from tada_core.contracts.messages import ConversationMessage


class HookEventKind(str, Enum):
    ON_SESSION_START = "OnSessionStart"
    ON_TURN_START = "OnTurnStart"
    PRE_LLM_CALL = "PreLlmCall"
    POST_LLM_CALL = "PostLlmCall"
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"
    ON_TURN_END = "OnTurnEnd"


@dataclass
class HookResult:
    """Outcome returned by a hook invocation.

    Runtime interpretation:
    - `updated_input` replaces the original tool input for subsequent steps
    - `updated_messages` replaces the session message list before an LLM call
      (used by PRE_LLM_CALL hooks such as memory compaction)
    - `permission_override` / `permission_reason` feed into `PermissionContext`
    - `denied`, `failed`, or `cancelled` must stop normal execution
    - `exit_loop` requests graceful loop exit after current tool completes,
      without skipping remaining tools (use for ask_user-style pausing)
    - `steering_messages` injects user messages after current tool, skips all
      remaining tools in this iteration, then re-enters the LLM (steer pattern)
    """

    denied: bool = False
    failed: bool = False
    cancelled: bool = False
    exit_loop: bool = False
    exit_reason: str | None = None
    steering_messages: list[ConversationMessage] = field(default_factory=list)
    messages: list[str] = field(default_factory=list)
    permission_override: Any | None = None
    permission_reason: str | None = None
    updated_input: str | None = None
    updated_messages: list[ConversationMessage] | None = None
    compaction_handled: bool = False
    skip_builtin_compaction: bool = False

    @staticmethod
    def allow(messages: list[str] | None = None) -> HookResult:
        return HookResult(messages=list(messages or []))


class HookRunner(ABC):
    """Runs hooks at the correct phases of the runtime loop."""

    @abstractmethod
    async def run_pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        raise NotImplementedError

    @abstractmethod
    async def run_post_tool_use(
        self, tool_name: str, input_json: str, output: str, *, is_error: bool
    ) -> HookResult:
        raise NotImplementedError

    @abstractmethod
    async def run_post_tool_use_failure(
        self, tool_name: str, input_json: str, error_output: str
    ) -> HookResult:
        raise NotImplementedError

    async def run_pre_llm_call(
        self, messages: list[ConversationMessage]
    ) -> HookResult:
        """Called before every LLM request. May return updated_messages."""
        return HookResult.allow()

    async def run_post_llm_call(
        self, tool_names: list[str], text: str
    ) -> HookResult:
        """Called after every LLM response. Observe-only by default."""
        return HookResult.allow()

    async def run_on_turn_start(
        self, user_text: str
    ) -> HookResult:
        """Called at the entry of run_turn()."""
        return HookResult.allow()

    async def run_on_turn_end(self) -> HookResult:
        """Called at the exit of run_turn()."""
        return HookResult.allow()

    async def run_on_session_start(self) -> HookResult:
        """Called once when a session is first initialised."""
        return HookResult.allow()


class NoOpHookRunner(HookRunner):
    """Default hook runner for providers with no configured hooks."""

    async def run_pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        return HookResult.allow()

    async def run_post_tool_use(
        self, tool_name: str, input_json: str, output: str, *, is_error: bool
    ) -> HookResult:
        return HookResult.allow()

    async def run_post_tool_use_failure(
        self, tool_name: str, input_json: str, error_output: str
    ) -> HookResult:
        return HookResult.allow()


_SyncOrAsync = Coroutine | HookResult


def _is_coroutine(fn: Callable) -> bool:
    import asyncio
    return asyncio.iscoroutinefunction(fn)


async def _call(fn: Callable, *args: Any, **kwargs: Any) -> HookResult:
    """Call sync or async hook callback uniformly."""
    result = fn(*args, **kwargs)
    if hasattr(result, "__await__"):
        return await result
    return result  # type: ignore[return-value]


@runtime_checkable
class PreToolHookFn(Protocol):
    def __call__(self, tool_name: str, input_json: str) -> HookResult | Coroutine: ...


class FunctionHookRunner(HookRunner):
    """Compose Python callbacks. Callbacks may be sync or async."""

    def __init__(
        self,
        pre: PreToolHookFn | None = None,
        post: Callable[..., HookResult | Coroutine] | None = None,
        post_failure: Callable[..., HookResult | Coroutine] | None = None,
        pre_llm_call: Callable[..., HookResult | Coroutine] | None = None,
        post_llm_call: Callable[..., HookResult | Coroutine] | None = None,
        on_turn_start: Callable[..., HookResult | Coroutine] | None = None,
        on_turn_end: Callable[..., HookResult | Coroutine] | None = None,
        on_session_start: Callable[..., HookResult | Coroutine] | None = None,
    ) -> None:
        self._pre = pre
        self._post = post
        self._post_failure = post_failure
        self._pre_llm_call = pre_llm_call
        self._post_llm_call = post_llm_call
        self._on_turn_start = on_turn_start
        self._on_turn_end = on_turn_end
        self._on_session_start = on_session_start

    async def run_pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        if self._pre:
            return await _call(self._pre, tool_name, input_json)
        return HookResult.allow()

    async def run_post_tool_use(
        self, tool_name: str, input_json: str, output: str, *, is_error: bool
    ) -> HookResult:
        if self._post:
            return await _call(self._post, tool_name, input_json, output, is_error=is_error)
        return HookResult.allow()

    async def run_post_tool_use_failure(
        self, tool_name: str, input_json: str, error_output: str
    ) -> HookResult:
        if self._post_failure:
            return await _call(self._post_failure, tool_name, input_json, error_output)
        return HookResult.allow()

    async def run_pre_llm_call(self, messages: list[ConversationMessage]) -> HookResult:
        if self._pre_llm_call:
            return await _call(self._pre_llm_call, messages)
        return HookResult.allow()

    async def run_post_llm_call(self, tool_names: list[str], text: str) -> HookResult:
        if self._post_llm_call:
            return await _call(self._post_llm_call, tool_names, text)
        return HookResult.allow()

    async def run_on_turn_start(self, user_text: str) -> HookResult:
        if self._on_turn_start:
            return await _call(self._on_turn_start, user_text)
        return HookResult.allow()

    async def run_on_turn_end(self) -> HookResult:
        if self._on_turn_end:
            return await _call(self._on_turn_end)
        return HookResult.allow()

    async def run_on_session_start(self) -> HookResult:
        if self._on_session_start:
            return await _call(self._on_session_start)
        return HookResult.allow()


class CompositeHookRunner(HookRunner):
    """Chain multiple HookRunners; first deny/fail/cancel short-circuits."""

    def __init__(self, runners: list[HookRunner]) -> None:
        self._runners = runners

    def _merge(self, results: list[HookResult]) -> HookResult:
        merged = HookResult()
        for r in results:
            merged.messages.extend(r.messages)
            if r.denied:
                merged.denied = True
            if r.failed:
                merged.failed = True
            if r.cancelled:
                merged.cancelled = True
            if r.exit_loop:
                merged.exit_loop = True
                if r.exit_reason is not None:
                    merged.exit_reason = r.exit_reason
            if r.steering_messages:
                merged.steering_messages.extend(r.steering_messages)
            if r.updated_input is not None:
                merged.updated_input = r.updated_input
            if r.updated_messages is not None:
                merged.updated_messages = r.updated_messages
            if r.compaction_handled:
                merged.compaction_handled = True
            if r.skip_builtin_compaction:
                merged.skip_builtin_compaction = True
            if r.permission_override is not None:
                merged.permission_override = r.permission_override
                merged.permission_reason = r.permission_reason
            if merged.denied or merged.failed or merged.cancelled:
                break
        return merged

    async def run_pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        results: list[HookResult] = []
        for runner in self._runners:
            r = await runner.run_pre_tool_use(tool_name, input_json)
            results.append(r)
            if r.denied or r.failed or r.cancelled:
                break
        return self._merge(results)

    async def run_post_tool_use(
        self, tool_name: str, input_json: str, output: str, *, is_error: bool
    ) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_post_tool_use(tool_name, input_json, output, is_error=is_error))
        return self._merge(results)

    async def run_post_tool_use_failure(
        self, tool_name: str, input_json: str, error_output: str
    ) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_post_tool_use_failure(tool_name, input_json, error_output))
        return self._merge(results)

    async def run_pre_llm_call(self, messages: list[ConversationMessage]) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_pre_llm_call(messages))
        return self._merge(results)

    async def run_post_llm_call(self, tool_names: list[str], text: str) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_post_llm_call(tool_names, text))
        return self._merge(results)

    async def run_on_turn_start(self, user_text: str) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_on_turn_start(user_text))
        return self._merge(results)

    async def run_on_turn_end(self) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_on_turn_end())
        return self._merge(results)

    async def run_on_session_start(self) -> HookResult:
        results = []
        for r in self._runners:
            results.append(await r.run_on_session_start())
        return self._merge(results)
