"""Provider-agnostic message models.

These models are the shared transcript language for all providers. The goal is
not to mirror any single SDK exactly, but to preserve enough structure for
event replay, session persistence, compaction, and adapter translation.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, model_validator


class MessageRole(str, Enum):
    """Stable participant roles understood by every provider."""

    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class ContentBlock(BaseModel):
    """A single block inside a conversation message.

    Providers may attach provider-specific details under `extra`, but the main
    transcript semantics must stay within the declared fields.
    """

    type: str = Field(
        ...,
        description="text | thinking | tool_use | tool_result | image | file | ...",
    )
    text: str | None = None
    thinking: str | None = None
    signature: str | None = None
    tool_use_id: str | None = None
    tool_name: str | None = None
    tool_input: str | None = None
    tool_result: str | None = None
    is_error: bool = False
    source: str | None = Field(
        default=None,
        description="base64 | url | path for image/file blocks",
    )
    mime_type: str | None = None
    data: str | None = None
    url: str | None = None
    name: str | None = None
    extra: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_known_block_payload(self) -> ContentBlock:
        if self.type == "thinking":
            return self
        if self.type not in {"image", "file"}:
            return self
        if self.source not in {"base64", "url", "path"}:
            raise ValueError(f"{self.type} blocks require source to be one of base64, url, or path")
        if not self.mime_type:
            raise ValueError(f"{self.type} blocks require mime_type")
        if self.source == "url":
            if not self.url:
                raise ValueError(f"{self.type} blocks require url when source is url")
        elif not self.data:
            raise ValueError(f"{self.type} blocks require data when source is {self.source}")
        return self

    def tool_result_blocks(self) -> list[ContentBlock]:
        """Return nested tool result blocks or a text fallback."""
        if self.type != "tool_result":
            return []
        nested = self.extra.get("content_blocks")
        if isinstance(nested, list):
            blocks: list[ContentBlock] = []
            for item in nested:
                if isinstance(item, dict):
                    blocks.append(ContentBlock.model_validate(item))
                elif isinstance(item, ContentBlock):
                    blocks.append(item)
            return blocks
        if self.tool_result:
            return [ContentBlock(type="text", text=self.tool_result)]
        return []


class ConversationMessage(BaseModel):
    """One transcript message composed of normalized content blocks."""

    id: str | None = None
    role: MessageRole
    content: list[ContentBlock] = Field(default_factory=list)
    provider: str | None = None
    api: str | None = None
    model: str | None = None
    stop_reason: str | None = None

    def text_only(self) -> str:
        """Flatten text blocks for compaction, tests, and simple adapters."""
        parts: list[str] = []
        for b in self.content:
            if b.type == "text" and b.text:
                parts.append(b.text)
        return "\n".join(parts)

    def tool_result_blocks(self) -> list[ContentBlock]:
        """Return structured tool result blocks when present."""
        blocks: list[ContentBlock] = []
        for b in self.content:
            if b.type == "tool_result":
                blocks.extend(b.tool_result_blocks())
        return blocks
