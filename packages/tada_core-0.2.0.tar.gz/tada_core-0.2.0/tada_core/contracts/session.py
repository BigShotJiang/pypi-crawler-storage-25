"""Session state and usage tracking.

`SessionState` is the minimum provider-agnostic state that every runtime
must be able to read and write. Provider-specific fields belong under
`metadata`; they must not invent new top-level state that other providers
or adapters cannot understand.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from tada_core.contracts.messages import ConversationMessage


class TokenUsage(BaseModel):
    """Portable usage counters shared across providers."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0


class SessionState(BaseModel):
    """Serializable conversation state for a single thread.

    Stable top-level fields:
    - `messages`: conversation transcript in provider-agnostic form
    - `usage`: shared token/cost-related counters
    - `metadata`: extension slot for provider-specific state
    """

    messages: list[ConversationMessage] = Field(default_factory=list)
    usage: TokenUsage = Field(default_factory=TokenUsage)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def clone(self) -> SessionState:
        """Return a deep copy safe for speculative mutation."""
        return self.model_copy(deep=True)
