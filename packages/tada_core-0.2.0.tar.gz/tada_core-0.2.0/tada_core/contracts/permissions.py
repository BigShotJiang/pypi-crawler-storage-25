"""Permission policy for tool execution.

Permissions are evaluated after hook preprocessing and before tool execution.
This means a runtime should inject hook output into `PermissionContext`
instead of bypassing policy decisions.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class PermissionOutcome(str, Enum):
    """Binary permission decision for a tool invocation."""

    ALLOW = "allow"
    DENY = "deny"


class PermissionContext:
    """Optional overrides from hooks (claw-code PermissionContext analogue).

    A runtime should populate this from hook output before calling the policy.
    """

    def __init__(
        self,
        override: Any | None = None,
        reason: str | None = None,
    ) -> None:
        self.override = override
        self.reason = reason


@runtime_checkable
class PermissionPrompter(Protocol):
    """Interactive approval (optional; tests can use mock)."""

    def prompt(self, tool_name: str, tool_input: str) -> PermissionOutcome: ...


class PermissionPolicy(ABC):
    """Decide whether a tool call is allowed."""

    @abstractmethod
    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:
        raise NotImplementedError


class AllowAllPolicy(PermissionPolicy):
    """Permissive policy useful for tests and non-interactive flows."""

    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:
        return PermissionOutcome.ALLOW


class DenyListPolicy(PermissionPolicy):
    """Simple policy that denies tool names in a case-insensitive set."""

    def __init__(self, denied: set[str]) -> None:
        self._denied = {n.lower() for n in denied}

    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:
        if tool_name.lower() in self._denied:
            return PermissionOutcome.DENY
        return PermissionOutcome.ALLOW
