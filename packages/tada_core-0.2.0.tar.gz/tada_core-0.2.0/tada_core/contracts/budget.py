"""Runtime budget controls for AgentLoop.

Budgets are provider-agnostic execution limits. They intentionally do not
contain provider prices, routing priorities, quota accounts, or OAuth details.
Hosts may translate token usage into cost externally and feed a derived limit
back into this contract later.
"""

from __future__ import annotations

from pydantic import BaseModel

from tada_core.contracts.session import TokenUsage


class BudgetLimits(BaseModel):
    """Simple per-turn/session budget limits enforced by AgentLoop."""

    max_input_tokens: int | None = None
    max_output_tokens: int | None = None
    max_total_tokens: int | None = None
    max_iterations: int | None = None
    max_tool_calls: int | None = None

    def check_usage(self, usage: TokenUsage) -> str | None:
        if self.max_input_tokens is not None and usage.input_tokens > self.max_input_tokens:
            return f"input token budget exceeded: {usage.input_tokens} > {self.max_input_tokens}"
        if self.max_output_tokens is not None and usage.output_tokens > self.max_output_tokens:
            return f"output token budget exceeded: {usage.output_tokens} > {self.max_output_tokens}"
        total = usage.input_tokens + usage.output_tokens
        if self.max_total_tokens is not None and total > self.max_total_tokens:
            return f"total token budget exceeded: {total} > {self.max_total_tokens}"
        return None

    def check_iteration(self, iterations_used: int) -> str | None:
        if self.max_iterations is not None and iterations_used >= self.max_iterations:
            return f"iteration budget exceeded: {iterations_used} >= {self.max_iterations}"
        return None

    def check_tool_calls(self, tool_calls_used: int) -> str | None:
        if self.max_tool_calls is not None and tool_calls_used > self.max_tool_calls:
            return f"tool call budget exceeded: {tool_calls_used} > {self.max_tool_calls}"
        return None
