"""Model client contract (claw-code ApiRequest / AssistantEvent analogue)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from tada_core.contracts.messages import ConversationMessage, MessageRole
from tada_core.contracts.session import TokenUsage


class StopReason(str, Enum):
    STOP = "stop"
    LENGTH = "length"
    TOOL_USE = "tool_use"
    ERROR = "error"
    ABORTED = "aborted"


class AssistantEventKind(str, Enum):
    TEXT_START = "text_start"
    TEXT_DELTA = "text_delta"
    TEXT_END = "text_end"
    THINKING_START = "thinking_start"
    THINKING_DELTA = "thinking_delta"
    THINKING_END = "thinking_end"
    TOOL_USE = "tool_use"
    TOOL_INPUT_DELTA = "tool_input_delta"
    USAGE = "usage"
    MESSAGE_STOP = "message_stop"


class AssistantEvent(BaseModel):
    kind: AssistantEventKind
    text_delta: str | None = None
    thinking_delta: str | None = None
    # Anthropic extended-thinking signature. The Messages API requires that
    # any ``thinking`` block sent back in subsequent turns carries a matching
    # cryptographic ``signature``; the server returns 400 if it is missing.
    # Providers should populate this on the THINKING_END event (and the
    # AgentLoop is expected to attach it to the assistant message's
    # ``ContentBlock.signature``).
    thinking_signature: str | None = None
    tool_use_id: str | None = None
    tool_name: str | None = None
    tool_input: str | None = None
    tool_input_delta: str | None = None
    usage: TokenUsage | None = None
    stop_reason: StopReason | None = None
    model_id: str | None = None
    request_id: str | None = None


class ApiRequest(BaseModel):
    system_prompt: list[str] = Field(default_factory=list)
    messages: list[ConversationMessage] = Field(default_factory=list)
    tools: list[dict[str, Any]] = Field(default_factory=list)
    model_spec: Any | None = None
    max_tokens: int | None = None
    generate_kwargs: dict[str, Any] = Field(default_factory=dict)


class ModelClient(ABC):
    """Normalize provider responses into an async AssistantEvent stream."""

    @abstractmethod
    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        """Return an async iterator of AssistantEvents for the given request."""

    def estimate_tokens(self, request: ApiRequest) -> int | None:
        """Optional provider-native request token estimate."""
        _ = request
        return None


class EchoModelClient(ModelClient):
    """Compatibility test double: echoes last user text, no tools."""

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        text = ""
        for m in reversed(request.messages):
            if m.role == MessageRole.USER:
                text = m.text_only()
                break
        if not text:
            for m in reversed(request.messages):
                if m.role == MessageRole.TOOL:
                    for b in m.content:
                        if b.type == "tool_result" and b.tool_result:
                            text = b.tool_result
                            break
                    if text:
                        break

        async def _gen() -> AsyncIterator[AssistantEvent]:
            if text:
                yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text)
                yield AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text)
            yield AssistantEvent(
                kind=AssistantEventKind.MESSAGE_STOP,
                stop_reason=StopReason.STOP,
            )

        return _gen()
