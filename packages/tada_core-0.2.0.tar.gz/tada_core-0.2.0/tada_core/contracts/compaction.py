"""Session compaction strategies.

Compaction is a first-class runtime concern. Providers may run it before a
turn, after a turn, or both, but they should surface the effect through
`CompactionEvent` and preserve the `SessionState` contract.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, Field

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind
from tada_core.contracts.session import SessionState
from tada_core.contracts.tokenization import (
    CharacterTokenEstimator,
    TokenEstimator,
    TokenEstimatorConfig,
)

if TYPE_CHECKING:
    from tada_core.contracts.model import ModelClient


class CompactionMode(str, Enum):
    AUTO = "auto"
    DISABLED = "disabled"
    HOOK_ONLY = "hook_only"


class ToolResultPruningConfig(BaseModel):
    """Controls lossless metadata + lossy payload pruning for old tool results."""

    enabled: bool = True
    scope: Literal["middle_only", "outside_tail", "all_except_recent"] = "middle_only"
    max_chars: int = 4000
    keep_tail_messages: int | None = None
    preserve_error_chars: int = 8000
    placeholder: str = "[Old tool output cleared to save context space]"


class CompactionConfig(BaseModel):
    mode: CompactionMode = CompactionMode.AUTO
    threshold_tokens: int | None = None
    threshold_ratio: float = 0.7
    keep_last: int = 4
    head_protect: int = 1
    cooldown_seconds: int = 600
    tail_token_budget: int | None = None
    tool_result_pruning: ToolResultPruningConfig = Field(default_factory=ToolResultPruningConfig)


class CompactionResult(BaseModel):
    """Portable result from one compaction pass."""

    removed_message_count: int = 0
    summary: str | None = None
    new_messages: list | None = None  # optional replacement tail
    trigger: str | None = None
    tokens_before: int | None = None
    tokens_after: int | None = None
    pruned_tool_count: int = 0
    cache_hit_estimated: bool | None = None
    compacted_message_ids: list[str] = Field(default_factory=list)
    pruned_tool_results: list[dict[str, Any]] = Field(default_factory=list)
    fallback_used: bool = False
    manifest: dict[str, Any] = Field(default_factory=dict)
    summary_cache_read_tokens: int = 0


class CompactionStrategy(ABC):
    """Provider-agnostic strategy interface for session compaction."""

    @abstractmethod
    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        raise NotImplementedError

    @abstractmethod
    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        raise NotImplementedError


class NeverCompact(CompactionStrategy):
    """Strategy that explicitly disables compaction."""

    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        _ = (trigger, system_prompt, tools)
        return False

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        _ = trigger
        return CompactionResult()


class TruncateCompaction(CompactionStrategy):
    """Keep last N messages by dropping the oldest transcript entries."""

    def __init__(self, max_messages: int = 20) -> None:
        self.max_messages = max_messages

    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        _ = (trigger, system_prompt, tools)
        return len(state.messages) > self.max_messages

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        n = len(state.messages)
        if n <= self.max_messages:
            return CompactionResult()
        removed = n - self.max_messages
        state.messages = state.messages[-self.max_messages :]
        return CompactionResult(removed_message_count=removed, trigger=trigger)


class SummarizeCompaction(CompactionStrategy):
    """Placeholder summarization strategy.

    Real providers are expected to subclass or replace this with a
    model-backed summarizer. See ModelSummaryCompaction for the LLM-backed
    implementation.
    """

    def __init__(self, threshold_tokens: int = 8000) -> None:
        self.threshold_tokens = threshold_tokens

    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        _ = (trigger, system_prompt, tools)
        # rough estimate: 4 chars per token
        total = sum(len(m.text_only()) for m in state.messages)
        return total // 4 > self.threshold_tokens

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        # Minimal behavior for tests: truncate + synthetic summary
        if not state.messages:
            return CompactionResult()
        removed = max(0, len(state.messages) - 2)
        state.messages = state.messages[-2:]
        return CompactionResult(
            removed_message_count=removed,
            summary="[compacted]",
            trigger=trigger,
        )


class ModelSummaryCompaction(CompactionStrategy):
    """LLM-backed compaction: summarize older transcript entries via a ModelClient.

    This is the standard reusable implementation available to all providers.
    The model client must be passed explicitly so any provider can supply its
    own transport without coupling to a specific provider's internals.
    """

    def __init__(
        self,
        model: "ModelClient",
        *,
        threshold_tokens: int = 8000,
        keep_last: int = 4,
    ) -> None:
        self._model = model
        self.threshold_tokens = threshold_tokens
        self.keep_last = keep_last

    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        _ = (trigger, system_prompt, tools)
        total = sum(len(message.text_only()) for message in state.messages)
        return total // 4 > self.threshold_tokens

    async def compact_async(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
        from tada_core.contracts.model import ApiRequest, AssistantEventKind

        if len(state.messages) <= self.keep_last:
            return CompactionResult(trigger=trigger)

        removed = len(state.messages) - self.keep_last
        head = state.messages[:removed]
        tail = state.messages[-self.keep_last :]
        summary_prompt = "\n".join(
            [
                "Summarize the following conversation for continued tool-aware execution.",
                "Keep user intent, tool outcomes, open questions, and constraints.",
                "",
                *[message.text_only() for message in head if message.text_only()],
            ]
        )
        request = ApiRequest(
            system_prompt=["You write compact execution summaries for future turns."],
            messages=[
                ConversationMessage(
                    role=MessageRole.USER,
                    content=[ContentBlock(type="text", text=summary_prompt)],
                )
            ],
        )
        parts: list[str] = []
        async for event in self._model.stream(request):
            if event.kind == AssistantEventKind.TEXT_DELTA and event.text_delta:
                parts.append(event.text_delta)
        summary = "".join(parts).strip()
        if not summary:
            summary = "[summary unavailable]"

        state.messages = [
            ConversationMessage(
                role=MessageRole.ASSISTANT,
                content=[ContentBlock(type="text", text=f"[compacted summary]\n{summary}")],
            ),
            *tail,
        ]
        return CompactionResult(
            removed_message_count=removed,
            summary=summary,
            trigger=trigger,
        )

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            raise RuntimeError(
                "ModelSummaryCompaction.compact() called from async context — "
                "use await loop.compact_async() instead, or call AgentLoop.run_turn() "
                "which handles this automatically."
            )
        return asyncio.run(self.compact_async(state, trigger=trigger))


class StructuredSummaryCompaction(CompactionStrategy):
    """Default high-quality structured summary compaction.

    The strategy is provider-neutral: it works with any ModelClient, reuses
    system/tools passed by AgentLoop, and lets provider adapters decide how
    prompt caching is expressed on the wire.
    """

    DEFAULT_THRESHOLD_RATIO = 0.7
    FALLBACK_THRESHOLD_TOKENS = 100_000

    def __init__(
        self,
        model: "ModelClient",
        *,
        summary_model_client: "ModelClient | None" = None,
        threshold_tokens: int | None = None,
        threshold_ratio: float = DEFAULT_THRESHOLD_RATIO,
        keep_last: int = 4,
        head_protect: int = 1,
        cooldown_seconds: int = 600,
        tail_token_budget: int | None = None,
        tool_result_pruning: ToolResultPruningConfig | None = None,
        token_estimator: TokenEstimator | None = None,
        image_token_estimate: int = 1500,
        file_token_estimate: int = 800,
    ) -> None:
        self._model = model
        self._summary_model = summary_model_client or model
        self.threshold_tokens = threshold_tokens
        self.threshold_ratio = threshold_ratio
        self.keep_last = keep_last
        self.head_protect = head_protect
        self.cooldown_seconds = cooldown_seconds
        self.tail_token_budget = tail_token_budget
        self.tool_result_pruning = tool_result_pruning or ToolResultPruningConfig()
        self._token_estimator = token_estimator or CharacterTokenEstimator(
            TokenEstimatorConfig(
                image_token_estimate=image_token_estimate,
                file_token_estimate=file_token_estimate,
            )
        )
        self._model_spec = getattr(model, "model_spec", None) or getattr(model, "_model_spec", None)
        self._summary_model_spec = (
            getattr(self._summary_model, "model_spec", None)
            or getattr(self._summary_model, "_model_spec", None)
            or self._model_spec
        )

    @classmethod
    def from_spec(
        cls,
        spec: Any,
        *,
        api_key: str = "",
        threshold_tokens: int | None = None,
        summary_spec: Any | None = None,
        summary_api_key: str | None = None,
        **kwargs: Any,
    ) -> "StructuredSummaryCompaction":
        from tada_core.providers import build_model_client

        model = build_model_client(spec, api_key=api_key, **kwargs)
        summary_model = None
        if summary_spec is not None:
            summary_model = build_model_client(
                summary_spec,
                api_key=summary_api_key if summary_api_key is not None else api_key,
                **kwargs,
            )
        return cls(
            model,
            summary_model_client=summary_model,
            threshold_tokens=threshold_tokens,
        )

    def effective_threshold_tokens(self, spec: Any | None = None) -> int:
        if self.threshold_tokens is not None:
            return self.threshold_tokens
        model_spec = spec or self._model_spec
        context_window = getattr(model_spec, "context_window", None)
        if context_window:
            return int(context_window * self.threshold_ratio)
        return self.FALLBACK_THRESHOLD_TOKENS

    def estimate_state_tokens(
        self,
        state: SessionState,
        *,
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
        spec: Any | None = None,
    ) -> int:
        last_usage = state.metadata.get("last_usage")
        if isinstance(last_usage, dict) and int(last_usage.get("input_tokens") or 0) > 0:
            return int(last_usage["input_tokens"])
        if hasattr(last_usage, "input_tokens") and int(last_usage.input_tokens) > 0:
            return int(last_usage.input_tokens)

        request = ApiRequest(
            system_prompt=list(system_prompt or []),
            messages=list(state.messages),
            tools=list(tools or []),
            model_spec=spec or self._model_spec,
        )
        estimate_tokens = getattr(self._model, "estimate_tokens", None)
        if estimate_tokens is not None:
            try:
                estimated = estimate_tokens(request)
            except Exception:
                estimated = None
            if estimated:
                return int(estimated)
        return self._token_estimator.estimate_request(request)

    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> bool:
        _ = trigger
        cooldown_until = state.metadata.get("compaction", {}).get("cooldown_until", 0)
        if cooldown_until and float(cooldown_until) > time.time():
            return False
        return (
            self.estimate_state_tokens(
                state,
                system_prompt=system_prompt,
                tools=tools,
                spec=self._model_spec,
            )
            > self.effective_threshold_tokens()
        )

    def _fallback_summary(self, messages: list[ConversationMessage]) -> str:
        snippets = [m.text_only() for m in messages if m.text_only()]
        joined = "\n".join(snippets[:8])
        return f"fallback summary generated without model output\n{joined}".strip()

    def _select_tail_count(
        self,
        messages: list[ConversationMessage],
        *,
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> int:
        tail_count = min(max(0, self.keep_last), len(messages))
        if not self.tail_token_budget or tail_count >= len(messages):
            return tail_count

        while tail_count < len(messages):
            candidate_count = tail_count + 1
            candidate = messages[-candidate_count:]
            estimated = self._token_estimator.estimate_messages(
                candidate,
                system_prompt=system_prompt,
                tools=tools,
            )
            if estimated > self.tail_token_budget:
                break
            tail_count = candidate_count
        return tail_count

    def _tool_use_ids(self, messages: list[ConversationMessage]) -> set[str]:
        return {
            block.tool_use_id
            for message in messages
            for block in message.content
            if block.type == "tool_use" and block.tool_use_id
        }

    def _tool_result_ids(self, messages: list[ConversationMessage]) -> set[str]:
        return {
            block.tool_use_id
            for message in messages
            for block in message.content
            if block.type == "tool_result" and block.tool_use_id
        }

    def _align_tool_boundaries(
        self,
        head: list[ConversationMessage],
        middle: list[ConversationMessage],
        tail: list[ConversationMessage],
    ) -> tuple[list[ConversationMessage], list[ConversationMessage], list[ConversationMessage]]:
        """Keep tool_use/tool_result pairs out of partition boundary splits."""

        head = list(head)
        middle = list(middle)
        tail = list(tail)

        while middle and self._tool_use_ids(head) & self._tool_result_ids([middle[0]]):
            head.append(middle.pop(0))

        while middle and self._tool_use_ids(middle) & self._tool_result_ids(tail):
            tail.insert(0, middle.pop())

        return head, middle, tail

    async def compact_async(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> CompactionResult:
        from tada_core.loop.message_sanitizer import (
            prune_tool_results_for_compaction,
            sanitize_tool_pairs,
            serialize_messages_for_compaction,
        )

        tail_count = self._select_tail_count(
            state.messages,
            system_prompt=system_prompt,
            tools=tools,
        )
        minimum_kept = self.head_protect + tail_count
        if len(state.messages) <= minimum_kept:
            return CompactionResult(trigger=trigger)

        tokens_before = self.estimate_state_tokens(
            state,
            system_prompt=system_prompt,
            tools=tools,
            spec=self._model_spec,
        )
        head = state.messages[: self.head_protect] if self.head_protect else []
        tail = state.messages[-tail_count:] if tail_count else []
        middle_end = len(state.messages) - len(tail)
        middle = state.messages[len(head) : middle_end]
        head, middle, tail = self._align_tool_boundaries(head, middle, tail)
        if not middle:
            state.messages = [*head, *tail]
            return CompactionResult(trigger=trigger, tokens_before=tokens_before)

        pruned_middle, pruning_manifest = prune_tool_results_for_compaction(
            middle,
            config=self.tool_result_pruning,
            head_count=0,
            tail_count=0,
        )
        serialized, serialization_manifest = serialize_messages_for_compaction(pruned_middle)
        manifest = {
            **serialization_manifest,
            "pruned_tool_count": pruning_manifest["pruned_tool_count"],
            "pruned_tool_results": pruning_manifest["pruned_tool_results"],
        }
        compacted_message_ids = [message.id for message in middle if message.id]
        compaction_meta = state.metadata.setdefault("compaction", {})
        previous_summary = compaction_meta.get("last_summary", "")
        prompt = "\n\n".join(
            [
                "Summarize the following conversation for continued tool-aware execution.",
                "Use these sections: Goal, Progress, Key Decisions, Files and Tool Results, Todo, Risks.",
                "Preserve constraints, unresolved questions, and any tool output placeholders from the transcript.",
                f"Previous summary:\n{previous_summary or '(none)'}",
                f"Conversation to compact:\n{serialized}",
            ]
        )
        request = ApiRequest(
            system_prompt=list(system_prompt or ["You write compact execution summaries for future turns."]),
            messages=[
                ConversationMessage(
                    role=MessageRole.USER,
                    content=[ContentBlock(type="text", text=prompt)],
                )
            ],
            tools=list(tools or []),
            model_spec=self._summary_model_spec,
            max_tokens=2048,
        )

        summary_parts: list[str] = []
        fallback_used = False
        summary_cache_read_tokens = 0
        try:
            async for event in self._summary_model.stream(request):
                if event.kind == AssistantEventKind.TEXT_DELTA and event.text_delta:
                    summary_parts.append(event.text_delta)
                elif event.kind == AssistantEventKind.USAGE and event.usage:
                    summary_cache_read_tokens += event.usage.cache_read_tokens
        except Exception:
            fallback_used = True

        summary = "".join(summary_parts).strip()
        if not summary:
            fallback_used = True
            summary = self._fallback_summary(pruned_middle)

        summary_message = ConversationMessage(
            role=MessageRole.ASSISTANT,
            content=[ContentBlock(type="text", text=f"[compacted summary]\n{summary}")],
        )
        state.messages = sanitize_tool_pairs([*head, summary_message, *tail])

        tokens_after = self._token_estimator.estimate_messages(
            state.messages,
            system_prompt=system_prompt,
            tools=tools,
        )
        compaction_meta.update(
            {
                "version": 1,
                "last_trigger": trigger,
                "last_summary": summary,
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "manifest": manifest,
                "compacted_message_ids": compacted_message_ids,
                "fallback_used": fallback_used,
                "summary_cache_read_tokens": summary_cache_read_tokens,
            }
        )
        if fallback_used:
            compaction_meta["cooldown_until"] = time.time() + self.cooldown_seconds

        return CompactionResult(
            removed_message_count=len(middle),
            summary=summary,
            trigger=trigger,
            tokens_before=tokens_before,
            tokens_after=tokens_after,
            pruned_tool_count=manifest.get("pruned_tool_count", 0),
            cache_hit_estimated=bool(system_prompt or tools),
            compacted_message_ids=compacted_message_ids,
            pruned_tool_results=manifest.get("pruned_tool_results", []),
            fallback_used=fallback_used,
            manifest=manifest,
            summary_cache_read_tokens=summary_cache_read_tokens,
        )

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            raise RuntimeError(
                "StructuredSummaryCompaction.compact() called from async context — "
                "use compact_async() instead."
            )
        return asyncio.run(self.compact_async(state, trigger=trigger))
