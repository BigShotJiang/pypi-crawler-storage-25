"""Lightweight model metadata for protocol adapter selection.

ModelSpec describes model capabilities and wire protocol — not routing,
billing, quotas, or OAuth. Those belong to token-router or the host app.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

KnownApi = Literal[
    "anthropic-messages",
    "openai-completions",
    "openai-responses",
    "google-generative-ai",
    "bedrock-converse-stream",
]

InputModality = Literal["text", "image", "file"]


class ModelSpec(BaseModel):
    """Minimal model descriptor used to select a protocol adapter."""

    id: str
    provider: str = ""
    api: str
    base_url: str = ""
    input: list[InputModality] = Field(default_factory=lambda: ["text"])
    reasoning: bool = False
    context_window: int | None = None
    max_tokens: int | None = None
    headers: dict[str, str] = Field(default_factory=dict)
    compat: dict[str, Any] = Field(default_factory=dict)

    def supports_input(self, modality: InputModality) -> bool:
        return modality in self.input
