"""Unified event stream from any ConversationRuntime.

`Event` is a stable public API for both provider implementations and
host-side integrators. Event order is part of the contract:

- `tool_use` must appear before the matching `tool_result`
- `permission` must be decided before tool execution
- `subagent_started` / `subagent_finished` must wrap child runtime work
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from tada_core.contracts.model import StopReason


class TextStart(BaseModel):
    type: Literal["text_start"] = "text_start"


class TextDelta(BaseModel):
    """Incremental assistant text output."""

    type: Literal["text_delta"] = "text_delta"
    text: str


class TextEnd(BaseModel):
    type: Literal["text_end"] = "text_end"
    text: str = ""


class ThinkingStart(BaseModel):
    type: Literal["thinking_start"] = "thinking_start"


class ThinkingDelta(BaseModel):
    type: Literal["thinking_delta"] = "thinking_delta"
    text: str


class ThinkingEnd(BaseModel):
    type: Literal["thinking_end"] = "thinking_end"
    text: str = ""


class ToolUseRequest(BaseModel):
    """Assistant-requested tool invocation."""

    type: Literal["tool_use"] = "tool_use"
    tool_use_id: str
    tool_name: str
    input_json: str


class ToolInputDelta(BaseModel):
    type: Literal["tool_input_delta"] = "tool_input_delta"
    tool_use_id: str
    tool_name: str
    delta: str


class ToolResultEvent(BaseModel):
    """Result emitted after a tool invocation completes."""

    type: Literal["tool_result"] = "tool_result"
    tool_use_id: str
    tool_name: str
    output: str
    is_error: bool = False


class UsageEvent(BaseModel):
    """Token or cache usage reported by the model/provider."""

    type: Literal["usage"] = "usage"
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    model_id: str | None = None
    request_id: str | None = None


class MessageStop(BaseModel):
    """Logical end of one assistant message."""

    type: Literal["message_stop"] = "message_stop"
    stop_reason: StopReason | None = None


class PermissionEvent(BaseModel):
    """Permission decision taken before tool execution."""

    type: Literal["permission"] = "permission"
    tool_name: str
    allowed: bool
    reason: str | None = None


class HookEvent(BaseModel):
    """Observation emitted when a hook participates in the loop."""

    type: Literal["hook"] = "hook"
    hook_name: str
    phase: str
    messages: list[str] = Field(default_factory=list)


class CompactionEvent(BaseModel):
    """Session compaction summary for pre/post turn compaction."""

    type: Literal["compaction"] = "compaction"
    strategy: str
    removed_message_count: int = 0
    summary: str | None = None
    trigger: str | None = None
    tokens_before: int | None = None
    tokens_after: int | None = None
    pruned_tool_count: int = 0
    pruned_tool_results_count: int = 0
    cache_hit_estimated: bool | None = None
    compacted_message_ids: list[str] = Field(default_factory=list)
    fallback_used: bool = False
    summary_cache_read_tokens: int = 0


class ErrorEvent(BaseModel):
    """Provider/runtime error surfaced in-band."""

    type: Literal["error"] = "error"
    message: str
    code: str | None = None


class UnsupportedEvent(BaseModel):
    """Emitted when a capability is not implemented by the provider.

    This is the preferred in-band signal for unsupported runtime behavior.
    """

    type: Literal["unsupported"] = "unsupported"
    feature: str
    detail: str | None = None


class TurnStartEvent(BaseModel):
    """Emitted at the entry of run_turn(), before any LLM call."""

    type: Literal["turn_start"] = "turn_start"
    turn_index: int = 0


class TurnEndEvent(BaseModel):
    """Emitted at the exit of run_turn()."""

    type: Literal["turn_end"] = "turn_end"
    iterations_used: int = 0
    completed: bool = True


class ToolProgressEvent(BaseModel):
    """Emitted when a tool reports intermediate progress during execution.

    Tools opt in by calling the ``on_update`` callback passed to
    ``ToolExecutor.execute()``. Useful for long-running operations (file
    scans, network requests, MCP calls) to provide live feedback to the UI.
    """

    type: Literal["tool_progress"] = "tool_progress"
    tool_use_id: str
    tool_name: str
    update: str


class LoopExitEvent(BaseModel):
    """Emitted when a POST_TOOL_USE hook requests graceful loop exit.

    The loop stops after the current tool completes; no further LLM call is
    made. Used for ask_user-style patterns where the agent hands control back
    to the user and expects a fresh prompt to resume.
    ``reason`` is the explicit exit reason set via ``HookResult.exit_reason``.
    """

    type: Literal["loop_exit"] = "loop_exit"
    tool_name: str
    reason: str | None = None


class SteeringEvent(BaseModel):
    """Emitted when a POST_TOOL_USE hook injects steering messages.

    Remaining tool calls in the current iteration are skipped. The steering
    messages are appended to the session and a new LLM call is made so the
    model can re-plan with the updated context.
    ``skipped_tools`` is the number of tool calls skipped in this iteration.
    """

    type: Literal["steering"] = "steering"
    tool_name: str
    message_count: int
    skipped_tools: int = 0


Event = Annotated[
    Union[
        TurnStartEvent,
        TurnEndEvent,
        TextStart,
        TextDelta,
        TextEnd,
        ThinkingStart,
        ThinkingDelta,
        ThinkingEnd,
        ToolUseRequest,
        ToolInputDelta,
        ToolResultEvent,
        ToolProgressEvent,
        UsageEvent,
        MessageStop,
        PermissionEvent,
        HookEvent,
        CompactionEvent,
        ErrorEvent,
        UnsupportedEvent,
        LoopExitEvent,
        SteeringEvent,
    ],
    Field(discriminator="type"),
]
