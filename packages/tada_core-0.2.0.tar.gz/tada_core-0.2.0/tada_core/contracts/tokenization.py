"""Provider-neutral token estimation contracts.

The runtime prefers provider usage truth after an API call. These estimators are
fallbacks for preflight checks, first turns, and tests.
"""

from __future__ import annotations

import json
from typing import Protocol

from pydantic import BaseModel

from tada_core.contracts.messages import ConversationMessage
from tada_core.contracts.model import ApiRequest


class TokenEstimator(Protocol):
    def estimate_request(self, request: ApiRequest) -> int: ...

    def estimate_messages(
        self,
        messages: list[ConversationMessage],
        *,
        system_prompt: list[str] | None = None,
        tools: list[dict] | None = None,
    ) -> int: ...


class TokenEstimatorConfig(BaseModel):
    chars_per_token: int = 4
    image_token_estimate: int = 1500
    file_token_estimate: int = 800


class CharacterTokenEstimator:
    """Conservative dependency-free fallback that counts all content blocks."""

    def __init__(self, config: TokenEstimatorConfig | None = None) -> None:
        self.config = config or TokenEstimatorConfig()

    def _chars_to_tokens(self, value: str) -> int:
        if not value:
            return 0
        return max(1, len(value) // self.config.chars_per_token)

    def estimate_request(self, request: ApiRequest) -> int:
        return self.estimate_messages(
            request.messages,
            system_prompt=request.system_prompt,
            tools=request.tools,
        )

    def estimate_messages(
        self,
        messages: list[ConversationMessage],
        *,
        system_prompt: list[str] | None = None,
        tools: list[dict] | None = None,
    ) -> int:
        total = 0
        for prompt in system_prompt or []:
            total += self._chars_to_tokens(prompt)
        if tools:
            total += self._chars_to_tokens(json.dumps(tools, sort_keys=True, ensure_ascii=False))
        for message in messages:
            total += self._chars_to_tokens(message.role.value)
            for block in message.content:
                if block.type == "text" and block.text:
                    total += self._chars_to_tokens(block.text)
                elif block.type == "thinking" and block.thinking:
                    total += self._chars_to_tokens(block.thinking)
                elif block.type == "tool_use":
                    total += self._chars_to_tokens(block.tool_name or "")
                    total += self._chars_to_tokens(block.tool_input or "")
                elif block.type == "tool_result":
                    total += self._chars_to_tokens(block.tool_name or "")
                    total += self._chars_to_tokens(block.tool_result or "")
                elif block.type == "image":
                    total += self.config.image_token_estimate
                elif block.type == "file":
                    if block.source == "base64" and block.data:
                        total += self._chars_to_tokens(block.data)
                    else:
                        total += self.config.file_token_estimate
                else:
                    total += self._chars_to_tokens(block.model_dump_json())
        return total
