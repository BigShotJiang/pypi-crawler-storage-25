"""Tool registry and execution.

Tool execution is a core runtime contract when ``Capabilities.tools`` is
``True``. Tool definitions expose a small JSON Schema-compatible parameter
shape to model clients, while executors receive and return JSON strings so
providers can forward tool traffic without knowing host-specific Python types.
Unknown tools and handler failures must be explicit errors; runtimes should
surface them through ``ToolResultEvent(is_error=True)`` or another clear error
path rather than silently dropping the request.

The optional ``on_update`` callback passed to ``execute()`` lets a tool push
intermediate progress strings during a long-running operation. The runtime
converts each call into a ``ToolProgressEvent`` so the UI can show live
feedback without polling.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol

from tada_core.contracts.messages import ContentBlock


class ToolError(Exception):
    """Raised when a tool request cannot be executed."""

    pass


@dataclass
class ToolDefinition:
    """Portable tool schema advertised to model clients.

    ``parameters_schema`` is intentionally a JSON Schema subset. Host
    applications may use richer local types, but the provider boundary remains
    JSON-compatible.

    ``parallel`` marks this tool as safe to run concurrently with other
    parallel-marked tools in the same LLM response. The runner groups
    consecutive parallel tools and executes them with asyncio.gather; a
    steering or exit_loop signal from any completed tool immediately cancels
    the remaining tasks in the group.
    """

    name: str
    description: str
    parameters_schema: dict[str, Any]  # JSON Schema subset
    parallel: bool = False


@dataclass
class ToolResult:
    """Structured tool result with optional multimodal blocks."""

    content: str = ""
    content_blocks: list[ContentBlock] = field(default_factory=list)
    is_error: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


UpdateCallback = Callable[[str], None]
ToolOutput = str | ToolResult
ToolNextCall = Callable[[], Awaitable[ToolOutput]]
ToolMiddleware = Callable[[str, str, UpdateCallback | None, ToolNextCall], Awaitable[ToolOutput]]


class ToolExecutor(ABC):
    """Execute provider-agnostic tool calls asynchronously.

    Implementations accept a tool name and a JSON string input, and return a
    JSON string output. They should raise ``ToolError`` for unknown tools or
    invalid execution requests so runtimes can emit an explicit error result.

    The optional ``on_update`` callback may be called zero or more times during
    execution to push intermediate progress strings. The runtime converts each
    call into a ``ToolProgressEvent`` yielded in-band.
    """

    @abstractmethod
    async def execute(
        self,
        tool_name: str,
        input_json: str,
        on_update: UpdateCallback | None = None,
    ) -> ToolOutput:
        raise NotImplementedError

    def list_tools(self) -> list[ToolDefinition]:
        """Return the tools currently available to the runtime."""
        return []


class InMemoryToolExecutor(ToolExecutor):
    """Map tool names to callables returning JSON strings.

    Registered functions may be sync or async — both are supported.
    If the registered function accepts an ``on_update`` keyword argument it
    will receive the callback; otherwise it is called without it.
    """

    def __init__(self) -> None:
        self._tools: dict[str, tuple[ToolDefinition, Any]] = {}

    def register(self, spec: ToolDefinition, fn: Any) -> None:
        self._tools[spec.name] = (spec, fn)

    def list_tools(self) -> list[ToolDefinition]:
        return [t[0] for t in self._tools.values()]

    async def execute(
        self,
        tool_name: str,
        input_json: str,
        on_update: UpdateCallback | None = None,
    ) -> ToolOutput:
        import inspect

        if tool_name not in self._tools:
            raise ToolError(f"unknown tool: {tool_name}")
        _, fn = self._tools[tool_name]
        sig = inspect.signature(fn)
        if "on_update" in sig.parameters:
            result = fn(input_json, on_update=on_update)
        else:
            result = fn(input_json)
        if inspect.isawaitable(result):
            result = await result
        return result


class ChainedToolExecutor(ToolExecutor):
    """Wrap an executor with ordered async middleware."""

    def __init__(self, inner: ToolExecutor, middlewares: list[ToolMiddleware]) -> None:
        self._inner = inner
        self._middlewares = list(middlewares)

    def list_tools(self) -> list[ToolDefinition]:
        return self._inner.list_tools()

    async def execute(
        self,
        tool_name: str,
        input_json: str,
        on_update: UpdateCallback | None = None,
    ) -> ToolOutput:
        async def call_inner() -> ToolOutput:
            return await self._inner.execute(tool_name, input_json, on_update=on_update)

        next_call = call_inner
        for middleware in reversed(self._middlewares):
            previous_next = next_call

            async def wrapped(
                mw: ToolMiddleware = middleware,
                nxt: ToolNextCall = previous_next,
            ) -> ToolOutput:
                return await mw(tool_name, input_json, on_update, nxt)

            next_call = wrapped

        return await next_call()


class ToolExecutorProtocol(Protocol):
    """Structural protocol for lightweight integrations."""

    async def execute(
        self,
        tool_name: str,
        input_json: str,
        on_update: UpdateCallback | None = None,
    ) -> ToolOutput: ...
