"""Model clients for the agent loop.

Backward-compatible re-exports. New code should prefer:
  - tada_core.contracts.models.ModelSpec
  - tada_core.providers.build_model_client
  - tada_core.providers.anthropic.AnthropicModelClient
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Callable

from tada_core.contracts.model import ApiRequest
from tada_core.providers.anthropic import (
    AnthropicModelClient,
    CacheRetention,
    apply_anthropic_cache_control as _apply_anthropic_cache_control,
    parse_anthropic_response as _parse_anthropic_response,
    parse_anthropic_stream as _parse_anthropic_stream,
    serialize_anthropic_messages as _serialize_anthropic_messages,
    serialize_anthropic_tools as _serialize_anthropic_tools,
)
from tada_core.providers.openai_completions import OpenAICompletionsModelClient
from tada_core.providers.openai_utils import (
    parse_openai_completions_batch as _parse_batch_payload,
    parse_openai_completions_stream as _parse_stream_payload,
    usage_from_payload as _usage_from_payload,
)

TransportFn = Callable[[ApiRequest, bool], dict[str, Any] | Iterable[dict[str, Any]]]

OpenAICompatibleModelClient = OpenAICompletionsModelClient


def make_echo_transport() -> TransportFn:
    """Return an OpenAI-like local transport used as the default baseline path."""

    def _transport(request: ApiRequest, stream: bool) -> dict[str, Any] | Iterable[dict[str, Any]]:
        last_user = ""
        for message in reversed(request.messages):
            text = message.text_only()
            if text:
                last_user = text
                break
        if stream:
            return [
                {"choices": [{"delta": {"content": last_user[: max(1, len(last_user) // 2)]}}]},
                {"choices": [{"delta": {"content": last_user[max(1, len(last_user) // 2) :]}}]},
                {
                    "choices": [{"delta": {}, "finish_reason": "stop"}],
                    "usage": {
                        "input_tokens": max(1, len(last_user) // 4),
                        "output_tokens": max(1, len(last_user) // 4),
                    },
                },
            ]
        return {
            "choices": [{"message": {"content": last_user}, "finish_reason": "stop"}],
            "usage": {
                "input_tokens": max(1, len(last_user) // 4),
                "output_tokens": max(1, len(last_user) // 4),
            },
        }

    return _transport


__all__ = [
    "AnthropicModelClient",
    "CacheRetention",
    "OpenAICompatibleModelClient",
    "OpenAICompletionsModelClient",
    "TransportFn",
    "make_echo_transport",
    "_apply_anthropic_cache_control",
    "_parse_anthropic_response",
    "_parse_anthropic_stream",
    "_parse_batch_payload",
    "_parse_stream_payload",
    "_serialize_anthropic_messages",
    "_serialize_anthropic_tools",
    "_usage_from_payload",
]
