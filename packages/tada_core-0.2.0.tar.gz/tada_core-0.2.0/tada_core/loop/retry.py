"""Retry wrapper for model clients."""

from __future__ import annotations

import asyncio
import random
from collections.abc import AsyncIterator

from pydantic import BaseModel, ConfigDict, Field

from tada_core.contracts.model import ApiRequest, AssistantEvent, ModelClient


class RetryPolicy(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    max_attempts: int = 3
    initial_backoff_s: float = 1.0
    max_backoff_s: float = 30.0
    backoff_multiplier: float = 2.0
    jitter: float = 0.25
    retry_on_status: set[int] = Field(default_factory=lambda: {408, 429, 500, 502, 503, 504})
    retry_on_exceptions: tuple[type[BaseException], ...] = ()


def _status_code(exc: BaseException) -> int | None:
    status = getattr(exc, "status_code", None)
    if isinstance(status, int):
        return status
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    return status if isinstance(status, int) else None


class RetryingModelClient(ModelClient):
    """Retry a model stream only until the first event is yielded."""

    def __init__(self, inner: ModelClient, policy: RetryPolicy | None = None) -> None:
        self._inner = inner
        self._policy = policy or RetryPolicy()

    def estimate_tokens(self, request: ApiRequest) -> int | None:
        return self._inner.estimate_tokens(request)

    def _should_retry(self, exc: BaseException) -> bool:
        if self._policy.retry_on_exceptions and isinstance(exc, self._policy.retry_on_exceptions):
            return True
        status = _status_code(exc)
        return status in self._policy.retry_on_status if status is not None else False

    async def _sleep_before_retry(self, attempt_index: int) -> None:
        base = min(
            self._policy.initial_backoff_s
            * (self._policy.backoff_multiplier ** max(0, attempt_index - 1)),
            self._policy.max_backoff_s,
        )
        if self._policy.jitter:
            base += random.uniform(0, base * self._policy.jitter)
        if base > 0:
            await asyncio.sleep(base)

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            attempt = 0
            while True:
                attempt += 1
                emitted = False
                try:
                    async for event in self._inner.stream(request):
                        emitted = True
                        yield event
                    return
                except BaseException as exc:
                    if emitted or attempt >= self._policy.max_attempts or not self._should_retry(exc):
                        raise
                    await self._sleep_before_retry(attempt)

        return _gen()
