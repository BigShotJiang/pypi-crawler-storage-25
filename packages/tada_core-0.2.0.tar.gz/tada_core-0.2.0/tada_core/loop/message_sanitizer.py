"""Message helpers for safe compaction boundaries."""

from __future__ import annotations

import json
from typing import Any

from tada_core.contracts.compaction import ToolResultPruningConfig
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole

ORPHAN_TOOL_STUB = "[Result from earlier conversation; see compacted summary]"


def _message_tool_uses(message: ConversationMessage) -> list[ContentBlock]:
    return [block for block in message.content if block.type == "tool_use" and block.tool_use_id]


def _message_tool_results(message: ConversationMessage) -> list[ContentBlock]:
    return [block for block in message.content if block.type == "tool_result" and block.tool_use_id]


def sanitize_tool_pairs(messages: list[ConversationMessage]) -> list[ConversationMessage]:
    """Drop orphan results and add stub results for retained orphan tool uses."""

    tool_use_ids = {
        block.tool_use_id
        for message in messages
        for block in _message_tool_uses(message)
        if block.tool_use_id
    }
    tool_result_ids = {
        block.tool_use_id
        for message in messages
        for block in _message_tool_results(message)
        if block.tool_use_id
    }

    sanitized: list[ConversationMessage] = []
    for message in messages:
        if message.role != MessageRole.TOOL:
            sanitized.append(message)
            continue
        kept_blocks = [
            block
            for block in message.content
            if block.type != "tool_result" or block.tool_use_id in tool_use_ids
        ]
        if kept_blocks:
            sanitized.append(message.model_copy(update={"content": kept_blocks}, deep=True))

    missing_results = tool_use_ids - tool_result_ids
    for tool_use_id in sorted(missing_results):
        tool_name = ""
        for message in messages:
            for block in _message_tool_uses(message):
                if block.tool_use_id == tool_use_id:
                    tool_name = block.tool_name or ""
                    break
            if tool_name:
                break
        sanitized.append(
            ConversationMessage(
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id=tool_use_id,
                        tool_name=tool_name,
                        tool_result=ORPHAN_TOOL_STUB,
                    )
                ],
            )
        )
    return sanitized


def _truncate(value: str, max_chars: int) -> str:
    if len(value) <= max_chars:
        return value
    return value[:max_chars] + "...[truncated]"


def _message_id(message: ConversationMessage, index: int) -> str | None:
    return message.id or f"index:{index}"


def _should_prune_index(
    index: int,
    total: int,
    *,
    config: ToolResultPruningConfig,
    head_count: int,
    tail_count: int,
) -> bool:
    keep_tail = config.keep_tail_messages if config.keep_tail_messages is not None else tail_count
    tail_start = max(0, total - max(0, keep_tail))
    middle_start = max(0, head_count)
    middle_end = max(middle_start, total - max(0, tail_count))

    if config.scope == "middle_only":
        return middle_start <= index < middle_end
    if config.scope == "outside_tail":
        return index < tail_start
    if config.scope == "all_except_recent":
        return index < tail_start
    return False


def prune_tool_results_for_compaction(
    messages: list[ConversationMessage],
    *,
    config: ToolResultPruningConfig,
    head_count: int = 0,
    tail_count: int = 0,
) -> tuple[list[ConversationMessage], dict[str, Any]]:
    """Replace old oversized tool results with placeholders before summarization.

    This changes only the copy returned by this helper. Callers can use the
    manifest to preserve audit metadata or to mark source messages in a host
    store such as ReMe.
    """

    manifest: dict[str, Any] = {"pruned_tool_count": 0, "pruned_tool_results": []}
    if not config.enabled:
        return list(messages), manifest

    pruned: list[ConversationMessage] = []
    total = len(messages)
    for message_index, message in enumerate(messages):
        if not _should_prune_index(
            message_index,
            total,
            config=config,
            head_count=head_count,
            tail_count=tail_count,
        ):
            pruned.append(message)
            continue

        changed = False
        new_blocks: list[ContentBlock] = []
        for block_index, block in enumerate(message.content):
            if block.type != "tool_result" or not block.tool_result:
                new_blocks.append(block)
                continue

            limit = config.preserve_error_chars if block.is_error else config.max_chars
            if len(block.tool_result) <= limit or block.tool_result == config.placeholder:
                new_blocks.append(block)
                continue

            manifest["pruned_tool_count"] += 1
            manifest["pruned_tool_results"].append(
                {
                    "message_id": _message_id(message, message_index),
                    "message_index": message_index,
                    "block_index": block_index,
                    "tool_use_id": block.tool_use_id,
                    "tool_name": block.tool_name,
                    "is_error": block.is_error,
                    "original_chars": len(block.tool_result),
                    "preserved_chars": len(config.placeholder),
                }
            )
            new_blocks.append(block.model_copy(update={"tool_result": config.placeholder}, deep=True))
            changed = True

        pruned.append(message.model_copy(update={"content": new_blocks}, deep=True) if changed else message)

    return pruned, manifest


def serialize_messages_for_compaction(
    messages: list[ConversationMessage],
    *,
    max_block_chars: int = 2000,
) -> tuple[str, dict[str, Any]]:
    """Serialize messages for summary prompts without embedding binary payloads."""

    lines: list[str] = []
    manifest: dict[str, Any] = {"artifacts": [], "pruned_tool_count": 0}

    for message_index, message in enumerate(messages):
        lines.append(f"{message.role.value}:")
        for block in message.content:
            if block.type == "text" and block.text:
                lines.append(f"  text: {_truncate(block.text, max_block_chars)}")
            elif block.type == "thinking" and block.thinking:
                lines.append(f"  thinking: {_truncate(block.thinking, max_block_chars)}")
            elif block.type == "tool_use":
                lines.append(
                    "  tool_use: "
                    + json.dumps(
                        {
                            "id": block.tool_use_id,
                            "name": block.tool_name,
                            "input": _truncate(block.tool_input or "", max_block_chars),
                        },
                        ensure_ascii=False,
                    )
                )
            elif block.type == "tool_result":
                if block.tool_result and len(block.tool_result) > max_block_chars:
                    manifest["pruned_tool_count"] += 1
                lines.append(
                    "  tool_result: "
                    + json.dumps(
                        {
                            "id": block.tool_use_id,
                            "name": block.tool_name,
                            "is_error": block.is_error,
                            "result": _truncate(block.tool_result or "", max_block_chars),
                        },
                        ensure_ascii=False,
                    )
                )
            elif block.type in {"image", "file"}:
                artifact = {
                    "type": block.type,
                    "source": block.source,
                    "mime_type": block.mime_type,
                    "name": block.name,
                    "url": block.url,
                    "source_message_index": message_index,
                }
                manifest["artifacts"].append(artifact)
                lines.append(
                    f"  {block.type}: [artifact_ref index={len(manifest['artifacts']) - 1}]"
                )
            else:
                lines.append(f"  {block.type}: {_truncate(block.model_dump_json(), max_block_chars)}")
    return "\n".join(lines), manifest
