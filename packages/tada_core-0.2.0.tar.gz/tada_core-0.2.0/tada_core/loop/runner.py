"""Agent execution loop (claw-code–style while loop)."""

from __future__ import annotations

import asyncio
import uuid
from collections.abc import AsyncIterator, Callable
from typing import Any

from tada_core.contracts.budget import BudgetLimits
from tada_core.contracts.compaction import (
    CompactionConfig,
    CompactionMode,
    CompactionStrategy,
    NeverCompact,
    StructuredSummaryCompaction,
)
from tada_core.contracts.events import (
    CompactionEvent,
    ErrorEvent,
    Event,
    HookEvent,
    LoopExitEvent,
    MessageStop,
    PermissionEvent,
    SteeringEvent,
    TextDelta,
    TextEnd,
    TextStart,
    ThinkingDelta,
    ThinkingEnd,
    ThinkingStart,
    ToolInputDelta,
    ToolProgressEvent,
    ToolResultEvent,
    ToolUseRequest,
    TurnEndEvent,
    TurnStartEvent,
    UsageEvent,
)
from tada_core.contracts.hooks import HookResult, HookRunner, NoOpHookRunner
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import (
    ApiRequest,
    AssistantEvent,
    AssistantEventKind,
    ModelClient,
    StopReason,
)
from tada_core.contracts.permissions import PermissionContext, PermissionOutcome, PermissionPolicy
from tada_core.contracts.session import SessionState
from tada_core.contracts.tools import InMemoryToolExecutor, ToolError, ToolExecutor, ToolResult


def _merge_hook_messages(base: str, hook: HookResult) -> str:
    if not hook.messages:
        return base
    prefix = "\n".join(hook.messages)
    return f"{prefix}\n{base}" if base else prefix


# (global_idx_in_pending_tools, tool_use_id, tool_name, input_json)
_ToolEntry = tuple[int, str, str, str]
# (events_to_yield, post_hook_result, is_error, final_output, content_blocks, metadata)
_ToolRunResult = tuple[list[Event], HookResult, bool, str, list[ContentBlock], dict[str, Any]]


def _normalize_tool_output(
    output: str | ToolResult,
    *,
    is_error: bool,
) -> tuple[str, bool, list[ContentBlock], dict[str, Any]]:
    if isinstance(output, ToolResult):
        return (
            output.content,
            is_error or output.is_error,
            list(output.content_blocks),
            dict(output.metadata),
        )
    return str(output), is_error, [], {}


def _tool_result_content_block(
    *,
    tool_use_id: str,
    tool_name: str,
    output: str,
    is_error: bool,
    content_blocks: list[ContentBlock],
    metadata: dict[str, Any],
) -> ContentBlock:
    extra: dict[str, Any] = {}
    if content_blocks:
        extra["content_blocks"] = [
            block.model_dump(mode="json", exclude_none=True)
            for block in content_blocks
        ]
    if metadata:
        extra["metadata"] = metadata
    return ContentBlock(
        type="tool_result",
        tool_use_id=tool_use_id,
        tool_name=tool_name,
        tool_result=output,
        is_error=is_error,
        extra=extra,
    )


class AgentLoop:
    """The tada-core agent execution loop.

    Drives the model ↔ tool ↔ hook cycle until the model stops requesting
    tools or max_iterations is reached.

    Tools marked ``parallel=True`` in their ``ToolDefinition`` are grouped
    with consecutive parallel tools and executed concurrently via
    ``asyncio.create_task``. A steering or exit_loop signal from any completed
    task immediately cancels the remaining tasks in the group.
    """

    def __init__(
        self,
        model: ModelClient,
        *,
        system_prompt: list[str] | None = None,
        max_iterations: int = 32,
        compaction: CompactionStrategy | CompactionConfig | str | None = None,
    ) -> None:
        self._model = model
        self._system_prompt = system_prompt or []
        self._max_iterations = max_iterations
        from tada_core.contracts.permissions import AllowAllPolicy

        self._permission: PermissionPolicy = AllowAllPolicy()
        self._hooks: HookRunner = NoOpHookRunner()
        self._compaction_mode: CompactionMode = CompactionMode.AUTO
        self._compaction: CompactionStrategy = self._resolve_compaction(compaction)
        self._tools: ToolExecutor = InMemoryToolExecutor()
        self._context_transform: Callable[[list[ConversationMessage]], list[ConversationMessage]] | None = None
        self._budget: BudgetLimits | None = None
        self._model_spec = getattr(model, "model_spec", None) or getattr(model, "_model_spec", None)

    def _resolve_compaction(
        self,
        compaction: CompactionStrategy | CompactionConfig | str | None,
    ) -> CompactionStrategy:
        if compaction is None:
            self._compaction_mode = CompactionMode.AUTO
            return StructuredSummaryCompaction(self._model)
        if isinstance(compaction, str):
            compaction = CompactionConfig(mode=compaction)
        if isinstance(compaction, CompactionConfig):
            self._compaction_mode = compaction.mode
            if compaction.mode in {CompactionMode.DISABLED, CompactionMode.HOOK_ONLY}:
                return NeverCompact()
            return StructuredSummaryCompaction(
                self._model,
                threshold_tokens=compaction.threshold_tokens,
                threshold_ratio=compaction.threshold_ratio,
                keep_last=compaction.keep_last,
                head_protect=compaction.head_protect,
                cooldown_seconds=compaction.cooldown_seconds,
                tail_token_budget=compaction.tail_token_budget,
                tool_result_pruning=compaction.tool_result_pruning,
            )
        self._compaction_mode = CompactionMode.AUTO
        return compaction

    def set_permission_policy(self, policy: PermissionPolicy) -> None:
        self._permission = policy

    def set_hook_runner(self, runner: HookRunner) -> None:
        self._hooks = runner

    def set_compaction_strategy(self, strategy: CompactionStrategy) -> None:
        self._compaction = strategy
        self._compaction_mode = CompactionMode.AUTO

    def set_tool_executor(self, executor: ToolExecutor) -> None:
        self._tools = executor

    def set_context_transform(
        self,
        transform: Callable[[list[ConversationMessage]], list[ConversationMessage]] | None,
    ) -> None:
        """Optional message-list transform applied before PRE_LLM_CALL hooks."""
        self._context_transform = transform

    def set_budget_policy(self, budget: BudgetLimits | None) -> None:
        """Set provider-agnostic runtime budget limits."""
        self._budget = budget

    def _build_api_request(self, state: SessionState) -> ApiRequest:
        tools: list[dict[str, Any]] = []
        for td in self._tools.list_tools():
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": td.name,
                        "description": td.description,
                        "parameters": td.parameters_schema,
                    },
                }
            )
        return ApiRequest(
            system_prompt=list(self._system_prompt),
            messages=list(state.messages),
            tools=tools,
            model_spec=self._model_spec,
        )

    async def compact(self, state: SessionState, *, trigger: str = "manual") -> CompactionEvent | None:
        req = self._build_api_request(state)
        try:
            should_compact = self._compaction.should_compact(
                state,
                trigger=trigger,
                system_prompt=req.system_prompt,
                tools=req.tools,
            )
        except TypeError:
            should_compact = self._compaction.should_compact(state, trigger=trigger)
        if not should_compact:
            return None
        compact_fn = getattr(self._compaction, "compact_async", None)
        if compact_fn is not None:
            try:
                result = await compact_fn(
                    state,
                    trigger=trigger,
                    system_prompt=req.system_prompt,
                    tools=req.tools,
                )
            except TypeError:
                result = await compact_fn(state, trigger=trigger)
        else:
            result = self._compaction.compact(state, trigger=trigger)
        return CompactionEvent(
            strategy=type(self._compaction).__name__,
            removed_message_count=result.removed_message_count,
            summary=result.summary,
            trigger=result.trigger or trigger,
            tokens_before=result.tokens_before,
            tokens_after=result.tokens_after,
            pruned_tool_count=result.pruned_tool_count,
            pruned_tool_results_count=len(result.pruned_tool_results),
            cache_hit_estimated=result.cache_hit_estimated,
            compacted_message_ids=result.compacted_message_ids,
            fallback_used=result.fallback_used,
            summary_cache_read_tokens=result.summary_cache_read_tokens,
        )

    def _note_usage(self, state: SessionState, usage: Any) -> None:
        if usage is None:
            return
        state.usage.input_tokens += usage.input_tokens
        state.usage.output_tokens += usage.output_tokens
        state.usage.cache_read_tokens += usage.cache_read_tokens
        state.usage.cache_creation_tokens += getattr(usage, "cache_creation_tokens", 0)
        state.metadata["last_usage"] = usage.model_dump() if hasattr(usage, "model_dump") else {
            "input_tokens": usage.input_tokens,
            "output_tokens": usage.output_tokens,
            "cache_read_tokens": usage.cache_read_tokens,
            "cache_creation_tokens": getattr(usage, "cache_creation_tokens", 0),
        }

    def _is_parallel_tool(self, tool_name: str) -> bool:
        for td in self._tools.list_tools():
            if td.name == tool_name:
                return td.parallel
        return False

    def _group_pending_tools(
        self, pending_tools: list[tuple[str, str, str]]
    ) -> list[list[_ToolEntry]]:
        """Split pending_tools into sequential and parallel groups.

        Consecutive parallel-marked tools form one group and run concurrently.
        Sequential tools are single-item groups and always run one at a time.
        """
        groups: list[list[_ToolEntry]] = []
        current_parallel: list[_ToolEntry] = []
        for idx, (tid, name, inp) in enumerate(pending_tools):
            if self._is_parallel_tool(name):
                current_parallel.append((idx, tid, name, inp))
            else:
                if current_parallel:
                    groups.append(current_parallel)
                    current_parallel = []
                groups.append([(idx, tid, name, inp)])
        if current_parallel:
            groups.append(current_parallel)
        return groups

    async def _run_one_tool(
        self,
        tool_use_id: str,
        tool_name: str,
        input_json: str,
    ) -> _ToolRunResult:
        """Execute one tool call end-to-end. Collects all events into a list
        so the caller can yield them (and cancel this coroutine if needed).
        Returns (events, post_hook_result, is_error, final_output).
        """
        events: list[Event] = []

        pre = await self._hooks.run_pre_tool_use(tool_name, input_json)
        if pre.messages:
            events.append(HookEvent(hook_name="pre_tool_use", phase="PreToolUse", messages=pre.messages))
        eff = pre.updated_input if pre.updated_input is not None else input_json
        ctx = PermissionContext(pre.permission_override, pre.permission_reason)

        if pre.cancelled or pre.failed or pre.denied:
            reason = "hook denied or failed"
            out = _merge_hook_messages(f"tool blocked: {reason}", pre)
            events.append(PermissionEvent(tool_name=tool_name, allowed=False, reason=reason))
            events.append(ToolResultEvent(tool_use_id=tool_use_id, tool_name=tool_name, output=out, is_error=True))
            return events, pre, True, out, [], {}

        outcome = self._permission.authorize(tool_name, eff, context=ctx, prompter=None)
        allowed = outcome == PermissionOutcome.ALLOW
        events.append(PermissionEvent(
            tool_name=tool_name,
            allowed=allowed,
            reason=None if allowed else "denied by policy",
        ))
        if not allowed:
            out = "permission denied"
            events.append(ToolResultEvent(tool_use_id=tool_use_id, tool_name=tool_name, output=out, is_error=True))
            return events, HookResult(denied=True), True, out, [], {}

        progress_events: list[ToolProgressEvent] = []

        def _on_update(update: str) -> None:
            progress_events.append(ToolProgressEvent(
                tool_use_id=tool_use_id,
                tool_name=tool_name,
                update=update,
            ))

        try:
            tool_output = await self._tools.execute(tool_name, eff, on_update=_on_update)
            raw, is_err, content_blocks, metadata = _normalize_tool_output(
                tool_output,
                is_error=False,
            )
        except (ToolError, Exception) as e:
            raw = str(e)
            is_err = True
            content_blocks = []
            metadata = {}

        events.extend(progress_events)

        if is_err:
            fail_hook = await self._hooks.run_post_tool_use_failure(tool_name, eff, raw)
            if fail_hook.messages:
                events.append(HookEvent(
                    hook_name="post_tool_use_failure",
                    phase="PostToolUseFailure",
                    messages=fail_hook.messages,
                ))
            raw = _merge_hook_messages(raw, fail_hook)
            post = fail_hook
        else:
            post = await self._hooks.run_post_tool_use(tool_name, eff, raw, is_error=is_err)
            if post.messages:
                events.append(HookEvent(
                    hook_name="post_tool_use",
                    phase="PostToolUse",
                    messages=post.messages,
                ))
            raw = _merge_hook_messages(raw, post)

        if post.denied or post.failed or post.cancelled:
            is_err = True

        events.append(ToolResultEvent(
            tool_use_id=tool_use_id,
            tool_name=tool_name,
            output=raw,
            is_error=is_err,
        ))
        return events, post, is_err, raw, content_blocks, metadata

    async def _prepare_messages_for_llm(self, state: SessionState) -> None:
        if self._context_transform is not None:
            state.messages = self._context_transform(list(state.messages))

    async def _consume_model_stream(
        self,
        state: SessionState,
        req: ApiRequest,
    ) -> AsyncIterator[Event | tuple[list[tuple[str, str, str]], str]]:
        events = self._model.stream(req)
        assistant_blocks: list[ContentBlock] = []
        pending_tools: list[tuple[str, str, str]] = []
        text_acc: list[str] = []
        thinking_acc: list[str] = []
        thinking_signature_last: str | None = None
        stop_reason: StopReason | None = None

        async for ev in events:
            if ev.kind == AssistantEventKind.TEXT_START:
                yield TextStart()
            elif ev.kind == AssistantEventKind.TEXT_DELTA and ev.text_delta:
                text_acc.append(ev.text_delta)
                yield TextDelta(text=ev.text_delta)
            elif ev.kind == AssistantEventKind.TEXT_END:
                if ev.text_delta:
                    text_acc = [ev.text_delta]
                if text_acc:
                    assistant_blocks.append(
                        ContentBlock(type="text", text="".join(text_acc))
                    )
                yield TextEnd(text="".join(text_acc))
                text_acc = []
            elif ev.kind == AssistantEventKind.THINKING_START:
                yield ThinkingStart()
            elif ev.kind == AssistantEventKind.THINKING_DELTA and ev.thinking_delta:
                thinking_acc.append(ev.thinking_delta)
                yield ThinkingDelta(text=ev.thinking_delta)
            elif ev.kind == AssistantEventKind.THINKING_END:
                if ev.thinking_delta:
                    thinking_acc = [ev.thinking_delta]
                if ev.thinking_signature:
                    thinking_signature_last = ev.thinking_signature
                if thinking_acc:
                    assistant_blocks.append(
                        ContentBlock(
                            type="thinking",
                            thinking="".join(thinking_acc),
                            # Anthropic Messages API rejects any later turn
                            # whose history contains a ``thinking`` block
                            # without a matching ``signature``; provider
                            # adapters must surface it here.
                            signature=thinking_signature_last,
                        )
                    )
                yield ThinkingEnd(text="".join(thinking_acc))
                thinking_acc = []
                thinking_signature_last = None
            elif ev.kind == AssistantEventKind.TOOL_INPUT_DELTA:
                yield ToolInputDelta(
                    tool_use_id=ev.tool_use_id or "",
                    tool_name=ev.tool_name or "",
                    delta=ev.tool_input_delta or "",
                )
            elif ev.kind == AssistantEventKind.TOOL_USE:
                tid = ev.tool_use_id or str(uuid.uuid4())
                name = ev.tool_name or ""
                inp = ev.tool_input or "{}"
                assistant_blocks.append(
                    ContentBlock(
                        type="tool_use",
                        tool_use_id=tid,
                        tool_name=name,
                        tool_input=inp,
                    )
                )
                pending_tools.append((tid, name, inp))
                yield ToolUseRequest(tool_use_id=tid, tool_name=name, input_json=inp)
            elif ev.kind == AssistantEventKind.USAGE and ev.usage:
                self._note_usage(state, ev.usage)
                yield UsageEvent(
                    input_tokens=ev.usage.input_tokens,
                    output_tokens=ev.usage.output_tokens,
                    cache_read_tokens=ev.usage.cache_read_tokens,
                    cache_creation_tokens=ev.usage.cache_creation_tokens,
                    model_id=ev.model_id,
                    request_id=ev.request_id,
                )
                if self._budget is not None:
                    reason = self._budget.check_usage(state.usage)
                    if reason is not None:
                        yield ErrorEvent(message=reason, code="budget_exceeded")
                        return
            elif ev.kind == AssistantEventKind.MESSAGE_STOP:
                stop_reason = ev.stop_reason
                yield MessageStop(stop_reason=stop_reason)

        if text_acc and not any(b.type == "text" for b in assistant_blocks):
            assistant_blocks.insert(0, ContentBlock(type="text", text="".join(text_acc)))
        if thinking_acc and not any(b.type == "thinking" for b in assistant_blocks):
            assistant_blocks.insert(
                0,
                ContentBlock(
                    type="thinking",
                    thinking="".join(thinking_acc),
                    signature=thinking_signature_last,
                ),
            )

        if assistant_blocks:
            assistant_msg = ConversationMessage(
                role=MessageRole.ASSISTANT,
                content=assistant_blocks,
                stop_reason=stop_reason.value if stop_reason else None,
            )
            spec = req.model_spec
            if spec is not None:
                assistant_msg.provider = getattr(spec, "provider", None)
                assistant_msg.api = getattr(spec, "api", None)
                assistant_msg.model = getattr(spec, "id", None)
            state.messages.append(assistant_msg)

        yield pending_tools, "".join(text_acc)

    async def _run_iteration_loop(
        self,
        state: SessionState,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        iterations = 0
        completed_without_pending_tools = False
        while iterations < self._max_iterations:
            if abort and getattr(abort, "is_set", lambda: False)():
                yield ErrorEvent(message="aborted during turn", code="aborted")
                return
            if self._budget is not None:
                reason = self._budget.check_iteration(iterations)
                if reason is not None:
                    yield ErrorEvent(message=reason, code="budget_exceeded")
                    break
            iterations += 1

            await self._prepare_messages_for_llm(state)

            pre_llm = await self._hooks.run_pre_llm_call(list(state.messages))
            if pre_llm.messages:
                yield HookEvent(hook_name="pre_llm_call", phase="PreLlmCall", messages=pre_llm.messages)
            if pre_llm.updated_messages is not None:
                state.messages = pre_llm.updated_messages

            req = self._build_api_request(state)
            try:
                stream = self._consume_model_stream(state, req)
                pending_tools: list[tuple[str, str, str]] = []
                collected_text = ""
                async for item in stream:
                    if isinstance(item, tuple):
                        pending_tools, collected_text = item
                    else:
                        yield item
            except Exception as e:
                yield ErrorEvent(message=str(e), code="model_error")
                return

            tool_names_called = [t[1] for t in pending_tools]
            post_llm = await self._hooks.run_post_llm_call(tool_names_called, collected_text)
            if post_llm.messages:
                yield HookEvent(hook_name="post_llm_call", phase="PostLlmCall", messages=post_llm.messages)
            if post_llm.updated_messages is not None:
                state.messages = post_llm.updated_messages

            if (
                self._compaction_mode == CompactionMode.AUTO
                and not pre_llm.compaction_handled
                and not pre_llm.skip_builtin_compaction
                and not post_llm.compaction_handled
                and not post_llm.skip_builtin_compaction
            ):
                post_llm_compaction = await self.compact(state, trigger="post_llm")
                if post_llm_compaction is not None:
                    yield post_llm_compaction

            if not pending_tools:
                completed_without_pending_tools = True
                break
            if self._budget is not None:
                reason = self._budget.check_tool_calls(len(pending_tools))
                if reason is not None:
                    yield ErrorEvent(message=reason, code="budget_exceeded")
                    break

            groups = self._group_pending_tools(pending_tools)
            exit_loop_requested = False
            stop_iteration = False

            for group_idx, group in enumerate(groups):
                if abort and getattr(abort, "is_set", lambda: False)():
                    yield ErrorEvent(message="aborted during tool execution", code="aborted")
                    return

                if len(group) == 1:
                    global_idx, tool_use_id, tool_name, input_json = group[0]
                    evs, post, is_err, raw, content_blocks, metadata = await self._run_one_tool(
                        tool_use_id, tool_name, input_json
                    )
                    for ev in evs:
                        yield ev
                    state.messages.append(ConversationMessage(
                        role=MessageRole.TOOL,
                        content=[_tool_result_content_block(
                            tool_use_id=tool_use_id,
                            tool_name=tool_name,
                            output=raw,
                            is_error=is_err,
                            content_blocks=content_blocks,
                            metadata=metadata,
                        )],
                    ))

                    if post.steering_messages:
                        skipped = len(pending_tools) - global_idx - 1
                        yield SteeringEvent(
                            tool_name=tool_name,
                            message_count=len(post.steering_messages),
                            skipped_tools=skipped,
                        )
                        for sm in post.steering_messages:
                            state.messages.append(sm)
                        stop_iteration = True
                        break

                    if post.exit_loop:
                        yield LoopExitEvent(tool_name=tool_name, reason=post.exit_reason)
                        exit_loop_requested = True
                        stop_iteration = True
                        break

                else:
                    task_map: dict[asyncio.Task, _ToolEntry] = {
                        asyncio.create_task(
                            self._run_one_tool(tid, name, inp)
                        ): (gidx, tid, name, inp)
                        for gidx, tid, name, inp in group
                    }
                    remaining: dict[asyncio.Task, _ToolEntry] = dict(task_map)
                    completed: dict[int, tuple[
                        str,
                        str,
                        bool,
                        str,
                        list[ContentBlock],
                        dict[str, Any],
                    ]] = {}
                    signal_post: HookResult | None = None
                    signal_tool_name = ""

                    while remaining:
                        done, _ = await asyncio.wait(
                            remaining.keys(), return_when=asyncio.FIRST_COMPLETED
                        )
                        for task in done:
                            del remaining[task]
                            gidx, tid, name, inp = task_map[task]
                            try:
                                evs, post, is_err, raw, content_blocks, metadata = await task
                            except asyncio.CancelledError:
                                continue
                            for ev in evs:
                                yield ev
                            completed[gidx] = (tid, name, is_err, raw, content_blocks, metadata)

                            if signal_post is None and (post.steering_messages or post.exit_loop):
                                signal_post = post
                                signal_tool_name = name

                        if signal_post is not None and remaining:
                            for t in remaining:
                                t.cancel()
                            remaining = {}

                    for gidx in sorted(completed):
                        tid, name, is_err, raw, content_blocks, metadata = completed[gidx]
                        state.messages.append(ConversationMessage(
                            role=MessageRole.TOOL,
                            content=[_tool_result_content_block(
                                tool_use_id=tid,
                                tool_name=name,
                                output=raw,
                                is_error=is_err,
                                content_blocks=content_blocks,
                                metadata=metadata,
                            )],
                        ))

                    if signal_post is not None:
                        cancelled_count = len(group) - len(completed)
                        subsequent_tools = sum(len(g) for g in groups[group_idx + 1:])
                        skipped = cancelled_count + subsequent_tools

                        if signal_post.steering_messages:
                            yield SteeringEvent(
                                tool_name=signal_tool_name,
                                message_count=len(signal_post.steering_messages),
                                skipped_tools=skipped,
                            )
                            for sm in signal_post.steering_messages:
                                state.messages.append(sm)
                            stop_iteration = True
                            break

                        if signal_post.exit_loop:
                            yield LoopExitEvent(
                                tool_name=signal_tool_name,
                                reason=signal_post.exit_reason,
                            )
                            exit_loop_requested = True
                            stop_iteration = True
                            break

            if exit_loop_requested:
                completed_without_pending_tools = True
                break

            if stop_iteration and not exit_loop_requested:
                pass

        if not completed_without_pending_tools and iterations >= self._max_iterations:
            yield ErrorEvent(message="max iterations exceeded", code="max_iterations_exceeded")

        yield TurnEndEvent(
            iterations_used=iterations,
            completed=completed_without_pending_tools,
        )

    async def run_turn(
        self,
        state: SessionState,
        user_text: str,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        user_msg = ConversationMessage(
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text=user_text)],
        )
        async for ev in self.run_turn_message(state, user_msg, abort=abort):
            yield ev

    async def run_turn_message(
        self,
        state: SessionState,
        message: ConversationMessage,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        if abort and getattr(abort, "is_set", lambda: False)():
            yield ErrorEvent(message="aborted before turn", code="aborted")
            return

        user_text = message.text_only()
        turn_start = await self._hooks.run_on_turn_start(user_text)
        if turn_start.messages:
            yield HookEvent(hook_name="on_turn_start", phase="OnTurnStart", messages=turn_start.messages)
        yield TurnStartEvent()

        state.messages.append(message)

        pre_turn_compaction = await self.compact(state, trigger="pre_turn")
        if pre_turn_compaction is not None:
            yield pre_turn_compaction

        async for ev in self._run_iteration_loop(state, abort=abort):
            yield ev

        post_turn_compaction = await self.compact(state, trigger="post_turn")
        if post_turn_compaction is not None:
            yield post_turn_compaction

        turn_end = await self._hooks.run_on_turn_end()
        if turn_end.messages:
            yield HookEvent(hook_name="on_turn_end", phase="OnTurnEnd", messages=turn_end.messages)

    async def continue_turn(
        self,
        state: SessionState,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        if not state.messages:
            yield ErrorEvent(message="no messages to continue from", code="invalid_state")
            return
        if state.messages[-1].role == MessageRole.ASSISTANT:
            yield ErrorEvent(
                message="cannot continue from assistant message",
                code="invalid_state",
            )
            return

        if abort and getattr(abort, "is_set", lambda: False)():
            yield ErrorEvent(message="aborted before turn", code="aborted")
            return

        yield TurnStartEvent()

        pre_turn_compaction = await self.compact(state, trigger="pre_turn")
        if pre_turn_compaction is not None:
            yield pre_turn_compaction

        async for ev in self._run_iteration_loop(state, abort=abort):
            yield ev

        post_turn_compaction = await self.compact(state, trigger="post_turn")
        if post_turn_compaction is not None:
            yield post_turn_compaction

        turn_end = await self._hooks.run_on_turn_end()
        if turn_end.messages:
            yield HookEvent(hook_name="on_turn_end", phase="OnTurnEnd", messages=turn_end.messages)


class StubToolModelClient(ModelClient):
    """Emits one tool_use then stops — for conformance tests."""

    def __init__(self, tool_name: str = "echo", tool_input: str = '{"x":1}') -> None:
        self._tool_name = tool_name
        self._tool_input = tool_input

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        tool_name = self._tool_name
        tool_input = self._tool_input

        async def _gen() -> AsyncIterator[AssistantEvent]:
            yield AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_use_id="t1",
                tool_name=tool_name,
                tool_input=tool_input,
            )
            yield AssistantEvent(
                kind=AssistantEventKind.MESSAGE_STOP,
                stop_reason=StopReason.TOOL_USE,
            )

        return _gen()
