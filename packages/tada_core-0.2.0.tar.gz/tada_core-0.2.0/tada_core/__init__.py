"""Public SDK surface for tada-core."""

from tada_core.contracts.budget import BudgetLimits
from tada_core.contracts.compaction import (
    CompactionConfig,
    CompactionMode,
    CompactionStrategy,
    ModelSummaryCompaction,
    NeverCompact,
    StructuredSummaryCompaction,
    ToolResultPruningConfig,
    TruncateCompaction,
)
from tada_core.contracts.events import Event
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import StopReason
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import SessionState
from tada_core.contracts.tokenization import CharacterTokenEstimator, TokenEstimator
from tada_core.contracts.tools import ChainedToolExecutor, ToolResult
from tada_core.loop import AgentLoop, AnthropicModelClient
from tada_core.loop.retry import RetryingModelClient, RetryPolicy
from tada_core.providers import build_model_client
from tada_core.utils.content_normalizer import ContentNormalizerConfig, normalize_messages

__version__ = "0.2.0"

__all__ = [
    "AgentLoop",
    "AnthropicModelClient",
    "BudgetLimits",
    "CharacterTokenEstimator",
    "ChainedToolExecutor",
    "CompactionConfig",
    "CompactionMode",
    "CompactionStrategy",
    "ContentNormalizerConfig",
    "ContentBlock",
    "ConversationMessage",
    "Event",
    "MessageRole",
    "ModelSpec",
    "ModelSummaryCompaction",
    "NeverCompact",
    "SessionState",
    "StopReason",
    "StructuredSummaryCompaction",
    "TokenEstimator",
    "ToolResult",
    "ToolResultPruningConfig",
    "TruncateCompaction",
    "RetryPolicy",
    "RetryingModelClient",
    "build_model_client",
    "normalize_messages",
    "__version__",
]
