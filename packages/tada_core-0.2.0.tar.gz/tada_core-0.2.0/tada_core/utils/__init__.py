"""Optional utility helpers for host integrations."""

