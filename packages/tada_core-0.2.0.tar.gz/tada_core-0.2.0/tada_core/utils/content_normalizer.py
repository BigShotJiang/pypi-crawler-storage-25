"""Multimodal content normalization helpers.

The core loop does not call these helpers automatically. Host applications can
opt in via ``AgentLoop.set_context_transform`` or a PRE_LLM_CALL hook when they
need local file/http image sources converted before provider serialization.
"""

from __future__ import annotations

import base64
import io
import mimetypes
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from tada_core.contracts.messages import ContentBlock, ConversationMessage


class ContentNormalizationError(Exception):
    """Raised when content normalization cannot complete safely."""


class ContentNormalizerConfig(BaseModel):
    max_image_dimension: int = 2000
    max_image_bytes: int = 5 * 1024 * 1024
    hard_pixel_limit: int = 8000
    fetch_http_urls: bool = True
    http_timeout_s: float = 10.0
    mime_aliases: dict[str, str] = Field(
        default_factory=lambda: {
            "image/jpg": "image/jpeg",
            "image/pjpeg": "image/jpeg",
            "image/x-png": "image/png",
        }
    )


def _canonical_mime(mime_type: str | None, config: ContentNormalizerConfig) -> str | None:
    if not mime_type:
        return mime_type
    return config.mime_aliases.get(mime_type, mime_type)


def _copy_block(block: ContentBlock, **updates: Any) -> ContentBlock:
    payload = block.model_dump()
    payload.update(updates)
    return ContentBlock.model_validate(payload)


def _ensure_heif_registered() -> None:
    try:
        import pillow_heif  # type: ignore[import-not-found]
    except Exception:
        return
    pillow_heif.register_heif_opener()


def _resize_image_if_possible(
    data_b64: str,
    mime_type: str,
    config: ContentNormalizerConfig,
) -> tuple[str, str]:
    try:
        from PIL import Image, ImageOps
    except Exception:
        return data_b64, mime_type

    if mime_type in {"image/heic", "image/heif"}:
        _ensure_heif_registered()

    try:
        raw = base64.b64decode(data_b64, validate=False)
        image = Image.open(io.BytesIO(raw))
        image.load()
        image = ImageOps.exif_transpose(image) or image
    except Exception:
        return data_b64, mime_type

    width, height = image.size
    if max(width, height) > config.hard_pixel_limit:
        raise ContentNormalizationError(
            f"image {width}x{height} exceeds {config.hard_pixel_limit}px per side"
        )

    target_mime = "image/jpeg" if mime_type in {"image/heic", "image/heif"} else mime_type
    if max(image.size) > config.max_image_dimension:
        image.thumbnail(
            (config.max_image_dimension, config.max_image_dimension),
            Image.Resampling.LANCZOS,
        )

    raw_size = len(base64.b64decode(data_b64, validate=False))
    if target_mime == mime_type and raw_size <= config.max_image_bytes:
        return data_b64, mime_type

    has_alpha = image.mode in {"RGBA", "LA"} or (
        image.mode == "P" and "transparency" in image.info
    )
    use_png = has_alpha and target_mime == "image/png"
    if use_png:
        if image.mode not in {"RGBA", "LA"}:
            image = image.convert("RGBA")
        output = io.BytesIO()
        image.save(output, format="PNG", optimize=True)
        if output.tell() <= config.max_image_bytes:
            return base64.b64encode(output.getvalue()).decode(), "image/png"

    if image.mode not in {"RGB", "L"}:
        image = image.convert("RGB")
    for quality in (85, 60, 40, 20):
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=quality, optimize=True, progressive=True)
        if output.tell() <= config.max_image_bytes:
            return base64.b64encode(output.getvalue()).decode(), "image/jpeg"

    raise ContentNormalizationError("image could not be compressed below configured byte limit")


def _read_path_image(block: ContentBlock, config: ContentNormalizerConfig) -> ContentBlock:
    raw_path = block.data or block.url
    if not raw_path:
        raise ContentNormalizationError("path image block requires data or url path")
    path = Path(raw_path.removeprefix("file://"))
    if not path.is_file():
        raise ContentNormalizationError(f"image path does not exist: {path}")
    mime_type = _canonical_mime(block.mime_type or mimetypes.guess_type(path.name)[0], config)
    mime_type = mime_type or "image/jpeg"
    data = base64.b64encode(path.read_bytes()).decode()
    data, mime_type = _resize_image_if_possible(data, mime_type, config)
    return _copy_block(
        block,
        source="base64",
        mime_type=mime_type,
        data=data,
        url=None,
    )


async def _read_http_image(block: ContentBlock, config: ContentNormalizerConfig) -> ContentBlock:
    if not config.fetch_http_urls or not block.url:
        return block
    try:
        import httpx
    except Exception as exc:
        raise ContentNormalizationError("httpx is required for URL image normalization") from exc

    async with httpx.AsyncClient(
        timeout=config.http_timeout_s,
        follow_redirects=True,
    ) as client:
        response = await client.get(block.url)
        response.raise_for_status()
    mime_type = response.headers.get("content-type", "").split(";")[0].strip()
    mime_type = _canonical_mime(mime_type or block.mime_type, config) or "image/jpeg"
    data = base64.b64encode(response.content).decode()
    data, mime_type = _resize_image_if_possible(data, mime_type, config)
    return _copy_block(block, source="base64", mime_type=mime_type, data=data, url=None)


async def _normalize_block(
    block: ContentBlock,
    config: ContentNormalizerConfig,
) -> ContentBlock:
    if block.type not in {"image", "file"}:
        return block
    mime_type = _canonical_mime(block.mime_type, config)
    block = _copy_block(block, mime_type=mime_type)
    if block.type != "image":
        return block
    if block.source == "path":
        return _read_path_image(block, config)
    if block.source == "url" and block.url and block.url.startswith(("http://", "https://")):
        return await _read_http_image(block, config)
    if block.source == "base64" and block.data and block.mime_type:
        data, new_mime = _resize_image_if_possible(block.data, block.mime_type, config)
        return _copy_block(block, data=data, mime_type=new_mime)
    return block


async def normalize_messages(
    messages: list[ConversationMessage],
    config: ContentNormalizerConfig | None = None,
) -> list[ConversationMessage]:
    """Return a normalized deep copy of conversation messages."""

    cfg = config or ContentNormalizerConfig()
    normalized: list[ConversationMessage] = []
    for message in messages:
        content = [await _normalize_block(block, cfg) for block in message.content]
        normalized.append(message.model_copy(update={"content": content}, deep=True))
    return normalized
