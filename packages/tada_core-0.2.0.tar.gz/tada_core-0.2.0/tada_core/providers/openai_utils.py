"""Shared helpers for OpenAI-style protocol adapters."""

from __future__ import annotations

from collections.abc import Iterable
import json
from typing import Any

from tada_core.contracts.model import AssistantEvent, AssistantEventKind, StopReason
from tada_core.contracts.session import TokenUsage
from tada_core.contracts.tokenization import CharacterTokenEstimator


def usage_from_payload(payload: dict[str, Any]) -> TokenUsage | None:
    usage = payload.get("usage")
    if not isinstance(usage, dict):
        return None
    prompt_details = usage.get("prompt_tokens_details")
    if not isinstance(prompt_details, dict):
        prompt_details = {}
    return TokenUsage(
        input_tokens=int(usage.get("input_tokens") or usage.get("prompt_tokens") or 0),
        output_tokens=int(usage.get("output_tokens") or usage.get("completion_tokens") or 0),
        cache_read_tokens=int(
            usage.get("cache_read_tokens")
            or usage.get("cache_read_input_tokens")
            or prompt_details.get("cached_tokens")
            or 0
        ),
        cache_creation_tokens=int(
            usage.get("cache_creation_tokens")
            or usage.get("cache_creation_input_tokens")
            or usage.get("cache_write_tokens")
            or 0
        ),
    )


def estimate_openai_payload_tokens(
    request_text: str,
    *,
    model_id: str | None = None,
) -> int:
    try:
        import tiktoken  # type: ignore[import-not-found]

        try:
            encoding = tiktoken.encoding_for_model(model_id or "")
        except Exception:
            encoding = tiktoken.get_encoding("cl100k_base")
        return max(1, len(encoding.encode(request_text)))
    except Exception:
        return CharacterTokenEstimator()._chars_to_tokens(request_text)


def estimate_openai_request_tokens(
    request: Any,
    *,
    serialized_messages: Any,
    serialized_tools: Any = None,
    model_id: str | None = None,
) -> int:
    payload = {
        "system_prompt": getattr(request, "system_prompt", []),
        "messages": serialized_messages,
        "tools": serialized_tools or [],
    }
    return estimate_openai_payload_tokens(
        json.dumps(payload, sort_keys=True, ensure_ascii=False),
        model_id=model_id,
    )


def stop_reason_from_finish(finish_reason: str | None) -> StopReason:
    if finish_reason == "length":
        return StopReason.LENGTH
    if finish_reason == "tool_calls":
        return StopReason.TOOL_USE
    if finish_reason in {"stop", "end_turn"}:
        return StopReason.STOP
    return StopReason.STOP


def parse_openai_completions_batch(payload: dict[str, Any]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    choices = payload.get("choices") or []
    if not isinstance(choices, list) or not choices:
        return [
            AssistantEvent(
                kind=AssistantEventKind.MESSAGE_STOP,
                stop_reason=StopReason.STOP,
            )
        ]

    choice0 = choices[0] if isinstance(choices[0], dict) else {}
    message = choice0.get("message") or {}
    if not isinstance(message, dict):
        message = {}

    content = message.get("content")
    reasoning_content = message.get("reasoning_content")
    if isinstance(reasoning_content, str) and reasoning_content:
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=reasoning_content))
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_END, thinking_delta=reasoning_content))

    if isinstance(content, str) and content:
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=content))
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=content))

    tool_calls = message.get("tool_calls") or []
    if isinstance(tool_calls, list):
        for call in tool_calls:
            if not isinstance(call, dict):
                continue
            function = call.get("function") or {}
            if not isinstance(function, dict):
                function = {}
            events.append(
                AssistantEvent(
                    kind=AssistantEventKind.TOOL_USE,
                    tool_use_id=str(call.get("id") or ""),
                    tool_name=str(function.get("name") or ""),
                    tool_input=str(function.get("arguments") or "{}"),
                )
            )

    usage = usage_from_payload(payload)
    if usage is not None:
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=usage,
                model_id=payload.get("model"),
                request_id=payload.get("id"),
            )
        )
    finish = choice0.get("finish_reason")
    events.append(
        AssistantEvent(
            kind=AssistantEventKind.MESSAGE_STOP,
            stop_reason=stop_reason_from_finish(str(finish) if finish else None),
        )
    )
    return events


def parse_openai_completions_stream(chunks: Iterable[dict[str, Any]]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    tool_acc: dict[int, dict[str, Any]] = {}
    usage: TokenUsage | None = None
    model_id: str | None = None
    request_id: str | None = None
    finish_reason: StopReason | None = None
    text_started = False
    thinking_started = False

    for chunk in chunks:
        if not isinstance(chunk, dict):
            continue
        model_id = chunk.get("model") or model_id
        request_id = chunk.get("id") or request_id
        usage = usage_from_payload(chunk) or usage
        choices = chunk.get("choices") or []
        if not isinstance(choices, list):
            continue
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            if choice.get("finish_reason"):
                finish_reason = stop_reason_from_finish(str(choice.get("finish_reason")))
            delta = choice.get("delta") or {}
            if not isinstance(delta, dict):
                continue
            reasoning_content = delta.get("reasoning_content")
            if isinstance(reasoning_content, str) and reasoning_content:
                if not thinking_started:
                    thinking_started = True
                    events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
                events.append(
                    AssistantEvent(
                        kind=AssistantEventKind.THINKING_DELTA,
                        thinking_delta=reasoning_content,
                    )
                )
            content = delta.get("content")
            if isinstance(content, str) and content:
                if not text_started:
                    text_started = True
                    events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
                events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=content))
            tool_calls = delta.get("tool_calls") or []
            if isinstance(tool_calls, list):
                for raw_call in tool_calls:
                    if not isinstance(raw_call, dict):
                        continue
                    index = int(raw_call.get("index") or 0)
                    current = tool_acc.setdefault(
                        index,
                        {"id": "", "name": "", "arguments": ""},
                    )
                    if raw_call.get("id"):
                        current["id"] = str(raw_call["id"])
                    function = raw_call.get("function") or {}
                    if isinstance(function, dict):
                        if function.get("name"):
                            current["name"] = str(function["name"])
                        if function.get("arguments"):
                            partial = str(function["arguments"])
                            current["arguments"] += partial
                            current.setdefault("deltas", [])
                            current["deltas"].append(partial)

    if thinking_started:
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_END))
    if text_started:
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END))
    for idx in sorted(tool_acc.keys()):
        call = tool_acc[idx]
        for partial in call.get("deltas", []):
            if partial:
                events.append(
                    AssistantEvent(
                        kind=AssistantEventKind.TOOL_INPUT_DELTA,
                        tool_use_id=call["id"] or f"tool-{idx}",
                        tool_name=call["name"],
                        tool_input_delta=partial,
                    )
                )
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_use_id=call["id"] or f"tool-{idx}",
                tool_name=call["name"],
                tool_input=call["arguments"] or "{}",
            )
        )
    if usage is not None:
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=usage,
                model_id=model_id,
                request_id=request_id,
            )
        )
    events.append(
        AssistantEvent(
            kind=AssistantEventKind.MESSAGE_STOP,
            stop_reason=finish_reason or (StopReason.TOOL_USE if tool_acc else StopReason.STOP),
        )
    )
    return events
