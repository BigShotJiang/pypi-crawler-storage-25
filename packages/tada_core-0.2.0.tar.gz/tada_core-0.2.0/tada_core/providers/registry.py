"""Adapter registry: map protocol api name -> ModelClient factory."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from tada_core.contracts.model import ModelClient
from tada_core.contracts.models import ModelSpec

ModelClientFactory = Callable[..., ModelClient]

_adapter_registry: dict[str, ModelClientFactory] = {}


def register_model_adapter(api: str, factory: ModelClientFactory) -> None:
    """Register a factory that builds a ModelClient for the given api name."""
    _adapter_registry[api] = factory


def get_model_adapter(api: str) -> ModelClientFactory | None:
    return _adapter_registry.get(api)


def build_model_client(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    **kwargs: Any,
) -> ModelClient:
    """Build a ModelClient from a ModelSpec using the registered adapter."""
    factory = get_model_adapter(spec.api)
    if factory is None:
        raise ValueError(f"No model adapter registered for api: {spec.api!r}")
    return factory(spec, api_key=api_key, streaming=streaming, **kwargs)


def _register_builtins() -> None:
    from tada_core.providers.anthropic import anthropic_client_factory
    from tada_core.providers.bedrock import bedrock_client_factory
    from tada_core.providers.google import google_client_factory
    from tada_core.providers.openai_completions import openai_completions_client_factory
    from tada_core.providers.openai_responses import openai_responses_client_factory

    register_model_adapter("anthropic-messages", anthropic_client_factory)
    register_model_adapter("openai-completions", openai_completions_client_factory)
    register_model_adapter("openai-responses", openai_responses_client_factory)
    register_model_adapter("google-generative-ai", google_client_factory)
    register_model_adapter("bedrock-converse-stream", bedrock_client_factory)


_register_builtins()
