"""Anthropic Messages API protocol adapter."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterable
from typing import Any, Literal

from tada_core.contracts.messages import ContentBlock
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient, StopReason
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import TokenUsage
from tada_core.contracts.tokenization import CharacterTokenEstimator

CacheRetention = Literal["none", "short", "long"]

_ANTHROPIC_GENERATE_KWARGS = {
    "container",
    "context_management",
    "metadata",
    "service_tier",
    "stop_sequences",
    "temperature",
    "thinking",
    "top_k",
    "top_p",
}


def _allowed_generate_kwargs(
    request: ApiRequest,
    allowed: set[str],
) -> dict[str, Any]:
    return {key: value for key, value in request.generate_kwargs.items() if key in allowed}


def _cache_control_for_retention(
    cache_retention: CacheRetention,
    base_url: str,
    *,
    force_long: bool = False,
) -> dict[str, str] | None:
    if cache_retention == "none":
        return None
    allow_long = "api.anthropic.com" in base_url or force_long
    ttl = "1h" if cache_retention == "long" and allow_long else None
    return {"type": "ephemeral", **({"ttl": ttl} if ttl else {})}


def _attach_cache_control(block: dict[str, Any], cache_control: dict[str, str]) -> None:
    if "cache_control" not in block:
        block["cache_control"] = dict(cache_control)


def _last_content_block(message: dict[str, Any]) -> dict[str, Any] | None:
    content = message.get("content")
    if isinstance(content, list) and content and isinstance(content[-1], dict):
        return content[-1]
    if isinstance(content, str) and content:
        message["content"] = [{"type": "text", "text": content}]
        return message["content"][-1]
    return None


def apply_anthropic_cache_control(
    payload: dict[str, Any],
    *,
    cache_retention: CacheRetention,
    base_url: str,
    force_long: bool = False,
) -> None:
    cache_control = _cache_control_for_retention(
        cache_retention,
        base_url,
        force_long=force_long,
    )
    if cache_control is None:
        return

    system = payload.get("system")
    if isinstance(system, str) and system:
        payload["system"] = [
            {
                "type": "text",
                "text": system,
                "cache_control": dict(cache_control),
            }
        ]
    elif isinstance(system, list) and system:
        last = system[-1]
        if isinstance(last, dict):
            _attach_cache_control(last, cache_control)

    tools = payload.get("tools")
    if isinstance(tools, list) and tools and isinstance(tools[-1], dict):
        _attach_cache_control(tools[-1], cache_control)

    user_messages = [
        message
        for message in payload.get("messages", [])
        if isinstance(message, dict) and message.get("role") == "user"
    ]
    for message in user_messages[-2:]:
        block = _last_content_block(message)
        if block is not None:
            _attach_cache_control(block, cache_control)


def serialize_anthropic_content_block(block: ContentBlock) -> dict[str, Any] | None:
    if block.type == "text" and block.text:
        return {"type": "text", "text": block.text}
    if block.type == "thinking" and block.thinking:
        result: dict[str, Any] = {"type": "thinking", "thinking": block.thinking}
        if block.signature:
            result["signature"] = block.signature
        return result
    if block.type == "tool_use":
        try:
            parsed_input = json.loads(block.tool_input or "{}")
        except ValueError:
            parsed_input = {}
        return {
            "type": "tool_use",
            "id": block.tool_use_id or "",
            "name": block.tool_name or "",
            "input": parsed_input,
        }
    if block.type == "image":
        if block.source == "base64":
            return {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": block.mime_type,
                    "data": block.data,
                },
            }
        if block.source == "url":
            return {"type": "image", "source": {"type": "url", "url": block.url}}
        raise ValueError("Anthropic image blocks do not support source='path'")
    if block.type == "file":
        if block.mime_type != "application/pdf":
            raise ValueError(f"Unsupported file mime_type for Anthropic: {block.mime_type}")
        if block.source == "base64":
            doc: dict[str, Any] = {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": block.mime_type,
                    "data": block.data,
                },
            }
        elif block.source == "url":
            doc = {"type": "document", "source": {"type": "url", "url": block.url}}
        else:
            raise ValueError("Anthropic file blocks do not support source='path'")
        if block.name:
            doc["title"] = block.name
        return doc
    return None


def serialize_anthropic_messages(request: ApiRequest) -> tuple[str, list[dict[str, Any]]]:
    system_text = "\n\n".join(request.system_prompt)
    messages: list[dict[str, Any]] = []

    for msg in request.messages:
        role = msg.role.value

        if role == "tool":
            tool_blocks: list[dict[str, Any]] = []
            for b in msg.content:
                if b.type != "tool_result":
                    continue
                nested = b.tool_result_blocks()
                if nested:
                    content_parts: list[Any] = []
                    for nb in nested:
                        if nb.type == "text" and nb.text:
                            # Anthropic Messages API requires tool_result.content
                            # to be either a string or a list of typed blocks
                            # ({"type": "text", ...} | {"type": "image", ...}).
                            # Bare strings inside the list are rejected by both
                            # official Anthropic and stricter proxies (e.g.
                            # token-router) with HTTP 400.
                            content_parts.append({"type": "text", "text": nb.text})
                        elif nb.type == "image" and nb.source == "base64":
                            content_parts.append(
                                {
                                    "type": "image",
                                    "source": {
                                        "type": "base64",
                                        "media_type": nb.mime_type,
                                        "data": nb.data,
                                    },
                                }
                            )
                    block: dict[str, Any] = {
                        "type": "tool_result",
                        "tool_use_id": b.tool_use_id or "",
                        "content": content_parts or (b.tool_result or ""),
                    }
                else:
                    block = {
                        "type": "tool_result",
                        "tool_use_id": b.tool_use_id or "",
                        "content": b.tool_result or "",
                    }
                if b.is_error:
                    block["is_error"] = True
                tool_blocks.append(block)
            if tool_blocks:
                if messages and messages[-1]["role"] == "user":
                    prev = messages[-1]["content"]
                    if isinstance(prev, list):
                        prev.extend(tool_blocks)
                    else:
                        messages[-1]["content"] = [{"type": "text", "text": prev}, *tool_blocks]
                else:
                    messages.append({"role": "user", "content": tool_blocks})
            continue

        content_blocks: list[dict[str, Any]] = []
        for b in msg.content:
            serialized = serialize_anthropic_content_block(b)
            if serialized is not None:
                content_blocks.append(serialized)

        if content_blocks:
            messages.append({"role": role, "content": content_blocks})

    return system_text, messages


def serialize_anthropic_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for t in tools:
        fn = t.get("function", {})
        result.append({
            "name": fn.get("name", ""),
            "description": fn.get("description", ""),
            "input_schema": fn.get("parameters", {"type": "object"}),
        })
    return result


def build_anthropic_payload(
    request: ApiRequest,
    *,
    model_id: str,
    max_tokens: int,
    streaming: bool,
) -> dict[str, Any]:
    system_text, messages = serialize_anthropic_messages(request)
    payload: dict[str, Any] = {
        "model": model_id,
        "max_tokens": request.max_tokens or max_tokens,
        "messages": messages,
        "stream": streaming,
        **_allowed_generate_kwargs(request, _ANTHROPIC_GENERATE_KWARGS),
    }
    if system_text:
        payload["system"] = system_text
    if request.tools:
        payload["tools"] = serialize_anthropic_tools(request.tools)
    return payload


def _stop_reason_from_anthropic(payload: dict[str, Any]) -> StopReason:
    reason = payload.get("stop_reason") or payload.get("stopReason")
    if reason == "max_tokens":
        return StopReason.LENGTH
    if reason == "tool_use":
        return StopReason.TOOL_USE
    return StopReason.STOP


def parse_anthropic_response(payload: dict[str, Any]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    for block in payload.get("content") or []:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text":
            text = block.get("text") or ""
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text))
        elif block.get("type") == "thinking":
            thinking = block.get("thinking") or ""
            signature = block.get("signature") or None
            events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
            events.append(AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=thinking))
            # Carry the signature on THINKING_END so AgentLoop can attach it
            # to ContentBlock.signature; Claude requires this on any later
            # turn that includes this thinking block.
            events.append(AssistantEvent(
                kind=AssistantEventKind.THINKING_END,
                thinking_delta=thinking,
                thinking_signature=signature,
            ))
        elif block.get("type") == "tool_use":
            raw_input = block.get("input") or {}
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_use_id=block.get("id") or "",
                tool_name=block.get("name") or "",
                tool_input=json.dumps(raw_input),
            ))
    usage_data = payload.get("usage") or {}
    if usage_data:
        events.append(AssistantEvent(
            kind=AssistantEventKind.USAGE,
            usage=TokenUsage(
                input_tokens=int(usage_data.get("input_tokens") or 0),
                output_tokens=int(usage_data.get("output_tokens") or 0),
                cache_read_tokens=int(usage_data.get("cache_read_input_tokens") or 0),
                cache_creation_tokens=int(usage_data.get("cache_creation_input_tokens") or 0),
            ),
            model_id=payload.get("model"),
            request_id=payload.get("id"),
        ))
    events.append(AssistantEvent(
        kind=AssistantEventKind.MESSAGE_STOP,
        stop_reason=_stop_reason_from_anthropic(payload),
    ))
    return events


def parse_anthropic_stream(chunks: Iterable[dict[str, Any]]) -> list[AssistantEvent]:
    text_parts: list[str] = []
    thinking_parts: list[str] = []
    thinking_signature_parts: list[str] = []
    tool_acc: dict[int, dict[str, Any]] = {}
    current_block_index: int = -1
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    model_id: str | None = None
    request_id: str | None = None
    stop_reason = StopReason.STOP

    for chunk in chunks:
        if not isinstance(chunk, dict):
            continue
        etype = chunk.get("type")

        if etype == "message_start":
            message = chunk.get("message") or {}
            usage = message.get("usage") or {}
            input_tokens = int(usage.get("input_tokens") or 0)
            cache_read_tokens = int(usage.get("cache_read_input_tokens") or 0)
            cache_creation_tokens = int(usage.get("cache_creation_input_tokens") or 0)
            model_id = message.get("model")
            request_id = message.get("id")

        elif etype == "content_block_start":
            current_block_index = int(chunk.get("index") or 0)
            block = chunk.get("content_block") or {}
            block.get("type")
            if block.get("type") == "tool_use":
                tool_acc[current_block_index] = {
                    "id": block.get("id") or "",
                    "name": block.get("name") or "",
                    "input_parts": [],
                }

        elif etype == "content_block_delta":
            delta = chunk.get("delta") or {}
            dtype = delta.get("type")
            if dtype == "text_delta":
                text_parts.append(delta.get("text") or "")
            elif dtype == "thinking_delta":
                thinking_parts.append(delta.get("thinking") or "")
            elif dtype == "signature_delta":
                # Anthropic extended-thinking emits the per-block signature as
                # a separate delta inside the same thinking content block;
                # without capturing it we'd send the thinking block back to
                # the API with no signature and get HTTP 400.
                sig = delta.get("signature") or ""
                if sig:
                    thinking_signature_parts.append(sig)
            elif dtype == "input_json_delta":
                if current_block_index in tool_acc:
                    partial = delta.get("partial_json") or ""
                    tool_acc[current_block_index]["input_parts"].append(partial)

        elif etype == "message_delta":
            usage = chunk.get("usage") or {}
            output_tokens = int(usage.get("output_tokens") or 0)
            delta = chunk.get("delta") or {}
            if delta.get("stop_reason") == "max_tokens":
                stop_reason = StopReason.LENGTH
            elif delta.get("stop_reason") == "tool_use":
                stop_reason = StopReason.TOOL_USE

    events: list[AssistantEvent] = []
    if thinking_parts:
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
        full_thinking = "".join(thinking_parts)
        full_signature = "".join(thinking_signature_parts) or None
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=full_thinking))
        events.append(AssistantEvent(
            kind=AssistantEventKind.THINKING_END,
            thinking_delta=full_thinking,
            thinking_signature=full_signature,
        ))
    if text_parts:
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
        full_text = "".join(text_parts)
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=full_text))
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=full_text))
    for tool in tool_acc.values():
        raw = "".join(tool["input_parts"])
        for partial in tool["input_parts"]:
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_INPUT_DELTA,
                tool_use_id=tool["id"],
                tool_name=tool["name"],
                tool_input_delta=partial,
            ))
        try:
            json.loads(raw)
        except ValueError:
            raw = "{}"
        events.append(AssistantEvent(
            kind=AssistantEventKind.TOOL_USE,
            tool_use_id=tool["id"],
            tool_name=tool["name"],
            tool_input=raw or "{}",
        ))
    if input_tokens or output_tokens:
        events.append(AssistantEvent(
            kind=AssistantEventKind.USAGE,
            usage=TokenUsage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=cache_read_tokens,
                cache_creation_tokens=cache_creation_tokens,
            ),
            model_id=model_id,
            request_id=request_id,
        ))
    if tool_acc and stop_reason == StopReason.STOP:
        stop_reason = StopReason.TOOL_USE
    events.append(AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason))
    return events


class AnthropicModelClient(ModelClient):
    DEFAULT_BASE_URL = "https://api.anthropic.com"
    ANTHROPIC_VERSION = "2023-06-01"

    def __init__(
        self,
        api_key: str,
        model: str,
        *,
        base_url: str = "",
        streaming: bool = True,
        max_tokens: int = 8192,
        extra_headers: dict[str, str] | None = None,
        cache_retention: CacheRetention = "short",
        model_spec: ModelSpec | None = None,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self._streaming = streaming
        self._max_tokens = max_tokens
        self._extra_headers = extra_headers or {}
        self._cache_retention: CacheRetention = cache_retention
        self._model_spec = model_spec

    @property
    def model_spec(self) -> ModelSpec | None:
        return self._model_spec

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        import httpx

        payload = build_anthropic_payload(
            request,
            model_id=self._model,
            max_tokens=self._max_tokens,
            streaming=self._streaming,
        )
        apply_anthropic_cache_control(
            payload,
            cache_retention=self._cache_retention,
            base_url=self._base_url,
            force_long=(
                self._model_spec is not None
                and self._model_spec.compat.get("cache_retention_force") == "long"
            ),
        )

        headers = {
            "x-api-key": self._api_key,
            "anthropic-version": self.ANTHROPIC_VERSION,
            "content-type": "application/json",
            **self._extra_headers,
        }
        streaming = self._streaming
        base_url = self._base_url

        async def _gen() -> AsyncIterator[AssistantEvent]:
            if streaming:
                # Incremental SSE parsing: emit AssistantEvents as soon as each
                # ``content_block_delta`` arrives, instead of buffering the
                # whole stream and replaying it after the upstream connection
                # closes. The earlier "collect all chunks then parse" path
                # broke perceived streaming (the client saw the full text in
                # one shot at the very end of the turn) and made
                # extended-thinking impossible to use interactively.
                block_types: dict[int, str] = {}
                tool_acc: dict[int, dict[str, Any]] = {}
                thinking_sig: dict[int, list[str]] = {}
                text_started: set[int] = set()
                thinking_started: set[int] = set()

                in_tokens = out_tokens = cache_read = cache_create = 0
                seen_any_usage = False
                model_id_acc: str | None = None
                request_id_acc: str | None = None
                stop_reason: StopReason | None = None
                seen_any_tool = False

                async with httpx.AsyncClient() as client:
                    async with client.stream(
                        "POST",
                        f"{base_url}/v1/messages",
                        json=payload,
                        headers=headers,
                        timeout=120,
                    ) as resp:
                        resp.raise_for_status()
                        async for line in resp.aiter_lines():
                            if not line.startswith("data: "):
                                continue
                            body = line[6:].strip()
                            if not body or body == "[DONE]":
                                continue
                            try:
                                chunk = json.loads(body)
                            except ValueError:
                                continue
                            if not isinstance(chunk, dict):
                                continue

                            etype = chunk.get("type")

                            if etype == "message_start":
                                message = chunk.get("message") or {}
                                usage = message.get("usage") or {}
                                in_tokens = int(usage.get("input_tokens") or 0)
                                cache_read = int(usage.get("cache_read_input_tokens") or 0)
                                cache_create = int(usage.get("cache_creation_input_tokens") or 0)
                                model_id_acc = message.get("model")
                                request_id_acc = message.get("id")
                                if in_tokens or cache_read or cache_create:
                                    seen_any_usage = True

                            elif etype == "content_block_start":
                                idx = int(chunk.get("index") or 0)
                                block = chunk.get("content_block") or {}
                                btype = block.get("type") or ""
                                block_types[idx] = btype
                                if btype == "tool_use":
                                    tool_acc[idx] = {
                                        "id": block.get("id") or "",
                                        "name": block.get("name") or "",
                                        "input_parts": [],
                                    }
                                    seen_any_tool = True

                            elif etype == "content_block_delta":
                                idx = int(chunk.get("index") or 0)
                                delta = chunk.get("delta") or {}
                                dtype = delta.get("type")
                                if dtype == "text_delta":
                                    text = delta.get("text") or ""
                                    if text:
                                        if idx not in text_started:
                                            text_started.add(idx)
                                            yield AssistantEvent(
                                                kind=AssistantEventKind.TEXT_START,
                                            )
                                        yield AssistantEvent(
                                            kind=AssistantEventKind.TEXT_DELTA,
                                            text_delta=text,
                                        )
                                elif dtype == "thinking_delta":
                                    text = delta.get("thinking") or ""
                                    if text:
                                        if idx not in thinking_started:
                                            thinking_started.add(idx)
                                            yield AssistantEvent(
                                                kind=AssistantEventKind.THINKING_START,
                                            )
                                        yield AssistantEvent(
                                            kind=AssistantEventKind.THINKING_DELTA,
                                            thinking_delta=text,
                                        )
                                elif dtype == "signature_delta":
                                    sig = delta.get("signature") or ""
                                    if sig:
                                        thinking_sig.setdefault(idx, []).append(sig)
                                elif dtype == "input_json_delta":
                                    if idx in tool_acc:
                                        partial = delta.get("partial_json") or ""
                                        tool_acc[idx]["input_parts"].append(partial)
                                        if partial:
                                            yield AssistantEvent(
                                                kind=AssistantEventKind.TOOL_INPUT_DELTA,
                                                tool_use_id=tool_acc[idx]["id"],
                                                tool_name=tool_acc[idx]["name"],
                                                tool_input_delta=partial,
                                            )

                            elif etype == "content_block_stop":
                                idx = int(chunk.get("index") or 0)
                                btype = block_types.get(idx, "")
                                if btype == "text" and idx in text_started:
                                    yield AssistantEvent(kind=AssistantEventKind.TEXT_END)
                                elif btype == "thinking" and idx in thinking_started:
                                    sig_parts = thinking_sig.get(idx) or []
                                    yield AssistantEvent(
                                        kind=AssistantEventKind.THINKING_END,
                                        thinking_signature=("".join(sig_parts) or None),
                                    )
                                elif btype == "tool_use" and idx in tool_acc:
                                    tool = tool_acc[idx]
                                    raw = "".join(tool["input_parts"]) or "{}"
                                    try:
                                        json.loads(raw)
                                    except ValueError:
                                        raw = "{}"
                                    yield AssistantEvent(
                                        kind=AssistantEventKind.TOOL_USE,
                                        tool_use_id=tool["id"],
                                        tool_name=tool["name"],
                                        tool_input=raw,
                                    )

                            elif etype == "message_delta":
                                usage = chunk.get("usage") or {}
                                if "output_tokens" in usage:
                                    out_tokens = int(usage.get("output_tokens") or 0)
                                    seen_any_usage = True
                                delta = chunk.get("delta") or {}
                                sr = delta.get("stop_reason")
                                if sr == "max_tokens":
                                    stop_reason = StopReason.LENGTH
                                elif sr == "tool_use":
                                    stop_reason = StopReason.TOOL_USE
                                elif sr == "end_turn":
                                    stop_reason = StopReason.STOP

                            elif etype == "message_stop":
                                # Final marker; usage/stop_reason already
                                # captured above. Nothing more to do here.
                                pass

                if seen_any_usage:
                    yield AssistantEvent(
                        kind=AssistantEventKind.USAGE,
                        usage=TokenUsage(
                            input_tokens=in_tokens,
                            output_tokens=out_tokens,
                            cache_read_tokens=cache_read,
                            cache_creation_tokens=cache_create,
                        ),
                        model_id=model_id_acc,
                        request_id=request_id_acc,
                    )
                if stop_reason is None:
                    stop_reason = (
                        StopReason.TOOL_USE if seen_any_tool else StopReason.STOP
                    )
                yield AssistantEvent(
                    kind=AssistantEventKind.MESSAGE_STOP,
                    stop_reason=stop_reason,
                )
            else:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(
                        f"{base_url}/v1/messages",
                        json=payload,
                        headers=headers,
                        timeout=120,
                    )
                    resp.raise_for_status()
                    for ev in parse_anthropic_response(resp.json()):
                        yield ev

        return _gen()

    def estimate_tokens(self, request: ApiRequest) -> int | None:
        fallback = CharacterTokenEstimator().estimate_request(request)
        if not self._api_key:
            return fallback
        payload = build_anthropic_payload(
            request,
            model_id=self._model,
            max_tokens=self._max_tokens,
            streaming=False,
        )
        payload.pop("stream", None)
        try:
            import httpx

            with httpx.Client(timeout=30) as client:
                response = client.post(
                    f"{self._base_url}/v1/messages/count_tokens",
                    json=payload,
                    headers={
                        "x-api-key": self._api_key,
                        "anthropic-version": self.ANTHROPIC_VERSION,
                        "content-type": "application/json",
                        **self._extra_headers,
                    },
                )
                response.raise_for_status()
            count = response.json().get("input_tokens")
            return int(count) if count is not None else fallback
        except Exception:
            return fallback


def anthropic_client_factory(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    max_tokens: int | None = None,
    extra_headers: dict[str, str] | None = None,
    cache_retention: CacheRetention = "short",
    **_: Any,
) -> AnthropicModelClient:
    headers = dict(spec.headers)
    if extra_headers:
        headers.update(extra_headers)
    return AnthropicModelClient(
        api_key=api_key,
        model=spec.id,
        base_url=spec.base_url,
        streaming=streaming,
        max_tokens=max_tokens or spec.max_tokens or 8192,
        extra_headers=headers,
        cache_retention=cache_retention,
        model_spec=spec,
    )
