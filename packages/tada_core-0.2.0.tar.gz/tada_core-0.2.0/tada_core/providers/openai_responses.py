"""OpenAI Responses API protocol adapter."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable, Iterable
from typing import Any

import httpx

from tada_core.contracts.messages import MessageRole
from tada_core.contracts.model import (
    ApiRequest,
    AssistantEvent,
    AssistantEventKind,
    ModelClient,
    StopReason,
)
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import TokenUsage
from tada_core.providers.openai_utils import estimate_openai_request_tokens, usage_from_payload

TransportFn = Callable[[ApiRequest, bool], dict[str, Any] | Iterable[dict[str, Any]]]

_OPENAI_RESPONSES_GENERATE_KWARGS = {
    "extra_body",
    "include",
    "max_output_tokens",
    "metadata",
    "parallel_tool_calls",
    "previous_response_id",
    "reasoning",
    "response_format",
    "service_tier",
    "store",
    "temperature",
    "text",
    "tool_choice",
    "top_p",
    "truncation",
    "user",
}


def _allowed_generate_kwargs(request: ApiRequest, allowed: set[str]) -> dict[str, Any]:
    return {key: value for key, value in request.generate_kwargs.items() if key in allowed}


def serialize_openai_responses_input(request: ApiRequest) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for m in request.messages:
        if m.role == MessageRole.TOOL:
            for b in m.content:
                if b.type == "tool_result":
                    items.append({
                        "type": "function_call_output",
                        "call_id": b.tool_use_id or "",
                        "output": b.tool_result or "",
                    })
            continue
        if m.role == MessageRole.USER:
            content_parts: list[dict[str, Any]] = []
            for b in m.content:
                if b.type == "text" and b.text:
                    content_parts.append({"type": "input_text", "text": b.text})
                elif b.type == "image" and b.source == "base64":
                    content_parts.append({
                        "type": "input_image",
                        "image_url": f"data:{b.mime_type};base64,{b.data}",
                    })
            if content_parts:
                items.append({"role": "user", "content": content_parts})
            continue
        if m.role == MessageRole.ASSISTANT:
            for b in m.content:
                if b.type == "text" and b.text:
                    items.append({"role": "assistant", "content": b.text})
                elif b.type == "tool_use":
                    items.append({
                        "type": "function_call",
                        "call_id": b.tool_use_id or "",
                        "name": b.tool_name or "",
                        "arguments": b.tool_input or "{}",
                    })
    return items


def serialize_openai_responses_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for t in tools:
        fn = t.get("function", {})
        result.append({
            "type": "function",
            "name": fn.get("name", ""),
            "description": fn.get("description", ""),
            "parameters": fn.get("parameters", {"type": "object"}),
        })
    return result


def build_openai_responses_payload(
    request: ApiRequest,
    *,
    model_id: str,
    stream: bool,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model_id,
        "input": serialize_openai_responses_input(request),
        "stream": stream,
        **_allowed_generate_kwargs(request, _OPENAI_RESPONSES_GENERATE_KWARGS),
    }
    if request.max_tokens is not None and "max_output_tokens" not in payload:
        payload["max_output_tokens"] = request.max_tokens
    if request.system_prompt and "instructions" not in payload:
        payload["instructions"] = "\n\n".join(request.system_prompt)
    if request.tools:
        payload["tools"] = serialize_openai_responses_tools(request.tools)
    return payload


def parse_openai_responses_batch(payload: dict[str, Any]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    output = payload.get("output") or []
    if isinstance(output, list):
        for item in output:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "message":
                for part in item.get("content") or []:
                    if not isinstance(part, dict):
                        continue
                    if part.get("type") == "output_text":
                        text = part.get("text") or ""
                        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
                        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
                        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text))
            elif item.get("type") == "function_call":
                events.append(AssistantEvent(
                    kind=AssistantEventKind.TOOL_USE,
                    tool_use_id=item.get("call_id") or item.get("id") or "",
                    tool_name=item.get("name") or "",
                    tool_input=item.get("arguments") or "{}",
                ))
    usage = usage_from_payload(payload)
    if usage is not None:
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=usage,
                model_id=payload.get("model"),
                request_id=payload.get("id"),
            )
        )
    status = payload.get("status")
    stop = StopReason.TOOL_USE if any(
        isinstance(i, dict) and i.get("type") == "function_call" for i in (output if isinstance(output, list) else [])
    ) else StopReason.STOP
    if status == "incomplete":
        stop = StopReason.LENGTH
    events.append(AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop))
    return events


def parse_openai_responses_stream(chunks: Iterable[dict[str, Any]]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    text_started = False
    tool_acc: dict[str, dict[str, str]] = {}
    usage: TokenUsage | None = None
    model_id: str | None = None
    request_id: str | None = None
    stop_reason = StopReason.STOP

    for chunk in chunks:
        if not isinstance(chunk, dict):
            continue
        model_id = chunk.get("model") or model_id
        request_id = chunk.get("id") or request_id
        usage = usage_from_payload(chunk) or usage
        etype = chunk.get("type")
        if etype == "response.output_text.delta":
            text = str(chunk.get("delta") or "")
            if text:
                if not text_started:
                    text_started = True
                    events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
                events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
        elif etype == "response.function_call_arguments.delta":
            item_id = str(chunk.get("item_id") or chunk.get("call_id") or "")
            current = tool_acc.setdefault(item_id, {"id": item_id, "name": "", "arguments": ""})
            partial = str(chunk.get("delta") or "")
            current["arguments"] += partial
            current.setdefault("deltas", [])
            current["deltas"].append(partial)
        elif etype == "response.output_item.added":
            item = chunk.get("item") or {}
            if item.get("type") == "function_call":
                item_id = str(item.get("call_id") or item.get("id") or "")
                tool_acc[item_id] = {
                    "id": item_id,
                    "name": str(item.get("name") or ""),
                    "arguments": str(item.get("arguments") or ""),
                }
        elif etype == "response.completed":
            response = chunk.get("response") or {}
            model_id = response.get("model") or model_id
            request_id = response.get("id") or request_id
            usage = usage_from_payload(response) or usage
            status = response.get("status")
            if status == "incomplete":
                stop_reason = StopReason.LENGTH

    if text_started:
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END))
    for tool in tool_acc.values():
        for partial in tool.get("deltas", []):
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_INPUT_DELTA,
                tool_use_id=tool["id"],
                tool_name=tool["name"],
                tool_input_delta=partial,
            ))
        if tool["name"] or tool["arguments"]:
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_use_id=tool["id"],
                tool_name=tool["name"],
                tool_input=tool["arguments"] or "{}",
            ))
    if usage is not None:
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=usage,
                model_id=model_id,
                request_id=request_id,
            )
        )
    if tool_acc and stop_reason == StopReason.STOP:
        stop_reason = StopReason.TOOL_USE
    events.append(AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason))
    return events


def make_openai_responses_transport(
    *,
    api_key: str,
    model_id: str,
    base_url: str,
) -> TransportFn:
    from urllib.request import Request, urlopen

    def _transport(request: ApiRequest, stream: bool) -> Any:
        payload = build_openai_responses_payload(
            request,
            model_id=model_id,
            stream=stream,
        )
        ep = (base_url or "https://api.openai.com").rstrip("/")
        req = Request(
            f"{ep}/v1/responses",
            data=json.dumps(payload).encode(),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        with urlopen(req) as resp:
            ct = resp.headers.get("Content-Type", "")
            if "event-stream" in ct:
                chunks = []
                for part in resp.read().decode().split("\n\n"):
                    for line in part.splitlines():
                        if line.startswith("data: "):
                            body = line[6:].strip()
                            if body and body != "[DONE]":
                                chunks.append(json.loads(body))
                return chunks
            return json.loads(resp.read().decode())

    return _transport


class OpenAIResponsesModelClient(ModelClient):
    def __init__(
        self,
        transport: TransportFn | None,
        *,
        streaming: bool = False,
        api_key: str = "",
        model_id: str = "",
        base_url: str = "https://api.openai.com",
        model_spec: ModelSpec | None = None,
    ) -> None:
        self._transport = transport
        self._streaming = streaming
        self._api_key = api_key
        self._model_id = model_id
        self._base_url = base_url
        self.model_spec = model_spec

    def estimate_tokens(self, request: ApiRequest) -> int | None:
        return estimate_openai_request_tokens(
            request,
            serialized_messages=serialize_openai_responses_input(request),
            serialized_tools=serialize_openai_responses_tools(request.tools),
            model_id=self.model_spec.id if self.model_spec else None,
        )

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            if self._transport is not None:
                payload = await asyncio.to_thread(self._transport, request, self._streaming)
                if self._streaming:
                    assert not isinstance(payload, dict)
                    events = parse_openai_responses_stream(payload)
                else:
                    assert isinstance(payload, dict)
                    events = parse_openai_responses_batch(payload)
                for ev in events:
                    yield ev
                return

            payload = build_openai_responses_payload(
                request,
                model_id=self._model_id,
                stream=self._streaming,
            )
            url = f"{self._base_url.rstrip('/')}/v1/responses"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key}",
            }

            if not self._streaming:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                for ev in parse_openai_responses_batch(resp.json()):
                    yield ev
                return

            text_started = False
            tool_acc: dict[str, dict[str, Any]] = {}
            usage: TokenUsage | None = None
            model_id: str | None = None
            request_id: str | None = None
            stop_reason = StopReason.STOP
            async with httpx.AsyncClient() as client:
                async with client.stream("POST", url, json=payload, headers=headers) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        body = line[6:].strip()
                        if not body or body == "[DONE]":
                            continue
                        try:
                            chunk = json.loads(body)
                        except ValueError:
                            continue
                        if not isinstance(chunk, dict):
                            continue
                        model_id = chunk.get("model") or model_id
                        request_id = chunk.get("id") or request_id
                        usage = usage_from_payload(chunk) or usage
                        etype = chunk.get("type")
                        if etype == "response.output_text.delta":
                            text = str(chunk.get("delta") or "")
                            if text:
                                if not text_started:
                                    text_started = True
                                    yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
                                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text)
                        elif etype == "response.output_item.added":
                            item = chunk.get("item") or {}
                            if isinstance(item, dict) and item.get("type") == "function_call":
                                item_id = str(item.get("call_id") or item.get("id") or "")
                                tool_acc[item_id] = {
                                    "id": item_id,
                                    "name": str(item.get("name") or ""),
                                    "arguments": str(item.get("arguments") or ""),
                                }
                        elif etype == "response.function_call_arguments.delta":
                            item_id = str(chunk.get("item_id") or chunk.get("call_id") or "")
                            tool = tool_acc.setdefault(item_id, {"id": item_id, "name": "", "arguments": ""})
                            partial = str(chunk.get("delta") or "")
                            if partial:
                                tool["arguments"] += partial
                                yield AssistantEvent(
                                    kind=AssistantEventKind.TOOL_INPUT_DELTA,
                                    tool_use_id=tool["id"],
                                    tool_name=tool["name"],
                                    tool_input_delta=partial,
                                )
                        elif etype == "response.completed":
                            response = chunk.get("response") or {}
                            if isinstance(response, dict):
                                model_id = response.get("model") or model_id
                                request_id = response.get("id") or request_id
                                usage = usage_from_payload(response) or usage
                                if response.get("status") == "incomplete":
                                    stop_reason = StopReason.LENGTH

            if text_started:
                yield AssistantEvent(kind=AssistantEventKind.TEXT_END)
            for tool in tool_acc.values():
                if tool["name"] or tool["arguments"]:
                    yield AssistantEvent(
                        kind=AssistantEventKind.TOOL_USE,
                        tool_use_id=tool["id"],
                        tool_name=tool["name"],
                        tool_input=tool["arguments"] or "{}",
                    )
            if usage is not None:
                yield AssistantEvent(
                    kind=AssistantEventKind.USAGE,
                    usage=usage,
                    model_id=model_id,
                    request_id=request_id,
                )
            if tool_acc and stop_reason == StopReason.STOP:
                stop_reason = StopReason.TOOL_USE
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason)

        return _gen()


def openai_responses_client_factory(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    transport: TransportFn | None = None,
    **_: Any,
) -> OpenAIResponsesModelClient:
    return OpenAIResponsesModelClient(
        transport,
        streaming=streaming,
        api_key=api_key,
        model_id=spec.id,
        base_url=spec.base_url or "https://api.openai.com",
        model_spec=spec,
    )
