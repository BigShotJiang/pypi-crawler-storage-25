"""Protocol adapters for LLM providers."""

from tada_core.providers.registry import (
    build_model_client,
    get_model_adapter,
    register_model_adapter,
)

__all__ = [
    "build_model_client",
    "get_model_adapter",
    "register_model_adapter",
]
