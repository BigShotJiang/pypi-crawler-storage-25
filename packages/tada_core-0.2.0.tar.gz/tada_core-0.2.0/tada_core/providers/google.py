"""Google Gemini Generative Language API adapter."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable, Iterable
from typing import Any

import httpx

from tada_core.contracts.messages import MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient, StopReason
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import TokenUsage

TransportFn = Callable[[ApiRequest, bool], dict[str, Any] | Iterable[dict[str, Any]]]

_GOOGLE_GENERATE_KWARGS = {
    "cachedContent",
    "generationConfig",
    "safetySettings",
    "toolConfig",
}


def _allowed_generate_kwargs(request: ApiRequest, allowed: set[str]) -> dict[str, Any]:
    return {key: value for key, value in request.generate_kwargs.items() if key in allowed}


def serialize_google_contents(request: ApiRequest) -> list[dict[str, Any]]:
    contents: list[dict[str, Any]] = []
    for message in request.messages:
        role = "model" if message.role == MessageRole.ASSISTANT else "user"
        parts: list[dict[str, Any]] = []
        if message.role == MessageRole.TOOL:
            for block in message.content:
                if block.type == "tool_result":
                    parts.append({
                        "functionResponse": {
                            "name": block.tool_name or block.tool_use_id or "tool",
                            "response": {"result": block.tool_result or ""},
                        }
                    })
        else:
            for block in message.content:
                if block.type == "text" and block.text:
                    parts.append({"text": block.text})
                elif block.type == "image" and block.source == "base64":
                    parts.append({
                        "inlineData": {
                            "mimeType": block.mime_type,
                            "data": block.data,
                        }
                    })
                elif block.type == "tool_use":
                    try:
                        args = json.loads(block.tool_input or "{}")
                    except ValueError:
                        args = {}
                    parts.append({
                        "functionCall": {
                            "name": block.tool_name or "",
                            "args": args,
                        }
                    })
        if parts:
            contents.append({"role": role, "parts": parts})
    return contents


def serialize_google_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    declarations = []
    for tool in tools:
        fn = tool.get("function", {})
        declarations.append({
            "name": fn.get("name", ""),
            "description": fn.get("description", ""),
            "parameters": fn.get("parameters", {"type": "object"}),
        })
    return [{"functionDeclarations": declarations}] if declarations else []


def serialize_google_request(request: ApiRequest) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "contents": serialize_google_contents(request),
        **_allowed_generate_kwargs(request, _GOOGLE_GENERATE_KWARGS),
    }
    if request.system_prompt:
        payload["systemInstruction"] = {"parts": [{"text": "\n\n".join(request.system_prompt)}]}
    if request.tools:
        payload["tools"] = serialize_google_tools(request.tools)
    return payload


def _stop_reason_from_google(reason: str | None) -> StopReason:
    if reason in {"MAX_TOKENS", "LENGTH"}:
        return StopReason.LENGTH
    if reason == "STOP":
        return StopReason.STOP
    return StopReason.STOP


def parse_google_response(payload: dict[str, Any]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    candidates = payload.get("candidates") or []
    first = candidates[0] if isinstance(candidates, list) and candidates else {}
    content = first.get("content") if isinstance(first, dict) else {}
    parts = content.get("parts") if isinstance(content, dict) else []
    for part in parts or []:
        if not isinstance(part, dict):
            continue
        if isinstance(part.get("text"), str):
            text = part["text"]
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text))
        function_call = part.get("functionCall")
        if isinstance(function_call, dict):
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_name=str(function_call.get("name") or ""),
                tool_input=json.dumps(function_call.get("args") or {}),
            ))
    usage = payload.get("usageMetadata") or {}
    if isinstance(usage, dict) and usage:
        events.append(AssistantEvent(
            kind=AssistantEventKind.USAGE,
            usage=TokenUsage(
                input_tokens=int(usage.get("promptTokenCount") or 0),
                output_tokens=int(usage.get("candidatesTokenCount") or 0),
                cache_read_tokens=int(usage.get("cachedContentTokenCount") or 0),
            ),
            model_id=payload.get("modelVersion"),
            request_id=payload.get("responseId"),
        ))
    finish = first.get("finishReason") if isinstance(first, dict) else None
    events.append(AssistantEvent(
        kind=AssistantEventKind.MESSAGE_STOP,
        stop_reason=_stop_reason_from_google(str(finish) if finish else None),
    ))
    return events


def parse_google_stream(chunks: Iterable[dict[str, Any]]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    text_started = False
    usage: TokenUsage | None = None
    model_id: str | None = None
    request_id: str | None = None
    stop_reason = StopReason.STOP
    for chunk in chunks:
        if not isinstance(chunk, dict):
            continue
        model_id = chunk.get("modelVersion") or model_id
        request_id = chunk.get("responseId") or request_id
        candidates = chunk.get("candidates") or []
        first = candidates[0] if isinstance(candidates, list) and candidates else {}
        content = first.get("content") if isinstance(first, dict) else {}
        parts = content.get("parts") if isinstance(content, dict) else []
        for part in parts or []:
            if not isinstance(part, dict):
                continue
            if isinstance(part.get("text"), str):
                if not text_started:
                    text_started = True
                    events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
                events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=part["text"]))
            function_call = part.get("functionCall")
            if isinstance(function_call, dict):
                events.append(AssistantEvent(
                    kind=AssistantEventKind.TOOL_USE,
                    tool_name=str(function_call.get("name") or ""),
                    tool_input=json.dumps(function_call.get("args") or {}),
                ))
        finish = first.get("finishReason") if isinstance(first, dict) else None
        if finish:
            stop_reason = _stop_reason_from_google(str(finish))
        raw_usage = chunk.get("usageMetadata")
        if isinstance(raw_usage, dict) and raw_usage:
            usage = TokenUsage(
                input_tokens=int(raw_usage.get("promptTokenCount") or 0),
                output_tokens=int(raw_usage.get("candidatesTokenCount") or 0),
                cache_read_tokens=int(raw_usage.get("cachedContentTokenCount") or 0),
            )
    if text_started:
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END))
    if usage is not None:
        events.append(AssistantEvent(
            kind=AssistantEventKind.USAGE,
            usage=usage,
            model_id=model_id,
            request_id=request_id,
        ))
    events.append(AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason))
    return events


class GoogleGenerativeAIModelClient(ModelClient):
    def __init__(
        self,
        transport: TransportFn | None,
        *,
        streaming: bool = False,
        api_key: str = "",
        model_id: str = "",
        base_url: str = "https://generativelanguage.googleapis.com",
        headers: dict[str, str] | None = None,
        model_spec: ModelSpec | None = None,
    ) -> None:
        self._transport = transport
        self._streaming = streaming
        self._api_key = api_key
        self._model_id = model_id
        self._base_url = base_url
        self._headers = headers or {}
        self.model_spec = model_spec

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            if self._transport is not None:
                payload = await asyncio.to_thread(self._transport, request, self._streaming)
                events = parse_google_stream(payload) if self._streaming and not isinstance(payload, dict) else parse_google_response(payload)  # type: ignore[arg-type]
                for event in events:
                    yield event
                return

            payload = serialize_google_request(request)
            endpoint = "streamGenerateContent?alt=sse" if self._streaming else "generateContent"
            base = self._base_url.rstrip("/")
            separator = "&" if "?" in endpoint else "?"
            url = f"{base}/v1beta/models/{self._model_id}:{endpoint}{separator}key={self._api_key}"
            headers = {"Content-Type": "application/json", **self._headers}

            if not self._streaming:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                for event in parse_google_response(resp.json()):
                    yield event
                return

            text_started = False
            usage: TokenUsage | None = None
            model_id: str | None = None
            request_id: str | None = None
            stop_reason = StopReason.STOP
            async with httpx.AsyncClient() as client:
                async with client.stream("POST", url, json=payload, headers=headers) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        body = line[6:].strip()
                        if not body or body == "[DONE]":
                            continue
                        try:
                            chunk = json.loads(body)
                        except ValueError:
                            continue
                        if isinstance(chunk, dict):
                            model_id = chunk.get("modelVersion") or model_id
                            request_id = chunk.get("responseId") or request_id
                            candidates = chunk.get("candidates") or []
                            first = candidates[0] if isinstance(candidates, list) and candidates else {}
                            content = first.get("content") if isinstance(first, dict) else {}
                            parts = content.get("parts") if isinstance(content, dict) else []
                            for part in parts or []:
                                if not isinstance(part, dict):
                                    continue
                                if isinstance(part.get("text"), str):
                                    if not text_started:
                                        text_started = True
                                        yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
                                    yield AssistantEvent(
                                        kind=AssistantEventKind.TEXT_DELTA,
                                        text_delta=part["text"],
                                    )
                                function_call = part.get("functionCall")
                                if isinstance(function_call, dict):
                                    yield AssistantEvent(
                                        kind=AssistantEventKind.TOOL_USE,
                                        tool_name=str(function_call.get("name") or ""),
                                        tool_input=json.dumps(function_call.get("args") or {}),
                                    )
                            finish = first.get("finishReason") if isinstance(first, dict) else None
                            if finish:
                                stop_reason = _stop_reason_from_google(str(finish))
                            raw_usage = chunk.get("usageMetadata")
                            if isinstance(raw_usage, dict) and raw_usage:
                                usage = TokenUsage(
                                    input_tokens=int(raw_usage.get("promptTokenCount") or 0),
                                    output_tokens=int(raw_usage.get("candidatesTokenCount") or 0),
                                    cache_read_tokens=int(raw_usage.get("cachedContentTokenCount") or 0),
                                )

            if text_started:
                yield AssistantEvent(kind=AssistantEventKind.TEXT_END)
            if usage is not None:
                yield AssistantEvent(
                    kind=AssistantEventKind.USAGE,
                    usage=usage,
                    model_id=model_id,
                    request_id=request_id,
                )
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason)

        return _gen()


def google_client_factory(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    transport: TransportFn | None = None,
    **_: Any,
) -> GoogleGenerativeAIModelClient:
    return GoogleGenerativeAIModelClient(
        transport,
        streaming=streaming,
        api_key=api_key,
        model_id=spec.id,
        base_url=spec.base_url or "https://generativelanguage.googleapis.com",
        headers=spec.headers,
        model_spec=spec,
    )
