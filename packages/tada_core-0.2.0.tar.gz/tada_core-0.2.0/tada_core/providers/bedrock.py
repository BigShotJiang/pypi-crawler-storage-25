"""AWS Bedrock Converse protocol adapter."""

from __future__ import annotations

import asyncio
import base64
import json
from collections.abc import AsyncIterator, Callable, Iterable
from typing import Any, Literal

from tada_core.contracts.messages import MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient, StopReason
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import TokenUsage

TransportFn = Callable[[ApiRequest, bool], dict[str, Any] | Iterable[dict[str, Any]]]
CacheRetention = Literal["none", "short", "long"]

_BEDROCK_GENERATE_KWARGS = {
    "additionalModelRequestFields",
    "guardrailConfig",
    "inferenceConfig",
    "performanceConfig",
    "promptVariables",
}


def _allowed_generate_kwargs(request: ApiRequest, allowed: set[str]) -> dict[str, Any]:
    return {key: value for key, value in request.generate_kwargs.items() if key in allowed}


def _bedrock_cache_point(cache_retention: CacheRetention) -> dict[str, Any] | None:
    if cache_retention == "none":
        return None
    cache_point: dict[str, Any] = {"type": "default"}
    if cache_retention == "long":
        cache_point["ttl"] = "1h"
    return {"cachePoint": cache_point}


def serialize_bedrock_messages(request: ApiRequest) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    for message in request.messages:
        role = "assistant" if message.role == MessageRole.ASSISTANT else "user"
        content: list[dict[str, Any]] = []
        if message.role == MessageRole.TOOL:
            for block in message.content:
                if block.type == "tool_result":
                    result_content: list[dict[str, Any]] = []
                    for nested in block.tool_result_blocks():
                        if nested.type == "text" and nested.text:
                            result_content.append({"text": nested.text})
                        elif nested.type == "image" and nested.source == "base64":
                            fmt = (nested.mime_type or "image/png").split("/")[-1]
                            result_content.append({
                                "image": {
                                    "format": fmt,
                                    "source": {"bytes": base64.b64decode(nested.data or "")},
                                }
                            })
                    content.append({
                        "toolResult": {
                            "toolUseId": block.tool_use_id or "",
                            "content": result_content or [{"text": block.tool_result or ""}],
                            "status": "error" if block.is_error else "success",
                        }
                    })
        else:
            for block in message.content:
                if block.type == "text" and block.text:
                    content.append({"text": block.text})
                elif block.type == "image" and block.source == "base64":
                    fmt = (block.mime_type or "image/png").split("/")[-1]
                    content.append({
                        "image": {
                            "format": fmt,
                            "source": {"bytes": base64.b64decode(block.data or "")},
                        }
                    })
                elif block.type == "thinking" and block.thinking:
                    reasoning_text: dict[str, Any] = {"text": block.thinking}
                    if block.signature:
                        reasoning_text["signature"] = block.signature
                    content.append({"reasoningContent": {"reasoningText": reasoning_text}})
                elif block.type == "tool_use":
                    try:
                        parsed = json.loads(block.tool_input or "{}")
                    except ValueError:
                        parsed = {}
                    content.append({
                        "toolUse": {
                            "toolUseId": block.tool_use_id or "",
                            "name": block.tool_name or "",
                            "input": parsed,
                        }
                    })
        if content:
            messages.append({"role": role, "content": content})
    return messages


def serialize_bedrock_tools(tools: list[dict[str, Any]]) -> dict[str, Any] | None:
    tool_specs = []
    for tool in tools:
        fn = tool.get("function", {})
        tool_specs.append({
            "toolSpec": {
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "inputSchema": {"json": fn.get("parameters", {"type": "object"})},
            }
        })
    return {"tools": tool_specs} if tool_specs else None


def serialize_bedrock_request(
    request: ApiRequest,
    *,
    model_id: str,
    cache_retention: CacheRetention = "short",
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "modelId": model_id,
        "messages": serialize_bedrock_messages(request),
        **_allowed_generate_kwargs(request, _BEDROCK_GENERATE_KWARGS),
    }
    cache_point = _bedrock_cache_point(cache_retention)

    if request.system_prompt:
        body["system"] = [{"text": "\n\n".join(request.system_prompt)}]
        if cache_point is not None:
            body["system"].append(dict(cache_point))

    tool_config = serialize_bedrock_tools(request.tools)
    if tool_config:
        if cache_point is not None:
            tool_config["tools"].append(dict(cache_point))
        body["toolConfig"] = tool_config

    if cache_point is not None:
        user_messages = [message for message in body["messages"] if message.get("role") == "user"]
        for message in user_messages[-2:]:
            content = message.get("content")
            if isinstance(content, list):
                content.append(dict(cache_point))

    return body


def _stop_reason_from_bedrock(reason: str | None) -> StopReason:
    if reason == "max_tokens":
        return StopReason.LENGTH
    if reason == "tool_use":
        return StopReason.TOOL_USE
    return StopReason.STOP


def parse_bedrock_response(payload: dict[str, Any]) -> list[AssistantEvent]:
    events: list[AssistantEvent] = []
    message = ((payload.get("output") or {}).get("message") or {})
    for part in message.get("content") or []:
        if not isinstance(part, dict):
            continue
        if isinstance(part.get("text"), str):
            text = part["text"]
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
            events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text))
        reasoning = part.get("reasoningContent")
        if isinstance(reasoning, dict):
            reasoning_text = reasoning.get("reasoningText") or {}
            if isinstance(reasoning_text, dict):
                text = str(reasoning_text.get("text") or "")
                signature = reasoning_text.get("signature")
                if text:
                    events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
                    events.append(AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=text))
                    events.append(AssistantEvent(
                        kind=AssistantEventKind.THINKING_END,
                        thinking_delta=text,
                        thinking_signature=str(signature) if signature else None,
                    ))
        tool_use = part.get("toolUse")
        if isinstance(tool_use, dict):
            events.append(AssistantEvent(
                kind=AssistantEventKind.TOOL_USE,
                tool_use_id=str(tool_use.get("toolUseId") or ""),
                tool_name=str(tool_use.get("name") or ""),
                tool_input=json.dumps(tool_use.get("input") or {}),
            ))
    usage = payload.get("usage") or {}
    if isinstance(usage, dict) and usage:
        events.append(AssistantEvent(
            kind=AssistantEventKind.USAGE,
            usage=TokenUsage(
                input_tokens=int(usage.get("inputTokens") or 0),
                output_tokens=int(usage.get("outputTokens") or 0),
                cache_read_tokens=int(usage.get("cacheReadInputTokens") or 0),
                cache_creation_tokens=int(usage.get("cacheWriteInputTokens") or 0),
            ),
            model_id=payload.get("modelId"),
            request_id=payload.get("ResponseMetadata", {}).get("RequestId"),
        ))
    events.append(AssistantEvent(
        kind=AssistantEventKind.MESSAGE_STOP,
        stop_reason=_stop_reason_from_bedrock(payload.get("stopReason")),
    ))
    return events


def parse_bedrock_stream(chunks: Iterable[dict[str, Any]]) -> list[AssistantEvent]:
    text_parts: list[str] = []
    thinking_parts: list[str] = []
    thinking_signature_parts: list[str] = []
    tool_acc: dict[str, dict[str, str]] = {}
    usage: TokenUsage | None = None
    request_id: str | None = None
    stop_reason = StopReason.STOP
    for chunk in chunks:
        if isinstance(chunk, dict):
            metadata = chunk.get("metadata")
            if isinstance(metadata, dict):
                request_id = metadata.get("requestId") or request_id
        delta = chunk.get("contentBlockDelta", {}).get("delta", {}) if isinstance(chunk, dict) else {}
        if "text" in delta:
            text_parts.append(delta.get("text") or "")
        reasoning = delta.get("reasoningContent")
        if isinstance(reasoning, dict):
            if reasoning.get("text"):
                thinking_parts.append(str(reasoning["text"]))
            if reasoning.get("signature"):
                thinking_signature_parts.append(str(reasoning["signature"]))
        if "toolUse" in delta:
            tool_delta = delta["toolUse"]
            tool_id = str(tool_delta.get("toolUseId") or tool_delta.get("name") or "tool")
            current = tool_acc.setdefault(tool_id, {"id": tool_id, "name": "", "input": ""})
            if tool_delta.get("name"):
                current["name"] = str(tool_delta["name"])
            if tool_delta.get("input"):
                current["input"] += str(tool_delta["input"])
        metadata = chunk.get("metadata") if isinstance(chunk, dict) else None
        if isinstance(metadata, dict) and isinstance(metadata.get("usage"), dict):
            raw_usage = metadata["usage"]
            usage = TokenUsage(
                input_tokens=int(raw_usage.get("inputTokens") or 0),
                output_tokens=int(raw_usage.get("outputTokens") or 0),
                cache_read_tokens=int(raw_usage.get("cacheReadInputTokens") or 0),
                cache_creation_tokens=int(raw_usage.get("cacheWriteInputTokens") or 0),
            )
        if isinstance(chunk, dict) and chunk.get("messageStop"):
            stop_reason = _stop_reason_from_bedrock(chunk["messageStop"].get("stopReason"))
    events: list[AssistantEvent] = []
    if thinking_parts:
        thinking = "".join(thinking_parts)
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_START))
        events.append(AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=thinking))
        events.append(AssistantEvent(
            kind=AssistantEventKind.THINKING_END,
            thinking_delta=thinking,
            thinking_signature="".join(thinking_signature_parts) or None,
        ))
    if text_parts:
        text = "".join(text_parts)
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_START))
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text))
        events.append(AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta=text))
    for tool in tool_acc.values():
        events.append(AssistantEvent(
            kind=AssistantEventKind.TOOL_USE,
            tool_use_id=tool["id"],
            tool_name=tool["name"],
            tool_input=tool["input"] or "{}",
        ))
    if usage is not None:
        events.append(
            AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=usage,
                request_id=request_id,
            )
        )
    events.append(AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason))
    return events


def _make_default_bedrock_transport(spec: ModelSpec, cache_retention: CacheRetention) -> TransportFn:
    def _transport(request: ApiRequest, stream: bool) -> dict[str, Any] | Iterable[dict[str, Any]]:
        import boto3  # type: ignore[import-not-found]

        client = boto3.client("bedrock-runtime", **spec.compat.get("boto3", {}))
        body = serialize_bedrock_request(
            request,
            model_id=spec.id,
            cache_retention=cache_retention,
        )
        if stream:
            response = client.converse_stream(**body)
            return response.get("stream", [])
        return client.converse(**body)

    return _transport


class BedrockConverseModelClient(ModelClient):
    def __init__(
        self,
        transport: TransportFn,
        *,
        streaming: bool = False,
        model_spec: ModelSpec | None = None,
    ) -> None:
        self._transport = transport
        self._streaming = streaming
        self.model_spec = model_spec

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            payload = await asyncio.to_thread(self._transport, request, self._streaming)
            if self._streaming and not isinstance(payload, dict):
                block_types: dict[int, str] = {}
                tool_acc: dict[int, dict[str, str]] = {}
                thinking_sig: dict[int, str] = {}
                thinking_started: set[int] = set()
                text_started: set[int] = set()
                usage: TokenUsage | None = None
                request_id: str | None = None
                stop_reason = StopReason.STOP
                sentinel = object()
                iterator = iter(payload)

                while True:
                    chunk = await asyncio.to_thread(next, iterator, sentinel)
                    if chunk is sentinel:
                        break
                    if not isinstance(chunk, dict):
                        continue

                    metadata = chunk.get("metadata")
                    if isinstance(metadata, dict):
                        request_id = metadata.get("requestId") or request_id
                        raw_usage = metadata.get("usage")
                        if isinstance(raw_usage, dict):
                            usage = TokenUsage(
                                input_tokens=int(raw_usage.get("inputTokens") or 0),
                                output_tokens=int(raw_usage.get("outputTokens") or 0),
                                cache_read_tokens=int(raw_usage.get("cacheReadInputTokens") or 0),
                                cache_creation_tokens=int(raw_usage.get("cacheWriteInputTokens") or 0),
                            )

                    start = chunk.get("contentBlockStart")
                    if isinstance(start, dict):
                        idx = int(start.get("contentBlockIndex") or 0)
                        data = start.get("start") or {}
                        if isinstance(data, dict) and isinstance(data.get("toolUse"), dict):
                            tool = data["toolUse"]
                            block_types[idx] = "toolUse"
                            tool_acc[idx] = {
                                "id": str(tool.get("toolUseId") or f"tool-{idx}"),
                                "name": str(tool.get("name") or ""),
                                "input": "",
                            }

                    delta_wrap = chunk.get("contentBlockDelta")
                    delta = delta_wrap.get("delta") if isinstance(delta_wrap, dict) else None
                    idx = int(delta_wrap.get("contentBlockIndex") or 0) if isinstance(delta_wrap, dict) else 0
                    if isinstance(delta, dict):
                        if "text" in delta:
                            block_types[idx] = "text"
                            if idx not in text_started:
                                text_started.add(idx)
                                yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
                            text = str(delta.get("text") or "")
                            if text:
                                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=text)
                        reasoning = delta.get("reasoningContent")
                        if isinstance(reasoning, dict):
                            block_types[idx] = "reasoningContent"
                            if idx not in thinking_started:
                                thinking_started.add(idx)
                                yield AssistantEvent(kind=AssistantEventKind.THINKING_START)
                            text = str(reasoning.get("text") or "")
                            if text:
                                yield AssistantEvent(kind=AssistantEventKind.THINKING_DELTA, thinking_delta=text)
                            signature = reasoning.get("signature")
                            if signature:
                                thinking_sig[idx] = str(signature)
                        tool_delta = delta.get("toolUse")
                        if isinstance(tool_delta, dict):
                            block_types[idx] = "toolUse"
                            tool = tool_acc.setdefault(
                                idx,
                                {"id": str(tool_delta.get("toolUseId") or f"tool-{idx}"), "name": "", "input": ""},
                            )
                            if tool_delta.get("toolUseId"):
                                tool["id"] = str(tool_delta["toolUseId"])
                            if tool_delta.get("name"):
                                tool["name"] = str(tool_delta["name"])
                            partial = str(tool_delta.get("input") or "")
                            if partial:
                                tool["input"] += partial
                                yield AssistantEvent(
                                    kind=AssistantEventKind.TOOL_INPUT_DELTA,
                                    tool_use_id=tool["id"],
                                    tool_name=tool["name"],
                                    tool_input_delta=partial,
                                )

                    stop = chunk.get("contentBlockStop")
                    if isinstance(stop, dict):
                        idx = int(stop.get("contentBlockIndex") or 0)
                        btype = block_types.get(idx)
                        if btype == "text" and idx in text_started:
                            yield AssistantEvent(kind=AssistantEventKind.TEXT_END)
                        elif btype == "reasoningContent" and idx in thinking_started:
                            yield AssistantEvent(
                                kind=AssistantEventKind.THINKING_END,
                                thinking_signature=thinking_sig.get(idx),
                            )
                        elif btype == "toolUse" and idx in tool_acc:
                            tool = tool_acc[idx]
                            yield AssistantEvent(
                                kind=AssistantEventKind.TOOL_USE,
                                tool_use_id=tool["id"],
                                tool_name=tool["name"],
                                tool_input=tool["input"] or "{}",
                            )

                    message_stop = chunk.get("messageStop")
                    if isinstance(message_stop, dict):
                        stop_reason = _stop_reason_from_bedrock(message_stop.get("stopReason"))

                if usage is not None:
                    yield AssistantEvent(kind=AssistantEventKind.USAGE, usage=usage, request_id=request_id)
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=stop_reason)
            else:
                assert isinstance(payload, dict)
                for event in parse_bedrock_response(payload):
                    yield event

        return _gen()


def bedrock_client_factory(
    spec: ModelSpec,
    *,
    streaming: bool = True,
    transport: TransportFn | None = None,
    cache_retention: CacheRetention = "short",
    **_: Any,
) -> BedrockConverseModelClient:
    if transport is None:
        transport = _make_default_bedrock_transport(spec, cache_retention)

    return BedrockConverseModelClient(transport, streaming=streaming, model_spec=spec)
