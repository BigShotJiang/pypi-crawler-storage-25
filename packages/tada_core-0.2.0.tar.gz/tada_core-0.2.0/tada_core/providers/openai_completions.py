"""OpenAI Chat Completions protocol adapter."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Callable, Iterable
from typing import Any

import httpx

from tada_core.contracts.messages import MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient, StopReason
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import TokenUsage
from tada_core.providers.openai_utils import (
    estimate_openai_request_tokens,
    parse_openai_completions_batch,
    parse_openai_completions_stream,
    stop_reason_from_finish,
    usage_from_payload,
)

TransportFn = Callable[[ApiRequest, bool], dict[str, Any] | Iterable[dict[str, Any]]]

_OPENAI_COMPLETIONS_GENERATE_KWARGS = {
    "extra_body",
    "frequency_penalty",
    "logit_bias",
    "metadata",
    "parallel_tool_calls",
    "presence_penalty",
    "response_format",
    "seed",
    "stop",
    "temperature",
    "tool_choice",
    "top_p",
    "user",
}


def _allowed_generate_kwargs(request: ApiRequest, allowed: set[str]) -> dict[str, Any]:
    return {key: value for key, value in request.generate_kwargs.items() if key in allowed}


def serialize_openai_completions_messages(request: ApiRequest) -> list[dict[str, Any]]:
    msgs: list[dict[str, Any]] = []
    for p in request.system_prompt:
        msgs.append({"role": "system", "content": p})
    for m in request.messages:
        if m.role == MessageRole.TOOL:
            for b in m.content:
                if b.type == "tool_result":
                    msgs.append({
                        "role": "tool",
                        "tool_call_id": b.tool_use_id or "",
                        "content": b.tool_result or "",
                    })
            continue
        texts: list[str] = []
        images: list[dict[str, Any]] = []
        calls: list[dict[str, Any]] = []
        reasoning_content: str | None = None
        for b in m.content:
            if b.type == "text" and b.text:
                texts.append(b.text)
            elif b.type == "image" and b.source == "base64":
                images.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{b.mime_type};base64,{b.data}"},
                })
            elif b.type == "tool_use":
                calls.append({
                    "id": b.tool_use_id or "",
                    "type": "function",
                    "function": {
                        "name": b.tool_name or "",
                        "arguments": b.tool_input or "{}",
                    },
                })
            elif b.type == "thinking" and b.thinking:
                reasoning_content = (
                    f"{reasoning_content or ''}{b.thinking}"
                )
        if images:
            content: list[dict[str, Any]] = []
            if texts:
                content.append({"type": "text", "text": "".join(texts)})
            content.extend(images)
            entry: dict[str, Any] = {"role": m.role.value, "content": content}
        else:
            entry = {"role": m.role.value, "content": "".join(texts)}
        if calls:
            entry["tool_calls"] = calls
        if reasoning_content:
            entry["reasoning_content"] = reasoning_content
        msgs.append(entry)
    return msgs


def build_openai_completions_payload(
    request: ApiRequest,
    *,
    model_id: str,
    stream: bool,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model_id,
        "messages": serialize_openai_completions_messages(request),
        "stream": stream,
        **_allowed_generate_kwargs(request, _OPENAI_COMPLETIONS_GENERATE_KWARGS),
    }
    if request.max_tokens is not None:
        payload["max_tokens"] = request.max_tokens
    if request.tools:
        payload["tools"] = request.tools
    return payload


def make_openai_completions_transport(
    *,
    api_key: str,
    model_id: str,
    base_url: str,
) -> TransportFn:
    import json
    from urllib.request import Request, urlopen

    def _transport(request: ApiRequest, stream: bool) -> Any:
        payload = build_openai_completions_payload(
            request,
            model_id=model_id,
            stream=stream,
        )
        ep = (base_url or "https://api.openai.com").rstrip("/")
        req = Request(
            f"{ep}/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        with urlopen(req) as resp:
            ct = resp.headers.get("Content-Type", "")
            if "event-stream" in ct:
                chunks = []
                for part in resp.read().decode().split("\n\n"):
                    for line in part.splitlines():
                        if line.startswith("data: "):
                            body = line[6:].strip()
                            if body and body != "[DONE]":
                                chunks.append(json.loads(body))
                return chunks
            return json.loads(resp.read().decode())

    return _transport


class OpenAICompletionsModelClient(ModelClient):
    def __init__(
        self,
        transport: TransportFn | None,
        *,
        streaming: bool = False,
        api_key: str = "",
        model_id: str = "",
        base_url: str = "https://api.openai.com",
        model_spec: ModelSpec | None = None,
    ) -> None:
        self._transport = transport
        self._streaming = streaming
        self._api_key = api_key
        self._model_id = model_id
        self._base_url = base_url
        self.model_spec = model_spec

    def estimate_tokens(self, request: ApiRequest) -> int | None:
        return estimate_openai_request_tokens(
            request,
            serialized_messages=serialize_openai_completions_messages(request),
            serialized_tools=request.tools,
            model_id=self.model_spec.id if self.model_spec else None,
        )

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            if self._transport is not None:
                payload = await asyncio.to_thread(self._transport, request, self._streaming)
                if self._streaming:
                    assert not isinstance(payload, dict)
                    events = parse_openai_completions_stream(payload)
                else:
                    assert isinstance(payload, dict)
                    events = parse_openai_completions_batch(payload)
                for ev in events:
                    yield ev
                return

            payload = build_openai_completions_payload(
                request,
                model_id=self._model_id,
                stream=self._streaming,
            )
            url = f"{self._base_url.rstrip('/')}/v1/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key}",
            }

            if not self._streaming:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(url, json=payload, headers=headers)
                    resp.raise_for_status()
                for ev in parse_openai_completions_batch(resp.json()):
                    yield ev
                return

            text_started = False
            thinking_started = False
            tool_acc: dict[int, dict[str, Any]] = {}
            usage: TokenUsage | None = None
            model_id: str | None = None
            request_id: str | None = None
            finish_reason: StopReason | None = None

            async with httpx.AsyncClient() as client:
                async with client.stream("POST", url, json=payload, headers=headers) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        body = line[6:].strip()
                        if not body or body == "[DONE]":
                            continue
                        try:
                            chunk = json.loads(body)
                        except ValueError:
                            continue
                        if not isinstance(chunk, dict):
                            continue
                        model_id = chunk.get("model") or model_id
                        request_id = chunk.get("id") or request_id
                        choices = chunk.get("choices") or []
                        if not isinstance(choices, list):
                            continue
                        for choice in choices:
                            if not isinstance(choice, dict):
                                continue
                            if choice.get("finish_reason"):
                                finish_reason = stop_reason_from_finish(str(choice.get("finish_reason")))
                            delta = choice.get("delta") or {}
                            if not isinstance(delta, dict):
                                continue
                            reasoning = delta.get("reasoning_content")
                            if isinstance(reasoning, str) and reasoning:
                                if not thinking_started:
                                    thinking_started = True
                                    yield AssistantEvent(kind=AssistantEventKind.THINKING_START)
                                yield AssistantEvent(
                                    kind=AssistantEventKind.THINKING_DELTA,
                                    thinking_delta=reasoning,
                                )
                            content = delta.get("content")
                            if isinstance(content, str) and content:
                                if not text_started:
                                    text_started = True
                                    yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
                                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=content)
                            tool_calls = delta.get("tool_calls") or []
                            if isinstance(tool_calls, list):
                                for raw_call in tool_calls:
                                    if not isinstance(raw_call, dict):
                                        continue
                                    index = int(raw_call.get("index") or 0)
                                    current = tool_acc.setdefault(
                                        index,
                                        {"id": "", "name": "", "arguments": ""},
                                    )
                                    if raw_call.get("id"):
                                        current["id"] = str(raw_call["id"])
                                    function = raw_call.get("function") or {}
                                    if isinstance(function, dict):
                                        if function.get("name"):
                                            current["name"] = str(function["name"])
                                        partial = str(function.get("arguments") or "")
                                        if partial:
                                            current["arguments"] += partial
                                            yield AssistantEvent(
                                                kind=AssistantEventKind.TOOL_INPUT_DELTA,
                                                tool_use_id=current["id"] or f"tool-{index}",
                                                tool_name=current["name"],
                                                tool_input_delta=partial,
                                            )
                        usage = usage_from_payload(chunk) or usage

            if thinking_started:
                yield AssistantEvent(kind=AssistantEventKind.THINKING_END)
            if text_started:
                yield AssistantEvent(kind=AssistantEventKind.TEXT_END)
            for index in sorted(tool_acc.keys()):
                tool = tool_acc[index]
                yield AssistantEvent(
                    kind=AssistantEventKind.TOOL_USE,
                    tool_use_id=tool["id"] or f"tool-{index}",
                    tool_name=tool["name"],
                    tool_input=tool["arguments"] or "{}",
                )
            if usage is not None:
                yield AssistantEvent(
                    kind=AssistantEventKind.USAGE,
                    usage=usage,
                    model_id=model_id,
                    request_id=request_id,
                )
            yield AssistantEvent(
                kind=AssistantEventKind.MESSAGE_STOP,
                stop_reason=finish_reason or (StopReason.TOOL_USE if tool_acc else StopReason.STOP),
            )

        return _gen()


def openai_completions_client_factory(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    transport: TransportFn | None = None,
    **_: Any,
) -> OpenAICompletionsModelClient:
    return OpenAICompletionsModelClient(
        transport,
        streaming=streaming,
        api_key=api_key,
        model_id=spec.id,
        base_url=spec.base_url or "https://api.openai.com",
        model_spec=spec,
    )
