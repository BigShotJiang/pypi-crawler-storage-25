"""Conformance tests for provider-specific request option passthrough."""

from tada_core.contracts.model import ApiRequest
from tada_core.providers.anthropic import build_anthropic_payload
from tada_core.providers.bedrock import serialize_bedrock_request
from tada_core.providers.google import serialize_google_request
from tada_core.providers.openai_completions import build_openai_completions_payload
from tada_core.providers.openai_responses import build_openai_responses_payload


def test_api_request_preserves_generate_kwargs() -> None:
    request = ApiRequest(generate_kwargs={"temperature": 0.7})

    assert request.generate_kwargs == {"temperature": 0.7}


def test_anthropic_payload_includes_allowed_generate_kwargs() -> None:
    request = ApiRequest(
        generate_kwargs={
            "temperature": 0.7,
            "thinking": {"type": "enabled", "budget_tokens": 1024},
            "messages": ["must not override"],
        }
    )

    payload = build_anthropic_payload(
        request,
        model_id="claude-test",
        max_tokens=2048,
        streaming=False,
    )

    assert payload["temperature"] == 0.7
    assert payload["thinking"] == {"type": "enabled", "budget_tokens": 1024}
    assert payload["messages"] == []


def test_openai_completions_payload_includes_allowed_generate_kwargs() -> None:
    request = ApiRequest(
        generate_kwargs={
            "temperature": 0.7,
            "extra_body": {"enable_thinking": False},
            "tools": ["must not override"],
        }
    )

    payload = build_openai_completions_payload(request, model_id="gpt-test", stream=False)

    assert payload["temperature"] == 0.7
    assert payload["extra_body"] == {"enable_thinking": False}
    assert "tools" not in payload


def test_openai_responses_payload_includes_allowed_generate_kwargs() -> None:
    request = ApiRequest(
        generate_kwargs={
            "temperature": 0.7,
            "response_format": {"type": "json_object"},
            "input": ["must not override"],
        }
    )

    payload = build_openai_responses_payload(request, model_id="gpt-test", stream=False)

    assert payload["temperature"] == 0.7
    assert payload["response_format"] == {"type": "json_object"}
    assert payload["input"] == []


def test_google_payload_maps_generation_config() -> None:
    request = ApiRequest(
        generate_kwargs={
            "generationConfig": {"temperature": 0.7},
            "contents": ["must not override"],
        }
    )

    payload = serialize_google_request(request)

    assert payload["generationConfig"] == {"temperature": 0.7}
    assert payload["contents"] == []


def test_bedrock_payload_merges_inference_config() -> None:
    request = ApiRequest(
        generate_kwargs={
            "inferenceConfig": {"temperature": 0.7},
            "messages": ["must not override"],
        }
    )

    payload = serialize_bedrock_request(request, model_id="anthropic.claude-test")

    assert payload["inferenceConfig"] == {"temperature": 0.7}
    assert payload["messages"] == []
