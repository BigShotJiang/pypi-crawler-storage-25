import pytest

from tada_core.contracts.compaction import StructuredSummaryCompaction
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, EchoModelClient
from tada_core.contracts.session import SessionState
from tada_core.providers.anthropic import (
    apply_anthropic_cache_control,
    serialize_anthropic_messages,
    serialize_anthropic_tools,
)
from tada_core.providers.openai_completions import serialize_openai_completions_messages


class CapturingSummaryModel(EchoModelClient):
    def __init__(self) -> None:
        self.requests: list[ApiRequest] = []

    def stream(self, request: ApiRequest):
        self.requests.append(request)

        async def _gen():
            yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta="summary")
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

        return _gen()


def _state() -> SessionState:
    return SessionState(
        messages=[
            ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="old")]),
            ConversationMessage(role=MessageRole.ASSISTANT, content=[ContentBlock(type="text", text="middle")]),
            ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="new")]),
        ]
    )


@pytest.mark.asyncio
async def test_summary_request_reuses_system_tools_and_model_spec() -> None:
    model = CapturingSummaryModel()
    strategy = StructuredSummaryCompaction(model, threshold_tokens=1, keep_last=1)
    tools = [{"type": "function", "function": {"name": "search", "description": "s", "parameters": {}}}]

    await strategy.compact_async(
        _state(),
        trigger="post_llm",
        system_prompt=["main system"],
        tools=tools,
    )

    request = model.requests[0]
    assert request.system_prompt == ["main system"]
    assert request.tools == tools


@pytest.mark.asyncio
async def test_anthropic_summary_payload_still_receives_cache_markers() -> None:
    model = CapturingSummaryModel()
    strategy = StructuredSummaryCompaction(model, threshold_tokens=1, keep_last=1)
    tools = [{"type": "function", "function": {"name": "search", "description": "s", "parameters": {}}}]

    await strategy.compact_async(
        _state(),
        trigger="post_llm",
        system_prompt=["cached system"],
        tools=tools,
    )

    request = model.requests[0]
    system, messages = serialize_anthropic_messages(request)
    payload = {"system": system, "messages": messages, "tools": serialize_anthropic_tools(request.tools)}
    apply_anthropic_cache_control(payload, cache_retention="short", base_url="https://api.anthropic.com")

    assert payload["system"][-1]["cache_control"]["type"] == "ephemeral"
    assert payload["tools"][-1]["cache_control"]["type"] == "ephemeral"


@pytest.mark.asyncio
async def test_tool_result_pruning_does_not_change_tools_cache_marker() -> None:
    model = CapturingSummaryModel()
    strategy = StructuredSummaryCompaction(model, threshold_tokens=1, keep_last=1)
    tools = [{"type": "function", "function": {"name": "search", "description": "s", "parameters": {}}}]
    state = SessionState(
        messages=[
            ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="head")]),
            ConversationMessage(
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id="t1",
                        tool_name="search",
                        tool_result="x" * 5000,
                    )
                ],
            ),
            ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="tail")]),
        ]
    )

    await strategy.compact_async(
        state,
        trigger="post_llm",
        system_prompt=["cached system"],
        tools=tools,
    )

    request = model.requests[0]
    payload = {
        "system": serialize_anthropic_messages(request)[0],
        "messages": serialize_anthropic_messages(request)[1],
        "tools": serialize_anthropic_tools(request.tools),
    }
    apply_anthropic_cache_control(payload, cache_retention="short", base_url="https://api.anthropic.com")

    assert request.tools == tools
    assert payload["tools"][-1]["name"] == "search"
    assert payload["tools"][-1]["cache_control"]["type"] == "ephemeral"


@pytest.mark.asyncio
async def test_openai_summary_request_preserves_prefix_for_implicit_cache() -> None:
    model = CapturingSummaryModel()
    strategy = StructuredSummaryCompaction(model, threshold_tokens=1, keep_last=1)
    system_prompt = ["prefix system"]
    tools = [{"type": "function", "function": {"name": "search", "description": "s", "parameters": {}}}]

    await strategy.compact_async(
        _state(),
        trigger="post_llm",
        system_prompt=system_prompt,
        tools=tools,
    )

    main_request = ApiRequest(system_prompt=system_prompt, messages=[], tools=tools)
    summary_request = model.requests[0]

    assert serialize_openai_completions_messages(summary_request)[0] == serialize_openai_completions_messages(main_request)[0]
