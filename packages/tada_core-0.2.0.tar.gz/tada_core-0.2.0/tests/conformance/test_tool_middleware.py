"""Tests for chained tool middleware."""

from tada_core.contracts.tools import ChainedToolExecutor, InMemoryToolExecutor, ToolDefinition


async def test_chained_tool_executor_runs_middlewares_in_order() -> None:
    inner = InMemoryToolExecutor()
    inner.register(
        ToolDefinition(name="echo", description="Echo", parameters_schema={"type": "object"}),
        lambda input_json: f"inner:{input_json}",
    )
    seen: list[str] = []

    async def first(tool_name, input_json, on_update, next_call):
        seen.append(f"first-before:{tool_name}:{input_json}")
        result = await next_call()
        seen.append(f"first-after:{result}")
        return f"{result}:first"

    async def second(tool_name, input_json, on_update, next_call):
        seen.append(f"second-before:{tool_name}:{input_json}")
        result = await next_call()
        seen.append(f"second-after:{result}")
        return f"{result}:second"

    executor = ChainedToolExecutor(inner, [first, second])

    result = await executor.execute("echo", "{}")

    assert result == "inner:{}:second:first"
    assert seen == [
        "first-before:echo:{}",
        "second-before:echo:{}",
        "second-after:inner:{}",
        "first-after:inner:{}:second",
    ]
    assert executor.list_tools()[0].name == "echo"
