"""Offline conformance tests for OpenAI protocol adapters."""

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind, StopReason
from tada_core.providers.google import (
    parse_google_response,
    serialize_google_contents,
)
from tada_core.providers.bedrock import (
    parse_bedrock_response,
    serialize_bedrock_request,
    serialize_bedrock_messages,
)
from tada_core.providers.openai_completions import serialize_openai_completions_messages
from tada_core.providers.openai_responses import (
    parse_openai_responses_batch,
    parse_openai_responses_stream,
    serialize_openai_responses_input,
)
from tada_core.providers.registry import get_model_adapter
from tada_core.providers.openai_utils import parse_openai_completions_batch


def _req(*messages: ConversationMessage, system: list[str] | None = None) -> ApiRequest:
    return ApiRequest(system_prompt=system or [], messages=list(messages))


def test_openai_completions_serializes_tool_messages() -> None:
    tool_msg = ConversationMessage(
        role=MessageRole.TOOL,
        content=[
            ContentBlock(type="tool_result", tool_use_id="call_1", tool_result='{"ok": true}')
        ],
    )
    msgs = serialize_openai_completions_messages(_req(tool_msg))
    assert msgs[0]["role"] == "tool"
    assert msgs[0]["tool_call_id"] == "call_1"


def test_openai_completions_batch_parses_tool_use() -> None:
    payload = {
        "choices": [
            {
                "message": {
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "call_1",
                            "type": "function",
                            "function": {"name": "echo", "arguments": '{"x": 1}'},
                        }
                    ],
                },
                "finish_reason": "tool_calls",
            }
        ],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5},
    }
    events = parse_openai_completions_batch(payload)
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.TOOL_USE


def test_openai_responses_serializes_multimodal_user() -> None:
    msg = ConversationMessage(
        role=MessageRole.USER,
        content=[
            ContentBlock(type="text", text="describe"),
            ContentBlock(
                type="image",
                source="base64",
                mime_type="image/png",
                data="abc",
            ),
        ],
    )
    items = serialize_openai_responses_input(_req(msg))
    assert items[0]["role"] == "user"
    content = items[0]["content"]
    assert any(part.get("type") == "input_text" for part in content)
    assert any(part.get("type") == "input_image" for part in content)


def test_openai_responses_batch_parses_text() -> None:
    payload = {
        "output": [
            {
                "type": "message",
                "content": [{"type": "output_text", "text": "done"}],
            }
        ],
        "usage": {"input_tokens": 3, "output_tokens": 2},
        "status": "completed",
    }
    events = parse_openai_responses_batch(payload)
    assert any(e.kind == AssistantEventKind.TEXT_DELTA and e.text_delta == "done" for e in events)


def test_openai_responses_stream_emits_tool_input_delta() -> None:
    events = parse_openai_responses_stream([
        {
            "type": "response.output_item.added",
            "item": {"type": "function_call", "call_id": "call_1", "name": "echo"},
        },
        {
            "type": "response.function_call_arguments.delta",
            "call_id": "call_1",
            "delta": '{"x"',
        },
        {
            "type": "response.function_call_arguments.delta",
            "call_id": "call_1",
            "delta": ":1}",
        },
        {"type": "response.completed", "response": {"status": "completed"}},
    ])
    deltas = [e.tool_input_delta for e in events if e.kind == AssistantEventKind.TOOL_INPUT_DELTA]
    assert deltas == ['{"x"', ":1}"]
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_input == '{"x":1}'


def test_google_and_bedrock_adapters_are_registered() -> None:
    assert get_model_adapter("google-generative-ai") is not None
    assert get_model_adapter("bedrock-converse-stream") is not None


def test_google_adapter_serializes_and_parses_text() -> None:
    msg = ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text="hello")],
    )
    contents = serialize_google_contents(_req(msg))
    assert contents[0]["role"] == "user"
    assert contents[0]["parts"][0]["text"] == "hello"

    events = parse_google_response({
        "candidates": [{"content": {"parts": [{"text": "hi"}]}, "finishReason": "STOP"}],
        "usageMetadata": {"promptTokenCount": 2, "candidatesTokenCount": 1},
    })
    assert any(e.kind == AssistantEventKind.TEXT_DELTA and e.text_delta == "hi" for e in events)


def test_google_adapter_maps_cached_content_tokens() -> None:
    events = parse_google_response({
        "candidates": [{"content": {"parts": [{"text": "cached"}]}, "finishReason": "STOP"}],
        "usageMetadata": {
            "promptTokenCount": 10,
            "candidatesTokenCount": 2,
            "cachedContentTokenCount": 7,
        },
    })
    usage = next(e.usage for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage is not None
    assert usage.input_tokens == 10
    assert usage.output_tokens == 2
    assert usage.cache_read_tokens == 7


def test_bedrock_adapter_serializes_and_parses_text() -> None:
    msg = ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text="hello")],
    )
    messages = serialize_bedrock_messages(_req(msg))
    assert messages[0]["role"] == "user"
    assert messages[0]["content"][0]["text"] == "hello"

    events = parse_bedrock_response({
        "output": {"message": {"content": [{"text": "hi"}]}},
        "stopReason": "end_turn",
        "usage": {"inputTokens": 2, "outputTokens": 1},
    })
    assert any(e.kind == AssistantEventKind.TEXT_DELTA and e.text_delta == "hi" for e in events)


def test_bedrock_adapter_applies_cache_points() -> None:
    req = _req(
        ConversationMessage(
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="first")],
        ),
        ConversationMessage(
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="second")],
        ),
        system=["system prompt"],
    )
    req.tools = [
        {
            "type": "function",
            "function": {
                "name": "echo",
                "description": "echo",
                "parameters": {"type": "object"},
            },
        }
    ]
    payload = serialize_bedrock_request(
        req,
        model_id="anthropic.claude-3-5-sonnet-20241022-v2:0",
        cache_retention="long",
    )

    cache_point = {"cachePoint": {"type": "default", "ttl": "1h"}}
    assert payload["system"][-1] == cache_point
    assert payload["toolConfig"]["tools"][-1] == cache_point
    user_messages = [m for m in payload["messages"] if m["role"] == "user"]
    assert user_messages[-2]["content"][-1] == cache_point
    assert user_messages[-1]["content"][-1] == cache_point


def test_bedrock_adapter_maps_cache_usage() -> None:
    events = parse_bedrock_response({
        "output": {"message": {"content": [{"text": "hi"}]}},
        "usage": {
            "inputTokens": 2,
            "outputTokens": 1,
            "cacheReadInputTokens": 7,
            "cacheWriteInputTokens": 9,
        },
    })
    usage = next(e.usage for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage is not None
    assert usage.cache_read_tokens == 7
    assert usage.cache_creation_tokens == 9
