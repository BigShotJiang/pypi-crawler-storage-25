"""Offline conformance tests for the Google Generative Language adapter."""

import asyncio
import json

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind, StopReason
from tada_core.providers.google import GoogleGenerativeAIModelClient


def _req(*messages: ConversationMessage) -> ApiRequest:
    return ApiRequest(messages=list(messages))


def _user(text: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text=text)],
    )


def test_google_client_streams_text_deltas_incrementally() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {
                    "candidates": [
                        {
                            "content": {"parts": [{"text": "hel"}]},
                            "finishReason": None,
                        }
                    ],
                    "modelVersion": "gemini-test",
                },
                {
                    "candidates": [
                        {
                            "content": {"parts": [{"text": "lo"}]},
                            "finishReason": "STOP",
                        }
                    ],
                    "usageMetadata": {
                        "promptTokenCount": 4,
                        "candidatesTokenCount": 2,
                        "cachedContentTokenCount": 1,
                    },
                    "responseId": "resp-1",
                },
            ]
        )

    client = GoogleGenerativeAIModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["hel", "lo"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 4
    assert usage.usage.cache_read_tokens == 1
    assert usage.request_id == "resp-1"


def test_google_client_streams_function_call() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {
                    "candidates": [
                        {
                            "content": {
                                "parts": [
                                    {"functionCall": {"name": "echo", "args": {"x": 1}}}
                                ]
                            },
                            "finishReason": "STOP",
                        }
                    ]
                }
            ]
        )

    client = GoogleGenerativeAIModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.STOP


def test_google_default_httpx_stream_path_parses_sse_lines() -> None:
    import httpx

    body = "\n".join(
        [
            'data: {"candidates":[{"content":{"parts":[{"text":"he"}]}}]}',
            "",
            'data: {"candidates":[{"content":{"parts":[{"text":"llo"}]},"finishReason":"STOP"}],"usageMetadata":{"promptTokenCount":4,"candidatesTokenCount":2},"responseId":"resp-1"}',
            "",
        ]
    )

    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url).endswith(":streamGenerateContent?alt=sse&key=test-key")
        return httpx.Response(
            200,
            content=(body + "\n").encode(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    original_init = httpx.AsyncClient.__init__

    def patched_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        kwargs["transport"] = transport
        original_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = patched_init  # type: ignore[method-assign]
    try:
        client = GoogleGenerativeAIModelClient(
            None,
            streaming=True,
            api_key="test-key",
            model_id="models/gemini-test",
            base_url="https://example.invalid",
        )

        async def collect() -> list:
            events = []
            async for event in client.stream(_req(_user("hi"))):
                events.append(event)
            return events

        events = asyncio.run(collect())
    finally:
        httpx.AsyncClient.__init__ = original_init  # type: ignore[method-assign]

    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["he", "llo"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.request_id == "resp-1"
