"""Offline conformance tests for the OpenAI Chat Completions adapter."""

import asyncio
import json

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind, StopReason
from tada_core.providers.openai_completions import (
    OpenAICompletionsModelClient,
    serialize_openai_completions_messages,
)
from tada_core.providers.openai_utils import (
    parse_openai_completions_batch,
    parse_openai_completions_stream,
)


def _req(*messages: ConversationMessage) -> ApiRequest:
    return ApiRequest(messages=list(messages))


def _user(text: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text=text)],
    )


def test_openai_completions_serializes_thinking_to_reasoning_content() -> None:
    assistant = ConversationMessage(
        role=MessageRole.ASSISTANT,
        content=[
            ContentBlock(type="thinking", thinking="reasoning"),
            ContentBlock(type="text", text="answer"),
        ],
    )

    messages = serialize_openai_completions_messages(_req(_user("q"), assistant))

    assert messages[1]["role"] == "assistant"
    assert messages[1]["content"] == "answer"
    assert messages[1]["reasoning_content"] == "reasoning"


def test_openai_completions_batch_parses_reasoning_content() -> None:
    events = parse_openai_completions_batch(
        {
            "id": "chatcmpl-1",
            "model": "deepseek-reasoner",
            "choices": [
                {
                    "message": {
                        "reasoning_content": "think",
                        "content": "done",
                    },
                    "finish_reason": "stop",
                }
            ],
        }
    )

    assert [e.kind for e in events[:4]] == [
        AssistantEventKind.THINKING_START,
        AssistantEventKind.THINKING_DELTA,
        AssistantEventKind.THINKING_END,
        AssistantEventKind.TEXT_START,
    ]
    thinking = next(e for e in events if e.kind == AssistantEventKind.THINKING_DELTA)
    assert thinking.thinking_delta == "think"


def test_openai_completions_buffered_stream_parses_reasoning_content() -> None:
    events = parse_openai_completions_stream(
        [
            {
                "id": "chatcmpl-1",
                "model": "deepseek-reasoner",
                "choices": [{"delta": {"reasoning_content": "a "}}],
            },
            {
                "id": "chatcmpl-1",
                "model": "deepseek-reasoner",
                "choices": [{"delta": {"reasoning_content": "b"}}],
            },
            {"choices": [{"delta": {"content": "done"}, "finish_reason": "stop"}]},
        ]
    )

    assert [e.thinking_delta for e in events if e.kind == AssistantEventKind.THINKING_DELTA] == [
        "a ",
        "b",
    ]
    text = next(e for e in events if e.kind == AssistantEventKind.TEXT_DELTA)
    assert text.text_delta == "done"


def test_openai_completions_client_streams_reasoning_text_and_tool_deltas() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {
                    "id": "chatcmpl-1",
                    "model": "deepseek-reasoner",
                    "choices": [{"delta": {"reasoning_content": "think "}}],
                },
                {"choices": [{"delta": {"reasoning_content": "more"}}]},
                {"choices": [{"delta": {"content": "he"}}]},
                {"choices": [{"delta": {"content": "llo"}}]},
                {
                    "choices": [
                        {
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "id": "call_1",
                                        "function": {"name": "echo", "arguments": '{"x"'},
                                    }
                                ]
                            }
                        }
                    ]
                },
                {
                    "choices": [
                        {
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "function": {"arguments": ":1}"},
                                    }
                                ]
                            },
                            "finish_reason": "tool_calls",
                        }
                    ],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 4},
                },
            ]
        )

    client = OpenAICompletionsModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    assert [e.thinking_delta for e in events if e.kind == AssistantEventKind.THINKING_DELTA] == [
        "think ",
        "more",
    ]
    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["he", "llo"]
    assert [e.tool_input_delta for e in events if e.kind == AssistantEventKind.TOOL_INPUT_DELTA] == [
        '{"x"',
        ":1}",
    ]
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.TOOL_USE


def test_openai_completions_default_httpx_stream_path_parses_sse_lines() -> None:
    import httpx

    body = "\n".join(
        [
            'data: {"id":"chatcmpl-1","model":"deepseek-reasoner","choices":[{"delta":{"reasoning_content":"think"}}]}',
            "",
            'data: {"id":"chatcmpl-1","model":"deepseek-reasoner","choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":1}}',
            "",
            "data: [DONE]",
            "",
        ]
    )

    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == "https://example.invalid/v1/chat/completions"
        assert request.headers["authorization"] == "Bearer test-key"
        return httpx.Response(
            200,
            content=(body + "\n").encode(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    original_init = httpx.AsyncClient.__init__

    def patched_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        kwargs["transport"] = transport
        original_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = patched_init  # type: ignore[method-assign]
    try:
        client = OpenAICompletionsModelClient(
            None,
            streaming=True,
            api_key="test-key",
            model_id="deepseek-reasoner",
            base_url="https://example.invalid",
        )

        async def collect() -> list:
            events = []
            async for event in client.stream(_req(_user("hi"))):
                events.append(event)
            return events

        events = asyncio.run(collect())
    finally:
        httpx.AsyncClient.__init__ = original_init  # type: ignore[method-assign]

    assert [e.thinking_delta for e in events if e.kind == AssistantEventKind.THINKING_DELTA] == ["think"]
    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["ok"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 3
