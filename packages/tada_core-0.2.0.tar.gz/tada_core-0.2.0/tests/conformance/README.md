# Conformance Tests

这组测试只负责 **contracts / AgentLoop / ModelClient** 的一致性，不负责上层产品接入。

## 属于这里的内容

- `AgentLoop.run_turn()` 的事件语义
- `SessionState` 的稳定序列化语义
- hook / permission / tool / compaction / steering / loop exit 的 contracts 级不变量
- `AnthropicModelClient` 与 OpenAI-compatible 测试客户端的协议转换行为

## 不属于这里的内容

以下内容应放在具体宿主应用仓库中测试：

- `AgentRequest -> SessionState` 映射
- `Event -> Msg` 翻译
- `runner.stream_query()` 集成
- channels / websocket / app lifecycle

## 当前结构

- `fixtures.py`: shared test helpers
- `test_agent_loop.py`: `AgentLoop` 主路径，覆盖 text、tools、permissions、hooks、compaction、parallel tools、steering、loop exit、abort
- `test_anthropic_client.py`: Anthropic Messages API 序列化、cache control 与流式解析
- `test_clawcode_model_client.py`: OpenAI-compatible 客户端解析
- `test_event_sequences.py`: golden event sequence，覆盖 text-only、tool roundtrip、permission deny、hook updated input
- `test_contract_semantics.py`: contracts 级不变量
- `../test_public_api.py`: 顶层 public API 与 multimodal 内容块校验

## 验证命令

```bash
uv run pytest tests/
uv run ruff check tada_core tests scripts
```

## 未来矩阵方向

如果后续重新引入 provider registry、capability matrix 或 subagent contract，应新增对应 conformance matrix。新增时需要先定义真实 contract，再把 `UnsupportedEvent` 语义和 provider 可用性纳入测试，不能只在文档里声明。
