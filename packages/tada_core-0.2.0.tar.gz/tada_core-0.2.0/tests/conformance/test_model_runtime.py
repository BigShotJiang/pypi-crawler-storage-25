"""Tests for ModelSpec, adapter registry, and extended contracts."""

import pytest

from tada_core import ModelSpec, build_model_client
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import AssistantEvent, AssistantEventKind, StopReason
from tada_core.loop import AgentLoop, AnthropicModelClient
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport
from tada_core.providers.anthropic import parse_anthropic_response, serialize_anthropic_messages
from tada_core.providers.openai_responses import parse_openai_responses_batch
from tada_core.providers.registry import get_model_adapter
from tada_core.contracts.model import ApiRequest
from tada_core.contracts.session import SessionState


def test_model_spec_supports_input() -> None:
    spec = ModelSpec(id="gpt-4o", provider="openai", api="openai-responses", input=["text", "image"])
    assert spec.supports_input("text")
    assert spec.supports_input("image")
    assert not spec.supports_input("file")


def test_registry_has_builtin_adapters() -> None:
    assert get_model_adapter("anthropic-messages") is not None
    assert get_model_adapter("openai-completions") is not None
    assert get_model_adapter("openai-responses") is not None


def test_build_model_client_anthropic() -> None:
    spec = ModelSpec(
        id="claude-sonnet-4-6",
        provider="anthropic",
        api="anthropic-messages",
        base_url="https://api.anthropic.com",
    )
    client = build_model_client(spec, api_key="test-key", streaming=False)
    assert isinstance(client, AnthropicModelClient)


def test_thinking_block_serialization() -> None:
    msg = ConversationMessage(
        role=MessageRole.ASSISTANT,
        content=[ContentBlock(type="thinking", thinking="planning...")],
    )
    _, msgs = serialize_anthropic_messages(ApiRequest(messages=[msg]))
    assert msgs[0]["content"][0]["type"] == "thinking"


def test_anthropic_response_parses_thinking_and_stop_reason() -> None:
    payload = {
        "content": [
            {"type": "thinking", "thinking": "hmm"},
            {"type": "text", "text": "answer"},
        ],
        "stop_reason": "end_turn",
        "usage": {"input_tokens": 1, "output_tokens": 2},
    }
    events = parse_anthropic_response(payload)
    kinds = [e.kind for e in events]
    assert AssistantEventKind.THINKING_START in kinds
    assert AssistantEventKind.TEXT_DELTA in kinds
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.STOP


def test_openai_responses_batch_parsing() -> None:
    payload = {
        "output": [
            {
                "type": "message",
                "content": [{"type": "output_text", "text": "hello"}],
            }
        ],
        "usage": {"input_tokens": 5, "output_tokens": 3},
        "status": "completed",
    }
    events = parse_openai_responses_batch(payload)
    assert any(e.kind == AssistantEventKind.TEXT_DELTA for e in events)


@pytest.mark.asyncio
async def test_run_turn_message_multimodal() -> None:
    loop = AgentLoop(OpenAICompatibleModelClient(make_echo_transport(), streaming=True))
    state = SessionState()
    msg = ConversationMessage(
        role=MessageRole.USER,
        content=[
            ContentBlock(type="text", text="describe"),
            ContentBlock(
                type="image",
                source="base64",
                mime_type="image/png",
                data="abc",
            ),
        ],
    )
    events = []
    async for ev in loop.run_turn_message(state, msg):
        events.append(ev)
    assert any(ev.type == "text_delta" for ev in events)
    assert state.messages[0].content[1].type == "image"


@pytest.mark.asyncio
async def test_continue_turn_from_tool_result() -> None:
    from tada_core.contracts.model import EchoModelClient

    loop = AgentLoop(EchoModelClient())
    state = SessionState(
        messages=[
            ConversationMessage(
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id="t1",
                        tool_result="ok",
                    )
                ],
            )
        ]
    )
    events = []
    async for ev in loop.continue_turn(state):
        events.append(ev)
    assert any(ev.type == "turn_end" for ev in events)
    assert state.messages[-1].role == MessageRole.ASSISTANT


@pytest.mark.asyncio
async def test_model_spec_metadata_is_persisted_on_assistant_message() -> None:
    spec = ModelSpec(
        id="gpt-4.1-mini",
        provider="openai",
        api="openai-completions",
        base_url="https://api.openai.com",
    )
    client = build_model_client(
        spec,
        api_key="test-key",
        streaming=True,
        transport=make_echo_transport(),
    )
    loop = AgentLoop(client)
    state = SessionState()

    async for _ in loop.run_turn(state, "hello"):
        pass

    assistant = state.messages[-1]
    assert assistant.role == MessageRole.ASSISTANT
    assert assistant.provider == "openai"
    assert assistant.api == "openai-completions"
    assert assistant.model == "gpt-4.1-mini"


@pytest.mark.asyncio
async def test_budget_limit_emits_error_when_usage_exceeds_total_tokens() -> None:
    from tada_core.contracts.budget import BudgetLimits

    class UsageHeavyModel:
        def stream(self, request: ApiRequest):
            async def _gen():
                yield AssistantEvent(
                    kind=AssistantEventKind.USAGE,
                    usage=SessionState().usage.model_copy(update={"input_tokens": 2}),
                )
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=StopReason.STOP)

            return _gen()

    loop = AgentLoop(UsageHeavyModel())
    loop.set_budget_policy(BudgetLimits(max_total_tokens=1))
    state = SessionState()
    events = []

    async for ev in loop.run_turn(state, "hello"):
        events.append(ev)

    assert any(ev.type == "error" and ev.code == "budget_exceeded" for ev in events)


@pytest.mark.asyncio
async def test_usage_event_includes_model_and_request_ids() -> None:
    from tada_core.contracts.session import TokenUsage

    class UsageModel:
        def stream(self, request: ApiRequest):
            async def _gen():
                yield AssistantEvent(
                    kind=AssistantEventKind.USAGE,
                    usage=TokenUsage(input_tokens=2, output_tokens=1),
                    model_id="model-1",
                    request_id="req-1",
                )
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP, stop_reason=StopReason.STOP)

            return _gen()

    loop = AgentLoop(UsageModel())
    state = SessionState()
    events = []

    async for ev in loop.run_turn(state, "hello"):
        events.append(ev)

    usage_event = next(ev for ev in events if ev.type == "usage")
    assert usage_event.model_id == "model-1"
    assert usage_event.request_id == "req-1"
