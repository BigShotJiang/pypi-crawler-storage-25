"""Unit tests for AnthropicModelClient message serialization and response parsing.

All tests are offline — no API key required.
"""

import json

import pytest

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind
from tada_core.loop.model_client import (
    _apply_anthropic_cache_control,
    _parse_anthropic_response,
    _parse_anthropic_stream,
    _serialize_anthropic_messages,
    _serialize_anthropic_tools,
)
from tada_core.providers.anthropic import _cache_control_for_retention


def _req(*messages: ConversationMessage, system: list[str] | None = None) -> ApiRequest:
    return ApiRequest(system_prompt=system or [], messages=list(messages))


def _user(text: str) -> ConversationMessage:
    return ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text=text)])


def _assistant_text(text: str) -> ConversationMessage:
    return ConversationMessage(role=MessageRole.ASSISTANT, content=[ContentBlock(type="text", text=text)])


def _assistant_tool(tid: str, name: str, inp: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.ASSISTANT,
        content=[ContentBlock(type="tool_use", tool_use_id=tid, tool_name=name, tool_input=inp)],
    )


def _tool_result(tid: str, result: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.TOOL,
        content=[ContentBlock(type="tool_result", tool_use_id=tid, tool_result=result)],
    )


# ── Serialization ──────────────────────────────────────────────────────────────

def test_system_extracted_separately() -> None:
    system, msgs = _serialize_anthropic_messages(
        _req(_user("hi"), system=["Be helpful.", "Stay concise."])
    )
    assert system == "Be helpful.\n\nStay concise."
    assert msgs[0]["role"] == "user"


def test_user_text_block() -> None:
    _, msgs = _serialize_anthropic_messages(_req(_user("hello")))
    assert msgs == [{"role": "user", "content": [{"type": "text", "text": "hello"}]}]


def test_user_image_block_serializes_to_anthropic_image() -> None:
    _, msgs = _serialize_anthropic_messages(
        _req(
            ConversationMessage(
                role=MessageRole.USER,
                content=[
                    ContentBlock(
                        type="image",
                        source="base64",
                        mime_type="image/png",
                        data="iVBORw0KGgo=",
                    )
                ],
            )
        )
    )
    assert msgs == [
        {
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/png",
                        "data": "iVBORw0KGgo=",
                    },
                }
            ],
        }
    ]


def test_pdf_file_block_serializes_to_anthropic_document() -> None:
    _, msgs = _serialize_anthropic_messages(
        _req(
            ConversationMessage(
                role=MessageRole.USER,
                content=[
                    ContentBlock(
                        type="file",
                        source="base64",
                        mime_type="application/pdf",
                        data="JVBERi0xLjQ=",
                        name="brief.pdf",
                    )
                ],
            )
        )
    )
    assert msgs[0]["content"] == [
        {
            "type": "document",
            "source": {
                "type": "base64",
                "media_type": "application/pdf",
                "data": "JVBERi0xLjQ=",
            },
            "title": "brief.pdf",
        }
    ]


def test_unsupported_file_block_raises_clear_error() -> None:
    with pytest.raises(ValueError, match="Unsupported file mime_type"):
        _serialize_anthropic_messages(
            _req(
                ConversationMessage(
                    role=MessageRole.USER,
                    content=[
                        ContentBlock(
                            type="file",
                            source="base64",
                            mime_type="video/mp4",
                            data="AAAA",
                        )
                    ],
                )
            )
        )


def test_assistant_text_block() -> None:
    _, msgs = _serialize_anthropic_messages(_req(_user("q"), _assistant_text("a")))
    assert msgs[1] == {"role": "assistant", "content": [{"type": "text", "text": "a"}]}


def test_tool_use_block_in_assistant() -> None:
    _, msgs = _serialize_anthropic_messages(
        _req(_user("go"), _assistant_tool("t1", "echo", '{"x":1}'))
    )
    blk = msgs[1]["content"][0]
    assert blk["type"] == "tool_use"
    assert blk["id"] == "t1"
    assert blk["name"] == "echo"
    assert blk["input"] == {"x": 1}


def test_tool_result_merged_into_user_message() -> None:
    _, msgs = _serialize_anthropic_messages(
        _req(_user("go"), _assistant_tool("t1", "echo", "{}"), _tool_result("t1", "ok"))
    )
    # tool_result must appear as a user-role message
    last = msgs[-1]
    assert last["role"] == "user"
    assert any(b.get("type") == "tool_result" and b.get("tool_use_id") == "t1" for b in last["content"])


def test_tool_result_text_content_wrapped_as_typed_block() -> None:
    """Anthropic Messages API requires tool_result.content list entries to be
    typed blocks ({"type": "text", "text": ...}). Bare strings inside the
    list are rejected by both api.anthropic.com and stricter proxies
    (e.g. token-router) with HTTP 400.
    """
    _, msgs = _serialize_anthropic_messages(
        _req(_user("go"), _assistant_tool("t1", "echo", "{}"), _tool_result("t1", "hello world"))
    )
    last = msgs[-1]
    tr = next(b for b in last["content"] if b.get("type") == "tool_result")
    content = tr["content"]
    assert isinstance(content, list)
    for entry in content:
        assert isinstance(entry, dict), f"bare string in tool_result.content: {entry!r}"
        assert "type" in entry
    assert any(
        entry.get("type") == "text" and entry.get("text") == "hello world"
        for entry in content
    )


def test_tool_result_nested_text_and_image_blocks_round_trip() -> None:
    tool_result = ConversationMessage(
        role=MessageRole.TOOL,
        content=[
            ContentBlock(
                type="tool_result",
                tool_use_id="t1",
                extra={
                    "content_blocks": [
                        {"type": "text", "text": "hello"},
                        {
                            "type": "image",
                            "source": "base64",
                            "mime_type": "image/png",
                            "data": "abc",
                        },
                    ]
                },
            )
        ],
    )
    _, msgs = _serialize_anthropic_messages(
        _req(_user("go"), _assistant_tool("t1", "echo", "{}"), tool_result)
    )

    tr = next(b for b in msgs[-1]["content"] if b.get("type") == "tool_result")
    assert tr["content"] == [
        {"type": "text", "text": "hello"},
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": "image/png",
                "data": "abc",
            },
        },
    ]


def test_multiple_tool_results_merged_into_one_user_turn() -> None:
    """Consecutive TOOL messages are merged into a single user-role message."""
    t2 = ConversationMessage(
        role=MessageRole.TOOL,
        content=[ContentBlock(type="tool_result", tool_use_id="t2", tool_result="r2")],
    )
    _, msgs = _serialize_anthropic_messages(
        _req(
            _user("go"),
            _assistant_tool("t1", "echo", "{}"),
            _tool_result("t1", "r1"),
            t2,
        )
    )
    user_msgs = [m for m in msgs if m["role"] == "user"]
    # Both tool_results should end up in the same user turn
    assert len(user_msgs) == 2  # original user "go" + merged tool-results turn
    tool_result_turn = user_msgs[-1]
    ids = [b.get("tool_use_id") for b in tool_result_turn["content"] if isinstance(b, dict)]
    assert "t1" in ids and "t2" in ids


def test_serialize_anthropic_tools() -> None:
    tools = [
        {
            "type": "function",
            "function": {
                "name": "echo",
                "description": "echo input",
                "parameters": {"type": "object", "properties": {}},
            },
        }
    ]
    result = _serialize_anthropic_tools(tools)
    assert result == [
        {
            "name": "echo",
            "description": "echo input",
            "input_schema": {"type": "object", "properties": {}},
        }
    ]


def _count_cache_control(value: object) -> int:
    if isinstance(value, dict):
        return int("cache_control" in value) + sum(_count_cache_control(v) for v in value.values())
    if isinstance(value, list):
        return sum(_count_cache_control(v) for v in value)
    return 0


def test_cache_retention_long_only_emits_ttl_for_official_anthropic_url() -> None:
    assert _cache_control_for_retention("long", "https://api.anthropic.com") == {
        "type": "ephemeral",
        "ttl": "1h",
    }
    assert _cache_control_for_retention("long", "http://localhost:8787") == {
        "type": "ephemeral"
    }
    assert _cache_control_for_retention("none", "https://api.anthropic.com") is None


def test_cache_retention_long_can_be_forced_for_proxy_url() -> None:
    assert _cache_control_for_retention(
        "long",
        "http://localhost:8787",
        force_long=True,
    ) == {"type": "ephemeral", "ttl": "1h"}


def test_cache_control_marks_system_tools_and_last_two_user_turns() -> None:
    payload = {
        "system": "system prompt",
        "messages": [
            {"role": "user", "content": [{"type": "text", "text": "first"}]},
            {"role": "assistant", "content": [{"type": "text", "text": "answer"}]},
            {"role": "user", "content": [{"type": "text", "text": "second"}]},
            {"role": "user", "content": [{"type": "text", "text": "third"}]},
        ],
        "tools": [
            {"name": "echo", "description": "echo", "input_schema": {"type": "object"}},
            {"name": "other", "description": "other", "input_schema": {"type": "object"}},
        ],
    }
    _apply_anthropic_cache_control(payload, cache_retention="short", base_url="http://localhost:8787")

    assert payload["system"] == [
        {
            "type": "text",
            "text": "system prompt",
            "cache_control": {"type": "ephemeral"},
        }
    ]
    assert payload["tools"][-1]["cache_control"] == {"type": "ephemeral"}
    assert payload["messages"][2]["content"][-1]["cache_control"] == {"type": "ephemeral"}
    assert payload["messages"][3]["content"][-1]["cache_control"] == {"type": "ephemeral"}
    assert _count_cache_control(payload) <= 4


def test_cache_control_none_leaves_payload_unchanged() -> None:
    payload = {
        "messages": [{"role": "user", "content": [{"type": "text", "text": "hello"}]}]
    }
    _apply_anthropic_cache_control(payload, cache_retention="none", base_url="https://api.anthropic.com")
    assert _count_cache_control(payload) == 0


def test_cache_control_can_mark_image_last_block() -> None:
    payload = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "describe"},
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": "iVBORw0KGgo=",
                        },
                    },
                ],
            }
        ]
    }
    _apply_anthropic_cache_control(payload, cache_retention="short", base_url="http://localhost:8787")
    assert payload["messages"][0]["content"][-1]["cache_control"] == {"type": "ephemeral"}


# ── Response parsing ───────────────────────────────────────────────────────────

def test_parse_anthropic_response_text() -> None:
    payload = {
        "content": [{"type": "text", "text": "hello"}],
        "usage": {
            "input_tokens": 10,
            "output_tokens": 5,
            "cache_read_input_tokens": 3,
            "cache_creation_input_tokens": 7,
        },
    }
    events = _parse_anthropic_response(payload)
    assert any(e.kind == AssistantEventKind.TEXT_DELTA and e.text_delta == "hello" for e in events)
    usage = [e for e in events if e.kind == AssistantEventKind.USAGE]
    assert usage and usage[0].usage.input_tokens == 10
    assert usage[0].usage.cache_read_tokens == 3
    assert usage[0].usage.cache_creation_tokens == 7


def test_parse_anthropic_response_tool_use() -> None:
    payload = {
        "content": [{"type": "tool_use", "id": "t1", "name": "echo", "input": {"x": 1}}],
    }
    events = _parse_anthropic_response(payload)
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_use_id == "t1"
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}


def test_parse_anthropic_stream_text() -> None:
    chunks = [
        {"type": "message_start", "message": {"usage": {
            "input_tokens": 8,
            "cache_read_input_tokens": 4,
            "cache_creation_input_tokens": 6,
        }}},
        {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
        {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "hel"}},
        {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "lo"}},
        {"type": "message_delta", "usage": {"output_tokens": 3}},
    ]
    events = _parse_anthropic_stream(chunks)
    text = next(e for e in events if e.kind == AssistantEventKind.TEXT_DELTA)
    assert text.text_delta == "hello"
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 8
    assert usage.usage.output_tokens == 3
    assert usage.usage.cache_read_tokens == 4
    assert usage.usage.cache_creation_tokens == 6


def test_parse_anthropic_stream_tool_use() -> None:
    chunks = [
        {"type": "content_block_start", "index": 0,
         "content_block": {"type": "tool_use", "id": "t1", "name": "echo"}},
        {"type": "content_block_delta", "index": 0,
         "delta": {"type": "input_json_delta", "partial_json": '{"x":'}},
        {"type": "content_block_delta", "index": 0,
         "delta": {"type": "input_json_delta", "partial_json": "1}"}},
    ]
    events = _parse_anthropic_stream(chunks)
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}


def test_parse_anthropic_stream_captures_thinking_signature() -> None:
    """Extended-thinking emits a separate signature_delta per content block.
    The signature MUST be carried on THINKING_END so AgentLoop can attach it
    to ContentBlock.signature — without it Claude rejects any later turn
    that includes the thinking block with HTTP 400.
    """
    chunks = [
        {"type": "content_block_start", "index": 0,
         "content_block": {"type": "thinking", "thinking": ""}},
        {"type": "content_block_delta", "index": 0,
         "delta": {"type": "thinking_delta", "thinking": "step1 "}},
        {"type": "content_block_delta", "index": 0,
         "delta": {"type": "thinking_delta", "thinking": "step2"}},
        {"type": "content_block_delta", "index": 0,
         "delta": {"type": "signature_delta", "signature": "sig-abc"}},
        {"type": "content_block_stop", "index": 0},
    ]
    events = _parse_anthropic_stream(chunks)
    ends = [e for e in events if e.kind == AssistantEventKind.THINKING_END]
    assert len(ends) == 1
    assert ends[0].thinking_signature == "sig-abc"
    assert ends[0].thinking_delta == "step1 step2"


def test_parse_anthropic_response_captures_thinking_signature() -> None:
    payload = {
        "content": [
            {"type": "thinking", "thinking": "abc", "signature": "sig-xyz"},
        ],
    }
    events = _parse_anthropic_response(payload)
    ends = [e for e in events if e.kind == AssistantEventKind.THINKING_END]
    assert len(ends) == 1
    assert ends[0].thinking_signature == "sig-xyz"


def test_anthropic_client_streams_text_deltas_incrementally() -> None:
    """``AnthropicModelClient.stream()`` must emit each ``text_delta`` chunk
    as it arrives — not buffer the whole SSE stream and replay it after
    ``aread()`` completes. The earlier buffered-replay implementation made
    the entire reply appear in one shot at the end of the turn, which the
    user perceived as "no streaming".
    """
    import asyncio

    import httpx

    from tada_core import AnthropicModelClient
    from tada_core.contracts.model import AssistantEventKind

    def _sse_body() -> bytes:
        lines = [
            'event: message_start',
            'data: {"type":"message_start","message":{"id":"msg_1","model":"claude-x","usage":{"input_tokens":5}}}',
            '',
            'event: content_block_start',
            'data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}',
            '',
            'event: content_block_delta',
            'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"hel"}}',
            '',
            'event: content_block_delta',
            'data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"lo"}}',
            '',
            'event: content_block_stop',
            'data: {"type":"content_block_stop","index":0}',
            '',
            'event: message_delta',
            'data: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":2}}',
            '',
            'event: message_stop',
            'data: {"type":"message_stop"}',
            '',
        ]
        return ("\n".join(lines) + "\n").encode("utf-8")

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            content=_sse_body(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)

    # Monkey-patch httpx.AsyncClient to inject our transport for this test.
    original_init = httpx.AsyncClient.__init__

    def patched_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        kwargs["transport"] = transport
        original_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = patched_init  # type: ignore[method-assign]
    try:
        client = AnthropicModelClient(
            api_key="test",
            model="claude-test",
            base_url="https://example.invalid",
            streaming=True,
        )

        async def _collect() -> list:
            req = ApiRequest(messages=[_user("hi")])
            out = []
            async for ev in client.stream(req):
                out.append(ev)
            return out

        events = asyncio.run(_collect())
    finally:
        httpx.AsyncClient.__init__ = original_init  # type: ignore[method-assign]

    # Must see TEXT_START followed by 2 *separate* TEXT_DELTAs — not one
    # combined delta with "hello". This guards the per-chunk emission.
    kinds = [e.kind for e in events]
    assert AssistantEventKind.TEXT_START in kinds
    text_deltas = [e for e in events if e.kind == AssistantEventKind.TEXT_DELTA]
    assert [d.text_delta for d in text_deltas] == ["hel", "lo"]
    assert AssistantEventKind.TEXT_END in kinds

    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 5
    assert usage.usage.output_tokens == 2

    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason is not None


def test_thinking_block_signature_round_trips_through_serialization() -> None:
    """End-to-end: a thinking ContentBlock carrying a signature must be
    serialized as ``{"type":"thinking","thinking":"...","signature":"..."}``
    so the Anthropic Messages API accepts the next turn. Without the
    signature the API returns 400.
    """
    history_assistant = ConversationMessage(
        role=MessageRole.ASSISTANT,
        content=[
            ContentBlock(
                type="thinking",
                thinking="reasoning chain",
                signature="sig-roundtrip",
            ),
            ContentBlock(type="text", text="hi"),
        ],
    )
    _, msgs = _serialize_anthropic_messages(_req(_user("ping"), history_assistant))
    assistant_msg = msgs[1]
    assert assistant_msg["role"] == "assistant"
    thinking_block = next(
        b for b in assistant_msg["content"] if b.get("type") == "thinking"
    )
    assert thinking_block["thinking"] == "reasoning chain"
    assert thinking_block["signature"] == "sig-roundtrip"
