"""Offline conformance tests for the Bedrock Converse adapter."""

import asyncio
import json

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind, StopReason
from tada_core.providers.bedrock import (
    BedrockConverseModelClient,
    parse_bedrock_response,
    parse_bedrock_stream,
    serialize_bedrock_messages,
)


def _req(*messages: ConversationMessage) -> ApiRequest:
    return ApiRequest(messages=list(messages))


def _user(text: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text=text)],
    )


def test_bedrock_serializes_thinking_block_with_signature() -> None:
    assistant = ConversationMessage(
        role=MessageRole.ASSISTANT,
        content=[
            ContentBlock(
                type="thinking",
                thinking="private reasoning",
                signature="sig-bedrock",
            ),
            ContentBlock(type="text", text="answer"),
        ],
    )

    messages = serialize_bedrock_messages(_req(_user("q"), assistant))

    reasoning = messages[1]["content"][0]["reasoningContent"]["reasoningText"]
    assert reasoning == {"text": "private reasoning", "signature": "sig-bedrock"}


def test_bedrock_parses_reasoning_content_signature_from_batch_response() -> None:
    events = parse_bedrock_response(
        {
            "output": {
                "message": {
                    "content": [
                        {
                            "reasoningContent": {
                                "reasoningText": {
                                    "text": "think",
                                    "signature": "sig-batch",
                                }
                            }
                        },
                        {"text": "done"},
                    ]
                }
            },
            "stopReason": "end_turn",
        }
    )

    assert [e.kind for e in events[:4]] == [
        AssistantEventKind.THINKING_START,
        AssistantEventKind.THINKING_DELTA,
        AssistantEventKind.THINKING_END,
        AssistantEventKind.TEXT_START,
    ]
    thinking_end = next(e for e in events if e.kind == AssistantEventKind.THINKING_END)
    assert thinking_end.thinking_delta == "think"
    assert thinking_end.thinking_signature == "sig-batch"


def test_bedrock_buffered_stream_parses_reasoning_content_signature() -> None:
    events = parse_bedrock_stream(
        [
            {
                "contentBlockDelta": {
                    "contentBlockIndex": 0,
                    "delta": {"reasoningContent": {"text": "a "}},
                }
            },
            {
                "contentBlockDelta": {
                    "contentBlockIndex": 0,
                    "delta": {"reasoningContent": {"text": "b"}},
                }
            },
            {
                "contentBlockDelta": {
                    "contentBlockIndex": 0,
                    "delta": {"reasoningContent": {"signature": "sig-stream"}},
                }
            },
            {"contentBlockStop": {"contentBlockIndex": 0}},
        ]
    )

    thinking_end = next(e for e in events if e.kind == AssistantEventKind.THINKING_END)
    assert thinking_end.thinking_delta == "a b"
    assert thinking_end.thinking_signature == "sig-stream"


def test_bedrock_tool_result_serializes_nested_text_and_image_blocks() -> None:
    tool_result = ConversationMessage(
        role=MessageRole.TOOL,
        content=[
            ContentBlock(
                type="tool_result",
                tool_use_id="tool-1",
                tool_result="fallback",
                extra={
                    "content_blocks": [
                        {"type": "text", "text": "hello"},
                        {
                            "type": "image",
                            "source": "base64",
                            "mime_type": "image/png",
                            "data": "aW1n",
                        },
                    ]
                },
            )
        ],
    )

    messages = serialize_bedrock_messages(_req(tool_result))

    content = messages[0]["content"][0]["toolResult"]["content"]
    assert content == [
        {"text": "hello"},
        {"image": {"format": "png", "source": {"bytes": b"img"}}},
    ]


def test_bedrock_client_streams_text_deltas_incrementally() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {"contentBlockDelta": {"delta": {"text": "hel"}}},
                {"contentBlockDelta": {"delta": {"text": "lo"}}},
                {
                    "metadata": {
                        "usage": {"inputTokens": 3, "outputTokens": 2},
                        "requestId": "req-1",
                    }
                },
                {"messageStop": {"stopReason": "end_turn"}},
            ]
        )

    client = BedrockConverseModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    text_deltas = [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA]
    assert text_deltas == ["hel", "lo"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 3
    assert usage.request_id == "req-1"
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.STOP


def test_bedrock_client_streams_tool_input_deltas_incrementally() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {
                    "contentBlockStart": {
                        "start": {
                            "toolUse": {"toolUseId": "t1", "name": "echo"},
                        }
                    }
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": '{"x"'}},
                    }
                },
                {
                    "contentBlockDelta": {
                        "delta": {"toolUse": {"input": ":1}"}},
                    }
                },
                {"contentBlockStop": {}},
                {"messageStop": {"stopReason": "tool_use"}},
            ]
        )

    client = BedrockConverseModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    deltas = [e.tool_input_delta for e in events if e.kind == AssistantEventKind.TOOL_INPUT_DELTA]
    assert deltas == ['{"x"', ":1}"]
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}
