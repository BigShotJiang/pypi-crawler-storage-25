from __future__ import annotations

from tada_core.contracts.events import Event, UnsupportedEvent
from tada_core.contracts.session import SessionState
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition
from tada_core.loop import AgentLoop, StubToolModelClient
from tada_core.contracts.model import EchoModelClient


def make_echo_loop() -> AgentLoop:
    return AgentLoop(EchoModelClient())


def make_stub_tool_loop(tool_name: str = "echo", tool_input: str = "{}") -> AgentLoop:
    return AgentLoop(StubToolModelClient(tool_name, tool_input))


def new_state() -> SessionState:
    return SessionState()


def build_echo_executor() -> InMemoryToolExecutor:
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="echo", parameters_schema={"type": "object"}),
        lambda s: s,
    )
    ex.register(
        ToolDefinition(name="delegate", description="delegate", parameters_schema={"type": "object"}),
        lambda _: "delegate-not-used",
    )
    return ex


async def collect_events(loop: AgentLoop, text: str = "hi", state: SessionState | None = None) -> list[Event]:
    actual_state = state or new_state()
    events: list[Event] = []
    async for ev in loop.run_turn(actual_state, text):
        events.append(ev)
    return events


def has_unsupported(events: list[Event], feature: str | None = None) -> bool:
    for ev in events:
        if isinstance(ev, UnsupportedEvent):
            if feature is None or ev.feature == feature:
                return True
    return False
