"""Tests for optional multimodal content normalization helpers."""

import base64

import pytest

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.utils.content_normalizer import ContentNormalizerConfig, normalize_messages


def _message_with(block: ContentBlock) -> ConversationMessage:
    return ConversationMessage(role=MessageRole.USER, content=[block])


@pytest.mark.asyncio
async def test_normalize_messages_canonicalizes_image_mime_alias() -> None:
    messages = [
        _message_with(
            ContentBlock(
                type="image",
                source="base64",
                mime_type="image/jpg",
                data=base64.b64encode(b"not-a-real-image").decode(),
            )
        )
    ]

    normalized = await normalize_messages(messages)

    assert normalized[0].content[0].mime_type == "image/jpeg"


@pytest.mark.asyncio
async def test_normalize_messages_converts_path_image_to_base64(tmp_path) -> None:
    image_path = tmp_path / "sample.PNG"
    image_path.write_bytes(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lkBv5QAAAABJRU5ErkJggg=="))
    messages = [
        _message_with(
            ContentBlock(
                type="image",
                source="path",
                mime_type="image/x-png",
                data=str(image_path),
            )
        )
    ]

    normalized = await normalize_messages(messages, ContentNormalizerConfig(fetch_http_urls=False))

    block = normalized[0].content[0]
    assert block.source == "base64"
    assert block.mime_type == "image/png"
    assert block.data
    assert block.data != str(image_path)
