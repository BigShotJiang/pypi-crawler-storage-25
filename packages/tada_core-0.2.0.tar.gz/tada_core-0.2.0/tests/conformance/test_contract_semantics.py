import pytest

from tada_core.contracts.compaction import (
    CompactionConfig,
    CompactionMode,
    CompactionResult,
    CompactionStrategy,
)
from tada_core.contracts.events import (
    CompactionEvent,
    PermissionEvent,
    TextDelta,
    ToolResultEvent,
    ToolUseRequest,
    UsageEvent,
)
from tada_core.contracts.hooks import FunctionHookRunner, HookResult
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import AssistantEvent, AssistantEventKind, ModelClient
from tada_core.contracts.permissions import PermissionContext, PermissionOutcome, PermissionPolicy
from tada_core.contracts.session import SessionState, TokenUsage
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition
from tada_core.loop import AgentLoop, StubToolModelClient


class CapturePolicy(PermissionPolicy):
    def __init__(self) -> None:
        self.contexts: list[PermissionContext | None] = []

    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter=None,
    ) -> PermissionOutcome:
        _ = tool_name, tool_input, prompter
        self.contexts.append(context)
        return PermissionOutcome.ALLOW


class CountingCompaction(CompactionStrategy):
    def __init__(self) -> None:
        self.should_calls = 0
        self.compact_calls = 0

    def should_compact(self, state: SessionState, *, trigger: str = "auto") -> bool:
        _ = state, trigger
        self.should_calls += 1
        return True

    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult:
        _ = state
        self.compact_calls += 1
        return CompactionResult(removed_message_count=0, summary="counted", trigger=trigger)


def _echo_executor() -> InMemoryToolExecutor:
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="echo", parameters_schema={"type": "object"}),
        lambda s: s,
    )
    return ex


def test_session_state_roundtrip_and_clone() -> None:
    state = SessionState(
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="hello")],
            )
        ],
        metadata={"provider": "agent_loop"},
    )
    loaded = SessionState.model_validate(state.model_dump())
    cloned = loaded.clone()
    cloned.metadata["provider"] = "changed"
    assert loaded.messages[0].text_only() == "hello"
    assert loaded.metadata["provider"] == "agent_loop"


def test_session_state_roundtrips_multimodal_content_blocks() -> None:
    state = SessionState(
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=[
                    ContentBlock(
                        type="image",
                        source="base64",
                        mime_type="image/png",
                        data="iVBORw0KGgo=",
                    ),
                    ContentBlock(type="text", text="describe it"),
                ],
            )
        ]
    )

    loaded = SessionState.model_validate(state.model_dump())

    image = loaded.messages[0].content[0]
    assert image.type == "image"
    assert image.source == "base64"
    assert image.mime_type == "image/png"
    assert image.data == "iVBORw0KGgo="


def test_compaction_config_modes_are_contract_values() -> None:
    assert CompactionConfig().mode == CompactionMode.AUTO
    assert CompactionConfig(mode="disabled").mode == CompactionMode.DISABLED
    assert CompactionConfig(mode="hook_only").mode == CompactionMode.HOOK_ONLY


def test_compaction_event_carries_optional_diagnostics() -> None:
    event = CompactionEvent(
        strategy="StructuredSummaryCompaction",
        removed_message_count=2,
        summary="s",
        trigger="post_llm",
        tokens_before=100,
        tokens_after=40,
        pruned_tool_count=3,
        cache_hit_estimated=True,
    )

    assert event.trigger == "post_llm"
    assert event.tokens_before == 100
    assert event.tokens_after == 40
    assert event.pruned_tool_count == 3
    assert event.cache_hit_estimated is True


def test_content_block_rejects_known_multimodal_blocks_without_payload() -> None:
    with pytest.raises(ValueError, match="image blocks require"):
        ContentBlock(type="image", source="base64", mime_type="image/png")

    with pytest.raises(ValueError, match="file blocks require"):
        ContentBlock(type="file", source="base64", mime_type="application/pdf")


def test_composite_hook_runner_merges_compaction_coordination_fields() -> None:
    from tada_core.contracts.hooks import CompositeHookRunner, NoOpHookRunner

    class CompactionHook(NoOpHookRunner):
        async def run_pre_llm_call(self, messages):
            _ = messages
            return HookResult(compaction_handled=True, skip_builtin_compaction=True)

    async def _run():
        runner = CompositeHookRunner([CompactionHook()])
        return await runner.run_pre_llm_call([])

    import asyncio

    result = asyncio.run(_run())
    assert result.compaction_handled is True
    assert result.skip_builtin_compaction is True


class UsageModelClient(ModelClient):
    def stream(self, request):
        _ = request

        async def _gen():
            yield AssistantEvent(
                kind=AssistantEventKind.USAGE,
                usage=TokenUsage(
                    input_tokens=10,
                    output_tokens=2,
                    cache_read_tokens=4,
                    cache_creation_tokens=6,
                ),
            )
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

        return _gen()


@pytest.mark.asyncio
async def test_usage_event_and_session_state_include_cache_creation_tokens() -> None:
    loop = AgentLoop(UsageModelClient())
    state = SessionState()
    usage_events = []

    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, UsageEvent):
            usage_events.append(ev)

    assert usage_events
    assert usage_events[0].cache_read_tokens == 4
    assert usage_events[0].cache_creation_tokens == 6
    assert state.usage.cache_read_tokens == 4
    assert state.usage.cache_creation_tokens == 6


@pytest.mark.asyncio
async def test_permission_event_precedes_tool_result() -> None:
    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    loop.set_tool_executor(_echo_executor())
    state = SessionState()
    sequence: list[str] = []
    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, ToolUseRequest):
            sequence.append("tool_use")
        elif isinstance(ev, PermissionEvent):
            sequence.append("permission")
        elif isinstance(ev, ToolResultEvent):
            sequence.append("tool_result")
    assert sequence.index("tool_use") < sequence.index("permission") < sequence.index("tool_result")


@pytest.mark.asyncio
async def test_hook_injects_permission_context() -> None:
    def pre(name: str, inp: str) -> HookResult:
        _ = name, inp
        return HookResult(
            permission_override="allow_once",
            permission_reason="hook requested override",
            updated_input='{"from":"hook"}',
        )

    policy = CapturePolicy()
    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    loop.set_hook_runner(FunctionHookRunner(pre=pre))
    loop.set_permission_policy(policy)
    loop.set_tool_executor(_echo_executor())
    state = SessionState()
    outputs: list[str] = []
    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, ToolResultEvent):
            outputs.append(ev.output)
    assert policy.contexts
    assert policy.contexts[0] is not None
    assert policy.contexts[0].override == "allow_once"
    assert policy.contexts[0].reason == "hook requested override"
    assert outputs and '"from":"hook"' in outputs[0]


@pytest.mark.asyncio
async def test_compaction_strategy_can_run_pre_and_post_turn() -> None:
    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    loop.set_tool_executor(_echo_executor())
    strategy = CountingCompaction()
    loop.set_compaction_strategy(strategy)
    state = SessionState()
    compactions = 0
    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, CompactionEvent):
            compactions += 1
    assert strategy.should_calls >= 2
    assert strategy.compact_calls >= 2
    assert compactions >= 2


@pytest.mark.asyncio
async def test_text_event_stays_serializable() -> None:
    from tada_core.contracts.model import EchoModelClient

    loop = AgentLoop(EchoModelClient())
    state = SessionState()
    seen = []
    async for ev in loop.run_turn(state, "hello"):
        if isinstance(ev, TextDelta):
            payload = ev.model_dump()
            assert payload["type"] == "text_delta"
            seen.append(payload["text"])
    assert seen and "hello" in seen[0]
