"""Tests for RetryingModelClient."""

import pytest

from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient
from tada_core.loop.retry import RetryPolicy, RetryingModelClient


class StatusError(RuntimeError):
    def __init__(self, status_code: int) -> None:
        super().__init__(f"status {status_code}")
        self.status_code = status_code


@pytest.mark.asyncio
async def test_retrying_model_client_retries_before_first_event() -> None:
    class FlakyModel(ModelClient):
        def __init__(self) -> None:
            self.calls = 0

        def stream(self, request: ApiRequest):
            self.calls += 1
            if self.calls < 3:
                raise StatusError(429)

            async def _gen():
                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta="ok")

            return _gen()

    model = FlakyModel()
    retrying = RetryingModelClient(
        model,
        RetryPolicy(max_attempts=3, initial_backoff_s=0, jitter=0),
    )

    events = [event async for event in retrying.stream(ApiRequest())]

    assert model.calls == 3
    assert events[0].text_delta == "ok"


@pytest.mark.asyncio
async def test_retrying_model_client_does_not_retry_after_first_event() -> None:
    class PartialThenFailModel(ModelClient):
        def __init__(self) -> None:
            self.calls = 0

        def stream(self, request: ApiRequest):
            self.calls += 1

            async def _gen():
                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta="partial")
                raise StatusError(429)

            return _gen()

    model = PartialThenFailModel()
    retrying = RetryingModelClient(
        model,
        RetryPolicy(max_attempts=3, initial_backoff_s=0, jitter=0),
    )

    with pytest.raises(StatusError):
        _ = [event async for event in retrying.stream(ApiRequest())]

    assert model.calls == 1
