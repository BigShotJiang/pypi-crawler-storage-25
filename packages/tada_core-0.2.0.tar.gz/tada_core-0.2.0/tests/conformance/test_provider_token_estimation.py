"""Tests for provider token estimation hooks."""

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest
from tada_core.contracts.models import ModelSpec
from tada_core.providers.anthropic import AnthropicModelClient
from tada_core.providers.openai_completions import OpenAICompletionsModelClient, make_openai_completions_transport
from tada_core.providers.openai_responses import OpenAIResponsesModelClient, make_openai_responses_transport


def _request() -> ApiRequest:
    return ApiRequest(
        system_prompt=["You are concise."],
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="hello world")],
            )
        ],
    )


def test_anthropic_estimate_tokens_falls_back_offline() -> None:
    client = AnthropicModelClient(
        api_key="",
        model="claude-test",
        streaming=False,
        model_spec=ModelSpec(id="claude-test", api="anthropic-messages"),
    )

    assert client.estimate_tokens(_request()) > 0


def test_openai_completions_estimate_tokens_returns_positive_count() -> None:
    client = OpenAICompletionsModelClient(
        make_openai_completions_transport(
            api_key="",
            model_id="gpt-4o-mini",
            base_url="https://api.openai.com",
        ),
        model_spec=ModelSpec(id="gpt-4o-mini", api="openai-completions"),
    )

    assert client.estimate_tokens(_request()) > 0


def test_openai_responses_estimate_tokens_returns_positive_count() -> None:
    client = OpenAIResponsesModelClient(
        make_openai_responses_transport(
            api_key="",
            model_id="gpt-4o-mini",
            base_url="https://api.openai.com",
        ),
        model_spec=ModelSpec(id="gpt-4o-mini", api="openai-responses"),
    )

    assert client.estimate_tokens(_request()) > 0
