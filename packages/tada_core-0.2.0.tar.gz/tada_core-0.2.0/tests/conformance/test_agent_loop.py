"""Conformance tests for AgentLoop (primary reference implementation)."""

import pytest

from tada_core.contracts.compaction import (
    CompactionConfig,
    ModelSummaryCompaction,
    NeverCompact,
    StructuredSummaryCompaction,
    TruncateCompaction,
)
from tada_core.contracts.events import (
    CompactionEvent,
    ErrorEvent,
    HookEvent,
    LoopExitEvent,
    PermissionEvent,
    SteeringEvent,
    TextDelta,
    ToolProgressEvent,
    ToolResultEvent,
    ToolUseRequest,
)
from tada_core.contracts.hooks import FunctionHookRunner, HookResult
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import EchoModelClient
from tada_core.contracts.permissions import DenyListPolicy
from tada_core.contracts.session import SessionState
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition, ToolResult
from tada_core.loop import AgentLoop, StubToolModelClient


@pytest.mark.asyncio
async def test_echo_single_turn() -> None:
    loop = AgentLoop(EchoModelClient())
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "ping"):
        events.append(ev)
    assert any(isinstance(e, TextDelta) and "ping" in e.text for e in events)
    assert state.messages[0].role == MessageRole.USER
    assert state.messages[-1].role == MessageRole.ASSISTANT


def test_agent_loop_defaults_to_structured_summary_compaction() -> None:
    loop = AgentLoop(EchoModelClient())

    assert isinstance(loop._compaction, StructuredSummaryCompaction)


def test_agent_loop_can_disable_builtin_compaction() -> None:
    assert isinstance(AgentLoop(EchoModelClient(), compaction="disabled")._compaction, NeverCompact)
    assert isinstance(
        AgentLoop(EchoModelClient(), compaction=CompactionConfig(mode="disabled"))._compaction,
        NeverCompact,
    )


@pytest.mark.asyncio
async def test_agent_loop_compaction_event_includes_extended_metadata() -> None:
    loop = AgentLoop(EchoModelClient())
    loop.set_compaction_strategy(
        StructuredSummaryCompaction(EchoModelClient(), threshold_tokens=1, keep_last=2, head_protect=1)
    )
    state = SessionState(
        messages=[
            ConversationMessage(
                id="head",
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="head")],
            ),
            ConversationMessage(
                id="old",
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id="t1",
                        tool_name="shell",
                            tool_result="x" * 5000,
                    )
                ],
            ),
            ConversationMessage(
                id="tail-a",
                role=MessageRole.ASSISTANT,
                content=[ContentBlock(type="text", text="tail a")],
            ),
            ConversationMessage(
                id="tail",
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="tail")],
            ),
        ]
    )

    event = await loop.compact(state, trigger="manual")

    assert isinstance(event, CompactionEvent)
    assert event.compacted_message_ids == ["old"]
    assert event.pruned_tool_results_count == 1
    assert event.fallback_used is False


@pytest.mark.asyncio
async def test_tool_roundtrip() -> None:
    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="echo", parameters_schema={"type": "object"}),
        lambda _: "ok",
    )
    loop.set_tool_executor(ex)
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)
    assert any(isinstance(e, ToolUseRequest) for e in events)
    assert any(isinstance(e, ToolResultEvent) and e.output == "ok" for e in events)


@pytest.mark.asyncio
async def test_structured_tool_result_blocks_are_persisted() -> None:
    loop = AgentLoop(StubToolModelClient("screenshot", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(
            name="screenshot",
            description="Return screenshot",
            parameters_schema={"type": "object"},
        ),
        lambda _: ToolResult(
            content="screenshot captured",
            content_blocks=[
                ContentBlock(
                    type="image",
                    source="base64",
                    mime_type="image/png",
                    data="abc",
                )
            ],
        ),
    )
    loop.set_tool_executor(ex)
    state = SessionState()

    async for _ in loop.run_turn(state, "capture"):
        pass

    tool_message = next(message for message in state.messages if message.role == MessageRole.TOOL)
    result_block = tool_message.content[0]
    nested = result_block.tool_result_blocks()
    assert result_block.tool_result == "screenshot captured"
    assert nested[0].type == "image"
    assert nested[0].data == "abc"


@pytest.mark.asyncio
async def test_permission_deny() -> None:
    loop = AgentLoop(StubToolModelClient("bad", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="bad", description="x", parameters_schema={"type": "object"}),
        lambda _: "no",
    )
    loop.set_tool_executor(ex)
    loop.set_permission_policy(DenyListPolicy({"bad"}))
    state = SessionState()
    perms: list = []
    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, PermissionEvent):
            perms.append(ev)
    assert any(not p.allowed for p in perms)


@pytest.mark.asyncio
async def test_hook_updated_input() -> None:
    def pre(name: str, inp: str) -> HookResult:
        if name == "echo":
            return HookResult(updated_input='{"patched":true}')
        return HookResult.allow()

    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    loop.set_hook_runner(FunctionHookRunner(pre=pre))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="e", parameters_schema={"type": "object"}),
        lambda s: s,
    )
    loop.set_tool_executor(ex)
    state = SessionState()
    results: list = []
    async for ev in loop.run_turn(state, "x"):
        if isinstance(ev, ToolResultEvent):
            results.append(ev.output)
    assert results and "patched" in results[0]


@pytest.mark.asyncio
async def test_hook_only_mode_skips_builtin_compaction_when_hook_handles_it() -> None:
    def pre_llm(messages: list[ConversationMessage]) -> HookResult:
        return HookResult(
            updated_messages=messages[-1:],
            compaction_handled=True,
            skip_builtin_compaction=True,
        )

    loop = AgentLoop(EchoModelClient(), compaction=CompactionConfig(mode="hook_only"))
    loop.set_hook_runner(FunctionHookRunner(pre_llm_call=pre_llm))
    state = SessionState(
        messages=[
            ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="old")])
        ]
    )

    events: list = []
    async for ev in loop.run_turn(state, "new"):
        events.append(ev)

    assert not any(isinstance(ev, CompactionEvent) for ev in events)
    assert all("old" not in m.text_only() for m in state.messages)


@pytest.mark.asyncio
async def test_truncate_compaction() -> None:
    loop = AgentLoop(EchoModelClient())
    loop.set_compaction_strategy(TruncateCompaction(max_messages=2))
    state = SessionState()
    state.messages = [
        ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="a")]),
        ConversationMessage(
            role=MessageRole.ASSISTANT, content=[ContentBlock(type="text", text="b")]
        ),
        ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="c")]),
    ]
    comps: list = []
    async for ev in loop.run_turn(state, "d"):
        if isinstance(ev, CompactionEvent):
            comps.append(ev)
    assert comps or len(state.messages) <= 3


@pytest.mark.asyncio
async def test_tool_failure_emits_hook_and_error_result() -> None:
    def _boom(_: str) -> str:
        raise RuntimeError("tool exploded")

    loop = AgentLoop(StubToolModelClient("boom", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="boom", description="boom", parameters_schema={"type": "object"}),
        _boom,
    )
    loop.set_tool_executor(ex)
    loop.set_hook_runner(
        FunctionHookRunner(
            post_failure=lambda name, inp, err: HookResult(messages=[f"failed:{name}:{err}"])
        )
    )
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)
    assert any(isinstance(ev, HookEvent) and ev.phase == "PostToolUseFailure" for ev in events)
    assert any(isinstance(ev, ToolResultEvent) and ev.is_error for ev in events)


@pytest.mark.asyncio
async def test_model_error_emits_error_event() -> None:
    class BrokenModel(EchoModelClient):
        def stream(self, request):  # type: ignore[override]
            raise RuntimeError("model down")  # raised synchronously before yielding

    loop = AgentLoop(BrokenModel())
    state = SessionState()
    events = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)
    assert any(isinstance(ev, ErrorEvent) and ev.code == "model_error" for ev in events)


@pytest.mark.asyncio
async def test_abort_mid_turn_emits_abort_error() -> None:
    class FlipAbort:
        def __init__(self) -> None:
            self.calls = 0

        def is_set(self) -> bool:
            self.calls += 1
            return self.calls >= 2

    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    loop.set_tool_executor(InMemoryToolExecutor())
    state = SessionState()
    events = []
    async for ev in loop.run_turn(state, "x", abort=FlipAbort()):
        events.append(ev)
    assert any(isinstance(ev, ErrorEvent) and ev.code == "aborted" for ev in events)


@pytest.mark.asyncio
async def test_model_summary_compaction_rewrites_history() -> None:
    loop = AgentLoop(EchoModelClient())
    loop.set_compaction_strategy(ModelSummaryCompaction(EchoModelClient(), threshold_tokens=1, keep_last=2))
    state = SessionState()
    state.messages = [
        ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="first")]),
        ConversationMessage(
            role=MessageRole.ASSISTANT, content=[ContentBlock(type="text", text="second")]
        ),
        ConversationMessage(role=MessageRole.USER, content=[ContentBlock(type="text", text="third")]),
        ConversationMessage(
            role=MessageRole.ASSISTANT, content=[ContentBlock(type="text", text="fourth")]
        ),
    ]
    events = []
    async for ev in loop.run_turn(state, "fifth"):
        events.append(ev)
    assert any(isinstance(ev, CompactionEvent) for ev in events)
    assert state.messages[0].text_only().startswith("[compacted summary]")


@pytest.mark.asyncio
async def test_tool_progress_events_emitted() -> None:
    """on_update callback produces ToolProgressEvent in the stream."""
    from tada_core.contracts.model import AssistantEventKind, ApiRequest, AssistantEvent

    # Model: first call returns a tool use, second call returns plain text (stops loop)
    call_count = 0

    class OnceToolModel(EchoModelClient):
        def stream(self, request: ApiRequest):  # type: ignore[override]
            nonlocal call_count
            call_count += 1

            async def _gen():
                if call_count == 1:
                    yield AssistantEvent(
                        kind=AssistantEventKind.TOOL_USE,
                        tool_use_id="t1",
                        tool_name="slow",
                        tool_input="{}",
                    )
                    yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)
                else:
                    yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta="done")
                    yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

            return _gen()

    def _slow_tool(input_json: str, on_update=None) -> str:
        if on_update:
            on_update("step 1/2")
            on_update("step 2/2")
        return "done"

    loop = AgentLoop(OnceToolModel())
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="slow", description="slow", parameters_schema={"type": "object"}),
        _slow_tool,
    )
    loop.set_tool_executor(ex)
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)
    progress = [ev for ev in events if isinstance(ev, ToolProgressEvent)]
    assert len(progress) == 2
    assert progress[0].update == "step 1/2"
    assert progress[1].update == "step 2/2"
    assert progress[0].tool_name == "slow"


@pytest.mark.asyncio
async def test_loop_exit_with_reason() -> None:
    """exit_loop=True + exit_reason stops the loop and emits LoopExitEvent."""
    async def _post(name: str, inp: str, out: str, *, is_error: bool) -> HookResult:
        if name == "ask":
            return HookResult(exit_loop=True, exit_reason="waiting for user reply")
        return HookResult.allow()

    loop = AgentLoop(StubToolModelClient("ask", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="ask", description="ask", parameters_schema={"type": "object"}),
        lambda _: "What would you like?",
    )
    loop.set_tool_executor(ex)
    loop.set_hook_runner(FunctionHookRunner(post=_post))
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)
    exit_evs = [ev for ev in events if isinstance(ev, LoopExitEvent)]
    assert len(exit_evs) == 1
    assert exit_evs[0].reason == "waiting for user reply"
    assert exit_evs[0].tool_name == "ask"


@pytest.mark.asyncio
async def test_steering_skipped_tools_count() -> None:
    """steering_messages skips remaining tools and reports correct skipped count."""
    from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
    from tada_core.loop.model_client import OpenAICompatibleModelClient

    # Model returns two tool calls on first invocation, then plain text to stop loop
    _call_count = 0

    def _transport(request, stream):
        nonlocal _call_count
        _call_count += 1
        if _call_count == 1:
            return {
                "choices": [{
                    "message": {
                        "tool_calls": [
                            {"id": "t1", "function": {"name": "tool_a", "arguments": "{}"}},
                            {"id": "t2", "function": {"name": "tool_b", "arguments": "{}"}},
                        ]
                    }
                }],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1},
            }
        return {
            "choices": [{"message": {"content": "done"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }

    model = OpenAICompatibleModelClient(_transport, streaming=False)
    loop = AgentLoop(model)
    ex = InMemoryToolExecutor()
    for name in ("tool_a", "tool_b"):
        ex.register(
            ToolDefinition(name=name, description=name, parameters_schema={"type": "object"}),
            lambda _: "ok",
        )
    loop.set_tool_executor(ex)

    steering_msg = ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text="changed my mind")],
    )

    async def _post(name: str, inp: str, out: str, *, is_error: bool) -> HookResult:
        if name == "tool_a":
            return HookResult(steering_messages=[steering_msg])
        return HookResult.allow()

    loop.set_hook_runner(FunctionHookRunner(post=_post))
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    steering_evs = [ev for ev in events if isinstance(ev, SteeringEvent)]
    assert len(steering_evs) == 1
    assert steering_evs[0].skipped_tools == 1   # tool_b was skipped
    assert steering_evs[0].message_count == 1
    # tool_b should NOT have a ToolResultEvent
    tool_results = [ev for ev in events if isinstance(ev, ToolResultEvent)]
    assert all(ev.tool_name == "tool_a" for ev in tool_results)


@pytest.mark.asyncio
async def test_exit_loop_stops_after_current_tool() -> None:
    """POST_TOOL_USE hook returning exit_loop=True stops the loop after the
    tool completes; no further LLM call is made."""

    async def post(name: str, inp: str, out: str, is_error: bool) -> HookResult:
        return HookResult(exit_loop=True, messages=["ask_user sent"])

    loop = AgentLoop(StubToolModelClient("echo", "{}"))
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="e", parameters_schema={"type": "object"}),
        lambda _: "ok",
    )
    loop.set_tool_executor(ex)
    loop.set_hook_runner(FunctionHookRunner(post=post))
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    assert any(isinstance(ev, LoopExitEvent) and ev.tool_name == "echo" for ev in events)
    # loop exits cleanly — TurnEndEvent must still be emitted
    assert any(isinstance(ev, __import__("tada_core.contracts.events", fromlist=["TurnEndEvent"]).TurnEndEvent) for ev in events)


@pytest.mark.asyncio
async def test_steering_skips_remaining_tools_and_injects_message() -> None:
    """POST_TOOL_USE hook returning steering_messages causes remaining tools to
    be skipped and the messages to be appended to session state."""

    steering_msg = ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text="change direction")],
    )

    call_count = 0

    async def post(name: str, inp: str, out: str, is_error: bool) -> HookResult:
        nonlocal call_count
        call_count += 1
        return HookResult(steering_messages=[steering_msg])

    # First LLM call returns two tools; subsequent calls return no tools
    # (simulating LLM re-planning after seeing the steering message)
    class TwoToolThenDoneModel(StubToolModelClient):
        def __init__(self) -> None:
            super().__init__()
            self._call_index = 0

        def stream(self, request):  # type: ignore[override]
            from tada_core.contracts.model import AssistantEvent, AssistantEventKind

            call = self._call_index
            self._call_index += 1

            async def _gen():
                if call == 0:
                    yield AssistantEvent(kind=AssistantEventKind.TOOL_USE, tool_use_id="t1", tool_name="echo", tool_input="{}")
                    yield AssistantEvent(kind=AssistantEventKind.TOOL_USE, tool_use_id="t2", tool_name="echo", tool_input="{}")
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

            return _gen()

    loop = AgentLoop(TwoToolThenDoneModel())
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="e", parameters_schema={"type": "object"}),
        lambda _: "ok",
    )
    loop.set_tool_executor(ex)
    loop.set_hook_runner(FunctionHookRunner(post=post))
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    # Only the first tool's POST_TOOL_USE hook should fire
    assert call_count == 1
    # SteeringEvent emitted
    assert any(isinstance(ev, SteeringEvent) for ev in events)
    # Steering message appended to state
    assert any(
        m.role == MessageRole.USER and "change direction" in m.text_only()
        for m in state.messages
    )


# ── Parallel tool execution ──────────────────────────────────────────────────


def _make_parallel_model(*tool_names: str, then_text: str = "done"):
    """Returns a ModelClient that emits the given tool_names on the first call,
    then plain text on subsequent calls (to stop the loop)."""
    from tada_core.contracts.model import AssistantEvent, AssistantEventKind, EchoModelClient

    class _Model(EchoModelClient):
        def __init__(self) -> None:
            self._call = 0

        def stream(self, request):  # type: ignore[override]
            call = self._call
            self._call += 1

            async def _gen():
                if call == 0:
                    for i, name in enumerate(tool_names):
                        yield AssistantEvent(
                            kind=AssistantEventKind.TOOL_USE,
                            tool_use_id=f"t{i}",
                            tool_name=name,
                            tool_input="{}",
                        )
                else:
                    yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=then_text)
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

            return _gen()

    return _Model()


@pytest.mark.asyncio
async def test_parallel_tools_all_execute() -> None:
    """All parallel-marked tools in a group run and emit ToolResultEvents."""
    import asyncio

    started: list[str] = []
    finished: list[str] = []

    async def _slow(name: str, input_json: str, on_update=None) -> str:
        started.append(name)
        await asyncio.sleep(0)  # yield to event loop
        finished.append(name)
        return f"result-{name}"

    loop = AgentLoop(_make_parallel_model("p1", "p2", "p3"))
    ex = InMemoryToolExecutor()
    for name in ("p1", "p2", "p3"):
        td = ToolDefinition(name=name, description=name, parameters_schema={"type": "object"}, parallel=True)
        fn = (lambda n: lambda inp, on_update=None: _slow(n, inp, on_update))(name)
        ex.register(td, fn)
    loop.set_tool_executor(ex)
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    results = [ev for ev in events if isinstance(ev, ToolResultEvent)]
    assert len(results) == 3
    assert {ev.tool_name for ev in results} == {"p1", "p2", "p3"}
    assert not any(ev.is_error for ev in results)


@pytest.mark.asyncio
async def test_parallel_steering_cancels_remaining() -> None:
    """steering_messages from one parallel tool cancels still-running peers."""
    import asyncio

    executed: list[str] = []
    gate = asyncio.Event()  # p2 blocks until released

    async def _p1(input_json: str) -> str:
        executed.append("p1")
        return "p1-done"

    async def _p2(input_json: str) -> str:
        await gate.wait()   # will be cancelled before gate is set
        executed.append("p2")
        return "p2-done"

    steering_msg = ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text="steer")],
    )

    async def _post(name: str, inp: str, out: str, *, is_error: bool) -> HookResult:
        if name == "p1":
            return HookResult(steering_messages=[steering_msg])
        return HookResult.allow()

    loop = AgentLoop(_make_parallel_model("p1", "p2"))
    ex = InMemoryToolExecutor()
    ex.register(ToolDefinition(name="p1", description="p1", parameters_schema={"type": "object"}, parallel=True), _p1)
    ex.register(ToolDefinition(name="p2", description="p2", parameters_schema={"type": "object"}, parallel=True), _p2)
    loop.set_tool_executor(ex)
    loop.set_hook_runner(FunctionHookRunner(post=_post))
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    assert any(isinstance(ev, SteeringEvent) for ev in events)
    steering_ev = next(ev for ev in events if isinstance(ev, SteeringEvent))
    assert steering_ev.skipped_tools >= 1   # p2 was cancelled
    # p2 must NOT have produced a ToolResultEvent
    tool_results = [ev for ev in events if isinstance(ev, ToolResultEvent)]
    assert all(ev.tool_name == "p1" for ev in tool_results)
    # p2 was never completed
    assert "p2" not in executed


@pytest.mark.asyncio
async def test_parallel_and_sequential_mixed() -> None:
    """Sequential tool after a parallel group still runs when no signal fires."""
    executed: list[str] = []

    def _fn(name: str):
        def _inner(input_json: str) -> str:
            executed.append(name)
            return f"ok-{name}"
        return _inner

    # Model: first call → p1(parallel), p2(parallel), seq(sequential)
    # second call → plain text
    from tada_core.contracts.model import AssistantEvent, AssistantEventKind, EchoModelClient

    class _MixedModel(EchoModelClient):
        def __init__(self) -> None:
            self._call = 0

        def stream(self, request):  # type: ignore[override]
            call = self._call
            self._call += 1

            async def _gen():
                if call == 0:
                    yield AssistantEvent(kind=AssistantEventKind.TOOL_USE, tool_use_id="t0", tool_name="p1", tool_input="{}")
                    yield AssistantEvent(kind=AssistantEventKind.TOOL_USE, tool_use_id="t1", tool_name="p2", tool_input="{}")
                    yield AssistantEvent(kind=AssistantEventKind.TOOL_USE, tool_use_id="t2", tool_name="seq", tool_input="{}")
                else:
                    yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta="done")
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

            return _gen()

    loop = AgentLoop(_MixedModel())
    ex = InMemoryToolExecutor()
    ex.register(ToolDefinition(name="p1", description="p1", parameters_schema={"type": "object"}, parallel=True), _fn("p1"))
    ex.register(ToolDefinition(name="p2", description="p2", parameters_schema={"type": "object"}, parallel=True), _fn("p2"))
    ex.register(ToolDefinition(name="seq", description="seq", parameters_schema={"type": "object"}, parallel=False), _fn("seq"))
    loop.set_tool_executor(ex)
    state = SessionState()
    events: list = []
    async for ev in loop.run_turn(state, "x"):
        events.append(ev)

    results = [ev for ev in events if isinstance(ev, ToolResultEvent)]
    assert {ev.tool_name for ev in results} == {"p1", "p2", "seq"}
    assert set(executed) == {"p1", "p2", "seq"}
