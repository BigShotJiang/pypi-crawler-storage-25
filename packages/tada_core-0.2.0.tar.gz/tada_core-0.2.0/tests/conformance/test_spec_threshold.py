import pytest

from tada_core.contracts.compaction import StructuredSummaryCompaction
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import EchoModelClient
from tada_core.contracts.models import ModelSpec
from tada_core.contracts.session import SessionState


def _state_with_text(text: str) -> SessionState:
    return SessionState(
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text=text)],
            )
        ]
    )


def test_structured_compaction_threshold_defaults_from_model_spec_context_window() -> None:
    spec = ModelSpec(
        id="spec-model",
        provider="test",
        api="openai-completions",
        context_window=100,
    )
    model = EchoModelClient()
    model.model_spec = spec  # type: ignore[attr-defined]

    strategy = StructuredSummaryCompaction(model)

    assert strategy.effective_threshold_tokens() == 70
    assert strategy.should_compact(_state_with_text("x" * 400), trigger="pre_turn")


def test_structured_compaction_explicit_threshold_wins_over_model_spec() -> None:
    spec = ModelSpec(
        id="spec-model",
        provider="test",
        api="openai-completions",
        context_window=100,
    )
    model = EchoModelClient()
    model.model_spec = spec  # type: ignore[attr-defined]

    strategy = StructuredSummaryCompaction(model, threshold_tokens=10)

    assert strategy.effective_threshold_tokens() == 10


def test_structured_compaction_uses_fallback_threshold_without_spec() -> None:
    strategy = StructuredSummaryCompaction(EchoModelClient())

    assert strategy.effective_threshold_tokens() == StructuredSummaryCompaction.FALLBACK_THRESHOLD_TOKENS


@pytest.mark.asyncio
async def test_structured_compaction_from_spec_builds_client_and_keeps_spec_threshold() -> None:
    spec = ModelSpec(
        id="echo-ish",
        provider="test",
        api="openai-completions",
        context_window=100,
    )

    def transport(request, stream):
        _ = request, stream
        return {
            "choices": [{"message": {"content": "summary"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }

    strategy = StructuredSummaryCompaction.from_spec(
        spec,
        transport=transport,
        streaming=False,
    )

    assert strategy.effective_threshold_tokens() == 70
