"""Offline conformance tests for the OpenAI Responses adapter."""

import asyncio
import json

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind, StopReason
from tada_core.providers.openai_responses import OpenAIResponsesModelClient


def _req(*messages: ConversationMessage) -> ApiRequest:
    return ApiRequest(messages=list(messages))


def _user(text: str) -> ConversationMessage:
    return ConversationMessage(
        role=MessageRole.USER,
        content=[ContentBlock(type="text", text=text)],
    )


def test_openai_responses_client_streams_output_text_deltas_incrementally() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {"type": "response.output_text.delta", "delta": "he", "id": "resp_1"},
                {"type": "response.output_text.delta", "delta": "llo", "id": "resp_1"},
                {
                    "type": "response.completed",
                    "response": {
                        "id": "resp_1",
                        "model": "gpt-test",
                        "status": "completed",
                        "usage": {"input_tokens": 5, "output_tokens": 2},
                    },
                },
            ]
        )

    client = OpenAIResponsesModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["he", "llo"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.usage.input_tokens == 5
    assert usage.model_id == "gpt-test"


def test_openai_responses_client_streams_function_call_arguments() -> None:
    def transport(_request: ApiRequest, stream: bool):
        assert stream is True
        return iter(
            [
                {
                    "type": "response.output_item.added",
                    "item": {
                        "type": "function_call",
                        "call_id": "call_1",
                        "name": "echo",
                    },
                },
                {
                    "type": "response.function_call_arguments.delta",
                    "call_id": "call_1",
                    "delta": '{"x"',
                },
                {
                    "type": "response.function_call_arguments.delta",
                    "call_id": "call_1",
                    "delta": ":1}",
                },
                {
                    "type": "response.completed",
                    "response": {
                        "status": "completed",
                    },
                },
            ]
        )

    client = OpenAIResponsesModelClient(transport, streaming=True)

    async def collect() -> list:
        events = []
        async for event in client.stream(_req(_user("hi"))):
            events.append(event)
        return events

    events = asyncio.run(collect())

    assert [e.tool_input_delta for e in events if e.kind == AssistantEventKind.TOOL_INPUT_DELTA] == [
        '{"x"',
        ":1}",
    ]
    tool = next(e for e in events if e.kind == AssistantEventKind.TOOL_USE)
    assert tool.tool_name == "echo"
    assert json.loads(tool.tool_input) == {"x": 1}
    stop = next(e for e in events if e.kind == AssistantEventKind.MESSAGE_STOP)
    assert stop.stop_reason == StopReason.TOOL_USE


def test_openai_responses_default_httpx_stream_path_parses_sse_lines() -> None:
    import httpx

    body = "\n".join(
        [
            'data: {"type":"response.output_text.delta","delta":"he","id":"resp_1"}',
            "",
            'data: {"type":"response.output_text.delta","delta":"llo","id":"resp_1"}',
            "",
            'data: {"type":"response.completed","response":{"id":"resp_1","model":"gpt-test","status":"completed","usage":{"input_tokens":5,"output_tokens":2}}}',
            "",
        ]
    )

    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == "https://example.invalid/v1/responses"
        assert request.headers["authorization"] == "Bearer test-key"
        return httpx.Response(
            200,
            content=(body + "\n").encode(),
            headers={"content-type": "text/event-stream"},
        )

    transport = httpx.MockTransport(handler)
    original_init = httpx.AsyncClient.__init__

    def patched_init(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        kwargs["transport"] = transport
        original_init(self, *args, **kwargs)

    httpx.AsyncClient.__init__ = patched_init  # type: ignore[method-assign]
    try:
        client = OpenAIResponsesModelClient(
            None,
            streaming=True,
            api_key="test-key",
            model_id="gpt-test",
            base_url="https://example.invalid",
        )

        async def collect() -> list:
            events = []
            async for event in client.stream(_req(_user("hi"))):
                events.append(event)
            return events

        events = asyncio.run(collect())
    finally:
        httpx.AsyncClient.__init__ = original_init  # type: ignore[method-assign]

    assert [e.text_delta for e in events if e.kind == AssistantEventKind.TEXT_DELTA] == ["he", "llo"]
    usage = next(e for e in events if e.kind == AssistantEventKind.USAGE)
    assert usage.model_id == "gpt-test"
    assert usage.request_id == "resp_1"
