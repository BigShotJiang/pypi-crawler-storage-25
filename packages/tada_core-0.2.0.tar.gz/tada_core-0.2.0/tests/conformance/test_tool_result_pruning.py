from tada_core.contracts.compaction import ToolResultPruningConfig
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.loop.message_sanitizer import prune_tool_results_for_compaction


PLACEHOLDER = "[Old tool output cleared to save context space]"


def _tool_result(
    text: str,
    *,
    message_id: str,
    tool_use_id: str = "tool-1",
    is_error: bool = False,
) -> ConversationMessage:
    return ConversationMessage(
        id=message_id,
        role=MessageRole.TOOL,
        content=[
            ContentBlock(
                type="tool_result",
                tool_use_id=tool_use_id,
                tool_name="shell",
                tool_result=text,
                is_error=is_error,
            )
        ],
    )


def test_prunes_middle_tool_results_and_records_manifest() -> None:
    messages = [
        ConversationMessage(
            id="head",
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="original request")],
        ),
        _tool_result("x" * 80, message_id="middle-tool"),
        ConversationMessage(
            id="tail",
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="continue from here")],
        ),
    ]

    pruned, manifest = prune_tool_results_for_compaction(
        messages,
        config=ToolResultPruningConfig(
            enabled=True,
            scope="middle_only",
            max_chars=20,
            placeholder=PLACEHOLDER,
        ),
        head_count=1,
        tail_count=1,
    )

    block = pruned[1].content[0]
    assert block.tool_result == PLACEHOLDER
    assert manifest["pruned_tool_count"] == 1
    assert manifest["pruned_tool_results"][0]["message_id"] == "middle-tool"
    assert manifest["pruned_tool_results"][0]["original_chars"] == 80


def test_pruning_keeps_tail_tool_results_verbatim_by_default() -> None:
    messages = [
        ConversationMessage(
            id="head",
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="original request")],
        ),
        ConversationMessage(
            id="middle",
            role=MessageRole.ASSISTANT,
            content=[ContentBlock(type="text", text="old answer")],
        ),
        _tool_result("recent output" * 20, message_id="tail-tool"),
    ]

    pruned, manifest = prune_tool_results_for_compaction(
        messages,
        config=ToolResultPruningConfig(enabled=True, scope="middle_only", max_chars=20),
        head_count=1,
        tail_count=1,
    )

    assert pruned[-1].content[0].tool_result == "recent output" * 20
    assert manifest["pruned_tool_count"] == 0


def test_pruning_preserves_more_error_output() -> None:
    messages = [
        ConversationMessage(
            id="head",
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="original request")],
        ),
        _tool_result("error stack" * 10, message_id="middle-error", is_error=True),
        ConversationMessage(
            id="tail",
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text="continue")],
        ),
    ]

    pruned, manifest = prune_tool_results_for_compaction(
        messages,
        config=ToolResultPruningConfig(
            enabled=True,
            scope="middle_only",
            max_chars=20,
            preserve_error_chars=200,
        ),
        head_count=1,
        tail_count=1,
    )

    assert pruned[1].content[0].tool_result == "error stack" * 10
    assert manifest["pruned_tool_count"] == 0
