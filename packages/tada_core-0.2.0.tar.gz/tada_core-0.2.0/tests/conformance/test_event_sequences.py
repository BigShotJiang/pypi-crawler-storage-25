import pytest

from tada_core.contracts.events import MessageStop, PermissionEvent, TextDelta, ToolResultEvent, TurnEndEvent, TurnStartEvent
from tada_core.contracts.hooks import FunctionHookRunner, HookResult
from tada_core.contracts.model import EchoModelClient
from tada_core.contracts.permissions import DenyListPolicy
from tada_core.loop import AgentLoop, StubToolModelClient
from tests.conformance.fixtures import build_echo_executor, collect_events, new_state


@pytest.mark.asyncio
async def test_text_only_sequence() -> None:
    rt = AgentLoop(EchoModelClient())
    state = new_state()
    events = await collect_events(rt, "hello", state)
    labels = [ev.type for ev in events]
    assert any(isinstance(ev, TextDelta) and ev.text == "hello" for ev in events)
    assert "turn_start" in labels
    assert "turn_end" in labels
    assert labels.index("turn_start") < labels.index("text_delta") < labels.index("turn_end")
    assert state.messages[-1].role.value == "assistant"


@pytest.mark.asyncio
async def test_tool_roundtrip_sequence() -> None:
    rt = AgentLoop(StubToolModelClient("echo", "{}"))
    rt.set_tool_executor(build_echo_executor())
    events = await collect_events(rt, "tool", new_state())
    labels = [ev.type for ev in events]
    assert "tool_use" in labels
    assert "permission" in labels
    assert "tool_result" in labels
    assert labels.index("tool_use") < labels.index("permission") < labels.index("tool_result")
    assert labels[0] == "turn_start"
    assert labels[-1] == "turn_end"


@pytest.mark.asyncio
async def test_hook_updated_input_sequence() -> None:
    def pre(name: str, inp: str) -> HookResult:
        _ = name, inp
        return HookResult(updated_input='{"patched":true}', messages=["patched"])

    rt = AgentLoop(StubToolModelClient("echo", "{}"))
    rt.set_tool_executor(build_echo_executor())
    rt.set_hook_runner(FunctionHookRunner(pre=pre))
    events = await collect_events(rt, "hook", new_state())
    labels = [ev.type for ev in events]
    assert "hook" in labels
    assert labels.index("hook") < labels.index("permission") < labels.index("tool_result")


@pytest.mark.asyncio
async def test_permission_deny_sequence() -> None:
    rt = AgentLoop(StubToolModelClient("echo", "{}"))
    rt.set_tool_executor(build_echo_executor())
    rt.set_permission_policy(DenyListPolicy({"echo"}))
    events = await collect_events(rt, "deny", new_state())
    labels = [ev.type for ev in events]
    permission = next(ev for ev in events if isinstance(ev, PermissionEvent))
    result = next(ev for ev in events if isinstance(ev, ToolResultEvent))
    assert labels.index("tool_use") < labels.index("permission") < labels.index("tool_result")
    assert permission.allowed is False
    assert result.is_error is True
    assert result.output == "permission denied"


@pytest.mark.asyncio
async def test_message_stop_happens_before_tool_execution_path_completes() -> None:
    rt = AgentLoop(StubToolModelClient("echo", "{}"))
    rt.set_tool_executor(build_echo_executor())
    events = await collect_events(rt, "tool", new_state())
    stop_index = next(i for i, ev in enumerate(events) if isinstance(ev, MessageStop))
    tool_result_index = next(i for i, ev in enumerate(events) if isinstance(ev, ToolResultEvent))
    assert stop_index < tool_result_index


@pytest.mark.asyncio
async def test_turn_start_end_wrap_all_events() -> None:
    rt = AgentLoop(EchoModelClient())
    events = await collect_events(rt, "hi", new_state())
    assert isinstance(events[0], TurnStartEvent)
    assert isinstance(events[-1], TurnEndEvent)
    assert events[-1].completed is True
    assert events[-1].iterations_used >= 1
