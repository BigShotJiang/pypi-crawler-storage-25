import pytest

from tada_core.contracts.compaction import StructuredSummaryCompaction
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, EchoModelClient
from tada_core.contracts.session import SessionState


class StaticSummaryModel(EchoModelClient):
    def __init__(self, text: str = "structured summary") -> None:
        self.text = text

    def stream(self, request: ApiRequest):
        _ = request

        async def _gen():
            yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=self.text)
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

        return _gen()


def _message(role: MessageRole, text: str) -> ConversationMessage:
    return ConversationMessage(role=role, content=[ContentBlock(type="text", text=text)])


@pytest.mark.asyncio
async def test_structured_compaction_preserves_head_summary_and_tail() -> None:
    state = SessionState(
        messages=[
            _message(MessageRole.USER, "head"),
            _message(MessageRole.ASSISTANT, "old work"),
            _message(MessageRole.USER, "middle"),
            _message(MessageRole.ASSISTANT, "tail answer"),
            _message(MessageRole.USER, "tail ask"),
        ]
    )
    strategy = StructuredSummaryCompaction(
        StaticSummaryModel(),
        threshold_tokens=1,
        keep_last=2,
        head_protect=1,
    )

    result = await strategy.compact_async(state, trigger="post_llm")

    assert result.removed_message_count == 2
    assert state.messages[0].text_only() == "head"
    assert state.messages[1].text_only().startswith("[compacted summary]")
    assert [m.text_only() for m in state.messages[-2:]] == ["tail answer", "tail ask"]


@pytest.mark.asyncio
async def test_structured_compaction_reports_compacted_message_ids_and_manifest() -> None:
    state = SessionState(
        messages=[
            ConversationMessage(
                id="head",
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="head")],
            ),
            ConversationMessage(
                id="middle-tool",
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id="t1",
                        tool_name="shell",
                        tool_result="x" * 5000,
                    )
                ],
            ),
            ConversationMessage(
                id="tail",
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text="tail")],
            ),
        ]
    )
    strategy = StructuredSummaryCompaction(
        StaticSummaryModel(),
        threshold_tokens=1,
        keep_last=1,
        head_protect=1,
    )

    result = await strategy.compact_async(state, trigger="post_llm")

    assert result.compacted_message_ids == ["middle-tool"]
    assert result.manifest["pruned_tool_count"] == 1
    assert result.pruned_tool_count == 1
    assert state.metadata["compaction"]["compacted_message_ids"] == ["middle-tool"]
    assert state.metadata["compaction"]["manifest"]["pruned_tool_results"][0]["message_id"] == "middle-tool"


@pytest.mark.asyncio
async def test_structured_compaction_expands_tail_within_token_budget() -> None:
    state = SessionState(
        messages=[
            ConversationMessage(id=f"m{i}", role=MessageRole.USER, content=[ContentBlock(type="text", text=f"m{i}")])
            for i in range(6)
        ]
    )
    strategy = StructuredSummaryCompaction(
        StaticSummaryModel(),
        threshold_tokens=1,
        keep_last=2,
        head_protect=1,
        tail_token_budget=6,
    )

    result = await strategy.compact_async(state, trigger="post_llm")

    assert result.compacted_message_ids == ["m1", "m2"]
    assert [message.id for message in state.messages[-3:]] == ["m3", "m4", "m5"]


@pytest.mark.asyncio
async def test_structured_compaction_keeps_tool_use_result_boundary_together() -> None:
    state = SessionState(
        messages=[
            ConversationMessage(id="head", role=MessageRole.USER, content=[ContentBlock(type="text", text="head")]),
            ConversationMessage(
                id="tool-use",
                role=MessageRole.ASSISTANT,
                content=[
                    ContentBlock(
                        type="tool_use",
                        tool_use_id="t1",
                        tool_name="shell",
                        tool_input="{}",
                    )
                ],
            ),
            ConversationMessage(
                id="tool-result",
                role=MessageRole.TOOL,
                content=[
                    ContentBlock(
                        type="tool_result",
                        tool_use_id="t1",
                        tool_name="shell",
                        tool_result="ok",
                    )
                ],
            ),
            ConversationMessage(id="tail", role=MessageRole.USER, content=[ContentBlock(type="text", text="tail")]),
        ]
    )
    strategy = StructuredSummaryCompaction(
        StaticSummaryModel(),
        threshold_tokens=1,
        keep_last=1,
        head_protect=2,
    )

    result = await strategy.compact_async(state, trigger="post_llm")

    assert result.compacted_message_ids == []
    assert [message.id for message in state.messages[:3]] == ["head", "tool-use", "tool-result"]


@pytest.mark.asyncio
async def test_structured_compaction_uses_incremental_summary_metadata() -> None:
    state = SessionState(
        messages=[
            _message(MessageRole.USER, "old"),
            _message(MessageRole.ASSISTANT, "new"),
            _message(MessageRole.USER, "tail"),
        ],
        metadata={"compaction": {"last_summary": "previous summary"}},
    )
    model = StaticSummaryModel("updated summary")
    strategy = StructuredSummaryCompaction(model, threshold_tokens=1, keep_last=1)

    await strategy.compact_async(state, trigger="post_llm")

    compaction = state.metadata["compaction"]
    assert compaction["last_summary"] == "updated summary"
    assert compaction["last_trigger"] == "post_llm"


@pytest.mark.asyncio
async def test_structured_compaction_fallback_sets_cooldown_on_model_error() -> None:
    class BrokenSummaryModel(EchoModelClient):
        def stream(self, request: ApiRequest):
            _ = request
            raise RuntimeError("summary model down")

    state = SessionState(
        messages=[
            _message(MessageRole.USER, "old"),
            _message(MessageRole.ASSISTANT, "new"),
            _message(MessageRole.USER, "tail"),
        ]
    )
    strategy = StructuredSummaryCompaction(BrokenSummaryModel(), threshold_tokens=1, keep_last=1)

    result = await strategy.compact_async(state, trigger="post_llm")

    assert result.summary
    assert "fallback" in result.summary
    assert state.metadata["compaction"]["cooldown_until"] > 0
