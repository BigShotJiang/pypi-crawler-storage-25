import pytest

from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, AssistantEventKind
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport


def _request(text: str = "hello") -> ApiRequest:
    return ApiRequest(
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=[ContentBlock(type="text", text=text)],
            )
        ]
    )


async def _collect(client, request):
    events = []
    async for ev in client.stream(request):
        events.append(ev)
    return events


@pytest.mark.asyncio
async def test_openai_compatible_client_parses_batch_usage() -> None:
    client = OpenAICompatibleModelClient(make_echo_transport(), streaming=False)
    events = await _collect(client, _request("batch"))
    assert any(ev.kind == AssistantEventKind.TEXT_DELTA and ev.text_delta == "batch" for ev in events)
    usage = [ev for ev in events if ev.kind == AssistantEventKind.USAGE]
    assert usage and usage[0].usage is not None
    assert usage[0].usage.input_tokens >= 1


@pytest.mark.asyncio
async def test_openai_compatible_client_streams_text_chunks_incrementally() -> None:
    client = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)
    events = await _collect(client, _request("streaming"))
    texts = [ev.text_delta for ev in events if ev.kind == AssistantEventKind.TEXT_DELTA]
    assert texts == ["stre", "aming"]


@pytest.mark.asyncio
async def test_openai_compatible_client_parses_tool_calls() -> None:
    def transport(request: ApiRequest, stream: bool):
        _ = request, stream
        return {
            "choices": [
                {
                    "message": {
                        "tool_calls": [
                            {
                                "id": "tool-1",
                                "function": {
                                    "name": "echo",
                                    "arguments": '{"ok":true}',
                                },
                            }
                        ]
                    }
                }
            ],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2},
        }

    client = OpenAICompatibleModelClient(transport, streaming=False)
    events = await _collect(client, _request())
    tool_events = [ev for ev in events if ev.kind == AssistantEventKind.TOOL_USE]
    assert tool_events and tool_events[0].tool_name == "echo"
    assert tool_events[0].tool_input == '{"ok":true}'
