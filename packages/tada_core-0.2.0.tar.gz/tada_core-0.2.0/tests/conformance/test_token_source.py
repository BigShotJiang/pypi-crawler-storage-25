from tada_core.contracts.compaction import StructuredSummaryCompaction
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.contracts.model import ApiRequest, EchoModelClient
from tada_core.contracts.session import SessionState, TokenUsage


def _state_with_blocks(*blocks: ContentBlock) -> SessionState:
    return SessionState(
        messages=[
            ConversationMessage(
                role=MessageRole.USER,
                content=list(blocks),
            )
        ]
    )


def test_structured_compaction_prefers_last_usage_true_value() -> None:
    state = _state_with_blocks(ContentBlock(type="text", text="tiny"))
    state.metadata["last_usage"] = TokenUsage(input_tokens=123).model_dump()
    strategy = StructuredSummaryCompaction(EchoModelClient(), threshold_tokens=100)

    assert strategy.estimate_state_tokens(state) == 123
    assert strategy.should_compact(state, trigger="post_llm")


def test_structured_compaction_uses_model_estimator_before_fallback() -> None:
    class EstimatingModel(EchoModelClient):
        def estimate_tokens(self, request: ApiRequest) -> int:
            _ = request
            return 55

    state = _state_with_blocks(ContentBlock(type="text", text="tiny"))
    strategy = StructuredSummaryCompaction(EstimatingModel(), threshold_tokens=40)

    assert strategy.estimate_state_tokens(state) == 55
    assert strategy.should_compact(state, trigger="pre_turn")


def test_structured_compaction_should_compact_counts_system_and_tools() -> None:
    class RequestEstimatingModel(EchoModelClient):
        def estimate_tokens(self, request: ApiRequest) -> int:
            assert request.system_prompt == ["system prompt"]
            assert request.tools == [
                {
                    "type": "function",
                    "function": {"name": "search", "description": "search docs", "parameters": {}},
                }
            ]
            return 90

    state = _state_with_blocks(ContentBlock(type="text", text="tiny"))
    strategy = StructuredSummaryCompaction(RequestEstimatingModel(), threshold_tokens=80)

    assert strategy.should_compact(
        state,
        trigger="pre_turn",
        system_prompt=["system prompt"],
        tools=[
            {
                "type": "function",
                "function": {"name": "search", "description": "search docs", "parameters": {}},
            }
        ],
    )


def test_structured_compaction_fallback_counts_non_text_blocks() -> None:
    state = _state_with_blocks(
        ContentBlock(type="text", text="abcd"),
        ContentBlock(type="tool_use", tool_use_id="t1", tool_name="search", tool_input='{"q":"x"}'),
        ContentBlock(type="tool_result", tool_use_id="t1", tool_name="search", tool_result="result"),
        ContentBlock(type="image", source="base64", mime_type="image/png", data="a" * 20),
    )
    strategy = StructuredSummaryCompaction(EchoModelClient(), image_token_estimate=1500)

    assert strategy.estimate_state_tokens(state) >= 1500
