from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole
from tada_core.loop.message_sanitizer import (
    sanitize_tool_pairs,
    serialize_messages_for_compaction,
)


def test_sanitizer_drops_orphan_tool_result() -> None:
    messages = [
        ConversationMessage(
            role=MessageRole.TOOL,
            content=[
                ContentBlock(
                    type="tool_result",
                    tool_use_id="missing",
                    tool_name="search",
                    tool_result="orphan",
                )
            ],
        )
    ]

    assert sanitize_tool_pairs(messages) == []


def test_sanitizer_adds_stub_for_kept_orphan_tool_use() -> None:
    messages = [
        ConversationMessage(
            role=MessageRole.ASSISTANT,
            content=[
                ContentBlock(
                    type="tool_use",
                    tool_use_id="t1",
                    tool_name="search",
                    tool_input='{"q":"x"}',
                )
            ],
        )
    ]

    sanitized = sanitize_tool_pairs(messages)

    assert len(sanitized) == 2
    assert sanitized[-1].role == MessageRole.TOOL
    stub = sanitized[-1].content[0]
    assert stub.type == "tool_result"
    assert stub.tool_use_id == "t1"
    assert "earlier conversation" in (stub.tool_result or "")


def test_serializer_records_multimodal_manifest_without_binary_payload() -> None:
    messages = [
        ConversationMessage(
            role=MessageRole.USER,
            content=[
                ContentBlock(type="text", text="see file"),
                ContentBlock(
                    type="image",
                    source="base64",
                    mime_type="image/png",
                    data="BINARYDATA",
                    name="shot.png",
                ),
            ],
        )
    ]

    text, manifest = serialize_messages_for_compaction(messages)

    assert "BINARYDATA" not in text
    assert manifest["artifacts"][0]["name"] == "shot.png"
    assert manifest["artifacts"][0]["mime_type"] == "image/png"
