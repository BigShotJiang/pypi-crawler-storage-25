from typing import get_args, get_origin

from tada_core import (
    AgentLoop,
    BudgetLimits,
    CharacterTokenEstimator,
    ChainedToolExecutor,
    CompactionConfig,
    CompactionMode,
    CompactionStrategy,
    ContentNormalizerConfig,
    ContentBlock,
    ConversationMessage,
    Event,
    MessageRole,
    ModelSummaryCompaction,
    NeverCompact,
    SessionState,
    StructuredSummaryCompaction,
    TokenEstimator,
    ToolResult,
    ToolResultPruningConfig,
    TruncateCompaction,
    RetryPolicy,
    RetryingModelClient,
    __all__,
    __version__,
    normalize_messages,
)


def test_package_exports_sdk_surface() -> None:
    assert AgentLoop.__name__ == "AgentLoop"
    assert BudgetLimits.__name__ == "BudgetLimits"
    assert CharacterTokenEstimator.__name__ == "CharacterTokenEstimator"
    assert ChainedToolExecutor.__name__ == "ChainedToolExecutor"
    assert CompactionConfig.__name__ == "CompactionConfig"
    assert CompactionMode.AUTO.value == "auto"
    assert ContentNormalizerConfig.__name__ == "ContentNormalizerConfig"
    assert ContentBlock.__name__ == "ContentBlock"
    assert ConversationMessage.__name__ == "ConversationMessage"
    assert CompactionStrategy.__name__ == "CompactionStrategy"
    assert MessageRole.USER.value == "user"
    assert NeverCompact.__name__ == "NeverCompact"
    assert TruncateCompaction.__name__ == "TruncateCompaction"
    assert ModelSummaryCompaction.__name__ == "ModelSummaryCompaction"
    assert SessionState.__name__ == "SessionState"
    assert StructuredSummaryCompaction.__name__ == "StructuredSummaryCompaction"
    assert ToolResult.__name__ == "ToolResult"
    assert ToolResultPruningConfig.__name__ == "ToolResultPruningConfig"
    assert RetryPolicy.__name__ == "RetryPolicy"
    assert RetryingModelClient.__name__ == "RetryingModelClient"
    assert TokenEstimator is not None
    assert normalize_messages is not None
    assert get_origin(Event) is not None
    assert get_args(Event)
    assert isinstance(__version__, str) and __version__


def test_package___all___lists_sdk_exports() -> None:
    assert set(__all__) == {
        "AgentLoop",
        "AnthropicModelClient",
        "BudgetLimits",
        "CharacterTokenEstimator",
        "ChainedToolExecutor",
        "CompactionConfig",
        "CompactionMode",
        "CompactionStrategy",
        "ContentNormalizerConfig",
        "ContentBlock",
        "ConversationMessage",
        "Event",
        "MessageRole",
        "ModelSpec",
        "ModelSummaryCompaction",
        "NeverCompact",
        "SessionState",
        "StopReason",
        "StructuredSummaryCompaction",
        "TokenEstimator",
        "ToolResult",
        "ToolResultPruningConfig",
        "TruncateCompaction",
        "RetryPolicy",
        "RetryingModelClient",
        "build_model_client",
        "normalize_messages",
        "__version__",
    }


def test_multimodal_content_block_is_public_and_validated() -> None:
    block = ContentBlock(
        type="image",
        source="base64",
        mime_type="image/png",
        data="iVBORw0KGgo=",
    )
    msg = ConversationMessage(role=MessageRole.USER, content=[block])
    assert msg.content[0].mime_type == "image/png"
