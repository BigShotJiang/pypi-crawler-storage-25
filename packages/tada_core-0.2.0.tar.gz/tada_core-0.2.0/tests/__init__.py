"""Test package for tada-core."""
