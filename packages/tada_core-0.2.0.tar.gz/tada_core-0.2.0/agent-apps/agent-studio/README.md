# Agent Studio

多 Agent 统一宿主：共享前后端框架、模型配置与 SSE/trace 协议。通过插件挂载：

| Agent | ID | 说明 |
|-------|-----|------|
| Coding | `coding-agent` | tada-core 验证 + 共享 sandbox 场景 |
| Trip | `trip-agent` | 旅行规划（mock 工具与行程 artifact） |
| Shopping | `shopping-agent` | 购物比价（mock 商品网格 artifact） |

## 布局

- **左侧**：Agent 选择与模型配置
- **主区域**：Chat 对话（默认占满宽度）
- **右侧 Inspector**（按需展开，默认收起）：Tab 切换 **执行节点** / **产物**，不同时并排展示

发送消息或产生产物时会自动展开 Inspector；也可通过 Chat 标题栏「运行详情」手动开关。

## 启动

```bash
# 从 tada-core 根目录
bash agent-apps/agent-studio/dev.sh
```

默认地址：

- Backend: `http://127.0.0.1:8010`
- Frontend: `http://127.0.0.1:3010`

## API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| GET | `/api/agents` | Agent 列表 |
| GET | `/api/agents/{id}/scenarios` | 场景/示例 |
| GET/POST | `/api/config` | 模型配置 |
| POST | `/api/runs` | 统一 SSE 运行（`event: trace\|message\|artifact\|done\|error`） |
| POST | `/api/probe` | coding-agent 确定性探针 |
| GET/DELETE | `/api/session/{agent_id}` | 会话快照/重置 |

`POST /api/runs` 请求体：

```json
{
  "agent_id": "trip-agent",
  "text": "帮我规划东京 3 日游",
  "scenario": "default",
  "reset_session": false
}
```

## 测试

```bash
cd /path/to/tada-core
uv run pytest agent-apps/agent-studio/backend/tests -q
uv run pytest agent-apps/shared/sandbox/tests -q
cd agent-apps/agent-studio/frontend && npm install && npm run build
```

## 与 sandbox 的关系

`coding-agent` 插件通过正式 Python 包 `sandbox` 使用沙箱 runtime、场景、fixtures 与确定性 probe，不修改 `tada_core` 包。Agent Studio 是当前唯一 UI/API 入口，旧 `code-agent` app 已移除。
