import { AgentStudioShell } from './components/AgentStudioShell'

export default function Page() {
  return <AgentStudioShell />
}
