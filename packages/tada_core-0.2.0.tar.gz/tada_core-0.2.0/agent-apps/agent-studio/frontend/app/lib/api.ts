import type {
  AgentDescriptor,
  AgentScenario,
  HostConfig,
  SkillsResponse,
  ToolsResponse,
  WorkspaceFileContent,
  WorkspaceFileInfo,
} from './types'

export function resolveApiBase(): string {
  if (typeof window === 'undefined') {
    return process.env.NEXT_PUBLIC_API_BASE ?? 'http://127.0.0.1:8010'
  }
  const fromEnv = process.env.NEXT_PUBLIC_API_BASE
  if (fromEnv) return fromEnv
  const fromQuery = new URLSearchParams(window.location.search).get('api')
  if (fromQuery) return fromQuery
  return `${window.location.protocol}//${window.location.hostname}:8010`
}

const API_BASE = resolveApiBase()

export async function fetchAgents(): Promise<AgentDescriptor[]> {
  const res = await fetch(`${API_BASE}/api/agents`)
  if (!res.ok) throw new Error(`agents HTTP ${res.status}`)
  return res.json()
}

export async function fetchScenarios(agentId: string): Promise<AgentScenario[]> {
  const res = await fetch(`${API_BASE}/api/agents/${agentId}/scenarios`)
  if (!res.ok) return []
  return res.json()
}

export async function fetchConfig(): Promise<HostConfig> {
  const res = await fetch(`${API_BASE}/api/config`)
  if (!res.ok) throw new Error(`config HTTP ${res.status}`)
  return res.json()
}

export async function saveConfig(body: Partial<HostConfig & { api_key: string }>): Promise<void> {
  const res = await fetch(`${API_BASE}/api/config`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`save config HTTP ${res.status}`)
}

export async function fetchRuntimeConfig(): Promise<HostConfig> {
  const res = await fetch(`${API_BASE}/api/runtime-config`)
  if (!res.ok) throw new Error(`runtime config HTTP ${res.status}`)
  return res.json()
}

export async function saveRuntimeConfig(
  body: Partial<HostConfig & { api_key: string }>,
): Promise<HostConfig> {
  const res = await fetch(`${API_BASE}/api/runtime-config`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`save runtime config HTTP ${res.status}`)
  return res.json()
}

export async function fetchWorkspaceFiles(): Promise<WorkspaceFileInfo[]> {
  const res = await fetch(`${API_BASE}/api/workspace/files`)
  if (!res.ok) throw new Error(`workspace files HTTP ${res.status}`)
  return res.json()
}

export async function fetchWorkspaceFile(filename: string): Promise<WorkspaceFileContent> {
  const res = await fetch(`${API_BASE}/api/workspace/files/${encodeURIComponent(filename)}`)
  if (!res.ok) throw new Error(`workspace file HTTP ${res.status}`)
  return res.json()
}

export async function saveWorkspaceFile(filename: string, content: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/workspace/files/${encodeURIComponent(filename)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content }),
  })
  if (!res.ok) throw new Error(`save workspace file HTTP ${res.status}`)
}

export async function fetchSkills(): Promise<SkillsResponse> {
  const res = await fetch(`${API_BASE}/api/skills`)
  if (!res.ok) throw new Error(`skills HTTP ${res.status}`)
  return res.json()
}

export async function fetchTools(): Promise<ToolsResponse> {
  const res = await fetch(`${API_BASE}/api/tools`)
  if (!res.ok) throw new Error(`tools HTTP ${res.status}`)
  return res.json()
}

export interface RunStreamHandlers {
  onTrace: (node: unknown) => void
  onMessage: (data: { role: string; delta?: string; text?: string; done?: boolean }) => void
  onArtifact: (artifact: unknown) => void
  onDone: (data: unknown) => void
  onError: (err: Error) => void
}

export function openRunStream(
  body: {
    agent_id: string
    text: string
    reset_session?: boolean
    scenario?: string
    task_id?: string | null
  },
  handlers: RunStreamHandlers,
): () => void {
  const ctrl = new AbortController()
  let finished = false

  const finish = (data: unknown) => {
    if (finished) return
    finished = true
    handlers.onDone(data)
  }

  const fail = (err: Error) => {
    if (finished) return
    finished = true
    handlers.onError(err)
  }

  ;(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/runs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: ctrl.signal,
      })
      if (!res.ok) {
        const detail = await res.text().catch(() => '')
        throw new Error(detail || `run HTTP ${res.status}`)
      }
      if (!res.body) throw new Error('run stream has no body')

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const frames = buffer.split('\n\n')
        buffer = frames.pop() ?? ''
        for (const frame of frames) {
          if (!frame.trim()) continue
          const lines = frame.split('\n')
          const eventLine = lines.find(l => l.startsWith('event: '))
          const dataLine = lines.find(l => l.startsWith('data: '))
          if (!eventLine || !dataLine) continue
          const eventName = eventLine.slice(7).trim()
          let data: unknown
          try {
            data = JSON.parse(dataLine.slice(6))
          } catch {
            continue
          }
          switch (eventName) {
            case 'trace':
              handlers.onTrace(data)
              break
            case 'message':
              handlers.onMessage(
                data as { role: string; delta?: string; text?: string; done?: boolean },
              )
              break
            case 'artifact':
              handlers.onArtifact(data)
              break
            case 'done':
              finish(data)
              break
            case 'error':
              fail(new Error(String((data as { message?: string }).message ?? 'run error')))
              break
            default:
              break
          }
        }
      }
      if (!finished) finish({})
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        if (!finished) finish({ aborted: true })
        return
      }
      fail(err as Error)
    }
  })()

  return () => {
    ctrl.abort()
  }
}

export async function runProbe(body: {
  agent_id: string
  scenario: string
  probe_id: string
}): Promise<unknown> {
  const res = await fetch(`${API_BASE}/api/probe`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`probe HTTP ${res.status}`)
  return res.json()
}
