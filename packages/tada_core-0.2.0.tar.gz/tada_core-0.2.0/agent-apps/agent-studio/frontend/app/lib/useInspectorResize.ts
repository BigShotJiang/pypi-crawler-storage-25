'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

const STORAGE_KEY = 'agent-studio.inspector-width'
const DEFAULT_WIDTH = 420
const MIN_WIDTH = 280
const MAX_WIDTH = 880
const NAV_WIDTH = 240
const MAIN_MIN_WIDTH = 360

function clampWidth(value: number): number {
  const maxByViewport = Math.max(
    MIN_WIDTH,
    typeof window !== 'undefined'
      ? window.innerWidth - NAV_WIDTH - MAIN_MIN_WIDTH
      : MAX_WIDTH,
  )
  return Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, Math.min(value, maxByViewport)))
}

function readStoredWidth(): number {
  if (typeof window === 'undefined') return DEFAULT_WIDTH
  const raw = window.localStorage.getItem(STORAGE_KEY)
  if (!raw) return DEFAULT_WIDTH
  const parsed = Number.parseInt(raw, 10)
  if (Number.isNaN(parsed)) return DEFAULT_WIDTH
  return clampWidth(parsed)
}

export function useInspectorResize() {
  const [width, setWidth] = useState(DEFAULT_WIDTH)
  const [isResizing, setIsResizing] = useState(false)
  const dragRef = useRef<{ startX: number; startWidth: number } | null>(null)

  useEffect(() => {
    setWidth(readStoredWidth())
  }, [])

  useEffect(() => {
    const onWindowResize = () => {
      setWidth(w => clampWidth(w))
    }
    window.addEventListener('resize', onWindowResize)
    return () => window.removeEventListener('resize', onWindowResize)
  }, [])

  const onResizePointerDown = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault()
    const handle = event.currentTarget
    dragRef.current = { startX: event.clientX, startWidth: width }
    setIsResizing(true)
    handle.setPointerCapture(event.pointerId)

    const onPointerMove = (ev: PointerEvent) => {
      if (!dragRef.current) return
      const delta = dragRef.current.startX - ev.clientX
      setWidth(clampWidth(dragRef.current.startWidth + delta))
    }

    const endDrag = (ev: PointerEvent) => {
      if (!dragRef.current) return
      dragRef.current = null
      setIsResizing(false)
      setWidth(current => {
        const next = clampWidth(current)
        window.localStorage.setItem(STORAGE_KEY, String(next))
        return next
      })
      if (handle.hasPointerCapture(ev.pointerId)) {
        handle.releasePointerCapture(ev.pointerId)
      }
      window.removeEventListener('pointermove', onPointerMove)
      window.removeEventListener('pointerup', endDrag)
      window.removeEventListener('pointercancel', endDrag)
    }

    window.addEventListener('pointermove', onPointerMove)
    window.addEventListener('pointerup', endDrag)
    window.addEventListener('pointercancel', endDrag)
  }, [width])

  return { width, isResizing, onResizePointerDown }
}
