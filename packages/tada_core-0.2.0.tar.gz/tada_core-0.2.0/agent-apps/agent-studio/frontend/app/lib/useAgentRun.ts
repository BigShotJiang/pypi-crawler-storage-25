'use client'

import { useCallback, useRef, useState } from 'react'

import { openRunStream } from './api'
import type { Artifact, ChatMessage, RunStatus, TraceNode } from './types'

function traceFromPayload(data: Record<string, unknown>): TraceNode {
  return {
    id: String(data.id ?? crypto.randomUUID()),
    runId: data.run_id ? String(data.run_id) : undefined,
    parentId: data.parent_id ? String(data.parent_id) : undefined,
    kind: String(data.kind ?? 'unknown'),
    status: (data.status as TraceNode['status']) ?? 'done',
    title: String(data.title ?? data.kind ?? '事件'),
    summary: String(data.summary ?? ''),
    detail: data.detail ? String(data.detail) : undefined,
    seq: typeof data.seq === 'number' ? data.seq : undefined,
    raw: data.raw as Record<string, unknown> | undefined,
  }
}

function upsertTrace(list: TraceNode[], node: TraceNode): TraceNode[] {
  const idx = list.findIndex(x => x.id === node.id)
  if (idx >= 0) {
    const next = [...list]
    next[idx] = node
    return next
  }
  return [...list, node]
}

function upsertAssistantMessage(
  messages: ChatMessage[],
  text: string,
  runId?: string,
): ChatMessage[] {
  const last = messages[messages.length - 1]
  if (last?.role === 'assistant') {
    return messages.map((msg, i) =>
      i === messages.length - 1 ? { ...msg, text, runId: msg.runId ?? runId } : msg,
    )
  }
  return [...messages, { id: crypto.randomUUID(), role: 'assistant', text, runId }]
}

export function useAgentRun() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [traces, setTraces] = useState<TraceNode[]>([])
  const [artifacts, setArtifacts] = useState<Artifact[]>([])
  const [status, setStatus] = useState<RunStatus>({ running: false, runId: null, error: null })
  const abortRef = useRef<(() => void) | null>(null)
  const runningRef = useRef(false)
  const assistantBuf = useRef('')
  const currentRunId = useRef<string | undefined>(undefined)
  const currentUserMessageId = useRef<string | undefined>(undefined)

  const reset = useCallback(() => {
    abortRef.current?.()
    abortRef.current = null
    runningRef.current = false
    setMessages([])
    setTraces([])
    setArtifacts([])
    setStatus({ running: false, runId: null, error: null })
    assistantBuf.current = ''
    currentRunId.current = undefined
    currentUserMessageId.current = undefined
  }, [])

  const send = useCallback(
    (params: {
      agentId: string
      text: string
      scenario?: string
      resetSession?: boolean
      taskId?: string | null
    }) => {
      const text = params.text.trim()
      if (!text || runningRef.current) return

      runningRef.current = true
      setStatus({ running: true, runId: null, error: null })
      assistantBuf.current = ''
      currentRunId.current = undefined

      const userMessageId = crypto.randomUUID()
      currentUserMessageId.current = userMessageId
      setMessages(m => [...m, { id: userMessageId, role: 'user', text }])

      const close = openRunStream(
        {
          agent_id: params.agentId,
          text,
          reset_session: params.resetSession,
          scenario: params.scenario ?? 'default',
          task_id: params.taskId,
        },
        {
          onTrace: data => {
            const node = traceFromPayload(data as Record<string, unknown>)
            if (node.runId && !currentRunId.current) {
              currentRunId.current = node.runId
              setMessages(m =>
                m.map(msg =>
                  msg.id === currentUserMessageId.current ? { ...msg, runId: node.runId } : msg,
                ),
              )
            }
            setTraces(t => upsertTrace(t, node))
          },
          onMessage: data => {
            if (data.delta) {
              assistantBuf.current += data.delta
              setMessages(m =>
                upsertAssistantMessage(m, assistantBuf.current, currentRunId.current),
              )
            }
            if (data.done) {
              const finalText = data.text ?? assistantBuf.current
              assistantBuf.current = finalText
              setMessages(m => upsertAssistantMessage(m, finalText, currentRunId.current))
            }
          },
          onArtifact: data => {
            const a = data as Artifact
            setArtifacts(prev => {
              if (prev.some(x => x.id === a.id)) return prev
              return [...prev, a]
            })
          },
          onDone: data => {
            runningRef.current = false
            const finalText = assistantBuf.current
            if (finalText) {
              setMessages(m => upsertAssistantMessage(m, finalText, currentRunId.current))
            }
            setTraces(t =>
              t.map(node =>
                node.status === 'running' ? { ...node, status: 'done' as const } : node,
              ),
            )
            setStatus({
              running: false,
              runId: String((data as { run_id?: string }).run_id ?? ''),
              error: null,
            })
            abortRef.current = null
            currentRunId.current = undefined
            currentUserMessageId.current = undefined
          },
          onError: err => {
            runningRef.current = false
            setStatus({ running: false, runId: null, error: err.message })
            abortRef.current = null
            currentRunId.current = undefined
            currentUserMessageId.current = undefined
            setMessages(m => [
              ...m,
              {
                id: crypto.randomUUID(),
                role: 'assistant',
                text: `错误：${err.message}`,
              },
            ])
          },
        },
      )
      abortRef.current = close
    },
    [],
  )

  const stop = useCallback(() => {
    abortRef.current?.()
    abortRef.current = null
    runningRef.current = false
    setStatus(s => ({ ...s, running: false }))
    setTraces(t =>
      t.map(node => (node.status === 'running' ? { ...node, status: 'done' as const } : node)),
    )
    currentRunId.current = undefined
    currentUserMessageId.current = undefined
  }, [])

  const addArtifact = useCallback((artifact: Artifact) => {
    setArtifacts(prev => {
      if (prev.some(x => x.id === artifact.id)) return prev
      return [...prev, artifact]
    })
  }, [])

  const addAssistantMessage = useCallback((text: string) => {
    setMessages(m => [...m, { id: crypto.randomUUID(), role: 'assistant', text }])
  }, [])

  return {
    messages,
    traces,
    artifacts,
    status,
    send,
    stop,
    reset,
    addArtifact,
    addAssistantMessage,
  }
}
