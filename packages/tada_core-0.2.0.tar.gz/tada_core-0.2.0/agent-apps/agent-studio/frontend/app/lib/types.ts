export interface AgentDescriptor {
  id: string
  name: string
  description: string
  icon: string
  accent_color: string
  artifact_kinds: string[]
  example_prompts: string[]
  category: string
  is_default?: boolean
}

export interface AgentScenario {
  id: string
  label: string
  scenario: string
  preset_text: string
  sandbox?: boolean
  group?: string
  description?: string
  probes?: { id: string; title: string; description: string }[]
  primary_output?: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  text: string
  runId?: string
}

export type TraceStatus = 'running' | 'done' | 'error'

export interface TraceNode {
  id: string
  runId?: string
  parentId?: string
  kind: string
  status: TraceStatus
  title: string
  summary: string
  detail?: string
  seq?: number
  raw?: Record<string, unknown>
}

export interface Artifact {
  id: string
  kind: string
  title: string
  payload: Record<string, unknown>
  mime?: string
}

export interface RunStatus {
  running: boolean
  runId: string | null
  error: string | null
}

export interface HostConfig {
  base_url: string
  model_id: string
  protocol: string
  default_agent_id: string
  theme: string
  api_key_set: boolean
  echo_mode: boolean
}

export interface WorkspaceFileInfo {
  filename: string
  path: string
  size: number
  modified_time: number
}

export interface WorkspaceFileContent extends WorkspaceFileInfo {
  content: string
}

export interface SkillInfo {
  id: string
  name: string
  description: string
  group: string
  path: string
  content_preview: string
}

export interface SkillsResponse {
  skills: SkillInfo[]
}

export interface ToolInfo {
  name: string
  description: string
  parameters_schema: Record<string, unknown>
  parallel: boolean
  source: 'core' | 'sandbox' | 'demo'
  agent_id: string
  agent_name: string
  scenario_id?: string | null
  scenario_title?: string | null
}

export interface ToolGroupInfo {
  name: string
  agent_id: string
  source: 'core' | 'sandbox' | 'demo'
  description: string
  tools: ToolInfo[]
  error?: string | null
}

export interface ToolsResponse {
  groups: ToolGroupInfo[]
}
