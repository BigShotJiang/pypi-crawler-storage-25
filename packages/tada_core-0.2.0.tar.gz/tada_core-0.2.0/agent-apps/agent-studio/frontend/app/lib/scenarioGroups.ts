import type { AgentScenario } from './types'

export const SCENARIO_GROUP_LABELS: Record<string, string> = {
  core: 'tada-core 验证',
  fence: '围栏与安全',
  runtime: '运行时与可观测',
  task: '编码实战',
  sandbox: '沙箱场景',
  default: '其他场景',
}

const SANDBOX_GROUP_BY_ID: Record<string, string> = {
  sb_path_jail: 'fence',
  sb_shell_deny: 'fence',
  sb_audit_trace: 'runtime',
  sb_compaction_real: 'runtime',
  sb_steering: 'runtime',
  sb_task_todo_api: 'task',
}

const GROUP_ORDER = ['core', 'fence', 'runtime', 'task', 'sandbox', 'default']

export function resolveScenarioGroup(item: AgentScenario): string {
  if (item.group) return item.group
  if (!item.sandbox) return 'core'
  return SANDBOX_GROUP_BY_ID[item.id] ?? 'sandbox'
}

export interface ScenarioGroup {
  id: string
  label: string
  items: AgentScenario[]
}

export function groupScenarios(scenarios: AgentScenario[]): ScenarioGroup[] {
  const buckets = new Map<string, AgentScenario[]>()

  for (const item of scenarios) {
    const key = resolveScenarioGroup(item)
    const list = buckets.get(key) ?? []
    list.push(item)
    buckets.set(key, list)
  }

  return GROUP_ORDER.filter(id => buckets.has(id)).map(id => ({
    id,
    label: SCENARIO_GROUP_LABELS[id] ?? id,
    items: buckets.get(id) ?? [],
  }))
}
