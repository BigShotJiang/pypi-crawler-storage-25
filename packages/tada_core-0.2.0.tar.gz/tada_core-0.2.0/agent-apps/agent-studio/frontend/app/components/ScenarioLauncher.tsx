'use client'

import type { AgentDescriptor, AgentScenario } from '../lib/types'
import { groupScenarios, resolveScenarioGroup } from '../lib/scenarioGroups'

interface Props {
  agent: AgentDescriptor | null
  scenarios: AgentScenario[]
  running: boolean
  layout: 'starter' | 'inspector'
  scenarioLimit?: number | null
  onSend: (text: string) => void
  onRunScenario: (scenario: AgentScenario) => void
  onRunProbe: (scenario: AgentScenario) => void
}

type ScenarioDensity = 'compact' | 'card'

function ScenarioRow({
  item,
  running,
  onRunScenario,
  onRunProbe,
  density,
}: {
  item: AgentScenario
  running: boolean
  onRunScenario: (scenario: AgentScenario) => void
  onRunProbe: (scenario: AgentScenario) => void
  density: ScenarioDensity
}) {
  if (density === 'compact') {
    return (
      <li className="scenario-row">
        <div className="scenario-row-main">
          <span className="scenario-row-label">{item.label}</span>
          {item.description ? (
            <span className="scenario-row-desc" title={item.description}>
              {item.description}
            </span>
          ) : null}
        </div>
        <div className="scenario-row-actions">
          <button
            type="button"
            className="mini-action"
            disabled={running}
            onClick={() => onRunScenario(item)}
          >
            运行
          </button>
          {item.sandbox && item.probes?.length ? (
            <button
              type="button"
              className="mini-action secondary"
              disabled={running}
              onClick={() => onRunProbe(item)}
            >
              探针
            </button>
          ) : null}
        </div>
      </li>
    )
  }

  return (
    <article className="starter-card scenario-card">
      <span>{item.sandbox ? '沙箱' : '验证'}</span>
      <strong>{item.label}</strong>
      {item.description ? <p className="scenario-card-desc">{item.description}</p> : null}
      <div className="scenario-actions">
        <button
          type="button"
          className="mini-action"
          disabled={running}
          onClick={() => onRunScenario(item)}
        >
          运行
        </button>
        {item.sandbox && item.probes?.length ? (
          <button
            type="button"
            className="mini-action secondary"
            disabled={running}
            onClick={() => onRunProbe(item)}
          >
            探针
          </button>
        ) : null}
      </div>
    </article>
  )
}

export function ScenarioLauncher({
  agent,
  scenarios,
  running,
  layout,
  scenarioLimit = null,
  onSend,
  onRunScenario,
  onRunProbe,
}: Props) {
  const isInspector = layout === 'inspector'
  const isStarter = layout === 'starter'
  const visibleScenarios =
    scenarioLimit != null ? scenarios.slice(0, scenarioLimit) : scenarios
  const allGroups = groupScenarios(visibleScenarios)
  const starterGroupIds = new Set(['core', 'fence'])
  const scenarioGroups = isStarter
    ? allGroups.filter(g => starterGroupIds.has(g.id))
    : allGroups
  const hiddenScenarioCount = isStarter
    ? visibleScenarios.filter(s => !starterGroupIds.has(resolveScenarioGroup(s))).length
    : 0
  const scenarioDensity: ScenarioDensity = isInspector ? 'compact' : 'card'

  const rootClass = isInspector
    ? 'scenario-launcher scenario-launcher-inspector'
    : 'scenario-launcher scenario-launcher-starter'

  return (
    <div className={rootClass}>
      {isInspector && (
        <p className="scenario-launcher-hint">
          按类别选择场景；对话会保留，运行后可在「执行节点」查看过程。
        </p>
      )}

      {agent && agent.example_prompts.length > 0 && (
        <section className={isStarter ? 'starter-section prompt-section' : 'starter-section'}>
          <h3>示例任务</h3>
          <div className={isStarter ? 'starter-prompt-list' : 'prompt-chip-list'}>
            {agent.example_prompts.map(prompt => (
              <button
                key={prompt}
                type="button"
                className={isStarter ? 'starter-prompt-card' : 'prompt-chip'}
                disabled={running}
                title={prompt}
                onClick={() => onSend(prompt)}
              >
                {isStarter ? (
                  <>
                    <span>Prompt</span>
                    <strong>{prompt}</strong>
                  </>
                ) : (
                  prompt
                )}
              </button>
            ))}
          </div>
        </section>
      )}

      {scenarioGroups.map(group => (
        <section key={group.id} className="starter-section scenario-group">
          <h3>{group.label}</h3>
          {isInspector ? (
            <ul className="scenario-row-list">
              {group.items.map(item => (
                <ScenarioRow
                  key={item.id}
                  item={item}
                  running={running}
                  density="compact"
                  onRunScenario={onRunScenario}
                  onRunProbe={onRunProbe}
                />
              ))}
            </ul>
          ) : (
            <div className="starter-grid">
              {group.items.map(item => (
                <ScenarioRow
                  key={item.id}
                  item={item}
                  running={running}
                  density={scenarioDensity}
                  onRunScenario={onRunScenario}
                  onRunProbe={onRunProbe}
                />
              ))}
            </div>
          )}
        </section>
      ))}

      {isStarter && hiddenScenarioCount > 0 && (
        <p className="starter-more-hint">
          另有 {hiddenScenarioCount} 个沙箱/实战场景，请打开「运行详情」→「场景」查看。
        </p>
      )}

      {!agent && <p className="panel-empty">请先在左侧选择一个 Agent。</p>}
    </div>
  )
}
