'use client'

import { useEffect, useState } from 'react'

import { fetchTools } from '../../lib/api'
import type { ToolGroupInfo, ToolInfo } from '../../lib/types'

export function ToolsPage() {
  const [groups, setGroups] = useState<ToolGroupInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [detail, setDetail] = useState<ToolInfo | null>(null)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetchTools()
      .then(data => {
        if (!cancelled) setGroups(data.groups)
      })
      .catch(err => {
        if (!cancelled) setError((err as Error).message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const total = groups.reduce((sum, group) => sum + group.tools.length, 0)
  const activeGroups = groups.filter(group => group.tools.length > 0).length

  return (
    <section className="env-page">
      <header className="env-page-header">
        <div>
          <p className="eyebrow">Agents 环境</p>
          <h1>工具</h1>
          <p>展示每个 Agent runtime 注册给模型使用的工具与参数 schema。</p>
        </div>
        <span className="status-pill">{total} 个工具</span>
      </header>

      {error && <p className="env-error">{error}</p>}
      <div className="env-metric-row">
        <div className="env-metric-card">
          <span>TOOLS</span>
          <strong>{total}</strong>
          <p>runtime 注册工具</p>
        </div>
        <div className="env-metric-card">
          <span>AGENTS</span>
          <strong>{activeGroups}/{groups.length}</strong>
          <p>包含可用工具</p>
        </div>
        <div className="env-metric-card">
          <span>SCHEMA</span>
          <strong>JSON</strong>
          <p>点击卡片查看参数</p>
        </div>
      </div>
      {loading ? (
        <p className="panel-empty">加载工具库存中…</p>
      ) : total === 0 ? (
        <p className="panel-empty">暂无可用工具。</p>
      ) : (
        <div className="env-section-list">
          {groups.map(group => (
            <section key={group.source} className="env-section">
              <div className="env-section-head">
                <div>
                  <h2>{group.name}</h2>
                  <p>{group.description}</p>
                </div>
                <span>{group.tools.length}</span>
              </div>
              {group.error && <p className="env-error">{group.error}</p>}
              <div className="env-card-grid">
                {group.tools.map(tool => (
                  <button
                    key={`${group.agent_id}-${tool.name}`}
                    type="button"
                    className="env-card"
                    onClick={() => setDetail(tool)}
                  >
                    <span className={`env-source-badge env-source-${tool.source}`}>{tool.source}</span>
                    <strong>{tool.name}</strong>
                    <p>{tool.description}</p>
                    <small>{tool.agent_name}{tool.scenario_title ? ` · ${tool.scenario_title}` : ''}</small>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {detail && (
        <div className="env-detail-panel">
          <div className="env-detail-card">
            <div className="env-detail-head">
              <div>
                <p className="eyebrow">{detail.source} · {detail.parallel ? 'parallel' : 'sequential'}</p>
                <h2>{detail.name}</h2>
              </div>
              <button type="button" className="btn-icon" onClick={() => setDetail(null)} aria-label="关闭详情">
                ×
              </button>
            </div>
            <p>{detail.description}</p>
            <div className="env-tool-meta">
              <span>Agent: {detail.agent_name}</span>
              {detail.scenario_title && <span>Scenario: {detail.scenario_title}</span>}
            </div>
            <pre className="raw-json">{JSON.stringify(detail.parameters_schema, null, 2)}</pre>
          </div>
        </div>
      )}
    </section>
  )
}
