'use client'

import type { Artifact } from '../lib/types'
import { ArtifactRenderer } from './ArtifactRenderer'

interface Props {
  artifacts: Artifact[]
  selectedId: string | null
  onSelect: (id: string | null) => void
  embedded?: boolean
}

export function ArtifactPane({ artifacts, selectedId, onSelect, embedded = false }: Props) {
  const selected = artifacts.find(a => a.id === selectedId) ?? artifacts[artifacts.length - 1]

  const body = (
    <>
      {artifacts.length > 1 && (
        <div className="artifact-picker">
          {artifacts.map(a => (
            <button
              key={a.id}
              type="button"
              className={selected?.id === a.id ? 'active' : undefined}
              onClick={() => onSelect(a.id)}
            >
              {a.title}
            </button>
          ))}
        </div>
      )}

      <div className="artifact-body">
        {!selected && (
          <p className="panel-empty">
            运行结束后，行程、商品对比、测试报告等结构化产物会在此渲染。
          </p>
        )}
        {selected && (
          <article className="artifact-card">
            <h3>
              {selected.title}
              <span className="artifact-kind-tag">{selected.kind}</span>
            </h3>
            <ArtifactRenderer artifact={selected} />
          </article>
        )}
      </div>
    </>
  )

  if (embedded) return <div className="inspector-artifact-root">{body}</div>

  return (
    <section className="studio-artifact">
      <header className="panel-header">
        <div>
          <p className="eyebrow">Output</p>
          <h2>产物</h2>
        </div>
        <span className="status-pill">{artifacts.length} 项</span>
      </header>
      {body}
    </section>
  )
}
