'use client'

import type { AgentDescriptor } from '../lib/types'

export type StudioView = 'chat' | 'workspace' | 'skills' | 'tools' | 'runtime-config'

interface Props {
  agents: AgentDescriptor[]
  selectedAgentId: string
  activeView: StudioView
  onSelectAgent: (id: string) => void
  onSelectView: (view: StudioView) => void
}

const ENV_ITEMS: {
  id: Exclude<StudioView, 'chat'>
  label: string
  description: string
  icon: IconName
}[] = [
  { id: 'workspace', label: '工作区', description: '基础 Markdown 与系统上下文', icon: 'briefcase' },
  { id: 'skills', label: '技能', description: '可注入的 SKILL.md 上下文', icon: 'sparkles' },
  { id: 'tools', label: '工具', description: '运行时可用工具库存', icon: 'wrench' },
  { id: 'runtime-config', label: '运行时配置', description: '模型、协议与默认 Agent', icon: 'settings' },
]

type IconName =
  | 'code'
  | 'plane'
  | 'shopping'
  | 'briefcase'
  | 'sparkles'
  | 'wrench'
  | 'settings'

function StudioIcon({ name }: { name: IconName }) {
  const common = {
    width: 15,
    height: 15,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.8,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  }

  switch (name) {
    case 'code':
      return <svg {...common}><path d="m9 18-6-6 6-6" /><path d="m15 6 6 6-6 6" /></svg>
    case 'plane':
      return <svg {...common}><path d="M3 11.5 21 4l-7.5 18-3-7.5L3 11.5Z" /><path d="m10.5 14.5 4-4" /></svg>
    case 'shopping':
      return <svg {...common}><path d="M6 8h15l-2 9H8L6 8Z" /><path d="M6 8 5 4H2" /><path d="M9 21h.01" /><path d="M18 21h.01" /></svg>
    case 'briefcase':
      return <svg {...common}><path d="M10 6V5a2 2 0 0 1 2-2h0a2 2 0 0 1 2 2v1" /><path d="M4 7h16v12H4z" /><path d="M4 12h16" /></svg>
    case 'sparkles':
      return <svg {...common}><path d="m12 3 1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6L12 3Z" /><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z" /></svg>
    case 'wrench':
      return <svg {...common}><path d="M14.7 6.3a4 4 0 0 0 5 5L11 20l-4-4 8.7-8.7Z" /><path d="m7 16-3 3" /></svg>
    case 'settings':
      return <svg {...common}><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" /><path d="M19 12a7 7 0 0 0-.1-1.1l2-1.5-2-3.4-2.4 1a7 7 0 0 0-1.9-1.1L14.3 3h-4.6l-.4 2.9A7 7 0 0 0 7.5 7L5 6 3 9.4l2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.1l-2 1.5 2 3.4 2.4-1a7 7 0 0 0 1.9 1.1l.4 2.9h4.6l.4-2.9a7 7 0 0 0 1.9-1.1l2.4 1 2-3.4-2-1.5c.1-.3.1-.7.1-1.1Z" /></svg>
  }
}

function agentIcon(agent: AgentDescriptor): IconName {
  if (agent.id.includes('trip')) return 'plane'
  if (agent.id.includes('shopping')) return 'shopping'
  return 'code'
}

export function StudioSidebar({
  agents,
  selectedAgentId,
  activeView,
  onSelectAgent,
  onSelectView,
}: Props) {
  return (
    <nav className="studio-sidebar" aria-label="Agent Studio 导航">
      <section className="sidebar-group">
        <button type="button" className="sidebar-group-title" aria-expanded="true">
          <span>Agents</span>
        </button>
        <div className="sidebar-group-list">
          {agents.map(agent => {
            const active = activeView === 'chat' && selectedAgentId === agent.id
            return (
              <button
                key={agent.id}
                type="button"
                className={active ? 'sidebar-item active' : 'sidebar-item'}
                onClick={() => onSelectAgent(agent.id)}
                style={
                  active
                    ? { borderColor: agent.accent_color, boxShadow: `inset 3px 0 0 ${agent.accent_color}` }
                    : undefined
                }
              >
                <span className="sidebar-item-icon" aria-hidden="true">
                  <StudioIcon name={agentIcon(agent)} />
                </span>
                <span className="sidebar-item-copy">
                  <strong>{agent.name}</strong>
                  <span>{agent.description}</span>
                </span>
              </button>
            )
          })}
        </div>
      </section>

      <section className="sidebar-group">
        <button type="button" className="sidebar-group-title" aria-expanded="true">
          <span>Agents 环境</span>
        </button>
        <div className="sidebar-group-list">
          {ENV_ITEMS.map(item => (
            <button
              key={item.id}
              type="button"
              className={activeView === item.id ? 'sidebar-item active' : 'sidebar-item'}
              onClick={() => onSelectView(item.id)}
            >
              <span className="sidebar-item-icon" aria-hidden="true">
                <StudioIcon name={item.icon} />
              </span>
              <span className="sidebar-item-copy">
                <strong>{item.label}</strong>
                <span>{item.description}</span>
              </span>
            </button>
          ))}
        </div>
      </section>
    </nav>
  )
}
