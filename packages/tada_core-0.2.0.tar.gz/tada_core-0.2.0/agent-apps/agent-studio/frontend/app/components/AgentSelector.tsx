'use client'

import type { AgentDescriptor } from '../lib/types'

interface Props {
  agents: AgentDescriptor[]
  selectedId: string
  onSelect: (id: string) => void
}

export function AgentSelector({ agents, selectedId, onSelect }: Props) {
  return (
    <nav className="agent-list">
      {agents.map(agent => (
        <button
          key={agent.id}
          type="button"
          className={selectedId === agent.id ? 'active' : undefined}
          onClick={() => onSelect(agent.id)}
          style={
            selectedId === agent.id
              ? { borderColor: agent.accent_color, boxShadow: `inset 3px 0 0 ${agent.accent_color}` }
              : undefined
          }
        >
          <span className="agent-avatar" aria-hidden="true">
            {agent.name
              .split(' ')
              .map(part => part[0])
              .join('')
              .slice(0, 2)}
          </span>
          <span className="agent-copy">
            <strong>{agent.name}</strong>
            <span>{agent.description}</span>
          </span>
        </button>
      ))}
    </nav>
  )
}
