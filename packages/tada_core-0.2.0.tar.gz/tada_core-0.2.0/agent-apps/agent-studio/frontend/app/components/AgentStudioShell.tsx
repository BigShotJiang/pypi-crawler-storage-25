'use client'

import { useCallback, useEffect, useRef, useState } from 'react'

import { fetchAgents, fetchConfig, fetchScenarios, runProbe } from '../lib/api'
import { useAgentRun } from '../lib/useAgentRun'
import { useInspectorResize } from '../lib/useInspectorResize'
import type { AgentDescriptor, AgentScenario, HostConfig } from '../lib/types'
import { ChatPane } from './ChatPane'
import { RuntimeConfigPage } from './environment/RuntimeConfigPage'
import { SkillsPage } from './environment/SkillsPage'
import { ToolsPage } from './environment/ToolsPage'
import { WorkspacePage } from './environment/WorkspacePage'
import { InspectorPanel, type InspectorTab } from './InspectorPanel'
import { SettingsDrawer } from './SettingsDrawer'
import { StudioSidebar, type StudioView } from './StudioSidebar'

export function AgentStudioShell() {
  const [agents, setAgents] = useState<AgentDescriptor[]>([])
  const [selectedId, setSelectedId] = useState('coding-agent')
  const [scenarios, setScenarios] = useState<AgentScenario[]>([])
  const [scenario, setScenario] = useState('default')
  const [config, setConfig] = useState<HostConfig | null>(null)
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [inspectorOpen, setInspectorOpen] = useState(false)
  const [inspectorTab, setInspectorTab] = useState<InspectorTab>('trace')
  const [activeView, setActiveView] = useState<StudioView>('chat')
  const agentsBootstrapped = useRef(false)
  const prevArtifactCount = useRef(0)
  const wasRunning = useRef(false)

  const {
    messages,
    traces,
    artifacts,
    status,
    send,
    stop,
    reset,
    addArtifact,
  } = useAgentRun()

  const selectedAgent = agents.find(a => a.id === selectedId) ?? null
  const activeScenarioLabel =
    scenarios.find(s => s.scenario === scenario)?.label ??
    (scenario === 'default' ? null : scenario)

  const loadAgents = useCallback(async () => {
    const list = await fetchAgents()
    setAgents(list)
    if (!agentsBootstrapped.current) {
      const def = list.find(a => a.is_default) ?? list[0]
      if (def) setSelectedId(def.id)
      agentsBootstrapped.current = true
    }
  }, [])

  const loadConfig = useCallback(async () => {
    setConfig(await fetchConfig())
  }, [])

  useEffect(() => {
    void loadAgents()
    void loadConfig()
  }, [loadAgents, loadConfig])

  useEffect(() => {
    void fetchScenarios(selectedId).then(setScenarios)
    setScenario('default')
    reset()
    setSelectedArtifactId(null)
    setInspectorOpen(false)
    setInspectorTab('trace')
    prevArtifactCount.current = 0
  }, [selectedId, reset])

  // 运行结束后若有新产物，再切到产物 Tab（运行中不抢焦点）
  useEffect(() => {
    const justFinished = wasRunning.current && !status.running
    wasRunning.current = status.running

    if (justFinished && artifacts.length > prevArtifactCount.current && artifacts.length > 0) {
      const latest = artifacts[artifacts.length - 1]
      setSelectedArtifactId(latest.id)
      setInspectorTab('artifact')
      setInspectorOpen(true)
    }
    prevArtifactCount.current = artifacts.length
  }, [artifacts, status.running])

  const handleReset = useCallback(() => {
    reset()
    setSelectedArtifactId(null)
    setInspectorOpen(false)
    setInspectorTab('trace')
    prevArtifactCount.current = 0
  }, [reset])

  const handleSend = useCallback(
    (text: string) => {
      if (config?.echo_mode) {
        setSettingsOpen(true)
        return
      }
      setScenario('default')
      setInspectorOpen(true)
      setInspectorTab('trace')
      send({
        agentId: selectedId,
        text,
        scenario: 'default',
      })
    },
    [config?.echo_mode, send, selectedId],
  )

  const handleRunScenario = useCallback(
    (item: AgentScenario) => {
      if (config?.echo_mode) {
        setSettingsOpen(true)
        return
      }
      setScenario(item.scenario)
      setInspectorOpen(true)
      setInspectorTab('trace')
      send({
        agentId: selectedId,
        text: item.preset_text,
        scenario: item.scenario,
      })
    },
    [config?.echo_mode, send, selectedId],
  )

  const openScenariosTab = useCallback(() => {
    setInspectorOpen(true)
    setInspectorTab('scenarios')
  }, [])

  const handleSelectAgent = useCallback((agentId: string) => {
    setSelectedId(agentId)
    setActiveView('chat')
  }, [])

  const handleSelectView = useCallback((view: StudioView) => {
    setActiveView(view)
    if (view !== 'chat') {
      setInspectorOpen(false)
    }
  }, [])

  const handleProbe = useCallback(async (target?: AgentScenario) => {
    const active = target ?? scenarios.find(s => s.scenario === scenario)
    const probeId = active?.probes?.[0]?.id
    if (!probeId || !active?.sandbox) return
    try {
      const result = await runProbe({
        agent_id: 'coding-agent',
        scenario: active.scenario,
        probe_id: probeId,
      })
      const probeArtifact = {
        id: `probe-${probeId}`,
        kind: 'json',
        title: String((result as { title?: string }).title ?? 'Probe 结果'),
        payload: result as Record<string, unknown>,
      }
      addArtifact(probeArtifact)
      setSelectedArtifactId(probeArtifact.id)
      setInspectorTab('artifact')
      setInspectorOpen(true)
    } catch (err) {
      addArtifact({
        id: `probe-error-${Date.now()}`,
        kind: 'json',
        title: '探针失败',
        payload: { error: (err as Error).message },
      })
      setInspectorTab('artifact')
      setInspectorOpen(true)
    }
  }, [scenarios, scenario, addArtifact])

  const { width: inspectorWidth, isResizing, onResizePointerDown } = useInspectorResize()

  const showInspector = activeView === 'chat' && inspectorOpen
  const shellClass = showInspector ? 'studio-shell inspector-open' : 'studio-shell'
  const shellStyle = showInspector
    ? ({ gridTemplateColumns: `240px minmax(0, 1fr) ${inspectorWidth}px` } as const)
    : undefined

  return (
    <div
      className={shellClass}
      style={shellStyle}
      data-inspector-resizing={isResizing ? '' : undefined}
    >
      <aside className="studio-nav">
        <div className="studio-brand">
          <div className="studio-brand-mark">AS</div>
          <div>
            <strong>Agent Studio</strong>
            <span>Chat · Trace · Artifact</span>
          </div>
        </div>
        <StudioSidebar
          agents={agents}
          selectedAgentId={selectedId}
          activeView={activeView}
          onSelectAgent={handleSelectAgent}
          onSelectView={handleSelectView}
        />
        <SettingsDrawer
          config={config}
          open={settingsOpen}
          onOpenChange={setSettingsOpen}
          onSaved={loadConfig}
        />
      </aside>

      <main className="studio-main">
        {activeView === 'chat' ? (
          <ChatPane
            agent={selectedAgent}
            messages={messages}
            traces={traces}
            status={status}
            scenarios={scenarios}
            onSend={handleSend}
            onRunScenario={handleRunScenario}
            onRunProbe={item => void handleProbe(item)}
            onStop={stop}
            onReset={handleReset}
            echoMode={Boolean(config?.echo_mode)}
            onOpenConfig={() => setSettingsOpen(true)}
            inspectorOpen={inspectorOpen}
            traceCount={traces.length}
            artifactCount={artifacts.length}
            onToggleInspector={() => setInspectorOpen(o => !o)}
            activeScenarioLabel={activeScenarioLabel}
            onOpenScenarios={openScenariosTab}
          />
        ) : activeView === 'workspace' ? (
          <WorkspacePage />
        ) : activeView === 'skills' ? (
          <SkillsPage />
        ) : activeView === 'tools' ? (
          <ToolsPage />
        ) : (
          <RuntimeConfigPage
            agents={agents}
            config={config}
            onSaved={setConfig}
          />
        )}
      </main>

      <InspectorPanel
        open={showInspector}
        tab={inspectorTab}
        agent={selectedAgent}
        scenarios={scenarios}
        traces={traces}
        artifacts={artifacts}
        selectedArtifactId={selectedArtifactId}
        running={status.running}
        isResizing={isResizing}
        onResizePointerDown={onResizePointerDown}
        onTabChange={setInspectorTab}
        onClose={() => setInspectorOpen(false)}
        onSelectArtifact={setSelectedArtifactId}
        onSend={handleSend}
        onRunScenario={handleRunScenario}
        onRunProbe={item => void handleProbe(item)}
      />
    </div>
  )
}
