'use client'

import { useEffect, useMemo, useState } from 'react'

import { fetchSkills } from '../../lib/api'
import type { SkillInfo } from '../../lib/types'

export function SkillsPage() {
  const [skills, setSkills] = useState<SkillInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [detail, setDetail] = useState<SkillInfo | null>(null)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetchSkills()
      .then(data => {
        if (!cancelled) setSkills(data.skills)
      })
      .catch(err => {
        if (!cancelled) setError((err as Error).message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const groups = useMemo(() => {
    return skills.reduce<Record<string, SkillInfo[]>>((acc, skill) => {
      const key = skill.group
      acc[key] = acc[key] ?? []
      acc[key].push(skill)
      return acc
    }, {})
  }, [skills])

  return (
    <section className="env-page">
      <header className="env-page-header">
        <div>
          <p className="eyebrow">Agents 环境</p>
          <h1>技能</h1>
          <p>展示可注入 Agent 上下文的真实 SKILL.md 模块；未配置 skill 时该菜单会自动隐藏。</p>
        </div>
        <span className="status-pill">{skills.length} 项</span>
      </header>

      {error && <p className="env-error">{error}</p>}
      <div className="env-metric-row">
        <div className="env-metric-card">
          <span>SKILLS</span>
          <strong>{skills.length}</strong>
          <p>已发现 SKILL.md</p>
        </div>
        <div className="env-metric-card">
          <span>GROUPS</span>
          <strong>{Object.keys(groups).length}</strong>
          <p>按目录归组</p>
        </div>
        <div className="env-metric-card">
          <span>SOURCE</span>
          <strong>Repo</strong>
          <p>仅展示当前项目内 skill</p>
        </div>
      </div>
      {loading ? (
        <p className="panel-empty">加载技能清单中…</p>
      ) : skills.length === 0 ? (
        <div className="env-empty-card">
          <strong>当前项目未发现 SKILL.md</strong>
          <p>技能是可注入 Agent 上下文的常规模块。把 `SKILL.md` 放到项目的 agent context 目录后，这里会自动显示。</p>
        </div>
      ) : (
        <div className="env-section-list">
          {Object.entries(groups).map(([groupName, items]) => (
            <section key={groupName} className="env-section">
              <div className="env-section-head">
                <h2>{groupName}</h2>
                <span>{items.length}</span>
              </div>
              <div className="env-card-grid">
                {items.map(skill => (
                  <button
                    key={`${skill.path}-${skill.id}`}
                    type="button"
                    className="env-card"
                    onClick={() => setDetail(skill)}
                  >
                    <span>SKILL.md</span>
                    <strong>{skill.name}</strong>
                    <p>{skill.description}</p>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {detail && (
        <div className="env-detail-panel">
          <div className="env-detail-card">
            <div className="env-detail-head">
              <div>
                <p className="eyebrow">{detail.group}</p>
                <h2>{detail.name}</h2>
              </div>
              <button type="button" className="btn-icon" onClick={() => setDetail(null)} aria-label="关闭详情">
                ×
              </button>
            </div>
            <p>{detail.description}</p>
            <code className="env-path">{detail.path}</code>
            {detail.content_preview && <pre className="raw-json">{detail.content_preview}</pre>}
          </div>
        </div>
      )}
    </section>
  )
}
