'use client'

import { useEffect, useState } from 'react'

import { saveConfig } from '../lib/api'
import type { HostConfig } from '../lib/types'

interface Props {
  config: HostConfig | null
  onSaved: () => void
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SettingsDrawer({ config, onSaved, open, onOpenChange }: Props) {
  const [baseUrl, setBaseUrl] = useState('')
  const [modelId, setModelId] = useState('')
  const [protocol, setProtocol] = useState<'anthropic' | 'openai'>('anthropic')
  const [apiKey, setApiKey] = useState('')
  const [savedHint, setSavedHint] = useState<string | null>(null)

  useEffect(() => {
    if (!open || !config) return
    setBaseUrl(config.base_url ?? '')
    setModelId(config.model_id ?? '')
    setProtocol(config.protocol === 'openai' ? 'openai' : 'anthropic')
    setApiKey('')
  }, [open, config])

  const updateBaseUrl = (value: string) => {
    setBaseUrl(value)
    const lower = value.toLowerCase()
    if (lower.includes('openai')) {
      setProtocol('openai')
    } else if (lower.includes('anthropic')) {
      setProtocol('anthropic')
    }
  }

  return (
    <div className="config-drawer">
      <button type="button" className="btn-ghost" onClick={() => onOpenChange(true)}>
        模型配置
      </button>
      {open && (
        <div className="settings-overlay" role="presentation" onClick={() => onOpenChange(false)}>
          <section
            className="settings-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-title"
            onClick={e => e.stopPropagation()}
          >
            <header className="settings-modal-header">
              <div>
                <p className="eyebrow">Model Connection</p>
                <h2 id="settings-title">配置模型</h2>
              </div>
              <button type="button" className="btn-icon" onClick={() => onOpenChange(false)}>
                ×
              </button>
            </header>

            <div className="settings-modal-body">
              <p className="settings-help">
                配置会写入本地 `agent-apps/agent-studio/backend/.config.json`，用于一次配置、多次使用。该文件已加入 gitignore，不会提交到仓库。
              </p>
              <label>
                API Key
                <input
                  type="password"
                  value={apiKey}
                  onChange={e => setApiKey(e.target.value)}
                  placeholder={config?.api_key_set ? '已设置（留空不修改）' : 'Anthropic or token-router API key'}
                  autoFocus
                />
              </label>
              <label>
                Model ID
                <input
                  value={modelId}
                  onChange={e => setModelId(e.target.value)}
                  placeholder="claude-sonnet-4-6"
                />
              </label>
              <label>
                API 协议
                <select value={protocol} onChange={e => setProtocol(e.target.value as 'anthropic' | 'openai')}>
                  <option value="anthropic">Anthropic Messages API (/v1/messages)</option>
                  <option value="openai">OpenAI Compatible (/v1/chat/completions)</option>
                </select>
              </label>
              <label>
                Base URL
                <input
                  value={baseUrl}
                  onChange={e => updateBaseUrl(e.target.value)}
                  placeholder="https://api.anthropic.com 或 OpenAI-compatible 代理地址"
                />
              </label>
              {protocol === 'openai' && (
                <p className="settings-state">
                  当前会请求 <code>/v1/chat/completions</code>；适用于 sg-router / OpenAI-compatible 网关。
                </p>
              )}
              <p className={config?.echo_mode ? 'settings-state warning' : 'settings-state'}>
                {config?.echo_mode ? '当前为 Echo 模式：未配置 API Key' : '已检测到 API Key'}
              </p>
              {savedHint && <p className="settings-state success">{savedHint}</p>}
            </div>

            <footer className="settings-modal-footer">
              <button type="button" className="btn-ghost" onClick={() => onOpenChange(false)}>
                取消
              </button>
              <button
                type="button"
                className="btn-primary"
                onClick={async () => {
                  await saveConfig({
                    base_url: baseUrl,
                    model_id: modelId,
                    protocol,
                    ...(apiKey ? { api_key: apiKey } : {}),
                  })
                  setSavedHint('已保存到本地配置文件')
                  setApiKey('')
                  await onSaved()
                  onOpenChange(false)
                }}
              >
                保存并使用
              </button>
            </footer>
          </section>
        </div>
      )}
    </div>
  )
}
