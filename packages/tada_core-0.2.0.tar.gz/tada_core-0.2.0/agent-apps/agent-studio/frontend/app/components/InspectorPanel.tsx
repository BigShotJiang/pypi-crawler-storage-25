'use client'

import type { AgentDescriptor, AgentScenario, Artifact, TraceNode } from '../lib/types'
import { ArtifactPane } from './ArtifactPane'
import { ScenarioLauncher } from './ScenarioLauncher'
import { TracePane } from './TracePane'

export type InspectorTab = 'trace' | 'artifact' | 'scenarios'

interface Props {
  open: boolean
  tab: InspectorTab
  agent: AgentDescriptor | null
  scenarios: AgentScenario[]
  traces: TraceNode[]
  artifacts: Artifact[]
  selectedArtifactId: string | null
  running: boolean
  isResizing?: boolean
  onResizePointerDown?: (event: React.PointerEvent<HTMLDivElement>) => void
  onTabChange: (tab: InspectorTab) => void
  onClose: () => void
  onSelectArtifact: (id: string | null) => void
  onSend: (text: string) => void
  onRunScenario: (scenario: AgentScenario) => void
  onRunProbe: (scenario: AgentScenario) => void
}

export function InspectorPanel({
  open,
  tab,
  agent,
  scenarios,
  traces,
  artifacts,
  selectedArtifactId,
  running,
  isResizing = false,
  onResizePointerDown,
  onTabChange,
  onClose,
  onSelectArtifact,
  onSend,
  onRunScenario,
  onRunProbe,
}: Props) {
  if (!open) return null
  const activeTab = tab === 'artifact' && artifacts.length === 0 ? 'trace' : tab

  return (
    <aside
      className={`studio-inspector${isResizing ? ' is-resizing' : ''}`}
      aria-label="运行详情"
    >
      {onResizePointerDown ? (
        <div
          className="inspector-resize-handle"
          role="separator"
          aria-orientation="vertical"
          aria-label="拖动调整面板宽度"
          onPointerDown={onResizePointerDown}
        />
      ) : null}
      <header className="inspector-toolbar">
        <div className="inspector-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'trace'}
            className={activeTab === 'trace' ? 'active' : undefined}
            onClick={() => onTabChange('trace')}
          >
            Trace
            {traces.length > 0 && <span className="tab-badge">{traces.length}</span>}
          </button>
          {artifacts.length > 0 && (
            <button
              type="button"
              role="tab"
              aria-selected={activeTab === 'artifact'}
              className={activeTab === 'artifact' ? 'active' : undefined}
              onClick={() => onTabChange('artifact')}
            >
              产物
              <span className="tab-badge">{artifacts.length}</span>
            </button>
          )}
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'scenarios'}
            className={activeTab === 'scenarios' ? 'active' : undefined}
            onClick={() => onTabChange('scenarios')}
          >
            场景
            {scenarios.length > 0 && <span className="tab-badge">{scenarios.length}</span>}
          </button>
        </div>
        <button type="button" className="btn-icon" onClick={onClose} title="收起面板">
          ×
        </button>
      </header>

      <div className="inspector-body" role="tabpanel">
        {activeTab === 'trace' && <TracePane traces={traces} running={running} embedded />}
        {activeTab === 'artifact' && (
          <ArtifactPane
            artifacts={artifacts}
            selectedId={selectedArtifactId}
            onSelect={onSelectArtifact}
            embedded
          />
        )}
        {activeTab === 'scenarios' && (
          <ScenarioLauncher
            agent={agent}
            scenarios={scenarios}
            running={running}
            layout="inspector"
            onSend={onSend}
            onRunScenario={onRunScenario}
            onRunProbe={onRunProbe}
          />
        )}
      </div>
    </aside>
  )
}
