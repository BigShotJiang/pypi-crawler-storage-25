'use client'

import { useMemo, useState, type CSSProperties } from 'react'

import type { TraceNode } from '../lib/types'

interface Props {
  traces: TraceNode[]
  running: boolean
  embedded?: boolean
}

function groupTracesByRun(traces: TraceNode[]): TraceNode[][] {
  const groups = new Map<string, TraceNode[]>()
  traces.forEach(node => {
    const runId = node.runId ?? 'current'
    const group = groups.get(runId) ?? []
    group.push(node)
    groups.set(runId, group)
  })
  return Array.from(groups.values())
}

function traceDepth(node: TraceNode, byId: Map<string, TraceNode>, seen = new Set<string>()): number {
  if (!node.parentId || seen.has(node.id)) return 0
  const parent = byId.get(node.parentId)
  if (!parent) return 0
  seen.add(node.id)
  return Math.min(traceDepth(parent, byId, seen) + 1, 4)
}

export function TracePane({ traces, running, embedded = false }: Props) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(() => new Set())
  const groups = useMemo(() => groupTracesByRun(traces), [traces])

  const toggleExpanded = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const list = (
    <div className="trace-list">
      {traces.length === 0 && (
        <p className="panel-empty">
          发送消息后，模型调用、工具执行、权限与 Hook 会按时间顺序出现在这里。
        </p>
      )}
      {groups.map((group, groupIndex) => {
        const byId = new Map(group.map(node => [node.id, node]))
        return (
          <div key={group[0]?.runId ?? `group-${groupIndex}`} className="trace-run-group">
            {groups.length > 1 && (
              <div className="trace-run-label">Query {groupIndex + 1}</div>
            )}
            {group.map(node => {
              const expanded = expandedIds.has(node.id)
              const hasDetail = Boolean(node.summary || node.detail)
              const depth = traceDepth(node, byId)
              return (
                <article
                  key={node.id}
                  className={`trace-node-shell depth-${depth}`}
                  style={{ '--trace-depth': depth } as CSSProperties}
                >
                  <span className="trace-connector" aria-hidden="true" />
                  <button
                    type="button"
                    className={`trace-node ${node.status}`}
                    aria-expanded={expanded}
                    onClick={() => hasDetail && toggleExpanded(node.id)}
                  >
                    <div className="trace-node-head">
                      <strong>{node.title}</strong>
                      <span className={`trace-status ${node.status}`}>{node.status}</span>
                    </div>
                    <span className="trace-kind">{node.kind}</span>
                    {expanded && node.summary && (
                      <p className="trace-summary">{node.summary}</p>
                    )}
                    {expanded && node.detail && node.detail !== node.summary && (
                      <pre className="raw-json trace-detail">{node.detail}</pre>
                    )}
                  </button>
                </article>
              )
            })}
          </div>
        )
      })}
      {running && traces.length > 0 && (
        <p className="trace-live-hint">正在接收新的 trace 节点…</p>
      )}
    </div>
  )

  if (embedded) return <div className="inspector-trace-root">{list}</div>

  return (
    <section className="studio-trace">
      <header className="panel-header">
        <div>
          <p className="eyebrow">Runtime</p>
          <h2>Trace</h2>
        </div>
        <span className={`status-pill ${running ? 'running' : ''}`}>{traces.length} 节点</span>
      </header>
      {list}
    </section>
  )
}
