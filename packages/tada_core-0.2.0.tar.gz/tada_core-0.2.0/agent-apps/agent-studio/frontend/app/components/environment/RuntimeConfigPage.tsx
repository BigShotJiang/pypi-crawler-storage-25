'use client'

import { useEffect, useState } from 'react'

import { fetchRuntimeConfig, saveRuntimeConfig } from '../../lib/api'
import type { AgentDescriptor, HostConfig } from '../../lib/types'

interface Props {
  agents: AgentDescriptor[]
  config: HostConfig | null
  onSaved: (config: HostConfig) => void
}

const EMPTY_FORM = {
  base_url: '',
  api_key: '',
  model_id: '',
  protocol: 'anthropic',
  default_agent_id: 'coding-agent',
  theme: 'cursor-dark',
}

export function RuntimeConfigPage({ agents, config, onSaved }: Props) {
  const [form, setForm] = useState(EMPTY_FORM)
  const [loading, setLoading] = useState(!config)
  const [saving, setSaving] = useState(false)
  const [status, setStatus] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (config) {
      setForm({
        base_url: config.base_url,
        api_key: '',
        model_id: config.model_id,
        protocol: config.protocol,
        default_agent_id: config.default_agent_id,
        theme: config.theme,
      })
      return
    }

    let cancelled = false
    setLoading(true)
    fetchRuntimeConfig()
      .then(data => {
        if (cancelled) return
        onSaved(data)
        setForm({
          base_url: data.base_url,
          api_key: '',
          model_id: data.model_id,
          protocol: data.protocol,
          default_agent_id: data.default_agent_id,
          theme: data.theme,
        })
      })
      .catch(err => {
        if (!cancelled) setError((err as Error).message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [config, onSaved])

  const setField = (key: keyof typeof EMPTY_FORM, value: string) => {
    setForm(current => ({ ...current, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    setStatus(null)
    setError(null)
    try {
      const saved = await saveRuntimeConfig(form)
      onSaved(saved)
      setForm(current => ({ ...current, api_key: '' }))
      setStatus('运行时配置已保存。')
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className="env-page">
      <header className="env-page-header">
        <div>
          <p className="eyebrow">Agents 环境</p>
          <h1>运行时配置</h1>
          <p>配置模型连接、协议和默认 Agent；保存后会同步影响新一轮运行。</p>
        </div>
        <span className={config?.echo_mode ? 'status-pill error' : 'status-pill'}>
          {config?.echo_mode ? 'Echo 模式' : '模型已配置'}
        </span>
      </header>

      {loading ? (
        <p className="panel-empty">加载运行时配置中…</p>
      ) : (
        <div className="runtime-config-layout">
          <aside className="runtime-config-summary">
            <div className="env-metric-card">
              <span>MODE</span>
              <strong>{config?.echo_mode ? 'Echo' : 'Live'}</strong>
              <p>{config?.api_key_set ? 'API Key 已保存' : '未配置 API Key'}</p>
            </div>
            <div className="env-metric-card">
              <span>MODEL</span>
              <strong>{form.model_id || 'Default'}</strong>
              <p>{form.protocol}</p>
            </div>
            <div className="env-metric-card">
              <span>DEFAULT</span>
              <strong>{agents.find(agent => agent.id === form.default_agent_id)?.name ?? form.default_agent_id}</strong>
              <p>默认运行 Agent</p>
            </div>
          </aside>

          <div className="runtime-config-card">
            {error && <p className="env-error">{error}</p>}
            {status && <p className="env-success">{status}</p>}

            <label>
              <span>Base URL</span>
              <input value={form.base_url} onChange={event => setField('base_url', event.target.value)} placeholder="https://api.example.com" />
            </label>

            <label>
              <span>API Key</span>
              <input
                value={form.api_key}
                onChange={event => setField('api_key', event.target.value)}
                placeholder={config?.api_key_set ? '已保存，可留空' : '未设置时将使用 Echo 模式'}
                type="password"
              />
            </label>

            <label>
              <span>Model ID</span>
              <input value={form.model_id} onChange={event => setField('model_id', event.target.value)} placeholder="claude-sonnet-4-6" />
            </label>

            <div className="runtime-config-grid">
              <label>
                <span>Protocol</span>
                <select value={form.protocol} onChange={event => setField('protocol', event.target.value)}>
                  <option value="anthropic">Anthropic</option>
                  <option value="openai">OpenAI Compatible</option>
                </select>
              </label>

              <label>
                <span>默认 Agent</span>
                <select value={form.default_agent_id} onChange={event => setField('default_agent_id', event.target.value)}>
                  {agents.map(agent => (
                    <option key={agent.id} value={agent.id}>
                      {agent.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <label>
              <span>Theme</span>
              <input value={form.theme} onChange={event => setField('theme', event.target.value)} />
            </label>

            <div className="runtime-config-actions">
              <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={saving}>
                {saving ? '保存中…' : '保存配置'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
