'use client'

import { useEffect, useMemo, useRef, useState } from 'react'

import type { AgentDescriptor, AgentScenario, ChatMessage, RunStatus, TraceNode } from '../lib/types'
import { MarkdownMessage } from './MarkdownMessage'
import { ScenarioLauncher } from './ScenarioLauncher'

interface Props {
  agent: AgentDescriptor | null
  messages: ChatMessage[]
  traces: TraceNode[]
  status: RunStatus
  scenarios: AgentScenario[]
  onSend: (text: string) => void
  onRunScenario: (scenario: AgentScenario) => void
  onRunProbe: (scenario: AgentScenario) => void
  onStop: () => void
  onReset: () => void
  echoMode: boolean
  onOpenConfig: () => void
  inspectorOpen: boolean
  traceCount: number
  artifactCount: number
  onToggleInspector: () => void
  activeScenarioLabel?: string | null
  onOpenScenarios?: () => void
}

export function ChatPane({
  agent,
  messages,
  traces,
  status,
  scenarios,
  onSend,
  onRunScenario,
  onRunProbe,
  onStop,
  onReset,
  echoMode,
  onOpenConfig,
  inspectorOpen,
  traceCount,
  artifactCount,
  onToggleInspector,
  activeScenarioLabel,
  onOpenScenarios,
}: Props) {
  const [input, setInput] = useState('')
  const [expandedToolIds, setExpandedToolIds] = useState<Set<string>>(() => new Set())
  const messagesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = messagesRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages, traces, status.running])

  const activityCount = traceCount + artifactCount
  const hasConversation = messages.length > 0
  const toolTracesByRun = useMemo(() => {
    const toolKinds = new Set(['tool', 'tool_progress', 'permission', 'tool_result'])
    const groups = new Map<string, TraceNode[]>()
    traces.forEach(node => {
      if (!node.runId || !toolKinds.has(node.kind)) return
      const group = groups.get(node.runId) ?? []
      group.push(node)
      groups.set(node.runId, group)
    })
    return groups
  }, [traces])

  const toggleTool = (id: string) => {
    setExpandedToolIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  return (
    <section className="studio-chat">
      <header className="panel-header chat-header">
        <div>
          <p className="eyebrow">Chat</p>
          <h2>{agent?.name ?? '选择 Agent'}</h2>
          {agent && <p className="chat-subtitle">{agent.description}</p>}
          {hasConversation && activeScenarioLabel && (
            <p className="chat-active-scenario">场景：{activeScenarioLabel}</p>
          )}
        </div>
        <div className="chat-header-actions">
          <span className={`status-pill ${status.running ? 'running' : ''} ${status.error ? 'error' : ''}`}>
            {status.running ? '运行中' : status.error ? '错误' : '就绪'}
          </span>
          {hasConversation && onOpenScenarios && (
            <button type="button" className="btn-ghost" onClick={onOpenScenarios}>
              场景
            </button>
          )}
          <button
            type="button"
            className={`btn-ghost btn-inspector-toggle ${inspectorOpen ? 'active' : ''}`}
            onClick={onToggleInspector}
            title={inspectorOpen ? '收起运行详情' : '展开运行详情'}
          >
            {inspectorOpen ? '收起详情' : '运行详情'}
            {activityCount > 0 && !inspectorOpen && (
              <span className="tab-badge">{activityCount}</span>
            )}
          </button>
        </div>
      </header>

      {echoMode && (
        <div className="echo-notice" role="status">
          <p className="echo-notice-text">
            <strong>Echo 模式</strong>
            <span>未配置 API Key，普通对话不会调用真实模型；沙箱探针可继续使用。</span>
          </p>
          <button type="button" className="echo-notice-action" onClick={onOpenConfig}>
            立即配置
          </button>
        </div>
      )}

      <div className="chat-messages" ref={messagesRef}>
        {messages.length === 0 && (
          <div className="starter-panel">
            <div className="starter-copy">
              <p className="eyebrow">Start</p>
              <h1>{agent ? `和 ${agent.name} 开始` : '选择一个 Agent'}</h1>
              <p>
                选择示例或下方场景开始；更多验证项在「运行详情」→「场景」。
              </p>
            </div>

            <ScenarioLauncher
              agent={agent}
              scenarios={scenarios}
              running={status.running}
              layout="starter"
              onSend={onSend}
              onRunScenario={onRunScenario}
              onRunProbe={onRunProbe}
            />
          </div>
        )}
        {messages.map(m => (
          <div key={m.id} className="chat-turn">
            <div className={`chat-bubble ${m.role}`}>
              {m.role === 'user' ? m.text : (
                <div className="markdown-message">
                  <MarkdownMessage text={m.text} />
                </div>
              )}
            </div>
            {m.role === 'user' && m.runId && (
              <ToolActivityList
                traces={toolTracesByRun.get(m.runId) ?? []}
                expandedIds={expandedToolIds}
                onToggle={toggleTool}
              />
            )}
          </div>
        ))}
      </div>

      <footer className="chat-compose">
        <textarea
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="输入消息…"
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              if (input.trim()) {
                onSend(input)
                setInput('')
              }
            }
          }}
        />
        <div className="chat-actions">
          <button
            type="button"
            className="btn-primary"
            disabled={!input.trim() || status.running}
            onClick={() => {
              onSend(input)
              setInput('')
            }}
          >
            发送
          </button>
          {status.running && (
            <button type="button" className="btn-ghost" onClick={onStop}>
              停止
            </button>
          )}
          <button type="button" className="btn-ghost" onClick={onReset}>
            清空
          </button>
        </div>
      </footer>
    </section>
  )
}

function ToolActivityList({
  traces,
  expandedIds,
  onToggle,
}: {
  traces: TraceNode[]
  expandedIds: Set<string>
  onToggle: (id: string) => void
}) {
  if (traces.length === 0) return null
  return (
    <div className="chat-tool-list" aria-label="工具调用">
      {traces.map(node => {
        const expanded = expandedIds.has(node.id)
        const hasDetail = Boolean(node.summary || node.detail)
        return (
          <button
            key={node.id}
            type="button"
            className={`chat-tool-card ${node.status}`}
            aria-expanded={expanded}
            onClick={() => hasDetail && onToggle(node.id)}
          >
            <span className="chat-tool-main">
              <span className="chat-tool-title">{node.title}</span>
              <span className="chat-tool-kind">{node.kind}</span>
            </span>
            <span className={`trace-status ${node.status}`}>{node.status}</span>
            {expanded && node.summary && (
              <span className="chat-tool-summary">{node.summary}</span>
            )}
            {expanded && node.detail && node.detail !== node.summary && (
              <pre className="raw-json chat-tool-detail">{node.detail}</pre>
            )}
          </button>
        )
      })}
    </div>
  )
}
