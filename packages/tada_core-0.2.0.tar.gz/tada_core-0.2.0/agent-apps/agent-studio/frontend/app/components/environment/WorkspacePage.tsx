'use client'

import { useCallback, useEffect, useState } from 'react'

import { fetchWorkspaceFile, fetchWorkspaceFiles, saveWorkspaceFile } from '../../lib/api'
import type { WorkspaceFileContent, WorkspaceFileInfo } from '../../lib/types'

export function WorkspacePage() {
  const [files, setFiles] = useState<WorkspaceFileInfo[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [content, setContent] = useState('')
  const [original, setOriginal] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadFile = useCallback(async (filename: string) => {
    setLoading(true)
    setError(null)
    try {
      const data: WorkspaceFileContent = await fetchWorkspaceFile(filename)
      setSelected(data.filename)
      setContent(data.content)
      setOriginal(data.content)
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])

  const loadFiles = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const list = await fetchWorkspaceFiles()
      setFiles(list)
      if (list.length > 0) {
        await loadFile(list[0].filename)
      }
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setLoading(false)
    }
  }, [loadFile])

  useEffect(() => {
    void loadFiles()
  }, [loadFiles])

  const handleSave = async () => {
    if (!selected) return
    setSaving(true)
    setError(null)
    try {
      await saveWorkspaceFile(selected, content)
      setOriginal(content)
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setSaving(false)
    }
  }

  const hasChanges = content !== original
  const totalSizeKb = files.reduce((sum, file) => sum + Math.max(1, Math.round(file.size / 1024)), 0)

  return (
    <section className="env-page">
      <header className="env-page-header">
        <div>
          <p className="eyebrow">Agents 环境</p>
          <h1>工作区</h1>
          <p>查看和维护 Agent Studio 暴露给智能体的基础 Markdown 上下文文件。</p>
        </div>
        <button type="button" className="btn-ghost" onClick={() => void loadFiles()} disabled={loading}>
          刷新
        </button>
      </header>

      {error && <p className="env-error">{error}</p>}

      <div className="env-metric-row">
        <div className="env-metric-card">
          <span>FILES</span>
          <strong>{files.length}</strong>
          <p>白名单 Markdown</p>
        </div>
        <div className="env-metric-card">
          <span>SIZE</span>
          <strong>{totalSizeKb} KB</strong>
          <p>上下文文件总量</p>
        </div>
        <div className="env-metric-card">
          <span>STATE</span>
          <strong>{hasChanges ? 'Dirty' : 'Clean'}</strong>
          <p>{selected ?? '未选择文件'}</p>
        </div>
      </div>

      <div className="workspace-layout">
        <aside className="workspace-file-panel">
          <div className="workspace-file-panel-head">
            <strong>核心文件</strong>
            <span>{files.length}</span>
          </div>
          <div className="workspace-file-list">
            {files.map(file => (
              <button
                key={file.filename}
                type="button"
                className={selected === file.filename ? 'workspace-file active' : 'workspace-file'}
                onClick={() => void loadFile(file.filename)}
              >
                <strong>{file.filename}</strong>
                <span>{Math.max(1, Math.round(file.size / 1024))} KB</span>
              </button>
            ))}
          </div>
        </aside>

        <section className="workspace-editor">
          <div className="workspace-editor-toolbar">
            <div>
              <strong>{selected ?? '选择文件'}</strong>
              {hasChanges && <span className="dirty-dot">未保存</span>}
            </div>
            <div className="panel-actions">
              <button type="button" className="btn-ghost" onClick={() => setContent(original)} disabled={!hasChanges}>
                重置
              </button>
              <button type="button" className="btn-primary" onClick={() => void handleSave()} disabled={!hasChanges || saving}>
                {saving ? '保存中…' : '保存'}
              </button>
            </div>
          </div>
          {loading && !selected ? (
            <p className="panel-empty">加载工作区文件中…</p>
          ) : selected ? (
            <textarea
              className="workspace-textarea"
              value={content}
              onChange={event => setContent(event.target.value)}
              spellCheck={false}
            />
          ) : (
            <p className="panel-empty">暂无可显示的 Markdown 文件。</p>
          )}
        </section>
      </div>
    </section>
  )
}
