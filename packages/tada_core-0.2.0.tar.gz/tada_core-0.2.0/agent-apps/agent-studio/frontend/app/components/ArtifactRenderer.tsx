'use client'

import type { Artifact } from '../lib/types'

export function ArtifactRenderer({ artifact }: { artifact: Artifact }) {
  const { kind, payload } = artifact

  if (kind === 'trip_plan') {
    const days = (payload.days as { day: number; title: string; items: string[] }[]) ?? []
    const budget = payload.budget_cny as Record<string, number> | undefined
    return (
      <div>
        <p style={{ color: 'var(--muted)', fontSize: 12, marginBottom: 12 }}>
          目的地：{String(payload.destination ?? '—')} · 查询：{String(payload.user_query ?? '').slice(0, 80)}
        </p>
        {days.map(d => (
          <div key={d.day} className="trip-day">
            <h4>
              Day {d.day} · {d.title}
            </h4>
            <ul>
              {d.items.map(item => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
        {budget && (
          <pre className="raw-json">
            {JSON.stringify(budget, null, 2)}
          </pre>
        )}
      </div>
    )
  }

  if (kind === 'product_grid') {
    const products = (payload.products as Record<string, unknown>[]) ?? []
    return (
      <div>
        <p style={{ color: 'var(--muted)', fontSize: 12, marginBottom: 12 }}>
          查询：{String(payload.query ?? '')}
        </p>
        <div className="product-grid">
          {products.map(p => (
            <div key={String(p.id)} className="product-card">
              <strong style={{ fontSize: 12 }}>{String(p.name)}</strong>
              <p style={{ fontSize: 11, color: 'var(--muted)', margin: '4px 0' }}>{String(p.brand)}</p>
              <p style={{ fontSize: 13 }}>¥{String(p.price_cny)}</p>
              <p style={{ fontSize: 11, color: 'var(--green)' }}>★ {String(p.rating)}</p>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (kind === 'test_report') {
    return (
      <pre className="raw-json">
        {String(payload.output ?? payload.detail ?? JSON.stringify(payload, null, 2))}
      </pre>
    )
  }

  if (kind === 'audit_log') {
    return (
      <pre className="raw-json">
        {String(payload.output ?? JSON.stringify(payload, null, 2))}
      </pre>
    )
  }

  if (kind === 'markdown' && typeof payload.content === 'string') {
    return <pre className="raw-json">{payload.content}</pre>
  }

  return <pre className="raw-json">{JSON.stringify(payload, null, 2)}</pre>
}
