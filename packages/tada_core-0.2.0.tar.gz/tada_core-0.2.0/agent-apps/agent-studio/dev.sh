#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"

BACKEND_PORT="${BACKEND_PORT:-8010}"
FRONTEND_PORT="${FRONTEND_PORT:-3010}"
BACKEND_HOST="${BACKEND_HOST:-127.0.0.1}"
FRONTEND_HOST="${FRONTEND_HOST:-127.0.0.1}"
API_BASE="http://${BACKEND_HOST}:${BACKEND_PORT}"

BACKEND_PID=""
FRONTEND_PID=""

cleanup() {
  local exit_code=$?
  trap - INT TERM EXIT
  [[ -n "${FRONTEND_PID}" ]] && kill "${FRONTEND_PID}" 2>/dev/null || true
  [[ -n "${BACKEND_PID}" ]] && kill "${BACKEND_PID}" 2>/dev/null || true
  wait "${FRONTEND_PID}" 2>/dev/null || true
  wait "${BACKEND_PID}" 2>/dev/null || true
  exit "${exit_code}"
}

trap cleanup INT TERM EXIT

echo "Starting agent-studio backend on ${API_BASE}"
(
  cd "${ROOT_DIR}"
  uv run uvicorn app:app \
    --app-dir agent-apps/agent-studio/backend \
    --reload \
    --host "${BACKEND_HOST}" \
    --port "${BACKEND_PORT}"
) &
BACKEND_PID=$!

echo "Starting agent-studio frontend on http://${FRONTEND_HOST}:${FRONTEND_PORT}"
(
  cd "${SCRIPT_DIR}/frontend"
  NEXT_PUBLIC_API_BASE="${API_BASE}" \
  npm run dev -- --port "${FRONTEND_PORT}"
) &
FRONTEND_PID=$!

echo
echo "Backend:  ${API_BASE}"
echo "Frontend: http://${FRONTEND_HOST}:${FRONTEND_PORT}"
echo "Press Ctrl-C to stop both services."
echo

wait "${BACKEND_PID}" "${FRONTEND_PID}"
