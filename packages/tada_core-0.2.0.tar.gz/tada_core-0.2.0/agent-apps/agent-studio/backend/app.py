"""Agent Studio backend — unified multi-agent host."""
from __future__ import annotations

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from agent_studio.agents.base import RunContext
from agent_studio.agents.registry import get_plugin, list_agent_dicts
from agent_studio.config import load_config, public_config, save_config
from agent_studio.environment import (
    list_skills,
    list_tools,
    list_workspace_files,
    read_workspace_file,
    save_workspace_file,
)
from agent_studio.sessions import get_session_store
from agent_studio.streaming import run_sse

app = FastAPI(title="agent-studio")

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
    allow_methods=["*"],
    allow_headers=["*"],
)


class ConfigBody(BaseModel):
    base_url: str = ""
    api_key: str = ""
    model_id: str = ""
    protocol: str = ""
    default_agent_id: str = ""
    theme: str = ""


class RunRequest(BaseModel):
    agent_id: str
    text: str
    reset_session: bool = False
    scenario: str = "default"
    task_id: str | None = None


class ProbeRequest(BaseModel):
    agent_id: str = "coding-agent"
    scenario: str
    probe_id: str
    session_id: str | None = None


class WorkspaceFileBody(BaseModel):
    content: str


@app.get("/api/health")
def health() -> dict:
    return {"ok": True, "service": "agent-studio"}


@app.get("/api/config")
def get_config() -> dict:
    return public_config()


@app.post("/api/config")
def post_config(body: ConfigBody) -> dict:
    updates = {k: v for k, v in body.model_dump().items() if v}
    save_config(updates)
    return {"saved": True, **public_config()}


@app.get("/api/runtime-config")
def get_runtime_config() -> dict:
    return public_config()


@app.put("/api/runtime-config")
def put_runtime_config(body: ConfigBody) -> dict:
    updates = body.model_dump()
    save_config(updates)
    return public_config()


@app.get("/api/workspace/files")
def get_workspace_files() -> list[dict]:
    return list_workspace_files()


@app.get("/api/workspace/files/{filename:path}")
def get_workspace_file(filename: str) -> dict:
    data = read_workspace_file(filename)
    if data is None:
        raise HTTPException(status_code=404, detail="workspace file not found")
    return data


@app.put("/api/workspace/files/{filename:path}")
def put_workspace_file(filename: str, body: WorkspaceFileBody) -> dict:
    data = save_workspace_file(filename, body.content)
    if data is None:
        raise HTTPException(status_code=404, detail="workspace file not found")
    return data


@app.get("/api/skills")
def get_skills() -> dict:
    return list_skills()


@app.get("/api/tools")
def get_tools() -> dict:
    return list_tools()


@app.get("/api/agents")
def list_agents_route() -> list[dict]:
    cfg = load_config()
    agents = list_agent_dicts()
    default_id = cfg.get("default_agent_id", "coding-agent")
    for a in agents:
        a["is_default"] = a["id"] == default_id
    return agents


@app.get("/api/agents/{agent_id}/scenarios")
def list_scenarios(agent_id: str) -> list[dict]:
    try:
        plugin = get_plugin(agent_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return plugin.list_scenarios()


@app.get("/api/session/{agent_id}")
def get_session(agent_id: str) -> dict:
    snap = get_session_store().snapshot(agent_id)
    if snap is None:
        return {"agent_id": agent_id, "message_count": 0, "messages": []}
    return snap


@app.delete("/api/session/{agent_id}")
def reset_session(agent_id: str) -> dict:
    get_session_store().reset(agent_id)
    return {"reset": True, "agent_id": agent_id}


@app.post("/api/runs")
def start_run(body: RunRequest) -> StreamingResponse:
    try:
        plugin = get_plugin(body.agent_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    store = get_session_store()
    session = store.get_or_create(body.agent_id, reset=body.reset_session)
    ctx = RunContext(
        agent_id=body.agent_id,
        text=body.text,
        state=session.state,
        scenario=body.scenario,
        extras={"task_id": body.task_id} if body.task_id else {},
    )

    return StreamingResponse(
        run_sse(plugin, ctx),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/api/probe")
async def run_probe(body: ProbeRequest) -> dict:
    """Run a deterministic probe through the selected agent plugin."""
    if body.agent_id != "coding-agent":
        raise HTTPException(status_code=400, detail="probes only supported for coding-agent")
    try:
        plugin = get_plugin(body.agent_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    import uuid

    session_id = body.session_id or uuid.uuid4().hex[:8]
    ctx = RunContext(
        agent_id=body.agent_id,
        text="",
        state=get_session_store().get_or_create(body.agent_id).state,
        scenario=body.scenario,
        extras={"sandbox_session_id": session_id},
    )
    try:
        return await plugin.run_probe(ctx, body.probe_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except NotImplementedError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


def build_app() -> FastAPI:
    return app
