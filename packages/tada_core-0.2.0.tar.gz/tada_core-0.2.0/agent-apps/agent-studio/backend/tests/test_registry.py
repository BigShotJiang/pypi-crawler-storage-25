from agent_studio.agents.registry import get_plugin, list_agent_dicts


def test_list_three_agents():
    agents = list_agent_dicts()
    ids = {a["id"] for a in agents}
    assert ids == {"coding-agent", "trip-agent", "shopping-agent"}


def test_get_coding_plugin():
    plugin = get_plugin("coding-agent")
    assert plugin.descriptor.id == "coding-agent"
    assert "test_report" in plugin.descriptor.artifact_kinds
