from types import SimpleNamespace

from agent_studio.normalizer import normalize_event


def test_text_delta_produces_message_and_trace():
    ev = SimpleNamespace(
        type="text_delta",
        model_dump=lambda: {"type": "text_delta", "text": "hello"},
    )
    buf: list[str] = []
    frames = normalize_event(ev, run_id="r1", seq=0, text_buffer=buf)
    assert buf == ["hello"]
    kinds = {f["frame"] for f in frames}
    assert "message" in kinds
    assert "trace" in kinds


def test_tool_use_trace():
    ev = SimpleNamespace(
        type="tool_use",
        model_dump=lambda: {
            "type": "tool_use",
            "tool_name": "echo",
            "tool_use_id": "t1",
            "input_json": "{}",
        },
    )
    frames = normalize_event(ev, run_id="r1", seq=1, text_buffer=[])
    assert frames[0]["frame"] == "trace"
    assert frames[0]["data"]["kind"] == "tool"


def test_trace_nodes_include_flow_parent_ids():
    state: dict = {}
    buf: list[str] = []

    llm = SimpleNamespace(
        type="text_delta",
        model_dump=lambda: {"type": "text_delta", "text": "planning"},
    )
    tool = SimpleNamespace(
        type="tool_use",
        model_dump=lambda: {
            "type": "tool_use",
            "tool_name": "echo",
            "tool_use_id": "t1",
            "input_json": "{}",
        },
    )
    permission = SimpleNamespace(
        type="permission",
        model_dump=lambda: {
            "type": "permission",
            "tool_name": "echo",
            "tool_use_id": "t1",
            "allowed": True,
        },
    )

    llm_trace = normalize_event(llm, run_id="r1", seq=1, text_buffer=buf, run_state=state)[1]["data"]
    tool_trace = normalize_event(tool, run_id="r1", seq=2, text_buffer=buf, run_state=state)[0]["data"]
    permission_trace = normalize_event(
        permission,
        run_id="r1",
        seq=3,
        text_buffer=buf,
        run_state=state,
    )[0]["data"]

    assert llm_trace["parent_id"] == "r1-start"
    assert tool_trace["parent_id"] == llm_trace["id"]
    assert permission_trace["parent_id"] == "t1"
