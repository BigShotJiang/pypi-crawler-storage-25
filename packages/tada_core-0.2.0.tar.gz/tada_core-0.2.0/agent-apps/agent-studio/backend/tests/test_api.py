from fastapi.testclient import TestClient
import pytest

from agent_studio import config as config_module
from app import app

client = TestClient(app)


@pytest.fixture(autouse=True)
def isolate_config(tmp_path, monkeypatch):
    monkeypatch.setattr(config_module, "_CONFIG_PATH", tmp_path / ".config.json")


def test_health():
    r = client.get("/api/health")
    assert r.status_code == 200
    assert r.json()["service"] == "agent-studio"


def test_list_agents():
    r = client.get("/api/agents")
    assert r.status_code == 200
    assert len(r.json()) == 3


def test_coding_scenarios():
    r = client.get("/api/agents/coding-agent/scenarios")
    assert r.status_code == 200
    data = r.json()
    assert len(data) >= 3
    ids = {s["id"] for s in data}
    assert "echo_turn" in ids


def test_config_roundtrip():
    r = client.post("/api/config", json={"model_id": "test-model"})
    assert r.status_code == 200
    assert r.json()["model_id"] == "test-model"


def test_config_partial_update_does_not_force_protocol():
    r = client.post("/api/config", json={"protocol": "openai", "model_id": "test-model"})
    assert r.status_code == 200
    assert r.json()["protocol"] == "openai"

    r = client.post("/api/config", json={"model_id": "next-model"})
    assert r.status_code == 200
    assert r.json()["model_id"] == "next-model"
    assert r.json()["protocol"] == "openai"


def test_workspace_lists_and_reads_allowed_markdown_files():
    r = client.get("/api/workspace/files")
    assert r.status_code == 200
    files = r.json()
    filenames = {f["filename"] for f in files}
    assert "AGENTS.md" in filenames
    assert "README.md" in filenames

    r = client.get("/api/workspace/files/AGENTS.md")
    assert r.status_code == 200
    data = r.json()
    assert data["filename"] == "AGENTS.md"
    assert "tada-core" in data["content"]


def test_workspace_rejects_non_whitelisted_paths():
    r = client.get("/api/workspace/files/..%2Fpyproject.toml")
    assert r.status_code == 404


def test_workspace_can_save_allowed_markdown_file(tmp_path, monkeypatch):
    workspace_file = tmp_path / "README.md"
    workspace_file.write_text("before", encoding="utf-8")
    monkeypatch.setattr("agent_studio.environment._WORKSPACE_FILES", {"README.md": workspace_file})

    r = client.put("/api/workspace/files/README.md", json={"content": "after"})
    assert r.status_code == 200
    assert r.json()["saved"] is True
    assert workspace_file.read_text(encoding="utf-8") == "after"


def test_skills_inventory_is_empty_when_no_skill_files():
    r = client.get("/api/skills")
    assert r.status_code == 200
    data = r.json()
    assert data == {"skills": []}


def test_skills_inventory_reads_skill_files(tmp_path, monkeypatch):
    skill_dir = tmp_path / "demo-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        "---\n"
        "name: demo-skill\n"
        "description: Demo skill from test\n"
        "---\n"
        "\n"
        "# Demo Skill\n"
        "\n"
        "Use this for demo behavior.\n",
        encoding="utf-8",
    )
    monkeypatch.setattr("agent_studio.environment._SKILL_ROOTS", [tmp_path])

    r = client.get("/api/skills")
    assert r.status_code == 200
    data = r.json()
    assert data["skills"] == [
        {
            "id": "demo-skill",
            "name": "demo-skill",
            "description": "Demo skill from test",
            "path": str(skill_dir / "SKILL.md"),
            "group": "demo-skill",
            "content_preview": "# Demo Skill\n\nUse this for demo behavior.",
        }
    ]


def test_tools_inventory_includes_registered_agent_tools():
    r = client.get("/api/tools")
    assert r.status_code == 200
    data = r.json()
    names = {tool["name"] for group in data["groups"] for tool in group["tools"]}
    assert "echo" in names
    assert "read_file" in names
    assert "run_shell" in names
    assert "run_pytest" in names
    assert "search_flights" in names
    assert "search_products" in names

    sources = {tool["source"] for group in data["groups"] for tool in group["tools"]}
    assert {"core", "sandbox", "demo"} <= sources


def test_probe_runs_through_coding_agent_plugin():
    r = client.post(
        "/api/probe",
        json={
            "agent_id": "coding-agent",
            "scenario": "sb_path_jail",
            "probe_id": "path_jail.read_host_file",
            "session_id": "pytest-probe",
        },
    )
    assert r.status_code == 200
    data = r.json()
    assert data["probe_id"] == "path_jail.read_host_file"
    assert data["status"] == "denied"


def test_runtime_config_roundtrip_uses_config_store():
    r = client.put("/api/runtime-config", json={"model_id": "runtime-model", "protocol": "openai"})
    assert r.status_code == 200
    assert r.json()["model_id"] == "runtime-model"
    assert r.json()["protocol"] == "openai"

    r = client.get("/api/runtime-config")
    assert r.status_code == 200
    assert r.json()["model_id"] == "runtime-model"
