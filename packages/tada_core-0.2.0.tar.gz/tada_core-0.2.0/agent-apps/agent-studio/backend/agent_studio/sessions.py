"""Per-agent session store."""
from __future__ import annotations

from dataclasses import dataclass, field

from tada_core import SessionState


@dataclass
class AgentSession:
    agent_id: str
    state: SessionState = field(default_factory=SessionState)
    extras: dict = field(default_factory=dict)


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[str, AgentSession] = {}

    def get_or_create(self, agent_id: str, *, reset: bool = False) -> AgentSession:
        if reset or agent_id not in self._sessions:
            self._sessions[agent_id] = AgentSession(agent_id=agent_id)
        return self._sessions[agent_id]

    def reset(self, agent_id: str) -> None:
        self._sessions.pop(agent_id, None)

    def snapshot(self, agent_id: str) -> dict | None:
        session = self._sessions.get(agent_id)
        if session is None:
            return None

        def _blocks(msg) -> list:
            result = []
            for b in msg.content:
                if b.type == "text" and b.text:
                    result.append({"type": "text", "text": b.text})
                elif b.type == "tool_use":
                    result.append(
                        {
                            "type": "tool_use",
                            "id": b.tool_use_id,
                            "name": b.tool_name,
                            "input": b.tool_input,
                        }
                    )
                elif b.type == "tool_result":
                    result.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": b.tool_use_id,
                            "name": b.tool_name,
                            "result": b.tool_result,
                            "is_error": b.is_error,
                        }
                    )
            return result

        return {
            "agent_id": agent_id,
            "message_count": len(session.state.messages),
            "usage": session.state.usage.model_dump(),
            "metadata": session.state.metadata,
            "messages": [
                {"role": m.role.value, "text": m.text_only(), "blocks": _blocks(m)}
                for m in session.state.messages
            ],
        }


_store = SessionStore()


def get_session_store() -> SessionStore:
    return _store
