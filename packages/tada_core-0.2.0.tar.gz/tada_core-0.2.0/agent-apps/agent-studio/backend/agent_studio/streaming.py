"""Unified SSE encoder for Agent Studio runs."""
from __future__ import annotations

import json
import uuid
from collections.abc import AsyncIterator
from typing import Any

from agent_studio.agents.base import AgentPlugin, RunContext
from agent_studio.normalizer import finalize_message, normalize_event


async def run_sse(
    plugin: AgentPlugin,
    ctx: RunContext,
) -> AsyncIterator[bytes]:
    run_id = uuid.uuid4().hex[:12]
    seq = 0
    text_buffer: list[str] = []
    collected: list[dict[str, Any]] = []
    run_state: dict[str, Any] = {"run_id": run_id, "run_trace_id": f"{run_id}-start"}

    yield _frame(
        "trace",
        {
            "run_id": run_id,
            "seq": seq,
            "id": f"{run_id}-start",
            "kind": "run",
            "status": "running",
            "title": f"开始运行 · {plugin.descriptor.name}",
            "summary": ctx.text[:120],
        },
    )
    seq += 1

    try:
        async for event in plugin.run_turn(ctx):
            raw = event.model_dump() if hasattr(event, "model_dump") else {"type": "unknown"}
            collected.append(raw)
            for payload in normalize_event(
                event,
                run_id=run_id,
                seq=seq,
                text_buffer=text_buffer,
                run_state=run_state,
            ):
                seq += 1
                yield _frame(payload["frame"], payload["data"])

        for payload in finalize_message(text_buffer, run_state=run_state):
            seq += 1
            yield _frame(payload["frame"], payload["data"])

        for artifact in plugin.artifacts_from_events(collected, ctx):
            yield _frame("artifact", artifact.to_dict())

        yield _frame("done", {"run_id": run_id, "agent_id": ctx.agent_id, "ok": True})
    except Exception as exc:
        yield _frame("error", {"message": str(exc)})
        yield _frame("done", {"run_id": run_id, "agent_id": ctx.agent_id, "ok": False})


def _frame(name: str, data: dict[str, Any]) -> bytes:
    payload = json.dumps(data, ensure_ascii=False)
    return f"event: {name}\ndata: {payload}\n\n".encode("utf-8")
