"""Shared model client factory for all agent plugins."""
from __future__ import annotations

import json
import os
from typing import Any

from tada_core import AnthropicModelClient
from tada_core.contracts.messages import MessageRole
from tada_core.contracts.model import ModelClient
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

from agent_studio.config import load_config


def build_model() -> ModelClient:
    cfg = load_config()
    api_key = cfg.get("api_key") or os.environ.get("API_KEY", "")
    base_url = cfg.get("base_url") or os.environ.get("BASE_URL", "")
    model_id = cfg.get("model_id") or os.environ.get("MODEL_ID", "")
    protocol = cfg.get("protocol") or os.environ.get("PROTOCOL", "anthropic")

    if not api_key:
        return OpenAICompatibleModelClient(make_echo_transport(), streaming=True)

    if protocol == "openai":
        from urllib.request import Request, urlopen

        def _transport(request: Any, stream: bool) -> Any:
            msgs = []
            for p in request.system_prompt:
                msgs.append({"role": "system", "content": p})
            for m in request.messages:
                if m.role == MessageRole.TOOL:
                    b = m.content[0] if m.content else None
                    if b:
                        msgs.append(
                            {
                                "role": "tool",
                                "tool_call_id": b.tool_use_id or "",
                                "content": b.tool_result or "",
                            }
                        )
                    continue
                texts, calls = [], []
                for b in m.content:
                    if b.type == "text" and b.text:
                        texts.append(b.text)
                    if b.type == "tool_use":
                        calls.append(
                            {
                                "id": b.tool_use_id or "",
                                "type": "function",
                                "function": {
                                    "name": b.tool_name or "",
                                    "arguments": b.tool_input or "{}",
                                },
                            }
                        )
                entry: dict = {"role": m.role.value, "content": "".join(texts)}
                if calls:
                    entry["tool_calls"] = calls
                msgs.append(entry)
            payload: dict[str, Any] = {"model": model_id, "messages": msgs, "stream": stream}
            if request.tools:
                payload["tools"] = request.tools
            ep = (base_url or "https://api.openai.com").rstrip("/")
            req = Request(
                f"{ep}/v1/chat/completions",
                data=json.dumps(payload).encode(),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
                method="POST",
            )
            with urlopen(req) as resp:
                ct = resp.headers.get("Content-Type", "")
                if "event-stream" in ct:
                    chunks = []
                    for part in resp.read().decode().split("\n\n"):
                        for line in part.splitlines():
                            if line.startswith("data: "):
                                body = line[6:].strip()
                                if body and body != "[DONE]":
                                    chunks.append(json.loads(body))
                    return chunks
                return json.loads(resp.read().decode())

        return OpenAICompatibleModelClient(_transport, streaming=True)

    return AnthropicModelClient(
        api_key=api_key,
        model=model_id or "claude-sonnet-4-6",
        base_url=base_url,
        streaming=True,
    )
