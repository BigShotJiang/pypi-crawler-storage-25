"""Map tada-core events to trace nodes, chat messages, and artifacts."""
from __future__ import annotations

import json
from typing import Any

from agent_studio.agents.base import ArtifactEnvelope


def _event_dict(event: Any) -> dict[str, Any]:
    if hasattr(event, "model_dump"):
        return event.model_dump()
    return {"type": getattr(event, "type", "unknown"), "raw": str(event)}


def _stable_trace_id(run_id: str, etype: str, raw: dict[str, Any], run_state: dict) -> str:
    """Stable ids so the UI can merge streaming updates instead of flooding new nodes."""
    tool_use_id = raw.get("tool_use_id")
    if etype == "text_delta":
        key = "llm_trace_id"
        if key not in run_state:
            run_state[key] = f"{run_id}-llm"
        return str(run_state[key])
    if etype == "tool_use" and tool_use_id:
        return str(tool_use_id)
    if etype == "tool_result" and tool_use_id:
        return str(tool_use_id)
    if etype == "tool_progress" and tool_use_id:
        return f"{tool_use_id}-progress"
    if etype == "permission" and tool_use_id:
        return f"{tool_use_id}-permission"
    return f"{run_id}-{etype}-{run_state.get('_generic', 0)}"


def _run_root_id(run_id: str, run_state: dict[str, Any]) -> str:
    root_id = str(run_state.get("run_trace_id") or f"{run_id}-start")
    run_state["run_trace_id"] = root_id
    run_state["run_id"] = run_id
    return root_id


def _remember_tool_parent(
    tool_use_id: Any,
    parent_id: str,
    run_state: dict[str, Any],
) -> None:
    if not tool_use_id:
        return
    parents = run_state.setdefault("tool_parent_ids", {})
    parents[str(tool_use_id)] = parent_id


def _tool_parent(tool_use_id: Any, run_state: dict[str, Any], fallback: str) -> str:
    if tool_use_id:
        parents = run_state.get("tool_parent_ids", {})
        parent = parents.get(str(tool_use_id))
        if parent:
            return str(parent)
    return fallback


def normalize_event(
    event: Any,
    *,
    run_id: str,
    seq: int,
    text_buffer: list[str],
    run_state: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Return zero or more SSE frame payloads (without event: prefix)."""
    state = run_state if run_state is not None else {}
    raw = _event_dict(event)
    etype = raw.get("type", "unknown")
    frames: list[dict[str, Any]] = []
    root_id = _run_root_id(run_id, state)

    base_trace = {
        "run_id": run_id,
        "seq": seq,
        "raw": raw,
    }

    if etype == "text_delta":
        text = str(raw.get("text", ""))
        text_buffer.append(text)
        full_text = "".join(text_buffer)
        frames.append(
            {
                "frame": "message",
                "data": {"role": "assistant", "delta": text, "done": False},
            }
        )
        # Single updatable LLM trace node (no per-token spam)
        trace_id = _stable_trace_id(run_id, etype, raw, state)
        state["current_llm_trace_id"] = trace_id
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": trace_id,
                    "parent_id": root_id,
                    "kind": "llm",
                    "status": "running",
                    "title": "模型输出",
                    "summary": full_text[:160] or "…",
                    "detail": full_text,
                },
            }
        )
    elif etype == "tool_use":
        parent_id = str(state.get("current_llm_trace_id") or root_id)
        _remember_tool_parent(raw.get("tool_use_id"), parent_id, state)
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": parent_id,
                    "kind": "tool",
                    "status": "running",
                    "title": f"调用工具 · {raw.get('tool_name', '?')}",
                    "summary": str(raw.get("input_json", ""))[:160],
                    "tool_use_id": raw.get("tool_use_id"),
                    "tool_name": raw.get("tool_name"),
                },
            }
        )
    elif etype == "tool_progress":
        tool_use_id = raw.get("tool_use_id")
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": str(tool_use_id or _tool_parent(tool_use_id, state, root_id)),
                    "kind": "tool_progress",
                    "status": "running",
                    "title": f"工具进度 · {raw.get('tool_name', '?')}",
                    "summary": str(raw.get("update") or raw.get("message", "")),
                    "tool_use_id": tool_use_id,
                },
            }
        )
    elif etype == "permission":
        allowed = bool(raw.get("allowed"))
        tool_use_id = raw.get("tool_use_id")
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": str(tool_use_id or _tool_parent(tool_use_id, state, root_id)),
                    "kind": "permission",
                    "status": "done" if allowed else "error",
                    "title": f"权限 · {'允许' if allowed else '拒绝'}",
                    "summary": str(raw.get("reason") or raw.get("tool_name", "")),
                },
            }
        )
    elif etype == "tool_result":
        is_error = bool(raw.get("is_error"))
        output = str(raw.get("output", ""))
        parent_id = _tool_parent(raw.get("tool_use_id"), state, root_id)
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": parent_id,
                    "kind": "tool_result",
                    "status": "error" if is_error else "done",
                    "title": f"工具结果 · {raw.get('tool_name', '?')}",
                    "summary": output[:160],
                    "detail": output,
                    "tool_use_id": raw.get("tool_use_id"),
                },
            }
        )
        if raw.get("tool_name") in ("run_pytest", "run_shell", "list_dir"):
            frames.append(
                {
                    "frame": "artifact",
                    "data": ArtifactEnvelope(
                        id=f"{raw.get('tool_use_id', run_id)}-artifact",
                        kind="test_report" if raw.get("tool_name") == "run_pytest" else "audit_log",
                        title=f"{raw.get('tool_name')} 输出",
                        payload={"output": output, "is_error": is_error},
                    ).to_dict(),
                }
            )
    elif etype == "hook":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "hook",
                    "status": "done",
                    "title": f"Hook · {raw.get('hook_name', '?')}",
                    "summary": ", ".join(raw.get("messages") or [])[:160],
                },
            }
        )
    elif etype == "compaction":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "compaction",
                    "status": "done",
                    "title": "上下文压缩",
                    "summary": f"{raw.get('strategy')} · 移除 {raw.get('removed_message_count', 0)} 条",
                },
            }
        )
    elif etype in ("turn_start", "turn_end"):
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": etype,
                    "status": "done",
                    "title": "轮次开始" if etype == "turn_start" else "轮次结束",
                    "summary": json.dumps(
                        {k: raw[k] for k in raw if k != "type"},
                        ensure_ascii=False,
                    )[:120],
                },
            }
        )
    elif etype == "loop_exit":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "loop_exit",
                    "status": "done",
                    "title": "循环退出",
                    "summary": str(raw.get("reason", "")),
                },
            }
        )
    elif etype == "steering":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "steering",
                    "status": "done",
                    "title": "用户介入",
                    "summary": str(raw.get("message", ""))[:160],
                },
            }
        )
    elif etype == "usage":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "usage",
                    "status": "done",
                    "title": "Token 用量",
                    "summary": (
                        f"in={raw.get('input_tokens', 0)} "
                        f"out={raw.get('output_tokens', 0)}"
                    ),
                },
            }
        )
    elif etype == "error":
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": "error",
                    "status": "error",
                    "title": "错误",
                    "summary": str(raw.get("message", "")),
                },
            }
        )
        frames.append(
            {
                "frame": "error",
                "data": {"message": str(raw.get("message", "")), "code": raw.get("code")},
            }
        )
    else:
        state["_generic"] = int(state.get("_generic", 0)) + 1
        frames.append(
            {
                "frame": "trace",
                "data": {
                    **base_trace,
                    "id": _stable_trace_id(run_id, etype, raw, state),
                    "parent_id": root_id,
                    "kind": etype,
                    "status": "done",
                    "title": etype,
                    "summary": json.dumps(raw, ensure_ascii=False)[:120],
                },
            }
        )

    return frames


def finalize_message(text_buffer: list[str], *, run_state: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Finalize assistant text and mark LLM trace as done."""
    if not text_buffer:
        return []
    full_text = "".join(text_buffer)
    frames: list[dict[str, Any]] = [
        {
            "frame": "message",
            "data": {"role": "assistant", "delta": "", "done": True, "text": full_text},
        }
    ]
    state = run_state or {}
    llm_id = state.get("llm_trace_id")
    if llm_id:
        run_id = str(state.get("run_id", ""))
        frames.append(
            {
                "frame": "trace",
                "data": {
                    "id": llm_id,
                    "run_id": run_id,
                    "parent_id": str(state.get("run_trace_id") or f"{run_id}-start"),
                    "kind": "llm",
                    "status": "done",
                    "title": "模型输出",
                    "summary": full_text[:160],
                    "detail": full_text,
                },
            }
        )
    return frames
