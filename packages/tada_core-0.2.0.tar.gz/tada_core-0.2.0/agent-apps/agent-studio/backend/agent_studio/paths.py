"""Centralized filesystem paths for Agent Studio."""
from __future__ import annotations

from pathlib import Path

from sandbox.paths import RUNTIME_ROOT as _SANDBOX_RUNTIME_ROOT


REPO_ROOT = Path(__file__).resolve().parents[4]
AGENT_APPS_ROOT = REPO_ROOT / "agent-apps"
AGENT_STUDIO_ROOT = AGENT_APPS_ROOT / "agent-studio"
SANDBOX_RUNTIME_ROOT = _SANDBOX_RUNTIME_ROOT
