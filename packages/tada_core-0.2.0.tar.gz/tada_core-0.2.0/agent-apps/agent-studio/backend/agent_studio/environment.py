"""Agent Studio environment inventory and workspace helpers."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from sandbox.loop_builder import build_baseline_tool_executor
from sandbox.workspace import SandboxWorkspace
from tada_core import SessionState

from agent_studio.agents.base import RunContext
from agent_studio.agents.registry import get_plugin, list_agents
from agent_studio.paths import REPO_ROOT, SANDBOX_RUNTIME_ROOT

_WORKSPACE_FILES: dict[str, Path] = {
    "AGENTS.md": REPO_ROOT / "AGENTS.md",
    "README.md": REPO_ROOT / "README.md",
    "docs/README.md": REPO_ROOT / "docs" / "README.md",
    "docs/integration-guide.md": REPO_ROOT / "docs" / "integration-guide.md",
    "agent-apps/agent-studio/README.md": REPO_ROOT / "agent-apps" / "agent-studio" / "README.md",
}

_SKILL_ROOTS: list[Path] = [
    REPO_ROOT / "agent-apps",
    REPO_ROOT / "tada_core",
]

_TOOL_GROUPS: dict[str, dict[str, str]] = {
    "sandbox": {
        "name": "Sandbox runtime",
        "description": "Coding Agent 沙箱运行时工具，来自共享 sandbox runtime。",
    },
    "core": {
        "name": "Core runtime",
        "description": "Agent Studio 核心 runtime 注册的基础工具。",
    },
    "demo": {
        "name": "Demo agents",
        "description": "用于演示 Trip / Shopping 流程的 mock 工具。",
    },
}


def _file_info(filename: str, path: Path) -> dict[str, Any]:
    stat = path.stat()
    return {
        "filename": filename,
        "path": str(path),
        "size": stat.st_size,
        "modified_time": stat.st_mtime,
    }


def list_workspace_files() -> list[dict[str, Any]]:
    """Return whitelisted markdown files that exist in this checkout."""
    return [
        _file_info(filename, path)
        for filename, path in _WORKSPACE_FILES.items()
        if path.exists() and path.is_file()
    ]


def read_workspace_file(filename: str) -> dict[str, Any] | None:
    path = _WORKSPACE_FILES.get(filename)
    if path is None or not path.exists() or not path.is_file():
        return None
    return {
        **_file_info(filename, path),
        "content": path.read_text(encoding="utf-8"),
    }


def save_workspace_file(filename: str, content: str) -> dict[str, Any] | None:
    path = _WORKSPACE_FILES.get(filename)
    if path is None:
        return None
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return {"saved": True, **_file_info(filename, path)}


def _parse_skill_file(path: Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8")
    meta: dict[str, str] = {}
    body = text
    if text.startswith("---\n"):
        _, frontmatter, remainder = text.split("---", 2)
        body = remainder.strip()
        for line in frontmatter.splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip().strip("\"'")

    title = meta.get("name") or path.parent.name
    description = meta.get("description", "")
    if not description:
        for line in body.splitlines():
            clean = line.strip()
            if clean and not clean.startswith("#"):
                description = clean
                break

    return {
        "name": title,
        "description": description,
        "content_preview": body[:800].strip(),
    }


def list_skills() -> dict[str, list[dict[str, Any]]]:
    """Return real SKILL.md files available to Agent Studio."""
    skills: list[dict[str, Any]] = []
    seen: set[Path] = set()
    for root in _SKILL_ROOTS:
        if not root.exists():
            continue
        for path in sorted(root.rglob("SKILL.md")):
            if any(part in {".venv", "node_modules", ".next"} for part in path.parts):
                continue
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            parsed = _parse_skill_file(path)
            group = str(path.parent.relative_to(REPO_ROOT)) if path.is_relative_to(REPO_ROOT) else path.parent.name
            skills.append(
                {
                    "id": parsed["name"],
                    "name": parsed["name"],
                    "description": parsed["description"],
                    "path": str(path),
                    "group": group,
                    "content_preview": parsed["content_preview"],
                }
            )
    return {"skills": skills}


def _tool_info(
    tool: Any,
    *,
    descriptor: Any,
    source: str,
    scenario_id: str | None = None,
    scenario_title: str | None = None,
) -> dict[str, Any]:
    return {
        "name": tool.name,
        "description": tool.description,
        "parameters_schema": tool.parameters_schema,
        "parallel": tool.parallel,
        "source": source,
        "agent_id": descriptor.id,
        "agent_name": descriptor.name,
        "scenario_id": scenario_id,
        "scenario_title": scenario_title,
    }


def _collect_core_or_demo_tools(descriptor: Any) -> tuple[str, list[dict[str, Any]]]:
    plugin = get_plugin(descriptor.id)
    ctx = RunContext(agent_id=descriptor.id, text="", state=SessionState())
    loop = plugin.build_loop(ctx)
    executor = getattr(loop, "_tools", None)
    tool_defs = executor.list_tools() if executor is not None else []
    source = "core" if descriptor.id == "coding-agent" else "demo"
    tools = [
        _tool_info(
            tool,
            descriptor=descriptor,
            source=source,
            scenario_id="core" if source == "core" else None,
            scenario_title="Core runtime" if source == "core" else None,
        )
        for tool in tool_defs
    ]
    return source, tools


def _collect_sandbox_tools(descriptor: Any) -> list[dict[str, Any]]:
    workspace = SandboxWorkspace(
        root=SANDBOX_RUNTIME_ROOT,
        fixture_dir=REPO_ROOT,
        session_id="inventory",
    )
    executor = build_baseline_tool_executor(workspace)
    return [
        _tool_info(
            tool,
            descriptor=descriptor,
            source="sandbox",
            scenario_id="baseline",
            scenario_title="Baseline sandbox runtime",
        )
        for tool in executor.list_tools()
    ]


def list_tools() -> dict[str, list[dict[str, Any]]]:
    """Build a best-effort tool inventory grouped by runtime source."""
    grouped: dict[str, list[dict[str, Any]]] = {source: [] for source in _TOOL_GROUPS}
    errors: dict[str, list[str]] = {source: [] for source in _TOOL_GROUPS}

    for descriptor in list_agents():
        try:
            source, tools = _collect_core_or_demo_tools(descriptor)
            grouped[source].extend(tools)
        except Exception as exc:
            source = "core" if descriptor.id == "coding-agent" else "demo"
            errors[source].append(f"{descriptor.name}: {exc}")

        if descriptor.id == "coding-agent":
            try:
                grouped["sandbox"].extend(_collect_sandbox_tools(descriptor))
            except Exception as exc:
                errors["sandbox"].append(f"{descriptor.name}: {exc}")

    groups: list[dict[str, Any]] = []
    for source, meta in _TOOL_GROUPS.items():
        groups.append(
            {
                "name": meta["name"],
                "agent_id": source,
                "source": source,
                "description": meta["description"],
                "tools": grouped[source],
                "error": "; ".join(errors[source]) or None,
            }
        )
    return {"groups": groups}
