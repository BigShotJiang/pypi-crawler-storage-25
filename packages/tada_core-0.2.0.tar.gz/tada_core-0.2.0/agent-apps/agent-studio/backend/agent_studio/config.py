"""Host-level configuration persistence."""
from __future__ import annotations

import json
import os
import pathlib

_CONFIG_PATH = pathlib.Path(__file__).resolve().parents[1] / ".config.json"

_DEFAULTS: dict[str, str] = {
    "base_url": "",
    "api_key": "",
    "model_id": "",
    "protocol": "anthropic",
    "default_agent_id": "coding-agent",
    "theme": "cursor-dark",
}


def load_config() -> dict[str, str]:
    if _CONFIG_PATH.exists():
        try:
            data = json.loads(_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {**_DEFAULTS, **{k: str(v) for k, v in data.items()}}
        except Exception:
            pass
    return dict(_DEFAULTS)


def save_config(updates: dict[str, str]) -> dict[str, str]:
    current = load_config()
    for key, val in updates.items():
        if val:
            current[key] = val
        elif key in ("base_url", "model_id", "protocol", "default_agent_id", "theme") and val == "":
            current.pop(key, None)
            current[key] = _DEFAULTS.get(key, "")
    _CONFIG_PATH.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
    return current


def public_config() -> dict:
    cfg = load_config()
    api_key = cfg.get("api_key") or os.environ.get("API_KEY", "")
    return {
        "base_url": cfg.get("base_url", ""),
        "model_id": cfg.get("model_id", ""),
        "protocol": cfg.get("protocol", "anthropic"),
        "default_agent_id": cfg.get("default_agent_id", "coding-agent"),
        "theme": cfg.get("theme", "cursor-dark"),
        "api_key_set": bool(api_key),
        "echo_mode": not bool(api_key),
    }
