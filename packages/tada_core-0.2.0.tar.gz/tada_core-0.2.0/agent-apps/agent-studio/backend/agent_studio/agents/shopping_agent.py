"""Shopping agent — mock product search and comparison artifacts."""
from __future__ import annotations

import json
import uuid
from typing import Any

from tada_core import AgentLoop
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

from agent_studio.agents.base import AgentDescriptor, AgentPlugin, ArtifactEnvelope, RunContext
from agent_studio.model_factory import build_model

DESCRIPTOR = AgentDescriptor(
    id="shopping-agent",
    name="Shopping Agent",
    description="购物比价助手 — 商品检索与对比（mock）",
    icon="🛒",
    accent_color="#e07a5f",
    artifact_kinds=["product_grid", "markdown", "json"],
    example_prompts=[
        "找一款 2000 元以内的轻薄笔记本，用于写代码",
        "对比三款无线降噪耳机",
    ],
    category="shopping",
)


def _search_products(args: dict) -> str:
    query = args.get("query", "笔记本")
    budget = int(args.get("budget_cny", 5000))
    products = [
        {
            "id": "p1",
            "name": f"{query} Pro 14",
            "brand": "Lenovo",
            "price_cny": min(4599, budget),
            "rating": 4.6,
            "tags": ["轻薄", "16GB"],
        },
        {
            "id": "p2",
            "name": f"{query} Air M2",
            "brand": "Apple",
            "price_cny": min(7999, budget + 2000),
            "rating": 4.8,
            "tags": ["续航", "静音"],
        },
        {
            "id": "p3",
            "name": f"{query} Book 14",
            "brand": "Huawei",
            "price_cny": min(3999, budget),
            "rating": 4.4,
            "tags": ["触控屏", "便携"],
        },
    ]
    return json.dumps({"query": query, "products": products}, ensure_ascii=False)


class ShoppingAgentPlugin(AgentPlugin):
    descriptor = DESCRIPTOR

    def build_loop(self, ctx: RunContext) -> AgentLoop:
        try:
            model = build_model()
        except Exception:
            model = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)

        ex = InMemoryToolExecutor()
        ex.register(
            ToolDefinition(
                name="search_products",
                description="Search products by query and budget (mock)",
                parameters_schema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "budget_cny": {"type": "number"},
                    },
                    "required": ["query"],
                },
            ),
            lambda inp: _search_products(json.loads(inp) if inp else {}),
        )

        loop = AgentLoop(
            model,
            system_prompt=[
                "你是购物比价助手。调用 search_products 获取候选，"
                "用中文总结筛选逻辑、推荐排序和购买建议。"
            ],
            max_iterations=6,
        )
        loop.set_tool_executor(ex)
        return loop

    def artifacts_from_events(
        self, events: list[dict[str, Any]], ctx: RunContext
    ) -> list[ArtifactEnvelope]:
        products: list[dict] = []
        for ev in events:
            if ev.get("type") != "tool_result":
                continue
            try:
                data = json.loads(str(ev.get("output", "{}")))
                products = data.get("products", products)
            except Exception:
                pass

        if not products:
            products = [
                {"id": "p1", "name": "示例商品 A", "brand": "Demo", "price_cny": 1999, "rating": 4.5},
                {"id": "p2", "name": "示例商品 B", "brand": "Demo", "price_cny": 2499, "rating": 4.7},
            ]

        return [
            ArtifactEnvelope(
                id=uuid.uuid4().hex[:10],
                kind="product_grid",
                title="商品对比",
                payload={
                    "query": ctx.text,
                    "products": products,
                    "filters": {"budget_cny": 5000, "sort": "rating"},
                },
            )
        ]
