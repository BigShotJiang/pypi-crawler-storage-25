"""Agent plugin contract."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

from tada_core import AgentLoop, SessionState


@dataclass(frozen=True)
class AgentDescriptor:
    id: str
    name: str
    description: str
    icon: str
    accent_color: str
    artifact_kinds: list[str]
    example_prompts: list[str]
    category: str = "general"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "icon": self.icon,
            "accent_color": self.accent_color,
            "artifact_kinds": self.artifact_kinds,
            "example_prompts": self.example_prompts,
            "category": self.category,
        }


@dataclass
class ArtifactEnvelope:
    id: str
    kind: str
    title: str
    payload: dict[str, Any]
    mime: str = "application/json"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "kind": self.kind,
            "title": self.title,
            "payload": self.payload,
            "mime": self.mime,
        }


@dataclass
class RunContext:
    agent_id: str
    text: str
    state: SessionState
    scenario: str = "default"
    extras: dict[str, Any] = field(default_factory=dict)


class AgentPlugin(ABC):
    descriptor: AgentDescriptor

    @abstractmethod
    def build_loop(self, ctx: RunContext) -> AgentLoop:
        """Create an AgentLoop configured for this run."""

    def list_scenarios(self) -> list[dict[str, Any]]:
        return []

    def artifacts_from_events(
        self, events: list[dict[str, Any]], ctx: RunContext
    ) -> list[ArtifactEnvelope]:
        return []

    async def run_probe(self, ctx: RunContext, probe_id: str) -> dict[str, Any]:
        raise NotImplementedError(f"probes are not supported for {ctx.agent_id}")

    async def run_turn(self, ctx: RunContext) -> AsyncIterator[Any]:
        loop = self.build_loop(ctx)
        async for event in loop.run_turn(ctx.state, ctx.text):
            yield event
