"""Agent plugin registry."""
from __future__ import annotations

from agent_studio.agents.base import AgentDescriptor, AgentPlugin
from agent_studio.agents.coding_agent import CodingAgentPlugin
from agent_studio.agents.shopping_agent import ShoppingAgentPlugin
from agent_studio.agents.trip_agent import TripAgentPlugin

_PLUGINS: dict[str, AgentPlugin] = {
    "coding-agent": CodingAgentPlugin(),
    "trip-agent": TripAgentPlugin(),
    "shopping-agent": ShoppingAgentPlugin(),
}


def list_agents() -> list[AgentDescriptor]:
    return [p.descriptor for p in _PLUGINS.values()]


def get_plugin(agent_id: str) -> AgentPlugin:
    plugin = _PLUGINS.get(agent_id)
    if plugin is None:
        raise KeyError(f"unknown agent: {agent_id}")
    return plugin


def list_agent_dicts() -> list[dict]:
    return [d.to_dict() for d in list_agents()]
