"""Trip planning agent — mock tools and itinerary artifacts."""
from __future__ import annotations

import json
import uuid
from typing import Any

from tada_core import AgentLoop
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

from agent_studio.agents.base import AgentDescriptor, AgentPlugin, ArtifactEnvelope, RunContext
from agent_studio.model_factory import build_model

DESCRIPTOR = AgentDescriptor(
    id="trip-agent",
    name="Trip Agent",
    description="旅行规划助手 — 行程、预算与景点推荐（mock）",
    icon="✈",
    accent_color="#5b9fd4",
    artifact_kinds=["trip_plan", "markdown", "json"],
    example_prompts=[
        "帮我规划东京 3 日游，预算中等，喜欢美食和博物馆",
        "上海周末亲子游，两天一夜",
    ],
    category="travel",
)


def _search_flights(args: dict) -> str:
    origin = args.get("origin", "上海")
    dest = args.get("destination", "东京")
    return json.dumps(
        {
            "flights": [
                {"airline": "ANA", "price_cny": 2100, "depart": f"{origin} 08:30", "arrive": f"{dest} 12:45"},
                {"airline": "JAL", "price_cny": 2350, "depart": f"{origin} 14:10", "arrive": f"{dest} 18:20"},
            ]
        },
        ensure_ascii=False,
    )


def _search_hotels(args: dict) -> str:
    city = args.get("city", "东京")
    return json.dumps(
        {
            "hotels": [
                {"name": f"{city} 新宿格兰贝尔", "stars": 4, "price_cny": 680, "area": "新宿"},
                {"name": f"{city} 浅草豪景", "stars": 3, "price_cny": 520, "area": "浅草"},
            ]
        },
        ensure_ascii=False,
    )


class TripAgentPlugin(AgentPlugin):
    descriptor = DESCRIPTOR

    def build_loop(self, ctx: RunContext) -> AgentLoop:
        try:
            model = build_model()
        except Exception:
            model = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)

        ex = InMemoryToolExecutor()
        ex.register(
            ToolDefinition(
                name="search_flights",
                description="Search flights between cities (mock)",
                parameters_schema={
                    "type": "object",
                    "properties": {
                        "origin": {"type": "string"},
                        "destination": {"type": "string"},
                    },
                },
            ),
            lambda inp: _search_flights(json.loads(inp) if inp else {}),
        )
        ex.register(
            ToolDefinition(
                name="search_hotels",
                description="Search hotels in a city (mock)",
                parameters_schema={
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                },
            ),
            lambda inp: _search_hotels(json.loads(inp) if inp else {}),
        )

        loop = AgentLoop(
            model,
            system_prompt=[
                "你是旅行规划助手。根据用户需求调用 search_flights 和 search_hotels，"
                "然后给出按天划分的行程建议、预算摘要和注意事项。回复使用中文。"
            ],
            max_iterations=8,
        )
        loop.set_tool_executor(ex)
        return loop

    def artifacts_from_events(
        self, events: list[dict[str, Any]], ctx: RunContext
    ) -> list[ArtifactEnvelope]:
        flights, hotels = [], []
        for ev in events:
            if ev.get("type") != "tool_result":
                continue
            try:
                data = json.loads(str(ev.get("output", "{}")))
            except Exception:
                continue
            if "flights" in data:
                flights = data["flights"]
            if "hotels" in data:
                hotels = data["hotels"]

        days = [
            {"day": 1, "title": "抵达与浅草", "items": ["浅草寺", "晴空塔夜景", "居酒屋晚餐"]},
            {"day": 2, "title": "博物馆与美食", "items": ["上野博物馆", "阿美横丁", "寿司午餐"]},
            {"day": 3, "title": "购物与返程", "items": ["新宿购物", "机场免税店"]},
        ]
        return [
            ArtifactEnvelope(
                id=uuid.uuid4().hex[:10],
                kind="trip_plan",
                title="行程草案",
                payload={
                    "destination": "东京",
                    "days": days,
                    "budget_cny": {"flights": 2100, "hotels": 680 * 2, "daily": 400},
                    "flights": flights or [{"airline": "ANA", "price_cny": 2100}],
                    "hotels": hotels or [{"name": "新宿格兰贝尔", "price_cny": 680}],
                    "user_query": ctx.text,
                },
            )
        ]
