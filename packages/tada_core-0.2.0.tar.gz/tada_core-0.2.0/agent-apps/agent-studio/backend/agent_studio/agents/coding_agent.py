"""Coding agent plugin — tada-core validation + sandbox scenarios."""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any, AsyncIterator

from sandbox.paths import RUNTIME_ROOT
from sandbox.scenarios import SANDBOX_SCENARIO_CATALOG, _meta, build_session_for_scenario
from sandbox.tasks.registry import get_task
from tada_core import AgentLoop
from tada_core.contracts.compaction import TruncateCompaction
from tada_core.contracts.hooks import FunctionHookRunner, HookResult
from tada_core.contracts.permissions import DenyListPolicy
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition

from agent_studio.agents.base import AgentDescriptor, AgentPlugin, ArtifactEnvelope, RunContext
from agent_studio.model_factory import build_model


DESCRIPTOR = AgentDescriptor(
    id="coding-agent",
    name="Coding Agent",
    description="tada-core 编码验证与沙箱围栏实验",
    icon="</>",
    accent_color="#8b7cf6",
    artifact_kinds=["code", "test_report", "audit_log", "json"],
    example_prompts=[
        "请说 hello tada-core，不要调用工具",
        "调用 echo 工具传入 {\"test\": true}",
        "运行 sb_path_jail 场景：尝试读取 /etc/passwd",
    ],
    category="developer",
)


class CodingAgentPlugin(AgentPlugin):
    descriptor = DESCRIPTOR

    def list_scenarios(self) -> list[dict[str, Any]]:
        core = [
            {
                "id": "echo_turn",
                "label": "Echo Turn",
                "scenario": "default",
                "preset_text": "请说 'hello tada-core'，不要调用任何工具。",
                "group": "core",
                "description": "单轮文本回复，不触发工具。",
            },
            {
                "id": "tool_roundtrip",
                "label": "Tool Roundtrip",
                "scenario": "default",
                "preset_text": '请调用 echo 工具，传入 JSON {"test": "hello"}。',
                "group": "core",
                "description": "验证 tool_use → tool_result 事件顺序。",
            },
            {
                "id": "permission_deny",
                "label": "Permission Deny",
                "scenario": "permission_deny",
                "preset_text": '请调用 echo 工具，传入 {"x": 1}。',
                "group": "core",
                "description": "验证权限策略拒绝工具调用。",
            },
        ]
        sandbox_group = {
            "sb_path_jail": "fence",
            "sb_shell_deny": "fence",
            "sb_audit_trace": "runtime",
            "sb_compaction_real": "runtime",
            "sb_steering": "runtime",
            "sb_task_todo_api": "task",
        }
        for meta in SANDBOX_SCENARIO_CATALOG:
            core.append(
                {
                    "id": meta.id,
                    "label": meta.title,
                    "scenario": meta.id,
                    "preset_text": meta.user_message,
                    "sandbox": True,
                    "group": sandbox_group.get(meta.id, "sandbox"),
                    "description": meta.description,
                    "probes": meta.probes,
                    "primary_output": meta.primary_output,
                }
            )
        return core

    async def run_probe(self, ctx: RunContext, probe_id: str) -> dict[str, Any]:
        from sandbox.probes import run_probe

        self._build_sandbox_loop(ctx)
        sandbox = ctx.extras.get("sandbox_session")
        if sandbox is None:
            raise RuntimeError("failed to create sandbox session")
        return await run_probe(sandbox, probe_id)

    def build_loop(self, ctx: RunContext) -> AgentLoop:
        if ctx.scenario.startswith("sb_"):
            return self._build_sandbox_loop(ctx)
        return self._build_core_loop(ctx.scenario)

    def _build_core_loop(self, scenario: str) -> AgentLoop:
        model = build_model()
        ex = InMemoryToolExecutor()
        ex.register(
            ToolDefinition(
                name="echo",
                description="Return input unchanged",
                parameters_schema={"type": "object"},
            ),
            lambda inp: inp,
        )

        async def _slow_scan(inp: str, on_update=None) -> str:
            import asyncio

            for i in range(1, 4):
                await asyncio.sleep(0.05)
                if on_update:
                    on_update(f"scanning… step {i}/3")
            return f"scan complete: {inp}"

        ex.register(
            ToolDefinition(
                name="slow_scan",
                description="Slow scan with progress",
                parameters_schema={
                    "type": "object",
                    "properties": {"target": {"type": "string"}},
                },
            ),
            _slow_scan,
        )

        loop = AgentLoop(
            model,
            system_prompt=["You are a helpful coding assistant. Keep replies concise."],
            max_iterations=16,
        )
        loop.set_tool_executor(ex)

        if scenario == "permission_deny":
            loop.set_permission_policy(DenyListPolicy({"echo"}))
        elif scenario == "hook_rewrite":

            def _pre(tool_name: str, input_json: str) -> HookResult:
                import json

                try:
                    data = json.loads(input_json)
                except Exception:
                    data = {}
                data["_hook_injected"] = True
                r = HookResult()
                r.updated_input = json.dumps(data)
                r.messages = ["hook rewrote tool input"]
                return r

            loop.set_hook_runner(FunctionHookRunner(pre=_pre))
        elif scenario == "compaction":
            loop.set_compaction_strategy(TruncateCompaction(max_messages=4))
        elif scenario == "hook_exit":
            call_count = {"n": 0}

            def _post(tool_name: str, input_json: str, output: str, *, is_error: bool) -> HookResult:
                call_count["n"] += 1
                if call_count["n"] >= 1:
                    r = HookResult()
                    r.exit_loop = True
                    r.exit_reason = "hook requested graceful exit"
                    return r
                return HookResult.allow()

            loop.set_hook_runner(FunctionHookRunner(post=_post))

        return loop

    def _build_sandbox_loop(self, ctx: RunContext) -> AgentLoop:
        session_id = ctx.extras.get("sandbox_session_id") or uuid.uuid4().hex[:8]
        registry_root = Path(
            ctx.extras.get(
                "sandbox_root",
                RUNTIME_ROOT,
            )
        )
        sandbox_session = build_session_for_scenario(
            scenario_id=ctx.scenario,
            session_id=session_id,
            registry_root=registry_root,
            task_id=ctx.extras.get("task_id"),
        )
        ctx.extras["sandbox_session"] = sandbox_session
        ctx.state = sandbox_session.state
        return sandbox_session.loop

    async def run_turn(self, ctx: RunContext) -> AsyncIterator[Any]:
        if ctx.scenario.startswith("sb_"):
            meta = _meta(ctx.scenario)
            if not ctx.extras.get("sandbox_session"):
                self._build_sandbox_loop(ctx)
            sandbox = ctx.extras["sandbox_session"]
            user_message = str(
                ctx.extras.get("user_message")
                or sandbox.extras.get("user_message")
                or meta.user_message
            )
            async for event in sandbox.loop.run_turn(sandbox.state, user_message):
                yield event
            return
        loop = self.build_loop(ctx)
        async for event in loop.run_turn(ctx.state, ctx.text):
            yield event

    def artifacts_from_events(
        self, events: list[dict[str, Any]], ctx: RunContext
    ) -> list[ArtifactEnvelope]:
        artifacts: list[ArtifactEnvelope] = []
        for ev in events:
            if ev.get("type") == "tool_result" and ev.get("tool_name") == "run_pytest":
                artifacts.append(
                    ArtifactEnvelope(
                        id=uuid.uuid4().hex[:10],
                        kind="test_report",
                        title="pytest 报告",
                        payload={
                            "output": ev.get("output", ""),
                            "is_error": ev.get("is_error", False),
                        },
                    )
                )
        if ctx.scenario.startswith("sb_task_"):
            sandbox = ctx.extras.get("sandbox_session")
            if sandbox:
                try:
                    task = get_task(str(sandbox.extras.get("task_id", ctx.scenario)))
                    result = task.acceptance_check(sandbox.workspace)
                    artifacts.append(
                        ArtifactEnvelope(
                            id=uuid.uuid4().hex[:10],
                            kind="test_report",
                            title="验收结果",
                            payload={
                                "ok": result.ok,
                                "detail": result.detail,
                                "pytest_returncode": result.pytest_returncode,
                            },
                        )
                    )
                except Exception:
                    pass
        return artifacts
