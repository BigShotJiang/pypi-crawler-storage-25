"""Deterministic sandbox probes for the validation workbench.

Probe mode proves core runtime behavior without relying on the LLM to choose a
tool. Each probe still goes through AgentLoop's real hook → permission → tool
path, so evidence matches the production event model.
"""
from __future__ import annotations

import json
from typing import Any

from sandbox.registry import SandboxSession
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole


def _dump_event(event: Any) -> dict:
    if hasattr(event, "model_dump"):
        return event.model_dump()
    return {"type": getattr(event, "type", "unknown"), "raw": str(event)}


def _event_types(events: list[Any]) -> list[str]:
    return [str(getattr(event, "type", "unknown")) for event in events]


def _check(check_id: str, label: str, passed: bool, detail: str = "") -> dict:
    return {"id": check_id, "label": label, "passed": passed, "detail": detail}


async def _run_tool_probe(
    session: SandboxSession,
    *,
    tool_use_id: str,
    tool_name: str,
    input_json: str,
) -> tuple[list[Any], bool, str]:
    events, _post, is_error, raw = await session.loop._run_one_tool(  # type: ignore[attr-defined]
        tool_use_id,
        tool_name,
        input_json,
    )
    return events, is_error, raw


async def _path_jail_read_host_file(session: SandboxSession) -> dict:
    input_json = json.dumps({"path": "/etc/passwd"})
    events, is_error, raw = await _run_tool_probe(
        session,
        tool_use_id="probe-path-jail",
        tool_name="read_file",
        input_json=input_json,
    )
    denied_event = next(
        (event for event in events if getattr(event, "type", None) == "permission"),
        None,
    )
    policy = getattr(session.loop, "_permission", None)
    reason = getattr(policy, "last_reason", None) or getattr(denied_event, "reason", None) or raw
    denied = bool(denied_event and not getattr(denied_event, "allowed", True))
    return {
        "probe_id": "path_jail.read_host_file",
        "title": "读取宿主 /etc/passwd",
        "status": "denied" if denied and is_error else "failed",
        "input": {"tool": "read_file", "json": input_json},
        "sandbox_action": "PathJailPolicy 在工具执行前做路径解析与权限判定",
        "expected": "绝对路径应被拒绝,宿主文件不能被读取",
        "checks": [
            _check("permission_denied", "PermissionEvent.allowed = false", denied, reason),
            _check("tool_not_executed", "工具结果为错误", is_error, raw),
        ],
        "evidence": {"reason": reason, "event_types": _event_types(events)},
        "raw_events": [_dump_event(event) for event in events],
    }


async def _shell_deny_all(session: SandboxSession) -> dict:
    cases = [
        ("hard_ban", "rm -rf /", "hard_ban"),
        ("network_ban", "curl https://example.com", "network_ban"),
        ("rewrite", "rm tmp.log", "rewrite"),
    ]
    checks: list[dict] = []
    raw_events: list[dict] = []
    evidence: dict[str, Any] = {}
    for check_id, cmd, expected_marker in cases:
        input_json = json.dumps({"cmd": cmd, "timeout": 5})
        events, is_error, raw = await _run_tool_probe(
            session,
            tool_use_id=f"probe-shell-{check_id}",
            tool_name="run_shell",
            input_json=input_json,
        )
        dumped = [_dump_event(event) for event in events]
        raw_events.extend(dumped)
        text = json.dumps(dumped, ensure_ascii=False) + raw
        passed = expected_marker in text
        rewritten_cmd = "rm -i tmp.log" if check_id == "rewrite" else ""
        checks.append(_check(check_id, f"{cmd} → {expected_marker}", passed, raw[:240]))
        evidence[check_id] = {
            "cmd": cmd,
            "expected": expected_marker,
            "rewritten_cmd": rewritten_cmd,
            "event_types": _event_types(events),
            "is_error": is_error,
        }
    return {
        "probe_id": "shell_deny.all",
        "title": "ShellDenyHook 三类决策",
        "status": "passed" if all(c["passed"] for c in checks) else "failed",
        "input": {"tool": "run_shell", "json": [case[1] for case in cases]},
        "sandbox_action": "ShellDenyHook 在 PRE_TOOL_USE 阶段拦截或改写命令",
        "expected": "rm -rf / 被 hard_ban,curl 被 network_ban,rm tmp.log 被改写为 rm -i tmp.log",
        "checks": checks,
        "evidence": evidence,
        "raw_events": raw_events,
    }


async def _todo_acceptance_initial(session: SandboxSession) -> dict:
    from sandbox.tasks.registry import get_task

    task_id = session.extras.get("task_id")
    if not task_id:
        raise KeyError("todo.acceptance.initial")
    result = get_task(str(task_id)).acceptance_check(session.workspace)
    return {
        "probe_id": "todo.acceptance.initial",
        "title": "Todo API 初始验收",
        "status": "failed_as_expected" if not result.ok else "unexpected_pass",
        "input": {"tool": "pytest", "json": {"target": "."}},
        "sandbox_action": "在沙箱 repo 内运行 pytest -x .",
        "expected": "空 starter 应该失败,证明任务需要 Agent 实现 app.py",
        "checks": [
            _check(
                "pytest_failed",
                "初始 pytest 失败",
                not result.ok,
                f"returncode={result.pytest_returncode}",
            )
        ],
        "evidence": {
            "pytest_returncode": result.pytest_returncode,
            "detail": result.detail,
        },
        "raw_events": [],
    }


async def _audit_trace_list_repo(session: SandboxSession) -> dict:
    input_json = json.dumps({"path": "."})
    before = session.workspace.audit_path.read_text(encoding="utf-8") if session.workspace.audit_path.exists() else ""
    events, is_error, raw = await _run_tool_probe(
        session,
        tool_use_id="probe-audit-trace",
        tool_name="list_dir",
        input_json=input_json,
    )
    after = session.workspace.audit_path.read_text(encoding="utf-8") if session.workspace.audit_path.exists() else ""
    new_lines = [line for line in after[len(before):].splitlines() if line.strip()]
    last_record = json.loads(new_lines[-1]) if new_lines else {}
    ok = not is_error and last_record.get("tool") == "list_dir"
    return {
        "probe_id": "audit_trace.list_repo",
        "title": "列目录并检查审计链",
        "status": "passed" if ok else "failed",
        "input": {"tool": "list_dir", "json": input_json},
        "sandbox_action": "工具成功后进入 AuditHook.post_tool_use 并写入 .audit.jsonl",
        "expected": "审计记录包含 list_dir 的输入、输出摘要和场景 ID",
        "checks": [
            _check("tool_allowed", "工具调用成功", not is_error, raw[:240]),
            _check("audit_written", "审计文件新增记录", bool(new_lines), str(last_record)),
            _check("audit_tool", "审计记录 tool=list_dir", last_record.get("tool") == "list_dir", ""),
        ],
        "evidence": {"audit_record": last_record, "event_types": _event_types(events)},
        "raw_events": [_dump_event(event) for event in events],
    }


async def _compaction_force_truncate(session: SandboxSession) -> dict:
    session.state.messages.clear()
    for i in range(14):
        session.state.messages.append(
            ConversationMessage(
                role=MessageRole.USER if i % 2 == 0 else MessageRole.ASSISTANT,
                content=[ContentBlock(type="text", text=f"history message {i}")],
            )
        )
    events = [event async for event in session.loop.run_turn(session.state, "trigger compaction")]
    compaction = next((event for event in events if getattr(event, "type", None) == "compaction"), None)
    removed = int(getattr(compaction, "removed_message_count", 0)) if compaction else 0
    ok = compaction is not None and removed > 0
    return {
        "probe_id": "compaction.force_truncate",
        "title": "强制触发截断压缩",
        "status": "passed" if ok else "failed",
        "input": {"messages_before_turn": 14, "user_text": "trigger compaction"},
        "sandbox_action": "TruncateCompaction(max_messages=10) 在 pre_turn/post_turn 阶段检查 SessionState",
        "expected": "事件流出现 compaction 且 removed_message_count > 0",
        "checks": [
            _check("compaction_event", "出现 CompactionEvent", compaction is not None, ""),
            _check("removed_messages", "移除历史消息", removed > 0, f"removed={removed}"),
        ],
        "evidence": {
            "removed_message_count": removed,
            "messages_after": len(session.state.messages),
            "event_types": _event_types(events),
        },
        "raw_events": [_dump_event(event) for event in events],
    }


async def _steering_inject_message(session: SandboxSession) -> dict:
    if session.steering is None:
        raise KeyError("steering.inject_message")
    session.steering.push("先读取 README,不要继续 shell")
    result = await session.steering.post_tool_use("list_dir", "{}", "[]", is_error=False)
    texts = [msg.text_only() for msg in result.steering_messages]
    ok = texts == ["先读取 README,不要继续 shell"]
    return {
        "probe_id": "steering.inject_message",
        "title": "注入运行时干预",
        "status": "passed" if ok else "failed",
        "input": {"message": "先读取 README,不要继续 shell"},
        "sandbox_action": "SteeringQueueHook 将用户消息转成 ConversationMessage 注入下一轮规划",
        "expected": "HookResult.steering_messages 包含一条 USER 消息",
        "checks": [
            _check("message_enqueued", "消息进入 steering 队列", ok, str(texts)),
            _check("not_denied", "不阻断当前工具", not result.denied, ""),
        ],
        "evidence": {"messages": texts, "message_count": len(result.steering_messages)},
        "raw_events": [],
    }


_PROBES = {
    "path_jail.read_host_file": _path_jail_read_host_file,
    "shell_deny.all": _shell_deny_all,
    "audit_trace.list_repo": _audit_trace_list_repo,
    "compaction.force_truncate": _compaction_force_truncate,
    "steering.inject_message": _steering_inject_message,
    "todo.acceptance.initial": _todo_acceptance_initial,
}


async def run_probe(session: SandboxSession, probe_id: str) -> dict:
    if probe_id not in _PROBES:
        raise KeyError(probe_id)
    return await _PROBES[probe_id](session)
