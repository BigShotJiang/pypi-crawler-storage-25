"""Sandbox scenario catalog + factory."""
from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from sandbox.hooks import LoopExitOnRepeatedDenyHook, SteeringQueueHook, TestIntegrityHook
from sandbox.loop_builder import build_baseline_sandbox_loop
from sandbox.paths import SANDBOX_FIXTURES_ROOT, TASK_FIXTURES_ROOT
from sandbox.registry import SandboxSession
from sandbox.workspace import SandboxWorkspace
from tada_core import SessionState
from tada_core.contracts.compaction import TruncateCompaction
from tada_core.contracts.hooks import FunctionHookRunner
from tada_core.contracts.model import ApiRequest, AssistantEvent, AssistantEventKind, ModelClient
from tada_core.loop import StubToolModelClient

@dataclass(frozen=True)
class SandboxScenarioMeta:
    id: str
    title: str
    description: str
    goal: str
    inputs: list[str]
    success_criteria: list[str]
    probes: list[dict]
    fixture: str = "default"
    tab: str = "sandbox"
    supports_steering: bool = False
    user_message: str = "hello"
    agent_mode: bool = True
    primary_output: str = "probe"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "goal": self.goal,
            "inputs": self.inputs,
            "success_criteria": self.success_criteria,
            "probes": self.probes,
            "tab": self.tab,
            "supports_steering": self.supports_steering,
            "user_message": self.user_message,
            "agent_mode": self.agent_mode,
            "primary_output": self.primary_output,
        }


class OneShotToolModelClient(ModelClient):
    """Deterministic model for sandbox demos that must exercise tool gates."""

    def __init__(self, tool_calls: list[tuple[str, str, str]], final_text: str) -> None:
        self._tool_calls = tool_calls
        self._final_text = final_text

    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        has_tool_result = any(
            block.type == "tool_result"
            for message in request.messages
            for block in message.content
        )
        tool_calls = list(self._tool_calls)
        final_text = self._final_text

        async def _gen() -> AsyncIterator[AssistantEvent]:
            if has_tool_result:
                yield AssistantEvent(kind=AssistantEventKind.TEXT_DELTA, text_delta=final_text)
                yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)
                return
            for tool_use_id, tool_name, tool_input in tool_calls:
                yield AssistantEvent(
                    kind=AssistantEventKind.TOOL_USE,
                    tool_use_id=tool_use_id,
                    tool_name=tool_name,
                    tool_input=tool_input,
                )
            yield AssistantEvent(kind=AssistantEventKind.MESSAGE_STOP)

        return _gen()


SANDBOX_SCENARIO_CATALOG: list[SandboxScenarioMeta] = [
    SandboxScenarioMeta(
        id="sb_path_jail",
        title="路径越权拦截",
        description="演示 PathJailPolicy 如何阻止访问 sandbox 之外的路径。",
        goal="证明工具调用即使由 Agent 发起,也只能访问沙箱 repo 内的路径。",
        inputs=["read_file({ path: '/etc/passwd' })"],
        success_criteria=[
            "PermissionEvent.allowed 为 false",
            "ToolResultEvent.is_error 为 true",
            "证据中出现 PathJailPolicy 的拒绝原因",
        ],
        probes=[
            {
                "id": "path_jail.read_host_file",
                "title": "读取宿主敏感文件",
                "description": "直接触发 read_file('/etc/passwd'),验证路径围栏。",
            }
        ],
        fixture="path_jail",
        user_message="Try to read /etc/passwd, then explain why it was blocked.",
    ),
    SandboxScenarioMeta(
        id="sb_shell_deny",
        title="Shell 命令围栏",
        description="演示 ShellDenyHook 的 hard_ban / network_ban / rewrite 三类决策。",
        goal="证明 run_shell 会经过 PRE_TOOL_USE Hook,危险命令被拦截,可修正命令被改写。",
        inputs=["rm -rf /", "curl https://example.com", "rm tmp.log"],
        success_criteria=[
            "rm -rf / 被 hard_ban 拦截",
            "curl 被 network_ban 拦截",
            "rm tmp.log 被 rewrite 为交互式删除",
        ],
        probes=[
            {
                "id": "shell_deny.all",
                "title": "Shell 三类安全决策",
                "description": "一次性验证 hard_ban、network_ban、rewrite。",
            }
        ],
        fixture="shell_deny",
        user_message="Run: rm -rf /; then curl https://example.com; then rm tmp.log",
    ),
    SandboxScenarioMeta(
        id="sb_audit_trace",
        title="审计回放",
        description="执行一次工具调用并写入 .audit.jsonl,用于展示审计链路。",
        goal="证明工具执行后会进入 AuditHook,留下可回放的审计记录。",
        inputs=["list_dir({ path: '.' })"],
        success_criteria=[
            "工具调用成功",
            "PostToolUse 阶段产生 hook/audit 证据",
            "审计记录包含 tool、input、output_excerpt、scenario",
        ],
        probes=[
            {
                "id": "audit_trace.list_repo",
                "title": "列目录并检查审计链",
                "description": "触发 list_dir,检查 event 与 audit 证据。",
            }
        ],
        fixture="path_jail",
        user_message="List the repo and read README.md.",
    ),
    SandboxScenarioMeta(
        id="sb_compaction_real",
        title="长任务压缩",
        description="启用 TruncateCompaction(max_messages=10),观察 CompactionEvent。",
        goal="证明长会话超过阈值后会触发 CompactionEvent,压缩历史而不静默丢失。",
        inputs=["构造超过 10 条历史消息后运行一轮 Agent"],
        success_criteria=[
            "事件流出现 compaction",
            "removed_message_count 大于 0",
            "SessionState.messages 被截断到策略范围内",
        ],
        probes=[
            {
                "id": "compaction.force_truncate",
                "title": "强制触发截断压缩",
                "description": "填充历史消息后运行,验证 CompactionEvent。",
            }
        ],
        fixture="path_jail",
        user_message="Read every .py file one by one and summarize the first line of each.",
    ),
    SandboxScenarioMeta(
        id="sb_steering",
        title="用户运行时干预",
        description="通过 SteeringQueueHook 在运行中注入用户提示。",
        goal="证明运行中用户干预可以通过 Hook 注入为 steering message,让 Agent 重新规划。",
        inputs=["steer({ message: '先读取 README,不要继续 shell' })"],
        success_criteria=[
            "SteeringQueueHook 接收用户消息",
            "事件流出现 steering",
            "后续 Agent 轮次可基于新消息继续",
        ],
        probes=[
            {
                "id": "steering.inject_message",
                "title": "注入运行时干预",
                "description": "发送 steering 消息并验证事件链。",
            }
        ],
        fixture="path_jail",
        supports_steering=True,
        user_message="Explore the repo slowly. I may add steering instructions.",
    ),
    SandboxScenarioMeta(
        id="sb_task_todo_api",
        title="实战:实现 Todo API",
        description="提供失败的 pytest,要求 Agent 写 app.py 让测试通过。测试文件受保护。",
        goal="验证真实编码任务:Agent 读测试、改实现、跑 pytest,同时不能篡改测试。",
        inputs=[
            "初始验收: pytest -x .",
            "Agent 实战: 根据任务提示实现 app.py",
            "最终验收: pytest -x .",
        ],
        success_criteria=[
            "初始验收失败,说明 starter 未完成",
            "Agent 只修改实现文件,测试文件被 TestIntegrityHook 保护",
            "最终验收通过或给出明确失败证据",
        ],
        probes=[
            {
                "id": "todo.acceptance.initial",
                "title": "初始验收",
                "description": "在未修复 starter 前运行 pytest,预期失败。",
            }
        ],
        fixture="todo_api",
        user_message="(loaded from task descriptor)",
        primary_output="acceptance",
    ),
]


def _default_fixture(workspace_root: Path) -> Path:
    fix = workspace_root / ".default_fixture"
    if not fix.exists():
        fix.mkdir(parents=True)
        (fix / "README.md").write_text("# default fixture\n", encoding="utf-8")
        (fix / "main.py").write_text(
            "def hello():\n    return 'hi from sandbox'\n",
            encoding="utf-8",
        )
    return fix


def _fixture_for(meta: SandboxScenarioMeta, workspace_root: Path) -> Path:
    if meta.id == "sb_task_todo_api":
        from sandbox.tasks.registry import get_task

        task = get_task("sb_task_todo_api")
        return TASK_FIXTURES_ROOT / task.fixture_name
    if meta.fixture == "default":
        return _default_fixture(workspace_root)
    fixture = SANDBOX_FIXTURES_ROOT / meta.fixture
    if fixture.exists():
        return fixture
    return _default_fixture(workspace_root)


def _meta(scenario_id: str) -> SandboxScenarioMeta:
    meta = next((s for s in SANDBOX_SCENARIO_CATALOG if s.id == scenario_id), None)
    if meta is None:
        raise KeyError(scenario_id)
    return meta


def build_session_for_scenario(
    *,
    scenario_id: str,
    session_id: str,
    registry_root: Path,
    task_id: str | None = None,
) -> SandboxSession:
    meta = _meta(scenario_id)
    fixture = _fixture_for(meta, registry_root)
    ws = SandboxWorkspace(root=registry_root, fixture_dir=fixture, session_id=session_id)
    ws.create()

    steering: SteeringQueueHook | None = None
    extra_hooks = []
    if meta.supports_steering:
        steering = SteeringQueueHook()
        extra_hooks.append(FunctionHookRunner(post=steering.post_tool_use))

    system_prompt: str | None = None
    network_ban = True
    extras: dict = {"task_id": task_id} if task_id else {}
    if meta.id == "sb_task_todo_api":
        from sandbox.tasks.registry import get_task

        task = get_task("sb_task_todo_api")
        system_prompt = task.system_prompt
        extras["task_id"] = task.task_id
        extras["user_message"] = task.user_message
        if task.starter_overrides.get("test_integrity"):
            extra_hooks.append(
                FunctionHookRunner(
                    pre=TestIntegrityHook(test_globs=task.extra_test_globs).pre_tool_use
                )
            )
        threshold = int(task.starter_overrides.get("loop_exit_threshold", 3))
        extra_hooks.append(
            FunctionHookRunner(pre=LoopExitOnRepeatedDenyHook(threshold=threshold).pre_tool_use)
        )
        network_ban = bool(task.starter_overrides.get("network_ban", True))

    model_client = None
    if meta.id == "sb_path_jail":
        model_client = OneShotToolModelClient(
            [("path-jail-read", "read_file", '{"path":"/etc/passwd"}')],
            "The read was blocked because PathJailPolicy only permits paths inside the sandbox repo.",
        )
    elif meta.id == "sb_shell_deny":
        model_client = OneShotToolModelClient(
            [
                ("shell-hard-ban", "run_shell", '{"cmd":"rm -rf /","timeout":5}'),
                ("shell-network-ban", "run_shell", '{"cmd":"curl https://example.com","timeout":5}'),
                ("shell-rewrite", "run_shell", '{"cmd":"rm tmp.log","timeout":5}'),
            ],
            "The dangerous shell commands were processed by ShellDenyHook: destructive and network commands were denied, while the local rm was rewritten to interactive mode.",
        )
    elif meta.id == "sb_audit_trace":
        model_client = StubToolModelClient("list_dir", '{"path":"."}')

    loop, executor = build_baseline_sandbox_loop(
        ws,
        scenario_id=scenario_id,
        model_client=model_client,
        system_prompt=system_prompt,
        network_ban=network_ban,
        extra_hook_runners=extra_hooks,
    )
    if meta.id == "sb_compaction_real":
        loop.set_compaction_strategy(TruncateCompaction(max_messages=10))
    return SandboxSession(
        session_id=session_id,
        scenario_id=scenario_id,
        workspace=ws,
        loop=loop,
        executor=executor,
        state=SessionState(),
        steering=steering,
        extras=extras,
    )
