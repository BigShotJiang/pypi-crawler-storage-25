"""SandboxWorkspace: per-session directory + fixture replication + audit log.

A SandboxWorkspace owns ``<root>/<session_id>/`` which contains:

- ``repo/`` — copy of ``fixture_dir``, fully writable by tools
- ``.audit.jsonl`` — append-only log of policy/hook decisions

All paths resolve inside ``repo/``; ``resolve_inside`` rejects traversal and
absolute paths. The workspace itself does NOT enforce permissions beyond
path resolution; PathJailPolicy / hooks build on top of these primitives.
"""
from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SandboxWorkspace:
    root: Path
    fixture_dir: Path
    session_id: str

    @property
    def session_root(self) -> Path:
        return self.root / self.session_id

    @property
    def repo_root(self) -> Path:
        return self.session_root / "repo"

    @property
    def audit_path(self) -> Path:
        return self.session_root / ".audit.jsonl"

    def create(self) -> None:
        """Create or replace the session work-tree from ``fixture_dir``."""
        if self.session_root.exists():
            shutil.rmtree(self.session_root)
        self.session_root.mkdir(parents=True)
        shutil.copytree(self.fixture_dir, self.repo_root)
        self.audit_path.touch()

    def reset(self) -> None:
        """Alias for ``create`` — drops user changes, restores fixture."""
        self.create()

    def destroy(self) -> None:
        """Remove the entire session directory (idempotent)."""
        if self.session_root.exists():
            shutil.rmtree(self.session_root)

    def resolve_inside(self, relative_path: str) -> Path:
        """Resolve a user-supplied path under repo_root.

        Rejects absolute paths and any path that, after resolution, escapes
        the sandbox repo. Symlinks pointing outside the repo are also caught
        because ``Path.resolve()`` follows them before the relative-to check.
        """
        if Path(relative_path).is_absolute():
            raise PermissionError(
                f"absolute path '{relative_path}' is not allowed in sandbox"
            )
        repo = self.repo_root.resolve()
        candidate = (self.repo_root / relative_path).resolve()
        try:
            candidate.relative_to(repo)
        except ValueError as exc:
            raise PermissionError(
                f"path '{relative_path}' resolved outside sandbox root"
            ) from exc
        return candidate

    def audit_append(self, record: dict) -> None:
        """Append a single JSON record to the audit log."""
        with self.audit_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
