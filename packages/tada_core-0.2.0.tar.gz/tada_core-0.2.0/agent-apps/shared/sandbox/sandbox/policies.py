"""Permission policies that enforce sandbox path-jail semantics."""
from __future__ import annotations

import json

from sandbox.workspace import SandboxWorkspace
from tada_core.contracts.permissions import (
    PermissionContext,
    PermissionOutcome,
    PermissionPolicy,
    PermissionPrompter,
)


_PATH_TOOLS = {"read_file", "write_file", "apply_patch", "grep", "list_dir"}


class PathJailPolicy(PermissionPolicy):
    """Deny tool calls whose ``path`` field resolves outside sandbox root.

    Tools without a path field pass through. The tool implementation can still
    return a structured input error for malformed payloads.
    """

    def __init__(self, workspace: SandboxWorkspace) -> None:
        self._ws = workspace
        self.last_reason: str | None = None

    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:
        self.last_reason = None
        if tool_name not in _PATH_TOOLS:
            return PermissionOutcome.ALLOW
        try:
            data = json.loads(tool_input)
        except (json.JSONDecodeError, ValueError, TypeError):
            return PermissionOutcome.ALLOW

        path = data.get("path")
        if not isinstance(path, str) or not path:
            return PermissionOutcome.ALLOW

        try:
            self._ws.resolve_inside(path)
        except PermissionError as exc:
            self.last_reason = str(exc)
            return PermissionOutcome.DENY
        return PermissionOutcome.ALLOW
