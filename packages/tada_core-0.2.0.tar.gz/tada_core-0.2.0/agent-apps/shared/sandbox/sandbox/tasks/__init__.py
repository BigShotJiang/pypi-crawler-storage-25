"""Declarative TaskDescriptor framework — bundles fixture + prompt + checks.

Tasks are real-ish projects the agent has to finish (e.g. build a Todo API).
sandbox/scenarios.py reads a descriptor and assembles the AgentLoop accordingly.
"""
