"""Task: build a minimal in-memory Todo REST API and pass bundled tests."""
from __future__ import annotations

import subprocess

from sandbox.workspace import SandboxWorkspace
from sandbox.tasks.registry import AcceptanceResult, TaskDescriptor, register


_SYSTEM_PROMPT = """\
You are a focused Python engineer. Inside this sandbox repo, implement a
minimal Todo REST API in `app.py` so that `pytest -x .` passes without
modifying any test_* file.

Rules:
- Edit implementation files, not the tests under `tests/`.
- Use only Python stdlib + FastAPI + Pydantic (already available).
- After each change, run `run_pytest` to check progress.
- If a tool denies you repeatedly, pivot instead of retrying blindly.
"""


_USER_MESSAGE = (
    "Read the existing tests, design the data model + API, implement it in "
    "app.py, and run pytest until everything passes."
)


def _check(workspace: SandboxWorkspace) -> AcceptanceResult:
    proc = subprocess.run(
        ["pytest", "-x", "."],
        cwd=str(workspace.repo_root),
        capture_output=True,
        text=True,
        timeout=60,
    )
    return AcceptanceResult(
        ok=(proc.returncode == 0),
        detail=proc.stdout[-1000:] + proc.stderr[-500:],
        pytest_returncode=proc.returncode,
    )


register(
    TaskDescriptor(
        task_id="sb_task_todo_api",
        title="实现 Todo REST API",
        fixture_name="todo_api",
        system_prompt=_SYSTEM_PROMPT,
        user_message=_USER_MESSAGE,
        acceptance_check=_check,
        starter_overrides={
            "test_integrity": True,
            "network_ban": True,
            "loop_exit_threshold": 4,
        },
    )
)
