"""TaskDescriptor framework: fixture + prompt + acceptance check."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from sandbox.workspace import SandboxWorkspace


@dataclass
class AcceptanceResult:
    ok: bool
    detail: str = ""
    pytest_returncode: int | None = None


@dataclass
class TaskDescriptor:
    task_id: str
    title: str
    fixture_name: str
    system_prompt: str
    user_message: str
    acceptance_check: Callable[[SandboxWorkspace], AcceptanceResult]
    starter_overrides: dict = field(default_factory=dict)
    extra_test_globs: tuple[str, ...] = ("test_*.py", "tests/**/*.py")


_REGISTRY: dict[str, TaskDescriptor] = {}


def register(descriptor: TaskDescriptor) -> None:
    _REGISTRY[descriptor.task_id] = descriptor


def get_task(task_id: str) -> TaskDescriptor:
    if task_id not in _REGISTRY:
        raise KeyError(task_id)
    return _REGISTRY[task_id]


# Side-effect import to populate the registry.
from sandbox.tasks import todo_api as _todo_api  # noqa: E402,F401


TASK_REGISTRY = _REGISTRY
