"""In-memory registry of active sandbox sessions."""
from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from sandbox.hooks import SteeringQueueHook
from sandbox.workspace import SandboxWorkspace
from tada_core import AgentLoop, SessionState
from tada_core.contracts.tools import InMemoryToolExecutor


@dataclass
class SandboxSession:
    session_id: str
    scenario_id: str
    workspace: SandboxWorkspace
    loop: AgentLoop
    executor: InMemoryToolExecutor
    state: SessionState
    steering: SteeringQueueHook | None = None
    extras: dict = field(default_factory=dict)


class SandboxRegistry:
    """Process-local sandbox session registry.

    This validation app intentionally does not persist session metadata across
    backend restarts.
    """

    def __init__(self, root: Path) -> None:
        self._root = root
        self._lock = threading.Lock()
        self._sessions: dict[str, SandboxSession] = {}
        root.mkdir(parents=True, exist_ok=True)

    @property
    def root(self) -> Path:
        return self._root

    def new_session_id(self) -> str:
        return uuid.uuid4().hex[:12]

    def add(self, session: SandboxSession) -> None:
        with self._lock:
            self._sessions[session.session_id] = session

    def get(self, session_id: str) -> SandboxSession | None:
        with self._lock:
            return self._sessions.get(session_id)

    def remove(self, session_id: str) -> SandboxSession | None:
        with self._lock:
            return self._sessions.pop(session_id, None)

    def all_ids(self) -> list[str]:
        with self._lock:
            return list(self._sessions.keys())
