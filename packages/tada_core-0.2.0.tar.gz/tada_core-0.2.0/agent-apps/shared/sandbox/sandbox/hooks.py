"""Hooks that drive sandbox auditing and safety enforcement.

This file grows over the milestones:
- M1: AuditHook
- M2: ShellDenyHook
- M3: TestIntegrityHook, LoopExitOnRepeatedDenyHook, SteeringQueueHook
"""
from __future__ import annotations

import json
import re
import time
import fnmatch
import threading
from dataclasses import dataclass
from collections.abc import Iterable
from typing import Literal

from sandbox.workspace import SandboxWorkspace
from tada_core.contracts.hooks import HookResult
from tada_core.contracts.messages import ContentBlock, ConversationMessage, MessageRole


_OUTPUT_EXCERPT_LIMIT = 1024


@dataclass
class AuditHook:
    """Append every post_tool_use result to ``.audit.jsonl``.

    Observe-only: never denies/rewrites/exits.
    """

    workspace: SandboxWorkspace
    scenario_id: str

    async def post_tool_use(
        self,
        tool_name: str,
        input_json: str,
        output: str,
        *,
        is_error: bool,
    ) -> HookResult:
        excerpt = output[:_OUTPUT_EXCERPT_LIMIT]
        if len(output) > _OUTPUT_EXCERPT_LIMIT:
            excerpt += f"... ({len(output) - _OUTPUT_EXCERPT_LIMIT} bytes truncated)"
        self.workspace.audit_append(
            {
                "ts": time.time(),
                "tool": tool_name,
                "input": input_json[:512],
                "output_excerpt": excerpt,
                "decision": "error" if is_error else "allow",
                "decision_source": "none",
                "scenario": self.scenario_id,
                "is_error": is_error,
            }
        )
        return HookResult.allow()


class TestIntegrityHook:
    """Deny write_file / apply_patch on files matching test_globs."""

    __test__ = False
    _TARGET_TOOLS = {"write_file", "apply_patch"}

    def __init__(self, *, test_globs: Iterable[str]) -> None:
        self._globs = list(test_globs)

    def _is_test(self, path: str) -> bool:
        norm = path.replace("\\", "/").lstrip("./")
        for glob in self._globs:
            if fnmatch.fnmatch(norm, glob):
                return True
            if "/**/" in glob and fnmatch.fnmatch(norm, glob.replace("/**/", "/")):
                return True
        return False

    async def pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        if tool_name not in self._TARGET_TOOLS:
            return HookResult.allow()
        try:
            data = json.loads(input_json)
        except (ValueError, TypeError):
            return HookResult.allow()
        path = data.get("path", "")
        if not isinstance(path, str) or not self._is_test(path):
            return HookResult.allow()
        return HookResult(
            denied=True,
            messages=[
                f"test_integrity: refusing to modify protected test file '{path}'. "
                "Fix implementation code instead."
            ],
        )


class LoopExitOnRepeatedDenyHook:
    """Exit the loop after N consecutive dangerous shell attempts.

    tada-core currently has no post-permission hook. This hook therefore
    performs its own lightweight ShellDenyHook decision in pre_tool_use and
    sets ``exit_loop=True`` when the streak reaches the threshold.
    """

    def __init__(self, *, threshold: int = 3, network_ban: bool = True) -> None:
        self._threshold = threshold
        self._shell = ShellDenyHook(network_ban=network_ban)
        self._streak = 0

    async def pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        if tool_name != "run_shell":
            self._streak = 0
            return HookResult.allow()
        try:
            data = json.loads(input_json)
        except (ValueError, TypeError):
            self._streak = 0
            return HookResult.allow()
        cmd = data.get("cmd", "")
        if not isinstance(cmd, str):
            self._streak = 0
            return HookResult.allow()

        decision = self._shell.decide(cmd)
        if decision.kind not in {"hard_ban", "network_ban"}:
            self._streak = 0
            return HookResult.allow()

        self._streak += 1
        if self._streak >= self._threshold:
            return HookResult(
                denied=True,
                exit_loop=True,
                exit_reason=f"{self._streak} consecutive denied shell attempts",
                messages=[
                    f"loop_exit: {self._streak} consecutive denied shell attempts; "
                    "stopping the loop."
                ],
            )
        return HookResult.allow(messages=[f"deny_streak: {self._streak}/{self._threshold}"])


class SteeringQueueHook:
    """Deliver user-supplied steering messages to AgentLoop.

    ``HookResult.steering_messages`` expects normalized ConversationMessage
    objects, not raw strings. The runtime appends them to the session after the
    current tool and re-enters the model loop.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._queue: list[str] = []

    def push(self, msg: str) -> None:
        if not msg:
            return
        with self._lock:
            self._queue.append(msg)

    def _drain(self) -> list[str]:
        with self._lock:
            out = self._queue[:]
            self._queue.clear()
        return out

    @staticmethod
    def _to_message(text: str) -> ConversationMessage:
        return ConversationMessage(
            role=MessageRole.USER,
            content=[ContentBlock(type="text", text=text)],
        )

    async def pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        msgs = self._drain()
        if not msgs:
            return HookResult.allow()
        return HookResult(steering_messages=[self._to_message(msg) for msg in msgs])

    async def post_tool_use(
        self,
        tool_name: str,
        input_json: str,
        output: str,
        *,
        is_error: bool,
    ) -> HookResult:
        msgs = self._drain()
        if not msgs:
            return HookResult.allow()
        return HookResult(steering_messages=[self._to_message(msg) for msg in msgs])


_HARD_BAN_PATTERNS = [
    (re.compile(r"\brm\s+-[rRf]+\s+(/|~|\*|\.\.)(?:\s|$)"), "rm -rf"),
    (re.compile(r":\s*\(\s*\)\s*\{[^}]*\}\s*;\s*:"), "fork bomb"),
    (re.compile(r"\bsudo\b"), "sudo"),
    (re.compile(r"\bchmod\s+777\s+/"), "chmod 777 /"),
    (re.compile(r"\bdd\s+if=.*of=/dev"), "dd to device"),
]

_NETWORK_PATTERNS = [
    (re.compile(r"\bcurl\b"), "curl"),
    (re.compile(r"\bwget\b"), "wget"),
    (re.compile(r"\bnc\b"), "netcat"),
    (re.compile(r"\bssh\b"), "ssh"),
    (re.compile(r"\bscp\b"), "scp"),
    (re.compile(r"\bpip(?:3)?\s+install\b"), "pip install"),
    (re.compile(r"\bnpm\s+install\b"), "npm install"),
    (re.compile(r"\bapt(?:-get)?\s+install\b"), "apt install"),
    (re.compile(r"\bbrew\s+install\b"), "brew install"),
]

_RM_NEEDS_INTERACTIVE = re.compile(r"^\s*rm\s+(?!.*(?:^|\s)-[^ ]*i\b)(.+)$")


@dataclass
class ShellDecision:
    kind: Literal["allow", "hard_ban", "network_ban", "rewrite"]
    reason: str = ""
    rewritten_cmd: str = ""


class ShellDenyHook:
    """Pre-tool hook that gates ``run_shell.cmd`` for sandbox safety."""

    def __init__(self, *, network_ban: bool = True) -> None:
        self._network_ban = network_ban

    def decide(self, cmd: str) -> ShellDecision:
        for pattern, label in _HARD_BAN_PATTERNS:
            if pattern.search(cmd):
                return ShellDecision(kind="hard_ban", reason=f"matched {label}")
        if self._network_ban:
            for pattern, label in _NETWORK_PATTERNS:
                if pattern.search(cmd):
                    return ShellDecision(kind="network_ban", reason=f"matched {label}")
        m = _RM_NEEDS_INTERACTIVE.match(cmd)
        if m:
            return ShellDecision(
                kind="rewrite",
                rewritten_cmd=f"rm -i {m.group(1)}",
                reason="rm without -i auto-rewritten",
            )
        return ShellDecision(kind="allow")

    async def pre_tool_use(self, tool_name: str, input_json: str) -> HookResult:
        if tool_name != "run_shell":
            return HookResult.allow()
        try:
            data = json.loads(input_json)
        except (ValueError, TypeError):
            return HookResult.allow()
        cmd = data.get("cmd", "")
        if not isinstance(cmd, str):
            return HookResult.allow()

        decision = self.decide(cmd)
        if decision.kind == "hard_ban":
            return HookResult(denied=True, messages=[f"hard_ban: {decision.reason}"])
        if decision.kind == "network_ban":
            return HookResult(denied=True, messages=[f"network_ban: {decision.reason}"])
        if decision.kind == "rewrite":
            new_data = dict(data)
            new_data["cmd"] = decision.rewritten_cmd
            return HookResult(
                updated_input=json.dumps(new_data),
                messages=[f"rewrite: {decision.reason}"],
            )
        return HookResult.allow()
