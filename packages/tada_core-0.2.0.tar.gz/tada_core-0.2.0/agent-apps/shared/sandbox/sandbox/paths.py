"""Shared filesystem locations for the sandbox package."""
from __future__ import annotations

from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
FIXTURES_ROOT = PACKAGE_ROOT / "fixtures"
SANDBOX_FIXTURES_ROOT = FIXTURES_ROOT / "sandbox"
TASK_FIXTURES_ROOT = FIXTURES_ROOT / "tasks"
RUNTIME_ROOT = PACKAGE_ROOT / "runtime"
