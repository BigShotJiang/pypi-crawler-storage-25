"""Shared sandbox infrastructure for Agent Studio.

Owns per-session work directories, path-jail policies, hooks (audit,
shell-deny, test-integrity, steering, loop-exit), and the registry of
in-memory tools that operate inside the sandbox.

Module layout:
    workspace.py     — SandboxWorkspace (per-session repo + audit log)
    policies.py      — PathJailPolicy
    hooks.py         — AuditHook, ShellDenyHook, TestIntegrityHook,
                       LoopExitOnRepeatedDenyHook, SteeringQueueHook
    tools.py         — read_file / write_file / list_dir / grep /
                       apply_patch / run_shell / run_pytest
    loop_builder.py  — build_baseline_sandbox_loop()
    registry.py      — SandboxSession and optional in-memory registry
    scenarios.py     — sandbox scenario catalog + factory
"""
