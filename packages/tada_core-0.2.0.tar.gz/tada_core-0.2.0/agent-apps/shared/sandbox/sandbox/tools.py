"""Sandbox tool registry.

All tools resolve paths through ``SandboxWorkspace.resolve_inside``. Tool
handlers return JSON strings; errors are encoded as ``{"error": ...}`` so the
runtime surfaces them through normal ToolResultEvent flow.
"""
from __future__ import annotations

import json
import os
import re
import subprocess

from sandbox.workspace import SandboxWorkspace
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition


def _ok(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False)


def _err(msg: str) -> str:
    return json.dumps({"error": msg}, ensure_ascii=False)


def _read_file(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json)
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")

        path = args.get("path", "")
        if not isinstance(path, str) or not path:
            return _err("path is required")
        try:
            target = workspace.resolve_inside(path)
        except PermissionError as exc:
            return _err(str(exc))
        if not target.exists():
            return _err(f"file not found: {path}")
        if not target.is_file():
            return _err(f"not a file: {path}")
        try:
            return _ok({"content": target.read_text(encoding="utf-8")})
        except UnicodeDecodeError:
            return _err(f"binary file not supported: {path}")

    return fn


def _write_file(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json)
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")

        path = args.get("path", "")
        content = args.get("content", "")
        if not isinstance(path, str) or not path:
            return _err("path is required")
        if not isinstance(content, str):
            return _err("content must be a string")
        try:
            target = workspace.resolve_inside(path)
        except PermissionError as exc:
            return _err(str(exc))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return _ok({"written": str(target.relative_to(workspace.repo_root))})

    return fn


def _list_dir(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json) if input_json.strip() else {}
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")

        path = args.get("path", ".")
        if not isinstance(path, str) or not path:
            path = "."
        try:
            target = workspace.resolve_inside(path)
        except PermissionError as exc:
            return _err(str(exc))
        if not target.is_dir():
            return _err(f"not a directory: {path}")

        entries = []
        for child in sorted(target.iterdir(), key=lambda p: p.name):
            entries.append(
                {
                    "name": child.name,
                    "kind": "dir" if child.is_dir() else "file",
                    "size": child.stat().st_size if child.is_file() else None,
                }
            )
        return _ok({"entries": entries})

    return fn


def build_file_tool_executor(workspace: SandboxWorkspace) -> InMemoryToolExecutor:
    """Register the file-level sandbox tools and return the executor."""
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(
            name="read_file",
            description='Read a UTF-8 text file inside the sandbox repo. Input: {"path": str}.',
            parameters_schema={
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
            parallel=True,
        ),
        _read_file(workspace),
    )
    ex.register(
        ToolDefinition(
            name="write_file",
            description=(
                "Write a UTF-8 text file inside the sandbox repo, overwriting if it "
                'exists. Input: {"path": str, "content": str}.'
            ),
            parameters_schema={
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
            parallel=False,
        ),
        _write_file(workspace),
    )
    ex.register(
        ToolDefinition(
            name="list_dir",
            description='List entries in a directory inside the sandbox repo. Input: {"path": str}.',
            parameters_schema={
                "type": "object",
                "properties": {"path": {"type": "string"}},
            },
            parallel=True,
        ),
        _list_dir(workspace),
    )
    return ex


def _safe_env() -> dict[str, str]:
    """Whitelist a minimal env so subprocesses do not inherit secrets."""
    keep = ("PATH", "PYTHONPATH", "HOME", "LANG", "LC_ALL", "TERM")
    return {key: os.environ[key] for key in keep if key in os.environ}


def _parse_timeout(value: object, default: int, *, max_seconds: int) -> int:
    try:
        timeout = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        timeout = default
    return max(1, min(timeout, max_seconds))


def _run_shell(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json)
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")
        cmd = args.get("cmd", "")
        if not isinstance(cmd, str) or not cmd:
            return _err("cmd is required")
        timeout = _parse_timeout(args.get("timeout"), 30, max_seconds=120)

        try:
            proc = subprocess.run(
                cmd,
                shell=True,
                cwd=str(workspace.repo_root),
                env=_safe_env(),
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return _ok(
                {
                    "stdout": "",
                    "stderr": f"timed out after {timeout}s",
                    "returncode": -1,
                    "timed_out": True,
                }
            )
        return _ok(
            {
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "returncode": proc.returncode,
                "timed_out": False,
            }
        )

    return fn


def _run_pytest(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json) if input_json.strip() else {}
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")
        target = args.get("target", ".")
        if not isinstance(target, str) or not target:
            target = "."
        try:
            workspace.resolve_inside(target)
        except PermissionError as exc:
            return _err(str(exc))

        try:
            proc = subprocess.run(
                ["pytest", "-x", target],
                cwd=str(workspace.repo_root),
                env=_safe_env(),
                capture_output=True,
                text=True,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return _ok(
                {
                    "stdout": "",
                    "stderr": "pytest timed out after 60s",
                    "returncode": -1,
                    "timed_out": True,
                }
            )
        return _ok(
            {
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "returncode": proc.returncode,
                "timed_out": False,
            }
        )

    return fn


def register_shell_tools(
    ex: InMemoryToolExecutor, workspace: SandboxWorkspace
) -> InMemoryToolExecutor:
    """Add run_shell + run_pytest to an existing executor."""
    ex.register(
        ToolDefinition(
            name="run_shell",
            description=(
                "Execute a shell command inside the sandbox repo. Returns "
                'stdout/stderr/returncode/timed_out. Input: {"cmd": str, '
                '"timeout": int}.'
            ),
            parameters_schema={
                "type": "object",
                "properties": {
                    "cmd": {"type": "string"},
                    "timeout": {"type": "integer"},
                },
                "required": ["cmd"],
            },
            parallel=False,
        ),
        _run_shell(workspace),
    )
    ex.register(
        ToolDefinition(
            name="run_pytest",
            description='Run `pytest -x <target>` inside the sandbox repo. Input: {"target": str}.',
            parameters_schema={
                "type": "object",
                "properties": {"target": {"type": "string"}},
            },
            parallel=False,
        ),
        _run_pytest(workspace),
    )
    return ex


def _grep(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json)
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")
        pattern = args.get("pattern", "")
        path = args.get("path", ".")
        if not isinstance(pattern, str) or not pattern:
            return _err("pattern is required")
        if not isinstance(path, str) or not path:
            path = "."
        try:
            root = workspace.resolve_inside(path)
        except PermissionError as exc:
            return _err(str(exc))
        try:
            regex = re.compile(pattern)
        except re.error as exc:
            return _err(f"invalid regex: {exc}")

        if not root.exists():
            return _err(f"path not found: {path}")
        targets = [root] if root.is_file() else [
            p
            for p in root.rglob("*")
            if p.is_file() and p.suffix not in {".pyc", ".png", ".jpg", ".jpeg", ".gif"}
        ]
        matches: list[dict] = []
        for file_path in targets:
            try:
                text = file_path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for line_no, line in enumerate(text.splitlines(), start=1):
                if regex.search(line):
                    matches.append(
                        {
                            "path": str(file_path.relative_to(workspace.repo_root)),
                            "line": line_no,
                            "text": line,
                        }
                    )
                    if len(matches) >= 200:
                        return _ok({"matches": matches, "truncated": True})
        return _ok({"matches": matches, "truncated": False})

    return fn


def _apply_patch(workspace: SandboxWorkspace):
    def fn(input_json: str) -> str:
        try:
            args = json.loads(input_json)
        except (json.JSONDecodeError, ValueError, TypeError):
            return _err("invalid input json")
        path = args.get("path", "")
        old = args.get("old", "")
        new = args.get("new", "")
        if not isinstance(path, str) or not path:
            return _err("path is required")
        if not isinstance(old, str) or not old:
            return _err("old text is required")
        if not isinstance(new, str):
            return _err("new must be a string")
        try:
            target = workspace.resolve_inside(path)
        except PermissionError as exc:
            return _err(str(exc))
        if not target.exists():
            return _err(f"file not found: {path}")
        if not target.is_file():
            return _err(f"not a file: {path}")

        text = target.read_text(encoding="utf-8")
        count = text.count(old)
        if count == 0:
            return _err(f"old text not found in {path}")
        if count > 1:
            return _err(f"old text is ambiguous in {path} ({count} matches); add more context")
        target.write_text(text.replace(old, new, 1), encoding="utf-8")
        return _ok({"path": path, "replaced": 1})

    return fn


def register_search_tools(
    ex: InMemoryToolExecutor, workspace: SandboxWorkspace
) -> InMemoryToolExecutor:
    """Add grep + apply_patch to an existing executor."""
    ex.register(
        ToolDefinition(
            name="grep",
            description=(
                "Search a regex inside the sandbox repo recursively when path is "
                'a directory. Input: {"pattern": str, "path": str}.'
            ),
            parameters_schema={
                "type": "object",
                "properties": {
                    "pattern": {"type": "string"},
                    "path": {"type": "string"},
                },
                "required": ["pattern"],
            },
            parallel=True,
        ),
        _grep(workspace),
    )
    ex.register(
        ToolDefinition(
            name="apply_patch",
            description=(
                "Search/replace one occurrence of `old` with `new` in a file. "
                "Errors if `old` is missing or ambiguous."
            ),
            parameters_schema={
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "old": {"type": "string"},
                    "new": {"type": "string"},
                },
                "required": ["path", "old", "new"],
            },
            parallel=False,
        ),
        _apply_patch(workspace),
    )
    return ex
