"""Build an AgentLoop wired with sandbox infrastructure.

This is the seam between routes/scenarios and tada-core. HTTP route code should
not know how tools, policies, and hooks are assembled.
"""
from __future__ import annotations

from typing import Any

from sandbox.hooks import AuditHook, ShellDenyHook
from sandbox.policies import PathJailPolicy
from sandbox.tools import build_file_tool_executor, register_search_tools, register_shell_tools
from sandbox.workspace import SandboxWorkspace
from tada_core import AgentLoop
from tada_core.contracts.compaction import NeverCompact
from tada_core.contracts.hooks import CompositeHookRunner, FunctionHookRunner, HookRunner
from tada_core.contracts.model import ModelClient
from tada_core.contracts.permissions import PermissionPolicy
from tada_core.contracts.tools import InMemoryToolExecutor
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport


_DEFAULT_SYSTEM_PROMPT = (
    "You are a coding assistant working inside a strict sandbox. "
    "All file operations must stay under the repo/ root. "
    "Use read_file/write_file/grep/apply_patch/list_dir for code changes. "
    "Use run_shell or run_pytest for execution. "
    "If a tool returns an error, read it carefully and adapt."
)


def build_baseline_tool_executor(workspace: SandboxWorkspace) -> InMemoryToolExecutor:
    ex = build_file_tool_executor(workspace)
    register_search_tools(ex, workspace)
    register_shell_tools(ex, workspace)
    return ex


def _wrap_hook(obj: Any, *, pre: bool = False, post: bool = False) -> HookRunner:
    return FunctionHookRunner(
        pre=obj.pre_tool_use if pre else None,
        post=obj.post_tool_use if post else None,
    )


def build_baseline_hook_runner(
    workspace: SandboxWorkspace,
    scenario_id: str,
    *,
    network_ban: bool = True,
    extra_runners: list[HookRunner] | None = None,
) -> HookRunner:
    runners: list[HookRunner] = [
        _wrap_hook(ShellDenyHook(network_ban=network_ban), pre=True),
        _wrap_hook(AuditHook(workspace, scenario_id=scenario_id), post=True),
    ]
    if extra_runners:
        runners.extend(extra_runners)
    return CompositeHookRunner(runners)


def build_baseline_sandbox_loop(
    workspace: SandboxWorkspace,
    scenario_id: str,
    *,
    model_client: ModelClient | None = None,
    system_prompt: str | None = None,
    network_ban: bool = True,
    extra_hook_runners: list[HookRunner] | None = None,
    extra_policy: PermissionPolicy | None = None,
) -> tuple[AgentLoop, InMemoryToolExecutor]:
    """Construct an AgentLoop with the sandbox starter layer applied."""
    model = model_client
    if model is None:
        model = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)

    executor = build_baseline_tool_executor(workspace)
    loop = AgentLoop(
        model,
        system_prompt=[system_prompt or _DEFAULT_SYSTEM_PROMPT],
        max_iterations=24,
    )
    loop.set_tool_executor(executor)
    loop.set_permission_policy(extra_policy or PathJailPolicy(workspace))
    loop.set_hook_runner(
        build_baseline_hook_runner(
            workspace,
            scenario_id,
            network_ban=network_ban,
            extra_runners=extra_hook_runners,
        )
    )
    loop.set_compaction_strategy(NeverCompact())
    return loop, executor
