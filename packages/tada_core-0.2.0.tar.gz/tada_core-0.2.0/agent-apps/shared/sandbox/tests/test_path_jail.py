"""Tests for PathJailPolicy."""
from __future__ import annotations

import json

import pytest

from sandbox.policies import PathJailPolicy
from sandbox.workspace import SandboxWorkspace
from tada_core.contracts.permissions import PermissionOutcome


@pytest.fixture
def workspace(tmp_path) -> SandboxWorkspace:
    fix = tmp_path / "_fixture"
    fix.mkdir()
    (fix / "ok.txt").write_text("ok\n")
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fix, session_id="s1")
    ws.create()
    return ws


def test_allows_path_inside_repo(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize("read_file", json.dumps({"path": "ok.txt"}))
    assert out is PermissionOutcome.ALLOW
    assert p.last_reason is None


def test_denies_traversal(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize("read_file", json.dumps({"path": "../../etc/passwd"}))
    assert out is PermissionOutcome.DENY
    assert p.last_reason is not None
    assert "outside" in p.last_reason


def test_denies_absolute(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize("write_file", json.dumps({"path": "/etc/passwd", "content": "x"}))
    assert out is PermissionOutcome.DENY


def test_passthrough_for_non_path_tool(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize("run_shell", json.dumps({"cmd": "rm -rf /"}))
    assert out is PermissionOutcome.ALLOW


def test_passthrough_when_path_field_missing(workspace):
    p = PathJailPolicy(workspace)
    # list_dir without "path" defaults to repo root inside the tool itself
    out = p.authorize("list_dir", json.dumps({}))
    assert out is PermissionOutcome.ALLOW


def test_passthrough_for_invalid_json(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize("read_file", "not json")
    # PathJailPolicy is conservative on parse failures: pass-through. The tool
    # itself returns a JSON error.
    assert out is PermissionOutcome.ALLOW


def test_resets_last_reason_on_each_call(workspace):
    p = PathJailPolicy(workspace)
    p.authorize("read_file", json.dumps({"path": "../escape"}))
    assert p.last_reason is not None
    p.authorize("read_file", json.dumps({"path": "ok.txt"}))
    assert p.last_reason is None


def test_apply_patch_path_is_jailed(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize(
        "apply_patch",
        json.dumps({"path": "../boom", "old": "a", "new": "b"}),
    )
    assert out is PermissionOutcome.DENY


def test_grep_path_is_jailed(workspace):
    p = PathJailPolicy(workspace)
    out = p.authorize(
        "grep", json.dumps({"pattern": "x", "path": "/etc"}),
    )
    assert out is PermissionOutcome.DENY
