"""Shared pytest fixtures for sandbox tests."""
from __future__ import annotations

import shutil
import uuid
from pathlib import Path

import pytest


SANDBOX_ROOT = Path(__file__).resolve().parents[1] / "runtime"


@pytest.fixture
def sandbox_session(tmp_path) -> Path:
    """Provide an isolated sandbox <session_id>/repo/ directory inside tmp."""
    session_id = uuid.uuid4().hex[:8]
    session_root = tmp_path / session_id
    repo = session_root / "repo"
    repo.mkdir(parents=True)
    (session_root / ".audit.jsonl").touch()
    yield session_root
    if session_root.exists():
        shutil.rmtree(session_root)
