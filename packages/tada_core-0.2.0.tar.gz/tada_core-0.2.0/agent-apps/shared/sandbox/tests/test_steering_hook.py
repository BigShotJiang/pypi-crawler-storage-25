"""Tests for SteeringQueueHook."""
from __future__ import annotations

import asyncio

from sandbox.hooks import SteeringQueueHook
from tada_core.contracts.messages import MessageRole


def _run(coro):
    return asyncio.run(coro)


def _texts(result) -> list[str]:
    return [msg.text_only() for msg in result.steering_messages]


def test_emits_steering_message_when_queued():
    hook = SteeringQueueHook()
    hook.push("focus on the failing test_user.py first")
    res = _run(hook.pre_tool_use("read_file", "{}"))
    assert _texts(res) == ["focus on the failing test_user.py first"]
    assert res.steering_messages[0].role is MessageRole.USER
    assert res.denied is False


def test_no_steering_when_queue_empty():
    hook = SteeringQueueHook()
    res = _run(hook.pre_tool_use("read_file", "{}"))
    assert res.steering_messages == []


def test_drains_queue_in_fifo_order():
    hook = SteeringQueueHook()
    hook.push("first")
    hook.push("second")
    res = _run(hook.pre_tool_use("read_file", "{}"))
    assert _texts(res) == ["first", "second"]
    res2 = _run(hook.pre_tool_use("read_file", "{}"))
    assert res2.steering_messages == []


def test_thread_safe_push():
    import threading

    hook = SteeringQueueHook()

    def worker(n: int):
        for i in range(n):
            hook.push(f"msg-{i}")

    threads = [threading.Thread(target=worker, args=(50,)) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    res = _run(hook.pre_tool_use("read_file", "{}"))
    assert len(res.steering_messages) == 200
