"""Tests for AuditHook."""
from __future__ import annotations

import asyncio
import json

import pytest

from sandbox.hooks import AuditHook
from sandbox.workspace import SandboxWorkspace


@pytest.fixture
def workspace(tmp_path) -> SandboxWorkspace:
    fix = tmp_path / "_fixture"
    fix.mkdir()
    (fix / "README.md").write_text("ok\n")
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fix, session_id="s1")
    ws.create()
    return ws


def _run(coro):
    return asyncio.run(coro)


def test_audit_hook_appends_post_tool_record(workspace):
    hook = AuditHook(workspace=workspace, scenario_id="sb_audit_trace")
    res = _run(
        hook.post_tool_use(
            "read_file",
            '{"path":"README.md"}',
            '{"content":"ok"}',
            is_error=False,
        )
    )
    assert res.denied is False

    lines = workspace.audit_path.read_text().splitlines()
    assert len(lines) == 1
    rec = json.loads(lines[0])
    assert rec["tool"] == "read_file"
    assert rec["decision"] == "allow"
    assert rec["scenario"] == "sb_audit_trace"
    assert rec["is_error"] is False
    assert "output_excerpt" in rec


def test_audit_hook_marks_error(workspace):
    hook = AuditHook(workspace=workspace, scenario_id="sb_audit_trace")
    _run(hook.post_tool_use("read_file", "{}", '{"error":"boom"}', is_error=True))
    rec = json.loads(workspace.audit_path.read_text().splitlines()[0])
    assert rec["decision"] == "error"
    assert rec["is_error"] is True


def test_audit_hook_truncates_large_output(workspace):
    hook = AuditHook(workspace=workspace, scenario_id="sb_audit_trace")
    large = "x" * 2000
    _run(hook.post_tool_use("run_shell", "{}", large, is_error=False))
    rec = json.loads(workspace.audit_path.read_text().splitlines()[0])
    assert len(rec["output_excerpt"]) < 1200
    assert "truncated" in rec["output_excerpt"]
