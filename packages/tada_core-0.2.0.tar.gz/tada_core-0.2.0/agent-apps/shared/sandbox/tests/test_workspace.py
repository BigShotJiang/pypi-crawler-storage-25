"""Tests for SandboxWorkspace."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from sandbox.workspace import SandboxWorkspace


@pytest.fixture
def fixture_dir(tmp_path) -> Path:
    fix = tmp_path / "_fixture"
    fix.mkdir()
    (fix / "README.md").write_text("# fixture readme\n")
    sub = fix / "sub"
    sub.mkdir()
    (sub / "nested.txt").write_text("nested\n")
    return fix


def test_create_copies_fixture_and_makes_audit(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s1")
    ws.create()
    assert ws.session_root.exists()
    assert ws.repo_root.is_dir()
    assert (ws.repo_root / "README.md").read_text() == "# fixture readme\n"
    assert (ws.repo_root / "sub" / "nested.txt").read_text() == "nested\n"
    assert ws.audit_path.exists()
    assert ws.audit_path.read_text() == ""


def test_create_replaces_existing_session(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s2")
    ws.create()
    (ws.repo_root / "extra.txt").write_text("user-added")
    ws.create()  # should wipe extras
    assert not (ws.repo_root / "extra.txt").exists()
    assert (ws.repo_root / "README.md").exists()


def test_reset_is_alias_for_create(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s3")
    ws.create()
    (ws.repo_root / "scratch.txt").write_text("x")
    ws.reset()
    assert not (ws.repo_root / "scratch.txt").exists()


def test_destroy_removes_session_dir(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s4")
    ws.create()
    ws.destroy()
    assert not ws.session_root.exists()


def test_resolve_inside_accepts_relative_path(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s5")
    ws.create()
    p = ws.resolve_inside("README.md")
    assert p == (ws.repo_root / "README.md").resolve()


def test_resolve_inside_accepts_subdir(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s6")
    ws.create()
    p = ws.resolve_inside("sub/nested.txt")
    assert p == (ws.repo_root / "sub" / "nested.txt").resolve()


def test_resolve_inside_rejects_traversal(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s7")
    ws.create()
    with pytest.raises(PermissionError):
        ws.resolve_inside("../../../etc/passwd")


def test_resolve_inside_rejects_absolute(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s8")
    ws.create()
    with pytest.raises(PermissionError):
        ws.resolve_inside("/etc/passwd")


def test_audit_append_writes_jsonl(tmp_path, fixture_dir):
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fixture_dir, session_id="s9")
    ws.create()
    ws.audit_append({"tool": "read_file", "decision": "allow"})
    ws.audit_append({"tool": "write_file", "decision": "deny", "reason": "blocked"})
    lines = ws.audit_path.read_text().strip().splitlines()
    assert len(lines) == 2
    assert json.loads(lines[0])["tool"] == "read_file"
    assert json.loads(lines[1])["decision"] == "deny"
