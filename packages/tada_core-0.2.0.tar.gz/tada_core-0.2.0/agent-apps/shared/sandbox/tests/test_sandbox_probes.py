"""Tests for deterministic sandbox probes."""
from __future__ import annotations

import pytest

from sandbox.probes import run_probe
from sandbox.scenarios import build_session_for_scenario


def _session(tmp_path, scenario_id: str):
    return build_session_for_scenario(
        scenario_id=scenario_id,
        session_id=f"{scenario_id}_probe",
        registry_root=tmp_path / "sb",
        task_id=None,
    )


@pytest.mark.asyncio
async def test_path_jail_probe_returns_denied_result(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_path_jail"), "path_jail.read_host_file")
    assert result["status"] == "denied"
    assert result["checks"][0]["passed"] is True
    assert "sandbox" in result["evidence"]["reason"].lower()


@pytest.mark.asyncio
async def test_shell_probe_returns_hard_network_and_rewrite_results(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_shell_deny"), "shell_deny.all")
    checks = {check["id"]: check for check in result["checks"]}
    assert result["status"] == "passed"
    assert checks["hard_ban"]["passed"] is True
    assert checks["network_ban"]["passed"] is True
    assert checks["rewrite"]["passed"] is True


@pytest.mark.asyncio
async def test_todo_acceptance_probe_starts_failing(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_task_todo_api"), "todo.acceptance.initial")
    assert result["status"] == "failed_as_expected"
    assert result["checks"][0]["passed"] is True
    assert result["evidence"]["pytest_returncode"] != 0


@pytest.mark.asyncio
async def test_audit_probe_writes_audit_evidence(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_audit_trace"), "audit_trace.list_repo")
    assert result["status"] == "passed"
    assert result["evidence"]["audit_record"]["tool"] == "list_dir"


@pytest.mark.asyncio
async def test_compaction_probe_emits_compaction_evidence(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_compaction_real"), "compaction.force_truncate")
    assert result["status"] == "passed"
    assert result["evidence"]["removed_message_count"] > 0


@pytest.mark.asyncio
async def test_steering_probe_converts_user_message(tmp_path):
    result = await run_probe(_session(tmp_path, "sb_steering"), "steering.inject_message")
    assert result["status"] == "passed"
    assert result["evidence"]["message_count"] == 1
