"""Tests for TaskDescriptor + TASK_REGISTRY."""
from __future__ import annotations

import pytest

from sandbox.tasks.registry import TASK_REGISTRY, TaskDescriptor, get_task


def test_registry_has_todo_api():
    assert "sb_task_todo_api" in TASK_REGISTRY


def test_get_task_returns_descriptor():
    task = get_task("sb_task_todo_api")
    assert isinstance(task, TaskDescriptor)
    assert task.fixture_name == "todo_api"
    assert "FastAPI" in task.system_prompt or "todo" in task.system_prompt.lower()
    assert callable(task.acceptance_check)


def test_get_task_unknown_raises():
    with pytest.raises(KeyError):
        get_task("nope")


def test_descriptor_has_starter_overrides():
    task = get_task("sb_task_todo_api")
    assert isinstance(task.starter_overrides, dict)
