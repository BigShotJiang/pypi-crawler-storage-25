"""Scenario-level smoke tests."""
from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from tada_core.contracts.events import HookEvent, PermissionEvent, ToolResultEvent, ToolUseRequest
from sandbox.scenarios import SANDBOX_SCENARIO_CATALOG, build_session_for_scenario


@pytest.fixture
def root(tmp_path) -> Path:
    return tmp_path / "sb"


@pytest.mark.parametrize("scenario_id", [s.id for s in SANDBOX_SCENARIO_CATALOG])
def test_scenario_can_be_constructed(scenario_id, root):
    session = build_session_for_scenario(
        scenario_id=scenario_id,
        session_id=f"{scenario_id}_s",
        registry_root=root,
        task_id=None,
    )
    assert session.scenario_id == scenario_id
    assert session.workspace.repo_root.exists()


def test_catalog_has_five_a_class_scenarios():
    ids = {s.id for s in SANDBOX_SCENARIO_CATALOG}
    assert {
        "sb_path_jail",
        "sb_shell_deny",
        "sb_audit_trace",
        "sb_compaction_real",
        "sb_steering",
    }.issubset(ids)


def test_steering_scenario_has_hook(root):
    session = build_session_for_scenario(
        scenario_id="sb_steering",
        session_id="steer_s",
        registry_root=root,
        task_id=None,
    )
    assert session.steering is not None


def test_audit_log_grows_after_a_turn(root):
    session = build_session_for_scenario(
        scenario_id="sb_audit_trace",
        session_id="audit_s",
        registry_root=root,
        task_id=None,
    )

    async def go():
        async for _ in session.loop.run_turn(session.state, "list the repo"):
            pass

    asyncio.run(go())
    audit = session.workspace.audit_path.read_text()
    assert audit.strip() != ""


@pytest.mark.asyncio
async def test_path_jail_run_turn_invokes_blocked_read_tool(root):
    session = build_session_for_scenario(
        scenario_id="sb_path_jail",
        session_id="path_run_s",
        registry_root=root,
        task_id=None,
    )

    events = [event async for event in session.loop.run_turn(session.state, "run path jail")]

    assert any(isinstance(event, ToolUseRequest) and event.tool_name == "read_file" for event in events)
    assert any(isinstance(event, PermissionEvent) and event.allowed is False for event in events)
    assert any(isinstance(event, ToolResultEvent) and event.is_error for event in events)


@pytest.mark.asyncio
async def test_shell_deny_run_turn_invokes_guarded_shell_tools(root):
    session = build_session_for_scenario(
        scenario_id="sb_shell_deny",
        session_id="shell_run_s",
        registry_root=root,
        task_id=None,
    )

    events = [event async for event in session.loop.run_turn(session.state, "run shell deny")]
    results = [event for event in events if isinstance(event, ToolResultEvent)]
    combined_output = "\n".join(event.output for event in results)
    hook_messages = "\n".join(
        message
        for event in events
        if isinstance(event, HookEvent)
        for message in event.messages
    )

    assert sum(1 for event in events if isinstance(event, ToolUseRequest)) == 3
    assert "hard_ban" in combined_output
    assert "network_ban" in combined_output
    assert "rewrite" in hook_messages
