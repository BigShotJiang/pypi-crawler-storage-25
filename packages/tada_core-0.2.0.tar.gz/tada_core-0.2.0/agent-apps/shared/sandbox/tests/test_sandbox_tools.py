"""Tests for sandbox file tools."""
from __future__ import annotations

import asyncio
import json

import pytest

from sandbox.tools import build_file_tool_executor
from sandbox.workspace import SandboxWorkspace


def _run(coro):
    return asyncio.run(coro)


@pytest.fixture
def workspace(tmp_path) -> SandboxWorkspace:
    fix = tmp_path / "_fixture"
    fix.mkdir()
    (fix / "README.md").write_text("# hello\n")
    (fix / "src").mkdir()
    (fix / "src" / "app.py").write_text("print('hi')\n")
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fix, session_id="s1")
    ws.create()
    return ws


def test_executor_lists_file_tools(workspace):
    ex = build_file_tool_executor(workspace)
    names = {t.name for t in ex.list_tools()}
    assert names == {"read_file", "write_file", "list_dir"}


def test_read_file(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(ex.execute("read_file", json.dumps({"path": "README.md"})))
    assert json.loads(out) == {"content": "# hello\n"}


def test_read_file_missing_returns_error(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(ex.execute("read_file", json.dumps({"path": "missing.txt"})))
    assert "error" in json.loads(out)


def test_write_file_creates_parent_dirs(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(
        ex.execute(
            "write_file",
            json.dumps({"path": "new/deep/file.txt", "content": "ok"}),
        )
    )
    assert json.loads(out)["written"] == "new/deep/file.txt"
    assert (workspace.repo_root / "new" / "deep" / "file.txt").read_text() == "ok"


def test_list_dir(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(ex.execute("list_dir", json.dumps({"path": "."})))
    data = json.loads(out)
    names = {e["name"] for e in data["entries"]}
    assert {"README.md", "src"}.issubset(names)
    assert any(e["name"] == "src" and e["kind"] == "dir" for e in data["entries"])


def test_list_dir_non_dir_errors(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(ex.execute("list_dir", json.dumps({"path": "README.md"})))
    assert "error" in json.loads(out)


def test_tools_reject_path_escape(workspace):
    ex = build_file_tool_executor(workspace)
    out = _run(ex.execute("read_file", json.dumps({"path": "/etc/passwd"})))
    assert "error" in json.loads(out)


def test_run_shell_executes_in_repo_root(workspace):
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_shell_tools

    register_shell_tools(ex, workspace)
    out = _run(ex.execute("run_shell", json.dumps({"cmd": "pwd", "timeout": 5})))
    data = json.loads(out)
    assert str(workspace.repo_root.resolve()) in data["stdout"]
    assert data["returncode"] == 0


def test_run_shell_captures_stderr_and_returncode(workspace):
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_shell_tools

    register_shell_tools(ex, workspace)
    out = _run(ex.execute("run_shell", json.dumps({"cmd": "ls /nonexistent_xyz", "timeout": 5})))
    data = json.loads(out)
    assert data["returncode"] != 0
    assert data["stderr"]


def test_run_shell_timeout(workspace):
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_shell_tools

    register_shell_tools(ex, workspace)
    out = _run(ex.execute("run_shell", json.dumps({"cmd": "sleep 5", "timeout": 1})))
    data = json.loads(out)
    assert data.get("timed_out") is True


def test_run_shell_isolates_env(workspace, monkeypatch):
    monkeypatch.setenv("LEAKED_SECRET", "should_not_appear")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_shell_tools

    register_shell_tools(ex, workspace)
    out = _run(ex.execute("run_shell", json.dumps({"cmd": "env", "timeout": 5})))
    data = json.loads(out)
    assert "LEAKED_SECRET" not in data["stdout"]


def test_run_pytest_invokes_pytest(workspace):
    (workspace.repo_root / "test_sample.py").write_text("def test_x():\n    assert 1 == 1\n")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_shell_tools

    register_shell_tools(ex, workspace)
    out = _run(ex.execute("run_pytest", json.dumps({"target": "."})))
    data = json.loads(out)
    assert data["returncode"] == 0
    assert "passed" in data["stdout"]


def test_grep_finds_pattern(workspace):
    (workspace.repo_root / "x.py").write_text("import requests\nrequests.get(URL)\n")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_search_tools

    register_search_tools(ex, workspace)
    out = _run(ex.execute("grep", json.dumps({"pattern": r"requests\.get", "path": "."})))
    data = json.loads(out)
    assert any(m["path"].endswith("x.py") for m in data["matches"])
    assert any(m["line"] == 2 for m in data["matches"])


def test_grep_handles_no_match(workspace):
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_search_tools

    register_search_tools(ex, workspace)
    out = _run(ex.execute("grep", json.dumps({"pattern": "nonexistent_xyz", "path": "."})))
    data = json.loads(out)
    assert data["matches"] == []


def test_apply_patch_replaces_content(workspace):
    (workspace.repo_root / "p.py").write_text("a=1\nb=2\nc=3\n")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_search_tools

    register_search_tools(ex, workspace)
    out = _run(
        ex.execute(
            "apply_patch",
            json.dumps({"path": "p.py", "old": "b=2", "new": "b=22"}),
        )
    )
    data = json.loads(out)
    assert data["replaced"] == 1
    assert (workspace.repo_root / "p.py").read_text() == "a=1\nb=22\nc=3\n"


def test_apply_patch_errors_when_old_missing(workspace):
    (workspace.repo_root / "p.py").write_text("hello\n")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_search_tools

    register_search_tools(ex, workspace)
    out = _run(
        ex.execute(
            "apply_patch",
            json.dumps({"path": "p.py", "old": "nope", "new": "x"}),
        )
    )
    data = json.loads(out)
    assert "error" in data and "old" in data["error"]


def test_apply_patch_errors_when_old_ambiguous(workspace):
    (workspace.repo_root / "p.py").write_text("dup\ndup\n")
    ex = build_file_tool_executor(workspace)
    from sandbox.tools import register_search_tools

    register_search_tools(ex, workspace)
    out = _run(
        ex.execute(
            "apply_patch",
            json.dumps({"path": "p.py", "old": "dup", "new": "uniq"}),
        )
    )
    data = json.loads(out)
    assert "error" in data and "ambiguous" in data["error"].lower()
