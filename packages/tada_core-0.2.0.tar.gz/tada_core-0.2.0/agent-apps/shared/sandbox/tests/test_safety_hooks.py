"""Tests for TestIntegrityHook and LoopExitOnRepeatedDenyHook."""
from __future__ import annotations

import asyncio
import json

from sandbox.hooks import LoopExitOnRepeatedDenyHook, TestIntegrityHook


def _run(coro):
    return asyncio.run(coro)


def test_test_integrity_blocks_test_modification():
    hook = TestIntegrityHook(test_globs=["test_*.py", "tests/**/*.py"])
    res = _run(
        hook.pre_tool_use(
            "write_file",
            json.dumps(
                {"path": "tests/test_api.py", "content": "def test_x(): assert True"}
            ),
        )
    )
    assert res.denied is True
    assert "test" in res.messages[0].lower()


def test_test_integrity_blocks_apply_patch_on_test():
    hook = TestIntegrityHook(test_globs=["test_*.py"])
    res = _run(
        hook.pre_tool_use(
            "apply_patch",
            json.dumps({"path": "test_user.py", "old": "a", "new": "b"}),
        )
    )
    assert res.denied is True


def test_test_integrity_allows_non_test_writes():
    hook = TestIntegrityHook(test_globs=["tests/**/*.py"])
    res = _run(
        hook.pre_tool_use("write_file", json.dumps({"path": "src/api.py", "content": "x=1"}))
    )
    assert res.denied is False


def test_test_integrity_passthrough_for_unrelated_tools():
    hook = TestIntegrityHook(test_globs=["tests/**/*.py"])
    res = _run(hook.pre_tool_use("read_file", json.dumps({"path": "tests/test_x.py"})))
    assert res.denied is False


def test_loop_exit_after_threshold():
    hook = LoopExitOnRepeatedDenyHook(threshold=3)
    res1 = _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "rm -rf /"})))
    res2 = _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "curl https://x"})))
    assert res1.exit_loop is False and res2.exit_loop is False
    res3 = _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "sudo id"})))
    assert res3.denied is True
    assert res3.exit_loop is True
    assert "3 consecutive" in res3.messages[0]


def test_loop_exit_resets_after_allow():
    hook = LoopExitOnRepeatedDenyHook(threshold=2)
    _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "rm -rf /"})))
    _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "ls -la"})))
    res = _run(hook.pre_tool_use("run_shell", json.dumps({"cmd": "sudo id"})))
    assert res.exit_loop is False
