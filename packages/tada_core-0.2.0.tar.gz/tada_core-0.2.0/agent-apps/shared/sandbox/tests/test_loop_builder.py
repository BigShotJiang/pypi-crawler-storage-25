"""Tests for sandbox loop_builder."""
from __future__ import annotations

import pytest

from sandbox.loop_builder import build_baseline_sandbox_loop
from sandbox.workspace import SandboxWorkspace


@pytest.fixture
def workspace(tmp_path) -> SandboxWorkspace:
    fix = tmp_path / "fixture"
    fix.mkdir()
    (fix / "a.py").write_text("x=1\n")
    ws = SandboxWorkspace(root=tmp_path / "sb", fixture_dir=fix, session_id="s1")
    ws.create()
    return ws


def test_baseline_loop_has_seven_tools(workspace):
    _loop, ex = build_baseline_sandbox_loop(workspace, scenario_id="sb_test")
    names = {t.name for t in ex.list_tools()}
    assert names == {
        "read_file",
        "write_file",
        "list_dir",
        "grep",
        "apply_patch",
        "run_shell",
        "run_pytest",
    }


def test_baseline_loop_uses_path_jail_policy(workspace):
    from sandbox.policies import PathJailPolicy

    loop, _ = build_baseline_sandbox_loop(workspace, scenario_id="sb_test")
    assert isinstance(loop._permission, PathJailPolicy)  # type: ignore[attr-defined]


def test_baseline_loop_uses_composite_hooks(workspace):
    from tada_core.contracts.hooks import CompositeHookRunner

    loop, _ = build_baseline_sandbox_loop(workspace, scenario_id="sb_test")
    runner = loop._hooks  # type: ignore[attr-defined]
    assert isinstance(runner, CompositeHookRunner)
    assert len(runner._runners) == 2  # type: ignore[attr-defined]
