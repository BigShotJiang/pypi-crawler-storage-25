"""Tests for ShellDenyHook."""
from __future__ import annotations

import asyncio
import json

from sandbox.hooks import ShellDecision, ShellDenyHook


def _input(cmd: str) -> str:
    return json.dumps({"cmd": cmd, "timeout": 30})


def _run(coro):
    return asyncio.run(coro)


def test_allows_safe_ls():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input("ls -la")))
    assert res.denied is False
    assert res.updated_input is None


def test_hard_ban_rm_rf_root():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input("rm -rf /")))
    assert res.denied is True
    assert "rm -rf" in (res.messages[0] if res.messages else "")


def test_hard_ban_fork_bomb():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input(":(){ :|:& };:")))
    assert res.denied is True


def test_network_ban_curl():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input("curl https://example.com")))
    assert res.denied is True


def test_network_ban_pip_install():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input("pip install requests")))
    assert res.denied is True


def test_rewrite_rm_adds_interactive():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("run_shell", _input("rm tmp.log")))
    assert res.denied is False
    assert res.updated_input is not None
    rewritten = json.loads(res.updated_input)
    assert rewritten["cmd"] == "rm -i tmp.log"


def test_passthrough_for_non_shell_tool():
    hook = ShellDenyHook()
    res = _run(hook.pre_tool_use("read_file", json.dumps({"path": "a.py"})))
    assert res.denied is False
    assert res.updated_input is None


def test_decide_returns_structured_decision():
    hook = ShellDenyHook()
    d = hook.decide("rm -rf /")
    assert isinstance(d, ShellDecision)
    assert d.kind == "hard_ban"


def test_network_override_disables_network_ban():
    hook = ShellDenyHook(network_ban=False)
    res = _run(hook.pre_tool_use("run_shell", _input("pip install fastapi")))
    assert res.denied is False
