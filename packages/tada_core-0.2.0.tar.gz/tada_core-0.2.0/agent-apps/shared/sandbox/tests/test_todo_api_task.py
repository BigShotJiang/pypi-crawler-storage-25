"""Smoke tests for sb_task_todo_api."""
from __future__ import annotations

from sandbox.scenarios import build_session_for_scenario
from sandbox.tasks.registry import get_task


def test_todo_api_session_builds(tmp_path):
    session = build_session_for_scenario(
        scenario_id="sb_task_todo_api",
        session_id="t1",
        registry_root=tmp_path / "sb",
    )
    assert (session.workspace.repo_root / "tests" / "test_api.py").exists()
    assert (session.workspace.repo_root / "app.py").exists()
    assert session.extras["task_id"] == "sb_task_todo_api"


def test_acceptance_fails_on_empty_starter(tmp_path):
    session = build_session_for_scenario(
        scenario_id="sb_task_todo_api",
        session_id="t2",
        registry_root=tmp_path / "sb",
    )
    task = get_task("sb_task_todo_api")
    result = task.acceptance_check(session.workspace)
    assert result.ok is False
    assert result.pytest_returncode != 0
