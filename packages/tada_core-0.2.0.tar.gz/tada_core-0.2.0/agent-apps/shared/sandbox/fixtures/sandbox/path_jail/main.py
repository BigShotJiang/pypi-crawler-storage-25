from util import add


def main() -> str:
    return f"hello from sandbox: {add(1, 2)}"

