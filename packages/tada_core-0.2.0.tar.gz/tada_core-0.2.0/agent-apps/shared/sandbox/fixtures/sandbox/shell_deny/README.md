# shell_deny demo

The agent is asked to run several shell commands. ShellDenyHook intercepts
dangerous commands before the tool runs.

