# path_jail demo

This tiny repo demonstrates PathJailPolicy. Real files:

- `README.md`
- `main.py`
- `util.py`

