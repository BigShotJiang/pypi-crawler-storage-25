# Todo API task

Implement `app.py` so that `pytest -x .` passes. See `tests/test_api.py` for
the expected behavior.

