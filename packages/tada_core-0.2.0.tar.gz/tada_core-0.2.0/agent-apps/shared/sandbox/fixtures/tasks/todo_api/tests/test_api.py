def test_create_and_list(client):
    r = client.post("/todos", json={"title": "buy milk"})
    assert r.status_code == 201
    todo_id = r.json()["id"]

    r = client.get("/todos")
    assert r.status_code == 200
    items = r.json()
    assert any(item["id"] == todo_id and item["done"] is False for item in items)


def test_mark_done(client):
    todo_id = client.post("/todos", json={"title": "x"}).json()["id"]
    r = client.patch(f"/todos/{todo_id}", json={"done": True})
    assert r.status_code == 200
    assert r.json()["done"] is True


def test_delete_then_404(client):
    todo_id = client.post("/todos", json={"title": "y"}).json()["id"]
    assert client.delete(f"/todos/{todo_id}").status_code == 204
    assert client.get(f"/todos/{todo_id}").status_code == 404


def test_validation_empty_title(client):
    r = client.post("/todos", json={"title": ""})
    assert r.status_code in (400, 422)

