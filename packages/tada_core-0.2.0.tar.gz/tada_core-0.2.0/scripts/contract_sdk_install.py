"""Build the package, install it into a fresh venv, and verify the SDK surface."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _run(cmd: list[str], *, cwd: Path = ROOT, env: dict[str, str] | None = None) -> None:
    subprocess.run(cmd, cwd=cwd, env=env, check=True)


def _assert_wheel_contents(wheel: Path) -> None:
    names = zipfile.ZipFile(wheel).namelist()
    unexpected = [name for name in names if name.startswith("sandbox/")]
    if unexpected:
        sample = ", ".join(unexpected[:5])
        raise AssertionError(f"wheel must not include sandbox package files: {sample}")


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="tada-core-sdk-contract-") as tmp:
        tmp_path = Path(tmp)
        venv = tmp_path / ".venv"
        _run(["uv", "build", "--wheel", "--out-dir", str(tmp_path)])
        wheel = next(tmp_path.glob("tada_core-*.whl"))
        _assert_wheel_contents(wheel)
        _run(["uv", "venv", str(venv)])

        python = venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
        env = {**os.environ, "PYTHONPATH": ""}
        _run(["uv", "pip", "install", "--python", str(python), str(wheel)], env=env)

        script = tmp_path / "verify.py"
        script.write_text(
            """
import asyncio
import importlib.util

from tada_core import (
    AgentLoop,
    AnthropicModelClient,
    CompactionStrategy,
    ContentBlock,
    ConversationMessage,
    Event,
    MessageRole,
    ModelSummaryCompaction,
    NeverCompact,
    SessionState,
    TruncateCompaction,
    __version__,
)
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

_ = (
    AnthropicModelClient,
    CompactionStrategy,
    ContentBlock,
    ConversationMessage,
    Event,
    MessageRole,
    ModelSummaryCompaction,
    NeverCompact,
    TruncateCompaction,
    __version__,
)

async def main():
    assert importlib.util.find_spec("sandbox") is None
    loop = AgentLoop(OpenAICompatibleModelClient(make_echo_transport(), streaming=True))
    state = SessionState()
    seen = []
    async for event in loop.run_turn(state, "hello"):
        seen.append(event.type)
    assert "text_delta" in seen
    assert "message_stop" in seen

asyncio.run(main())
""",
            encoding="utf-8",
        )
        _run([str(python), str(script)], env=env)


if __name__ == "__main__":
    main()
