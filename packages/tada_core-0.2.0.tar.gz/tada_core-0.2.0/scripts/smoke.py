r"""Real-LLM smoke test for AgentLoop.

Environment variables
---------------------
API_KEY     required for real LLM; omit to use echo mode
MODEL_ID    model identifier (default: claude-sonnet-4-6)
BASE_URL    API base URL; defaults to https://api.anthropic.com
            set this for third-party providers (OpenRouter, token-router, etc.)
PROTOCOL    "anthropic" (default) | "openai"
            use "openai" for OpenAI chat/completions format endpoints

Usage examples
--------------
# echo mode — no API key, tests the loop itself
uv run python scripts/smoke.py

# Anthropic direct or any Anthropic-compatible proxy (OpenRouter, token-router, etc.)
API_KEY=<key> \
BASE_URL=https://your-proxy-host \
MODEL_ID=claude-sonnet-4-6 \
uv run python scripts/smoke.py

# OpenAI chat/completions format endpoint
PROTOCOL=openai \
API_KEY=sk-... \
BASE_URL=https://api.openai.com \
MODEL_ID=gpt-4o-mini \
uv run python scripts/smoke.py

# multi-turn: each --text is one turn, all share the same SessionState
# turn 2 sees turn 1's response in its context
API_KEY=<key> MODEL_ID=claude-haiku-4-5-20251001 \
uv run python scripts/smoke.py --text "what is 2+2" --text "multiply that by 3"
"""

from __future__ import annotations

import argparse
import asyncio
import os

from tada_core import AgentLoop, AnthropicModelClient, SessionState
from tada_core.contracts.model import ModelClient
from tada_core.contracts.tools import InMemoryToolExecutor, ToolDefinition
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport


def _build_model() -> ModelClient:
    api_key = os.environ.get("API_KEY", "")
    base_url = os.environ.get("BASE_URL", "")
    model_id = os.environ.get("MODEL_ID", "")
    protocol = os.environ.get("PROTOCOL", "anthropic").lower()

    if api_key and protocol == "openai":
        print(f"[smoke] openai-compatible: {model_id or '(unset)'} @ {base_url or 'https://api.openai.com'}")
        import json as _json
        from typing import Any
        from urllib.request import Request, urlopen
        from tada_core.contracts.messages import MessageRole

        def _transport(request: Any, stream: bool) -> Any:
            msgs = []
            for p in request.system_prompt:
                msgs.append({"role": "system", "content": p})
            for m in request.messages:
                if m.role == MessageRole.TOOL:
                    b = m.content[0] if m.content else None
                    if b:
                        msgs.append({"role": "tool", "tool_call_id": b.tool_use_id or "", "content": b.tool_result or ""})
                    continue
                texts, calls = [], []
                for b in m.content:
                    if b.type == "text" and b.text:
                        texts.append(b.text)
                    if b.type == "tool_use":
                        calls.append({"id": b.tool_use_id or "", "type": "function",
                                      "function": {"name": b.tool_name or "", "arguments": b.tool_input or "{}"}})
                entry: dict = {"role": m.role.value, "content": "".join(texts)}
                if calls:
                    entry["tool_calls"] = calls
                msgs.append(entry)
            payload: dict[str, Any] = {"model": model_id, "messages": msgs, "stream": stream}
            if request.tools:
                payload["tools"] = request.tools
            ep = (base_url or "https://api.openai.com").rstrip("/")
            req = Request(
                f"{ep}/v1/chat/completions",
                data=_json.dumps(payload).encode(),
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                method="POST",
            )
            with urlopen(req) as resp:
                ct = resp.headers.get("Content-Type", "")
                if "event-stream" in ct:
                    chunks = []
                    for part in resp.read().decode().split("\n\n"):
                        for line in part.splitlines():
                            if line.startswith("data: "):
                                body = line[6:].strip()
                                if body and body != "[DONE]":
                                    chunks.append(_json.loads(body))
                    return chunks
                return _json.loads(resp.read().decode())

        return OpenAICompatibleModelClient(_transport, streaming=True)

    if api_key:
        print(f"[smoke] anthropic: {model_id or 'claude-sonnet-4-6'} @ {base_url or 'https://api.anthropic.com'}")
        return AnthropicModelClient(
            api_key=api_key,
            model=model_id or "claude-sonnet-4-6",
            base_url=base_url,
            streaming=True,
        )

    print("[smoke] no API_KEY set — using echo mode")
    return OpenAICompatibleModelClient(make_echo_transport(), streaming=True)


def _build_loop() -> AgentLoop:
    loop = AgentLoop(
        _build_model(),
        system_prompt=["You are a concise assistant. Keep replies under 3 sentences."],
        max_iterations=8,
    )
    ex = InMemoryToolExecutor()
    ex.register(
        ToolDefinition(name="echo", description="Return input unchanged.", parameters_schema={"type": "object"}),
        lambda inp: inp,
    )
    loop.set_tool_executor(ex)
    return loop


async def run_turn(loop: AgentLoop, state: SessionState, text: str) -> None:
    print(f"\n{'─'*60}")
    print(f"USER: {text}")
    print(f"{'─'*60}")
    async for ev in loop.run_turn(state, text):
        t = ev.type
        if t == "text_delta":
            print(ev.text, end="", flush=True)  # type: ignore[attr-defined]
        elif t == "tool_use":
            print(f"\n[tool_use] {ev.tool_name}({ev.input_json})")  # type: ignore[attr-defined]
        elif t == "tool_result":
            print(f"[tool_result] {ev.tool_name} → {ev.output}")  # type: ignore[attr-defined]
        elif t == "permission":
            status = "✓" if ev.allowed else "✗"  # type: ignore[attr-defined]
            print(f"[permission] {ev.tool_name} {status}")  # type: ignore[attr-defined]
        elif t == "compaction":
            print(f"\n[compaction] {ev.strategy} removed {ev.removed_message_count} msgs")  # type: ignore[attr-defined]
        elif t == "usage":
            print(
                f"\n[usage] in={ev.input_tokens} out={ev.output_tokens} "
                f"cache_read={getattr(ev, 'cache_read_tokens', 0)} "
                f"cache_create={getattr(ev, 'cache_creation_tokens', 0)}"
            )  # type: ignore[attr-defined]
        elif t == "error":
            print(f"\n[error:{ev.code}] {ev.message}")  # type: ignore[attr-defined]
        elif t == "message_stop":
            print()


async def main(prompts: list[str]) -> None:
    loop = _build_loop()
    state = SessionState()
    for text in prompts:
        await run_turn(loop, state, text)
    print(f"\n{'─'*60}")
    print(f"session: {len(state.messages)} messages | "
          f"tokens in={state.usage.input_tokens} out={state.usage.output_tokens} "
          f"cache_read={state.usage.cache_read_tokens} "
          f"cache_create={state.usage.cache_creation_tokens}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AgentLoop smoke test")
    parser.add_argument("--text", action="append", default=[], help="prompt(s) to send")
    args = parser.parse_args()
    prompts = args.text or ["hello, what can you do?"]
    asyncio.run(main(prompts))
