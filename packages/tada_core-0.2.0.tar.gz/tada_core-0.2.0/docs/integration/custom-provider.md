# 自定义 ModelClient 指南

如果内置 adapter 不能满足你的需求，可以实现自己的 `ModelClient`，或通过 adapter registry 注册工厂函数。`tada-core` 对自定义模型接入的要求不是“长得像某个 provider”，而是 **把模型原生协议转换成统一的 `AssistantEvent`**。

## 1. 推荐路径：Adapter Registry

优先注册 factory，而不是让宿主直接依赖某个具体 client 类：

```python
from tada_core import ModelSpec, build_model_client
from tada_core.providers.registry import register_model_adapter


def my_client_factory(
    spec: ModelSpec,
    *,
    api_key: str = "",
    streaming: bool = True,
    **kwargs,
):
    return MyModelClient(spec=spec, api_key=api_key, streaming=streaming)


register_model_adapter("my-api", my_client_factory)

spec = ModelSpec(id="my-model", provider="acme", api="my-api")
client = build_model_client(spec, api_key="...")
loop = AgentLoop(client)
```

`ModelSpec` 只描述模型与协议能力，不承载路由、fallback、账号额度、价格表或 OAuth。

## 2. 最小实现目标

一个自定义模型客户端只需要实现：

```python
class ModelClient(ABC):
    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]: ...
```

`AgentLoop` 负责工具执行、权限、hooks、compaction 和 `SessionState` 更新；`ModelClient` 只负责模型请求和模型响应解析。

## 3. 最小骨架

```python
from collections.abc import AsyncIterator

from tada_core.contracts.model import (
    ApiRequest,
    AssistantEvent,
    AssistantEventKind,
    ModelClient,
    StopReason,
)


class MyModelClient(ModelClient):
    def stream(self, request: ApiRequest) -> AsyncIterator[AssistantEvent]:
        async def _gen() -> AsyncIterator[AssistantEvent]:
            yield AssistantEvent(kind=AssistantEventKind.TEXT_START)
            yield AssistantEvent(
                kind=AssistantEventKind.TEXT_DELTA,
                text_delta="hello from my model",
            )
            yield AssistantEvent(kind=AssistantEventKind.TEXT_END, text_delta="hello from my model")
            yield AssistantEvent(
                kind=AssistantEventKind.MESSAGE_STOP,
                stop_reason=StopReason.STOP,
            )

        return _gen()
```

接入方式：

```python
from tada_core import AgentLoop, SessionState

loop = AgentLoop(MyModelClient(), system_prompt=["You are concise."])
state = SessionState()
```

## 4. 需要转换的对象

### 输入：`ApiRequest`

`ApiRequest` 包含：

- `system_prompt`: `list[str]`
- `messages`: `list[ConversationMessage]`
- `tools`: 模型可见的工具 schema
- optional `model_spec`: `ModelSpec` for adapter-specific behavior

自定义客户端需要把这些字段转换成目标模型 API 的 wire format。

### 输出：`AssistantEvent`

当前支持的模型输出事件包括：

- `TEXT_START` / `TEXT_DELTA` / `TEXT_END`
- `THINKING_START` / `THINKING_DELTA` / `THINKING_END`
- `TOOL_INPUT_DELTA`
- `TOOL_USE`
- `USAGE`
- `MESSAGE_STOP` with `stop_reason`

工具请求只需要转换成 `AssistantEventKind.TOOL_USE`（以及可选的 partial input delta）。真正执行工具的是 `AgentLoop`，不是 `ModelClient`。

## 5. 常见错误

### 错误 1：在 ModelClient 里执行工具

不要这样做。工具执行、权限判断、hook 运行都属于 `AgentLoop`。

### 错误 2：返回 provider 私有对象

宿主应用只应看到 `Event`，`AgentLoop` 只应看到 `AssistantEvent`。模型 API 的原始 JSON 不应泄漏到上层。

### 错误 3：直接修改 `SessionState`

`ModelClient` 不应直接写 `state.messages` 或 `state.usage`。它只通过 `AssistantEvent` 报告文本、工具请求和 usage。

### 错误 4：吞掉不认识的工具调用字段

如果模型返回了工具调用，至少要保留：

- `tool_use_id`
- `tool_name`
- `tool_input`

否则 `AgentLoop` 无法把后续 `tool_result` 和原始请求关联起来。

### 错误 5：把路由/计费写进 adapter

adapter 只做协议翻译。fallback、quota、billing、OAuth 属于 `token-router` 或宿主层。

### 错误 6：用 provider 价格表污染 runtime contract

`tada-core` 只内置 `BudgetLimits` 这类 provider-agnostic 控制。价格表、折扣、组织额度和账单归因应由 token-router 或宿主计算。

## 6. 推荐实现顺序

1. 先实现 text-only streaming，发出 `TEXT_*` 和 `MESSAGE_STOP`。
2. 再解析 usage，发出 `USAGE`。
3. 再解析工具调用，发出 `TOOL_USE` / `TOOL_INPUT_DELTA`。
4. 如有 reasoning/thinking，补齐 `THINKING_*`。
5. 最后接入真实 HTTP streaming、错误处理和重试。

## 7. 必跑验证

实现完成后，至少要跑：

```bash
uv run pytest tests/
uv run ruff check tada_core tests scripts
uv run python scripts/smoke.py --text "hello"
```

Offline conformance tests live under `tests/conformance/`. Add serialization/parsing tests for your adapter without calling live APIs.

## 8. 一个判断标准

写自定义 adapter 时，最重要的标准不是“能返回文本”，而是：

> 宿主应用是否可以在不改 `AgentLoop`、tools、permissions、hooks 和 `SessionState` 持久化逻辑的前提下切换到这个模型客户端。
