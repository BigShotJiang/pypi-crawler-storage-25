# 宿主接入指南

这篇文档只回答一个问题：**一个宿主系统怎样以最小成本、最稳妥的方式接入 `tada-core`。**

如果你还没建立整体认知，建议先看 [`../architecture/overview.md`](../architecture/overview.md)。
如果你想先理解 agent loop 的分层、协议边界与上层职责，建议先看 [`../architecture/agent-loop.md`](../architecture/agent-loop.md)。

## 1. 最小接入闭环

一个最小可工作的接入路径可以压缩成 7 步：

1. 创建 `ModelClient`
2. 创建 `AgentLoop`
3. 初始化 `SessionState`
4. `async for` 消费 `run_turn()`
5. 处理 `text_delta` / `message_stop` / `error`
6. 持久化更新后的 `SessionState`
7. 再按需装配 tools、permissions、hooks、compaction

建议先让这条最小链路跑通，再逐步接入 tools、permissions、hooks、compaction。

## 2. 安装

```bash
pip install tada-core
```

如果使用 `uv`：

```bash
uv add tada-core
```

## 3. 创建 ModelClient

```python
from tada_core import AnthropicModelClient

client = AnthropicModelClient(
    api_key="token-router-key",
    model="claude-sonnet-4-6",
    base_url="http://localhost:8787",
)
```

`tada-core` 推荐使用 Anthropic-compatible `/v1/messages` endpoint。多 provider 路由、fallback、quota 和计费应由 `token-router` 或宿主系统负责。

本地只想先跑通 loop 时，也可以用 echo transport：

```python
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

client = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)
```

## 4. 创建 AgentLoop

```python
from tada_core import AgentLoop

loop = AgentLoop(
    client,
    system_prompt=["You are a helpful assistant."],
    max_iterations=16,
)
```

模型协议细节见 [`../reference/providers.md`](../reference/providers.md)。

## 5. 创建和保存 `SessionState`

```python
from tada_core import SessionState

state = SessionState(metadata={"user_id": "u-123", "session_id": "s-1"})
```

接入时请记住：

- `SessionState` 会在 `run_turn()` 中被原地更新
- 每轮结束后都应保存最新状态
- `metadata` 应保持轻量并可 JSON 序列化

持久化示例：

```python
blob = state.model_dump_json()
await db.set("session:s-1", blob)
```

恢复示例：

```python
raw = await db.get("session:s-1")
state = SessionState.model_validate_json(raw) if raw else SessionState()
```

## 6. 运行一轮 turn

```python
async def handle_turn(state: SessionState, user_input: str) -> str:
    output_parts: list[str] = []

    async for event in loop.run_turn(state, user_input):
        match event.type:
            case "text_delta":
                output_parts.append(event.text)
            case "message_stop":
                pass
            case "error":
                raise RuntimeError(f"[{event.code}] {event.message}")

    return "".join(output_parts)
```

### 接入时最先处理的事件

建议先只稳定处理这 4 类：

- `text_delta`
- `message_stop`
- `turn_end`
- `error`

待主链路稳定后，再逐步加上 `tool_use`、`tool_result`、`permission`、`hook`、`compaction`、`loop_exit`、`steering`。

## 7. 按需装配可选能力

### tools

当你需要工具调用时，注入 `ToolExecutor`。

### permissions

当你需要审批或拦截工具调用时，注入 `PermissionPolicy`。

### hooks

当你需要输入改写、安全检查、审计附加逻辑时，注入 `HookRunner`。

### compaction

当你需要控制长会话上下文时，注入 `CompactionStrategy`。

这些具体机制的细节建议转到：

- [`../reference/mechanisms.md`](../reference/mechanisms.md)
- [`../reference/compaction.md`](../reference/compaction.md)

## 8. 多轮会话模式

典型的宿主管理方式如下：

```python
sessions: dict[str, SessionState] = {}

async def chat(session_id: str, user_text: str) -> str:
    if session_id not in sessions:
        sessions[session_id] = SessionState(metadata={"session_id": session_id})

    state = sessions[session_id]
    reply = await handle_turn(state, user_text)
    return reply
```

真实系统里，通常会把 `sessions` 换成数据库或缓存。

## 9. 中止一轮运行

如果你的宿主支持超时取消，可以传入 `abort`：

```python
import asyncio
import threading

abort = threading.Event()

async def run_with_timeout(state, user_text, timeout_seconds=30):
    try:
        async with asyncio.timeout(timeout_seconds):
            async for event in loop.run_turn(state, user_text, abort=abort):
                pass
    except TimeoutError:
        abort.set()
```

当前 `AgentLoop` 在取消时会发出 `ErrorEvent(code="aborted")`。

## 10. 一条最稳妥的接入建议

如果你只想先把事情做对，不想一开始就背很多细节，建议遵循这条顺序：

1. echo transport
2. 跑通事件流
3. 保存 `SessionState`
4. 切到真实 Anthropic-compatible endpoint
5. 加入工具
6. 加入 permissions / hooks
7. 最后考虑 compaction

这条路径最容易定位问题，也最符合 `tada-core` 的分层设计。
