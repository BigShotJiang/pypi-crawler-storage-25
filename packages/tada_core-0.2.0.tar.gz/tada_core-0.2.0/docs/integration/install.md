# Install tada-core as an SDK

Use these options when a host application, such as tada-agent, consumes `tada-core`.

## Local Editable Path

Recommended for short feedback loops while validating integration:

```toml
[project]
dependencies = ["tada-core"]

[tool.uv.sources]
tada-core = { path = "../tada-core", editable = true }
```

Do not use local path dependencies in production configuration.

## Git URL

Use a Git dependency when CI or another repository needs a reproducible version before PyPI publication:

```toml
[project]
dependencies = ["tada-core"]

[tool.uv.sources]
tada-core = { git = "ssh://git@.../tada-core.git", tag = "v0.1.0" }
```

Prefer tags over branches so downstream behavior is reproducible.

## PyPI

After public release:

```toml
[project]
dependencies = ["tada-core>=0.1,<0.2"]
```

## Smoke Check

```bash
uv run python scripts/smoke.py
tada-core-smoke --text "hello"
uv run python scripts/contract_sdk_install.py
```

`scripts/smoke.py` supports real Anthropic-compatible endpoints via:

- `API_KEY`
- `BASE_URL`
- `MODEL_ID`
- `PROTOCOL`
