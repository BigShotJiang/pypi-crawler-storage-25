# 排障指南

这篇文档汇总宿主接入 `tada-core` 时最常见的问题，以及推荐的排查顺序。

## 1. 推荐排查顺序

遇到问题时，优先按下面顺序拆：

1. 是宿主接入问题，还是 `ModelClient` / endpoint 配置问题？
2. 是 `AgentLoop` contract 不满足，还是模型端返回格式不符合预期？
3. 有没有 `ErrorEvent`、完整事件流、最终 `SessionState` 或环境变量提示？

不要一上来就怀疑“模型不对”或“框架有 bug”。

## 2. 常见问题总表

| 现象 | 可能原因 | 建议处理 |
|------|----------|----------|
| `ErrorEvent(code="aborted")` | 外部取消或超时 | 检查 abort / timeout 逻辑 |
| `ErrorEvent(code="model_error")` | `ModelClient.stream()` 抛错或流式解析失败 | 检查 endpoint、API key、返回格式和 `PROTOCOL` |
| `ErrorEvent(code="max_iterations_exceeded")` | agentic loop 超过上限 | 调大 `max_iterations` 或检查工具回路 |
| 有事件输出但 `state.messages` 不符合预期 | 没完整消费 `run_turn()` 或 compaction 改写了状态 | 确保完整 `async for`，并记录 compaction |
| 没有真实模型输出，只回显输入 | 未设置 `API_KEY`，进入 echo 模式 | 设置 `API_KEY` / `MODEL_ID` / `BASE_URL` 后重跑 `scripts/smoke.py` |

## 3. 模型接入相关问题

### 问题：真实 endpoint 调不通

最常见原因：

- `API_KEY` 为空或无效
- `BASE_URL` 没有指向 Anthropic Messages API 的根地址
- `MODEL_ID` 不存在或不被代理支持
- `PROTOCOL=openai` / `anthropic` 与 endpoint 实际协议不匹配

推荐检查：

```bash
uv run python scripts/smoke.py --text "hello"

API_KEY=<key> \
BASE_URL=https://your-proxy-host \
MODEL_ID=claude-sonnet-4-6 \
uv run python scripts/smoke.py --text "hello"
```

如果 echo 模式能跑、真实 endpoint 不能跑，优先看 endpoint 协议和鉴权，而不是 `AgentLoop`。

### 问题：OpenAI-compatible endpoint 不工作

`tada-core` 推荐 Anthropic-compatible `/v1/messages` 路径。OpenAI-compatible 路径主要用于 echo 测试和手动 transport。

如确实要走 OpenAI chat/completions 格式：

```bash
PROTOCOL=openai \
API_KEY=<key> \
BASE_URL=https://api.openai.com \
MODEL_ID=gpt-4o-mini \
uv run python scripts/smoke.py --text "hello"
```

## 4. Hooks / permissions 相关问题

### 问题：hook 没有被调用

优先检查：

1. 是否调用了 `loop.set_hook_runner(...)`
2. 是否完整消费了 `run_turn()` 的异步生成器
3. hook 阶段是否是当前 `AgentLoop` 会调用的阶段

当前会调用 `OnTurnStart`、`PreLlmCall`、`PostLlmCall`、`PreToolUse`、`PostToolUse`、`PostToolUseFailure`、`OnTurnEnd`。`OnSessionStart` 已在接口中定义，但主 `AgentLoop` 尚未调用。

### 问题：权限拒绝后没有执行工具

这是预期行为。权限顺序是：

```text
tool_use -> PreToolUse hook -> permission -> tool_result
```

权限拒绝会产生 `PermissionEvent(allowed=False)` 和错误型 `ToolResultEvent(is_error=True)`。

## 5. AgentLoop 相关问题

### 问题：`ErrorEvent(code="max_iterations_exceeded")`

说明 agentic loop 在上限内没有收敛。常见原因：

- 提示词导致反复请求工具
- 工具返回结果不满足模型预期
- 工具 schema 不清晰

建议先：

1. 降低场景复杂度
2. 用 `echo` 或 `stub_tool` 复现
3. 记录完整 `tool_use -> tool_result` 链

## 6. 事件流问题

### 问题：只看到了部分结果

`run_turn()` 是惰性的异步生成器。如果你没有完整 `async for`，很多后续逻辑不会发生。

错误示例是：

- 只拿第一条事件就返回
- 中途没有消费完整生成器

### 问题：`state.messages` 为空或不完整

优先检查：

1. 是否完整消费了 `run_turn()`
2. 是否在中途异常退出
3. 是否发生了 compaction

## 7. 排查时推荐记录什么

建议至少记录：

- `MODEL_ID`
- `BASE_URL`（脱敏后）
- `PROTOCOL`
- 完整事件流
- 最终 `SessionState`
- 任何 `UnsupportedEvent`
- 任何 `ErrorEvent`

如果少了这些信息，很多问题看起来都像“行为异常”，但其实只是能力差异或配置错误。

## 8. 一个实用原则

排障时优先问这三个问题：

1. 这个 endpoint 实际说的是 Anthropic Messages API 还是 OpenAI chat/completions？
2. 有没有 `ErrorEvent` 明确告诉我失败阶段？
3. 我是否完整消费并保存了 `run_turn()` 的结果？

这三个问题通常能快速把大多数问题缩到正确范围内。
