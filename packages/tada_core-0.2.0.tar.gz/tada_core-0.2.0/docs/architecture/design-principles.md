# 设计原则

这篇文档回答的是：**为什么 `tada-core` 要这样设计，而不是看起来更“方便”的另一种方式。**

## 1. 契约优先，而不是实现优先

`tada-core` 的核心哲学是：**先定义 contracts，再让 provider 适配 contracts。**

这意味着：

- `AgentLoop` 决定宿主如何调用 runtime
- `Event` 决定宿主如何观测运行过程
- `SessionState` 决定状态如何持久化与迁移
- `ModelClient` 决定模型原生协议如何接入 runtime

这样做的好处是，宿主应用写一次接入逻辑，就不需要为每个模型端点都重写一套工具、权限、hook 和状态处理。

## 2. 禁止 silent drop

很多 runtime 最难排查的问题，不是“报错了”，而是“看起来没报错，但某个功能其实根本没生效”。

`tada-core` 对这件事的态度非常明确：

- 不支持某项能力时，不能静默忽略
- 要么在运行时发出 `UnsupportedEvent`
- 要么在同步接口上抛出明确异常

当前 v0.1 还没有 provider capability 矩阵；如果未来增加这层，它必须是可测试的 contract，而不是文档提示。

## 3. 模型协议隔离

模型端点的协议差异应限制在 `ModelClient` 内部：

- Anthropic Messages API 由 `AnthropicModelClient` 处理
- OpenAI chat/completions 可通过 `OpenAICompatibleModelClient` 或自定义 transport 处理
- `AgentLoop` 只接收归一化后的 `AssistantEvent`

这样可以避免把 provider 私有响应格式泄漏给宿主应用。

## 4. 流式优先

`run_turn()` 返回 `AsyncIterator[Event]`，不是一个整包结果。这背后代表两个判断：

1. 流式输出是常见需求，不应该变成附加模式
2. 一轮 agent 交互里不只有最终文本，还有工具、权限、hook、压缩、usage 等中间事件

如果一开始就把这些过程折叠成“一次返回一个结果对象”，很多 runtime 行为会变得不可观测。

## 5. 运行时后装配

为什么 tool executor、permission policy、hook runner、compaction strategy 都是通过 setter 注入？

因为真实系统里，这些对象经常依赖请求级上下文：

- 当前用户是谁
- 当前 workspace 是什么
- 当前租户的权限策略是什么
- 当前会话有没有特殊审计规则

这些信息通常在模型客户端初始化时并不存在，所以“先创建 runtime，再注入上下文能力”更贴近真实接入方式。

## 6. 子代理是 Phase 2 方向

`tada-core` 当前 v0.1 还没有框架级 subagent contract。后续如果实现，应把 subagent 建模成“特殊工具调用”，而不是额外平行的一套 runtime 树。

这样做的直接收益是：

- 复用统一工具调用语义
- 让 delegation 过程进入同一条事件流
- 让宿主不需要为 subagent 单独学一套观测方式

这类设计需要先补 `SubagentSpec`、边界事件和 conformance tests，不能只写在文档里。

## 7. compaction 必须可观测

上下文压缩不是 provider 私有优化细节，而是会直接影响宿主可见行为的 runtime 机制：

- 它会改变 `SessionState`
- 它会影响模型可见上下文
- 它会影响调试、回放和会话理解

因此 `tada-core` 选择用 `CompactionStrategy` + `CompactionEvent` 把 compaction 放进 contract 范围，而不是藏在 provider 内部。

## 8. 一致性测试优先于“看起来能跑”

`tests/conformance/` 的价值不只是回归测试，而是防止 contract 退化。

如果没有 conformance tests，所有漂亮的设计都会慢慢变成：

- 每个 model client 或 host adapter 各做各的
- 文档和实际行为不一致
- 宿主接入只能靠经验和猜测

因此新增模型客户端或 runtime 能力的标准不应该是“跑起来了”，而应该是“在统一 contract 下可替换”。

## 9. 最终想换来的是什么

这套设计并不是为了追求抽象本身，而是为了换来几个非常现实的结果：

- 宿主应用只接一次 runtime
- 模型端点可以逐步增加，但不拖垮上层接入
- 运行过程可观测、可审计、可回放
- 能力差异显式暴露，不靠隐式约定
- 新模型客户端和新 runtime 能力有清晰的验证门槛

如果把这些都压缩成一句话，就是：

> `tada-core` 用稳定 contracts 约束模型和宿主差异，用显式事件保证运行过程可见。
