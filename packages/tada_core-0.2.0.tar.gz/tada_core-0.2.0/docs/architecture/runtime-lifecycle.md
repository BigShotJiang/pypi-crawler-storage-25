# `run_turn()` 生命周期

这篇文档专门回答一个问题：**一次 `run_turn()` 到底发生了什么？**

不同模型端点的原生协议不一样，但 `tada-core` 希望宿主应用看到一条统一的 `AgentLoop` 生命周期。

## 1. 抽象生命周期

从宿主视角看，一轮 turn 的形状大致如下：

```mermaid
flowchart TD
    userInput["宿主传入 user_text + SessionState"] --> appendUser["写入 USER message"]
    appendUser --> preCompact["可选 pre_turn compaction"]
    preCompact --> agentLoop["AgentLoop 推理循环"]
    agentLoop --> emitEvents["持续产出 Event"]
    emitEvents --> toolPath["如需工具：hook -> permission -> tool_result"]
    emitEvents --> finishMsg["assistant message_stop / error"]
    toolPath --> postCompact["可选 post_turn compaction"]
    finishMsg --> postCompact
    postCompact --> updatedState["更新后的 SessionState 返回给宿主"]
```

宿主应用真正需要关心的，不是 provider 内部调用了多少层函数，而是：

- 事件按什么顺序出现
- `SessionState` 在什么时候被更新
- 哪些阶段可能产生 `ErrorEvent`

## 2. `AgentLoop` 的 turn 流程

当前核心过程可以概括为：

1. 运行 `OnTurnStart` hook
2. 发出 `TurnStartEvent`
3. 将用户输入追加到 `state.messages`
4. 在模型调用前执行 `pre_turn` compaction 检查
5. 运行 `PreLlmCall` hook，允许替换 message 列表
6. 构造 `ApiRequest`
7. 调用 `ModelClient.stream()`，持续产生：
   - `TextDelta`
   - `ToolUseRequest`
   - `UsageEvent`
   - `MessageStop`
8. 运行 `PostLlmCall` hook
9. 如果存在待执行工具：
   - 运行 pre-hook
   - 计算 `PermissionEvent`
   - 执行工具
   - 运行 post-hook 或 failure hook
   - 发出 `ToolResultEvent`
   - 如 hook 设置 `exit_loop`，发出 `LoopExitEvent`
   - 如 hook 注入 `steering_messages`，发出 `SteeringEvent` 并重新进入模型调用
10. 如有需要，在 turn 结束后执行 `post_turn` compaction
11. 运行 `OnTurnEnd` hook
12. 发出 `TurnEndEvent`

在源码中，这套流程主要由 `tada_core/loop/runner.py` 实现。

## 3. 事件顺序保证

宿主最重要的依赖点之一是事件顺序。当前 contract 保证：

1. `tool_use` 先于对应的 `permission`
2. `permission` 先于对应的 `tool_result`
3. `tool_progress` 先于对应的最终 `tool_result`
4. `loop_exit` / `steering` 发生在触发它们的工具结果之后

这意味着宿主可以稳定实现：

- 工具调用审计
- 用户确认界面
- 流式调试和回放

## 4. `SessionState` 在什么时候变化

`SessionState` 不是在最后一次性“赋值”完成，而是在 turn 过程中不断变化。

### 一般会发生的状态变化

- 用户输入会被追加为一条 `USER` message
- 模型输出会被追加为 `ASSISTANT` message
- 工具执行结果会被追加为 `TOOL` message
- usage 计数会累加到 `state.usage`
- provider 可能会往 `state.metadata` 里写入自己的扩展信息

### compaction 也会修改状态

如果 compaction 生效，`state.messages` 可能在 `pre_turn` 或 `post_turn` 被直接裁剪或替换。因此宿主不能把“消息数组长度不变”当作假设。

## 5. ModelClient 与生命周期边界

`ModelClient` 只负责把模型端输出转换成 `AssistantEvent`。它不执行工具、不做权限判断，也不直接修改 `SessionState`。

这条边界让宿主可以替换模型端点，同时保持工具、hook、permission、compaction 的 runtime 语义不变。

## 6. 中止与错误路径

宿主可以通过 `abort` 信号中止运行中的 turn。当前内置 runtime 会在不同阶段报告：

- `ErrorEvent(code=\"aborted\")`
- `ErrorEvent(code=\"model_error\")`
- `ErrorEvent(code=\"max_iterations_exceeded\")`

对宿主来说，一个稳妥做法是：

- 把 `error` 也当成标准事件处理
- 不要只依赖 Python 异常来感知失败

## 7. 为什么这层文档重要

如果没有对生命周期的明确理解，宿主接入时很容易出现这些误判：

- 以为 `SessionState` 只在最后更新
- 以为 `tool_result` 之前不可能出现 hook 或 permission 相关信息
- 以为 compaction 是 provider 私有细节，宿主不需要感知
- 以为 `ModelClient` 会负责工具执行或权限判断

所以，这篇文档的目标不是描述每一行实现，而是帮助你建立一条稳定的 runtime 心智模型。
