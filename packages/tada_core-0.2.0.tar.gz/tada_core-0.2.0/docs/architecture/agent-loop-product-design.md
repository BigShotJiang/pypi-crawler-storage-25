# 三种 Agent Loop 对 Agent 产品设计的影响

这篇文档讨论 `claw-code`、`hermes-agent`、`tada-agent` 三种 agent loop 对 agent 产品设计的影响。

这里不把 checkpoint、hooks 当成孤立功能对比。它们更像是观察 agent loop 的切面：一个产品把“安全恢复、工具治理、扩展能力、用户配置”放在 loop 的哪个位置，决定了它能向宿主应用和最终用户承诺什么。

## 1. 为什么从 agent loop 看产品设计

Agent 产品不是只有“模型调用 + 工具调用”。真正影响产品形态的是 loop 的边界：

- 谁拥有工具执行链
- 谁决定权限和审批
- 谁负责长上下文治理
- 谁负责失败恢复和回滚
- 谁暴露扩展点给用户或插件
- 宿主应用能否把外部 policy 注入到 loop 中

同样叫 hooks 或 checkpoint，在不同 loop 里含义会完全不同。一个是 runtime contract，一个是产品壳能力，一个是内部治理策略。`tada-core` 在建模 provider 能力时，应该看这些机制是否能被宿主稳定依赖，而不是只看底层项目里是否出现了同名概念。

## 2. 三种 loop 类型

| 项目 | Loop 类型 | 产品设计重心 | 对宿主的影响 |
|------|-----------|--------------|--------------|
| `claw-code` | runtime-controlled loop | 把工具、权限、hooks、subagent 组织成可预测的执行链 | 宿主可以依赖 runtime contract，适合作为标准化 provider 参考 |
| `hermes-agent` | product-shell loop | CLI、gateway、session、tools、plugins、checkpoint 都在产品壳内闭环 | 终端用户能力强，但外部宿主较难深入注入内部决策链 |
| `tada-agent` | app-governed loop | 通过应用 runtime 注入 memory、MCP、toolkit、内部 hooks 和治理策略 | 适合做统一产品治理，但当前不是通用 hook/plugin surface |

## 3. `claw-code`：把 loop 做成 runtime contract

`claw-code` 的核心特点是：工具调用链本身就是产品和宿主之间的契约。

它的 hooks 挂在工具生命周期上：

```text
tool_use -> PreToolUse -> permission -> tool execute -> PostToolUse / PostToolUseFailure -> tool_result
```

这对产品设计的影响很直接：

- 产品可以在工具执行前做权限收敛、参数改写和策略注入
- 工具执行结果可以被 post hook 观察或标记失败
- subagent 可以被建模为一种特殊工具，而不是第二套隐藏 loop
- 宿主可以把 hooks、permissions、tool executor 放进同一条可测试链路

因此，`claw-code` 适合作为 `tada-core` 的完整能力参考实现。它告诉我们：如果一个 provider 声称支持 hooks，就应该能让宿主影响工具链，而不只是内部记录日志。

需要注意的是，`claw-code` 虽然暴露了 `fileCheckpointingEnabled` 设置项，但当前未见运行时消费该字段来实现文件快照或 rollback。它不应该被理解为完整产品级 checkpoint 能力。

## 4. `hermes-agent`：把 loop 包进产品壳

`hermes-agent` 的 loop 更像完整 agent 产品，而不只是 runtime library。CLI、gateway、session store、toolsets、plugins、checkpoint、rollback 都在 Hermes 自己的产品边界内协作。

这种设计带来的优势是终端用户体验完整：

- `~/.hermes/config.yaml` 统一承载模型、工具、checkpoint 等配置
- 文件修改前可以通过 shadow git repo 自动 checkpoint
- 用户可以用 `/rollback` 查看、diff、恢复文件状态
- gateway 可以通过 `~/.hermes/hooks/<name>/HOOK.yaml` + `handler.py` 订阅事件
- plugin 可以通过 `ctx.register_hook()` 挂 `pre_tool_call`、`post_tool_call`、`pre_llm_call` 等生命周期点

但对 `tada-core` 这种外部宿主来说，这也意味着 Hermes 更像黑盒产品 loop。宿主能桥接 Hermes 的输入输出和部分事件，但不能天然假设自己的 `HookRunner`、`PermissionPolicy`、`CompactionStrategy` 可以 1:1 注入 Hermes 内部工具执行链。

所以在 provider 能力建模上，`hermes_bridge` 应该谨慎：Hermes 内部有 hooks，不等于 `tada-core` 可以控制 Hermes 的 hooks；Hermes 内部有 checkpoint，也不等于 checkpoint 已经成为 `tada-core` 的公共 runtime contract。

## 5. `tada-agent`：把 loop 作为应用治理面

`tada-agent` 的 loop 更接近应用 runtime：它在创建 agent 时注入 DB、memory、MCP clients、toolkit、skills、用户设置和内部 hooks。

当前 hooks 主要体现为 runtime policy，例如 `MemoryCompactionHook`：

- 注册点在 `TadaAgent._register_hooks()`
- hook type 是 `pre_reasoning`
- 触发时机在 ReAct reasoning 前
- 作用是上下文接近阈值时压缩旧消息，保留系统提示词和最近消息

这类 hook 的产品意义不是“用户可以随意扩展 loop”，而是“产品可以统一治理 loop”。例如上下文压缩、记忆整理、工具结果压缩、内部安全策略，都可以作为 runtime policy 注入。

因此，`tada-agent` 的设计适合做一个受控的个人助理产品：能力来自 tools、skills、MCP 和配置中心，治理逻辑由应用 runtime 统一安排。它当前不像 Hermes 那样给用户提供目录式 hook 插件系统，也不像 `claw-code` 那样把工具生命周期 hook 作为宿主可替换 contract。

同样，当前也未见 Hermes 式文件 checkpoint/rollback。若讨论可恢复状态，更接近 session 或 agent state 的保存与加载，而不是文件系统快照。

## 6. 产品设计上的关键分歧

### 安全恢复

Hermes 把安全恢复做成面向用户的产品能力：修改前自动 checkpoint，失败后 `/rollback`。

`claw-code` 更强调工具执行链的可治理性；它有 checkpoint 兼容设置项，但不应按完整 rollback 产品能力理解。

`tada-agent` 当前重点在会话和记忆状态治理，而不是文件系统级恢复。

### 扩展能力

`claw-code` 的扩展点靠近工具执行链，适合表达强 contract。

Hermes 的扩展点分成 gateway hooks 和 plugin hooks，适合面向最终用户和消息平台自动化。

`tada-agent` 的扩展模型更多由产品 runtime 装配：tools、skills、MCP、内部 hooks 共同组成能力面。

### 宿主可控性

`claw-code` 最适合被 `tada-core` 抽象为可控 runtime。

Hermes 更适合桥接，而不是深度改造。外部宿主应观察它的行为，而不是假设可以完全控制内部 loop。

`tada-agent` 如果要成为完整 provider，需要先明确哪些 runtime policy 要开放成 contract，哪些仍留在产品内部。

## 7. 对 `tada-core` 的建模建议

`tada-core` 的 provider capability 不应按“底层是否有同名功能”判断，而应按“宿主是否能稳定依赖该能力”判断。

具体来说：

- `hooks=True` 应表示宿主可以通过 `HookRunner` 影响工具生命周期
- `compaction=True` 应表示宿主可以理解或控制压缩策略，而不是只能观察内部压缩发生
- checkpoint 暂时不应进入核心 capability，除非定义清楚 checkpoint 事件、rollback 语义和 `SessionState` 关系
- bridge 型 provider 应主动发出 `UnsupportedEvent`，避免让宿主误以为能力已经完整注入

如果未来要把 checkpoint 纳入 `tada-core`，建议先定义这些问题：

- checkpoint 何时创建
- checkpoint 是否绑定某次 `tool_use`
- rollback 是否修改 `SessionState`
- rollback 是否发出独立事件
- provider 不支持时如何报告

## 8. 相关文档

- provider 能力矩阵见 [`../reference/providers.md`](../reference/providers.md)
- tools / permissions / hooks / subagent 的统一链路见 [`../reference/mechanisms.md`](../reference/mechanisms.md)
- compaction 机制见 [`../reference/compaction.md`](../reference/compaction.md)
