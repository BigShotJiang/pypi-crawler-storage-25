# tada-core 架构概览

## 1. 为什么需要 tada-core

Agent runtime 很容易碎片化。不同模型提供方、不同工具执行方式、不同流式协议、不同记忆模型，都会让上层应用一旦绑定某个 runtime，就很难迁移、复用或测试。

`tada-core` 解决的是其中最核心的那一层：**把一轮 agent 交互抽象成稳定的 runtime contracts**，让宿主应用始终只面向统一接口编排，而不是直接依赖某个 provider 的内部实现。

它不是产品壳，不是聊天应用，也不是渠道路由器。它是一层可复用的 runtime SDK。

## 2. 三层模型

`tada-core` 推荐的结构不是“大而全框架”，而是分层清晰的 runtime SDK：

```mermaid
flowchart TD
    hostApp["宿主应用"]
    agentLoop["AgentLoop"]
    modelClient["ModelClient"]
    tools["ToolExecutor"]
    hooks["HookRunner"]
    events["Event Stream"]

    hostApp -->|"SessionState + user_text"| agentLoop
    agentLoop -->|"ApiRequest"| modelClient
    agentLoop -->|"tool calls"| tools
    agentLoop -->|"runtime phases"| hooks
    agentLoop --> events
    events --> hostApp
```

### 宿主应用负责什么

- 请求/响应协议
- HTTP / WebSocket / SSE / CLI 等渠道
- 会话存储与检索
- 工作区与进程生命周期
- 鉴权、UI、交互呈现

### tada-core 负责什么

- 统一 runtime contracts
- 统一 event 语义
- `AgentLoop.run_turn()` 的模型、工具、权限、hook、compaction 循环
- Anthropic-compatible `ModelClient` 适配
- tool / permission / hook / compaction 的装配点

如果你要进一步区分“模型原生协议”和 `tada-core` 公共 contract，请继续看 [`../reference/protocols.md`](../reference/protocols.md)。

### ModelClient 负责什么

- 把具体 endpoint 返回转换成 `AssistantEvent`
- 处理模型原生协议和 `ConversationMessage` 之间的序列化
- 保持 provider 私有细节不泄漏到 `AgentLoop`

一句话理解：**宿主决定怎么接入和怎么消费，`AgentLoop` 负责 runtime 语义，`ModelClient` 负责模型协议。**

## 3. 四个核心契约

### 3.1 `AgentLoop`

宿主应用真正调用的是 `AgentLoop.run_turn()`：

```python
async for event in loop.run_turn(state, user_text, abort=abort):
    ...
```

它定义了一轮交互最核心的输入输出边界：

- 输入：`SessionState` + 用户文本
- 输出：`AsyncIterator[Event]`
- 副作用：原地更新会话状态

### 3.2 `Event`

所有 provider 都向上暴露统一的 `Event` 流。宿主应用不需要理解 provider 内部细节，只需要按 `event.type` 处理统一事件。

这让日志、流式输出、审计、回放和 UI 渲染都可以建立在稳定 contract 上，而不是建立在某个 provider 私有返回结构上。

### 3.3 `SessionState`

`SessionState` 是 provider 无关的会话状态模型：

- `messages`：归一化后的对话记录
- `usage`：统一 usage 计数
- `metadata`：provider 或宿主扩展槽

它既适合多轮持久化，也适合 provider 之间迁移。

### 3.4 `ModelClient`

`ModelClient` 是模型访问边界。当前公共推荐路径是 `AnthropicModelClient`，它直连 Anthropic Messages API 或兼容代理：

```python
client = AnthropicModelClient(
    api_key="...",
    model="claude-sonnet-4-6",
    base_url="http://localhost:8787",
)
loop = AgentLoop(client)
```

provider registry、capability matrix 和多 runtime 工厂是后续方向，不是当前 v0.1 的实现面。

## 4. 两个关键设计选择

### 4.1 流式是默认能力

`run_turn()` 返回的是 `AsyncIterator[Event]`，而不是单次 coroutine。这意味着流式输出是第一公民，不需要额外开一条完全不同的接口。

### 4.2 运行时后装配

tool executor、permission policy、hook runner、compaction strategy 都在 `AgentLoop` 创建后注入，而不是都塞进模型客户端构造函数。

这样做的原因很现实：很多装配点依赖请求级上下文，runtime 初始化时还拿不到这些信息。

## 5. 当前内置实现的定位

当前内置实现的角色分工可以先这样理解：

| 名称 | 定位 | 适合场景 |
|------|------|----------|
| `AgentLoop` | 唯一 runtime loop | 驱动模型、工具、权限、hook、compaction |
| `AnthropicModelClient` | 推荐模型客户端 | Anthropic direct、token-router、LiteLLM Anthropic mode |
| `OpenAICompatibleModelClient` | 测试/echo 辅助客户端 | echo smoke、手写 OpenAI chat/completions transport |

如果你最关心模型客户端，继续看 [`../reference/providers.md`](../reference/providers.md)。

## 6. Phase 2 方向

这些能力曾出现在设计分析文档中，但不属于当前 v0.1 实现：

- `ProviderRegistry`
- `Capabilities`
- `SubagentSpec`
- `SubagentStarted` / `SubagentFinished`
- 框架级 MCP 管理

如果这些能力进入实现，应先补 contract、事件、conformance tests，再把本页从“Phase 2 方向”更新为“当前能力”。

## 7. 什么不属于 tada-core

下面这些职责明确不在 `tada-core` 中：

- 渠道路由
- 会话存储
- 工作区生命周期
- 用户鉴权与授权
- UI 渲染与消息展示
- MCP server 管理与发现流程
- 多 provider 路由、fallback、计费

如果把这些都塞回 core，`tada-core` 就会退化成一个强绑定框架，而不是可复用 runtime SDK。

## 8. 推荐下一步阅读

- 想理解 agent loop 是怎么被分层和设计的：[`agent-loop.md`](agent-loop.md)
- 想看一轮 turn 怎么流动：[`runtime-lifecycle.md`](runtime-lifecycle.md)
- 想看为什么强调 contracts 和一致性测试：[`design-principles.md`](design-principles.md)
- 想查 provider、event、compaction 细节：[`../reference/providers.md`](../reference/providers.md)
