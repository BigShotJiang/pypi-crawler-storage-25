# tada-core 与 Agent Loop：从模型协议到应用编排

> 状态说明：这篇是架构判断版背景文档，包含 provider/capability/subagent 的目标形态。当前 v0.1 代码尚未实现这些 Phase 2 能力；实际实现以 `AgentLoop + ModelClient` 为准。

这篇文档尝试用另一种方式回答同一个问题：

> `tada-core` 在 agent loop 中到底提供了什么，没提供什么；它为什么要这样设计；上层 agent 框架或应用层应该怎样把这些协议真正用起来。

如果说 [`agent-loop.md`](agent-loop.md) 更偏“完整讲解版”，那么这篇 v2 更偏“架构判断版”。它不追求覆盖所有背景，而是试图把最关键的设计判断讲得更锋利一些。

## 1. 先把问题问对

很多团队在做 agent 时，最先接触到的是 OpenAI / Anthropic 的模型 API，于是会自然形成一个认知：

- 模型支持多轮 `messages`
- 模型会输出 `tool_calls` 或 `tool_use`
- 宿主执行工具，再把 `tool_result` 喂回去
- 某些模型还能输出 `thinking`

这个认知并不假，但它只解释了 **LLM 如何表达**，没有解释 **系统如何运行**。

而 `tada-core` 的设计重点，恰恰不在“替模型说话”，而在“给宿主一层稳定的运行时结构”。

一句话说：

> 模型协议解决“模型说了什么”，`tada-core` 解决“宿主如何把这一轮 turn 跑成一个可观测、可持久化、可扩展的系统过程”。

## 2. 一个更准确的分层图

理解 `tada-core` 最好的方法，不是从某个 provider 的代码细节出发，而是先看分层。

```mermaid
flowchart TD
    model["Model Protocol"]
    adapter["Provider / Adapter"]
    runtime["tada-core Runtime Contracts"]
    app["Agent Framework / App Orchestration"]
    ux["Product UX / UI"]

    model --> adapter
    adapter --> runtime
    runtime --> app
    app --> ux
```

这五层分别回答不同问题。

### 模型协议层

回答：

- 模型如何接收上下文
- 模型如何表达工具调用
- 工具结果怎么回填
- 是否存在 reasoning / thinking 等原生能力

典型例子：

- OpenAI 的 `messages`、`tool_calls`、`role="tool"`
- Anthropic 的 `content blocks`、`tool_use`、`tool_result`、`thinking`

### provider / adapter 层

回答：

- 不同模型协议如何映射进统一内部语义
- provider 怎样把底层 payload 归一化
- 哪些底层能力能稳定暴露，哪些只能做兼容桥接

这一层属于实现层，不是宿主的长期契约层。

### `tada-core` runtime contracts 层

回答：

- 宿主如何调用一轮 turn
- 宿主如何观察运行过程
- 宿主如何保存会话状态
- hooks / permissions / compaction / subagent 如何进入统一 loop

这是 `tada-core` 最核心的一层。

### 上层编排层

回答：

- human-in-the-loop 怎么暂停、恢复、审批
- checkpoint 怎么设计
- 长任务怎么拆成多轮 turn
- 什么时候 retry，什么时候 abort
- 是否要引入 DAG / scheduler / workflow engine

这层通常属于 agent framework 或应用后端。

### 产品体验层

回答：

- 用户现在看到什么
- 什么时候展示“等待确认”
- 什么信息进 debug timeline
- 什么信息只做日志、不对用户展示

这层和模型协议通常隔得最远。

## 3. 为什么“只靠模型协议”不够

一个只依赖模型原生协议的最小 agent，通常可以写成这样：

```python
while True:
    response = llm(messages, tools=tools)
    if response.has_tool_call:
        result = run_tool(response.tool_call)
        messages.append(tool_result_message(result))
    else:
        show_to_user(response.text)
        break
```

这个 loop 能工作，但很快会在工程上失真。

### 3.1 它没有统一的运行时观测面

在这种写法里，你通常只能拿到：

- 模型最终文本
- 工具调用请求
- 工具执行结果

但你拿不到稳定的：

- permission 决策点
- hook 参与信息
- compaction 发生时机
- subagent 包裹事件
- unsupported 的显式信号

这会导致上层很难做：

- 审计
- 回放
- 产品调试
- provider 间行为对齐

### 3.2 它没有统一的状态层

如果系统里没有一个稳定的 `SessionState`，你最终往往会落到两种坏结果之一：

1. 把所有状态都塞进 prompt
2. 每个 provider / 应用各存一套私有上下文结构

前者成本高且脆弱，后者不可迁移、不可复用、不可比较。

### 3.3 它无法自然承接 human-in-the-loop

模型可以输出一句“请用户确认”，但模型不会负责：

- 真正暂停运行
- 记录等待哪个动作
- 用户回来后从哪继续
- 拒绝后要不要回退某一步

所以 human-in-the-loop 从来不是“模型多输出一句话”就能解决的，它需要 runtime 和 app 层的显式结构。

## 4. `tada-core` 的核心设计判断

如果把 `tada-core` 的设计提炼成几条判断，我认为是下面这些。

### 4.1 把一轮 turn 抽象成稳定 contracts，而不是 provider 私有调用链

`tada-core` 不要求每个 provider 的内部过程相同，但要求宿主看到的外部 contracts 尽量一致。

核心入口是：

- `ConversationRuntime.run_turn()`

核心运行时输出是：

- `Event`

核心状态对象是：

- `SessionState`

核心 transcript 是：

- `ConversationMessage`
- `ContentBlock`

这意味着宿主接入时，重点不是理解某个 provider 内部调用了多少函数，而是理解：

- 这轮 turn 怎么开始
- 会发出什么事件
- 状态会怎么变化

### 4.2 把事件流当成一等协议，而不是日志副产物

在很多系统里，事件只是“顺手记一下日志”。在 `tada-core` 里，事件不是附属物，而是主协议之一。

这意味着：

- `text_delta` 不只是 UI 流式文本
- `tool_use` / `tool_result` 不只是模型工具调用映射
- `permission`、`hook`、`compaction`、`subagent_*` 都是正式 runtime 语义
- `unsupported` 是 contract 的一部分，不是噪声

这件事的价值在于：宿主终于有了一个统一的运行时观测面。

### 4.3 把 transcript 和 event 分开

`tada-core` 同时保留了两条互补结构：

- `Event`：运行时过程
- `ConversationMessage` / `ContentBlock`：归一化会话记录

这两个东西很容易被误混，但它们职责不同。

`Event` 更适合：

- 流式输出
- timeline
- 审计
- 调试
- 过程感知

`ConversationMessage` / `ContentBlock` 更适合：

- 会话持久化
- 回放
- 压缩
- 跨 provider transcript 表达

一个常见错误，是想只保留一种结构。结果通常要么丢过程，要么丢状态。

### 4.4 把子代理建模成“特殊工具调用”

这是 `tada-core` 很重要的一个选择。

它没有把 subagent 设计成另一棵平行 runtime 树暴露给宿主，而是把它纳入统一工具链，并用包裹事件描述边界：

- `subagent_started`
- `subagent_finished`

它的好处不是“更优雅”，而是“更少认知分裂”：

- 宿主仍然沿用同一套工具时间线理解 delegation
- UI 不需要为 subagent 单独设计完全不同的数据模型
- provider 能力差异也更容易暴露和降级

### 4.5 把能力差异显式化，而不是假装等价

`tada-core` 没有假装所有 provider 都支持相同能力，而是通过 `Capabilities` 和 `UnsupportedEvent` 明确边界。

这件事很工程化，也很重要。

如果系统不这么做，上层常见的结果是：

- 功能“看起来能配”，实际上根本不生效
- hooks / permissions / compaction / subagent 在不同 provider 上行为漂移
- UI 误以为某些能力稳定存在

显式能力矩阵的意义，不只是文档清晰，而是让上层可以做真正可靠的依赖判断。

## 5. `tada-core` 到底提供了哪些“agent loop 基础设施”

可以把它理解成五组基础件。

### 5.1 turn contract

这是运行一轮对话的统一入口：

- `run_turn(state, user_text, *, abort=None)`

它定义了最核心的 I/O 边界：

- 输入是什么
- 输出是什么
- 哪些状态会原地变化

### 5.2 runtime event protocol

这是运行时可观测面的统一接口：

- 文本
- 工具
- 权限
- hooks
- compaction
- subagent
- error
- unsupported

这让“agent 正在干什么”终于有了稳定外部表达。

### 5.3 session state protocol

这是状态持久化与恢复的最小公共层：

- `messages`
- `usage`
- `metadata`

它故意不做成一个什么都往里塞的大状态桶，因为那会破坏 provider 无关性。

### 5.4 normalized transcript protocol

这是跨 provider 的统一消息表达：

- `ConversationMessage`
- `ContentBlock`
- `MessageRole`

它的核心价值不是“精确复刻某家模型原始 block”，而是“保留足够多的稳定语义，供持久化、回放、压缩和适配使用”。

### 5.5 runtime extension points

这是 `tada-core` 对 agent loop 提供的治理和扩展点：

- tools
- permissions
- hooks
- compaction
- subagent

注意，这些不是“产品功能按钮”，而是运行时结构。

## 6. 上层真正应该怎么使用这些结构

这一部分最关键，因为很多误用都发生在这里。

### 6.1 用 `Event` 驱动运行时交互

如果你在做：

- Web chat
- Console
- 审计面板
- 调试 timeline
- 运维可观测性

最推荐的做法是：**以 `Event` 为主协议。**

这意味着：

- 文本展示流用 `text_delta`
- 工具执行链用 `tool_use` / `tool_result`
- 审批 UI 用 `permission`
- 调试信息用 `hook` / `compaction`
- 故障面板用 `error` / `unsupported`

这样做的关键收益是：

> 上层面向的是稳定 runtime 语义，而不是某一家模型的返回细节。

### 6.2 用 `SessionState` 驱动会话持久化

宿主不应重新发明一套 provider 私有 transcript 存储格式作为主状态。

更合理的做法是：

- 把 `SessionState` 作为 runtime 主状态
- 把自己的业务对象单独建模
- 通过 `session_id` / task id / trace id 建关联

也就是说：

- `SessionState` 管“这一轮对话是如何被 runtime 理解的”
- 应用数据库管“这次业务任务在产品上意味着什么”

### 6.3 把 human-in-the-loop 设计成应用层状态机，而不是 prompt 技巧

如果上层需要审批、确认、补充信息、人工接管，建议显式维护应用层状态，例如：

- `waiting_approval`
- `waiting_user_input`
- `paused_for_review`
- `resumable`

这些状态不应该寄希望于模型自然语言自己表达清楚，更不应该只存在于前端临时状态里。

一个更稳妥的做法是：

1. 消费 `tool_use` / `permission`
2. 生成应用层 approval record
3. 保存 `SessionState` 快照
4. 等待人工动作
5. 明确 resume 点后继续跑 turn

换句话说，HITL 应该建立在显式状态与 checkpoint 之上，而不是建立在“模型说请你点确认”之上。

### 6.4 把 workflow engine 放在 `tada-core` 上层，而不是放在 provider 内部

如果未来你想引入：

- LangGraph
- Temporal
- 自己的 DAG / scheduler

更推荐的方式不是让它们替代 `tada-core`，而是让它们编排 `tada-core`。

最自然的职责分工是：

- `tada-core`：定义单轮 turn 的统一 runtime contracts
- workflow engine：管理跨 turn 的长流程、checkpoint、审批、重试策略

这样你就不会把工作流逻辑和 provider 实现缠死在一起。

### 6.5 把 UI 状态从 runtime 协议推导出来

产品态 UI 最好不要直接吃模型 payload，也不要把 runtime event 原样塞给用户。

更合理的是在 UI 或 BFF 层再派生一层状态，例如：

- `idle`
- `generating`
- `running_tool`
- `awaiting_approval`
- `paused`
- `failed`
- `done`

这些状态是：

- 对用户友好的
- 对 provider 无关的
- 从 `Event` 流中可推导的

它们不是 `tada-core` 的公共协议本身，但非常适合作为产品层协议。

## 7. 上层最容易踩的几个坑

### 坑 1：把模型原始 payload 当产品主协议

这通常会带来三个后果：

- provider 一换，上层大量逻辑跟着改
- UI 状态和底层字段路径强耦合
- “模型协议”和“产品协议”混成一团

### 坑 2：把 `metadata` 当工作流大仓库

`metadata` 很重要，但它的定位是轻量扩展槽，不是 workflow engine 的全量状态树。

如果把审批、checkpoint、任务图、业务上下文全部塞进去：

- 状态会迅速失控
- 可迁移性会下降
- core state 与业务 state 会边界模糊

### 坑 3：把 hook / permission 看成可有可无的附属品

在真正的 agent 产品里，它们通常不是“高级功能”，而是：

- 安全边界
- 审计入口
- HITL 触发器
- 运行治理点

如果这层设计不清晰，human-in-the-loop 往往会被做成一堆不稳定的 UI 猜测逻辑。

### 坑 4：把 subagent 做成第二套产品协议

如果上层自己再发明一套完全独立的 subagent message / timeline / state protocol，最终通常会得到两套互不兼容的数据模型。

更稳妥的方式，是尽量复用 `tada-core` 已有的 delegation 语义。

## 8. 一个更实用的落地模板

如果你正在用 `tada-core` 搭一个 agent 应用，我更推荐这样组织系统。

### core runtime 层

职责：

- `run_turn()`
- `Event`
- `SessionState`
- tools / permissions / hooks / compaction / subagent

### app orchestration 层

职责：

- task record
- checkpoint record
- approval record
- retry / timeout policy
- resume logic

### delivery / UX 层

职责：

- chat transcript UI
- event timeline
- approval modal
- debug panel
- playback / audit views

这个结构背后的重点不是“好看”，而是：

> 把运行时 contracts、业务控制流、产品体验三件事分开。

## 9. 读完后最该记住的三句话

### 第一句

`tool_use`、`tool_result`、`thinking` 很重要，但它们主要属于模型表达层，不足以单独构成完整 agent 系统。

### 第二句

`tada-core` 的核心价值，不是透传模型 payload，而是把 turn 生命周期、事件流、会话状态和扩展机制统一成稳定 runtime contracts。

### 第三句

上层 agent 框架或应用层应该围绕 `Event` 和 `SessionState` 建立自己的 HITL、checkpoint、workflow 和产品状态，而不是绕回去直接依赖底层模型原始协议。

## 10. 进一步阅读

- 体系定位：[`overview.md`](overview.md)
- 生命周期：[`runtime-lifecycle.md`](runtime-lifecycle.md)
- 协议分层：[`../reference/protocols.md`](../reference/protocols.md)
- 事件协议：[`../reference/events.md`](../reference/events.md)
- 会话状态：[`../reference/session-state.md`](../reference/session-state.md)
- 机制参考：[`../reference/mechanisms.md`](../reference/mechanisms.md)
- 接入主线：[`../integration/human-guide.md`](../integration/human-guide.md)
