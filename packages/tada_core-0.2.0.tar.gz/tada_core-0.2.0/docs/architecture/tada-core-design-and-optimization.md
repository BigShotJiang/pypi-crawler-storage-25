# Tada-Core 技术理念与设计原则

> Tada-Core 是 Tada-Agent 的 agent 运行底座，替换 agentscope 解决三个平台级问题：AI 思考内容不可控、多用户策略无法按请求注入、工具执行前无法强制拦截。
>
> 技术亮点：统一 Event 流、两级 Context 压缩 + 迭代摘要（设计目标）、Prompt Caching 与压缩协同降本约 84%（设计目标）、框架级 Subagent 预算约束。

---

## 目录

1. [背景：为什么需要 Tada-Core](#1-背景为什么需要-tada-core)
2. [Tada-Core 是什么](#2-tada-core-是什么)
3. [核心接口与能力体系](#3-核心接口与能力体系)
4. [接入 Tada-Core：迁移路径](#4-接入-tada-core迁移路径)
5. [路线图](#5-路线图)

---

## 1. 背景：为什么需要 Tada-Core

### 1.1 当前架构：Agentscope 是 Tada-Agent 的 Core

Tada-Agent 基于 `agentscope.ReActAgent` 构建。Agentscope 承担的角色是 agent core：驱动 LLM 调用、工具执行、循环控制。

Tada-Agent 自身的代码是产品配置层和胶水层——工具注册、提示词组装、Langfuse 埋点、MCP 接入——真正的循环逻辑一行都不在 tada-agent 里，而在 agentscope 内部。**agentscope 的能力边界，就是 tada-agent 当前的能力边界。**

### 1.2 为什么需要一个好的 Agent Core

"有没有独立 core"本身是一个工程权衡，不是显然的对错。

以 Hermes 为例：它把 loop 控制、工具调度、错误处理、业务逻辑全部内联在单一的 `run_agent.py`（9500+ 行）中，没有任何独立的 core 层。这条路完全成立——Hermes 的价值在于它的**组件精良**（迭代压缩、prompt caching、集中错误分类），与有没有 core 无关。对于"单一应用、单一团队、快速迭代"的场景，把一切放在一个文件里反而是最省事的选择。

**"无 core"路子的代价是：可扩展性和可观测性都归零。** loop 与业务逻辑混在一起，想换一个行为要在万行代码里找位置改，另一个应用想复用只能 fork 整个文件。

对于 tada-agent 这类**平台应用**，这个代价是不可接受的。多用户需要按请求注入不同策略，合规场景需要在工具执行前强制拦截。这些都要求 loop 对外暴露清晰的扩展点——也就是说，必须有 core。

**Tada-Agent 从一开始就选择了"有 core"的路**，当前使用 agentscope 作为 core。所以接下来要回答的问题不是"要不要 core"，而是：**当前这个 core 够不够用？**

### 1.3 Agentscope 的三个平台级短板

#### 一、Context 不受控

用一个比喻：每次用户发消息，AI 开始思考之前，系统会把"背景资料"塞给它——包括系统提示词、历史对话、工具描述等。这些内容的质量和成本，直接决定 AI 的表现和 API 费用。

问题是：**agentscope 没有给上层一个统一的"塞内容"入口**。每次调用都重新构建系统提示词，哪怕内容完全没变，Anthropic 的缓存也会失效。2000-8000 tokens 的系统提示词本可以稳定复用，重建机制导致每轮都重新计费。

更深层的问题是：上层对"每次 LLM 调用前的完整消息列表"没有统一干预点，无法做内容过滤、临时数据注入、动态提示词片段插入。

技术上：agentscope 没有统一的 `context transform` 入口，每次 `reply()` 重新构建 system prompt，Anthropic prompt cache 每轮 miss。

#### 二、策略无法按请求注入

Tada 是多用户平台，普通用户、会员、内部运营人员能用的工具不一样，会员到期后权限也应该立刻变化。这要求**每次对话请求都能带着自己的权限配置和行为规则进来**，而不是服务启动时配置一次就固定了。

agentscope 的 hook 策略绑定在 agent 实例上，不是绑定在单次请求上。这在平台场景下直接出两个问题：

- 会话中途权限变化，必须重建 agent 实例才能生效，而重建会丢失对话历史
- 多用户并发时，修改 agent 实例的配置存在竞争条件，A 用户的规则可能被 B 用户的请求看到

根本原因在于：agentscope 的扩展机制工作在 **LLM 流解析层**，感知不到 loop 控制层。压缩触发、权限决策结果、subagent 边界等 loop 级事件无法向上层暴露。当前工具调用状态能推给前端，是 `agentscope-runtime` 适配包在流解析层打的补丁——覆盖不了 loop 控制层的事件。

#### 三、工具执行前无法强制 async 拦截

部分工具（涉及支付、敏感数据）在执行前必须等用户点击"允许"或"拒绝"。这需要框架在工具执行前能暂停、等待外部响应。

agentscope 的 hook 是同步的，内部不能 `await`，做不到"暂停等待用户确认"。当前 `ask_user` 工具是绕过方案——它依赖 LLM 主动调用，而不是框架强制拦截。在合规场景里，这是依赖 prompt 约束而不是框架保证，两者可靠性差距很大。

> **注意**：第三个短板（强制 async 拦截）在当前版本尚未完全解决，因为 `HookRunner` 仍是同步接口。这是 Phase 3 要解决的架构债务（见 §5）。

### 1.4 参照框架的设计借鉴

| 框架 | 定位 | 对 Tada-Core 的参照价值 |
|------|------|----------------------|
| **pi-agent-core** | 有状态 loop runtime，22 个 async hook + EventStream，上下层边界由两个回调划定 | **Loop 架构基线**：循环结构清晰，EventStream（只读观测）与 Hook（可写拦截）职责分离 |
| **hermes** | 无独立 core；`run_agent.py` 9500+ 行；`agent/` 是高质量无状态组件库 | **组件层参照**：迭代压缩、prompt caching、集中错误分类实现质量高，在组件层吸纳 |
| **Claude Code** | while loop + 27 个 hook；独立 PermissionPolicy；四级 context 压缩 | **Hook 体系与压缩层次参照**：hook 覆盖完整生命周期，压缩分级精细 |
| **agentscope** | 通用 ReAct 循环框架 | 工具、MCP、并行执行基础能力完备；三个平台级短板见 §1.3 |

**结论：** pi-agent-core 是唯一真正以"可复用 core"为设计目标的框架，以它作为 loop 架构基线；Hermes 的组件设计在组件层吸纳；Claude Code 的 hook 体系和压缩分级作为能力设计参照。

---

## 2. Tada-Core 是什么

### 2.1 定位与范围边界

Tada-Core 是一个**可扩展的 Agent Core**，为 Tada-Agent 提供 agent 运行底座。

它定义了 agent 应该具备哪些能力（context 管理、工具执行、权限控制、压缩、subagent 编排），通过稳定的接口层（`contracts/`）约束所有 runtime 实现遵守一致的行为，并把被实践验证的最优设计内置进来。

**范围边界（对应 tada-agent 五层架构）：**

```
应用宿主层    FastAPI、全局中间件、Config Center          ← tada-agent
运行时编排层  MultiAgentManager、Workspace、AgentRunner   ← tada-agent
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Agent 执行层  ConversationRuntime / run_turn()             ← tada-core
              统一 Event 流、工具执行、权限、Hook
              Context 压缩机制、Subagent 预算约束
              SessionState（消息转录 + token 统计）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
扩展能力层    ToolExecutor / HookRunner 接口契约           ← 接口在 tada-core，实现在 tada-agent
              MCP 注册、built-in tools、skills              ← tada-agent
状态与接入层  ProfileStore、MemoryStore、ChatManager        ← tada-agent
              DB / Redis / WS / IM channels                 ← tada-agent
```

**明确不在 tada-core 范围：**
- Workspace 的请求装配逻辑（build_env_context、profile 加载、MCP 注册）
- long-term memory 的追加与检索
- session 到 DB 的持久化（`SessionState` 仅是 in-memory 转录对象）
- IM channel 接入、WebSocket 推送、HTTP 路由

### 2.2 三条核心原则

**可控制**

上层对进入模型的 context 有精确控制权——什么内容会被压缩、什么策略决定权限、什么 hook 在何时介入，都不该由框架暗自决定。框架提供机制，策略由上层注入。这是 context engineering 得以真正发生的前提。

**高扩展**

工具、权限、压缩、session 存储，全部可以被替换或扩展，不需要 fork 框架。扩展点通过稳定接口（`HookRunner`、`CompactionStrategy`、`PermissionPolicy`、`ToolExecutor`）暴露，上层按需实现，core 不预设业务逻辑。

**机制内聚，策略外置**

框架负责机制：循环控制、上下文压缩的触发时机、工具完整性修复、错误恢复路径、subagent 预算约束——这些不应该让每个应用重复实现。框架不负责策略：用哪个模型做摘要、token 阈值是多少、哪些工具需要审批——这些由上层在请求级动态注入，支持按用户、按租户、按 session 变化。

### 2.3 与 Pi-agent-core 的关键差异

Tada-Core 以 pi-agent-core 为参照基线，但针对平台场景做了几个不同的判断：

**平台场景要求策略绑定在请求上，不是进程上**

Pi 的很多设计隐含了"单用户、单 session、本地运行"的假设：session 存本地文件、credential 是个人 key、权限设置是用户偏好。平台场景要求 `PermissionPolicy`、`HookRunner`、`ToolExecutor` 等全部可以在**请求级别**注入，不同用户、不同租户可以获得不同的策略，而不是进程启动时配置一次。

**Permission 与 Hook 职责分离**

Pi 把授权决策混在 hook 的 `block: true` 返回值里，导致权限逻辑与变换逻辑耦合。Tada-Core 把 `PermissionPolicy`（做授权）和 `HookRunner`（做变换）拆成独立接口，可以各自测试和替换。

**Subagent 预算是框架责任**

Pi 的 subagent 由工具实现自行 spawn，无框架级预算约束。Tada-Core 通过 `SubagentSpec` 在框架层声明 `max_iterations`、`max_depth`、`allowed_tools`，防止预算失控。

---

## 3. 核心接口与能力体系

> 本节每项能力标注实现状态：✅ 已实现 / 🚧 Placeholder / 📋 规划中

### 3.1 宿主应用的唯一入口：ConversationRuntime ✅

宿主应用（runner.py、tada-agent、第三方 app）只与一个接口交互：

```python
class ConversationRuntime(ABC):

    async def run_turn(
        self,
        state: SessionState,
        user_text: str,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        """一个用户 Turn → 产出统一 Event 流（流式）"""

    # 每次 run_turn 前按需注入，支持按用户 / 租户动态变化
    def set_permission_policy(self, policy: PermissionPolicy) -> None: ...
    def set_hook_runner(self, runner: HookRunner) -> None: ...
    def set_compaction_strategy(self, strategy: CompactionStrategy) -> None: ...
    def set_tool_executor(self, executor: ToolExecutor) -> None: ...
    def register_subagent(self, spec: SubagentSpec) -> None: ...
```

宿主不需要了解 provider 内部的 loop 机制。它只消费两样东西：**Event 流**（实时观测运行过程）和 **SessionState**（跨 Turn 的消息历史与元数据）。

所有 setter 通过 `ConversationRuntime` 方法注入，不在构造函数里——平台场景下这些对象依赖请求级上下文，provider 初始化时并不存在。

### 3.2 Provider 注册机制 ✅

`ProviderRegistry` 是 tada-core 内部的 provider 路由表。`AgentCore` facade 封装了"按 provider_id 创建 runtime"的逻辑：

```python
from tada_core.contracts.registry import get_registry, register_builtin_providers

register_builtin_providers()          # 注册内置 provider
registry = get_registry()
runtime = registry.create_runtime("clawcode", {"max_iterations": 16})
```

每个 provider 声明 `ProviderMetadata`（含 `Capabilities` 矩阵），描述它支持哪些能力：

| Capability | 说明 |
|-----------|------|
| `streaming` | 能否增量 yield Event |
| `tools` | 是否支持工具调用 |
| `hooks` | HookRunner 是否生效 |
| `compaction` | CompactionStrategy 是否生效 |
| `subagent` | SubagentSpec 是否可注册 |
| `mcp` | 可选扩展，不是 core 合规要求 |

不支持的 capability **必须** 发出 `UnsupportedEvent`，不能静默忽略。

**当前内置 provider：**

| provider_id | 实现 | hooks | compaction | subagent |
|-------------|------|-------|------------|---------|
| `clawcode` | Python port of claw-code loop | ✅ | ✅ | ✅ |
| `hermes` / `hermes_native` | Hermes 风格 loop（native）| ✅ | ✅ | ✅ |
| `hermes_bridge` | 包装外部 hermes-agent | ❌ | ✅ | ✅ |
| `tada_agent_base` | 最小提取层（阶段性过渡） | ❌（Phase 2） | ❌（Phase 2） | ❌ |

### 3.3 统一 Event 流 ✅

12 种强类型事件，覆盖 agent 运行的完整生命周期：

```
TextDelta           ← LLM 流式文本增量
MessageStop         ← 一条 assistant 消息结束
ToolUseRequest      ← LLM 决定调用工具（工具名 + 输入）
ToolResultEvent     ← 工具执行结果
PermissionEvent     ← 权限决策（allow/deny + reason），保证在工具执行前出现
HookEvent           ← hook 介入通知
CompactionEvent     ← 压缩发生通知（strategy + removed_count + summary）
SubagentStarted     ← subagent 启动边界
SubagentFinished    ← subagent 结束（ok 字段）
UsageEvent          ← token 用量
ErrorEvent          ← provider 级别错误
UnsupportedEvent    ← 能力不支持（feature + detail）
```

`PermissionEvent` 保证在工具执行**前**出现，让 UI 层可以展示"准备调用：xxx"并等待用户确认。

### 3.4 Hook 系统：可写拦截器 ✅（同步）/ 📋（async）

Hook 是在不修改 runtime 代码的情况下注入自定义逻辑的扩展点。**Hook 与 Permission 职责分离**：`HookRunner` 做变换（input rewriting、工具输出脱敏、ephemeral 消息注入），`PermissionPolicy` 做授权决策（allow/deny，携带 reason），两者可独立测试和替换。

**当前已实现的 Hook 方法（同步）：**

| 方法 | 触发时机 | 典型用途 |
|------|---------|---------|
| `run_pre_tool_use` | 工具执行前 | 危险工具拦截、input rewriting |
| `run_post_tool_use` | 工具执行后 | 工具输出脱敏、增强 |
| `run_post_tool_use_failure` | 工具执行出错后 | 错误记录、恢复逻辑 |

`HookEventKind` 枚举还定义了 `PRE_LLM_CALL` 和 `ON_SESSION_START`，但当前 `HookRunner` 接口尚未提供对应方法，runtime 也未在这两个时机调用 hook。这两个 phase 是 Phase 2 补齐目标。

**架构债务**：Hook 方法目前是同步的，无法在 `PRE_TOOL_USE` 中 `await` 等待用户在前端点击 allow/deny。这是问题三（工具执行前强制 async 拦截）尚未真正解决的原因。改为 async 是 Phase 3 的核心目标。

### 3.5 Permission 层 ✅

```python
class PermissionPolicy(ABC):
    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:  # ALLOW | DENY
```

内置实现：`AllowAllPolicy`（测试默认）、`DenyListPolicy`（黑名单）。平台方实现 `PermissionPolicy` 按用户/租户动态授权，通过 `set_permission_policy()` 在每次请求前注入。

`PermissionContext` 携带来自 hook 的 override 信息，runtime 在调用 policy 前先注入 hook 的决策结果。

### 3.6 Context 压缩：两级机制

**Level 1：Tool Output Pruning** 📋（设计目标）

```
零额外成本，每次 LLM call 前自动运行
裁剪旧工具输出的超长内容，替换为占位符
不删消息、不调 LLM，维持工具调用语义完整
适合：日常维护 context 大小
```

**Level 2：LLM Summarize Compaction** 📋（设计目标）

```
三段式：HEAD（保留初始任务）/ MIDDLE（LLM 摘要）/ TAIL（保护最近 N 条）
迭代摘要：传入上次摘要，增量更新而非全量重生成
工具完整性修复：处理压缩后的孤儿 tool_call/tool_result 对
摘要结构化模板：Goal / Progress / Constraints / Key Decisions / Next Steps
```

**当前实现状态（🚧）：**

`contracts/compaction.py` 提供三个策略：
- `NeverCompact`：显式禁用压缩
- `TruncateCompaction`：按消息条数截断（无 LLM 调用）
- `SummarizeCompaction`：Placeholder，内部使用截断逻辑，**无真正 LLM 摘要调用**

`LLMSummarizeCompaction`（含迭代摘要）是 Phase 1 P0 目标，尚未实现。`CompactionStrategy.compact()` 当前是同步接口，改为 async 是 LLM 摘要实现的前提。

**迭代摘要的价值（目标）**：多数框架每次压缩都从头生成摘要，超长对话中摘要成本线性增长。增量更新把每次摘要 LLM 调用的输入稳定在"上次摘要 + 最近 N 轮"，成本恒定，质量随对话进行递增。

**为什么 Compressor 必须在 core 而不是上层**：上层应用无法原子地完成"检测到 overflow → 压缩 → 重发"，因为这条路径完全在 core 的 retry 循环内部。压缩后的孤儿 tool_call/tool_result 对是 API 协议级问题，只有 core 能原子修复。Policy 暴露给上层，机制留在 core。

### 3.7 Prompt Caching 📋（设计目标）

**策略（system_and_3）**：每次 API 调用自动注入 `cache_control`——system message（永远不变，命中率最高）+ messages[-3]、[-2]、[-1]（最近 3 条滚动窗口）。

**关键约束**：system prompt 必须跨 Turn 字节完全一致。解法：session 首次构建 system prompt 后快照存储，续接时从快照恢复，不重新构建。

**当前状态**：`ClawcodeConversationRuntime` 尚未实现 `cache_control` 注入，system prompt 快照机制也尚未实现。这是 Phase 1 P0 目标。

**与压缩的协同效应（目标）**：压缩后的 summary 消息比原始历史更稳定，之后每轮都能命中缓存。两者是乘法关系：压缩把平均 context 维持在低水位，caching 在此基础上再降 75% token 成本。综合测算节省约 84%。

### 3.8 错误治理：集中分类，差异处理 📋（设计目标）

目标：集中化错误分类，替换分散的无差别重试逻辑：

```python
@dataclass
class ClassifiedError:
    reason: FailoverReason       # rate_limit / context_overflow / auth / timeout / ...
    retryable: bool
    should_compress: bool        # True 时：先压缩再重试（用于 context_overflow）
    retry_after: float | None    # 来自 Retry-After 头
```

**当前状态**：`ClassifiedError` 尚未实现。`ClawcodeConversationRuntime` 的错误处理为 `except Exception → ErrorEvent`，无分类，context_overflow 时不会自动触发压缩再重试。这是 Phase 1 P1 目标。

### 3.9 Subagent 编排：框架级预算约束 ✅

Subagent 建模为特殊工具调用，不是独立的第二套 runtime 树。delegation 过程进入同一条事件流，宿主不需要为 subagent 单独学一套观测方式。

预算约束（`max_iterations`、`max_depth`、`allowed_tools`）是框架层声明，不是每个工具实现自己管，防止失控：

```python
@dataclass
class SubagentSpec:
    tool_name: str
    provider_id: str
    max_iterations: int = 8
    max_depth: int = 1
    allowed_tools: list[str] | None = None  # None = 继承全部
```

父 agent 事件流中 `SubagentStarted/Finished` 提供边界标记，便于监控嵌套 agent 树。`RestrictedToolExecutor` 确保 subagent 只能访问 `allowed_tools` 内的工具。

---

## 4. 接入 Tada-Core：迁移路径

### 4.1 这不是换一个 wrapper，是交互模型的切换

当前 tada-agent 的交互模型：

```
runner.py → TadaAgent.reply(msg) → Msg
```

一次性请求-响应。上层发一条消息，等待一个完整回复，过程不可见。

Tada-Core 的交互模型：

```
runner.py → runtime.run_turn(state, user_text) → AsyncIterator[Event]
```

上层消费一条事件流，实时处理每个事件（文本增量、工具请求、权限决策、压缩通知……），过程完全可观测。

这不是把 `TadaAgent` 包一层就能完成的改造，runner 层的消费逻辑需要重写。

### 4.2 每次请求动态注入策略

当前方式：工具、权限逻辑、hook 都在 `TadaAgent` 初始化时硬编码配置，所有用户共用同一套。

Tada-Core 方式：每次 `run_turn` 之前，通过 setter 注入当前请求所需的策略，按用户、按租户、按 session 动态变化：

```python
from tada_core.contracts.registry import get_registry, register_builtin_providers

register_builtin_providers()
runtime = get_registry().create_runtime("clawcode", {"max_iterations": 16})

# 每次请求前，根据当前用户身份组装策略
runtime.set_permission_policy(UserPermissionPolicy(user_id=current_user))
runtime.set_hook_runner(TenantHookRunner(tenant_id=tenant_id))

# 执行，消费事件流
async for event in runtime.run_turn(state, user_text):
    if isinstance(event, PermissionEvent):
        # 展示权限决策给用户
    elif isinstance(event, TextDelta):
        # 流式推给前端
    elif isinstance(event, ToolUseRequest):
        # 展示"正在调用：xxx 工具"
```

### 4.3 迁移原则

- **工具实现不需要重写**：`ToolExecutor` 接口足够薄，现有工具可以直接包装
- **业务 hook 逻辑可以迁移**：现有的 `MemoryCompactionHook` 等可以映射到对应的 hook 方法
- **事件消费逻辑需要新写**：runner 层对 `AsyncIterator[Event]` 的消费是全新的
- **Session 管理需要显式化**：`SessionState` 的保存和恢复由调用方负责，不再由 agentscope 内部管理；DB 持久化留在 tada-agent 的 `AgentRunner`
- **MCP / profile / memory 装配留在 AgentRunner**：tada-core 的 `ToolExecutor` 接收已装配好的工具，不负责 MCP 注册和 profile 加载

---

## 5. 路线图

### 现状差距

| 能力维度 | 当前状态 | 目标状态 | 差距 |
|---------|---------|---------|------|
| **Prompt Caching** | 无（system prompt 每次重建） | system_and_3 策略自动注入 | 多轮对话 cache 每轮 miss |
| **Context 压缩** | TruncateCompaction（无 LLM）| 两级 + 迭代摘要 | LLMSummarizeCompaction 无 LLM 调用 |
| **错误治理** | except → ErrorEvent | ClassifiedError 集中分类 | context_overflow 无法自动压缩再重试 |
| **Hook async** | 同步（3 个方法）| 全 async | 无法 await 用户 approve |
| **Hook 覆盖** | 3 种（tool use 生命周期） | 5+ 种 | 缺 PRE_LLM_CALL、ON_SESSION_START |
| **CompactionStrategy** | 同步 compact() | async compact() | LLM 摘要实现的前提 |
| **steer/followUp** | 无 | Phase 3 实现 | 依赖 loop 控制权升级 |
| **Subagent** | 接口完整，clawcode 实现 | 同左 | 已是强项，保持 |
| **Permission 层** | 独立接口 + 两个内置实现 | 同左 | 已是强项，保持 |
| **Session 持久化** | 无参考实现 | contrib 提供 | 接入方需自行造轮子 |

### Phase 1：低成本补齐（短期，P0/P1）

**System Prompt 快照 + Prompt Caching 注入（P0）**
Session 首次构建 system prompt 后快照存储，后续 Turn 从快照读取，保证 Anthropic cache prefix 字节一致。在 `ModelClient` 包装层自动注入 `cache_control`，对上层透明。预期降低 API 成本 75%。

**LLMSummarizeCompaction 实现 + 迭代摘要（P0）**
将 `CompactionStrategy.compact()` 改为 async，实现两级压缩（Tool Output Pruning + LLM 摘要），支持 `previous_summary` 迭代更新，包含工具完整性修复。

**集中化错误分类（P1）**
引入 `ClassifiedError`，替换 `ClawcodeConversationRuntime` 中分散的无差别重试逻辑，实现 context_overflow 时先压缩再重试。

**PRE_LLM_CALL / ON_SESSION_START Hook（P1）**
在 `HookRunner` 接口补充对应方法，把 `pre_reasoning` 触发器改为通用管道，支持多个 hook 顺序执行：context 过滤、ephemeral 数据注入、动态 system prompt 片段注入。

### Phase 2：压缩规整 + Session 参考实现（中期，P2）

**两级压缩完整实现**
Tool Output Pruning 作为 Level 1 低成本日常维护；LLM 摘要作为 Level 2 在极端情况兜底，两级互补。

**Session AppendOnlySessionStore contrib**
提供 `tada_core.contrib.session.AppendOnlySessionStore`，包含 `parentId` 链结构、compaction entry 替换语义、branch_summary 支持。作为 `contrib` 模块提供，不作为 core 依赖。

**tada_agent_base 完整 hooks + compaction 支持**
当前 `TadaAgentBaseRuntime` 对 hooks 和 compaction 返回 `UnsupportedEvent`，Phase 2 补齐。

### Phase 3：Loop 控制权升级（长期，P3）

**核心动机**：agentscope hook 同步限制是架构级债务，async approve 成为业务硬需求时（危险工具审计、合规场景）必须解决。

**方向：自研轻量 TadaReActRunner**
保留 agentscope 的 Toolkit / Model / Formatter，替换 loop 本身。实现天然 async hook、steer/followUp 消息队列、每个工具后的 steering 检查点：

```
while budget.remaining > 0:
    [PRE_LLM_CALL hooks（async）]     ← context transform 管道
    [prompt caching 注入]
    LLM 流式调用
    for each tool:
        [PRE_TOOL_USE await]          ← 支持等待用户 approve
        执行工具
        [POST_TOOL_USE（async）]
        [steering queue 检查]         ← 每个工具后检查用户是否中途改变方向
    [压缩检查]
    [followUp 队列检查]
```

---

## 附录：关键架构决策记录

**为什么 Compressor 必须在 core 而不是上层**

上层应用无法原子地完成"检测到 overflow → 压缩 → 重发"，因为这条路径完全在 core 的 retry 循环内部。上层也无法感知 API 返回的精确 token 数，无法修复压缩后的孤儿 tool_call/tool_result 对。Policy 暴露给上层，机制留在 core。

**为什么 Prompt Caching 与 Context Compression 是乘法而非竞争**

压缩改变前缀，会导致一次 cache miss。但压缩后生成的 summary 消息本身比原始历史更稳定（内容在下次压缩前不变），之后每轮都能命中缓存。

**为什么 Hook 方法必须改为 async**

真实的 human-in-the-loop 场景需要在工具执行前 `await asyncio.Queue.get()` 等待用户在前端点击 allow/deny。同步 hook 做不到这点，只能退化为工具内部 polling（ask_user 工具），这是工具层面的临时方案，而非框架级能力。

**为什么 SessionState.metadata 只存 str 值**

`metadata: dict[str, str]` 是有意限制：保证 `SessionState` 可序列化到任意存储后端（JSON、Redis、DB text 列），不依赖 Python 类型。Provider 需要存储复杂状态时，应序列化为字符串后存入 metadata，或在 tada-agent 层维护独立状态对象。

---

*文档更新时间：2026-05-06*
*参考分析：pi-agent-core-analysis.md / hermes-agent-core-analysis.md / tada-core-analysis.md / tada-agent-optimization-guide.md / context-compression-and-caching-deep-dive.md*
*代码核实：tada_core/contracts/\*.py / tada_core/providers/clawcode/runtime.py / tada_core/providers/hermes_provider.py*
