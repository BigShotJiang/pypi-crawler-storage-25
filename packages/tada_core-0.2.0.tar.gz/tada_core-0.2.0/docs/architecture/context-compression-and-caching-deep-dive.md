# Agent Context Compression 深度技术解析

> **范围**：Context Compression 的动因、技术原理、业内主要实现（Claude Code / openclaw / hermes / copaw / tada-agent）横向对比、Prompt Caching 与 Context Caching 的关系、压缩与缓存的协同机制，以及 tada-core 的设计方向。
>
> **基于源码**：Claude Code (cc-haha) · pi-mono · hermes-agent · agentscope · tada-agent

---

## 一、为什么需要 Context Compression

### 1.1 上下文窗口的物理边界

现代 LLM 的上下文窗口虽然从最初的 4K 一路扩展到如今的百万 token 量级，但对 Agent 场景来说，这个上限始终是存在的硬约束：

- **代码 Agent 的工具输出极其庞大**：`read_file` 返回一个 3000 行源文件，`bash` 返回完整 log，`grep` 返回几十条匹配——单次工具调用轻易消耗 10K tokens
- **工具调用轮次快速累积**：一个稍复杂的生活决策任务（如机票比价 + 酒店筛选 + 行程规划），agent 内部可能经历 50+ 次 LLM 调用（每次调用 = 一次 think + 若干工具调用），平均每轮 5K tokens，合计轻松超过 200K
- **长任务的时间跨度**：一个需要两小时完成的重构任务，中间产生的探索性失败、废弃方案、中间结果，大部分对最终决策毫无价值

上下文满了会发生什么：
1. API 返回 `context_length_exceeded` 错误，任务中断
2. 即使未超限，过长的 context 会显著降低模型的"注意力密度"（Lost in the Middle 问题），早期指令被遗忘
3. 每次 API 调用成本与 input tokens 数量线性正比

### 1.2 Naive 解法的问题

最直接的应对是截断——丢弃最旧的 N 条消息。但这会引入一个严重问题：**工具调用的语义完整性被破坏**。

```
被截断的消息：
  [user]      → 请帮我重构 auth.py
  [assistant] → <tool_call id="abc"> read_file("auth.py") </tool_call>   ← 被截断
  [tool]      → <tool_result id="abc"> ...文件内容... </tool_result>      ← 孤儿！

剩余消息：
  [assistant] → 根据文件内容，我建议...  ← 模型看不到它引用的 tool_result
```

大多数 LLM API 要求 tool_call 和 tool_result 必须成对出现，否则报错。简单截断会制造大量"孤儿"消息，导致 API 拒绝请求。

### 1.3 Context Compression 的核心目标

正确的 Context Compression 需要同时满足：

| 目标 | 说明 |
|-----|-----|
| **语义保留** | 压缩后模型仍能理解任务目标、已完成工作、关键决策 |
| **工具完整性** | 不产生孤儿 tool_call/tool_result 对 |
| **成本可控** | 压缩本身的代价（LLM 调用）要远小于节省的 token 费用 |
| **无损最近上下文** | 最近 N 轮保持原样，不能影响当前推理质量 |
| **可恢复性** | 压缩后 agent 能从摘要中提取足够信息继续执行任务 |

---

## 二、Prompt Caching 与 Context Caching：名词解释

Context 成本优化有两条路径：**压缩**（减少要发送的 token 数量）和**缓存**（减少已发送 token 的计算费用）。两者不是替代关系，而是乘法叠加——压缩后的内容更稳定，反而更容易命中缓存。这是第五章"协同机制"的核心论点，在此先把缓存的基本概念澄清清楚，避免后续各系统分析时产生混淆。

**缓存的核心价值**：
- 写入缓存：+25% 额外成本（一次性）
- 命中缓存：**-90% token 费用**（每次命中）
- 盈亏平衡点：同一前缀被复用 **1.1 次**即开始盈利
- Agent 多轮对话中 system prompt 每轮都在，天然是命中率最高的缓存段

> 注意：命中缓存只降低计算费用，**不释放 context window 空间**。要解决 context 溢出问题，必须靠压缩，缓存解决不了。

在进入各系统的压缩实现之前，先澄清两个经常混用的术语，因为它们与压缩策略密切相关。

### 2.1 技术本质

LLM 在处理 prompt 时，对每个 token 计算 Attention 的 Key-Value 矩阵（KV Cache）。这些矩阵是纯计算密集型操作，与具体的 input tokens 一一对应。

**核心洞察**：如果两次 API 调用的 prompt **前缀完全相同**，后一次调用可以跳过前缀部分的 KV 计算，直接复用缓存结果。

```
第一次调用：
  [system: 你是代码助手...] [user: 帮我看 auth.py] [assistant: 好的...] [user: 新问题]
   ←────────── 全部重新计算 ──────────→

第二次调用：
  [system: 你是代码助手...] [user: 帮我看 auth.py] [assistant: 好的...] [user: 另一个问题]
   ←──── 命中缓存，跳过计算 ────→  [只需计算新的 token]
```

### 2.2 各厂商的术语对照

| 提供商 | 官方术语 | 控制方式 | 缓存 TTL |
|------|--------|--------|--------|
| Anthropic (Claude) | **Prompt Caching** | 显式：在消息上打 `cache_control: {type: "ephemeral"}` | 5 分钟（可选 1 小时） |
| Google (Gemini) | **Context Caching** | 显式：创建 CachedContent 对象 | 最短 1 分钟，可配置 |
| OpenAI (GPT-4o) | **Prompt Caching** | 隐式：自动缓存超过 1024 tokens 的前缀 | 约 5-10 分钟 |

**名字不同，本质相同**——都是 Transformer KV Cache 的 API 层暴露。

### 2.3 Anthropic Prompt Caching 的工作细节

Anthropic 提供最多 **4 个 cache breakpoint**，可以标记在任意消息的任意内容块上：

```python
# 打了 cache_control 的消息，表示"缓存到此处的前缀"
{
    "role": "user",
    "content": [{
        "type": "text",
        "text": "...(长文本)...",
        "cache_control": {"type": "ephemeral"}  # ← breakpoint
    }]
}
```

**命中条件**：新请求的 prompt 与已缓存的 prompt 在 breakpoint 之前**逐 token 完全相同**。

### 2.4 为什么这两个名词容易混淆

当有人说"做了 context caching"，他可能指：
1. 使用了 Anthropic/Google/OpenAI 的 KV Cache 复用机制（本节所说）
2. 在 agent 层面缓存工具调用结果（如 read_file 结果不重复获取）
3. 使用向量数据库缓存历史记忆（RAG/Memory 模块）

本文只讨论含义 1，即 LLM KV Cache 层面的缓存。

---

## 三、业内实现横向对比

### 3.1 各框架压缩能力一览

> **本节基于源码核实**。2026-04 对 cc-haha、hermes-agent、pi-mono 三份源码进行了逐条验证，修正了早期版本中对 pi-mono "无迭代摘要、无 Prompt Caching" 的错误结论，以及对 hermes "双层阈值（85% + 50%）" 的不准确描述。

| 框架 | 压缩算法 | 迭代摘要 | Prompt Caching 布局 | 工具对保护 | 压缩后恢复 |
|-----|--------|--------|------------------|---------|---------|
| **Claude Code** | 三层分级：微压缩 → 全量 LLM 摘要 | ❌（每次全量重生成） | 多 scope system 切分 + 每条消息末 block 打 BP；`cache_edits` 虚拟删除（Ant-only） | ✅ 按 API round 分组 | ✅ 文件/plan/tools re-attach（唯一） |
| **hermes** | LLM 摘要（四阶段流水线 + 结构化模板） | ✅ `previous_summary` 增量更新 | **system_and_3 滚动窗口**（1 固定 system + 3 滚动） | ✅ `_sanitize_tool_pairs` 显式修复 | ❌ |
| **openclaw / pi-mono** | Token-budget 切割 + LLM 摘要 + 文件追踪 + split turn + 分支摘要 | ✅ `UPDATE_SUMMARIZATION_PROMPT` 增量更新 | system + last user message 的 2-BP ephemeral（可选 1h TTL） | ✅ valid cut points（切割阶段避免孤儿，无显式 sanitize） | ⚠️ 只在 summary 末尾附文件名 |
| **tada-agent（现状）** | LLM 摘要（ReMeLight） | ❌ | ❌ | ⚠️ 继承 agentscope | ❌ |

#### 定量估算：50 轮 LLM 调用任务，各框架成本对比

> **假设条件**：200K context 模型，每轮平均产生 3K tokens，50 轮后累计 ~150K tokens，system prompt 5K。Anthropic 缓存折扣：命中 cache 的 token 按 10% 计费。以下为相对量级估算，非精确数字。
>
> **命中率测算关键点**（修正早期版本的量级错误）：
> - Anthropic 缓存按"最新 BP 位置前的整段前缀"匹配，**不是按 BP 数量线性叠加**。
> - pi-mono 的 2-BP（system + last user）：每轮新消息到来时，`[sys, ..., 上轮最后一条 user]` 整段命中，只有本轮新增（新 user + 新 assistant 响应）miss。稳定期命中率 ~70-80%。
> - hermes 的 system_and_3 滚动窗口：4 个 BP 铺在 system + 最后 3 条非 system 消息，每轮依然只有最新一条 miss，但 BP 位置更稳、抗抖动更强。稳定期命中率 ~80-85%。
> - 两者的真实差距只有 5-10%，不是早期文档写的 "0% vs 85%" 的量级差距。
> - Claude Code 没有滚动窗口，但通过 system prompt 多 scope 切分 + 微压缩保护 BP1，命中率估算 ~70%。

| 框架 / 方案 | 是否压缩 | 是否有缓存 | 稳定期平均 context | 缓存命中率 | 相对总成本 |
|-----------|--------|---------|-----------------|---------|---------|
| 无任何优化（基准） | ❌ | ❌ | 150K（线性增长） | 0% | **100%** |
| Claude Code | ✅ 三层分级 | ✅ 多 scope 切分 + 微压缩保护前缀 | ~50K | ~70% | ~18% |
| hermes | ✅ 迭代增量摘要 | ✅ system_and_3 滚动窗口 | ~40K | ~85% | **~12%** |
| openclaw / pi-mono | ✅ 迭代摘要 + 文件追踪 + split turn | ✅ system + last user（2-BP） | ~40K | ~75% | **~15-18%** |
| tada-agent（现状） | ✅ ReMeLight | ❌ | ~40K | 0% | ~35% |
| tada-agent（目标） | ✅ 迭代摘要 | ✅ system_and_3 | ~40K | ~85% | **~12%** |

**结论**：
- Claude Code / hermes / pi-mono 三者的综合成本都落在 **12-18% 的同一档位**，选择更多取决于工程需求匹配度而非纯粹成本。
- pi-mono 的 2-BP 缓存布局比 hermes 的 system_and_3 略差（~5-10% 命中率），但工程完整度更高（文件追踪、split turn、分支摘要、auto trigger、extension hook）。
- Claude Code 的独特价值是**压缩后恢复**（re-attach 文件/plan/tools）——其他框架都没有，对代码任务意义重大。
- tada-agent 现状是"仅压缩无缓存"，叠加 system_and_3 + 迭代摘要是最直接的提升路径。

**一句话定位**：
- **Claude Code**：微压缩保护缓存前缀 + 压缩后文件恢复，代码交互场景最完整；
- **hermes**：迭代增量摘要 + system_and_3 + 显式孤儿修复，算法层面最精致；
- **openclaw / pi-mono**：工程最完备（文件追踪、split turn、分支摘要、auto trigger、extension hook），缓存布局尚有升级空间（2-BP → 4-BP 滚动窗口）；
- **tada-agent（现状）**：ReMeLight 支持语义检索，但缺压缩-缓存协同。

### 3.2 Claude Code：多层级自适应压缩（TypeScript）

**背景**：本节分析基于 Claude Code 的 TypeScript 源码（内部参考版本 cc-haha，在原版基础上做了若干修复和扩展）。与 claw-code 的 Rust 完全重写路线不同，Claude Code 的 TypeScript 实现更贴近原始设计，差异更具参考价值。

**核心策略：三层渐进式压缩，与 Prompt Cache 协同**

Claude Code 的最大特点是把压缩做成了**从轻到重的分层策略**，优先用零成本手段，只在必要时才调用 LLM 生成摘要：

```
每次 query 调用前：
    ↓
[Layer 1] Microcompact（时间触发，纯字符串替换，不调用 LLM）
    │  距上次 assistant 消息超过 N 分钟？
    │  → 找到旧的 tool result 消息，直接把 content 字段改成占位符字符串
    │    { content: "...10K 文件内容..." }  →  { content: "[Old tool result content cleared]" }
    │  → 当次 BP2-4 cache miss（前缀变了），下一轮重建后恢复
    │    作用：延缓 Layer 3 全量摘要的触发，不产生语义损失
    ↓
[Layer 2] Cached Microcompact（Ant-only，外部不可用）
    │  Anthropic 内部 API：发送 cache_edits 指令，服务端推理时"虚拟删除"旧内容
    │  → 本地消息序列完全不变，KV Cache 前缀不变，cache_read tokens 完全保留
    │  → 是 Layer 1 的进化版，但属于 Anthropic 内部能力，外部开发者无法使用
    ↓
[Layer 3] Autocompact（LLM 全量摘要，threshold 触发）
    │  token_count >= contextWindow - reservedOutput - 13K buffer？
    │  → 调用 LLM 生成摘要（最多 20K output tokens）
    │  → PTL 重试：摘要请求本身超长时，截断最老的 API round 组再重试
    └  → 压缩后恢复：重新 attach 最近读取的文件、plan、skills
```

**关键阈值常量**：
```typescript
const AUTOCOMPACT_BUFFER_TOKENS = 13_000      // 触发前保留的缓冲
const MAX_OUTPUT_TOKENS_FOR_SUMMARY = 20_000  // 摘要最大输出
const POST_COMPACT_TOKEN_BUDGET = 50_000      // 压缩后恢复文件的 token 预算
const MAX_CONSECUTIVE_AUTOCOMPACT_FAILURES = 3 // 连续失败熔断
const MAX_PTL_RETRIES = 3                      // prompt-too-long 重试次数
```

**压缩后的上下文恢复**（Claude Code 独有）：

全量压缩完成后，Claude Code 会把三类内容重新注入 context，确保 agent 压缩后不"迷失"：**最近读取过的文件内容**（最多 5 个，50K token 预算内）、**当前任务 plan**（如果有）、**工具列表变更声明**（让 agent 知道哪些工具可用）。其他框架压缩完只有摘要文字，agent 知道"自己改过某个文件"但看不到代码内容，需要重新调用工具才能继续。

```typescript
// 重新 attach 最近读取的文件（最多 5 个，共 50K token budget）
const fileAttachments = createPostCompactFileAttachments(readFileState, ...)

// 恢复当前 plan（如果有）
const planAttachment = createPlanAttachmentIfNeeded(...)

// 重新声明工具列表变更（tools delta）
getDeferredToolsDeltaAttachment(tools, [], { callSite: 'compact_full' })
```

**Prompt Cache 布局**（源码核实后修正）：

Claude Code **未使用** hermes 式的 "system_and_3 滚动窗口"。实际的 breakpoint 布局是**多 scope system 切分 + per-message 末 block**的混合策略：

```
请求构建层 [api.ts:321-435]：
  ├── 归因 header（无 cache）
  ├── System prompt 前缀（org scope）
  ├── 边界前静态内容（global scope，需 feature gate）
  └── 边界后动态内容（无 cache）

消息层 [claude.ts:593-674]：
  ├── 每条 user 消息的最后一个 content block 打 ephemeral BP
  └── 每条 assistant 消息的最后一个 content block 打 ephemeral BP（排除 thinking）
```

这种布局的特点：
- **跨 session 复用**：org / global scope 能让 system prompt 在不同 session 间共享缓存（hermes 的 ephemeral 做不到）
- **per-message 末 block**：每条消息末尾都打 BP，单次请求命中率高
- **不是滚动窗口**：没有"最后 N 条稳定命中"的保证，依赖消息本身稳定不变

**Prompt Cache 感知设计**：三层压缩策略始终把"不破坏已有缓存"作为约束条件。最有价值的细节是：Layer 3 全量摘要时，通过 `tengu_compact_cache_prefix` feature flag **fork 一个子 agent 复用主对话的 cache 前缀**来生成摘要 [compact.ts:435-438, 1179-1200]——"请帮我总结这段对话"这个请求本身也能命中已有缓存，摘要生成的 LLM 调用费用随之降低。

**PTL（Prompt-Too-Long）重试机制**：

摘要请求本身也可能超长（被压缩的内容太多），Claude Code 有专门的处理路径：

```typescript
// 按 API round 分组（一轮 assistant + 对应的所有 tool_results 算一组）
const groups = groupMessagesByApiRound(messages)

// 从错误 metadata 中提取超出的 token gap
const tokenGap = getPromptTooLongTokenGap(ptlResponse)

// 丢弃最旧的 group 直到覆盖 gap，最多重试 3 次
```

**优势**：
- 分层策略精细（Layer 1 零成本微压缩延缓 Layer 3 触发）
- **压缩后文件/plan/tools re-attach**（横向对比中唯一有此能力的框架）
- PTL 按 API round 分组的专门重试路径
- 与 Anthropic cache API 深度集成（org/global scope 可跨 session 复用）
- `tengu_compact_cache_prefix` 让摘要请求本身也能复用缓存

**劣势**：
- **无迭代增量摘要**（每次 autocompact 全量重生成，长任务摘要质量随时间退化）——这是相对于 hermes / pi-mono 的明确弱点
- 部分能力（cached microcompact、context collapse）依赖 Ant 内部 feature flag，外部用不到
- 无 hermes 式 system_and_3 滚动窗口保证，依赖消息稳定性

---

### 3.3 openclaw / pi-mono：Token-Budget 切割 + 迭代摘要 + Prompt Caching（TypeScript）

**背景**：openclaw 的 agent 核心就是 pi-mono（两者是同一个东西，不是两个独立实现）。pi-mono 是目前工程完整度最高的 TypeScript coding agent 框架，context compaction 系统覆盖了文件追踪、split turn、分支摘要、extension hook 等一系列生产级场景。

**核心策略：Token-budget aware 切割 + 并行 LLM 摘要 + 迭代更新**

```
消息列表（总 token 超过阈值）
    ↓
[1] Token 计算：优先用 API 返回的 usage.totalTokens，回退到 chars/4 估算
    [compaction.ts:128-144, 225-283]
    ↓
[2] Cut Point Detection（valid cut points 保护工具对）：
    │  从末尾向前累积 token，直到超过 keepRecentTokens(20K)
    │  只允许 user/assistant/custom/bash 作为 cut point，排除 toolResult
    [compaction.ts:292-438]
    ↓
[3] 判断是否 Split Turn：
    ├── 普通情况 → 一次 generateSummary()
    └── 单 turn 超预算 → Promise.all 并行双摘要再合并：
        [旧历史摘要 + previousSummary] || [Turn Prefix 摘要]
        ↓
        "历史摘要\n\n---\n\n**Turn Context (split turn):**\n\n前缀摘要"
    [compaction.ts:705-771]
    ↓
[4] 迭代增量摘要（文档此前漏写的核心能力）：
    │  if previousSummary:
    │    → 用 UPDATE_SUMMARIZATION_PROMPT
    │      PRESERVE existing / ADD new / UPDATE progress / REMOVE obsolete
    │  else:
    │    → 用 SUMMARIZATION_PROMPT 全量生成
    │  previousSummary 来源：上一条 CompactionEntry.summary（session 链式存储）
    [compaction.ts:520-573, 650-655]
    ↓
[5] 文件操作追踪（跨压缩累积）：
    │  从上次 CompactionEntry.details 取 {readFiles, modifiedFiles}
    │  + 从本次 messagesToSummarize 的 tool_call 参数提取
    │  追加到摘要末尾 <read-files>...<modified-files>
    [compaction.ts:37-69, 755-769]
    ↓
[6] Branch Summarization（其他框架都没有）：
    │  树形会话切换时为离开的分支生成摘要
    [branch-summarization.ts]
```

**迭代摘要的具体机制**（对标 hermes 的 `previous_summary`）：

```typescript
// compaction.ts:520-573
export async function generateSummary(
  currentMessages: AgentMessage[],
  model: Model<any>,
  reserveTokens: number,
  apiKey: string,
  signal?: AbortSignal,
  customInstructions?: string,
  previousSummary?: string,  // ← 来自上次 CompactionEntry.summary
): Promise<string> {
  let basePrompt = previousSummary ? UPDATE_SUMMARIZATION_PROMPT : SUMMARIZATION_PROMPT;
  // UPDATE_SUMMARIZATION_PROMPT:
  //   "PRESERVE all existing information / ADD new progress / UPDATE Progress section /
  //    PRESERVE exact file paths, function names, and error messages"
  ...
}
```

**Prompt Caching 布局**（文档此前漏写）：

```typescript
// anthropic.ts:487-508, 673-695
// BP1: system prompt（每次调用都命中）
params.system = [{
  text,
  cache_control: { type: "ephemeral", ...(ttl && { ttl }) },
}]

// BP2: 最后一条 user message 的最后一个 content block
if (lastMessage.role === "user") {
  lastBlock.cache_control = cacheControl
}

// PI_CACHE_RETENTION 环境变量控制：
//   "short"（默认）→ ephemeral 5m
//   "long"         → ephemeral + ttl: "1h"
//   "none"         → 不打 cache
```

**2-BP 布局的实际命中效果**：每轮新消息进来时，`[sys, ..., 上轮最后一条 user]` 整段历史都命中（因为上一轮 BP2 打在那里），只有本轮新 user + 新 assistant 响应 miss。稳定期命中率 ~70-80%。相比 hermes 的 system_and_3，**差距不在于覆盖率翻倍，而在于抗抖动性**——system_and_3 用 4 个 BP 能让 BP 位置更稳、对最后一条消息内容频繁变化（如流式更新）不敏感。

**消息序列化策略**：送入 summarizer 之前，把对话序列化成带标签的文本，防止 summarizer 误把历史消息当作"对话继续"：

```typescript
// utils.ts serializeConversation
parts.push(`[User]: ${content}`);
parts.push(`[Assistant thinking]: ${thinkingParts.join("\n")}`);
parts.push(`[Assistant]: ${textParts.join("\n")}`);
parts.push(`[Assistant tool calls]: ${toolCalls.join("; ")}`);
parts.push(`[Tool Result]: ${...}`);
```

**Extension Hook 机制**（其他框架都没有）：
- `session_before_compact` hook：extension 可接管压缩逻辑、提供自定义 summary / details
- Auto compaction 由 `_autoCompactionAbortController` 在 session 层驱动（非纯手动 `session.compact()`）
- Multi-provider 支持：同一套 compaction 架构下 Anthropic / OpenAI / Gemini / Bedrock 都能用

**优势**：
- **工程完备性最高**：文件追踪、split turn、分支摘要、extension hook、auto trigger、多 compaction 链式存储
- **迭代增量摘要 + Prompt Caching 都齐全**（与 hermes 并列，不是弱点）
- TypeScript 类型安全，多 provider 支持
- Multi-compaction 链式 session：每次压缩 append CompactionEntry，parentId 构成 git-like 树结构

**劣势**：
1. **Cache breakpoint 布局是 2-BP 而非 system_and_3 滚动窗口**（命中率 ~75% vs hermes ~85%，差距 5-10%）
2. **无显式 `sanitize_tool_pairs` 兜底函数**：靠 `findValidCutPoints` 从切割阶段避免孤儿，正常路径无虞，但 extension 注入 / session fork / 手动编辑 session file 等绕过 cut point 的场景缺兜底
3. **无零成本 Tool Output Pruning 预压缩层**：要么不压要么全量 LLM 摘要，没有 hermes 的"先剪 >200 字符 tool result"零成本中间层
4. **无压缩后 re-attach**：只在 summary 末尾附文件**名**（`<read-files>` tag），agent 想看文件内容需要重新调用工具（Claude Code 这点更强）

---

### 3.4 hermes：迭代 LLM 摘要 + Prompt Caching 协同（Python）

**背景**：hermes 是算法层面最精致的运行时压缩实现，核心创新是**迭代增量摘要**和**压缩-缓存协同设计**（system_and_3 滚动窗口）。

#### 3.4.1 触发架构：单层阈值 + 错误兜底（源码核实后修正）

> **修正说明**：早期文档描述的"双层防护（85% Gateway + 50% Agent）"与源码不符。对 hermes-agent 源码（`agent/context_compressor.py`、`gateway/`）全仓 grep `0.85` / `gateway` / `>= 4` 均无匹配。源码实际实现的是**单层 50% 阈值 + context_length_exceeded 错误恢复**。

```
即将发送的 prompt
    ↓
┌─────────────────────────────────────────────────────┐
│ [主路径] threshold = 50% × context_limit           │  ← 主动预防
│  默认 threshold_percent = 0.50                     │
│  [context_compressor.py:95]                        │
│  触发：self.threshold_tokens = int(ctx_len * 0.50) │
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│ [错误兜底] context_length_exceeded → 复用同一 compressor │
│  error_classifier.py:641 设 should_compress=True   │
│  重试前走一次压缩（不是独立阈值，是共用的错误路径）  │
└─────────────────────────────────────────────────────┘
    ↓
LLM API 调用（重试）
```

这是"**单阈值主路径 + 错误兜底**"，而非"双层独立阈值"。`_context_probed` 标志位（[context_compressor.py:72, 141]）仅用于跟踪"从错误恢复后的步进状态"，是二元状态位，不是 85% 这样的数值阈值。

#### 3.4.2 四阶段压缩流水线

```
Phase 1: Tool Output Pruning（零 LLM 成本）
  ↓ 从旧消息开始，将超过 200 字符的 tool result 替换为占位符
  ↓ 用 token budget 而非消息数量控制尾部保护范围

Phase 2: Head/Middle/Tail 边界检测
  ↓ Token budget 方式：从末尾向前累积，确定 tail_start
  ↓ Boundary Alignment：不切割 tool_call/tool_result 对

Phase 3: 结构化 LLM 摘要（增量或全量）
  ↓ 第 1 次：全量生成
  ↓ 第 2+ 次：增量更新 previous_summary（hermes 的核心创新）

Phase 4: 重组 + 工具完整性修复
  ↓ 处理 same-role 冲突（连续 user/user 或 assistant/assistant）
  ↓ sanitize_tool_pairs()：修复孤儿 tool_call/tool_result
```

#### 3.4.3 迭代增量摘要（hermes 核心创新）

这是 hermes 最独特的能力，其他系统（包括 pi-mono、claw-code）都没有：

```python
# 第一次压缩：全量生成
if not self._previous_summary:
    prompt = "Create structured handoff summary of this conversation..."

# 第二次及以后：增量更新
else:
    prompt = f"""
    Update existing summary based on new turns:
    - PRESERVING: 仍然相关的信息（约束、已完成工作、关键决策）
    - ADDING: 新进展（将任务从 In-Progress 移入 Done/Blocked）
    - REMOVING: 已过时的信息（已解决的阻塞、废弃的方案）
    
    PREVIOUS SUMMARY:
    {self._previous_summary}
    
    NEW TURNS (since last compaction):
    {content_to_summarize}
    """
```

**为什么这很重要**（修正：pi-mono 也已实现迭代摘要，本表对比的是"有无迭代摘要"的差异）：

| 压缩次数 | 全量重生成（Claude Code / tada-agent 现状） | 增量更新（hermes / pi-mono） |
|--------|-------------------------------------|--------------------------|
| 第 1 次 | summarize(轮次 1-50) | summarize(轮次 1-50) |
| 第 2 次 | summarize(轮次 1-100) | update(prev_summary, 轮次 51-100) |
| 第 3 次 | summarize(轮次 1-150) | update(prev_summary, 轮次 101-150) |
| 输入 token 趋势 | 线性增长 | **稳定不变** |
| 历史积累 | 每次重置，早期信息丢失 | **持续累积，不丢失** |

> **重要更正**：pi-mono 的 `generateSummary(..., previousSummary?)` [compaction.ts:520-573] 与 hermes 的迭代机制本质相同。早期文档把 pi-mono 划入"全量重生成"阵营是错误的，真正"无迭代摘要"的只有 Claude Code（每次 autocompact 全量重生成）和当前版本 tada-agent。

#### 3.4.4 摘要结构模板

```markdown
## Goal                    [用户想完成什么]
## Constraints & Preferences  [决策约束、偏好]
## Progress
### Done
- [x] 已完成（含文件路径和命令）
### In Progress
- [ ] 进行中
### Blocked
- 阻塞问题
## Key Decisions           [关键决策及理由]
## Relevant Files          [读取/修改的文件]
## Next Steps              [接下来需要什么]
## Critical Context        [具体数值、报错、配置]
## Tools & Patterns        [有效的工具调用模式]
```

#### 3.4.5 摘要 Token Budget 自适应缩放

```python
summary_budget = max(
    int(content_tokens × 0.20),            # 压缩内容的 20%
    _MIN_SUMMARY_TOKENS,                    # 最小 2000 tokens
    min(context_length × 0.05, 12_000)     # 上限 12K tokens
)
```

内容越多，摘要越详细，但有硬上限防止摘要本身膨胀。

#### 3.4.6 工具完整性修复（Sanitization）

压缩后两类残留问题的处理：

```
情况 A：tool_result 的 call_id 引用了已删除的 tool_call
  修复：删除这个孤儿 tool_result

情况 B：tool_call 的结果被保留，但 call 本身被删除
  修复：插入占位 tool_result：
  {
    "role": "tool",
    "content": "[Result from earlier — see context summary above]",
    "tool_call_id": cid,
  }
```

#### 3.4.7 摘要 Token Budget 实际公式（源码核实修正）

源码的实现公式与文档 3.4.5 描述略有差异（数学上等价，但形式不同）：

```python
# context_compressor.py:127-129（初始化时计算上限）
self.max_summary_tokens = min(
    int(self.context_length * 0.05),
    _SUMMARY_TOKENS_CEILING,  # 12_000
)

# context_compressor.py:227-236（每次压缩计算预算）
def _compute_summary_budget(self, turns_to_summarize):
    content_tokens = estimate_messages_tokens_rough(turns_to_summarize)
    budget = int(content_tokens * _SUMMARY_RATIO)  # 0.20
    return max(_MIN_SUMMARY_TOKENS, min(budget, self.max_summary_tokens))
```

逻辑等价于 3.4.5 描述，内容越多摘要越详细，有 12K 硬上限。

#### 3.4.8 批量轨迹压缩（trajectory_compressor）

`trajectory_compressor.py`（1456 行）与 `context_compressor.py` **不是同一用途**：
- **context_compressor**：运行时压缩活跃会话
- **trajectory_compressor**：**offline 批量处理训练数据 JSONL**，为 RL / SFT 训练数据降 token
- 横向对比 Agent 运行时 context compression 时不应作为同类对比项

**优势**：
- **迭代摘要**（长期任务信息积累，与 pi-mono 并列）
- **system_and_3 滚动窗口**（4 个 BP 最优分配，命中率横向对比最高）
- **显式 `_sanitize_tool_pairs`**（两种孤儿场景都处理，对 extension 注入/session fork 等边界场景鲁棒）
- **零成本 Tool Output Pruning**（Phase 1 先剪 >200 字符 tool result，再决定是否 LLM 压缩）
- 单层阈值 + 错误兜底，架构简洁

**劣势**：
- 无文件操作追踪（pi-mono 有）
- 无 split-turn 处理（pi-mono 有）
- 无分支摘要（pi-mono 有）
- 无压缩后 re-attach（Claude Code 有）
- Python 生态绑定较强，移植到 TypeScript 场景需重写

---

### 3.5 copaw / agentscope：结构化 LLM 摘要，Pydantic 约束（Python）

**背景**：copaw 是 tada-agent 的前身，基于阿里巴巴开源的 agentscope 框架构建，其 context 压缩继承自 agentscope 的 ReActAgent 实现。

**核心策略：LLM 输出通过 Pydantic Schema 约束，确保摘要字段完整性**

```python
class SummarySchema(BaseModel):
    task_overview: str = Field(max_length=300)          # 任务总览
    current_state: str = Field(max_length=300)          # 当前状态
    important_discoveries: str = Field(max_length=300)  # 重要发现
    next_steps: str = Field(max_length=200)             # 下一步
    context_to_preserve: str = Field(max_length=300)    # 需要保留的上下文
```

**触发机制**：
- 可配置的 `trigger_threshold`（token 数）
- `keep_recent`（保留最近 N 条不压缩）
- 压缩后的消息被标记为 `_MemoryMark.COMPRESSED`，未来检索时过滤掉
- 摘要以 `<system-info>` 包裹注入到后续轮次

**摘要注入格式**：
```
<system-info>Here is a summary of your previous work
# Task Overview
{task_overview}

# Current State  
{current_state}

# Important Discoveries
{important_discoveries}

# Next Steps
{next_steps}

# Context to Preserve
{context_to_preserve}
</system-info>
```

**优势**：Pydantic 确保结构完整、字段长度可控、framework 生态丰富（多种 Memory backend）  
**劣势**：无迭代摘要（每次全量）、无工具完整性修复、无 Prompt Caching

---

### 3.6 tada-agent：agentscope + ReMeLight 扩展（Python，当前版本）

**背景**：tada-agent 在 copaw/agentscope 基础上，增加了 ReMeLight（内部记忆管理库）和异步处理层，是目前 Tada 的 agent 运行时。

**核心扩展点**：

```python
class RunningConfig(BaseModel):
    max_input_length: int = 128 * 1024     # 131,072 tokens 上限

    memory_compact_ratio: float = 0.75     # 达到 75% 时触发压缩
    memory_reserve_ratio: float = 0.10     # 保留最近 10% tokens 不压缩

    @property
    def memory_compact_threshold(self) -> int:
        return int(self.max_input_length * self.memory_compact_ratio)  # ~98K

    @property  
    def memory_compact_reserve(self) -> int:
        return int(self.max_input_length * self.memory_reserve_ratio)  # ~13K
```

**Pre-reasoning Hook 架构**：

```
每次推理前（before_reasoning hook）
    ↓
MemoryCompactionHook.__call__(agent, kwargs)
    ↓
计算 system_prompt + compressed_summary 的 token 数
    ↓
context_check(messages, threshold=98K - sys_tokens, reserve=13K)
    │  （CPU 密集型，offload 到 thread pool via asyncio.to_thread）
    ↓
如果 messages_to_compact 非空：
    compact_memory(messages_to_compact, previous_summary)
    │  调用 ReMeLight.compact_memory()
    │  传入 as_llm（聊天模型）、token_counter、language 等
    ↓
update_compressed_summary(compact_content)
update_messages_mark(ids, COMPRESSED)  ← 标记已压缩消息
```

**ReMeLight 是什么**：

普通压缩把历史消息变成一段摘要文字，agent 只能靠这段文字"回忆"过去。ReMeLight 在摘要之外，额外把历史内容构建成**可检索的索引**：

```
普通压缩：历史消息 → 摘要文字 → 注入 context（线性传递，靠描述）

ReMeLight：历史消息 → 摘要文字 + 向量索引 + 全文索引
                                  ↓
                         "找和预算相关的历史步骤" → 按需召回
```

对生活决策类长任务（查了十几家酒店、多个航班方案）尤其有价值——压缩后不是靠文字描述"之前查过很多选项"，而是在需要时能精确检索"之前查过的上海五星酒店列表"。

**ReMeLight 附加能力**：
- **向量搜索（可选）**：需要 EMBEDDING_API_KEY，对历史记忆做语义检索
- **全文搜索（默认启用）**：BM25 类全文检索历史记忆
- **嵌入缓存**：`EMBEDDING_CACHE_ENABLED=true`，最多缓存 2000 条嵌入
- **多语言支持**：压缩 prompt 可以是中文（`language="zh"`）

**优势**：异步架构（CPU 密集型不阻塞主循环）、向量/全文搜索支持、多语言  
**劣势**：继承 agentscope 的问题（无迭代摘要、无工具完整性修复、无 Prompt Caching）

---

## 四、横向能力对比

> **本表基于 2026-04 源码核实**。早期版本多处错误已修正，变化点：
> - pi-mono 的迭代摘要 / Prompt Caching 改为 ✅
> - hermes 触发层数从"双层 (85%+50%)" 改为"单层 50% + 错误兜底"
> - Claude Code 的 Prompt Caching 描述改为"多 scope system 切分 + per-message 末 block"（非滚动窗口）
> - Claude Code 语言从 "Rust" 改为 "TypeScript"（早期错误）
> - trajectory_compressor 澄清为 offline 训练数据工具，不是运行时能力

| 能力维度 | Claude Code | openclaw/pi-mono | hermes | copaw/agentscope | tada-agent |
|--------|--------|-----------------|--------|-----------------|-----------|
| **压缩算法** | 三层分级（微压缩→全量摘要） | LLM 摘要 + 文件追踪 + split turn + 分支摘要 | LLM 摘要（四阶段） | LLM + Pydantic | LLM + ReMeLight |
| **迭代增量摘要** | ❌ 每次全量 | ✅ `UPDATE_SUMMARIZATION_PROMPT` | ✅ `previous_summary` | ❌ | ❌ |
| **触发层数** | 三层（时间微压 / token阈值 / PTL恢复） | 单层 + auto trigger | 单层 50% + 错误兜底 | 单层 | 单层 (75%) |
| **边界检测** | Token buffer（contextWindow - 13K） | Token budget | Token budget | Token count | Ratio-based |
| **工具对保护** | ✅ 按 API round 分组截断 | ✅ valid cut points | ✅ + sanitize | ⚠️ 依赖 mark | ⚠️ 继承 agentscope |
| **工具完整性修复** | ⚠️ PTL 重试时按 round 丢弃 | ⚠️ 依赖 cut point（无显式 sanitize 兜底） | ✅ sanitize_tool_pairs | ❌ | ❌ |
| **摘要结构化** | LLM 自由生成 + 边界 marker | Markdown 模板 + `<read-files>` tags | Markdown 8-section | Pydantic schema | Pydantic (继承) |
| **Prompt Caching** | ✅ 多 scope system 切分 + per-message 末 block + fork 复用 cache | ✅ system + last user (2-BP)，可选 1h TTL | ✅ **system_and_3 滚动窗口** | ❌ | ❌ |
| **零成本预压缩** | ✅ Microcompact（清空旧 tool result） | ❌ | ✅ Tool Output Pruning（>200 字符替换占位符） | ❌ | ❌ |
| **压缩后上下文恢复** | ✅ 文件/plan/tools re-attach | ⚠️ 仅文件名列表 | ❌ | ❌ | ❌ |
| **文件操作追踪** | ✅ readFileState 跟踪 | ✅ 跨压缩累积（readFiles/modifiedFiles） | ❌ | ❌ | ❌ |
| **Split turn 处理** | ❌ | ✅ Promise.all 并行双摘要 | ❌ | ❌ | ❌ |
| **分支摘要** | ❌ | ✅ 树形导航（branch-summarization.ts） | ❌ | ❌ | ❌ |
| **Extension Hook** | ❌ | ✅ `session_before_compact` | ❌ | ❌ | ❌ |
| **Multi-provider** | Anthropic-only | ✅ Anthropic/OpenAI/Gemini/Bedrock | Anthropic-only | 多 backend | 多 backend |
| **向量/语义检索** | ❌ | ❌ | ❌ | ❌ | ✅ ReMeLight |
| **异步处理** | TypeScript async | TypeScript async | asyncio | 同步 | ✅ asyncio.to_thread |
| **批量轨迹压缩** | ❌ | ❌ | ✅ trajectory_compressor（offline 训练数据，非运行时） | ❌ | ❌ |
| **语言** | TypeScript | TypeScript | Python | Python | Python |

---

## 五、压缩与 Prompt Caching 的协同机制

这是整个技术体系中最精妙的部分，也是最容易产生误解的地方。

### 5.1 表面矛盾

**压缩**改变了消息内容 → 前缀不再与旧缓存一致 → **缓存失效**

这两件事看起来是对立的：你要么保持前缀稳定（利于缓存），要么压缩改变前缀（摧毁缓存）。

### 5.2 矛盾的消解：时间维度

把视角从单次调用拉到整个 session 生命周期：

```
轮次:  1   2   3  ...  50  51  52  53  ...  100  101 ... 150
                       ↑                    ↑
                  [第1次压缩]           [第2次压缩]

缓存状态:
  1-49:   ████████ 命中（前缀稳定增长，越来越多命中）
  50:     ✗        压缩 → 前缀改变 → 一次 miss
  51:     ✗        写入新缓存（summary 作为新前缀）
  52-99:  ████████ 命中（summary 内容稳定！比历史消息更稳定）
  100:    ✗        第二次压缩，一次 miss
  101-149:████████ 命中
```

**关键洞察**：压缩只引入 **1次** cache miss，换来：
1. context 从 150K 降回 30K（节省大量 token 费用）
2. 压缩后的 summary 比历史消息**更稳定**，成为命中率更高的缓存前缀

### 5.3 hermes system_and_3 策略

**为什么叫 system_and_3**

Anthropic 限制每次请求最多 4 个 cache breakpoint。system_and_3 是对这 4 个 breakpoint 的最优分配方式：1 个给 system（永远不变，永远命中），剩余 3 个形成**滚动窗口**覆盖最近 3 条消息。

**滚动窗口的工作原理**

缓存按"前缀哈希"存储，不是按消息位置存储。Turn N 写入的 breakpoint，正好是 Turn N+1 需要查的前缀：

```
Turn 5 发送：[sys, m1, m2, m3, m4, m5]
打 BP 的位置：sys(BP1), m3(BP2), m4(BP3), m5(BP4)

服务器写入缓存：
  hash([sys])             ← BP1 写入
  hash([sys..m3])         ← BP2 写入
  hash([sys..m4])         ← BP3 写入
  hash([sys..m5])         ← BP4 写入

Turn 6 发送：[sys, m1, m2, m3, m4, m5, m6]
打 BP 的位置：sys(BP1), m4(BP2), m5(BP3), m6(BP4)

服务器查缓存：
  hash([sys])       = Turn5.BP1 → 命中 ✅
  hash([sys..m4])   = Turn5.BP3 → 命中 ✅（上一轮写过！）
  hash([sys..m5])   = Turn5.BP4 → 命中 ✅（上一轮写过！）
  hash([sys..m6])   = 新内容    → miss，写入
```

每轮只有最新消息 miss（需写入），其余 3 个全部命中。名字描述的是"strategy 形状"——1 个固定的 system + 3 个滚动的最近消息，正好用满 4 个 breakpoint。

hermes 设计了针对 Anthropic 4-breakpoint 限制的最优策略：

```python
def apply_anthropic_cache_control(messages, cache_ttl="5m"):
    # Breakpoint 1: system message（每次调用都在，永远命中）
    if messages[0]["role"] == "system":
        _apply_cache_marker(messages[0], marker)
    
    # Breakpoints 2-4: 最后 3 条非 system 消息（滚动窗口）
    non_sys = [i for i, m in enumerate(messages) if m["role"] != "system"]
    for idx in non_sys[-3:]:
        _apply_cache_marker(messages[idx], marker)
```

**压缩前后的缓存行为**：

```
正常轮次（稳定期）：
  [system]        ← BP1: 永远命中 ✅
  ...（中间历史）
  [messages[-3]]  ← BP2: 命中（上轮 BP3 写入）✅
  [messages[-2]]  ← BP3: 命中（上轮 BP4 写入）✅
  [messages[-1]]  ← BP4: 新消息，miss → 写入缓存

压缩发生那一轮（例如 Turn 51）：
  [system]        ← BP1: 命中 ✅（从未改变）
  [summary]       ← BP2: miss，写入（新前缀）
  [messages[-2]]  ← BP3: miss，写入
  [messages[-1]]  ← BP4: miss，写入

压缩后第 2 轮（Turn 52）：
  [system]        ← BP1: 命中 ✅
  [summary]       ← BP2: 命中 ✅（Turn51 BP2 写过，summary 内容稳定）
  [messages[-2]]  ← BP3: 命中 ✅（Turn51 BP3 写过）
  [messages[-1]]  ← BP4: 新消息，miss → 写入
```

压缩那一轮 miss 3 次（滚动窗口重建），**第 2 轮立即恢复 3/4 命中，第 3 轮满命中**。压缩后 summary 内容比原始历史消息更稳定（不随每轮变化），反而提升了 BP2 的长期命中率。

### 5.4 三层成本优化的乘法效应

**以 hermes 为例**（三层都具备）的完整成本优化叠加：

```
Layer 1: Tool Output Pruning（免费，零 LLM 调用）
  工具输出往往占总 token 的 40-60%
  → 把 150K tokens 降到 80K（节省 47%）

Layer 2: LLM Summary 压缩（低成本：Haiku 做摘要）
  把 80K 中间历史压缩到 10K summary
  → 把 80K 降到 30K（节省 63%）

Layer 3: Prompt Caching（缓存折扣 90%）
  30K tokens 中，system(5K) + summary(10K) = 15K 稳定命中缓存
  → 15K × 0.1（缓存价格）+ 15K = 16.5K effective tokens

最终：150K raw tokens → 16.5K effective tokens，节省约 89%
```

**其他框架的层次覆盖情况**：

| 框架 | Layer 1 Tool Pruning | Layer 2 Summary | Layer 3 Cache |
|-----|-------------------|----------------|---------------|
| Claude Code | ✅ Microcompact（时间触发） | ✅ Autocompact（全量） | ✅ 多 scope system + per-msg |
| pi-mono | ❌ | ✅ 迭代增量 | ✅ 2-BP ephemeral |
| hermes | ✅ 零成本占位符替换 | ✅ 迭代增量 | ✅ system_and_3 |

pi-mono 最直接的成本优化空间是**补齐 Layer 1 Tool Output Pruning**（延缓 Layer 2 触发频率）和**升级 Layer 3 到 system_and_3**（5-10% 命中率）。

### 5.5 迭代摘要进一步增强缓存效果

迭代增量摘要（`previous_summary` 机制，hermes 和 pi-mono 都有）不仅节省了摘要 LLM 的调用成本，还间接增强了缓存效果：

- 全量重生成（Claude Code / tada-agent 现状）：每次生成不同 summary → 前缀不同 → 缓存失效
- 增量更新（hermes / pi-mono）：summary 结构保持稳定，只更新状态变化的字段 → **summary 前缀命中率更高**

---

## 六、tada-core 的设计方向

### 6.1 现状问题梳理

tada-agent（当前版本）继承自 agentscope，存在以下主要问题：

| 问题 | 影响 |
|-----|-----|
| 无迭代增量摘要 | 每次全量重生成，长期任务摘要质量随时间退化 |
| 无工具完整性修复 | 孤儿 tool_call/result 可能导致 API 拒绝请求 |
| 无 Prompt Caching | 每次调用重复计算 system prompt（2K-8K tokens），浪费 |
| 同步 token 计数 | CPU 密集型 tokenization 阻塞主循环（已部分修复为 asyncio.to_thread） |
| 单层触发 | 只有一个 75% 阈值，无被动兜底层 |

### 6.2 分层架构原则

**基础设施在 core，Policy 暴露给上层**

```
┌─────────────────────────────────────────────────────┐
│               Agent Application Layer                │
│  提供：CompressorPolicy（threshold, template, model）│
│  提供：CachingPolicy（strategy, ttl）               │
└───────────────────┬─────────────────────────────────┘
                    │ Policy 注入
┌───────────────────▼─────────────────────────────────┐
│                  Agent Core Layer                    │
│                                                      │
│  ContextCompressor（基础设施）                        │
│  ├── Tool Output Pruning                             │
│  ├── Boundary Detection（token budget）              │
│  ├── LLM Summary（增量/全量）                         │
│  ├── Tool Pair Sanitization                          │
│  └── 触发时机（主动 50% + 被动 85%）                   │
│                                                      │
│  PromptCachingManager（与 Compressor 协同）           │
│  └── apply_cache_control(strategy, ttl)              │
└─────────────────────────────────────────────────────┘
```

**为什么 core 必须有：**
1. `context_length_exceeded` 错误在 core 的 retry 循环里处理，上层无法介入
2. 工具完整性修复是 API 协议级问题，上层不应感知
3. 触发阈值依赖 API 返回的实际 token 数，只有 core 能拿到
4. 避免每个 agent 应用重复实现压缩逻辑

### 6.3 推荐实现路线

**P0：工具完整性修复**（最高优先级，影响稳定性）

```python
class ContextCompressor:
    def _sanitize_tool_pairs(self, messages: list) -> list:
        """修复压缩后的孤儿 tool_call/tool_result"""
        call_ids = {block.id for m in messages for block in m.tool_calls}
        result_ids = {m.tool_call_id for m in messages if m.role == "tool"}
        
        # 删除孤儿 result
        messages = [m for m in messages
                    if m.role != "tool" or m.tool_call_id in call_ids]
        
        # 补全缺失的 result
        missing = call_ids - result_ids
        for cid in missing:
            messages.insert(after_call_position, stub_result(cid))
        
        return messages
```

**P1：Prompt Caching（system_and_3 策略）**

```python
class PromptCachingManager:
    def apply(self, messages: list, ttl: str = "5m") -> list:
        # system message（最稳定）
        # messages[-3], [-2], [-1]（滚动窗口）
        # 总共不超过 4 个 breakpoint
```

**P2：迭代增量摘要**

```python
class ContextCompressor:
    def __init__(self):
        self._previous_summary: str | None = None
    
    async def _generate_summary(self, middle_messages, policy) -> str:
        if self._previous_summary:
            # 增量更新
            prompt = UPDATE_PROMPT.format(
                previous=self._previous_summary,
                new_turns=serialize(middle_messages)
            )
        else:
            # 首次全量生成
            prompt = CREATE_PROMPT.format(
                content=serialize(middle_messages)
            )
        summary = await call_llm(policy.summary_model, prompt)
        self._previous_summary = summary
        return summary
```

**P3：双层触发**

```python
# 主动层：before_api_call hook
if estimated_tokens > context_limit * 0.50:
    messages = await compressor.compress(messages, policy)

# 被动层：error recovery
except ContextLengthExceeded:
    messages = await compressor.compress(messages, policy)
    retry()
```

### 6.4 可借鉴的最优实践组合

根据各系统的横向对比，为 tada-core 推荐以下技术选型：

| 技术点 | 参考来源 | 说明 |
|------|--------|-----|
| 迭代增量摘要 | hermes | 最核心，其他系统都没有 |
| system_and_3 Prompt Caching | hermes | 直接采用 |
| 工具完整性修复 | hermes | `_sanitize_tool_pairs()` 逻辑 |
| Token budget 边界检测 | hermes / pi-mono | 比固定 N 条更精确 |
| 微压缩（tool result 清空）优先于全量摘要 | Claude Code | 零成本先行，保护 cache 前缀 |
| 压缩后上下文恢复（文件/plan re-attach） | Claude Code | 防止 agent 压缩后"迷失" |
| PTL 重试（按 API round 截断） | Claude Code | 摘要请求本身超长时的降级路径 |
| 文件操作追踪 | pi-mono | 对代码任务有价值 |
| 异步 token 计数 | tada-agent（现有） | 保留 |
| Pydantic schema 约束 | agentscope（现有） | 可保留，增强字段完整性 |
| 双层触发 | hermes | Gateway(85%) + Agent(50%) |

---

## 附录：各系统关键文件索引

| 系统 | 关键文件 | 说明 |
|-----|--------|-----|
| hermes-agent | `agent/context_compressor.py` | 核心压缩算法 |
| hermes-agent | `agent/prompt_caching.py` | system_and_3 策略 |
| hermes-agent | `trajectory_compressor.py` | 批量轨迹压缩 |
| pi-mono | `packages/coding-agent/src/core/compaction/compaction.ts` | 压缩主流程 |
| pi-mono | `packages/coding-agent/src/core/compaction/branch-summarization.ts` | 分支摘要 |
| pi-mono | `packages/coding-agent/src/core/compaction/utils.ts` | 序列化 + 文件追踪 |
| Claude Code | `src/services/compact/autoCompact.ts` | 阈值检测 + 自动触发 |
| Claude Code | `src/services/compact/compact.ts` | 全量摘要 + PTL 重试 + 上下文恢复 |
| Claude Code | `src/services/compact/microCompact.ts` | 时间触发微压缩 + cached microcompact |
| agentscope | `src/agentscope/agent/_react_agent.py` | 压缩 config + 触发 |
| agentscope | `src/agentscope/memory/_working_memory/_base.py` | memory mark 系统 |
| tada-agent | `src/tada_agent/agents/memory/memory_manager.py` | ReMeLight 扩展 |
| tada-agent | `src/tada_agent/agents/hooks/memory_compaction.py` | pre-reasoning hook |
