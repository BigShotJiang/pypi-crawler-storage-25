# Tada-Core 架构深度分析

> 基于 `/Users/wayne/mywork/dev/maze/tada-core/tada_core/` 源码精读整理，
> 聚焦 `contracts/` 合约层 + `providers/` 实现层的设计。
> 对比参照：hermes-agent-core-analysis.md、pi-agent-core-analysis.md。

---

## 目录

1. [定位与分层](#1-定位与分层)
2. [ConversationRuntime：核心 runtime 接口](#2-conversationruntime核心-runtime-接口)
3. [contracts/ 合约层全景](#3-contracts-合约层全景)
4. [Event 系统：统一事件流](#4-event-系统统一事件流)
5. [HookRunner：pre/post 工具拦截](#5-hookrunner-prepost-工具拦截)
6. [CompactionStrategy：可插拔压缩接口](#6-compactionstrategy可插拔压缩接口)
7. [PermissionPolicy：独立权限层](#7-permissionpolicy独立权限层)
8. [SubagentSpec：一等 subagent 预算约束](#8-subagentspec一等-subagent-预算约束)
9. [providers/ 实现层全景](#9-providers-实现层全景)
10. [Tada-Core 的亮点总结](#10-tada-core-的亮点总结)
11. [Tada-Core 当前的不足与空白](#11-tada-core-当前的不足与空白)
12. [与 Pi/Hermes 三方对比表](#12-与-pihermes-三方对比表)

---

## 1. 定位与分层

```
tada_core/
├── contracts/       ← 合约层：接口定义 + Pydantic 数据模型（无副作用）
│   ├── runtime.py        ConversationRuntime ABC + AgentCore facade
│   ├── events.py         12 种统一事件类型
│   ├── hooks.py          HookRunner ABC + HookResult + HookEventKind
│   ├── compaction.py     CompactionStrategy ABC + 3 种内置实现
│   ├── permissions.py    PermissionPolicy ABC + AllowAll / DenyList
│   ├── subagent.py       SubagentSpec + SubagentContext
│   ├── tools.py          ToolExecutor ABC
│   ├── session.py        SessionState（messages + metadata）
│   ├── messages.py       Message 数据模型
│   └── model.py          ModelClient ABC
│
├── providers/       ← 实现层：把外部 runtime 适配进 ConversationRuntime
│   ├── tada_agent_base_runtime.py   TadaAgent-based 实现
│   ├── hermes_native/              Hermes AIAgent 原生包装
│   ├── clawcode/                   ClawCode（Claude Code）运行时包装
│   └── stub_runtime.py             测试用 stub
│
└── extensions/
    └── mcp_optional.py             MCP 可选扩展
```

**设计理念：** tada-core 是一个"provider 统一接入层"，不是 agent loop 本身。它定义了所有 provider 必须遵守的合约（Event 格式、Hook 时机、Permission 决策流程），而不替代任何现有 runtime 的具体循环逻辑。

---

## 2. ConversationRuntime：核心 runtime 接口

```python
# contracts/runtime.py
class ConversationRuntime(ABC):

    @abstractmethod
    async def run_turn(
        self,
        state: SessionState,
        user_text: str,
        *,
        abort: Any | None = None,
    ) -> AsyncIterator[Event]:
        """一个用户 Turn → 产出 Event 流（流式）"""

    @abstractmethod
    def set_permission_policy(self, policy: PermissionPolicy) -> None: ...

    @abstractmethod
    def set_hook_runner(self, runner: HookRunner) -> None: ...

    @abstractmethod
    def set_compaction_strategy(self, strategy: CompactionStrategy) -> None: ...

    @abstractmethod
    def set_tool_executor(self, executor: ToolExecutor) -> None: ...

    def register_subagent(self, spec: SubagentSpec) -> None:
        """默认抛出 NotImplementedError；不支持 subagent 的 provider 给出清晰错误"""
```

**设计亮点：**
- **AsyncIterator[Event]**：每个 Turn 以异步迭代器流式产出事件，消费方可实时处理（流式 UI 渲染、实时日志）
- **setter 注入**：permission / hook / compaction / tool 均通过 setter 注入，运行时可换策略，不需要重建 runtime
- **`register_subagent` 默认抛错**：不支持 subagent 的 provider 不会静默忽略，而是给出明确错误

**AgentCore facade：**

```python
class AgentCore:
    """门面：通过 ProviderRegistry 选 provider 并创建 runtime"""

    def create_runtime(self, provider_id: str, config: dict) -> ConversationRuntime:
        return self._registry.create_runtime(provider_id, config)
```

---

## 3. contracts/ 合约层全景

| 文件 | 核心类型 | 职责 |
|------|---------|------|
| `runtime.py` | `ConversationRuntime`, `AgentCore` | runtime 接口 + 门面 |
| `events.py` | `Event`（Union 12 种） | 统一事件流 |
| `hooks.py` | `HookRunner`, `HookResult`, `HookEventKind` | tool 前后拦截 |
| `compaction.py` | `CompactionStrategy`, `CompactionResult` | 压缩策略接口 |
| `permissions.py` | `PermissionPolicy`, `PermissionOutcome` | 权限决策接口 |
| `subagent.py` | `SubagentSpec`, `SubagentContext` | subagent 预算约束 |
| `tools.py` | `ToolExecutor` | 工具执行器接口 |
| `session.py` | `SessionState` | 对话状态（消息 + 元数据） |
| `messages.py` | `Message` | 消息数据模型 |
| `model.py` | `ModelClient` | LLM 客户端接口 |

---

## 4. Event 系统：统一事件流

`events.py` 定义了 12 种 Pydantic 强类型事件，全部以 `type` 字段作为 discriminator：

```python
Event = Annotated[
    Union[
        TextDelta,          # 流式助手文本
        ToolUseRequest,     # LLM 请求工具调用
        ToolResultEvent,    # 工具执行结果
        UsageEvent,         # token 用量
        MessageStop,        # 一条 assistant 消息结束
        PermissionEvent,    # 权限决策（allow/deny + reason）
        HookEvent,          # hook 介入通知
        CompactionEvent,    # 压缩发生通知（strategy + removed_count + summary）
        SubagentStarted,    # subagent 启动包裹
        SubagentFinished,   # subagent 结束包裹（ok 字段）
        ErrorEvent,         # provider 级别错误（message + code）
        UnsupportedEvent,   # 能力不支持（feature + detail）
    ],
    Field(discriminator="type"),
]
```

**设计亮点：**

**① 可观测性一等公民**：`CompactionEvent` 和 `HookEvent` 让上层消费者可以知道"何时发生了压缩"、"何时 hook 介入了执行"，而不是靠日志猜测。

**② 显式 capability 降级**：`UnsupportedEvent` 是 tada-core 独有的设计。当 provider 不支持某个特性（如 subagent、streaming），不静默跳过，而是在事件流中发出 `UnsupportedEvent`，消费方可以决定是报错还是降级。

**③ Subagent 边界标记**：`SubagentStarted/SubagentFinished` 包裹 subagent 的所有事件，消费方可以准确切分父/子 agent 的事件序列。

**④ PermissionEvent 前置**：合约规定 `permission` 事件必须在 tool 执行前出现，这让 UI 可以在工具执行前展示"准备调用：xxx"并等待用户确认。

---

## 5. HookRunner：pre/post 工具拦截

```python
# contracts/hooks.py

class HookEventKind(str, Enum):
    PRE_TOOL_USE     = "PreToolUse"
    POST_TOOL_USE    = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"
    PRE_LLM_CALL     = "PreLLMCall"
    ON_SESSION_START = "OnSessionStart"

@dataclass
class HookResult:
    denied: bool = False
    failed: bool = False
    cancelled: bool = False
    messages: list[str] = field(default_factory=list)
    permission_override: Any | None = None
    permission_reason: str | None = None
    updated_input: str | None = None   # 替换工具输入（input rewriting）

class HookRunner(ABC):
    def run_pre_tool_use(self, tool_name: str, input_json: str) -> HookResult: ...
    def run_post_tool_use(self, ..., is_error: bool) -> HookResult: ...
    def run_post_tool_use_failure(self, ...) -> HookResult: ...
```

**设计亮点：**

**① HookResult 携带行为指令**：`denied/failed/cancelled` 直接指示 runtime 停止执行，`updated_input` 允许 hook 在工具执行前重写输入（例如脱敏、增强）。

**② PermissionPolicy 与 HookRunner 职责分离**：Hook 做变换和观测，Permission 做授权决策，两者独立可测试。

**③ NoOpHookRunner / FunctionHookRunner**：提供了 NoOp 默认实现（无需配置），以及 `FunctionHookRunner` 允许直接传入 Python callable，类似 hermes 的风格。

**当前不足：**
- 所有方法是同步的（`run_pre_tool_use → HookResult`），无法 await，不支持"等待用户 approve"这类 async hook 场景
- 只有 5 种 HookEventKind，缺少：
  - `CONTEXT`（每次 LLM call 前修改 messages 列表）
  - `BEFORE_AGENT_START`（每次 user prompt 前注入系统指令）
  - `TOOL_RESULT`（工具执行后修改输出，如脱敏）
  - Session 生命周期 hook（start/end/compact 前后）

---

## 6. CompactionStrategy：可插拔压缩接口

```python
# contracts/compaction.py
class CompactionStrategy(ABC):
    def should_compact(self, state: SessionState, *, trigger: str) -> bool: ...
    def compact(self, state: SessionState, *, trigger: str) -> CompactionResult: ...

class CompactionResult(BaseModel):
    removed_message_count: int = 0
    summary: str | None = None
    new_messages: list | None = None   # 可选：替换尾部消息
    trigger: str | None = None
```

**三种内置实现：**

| 实现 | 触发条件 | 方法 |
|------|---------|------|
| `NeverCompact` | 永不触发 | 禁用 |
| `TruncateCompaction` | `len(messages) > max_messages` | 截断（丢弃旧消息） |
| `SummarizeCompaction` | 字符 token 估算 > threshold_tokens | **Placeholder**（最小截断 + `[compacted]` 标记） |

**设计亮点：**
- `CompactionResult.new_messages` 允许 provider 在压缩后不仅删除消息，还可以注入摘要消息（替换旧消息尾部）
- `trigger` 字段区分触发来源（`"auto"`/`"overflow"`/`"manual"`），`CompactionEvent` 将此信息传给消费方

**当前不足：**
- `compact()` 是同步方法，无法做 LLM 摘要（需要 await）；`SummarizeCompaction` 是 placeholder，没有实际 LLM 调用
- 没有 `previous_summary` 参数（hermes 的迭代摘要更新），每次压缩独立，超长对话摘要质量递减
- 没有 `protect_last_n` 语义（保护最近 N 条消息不被压缩）
- 缺乏两级机制：截断（低成本）在前，LLM 摘要（高成本）在后

---

## 7. PermissionPolicy：独立权限层

```python
# contracts/permissions.py
class PermissionPolicy(ABC):
    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome:  # ALLOW | DENY
```

**设计亮点：**

**① 与 Hook 完全分离**：HookRunner 的 `permission_override` 字段可以传入 `PermissionContext`，形成 Hook → Permission 的信息流，但 PermissionPolicy 不依赖 HookRunner。

**② PermissionPrompter 协议**：声明了交互式确认的接口（`prompt(tool_name, tool_input) → PermissionOutcome`），测试可 mock，UI 层可注入真实的用户弹窗。

**③ 两种内置实现**：`AllowAllPolicy`（测试用）+ `DenyListPolicy`（配置化黑名单）。

---

## 8. SubagentSpec：一等 subagent 预算约束

```python
# contracts/subagent.py
@dataclass
class SubagentSpec:
    tool_name: str          # 注册为哪个工具名
    provider_id: str        # 子 runtime 的 provider
    max_iterations: int = 8
    max_depth: int = 1
    allowed_tools: list[str] | None = None  # None = 继承父 agent 所有工具
    extra: dict[str, Any] = field(default_factory=dict)

@dataclass
class SubagentContext:
    parent_session_id: str | None
    depth: int
    budget_iterations: int
    allowed_tools: list[str] | None = None
```

**相比 pi 和 hermes 的优势：**

| 维度 | Pi-agent-core | Hermes | Tada-Core |
|------|--------------|--------|-----------|
| subagent 启动 | 工具实现自行 spawn | 工具实现自行创建 AIAgent | `SubagentSpec` 框架注册 |
| 预算约束 | 无（工具自管） | `IterationBudget` 跨 agent 共享对象 | `max_iterations`/`max_depth` 框架级声明 |
| 工具继承 | 无控制 | 无控制 | `allowed_tools` 显式声明 |
| 深度追踪 | 无 | `_delegate_depth` int | `SubagentContext.depth` |
| 可观测 | 子 agent 独立 EventStream | 无 | `SubagentStarted/Finished` 包裹父 EventStream |

---

## 9. providers/ 实现层全景

| Provider | 文件 | 说明 |
|----------|------|------|
| `tada_agent_base` | `tada_agent_base_runtime.py` | 包装 TadaAgent（agentscope.ReActAgent） |
| `hermes_native` | `hermes_native/runtime.py` | 包装 Hermes AIAgent（原生 loop） |
| `clawcode` | `clawcode/runtime.py` | 包装 ClawCode（Claude Code SDK） |
| `stub` | `stub_runtime.py` | 测试 stub |

**tada_agent_base_adapter 的适配模式：**

```
TadaAgent.reply(msg)         ← agentscope ReActAgent 接口
     ↕ 适配
ConversationRuntime.run_turn()  ← tada-core 标准接口
     ↓
AsyncIterator[Event]         ← tada-core 事件流
```

适配器把 agentscope 的 `Msg.content` 消息流转换为 tada-core 的 `Event`（TextDelta / ToolUseRequest / ToolResultEvent）。

---

## 10. Tada-Core 的亮点总结

**① 合约层完整性**：`contracts/` 是所有 provider 共享的类型系统，Pydantic 强类型保证跨 provider 一致性。

**② 显式 Capability 降级（UnsupportedEvent）**：任何 provider 不支持的特性都通过 `UnsupportedEvent` 在事件流中显式通知，不静默忽略。

**③ Permission 与 Hook 职责分离**：permission 做授权决策，hook 做变换观测，两者可独立测试和替换，优于 hermes 的"hook 返回 block=True"混合模式。

**④ SubagentSpec 一等框架支持**：subagent 的预算约束（max_iterations/max_depth/allowed_tools）是框架级约束，不需要每个工具实现自己管，比 pi/hermes 更安全。

**⑤ CompactionEvent 可观测**：压缩发生时发出带 strategy/summary 的事件，上层消费方（UI、监控）可以清晰地感知。

---

## 11. Tada-Core 当前的不足与空白

### 11.1 HookRunner 覆盖不足

当前 5 种 `HookEventKind` 相比 pi 的 22 个 hook 差距较大：

| 缺失的 Hook | 对应 Pi Hook | 影响 |
|-----------|-------------|------|
| `CONTEXT`（每次 LLM call 前修改 messages） | `context` | 无法在不修改 runtime 的情况下注入/过滤 messages |
| `BEFORE_AGENT_START`（每次 user prompt 前） | `before_agent_start` | 无法每次 prompt 注入全局指令 |
| `TOOL_RESULT`（工具执行后修改输出） | `tool_result` | 无法脱敏或增强工具输出 |
| Session 生命周期（start/end/compact） | `session_start/end/compact` | 无法在 session 边界执行清理/初始化 |
| `INPUT`（用户输入拦截） | `input` | 无法处理斜线命令等输入转换 |

**更严重的问题：所有 hook 方法是同步的**（`→ HookResult`，不是 `async → HookResult`），导致：
- 无法 await 用户 approve（pi 的关键能力）
- 无法在 hook 中做异步 LLM 调用（如工具输出摘要）

### 11.2 CompactionStrategy 是 Placeholder

- `SummarizeCompaction.compact()` 只做最小截断 + `[compacted]` 字符串，没有 LLM 调用
- 同步方法签名：`compact(state) → CompactionResult` 无法做 async LLM 摘要
- 缺少 `previous_summary` 参数（hermes 的迭代摘要更新能力）
- 没有两级机制（截断 + LLM 摘要）

### 11.3 Session 持久化无参考实现

- `SessionState` 只是一个数据模型，没有 append-only 存储实现
- 缺少 pi 的树结构 session（分支/compaction entry）
- 缺少 hermes 的 SQLite + FTS5 实现
- 接入方需要自己造轮子

### 11.4 Model Routing 和 Credential Pool 无抽象

- 没有廉价/强力模型路由接口（hermes 的 `smart_model_routing`）
- 没有多凭证故障转移抽象（hermes 的 `credential_pool`）
- 这些通常是 provider 内部实现，但 contracts 层没有预留扩展点

### 11.5 Prompt Caching 无统一接口

- hermes 有 `prompt_caching.py` 负责注入 `cache_control`，保证 system prompt 跨轮次不变（字节级一致）
- tada-core 没有对应的抽象，各 provider 自行处理（或不处理）

---

## 12. 与 Pi/Hermes 三方对比表

| 维度 | Pi-agent-core + pi-coding-agent | Hermes agent/ | Tada-Core contracts |
|------|-------------------------------|---------------|---------------------|
| **语言** | TypeScript | Python | Python |
| **定位** | 有状态 runtime（循环本身） | 无状态工具库（循环在应用层） | provider 统一接入合约（无循环） |
| **事件流** | EventStream（11 种，只读） | 无 | **AsyncIterator[Event]（12 种，含 PermissionEvent/SubagentStarted/UnsupportedEvent）** |
| **Hook 系统** | 22 个 hook，async，有返回值 | 无 hook（硬编码调用点） | 5 种 HookEventKind，**同步**，HookResult |
| **Permission 层** | Hook 返回 `block` | 无独立层 | **独立 PermissionPolicy，与 Hook 分离** |
| **Context 压缩** | Level1 截断 + Level2 LLM 摘要 | LLM 摘要（迭代更新） | 接口完整，**实现是 Placeholder** |
| **Subagent** | 工具自行 spawn，无预算 | 工具自行 spawn，IterationBudget 共享 | **SubagentSpec + max_depth/max_iterations 框架级约束** |
| **Session 持久化** | Append-only 树，内置 | SQLite + FTS5，内置 | 无参考实现（外置） |
| **Capability 声明** | 无 | 无 | **UnsupportedEvent + ProviderMetadata 显式矩阵** |
| **Prompt Caching** | 无 | system_and_3 策略 + SQLite 快照 | 无 |
| **错误治理** | 分散在 core 内 | 集中 ClassifiedError + FailoverReason | 无（provider 自管） |
| **Credential Pool** | 无 | PooledCredential + 4 种选择策略 | 无 |
| **Model Routing** | 无 | 廉价/强力模型路由启发式 | 无 |

---

*文档更新时间：2026-04-28*
*源码版本：tada-core @ /Users/wayne/mywork/dev/maze/tada-core*
