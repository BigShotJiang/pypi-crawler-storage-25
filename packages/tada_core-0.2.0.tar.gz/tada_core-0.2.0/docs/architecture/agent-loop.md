# tada-core 的 Agent Loop 架构与上层使用方式

> 状态说明：这篇是 agent loop 分层背景文档，包含 provider registry、capability matrix、subagent envelope 等 Phase 2/历史设计语境。当前 v0.1 实现以 [`overview.md`](overview.md)、[`runtime-lifecycle.md`](runtime-lifecycle.md) 和 `tada_core/loop/runner.py` 为准：核心入口是 `AgentLoop.run_turn()`，模型接入边界是 `ModelClient`。

这篇文档回答一个核心问题：

> 当我们说 `tada-core` 在设计 agent loop 时，到底在设计什么；它定义了哪些协议 / 结构；而上层 agent 框架或应用层又应该如何使用这些协议 / 结构。

如果你只看 OpenAI / Anthropic 的官方模型 API，很容易把 `messages`、`tool_calls`、`tool_use`、`tool_result`、`thinking` 误以为就是“agent 协议本身”。这当然不完全错，但也远远不够。

这些模型原生结构，解决的是 **LLM 如何表达意图**；而 `tada-core` 解决的是 **宿主如何稳定地运行、观测、持久化和消费一轮 agent turn**。

## 1. 核心结论

先给出一个简短结论：

1. OpenAI / Anthropic 的模型协议定义了“模型如何输出”
2. `tada-core` 定义了“宿主如何统一地理解一次 agent loop”
3. 上层 agent 框架 / 应用层还需要补充 checkpoint、审批、任务状态、产品交互等业务结构

也就是说：

- **模型协议不等于 agent 系统**
- **`tada-core` 也不等于完整工作流引擎**
- **`tada-core` 的职责，是提供一层稳定的 runtime contracts**

## 2. 什么是 `tada-core` 里的 agent loop

在最原始的意义上，一个 agent loop 看起来像这样：

1. 宿主把用户输入和历史上下文发给模型
2. 模型输出文本，或请求调用工具
3. 如果请求工具，宿主执行工具
4. 工具结果再喂回模型
5. 重复，直到本轮结束

这套最小闭环可以跑通 demo，但无法直接回答下面这些系统级问题：

- 这轮 turn 的标准输入输出边界是什么
- 不同 provider 如何暴露一致语义
- 工具调用前后如何插入 hook 和 permission
- 子代理如何进入同一条事件链
- 会话状态如何稳定持久化
- 哪些能力可以依赖，哪些只能降级处理

`tada-core` 的 agent loop 设计，本质上是在回答这些问题。

## 3. `tada-core` 的分层视角

理解 `tada-core`，最重要的是先区分 3 层协议：

```mermaid
flowchart TD
    model["Model API Protocol"]
    provider["Provider / Adapter Layer"]
    core["tada-core Runtime Contracts"]
    host["Host / Agent Framework / App"]

    model --> provider
    provider --> core
    core --> host
```

### 3.1 模型原生协议层

这一层由模型厂商定义，例如：

- OpenAI Chat Completions / Responses 的 `messages`、`tool_calls`、`role="tool"`
- Anthropic Messages 的 `content blocks`、`tool_use`、`tool_result`、`thinking`

这一层解决的是：

- 模型如何表达工具调用意图
- 工具结果如何回填给模型
- 某些模型如何表达 reasoning / thinking

但这一层并不直接解决：

- human-in-the-loop 的暂停与恢复
- hook / guardrail / policy
- 子代理编排
- checkpoint
- 产品态 UI 状态机

### 3.2 provider / adapter 层

这一层把不同模型协议翻译成统一 runtime 语义。

在 `tada-core` 中，典型载体包括：

- `ApiRequest`
- `AssistantEvent`
- 各 provider 的 model client / runtime 桥接逻辑

这一层是必要的，因为 OpenAI、Anthropic、Hermes 生态都不会天然对齐。

但要明确：

- 这层是内部适配层
- 宿主不应把它当作长期稳定公共协议
- `Hermes` 属于 provider / runtime 层，不是模型协议层；旧的外部 hermes-agent 兼容路径是 `hermes_bridge`

### 3.3 `tada-core` 公共 runtime 协议层

这是 `tada-core` 最重要的部分，也是宿主真正应该依赖的层：

- `ConversationRuntime.run_turn()`
- `Event`
- `SessionState`
- `ConversationMessage`
- `ContentBlock`
- `MessageRole`

这一层的目标是：

- 把 provider 差异收敛成统一 contracts
- 把一轮 turn 的运行时过程变得可观测
- 让宿主面向稳定接口接入，而不是面向底层模型 payload 接入

## 4. `tada-core` 里的核心协议 / 结构

### 4.1 `ConversationRuntime.run_turn()`

`run_turn()` 是一轮 agent loop 的核心入口。

它定义了：

- 输入：`SessionState` + `user_text`
- 输出：`AsyncIterator[Event]`
- 副作用：原地更新 `SessionState`

这意味着 `tada-core` 从一开始就把“流式事件”当成一等公民，而不是把所有过程折叠成一个最终结果对象。

### 4.2 `Event`

`Event` 是宿主消费运行时过程的统一协议。

当前公共事件包括：

- `text_delta`
- `tool_use`
- `tool_result`
- `usage`
- `message_stop`
- `permission`
- `hook`
- `compaction`
- `subagent_started`
- `subagent_finished`
- `error`
- `unsupported`

这说明 `tada-core` 的 agent loop 不只是“文本 + 工具”，而是一条带治理、观测和能力边界的标准事件链。

### 4.3 `SessionState`

`SessionState` 是宿主与 runtime 之间最重要的状态对象。

它的顶层字段只有 3 个：

- `messages`
- `usage`
- `metadata`

这个设计刻意保持克制。原因是：

- provider 不应该随意扩张顶层结构
- 宿主需要一个稳定、可序列化、可迁移的状态模型
- 业务方可以在外部再包自己的任务状态，但不应破坏 core state 的统一性

### 4.4 `ConversationMessage` / `ContentBlock`

这是 `tada-core` 的统一 transcript 语言。

它不是某一家模型原始消息格式的镜像，而是一个归一化后的消息层：

- `text`
- `tool_use`
- `tool_result`
- 其他 provider 扩展内容放进 `extra`

这使得宿主可以基于统一 block 结构做：

- 消息展示
- 回放
- 调试面板
- 会话持久化

### 4.5 `Capabilities`

`tada-core` 不假装所有 provider 都完全等价，而是要求 provider 明确声明能力矩阵。

这很关键，因为 agent loop 的很多能力是可选的：

- hooks
- compaction
- subagent
- mcp

宿主接入时应遵循一条简单规则：

> 先看 `Capabilities`，再启用功能。

## 5. `tada-core` 如何把 agent loop 组织成一条运行时链路

从宿主视角看，一次较完整的 turn 可以理解为：

```mermaid
flowchart TD
    user["user_text + SessionState"] --> runtime["run_turn()"]
    runtime --> model["provider 推理循环"]
    model --> text["text_delta / usage / message_stop"]
    model --> tool["tool_use"]
    tool --> hook["hook"]
    hook --> permission["permission"]
    permission --> execute["tool execute or subagent"]
    execute --> result["tool_result"]
    result --> compact["optional compaction"]
    compact --> updated["updated SessionState"]
```

这条链路背后包含了几个重要设计判断。

### 5.1 工具调用不是孤立动作

工具调用前后不只是“模型要调工具 -> 系统执行一下”。

中间可能还要经过：

- pre hook
- permission policy
- failure hook
- tool result normalization

所以 `tool_use` 和 `tool_result` 之间，本来就需要一套 runtime 级控制链。

### 5.2 `subagent` 不是隐藏的第二套系统

在 `tada-core` 里，subagent 被建模成“特殊工具调用”，不是一套平行的神秘执行机制。

这样做的收益是：

- delegation 进入同一条事件流
- 父子关系可观测
- 宿主不需要再学习一套独立的 subagent 协议

### 5.3 compaction 是 runtime 机制，不是 provider 私有优化

上下文压缩会改变：

- 模型可见上下文
- `SessionState`
- 会话回放和调试体验

所以它必须进入 contract 范围，而不是被藏在 provider 内部。

## 6. 模型协议解决了什么，没解决什么

### 6.1 模型协议已经解决的部分

模型原生协议通常已经能表达：

- 多轮上下文
- 工具调用请求
- 工具结果回填
- 文本输出
- 某些模型的 thinking / reasoning

因此它足以支撑一个原始的 tool loop demo。

### 6.2 模型协议没有直接解决的部分

但如果你要做真正可用的 agent 系统，至少还需要额外解决下面这些问题。

#### Human-in-the-loop

模型可以“建议请求用户确认”，但它不会天然定义：

- 什么时候暂停
- 谁来批准
- 拒绝后怎么恢复
- 用户回来后从哪继续

#### Guardrails / Hooks / Policy

模型不会天然表达：

- 工具输入是否要改写
- 某次调用是否要拦截
- 哪些结果要审计
- 哪些输出要脱敏

#### Checkpoint / Resume

模型协议通常不定义：

- 长任务的中断恢复
- crash recovery
- 某一步单独重试
- 从哪个状态点 resume

#### 多代理编排

模型不会替你定义：

- 子代理预算
- delegation 深度
- 父子关系追踪
- 子代理结果折叠方式

换句话说：

> 模型协议负责表达；runtime 负责控制；上层应用负责业务编排与体验设计。

## 7. 上层 agent 框架 / 应用层应该如何使用 `tada-core`

### 7.1 把 `Event` 当成主运行时协议

上层不应该直接围绕 OpenAI / Anthropic 原始 payload 写主逻辑，而应该围绕 `Event` 设计：

- 流式文本：看 `text_delta`
- 工具时间线：看 `tool_use` / `tool_result`
- 审批：看 `permission`
- 运行治理：看 `hook`
- 压缩行为：看 `compaction`
- 子代理：看 `subagent_started` / `subagent_finished`
- 故障与降级：看 `error` / `unsupported`

这样做的好处是，宿主的日志、前端、回放、审计逻辑都不需要与特定模型协议强耦合。

### 7.2 把 `SessionState` 当成 runtime 主状态

建议把 `SessionState` 作为 agent loop 的主状态层：

- 保存 transcript
- 保存 usage
- 保存 provider / 宿主扩展 metadata

但业务系统通常还需要一层额外状态，例如：

- `task_id`
- `approval_id`
- `checkpoint_id`
- `ui_status`
- `workflow_step`

推荐做法是：

- `SessionState` 管 runtime state
- 应用自己的数据库模型管 business state
- 两者通过 `session_id` / trace id 关联

### 7.3 把 checkpoint 设计在 `tada-core` 之上

当前 `tada-core` 提供的是稳定 runtime state 与事件语义，但不试图内置完整 workflow engine。

如果上层要做 human-in-the-loop 或长任务恢复，建议在 `SessionState` 之上显式维护 checkpoint，例如：

- 当前等待什么动作
- 对应哪个 `tool_use_id`
- 当前是否可 resume
- 上次稳定保存的 `SessionState` 快照

不要把这些职责完全寄希望于 prompt 和记忆拼接。

### 7.4 把面向用户的体验状态和底层协议状态分开

上层 UI 最好再有一层面向体验的状态模型，例如：

- `idle`
- `generating`
- `running_tool`
- `waiting_approval`
- `paused`
- `failed`
- `completed`

这些状态通常不是底层模型原生字段，而是从 `Event` 流里推导出来的。

这样做能避免两个问题：

1. 直接把底层 payload 泄露给产品层
2. 让 UI 状态跟着某一家 provider 的细节摇摆

### 7.5 先使用稳定 contracts，再考虑 workflow engine

如果上层未来要接入：

- LangGraph
- Temporal
- 自己的任务图 / DAG / scheduler

更稳妥的方式也不是绕开 `tada-core`，而是：

- 让这些工作流系统编排 turn
- 让 `tada-core` 提供每个 turn 的稳定 runtime contract
- 用工作流系统管理跨 turn 的 checkpoint、审批流和长任务

这样分层更清楚：

- `tada-core` 管一轮 turn 的统一语义
- workflow / app 层管跨轮次、跨任务的控制流

## 8. 对上层设计的一组具体建议

如果你要在 `tada-core` 之上做 agent 框架或应用，建议遵循下面这组规则。

### 建议 1：不要把模型原始 payload 暴露成产品主协议

模型原始 payload 可以用于：

- provider 内部适配
- 调试
- 兼容性排查

但不适合做：

- UI 主数据协议
- 审计主协议
- 会话持久化主协议

### 建议 2：不要把审批流建立在“模型说了一句请确认”之上

审批应该建立在显式运行时语义上，例如：

- `tool_use`
- `permission`
- `tool_result`
- 应用层自己的 approval record

而不是靠自然语言猜测“这里是不是该弹窗”。

### 建议 3：不要把 checkpoint 混进 `metadata` 大对象里

`metadata` 适合轻量扩展，不适合承载复杂工作流状态。

更合理的做法是：

- `SessionState` 保持轻量、稳定、可迁移
- checkpoint / workflow state 进入应用自己的持久化模型

### 建议 4：把 subagent 当成 delegation 能力，不要重造第二套代理协议

如果上层需要 planner / executor / reviewer / researcher 这类结构，优先复用 `SubagentSpec` 和现有事件链，而不是重新定义一套“agent message protocol”。

### 建议 5：把 `unsupported` 当成正式信号处理

如果某个 provider 不支持 hooks / subagent / compaction，不应 silent drop。

上层应该：

- 记录 `unsupported`
- 做清晰降级
- 在 UI 或日志里让行为差异可见

## 9. 一个推荐的上层分层方式

对于一个完整 agent 产品，可以参考下面这个职责划分：

### 模型层

负责：

- 生成文本
- 请求调用工具
- 输出 reasoning / thinking

### `tada-core` provider / runtime 层

负责：

- 适配不同模型协议
- 归一化消息与事件
- 暴露统一 turn contracts
- 管理工具、permission、hook、subagent、compaction 接入点

### agent framework / 应用 orchestration 层

负责：

- checkpoint
- human-in-the-loop
- workflow / DAG / scheduler
- retry / timeout / task policy
- 业务任务状态

### 产品体验层

负责：

- 消息展示
- 调试 timeline
- 审批界面
- stop / retry / continue
- 审计与回放入口

这种分层方式有一个很现实的好处：

> 上层可以持续演进工作流和产品体验，而不用反复重写底层 runtime 接入。

## 10. 一句话总结

`tada-core` 在 agent loop 中提供的，不是某家模型协议的简单透传，也不是完整应用框架，而是：

> 一层稳定、可观测、可持久化、可扩展的 runtime contracts，让上层 agent 框架和应用层能够把 human-in-the-loop、checkpoint、workflow 和产品体验建立在统一协议之上，而不是建立在底层模型原始 payload 之上。

## 11. 建议继续阅读

- 协议分层：[`../reference/protocols.md`](../reference/protocols.md)
- turn 生命周期：[`runtime-lifecycle.md`](runtime-lifecycle.md)
- 事件流：[`../reference/events.md`](../reference/events.md)
- 会话状态：[`../reference/session-state.md`](../reference/session-state.md)
- tools / hooks / subagent：[`../reference/mechanisms.md`](../reference/mechanisms.md)
- 宿主接入主线：[`../integration/human-guide.md`](../integration/human-guide.md)
