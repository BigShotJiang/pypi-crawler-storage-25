# Model Client Reference

`tada-core` is a multi-protocol agent runtime SDK. Model access is supplied by a `ModelClient`, usually constructed from a lightweight `ModelSpec` and the built-in adapter registry.

Routing, fallback, quota, billing, and OAuth stay outside `tada-core` — typically in `token-router` or the host application.

## ModelSpec + Adapter Registry

`ModelSpec` describes model identity and protocol capabilities. It is **not** a full provider catalog and does not carry price or routing priority.

```python
from tada_core import ModelSpec, build_model_client

spec = ModelSpec(
    id="claude-sonnet-4-6",
    provider="anthropic",
    api="anthropic-messages",
    base_url="http://localhost:8787",
    input=["text", "image", "file"],
    reasoning=True,
    cache_retention="short",  # stored in compat when needed
)
client = build_model_client(spec, api_key="...", streaming=True)
loop = AgentLoop(client)
```

Built-in `api` values:

| api | Client | Use when |
|-----|--------|----------|
| `anthropic-messages` | `AnthropicModelClient` | Anthropic Messages API or Anthropic-compatible proxies (`POST /v1/messages`) |
| `openai-responses` | `OpenAIResponsesModelClient` | OpenAI Responses API, modern reasoning/tool/image path |
| `openai-completions` | `OpenAICompletionsModelClient` | OpenAI Chat Completions and OpenAI-compatible providers (Groq, xAI, Mistral, OpenRouter, LiteLLM, Ollama, etc.) |
| `google-generative-ai` | `GoogleGenerativeAIModelClient` | Google Gemini Generative Language API |
| `bedrock-converse-stream` | `BedrockConverseModelClient` | AWS Bedrock Converse / ConverseStream |

Register a custom adapter:

```python
from tada_core.providers.registry import register_model_adapter

register_model_adapter("my-api", my_client_factory)
```

Direct construction remains supported for backward compatibility:

```python
from tada_core import AnthropicModelClient

AnthropicModelClient(api_key="...", model="claude-sonnet-4-6")
```

## AnthropicModelClient

Use `AnthropicModelClient` (or `ModelSpec(api="anthropic-messages")`) for any endpoint that speaks Anthropic Messages API:

```python
from tada_core import AgentLoop, AnthropicModelClient, SessionState

loop = AgentLoop(
    AnthropicModelClient(
        api_key="...",
        model="claude-sonnet-4-6",
        base_url="http://localhost:8787",
        streaming=True,
        max_tokens=8192,
        cache_retention="short",
    )
)
state = SessionState()
```

Compatible endpoint examples:

- Anthropic direct: `https://api.anthropic.com`
- token-router Anthropic route
- LiteLLM in Anthropic-compatible mode
- other proxies that preserve Anthropic message, tool, stream, and usage shapes

The adapter translates:

- `ContentBlock(type="thinking")` ↔ Anthropic thinking blocks
- multimodal user/tool result blocks ↔ Anthropic image/document blocks
- provider `stop_reason` ↔ unified `StopReason` on `MessageStop`

## Cache Control

Anthropic prompt caching requires client-side `cache_control` markers. The Anthropic adapter owns this because it serializes `ConversationMessage` into Anthropic wire format.

`cache_retention` values:

| Value | Behavior |
|-------|----------|
| `none` | Emit no `cache_control` markers |
| `short` | Emit block-level `{ "type": "ephemeral" }` markers |
| `long` | Emit `ttl="1h"` only for `api.anthropic.com`; proxies fall back to `short` |

The client uses up to four breakpoints:

1. system prompt
2. tools schema
3. previous user turn
4. current user turn

Markers are attached to content blocks, not sent as a top-level SDK parameter.

## OpenAI Adapters

### OpenAI Responses (`openai-responses`)

Preferred for OpenAI-native reasoning, tools, and image input when the endpoint exposes the Responses API.

```python
from tada_core import ModelSpec, build_model_client

spec = ModelSpec(
    id="gpt-4.1",
    provider="openai",
    api="openai-responses",
    base_url="https://api.openai.com",
)
client = build_model_client(spec, api_key="...", streaming=True)
```

### OpenAI Completions (`openai-completions`)

Use for Chat Completions and OpenAI-compatible gateways. `OpenAICompatibleModelClient` is a backward-compatible alias for `OpenAICompletionsModelClient`.

```python
from tada_core.loop.model_client import OpenAICompatibleModelClient, make_echo_transport

client = OpenAICompatibleModelClient(make_echo_transport(), streaming=True)
loop = AgentLoop(client)
```

Use `ModelSpec.compat` for provider-specific toggles instead of hardcoding per-vendor clients.

## Google Gemini (`google-generative-ai`)

Gemini support covers text, base64 image input, function calls, and usage parsing through the same `ConversationMessage` / `AssistantEvent` contract.

```python
from tada_core import ModelSpec, build_model_client

spec = ModelSpec(
    id="gemini-2.5-pro",
    provider="google",
    api="google-generative-ai",
    input=["text", "image"],
)
client = build_model_client(spec, api_key="...", streaming=True)
```

OAuth, Vertex project selection, and quota policy remain host concerns. Use `ModelSpec.headers` / `compat` or a custom transport for non-API-key deployments.

## AWS Bedrock (`bedrock-converse-stream`)

Bedrock support covers Converse message/tool serialization and response/stream parsing. The default factory uses `boto3` if available; hosts can also inject a `transport` for tests or custom AWS auth.

```python
from tada_core import ModelSpec, build_model_client

spec = ModelSpec(
    id="anthropic.claude-3-5-sonnet-20241022-v2:0",
    provider="bedrock",
    api="bedrock-converse-stream",
    compat={"boto3": {"region_name": "us-east-1"}},
)
client = build_model_client(spec, streaming=True)
```

Prompt caching is supported through Bedrock Converse `cachePoint` blocks. This is Bedrock's equivalent checkpoint mechanism, not Anthropic's raw `cache_control` field.

```python
client = build_model_client(spec, streaming=True, cache_retention="long")
```

`cache_retention` values:

| Value | Behavior |
|-------|----------|
| `none` | Emit no `cachePoint` blocks |
| `short` | Emit `{ "cachePoint": { "type": "default" } }` |
| `long` | Emit `{ "cachePoint": { "type": "default", "ttl": "1h" } }` |

The Bedrock adapter places cache points after the system prompt, after tool definitions, and after the two most recent user messages. Bedrock cache usage is mapped into `TokenUsage.cache_read_tokens` and `TokenUsage.cache_creation_tokens`.

AWS account setup, IAM, regional routing, and Bedrock pricing stay outside `tada-core`.

## Runtime Budgets

`BudgetLimits` controls runtime spend in provider-neutral units: token counts, iterations, and tool calls. It is not a price catalog and does not estimate cost by itself.

```python
from tada_core import BudgetLimits

loop.set_budget_policy(BudgetLimits(max_total_tokens=100_000, max_tool_calls=20))
```

If a host wants cost caps, it should convert provider usage into cost externally and enforce that policy at the host or token-router layer.

## Custom ModelClient

Implement `ModelClient.stream(request: ApiRequest) -> AsyncIterator[AssistantEvent]` when you need a custom transport, or register a factory with `register_model_adapter`.

Keep provider-specific details behind the adapter. The rest of `tada-core` should continue to see only:

- normalized `ConversationMessage`
- normalized `AssistantEvent`
- normalized `TokenUsage`

See [`../integration/custom-provider.md`](../integration/custom-provider.md) for the full adapter pattern.
