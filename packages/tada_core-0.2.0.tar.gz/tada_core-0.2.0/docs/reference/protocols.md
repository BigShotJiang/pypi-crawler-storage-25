# 协议分层参考

这篇文档只回答一个问题：**当你在 `tada-core` 里看到 `tool_use`、`tool_result`、`thinking`、`ContentBlock`、`Event` 这些词时，它们分别属于哪一层协议。**

如果不先把层级拆开，很容易把模型 API、provider 内部适配、`tada-core` 公共 contract 混写在一起，最后导致：

- 把 `Hermes` 误写成模型协议
- 把模型原生字段误当成宿主稳定接口
- 把展示约定误写成 runtime 协议

## 1. 范围与边界

这篇文档只讨论 `tada-core` 自己的协议边界：

- `tada-core` 的公共 runtime contracts
- `tada-core` model client / adapter 层的内部翻译
- OpenAI / Anthropic 官方模型协议里已经存在的原生结构

它**不**讨论上层产品壳、UI 展示协议，也不把其他仓库当成这篇文档的定义来源。

## 2. 三层协议模型

```mermaid
flowchart LR
    ModelApi["ModelApiProtocol"] --> Adapter["ProviderAdapterLayer"]
    Adapter --> Runtime["tadaCoreRuntimeContracts"]
    Runtime --> Host["HostApp"]
```

### 第 1 层：模型原生协议层

这一层是模型厂商自己定义的请求 / 响应格式，例如：

- OpenAI Chat Completions / Responses 的 `messages`、`tool_calls`、`role="tool"`
- Anthropic Messages 的 `content` blocks、`tool_use`、`tool_result`、`thinking`

这一层的特点是：

- 结构由模型 API 定义
- 字段名和载体由厂商决定
- 不同厂商之间不保证同名同义

### 第 2 层：ModelClient / adapter 协议层

这一层是 `tada-core` 内部为了桥接不同模型协议而使用的适配层。它的职责不是对宿主暴露稳定接口，而是把不同模型返回形态翻译成统一 runtime 语义。

当前最典型的载体包括：

- `tada_core/contracts/model.py` 里的 `ApiRequest`、`AssistantEvent`
- `tada_core/contracts/models.py` 里的 `ModelSpec`
- `tada_core/providers/registry.py` 里的 adapter registry
- `tada_core/providers/anthropic.py` 里的 `AnthropicModelClient`
- `tada_core/providers/openai_completions.py` / `openai_responses.py`

这一层要特别注意两件事：

1. `ModelClient` 属于适配层，不是宿主应用主协议
2. 这一层可以重排、补充、裁剪模型字段，但宿主不应直接依赖这些私有格式

### 第 3 层：`tada-core` 公共运行时协议层

这一层才是宿主应用应该长期依赖的稳定 contract：

- `AgentLoop.run_turn()` / `run_turn_message()` / `continue_turn()`
- `Event`
- `SessionState`
- `ConversationMessage`
- `ContentBlock`
- `MessageRole`

如果你在写宿主接入、前端调试面板、状态持久化或统一回放，应该优先围绕这一层设计，而不是围绕底层模型 payload 设计。

## 3. 关键对象分别属于哪一层

| 名称 | 模型原生协议 | provider / adapter 层 | `tada-core` 公共协议 | 说明 |
|------|--------------|-----------------------|----------------------|------|
| OpenAI `tool_calls` | 是 | 会被适配 | 否 | OpenAI 模型 API 原生字段 |
| OpenAI `role="tool"` | 是 | 会被适配 | 否 | 工具结果回填消息 |
| Anthropic `tool_use` | 是 | 会被适配 | 否 | Messages API 原生 block |
| Anthropic `tool_result` | 是 | 会被适配 | 否 | Messages API 原生 block |
| Anthropic `thinking` | 是 | 会被适配 | 是 | `ContentBlock(type="thinking")` + `thinking_*` runtime events |
| `AssistantEvent` | 否 | 是 | 否 | `ModelClient` 输出给 `AgentLoop` 的中间层 |
| `Event` | 否 | 由 `AgentLoop` 产出 | 是 | 宿主消费的统一事件流 |
| `ConversationMessage` | 否 | 由 `AgentLoop` 组装 | 是 | 宿主持久化的统一消息模型 |
| `ContentBlock(type="tool_use")` | 否 | 由 `AgentLoop` 归一化 | 是 | `tada-core` 统一 transcript block |
| `ContentBlock(type="tool_result")` | 否 | 由 `AgentLoop` 归一化 | 是 | `tada-core` 统一 transcript block |
| `subagent_started` / `subagent_finished` | 否 | Phase 2 | 否 | 当前 v0.1 尚未实现 |
| Markdown 回答格式 | 否 | 可由 prompt 约束 | 否 | 是文本格式偏好，不是独立协议块 |

## 4. 你关心的几个组件，应该怎么定性

### `tool_use`

- 在 OpenAI、Anthropic 等模型协议里，工具调用本身是原生存在的
- 进入 `tada-core` 后，会被 provider 归一化成：
  - `Event(type="tool_use")`
  - `ContentBlock(type="tool_use")`

所以 `tool_use` 同时存在于两层，但**字段形态不是同一个东西**。宿主依赖时应依赖 `tada-core` 的统一形态。

### `tool_result`

- 在模型协议里，工具结果通常由宿主执行工具后再回填给模型
- 在 OpenAI 中通常表现为 `role="tool"` 消息
- 在 Anthropic 中通常表现为 `tool_result` content block
- 在 `tada-core` 中则被统一成：
  - `Event(type="tool_result")`
  - `ContentBlock(type="tool_result")`

也就是说，`tool_result` 的“语义”跨层存在，但公共对外形态以 `tada-core` contract 为准。

### `thinking`

- Anthropic Messages API 有 `thinking` / extended thinking 内容块
- OpenAI Responses / reasoning models expose reasoning through different wire shapes
- `tada-core` 现在提供统一 public contract：
  - `ContentBlock(type="thinking")`
  - `Event(type="thinking_start" | "thinking_delta" | "thinking_end")`

adapter 负责把 provider-native reasoning/thinking 字段翻译成上述统一形态。

### `markdown`

`markdown` 更像回答格式偏好，而不是独立协议类型。

这意味着：

- 模型可以被提示“用 Markdown 回答”
- provider 可以把 Markdown 文本当普通文本返回
- `tada-core` 当前不会把它升格成独立 block 或事件类型

所以在 `tada-core` 中，Markdown 仍应视为 `text` 内容。

### `subagent`

`subagent` 不是模型原生协议，而是未来 runtime 语义。

当前 v0.1 没有 `SubagentSpec` 或 `subagent_started` / `subagent_finished` 事件。后续如果实现，推荐继续把它设计成“特殊工具调用”：

- 注册时使用 `SubagentSpec`
- 执行时包在统一工具链里
- 观测时通过 `subagent_started` / `subagent_finished` 暴露
- 最终结果仍折叠回父级 `tool_result`

在当前版本，宿主如果需要 delegation，应先把它作为普通工具调用封装。

## 5. 宿主应该依赖哪一层

宿主应用的推荐依赖顺序是：

1. **运行时观测**：依赖 `Event`
2. **状态持久化**：依赖 `SessionState`
3. **消息展示 / 回放**：依赖 `ConversationMessage` + `ContentBlock`

不推荐的做法是：

- 直接把 OpenAI / Anthropic 原始 payload 暴露给上层 UI
- 在宿主代码里写死某家模型的 `tool_use` 字段路径
- 把 `ModelClient` 内部的 `AssistantEvent` 当成公共协议

## 6. 对文档与 demo 的直接影响

这次分层确认以后，`tada-core` 文档和 demo 都应遵循同一条规则：

- 文档里区分“模型原生协议”和“`tada-core` 公共协议”
- demo 展示的是归一化后的 `Event` 与 `ContentBlock`
- demo 不应暗示自己展示的是 OpenAI / Anthropic 原始 payload

换句话说，demo 适合回答：

- `tada-core` 最终向宿主暴露了什么
- 一轮 turn 里有哪些标准事件
- 一条消息被归一化成了哪些 `ContentBlock`

但它不应该被解释为“底层模型 API 原样透传面板”。

## 7. 继续阅读

- 事件流细节：[`events.md`](events.md)
- 会话与消息模型：[`session-state.md`](session-state.md)
- tools / hooks / steering 机制：[`mechanisms.md`](mechanisms.md)
- model client 差异与桥接边界：[`providers.md`](providers.md)
