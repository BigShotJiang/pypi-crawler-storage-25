# Event 参考

`Event` 是 `tada-core` 最核心的公共 contract 之一。宿主应用真正消费的，不是 provider 内部对象，而是统一事件流。

如果你想先区分“模型原生协议”和“`tada-core` 公共协议”，建议先看 [`protocols.md`](protocols.md)。`Event` 属于后者，不等于 OpenAI / Anthropic 的原始返回格式。

## 1. 事件总览

当前 `Event` 是 15 个事件类型的判别联合，判别字段为 `type`。

| `type` | 类名 | 主要字段 | 用途 |
|--------|------|----------|------|
| `text_delta` | `TextDelta` | `text` | 增量文本输出 |
| `tool_use` | `ToolUseRequest` | `tool_use_id`, `tool_name`, `input_json` | 模型请求调用工具 |
| `tool_result` | `ToolResultEvent` | `tool_use_id`, `tool_name`, `output`, `is_error` | 工具执行结果 |
| `tool_progress` | `ToolProgressEvent` | `tool_use_id`, `tool_name`, `update` | 工具中间进度 |
| `usage` | `UsageEvent` | `input_tokens`, `output_tokens`, `cache_read_tokens`, `cache_creation_tokens` | usage 统计 |
| `message_stop` | `MessageStop` | 无 | 一条 assistant message 逻辑结束 |
| `permission` | `PermissionEvent` | `tool_name`, `allowed`, `reason` | 工具执行前的权限结果 |
| `hook` | `HookEvent` | `hook_name`, `phase`, `messages` | hook 参与的可观测信息 |
| `compaction` | `CompactionEvent` | `strategy`, `removed_message_count`, `summary` | 会话压缩摘要 |
| `error` | `ErrorEvent` | `message`, `code` | 运行时或 provider 错误 |
| `unsupported` | `UnsupportedEvent` | `feature`, `detail` | 不支持能力的显式信号 |
| `turn_start` | `TurnStartEvent` | `turn_index` | turn 开始 |
| `turn_end` | `TurnEndEvent` | `iterations_used`, `completed` | turn 结束 |
| `loop_exit` | `LoopExitEvent` | `tool_name`, `reason` | hook 请求结束 loop |
| `steering` | `SteeringEvent` | `tool_name`, `message_count`, `skipped_tools` | hook 注入 steering messages |

## 2. 顺序保证

以下顺序是 contract 的一部分：

1. `tool_use` 必须先于对应的 `permission`
2. `permission` 必须先于对应的 `tool_result`
3. `tool_progress` 必须先于对应的最终 `tool_result`
4. 未来能力协商层遇到不支持能力时，应显式发出 `unsupported`，不能 silent drop

宿主如果依赖工具审批、子代理可视化或链路审计，应把这些顺序当成稳定假设来实现。

## 3. 各事件的宿主处理建议

### `text_delta`

适合：

- 直接流式转发到前端
- 拼接成最终响应文本
- 记录流式输出日志

### `tool_use`

适合：

- 审计和可视化
- 调试模型行为
- 在工具执行前给 UI 提示“正在调用某工具”

### `permission`

适合：

- 审计权限决策
- 显示用户确认结果
- 解释某次工具调用为什么被拒绝

### `tool_result`

适合：

- 记录工具输出
- 判断是否发生工具错误
- 与对应 `tool_use_id` 关联形成完整调用链

### `hook`

适合：

- 调试 hooks 行为
- 输出审计信息
- 查看 hook 是否重写了输入或附加了说明

### `compaction`

适合：

- 观测上下文何时被压缩
- 在调试面板中记录压缩行为
- 解释会话上下文为什么变短

### `unsupported`

适合：

- 记录能力缺口
- 做降级处理
- 向调用方暴露“该 provider 当前不支持该功能”

它不是噪声事件，不能忽略。

当前 v0.1 的主实现是 `AgentLoop + ModelClient`，还没有 provider/capability 协商层，因此内置 `AgentLoop` 主路径通常不会自然产生 `unsupported`。这个事件类型保留给自定义 `ModelClient`、未来 provider 层，或宿主适配层显式报告能力缺口。

### `error`

适合：

- 将 provider 或 runtime 内错误标准化回传
- 显示中止、模型错误、迭代超限等运行状态

## 4. 常见 `error.code`

不同 provider 具体 code 可能不同，但当前内置 runtime 中常见的有：

| `code` | 说明 |
|--------|------|
| `aborted` | turn 被外部取消 |
| `model_error` | 模型层报错 |
| `max_iterations_exceeded` | agentic loop 超过最大迭代数 |

宿主不要只根据文案判断错误，最好同时记录 `type="error"` 与 `code`。

## 5. 事件与 `SessionState` 的关系

事件流和 `SessionState` 是互补关系：

- `Event` 用于运行时观测
- `SessionState` 用于稳定状态存储

并不是所有状态变化都会先以“单独事件”形式出现。例如 provider 可以在 turn 结束后统一更新 `state.messages`。因此宿主既要消费事件，也要正确持久化更新后的 `SessionState`。

## 6. 序列化

所有事件模型都是 Pydantic `BaseModel`，支持：

- `.model_dump()`
- `.model_dump_json()`

这意味着宿主可以把事件用于：

- 日志记录
- 回放
- 事件总线
- 调试面板

## 7. 一条实用建议

接入时，先至少完整处理这 6 类事件：

- `text_delta`
- `message_stop`
- `error`
- `unsupported`
- `tool_use`
- `tool_result`

这样你就能在最小成本下得到一条可观测、可调试的接入路径。
