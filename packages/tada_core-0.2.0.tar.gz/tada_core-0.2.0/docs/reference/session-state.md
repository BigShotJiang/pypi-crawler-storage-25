# SessionState 参考

`SessionState` 是宿主应用与 provider runtime 之间最重要的状态对象。它的设计目标不是“尽量多装东西”，而是“足够稳定、可移植、可序列化”。

这里的 `ConversationMessage` / `ContentBlock` 是 `tada-core` 的归一化 transcript 语言，不是某家模型 API 的原始消息格式。分层说明见 [`protocols.md`](protocols.md)。

## 1. 结构

当前 `SessionState` 的稳定顶层字段只有 3 个：

```python
class SessionState(BaseModel):
    messages: list[ConversationMessage]
    usage: TokenUsage
    metadata: dict[str, Any]
```

这 3 个字段分别代表：

- `messages`：归一化后的会话消息
- `usage`：跨 provider 的统一 usage 计数
- `metadata`：扩展槽，给 provider 或宿主放附加状态

## 2. 为什么字段这么少

这是一个有意收缩的设计。

如果 `SessionState` 顶层字段过多，就会出现两个问题：

1. provider 容易开始往顶层塞私有结构
2. 不同 provider 之间会逐渐失去可移植性

因此 `tada-core` 明确要求：

- provider 不能随意新增顶层字段
- provider 专属附加信息应放入 `metadata`

## 3. `messages`

`messages` 是 provider 无关的统一转录语言，元素类型是 `ConversationMessage`。

### `ConversationMessage`

```python
class ConversationMessage(BaseModel):
    role: MessageRole
    content: list[ContentBlock]
```

### `MessageRole`

稳定支持 3 个角色：

- `user`
- `assistant`
- `tool`

### `ContentBlock`

`ContentBlock` 表示消息里的一个归一化内容块，常见字段包括：

- `type`
- `text`
- `tool_use_id`
- `tool_name`
- `tool_input`
- `tool_result`
- `is_error`
- `extra`

常见 `type` 包括：

- `text`
- `tool_use`
- `tool_result`
- `image`
- `file`

`extra` 可以承载 provider 特定细节，但不应该破坏统一语义。

`image` / `file` 是一等内容块，常见字段包括：

- `source`: `base64` / `url` / `path`
- `mime_type`
- `data` 或 `url`
- `name`（文件名，可选）

0.x 阶段不保证旧版本 `tada-core` 能读取新版本写出的 `SessionState` JSON；宿主如需跨版本回滚，应在自己的持久化层记录 SDK 版本。

## 4. `usage`

`usage` 的类型是 `TokenUsage`：

```python
class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
```

它的目的是提供一套跨 provider 的最低公共 usage 计数，而不是强行对齐所有成本模型。

宿主应用通常可以把它用于：

- 基础日志
- 会话统计
- 简单成本估算

## 5. `metadata`

`metadata` 是 `dict[str, Any]`，它是 model client、runtime 和宿主的唯一稳定扩展槽。

### 这里适合放什么

- `user_id`
- `workspace_id`
- `session_id`
- `channel`
- provider 写入的会话元数据
- 调试或追踪字段

### 建议保留 key

这些 key 是 tada-core 内置策略或宿主集成中已经约定的轻量字段。宿主可以按需使用，但应保持 value 可 JSON 序列化。

| Key | 建议类型 | 用途 |
| --- | --- | --- |
| `session_id` | `str` | 宿主会话 / thread 标识，用于追踪、异步 compaction registry、持久化关联 |
| `user_id` | `str` | 终端用户标识，用于审计、配额、个性化上下文 |
| `workspace_id` | `str` | workspace / tenant / project 标识 |
| `channel` | `str` | CLI、Web、Feishu、Slack 等宿主入口 |
| `last_usage` | `dict` | 最近一次模型 usage；`StructuredSummaryCompaction` 会优先读取它做阈值判断 |
| `compaction` | `dict` | 压缩策略写入的摘要、tokens_before/after、manifest、fallback 状态 |
| `trace_id` | `str` | 外部 tracing 系统的关联 ID |

### 这里不适合放什么

- 复杂嵌套结构
- 大块原始响应对象
- 二进制或超长上下文

虽然类型允许 `Any`，宿主仍应只放轻量、可 JSON 序列化的数据。如果你发现自己想往 `metadata` 里塞大型 JSON，通常意味着应该把它放到宿主应用自己的存储模型中，而不是 core state 里。

## 6. `clone()`

`SessionState.clone()` 会返回深拷贝：

```python
snapshot = state.clone()
```

它适合：

- 子代理上下文隔离
- 推测性执行
- 分支式实验

不要用浅拷贝替代它，否则很容易在共享列表与嵌套对象上踩坑。

## 7. 序列化与持久化

`SessionState` 是完整可序列化的：

```python
blob = state.model_dump_json()
restored = SessionState.model_validate_json(blob)
```

这意味着宿主可以：

- 存数据库
- 存缓存
- 通过消息队列传输
- 在不同 provider 之间迁移

## 8. 宿主接入时要遵守的规则

1. 不要给 `SessionState` 动态新增顶层字段
2. 宿主扩展信息只放进 `metadata`
3. `metadata` 的 value 应保持轻量并可 JSON 序列化
4. 每轮结束后应持久化更新后的 `SessionState`
5. 不要假设 `messages` 长度稳定不变，因为 compaction 可能会修改它

## 9. 常见误区

### 误区 1：把 `SessionState` 当成 provider 私有状态桶

这样会破坏 provider 无关性。

### 误区 2：把复杂宿主对象直接塞进 `metadata`

`metadata` 是轻量扩展槽，不是通用对象存储。

### 误区 3：只看事件，不保存状态

事件流用于观测，`SessionState` 用于恢复和续聊，两者都重要。

## 10. 一句话总结

`SessionState` 的价值不在于它“信息很多”，而在于它是 **最小、稳定、可迁移的会话状态 contract**。
