# Compaction 参考

`tada-core` 的 compaction 是 runtime 级能力：长会话超过上下文预算时，SDK 可以把旧消息压缩成结构化摘要，并通过 `CompactionEvent` 让宿主可观测、可记录、可替换。

## 默认行为

`AgentLoop` 默认启用 `StructuredSummaryCompaction`，不再默认 `NeverCompact`：

```python
loop = AgentLoop(model)
```

默认策略会：

- 优先用 provider 返回的 `usage.input_tokens` 真值判断是否需要压缩。
- 缺少 usage 时使用 SDK 内置 `CharacterTokenEstimator` 兜底，覆盖 `text`、`tool_use`、`tool_result`、`image`、`file`。
- 从 `ModelSpec.context_window * 0.7` 自动派生阈值；显式传 `threshold_tokens` 时优先用显式值。
- 保留 head 和 tail，把中段消息总结成一条 `[compacted summary]`。
- 默认在摘要前主动裁剪 middle 中过大的 `tool_result`，用占位符替换并记录 manifest；tail 默认保留，避免丢掉近期工具输出。
- 维护 tool use / tool result 成对语义，删除孤儿 result，并为保留的孤儿 tool use 补 stub result。
- 不把真实 base64 图片或文件塞进摘要，只把引用写入 `SessionState.metadata["compaction"]["manifest"]`。

关闭或接管：

```python
from tada_core import CompactionConfig

AgentLoop(model, compaction="disabled")
AgentLoop(model, compaction=CompactionConfig(mode="disabled"))
AgentLoop(model, compaction=CompactionConfig(mode="hook_only"))
```

`hook_only` 模式下，core 不主动压缩，但宿主 hook 仍可改写消息：

```python
HookResult(
    updated_messages=compacted_messages,
    compaction_handled=True,
    skip_builtin_compaction=True,
)
```

## Contract

核心接口：

```python
class CompactionStrategy(ABC):
    def should_compact(
        self,
        state: SessionState,
        *,
        trigger: str = "auto",
        system_prompt: list[str] | None = None,
        tools: list[dict] | None = None,
    ) -> bool: ...
    def compact(self, state: SessionState, *, trigger: str = "auto") -> CompactionResult: ...
```

异步模型摘要策略可额外实现：

```python
async def compact_async(
    state: SessionState,
    *,
    trigger: str = "auto",
    system_prompt: list[str] | None = None,
    tools: list[dict] | None = None,
) -> CompactionResult: ...
```

`CompactionResult` 包含：

| 字段 | 含义 |
|---|---|
| `removed_message_count` | 被摘要替换的消息数量 |
| `summary` | 摘要正文 |
| `trigger` | 触发点，例如 `pre_turn` / `post_llm` / `post_turn` |
| `tokens_before` / `tokens_after` | 压缩前后 token 估算 |
| `pruned_tool_count` | 被裁剪的大型 tool result 数量 |
| `cache_hit_estimated` | 摘要请求是否具备 cache hit 前置条件 |
| `compacted_message_ids` | 被摘要覆盖的原始 `ConversationMessage.id` 列表 |
| `pruned_tool_results` | 被裁剪工具结果的结构化审计记录 |
| `fallback_used` | 摘要模型失败或空输出时是否使用 fallback 摘要 |
| `manifest` | artifact、tool pruning、source id 等可观测元数据 |

对应事件：

```python
CompactionEvent(
    strategy="StructuredSummaryCompaction",
    removed_message_count=...,
    summary=...,
    trigger="post_llm",
    tokens_before=...,
    tokens_after=...,
    compacted_message_ids=[...],
    pruned_tool_results_count=...,
    fallback_used=False,
)
```

## 触发时机

`AgentLoop` 有三个可观测压缩点：

| 触发点 | 用途 |
|---|---|
| `pre_turn` | 冷启动 preflight，避免载入历史后一开始就超窗 |
| `post_llm` | 主路径，模型返回 usage 真值后判断，最准确 |
| `post_turn` | 可选回收点，兼容旧策略 |

主路径是 `post_llm`：模型响应完成后，SDK 已经拿到 `TokenUsage`，此时压缩判断最接近 provider 自己的 tokenizer 结果。

## Token 估算

估算源优先级：

1. `state.metadata["last_usage"].input_tokens`，由最近一次 `UsageEvent` 写入，是真值。
2. `ModelClient.estimate_tokens(request)`，可选 provider-native 估算。
3. 宿主传入的 `TokenEstimator`。
4. `CharacterTokenEstimator`，依赖字符数和固定 multimodal 常量兜底。

`SessionState.usage` 是累计值；最近一次请求的 usage 会同时写入 `state.metadata["last_usage"]`，用于下一次 compaction 判断。

## Tool Result Pruning

`tools` 和 `tool_result` 是两类不同数据：

- `tools` 是请求级工具定义列表，和 `system_prompt` 一起位于 provider payload 的稳定前缀区域。
- `tool_result` 是消息内容块，表示某次工具调用的输出，位于对话消息中。

因此，裁剪旧 `tool_result` 不会改变 `tools` 定义列表，也不会破坏 `system + tools` 这段稳定前缀的 cache marker。默认配置只裁剪 middle：

```python
from tada_core import CompactionConfig, ToolResultPruningConfig

config = CompactionConfig(
    tool_result_pruning=ToolResultPruningConfig(
        enabled=True,
        scope="middle_only",
        max_chars=4000,
        keep_tail_messages=4,
        preserve_error_chars=8000,
        placeholder="[Old tool output cleared to save context space]",
    )
)
```

默认语义：

- `head` 永不裁剪，保留初始任务语义。
- `middle` 可以裁剪，因为它马上会被 summary 替换。
- `tail` 默认不裁剪，除非宿主显式选择更激进 scope。
- error tool result 使用 `preserve_error_chars`，默认保留更多诊断信息。
- 每次裁剪都会写入 `manifest["pruned_tool_results"]`，包括 `message_id`、`tool_use_id`、`tool_name`、原始长度和 error 标记。

## Prompt Cache 协同

`StructuredSummaryCompaction` 默认复用主对话的 `system_prompt` 和 `tools` 构造摘要请求。这是协议中立的 cache 友好策略：SDK 不探测 provider 是否支持 cache，而是让各 adapter 在 wire format 层处理。

| Provider / api | cache 机制 | tada-core 当前状态 |
|---|---|---|
| `anthropic-messages` | 显式 `cache_control` marker，默认 5m，`ttl="1h"` 为 1h | 已打 marker，已解析 cache read/write tokens |
| `openai-completions` | 服务端隐式 prefix cache | 已通过 `prompt_tokens_details.cached_tokens` 观测 |
| `openai-responses` | 服务端隐式 prefix cache | 已通过 shared OpenAI usage parser 观测 |
| `google-generative-ai` | Gemini implicit cache / cachedContent API | 压缩正常；cache token 解析是 follow-up |
| `bedrock-converse-stream` | Bedrock cachePoint / Anthropic-on-Bedrock cache_control | 压缩正常；cache marker 与 token 解析是 follow-up |

### `cache_control` / `retention` / `ttl`

- `cache_control` 是 Anthropic Messages API 的 payload 字段，例如 `{"type": "ephemeral"}`。
- `ttl` 是 `cache_control` 内的字段。Anthropic 当前只支持不写（默认 5 分钟）或 `"1h"`，不支持 `"5m"`、`"30m"`、`"2h"` 这类任意时长。
- `retention` 是 tada-core 的 SDK 抽象：`"none" | "short" | "long"`。

映射：

| `CacheRetention` | Anthropic payload | TTL |
|---|---|---|
| `"none"` | 不打 `cache_control` | 不缓存 |
| `"short"` | `{"type": "ephemeral"}` | 5 分钟 |
| `"long"` 且 base_url 是 `api.anthropic.com` | `{"type": "ephemeral", "ttl": "1h"}` | 1 小时 |
| `"long"` 但 base_url 是 proxy | 自动降级为 `{"type": "ephemeral"}` | 5 分钟 |

Cache read 命中时按 provider 计费规则降低 input 成本；判断是否真的命中，以 `UsageEvent.cache_read_tokens` 为准。

## 成本取舍

| 方案 | 摘要质量 | 配置复杂度 | 推荐度 |
|---|---|---|---|
| 主模型 + cache hit | 高 | 简单 | 首选 |
| 主模型 + cache miss | 高 | 简单 | 退化情形 |
| 单独小模型（同协议） | 中 | 中 | 主 provider 不支持 cache 或主模型限流时考虑 |
| 单独小模型（跨协议） | 中 | 高 | 需要宿主明确做多 provider 路由时考虑 |

主模型 + cache hit 通常能接近小模型成本，同时保留主模型摘要质量，并避免双套凭证、双套工具 schema 兼容问题。

## tada-agent 迁移建议

短期：`tada-agent` 接入时使用 `CompactionConfig(mode="hook_only")`，继续让现有 `MemoryCompactionHook` 作为压缩 owner。

中期：逐步把通用能力下沉到 core：

- tool pair sanitizer 改用 `tada_core.loop.message_sanitizer`。
- 触发判断改为 `usage.input_tokens` 真值优先。
- `MemoryCompactionHook._compact` 委托 `StructuredSummaryCompaction.compact_async()`。
- 模型注入走 `ModelSpec + build_model_client`，避免绑定某个具体 provider client。

长期：`tada-agent` 只保留业务 adapter：reme/DB mark、Langfuse、artifact resolver、长期记忆联动、UI/outcome 语义。消息改写由 `tada-core` 单点执行，避免双重压缩。

Bridge 字段对照：

- `CompactionResult.summary` -> ReMe `_compressed_summary`
- `CompactionResult.compacted_message_ids` -> AgentScope `Msg` 的 `COMPRESSED` mark
- `CompactionResult.manifest["pruned_tool_results"]` -> tool result 裁剪审计与回溯
- `CompactionEvent` -> Langfuse span / trace metadata

`tada-core` 不直接写 ReMe，也不拥有跨 query `PendingCompactionRegistry`；这些仍由 `tada-agent` adapter 管理。

## 什么时候自定义

以下场景可自定义 `CompactionStrategy`：

- 合规策略要求特定消息永不摘要。
- 需要接业务长期记忆或知识库。
- 需要完全不同的摘要格式。
- 需要宿主统一调度 summary model、限流、成本预算。

默认情况下，优先使用 `StructuredSummaryCompaction`，并通过 `CompactionConfig` 调整行为。
