"""
工具并发执行 Demo — 以旅行查询为例

说明：
  本文件展示 tada-core 工具并发执行的设计模式。
  核心思路来自 cc-haha（Claude Code）的 isConcurrencySafe / partitionToolCalls 设计：
    - 并发安全性由工具自己声明，而非全局开关
    - 调度器（ToolExecutor）根据声明动态决定并发还是顺序
    - 默认保守（False），工具按需 override

涉及 contracts/tools.py 的扩展：
  ToolDefinition 需要增加 is_concurrency_safe(input) 方法（见下方 ConcurrentTool）
  ToolExecutor 的 execute 需要升级为 execute_batch，支持 partition 调度

用法：
  直接运行本文件查看 mock 输出：
    python docs/reference/tool-concurrency-demo.py
"""

from __future__ import annotations

import asyncio
import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# 扩展后的工具基类（对应 contracts/tools.py 中 ToolDefinition 的扩展方向）
# ---------------------------------------------------------------------------

@dataclass
class ConcurrentTool(ABC):
    """带并发安全声明的工具基类。

    工具开发者需要实现：
      - name / description / parameters_schema：工具声明（同现有 ToolDefinition）
      - is_concurrency_safe(input)：告知调度器这次调用是否可以并发
      - execute(input)：实际执行逻辑
    """

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def description(self) -> str: ...

    def is_concurrency_safe(self, input: dict) -> bool:
        """声明本次调用是否可以与其他工具并发执行。

        默认 False（保守）。工具根据实际副作用模型 override。

        判断依据：
          - 只读、无共享状态修改 → True
          - 写文件、修改 DB、有副作用 → False
          - 依赖其他工具结果 → False
          - 需要路径级隔离时 → 检查 input 中的路径是否冲突（见 FileReadTool 示例）
        """
        return False

    @abstractmethod
    async def execute(self, input: dict) -> dict: ...


# ---------------------------------------------------------------------------
# Demo 工具：查机票（只读，可并发）
# ---------------------------------------------------------------------------

class SearchFlightTool(ConcurrentTool):
    """查询航班信息。只读 API 调用，无副作用，可并发。"""

    @property
    def name(self) -> str:
        return "search_flight"

    @property
    def description(self) -> str:
        return "查询指定日期的航班信息"

    def is_concurrency_safe(self, input: dict) -> bool:
        # 只读 API 查询，无状态修改，始终可并发
        return True

    async def execute(self, input: dict) -> dict:
        # mock：模拟网络延迟
        await asyncio.sleep(0.8)
        return {
            "tool": self.name,
            "origin": input.get("origin"),
            "destination": input.get("destination"),
            "date": input.get("date"),
            "results": [
                {"flight": "CA1234", "price": 980, "departure": "08:00"},
                {"flight": "MU5678", "price": 1050, "departure": "14:30"},
            ],
        }


# ---------------------------------------------------------------------------
# Demo 工具：查酒店（只读，可并发）
# ---------------------------------------------------------------------------

class SearchHotelTool(ConcurrentTool):
    """查询酒店信息。只读 API 调用，无副作用，可并发。"""

    @property
    def name(self) -> str:
        return "search_hotel"

    @property
    def description(self) -> str:
        return "查询指定城市和日期的酒店信息"

    def is_concurrency_safe(self, input: dict) -> bool:
        # 只读 API 查询，始终可并发
        return True

    async def execute(self, input: dict) -> dict:
        await asyncio.sleep(1.0)
        return {
            "tool": self.name,
            "city": input.get("city"),
            "checkin": input.get("checkin"),
            "results": [
                {"hotel": "如家酒店", "price": 388, "rating": 4.2},
                {"hotel": "汉庭酒店", "price": 428, "rating": 4.5},
            ],
        }


# ---------------------------------------------------------------------------
# Demo 工具：写入行程单（有副作用，不可并发）
# ---------------------------------------------------------------------------

class SaveItineraryTool(ConcurrentTool):
    """保存行程到数据库。写操作，有副作用，不可并发。"""

    @property
    def name(self) -> str:
        return "save_itinerary"

    @property
    def description(self) -> str:
        return "将选定的航班和酒店保存为行程单"

    def is_concurrency_safe(self, input: dict) -> bool:
        # 写操作，不可并发
        return False

    async def execute(self, input: dict) -> dict:
        await asyncio.sleep(0.3)
        return {
            "tool": self.name,
            "status": "saved",
            "itinerary_id": "itin_20260501_001",
        }


# ---------------------------------------------------------------------------
# 调度器：partitionToolCalls + 并发/顺序执行
# （对应 tada-core ToolExecutor 的 execute_batch 升级方向）
# ---------------------------------------------------------------------------

@dataclass
class ToolCallRequest:
    tool_name: str
    input: dict
    call_id: str = ""


@dataclass
class Batch:
    is_concurrency_safe: bool
    calls: list[ToolCallRequest] = field(default_factory=list)


def partition_tool_calls(
    calls: list[ToolCallRequest],
    tools: dict[str, ConcurrentTool],
) -> list[Batch]:
    """将工具调用列表分成并发/顺序 batch。

    规则：
      - 连续的 safe 调用合并为一个并发 batch
      - 非 safe 调用单独一个顺序 batch
      - safe 判断基于工具的 is_concurrency_safe(input)，而非全局开关
    """
    batches: list[Batch] = []
    for call in calls:
        tool = tools.get(call.tool_name)
        if tool is None:
            # 未知工具，保守顺序处理
            safe = False
        else:
            try:
                safe = tool.is_concurrency_safe(call.input)
            except Exception:
                # is_concurrency_safe 抛异常时，保守回退到顺序
                safe = False

        if safe and batches and batches[-1].is_concurrency_safe:
            # 合并进当前并发 batch
            batches[-1].calls.append(call)
        else:
            batches.append(Batch(is_concurrency_safe=safe, calls=[call]))

    return batches


async def execute_batch(
    batch: Batch,
    tools: dict[str, ConcurrentTool],
) -> list[dict]:
    """执行一个 batch，并发或顺序取决于 batch.is_concurrency_safe。"""
    if batch.is_concurrency_safe:
        # 并发执行
        results = await asyncio.gather(
            *[tools[c.tool_name].execute(c.input) for c in batch.calls]
        )
        return list(results)
    else:
        # 顺序执行
        results = []
        for call in batch.calls:
            result = await tools[call.tool_name].execute(call.input)
            results.append(result)
        return results


async def execute_tool_calls(
    calls: list[ToolCallRequest],
    tools: dict[str, ConcurrentTool],
) -> list[dict]:
    """完整调度入口：partition → 逐 batch 执行 → 收集结果。"""
    batches = partition_tool_calls(calls, tools)

    print("\n=== 调度计划 ===")
    for i, batch in enumerate(batches):
        mode = "并发" if batch.is_concurrency_safe else "顺序"
        names = [c.tool_name for c in batch.calls]
        print(f"  Batch {i+1} [{mode}]: {names}")

    all_results = []
    for batch in batches:
        results = await execute_batch(batch, tools)
        all_results.extend(results)

    return all_results


# ---------------------------------------------------------------------------
# 演示：LLM 返回 3 个工具调用，前两个可并发，第三个顺序
# ---------------------------------------------------------------------------

async def main():
    registry: dict[str, ConcurrentTool] = {
        "search_flight": SearchFlightTool(),
        "search_hotel": SearchHotelTool(),
        "save_itinerary": SaveItineraryTool(),
    }

    # 模拟 LLM 在单次响应中返回的工具调用列表
    llm_tool_calls = [
        ToolCallRequest(
            tool_name="search_flight",
            input={"origin": "BJS", "destination": "SHA", "date": "2026-05-01"},
            call_id="call_001",
        ),
        ToolCallRequest(
            tool_name="search_hotel",
            input={"city": "上海", "checkin": "2026-05-01"},
            call_id="call_002",
        ),
        # save_itinerary 依赖前两个结果，is_concurrency_safe=False，独立顺序执行
        ToolCallRequest(
            tool_name="save_itinerary",
            input={"flight_id": "CA1234", "hotel_id": "汉庭酒店"},
            call_id="call_003",
        ),
    ]

    print("=== 开始执行 ===")
    start = time.monotonic()
    results = await execute_tool_calls(llm_tool_calls, registry)
    elapsed = time.monotonic() - start

    print("\n=== 执行结果 ===")
    for r in results:
        print(f"  {r['tool']}: OK")

    print(f"\n总耗时: {elapsed:.2f}s")
    print("（search_flight=0.8s + search_hotel=1.0s 并发，实际等 1.0s；save_itinerary=0.3s 顺序）")
    print(f"预期: ~1.3s，全部顺序则需 ~2.1s")


if __name__ == "__main__":
    asyncio.run(main())
