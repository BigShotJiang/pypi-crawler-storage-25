# 机制参考

这篇文档集中说明 `tada-core` 的几个核心运行机制：

- tools
- permissions
- hooks
- compaction / steering / loop exit

这些机制都属于“runtime 扩展点”，但它们不是彼此孤立的，而是被组织在同一条事件链里。

完整分层见 [`protocols.md`](protocols.md)。当前 v0.1 的实现中心是 `AgentLoop`，模型访问由 `ModelClient` 提供；历史 provider / capability / subagent 设计仍属于后续阶段。

## 1. Tools

工具通过 `ToolExecutor` 接入。

### 核心接口

```python
class ToolExecutor(ABC):
    def execute(self, tool_name: str, input_json: str) -> str: ...
    def list_tools(self) -> list[ToolDefinition]: ...
```

### `ToolDefinition`

每个工具的最小定义包括：

- `name`
- `description`
- `parameters_schema`

也就是说，工具对模型暴露的是一个标准化函数描述，而不是任意 Python 对象。

### 默认实现

`InMemoryToolExecutor` 是最简单的实现，它把工具名映射到 Python callable。

### 接入重点

- 输入输出边界统一是 JSON 字符串
- 工具 schema 应尽量稳定
- 未注册工具会抛出 `ToolError`

## 2. Permissions

权限系统用来决定某次工具调用是否允许执行。

### 核心接口

```python
class PermissionPolicy(ABC):
    def authorize(
        self,
        tool_name: str,
        tool_input: str,
        *,
        context: PermissionContext | None = None,
        prompter: PermissionPrompter | None = None,
    ) -> PermissionOutcome: ...
```

### 内置策略

- `AllowAllPolicy`
- `DenyListPolicy`

### `PermissionContext`

权限不是孤立判断，它可以接收 hooks 传递过来的 override 信息：

- `override`
- `reason`

这使得 hooks 和 permission 可以串成同一条决策链，而不是各做各的。

## 3. Hooks

hooks 是 runtime 中的一等参与者，而不是外部旁路。

### 核心相位

当前 `AgentLoop` 会调用的 hook 方法包括：

- `run_on_turn_start()`
- `run_pre_llm_call()`
- `run_post_llm_call()`
- `run_pre_tool_use()`
- `run_post_tool_use()`
- `run_post_tool_use_failure()`
- `run_on_turn_end()`

枚举中还定义了 `OnSessionStart`，`FunctionHookRunner` 和 `CompositeHookRunner` 也提供对应方法，但当前 `AgentLoop` 尚未调用这个阶段。

### `HookResult`

`HookResult` 可以表达：

- `denied`
- `failed`
- `cancelled`
- `messages`
- `permission_override`
- `permission_reason`
- `updated_input`
- `updated_messages`
- `exit_loop`
- `steering_messages`

其中最关键的一条规则是：

> `updated_input` 一旦存在，后续权限判断和实际工具执行都应使用改写后的输入。

### 默认实现

`NoOpHookRunner` 是默认 no-op 实现；`FunctionHookRunner` 适合用 Python 回调快速组装 hooks。

## 4. Steering 与 loop exit

`POST_TOOL_USE` hook 可以影响当前 loop 后续走向：

- `exit_loop=True`：当前工具结果写入 `SessionState` 后，发出 `LoopExitEvent` 并结束本轮；适合 ask-user 风格的暂停。
- `steering_messages=[...]`：工具结果写入后，发出 `SteeringEvent`，跳过本轮剩余工具，并把 steering messages 追加到会话，让模型重新规划。

这两种机制都通过普通 hook 结果表达，不需要宿主发明额外协议。

## 5. Subagent 状态

Subagent 是 Phase 2 设计方向，当前 v0.1 代码没有 `SubagentSpec`、`SubagentStarted`、`SubagentFinished`，也没有框架级子代理预算约束。

如果宿主现在需要 delegation，可以先把它作为普通工具实现：工具内部自己启动子流程，最终把结果作为 `tool_result` 返回。这样仍能复用现有 `tool_use -> permission -> tool_result` 事件链，但不会有框架级子代理边界事件。

## 6. 这些机制是怎么串起来的

以支持完整能力的 runtime 为例，一次工具调用的路径通常是：

```mermaid
flowchart TD
    toolUse[tool_use]
    preHook[pre hook]
    permission[permission]
    execute[tool execute or subagent]
    postHook[post hook]
    toolResult[tool_result]

    toolUse --> preHook
    preHook --> permission
    permission --> execute
    execute --> postHook
    postHook --> toolResult
```

这条链路解释了为什么这些机制不能分开理解：

- hooks 会影响 permission
- permission 决定是否允许工具执行
- steering / loop exit 会影响下一步是否继续调用模型
- 最终所有结果仍统一落到事件流里

## 7. 宿主接入建议

1. 把 tools / hooks / permissions / steering 看成一条链，而不是几个互不相关的按钮
2. 自定义 `ModelClient` 时，把 provider 私有协议转换成 `AssistantEvent`
3. 对 `error` 和未来可能出现的 `unsupported` 做清晰日志
4. 如果依赖严格权限或 hook 改写，应在集成测试中覆盖对应事件顺序

## 8. 和其他文档的关系

- compaction 单独见 [`compaction.md`](compaction.md)
- provider 差异见 [`providers.md`](providers.md)
- 事件类型见 [`events.md`](events.md)
