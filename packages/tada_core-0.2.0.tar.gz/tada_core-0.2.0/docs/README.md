# tada-core 文档索引

`tada-core` 的文档现在按 4 层组织：

- **项目入口**：回答“这是什么”，见根目录 `README.md`
- **架构层**：回答“为什么这样设计”，见 `docs/architecture/`
- **参考层**：回答“具体能力和机制是什么”，见 `docs/reference/`
- **接入层**：回答“实际怎么接”，见 `docs/integration/`

此外，根目录还有一份单独的 `AGENTS.md`，它是面向 AI / coding agent 的机器可读入口；为什么它在根目录，见 [`ai/README.zh.md`](ai/README.zh.md)。

## 推荐阅读路径

### 第一次了解 tada-core

1. [`architecture/overview.md`](architecture/overview.md)
2. [`architecture/runtime-lifecycle.md`](architecture/runtime-lifecycle.md)
3. [`architecture/design-principles.md`](architecture/design-principles.md)
4. [`reference/providers.md`](reference/providers.md)
5. [`integration/human-guide.md`](integration/human-guide.md)

### 需要查细节

1. [`reference/providers.md`](reference/providers.md)
2. [`reference/protocols.md`](reference/protocols.md)
3. [`reference/events.md`](reference/events.md)
4. [`reference/compaction.md`](reference/compaction.md)
5. [`reference/mechanisms.md`](reference/mechanisms.md)
6. [`reference/session-state.md`](reference/session-state.md)

### 准备落地接入

1. [`integration/install.md`](integration/install.md)
2. [`integration/human-guide.md`](integration/human-guide.md)
3. [`integration/custom-provider.md`](integration/custom-provider.md)
4. [`integration/troubleshooting.md`](integration/troubleshooting.md)

### 需要给 AI 提供仓库接入说明

1. [`ai/README.zh.md`](ai/README.zh.md)
2. [`../AGENTS.md`](../AGENTS.md)

## 目录说明

### `docs/architecture/`

- [`overview.md`](architecture/overview.md)：系统定位、边界、`AgentLoop + ModelClient` 架构、核心 contracts
- [`agent-loop.md`](architecture/agent-loop.md)：agent loop 分层背景；含部分 Phase 2/历史设计语境，当前实现以 `overview.md` 为准
- [`agent-loop-product-design.md`](architecture/agent-loop-product-design.md)：三种 agent loop 对 agent 产品设计、扩展点和能力建模的影响
- [`runtime-lifecycle.md`](architecture/runtime-lifecycle.md)：`run_turn()` 生命周期、事件顺序、状态变化
- [`design-principles.md`](architecture/design-principles.md)：契约优先、模型协议隔离、禁止 silent drop、一致性测试

### `docs/reference/`

- [`providers.md`](reference/providers.md)：`AnthropicModelClient`、OpenAI-compatible 测试客户端与自定义 `ModelClient`
- [`protocols.md`](reference/protocols.md)：模型原生协议、model client 适配层与 `tada-core` 公共协议的分层边界
- [`events.md`](reference/events.md)：15 类 `Event` 的字段、顺序保证、宿主处理建议
- [`session-state.md`](reference/session-state.md)：`SessionState`、`ConversationMessage`、`TokenUsage` 的约束
- [`mechanisms.md`](reference/mechanisms.md)：tools、permissions、hooks、steering、loop exit 的统一说明
- [`compaction.md`](reference/compaction.md)：`CompactionStrategy`、触发时机、内置方案、生产建议

### `docs/integration/`

- [`install.md`](integration/install.md)：作为 SDK 被其他 Python 项目引入的本地 path、Git URL、PyPI 写法
- [`human-guide.md`](integration/human-guide.md)：面向工程师的中文接入主线
- [`custom-provider.md`](integration/custom-provider.md)：自定义模型接入的实现与验证路径
- [`troubleshooting.md`](integration/troubleshooting.md)：常见 `ModelClient`、事件流与 `SessionState` 排障方法

### `docs/ai/`

- [`README.zh.md`](ai/README.zh.md)：解释 `AGENTS.md` 为什么在根目录，以及它和中文文档的关系

## 兼容入口

原先的 [`architecture.md`](architecture.md) 和 [`integration-guide.md`](integration-guide.md) 现在保留为兼容入口页，仅用于指向新的目录化文档结构。

## 文档边界

`tada-core` 文档只描述 core 自己的职责与接入方式，不讨论上层产品逻辑、渠道业务、UI 形态或产品壳实现。

如果你只想记住一句话：

> `tada-core` 负责统一 runtime contracts 与事件语义，宿主应用负责接入、存储、路由和消费。
