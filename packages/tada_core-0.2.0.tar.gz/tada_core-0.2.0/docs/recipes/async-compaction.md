# Async Compaction Recipe

Use this pattern when summary generation is expensive enough that you want to
start it in the background before the hard context limit is reached, then apply
the completed summary on a later turn.

## Runtime Shape

```mermaid
graph LR
  preLlm[PreLlmCall hook] --> claim[Claim ready summary]
  claim --> apply[Apply summary to SessionState]
  apply --> estimate[Estimate current tokens]
  estimate --> warn[Above warn threshold]
  warn --> spawn[Spawn background worker]
  spawn --> handled[Return compaction_handled]
  handled --> loop[AgentLoop skips builtin compaction]
```

The hook owns the async registry and tells `AgentLoop` not to run its built-in
compaction for that LLM call:

```python
from tada_core.contracts.hooks import HookResult


async def pre_llm_call(messages):
    ready = await registry.claim_result(session_id)
    if ready is not None:
        messages = apply_summary(messages, ready)

    token_count = estimator.estimate_messages(messages, system_prompt=system_prompt, tools=tools)
    if token_count >= warn_threshold and not registry.has_pending(session_id):
        await registry.spawn(session_id, compact_worker, snapshot(messages))

    return HookResult(
        updated_messages=messages,
        compaction_handled=True,
        skip_builtin_compaction=True,
    )
```

## Hard Threshold

At a hard threshold, do not start another background worker. Drain the pending
task if one exists; if it failed or none exists, run the compaction synchronously
and apply the result before the next model call.

## State Contract

Store registry state outside `SessionState`. Store only durable compaction facts
under `SessionState.metadata["compaction"]`, such as:

- `last_summary`
- `tokens_before`
- `tokens_after`
- `compacted_message_ids`
- `fallback_used`

This keeps `SessionState` serializable while allowing host applications to use
their own task registry, database, or queue implementation.
