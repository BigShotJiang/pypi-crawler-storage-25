# 架构说明已拆分

原先的架构长文已经按“概览 / 生命周期 / 设计原则”拆分到 `docs/architecture/` 目录。

建议改为阅读以下文件：

1. [`architecture/overview.md`](architecture/overview.md)：系统定位、边界、三层模型、核心 contracts
2. [`architecture/runtime-lifecycle.md`](architecture/runtime-lifecycle.md)：`run_turn()` 生命周期、事件顺序、状态变化
3. [`architecture/design-principles.md`](architecture/design-principles.md)：契约优先、能力矩阵、禁止 silent drop、一致性测试

如果你是第一次阅读 `tada-core`，建议从 [`architecture/overview.md`](architecture/overview.md) 开始。
