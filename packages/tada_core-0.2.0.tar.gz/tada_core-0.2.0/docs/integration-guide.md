# 接入指南已拆分

原先的接入长文已经拆分到 `docs/integration/` 目录，按“接入主线 / 自定义模型接入 / 排障”分开组织。

建议改为阅读以下文件：

1. [`integration/human-guide.md`](integration/human-guide.md)：最小可工作的宿主接入路径
2. [`integration/custom-provider.md`](integration/custom-provider.md)：如何实现自定义 `ModelClient` 并跑验证
3. [`integration/troubleshooting.md`](integration/troubleshooting.md)：常见 `ModelClient`、事件流与运行问题

如果你当前的目标是把某个宿主系统真正接上 `tada-core`，建议从 [`integration/human-guide.md`](integration/human-guide.md) 开始。
