import pubchempy as pcp # type: ignore
import rdkit as rd
from rdkit import Chem 
import pandas as pd #type: ignore
from organomind.data.functional_groups_data import functional_groups

def detect_functional_groups(smiles, return_df = True):
    """
    Finds functional groups if present.
    Args:
        smiles (str): SMILES string of the molecule.
    Returns:
        dict: A dictionay of detected functional groups and the amount of times.
    """
    mol = Chem.MolFromSmiles(smiles)
   
    groups_present={}
    
    if mol is None:
        raise ValueError("Invalid Molecule inserted.")

    for group, smart in functional_groups.items():
        pattern=Chem.MolFromSmarts(smart)
        matches=mol.GetSubstructMatches(pattern)
        
        if len (matches)>0:
            groups_present[group]={
                "amount": len(matches),
                "position": matches
            }

    return groups_present

def detect_functional_groups_df(smiles):
    group_df = detect_functional_groups(smiles)
    df = pd.DataFrame([{"Functional Group": group, "Count": data["amount"], "Position": data["position"]} for group, data in group_df.items()])

    return df