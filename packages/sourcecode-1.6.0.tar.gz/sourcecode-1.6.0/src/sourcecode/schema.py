from __future__ import annotations

"""Output schema v1.0 for sourcecode.

Stable public contract — phase 2 detectors write into SourceMap.stacks.
Fields stacks, project_type, and entry_points are empty/null in phase 1.

File tree convention (D-01, D-02):
  - None = file
  - dict = directory (empty or with children)
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal, Optional


def _now_utc() -> str:
    """Return ISO 8601 UTC timestamp with +00:00 offset."""
    return datetime.now(timezone.utc).isoformat()


def _sourcecode_version() -> str:
    from sourcecode import __version__
    return __version__


@dataclass
class AnalysisMetadata:
    """Analysis metadata — always present in output."""

    schema_version: str = "1.0"
    generated_at: str = field(default_factory=_now_utc)
    sourcecode_version: str = field(default_factory=_sourcecode_version)
    analyzed_path: str = ""
    analyzer_fingerprints: dict[str, str] = field(default_factory=dict)
    traversal_topology: Optional[dict[str, Any]] = None


@dataclass
class FrameworkDetection:
    """Framework detected within a stack."""

    name: str
    source: str = "manifest"
    confidence: Literal["high", "medium", "low"] = "high"
    detected_via: list[str] = field(default_factory=list)
    version: Optional[str] = None  # e.g. "2.7.18" for Spring Boot


@dataclass
class StackDetection:
    """Detected technology stack."""

    stack: str
    detection_method: Literal["manifest", "lockfile", "heuristic"] = "manifest"
    confidence: Literal["high", "medium", "low"] = "high"
    frameworks: list[FrameworkDetection] = field(default_factory=list)
    package_manager: Optional[str] = None
    manifests: list[str] = field(default_factory=list)
    primary: bool = False
    root: Optional[str] = None
    workspace: Optional[str] = None
    signals: list[str] = field(default_factory=list)
    produced_by: Optional[str] = None  # which detector emitted this
    # Java-specific fields (FIX-6, FIX-7)
    language_version: Optional[str] = None   # e.g. "1.8" from maven.compiler.source
    packaging: Optional[str] = None          # e.g. "war" | "jar"
    app_server_hint: Optional[str] = None    # e.g. "weblogic" | "wildfly"
    spring_profiles: list[str] = field(default_factory=list)  # detected Spring profiles


@dataclass
class EntryPoint:
    """Detected project entry point."""

    path: str
    stack: str
    kind: str = "entry"
    source: str = "manifest"
    confidence: Literal["high", "medium", "low"] = "high"
    reason: Optional[str] = None   # console_script | entry_file_pattern | main_guard | typer_app | heuristic | convention
    evidence: Optional[str] = None  # brief evidence string
    entrypoint_type: Optional[Literal["production", "development", "benchmark", "example"]] = None
    classification: Optional[Literal["production", "development", "auxiliary"]] = None
    runtime_relevance: Optional[Literal["high", "medium", "low"]] = None
    produced_by: Optional[str] = None  # which detector emitted this
    http_path: Optional[str] = None  # extracted from @RequestMapping / @GetMapping (Java REST controllers)


@dataclass
class DependencyRecord:
    """Detected project dependency."""

    name: str
    ecosystem: str
    scope: str = "direct"
    declared_version: Optional[str] = None
    resolved_version: Optional[str] = None
    source: str = "manifest"
    parent: Optional[str] = None
    manifest_path: Optional[str] = None
    workspace: Optional[str] = None
    role: Optional[str] = None  # runtime | parsing | serialization | buildtool | observability | infra | devtool | testtool | unknown


@dataclass
class DependencySummary:
    """Dependency analysis summary."""

    requested: bool = False
    total_count: int = 0
    direct_count: int = 0
    transitive_count: int = 0
    ecosystems: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    dependencies: list["DependencyRecord"] = field(default_factory=list)


@dataclass
class GraphNode:
    """Node in the structural module graph."""

    id: str
    kind: str
    language: str
    path: str
    symbol: Optional[str] = None
    display_name: Optional[str] = None
    workspace: Optional[str] = None
    importance: Optional[Literal["high", "medium", "low"]] = None


@dataclass
class GraphEdge:
    """Edge in the structural module graph."""

    source: str
    target: str
    kind: str
    confidence: Literal["high", "medium", "low"] = "medium"
    method: Literal["ast", "heuristic", "unresolved"] = "heuristic"


@dataclass
class ModuleGraphSummary:
    """Structural module graph analysis summary."""

    requested: bool = False
    node_count: int = 0
    edge_count: int = 0
    languages: list[str] = field(default_factory=list)
    methods: list[str] = field(default_factory=list)
    main_flows: list[str] = field(default_factory=list)
    layers: list[str] = field(default_factory=list)
    entry_points_count: int = 0
    truncated: bool = False
    detail: Optional[Literal["high", "medium", "full"]] = None
    max_nodes_applied: Optional[int] = None
    edge_kinds: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    hubs: list[str] = field(default_factory=list)
    orphans: list[str] = field(default_factory=list)
    cycle_count: int = 0


@dataclass
class ModuleGraph:
    """Module, symbol, and relationship graph for the project."""

    nodes: list[GraphNode] = field(default_factory=list)
    edges: list[GraphEdge] = field(default_factory=list)
    summary: ModuleGraphSummary = field(default_factory=ModuleGraphSummary)


DocsDepth = Literal["module", "symbols", "full"]

MetricAvailability = Literal["measured", "inferred", "unavailable"]


@dataclass
class FileMetrics:
    """Code quality metrics for a single source file."""

    path: str
    language: str
    is_test: bool = False
    production_target: Optional[str] = None
    total_lines: int = 0
    code_lines: int = 0
    blank_lines: int = 0
    comment_lines: int = 0
    loc_availability: MetricAvailability = "unavailable"
    function_count: int = 0
    class_count: int = 0
    symbol_availability: MetricAvailability = "unavailable"
    cyclomatic_complexity: Optional[float] = None
    complexity_availability: MetricAvailability = "unavailable"
    line_rate: Optional[float] = None
    branch_rate: Optional[float] = None
    coverage_source: Optional[str] = None
    coverage_availability: MetricAvailability = "unavailable"
    workspace: Optional[str] = None


@dataclass
class CoverageRecord:
    """Coverage record extracted from a coverage report file."""

    source_file: str
    format: str
    line_rate: Optional[float] = None
    branch_rate: Optional[float] = None
    lines_covered: Optional[int] = None
    lines_valid: Optional[int] = None
    timestamp: Optional[str] = None
    tool_version: Optional[str] = None
    file_count: int = 0


@dataclass
class MetricsSummary:
    """Code quality metrics analysis summary."""

    requested: bool = False
    file_count: int = 0
    test_file_count: int = 0
    languages: list[str] = field(default_factory=list)
    total_loc: int = 0
    coverage_records: list[CoverageRecord] = field(default_factory=list)
    coverage_sources_found: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    ddd_module_metrics: list[dict] = field(default_factory=list)


@dataclass
class DocRecord:
    """Documentation record extracted from a code symbol."""

    symbol: str
    kind: str
    language: str
    path: str
    doc_text: Optional[str] = None
    signature: Optional[str] = None
    source: str = "unavailable"
    importance: Literal["high", "medium", "low"] = "medium"
    workspace: Optional[str] = None


@dataclass
class DocSummary:
    """Extracted documentation analysis summary."""

    requested: bool = False
    total_count: int = 0
    symbol_count: int = 0
    languages: list[str] = field(default_factory=list)
    depth: Optional[DocsDepth] = None
    truncated: bool = False
    limitations: list[str] = field(default_factory=list)
    # Per-language support status: "supported" | "unsupported" | "partial"
    # Absent key = language not present in scanned files.
    language_coverage: dict[str, str] = field(default_factory=dict)


@dataclass
class SymbolRecord:
    """Symbol definition found in a source file."""

    symbol: str               # local name: "MyClass" or "my_func"
    kind: str                 # "function" | "class" | "constant" | "method"
    language: str
    path: str                 # relative path to defining file
    line: Optional[int] = None
    qualified_name: Optional[str] = None  # "pkg.module.MyClass"
    exported: bool = True     # False if name starts with _ and no __all__ override
    workspace: Optional[str] = None


@dataclass
class CallRecord:
    """A resolved call from one symbol to another, possibly across files."""

    caller_path: str
    caller_symbol: str
    callee_path: str
    callee_symbol: str
    call_line: Optional[int] = None
    confidence: Literal["high", "medium", "low"] = "medium"
    method: Literal["ast", "heuristic", "unresolved"] = "heuristic"
    args: list[str] = field(default_factory=list)
    kwargs: dict[str, str] = field(default_factory=dict)
    workspace: Optional[str] = None


@dataclass
class SymbolLink:
    """A symbol imported in one file, resolved to its definition in another."""

    importer_path: str
    symbol: str
    source_path: Optional[str] = None
    source_line: Optional[int] = None
    is_external: bool = False
    confidence: Literal["high", "medium", "low"] = "high"
    method: Literal["ast", "heuristic", "unresolved"] = "ast"
    workspace: Optional[str] = None


@dataclass
class SemanticSummary:
    """Summary of the --semantics analysis."""

    requested: bool = False
    # Explicit analysis outcome — never omit, never silent.
    # "ok": analysis ran and produced results
    # "partial": analysis ran but with significant coverage gaps
    # "failed": analysis could not produce useful results
    status: str = "ok"
    reason: Optional[str] = None        # human-readable failure/partial reason
    call_count: int = 0
    symbol_count: int = 0
    link_count: int = 0
    languages: list[str] = field(default_factory=list)
    language_coverage: dict[str, str] = field(default_factory=dict)
    # Structured per-language support details. Each value:
    # {"supported": bool, "status": str, "reason": str}
    # status: "full" | "heuristic" | "unsupported"
    language_coverage_details: dict[str, Any] = field(default_factory=dict)
    files_analyzed: int = 0
    files_skipped: int = 0
    truncated: bool = False
    limitations: list[str] = field(default_factory=list)
    # Ranked hotspots by fan-in/fan-out (populated after analysis)
    hotspots: list[dict] = field(default_factory=list)
    # Coverage percentage: files_analyzed / total source files in repo
    coverage_pct: Optional[float] = None
    coverage_confidence: str = "unknown"


# --- Runtime Architecture ---

ArchitecturalRole = Literal[
    "runtime_core",
    "plugin_host",
    "plugin_package",
    "frontend_runtime",
    "backend_runtime",
    "composition_layer",
    "infrastructure_layer",
    "tooling_layer",
    "docs_layer",
    "test_layer",
    "benchmark_layer",
    "unknown",
]


@dataclass
class MonorepoPackageInfo:
    """Classified workspace package with architectural role and criticality."""

    path: str
    name: str
    architectural_role: str  # ArchitecturalRole value
    criticality: Literal["high", "medium", "low"] = "low"
    confidence: Literal["high", "medium", "low"] = "low"
    role_signals: list[str] = field(default_factory=list)


# --- Phase 13 Plan 04: Architectural Inference ---

@dataclass
class ArchitectureDomain:
    """Inferred functional domain from code structure."""

    name: str
    files: list[str] = field(default_factory=list)
    role: str = ""
    confidence: Literal["high", "medium", "low"] = "low"


@dataclass
class ArchitectureLayer:
    """Detected architectural layer."""

    name: str
    pattern: str
    files: list[str] = field(default_factory=list)
    confidence: Literal["high", "medium", "low"] = "low"


@dataclass
class BoundedContext:
    """Approximate bounded context inferred from code structure."""

    name: str
    modules: list[str] = field(default_factory=list)
    entry_files: list[str] = field(default_factory=list)
    confidence: Literal["high", "medium", "low"] = "low"


@dataclass
class ArchitectureAnalysis:
    """Complete architectural analysis result."""

    requested: bool = False
    pattern: Optional[str] = None
    domains: list[ArchitectureDomain] = field(default_factory=list)
    layers: list[ArchitectureLayer] = field(default_factory=list)
    bounded_contexts: list[BoundedContext] = field(default_factory=list)
    confidence: Literal["high", "medium", "low"] = "low"
    method: str = "heuristic"
    limitations: list[str] = field(default_factory=list)
    # Structured evidence for each architectural inference.
    # Each entry: {"type": str, "paths": list[str], "reason": str, "confidence": str}
    # type: "workspace_config" | "filesystem_naming" | "import_graph" | "entry_files"
    evidence: list[dict] = field(default_factory=list)
    # True when pattern is inferred from weak signals (e.g. directory names only).
    # Agents must not treat tentative patterns as confirmed facts.
    tentative: bool = False
    ddd_layers_detected: list[str] = field(default_factory=list)  # e.g. ["application", "domain", "infrastructure"]


# --- Env Map ---

@dataclass
class EnvVarRecord:
    """Environment variable referenced in project code."""

    key: str
    required: bool = True
    default: Optional[str] = None
    type_hint: Optional[str] = None   # string | int | bool | url | path | enum
    category: Optional[str] = None    # database | cache | storage | auth | service | observability | feature_flag | server | general | application
    description: Optional[str] = None
    files: list[str] = field(default_factory=list)  # "path:line"
    profile: Optional[str] = None     # Spring profile if first occurrence is in application-{profile}.yml
    source: Optional[str] = None      # yml_property | env_var | source_code


@dataclass
class EnvSummary:
    """Environment variable analysis summary."""

    requested: bool = False
    total: int = 0
    required_count: int = 0
    optional_count: int = 0
    categories: list[str] = field(default_factory=list)
    example_files_found: list[str] = field(default_factory=list)
    limitations: list[str] = field(default_factory=list)
    # Spring Boot coverage metadata
    profiles_scanned: list[str] = field(default_factory=list)
    spring_candidates: int = 0   # total ${VAR} refs found across Spring config files
    coverage_note: Optional[str] = None  # explicit note about partial coverage
    spring_profiles: list[str] = field(default_factory=list)  # canonical list: profile names from application-{profile}.yml


# --- Code Notes ---

@dataclass
class CodeNote:
    """Inline code annotation: TODO, FIXME, HACK, NOTE, DEPRECATED, WARNING, XXX, BUG, OPTIMIZE."""

    kind: str                   # TODO | FIXME | HACK | NOTE | DEPRECATED | WARNING | XXX | BUG | OPTIMIZE
    path: str                   # relative path to file
    line: int                   # line number (1-based)
    text: str                   # annotation text (truncated to 200 chars)
    symbol: Optional[str] = None  # nearest enclosing function or class


@dataclass
class AdrRecord:
    """Architecture Decision Record detected in the repository."""

    path: str
    title: str
    status: Optional[str] = None    # accepted | proposed | deprecated | superseded
    summary: Optional[str] = None   # first paragraph of the ADR


@dataclass
class CodeNotesSummary:
    """Code annotations and ADR analysis summary."""

    requested: bool = False
    total: int = 0
    by_kind: dict[str, int] = field(default_factory=dict)
    top_files: list[str] = field(default_factory=list)   # files with the most notes
    adr_count: int = 0
    limitations: list[str] = field(default_factory=list)


# --- Context Summary for AI agents ---

@dataclass
class ContextSummary:
    """Compact, high-signal context for AI agents. Generated from all available analysis."""

    requested: bool = True
    runtime_shape: str = ""                          # "REST API (FastAPI + PostgreSQL)"
    dominant_pattern: Optional[str] = None           # "Clean Architecture", "MVC", etc.
    critical_modules: list[str] = field(default_factory=list)   # hub paths + entry paths
    layer_map: dict[str, list[str]] = field(default_factory=dict)  # {"domain": ["src/domain/"]}
    edit_hints: list[str] = field(default_factory=list)  # "auth → src/auth/, tests/"
    coupling_notes: list[str] = field(default_factory=list)  # "2 import cycles", "hub: schema.py"


# --- Pipeline Trace ---

@dataclass
class PipelineEvent:
    """Single event in the pipeline trace."""

    stage: str       # "scan" | "detect" | "merge" | "confidence" | "output"
    component: str   # detector name or analyzer name
    action: str      # "emit_stack" | "emit_ep" | "filter_ep" | "discard_ep" | "computed"
    target: Optional[str] = None   # path or stack name
    reason: Optional[str] = None   # human-readable explanation


@dataclass
class PipelineTrace:
    """Full trace of what each pipeline stage produced or discarded."""

    requested: bool = False
    events: list[PipelineEvent] = field(default_factory=list)


# --- Confidence & Explainability ---

@dataclass
class ConfidenceSummary:
    """Analysis confidence and quality summary."""

    overall: Literal["high", "medium", "low"] = "medium"
    stack_confidence: Literal["high", "medium", "low"] = "medium"
    entry_point_confidence: Literal["high", "medium", "low"] = "medium"
    hard_signals: list[str] = field(default_factory=list)   # manifest, lockfile, real entrypoint
    soft_signals: list[str] = field(default_factory=list)   # heuristic, extension-based
    ignored_signals: list[str] = field(default_factory=list)  # tooling dirs, aux manifests
    anomalies: list[str] = field(default_factory=list)


@dataclass
class AnalysisGap:
    """Gap or uncertainty detected in the analysis."""

    area: str   # entry_points | dependencies | stack | architecture | env
    reason: str
    impact: Literal["high", "medium", "low"] = "medium"


# --- Git Context ---

@dataclass
class CommitRecord:
    """A recent repository commit."""

    hash: str
    message: str
    author: str
    date: str
    files_changed: list[str] = field(default_factory=list)


@dataclass
class ChangeHotspot:
    """File with the highest change frequency in the time window."""

    file: str
    commit_count: int
    last_changed: str


@dataclass
class UncommittedChanges:
    """Pending changes in the working tree."""

    staged: list[str] = field(default_factory=list)
    unstaged: list[str] = field(default_factory=list)
    untracked: list[str] = field(default_factory=list)


@dataclass
class GitContext:
    """Git repository temporal context."""

    requested: bool = False
    branch: Optional[str] = None
    recent_commits: list[CommitRecord] = field(default_factory=list)
    change_hotspots: list[ChangeHotspot] = field(default_factory=list)
    # Explicit hotspot analysis outcome — distinguishes "no hotspots found" from "analysis failed".
    # "ok": hotspot analysis ran (change_hotspots may still be empty if no changes in window)
    # "failed": hotspot analysis threw an exception (see limitations for hotspots_error:...)
    hotspots_status: str = "ok"
    uncommitted_changes: Optional[UncommittedChanges] = None
    contributors: list[str] = field(default_factory=list)
    git_summary: Optional[str] = None
    limitations: list[str] = field(default_factory=list)


@dataclass
class SourceMap:
    """Complete output schema v1.0.

    Detection fields (stacks, project_type, entry_points) are empty/null
    in phase 1 and populated from phase 2 onwards.

    file_tree follows convention D-01/D-02:
      - None = file
      - dict = directory
    """

    metadata: AnalysisMetadata = field(default_factory=AnalysisMetadata)
    file_tree: dict[str, Any] = field(default_factory=dict)
    stacks: list[StackDetection] = field(default_factory=list)
    project_type: Optional[str] = None                    # populated in phase 3
    entry_points: list[EntryPoint] = field(default_factory=list)
    dependencies: list[DependencyRecord] = field(default_factory=list)
    dependency_summary: Optional[DependencySummary] = None
    module_graph: Optional[ModuleGraph] = None
    module_graph_summary: Optional[ModuleGraphSummary] = None
    docs: list[DocRecord] = field(default_factory=list)
    doc_summary: Optional[DocSummary] = None
    # Phase 9: LLM Output Quality
    file_paths: list[str] = field(default_factory=list)
    project_summary: Optional[str] = None
    architecture_summary: Optional[str] = None
    key_dependencies: list[DependencyRecord] = field(default_factory=list)
    # Phase 10: Code Quality Metrics
    file_metrics: list[FileMetrics] = field(default_factory=list)
    metrics_summary: Optional[MetricsSummary] = None
    # Phase 12: Static Semantics
    semantic_calls: list[CallRecord] = field(default_factory=list)
    semantic_symbols: list[SymbolRecord] = field(default_factory=list)
    semantic_links: list[SymbolLink] = field(default_factory=list)
    semantic_summary: Optional[SemanticSummary] = None
    # Phase 13 Plan 04: Architectural Inference
    architecture: Optional[ArchitectureAnalysis] = None
    # Git Context
    git_context: Optional[GitContext] = None
    # Env Map
    env_map: list[EnvVarRecord] = field(default_factory=list)
    env_summary: Optional[EnvSummary] = None
    # Code Notes
    code_notes: list[CodeNote] = field(default_factory=list)
    code_adrs: list[AdrRecord] = field(default_factory=list)
    code_notes_summary: Optional[CodeNotesSummary] = None
    # Confidence & Explainability (v0.26.0)
    confidence_summary: Optional[ConfidenceSummary] = None
    analysis_gaps: list[AnalysisGap] = field(default_factory=list)
    # AI context summary (v0.26.0)
    context_summary: Optional[ContextSummary] = None
    # Runtime architecture (v0.26.0)
    monorepo_packages: list[MonorepoPackageInfo] = field(default_factory=list)
    # Pipeline trace (v0.29.0) — populated only when --trace-pipeline is passed
    pipeline_trace: Optional[PipelineTrace] = None
    # AST contract mode (v0.33.0) — populated when --mode contract|hybrid
    file_contracts: list[Any] = field(default_factory=list)   # list[FileContract]
    contract_summary: Optional[Any] = None                    # ContractSummary
    # Java-specific root fields (v1.3.0) — additive, null/empty for non-Java projects
    packaging: Optional[str] = None           # "war" | "jar"
    language_version: Optional[str] = None    # "1.8" | "11" | "17"
    spring_profiles: list[str] = field(default_factory=list)
    app_server_hint: Optional[str] = None     # "weblogic" | "wildfly" | "tomcat"
