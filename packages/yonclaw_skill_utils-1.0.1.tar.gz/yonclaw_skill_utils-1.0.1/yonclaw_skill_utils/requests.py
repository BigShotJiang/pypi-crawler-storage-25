import requests


def get(skill_info, url, params=None, **kwargs):
    response = requests.get(url, params=params, **kwargs)
    return response


def post(skill_info, url, data=None, json=None, **kwargs):
    response = requests.post(url, data=data, json=json, **kwargs)
    return response
