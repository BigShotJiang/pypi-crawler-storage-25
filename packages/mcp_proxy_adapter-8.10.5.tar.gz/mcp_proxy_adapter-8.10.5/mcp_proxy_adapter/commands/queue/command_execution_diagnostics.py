"""
Helpers for explicit command_execution fields on queue API responses.

Author: Vasiliy Zdanovskiy
"""

from __future__ import annotations

from typing import Any, Dict


def build_command_execution_fields(outer_status: str, result: Any) -> Dict[str, Any]:
    """
    Build job_success / command_execution diagnostic fields.

    Does not alter nested ``result`` shape.
    """
    job_success = outer_status == "completed"
    base: Dict[str, Any] = {
        "job_success": job_success,
        "command_execution": False,
        "command_name": None,
        "command_success": None,
        "inner_success": None,
        "completed_with_error": False,
    }

    if not isinstance(result, dict):
        return base

    if "command" not in result or "result" not in result:
        return base

    inner = result.get("result")
    base["command_execution"] = True
    cmd = result.get("command")
    base["command_name"] = cmd if isinstance(cmd, str) else (str(cmd) if cmd is not None else None)

    if isinstance(inner, dict):
        inner_ok = bool(inner.get("success"))
    else:
        inner_ok = False

    base["command_success"] = inner_ok
    base["inner_success"] = inner_ok
    base["completed_with_error"] = bool(
        outer_status == "completed" and base["command_execution"] and not inner_ok
    )
    return base


def list_job_command_execution_fields(job_result: Any) -> Dict[str, Any]:
    """
    Diagnostics for one job row in ``queue_list_jobs`` (cheap, read-only).
    """
    result = getattr(job_result, "result", None) or {}
    outer_status = getattr(job_result, "status", "") or ""
    fields = build_command_execution_fields(outer_status, result)
    err = getattr(job_result, "error", None)
    return {
        **fields,
        "has_result": bool(result),
        "has_error": bool(err),
    }
