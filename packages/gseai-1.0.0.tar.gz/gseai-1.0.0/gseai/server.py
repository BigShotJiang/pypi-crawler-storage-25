"""Client for the GSE AI LocalAI server's OpenAI-compatible REST API."""

from collections.abc import Generator
from contextlib import ExitStack
from pathlib import Path
from typing import Any

import httpx


class GSEAIServer:
    """Client for the GSE AI LocalAI server.

    Args:
        api_token: Bearer token for authentication.
        host: Hostname of the server.
        port: Port the server listens on.
        timeout: Request timeout in seconds. ``None`` (default) means no timeout,
            which is recommended for slow models.
    """

    def __init__(
        self,
        api_token: str,
        host: str = "gseai.gse.buffalo.edu",
        port: int = 11434,
        timeout: float | None = None,
    ) -> None:
        self.base_url = f"http://{host}:{port}"
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_token}"},
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -------------------------------------------------------------------------
    # OpenAI-compatible endpoints  (/v1/)
    # -------------------------------------------------------------------------

    def list_models(self) -> dict:
        """GET /v1/models — list available models."""
        return self._client.get("/v1/models").raise_for_status().json()

    def chat(
        self,
        model: str,
        prompt: str,
        *,
        system_prompt: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stream: bool = False,
    ) -> dict | Generator[dict, None, None]:
        """Convenience wrapper for single-turn chat.

        Args:
            model: Model identifier.
            prompt: User message as a plain string.
            system_prompt: Optional system message.
            temperature: Sampling temperature (0–2).
            max_tokens: Maximum tokens to generate.
            stream: If True, return a generator of SSE event dicts.

        Returns:
            Response dict, or a generator of SSE event dicts when ``stream=True``.
        """
        messages: list[dict] = []
        if system_prompt is not None:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        return self.chat_completions(
            model,
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
        )

    def chat_completions(
        self,
        model: str,
        messages: list[dict],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stream: bool = False,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        repeat_penalty: float | None = None,
        logit_bias: dict | None = None,
        seed: int | None = None,
        response_format: dict | None = None,
        tools: list[dict] | None = None,
        tool_choice: str | None = None,
    ) -> dict | Generator[dict, None, None]:
        """POST /v1/chat/completions — OpenAI-compatible chat completions.

        Args:
            model: Model identifier.
            messages: List of message dicts with ``role`` and ``content``.
            temperature: Sampling temperature (0–2).
            max_tokens: Maximum tokens to generate.
            stream: If True, return a generator of SSE event dicts.
            top_p: Nucleus sampling (0–1).
            top_k: Top-k sampling limit.
            stop: Stop sequence(s).
            presence_penalty: Presence penalty (-2 to 2).
            frequency_penalty: Frequency penalty (-2 to 2).
            repeat_penalty: Repetition penalty.
            logit_bias: Token probability bias adjustments.
            seed: Random seed for reproducibility.
            response_format: JSON schema for structured output.
            tools: Function definitions for tool/function calling.
            tool_choice: Tool selection mode — "auto", "none", or "required".
        """
        body: dict[str, Any] = {"model": model, "messages": messages}
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if top_p is not None:
            body["top_p"] = top_p
        if top_k is not None:
            body["top_k"] = top_k
        if stop is not None:
            body["stop"] = stop
        if presence_penalty is not None:
            body["presence_penalty"] = presence_penalty
        if frequency_penalty is not None:
            body["frequency_penalty"] = frequency_penalty
        if repeat_penalty is not None:
            body["repeat_penalty"] = repeat_penalty
        if logit_bias is not None:
            body["logit_bias"] = logit_bias
        if seed is not None:
            body["seed"] = seed
        if response_format is not None:
            body["response_format"] = response_format
        if tools is not None:
            body["tools"] = tools
        if tool_choice is not None:
            body["tool_choice"] = tool_choice

        if stream:
            body["stream"] = True
            return self._stream_sse("/v1/chat/completions", body)
        else:
            return (
                self._client.post("/v1/chat/completions", json=body).raise_for_status().json()
            )

    def completions(
        self,
        model: str,
        prompt: str | list,
        *,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        stream: bool = False,
        seed: int | None = None,
    ) -> dict | Generator[dict, None, None]:
        """POST /v1/completions — legacy text completions.

        Args:
            model: Model identifier.
            prompt: Input text or list of texts.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature (0–2).
            top_p: Nucleus sampling (0–1).
            top_k: Top-k sampling limit.
            stop: Stop sequence(s).
            frequency_penalty: Frequency penalty (-2 to 2).
            presence_penalty: Presence penalty (-2 to 2).
            stream: If True, return a generator of SSE event dicts.
            seed: Random seed.
        """
        body: dict[str, Any] = {"model": model, "prompt": prompt}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if temperature is not None:
            body["temperature"] = temperature
        if top_p is not None:
            body["top_p"] = top_p
        if top_k is not None:
            body["top_k"] = top_k
        if stop is not None:
            body["stop"] = stop
        if frequency_penalty is not None:
            body["frequency_penalty"] = frequency_penalty
        if presence_penalty is not None:
            body["presence_penalty"] = presence_penalty
        if seed is not None:
            body["seed"] = seed

        if stream:
            body["stream"] = True
            return self._stream_sse("/v1/completions", body)
        else:
            return self._client.post("/v1/completions", json=body).raise_for_status().json()

    def embeddings(
        self,
        model: str,
        input: str | list[str],
        *,
        encoding_format: str | None = None,
        dimensions: int | None = None,
    ) -> dict:
        """POST /v1/embeddings — generate text embeddings.

        Args:
            model: Model identifier.
            input: Text or list of texts to embed.
            encoding_format: Output format — "float" or "base64".
            dimensions: Target embedding dimensionality.
        """
        body: dict[str, Any] = {"model": model, "input": input}
        if encoding_format is not None:
            body["encoding_format"] = encoding_format
        if dimensions is not None:
            body["dimensions"] = dimensions
        return self._client.post("/v1/embeddings", json=body).raise_for_status().json()

    def responses(
        self,
        model: str,
        messages: list[dict],
        **kwargs: Any,
    ) -> dict:
        """POST /v1/responses — stateful chat responses (OpenAI-compatible).

        Args:
            model: Model identifier.
            messages: List of message dicts with ``role`` and ``content``.
            **kwargs: Additional parameters forwarded to the endpoint.
        """
        body: dict[str, Any] = {"model": model, "messages": messages, **kwargs}
        return self._client.post("/v1/responses", json=body).raise_for_status().json()

    # -------------------------------------------------------------------------
    # Anthropic-compatible endpoint  (/v1/messages)
    # -------------------------------------------------------------------------

    def messages(
        self,
        model: str,
        messages: list[dict],
        max_tokens: int,
        *,
        system: str | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
    ) -> dict:
        """POST /v1/messages — Anthropic-compatible messages API.

        Args:
            model: Model identifier.
            messages: List of message dicts with ``role`` and ``content``.
            max_tokens: Maximum tokens to generate (required by the API).
            system: System prompt.
            temperature: Sampling temperature.
            top_p: Nucleus sampling (0–1).
            top_k: Top-k sampling limit.
        """
        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
        }
        if system is not None:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature
        if top_p is not None:
            body["top_p"] = top_p
        if top_k is not None:
            body["top_k"] = top_k
        return self._client.post("/v1/messages", json=body).raise_for_status().json()

    # -------------------------------------------------------------------------
    # Audio endpoints  (/v1/audio/)
    # -------------------------------------------------------------------------

    def transcribe(
        self,
        model: str,
        file_path: str,
        *,
        language: str | None = None,
        prompt: str | None = None,
        response_format: str = "json",
    ) -> dict | str:
        """POST /v1/audio/transcriptions — transcribe audio to text.

        Args:
            model: Whisper model identifier.
            file_path: Path to the audio file.
            language: Source language code (e.g. ``"en"``); auto-detected if omitted.
            prompt: Optional context hint passed to the model.
            response_format: One of ``"json"``, ``"verbose_json"``, ``"text"``,
                ``"srt"``, or ``"vtt"`` (default ``"json"``).

        Returns:
            Parsed dict for JSON formats, plain text string otherwise.
        """
        data: dict[str, Any] = {"model": model, "response_format": response_format}
        if language is not None:
            data["language"] = language
        if prompt is not None:
            data["prompt"] = prompt
        with open(file_path, "rb") as f:
            response = self._client.post(
                "/v1/audio/transcriptions",
                files={"file": (Path(file_path).name, f)},
                data=data,
            ).raise_for_status()
        if response_format in ("json", "verbose_json"):
            return response.json()
        return response.text

    def translate(
        self,
        model: str,
        file_path: str,
        *,
        prompt: str | None = None,
        response_format: str = "json",
    ) -> dict | str:
        """POST /v1/audio/translations — transcribe audio and translate to English.

        Args:
            model: Whisper model identifier.
            file_path: Path to the audio file.
            prompt: Optional context hint passed to the model.
            response_format: One of ``"json"``, ``"verbose_json"``, ``"text"``,
                ``"srt"``, or ``"vtt"`` (default ``"json"``).

        Returns:
            Parsed dict for JSON formats, plain text string otherwise.
        """
        data: dict[str, Any] = {"model": model, "response_format": response_format}
        if prompt is not None:
            data["prompt"] = prompt
        with open(file_path, "rb") as f:
            response = self._client.post(
                "/v1/audio/translations",
                files={"file": (Path(file_path).name, f)},
                data=data,
            ).raise_for_status()
        if response_format in ("json", "verbose_json"):
            return response.json()
        return response.text

    def speech(
        self,
        model: str,
        input: str,
        *,
        voice: str | None = None,
        speed: float | None = None,
    ) -> bytes:
        """POST /v1/audio/speech — synthesize speech from text.

        Args:
            model: TTS model identifier.
            input: Text to synthesize.
            voice: Voice identifier.
            speed: Playback speed multiplier (default ``1.0``).

        Returns:
            Raw audio bytes.
        """
        body: dict[str, Any] = {"model": model, "input": input}
        if voice is not None:
            body["voice"] = voice
        if speed is not None:
            body["speed"] = speed
        return self._client.post("/v1/audio/speech", json=body).raise_for_status().content

    # -------------------------------------------------------------------------
    # Image endpoints  (/v1/images/)
    # -------------------------------------------------------------------------

    def generate_image(
        self,
        model: str,
        prompt: str,
        *,
        n: int | None = None,
        size: str | None = None,
        steps: int | None = None,
        seed: int | None = None,
    ) -> dict:
        """POST /v1/images/generations — generate images from a text prompt.

        Args:
            model: Image generation model identifier.
            prompt: Text description of the desired image.
            n: Number of images to generate.
            size: Output dimensions, e.g. ``"512x512"``.
            steps: Diffusion steps.
            seed: Random seed for reproducibility.
        """
        body: dict[str, Any] = {"model": model, "prompt": prompt}
        if n is not None:
            body["n"] = n
        if size is not None:
            body["size"] = size
        if steps is not None:
            body["steps"] = steps
        if seed is not None:
            body["seed"] = seed
        return self._client.post("/v1/images/generations", json=body).raise_for_status().json()

    def edit_image(
        self,
        model: str,
        image_path: str,
        prompt: str,
        *,
        mask_path: str | None = None,
        n: int | None = None,
        size: str | None = None,
    ) -> dict:
        """POST /v1/images/edits — edit an image guided by a text prompt.

        Args:
            model: Image model identifier.
            image_path: Path to the source image.
            prompt: Edit instruction.
            mask_path: Optional greyscale mask (white = region to edit).
            n: Number of variants to generate.
            size: Output dimensions, e.g. ``"512x512"``.
        """
        data: dict[str, Any] = {"model": model, "prompt": prompt}
        if n is not None:
            data["n"] = str(n)
        if size is not None:
            data["size"] = size
        with ExitStack() as stack:
            files: dict[str, Any] = {
                "image": (Path(image_path).name, stack.enter_context(open(image_path, "rb")))
            }
            if mask_path is not None:
                files["mask"] = (Path(mask_path).name, stack.enter_context(open(mask_path, "rb")))
            return self._client.post("/v1/images/edits", files=files, data=data).raise_for_status().json()

    def image_variation(
        self,
        model: str,
        image_path: str,
        *,
        n: int | None = None,
        size: str | None = None,
    ) -> dict:
        """POST /v1/images/variations — generate variations of an existing image.

        Args:
            model: Image model identifier.
            image_path: Path to the source image.
            n: Number of variations to generate.
            size: Output dimensions, e.g. ``"512x512"``.
        """
        data: dict[str, Any] = {"model": model}
        if n is not None:
            data["n"] = str(n)
        if size is not None:
            data["size"] = size
        with open(image_path, "rb") as f:
            return self._client.post(
                "/v1/images/variations",
                files={"image": (Path(image_path).name, f)},
                data=data,
            ).raise_for_status().json()

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _stream_sse(self, path: str, body: dict) -> Generator[dict, None, None]:
        """POST to *path* and yield parsed Server-Sent Event data dicts."""
        import json

        with self._client.stream("POST", path, json=body) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    payload = line[len("data: "):]
                    if payload == "[DONE]":
                        break
                    yield json.loads(payload)
