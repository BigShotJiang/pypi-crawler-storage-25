"""Command-line interface for the GSE AI LocalAI server."""

import base64
import json as json_mod
from pathlib import Path

import click
import httpx

from .server import GSEAIServer


def _save_images(data: list[dict], output: str, n: int) -> None:
    p = Path(output)
    stem, suffix = p.stem, p.suffix or ".png"
    for i, item in enumerate(data):
        filename = output if n == 1 else str(p.parent / f"{stem}_{i + 1}{suffix}")
        if "b64_json" in item:
            Path(filename).write_bytes(base64.b64decode(item["b64_json"]))
        elif "url" in item:
            Path(filename).write_bytes(httpx.get(item["url"]).content)
        click.echo(filename)


@click.group()
@click.option("-t", "--token", envvar="GSEAI_API_TOKEN", default=None, help="Bearer auth token.")
@click.option("-H", "--host", envvar="GSEAI_HOST", default="gseai.gse.buffalo.edu", show_default=True, help="Server hostname.")
@click.option("-p", "--port", envvar="GSEAI_PORT", default=11434, show_default=True, type=int, help="Server port.")
@click.option("-T", "--timeout", envvar="GSEAI_TIMEOUT", default=None, type=float, help="Request timeout in seconds (default: no timeout).")
@click.pass_context
def cli(ctx: click.Context, token: str | None, host: str, port: int, timeout: float | None) -> None:
    """GSE AI server CLI."""
    ctx.ensure_object(dict)
    ctx.obj["token"] = token
    ctx.obj["host"] = host
    ctx.obj["port"] = port
    ctx.obj["timeout"] = timeout


def _server(obj: dict) -> GSEAIServer:
    """Return a connected server, creating it on first call."""
    if "server" not in obj:
        if not obj.get("token"):
            raise click.ClickException(
                "Bearer token required. Set GSEAI_API_TOKEN or pass --token."
            )
        obj["server"] = GSEAIServer(obj["token"], host=obj["host"], port=obj["port"], timeout=obj.get("timeout"))
    return obj["server"]


# ---------------------------------------------------------------------------
# models
# ---------------------------------------------------------------------------

@cli.command("models")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON.")
@click.pass_obj
def models(obj: dict, as_json: bool) -> None:
    """List available models."""
    result = _server(obj).list_models()
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        for model in result.get("data", []):
            click.echo(model["id"])


# ---------------------------------------------------------------------------
# chat
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("model")
@click.argument("prompt", default=None, required=False)
@click.option("-f", "--file", "prompt_file", type=click.Path(exists=True, dir_okay=False), default=None, help="Read prompt from a file.")
@click.option("-i", "--interactive", is_flag=True, help="Start an interactive chat session.")
@click.option("-s", "--system", default=None, help="System prompt.")
@click.option("-t", "--temperature", type=float, default=None, help="Sampling temperature (0–2).")
@click.option("-m", "--max-tokens", type=int, default=None, help="Maximum tokens to generate.")
@click.option("-S", "--stream", is_flag=True, help="Stream output tokens.")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def chat(
    obj: dict,
    model: str,
    prompt: str | None,
    prompt_file: str | None,
    interactive: bool,
    system: str | None,
    temperature: float | None,
    max_tokens: int | None,
    stream: bool,
    as_json: bool,
) -> None:
    """Chat with a model. Prompt may be an argument, a file (-f), or interactive (-i)."""
    server: GSEAIServer = _server(obj)

    if interactive:
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        click.echo(f"Chatting with {model}. Ctrl+C or 'exit' to quit.")
        while True:
            try:
                user_input = input("> ")
            except (EOFError, KeyboardInterrupt):
                click.echo()
                break
            if user_input.strip().lower() in ("exit", "quit"):
                break
            if not user_input.strip():
                continue
            messages.append({"role": "user", "content": user_input})
            result = server.chat_completions(
                model, messages, temperature=temperature, max_tokens=max_tokens, stream=True
            )
            reply_parts: list[str] = []
            for event in result:
                delta = event.get("choices", [{}])[0].get("delta", {}).get("content", "")
                if delta:
                    click.echo(delta, nl=False)
                    reply_parts.append(delta)
            click.echo()
            reply = "".join(reply_parts)
            messages.append({"role": "assistant", "content": reply})
        return

    if prompt_file:
        prompt = Path(prompt_file).read_text()
    if not prompt:
        raise click.UsageError("Provide a PROMPT argument, --file, or --interactive.")

    result = server.chat(
        model,
        prompt,
        system_prompt=system,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=stream,
    )
    if stream:
        for event in result:
            delta = event.get("choices", [{}])[0].get("delta", {}).get("content", "")
            if delta:
                click.echo(delta, nl=False)
        click.echo()
    elif as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        click.echo(result["choices"][0]["message"]["content"])


# ---------------------------------------------------------------------------
# completions
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("model")
@click.argument("prompt")
@click.option("-t", "--temperature", type=float, default=None, help="Sampling temperature (0–2).")
@click.option("-m", "--max-tokens", type=int, default=None, help="Maximum tokens to generate.")
@click.option("-S", "--stream", is_flag=True, help="Stream output tokens.")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def completions(
    obj: dict,
    model: str,
    prompt: str,
    temperature: float | None,
    max_tokens: int | None,
    stream: bool,
    as_json: bool,
) -> None:
    """Legacy text completion."""
    server: GSEAIServer = _server(obj)
    result = server.completions(
        model,
        prompt,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=stream,
    )
    if stream:
        for event in result:
            text = event.get("choices", [{}])[0].get("text", "")
            if text:
                click.echo(text, nl=False)
        click.echo()
    elif as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        click.echo(result["choices"][0]["text"])


# ---------------------------------------------------------------------------
# embeddings
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("model")
@click.argument("text")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def embeddings(obj: dict, model: str, text: str, as_json: bool) -> None:
    """Generate an embedding vector for TEXT."""
    result = _server(obj).embeddings(model, text)
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        vector = result["data"][0]["embedding"]
        dims = len(vector)
        preview = ", ".join(f"{v:.4f}" for v in vector[:5])
        click.echo(f"model:      {result.get('model', model)}")
        click.echo(f"dimensions: {dims}")
        click.echo(f"values:     [{preview}, ...]")


# ---------------------------------------------------------------------------
# audio
# ---------------------------------------------------------------------------

@cli.group()
def audio() -> None:
    """Audio transcription, translation, and speech synthesis."""


@audio.command("transcribe")
@click.argument("model")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("-l", "--language", default=None, help="Source language code (e.g. en, fr).")
@click.option("-p", "--prompt", default=None, help="Context hint for the model.")
@click.option(
    "-f", "--format", "fmt",
    type=click.Choice(["text", "json", "verbose_json", "srt", "vtt"]),
    default="text",
    show_default=True,
    help="Response format.",
)
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON (overrides --format).")
@click.pass_obj
def audio_transcribe(
    obj: dict,
    model: str,
    file: str,
    language: str | None,
    prompt: str | None,
    fmt: str,
    as_json: bool,
) -> None:
    """Transcribe an audio FILE to text."""
    response_format = "verbose_json" if as_json else fmt
    result = _server(obj).transcribe(
        model, file, language=language, prompt=prompt, response_format=response_format
    )
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    elif isinstance(result, dict):
        click.echo(result.get("text", ""))
    else:
        click.echo(result)


@audio.command("translate")
@click.argument("model")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("-p", "--prompt", default=None, help="Context hint for the model.")
@click.option(
    "-f", "--format", "fmt",
    type=click.Choice(["text", "json", "verbose_json", "srt", "vtt"]),
    default="text",
    show_default=True,
    help="Response format.",
)
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def audio_translate(
    obj: dict,
    model: str,
    file: str,
    prompt: str | None,
    fmt: str,
    as_json: bool,
) -> None:
    """Transcribe an audio FILE and translate to English."""
    response_format = "verbose_json" if as_json else fmt
    result = _server(obj).translate(
        model, file, prompt=prompt, response_format=response_format
    )
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    elif isinstance(result, dict):
        click.echo(result.get("text", ""))
    else:
        click.echo(result)


@audio.command("speech")
@click.argument("model")
@click.argument("text")
@click.option("-o", "--output", default="speech.mp3", show_default=True, help="Output file path.")
@click.option("-v", "--voice", default=None, help="Voice identifier.")
@click.option("-s", "--speed", type=float, default=None, help="Playback speed (default 1.0).")
@click.pass_obj
def audio_speech(
    obj: dict,
    model: str,
    text: str,
    output: str,
    voice: str | None,
    speed: float | None,
) -> None:
    """Synthesize speech from TEXT and save to a file."""
    audio_bytes = _server(obj).speech(model, text, voice=voice, speed=speed)
    Path(output).write_bytes(audio_bytes)
    click.echo(output)


# ---------------------------------------------------------------------------
# images
# ---------------------------------------------------------------------------

@cli.group()
def images() -> None:
    """Image generation and editing."""


@images.command("generate")
@click.argument("model")
@click.argument("prompt")
@click.option("-o", "--output", default="image.png", show_default=True, help="Output file path.")
@click.option("-n", "--n", type=int, default=1, show_default=True, help="Number of images.")
@click.option("-s", "--size", default=None, help="Image dimensions, e.g. 512x512.")
@click.option("-S", "--steps", type=int, default=None, help="Diffusion steps.")
@click.option("-r", "--seed", type=int, default=None, help="Random seed.")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def images_generate(
    obj: dict,
    model: str,
    prompt: str,
    output: str,
    n: int,
    size: str | None,
    steps: int | None,
    seed: int | None,
    as_json: bool,
) -> None:
    """Generate images from a text PROMPT."""
    result = _server(obj).generate_image(
        model, prompt, n=n, size=size, steps=steps, seed=seed
    )
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        _save_images(result.get("data", []), output, n)


@images.command("edit")
@click.argument("model")
@click.argument("image", type=click.Path(exists=True, dir_okay=False))
@click.argument("prompt")
@click.option("-m", "--mask", type=click.Path(exists=True, dir_okay=False), default=None, help="Greyscale mask image.")
@click.option("-o", "--output", default="edited.png", show_default=True, help="Output file path.")
@click.option("-n", "--n", type=int, default=1, show_default=True, help="Number of variants.")
@click.option("-s", "--size", default=None, help="Output dimensions, e.g. 512x512.")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def images_edit(
    obj: dict,
    model: str,
    image: str,
    prompt: str,
    mask: str | None,
    output: str,
    n: int,
    size: str | None,
    as_json: bool,
) -> None:
    """Edit an IMAGE guided by a text PROMPT."""
    result = _server(obj).edit_image(model, image, prompt, mask_path=mask, n=n, size=size)
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        _save_images(result.get("data", []), output, n)


@images.command("variation")
@click.argument("model")
@click.argument("image", type=click.Path(exists=True, dir_okay=False))
@click.option("-o", "--output", default="variation.png", show_default=True, help="Output file path.")
@click.option("-n", "--n", type=int, default=1, show_default=True, help="Number of variations.")
@click.option("-s", "--size", default=None, help="Output dimensions, e.g. 512x512.")
@click.option("-j", "--json", "as_json", is_flag=True, help="Print raw JSON response.")
@click.pass_obj
def images_variation(
    obj: dict,
    model: str,
    image: str,
    output: str,
    n: int,
    size: str | None,
    as_json: bool,
) -> None:
    """Generate variations of an existing IMAGE."""
    result = _server(obj).image_variation(model, image, n=n, size=size)
    if as_json:
        click.echo(json_mod.dumps(result, indent=2))
    else:
        _save_images(result.get("data", []), output, n)
