gseai
=====

A Python client and command-line tool for the `GSE AI <https://gseai.gse.buffalo.edu>`_
LocalAI server.

The :class:`~gseai.GSEAIServer` class wraps LocalAI's OpenAI-compatible ``/v1/``
endpoints and the Anthropic-compatible ``/v1/messages`` endpoint. The ``gseai``
CLI exposes the same functionality without writing any Python.

Installation
------------

To add ``gseai`` as a dependency of a Python project:

.. code-block:: bash

   uv add gseai

To install the ``gseai`` CLI as a system-wide tool:

.. code-block:: bash

   uv tool install gseai

Quick start — Python
--------------------

.. code-block:: python

   from gseai import GSEAIServer

   with GSEAIServer("your-api-token") as server:
       # List available models
       models = server.list_models()

       # Simple single-turn chat
       response = server.chat("model-id", "What is machine learning?")

       # Multi-turn chat using the OpenAI-compatible API
       response = server.chat_completions(
           "model-id",
           messages=[{"role": "user", "content": "What is machine learning?"}],
       )

Quick start — CLI
-----------------

.. code-block:: bash

   export GSEAI_API_TOKEN=your-api-token

   gseai models list
   gseai chat gemma-4-e2b-it "What is machine learning?"
   gseai audio transcribe whisper lecture.mp3
   gseai images generate stable-diffusion "a red barn in a snowy field"

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   setup
   cli
   api

Indices
-------

* :ref:`genindex`
* :ref:`modindex`
