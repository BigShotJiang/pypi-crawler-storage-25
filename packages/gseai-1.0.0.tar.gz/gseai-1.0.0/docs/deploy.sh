aws s3 sync _build/html s3://docs.makingwithcode.org/gseai/
