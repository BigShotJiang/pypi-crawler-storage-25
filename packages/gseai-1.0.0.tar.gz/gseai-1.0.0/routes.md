# gseai CLI — proposed commands

## Global flags

These apply to every command.

| Flag | Env var | Default | Purpose |
|------|---------|---------|---------|
| `--token` | `GSEAI_API_TOKEN` | — | Bearer token (required) |
| `--host` | `GSEAI_HOST` | `gseai.gse.buffalo.edu` | Server hostname |
| `--port` | `GSEAI_PORT` | `11434` | Server port |
| `--json` | — | off | Print raw JSON instead of formatted output |

---

## Commands

### `gseai models list`
→ `GET /v1/models`

Lists all models available on the server.

Default output: a plain table of model IDs and any metadata (created date, owned-by).

---

### `gseai chat <model> <prompt>`
→ `POST /v1/chat/completions`

Single-turn chat. Prints the assistant reply text.

```
gseai chat llama3 "What is machine learning?"
```

| Flag | Purpose |
|------|---------|
| `--system <text>` | System prompt |
| `--temperature <float>` | Sampling temperature (0–2) |
| `--max-tokens <int>` | Max tokens to generate |
| `--stream` | Stream tokens as they arrive |

Default output: assistant message text only.  
With `--json`: full response object.

---

### `gseai completions <model> <prompt>`
→ `POST /v1/completions`

Legacy text completion (no chat turn structure).

```
gseai completions llama3 "Once upon a time"
```

| Flag | Purpose |
|------|---------|
| `--temperature <float>` | Sampling temperature |
| `--max-tokens <int>` | Max tokens |
| `--stream` | Stream output |

Default output: completion text only.  
With `--json`: full response object.

---

### `gseai embeddings <model> <text>`
→ `POST /v1/embeddings`

Generates an embedding vector for the given text. Since raw vectors aren't human-readable, `--json` is the default output; the plain default prints a summary (model, dimensions, first few values).

```
gseai embeddings nomic-embed-text "Hello world"
```

---

---

### `gseai audio transcribe <model> <file>`
→ `POST /v1/audio/transcriptions`

Transcribes an audio file to text using Whisper.

```
gseai audio transcribe whisper recording.mp3
```

| Flag | Purpose |
|------|---------|
| `--language <code>` | Source language hint (e.g. `en`, `fr`); auto-detected if omitted |
| `--prompt <text>` | Optional context/style hint passed to the model |
| `--format <fmt>` | Response format: `text` (default), `json`, `verbose_json`, `srt`, `vtt` |

Default output: transcript text.  
With `--json`: full response object (same as `--format verbose_json`).

---

### `gseai audio translate <model> <file>`
→ `POST /v1/audio/translations`

Transcribes audio and translates it to English in one step.

```
gseai audio translate whisper french_lecture.mp3
```

Same flags as `transcribe` except `--language` (source is auto-detected; output is always English).

---

### `gseai audio speech <model> <text>`
→ `POST /v1/audio/speech`

Synthesizes speech from text and writes audio to a file (requires a TTS model on the server).

```
gseai audio speech tts-model "Hello, world" --output hello.mp3
```

| Flag | Purpose |
|------|---------|
| `--output <file>` | Output file path (default: `speech.mp3`) |
| `--voice <name>` | Voice identifier |
| `--speed <float>` | Playback speed (default `1.0`) |

---

---

### `gseai images generate <model> <prompt>`
→ `POST /v1/images/generations`

Generates an image from a text prompt and saves it to a file.

```
gseai images generate stable-diffusion "a red barn in a snowy field" --output barn.png
```

| Flag | Purpose |
|------|---------|
| `--output <file>` | Output file path (default: `image.png`) |
| `--n <int>` | Number of images to generate (default `1`) |
| `--size <WxH>` | Image dimensions, e.g. `512x512` (default model-dependent) |
| `--steps <int>` | Diffusion steps |
| `--seed <int>` | Random seed for reproducibility |

Default output: saves image file(s) and prints the filename(s).  
With `--json`: prints the raw response (base64 or URL).

---

### `gseai images edit <model> <image> <prompt>`
→ `POST /v1/images/edits`

Edits an existing image guided by a text prompt, with an optional mask.

```
gseai images edit stable-diffusion photo.png "replace the sky with a sunset"
```

| Flag | Purpose |
|------|---------|
| `--mask <file>` | Greyscale mask image (white = area to edit) |
| `--output <file>` | Output file path (default: `edited.png`) |
| `--n <int>` | Number of variants to generate |
| `--size <WxH>` | Output dimensions |

---

### `gseai images variation <model> <image>`
→ `POST /v1/images/variations`

Generates variations of an existing image.

```
gseai images variation stable-diffusion photo.png --n 3
```

| Flag | Purpose |
|------|---------|
| `--output <file>` | Output file path prefix (default: `variation`) |
| `--n <int>` | Number of variations (default `1`) |
| `--size <WxH>` | Output dimensions |

---

## Out of scope for now

- `POST /v1/responses` — stateful multi-turn (OpenAI Responses API); more complex, leave for a later version.
- `POST /v1/messages` — Anthropic-compatible endpoint; useful but niche for CLI use.
