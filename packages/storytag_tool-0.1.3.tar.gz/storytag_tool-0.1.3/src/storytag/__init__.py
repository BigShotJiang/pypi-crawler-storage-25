"""storytag-tool - 音乐专辑信息整理工具"""
from storytag.cli import cli
__all__ = ["cli"]
