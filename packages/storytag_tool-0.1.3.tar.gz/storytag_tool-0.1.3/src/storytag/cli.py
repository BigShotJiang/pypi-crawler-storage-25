#!/usr/bin/env python3
"""
musictag.py - 音乐专辑信息整理工具
- 扫描音乐目录，按专辑分组
- 通过 MusicBrainz 自动匹配专辑信息
- 用户确认后再写入标签
- 匹配不到时使用目录名作为专辑名
"""
import os
import sys
import re
# readline 仅在 Unix/Linux 上可用，Windows 上无需使用（脚本未使用其功能）
try:
    import readline
except (ImportError, AttributeError):
    pass  # Windows 或 Python 3.10+ 兼容
import musicbrainzngs
import mutagen
from mutagen.flac import FLAC
from mutagen.mp3 import MP3
from mutagen.oggvorbis import OggVorbis
from pathlib import Path
from difflib import SequenceMatcher
from typing import Optional

# ============================================================
# 配置
# ============================================================
# 支持两种方式配置路径（按优先级）：
#   1. 命令行参数
#   2. 环境变量 MUSICTAG_DIR
#   3. 交互式输入
MUSIC_DIR = ""                  # 空字符串则运行时输入
AUDIO_EXTS = {".flac", ".mp3", ".ogg"}
DIR_ALIAS = {}                  # 可选：目录名别名映射，防止误匹配
# ============================================================

musicbrainzngs.set_useragent("musictag", "0.1", "musictag@example.com")


# ------------------------------------------------------------
# 工具
# ------------------------------------------------------------
def ask_yes(prompt: str) -> bool:
    while True:
        ans = input(f"  {prompt} [Y/n]: ").strip().lower()
        if ans in ("y", "yes", ""):
            return True
        if ans in ("n", "no"):
            return False


def ask_choice(prompt: str, options: list[str]) -> int:
    """返回用户选择的 0-based 索引，-1 表示跳过"""
    print(f"  {prompt}")
    for i, o in enumerate(options):
        print(f"    [{i}] {o}")
    print(f"    [s] 跳过此专辑")
    while True:
        ans = input(f"  选择 (0-{len(options)-1}, s=跳过): ").strip()
        if ans.lower() == "s":
            return -1
        try:
            idx = int(ans)
            if 0 <= idx < len(options):
                return idx
        except ValueError:
            pass


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def format_size(n: int) -> str:
    if n < 1024 * 1024:
        return f"{n/1024:.0f} KB"
    return f"{n/1024/1024:.1f} MB"


# ------------------------------------------------------------
# 标签读写
# ------------------------------------------------------------
class Tagger:
    @staticmethod
    def read_tags(path: str) -> dict:
        try:
            ext = Path(path).suffix.lower()
            if ext == '.mp3':
                # MP3 使用 EasyMP3 获取规范化的键名（如 "album" 而不是 "TALB"）
                from mutagen.mp3 import EasyMP3
                f = EasyMP3(path)
            else:
                f = mutagen.File(path)
            if f is None:
                return {}
            tags = f.tags or {}
            out = {}
            for k, v in tags.items():
                if isinstance(v, list) and len(v) == 1:
                    v = v[0]
                out[k] = v
            return out
        except Exception as e:
            return {"_error": str(e)}

    @staticmethod
    def write_tags(path: str, meta: dict) -> bool:
        """写入标签，保留原有其他标签"""
        try:
            ext = Path(path).suffix.lower()

            if ext == '.mp3':
                # MP3 使用 EasyMP3 (处理 ID3 格式)
                from mutagen.mp3 import EasyMP3
                f = EasyMP3(path)
                # 先删除现有标签再重写，避免同步错误
                f.delete()
                f.add_tags()
            else:
                # FLAC, Ogg, Opus, M4a 等使用通用 mutagen.File
                f = mutagen.File(path)
                if f is None:
                    print(f"    [WARN] 无法识别的文件格式: {path}")
                    return False
                if f.tags is None:
                    f.add_tags()

            # 映射 (使用小写键名，EasyMP3 和 mutagen.File 都支持)
            field_map = {
                "album": "album",
                "artist": "artist",
                "albumartist": "albumartist",
                "title": "title",
                "tracknumber": "tracknumber",
                "date": "date",
                "genre": "genre",
            }
            for src, dst in field_map.items():
                if src in meta and meta[src]:
                    f[dst] = str(meta[src])

            f.save()
            return True
        except Exception as e:
            print(f"    [ERROR] 写入失败 {path}: {e}")
            return False


# ------------------------------------------------------------
# 扫描
# ------------------------------------------------------------
class Album:
    def __init__(self, dir_path: str, files: list[str]):
        self.dir_path = dir_path
        self.dir_name = os.path.basename(dir_path)
        self.files = sorted(files)
        self.tracks = []  # [{path, tracknumber, title, duration}]
        self.current_meta: Optional[dict] = None  # 从现有标签读出的汇总信息
        self.mb_result: Optional[dict] = None      # MusicBrainz 匹配结果

    @property
    def album_key(self) -> str:
        """用于 MusicBrainz 搜索的键名（目录名或别名）"""
        return DIR_ALIAS.get(self.dir_name, self.dir_name)


def scan_albums(root: str) -> list[Album]:
    """遍历目录，返回 Album 列表

    支持两种模式：
    1. 多专辑模式：每个子目录为一个专辑
    2. 单专辑模式：根目录下直接有音频文件（无子目录时）
    """
    albums = []
    subdirs = []
    root_audio_files = []

    for entry in sorted(os.scandir(root), key=lambda e: e.name):
        if entry.is_dir():
            # 排除以 @eaDir 或 @ 开头的特殊目录
            if entry.name.startswith("@eaDir") or entry.name.startswith("@"):
                continue
            subdirs.append(entry)
        elif Path(entry.name).suffix.lower() in AUDIO_EXTS:
            root_audio_files.append(entry.path)

    # 模式1：有多级子目录，每个子目录是一个专辑
    if subdirs:
        for entry in subdirs:
            audio_files = [os.path.join(entry.path, f) for f in os.listdir(entry.path)
                          if Path(f).suffix.lower() in AUDIO_EXTS]
            if audio_files:
                albums.append(Album(entry.path, audio_files))
    # 模式2：根目录下直接有音频文件
    elif root_audio_files:
        albums.append(Album(root, root_audio_files))

    return albums


def load_album_info(album: Album) -> dict:
    """从现有标签中汇总专辑信息（取出现最多的值）"""
    from collections import Counter
    fields = ["album", "artist", "albumartist", "date", "genre"]
    result = {k: None for k in fields}
    votes = {k: Counter() for k in fields}

    for fp in album.files:
        tags = Tagger.read_tags(fp)
        for k in fields:
            if k in tags and tags[k]:
                votes[k][tags[k]] += 1

    for k in fields:
        if votes[k]:
            result[k] = votes[k].most_common(1)[0][0]

    # 读取轨道信息
    album.tracks = []
    for fp in album.files:
        tags = Tagger.read_tags(fp)
        fn = os.path.basename(fp)
        album.tracks.append({
            "path": fp,
            "tracknumber": tags.get("tracknumber", fn.rsplit(".", 1)[0].zfill(2)),
            "title": tags.get("title", os.path.splitext(fn)[0]),
            "duration": tags.get("_info", ""),
        })
    return result


# ------------------------------------------------------------
# MusicBrainz 搜索
# ------------------------------------------------------------
def search_album(album_key: str, artist_hint: str = None) -> list[dict]:
    """搜索 MusicBrainz，返回最多 5 个候选"""
    try:
        # 使用 query 参数进行搜索
        if artist_hint:
            query = f"album:{album_key} AND artist:{artist_hint}"
        else:
            query = f"album:{album_key}"
        result = musicbrainzngs.search_releases(query=query, limit=5)
        return result.get("release-list", [])
    except Exception as e:
        print(f"    [WARN] MusicBrainz 搜索失败: {e}")
        return []


def get_release_tracks(release_id: str) -> list[dict]:
    """获取专辑的轨道列表"""
    try:
        info = musicbrainzngs.get_release_by_id(release_id, includes=["recordings"])
        release = info.get("release", {})
        media_list = release.get("media-list", [])
        tracks = []
        for media in media_list:
            for track in media.get("track-list", []):
                rec = track.get("recording", {})
                tracks.append({
                    "title": rec.get("title", "Unknown"),
                    "tracknumber": track.get("position", 0),
                    "duration": rec.get("length", 0),
                })
        return tracks
    except Exception as e:
        print(f"    [WARN] 获取轨道失败: {e}")
        return []


def best_match(album: Album, candidates: list[dict]) -> tuple[int, float]:
    """找最匹配的结果，返回 (best_index, score)"""
    best_i, best_s = 0, 0.0
    key = album.album_key.lower()
    for i, c in enumerate(candidates):
        title = c.get("title", "").lower()
        score = similarity(key, title)
        # MusicBrainz 自带的 score 权重
        mb_score = int(c.get("ext:score", 0)) / 100.0
        combined = mb_score * 0.7 + score * 0.3
        if combined > best_s:
            best_i, best_s = i, combined
    return best_i, best_s


# ------------------------------------------------------------
# 展示 & 交互
# ------------------------------------------------------------
def show_album(album: Album, candidates: list[dict], best_i: int):
    print("")
    print(f"{'='*60}")
    print(f"  目录: {album.dir_name}")
    print(f"{'='*60}")

    cur = album.current_meta
    print(f"\n  当前标签:")
    print(f"    专辑名 : {cur.get('album') or '-':<40}")
    print(f"    艺术家 : {cur.get('artist') or '-':<40}")
    print(f"    日期   : {cur.get('date') or '-':<40}")
    print(f"    流派   : {cur.get('genre') or '-':<40}")
    print(f"    文件数 : {len(album.files)}")

    # 当前文件列表
    print(f"\n  当前文件列表:")
    for t in album.tracks:
        print(f"    {t['tracknumber']:>3}. {t['title']}")

    if not candidates:
        print("\n  MusicBrainz: 未找到匹配，目录名作为专辑名")
        return

    c = candidates[best_i]
    print(f"\n  MusicBrainz 匹配 (得分 {best_i+1}/{len(candidates)}):")
    print(f"    专辑名 : {c.get('title', '-'):<40}")
    print(f"    艺术家 : {c.get('artist-credit', [{}])[0].get('name', '-') if c.get('artist-credit') else '-'}")
    print(f"    日期   : {c.get('date', '-'):<40}")
    print(f"    ID     : {c.get('id', '-')}")
    score = int(c.get("ext:score", 0))
    print(f"    匹配度 : {score}%")

    # 显示其他候选
    if len(candidates) > 1:
        print(f"\n  其他候选 ({len(candidates)-1} 个):")
        for i, c2 in enumerate(candidates):
            if i == best_i:
                continue
            artist = c2.get("artist-credit", [{}])
            artist_name = artist[0].get("name", "-") if artist else "-"
            print(f"    [{i}] {c2.get('title','-')} — {artist_name} ({c2.get('date','-')})")


def build_meta_from_mb(release: dict, tracks: list[dict]) -> dict:
    """从 MusicBrainz 数据构建元数据字典"""
    artist_credit = release.get("artist-credit", [])
    artist_name = artist_credit[0].get("name", "-") if artist_credit else "-"
    return {
        "album": release.get("title", "Unknown"),
        "artist": artist_name,
        "albumartist": artist_name,
        "date": release.get("date", ""),
        "genre": "",  # MusicBrainz 不提供流派
        "mb_release_id": release.get("id", ""),
    }


def apply_meta(album: Album, meta: dict, tracks: list[dict]) -> dict:
    """将 meta 和 tracks 写入文件"""
    ok_count, fail_count = 0, 0
    # 建立轨道映射：按 tracknumber 对应
    track_map = {str(t["tracknumber"]): t for t in tracks}
    # 如果 MusicBrainz 没有 tracks，就用原文件名推断
    if not track_map:
        for i, fp in enumerate(album.files):
            bn = os.path.splitext(os.path.basename(fp))[0]
            track_map[str(i + 1)] = {"title": bn}

    for fp in album.files:
        bn = os.path.basename(fp)
        # 从文件名推断轨道号：01.xxx, 02.xxx
        m = re.match(r"^(\d+)", bn)
        track_num = m.group(1) if m else os.path.splitext(bn)[0].zfill(2)
        # 从 MusicBrainz 找对应轨道
        mb_track = track_map.get(track_num, {})
        file_meta = dict(meta)
        if mb_track.get("title"):
            file_meta["title"] = mb_track["title"]
        else:
            # 用原文件名作为标题
            file_meta["title"] = os.path.splitext(bn)[0]
        file_meta["tracknumber"] = track_num

        if Tagger.write_tags(fp, file_meta):
            ok_count += 1
        else:
            fail_count += 1
    return {"ok": ok_count, "fail": fail_count}


def use_dir_name_as_album(album: Album) -> dict:
    """搜不到时，把目录名当作专辑名"""
    album_name = album.album_key
    print(f"  使用目录名作为专辑名: {album_name}")
    meta = {
        "album": album_name,
        "artist": album_name.split(" - ")[0] if " - " in album_name else "",
        "albumartist": album_name.split(" - ")[0] if " - " in album_name else album_name,
        "date": "",
        "genre": "",
    }
    ok_count, fail_count = 0, 0
    for fp in album.files:
        bn = os.path.basename(fp)
        file_meta = dict(meta)
        m = re.match(r"^(\d+)", bn)
        file_meta["tracknumber"] = m.group(1) if m else os.path.splitext(bn)[0].zfill(2)
        file_meta["title"] = os.path.splitext(bn)[0]
        if Tagger.write_tags(fp, file_meta):
            ok_count += 1
        else:
            fail_count += 1
    return {"ok": ok_count, "fail": fail_count}


def apply_meta_with_name(album: Album, album_name: str) -> dict:
    """使用指定的专辑名写入标签"""
    print(f"  使用专辑名: {album_name}")
    meta = {
        "album": album_name,
        "artist": album_name.split(" - ")[0] if " - " in album_name else "",
        "albumartist": album_name.split(" - ")[0] if " - " in album_name else album_name,
        "date": "",
        "genre": "",
    }
    ok_count, fail_count = 0, 0
    for fp in album.files:
        bn = os.path.basename(fp)
        file_meta = dict(meta)
        m = re.match(r"^(\d+)", bn)
        file_meta["tracknumber"] = m.group(1) if m else os.path.splitext(bn)[0].zfill(2)
        file_meta["title"] = os.path.splitext(bn)[0]
        if Tagger.write_tags(fp, file_meta):
            ok_count += 1
        else:
            fail_count += 1
    return {"ok": ok_count, "fail": fail_count}


# ------------------------------------------------------------
# 主流程
# ------------------------------------------------------------
def clean_album_name(dir_name: str) -> str:
    """从目录名提取专辑名，清除前导音轨号等"""
    # 移除前导音轨号：如 "05. 口袋神探 - 第三季" -> "口袋神探 - 第三季"
    cleaned = re.sub(r'^\d+[\.\-\_]\s*', '', dir_name)
    return cleaned


def ask_album_name(dir_name: str) -> tuple[bool, str]:
    """询问用户专辑名
    返回 (confirmed, album_name)
    - confirmed=True 表示确认使用（用户回车或输入新名称）
    - confirmed=False 表示跳过
    - album_name 是确认使用的专辑名
    """
    suggested = clean_album_name(dir_name)
    prompt = f"  专辑名 [{suggested}] (回车确认，输入新名称修改): "
    ans = input(prompt).strip()
    if not ans:
        # 用户直接回车，使用建议的名称
        return (True, suggested)
    else:
        # 用户输入了新名称
        return (True, ans)


def scan_all_dirs(root: str) -> list[tuple[str, list[str]]]:
    """递归扫描所有子目录，返回 (dir_path, audio_files) 列表"""
    results = []
    for entry in sorted(os.scandir(root), key=lambda e: e.name):
        if entry.is_dir():
            # 排除以 @eaDir 或 @ 开头的特殊目录
            if entry.name.startswith("@eaDir") or entry.name.startswith("@"):
                continue
            audio_files = [os.path.join(entry.path, f) for f in os.listdir(entry.path)
                          if Path(f).suffix.lower() in AUDIO_EXTS]
            if audio_files:
                results.append((entry.path, audio_files))
            # 递归扫描子目录
            results.extend(scan_all_dirs(entry.path))
    return results


def check_missing_album(root: str, output_file: str = None):
    """检查所有子目录下音乐文件无专辑名的目录
    规则：目录下前2个文件有专辑名则认为目录有专辑名
    输出 Markdown 或 CSV 表格（根据文件扩展名）
    """
    print(f"检查目录: {root}\n")

    all_dirs = scan_all_dirs(root)

    # 收集数据
    rows = []
    for dir_path, audio_files in all_dirs:
        dir_name = os.path.basename(dir_path)
        file_count = len(audio_files)

        # 检查前2个文件的专辑名
        has_album_count = 0
        check_count = min(2, len(audio_files))
        suggested_album = "-"

        for fp in audio_files[:check_count]:
            tags = Tagger.read_tags(fp)
            album = tags.get('album')
            if album:
                has_album_count += 1
                if suggested_album == "-":
                    suggested_album = album

        # 有专辑用 "是"，无专辑用 "否"
        has_album_str = "是" if has_album_count >= 2 else "否"
        dir_path_clean = dir_path.replace(chr(92), '/')

        rows.append((dir_name, file_count, has_album_str, suggested_album, dir_path_clean))

    # 打印到屏幕
    if output_file and output_file.endswith('.csv'):
        # CSV 格式打印
        print("| 本目录名 | 文件数 | 有专辑 | 建议专辑名 | 本目录所在路径 |")
        print("|----------|--------|--------|------------|----------------|")
        for r in rows:
            print(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} |")
    else:
        # Markdown 格式打印
        print(f"| 本目录名 | 文件数 | 有专辑 | 建议专辑名 | 本目录所在路径 |")
        print(f"|----------|--------|--------|------------|----------------|")
        for r in rows:
            print(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} |")

    # 保存到文件
    if output_file is None:
        output_file = os.path.join(root, "result.md")

    if output_file.endswith('.csv'):
        import csv
        with open(output_file, 'w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['本目录名', '文件数', '有专辑', '建议专辑名', '本目录所在路径'])
            for r in rows:
                writer.writerow(r)
    else:
        lines = []
        lines.append(f"| 本目录名 | 文件数 | 有专辑 | 建议专辑名 | 本目录所在路径 |")
        lines.append(f"|----------|--------|--------|------------|----------------|")
        for r in rows:
            lines.append(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} |")
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("\n".join(lines) + "\n")
    print(f"\n结果已保存到: {output_file}")


def apply_from_md(md_file: str, dryrun: bool = False):
    """从 md 表读取并应用专辑名修改（支持 md 和 csv 格式）"""
    import re
    import csv

    root = os.path.dirname(md_file)
    if not root:
        root = "."

    albums = []  # [(dir_path, dir_name, album_name)]

    if md_file.endswith('.csv'):
        # 解析 CSV 文件
        with open(md_file, 'r', encoding='utf-8-sig') as f:
            reader = csv.reader(f)
            header = next(reader, None)  # 跳过表头
            for row in reader:
                if len(row) >= 5:
                    dir_name = row[0]
                    file_count = row[1]
                    has_album = row[2]
                    suggested_album = row[3]
                    dir_path = row[4]
                    if has_album == "是":
                        continue
                    if suggested_album and suggested_album != "-":
                        albums.append((dir_path, dir_name, suggested_album))
    else:
        # 解析 md 表
        with open(md_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        for line in lines:
            line = line.strip()
            if not line or line.startswith('|') and ('本目录名' in line or '---' in line):
                continue
            parts = [p.strip() for p in line.split('|')]
            if len(parts) >= 6:
                dir_name = parts[1]
                file_count = parts[2]
                has_album = parts[3]
                suggested_album = parts[4]
                dir_path = parts[5]

                if has_album == "是":
                    continue
                if suggested_album and suggested_album != "-":
                    albums.append((dir_path, dir_name, suggested_album))

    if not albums:
        print("没有需要修改的目录")
        return

    print(f"找到 {len(albums)} 个目录需要修改专辑名\n")

    total_ok = 0
    total_fail = 0

    for dir_path, dir_name, album_name in albums:
        print(f"{'='*60}")
        print(f"  目录: {dir_name}")
        print(f"  专辑名: {album_name}")
        print(f"  路径: {dir_path}")

        # 获取目录下所有音频文件
        audio_files = [os.path.join(dir_path, f) for f in os.listdir(dir_path)
                      if Path(f).suffix.lower() in AUDIO_EXTS]

        if dryrun:
            print(f"  [DRYRUN] 将修改 {len(audio_files)} 个文件")
            meta = {
                "album": album_name,
                "artist": album_name.split(" - ")[0] if " - " in album_name else "",
                "albumartist": album_name.split(" - ")[0] if " - " in album_name else album_name,
            }
            print(f"    专辑: {meta['album']}")
            print(f"    艺术家: {meta['artist']}")
            print(f"    专辑艺术家: {meta['albumartist']}")
            print(f"    文件列表:")
            for fp in audio_files:
                bn = os.path.basename(fp)
                m = re.match(r"^(\d+)", bn)
                track_num = m.group(1) if m else bn.split('.')[0].zfill(2)
                title = os.path.splitext(bn)[0]
                print(f"      [{track_num}] {title}")
        else:
            result = apply_meta_with_name_simple(dir_path, audio_files, album_name)
            print(f"  写入完成: {result['ok']} 成功, {result['fail']} 失败")
            total_ok += result["ok"]
            total_fail += result["fail"]

    if dryrun:
        total_files = sum(len([os.path.join(p, fi) for fi in os.listdir(p) if Path(fi).suffix.lower() in AUDIO_EXTS]) for p, _, _ in albums)
        print(f"\n{'='*60}")
        print(f"[DRYRUN] 共 {len(albums)} 个目录，{total_files} 个文件将被修改")
    else:
        print(f"\n{'='*60}")
        print(f"全部完成！")
        print(f"  写入成功: {total_ok} 文件")
        print(f"  写入失败: {total_fail} 文件")


def apply_meta_with_name_simple(dir_path: str, audio_files: list[str], album_name: str) -> dict:
    """使用指定专辑名写入目录下所有文件"""
    meta = {
        "album": album_name,
        "artist": album_name.split(" - ")[0] if " - " in album_name else "",
        "albumartist": album_name.split(" - ")[0] if " - " in album_name else album_name,
        "date": "",
        "genre": "",
    }
    ok_count, fail_count = 0, 0
    for fp in audio_files:
        bn = os.path.basename(fp)
        file_meta = dict(meta)
        m = re.match(r"^(\d+)", bn)
        file_meta["tracknumber"] = m.group(1) if m else os.path.splitext(bn)[0].zfill(2)
        file_meta["title"] = os.path.splitext(bn)[0]
        if Tagger.write_tags(fp, file_meta):
            ok_count += 1
        else:
            fail_count += 1
    return {"ok": ok_count, "fail": fail_count}


def cli():
    import argparse
    parser = argparse.ArgumentParser(description="musictag - 音乐专辑信息整理工具")
    parser.add_argument("dir", nargs="?", default=os.environ.get("MUSICTAG_DIR", MUSIC_DIR),
                        help="音乐目录路径（支持 SMB 挂载路径）")
    parser.add_argument("-s", "--search", action="store_true",
                        help="启用 MusicBrainz 元数据搜索（默认关闭）")
    parser.add_argument("-c", "--check", action="store_true",
                        help="检查缺少专辑名的目录，输出到 md 表")
    parser.add_argument("-o", "--output", metavar="FILE",
                        help="-c 时指定 md 表输出路径")
    parser.add_argument("-f", "--file", metavar="FILE",
                        help="从 md 表读取并应用专辑名修改")
    parser.add_argument("--dryrun", action="store_true",
                        help="不实际执行文件修改，仅显示预期")
    args = parser.parse_args()

    # -f 模式
    if args.file:
        if not os.path.exists(args.file):
            print(f"文件不存在: {args.file}")
            sys.exit(1)
        apply_from_md(args.file, dryrun=args.dryrun)
        return

    root = os.path.expanduser(args.dir)
    while not root or not os.path.isdir(root):
        if root:
            print(f"目录不存在: {root}")
        root = input("请输入音乐目录路径（SMB 挂载路径，如 /mnt/nas/music）: ").strip()
        root = os.path.expanduser(root)

    print(f"使用目录: {root}")

    # 仅检查模式
    if args.check:
        check_missing_album(root, args.output)
        return

    print(f"MusicBrainz 搜索: {'启用' if args.search else '禁用（使用目录名）'}\n")

    print(f"扫描目录: {root}")
    albums = scan_albums(root)
    print(f"找到 {len(albums)} 个专辑\n")

    if not albums:
        print("未找到任何音频文件，检查路径或 AUDIO_EXTS 配置是否包含你的文件格式")
        sys.exit(0)

    total_ok = 0
    total_skip = 0
    total_fail = 0

    for i, album in enumerate(albums):
        print(f"\n[{i+1}/{len(albums)}] 处理: {album.dir_name}")

        # 读取现有标签
        album.current_meta = load_album_info(album)

        # 展示当前状态
        print("")
        print(f"{'='*60}")
        print(f"  目录: {album.dir_name}")
        print(f"{'='*60}")

        cur = album.current_meta
        existing_album = cur.get('album')
        if existing_album:
            print(f"\n  已有专辑名: {existing_album}")
        print(f"\n  当前标签:")
        print(f"    专辑名 : {existing_album or '-':<40}")
        print(f"    艺术家 : {cur.get('artist') or '-':<40}")
        print(f"    日期   : {cur.get('date') or '-':<40}")
        print(f"    流派   : {cur.get('genre') or '-':<40}")
        print(f"    文件数 : {len(album.files)}")

        # 当前文件列表
        print(f"\n  当前文件列表:")
        for t in album.tracks:
            print(f"    {t['tracknumber']:>3}. {t['title']}")

        # 是否启用 MusicBrainz 搜索
        if args.search:
            # 搜索 MusicBrainz
            artist_hint = album.current_meta.get("artist") or None
            candidates = search_album(album.album_key, artist_hint)
            best_i, best_score = best_match(album, candidates)

            if candidates:
                c = candidates[best_i]
                print(f"\n  MusicBrainz 匹配 (得分 {best_i+1}/{len(candidates)}):")
                print(f"    专辑名 : {c.get('title', '-'):<40}")
                artist_credit = c.get("artist-credit", [])
                artist_name = artist_credit[0].get('name', '-') if artist_credit else '-'
                print(f"    艺术家 : {artist_name:<40}")
                print(f"    日期   : {c.get('date', '-'):<40}")
                print(f"    ID     : {c.get('id', '-')}")
                score = int(c.get("ext:score", 0))
                print(f"    匹配度 : {score}%")

                # 显示其他候选
                if len(candidates) > 1:
                    print(f"\n  其他候选 ({len(candidates)-1} 个):")
                    for j, c2 in enumerate(candidates):
                        if j == best_i:
                            continue
                        artist = c2.get("artist-credit", [{}])
                        artist_name = artist[0].get('name', '-') if artist else '-'
                        print(f"    [{j}] {c2.get('title','-')} — {artist_name} ({c2.get('date','-')})")

                # 用户决策
                if ask_yes(f"\n  使用 MusicBrainz 匹配 [{candidates[best_i].get('title','?')}]"):
                    mb_meta = build_meta_from_mb(candidates[best_i], [])
                    mb_tracks = get_release_tracks(candidates[best_i]["id"])

                    if mb_tracks:
                        print("\n  MusicBrainz 轨道列表:")
                        for t in mb_tracks[:10]:
                            dur = t.get("duration", 0)
                            dur_str = f"{dur//1000}:{dur%1000//10:02d}" if dur else "-"
                            print(f"    {t.get('tracknumber',0):>2}. {t.get('title','?')} ({dur_str})")
                        if len(mb_tracks) > 10:
                            print(f"    ... 共 {len(mb_tracks)} 曲")

                    if ask_yes("  确认写入 MusicBrainz 信息（含轨道名）"):
                        result = apply_meta(album, mb_meta, mb_tracks)
                        print(f"  写入完成: {result['ok']} 成功, {result['fail']} 失败")
                        total_ok += result["ok"]
                        total_fail += result["fail"]
                    else:
                        print("  已跳过")
                        total_skip += len(album.files)
                elif ask_yes("  改用手动输入专辑名"):
                    confirmed, album_name = ask_album_name(album.dir_name)
                    if confirmed:
                        result = apply_meta_with_name(album, album_name)
                        print(f"  写入完成: {result['ok']} 成功, {result['fail']} 失败")
                        total_ok += result["ok"]
                        total_fail += result["fail"]
                    else:
                        print("  已跳过此专辑")
                        total_skip += len(album.files)
                else:
                    print("  已跳过此专辑")
                    total_skip += len(album.files)
            else:
                print("\n  MusicBrainz: 未找到匹配")
                if ask_yes("  使用目录名作为专辑名"):
                    result = use_dir_name_as_album(album)
                    print(f"  写入完成: {result['ok']} 成功, {result['fail']} 失败")
                    total_ok += result["ok"]
                    total_fail += result["fail"]
                else:
                    print("  已跳过此专辑")
                    total_skip += len(album.files)
        else:
            # 默认模式：输入专辑名或使用目录名
            print("\n  MusicBrainz 搜索已禁用")
            confirmed, album_name = ask_album_name(album.dir_name)
            if confirmed:
                result = apply_meta_with_name(album, album_name)
                print(f"  写入完成: {result['ok']} 成功, {result['fail']} 失败")
                total_ok += result["ok"]
                total_fail += result["fail"]
            else:
                print("  已跳过此专辑")
                total_skip += len(album.files)

    print(f"\n{'='*60}")
    print(f"全部完成！")
    print(f"  写入成功: {total_ok} 文件")
    print(f"  写入失败: {total_fail} 文件")
    print(f"  跳过    : {total_skip} 文件")


if __name__ == "__main__":
    cli()
