"""musictag - 音乐专辑信息整理工具"""
from musictag.cli import cli
__all__ = ["cli"]
