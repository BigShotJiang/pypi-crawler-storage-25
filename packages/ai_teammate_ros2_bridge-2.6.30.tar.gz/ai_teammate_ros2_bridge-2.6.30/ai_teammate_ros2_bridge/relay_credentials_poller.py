"""Periodic poll for phone-issued relay credentials — Phase 4.14.

Robot bridge polls `/api/control-tower/devices/relay-config?api_key=…`
every N minutes (default 5). If the returned token / fingerprint differs
from what's currently in `.env`, write the new values into `.env` — the
v2.6.29 hot-reload watcher detects the mtime change within 5s and bounces
the WS without restarting the service.

This closes the C-loop in the relay design: phone rotates a token in its
Robot Relay UI → pushes to AT API → robot picks up automatically. Operator
no longer needs to scan a QR or SSH into the robot for routine token
rotations.

Polling deliberately uses the cloud HTTP API (not mDNS). When cloud is
unreachable we just skip the iteration and try again later — the robot
keeps using whatever credentials it had last and continues to fall back
through mDNS to the phone if needed.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re

log = logging.getLogger(__name__)

_DEFAULT_INTERVAL_SEC = 300  # 5 minutes


def _gateway_to_http(gateway_url: str) -> str:
    """Derive the HTTP base URL from a `wss://host/gw` style GATEWAY_URL.

    Returns "" when GATEWAY_URL is empty or non-cloud (e.g., a phone-relay
    `ws://192.168…` URL — we don't poll over relay).
    """
    if not gateway_url:
        return ""
    base = gateway_url.replace("wss://", "https://").replace("ws://", "http://")
    # Strip /gw suffix if present
    if base.endswith("/gw"):
        base = base[:-3]
    return base


def _patch_env_file(env_path: str, updates: dict[str, str]) -> bool:
    """Write `updates` (key→value) into `env_path`, replacing existing
    `KEY=…` lines or appending new ones. Returns True if the file was
    actually modified.
    """
    if not updates:
        return False
    try:
        existing = ""
        if os.path.exists(env_path):
            with open(env_path) as f:
                existing = f.read()
        new_text = existing
        changed = False
        for k, v in updates.items():
            line = f"{k}={v}"
            pat = re.compile(rf"^{re.escape(k)}=.*$", re.MULTILINE)
            if pat.search(new_text):
                replaced = pat.sub(line, new_text, count=1)
                if replaced != new_text:
                    new_text = replaced
                    changed = True
            else:
                # Append, ensuring a leading newline if file doesn't end with one.
                if new_text and not new_text.endswith("\n"):
                    new_text += "\n"
                new_text += line + "\n"
                changed = True
        if not changed:
            return False
        # Atomic-ish write — create alongside, then rename.
        tmp = env_path + ".tmp"
        with open(tmp, "w") as f:
            f.write(new_text)
        os.replace(tmp, env_path)
        return True
    except OSError as e:
        log.warning(f"[relay-poll] .env writeback failed: {e}")
        return False


async def poll_relay_credentials(
    api_key: str,
    gateway_url: str,
    env_path: str = ".env",
    interval_sec: float = _DEFAULT_INTERVAL_SEC,
) -> None:
    """Background task — poll AT API for fresh relay credentials and apply.

    Stops silently if `api_key` is missing or `gateway_url` doesn't look
    like a cloud HTTP base; in those cases there's no place to call.
    """
    base = _gateway_to_http(gateway_url)
    if not api_key or not base:
        log.debug("[relay-poll] disabled (no api_key or non-cloud gateway)")
        return

    url = f"{base}/api/control-tower/devices/relay-config"
    log.info(f"[relay-poll] starting (every {int(interval_sec)}s) → {url}")

    # Lazy import — keep startup fast and avoid hard dependency at module load.
    try:
        import httpx  # type: ignore
    except ImportError:
        try:
            # Bridge already depends on websockets; httpx may not be present.
            # Fall back to the standard-library urllib in a thread.
            import urllib.request  # noqa: F401

            httpx = None
        except ImportError:
            log.warning("[relay-poll] no HTTP client available — disabled")
            return

    while True:
        try:
            data = await _fetch_relay_config(url, api_key, httpx)
            if data is not None:
                _apply_if_changed(data, env_path)
        except Exception as e:  # never crash the bg task
            log.debug(f"[relay-poll] iteration error: {e}")
        await asyncio.sleep(interval_sec)


async def _fetch_relay_config(url: str, api_key: str, httpx_module) -> dict | None:
    if httpx_module is not None:
        async with httpx_module.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, params={"api_key": api_key})
            if resp.status_code != 200:
                log.debug(f"[relay-poll] HTTP {resp.status_code}")
                return None
            payload = resp.json()
    else:
        # Stdlib fallback — run in a thread.
        import urllib.parse
        import urllib.request

        def _get():
            qs = urllib.parse.urlencode({"api_key": api_key})
            req = urllib.request.Request(f"{url}?{qs}")
            with urllib.request.urlopen(req, timeout=10) as r:
                if r.status != 200:
                    return None
                import json as _json
                return _json.loads(r.read().decode())

        payload = await asyncio.get_running_loop().run_in_executor(None, _get)
        if payload is None:
            return None

    if not payload.get("valid"):
        log.debug(f"[relay-poll] invalid: {payload.get('reason')}")
        return None
    return payload.get("relay")


def _apply_if_changed(relay: dict | None, env_path: str) -> None:
    """Compare server-side relay config with current process env; write
    differences to `.env` so the hot-reload watcher can pick them up.
    Returns silently when nothing changed.
    """
    if not relay:
        return
    server_token = relay.get("relay_token", "") or ""
    server_fp = relay.get("relay_fingerprint", "") or ""
    cur_token = os.environ.get("RELAY_TOKEN", "")
    cur_fp = os.environ.get("RELAY_FINGERPRINT", "")
    updates: dict[str, str] = {}
    if server_token and server_token != cur_token:
        updates["RELAY_TOKEN"] = server_token
    if server_fp and server_fp != cur_fp:
        updates["RELAY_FINGERPRINT"] = server_fp
    if not updates:
        return
    if _patch_env_file(env_path, updates):
        log.info(
            f"[relay-poll] applied {sorted(updates.keys())} to {env_path} — "
            f"hot-reload watcher will bounce WS"
        )
