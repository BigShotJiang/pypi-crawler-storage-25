"""QR-based pairing — Phase 4.14.

Scans QR codes from the robot's camera and applies the embedded credentials
to `.env`. Designed for the case where the operator can't (or doesn't want
to) SSH into the robot to paste relay credentials by hand: hold the phone's
Robot Relay QR up to the robot's camera and the bridge auto-pairs.

The phone-side QR encodes `ai-teammate://relay?token=…&fp=…&label=…`
(see `greenmobio-lite/ros2_relay_page.dart::_qrPayloadFor`). We accept that
deeplink form first; legacy multi-line `.env` blocks (older phone builds)
also parse since they contain `RELAY_TOKEN=` lines.

Decoder priority:
  1. `pyzbar` (system libzbar). Robust across lighting; widest format support.
  2. `qreader` / `cv2.QRCodeDetector` fallback if pyzbar unavailable.
  3. No decoder → log warning + give up gracefully.

Triggered by:
  - `bridge.scan_qr` skill via existing skill_dispatch.
  - LAN HTTP endpoint `POST /pair/scan` (operator hits with curl from same
    network when SSH isn't convenient).
  - First-boot auto-scan when RELAY_TOKEN is empty (best-effort).
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional
from urllib.parse import parse_qs, urlparse

log = logging.getLogger(__name__)


def parse_qr_payload(payload: str) -> Optional[dict[str, str]]:
    """Parse a QR-encoded credentials payload into a dict of `.env` keys.

    Supports two formats:
      1. Deeplink:    `ai-teammate://relay?token=rt_xxx&fp=fp_yyy&label=…`
      2. Env block:   `GATEWAY_URL=…\\nRELAY_TOKEN=…\\nRELAY_FINGERPRINT=…`

    Returns None when the payload is unrecognized.
    """
    if not payload:
        return None
    s = payload.strip()

    # Deeplink form
    if s.startswith("ai-teammate://"):
        try:
            u = urlparse(s)
            if u.netloc != "relay":
                return None
            qs = parse_qs(u.query)
            out: dict[str, str] = {}
            tok = qs.get("token", [""])[0]
            fp = qs.get("fp", [""])[0]
            if tok:
                out["RELAY_TOKEN"] = tok
            if fp:
                out["RELAY_FINGERPRINT"] = fp
            return out or None
        except Exception:
            return None

    # Env-block form — match KEY=VALUE lines for the keys we care about.
    out_env: dict[str, str] = {}
    for line in s.splitlines():
        m = re.match(r"^\s*(GATEWAY_URL|RELAY_TOKEN|RELAY_FINGERPRINT)\s*=\s*(.*?)\s*$", line)
        if m:
            out_env[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    return out_env or None


def _decode_with_pyzbar(jpeg_bytes: bytes) -> list[str]:
    try:
        from pyzbar.pyzbar import decode  # type: ignore
        from PIL import Image  # type: ignore
        import io

        img = Image.open(io.BytesIO(jpeg_bytes))
        results = decode(img)
        return [r.data.decode("utf-8", errors="ignore") for r in results if r.data]
    except ImportError:
        return []
    except Exception as e:
        log.debug(f"[qr-pair] pyzbar decode error: {e}")
        return []


def _decode_with_cv2(jpeg_bytes: bytes) -> list[str]:
    try:
        import cv2  # type: ignore
        import numpy as np  # type: ignore

        arr = np.frombuffer(jpeg_bytes, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return []
        det = cv2.QRCodeDetector()
        # Single-QR fast path; multi-QR detection has higher latency.
        text, points, _ = det.detectAndDecode(img)
        if text:
            return [text]
        return []
    except ImportError:
        return []
    except Exception as e:
        log.debug(f"[qr-pair] cv2 decode error: {e}")
        return []


def decode_qr(jpeg_bytes: bytes) -> list[str]:
    """Try every available decoder; return any payloads found."""
    found = _decode_with_pyzbar(jpeg_bytes)
    if found:
        return found
    return _decode_with_cv2(jpeg_bytes)


async def scan_camera_for_qr(
    timeout_sec: float = 30.0,
    poll_interval_sec: float = 0.5,
) -> Optional[dict[str, str]]:
    """Watch the bridge's camera frame cache for QR codes for up to
    `timeout_sec`. Returns the parsed `.env`-shaped dict on first valid
    match, or None on timeout.

    Reads from `_ros2_cache["camera_frame"]` populated by the existing
    image subscriber (see ros2_node.py). Activates the camera on demand
    so we don't waste battery / CPU when not pairing.
    """
    from .ros2_node import _ros2_cache, _ros2_lock, start_camera

    start_camera()
    deadline = asyncio.get_event_loop().time() + timeout_sec
    last_ts = 0.0
    try:
        while asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(poll_interval_sec)
            with _ros2_lock:
                ts = _ros2_cache.get("camera_frame_ts", 0)
                frame = _ros2_cache.get("camera_frame")
            if not frame or ts <= last_ts:
                continue
            last_ts = ts
            payloads = decode_qr(frame)
            for p in payloads:
                creds = parse_qr_payload(p)
                if creds:
                    log.info(
                        f"[qr-pair] decoded payload "
                        f"({sorted(creds.keys())}) — applying"
                    )
                    return creds
    finally:
        # Camera will idle out via the existing check_camera_idle() loop;
        # no need to force-stop here.
        pass
    log.warning(f"[qr-pair] no QR detected within {int(timeout_sec)}s")
    return None


async def scan_and_apply(
    env_path: str = ".env",
    timeout_sec: float = 30.0,
) -> bool:
    """Convenience helper — scan + write to `.env` if a payload is found.

    Returns True when credentials were applied. Hot-reload watcher (v2.6.29+)
    will detect the mtime change and bounce WS within 5s.
    """
    from .relay_credentials_poller import _patch_env_file

    creds = await scan_camera_for_qr(timeout_sec=timeout_sec)
    if not creds:
        return False
    return _patch_env_file(env_path, creds)
