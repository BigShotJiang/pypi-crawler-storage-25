"""Gateway candidate resolver — Phase 4.12 (mDNS fallback).

Returns an ordered list of WebSocket gateway URLs to try when establishing the
device's primary connection. The bridge prefers cloud (`GATEWAY_URL` from
`.env`); if that's unreachable, it falls back to a phone running the AI Teammate
relay app (discovered via mDNS service `_aiteammate-relay._tcp.local`).

Security model
--------------
The mDNS broadcast includes a `fingerprint` TXT record identifying which phone
the service belongs to. The robot's `.env` carries `RELAY_FINGERPRINT` from the
QR pairing step; we filter discovered services to that fingerprint only, so a
rogue advertiser on the same network with a different fingerprint is rejected
before any token is sent. Auth itself uses the per-robot pre-shared
`RELAY_TOKEN`, which is **never** broadcast.

Why not just `nslookup` or DNS-over-multicast directly: zeroconf handles cache
invalidation, multi-interface, and TXT decoding consistently across
distributions.
"""

from __future__ import annotations

import logging
import socket
import threading
import time
from dataclasses import dataclass

log = logging.getLogger(__name__)

MDNS_SERVICE_TYPE = "_aiteammate-relay._tcp.local."


@dataclass
class GatewayCandidate:
    """One try-able gateway endpoint."""

    url: str  # full ws:// or wss:// URL up to /gw (no /ws/<device_id> suffix)
    label: str  # short human label for logs (e.g. 'cloud', 'mdns:fp_a1b2…')
    is_primary: bool = False


class GatewayResolver:
    """Builds the candidate list for the bridge connect loop.

    Use [`candidates(...)`][GatewayResolver.candidates] each connect attempt —
    a fresh mDNS browse runs on every call, with a short timeout, so newly
    appearing/disappearing phones are picked up.
    """

    def __init__(
        self,
        primary_url: str,
        relay_token: str,
        relay_fingerprint: str,
        mdns_browse_timeout: float = 3.0,
    ):
        self._primary_url = primary_url
        self._relay_token = relay_token
        self._relay_fingerprint = relay_fingerprint
        self._mdns_browse_timeout = mdns_browse_timeout

    def candidates(self) -> list[GatewayCandidate]:
        """Return ordered candidates: primary first, then mDNS-discovered phones.

        mDNS lookup is best-effort. Failures here are non-fatal and only mean
        no fallback is available; the bridge will retry on the next loop.
        """
        out: list[GatewayCandidate] = []
        if self._primary_url:
            out.append(
                GatewayCandidate(
                    url=self._primary_url,
                    label="cloud",
                    is_primary=True,
                )
            )
        if self._relay_token and self._relay_fingerprint:
            out.extend(self._discover_via_mdns())
        return out

    # ── mDNS discovery ─────────────────────────────────────────

    def _discover_via_mdns(self) -> list[GatewayCandidate]:
        """Browse the LAN for relay services matching our fingerprint.

        Imports lazily so robots without zeroconf installed (or offline
        installs) still boot; missing-dependency just disables the fallback.
        """
        try:
            from zeroconf import ServiceBrowser, ServiceListener, Zeroconf
        except ImportError:
            log.debug("[gw-resolver] zeroconf not installed — mDNS disabled")
            return []

        # Capture closure values as locals so the listener class doesn't have
        # to reach back through `self` of the outer GatewayResolver.
        expected_fp = self._relay_fingerprint
        relay_token = self._relay_token

        found: list[GatewayCandidate] = []
        seen_lock = threading.Lock()

        def inspect(zc, type_: str, name: str) -> None:
            try:
                info = zc.get_service_info(type_, name, timeout=1500)
            except Exception as e:
                log.debug(f"[gw-resolver] get_service_info failed: {e}")
                return
            if info is None:
                return
            fp = (info.properties.get(b"fingerprint", b"") or b"").decode(
                "utf-8", errors="ignore"
            )
            if fp != expected_fp:
                log.debug(
                    f"[gw-resolver] skipping mDNS hit {name} — fingerprint "
                    f"mismatch (got {fp!r}, want {expected_fp!r})"
                )
                return
            addrs = info.parsed_addresses() or []
            ipv4 = next((a for a in addrs if ":" not in a), None)
            if not ipv4:
                log.debug(f"[gw-resolver] mDNS hit {name} has no IPv4")
                return
            cand_url = f"ws://{ipv4}:{info.port}/gw?token={relay_token}"
            with seen_lock:
                if any(c.url == cand_url for c in found):
                    return
                found.append(
                    GatewayCandidate(
                        url=cand_url,
                        label=f"mdns:{fp}",
                        is_primary=False,
                    )
                )

        class _Listener(ServiceListener):
            def add_service(self, zc, type_: str, name: str) -> None:
                inspect(zc, type_, name)

            def update_service(self, zc, type_: str, name: str) -> None:
                inspect(zc, type_, name)

            def remove_service(self, zc, type_: str, name: str) -> None:
                pass

        zc = None
        try:
            zc = Zeroconf()
            ServiceBrowser(zc, MDNS_SERVICE_TYPE, _Listener())
            # Browse for a short window; relays on the LAN respond well within 1-2s.
            time.sleep(self._mdns_browse_timeout)
        except OSError as e:
            # Common: robot has no network, or restricted multicast.
            log.debug(f"[gw-resolver] mDNS browse failed: {e}")
        except Exception as e:
            log.warning(f"[gw-resolver] unexpected mDNS error: {e}")
        finally:
            try:
                if zc is not None:
                    zc.close()
            except Exception:
                pass

        if found:
            log.info(
                f"[gw-resolver] mDNS found {len(found)} relay(s) matching "
                f"fingerprint {self._relay_fingerprint}"
            )
        return found

    # ── reachability probe (used by primary recheck) ───────────

    @staticmethod
    def reachable(url: str, timeout: float = 3.0) -> bool:
        """TCP-level reachability check for `url`. Used to decide whether to
        switch back from a fallback to the primary. Cheap — no WS handshake."""
        try:
            from urllib.parse import urlparse

            p = urlparse(url)
            host = p.hostname
            if not host:
                return False
            port = p.port or (443 if p.scheme == "wss" else 80)
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except (socket.timeout, OSError):
            return False
        except Exception as e:
            log.debug(f"[gw-resolver] reachable() error for {url}: {e}")
            return False
