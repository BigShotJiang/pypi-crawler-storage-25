"""Runtime hot-reload of `.env` configuration — Phase 4.13.

Allows the bridge to pick up new `RELAY_TOKEN`, `RELAY_FINGERPRINT`,
`GATEWAY_URL`, etc. without restarting the systemd service (which would
re-init rclpy and lose ROS2 subscriptions, ~5-10s downtime). Only the
WS connection is bounced (~1s downtime); ROS2 stays alive.

Two trigger paths:
  1. **File watcher** — async task polls `.env` mtime every 5s and reloads
     on change. Operator just edits the file (or scp's a new one).
  2. **SIGHUP** — `kill -HUP <pid>` or `systemctl --user reload`.

Both call [`reload_from_file`][reload_from_file], which:
  - Re-parses `.env`
  - Updates `os.environ` and the matching `config` module attribute
  - Sets the reconnect-requested flag so `ws_client._run`'s main loop
    closes the current WS and rebuilds the resolver from fresh values.

Only a curated set of keys are reloadable (see `_RELOADABLE_KEYS`). Keys
that require ROS2 graph rebuild (topic names, mode) are excluded — those
still need `systemctl restart`.
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal

from . import config as _cfg

log = logging.getLogger(__name__)

# Keys safe to hot-reload. Topic names + mode intentionally excluded —
# changing them at runtime would leave stale rclpy subscriptions.
_RELOADABLE_KEYS = {
    "GATEWAY_URL",
    "API_KEY",
    "RELAY_TOKEN",
    "RELAY_FINGERPRINT",
    "GATEWAY_FAILOVER_TIMEOUT",
    "GATEWAY_PRIMARY_RECHECK_INTERVAL",
    "STATUS_REPORT_INTERVAL",
}

# Shared flag consumed by ws_client._run loop — closes the current WS so
# the next iteration picks up new gateway/token values.
_reconnect_requested = False


def request_reconnect() -> None:
    """Mark that a reconnect should happen at the next opportunity."""
    global _reconnect_requested
    _reconnect_requested = True


def consume_reconnect_request() -> bool:
    """Pop the reconnect flag. Returns True if one was set."""
    global _reconnect_requested
    if _reconnect_requested:
        _reconnect_requested = False
        return True
    return False


def reload_from_file(env_path: str = ".env") -> dict[str, str]:
    """Re-parse `.env` and apply changed reloadable keys.

    Returns the dict of keys that actually changed. Sets the reconnect
    request flag if any key changed. Non-reloadable keys are silently
    ignored.
    """
    if not os.path.exists(env_path):
        log.debug(f"[reload] {env_path} not found")
        return {}

    changed: dict[str, str] = {}
    try:
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip('"').strip("'")
                if k not in _RELOADABLE_KEYS:
                    continue
                old_env = os.environ.get(k)
                if old_env == v:
                    continue
                os.environ[k] = v
                # Mirror into the config module so importers see fresh
                # values. Cast to existing attr's type when applicable.
                if hasattr(_cfg, k):
                    cur = getattr(_cfg, k)
                    if isinstance(cur, float):
                        try:
                            setattr(_cfg, k, float(v))
                        except ValueError:
                            log.warning(f"[reload] invalid float for {k}: {v}")
                            continue
                    elif isinstance(cur, int) and not isinstance(cur, bool):
                        try:
                            setattr(_cfg, k, int(v))
                        except ValueError:
                            log.warning(f"[reload] invalid int for {k}: {v}")
                            continue
                    else:
                        setattr(_cfg, k, v)
                changed[k] = v
    except OSError as e:
        log.warning(f"[reload] read failed: {e}")
        return {}

    if changed:
        log.info(
            f"[reload] applied {len(changed)} key(s): "
            f"{sorted(changed.keys())} — bouncing WS"
        )
        request_reconnect()
    return changed


async def watch_env_file(
    env_path: str = ".env",
    interval: float = 5.0,
) -> None:
    """Async task — polls `.env` mtime every [interval] seconds.

    Cheap (one stat() call per tick); avoids pulling in the `watchdog`
    package. Survives transient FileNotFoundError (e.g. atomic rename
    during scp upload).
    """
    last_mtime: float | None = None
    while True:
        try:
            mtime = os.path.getmtime(env_path)
            if last_mtime is not None and mtime > last_mtime:
                log.info(f"[reload] {env_path} changed (mtime watcher), reloading")
                reload_from_file(env_path)
            last_mtime = mtime
        except FileNotFoundError:
            # File missing — retry next tick (might be mid-rename).
            pass
        except Exception as e:
            log.debug(f"[reload] watcher error: {e}")
        await asyncio.sleep(interval)


def install_sighup_handler(loop: asyncio.AbstractEventLoop, env_path: str = ".env") -> None:
    """Install asyncio SIGHUP handler that triggers a reload.

    Best-effort: on platforms without SIGHUP (Windows), logs a warning
    and continues. Operators trigger via:
        kill -HUP <pid>
        systemctl --user reload ai-teammate-bridge
    """
    def _on_sighup() -> None:
        log.info("[reload] SIGHUP received")
        reload_from_file(env_path)

    try:
        loop.add_signal_handler(signal.SIGHUP, _on_sighup)
        log.info("[reload] SIGHUP handler installed")
    except (NotImplementedError, ValueError, AttributeError) as e:
        log.warning(f"[reload] SIGHUP handler not available on this platform: {e}")
