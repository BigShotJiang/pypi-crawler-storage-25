# Text2JSON SDK

A lightweight Python SDK to convert structured text (list-based data) into clean JSON format using predefined keys.

---

## 🚀 Installation

Install from PyPI:

```bash
pip install text2json-sdk
```

---

## 📌 Quick Start

```python
from text2json_sdk import Text2JSON

keys = ["Name", "Enrollment", "Department", "Location"]

data = [
    ["Gautam", "001", "Production", "Pune"],
    ["Dhruv", "002", "Production", "Gujarat"]
]

converter = Text2JSON(keys)

# Get Python object
result = converter.fill(data)
print(result)

# Get JSON string
json_result = converter.fill(data, as_json=True)
print(json_result)
```

---

## 🧠 How It Works

1. Define a list of keys (schema)
2. Provide structured data as list of rows
3. SDK maps each row to keys
4. Returns JSON-ready output

---

## 📦 Example Output

```json
[
  {
    "Name": "Gautam",
    "Enrollment": "001",
    "Department": "Production",
    "Location": "Pune"
  },
  {
    "Name": "Dhruv",
    "Enrollment": "002",
    "Department": "Production",
    "Location": "Gujarat"
  }
]
```

---

## ✅ Features

- Simple and intuitive API
- Converts list-based data into structured JSON
- Handles missing values automatically
- Input validation with clear errors
- Optional JSON string output

---

## ⚠️ Error Handling

The SDK raises `StructureError` in the following cases:

- Keys are not a list of strings
- Keys list is empty
- Data is not a list of lists
- Row contains too many values
- Row format is invalid

Example:

```python
from text2json_sdk import Text2JSON
from text2json_sdk.exceptions import StructureError

try:
    converter = Text2JSON(["Name", "Age"])
    converter.fill([["Alice", 25, "Extra"]])
except StructureError as e:
    print(e)
```

---

## 🧪 Development Setup

Clone the repository and install locally:

```bash
git clone <your-repo-url>
cd text2json_sdk
pip install -e .
```

Run tests (if added):

```bash
pytest
```

---

## Upload to PyPI:

```bash
twine upload dist/*
```

---

## 🛠 Future Improvements

- CSV file support
- CLI tool (`text2json file.csv`)
- Schema validation
- Async support
- Integration with pandas

---

## 💡 Philosophy

This SDK focuses on simplicity and developer experience:

> "Make structured data transformation effortless and readable."

