import json
from typing import List, Any

from .exceptions import StructureError


class Text2JSON:
    """
    Convert structured list data into JSON using predefined keys.
    """

    def __init__(self, keys: List[str]):
        if not isinstance(keys, list) or not all(isinstance(k, str) for k in keys):
            raise StructureError("Keys must be a list of strings")

        if len(keys) == 0:
            raise StructureError("Keys list cannot be empty")

        self.keys = [k.strip() for k in keys]

    def fill(self, data: List[List[Any]], as_json: bool = False):
        """
        Convert list of rows into structured JSON.

        :param data: List of lists (rows)
        :param as_json: If True, returns JSON string instead of Python object
        :return: List of dictionaries OR JSON string
        """

        if not isinstance(data, list):
            raise StructureError("Data must be a list of lists")

        result = []

        for idx, row in enumerate(data):
            if not isinstance(row, list):
                raise StructureError(f"Row {idx} is not a list")

            # Normalize row values
            row = [str(item).strip() for item in row]

            # Handle missing values
            if len(row) < len(self.keys):
                row += [None] * (len(self.keys) - len(row))

            # Handle extra values
            if len(row) > len(self.keys):
                raise StructureError(
                    f"Row {idx} has too many values. Expected {len(self.keys)}, got {len(row)}"
                )

            obj = dict(zip(self.keys, row))
            result.append(obj)

        return json.dumps(result, indent=2) if as_json else result