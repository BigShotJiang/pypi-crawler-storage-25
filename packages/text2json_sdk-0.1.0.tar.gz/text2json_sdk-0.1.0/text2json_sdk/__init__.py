from .core import Text2JSON

__all__ = ["Text2JSON"]
__version__ = "0.1.0"