class StructureError(Exception):
    """Raised when input structure is invalid"""
    pass