from setuptools import setup, find_packages

setup(
    name             = "total-recall-sdk",
    version          = "0.6.0",
    description      = "Python SDK for Total Recall — on-chain AI agent memory",
    long_description = open("README.md").read(),
    long_description_content_type = "text/markdown",
    author           = "Cleo 3 LLC",
    author_email     = "contact@totalrecallagent.com",
    url              = "https://totalrecallagent.com",
    license          = "MIT",
    packages         = find_packages(),
    python_requires  = ">=3.8",
    install_requires = [],   # zero dependencies — stdlib only
    classifiers      = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Software Development :: Libraries",
        "Intended Audience :: Developers",
    ],
    keywords = "AI agent memory ICP blockchain total-recall",
)
