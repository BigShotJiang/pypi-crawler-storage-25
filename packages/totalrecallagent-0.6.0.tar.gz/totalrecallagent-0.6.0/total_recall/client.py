# ============================================================
# Total Recall — Python SDK
# On-chain memory infrastructure for AI agents
# https://www.totalrecallagent.com
# ============================================================

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional, Union

import requests

# ── Constants ────────────────────────────────────────────────

_IC_HOST      = "https://ic0.app"
_CANISTER_ID  = "fwyts-iiaaa-aaaaj-a6lpq-cai"
_API_BASE     = "https://api.totalrecallagent.com/v1"

# Retry config
_MAX_RETRIES  = 3
_RETRY_DELAY  = 1.0  # seconds


# ── Data Types ───────────────────────────────────────────────

@dataclass
class MemoryEntry:
    """A single memory entry retrieved from Total Recall."""
    key:        str
    value:      Any          # auto-decoded: dict/list if JSON, else str
    tags:       list[str]
    created_at: datetime
    updated_at: datetime
    raw:        Optional[bytes] = field(default=None, repr=False)


class TotalRecallError(Exception):
    """Raised when a Total Recall API call fails."""
    def __init__(self, method: str, kind: str):
        super().__init__(f"[TotalRecall] {method}() failed: {kind}")
        self.method = method
        self.kind   = kind


# ── Client ───────────────────────────────────────────────────

class TotalRecallClient:
    """
    Connect any Python AI agent to on-chain memory via Total Recall.

    Usage::

        from total_recall import TotalRecallClient

        memory = TotalRecallClient(api_key="tr_...")
        memory.store("last_context", {"task": "review", "status": "done"})
        ctx = memory.get("last_context")
        print(ctx.value)  # {"task": "review", "status": "done"}

    All methods are synchronous. For async use, wrap in asyncio.to_thread().
    See TotalRecallAsyncClient for a native async version.
    """

    def __init__(
        self,
        api_key:     str,
        *,
        base_url:    str = _API_BASE,
        timeout:     float = 30.0,
        max_retries: int   = _MAX_RETRIES,
    ):
        if not api_key:
            raise ValueError(
                "[TotalRecall] api_key is required. "
                "Generate one at www.totalrecallagent.com"
            )
        self._api_key     = api_key
        self._base_url    = base_url.rstrip("/")
        self._timeout     = timeout
        self._max_retries = max_retries
        self._session     = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "totalrecallagent-python/0.2.0",
        })

    # ── Core Memory Methods ──────────────────────────────────

    def store(
        self,
        key:   str,
        value: Union[str, dict, list, bytes],
        tags:  list[str] = [],
    ) -> None:
        """
        Store a memory entry. Value can be a string, dict/list (auto JSON-encoded),
        or raw bytes.

        Example::

            memory.store("session_state", {"user": "MTR", "task": "HVAC review"})
            memory.store("raw_log", "Agent woke up at 09:00", tags=["log"])
        """
        payload = {
            "key":   key,
            "value": self._encode(value),
            "tags":  tags,
        }
        self._request("POST", "/memory", json=payload, method_name="store")

    def get(
        self,
        key: str,
        *,
        raw: bool = False,
    ) -> Optional[MemoryEntry]:
        """
        Retrieve a memory entry by key. Returns None if not found.

        Example::

            entry = memory.get("session_state")
            if entry:
                print(entry.value)      # auto-decoded dict or str
                print(entry.tags)       # ["session"]
                print(entry.updated_at) # datetime
        """
        data = self._request("GET", f"/memory/{key}", method_name="get", allow_404=True)
        if data is None:
            return None
        return self._format_entry(data, raw=raw)

    def get_all(self, *, raw: bool = False) -> list[MemoryEntry]:
        """
        Get all stored memory entries at once.

        Example::

            entries = memory.get_all()
            for e in entries:
                print(e.key, e.value)
        """
        data = self._request("GET", "/memory", method_name="get_all")
        return [self._format_entry(e, raw=raw) for e in data.get("entries", [])]

    def keys(self) -> list[str]:
        """
        List all stored memory keys.

        Example::

            ks = memory.keys()
            # ["session_state", "last_context", "project_notes"]
        """
        data = self._request("GET", "/memory/keys", method_name="keys")
        return data.get("keys", [])

    def delete(self, key: str) -> None:
        """
        Delete a memory entry by key. No-op if key doesn't exist.

        Example::

            memory.delete("old_session")
        """
        self._request("DELETE", f"/memory/{key}", method_name="delete", allow_404=True)

    # ── Convenience Helpers ──────────────────────────────────

    def store_json(self, key: str, obj: Any, tags: list[str] = []) -> None:
        """Explicit JSON store. Alias for store() with dict/list."""
        return self.store(key, obj, tags)

    def get_json(self, key: str) -> Optional[Any]:
        """
        Retrieve and parse a JSON value. Returns None if key doesn't exist.

        Example::

            config = memory.get_json("agent_config")
            # {"model": "claude", "temp": 0.7}
        """
        entry = self.get(key)
        if entry is None:
            return None
        if isinstance(entry.value, str):
            try:
                return json.loads(entry.value)
            except json.JSONDecodeError:
                return entry.value
        return entry.value

    def merge(self, key: str, patch: dict, tags: list[str] = []) -> None:
        """
        Merge new data into an existing entry. Creates it if it doesn't exist.

        Example::

            memory.merge("agent_state", {"last_seen": "2026-04-26", "status": "idle"})
        """
        existing = self.get_json(key)
        if isinstance(existing, dict):
            merged = {**existing, **patch}
        else:
            merged = patch
        self.store_json(key, merged, tags)

    def semantic_search(self, query: str, *, k: int = 10) -> list[dict]:
        """
        Semantic search — find memories by meaning, not just keywords.
        Uses BGE-base embeddings via Cloudflare Workers AI.

        Returns list of dicts with MemoryEntry fields + 'score' (0-1 similarity).

        Example::

            results = memory.semantic_search('cooling systems for data centers')
            for r in results:
                print(f'{r["score"]:.3f}', r["key"])
        """
        data = self._request(
            "GET", "/memory/semantic-search",
            params={"q": query, "k": min(k, 20)},
            method_name="semantic_search",
        )
        entries = data.get("entries", []) if data else []
        result = []
        for e in entries:
            entry = self._format_entry(e)
            result.append({
                "key":        entry.key,
                "value":      entry.value,
                "tags":       entry.tags,
                "created_at": entry.created_at,
                "updated_at": entry.updated_at,
                "score":      e.get("score", 0),
            })
        return result

    def search(self, tags: list[str]) -> list[MemoryEntry]:
        """
        Search memory entries by tags. Returns all entries that have ALL of the given tags.

        Example::

            results = memory.search(tags=["session", "hvac"])
            for e in results:
                print(e.key, e.tags)
        """
        data = self._request(
            "GET", "/memory/search",
            params={"tags": ",".join(tags)},
            method_name="search",
        )
        return [self._format_entry(e) for e in data.get("entries", [])]

    # ── Stats & Tier Methods ─────────────────────────────────

    def ping(self) -> str:
        """Check if the canister is reachable."""
        data = self._request("GET", "/ping", method_name="ping")
        return data.get("status", "ok")

    def get_stats(self) -> dict:
        """
        Get current usage stats and tier limits.

        Returns::

            {
                "tier": "Free",             # Free | Pro | Agent | Enterprise
                "storage_bytes": 4096,      # bytes used
                "calls_today": 12,          # calls made today
                "calls_total": 142,         # all-time calls
                "limits": {
                    "storage_bytes": 100000000,
                    "max_api_keys": 1,
                    "calls_per_day": 1000,
                }
            }
        """
        return self._request("GET", "/stats", method_name="get_stats")

    # ── Internal ─────────────────────────────────────────────

    @staticmethod
    def _encode(value: Any) -> str:
        """Encode value to a base string for the API."""
        if isinstance(value, bytes):
            import base64
            return base64.b64encode(value).decode()
        if isinstance(value, (dict, list)):
            return json.dumps(value)
        return str(value)

    @staticmethod
    def _decode(raw_str: str) -> Any:
        """Auto-decode a string value — parse JSON if possible."""
        try:
            return json.loads(raw_str)
        except (json.JSONDecodeError, TypeError):
            return raw_str

    @staticmethod
    def _format_entry(data: dict, *, raw: bool = False) -> MemoryEntry:
        value_str = data.get("value", "")
        value     = value_str if raw else TotalRecallClient._decode(value_str)
        return MemoryEntry(
            key        = data["key"],
            value      = value,
            tags       = data.get("tags", []),
            created_at = datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")),
            updated_at = datetime.fromisoformat(data["updated_at"].replace("Z", "+00:00")),
        )

    def _request(
        self,
        method:      str,
        path:        str,
        *,
        method_name: str = "request",
        allow_404:   bool = False,
        **kwargs,
    ) -> Any:
        url = self._base_url + path
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries):
            try:
                resp = self._session.request(
                    method, url, timeout=self._timeout, **kwargs
                )
                if resp.status_code == 404 and allow_404:
                    return None
                if not resp.ok:
                    # Try to extract error kind from JSON body
                    try:
                        body = resp.json()
                        kind = body.get("error", resp.reason or str(resp.status_code))
                    except Exception:
                        kind = resp.reason or str(resp.status_code)
                    raise TotalRecallError(method_name, kind)
                if resp.status_code == 204:
                    return None
                return resp.json()
            except TotalRecallError:
                raise
            except Exception as exc:
                last_exc = exc
                if attempt < self._max_retries - 1:
                    time.sleep(_RETRY_DELAY * (attempt + 1))

        raise TotalRecallError(method_name, f"NetworkError: {last_exc}")


# ── Async Client ─────────────────────────────────────────────

try:
    import asyncio
    import httpx

    class TotalRecallAsyncClient(TotalRecallClient):
        """
        Async version of TotalRecallClient. Uses httpx under the hood.
        Requires: pip install total-recall httpx

        Usage::

            from total_recall import TotalRecallAsyncClient

            async def main():
                memory = TotalRecallAsyncClient(api_key="tr_...")
                await memory.store("key", {"hello": "world"})
                entry = await memory.get("key")
        """

        def __init__(self, api_key: str, **kwargs):
            super().__init__(api_key, **kwargs)
            self._async_client = httpx.AsyncClient(
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type":  "application/json",
                    "User-Agent":    "totalrecallagent-python/0.2.0",
                },
                timeout=self._timeout,
            )

        async def store(self, key, value, tags=[]):
            return await asyncio.to_thread(super().store, key, value, tags)

        async def get(self, key, *, raw=False):
            return await asyncio.to_thread(super().get, key, raw=raw)

        async def get_all(self, *, raw=False):
            return await asyncio.to_thread(super().get_all, raw=raw)

        async def keys(self):
            return await asyncio.to_thread(super().keys)

        async def delete(self, key):
            return await asyncio.to_thread(super().delete, key)

        async def merge(self, key, patch, tags=[]):
            return await asyncio.to_thread(super().merge, key, patch, tags)

        async def search(self, tags):
            return await asyncio.to_thread(super().search, tags)

        async def get_stats(self):
            return await asyncio.to_thread(super().get_stats)

        async def ping(self):
            return await asyncio.to_thread(super().ping)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            await self._async_client.aclose()

except ImportError:
    pass  # httpx optional — async client unavailable without it


# ============================================================
# SpaceClient — shared/team memory spaces
# ============================================================

class SpaceError(Exception):
    """Raised when a SpaceClient API call fails."""
    def __init__(self, method: str, kind: str):
        super().__init__(f"[SpaceClient] {method}() failed: {kind}")
        self.method = method
        self.kind   = kind


class SpaceClient:
    """
    Read/write a shared memory space using a space API key.

    Spaces are created and managed via the Total Recall web UI (Internet Identity auth).
    Once created, agents interact with space memory using a space API key (``spk_...``).

    Usage::

        from total_recall import SpaceClient

        space = SpaceClient(
            space_api_key="spk_...",  # from Total Recall dashboard
            space_id="sp_...",        # from createSpace()
        )

        space.store("shared_context", {"project": "HVAC-Lab-5", "status": "active"})
        ctx = space.get("shared_context")
        print(ctx.value)
    """

    def __init__(
        self,
        space_api_key: str,
        space_id:      str,
        *,
        base_url:      str   = _API_BASE,
        timeout:       float = 30.0,
        max_retries:   int   = _MAX_RETRIES,
    ):
        if not space_api_key:
            raise ValueError("[SpaceClient] space_api_key is required")
        if not space_id:
            raise ValueError("[SpaceClient] space_id is required")
        self._api_key     = space_api_key
        self._space_id    = space_id
        self._base_url    = base_url.rstrip("/")
        self._timeout     = timeout
        self._max_retries = max_retries
        self._session     = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {space_api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "totalrecallagent-python/0.2.0",
        })

    @property
    def space_prefix(self) -> str:
        return f"/spaces/{self._space_id}/memory"

    def store(
        self,
        key:   str,
        value: Union[str, dict, list, bytes],
        tags:  list[str] = [],
    ) -> None:
        """Store a memory entry in the shared space."""
        payload = {
            "key":   key,
            "value": TotalRecallClient._encode(value),
            "tags":  tags,
        }
        self._request("POST", self.space_prefix, json=payload, method_name="store")

    def get(self, key: str, *, raw: bool = False) -> Optional[MemoryEntry]:
        """Retrieve a memory entry from the space. Returns None if not found."""
        data = self._request("GET", f"{self.space_prefix}/{key}", method_name="get", allow_404=True)
        if data is None:
            return None
        return TotalRecallClient._format_entry(data, raw=raw)

    def keys(self) -> list[str]:
        """List all memory keys in this space."""
        data = self._request("GET", f"{self.space_prefix}/keys", method_name="keys")
        return data.get("keys", [])

    def get_all(self, *, raw: bool = False) -> list[MemoryEntry]:
        """Get all memory entries in the space."""
        data = self._request("GET", self.space_prefix, method_name="get_all")
        return [TotalRecallClient._format_entry(e, raw=raw) for e in data.get("entries", [])]

    def delete(self, key: str) -> None:
        """Delete a memory entry from the space."""
        self._request("DELETE", f"{self.space_prefix}/{key}", method_name="delete", allow_404=True)

    def search(self, tags: list[str]) -> list[MemoryEntry]:
        """Tag search — returns entries that have ALL of the specified tags."""
        data = self._request(
            "GET", f"{self.space_prefix}/search",
            params={"tags": ",".join(tags)},
            method_name="search",
        )
        return [TotalRecallClient._format_entry(e) for e in data.get("entries", [])]

    def semantic_search(self, query: str, *, k: int = 10) -> list[dict]:
        """
        Semantic search across space memories via Cloudflare Workers AI.

        Returns list of dicts with MemoryEntry fields + 'score' (0-1 similarity).
        """
        data = self._request(
            "GET", f"{self.space_prefix}/semantic-search",
            params={"q": query, "k": min(k, 20)},
            method_name="semantic_search",
        )
        entries = data.get("entries", []) if data else []
        result = []
        for e in entries:
            entry = TotalRecallClient._format_entry(e)
            result.append({
                "key":        entry.key,
                "value":      entry.value,
                "tags":       entry.tags,
                "created_at": entry.created_at,
                "updated_at": entry.updated_at,
                "score":      e.get("score", 0),
            })
        return result

    def _request(
        self,
        method:      str,
        path:        str,
        *,
        method_name: str  = "request",
        allow_404:   bool = False,
        **kwargs,
    ) -> Any:
        url       = self._base_url + path
        last_exc: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                resp = self._session.request(method, url, timeout=self._timeout, **kwargs)
                if resp.status_code == 404 and allow_404:
                    return None
                if not resp.ok:
                    try:
                        body = resp.json()
                        kind = body.get("error", resp.reason or str(resp.status_code))
                    except Exception:
                        kind = resp.reason or str(resp.status_code)
                    raise SpaceError(method_name, kind)
                if resp.status_code == 204:
                    return None
                return resp.json()
            except SpaceError:
                raise
            except Exception as exc:
                last_exc = exc
                if attempt < self._max_retries - 1:
                    time.sleep(_RETRY_DELAY * (attempt + 1))
        raise SpaceError(method_name, f"NetworkError: {last_exc}")
