"""
Total Recall LangChain Hub Template
Submit to: smith.langchain.com/hub

This creates a reusable chain template that anyone can pull from
LangChain Hub with: chain = hub.pull("totalrecall/memory-agent")
"""

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser

# The Total Recall memory agent prompt template
# Designed to work with TotalRecallChatMemory
TOTAL_RECALL_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a helpful AI assistant with persistent memory powered by Total Recall.

You remember everything across sessions. At the start of this conversation:
- Your prior context has been loaded from Total Recall
- Greet the user by name if you know it
- Resume from where you left off — never start fresh

During this conversation:
- Save important information to memory as you go
- Tell the user when you've saved something
- Always check your memory before saying you don't know something

You are: {agent_name}
Your memory namespace: agents/{agent_id}/"""),

    MessagesPlaceholder(variable_name="history"),

    ("human", "{input}"),
])


def create_memory_chain(llm, api_key: str, agent_id: str = "agent", agent_name: str = "Assistant"):
    """
    Create a ConversationChain with Total Recall persistent memory.

    Args:
        llm:        Any LangChain LLM (ChatOpenAI, ChatAnthropic, etc.)
        api_key:    Total Recall API key (tr_xxx)
        agent_id:   Agent identifier
        agent_name: Display name for the agent

    Returns:
        chain: Runnable chain with TR memory

    Example:
        from langchain_openai import ChatOpenAI
        from total_recall.langchain_hub import create_memory_chain

        chain = create_memory_chain(
            llm=ChatOpenAI(model="gpt-4o"),
            api_key="tr_your_key",
            agent_id="my-assistant",
            agent_name="Max"
        )

        # First session
        chain.invoke({"input": "My name is MTR and I work in HVAC"})

        # Next session (new Python process) — Max still knows your name
        chain.invoke({"input": "What do you remember about me?"})
    """
    from total_recall.langchain_memory import TotalRecallChatMemory
    from langchain.chains import ConversationChain

    memory = TotalRecallChatMemory(
        api_key=api_key,
        agent_id=agent_id,
        return_messages=True
    )

    prompt = ChatPromptTemplate.from_messages([
        ("system", f"You are {agent_name}, an AI with persistent memory. "
                   f"Your memories are stored on-chain via Total Recall. "
                   f"Resume from prior context. Save important things as you go."),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}"),
    ])

    chain = ConversationChain(
        llm=llm,
        memory=memory,
        prompt=prompt,
        verbose=True
    )
    return chain
