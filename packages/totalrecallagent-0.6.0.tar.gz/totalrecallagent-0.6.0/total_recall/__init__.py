"""
Total Recall Python SDK
© 2026 Cleo 3 LLC — https://totalrecallagent.com

Install:  pip install total-recall-sdk
Usage:    from total_recall import TotalRecallClient
"""

import json
import urllib.request
import urllib.error
from typing import Any, Optional

__version__ = "0.6.0"
__all__      = ["TotalRecallClient", "TotalRecallError"]

BASE_URL = "https://api.totalrecallagent.com/v1"


class TotalRecallError(Exception):
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


class TotalRecallClient:
    """
    Python client for the Total Recall on-chain memory API.

    Example:
        from total_recall import TotalRecallClient

        memory = TotalRecallClient(api_key="tr_your_key_here")
        memory.store("agent/context", {"task": "active", "step": 3})
        ctx = memory.get("agent/context")
        keys = memory.list_keys()
        memory.delete("agent/context")
        stats = memory.stats()
    """

    def __init__(self, api_key: str, base_url: str = BASE_URL, timeout: int = 15):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key  = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

    # ── Internal ──────────────────────────────────────────────

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    f"total-recall-python/{__version__}",
        }

    def _request(self, method: str, path: str, body: Any = None) -> Any:
        url  = f"{self.base_url}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req  = urllib.request.Request(url, data=data, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as e:
            raw = e.read().decode()
            try:
                msg = json.loads(raw).get("error", raw)
            except Exception:
                msg = raw
            raise TotalRecallError(msg, status=e.code)
        except urllib.error.URLError as e:
            raise TotalRecallError(str(e.reason))

    # ── Memory Operations ──────────────────────────────────────

    def store(self, key: str, value: Any, tags: Optional[list] = None, ttl_seconds: Optional[int] = None) -> dict:
        """Store a value at a key. Value can be any JSON-serialisable type."""
        body: dict = {
            "key":   key,
            "value": value if isinstance(value, str) else json.dumps(value),
            "tags":  tags or [],
        }
        if ttl_seconds:
            body["ttl_seconds"] = ttl_seconds
        return self._request("POST", "/memory", body)

    def get(self, key: str) -> Any:
        """Retrieve a value by key. Returns parsed JSON or raw string."""
        result = self._request("GET", f"/memory/{urllib.parse.quote(key, safe='')}")
        val = result.get("value") if result else None
        if val is None:
            return None
        try:
            return json.loads(val)
        except Exception:
            return val

    def delete(self, key: str) -> dict:
        """Delete a memory entry."""
        return self._request("DELETE", f"/memory/{urllib.parse.quote(key, safe='')}")

    def list_keys(self, prefix: Optional[str] = None) -> list:
        """List all memory keys, optionally filtered by prefix."""
        result = self._request("GET", "/memory/keys")
        keys = result if isinstance(result, list) else (result or {}).get("keys", [])
        if prefix:
            keys = [k for k in keys if k.startswith(prefix)]
        return keys

    def get_all(self, prefix: Optional[str] = None) -> list:
        """Get all memory entries, optionally filtered by prefix."""
        result = self._request("GET", "/memory/all")
        entries = result if isinstance(result, list) else []
        if prefix:
            entries = [e for e in entries if e.get("key", "").startswith(prefix)]
        return entries

    def search(self, query: str, tags: Optional[list] = None) -> list:
        """Search memory by tag list."""
        body = {"tags": tags or [query]}
        result = self._request("POST", "/memory/search", body)
        return result if isinstance(result, list) else []

    # ── Stats ──────────────────────────────────────────────────

    def stats(self) -> dict:
        """Get usage stats for this API key."""
        return self._request("GET", "/stats") or {}

    # ── Convenience ────────────────────────────────────────────

    def update(self, key: str, value: Any, tags: Optional[list] = None) -> dict:
        """Alias for store() — upserts the value."""
        return self.store(key, value, tags)

    def exists(self, key: str) -> bool:
        """Check if a key exists."""
        try:
            return self.get(key) is not None
        except TotalRecallError:
            return False

    def store_session(self, agent_id: str, data: dict) -> dict:
        """Store session context for an agent. Key: agents/{agent_id}/context"""
        return self.store(f"agents/{agent_id}/context", data, tags=["agent", "session"])

    def get_session(self, agent_id: str) -> Optional[dict]:
        """Retrieve session context for an agent."""
        return self.get(f"agents/{agent_id}/context")

    def handoff(self, agent_id: str, agent_name: str, message: str) -> dict:
        """Post a session-end handoff to Basecamp (inbox/messages)."""
        import time
        entry = {
            "agentName": agent_name,
            "agentId":   agent_id,
            "message":   message,
            "timestamp": int(time.time() * 1000),
            "read":      False,
        }
        return self.store("inbox/messages", json.dumps(entry), tags=["inbox", "basecamp"])

    # ── Context manager ────────────────────────────────────────

    def __repr__(self):
        return f"TotalRecallClient(key={self.api_key[:12]}..., url={self.base_url})"


# Make urllib.parse available (it's used above)
import urllib.parse
