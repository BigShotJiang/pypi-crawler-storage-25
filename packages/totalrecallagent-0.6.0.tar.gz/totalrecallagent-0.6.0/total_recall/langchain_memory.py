"""
Total Recall LangChain Memory Integration
© 2026 Cleo 3 LLC — totalrecallagent.com

Drop-in persistent memory for LangChain agents using
Total Recall on-chain storage (Internet Computer Protocol).

Install:
    pip install total-recall-sdk langchain langchain-openai

Quick start:
    from total_recall.langchain_memory import TotalRecallChatMemory
    from langchain_openai import ChatOpenAI
    from langchain.chains import ConversationChain

    memory = TotalRecallChatMemory(api_key="tr_your_key")
    chain  = ConversationChain(llm=ChatOpenAI(), memory=memory)
    chain.predict(input="Remember: my name is MTR and I work in HVAC")
    # Next session → chain.predict(input="What do you remember?")
    # Returns: "Your name is MTR and you work in HVAC."
"""

import json
import time
from typing import Any, Dict, List, Optional

from total_recall import TotalRecallClient, TotalRecallError

try:
    from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
    from langchain_core.messages import messages_from_dict, messages_to_dict
    from langchain.memory.chat_memory import BaseChatMemory
    LANGCHAIN_V2 = True
except ImportError:
    try:
        from langchain.schema import BaseMessage, HumanMessage, AIMessage
        from langchain.schema.messages import messages_from_dict, messages_to_dict
        from langchain.memory.chat_memory import BaseChatMemory
        LANGCHAIN_V2 = False
    except ImportError:
        BaseChatMemory = object
        LANGCHAIN_V2   = False


class TotalRecallChatMemory(BaseChatMemory if BaseChatMemory != object else object):
    """
    LangChain chat memory backed by Total Recall on-chain storage.

    Stores full conversation history on the Internet Computer blockchain.
    History survives across sessions, LLMs, and devices.

    Args:
        api_key:         Your Total Recall API key (tr_xxx)
        agent_id:        Identifier for this agent (used as key prefix)
        session_id:      Session identifier (auto-generated if not provided)
        max_history:     Max messages to keep (default 50)
        return_messages: Return as message objects vs string (default True)
        human_prefix:    Label for human turns in string mode
        ai_prefix:       Label for AI turns in string mode

    Example:
        memory = TotalRecallChatMemory(api_key="tr_xxx", agent_id="support-bot")
        chain  = ConversationChain(llm=ChatOpenAI(), memory=memory)
    """

    def __init__(
        self,
        api_key: str,
        agent_id: str = "langchain-agent",
        session_id: Optional[str] = None,
        max_history: int = 50,
        return_messages: bool = True,
        human_prefix: str = "Human",
        ai_prefix: str = "AI",
        **kwargs
    ):
        if BaseChatMemory == object:
            raise ImportError("pip install langchain")
        super().__init__(**kwargs)
        self.client          = TotalRecallClient(api_key=api_key)
        self.agent_id        = agent_id
        self.session_id      = session_id or f"session-{int(time.time())}"
        self.max_history     = max_history
        self.return_messages = return_messages
        self.human_prefix    = human_prefix
        self.ai_prefix       = ai_prefix
        self._key            = f"langchain/{agent_id}/history"

    @property
    def memory_variables(self) -> List[str]:
        return ["history"]

    def _load(self) -> List:
        try:
            data = self.client.get(self._key)
            if data and isinstance(data, list):
                return messages_from_dict(data[-self.max_history:])
        except TotalRecallError:
            pass
        return []

    def _save(self, messages: List) -> None:
        try:
            self.client.store(
                self._key,
                json.dumps(messages_to_dict(messages[-self.max_history:])),
                tags=["langchain", "history", self.agent_id]
            )
        except TotalRecallError as e:
            print(f"[TotalRecall] Warning: {e}")

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        messages = self._load()
        if self.return_messages:
            return {"history": messages}
        buf = "\n".join(
            f"{self.human_prefix}: {m.content}" if isinstance(m, HumanMessage)
            else f"{self.ai_prefix}: {m.content}"
            for m in messages
        )
        return {"history": buf}

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        msgs = self._load()
        msgs.append(HumanMessage(content=str(inputs.get("input", inputs))))
        msgs.append(AIMessage(content=str(outputs.get("response", outputs.get("output", outputs)))))
        self._save(msgs)

    def clear(self) -> None:
        try: self.client.delete(self._key)
        except TotalRecallError: pass


class TotalRecallAgentMemory:
    """
    Key-value memory store for autonomous LangChain agents.
    All keys are namespaced to agent_id.

    Example:
        mem = TotalRecallAgentMemory(api_key="tr_xxx", agent_id="researcher")
        mem.save("current_topic", "ICP blockchain architecture")
        mem.save("sources", ["paper1", "paper2"])
        topic = mem.load("current_topic")
        mem.handoff("Research complete — sources saved to 'sources' key")
    """

    def __init__(self, api_key: str, agent_id: str = "agent"):
        self.client    = TotalRecallClient(api_key=api_key)
        self.agent_id  = agent_id
        self.namespace = f"agents/{agent_id}"

    def save(self, key: str, value: Any, tags: Optional[list] = None) -> None:
        val = json.dumps(value) if not isinstance(value, str) else value
        self.client.store(f"{self.namespace}/{key}", val,
                          tags=tags or ["agent", self.agent_id])

    def load(self, key: str, default=None) -> Any:
        try: return self.client.get(f"{self.namespace}/{key}") or default
        except TotalRecallError: return default

    def delete(self, key: str) -> None:
        try: self.client.delete(f"{self.namespace}/{key}")
        except TotalRecallError: pass

    def keys(self, prefix: str = "") -> List[str]:
        ns = f"{self.namespace}/{prefix}" if prefix else self.namespace
        return self.client.list_keys(prefix=ns)

    def handoff(self, message: str) -> None:
        self.client.handoff(self.agent_id, self.agent_id, message)


def make_total_recall_tools(api_key: str, agent_id: str = "agent"):
    """
    Create LangChain Tool objects for Total Recall.
    Compatible with initialize_agent() and AgentExecutor.

    Example:
        from langchain.agents import initialize_agent, AgentType
        from langchain_openai import ChatOpenAI

        tools = make_total_recall_tools("tr_xxx", "my-agent")
        agent = initialize_agent(
            tools, ChatOpenAI(model="gpt-4o"),
            agent=AgentType.OPENAI_FUNCTIONS
        )
        agent.run("Remember that the project deadline is June 1st")
    """
    try:
        from langchain.tools import Tool
    except ImportError:
        raise ImportError("pip install langchain")

    mem = TotalRecallAgentMemory(api_key=api_key, agent_id=agent_id)

    def _store(x: str) -> str:
        if "::" not in x:
            return "Error: use format 'key::value'"
        k, v = x.split("::", 1)
        mem.save(k.strip(), v.strip())
        return f"Stored '{k.strip()}' ✓"

    def _get(key: str) -> str:
        val = mem.load(key.strip())
        return str(val) if val is not None else f"No memory found for key '{key.strip()}'"

    def _keys(_: str) -> str:
        keys = mem.keys()
        return "\n".join(keys) if keys else "No memories stored yet"

    def _handoff(msg: str) -> str:
        mem.handoff(msg)
        return "Session summary posted to Basecamp ✓"

    return [
        Tool(name="store_memory",
             description="Store info in persistent memory. Input format: 'key::value'. Use hierarchical keys like 'project/status' or 'user/name'. Call this after learning anything important.",
             func=_store),
        Tool(name="get_memory",
             description="Retrieve stored info by key. Returns the stored value or 'not found'.",
             func=_get),
        Tool(name="list_memory_keys",
             description="List all memory keys. Call with empty string. Use at session start.",
             func=_keys),
        Tool(name="session_handoff",
             description="Post session completion summary when done. Input: summary of what was accomplished and what's next.",
             func=_handoff),
    ]
