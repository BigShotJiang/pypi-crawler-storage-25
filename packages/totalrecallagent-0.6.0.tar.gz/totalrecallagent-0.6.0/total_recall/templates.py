# ============================================================
# Total Recall — Agent Memory Templates
# Pre-built memory structures for common agent patterns
# ============================================================

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import TotalRecallClient, SpaceClient

_API_BASE = "https://api.totalrecallagent.com/v1"


@dataclass
class TemplateField:
    """A single field in a memory template."""
    key:           str
    description:   str
    default_value: Any
    tags:          list[str] = field(default_factory=list)
    required:      bool = False


class MemoryTemplate:
    """
    Pre-built memory structure for a common agent pattern.

    Built-in templates::

        MemoryTemplate.SESSION       # session state tracking
        MemoryTemplate.TASK          # task management
        MemoryTemplate.USER          # user profile & preferences
        MemoryTemplate.AGENT_CONFIG  # agent configuration
        MemoryTemplate.PROJECT       # project state
        MemoryTemplate.KNOWLEDGE     # knowledge base

    Usage::

        from total_recall import TotalRecallClient, MemoryTemplate

        memory = TotalRecallClient(api_key="tr_...")

        # Apply template (only writes missing keys)
        written = MemoryTemplate.SESSION.instantiate(memory)
        print(f"Initialized {written} keys")

        # Use the structured keys
        memory.merge("session/current", {"task": "analyze logs", "status": "active"})
        state = memory.get_json("session/current")
    """

    def __init__(
        self,
        name:        str,
        description: str,
        fields:      list[TemplateField],
        version:     str = "1.0",
    ):
        self.name        = name
        self.description = description
        self.version     = version
        self.fields      = fields

    def instantiate(self, client: "TotalRecallClient | SpaceClient") -> int:
        """
        Apply this template to a client, writing default values for missing keys.
        Returns the number of keys written.

        Only writes fields that don't already exist — safe to call multiple times.
        """
        existing = set(client.keys())
        written  = 0
        for f in self.fields:
            if f.key not in existing:
                val = (
                    json.dumps(f.default_value)
                    if isinstance(f.default_value, (dict, list))
                    else str(f.default_value)
                )
                client.store(f.key, val, f.tags)
                written += 1
        return written

    def instantiate_via_api(self, api_key: str) -> int:
        """
        Apply this template via the REST API (single round-trip).
        The canister handles the key-existence check server-side.

        Returns the number of keys written.
        """
        import requests
        res = requests.post(
            f"{_API_BASE}/templates/{self.name}/instantiate",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )
        res.raise_for_status()
        return res.json().get("keys_written", 0)

    def register(self, api_key: str, is_public: bool = True) -> None:
        """
        Register this template to the on-chain registry.
        Makes it discoverable via MemoryTemplate.list() and MemoryTemplate.fetch().
        """
        import requests
        payload = {
            "name":        self.name,
            "description": self.description,
            "version":     self.version,
            "is_public":   is_public,
            "fields": [
                {
                    "key":           f.key,
                    "description":   f.description,
                    "default_value": f.default_value,
                    "tags":          f.tags,
                    "required":      f.required,
                }
                for f in self.fields
            ],
        }
        res = requests.post(
            f"{_API_BASE}/templates",
            json=payload,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type":  "application/json",
            },
            timeout=30,
        )
        res.raise_for_status()

    @classmethod
    def fetch(cls, name: str) -> "MemoryTemplate":
        """Fetch a template from the on-chain registry by name."""
        import requests
        res = requests.get(f"{_API_BASE}/templates/{name}", timeout=30)
        if res.status_code == 404:
            raise ValueError(f"Template '{name}' not found")
        res.raise_for_status()
        return cls._from_dict(res.json())

    @classmethod
    def list(cls) -> list["MemoryTemplate"]:
        """List all public templates from the on-chain registry."""
        import requests
        res = requests.get(f"{_API_BASE}/templates", timeout=30)
        res.raise_for_status()
        return [cls._from_dict(t) for t in res.json().get("templates", [])]

    @classmethod
    def _from_dict(cls, data: dict) -> "MemoryTemplate":
        fields = [
            TemplateField(
                key           = f["key"],
                description   = f["description"],
                default_value = f.get("default_value", ""),
                tags          = f.get("tags", []),
                required      = f.get("required", False),
            )
            for f in data.get("fields", [])
        ]
        return cls(
            name        = data["name"],
            description = data.get("description", ""),
            version     = data.get("version", "1.0"),
            fields      = fields,
        )

    def __repr__(self) -> str:
        return f"MemoryTemplate(name={self.name!r}, fields={len(self.fields)})"


# ── Built-in Templates ───────────────────────────────────────────────────────

MemoryTemplate.SESSION = MemoryTemplate(
    name        = "session",
    description = "Track current session state for AI agents",
    fields = [
        TemplateField(
            key           = "session/current",
            description   = "Current session metadata: status, task, startedAt",
            default_value = {"status": "idle", "task": None, "startedAt": None, "model": None},
            tags          = ["session", "state"],
            required      = True,
        ),
        TemplateField(
            key           = "session/history",
            description   = "Array of recent session summaries",
            default_value = [],
            tags          = ["session", "history"],
        ),
        TemplateField(
            key           = "session/preferences",
            description   = "Persistent preferences that carry across sessions",
            default_value = {"verbosity": "normal", "language": "en", "timezone": None},
            tags          = ["session", "prefs"],
        ),
    ],
)

MemoryTemplate.TASK = MemoryTemplate(
    name        = "task",
    description = "Task state tracking for agents doing multi-step work",
    fields = [
        TemplateField(
            key           = "task/current",
            description   = "The currently active task",
            default_value = {"id": None, "title": None, "status": "pending", "priority": "normal", "startedAt": None},
            tags          = ["task", "state"],
            required      = True,
        ),
        TemplateField(
            key           = "task/steps",
            description   = "Ordered list of steps for the current task",
            default_value = [],
            tags          = ["task", "steps"],
        ),
        TemplateField(
            key           = "task/blockers",
            description   = "List of blockers preventing task completion",
            default_value = [],
            tags          = ["task", "blockers"],
        ),
        TemplateField(
            key           = "task/completed",
            description   = "Log of recently completed tasks",
            default_value = [],
            tags          = ["task", "history"],
        ),
    ],
)

MemoryTemplate.USER = MemoryTemplate(
    name        = "user",
    description = "User profile and preferences for personalized agent behavior",
    fields = [
        TemplateField(
            key           = "user/profile",
            description   = "Core user info: name, timezone, role",
            default_value = {"name": None, "timezone": None, "role": None, "language": "en"},
            tags          = ["user", "profile"],
            required      = True,
        ),
        TemplateField(
            key           = "user/preferences",
            description   = "User preferences for agent behavior",
            default_value = {"responseStyle": "concise", "notifications": True, "autoSave": True},
            tags          = ["user", "prefs"],
        ),
        TemplateField(
            key           = "user/context",
            description   = "Background context about the user (domain, goals)",
            default_value = {"domain": None, "goals": [], "notes": ""},
            tags          = ["user", "context"],
        ),
        TemplateField(
            key           = "user/interactions",
            description   = "Summary of recent interactions and feedback",
            default_value = {"lastActive": None, "totalSessions": 0, "feedback": []},
            tags          = ["user", "history"],
        ),
    ],
)

MemoryTemplate.AGENT_CONFIG = MemoryTemplate(
    name        = "agent-config",
    description = "Agent configuration: model, tools, persona, instructions",
    fields = [
        TemplateField(
            key           = "agent/config",
            description   = "Core agent config: model, thinking level, max tokens",
            default_value = {"model": None, "thinking": "adaptive", "maxTokens": 4096, "temperature": None},
            tags          = ["agent", "config"],
            required      = True,
        ),
        TemplateField(
            key           = "agent/persona",
            description   = "Agent persona and tone guidelines",
            default_value = {"name": None, "tone": "helpful", "style": "concise", "language": "en"},
            tags          = ["agent", "persona"],
        ),
        TemplateField(
            key           = "agent/tools",
            description   = "Enabled tools and their configurations",
            default_value = {"enabled": [], "disabled": [], "customInstructions": {}},
            tags          = ["agent", "tools"],
        ),
        TemplateField(
            key           = "agent/instructions",
            description   = "System-level instructions and constraints",
            default_value = "",
            tags          = ["agent", "instructions"],
        ),
    ],
)

MemoryTemplate.PROJECT = MemoryTemplate(
    name        = "project",
    description = "Project state tracking for long-running work",
    fields = [
        TemplateField(
            key           = "project/meta",
            description   = "Project identity: name, description, owner, phase",
            default_value = {"name": None, "description": None, "owner": None, "phase": "planning", "createdAt": None},
            tags          = ["project", "meta"],
            required      = True,
        ),
        TemplateField(
            key           = "project/milestones",
            description   = "List of milestones with status and target dates",
            default_value = [],
            tags          = ["project", "milestones"],
        ),
        TemplateField(
            key           = "project/current-focus",
            description   = "What the team is working on right now",
            default_value = {"item": None, "since": None, "notes": ""},
            tags          = ["project", "focus"],
        ),
        TemplateField(
            key           = "project/decisions",
            description   = "Log of key architectural or product decisions",
            default_value = [],
            tags          = ["project", "decisions"],
        ),
        TemplateField(
            key           = "project/links",
            description   = "Important URLs: repo, docs, CI, deployments",
            default_value = {"repo": None, "docs": None, "ci": None, "production": None, "staging": None},
            tags          = ["project", "links"],
        ),
    ],
)

MemoryTemplate.KNOWLEDGE = MemoryTemplate(
    name        = "knowledge",
    description = "Knowledge base for storing domain facts, rules, and references",
    fields = [
        TemplateField(
            key           = "knowledge/facts",
            description   = "Factual statements the agent should know",
            default_value = [],
            tags          = ["knowledge", "facts"],
        ),
        TemplateField(
            key           = "knowledge/rules",
            description   = "Business rules or constraints to follow",
            default_value = [],
            tags          = ["knowledge", "rules"],
        ),
        TemplateField(
            key           = "knowledge/examples",
            description   = "Few-shot examples for task guidance",
            default_value = [],
            tags          = ["knowledge", "examples"],
        ),
        TemplateField(
            key           = "knowledge/glossary",
            description   = "Domain-specific terms and definitions",
            default_value = {},
            tags          = ["knowledge", "glossary"],
        ),
        TemplateField(
            key           = "knowledge/references",
            description   = "External references: docs, papers, URLs",
            default_value = [],
            tags          = ["knowledge", "refs"],
        ),
    ],
)

MemoryTemplate.TOTAL_RECALL = MemoryTemplate(
    name        = "total-recall",
    description = "Record everything — sessions, decisions, errors, facts, relationships, goals, skills, and timeline. Designed for append-style accumulation over an agent's lifetime.",
    fields = [
        TemplateField(
            key           = "recall/sessions",
            description   = "Log of every session: summary, task, outcome, timestamp. Append each run.",
            default_value = [],
            tags          = ["recall", "sessions", "log"],
            required      = True,
        ),
        TemplateField(
            key           = "recall/decisions",
            description   = "Log of significant decisions made, with reasoning and outcome.",
            default_value = [],
            tags          = ["recall", "decisions", "log"],
        ),
        TemplateField(
            key           = "recall/errors",
            description   = "Mistakes made and lessons learned. Never delete — learn from them.",
            default_value = [],
            tags          = ["recall", "errors", "lessons"],
        ),
        TemplateField(
            key           = "recall/facts",
            description   = "Growing pile of discovered facts about the world, the user, and the domain.",
            default_value = [],
            tags          = ["recall", "facts", "knowledge"],
        ),
        TemplateField(
            key           = "recall/relationships",
            description   = "People, tools, systems, and services the agent interacts with regularly.",
            default_value = {},
            tags          = ["recall", "relationships"],
        ),
        TemplateField(
            key           = "recall/goals",
            description   = "Short and long-term goals, updated over time. Includes completed goals.",
            default_value = {"active": [], "completed": [], "abandoned": []},
            tags          = ["recall", "goals"],
        ),
        TemplateField(
            key           = "recall/skills",
            description   = "Things the agent has gotten better at. Track growth over time.",
            default_value = [],
            tags          = ["recall", "skills", "growth"],
        ),
        TemplateField(
            key           = "recall/timeline",
            description   = "Chronological log of significant events in the agent's life.",
            default_value = [],
            tags          = ["recall", "timeline", "history"],
        ),
        TemplateField(
            key           = "recall/identity",
            description   = "Who this agent is — name, purpose, capabilities, owner, created date.",
            default_value = {"name": None, "purpose": None, "owner": None, "model": None, "createdAt": None, "capabilities": []},
            tags          = ["recall", "identity"],
            required      = True,
        ),
    ],
)

BUILT_IN_TEMPLATES: list[MemoryTemplate] = [
    MemoryTemplate.SESSION,
    MemoryTemplate.TASK,
    MemoryTemplate.USER,
    MemoryTemplate.AGENT_CONFIG,
    MemoryTemplate.PROJECT,
    MemoryTemplate.KNOWLEDGE,
    MemoryTemplate.TOTAL_RECALL,
]
