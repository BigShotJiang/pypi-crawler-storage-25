"""Service generation, diffing, and installation logic (cross-platform)."""

from __future__ import annotations

import datetime
import difflib
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING
from xml.sax.saxutils import escape as xml_escape

from svci import platform as plat
from svci.template import LAUNCHD_TEMPLATE, SYSTEMD_TEMPLATE

if TYPE_CHECKING:
    from argparse import Namespace

# ── colour helpers ──────────────────────────────────────────────────

RED = "\033[31m"
GREEN = "\033[32m"
CYAN = "\033[36m"
RESET = "\033[0m"


def _coloured_diff(old: str, new: str, old_label: str, new_label: str) -> str:
    lines: list[str] = []
    for line in difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=old_label,
        tofile=new_label,
    ):
        if line.startswith("---") or line.startswith("+++"):
            lines.append(f"{CYAN}{line}{RESET}")
        elif line.startswith("-"):
            lines.append(f"{RED}{line}{RESET}")
        elif line.startswith("+"):
            lines.append(f"{GREEN}{line}{RESET}")
        else:
            lines.append(line)
    return "".join(lines)


# ── venv check ──────────────────────────────────────────────────────

def _check_venv(working_dir: Path) -> None:
    venv = working_dir / ".venv"
    if not venv.is_dir():
        print(f"\u26a0\ufe0f  No .venv found in {working_dir}")
        print("   The run command may fail if it depends on a virtual environment.")
    else:
        print(f"\u2705 .venv detected in {working_dir}")


# ── template loading ────────────────────────────────────────────────

_SYSTEMD_EXT = Path.home() / ".config" / "svci" / "templates" / "systemd.service-template"
_LAUNCHD_EXT = Path.home() / ".config" / "svci" / "templates" / "launchd.plist-template"


def _load_template(override: str | None, os_plat: str) -> str:
    if override:
        p = Path(override).expanduser()
        if p.is_file():
            print(f"\U0001f4c4 Using custom template: {p}")
            return p.read_text()
        print(f"\u26a0\ufe0f  Template not found at {p}, falling back to built-in")

    ext = _LAUNCHD_EXT if plat.is_macos(os_plat) else _SYSTEMD_EXT
    if ext.is_file():
        print(f"\U0001f4c4 Using external template: {ext}")
        return ext.read_text()

    kind = "launchd" if plat.is_macos(os_plat) else "systemd"
    print(f"\U0001f4e6 Using built-in {kind} template")
    return LAUNCHD_TEMPLATE if plat.is_macos(os_plat) else SYSTEMD_TEMPLATE


# ═══════════════════════════════════════════════════════════════════
# Linux / systemd helpers
# ═══════════════════════════════════════════════════════════════════

def _systemd_unit_path(name: str, mode: str) -> Path:
    if mode == "user":
        return Path.home() / ".config" / "systemd" / "user" / f"{name}.service"
    if mode == "system-at-user":
        return Path(f"/etc/systemd/system/{name}@.service")
    return Path(f"/etc/systemd/system/{name}.service")


def _systemd_unit_name(name: str, mode: str) -> str:
    if mode == "system-at-user":
        return f"{name}@.service"
    return f"{name}.service"


_systemd_unit_filename = _systemd_unit_name


def _systemd_check_existing(unit_path: Path, name: str, mode: str) -> str | None:
    if not unit_path.exists():
        return None
    print(f"\U0001f50d Existing unit file found: {unit_path}")
    from svci import systemd_dbus as sd
    user_bus = mode == "user"
    unit_svc = _systemd_unit_name(name, mode)
    try:
        state = sd.get_unit_active_state(unit_svc, user_bus)
        file_state = sd.get_unit_file_state(unit_svc, user_bus)
        print(f"\U0001f4cb Active: {state}  |  UnitFile: {file_state}")
    except (RuntimeError, OSError) as exc:
        print(f"\u26a0\ufe0f  Could not query unit state via D-Bus: {exc}")
    return unit_path.read_text()


def _systemd_check_linger(args: Namespace) -> None:
    if args.service_mode != "user":
        return
    from svci import systemd_dbus as sd
    username = args.user or os.getlogin()
    sd.print_linger_status(username)


def _render_systemd(args: Namespace, template: str) -> str:
    working_dir = Path(args.working_dir).expanduser().resolve()
    name = args.name or working_dir.name

    if args.service_mode in ("system", "system-at-user"):
        user = args.user or os.getlogin()
        group = args.group or user
        user_group_block = f"User={user}\nGroup={group}"
    else:
        user_group_block = "# (user service -- User=/Group= omitted)"

    if args.service_mode == "user":
        install_target = "WantedBy=default.target"
    else:
        install_target = "WantedBy=multi-user.target"

    # Environment block from pyproject.toml or defaults
    env_vars = getattr(args, "environment", {})
    overrides = getattr(args, "systemd_overrides", {})
    restart = overrides.get("restart", "on-failure")
    restart_sec = overrides.get("restart_sec", 5)

    if env_vars:
        env_lines = [f'Environment="{k}={v}"' for k, v in env_vars.items()]
        environment_block = "\n".join(env_lines)
    else:
        environment_block = (
            "# --- Environment ---\n"
            "# Uncomment or add variables as needed:\n"
            '# Environment="APP_ENV=production"\n'
            '# Environment="LOG_LEVEL=info"\n'
            f"# EnvironmentFile=/etc/default/{name}"
        )

    # Apply systemd-specific overrides to template before formatting
    rendered = template.replace("Restart=on-failure", f"Restart={restart}")
    rendered = rendered.replace("RestartSec=5", f"RestartSec={restart_sec}")

    return rendered.format(
        install_date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        description=args.description,
        working_dir=working_dir,
        run_cmd=args.run_cmd,
        name=name,
        user_group_block=user_group_block,
        install_target=install_target,
        environment_block=environment_block,
    )


def _systemd_install(args: Namespace, name: str, mode: str, unit_path: Path, content: str) -> None:
    from svci import systemd_dbus as sd
    user_bus = mode == "user"

    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(content)
    print(f"\u2705 Unit file written to {unit_path}")

    try:
        sd.daemon_reload(user_bus)
        print(f"\u2705 Daemon reloaded (D-Bus)")
    except (RuntimeError, OSError) as exc:
        print(f"\u26a0\ufe0f  D-Bus daemon-reload failed: {exc}")
        print("   You may need to run: systemctl daemon-reload")

    svc_name = f"{name}@{args.user}" if mode == "system-at-user" and args.user else name
    unit_svc = _systemd_unit_name(name, mode) if mode != "system-at-user" else f"{svc_name}.service"

    if args.enable:
        try:
            sd.enable_unit(unit_svc, user_bus)
            print(f"\u2705 Service enabled: {svc_name} (D-Bus)")
        except (RuntimeError, OSError) as exc:
            print(f"\u26a0\ufe0f  D-Bus enable failed: {exc}")

    if args.start:
        try:
            sd.start_unit(unit_svc, user_bus)
            print(f"\u2705 Service started: {svc_name} (D-Bus)")
        except (RuntimeError, OSError) as exc:
            print(f"\u26a0\ufe0f  D-Bus start failed: {exc}")


# ═══════════════════════════════════════════════════════════════════
# macOS / launchd helpers
# ═══════════════════════════════════════════════════════════════════

def _launchd_check_existing(name: str, mode: str) -> str | None:
    from svci import launchd as ld
    return ld.read_existing_plist(name, mode)


def _render_launchd(args: Namespace, template: str) -> str:
    from svci import launchd as ld

    working_dir = Path(args.working_dir).expanduser().resolve()
    name = args.name or working_dir.name
    mode = args.service_mode

    # Split run-cmd into argument array for ProgramArguments
    parts = shlex.split(args.run_cmd)
    prog_args = "\n".join(
        f"        <string>{xml_escape(p)}</string>" for p in parts
    )

    # UserName block (system daemons only)
    if mode in ("system", "system-at-user"):
        user = args.user or os.getlogin()
        user_name_block = (
            f"\n    <key>UserName</key>\n"
            f"    <string>{xml_escape(user)}</string>\n"
        )
    else:
        user_name_block = ""

    # Environment block from pyproject.toml or placeholder
    env_vars = getattr(args, "environment", {})
    overrides = getattr(args, "launchd_overrides", {})
    run_at_load = overrides.get("run_at_load", True)

    if env_vars:
        env_entries = []
        for k, v in env_vars.items():
            env_entries.append(f"        <key>{xml_escape(str(k))}</key>")
            env_entries.append(f"        <string>{xml_escape(str(v))}</string>")
        environment_block = (
            "\n    <key>EnvironmentVariables</key>\n"
            "    <dict>\n"
            + "\n".join(env_entries) + "\n"
            "    </dict>\n"
        )
    else:
        environment_block = (
            "\n    <!-- Uncomment to set environment variables:\n"
            "    <key>EnvironmentVariables</key>\n"
            "    <dict>\n"
            "        <key>APP_ENV</key>\n"
            "        <string>production</string>\n"
            "    </dict>\n"
            "    -->\n"
        )

    logdir = ld.log_dir(name, mode)

    return template.format(
        install_date=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        label=xml_escape(ld.plist_label(name)),
        program_arguments=prog_args,
        working_dir=xml_escape(str(working_dir)),
        run_at_load="true" if run_at_load else "false",
        log_dir=xml_escape(str(logdir)),
        name=xml_escape(name),
        user_name_block=user_name_block,
        environment_block=environment_block,
    )


def _launchd_install(args: Namespace, name: str, mode: str, content: str) -> None:
    from svci import launchd as ld

    path = ld.plist_path(name, mode)
    logdir = ld.log_dir(name, mode)

    # Ensure directories exist
    path.parent.mkdir(parents=True, exist_ok=True)
    logdir.mkdir(parents=True, exist_ok=True)

    # Set log directory ownership for system daemons
    if mode in ("system", "system-at-user") and args.user:
        try:
            import pwd
            pw = pwd.getpwnam(args.user)
            os.chown(logdir, pw.pw_uid, pw.pw_gid)
            print(f"\u2705 Log directory ownership set to {args.user}")
        except (KeyError, PermissionError, OSError) as exc:
            print(f"\u26a0\ufe0f  Could not set log dir ownership: {exc}")

    # If already loaded, bootout first
    if ld.is_loaded(name, mode):
        print(f"\U0001f504 Unloading existing service...")
        try:
            ld.bootout(name, mode)
        except (subprocess.CalledProcessError, OSError):
            pass

    path.write_text(content)
    print(f"\u2705 Plist written to {path}")

    # System LaunchDaemons must be owned by root:wheel with mode 644
    if mode in ("system", "system-at-user"):
        try:
            import grp
            import pwd
            root_uid = pwd.getpwnam("root").pw_uid
            wheel_gid = grp.getgrnam("wheel").gr_gid
            os.chown(path, root_uid, wheel_gid)
            os.chmod(path, 0o644)
            print(f"\u2705 Permissions set: root:wheel 644")
        except (KeyError, PermissionError, OSError) as exc:
            print(f"\u26a0\ufe0f  Could not set file permissions: {exc}")
            print(f"   Run: sudo chown root:wheel {path} && sudo chmod 644 {path}")

    if args.enable:
        try:
            ld.enable(name, mode)
            print(f"\u2705 Service enabled: {ld.plist_label(name)}")
        except (subprocess.CalledProcessError, OSError) as exc:
            print(f"\u26a0\ufe0f  Enable failed: {exc}")

    if args.start or args.enable:
        try:
            ld.bootstrap(name, mode)
            print(f"\u2705 Service loaded: {ld.plist_label(name)}")
        except (subprocess.CalledProcessError, OSError) as exc:
            print(f"\u26a0\ufe0f  Bootstrap failed: {exc}")

    if args.start:
        try:
            ld.kickstart(name, mode)
            print(f"\u2705 Service started: {ld.plist_label(name)}")
        except (subprocess.CalledProcessError, OSError) as exc:
            print(f"\u26a0\ufe0f  Kickstart failed: {exc}")


# ═══════════════════════════════════════════════════════════════════
# DIY bundle (cross-platform)
# ═══════════════════════════════════════════════════════════════════

def _generate_diy(args: Namespace, name: str, mode: str, content: str, os_plat: str) -> None:
    diy_dir = Path.home() / "tmp" / name
    diy_dir.mkdir(parents=True, exist_ok=True)

    if plat.is_macos(os_plat):
        _generate_diy_macos(args, name, mode, content, diy_dir)
    else:
        _generate_diy_linux(args, name, mode, content, diy_dir)

    print(f"\n\U0001f4c2 DIY bundle ready: {diy_dir}/")
    print(f"   Follow the instructions in README.md to deploy manually.")


def _generate_diy_linux(args: Namespace, name: str, mode: str, content: str, diy_dir: Path) -> None:
    unit_path = _systemd_unit_path(name, mode)
    svc_name = f"{name}@{args.user}" if mode == "system-at-user" and args.user else name
    unit_filename = _systemd_unit_filename(name, mode)

    (diy_dir / unit_filename).write_text(content)
    print(f"\u2705 Unit file written to {diy_dir / unit_filename}")

    readme = _build_readme_linux(
        name=name, mode=mode, unit_filename=unit_filename,
        unit_path=unit_path, svc_name=svc_name,
        working_dir=Path(args.working_dir).expanduser().resolve(),
        user=args.user,
    )
    (diy_dir / "README.md").write_text(readme)
    print(f"\u2705 README written to {diy_dir / 'README.md'}")


def _generate_diy_macos(args: Namespace, name: str, mode: str, content: str, diy_dir: Path) -> None:
    from svci import launchd as ld

    filename = ld.plist_filename(name)
    plist_dst = ld.plist_path(name, mode)
    label = ld.plist_label(name)
    logdir = ld.log_dir(name, mode)

    (diy_dir / filename).write_text(content)
    print(f"\u2705 Plist written to {diy_dir / filename}")

    readme = _build_readme_macos(
        name=name, mode=mode, filename=filename,
        plist_dst=plist_dst, label=label, logdir=logdir,
        working_dir=Path(args.working_dir).expanduser().resolve(),
        user=args.user,
    )
    (diy_dir / "README.md").write_text(readme)
    print(f"\u2705 README written to {diy_dir / 'README.md'}")


# ── Linux README builder ───────────────────────────────────────────

def _build_readme_linux(
    *, name: str, mode: str, unit_filename: str, unit_path: Path,
    svc_name: str, working_dir: Path, user: str | None,
) -> str:
    L: list[str] = []
    w = L.append
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    w(f"# Manual deployment: {name} (Linux / systemd)\n")
    w(f"Generated by `svci` on {ts}.\n")

    w("## Prerequisites\n")
    w(f"- Application directory exists: `{working_dir}`")
    w(f"- Virtual environment set up in `{working_dir}/.venv`")
    if mode == "user":
        w("- Logged in as the user who will own the service\n")
    else:
        w("- Root / sudo access\n")

    if mode == "user":
        username = user or os.getlogin()
        w("## Enable linger (important!)\n")
        w("User services stop when you log out unless **linger** is enabled.\n")
        w("```bash")
        w(f"loginctl show-user {username} --property=Linger")
        w(f"sudo loginctl enable-linger {username}")
        w("```\n")
        w("> Without linger your service **will stop** when your SSH session ends.\n")

    w("## Install the unit file\n")
    if mode == "user":
        w("```bash")
        w(f"mkdir -p ~/.config/systemd/user")
        w(f"cp {unit_filename} {unit_path}")
        w(f"systemctl --user daemon-reload")
        w("```\n")
    else:
        w("```bash")
        if mode == "system-at-user":
            w(f"sudo cp {unit_filename} {unit_path}")
        else:
            w(f"sudo cp {unit_filename} {unit_path}")
        w(f"sudo systemctl daemon-reload")
        w("```\n")

    w("## Enable and start\n")
    if mode == "user":
        w("```bash")
        w(f"systemctl --user enable {svc_name}")
        w(f"systemctl --user start {svc_name}")
        w(f"systemctl --user status {svc_name}")
        w("```\n")
    else:
        w("```bash")
        w(f"sudo systemctl enable {svc_name}")
        w(f"sudo systemctl start {svc_name}")
        w(f"sudo systemctl status {svc_name}")
        w("```\n")

    w("## View logs\n")
    if mode == "user":
        w("```bash")
        w(f"journalctl --user -u {svc_name} -f")
        w("```\n")
    else:
        w("```bash")
        w(f"journalctl -u {svc_name} -f")
        w("```\n")

    w("## Stop / disable / remove\n")
    if mode == "user":
        w("```bash")
        w(f"systemctl --user stop {svc_name}")
        w(f"systemctl --user disable {svc_name}")
        w(f"rm {unit_path}")
        w(f"systemctl --user daemon-reload")
        w("```\n")
    else:
        w("```bash")
        w(f"sudo systemctl stop {svc_name}")
        w(f"sudo systemctl disable {svc_name}")
        w(f"sudo rm {unit_path}")
        w(f"sudo systemctl daemon-reload")
        w("```\n")

    return "\n".join(L)


# ── macOS README builder ───────────────────────────────────────────

def _build_readme_macos(
    *, name: str, mode: str, filename: str, plist_dst: Path,
    label: str, logdir: Path, working_dir: Path, user: str | None,
) -> str:
    L: list[str] = []
    w = L.append
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    uid = os.getuid()

    w(f"# Manual deployment: {name} (macOS / launchd)\n")
    w(f"Generated by `svci` on {ts}.\n")

    w("## Prerequisites\n")
    w(f"- Application directory exists: `{working_dir}`")
    w(f"- Virtual environment set up in `{working_dir}/.venv`")
    if mode == "user":
        w("- Logged in as the user who will own the agent\n")
    else:
        w("- Root / sudo access\n")

    # ── terminology note ────────────────────────────
    w("## How launchd works\n")
    if mode == "user":
        w("On macOS, user-level background services are called **LaunchAgents**.")
        w(f"Plist files go in `~/Library/LaunchAgents/`.")
        w("They start automatically at login when `RunAtLoad` is true.\n")
    else:
        w("On macOS, system-level background services are called **LaunchDaemons**.")
        w(f"Plist files go in `/Library/LaunchDaemons/`.")
        w("They start automatically at boot.\n")

    # ── install ─────────────────────────────────────
    w("## Install the plist\n")
    if mode == "user":
        w("```bash")
        w(f"# Create log directory")
        w(f"mkdir -p {logdir}")
        w(f"")
        w(f"# Copy the plist")
        w(f"cp {filename} {plist_dst}")
        w("```\n")
    else:
        w("```bash")
        w(f"# Create log directory")
        w(f"sudo mkdir -p {logdir}")
        w(f"")
        w(f"# Copy the plist")
        w(f"sudo cp {filename} {plist_dst}")
        w(f"sudo chown root:wheel {plist_dst}")
        w(f"sudo chmod 644 {plist_dst}")
        w("```\n")

    # ── load & start ────────────────────────────────
    w("## Load and start\n")
    if mode == "user":
        domain = f"gui/{uid}"
        w("```bash")
        w(f"# Load the agent (modern launchctl)")
        w(f"launchctl bootstrap {domain} {plist_dst}")
        w(f"")
        w(f"# Enable so it persists across reboots")
        w(f"launchctl enable {domain}/{label}")
        w(f"")
        w(f"# Start immediately (if not already running)")
        w(f"launchctl kickstart -k {domain}/{label}")
        w("```\n")
        w("Or using the legacy commands:\n")
        w("```bash")
        w(f"launchctl load -w {plist_dst}")
        w("```\n")
    else:
        w("```bash")
        w(f"# Load the daemon")
        w(f"sudo launchctl bootstrap system {plist_dst}")
        w(f"")
        w(f"# Enable so it persists across reboots")
        w(f"sudo launchctl enable system/{label}")
        w(f"")
        w(f"# Start immediately")
        w(f"sudo launchctl kickstart -k system/{label}")
        w("```\n")

    # ── status ──────────────────────────────────────
    w("## Check status\n")
    if mode == "user":
        domain = f"gui/{uid}"
        w("```bash")
        w(f"launchctl print {domain}/{label}")
        w(f"")
        w(f"# Quick check (shows PID if running)")
        w(f"launchctl list | grep {label}")
        w("```\n")
    else:
        w("```bash")
        w(f"sudo launchctl print system/{label}")
        w(f"sudo launchctl list | grep {label}")
        w("```\n")

    # ── logs ────────────────────────────────────────
    w("## View logs\n")
    w("```bash")
    w(f"tail -f {logdir}/{name}.out.log")
    w(f"tail -f {logdir}/{name}.err.log")
    w("```\n")

    # ── stop / unload / remove ──────────────────────
    w("## Stop / unload / remove\n")
    if mode == "user":
        domain = f"gui/{uid}"
        w("```bash")
        w(f"launchctl bootout {domain}/{label}")
        w(f"rm {plist_dst}")
        w("```\n")
    else:
        w("```bash")
        w(f"sudo launchctl bootout system/{label}")
        w(f"sudo rm {plist_dst}")
        w("```\n")

    return "\n".join(L)


# ═══════════════════════════════════════════════════════════════════
# Operations help (post-install / dry-run / --help-platform)
# ═══════════════════════════════════════════════════════════════════

BOLD = "\033[1m"
DIM = "\033[2m"


def _ops_help_systemd(name: str, mode: str, user: str | None) -> str:
    """Return systemd operational commands as a help string."""
    username = user or "<user>"
    svc_name = f"{name}@{username}" if mode == "system-at-user" else name
    unit_svc = f"{name}@.service" if mode == "system-at-user" else f"{name}.service"
    unit_path = _systemd_unit_path(name, mode)
    is_user = mode == "user"
    ctl = "systemctl --user" if is_user else "sudo systemctl"
    jctl = "journalctl --user" if is_user else "journalctl"

    L: list[str] = []
    w = L.append

    w(f"{BOLD}── Manage: {svc_name} (systemd / {mode}) ──{RESET}\n")

    # Linger (user mode only)
    if is_user:
        w(f"{BOLD}Enable linger{RESET} {DIM}(keeps user services running after logout){RESET}")
        w(f"  loginctl show-user {username} --property=Linger")
        w(f"  sudo loginctl enable-linger {username}\n")

    # Enable / start
    w(f"{BOLD}Enable & start{RESET}")
    w(f"  {ctl} enable {svc_name}")
    w(f"  {ctl} start {svc_name}\n")

    # Status
    w(f"{BOLD}Status{RESET}")
    w(f"  {ctl} status {svc_name}")
    w(f"  {ctl} is-active {svc_name}\n")

    # Restart
    w(f"{BOLD}Restart{RESET}")
    w(f"  {ctl} restart {svc_name}\n")

    # Logs
    w(f"{BOLD}Logs{RESET}")
    w(f"  {jctl} -u {svc_name} -f          {DIM}# follow{RESET}")
    w(f"  {jctl} -u {svc_name} -xe         {DIM}# last entries + explanations{RESET}")
    w(f"  {jctl} -u {svc_name} --since today{RESET}\n")

    # Stop / disable
    w(f"{BOLD}Stop & disable{RESET}")
    w(f"  {ctl} stop {svc_name}")
    w(f"  {ctl} disable {svc_name}\n")

    # Remove
    w(f"{BOLD}Remove completely{RESET}")
    w(f"  {ctl} stop {svc_name}")
    w(f"  {ctl} disable {svc_name}")
    if is_user:
        w(f"  rm {unit_path}")
        w(f"  {ctl} daemon-reload")
    else:
        w(f"  sudo rm {unit_path}")
        w(f"  {ctl} daemon-reload")

    return "\n".join(L)


def _ops_help_launchd(name: str, mode: str, user: str | None) -> str:
    """Return launchd operational commands as a help string."""
    from svci import launchd as ld

    label = ld.plist_label(name)
    plist = ld.plist_path(name, mode)
    logdir = ld.log_dir(name, mode)
    uid = os.getuid()
    is_user = mode == "user"
    domain = f"gui/{uid}" if is_user else "system"
    target = f"{domain}/{label}"
    sudo = "" if is_user else "sudo "

    L: list[str] = []
    w = L.append

    kind = "LaunchAgent" if is_user else "LaunchDaemon"
    w(f"{BOLD}── Manage: {label} (launchd / {kind}) ──{RESET}\n")

    # Load & enable
    w(f"{BOLD}Load & enable{RESET}")
    w(f"  {sudo}launchctl bootstrap {domain} {plist}")
    w(f"  {sudo}launchctl enable {target}\n")

    # Start (kickstart)
    w(f"{BOLD}Start / restart{RESET}")
    w(f"  {sudo}launchctl kickstart -k {target}\n")

    # Status
    w(f"{BOLD}Status{RESET}")
    w(f"  {sudo}launchctl print {target}")
    w(f"  {sudo}launchctl list | grep {label}\n")

    # Stop
    w(f"{BOLD}Stop{RESET}")
    w(f"  {sudo}launchctl kill SIGTERM {target}\n")

    # Logs
    w(f"{BOLD}Logs{RESET}")
    w(f"  tail -f {logdir}/{name}.out.log  {DIM}# stdout{RESET}")
    w(f"  tail -f {logdir}/{name}.err.log  {DIM}# stderr{RESET}\n")

    # Unload / remove
    w(f"{BOLD}Unload & remove{RESET}")
    w(f"  {sudo}launchctl bootout {target}")
    w(f"  {sudo}rm {plist}")

    return "\n".join(L)


def print_ops_help(name: str, mode: str, user: str | None, os_plat: str) -> None:
    """Print platform-specific operational commands."""
    print()
    if plat.is_macos(os_plat):
        print(_ops_help_launchd(name, mode, user))
    else:
        print(_ops_help_systemd(name, mode, user))
    print()


# ═══════════════════════════════════════════════════════════════════
# Main entry point
# ═══════════════════════════════════════════════════════════════════

def generate_and_install(args: Namespace) -> None:
    working_dir = Path(args.working_dir).expanduser().resolve()
    name = args.name or working_dir.name
    mode = args.service_mode
    os_plat = plat.detect()

    kind = "launchd agent" if plat.is_macos(os_plat) else "systemd service"
    print(f"\n\U0001f680 svci - {kind} generator  [{os_plat}]\n")
    print(f"   Name          : {name}")
    print(f"   Mode          : {mode}")
    print(f"   Working dir   : {working_dir}")
    print(f"   Run command   : {args.run_cmd}\n")

    _check_venv(working_dir)

    # ── platform-specific pre-checks ────────────────
    if plat.is_linux(os_plat):
        _systemd_check_linger(args)
        unit_path = _systemd_unit_path(name, mode)
        existing = _systemd_check_existing(unit_path, name, mode)
    else:
        from svci import launchd as ld
        # system-at-user maps to system daemon with UserName on macOS
        if mode == "system-at-user":
            print(f"\u2139\ufe0f  system-at-user maps to a system LaunchDaemon with UserName on macOS")
        existing = _launchd_check_existing(name, mode)
        unit_path = ld.plist_path(name, mode)

    # ── render ──────────────────────────────────────
    template = _load_template(args.template, os_plat)
    if plat.is_macos(os_plat):
        content = _render_launchd(args, template)
    else:
        content = _render_systemd(args, template)

    # ── DIY mode ────────────────────────────────────
    if args.diy:
        _generate_diy(args, name, mode, content, os_plat)
        return

    # ── dry run ─────────────────────────────────────
    if not args.install:
        print(f"\n\U0001f4dd Generated {kind} file (dry run):\n")
        print(content)
        print("Pass --install to write to disk, or --diy for a manual deployment bundle.")
        print_ops_help(name, mode, args.user, os_plat)
        return

    # ── diff + force check ──────────────────────────
    if existing is not None:
        diff = _coloured_diff(existing, content, str(unit_path), "<new>")
        if diff:
            print(f"\n\U0001f504 Changes:\n{diff}")
            if not args.force:
                print(f"\u274c File already exists at {unit_path}")
                print("   Use --force to overwrite.")
                sys.exit(1)
            print(f"\u26a1 --force: overwriting {unit_path}")
        else:
            print(f"\u2705 File is already up to date at {unit_path}")
    else:
        print(f"\u2728 Writing new file: {unit_path}")

    # ── install ─────────────────────────────────────
    if plat.is_linux(os_plat):
        _systemd_install(args, name, mode, unit_path, content)
    else:
        _launchd_install(args, name, mode, content)

    print(f"\n\U0001f389 Done!")
    print_ops_help(name, mode, args.user, os_plat)
