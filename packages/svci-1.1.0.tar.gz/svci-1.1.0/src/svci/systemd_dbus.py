"""D-Bus interaction with systemd (systemd1) and logind (login1) via jeepney."""

from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path

from jeepney import DBusAddress, MessageType, new_method_call
from jeepney.io.blocking import open_dbus_connection

# ── D-Bus addresses ────────────────────────────────────────────────

SYSTEMD_MANAGER = DBusAddress(
    object_path="/org/freedesktop/systemd1",
    bus_name="org.freedesktop.systemd1",
    interface="org.freedesktop.systemd1.Manager",
)

LOGIN_MANAGER = DBusAddress(
    object_path="/org/freedesktop/login1",
    bus_name="org.freedesktop.login1",
    interface="org.freedesktop.login1.Manager",
)

UNIT_IFACE = "org.freedesktop.systemd1.Unit"
PROPS_IFACE = "org.freedesktop.DBus.Properties"


# ── connection helpers ──────────────────────────────────────────────

@contextmanager
def _bus(user_bus: bool):
    """Open a blocking D-Bus connection, ensuring it is closed afterwards."""
    bus = "SESSION" if user_bus else "SYSTEM"
    conn = open_dbus_connection(bus)
    try:
        yield conn
    finally:
        conn.close()


def _call(conn, msg):
    """Send a message and return the reply body, raising on D-Bus errors."""
    reply = conn.send_and_get_reply(msg)
    if reply.header.message_type == MessageType.error:
        err_name = reply.header.fields.get(reply.header.fields.__class__(7), "")
        err_body = reply.body[0] if reply.body else ""
        raise RuntimeError(f"D-Bus error {err_name}: {err_body}")
    return reply.body


# ── systemd1.Manager wrappers ──────────────────────────────────────

def daemon_reload(user_bus: bool) -> None:
    with _bus(user_bus) as conn:
        msg = new_method_call(SYSTEMD_MANAGER, "Reload")
        _call(conn, msg)


def start_unit(name: str, user_bus: bool) -> None:
    with _bus(user_bus) as conn:
        msg = new_method_call(SYSTEMD_MANAGER, "StartUnit", "ss", (name, "replace"))
        _call(conn, msg)


def stop_unit(name: str, user_bus: bool) -> None:
    with _bus(user_bus) as conn:
        msg = new_method_call(SYSTEMD_MANAGER, "StopUnit", "ss", (name, "replace"))
        _call(conn, msg)


def enable_unit(name: str, user_bus: bool) -> None:
    with _bus(user_bus) as conn:
        # EnableUnitFiles(files: as, runtime: b, force: b) -> (carries_install_info: b, changes: a(sss))
        msg = new_method_call(
            SYSTEMD_MANAGER, "EnableUnitFiles", "asbb", ([name], False, False),
        )
        _call(conn, msg)


def get_unit_active_state(name: str, user_bus: bool) -> str:
    """Return the ActiveState of a unit (e.g. 'active', 'inactive', 'failed')."""
    try:
        with _bus(user_bus) as conn:
            # First, get the unit object path
            msg = new_method_call(SYSTEMD_MANAGER, "GetUnit", "s", (name,))
            (unit_path,) = _call(conn, msg)

            # Then read its ActiveState property
            unit_addr = DBusAddress(
                object_path=unit_path,
                bus_name="org.freedesktop.systemd1",
                interface=PROPS_IFACE,
            )
            msg = new_method_call(unit_addr, "Get", "ss", (UNIT_IFACE, "ActiveState"))
            (variant,) = _call(conn, msg)
            # variant is (signature, value)
            return variant[1]
    except RuntimeError:
        return "not-found"


def get_unit_file_state(name: str, user_bus: bool) -> str:
    """Return the UnitFileState (e.g. 'enabled', 'disabled', 'masked')."""
    try:
        with _bus(user_bus) as conn:
            msg = new_method_call(
                SYSTEMD_MANAGER, "GetUnitFileState", "s", (name,),
            )
            (state,) = _call(conn, msg)
            return state
    except RuntimeError:
        return "not-found"


# ── linger check via login1 + filesystem ────────────────────────────

def check_linger(username: str | None = None) -> bool:
    """Check whether lingering is enabled for the given user.

    First checks /var/lib/systemd/linger/<user> (fast, no D-Bus needed).
    Falls back to querying logind via D-Bus if the filesystem check is
    inconclusive (e.g. permission denied).
    """
    if username is None:
        username = os.getlogin()

    # Fast path: linger is a simple file presence check
    linger_file = Path(f"/var/lib/systemd/linger/{username}")
    if linger_file.exists():
        return True

    # Fall back to D-Bus: ask logind for the user object, read Linger property
    try:
        with _bus(user_bus=False) as conn:  # logind is always on the system bus
            uid = os.getuid()
            msg = new_method_call(LOGIN_MANAGER, "GetUser", "u", (uid,))
            (user_path,) = _call(conn, msg)

            user_addr = DBusAddress(
                object_path=user_path,
                bus_name="org.freedesktop.login1",
                interface=PROPS_IFACE,
            )
            msg = new_method_call(
                user_addr, "Get", "ss",
                ("org.freedesktop.login1.User", "Linger"),
            )
            (variant,) = _call(conn, msg)
            return bool(variant[1])
    except (RuntimeError, OSError):
        return False


def print_linger_status(username: str | None = None) -> bool:
    """Print linger status and return whether linger is enabled."""
    if username is None:
        username = os.getlogin()

    enabled = check_linger(username)
    if enabled:
        print(f"\u2705 Linger is enabled for {username}")
    else:
        print(f"\u26a0\ufe0f  Linger is NOT enabled for {username}")
        print(f"   User services may stop when you log out.")
        print(f"   Enable with: loginctl enable-linger {username}")
    return enabled
