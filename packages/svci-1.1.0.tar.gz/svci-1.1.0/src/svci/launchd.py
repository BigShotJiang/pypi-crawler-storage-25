"""macOS launchd interaction via launchctl."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path


# ── label / path helpers ────────────────────────────────────────────

LABEL_PREFIX = "com.svci"


def plist_label(name: str) -> str:
    return f"{LABEL_PREFIX}.{name}"


def plist_path(name: str, mode: str) -> Path:
    """Return the canonical plist file path."""
    label = plist_label(name)
    if mode == "user":
        return Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"
    return Path("/Library/LaunchDaemons") / f"{label}.plist"


def plist_filename(name: str) -> str:
    return f"{plist_label(name)}.plist"


def log_dir(name: str, mode: str) -> Path:
    if mode == "user":
        return Path.home() / "Library" / "Logs" / "svci"
    return Path("/var/log/svci")


# ── launchctl wrappers ─────────────────────────────────────────────

def _uid() -> int:
    return os.getuid()


def _domain_target(mode: str) -> str:
    """Return the launchctl domain-target (gui/<uid> or system)."""
    if mode == "user":
        return f"gui/{_uid()}"
    return "system"


def _service_target(name: str, mode: str) -> str:
    """Return the launchctl service-target (domain/label)."""
    return f"{_domain_target(mode)}/{plist_label(name)}"


def _run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def bootstrap(name: str, mode: str) -> None:
    """Load and register the plist (modern launchctl)."""
    path = plist_path(name, mode)
    domain = _domain_target(mode)
    _run(["launchctl", "bootstrap", domain, str(path)])


def bootout(name: str, mode: str) -> None:
    """Unload the service (modern launchctl)."""
    target = _service_target(name, mode)
    _run(["launchctl", "bootout", target], check=False)


def kickstart(name: str, mode: str) -> None:
    """Start (or restart) the service immediately."""
    target = _service_target(name, mode)
    _run(["launchctl", "kickstart", "-k", target])


def stop(name: str, mode: str) -> None:
    """Stop the service via kill signal."""
    target = _service_target(name, mode)
    _run(["launchctl", "kill", "SIGTERM", target], check=False)


def enable(name: str, mode: str) -> None:
    """Enable the service so it loads on boot/login."""
    target = _service_target(name, mode)
    _run(["launchctl", "enable", target])


def disable(name: str, mode: str) -> None:
    """Disable the service."""
    target = _service_target(name, mode)
    _run(["launchctl", "disable", target])


def get_status(name: str, mode: str) -> dict[str, str]:
    """Query service status. Returns dict with 'state' and 'pid' keys."""
    target = _service_target(name, mode)
    result = _run(["launchctl", "print", target], check=False)
    if result.returncode != 0:
        return {"state": "not-loaded", "pid": "-"}

    info: dict[str, str] = {"state": "loaded", "pid": "-"}
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if stripped.startswith("state ="):
            info["state"] = stripped.split("=", 1)[1].strip()
        elif stripped.startswith("pid ="):
            info["pid"] = stripped.split("=", 1)[1].strip()
    return info


def is_loaded(name: str, mode: str) -> bool:
    label = plist_label(name)
    result = _run(["launchctl", "list"], check=False)
    return label in result.stdout


def print_status(name: str, mode: str) -> None:
    """Print human-friendly status."""
    info = get_status(name, mode)
    state = info["state"]
    pid = info["pid"]
    label = plist_label(name)
    if state == "not-loaded":
        print(f"\U0001f4cb {label}: not loaded")
    else:
        print(f"\U0001f4cb {label}: state={state}  pid={pid}")


# ── plist reading helper ───────────────────────────────────────────

def read_existing_plist(name: str, mode: str) -> str | None:
    """Return existing plist text if present, else None."""
    path = plist_path(name, mode)
    if not path.exists():
        return None
    print(f"\U0001f50d Existing plist found: {path}")
    print_status(name, mode)
    return path.read_text()
