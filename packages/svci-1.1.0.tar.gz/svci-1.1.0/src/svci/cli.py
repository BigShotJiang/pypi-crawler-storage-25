"""CLI entry point for svci."""

from __future__ import annotations

import sys
import tomllib
from pathlib import Path

import configargparse

from svci.service import generate_and_install, print_ops_help


# ── pyproject.toml reader ──────────────────────────────────────────

# Mapping from [tool.svci] keys to argparse dest names.
_PYPROJECT_KEY_MAP = {
    "name": "name",
    "description": "description",
    "working_dir": "working_dir",
    "run_cmd": "run_cmd",
    "service_mode": "service_mode",
    "user": "user",
    "group": "group",
    "template": "template",
}


def _load_pyproject(path: Path) -> dict:
    """Read [tool.svci] from a pyproject.toml file."""
    if not path.is_file():
        print(f"\u274c pyproject.toml not found: {path}", file=sys.stderr)
        sys.exit(1)
    with open(path, "rb") as f:
        data = tomllib.load(f)
    svci_cfg = data.get("tool", {}).get("svci", {})
    if not svci_cfg:
        print(f"\u274c No [tool.svci] section in {path}", file=sys.stderr)
        sys.exit(1)
    print(f"\U0001f4c4 Reading config from {path} [tool.svci]")
    return svci_cfg


def _apply_pyproject(args, pyproject_cfg: dict) -> None:
    """Merge pyproject.toml values into args (CLI args take precedence)."""
    # Flat keys
    for toml_key, dest in _PYPROJECT_KEY_MAP.items():
        if toml_key in pyproject_cfg:
            current = getattr(args, dest, None)
            # Only apply if CLI didn't set it (None or default)
            if current is None:
                setattr(args, dest, pyproject_cfg[toml_key])

    # description has a non-None default, so check explicitly
    if "description" in pyproject_cfg and args.description == "Service managed by svci":
        args.description = pyproject_cfg["description"]

    # Environment variables dict
    if "environment" in pyproject_cfg:
        args.environment = pyproject_cfg["environment"]

    # Platform-specific overrides
    if "systemd" in pyproject_cfg:
        args.systemd_overrides = pyproject_cfg["systemd"]
    if "launchd" in pyproject_cfg:
        args.launchd_overrides = pyproject_cfg["launchd"]


# ── parser ─────────────────────────────────────────────────────────

def build_parser() -> configargparse.ArgumentParser:
    config_files = [
        "~/.config/svci/config.toml",
    ]
    p = configargparse.ArgumentParser(
        prog="svci",
        description="Service generator for Python apps (systemd on Linux, launchd on macOS)",
        default_config_files=config_files,
        config_file_parser_class=configargparse.TomlConfigParser(["svci"]),
    )

    p.add_argument(
        "-c", "--config",
        is_config_file=True,
        help="Path to config file",
    )

    p.add_argument(
        "--version", action="version", version="%(prog)s 1.1.0",
    )

    # --- pyproject.toml ---
    p.add_argument(
        "--pyproject",
        nargs="?",
        const="pyproject.toml",
        default=None,
        metavar="PATH",
        help="Read [tool.svci] from pyproject.toml (default: ./pyproject.toml)",
    )

    # --- service identity ---
    p.add_argument(
        "--name",
        env_var="SVCI_NAME",
        help="Service name (default: parent directory name of --working-dir)",
    )
    p.add_argument(
        "--description",
        env_var="SVCI_DESCRIPTION",
        default="Service managed by svci",
        help="Service description",
    )

    # --- paths & command ---
    p.add_argument(
        "--working-dir",
        env_var="SVCI_WORKING_DIR",
        help="Working directory for the service",
    )
    p.add_argument(
        "--run-cmd",
        env_var="SVCI_RUN_CMD",
        help="Command to run (ExecStart on Linux, ProgramArguments on macOS)",
    )

    # --- service mode ---
    p.add_argument(
        "--service-mode",
        env_var="SVCI_SERVICE_MODE",
        choices=["user", "system", "system-at-user"],
        default="user",
        help=(
            "Service mode: user (systemd user unit / LaunchAgent), "
            "system (systemd system unit / LaunchDaemon), "
            "system-at-user (name@user on Linux, LaunchDaemon+UserName on macOS)"
        ),
    )
    p.add_argument(
        "--user",
        env_var="SVCI_USER",
        help="User for system / system-at-user modes",
    )
    p.add_argument(
        "--group",
        env_var="SVCI_GROUP",
        help="Group for system modes (Linux only)",
    )

    # --- template override ---
    p.add_argument(
        "--template",
        env_var="SVCI_TEMPLATE",
        help="Path to custom template file",
    )

    # --- actions ---
    p.add_argument(
        "--diy",
        action="store_true",
        help="Generate a ~/tmp/<name>/ bundle with service file + README for manual deployment",
    )
    p.add_argument(
        "--install",
        action="store_true",
        help="Write service file and manage via D-Bus (Linux) or launchctl (macOS)",
    )
    p.add_argument(
        "--enable",
        action="store_true",
        help="Enable the service after install",
    )
    p.add_argument(
        "--start",
        action="store_true",
        help="Start the service after install",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing service file without confirmation",
    )
    p.add_argument(
        "--help-platform",
        action="store_true",
        help="Show platform-specific commands to manage the service (enable, start, stop, logs, remove)",
    )

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Ensure environment and platform override attrs exist
    if not hasattr(args, "environment"):
        args.environment = {}
    if not hasattr(args, "systemd_overrides"):
        args.systemd_overrides = {}
    if not hasattr(args, "launchd_overrides"):
        args.launchd_overrides = {}

    # Load pyproject.toml if requested
    if args.pyproject is not None:
        pyproject_path = Path(args.pyproject).expanduser().resolve()
        pyproject_cfg = _load_pyproject(pyproject_path)
        _apply_pyproject(args, pyproject_cfg)
        # If --working-dir not set via CLI or pyproject, use pyproject.toml's directory
        if args.working_dir is None:
            args.working_dir = str(pyproject_path.parent)

    # --help-platform: works standalone with generic placeholders, or with a real name
    if args.help_platform:
        from svci import platform as plat
        os_plat = plat.detect()
        name = args.name
        if not name and args.working_dir:
            name = Path(args.working_dir).expanduser().resolve().name
        if not name:
            name = "<svc-name>"
        user = args.user or "<user>"
        print_ops_help(name, args.service_mode, user, os_plat)
        return

    # Validate required fields
    if not args.working_dir:
        parser.error("--working-dir is required (or use --pyproject)")
    if not args.run_cmd:
        parser.error("--run-cmd is required (or set run_cmd in [tool.svci])")

    generate_and_install(args)
