"""svci - Service installer for Python apps (systemd + launchd)."""
