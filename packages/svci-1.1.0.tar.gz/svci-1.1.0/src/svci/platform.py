"""Platform detection and backend routing."""

from __future__ import annotations

import sys

LINUX = "linux"
MACOS = "macos"


def detect() -> str:
    """Return the current platform identifier."""
    if sys.platform == "darwin":
        return MACOS
    if sys.platform.startswith("linux"):
        return LINUX
    raise SystemExit(f"Unsupported platform: {sys.platform}")


def is_linux(platform: str | None = None) -> bool:
    return (platform or detect()) == LINUX


def is_macos(platform: str | None = None) -> bool:
    return (platform or detect()) == MACOS
