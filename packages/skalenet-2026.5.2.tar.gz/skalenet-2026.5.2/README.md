# skale
SKALE: Hybrid Slater–Koster Tight-Binding Atomistic Line Graph Engine for Quantum Materials Design
