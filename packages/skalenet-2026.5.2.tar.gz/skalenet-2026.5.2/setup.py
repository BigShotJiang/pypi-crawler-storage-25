from setuptools import setup, find_packages
from pathlib import Path

base_dir = Path(__file__).resolve().parent
long_description = (base_dir / "README.md").read_text(encoding="utf-8")

setup(
    name="skalenet",
    version="2026.5.2",
    description="SKALENET: Hybrid Slater-Koster Tight-Binding Atomsitic Line Graph Networks for Scalable Materials Design",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Kamal Choudhary",
    author_email="kchoudh2@jhu.edu",
    url="https://github.com/atomgptlab/skalenet",
    license="MIT",

    packages=find_packages(),

    install_requires=[
        "numpy>=1.20.1",
        "scipy>=1.5.0",
        "matplotlib>=3.0.0",
        "torch>=2.0",
        "alignn",
        "slakonet",
    ],

    python_requires=">=3.9",

    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],

    keywords=[
        "materials science",
        "tight binding",
        "graph neural network",
        "quantum materials",
        "machine learning",
        "electronic structure",
    ],
)
