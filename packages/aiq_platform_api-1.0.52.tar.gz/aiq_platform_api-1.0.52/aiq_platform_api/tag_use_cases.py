import asyncio
import uuid
from enum import Enum
from typing import Optional

from aiq_platform_api import (
    AttackIQClient,
    AttackIQLogger,
    Assets,
    Tags,
    TagSets,
    TaggedItems,
    ATTACKIQ_PLATFORM_URL,
    ATTACKIQ_PLATFORM_API_TOKEN,
)
from aiq_platform_api.core.testing import parse_test_choice, require_env

logger = AttackIQLogger.get_logger(__name__)


_TEST_TAGSET_PREFIX = "aiq-sdk-test-tagset"
_TEST_TAG_PREFIX = "aiq-sdk-test-tag"


def _unique_name(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


async def list_tags(client: AttackIQClient, limit: Optional[int] = 10) -> int:
    logger.info(f"Listing up to {limit} tags...")
    tag_count = 0

    async for tag in Tags.get_tags(client, limit=limit):
        tag_count += 1
        logger.info(f"Tag {tag_count}:")
        logger.info(f"  ID: {tag.get('id', 'N/A')}")
        logger.info(f"  Name: {tag.get('name', 'N/A')}")
        logger.info(f"  Display Name: {tag.get('display_name', 'N/A')}")
        logger.info(f"  Tag Set ID: {tag.get('tag_set_id', 'N/A')}")
        logger.info("---")

    logger.info(f"Total tags listed: {tag_count}")
    return tag_count


async def add_custom_tag(client: AttackIQClient, tag_name: str) -> Optional[str]:
    logger.info(f"Adding new tag: {tag_name} to Custom tag set")
    result = await Tags.get_or_create_custom_tag(client, tag_name)
    tag = result["tag"]
    logger.info(f"Tag '{tag_name}' ready with ID '{tag['id']}' (created={result['created']})")
    return tag["id"]


async def remove_tag(client: AttackIQClient, tag_id: str) -> bool:
    logger.info(f"Removing tag with ID: {tag_id}")
    result = await Tags.delete_tag(client, tag_id)
    if result:
        logger.info(f"Tag {tag_id} removed successfully")
        return True
    logger.error(f"Failed to remove tag {tag_id}")
    return False


async def test_list_tags(client: AttackIQClient):
    """Test listing tags."""
    await list_tags(client, limit=5)


async def test_tag_lifecycle(client: AttackIQClient):
    """Test creating and removing a tag."""
    new_tag_id = await add_custom_tag(client, _unique_name(_TEST_TAG_PREFIX))
    if new_tag_id:
        await remove_tag(client, new_tag_id)


async def test_search_tag_sets(client: AttackIQClient):
    """Search tag sets and assert the response shape."""
    response = await TagSets.search_tag_sets(client, limit=5)
    assert isinstance(response, dict), f"Expected dict, got {type(response)}"
    assert "count" in response, "search_tag_sets must return 'count'"
    assert "results" in response, "search_tag_sets must return 'results'"
    logger.info(f"search_tag_sets returned count={response['count']}, results={len(response['results'])}")


async def test_tagset_lifecycle(client: AttackIQClient):
    """Create -> search -> delete a tag set."""
    name = _unique_name(_TEST_TAGSET_PREFIX)
    created = await TagSets.create_tag_set(client, name)
    assert created and created.get("id"), f"Failed to create tag set '{name}'"
    tag_set_id = created["id"]
    logger.info(f"Created tag set '{name}' with ID {tag_set_id}")

    found = await TagSets.search_tag_sets(client, query=name, limit=5)
    matches = [ts for ts in found["results"] if ts.get("name") == name]
    assert matches, f"Created tag set '{name}' was not returned by search"

    deleted = await TagSets.delete_tag_set(client, tag_set_id)
    assert deleted, f"Failed to delete tag set '{name}'"
    logger.info(f"Deleted tag set '{name}'")


async def test_idempotent_create_tag(client: AttackIQClient):
    """get_or_create_custom_tag returns created=True the first time, False the second."""
    name = _unique_name(_TEST_TAG_PREFIX)
    first = await Tags.get_or_create_custom_tag(client, name)
    assert first["created"] is True, "First call must report created=True"
    assert first["tag"].get("id"), "First call must return a tag record with id"

    second = await Tags.get_or_create_custom_tag(client, name)
    assert second["created"] is False, "Second call must report created=False"
    assert second["tag"]["id"] == first["tag"]["id"], "Second call must return the same tag id"

    await Tags.delete_tag(client, first["tag"]["id"])


async def test_apply_tag_to_asset(client: AttackIQClient):
    """Find an asset by listing, ensure a tag exists, apply it via bulk-create, then clean up."""
    asset_id: Optional[str] = None
    async for asset in Assets.get_assets(client, limit=1):
        asset_id = asset.get("id")
        break
    if not asset_id:
        logger.warning("No assets available; skipping APPLY_TAG_TO_ASSET")
        return

    tag_name = _unique_name(_TEST_TAG_PREFIX)
    tag_result = await Tags.get_or_create_custom_tag(client, tag_name)
    tag_id = tag_result["tag"]["id"]

    apply_items = [{"tag": tag_id, "content_type": "asset", "object_id": asset_id}]
    apply_response = await TaggedItems.bulk_create_tagged_items(client, items=apply_items)
    assert "success" in apply_response, "bulk_create_tagged_items must return 'success'"
    assert "errors" in apply_response, "bulk_create_tagged_items must return 'errors'"
    apply_successes = apply_response.get("success", [])
    apply_errors = apply_response.get("errors", [])
    assert apply_errors == [], f"Expected no errors on bulk apply, got {len(apply_errors)}: {apply_errors}"
    assert len(apply_successes) == len(
        apply_items
    ), f"Expected {len(apply_items)} success(es) on bulk apply, got {len(apply_successes)}"

    delete_tuples = [{"tag": tag_id, "object_id": asset_id, "content_type": "asset"}]
    delete_response = await TaggedItems.bulk_delete_tagged_items(client, tuples=delete_tuples)
    assert "success" in delete_response
    assert "errors" in delete_response
    delete_successes = delete_response.get("success", [])
    delete_errors = delete_response.get("errors", [])
    assert delete_errors == [], f"Expected no errors on bulk delete, got {len(delete_errors)}: {delete_errors}"
    assert len(delete_successes) == len(
        delete_tuples
    ), f"Expected {len(delete_tuples)} success(es) on bulk delete, got {len(delete_successes)}"

    await Tags.delete_tag(client, tag_id)


async def test_list_tags_on_object(client: AttackIQClient):
    """List tagged items filtered by object_id and content_type."""
    asset_id: Optional[str] = None
    async for asset in Assets.get_assets(client, limit=1):
        asset_id = asset.get("id")
        break
    if not asset_id:
        logger.warning("No assets available; skipping LIST_TAGS_ON_OBJECT")
        return

    response = await TaggedItems.search_tagged_items(client, content_type="asset", object_id=asset_id, limit=20)
    assert "count" in response
    assert "results" in response
    logger.info(f"Tagged items on asset {asset_id}: count={response['count']}")


async def test_find_objects_by_tag(client: AttackIQClient):
    """Create a tag, apply it, find tagged objects by tag_id, then clean up."""
    asset_id: Optional[str] = None
    async for asset in Assets.get_assets(client, limit=1):
        asset_id = asset.get("id")
        break
    if not asset_id:
        logger.warning("No assets available; skipping FIND_OBJECTS_BY_TAG")
        return

    tag_name = _unique_name(_TEST_TAG_PREFIX)
    tag_result = await Tags.get_or_create_custom_tag(client, tag_name)
    tag_id = tag_result["tag"]["id"]

    try:
        await TaggedItems.bulk_create_tagged_items(
            client, items=[{"tag": tag_id, "content_type": "asset", "object_id": asset_id}]
        )
        response = await TaggedItems.search_tagged_items(client, tag_id=tag_id, limit=20)
        assert "count" in response
        assert response["count"] >= 1, "Expected at least one tagged item after apply"
    finally:
        await TaggedItems.bulk_delete_tagged_items(
            client, tuples=[{"tag": tag_id, "object_id": asset_id, "content_type": "asset"}]
        )
        await Tags.delete_tag(client, tag_id)


async def test_bulk_apply(client: AttackIQClient):
    """Bulk apply the same tag to N assets (up to 3 in this test)."""
    asset_ids = []
    async for asset in Assets.get_assets(client, limit=3):
        if asset.get("id"):
            asset_ids.append(asset["id"])
    if not asset_ids:
        logger.warning("No assets available; skipping BULK_APPLY")
        return

    tag_name = _unique_name(_TEST_TAG_PREFIX)
    tag_id = (await Tags.get_or_create_custom_tag(client, tag_name))["tag"]["id"]

    try:
        items = [{"tag": tag_id, "content_type": "asset", "object_id": aid} for aid in asset_ids]
        response = await TaggedItems.bulk_create_tagged_items(client, items=items)
        assert "success" in response
        assert "errors" in response
        successes = response.get("success", [])
        errors_out = response.get("errors", [])
        logger.info(f"BULK_APPLY: success={len(successes)}, errors={len(errors_out)}")
        assert errors_out == [], f"Expected no errors, got {len(errors_out)}: {errors_out}"
        assert len(successes) == len(items), f"Expected {len(items)} successes (one per input), got {len(successes)}"
    finally:
        tuples = [{"tag": tag_id, "object_id": aid, "content_type": "asset"} for aid in asset_ids]
        await TaggedItems.bulk_delete_tagged_items(client, tuples=tuples)
        await Tags.delete_tag(client, tag_id)


async def test_bulk_remove(client: AttackIQClient):
    """Bulk remove tagged items via tuple input."""
    asset_ids = []
    async for asset in Assets.get_assets(client, limit=2):
        if asset.get("id"):
            asset_ids.append(asset["id"])
    if not asset_ids:
        logger.warning("No assets available; skipping BULK_REMOVE")
        return

    tag_name = _unique_name(_TEST_TAG_PREFIX)
    tag_id = (await Tags.get_or_create_custom_tag(client, tag_name))["tag"]["id"]

    try:
        items = [{"tag": tag_id, "content_type": "asset", "object_id": aid} for aid in asset_ids]
        await TaggedItems.bulk_create_tagged_items(client, items=items)

        tuples = [{"tag": tag_id, "object_id": aid, "content_type": "asset"} for aid in asset_ids]
        response = await TaggedItems.bulk_delete_tagged_items(client, tuples=tuples)
        assert "success" in response
        assert "errors" in response
        successes = response.get("success", [])
        errors_out = response.get("errors", [])
        logger.info(f"BULK_REMOVE: success={len(successes)}, errors={len(errors_out)}")
        assert errors_out == [], f"Expected no errors, got {len(errors_out)}: {errors_out}"
        assert len(successes) == len(tuples), f"Expected {len(tuples)} successes (one per input), got {len(successes)}"
    finally:
        await Tags.delete_tag(client, tag_id)


async def test_search_tags_by_tagset_name(client: AttackIQClient):
    """search_tags(tag_set='Custom') resolves the tag set by name."""
    response = await Tags.search_tags(client, tag_set="Custom", limit=5)
    assert "count" in response
    assert "results" in response
    logger.info(f"Tags in Custom tag set: count={response['count']}")


async def test_count_validation(client: AttackIQClient):
    """All search_* methods must return a dict with 'count' and 'results'."""
    tag_set_response = await TagSets.search_tag_sets(client, limit=5)
    assert isinstance(tag_set_response, dict) and "count" in tag_set_response and "results" in tag_set_response

    tag_response = await Tags.search_tags(client, limit=5)
    assert isinstance(tag_response, dict) and "count" in tag_response and "results" in tag_response

    tagged_response = await TaggedItems.search_tagged_items(client, limit=5)
    assert isinstance(tagged_response, dict) and "count" in tagged_response and "results" in tagged_response
    logger.info("COUNT_VALIDATION passed for search_tag_sets, search_tags, search_tagged_items")


async def test_optional_query(client: AttackIQClient):
    """search_* must accept query=None and return all rows (subject to pagination)."""
    tag_sets = await TagSets.search_tag_sets(client, query=None, limit=5)
    assert tag_sets["count"] >= 0
    tags = await Tags.search_tags(client, query=None, limit=5)
    assert tags["count"] >= 0
    tagged_items = await TaggedItems.search_tagged_items(client, query=None, limit=5)
    assert tagged_items["count"] >= 0
    logger.info("OPTIONAL_QUERY passed: query=None returns paginated rows for all search methods")


async def test_all(client: AttackIQClient):
    """Run all tag tests."""
    for choice in TestChoice:
        if choice != TestChoice.ALL:
            await run_test(choice, client)


async def run_test(choice: "TestChoice", client: AttackIQClient):
    """Run the selected test."""
    test_functions = {
        TestChoice.LIST_TAGS: lambda: test_list_tags(client),
        TestChoice.TAG_LIFECYCLE: lambda: test_tag_lifecycle(client),
        TestChoice.SEARCH_TAG_SETS: lambda: test_search_tag_sets(client),
        TestChoice.TAGSET_LIFECYCLE: lambda: test_tagset_lifecycle(client),
        TestChoice.IDEMPOTENT_CREATE_TAG: lambda: test_idempotent_create_tag(client),
        TestChoice.APPLY_TAG_TO_ASSET: lambda: test_apply_tag_to_asset(client),
        TestChoice.LIST_TAGS_ON_OBJECT: lambda: test_list_tags_on_object(client),
        TestChoice.FIND_OBJECTS_BY_TAG: lambda: test_find_objects_by_tag(client),
        TestChoice.BULK_APPLY: lambda: test_bulk_apply(client),
        TestChoice.BULK_REMOVE: lambda: test_bulk_remove(client),
        TestChoice.SEARCH_TAGS_BY_TAGSET_NAME: lambda: test_search_tags_by_tagset_name(client),
        TestChoice.COUNT_VALIDATION: lambda: test_count_validation(client),
        TestChoice.OPTIONAL_QUERY: lambda: test_optional_query(client),
        TestChoice.ALL: lambda: test_all(client),
    }

    await test_functions[choice]()


class TestChoice(Enum):
    LIST_TAGS = "list_tags"
    TAG_LIFECYCLE = "tag_lifecycle"
    SEARCH_TAG_SETS = "search_tag_sets"
    TAGSET_LIFECYCLE = "tagset_lifecycle"
    IDEMPOTENT_CREATE_TAG = "idempotent_create_tag"
    APPLY_TAG_TO_ASSET = "apply_tag_to_asset"
    LIST_TAGS_ON_OBJECT = "list_tags_on_object"
    FIND_OBJECTS_BY_TAG = "find_objects_by_tag"
    BULK_APPLY = "bulk_apply"
    BULK_REMOVE = "bulk_remove"
    SEARCH_TAGS_BY_TAGSET_NAME = "search_tags_by_tagset_name"
    COUNT_VALIDATION = "count_validation"
    OPTIONAL_QUERY = "optional_query"
    ALL = "all"


async def main():
    require_env(ATTACKIQ_PLATFORM_URL, ATTACKIQ_PLATFORM_API_TOKEN)
    choice = parse_test_choice(TestChoice)

    async with AttackIQClient(ATTACKIQ_PLATFORM_URL, ATTACKIQ_PLATFORM_API_TOKEN) as client:
        await run_test(choice, client)


if __name__ == "__main__":
    asyncio.run(main())
