"""Test utilities for use case modules."""

import sys
from enum import Enum
from pathlib import Path
from typing import Type, TypeVar

from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)

T = TypeVar("T", bound=Enum)


_ENV_PLACEHOLDERS = ("REPLACE_WITH_YOUR_PLATFORM_URL", "REPLACE_WITH_YOUR_API_TOKEN")


def require_env(platform_url: str, api_token: str) -> None:
    """Validate required environment variables are set. Exits if missing.

    Rejects the placeholder defaults from ``env.py`` (``REPLACE_WITH_YOUR_…``)
    so use cases fail fast with a clear message instead of crashing inside the
    HTTP layer with ``UnsupportedProtocol``.
    """
    if not platform_url or not api_token or platform_url in _ENV_PLACEHOLDERS or api_token in _ENV_PLACEHOLDERS:
        logger.error(
            "ATTACKIQ_PLATFORM_URL and ATTACKIQ_PLATFORM_API_TOKEN must be set "
            "in the environment (or .env). Current values look unset/placeholder."
        )
        sys.exit(1)


def parse_test_choice(enum_class: Type[T]) -> T:
    """Parse command-line argument as enum value. Exits if invalid."""
    script_name = Path(sys.argv[0]).name
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        try:
            return enum_class(arg.lower())
        except ValueError:
            logger.error(f"Invalid test choice: '{arg}'")
            logger.error(f"Valid choices: {[c.value for c in enum_class]}")
            sys.exit(1)
    else:
        logger.error(f"Usage: python {script_name} <test_choice>")
        logger.error(f"Valid choices: {[c.value for c in enum_class]}")
        sys.exit(1)
