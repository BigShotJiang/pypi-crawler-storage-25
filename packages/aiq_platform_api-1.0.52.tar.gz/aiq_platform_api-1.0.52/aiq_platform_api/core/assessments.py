import asyncio
import copy
import re
import time
from typing import Optional, Dict, Any, List, AsyncGenerator, Tuple

import httpx

from aiq_platform_api.core.async_utils import async_islice
from aiq_platform_api.core.client import AttackIQClient
from aiq_platform_api.core.constants import AssessmentExecutionStrategy
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)

REDACTED_TOKEN_PREFIX = "AIQ_REDACTED_"
DEFAULT_ZIP_PASSWORD = "infected"


class Assessments:
    ASSESSMENT_ENDPOINT = "v1/assessments"
    PUBLIC_ENDPOINT = "v1/public/assessment"
    RESULTS_V1_ENDPOINT = "v1/results"
    RESULTS_V2_ENDPOINT = "v2/results"
    RUN_ASSESSMENT_V1_ENDPOINT = "v1/assessments/{}/run_all"
    RUN_ASSESSMENT_V2_ENDPOINT = "v2/assessments/{}/run_all"
    ASSESSMENT_V2_ENDPOINT = "v2/assessments"

    @staticmethod
    async def get_assessments(
        client: AttackIQClient,
        params: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = 10,
        offset: Optional[int] = 0,
        ordering: Optional[str] = "-modified",
    ) -> AsyncGenerator[Dict[str, Any], None]:
        request_params = params.copy() if params else {}
        if ordering:
            request_params["ordering"] = ordering
        logger.info(f"Listing assessments with params: {request_params}, limit: {limit}, offset: {offset}")
        generator = client.get_all_objects(Assessments.ASSESSMENT_ENDPOINT, params=request_params)
        stop = None if limit is None else offset + limit
        async for assessment in async_islice(generator, offset, stop):
            yield assessment

    @staticmethod
    async def _fetch_atomic_tests(
        client: AttackIQClient,
        assessment_id: str,
        scenarios_limit: Optional[int] = None,
    ) -> Tuple[List[Dict[str, Any]], int, bool]:
        tests = [test async for test in client.get_all_objects("v1/tests", {"project_id": assessment_id})]

        scenarios_fetched = 0
        limit_reached = False

        for test in tests:
            if limit_reached:
                # Don't fetch more tests once limit is reached
                test["scenarios"] = []
                test["assets"] = []
                continue

            test_id = test["id"]

            # Fetch scenarios with optional limit
            scenarios = []
            async for scenario in client.get_all_objects("v1/test_scenarios", {"scenario_master_job": test_id}):
                # Check limit BEFORE appending so limit=0 fetches nothing
                if scenarios_limit is not None and scenarios_fetched >= scenarios_limit:
                    limit_reached = True
                    break  # Stop fetching scenarios
                scenarios.append(scenario)
                scenarios_fetched += 1
            test["scenarios"] = scenarios

            # Only fetch assets if we fetched scenarios for this test
            if scenarios:
                test["assets"] = [
                    asset async for asset in client.get_all_objects("v1/test_assets", {"scenario_master_job": test_id})
                ]
            else:
                test["assets"] = []

        return tests, scenarios_fetched, limit_reached

    @staticmethod
    def _compute_atomic_analysis(tests: List[Dict], version: int, boundaries: List) -> Dict[str, Any]:
        total_scenarios = sum(len(t.get("scenarios", [])) for t in tests)
        total_assets = sum(len(t.get("assets", [])) for t in tests)
        has_multi_asset = any(
            s.get("scenario", {}).get("is_multi_asset") for t in tests for s in t.get("scenarios", [])
        )
        is_network = bool(boundaries) and has_multi_asset

        if is_network:
            assessment_type = f"v{version} Atomic Network"
            estimated_jobs = total_scenarios * len(boundaries)
        else:
            assessment_type = f"v{version} Atomic Endpoint"
            estimated_jobs = sum(len(t.get("scenarios", [])) * max(len(t.get("assets", [])), 1) for t in tests)

        return {
            "assessment_type": assessment_type,
            "is_attack_graph": False,
            "is_network": is_network,
            "has_multi_asset_scenarios": has_multi_asset,
            "total_scenarios": total_scenarios,
            "total_assets": total_assets,
            "total_boundaries": len(boundaries) if is_network else 0,
            "estimated_jobs": estimated_jobs,
        }

    @staticmethod
    async def _fetch_attack_graph(
        client: AttackIQClient,
        assessment_id: str,
        nodes_limit: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        extra_url = client._build_url("v1/assessments/details", {"project_ids": assessment_id})
        extra = await client._make_request(extra_url, method="get", json=None)
        attack_graph_id = extra.get("results", {}).get(assessment_id, {}).get("attack_graph_id") if extra else None
        if not attack_graph_id:
            return None

        graph = await client.get_object(f"v1/attack_graphs/{attack_graph_id}")
        if not graph or nodes_limit is None:
            return graph

        # Apply nodes limit to the graph
        graph_data = graph.get("graph", {})
        nodes = graph_data.get("graph", {})
        total_nodes = len(nodes)

        if total_nodes > nodes_limit:
            # Keep only first N nodes (by key order)
            limited_keys = list(nodes.keys())[:nodes_limit]
            limited_nodes = {k: nodes[k] for k in limited_keys}
            graph["graph"]["graph"] = limited_nodes
            graph["_truncated"] = True
            graph["_truncation_info"] = {
                "type": "nodes",
                "fetched": nodes_limit,
                "total": total_nodes,
                "limit": nodes_limit,
            }

        return graph

    @staticmethod
    def _compute_attack_graph_analysis(graph: Dict[str, Any]) -> Dict[str, Any]:
        graph_data = graph.get("graph", {})
        nodes = graph_data.get("graph", {})
        stages = graph_data.get("graph_meta", {}).get("stages", {})
        has_multi_asset = any(n.get("is_multi_asset") for n in nodes.values())
        graph_type = "MTAG" if has_multi_asset else "STAG"

        return {
            "assessment_type": f"Attack Graph {graph_type}",
            "is_attack_graph": True,
            "graph_type": graph_type,
            "total_nodes": len(nodes),
            "total_stages": len(stages),
            "has_multi_asset_nodes": has_multi_asset,
            "estimated_jobs": len(nodes),
        }

    @staticmethod
    async def get_assessment_by_id(
        client: AttackIQClient,
        assessment_id: str,
        include_tests: bool = False,
        scenarios_limit: Optional[int] = None,
    ) -> Optional[Dict[str, Any]]:
        endpoint = f"{Assessments.ASSESSMENT_ENDPOINT}/{assessment_id}"
        logger.info(f"Fetching assessment details for ID: {assessment_id}")
        details = await client.get_object(endpoint)

        if not include_tests or details is None:
            return details

        version = details.get("version", 1)
        boundaries = details.get("boundaries", [])

        if details.get("master_job_count", 0) > 0:
            tests, scenarios_fetched, was_truncated = await Assessments._fetch_atomic_tests(
                client, assessment_id, scenarios_limit=scenarios_limit
            )
            details["tests"] = tests
            details["_analysis"] = Assessments._compute_atomic_analysis(tests, version, boundaries)
            # Add truncation metadata
            if was_truncated:
                details["_truncated"] = True
                details["_truncation_info"] = {
                    "type": "scenarios",
                    "fetched": scenarios_fetched,
                    "limit": scenarios_limit,
                    # Note: actual total unknown since we stopped fetching early
                }
        else:
            graph = await Assessments._fetch_attack_graph(client, assessment_id, nodes_limit=scenarios_limit)
            if graph:
                details["attack_graph"] = graph
                analysis = Assessments._compute_attack_graph_analysis(graph)
                details["_analysis"] = analysis
                # Add truncation metadata for attack graphs
                # Note: _analysis describes the truncated data, _truncation_info has full totals
                if graph.get("_truncated"):
                    details["_truncated"] = True
                    details["_truncation_info"] = graph.get("_truncation_info", {})

        return details

    @staticmethod
    async def search_assessments(
        client: AttackIQClient,
        query: Optional[str] = None,
        version: Optional[int] = None,
        created_after: Optional[str] = None,
        modified_after: Optional[str] = None,
        execution_strategy: Optional[int] = None,
        user_id: Optional[str] = None,
        is_attack_graph: Optional[bool] = None,
        project_template_id: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-modified",
    ) -> Dict[str, Any]:
        logger.info(f"Searching assessments: query='{query}', version={version}, limit={limit}, offset={offset}")
        params: Dict[str, Any] = {"page_size": limit, "offset": offset}
        if query:
            params["search"] = query
        if version is not None:
            params["version"] = version
        if created_after:
            params["created_after"] = created_after
        if modified_after:
            params["modified_after"] = modified_after
        if execution_strategy is not None:
            params["execution_strategy"] = execution_strategy
        if user_id:
            params["user_id"] = user_id
        if is_attack_graph is not None:
            params["is_attack_graph"] = str(is_attack_graph).lower()
        if project_template_id:
            params["project_template_id"] = project_template_id
        if ordering:
            params["ordering"] = ordering

        url = client._build_url(Assessments.ASSESSMENT_ENDPOINT, params)
        data = await client._make_request(url, method="get", json=None)
        total_count = data.get("count", 0)
        results = data.get("results", [])
        logger.info(f"Found {total_count} total assessments, returning {len(results)}")
        return {"count": total_count, "results": results}

    @staticmethod
    async def list_assessment_runs(
        client: AttackIQClient,
        assessment_id: str,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-created",
    ) -> Dict[str, Any]:
        logger.info(f"Listing runs for assessment {assessment_id}: limit={limit}, offset={offset}")
        endpoint = f"{Assessments.PUBLIC_ENDPOINT}/{assessment_id}/runs"

        # Older backend versions ignore the ordering param and return -modified
        # (model default). Pass ordering to the API for newer backends, but always
        # sort client-side as a safety net regardless of backend version.
        params: Dict[str, Any] = {}
        if ordering:
            params["ordering"] = ordering
        generator = client.get_all_objects(endpoint, params=params)
        all_runs = [run async for run in generator]

        if ordering:
            descending = ordering.startswith("-")
            field = ordering.lstrip("-")

            def run_order_value(run: Dict[str, Any]) -> str:
                value = run.get(field, "")
                if field == "created" and not value:
                    return run.get("created_at", "")
                return value

            all_runs.sort(key=run_order_value, reverse=descending)

        total_count = len(all_runs)
        results = all_runs[offset : offset + limit]
        logger.info(f"Found {len(results)} runs (total: {total_count}) for assessment {assessment_id}")
        return {"count": total_count, "results": results}

    @staticmethod
    async def search_assessment_runs(
        client: AttackIQClient,
        assessment_id: str,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-created",
    ) -> Dict[str, Any]:
        return await Assessments.list_assessment_runs(client, assessment_id, limit, offset, ordering)

    @staticmethod
    async def get_run(client: AttackIQClient, assessment_id: str, run_id: str) -> Optional[Dict[str, Any]]:
        endpoint = "v1/widgets/assessment_runs"
        params = {"project_id": assessment_id, "run_id": run_id}
        logger.debug(f"Getting run {run_id} for assessment {assessment_id}")

        try:
            results = await client.get_object(endpoint, params=params)
            if results and isinstance(results, dict):
                runs = results["results"]
                if runs:
                    return runs[0]
        except httpx.HTTPStatusError as e:
            if e.response is not None and e.response.status_code == 400:
                if "run does not exist" in e.response.text:
                    return None
            raise

        return None

    @staticmethod
    async def get_most_recent_run_status(
        client: AttackIQClient, assessment_id: str, without_detection: bool = True
    ) -> Optional[Dict[str, Any]]:
        logger.info(f"Getting most recent run status for assessment {assessment_id}")

        result = await Assessments.list_assessment_runs(client, assessment_id, limit=1)
        runs = result.get("results", [])
        if runs:
            run = runs[0]
            run_id = run.get("id")
            logger.info(f"Found most recent run: {run_id}")

            status = await Assessments.get_run_status(client, assessment_id, run_id, without_detection)
            if status:
                run.update(status)

            return run

        logger.warning(f"No runs found for assessment {assessment_id}")
        return None

    @staticmethod
    async def get_run_status(
        client: AttackIQClient,
        assessment_id: str,
        run_id: str,
        without_detection: bool = True,
    ) -> Optional[Dict[str, Any]]:
        logger.info(
            f"Checking status for run {run_id} of assessment {assessment_id} without detection: {without_detection}"
        )

        run = await Assessments.get_run(client, assessment_id, run_id)
        if not run:
            logger.warning(f"Run ID {run_id} not found for assessment {assessment_id}")
            return None

        scenario_jobs = run.get("scenario_jobs_in_progress", 0)
        integration_jobs = run.get("integration_jobs_in_progress", 0)

        scenario_jobs = 0 if scenario_jobs is False else scenario_jobs
        integration_jobs = 0 if integration_jobs is False else integration_jobs

        completed = scenario_jobs == 0 if without_detection else (scenario_jobs == 0 and integration_jobs == 0)

        return {
            "scenario_jobs_in_progress": scenario_jobs,
            "integration_jobs_in_progress": integration_jobs,
            "completed": completed,
            "total_count": run.get("total_count", 0),
            "done_count": run.get("done_count", 0),
            "sent_count": run.get("sent_count", 0),
            "pending_count": run.get("pending_count", 0),
            "cancelled_count": run.get("cancelled_count", 0),
        }

    @staticmethod
    async def is_run_complete(
        client: AttackIQClient,
        assessment_id: str,
        run_id: str,
        without_detection: bool = True,
    ) -> bool:
        status = await Assessments.get_run_status(client, assessment_id, run_id, without_detection)
        return status.get("completed", False) if status else False

    @staticmethod
    def _normalize_assessment_version(assessment_version: Any) -> int:
        """Normalize version inputs from API payloads/CLI args to a supported int."""
        if isinstance(assessment_version, float) and not assessment_version.is_integer():
            raise ValueError(f"Invalid assessment version: {assessment_version!r}. Expected 1 or 2.")

        try:
            version = int(assessment_version)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid assessment version: {assessment_version!r}. Expected 1 or 2.") from exc

        if version not in (1, 2):
            raise ValueError(f"Unsupported assessment version: {version}. Expected 1 or 2.")

        return version

    _TASK_ID_PATTERN = re.compile(r"task_id\s+([0-9a-fA-F-]{36})")

    _RUN_ERROR_PATTERNS = [
        ("already queued", "already_queued", "ALREADY_QUEUED"),
        ("no active assets", "not_runnable", "NO_ACTIVE_ASSETS"),
        ("stop_all_scenarios_enabled", "not_runnable", "STOP_ALL_SCENARIOS_ENABLED"),
        ("no runnable tests", "not_runnable", "NO_RUNNABLE_TESTS"),
        ("no active hosted agents", "not_runnable", "NO_HOSTED_AGENTS"),
        ("does not exist", "not_runnable", "COMPANY_NOT_FOUND"),
    ]

    @staticmethod
    async def run_assessment(client: AttackIQClient, assessment_id: str, assessment_version: int) -> dict:
        """Run an assessment. Returns structured dict with status.

        Returns:
            {"status": "started", "run_id": "...", "assessment_id": "...", "version": N}
            {"status": "already_queued", "detail": "...", "task_id": "..." or absent}
            {"status": "not_runnable", "detail": "...", "reason_code": "..."}
            {"status": "error", "detail": "...", "http_status": N}

        Raises:
            ValueError: Invalid version
            httpx.RequestError: Network failure
            httpx.HTTPStatusError: 401/403/5xx (true failures)
        """
        version = Assessments._normalize_assessment_version(assessment_version)
        endpoint = (
            Assessments.RUN_ASSESSMENT_V2_ENDPOINT if version == 2 else Assessments.RUN_ASSESSMENT_V1_ENDPOINT
        ).format(assessment_id)

        try:
            run_result = await client.post_object(endpoint, data={})
        except httpx.HTTPStatusError as exc:
            return Assessments._classify_run_error(assessment_id, version, exc)

        run_id = run_result.get("run_id") if run_result else None
        if not run_id:
            return {
                "assessment_id": assessment_id,
                "version": version,
                "status": "error",
                "detail": "No run_id in response",
            }

        logger.info(f"Assessment {assessment_id} (v{version}) started with run ID: {run_id}")
        return {
            "assessment_id": assessment_id,
            "version": version,
            "status": "started",
            "run_id": run_id,
        }

    @staticmethod
    def _classify_run_error(assessment_id: str, version: int, exc: httpx.HTTPStatusError) -> dict:
        """Classify a run_all HTTP error into a structured result.

        400/409 with known patterns -> structured dict (expected business state).
        401/403/5xx -> re-raise (true failure, fail fast).
        """
        status_code = exc.response.status_code if exc.response is not None else 0

        # True failures: re-raise
        if status_code in (401, 403, 404) or status_code >= 500:
            raise exc

        detail = Assessments._extract_error_detail(exc)
        detail_lower = detail.lower()

        for pattern, status, reason_code in Assessments._RUN_ERROR_PATTERNS:
            if pattern in detail_lower:
                result = {
                    "assessment_id": assessment_id,
                    "version": version,
                    "status": status,
                    "detail": detail,
                    "reason_code": reason_code,
                }
                # Extract task_id for already_queued
                if status == "already_queued":
                    match = Assessments._TASK_ID_PATTERN.search(detail)
                    if match:
                        result["task_id"] = match.group(1)
                return result

        # Unknown 400-level error
        return {
            "assessment_id": assessment_id,
            "version": version,
            "status": "error",
            "detail": detail,
            "http_status": status_code,
        }

    @staticmethod
    def _extract_error_detail(exc: httpx.HTTPStatusError) -> str:
        if exc.response is None:
            return ""
        try:
            payload = exc.response.json()
            detail = payload.get("detail")
            if isinstance(detail, str) and detail:
                return detail
        except Exception:
            pass
        return exc.response.text.strip() if exc.response.text else ""

    @staticmethod
    async def get_results_by_run_id(
        client: AttackIQClient,
        run_id: str,
        assessment_version: int,
        limit: Optional[int] = 10,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        version = Assessments._normalize_assessment_version(assessment_version)
        endpoint = Assessments.RESULTS_V2_ENDPOINT if version == 2 else Assessments.RESULTS_V1_ENDPOINT
        params = {"run_id": run_id, "assessment_results": "true"}
        logger.info(f"Fetching results for run ID: {run_id} from {endpoint}")

        generator = client.get_all_objects(endpoint, params=params)
        async for result in async_islice(generator, 0, limit):
            yield result

    @staticmethod
    async def get_result_details(
        client: AttackIQClient, result_id: str, assessment_version: int
    ) -> Optional[Dict[str, Any]]:
        version = Assessments._normalize_assessment_version(assessment_version)
        base_endpoint = Assessments.RESULTS_V2_ENDPOINT if version == 2 else Assessments.RESULTS_V1_ENDPOINT
        endpoint = f"{base_endpoint}/{result_id}"
        logger.info(f"Fetching detailed result for ID: {result_id} from {endpoint}")
        return await client.get_object(endpoint)

    @staticmethod
    async def get_assets_in_assessment(
        client: AttackIQClient,
        assessment_id: str,
        limit: Optional[int] = 10,
        hide_hosted_agents: bool = True,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """List assets assigned to an assessment.

        Args:
            hide_hosted_agents: When True (default), exclude hosted-agent assets
                from the response. This preserves the historical behaviour
                consumers relied on. Pass False to surface every asset attached
                to the assessment (including hosted/pool agents).
        """
        from aiq_platform_api.core.assets import Assets

        params = {"project_id": assessment_id}
        logger.info(f"Listing assets for assessment ID: {assessment_id} (hide_hosted_agents={hide_hosted_agents})")
        generator = Assets.get_assets(client, params=params, hide_hosted_agents=hide_hosted_agents)
        async for asset in async_islice(generator, 0, limit):
            yield asset

    @staticmethod
    async def wait_for_run_completion(
        client: AttackIQClient,
        assessment_id: str,
        run_id: str,
        timeout: int = 600,
        check_interval: int = 10,
        without_detection: bool = True,
    ) -> bool:
        logger.info(
            f"Waiting for run {run_id} of assessment {assessment_id} to complete without detection: {without_detection}"
        )
        start_time = time.time()
        last_status = None

        while time.time() - start_time < timeout:
            run = await Assessments.get_run(client, assessment_id, run_id)
            if not run:
                logger.warning(f"Run {run_id} not found")
                return False

            scenario_jobs = run.get("scenario_jobs_in_progress", 0)
            integration_jobs = run.get("integration_jobs_in_progress", 0)

            total_count = run.get("total_count", 0)
            done_count = run.get("done_count", 0)

            if without_detection:
                is_completed = not scenario_jobs
            else:
                is_completed = not scenario_jobs and not integration_jobs

            if is_completed:
                elapsed_time = round(time.time() - start_time, 2)
                logger.info(f"Run completed in {elapsed_time} seconds")
                return True

            status_msg = f"Progress: {done_count}/{total_count} completed"
            if status_msg != last_status:
                logger.info(f"{status_msg}")
                last_status = status_msg

            await asyncio.sleep(check_interval)

        logger.warning(f"Run did not complete within {timeout} seconds")
        return False

    @staticmethod
    async def get_execution_strategy(client: AttackIQClient, assessment_id: str) -> AssessmentExecutionStrategy:
        endpoint = f"{Assessments.ASSESSMENT_ENDPOINT}/{assessment_id}"
        assessment = await client.get_object(endpoint)
        return AssessmentExecutionStrategy(assessment["execution_strategy"])

    @staticmethod
    async def set_execution_strategy(client: AttackIQClient, assessment_id: str, with_detection: bool) -> bool:
        execution_strategy = (
            AssessmentExecutionStrategy.WITH_DETECTION
            if with_detection
            else AssessmentExecutionStrategy.WITHOUT_DETECTION
        )
        endpoint = f"{Assessments.ASSESSMENT_ENDPOINT}/{assessment_id}"
        result = await client.patch_object(endpoint, {"execution_strategy": execution_strategy.value})
        return result is not None

    # Blank template UUID for atomic assessment creation
    BLANK_TEMPLATE_UUID = "d09d29ba-eed8-4212-bff2-4d1ee11ed80c"
    MAX_SCENARIOS_PER_BATCH = 25

    @staticmethod
    async def validate_scenario_configurations(
        client: AttackIQClient,
        scenario_configs: List[Dict[str, Any]],
        asset_ids: Optional[List[str]] = None,
        asset_tag_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Validate scenario configurations against the platform's get_requirements endpoint.

        Uses /v2/assessments/get_requirements - the authoritative validation that checks:
        1. args.met: Are all required model_json fields provided?
        2. assets[].met: Do provided assets/tags satisfy asset tag requirements?

        Args:
            client: AttackIQ API client
            scenario_configs: List of {id, model_json} for each scenario
            asset_ids: List of asset UUIDs (test points to consider)
            asset_tag_ids: List of tag UUIDs (asset tags to consider)

        Returns:
            {
                "all_runnable": bool,
                "scenarios": [
                    {
                        "id": str,
                        "runnable": bool,
                        "args_met": bool,
                        "assets_met": bool,
                        "missing_args": [str],
                        "unmet_asset_tags": [{tag_id, tag_display_name}],
                    }
                ],
                "scenarios_need_args": [{id, name, missing_args}],
                "scenarios_need_asset_tags": [{id, name, required_tags}],
            }
        """
        from aiq_platform_api.core.scenarios import Scenarios

        if not scenario_configs:
            return {
                "all_runnable": True,
                "scenarios": [],
                "scenarios_need_args": [],
                "scenarios_need_asset_tags": [],
            }

        # Build request for /v2/assessments/get_requirements
        payload = {
            "tests": [
                {
                    "scenarios": [
                        {"id": cfg["id"], "model_json": cfg.get("model_json") or {}} for cfg in scenario_configs
                    ]
                }
            ],
            "assets": asset_ids or [],
            "asset_tags": asset_tag_ids or [],
        }
        scenario_model_json_by_id = {cfg["id"]: (cfg.get("model_json") or {}) for cfg in scenario_configs}

        logger.info(f"Validating {len(scenario_configs)} scenario configurations")
        result = await client.post_object("v2/assessments/get_requirements", data=payload)

        # Parse response
        scenarios_out: List[Dict[str, Any]] = []
        scenarios_need_args: List[Dict[str, Any]] = []
        scenarios_need_asset_tags: List[Dict[str, Any]] = []

        tests = result.get("tests", []) if result else []
        for test in tests:
            for scenario_result in test.get("scenarios", []):
                sid = scenario_result["id"]
                requirements = scenario_result.get("requirements", {})
                args_met = requirements.get("args", {}).get("met", True)
                asset_requirements = requirements.get("assets", [])
                assets_met = all(ar.get("met", True) for ar in asset_requirements)
                runnable = scenario_result.get("runnable", True)

                # Build missing args list by comparing to schema
                missing_args: List[str] = []
                if not args_met:
                    try:
                        schema_info = await Scenarios.get_scenario_configuration_schema(client, sid)
                        required_args = schema_info.get("required_args", [])
                        provided_model_json = scenario_model_json_by_id.get(sid) or {}
                        missing_args = [
                            arg
                            for arg in required_args
                            if arg not in provided_model_json or provided_model_json.get(arg) is None
                        ]
                    except Exception:
                        missing_args = ["(unable to determine - fetch schema for details)"]

                # Build unmet asset tags list
                unmet_asset_tags: List[Dict[str, Any]] = []
                for ar in asset_requirements:
                    if not ar.get("met", True):
                        for tag in ar.get("tags", []):
                            unmet_asset_tags.append(
                                {
                                    "tag_id": tag.get("tag_id"),
                                    "tag_display_name": tag.get("tag_display_name"),
                                }
                            )

                scenarios_out.append(
                    {
                        "id": sid,
                        "runnable": runnable,
                        "args_met": args_met,
                        "assets_met": assets_met,
                        "missing_args": missing_args,
                        "unmet_asset_tags": unmet_asset_tags,
                    }
                )

                # Track scenarios needing args
                if not args_met:
                    scenarios_need_args.append(
                        {
                            "id": sid,
                            "name": "(fetch from scenario)",
                            "missing_args": missing_args,
                        }
                    )

                # Track scenarios needing asset tags
                if not assets_met:
                    scenarios_need_asset_tags.append(
                        {
                            "id": sid,
                            "name": "(fetch from scenario)",
                            "required_tags": unmet_asset_tags,
                        }
                    )

        all_runnable = all(s["runnable"] for s in scenarios_out) if scenarios_out else True

        return {
            "all_runnable": all_runnable,
            "scenarios": scenarios_out,
            "scenarios_need_args": scenarios_need_args,
            "scenarios_need_asset_tags": scenarios_need_asset_tags,
        }

    @staticmethod
    async def check_v2_runnability(
        client: AttackIQClient,
        assessment_id: str,
    ) -> Dict[str, Any]:
        assessment = await Assessments.get_assessment_by_id(
            client, assessment_id, include_tests=True, scenarios_limit=None
        )
        if not assessment:
            raise ValueError(f"Assessment {assessment_id} not found")

        tests = assessment.get("tests", [])
        if not tests:
            # No tests → can't determine runnability, fail open
            return {"runnable": True, "reasons": []}

        # Assessment-level asset tag IDs (assigned via update_defaults, returned as "tags").
        # NOTE: GET /v1/assessments/{id} does NOT include "tags" in its serializer,
        # so this is effectively always [] until the backend adds it.  When absent,
        # we skip MISSING_ASSET_TAGS reporting (fail-open: can't validate without context).
        has_tag_context = "tags" in assessment
        assessment_tag_ids = assessment.get("tags") or []

        all_reasons: List[Dict[str, Any]] = []

        for test in tests:
            test_name = test.get("name", "unknown")
            scenarios = test.get("scenarios", [])
            assets = test.get("assets", [])

            if not scenarios:
                continue

            # Build scenario configs from test data
            scenario_configs = []
            for s in scenarios:
                scenario_data = s.get("scenario", {})
                sid = scenario_data.get("id") or s.get("id")
                if sid:
                    scenario_configs.append(
                        {
                            "id": sid,
                            "model_json": s.get("model_json") or {},
                        }
                    )

            if not scenario_configs:
                continue

            # Extract asset IDs from test assets (per-test scoping)
            asset_ids = [a["asset"]["id"] for a in assets if a.get("asset", {}).get("id")]

            # Validate via get_requirements
            try:
                validation = await Assessments.validate_scenario_configurations(
                    client,
                    scenario_configs=scenario_configs,
                    asset_ids=asset_ids,
                    asset_tag_ids=assessment_tag_ids,
                )
            except Exception as e:
                logger.warning(f"get_requirements failed for test '{test_name}' in assessment {assessment_id}: {e}")
                continue

            for item in validation.get("scenarios_need_args", []):
                missing = ", ".join(item.get("missing_args", []))
                all_reasons.append(
                    {
                        "code": "MISSING_REQUIRED_ARGS",
                        "message": f"Test '{test_name}': scenario {item['id'][:8]}... missing required args: {missing}",
                        "resolution": "Configure the scenario's required arguments in the test setup",
                    }
                )

            if has_tag_context:
                for item in validation.get("scenarios_need_asset_tags", []):
                    tags = ", ".join(
                        t.get("tag_display_name") or t.get("tag_id", "?") for t in item.get("required_tags", [])
                    )
                    all_reasons.append(
                        {
                            "code": "MISSING_ASSET_TAGS",
                            "message": f"Test '{test_name}': scenario {item['id'][:8]}... has unmet asset tag requirements: {tags}",
                            "resolution": "Assign assets with the required tags or add asset tags to the assessment",
                        }
                    )

        return {
            "runnable": len(all_reasons) == 0,
            "reasons": all_reasons,
        }

    @staticmethod
    async def _fetch_and_merge_model_json(
        client: AttackIQClient,
        scenario_ids: List[str],
        scenario_configs: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Dict[str, Any]]:
        """Fetch each scenario's full default model_json and merge user overrides on top.

        Mirrors platform UI behavior: start with complete defaults, overlay user changes.
        Uses asyncio.gather for concurrent fetches (handles up to 25 scenarios).
        """
        from aiq_platform_api.core.scenarios import Scenarios

        async def fetch_one(sid: str) -> Tuple[str, Dict[str, Any]]:
            schema = await Scenarios.get_scenario_configuration_schema(client, sid)
            base = copy.deepcopy(schema.get("current_model_json") or {})
            base.update(scenario_configs.get(sid) or {})
            zip_file_password = base.get("zip_file_password")
            if isinstance(zip_file_password, str) and zip_file_password.startswith(REDACTED_TOKEN_PREFIX):
                base["zip_file_password"] = DEFAULT_ZIP_PASSWORD
            return sid, base

        results = await asyncio.gather(*(fetch_one(sid) for sid in scenario_ids))
        return dict(results)

    @staticmethod
    async def create_atomic_assessment(
        client: AttackIQClient,
        name: str,
        scenario_ids: List[str],
        asset_ids: List[str],
        asset_tag_ids: Optional[List[str]] = None,
        scenario_configurations: Optional[Dict[str, Dict[str, Any]]] = None,
        test_name: str = "Test Container 1",
        use_hosted_agent: bool = False,
    ) -> Dict[str, Any]:
        """Create a v2 atomic assessment with transaction semantics.

        Orchestrates 3-4 API calls (4 when use_hosted_agent=True):
        1. POST /v2/assessments/project_from_template - Create with full model_json
           (defaults fetched from each scenario + user overrides merged on top)
        2. POST /v1/assessments/{id}/update_defaults - Assign test points and asset tags
        3. (if use_hosted_agent=True) PATCH /v1/tests/{test_id} for each test - set
           `use_hosted_agent=True` so the platform skips per-asset OS checks for
           hosted/pool agent assets and runs HA-capable scenarios on them
        4. PATCH /v1/assessments/{id} - Set execution_strategy to prevention-only

        model_json handling: For each scenario, fetches the full default model_json via
        get_scenario_configuration_schema, then merges any user-provided overrides on top.
        This mirrors platform UI behavior where the complete model_json is always sent.

        Detection is disabled by design. Legacy detection validation via API is deprecated.
        Use the platform UI if detection is required. New detection workflow: Atlas project.

        Args:
            client: AttackIQ API client
            name: Assessment name (recommend using [plan_id-batch_id] prefix)
            scenario_ids: List of scenario UUIDs (max 25)
            asset_ids: List of test point (asset) UUIDs - provide at least one per OS.
                When use_hosted_agent=True, pass the hosted/pool agent asset IDs returned
                by `Assets.recommend_test_points` (class="hosted_agent" | "pool_agent").
            asset_tag_ids: List of tag UUIDs for asset tag requirements. Callers should
                NOT pass tags when use_hosted_agent=True — tag-based asset matching is
                bypassed for the hosted-agent execution path.
            scenario_configurations: Dict of {scenario_id: model_json} for user overrides
                (merged on top of scenario defaults)
            test_name: Name for the test container
            use_hosted_agent: When True, enables the hosted-agent execution path on
                every test created. Required for assessments built from hosted/pool
                agent assets. The flag is the master switch — without it, hosted-agent
                assets in the assessment are silently ignored at run time.

        Returns:
            Dict with assessment_id, name, scenario_count, asset_ids, asset_tag_ids,
            use_hosted_agent, version

        Raises:
            ValueError: If scenario_ids exceeds MAX_SCENARIOS_PER_BATCH, is empty, or asset_ids is empty
            RuntimeError: If any API call fails (assessment is cleaned up)
        """
        if not scenario_ids:
            raise ValueError("At least one scenario_id is required")
        if len(scenario_ids) > Assessments.MAX_SCENARIOS_PER_BATCH:
            raise ValueError(
                f"Cannot add more than {Assessments.MAX_SCENARIOS_PER_BATCH} scenarios per batch, got {len(scenario_ids)}"
            )
        if not asset_ids:
            raise ValueError("At least one asset_id is required")

        assessment_id = None
        scenario_configs = scenario_configurations or {}

        try:
            # Fetch each scenario's full default model_json and merge user overrides on top
            # This mirrors platform UI behavior - always send complete model_json
            merged_configs = await Assessments._fetch_and_merge_model_json(client, scenario_ids, scenario_configs)

            # Step 1: Create v2 assessment with tests, scenarios, and FULL model_json
            scenarios_payload = []
            for i, sid in enumerate(scenario_ids, 1):
                scenarios_payload.append(
                    {
                        "id": sid,
                        "order": i,
                        "model_json": merged_configs[sid],
                    }
                )

            logger.info(f"Creating v2 assessment '{name}' with {len(scenario_ids)} scenarios")
            create_result = await client.post_object(
                "v2/assessments/project_from_template",
                data={
                    "template": Assessments.BLANK_TEMPLATE_UUID,
                    "project_name": name,
                    "tests": [
                        {
                            "name": test_name,
                            "order": 1,
                            "scenarios": scenarios_payload,
                        }
                    ],
                },
            )
            # API returns "project_id" not "id"
            assessment_id = create_result.get("project_id") if create_result else None
            if not assessment_id:
                raise RuntimeError(f"Failed to create assessment: {create_result}")
            logger.info(f"Created v2 assessment: {assessment_id}")

            # Step 2: Assign test points (assets) and asset tags
            # NOTE: v1 endpoint works correctly for v2 assessments; v2 endpoint returns
            # success but silently fails to assign assets. Using v1 until platform fixes v2.
            logger.info(f"Assigning {len(asset_ids)} test points to assessment {assessment_id}")
            update_payload = {"assets": asset_ids, "tags": asset_tag_ids or []}
            defaults_result = await client.post_object(
                f"v1/assessments/{assessment_id}/update_defaults",
                data=update_payload,
            )
            if defaults_result is None:
                raise RuntimeError("Failed to assign test points and tags")
            logger.info(f"Assigned test points: {asset_ids}, tags: {asset_tag_ids or []}")

            # Step 3 (HA-only): set use_hosted_agent=True on every test in the
            # assessment. The flag lives on `ScenarioMasterJob`, not on the
            # assessment itself, so each test must be patched individually.
            #
            # Fail closed if anything unexpected happens here. The original
            # MCP RCA was caused by the platform silently ignoring HA-required
            # scenarios at run time when the flag was missing — we must not
            # return a successful create result with `use_hosted_agent=True`
            # unless we have proof the flag is actually set on every test:
            #   - At least one test exists to patch (caller intent honored).
            #   - The PATCH response echoes `use_hosted_agent=True` for each.
            if use_hosted_agent:
                from aiq_platform_api.core.tests import Tests

                test_ids = [
                    test["id"] async for test in client.get_all_objects(Tests.ENDPOINT, {"project_id": assessment_id})
                ]
                if not test_ids:
                    raise RuntimeError(
                        f"use_hosted_agent=True requested but assessment {assessment_id} "
                        f"has no tests to patch — cannot honour caller intent. "
                        f"Refusing to return a 'success' result that would silently "
                        f"execute without the hosted-agent flag at run time."
                    )
                logger.info(f"Enabling use_hosted_agent on {len(test_ids)} test(s) for assessment {assessment_id}")
                for test_id in test_ids:
                    patch_resp = await Tests.patch_use_hosted_agent(client, test_id, True)
                    # PATCH endpoints echo the updated object. If the field did
                    # not persist server-side (as happens with the sibling
                    # use_pool_agent flag), refuse to claim success.
                    if not patch_resp or patch_resp.get("use_hosted_agent") is not True:
                        raise RuntimeError(
                            f"PATCH /v1/tests/{test_id} did not persist use_hosted_agent=True "
                            f"(response: {patch_resp}). The assessment would execute without "
                            f"the hosted-agent flag — refusing to return success."
                        )

            # Step 4: Disable detection (execution_strategy=1 = prevention-only)
            # Legacy detection via API is deprecated. Use platform UI or Atlas project.
            logger.info(f"Disabling detection for assessment {assessment_id}")
            await Assessments.set_execution_strategy(client, assessment_id, with_detection=False)

            return {
                "assessment_id": assessment_id,
                "name": name,
                "scenario_count": len(scenario_ids),
                "asset_ids": asset_ids,
                "asset_tag_ids": asset_tag_ids or [],
                "use_hosted_agent": use_hosted_agent,
                "version": 2,
            }

        except Exception as e:
            # Transaction rollback: delete assessment if created
            if assessment_id:
                logger.warning(f"Rolling back: deleting assessment {assessment_id} due to error: {e}")
                try:
                    await client.delete_object(f"v1/assessments/{assessment_id}")
                    logger.info(f"Rolled back assessment {assessment_id}")
                except Exception as cleanup_error:
                    logger.error(f"Failed to rollback assessment {assessment_id}: {cleanup_error}")
            raise

    @staticmethod
    async def validate_assessment_batch(
        client: AttackIQClient,
        scenario_ids: List[str],
        test_point_ids: List[str],
        scenario_configurations: Optional[Dict[str, Dict[str, Any]]] = None,
        asset_tag_ids: Optional[List[str]] = None,
        use_hosted_agent: bool = False,
    ) -> Dict[str, Any]:
        """Validate a batch before creating an assessment.

        Pre-creation guardrail that checks:
        1. Scenario count ≤ 25
        2. All test points exist and have status: Active
        3. OS compatibility: each scenario has ≥1 compatible test point
           (asset-aware — accounts for hosted-agent execution path when
           use_hosted_agent=True)
        4. Multi-asset scenarios are flagged
        5. All scenario IDs exist (anti-hallucination)
        6. Config completeness: scenarios needing args have them provided (via get_requirements)
        7. Asset tag requirements: scenarios requiring asset tags are satisfied

        The compatibility analysis is asset-aware: hosted-agent capability is a
        SIGNAL, not a requirement. A scenario tagged `Runnable by Hosted Agent`
        with non-empty `supported_platforms` is dual-mode — it runs on a regular
        OS-tagged asset OR (when use_hosted_agent=True) on a hosted/pool agent.
        Errors are keyed on the SELECTED ASSET CLASS, not on the scenario tag
        alone, so existing dual-mode workflows that pass today continue to pass.

        Args:
            client: AttackIQ API client
            scenario_ids: List of scenario UUIDs to validate
            test_point_ids: List of test point (asset) UUIDs - need at least one per OS
            scenario_configurations: Dict of {scenario_id: model_json} user overrides
                (merged on top of scenario defaults before validation)
            asset_tag_ids: List of tag UUIDs for asset tag requirement validation
            use_hosted_agent: When True, signals that the assessment will be created
                with `use_hosted_agent=True` on every test, enabling the hosted-agent
                execution path. Hosted/pool agents in test_point_ids are then valid
                runners for HA-capable scenarios. Default False matches existing
                regular-asset workflows exactly.

        Returns:
            {
                "is_valid": bool,
                "errors": [...],
                "warnings": [...],
                "compatible_scenarios": [...],
                "scenarios_need_args": [{id, name, missing_args}],
                "scenarios_need_asset_tags": [{id, name, required_tags}],
                "scenarios_need_test_point": [{id, name, required_platforms, reason}],
                "multi_asset_scenarios": [{id, name}],
                "not_found_scenarios": [...],
                "test_points": [{id, hostname, status, platforms, class, is_hosted_agent}, ...],
                "hosted_agent_matrix": {
                    "use_hosted_agent": bool,
                    "hosted_agent_assets_present": bool,
                    "regular_assets_present": bool,
                    "scenarios_ha_capable": [sid, ...],
                    "scenarios_regular_capable": [sid, ...],
                    "per_asset": [{id, class, compatible_scenarios}, ...],
                    "issues": [{code, level, asset_ids?, scenario_ids?}, ...],
                },
                "summary": {...}
            }
        """
        from aiq_platform_api.core.assets import (
            Assets,
            get_asset_platforms,
            is_hosted_agent,
            is_pool_agent,
            normalize_platform,
        )
        from aiq_platform_api.core.scenarios import Scenarios

        errors: List[str] = []
        warnings: List[str] = []
        compatible: List[str] = []
        need_args: List[Dict[str, Any]] = []
        need_asset_tags: List[Dict[str, Any]] = []
        need_test_point: List[Dict[str, Any]] = []
        multi_asset: List[Dict[str, Any]] = []
        not_found: List[Dict[str, Any]] = []
        scenario_configs = scenario_configurations or {}

        # Check 1: Scenario count
        if not scenario_ids:
            errors.append("No scenarios provided")
        elif len(scenario_ids) > Assessments.MAX_SCENARIOS_PER_BATCH:
            errors.append(f"Too many scenarios: {len(scenario_ids)} exceeds max {Assessments.MAX_SCENARIOS_PER_BATCH}")

        # Check 2: All test points exist and are Active
        if not test_point_ids:
            errors.append("No test points provided")

        test_points_info: List[Dict[str, Any]] = []
        all_regular_test_point_platforms: set = set()
        # Track which selected assets are HA — drives the matrix-aware checks below
        selected_hosted_asset_ids: List[str] = []
        selected_regular_asset_ids: List[str] = []

        # Pool-agent fallback inventory. The detail endpoint (/v2/assets/{id})
        # returns 404 for cross-tenant pool agents because the resource is owned
        # by ATTACKIQ_POOL_COMPANY_ID, not the caller's company. The list endpoint
        # with show_pool_agents=true is the only place pool agents are visible
        # to a non-pool tenant. Build the lookup lazily — only if a per-id fetch
        # comes back None — so the happy path (own-tenant assets) stays one call
        # per asset.
        _pool_agent_lookup_cache: Optional[Dict[str, Dict[str, Any]]] = None

        async def _resolve_pool_agent(asset_id: str) -> Optional[Dict[str, Any]]:
            nonlocal _pool_agent_lookup_cache
            if _pool_agent_lookup_cache is None:
                _pool_agent_lookup_cache = {}
                # Build the cache by paginating through assets via the
                # generator — `search_assets` would do a single API call
                # with `page_size=limit`, which the platform may cap. The
                # generator pages internally and respects `limit` as a
                # total cap. Budget chosen to comfortably exceed realistic
                # tenant size (Codex's H1 round-3 finding: a tenant with
                # 250+ regulars before any pool agent broke the previous
                # 200-item cap with "test point not found"). The same
                # constant is used by recommend_test_points so the two
                # paths stay consistent.
                from aiq_platform_api.core.assets import HOSTED_AGENT_SCAN_BUDGET

                try:
                    async for a in Assets.get_assets(
                        client,
                        params={},
                        limit=HOSTED_AGENT_SCAN_BUDGET,
                        show_pool_agents=True,
                    ):
                        if a.get("id"):
                            _pool_agent_lookup_cache[a["id"]] = a
                except Exception as e:
                    logger.warning(f"Pool-agent fallback lookup failed: {e}")
                logger.info(
                    f"Pool-agent fallback inventory built: {len(_pool_agent_lookup_cache)} "
                    f"asset(s) cached (budget={HOSTED_AGENT_SCAN_BUDGET})"
                )
            return _pool_agent_lookup_cache.get(asset_id)

        for tp_id in test_point_ids:
            try:
                tp = await Assets.get_asset_by_id(client, tp_id)
                if tp is None:
                    # Detail endpoint 404'd. Fall back to the list endpoint with
                    # show_pool_agents=true — pool agents resolve there even
                    # though they 404 on the detail endpoint.
                    tp = await _resolve_pool_agent(tp_id)
                    if tp is None:
                        errors.append(f"Test point not found: {tp_id}")
                        continue
                if tp.get("status") != "Active":
                    errors.append(f"Test point {tp_id} is not Active (status: {tp.get('status')})")

                tp_platforms = get_asset_platforms(tp)
                if not tp_platforms:
                    # Fallback: infer from product_name
                    product_name = (tp.get("product_name") or "").lower()
                    if "windows" in product_name:
                        tp_platforms.add("windows")
                    elif "linux" in product_name or "ubuntu" in product_name or "centos" in product_name:
                        tp_platforms.add("linux")
                    elif "mac" in product_name or "darwin" in product_name:
                        tp_platforms.add("osx")

                tp_is_hosted = is_hosted_agent(tp)
                if tp_is_hosted:
                    asset_class = "pool_agent" if is_pool_agent(tp) else "hosted_agent"
                    selected_hosted_asset_ids.append(tp_id)
                else:
                    asset_class = "regular"
                    selected_regular_asset_ids.append(tp_id)
                    all_regular_test_point_platforms.update(tp_platforms)

                test_points_info.append(
                    {
                        "id": tp_id,
                        "hostname": tp.get("hostname"),
                        "status": tp.get("status"),
                        "platforms": list(tp_platforms),
                        "class": asset_class,
                        "is_hosted_agent": tp_is_hosted,
                    }
                )
            except Exception as e:
                errors.append(f"Test point not found: {tp_id} ({str(e)})")

        # Check 3, 4, 5: Scenario validation (existence, multi-asset, OS compatibility)
        # Compatibility is asset-aware: a scenario passes when ANY selected asset
        # can run it under the agreed execution model (regular OS match OR
        # hosted-agent path when both the flag and an HA asset are present).
        valid_scenario_ids: List[str] = []
        scenarios_ha_capable_ids: List[str] = []
        scenarios_regular_capable_ids: List[str] = []
        # Per-scenario data for the matrix (id -> {name, supported_platforms, hosted_agent_capable})
        scenario_meta: Dict[str, Dict[str, Any]] = {}

        for sid in scenario_ids:
            try:
                req = await Scenarios.get_scenario_requirements(client, sid)

                # Handle None or empty return (scenario not found - SDK returns {} on 404)
                if not req or not req.get("name"):
                    not_found.append({"id": sid, "error": "Scenario not found"})
                    errors.append(f"Scenario not found: {sid}")
                    continue

                # Check multi-asset
                if req.get("is_multi_asset"):
                    multi_asset.append({"id": sid, "name": req.get("name", "")})
                    warnings.append(f"Multi-asset scenario excluded: {req.get('name', sid)}")
                    continue

                valid_scenario_ids.append(sid)

                scenario_platforms = set(normalize_platform(p) for p in req.get("supported_platforms", []))
                ha_capable = bool(req.get("hosted_agent_capable"))

                # Capability tracking for the matrix
                if ha_capable:
                    scenarios_ha_capable_ids.append(sid)
                # "regular_capable" means there's a non-HA path: universal scenarios
                # (no platform restriction) or any scenario with declared platforms.
                # The latter can run on a matching regular asset.
                scenarios_regular_capable_ids.append(sid)

                scenario_meta[sid] = {
                    "name": req.get("name", ""),
                    "supported_platforms": list(scenario_platforms),
                    "hosted_agent_capable": ha_capable,
                }

                # Per-asset compatibility paths:
                # 1. Regular asset path: scenario.platforms ∩ regular_assets.platforms
                #    OR scenario is universal (no platform restriction)
                # 2. HA path: ha_capable AND use_hosted_agent AND any HA asset selected
                regular_path_ok = not scenario_platforms or (  # universal — runs anywhere including regular
                    bool(selected_regular_asset_ids) and bool(scenario_platforms & all_regular_test_point_platforms)
                )
                ha_path_ok = ha_capable and use_hosted_agent and bool(selected_hosted_asset_ids)

                if regular_path_ok or ha_path_ok:
                    compatible.append(sid)
                elif (
                    not regular_path_ok
                    and not selected_regular_asset_ids
                    and selected_hosted_asset_ids
                    and not all_regular_test_point_platforms
                ):
                    # Edge case: no regular assets at all, only HA assets selected.
                    # If we can't take the HA path (use_hosted_agent=False or scenario
                    # not HA-capable), this is also "no compatible test point" — but
                    # the dominant root cause depends on the flag/tag, surfaced via
                    # the matrix issue codes below.
                    need_test_point.append(
                        {
                            "id": sid,
                            "name": req.get("name", ""),
                            "required_platforms": list(scenario_platforms),
                            "reason": (
                                "No regular test point supports this scenario; "
                                "hosted-agent path unavailable "
                                f"(use_hosted_agent={use_hosted_agent}, ha_capable={ha_capable})"
                            ),
                        }
                    )
                else:
                    # Standard "no test point supports this scenario's platforms"
                    need_test_point.append(
                        {
                            "id": sid,
                            "name": req.get("name", ""),
                            "required_platforms": list(scenario_platforms),
                            "reason": f"No test point supports platforms {list(scenario_platforms)}",
                        }
                    )

            except Exception as e:
                not_found.append({"id": sid, "error": str(e)})
                errors.append(f"Scenario not found: {sid}")

        # Check 6, 7: Config and asset tag validation using get_requirements endpoint
        # Mirror create_atomic_assessment behavior by validating merged defaults+overrides.
        if valid_scenario_ids and test_point_ids:
            # Build scenario configs list for validation (full model_json when available)
            configs_for_validation = []
            for sid in valid_scenario_ids:
                merged_model_json: Dict[str, Any] = {}
                try:
                    schema = await Scenarios.get_scenario_configuration_schema(client, sid)
                    merged_model_json = copy.deepcopy(schema.get("current_model_json") or {})
                except Exception as e:
                    warnings.append(f"Could not fetch defaults for {sid}; validating overrides only ({str(e)})")

                merged_model_json.update(scenario_configs.get(sid) or {})
                configs_for_validation.append({"id": sid, "model_json": merged_model_json})

            try:
                config_validation = await Assessments.validate_scenario_configurations(
                    client,
                    scenario_configs=configs_for_validation,
                    asset_ids=test_point_ids,
                    asset_tag_ids=asset_tag_ids,
                )

                # Extract scenarios needing args or asset tags
                need_args = config_validation.get("scenarios_need_args", [])
                need_asset_tags = config_validation.get("scenarios_need_asset_tags", [])

                # Remove from compatible list if they need configuration
                need_config_ids = {s["id"] for s in need_args + need_asset_tags}
                compatible = [sid for sid in compatible if sid not in need_config_ids]

            except Exception as e:
                warnings.append(f"Could not validate configurations: {str(e)}")
                errors.append("Scenario configuration validation failed; cannot confirm required args or asset tags")
                compatible = [sid for sid in compatible if sid not in valid_scenario_ids]

        # Asset-aware HA matrix — keys execution-path errors on the SELECTED asset
        # class, never on the scenario tag alone. This protects dual-mode flows
        # (HA-tagged scenario + regular OS-tagged asset + use_hosted_agent=False)
        # from being incorrectly rejected.
        hosted_agent_assets_present = bool(selected_hosted_asset_ids)
        regular_assets_present = bool(selected_regular_asset_ids)

        matrix_per_asset: List[Dict[str, Any]] = []
        for tp in test_points_info:
            tp_id = tp["id"]
            tp_class = tp["class"]
            tp_platforms_set = set(tp["platforms"])
            asset_compat: List[str] = []
            for sid, meta in scenario_meta.items():
                splatforms = set(meta["supported_platforms"])
                ha_cap = meta["hosted_agent_capable"]
                if tp_class == "regular":
                    # Regular-path match: scenario universal OR scenario.platforms ∩ asset.platforms
                    if not splatforms or (splatforms & tp_platforms_set):
                        asset_compat.append(sid)
                else:
                    # HA-path match: scenario must carry the capability tag AND the
                    # caller intends to enable use_hosted_agent on the assessment.
                    if ha_cap and use_hosted_agent:
                        asset_compat.append(sid)
            matrix_per_asset.append({"id": tp_id, "class": tp_class, "compatible_scenarios": asset_compat})

        # Issue codes — consumed by the AI service layer to render asset-aware
        # human-readable errors. SDK only emits the structured codes.
        matrix_issues: List[Dict[str, Any]] = []

        # Code: HOSTED_AGENT_FLAG_REQUIRED_FOR_HA_ASSETS
        # Hosted/pool assets are selected but use_hosted_agent=False. They will
        # be silently ignored at run time — fail fast at validation.
        if hosted_agent_assets_present and not use_hosted_agent:
            matrix_issues.append(
                {
                    "code": "HOSTED_AGENT_FLAG_REQUIRED_FOR_HA_ASSETS",
                    "level": "error",
                    "asset_ids": list(selected_hosted_asset_ids),
                }
            )

        # Code: HOSTED_AGENT_HAS_NO_HA_TAG
        # use_hosted_agent=True with HA assets, but some scenarios lack the HA
        # capability tag AND have no regular asset to fall back to. Those
        # scenarios cannot run on the assigned assets.
        if use_hosted_agent and hosted_agent_assets_present and not regular_assets_present:
            no_ha_tag_sids = [
                sid
                for sid in valid_scenario_ids
                if sid in scenario_meta and not scenario_meta[sid]["hosted_agent_capable"]
            ]
            if no_ha_tag_sids:
                matrix_issues.append(
                    {
                        "code": "HOSTED_AGENT_HAS_NO_HA_TAG",
                        "level": "error",
                        "asset_ids": list(selected_hosted_asset_ids),
                        "scenario_ids": no_ha_tag_sids,
                    }
                )

        # Code: HOSTED_AGENT_ASSET_REQUIRED
        # An HA-capable scenario has no regular asset whose OS matches AND no
        # HA execution path is available (either flag is False, or no HA asset
        # was selected). This is a subset of need_test_point — surfaced
        # separately so the consumer can suggest "add a hosted/pool agent".
        ha_asset_required_sids = [
            sid
            for sid in valid_scenario_ids
            if sid in scenario_meta
            and scenario_meta[sid]["hosted_agent_capable"]
            and not (
                # regular-path ok?
                not scenario_meta[sid]["supported_platforms"]
                or (
                    selected_regular_asset_ids
                    and (set(scenario_meta[sid]["supported_platforms"]) & all_regular_test_point_platforms)
                )
            )
            and not (use_hosted_agent and hosted_agent_assets_present)
        ]
        if ha_asset_required_sids:
            matrix_issues.append(
                {
                    "code": "HOSTED_AGENT_ASSET_REQUIRED",
                    "level": "error",
                    "scenario_ids": ha_asset_required_sids,
                }
            )

        # Code: OS_TAG_IGNORED_FOR_HOSTED_AGENT (warning)
        # When use_hosted_agent=True, the platform skips OS tag enforcement on
        # any HA asset. Regular assets in the same assessment still enforce OS
        # tags — but no error, the regular path simply runs in parallel. Warn
        # only when the regular asset's OS does not intersect any selected
        # scenario's platforms (it would do nothing on that test).
        if use_hosted_agent and selected_regular_asset_ids:
            useless_regular = []
            for tp in test_points_info:
                if tp["class"] != "regular":
                    continue
                tp_pl = set(tp["platforms"])
                useful_for_some = any(
                    not set(meta["supported_platforms"]) or (set(meta["supported_platforms"]) & tp_pl)
                    for meta in scenario_meta.values()
                )
                if not useful_for_some:
                    useless_regular.append(tp["id"])
            if useless_regular:
                matrix_issues.append(
                    {
                        "code": "OS_TAG_IGNORED_FOR_HOSTED_AGENT",
                        "level": "warning",
                        "asset_ids": useless_regular,
                    }
                )

        # Code: OS_TAG_MISMATCH_ON_ASSET (warning)
        # Even without the HA path, a regular asset whose OS doesn't intersect
        # any selected scenario is dead weight in the assessment. Surface as a
        # warning so callers can prune their asset list.
        if not use_hosted_agent and selected_regular_asset_ids and scenario_meta:
            mismatched = []
            for tp in test_points_info:
                if tp["class"] != "regular":
                    continue
                tp_pl = set(tp["platforms"])
                useful_for_some = any(
                    not set(meta["supported_platforms"]) or (set(meta["supported_platforms"]) & tp_pl)
                    for meta in scenario_meta.values()
                )
                if not useful_for_some:
                    mismatched.append(tp["id"])
            if mismatched:
                matrix_issues.append(
                    {
                        "code": "OS_TAG_MISMATCH_ON_ASSET",
                        "level": "warning",
                        "asset_ids": mismatched,
                    }
                )

        hosted_agent_matrix = {
            "use_hosted_agent": use_hosted_agent,
            "hosted_agent_assets_present": hosted_agent_assets_present,
            "regular_assets_present": regular_assets_present,
            "scenarios_ha_capable": list(scenarios_ha_capable_ids),
            "scenarios_regular_capable": list(scenarios_regular_capable_ids),
            "per_asset": matrix_per_asset,
            "issues": matrix_issues,
        }

        # Determine overall validity. Matrix error-level issues are blocking.
        matrix_has_errors = any(issue["level"] == "error" for issue in matrix_issues)
        is_valid = (
            len(errors) == 0
            and len(need_args) == 0
            and len(need_asset_tags) == 0
            and len(need_test_point) == 0
            and len(not_found) == 0
            and len(multi_asset) == 0
            and not matrix_has_errors
        )

        # Count only truly active test points for summary
        active_count = sum(1 for tp in test_points_info if tp.get("status") == "Active")

        # Backward-compatible "available_platforms" field — same OS string set
        # callers consumed before. Hosted-agent capability is reported via
        # `hosted_agent_matrix.use_hosted_agent` and `summary.hosted_agent_assets_present`
        # rather than as a synthetic platform string, to avoid confusing
        # consumers that assume members are real OS identifiers.
        available_platforms = list(all_regular_test_point_platforms)

        return {
            "is_valid": is_valid,
            "errors": errors,
            "warnings": warnings,
            "compatible_scenarios": compatible,
            "scenarios_need_args": need_args,
            "scenarios_need_asset_tags": need_asset_tags,
            "scenarios_need_test_point": need_test_point,
            "multi_asset_scenarios": multi_asset,
            "not_found_scenarios": not_found,
            "test_points": test_points_info,
            "hosted_agent_matrix": hosted_agent_matrix,
            "summary": {
                "total_scenarios": len(scenario_ids),
                "total_test_points": len(test_point_ids),
                "active_test_points": active_count,
                "available_platforms": available_platforms,
                "compatible": len(compatible),
                "need_args": len(need_args),
                "need_asset_tags": len(need_asset_tags),
                "need_test_point": len(need_test_point),
                "multi_asset": len(multi_asset),
                "not_found": len(not_found),
                "hosted_agent_assets_present": hosted_agent_assets_present,
                "regular_assets_present": regular_assets_present,
                "use_hosted_agent": use_hosted_agent,
                "matrix_error_count": sum(1 for i in matrix_issues if i["level"] == "error"),
                "matrix_warning_count": sum(1 for i in matrix_issues if i["level"] == "warning"),
            },
        }
