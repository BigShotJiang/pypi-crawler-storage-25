import re
from typing import Optional, Dict, Any, AsyncGenerator, List

from aiq_platform_api.core.async_utils import async_islice
from aiq_platform_api.core.client import AttackIQClient
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


_SLUG_NON_ALPHANUMERIC = re.compile(r"[^a-z0-9]+")


def _slugify(value: str) -> str:
    # Backend Tag.name is a SlugField. The platform normalizes via Django's
    # slugify before persisting, so we must search by the slug form to hit an
    # existing row when the caller passes a free-form display name.
    lowered = value.strip().lower()
    slug = _SLUG_NON_ALPHANUMERIC.sub("-", lowered).strip("-")
    return slug


def _limit_offset_to_page_params(limit: Optional[int], offset: Optional[int]) -> Dict[str, Any]:
    page_size = limit if limit is not None else 20
    if page_size <= 0:
        raise ValueError(f"limit must be positive, got {limit}")
    offset_value = offset or 0
    if offset_value < 0:
        raise ValueError(f"offset must be non-negative, got {offset}")
    if offset_value % page_size != 0:
        raise ValueError(
            f"offset {offset_value} is not aligned to page_size {page_size}; "
            "use offsets that are integer multiples of limit"
        )
    page = (offset_value // page_size) + 1
    return {"page_size": page_size, "page": page}


class TagSets:
    """Utilities for working with tag sets.

    API Endpoint: /v1/tag_sets
    """

    ENDPOINT = "v1/tag_sets"

    @staticmethod
    async def get_tag_set_id(client: AttackIQClient, tag_set_name: str) -> Optional[str]:
        """Get the ID of a tag set by its name (exact match)."""
        logger.debug(f"Searching for TagSet: '{tag_set_name}'")
        params = {"name": tag_set_name}
        tag_sets = [tag async for tag in client.get_all_objects(TagSets.ENDPOINT, params=params)]
        # Backend filters via name__icontains, so disambiguate client-side.
        for tag_set in tag_sets:
            if tag_set.get("name") == tag_set_name:
                logger.debug(f"TagSet '{tag_set_name}' found with ID '{tag_set['id']}'")
                return tag_set["id"]
        logger.warning(f"TagSet '{tag_set_name}' not found (exact match)")
        return None

    @staticmethod
    async def get_custom_tag_set_id(client: AttackIQClient) -> Optional[str]:
        """Get the ID of the 'Custom' tag set."""
        return await TagSets.get_tag_set_id(client, "Custom")

    @staticmethod
    async def search_tag_sets(
        client: AttackIQClient,
        query: Optional[str] = None,
        limit: Optional[int] = 20,
        offset: Optional[int] = 0,
        ordering: Optional[str] = "-modified",
    ) -> Dict[str, Any]:
        """Search tag sets. `query` maps to backend `name__icontains` (the only
        filter `/v1/tag_sets` supports). Returns full nested records — backend
        does not provide a `minimal` projection for this endpoint.
        """
        params: Dict[str, Any] = _limit_offset_to_page_params(limit, offset)
        if query:
            params["name"] = query
        if ordering:
            params["ordering"] = ordering
        logger.debug(f"Searching tag sets with params: {params}")
        data = await client.get_object(TagSets.ENDPOINT, params=params)
        return {"count": data.get("count", 0), "results": data.get("results", [])}

    @staticmethod
    async def create_tag_set(
        client: AttackIQClient,
        name: str,
        meta_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a tag set. `name` is stored verbatim (no slug field)."""
        payload: Dict[str, Any] = {"name": name}
        if meta_data is not None:
            payload["meta_data"] = meta_data
        logger.debug(f"Creating tag set '{name}'")
        return await client.post_object(TagSets.ENDPOINT, data=payload)

    @staticmethod
    async def delete_tag_set(client: AttackIQClient, tag_set_id: str) -> bool:
        """Delete a tag set by ID. Returns True on 2xx response."""
        logger.info(f"Deleting tag set with ID '{tag_set_id}'")
        response = await client.delete_object(f"{TagSets.ENDPOINT}/{tag_set_id}")
        if response is not None and 200 <= response.get("status_code", 0) < 300:
            logger.info(f"Successfully deleted tag set: {tag_set_id}")
            return True
        logger.error(f"Failed to delete tag set: {tag_set_id}")
        return False


class Tags:
    """Utilities for managing tags in the AttackIQ platform.

    API Endpoint: /v1/tags
    """

    ENDPOINT = "v1/tags"

    @staticmethod
    async def get_tags(
        client: AttackIQClient, params: dict = None, limit: Optional[int] = 10
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """List tags, optionally filtered and limited."""
        generator = client.get_all_objects(Tags.ENDPOINT, params=params)
        async for tag in async_islice(generator, 0, limit):
            yield tag

    @staticmethod
    async def get_tag_by_id(client: AttackIQClient, tag_id: str):
        """Get a specific tag by its ID."""
        return await client.get_object(f"{Tags.ENDPOINT}/{tag_id}")

    @staticmethod
    async def create_tag(
        client: AttackIQClient,
        tag_name: str,
        tag_set_id: str,
        display_name: Optional[str] = None,
    ):
        """Create a new tag. `tag_name` should be the slug form; `display_name`
        defaults to `tag_name` when not provided.
        """
        tag_data = {
            "name": tag_name,
            "display_name": display_name if display_name is not None else tag_name,
            "tag_set": tag_set_id,
            "meta_data": None,
        }
        logger.debug(f"Creating tag '{tag_name}' in tag set ID '{tag_set_id}'")
        return await client.post_object(Tags.ENDPOINT, data=tag_data)

    @staticmethod
    async def get_tag_id(client: AttackIQClient, tag_name: str, tag_set_id: str):
        """Get the ID of a tag by name and tag set ID (exact match on name)."""
        params = {"name": tag_name, "tag_set": tag_set_id}
        tags = [tag async for tag in client.get_all_objects(Tags.ENDPOINT, params=params)]
        # Backend filters via name__icontains, so disambiguate client-side.
        for tag in tags:
            if tag.get("name") == tag_name:
                logger.debug(f"Tag '{tag_name}' found with ID '{tag['id']}'")
                return tag["id"]
        logger.debug(f"Tag '{tag_name}' not found in tag set '{tag_set_id}'")
        return None

    @staticmethod
    async def get_tag_record(client: AttackIQClient, tag_name: str, tag_set_id: str) -> Optional[Dict[str, Any]]:
        """Get the full tag record by name and tag set ID (exact match on name)."""
        params = {"name": tag_name, "tag_set": tag_set_id}
        tags = [tag async for tag in client.get_all_objects(Tags.ENDPOINT, params=params)]
        for tag in tags:
            if tag.get("name") == tag_name:
                return tag
        return None

    @staticmethod
    async def delete_tag(client: AttackIQClient, tag_id: str):
        """Delete a specific tag by its ID."""
        logger.info(f"Deleting tag with ID '{tag_id}'")
        return await client.delete_object(f"{Tags.ENDPOINT}/{tag_id}")

    @staticmethod
    async def get_or_create_tag(
        client: AttackIQClient,
        tag_name: str,
        tag_set: str,
        display_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get or create a tag. Returns ``{"tag": <full record>, "created": <bool>}``.

        - ``tag_set`` accepts a UUID *or* a name; names are resolved via
          ``TagSets.get_tag_set_id`` (exact client-side match).
        - ``tag_name`` is slugified before the lookup/create so that callers
          passing a free-form display name still hit existing rows.
        - When no explicit ``display_name`` is passed, the original input
          string is preserved as the display name.
        """
        # Resolve tag_set: heuristic — UUIDs always include a dash and never
        # appear with whitespace, so anything containing a space is a name.
        tag_set_id = tag_set
        if " " in tag_set or not _looks_like_uuid(tag_set):
            resolved = await TagSets.get_tag_set_id(client, tag_set)
            if not resolved:
                raise ValueError(f"TagSet '{tag_set}' not found")
            tag_set_id = resolved

        slug = _slugify(tag_name)
        if not slug:
            raise ValueError(f"tag_name '{tag_name}' slugifies to empty string")
        resolved_display = display_name if display_name is not None else tag_name

        existing = await Tags.get_tag_record(client, slug, tag_set_id)
        if existing:
            return {"tag": existing, "created": False}

        created = await Tags.create_tag(client, slug, tag_set_id, display_name=resolved_display)
        if not created:
            raise RuntimeError(f"Failed to create tag '{slug}' in tag set '{tag_set_id}'")
        return {"tag": created, "created": True}

    @staticmethod
    async def get_or_create_custom_tag(
        client: AttackIQClient,
        tag_name: str,
        display_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get or create a tag in the Custom tag set. Returns
        ``{"tag": <full record>, "created": <bool>}``.
        """
        return await Tags.get_or_create_tag(client, tag_name, "Custom", display_name=display_name)

    @staticmethod
    async def search_tags(
        client: AttackIQClient,
        query: Optional[str] = None,
        name: Optional[str] = None,
        tag_set: Optional[str] = None,
        modified: Optional[str] = None,
        limit: Optional[int] = 20,
        offset: Optional[int] = 0,
        ordering: Optional[str] = "-modified",
    ) -> Dict[str, Any]:
        """Search tags on ``/v1/tags``.

        - ``query`` maps to backend ``search`` (free-text across ``name`` and
          ``display_name``).
        - ``name`` maps to backend ``name__icontains`` (slug-only).
        - ``tag_set`` accepts a UUID or a name; names are exact-matched via
          ``TagSets.get_tag_set_id``.
        - ``modified`` is a pass-through filter.

        Backend ``/v1/tags`` does **not** support ``content_type`` or exact
        ``display_name`` filters; callers wanting an exact display-name match
        should pass ``query=<name>`` and post-filter client-side.
        """
        params: Dict[str, Any] = _limit_offset_to_page_params(limit, offset)
        if query:
            params["search"] = query
        if name:
            params["name"] = name
        if tag_set:
            if _looks_like_uuid(tag_set):
                params["tag_set"] = tag_set
            else:
                resolved = await TagSets.get_tag_set_id(client, tag_set)
                if not resolved:
                    raise ValueError(f"TagSet '{tag_set}' not found")
                params["tag_set"] = resolved
        if modified:
            params["modified"] = modified
        if ordering:
            params["ordering"] = ordering
        logger.debug(f"Searching tags with params: {params}")
        data = await client.get_object(Tags.ENDPOINT, params=params)
        response: Dict[str, Any] = {"count": data.get("count", 0), "results": data.get("results", [])}
        if "detail" in data:
            response["detail"] = data["detail"]
        return response

    @staticmethod
    async def search_mitre_tags(
        client: AttackIQClient, technique_id: str, limit: Optional[int] = 20, offset: Optional[int] = 0
    ) -> Dict[str, Any]:
        return await Tags.search_tags(client, query=technique_id, limit=limit, offset=offset)


def _looks_like_uuid(value: str) -> bool:
    """Cheap heuristic: 32 hex chars with 4 hyphens at canonical positions."""
    if not value or len(value) != 36:
        return False
    if value[8] != "-" or value[13] != "-" or value[18] != "-" or value[23] != "-":
        return False
    hex_chars = value.replace("-", "")
    return len(hex_chars) == 32 and all(c in "0123456789abcdefABCDEF" for c in hex_chars)


class TaggedItems:
    """Utilities for working with tagged items in the AttackIQ platform.

    API Endpoint: /v1/tagged_items
    """

    ENDPOINT = "v1/tagged_items"
    BULK_CREATE_ENDPOINT = "v1/tagged_items/bulk_create"
    BULK_DELETE_ENDPOINT = "v1/tagged_items/bulk_delete"

    @staticmethod
    async def get_tagged_items(
        client: AttackIQClient,
        content_type: str,
        object_id: str,
        limit: Optional[int] = 10,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """List tagged items for an object, optionally limited."""
        logger.info(f"Fetching tagged items for object of type: {content_type} with ID '{object_id}'")
        params = {"content_type": content_type, "object_id": object_id}
        generator = client.get_all_objects(TaggedItems.ENDPOINT, params=params)
        async for item in async_islice(generator, 0, limit):
            yield item

    @staticmethod
    async def get_tagged_item(client: AttackIQClient, content_type: str, object_id: str, tag_id: str):
        """Get a specific tagged item linking an object and a tag."""
        params = {"content_type": content_type, "object_id": object_id, "tag_id": tag_id}
        items = [item async for item in client.get_all_objects(TaggedItems.ENDPOINT, params=params)]
        return items[0] if items else None

    @staticmethod
    async def create_tagged_item(client: AttackIQClient, content_type: str, object_id: str, tag_id: str) -> str:
        """Create a tagged item (apply a tag to an object)."""
        logger.info(
            f"Creating tagged item with tag_id '{tag_id}' to object of type: {content_type} with ID '{object_id}'"
        )
        data = {
            "content_type": content_type,
            "object_id": object_id,
            "tag": tag_id,
        }
        tag_item = await client.post_object(TaggedItems.ENDPOINT, data)
        if tag_item:
            tag_item_id = tag_item["id"]
            logger.info(f"Successfully created tagged item with ID {tag_item_id}")
            return tag_item_id
        logger.error(f"Failed to create tag item with tag '{tag_id}' to object with ID '{object_id}'")
        return ""

    @staticmethod
    async def delete_tagged_item(client: AttackIQClient, tagged_item_id: str) -> bool:
        """Delete a tagged item (remove a tag from an object)."""
        logger.info(f"Removing tag item with ID {tagged_item_id}")
        response = await client.delete_object(f"{TaggedItems.ENDPOINT}/{tagged_item_id}")
        if response:
            logger.info(f"Successfully deleted tag item with ID {tagged_item_id}")
            return True
        logger.error(f"Failed to delete tagged item with ID {tagged_item_id}")
        return False

    @staticmethod
    async def bulk_create_tagged_items(client: AttackIQClient, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Bulk-create tagged items.

        Each item: ``{"tag": <tag_id>, "content_type": <type>, "object_id": <uuid>}``.
        Returns the raw backend response ``{"success": [...], "errors": [...]}``.
        """
        url = client._build_url(TaggedItems.BULK_CREATE_ENDPOINT)
        body = {"data": items}
        logger.info(f"Bulk-creating {len(items)} tagged items")
        data = await client._make_request(url, method="post", json=body)
        return data or {"success": [], "errors": []}

    @staticmethod
    async def bulk_delete_tagged_items(client: AttackIQClient, tuples: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Bulk-delete tagged items by ``(tag, object_id, content_type)`` tuples.

        Backend takes tuples (not tagged-item IDs). Each tuple:
        ``{"tag": <tag_id>, "object_id": <uuid>, "content_type": <type>}``.
        Returns the raw backend response ``{"success": [...], "errors": [...]}``
        where ``success`` contains deleted tagged-item IDs and ``errors``
        contains per-tuple failures.

        ``AttackIQClient.delete_object()`` does not accept a JSON body, so this
        helper calls ``_make_request`` directly.
        """
        url = client._build_url(TaggedItems.BULK_DELETE_ENDPOINT)
        body = {"data": tuples}
        logger.info(f"Bulk-deleting {len(tuples)} tagged items")
        data = await client._make_request(url, method="delete", json=body)
        return data or {"success": [], "errors": []}

    @staticmethod
    async def search_tagged_items(
        client: AttackIQClient,
        tag_id: Optional[str] = None,
        content_type: Optional[str] = None,
        object_id: Optional[str] = None,
        query: Optional[str] = None,
        limit: Optional[int] = 20,
        offset: Optional[int] = 0,
        ordering: Optional[str] = "-modified",
    ) -> Dict[str, Any]:
        """Search tagged items.

        - ``tag_id`` filters by tag UUID (backend param is ``tag_id``, not
          ``tag``). Callers passing a tag *name* must resolve it via
          ``Tags.search_tags`` first.
        - ``content_type`` and ``object_id`` are pass-through filters.
        - ``query`` maps to backend ``search`` which on ``TaggedItemViewSet``
          is restricted to ``tag__display_name`` only — **not** a free-text
          search across all tagged-item fields.

        Returns ``{"count", "results"}``.
        """
        params: Dict[str, Any] = _limit_offset_to_page_params(limit, offset)
        if tag_id:
            params["tag_id"] = tag_id
        if content_type:
            params["content_type"] = content_type
        if object_id:
            params["object_id"] = object_id
        if query:
            params["search"] = query
        if ordering:
            params["ordering"] = ordering
        logger.debug(f"Searching tagged items with params: {params}")
        data = await client.get_object(TaggedItems.ENDPOINT, params=params)
        return {"count": data.get("count", 0), "results": data.get("results", [])}
