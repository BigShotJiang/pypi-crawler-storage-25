from typing import Any, Dict, Optional

from aiq_platform_api.core.client import AttackIQClient
from aiq_platform_api.core.logger import AttackIQLogger

logger = AttackIQLogger.get_logger(__name__)


class Tests:
    """Utilities for working with assessment tests (ScenarioMasterJobs).

    A "test" in the platform is a `ScenarioMasterJob` — the per-test container
    inside an assessment that holds scenarios, default assets, and execution
    flags such as `use_hosted_agent`.

    API Endpoint: /v1/tests
    """

    ENDPOINT = "v1/tests"

    @staticmethod
    async def patch(client: AttackIQClient, test_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Generic PATCH on /v1/tests/{test_id}.

        Use this for any updatable field on the test. For the common
        `use_hosted_agent` toggle, prefer `Tests.patch_use_hosted_agent`
        which documents the platform's asymmetric behaviour for the
        sibling `use_pool_agent` flag.
        """
        endpoint = f"{Tests.ENDPOINT}/{test_id}"
        logger.info(f"Patching test {test_id} with data: {data}")
        return await client.patch_object(endpoint, data)

    @staticmethod
    async def patch_use_hosted_agent(client: AttackIQClient, test_id: str, value: bool) -> Optional[Dict[str, Any]]:
        """Set the `use_hosted_agent` flag on a test.

        This is the master toggle that enables the hosted-agent execution
        path: when True, the platform skips per-asset OS checks for any
        hosted-agent (custom or pool) asset assigned to the test, and the
        scenarios with the `Runnable by Hosted Agent` capability tag execute
        on those assets.

        Note: the sibling `use_pool_agent` flag is intentionally NOT exposed
        here. It is read-computed by the platform from the test's assets
        (returns True only if a `PoolAgentAsset` row exists for one of the
        test's assets). PATCHing it returns 200 OK but the value does not
        persist — exposing it as a tunable would mislead callers.
        """
        return await Tests.patch(client, test_id, {"use_hosted_agent": value})
