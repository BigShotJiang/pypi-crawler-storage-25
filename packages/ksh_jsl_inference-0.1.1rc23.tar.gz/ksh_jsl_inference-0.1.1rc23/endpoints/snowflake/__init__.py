"""Snowflake deployment utilities for John Snow Labs models.

This module provides functionality for deploying machine learning models to Snowflake
platform. It includes utilities for generating Docker files and building Docker images
specifically configured for Snowflake's deployment requirements.

The module handles:
- Generation of Snowflake-compatible Docker configurations
- Building Docker images optimized for Snowflake deployment
- Managing default file locations for deployment artifacts

Examples:
    ```python
    from endpoints.snowflake import generate_docker_files, build_docker_image

    # Generate Docker files for a model
    docker_files_path = generate_docker_files("my-model-id")

    # Build Docker image for Snowflake deployment
    build_docker_image("my-model-id")
    ```
"""

import os
import uuid
from typing import Optional

import endpoints
from endpoints import Platform, container
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION, HOME_DIR

from .components import *


def get_default_docker_file_location() -> str:
    """Get the default location for Docker files in Snowflake platform.

    Generates a unique directory path within the JSL inference home directory
    specifically for Snowflake Docker files.

    Returns:
        str: The default directory path for storing Docker files.
    """
    return os.path.join(
        HOME_DIR, ".jsl_inference", Platform.SNOWFLAKE, str(uuid.uuid4())
    )


def generate_docker_files(
    model_id: str,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    no_license: bool = False,
    language: str = "en",
    output_dir: Optional[str] = None,
    **kwargs,
):
    """Generate Docker files for the specified model for Snowflake deployment.

    Creates the necessary Docker configuration files required to deploy a model
    on Snowflake platform. This includes Dockerfile and other deployment
    artifacts specific to Snowflake's requirements.

    Args:
        model_id (str): The identifier of the model to generate Docker files for.
        johnsnowlabs_version (str, optional): Version of johnsnowlabs library to use.
            Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        no_license (bool, optional): Whether to skip license validation.
            Defaults to False.
        language (str, optional): Language setting for the model.
            Defaults to "en".
        output_dir (Optional[str], optional): Directory where Docker files will be stored.
            If None, uses the default location from get_default_docker_file_location().
            Defaults to None.

    Returns:
        The result from container.generate_docker_files function, typically the
        output directory path where files were generated.
    """

    return container.generate_docker_files(
        model_id=model_id,
        language=language,
        no_license=no_license,
        johnsnowlabs_version=johnsnowlabs_version,
        platform=endpoints.Platform.SNOWFLAKE,
        store_model=True,
        output_dir=output_dir or get_default_docker_file_location(),
        **kwargs,
    )


def build_docker_image(
    model_id: str,
    language: str = "en",
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    no_license: bool = False,
    output_dir: Optional[str] = None,
    image_name: Optional[str] = None,
    license_path: Optional[str] = None,
    no_cache: bool = False,
    image_tag: str = "latest",
    **kwargs,
):
    """Build Docker image for Snowflake platform deployment.

    Generates the necessary Docker files for the specified model and then builds
    a Docker image suitable for deployment on Snowflake platform.

    Args:
        model_id (str): The identifier of the model to build Docker image for.
        language (str, optional): Language setting for the model.
            Defaults to "en".
        johnsnowlabs_version (str, optional): Version of johnsnowlabs library to use.
            Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        no_license (bool, optional): Whether to skip license validation.
            Defaults to False.
        output_dir (Optional[str], optional): Directory where Docker files will be stored.
            If None, uses the default location from get_default_docker_file_location().
            Defaults to None.
        image_name (str): Name for the Docker image to be built.
        license_path (Optional[str]): Path to the license file. If None or invalid,
            will attempt to find license from JSL_HOME.
        no_cache (bool, optional): Whether to build without using Docker cache.
            Defaults to False.
        image_tag (str, optional): Tag for the Docker image. Defaults to "latest".


    Note:
        This function combines the Docker file generation and image building
        steps into a single operation for convenience.
    """
    docker_files_location = generate_docker_files(
        model_id,
        language=language,
        johnsnowlabs_version=johnsnowlabs_version,
        no_license=no_license,
        output_dir=output_dir,
        **kwargs,
    )

    container.build_docker_image(
        image_name=image_name or container.format_docker_image_name(model_id),
        build_context_dir=docker_files_location,
        license_path=license_path,
        no_cache=no_cache,
        image_tag=image_tag,
        **kwargs,
    )


__all__ = ["generate_docker_files", "build_docker_image"]
