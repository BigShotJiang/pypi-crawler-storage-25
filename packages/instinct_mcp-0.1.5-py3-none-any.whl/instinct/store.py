"""instinct.store — SQLite-backed pattern learning engine.

Records recurring patterns from AI agent sessions, tracks confidence,
and auto-promotes patterns through maturity levels:

  raw       (confidence < 5)   — observed but not yet actionable
  mature    (confidence >= 5)  — ready to suggest
  rule      (confidence >= 10) — strong enough to auto-apply

Schema:
  instincts(
    pattern TEXT PRIMARY KEY,  -- e.g. "seq:lint->fix->lint"
    category TEXT,             -- "sequence", "preference", "fix_pattern", "combo"
    confidence INTEGER,        -- incremented on each observation
    first_seen TEXT,           -- ISO timestamp
    last_seen TEXT,            -- ISO timestamp
    source TEXT,               -- originating tool/agent
    project TEXT,              -- project fingerprint
    promoted INTEGER,          -- 0=raw, 1=mature, 2=rule
    metadata TEXT              -- JSON blob for extra context
  )
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_DB = Path.home() / ".instinct" / "instinct.db"

# Promotion thresholds
THRESHOLD_MATURE = 5
THRESHOLD_RULE = 10


def project_fingerprint(path: str | Path | None = None) -> str:
    """Generate a stable fingerprint for a project directory."""
    if path is None:
        path = Path.cwd()
    p = Path(path).resolve()
    return hashlib.sha256(str(p).encode()).hexdigest()[:12]


class InstinctStore:
    """Pattern learning engine backed by SQLite."""

    def __init__(self, db_path: Path | str | None = None):
        self.db_path = Path(db_path) if db_path else DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS instincts (
                pattern TEXT PRIMARY KEY,
                category TEXT NOT NULL DEFAULT 'sequence',
                confidence INTEGER NOT NULL DEFAULT 1,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                source TEXT NOT NULL DEFAULT '',
                project TEXT NOT NULL DEFAULT '',
                promoted INTEGER NOT NULL DEFAULT 0,
                metadata TEXT NOT NULL DEFAULT '{}'
            )
        """)
        self._conn.commit()

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _parse_row(self, row: sqlite3.Row) -> dict:
        d = dict(row)
        try:
            d["metadata"] = json.loads(d["metadata"])
        except (json.JSONDecodeError, TypeError):
            pass
        d["level"] = ["raw", "mature", "rule"][min(d.get("promoted", 0), 2)]
        return d

    # ── Core Operations ───────────────────────────────────────────

    def observe(
        self,
        pattern: str,
        category: str = "sequence",
        source: str = "",
        project: str = "",
        metadata: dict | None = None,
    ) -> dict:
        """Record or reinforce a pattern. Returns the updated instinct."""
        now = self._now()
        meta_json = json.dumps(metadata or {})
        self._conn.execute(
            """
            INSERT INTO instincts
                (pattern, category, confidence, first_seen, last_seen,
                 source, project, promoted, metadata)
            VALUES (?, ?, 1, ?, ?, ?, ?, 0, ?)
            ON CONFLICT(pattern) DO UPDATE SET
                confidence = confidence + 1,
                last_seen = excluded.last_seen,
                source = CASE WHEN excluded.source != '' THEN excluded.source
                              ELSE instincts.source END,
                project = CASE WHEN excluded.project != '' THEN excluded.project
                               ELSE instincts.project END,
                metadata = CASE WHEN excluded.metadata != '{}'
                                THEN excluded.metadata ELSE instincts.metadata END
            """,
            (pattern, category, now, now, source, project, meta_json),
        )
        self._conn.commit()
        return self.get(pattern)  # type: ignore[return-value]

    def get(self, pattern: str) -> dict | None:
        """Get a single instinct by pattern."""
        row = self._conn.execute(
            "SELECT * FROM instincts WHERE pattern = ?", (pattern,)
        ).fetchone()
        return self._parse_row(row) if row else None

    def delete(self, pattern: str) -> bool:
        """Delete a single instinct."""
        cur = self._conn.execute(
            "DELETE FROM instincts WHERE pattern = ?", (pattern,)
        )
        self._conn.commit()
        return cur.rowcount > 0

    # ── Query Operations ──────────────────────────────────────────

    def list(
        self,
        min_confidence: int = 1,
        category: str | None = None,
        project: str | None = None,
        promoted: int | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """List instincts with optional filters."""
        sql = "SELECT * FROM instincts WHERE confidence >= ?"
        params: list[Any] = [min_confidence]
        if category:
            sql += " AND category = ?"
            params.append(category)
        if project:
            sql += " AND project = ?"
            params.append(project)
        if promoted is not None:
            sql += " AND promoted >= ?"
            params.append(promoted)
        sql += " ORDER BY confidence DESC, last_seen DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._parse_row(r) for r in rows]

    def suggest(self, project: str | None = None) -> list[dict]:
        """Return mature+ instincts (confidence >= THRESHOLD_MATURE).

        If project is given, includes both project-specific and global instincts.
        """
        if project:
            rows = self._conn.execute(
                """SELECT * FROM instincts
                   WHERE confidence >= ?
                     AND (project = ? OR project = '')
                   ORDER BY confidence DESC""",
                (THRESHOLD_MATURE, project),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM instincts WHERE confidence >= ? ORDER BY confidence DESC",
                (THRESHOLD_MATURE,),
            ).fetchall()
        return [self._parse_row(r) for r in rows]

    def search(self, query: str, limit: int = 20) -> list[dict]:
        """Search instincts by pattern or metadata content."""
        pattern = f"%{query}%"
        rows = self._conn.execute(
            """SELECT * FROM instincts
               WHERE pattern LIKE ? OR metadata LIKE ?
               ORDER BY confidence DESC LIMIT ?""",
            (pattern, pattern, limit),
        ).fetchall()
        return [self._parse_row(r) for r in rows]

    # ── Lifecycle Operations ──────────────────────────────────────

    def consolidate(self) -> dict:
        """Auto-promote instincts based on confidence thresholds.

        Returns: {promoted_to_mature, promoted_to_rule, total, timestamp}
        """
        cur_mature = self._conn.execute(
            "UPDATE instincts SET promoted = 1 WHERE confidence >= ? AND promoted < 1",
            (THRESHOLD_MATURE,),
        )
        to_mature = cur_mature.rowcount

        cur_rule = self._conn.execute(
            "UPDATE instincts SET promoted = 2 WHERE confidence >= ? AND promoted < 2",
            (THRESHOLD_RULE,),
        )
        to_rule = cur_rule.rowcount

        self._conn.commit()
        total = self._conn.execute("SELECT COUNT(*) FROM instincts").fetchone()[0]
        return {
            "promoted_to_mature": to_mature,
            "promoted_to_rule": to_rule,
            "total": total,
            "timestamp": self._now(),
        }

    def decay(self, days_inactive: int = 90, amount: int = 1) -> int:
        """Reduce confidence of instincts not seen for N days. Returns count affected."""
        from datetime import timedelta

        cutoff = (datetime.now(timezone.utc) - timedelta(days=days_inactive)).isoformat()
        cur = self._conn.execute(
            """UPDATE instincts SET confidence = MAX(confidence - ?, 0)
               WHERE last_seen < ? AND confidence > 0""",
            (amount, cutoff),
        )
        # Clean up zero-confidence entries
        self._conn.execute("DELETE FROM instincts WHERE confidence = 0")
        self._conn.commit()
        return cur.rowcount

    def stats(self) -> dict:
        """Return summary statistics."""
        rows = self._conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN promoted = 0 THEN 1 ELSE 0 END) as raw,
                SUM(CASE WHEN promoted = 1 THEN 1 ELSE 0 END) as mature,
                SUM(CASE WHEN promoted = 2 THEN 1 ELSE 0 END) as rules,
                AVG(confidence) as avg_confidence,
                MAX(confidence) as max_confidence
            FROM instincts
        """).fetchone()
        d = dict(rows)
        # sqlite returns None for empty tables
        return {k: (v or 0) for k, v in d.items()}

    def export_rules(self) -> list[dict]:
        """Export rule-level instincts (promoted=2) for external consumption."""
        rows = self._conn.execute(
            "SELECT * FROM instincts WHERE promoted = 2 ORDER BY confidence DESC"
        ).fetchall()
        return [self._parse_row(r) for r in rows]

    def close(self) -> None:
        self._conn.close()
