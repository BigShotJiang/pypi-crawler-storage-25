// tests/integration/test_130_stiffness_curve.rs
//
// 130 — StiffnessCurve support tests
//
// Validates the StiffnessCurve support condition type where rotational spring
// stiffness varies as a function of the axial load (Fz) at the support node.
//
// Model: Vertical column (Z-axis) with fixed base translations, StiffnessCurve
// rotational springs, subjected to axial + lateral loads.

use super::test_support::helpers::*;
use super::test_support::*;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::supports::supportcondition::SupportCondition;
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

// ─────────────────────────────────────────────────────────────────────────────
// 130a — Constant stiffness curve should match a regular Spring support
//
// When all curve points have the same stiffness, behaviour must be
// identical to a constant rotational Spring support.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_130a_constant_curve_matches_spring() {
    let k_rot = 1.0e7; // 10 MN·m/rad

    // ── Model with constant-stiffness curve ──
    let mut model_curve = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model_curve, 1);
    let sec = add_section_ipe180_like(&mut model_curve, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // StiffnessCurve with constant stiffness across all axial loads
    let curve = vec![
        [0.0, k_rot],
        [100_000.0, k_rot],
    ];
    model_curve.nodal_supports.push(make_stiffness_curve_support(1, None, Some(curve)));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 0.0, 0.0, 3.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec);
    add_member_set(&mut model_curve, 1, vec![m1]);

    let lc = add_load_case(&mut model_curve, 1, "Axial+Lateral");
    // Axial compression (Z-direction) + lateral (X-direction)
    add_nodal_load(&mut model_curve, 1, lc, 2, 50_000.0, (0.0, 0.0, -1.0)); // 50 kN axial
    add_nodal_load(&mut model_curve, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0)); // 1 kN lateral

    model_curve.normalize_units();
    model_curve
        .solve_for_load_case_second_order(lc, 30)
        .expect("StiffnessCurve second-order solve failed");
    denorm_results_in_place(&mut model_curve);

    // ── Model with regular Spring (same stiffness) ──
    let mut model_spring = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat2 = add_material_s235(&mut model_spring, 1);
    let sec2 = add_section_ipe180_like(&mut model_spring, 1, mat2, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Build the same support manually with Spring type and constant stiffness
    let mut spring_sup = make_fixed_support(2);
    spring_sup.id = 1;
    spring_sup.rotation_conditions.insert(
        "Z".to_string(),
        SupportCondition {
            condition_type: SupportConditionType::Spring,
            stiffness: Some(k_rot),
            stiffness_curve: None,
        },
    );
    model_spring.nodal_supports.push(spring_sup);

    let n1b = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2b = make_node(2, 0.0, 0.0, 3.0, None);
    let m1b = make_beam_member(1, &n1b, &n2b, sec2);
    add_member_set(&mut model_spring, 1, vec![m1b]);

    let lc2 = add_load_case(&mut model_spring, 1, "Axial+Lateral");
    add_nodal_load(&mut model_spring, 1, lc2, 2, 50_000.0, (0.0, 0.0, -1.0));
    add_nodal_load(&mut model_spring, 2, lc2, 2, 1_000.0, (1.0, 0.0, 0.0));

    model_spring.normalize_units();
    model_spring
        .solve_for_load_case_second_order(lc2, 30)
        .expect("Spring second-order solve failed");
    denorm_results_in_place(&mut model_spring);

    // ── Compare displacements ──
    let res_curve = &model_curve.results.as_ref().unwrap().loadcases["Axial+Lateral"];
    let res_spring = &model_spring.results.as_ref().unwrap().loadcases["Axial+Lateral"];

    let d2_curve = res_curve.displacement_nodes.get(&2).unwrap();
    let d2_spring = res_spring.displacement_nodes.get(&2).unwrap();

    let tol = 1.0e-4;
    assert_close_ctx(
        "130a constant curve vs spring",
        d2_spring.dx, d2_curve.dx, tol, "dx at tip",
    );
    assert_close_ctx(
        "130a constant curve vs spring",
        d2_spring.dy, d2_curve.dy, tol, "dy at tip",
    );
    assert_close_ctx(
        "130a constant curve vs spring",
        d2_spring.dz, d2_curve.dz, tol, "dz at tip",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 130b — Variable stiffness: changing axial load changes rotational behaviour
//
// Column with StiffnessCurve that increases stiffness with axial load on My.
// Two models with different axial loads get different rotational stiffness,
// producing different lateral displacements.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_130b_variable_stiffness_with_axial_load() {
    // Stiffness curve on My (bending about Y due to X-lateral load):
    // low axial → soft spring, high axial → stiff spring
    let curve_my = vec![
        [0.0, 1.0e5],      // 0 kN axial → 100 kN·m/rad
        [50_000.0, 1.0e7],  // 50 kN axial → 10 MN·m/rad
        [100_000.0, 1.0e8], // 100 kN axial → 100 MN·m/rad
    ];

    // ── Model with low axial load ──
    let mut model_low = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat = add_material_s235(&mut model_low, 1);
    let sec = add_section_ipe180_like(&mut model_low, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model_low.nodal_supports.push(make_stiffness_curve_support(1, Some(curve_my.clone()), None));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 0.0, 0.0, 3.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec);
    add_member_set(&mut model_low, 1, vec![m1]);

    let lc = add_load_case(&mut model_low, 1, "LowAxial");
    add_nodal_load(&mut model_low, 1, lc, 2, 5_000.0, (0.0, 0.0, -1.0)); // 5 kN axial (low)
    add_nodal_load(&mut model_low, 2, lc, 2, 1_000.0, (1.0, 0.0, 0.0)); // 1 kN lateral X

    model_low.normalize_units();
    model_low
        .solve_for_load_case_second_order(lc, 30)
        .expect("Low axial solve failed");
    denorm_results_in_place(&mut model_low);

    // ── Model with high axial load ──
    let mut model_high = make_fers_with_strategy(RigidStrategy::RigidMember);
    let mat2 = add_material_s235(&mut model_high, 1);
    let sec2 = add_section_ipe180_like(&mut model_high, 1, mat2, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model_high.nodal_supports.push(make_stiffness_curve_support(1, Some(curve_my), None));

    let n1b = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2b = make_node(2, 0.0, 0.0, 3.0, None);
    let m1b = make_beam_member(1, &n1b, &n2b, sec2);
    add_member_set(&mut model_high, 1, vec![m1b]);

    let lc2 = add_load_case(&mut model_high, 1, "HighAxial");
    add_nodal_load(&mut model_high, 1, lc2, 2, 80_000.0, (0.0, 0.0, -1.0)); // 80 kN axial (high)
    add_nodal_load(&mut model_high, 2, lc2, 2, 1_000.0, (1.0, 0.0, 0.0)); // 1 kN lateral X

    model_high.normalize_units();
    model_high
        .solve_for_load_case_second_order(lc2, 30)
        .expect("High axial solve failed");
    denorm_results_in_place(&mut model_high);

    // ── Compare: different axial loads produce different displacements ──
    let dx_low = model_low
        .results.as_ref().unwrap().loadcases["LowAxial"]
        .displacement_nodes.get(&2).unwrap().dx;
    let dx_high = model_high
        .results.as_ref().unwrap().loadcases["HighAxial"]
        .displacement_nodes.get(&2).unwrap().dx;

    // Both displacements should be non-zero (lateral load applied)
    assert!(
        dx_low.abs() > 1.0e-8,
        "Low-axial model should have non-zero lateral displacement: dx_low={dx_low}",
    );
    assert!(
        dx_high.abs() > 1.0e-8,
        "High-axial model should have non-zero lateral displacement: dx_high={dx_high}",
    );

    // The displacements should differ meaningfully since the rotational
    // spring stiffness is very different (100 kN·m/rad vs ~80 MN·m/rad)
    let ratio = dx_low.abs() / dx_high.abs();
    assert!(
        !(0.67..=1.5).contains(&ratio),
        "Displacements should differ significantly due to stiffness curve. \
         dx_low={dx_low}, dx_high={dx_high}, ratio={ratio}",
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 130c — Clamping at curve boundaries
//
// When axial load exceeds the curve range, the stiffness should clamp
// to the nearest boundary value.
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_130c_clamping_at_boundaries() {
    use fers_calculations::functions::support_utils::interpolate_stiffness_curve;

    let curve = &[
        [10.0, 100.0],
        [50.0, 500.0],
    ];

    // Below range → clamp to first point's stiffness
    assert_close(100.0, interpolate_stiffness_curve(curve, 0.0), 1e-10);
    assert_close(100.0, interpolate_stiffness_curve(curve, 10.0), 1e-10);

    // Above range → clamp to last point's stiffness
    assert_close(500.0, interpolate_stiffness_curve(curve, 100.0), 1e-10);
    assert_close(500.0, interpolate_stiffness_curve(curve, 50.0), 1e-10);

    // Mid-range → linear interpolation
    // At 30: t = (30-10)/(50-10) = 0.5, k = 100 + 0.5*(500-100) = 300
    assert_close(300.0, interpolate_stiffness_curve(curve, 30.0), 1e-10);
}

// ─────────────────────────────────────────────────────────────────────────────
// 130d — Error when used with linear analysis
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_130d_error_with_linear_analysis() {
    use fers_calculations::analysis::calculate_from_json_internal;

    let json_str = r#"{
        "member_sets": [{
            "id": 1,
            "members": [{
                "id": 1,
                "start_node": {"id": 1, "X": 0, "Y": 0, "Z": 0, "nodal_support": 1},
                "end_node": {"id": 2, "X": 0, "Y": 0, "Z": 3, "nodal_support": null},
                "rotation_angle": 0, "classification": "Normal", "weight": 0,
                "member_type": "Normal", "section": 1
            }]
        }],
        "load_cases": [{
            "id": 1, "name": "Test",
            "nodal_loads": [{"id": 1, "node": 2, "load_case": 1, "magnitude": 1000, "direction": [1,0,0], "load_type": "Force"}],
            "nodal_moments": [], "distributed_loads": [],
            "rotation_imperfections": [], "translation_imperfections": []
        }],
        "load_combinations": [],
        "imperfection_cases": [],
        "materials": [{"id": 1, "name": "S235", "e_mod": 210000000000, "g_mod": 81000000000, "density": 7850, "yield_stress": 235000000}],
        "sections": [{"id": 1, "name": "IPE180", "material": 1, "i_y": 1.0e-6, "i_z": 13.21e-6, "j": 1e-5, "area": 26.2e-4}],
        "nodal_supports": [{
            "id": 1,
            "displacement_conditions": {
                "X": {"condition_type": "Fixed"},
                "Y": {"condition_type": "Fixed"},
                "Z": {"condition_type": "Fixed"}
            },
            "rotation_conditions": {
                "X": {"condition_type": "Fixed"},
                "Y": {"condition_type": "Fixed"},
                "Z": {"condition_type": "StiffnessCurve", "stiffness_curve": [[0, 1e7], [100000, 1e8]]}
            }
        }],
        "settings": {
            "id": 1,
            "analysis_options": {
                "id": 1, "solve_loadcases": true, "solver": "Direct",
                "tolerance": 1e-9, "dimensionality": "3D",
                "order": "Linear", "max_iterations": 20,
                "rigid_strategy": "RigidMember", "axial_slack": 0.001,
                "include_shear_deformation": true, "include_warping": true
            },
            "general_info": {"project_name": "Test", "author": "Test", "version": "0.0.1"},
            "unit_settings": {"length_unit": "M", "force_unit": "N", "pressure_unit": "Pa"}
        }
    }"#;

    let result = calculate_from_json_internal(json_str);
    assert!(
        result.is_err(),
        "StiffnessCurve with Linear analysis should produce an error"
    );
    let err = result.unwrap_err();
    assert!(
        err.contains("StiffnessCurve") && err.contains("NonLinear"),
        "Error message should mention StiffnessCurve and NonLinear: got '{}'",
        err
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 130e — Validation errors for malformed curves
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_130e_curve_validation_errors() {
    use fers_calculations::functions::support_utils::validate_stiffness_curve;

    // Missing curve data
    let result = validate_stiffness_curve(1, "Z", &None);
    assert!(result.is_err(), "Missing curve should error");

    // Too few points
    let result = validate_stiffness_curve(1, "Z", &Some(vec![[0.0, 100.0]]));
    assert!(result.is_err(), "Single-point curve should error");

    // Negative stiffness
    let result = validate_stiffness_curve(1, "Z", &Some(vec![[0.0, -100.0], [10.0, 200.0]]));
    assert!(result.is_err(), "Negative stiffness should error");

    // Unsorted axial loads
    let result = validate_stiffness_curve(1, "Z", &Some(vec![[50.0, 100.0], [10.0, 200.0]]));
    assert!(result.is_err(), "Unsorted curve should error");

    // Valid curve
    let result = validate_stiffness_curve(1, "Z", &Some(vec![[0.0, 100.0], [50.0, 500.0]]));
    assert!(result.is_ok(), "Valid curve should not error");
}
