// src/functions/support_utils.rs
use std::collections::{BTreeMap, HashMap, HashSet};

use crate::functions::geometry::{compute_num_dofs_from_members, dof_index, DOFS_PER_NODE};
use crate::models::fers::fers::{FERS, ROTATION_AXES, TRANSLATION_AXES, WARPING_DOF_INDEX};
use crate::models::members::enums::MemberType;
use crate::models::members::memberset::MemberSet;
use crate::models::supports::nodalsupport::NodalSupport;
use crate::models::supports::supportcondition::SupportCondition;
use crate::models::supports::supportconditiontype::SupportConditionType;
use nalgebra::DMatrix;

pub fn visit_unique_supported_nodes<F>(
    member_sets: &[MemberSet],
    nodal_supports: &[NodalSupport],
    mut visitor: F,
) -> Result<(), String>
where
    F: FnMut(u32, usize, &NodalSupport) -> Result<(), String>,
{
    let support_by_id: HashMap<u32, &NodalSupport> =
        nodal_supports.iter().map(|s| (s.id, s)).collect();

    let mut seen: HashSet<u32> = HashSet::new();

    for member_set in member_sets {
        for member in &member_set.members {
            for node in [&member.start_node, &member.end_node] {
                if !seen.insert(node.id) {
                    continue;
                }
                if let Some(support_id) = node.nodal_support {
                    if let Some(support) = support_by_id.get(&support_id) {
                        let base_index = dof_index(node.id, 0);
                        visitor(node.id, base_index, support)?;
                    }
                }
            }
        }
    }
    Ok(())
}

pub fn detect_zero_energy_dofs(fers: &FERS) -> std::collections::HashSet<usize> {
    use std::collections::HashSet;
    use crate::models::settings::analysissettings::RigidStrategy;

    let number_of_dofs: usize = compute_num_dofs_from_members(&fers.member_sets);

    let mut has_stiffness = vec![false; number_of_dofs];
    let mut is_directly_constrained = vec![false; number_of_dofs];
    let mut is_directly_loaded = vec![false; number_of_dofs];

    // 1) Mark stiffness participation per element type
    for set in &fers.member_sets {
        for member in &set.members {
            let i0 = (member.start_node.id as usize - 1) * DOFS_PER_NODE;
            let j0 = (member.end_node.id as usize - 1) * DOFS_PER_NODE;

            match member.member_type {
                MemberType::Normal => {
                    for d in 0..DOFS_PER_NODE {
                        has_stiffness[i0 + d] = true;
                    }
                    for d in 0..DOFS_PER_NODE {
                        has_stiffness[j0 + d] = true;
                    }
                }
                // Truss/Tension/Compression: translations only, no rotations
                MemberType::Truss | MemberType::Tension | MemberType::Compression => {
                    for d in 0..3 {
                        has_stiffness[i0 + d] = true;
                    }
                    for d in 0..3 {
                        has_stiffness[j0 + d] = true;
                    }
                    // leave rotations false here
                }
                // Rigid: with RigidMember strategy, penalty stiffness is
                // assembled into K for all DOFs.  With LinearMpc strategy,
                // rigid members are handled by MPC constraints (S matrix)
                // and contribute no direct stiffness rows.
                MemberType::Rigid => {
                    if matches!(
                        fers.settings.analysis_options.rigid_strategy,
                        RigidStrategy::RigidMember
                    ) {
                        for d in 0..DOFS_PER_NODE {
                            has_stiffness[i0 + d] = true;
                        }
                        for d in 0..DOFS_PER_NODE {
                            has_stiffness[j0 + d] = true;
                        }
                    }
                }
            }
        }
    }

    let support_by_id: std::collections::HashMap<u32, &NodalSupport> =
        fers.nodal_supports.iter().map(|s| (s.id, s)).collect();

    for set in &fers.member_sets {
        for member in &set.members {
            for node in [&member.start_node, &member.end_node] {
                let base_full = (node.id as usize - 1) * DOFS_PER_NODE;

                if let Some(sup_id) = node.nodal_support {
                    if let Some(sup) = support_by_id.get(&sup_id) {
                        // Translations
                        for (axis_label, local_dof) in TRANSLATION_AXES {
                            if let Some(cond) =
                                sup.displacement_conditions.get(axis_label).or_else(|| {
                                    sup.displacement_conditions
                                        .get(&axis_label.to_ascii_lowercase())
                                })
                            {
                                let idx = base_full + local_dof;
                                // Fixed or explicit spring => keep
                                if matches!(cond.condition_type, SupportConditionType::Fixed)
                                    || matches!(cond.condition_type, SupportConditionType::StiffnessCurve)
                                    || cond.stiffness.unwrap_or(0.0) > 0.0
                                {
                                    is_directly_constrained[idx] = true;
                                }
                            }
                        }
                        // Rotations
                        for (axis_label, local_dof) in ROTATION_AXES {
                            if let Some(cond) =
                                sup.rotation_conditions.get(axis_label).or_else(|| {
                                    sup.rotation_conditions
                                        .get(&axis_label.to_ascii_lowercase())
                                })
                            {
                                let idx = base_full + local_dof;
                                if matches!(cond.condition_type, SupportConditionType::Fixed)
                                    || matches!(cond.condition_type, SupportConditionType::StiffnessCurve)
                                    || cond.stiffness.unwrap_or(0.0) > 0.0
                                {
                                    is_directly_constrained[idx] = true;
                                }
                            }
                        }
                        // Warping
                        if let Some(ref warp_cond) = sup.warping_condition {
                            let idx = base_full + WARPING_DOF_INDEX;
                            if matches!(warp_cond.condition_type, SupportConditionType::Fixed)
                                || warp_cond.stiffness.unwrap_or(0.0) > 0.0
                            {
                                is_directly_constrained[idx] = true;
                            }
                        }
                    }
                }
            }
        }
    }

    // 3) Mark direct nodal loads (forces map to translations, moments map to rotations)
    for lc in &fers.load_cases {
        for nl in &lc.nodal_loads {
            // direction is [dx, dy, dz] in your model => translations
            let base_full = (nl.node as usize - 1) * DOFS_PER_NODE;
            let direction_values = [nl.direction.0, nl.direction.1, nl.direction.2];
            for (comp, local_dof) in [(0usize, 0usize), (1usize, 1usize), (2usize, 2usize)] {
                if direction_values[comp].abs() != 0.0 && nl.magnitude.abs() > 0.0 {
                    is_directly_loaded[base_full + local_dof] = true;
                }
            }
            for nm in &lc.nodal_moments {
                // moments excite rotations
                let base_full = (nm.node as usize - 1) * DOFS_PER_NODE;
                let direction_values = [nm.direction.0, nm.direction.1, nm.direction.2];
                for (comp, local_dof) in [(0usize, 3usize), (1usize, 4usize), (2usize, 5usize)] {
                    if direction_values[comp].abs() != 0.0 && nm.magnitude.abs() > 0.0 {
                        is_directly_loaded[base_full + local_dof] = true;
                    }
                }
            }
        }
    }

    // 4) Decide zero-energy DOFs
    let mut zero_energy: HashSet<usize> = HashSet::new();
    for dof in 0..number_of_dofs {
        let has_any_stiffness = has_stiffness[dof];
        let constrained = is_directly_constrained[dof];
        let loaded = is_directly_loaded[dof];

        if !has_any_stiffness && !constrained && !loaded {
            zero_energy.insert(dof);
        }
    }

    zero_energy
}

/// Case-insensitive fetch of a support condition from a per-axis map.
pub fn get_support_condition<'a>(
    map: &'a BTreeMap<String, SupportCondition>,
    axis_label: &str,
) -> Option<&'a SupportCondition> {
    map.get(axis_label)
        .or_else(|| map.get(&axis_label.to_ascii_lowercase()))
}

pub fn add_support_springs_to_operator(
    member_sets: &[MemberSet],
    nodal_supports: &[NodalSupport],
    k_global: &mut DMatrix<f64>,
) -> Result<(), String> {
    add_support_springs_to_operator_with_axial(
        member_sets, nodal_supports, k_global, &HashMap::new(),
    )
}

/// Add support springs to a dense stiffness matrix, with optional axial-load lookup
/// for `StiffnessCurve` conditions.
pub fn add_support_springs_to_operator_with_axial(
    member_sets: &[MemberSet],
    nodal_supports: &[NodalSupport],
    k_global: &mut DMatrix<f64>,
    axial_loads: &HashMap<u32, f64>,
) -> Result<(), String> {
    visit_unique_supported_nodes(
        member_sets,
        nodal_supports,
        |node_id, base_index, support| {
            let fz = axial_loads.get(&node_id).copied();

            // Translational springs
            for (axis_label, local_dof) in TRANSLATION_AXES {
                if let Some(cond) =
                    get_support_condition(&support.displacement_conditions, axis_label)
                {
                    if let Some(k) =
                        resolve_spring_stiffness(cond, support.id, axis_label, "displacement", fz)?
                    {
                        k_global[(base_index + local_dof, base_index + local_dof)] += k;
                    }
                }
            }

            // Rotational springs
            for (axis_label, local_dof) in ROTATION_AXES {
                if let Some(cond) = get_support_condition(&support.rotation_conditions, axis_label)
                {
                    if let Some(k) =
                        resolve_spring_stiffness(cond, support.id, axis_label, "rotation", fz)?
                    {
                        k_global[(base_index + local_dof, base_index + local_dof)] += k;
                    }
                }
            }

            // Warping spring
            if let Some(ref warp_cond) = support.warping_condition {
                if let Some(k) =
                    resolve_spring_stiffness(warp_cond, support.id, "Warp", "warping", fz)?
                {
                    k_global[(base_index + WARPING_DOF_INDEX, base_index + WARPING_DOF_INDEX)] += k;
                }
            }

            Ok(())
        },
    )
}

/// Collect support spring entries as `(dof_index, stiffness)` pairs.
/// Used by the sparse assembly path where we cannot mutate a dense matrix.
/// For StiffnessCurve conditions, uses zero axial load (initial stiffness).
pub fn collect_support_spring_entries(
    member_sets: &[MemberSet],
    nodal_supports: &[NodalSupport],
) -> Result<Vec<(usize, f64)>, String> {
    collect_support_spring_entries_with_axial(member_sets, nodal_supports, &HashMap::new())
}

/// Validate stiffness option and return k > 0 (uniform error text).
pub fn spring_stiffness_or_error(
    owner_id: u32,
    axis_label: &str,
    kind_label: &str,
    stiffness: Option<f64>,
) -> Result<f64, String> {
    let k = stiffness.ok_or_else(|| {
        format!(
            "Support {} {} {} is Spring but stiffness is missing.",
            owner_id, kind_label, axis_label
        )
    })?;
    if k <= 0.0 {
        return Err(format!(
            "Support {} {} {} Spring stiffness must be positive.",
            owner_id, kind_label, axis_label
        ));
    }
    Ok(k)
}

/// Linearly interpolate a stiffness curve at the given axial load.
/// `curve` must have at least 2 points sorted by ascending axial load (column 0).
/// Values outside the curve range are clamped to the nearest boundary stiffness.
pub fn interpolate_stiffness_curve(curve: &[[f64; 2]], axial_load: f64) -> f64 {
    debug_assert!(curve.len() >= 2, "StiffnessCurve must have ≥2 points");

    // Clamp below
    if axial_load <= curve[0][0] {
        return curve[0][1];
    }
    // Clamp above
    if axial_load >= curve[curve.len() - 1][0] {
        return curve[curve.len() - 1][1];
    }
    // Linear interpolation between bracketing points
    for i in 0..curve.len() - 1 {
        let (x0, y0) = (curve[i][0], curve[i][1]);
        let (x1, y1) = (curve[i + 1][0], curve[i + 1][1]);
        if axial_load >= x0 && axial_load <= x1 {
            let t = (axial_load - x0) / (x1 - x0);
            return y0 + t * (y1 - y0);
        }
    }
    // Fallback (should not reach here with sorted data)
    curve[curve.len() - 1][1]
}

/// Validate a stiffness curve and return a descriptive error if invalid.
pub fn validate_stiffness_curve(
    owner_id: u32,
    axis_label: &str,
    curve: &Option<Vec<[f64; 2]>>,
) -> Result<(), String> {
    let points = curve.as_ref().ok_or_else(|| {
        format!(
            "Support {} rotation {} is StiffnessCurve but stiffness_curve data is missing.",
            owner_id, axis_label
        )
    })?;
    if points.len() < 2 {
        return Err(format!(
            "Support {} rotation {} StiffnessCurve must have at least 2 points (got {}).",
            owner_id, axis_label, points.len()
        ));
    }
    for (i, pt) in points.iter().enumerate() {
        if pt[1] <= 0.0 {
            return Err(format!(
                "Support {} rotation {} StiffnessCurve point {} has non-positive stiffness ({}).",
                owner_id, axis_label, i, pt[1]
            ));
        }
    }
    for i in 1..points.len() {
        if points[i][0] < points[i - 1][0] {
            return Err(format!(
                "Support {} rotation {} StiffnessCurve points must be sorted by ascending axial load \
                 (point {} axial_load={} < point {} axial_load={}).",
                owner_id, axis_label, i, points[i][0], i - 1, points[i - 1][0]
            ));
        }
    }
    Ok(())
}

/// Resolve the effective spring stiffness for a support condition, handling both
/// constant `Spring` and load-dependent `StiffnessCurve` types.
fn resolve_spring_stiffness(
    cond: &SupportCondition,
    owner_id: u32,
    axis_label: &str,
    kind_label: &str,
    axial_load: Option<f64>,
) -> Result<Option<f64>, String> {
    match cond.condition_type {
        SupportConditionType::Spring => {
            let k = spring_stiffness_or_error(owner_id, axis_label, kind_label, cond.stiffness)?;
            Ok(Some(k))
        }
        SupportConditionType::StiffnessCurve => {
            validate_stiffness_curve(owner_id, axis_label, &cond.stiffness_curve)?;
            let fz = axial_load.unwrap_or(0.0);
            let k = interpolate_stiffness_curve(cond.stiffness_curve.as_ref().unwrap(), fz);
            Ok(Some(k))
        }
        _ => Ok(None),
    }
}

/// Collect support spring entries as `(dof_index, stiffness)` pairs, with
/// optional axial-load lookup for `StiffnessCurve` conditions.
/// `axial_loads` maps node_id → Fz reaction force (only needed if model has StiffnessCurve supports).
pub fn collect_support_spring_entries_with_axial(
    member_sets: &[MemberSet],
    nodal_supports: &[NodalSupport],
    axial_loads: &HashMap<u32, f64>,
) -> Result<Vec<(usize, f64)>, String> {
    let mut entries: Vec<(usize, f64)> = Vec::new();

    visit_unique_supported_nodes(
        member_sets,
        nodal_supports,
        |node_id, base_index, support| {
            let fz = axial_loads.get(&node_id).copied();

            for (axis_label, local_dof) in TRANSLATION_AXES {
                if let Some(cond) =
                    get_support_condition(&support.displacement_conditions, axis_label)
                {
                    if let Some(k) =
                        resolve_spring_stiffness(cond, support.id, axis_label, "displacement", fz)?
                    {
                        entries.push((base_index + local_dof, k));
                    }
                }
            }
            for (axis_label, local_dof) in ROTATION_AXES {
                if let Some(cond) =
                    get_support_condition(&support.rotation_conditions, axis_label)
                {
                    if let Some(k) =
                        resolve_spring_stiffness(cond, support.id, axis_label, "rotation", fz)?
                    {
                        entries.push((base_index + local_dof, k));
                    }
                }
            }
            if let Some(ref warp_cond) = support.warping_condition {
                if let Some(k) =
                    resolve_spring_stiffness(warp_cond, support.id, "Warp", "warping", fz)?
                {
                    entries.push((base_index + WARPING_DOF_INDEX, k));
                }
            }
            Ok(())
        },
    )?;

    Ok(entries)
}

/// Returns true if any nodal support uses a `StiffnessCurve` condition.
pub fn has_stiffness_curves(nodal_supports: &[NodalSupport]) -> bool {
    nodal_supports.iter().any(|sup| {
        sup.rotation_conditions.values().any(|c| {
            matches!(c.condition_type, SupportConditionType::StiffnessCurve)
        })
    })
}

/// Strong Dirichlet on a single DOF.
pub fn constrain_single_dof(
    k: &mut DMatrix<f64>,
    rhs: &mut DMatrix<f64>,
    dof_index: usize,
    prescribed: f64,
) {
    for j in 0..k.ncols() {
        k[(dof_index, j)] = 0.0;
    }
    for i in 0..k.nrows() {
        k[(i, dof_index)] = 0.0;
    }
    k[(dof_index, dof_index)] = 1.0;
    rhs[(dof_index, 0)] = prescribed;
}
