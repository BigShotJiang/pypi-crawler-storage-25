use crate::functions::hinge_and_release_operations::{
    apply_end_releases_to_local_beam_k, modes_from_single_ends,
};
use crate::models::members::member::Member;
use crate::models::members::memberhinge::MemberHinge;
use nalgebra::DMatrix;
use std::collections::HashMap;

// src/functions/geometry.rs
use crate::models::members::memberset::MemberSet;

/// Number of degrees of freedom per node: ux, uy, uz, rx, ry, rz, warping.
pub const DOFS_PER_NODE: usize = 7;
/// Number of DOFs per beam element (2 nodes).
pub const ELEMENT_DOFS: usize = DOFS_PER_NODE * 2;

/// Returns the seven degrees of freedom indices for the given node.
/// The first three are translational (X, Y, Z), next three rotational (RX, RY, RZ),
/// and the last is the warping DOF.
pub fn get_dof_indices(node_id: usize) -> (usize, usize, usize, usize, usize, usize, usize) {
    let base_index = (node_id - 1) * DOFS_PER_NODE;
    (
        base_index,     // X translation
        base_index + 1, // Y translation
        base_index + 2, // Z translation
        base_index + 3, // X rotation
        base_index + 4, // Y rotation
        base_index + 5, // Z rotation
        base_index + 6, // Warping
    )
}

pub fn dof_index(node_id: u32, local_dof: usize) -> usize {
    (node_id as usize - 1) * DOFS_PER_NODE + local_dof
}

pub fn compute_num_dofs_from_members(member_sets: &[MemberSet]) -> usize {
    let max_node = member_sets
        .iter()
        .flat_map(|ms| ms.members.iter())
        .flat_map(|m| [m.start_node.id, m.end_node.id])
        .max()
        .unwrap_or(0) as usize;
    max_node * DOFS_PER_NODE
}

pub fn local_to_global_with_releases(
    member: &Member,
    k_local_base: &DMatrix<f64>,
    hinge_by_id: &HashMap<u32, &MemberHinge>,
    displacement: Option<&DMatrix<f64>>,
) -> Result<DMatrix<f64>, String> {
    let a_h = member
        .start_hinge
        .and_then(|id| hinge_by_id.get(&id).copied());
    let b_h = member
        .end_hinge
        .and_then(|id| hinge_by_id.get(&id).copied());
    let (a_trans, a_rot, b_trans, b_rot, a_warp, b_warp) = modes_from_single_ends(a_h, b_h);

    let k_local_mod =
        apply_end_releases_to_local_beam_k(k_local_base, a_trans, a_rot, b_trans, b_rot, a_warp, b_warp)?;

    let t = if let Some(u) = displacement {
        let (sp, ep) = member.deformed_positions(u);
        member.calculate_transformation_matrix_3d_from_positions(&sp, &ep)
    } else {
        member.calculate_transformation_matrix_3d()
    };
    Ok(t.transpose() * k_local_mod * t)
}
