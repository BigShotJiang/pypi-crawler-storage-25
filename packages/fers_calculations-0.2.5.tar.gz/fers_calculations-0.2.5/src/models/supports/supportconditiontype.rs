use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Debug, Serialize, Deserialize, Clone, ToSchema)]
pub enum SupportConditionType {
    Fixed,
    Free,
    Spring,
    PositiveOnly,
    NegativeOnly,
    /// Rotational spring whose stiffness varies with axial load (Fz reaction).
    /// Requires NonLinear analysis order.
    StiffnessCurve,
}
