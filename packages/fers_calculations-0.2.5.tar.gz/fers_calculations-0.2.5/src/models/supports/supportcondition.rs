use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

use crate::models::supports::supportconditiontype::SupportConditionType;

#[derive(Debug, Serialize, Deserialize, ToSchema, Clone)]
pub struct SupportCondition {
    pub condition_type: SupportConditionType,
    pub stiffness: Option<f64>,
    /// Stiffness curve: array of [axial_load, rotational_stiffness] pairs.
    /// Used only with `StiffnessCurve` condition_type. Points must be sorted
    /// by ascending axial load. Linearly interpolated, clamped at boundaries.
    #[serde(default)]
    pub stiffness_curve: Option<Vec<[f64; 2]>>,
}

impl SupportCondition {
    pub fn normalize_translation_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f / l;
        }
    }

    pub fn normalize_rotation_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f * l;
        }
        // Also normalize stiffness curve values (rotational stiffness is [F·L/rad])
        if let Some(ref mut curve) = self.stiffness_curve {
            for point in curve.iter_mut() {
                point[0] *= f; // axial load: [F]
                point[1] *= f * l; // rotational stiffness: [F·L/rad]
            }
        }
    }

    pub fn normalize_warping_units(&mut self, f: f64, l: f64) {
        if let Some(k) = &mut self.stiffness {
            *k *= f * l * l; // warping spring: [F·L²/rad]
        }
    }
}
