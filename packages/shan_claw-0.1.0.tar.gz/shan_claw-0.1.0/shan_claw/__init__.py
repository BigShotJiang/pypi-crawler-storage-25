"""Shan Claw autonomous QA prototype package."""

__version__ = "0.1.0"
