use crate::windows::constants;
use crate::emu;

pub fn BaseDllReadWriteIniFile(emu: &mut emu::Emu) {
    let _a1 = emu
        .maps
        .read_dword(emu.regs().get_esp())
        .expect("cannot read the api parameter");
    let _a2 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 4)
        .expect("cannot read the api parameter");
    let _a3 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 8)
        .expect("cannot read the api parameter");
    let _lpFileName = emu
        .maps
        .read_dword(emu.regs().get_esp() + 12)
        .expect("cannot read the api parameter");
    let _a5 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 16)
        .expect("cannot read the api parameter");
    let _a6 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 20)
        .expect("cannot read the api parameter");
    let _a7 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 24)
        .expect("cannot read the api parameter");
    let _a8 = emu
        .maps
        .read_dword(emu.regs().get_esp() + 28)
        .expect("cannot read the api parameter");

    log_red!(emu, "kernel32!BaseDllReadWriteIniFile");

    emu.regs_mut().rax = constants::ERROR_SUCCESS;

    for _ in 0..8 {
        emu.stack_pop32(false);
    }
}
