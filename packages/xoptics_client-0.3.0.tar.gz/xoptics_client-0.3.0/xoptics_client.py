"""xoptics remote simulation client.

Submit XML scenes to the xoptics API, stream stdout in real time, get h5 results.

Quick start:
    from xoptics_client import Client
    c = Client(api_key="sk_...")            # or set XOPTICS_API_KEY env var
    result = c.run(xml=open("scene.xml").read(), cores=64)
    arr = result.detector("eyebox_g").to_array()

Monitor + cancel:
    c.print_usage()                          # your current cores + running jobs
    c.get_job("abc123").cancel()             # cancel a specific job
"""
import os
import time
import tempfile
from pathlib import Path
from typing import Optional, Callable, List

import httpx


__version__ = "0.3.0"
DEFAULT_BASE_URL = "https://api.xoptics.org"
USER_AGENT = f"xoptics-client/{__version__}"


class XopticsError(Exception):
    """Base error."""


class AuthError(XopticsError):
    """401 / 403."""


class JobFailedError(XopticsError):
    """xTracerCL exited non-zero or job errored."""


# =========================================================================
# Client
# =========================================================================

class Client:
    """Main entry point for the xoptics API."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("XOPTICS_API_KEY")
        if not self.api_key:
            raise AuthError(
                "No API key. Pass api_key=... or set XOPTICS_API_KEY env var."
            )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._http = httpx.Client(
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "User-Agent": USER_AGENT,
            },
            timeout=timeout,
        )

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    # ---- core ----

    def submit(
        self, xml: str, cores: int = 32, label: Optional[str] = None
    ) -> "Job":
        """Submit a job. Returns Job handle immediately."""
        resp = self._http.post(
            f"{self.base_url}/v1/jobs",
            json={"xml": xml, "cores": cores, "label": label},
        )
        self._check(resp)
        return Job(self, resp.json())

    def run(
        self,
        xml: str,
        cores: int = 32,
        label: Optional[str] = None,
        on_log: Optional[Callable[[str], None]] = print,
    ) -> "Result":
        """Submit + stream stdout + block until done. Returns Result.

        ``on_log(line)`` is called for each stdout line in real time.
        Pass ``on_log=None`` to suppress.
        """
        job = self.submit(xml=xml, cores=cores, label=label)
        if on_log:
            on_log(f"[xoptics] Job {job.id} submitted (cores={cores})")
        job.wait(on_log=on_log)
        if job.status != "done":
            raise JobFailedError(f"Job {job.id} ended as {job.status}: {job.error}")
        return job.result()

    def get_job(self, job_id: str) -> "Job":
        resp = self._http.get(f"{self.base_url}/v1/jobs/{job_id}")
        self._check(resp)
        return Job(self, resp.json())

    def jobs(self, limit: int = 50) -> List["Job"]:
        """List your jobs, newest first."""
        resp = self._http.get(
            f"{self.base_url}/v1/jobs", params={"limit": limit}
        )
        self._check(resp)
        return [Job(self, d) for d in resp.json()]

    def cancel_job(self, job_id: str) -> "Job":
        """Cancel a pending or running job by id. Returns updated Job."""
        resp = self._http.delete(f"{self.base_url}/v1/jobs/{job_id}")
        self._check(resp)
        return Job(self, resp.json())

    # ---- monitoring ----

    def usage(self) -> dict:
        """Your own usage snapshot: cores_in_use, lifetime CPU-hours, running jobs."""
        resp = self._http.get(f"{self.base_url}/v1/usage")
        self._check(resp)
        return resp.json()

    def print_usage(self):
        u = self.usage()
        _print_user(u, indent="")

    def server_status(self) -> dict:
        """Global cluster snapshot — any user can call.

        Returns server-wide cores total/in-use/free and a per-user-id core count.
        Other users' job labels / job ids are NOT included (admin sees those via
        fleet_usage()).
        """
        resp = self._http.get(f"{self.base_url}/v1/server_status")
        self._check(resp)
        return resp.json()

    def print_server_status(self):
        s = self.server_status()
        sv = s["server"]
        bar_unit = max(1, sv["total_cores"] // 40)   # ~40-char bar at full
        print(f"server cores: {sv['cores_in_use']}/{sv['total_cores']} in use  "
              f"({sv['cores_free']} free)")
        print("-" * 60)
        if not s["users"]:
            print("  (no users)")
            return
        for u in s["users"]:
            bar = "█" * (u["cores_in_use"] // bar_unit) if u["cores_in_use"] else ""
            jobs = u["running_jobs_count"]
            jobs_str = f"{jobs} job{'s' if jobs != 1 else ''}" if jobs else "idle"
            print(f"  {u['user_id']:14s} {u['cores_in_use']:>4} cores  "
                  f"{jobs_str:>8s}   {bar}")

    def fleet_usage(self) -> dict:
        """Admin only: every user's usage + server totals + running-job details."""
        resp = self._http.get(f"{self.base_url}/admin/usage")
        self._check(resp)
        return resp.json()

    def print_fleet_usage(self):
        f = self.fleet_usage()
        s = f["server"]
        print(f"server cores: {s['total_cores']} total | "
              f"{s['cores_in_use']} in use | {s['cores_free']} free")
        print("-" * 72)
        for u in f["users"]:
            _print_user(u, indent="")
            print()

    # ---- internal ----

    def _check(self, resp: httpx.Response):
        if resp.status_code == 401:
            raise AuthError("401 — invalid or missing API key")
        if resp.status_code == 403:
            raise AuthError("403 — forbidden (admin-only endpoint?)")
        resp.raise_for_status()


def _print_user(u: dict, indent: str = ""):
    """Pretty-print one user's usage block."""
    head = f"{u['user_id']}"
    if u.get("name") and u["name"] != u["user_id"]:
        head += f" ({u['name']})"
    if u.get("key_mask"):
        head += f"  [{u['key_mask']}]"
    if u.get("role") and u["role"] != "user":
        head += f"  role={u['role']}"
    print(indent + head)
    print(indent + f"  cores in use:      {u['cores_in_use']}")
    print(indent + f"  lifetime CPU-hrs:  {u['lifetime_cpu_hours']:.3f}")
    rj = u.get("running_jobs", [])
    if not rj:
        print(indent + "  running jobs:      (none)")
        return
    print(indent + f"  running jobs:      {len(rj)}")
    for j in rj:
        pct = j.get("progress_percent")
        pct_str = f"{pct:5.1f}%" if pct is not None else "  ?  %"
        rem = j.get("remaining") or "  --  "
        ela = j.get("elapsed") or "  --  "
        lbl = j.get("label") or ""
        print(indent + f"    {j['job_id']}  cores={j['cores']:>3}  "
              f"{pct_str}  elapsed={ela}  remaining={rem}  {lbl!r}")


# =========================================================================
# Job handle
# =========================================================================

class Job:
    """Handle to a remote job."""

    def __init__(self, client: Client, data: dict):
        self._client = client
        self._update(data)

    def _update(self, data: dict):
        self.id: str = data["id"]
        self.status: str = data["status"]
        self.label: Optional[str] = data.get("label")
        self.cores: int = data["cores"]
        self.created_at: str = data["created_at"]
        self.started_at: Optional[str] = data.get("started_at")
        self.finished_at: Optional[str] = data.get("finished_at")
        self.elapsed_sec: Optional[float] = data.get("elapsed_sec")
        self.error: Optional[str] = data.get("error")
        self.user_id: Optional[str] = data.get("user_id")

    def refresh(self) -> "Job":
        resp = self._client._http.get(
            f"{self._client.base_url}/v1/jobs/{self.id}"
        )
        self._client._check(resp)
        self._update(resp.json())
        return self

    def wait(
        self,
        on_log: Optional[Callable[[str], None]] = None,
        timeout: Optional[float] = None,
        poll_interval: float = 2.0,
    ) -> "Job":
        """Block until job finishes.

        With ``on_log`` set, uses SSE stream — every stdout line is forwarded
        in real time. Without, polls status every ``poll_interval`` seconds.
        """
        if on_log is None:
            deadline = time.time() + timeout if timeout else None
            while True:
                self.refresh()
                if self.status in ("done", "failed", "cancelled"):
                    return self
                if deadline and time.time() > deadline:
                    raise TimeoutError(
                        f"Job {self.id} did not finish within {timeout}s"
                    )
                time.sleep(poll_interval)
        else:
            url = f"{self._client.base_url}/v1/jobs/{self.id}/stream"
            with self._client._http.stream("GET", url, timeout=None) as r:
                self._client._check(r)
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    if raw.startswith("data: "):
                        line = raw[6:]
                        if line in ("running", "pending", "done", "failed", "cancelled"):
                            continue
                        on_log(line)
                    elif raw.startswith("event: end"):
                        break
            self.refresh()
            return self

    def cancel(self) -> "Job":
        """Cancel this job (sends SIGTERM to xTracerCL)."""
        resp = self._client._http.delete(
            f"{self._client.base_url}/v1/jobs/{self.id}"
        )
        self._client._check(resp)
        self._update(resp.json())
        return self

    def log(self, tail: Optional[int] = None) -> str:
        params = {"tail": tail} if tail else {}
        resp = self._client._http.get(
            f"{self._client.base_url}/v1/jobs/{self.id}/log",
            params=params,
        )
        self._client._check(resp)
        return resp.text

    def result(self) -> "Result":
        """Download h5 (cached locally) and return Result."""
        if self.status != "done":
            raise JobFailedError(
                f"Job {self.id} is {self.status}, no result available"
            )
        url = f"{self._client.base_url}/v1/jobs/{self.id}/result"
        cache_dir = Path(tempfile.gettempdir()) / "xoptics-client"
        cache_dir.mkdir(exist_ok=True)
        h5_path = cache_dir / f"{self.id}.h5"
        if not h5_path.exists():
            with self._client._http.stream("GET", url, timeout=None) as r:
                self._client._check(r)
                with open(h5_path, "wb") as f:
                    for chunk in r.iter_bytes(chunk_size=64 * 1024):
                        f.write(chunk)
        return Result(self.id, h5_path)

    def __repr__(self):
        return f"<Job {self.id} status={self.status} label={self.label!r}>"


# =========================================================================
# Result + DetectorResult
# =========================================================================

class Result:
    """Local cached h5 file from a finished job."""

    def __init__(self, job_id: str, h5_path: Path):
        self.job_id = job_id
        self.h5_path = Path(h5_path)
        self._h5 = None

    @property
    def h5(self):
        if self._h5 is None:
            import h5py
            self._h5 = h5py.File(self.h5_path, "r")
        return self._h5

    def detectors(self) -> List[str]:
        return [k for k in self.h5.keys() if hasattr(self.h5[k], "shape")]

    def detector(self, name: str) -> "DetectorResult":
        if name not in self.h5:
            raise KeyError(
                f"Detector {name!r} not in result. Available: {self.detectors()}"
            )
        return DetectorResult(name, self.h5[name])

    def save(self, path) -> Path:
        import shutil
        path = Path(path)
        shutil.copy(self.h5_path, path)
        return path

    def close(self):
        if self._h5 is not None:
            self._h5.close()
            self._h5 = None

    def __repr__(self):
        return f"<Result job={self.job_id} datasets={len(self.detectors())}>"


class DetectorResult:
    """Single-detector view."""

    def __init__(self, name: str, h5_dataset):
        self.name = name
        self._ds = h5_dataset
        self.shape = h5_dataset.shape
        self.dtype = h5_dataset.dtype

    def to_array(self):
        import numpy as np
        return np.asarray(self._ds)

    def to_dataframe(self):
        import pandas as pd
        arr = self.to_array()
        if arr.ndim == 2:
            return pd.DataFrame(arr)
        return pd.DataFrame({"value": arr.ravel()})

    def __repr__(self):
        return f"<DetectorResult {self.name} shape={self.shape}>"
