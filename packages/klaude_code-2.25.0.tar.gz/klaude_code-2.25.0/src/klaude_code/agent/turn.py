from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from klaude_code.agent.handoff import HandoffManager
from klaude_code.agent.rewind import RewindManager
from klaude_code.const import (
    FIRST_TOKEN_TIMEOUT_NO_RETRY_INPUT_TOKENS,
    LLM_FIRST_TOKEN_TIMEOUT_S,
    RETRY_PRESERVE_PARTIAL_MESSAGE,
)
from klaude_code.tool import ToolABC
from klaude_code.tool.context import ToolContext

if TYPE_CHECKING:
    from klaude_code.agent.task import SessionContext

from klaude_code.llm import LLMClientABC
from klaude_code.llm.client import LLMStreamABC
from klaude_code.log import DebugType, log_debug
from klaude_code.protocol import events, llm_param, message, model
from klaude_code.tool.tool_runner import (
    ToolCallRequest,
    ToolExecutionCallStarted,
    ToolExecutionOutputDelta,
    ToolExecutionResult,
    ToolExecutionTodoChange,
    ToolExecutor,
    ToolExecutorEvent,
)


class TurnError(Exception):
    """Raised when a turn fails and should be retried."""

    pass


@dataclass
class TurnExecutionContext:
    """Execution context required to run a single turn."""

    session_ctx: SessionContext
    llm_client: LLMClientABC
    system_prompt: str | None
    tools: list[llm_param.ToolSchema]
    tool_registry: dict[str, type[ToolABC]]
    sub_agent_state: model.SubAgentState | None = None
    rewind_manager: RewindManager | None = None
    handoff_manager: HandoffManager | None = None
    prev_turn_input_tokens: int = 0


@dataclass
class TurnResult:
    """Aggregated state produced while executing a turn."""

    assistant_message: message.AssistantMessage | None
    tool_calls: list[ToolCallRequest]
    stream_error: message.StreamErrorItem | None
    continue_agent: bool = field(default=True)


def _build_continuation_prompt(partial_text: str) -> str:
    return (
        "<assistant>\n"
        f"{partial_text}\n"
        "</assistant>\n\n"
        "<system-reminder>"
        "Your previous response was interrupted due to a transient error "
        "(often network-related). "
        "Please continue from where it left off without repeating content you've already provided."
        "</system-reminder>"
    )


def build_events_from_tool_executor_event(session_id: str, event: ToolExecutorEvent) -> list[events.Event]:
    """Translate internal tool executor events into public protocol events."""

    ui_events: list[events.Event] = []

    match event:
        case ToolExecutionCallStarted(tool_call=tool_call):
            ui_events.append(
                events.ToolCallEvent(
                    session_id=session_id,
                    response_id=tool_call.response_id,
                    tool_call_id=tool_call.call_id,
                    tool_name=tool_call.tool_name,
                    arguments=tool_call.arguments_json,
                )
            )
        case ToolExecutionResult(tool_call=tool_call, tool_result=tool_result, is_last_in_turn=is_last_in_turn):
            ui_events.append(
                events.ToolResultEvent(
                    session_id=session_id,
                    response_id=tool_call.response_id,
                    tool_call_id=tool_call.call_id,
                    tool_name=tool_call.tool_name,
                    result=tool_result.output_text,
                    ui_extra=tool_result.ui_extra,
                    status=tool_result.status,
                    task_metadata=tool_result.task_metadata,
                    is_last_in_turn=is_last_in_turn,
                )
            )
        case ToolExecutionOutputDelta(tool_call=tool_call, content=content):
            ui_events.append(
                events.ToolOutputDeltaEvent(
                    session_id=session_id,
                    response_id=tool_call.response_id,
                    tool_call_id=tool_call.call_id,
                    tool_name=tool_call.tool_name,
                    content=content,
                )
            )
        case ToolExecutionTodoChange(todos=todos):
            ui_events.append(
                events.TodoChangeEvent(
                    session_id=session_id,
                    todos=todos,
                )
            )

    return ui_events


class TurnExecutor:
    """Executes a single model turn including tool calls.

    Manages the lifecycle of tool execution and tool context internally.
    Raises TurnError on failure.
    """

    def __init__(self, context: TurnExecutionContext) -> None:
        self._context = context
        self._tool_executor: ToolExecutor | None = None
        self._turn_result: TurnResult | None = None
        self._llm_stream: LLMStreamABC | None = None
        self._accumulated_assistant_text: list[str] = []

    @property
    def task_finished(self) -> bool:
        """Check if this turn indicates the task should end."""
        if self._turn_result is None:
            return True
        if not self._turn_result.continue_agent:
            return True
        return not self._turn_result.tool_calls

    @property
    def task_result(self) -> str:
        """Get the task result from this turn."""
        if self._turn_result is not None and self._turn_result.assistant_message is not None:
            assistant_message = self._turn_result.assistant_message
            return message.join_text_parts(assistant_message.parts)
        return ""

    @property
    def continue_agent(self) -> bool:
        if self._turn_result is None:
            return True
        return self._turn_result.continue_agent

    def on_interrupt(self) -> list[events.Event]:
        """Handle an interrupt by persisting partial output and finalizing running tools.

        This method emits best-effort UI/history events, but it does not cancel
        the outer asyncio task.
        """
        ui_events: list[events.Event] = []
        if self._tool_executor is not None:
            for exec_event in self._tool_executor.on_interrupt():
                for ui_event in build_events_from_tool_executor_event(self._context.session_ctx.session_id, exec_event):
                    ui_events.append(ui_event)
            self._tool_executor = None
        self._persist_continuation_prompt_on_interrupt()
        return ui_events

    async def run(self) -> AsyncGenerator[events.Event]:
        """Execute the turn, yielding events as they occur.

        Raises:
            TurnError: If the turn fails (stream error or non-completed status).
        """
        ctx = self._context
        session_ctx = ctx.session_ctx

        yield events.TurnStartEvent(session_id=session_ctx.session_id)

        self._turn_result = TurnResult(
            assistant_message=None,
            tool_calls=[],
            stream_error=None,
        )

        async for event in self._consume_llm_stream(self._turn_result):
            yield event

        if self._turn_result.stream_error is not None:
            # Save stream error and partial output for retry continuation.
            session_ctx.append_history([self._turn_result.stream_error])
            if RETRY_PRESERVE_PARTIAL_MESSAGE:
                partial_text = "".join(self._accumulated_assistant_text).strip()
                if partial_text:
                    continuation_prompt = _build_continuation_prompt(partial_text)
                    session_ctx.append_history(
                        [message.UserMessage(parts=[message.TextPart(text=continuation_prompt)])]
                    )
            yield events.TurnEndEvent(session_id=session_ctx.session_id)
            raise TurnError(self._turn_result.stream_error.error)

        self._append_success_history(self._turn_result)

        if self._turn_result.tool_calls:
            async for ui_event in self._run_tool_executor(self._turn_result.tool_calls):
                yield ui_event

        yield events.TurnEndEvent(session_id=session_ctx.session_id)

    async def _consume_llm_stream(self, turn_result: TurnResult) -> AsyncGenerator[events.Event]:
        """Stream events from LLM and update turn_result in place."""

        ctx = self._context
        session_ctx = ctx.session_ctx
        thinking_active = False
        assistant_text_active = False
        message_types = (
            message.SystemMessage,
            message.DeveloperMessage,
            message.UserMessage,
            message.AssistantMessage,
            message.ToolResultMessage,
        )
        messages = [item for item in session_ctx.get_conversation_history() if isinstance(item, message_types)]
        call_param = llm_param.LLMCallParameter(
            input=messages,
            system=ctx.system_prompt,
            tools=ctx.tools,
            session_id=session_ctx.session_id,
        )

        self._llm_stream = await ctx.llm_client.call(call_param)
        first_effective_token_received = False
        try:
            stream_iter = self._llm_stream.__aiter__()
            while True:
                try:
                    if first_effective_token_received:
                        delta = await anext(stream_iter)
                    elif ctx.prev_turn_input_tokens >= FIRST_TOKEN_TIMEOUT_NO_RETRY_INPUT_TOKENS:
                        # Large context: skip first-token timeout since slow processing is expected
                        delta = await anext(stream_iter)
                    else:
                        delta = await asyncio.wait_for(anext(stream_iter), timeout=LLM_FIRST_TOKEN_TIMEOUT_S)
                except StopAsyncIteration:
                    break
                except TimeoutError:
                    turn_result.stream_error = message.StreamErrorItem(
                        error=f"First token timeout after {LLM_FIRST_TOKEN_TIMEOUT_S:.1f}s"
                    )
                    break

                log_debug(
                    f"[{delta.__class__.__name__}]",
                    delta.model_dump_json(exclude_none=True),
                    debug_type=DebugType.RESPONSE,
                )
                match delta:
                    case message.ThinkingTextDelta() as delta:
                        if delta.content:
                            first_effective_token_received = True
                        if not thinking_active:
                            thinking_active = True
                            yield events.ThinkingStartEvent(
                                response_id=delta.response_id,
                                session_id=session_ctx.session_id,
                            )
                        yield events.ThinkingDeltaEvent(
                            content=delta.content,
                            response_id=delta.response_id,
                            session_id=session_ctx.session_id,
                        )
                    case message.AssistantTextDelta() as delta:
                        if delta.content:
                            first_effective_token_received = True
                            self._accumulated_assistant_text.append(delta.content)
                        if thinking_active:
                            thinking_active = False
                            yield events.ThinkingEndEvent(
                                response_id=delta.response_id,
                                session_id=session_ctx.session_id,
                            )
                        if not assistant_text_active:
                            assistant_text_active = True
                            yield events.AssistantTextStartEvent(
                                response_id=delta.response_id,
                                session_id=session_ctx.session_id,
                            )
                        yield events.AssistantTextDeltaEvent(
                            content=delta.content,
                            response_id=delta.response_id,
                            session_id=session_ctx.session_id,
                        )
                    case message.AssistantMessage() as msg:
                        if msg.parts:
                            first_effective_token_received = True
                        if thinking_active:
                            thinking_active = False
                            yield events.ThinkingEndEvent(
                                response_id=msg.response_id,
                                session_id=session_ctx.session_id,
                            )
                        if assistant_text_active:
                            assistant_text_active = False
                            yield events.AssistantTextEndEvent(
                                response_id=msg.response_id,
                                session_id=session_ctx.session_id,
                            )
                        turn_result.assistant_message = msg
                        for part in msg.parts:
                            if isinstance(part, message.ToolCallPart):
                                turn_result.tool_calls.append(
                                    ToolCallRequest(
                                        response_id=msg.response_id,
                                        call_id=part.call_id,
                                        tool_name=part.tool_name,
                                        arguments_json=part.arguments_json,
                                    )
                                )
                        if msg.stop_reason != "aborted":
                            thinking_text = "".join(
                                part.text for part in msg.parts if isinstance(part, message.ThinkingTextPart)
                            )
                            yield events.ResponseCompleteEvent(
                                content=message.join_text_parts(msg.parts),
                                response_id=msg.response_id,
                                session_id=session_ctx.session_id,
                                thinking_text=thinking_text or None,
                            )
                        if msg.stop_reason == "aborted":
                            yield events.InterruptEvent(session_id=session_ctx.session_id)
                        if msg.usage:
                            metadata = msg.usage
                            if metadata.response_id is None:
                                metadata.response_id = msg.response_id
                            if not metadata.model_name:
                                metadata.model_name = ctx.llm_client.model_name
                            if metadata.provider is None:
                                metadata.provider = ctx.llm_client.get_llm_config().provider_name or None
                            yield events.UsageEvent(
                                session_id=session_ctx.session_id,
                                usage=metadata,
                            )
                    case message.StreamErrorItem() as msg:
                        log_debug(msg.error, debug_type=DebugType.LLM_STREAM)
                        turn_result.stream_error = msg
                    case message.ToolCallStartDelta() as msg:
                        first_effective_token_received = True
                        if thinking_active:
                            thinking_active = False
                            yield events.ThinkingEndEvent(
                                response_id=msg.response_id,
                                session_id=session_ctx.session_id,
                            )
                        if assistant_text_active:
                            assistant_text_active = False
                            yield events.AssistantTextEndEvent(
                                response_id=msg.response_id,
                                session_id=session_ctx.session_id,
                            )
                        yield events.ToolCallStartEvent(
                            session_id=session_ctx.session_id,
                            response_id=msg.response_id,
                            tool_call_id=msg.call_id,
                            tool_name=msg.name,
                        )
                    case _:
                        continue
        finally:
            self._llm_stream = None

    def _append_success_history(self, turn_result: TurnResult) -> None:
        """Persist successful turn artifacts to conversation history."""
        session_ctx = self._context.session_ctx
        if turn_result.assistant_message:
            session_ctx.append_history([turn_result.assistant_message])

    async def _run_tool_executor(self, tool_calls: list[ToolCallRequest]) -> AsyncGenerator[events.Event]:
        """Run tools for the turn and translate executor events to UI events."""

        ctx = self._context
        session_ctx = ctx.session_ctx
        tool_context = ToolContext(
            file_tracker=session_ctx.file_tracker,
            todo_context=session_ctx.todo_context,
            session_id=session_ctx.session_id,
            work_dir=session_ctx.work_dir,
            file_change_summary=session_ctx.file_change_summary,
            run_subtask=session_ctx.run_subtask,
            rewind_manager=ctx.rewind_manager,
            handoff_manager=ctx.handoff_manager,
            request_user_interaction=session_ctx.request_user_interaction,
        )

        executor = ToolExecutor(
            context=tool_context,
            registry=ctx.tool_registry,
            append_history=session_ctx.append_history,
        )
        self._tool_executor = executor
        try:
            async for exec_event in executor.run_tools(tool_calls):
                if (
                    isinstance(exec_event, ToolExecutionResult)
                    and not exec_event.tool_result.continue_agent
                    and self._turn_result is not None
                ):
                    self._turn_result.continue_agent = False
                for ui_event in build_events_from_tool_executor_event(session_ctx.session_id, exec_event):
                    yield ui_event
        finally:
            self._tool_executor = None

    def _persist_continuation_prompt_on_interrupt(self) -> None:
        """Persist user continuation prompt from accumulated assistant text.

        Uses text accumulated from AssistantTextDelta events, which excludes
        thinking content.
        """
        partial_text = "".join(self._accumulated_assistant_text).strip()
        if not partial_text:
            return
        continuation_prompt = _build_continuation_prompt(partial_text)
        self._context.session_ctx.append_history(
            [message.UserMessage(parts=[message.TextPart(text=continuation_prompt)])]
        )
