from .command_abc import CommandABC, CommandResult
from .registry import (
    dispatch_command,
    get_command_info_list,
    get_command_names,
    get_commands,
    has_interactive_command,
    is_slash_command_name,
    register,
)
from .types import CommandInfo, CommandName

# Lazy load commands to avoid heavy imports at module load time
_commands_loaded = False


def ensure_commands_loaded() -> None:
    """Ensure all commands are loaded (lazy initialization).

    This function is called internally by registry functions like get_commands(),
    dispatch_command(), etc. It can also be called explicitly if early loading is desired.

    Commands are registered in display order - the order here determines
    the order shown in slash command completion.
    """
    global _commands_loaded
    if _commands_loaded:
        return
    _commands_loaded = True

    # Import and register commands in display order
    from .compact_cmd import CompactCommand
    from .continue_cmd import ContinueCommand
    from .copy_cmd import CopyCommand
    from .debug_cmd import DebugCommand
    from .fork_session_cmd import ForkSessionCommand
    from .login_cmd import LoginCommand
    from .logout_cmd import LogoutCommand
    from .model_cmd import ModelCommand
    from .new_cmd import NewCommand
    from .refresh_cmd import RefreshTerminalCommand
    from .status_cmd import StatusCommand
    from .sub_agent_model_cmd import SubAgentModelCommand
    from .thinking_cmd import ThinkingCommand
    from .web_cmd import WebCommand

    # Register in desired display order
    register(CopyCommand())
    register(CompactCommand())
    register(ForkSessionCommand())
    register(RefreshTerminalCommand())
    register(WebCommand())
    register(NewCommand())
    register(ModelCommand())
    register(SubAgentModelCommand())
    register(ThinkingCommand())
    register(StatusCommand())
    register(LoginCommand())
    register(LogoutCommand())
    register(ContinueCommand())
    register(DebugCommand())


# Lazy accessors for command classes
def __getattr__(name: str) -> object:
    _commands_map = {
        "NewCommand": "new_cmd",
        "CompactCommand": "compact_cmd",
        "ContinueCommand": "continue_cmd",
        "CopyCommand": "copy_cmd",
        "DebugCommand": "debug_cmd",
        "ForkSessionCommand": "fork_session_cmd",
        "LoginCommand": "login_cmd",
        "LogoutCommand": "logout_cmd",
        "ModelCommand": "model_cmd",
        "RefreshTerminalCommand": "refresh_cmd",
        "StatusCommand": "status_cmd",
        "SubAgentModelCommand": "sub_agent_model_cmd",
        "ThinkingCommand": "thinking_cmd",
        "WebCommand": "web_cmd",
    }
    if name in _commands_map:
        import importlib

        module = importlib.import_module(f".{_commands_map[name]}", __package__)
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Command classes are lazily loaded via __getattr__
    # "NewCommand", "DiffCommand", "HelpCommand", "ModelCommand",
    # "ExportCommand", "RefreshTerminalCommand", "ReleaseNotesCommand",
    # "StatusCommand",
    "CommandABC",
    "CommandInfo",
    "CommandName",
    "CommandResult",
    "dispatch_command",
    "ensure_commands_loaded",
    "get_command_info_list",
    "get_command_names",
    "get_commands",
    "has_interactive_command",
    "is_slash_command_name",
]
