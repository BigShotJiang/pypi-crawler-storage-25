from dataclasses import dataclass
from enum import Enum

from rich.style import Style
from rich.theme import Theme


@dataclass
class Palette:
    red: str
    yellow: str
    green: str
    cyan: str
    blue: str
    orange: str
    magenta: str
    grey1: str
    grey2: str
    grey3: str
    grey_green: str
    purple: str
    lavender: str
    black: str
    # Dim variants: pre-computed dimmed colors to avoid relying on terminal "dim" attribute
    dim_red: str
    dim_grey1: str
    dim_grey2: str
    dim_grey3: str
    diff_add: str
    diff_add_char: str
    diff_remove: str
    diff_remove_char: str
    code_theme: str
    code_background: str
    green_background: str
    blue_grey_background: str
    # Sub-agent backgrounds (corresponding to sub_agent_colors order)
    cyan_background: str
    green_sub_background: str
    blue_sub_background: str
    purple_background: str
    orange_background: str
    red_background: str
    grey_background: str
    yellow_background: str
    user_message_background: str


LIGHT_PALETTE = Palette(
    red="red",
    yellow="yellow",
    green="#00875f",
    cyan="cyan",
    blue="#3078C5",
    orange="#c96542",
    magenta="magenta",
    grey1="#667e90",
    grey2="#93a4b1",
    grey3="#c4ced4",
    grey_green="#96a096",
    purple="#5f5fb7",
    lavender="#7878b0",
    black="#101827",
    dim_red="#d88888",
    dim_grey1="#8fa2b0",
    dim_grey2="#b0bec5",
    dim_grey3="#d8dfe3",
    diff_add="#2e5a32 on #dafbe1",
    diff_add_char="#2e5a32 on #aceebb",
    diff_remove="#82071e on #ffecec",
    diff_remove_char="#82071e on #ffcfcf",
    code_theme="ansi_light",
    code_background="#ebebeb",
    green_background="#f0f7f1",
    blue_grey_background="#f0f1f7",
    cyan_background="#ecf7f7",
    green_sub_background="#ecf7ec",
    blue_sub_background="#ecf1f9",
    purple_background="#f5ecf9",
    orange_background="#f9f3ec",
    red_background="#f9ecec",
    grey_background="#f0f0f0",
    yellow_background="#f9f9ec",
    user_message_background="#f0f0f0",
)

DARK_PALETTE = Palette(
    red="#d75f5f",
    yellow="yellow",
    green="#5fd787",
    cyan="cyan",
    blue="#00afff",
    orange="#e6704e",
    magenta="magenta",
    grey1="#99aabb",
    grey2="#778899",
    grey3="#545c6c",
    grey_green="#6d8672",
    purple="#afbafe",
    lavender="#9898b8",
    black="white",
    dim_red="#9a4545",
    dim_grey1="#6e7b89",
    dim_grey2="#576574",
    dim_grey3="#3e444f",
    diff_add="#c8e6c9 on #1b3928",
    diff_add_char="#c8e6c9 on #2d6b42",
    diff_remove="#ffcdd2 on #3d1f23",
    diff_remove_char="#ffcdd2 on #7a3a42",
    code_theme="ansi_dark",
    code_background="#141720",
    green_background="#1a2721",
    blue_grey_background="#1c222c",
    cyan_background="#142626",
    green_sub_background="#142b1e",
    blue_sub_background="#14202e",
    purple_background="#201c30",
    orange_background="#2e2014",
    red_background="#2e171a",
    grey_background="#202224",
    yellow_background="#2e2c14",
    user_message_background="#202224",
)


class ThemeKey(str, Enum):
    LINES = "lines"
    LINES_DIM = "lines.dim"

    # CODE
    CODE_BACKGROUND = "code_background"

    # PANEL
    SUB_AGENT_RESULT_PANEL = "panel.sub_agent_result"
    WRITE_MARKDOWN_PANEL = "panel.write_markdown"
    COMPACTION_SUMMARY_PANEL = "panel.compaction_summary"
    # DIFF
    DIFF_FILE_NAME = "diff.file_name"
    DIFF_REMOVE = "diff.remove"
    DIFF_ADD = "diff.add"
    DIFF_ADD_CHAR = "diff.add.char"
    DIFF_REMOVE_CHAR = "diff.remove.char"
    DIFF_STATS_ADD = "diff.stats.add"
    DIFF_STATS_REMOVE = "diff.stats.remove"
    # ERROR
    ERROR = "error"
    ERROR_BOLD = "error.bold"
    ERROR_DIM = "error.dim"
    WARN = "warn"
    WARN_BOLD = "warn.bold"
    INTERRUPT = "interrupt"
    # METADATA
    METADATA = "metadata"
    METADATA_DIM = "metadata.dim"
    METADATA_BOLD = "metadata.bold"
    METADATA_ITALIC = "metadata.italic"
    METADATA_TOKEN = "metadata.token"
    METADATA_TOKEN_OK = "metadata.token.ok"
    METADATA_TOKEN_WARN = "metadata.token.warn"
    METADATA_CONTEXT = "metadata.context"
    METADATA_MAIN_AGENT_NAME = "metadata.main_agent_name"
    METADATA_SUB_AGENT_NAME = "metadata.sub_agent_name"
    METADATA_GREEN = "metadata.green"
    METADATA_GREEN_DIM = "metadata.green.dim"
    # SPINNER_STATUS
    STATUS_SPINNER = "spinner.status"
    STATUS_TEXT = "spinner.status.text"
    STATUS_TODO = "spinner.status.todo"
    STATUS_TEXT_BOLD = "spinner.status.text.bold"
    STATUS_TEXT_BOLD_ITALIC = "spinner.status.text.bold_italic"
    STATUS_TOAST = "spinner.status.toast"
    # STATUS
    STATUS_HINT = "status.hint"
    # USER_INPUT
    USER_INPUT = "user.input"
    USER_INPUT_PROMPT = "user.input.prompt"
    USER_INPUT_AT_PATTERN = "user.at_pattern"
    USER_INPUT_SLASH_COMMAND = "user.slash_command"
    USER_INPUT_SKILL = "user.skill"
    # ASSISTANT
    ASSISTANT_MESSAGE_MARK = "assistant.message_mark"
    # ATTACHMENT
    ATTACHMENT = "attachment"
    ATTACHMENT_BOLD = "attachment.bold"
    # TOOL
    INVALID_TOOL_CALL_ARGS = "tool.invalid_tool_call_args"
    TOOL_NAME = "tool.name"
    TOOL_PARAM_FILE_PATH = "tool.param.file_path"
    TOOL_PARAM_FILE_PATH_SKILL_NAME = "tool.param.file_path_skill_name"
    TOOL_PARAM_FILE_PATH_SKILL_FILE = "tool.param.file_path_skill_file"
    TOOL_PARAM = "tool.param"
    TOOL_PARAM_BOLD = "tool.param.bold"
    TOOL_RESULT = "tool.result"
    TOOL_RESULT_QUESTION = "tool.result.question"
    TOOL_RESULT_QUESTION_PROMPT = "tool.result.question_prompt"
    TOOL_RESULT_TREE_PREFIX = "tool.result.tree_prefix"
    TOOL_RESULT_TRUNCATED = "tool.result.truncated"
    TOOL_RESULT_BOLD = "tool.result.bold"
    COMMAND_OUTPUT = "command.output"
    FORK_NOTICE = "fork.notice"
    SESSION_STATUS = "session.status"
    SESSION_STATUS_BOLD = "session.status.bold"
    TOOL_MARK = "tool.mark"
    TOOL_APPROVED = "tool.approved"
    TOOL_REJECTED = "tool.rejected"
    TOOL_TIMEOUT = "tool.timeout"
    # BASH SYNTAX
    BASH_COMMAND = "bash.command"
    BASH_ARGUMENT = "bash.argument"
    BASH_OPERATOR = "bash.operator"
    BASH_STRING = "bash.string"
    BASH_HEREDOC_DELIMITER = "bash.heredoc.delimiter"
    # THINKING
    THINKING = "thinking"
    THINKING_BOLD = "thinking.bold"
    # COMPACTION
    COMPACTION_SUMMARY = "compaction.summary"
    # HANDOFF
    HANDOFF = "handoff"
    HANDOFF_INFO = "handoff.info"
    HANDOFF_NOTE = "handoff.note"
    # REWIND
    REWIND = "rewind"
    REWIND_INFO = "rewind.info"
    REWIND_USER_MESSAGE = "rewind.user_message"
    REWIND_NOTE = "rewind.note"
    # TODO_ITEM
    TODO_EXPLANATION = "todo.explanation"
    TODO_PENDING_MARK = "todo.pending.mark"
    TODO_COMPLETED_MARK = "todo.completed.mark"
    TODO_IN_PROGRESS_MARK = "todo.in_progress.mark"
    TODO_NEW_COMPLETED_MARK = "todo.new_completed.mark"
    TODO_PENDING = "todo.pending"
    TODO_COMPLETED = "todo.completed"
    TODO_IN_PROGRESS = "todo.in_progress"
    TODO_NEW_COMPLETED = "todo.new_completed"
    # WELCOME
    WELCOME_HIGHLIGHT_BOLD = "welcome.highlight.bold"
    WELCOME_HIGHLIGHT = "welcome.highlight"
    WELCOME_INFO = "welcome.info"
    WELCOME_INFO_BOLD = "welcome.info.bold"
    WELCOME_SHORTCUT = "welcome.shortcut"
    WELCOME_SCOPE = "welcome.scope"
    WARN_SCOPE = "warn.scope"
    # WELCOME DEBUG
    WELCOME_DEBUG_TITLE = "welcome.debug.title"
    WELCOME_DEBUG_BORDER = "welcome.debug.border"
    # RESUME
    RESUME_FLAG = "resume.flag"
    RESUME_INFO = "resume.info"
    # CONFIGURATION DISPLAY
    CONFIG_PROVIDER = "config.provider"
    CONFIG_TABLE_HEADER = "config.table.header"
    CONFIG_STATUS_OK = "config.status.ok"
    CONFIG_STATUS_PRIMARY = "config.status.primary"
    CONFIG_STATUS_ERROR = "config.status.error"
    CONFIG_ITEM_NAME = "config.item.name"
    CONFIG_MODEL_ID = "config.model.id"
    CONFIG_PARAM_LABEL = "config.param.label"
    CONFIG_PARAM_VALUE = "config.param.value"

    def __str__(self) -> str:
        return self.value


@dataclass
class Themes:
    app_theme: Theme
    markdown_theme: Theme
    thinking_markdown_theme: Theme
    code_theme: str
    sub_agent_colors: list[Style]
    sub_agent_backgrounds: list[Style]


def get_theme(theme: str | None = None) -> Themes:
    palette = LIGHT_PALETTE if theme == "light" else DARK_PALETTE

    return Themes(
        app_theme=Theme(
            styles={
                ThemeKey.LINES.value: palette.grey3,
                ThemeKey.LINES_DIM.value: palette.dim_grey3,
                # CODE
                ThemeKey.CODE_BACKGROUND.value: f"on {palette.code_background}",
                # PANEL
                ThemeKey.SUB_AGENT_RESULT_PANEL.value: f"on {palette.blue_grey_background}",
                ThemeKey.WRITE_MARKDOWN_PANEL.value: f"on {palette.green_background}",
                ThemeKey.COMPACTION_SUMMARY_PANEL.value: f"on {palette.blue_grey_background}",
                # DIFF
                ThemeKey.DIFF_FILE_NAME.value: palette.blue,
                ThemeKey.DIFF_REMOVE.value: palette.diff_remove,
                ThemeKey.DIFF_ADD.value: palette.diff_add,
                ThemeKey.DIFF_ADD_CHAR.value: palette.diff_add_char,
                ThemeKey.DIFF_REMOVE_CHAR.value: palette.diff_remove_char,
                ThemeKey.DIFF_STATS_ADD.value: palette.green,
                ThemeKey.DIFF_STATS_REMOVE.value: palette.red,
                # ERROR
                ThemeKey.ERROR.value: palette.red,
                ThemeKey.ERROR_BOLD.value: "bold " + palette.red,
                ThemeKey.ERROR_DIM.value: palette.dim_red,
                ThemeKey.WARN.value: palette.yellow,
                ThemeKey.WARN_BOLD.value: "bold " + palette.yellow,
                ThemeKey.INTERRUPT.value: palette.red,
                # USER_INPUT
                ThemeKey.USER_INPUT.value: f"bold {palette.cyan} on {palette.user_message_background}",
                ThemeKey.USER_INPUT_PROMPT.value: f"bold {palette.cyan} on {palette.user_message_background}",
                ThemeKey.USER_INPUT_AT_PATTERN.value: f"bold {palette.purple} on {palette.user_message_background}",
                ThemeKey.USER_INPUT_SLASH_COMMAND.value: f"bold {palette.blue} on {palette.user_message_background}",
                ThemeKey.USER_INPUT_SKILL.value: f"bold {palette.blue} on {palette.user_message_background}",
                # ASSISTANT
                ThemeKey.ASSISTANT_MESSAGE_MARK.value: "bold",
                # METADATA
                ThemeKey.METADATA.value: palette.grey1,
                ThemeKey.METADATA_DIM.value: palette.dim_grey1,
                ThemeKey.METADATA_BOLD.value: "bold " + palette.grey1,
                ThemeKey.METADATA_ITALIC.value: "italic " + palette.purple,
                ThemeKey.METADATA_TOKEN.value: palette.grey1 + " on " + palette.green_background,
                ThemeKey.METADATA_TOKEN_OK.value: palette.green + " on " + palette.green_background,
                ThemeKey.METADATA_TOKEN_WARN.value: palette.red + " on " + palette.red_background,
                ThemeKey.METADATA_CONTEXT.value: palette.dim_grey1,
                ThemeKey.METADATA_MAIN_AGENT_NAME.value: palette.blue + " on " + palette.blue_sub_background,
                ThemeKey.METADATA_SUB_AGENT_NAME.value: palette.purple + " on " + palette.purple_background,
                ThemeKey.METADATA_GREEN.value: palette.green,
                ThemeKey.METADATA_GREEN_DIM.value: palette.grey_green,
                # STATUS
                ThemeKey.STATUS_SPINNER.value: palette.grey1,
                ThemeKey.STATUS_TEXT.value: palette.grey1,
                ThemeKey.STATUS_TODO.value: palette.blue,
                ThemeKey.STATUS_TEXT_BOLD.value: "bold " + palette.grey1,
                ThemeKey.STATUS_TEXT_BOLD_ITALIC.value: "bold italic " + palette.grey1,
                ThemeKey.STATUS_TOAST.value: "bold " + palette.yellow,
                ThemeKey.STATUS_HINT.value: palette.grey2,
                # ATTACHMENT
                ThemeKey.ATTACHMENT.value: palette.grey1,
                ThemeKey.ATTACHMENT_BOLD.value: palette.grey1,
                # TOOL
                ThemeKey.INVALID_TOOL_CALL_ARGS.value: palette.yellow,
                ThemeKey.TOOL_NAME.value: "bold",
                ThemeKey.TOOL_PARAM_FILE_PATH.value: palette.green,
                ThemeKey.TOOL_PARAM_FILE_PATH_SKILL_NAME.value: "bold "
                + palette.blue
                + " on "
                + palette.code_background,
                ThemeKey.TOOL_PARAM_FILE_PATH_SKILL_FILE.value: palette.blue,
                ThemeKey.TOOL_PARAM.value: palette.green,
                ThemeKey.TOOL_PARAM_BOLD.value: "bold " + palette.green,
                ThemeKey.TOOL_RESULT.value: palette.grey_green,
                ThemeKey.TOOL_RESULT_QUESTION.value: palette.cyan,
                ThemeKey.TOOL_RESULT_QUESTION_PROMPT.value: palette.black,
                ThemeKey.TOOL_RESULT_TREE_PREFIX.value: palette.grey3,
                ThemeKey.TOOL_RESULT_BOLD.value: "bold " + palette.grey_green,
                ThemeKey.TOOL_RESULT_TRUNCATED.value: palette.dim_grey1,
                ThemeKey.COMMAND_OUTPUT.value: palette.grey1,
                ThemeKey.FORK_NOTICE.value: "bold " + palette.blue,
                ThemeKey.SESSION_STATUS.value: palette.grey1,
                ThemeKey.SESSION_STATUS_BOLD.value: "bold " + palette.grey1,
                ThemeKey.TOOL_MARK.value: "bold",
                ThemeKey.TOOL_APPROVED.value: palette.green + " bold reverse",
                ThemeKey.TOOL_REJECTED.value: palette.red + " bold reverse",
                ThemeKey.TOOL_TIMEOUT.value: palette.grey2,
                # BASH SYNTAX
                ThemeKey.BASH_COMMAND.value: "bold " + palette.green,
                ThemeKey.BASH_ARGUMENT.value: palette.green,
                ThemeKey.BASH_OPERATOR.value: palette.grey2,
                ThemeKey.BASH_STRING.value: palette.purple,
                ThemeKey.BASH_HEREDOC_DELIMITER.value: "bold " + palette.grey1,
                # THINKING
                ThemeKey.THINKING.value: "italic " + palette.grey2,
                ThemeKey.THINKING_BOLD.value: "italic " + palette.grey1,
                # COMPACTION
                ThemeKey.COMPACTION_SUMMARY.value: palette.grey1,
                # HANDOFF
                ThemeKey.HANDOFF.value: palette.blue,
                ThemeKey.HANDOFF_INFO.value: palette.dim_grey2,
                ThemeKey.HANDOFF_NOTE.value: palette.grey1,
                # REWIND
                ThemeKey.REWIND.value: palette.orange,
                ThemeKey.REWIND_INFO.value: palette.dim_grey2,
                ThemeKey.REWIND_USER_MESSAGE.value: palette.cyan,
                ThemeKey.REWIND_NOTE.value: palette.grey1,
                # TODO_ITEM
                ThemeKey.TODO_EXPLANATION.value: "italic " + palette.lavender,
                ThemeKey.TODO_PENDING_MARK.value: "bold " + palette.grey1,
                ThemeKey.TODO_COMPLETED_MARK.value: "bold " + palette.grey3,
                ThemeKey.TODO_IN_PROGRESS_MARK.value: "bold " + palette.blue,
                ThemeKey.TODO_NEW_COMPLETED_MARK.value: "bold " + palette.green,
                ThemeKey.TODO_PENDING.value: palette.grey1,
                ThemeKey.TODO_COMPLETED.value: palette.grey3 + " strike",
                ThemeKey.TODO_IN_PROGRESS.value: "bold " + palette.blue,
                ThemeKey.TODO_NEW_COMPLETED.value: "bold strike " + palette.green,
                # WELCOME
                ThemeKey.WELCOME_HIGHLIGHT_BOLD.value: "bold",
                ThemeKey.WELCOME_HIGHLIGHT.value: palette.blue,
                ThemeKey.WELCOME_INFO.value: palette.grey1,
                ThemeKey.WELCOME_INFO_BOLD.value: "bold " + palette.grey1,
                ThemeKey.WELCOME_SHORTCUT.value: palette.green,
                ThemeKey.WELCOME_SCOPE.value: palette.green,
                ThemeKey.WARN_SCOPE.value: palette.yellow + " on " + palette.code_background,
                # WELCOME DEBUG
                ThemeKey.WELCOME_DEBUG_TITLE.value: "bold " + palette.purple,
                ThemeKey.WELCOME_DEBUG_BORDER.value: palette.purple,
                # RESUME
                ThemeKey.RESUME_FLAG.value: "bold reverse " + palette.green,
                ThemeKey.RESUME_INFO.value: palette.green,
                # CONFIGURATION DISPLAY
                ThemeKey.CONFIG_TABLE_HEADER.value: "bold " + palette.grey1,
                ThemeKey.CONFIG_STATUS_OK.value: palette.green,
                ThemeKey.CONFIG_STATUS_PRIMARY.value: "bold " + palette.yellow,
                ThemeKey.CONFIG_STATUS_ERROR.value: palette.red,
                ThemeKey.CONFIG_ITEM_NAME.value: palette.cyan,
                ThemeKey.CONFIG_MODEL_ID.value: palette.blue,
                ThemeKey.CONFIG_PARAM_LABEL.value: palette.grey2,
                ThemeKey.CONFIG_PARAM_VALUE.value: palette.grey1,
                ThemeKey.CONFIG_PROVIDER.value: palette.cyan + " bold",
            }
        ),
        markdown_theme=Theme(
            styles={
                "markdown.code": palette.cyan,
                # Render degraded `<thinking>...</thinking>` blocks inside assistant markdown.
                # This must live in markdown_theme (not just thinking_markdown_theme) because
                # it is used while rendering assistant output.
                "markdown.thinking": "italic " + palette.grey2,
                "markdown.thinking.tag": palette.grey2,
                "markdown.code.border": palette.grey2,
                "markdown.code.fence": palette.grey2,
                "markdown.code.fence.title": palette.grey1,
                # Used by ThinkingMarkdown when rendering `<thinking>` blocks.
                "markdown.code.block": palette.grey1,
                "markdown.h1": "bold reverse " + palette.black,
                "markdown.h1.border": palette.grey3,
                "markdown.h2": "bold underline " + palette.black,
                "markdown.h3": "bold " + palette.grey1,
                "markdown.h4": "bold " + palette.grey2,
                "markdown.hr": palette.grey3,
                "markdown.item.bullet": palette.grey2,
                "markdown.item.number": palette.grey2,
                "markdown.link": "underline " + palette.blue,
                "markdown.link_url": "underline " + palette.blue,
                "markdown.image.placeholder": palette.grey2,
                "markdown.table.border": palette.grey2,
                "markdown.checkbox.checked": palette.green,
                "markdown.block_quote": palette.cyan,
            }
        ),
        thinking_markdown_theme=Theme(
            styles={
                # THINKING (used for left-side mark in thinking output)
                ThemeKey.THINKING.value: "italic " + palette.grey2,
                ThemeKey.THINKING_BOLD.value: "italic " + palette.grey1,
                "markdown.strong": "italic " + palette.grey1,
                "markdown.code": palette.grey1 + " italic on " + palette.code_background,
                "markdown.code.block": palette.grey2,
                "markdown.code.fence": palette.grey2,
                "markdown.code.fence.title": palette.grey1,
                "markdown.code.border": palette.grey2,
                "markdown.thinking.tag": palette.dim_grey2,
                "markdown.h1": "bold reverse",
                "markdown.h1.border": palette.grey3,
                "markdown.h3": "bold " + palette.grey1,
                "markdown.h4": "bold " + palette.grey2,
                "markdown.hr": palette.grey3,
                "markdown.item.bullet": palette.grey2,
                "markdown.item.number": palette.grey2,
                "markdown.link": "underline " + palette.blue,
                "markdown.link_url": "underline " + palette.blue,
                "markdown.image.placeholder": palette.grey2,
                "markdown.table.border": palette.grey2,
                "markdown.checkbox.checked": palette.green,
                "markdown.block_quote": palette.grey1,
            }
        ),
        code_theme=palette.code_theme,
        sub_agent_colors=[
            Style(color=palette.cyan),
            Style(color=palette.green),
            Style(color=palette.blue),
            Style(color=palette.purple),
            Style(color=palette.orange),
            Style(color=palette.grey1),
            Style(color=palette.yellow),
        ],
        sub_agent_backgrounds=[
            Style(bgcolor=palette.cyan_background),
            Style(bgcolor=palette.green_sub_background),
            Style(bgcolor=palette.blue_sub_background),
            Style(bgcolor=palette.purple_background),
            Style(bgcolor=palette.orange_background),
            Style(bgcolor=palette.grey_background),
            Style(bgcolor=palette.yellow_background),
        ],
    )
