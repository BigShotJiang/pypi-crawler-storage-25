import json
from pathlib import Path
from typing import Any, Literal, cast

from rich import box
from rich.console import Group, RenderableType
from rich.padding import Padding
from rich.panel import Panel
from rich.text import Text

from klaude_code.const import (
    DIFF_PREFIX_WIDTH,
    INVALID_TOOL_CALL_MAX_LENGTH,
    QUERY_DISPLAY_TRUNCATE_LENGTH,
    TAB_EXPAND_WIDTH,
    URL_TRUNCATE_MAX_LENGTH,
    WEB_SEARCH_DEFAULT_MAX_RESULTS,
)
from klaude_code.protocol import events, model, tools
from klaude_code.protocol.sub_agent import is_sub_agent_tool as _is_sub_agent_tool
from klaude_code.tui.components import diffs as r_diffs
from klaude_code.tui.components.bash_syntax import highlight_bash_command
from klaude_code.tui.components.common import create_grid, truncate_middle
from klaude_code.tui.components.rich.markdown import NoInsetMarkdown
from klaude_code.tui.components.rich.quote import TreeQuote
from klaude_code.tui.components.rich.theme import ThemeKey

# Tool markers (Unicode symbols for UI display)
MARK_GENERIC = "⚒"
MARK_BASH = "$"
MARK_PLAN = "◈"
MARK_READ = "→"
MARK_EDIT = "±"
MARK_WRITE = "+"
MARK_WEB_FETCH = "→"
MARK_WEB_SEARCH = "✱"
MARK_REWIND = "↶"
MARK_QUESTION = "◉"

_EXTERNAL_CONTENT_START = "<<<EXTERNAL_UNTRUSTED_CONTENT>>>"
_EXTERNAL_CONTENT_END = "<<<END_EXTERNAL_UNTRUSTED_CONTENT>>>"
_WEB_FETCH_SAVED_PATH_PREFIX = "[Full content saved to "

# Todo status markers
MARK_TODO_PENDING = "▢"
MARK_TODO_IN_PROGRESS = "◉"
MARK_TODO_COMPLETED = "✔"


def is_sub_agent_tool(tool_name: str) -> bool:
    return _is_sub_agent_tool(tool_name)


def get_agent_active_form(arguments: str) -> str:
    """Return active form text for Agent tool based on its arguments."""
    from klaude_code.protocol.sub_agent import get_sub_agent_profile

    _DEFAULT = "Tasking"

    try:
        parsed = json.loads(arguments)
    except json.JSONDecodeError:
        return _DEFAULT

    if not isinstance(parsed, dict):
        return _DEFAULT

    args = cast(dict[str, Any], parsed)

    type_raw = args.get("type")
    if not isinstance(type_raw, str):
        return _DEFAULT

    try:
        profile = get_sub_agent_profile(type_raw.strip())
    except KeyError:
        return _DEFAULT
    return profile.active_form or _DEFAULT


def render_path(path: str, style: str, is_directory: bool = False) -> Text:
    if path.startswith(str(Path().cwd())):
        path = path.replace(str(Path().cwd()), "").lstrip("/")
    elif path.startswith(str(Path().home())):
        path = path.replace(str(Path().home()), "~")
    elif not path.startswith("/") and not path.startswith("."):
        path = "./" + path
    if is_directory:
        path = path.rstrip("/") + "/"
    return Text(path, style=style, overflow="fold")


def _render_tool_call_tree(
    *,
    mark: str,
    tool_name: str,
    details: RenderableType | None,
    overflow: Literal["fold", "crop", "ellipsis", "ignore"] = "ellipsis",
) -> RenderableType:
    grid = create_grid(overflow=overflow)
    grid.add_row(
        Text(tool_name, style=ThemeKey.TOOL_NAME),
        details if details is not None else Text(""),
    )

    return TreeQuote.for_tool_call(
        grid,
        mark=mark,
        style=ThemeKey.TOOL_RESULT_TREE_PREFIX,
        style_first=ThemeKey.TOOL_MARK,
    )


def render_generic_tool_call(tool_name: str, arguments: str, markup: str = MARK_GENERIC) -> RenderableType:
    if not arguments:
        return _render_tool_call_tree(mark=markup, tool_name=tool_name, details=None)

    details: RenderableType
    try:
        payload = json.loads(arguments)
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
    else:
        if isinstance(payload, dict):
            payload_dict = cast(dict[str, Any], payload)
            if len(payload_dict) == 0:
                details = Text("", ThemeKey.TOOL_PARAM)
            elif len(payload_dict) == 1:
                details = Text(str(next(iter(payload_dict.values()))), ThemeKey.TOOL_PARAM)
            else:
                details = Text(
                    ", ".join([f"{k}: {v}" for k, v in payload_dict.items()]),
                    ThemeKey.TOOL_PARAM,
                )
        else:
            details = Text(str(payload)[:INVALID_TOOL_CALL_MAX_LENGTH], style=ThemeKey.INVALID_TOOL_CALL_ARGS)

    return _render_tool_call_tree(mark=markup, tool_name=tool_name, details=details)


def render_bash_tool_call(arguments: str) -> RenderableType:
    tool_name = "Bash"

    try:
        payload_raw: Any = json.loads(arguments) if arguments else {}
    except json.JSONDecodeError:
        details: RenderableType = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_BASH, tool_name=tool_name, details=details)

    if not isinstance(payload_raw, dict):
        details = Text(
            str(payload_raw)[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_BASH, tool_name=tool_name, details=details)

    payload: dict[str, object] = cast(dict[str, object], payload_raw)

    command = payload.get("command")
    if isinstance(command, str) and command.strip():
        cmd_str = command.strip()
        highlighted = highlight_bash_command(cmd_str)
        padded = Padding(highlighted, pad=0, style=ThemeKey.CODE_BACKGROUND, expand=False)
        return _render_tool_call_tree(mark=MARK_BASH, tool_name=tool_name, details=padded)

    return _render_tool_call_tree(mark=MARK_BASH, tool_name=tool_name, details=None)


def render_todo_write_tool_call(arguments: str) -> RenderableType:
    tool_name = "Update To-Dos"
    details: RenderableType | None = None

    if arguments:
        try:
            json.loads(arguments)
        except json.JSONDecodeError:
            details = Text(
                arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
                style=ThemeKey.INVALID_TOOL_CALL_ARGS,
            )

    return _render_tool_call_tree(mark=MARK_PLAN, tool_name=tool_name, details=details)


def render_read_tool_call(arguments: str) -> RenderableType:
    tool_name = "Read"
    details = Text("", ThemeKey.TOOL_PARAM)

    try:
        payload_raw: Any = json.loads(arguments)
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )

        return _render_tool_call_tree(mark=MARK_READ, tool_name=tool_name, details=details, overflow="fold")

    if not isinstance(payload_raw, dict):
        details = Text(str(payload_raw)[:INVALID_TOOL_CALL_MAX_LENGTH], style=ThemeKey.INVALID_TOOL_CALL_ARGS)
        return _render_tool_call_tree(mark=MARK_READ, tool_name=tool_name, details=details, overflow="fold")

    payload = cast(dict[str, Any], payload_raw)
    file_path = payload.get("file_path")
    limit = payload.get("limit", None)
    offset = payload.get("offset", None)
    offset_int = offset if isinstance(offset, int) and not isinstance(offset, bool) else None
    limit_int = limit if isinstance(limit, int) and not isinstance(limit, bool) else None

    if isinstance(file_path, str) and file_path:
        path_obj = Path(file_path)
        is_skill = path_obj.name == "SKILL.md"
        if is_skill:
            tool_name = "Read Skill"
            path_text = render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH)
            skill_file = "SKILL.md"
            skill_file_start = path_text.plain.rfind(skill_file)
            if skill_file_start != -1:
                skill_file_end = skill_file_start + len(skill_file)
                path_text.stylize(ThemeKey.TOOL_PARAM_FILE_PATH_SKILL_FILE, skill_file_start, skill_file_end)

                slash_index = skill_file_start - 1
                if slash_index >= 0 and path_text.plain[slash_index] == "/":
                    skill_name_start = path_text.plain.rfind("/", 0, slash_index) + 1
                    if skill_name_start < slash_index:
                        path_text.stylize(ThemeKey.TOOL_PARAM_FILE_PATH_SKILL_NAME, skill_name_start, slash_index)
            details.append_text(path_text)
        else:
            details.append_text(render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH))
    else:
        details.append("(no file_path)", style=ThemeKey.TOOL_PARAM)

    if limit_int is not None and offset_int is not None:
        details = (
            details.append_text(Text(" "))
            .append_text(Text(str(offset_int), ThemeKey.TOOL_PARAM))
            .append_text(Text(":", ThemeKey.TOOL_PARAM))
            .append_text(Text(str(offset_int + limit_int - 1), ThemeKey.TOOL_PARAM))
        )
    elif limit_int is not None and offset is None:
        details = (
            details.append_text(Text(" "))
            .append_text(Text("1", ThemeKey.TOOL_PARAM))
            .append_text(Text(":", ThemeKey.TOOL_PARAM))
            .append_text(Text(str(limit_int), ThemeKey.TOOL_PARAM))
        )
    elif offset_int is not None and limit is None:
        details = (
            details.append_text(Text(" "))
            .append_text(Text(str(offset_int), ThemeKey.TOOL_PARAM))
            .append_text(Text(":", ThemeKey.TOOL_PARAM))
            .append_text(Text("-", ThemeKey.TOOL_PARAM))
        )
    elif offset is not None or limit is not None:
        invalid_parts: list[str] = []
        if offset is not None and (offset_int is None or limit is not None):
            invalid_parts.append(f"offset={offset}")
        if limit is not None and (limit_int is None or offset is not None):
            invalid_parts.append(f"limit={limit}")
        if invalid_parts:
            details.append_text(Text(f" ({', '.join(invalid_parts)})", ThemeKey.INVALID_TOOL_CALL_ARGS))

    return _render_tool_call_tree(mark=MARK_READ, tool_name=tool_name, details=details, overflow="fold")


def render_edit_tool_call(arguments: str) -> RenderableType:
    tool_name = "Edit"
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path")
        replace_all = json_dict.get("replace_all", False)
        path_text = render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH)
        if replace_all:
            old_string = json_dict.get("old_string", "")
            new_string = json_dict.get("new_string", "")
            replace_info = Text("Replacing all ", ThemeKey.TOOL_RESULT_TRUNCATED)
            replace_info.append(old_string, ThemeKey.BASH_STRING)
            replace_info.append(" → ", ThemeKey.BASH_OPERATOR)
            replace_info.append(new_string, ThemeKey.BASH_STRING)
            details: RenderableType = Group(path_text, replace_info)
        else:
            details = path_text
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
    return _render_tool_call_tree(mark=MARK_EDIT, tool_name=tool_name, details=details)


def render_write_tool_call(arguments: str) -> RenderableType:
    tool_name = "Write"
    try:
        json_dict = json.loads(arguments)
        file_path = json_dict.get("file_path", "")
        details: RenderableType | None = render_path(file_path, ThemeKey.TOOL_PARAM_FILE_PATH)
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
    return _render_tool_call_tree(mark=MARK_WRITE, tool_name=tool_name, details=details)


def render_apply_patch_tool_call(arguments: str) -> RenderableType:
    tool_name = "Patch"

    try:
        payload = json.loads(arguments)
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_EDIT, tool_name=tool_name, details=details)

    patch_content = payload.get("patch", "")
    details = Text("", ThemeKey.TOOL_PARAM)

    if isinstance(patch_content, str):
        update_files: list[str] = []
        add_files: list[str] = []
        delete_files: list[str] = []
        for line in patch_content.splitlines():
            if line.startswith("*** Update File:"):
                update_files.append(line[len("*** Update File:") :].strip())
            elif line.startswith("*** Add File:"):
                add_files.append(line[len("*** Add File:") :].strip())
            elif line.startswith("*** Delete File:"):
                delete_files.append(line[len("*** Delete File:") :].strip())

        details = Text("", ThemeKey.TOOL_PARAM)
        if update_files:
            details.append(f"Edit × {len(update_files)}")
        if add_files:
            if details.plain:
                details.append(", ")
            # For single .md file addition, show filename in parentheses
            if len(add_files) == 1 and add_files[0].endswith(".md"):
                details.append("Create ")
                details.append_text(render_path(add_files[0], ThemeKey.TOOL_PARAM_FILE_PATH))
            else:
                details.append(f"Create × {len(add_files)}")
        if delete_files:
            if details.plain:
                details.append(", ")
            details.append(f"Delete × {len(delete_files)}")
    else:
        details = Text(
            str(patch_content)[:INVALID_TOOL_CALL_MAX_LENGTH],
            ThemeKey.INVALID_TOOL_CALL_ARGS,
        )

    return _render_tool_call_tree(mark=MARK_EDIT, tool_name=tool_name, details=details)


def render_todo(tr: events.ToolResultEvent) -> RenderableType:
    assert isinstance(tr.ui_extra, model.TodoListUIExtra)
    ui_extra = tr.ui_extra.todo_list
    todo_grid = create_grid()
    for todo in ui_extra.todos:
        is_new_completed = todo.content in ui_extra.new_completed
        match todo.status:
            case "pending":
                mark = MARK_TODO_PENDING
                mark_style = ThemeKey.TODO_PENDING_MARK
                text_style = ThemeKey.TODO_PENDING
            case "in_progress":
                mark = MARK_TODO_IN_PROGRESS
                mark_style = ThemeKey.TODO_IN_PROGRESS_MARK
                text_style = ThemeKey.TODO_IN_PROGRESS
            case "completed":
                mark = MARK_TODO_COMPLETED
                mark_style = ThemeKey.TODO_NEW_COMPLETED_MARK if is_new_completed else ThemeKey.TODO_COMPLETED_MARK
                text_style = ThemeKey.TODO_NEW_COMPLETED if is_new_completed else ThemeKey.TODO_COMPLETED
        text = Text(todo.content)
        text.stylize(text_style)
        todo_grid.add_row(Text(mark, style=mark_style), text)

    parts: list[RenderableType] = []
    if ui_extra.explanation:
        parts.append(Text(ui_extra.explanation, style=ThemeKey.TODO_EXPLANATION))
    parts.append(todo_grid)
    return Group(*parts) if len(parts) > 1 else todo_grid


def render_generic_tool_result(result: str, *, is_error: bool = False) -> RenderableType:
    """Render a generic tool result as truncated text."""
    style = ThemeKey.ERROR if is_error else ThemeKey.TOOL_RESULT
    text = truncate_middle(result, base_style=style)
    # Tool results should not reflow/wrap; use ellipsis when exceeding terminal width.
    text.no_wrap = True
    text.overflow = "ellipsis"
    return text


def render_ask_user_question_tool_result(result: str, *, is_error: bool = False) -> RenderableType:
    """Render AskUserQuestion result without truncating the middle content."""
    style = ThemeKey.ERROR if is_error else ThemeKey.TOOL_RESULT_QUESTION
    return Text(result.expandtabs(TAB_EXPAND_WIDTH), style=style, overflow="fold")


def render_ask_user_question_summary(ui_extra: model.AskUserQuestionSummaryUIExtra) -> RenderableType:
    """Render AskUserQuestion structured summary with highlighted answered status."""
    if not ui_extra.items:
        return Text("(No answer provided)", style=ThemeKey.WARN)

    grid = create_grid(overflow="fold")
    for item in ui_extra.items:
        grid.add_row(Text(""), Text("---", style=ThemeKey.LINES))
        grid.add_row(
            Text("●", style=ThemeKey.TOOL_RESULT_QUESTION_PROMPT),
            Text(
                item.question.expandtabs(TAB_EXPAND_WIDTH), style=ThemeKey.TOOL_RESULT_QUESTION_PROMPT, overflow="fold"
            ),
        )
        summary_style = ThemeKey.TOOL_PARAM if item.answered else ThemeKey.WARN
        summary_lines = item.summary.split("\n")
        for line in summary_lines:
            answer_text = Text()
            answer_text.append(Text("→ ", style=ThemeKey.TOOL_RESULT_TRUNCATED, overflow="fold"))
            answer_text.append(line.expandtabs(TAB_EXPAND_WIDTH), style=summary_style)
            grid.add_row(
                Text(""),
                answer_text,
            )

    return grid


def render_read_preview(ui_extra: model.ReadPreviewUIExtra) -> RenderableType:
    """Render read preview with line numbers aligned to diff style."""
    grid = create_grid()
    grid.padding = (0, 0)

    for line in ui_extra.lines:
        prefix = f"{line.line_no:>{DIFF_PREFIX_WIDTH}}  "
        content = line.content.expandtabs(TAB_EXPAND_WIDTH)
        grid.add_row(Text(prefix, ThemeKey.TOOL_RESULT), Text(content, ThemeKey.TOOL_RESULT))

    if ui_extra.remaining_lines > 0:
        remaining_prefix = f"{'⋮':>{DIFF_PREFIX_WIDTH}}  "
        remaining_text = Text(f"(more {ui_extra.remaining_lines} lines)", ThemeKey.TOOL_RESULT_TRUNCATED)
        grid.add_row(Text(remaining_prefix, ThemeKey.TOOL_RESULT_TRUNCATED), remaining_text)

    return grid


def _truncate_url(url: str, max_length: int = URL_TRUNCATE_MAX_LENGTH) -> str:
    """Truncate URL for display, preserving domain and path structure."""
    if len(url) <= max_length:
        return url
    # Remove protocol for display
    display_url = url
    for prefix in ("https://", "http://"):
        if display_url.startswith(prefix):
            display_url = display_url[len(prefix) :]
            break
    if len(display_url) <= max_length:
        return display_url
    # Truncate with ellipsis
    return display_url[: max_length - 1] + "…"


def _extract_web_result_for_display(result: str) -> str:
    """Extract readable web content from wrapped external-content payloads for TUI display."""
    start_idx = result.find(_EXTERNAL_CONTENT_START)
    end_idx = result.find(_EXTERNAL_CONTENT_END)
    if start_idx == -1 or end_idx == -1 or end_idx < start_idx:
        return result

    prefix = result[:start_idx]
    wrapped_body = result[start_idx + len(_EXTERNAL_CONTENT_START) : end_idx].lstrip("\n")

    lines = wrapped_body.splitlines()
    if len(lines) >= 2 and lines[0].startswith("Source: ") and lines[1].strip() == "---":
        content = "\n".join(lines[2:])
    else:
        divider = "\n---\n"
        divider_idx = wrapped_body.find(divider)
        content = wrapped_body[divider_idx + len(divider) :] if divider_idx != -1 else wrapped_body
    content = content.rstrip("\n")

    prefix_lines = [
        line.strip() for line in prefix.splitlines() if line.strip().startswith(_WEB_FETCH_SAVED_PATH_PREFIX)
    ]
    saved_path_hint = "\n".join(prefix_lines)

    if saved_path_hint and content:
        return f"{saved_path_hint}\n\n{content}"
    if saved_path_hint:
        return saved_path_hint
    return content


def render_web_fetch_tool_call(arguments: str) -> RenderableType:
    tool_name = "Fetch Web"

    try:
        payload: dict[str, str] = json.loads(arguments)
    except json.JSONDecodeError:
        summary = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_WEB_FETCH, tool_name=tool_name, details=summary)

    url = payload.get("url", "")
    summary = Text(_truncate_url(url), ThemeKey.TOOL_PARAM_FILE_PATH) if url else Text("(no url)", ThemeKey.TOOL_PARAM)

    return _render_tool_call_tree(mark=MARK_WEB_FETCH, tool_name=tool_name, details=summary)


def render_web_search_tool_call(arguments: str) -> RenderableType:
    tool_name = "Search Web"

    try:
        payload: dict[str, Any] = json.loads(arguments)
    except json.JSONDecodeError:
        summary = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_WEB_SEARCH, tool_name=tool_name, details=summary)

    query = payload.get("query", "")
    max_results = payload.get("max_results")

    summary = Text("", ThemeKey.TOOL_PARAM)
    if query:
        # Truncate long queries
        display_query = (
            query if len(query) <= QUERY_DISPLAY_TRUNCATE_LENGTH else query[: QUERY_DISPLAY_TRUNCATE_LENGTH - 1] + "…"
        )
        summary.append(display_query, ThemeKey.TOOL_PARAM)
    else:
        summary.append("(no query)", ThemeKey.TOOL_PARAM)

    if isinstance(max_results, int) and max_results != WEB_SEARCH_DEFAULT_MAX_RESULTS:
        summary.append(f" (max {max_results})", ThemeKey.TOOL_TIMEOUT)

    return _render_tool_call_tree(mark=MARK_WEB_SEARCH, tool_name=tool_name, details=summary)


def render_rewind_tool_call(arguments: str) -> RenderableType:
    tool_name = "Rewind"

    try:
        payload: dict[str, Any] = json.loads(arguments)
    except json.JSONDecodeError:
        details = Text(
            arguments.strip()[:INVALID_TOOL_CALL_MAX_LENGTH],
            style=ThemeKey.INVALID_TOOL_CALL_ARGS,
        )
        return _render_tool_call_tree(mark=MARK_REWIND, tool_name=tool_name, details=details)

    checkpoint_id = payload.get("checkpoint_id")
    rationale = payload.get("rationale", "")

    summary = Text("", ThemeKey.TOOL_PARAM)
    if isinstance(checkpoint_id, int):
        summary.append(f"Checkpoint {checkpoint_id}", ThemeKey.TOOL_PARAM_BOLD)
    if rationale:
        rationale_preview = rationale if len(rationale) <= 50 else rationale[:47] + "..."
        if summary.plain:
            summary.append(" - ")
        summary.append(rationale_preview, ThemeKey.TOOL_PARAM)

    return _render_tool_call_tree(mark=MARK_REWIND, tool_name=tool_name, details=summary if summary.plain else None)


def render_ask_user_question_tool_call(arguments: str) -> RenderableType:
    question_count = 1
    headers: list[str] = []
    if arguments:
        try:
            payload_raw: Any = json.loads(arguments)
            if isinstance(payload_raw, dict):
                payload = cast(dict[str, Any], payload_raw)
                questions: Any = payload.get("questions")
                if isinstance(questions, list) and questions:
                    question_count = len(cast(list[Any], questions))
                    for q in cast(list[dict[str, Any]], questions):
                        header = q.get("header")
                        if isinstance(header, str):
                            headers.append(header)
        except json.JSONDecodeError:
            pass

    if question_count == 1:
        tool_name = "Agent has a question for you"
    else:
        tool_name = f"Agent has {question_count} questions for you"

    details: RenderableType | None = None
    if headers:
        details = Text(" / ".join(headers), style="dim")

    return _render_tool_call_tree(mark=MARK_QUESTION, tool_name=tool_name, details=details)


# Tool name to active form mapping (for spinner status)
_TOOL_ACTIVE_FORM: dict[str, str] = {
    tools.BASH: "Bashing",
    tools.APPLY_PATCH: "Patching",
    tools.EDIT: "Editing",
    tools.READ: "Reading",
    tools.WRITE: "Writing",
    tools.TODO_WRITE: "Updating Todos",
    tools.WEB_FETCH: "Fetching Web",
    tools.WEB_SEARCH: "Searching Web",
    tools.AGENT: "Running Task",
    tools.REWIND: "Rewinding",
    tools.ASK_USER_QUESTION: "Questioning",
}


def get_tool_active_form(tool_name: str) -> str:
    """Get the active form of a tool name for spinner status.

    Checks both the static mapping and sub agent profiles.
    """
    if tool_name in _TOOL_ACTIVE_FORM:
        return _TOOL_ACTIVE_FORM[tool_name]

    return f"Calling {tool_name}"


def render_tool_call(e: events.ToolCallEvent) -> RenderableType | None:
    """Unified entry point for rendering tool calls.

    Returns a Rich Renderable or None if the tool call should not be rendered.
    """

    if is_sub_agent_tool(e.tool_name):
        return None

    match e.tool_name:
        case tools.READ:
            return render_read_tool_call(e.arguments)
        case tools.EDIT:
            return render_edit_tool_call(e.arguments)
        case tools.WRITE:
            return render_write_tool_call(e.arguments)
        case tools.BASH:
            return render_bash_tool_call(e.arguments)
        case tools.APPLY_PATCH:
            return render_apply_patch_tool_call(e.arguments)
        case tools.TODO_WRITE:
            return render_todo_write_tool_call(e.arguments)
        case tools.REWIND:
            return render_rewind_tool_call(e.arguments)
        case tools.WEB_FETCH:
            return render_web_fetch_tool_call(e.arguments)
        case tools.WEB_SEARCH:
            return render_web_search_tool_call(e.arguments)
        case tools.ASK_USER_QUESTION:
            return render_ask_user_question_tool_call(e.arguments)
        case _:
            return render_generic_tool_call(e.tool_name, e.arguments)


def _extract_diff(ui_extra: model.ToolResultUIExtra | None) -> model.DiffUIExtra | None:
    if isinstance(ui_extra, model.DiffUIExtra):
        return ui_extra
    if isinstance(ui_extra, model.MultiUIExtra):
        for item in ui_extra.items:
            if isinstance(item, model.DiffUIExtra):
                return item
    return None


def _extract_markdown_doc(ui_extra: model.ToolResultUIExtra | None) -> model.MarkdownDocUIExtra | None:
    if isinstance(ui_extra, model.MarkdownDocUIExtra):
        return ui_extra
    if isinstance(ui_extra, model.MultiUIExtra):
        for item in ui_extra.items:
            if isinstance(item, model.MarkdownDocUIExtra):
                return item
    return None


def render_markdown_doc(md_ui: model.MarkdownDocUIExtra, *, code_theme: str) -> RenderableType:
    """Render markdown document content in a panel with 2-char left indent and top margin."""
    import shutil

    from rich.padding import Padding

    # Limit panel width to min(100, terminal_width) minus left indent (2)
    terminal_width = shutil.get_terminal_size().columns
    panel_width = min(100, terminal_width) - 2

    panel = Panel(
        NoInsetMarkdown(md_ui.content, code_theme=code_theme),
        box=box.SIMPLE,
        border_style=ThemeKey.LINES,
        style=ThemeKey.WRITE_MARKDOWN_PANEL,
        width=panel_width,
    )
    # (top, right, bottom, left) - 1 line top margin, 2-char left indent
    return Padding(panel, (1, 0, 0, 2))


def render_tool_result(
    e: events.ToolResultEvent,
    *,
    code_theme: str = "monokai",
) -> RenderableType | None:
    """Unified entry point for rendering tool results.

    Returns a Rich Renderable or None if the tool result should not be rendered.
    """
    if is_sub_agent_tool(e.tool_name):
        return None

    def wrap(content: RenderableType) -> TreeQuote:
        return TreeQuote.for_tool_result(content, is_last=e.is_last_in_turn)

    # Handle error case
    if e.is_error and e.ui_extra is None:
        return wrap(render_generic_tool_result(e.result, is_error=True))

    # Render multiple ui blocks if present
    if isinstance(e.ui_extra, model.MultiUIExtra) and e.ui_extra.items:
        rendered: list[RenderableType] = []
        for item in e.ui_extra.items:
            if isinstance(item, model.MarkdownDocUIExtra):
                # Markdown docs render without TreeQuote wrap (already has 2-char indent)
                rendered.append(render_markdown_doc(item, code_theme=code_theme))
            elif isinstance(item, model.DiffUIExtra):
                show_file_name = e.tool_name == tools.APPLY_PATCH
                rendered.append(wrap(r_diffs.render_structured_diff(item, show_file_name=show_file_name)))
        return Group(*rendered) if rendered else None

    diff_ui = _extract_diff(e.ui_extra)
    md_ui = _extract_markdown_doc(e.ui_extra)

    def _render_fallback() -> TreeQuote:
        if len(e.result.strip()) == 0:
            return wrap(render_generic_tool_result("(no content)"))
        return wrap(render_generic_tool_result(e.result, is_error=e.is_error))

    match e.tool_name:
        case tools.READ:
            if isinstance(e.ui_extra, model.ReadPreviewUIExtra):
                return wrap(render_read_preview(e.ui_extra))
            return None
        case tools.EDIT:
            return wrap(r_diffs.render_structured_diff(diff_ui) if diff_ui else Text(""))
        case tools.WRITE:
            if md_ui:
                # Markdown docs render without TreeQuote wrap (already has 2-char indent)
                return render_markdown_doc(md_ui, code_theme=code_theme)
            return wrap(r_diffs.render_structured_diff(diff_ui) if diff_ui else Text(""))
        case tools.APPLY_PATCH:
            if md_ui:
                # Markdown docs render without TreeQuote wrap (already has 2-char indent)
                return render_markdown_doc(md_ui, code_theme=code_theme)
            if diff_ui:
                return wrap(r_diffs.render_structured_diff(diff_ui, show_file_name=True))
            return _render_fallback()
        case tools.TODO_WRITE:
            return wrap(render_todo(e))
        case tools.BASH:
            return _render_fallback()
        case tools.WEB_FETCH | tools.WEB_SEARCH:
            display_result = _extract_web_result_for_display(e.result)
            if len(display_result.strip()) == 0:
                return wrap(render_generic_tool_result("(no content)"))
            return wrap(render_generic_tool_result(display_result, is_error=e.is_error))
        case tools.ASK_USER_QUESTION:
            if isinstance(e.ui_extra, model.AskUserQuestionSummaryUIExtra):
                return wrap(render_ask_user_question_summary(e.ui_extra))
            if len(e.result.strip()) == 0:
                return wrap(render_generic_tool_result("(no content)"))
            return wrap(render_ask_user_question_tool_result(e.result, is_error=e.is_error))
        case _:
            return _render_fallback()
