# Third-party software notices

athanor-sdk vendors third-party Lean 4 source code under
`src/kairos/_vendor/`. Each vendored project keeps its upstream
`LICENSE` file unmodified inside its directory. This `NOTICE.md`
records the attribution requirements those licenses impose on
downstream redistribution.

## lean-machines

Source: <https://github.com/lean-machines-central/lean-machines>
License: Apache License, Version 2.0

A Lean 4 framework for the modeling and refinement of stateful
systems, supporting Event-B-style stepwise refinement. Vendored at
`src/kairos/_vendor/lean_machines/` from the upstream `main` branch.
No modifications to the source.

The full Apache-2.0 text is available at
`src/kairos/_vendor/lean_machines/LICENSE` and at
<https://www.apache.org/licenses/LICENSE-2.0>.

## lean-machines-examples

Source: <https://github.com/lean-machines-central/lean-machines-examples>
License: Apache License, Version 2.0

A companion repository providing fully-documented example
specifications (Buffer, MQueue, EventB, Algebraic, VDM) built on
the lean-machines framework. Vendored at
`src/kairos/_vendor/lean_machines_examples/` from the upstream
`main` branch. No modifications to the source.

The full Apache-2.0 text is available at
`src/kairos/_vendor/lean_machines_examples/LICENSE` and at
<https://www.apache.org/licenses/LICENSE-2.0>.

## pythia

Source: <https://github.com/athanor-ai/pythia>
License: Apache License, Version 2.0

A Lean 4 tactic library for closing proofs in probability and
statistics. Specializes Mathlib automation (`simp`, `linarith`,
`aesop`, `bound`, `measurability`) for statistical reasoning, plus
theorem corpora for anytime-valid CS, sequential statistics,
concentration inequalities, and finite-precision quantization.
Vendored at `src/kairos/_vendor/pythia/` from upstream commit
`d99966ac9211b040a4a250ef230bbc178afa5981` (2026-04-26). No
modifications to the source. Mathlib oleans are NOT vendored;
customers pull Mathlib v4.28.0 via Lake at first build time.

The full Apache-2.0 text is available at
`src/kairos/_vendor/pythia/LICENSE` and at
<https://www.apache.org/licenses/LICENSE-2.0>.
