#!/opt/venv/bin/python
"""Container entrypoint for kairos.fleet.ContainerizedDrafter.

Runs as PID 1 inside the fleet-drafter image. Reads a single
`cycle_target` JSON message from stdin, constructs an in-container
StdioProxyClient (which speaks JSON-RPC over stdio to the host
HostLLMProxy), invokes cycle_prove, and writes a single terminal
`cycle_result` JSON message to stdout. Exits 0 on a clean cycle
(closed or not), 1 on protocol / setup errors.

Stdio is line-delimited JSON in both directions. stdout is reserved
for protocol traffic — diagnostic logs go to stderr (which the
caller can capture via `docker run`'s combined output or a tee'd
pipe; HostLLMProxy reads stdout only).
"""
from __future__ import annotations

import json
import os
import sys
import traceback
from dataclasses import asdict
from pathlib import Path


def _err(msg: str) -> None:
    print(f"[drafter-entrypoint] {msg}", file=sys.stderr, flush=True)


def _emit_terminal_error(reason: str) -> None:
    """Write a cycle_result-shaped terminal message that signals a
    setup-side failure. The host parses this as `closed=False` with
    a single fake round whose proof_result.errors carries the reason.
    Lets HostLLMProxy.run() return cleanly instead of raising on EOF.
    """
    payload = {
        "method": "cycle_result",
        "tid": "<entrypoint-error>",
        "closed": False,
        "rounds": [{
            "round": 0,
            "drafter_alias": "entrypoint",
            "candidate": "",
            "proof_result": {
                "compiles": False,
                "has_sorry": False,
                "sorry_count": 0,
                "errors": [f"entrypoint_error: {reason}"],
                "banned": None,
            },
            "wall_sec": 0.0,
            "drafter_resp_meta": {},
        }],
        "total_wall_sec": 0.0,
    }
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def _attempt_to_dict(attempt) -> dict:
    """Serialize one CycleAttempt for the cycle_result payload.

    asdict() handles the dataclass fields except for ProofResult
    enums / non-JSON-safe types. CycleAttempt + ProofResult are
    plain dataclasses with primitive fields so asdict round-trips
    cleanly today; this wrapper exists so future field additions
    that aren't JSON-safe (Path, datetime) get caught here rather
    than crash the host.
    """
    return asdict(attempt)


def main() -> int:
    # 1. Read the single initial cycle_target message from stdin.
    init_line = sys.stdin.readline()
    if not init_line:
        _err("stdin closed before cycle_target message arrived")
        _emit_terminal_error("no cycle_target message; stdin EOF")
        return 1
    try:
        init = json.loads(init_line)
    except json.JSONDecodeError as e:
        _err(f"first stdin line was not JSON: {e}")
        _emit_terminal_error(f"invalid JSON on first stdin line: {e}")
        return 1
    if not isinstance(init, dict) or init.get("method") != "cycle_target":
        _err(f"first message must have method=cycle_target; got {init!r:.200}")
        _emit_terminal_error("first message method != cycle_target")
        return 1

    # 2. Imports deferred until after we've confirmed protocol is
    # alive — gives the host a useful terminal message even if the
    # SDK install is broken inside the image.
    try:
        from kairos.lean_cycle import CycleTarget, cycle_prove
    except Exception as e:
        _err(f"kairos.lean_cycle import failed: {type(e).__name__}: {e}")
        _emit_terminal_error(f"kairos.lean_cycle import: {type(e).__name__}: {e}")
        return 1
    try:
        from kairos.fleet.stdio_proxy import StdioProxyClient
    except Exception as e:
        # StdioProxyClient is research's deliverable per ATH-749 split.
        # If it's missing, fail loudly with a recognizable reason so
        # CI output is unambiguous.
        _err(f"kairos.fleet.stdio_proxy import failed: {type(e).__name__}: {e}")
        _emit_terminal_error(
            f"kairos.fleet.stdio_proxy.StdioProxyClient missing — research-side "
            f"deliverable for ATH-749 not yet wired ({type(e).__name__}: {e})"
        )
        return 1

    # 3. Build the CycleTarget. The host serializes a CycleTarget by
    # converting `lake_project: Path` to a string. We re-hydrate to
    # a Path here. If the host decides to bind-mount a different
    # path inside the container than on the host, it sets
    # `target.lake_project` to the in-container path before serialize.
    raw = init.get("target")
    if not isinstance(raw, dict):
        _emit_terminal_error("cycle_target.target must be a dict")
        return 1
    try:
        target = CycleTarget(
            tid=raw["tid"],
            imports=list(raw.get("imports", [])),
            opens=list(raw.get("opens", [])),
            header=raw["header"],
            lake_project=Path(raw["lake_project"]),
            module_path=raw["module_path"],
            scratch_namespace=raw.get(
                "scratch_namespace", "Pythia.Scratch.SwarmDogfood"
            ),
            timeout_per_attempt=int(raw.get("timeout_per_attempt", 180)),
        )
    except (KeyError, TypeError, ValueError) as e:
        _emit_terminal_error(f"CycleTarget construction failed: {type(e).__name__}: {e}")
        return 1

    # 4. Build the in-container drafter — speaks stdio JSON-RPC back
    # to the host on every .call(). The host pipes this container's
    # stdout into HostLLMProxy and writes responses to stdin.
    model_id = init.get("model_id")
    if not isinstance(model_id, str) or not model_id:
        _emit_terminal_error("cycle_target.model_id missing")
        return 1
    try:
        client = StdioProxyClient(
            model_id=model_id,
            request_pipe=sys.stdout,
            response_pipe=sys.stdin,
        )
    except Exception as e:
        _emit_terminal_error(
            f"StdioProxyClient construction failed: {type(e).__name__}: {e}"
        )
        return 1

    # 5. Run cycle. Any exception here is reported via terminal message.
    drafter_alias = init.get("drafter_alias", "drafter")
    max_rounds = int(init.get("max_rounds", 4))
    temperature = float(init.get("temperature", 0.0))
    max_tokens = int(init.get("max_tokens", 800))

    try:
        result = cycle_prove(
            target,
            drafter=client,
            drafter_alias=drafter_alias,
            max_rounds=max_rounds,
            temperature=temperature,
            max_tokens=max_tokens,
        )
    except Exception as e:
        tb = traceback.format_exc()
        _err(f"cycle_prove raised: {tb}")
        _emit_terminal_error(
            f"cycle_prove raised: {type(e).__name__}: {e!s:.300}"
        )
        return 1

    # 6. Emit terminal cycle_result. The audit/ bind-mount (when
    # present) gets a JSONL copy of the per-round attempts so the
    # ATH-739 mining cron can pick them up off the host filesystem
    # — we never trust the in-container audit log alone.
    payload = {
        "method": "cycle_result",
        "tid": result.tid,
        "closed": result.closed,
        "rounds": [_attempt_to_dict(a) for a in result.rounds],
        "total_wall_sec": result.total_wall_sec,
    }
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()

    audit_dir = os.environ.get("DRAFTER_AUDIT_DIR", "/workspace/audit")
    if os.path.isdir(audit_dir):
        try:
            audit_path = Path(audit_dir) / f"{result.tid}-{drafter_alias}.jsonl"
            with audit_path.open("w") as f:
                for attempt in result.rounds:
                    f.write(json.dumps(_attempt_to_dict(attempt)) + "\n")
        except OSError as e:
            _err(f"audit log write failed (non-fatal): {e}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
