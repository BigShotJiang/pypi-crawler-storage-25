# Customer Onboarding Guide

How to get a customer from zero to seeing their verification runs on
the Tahoe dashboard.

## Prerequisites

- Customer has received their **ATHANOR_SYNC_TOKEN** from Athanor
- Customer has Python 3.10+ installed
- For hardware verification: EBMC installed (`apt install ebmc` or
  Docker image `ghcr.io/athanor-ai/hw-cbmc:latest`)
- For Lean proofs: Lean 4 + elan installed

## Step 1: Install the SDK

```bash
pip install athanor-kairos
```

Verify the install:

```bash
kairos --version
kairos doctor
```

`kairos doctor` checks for available verification engines (EBMC, Lean,
ACL2) and reports which are installed.

## Step 1.5: Bring your own LLM credentials

`simple_prove` and `prove` call an LLM provider. The SDK supports six
customer-facing provider paths; pick **one** + set its env vars. Bedrock
is the recommended path for Amazon-shape customers.

### AWS Bedrock (recommended for Amazon)

```bash
export KAIROS_ANTHROPIC_BACKEND=bedrock
export AWS_BEDROCK_REGION=us-west-2          # or AWS_REGION / AWS_DEFAULT_REGION
# AWS credentials via standard AWS chain - pick ONE:
#   (a) env keys
export AWS_ACCESS_KEY_ID=AKIA...
export AWS_SECRET_ACCESS_KEY=...
#   (b) named profile from ~/.aws/credentials
export AWS_PROFILE=your-profile
#   (c) IAM role attached to the EC2 instance / Lambda execution
```

Models available: `anthropic/claude-sonnet-4-6`, `anthropic/claude-opus-4-6`.
Bedrock typically does not deploy `claude-haiku-4-5`; pass an explicit
`model="anthropic/claude-sonnet-4-6"` to `simple_prove`.

### Anthropic - direct API

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# Do NOT set ANTHROPIC_BASE_URL - that switches to the Azure path.
```

### Anthropic - your own Azure tenant

```bash
export ANTHROPIC_API_KEY=<your-azure-tenant-key>
export ANTHROPIC_BASE_URL=https://<your-resource>.services.ai.azure.com/anthropic
```

The `azure` substring in `ANTHROPIC_BASE_URL` is the discriminant; the
SDK auto-routes through the Azure path.

### OpenAI - direct API

```bash
export OPENAI_API_KEY=sk-...
```

### Azure-OpenAI compatible (KIMI / Mistral)

```bash
export OPENAI_API_KEY=<your-azure-key>
export OPENAI_API_BASE=https://<your-resource>.services.ai.azure.com/models
```

### Google Gemini

```bash
export GEMINI_API_KEY=AIza...
# Or: export GOOGLE_API_KEY=AIza...
```

### Verify before launch

```bash
python -m kairos doctor
```

Programmatic equivalent (callable from a notebook):

```python
import kairos
print(kairos.help())
models = kairos.list_available_models()  # returns only models you can call
```

`kairos.list_available_models()` is the canonical "what can I pick?"
surface - it returns only models whose provider check is green, so
customer agent code (and MCP integrations) never asks for a model that
will 401/404.

### Routing collisions (avoid)

`kairos doctor` and `kairos.detect_routing_collisions()` flag these
explicitly; surfacing them up front beats discovering them as opaque
litellm errors at first call:

| Symptom | Cause | Fix |
|---|---|---|
| `api-version query parameter not allowed when using /v1 path` | `ANTHROPIC_BASE_URL` (Azure) AND `AZURE_OPENAI_BASE_URL` set | Pick one; unset the other. |
| Bedrock used unexpectedly | `KAIROS_ANTHROPIC_BACKEND=bedrock` AND `ANTHROPIC_BASE_URL=...azure...` | Pick one; unset the other. |
| Direct used unexpectedly | `ANTHROPIC_API_KEY=sk-ant-...` AND `KAIROS_ANTHROPIC_BACKEND=bedrock` | Unset `ANTHROPIC_API_KEY` (Bedrock uses AWS credentials). |
| Default `claude-haiku-4-5` 404 on Azure | Haiku not deployed in your Azure tenant | Pass `model="anthropic/claude-sonnet-4-6"`, or query `kairos.list_available_models()` first. |

## Step 2: Configure the sync token (paid tier only)

> **Paid-tier feature.** The Tahoe dashboard requires a paid sync token
> + an org scope. Free-tier customers can skip this step; runs land in
> a local journal at `~/.athanor/runs/<run_id>/events.jsonl` instead.

Set the sync token so traces flow to Tahoe:

```bash
export ATHANOR_SYNC_TOKEN="<token-from-athanor>"
export NEXT_PUBLIC_SUPABASE_URL="https://<your-project>.supabase.co"
```

Without these, the SDK falls back to the local JSONL journal (free-tier
default; zero phone-home). With them, every `kairos.session()` /
`kairos.observe.observe()` writes trace events to your Tahoe org.

### Sink routing waterfall (3 tiers)

`kairos` resolves the trace sink with a fixed waterfall:

1. **`SUPABASE_URL` + `ATHANOR_SYNC_TOKEN` set** → `SupabaseTraceSink` (paid, dashboard-visible)
2. **Else (default)** → `JsonlTraceSink` writing to `~/.athanor/runs/<run_id>/events.jsonl` (free, local-only)
3. **`KAIROS_TRACE_STRICT=1` + missing creds** → loud `TraceSinkUnavailable` raise (CI / fleet-VM mode)

`kairos doctor` reports which tier resolved + why. Run it before any
prove call.

> ⚠️ **Env-resolved-at-import-time gotcha**. Set the env vars BEFORE
> `import kairos` (in your shell or `.env`). If you set them in Python
> code AFTER the first kairos call, the sink may already be cached at
> the wrong tier and your events go to the journal silently. Restart
> Python or set the env in `~/.bashrc`.

## Step 3: Run your first verification

### Hardware (SystemVerilog)

```python
from kairos.sv import prove

result = prove(
    "my_design.sv",
    top_module="my_module",
    bound=10,
)
print(f"Proved: {result.proved}, Refuted: {result.refuted}")
```

For multi-file designs:

```python
result = prove(
    ["cpu_pkg.sv", "cpu_top.sv", "formal_wrapper.sv"],
    top_module="formal_wrapper",
    bound=10,
    flatten=True,  # preprocess packed structs for EBMC
)
```

### Lean theorem proving

```bash
kairos simple-prove "for all natural numbers n, n + 0 = n"
```

Or programmatically:

```python
from kairos import simple_prove_template

result = simple_prove_template("the sum of two even numbers is even")
print(result["summary"])
```

## Step 4: View results on Tahoe (paid tier only)

> **Paid-tier feature.** Requires Step 2 sync-token setup + an org scope.
> Free-tier customers can inspect the local JSONL journal at
> `~/.athanor/runs/<run_id>/events.jsonl` directly.

Open `tahoe.athanor-ai.com` and log in with your Cloudflare Access
credentials. Two surfaces:

- **Runs** - every `kairos.session()` / `kairos.observe.observe()` lands
  on `/solve-runs/[run_id]` with full event traces
- **Analytics** - cross-run metrics + per-vertical surfaces

### What `/solve-runs/[run_id]` renders

Every kairos run - paid orchestrator path or free-tier observe-only -
gets a detail page at `/solve-runs/<run_id>`. The page assembles
several sections from the trace events landed in your sink:

1. **Header banner** discloses the routing path used:
   - `Observe-only run` banner when no parent `solve_runs` row was
     written (free-tier `kairos.observe.observe()` path; events came
     from sink only). Hero metrics + artifacts render as empty because
     they live on the parent row.
   - No banner when the row exists (paid `kairos.session()` path).
2. **Run intent card** - vertical / run_subtype / target_module +
   trigger source. Surfaces the run's *kind* at a glance.
3. **Pipeline I/O summary** - `input_artifact_uris` + `output_artifact_uris`
   from the auto-emitted `agent_start` + `pipeline_complete` events.
   Renders an honest-disclosure variant ("not captured for this run shape")
   when neither event emitted (legacy / pre-`agent_start` runs).
4. **Hero metrics row** - wall time, started, finished, ship-gate verdict
   when present. Empty fields render as `-` rather than zero (honest-
   framing rule: never fabricate a value the engine didn't produce).
5. **Engine versions chip row** - every engine that recorded a version
   surfaces with `engine=version` chip. Cross-run reproducibility signal.
6. **What happened panel** - plain-English outcome story derived from
   `pipeline_complete.outcome` + `outcome_reason`. When outcome is
   non-`succeeded` and `outcome_reason` is undefined, the page renders
   `· reason: not captured` rather than silent (per ATH-1038).
7. **Agent trace pane** - every recognized event type renders as a
   per-event card with timestamp + a fleet-role chip (`[research]` /
   `[cto]` / `[qa]` / `[platform]`) when `fleet_agent_role` is set.
   Recognized event types:

   - `agent_start` / `agent_handoff` / `agent_message` / `pipeline_complete`
     - fleet-coordination narrative
   - `fleet_agent_message` - cross-agent posts via agent-msg / slack-bot
   - `lean_solve_attempt` - top-level kairos.prove() solve with
     `path_taken` + n_sub_solves + cost
   - `lean_race_attempt` - race result with `winner` chip + n_drafters
     + closed-clean / open status
   - `cycle_prove_attempt` - per-drafter cycle wrap-up with
     drafter_alias + rounds_run / max_rounds + final_score
   - `verify_proof_attempt` - per-draft compile attempt with
     compile-fail / has_sorry chips + collapsible errors_head
8. **Artifacts list** - every uploaded file with a 1-hour signed-URL
   download link.

### Per-run-type render-path table

| Run shape                              | API route                                | Page                                       |
|----------------------------------------|------------------------------------------|--------------------------------------------|
| Any kairos run (universal catch-all)   | `/api/solve-runs/[run_id]`               | `/solve-runs/[run_id]`                     |
| SEC closed-loop iteration arc          | `/api/analytics/sec-closed-loop/[run_id]`| `/analytics/sec-closed-loop/[run_id]`      |
| D-spike per-property invariant_gen     | `/api/analytics/invariant-gen/[run_id]`  | `/analytics/invariant-gen/[run_id]`        |
| `kairos.prove_batch` aggregate         | `/api/analytics/batch-run/[batch_run_id]`| `/analytics/batch-run/[batch_run_id]`      |
| Free-tier observe-only (no parent row) | same `/solve-runs/[run_id]` (catch-all)  | same `/solve-runs/[run_id]` (event-only)   |

Sibling routes are *enhanced* per-vertical surfaces that render the
canonical iteration arc / per-property tree / batch tile grid. The
universal catch-all at `/solve-runs/[run_id]` always works for every
run regardless of vertical - same URL contract whether your run shape
has a special-purpose surface or not.

### Customer-as-orchestrator: parent-child run linkage

When you wrap each MCP `lean_solve` / `lean_race` / `prove_batch` call
in `observe(parent_run_id=parent_id, ...)`, the children link to the
parent's run_id through `agent_start.payload.parent_run_id`. The
dashboard side reads that linkage to render the tree:

- `/analytics/batch-run/[batch_run_id]` - `kairos.prove_batch` shape:
  6-tile aggregate header (closed / refuted / errored / timeout / wall /
  cost) + per-target tile grid; each tile click drills into
  `/solve-runs/<child_run_id>`. Honest-framing chips: `partial_failure`
  disclosure lines, `dropped_field_count` chip on shape drift.
- `/analytics/decomposition/[parent_run_id]` (queued, ATH-1042) -
  recursive customer-as-orchestrator shape: parent + N sub-lemma
  children rendered as a tree, each child's verdict chip + winner
  drafter alias visible at-a-glance.

Every per-call run still has its own `/solve-runs/[run_id]` page; the
parent-rooted views compose those individual pages into the customer-
trust artifact.

### Honest-framing carry-throughs you'll see on tahoe

The dashboard mirrors the SDK's honest-framing discipline so customer
reads exactly what the engine produced - never fabricated:

- `outcome: errored · reason: AuthenticationError: ...` - qa ATH-1038
  derives `pipeline_complete.outcome` from underlying `tier_verdict`
  events. No silent succeeded-on-actually-errored.
- `path: not_a_sorry` chip when the orchestrator bailed because target
  file lacked a sorry to fill in (vs opaque `failed`).
- `UNPROVEN - assumed; v0 D-spike` badge on bridge invariants whose
  Lean theorem doesn't yet discharge structurally.
- `dropped_event_count` / `truncated` / `is_event_only` chips when the
  underlying event stream had any drift, gap, or shape concern. Surface
  the gap; never silent-render-as-if-everything-is-fine.

### Worked example: gamma_monotone closure (research dogfood, 2026-05-05)

Run `0663963e-cb13-4358-aa9d-32804b9b7e01` was research's first
customer-as-orchestrator MCP race that closed a real Lean theorem
(γ_k ≤ γ_{k+1} via `div_le_div_iff + nlinarith`). View at
`tahoe.athanor-ai.com/solve-runs/0663963e-cb13-4358-aa9d-32804b9b7e01`.

What renders:

- Observe-only run banner (free-tier path)
- `theorem_proving · mostly verify_proof_attempt` run intent card
- Pipeline I/O honest-disclosure (legacy pre-1027 emit shape)
- Agent trace pane with **fleet roles legend** showing `[research]`
  chip + `↳ subagent` reference
- 8 event cards in chronological order:
  - 4× `VERIFY PROOF ATTEMPT` cards from Flash and Sonnet's per-round
    compile attempts (1.23s / 1.11s / 1.20s for Flash; 13.75s for
    Sonnet's slower attempt) - each with score / module_path /
    collapsible errors_head
  - 2× `CYCLE PROVE ATTEMPT` cards (per-drafter cycle wrap-ups with
    `drafter_alias: flash` / `drafter_alias: sonnet` + `rounds_run: 3
    / 3` + `final_score: 0.25` / `1.00`)
  - 1× `LEAN RACE ATTEMPT` card with **`winner: flash`** chip +
    `CLOSED-CLEAN` chip + `n_drafters: 2` + `wall_seconds: 18.71` +
    `cost_usd: 0.0234`

The customer-trust signal: race shape, two-drafter parallelism, Flash
beating Sonnet on Mathlib-named-lemma class via cheap-multi-attempt
strategy - *all rendered in the dashboard without a single line of
prose explanation*. Click into any per-attempt card to see the full
candidate text + tactic that was tried.

### Quick verification recipe (for new customers)

After your first `kairos.prove()` / `lean_race` / `prove_batch` call
returns:

```bash
# 1. Note the run_id from the return value (or kairos.observe.context().run_id)
run_id="<from your code>"

# 2. View on tahoe (paid tier)
open "https://tahoe.athanor-ai.com/solve-runs/${run_id}"

# 3. Or inspect the JSONL journal directly (free or paid)
cat ~/.athanor/runs/${run_id}/events.jsonl | jq '.event_type'
```

If your dashboard view shows `Observe-only run` banner: your run
landed via the free-tier `kairos.observe.observe()` path and tahoe is
rendering the events directly from your sink. If you don't see a
banner, your run wrote a parent `solve_runs` row + you're on the paid
orchestrator path.

If your view 404s: check the journal first (`ls ~/.athanor/runs/`);
then run `python -m kairos doctor` to see your sink resolution. The
universal catch-all at `/solve-runs/[run_id]` works for any run that
emitted ≥1 event; 404 means events didn't reach the sink (Gap C / D /
E class - see Step 2 sink-routing-gotcha).

## Step 5: MCP server for AI agents (Claude Code, Cursor, etc.)

`kairos mcp serve` exposes the SDK's verification tools as MCP tools so
your AI agent can call them directly. This is the canonical
**customer-as-orchestrator** path: your agent decomposes a hard theorem
into sub-lemmas, dispatches each via MCP, composes the closed proofs.

### Install + setup

```bash
pip install athanor-kairos[mcp]   # mcp extra: includes the MCP transport
```

Add to your agent's MCP config (e.g. `~/.claude/.mcp.json` for Claude
Code, or the Cursor / Continue equivalent):

```json
{
  "mcpServers": {
    "kairos": {
      "command": "kairos",
      "args": ["mcp", "serve"],
      "env": {
        "ANTHROPIC_API_KEY": "${ANTHROPIC_API_KEY}",
        "ATHANOR_SYNC_TOKEN": "${ATHANOR_SYNC_TOKEN}",
        "NEXT_PUBLIC_SUPABASE_URL": "${NEXT_PUBLIC_SUPABASE_URL}",
        "KAIROS_FLEET_ROLE": "customer"
      }
    }
  }
}
```

Restart your agent. The kairos tools appear in the tool list.

### Tool surface

| Tool | Tier | When to use |
|---|---|---|
| `simple_prove_template` | free | Plain-English claim against built-in Pythia patterns. Single shot. |
| `lean_verify` | free | Verify a Lean proof candidate you already have. |
| `lean_check_signature` | free | Typecheck a theorem signature. |
| `dispatch` | free | Generic per-target drafter dispatch. |
| `verify_batch` | free | Bulk-verify a directory of `.lean` files. |
| `certify` | free | Axiom-clean certificate generation. |
| `lean_race` | paid | Race N drafters in parallel; first axiom-clean wins. |
| `lean_solve` | paid | Cheap-first → race → decompose-hints OR internal-recurse. |
| `sv_prove` | paid | RTL/SystemVerilog property proof via EBMC. |
| `sv_cegar` | paid | CEGAR-based invariant discovery on RTL. |

### Customer-as-orchestrator pattern (kairos MVP)

The default flow expects YOU (the customer agent) to drive
decomposition. kairos provides muscle: drafter race, single-target
proof close, axiom audit. You provide context: which Mathlib lemmas
exist, which sub-goals decompose cleanly, how to compose.

```python
# In your agent's reasoning loop:

# 1. You read the sorry'd theorem
target = read_lean_theorem("Pythia/Stats/MatrixBernstein.lean", "bernstein_master_bound")

# 2. You decompose using your own reasoning (Mathlib knowledge,
#    prior failures, hypothesis structure)
sub_lemmas = [
    "trace_mul_comm: tr(AB) = tr(BA)",
    "psd_sum_psd: PSD A + PSD B = PSD (A+B)",
    "concentration_bound: ||X - E[X]|| <= 2 sigma sqrt(log(2/delta))",
]

# 3. Dispatch each sub-lemma via MCP `lean_race`
for sub in sub_lemmas:
    result = mcp_call("lean_race", target=sub, drafters=["sonnet", "flash"], max_rounds=3)
    # result.closed: bool ; result.first_closer_alias: str ; result.closing_candidate: str

# 4. You compose the closed proof terms
final_proof = compose_proof(sub_results)

# 5. MCP `lean_verify` validates the composed proof
verdict = mcp_call("lean_verify", proof_code=final_proof)
```

Production strategy validated 2026-05-05 (gamma_monotone closed via
`lean_race[Sonnet, Flash]`):

- **Flash + cheap-multi-attempt wins on Mathlib-named-lemma class**
  (sub-goals closeable by `div_le_div_iff` / `nlinarith` / `positivity`
  / `linarith`). 3 attempts in 3.5s cumulative beats one Sonnet attempt
  in 13.75s.
- **Sonnet for proof composition** (the outer "stitch sub-lemmas
  together" step where context awareness matters).
- **lean_race** when unsure which class - parallelism decides.

### Black-box-orchestrator alternative

If you want kairos to drive decomposition internally instead of returning
hints to YOUR agent, pass `internal_planner_model="anthropic/claude-opus-4-6"`
to `lean_solve`. Cheaper customer-side context, but kairos burns its own
Opus call per decomposition step. Customer-as-orchestrator is the
default + recommended path.

### Preflight check

```bash
python -m kairos doctor
```

Reports per-provider green/red + the resolved sink class. Run this
BEFORE any agent run; surfaces missing env vars + routing collisions
before the agent burns time on a 401.

## What the customer sees vs what is internal

Customers see only:
- **Runs**. their org's solve_runs with full trace events
- **Analytics**. aggregated metrics for their org
- **Download**. proof artifact bundles

Customers do NOT see:
- Research pages (proofs, anti-cheat)
- Data pages (environments, eval runs)
- Other organizations' data

All access is scoped by organization. The sync token determines
which org the traces belong to.

## Troubleshooting

### "No EBMC binary found"

Install EBMC:
```bash
# Ubuntu/Debian
sudo apt install ebmc

# Or use Docker
export EBMC_DOCKER_IMAGE=ghcr.io/athanor-ai/hw-cbmc:latest
```

### "ATHANOR_SYNC_TOKEN not set"

Traces run locally without the token. To see them on Tahoe, set
the token in your shell or `.env` file.

### "Lean not found"

Install Lean 4 via elan:
```bash
curl -sSf https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh
```

### Multi-file designs fail to parse

Use `flatten=True` to preprocess packed struct member access for
EBMC 5.x compatibility:

```python
prove(["pkg.sv", "top.sv"], top_module="top", flatten=True)
```

Or pass files via a filelist:

```python
prove("top.sv", filelist="filelist.f", top_module="top")
```
