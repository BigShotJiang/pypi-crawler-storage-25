# athanor-sdk, Free vs Paid Tier Model

**Audience:** product + engineering. This is the source-of-truth doc
for what `athanor-sdk` offers in its free tier versus its paid tier.

**Status:** v1 draft, Sam-directed (ts=1777180974). asabi-aligned
on the headline split (ts=1777180186). Sam-flagged additions on
free-tier-as-standalone (ts=1777180555) + bundled OSS SDKs
(ts=1777180555) + all-local persistence (ts=1777180974).

**Implementation parent:** ATH-675.

---

## 1. Headline

`athanor-sdk` ships as **a single PyPI artifact** with **two tiers**
gated at runtime via `kairos.license_scope`. There is **no separate
PyPI package** (`athanor-sdk-pro`, etc.) and no private index. The
tier separation is enforced by license claims, not by code distribution.

**Free tier** is a full verification toolkit: anyone can
`pip install athanor-sdk` and use it to verify Lean proofs, generate
hardware assertions from Lean specs, run multi-prover smokes on
toy theorems, and inspect their own LLM call costs locally, without
paying us anything. All output stays on the customer's machine.

**Paid tier** is an end-to-end automated proof and verification
service: the customer hands us a hypothesis, our proprietary
Orchestrator dispatches across LLMs and provers, retries
intelligently, and lands a closed proof; runs surface in our cloud
dashboard with full audit + analytics. Paid customers also get
production-grade RTL verification (CEGAR with k-induction,
mutation-kill invariant discovery, multi-abstraction swarm
exploration) and a customer-support contract.

**Why this split:** free customers can evaluate the SDK in <5
minutes on a real theorem. They upgrade when they want *us* to
close real customer-grade theorems and want auditability through
our dashboard. Sentry pattern: free SDK + paid backend; the
backend is the differentiator.

---

## 2. Free tier, exhaustive feature list

Anyone with `pip install athanor-sdk` gets all of the following.
Output stays local (`~/.athanor/runs/<run_id>/` by default).

### 2.1 Lean proof verification

`kairos.lean.*`, Apache-2.0 wrapper over the Lean toolchain.

| Function | What it does |
|----------|--------------|
| `verify_proof(code, lake_project=None, module_path=None, timeout=600)` | Compiles a Lean proof string. Returns `ProofResult` with `compiles`, `has_sorry`, `sorry_count`, `score` (0.0-1.0), `errors`, `banned`. Supports both bare-file mode and lake-project mode (uses customer's own Lean toolchain + Mathlib). |
| `check_sorry(code)` | Returns `(has_sorry: bool, sorry_count: int)`. Used by lints + scorers to flag in-flight proofs. |
| `score_proof(code, timeout=600)` | Numeric quality score: 1.0 (full proof, no sorry, no banned), 0.35 (partial), 0.25 (compile error), 0.0 (banned construct or unparseable). |
| `predicate_verify(...)` | Higher-order: prove a decidable predicate `∀ x, P x` by enumeration. |
| `sample_generator(...)` | Sample terms from a Lean type for testing or property fuzzing. |
| `check_banned(code)` | Static regex check for banned constructs (axiom, Mathlib import on bare-file mode, unsafe def, `@[init]`). |

**Use case:** customer has Lean code, wants to know if it compiles
+ whether it's a real proof. Identical to a CI gate in their own
Mathlib repo.

### 2.2 Lean spec → hardware verification (lean-machines × EBMC)

`kairos.lean_machines.*`, Apache-2.0 corpus + bridge to EBMC.
Just-shipped 2026-04-26 (ATH-657). Killer free-tier feature.

| Function | What it does |
|----------|--------------|
| `to_sva(lean_module, machine_name, rtl_signal_map, *, clk=None, rst=None)` | Extracts every `invariant` clause from a `lean-machines` Event-B-style Machine and emits a SystemVerilog assertion. Supports `@(posedge clk) disable iff (rst)` wrapper for synchronous designs. |
| `k_induction_strengthen(abstract_machine, machine_name, rtl_signal_map)` | Proof-grade `assume property(...)` strengthening hypotheses extracted from the lean-machines refinement structure. Replaces LLM-guessed CEGAR strengthening. |
| `splice_strengthening(spec_sv, strengthening, output=None)` | Prepends generated `assume` clauses inside the top module body of a customer's `.sv` file. Comment-aware regex (skips `//` + `/* */`). |
| `parse_cex_trace(cex_block)` | Parses an EBMC counterexample block (5.4 + 5.10 formats) into per-cycle state-assignment dicts. |
| `cex_to_lean_refutation(ebmc_stdout, abstract_machine, machine_name, rtl_signal_map, *, verify=True)` | Lifts an EBMC counterexample into a Lean witness term that formalizes the impossibility. v1 emits a `sorry`-bearing scaffold; full mechanization tracked under ATH-661+1. |
| `run_refinement_chain(chain)` | Builds each refinement level of a vendored chain (e.g. `Buffer0 → Buffer1 → Buffer2`) via `lake build`. |

**Use case:** customer writes their high-level functional spec as a
Lean machine; SDK auto-generates SystemVerilog assertions for EBMC
to verify against the customer's RTL. End-to-end "Lean spec → proven
RTL" pipeline. No proprietary code from us; it's stitching together
the customer's own toolchain.

**Vendored Apache-2.0 source:** `kairos/_vendor/lean_machines/` (50
files, 692K) + `kairos/_vendor/lean_machines_examples/` (Buffer
chain only, 92K, narrowed scope per ATH-657 sub-a). Attribution in
repo-root `NOTICE.md`.

### 2.3 Cython-compiled scoring + lint

`kairos.scoring.score(...)` and `kairos.lint.lint_lean(...)`.
Cython source private (.pyx never ships); only `.so` binaries in
the wheel. Customer can't reverse-engineer our scoring weights or
banned-construct list without disassembly.

**Use case:** integrate scoring + lint into the customer's own CI.

### 2.4 Trace + observability primitives (local-only)

| API | What it does |
|-----|--------------|
| `kairos.observe(run_id=, model=)` | Context manager that wraps an `litellm.completion(...)` call. Captures duration + cost (from `usage.total_cost`) + model + tokens. Writes to local journal by default. Sentry-pattern: free SDK + paid backend; the wrapper is free. |
| `kairos.session(task_id=, run_subtype=)` | Context manager opening a "session", groups multiple LLM/prover calls under one `run_id`. Stamps event sequence + writes events to the local output directory. |

**Use case:** customer instruments their own LLM agent (verification
or otherwise), wants per-call cost / latency tracking. They get the
data; *we don't see it* unless they upgrade.

### 2.5 Bundled open-source verticals (Sam-directed, Aidan-narrowed scope)

**Aidan-ratified ts=1777184500: just Pythia in default bundle. Cedar AND telos behind `pip install athanor-sdk[...]` extras.** Tighter than asabi's draft (cedar was originally default). Pythia is the killer free-tier hook (Lean stats library, `kairos init --lean-pythia` bootstrap demo); cedar + telos move to opt-in to keep the default wheel lean.

| Vendored project | Default? | Install command | Sub-vertical |
|--------|----------|-----------------|---------|
| `kairos.lean_machines` (lean-machines + lean-machines-examples) | ✅ default | `pip install athanor-sdk` | Hardware verification, Lean spec → SVA → EBMC. Already shipped, see §2.2. |
| `kairos.pythia` (kairos-stats-lean) | ✅ default | `pip install athanor-sdk` | Lean stats library: anytime-valid CS, e-detectors, Bernstein/Bennett/Freedman concentration, sequential testing. *Killer free-tier demo via `kairos init --lean-pythia`.* |
| `kairos.cedar` (kairos-cedar bridge) | ❌ extra | `pip install athanor-sdk[cedar]` | Cedar policy authorization verification (customer writes policy → SDK proves authz decisions match the spec). Enterprise authz vertical. |
| `kairos.telos` (telos) | ❌ extra | `pip install athanor-sdk[telos]` | YAML→multi-prover DSL (customer writes `.yaml` spec; SDK compiles to Lean 4 + Dafny + EBMC + Hypothesis + CPU-sim cross-checks). Networking / congestion-control vertical (FMCAD 2026 paper material). |

**Mechanics:** vendor each under `kairos/_vendor/{lean_machines,pythia,cedar,telos}/` following the lean-machines pattern shipped 2026-04-26. Preserve upstream LICENSE files + NOTICE.md attribution per Apache-2.0 §4(c). Default wheel size estimate: ~3-5 MB (vs the 25 MB ceiling); cedar + telos extras keep the default bundle lean.

**For pythia specifically:** vendor only the `.lean` source files. NOT the Mathlib oleans (those pull on customer-side via Lake at first build). This keeps the default-bundled pythia footprint small.

### 2.6 Simple-prover mode (Sam-directed addition)

`kairos prove --simple` (or Python: `kairos.simple_prove(hypothesis,
target_file, model="anthropic/claude-sonnet-4-6")`), single-LLM,
single-shot, no retries, no multi-prover dispatch.

**Closes ~50-60% of theorems** that the paid `Orchestrator` would
close at ~85-90%. Gives free customers an end-to-end "give me a
theorem, here's a closed proof" experience without exposing the
proprietary tier-planning IP. The gap (50-60% vs 85-90%) is the
upgrade hook.

**Implementation:** thin wrapper around `verify_proof` + a single
`litellm.completion(...)` call. Reuses the existing prompt scaffolds
in `kairos.prove` but skips the `Orchestrator.plan(...)` step.

### 2.7 Batch verification CLI (Sam-directed addition)

`kairos verify-batch <dir> [--out report.csv]`, scores every `.lean`
file in a directory, writes a CSV report. Useful for academic /
research customers who want bulk numbers.

**Output columns:** `path, compiles, has_sorry, sorry_count, score,
banned, errors_first_line, elapsed_sec`.

### 2.8 Local report rendering (Sam-directed addition)

`kairos report <run_id> [--out report.html]`, renders a single-page
HTML report from the local `~/.athanor/runs/<run_id>/` directory.
Self-serve audit trail without our cloud dashboard.

**Sections:** run metadata, total cost, per-event timeline, generated
artefacts (SVAs, Lean code, refutations), EBMC outputs, refinement
chain status. Static HTML + inline CSS; no external dependencies.

### 2.9 Read-only CLI commands

| Command | What it does |
|---------|--------------|
| `kairos run` | Self-hosted runner (relays sessions; doesn't call models itself). |
| `kairos run-summary` | Summarizes a run from local journal data. |
| `kairos replay` | Re-emits journalled events (e.g. for debugging or re-rendering reports). |
| `kairos runs list` | Lists all `~/.athanor/runs/<run_id>/manifest.json` entries. |
| `kairos init --lean-pythia` | Bootstraps a starter Lean project (lakefile + smoke files + pythia dependency). *asabi's killer-demo idea: customer closes a Lean theorem with `by z3_check` in 1 line.* |

### 2.10 Public types

`kairos.types.*`, `ScoreResult`, `TaskConfig`, `ProofResult`,
`ProveResult`, `Session`, `Verdict`, `OrchestrationChoice`,
`RefinementHop`, `SvaAssertion`, `LeanRefutation`. Pure data classes
+ TypedDicts; customers write integrations against them.

### 2.11 Not in free tier

Free customers explicitly **do not get**:

- The `kairos.fleet.Orchestrator` LLM tier-planner, multi-LLM
  selection, model spreading, retry strategy. *Proprietary IP.*
- Full `kairos.prove()` / `kairos.solve()` / `kairos.cegar()`
  pipelines (gated already by `require_product("solve")`).
- `kairos.sv.*` SystemVerilog research stack (CEGAR loop, swarm,
  invariants, hazard graphs). Already paper-priority deny-listed.
- `SupabaseTraceSink` writes to *our* prod Supabase. Customers can
  configure their own Supabase URL via `KAIROS_TRACE_SUPABASE_URL`
  + `ATHANOR_SYNC_TOKEN` for self-hosted dashboards if they want; we
  only gate writes to `*.athanor-ai.com` URLs.
- Customer support contract.

---

## 3. Paid tier, exhaustive feature list

Customer obtains a license file (`~/.athanor/license.json` with
`products=["solve"]`). All free-tier features stay; paid adds:

### 3.1 Auto-prover

`kairos.prove(hypothesis, vertical, target_file, *,
budget_usd=10.0)`, full Tier 1 pipeline. Internally:

1. `nl_to_intent(hypothesis)`, natural language → IntentV1 spec.
2. `Orchestrator.plan(...)`, emits `OrchestrationChoice` (tier
   dispatch order, tool selection, model selection per tier,
   prompt selection, rationale).
3. `SpecPipeline.run(...)`, iterates tiers, dispatches each
   verifier plugin, threads per-hop results, halts on first
   non-proved verdict.
4. Returns `ProveResult(outcome, reason, score, cost_usd, tier,
   details)`.

**This is what customers buy.** They don't have to know which LLM,
which prover, which strategy. The Orchestrator picks for them.

### 3.2 LLM tier-planning Orchestrator

`kairos.fleet.Orchestrator(model=, worker_models=, config=)`.
LLM-backed tier planner. T=0 LLM call per intent that ingests:

- `{intent_summary}`, what the customer is trying to prove
- `{tier_table}`, available verifier tiers (lean_proved,
  bmc_kind, lean_machines_proved, etc.)
- `{tool_list}`, available tools (lean-lsp-mcp, ebmc, z3, dafny)
- `{worker_table}`, available worker models (Claude Sonnet,
  Gemini Pro, Kimi-K2, Mistral)
- `{budget_usd}`, cost cap

Outputs strict JSON `OrchestrationChoice` with rationale. **Cached
by `(intent_hash, tier_set, tool_set)` with TTL 5 min.** Graceful
fallback to `DefaultRoundRobinOrchestrator` on LLM failure.

When `worker_models` supplied (≥2), the planner steers DIFFERENT
workers to DIFFERENT tiers in `model_selection` (Lean proofs to
Claude, BMC to Kimi, etc.) for tier-specialization.

**v1.1 follow-up:** Cython port of `Orchestrator` to ship binary-only.
Currently `.py` source ships but is in the paid-license-gated path,
so customers without a license can't import it cleanly anyway.

### 3.3 Multi-level refinement chain (lean-machines × RTL)

`OrchestrationChoice.refinement_chain: tuple[RefinementHop, ...]`.
when set, `SpecPipeline.run` iterates a multi-level Lean → ... →
RTL chain in order, threading per-hop verdict.details. Halts at
first non-proved.

**Customer scenario:** prove M0 (functional ISA-level Lean machine)
→ M1 (pipeline) → M2 (microarch) → M3 (RTL Verilog). lean-machines
proves M0→M1→M2 mechanically; EBMC handles M2→M3.

### 3.4 Production RTL verification stack

`kairos.sv.*`, SystemVerilog research-grade verification, behind
the paper-priority deny-list:

| Module | What it does |
|--------|--------------|
| `kairos.sv.cegar.cegar(spec, top_module, bound, max_iter=5, budget_usd=5.0)` | Full CEGAR loop with k-induction. LLM proposer for invariant strengthening; vacuity-gated candidates. Lean-derived strengthening (free-tier `kairos.lean_machines.k_induction_strengthen`) preferred when available. |
| `kairos.sv.swarm.cycle_swarm(...)` / `state_swarm(...)` | Cycle/state exploration. Splices probes/counters/gates; runs EBMC on each variant. |
| `kairos.sv.invariants.discover_invariants(...)` | Reverse-mutation-kill invariant discovery. |
| `kairos.sv.multi.run_multi(...)` | Multi-abstraction layer verification. |
| `kairos.sv.hb_*` | Hazard-graph extraction + SVA emission. Pending paper-arxiv-id (ATH-453). |

**Use case:** customer has production RTL (CPU pipeline, network
chip, accelerator), wants high-assurance verification beyond
hand-written assertions. The CEGAR loop converges where bare BMC
or k-induction wouldn't.

### 3.5 Cloud dashboard

Runs land on `tahoe.athanor-ai.com/solve-runs/<run_id>`. Includes:

- Swarm matrix visualization (with help-text, pending ATH-672 fix)
- Per-event timeline with cost rollup (pending ATH-671 fix on the
  swarm-driver side)
- Ship-gate verdict (when `kairos.spec.pipeline.SpecPipeline.run`
  populates it; pending ATH-670 fix)
- CEX inspector with linked source lines
- Trace export (CSV / JSONL)

**Authentication:** `ATHANOR_SYNC_TOKEN`, issued per organization.
Resolves to `organization_id` via the SDK's credential waterfall
(kwarg → env → token → ~/.athanor/license.json).

### 3.6 SupabaseTraceSink writes (cloud trace ingest)

`kairos.trace.SupabaseTraceSink`, writes to our prod Supabase.
Required for cloud dashboard surfacing. Free customers' data stays
local; paid customers' data is local-AND-cloud (so the customer
keeps their own copy too, never lose data even if our dashboard
goes down).

**License gate:** `SupabaseTraceSink.open_run(...)` calls
`require_product("solve")` if the configured Supabase URL matches
`*.athanor-ai.com`. Self-hosted Supabase URLs (different host)
allowed without license, customers can run their own private
dashboard if they prefer. *(This dual-mode behavior is the v1
implementation; ATH-675 will wire it.)*

### 3.7 Customer-support contract

Out of band. Sales / ops decision; not implemented in code.

---

## 4. Local output directory layout (free + paid)

Both tiers write to `~/.athanor/runs/<run_id>/` by default. Override
via `KAIROS_LOCAL_OUTPUT_DIR=/path/to/dir`. Per-run subtree:

```
~/.athanor/runs/<run_id>/
├── manifest.json           # {run_id, started_at, finished_at,
│                           #  total_cost_usd, outcome,
│                           #  tier ("free" or "paid"), license_subject}
├── traces.jsonl            # every event the SDK would have sent
│                           # to Supabase, written line-by-line locally
├── generated/
│   ├── sva/                # SVA assertions emitted by to_sva()
│   ├── lean/               # Lean code emitted by cex_to_lean_refutation
│   ├── refutations/        # Lean refutation files
│   └── strengthening/      # spliced .sv files from splice_strengthening
├── ebmc/
│   ├── <call_n>.stdout     # raw EBMC stdout per call
│   ├── <call_n>.stderr
│   └── counterexample_<n>.txt   # extracted CEX block
├── lake/                   # `lake build` output if Lean tasks ran
└── report.html             # auto-rendered when `kairos report` invoked
```

**Privacy:** *free* customers' data stays on their box. Nothing
goes to us unless they upgrade and configure `ATHANOR_SYNC_TOKEN`.
*Paid* customers' data lives both locally + on our prod Supabase;
they always have a backup.

**Reproducibility win:** when a customer hits a bug, they can hand
us their `~/.athanor/runs/<run_id>/` directory + `pip install
athanor-sdk==<version>` reproduces the exact run.

---

## 5. License gate mechanism

`kairos.license_scope` (ATH-389) handles runtime enforcement.
Post-ATH-686 (PR #221, merged 2026-04-26) the gate is **fail-closed**:
a missing license file raises `LicenseScopeError` rather than passing
silently. License claims in `~/.athanor/license.json`:

```json
{
  "subject": "acme-corp",
  "organization_id": "11111111-1111-1111-1111-111111111111",
  "products": ["solve", "envs"],
  "envs": ["sysverilog", "neuron-nki"],
  "expires_at": "2027-01-01T00:00:00Z",
  "signature": "..."
}
```

| Claim | What it gates |
|-------|---------------|
| `products: ["solve"]` | The whole paid-tier surface (`prove()`, `solve()`, `cegar()`, `Orchestrator`, `kairos.sv.*`, `SupabaseTraceSink` writes to `*.athanor-ai.com`). |
| `products: ["envs"]` | Required to instantiate any `kairos.env.Environment` (gates the env builder API even when the customer has named the env in `envs`). |
| `envs: ["sysverilog", ...]` | Specific verticals (a customer with `["neuron-nki"]` cannot instantiate `Environment("sysverilog")`). |
| `expires_at` | Past-tense rejects the license with a renewal CTA. Must include a timezone offset (P2 fix). |
| `organization_id` | Carried into audit-log rows + serves as the SDK→DB join key (asabi onboarding seam). |

**Fail-closed (post-ATH-686):**
- Missing `~/.athanor/license.json` → `LicenseScopeError` with email CTA. No silent permissive.
- Forged license file (signature mismatch) → `LicenseScopeError`. The `_internal_dev_bypass` marker is a constructor-only field; forging `__dev_bypass__: true` in license.json content cannot flip it.
- Expired license → `LicenseScopeError` with renewal CTA.
- Wrong product / wrong env → `LicenseScopeError` with upgrade CTA.

**Internal CI bypass:** `KAIROS_DEV_NO_LICENSE=1` env var bypasses both
gates. NOT documented for customers. Soft gate at v1.0; v1.1 will
replace with a build-time-baked token rotated per release.

**Signature verification:** `kairos.sdk_security.verify_license_signature`
(ATH-369) is wired into `load_license`. Currently in grace-period mode
(`KEYS_PROVISIONED=False` in `kairos/_keys/__init__.py`); a `WARNING`
log line fires on every load + the cryptographic check is skipped, so
the policy gate alone defends. Grace period closes on ATH-689 Sam-OPS
GPG provisioning, which blocks v1.0 customer onboarding by design.

**Audit log (ATH-690, PR #222):** every gate decision (`require_product`,
`require_env_access`, `load_license` fail-closed branches) emits one
row to `~/.athanor/audit.jsonl` always, plus to the Supabase
`license_gate_decisions` table when `ATHANOR_SYNC_TOKEN` is set. Schema
pinned to platform's CHECK enums; deny rows are forensically
critical and treated as long-retention.

**Threat model:** `docs/security-model.md` covers the full table
(forged license, stolen file, license sharing, revocation, replay,
etc.) with current defense + future plan per row.

**Cython IP fence:** for the IP-sensitive bits we want binary-only
(scoring weights, lint banned-construct list, future Orchestrator
internals), we ship `.cpython-*.so` files and exclude the `.pyx`
source from the wheel. Already in place for `_lint_impl.pyx` +
`_scoring_impl.pyx`. Extension to `Orchestrator` is the v1.1
follow-up.

---

## 6. Implementation plan

### v1.0, tier launch (target: athanor-sdk 0.5.0)

1. **Audit `kairos.__all__` + classify each entry as free/paid.**
   Output: a markdown table in this doc + an audit Linear ticket
   pinning the classification. Sub-ticket of ATH-675.
2. **Add `require_product("solve")` gates** where missing on the
   paid surface (`prove()`, `Orchestrator.__init__`,
   `orchestrate()`, `SupabaseTraceSink.open_run` when URL matches
   `*.athanor-ai.com`). Sub-ticket of ATH-675.
3. **Build `kairos prove --simple` + Python `simple_prove(...)`**
  , single-LLM, no retries, free tier. Sub-ticket.
4. **Build `kairos verify-batch <dir>`**, bulk Lean verification
   + CSV report. Sub-ticket.
5. **Build `kairos report <run_id>`**, local HTML report renderer.
   Sub-ticket.
6. **Build `kairos init --lean-pythia`**, starter Lean project
   bootstrap (lakefile + smoke files + pythia dep). Sub-ticket.
7. **Vendor kairos-cedar + pythia** under `kairos/_vendor/`
   following the lean-machines pattern. Default-bundle (small).
   Sub-ticket per vendored project.
8. **Vendor telos as optional extra** (`pip install
   athanor-sdk[telos]`), has Docker dep, too big to default-bundle.
   Sub-ticket.
9. **README rewrite**, tier model + free-vs-paid feature matrix +
   upgrade path + bundled-OSS attribution. Sub-ticket.
10. **CHANGELOG: 0.5.0 tier-launch announcement.** Sub-ticket.

### v1.1, IP hardening (target: athanor-sdk 0.5.1, post-launch)

11. **Cython port for `Orchestrator`**, proprietary tier-planning
    IP ships binary-only. Adds `.pyx` + extends `hatch_build.py`
    custom hook + cibuildwheel test-import update. Sub-ticket.

### v2, speculative

- Per-feature license claims (e.g. `products=["orchestrator",
  "rtl"]` separate) if a customer asks for raw orchestrator access
  without RTL. Today: fold into `"solve"`.
- Enterprise SSO / private-PyPI-index split if a customer's
  procurement flow demands it.

---

## 7. Regression safety

Sam-flagged constraint (ts=1777180974): "make sure while you make
changes you absolutely do not introduce new bugs or regressions."

**Mechanical guardrails:**

- Every implementation sub-ticket lands as its own PR with **green
  CI** before admin-merge.
- `tests/test_lean_machines.py` (36 tests, all green) + the
  rest of the existing 2700+ test suite is the floor, nothing
  merges with a delta in pass-count.
- New features land with new tests covering the happy path + at
  least 2 error/edge cases each.
- License gate additions: **defensive default**, when the gate's
  intent is ambiguous, do nothing (fall through). Better to
  silently allow than silently deny in dev.
- Bundled OSS vendor commits: zero modifications to upstream source
  (Apache-2.0 §4(c) + reproducibility). Add `NOTICE.md` entries
  per vendored project.
- The free-tier `simple_prove(...)` cannot regress the paid
  `prove()`, keep `simple_prove` in its own callsite, just call
  the underlying primitives.
- All work driven through the existing fleet protocols (asabi
  approval for cross-cutting; research dogfood for Lean changes;
  platform skim for trace-sink changes).

**Pre-launch full smoke** (after all v1 sub-tickets land):

- Free tier: `pip install athanor-sdk==0.5.0rc1` on a fresh Py
  3.10 / 3.11 / 3.12 / 3.13 venv; `kairos init --lean-pythia` →
  `kairos verify-batch ./examples` → `kairos report <run_id>`.
  Expect zero crashes, zero leaked-license errors.
- Paid tier: same, with a test license file at
  `~/.athanor/license.json`. Run a real `prove()` end-to-end.

---

## 8. asabi-resolved decisions (ts=1777181383)

| # | Question | Resolution | Lane |
|---|----------|------------|------|
| 1 | Bundled scope | **Aidan-ratified ts=1777184500: just Pythia in default bundle; cedar AND telos behind extras** (`pip install athanor-sdk[cedar]` / `[telos]`). Aidan tightened asabi's recommendation, Pythia is the killer free-tier hook (Lean stats library, init-lean-pythia bootstrap demo); cedar + telos move to opt-in to keep the default wheel lean. | Aidan-ratified |
| 2 | Wheel-size budget | **Aidan-ratified ts=1777184500: ≤25 MB total wheel.** Per Aidan's Q1 narrowing: default wheel = lean-machines (~800K) + pythia `.lean` source only (NOT Mathlib oleans, those pull on customer-side via Lake at build time). cedar + telos in extras → no default-budget impact. Net default wheel size estimate: ~3-5 MB (vs the 25 MB ceiling). | Aidan-ratified |
| 3 | `simple_prove` default model | Haiku 4.5, config-overrideable. simple_prove is mechanical-CRUD-shape (per fleet routing rule); Sonnet 4.6 overkill. Anthropic default minimizes auth-key surface area. Customers without Anthropic key fall back via `kairos.config.set_simple_prove_model("gemini-flash")`. Document in §3 as part of `simple_prove` API. | asabi-call (final) |
| 4 | Cython port scope (v1.1) | Just `Orchestrator` for v1.1. `kairos.fleet.*` waits for v1.2+. Orchestrator carries the proprietary tier-planning IP (the swap-test claim from the paper-contribution rule); fleet.* is multi-agent infra, lower IP-sensitivity. One module at a time keeps build complexity bounded. | asabi-call (final) |
| 5 | License-key delivery flow | **Sam-ratified ts=1777183391: contact-us via email at `aidan@athanorl.com`**, sales-led custom pricing (overrides asabi's self-serve Stripe). Each customer hits a `LicenseScopeError` CTA when they try a paid feature; the message points to the email; Sam manually issues YAML license keys after the discovery conversation. Per-customer pricing reflects different value extraction (research lab vs enterprise CPU vendor). Self-serve Stripe deferred to v2+ (or never if the sales-led model holds). | Sam-ratified |

**Sam-ratify lane (Q1, Q2, Q5):** product-surface decisions; Sam can override.

**asabi-locked (Q3, Q4):** technical/IP calls per asabi authority.

### Pythia dual-namespace clarification (asabi-flagged addition)

`Pythia` (Lean library, capitalized) is the canonical Lean-native
source, installed via `require pythia from git ...` in the
customer's lakefile.

`kairos.pythia` (Python module, lowercase) is the SDK-side wrapper
that vendors a known-good snapshot of the `.lean` source under
`kairos/_vendor/pythia/`. The SDK wrapper exposes Python helpers
(parsers, compilers, scaffolders) over the vendored Lean code.

These are independent paths. Customers who want raw Pythia drop the
git dependency in their lakefile. Customers who want SDK-integrated
Pythia (with batch-verify, scoring, tracing) use `kairos.pythia.*`.
The vendored snapshot may lag the upstream `Pythia` git head by
days; we sync each minor SDK release.

---

## 9. FAQ (for README rewrite)

**Q: How do I install?**
A: `pip install athanor-sdk`. That gets you the free tier.

**Q: How do I upgrade to paid?**
A: Email aidan@athanorl.com. We'll deliver a license file you
drop at `~/.athanor/license.json`.

**Q: What happens to my data?**
A: Free tier, stays 100% on your machine in
`~/.athanor/runs/<run_id>/`. Paid tier, stored locally AND
synced to our cloud (`tahoe.athanor-ai.com`) so you can see your
runs in the dashboard.

**Q: Can I use this for production?**
A: Free tier, for evaluation, prototyping, and academic use. Paid
tier, production-grade with customer-support contract.

**Q: Can I run a private cloud?**
A: Yes (paid tier feature). Configure `KAIROS_TRACE_SUPABASE_URL`
to your own Supabase instance and the SDK writes there instead of
ours. Self-hosted dashboard separate.

**Q: What's vendored Apache-2.0 source?**
A: `kairos/_vendor/lean_machines/`, `kairos/_vendor/cedar/`,
`kairos/_vendor/pythia/`. Each has its upstream LICENSE preserved
inside; repo-root `NOTICE.md` lists all attributions.

**Q: Wait, `Pythia` (Lean) vs `kairos.pythia` (Python). Which do I use?**
A: Two separate paths, both supported. *Raw Pythia*, drop
`require pythia from git ...` in your lakefile + import the Lean
modules directly. Use this if you're a Lean-native customer who
just wants the proof library. *SDK-integrated `kairos.pythia`*.
use the Python wrapper (`from kairos import pythia`) for
batch-verify, scoring, tracing, and report-rendering on top of
Pythia proofs. The wrapper vendors a known-good snapshot of the
Lean source under `kairos/_vendor/pythia/`; the snapshot may lag
the upstream `Pythia` git head by days, synced each minor SDK
release. (Same model for `kairos.lean_machines` ↔ upstream
`lean-machines` and `kairos.cedar` ↔ upstream `cedar-spec`.)

**Q: Will the free tier always be free?**
A: We don't plan to change the free-tier feature set. New paid
features will be added to the paid tier; free-tier features stay
where they are.

---

## 11. Public API audit (kairos.__all__ free/paid classification)

**Purpose.** Source-of-truth table mapping every entry in
`kairos.__all__` (and every public method on classes exported there)
to its tier classification + license-scope-gate status. Drives the
v1.2 gate-wiring work (ATH-677), the v1.3 free-tier helper (ATH-678),
and the v1.6 local-output-dir defaults (ATH-681).

**Audit performed against:** `src/kairos/__init__.py` at v0.4.1
(latest main 2026-04-27). 23 public names total.

**Three classifications named in the ATH-676 spec, plus one
unavoidable fourth.** ATH-676 named: `free`, `paid (require_product("solve"))`,
`paid (license-gated SupabaseTraceSink only)`. The `kairos.Environment`
RL-env factory is gated on a *separate* product, `envs`, via
`require_env_access(env_name)` (the legacy env-quality lane that
predates the solve product split). We list it explicitly as
`paid (require_env_access(env_name))` to avoid hiding the dual-product
reality behind a "TBD."

**Gate-status column:**
- `already-gated`: a `require_product`/`require_env_access` call exists
  in the entry's `__init__`, function body, or transitively-reachable
  constructor.
- `transitively-gated`: no direct gate, but the entry's first useful
  call instantiates or dispatches into something that is gated. ATH-677
  may want to add an explicit early-fail gate at the public surface
  for clearer error messages and lower latency-to-rejection. Flagged
  per-entry below.
- `needs-gate`: paid surface with no gate of any kind today. ATH-677
  must wire one before v1 ships.
- `n/a`: free surface, or pure data type (no behavior to gate).

### 11.1 `__all__` entries

| Public name | Kind | Tier | Gate status | Source |
|---|---|---|---|---|
| `make` | function (factory) | `paid (require_env_access(env_name))` | already-gated (transitive via `Environment.__init__`) | `kairos/__init__.py:33` |
| `Environment` | class | `paid (require_env_access(env_name))` | already-gated | `kairos/env.py:42`, gate at `:71` |
| `ScoreResult` | dataclass | `free` | n/a (pure type) | `kairos/types.py` |
| `TaskConfig` | dataclass | `free` | n/a (pure type) | `kairos/types.py` |
| `verify_proof` | function | `free` | n/a | `kairos/lean.py:279` |
| `check_sorry` | function | `free` | n/a | `kairos/lean.py` |
| `score_proof` | function | `free` | n/a | `kairos/lean.py:633` |
| `ProofResult` | dataclass | `free` | n/a (pure type) | `kairos/lean.py:35` |
| `simple_prove` | function | `free` | n/a | `kairos/simple_prove.py:99` |
| `SimpleProveResult` | dataclass | `free` | n/a (pure type) | `kairos/simple_prove.py:51` |
| `prove` | function | `paid (require_product("solve"))` | already-gated | `kairos/prove.py:215`, gate at `:277` |
| `session` | context manager | `paid (require_product("solve"))` | already-gated | `kairos/prove.py:545`, gate at `:620` |
| `ProveResult` | dataclass | `free` | n/a (pure type; methods are pure formatting) | `kairos/prove.py:105` |
| `Session` | class | `paid (require_product("solve"))` | already-gated (transitive via `session()`, which is the only public construction path) | `kairos/prove.py:324` |
| `litellm_trace_session` | context manager | `free (wrapper)` + `paid (license-gated SupabaseTraceSink only)` for the *sink write* when the configured Supabase URL matches `*.athanor-ai.com` | wrapper: n/a; sink: **needs-gate** (ATH-677 step 3) | `kairos/observe.py:648` |
| `observe` | context manager | `free (wrapper)` + `paid (license-gated SupabaseTraceSink only)` for the *sink write* when the configured Supabase URL matches `*.athanor-ai.com` | wrapper: n/a; sink: **needs-gate** (ATH-677 step 3) | `kairos/observe.py:786` |
| `Orchestrator` | class | `paid (require_product("solve"))` | already-gated (`__init__`) | `kairos/fleet/orchestrator.py:105`, gate at `:156` |
| `orchestrate` | function | `paid (require_product("solve"))` | **needs-gate** at function entry. Currently transitively-gated via `Orchestrator(...)` instantiation, which raises only after partial setup. ATH-677 to add explicit early-fail gate. | `kairos/fleet/orchestrator.py:356` |
| `gpt2_bpe_to_utf8` | function | `free` | n/a (pure post-decode helper) | `kairos/tokenizer.py:61` |
| `lean_machines` | module | `free` | n/a (whole module free per §2: vendored Apache-2.0 + the `to_sva` bridge) | `kairos/lean_machines.py` |
| `to_sva` | function | `free` | n/a | `kairos/lean_machines.py:223` |
| `SvaAssertion` | dataclass | `free` | n/a (pure type) | `kairos/lean_machines.py:167` |
| `__version__` | string constant | `free` | n/a (constant) | `kairos/__init__.py:30` |

### 11.2 Public methods on exported classes

The ATH-676 spec asks for "every public method on classes exported
[in `__all__`]." Methods on free classes are free; methods on paid
classes are paid (the surface inherits the class's tier through
construction). Specific public methods worth naming for ATH-677's
gate-wiring scope:

| Class.method | Kind | Tier | Gate status | Source |
|---|---|---|---|---|
| `Environment.reset` | method | paid (transitive; Environment is gated at construction) | already-gated | `kairos/env.py:157` |
| `Environment.score` | method | paid (transitive) | already-gated | `kairos/env.py:208` |
| `Environment.run` | method | paid (transitive) | already-gated | `kairos/env.py:282` |
| `Environment.cleanup` | method | paid (transitive) | already-gated | `kairos/env.py:419` |
| `Session.prove` | method | paid (transitive; Session constructed only via gated `session()`) | already-gated | `kairos/prove.py:450` |
| `Session.emit` | method | paid (transitive) | already-gated | `kairos/prove.py:380` |
| `Session.outcomes` | method | paid (transitive; pure read of internal state) | already-gated | `kairos/prove.py:445` |
| `Session.summary` | method | paid (transitive) | already-gated | `kairos/prove.py:484` |
| `Orchestrator.orchestrate` | method | paid (transitive; Orchestrator gated at `__init__`) | already-gated | `kairos/fleet/orchestrator.py:170` |
| `ProveResult.refined_prompt_suggestion` | method | free (pure formatting on returned dataclass) | n/a | `kairos/prove.py` |

No methods identified that need a *separate* gate beyond their owning
class's gate. Transitive gating via the constructor is sufficient
for the paid classes; the rest are free pure-data methods.

### 11.3 Summary counts

- **Free entries:** 14 (7 functions / context managers, 6 dataclasses + types, 1 constant)
- **Paid `solve`-gated entries:** 6 (`prove`, `session`, `Session`, `Orchestrator`, `orchestrate`, plus the SupabaseTraceSink writes triggered through `litellm_trace_session` / `observe`)
- **Paid `envs`-gated entries:** 2 (`make`, `Environment`)
- **Mixed (free wrapper, paid sink):** 2 (`litellm_trace_session`, `observe`; the API surface is free, the cloud-write side-effect is paid)

**Needs-gate count for ATH-677:**
- `orchestrate()`: explicit early-fail gate (currently transitive only)
- `SupabaseTraceSink.open_run`: license check when URL matches `*.athanor-ai.com` (per §3.6 of this doc)

Everything else with a paid classification already has a gate that
fires before any meaningful work is done. ATH-677 should be a
two-call diff at minimum, plus tests; expand-scope to "add explicit
gate to every paid public surface for consistency" if asabi/qa
prefers a uniform contract.

### 11.4 Maintenance contract

When a new entry lands in `kairos.__all__`, this table MUST be
updated in the same PR. The audit is the input to ATH-677's
gate-wiring; if a new paid surface ships without a row here, the
gate will be missed and the surface will leak the paid product to
free customers. Recommended check: a CI test that loads
`kairos.__all__` and asserts every name is present in this table
(future v1.x add, out of scope for ATH-676, but a clean follow-up).

---

*Last updated: 2026-04-27 by builder per ATH-676 (audit kairos.__all__ + classify each entry). Adds §11 audit table covering 23 `__all__` entries + 10 public methods on exported classes. Surfaces two needs-gate items for ATH-677 (`orchestrate()` early-fail, `SupabaseTraceSink.open_run` URL gate). Previous: 2026-04-26 by qa (hongsksam) per Sam-directive ts=1777180974, etc.*
