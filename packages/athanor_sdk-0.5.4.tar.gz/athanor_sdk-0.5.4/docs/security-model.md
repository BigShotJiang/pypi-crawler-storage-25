# Athanor SDK security model

The paid tier of the Athanor SDK gates access through a license file at
`~/.athanor/license.json`. This document is the threat model that
customers, security reviewers, and future maintainers should consult
when they want to know what the gate defends against. and, equally
important, what it does not.

Last reviewed 2026-04-26 after ATH-686 PR 1 (`#221`) shipped fail-closed
license enforcement and ATH-690 PR 2 (`#222`) added per-decision audit
logging.

## Two layers, both run on every paid-tier callsite

1. **Cryptographic gate** (`kairos.sdk_security.verify_license_signature`).
   The license file carries a detached GPG signature; the SDK ships the
   Athanor public key + expected fingerprint under `kairos/_keys/`;
   verification proves the license was issued by Athanor and not forged.
2. **Policy gate** (`kairos.license_scope.require_product` /
   `require_env_access`). The verified license carries `products` (which
   SKUs the customer bought), `envs` (specific verticals), and
   `expires_at`. The policy gate rejects expired licenses, missing
   claims, and dev-mode bypass attempts.

Both layers run before any paid programmatic surface (`kairos.prove`,
`kairos.session`, `kairos.fleet.Orchestrator`, every entry point under
`kairos.sv.*`) executes any work.

## Threat table

| Threat | Current defense | Status | Future plan |
|---|---|---|---|
| Forged license file | GPG signature verification rejects any license not signed by the Athanor key whose fingerprint matches `EXPECTED_FINGERPRINT` | Defended once `KEYS_PROVISIONED=True` (see grace-period note below) | Hardware-secured key rotation per ATH-689 |
| Expired license | `_parse_expires_at` enforces `expires_at` with a timezone-aware comparison; the gate raises `LicenseScopeError` with a renewal CTA pointing at `aidan@athanorl.com` | Defended | Auto-renewal flow at v1.5 |
| Wrong product / wrong env | Policy gate denies with a clear "license does not grant access to product 'X'" message + upgrade CTA | Defended |. |
| Forged dev-bypass | The `_internal_dev_bypass` marker lives on a constructor-only `License` field that `_parse` never sets. A customer crafting `{"__dev_bypass__": true, ...}` in their license.json gets parsed as a normal license with empty `products` and is denied | Defended (ATH-686 P0 fix, PR #221) |. |
| Stolen license file (machine-locking) | None today. A copied `~/.athanor/license.json` works on any machine | Accepted for v1 | Per-machine binding via TPM / secure-enclave attestation evaluated for v2 |
| License sharing across machines | None today. A leaked license file is silently usable in parallel by multiple parties | Detection-only via audit log (ATH-690 PR 2) | Per-customer concurrent-use telemetry pulled from `license_audit_events` Supabase table; abuse pattern review is post-customer-#1 work |
| License revocation | None today. A revoked license remains usable until its natural `expires_at` | Accepted for v1 | v2 will pull a revocation list from a known URL on every gate call (or every N seconds via cache) |
| Internal CI bypass abuse | `KAIROS_DEV_NO_LICENSE=1` is a documented internal bypass, not customer-facing. The env var is NOT mentioned in customer-facing docs; no support article references it | Soft gate at v1.0 | v1.1 replaces with a build-time-baked token rotated per release. The dev-bypass branch will then require both the env var AND the matching token, defeating the "set the env var" leak path |
| Replay of an old, signed license | The signature is over the file content, so we trust whatever `expires_at` Athanor signed at issue time. A customer who saved an older, longer-expiry signed license could in theory replay it | Tolerable in v1 (signing happens manually per Sam, no expiry-update reissues yet) | v1.5: revocation list (above) covers this |
| Audit-log tampering | The local journal at `~/.athanor/audit.jsonl` is not append-only at the OS level. a customer can edit or delete it. Customers inspect their own log with `kairos audit show [--since 7d] [--denied] [--gate <name>]` | Accepted for v1 (audit log is forensic infra, not enforcement) | The Supabase mirror (when `ATHANOR_SYNC_TOKEN` is configured) is the tamper-resistant copy fleet-side; customer-side rows are convenience |
| Network-attached gate bypass | The gate decision NEVER depends on network. license parsing + signature verification are local-only. A customer who blocks all egress traffic still gets correctly enforced gates (and a local-only audit log) | Defended by design |. |

## Grace-period mode (current state, 2026-04-26)

`kairos._keys` ships with `KEYS_PROVISIONED = False` and a placeholder
public key. License signature verification is *skipped* during this
period; the policy gate alone defends. This means:

- A forged `license.json` carrying `{"products": ["solve"], ...}` would
  silently pass the cryptographic gate and be checked against policy
  alone. and policy alone has no way to distinguish a real license
  from a forged one.
- A `WARNING` log line is emitted on every fresh `load_license` call
  during this period: `"kairos._keys reports KEYS_PROVISIONED=False.
  license signature verification skipped."`
- The local audit-log journal records every gate decision regardless,
  so post-hoc forensics work even during the grace period.

The grace period closes when ATH-689 (Sam-OPS GPG key provisioning)
ships. That sub-ticket blocks customer #1 onboarding by design. the
SDK is not safe to ship to a paying customer with `KEYS_PROVISIONED=False`.

Customers can verify which mode they're running in by:

```python
import kairos._keys
print(kairos._keys.KEYS_PROVISIONED)
```

A `True` return means the bundled key is real and signature verification
is active; `False` means grace-period mode.

## Out-of-scope (explicitly)

The following are NOT defenses we make and customers should not assume
otherwise:

- **Code obfuscation / DRM** of the SDK itself. The `_scoring_impl.c` /
  `_lint_impl.c` Cython compilations protect specific proprietary
  algorithms but are not a general anti-reverse-engineering measure.
- **Egress controls** on what the SDK contacts. The SDK ships with
  `NoopTraceSink` as the customer default. zero phone-home. but
  customers can override and customers running with
  `ATHANOR_SYNC_TOKEN` set DO upload trace events. Audit-log Supabase
  emit follows the same opt-in.
- **Anti-abuse rate limiting** at the gate level. A customer with a
  valid license can hit `require_product` ten million times a second
  and the gate will not slow down (the cache is a perf feature, not a
  rate-limit). Network-side rate limits live in the platform.

## Where to file security issues

Email `aidan@athanorl.com` with subject `[Security] Athanor SDK …`. We
do not maintain a public bug bounty at this time; high-severity findings
will be acknowledged within 48 hours.

## Cross-references

- ATH-369. `verify_license_signature` (cryptographic gate)
- ATH-389. `require_product` / `require_env_access` (policy gate)
- ATH-686. fail-closed license + signature-verify wiring (PR `#221`)
- ATH-686 P0. unforgeable dev-bypass via constructor-only field
- ATH-686 P1. paid-API gate coverage (`kairos.prove`, `Orchestrator`,
  every `kairos.sv.*` entry)
- ATH-686 P2. timezone-aware `expires_at` validation
- ATH-689. Sam-OPS GPG key provisioning (closes the grace period)
- ATH-690. audit log on every license-gate decision (PR `#222`,
  schema pinned to platform's `license_gate_decisions` migration via
  PR `#226` + column-name pin via PR `#229`)
- `kairos audit show`. customer-self-service audit-log inspection
  CLI (PR `#227`)
- ATH-692. lean_machines API discoverability (`list_refinement_chains()`
  + `to_sva()` Examples block) (PR `#228`)
- `docs/license-schema.md`. `license.json` field reference
