# `~/.athanor/license.json` - schema reference

The license file is GPG-signed by Athanor and installed via the enterprise tarball's `install.sh`. It carries both cryptographic proof (verified by [ATH-369](../src/athanor/sdk_security.py)) and scope claims (enforced by [ATH-389](../src/athanor/license_scope.py)).

## Schema

```json
{
  "org": "acme-corp",
  "products": ["envs", "solve"],
  "envs": ["neuron-nki", "sysverilog"],
  "expires": "2027-01-01T00:00:00Z"
}
```

| Field | Type | Required | Purpose |
|:-|:-|:-|:-|
| `org` | string | yes | Customer organisation slug. Appears in telemetry + bundle receipts. |
| `products` | `string[]` | yes | SKUs the customer bought. Currently recognised: `"envs"`, `"solve"`. |
| `envs` | `string[]` | yes | Environment slugs this customer may instantiate (only checked when `"envs"` is in `products`). |
| `expires` | ISO-8601 string | no | Optional expiry. Enforced by ATH-369 signature-path checks, not by this scope module. |

Additional keys are preserved (stored on `License.raw`) but not currently enforced.

## Enforcement points

| Codepath | Check | Where |
|:-|:-|:-|
| `Environment(env_name)` | `require_env_access(env_name)` | `src/athanor/env.py` |
| `athanor solve --vertical ...` (ATH-386) | `require_product("solve")` | *Deferred to follow-up PR on top of ATH-386* |
| Future `athanor.solve.Solver(...)` | `require_product("solve")` | - |

## Dev-mode fallthrough

If `~/.athanor/license.json` does not exist, every check passes. This keeps internal CI + agent-fleet workflows working without shipping a test license everywhere. Customer installs always receive a license in their tarball.

## Example error (customer sees)

```
LicenseScopeError: license does not grant access to environment 'sysverilog'.
  Licensed environments: neuron-nki.
  Contact @athanor-ai to license this env.
```

## Caching

The license is parsed once and cached in-process. The cache invalidates automatically when `license.json`'s mtime changes; tests can force a reload with `ATHANOR_LICENSE_RELOAD=1` or `clear_license_cache()`.

## Relationship to signature verification

Scope enforcement (ATH-389) and signature verification (ATH-369) are complementary and both run at their respective enforcement points:

- **Signature verification** answers *"is this license really from Athanor?"*
- **Scope enforcement** answers *"does this license grant access to this codepath?"*

Today we only call `verify_license_signature` from `athanor spec submit`. A customer who forges `license.json` without the signature will pass scope checks but be caught at submit-time before anything expensive runs. Running signature-verify on every `Environment` construction is a future hardening.
