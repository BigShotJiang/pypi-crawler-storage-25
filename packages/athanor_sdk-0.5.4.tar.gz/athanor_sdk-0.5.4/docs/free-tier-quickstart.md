# Athanor SDK free-tier quickstart

The Athanor SDK ships a free tier that lets you verify properties of
your code in plain English. You never have to write or read Lean.

This guide gets you from `pip install` to your first proof in five
minutes.

## Install

```bash
pip install athanor-kairos
```

That's the whole install. No license required for the free tier.

## Your first proof

```python
from kairos import simple_prove_template

result = simple_prove_template("prove c_vector_sharp is positive")
print(result.summary)
```

Expected output:

```
✓ proved. c_vector_sharp is strictly positive (Pythia.MatchingConstants).
```

## What works out of the box

The free tier ships with a fixed set of natural-language patterns
hand-written against the public [Pythia](https://github.com/athanor-ai/pythia)
Lean 4 statistics library. These work with **no API key**, no setup
beyond `pip install` + a working `lake` toolchain.

**First-run note:** the very first `simple_prove_template` call bootstraps a
hidden Lake project at `~/.athanor/pythia-runs/` and runs `lake update`
to fetch Pythia + Mathlib. That's a multi-GB download and can take
several minutes on a fresh machine. Subsequent calls hit the local
cache and run in seconds. To reset the cache (e.g. on a Pythia
version bump): `rm -rf ~/.athanor/pythia-runs/`.

| Hypothesis shape | Example | Maps to |
|---|---|---|
| Sharp-constant equivalence | `"prove c_vector_sharp equals sqrt 2 times c_HR_sharp"` | `Pythia.c_vector_eq_sqrt_two_mul_c_HR` |
| Sharp-constant ranking | `"prove c_aCS_sharp <= c_vector_sharp"` | `Pythia.c_sharp_ranking` |
| Sharp-constant positivity | `"prove c_vector_sharp is positive"` | `Pythia.c_vector_sharp_pos` |
| Time abbrev | `"prove Pythia.Time is a natural number"` | `Pythia.Time` (definitional) |
| Pythia API smoke test | `"verify the Pythia API"` | `import Pythia.API` + trivial proposition |

To see the full list at runtime:

```python
from kairos.verticals import pythia
print(pythia.list_patterns())
```

## Going beyond the templates: bring your own LLM key

If your hypothesis doesn't fit one of the built-in patterns, you can
plug in your own LLM API key. The SDK will use the model to map your
prose onto a Pythia template. **Athanor never sees your key, your
prompt, or your response. the call goes straight from your machine
to the provider you chose.**

### Set one of these in your shell or `.env` file:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# OR
export OPENAI_API_KEY=sk-...
# OR
export GEMINI_API_KEY=...
```

The SDK auto-detects the first key it finds. To force a specific
provider when you have multiple keys set:

```bash
export KAIROS_LLM_PROVIDER=openai   # or anthropic / gemini
```

To override the default model:

```bash
export KAIROS_LLM_MODEL=claude-opus-4-7
```

### `.env` file (recommended)

Create a `.env` in your project root:

```
ANTHROPIC_API_KEY=sk-ant-...
```

Then load it before running your script. Most Python frameworks
auto-load `.env`; if yours doesn't:

```python
from dotenv import load_dotenv
load_dotenv()

from kairos import simple_prove_template
result = simple_prove_template("prove your free-form claim here")
```

### Cost estimate

The default models are small/fast/cheap (`claude-haiku-4-5`,
`gpt-4o-mini`, `gemini-2.5-flash`). A typical `simple_prove_template` call
sends ~200 tokens of prompt and gets back ~100 tokens of structured
output. At Anthropic Haiku pricing that's a fraction of a cent per
call. Hand-written template matches use no LLM and cost nothing.

## What you get back

```python
result = simple_prove_template("prove c_vector_sharp is positive")

result.summary       # "✓ proved. c_vector_sharp is strictly positive..."
result.proved        # True
result.pattern_id    # "sharp_constant_positive". which template fired
result.used_llm      # False. template-match path, no LLM call
result.spec_path     # Path to the generated Lean source (debug only)
```

`result.summary` is the only field you need to read in normal use.
The other fields are diagnostics. they're there if you want them.

## When the proof fails

```
✗ could not verify. c_vector_sharp is strictly positive (...). Lean
reported: <compiler error>
```

That means the Lean verification ran but didn't produce a proof. Common
causes:

1. `lake` toolchain is not installed or `Pythia` package is not in the
   project's manifest.
2. The customer is calling a Pythia symbol that has moved or been
   renamed in a newer Pythia release.

To inspect the generated Lean source for debugging:

```python
result = simple_prove_template(
    "prove c_vector_sharp is positive",
    show_lean=True,
)
print(result.summary)  # now includes the Lean source

# Or read it directly:
print(result.spec_path.read_text())
```

## When no template matches and no LLM key is set

```
✗ no Pythia template matched your hypothesis. Available templates: [...].
Either rephrase to match one of the supported shapes (sharp-constant
positivity / ranking / equivalence, time-abbrev, Pythia API smoke), OR
set ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY in your
environment to enable the BYO LLM fallback.
```

The error message tells you exactly what's available + how to unlock more.

## Privacy and security

The free tier:

- Never phones home to Athanor servers. Zero egress except the LLM call
  you opted into with your own key.
- Never reads your code beyond what you pass into `simple_prove_template`.
- Stashes generated Lean under `~/.athanor/runs/<run_id>/spec.lean`
  for debugging. You can delete that directory anytime.

When you set a BYO LLM key, your hypothesis text + the Pythia template
prompt are sent to the provider you chose (Anthropic / OpenAI /
Gemini). Athanor is not in that loop. Their privacy policy applies to
that traffic, not ours.

## Where to next

- Need more than templates? Set a BYO LLM key (above).
- Need verification beyond Pythia (full RTL / Lean proofs / orchestrated
  multi-tier reasoning)? That's the paid tier. see `docs/sdk-tier-model.md`
  for the upgrade scope. Contact `aidan@athanorl.com`.
- Want to inspect the security model? See `docs/security-model.md`.
- Hit a bug? File at https://github.com/athanor-ai/athanor-sdk/issues.
