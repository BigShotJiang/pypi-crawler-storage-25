# Kairos Lean + Lake-project mode

> Added 2026-04-23 to unblock platform's Cedar fleet (cedar-spec is a
> Lake project). Every Mathlib-using customer workflow needs this.

## Two operating modes on `kairos.lean.verify_proof`

### Bare-file mode (default)

Writes the submitted source to a temp `.lean` file and runs `lean
<file>` directly. Fast path for standalone proofs. No Mathlib / no
imports beyond core Lean 4.

```python
from kairos.lean import verify_proof

result = verify_proof("theorem trivial : 1 + 1 = 2 := rfl")
assert result.status == "full_proof"
```

Banned patterns enforced: `axiom`, `import Mathlib`, `import Lean`,
`unsafe def`, `@[init]`. Mathlib is banned because the compile would
fail to resolve anyway - the ban surfaces the real failure (no
project context) as a cleaner verdict.

### Lake-project mode (ATH-510, Cedar-fleet unblock)

Writes the submitted source into `<lake_project>/<module_path>.lean`
and runs `lake build <module_path>` inside the project. The
project's `lean-toolchain` + `lakefile.toml` define the trust
boundary: Mathlib + any declared dependencies are available.

```python
from pathlib import Path
from kairos.lean import verify_proof

result = verify_proof(
    "theorem cedar_foo : 2 + 3 = 5 := by decide",
    lake_project=Path("/customer/cedar-spec"),
    module_path="CedarSpec.Drafts.Kairos",  # → CedarSpec/Drafts/Kairos.lean
    timeout=120,
)
assert result.status == "full_proof"
```

**Filesystem rollback** is contractual. If the module file existed
before the call, its original bytes are restored. If the module did
not exist, the file (and any directories created for it) are removed
after the call. The project is left in the same state regardless of
build outcome.

Banned patterns: `axiom`, `unsafe def`, `@[init]` remain banned
because they represent a soundness bypass inside the submitted proof
code. `import Mathlib` / `import Lean` are allowed - the project
owner already opted into them via the lakefile.

**Requirements:**

* `lake` on `PATH` (install via [elan](https://leanprover.github.io/installation/))
* A project directory containing `lakefile.lean` **or** `lakefile.toml`
* A valid dotted `module_path` (e.g. `"Foo.Bar"` → `Foo/Bar.lean`).
  Invalid paths (containing `..`, `/`, etc.) are rejected with an
  error verdict.

## Plugin witness shape (`kairos.verticals.lean.LeanProofPlugin`)

```python
witness = {
    "lean_code": "theorem ... := by ...",    # always required
    "lake_project": "/customer/cedar-spec",  # optional; both or neither
    "module_path": "CedarSpec.Drafts.Kairos",
    "timeout_sec": 120,                       # optional
}
```

The plugin rejects (via `Verdict(outcome='error')`, not a raise) if
only one of `lake_project` / `module_path` is supplied - the pair
must match to avoid ambiguity.

## Verdict mapping

Same mapping as bare-file mode:

* `full_proof` → `Verdict(outcome='proved', score=1.0)`
* `partial_proof` (sorry present) → `Verdict(outcome='unknown')`
* `compile_error` → `Verdict(outcome='refuted')`
* `banned` (axiom / unsafe etc.) → `Verdict(outcome='refuted')`

## Cross-ref

* Platform message 2026-04-23-1737 routed this work from platform
  (Cedar fleet lead) to qa (this branch).
* See `src/kairos/lean.py :: verify_proof` for the impl.
* See `tests/test_lean_lake_project.py` for 15 tests incl. rollback
  contract.
* `tests/fixtures/lean_lake_project/` is the minimal Lake fixture
  used by tests.
