# `athanor solve` - drive the verification chassis from your code

Athanor's verification orchestration chassis ships with 7 registered
verticals; `athanor solve` is the single entry point to run any of
them. This doc walks through the three ways to drive it - CLI,
Python API, and backend registry - and documents the flags every
vertical shares.



## Three tiers of access

| Tier | Surface | Customer |
|:-|:-|:-|
| **1 - CLI** | `athanor solve --vertical <name> --target <slug> [flags]` | Ops / CI scripts |
| **2 - Python API** | `athanor.solve.run_vertical(...)` → `Result` | Agents / pipelines |
| **3 - Backend registry** | `athanor.sv.registered_multi_backends()` et al. | Verifier power users |

Pick the shallowest tier that fits. If you can drive everything from
a shell script, use Tier 1. If you want programmatic access to the
verdict + evidence, use Tier 2. Tier 3 is for replacing the verifier
backend itself.



## Tier 1 - CLI dispatch

### Shape

```bash
athanor solve --vertical <name> --target <slug> \
              [--workdir <path>] \
              [--resume | --force] \
              [--verifier ebmc,lean,hypothesis] \
              [--dry-run] \
              [--max-cost <usd>] \
              [--max-iter <N>] \
              [--skip-phases p0,p1 | --only-phases p0,p1] \
              [--extra KEY=VALUE ...] \
              [--list-verticals]
```

`--skip-phases` and `--only-phases` are mutually exclusive.
`--resume` and `--force` are mutually exclusive.

### Registered verticals (as of this release)

| Name | Purpose | Backends | Required `--extra` keys |
|:-|:-|:-|:-|
| `sysverilog-fleet` | SystemVerilog property proofs via EBMC + CEGAR | `ebmc`, `lean` | `sv_file`, `top_module`, `bound` |
| `neuron-fleet` | NKI kernel + Lean proof | `lean`, `hypothesis` | `env_dir`, `config_file` (defaults from target) |
| `cross-accel-fleet` | CUDA / Pallas → NKI port, dual-lane adversarial | `lean`, `hypothesis` | `task_file` (defaults from target) |
| `action-cred-fleet` | Kairos dopamine credit-assignment | `lean`, `hypothesis` | `theorem_label`, `paper_env_dir` |
| `bio-fleet` | Kairos Brian2 sim + property tests | `lean`, `hypothesis` | (see vertical docstring) |
| `two-agent-fleet` | Builder + Adversarial (smaller tier) | (none - internal) | `task_file` |
| `toy` | Smoke use; exercises the chassis without real tools | (none) | (none) |

Run `athanor solve --list-verticals` to enumerate the registered set
on your install - it's authoritative over this table.

### Exit codes

- `0` - pipeline completed, `overall_passed=True`
- `1` - pipeline completed, `overall_passed=False` (refutation or
  chassis declined to pass)
- `2` - SDK-side gate failure (license, `$ATHANOR_BUILDER_ROOT`
  missing, `run.sh` not executable, etc.) - customer hasn't reached
  the chassis yet
- Other codes - propagated from the chassis (e.g. budget exceeded)

### Example: sysverilog-fleet against a toy counter

```bash
export ATHANOR_BUILDER_ROOT=/opt/athanor/builder

athanor solve --vertical sysverilog-fleet --target toy_counter \
  --workdir /tmp/toy-run \
  --extra sv_file=/path/to/toy_counter.sv \
  --extra top_module=toy_counter \
  --extra bound=10
```

On exit, the chassis has written `/tmp/toy-run/manifest.json` and
each phase has its own `/tmp/toy-run/phase_*/` directory with
intermediate artifacts.

### Example: resume an in-progress run

```bash
athanor solve --vertical sysverilog-fleet --target toy_counter \
  --workdir /tmp/toy-run \
  --resume \
  --extra sv_file=... --extra top_module=toy_counter --extra bound=10
```

`--resume` skips phases with a `_DONE` marker. If the workdir is
non-empty but has no `_DONE` markers and neither `--resume` nor
`--force` is passed, the chassis exits with an actionable error
message - this is the intended guard against accidental stomps.

### Example: only run one phase

```bash
athanor solve --vertical sysverilog-fleet --target toy_counter \
  --workdir /tmp/ebmc-only \
  --only-phases phase_4_ebmc_close \
  --extra sv_file=... --extra top_module=toy_counter --extra bound=10
```

Other phases pre-seed their `_DONE` markers so the pipeline doesn't
try to run them.



## Tier 2 - Python API

```python
from athanor.solve import run_vertical, list_verticals, Result

result: Result = run_vertical(
    vertical="sysverilog-fleet",
    target="toy_counter",
    workdir="/tmp/toy-run",
    extra={
        "sv_file": "/path/to/toy_counter.sv",
        "top_module": "toy_counter",
        "bound": 10,
    },
)

if result.proved:
    print(f"proved in {result.elapsed_sec:.2f}s, cost ${result.cost_usd:.2f}")
    for prop, verdict in result.evidence.property_verdicts.items():
        print(f"  {prop}: {verdict}")
else:
    print(f"verdict={result.verdict} exit_reason={result.exit_reason}")
    if result.antecedent_failed:
        print("  chassis claimed success with no evidence - treat as unknown")
```

### `Result` fields (stable)

| Field | Type | Description |
|:-|:-|:-|
| `verdict` | `str` | `"proved"` / `"refuted"` / `"unknown"` / `"error"` / `"stopped"` |
| `proved` | `bool` | `verdict == "proved"` |
| `artifacts_dir` | `Path` | Workdir where the chassis wrote outputs |
| `exit_reason` | `str` | Chassis reason: `"completed"` / `"exception"` / `"stop_on_error"` |
| `exit_code` | `int` | Subprocess return code |
| `elapsed_sec` | `float` | Whole-run wall time |
| `cost_usd` | `float` | Summed from `phases[*].details.cost_usd` |
| `iterations` | `int` | Summed from `phases[*].details.iterations` |
| `phase_events` | `list[PhaseEvent]` | 1:1 with `manifest.phases` |
| `evidence` | `Evidence` | Rolled-up proved-count / property-verdicts / mutation-kill-rate |
| `exception` | `dict \| None` | `{type, message, traceback}` when chassis crashed, else `None` |
| `antecedent_failed` | `bool` | `True` if chassis claimed success with `proved_count=0` |
| `manifest` | `dict` | Raw manifest - escape hatch for fields not yet in the canonical view |

### Evidence-of-work guard

`run_vertical` defensively downgrades `verdict` to `"unknown"` when
`overall_passed=True` but no phase emitted a non-zero `proved_count`.
This is a defense-in-depth mirror of the chassis-side
`NonVacuousProvedGate` - catches the case where a chassis bug lets a
noop phase return "proved" with zero real work.

```python
if result.verdict == "unknown" and result.antecedent_failed:
    # chassis declared success but did no measurable verification work
    alert_on_call("suspicious proved-with-no-evidence verdict")
```

### Exceptions

`run_vertical` raises `SolveError` when dispatch can't reach the
chassis (license gate, missing `$ATHANOR_BUILDER_ROOT`, missing
`run.sh`, subprocess-launch `OSError`). **Chassis runtime failures
do NOT raise** - they populate `Result.exit_code` + `Result.exit_reason`
instead. This matches Tier 1 CLI semantics (exit code 2 vs chassis exit
codes).

```python
from athanor.solve import run_vertical, SolveError

try:
    result = run_vertical("sysverilog-fleet", "toy_counter", extra={...})
except SolveError as e:
    # dispatch couldn't reach chassis - fix license / paths / binaries
    ...
```

### `list_verticals()`

```python
from athanor.solve import list_verticals
print(list_verticals())
# ['action-cred-fleet', 'bio-fleet', 'cross-accel-fleet',
#  'neuron-fleet', 'sysverilog-fleet', 'toy', 'two-agent-fleet']
```



## Tier 3 - Backend registry

For power users swapping verifier backends:

```python
from athanor.sv import (
    registered_multi_backends,     # -> list[str]
    register_multi_backend,        # -> decorator
    run_multi, load_spec,          # -> primitives
)
```

This surface was already stable in athanor-sdk 0.4.x and isn't
touched by this release. See the `athanor.sv` module docstring for
the full contract.



## The `manifest.json` schema

Written by `Pipeline.run()` on every exit path (completed, exception,
stop_on_error). The chassis-side writer lives in
`solve/core/pipeline.py`; the SDK-side parser is `athanor.solve._build_result`.

```json
{
  "pipeline": "sysverilog-fleet",
  "target": "toy_counter",
  "workdir": "/tmp/toy-run",
  "overall_passed": true,
  "elapsed_sec": 1.481,
  "exit_reason": "completed",
  "exception": null,
  "phases": [
    {
      "name": "phase_4_ebmc_close",
      "outcome": "proved",
      "source": "ebmc",
      "reason": "ebmc proved 1/1 properties",
      "elapsed_sec": 1.478,
      "skipped": false,
      "details": {
        "proved_count": 1,
        "property_verdicts": {"p_bound": "proved"},
        "mutation_kill_rate": 0.83,
        "axiom_audit_clean": true
      }
    }
  ]
}
```

### Canonical `details` keys (defensive read - don't `[key]`)

| Key | Type | Emitted by |
|:-|:-|:-|
| `iterations` | `int` | CEGAR-like phases |
| `refutations` | `int` | CEGAR-like phases |
| `cost_usd` | `float` | Any LLM-spending phase |
| `proved_count` | `int` | EBMC / Lean close phases |
| `property_verdicts` | `dict[str, str]` | EBMC / Lean close phases |
| `mutants_killed` / `kill_rate` | `int` / `float` | Mutation sweep phase |
| `axiom_audit_clean` | `bool` | Axiom audit phase |
| `skipped` | `bool` | Any phase that self-skipped |
| `reason_code` | `str` | Machine-readable skip/error category |

Customers reading the raw manifest should use `phase.details.get(key, default)`
rather than `phase.details[key]`, since not every phase emits every
canonical key.



## Further reading

- **ATH-418 SDK expose RFC** (`solve/docs/ath-418-sdk-expose-rfc.md` on
  athanor-builder main) - the full contract spec, with private-surface
  enumeration + deferred-scope notes.
- **Per-vertical docstrings** - `solve/core/verticals/<name>.py` in
  athanor-builder documents each vertical's phase list, dispatched
  shared modules, and deferred items.
- **`solve/core/anti_cheat/seeds.py`** - public CheatFingerprint
  catalog (ATH-424), referenced when a phase reports
  `axiom_audit_clean=False`.



## Troubleshooting

### `SolveError: license: ...`
Your license doesn't cover the `solve` product. Contact your account
owner.

### `SolveError: builder: ...`
`$ATHANOR_BUILDER_ROOT` isn't set or doesn't point at an
athanor-builder install. Point it at a directory containing
`solve/core/run.sh`.

### `SolveError: solve/core/run.sh not found at ...`
Your builder install is too old (pre-ATH-415). Upgrade to a build
that ships `solve/core/`.

### Verdict is `"unknown"` with `antecedent_failed=True`
The chassis returned `overall_passed=True` but no phase emitted any
evidence (`proved_count=0` everywhere). Treat as "no useful proof" -
do not ship on this verdict.

### Verdict is `"error"`
Check `result.exception` for the chassis exception type and message.
If the exception is intermittent, re-run with `--force` to wipe the
workdir.
