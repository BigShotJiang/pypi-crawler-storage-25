# ATH-971 Phase 1: canonical session-shape design

Single-page commit-to-direction. Implementation detail lives in the Phase 2 PR.

## Decision

`kairos.observe._ObserveContext` is the canonical session shape. `kairos.trace.CURRENT_SESSION` (dict-shape `contextvars.ContextVar`) is the deprecated path.

## Why _ObserveContext wins

1. *Dataclass discipline + type-checkable surface.* Fields are typed (`run_id: str`, `sink: TraceSink`, `sequence_counter: int`, `sequence_lock: threading.Lock`, ...) so a future refactor that drops a field trips at type-check time. The dict-shape allows arbitrary `session.get("ad_hoc_field")` reads to silently return `None` without surfacing the contract drift.

2. *Sequence-monotonicity built in.* `_ObserveContext.next_sequence()` + `sequence_lock` give per-session monotonic event ordering for free. The legacy path has no shared counter, so every emit site uses `sequence=0` and downstream consumers cannot reconstruct event order. The ATH-969 legacy bridge cache in `kairos.observe._LEGACY_BRIDGED_CONTEXTS` already pays this cost on the bridge boundary; making `_ObserveContext` canonical removes the cache need entirely once Phase 3 lands.

3. *Auto-bootstrap inheritance.* `kairos.observe.emit` already auto-bootstraps a free-tier observe context when no session is active (atexit-flushed). Customers calling SDK helpers without an explicit `with kairos.session()` block get traces by default. Migrating CURRENT_SESSION readers onto the `_ObserveContext` shape inherits this customer-experience win.

## Considered and ruled out: keeping CURRENT_SESSION as canonical

The seductive counter-argument is that a contextvar of plain dicts is *flexible*: nested call sites can poke ad-hoc fields without triggering a dataclass-version churn. That flexibility is exactly the type-safety gap this refactor is closing. Documented here so future readers second-guessing the canonical-shape decision see the explicit ruling.

## Field shape today

`kairos.trace.CURRENT_SESSION` (dict-shape, set in `kairos.prove.py:844`):

| Field | Type | Source |
|---|---|---|
| `session_id` | `str` | `prove.session()` |
| `task_id` | `str \| None` | `prove.session()` |
| `sink` | `TraceSink` | `prove.session()` |
| `vertical` | `str` | `prove.session()` |

`kairos.observe._ObserveContext` (dataclass, set in `kairos.observe.observe()` / `litellm_trace_session()`):

| Field | Type |
|---|---|
| `run_id` | `str` |
| `session_id` | `str \| None` |
| `sink` | `TraceSink` |
| `events_path` | `Path \| None` |
| `run_type` | `RunType` |
| `run_subtype` | `RunSubtype` |
| `sequence_counter` | `int` |
| `sequence_lock` | `threading.Lock` |

Phase 2 adds `task_id: str | None = None` and `vertical: str | None = None` to `_ObserveContext` so the migrated callers preserve the prove-specific fields they read today.

## Caller migration enumeration (Phase 3 scope)

Six direct `CURRENT_SESSION.get()` readers in the SDK (verified via grep on main 2026-05-03, post-#446):

| Caller | What it reads | Migration shape |
|---|---|---|
| `kairos.lean:309` | `session.get("sink")`, `session.get("session_id")`, `session.get("task_id")` | Read via `_resolve_emit_context()` getter; same field-set on `_ObserveContext`. |
| `kairos.differential:297` | `session.get("sink")` (Noop-gate check), `session.get("session_id")` | Same. |
| `kairos.generator_synthesize:542` | `current_session = _CURRENT_SESSION.get()` then None-check (skip own auto-wrap) | Detection-only; switches to `kairos.observe._CURRENT_CONTEXT.get() is not None`. |
| `kairos.sv.cegar:259` | `session.get("sink")`, `session.get("session_id")` | Same as `kairos.lean`. |
| `kairos.observe._try_legacy_session_context:1103` | The bridge added in ATH-969. Removed in Phase 4 once Phase 3 lands. | Delete the bridge + its cache. |
| `kairos.sv._trace_helpers:emit_to_active_session` | The transitional shim added in ATH-969 | Already calls `observe.emit` underneath; in Phase 4 the 6 sv-* / ebmc / acl2 / quantization / cegar / ghost_tag callers migrate to `observe.emit(silent_if_no_session=True)` directly + the shim deletes. |

`kairos.prove:844` (the *writer*) keeps writing to CURRENT_SESSION through Phase 3 + emits a deprecation warning starting Phase 3. In Phase 4 the writer flips to `_CURRENT_CONTEXT.set(...)` only.

## Per-phase privacy-fence obligation

The privacy-fence contract across the entire migration: `pip install athanor-sdk` followed by `import kairos` must NOT phone home unless the customer explicitly opens a session.

| Phase | Privacy-fence obligation |
|---|---|
| 1 (this doc) | No code changes; obligation is asserted as the per-phase test contract for Phases 2-4. |
| 2 (`_ObserveContext` field expansion) | `tests/test_sv_trace_helpers.py::TestPrivacyFenceRegression` (4 tests, ATH-969-pinned) must continue to pass. Dataclass field additions cannot change the silent-on-no-session behavior. |
| 3 (caller migration) | Each migrated caller adds a per-vertical privacy-fence test before its migration commit lands. Same shape as ATH-969's pin: monkeypatch `_auto_bootstrap_context` to AssertionError; assert no fire when no session is active. |
| 4 (deprecate + remove) | One full release cycle of deprecation warnings on `CURRENT_SESSION` reads/writes before the legacy contextvar is removed. Phase 4 PR audits all 6 callers + greps the wider codebase to confirm no late-stage stragglers. |

## Field-set consumed by platform's Verification Coverage card v2

For platform's pre-Phase-2 sanity-check (per asabi 2026-05-03 coordination): the `solve_runs` writeback path consumes the following session-derived fields. All survive the migration via `_ObserveContext`:

| Card v2 column | Source field on `_ObserveContext` | Notes |
|---|---|---|
| `run_id` | `run_id` | Direct. |
| `session_id` | `session_id` | Direct; nullable per the existing contract. |
| `sink_kind` | `type(sink).__name__` | Read via `sink.__class__.__name__`; canonical and legacy paths produce identical `TraceSink` objects so this is unchanged. |
| `vertical` | `vertical` (added in Phase 2) | Currently sourced from `CURRENT_SESSION["vertical"]`; Phase 2 hoists onto `_ObserveContext`. |
| `task_id` | `task_id` (added in Phase 2) | Same. |
| `run_type` / `run_subtype` | `run_type`, `run_subtype` | Direct. |

If platform's card consumes any field NOT in this table, surface it before Phase 2 starts so it gets added to `_ObserveContext` in the same commit.

## Phase boundaries (each ships complete before the next starts)

* *Phase 1*: this doc + asabi LGTM. Done when this PR lands.
* *Phase 2*: extend `_ObserveContext` with `task_id` + `vertical`. Migration is field-additive only; no caller changes. Privacy-fence regression tests pass. Platform reviews the field-set table above before merge.
* *Phase 3*: flip the 5 caller readers (`kairos.lean`, `kairos.differential`, `kairos.generator_synthesize`, `kairos.sv.cegar`, `kairos.observe._try_legacy_session_context`) to read from `_CURRENT_CONTEXT`. Add deprecation warning on `CURRENT_SESSION.get()`. Per-vertical privacy-fence test added per migrated caller.
* *Phase 4*: `kairos.prove.py:844` writer flips to `_CURRENT_CONTEXT.set(...)` only. Delete the legacy bridge + its cache. Drop the transitional `_trace_helpers.emit_to_active_session` shim; migrate its 6 callers (sv.prove / sv.cegar / sv.ghost_tag / ebmc / acl2 / quantization) to `kairos.observe.emit(silent_if_no_session=True)` directly. Codebase grep confirms zero `CURRENT_SESSION` references survive (the contextvar definition itself can stay deprecated for one release cycle, then deletes).

## Cross-refs

* ATH-969: API consolidation + transitional shim + privacy-fence regression test pin (this is the on-ramp; canonicalization is the work).
* ATH-971: this design doc (Phase 1).
* PR #439 review (asabi): original divergence flag.
