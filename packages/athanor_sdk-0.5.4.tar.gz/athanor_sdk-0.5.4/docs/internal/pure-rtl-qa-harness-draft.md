# PureRTL QA-lane corpus draft (pre-Linear)

Drafted 2026-05-01 per asabi's green-light to spec in parallel ahead of
the future Todd PureRTL Linear ticket. Lands as the qa-lane attachment
once Aidan green-lights the bridge engineering and the ticket is filed.

The pattern mirrors `tests/integration/test_hw_cbmc_corpus.py` (PR
#71) and `tests/integration/test_sv_invariants_corpus.py` (PR #368).
Same discovery + skipif gating, same stub-vs-live split.

## Scope

Three files, same factoring as the existing two:

1. `tests/integration/test_pure_rtl_corpus.py`: corpus dispatch
   for `kairos.eqy.verify()` (and `kairos.slec.verify()` once that
   surface lands). Stub-driven, no commercial license required.

2. `tests/integration/test_pure_rtl_lean_clash.py`: property-based
   tests for the unsigned Lean → Clash translation step. Per Todd's
   v1 mitigation: enumerate spec, drive Clash codegen, verify
   equivalence at observation-point granularity via EQY.

3. `examples/pure-rtl-corpus/demo.md`: paired customer-facing
   demo. Same shape as `examples/sv-invariants-corpus/demo.md`.

## Discovery shape

```python
# tests/integration/test_pure_rtl_corpus.py
_ENV_ROOT_ENV = os.environ.get("ATHANOR_ENV_PURE_RTL")
_DEFAULT_ENV_ROOT = Path.home() / "athanor-ai-repos" / "environments" / "pure-rtl"
_ENV_ROOT = Path(_ENV_ROOT_ENV) if _ENV_ROOT_ENV else _DEFAULT_ENV_ROOT

_HAS_ENV = _ENV_ROOT.is_dir() and (_ENV_ROOT / "tasks").is_dir()
_HAS_EQY = shutil.which("eqy") is not None
_HAS_SLEC = shutil.which("slec") is not None or os.environ.get("SLEC_BIN")

pytestmark = [
    pytest.mark.skipif(not _HAS_ENV, reason="pure-rtl env not vendored"),
    pytest.mark.skipif(not _HAS_EQY, reason="eqy binary missing"),
    pytest.mark.integration,
]
```

Same `_load_task_configs` + `_resolve_sv` helpers from PR #71. If we
end up duplicating across three corpus files, extract to
`tests/integration/_corpus.py` per the original PR #71 ticket
suggestion.

## Stub-vs-live split

The mainline integration test runs against a stubbed equivalence
checker that returns deterministic verdicts. Real-binary tests live
in a separate `@pytest.mark.live` class so the corpus runs in CI
budget (no commercial license, no GPU, no real LLM).

```python
def _stub_eqy_verify(spec_sv, impl_sv, top_module):
    """Deterministic stub: returns PROVED for a hash-based fixture
    so the dispatch + result-shape logic gets exercised without
    actually running EQY."""
    return EqyResult(
        verdict="PROVED",
        elapsed_sec=0.01,
        stderr="",
        properties_proved=["equivalence"],
        properties_refuted=[],
    )


class TestEqyVerifyDispatchCorpus:
    @pytest.mark.parametrize("config", _eligible_configs(), ids=...)
    def test_dispatch_completes(self, config, monkeypatch):
        monkeypatch.setattr("kairos.eqy._run_eqy_subprocess", _stub_eqy_verify)
        result = kairos.eqy.verify(...)
        assert result.verdict in {"PROVED", "REFUTED", "UNKNOWN", "ERROR"}
        # Shape assertions only; verdict correctness lives in @live.


class TestEqyVerifyLive:
    """Real EQY invocation. @pytest.mark.live keeps these out of CI."""

    @pytest.mark.live
    @pytest.mark.skipif(not _HAS_EQY, reason="eqy binary missing")
    def test_real_eqy_on_known_equivalent(self):
        ...
```

## Property-based Lean to Clash shape

```python
# tests/integration/test_pure_rtl_lean_clash.py
class TestLeanClashRoundTrip:
    """For each LeanMachines spec in the corpus:
    1. Run the LLM-driven Lean to Clash translator (stubbed).
    2. Compile Clash to SystemVerilog via subprocess.
    3. Drive kairos.eqy.verify() between the LLM-cleaned SV and the
       Clash-emitted SV (observation-point equivalence).
    4. Assert verdict shape.

    Per Todd: this is the v1 mitigation for the unsigned Lean to Clash
    step.  v2 (Clash to Lean back-translator with round-trip proof) is
    out of scope here.
    """

    @pytest.mark.parametrize("spec_path", _lean_specs(), ids=...)
    def test_round_trip_observation_equivalent(self, spec_path):
        ...
```

## Trace events emitted

Five event types under `run_subtype="theorem_proving"` (registered in
`src/kairos/trace_schema.py` ahead of implementation per asabi's
green-light):

| event_type | step | payload sketch |
|------------|------|----------------|
| `pure_rtl_clash_codegen` | Lean to Clash to SV | `{spec_path, clash_options, sv_lines, elapsed_sec}` |
| `pure_rtl_eqy_verify` | EQY equivalence on cleaned SV vs Clash-emitted SV | `{spec_module, verdict, properties_proved, properties_refuted, elapsed_sec}` |
| `pure_rtl_slec_verify` | SLEC equivalence (commercial path) | same shape as eqy |
| `pure_rtl_lean_extraction` | SV to Lean reverse direction (round-trip experiment) | `{sv_path, lean_extracted, axioms_introduced, elapsed_sec}` |
| `pure_rtl_optimization_proposal` | Step-4 LLM-driven exploration | `{spec_module, search_strategy, candidate_count, accepted_count, cost_usd}` |

## Sequencing

* Now (no Aidan blocker): trace registry entries land. Risk-free,
  since events are not yet emitted, so the inverse-coverage check
  just shows "no traffic" (informational, not blocking).
* After Aidan green-light + ticket: test files + demo land in the
  same PR as the bridge proof scaffolding. The shape above is
  mostly fixed; plug in once `kairos.eqy.verify()` and
  `kairos.pure_rtl.*` surfaces exist.

## Cross-refs

* `tests/integration/test_hw_cbmc_corpus.py` (PR #71): pattern.
* `tests/integration/test_sv_invariants_corpus.py` (PR #368, ATH-423):
  same pattern, different SDK surface.
* `kairos.acl2.refinement_prove` (PR #363, ATH-906): VL+FGL refinement
  the bridge proof connects to via `refines_trans` and
  `ACL2Bridge.composeWitnessed`.
* asabi 2026-05-01 PureRTL methodology broadcast in #dev-sdk
  (ts=1777638319.131429).
