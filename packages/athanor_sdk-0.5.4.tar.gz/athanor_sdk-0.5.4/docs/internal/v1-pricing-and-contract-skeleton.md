# V1 pricing + contract skeleton

_Draft v0.2: 2026-04-19 08:30 UTC, platform. For asabi pre-review
before handoff to Aidan. Rewritten from v0.1 to match reality: we're
pre-V1, no SOC2, pre-first-customer, in a space where 12-month
commitments are neither realistic nor desirable. Keeping it simple._

## 1. Pricing model

**$50k / month / env. Month-to-month. Cancel anytime with 30 days'
notice. First month invoiced upfront.**

That's the product. One number, one term, one paragraph of business
terms.

No annual contracts. No multi-year discount curves. No tier matrix.
No pilot-only SKU. No mirror-mode pricing premium. Those are all
things we'll add when we have retention data + reference customers
+ SOC2 - probably 18-24 months from now.

Current stance on the $50k figure (subject to Aidan ratification):
that's $600k/yr annualized - 3x Aidan's 2026-04-12 $200k/env annual
MSRP anchor. The 3x multiplier is the **flexibility premium**:
customer gets month-to-month escape hatch, no SOC2, pre-V1 product
risk - they pay for access + flexibility. The premium collapses back
to Aidan's anchor the moment we offer annual-prepay (Year 2 move).

Alternative landing zones:
- **$30k/mo** - "premium but approachable." Annualized $360k, still
  above anchor. Works if first customer is price-sensitive.
- **$50k/mo** - frontier-lab territory. My pick.
- **$75k/mo** - "boutique premium." Only a few customers can cut the
  check without VP escalation; probably above our current evidence
  base.
- **$100k/mo** - Full enterprise partnership. Not today without
  reference customers; correct destination post-Amazon.

## 2. Why monthly (and not annual)

Three specific reasons we shouldn't force annual today, even though
some market comps (Cadence, Palantir) do:

1. **No SOC2 compliance.** Enterprise procurement at any serious
   customer cannot sign 12-month commitments with uncertified
   vendors. Their own legal teams won't approve it. An "annual-first"
   pricing structure gates us out of the customer segment we want.

2. **AI-space half-life under 12 months.** Model generations shift,
   customer verification needs evolve, new frontier labs emerge. A
   year is multiple AI cycles. Neither side should want to commit
   that far out.

3. **No retention data.** Annual pricing makes sense when you can
   predict the customer lifetime curve. Pre-first-customer, we're
   guessing. Better to price for the realistic "few months"
   commitment and upgrade later when evidence warrants.

What monthly signals to the customer: *"We'll earn each of your
months. No lock-in. Leave when you're ready."* That's a credibility
move specifically well-suited to the AI space, where customers are
burned out on big contracts for tools that die.

## 3. What's included in $50k/month

- The SDK + athanor-builder tarball for their licensed env
- Unlimited engineers within the licensed organization - one
  org-scoped `ATHANOR_TOKEN`; customer handles internal access
  control (secrets manager / SSH / whatever they already use)
- Quarterly prompt/weight/lemma updates delivered automatically
- Their choice of mirror mode (air-gapped / metadata / full -
  no price difference)
- Slack support channel, 24h response target
- Unlimited runs within the licensed env (infrastructure rate-limits
  apply at the token level for abuse prevention; they don't kick in
  at normal usage)

## 4. What's billed separately

Two optional line items. Everything else is in the monthly fee.

| Service | Fee | Notes |
|:-|:-|:-|
| **Custom prompt tuning at onboarding** | $25k one-time | Covers 1 person-month of our prompt engineers building a customer-specific variant (e.g., Amazon's NKI conventions). Optional - self-serve customers install the stock tarball and skip this. |
| **Custom env development** | $500k-$1M flat | Rare. Only if they want a new vertical we don't already have. 2-4 person-months of our team per asabi's 2026-04-19 cost math. Customer retains 3-year exclusive use. |

## 5. What we explicitly don't charge for

To keep the monthly fee feeling fair + avoid nickel-and-diming:

- Per-run fees - never
- Reading existing bundles / dry-run validation / replay
- Re-running a spec after a prompt update
- Storage of bundles on our side (up to 100 GB/org; "let's discuss"
  above that)
- SDK itself - free, pip-installable
- Customer's own LLM spend (they bring their own
  `ANTHROPIC_API_KEY`)

## 6. Mirror-level modes

Three modes, same price regardless. Customer picks based on their
security posture + compliance requirements.

| Mode | license.mirror_mode | What reaches our DB |
|:-|:-|:-|
| **Air-gapped** | `none` | Nothing |
| **Metadata mirror** | `metadata` (default) | org_id + timestamps + vertical + verdict pass/fail + cost aggregates |
| **Full mirror** | `full` (opt-in) | Above + redacted run transcripts + artifacts + detailed quality reports |

No pricing premium on air-gapped (yet). We may add one when we have
operational evidence it costs materially more to support; for now,
the product is the product regardless of how visible it is to us.

Platform-side enforcement of mirror mode is ATH-368 (filed).

## 7. Contract clause skeleton

One-page agreement. Four business clauses that matter + standard
boilerplate.

### 7.1 License grant

```
Athanor AI grants Customer a non-exclusive, non-transferable,
non-sublicensable right to use the Athanor SDK and the accompanying
Athanor Builder component on Customer's own hardware, for the
Licensed Envs listed in Schedule A, for each paid calendar month
during the Term.

The license is internal-use only. Customer may not redistribute,
sublicense, reverse-engineer, or publish any portion of the Athanor
Builder or its prompt templates, scoring weights, or lemma
libraries. Customer may not train derivative models on Athanor
Builder output or use the software to compete directly with Athanor
AI's core verification services.
```

### 7.2 Fee + term + termination

```
Customer pays Athanor AI $50,000 per Licensed Env per calendar
month, invoiced on the 1st of each month in advance. Payment terms
Net 15.

Either party may terminate for any reason on 30 days' written
notice. Athanor AI may terminate immediately for material breach of
the license-grant restrictions (redistribution, reverse-engineering,
sublicense).

Partial months at termination are pro-rated to day of notice.
Customer's locally-stored bundles and artifacts remain Customer's
property after termination. Customer's license to operate the
Athanor Builder ceases on the termination date.
```

### 7.3 Data residency

```
Customer's Mirror Mode, specified in Schedule A, determines what
data reaches Athanor AI's infrastructure. In Air-Gapped mode, no
data leaves Customer's hardware. In Metadata-Mirror mode, only
aggregate usage metrics are transmitted. In Full-Mirror mode,
redacted run transcripts and artifacts are mirrored for support
purposes.

Athanor AI processes any received data as a Processor acting on
Customer's behalf, per the attached Data Processing Addendum.
Customer may request deletion of mirrored data at any time;
Athanor AI commits to complete soft-delete within 7 business days
and hard-delete within 30 days.
```

### 7.4 Updates

```
During the Term, Athanor AI delivers quarterly updates to the
Athanor Builder at no additional charge. Updates may include
revised prompt templates, scoring weights, lemma libraries, and
verification layers. Customer may defer applying an update for up
to 90 days.
```

Plus standard boilerplate: confidentiality, IP ownership (ours stays
ours, theirs stays theirs), warranty disclaimer, limitation of
liability, governing law, dispute resolution.

## 8. Operational flow per onboarding

### Day 0 - contract signed
DocuSign → CRM webhook.

### Day 0 + 2h - platform-side provisioning (ATH-340)
1. Create `organizations` row: `license_expires_at = +30 days`,
   `allowed_verticals`, `mirror_mode`
2. Generate `license.json`, GPG-sign
3. Trigger per-customer tarball build (pruned to licensed envs)
4. Upload to Supabase Storage, generate 7-day signed URL
5. Mint one org-scoped `ATHANOR_TOKEN`
6. Email technical contact with delivery URL + token + GPG
   fingerprint

### End of month N
Automated Stripe (or ACH / invoice) charge for month N+1. If
payment fails, 14-day grace then license suspends.

### On termination notice
Revoke new-month issuance. Existing month runs out. Customer
retains their installed tarball until `license_expires_at`; then
hard-gates new submits.

## 9. Open questions for Aidan

Triaged from v0.1's 11 questions down to 3 actual decisions:

1. **Is $50k/month the right anchor?** Range I'd endorse is $30k-$75k.
   Lower = easier first-customer close, less value-capture. Higher =
   stronger positioning, fewer candidate customers.

2. **Who is customer #1, and do we offer a first-month discount as
   case-study goodwill?** Amazon Neuron is the named target from the
   2026-04-18 call. Option: first month at $25k (50% off) as
   explicit "trial month"; reverts to $50k/mo after, no action
   required from customer.

3. **When we eventually introduce annual-prepay (Year 2), what
   discount rate?** Not today, but worth having a plan: 20% off for
   annual is standard SaaS, 25% off matches Aidan's original $200k
   anchor exactly. Lock in now so we don't accidentally discount to
   break-even.

Other earlier questions (pilot tier, multi-year curves, mirror
premium) are killed - not relevant while we're month-to-month.

## 10. What's explicitly NOT V1

Deferred to when we have reference customers + SOC2:

- Annual contracts as an option (Year 2)
- Multi-year commitments with discount curves (Year 3)
- Multi-env bundle discounts (when a customer actually wants 2+ envs)
- Pilot-only SKU (monthly IS the pilot)
- Tier matrix with scoped support levels (monthly is one tier)
- Air-gapped pricing premium (no ops evidence yet)
- White-label rights
- Academic pricing tier
- Partner/reseller tier
- Usage-based billing (Aidan explicitly rejected; flat monthly
  respects that while keeping simple)

## 11. Platform-side operational work to support this

Three tickets, ~3 days total. Post-V1-ship; not V1-blocking:

1. **Admin panel: license issuance** - `/admin/organizations/new` form
   → triggers full provisioning pipeline. ~1 day.
2. **Customer-facing usage dashboard** - month-over-month runs,
   verticals, spend, current-month invoice preview. ~1.5 days.
3. **Monthly billing cron** - trigger Stripe invoice / ACH on 1st of
   each month for each active license. 14-day grace before suspend.
   ~0.5 days.

_Previously listed: "Seat audit report." Dropped - org-scoped
licensing per §3 makes per-seat tracking unnecessary._

## 12. Decision log

- 2026-04-12 Aidan: $200k/env annual MSRP anchor for frontier labs
- 2026-04-19 Aidan: we don't know how long partnerships will last;
  reject annual-first structure
- 2026-04-19 Aidan: price should be higher than $20k/month first draft
- 2026-04-19 platform → asabi: v0.2 rewrite - month-to-month at $50k
  (3x annual MSRP as flexibility premium); kill tier matrix, kill
  annual, kill multi-year, keep it one-paragraph simple
- 2026-04-19 v0.3: kill per-seat licensing. Modern AI infrastructure
  comps (Modal / Replicate / Databricks) don't seat-price; per-seat
  is a traditional-enterprise-SaaS pattern that doesn't match what
  we are. One org-scoped `ATHANOR_TOKEN` per customer; customer
  handles internal access control. Kills the seat-audit operational
  line item. Kills "Seat Count" from Schedule A. Simpler contract,
  simpler auth, honest customer conversation.

## 13. What changes 12-24 months from now

If we succeed:

- **Months 1-12 (now):** 100% monthly. 3-5 customers. Learn retention.
- **Year 2:** Monthly stays default; annual-prepay option added at
  20-25% discount for customers who self-select. SOC2 achieved
  mid-year. Early annual contracts start signing.
- **Year 3:** Annual-default for new enterprise deals; monthly
  stays as pilot/evaluation option. 50+ customers. Tier matrix
  genuinely differentiates support levels.

So monthly isn't the permanent answer - it's the entry point. The
simpler we keep V1, the faster we get to the data that informs
what comes next.



_Filed by: @platform (hongsksam) · 2026-04-19 08:30 UTC_
_For asabi pre-review before Aidan review_
