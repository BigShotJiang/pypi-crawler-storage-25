# Kairos Dogfood Analysis: 2026-05-08 Session

12-hour session. 9 optimizations shipped (2,400+ cells saved across 8 blocks
+ 1 fleet-wide power bug fix). 25+ commits on PR #558. This document captures
what broke, why, and the design rationale for every guardrail shipped.

## Part 1: What Broke and Why

### 1. EBMC is wrong for combo blocks

178-bit ALU: EBMC 900s timeout. yosys equiv: 1.16s. The orchestrator assumed
EBMC-for-everything because Todd asked for formal verification, not
specifically EBMC on combinational logic.

**Fix**: ATH-1112. Auto-route combo blocks (clock_port empty) to yosys
equiv_make + equiv_struct + equiv_simple + equiv_induct. EBMC runs as 60s
confirmatory cross-check, not primary engine.

**Design rationale**: engine selection is an orchestrator decision, not a
customer parameter. The customer says "verify this." The orchestrator picks
the right engine.

### 2. The proposer cheats constantly

Four failure modes caught this session:

- Simulation-code removal (ifdef/assertion cleanup): 0% area delta after synthesis
- Cosmetic rewrites (rename signals, reformat always blocks): same netlist
- Unparseable SystemVerilog: yosys gate elaborate fails
- Verbatim gold copy: zero structural change

Prompt bans are insufficient. The structural gate (reject gate_cells >=
gold_cells before verification) is the only reliable defense.

**Fix**: pre-verification structural gate + toggle-power gate. Both run
inside the orchestrator, not in the proposer. The proposer cannot bypass them.

**Design rationale**: you cannot trust LLM output. You can only gate it
structurally. Every defense that relies on prompting will fail. Every defense
that relies on code-level enforcement will hold. Infrastructure over LLM layers.

### 3. elaborate_gold had 3 stacked bugs

(a) No chparam: parameters defaulted wrong (DEPTH=16 instead of DEPTH=4).
(b) Cleared sig["parameters"]: gate elaboration skipped entirely.
(c) flatten;opt: stripped sequential logic from gate designs.

Each bug masked the next. Found one at a time across 4 hours.

**Root cause**: the elaborate path was added incrementally without end-to-end
testing on diverse block types (combo, sequential, parameterized, multi-module).

**Fix**: chparam in elaborate, keep parameters for gate elaboration, gate
uses flatten=False. Tests for each.

### 4. Area measurement was wrong

_measure_synthesis measured raw gold (default params) not elaborated gold
(concrete params). AP_PUSH_2_FIFO showed -76.4% when actual delta was 0%.

**This is the scariest finding.** The -76.4% would have gone to a customer.
Caught by independent verification, not infrastructure.

**Fix**: always measure elaborated gold vs elaborated gate. Never compare
raw-parameterized against concrete.

**Design rationale**: measurement must use the same artifacts as verification.
If the verifier sees elaborated files, the measurement must see elaborated
files. Any divergence between what-we-verify and what-we-measure is a bug.

### 5. Multi-model proposer is required for correctness

GPT-5.5 found alu_onebarrel (-14.5%) that Sonnet never discovered in 5
attempts. Sonnet found din & (~din+1) that GPT-5.5 missed. Neither alone
is complete.

**Fix**: DEFAULT_PARALLEL_MODELS with 4 model families. Not a nice-to-have.

**Design rationale**: different models have different blind spots. The
optimization landscape has multiple basins. Multi-model sampling is how you
escape local optima.

## Part 2: What Kairos Needs for Customers

### 1. One-command fire

Today: build bundle manually, set 15 parameters, remember elaborate_gold and
proposer_mode and timeout. Customer (Todd's Kiro agent) needs:

```
kairos optimize --rtl AP_ALU_US.sv --deps AP_MUX_US.v --params DATA_WIDTH=8
```

Auto-detect clock/reset, auto-elaborate, auto-select verification engine.
This is the customer-experience gap. Everything else is internal quality.
This is the thing that makes Kiro actually able to use kairos.

### 2. Auto-engine selection

combo (no clock) -> yosys equiv primary + EBMC confirmatory.
sequential (clock + reset) -> EBMC BMC + k-induction primary.
Large combo (>2000 cells) -> yosys SAT miter primary.
Small sequential -> EBMC with high k-bound.

The customer should never think about which engine to use.

### 3. Result trust ladder

Every result reports which engines confirmed:

"PROVED by yosys equiv (416/416) + SAT miter (SUCCESS) + EBMC (timeout)"

Two-engine agreement is minimum. Three is gold standard. The customer sees
the trust level and decides their own threshold.

### 4. Structural gates as API shape

Not prompt engineering. Not honor-system. The gate rejects bad proposals
structurally: cell count, toggle count, syntax parse. The customer's agent
cannot bypass them because they run inside the orchestrator.

### 5. Pattern invariant library as first-class SDK feature

Todd's pattern library (one-hot, FIFO ordering, arbiter fairness) should be
a JSON/YAML config that customers extend. The orchestrator reads it, detects
patterns, feeds to proposer. Today it is regex in pattern_invariants.py.
Should be declarative.

## Part 3: Codebase Health

### _orchestrator.py decomposition

1,800+ lines doing: bundle loading, gold elaboration, proposer dispatch,
verification (3 engines), counterexample feedback, invariant gen, ACL2
fallback, Lean formalization, result saving, cert tarball, event emission,
measurement. Should be 5-6 smaller modules with clear interfaces.

### Test coverage is tool-gated

113/160 basic_cells need foundry Liberty files. Orchestrator tests need
yosys + EBMC. CI can only run unit tests. Need a mock verification layer
so orchestrator logic is testable without external tools.

### Prompt library should be lazy-loaded

The proposer reads prompts at import time. Changing a prompt requires
restarting the process. Should be lazy-loaded per call so customers can
iterate prompts without code changes.

## Part 4: What Worked Well

1. **kairos trusts math, not models.** Structural gate + dual-engine
   verification caught every proposer cheat. Zero false positives shipped.

2. **Counterexample-feedback loop works.** MEM_1P and AP_REG_FIFO_US both
   had proposals refined from REFUTED to PROVED.

3. **Toggle power measurement fills a real gap.** Three blocks got both
   area AND power numbers.

4. **Session guard (ATH-1110) prevents ad-hoc-loses-results permanently.**

5. **Honest reporting builds trust.** FIFO at-synthesis-floor, compound ALU
   0/15 initial result, mem_wrapper tool-limitation -- these tell the
   customer where the tool's limits are.

## Session Results

| Block | Area | Power | Cells Saved |
|-------|------|-------|-------------|
| AP_ALU_US (compound) | -27.5% | -- | 1,614 |
| ap_hamming_encoder_266_256 | -48.1% | -- | 627 |
| AP_NUM2MASK_VEC_US | -75.0% | -77.0% | 15 |
| AP_FILL_ONES_UP_US | -33.3% | -- | 3 |
| AP_FILL_ONES_US | -33.3% | -11.9% | 3 |
| ap_hamming_encoder_39_32 | -29.9% | -- | 38 |
| AP_FINDFIRSTSET_US | -21.7% | -62.4% | 23 |
| AP_CMP_SWAP_US | -5.5% | -- | 3 |
| mem_wrapper swrp_port | -- | -26.6% | fleet-wide |

Total: 2,326+ cells saved across 8 blocks + 1 fleet-wide power fix.
