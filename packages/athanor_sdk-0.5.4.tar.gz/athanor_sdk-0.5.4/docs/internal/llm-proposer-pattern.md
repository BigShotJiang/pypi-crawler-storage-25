# LLM-proposer + Lake-sampling pattern

End-to-end walkthrough of `kairos.generator_synthesize` paired with
`kairos.lean.sample_terms_adapter` + `kairos.lean.sample_generator`.
Covers the shape of a full iterate-refine loop that has an LLM write
a Lean generator, runs it through Lake + Palamedes-style runtime
sampling, and verifies each sample via `predicate_verify`.

All the SDK primitives invoked here landed overnight 2026-04-24
(ATH-550 through ATH-563 + sibling helpers). Customers driving
their own LLM-proposer dogfood should copy this shape rather than
reinventing the adapter + session wiring from scratch.

## What you get for free

1. **Zero-ceremony tracing.** Set `ATHANOR_SYNC_TOKEN` in the env;
   every `kairos.*` operation auto-opens a parent `solve_runs` row
   and emits a child `sdk_agent_events` event per iteration. No
   explicit `trace_sink=` kwarg needed. See
   [observe-session-composability.md](observe-session-composability.md).
2. **Fail-loud rollback journal.** When Supabase is unreachable or
   the `sdk_agent_events.run_subtype` CHECK rejects a new event type,
   the SDK journals the failed upload to
   `~/.kairos/failed_events.jsonl` (or the
   `KAIROS_FAILED_EVENTS_JOURNAL` override) and logs at WARNING.
   Nothing silently drops. Drain via `kairos trace replay` after the
   upstream resolves.
3. **Sampler diagnostics.** When the Lake-side sampler returns zero
   terms (or raises), the iteration summary carries
   `sample_terms_error` + `sample_terms_stdout_tail` so dashboards
   + paper replay show WHY. `rejection_rate=None` on a zero-sample
   iteration distinguishes sampler failure from real
   predicate-failure (which reads as `rejection_rate=1.0`).
4. **Docker fallback for Lake.** If your workspace has a Lean
   toolchain mismatch or relies on a sibling-package layout (e.g.
   `cedar-micro/../palamedes-lean`), pass `docker_image=...` +
   `workspace_root=...` to `sample_generator` and the build runs
   inside the container with the right mount. Host lake is still
   the default when neither is supplied.

## Minimal end-to-end

```python
import os

os.environ["ATHANOR_SYNC_TOKEN"] = "<your-token>"

import kairos
from kairos.generator_synthesize import SpecBundle
from kairos.lean import sample_terms_adapter

# 1. Describe the synthesis target. The SDK doesn't assume anything
#    about your Lean project's shape - you pass the predicate name +
#    imports + workspace and it treats the rest as opaque.
bundle = SpecBundle(
    workspace="/path/to/cedar-full",
    module_scratch_prefix="CedarBridge.KairosGen",
    predicate_name="Cedar.Spec.isWellTyped",
    predicate_imports=["CedarBridge"],
    term_type="Cedar.Spec.Expr",
    example_term="Expr.lit .true",
)

# 2. Build the sampler adapter. This wraps kairos.lean.sample_generator
#    and translates SampleGeneratorResult -> SampleTermsResult so
#    diagnostics flow back into the iteration summary (ATH-563).
sampler = sample_terms_adapter(
    workspace="/path/to/kairos-cedar/cedar-full",
    workspace_root="/path/to/kairos-cedar",  # ATH-557 - sibling-path mount
    module="CedarFull.Expr",
    term_type="Cedar.Spec.Expr",
    docker_image="ghcr.io/athanor-ai/kairos-cedar:latest",  # ATH-552
    extra_imports=["CedarBridge"],
)

# 3. Fire the loop. No trace_sink= kwarg - ATH-550 auto-detects
#    ATHANOR_SYNC_TOKEN and wires SupabaseTraceSink. No session ctx
#    manager - ATH-551 auto-wraps a synthetic kairos.session so the
#    parent solve_runs row gets opened + closed cleanly.
result = kairos.generator_synthesize(
    spec_bundle=bundle,
    model="anthropic/claude-sonnet-4-6",
    max_iters=5,
    target_rejection_rate=0.1,
    n_samples=20,
    sample_terms=sampler,
)

print(f"converged: {result.converged}")
print(f"total cost: ${result.total_cost_usd:.4f}")
for it in result.iterations:
    print(
        f"  iter={it.iteration} sampled={it.sampled_count} "
        f"rejected={it.rejected_count} rate={it.rejection_rate} "
        f"err={it.sample_terms_error!r}"
    )
```

## Inlining an LLM-written generator (ATH-561 `prelude=`)

When the LLM writes a generator that references types outside
`module`'s transitive imports - common with cedar-full + Palamedes
- pass the LLM source as `prelude=` so it inlines into the driver's
namespace instead of requiring a pre-built module:

```python
from kairos.lean import sample_generator

# Suppose the LLM emitted this in its GENERATOR: block. The SDK
# strips markdown fences for you (ATH-560) before reaching here.
llm_source = """
def CedarGen.myTerms : IO (List Cedar.Spec.Expr) := pure [
  Cedar.Spec.Expr.lit .true,
  Cedar.Spec.Expr.lit .false,
]
"""

r = sample_generator(
    workspace="/path/to/cedar-full",
    workspace_root="/path/to/kairos-cedar",
    module="CedarFull.Expr",
    term_type="Cedar.Spec.Expr",
    generator_expr="CedarGen.myTerms",
    prelude=llm_source,                # ← ATH-561
    docker_image="ghcr.io/athanor-ai/kairos-cedar:latest",
    n=10,
)
print(r.terms)            # list of rendered sample strings
print(r.error)            # '' on success, lake build error otherwise
print(r.stdout_tail)      # last 4KB of captured lake output
```

The adapter from the minimal example threads `prelude=generator_source`
through automatically - you don't have to call `sample_generator`
directly unless you want a standalone sampling invocation.

## Reading the iteration summary (ATH-563)

Every `GeneratorIteration` now carries two extra fields:

| field | meaning |
| :- | :- |
| `sampled_count` | how many terms the sampler actually produced |
| `rejected_count` | how many the predicate rejected (capped at `sampled_count`) |
| `rejection_rate` | `rejected / sampled`, **or `None`** when `sampled_count == 0` |
| `sample_terms_error` | one-line reason the sampler produced &lt; N terms; `""` on full success |
| `sample_terms_stdout_tail` | last ~4KB of captured sampler output; `""` when not captured |

`rejection_rate=None` is the signal that the sampler itself failed -
Lake build error, toolchain missing, exception in the adapter. Pre-563
this collapsed to `1.0`, which misleadingly looked like a predicate
failure. Paper replay + dashboards should now distinguish:

- `rejection_rate == 1.0` → sampler returned terms, predicate refuted all of them. Real predicate failure.
- `rejection_rate is None` → sampler returned `[]` or raised. Inspect `sample_terms_error`.

The same distinction lives in the `generator_synthesis_round`
TraceEvent payload so paper-replay scripts + `/solve-runs` dashboards
can render the right verdict.

## What happens when Supabase is unhappy (ATH-553 + ATH-554)

The `sdk_agent_events` table has a `run_subtype` CHECK constraint.
If the SDK emits a subtype the CHECK rejects (e.g. a new
`'theorem_proving'` subtype before the migration lands), the upload
returns HTTP 400. The SDK:

1. Logs at WARNING (not ERROR-swallow).
2. Journals the full event - URL, method, body, response code, response
   body, timestamp - to `~/.kairos/failed_events.jsonl`.
3. Continues the run. Nothing drops.

After the upstream is fixed (migration lands, auth rotates, network
returns), drain the journal:

```
$ kairos trace replay --dry-run       # preview
$ kairos trace replay                 # actually re-upload
$ kairos trace replay --limit 10      # cron-friendly: 10-at-a-time
```

Per-line outcomes on replay:

- 2xx response → line removed from journal.
- 4xx permanent (400, 401, 403, 404, 409, 422, ...) → moved to
  `~/.kairos/failed_events.jsonl.permanent.jsonl` so the main queue
  drains. Operator reviews separately.
- 5xx / 408 / 429 / transport error → `attempts` incremented, line
  rewritten to the head of the journal.

## Anti-patterns

- **Don't re-implement the fence strip.** Pre-ATH-560 callers parsed
  the LLM response themselves and often shipped `` ```lean `` fences
  into `lake build`. The SDK strips outer fences in
  `_extract_generator_source`.
- **Don't pass `trace_sink=NoopTraceSink()` during dogfooding.** The
  01:14Z Kimi-cooldown → Noop misinterpretation cost ~$0.20 of lost
  traces. Trust ATH-550's default - env-populated = live sink,
  env-absent = Noop.
- **Don't post-process `sample_terms_error` by grepping your own
  adapter's stdout.** That works around the diagnostic instead of
  flowing it. Return `SampleTermsResult(terms=..., error=..., stdout_tail=...)`
  or use `sample_terms_adapter` which does the translation.
- **Don't widen the CHECK constraint without a migration.** If you
  want a new `run_subtype`, file a migration ticket and wait for
  schema widening. The journal + replay path handles the interim
  cleanly.

## Related

- [observe + session composability](observe-session-composability.md)
  - how `kairos.observe` + `kairos.session` stack cleanly.
- [kairos.lean lake-project mode](kairos-lean-lake-project-mode.md)
  - background on `verify_proof(lake_project=..., module_path=...)`.
- Platform's Exp 2 reference implementation:
  `kairos-cedar/experiments/phase_a_v2/run_lm_palamedes_sampled.py`.
