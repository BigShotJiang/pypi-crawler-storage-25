# ATH-1062 Phase 1 Aristotle queue forward-pin (v2.8.5)

Ticket templates for the v2.8.5-pythia children that close Phase 1 bridge invariants as kernel-checked Lean theorems. NOT yet filed as Linear tickets per `feedback_no_placeholder_tickets.md` discipline. When Phase 1 mints real bridges, qa fills the placeholder fields with actual bridge labels + theorem statements + files the tickets at that moment.

This doc cuts filing latency post-mint by pre-authoring everything except the bridge-specific fields.

## Why this exists

v2.7's UNPROVEN→PROVED-via-Lean arc (pythia#88 → pythia#93) showed the pattern: closed-loop mints a bridge invariant in `formal_sst_verif_only` shape, cert ships with `[UNPROVEN : assumed; v2.7 D-spike]` framing, then a follow-up Aristotle / Pythia child closes the bridge as `bridgeFullInv_holds_at_every_co_step` (axiom-audit-clean).

Phase 1 mints will follow the same arc. Each accepted iteration's bridge invariant ships UNPROVEN; v2.8.5-pythia children land the kernel-checked theorems. Pre-authoring the ticket templates saves filing latency when Phase 1 mints.

## Ticket template (copy-paste shape)

For each accepted iteration's bridge invariant, file a ticket of this shape:

```markdown
Title: [Pythia.Hardware.SEC] Phase 1 Annapurna <CELL>: discharge bridge <BRIDGE_LABEL> as kernel-checked Lean theorem

Description:

## Why

ATH-1062 Phase 1 mint of <CELL> on YYYY-MM-DD produced an iteration arc with at least one ACCEPTED iteration discharged via bridge invariant <BRIDGE_LABEL>. Cert prose ships UNPROVEN-as-Lean (PROVED-with-assume-property) per the v2.7 → v2.8 arc pattern; this Aristotle / Pythia child closes the bridge as a kernel-checked Lean theorem so the cert can flip to PROVED-via-Lean (axiom-audit-clean).

## What

Author the Lean theorem `Pythia.Hardware.SEC.<CellShortName>.<bridgeLabelCamelCase>_holds_at_every_co_step` proving:

```
For every co-step trace `(goldStep, gateStep)` starting from any reachable
state satisfying <BRIDGE_LABEL_SV_EXPR>, the post-step state pair also
satisfies <BRIDGE_LABEL_SV_EXPR>. Equivalently: <BRIDGE_LABEL> is preserved
by the gold/gate Mealy step.
```

Type signature template:

```lean
theorem <bridgeLabelCamelCase>_holds_at_every_co_step
    (gold gate : <CellShortName>State)
    (h : <bridgeLabelCamelCase> gold gate)
    (in_signal : <CellShortName>Input) :
    <bridgeLabelCamelCase>
      (<CellShortName>Step gold in_signal)
      (<CellShortName>Step gate in_signal) := by
  -- proof body
```

Pythia source path: `Pythia/Hardware/SEC/<CellShortName>.lean` extends the existing `Pythia/Hardware/SEC/FifoWidget.lean` pattern.

## Acceptance

- [ ] `<bridgeLabelCamelCase>_holds_at_every_co_step` lands in Pythia source under `Pythia.Hardware.SEC.<CellShortName>`
- [ ] `lake env lean --run AxiomAudit.lean` returns axiom-audit-clean (only `propext`, `Classical.choice`, `Quot.sound`)
- [ ] Type signature matches the cert prose claim verbatim
- [ ] qa updates ATH-1062 cert prose: `[UNPROVEN : assumed; v2.8 D-spike]` → `[PROVED via Pythia.Hardware.SEC.<CellShortName>.<bridgeLabelCamelCase>_holds_at_every_co_step]`
- [ ] Per `feedback_cert_against_actual_lean_source_not_proposal_doc.md`: cert authoring AGAINST the actual Lean source not against this ticket text. cto WRITES proofs → qa READS the Lean source → qa AUTHORS the cert flip.

## Cross-refs

- Parent: ATH-1062 Phase 1 dogfood (this cell's mint).
- Sibling pattern: pythia#88 → pythia#93 v2.5 → v2.6 arc closure.
- Phase 1 mint run_id: <RUN_ID> (filled in post-mint).
- v2.7 Aristotle queue precedent: invFifoStateBridge_holds_at_every_co_step + invStateSync_holds_at_every_co_step (pending v2.8 follow-up).

_Filed by: @qa (canonical) · YYYY-MM-DD_
```

## Pre-mint forecast (what bridges Phase 1 LIKELY mints)

Based on the Annapurna cell shapes + Gil's primer set, the LIKELY bridge invariants Phase 1 will mint:

### AP_REG_FIFO_REPL (Cell 1, smallest)

REPL is a wrapper-of-wrappers around `AP_REG_FIFO_US` instances. The proposer is constrained to interface-preserving rewrites (port-list byte-identical + capacity-preserving + combinational-output-equivalence). Likely transformations:

- `parameterization` class: trim the `FIFO_REPL_BITS` chunking parameter
- `structural` class: replace per-instance one-hot pointers with shared binary count register

Likely bridge invariant shapes (FORECAST, not authoritative):

- `inv_repl_chunk_state_eq` : gold's per-chunk one-hot pointer == gate's binary count
- `inv_repl_data_packed` : gold's flop-array data slices == gate's packed-mem slices

Number of v2.8.5-pythia tickets expected: 1-2 (per accepted iteration's bridge).

### AP_REG_FIFO_US (Cell 2, with Gil's primers)

Substantive cell with 8 Gil-primer invariants. The LLM proposer reads Gil's primers + extends them. Likely transformations:

- `structural`: one-hot pointer → binary count register (mirrors v2.7 toy_fifo iter 0 pattern); proposer's bridge will reference `invar_fifo_valid_vec` Gil-primer
- `impl_swap`: flop-array → packed register (mirrors v2.7 toy_fifo iter 2 pattern); proposer's bridge maps mem cells to packed slices

Likely bridge invariants (FORECAST):

- `inv_fifo_state_bridge_extending_gil` : extends `invar_fifo_valid_vec` + `invar_fifo_full_empty_ptrs` to gold-vs-gate state correspondence
- `inv_fifo_packed_mem_eq` : per-cell mem map to packed slices

Number of v2.8.5-pythia tickets expected: 2-3.

### AP_ALU_US (Cell 3, combinational)

Combinational SEC under BMC bound 0. NO bridge invariants needed (output equality across all input combinations IS the proof; no state-correspondence required).

Number of v2.8.5-pythia tickets expected: **0**. Honest-framing in cert prose explicitly states "combinational; no bridge invariant; no Lean follow-up needed."

## Total v2.8.5-pythia ticket forecast

3-5 tickets across Cells 1+2; 0 for Cell 3. Names + theorem statements fill in post-mint. cto-Pythia / asabi own the actual Lean authoring per `feedback_cert_against_actual_lean_source_not_proposal_doc.md` discipline.

## When to convert this doc into Linear tickets

Trigger: ATH-1062 Phase 1 fires + 3 cell mints land. At that moment:

1. qa reads each cert's bridge_invariants from the engine emit.
2. For each bridge_invariant in each accepted iteration: copy the ticket template above, fill in `<CELL>` / `<BRIDGE_LABEL>` / `<BRIDGE_LABEL_SV_EXPR>` / `<RUN_ID>` / `<CellShortName>` / `<bridgeLabelCamelCase>` from the actual mint.
3. File as Linear tickets under a v2.8.5 epic (or ATH-1061 sub-issue if cleaner).
4. Notify cto / asabi for Pythia authoring.
5. Update ATH-1062 cert prose with the `[UNPROVEN : assumed; v2.8 D-spike]` → `[PROVED via Pythia...]` flip arc once each Lean theorem closes.

## Why this is doc-not-tickets right now

Per `feedback_no_placeholder_tickets.md` (Aidan 2026-05-03): no placeholder tickets. Filing tickets BEFORE the bridge invariants exist would be placeholder work : empty fields, no acceptance, no real implementation. Doc-shape forward-pin sidesteps the rule while still saving filing latency post-mint.

## Cross-refs

- Parent: ATH-1062 Phase 1 dogfood.
- Companion: `phase1-dogfood-checklist.md` (the operational doc that fires the mints these tickets close behind).
- Pythia precedent: pythia#88 + pythia#93 (v2.5 → v2.6 arc).
- Discipline: `feedback_cert_against_actual_lean_source_not_proposal_doc.md` (cto WRITES proofs → qa READS → qa AUTHORS cert).
- Discipline: `feedback_no_placeholder_tickets.md` (Aidan rule that drives doc-not-tickets shape).
