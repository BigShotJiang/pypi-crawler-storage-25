# ATH-1062 Phase 1 dogfood checklist (qa lane)

Per-cell mint sequence + acceptance criteria + customer-eye-fourth-pass items for ATH-1062 Phase 1 against Annapurna basic_cells.

This is the operational doc qa reads against when firing the dogfood AND when reading the resulting cert as Todd-pretend before any Aidan-gate. Same checklist on both sides keeps the fire ↔ audit loop honest per `feedback_customer_eye_review_before_ship.md`.

## Pre-fire prerequisites

ALL of the following must be on `main` before firing the first dogfood mint:

Foundation PRs (all merged on main per the 2026-05-07 Phase 0a-wiring close):

- [x] PR #511 ATH-1063 Phase 0a schemas
- [x] PR #512 ATH-1063 Phase 0f invocation_path
- [x] PR #513 ATH-1063 Phase 0b signature_gen
- [x] PR #514 ATH-1062 annapurna_basic_cells bundles
- [x] PR #515 ATH-1063 Phase 0e onboarding guide first draft (sections 1-4 + 8)
- [x] PR #516 ATH-1063 Phase 0c yosys synth hook
- [x] PR #517 ATH-1063 MCP server integration tests
- [x] PR #518 ATH-1064 Phase 3 design doc
- [x] PR #519 v2.7 demo_driver k-bound 10 to 32
- [x] PR #520 MEM_1P bundle (Phase 3 forward-pin fixture)
- [x] PR #521 ATH-1059 doctor refspec check
- [x] PR #523 ATH-1063 Phase 0a-wiring commits 2a/2b/2c/3 (sha 605cb16): library extraction `kairos.sec.closed_loop.run_closed_loop_orchestration()` + 5 MCP callable bindings in `load_paid_extensions`
- [ ] PR #524 qa xfail-removal follow-up on `test_mcp_server_integration.py::test_mcp_server_advertises_phase_0a_wiring_closed_loop_tools_post_binding` (1-line; in flight)

NEW prerequisites surfaced by cto's pre-fire EBMC validation 2026-05-07:

- [ ] ATH-1074 dep_files schema extension + plumbing (PR #525 In Progress on cto/ath-1074-dep-files-schema). Phase 1 RTL is multi-module: AP_REG_FIFO_REPL deps on AP_REG_FIFO_US, AP_REG_FIFO_US deps on AP_DFFR_US. Without `dep_files: list[str]` in signature.json + plumbing through `verify_sec` + `yosys_gate_count` + `_emit_iteration_arc_for_proposal`, EBMC parse fails on missing module references. Per asabi commit pending: dep_files plumbed + AP_DFFR_US / AP_REG_FIFO_US bundled into Phase 1 inputs/.
- [ ] ATH-1076 EBMC SV-elaboration pipeline (yosys-elaborate-first preprocessing helper). Two real EBMC parser blockers caught pre-fire on Phase 1 RTL: AP_REG_FIFO_REPL line 55 uses `for(genvar i = 0; i < N; i++)` which EBMC 5.10 doesn't accept (post-increment on genvar); AP_REG_FIFO_US line 292 has the `uvm_macros.svh` include inside an `ifdef SIMULATION` block but EBMC's preprocessor resolves the include even when SIMULATION isn't defined. Fix: `kairos.sec.preprocess.yosys_elaborate_to_verilog` helper that runs `yosys read_verilog -sv` + `hierarchy -check` + `flatten` + `write_verilog -noattr` to produce plain Verilog EBMC parses cleanly. Manually validated end-to-end by cto.
- [ ] ATH-1075 AP_ALU_US deferred to Phase 1.5 (Backlog): `include "ap_func_US.inc"` references a file Todd's common_rtl.tar.gz package doesn't ship. Customer-facing ask staged in #project-annapurna for next Todd contact. Phase 1 v1 fires on AP_REG_FIFO_REPL + AP_REG_FIFO_US only (2 of 3 originally-planned targets). AP_ALU_US re-scopes to Phase 1.5 once Todd ships the include.

Platform-side prerequisite for the post-mint render:

- [ ] ATH-1073 platform follow-up PR (route extension + V27IterationArcPanel two-column claim-vs-verify render + bug 2 cert-404-short-circuit fix). Backlog, in flight per platform commitment. Required so post-Phase-1-mint renders show the claim-vs-verify pair fields surfaced from PR #523's iteration_verdict schema extension.

Pre-fire smoke checks:

- [ ] `git fetch origin main && git reset --hard origin/main` from a clean qa worktree; verify HEAD includes ALL above PRs
- [ ] `python3 -m pytest tests/ -q` passes (full suite, no skips except known-environment-dependent)
- [ ] `kairos doctor` PASSES on git-fetch-refspec check (ATH-1059)
- [ ] `from kairos.sec.closed_loop import run_closed_loop_orchestration` imports without ImportError
- [ ] `from kairos.synth import yosys_gate_count` imports + `yosys --version` returns clean
- [ ] `from kairos.sec.preprocess import yosys_elaborate_to_verilog` imports without ImportError (ATH-1076 helper)

EBMC parse-clean smoke gate (ATH-1076 regression net, fires BEFORE any LLM proposer call to save tokens). EBMC 5.10 has no `--parse-only` flag; `--show-modules` exits 0 on clean parse and is used as the proxy:

- [ ] `yosys_elaborate_to_verilog` against `examples/customer/annapurna_basic_cells/AP_REG_FIFO_REPL/inputs/AP_REG_FIFO_REPL.v` produces well-formed elaborated Verilog (~6KB per cto manual validation)
- [ ] `ebmc --show-modules` on the elaborated REPL form returns 0 (parser advances past `for(genvar i = 0; i < N; i++)` on line 55)
- [ ] `yosys_elaborate_to_verilog` against `examples/customer/annapurna_basic_cells/AP_REG_FIFO_US/inputs/AP_REG_FIFO_US.v` (with deps from ATH-1074 plumbing) produces well-formed elaborated Verilog (~3KB per cto manual validation)
- [ ] `ebmc --show-modules` on the elaborated US form returns 0 (parser advances past `uvm_macros.svh` ifdef-include + `logic` keyword + duplicate-iterator blockers)
- [ ] `tests/test_sec_preprocess_yosys_elaborate.py` 4-assert parametrized suite passes (parses clean + port-list preserved + byte-deterministic + identity-equivalence round-trip via EBMC PROVED on gold-vs-renamed-gold miter)

If any pre-fire item is missing, halt the fire + notify cto. NO LLM-DRIVEN FIRES until full stack assembled per Aidan no-waste-tokens directive.

## Mint sequence (in order)

### Cell 1: AP_REG_FIFO_REPL (smallest standalone FIFO)

**Why first**: smallest target (110 LoC). Validates pipeline holds against real RTL. Single-iteration likely closes inside k=32 default.

**Invocation**:

```sh
cd examples/customer/annapurna_basic_cells/AP_REG_FIFO_REPL/
KAIROS_DEV_NO_LICENSE=1 python3 demo_driver.py \
  --signature signature.json \
  --bound 32 \
  --model anthropic/claude-opus-4-6
```

(Exact CLI form depends on cto's `run_closed_loop_orchestration()` library extraction; update post-Phase-0a-wiring landing.)

**Expected runtime envelope**: 5-15 minutes for 3 iterations × (LLM proposer + EBMC BMC + bridge gen + EBMC k-induction). Anomaly threshold: > 30 min = halt + diagnose.

**Cert prose acceptance criteria** (post-mint):

- [ ] `01-customer-block-certificate-v2.8.md` exists with verdict table covering each iteration
- [ ] At least 1 iteration is `ACCEPTED` (any class : parameterization / structural / impl_swap)
- [ ] Per-iter cert prose names `claimed -X.X%` area delta with `claimed`-not-`verified` framing (Phase 1 ships claimed-only; Phase 2 yosys flip lands later)
- [ ] Per-iter bridge invariants disclosed in `02-iteration-arc-discharge.md` verbatim from engine emit
- [ ] EBMC subprocess captures verbatim under `_sec_work/iter_N_bundle/_sec_work/ebmc_*.{stdout,stderr,exitcode,cmdline}` per Aidan path-a directive
- [ ] No `formal_invariants_primer` references in cert prose for REPL (REPL has no Gil-invariants; all primers come from REG_FIFO_US)
- [ ] `is_combinational: false` honored : cert references k-induction at bound 32 not bound 0

**Customer-eye-fourth-pass items**:

- [ ] cert prose passes md-lint clean (no em-dash, no AI-fingerprint phrases, no banned vocabulary)
- [ ] every numeric claim traces verbatim to engine emit (qa runs `kairos.cert._bundle_audit.cross_check_bundle_against_engine_emit()` on the bundle; expect 0 findings)
- [ ] `build-tarball.sh` all 11 gates pass (Gate 11 Layer 1 audit + Gate 4f STALE_TOKENS + the rest)
- [ ] No prior-canonical references (the v2.7 4d9f013c run_id should not appear; this is a new run_id from the Phase 1 mint)
- [ ] Honest framing on UNPROVEN-as-Lean: every bridge invariant the LLM proposes is disclosed as `[UNPROVEN : assumed; v2.8 D-spike]` until Aristotle queue lands the kernel-checked theorem (see `phase1-aristotle-queue.md`)

### Cell 2: AP_REG_FIFO_US (substantive demo with Gil's primers)

**Why second**: ~200 LoC body + 8 hand-written `formal_sst_verif_only` invariants from Gil Stoler. Substantive demo target. Validates the proposer extends Annapurna's existing formal flow rather than running parallel.

**Invocation** (same shape as Cell 1, point at `AP_REG_FIFO_US/`):

```sh
cd examples/customer/annapurna_basic_cells/AP_REG_FIFO_US/
KAIROS_DEV_NO_LICENSE=1 python3 demo_driver.py \
  --signature signature.json \
  --bound 32 \
  --model anthropic/claude-opus-4-6
```

**Expected runtime envelope**: 8-20 minutes (deeper state space than REPL; k=32 BMC + k-induction may take longer per iteration).

**Cert prose acceptance criteria** (additional to Cell 1's items):

- [ ] LLM proposer prompt INGESTED Gil's 8 invariants from `signature.json::formal_invariants_primer[]` as starter set (verify in trace_schema event for the `transformation_proposed` event : `proposer_input_primers` field should list all 8)
- [ ] At least 1 of the LLM's bridge invariants references / extends Gil's primer set (e.g. proposer's bridge invariant clause uses `fifo_valid_x` which Gil's `invar_fifo_valid_vec` constrains)
- [ ] Cert prose cites Gil Stoler's primer-set in the honest-framing section: "kairos extends Annapurna's existing formal flow per Gil Stoler's `formal_sst_verif_only` invariants"

**Customer-eye-fourth-pass items** (additional to Cell 1):

- [ ] Audit module catches any drift between cert prose claims of "primers used = 8" and actual proposer event payload
- [ ] Bridge-invariant primer attribution is honest: cert distinguishes "Gil-primed" vs "LLM-extended" clauses

### Cell 3: AP_ALU_US (combinational, domain generality)

**Why third**: 148 LoC combinational ALU. Demonstrates pipeline isn't only-good-for-FIFOs. Different proof shape (BMC bound 0).

**Invocation**:

```sh
cd examples/customer/annapurna_basic_cells/AP_ALU_US/
KAIROS_DEV_NO_LICENSE=1 python3 demo_driver.py \
  --signature signature.json \
  --bound 0 \
  --mode bmc_combinational \
  --model anthropic/claude-opus-4-6
```

(Or library auto-detects `is_combinational: true` from signature.json + sets bound=0 + mode automatically.)

**Expected runtime envelope**: 3-10 minutes per iteration. Combinational SEC under bound 0 BMC is fast.

**Cert prose acceptance criteria** (additional to Cell 1):

- [ ] `is_combinational: true` honored throughout (cert references bound 0 BMC, not k-induction)
- [ ] Bridge invariants are NONE (combinational equivalence doesn't need state-correspondence bridges)
- [ ] Structural transformation candidates make sense for ALU (tree-balance / carry-lookahead / barrel-shifter consolidation per the README's transformation-candidates section)
- [ ] No bridge-invariant primer in `signature.json` (ALU has no formal block to harvest from)

**Customer-eye-fourth-pass items** (additional to Cell 1):

- [ ] Cert prose explicitly states "combinational equivalence verified at BMC bound 0; k-induction not applicable" : must NOT claim "k-induction PASS at k=32" because that doesn't apply to combinational logic. Catches a class of LLM-prose-drift where the proposer thoughtlessly inherits k-bound language from FIFO certs.

## Cross-cell aggregate acceptance (post-3-cells-mint)

After all three cells mint successfully:

- [ ] 3 separate `customer-block-certificate` bundles under `examples/customer/annapurna_basic_cells/<CELL>/`
- [ ] Each bundle's `build-tarball.sh` produces a tarball that passes Gate 11 Layer 1 audit clean
- [ ] Per-iter run_ids are distinct (3 cells × N iterations)
- [ ] Aggregate metrics: total iterations across 3 cells (likely 9), total accepted (likely 3+), total refuted (variable), total inconclusive (0 ideal)
- [ ] Phase 2 follow-up scope: re-mint each with yosys synth pass, flip cert prose `claimed -X.X%` to `verified -N gates`. This is cto-lane Phase 2 work (ATH-1060 Layer D), but qa kicks the trigger when Phase 1 mints clean.

## Aidan-gate handoff

When all 3 cells are minted + customer-eye-fourth-pass clean:

- [ ] Post a single thread to `#dev-sdk` (or whichever channel Aidan picks) summarizing the 3 mint results + linking to each bundle dir + flagging any honest-framing surfaces (UNPROVEN-as-Lean status, Phase 2 re-mint pending, etc.)
- [ ] WAIT for Aidan greenlight before posting to #project-annapurna or sharing with Todd. Per `feedback_no_customer_ship_without_aidan_approval.md` discipline.
- [ ] If Aidan greenlights ship: build-tarball each bundle, ship to `#project-annapurna` referencing Todd's prior tarball ts.
- [ ] If Aidan flags any surface for fix: cycle through customer-eye-fourth-pass per the receipt-3 discipline. Aidan-gate stands.

## Failure modes + recovery

Per-cell failure mode classifier:

- **Proposer LLM-error mid-call**: retry up to 3 attempts with backoff; if 3 fails → fall back to second-choice model from `KAIROS_LLM_FALLBACK_MODELS` env (per asabi 2026-04-23 customer-portable fallback). Document the fallback in cert prose.
- **EBMC parse error**: cell signature.json has `concrete_for_sec` parameter values that may not work with all FIFO_DEPTH; try concrete_for_sec=4 first, fall back to 8 / 16. Document the parameter in cert prose.
- **k-induction INCONCLUSIVE at k=32**: escalate to k=64, then k=128 per `feedback_higher_k_induction_bound_whenever_possible.md`. Document the actual bound used.
- **k-induction REFUTED hard**: this iteration's gate variant is genuinely not equivalent. Cert reports REFUTED honestly. NEXT iteration runs.
- **Yosys synth missing** (Phase 2 re-mint only): cert prose stays `claimed -X.X%` framing; flag for follow-up when synth env lands.

## Cross-refs

- Parent: ATH-1062 Phase 1 dogfood.
- Foundation: ATH-1063 (kairos MCP + signature_gen + yosys + onboarding guide).
- Sequenced after Phase 0a-wiring lands per asabi 2026-05-07 alignment.
- Companion: `phase1-aristotle-queue.md` (v2.8.5 Pythia children forward-pin).
- Bundle dirs: `examples/customer/annapurna_basic_cells/AP_REG_FIFO_REPL/`, `AP_REG_FIFO_US/`, `AP_ALU_US/`.
- v2.7 reference cert pattern: `examples/customer/toy_fifo_chain_v2.7_area_opt/01-customer-block-certificate-v2.7.md`.

## Operational notes

- This checklist is read in TWO directions: qa-as-fire (left-to-right per cell) AND qa-as-Todd-pretend (audit each item post-mint). Both reads keep the fire ↔ audit loop honest.
- No LLM-driven fires until the pre-fire prerequisites are ALL on main + smoke checks pass. Half-stack fires waste tokens AND produce certs that fail customer-eye review.
- Aidan-gate stands per `feedback_no_customer_ship_without_aidan_approval.md`. Customer-eye-fourth-pass before any Aidan-gate ask. asabi receipt-3 fourth-pass pattern carries through.
