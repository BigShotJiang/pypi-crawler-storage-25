# ATH-1064 Phase 3 power_gating module : design sketch

qa-lane prep work for the Phase 3 module (`kairos.sec.power_gating`) per ATH-1064. Internal scratch : no implementation lands until Phase 1 + Phase 2 close.

Context: Todd's second optimization vector at slack ts 1778108242: "rtl/mem_wrapper/rtl could have cases where memory is accessed when it's not supposed to be causing power issues." Read: prove ME (memory enable) can be dropped on cycles where the read result Q is not consumed downstream.

## Formal shape

Different from Phase 1's basic_cells structural rewrites (which use cycle-bit-equality miters). Power-gating uses TEMPORAL OBSERVABLE-EQUIVALENCE.

**Gold model**: `ME[t] = upstream_request[t]`. Whenever an upstream client requests memory access, ME asserts.

**Gate model**: `ME[t] = upstream_request[t] AND downstream_will_consume_Q[t+latency]`. Optimized: ME asserts only when downstream will actually read the result.

**Equivalence claim** (the customer-trust contract): for every input trace, the OBSERVABLE downstream behavior matches between gold and gate. The Q[t] value differs in cycles where downstream doesn't read it (gold reads memory and produces a real Q; gate gates ME and produces don't-care Q), but the observable signals downstream of the wrapper are identical.

Power saving estimate (NOT formally verified by EBMC): `gated_cycles_fraction × per_access_dynamic_energy`. The `gated_cycles_fraction` IS verified by counting gated cycles in a long-enough simulation trace under random inputs satisfying the observable-equivalence constraint.

## Why this is structurally different from Phase 1

Phase 1 (cycle-bit-equality):
- Miter: `gold(in) == gate(in)` at every cycle for every input
- Bridge invariants tie gold/gate INTERNAL state to align state-encodings
- BMC + k-induction with `assume property(bridge)` proves output-equality

Phase 3 (temporal observable-equivalence):
- Miter: `downstream_consumer(gold(in)) == downstream_consumer(gate(in))` at every cycle for every input
- Q[t] is FREE (don't-care) in cycles where `downstream_will_consume[t]` is false
- "Free Q" abstraction is the formal hook that lets gate gate ME without breaking the proof

ATH-1060's 11 pressure points all assume cycle-bit-equality miter; this is a NEW pressure-point class.

## Multi-module miter shape

```
                  upstream_request
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
    [gold_wrapper]  [gate_wrapper]  [downstream_consumer_stub]
        │               │               │
        Q_gold          Q_gate          consume_signal
        │               │               │
        └───────┬───────┘               │
                ▼                       ▼
          MUX(consume,                downstream
              Q_gold,                 observable
              Q_gate)                 outputs
                │                       │
                └───────────┬───────────┘
                            ▼
                     ASSERT: gold_observable == gate_observable
```

The downstream_consumer_stub is engineer-authored: a small module declaring "I read Q[t+latency] into this register and produce these observable outputs." The stub:
- Reads Q[t+latency] only when `consume[t]` is asserted
- Free behavior on Q[t+latency] when `consume[t]` is false (the don't-care)
- Produces observable outputs that the equivalence assertion checks

## API surface

```python
# kairos/sec/power_gating/__init__.py
from kairos.sec.power_gating import (
    verify_power_gating,
    PowerGatingResult,
)

result = verify_power_gating(
    bundle_path=Path("examples/customer/annapurna_mem_wrapper/MEM_1P/"),
    canonical_engine_emit={...},  # for cross-check audit
)
# PowerGatingResult.closed: bool
# PowerGatingResult.observable_predicate: str (the SV expression of what's observed)
# PowerGatingResult.gated_cycles_fraction: float
# PowerGatingResult.assumption_stack: list[str]
```

## signature.json schema extensions

New fields specific to power_gating bundles:

```json
{
  "target_module": "MEM_1P",
  "block_class": "memory_wrapper",
  "is_power_gating_target": true,
  "ports": [...],
  "memory_enable_port": "ME",
  "read_data_port": "Q",
  "memory_latency_cycles": 1,
  "downstream_consumers": [
    {
      "name": "primary_reader",
      "stub_path": "inputs/downstream_stub_primary.v",
      "observable_signals": ["primary_reader.observable_out"],
      "consume_predicate": "primary_reader.consume_signal"
    }
  ],
  "energy_per_access_pj": 12.5,
  "k_induction_bound": 32,
  "k_induction_escalation_ladder": [32, 64, 128]
}
```

The `consume_predicate` across all `downstream_consumers` is OR'd at miter-build time:

```
consume[t] = primary_reader.consume_signal[t]
          || secondary_reader.consume_signal[t]
          || ...
```

Gating is safe when `consume[t] == 1'b0` for ALL consumers; if any consumer might consume on cycle t, ME asserts.

`is_power_gating_target` flag tells the demo_driver to use `kairos.sec.power_gating.verify_power_gating()` instead of `kairos.sec.closed_loop.run_closed_loop_orchestration()`. Different proof flow = different module entry-point.

## New trace_schema event

`power_gating_verdict`:
- `iteration_index`: int (0 for v0; future iterations could refine the gate)
- `parent_run_id`: UUID
- `gated_cycles_fraction`: float
- `energy_saving_estimate_pj`: float
- `observable_predicate`: str
- `downstream_consumer_class`: str (e.g. "axi_read_response", "fifo_push", "register_read")
- `outcome`: Literal["accepted", "refuted", "inconclusive"]
- `bridge_used`: str | None (the SV expression of any bridge invariant required)

## Module-internal structure

```
src/kairos/sec/power_gating/
├── __init__.py                 # public API: verify_power_gating, PowerGatingResult
├── _miter_multi.py             # multi-module miter assembly
├── _observable_predicate.py    # extract observable signal set from signature.json
├── _stub_validator.py          # validate the downstream_stub module shape
└── _verify.py                  # EBMC invocation + verdict parsing
```

## Test plan (per feedback_test_coverage_never_goes_down)

- pytest unit: multi-module miter assembly correctness (4+ cases covering gate vs gold, free-Q-on-non-consume, observable-predicate composition, latency-aware consume window).
- pytest unit: observable-predicate parsing from signature.json (3+ cases).
- pytest unit: downstream_stub validation (3+ cases : port-list match against signature, free behavior on non-consume cycles, observable-output declaration).
- Integration: end-to-end `verify_power_gating()` on `MEM_1P` (48 LoC) with engineer-authored stub. Skip-clean if EBMC absent.
- Integration: end-to-end on `cce_ram_1w1r_64x128_n3p_wrapper_p32_w32` (309 LoC) with auto-generated stub. Skip-clean.
- Pydantic schema validation: `power_gating_verdict` event payloads validate against the new strict schema.
- Cross-arm contract test: power_gating cert prose `verified power-saving = N gated-cycles × M pJ/access` traces verbatim to the engine emit fields.

## Honest framing surface (cert prose discipline)

The cert prose for a power_gating bundle reports:

```
PROVED-with-stub-completeness-assume:
  Under the assumption that downstream_stub captures all observable
  consumers of Q[t], the gate variant's gating of ME is observably
  equivalent to gold for every input trace.

  Verified:
    - Observable signals identical: downstream_stub.observable_out
    - Gated-cycles fraction: 0.42 (under random inputs satisfying
      consume_predicate)
    - Energy saving estimate: 0.42 × 12.5 pJ/access = 5.25 pJ/cycle

  Assumed (not verified):
    - downstream_stub captures all consumers of Q[t]. If a real
      downstream module reads Q[t] under a condition not modeled
      in the stub, the equivalence does not transfer. Engineer is
      responsible for stub-completeness audit.
```

The "assumed (not verified)" framing is critical per `feedback_no_vacuous_proves_multi_layer.md` discipline. Stub-completeness is itself UNPROVEN-as-Lean class : same shape as v2.7's bridge-invariant assumption stack.

## Resolved decisions (asabi 2026-05-07 locks)

1. **Stub authoring**: ENGINEER-AUTHORED, not auto-inferred. The customer is the engineer working on the parent block; only they know what their downstream consumer cares about. Auto-inference is fragile + hides assumptions. `signature.json` carries `downstream_stub` field; engineer fills it when marking `is_power_gating_target: true`. Per the same-LLM rule shape: humans author the consume_predicate, the LLM doesn't speculate. Auto-infer is OUT of scope for v2.8; Phase 3 follow-up only if customer ask surfaces it.

2. **`gated_cycles_fraction` measurement**: FORMAL COUNTING via the `consume_predicate` over a bounded reachable-state envelope. Random-input simulation is a regression-test backstop only. Customer-trust contract on the energy savings demands a proven gating fraction, not a sampled one. The `gated_cycles_fraction` shipped in the cert is verified-not-claimed.

3. **Multiple downstream consumers**: list shape `downstream_consumers: [DownstreamSpec, ...]` in `signature.json`. `consume_predicate` is OR'd across all consumers; gating is safe when no consumer's consume_predicate is true. Per-consumer cost-of-stub-completeness disclosed in honest-framing cert prose.

4. **Latency variance**: lock the bound to `memory_latency_cycles` + 1-cycle slack window. Outside the window = stub-completeness violation, fail-loud. Variable-latency consumers (1-3 cycles based on stalls) are OUT of scope for v2.8; v2.9 follow-up.

5. **EBMC bound for temporal proof** (Aidan 2026-05-07 fleet directive: "we always want to push for higher bound, k induction whenever possible"): start `k=32` default : higher than the v2.7 `k=12` baseline and Phase 3 initial sketch's `k=20`. Expose as `k_induction_bound` parameter on `verify_power_gating()`. Adaptive escalation envelope: start `k=32`; on INCONCLUSIVE-without-counterexample, retry at `k=64`, then `k=128`. De-escalate ONLY when wall-clock budget exceeds the per-iteration cap. Compute-budget cap is the constraint, not low-k convenience. ATH-1060 Layer-extension follow-up captures the actual envelope across mem_wrapper variants once implementation surfaces the canonical range. Same higher-bound discipline applies to Phase 1 + Phase 4 work ; ATH-1060 pressure-point #5 ("k-induction bound default 12") needs to lift fleet-wide per Aidan directive.

## Sequencing

- **Phase 1 close** (qa lane): AP_REG_FIFO_REPL + AP_REG_FIFO_US + AP_ALU_US dogfood mints land. Phase 1 is cycle-bit-equality; doesn't touch power_gating.
- **Phase 2 close** (cto lane): yosys synth hook flips Phase 1 certs from claimed to verified gate-count.
- **Phase 3 starts here** (qa lane): kairos.sec.power_gating module + 1-2 mem_wrapper bundle mints. Different proof flow, different cert prose.
- **Phase 4 close** (cto lane): CEGAR loop driving FV_REDUCTION_LEVEL on AP_FIFO_CTRL_BASE_US.
- **Phase 5** (cto+qa joint): chunked proposer + structured bridge.

Phase 3 is independent of Phase 4 (different formal flows); they run in parallel after Phases 1+2 close.

## Design-doc next steps

This sketch covers the formal shape + module surface + cert framing. Implementation needs:

1. EBMC invocation script for multi-module miter (likely an extension of `kairos.sec.build_miter` to accept multi-instance hierarchy).
2. Concrete downstream_stub.v for MEM_1P first target (qa-author by hand; informs the auto-infer scope later).
3. Pydantic model for `power_gating_verdict` event in `kairos.trace_schema`.
4. Build-tarball Gate 12 extension to validate power_gating-class certs (different fields than basic_cells gate-count flow).

Total estimated lift: ~600-800 LoC across the new module + tests + signature.json schema bump + trace_schema extension. Comparable to PR #513 Phase 0b (~1000 LoC including tests).

Decision-pending on the open questions above before implementation kicks off post-Phases-1+2.
