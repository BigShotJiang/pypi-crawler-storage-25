# Single-model (one-token) mode

**ATH-336.** Enterprise customers (Amazon etc.) may arrive with a single
API key from a single provider (Anthropic Bedrock, Azure OpenAI,
Google Gemini, direct Anthropic). The Athanor fleet pipeline normally
routes phases to different providers (Opus planner, Sonnet builder,
Kimi builder-race, Pro + Opus + Speciale triple-voice audit). Under
single-model mode every role routes to the one model the customer
provisions.

## How to enable

Two equivalent entry points:

```bash
# CLI flag on solve/shared/modes/mode_fleet.py
python3 solve/shared/modes/mode_fleet.py --single-model openai/kimi-k2.5 ...

# Environment variable (also picked up by RunConfig defaults and by
# solve/shared/phases/spec_validate_llm.py coherence gate)
ATHANOR_SINGLE_MODEL=openai/kimi-k2.5 python3 solve/shared/modes/mode_fleet.py ...
```

CLI flag wins when both are set. Absent either, the fleet uses the
default per-role cascade.

## What gets overridden

| Role | Default | Under --single-model |
|:-|:-|:-|
| Phase -2 spec coherence | `anthropic/claude-opus-4-6` | single model |
| Phase -1 opus plan | `claude-opus-4-6` | single model |
| Phase 0 builder race | `{sonnet, pro, kimi}` | single model × 3 |
| Phase 1 property gen | `anthropic/claude-sonnet-4-6` | single model |
| Phase 3 Lean refine | `anthropic/claude-sonnet-4-6` | single model |
| Phase 4 Mathlib close | `anthropic/claude-sonnet-4-6` | single model |
| Phase 5 triple audit | `{pro, opus, speciale}` | single model × 3 |

Phase 2 (mutation sweep) and Phase 6 (bundle + ship) are
deterministic and do not call an LLM.

## Quality degradation matrix

What is lost when the single model is X vs the default multi-provider
cascade, by phase:

| X | Planner (-1) | Builder (0) | Property gen (1) | Lean (3, 4) | Audit (5) |
|:-|:-|:-|:-|:-|:-|
| Opus 4.6 | same | builder-race narrower (three-of-same) | same | same | same-side audit, less cross-provider signal |
| Sonnet 4.6 | marginal ↓ | narrower | same | same | same-side, stronger loss vs Pro + Opus + Speciale triple |
| Kimi K2.5 | ↓↓ (planner is Opus-calibrated) | narrower | ↓ (Sonnet-calibrated prompts) | ↓ (Mathlib fluency weaker) | ↓ (less diverse voice) |
| Mistral Large 3 | ↓↓ | narrower | ↓ | ↓ | ↓ |

**Practical recommendation for enterprise pilots:**

1. **Sonnet 4.6 single-model** - strongest baseline. Phase -1 and Phase 5 will be slightly weaker than the full multi-provider cascade but every phase runs end-to-end without graceful-degradation events.
2. **Opus 4.6 single-model** - marginally better on Phase -1 and Phase 5, more expensive per token, no Phase 0 builder-race diversity.
3. **Kimi K2.5 / Mistral Large 3 single-model** - budget tier. Expect Phase 0 builder-race to collapse (three-of-same), Phase 3 and Phase 4 Lean closure to stall more often. Some theorems that close with Opus-planner + Aristotle cross-check will not close on these models alone.

## Graceful degradation

No fleet phase is allowed to hard-fail because a preferred-model
provider is unavailable. If a customer sets
`ATHANOR_SINGLE_MODEL=openai/kimi-k2.5` and Phase 5 would normally
call Gemini Pro, the phase receives Kimi instead and emits a
`graceful_degradation` event to the run log. Absence of a graceful-
degradation event under single-model mode is a bug; file a ticket.

## Cost implications

Single-provider fleets avoid the inter-provider rate-limit coordination
cost but concentrate spend on one API key. Track via the existing
`solve/shared/cost_tracker.py` instrumentation. Per-phase cost profile
does not change fundamentally; only the per-phase provider shifts.

## Verification checklist (customer pilot)

Before declaring single-model mode production-ready for a customer:

- [ ] `python3 solve/shared/modes/mode_fleet.py --help` exposes `--single-model`.
- [ ] `ATHANOR_SINGLE_MODEL=<X> python3 -c "from solve.shared.phase_runner import RunConfig; ..."` shows every slot defaulting to `<X>`.
- [ ] End-to-end smoke: `solve/sysverilog/run.sh --single-model <X>` on one fixture task exits 0 with a ship / no-ship verdict. Any phase that emits a graceful-degradation event is expected, not a failure.
- [ ] Per-phase spend on the customer's API key fits inside their budget cap (default $50 per task, configurable).
- [ ] Mutation-kill rate on Phase 2 is within 20% of the default-cascade baseline on the same task (if not, file a ticket against Phase 0 builder-race diversity).

_Owner: @cto (asabi). Last updated 2026-04-18 by ATH-336 initial wiring._
