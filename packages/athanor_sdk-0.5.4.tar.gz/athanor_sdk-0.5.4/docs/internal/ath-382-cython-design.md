# ATH-382 - Cython compile for Tier-1 SDK modules

_Status: POC landed for `lint.py` (2026-04-20). Document captures the
design + trade-offs so the remaining modules (`scoring.py`, `lean.py`)
can adopt the same pattern without re-litigating each decision._



## Goal

Stop shipping readable `.py` source for the Tier-1 SDK files per
qa's 2026-04-18 audit (`audit/ATH-341-sdk-audit.md`). Replace with
compiled `.so` binaries where the source text is not cheaply
extractable.

## The options we considered

### Option 1 - build-backend swap to setuptools

The canonical Python-with-extensions toolchain. Would require moving
`pyproject.toml`'s `build-backend` from `hatchling.build` to
`setuptools.build_meta`, re-doing the metadata schema, and
re-validating the publish path. Large blast radius for a narrow
outcome.

**Rejected:** too much moving-part churn mid-V1.

### Option 2 - `hatch-cython` plugin

Third-party hatchling extension that advertises Cython integration.
At time of writing (2026-04-20), it's sparsely maintained and has
open issues for Cython 3.x compatibility.

**Rejected:** unproven dependency for critical IP-protection work.

### Option 3 - external `build_cython.py` + hatchling `artifacts`

Keep hatchling as the build backend. Add a standalone
`build_cython.py` script that compiles `.pyx` → `.so` via Cython's
own machinery. Tell hatchling to pick up `.so` files via the
`artifacts` include rule. The `.pyx` source is excluded from the
wheel; the compiled `.so` ships.

**Chosen.** Smallest delta to the existing build. The CI workflow
that produces the customer wheel invokes `python3 build_cython.py &&
python3 -m build`. That two-step is the only deviation from the
current pure-Python build.

## What shipped in the POC

### New files

- `build_cython.py` - compiles each entry in `PYX_MODULES` list.
  Skips gracefully if the `.pyx` doesn't exist. Idempotent.
  Currently: compiles `_lint_impl.pyx` → `_lint_impl.cpython-*.so`.

- `docs/ath-382-cython-design.md` - this document.

- `src/athanor/_lint_impl.pyx` - the lint module's real
  implementation. Identical to the previous `lint.py` content; `.pyx`
  accepts pure Python as valid syntax so no rewrites were needed.

### Modified files

- `src/athanor/lint.py` - rewritten as a ~50-line shim. Imports
  public names from `athanor._lint_impl` (the compiled binary).
  Falls back to `pyximport` for in-repo development where the build
  step might not have run. Never triggers the fallback in the
  shipped wheel (the `.pyx` is excluded there).

- `pyproject.toml` - added `cython>=3.0` to the `dev` extra;
  configured wheel `exclude = ["*.pyx", "*.pxd", "*.c"]`; added
  `artifacts = ["src/athanor/*.cpython-*.so"]` to force-include the
  compiled outputs.

### Verification

`python3 build_cython.py` produces a `.so`. Full SDK test suite
(991 tests) passes against the compiled import. Critically:

| Probe | Plain `.py` | Cython `.so` |
|:-|:-|:-|
| `cat lint.py` | full source visible | 50-line shim only |
| `inspect.getsource(lint_file)` | full source string | `TypeError` |
| `dis.dis(lint_file)` | bytecode visible | doesn't apply |
| `strings .so \| grep "axiom"` | N/A | 0 matches |
| `strings .so \| grep "bypass"` | N/A | 0 matches |
| `strings .so \| grep "IO\.FS"` | N/A | 0 matches |

The `strings` output on the compiled `.so` leaks zero anti-cheat
vocabulary. Cython 3.2's default module-constant compression handles
the baseline obfuscation case well. A determined reverse-engineer
with Ghidra can still disassemble - Cython is obfuscation, not
encryption - but extraction cost moves from "30 seconds" to "hours
for someone with the right tools." Combined with NDA + proprietary
license that's enough friction for our threat model.

## What's left (follow-ups inside ATH-382)

### Close: compile the remaining Tier-1 files

- `scoring.py` (102 LOC) - docker subprocess wrapper. Low risk to
  compile; same pattern as `lint.py`.
- `lean.py` (262 LOC) - `score_proof` carries the IP scoring weights
  (`1.0 / 0.35 / 0.25 / 0.0`). Compile + run `strings` to verify the
  weights are absent. If they leak, restructure to compute weights
  at runtime from a seeded hash rather than storing as literals.

Each is a small PR: copy `.py` → `.pyx`, rewrite `.py` as a shim,
add to `PYX_MODULES` list in `build_cython.py`, verify. ~30 min
each.

### Beyond ATH-382 (future work)

- **CI integration.** Add a GitHub Actions step that runs
  `python3 build_cython.py` before `python3 -m build`. Linux
  x86_64 only initially (customers run Azure Linux VMs). Cross-
  platform builds (macOS arm64, Windows x86_64) deferred until a
  customer asks for them.

- **Runtime weight derivation.** Even with Cython, string constants
  at module scope leak via `strings` / Ghidra. For the scoring
  weights specifically, compute them from a seeded hash of the
  license id at startup so the binary never contains them as
  literals. Separate ticket (not ATH-382 scope).

- **Remaining ATH-383 migration.** `eval_harness.py` (3,734 LOC),
  `runner.py` (1,618 LOC), `preflight_fleet.py` (395 LOC) are too
  big + too active for the Cython shim pattern - they move out of
  the SDK entirely (into athanor-builder subprocess or platform
  service). ATH-383 covers that. Cython is the wrong tool for
  4,000-LOC modules; for those the right answer is "not on
  customer VM at all."

## Runbook

### When a new Tier-1 file needs Cython protection

1. Identify the file. Confirm via qa's audit or a new review that
   it's actually Tier-1 (crown-jewel IP).
2. Copy `src/athanor/<name>.py` → `src/athanor/_<name>_impl.pyx`
   (leave the `.py` content identical; `.pyx` accepts pure-Python).
3. Rewrite `src/athanor/<name>.py` as a shim, like `lint.py` today:
   `from athanor._<name>_impl import *` with a `pyximport` fallback.
4. Add `("_<name>_impl", SRC_DIR / "_<name>_impl.pyx")` to
   `PYX_MODULES` in `build_cython.py`.
5. Run `python3 build_cython.py` - confirm `.so` is produced.
6. Run the module's tests - confirm imports still work.
7. Run `strings <new>.cpython-*.so | grep <leakable-constant>` -
   confirm no IP-valuable string content leaks. If it does, move
   the constant inside a function body (computed at call-time, not
   module-level) OR derive it from a seeded hash.
8. Update `ip-partitioning.md` to reflect the file's new tier.

### When updating an already-Cythonized file

Just edit the `.pyx`. `build_cython.py` picks up the change on
next run (distutils idempotent rebuild). The `.py` shim doesn't
need to change unless the public surface of the module did.

### When the build fails

- Cython version mismatch: `pip install 'cython>=3.0'`.
- `pyximport` import error in dev: `pip install cython` + run
  `python3 build_cython.py` once to produce the `.so`.
- Platform mismatch (wrong tags in wheel): `.so` files are
  Python-version + platform specific. CI matrix must match
  customer target platform.

## Why not do it everywhere at once

Three reasons:

1. **Validate the pattern first.** A working POC on one file proves
   `build_cython.py` works, the hatchling `artifacts` rule works,
   the pyximport dev fallback works, the test suite passes against
   the compiled form. Burn that in before rolling to 3+ files.

2. **Compile time + wheel size.** Each `.pyx` adds ~0.5s to build
   time and ~300KB to the wheel (Cython overhead per module).
   Acceptable but worth tracking.

3. **Review scope.** This PR is already substantial (new build
   script, new pattern, shim semantics, dev fallback). Adding 3+
   files at once triples the reviewer load for no risk reduction.

ATH-382 follow-up PRs will each be narrower: single file migrations
that reuse the verified pattern.
