# ATH-908 import path: source-visible auditor walkthrough

Drafted 2026-05-01 per asabi's customer-facing sign-off note. Closes
the audit gap Todd flagged the prior week ("can't audit sorry-free
axiom-clean without seeing the source") for the import side of the
ATH-908 cross-tool flow.

This doc is auditor-facing. Each step links to a specific commit /
file / line so a customer auditor can follow the chain end-to-end
without grep'ing the repo.

## What this walkthrough proves

The **import mechanism** is sound on accepted-soundness invariants.
The full EBMC-discovers-then-ACL2-imports loop comes online once the
discovery-side CEGAR work lands (platform Pattern 1, queue position
behind tarball-download). This walkthrough is precise about that
boundary.

What we DO NOT claim here:

- That EBMC discovered the demonstrated invariant in this session
  (the demo loop uses a synthetic invariant matching platform's
  emit shape).
- That the ACL2 proof closes a full refinement-relation between
  cpu_single_issue and cpu_pipelined. The proof closes a specific
  property at a specific observation point.

## The chain

### Step 1: synthetic invariant matches platform's emit shape

A real `kairos.sv.cegar` run produces an `accepted_invariants.json`
in its workdir. The walkthrough fixture uses an exact-shape match:

```json
[
  {
    "name": "halted_zero_during_reset",
    "signal_constraints": {
      "rst_n": 0, "halted": 0, "running": 0, "go": 0, "pc": 0
    },
    "signal_delays": {"halted": 1, "running": 1, "pc": 1},
    "target_signal": "halted",
    "expected_value": 0,
    "provenance": "cegar-iter-1-bound-10",
    "cegar_iteration": 1,
    "cegar_bound": 10,
    "accepted_at_iso": "2026-05-01T15:42:00Z",
    "hypothesis_sv": "assert property (@(posedge clk) !rst_n |-> !halted);",
    "classification": "accepted",
    "confidence": 0.95
  }
]
```

The shape is the contract platform's `kairos.sv.cegar._emit_accepted_invariants`
writes (PR #376) and Builder PR #271's `cegar/loop.py` produces. Both
sides use the same dataclass: `kairos.acl2.EbmcInvariant`.

Source: `tests/integration/test_ath_908_demo_loop.py` `_DEMO_INVARIANTS`.

### Step 2: SDK ingests the JSON file

```python
from kairos.acl2 import import_ebmc_invariants_from_json_file

result = import_ebmc_invariants_from_json_file(
    json_path,
    sv_files=[cpu_pkg.sv, uninterp_op.sv, cpu_single_issue.sv],
    spec_module="cpu_single_issue",
    mode="reprove",  # single trust root
    timeout_sec_per_invariant=300,
)
```

The decoder `_ebmc_invariant_from_event_payload` extracts only the
fields that shape the proof:

- `name`, `signal_constraints`, `signal_delays`, `target_signal`,
  `expected_value`, `provenance`.

Audit fields (`cegar_iteration`, `cegar_bound`, `accepted_at_iso`)
and bonus fields (`hypothesis_sv`, `classification`, `confidence`)
are dropped. They're informational; they cannot influence the proof.

Source: `src/kairos/acl2.py` `_ebmc_invariant_from_event_payload`.

### Step 3: SDK generates Book 1, Book 2, Book 3 ACL2 books

Per invariant, the SDK calls `kairos.acl2.import_ebmc_invariant`
which:

1. Generates **Book 1** (`<module>-design.lisp`): VL parses the SV
   sources, runs `vl-design->sv-design`, embeds the SVEX as a
   defconst `*kairos-svex-design*`. Book 1 is the single source of
   truth for the model.

2. Generates **Book 3** (`<module>-inv-<name>.lisp`): includes Book
   1 + emits the invariant as an `fgl::def-fgl-thm` (mode='reprove')
   that asserts the target signal's SVEX evaluates to expected_value
   under the env constructed from signal_constraints + signal_delays.

`mode='reprove'` is the single-trust-root choice: ACL2 itself
re-proves the invariant via FGL bit-blast. The resulting cert has
no axiom dependency on EBMC's verdict: only on VL translation
faithfulness, ACL2's logic, and the FGL clause processor.

Source: `src/kairos/acl2.py` `_generate_invariant_book`,
`_generate_two_book_proof`.

### Step 4: cert.pl certifies the books

```
cert.pl --acl2 /path/to/saved_acl2 cpu_single_issue-inv-halted_zero_during_reset
```

Both Book 1 and Book 3 must certify cleanly. Book 1's certification
includes a cw diagnostic that prints `[kairos] vl-design->sv-design
good-mods: <N>` to surface env-diff failures (different VL/SV book
chains may produce different translation outcomes: the diagnostic
makes those visible in `cert.out`).

Source: `src/kairos/acl2.py` `import_ebmc_invariant` (cert.pl
invocation).

### Step 5: result correlation

The SDK returns `BatchInvariantImportResult` with one
`InvariantImportResult` per invariant:

```python
result.all_proved          # True iff every invariant cert built
result.proved_count        # 1 (in this fixture)
result.total_count         # 1
result.per_invariant[0].invariant_name   # 'halted_zero_during_reset'
result.per_invariant[0].mode             # 'reprove'
result.per_invariant[0].book3_cert_path  # /tmp/.../cpu_single_issue-inv-halted_zero_during_reset.cert
result.per_invariant[0].proved           # True
```

The `book3_cert_path` is the auditable artifact. Customer can:

```sh
acl2-print-axioms < <(cat book1-design.cert book3-inv-halted_zero_during_reset.cert)
```

to confirm no `defaxiom` was introduced (mode='reprove' guarantees
this) and no `skip-proofs` slipped in (only mode='axiom' uses
skip-proofs, which the walkthrough does not).

### Step 6: trace event stream

Throughout the chain, the SDK emits trace events to Supabase under
`run_subtype="theorem_proving"`:

| event_type | when | shape |
|---|---|---|
| `acl2_invariant_import_start` | per-invariant entry | `{spec_module, invariant_name, mode, target_signal, constraint_count, provenance}` |
| `acl2_invariant_import_result` | per-invariant exit | `{spec_module, invariant_name, mode, proved, elapsed_sec, book3_cert, verification_status}` |
| `acl2_invariant_import_skipped` | malformed event in batch | `{reason, payload_preview}` |

A customer auditor who logs into Tahoe can filter on
`event_type LIKE 'acl2_invariant_import_%'` and walk the same chain
the integration test exercises.

## Trust roots

Mode='reprove' (used in this walkthrough):

1. ACL2 logic
2. FGL clause processor (cert: `centaur/fgl/top`)
3. VL translation faithfulness (cert: `centaur/vl/loader/top`,
   `centaur/sv/vl/top`)
4. cert.pl certification chain

Mode='axiom' (NOT used in this walkthrough; available via
`mode='axiom'` for fast cascade scaffolding):

1. EBMC verdict
2. VL translation faithfulness
3. ACL2's `skip-proofs` mechanism (untrusted-axiom semantics; cert
   marks the book as having a skip-proofs event)

## Reproducing this walkthrough

```sh
# Requires /tmp/acl2/saved_acl2 + /tmp/todd-cpu/toy_cpu_refinement/rtl/
pytest tests/integration/test_ath_908_demo_loop.py::TestAth908DemoLoop::test_real_cegar_invariant_imports_through_fgl -v
```

Runs in 72.43s on the qa box. Produces a real `book3.cert` in a
tempdir; the test asserts the cert exists and that
`result.all_proved` is True.

## Out of scope (and labeled as such)

- The full EBMC-discovers-then-ACL2-imports demo loop on real
  EBMC-discovered invariants. Discovery side is platform's Pattern
  1 work; landing it brings Todd's headline customer pitch online.
- Cycle-equivalence proofs between `cpu_single_issue` and
  `cpu_pipelined` (ATH-913 Mode B is the customer-facing claim
  for that: separate ticket).
- Unbounded refinement-relation proofs via FM9801-style flushing
  argument. Available via additional ATH-871 children if the
  customer demands.

## Cross-refs

- `kairos.acl2.import_ebmc_invariants_from_json_file` (PR #377)
- `kairos.sv.cegar._emit_accepted_invariants` (platform PR #376)
- Builder PR #271: `cegar/loop.py` writes `accepted_invariants.json`
- `tests/integration/test_ath_908_demo_loop.py` (PR #378)
- ATH-908 (Done): parent ticket
- ATH-913: Mode B cycle-equivalence (filed)
- Asabi 2026-05-01 #dev-sdk customer-facing sign-off note (canonical
  framing for what to / not to claim)
