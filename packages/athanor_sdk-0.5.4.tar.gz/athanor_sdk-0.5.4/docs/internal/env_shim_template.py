#!/usr/bin/env python3
"""Shim — delegates to athanor.eval_harness.

Historically each of the 10 environment repos shipped an identical
~3400-line `scripts/evaluate.py`. As of athanor-sdk 0.3.5 (ATH-229) the
harness lives in `athanor.eval_harness`. Every env's `scripts/evaluate.py`
is now a thin shim that imports from the SDK, so a fix in one place
reaches all envs via `pip install -U athanor-sdk`.

Requires: athanor-sdk>=0.3.5 with the `multi-model` extra for litellm
support. See athanor-sdk/README.md.
"""
from athanor.eval_harness import main

if __name__ == "__main__":
    main()
