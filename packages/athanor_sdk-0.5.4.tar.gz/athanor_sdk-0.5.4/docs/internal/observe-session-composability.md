# Tracing an SDK session end-to-end

> Added 2026-04-24 per research's Q4 on PR #131 - "does
> `kairos.litellm_trace_session` compose cleanly inside `kairos.session`?"
> Answer: **yes**, and here's the full composition story so the next
> customer doesn't have to ask.

## Three surfaces, one story

Kairos ships three trace-observation layers. Each has a narrower
concern than the one above:

| Layer | Scope | When to use |
|:-|:-|:-|
| `kairos.session(task, trace_sink=sink)` | **Whole task.** Opens a parent `solve_runs` row; auto-wraps observe; closes the row on exit with cost + status. | **Default.** Customer runs a multi-iteration task and wants one row in `/solve-runs`. |
| `kairos.observe.observe(run_id=..., sink=...)` | **Whole process block.** Installs both litellm + native Anthropic monkey-patches, one shared `_ObserveContext`. | When you want full LLM-call capture without the `solve_runs` parent row (e.g. a CLI script outside a task). |
| `kairos.litellm_trace_session(run_id=..., sink=...)` / `kairos.anthropic_trace_session(...)` | **One provider only.** Installs the wrapper for that provider alone. | Rarely. Exists so callers who know they only hit litellm can avoid the Anthropic SDK import. Prefer `observe()` in new code. |

## Recommended customer shape

```python
from kairos.prove import session
from kairos.trace import SupabaseTraceSink

sink = SupabaseTraceSink()  # reads SUPABASE_URL / NEXT_PUBLIC_SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY

with session(
    task_id="cedar-gen-2026-04-24",
    trace_sink=sink,
    vertical="auth",                         # matches solve_runs.vertical CHECK
    builder_model="anthropic/claude-opus-4-7",
) as sess:
    for iteration in range(20):
        draft = my_agent.draft_code(feedback=last_result)
        last_result = sess.prove(
            draft, vertical="lean",
            target_file="Generator.lean",
        )
        if last_result.outcome == "proved":
            break
```

What happens under the hood:

1. On `__enter__`:
   - `sink.open_run(session_id, vertical='auth', ...)` → INSERT into `public.solve_runs` with `target=session_id` + `status='running'`.
   - `observe()` installs monkey-patches for both litellm and native Anthropic. Every `litellm.completion(...)` and `anthropic.Anthropic().messages.create(...)` call inside the block is captured as a `TraceEvent` and POSTed to `public.sdk_agent_events` with `run_id=session_id`.
2. Inside the block:
   - Each `sess.prove(...)` runs normally + emits trace events for its LLM calls.
   - Exceptions propagate to the caller.
3. On `__exit__`:
   - observe uninstalls its monkey-patches (refcounted - safe across nested sessions).
   - `sink.close_run(session_id, status='succeeded', token_cost_usd=..., wall_time_seconds=...)` → PATCH the `solve_runs` row with terminal state.
   - If the block raised, `status='failed'` instead.

Net result: one parent `solve_runs` row + N per-iteration `sdk_agent_events` rows, all joined on `solve_runs.target = sdk_agent_events.run_id`. Dashboards surface the task; SQL consumers can pull the full event timeline.

## Nesting + re-entrancy

### observe() inside session()

`session(task, trace_sink=sink)` already calls `observe()` internally. Don't nest a second `observe()` block unless you want a *different* `run_id` + sink for some sub-region:

```python
with session(task_id="outer", trace_sink=fleet_sink) as sess:
    with observe(run_id="debug-probe", sink=local_sink) as probe:
        # LLM calls here emit to local_sink with run_id="debug-probe".
        # On __exit__, contextvar resets - calls OUTSIDE this block
        # resume emitting to fleet_sink with run_id=sess.session_id.
        my_debug_probe()
```

### Two `observe()` blocks side-by-side

Refcounted. The litellm + Anthropic monkey-patches install once and uninstall on the last exit. Concurrent blocks on different threads use `contextvars` for isolation - no cross-contamination between threads.

### Pre-ATH-524 single-provider wrappers still compose

`litellm_trace_session` + `anthropic_trace_session` still work (kept for backward compat). Nesting one inside the other pre-ATH-524 produced the "two disjoint streams" problem - both now route through the same `_CURRENT_CONTEXT`, so the inner's context replaces the outer's during the inner block. If you're on new code, use `observe()` directly.

## Zero-cost default when no sink

```python
# No sink = no monkey-patches = no phone-home.
with session(task_id="ephemeral") as sess:
    ...  # prove() still runs, no LLM-call tracing
```

Customers who haven't wired up Supabase pay zero cost for session context-management. The gate is: did the caller pass `trace_sink=` or `events_path=`? If both are `None`, the session is lightweight context-management only.

## Sinks

- **`NoopTraceSink`** - customer-wheel default. Every method is a no-op. Preserves "don't phone home by default."
- **`SupabaseTraceSink`** - fleet-internal. Reads `SUPABASE_URL` (falls back to `NEXT_PUBLIC_SUPABASE_URL` per ATH-544 - useful when sourcing `.env.platform`) + `SUPABASE_SERVICE_ROLE_KEY` from env. Implements `emit` / `emit_escalation` / `open_run` / `close_run` / `flush`.
- **Custom sink** - any class that satisfies the `kairos.trace.TraceSink` Protocol. `runtime_checkable`, so `isinstance(my_sink, TraceSink)` tells you if you've implemented the surface. S3, Datadog, internal SIEM - all fine.

## Schema join

```sql
-- All SDK runs today, newest first
SELECT * FROM public.solve_runs
WHERE pipeline_version = 'kairos-sdk'
ORDER BY created_at DESC;

-- Events for one run
SELECT * FROM public.sdk_agent_events
WHERE run_id = 'THE-SESSION-UUID'
ORDER BY sequence;

-- Parent + event count (dashboard-friendly)
SELECT r.id, r.target, r.vertical, r.status, r.token_cost_usd,
       COUNT(e.id) AS event_count
FROM public.solve_runs r
LEFT JOIN public.sdk_agent_events e ON e.run_id = r.target
WHERE r.pipeline_version = 'kairos-sdk'
GROUP BY r.id
ORDER BY r.created_at DESC;
```

## Migration from raw litellm

Before:

```python
import litellm
for i in range(20):
    response = litellm.completion(
        model="anthropic/claude-opus-4-7",
        messages=[...],
    )
    # ...manually track cost, manually log, manually stitch rows...
```

After:

```python
from kairos.prove import session
from kairos.trace import SupabaseTraceSink

with session("my-task", trace_sink=SupabaseTraceSink(), vertical="other"):
    for i in range(20):
        import litellm
        response = litellm.completion(
            model="anthropic/claude-opus-4-7",
            messages=[...],
        )
        # ...trace rows auto-land in sdk_agent_events with the session_id,
        # parent row auto-updates on exit with total cost + wall time...
```

Net 10-20 LOC deleted per driver, traces automatic.

## Related

- ATH-520 - schema-drift gate for `sdk_agent_events`
- ATH-523 - unified `Counterexample` shape (refuted verdicts)
- ATH-524 - the `observe()` unified wrapper + `session()` auto-wrap
- ATH-544 - `NEXT_PUBLIC_SUPABASE_URL` env-var fallback
- ATH-545 - parent `solve_runs` row (the dashboard-gap closure)
