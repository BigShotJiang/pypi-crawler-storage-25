# SpecV1 migration - 1.0 to 1.1 (ATH-492, 2026-04-23)

SpecV1 1.1 is a **backward-compatible minor bump** that adds four
fields for the 9-gate SDK-perfect-shape work (ATH-497 umbrella):

- `target_kind` - now explicit in the top-level spec; includes the
  new `integration` value for multi-tier composed verdicts.
- `evidence_tier` - open string; identifies which evidence class the
  customer expects (Lean proof, BMC bound, k-induction, empirical).
- `bound_k` - customer-declared trust horizon for bounded verdicts;
  informs escalation trigger 2 (bound-near-limit).
- `meta.integrity_hash` + `meta.integrity_version` - spec-level
  hash-lock (mirrors the IntentV1 integrity primitive from ATH-493
  PR #107).

All four are optional. A 1.0 spec that does not set any of them
continues to validate and run as before.

## Guarantees for 1.0 consumers

Per the 2026-04-23 platform+qa scope-lock vote (aligned with semver
minor-bump convention):

1. `spec_version: "1.0"` is still accepted by the schema and TypedDict.
2. A 1.0 spec loaded by a 1.1 reader behaves identically to 1.0 load:
   the new fields read as `None` / unset; the compile pipeline falls
   back to the 1.0 code paths.
3. A 1.1 spec loaded by a 1.0 reader (if a customer pins an older
   SDK version) ignores the forward fields. The JSON Schema validator
   in 1.0 has `additionalProperties: false` at the top level, so a
   1.0 validator will reject a 1.1 spec with unknown keys - customers
   on 1.0 must either pin their specs to 1.0 or upgrade. A 1.1
   validator reads both 1.0 and 1.1 specs lenient.
4. Unknown `evidence_tier` values pass validation with a once-per-
   process warning; the helper `kairos.spec_v1.validate_tier()`
   surfaces drift to operators without breaking the run. Plugins
   extending the tier set call `register_tier()` at import.

The only hard-refuse change between 1.0 and 1.1 is the `integration`
value of `target_kind`: a 1.0 schema does not enumerate it, so a
1.0 validator rejects specs that use it. Use 1.1 for those.

## New field reference

### `target_kind: str` (enum)

One of `"theorem" | "property" | "kernel" | "rtl_fix" |
"top_module" | "integration"`. In 1.0 this was implicit from
`vertical` + `extension[vertical]` shape; 1.1 makes it explicit so
the Stage-G dispatcher reads a single field.

`integration` is the 1.1-only value: the verdict composes multiple
tier-level proofs (e.g. a Lean proof of the top-level theorem, with
BMC bounded checks on inner sub-routines, plus empirical property
tests on the IO boundary).

### `evidence_tier: str` (open registry)

Built-in tiers in `kairos.spec_v1.KNOWN_TIERS`:

| Tier              | Meaning                                                         |
|:-|:-|
| `lean_proved`     | Lean 4 kernel accept + axiom-audit-match                        |
| `bmc_bounded`     | EBMC / Z3 bounded model check; `bound_k` is the declared cap   |
| `kind_unbounded`  | k-induction unbounded safety (ATH-491 label)                    |
| `empirical`       | property tests + simulator + mutation sweep                     |

Plugins that introduce new tiers call:

```python
from kairos.spec_v1 import register_tier
register_tier("coq_proved")
```

Unknown tiers pass `validate_tier()` with a warning. The schema
itself is an open string (`minLength: 1`) so the validator never
hard-refuses a new tier - plugin compatibility is the point.

### `bound_k: int`

Customer-declared ceiling on the k used by a bounded-verdict tier.
Distinct from `thresholds.bmc_k_bound` (which is a run BUDGET cap);
`bound_k` is the trust horizon the escalation system reads.

Escalation trigger 2 (bound-near-limit): if the verdict's actual
`bound_k` is > 80% of this declared ceiling, the pipeline fires
an escalation. A customer who sets `bound_k: 100` and sees a
PROVED verdict at k=85 will get escalated; at k=40, no escalation.

Typical values: 20-100 for production RTL, 10-20 for research
fixtures, 500+ for exotic depths.

### `meta.integrity_hash: str` + `meta.integrity_version: str`

Mirrors the IntentV1-level primitive shipped in ATH-493 PR #107.
Composition:

```python
from kairos.spec.integrity import sign, verify
spec = {...}  # SpecV1 1.1
signed = sign(spec)   # populates meta.integrity_hash
# spec may pass through fleet agents...
verify(signed)        # raises IntegrityError on tampering
```

An unsigned spec passes schema validation; the integrity check is
opt-in per run. Enterprise customers who rely on the hash-lock
guarantee (Todd 2026-04-22 feedback) sign after composition.

## No code-change required for existing integrations

Existing callers of `compile_intent(spec)` and
`spec_compiler.compile(spec)` continue to work unchanged on both 1.0
and 1.1 specs. The compile pipeline reads the new fields when
present and falls back to existing heuristics when absent.

## Related tickets

- ATH-491: CEGAR `--k-induction` + `PROVED_KIND_UNBOUNDED` label
  (2026-04-22) - source of the `kind_unbounded` tier + `bound_k`
  semantics in `Verdict.details`.
- ATH-493 PR #107: `kairos.spec.integrity` primitive (2026-04-22) -
  `meta.integrity_hash` mirrors the IntentV1 surface from this PR.
- ATH-497: 9-gate umbrella for the SDK-perfect-shape effort. This
  migration is Gate 4.
- ATH-498: TraceSink to Supabase - unaffected by this schema bump,
  but downstream queries benefit from the explicit `target_kind` +
  `evidence_tier` columns for filtering.
