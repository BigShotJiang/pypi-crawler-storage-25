# Athanor IP Partitioning - Internal Reference

_Audience: Athanor agents working on the SDK or builder. Describes
what IP lives where, why, and how the CI gates enforce the boundary.
Last updated 2026-04-19._

**This is NOT customer-facing.** It exists to keep the fleet honest
about what's proprietary crown-jewel material vs. commodity glue code.



## Why partition at all

Athanor ships the SDK to customers as a GPG-signed tarball with an
enterprise proprietary license. Every `.py` file inside that tarball
is legally NDA-protected but technically readable by a customer with
a text editor. So:

- **Crown-jewel IP** must live somewhere the customer either can't
  read (compiled `.so`, container image) or never receives at all
  (platform service).
- **Commodity glue** can live openly in the SDK; even if read, it
  doesn't replicate Athanor's value.

The partition is enforced architecturally (what we ship where) and
mechanically (CI gates). This doc is the map.

## IP tiers

Four tiers, ranked by value:

### Tier 1 - crown jewels

**Prompt templates.** The `solve/<vertical>/prompts/phase<N>_*.md`
files in `athanor-builder`. 2+ years of empirical tuning; determines
whether the pipeline produces verified-correct output or garbage.

**Scoring calibration.** Weights + thresholds that decide what counts
as "a good proof":

- `lean.score_proof` weights (`1.0` / `0.35` / `0.25` / `0.0`)
- `lint.BANNED_LEAN_CONSTRUCTS` (11 patterns the grader flags)
- `mutation_kill_rate_min = 0.75`, `bmc_k_bound = 10`, etc.
- Sigmoid calibration curves + per-task `sigmoid_center` /
  `sigmoid_scale` values

**Replication cost for a competitor:** ~1-2 years of research
investment in comparable eval infrastructure. Without these,
everything else we do is useless.

### Tier 2 - architecture

**7-phase pipeline design.** `mode_fleet` orchestrator (~2500 LOC),
phase sequencing, parallel builder race, triple-voice audit structure,
Aristotle closer, cross-vertical dispatch.

**IntentV1 neutral-intent contract.** The SDK↔builder boundary we
designed per ATH-337 so no prompt strings cross it.

**Replication cost:** ~3 months for a strong team given our public
whitepaper + observable customer outputs.

### Tier 3 - environments

**Task design.** `environments/<env>/root_data/eval/configs/*.json`,
reference implementations, anti-cheat test fixtures (eval shapes ≠
student hints).

**Replication cost:** medium - per-task copyable given the tarball,
but re-creating 10 envs × ~20 tasks at our difficulty-calibration
quality takes months.

### Tier 4 - SDK surface

`cli.py`, `spec_compiler`, `spec_validate`, `cli_renderer`,
`stream_schema`, the CLI UX files. Customer-facing utility code.
Thin by design post-ATH-337.

**Replication cost:** low. Commodity.

## What lives where

### `athanor-sdk` (ships to customers, proprietary license)

```
src/athanor/
├── cli.py                  - Tier 4. Command router.
├── spec_v1.py              - Tier 2. Neutral-intent schema (byte-mirror)
├── spec_compiler.py        - Tier 2. SpecV1 → IntentV1 pure transform (byte-mirror)
├── spec_validate.py        - Tier 2. Stage-A local validation (byte-mirror)
├── spec_schema.json        - Tier 2. JSON Schema (byte-mirror)
├── sdk_security.py         - Tier 4. File-perms, tempfile, license-verify utilities
├── auth.py                 - Tier 4. Token loading chain
├── builder_check.py        - Tier 4. Runtime probe for builder presence
├── bundle.py               - Tier 4. Customer-facing tarball packager + redaction gate
├── cli_renderer.py         - Tier 4. JSONL event stream → ANSI
├── stream_schema.py        - Tier 2. Event contract (byte-mirror)
├── runner.py               - **Tier 1 today; scheduled to migrate to builder per ATH-383**
├── eval_harness.py         - **Tier 1 today; scheduled to migrate to builder per ATH-383**
├── preflight_fleet.py      - **Tier 1 today; scheduled to migrate to builder per ATH-383**
├── lean.py                 - **Tier 1 today; scheduled Cython-compile per ATH-382**
├── lint.py                 - **Tier 1 today; scheduled Cython-compile per ATH-382**
└── scoring.py              - **Tier 1 today; scheduled Cython-compile per ATH-382**
```

Per qa's 2026-04-18 audit (`audit/ATH-341-sdk-audit.md`), **62% of
current SDK source is Tier-1 IP that shouldn't ship as plain .py**.
ATH-382 + ATH-383 close that gap.

### `athanor-builder` (private repo, signed-tarball delivery only)

```
solve/
├── shared/
│   ├── spec_v1.py          - Canonical SpecV1 + IntentV1. SDK byte-mirrors.
│   ├── spec_compile.py     - Canonical compile(). SDK byte-mirrors.
│   ├── spec_validate.py    - Canonical Stage-A. SDK byte-mirrors.
│   ├── spec_schema.json    - Canonical schema. SDK byte-mirrors.
│   ├── redactor.py         - Server-side redaction (drops raw prompts from run.json)
│   ├── stream_schema.py    - Canonical event schema. SDK byte-mirrors.
│   ├── modes/mode_fleet.py - **Tier 2 crown-jewel orchestrator**
│   └── cost_tracker.py     - Per-run LLM spend tracking
├── <vertical>/
│   ├── prompts/            - **Tier 1 - THE crown jewels**
│   │   ├── phase_-1_opus_plan.md
│   │   ├── phase_0_sonnet_formalize.md
│   │   ├── phase_1_property_gen.md
│   │   ├── phase_2_mutation.md
│   │   ├── phase_3_refine.md
│   │   ├── phase_4_close.md
│   │   └── phase_5_audit.md
│   ├── run.sh              - 7-phase pipeline entry
│   └── ...
└── environments/
    └── <env>/root_data/eval/
        ├── configs/*.json  - **Tier 3 task definitions**
        ├── scoring.py      - **Tier 1 scoring logic (compiled to .so)**
        ├── references/     - **Tier 3 reference implementations**
        └── tests/          - **Tier 3 anti-cheat fixtures**
```

### `athanor-platform` (our servers, not on customer VM)

- Next.js app at `tahoe.athanor-ai.com`
- Supabase-backed storage + DB
- Admin panel for license issuance
- `/api/solve-runs/*` endpoints (ATH-363) that fleet-VM-side mode_fleet
  ingests into
- Future home for Tier-1 content the customer can't air-gap around

### `athanor-website` / `athanor-whitepaper`

Marketing + research output. Fully public. Intentionally reveals
Tier 2 (architecture) as marketing - the public description doesn't
give you enough to replicate Tier 1.

## The cross-package boundaries

### Boundary 1: SDK `spec_compiler` → Builder `mode_fleet`

The SDK compiles `SpecV1` → `IntentV1` (pure data) and shells out to
the local `mode_fleet` binary with `--intent-json` or
`--intent-json-file`. `mode_fleet` is a Python module inside the
builder tarball, invoked via subprocess.

**Invariant:** `IntentV1` must never contain prompt strings. Enforced
by unit test `test_output_contains_no_prompt_strings` in
`test_spec_compiler.py`. If someone adds a field to IntentV1 whose
content is a prompt, CI trips.

### Boundary 2: Builder `run.json` → SDK `bundle.py`

`mode_fleet` writes a raw `run.json` containing per-phase traces, then
passes it through `solve/shared/redactor.py` to produce a
customer-safe `run.json`. The SDK's `bundle.py` has a second
(defense-in-depth) `FORBIDDEN_MARKERS` scan before packing. Two
layers of redaction before any artifact leaves the VM.

### Boundary 3: SDK has NO runtime import of `athanor-builder`

No `from solve.shared.*` in SDK runtime. Byte-mirrored files
(`spec_v1`, `spec_compiler`, `spec_validate`, `spec_schema`) are
duplicated copies with `solve.shared.*` → `athanor.*` import rewrite
as the only diff. Everything else that needs builder functionality
goes through subprocess.

## CI enforcement

Three gates in `.github/workflows/ci.yml` back the partition:

### `tls-verification` (ATH-369 #1)

Python script `scripts/check_tls_verify.py` using `tokenize` to skip
comments + strings. Fails if `src/` or `scripts/` executable code
disables TLS certificate verification.

### `canonical-spec-drift` (ATH-358)

Python script `scripts/check_canonical_drift.py`. Takes sha256 of
each SDK byte-mirrored file (after reversing the one-line
`solve.shared.*` → `athanor.*` import rewrite) and compares against
the pin file `schemas/canonical-hashes.txt`. Fails if any mirror
drifted from its canonical pin.

Updating the pin is explicit: when the canonical changes, a
coordinated PR updates the SDK mirror and the hash file together.
See `schemas/canonical-hashes.txt` header for the re-sync recipe.

### `sdk-ip-leak-check` (ATH-384)

Python script `scripts/check_sdk_ip.py` using `tokenize` to skip
comments + strings for most patterns; raw-content scan for
prompt-template markers (which legitimately exist only as strings).
Fails on:

- Builder-namespace imports (`from solve.shared.*` etc.)
- Internal artifact paths (`environments/<env>/root_data/eval/`)
- Scoring-weight literals (the `(1.0, 0.35, 0.25, 0.0)` tuple)
- Internal identifiers (`SPECIALE_`, `KAIROS`, `speciale_adapter`)
- Prompt-template markers (phrases from our system prompts)

Tracked existing debt lives in `scripts/check_sdk_ip_baseline.txt`
with per-line rationale. Every baseline entry either has a resolution
ticket (e.g. ATH-383 for eval_harness leaks) or is permanently
exempt (e.g. bundle.py's FORBIDDEN_MARKERS enforcement list).

**Goal:** drive the baseline to empty. Each removed line is a
real IP-protection gain.

## The remaining gap

As of 2026-04-19, Tier 1 files still shipping as readable `.py`:

| File | LOC | Protection today | Scheduled |
|:-|:-:|:-|:-|
| `eval_harness.py` | 3,734 | NDA + proprietary license | ATH-383 migration to builder subprocess |
| `runner.py`       | 1,618 | NDA + proprietary license | ATH-383 migration to builder subprocess |
| `preflight_fleet.py` | 395 | NDA + proprietary license | ATH-383 migration to platform service |
| `lean.py`         | 262  | NDA + proprietary license | ATH-382 Cython compile |
| `lint.py`         | 80   | NDA + proprietary license | ATH-382 Cython compile |
| `scoring.py`      | 102  | NDA + proprietary license | ATH-382 Cython compile |

Total: ~6,200 LOC = 62% of SDK surface today. Post ATH-382 + ATH-383
this drops to ~5% (thin subprocess stubs + HTTPS clients).

Until those land, the contractual layer (NDA, proprietary license,
per-customer enterprise agreement) is the primary protection for
Tier 1. That's legally real but runtime-slow. ATH-382 + ATH-383
convert it to runtime-real via technical enforcement.

## When you're adding SDK code

- Tier 4 is fine as plain `.py` in `src/athanor/`.
- Tier 2 (schema-like, boundary types) goes via byte-mirror if it
  crosses the SDK↔builder boundary.
- Tier 1 **does not go in the SDK**. Put it in
  `athanor-builder/solve/shared/` or `solve/<vertical>/`. If the SDK
  needs to invoke it, shell out via subprocess.
- Tier 3 belongs in `athanor-builder/environments/`.

If you're unsure whether something is Tier 1 vs Tier 2, err toward
Tier 1 (builder-only). The reverse is much easier than moving leaked
source back.

## Related docs

- `audit/ATH-341-sdk-audit.md` - qa's 2026-04-18 per-file
  classification of current SDK contents.
- `docs/enterprise-deployment.md` - customer-facing flow (install.sh
  through bundle).
- `docs/sdk-roadmap.md` - V1 scope + the roadmap that produced this
  partition.
- ATH-337 Linear ticket - parent umbrella for all partition work.
- ATH-382 / ATH-383 / ATH-384 Linear tickets - the concrete
  close-the-gap items.
