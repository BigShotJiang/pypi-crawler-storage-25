# `generate_invariant` emit shape - for athanor-platform `/analytics/invariant-gen` route

Author: qa, 2026-05-05 (ATH-1017 source-truth-holder commit; platform's ATH-1020 sibling-route renders against this shape)
Reviewer: cto / asabi (cross-arm sign-off on the per-event payload shape)
Consumer: platform (sibling route to `/analytics/sec-closed-loop` since render shape diverges - no orchestrator iteration arc, just per-property invariant-gen attempts)
Cross-refs:
- `src/kairos/sec/closed_loop/_invariant_gen.py` (the emit-side source-of-truth)
- `src/kairos/trace_schema.py` (event registry - three new entries: `invariant_gen_start`, `invariant_gen_attempt`, `invariant_gen_result`)
- ATH-1017 / ATH-1020 / ATH-1023 (the cluster of 3 tickets enacting telemetry → render → cross-arm E2E)
- meta-rule's first-instance-applied-to-URLs principle: sibling routes preserve customer-cert provenance disambiguation at the URL level (engine-naming-discipline at the path)

## Why this doc

Platform's ATH-1020 dashboard render needs the canonical event shapes upstream of any forward-guess. Per the source-truth-holder pattern: qa drafts the shape; cto signs off; platform consumes the spec. Same flow as the orchestrator-emit-shape doc + the JKLM IterationRecord-extension doc.

## Three emit channels per `generate_invariant()` call

When `kairos.sec.closed_loop.generate_invariant(bundle_path, target_property, ...)` is invoked, the function opens a `kairos.observe.observe()` session + emits three event types:

1. *One `invariant_gen_start` event* at function entry - carries the call-time inputs (bundle, target_property, max_attempts, model, bound).
2. *One `invariant_gen_attempt` event PER LLM propose-inject-verify cycle* - carries the candidate + the EBMC verdict on that attempt.
3. *One `invariant_gen_result` event* at function exit - carries the closed-or-not flag, halt_reason, attempts_count, chosen candidate (if any), assumption_stack disclosure.

Total event count: `2 + N` where `N` is the number of attempts the bounded loop took (`1 ≤ N ≤ max_attempts`). N=1 in the typical first-attempt-closure case; N=max_attempts when the loop exhausts.

## Parent `solve_runs` row shape

Opened via `kairos.observe.observe(...)`; written to `solve_runs` when `default_sink_from_env()` resolves to `SupabaseTraceSink` (i.e. `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` set).

```json
{
  "run_id": "uuid-string",
  "vertical": "neuron_sec_closed_loop",
  "run_type": "sdk_orchestration",
  "run_subtype": "autoformalize",
  "started_at": "2026-05-05T06:30:42.123Z",
  "completed_at": "2026-05-05T06:30:55.901Z"
}
```

`run_subtype: "autoformalize"` is the existing enum value used for LLM-proposes-formal-expression flows (per `kairos.trace.RunSubtype` Literal). `vertical: "neuron_sec_closed_loop"` matches the orchestrator-emit-shape doc's parent-row shape.

## `invariant_gen_start` event

Emitted exactly once at function entry. Anchors the run on the dashboard.

```json
{
  "event_type": "invariant_gen_start",
  "run_id": "<parent solve_runs.run_id>",
  "emitted_at": "2026-05-05T06:30:42.245Z",
  "payload": {
    "bundle_path": "examples/customer/toy_fifo_chain_v2_sec",
    "target_property": "sec_miter.full_match",
    "target_property_sv": "full_match: assert property (@(posedge clk) disable iff (!rst_n) gold_full == gate_full);",
    "max_attempts": 2,
    "model": "anthropic/claude-opus-4-6",
    "bound_k": 10
  }
}
```

| Field | Type | Source | Render |
|---|---|---|---|
| `bundle_path` | string | call arg | Header label: which SEC bundle we're discharging. |
| `target_property` | string | call arg | Headline property name (e.g. `sec_miter.full_match`). |
| `target_property_sv` | string | extracted from miter.sv | The full SV `assert property (...)` line - render in code block under the header so the customer sees what's being proved. |
| `max_attempts` | int | call arg | Loop budget (typically 2 or 3). |
| `model` | string | call arg | LLM model id (typically `anthropic/claude-opus-4-6`). |
| `bound_k` | int | call arg | EBMC k-induction bound. |

## `invariant_gen_attempt` event (one per attempt, ordered by `attempt_index`)

Emitted per LLM propose-inject-verify cycle. Ordering: `attempt_index` strictly increases 0..N-1 (dense). Per the orchestrator-emit-shape doc's iteration-ordering guarantee: dashboards MUST sort by `attempt_index` post-fetch, NOT rely on `created_at` (network-jitter retry can break monotonicity).

```json
{
  "event_type": "invariant_gen_attempt",
  "run_id": "<parent solve_runs.run_id>",
  "emitted_at": "2026-05-05T06:30:48.612Z",
  "payload": {
    "attempt_index": 0,
    "target_property": "sec_miter.full_match",
    "candidate": {
      "sv_expression": "gold.count == gate.count",
      "label": "inv_count_sync",
      "rationale": "Both designs implement the same FIFO control flow; the count register is the only state full_match reads (full = (count == cap)). Count-only equality is therefore the minimum sufficient inductive bridge.",
      "proves_obligation": null
    },
    "closed_target_property": true,
    "verdict": "PROVED",
    "counter_example_present": false
  }
}
```

| Field | Type | Source | Render |
|---|---|---|---|
| `attempt_index` | int | loop counter | Card index in the attempts strip. |
| `target_property` | string | (echoed for self-contained payloads) | (sanity check vs the parent run's target_property) |
| `candidate.sv_expression` | string | LLM JSON output | Code block: the proposed inductive invariant. |
| `candidate.label` | string | LLM JSON output | Chip with label (e.g. `inv_count_sync`). |
| `candidate.rationale` | string | LLM JSON output | Paragraph: why the LLM picked this bridge. |
| `candidate.proves_obligation` | string \| null | post-EBMC stamp from `_CANONICAL_BRIDGE_THEOREMS` registry | **`null` -> `[UNPROVEN - assumed; v0 D-spike]` chip (warning color); non-null -> `[proved by Pythia.Hardware.SEC.X]` link (success color)**. Honest-framing gate: render-as-proved is structurally impossible on null. Same discipline as ATH-993 phase 2 `provesObligationLabel`. |
| `closed_target_property` | bool | EBMC verdict on target | Green/red status chip. |
| `verdict` | string | EBMC raw output | `PROVED` / `REFUTED` / `INCONCLUSIVE` / `ERROR: <reason>`. Same enum as `kairos.yosys.EquivInductVerdict` + `kairos.ebmc.verify` so dashboard branch logic is single-codepath. |
| `counter_example_present` | bool | derived | When true, expand-to-show counter-example trace (trace text NOT in payload - fetched on demand from the run's `_sec_work/` artifact directory if exposed via API; v0 just renders "trace available, see EBMC log"). |

## `invariant_gen_result` event

Emitted exactly once at function exit. Anchors the dashboard's headline result + assumption-stack disclosure.

```json
{
  "event_type": "invariant_gen_result",
  "run_id": "<parent solve_runs.run_id>",
  "emitted_at": "2026-05-05T06:30:55.823Z",
  "payload": {
    "closed": true,
    "target_property": "sec_miter.full_match",
    "halt_reason": "closed",
    "attempts_count": 1,
    "chosen": {
      "sv_expression": "gold.count == gate.count",
      "label": "inv_count_sync",
      "rationale": "...",
      "proves_obligation": null
    },
    "assumption_stack": [
      "inv_count_sync: gold.count == gate.count  [UNPROVEN - assumed; v0 D-spike]"
    ]
  }
}
```

| Field | Type | Source | Render |
|---|---|---|---|
| `closed` | bool | `InvariantGenResult.closed` | Top-of-page success/failure banner. |
| `target_property` | string | `InvariantGenResult.target_property` | Echoed in the headline. |
| `halt_reason` | string | `InvariantGenResult.halt_reason` | One of `"closed"` / `"hard_refute"` / `"max_attempts"` / `"llm_error: ..."` / `"parse_failure"`. Surfaced as a chip + a per-reason explanation tooltip. |
| `attempts_count` | int | `len(attempts)` | "Closed in N attempt(s)" subhead. |
| `chosen` | object \| null | `InvariantGenResult.chosen` (with `proves_obligation` populated if the registry has a theorem for the target_property; null otherwise) | The chosen invariant card (when `closed=True`). |
| `assumption_stack` | array of strings | `InvariantGenResult.assumption_stack()` rendered output | The explicit assumption-stack disclosure section. Each string is one assumption with the `[UNPROVEN]` or `[proved by X]` annotation already baked in by the engine - dashboard renders verbatim. |

## Three-card sibling-route layout (per platform's ATH-1020 sibling-route choice)

For each `generate_invariant` run, the dashboard renders three side-by-side cards:

1. **Inputs card**: `invariant_gen_start.payload` - bundle, target property, target_property_sv, model, max_attempts, bound_k.
2. **Attempts strip**: ordered `invariant_gen_attempt.payload` events, sorted by `attempt_index` ascending. One sub-card per attempt with the candidate + verdict + proves_obligation chip.
3. **Result card**: `invariant_gen_result.payload` - closed/halt_reason headline, chosen invariant, assumption stack disclosure section.

## Honest-framing rules carried through

The 11-gate / 5-surface cluster discipline applies to this surface:

1. *`proves_obligation` chip never renders-as-proved on null* - same as `provesObligationLabel` on the SEC-closed-loop route. Negative test: snapshot fixture with `proves_obligation: null`, assert DOM contains `[UNPROVEN`, NOT `[proved by`.
2. *`assumption_stack` rendered verbatim from engine-emit, never re-rendered from chosen-fields client-side* - engine is source-of-truth. Dashboard shows the array as-is.
3. *`verdict` enum is the same as `kairos.ebmc.verify` + `kairos.yosys.equiv_induct`* - single-codepath branch logic, no per-route enum drift.
4. *Drop-count discipline* (per orchestrator-emit-shape ordering rule): if `attempt_index` array has gaps (missing index k where k < max), surface "N events dropped or lost" yellow chip - same surface-don't-swallow shape.
5. *Sort by `attempt_index` post-fetch*, not by `created_at`. Network-jitter retry can break the latter.

## Required platform-side tests

Per the cluster's "materially impossible to violate without breaking a test or a type" bar:

```
test_proves_obligation_null_renders_unproven_chip
test_proves_obligation_set_renders_proved_by_link
test_proves_obligation_null_never_renders_proved_by_link    # negative invariant
test_attempts_sorted_by_attempt_index_post_fetch
test_attempts_with_gap_renders_dropped_warning              # negative invariant
test_assumption_stack_rendered_verbatim_from_engine_emit
test_verdict_chip_uses_same_enum_as_sec_closed_loop_route
```

## Open question for cto sign-off

1. **Sibling route name**: platform's leaning toward `/analytics/invariant-gen/<run_id>`. Alternative: `/analytics/sec-invariant-gen/<run_id>` (signals the SEC-flavored grouping more explicitly). My read: `/analytics/invariant-gen/<run_id>` is sufficient since the parent solve_run's `vertical: neuron_sec_closed_loop` carries the SEC-grouping. But sec-invariant-gen prefix would be more grep-friendly if other invariant-gen verticals (e.g. NKI invariant gen) land later. Defer to your call.
2. **Per-attempt counter-example trace embedding**: today's payload sets `counter_example_present: bool` only; the trace text (which can be 4-16 KiB of EBMC-emitted SAT counter-example) is NOT in the payload to keep events small. Dashboard would need an API to fetch the trace from the runner's `_sec_work/` artifact dir. v0/v1 alternative: render "trace available, see EBMC log" placeholder; v2 wires the trace fetch endpoint. Same shape as VCD download (PR #390). Confirm v0 is acceptable.

## v0 vs v1 scope

Today's emit shape covers what `generate_invariant()` produces in v0:
- 1 + N + 1 events per call
- The candidate + verdict + proves_obligation fields per attempt
- The chosen + assumption_stack at result time

Forward-compat slots (nullable, lands in v1+):
- `attempt.elapsed_seconds: float` - per-attempt wall-clock for performance forensics
- `attempt.tokens_in / tokens_out: int` - per-LLM-call token usage for cost forensics
- `result.total_tokens / total_cost_usd: float` - aggregate cost per call
- `attempt.counter_example_storage_path: string | null` - cloud-storage object path for the counter-example trace, mirroring `vcd_storage_path` from PR #390

Phase 2 platform schema can leave nullable columns for these without forcing a v3 migration.
