# Spec Pipeline - Design Doc

**Author:** research (aidayang)
**Date:** 2026-04-22
**Status:** design, handoff for QA + platform fleet implementation
**Scope:** the architecture for turning a 1-page customer requirement into an executable, guarded `SpecV1` → `IntentV1` → `mode_fleet` invocation



## 1. Problem

Today, our spec flow is: *customer writes `spec.json` by hand → Stage A (rule-based) → compile → mode_fleet*. That's ATH-358, shipped.

But the actual customer need is one level higher: *customer has a high-level intent, doesn't know the SpecV1 shape, and is going to write a spec that misses constraints, sets vacuous acceptance criteria, or bakes in a direction flip.* Without guardrails between "high-level intent" and "mode_fleet launches," the fleet will confidently execute wrong specs. That's the same failure-mode category as vacuous theorem statements in autoformalization - costly to catch downstream, cheap to catch upstream.

The use case is: **take a requirement, produce a spec you can trust enough to spend $50 on.**

## 2. Architecture - 7 stages + execute

```
┌──────────────────────────────────────────────────────────────────────┐
│ Customer writes requirement.md (1 page, unstructured intent)         │
└──────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage 0: Draft                           │  Sonnet drafts SpecV1 from
          │   kairos.spec.draft(requirement.md)      │  requirement + codebase context
          └──────────────────────────────────────────┘
                              │ SpecV1 (draft)
                              ▼
          ┌──────────────────────────────────────────┐
  ATH-358 │ Stage A: Structural (existing ✓)         │  schema, target_file exists,
          │   kairos.spec_validate.stage_a(spec)     │  target_name findable, budget > 0
          └──────────────────────────────────────────┘
                              │ ok or defect list
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage B: LLM coherence                   │  Opus: does the spec describe a
          │   kairos.spec.coherence(spec)            │  coherent, achievable task?
          └──────────────────────────────────────────┘
                              │
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage C: Coverage                        │  Sonnet: for each requirement
          │   kairos.spec.coverage(req, spec)        │  clause, is it addressed in spec?
          └──────────────────────────────────────────┘
                              │ coverage matrix
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage D: Mutation testing of the spec    │  Mutate spec (drop criterion, flip
          │   kairos.spec.mutation_test(req, spec)   │  bound, weaken threshold); rerun
          │                                          │  Stage C; kill-rate ≥ threshold
          └──────────────────────────────────────────┘
                              │ mutation kill-rate
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage E: NL round-trip                   │  Paraphrase spec back to NL,
          │   kairos.spec.roundtrip(req, spec)       │  semantic-match to original req
          └──────────────────────────────────────────┘
                              │ similarity ≥ τ
                              ▼
          ┌──────────────────────────────────────────┐
   New ►  │ Stage F: Economic gate                   │  estimated cost × P(success) vs
          │   kairos.spec.economics(spec, claimed)   │  claimed value + risk premium
          └──────────────────────────────────────────┘
                              │ accept / reject
                              ▼
          ┌──────────────────────────────────────────┐
  ATH-358 │ spec_compiler: SpecV1 → IntentV1 (✓)     │  pure data transform
          └──────────────────────────────────────────┘
                              │ IntentV1
                              ▼
          ┌──────────────────────────────────────────┐
          │ Stage G: Execute                         │  delegates to existing
          │   mode_fleet or solve/two_agent/run.sh   │  builder + adversarial pipeline
          └──────────────────────────────────────────┘
```

Each guard stage returns a structured result. Any stage can produce:
- `PASS` - continue to next stage
- `FAIL` - stop, report defects, optionally loop back to Stage 0 with defects as feedback
- `PASS_WITH_CAVEATS` - continue, flag caveats to the caller

## 3. Existing surface (ATH-358) - what we reuse as-is

| File | Role |
|:-|:-|
| `kairos/spec_schema.json` | JSON Schema (ground truth) |
| `kairos/spec_v1.py` | `SpecV1`, `IntentV1` TypedDicts; `Vertical`, `TargetKind` enums |
| `kairos/spec_validate.py` | Stage A rule-based validator |
| `kairos/spec_compiler.py` | Pure `SpecV1 → IntentV1` transform |

**No changes to these files in MVP.** The new stages live alongside, not on top.

## 4. New surface - file layout

```
athanor-sdk/src/kairos/
  spec/
    __init__.py             # re-exports public API
    draft.py                # Stage 0
    coherence.py            # Stage B
    coverage.py             # Stage C
    mutation.py             # Stage D
    roundtrip.py            # Stage E
    economics.py            # Stage F2 (F1 Plausibility deferred post-MVP per QA 2026-04-22)
    integrity.py            # spec-integrity hash primitive (SHA256 of canonicalized IntentV1) - MVP scope
    pipeline.py             # orchestrates 0 → A → B → hash → C → D → E → F → execute
    types.py                # StageResult, Defect (shared dataclasses)
    mutators.py             # the mutator taxonomy for Stage D (includes tier_stretching per §7a)
```

Builder side (`solve/shared/phases/`) gets companion LLM-prompt files when a stage needs prompts (B, C, E for sure). Prompts stay builder-side per the ATH-337 IP partitioning rule; SDK side is pure logic.

## 5. Public API (minimal, MVP-first)

```python
from kairos.spec import pipeline

# All-in-one (what `athanor spec submit requirement.md` invokes)
result = pipeline.run(
    requirement_path="requirements/dspv2_awq_swap.md",
    stages=pipeline.ALL_STAGES,     # or subset for early runs
    budget_usd=25.0,
)

# Per-stage escape hatch (for debugging + CI)
from kairos.spec import draft, coherence
spec = draft.draft_spec(requirement_text)
coh  = coherence.check(spec)
```

Every stage function signature is:

```python
def run(input: Stage_N_Input) -> StageResult:
    """StageResult has: ok: bool, defects: list[Defect], artifacts: dict, cost_usd: float"""
```

## 6. MVP scope - ship with the DSPv2 dogfood

**In:**
- Stage 0 (draft)
- Stage B (coherence)
- The pipeline wrapper for 0 → A → B → compile → two_agent execute
- `kairos.spec.pipeline.run(requirement_path, stages=[0, A, B, G])`
- Dogfood: `solve/two_agent/requirements/dspv2_awq_swap.md` → end-to-end

**Out (post-MVP, each its own PR):**
- Stage C (coverage) - PR 2
- Stage D (mutation) - PR 3
- Stage E (round-trip) - PR 4
- Stage F (economics) - PR 5

Why split: each stage has its own failure-mode taxonomy and its own mutator-or-judge design question. Trying to land all 7 at once is a 1000-LOC PR that's hard to review. Incremental lands with their own dogfood fixtures prove each stage's value.

## 7. Stage-specific notes (for implementers)

### Stage 0 - Draft

- Input: requirement.md (plain text) + relevant codebase context (files the draft agent should read; extract via simple `grep -r` over target_file references in the requirement, or pass a `context_globs: list[str]` param)
- Model: Sonnet 4.6 - fast enough, good code-aware drafting
- Output: SpecV1 JSON + a companion `task.md` (body prose) in the style of existing `solve/cross_accel/tasks/port_flash_attn_cuda_to_nki.md`
- Prompt must enforce: "output strictly `{...}` SpecV1 JSON, nothing else" + a separate pass for the task.md body
- Cost envelope: $1-3 per draft

### Stage B - Coherence

- Input: SpecV1 + target_file content
- Model: Opus 4.6 - needs the deeper reasoning for "is this achievable + coherent"
- Judge prompt: "Given the codebase and spec, identify: (a) target references that don't exist, (b) acceptance criteria that are unmeasurable, (c) steps that contradict each other, (d) hidden prerequisites the spec doesn't declare. Return a JSON list of defects or `ok:true`."
- Cost envelope: $2-5 per check

### Stage C - Coverage

- Extract each ATOMIC clause from the requirement (§4 Measurable outcomes rows, §6 Hard constraints bullets, §8 non-goals). Sonnet can do the extraction in a sub-call.
- For each clause, judge "is this addressed in the spec?" → coverage matrix
- Uncovered clauses → defects
- Cost envelope: $2-4

### Stage D - Mutation

- Mutator taxonomy (initial, extend as we learn):
  - `drop_measurable_outcome` - remove one row from the spec's measurable outcomes
  - `weaken_threshold` - change `≥ 35 tok/s` to `≥ 20 tok/s`
  - `flip_metric_direction` - change `≥ baseline` to `≤ baseline`
  - `substitute_target` - change `DSPv2-7B` to `DSPv2-70B`
  - `drop_hard_constraint` - remove one §6 bullet
  - `move_constraint_to_soft` - move from §6 to §7
- Generate N ∈ [5, 10] mutants (enough for kill-rate signal, not so many that cost explodes)
- Re-run Stage C on each
- Kill-rate = (mutants rejected by C) / (mutants total); gate at **70%** initially, tune from fixtures
- Cost envelope: N × Stage C cost = $10-40 - needs a budget cap

### Stage E - Round-trip

- Sonnet: paraphrase SpecV1 back to a 1-page NL requirement
- Semantic-similarity: embedding cosine (sentence-transformers) OR a judge model - start with judge model, embedding is a follow-up optimization
- Threshold: 0.85 (tunable; must be set per vertical)
- Cost envelope: $1-2

### Stage F - Economics

- Inputs: `spec.budget.usd`, `spec.claimed_value` (new field - requirement §5 declares this), estimated P(success) from Stage B + D results
- Formula v0: `pass = (claimed_value × P_success) > (budget × (1 + risk_premium))`
- `risk_premium = 0.5` default; tune from dogfood outcomes
- This is the cheapest stage - pure arithmetic, no LLM call
- Returns BAIL with rationale if economics don't clear

## 7a. Evidence hierarchy - spec-hierarchy tiers (asabi directive 2026-04-22)

Every acceptance criterion in a `SpecV1` declares the evidence tier it requires to be considered "met." Three tiers, strongest to weakest, collapsed from the internal Kairos-pipeline five-verifier architecture. The taxonomy is self-supporting - it does not rely on any specific public paper section and must remain valid under any IP-protection-driven removal of pipeline disclosure from external artifacts (asabi 2026-04-22).

| Tier | Verifier | When applicable | Example criterion |
|:-|:-|:-|:-|
| `lean_proved` | Lean 4 kernel **and/or** Dafny/Z3 (collapsed - asabi 2026-04-22) | formal theorems, algorithmic invariants on real arithmetic | "close the sorry `howard_bridge_lower` with axiom audit ≤ {propext, Classical.choice, Quot.sound}" |
| `bmc_bounded` | EBMC k-induction at declared bound `k` | bit-vector invariants on finite-state machines, RTL/SystemVerilog properties | "property P1-P5 hold at k=16 on the `mask_shell.sv` encoding" |
| `empirical` | Property-based testing + CPU simulator + differential use | statistical measurements, integration/resource properties, ML close-rate | "close-rate on 5-theorem calibration fixture ≥ baseline at 1000 trials" |

**Why Lean + Dafny/Z3 collapsed into one tier** (asabi 2026-04-22 after my premature-split question): both produce axiom-audit-auditable formal guarantees. SMT `UNKNOWN` = failure that drops the outcome to `bmc_bounded`, not a weaker-but-still-formal tier. If post-MVP customers care about dependent-types-vs-SMT-decidable distinction, split then. Don't prematurely split.

**Schema implication.** `SpecV1.measurable_outcome` gains two new fields (bundled into the 1.0 → 1.1 schema bump that's already happening for `target_kind="integration"`):

```python
class MeasurableOutcome(TypedDict):
    name: str
    metric: str
    threshold: float | str
    direction: Literal["maximize", "minimize", "equal", "at_least", "at_most"]
    evidence_tier: Literal["lean_proved", "bmc_bounded", "empirical"]
    bound_k: int | None   # required when tier == "bmc_bounded"; else None
```

**Stage G execution** picks the verifier from `evidence_tier`, not from `target_kind`. This decouples "what we're doing" (kernel port, theorem close, runner swap) from "how we're verifying it" (formal / bounded / empirical).

**Tier-stretching is forbidden.** A spec that claims `evidence_tier="lean_proved"` for an outcome that's only checkable empirically is a Stage C (coverage) or Stage B (coherence) defect - the tier must match the verifier the pipeline will actually run. This is the `tier_stretching` mutator Stage D introduces (weaken `lean_proved` → `empirical`, or stretch `empirical` → `lean_proved`; Stage C re-run must reject).

**Concrete dogfood mappings:**

- **DSPv2 AWQ swap** (`target_kind="integration"`): all outcomes `evidence_tier="empirical"`. Close-rate on calibration fixtures, VRAM headroom, tok/s - statistical measurements. No formal proof of runner correctness required; vLLM's AWQ is trusted upstream.
- **PR #10 autoformalize** (`target_kind="theorem"`): outcomes span all three tiers. Statement mutation testing at `empirical`. Bit-level property invariants at `bmc_bounded` with declared `bound_k=16`. Closure proof at `lean_proved`.
- **Flash-attn NKI port** (`target_kind="kernel"`, existing cross_accel task): EBMC properties at `bmc_bounded` (k=16), differential use at `empirical`, SystemVerilog shell invariants at `bmc_bounded`.

**References:**
- Internal Kairos-pipeline architecture (not cited to any external paper section - IP-protection-safe decoupling per asabi 2026-04-22; the public paper style is Wu/Waudby-Smith/Whitehouse and deliberately does not disclose agent orchestration)
- asabi directive 2026-04-22 (slack #dev-research) - routing the spec-hierarchy-tiers commit into PR #10 autoformalize shape + Lean/SMT tier collapse
- QA's partial Q6 pushback earlier this thread - independent motivation from the plausibility-vs-coherence angle

## 8. Relationship to existing pipelines

- `solve/two_agent/run.sh` - Stage G can invoke this directly when `target_kind ∈ {"kernel", "runner_port", "custom"}`
- `solve/cross_accel/run.sh` - Stage G invokes for `target_kind="kernel"` + `verification=="three_layer"` (EBMC + Lean + differential)
- `solve/neuron/run.sh` - Stage G invokes for `vertical="neuron"`
- `solve/shared/modes/mode_fleet.py` - direct invocation for lean/bio/sysverilog verticals (existing path)

The pipeline doesn't replace these; it feeds pre-validated IntentV1 into them.

## 9. Open questions (please react before implementation)

1. **`target_kind` enum extension** - the current enum (`theorem | property | kernel | rtl_fix | top_module`) doesn't have a fit for "runner_port" or "integration_swap" (ML infra work). Do we (a) add `target_kind="integration"` as a new enum value (requires ATH-* ticket + schema version bump to 1.1), (b) stretch `target_kind="kernel"` with a new `spec.extension.custom.sub_kind` field (no schema bump, advisory), (c) leave this as a separate design decision? MVP can ship with (b) and revisit.
2. **Stage D mutator selection per-vertical?** A theorem-proving spec has different good mutators than an ML-infra spec. Do we ship a `mutators: list[Mutator]` override per vertical, or a single fixed taxonomy with per-vertical weights? MVP proposal: fixed taxonomy, all mutators tried with equal weight, tune weights from fixture kill-rates.
3. **Stage E embedding vs judge model?** Judge model is more expensive but easier to reason about. Embedding is cheap but opaque to debugging. MVP proposal: judge model (Sonnet), since it naturally explains divergences; swap for embedding once we have ≥100 requirement-spec pairs to tune a threshold against.
4. **Stage F "claimed_value" provenance** - the customer has to declare it in the requirement. What if they don't, or the declaration is wildly optimistic? Stage B (coherence) should catch the latter - flag "claimed_value inflation" as a coherence defect. Not a separate stage.
5. **Failure loop-back** - when Stage B/C/D fails, should Stage 0 retry with the defect list as input? MVP: no - return defects to the caller, let them decide. Retry automation is a follow-up.

## 10. Dogfood + handoff

First canonical dogfood: **`solve/two_agent/requirements/dspv2_awq_swap.md`** - a real internal need. See that file for the full requirement text.

Handoff owner split (proposed):
- **QA** - implements Stage 0 + B + pipeline wrapper + kairos.spec surface. MVP scope.
- **Platform** - produces reproducible `requirements-dspv2-vllm.txt` for the eventual Stage G execution (the DSPv2 env pins we just fought through by hand today).
- **Research (me)** - owns this design doc + the DSPv2 requirement file + gates the dogfood run end-to-end.

Open for objection or revision before QA/platform starts on MVP.

## 11. Known soundness dependencies (QA flagged 2026-04-22)

Stages of this pipeline rely on downstream verifiers being sound. Where a verifier is known to be weaker than its label implies, we document it here so implementers don't accidentally trust the output.

| Dependency | Owner | Ticket | Impact on spec pipeline | Status |
|:-|:-|:-|:-|:-|
| **CEGAR → k-induction** in builder's EBMC path (`loop.py:393` + `ebmc.py:32` docstring truth-up + split verdict labels `BMC-bounded-N` vs `k-induction-unbounded`) | builder / QA | [ATH-491](https://linear.app/athanor-ai/issue/ATH-491) | Stage F2 (Economics) risk_premium is under-calibrated if CEGAR's `PROVED` is actually BMC-bounded-10. Without this fix, any Stage G run producing an EBMC verdict inherits the ambiguity. Stage F2 must treat all `bmc_bounded` outcomes at declared `bound_k` - never as unbounded proved. | open, QA lane |
| **Spec-integrity hash lock** | research / QA | ATH-* (I'll file) | Without hash-verify at Stage G entry, any mutation to IntentV1 between Stage B end and Stage G start goes undetected. Mechanical guarantee that the fleet executes the exact spec that passed the guards. | MVP primitive lands (minimal - hash field in dataclass + Stage B end-of-stage call); Stage G enforcement wires post-MVP (PR 6). |
| **Autoformalize soundness** (PR #10) | research | TBD as PR #10 progresses | Autoformalize produces outcomes at three tiers (§7a). Statement mutation testing at `empirical`, bit-level invariants at `bmc_bounded`, closure proof at `lean_proved`. Each has its own soundness path that PR #10 surfaces - stale Mathlib, EBMC bound-too-low, kill-rate-threshold-too-loose. | placeholder; filed per PR #10 scoping |

**Stage F2 risk_premium calibration rule:** for every `bmc_bounded` outcome, risk_premium includes a `bound_uncertainty_factor` scaling the declared P(success) down by `(1 - bound_k / expected_unbounded_k)`. Makes the bound explicit in the economics. Default `expected_unbounded_k = 1000` (tune from fixture data post-MVP).

**Integrity-hash MVP shape** (per QA 2026-04-22):

```python
# kairos/spec/integrity.py
import hashlib, json
from kairos.spec_v1 import IntentV1

def canonical_hash(intent: IntentV1) -> str:
    """SHA256 of canonicalized JSON (sorted keys, no whitespace variance)."""
    return hashlib.sha256(
        json.dumps(intent, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()

def sign(intent: IntentV1) -> IntentV1:
    """Recompute + embed hash in intent.meta.integrity_hash. Call at Stage B end."""
    # ... ~10 LOC
def verify(intent: IntentV1) -> bool:
    """Recompute + compare to embedded hash. Call at Stage G start."""
    # ... ~10 LOC
```

~30 LOC total. Schema lands hash field in MVP (IntentV1 gains `meta.integrity_hash: str | None`); enforcement on all intermediate-stage writes lands post-MVP.

**Canonical-JSON scope rule (QA 2026-04-22 refinement):** `canonical_hash(intent)` excludes the `intent.audit_meta` branch. Audit metadata (timestamps, correlation_id, submitted_by, run_id) lives in that sibling and is deliberately not part of the hashed surface. This is cleaner than a per-field "is this ephemeral" judgment call each time a new field lands. Existing `IntentV1._operational` fields (customer_note, correlation_id, submitted_by) - QA to audit during integrity.py implementation: move ephemerals to `audit_meta`, keep stable ones in the hashed surface.

**Stage F2 risk_premium - post-MVP tuning note (QA 2026-04-22):** the `bound_uncertainty_factor = (1 - bound_k / expected_unbounded_k)` formula ships in MVP with `expected_unbounded_k=1000` default, but has a known calibration weakness: properties with small true diameter (e.g., proved at k=10 with diameter-5) get the same penalty as properties that need k=500+. Alternative proposed post-MVP: **binary gate** - for high-stakes specs (`budget_usd > $50` default threshold), F2 REFUSES `bmc_bounded` verdicts outright, forcing `k_induction_unbounded` or a REJECT; for low-stakes, accepts with explicit warning. Tune the binary threshold from dogfood outcomes, not before.

## 12. MVP scope - updated 2026-04-22 after QA review

**In (bundled into one MVP PR):**
- Stage 0 (draft) + Stage B (coherence) + pipeline wrapper + kairos.spec surface
- SpecV1 1.0 → 1.1 schema bump: `target_kind="integration"` enum addition + `MeasurableOutcome.evidence_tier` + `MeasurableOutcome.bound_k` + `IntentV1.meta.integrity_hash`
- `kairos/spec/integrity.py` - canonical_hash + sign + verify primitives (enforcement deferred post-MVP)
- `fail_fast: bool = True` kwarg in `pipeline.run()`
- Unit + property + integration tests (DSPv2 requirement end-to-end)

**Out (post-MVP follow-up PRs, each its own dogfood fixture):**
- PR 2: Stage C (coverage)
- PR 3: Stage D (mutation, includes `tier_stretching` mutator per §7a)
- PR 3.5: per-vertical mutator subsets (QA's Q4 flag - theorem-proving specs need different mutators than ML-infra specs; not just weight-tuning)
- PR 4: Stage E (round-trip; judge model MVP, embedding swap only after ≥20 pairs × ≥4 verticals)
- PR 5: Stage F (split into F1 Plausibility + F2 Economics; F2 first - simple arithmetic - F1 deferred pending comps-corpus data)
- PR 6: integrity-hash enforcement wired across all intermediate stages
- PR 10: autoformalize vertical exercising all three `evidence_tier` values per stage
