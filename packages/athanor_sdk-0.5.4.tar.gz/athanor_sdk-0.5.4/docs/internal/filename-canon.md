# Lean Filename Canonicalization

## The canonical rule

Given a snake_case `task_slug`, the Lean stub filename is derived as follows:

1. Strip the `_builder_verifier` suffix if present.
2. Convert the remaining slug to PascalCase: capitalize the first letter of each
   `_`-separated word, concatenate, no separator.
3. Append `.lean`.

Examples:

| task_slug | lean_file |
|:-|:-|
| `fib_add_formula` | `FibAddFormula.lean` |
| `binary_search_builder_verifier` | `BinarySearch.lean` |
| `sqrt2_irrational` | `Sqrt2Irrational.lean` |
| `sum_odds_equals_n_squared` | `SumOddsEqualsNSquared.lean` |

This rule is observed across all tasks in
`environments/lean-theorem-proving/root_data/eval/configs/*.json`
and matches the pattern in
`athanor-builder/scaffold-lean/src/environment/tasks/example_task/__init__.py`
(where `lean_filename = "ExampleSorry.lean"` for slug `example-sorry`).

## Authoritative side: the scoring container

The scoring container (`scoring.py`) reads `lean_file` directly from the task's
JSON config:

```python
lean_file = config["lean_file"]   # e.g. "/workdir/data/FibAddFormula.lean"
lean_path = Path(lean_file)
if not lean_path.exists():
    # → score 0, error "student file not found"
```

The container does **not** re-derive the filename from `task_slug` at runtime.
The `lean_file` field in the config JSON is the ground truth. The SDK helper
below exists so that the Build-a-Task flow writes the stub to the same path
before the container ever runs.

## SDK helper

```python
from athanor.filenames import task_slug_to_lean_filename

lean_filename = task_slug_to_lean_filename("sum_odds_equals_n_squared")
# → "SumOddsEqualsNSquared.lean"
```

The function is stdlib-only, no dependencies.

## What platform must do in Build-a-Task before docker build

When `proof_backend == "lean"`, the runner's `run_build` must use
`task_slug_to_lean_filename` instead of the default `f"{task_id}.py"`.
Concretely, the following two writes must use the canonicalized filename:

1. **Stub file** - write to `student_data/<lean_filename>`:
   ```python
   lean_filename = task_slug_to_lean_filename(task_id)
   stub_path = os.path.join(checkout, "student_data", lean_filename)
   ```

2. **Scoring config** - set `lean_file` (not `student_file`) in the JSON config
   to the in-container path:
   ```python
   scoring_config["lean_file"] = f"/workdir/data/{lean_filename}"
   ```
   The lean scoring.py reads `lean_file`, not `student_file`. Both fields
   should be set for forward compatibility:
   ```python
   scoring_config["student_file"] = f"/workdir/data/{lean_filename}"
   scoring_config["lean_file"]    = f"/workdir/data/{lean_filename}"
   ```

3. The `stub_filename` passed to `run_score` for validation must also use the
   canonicalized name so the runner writes the code to the right path inside
   the temp data dir:
   ```python
   task_cfg = {"task_slug": task_id, "stub_filename": lean_filename}
   ```

The scoring container will then find the file at `/workdir/data/<lean_filename>`
and proceed normally. Mismatch between the written path and `lean_file` in the
config is the root cause of ATH-110 ("student file not found").
