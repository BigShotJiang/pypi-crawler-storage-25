# Athanor SDK - Enterprise Deployment Guide

_Audience: Athanor's enterprise customers. Describes the end-to-end
flow from contract signing to first verified proof on the customer's
infrastructure. Last updated 2026-04-19._



## What you receive

When your contract signs, Athanor delivers a single GPG-signed
tarball: `athanor-enterprise-<customer-slug>-<version>.tar.gz`.
Expected contents after extracting:

```
install.sh              # Entry point - run this first
install.sh.sig          # Detached GPG signature of install.sh
pubkey.asc              # Athanor's signing public key (also shipped here)
athanor-sdk-<ver>.tar.gz          # The SDK wheel
athanor-sdk-<ver>.tar.gz.sig      # Detached signature
athanor-builder-<ver>.tar.gz      # Private orchestrator + per-vertical engines
athanor-builder-<ver>.tar.gz.sig    (ONLY IF "solve" in license.products; see ATH-390)
license.json            # Your per-org license, signed by Athanor
license.json.sig        # Detached signature
scoring-containers/     # Docker image tarballs for env scoring
  <env>.tar             # ONE PER ENV YOU LICENSED - filtered to license.envs[]
manifest.json           # Bundle contents + license-scope summary (audit)
```

### Bundle is per-customer (ATH-390)

The bundle you receive is assembled against your specific
`license.json` - we do not ship one-size-fits-all. Two conditional
rules govern what's inside:

- **`athanor-builder-*.tar.gz`** is ONLY included when your license
  grants `"solve"` (i.e. `products` contains `"solve"`). An
  envs-only customer receives no builder tarball at all. This is
  intentional: the builder holds Tier-1 orchestration IP that
  envs-only workloads don't use. If you later upgrade to solve, your
  next delivery includes the builder automatically.
- **`scoring-containers/<env>.tar`** is included ONLY for each `env`
  listed in your license's `envs[]`. Containers for envs you
  haven't licensed are not shipped even if they exist in our build
  artifacts.

Check `manifest.json` at the top of the extracted tree for the
authoritative list + why each asset was included or excluded.

## Before you install

**Verify the tarball fingerprint out-of-band.**

The `install.sh` script has our signing-key fingerprint hard-coded at
the top. Before you run it, confirm that fingerprint matches the one
you were told to expect from two independent channels:

1. The first page of your signed contract PDF.
2. The onboarding email from `aidan@athanorl.com`.

If those three strings (PDF, email, install.sh line) don't all agree,
**stop and contact us**. The tarball did not come from us.

**Ensure the system has the prerequisites:**

- Python 3.10 or later (`python3 --version`)
- `gpg` ≥ 2.2 (`gpg --version`)
- A supported OS: Linux x86_64 (the tarball's compiled artifacts
  target this platform today)
- For scoring: Docker or Podman with `--network=none` capability
- Optional: `sudo` if installing to a system prefix

## Install

```bash
tar xzf athanor-enterprise-<slug>-<version>.tar.gz
cd athanor-enterprise-<slug>-<version>/

# Preview every action without executing:
./install.sh --dry-run

# Run for real (default: user install to ~/.athanor/):
./install.sh

# Or install to a system prefix (requires sudo):
./install.sh --prefix /opt/athanor
```

### What install.sh does

1. Verifies its own signature (`install.sh.sig`) against `pubkey.asc`.
2. Imports the pubkey into an ephemeral `GNUPGHOME` (does NOT touch
   your existing `~/.gnupg`).
3. Confirms the imported key's fingerprint matches the hard-coded
   expected value (step-zero check; fails hard on mismatch).
4. Verifies each artifact signature (SDK, builder, license, scoring
   containers).
5. Installs the SDK wheel into your user site-packages (or
   `$PREFIX/lib` if `--prefix` was passed).
6. Copies `pubkey.asc` + `license.json` into `~/.athanor/` (mode
   `0o700`/`0o600`) so the SDK can re-verify license signatures on
   every `athanor spec submit`.
7. Does NOT invoke sudo unless `--prefix` was explicitly passed. By
   default everything is owner-only in your home directory.

## Set your API token

```bash
# Recommended: file-based config, owner-only readable
mkdir -p ~/.athanor && chmod 0700 ~/.athanor
printf '%s' "$YOUR_ATHANOR_TOKEN" > ~/.athanor/token
chmod 0600 ~/.athanor/token

# Or use the CLI helper:
athanor config --set-token
```

The legacy `ATHANOR_TOKEN` environment variable still works but emits
a deprecation warning. File-based is preferred: other same-user
processes can't read `/proc/<pid>/environ`, but they also can't read
a `0o600` file in a `0o700` directory.

## Verify the install

```bash
athanor --version
athanor spec template > sample-spec.json
athanor spec submit sample-spec.json --dry-run
```

If all three succeed without errors, you're installed correctly.

## The verification workflow

### 1. Author a spec

```bash
athanor spec template > my-theorem-spec.json
# Edit my-theorem-spec.json to describe your verification target.
```

A `SpecV1` contains at minimum:

- `target_file` - path to the Lean / SystemVerilog / Python file
- `target_name` - the theorem / module / kernel name
- `vertical` - one of `lean`, `sysverilog`, `neuron`, `bio`, `bbr3`,
  `action_cred`, `custom`
- `budget` - `{wall_seconds, usd}` caps

See the comments in the generated template for optional fields
(`verification` layer toggles, `thresholds` for acceptance gates,
per-vertical `extension` bag).

### 2. Validate locally (no builder required)

```bash
# Stage-A schema + rule-based validation, runs in seconds, no LLM:
athanor spec validate --stage A my-theorem-spec.json
```

Stage-A catches malformed specs, unknown verticals, missing required
fields, nonsensical budget values. It's fast + deterministic.

### 3. Submit

```bash
athanor spec submit my-theorem-spec.json
```

The SDK:

1. Runs Stage-A validation again (belt-and-braces).
2. Re-verifies `license.json` signature against the pinned fingerprint.
   ~10ms; cached for 60s on unchanged mtime.
3. Compiles `SpecV1` → `IntentV1` (a neutral intent structure; no
   prompt text crosses this boundary).
4. Creates `~/.athanor/runs/<run-id>/` with `0o700`.
5. Dispatches the `IntentV1` to the local `mode_fleet` orchestrator
   (part of athanor-builder). Large intents (>100KB) go via a secure
   temp file (`tempfile.mkstemp(mode=0o600)`); smaller intents go
   inline via argv.
6. Mode_fleet runs the multi-phase pipeline (planner / builder race /
   property / mutation / proof / audit - exact phases depend on
   vertical).
7. Output artifacts land under `~/.athanor/runs/<run-id>/`.

### 4. Bundle the run artifacts

```bash
athanor spec bundle <run-id>
# Writes ~/.athanor/runs/<run-id>/bundle.tar.gz at mode 0o600.
```

The bundler:

- Collects `run.json`, `proof.lean` (or the closest refined variant),
  `counterexample.txt`, `audit_report.json`, `mutation_report.json`,
  `property_report.json` - whichever artifacts the run produced.
- Embeds a `bundle.json` manifest with sha256 checksums for every
  included file.
- Refuses to write the bundle if any included text file contains an
  Athanor-internal prompt marker (IP redaction guard - prevents
  accidental exfiltration).

### 5. Verify a bundle later

```bash
athanor spec verify-bundle path/to/bundle.tar.gz
```

Recomputes every file's sha256 and compares against the embedded
manifest. Useful after transferring a bundle between machines, or
for regulatory-audit reproducibility.

## Security posture

### What stays local

- Your source files, specs, intermediate artifacts, run outputs -
  never leave your VM.
- Your API token - lives in `~/.athanor/token` (mode `0o600`) or
  optionally in a secrets manager you've wired up.

### What the SDK sends to Athanor

- Usage telemetry for billing / licensing - aggregate counts per
  submit, no content.
- No prompts, no model outputs, no verification artifacts.

### What you must trust

- The GPG signing chain (expected fingerprint + in-tarball pubkey).
- The athanor-builder binaries inside the tarball (Cython-compiled,
  verified via signature - their source lives in our private repo
  under proprietary license).

### Scope of the proprietary license

Per the `LICENSE` file shipped in the SDK: you may use the software
only within the organization named in your contract, for the
environments named in your license. You may not:

- Redistribute the SDK, builder, containers, or any derived artifact.
- Reverse-engineer the compiled components (Cython `.so` files,
  container binaries).
- Share your license / token with other organizations.

Violation voids the license. See `ENTERPRISE-CONTRACT.md` for the
full terms.

## Troubleshooting

**`install.sh` fails at "fingerprint mismatch":** the tarball was
tampered with in transit, or you're installing a tarball meant for a
different customer. Stop and contact us.

**`athanor spec submit` exits with code 2:** athanor-builder is not
installed or not on `PATH`. Check `ls /opt/athanor/builder/` or
`which mode_fleet`. Re-run `install.sh` if the builder tarball is
present but not extracted.

**`athanor spec submit` exits with code 3:** license signature
verification failed. Either `~/.athanor/license.json` is tampered
with, its mtime is in the future (clock skew), or the pubkey
fingerprint doesn't match what's pinned. Re-install from a fresh
tarball.

**`athanor spec bundle` exits with code 4:** the redaction gate
tripped - an Athanor-internal prompt marker was found in a run
artifact. This indicates a builder-side redactor regression (not
a customer issue). Contact us with the run id; we'll investigate
and ship a builder patch.

**`athanor spec verify-bundle` reports a checksum mismatch:** the
bundle was modified after packing. Either it's tampered with, or it
was re-compressed / re-archived along the way. Request a fresh
bundle from the source.

## Support

- Contract-scope issues: whoever signed your contract (the named
  contact on page 1 of the PDF).
- Technical issues: `aidan@athanorl.com`.
- Security reports: `aidan@athanorl.com` with PGP - our key
  fingerprint is the same one pinned in `install.sh`.

## Upgrading

New SDK versions ship as fresh signed tarballs. Install flow is the
same. Previous install stays intact under `~/.athanor/` until the new
install overwrites it; your license renewal process is separate
(handled via contract addenda, not in-tarball).
