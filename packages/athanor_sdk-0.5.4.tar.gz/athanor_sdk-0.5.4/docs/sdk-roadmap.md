# kairos SDK. roadmap

_Last full rewrite: 2026-05-01 (qa, ATH-916). Supersedes the 2026-04-19
draft, which planned a V1 partition that shipped in late April._

## TL;DR

`kairos` is Athanor's customer-facing verification SDK. As of
2026-05-01:

1. **Free tier ships.** `pip install athanor-kairos` →
   `kairos.simple_prove_template("...")` → NL hypothesis maps to a
   Pythia template, runs Lean, returns NL verdict. Zero phone-home,
   no license, no Lean files written by hand. See
   [`docs/free-tier-quickstart.md`](free-tier-quickstart.md).
2. **Paid tier ships, license-gated.** `kairos.prove(...)`,
   `kairos.fleet.Orchestrator(...)`, `kairos.sv.*` (cegar, prove,
   swarm, invariants, multi, hb_graph). Fail-closed at every callsite
   (`LicenseScopeError` on missing license). See
   [`docs/sdk-tier-model.md`](sdk-tier-model.md) for the API catalogue.
3. **Customer engagements active.** Todd PORT/NCS (Annapurna FV),
   Amazon HW verification, Customer-1 (NeurIPS dogfood). The verticals
   we ship against. RTL/SystemVerilog (EBMC), Lean/Pythia, ACL2,
   each have at least one in-flight customer.

V1 (the 2026-04-19 enterprise-customer-deliverable milestone) closed
2026-04-25. The current horizon is **dogfood-driven hardening**:
every customer task surfaces SDK gaps, and we ship the fix in-session
rather than deferring (per Aidan 2026-04-24).

## 1. What ships today

### 1.a Package + install

* PyPI: `athanor-kairos` (proprietary license, post-ATH-337 IP partition).
* Imports as `kairos`.
* Source layout: `src/kairos/`, `tests/`, `docs/`. The pre-rename
  `athanor-sdk` / `src/athanor/` paths are dead; they appear in old
  PRs and Linear tickets only.
* Vendored under `src/kairos/_vendor/`: Pythia (Apache-2.0,
  free-tier proof engine), lean-machines (Apache-2.0, refinement
  framework), lean-machines-examples (Apache-2.0, sample specs).

### 1.b Free-tier surface (no license, zero phone-home)

| API | Purpose |
|---|---|
| `simple_prove_template(hypothesis)` | NL → Pythia template → Lean → verdict → NL. Hides Lean entirely. |
| `simple_prove(hypothesis, target_file)` | Single-LLM proof against an existing Lean target file. |
| `verify_proof(code)` | Run a Lean 4 proof through the compiler. |
| `score_proof(code)` | 1.0 (full) / 0.35 (sorry) / 0.25 (broken) / 0.0 (banned). |
| `check_sorry(code)` | Count `sorry` placeholders. |
| `lean_machines.list_refinement_chains()` | List bundled Event-B chains (Buffer, PushBuffer). |
| `lean_machines.to_sva(...)` | Translate Lean invariants to SystemVerilog assertions. |
| `kairos verify-batch <dir>` | Bulk-verify a directory of `.lean` files. |
| `kairos init --lean-pythia --dest <path>` | Scaffold a Lake project with Pythia + Mathlib + lean-machines pre-wired. |

The free tier never opens a network socket except when the customer
opts into BYO LLM key for hypotheses outside the built-in templates.
That LLM call goes machine→provider, never machine→Athanor.

### 1.c Paid-tier surface (license-gated)

| API | Purpose |
|---|---|
| `prove(hypothesis, vertical=..., target_file=...)` | Tier-1 customer-agent entry. NL → IntentV1 → SpecPipeline → Verdict. |
| `session(task_id=...)` | Group multiple `prove()` calls under one task ID. |
| `fleet.Orchestrator(model=..., worker_models=...)` | LLM-backed tier/worker planning across multi-tier specs. |
| `sv.prove`, `sv.cegar`, `sv.swarm`, `sv.invariants`, `sv.multi`, `sv.hb_graph` | RTL verification stack via EBMC. |
| `acl2.refinement_prove`, `refinement_prove_two_module`, `refinement_prove_cycle_equivalence`, `import_ebmc_invariant*` | ACL2/VL/FGL refinement + cross-tool invariant import. |

License gate fires at construction or first call. no silent
permissive fallback. Callsites that need to read trace events without
running paid flows use the `KAIROS_DEV_NO_LICENSE=1` internal bypass
(documented in `kairos.license_scope`; never set on customer
machines).

### 1.d MCP server

`kairos mcp` exposes the SDK as an MCP server (Claude Code, Cursor,
Cline, OpenHands, Leanstral). Free-tier and paid-tier tool sets are
separate. paid tools surface only when a license is loaded. Schema
catalogue: `tests/test_mcp_schemas.py`, `kairos.mcp_server`.

### 1.e CLI

`kairos --help` lists 30+ subcommands. Free-tier-callable without a
license:

* `simple-prove`, `verify-batch`, `init`, `verify`, `audit`, `doctor`,
  `bootstrap`, `config`.

License-gated:

* `prove`, `sv-prove`, `sv-invariants`, `sv-swarm`, `sv-cycle-swarm`,
  `sv-multi`, `sv-hb-graph`, `cegar`, `solve`, `evaluate`, `mcp`
  (paid tools), `fleet.*`.

Internal-only (won't be in customer-shipped tarballs once the strip
ATH-918+ follow-up lands):

* `build`, `run`, `runs`, `proofs`, `pull`, `score`, `task-info`,
  `calibrate`, `stats`, `compare`, `eval-status`, `preflight`,
  `lint`, `estimate`, `report`, `stream`, `trace`.

## 2. Active customer engagements

### 2.a Todd PORT/NCS. Annapurna FV (Customer-2)

Todd sent the full PORT (Pre-implementation, Operations, RTL, Theorems)
+ NCS (Notation, Conditions, Specification) framework on 2026-04-29.
The v0 prototype we shipped was ~5% of the eventual scope. Children:
ATH-872, ATH-873, ATH-874, ATH-875.

Recent SDK-side wins driven by Todd:

* ATH-906: VL+FGL refinement actually certifies on `cpu_single_issue`
  (closed his audit critique that the previous 3-way refinement was a
  tautology. PRs #363/365).
* ATH-907: BTOR2-incremental CEGAR. Todd's 10-step loop (PR #362).
* ATH-908: EBMC↔ACL2 cross-tool invariant import. Pattern 2 (the
  import path) ships end-to-end with `mode='reprove'` (default,
  certifies via FGL) and `mode='axiom'` (`:skip-proofs-okp t`,
  customer-defensible only when invariants come from a trusted EBMC
  run). PRs #367/377/378/381. Pattern 1 (discovery side) is on
  platform's queue.
* ATH-911: two-module SI-vs-PIPE refinement, Mode A
  (API-validation milestone, PR #370).
* ATH-913: cycle-equivalence (Mode B, customer claim, PRs #384/385).
* ATH-918/919: customer-onboarding bugs surfaced during the
  free-tier walk and shipped same-day.

### 2.b Amazon. HW verification (Customer-3)

NDA in progress as of 2026-04-18. Big HW-verification customer; six
concerns mapped (orchestrator-vs-LLM partition, spec rejection, Lean
skepticism, private heuristics, custom anti-cheat, Harmonic
comparison). ATH-315 spec validator addresses concern #2 directly.
Engagement is pre-pilot.

### 2.c Customer-1. NeurIPS dogfood (asabi)

asabi is Customer-1 internally. running NeurIPS-paper experiments
against the SDK as an end user. Catches gaps that no synthetic test
exercises. Every gap files an SDK ticket; QA owns implementation.

## 3. Active workstreams

### 3.a ATH-912 declarative flows (Phase 1 + Phase 2)

Cascades (lean / sv / acl2) now consume YAML flow definitions rather
than hardcoded dispatch chains. PRs #371 → #375 + #379 + #382 +
#383. Phase 2 added typed I/O contracts (`flow_contracts.py`) with
hypothesis-style PBT verification of the compatibility checker.

Open: ATH-915 (Lean refinement proof of contract checker. backlog,
awaits Lean toolchain greenlight).

### 3.b Customer-onboarding hardening

The free-tier walk surfaced 4 bugs in one afternoon (ATH-918 ×3,
ATH-919). Pattern is "doc says X, reality is Y, customer hits TypeError
on first call." Going-forward fix: doc-test the README's quickstart
examples in CI (filed as TODO, not yet ticketed).

### 3.c Customer-facing language discipline (asabi 2026-04-26 sign-off)

Lock-in for any SDK output, doc, or customer-facing message:

* DON'T claim "we proved equivalence" or "real refinement proof"
  without naming the trust roots and bounds.
* DO claim what each artifact actually proves, e.g.
  "k-induction-bounded equivalence verified through EBMC on the
  actual RTL via VL translation; full unbounded equivalence via
  FM9801-style flushing remains future work."
* The two ATH-908 modes are NOT equivalent: `reprove` reverifies
  the imported invariants in ACL2/FGL; `axiom` accepts them via
  `:skip-proofs-okp t` and is only customer-defensible when the
  invariants came from a trusted EBMC run that the customer
  themselves authored.

### 3.d Internal hygiene

* ATH-917 (done): pyflakes cleanup. 75 unused imports + 35 f-strings
  + 1 real duplicate dict-key bug in `trace_schema.py`.
* ATH-920 (backlog): error-handling sweep. 285 `except Exception`,
  48 silent swallowers without justification. Recommend `ruff
  BLE001` + half-day mechanical comment-sweep.
* ATH-921 (urgent, in flight, platform-owned): main CI red since
  2026-04-28 due to test pollution (license cache leak across
  module-level state). Bisecting `e310d2b..52ac7fa`.

## 4. Next horizon (Q3 2026)

This section is forward-looking; treat as direction, not commitment.

### 4.a Pythia certify orchestrator

Per asabi 2026-04-26 reframe: Pythia becomes Athanor's
LLM-native applied-math Lean library. SDK owns the HW/SW + BYO-LLM
plumbing and the `pythia certify` orchestration entry; Lean templates
deferred to long-term `@[stat_lemma]` work. Free-tier
`simple_prove_template` is the v0 of this. pattern set will grow
with each customer.

### 4.b ATH-908 Pattern 1 (discovery side)

Platform-owned. SDK side already exposes `import_ebmc_invariants_from_*`;
discovery-pattern UI lives in platform.

### 4.c MCP advancement

* MCP tool surface accuracy audit (qa lane, in flight per audit-split
  with platform).
* Type-coverage gate: pyright non-strict first, file ticket for full
  strict (multi-day).
* @live nightly cron. file + own SDK-side.

### 4.d Tarball delivery

ATH-338 (signed per-customer tarball) is the route for air-gapped
customers (Amazon-tier). Platform owns the build + provisioning;
SDK exports the relevant manifest.

## 5. Architecture invariants

These don't change without an explicit founder/asabi decision:

1. **Free-tier independence.** `kairos.simple_prove_template`,
   `verify_proof`, `score_proof`, `check_sorry`, `lean_machines.*`,
   `verify-batch` MUST NOT import any paid-tier module or call
   `require_product` / `require_env_access`. Enforced by
   `tests/test_public_surface_docstrings.py` +
   `tests/test_mcp_schemas.py::TestFreeTierIndependence`.
2. **License fail-closed.** Every paid callsite raises
   `LicenseScopeError` on missing license. No silent permissive
   fallback. No "warn and continue."
3. **Zero phone-home on free tier.** No telemetry, no auto-update
   ping, no opt-out toggle (because there's nothing to opt out of).
   Only network traffic: BYO-LLM call when the customer sets a key,
   and that goes machine→provider.
4. **`ATHANOR_SYNC_TOKEN` is the SDK→DB contract gate.** Token
   present = always upload + fail-loud. Token absent = local-only.
   No `KAIROS_TRACE_SINK=noop` policy calls. (Aidan 2026-04-24.)
5. **Trust roots are spelled out.** Every claim in customer-facing
   output names what it depends on (Lean kernel, FGL, EBMC, k-bound,
   axiomatized invariant). No "we proved X" without "via Y under Z."

## 6. Ownership and coordination

* **qa**: SDK code review + onboarding hardening + dogfood-driven
  fixes. Customer-onboarding flow walk + MCP surface accuracy +
  type-coverage gate are qa-lane today.
* **platform**: SDK ops (CI, tarball provisioning, doc-consistency
  cross-repo audits, ATH-908 Pattern 1 discovery side).
* **asabi**: Customer-1 dogfood, customer-facing language
  calibration, Pythia direction.
* **research / cto**: GPU + ML; not in the SDK lane day-to-day.

Chain of command: all agents → asabi for sequencing/scope; asabi →
Aidan only on unsolvables (2026-04-25 lock-in, supersedes the
2026-04-23 platform-primary rule).

PR review discipline (Sam 2026-05-01): every PR gets an explicit
@platform review-please post in `#dev-sdk` before admin-merge.
CI-green ≠ peer review. Reciprocal: platform PRs ping qa.

## 7. Appendix

### 7.a Free vs paid breakdown

`docs/sdk-tier-model.md` is the source-of-truth doc. It enumerates
exact API names, license fields, and which env vars trigger which
gate.

### 7.b Security model

`docs/security-model.md` covers the threat table (forged license,
prompt-injection-via-spec, supply-chain), the GPG signature
verification chain, and the audit-log emission rules.

### 7.c License schema + delivery

`docs/license-schema.md` (license JSON shape) + `docs/enterprise-deployment.md`
(install path enterprise customers receive). Paid customers also
receive operational deep-dives (orchestrator internals, vertical
tactics, runbooks) in their tarball. those are not in this public
repo.

### 7.d Known risks

* **Pre-rename PyPI exposure.** `athanor-sdk` 0.3.2 + 0.3.5 shipped
  Apache-2.0 before the 2026-04-25 partition. Yanked, but pre-yank
  installs persist in the wild. Assume the pre-0.3.6 source is
  available to anyone determined enough.
* **Test pollution masking regressions.** ATH-921. 3 days of red
  CI before anyone (qa, today) noticed. Once fixed, the structural
  fix is "block admin-merge when main CI is red, or at least
  alert in #dev-platform."
* **Customer-onboarding doc rot.** Free-tier walk found 4 bugs in
  the README + linked docs. Pattern is broad; doc-testing the
  examples is the durable fix. Filed as backlog after ATH-919.
* **Vertical-specific vs generic SDK tension.** Aidan 2026-04-24:
  before shipping a platform-requested primitive, audit "does it
  serve all current + plausible customers?" Rename vertical-specific
  fields → generic. Push back with a redesign before merging.

### 7.e What this doc replaces

This file is a full rewrite of the 2026-04-19 platform draft. The
old draft's V1/V2 partition closed 2026-04-25 with the ATH-337 IP
partition; the customer-deliverable enterprise SDK is now the live
state, not a future state. The original draft is in
`git log -p docs/sdk-roadmap.md` if needed for archaeology.

_End of roadmap._
