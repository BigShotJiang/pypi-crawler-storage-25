# Getting started with kairos

## Quick start (for agents and engineers)

Optimize an RTL block in one call:

```python
from kairos.sec.closed_loop.optimize_cli import optimize

result = optimize(
    rtl_path="path/to/your_block.sv",
    dep_paths=["path/to/dep1.v", "path/to/dep2.v"],  # optional
    param_overrides={"DATA_WIDTH": 8, "DEPTH": 4},    # optional
)

print(f"Halt: {result.halt_reason}")
print(f"Accepted: {result.n_accepted()}")
for s in result.iteration_summaries:
    print(f"  {s['outcome']}: {s['claimed_area_delta_pct']}%")
```

Or via MCP (for agent-to-agent use):

```
kairos_optimize(rtl_path="your_block.sv", params="DATA_WIDTH=8,DEPTH=4")
```

What happens automatically:
- Clock/reset detection from port names
- Parameter extraction and concrete override
- Synthesis baseline measurement (yosys)
- Multi-model proposer generates optimization candidates
- Pre-verification gates reject cosmetic/zero-delta proposals
- Dual-engine formal verification (yosys equiv for combo, EBMC for sequential)
- Area + toggle-power measurement on verified results
- Results saved permanently with sha256 provenance chain

No manual signature.json needed. No bundle creation. One call.

## Full onboarding guide

This guide walks an engineer at a hardware-verification team through running kairos on their first RTL block. If you reached this page from `kairos doctor` output or from a teammate's link, you're in the right place.

By the end, you will have:

1. A working kairos install with license configured.
2. A first optimization run that produces a customer-block-certificate.
3. Trace data on the dashboard so you can audit what kairos verified.

## 1. Install

The PyPI distribution name is `athanor-sdk`. The Python import name is `kairos`. Install the dist:

```sh
pip install athanor-sdk
```

> **Banner warning**: do NOT run `pip install kairos`. There is an unrelated package on PyPI under that name (a date/time utility). It will install successfully and then `from kairos.sec import ...` will fail with `ModuleNotFoundError: No module named 'kairos.sec'`. Always install with the dist name `athanor-sdk`. Tracked under issue ATH-447 (PyPI rename held pending token rotation).

If you hit `ModuleNotFoundError: No module named 'kairos._scoring_impl'` after install, your wheel build did not include the compiled Cython extension. Reinstall with:

```sh
pip install --force-reinstall --no-cache-dir athanor-sdk
```

Tracked under ATH-1066. The fix is in flight; the workaround above is reliable in the meantime.

## 2. First-run health-check

Run the diagnostic:

```sh
kairos doctor
```

Expected output (truncated):

```
kairos doctor - health check report
  ✓ python: 3.10+
  ✓ kairos.sec.closed_loop importable
  ✓ EBMC binary: /usr/local/bin/ebmc (v5.x)
  ✓ License: configured (or: KAIROS_DEV_NO_LICENSE=1 dev-bypass active)
  ✓ Sink routing: SUPABASE_URL + ATHANOR_SYNC_TOKEN set; trace lands at tahoe.athanor-ai.com
  ✓ All checks passed.
```

If you see failures, jump to **Common failure modes** (section 8).

### License configuration

Two paths:

- **Dev-eval mode** (no license required): set `KAIROS_DEV_NO_LICENSE=1` in your shell. This bypasses the license check entirely. Customer-block-certificates minted under this mode disclose the dev-bypass in the cert prose for self-audit reproducibility (same shape as the v2.7 demo carry-forward).
- **Production**: set up your license file at `~/.athanor/license.json` (your sales contact provides the file). `kairos doctor` confirms the license is loaded.

For an evaluation engineer running first-time onboarding, dev-eval mode is the right choice. Production mode is for the deployed kairos in your team's CI / regression flow.

### Sink routing

kairos emits trace events to Supabase by default; the dashboard at `tahoe.athanor-ai.com/analytics/silicon-blocks/<run_id>` renders them. Two env vars control routing:

- `SUPABASE_URL` and `ATHANOR_SYNC_TOKEN`: required for trace upload.
- `KAIROS_NO_TRACE=1`: opt-out (local-only mode; no upload, no dashboard).

Most engineers run with sink routing on so they can share dashboard URLs with teammates. Local-only mode is for offline evaluation or compliance scenarios where trace data must not leave the engineer's machine.

## 3. Bundle anatomy

A kairos closed-loop run takes a *bundle directory* as input. The directory contains:

```
my_block/
├── inputs/
│   └── gold.sv             ← Your reference RTL (the implementation kairos optimizes).
├── signature.json          ← Module metadata (ports, parameters, reset semantics).
├── demo_driver.py          ← Entry-point invoking the closed-loop pipeline.
└── build-tarball.sh        ← Pre-flight gates + tarball mint after the run.
```

The `signature.json` is the most important file. It declares:

- `target_module`: the SV module name kairos optimizes.
- `gold_sv`: relative path to the gold-side RTL.
- `ports`: name + direction + width for every interface signal. Parameterized widths (e.g. `DATA_WIDTH-1:0`) preserved as expressions.
- `parameters`: the override-able parameters and their concrete values for the SEC run.
- `clock_port` + `reset_port` + `reset_active_low`: clocking semantics. Inferred from `posedge clk` / `negedge reset_n` patterns or from port names if the module uses flop-primitive instantiations.
- `is_combinational` (optional): set to `true` for purely combinational blocks. Drives `ebmc_bound: 0` + `bmc_combinational` mode.
- `formal_invariants_primer` (optional, recommended when present): pre-existing formal-verification invariants from your team. kairos's LLM proposer reads these in the user prompt as a starter set, so the closed-loop extends your existing formal flow rather than re-inventing.

You can author `signature.json` by hand for your first block, or generate it from the RTL automatically with:

```sh
kairos signature-gen path/to/gold.sv -o my_block/signature.json
```

## 4. Bundle anatomy reference (signature.json schema)

For an engineer authoring `signature.json` by hand, the canonical schema:

```json
{
  "target_module": "my_fifo",
  "gold_sv": "inputs/my_fifo.v",
  "gate_v": null,
  "block_class": "fifo",
  "ports": [
    {"name": "din",     "direction": "input",  "width": "DATA_WIDTH"},
    {"name": "dout",    "direction": "output", "width": "DATA_WIDTH"},
    {"name": "push",    "direction": "input",  "width": 1},
    {"name": "pop",     "direction": "input",  "width": 1},
    {"name": "full",    "direction": "output", "width": 1},
    {"name": "empty",   "direction": "output", "width": 1},
    {"name": "clk",     "direction": "input",  "width": 1},
    {"name": "reset_n", "direction": "input",  "width": 1}
  ],
  "parameters": [
    {"name": "DATA_WIDTH", "default": 32, "concrete_for_sec": 32},
    {"name": "FIFO_DEPTH", "default": 0,  "concrete_for_sec": 4, "must_override": true}
  ],
  "clock_port": "clk",
  "reset_port": "reset_n",
  "reset_active_low": true,
  "formal_invariants_primer": [
    {
      "name": "inv_full_implies_eq",
      "kind": "ASSERT_IMPL",
      "antec": "full",
      "cons": "push_ptr == pop_ptr",
      "source_line": 142,
      "intent": "Push and pop pointers coincide when the FIFO is full"
    }
  ]
}
```

Field reference:

| Field | Required | Notes |
|-------|----------|-------|
| `target_module` | yes | Must match the `module <name>` declaration in the gold RTL. |
| `gold_sv` | yes | Relative path from the bundle dir to the gold RTL file. |
| `gate_v` | no | Pre-built gate-side Verilog if you have one; otherwise null and kairos's proposer generates candidates. |
| `block_class` | no | One of `fifo` / `combinational_alu` / `combinational` / `generic`. Hint to the proposer about reasonable transformation classes. |
| `ports` | yes | Width is either an int (for bare bit-widths) or a string (for parameterized widths preserved as expressions). |
| `parameters` | yes | Each parameter has `default` from the RTL plus `concrete_for_sec` for the SEC run. `must_override: true` is for parameters that have no usable default (e.g. depth=0 sentinels). |
| `clock_port` | no | Null for combinational blocks. |
| `reset_port` | no | Null for combinational blocks. |
| `reset_active_low` | no | True for `_n`-suffix reset names. |
| `is_combinational` | no | When true, kairos uses `ebmc_bound: 0` + `bmc_combinational` mode. |
| `formal_invariants_primer` | no | List of invariants from your existing formal flow. Each entry has `name` + `kind` (one of ASSERT_NEVER / ASSERT_ALWAYS / ASSERT_IMPL) + `expr` (or `antec`+`cons` for ASSERT_IMPL) + `source_line` + `intent`. |

The auto-generator at `kairos signature-gen` produces this exact shape from any well-formed Verilog-2001 / SV-2017 module.

## 8. Common failure modes + diagnostics

### `ModuleNotFoundError: No module named 'kairos._scoring_impl'`

The Cython extension wasn't compiled into your wheel. Reinstall:

```sh
pip install --force-reinstall --no-cache-dir athanor-sdk
```

If the reinstall produces the same error, your build environment lacks Cython. Install it explicitly:

```sh
pip install cython>=3.0 setuptools>=60
pip install --force-reinstall --no-cache-dir athanor-sdk
```

Tracked under ATH-1066.

### `ModuleNotFoundError: No module named 'kairos.sec'`

You installed the wrong PyPI package. The unrelated `kairos` package (a date/time utility) does not have `kairos.sec`. Fix:

```sh
pip uninstall -y kairos MonthDelta
pip install athanor-sdk
```

### `kairos doctor` reports license check failed

Either set `KAIROS_DEV_NO_LICENSE=1` for evaluation mode, or place your production license file at `~/.athanor/license.json`. Your sales contact provides the license file.

### Sink routing reports "trace not landing on tahoe"

Verify both env vars are set:

```sh
echo $SUPABASE_URL
echo $ATHANOR_SYNC_TOKEN
```

If either is empty, trace upload is disabled and the dashboard URL won't render anything. Set them in your shell rc file or via `direnv`.

For local-only mode (intentionally not uploading), set `KAIROS_NO_TRACE=1` instead. Then `kairos doctor` confirms local-only is active.

### `signature-gen` emits an empty `formal_invariants_primer`

The generator parses `formal_sst_verif_only` ifdef blocks. If your team uses a different ifdef name for formal-only assertions (e.g. `FORMAL_ONLY` / `FV_ASSERTS`), the generator won't see them. Two paths:

- Add the invariants by hand to `signature.json` after running the generator.
- Open an issue under ATH-1063 with the ifdef name your team uses; the generator will accept a configurable list.

### `signature-gen` fails to detect clock + reset on a block that uses flop-primitive instantiations

The generator's two-tier detection: tier 1 looks for inline `always @(posedge clk)` / `negedge reset_n`; tier 2 falls back to the port name (assuming `clk` / `reset_n` ports → sequential block).

If your block has neither inline always-blocks nor standard `clk` / `reset_n` port names, tier 2 fails and the generator marks the block as combinational. Override by editing `signature.json`:

```json
{
  "is_combinational": false,
  "clock_port": "your_clk_name",
  "reset_port": "your_rst_name",
  "reset_active_low": true
}
```

## Cross-refs

- License + auth: pending Phase 0c license-server (ATH-1063).
- MCP integration: pending Phase 0a-wiring (ATH-1063); `kairos.mcp` server entry-point + tool surface for engineer-as-customer use from Claude Desktop / Cursor / Cline.
- First closed-loop run example: pending ATH-1062 Phase 1 mint (post-Phase-0a + Phase-0b + Phase-0c assembly).
- Reading a customer-block-certificate: pending Phase 1 + Phase 2 mints; will reference the v2.7 toy_fifo_chain cert as the structural template.
- Worked examples: pending ATH-1062 close (three Annapurna basic_cells production blocks).
