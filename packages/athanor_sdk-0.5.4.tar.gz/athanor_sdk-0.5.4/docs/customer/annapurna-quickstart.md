# Annapurna PureRTL quickstart

How to run formal-equivalence verification on your own SystemVerilog
block. End-to-end on your runner, on your file, with your spec.

The pipeline:

```
your_block.sv          (the block you want to verify)
    +
your_spec.lean         (the property you want to prove, in Lean)
    |
    | manually-bridged Clash gate (your_spec.hs)
    v
clash codegen          (regenerated SV from the Clash gate)
    +
EQY                    (formal-equivalence prover)
    v
discharged / refuted / gated
```

You run all four stages on your runner. Athanor ships the
orchestration; you bring the SV + the spec + the runner.

## Prerequisites

- Linux runner (tested on Ubuntu 22.04).
- Python 3.10 or later.
- A SystemVerilog block you want to verify, plus any peer-reviewed
  formal properties you have on it (those become the Lean spec).

## Step 1: Install the SDK

```bash
pip install athanor-kairos
```

Verify the install:

```bash
kairos --version
kairos doctor
```

## Step 2: Install the PureRTL toolchain

```bash
bash scripts/install-purertl-toolchain.sh
```

This installs Yosys (built from source for EQY compatibility), GHC
plus cabal, Clash, and EQY. Plan for 30 to 90 minutes for the
first-time install; the cabal step alone takes 15 to 20 minutes on
a fast runner.

The script is idempotent. Re-running skips already-installed
components. Output is teed to `/tmp/purertl-toolchain-install.log`
for post-hoc debugging.

When the script finishes, verify:

```bash
yosys-config --version
clash --numeric-version
eqy --version
```

## Step 3: Lay out your block

The `examples/customer/toy_fifo_chain/` directory in the SDK is the
reference layout. Copy it as a template:

```bash
cp -r examples/customer/toy_fifo_chain/ examples/customer/your_block/
cd examples/customer/your_block/
```

Replace `toy_fifo_chain.sv` with your own SV. Keep the directory
structure:

```
your_block/
  your_block.sv             (your SV; this is the "gold")
  spec/
    YourBlock.lean          (your Lean source-of-truth contract)
    README.md               (trust-shift narrative + bridge audit)
  clash_gates/
    YourBlock.hs            (manually-bridged Clash gate)
    cabal.project + .cabal  (build config)
  pipeline_run.py           (mechanical pipeline analyzer)
  discharge_obligations.py  (per-widget EQY discharge orchestrator)
```

## Step 4: Write the Lean spec

Open `spec/YourBlock.lean`. Follow the Mealy-machine convention:

```lean
namespace YourBlock

structure REG where
  -- registers in your block; one field per
  deriving Repr

structure Input where
  rst       : Bool   -- canonical-sense reset; SV rst_n is inverted at boundary
  -- one field per input port
  deriving Repr

structure Output where
  -- one field per output port
  deriving Repr

def init : REG := { ... }

def step (reg : REG) (inp : Input) : REG × Output :=
  -- step function: pure F : (REG, Input) -> (REG, Output)
  ...

end YourBlock
```

The Lean spec is the customer-auditable contract. Anyone reading it
should be able to see exactly what the block does, without reading
Haskell or SystemVerilog.

The reference example at `examples/customer/toy_fifo_chain/spec/FifoWidget.lean`
shows the full shape for a ring-buffer FIFO.

## Step 5: Bridge the Lean spec to Clash

Open `clash_gates/YourBlock.hs`. Mirror the Lean spec one-to-one:

```haskell
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE NoImplicitPrelude #-}

module YourBlock where

import Clash.Prelude
import Clash.Annotations.TopEntity
import Clash.Signal (unsafeFromActiveLow)

topEntity
  :: Clock System
  -> Signal System Bool      -- rst_n (active-low; inverted to canonical reset inside)
  -> Signal System Bool      -- (your input ports)
  -> ...
  -> ( Signal System ...     -- (your output ports)
     , ...
     )
topEntity clk rst_n ... = (...)
  where
    rst = unsafeFromActiveLow rst_n
    -- rest of body matches your Lean step function

{-# ANN topEntity
  (Synthesize
    { t_name   = "your_block"     -- must match SV module name
    , t_inputs = [ PortName "clk", PortName "rst_n", ... ]
    , t_output = PortProduct "" [ PortName "out_a", ... ]
    }
  ) #-}
```

The Synthesize annotation is what tells Clash to emit Verilog with
port names matching your SV. Without it, Clash auto-names ports and
EQY can't pair them with the SV gold.

The bridge is auditable by inspection. Anyone reading the Lean spec
plus the Clash gate side-by-side should be able to confirm they
encode the same behavior. The `examples/customer/toy_fifo_chain/spec/README.md`
includes a step-by-step bridge audit table.

## Step 6: Run the mechanical pipeline

```bash
python3 pipeline_run.py
```

Outputs:

- `dataflow_graph.md`: per-path dataflow graph + per-widget
  classification (FORWARDS / MODIFIES).
- `obligations.json`: machine-readable per-widget obligation list.
- `certificate_stub.md`: per-path certificate language ready for
  human review.

These three files are the customer-facing deliverable. The
mechanical pipeline does not run any prover yet; it enumerates what
needs to be proved and classifies how.

## Step 7: Run the discharge

```bash
python3 discharge_obligations.py
```

The discharge orchestrator:

1. Compiles the Clash gate to Verilog.
2. Runs the SystemVerilog preprocessor (struct flattening +
   function inlining; required for Yosys / EQY to parse customer
   SV).
3. For each obligation, invokes EQY (Yosys equivalence prover) on
   `(gold = your_block.sv, gate = clash-emitted-verilog)`.
4. Updates `obligations.json` per-obligation with one of:
   - `discharged_against_handauthored_clash`: EQY proved
     equivalence.
   - `refuted_by_eqy`: EQY found a counter-example. The SV gold and
     the Clash gate are not equivalent. This is the
     no-fake-certificate signal: a counter-example trace is
     attached for inspection.
   - `gated_on_yosys_sv_parse`: Yosys could not parse the input
     after flattening. File a bug; share the output of
     `discharge_obligations.py --debug-flatten`.
   - `gated_on_temporal_verifier`: this obligation is a temporal
     property, not a combinational equivalence. EQY is the wrong
     tool; the bounded-model-checker entry point (separate
     SDK call) is the right verifier.
   - `extraction_failed`: Clash compile or EQY invocation crashed.
     File a bug.

## Step 8: Read the certificate

`certificate_stub.md` is the customer-facing artifact. Each path in
your design has its own certificate language explaining what is
being claimed and what is gated on what. The honest framing is
central to the contract: a `refuted` obligation surfaced to the customer is
better than a fake `discharged` swallowing the counter-example.

A typical clean run looks like:

```
Path A: 3 obligations discharged_against_handauthored_clash
Path B: 1 obligation gated_on_temporal_verifier (correctly classified)
Path C: 0 obligations (no transforms on this path)
```

A run with real refute looks like:

```
Path A: 2 obligations discharged_against_handauthored_clash
Path A: 1 obligation refuted_by_eqy
  -> counter-example: cycles 0..3 push 0xFF, cycle 4 pop returned 0x00
  -> action: the Lean spec or the Clash bridge does not match the
     SV gold; reconcile or accept that the design has a bug
```

## Step 9: View the dashboard

If you have an `ATHANOR_SYNC_TOKEN`, every `discharge_obligations.py`
run uploads its trace to the Athanor dashboard. The
customer-block certificate card on the Athanor dashboard at `https://athanor-ai.com/analytics`
renders the per-path discharge counters with click-through to the
counter-example traces.

Without a token, the SDK runs locally with no network calls
(zero phone-home).

## Common issues

- *"Yosys can't parse my SV."* The toolchain ships a struct-and-function
  flattening preprocessor that handles most common patterns. If it
  doesn't handle yours, run with `--debug-flatten` and file the output
  with us. Yosys SystemVerilog support is a known frontier.
- *"My Lean spec compiles but the bridge to Clash is non-trivial."*
  Start with the count-only simplification (omit registers in v0;
  pure passthrough). Get one obligation discharged. Then iterate
  toward the faithful spec. The `toy_fifo_chain` example shows the
  v0-then-faithful arc.
- *"EQY says refuted but I think the SV is correct."* That is the
  no-fake-certificate signal working. Read the counter-example
  trace; usually either the Lean spec is over-specified or the
  Clash bridge is missing a state register.

## Reference

- `examples/customer/toy_fifo_chain/`: the canonical reference
  block. Mirror the directory layout for your own block.
- `examples/customer/toy_fifo_chain/spec/README.md`: bridge audit
  conventions + trust-shift narrative.
- `examples/pure-rtl-roundtrip/Spec.lean`: the methodology
  precedent (cpu_adder demo).
- `scripts/install-purertl-toolchain.sh`: the toolchain installer.
