# Athanor SDK doc index

Pick the doc that matches your goal. Free-tier docs are in green, paid-tier in 🔒.

## I want to...

### Prove a property of my code in plain English (free tier)

→ [`free-tier-quickstart.md`](free-tier-quickstart.md)

Five-minute setup. `pip install`, then `simple_prove_template("prove c_vector_sharp is positive")`. No license required. No Lean files written by hand.

### Understand what's in free vs paid

→ [`sdk-tier-model.md`](sdk-tier-model.md)

Source-of-truth doc covering exactly which APIs are free vs paid, what `kairos.simple_prove` covers, what triggers the license gate.

### 🔒 Set up a paid-tier license

→ [`license-schema.md`](license-schema.md), [`enterprise-deployment.md`](enterprise-deployment.md)

Schema reference for `~/.athanor/license.json` + the install path enterprise customers receive. Paid customers also get operational runbooks with their install tarball.

### Understand what the SDK defends against

→ [`security-model.md`](security-model.md)

Threat-model table covering forged license, expired license, stolen license file, license sharing, revocation, audit-log tampering, network-attached bypass. with current defense + future plan per row.

### See where the SDK is going

→ [`sdk-roadmap.md`](sdk-roadmap.md)

What's shipping in v1.0, v1.1, v2.

### 🔒 Verify RTL designs (paid tier)

→ [`enterprise-deployment.md`](enterprise-deployment.md), [`sdk-solve.md`](sdk-solve.md)

Paid-tier `kairos.sv.*` stack via EBMC. `prove`, `cegar`, `swarm`, `invariants`. Operational depth ships with the enterprise install tarball.

### Verify Lean 4 proofs directly (free tier)

→ [`kairos-lean-lake-project-mode.md`](kairos-lean-lake-project-mode.md)

`kairos.verify_proof` for raw Lean source + how to wire `lake` so larger projects build.

### Build a custom task

→ [`task-builder.md`](task-builder.md)

Customer task definition + scoring conventions.

### Inspect my license-gate audit log

```bash
kairos audit show --since 7d --denied
```

Lives at `~/.athanor/audit.jsonl`. See `kairos audit show --help` for filters.

## Reference

| What | Where |
|---|---|
| Public API surface | `from kairos import ...`. see top-level `__init__.py` exports |
| `~/.athanor/license.json` schema | [`license-schema.md`](license-schema.md) |
| Spec / pipeline / observability internals | [`internal/`](internal/) |

## Internal

[`internal/`](internal/). design memos, post-mortems, decision logs. Not required reading for customers; useful for contributors and SDK maintainers.

## Paid customer extras

Paid customers receive operational deep-dives (orchestrator internals, vertical-specific tactics, debugging runbooks) bundled with their enterprise install tarball. Those don't live in this public repo by design. IP partitioning is documented in [`internal/ip-partitioning.md`](internal/ip-partitioning.md).

## Where to file questions / bugs

- **Bugs**: https://github.com/athanor-ai/athanor-sdk/issues
- **Security**: `aidan@athanorl.com` with subject `[Security] ...`
- **Sales / paid-tier**: `aidan@athanorl.com`
