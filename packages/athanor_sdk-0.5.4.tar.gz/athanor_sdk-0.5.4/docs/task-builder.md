# Task Builder

The Task Builder lets you create new tasks for an Athanor environment without
writing code by hand. You describe the task in natural language through the
Athanor web UI, and Opus 4.6 generates the config, stub, reference solution,
and proof template (if applicable).

**The entire build happens on your machine.** Opus is called with your
Anthropic API key. The generated files are written into your local env
checkout. Nothing except validation metadata (the task slug and its validation
scores) is reported back to the Athanor platform. The task content - the
config, stub, reference, and proof - stays exclusively on your machine.

## Before you can use the builder

You need three things on the VM where your runner will run:

### 1. An extracted env tarball

Download the env tarball from the Athanor platform (Environments → your env →
Download) and extract it somewhere the runner can find it. By default the
runner looks under `~/athanor-envs/<env_slug>/`.

```bash
mkdir -p ~/athanor-envs
tar xzf ~/Downloads/computational-biology.tar.gz -C ~/athanor-envs
# Make sure the directory ends up named exactly as the env slug:
ls ~/athanor-envs/computational-biology/
# → Containerfile  LICENSE  README.md  root_data/  student_data/  ...
```

If you want to put env checkouts somewhere else, set `ATHANOR_ENV_DIR` to the
base directory:

```bash
export ATHANOR_ENV_DIR=/opt/athanor-envs
mkdir -p $ATHANOR_ENV_DIR
tar xzf computational-biology.tar.gz -C $ATHANOR_ENV_DIR
```

The runner will look for `$ATHANOR_ENV_DIR/<env_slug>/` when a build job
arrives.

### 2. An Anthropic API key

The runner uses your Anthropic API key to call Claude Opus 4.6 for task
generation. Export it before starting the runner:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

The key never leaves your machine. The Athanor platform never sees it.

### 3. Docker (or Podman) and a runner process

The runner needs Docker to rebuild the env image after generating a new task.
Make sure `docker` (or `podman`) is installed and accessible.

Install the SDK and start the runner:

```bash
pip install athanor-ai
athanor run --token <your-athanor-token>
```

Leave the runner running. It polls the platform every few seconds for queued
jobs.

## How to build a task

1. Open the Athanor platform web UI (`tahoe.athanor-ai.com`) in your browser.
2. Navigate to **Build Task**.
3. Pick your target environment, fill out the form:
   - **Task name** - human-readable name; the slug is derived from this
   - **Description** - natural-language description of what the task does
   - **Difficulty** - easy, medium, hard
   - **Category** - bug_fix, implementation, verification, optimization, translation
   - **Proof backend** - lean, dafny, verus, ebmc, or none
   - **Scoring type** - property_tests, simulation, compilation, output_match
4. Click **Build**.
5. The web UI queues a `build` job in your org's work queue and starts polling
   for the result.
6. Your runner picks up the job within a few seconds. Watch its logs - you'll
   see messages like:

   ```
   Job abc12345: build on computational-biology
     Env checkout: /home/you/athanor-envs/computational-biology
     New task slug: fix_sodium_channel_kinetics
     Using example task: fix_gating_bug
     Wrote 4 files to /home/you/athanor-envs/computational-biology
     Rebuilding image computational-biology from /home/you/... (may take 1-2 minutes)...
     Validation: stub=0.01, reference=0.94, passed=True
     Build: fix_sodium_channel_kinetics (passed=True, stub=0.01, ref=0.94)
   ```

7. If the build succeeds, the UI shows the validation scores and tells you
   where the files live on disk. If it fails (Opus generated something
   unparseable, stub accidentally solved the task, slug collision, etc.), the
   UI shows the error and no files are written.

## Using your new task

Once the build succeeds, the new task is a real task in your local env
checkout at these canonical paths:

```
~/athanor-envs/<env>/root_data/eval/configs/<slug>.json
~/athanor-envs/<env>/student_data/<slug>.py            (or .dfy, .lean, etc.)
~/athanor-envs/<env>/root_data/eval/references/<slug>.py   (if the env has a references/ dir)
~/athanor-envs/<env>/root_data/eval/proofs/<slug>.lean     (if a proof backend was selected)
```

You can edit these files directly - tweak the description, adjust the scoring
parameters, tighten the reference solution. They're plain files in a plain
directory.

To run evals against your new task, point `evaluate.py` at your local env
checkout:

```bash
cd ~/athanor-envs/computational-biology
python3 scripts/evaluate.py . --tasks fix_sodium_channel_kinetics \
  --model anthropic/claude-sonnet-4-6 \
  --output runs/claude-sonnet-4-6_custom.json
```

Or use the Athanor platform to queue a normal `solve`/`evaluate` job - the
runner will execute it against the same local checkout, so it'll see your
custom task alongside the built-in ones.

## What the runner actually does under the hood

When the runner claims a `build` job, it runs through these steps in order.
If any step fails, the runner aborts, reports the error back to the platform,
and (where possible) rolls back any files it wrote.

### 1. Resolve the local env checkout

The runner computes `$ATHANOR_ENV_DIR/<env_slug>/` (default:
`~/athanor-envs/<env_slug>/`) and checks that the directory exists. If not,
the build fails immediately with a clear error telling you where to extract
the tarball.

### 2. Normalize the task slug

Your task name is lowercased and non-alphanumeric characters are collapsed
to `_`. `"Fix Delayed ACK Bug"` becomes `fix_delayed_ack_bug`. The
slug is used as the task_id and as the filename stem for all generated files.

### 3. Pick a few-shot example

The runner reads one existing task from the env checkout to use as a template.
It picks the alphabetically-first config in `root_data/eval/configs/*.json`
and reads the matching stub, reference (if any), and proof template (if any).
This gives Opus a concrete example of what a correctly-shaped task in this env
looks like.

### 4. Collision check

The runner computes the target paths for the new task and fails if any of
them already exist. This prevents accidental overwrites of built-in tasks or
previously-built custom tasks. Pick a different task name if you get a
collision error.

### 5. Build the Opus prompt

The runner constructs a generation prompt that includes:
- The full contents of the example task (config, stub, reference, proof)
- Your task description and metadata from the web form
- Explicit instructions to match the example's file layout and style
- A required output format: fenced code blocks with `name=<filename>` labels

### 6. Call Opus 4.6

The runner sends the prompt to the Anthropic API at `/v1/messages` using your
`ANTHROPIC_API_KEY` (or `ANTHROPIC_BASE_URL` if set). Opus 4.6 is the only
model used for task generation. Your key never leaves your machine - it goes
straight from the runner to Anthropic's API.

### 7. Parse the response

The runner extracts fenced code blocks from Opus's response by their `name=`
label: `config.json`, `stub.py` (or `.dfy`/`.lean`/etc.), `reference.py`,
`proof.lean`. If any required file is missing, the build fails with an error
showing what Opus produced.

### 8. Write files to canonical paths

The runner writes each extracted file to its canonical location in the env
checkout, mirroring the directory layout of the example task. The config's
`task_id` and `student_file` fields are rewritten to match the new slug in
case Opus used the example's slug by mistake.

If writing any file fails partway through, the runner deletes every file it
already wrote so you're not left with a half-built task.

### 9. Rebuild the Docker image

The runner runs `docker build -f Containerfile -t <image_name> <env_dir>` to
rebuild the env container with the new task baked in. This is needed because
the validation step runs scoring inside the container, and the container has
to have the new files to score them.

Rebuild time depends on how much of the image is cached. First-time builds
can take 10+ minutes for envs with large dependencies (Dafny, Lean, etc.).
Cached incremental builds are usually 1-2 minutes. This is the slowest step
in the build flow.

### 10. Validate the stub

The runner runs the scorer against the generated stub file. The stub should
score near zero (specifically, the runner requires `stub_score < 0.1`). If
the stub accidentally solves the task, the build is marked as failed - a
useful stub should leave the problem unsolved so there's room for a student
agent to improve it.

### 11. Validate the reference (if present)

If the example env had reference solutions, the runner scores the generated
reference too. It must score greater than 0.5. A reference that doesn't
actually solve the task is a broken task - Opus hallucinated, and the build
is marked as failed.

Envs without a reference directory (like `congestion-control-sample`, which
validates by running a simulator directly) skip this step.

### 12. Report metadata back to the platform

The runner POSTs to `/api/runner/results` with only this payload:

```json
{
  "job_id": "abc...",
  "status": "completed",
  "result": {
    "task_slug": "fix_delayed_ack_bug",
    "env_slug": "congestion-control-sample",
    "validation": {
      "stub_score": 0.01,
      "reference_score": null,
      "passed": true
    }
  }
}
```

**Nothing else is sent.** No file contents. No description. No config. No
stub. No reference. Just the slug and the validation scores. The platform
updates the `runner_jobs` row with this result so the UI can display "build
succeeded, task `fix_delayed_ack_bug` is now on your runner" - but the
platform never sees the content of the generated task.

## Failure modes

**"Local env checkout not found at ..."**
Your env tarball isn't extracted to the expected location. Extract it to
`~/athanor-envs/<env_slug>/` or set `ATHANOR_ENV_DIR`.

**"Task slug ... collides with existing files"**
A task with the same slug already exists in your env checkout (either a
built-in or a previous custom build). Pick a different task name.

**"ANTHROPIC_API_KEY required for build jobs"**
Export `ANTHROPIC_API_KEY` in the shell where you started the runner, then
restart the runner.

**"Opus response missing required `config.json` fenced block"**
Opus didn't follow the output format. Re-queue the build - usually transient.
If it keeps happening, try a more specific description.

**"Opus did not generate required files: ['reference']"**
Same as above but for a missing reference or stub. Re-queue.

**"Docker build failed: ..."**
The rebuild step failed. Check the error tail in the runner logs. Common
causes: syntax errors in the generated files, missing dependencies, stale
Docker cache. Try `docker system prune` if cache corruption is suspected.

**"Validation: stub=0.4, ..., passed=False"**
The stub accidentally solved the task. The generated stub isn't actually a
good starting point for a student agent. The files are still written to
disk so you can inspect and edit them manually, but the platform will mark
the build as failed.

**"Validation: reference=0.2, ..., passed=False"**
The generated reference solution doesn't actually solve the task. Opus
hallucinated a wrong answer. Files are written to disk for inspection.

## Configuration summary

| Env var | Default | Purpose |
|:-|:-|:-|
| `ATHANOR_ENV_DIR` | `~/athanor-envs` | Base directory where env checkouts live |
| `ANTHROPIC_API_KEY` | (required) | Your key for calling Opus 4.6 |
| `ANTHROPIC_BASE_URL` | `https://api.anthropic.com` | Override for Azure-hosted Anthropic |
| `ATHANOR_TOKEN` | (required) | Runner auth token from the Athanor platform |

## What never happens

To be explicit about the privacy boundary:

- The runner does **not** upload the config, stub, reference, or proof to
  the platform.
- The runner does **not** upload the task description, category, difficulty,
  or any other form field from the build request. (The platform already has
  those - they were sent when you submitted the form.)
- The runner does **not** upload intermediate Opus responses, prompts, or
  token counts.
- The runner does **not** share task content with other customers or other
  runners. The files live on the machine that built them.
- The Athanor platform does **not** have a copy of your Anthropic API key
  or any other credential you set on the runner VM.

The only things that cross the boundary from runner → platform during a
build are:
1. Job claim + heartbeat (via `/api/runner/poll`)
2. Metadata-only completion report (via `/api/runner/results`) containing
   the task slug and the numeric validation scores.
