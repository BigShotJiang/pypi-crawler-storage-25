# Contributing to athanor-sdk

This file collects the small set of conventions every PR is expected
to follow. Each rule has a one-line rationale; if a rule blocks your
PR for a reason the rationale doesn't cover, raise it in the PR
discussion.

## Tests

### Test docstrings

Every `test_*` function should carry a one-line docstring describing
the contract it pins. Format:

```python
def test_kernel_refutes_on_signed_overflow():
    """`kernel(...)` rejects inputs that would overflow the signed
    32-bit accumulator: regression for the 2026-04-19 sign-error
    incident."""
    ...
```

Why: 72% of the 3959 SDK test functions lacked docstrings as of the
2026-05-02 ATH-929 audit. Without them, a failing test gives the
debugger no contract to compare against; the only signal is "X used
to pass, now X fails." A one-line contract is enough to make the
failure mode legible.

Enforcement: new PRs only. Existing tests opt in over time. CI does
not currently fail on missing docstrings; reviewers are encouraged
to flag.

### Integration marker

Tests under `tests/integration/` carry `@pytest.mark.integration`
automatically (via `tests/integration/conftest.py`). Use
`pytest -m "not integration"` for fast-loop local iteration.
Explicit `pytest -m integration` runs only the slow corpus.

CI default `pytest` runs everything (backwards-compatible). Fast
unit-only iteration is the contributor-side ergonomics win.

### Property-based testing

Hypothesis is under-utilized: only 8 of 229 test files use it as of
2026-05-02. New tests for **state machines, parsers, contract
checkers, and any code with non-trivial input shapes** should
prefer Hypothesis over hand-rolled examples. Target shape:

```python
from hypothesis import given, strategies as st

@given(st.integers(min_value=0, max_value=255))
def test_kernel_handles_any_byte(x):
    """`kernel(x)` is total over `[0, 255]`: regression against
    the off-by-one on the boundary class."""
    ...
```

Set `min_examples` and a deterministic `seed` for state-machine
tests so the reproduction shrinks consistently.

### Mock-the-subject discipline

A test that patches `kairos.<module>` from inside that module is
mocking the subject under test, which violates the contract that
the test asserts the module's real behavior. Use
`@pytest.mark.faking_subprocess` (per ATH-521) only for legitimate
fault-injection (e.g. simulating subprocess timeouts).

20 SDK test files were identified as "mock-the-subject suspects"
in the 2026-05-02 audit; new PRs should not add to that count.

## Code style

ruff handles formatting + lint. Pre-push hooks run the checks; CI
is the safety net.

## Customer-facing files

Customer-facing files (`README.md`, examples under
`examples/customer/`, `docs/`) go through `tools/md_lint.py` which
gates on:

* No em-dashes (U+2014) or en-dashes (U+2013) in prose
* No AI-fingerprint phrases (the linter has a current word list)
* No internal codenames (`ATH-NNN`, `kairos.*`, internal hostnames)
  in customer-visible prose

Run `python3 tools/md_lint.py path/to/file.md` before opening PRs
that touch customer-facing markdown.

## Cross-refs

* ATH-929 (test-quality audit + 6-point plan)
* ATH-521 (faking_subprocess marker for fault injection)
