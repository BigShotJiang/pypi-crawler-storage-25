"""Run the SV→Lean extraction demo on cpu_adder.

ATH-947 v0. Drives the two-gate LLM extractor end-to-end:

    cpu_adder.sv (original RTL)
        ↓ kairos.pure_rtl.lean_extractor.extract
    [LLM proposes Lean spec + Clash bridge]
        ↓ Gate 1: kairos.eqy.verify on Clash output vs original
        ↓ Gate 2: kairos.lean.verify_proof on customer properties
    Spec.lean (validated source-of-truth)

Customer properties for cpu_adder are minimal in v0: the same
``reset_clears_output`` theorem the hand-authored ``Spec.lean``
proves. The LLM-produced spec must support that property AND be
EQY-equivalent to the original SV.

When toolchain (Clash + EQY + Lake) or the Anthropic API key is
absent, the extractor returns verdict='error' or verdict='rejected'
cleanly. Install the toolchain via the platform-side spec to get a
real verdict.
"""
from __future__ import annotations

import sys
from pathlib import Path

from kairos.pure_rtl.lean_extractor import LeanProperty, extract


_CUSTOMER_PROPERTIES = [
    LeanProperty(
        name="reset_clears_output",
        statement=(
            "theorem reset_clears_output (reg : CpuAdder.REG) "
            "(inp : CpuAdder.Input) (h : inp.rst = true) : "
            "(CpuAdder.step reg inp).fst.s = 0 := by\n"
            "  simp [CpuAdder.step, h]"
        ),
    ),
]


def main() -> int:
    here = Path(__file__).parent
    result = extract(
        here / "cpu_adder.sv",
        _CUSTOMER_PROPERTIES,
        top_module="cpu_adder",
        workdir=here / ".extract-out",
        max_iterations=5,
    )

    print(f"Extraction verdict: {result.verdict}")
    print(f"  Iterations taken: {len(result.iterations)}")
    print(f"  Total elapsed: {result.elapsed_sec}s")
    if result.spec_lean_path:
        print(f"  Validated Spec.lean: {result.spec_lean_path}")
    if result.error_message:
        print(f"  Error: {result.error_message}")
    if result.iterations:
        last = result.iterations[-1]
        print("  Last iteration:")
        print(f"    gate1={last.gate1_verdict}")
        print(f"    gate2={last.gate2_property_verdicts}")
        if last.feedback_for_next_iter:
            preview = last.feedback_for_next_iter[:300]
            print(f"    feedback_preview={preview}")

    return 0 if result.extracted else 1


if __name__ == "__main__":
    sys.exit(main())
