# PureRTL round-trip demo (ATH-944 v0)

End-to-end round-trip on a small registered adder block. The pipeline:

```
Spec.lean   (Lean source-of-truth)
    │  manual bridge (v0)
    ▼
Spec.hs     (Clash)
    │  kairos.pure_rtl.clash_codegen.generate_sv
    ▼
regenerated cpu_adder.sv
    │  kairos.eqy.verify against cpu_adder.sv (the original)
    ▼
PROVED / REFUTED / UNKNOWN
```

This is the v0 customer-facing artifact for the PureRTL methodology
Todd designed in #project-annapurna 2026-05-01 (12:28). The block is
deliberately tiny. Every step of the loop is exercised end-to-end on
a design small enough that the Lean spec and Clash module can be
reviewed by inspection.

## Files

| File | What it is |
| --- | --- |
| `cpu_adder.sv` | The original (hand-written) RTL: the "spec" side of equivalence |
| `Spec.lean` | Lean source-of-truth: the contract the RTL implements |
| `Spec.hs` | Clash module mirroring `Spec.lean` (v0 manual bridge) |
| `run_demo.py` | Drives the round-trip orchestrator and prints the verdict |

## Run

```bash
python examples/pure-rtl-roundtrip/run_demo.py
```

The orchestrator logs the codegen verdict, the equivalence verdict,
and the total wall-clock. A successful run emits a
`pure_rtl_roundtrip_complete` trace event under your active
`kairos.observe()` / `kairos.session()` context.

## Toolchain

The orchestrator shells out to two real binaries:

* `clash`: Clash compiler (https://clash-lang.org/). Install via
  Stack or Cabal.
* `eqy`: YosysHQ EQY equivalence prover (Yosys ecosystem, ISC
  license).

When either binary is absent on `PATH`, the orchestrator returns
`codegen_failed` / `error` cleanly. The platform-side install for the
Tahoe runner is a separate ticket; this demo is designed to run on
any developer VM with both tools installed.

## What this demo proves (and doesn't)

**Proves:**

* That `Spec.hs` (the Clash bridge of `Spec.lean`) compiles to a
  SystemVerilog module that is sequentially equivalent to the
  hand-written `cpu_adder.sv`.

**Does not prove (yet):**

* That `Spec.hs` is faithful to `Spec.lean`. v0 is a manual bridge,
  by inspection. The automated Lean to Clash translation is a future
  ticket per asabi 2026-05-01 14:08.
* That arbitrary blocks round-trip cleanly. Larger blocks (FIFO,
  arbiter, payload-table) need the PureRTL pattern library, which is
  customer-driven and lands once the first round-trip is concrete.
* That LLM-extracted Lean models are usable. SV to Lean extraction is
  asabi's "riskiest hop" (12:29). Separate ticket once round-trip is
  working bidirectionally.

## What's next

If this demo lands cleanly:

1. Repeat on a real Customer-2 block (the toy CPU at
   `/tmp/todd-cpu/cpu_single_issue.sv` is the candidate, already
   proven via prior ATH-906 work, has `SI ≡ PIPE` properties).
2. File a follow-up for SV to Lean extraction (LLM-driven). With the
   round-trip closed, the LLM's job is to propose a Lean spec that
   makes `original_sv ≡ Clash(spec)`. EQY is the ground-truth gate.
3. File a follow-up for the optimization proposer. Once round-trip
   works, every payload-table / state-reduction / pipeline restructure
   can be proven in Lean before regenerating SV.
