-- Spec.hs — Clash module mirroring Spec.lean for the cpu_adder round-trip.
--
-- ATH-944 (PureRTL round-trip v0). This is the v0 *manual bridge* from
-- Lean to Clash; the automated Lean -> Clash translation is a future
-- ticket per asabi 2026-05-01 14:08.
--
-- The mapping from Spec.lean is mechanical:
--   * REG.s         <-> register `Signal dom (Unsigned 5)`
--   * Input.rst/a/b <-> three input signals
--   * Output.s      <-> output signal driven from the register
--   * step          <-> the `mealy` body below
--
-- Compile with:
--   clash --systemverilog Spec.hs -outputdir ./clash-out
--
-- Then EQY-verify the emitted SV against ../cpu_adder.sv via
-- kairos.eqy.verify.

{-# LANGUAGE DataKinds #-}
{-# LANGUAGE NoImplicitPrelude #-}

module Spec where

import Clash.Prelude

-- | Pure step function: REG -> Input -> (REG', Output).
--
-- This is the literal transcription of Spec.lean's `step`; if the
-- Lean source-of-truth changes, this function changes lock-step,
-- and EQY will catch any drift between Spec.hs and the SV impl.
step
    :: Unsigned 5
    -> (Bool, Unsigned 4, Unsigned 4)
    -> (Unsigned 5, Unsigned 5)
step regS (rst, a, b) =
    let s' = if rst then 0 else resize a + resize b
        out = regS
    in (s', out)

-- | Top entity: 1-bit reset + two 4-bit operands -> 5-bit sum.
{-# ANN topEntity
    (Synthesize
        { t_name = "cpu_adder"
        , t_inputs =
            [ PortName "clk"
            , PortName "rst"
            , PortName "a"
            , PortName "b"
            ]
        , t_output = PortName "s"
        }
    )
    #-}
topEntity
    :: Clock System
    -> Signal System Bool
    -> Signal System (Unsigned 4)
    -> Signal System (Unsigned 4)
    -> Signal System (Unsigned 5)
topEntity clk rst a b =
    withClockResetEnable clk
        (unsafeFromActiveHigh rst)
        enableGen
        (mealy step 0 (bundle (rst, a, b)))
