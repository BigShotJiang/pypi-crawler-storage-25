/-
  Spec.lean — Lean source-of-truth for the cpu_adder round-trip demo.

  ATH-944 (PureRTL round-trip v0).

  Methodology (Todd 2026-05-01 #project-annapurna): every block is
  a Mealy machine `step : (state, inputs) → (state', outputs)` over
  a register record `REG`. The Lean spec is the contract; Clash is
  the codegen target; EQY proves the regenerated RTL equivalent.

  This file documents the spec for `cpu_adder`. v0 is hand-bridged
  to `Spec.hs` (Clash) — the Lean → Clash automation is a future
  ticket per asabi 2026-05-01 14:08. The bridge is mechanical
  enough that a small audit by inspection suffices for v0.
-/

namespace CpuAdder

/-- Register state: just the output latch. -/
structure REG where
  s : UInt8  -- 5-bit sum lives here; UInt8 is the smallest convenient carrier
  deriving Repr, DecidableEq

/-- Inputs at one clock edge. -/
structure Input where
  rst : Bool
  a   : UInt8  -- 4-bit operand (high nybble unused)
  b   : UInt8  -- 4-bit operand (high nybble unused)
  deriving Repr

/-- Outputs at one clock edge. -/
structure Output where
  s : UInt8
  deriving Repr

/-- Initial register state at reset. -/
def init : REG := { s := 0 }

/--
  Step function: pure F : (REG, Input) → (REG, Output).

  Mirrors the behaviour of `cpu_adder.sv`:
  - `rst=1` → next-state s = 0
  - `rst=0` → next-state s = a + b (one-cycle latency)

  The combinational output mirrors the registered value, matching
  what the SV reads on `s` in the same cycle.
-/
def step (reg : REG) (inp : Input) : REG × Output :=
  let s' : UInt8 :=
    if inp.rst then 0
    else (inp.a &&& 0x0F) + (inp.b &&& 0x0F)
  ({ s := s' }, { s := reg.s })

/--
  Trivial structural property: after reset, the output latch is
  zero on the following cycle.
-/
theorem reset_clears_output (reg : REG) (inp : Input) (h : inp.rst = true) :
    (step reg inp).fst.s = 0 := by
  simp [step, h]

end CpuAdder
