"""Run the PureRTL round-trip demo on cpu_adder.

ATH-944 v0. This script drives the round-trip orchestrator end-to-end:

    Spec.lean (source-of-truth, by inspection)
        ↓ manual bridge
    Spec.hs   (Clash)
        ↓ kairos.pure_rtl.clash_codegen.generate_sv
    regenerated cpu_adder.sv
        ↓ kairos.eqy.verify against ../cpu_adder.sv
    PROVED / REFUTED / UNKNOWN

When the local toolchain (clash + eqy) is missing, the orchestrator
returns ``codegen_failed`` / ``error`` cleanly — no exception. Install
both via the platform-side toolchain spec to get a real verdict.
"""
from __future__ import annotations

import sys
from pathlib import Path

from kairos.pure_rtl.roundtrip import run_roundtrip


def main() -> int:
    here = Path(__file__).parent
    result = run_roundtrip(
        block_name="cpu_adder",
        clash_hs_file=here / "Spec.hs",
        original_sv=here / "cpu_adder.sv",
        top_module="cpu_adder",
        workdir=here / ".roundtrip-out",
    )

    print(f"Round-trip verdict for {result.block_name}: {result.verdict}")
    print(f"  Codegen success: {result.codegen.success}")
    if result.codegen.output_sv_file:
        print(f"  Regenerated SV: {result.codegen.output_sv_file}")
    if result.equivalence is not None:
        print(f"  Equivalence verdict: {result.equivalence.verdict}")
        print(
            f"  Properties: {result.equivalence.properties_proved} proved, "
            f"{result.equivalence.properties_refuted} refuted"
        )
    print(f"  Total elapsed: {result.total_elapsed_sec}s")

    return 0 if result.equivalent else 1


if __name__ == "__main__":
    sys.exit(main())
