// Original (hand-written) SystemVerilog for the round-trip demo.
//
// A 4-bit registered adder. Tiny on purpose: this example exists to
// demonstrate the full PureRTL round-trip pipeline end-to-end, not to
// flex any single tool. The Lean source-of-truth + Clash module + EQY
// equivalence check all target this exact RTL.
//
// Properties already proved against this design (live in the
// surrounding test corpus):
//   - reset clears `s` to zero on the next cycle
//   - in steady state, s == a + b (with one-cycle latency)
//
// ATH-944 (PureRTL round-trip v0).

module cpu_adder (
    input  wire        clk,
    input  wire        rst,
    input  wire [3:0]  a,
    input  wire [3:0]  b,
    output reg  [4:0]  s
);
    always @(posedge clk) begin
        if (rst)
            s <= 5'd0;
        else
            s <= a + b;
    end
endmodule
