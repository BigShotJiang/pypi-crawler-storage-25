// Telos Reno — k=10 reachability extension.
//
// Same RTL as TelosReno_patched.sv (Reno AIMD with cwnd_floor). Adds
// one multi-step reachability obligation, p_k10_growth_from_floor,
// that exercises EBMC's bounded reachability beyond the 1-step
// inductive arguments in the companion file. Paper §V.C threats
// addresses this directly: CUBIC+Reno close at k=1 by construction,
// but EBMC can still verify a non-trivial 10-cycle reachability
// property on the same module.
module reno_cca(
  input              clk,
  input              reset,
  input              ack,
  input              loss,
  output reg [7:0]   cwnd
);
  initial cwnd = 8'd1;

  always @(posedge clk) begin
    if (reset)
      cwnd <= 8'd1;
    else if (loss)
      cwnd <= (cwnd <= 8'd1) ? 8'd1 : (cwnd >> 1);
    else if (ack && cwnd != 8'hFF)
      cwnd <= cwnd + 8'd1;
  end

  // Safety: cwnd never underflows past 1 MSS.
  p_cwnd_ge_mss:
    assert property (@(posedge clk) !reset |=> cwnd >= 8'd1);

  // Multiplicative decrease on loss: cwnd after loss at most halves
  // of previous value (plus floor).
  p_cwnd_halves_on_loss:
    assert property (@(posedge clk)
      !reset && loss |=> cwnd <= ($past(cwnd) >> 1) + 8'd1);

  // Additive increase on ack under no-loss.
  p_cwnd_grows_on_ack:
    assert property (@(posedge clk)
      !reset && ack && !loss && cwnd < 8'hFF |=> cwnd == $past(cwnd) + 8'd1);

  // k=10 REACHABILITY obligation (the one this file exists for):
  // starting from cwnd==1 at some tick, ten consecutive (!reset && ack
  // && !loss) ticks drive cwnd to at least 11. Exercises bounded
  // reachability over ten composed transition steps, not a one-step
  // inductive invariant. Requires bound >= 11 for EBMC to close. Upper
  // bound would be 12 (cycle-0 ack is unconstrained, can add +1).
  p_k10_growth_from_floor:
    assert property (@(posedge clk)
      !reset && cwnd == 8'd1 ##1 (!reset && ack && !loss)[*10] |=> cwnd >= 8'd11);
endmodule
