# `athanor sv-invariants` on TelosReno (ATH-411)

Reverse-mutation-kill invariant discovery dogfood against the
bbr3-starvation-bench TelosReno spec. Demonstrates the full
proposer loop: enumerate mutants → run existing suite → for each
survivor, ask an LLM for a distinguishing invariant → vacuity-gate
→ progress-gate → accept or reject.

Canned run captured in [`canned_run.json`](./canned_run.json).

## What this shows

**Honest gate discipline.** The tool enumerated 30 RTL mutations
against `reno_cca` (bit-width flips, operator swaps, edge polarity
flips, blocking/non-blocking swaps, comment-line noise). The existing
3-assertion safety suite killed 3; 5 survived the 10-mutant cap.

For each surviving mutant, the stub proposer suggested a candidate
invariant. **All 5 were rejected** - not because the tool failed,
but because the survivors are either:

1. **Semantically equivalent** (comment-line flips, single-writer
   blocking/non-blocking swaps that EBMC treats as identical), or
2. **Redundant** with the existing suite (the proposer's suggestion
   `holds on original AND mutant`, so it doesn't distinguish).

That's the correct outcome for a tight spec: the tool refuses to
ship a no-op invariant disguised as coverage.

## Files

- `telos_reno_k10.sv` - TelosReno Reno CCA with 4 safety assertions
  (cwnd ≥ 1, multiplicative-decrease, additive-increase, k=10
  reachability). From `bbr3-starvation-bench/proofs/solve-runs/telos_reno/`.
- `canned_run.json` - captured output from the discovery run below.

## Run

```sh
athanor sv-invariants \
    --spec examples/sv-invariants-telos-reno/telos_reno_k10.sv \
    --top reno_cca \
    --bound 12 \
    --max-mutants 10
```

Or via the Python API:

```python
from athanor.sv.invariants import discover_invariants

result = discover_invariants(
    "examples/sv-invariants-telos-reno/telos_reno_k10.sv",
    top_module="reno_cca",
    bound=12,
    max_mutants=10,
)
print(f"surviving: {result.mutants_surviving}")
for p in result.proposals:
    if p.accepted:
        print(f"ACCEPTED: {p.candidate.assertion_sv}")
```

## Captured output (from `canned_run.json`)

```
enumerated:              30
killed by existing:       3
surviving (cap=10):       5
overall:                  NO_PROPOSALS
```

Per-proposal gate outcomes (all 5):

```
[REJECTED] target: flip_nonblocking_to_blocking @ line 21
  assertion holds on BOTH original AND mutant - no-op
  (blocking/non-blocking swap in reset init; EBMC treats equivalent)

[REJECTED] target: flip_nonblocking_to_blocking @ line 23
  assertion holds on BOTH original AND mutant - no-op
  (single-writer always_ff; no race, equivalent)

[REJECTED] target: flip_add_to_sub @ line 7 (comment-only)
  assertion holds on BOTH original AND mutant - no-op
  (mutation landed inside a comment; RTL behavior unchanged)

[REJECTED] target: flip_add_to_sub @ line 25
  assertion holds on BOTH original AND mutant - no-op
  (proposer's monotone-on-ack candidate is already implied by
   the original p_cwnd_grows_on_ack; not distinguishing)

[REJECTED] target: flip_sub_to_add @ line 48 (comment-only)
  assertion holds on BOTH original AND mutant - no-op
  (comment-line noise; no semantic change)
```

## How to graduate to FULL_COVERAGE

A richer spec with tighter invariants would shrink the surviving
set. Two real paths:

1. **Eliminate the comment-line mutations** - update the mutation
   catalog to skip tokens inside `//` comments. Tracked as a
   follow-up in `solve/shared/phases/mutation_sweep_runner.py`.
2. **Human-written invariant for the non-equivalence survivors** -
   for mutants #6 (line 25: `+` → `-` on increment), a strict
   monotonicity predicate under ack+no-loss would catch it IF the
   existing `p_cwnd_grows_on_ack` doesn't already subsume it.
   The gate correctly rejects redundant invariants; a genuinely
   new one would be accepted.

## Python API (full)

```python
from athanor.sv.invariants import discover_invariants, InvariantCandidate

# Optional: inject a stub proposer for deterministic CI tests.
def my_proposer(prompt: str) -> tuple[InvariantCandidate, float]:
    return InvariantCandidate(
        assertion_sv="p_my_invariant: assert property (...);",
        rationale="why this kills the mutant",
        target_mutant="operator + on line N",
        confidence=0.9,
    ), 0.0  # cost_usd

result = discover_invariants(
    "spec.sv",
    top_module="my_mod",
    bound=12,
    max_mutants=20,
    max_proposals_per_mutant=2,
    proposer=my_proposer,   # or omit for default Sonnet proposer
)
```

Return shape: `InvariantDiscoveryResult` carries
`mutants_enumerated`, `mutants_killed_by_existing`,
`mutants_surviving`, `proposals` (list of `CandidateVerdict`),
`overall` (`FULL_COVERAGE` | `PARTIAL` | `NO_PROPOSALS`),
`total_cost_usd`, `total_elapsed_sec`.

## Related

- `sv-multi-bbr3/` - multi-abstraction sandwich-rule demo on the
  same TelosReno spec (ATH-412a).
- ATH-408 umbrella - customer 2-day demo deliverables.
- `solve/shared/phases/mutation_sweep_runner.py` - the RTL
  mutation catalog this demo uses.
