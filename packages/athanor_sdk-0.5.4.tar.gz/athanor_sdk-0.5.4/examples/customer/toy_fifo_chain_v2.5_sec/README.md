# Athanor toy_fifo_chain v2.5 customer-block-certificate

Date: 2026-05-05 (placeholder; actual ship-date set on tone-pass)
Customer: Annapurna FV team (Todd lane)
Iteration: v2.5 - incremental update on top of the v2 cert (2026-05-04)
Live demo URL: https://tahoe.athanor-ai.com/analytics/silicon-blocks/c56c2b20-7411-4502-941c-f6a773c34b9c

## What's new in v2.5 vs v2

The v2 cert (2026-05-04) reported the SEC discharge result on the
`fifo_widget` block as: `pop_data_match` PROVED + `full_match` INCONCLUSIVE
+ `empty_match` INCONCLUSIVE - total 0 PROVED + 1 REFUTED + 2 INCONCLUSIVE on the
fifo_widget instance. The two INCONCLUSIVE properties were honestly
framed as "k-induction unable to close without an inductive bridge
invariant on the internal state".

Between v2 and v2.5, two independent results landed:

1. **Athanor closed-loop invariant-generation runner (D-spike, ATH-992)** ran the LLM-driven propose-inject-verify loop against both INCONCLUSIVE properties and produced bridge invariants that close k-induction:
   * `full_match` closes with the LLM-proposed bridge `gold.head == gate.head && gold.tail == gate.tail && gold.count == gate.count && gold.mem[0] == gate.mem[111:84] && gold.mem[1] == gate.mem[83:56] && gold.mem[2] == gate.mem[55:28] && gold.mem[3] == gate.mem[27:0]` - full state-equality with bit-packing-correspondence between gold's `logic [27:0] mem [4]` and gate's `reg [111:0] mem`.
   * `empty_match` closes with the weaker sufficient bridge `gold.count == gate.count && gold.head == gate.head && gold.tail == gate.tail` - count + head + tail equality (no mem-equality needed since `empty = (count == 0)`).

2. **Pythia/Hardware/SEC kernel-checked theorems on impl-side flag-count consistency**: the cto-side W2 commit lands `Pythia.Hardware.SEC.FifoWidget.bridge_inv_full` + `bridge_inv_empty` - *kernel-checked, axiom-audit-clean* theorems proving that the `fifo_widget` impl's full/empty flags are consistent with the abstract spec's full/empty predicates (`isFull`/`isEmpty` of `absFifoWidget s`). These theorems prove a property *about the impl side alone*, not about gold-vs-gate state correspondence.

These two results are *separate but complementary* - see `02-bridge-invariant-discharge.md` for the assumption-stack diagram showing how each contributes to the v2.5 verdict (now with both stacks kernel-proved as of pythia#93).

## The verdict at a glance (v2.5)

| Property | v2 verdict | v2.5 verdict |
|----------|-----------|-------------|
| `pop_data_match` | PROVED-standalone | PROVED-standalone (carried over; k-induction closes without assume-property) |
| `full_match` | INCONCLUSIVE | PROVED-with-assume (k-induction closes under assume-property bridge; bridge **PROVED via `bridgeFullInv_holds_at_every_co_step`** in pythia#93, kernel-checked) |
| `empty_match` | INCONCLUSIVE | PROVED-with-assume (same shape: closes under weaker bridge; bridge **PROVED via `bridgeEmptyInv_holds_at_every_co_step`** in pythia#93, kernel-checked) |
| **Total SEC-side** | 0 PROVED + 1 REFUTED + 2 INCONCLUSIVE (in v2's bare run) | **2 PROVED-with-assume + 1 REFUTED-carry-over** - `full_match` + `empty_match` PROVED via EBMC k-induction with LLM-proposed bridge invariants; both bridges kernel-checked as Lean theorems (pythia#93, axiom-clean); `pop_data_match` REFUTED via X-init aliasing diagnostic carried over from v2 (codegen finding, not behavioral divergence) |

*Two parallel proof artifacts agreeing on every bridge*: EBMC k-induction (with `assume property (inv_state_sync)`) AND kernel-checked Lean refinement (`bridge*Inv_holds_at_every_co_step` on every co-step trace of (goldStep, gateStep)). Both are axiom-audit-clean (`propext + Classical.choice + Quot.sound` only).

*Separately, on the impl side*: 2 carried-over theorems (`bridge_inv_full` + `bridge_inv_empty`) prove impl-side flag-count consistency against the abstract `fifoStep` spec. Different claim from gold-vs-gate state correspondence; both useful, both kernel-checked.

## Honest framing - what's PROVED, what's NOT

The v2.5 verdict for `full_match` and `empty_match` rests on TWO mutually-supporting proof artifacts:

1. *EBMC k-induction* closed each property under an assume-property bridge invariant (LLM-proposed during the closed-loop run).
2. *The bridge invariant itself* - the gold-vs-gate state correspondence - is **kernel-proved as a Lean theorem** in `Pythia.Hardware.SEC.FifoWidget.bridge*Inv_holds_at_every_co_step` (pythia#93). Customer can re-run the audit (below) to confirm.

Separately, the cto-side Lean theorems prove impl-side flag-count consistency:

* `Pythia.Hardware.SEC.FifoWidget.bridge_inv_full`: `s.full_flag = true ↔ isFull (absFifoWidget s)` - the impl's full-flag reflects the abstract spec's full-predicate.
* `Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty`: analogous for empty.

These are *axiom-audit-clean* (`[propext, Classical.choice, Quot.sound]` only, no `sorryAx`). Customer can re-run the audit:

```sh
cd lean-spec
lake env lean --run AxiomAudit.lean -- check_theorems
# expected: bridge_inv_full + bridge_inv_empty both clean
#   axioms: [propext, Classical.choice, Quot.sound]
```

The combined v2.5 customer-trust contract reads: "the gold-vs-gate equivalence holds under EBMC k-induction with an LLM-proposed bridge invariant. The bridge invariant is unproven as a Lean theorem in v2.5; v2.6 builds the gold-vs-gate Mealy step models + proves it. Separately, the impl side's flag-count consistency IS kernel-proved against the abstract spec."

## How to read this package

| File | Audience | Length |
|------|----------|--------|
| `01-customer-block-certificate-v2.5.md` | Engineer-reading-the-output | one page |
| `02-bridge-invariant-discharge.md` | Engineer-evaluating-rigor | three pages |
| `03-honest-framing-v2.5.md` | Engineer-evaluating-rigor (delta vs v2) | one page |
| `follow-up-roadmap-v2.5.md` | Anyone tracking the next iteration | one page |

The remaining directories carry the artifacts the pipeline
consumed and produced:

| Directory | What it contains |
|-----------|------------------|
| `inputs/` | gold.sv + gate.v + signature.json (unchanged from v2) |
| `clash-gate/` | The Clash gate Haskell source + flop-correspondence audit (unchanged from v2) |
| `lean-spec/` | The customer-auditable Lean theorems (NEW in v2.5: kernel-checked theorems on impl-side flag-count consistency; v2.6 adds gold-vs-gate Mealy theorems) |
| `sec-discharge-run/` | EBMC BMC + k-induction logs from the v2.5 discharge (with the assume-property bridges injected) |
| `demo-url.txt` | Direct link to the live dashboard render |

## Contact

Aidan Yang, Athanor AI.

---

*Cert generated by `kairos.sec.closed_loop` D-spike runner 2026-05-05;
discharge run id `c56c2b20-7411-4502-941c-f6a773c34b9c`. v2 -> v2.5 wording-discipline
applied per build-tarball.sh pre-flight gates.*
