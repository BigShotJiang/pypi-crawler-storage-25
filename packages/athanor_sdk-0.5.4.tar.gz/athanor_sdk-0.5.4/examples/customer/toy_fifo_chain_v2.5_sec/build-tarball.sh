#!/usr/bin/env bash
# v2.5 toy_fifo_chain customer-block-certificate build script with
# the new Gate 4c (assumption-stack-disclosure check) per the
# v2.5 honest-framing discipline + ATH-992 D-spike validation.
set -euo pipefail

SCAFFOLD_DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-/tmp/v2.5-toy-fifo-chain-tarball.tgz}"
SDR="$SCAFFOLD_DIR/sec-discharge-run"

REQUIRED_FILES=(
  README.md
  01-customer-block-certificate-v2.5.md
  02-bridge-invariant-discharge.md
  03-honest-framing-v2.5.md
  follow-up-roadmap-v2.5.md
  demo-url.txt
  inputs/gold.sv
  inputs/gate.v
  inputs/signature.json
  lean-spec/FifoWidgetGoldGateInvariant.lean
  lean-spec/AxiomAudit.lean
  sec-discharge-run/ebmc-induction-with-assume-full.log
  sec-discharge-run/ebmc-induction-with-assume-empty.log
  sec-discharge-run/ebmc-induction-bare.log
)

echo "==> Gate 1: required-files"
for f in "${REQUIRED_FILES[@]}"; do
  if [[ ! -f "$SCAFFOLD_DIR/$f" ]]; then
    echo "MISSING: $f"
    exit 1
  fi
done
echo "OK ($(echo "${REQUIRED_FILES[@]}" | wc -w) files present)"

echo "==> Gate 2: AI-fingerprint"
BANNED='load-bearing|harness|leverage|next generation|elided|delve|tapestry|seamlessly|in conclusion|comprehensive solution'
if grep -REil "$BANNED" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: AI-fingerprint phrases detected above"
  exit 1
fi
echo "OK (no banned phrases)"

echo "==> Gate 3: internal-codename"
CODENAMES='asabi|kairos\.observe|hongsksam|aidanby|athanor-builder|athanor-platform|athanor-sdk'
violations=$(grep -REinl "$CODENAMES" "$SCAFFOLD_DIR"/*.md || true)
filtered=$(echo "$violations" | grep -v '^$' || true)
if [[ -n "$filtered" ]]; then
  echo "FAIL: internal codename leaked in:"
  echo "$filtered"
  grep -REin "$CODENAMES" $filtered || true
  exit 1
fi
echo "OK (no internal codenames in customer-facing md)"

echo "==> Gate 4a: vacuous-overclaim phrases"
OVERCLAIM='formally verified|mathematically proven|machine-checked theorem|absolute correctness|guaranteed correct'
if grep -REil "$OVERCLAIM" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: vacuous-overclaim phrases detected above"
  exit 1
fi
echo "OK (no overclaim phrases)"

echo "==> Gate 4b: PROVED-as-headline-label (carryover from v2)"
LABEL_BAN='\| *PROVED *\||Verdict[^|]*\| *PROVED|verdict[^|]*\| *PROVED|^Proved by|\| *Proved by|\bPROVED verdict\b|\bPROVED kernels\b|\bproduced a PROVED\b'
if grep -REn "$LABEL_BAN" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: PROVED used as a headline verdict label above"
  exit 1
fi
echo "OK (no PROVED-as-headline-label)"

echo "==> Gate 4c: assumption-stack-disclosure — name-match (carryover from v2.5 v0)"
# Per ATH-992 deliverable 3 + the third-instance honest-framing pattern:
# every cert claim of `[proved by Pythia.Hardware.SEC.X]` MUST resolve
# to a real theorem in the lean-spec/ directory. If a [proved by X] claim
# cites a non-existent theorem, the build fails-loud — same shape as
# Gate 5's verdict-count cross-check.
LEAN_SOURCE_DIR="$SCAFFOLD_DIR/lean-spec"
violations_4c=0
while IFS= read -r line; do
  if [[ "$line" =~ \[proved\ by\ ([A-Za-z][A-Za-z0-9_.]+)\] ]]; then
    theorem="${BASH_REMATCH[1]}"
    bare="${theorem##*.}"
    if ! grep -rEq "(theorem|lemma|def)\s+${bare}\b" "$LEAN_SOURCE_DIR" 2>/dev/null; then
      echo "FAIL: cert claims [proved by $theorem] but no matching declaration found in lean-spec/"
      echo "  search pattern: (theorem|lemma|def)\\s+${bare}"
      echo "  source line: $line"
      violations_4c=$((violations_4c + 1))
    fi
  fi
done < <(grep -rh '\[proved by ' "$SCAFFOLD_DIR"/*.md "$SCAFFOLD_DIR"/*.txt 2>/dev/null || true)
if [[ $violations_4c -gt 0 ]]; then
  echo "FAIL: $violations_4c assumption-stack-disclosure violation(s)"
  exit 1
fi
echo "OK (every [proved by X] claim resolves to a real declaration in lean-spec/)"

echo "==> Gate 4c-stmt: statement-structural-audit (NEW per asabi 2026-05-05 HARD-STOP review)"
# Per asabi 2026-05-05 6th-instance meta-rule violation: name-match alone
# is bypassable because `theorem foo : True := trivial` passes Gate 4c
# (the name exists) while proving nothing useful. v2.5 ships a regex-
# level pattern catch on three obvious vacuous shapes:
#   (a) theorem statement is bare `: True` (vacuously inhabited)
#   (b) theorem body on the same line is bare `:= trivial` / `:= rfl` /
#       `:= True.intro` / `:= ⟨⟩` (vacuous discharge)
#   (c) theorem on a single line containing both : True := trivial
# v3 adds full elaboration via `lake env lean --run` + tactic analysis;
# this regex catch is the v2.5 floor.
violations_4c_stmt=0
shopt -s nullglob
for theorem_file in "$LEAN_SOURCE_DIR"/*.lean; do
  # (a) any theorem with `: True` as the type signature
  if grep -nEH ':\s*True\s*(:=|by|$)' "$theorem_file"; then
    echo "FAIL: theorem with vacuous type 'True' in $theorem_file"
    violations_4c_stmt=$((violations_4c_stmt + 1))
  fi
  # (b) any theorem body that is bare := trivial / rfl / True.intro / ⟨⟩ / ()
  if grep -nEH ':=\s*(trivial|rfl|True\.intro|⟨⟩|\(\))\s*$' "$theorem_file"; then
    echo "FAIL: theorem with bare-vacuous body (trivial/rfl/True.intro/⟨⟩/()) in $theorem_file"
    violations_4c_stmt=$((violations_4c_stmt + 1))
  fi
done
shopt -u nullglob
if [[ $violations_4c_stmt -gt 0 ]]; then
  echo "FAIL: $violations_4c_stmt statement-structural-audit violation(s)"
  exit 1
fi
echo "OK (no vacuous theorem bodies / types in lean-spec/)"

echo "==> Gate 4d: axiom-audit-pin (NEW per asabi 2026-05-05 review)"
# Per asabi 2026-05-05 third addition: theorem must audit-clean against
# [propext, Classical.choice, Quot.sound] only. v2.5 ships a regex
# check on the AxiomAudit.lean file confirming it asserts the
# axiom-clean property; v3 invokes `lake env lean --run` and parses
# the actual axiom output programmatically (deferred — needs Lean
# toolchain on the build host).
if [[ ! -f "$LEAN_SOURCE_DIR/AxiomAudit.lean" ]]; then
  echo "FAIL: lean-spec/AxiomAudit.lean missing (required for Gate 4d)"
  exit 1
fi
# The audit driver MUST contain a #print axioms invocation for each
# theorem the cert claims [proved by ...]. If the cert names theorem
# Foo but AxiomAudit.lean doesn't `#print axioms Foo`, the customer
# can't reproduce the audit + we can't claim axiom-clean.
violations_4d=0
while IFS= read -r line; do
  if [[ "$line" =~ \[proved\ by\ ([A-Za-z][A-Za-z0-9_.]+)\] ]]; then
    theorem="${BASH_REMATCH[1]}"
    if ! grep -qE "#print\s+axioms\s+${theorem}\b" "$LEAN_SOURCE_DIR/AxiomAudit.lean"; then
      echo "FAIL: cert claims [proved by $theorem] but AxiomAudit.lean has no '#print axioms $theorem' check"
      violations_4d=$((violations_4d + 1))
    fi
  fi
done < <(grep -rh '\[proved by ' "$SCAFFOLD_DIR"/*.md "$SCAFFOLD_DIR"/*.txt 2>/dev/null || true)
if [[ $violations_4d -gt 0 ]]; then
  echo "FAIL: $violations_4d axiom-audit-pin violation(s)"
  exit 1
fi
echo "OK (every [proved by X] has matching '#print axioms X' in AxiomAudit.lean)"

echo "==> Gate 4f: cert-authoring-time engine-output cross-check (NEW per ATH-1018, prior-run-carry-over instance-1 sub-shape)"
# Per ATH-1018 + the `prior-run-carry-over` memory rule: cert prose's
# per-property verdict claims must match the engine's freshly-derived
# output. Catches the "did you re-run, or did you remember?" failure
# mode structurally.
#
# v2.5 has THREE EBMC logs (one per property's appropriate run):
#   - bare log:           pop_data_match (no assume)
#   - assume-full log:    full_match (with count-sync assume)
#   - assume-empty log:   empty_match (with state-sync assume)
# Each property is cross-checked against its appropriate log so
# the bare log's INCONCLUSIVE on full_match/empty_match doesn't
# false-positive against the cert's PROVED-with-assume claim.
if command -v python3 >/dev/null 2>&1; then
  cross_check_out=$(python3 -c "
import sys
from pathlib import Path
try:
    from kairos.cert import cross_check_against_engine_output
except ImportError as e:
    print(f'SKIP: kairos.cert not importable ({e})', file=sys.stderr)
    sys.exit(0)
cert = Path('$SCAFFOLD_DIR/01-customer-block-certificate-v2.5.md')

# Three (target_property, log) pairings — each property gets its
# appropriate-log routing.
pairings = [
    ('sec_miter.pop_data_match', '$SDR/ebmc-induction-bare.log'),
    ('sec_miter.full_match', '$SDR/ebmc-induction-with-assume-full.log'),
    ('sec_miter.empty_match', '$SDR/ebmc-induction-with-assume-empty.log'),
]
all_mismatches = []
total_claims = 0
for prop, log_path in pairings:
    log = Path(log_path)
    if not log.exists():
        continue
    result = cross_check_against_engine_output(cert, log, target_properties=[prop])
    total_claims += len(result.claims)
    all_mismatches.extend(result.mismatches)

if all_mismatches:
    print(f'FAIL: {len(all_mismatches)} cert-vs-engine mismatch(es):', file=sys.stderr)
    for m in all_mismatches:
        print(f'  {m.claim.target_property} (cert line {m.claim.source_line}): claim={m.claim.claimed_verdict}, engine={m.engine_verdict}', file=sys.stderr)
        print(f'    {m.explanation}', file=sys.stderr)
    sys.exit(1)
print(f'OK ({total_claims} cert claims cross-checked against per-property engine logs, all match)')
" 2>&1)
  if [[ $? -ne 0 ]]; then
    echo "$cross_check_out"
    exit 1
  fi
  echo "$cross_check_out"
else
  echo "SKIP: python3 not available — Gate 4f deferred"
fi

echo "==> Gate 4e: customer-runnable-claim infrastructure (NEW per asabi 2026-05-05 forward-pin #1, 7th-instance meta-rule)"
# Per asabi 2026-05-05 forward-pin #1 (closed by cto/v2.5-cert-real-lean-source
# commit f198b3b but landed structurally here): if the cert prose claims
# the customer can run `lake env lean --run AxiomAudit.lean -- ...`,
# the Lake project infrastructure (lakefile.lean + lean-toolchain) MUST
# ship in lean-spec/. Otherwise the customer download → run command →
# missing-Lake-project error, customer-trust contract collapses on
# claim-customer-can-X-without-X-being-actually-doable.
#
# 7th-instance meta-rule cluster (audit-driver-without-Lake-project-bypass
# / VCD-download-without-storage-upload-bypass / ...):
# customer-reproducibility-claim must ship the reproducibility
# infrastructure structurally, never claim-without-substance.
violations_4e=0
if grep -rq 'lake env lean\|lake build\|lakefile' "$SCAFFOLD_DIR"/*.md "$SCAFFOLD_DIR"/*.txt 2>/dev/null; then
  # Cert claims a Lake-runnable command. Verify lakefile.lean +
  # lean-toolchain are present in lean-spec/.
  if [[ ! -f "$LEAN_SOURCE_DIR/lakefile.lean" ]]; then
    echo "FAIL: cert prose references 'lake' commands but lean-spec/lakefile.lean is missing"
    violations_4e=$((violations_4e + 1))
  fi
  if [[ ! -f "$LEAN_SOURCE_DIR/lean-toolchain" ]]; then
    echo "FAIL: cert prose references 'lake' commands but lean-spec/lean-toolchain is missing"
    violations_4e=$((violations_4e + 1))
  fi
fi
if [[ $violations_4e -gt 0 ]]; then
  echo "FAIL: $violations_4e customer-runnable-claim infrastructure violation(s)"
  exit 1
fi
echo "OK (customer-runnable claims have matching infrastructure in lean-spec/)"

echo "==> Gate 5: result-label cross-check"
cert_label=$(grep -c 'PROVED' "$SCAFFOLD_DIR/01-customer-block-certificate-v2.5.md" || true)
readme_label=$(grep -ic 'proved' "$SCAFFOLD_DIR/README.md" || true)
if [[ "$cert_label" -lt 1 ]] || [[ "$readme_label" -lt 1 ]]; then
  echo "FAIL: result label mismatch (cert PROVED=$cert_label readme proved=$readme_label)"
  exit 1
fi
echo "OK (result label PROVED present in cert + readme)"

echo "==> Gate 6: verdict-count cross-check (v2.5 round 3 — 2 PROVED + 1 REFUTED across 3 logs)"
# Per the round 3 honest-correction: cert claims 2 PROVED-with-assume +
# 1 REFUTED-carry-over. The actual EBMC artifacts split across THREE
# logs (one per property's tailored-assume run + one bare-miter run):
#   - ebmc-induction-with-assume-full.log:  full_match PROVED under
#     `gold.count == gate.count` assume
#   - ebmc-induction-with-assume-empty.log: empty_match PROVED under
#     `gold.{count,head,tail} == gate.{count,head,tail}` assume
#   - ebmc-induction-bare.log: pop_data_match REFUTED + the other two
#     INCONCLUSIVE without any assume (bare-miter carry-over from v2)
# Gate 6 cross-checks that the assume-runs each show a PROVED for their
# target property + that the bare-run shows a REFUTED for pop_data_match
# (so the X-init-aliasing diagnostic isn't silently dropped).
SDR="$SCAFFOLD_DIR/sec-discharge-run"
g6_violations=0

if [[ -f "$SDR/ebmc-induction-with-assume-full.log" ]]; then
  if ! grep -qE 'sec_miter\.full_match\b.*: PROVED' "$SDR/ebmc-induction-with-assume-full.log"; then
    echo "FAIL: ebmc-induction-with-assume-full.log does not show full_match PROVED"
    g6_violations=$((g6_violations + 1))
  fi
else
  echo "SKIP: sec-discharge-run/ebmc-induction-with-assume-full.log not present"
fi

if [[ -f "$SDR/ebmc-induction-with-assume-empty.log" ]]; then
  if ! grep -qE 'sec_miter\.empty_match\b.*: PROVED' "$SDR/ebmc-induction-with-assume-empty.log"; then
    echo "FAIL: ebmc-induction-with-assume-empty.log does not show empty_match PROVED"
    g6_violations=$((g6_violations + 1))
  fi
else
  echo "SKIP: sec-discharge-run/ebmc-induction-with-assume-empty.log not present"
fi

# REFUTED diagnostic on pop_data_match must be present + surfaced —
# never silently dropped (X-init-aliasing diagnostic is honest-framing
# carry-over from v2; cert prose explains the codegen finding).
if [[ -f "$SDR/ebmc-induction-bare.log" ]]; then
  if ! grep -qE 'sec_miter\.pop_data_match\b.*: REFUTED' "$SDR/ebmc-induction-bare.log"; then
    echo "FAIL: ebmc-induction-bare.log does not show pop_data_match REFUTED (X-init aliasing diagnostic must be present)"
    g6_violations=$((g6_violations + 1))
  fi
else
  echo "SKIP: sec-discharge-run/ebmc-induction-bare.log not present"
fi

if [[ $g6_violations -gt 0 ]]; then
  echo "FAIL: $g6_violations Gate 6 violation(s)"
  exit 1
fi
echo "OK (per-log verdict counts match cert claim: full_match PROVED, empty_match PROVED, pop_data_match REFUTED)"

echo "==> Gate 7: dry-run cert event Pydantic-validate (NEW per ATH-1042 v2.6 cluster meta-rule instance #10-A, build-time-pin lift)"
# Per asabi 2026-05-06 cluster-discipline meta-rule "runtime-catch →
# build-time-pin lift" — instance #10 was caught at runtime via re-
# screenshot; #10-A lifts the gate to build-time. Construct a sample
# customer_block_certificate_complete payload from the cert prose + the
# discharge run + validate against the Pydantic model in
# kairos.trace_schema. If shape divergence between cert + emit shape
# divergence → fail loud, do NOT ship the tarball.
if command -v python3 >/dev/null 2>&1; then
  gate7_out=$(python3 -c "
from kairos.trace_schema import validate_payload
sample = {
    'block_name': 'fifo_widget',
    'verdict_summary': '2 PROVED-with-assume + 1 REFUTED-carry-over (bridges PROVED via Lean)',
    'per_property_verdicts': [
        {'property': 'full_match', 'verdict': 'PROVED-with-assume', 'bridge_label': 'inv_state_sync'},
        {'property': 'empty_match', 'verdict': 'PROVED-with-assume', 'bridge_label': 'inv_state_sync'},
        {'property': 'pop_data_match', 'verdict': 'REFUTED-carry-over', 'diagnostic_class': 'x_init_aliasing'},
    ],
    'assumption_stack': [
        'inv_state_sync (full_match)',
        'inv_state_sync (empty_match)',
    ],
    'lean_proves_obligations': [
        {'property': 'full_match', 'theorem': 'Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step', 'status': 'PROVED via Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step'},
        {'property': 'empty_match', 'theorem': 'Pythia.Hardware.SEC.FifoWidget.bridgeEmptyInv_holds_at_every_co_step', 'status': 'PROVED via Pythia.Hardware.SEC.FifoWidget.bridgeEmptyInv_holds_at_every_co_step'},
    ],
    'n_proved': 2,
    'n_refuted': 1,
    'total_properties': 3,
    'discharge_engine': 'EBMC k-induction + Lean kernel',
}
r = validate_payload('theorem_proving', 'customer_block_certificate_complete', sample)
if not r.ok:
    print('VIOLATIONS:')
    for v in r.violations:
        print(' ', v)
    raise SystemExit(1)
" 2>&1)
  if [[ $? -ne 0 ]]; then
    echo "FAIL: cert event Pydantic validation: $gate7_out"
    exit 1
  fi
  echo "OK (cert event payload validates against _CustomerBlockCertificateComplete Pydantic model)"
else
  echo "SKIP: python3 not available — Gate 7 deferred"
fi

echo "==> Building tarball"
tar -czf "$OUT" -C "$(dirname "$SCAFFOLD_DIR")" "$(basename "$SCAFFOLD_DIR")"
echo "Wrote: $OUT"
ls -lh "$OUT"
