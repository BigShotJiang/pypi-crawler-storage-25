# Honest framing v2 -> v2.5 delta

## What changed

The v2 cert (2026-05-04) reported on `fifo_widget`:

* `pop_data_match`: PROVED via EBMC k-induction
* `full_match`: INCONCLUSIVE - k-induction unable to close without an inductive bridge invariant on the internal state
* `empty_match`: INCONCLUSIVE - same reason

The v2 cert was honest about the INCONCLUSIVE outcomes - it explicitly named "missing inductive invariant" as the gap. The customer trust contract on v2 read: 1 of 3 properties closed under the SEC runner; 2 are open pending bridge invariants.

The v2.5 cert refreshes the verdict with bridge invariants discharged. The v2 wording is still accurate as of v2's discharge run; v2.5 is an INCREMENTAL update, NOT a retroactive correction.

## What did NOT change

* The gold-side SV source (`gold.sv`).
* The gate-side Verilog (`gate.v`, Clash-emitted).
* The Clash flop-correspondence audit (carry-over from v2 ATH-983 W3).
* The miter shape (the same `sec_miter` module from v2).

The v2.5 verdict-mix change is *purely* due to the new closed-loop invariant-generation runner landing between v2 and v2.5. No RTL changed; no engine changed; we just learned how to discharge the inductive obligations that were open in v2.

## What this v2.5 packet IS

* An incremental refresh of the v2 cert's verdict-mix on `fifo_widget`.
* The first customer-facing application of the closed-loop invariant-generation runner (D-spike / ATH-992).
* The first customer-facing demonstration of the type-system-enforced honest-framing rules (`InvariantCandidate.proves_obligation`, `IterationRecord.is_auto_acceptable()`, `assumption_stack()` renderer) shipping in `kairos.sec.closed_loop`.
* Customer-runnable: customer can `pip install athanor-kairos` + run `kairos.sec.closed_loop.generate_invariant(...)` + reproduce the verdict + read the Lean theorems + run the axiom audit themselves.

## What this v2.5 packet IS NOT

* **Not a retroactive correction of v2**. v2's verdict was accurate at the time of v2's discharge - 2 INCONCLUSIVE properties are how EBMC k-induction stood without bridge invariants. v2.5 adds a discharge layer on top.
* **Not a claim that v2's INCONCLUSIVE properties were "always actually proved"**. They weren't - k-induction didn't close them in v2. The bridge invariants are NEW in v2.5; they didn't exist when v2 ran.
* **Not a closed-loop optimization arc**. The PPA-loop (proposer + ranker + verifier + comparator) is W2 substantive work; this v2.5 cert only refreshes the SEC verdict-mix. Optimization-loop shipping is downstream.
* **Not a real Trainium or post-place silicon-PD measurement**. `gate.v` is Clash-emitted Verilog mirroring `gold.sv` semantics; real synthesized cell counts + timing slack from a customer-provided liberty file land in v3.0 post-VPC-onboarding.

## Words we use vs words we don't

| Word | Status | Why |
|------|--------|-----|
| **PROVED via SEC + invariant-discharge** | Used | Combined claim: EBMC closes the property under assume-property; assume-property's bridge invariant is itself proved by a kernel-checked Lean theorem. |
| **TESTS PASSED** | Used in nki kernel context, NOT used here | nki kernels use empirical test-pass framing; SEC bundles use Lean-theorem-discharged framing because the claim IS a kernel-checked-theorem-discharged equivalence. |
| **Discharged** | Used carefully | Used in the technical sense ("the obligation is discharged by Lean theorem X"). The build-tarball gate distinguishes: `discharged by Pythia.Hardware.SEC.X` (allowed) vs `discharged` standalone as a verdict label (banned per the v1 wording-incident-class). |
| **Inductive bridge** | Used | Names the technical role of the assume-property: an invariant that's preserved across the gold/gate Mealy step + implies the equivalence claim. Customer-auditable in the Lean source. |

## Pre-flight gate Gate 4c (assumption-stack-disclosure)

The v2 build-tarball.sh shipped with 5 pre-flight gates:

* Gate 1: required-files
* Gate 2: AI-fingerprint
* Gate 3: internal-codename
* Gate 4a: vacuous-overclaim phrases
* Gate 4b: PROVED-as-headline-label
* Gate 5: result-label cross-check

The v2.5 build-tarball.sh adds:

* **Gate 4c: assumption-stack-disclosure**. Greps the cert prose for `[proved by <theorem_name>]` claims; for each, verifies that `X` is an existing axiom-audit-clean theorem in the `lean-spec/` directory. If a `[proved by <theorem_name>]` claim cites a non-existent theorem, the build fails-loud - same shape as Gate 5's verdict-count cross-check.

This closes the third-instance honest-framing pattern at the build-script level: any cert claim of `[proved by <theorem_name>]` is structurally tied to a real Lean theorem in the tarball.

## What we want from the customer

Same ask as v1 + v2: read the Lean theorems + run the axiom audit + cross-check the operational-semantics modeling against `gold.sv` and `gate.v`. If anything in the modeling looks wrong, surface the discrepancy as the next-iteration's audit-target. The closed-loop runner can iterate.
