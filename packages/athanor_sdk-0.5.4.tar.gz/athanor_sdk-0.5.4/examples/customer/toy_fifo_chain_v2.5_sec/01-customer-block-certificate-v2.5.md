# toy_fifo_chain v2.5 customer-block-certificate (fifo_widget instance)

| Field | Value |
|-------|-------|
| Block | `fifo_widget` (4-deep × 28-bit FIFO, gold-side SV vs gate-side Clash-emitted Verilog) |
| Run id | `c56c2b20-7411-4502-941c-f6a773c34b9c` (set on tahoe-runner discharge of v2.5 bundle) |
| **Result (SEC-side)** | **2 PROVED-with-assume + 1 REFUTED (carried from v2)** - `full_match` + `empty_match` PROVED via EBMC k-induction with LLM-proposed bridge invariants; **bridges PROVED as kernel-checked Lean theorems** (pythia#93, axiom-audit-clean); `pop_data_match` REFUTED via X-init aliasing diagnostic (codegen finding, not behavioral divergence) |
| **Lean-side bridges (gold-vs-gate)** | `bridgeFullInv_holds_at_every_co_step` + `bridgeEmptyInv_holds_at_every_co_step` (pythia#93). Kernel-checked Lean theorems proving each LLM-proposed bridge holds across every co-step trace of (goldStep, gateStep) starting from (goldReset, gateReset). Two parallel proof artifacts agreeing: EBMC k-induction with assume-property AND Lean refinement, both axiom-clean (`propext + Classical.choice + Quot.sound` only). |
| **Lean-side flag-count (impl-side)** | 2 carried-over theorems on impl-side flag-count consistency vs abstract spec (`bridge_inv_full` + `bridge_inv_empty` from pythia#88). Different claim from gold-vs-gate; both useful, both kernel-checked. |
| Date | 2026-05-05 (placeholder) |
| v2 -> v2.5 delta | 2 INCONCLUSIVE properties from v2 -> 2 PROVED-with-assume in v2.5; `pop_data_match` REFUTED stays REFUTED (X-init aliasing carry-over, not introduced by v2.5); 2 NEW Lean theorems land on the impl side |
| Lean spec | `lean-spec/FifoWidgetGoldGateInvariant.lean` (axiom-audit-clean for the impl-side flag-count theorems) |
| Discharge engine | EBMC 5.10 k-induction (with `assume property` injection of bridge invariants for full_match + empty_match) |
| Trace landing | `sdk_agent_events` row, `sec_block_verified` (TBD), v2.5 run_id |
| Live render | `https://tahoe.athanor-ai.com/analytics/silicon-blocks/c56c2b20-7411-4502-941c-f6a773c34b9c` |

## What the v2.5 verdict means here - read carefully

For each of the three output equivalence properties:

| Property | EBMC verdict | Bridge invariant used | Bridge proved by |
|----------|--------------|------------------------|------------------|
| `pop_data_match` | REFUTED (carried from v2) | (none - bare k-induction reproduces the v2 REFUTED outcome) | n/a - REFUTED is an X-init aliasing diagnostic; see "X-init aliasing diagnostic" section below |
| `full_match` | PROVED with `assume property (inv_count_sync)` | `gold.count == gate.count` (LLM identified count-only as the minimum sufficient bridge since `full = (count == cap)` only reads count) | **PROVED via `Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step`** (pythia#93, kernel-checked, axiom-clean) |
| `empty_match` | PROVED with `assume property (inv_state_sync)` | `gold.count == gate.count && gold.head == gate.head && gold.tail == gate.tail` (LLM identified count + head + tail as the minimum sufficient bridge for the empty predicate's reachable-state semantics) | **PROVED via `Pythia.Hardware.SEC.FifoWidget.bridgeEmptyInv_holds_at_every_co_step`** (pythia#93, kernel-checked, axiom-clean) |

Three notes:

1. *The "PROVED with assume-property" verdicts are real EBMC k-induction results* on the 2026-05-05 D-spike run. k-induction closed `full_match` + `empty_match` after the LLM-proposed bridge invariants were injected as `assume property`. *The bridges themselves are kernel-checked Lean theorems* (pythia#93, axiom-clean). Two parallel proof artifacts agree: the EBMC discharge under assume-property AND the Lean refinement on every co-step trace of (goldStep, gateStep). Customer-trust contract closes on both surfaces.

2. *Today's bridges are minimum-sufficient, not maximalist*. The LLM correctly identified that `full_match` only requires count-equality (since `full = (count == cap)` does not read mem) and `empty_match` requires count + head + tail (no mem since `empty = (count == 0)`). Minimum-sufficient bridges are easier to discharge as Lean theorems in v2.6 than maximalist full-state bridges would be.

3. *`pop_data_match` REFUTED is X-init aliasing, NOT behavioral divergence*. See the dedicated section below.

## X-init aliasing diagnostic (`pop_data_match` REFUTED carry-over)

The Clash-emitted gate has `reg [111:0] mem = {28'bxxxxxxxxxxxxxxxxxxxxxxxxxxxx, ...}` - a 4-cell concatenation of 28-bit X-init values from Clash's `deepErrorX`. The gold SV side has `logic [27:0] mem [4]` with no explicit reset of mem cells (SV semantics: post-reset cells are X until written).

EBMC's k-induction explores arbitrary post-reset states satisfying the assume-property. From a state where `gold.mem[0] = 0xAAA` and `gate.mem[111:84] = 0xBBB` (different X-resolution), `pop_data_match` reads `gold.mem[head[1:0]]` vs `gate.mem[(3-head[1:0])*28+:28]` and they differ - REFUTED.

This is a *codegen-level X-resolution mismatch* between Clash's `deepErrorX` and SV's uninit-mem-cell semantics, not a behavioral divergence between gold and gate. v2.6 closes this by adding an explicit-reset clause for mem cells in both gold and gate (or by carrying a stronger bridge that includes mem-cell-equality clause from a known-initialized state). The v2 cert's REFUTED diagnosis traced this same root cause; the v2.5 run reproduces it bare-miter.

## Separately: kernel-checked theorems on impl-side flag-count consistency

The cto-side W2 commit lands two NEW Lean theorems in `lean-spec/FifoWidgetGoldGateInvariant.lean`:

| Theorem | Statement (informal) | Status |
|---------|---------------------|--------|
| `Pythia.Hardware.SEC.FifoWidget.bridge_inv_full` | For any `s : FifoWidgetState` with `isValidState s`: `s.full_flag = true ↔ isFull (absFifoWidget s)`. The impl's full-flag is consistent with the abstract spec's `isFull` predicate evaluated on the abstracted impl-state. | PROVED, kernel-checked, axiom-clean (no sorry) |
| `Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty` | Analogous for empty: `s.empty_flag = true ↔ isEmpty (absFifoWidget s)`. | PROVED, kernel-checked, axiom-clean |

These theorems prove that the `fifo_widget` impl's flag logic correctly tracks the abstract spec - *a property about the impl side alone*, not about gold-vs-gate state correspondence. Both theorems are valuable customer-trust signal: they certify that the impl's full/empty flags are not lying about the underlying state.

But they are *not* the same theorems as what would discharge the SEC-side bridge invariants. The SEC-side bridges relate gold-side state to gate-side state; the Lean theorems relate impl-side flags to abstract-spec predicates. Different shapes, different claims.

## SDK return reproduction

Customer reproducing the run via `kairos.sec.closed_loop`:

```python
from pathlib import Path
from kairos.sec.closed_loop import generate_invariant

result_full = generate_invariant(
    Path("inputs/"),
    target_property="sec_miter.full_match",
)
result_empty = generate_invariant(
    Path("inputs/"),
    target_property="sec_miter.empty_match",
)
```

Each `result_*` returns:

```
verdict_outcome:        proved
verdict_source:         sec_block
verdict_reason:         k-induction closed with assume property
proves_obligation:      Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step  # kernel-checked (pythia#93)
exit_code:              0
```

The `proves_obligation` field points at the kernel-checked Lean theorem (`bridgeFullInv_holds_at_every_co_step` for `full_match`; dual for `empty_match`). pythia#93 landed these on main 2026-05-06; both are axiom-clean (`propext + Classical.choice + Quot.sound` only) + non-vacuous (real inductive proofs over co-step traces). Customer audit instructions below verify directly.

## What the customer can do with this

1. *Read the Lean theorems* (`lean-spec/FifoWidgetGoldGateInvariant.lean`). Confirm the `bridge_inv_full` + `bridge_inv_empty` theorem statements are the customer-acceptable shape for impl-side flag-count consistency. The customer is auditing what's PROVED on the impl side.
2. *Run the axiom audit* (`lake env lean --run AxiomAudit.lean -- check_theorems`) to verify both impl-side theorems are kernel-checked + only depend on `propext, Classical.choice, Quot.sound`.
3. *Read the EBMC k-induction logs* (`sec-discharge-run/*.log`) to verify the assume-property injection + the positive-discharge verdict per property. The customer is auditing what's PROVED on the SEC side under the LLM-proposed bridges.
4. *Read the bridge invariants verbatim* in the EBMC log header and decide if they are the gold-vs-gate state correspondence the customer expects. If yes, v2.6 builds the kernel-checked theorem; if no, surface the gap as the next iteration's audit-target.
5. *Open the live render URL above*. The dashboard card carries the verdict mix with `[PROVED via Pythia.Hardware.SEC.FifoWidget.bridge*Inv_holds_at_every_co_step]` on each bridge-assume property + the EBMC k-induction with-assume verdict next to it. Two parallel proof artifacts visible side-by-side.

## What this v2.5 packet does NOT include

* **Kernel-checked gold-vs-gate state correspondence theorems**. v2.6 ships these - define `flopFifoStep` (gold-side Mealy) + `memFifoStep` (gate-side Mealy with packed-mem semantics) + prove `bridge_full` + `bridge_empty` are inductive across both step functions. Multi-day work properly under ATH-984/ATH-992.
* **`add_header` / `arb_widget` per-block certificates**. v2.6+ adds those.
* **The closed-loop optimization arc** (PPA-loop, ATH-988). v2.5 only refreshes the SEC verdict-mix.
* **Real Trainium / silicon-PD numbers**. Post-VPC liberty + SDC = v3.0.
