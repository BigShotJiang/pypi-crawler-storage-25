/-
v2.5 lean-spec/FifoWidgetGoldGateInvariant.lean

Self-contained customer-auditable Lean source for the v2.5 cert's
two impl-side flag-count consistency theorems. The source pulled
verbatim from `Pythia.Hardware.SEC.FifoWidget` (commit f335b88 on
the upstream Pythia tree, 2026-05-05); inlined here so the cert
tarball is self-contained — `lake build` against this directory
audits both theorems without requiring the broader Pythia tree.

What this file proves:

* `bridge_inv_full` — On any `s : FifoWidgetState cap w` whose
  flag flops are consistent with the count register
  (`isValidState s`): `s.full_flag = true ↔ isFull (absFifoWidget s)`.
  The impl's full flag agrees with the abstract spec's `isFull`
  predicate evaluated on the abstracted impl-state.

* `bridge_inv_empty` — Companion claim for the empty flag.

What this file does NOT prove:

* The SEC-side gold-vs-gate state correspondence (the formula
  EBMC was given as `assume property` — see
  `01-customer-block-certificate-v2.5.md` for the gold-vs-gate
  bridge formula). The gold-vs-gate equivalence under the
  assume-property bridge is a real EBMC k-induction result
  (PROVED), but the bridge invariant *itself* is UNPROVEN as a
  Lean theorem in v2.5; v2.6 lifts via gold-vs-gate Mealy step
  models (`flopFifoStep` / `memFifoStep`) which do not yet exist.

Reproducing the audit:

```sh
$ cd lean-spec/
$ lake build
$ lake env lean --run AxiomAudit.lean
'Pythia.Hardware.SEC.FifoWidget.bridge_inv_full' depends on axioms: [propext, Classical.choice, Quot.sound]
'Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty' depends on axioms: [propext, Classical.choice, Quot.sound]
```

No `sorryAx`, no custom axioms — both theorems audit clean
against Lean's standard kernel axiom set.

Source provenance: `Pythia.Hardware.SEC.FifoWidget` namespace,
commit f335b88 on the upstream Pythia tree (2026-05-05). The
inlined declarations below are byte-identical to the upstream
source modulo namespace flattening (we drop the upstream
`Pythia.Hardware.SEC` import dependency on `FifoContract.lean` +
`RefinementRelation.lean` since this cert tarball doesn't carry
the broader hardware-SEC infrastructure — the supporting types
are inlined directly below).
-/
import Mathlib

namespace Pythia.Hardware.SEC.FifoWidget

/-! ## Minimal supporting types (inlined from
`Pythia.Hardware.SEC.FifoContract` + `RefinementRelation`) -/

/-- The abstract spec-side state: a `Fin (cap+1)`-valued count plus
a head element. Inlined from `Pythia.Hardware.SEC.FifoContract`. -/
structure FifoState (cap w : ℕ) where
  count : Fin (cap + 1)
  head_elem : BitVec w
  deriving Repr

/-- A typed abstraction function from one state space to another.
Inlined from `Pythia.Hardware.SEC.RefinementRelation`. -/
abbrev AbstractionFunction (S_new S_old : Type*) := S_new → S_old

/-- Impl-level abstract flop state for the fifoWidget RTL block:
count + full_flag + empty_flag + head element. The flags are
redundant with `count` semantically but exist as separate flops
in the RTL, which is the source of the EBMC obligation: the
flag-update logic is implementation choice; the bridge invariants
say it agrees with the count on reset-reachable states. -/
structure FifoWidgetState (cap w : ℕ) where
  count : Fin (cap + 1)
  full_flag : Bool
  empty_flag : Bool
  head_elem : BitVec w
  deriving Repr

/-- Project the impl state onto the abstract `FifoState` by
dropping the redundant flags. -/
def absFifoWidget {cap w : ℕ} :
    AbstractionFunction (FifoWidgetState cap w) (FifoState cap w) :=
  fun s => ⟨s.count, s.head_elem⟩

/-! ## State-level full + empty predicates (abstract spec side) -/

/-- The state-level "full" predicate: count is exactly cap. -/
def isFull {cap w : ℕ} (s : FifoState cap w) : Prop := s.count.val = cap

/-- The state-level "empty" predicate: count is exactly 0. -/
def isEmpty {cap w : ℕ} (s : FifoState cap w) : Prop := s.count.val = 0

/-! ## The validity predicate — non-vacuous core

`isValidState` says: the redundant flop registers agree with the
count. Without this predicate as a hypothesis, the bridge
invariants would be vacuously closable on arbitrary impl states
(which is wrong: an arbitrary `FifoWidgetState` can have
inconsistent flag/count). The invariant only holds on reset-
reachable states. -/

/-- The flag-count consistency predicate that captures the
reset-reachable subset of impl states. -/
def isValidState {cap w : ℕ} (s : FifoWidgetState cap w) : Prop :=
  (s.full_flag = decide (s.count.val = cap))
  ∧ (s.empty_flag = decide (s.count.val = 0))

/-! ## The two bridge invariants — kernel-checked, axiom-clean

Both proofs use only definitional unfolding plus a `rw` that
substitutes the impl-side flag with its `decide`-shape. Customer
auditing this source can read three lines and confirm the
discharge is honest. -/

/-- `bridge_inv_full`: on any valid state, the impl's full_flag
agrees with the spec's `isFull` predicate via the abstraction. -/
theorem bridge_inv_full {cap w : ℕ}
    (s : FifoWidgetState cap w) (h_valid : isValidState s) :
    s.full_flag = true ↔ isFull (absFifoWidget s) := by
  unfold isValidState at h_valid
  unfold isFull absFifoWidget
  -- After the abstraction the spec-side count.val equals impl
  -- s.count.val by construction; full_flag matches via h_valid.1.
  rw [h_valid.1]
  exact decide_eq_true_iff

/-- `bridge_inv_empty`: companion invariant for the empty_flag. -/
theorem bridge_inv_empty {cap w : ℕ}
    (s : FifoWidgetState cap w) (h_valid : isValidState s) :
    s.empty_flag = true ↔ isEmpty (absFifoWidget s) := by
  unfold isValidState at h_valid
  unfold isEmpty absFifoWidget
  rw [h_valid.2]
  exact decide_eq_true_iff

end Pythia.Hardware.SEC.FifoWidget
