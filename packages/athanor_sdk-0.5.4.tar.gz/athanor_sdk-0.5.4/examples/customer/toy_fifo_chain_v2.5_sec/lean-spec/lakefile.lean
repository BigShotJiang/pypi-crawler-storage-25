-- v2.5 cert customer-auditable Lake project
--
-- Self-contained — depends only on Mathlib (pinned to v4.28.0 to
-- match the upstream Pythia toolchain commit f335b88 was built
-- against). Customer downloads the cert tarball, runs `lake build`
-- here, then `lake env lean --run AxiomAudit.lean` to confirm both
-- bridge_inv_* theorems are kernel-checked + axiom-clean.

import Lake
open Lake DSL

package «v2_5_cert_audit» where

require mathlib from git
  "https://github.com/leanprover-community/mathlib4.git" @ "v4.28.0"

@[default_target]
lean_lib «FifoWidgetGoldGateInvariant» where

lean_lib «AxiomAudit» where
