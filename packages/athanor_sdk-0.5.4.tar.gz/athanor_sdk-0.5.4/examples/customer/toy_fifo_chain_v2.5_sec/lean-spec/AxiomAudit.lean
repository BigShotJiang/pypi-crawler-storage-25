-- v2.6 lean-spec/AxiomAudit.lean
-- Customer audit driver: runs `#print axioms` on each theorem
-- the v2.6 cert claims [proved by ...]. Gate 4d requires every
-- such claim has a matching `#print axioms` line below.

import FifoWidgetGoldGateInvariant

-- v2.5 impl-side flag-count consistency theorems (carry-over).
-- Source: Pythia.Hardware.SEC.FifoWidget (commit f335b88 on
-- pythia#88; merged to pythia main).
#print axioms Pythia.Hardware.SEC.FifoWidget.bridge_inv_full
#print axioms Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty

-- v2.6 gold-vs-gate Mealy refinement theorems (NEW; pythia#93
-- merged to main 2026-05-06). Aristotle bfd2707b closed all 5
-- stage-2 sorries (preservation + composition + gateWriteCell
-- bit-mask + base-case + induction). The two theorems below are
-- the cert assumption-stack's PROVED-via-Lean targets:
--
-- bridgeFullInv_holds_at_every_co_step:
--   The full-flag bridge invariant holds across every co-step trace
--   of (goldStep, gateStep) starting from (goldReset, gateReset).
--   This discharges the SEC-side EBMC `assume property (inv_state_sync)`
--   for full_match.
--
-- bridgeEmptyInv_holds_at_every_co_step:
--   Companion claim for the empty-flag bridge.
#print axioms Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step
#print axioms Pythia.Hardware.SEC.FifoWidget.bridgeEmptyInv_holds_at_every_co_step

-- Expected output for all four theorems:
--   axioms used: [propext, Classical.choice, Quot.sound]
-- No sorryAx; all axiom-clean.
