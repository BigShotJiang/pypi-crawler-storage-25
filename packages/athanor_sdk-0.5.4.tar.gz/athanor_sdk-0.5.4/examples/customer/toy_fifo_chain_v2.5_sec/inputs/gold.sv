// Gold side of the SEC pair for fifo_widget. Concrete-DEPTH version
// (DEPTH=4 specialized; no `parameter int DEPTH` or `$clog2` machinery)
// because EBMC 5.10's parser hits an internal invariant violation on
// the parameterized form. Body is otherwise byte-identical in
// register semantics to the v1 fifo_widget. head/tail/count are 3-bit
// (clog2(4)+1=3) and mem indices use `head[1:0]` pattern.

module fifo_widget(
  input  logic        clk,
  input  logic        rst_n,
  input  logic        push,
  input  logic [27:0] push_data,
  output logic        full,
  input  logic        pop,
  output logic [27:0] pop_data,
  output logic        empty
);
  logic [27:0] mem [4];
  logic [2:0] head;
  logic [2:0] tail;
  logic [2:0] count;

  assign full  = (count == 3'd4);
  assign empty = (count == 3'd0);
  assign pop_data = mem[head[1:0]];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head  <= 3'd0;
      tail  <= 3'd0;
      count <= 3'd0;
    end else begin
      if (push && !full) begin
        mem[tail[1:0]] <= push_data;
        tail  <= tail + 3'd1;
        count <= count + 3'd1;
      end
      if (pop && !empty) begin
        head  <= head + 3'd1;
        count <= count - 3'd1;
      end
      if (push && !full && pop && !empty)
        count <= count;  // push and pop same cycle
    end
  end
endmodule
