# Bridge invariant discharge - methodology + what's-and-isn't kernel-proved in v2.5

## What's a bridge invariant + why does k-induction need one

EBMC k-induction starts from arbitrary post-reset states + checks that the equivalence holds for k consecutive cycles AND is preserved into cycle k+1. The naked output equality (e.g. `gold.full == gate.full`) is often NOT inductive on its own - k-induction can pick a state where the gold and gate state registers diverge (e.g. `gold.count = 2`, `gate.count = 3`) and from there the next-cycle equality fails. The bridge invariant ties the internal state registers together so k-induction starts from synchronized states.

For the v2 toy_fifo_chain `fifo_widget` instance, two of the three output equivalences (`full_match` + `empty_match`) hit the missing-inductive-invariant case under v2 EBMC. The v2.5 closed-loop runner produces the bridge invariants via LLM proposal + EBMC re-verification. *Whether the bridge itself is proved as a Lean theorem is a separate question* - and one v2.5 honestly answers: NO, not yet, v2.6 will.

## The two assumption stacks (v2.5 ships both, distinguishes between them)

### Stack 1 - gold-vs-gate equivalence under EBMC + LLM-proposed bridge

```
                 +---------------------------------------+
                 |  EBMC k-induction PROVED              |
                 |  (under assume property bridge_X)     |
                 +-----------------+---------------------+
                                   |
                  rests on the truth of:
                                   |
                                   v
                 +---------------------------------------+
                 |  bridge_X holds inductively across    |
                 |  the gold/gate Mealy step             |
                 +-----------------+---------------------+
                                   |
                          discharged by:
                                   |
                                   v
                 +---------------------------------------+
                 |  Pythia.Hardware.SEC.FifoWidget.      |
                 |  bridgeFullInv_holds_at_every_co_step |
                 |  (kernel-checked Lean, axiom-clean,   |
                 |   pythia#93 merged 2026-05-06)        |
                 +---------------------------------------+
```

Customer trust contract for stack 1: "I accept that EBMC's k-induction with assume-property is sound, AND I accept that the LLM-proposed bridge invariant holds across every co-step trace of (goldStep, gateStep). Both halves are now kernel-proved: EBMC discharges the with-assume verdict, and Lean's `bridge*Inv_holds_at_every_co_step` discharges the bridge itself."

### Stack 2 - impl-side flag-count consistency (kernel-proved in v2.5)

```
                 +---------------------------------------+
                 |  bridge_inv_full  (impl side):        |
                 |  s.full_flag = true                   |
                 |    iff  isFull (absFifoWidget s)      |
                 +-----------------+---------------------+
                                   |
                          proved by:
                                   |
                                   v
                 +---------------------------------------+
                 |  Pythia.Hardware.SEC.FifoWidget.      |
                 |  bridge_inv_full                      |
                 |  (kernel-checked Lean, axiom-clean)   |
                 +---------------------------------------+
```

Customer trust contract for stack 2: "I accept that Lean's kernel is sound + the axioms (`propext, Classical.choice, Quot.sound`) are accepted, AND I accept that `absFifoWidget` is the right abstraction function from impl-state to abstract spec-state. The theorem is kernel-checked, no sorry."

These are *separate assumption stacks*. Stack 1 is what the SEC-side closed-loop produces (EBMC k-induction with assume-property + Lean refinement of the bridge - both kernel-checked as of pythia#93). Stack 2 is the cto-side W2 impl-side flag-count theorems (kernel-checked truth about a different aspect of the design). All three theorems axiom-audit-clean.

## The two impl-side theorems

### `Pythia.Hardware.SEC.FifoWidget.bridge_inv_full`

**Statement** (Lean):
```
theorem bridge_inv_full {cap w : Nat}
    (s : FifoWidgetState cap w) (h_valid : isValidState s) :
    s.full_flag = true <-> isFull (absFifoWidget s)
```

**What it proves**: the impl-state's `full_flag` register is consistent with the abstract spec's `isFull` predicate evaluated on the abstracted impl-state. In SV terms: the impl's full output reflects the underlying count register correctly per the FIFO contract.

**Proof body**: `unfold isValidState; rw [h_valid.1]; exact decide_eq_true_iff` (per pythia#88 commit f335b88). Three lines; rests on `isValidState` carrying the count-fits-in-cap invariant.

**What it does NOT prove**:
* It does NOT prove the gold-side and gate-side designs have equal `full_flag` outputs.
* It does NOT prove the gold-side `mem[head[1:0]]` equals the gate-side packed-mem read.
* It does NOT prove anything about the dynamic step semantics (it's a per-state predicate, not a state-transition relation).

**Axioms used**: `propext`, `Classical.choice`, `Quot.sound` only. Customer can verify:

```sh
$ cd lean-spec/
$ lake env lean --run AxiomAudit.lean -- check_theorems
Pythia.Hardware.SEC.FifoWidget.bridge_inv_full uses [propext, Classical.choice, Quot.sound]
Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty uses [propext, Classical.choice, Quot.sound]
* all theorems clean (no sorryAx)
```

### `Pythia.Hardware.SEC.FifoWidget.bridge_inv_empty`

**Statement** (informal): analogous to `bridge_inv_full` for the empty-flag: `s.empty_flag = true <-> isEmpty (absFifoWidget s)`. Same proof shape.

**Axioms used**: same as `bridge_inv_full`.

## Why these two theorems are valuable customer-trust signal

Even though they don't discharge the SEC-side bridge invariants, the impl-side flag-count consistency theorems prove a property the customer cares about:

* *The impl's flags are not lying about the state.* `full_flag` going high when the count says full, and going low when the count says not-full, is a basic correctness property of the FIFO impl. Without this theorem, the impl's flag logic could be silently wrong (e.g., a count-comparator off-by-one would let `full_flag` lie); WITH this theorem, the customer has a kernel-checked proof that the flag logic is correct.

This is a CONSISTENCY proof on the impl alone, NOT an EQUIVALENCE proof against the gold spec. The equivalence proof (gold-vs-gate state correspondence) is the v2.6 deliverable.

## v2.6 path - what discharges the SEC-side bridges

Multi-day work properly under ATH-984/ATH-992:

1. *Define `flopFifoStep`* - Mealy step modeling `gold.sv`'s `always_ff` block: `(s_gold, input) -> (s_gold', output)`. Uses `logic [27:0] mem [4]` array semantics + 3-bit `head`/`tail`/`count`.
2. *Define `memFifoStep`* - Mealy step modeling `gate.v`'s register update logic with `reg [111:0] mem` packed semantics + `(3-i)*28+:28` slicing convention from the Clash `vector_replace` generate block.
3. *Prove `bridge_full`*: state-equality with bit-packing-correspondence is preserved across both step functions + implies `gold.full == gate.full` per step. 4 cases by `pushEff x popEff` cross-product; mem-equality reduction via `BitVec.set_get_eq` + `BitVec.set_get_neq`.
4. *Prove `bridge_empty`*: weaker - count + head + tail equality preserved + implies `gold.empty == gate.empty`.
5. *Populate `_CANONICAL_BRIDGE_THEOREMS`* in `kairos.sec.closed_loop._invariant_gen` with the new theorem names; assumption_stack() renders `[proved by <theorem_name>]`; cert v2.6 ships with the SEC-side bridges KERNEL-PROVED.

This is the full v2.6 roadmap shape - multi-day Lean modeling + theorem proof work, but the result is the customer-trust contract finally closed at the gold-vs-gate level.

## What the customer can audit in v2.5

1. *Re-run the closed-loop discharge* (requires `kairos>=0.x.y`):
   ```sh
   $ python3 -m kairos.sec.closed_loop._invariant_gen \
       --bundle inputs/ --target-property sec_miter.full_match
   ```
   Should produce `verdict_outcome=proved` + `proves_obligation=Pythia.Hardware.SEC.FifoWidget.bridgeFullInv_holds_at_every_co_step` (kernel-checked Lean theorem; pythia#93).

2. *Read the Lean source* in `lean-spec/`:
   * `FifoWidgetGoldGateInvariant.lean` - defines `FifoWidgetState`, `absFifoWidget`, `isValidState`, `bridge_inv_full`, `bridge_inv_empty`.
   * `AxiomAudit.lean` - runs `#print axioms` on each theorem.

3. *Cross-check operational semantics on the impl side*: customer reads the impl-side full-flag logic in `gate.v`'s `assign full_1 = count == 3'd4;` line + confirms it matches the proved theorem statement (the impl-flag does indeed track `count == cap`, which is what `isFull` of the abstracted state evaluates to).

4. *Read the EBMC log* (`sec-discharge-run/ebmc-induction-with-assume.log`) to see the assume-property injection + the positive-discharge verdict per property under the LLM-proposed bridges. The customer is reading a real EBMC verdict + the bridges are kernel-checked Lean theorems (pythia#93) - two parallel proof artifacts agreeing.

5. *Read the bridge invariants verbatim* in the EBMC log header. Decide if they are the gold-vs-gate state correspondence the customer expects for v2.6's theorem-discharge work.
