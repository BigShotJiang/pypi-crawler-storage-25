# v2.5 follow-up roadmap

The v2.5 cert closes the two INCONCLUSIVE properties on `fifo_widget`. What's next:

## v2.6 - add_header + arb_widget per-block certs

* `add_header` was gated in v2 on yosys-parse fix (its SV form has a `parameter int DEPTH` + `$clog2(DEPTH)` machinery that EBMC 5.10 crashes on). v2.6 specializes to a concrete-DEPTH=N variant + runs the SEC discharge under the same v2.5 closed-loop runner. Same shape as v2.5: bridge invariant proposed by LLM + EBMC closes + Lean theorem discharges.
* `arb_widget`'s round-robin safety obligation was gated in v2 on temporal-verifier (LIVENESS form). Per Todd's 2026-05-04 v2 lock-in, the SAFETY form ("each source served exactly once per round, no source served twice in a row before all served") is k-induction-tractable as a state-machine refinement against an abstract `RoundRobin` spec. v2.6 implements the abstraction + discharges via EBMC-induction with Lean refinement.

## v3.0 - post-VPC liberty + SDC + real Trainium silicon numbers

* Once Annapurna VPC onboarding completes, `KAIROS_LIBERTY_PATH` + `KAIROS_SDC_PATH` env vars bind to the customer-provided cell library + timing constraints. Same code path; just configuration.
* Yosys `synth_stat` + opensta timing report produce real cell counts + worst-slack-ns numbers (replacing the `<default>`-cell numbers from v2.5).
* Verilator power-toggle counts get a real liberty-aware power-analysis pass (or stay as the toggle-proxy with the explicit "power proxy, not liberty-aware" tag).
* The customer-block-certificate gains a PPA section reporting baseline + measured + delta for each axis (third-instance honest-framing per `PpaAxisDelta`).

## v3.1 - closed-loop optimization arc on customer-chosen blocks

* The PPA-loop (ATH-988): proposer suggests area-reducing variants on a target block; ranker scores targets; orchestrator runs propose -> verify -> measure -> compare; PPA-comparator picks a winner under customer-tunable weights with timing-floor enforcement.
* Customer-block-certificate gains an "optimization arc" section: which proposals were tried, which closed equivalence, which won the PPA comparison, why.
* The autonomous-loop discipline (per Todd's 2026-05-05 spec): customer reviews final winner (or top-3 candidates), not every intermediate step.

## v4.0+ - broader transformation classes + LLM-judgment overlay

* Today the proposer's transformation taxonomy is parameterization / structural / impl-swap. Future expansions: CDC primitives, retiming pragmas, datapath restructuring, AXI4-Lite / AXI4-Stream-aware optimizations.
* Today the stim_gen classifier is 4-templates-only with structured `AmbiguousPortClassification` error per Todd's 2026-05-05 spec. v4 evaluates whether to add an LLM-judgment-with-confidence fallback once the hallucination-risk bar is cleared (e.g. via expanded test fixtures + structural-equivalence checking on classifications).
* Today's `_CANONICAL_BRIDGE_THEOREMS` registry is a hand-maintained dict mapping `target_property -> theorem_name`. v4 generalizes via a structural-equivalence check on SV-expression vs theorem's pinned-shape, fail-loud on drift (already filed as v1 hardening forward-pin).

## Catalog-list integration (carry over from v2)

`/analytics/silicon-blocks/[run_id]` per-block page renders from the SEC pivot card surface (ATH-987). v2.5 run_id renders the same dual-mode-matrix shape with the new closed-loop-invariant-discharge column added. No platform-side schema change required - the IterationRecord type extension (ATH-993 phase 3 + 4) carries the new fields nullable; the SEC v2.5 case populates the new columns when the closed-loop runner runs.

## When this v2.5 ships

Sam-approval-gated per `feedback_no_customer_ship_without_aidan_approval.md`. The v2.5 cert is build-first-respond-later; the closed-loop infrastructure (D-spike runner PR #480 + the `_CANONICAL_BRIDGE_THEOREMS` registry + the assumption-stack-disclosure renderer + the build-tarball Gate 4c) all need to be merged + the live discharge run on the tahoe runner needs to produce the `[TBD]` run_id before this cert can ship to Todd.

cto tone-pass + Sam approval per the standing rule.
