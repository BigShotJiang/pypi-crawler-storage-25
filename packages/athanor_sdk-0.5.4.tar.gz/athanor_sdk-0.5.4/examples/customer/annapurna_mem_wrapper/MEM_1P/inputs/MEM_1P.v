//------------------------------------------------------------------------
// Behavioral RAM model (Single Port)
// Date: 11/08/2017
// Author: Amit Pandey
//------------------------------------------------------------------------

`timescale 1 ns / 1 ps 

module MEM_1P ( Q, QP, ADR, D, WE, WEM, ME, CLK );

parameter DATA_WIDTH = 16;
parameter MEM_DEPTH  = 128;
parameter ADDR_WIDTH = 7;

output [DATA_WIDTH-1:0] Q;
output [DATA_WIDTH-1:0] QP;
input  [ADDR_WIDTH-1:0] ADR;
input  [DATA_WIDTH-1:0] D;
input                   WE;
input  [DATA_WIDTH-1:0] WEM;
input                   ME;
input                   CLK;

reg  [DATA_WIDTH-1:0] mem_core_array [0:MEM_DEPTH-1];
reg  [DATA_WIDTH-1:0] rddata;
reg  [DATA_WIDTH-1:0] rddata_q;
wire [DATA_WIDTH-1:0] Q;
wire [DATA_WIDTH-1:0] QP;


always @(posedge CLK) begin 
        if (ME & WE ) 
           mem_core_array[ADR] <= (mem_core_array[ADR] & ~WEM) | (D & WEM); 
end 

always @(posedge CLK) begin 
   if (ME & ~WE) begin
          rddata <= mem_core_array[ADR]; 
   end 
end 

always @(posedge CLK) 
   rddata_q <= rddata;

assign Q  = rddata;
assign QP = rddata_q;

endmodule
