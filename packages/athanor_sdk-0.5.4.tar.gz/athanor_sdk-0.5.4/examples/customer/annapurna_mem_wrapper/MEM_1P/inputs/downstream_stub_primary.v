//------------------------------------------------------------------------
// Downstream consumer stub for MEM_1P (ATH-1064 Phase 3 v0).
//
// Models a single downstream client that reads MEM_1P's Q output on a
// subset of cycles. The customer-engineer (qa as pretend) authors this
// stub to declare WHICH cycles their downstream pipeline actually
// consumes Q[t]. The kairos.sec.power_gating proof harness uses
// consume_signal as the temporal predicate for the free-Q-on-non-consume
// abstraction:
//
//   - On cycles where consume_signal[t] == 1'b1: gate's Q[t] must
//     observably equal gold's Q[t] (downstream sees same data).
//   - On cycles where consume_signal[t] == 1'b0: gate's Q[t] is free
//     (gold reads memory + produces a real Q; gate may have gated ME
//     and produces don't-care). The proof harness treats Q as a free
//     variable in those cycles.
//
// observable_out is the externally-visible signal the equivalence
// assertion checks. For this v0 stub: a registered version of Q latched
// on consume cycles. Customer engineers using power_gating on their own
// blocks would author the analogous stub for their downstream pipeline
// (FIFO push, AXI read response, register file write, etc.).
//
// Memory latency: MEM_1P has 1-cycle Q latency (rddata register clocks
// on posedge after read request). consume_signal[t] is asserted on the
// CYCLE THE CONSUMER LATCHES Q, which is t = read_request_cycle + 1.
//
// Stub-completeness assumption (UNPROVEN-as-Lean per cert prose
// honest-framing): this stub captures the ONLY consumer of MEM_1P's Q
// output. If a real downstream module reads Q[t] under a condition not
// modeled here, the equivalence does not transfer. Customer-engineer
// is responsible for stub-completeness audit per resolved-decision #1
// of docs/internal/ath-1064-power-gating-design.md (engineer-authored
// stub, NOT auto-inferred).
//------------------------------------------------------------------------

`timescale 1 ns / 1 ps

module downstream_stub_primary
#(
    parameter DATA_WIDTH = 16
)
(
    input  wire                   CLK,
    input  wire                   RSTN,

    // Q from MEM_1P (read data, 1-cycle latency post-ME).
    input  wire [DATA_WIDTH-1:0]  Q,

    // consume_signal: asserted on the cycle when the downstream pipeline
    // latches Q. The kairos.sec.power_gating harness uses this as the
    // temporal predicate for the free-Q-on-non-consume abstraction.
    input  wire                   consume_signal,

    // observable_out: externally-visible signal the equivalence
    // assertion checks. Latched copy of Q, valid only on the cycle
    // after consume_signal asserted.
    output wire [DATA_WIDTH-1:0]  observable_out,

    // observable_valid: companion strobe. Asserted one cycle after
    // consume_signal so the equivalence assertion knows when
    // observable_out is meaningful.
    output wire                   observable_valid
);

    reg [DATA_WIDTH-1:0] latched_q;
    reg                  latched_valid;

    always @(posedge CLK or negedge RSTN) begin
        if (!RSTN) begin
            latched_q     <= {DATA_WIDTH{1'b0}};
            latched_valid <= 1'b0;
        end else if (consume_signal) begin
            // Latch Q on consume cycles. Q value on non-consume cycles
            // is don't-care from the equivalence perspective; the proof
            // harness treats it as free.
            latched_q     <= Q;
            latched_valid <= 1'b1;
        end else begin
            latched_valid <= 1'b0;
        end
    end

    assign observable_out   = latched_q;
    assign observable_valid = latched_valid;

endmodule
