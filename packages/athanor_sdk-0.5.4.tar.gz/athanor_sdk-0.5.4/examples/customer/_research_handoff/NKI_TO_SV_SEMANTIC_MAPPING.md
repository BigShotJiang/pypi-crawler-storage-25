# NKI kernel → SystemVerilog semantic mapping (Layer 2 EBMC k-induction handoff)

**Filed**: 2026-05-07 by cto · **Ticket**: ATH-1098 (child of ATH-1093) · **qa next-session pickup**: `kairos.sec.preprocess` + `kairos.sec.signature_gen` wiring after this doc lands.

This document is the cto half of the cto+qa pair on Layer 2 of the multi-prover trust stack. It specifies how each NKI kernel construct maps onto a SystemVerilog model that EBMC + ACL2 can ingest via existing `kairos.sec.*` infrastructure. **Goal**: NO new prover infra; the NKI bundle becomes a kairos.sec input alongside Annapurna RTL.

## Why a SystemVerilog target

Three reasons:

1. **Reuse**. `kairos.ebmc.verify`, `kairos.acl2.run_acl2` + `parse_sv`, `kairos.sec.smoke.smoke_validate`, `kairos.prove.prove` already accept SystemVerilog. Zero new prover plumbing.
2. **Kroening-grade**. EBMC is Kroening's tool. K-induction over an SV model is the trust signal his team will recognize fastest.
3. **Convergent invariants**. Lean proves `kv_cache_get_preserved` abstractly; EBMC k-inducts the SAME invariant on the SV model concretely. Two independent prover technologies, same claim. That is the customer-facing pitch.

## Mapping table (NKI construct → SV construct)

| NKI construct | SV semantic | Notes |
|---|---|---|
| `nl.sequential_range(N)` outer loop | clocked counter `logic [LOG2N-1:0] tile_idx` advancing on `posedge clk` | seqlen-derived `N` is a `parameter`; matches kairos.sec.signature_gen `parameter_overrides` flow |
| `nl.affine_range(N)` parallel loop | unrolled SV `for genvar` block | unroll bound = compile-time-known; same as kairos preprocessing of Annapurna RTL `for(genvar i=0; i<N; i++)` |
| `running_max`, `running_sum`, `running_out` | flop-per-partition `logic [PMAX-1:0][31:0] reg_running_max` | one flop per running-stat per row partition; reset to NEG_INF/0/0 |
| `nisa.nc_matmul(stationary, moving)` | combinational dot-product `function automatic logic [31:0] [PMAX*PMAX-1:0] nc_matmul(...)` (or behavioral SV with `assign psum_out = ...`) | EBMC sees the dataflow; we don't model the actual PE array timing — just the algorithmic shape |
| `nisa.tensor_copy(src)` | wire-pass `assign dst = src` | combinational; SV optimizer collapses |
| `nisa.tensor_reduce(op=nl.maximum)` | combinational `max_tree` | unrolled; tree-depth = log2(PMAX) |
| `nisa.activation(op=nl.exp, bias=neg_max)` | uninterpreted function `function automatic logic [31:0] activation_exp(input [31:0] x, input [31:0] bias)` | EBMC treats as black box; equivalence is on stateful flow, not transcendental functions. For algebraic equivalence (Lean Layer 1) the function is interpreted. |
| `nisa.scalar_tensor_tensor(data, op0, op0_v, op1, op1_v)` | combinational fused-MAC `(data op0 op0_v) op1 op1_v` as one assignment | single-cycle datapath; PMAX-wide, so a generate block over partition |
| `nisa.affine_select(pred, on_true, on_false_value)` | combinational `assign masked = pred ? on_true : on_false_value` | causal mask — pred is purely affine in tile-local r,c so EBMC parses cleanly |
| `nisa.reciprocal(data)` | uninterpreted function `function automatic logic [31:0] reciprocal_(...)` | same as activation_exp — black box for control-flow proofs |
| `nl.psum` allocation | bram-shaped reg array `logic [31:0] psum_mem [0:PSUM_DEPTH-1]` | addressable; track read-before-write via shadow valid bit `psum_valid[idx]` |
| `nl.shared_hbm` allocation | similar bram-shaped reg array, larger | parameter `HBM_DEPTH` |
| `nl.load(hbm_buf)` / `nl.store(hbm_buf, val)` | one-cycle handshake to/from `hbm_mem` | model as posedge-clk read/write; the latency model is irrelevant for k-induction |
| `nl.full(...)`, `nl.zeros(...)` | reset-state initialization | always_ff posedge clk negedge rst |

## Invariants to k-induct on

These are the claims EBMC k-induction discharges for each kernel. Each maps to a Lean theorem in the bundle's spec/, providing the convergence-on-overlapping-invariants pitch.

### Universal (all 4 NKI bundles)

```systemverilog
// running_max_monotone
property running_max_monotone;
  @(posedge clk) disable iff (rst)
    (tile_idx > 0) |-> (reg_running_max >= $past(reg_running_max));
endproperty
assert property (running_max_monotone);
```
> Lean counterpart: implicit in `online_softmax_eq_offline` exact-arithmetic equivalence; running max is the running supremum.

```systemverilog
// running_sum_nonneg
property running_sum_nonneg;
  @(posedge clk) disable iff (rst)  reg_running_sum >= 0;
endproperty
assert property (running_sum_nonneg);
```
> Lean counterpart: by-construction (sum of exps is non-negative).

```systemverilog
// psum_no_uninit_read
property psum_no_uninit_read;
  @(posedge clk)
    psum_read_en |-> psum_valid[psum_read_addr];
endproperty
```
> Memory-safety; no Lean counterpart needed (safety property of the SV model).

### Bundle 2 (`nki_attention_causal_online_demo`)

```systemverilog
// causal_skip_holds — i_tile_kv > i_tile_q ⇒ no nc_matmul fired
property causal_skip_holds;
  @(posedge clk) disable iff (rst)
    (kv_tile_idx > q_tile_idx) |-> !nc_matmul_en;
endproperty
```
> **Lean counterpart**: `Pythia.Numerical.CausalMask.causal_mask_eq_partial_softmax` (research closed sorry-free 2026-05-07). EBMC k-inducts the *control-flow* form; Lean proves the *algebraic* form. Same claim, two prover technologies.

### Bundle 4 (`nki_attention_kv_cache_decode_demo`)

```systemverilog
// kv_cache_append_only — cache writes only at the next-slot index, never aliasing
property kv_cache_append_only;
  @(posedge clk) disable iff (rst)
    cache_write_en |-> (cache_write_addr == cache_len_at_step);
endproperty

// kv_cache_get_preserved — earlier-index reads return the same value across appends
property kv_cache_get_preserved(int i);
  @(posedge clk) disable iff (rst)
    (i < cache_len_prev) |-> (cache_mem[i] == $past(cache_mem[i]));
endproperty
```
> **Lean counterpart**: `Pythia.Numerical.KVCache.kv_cache_get_preserved` (research closed sorry-free 2026-05-07). EBMC k-inducts memory-aliasing; Lean proves the algebraic prefix-stability. Same claim — the killer pitch sentence for Kroening: "kv_cache_get_preserved proven by Lean abstractly + EBMC k-induction concretely on the *exact same claim*."

## SystemVerilog parameter conventions (compatible with `kairos.sec.signature_gen`)

```systemverilog
module attn_fwd_v3_online_skel #(
    parameter int unsigned PMAX             = 128,   // = nl.tile_size.pmax
    parameter int unsigned FMAX_STATIONARY  = 128,   // = nl.tile_size.gemm_stationary_fmax
    parameter int unsigned FMAX_MOVING      = 512,   // = nl.tile_size.gemm_moving_fmax
    parameter int unsigned SEQLEN           = 4096,
    parameter int unsigned D_HEAD           = PMAX,
    // concrete_for_sec values pinned by parameter_overrides per ATH-1082
    parameter int unsigned NUM_TILE_Q       = SEQLEN / PMAX,
    parameter int unsigned NUM_TILE_KV      = SEQLEN / PMAX
) (
    input  logic clk,
    input  logic rst,
    input  logic start,
    output logic done,
    // ... q/k/v/out HBM ports
);
```

`signature.json` follows the `AP_REG_FIFO_US` multi-module pattern qa specified — a `dep_files` registry listing the SV skeleton + any uninterpreted-function stubs (`activation_exp.sv`, `reciprocal_.sv`), `formal_invariants_primer` for the mask-predicate + PSUM invariants, `parameter_overrides` for tile/kv dimensions matching the bundle's verify_nki.py seqlen sweep ({512, 1024, 2048, 4096}).

## Prototype scope (cto, on top of this doc)

- `examples/customer/nki_attention_v3_online_demo/sv/attn_fwd_v3_online_skel.sv` — SV transpilation of the v3_online kernel covering: q/k/v load, kv-tile sweep, running-stats update, final divide.
- `examples/customer/nki_attention_v3_online_demo/sv/attn_fwd_v3_online_props.sv` — SVA property bindings for `running_max_monotone`, `running_sum_nonneg`, `psum_no_uninit_read`.
- `examples/customer/nki_attention_v3_online_demo/sv/signature.json` — kairos.sec signature in the AP_REG_FIFO_US format.
- `examples/customer/nki_attention_v3_online_demo/bench_ebmc.py` — calls `kairos.sec.smoke.smoke_validate` on the SV form, captures verdicts to `reports/ebmc_summary.json`.

## qa pickup scope (next session, on top of cto's prototype)

- Generalize `kairos.sec.preprocess` to detect the new `examples/customer/nki_*/sv/` shape as a valid kairos.sec input (currently only Annapurna basic_cells/mem_wrapper paths are recognized).
- Generalize `kairos.sec.signature_gen` to auto-stub the dep_files registry + formal_invariants_primer for NKI bundles given a kernel name + tile dimensions.
- Wire the per-bundle bench_ebmc.py into a fleet test harness similar to the kairos.sec.smoke pre-fire validation cadence.
- Roll the SV transpilation pattern out to bundles 2-4 once v3_online clears.

## Unknowns / decisions for qa

1. **`activation_exp` / `reciprocal_` semantics**: leave as uninterpreted functions for EBMC (k-induction proves control-flow + monotonicity) OR provide a finite SV approximation for ACL2 algebraic equivalence? Suggestion: uninterpreted for EBMC + FP-bounded for ACL2 + interpreted-Real for Lean. Each prover technology gets the right granularity.

2. **PSUM modeling depth**: shadow `psum_valid[]` bit per address (cheap k-induction) or full `psum_mem[]` array (expensive but catches aliasing classes)? Suggestion: shadow valid bit for v3_online, escalate to full array if EBMC misses an alias case.

3. **Real-arithmetic vs FP32 in the SV model**: EBMC over FP32 is hard. Suggestion: model as bounded-int with explicit overflow semantics for the running-stats invariants; the FP32 bound is Lean Layer 1's job, not Layer 2's.

## Cross-references

- Parent epic: ATH-1093 (Neuron NKI flagship)
- This ticket: ATH-1098
- Multi-prover thread: #dev-research thread under slack ts 1778172801
- Layer 1 (Lean): research closed sorry-free 2026-05-07 in `research/merge-all-session-work` under `Pythia/Numerical/Accelerator/`
- Layer 5 (Z3): research bench_z3.py — all 4 bundles UNSAT (commit ed5c9ef)
- Layer 6 (simulator): cto verify_nki.py for v3_online + causal_online (prior commits 469e7b5 + 22d8d01)
- Existing kairos.sec infra: `src/kairos/ebmc.py`, `src/kairos/acl2.py`, `src/kairos/sec/smoke.py`, `src/kairos/sec/preprocess.py`, `src/kairos/sec/signature_gen.py`
- AP_REG_FIFO_US pattern qa is matching: `examples/customer/annapurna_basic_cells/AP_REG_FIFO_US/`
