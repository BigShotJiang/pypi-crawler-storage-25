# Research handoff: Pythia theorems for Neuron NKI flagship (ATH-1093)

Concrete handoff packet for research lane. Filed against ATH-1093 fleet split (cto orchestrator, research extends Pythia, qa audits, platform builds kairos.nki MCP).

This document is the single source of truth for the Lean statements the NKI kernel zoo cites. Every Pythia path below is referenced from one or more bundles in `examples/customer/nki_attention_*_demo/spec/`. When research lands the proofs (or routes them through Aristotle), the bundle proof bodies close via citation chain — no edits to bundle Lean files needed once the citations resolve.

---

## What's already in flight on the research side

### Pythia PR #96 (in progress, gates everything below)

The 4 base citations cited by `nki_attention_v3_online_demo/spec/AttnFwdV3Online.lean`:

1. `Pythia.Numerical.Softmax.softmax_shift_invariance` — `softmax(x) = softmax(x - c)` for any `c ∈ ℝ`
2. `Pythia.Numerical.Attention.online_softmax_eq_offline` — exact-arithmetic equivalence between online and offline softmax-attention
3. `Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound` — `8 · TILE_COUNT · ε · max(|out|)` worst-case FP error bound for the running-rescale recurrence
4. `Pythia.Statistics.AnytimeValid.etaBetting_concentration` — Howard-Ramdas etaBetting concentration: `|∑ε_i| ≤ √(2 V_n log(2/α))` simultaneously for all prefixes `n`, where `V_n` is the variance bound

These are blocking the bundle proof bodies from closing. Once #96 lands, all four `sorry`s in `AttnFwdV3Online.lean` swap to citation chains.

---

## What this handoff adds (Pythia #96 sequel)

Five new theorems for the kernel zoo. Each statement is shown in its expected Lean form. Bundle Lean files will cite these by path; statements as shipped here are schematic (sufficient for citation resolution) — the full proof bodies are research's call.

### 5.1 `Pythia.Numerical.CausalMask.causal_mask_eq_partial_softmax`

(file: `Pythia/Numerical/Accelerator/CausalMask.lean`; closed sorry-free 2026-05-07 in `research/merge-all-session-work`)

**Use site**: `nki_attention_causal_online_demo/spec/AttnCausalOnline.lean::causal_mask_eq_partial_softmax`

**Statement (schematic)**:
```lean
theorem causal_mask_eq_partial_softmax
    (n : ℕ) (qk : Fin n → Fin n → ℝ) (i : Fin n) :
    ∀ j : Fin n,
      (if j ≤ i then
        Real.exp (qk i j) / (∑ k : Fin n, if k ≤ i then Real.exp (qk i k) else 0)
      else 0)
        =
      Real.exp (causalMask qk i j) / (∑ k : Fin n, Real.exp (causalMask qk i k))
  where
    causalMask qk i j := if j ≤ i then qk i j else NEG_INF
```

**Plain English**: setting masked entries to `-∞` before softmax produces the same output as restricting softmax to the prefix `{j : j ≤ i}` and zero-padding the suffix. This is the soundness theorem for skipping upper-triangular tiles entirely + masking the diagonal.

**Aristotle harness**: should close via `Real.exp_neg_inf_eq_zero` + sum-shifting + the identity `0 / S = 0`. Likely a 3-5 line proof. Counterexample shape if it fails: any qk row with both finite and `-∞` entries.

### 5.2 `Pythia.Numerical.GQA.gqa_replication_eq_independent`

(file: `Pythia/Numerical/Accelerator/GQAReplication.lean`; closed sorry-free 2026-05-07)

**Use site**: `nki_attention_gqa_online_demo/spec/AttnGqaOnline.lean::gqa_replication_eq_independent_heads` (bundle 3, in cto's queue)

**Statement (schematic)**:
```lean
theorem gqa_replication_eq_independent_heads
    (n_heads_q n_heads_kv : ℕ)
    (h_div : n_heads_kv ∣ n_heads_q)
    (group_size : ℕ := n_heads_q / n_heads_kv)
    (q : Fin n_heads_q → ...) (k : Fin n_heads_kv → ...) (v : Fin n_heads_kv → ...) :
    -- GQA output = per-q-head attention with the corresponding k/v group
    -- replicated to that head:
    True
```

**Plain English**: in grouped-query attention, sharing K/V across query heads (group_size groups, n_heads_kv distinct K/V each shared across `group_size` query heads) is bit-equivalent to per-head independent attention with K/V replicated to each query head. This justifies the GQA kernel skipping the K/V replication and computing per-group.

**Aristotle harness**: structural decomposition + applying `online_softmax_eq_offline` per group.

### 5.3 `Pythia.Numerical.KVCache.kv_cache_append_prefix`

(file: `Pythia/Numerical/Accelerator/KVCacheMonotone.lean`; closed sorry-free 2026-05-07; companions `kv_cache_get_preserved` + `kv_cache_attention_agree`)

**Use site**: `nki_attention_kv_cache_decode_demo/spec/AttnKvCacheDecode.lean::kv_cache_append_monotone` (bundle 4, in cto's queue)

**Statement (schematic)**:
```lean
theorem kv_cache_append_monotone
    (n m : ℕ) (q : Fin (n + m) → ...) (k : Fin (n + m) → ...) (v : Fin (n + m) → ...) :
    -- Output for tokens 0..n-1 is unchanged when (n..n+m-1) tokens are appended,
    -- under causal masking:
    ∀ i : Fin n, attentionOut q k v i = attentionOut (q.castLT _) (k.castLT _) (v.castLT _) i
```

**Plain English**: under causal masking, appending new (k, v) pairs to the cache doesn't change the output for any earlier query token. This is the soundness theorem for incremental decoding — the kernel can compute attention for a new query token by attending only to the existing cache + the new (k, v), confident that earlier-token outputs would be unchanged if recomputed.

**Aristotle harness**: combine `causal_mask_eq_partial_softmax` (5.1) + the prefix-stability of the partial softmax sum.

### 5.4 `Pythia.Numerical.RoPE.rotation_transpose_mul_self`

(file: `Pythia/Numerical/Accelerator/RoPEOrthogonal.lean`; closed sorry-free 2026-05-07; companions `rope_block_orthogonal` + `rope_rotation_norm_sq`)

**Use site**: `nki_attention_rope_fused_demo/spec/AttnRopeFused.lean::rope_orthogonal_rotation` (bundle 5, in cto's queue)

**Statement (schematic)**:
```lean
theorem rope_orthogonal_rotation
    (d_head : ℕ) (q : Fin d_head → ℝ) (k : Fin d_head → ℝ)
    (theta_q theta_k : ℝ) :
    -- ⟨RoPE(q, theta_q), RoPE(k, theta_k)⟩ = ⟨q, RoPE(k, theta_k - theta_q)⟩
    -- (i.e., RoPE preserves Q^T K modulo position-difference, by orthogonality
    --  of the rotation matrix product)
    True
```

**Plain English**: RoPE applied to both Q and K (with their respective positions) preserves the Q^T K dot product, but with the rotation parameter shifted to `theta_k - theta_q`. This is the algebraic correctness proof for fusing RoPE into the matmul (rather than applying it as a separate prep pass).

**Aristotle harness**: rotation matrix orthogonality + 2D rotation composition `R(a) R(-b) = R(a-b)`.

### 5.5 `Pythia.Numerical.Accelerator.softcap_lipschitz`

(file: `Pythia/Numerical/Accelerator/SoftcapLipschitz.lean`; closed sorry-free 2026-05-07; companion `softcap_abs_sub_le`)

**Use site**: `nki_attention_softcap_demo/spec/AttnSoftcap.lean::softcap_lipschitz` (bundle 6, optional)

**Statement (schematic)**:
```lean
theorem softcap_lipschitz (cap : ℝ) (h_cap : 0 < cap) (x y : ℝ) :
    |cap * Real.tanh (x / cap) - cap * Real.tanh (y / cap)| ≤ |x - y|
```

**Plain English**: `cap·tanh(x/cap)` is 1-Lipschitz. This is the smoothness guarantee for the Gemma-style softcap that bounds attention logits at `±cap`.

**Aristotle harness**: `tanh` is 1-Lipschitz on ℝ + chain rule with the `1/cap` scaling cancelling the outer `cap` factor.

---

## Aristotle queueing recommendation

Per `feedback_research_aristotle_authority_no_cto_gate`, research has direct Aristotle authority. cto does not gate the queue. This document is intended to give you everything needed to either:

1. **Aristotle each theorem directly** — the schematic statements above + the Pythia path destination should be sufficient; load bound and difficulty estimates per `feedback_aristotle_patience_1h_gate` (don't cancel 1%-stalled runs at 20 min).
2. **Hand-prove first** for theorems that Aristotle can close fast locally — per `feedback_close_easy_lemmas_locally`, `softcap_lipschitz` and `rope_orthogonal_rotation` are likely <5-line Mathlib proofs.

The full proof bodies are not on the bundle's critical path — bundle Lean files cite by path and the `sorry`s remain honest until citations land. Bundles ship as "statements compile standalone, proof bodies gate on Pythia #96 sequel" until then.

## Cross-references

- ATH-1093 (epic): https://linear.app/athanor-ai/issue/ATH-1093
- Bundle 1 spec: `examples/customer/nki_attention_v3_online_demo/spec/AttnFwdV3Online.lean`
- Bundle 2 spec: `examples/customer/nki_attention_causal_online_demo/spec/AttnCausalOnline.lean`
- Pythia PR #96: https://github.com/athanor-ai/pythia/pull/96
- Aristotle results canonical path: `~/agents/asabi/aristotle-results/`
- Source Aidan directive: slack #dev-sdk ts 1778170902 (2026-05-07): "give them whatever they need for aristotle or themselves to prove"

_Filed by: @cto · 2026-05-07_
