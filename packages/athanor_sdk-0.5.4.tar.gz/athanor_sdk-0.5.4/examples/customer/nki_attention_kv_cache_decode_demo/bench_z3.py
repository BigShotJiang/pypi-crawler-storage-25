"""Layer 5 — Z3 finite-precision spot-check for attn_kv_cache_decode.

KV-cache decode: single query attends over cached KV of length
cache_len. TILE_COUNT = ceil(cache_len / TILE_KV).

Bound: |err|_∞ ≤ 8 · TILE_COUNT · ε_fp32 · max(|out|)

Run:
    python3 bench_z3.py [--timeout 120]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from z3 import RealVal, Real, Solver, sat, unsat, If

HERE = Path(__file__).resolve().parent
REPORTS_DIR = HERE / "reports"

EPS_FP32 = 2.0 ** -23
TILE_KV = 128

SHAPES = [
    {"cache_len": 16, "d_head": 8},
    {"cache_len": 32, "d_head": 8},
    {"cache_len": 64, "d_head": 8},
    {"cache_len": 128, "d_head": 8},
]

INPUT_MAGNITUDE_BOUND = 10.0


def z3_abs(x):
    return If(x >= 0, x, -x)


def check_bound(cache_len: int, d_head: int, timeout_s: int = 120) -> dict:
    tile_count = max(1, (cache_len + TILE_KV - 1) // TILE_KV)
    eps = RealVal(EPS_FP32)
    bound_coeff = RealVal(8 * tile_count) * eps

    s = Solver()
    s.set("timeout", timeout_s * 1000)

    out_max = Real("out_max")
    s.add(out_max > 0)
    s.add(out_max <= INPUT_MAGNITUDE_BOUND)

    err_accum = RealVal(0)
    for tile_idx in range(tile_count):
        tile_err = Real(f"tile_err_{tile_idx}")
        correction = Real(f"correction_{tile_idx}")
        s.add(z3_abs(tile_err) <= eps * out_max)
        s.add(correction >= 0)
        s.add(correction <= 1)
        err_accum = err_accum * correction + tile_err

    s.add(z3_abs(err_accum) > bound_coeff * out_max)

    t0 = time.monotonic()
    result = s.check()
    elapsed = time.monotonic() - t0

    verdict = {
        "shape": f"cache_len={cache_len}, d_head={d_head}",
        "tile_count": tile_count,
        "result": str(result),
        "elapsed_s": round(elapsed, 3),
    }

    if result == sat:
        model = s.model()
        verdict["counterexample"] = {str(d): str(model[d]) for d in model.decls()}
        verdict["status"] = "FAIL"
    elif result == unsat:
        verdict["status"] = "PASS"
    else:
        verdict["status"] = "UNKNOWN"

    return verdict


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    REPORTS_DIR.mkdir(exist_ok=True)
    results = []
    all_pass = True

    print("=" * 60)
    print("Layer 5 — Z3 spot-check: attn_kv_cache_decode")
    print("Bound: |err|_∞ ≤ 8 · TILE_COUNT · ε_fp32 · max(|out|)")
    print("=" * 60)

    for shape in SHAPES:
        print(f"\nChecking cache_len={shape['cache_len']}, d_head={shape['d_head']}...")
        verdict = check_bound(shape["cache_len"], shape["d_head"], args.timeout)
        results.append(verdict)
        status = verdict["status"]
        print(f"  tile_count={verdict['tile_count']}, result={verdict['result']}, "
              f"elapsed={verdict['elapsed_s']}s → {status}")
        if status != "PASS":
            all_pass = False
            if "counterexample" in verdict:
                print(f"  COUNTEREXAMPLE: {verdict['counterexample']}")

    summary = {
        "bundle": "attn_kv_cache_decode",
        "layer": 5, "prover": "Z3",
        "bound": "8 * TILE_COUNT * eps_fp32 * out_max",
        "all_pass": all_pass,
        "shapes": results,
    }
    out_path = REPORTS_DIR / "z3_summary.json"
    out_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(f"\nSummary: {out_path}")
    if not all_pass:
        sys.exit(1)
    print("\n✓ ALL SHAPES UNSAT — bound holds.")


if __name__ == "__main__":
    main()
