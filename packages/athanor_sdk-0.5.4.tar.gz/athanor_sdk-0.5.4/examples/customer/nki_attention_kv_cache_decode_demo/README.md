# nki_attention_kv_cache_decode_demo

Engineer-facing entry. For customer-facing pitch see `CUSTOMER_README.md`.

## What

Single-query online-softmax decode kernel for production autoregressive LLM serving. Plus the Lean theorem `kv_cache_append_monotone` certifying that appending K/V cache entries doesn't change earlier-token outputs (incremental-decode soundness).

## Files

```
nki_attention_kv_cache_decode_demo/
├── README.md                       ← this file
├── CUSTOMER_README.md              ← customer-facing pitch
├── baseline.py                     ← single-query OFFLINE softmax decode
├── improved.py                     ← single-query ONLINE softmax decode
├── reference.py                    ← float64 ground truth
├── verify.py                       ← 6 test classes
├── spec/
│   └── AttnKvCacheDecode.lean      ← 5 theorems incl. kv_cache_append_monotone
└── reports/
    ├── summary.json
    └── test_report.json
```

## Run

```bash
cd examples/customer/nki_attention_kv_cache_decode_demo
python3 verify.py
```

## Status

- numpy verify.py: 6/6 PASS — basic_shape / first_position (cache_len=1 returns v[:, 0]) / append_monotone_skipped (theorem is broader-decode-loop property, see spec) / 16-trial differential at seqlen 512 + 2048 / total_decode_savings (cumulative HBM ratio over 1024 decode steps)
- Lean theorems: 5 statements compile standalone, proof bodies sorry-flagged. Gates on Pythia PR #96 sequel.
- @nki.jit kernel reuse: uses `attn_fwd_v3_online` from bundle 1 restricted to seqlen_q=1; simulator validation transfers directly.

## Lean theorems

1. `softmax_shift_invariance` — inherited
2. `kv_cache_append_monotone` — *new* fundamental soundness theorem
3. `decode_online_eq_offline_exact`
4. `decode_online_eq_offline_bounded`
5. `decode_online_eq_offline_av_bounded`

## Cross-refs

- ATH-1093 (Linear) — NKI flagship epic
- Sibling: `nki_attention_v3_online_demo/`
- Sibling: `nki_attention_causal_online_demo/` (composes naturally with this decode pattern)
