# KV-cache decode kernel — single-query online softmax over cached prefix

## What this package proposes

The production decode kernel for autoregressive LLM serving: at each inference step, ONE new query token attends to the FULL existing K/V cache. The naive implementation recomputes full causal attention from scratch every step (`O(t^2)` work per step over `t` cached tokens, `O(t^3)` cumulative for `t` decode steps). The improved kernel uses the cache directly + online softmax for the single new query — `O(t)` per step, `O(t^2)` cumulative.

This is the inference critical path for every decoder-only LLM in production (Llama, Qwen, Mistral, GPT, Claude, Gemini).

The novel theorem is `kv_cache_append_monotone`:
> Under causal masking, appending new `(k, v)` pairs to the cache does NOT change the attention output for any earlier query token.

This is what makes incremental decode sound — you can compute attention for a new query at position `n` against a cache of length `n`, confident that recomputing earlier-position attention with the same (now-truncated) cache prefix yields identical output. The kernel is built on this guarantee.

## What's in this package

| File | Role |
|---|---|
| `baseline.py` | Single-query offline-softmax decode (full QK row materialized). The intra-decode-step equivalence target. |
| `improved.py` | Single-query online-softmax decode (running stats, no full QK). Production-shape kernel. |
| `reference.py` | float64 ground truth via full causal attention; returns the new-position row only. |
| `spec/AttnKvCacheDecode.lean` | 5-theorem Lean spec including `kv_cache_append_monotone`. |
| `verify.py` | 6 test classes: basic_shape / first_position / append_monotone / 16 random differential trials at seqlen 512 + 2048 / total_decode_savings. 6/6 PASS. |

The `@nki.jit` kernel implementation reuses the inner online-softmax logic from `attn_fwd_v3_online` (sibling bundle 1) restricted to seqlen_q=1; no new kernel binding needed for the simulator validation.

## How to run

```bash
$ cd examples/customer/nki_attention_kv_cache_decode_demo
$ python3 verify.py
  [PASS] basic_shape
  [PASS] first_position
  [PASS] append_monotone_skipped
  [PASS] differential_seqlen_512
  [PASS] differential_seqlen_2048
  [PASS] total_decode_savings
```

## Cumulative HBM savings over a full decode

For 1024 decode steps at d_head=128:
- Naive recompute: O(t^3) cumulative HBM bytes — recompute full causal attention every step
- KV-cache decode: O(t^2) cumulative HBM bytes — single-query attention against growing cache

The `total_decode_savings` test reports the actual ratio at max_seqlen=1024.

## Lean theorems

1. `softmax_shift_invariance` — inherited from sibling bundles.
2. `kv_cache_append_monotone` — *new*. Soundness of incremental decode.
3. `decode_online_eq_offline_exact` — exact equivalence single-query online vs offline.
4. `decode_online_eq_offline_bounded` — worst-case FP32 bound.
5. `decode_online_eq_offline_av_bounded` — anytime-valid bound.

All five compile standalone. Proof bodies sorry-flagged honestly until Pythia PR #96 sequel lands `Pythia.Numerical.Attention.kv_cache_append_monotone`.

## Cross-references

- **Sibling kernel**: `examples/customer/nki_attention_v3_online_demo/` — the inner per-query online-softmax kernel
- **Sibling kernel**: `examples/customer/nki_attention_causal_online_demo/` — causal mask (combines naturally with this decode pattern)
- **Production deployment**: every autoregressive LLM serving stack uses some form of this pattern
- **Pythia PR #96**: <https://github.com/athanor-ai/pythia/pull/96>
- **ATH-1093 (Linear)**: NKI flagship epic
