"""KV-cache decode baseline (offline softmax + recompute).

This is the "naive recompute" baseline: at each decode step, the kernel
recomputes attention from scratch over the FULL sequence — including
the new token's q + the cached prefix's k, v. Used as the equivalence
target for `improved.py` (which leverages the cache to compute only
the new query's attention).

Algorithm at decode step t:
    Inputs:
        q_full: (d_head, t)   — query tensors for all positions 0..t-1
        k_full: (d_head, t)   — key tensors
        v_full: (d_head, t)   — value tensors
    Computation:
        Run causal attention over the full prefix as in
        `nki_attention_causal_online_demo` baseline, return the
        attention output for ALL positions.
    Output for the new token: out[t-1, :]

Cost: O(t * t) — recompute everything every step. The improved kernel
amortizes this to O(1 * t) per decode step by using the cached k/v
and computing only the new query's attention.
"""
from __future__ import annotations

import numpy as np


def baseline_decode_step(
    q_new: np.ndarray,
    k_cache: np.ndarray,
    v_cache: np.ndarray,
) -> np.ndarray:
    """Single-query OFFLINE softmax decode: equivalent computation to
    `improved_decode_step` but using the offline-softmax pattern (full
    QK row materialized, row_max sweep, then exp/sum/divide). Used as
    the equivalence target for the online variant.

    Args:
        q_new: (d_head,) — single new query token
        k_cache: (d_head, cache_len) — cumulative keys
        v_cache: (d_head, cache_len) — cumulative values

    Returns:
        (d_head,) attention output for the new token
    """
    if q_new.dtype != np.float32:
        q_new = q_new.astype(np.float32)
    if k_cache.dtype != np.float32:
        k_cache = k_cache.astype(np.float32)
    if v_cache.dtype != np.float32:
        v_cache = v_cache.astype(np.float32)

    qk = (q_new @ k_cache).astype(np.float32)            # (cache_len,)
    row_max = float(np.max(qk))
    exp = np.exp(qk - row_max).astype(np.float32)        # (cache_len,)
    row_sum = float(exp.sum())
    scores = (exp / row_sum).astype(np.float32)
    return (scores @ v_cache.T).astype(np.float32)        # (d_head,)


def memory_bytes(seqlen: int, d_head: int) -> int:
    """Working memory for naive recompute at a single decode step."""
    f32 = 4
    qkv_bytes = 3 * d_head * seqlen * f32
    qk_bytes = seqlen * seqlen * f32  # full QK materialization
    norm_bytes = seqlen * seqlen * f32
    exp_bytes = seqlen * seqlen * f32
    out_bytes = seqlen * d_head * f32
    return qkv_bytes + qk_bytes + norm_bytes + exp_bytes + out_bytes


def total_decode_cost_bytes(max_seqlen: int, d_head: int) -> int:
    """Cumulative HBM bytes for max_seqlen decode steps under the naive
    recompute model: each step recomputes the full attention to date.
    """
    total = 0
    for t in range(1, max_seqlen + 1):
        total += memory_bytes(t, d_head)
    return total
