"""float64 reference for KV-cache decode — full causal attention,
return only the new-token row."""
from __future__ import annotations

import numpy as np


def reference_decode_step(
    q_full: np.ndarray, k_full: np.ndarray, v_full: np.ndarray, new_pos: int
) -> np.ndarray:
    q64 = q_full.astype(np.float64)
    k64 = k_full.astype(np.float64)
    v64 = v_full.astype(np.float64)
    total = q64.shape[1]
    qk = q64.T @ k64
    rows = np.arange(total)[:, None]
    cols = np.arange(total)[None, :]
    qk = np.where(cols <= rows, qk, -1e30)
    row_max = np.max(qk, axis=1, keepdims=True)
    exp = np.exp(qk - row_max)
    row_sum = exp.sum(axis=1, keepdims=True)
    scores = exp / row_sum
    out_full = (scores @ v64.T).astype(np.float32)
    return out_full[new_pos]
