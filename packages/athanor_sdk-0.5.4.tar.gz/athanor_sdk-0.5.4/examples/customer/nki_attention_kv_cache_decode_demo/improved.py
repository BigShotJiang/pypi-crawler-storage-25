"""KV-cache decode with online softmax over the cached prefix.

Production decode kernel: only ONE new query token is processed per
decode step, attending to the FULL existing K/V cache. This is the
inference critical path for every autoregressive LLM in production.

Algorithm at decode step t:
    Inputs:
        q_new: (d_head,) — single new query token
        k_cache: (d_head, t) — cumulative key cache (positions 0..t-1
                               PLUS the new token's k)
        v_cache: (d_head, t) — cumulative value cache (same)
    Computation (causal: new query attends to all cached positions
                 INCLUDING itself):
        running_max = -inf
        running_sum = 0
        running_out = 0
        For each kv-tile in cache:
            qk_tile = q_new @ k_tile
            new_max = max(running_max, max(qk_tile))
            correction = exp(running_max - new_max)
            p_tile = exp(qk_tile - new_max)
            running_sum = correction * running_sum + sum(p_tile)
            running_out = correction * running_out + p_tile @ v_tile.T
            running_max = new_max
        return running_out / running_sum
    Output: (d_head,) attention for the new token

Per-step cost: O(t) where t is the current cache length.
Total decode cost: O(t^2 / 2) over t steps (vs O(t^2 * t) for naive
recompute → t-fold reduction).

Cache append: separate operation — the new query's k, v are written to
the next slot of the cache buffer BEFORE this kernel runs (handled by
the caller / the broader framework). The kernel only computes the
attention given an already-appended cache.

The Lean theorem `kv_cache_append_monotone` proves that under causal
masking, appending new (k, v) pairs doesn't change earlier-token
outputs — so per-step decode is sound.
"""
from __future__ import annotations

import math

import numpy as np


PARTITION_SIZE: int = 128


def improved_decode_step(
    q_new: np.ndarray,
    k_cache: np.ndarray,
    v_cache: np.ndarray,
    *,
    tile_kv: int = PARTITION_SIZE,
) -> np.ndarray:
    """Single-step decode kernel: compute attention for one new query
    token against an existing K/V cache.

    Args:
        q_new: (d_head,) float32 — single new query token
        k_cache: (d_head, cache_len) float32 — cumulative keys
        v_cache: (d_head, cache_len) float32 — cumulative values
        tile_kv: KV-tile width (default PARTITION_SIZE=128)

    Returns:
        (d_head,) float32 attention output for the new token
    """
    if q_new.dtype != np.float32:
        q_new = q_new.astype(np.float32)
    if k_cache.dtype != np.float32:
        k_cache = k_cache.astype(np.float32)
    if v_cache.dtype != np.float32:
        v_cache = v_cache.astype(np.float32)

    d_head = q_new.shape[0]
    cache_len = k_cache.shape[1]
    assert k_cache.shape == (d_head, cache_len)
    assert v_cache.shape == (d_head, cache_len)

    running_max = -np.inf
    running_sum = np.float32(0.0)
    running_out = np.zeros((d_head,), dtype=np.float32)

    for j in range(0, cache_len, tile_kv):
        j_end = min(j + tile_kv, cache_len)

        qk_tile = (q_new @ k_cache[:, j:j_end]).astype(np.float32)
        tile_max = float(np.max(qk_tile))
        new_max = max(running_max, tile_max)

        if running_max == -np.inf:
            correction = np.float32(0.0)
        else:
            correction = np.float32(np.exp(running_max - new_max))

        p_tile = np.exp(qk_tile - new_max).astype(np.float32)
        tile_sum = float(p_tile.sum())
        running_sum = np.float32(running_sum * correction + tile_sum)

        v_tile = v_cache[:, j:j_end]
        tile_contrib = (p_tile @ v_tile.T).astype(np.float32)
        running_out = (running_out * correction + tile_contrib).astype(np.float32)

        running_max = new_max

    return (running_out / running_sum).astype(np.float32)


def memory_bytes(cache_len: int, d_head: int) -> int:
    """Per-decode-step working memory: just q_new + k_cache + v_cache +
    running stats. NEVER materializes the full QK or per-tile scratch."""
    f32 = 4
    q_bytes = d_head * f32
    cache_bytes = 2 * d_head * cache_len * f32
    out_bytes = d_head * f32
    running_bytes = 2 * f32 + d_head * f32  # max + sum + out
    tile_bytes = PARTITION_SIZE * f32
    return q_bytes + cache_bytes + out_bytes + running_bytes + tile_bytes


def total_decode_cost_bytes(max_seqlen: int, d_head: int) -> int:
    """Cumulative HBM bytes for max_seqlen decode steps under the
    online-decode model: per-step is just one row of attention."""
    total = 0
    for t in range(1, max_seqlen + 1):
        total += memory_bytes(t, d_head)
    return total


def proven_error_bound(
    cache_len: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
) -> float:
    tile_count = (cache_len + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return 8.0 * tile_count * eps_fp32 * out_max


def av_error_bound(
    cache_len: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
    alpha: float = 0.05,
) -> float:
    tile_count = (cache_len + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return math.sqrt(2.0 * tile_count * math.log(2.0 / alpha)) * eps_fp32 * out_max
