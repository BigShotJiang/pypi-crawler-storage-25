module fifo_widget_gate(
  input  wire        clk,
  input  wire        rst_n,
  input  wire        push,
  input  wire [27:0] push_data,
  output wire        full,
  input  wire        pop,
  output wire [27:0] pop_data,
  output wire        empty
);

  reg [27:0] mem [0:3];
  reg [2:0] head;
  reg [2:0] tail;
  reg [2:0] count;

  assign full  = (count == 3'd4);
  assign empty = (count == 3'd0);
  assign pop_data = mem[head[1:0]];

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head  <= 3'd0;
      tail  <= 3'd0;
      count <= 3'd0;
    end else begin
      if (do_push) begin
        mem[tail[1:0]] <= push_data;
        tail <= tail + 3'd1;
      end
      if (do_pop) begin
        head <= head + 3'd1;
      end
      if (do_push && !do_pop)
        count <= count + 3'd1;
      else if (do_pop && !do_push)
        count <= count - 3'd1;
    end
  end

  assign pop_data = mem[head[1:0]];
endmodule
