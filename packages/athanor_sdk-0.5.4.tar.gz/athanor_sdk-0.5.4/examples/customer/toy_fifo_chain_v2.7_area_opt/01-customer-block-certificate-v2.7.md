# Athanor toy_fifo_chain v2.7 customer-block-certificate

Date: 2026-05-06
Customer: Annapurna FV team (Todd lane)
Iteration: v2.7 (closed-loop area-optimization full demo)
Live demo URL: https://tahoe.athanor-ai.com/analytics/silicon-blocks/4d9f013c-4a60-49ae-ad86-347ce1f5454c
Canonical run_id: `4d9f013c-4a60-49ae-ad86-347ce1f5454c`

## What v2.7 demonstrates

The closed-loop area-optimization arc Annapurna's chief architect asked for: an LLM proposer suggests structural transformations on a target RTL block, an EBMC verifier checks each candidate for sequential equivalence, and on inconclusive verdicts a bridge-invariant proposer attempts to close k-induction. The customer reads the full propose-verify-adjust-re-verify trace as one auditable iteration arc.

This run targets `fifo_widget` (depth-4 FIFO, 28-bit data, push/pop interface). The proposer was constrained to interface-preserving transformations (port-list byte-identical to gold + capacity-preserving + combinational-output-equivalence). The proposer can propose candidates from any of the three `TransformationClass` taxonomy classes (`parameterization`, `structural`, `impl_swap`); this canonical run sampled 2 `structural` + 1 `impl_swap` (LLM proposers are stochastic; reruns may sample different distributions).

## The verdict at a glance

| Iteration | Transformation class | Proposer-claimed area delta | Final outcome | Discharged via |
|-----------|----------------------|------------------------------|---------------|----------------|
| 0 | `structural` (eliminate redundant count register; derive full/empty from head/tail comparison + extra wrap bit) | claimed -8.0% | **ACCEPTED** | EBMC k-induction PASS under bridge `inv_fifo_state_bridge` |
| 1 | `impl_swap` (replace 4-entry flop array with shift-register barrel FIFO; eliminate head/tail/count, shift on every pop) | claimed -6.0% | **REFUTED** | EBMC k-induction `hard_refute` under LLM bridge `inv_sr_matches_circular_buf` (real semantic divergence) |
| 2 | `structural` (encode full/empty as registered flags instead of computing combinationally from count; remove comparators on critical path) | claimed -5.5% | **ACCEPTED** | EBMC k-induction PASS under bridge `inv_state_sync` |

**Aggregate (auditable from the engine emit):** 3 transformations proposed -> 2 accepted, 1 refuted, 0 inconclusive. Halt reason: `proved_equivalent_variant_found`. Final area delta on the most-savings accepted variant: claimed -8.0%.

## Honest framing on what is and is not verified

**On the accepted iterations (`structural -8%` and `structural -5.5%`):**

EBMC k-induction PASS confirms **sequential equivalence between gold and the proposed gate variant under the LLM-proposed bridge invariant**. Per-iter bridges:

- Iter 0 : bridge `inv_fifo_state_bridge` ties gold's binary-count register to gate's head/tail-derived occupancy (`gold.count == ((gate.tail - gate.head) & 3'b111)`) plus per-cell mem renaming (`gold.mem[i] == gate.mem_i`).
- Iter 2 : bridge `inv_state_sync` ties gold's combinational-flag computation to gate's registered-flag implementation while preserving head/tail/count register equality.

Both bridges are substantive: 7 real semantic clauses each, no tautology hedging. The bridge-invariant proposer is constrained against trivially-true sub-clauses (no `|| 1'b1` / no `: 1'b1` patterns) so the customer reads a clean expression that actually constrains internal-state agreement.

Per-iter claimed area deltas (proposer pre-synthesis estimates):

- Iter 0 : claimed -8.0%
- Iter 2 : claimed -5.5%

**EBMC verifies semantic equivalence under the bridge invariant; it does NOT verify area savings.** Area delta verification is a synthesis-tool job (post-tape-out flow integration). The customer-trust contract on each iteration's area number reads "claimed -X.X%, semantic equivalence verified, area savings not yet verified by synthesis tool".

**On the refuted iteration (iter 1, `impl_swap -6%`):**

EBMC k-induction returned `hard_refute` on iter 1 under the LLM-proposed bridge `inv_sr_matches_circular_buf`. The bridge tried to tie gold's circular-buffer-with-head/tail-pointers to gate's shift-register-with-occupancy-counter via position-conditional implications, but k-induction found a reachable state where the chosen mapping doesn't preserve external behavior. Honest read: this `impl_swap` candidate is genuinely NOT sequentially equivalent to gold; the verifier-as-safety-net caught a real divergence. The closed loop refuted it cleanly and moved on; no false-positive accept.

## Customer-trust contract for v2.7

The accepted iterations' `[PROVED-with-assume]` claims rest on two assumption stacks:

1. **EBMC k-induction soundness** under the assume-property bridge -- accepted by the customer per standard formal-verification practice.
2. **The bridge invariants `inv_fifo_state_bridge` and `inv_state_sync` hold inductively across the gold/gate Mealy step** -- currently UNPROVEN as Lean theorems in v2.7. The v2.8 follow-up (mirror of the v2.6 `bridgeFullInv_holds_at_every_co_step` pattern that closed via pythia#93) will discharge each bridge as a kernel-checked Lean theorem; once that lands, each accepted iteration's assumption stack flips from `[UNPROVEN -- assumed]` to `[PROVED via Pythia.Hardware.SEC.FifoWidget.<theorem_name>]`.

This is the same UNPROVEN->PROVED-via-Lean arc v2.5 -> v2.6 went through. Customer reads honest framing now; second proof artifact lands when Aristotle catches up.

## What's auditable now (v2.7)

1. *Re-run the closed-loop discharge end-to-end* (requires `kairos>=0.4.1`):
   ```sh
   KAIROS_DEV_NO_LICENSE=1 python3 demo_driver.py --model anthropic/claude-sonnet-4-6
   ```
   Mints a new run_id; iteration arc lands in Supabase `sdk_agent_events`. Outcome distribution may differ run-to-run (LLM stochastic).

   *Note on `KAIROS_DEV_NO_LICENSE=1`*: this is the dev-mode flag that bypasses the paid-tier license check while licensing infrastructure lands. Production deploys ship a real license file at `~/.athanor/license.json`; the dev-bypass is enabled here for self-audit reproducibility on this demo only. Same shape as the honest framing on the area-delta synthesis-tool gap.

2. *Read the verbatim engine emit* under `_sec_work/iter_N_bundle/_sec_work/` for each iteration:
   - `miter.sv` -- the SEC miter that EBMC k-induction discharged
   - `ebmc_bmc.cmdline` -- the exact EBMC command line invoked for the BMC initial verdict
   - `ebmc_bmc.stdout` -- EBMC's bounded-model-check output, including per-property PASS/REFUTED verdicts and (when refuted) the counter-example trace
   - `ebmc_bmc.stderr` + `ebmc_bmc.exitcode` -- diagnostic stream + subprocess exit code
   - `ebmc_kinduction_bare.{cmdline,stdout,stderr,exitcode}` -- analogous capture for the k-induction-without-bridge invocation; what k-induction would say without the LLM-proposed bridge invariant assumed
   - The proposed gate body the iteration verified against (`iter_N_proposed_gate.v` in the parent `_sec_work/`)

   The customer reads these to confirm every cert prose claim against the actual engine output -- no hand-waving, no "you must re-run yourself".

3. *Cross-check the bridge invariant text against the proposed gate*: each accepted iteration's bridge appears verbatim in the cert and in `02-iteration-arc-discharge.md`. Customer can read the proposed gate body and confirm the bridge clauses tie gold's internal state to gate's the way the rewrite implements.

4. *Read the dashboard render* at `/analytics/silicon-blocks/4d9f013c-4a60-49ae-ad86-347ce1f5454c` -- per-iteration row chips show transformation_class, outcome, bridge_invariant text, claimed area delta with the "claimed not verified" tooltip, and the propose -> verify -> bridge -> verify cascade.

## How to read this package

| File | Audience | Length |
|------|----------|--------|
| `01-customer-block-certificate-v2.7.md` | Engineer-reading-the-output | one page |
| `02-iteration-arc-discharge.md` | Engineer-evaluating-rigor (per-iteration audit trail) | three pages |
| `03-honest-framing-v2.7.md` | Engineer-evaluating-rigor (claimed-vs-verified + bridge-UNPROVEN disclosure) | one page |
| `README.md` | Anyone navigating the package | one page |
| `demo_driver.py` | Customer-reproduction script | runnable |
| `inputs/` | gold.sv + gate.v + signature.json (gold is the reference; gate.v is the static fallback for the demo's BMC-against-fixed-pair fall-through path) | inputs |
| `_sec_work/iter_N_bundle/_sec_work/` | Per-iteration miter.sv + EBMC stdout/stderr/exitcode/cmdline captures | engine output |
| `_sec_work/iter_N_proposed_gate.v` | LLM-proposed gate body for iteration N | engine input |

## Cluster-discipline carry-through

v2.7 applies every meta-rule shipped to date:
- engine-cross-check on cert headlines (every claim in this prose traces to a verbatim Supabase row OR captured EBMC stdout file, cited where named)
- render-then-screenshot-post-emit (platform PR carries the customer-visible render verification)
- three-arm defense-in-depth on the iteration-arc emit shape (Pydantic models, DOM tests, cross-arm contract test)
- claimed-vs-verified honest framing on area_delta_pct (this section, cluster meta-rule cross-check)
- source-truth-holder field-name-pin between SDK emit and dashboard read (no field-name drift across arms)
- anti-tautology constraint on bridge-invariant proposer (LLM is forbidden from hedging clauses with `|| 1'b1` or `: 1'b1`; clean bridges over hedged ones)
- engine output bundled verbatim (EBMC stdout/stderr/exitcode/cmdline captured per iteration, customer reads everything)

## Contact

Aidan Yang, Athanor AI.

---

*Cert generated by `kairos.sec.closed_loop` v2.7 demo driver 2026-05-06; canonical discharge run_id `4d9f013c-4a60-49ae-ad86-347ce1f5454c`. Engine emit verbatim from Supabase `sdk_agent_events` rows for that run_id + EBMC subprocess output captured into `_sec_work/iter_N_bundle/_sec_work/ebmc_*` files; build-tarball pre-flight gates verify cert claims against the engine output before tarball emit.*
