# Honest framing - what's PROVED, what's claimed, what's UNPROVEN-as-Lean

This document calls out the three honest-framing distinctions in the v2.7 cert that an engineer-evaluating-rigor needs to read carefully. Getting these distinctions right is critical for the customer-trust contract.

## Distinction 1: semantic equivalence verified vs area delta verified

The accepted iterations are both `structural` candidates. Per-iter accepted-area-delta + bridge:

- Iter 0 : claimed -8.0%, bridge `inv_fifo_state_bridge`.
- Iter 2 : claimed -5.5%, bridge `inv_state_sync`.

EBMC k-induction PASS under each iteration's bridge invariant confirms **sequential equivalence between gold and the proposed gate variant for all reachable states satisfying that iteration's bridge invariant**. EBMC k-induction does NOT verify area savings.

Area delta verification is a synthesis-tool job: the customer would need to run yosys (or commercial synthesis) on both gold and the accepted gate variant, count the resulting cell area, and compute the actual delta. The per-iter values above are the proposer's own pre-synthesis estimates from inspecting the SV body.

**Customer-trust contract on the area numbers reads (per iter):**

- For iter 0: claimed -8.0% (proposer estimate, NOT verified by EBMC); semantic equivalence verified by EBMC k-induction under bridge invariant `inv_fifo_state_bridge`.
- For iter 2: claimed -5.5% (proposer estimate, NOT verified by EBMC); semantic equivalence verified by EBMC k-induction under bridge invariant `inv_state_sync`.
- Post-tape-out flow integration with synthesis tool is v2.8 follow-up; until then, customer should run their own synthesis pass on the accepted gate variant before relying on the area numbers for decisions.

Without this distinction, the cert would read e.g. "-8.0% verified savings" - which is a fabrication-class claim per the cluster meta-rule. The dashboard render labels each chip as `claimed` (not `verified`) with a tooltip explaining the distinction; this prose document carries the same framing forward.

## Distinction 2: PROVED-with-assume vs PROVED-standalone vs PROVED-via-Lean

Both accepted iterations are labeled `PROVED-with-assume` in the cert and dashboard. This means EBMC k-induction PASS was achieved **under an `assume property (...)` injection of the iteration's bridge** - k-induction did not close on the bare miter; it closed only when the LLM-proposed bridge invariant was injected as an assumption.

Three categories of PROVED, distinguished:

| Label | What it means | Customer trust requires |
|---|---|---|
| `PROVED-standalone` | EBMC k-induction (or BMC at sufficient bound) closes without any bridge invariant. The gate is sequentially equivalent to gold from arbitrary post-reset states. | EBMC soundness only |
| `PROVED-with-assume` | EBMC k-induction closes under an `assume property` bridge invariant. The bridge constrains internal state to reachable configurations. | EBMC soundness + the bridge invariant holds inductively across the gold/gate Mealy step |
| `PROVED-via-Lean` | Same as `PROVED-with-assume`, plus the bridge invariant itself has been kernel-proved as a Lean theorem (axiom-audit-clean: `propext`, `Classical.choice`, `Quot.sound` only). | EBMC soundness + Lean kernel soundness + the abstraction function from impl-state to abstract spec-state is correct |

v2.7 ships with both accepted iterations at **`PROVED-with-assume`**. Per-iter assumption-stack bridge:

- Iter 0 : bridge `inv_fifo_state_bridge` is the assumption.
- Iter 2 : bridge `inv_state_sync` is the assumption.

## Distinction 3: UNPROVEN-as-Lean → PROVED-via-Lean follow-up

Per-iter bridge invariants currently **UNPROVEN as Lean theorems in v2.7**:

- Iter 0 : bridge `inv_fifo_state_bridge`.
- Iter 2 : bridge `inv_state_sync`.

v2.8 will discharge each as a kernel-checked Lean theorem (mirror of the v2.6 → pythia#93 arc that closed `bridgeFullInv_holds_at_every_co_step` and `bridgeEmptyInv_holds_at_every_co_step` on the v2.5 fifo_widget bundle).

The follow-up theorem statement (informal):

> For every co-step trace `(goldStep, gateStep)` starting from any reachable state satisfying iteration N's bridge invariant, the post-step state pair also satisfies that bridge invariant. Equivalently: each accepted iteration's bridge invariant is preserved by the gold/gate Mealy step. Per-iter bridge:
>
> - Iter 0 : `inv_fifo_state_bridge`.
> - Iter 2 : `inv_state_sync`.

When the v2.8 pythia child closes both theorems (`Pythia.Hardware.SEC.FifoWidget.invFifoStateBridge_holds_at_every_co_step` and `Pythia.Hardware.SEC.FifoWidget.invStateSync_holds_at_every_co_step`), the cert prose flips per iteration from `[UNPROVEN - assumed; v2.7 D-spike]` to `[PROVED via Pythia.Hardware.SEC.FifoWidget.<theorem>]` (axiom-audit-clean), and the dashboard's per-iteration row chips flip from `PROVED-with-assume` to `PROVED-with-assume / bridge PROVED via Lean`.

This is the same UNPROVEN→PROVED-via-Lean arc v2.5 → v2.6 went through. Customer reads honest framing now; the second proof artifact lands when Aristotle catches up on v2.7.

## Customer-runnable audit

For each distinction, the customer can audit independently:

1. **Semantic equivalence under bridge** - re-run `python3 demo_driver.py` against the same inputs; confirm `iter_2.iteration_verdict.outcome == "accepted"` lands in the new run's Supabase rows. Cross-check the bridge invariant text matches. If bridge_text drifts run-to-run (LLM non-determinism), the customer can also read the iter_2 EBMC log under `_sec_work/iter_2/` and verify the `assume property` line uses the same constraint.

2. **Area delta** - open `inputs/gold.sv` + `_sec_work/iter_0_proposed_gate.v` and `_sec_work/iter_2_proposed_gate.v` in a synthesis tool of choice, compare cell counts. Don't trust the cert's `-8.0%` and `-5.5%` until you've reproduced them.

3. **Bridge UNPROVEN-as-Lean status** - the v2.8 follow-up (filed as a child of `ATH-1053` v2.7 epic) will close the bridge as a Lean theorem. Until that lands, the cert correctly says UNPROVEN. Customer can grep the lean-spec/ directory (when v2.8 ships): if both `invFifoStateBridge_holds_at_every_co_step` and `invStateSync_holds_at_every_co_step` exist in the source AND `lake env lean --run AxiomAudit.lean` returns axiom-audit-clean, the cert prose flips.

## Why this framing matters

The cluster meta-rule (customer-claim engine-cross-check) discipline: every customer-facing claim must trace verbatim to engine output. v2.7 demonstrates the propose-verify-iterate arc Todd asked for, and the cert prose is the customer-facing surface. Getting the three distinctions above right means:

- Customer reads `-8%` and `-5.5%` as proposer-claimed pre-synthesis estimates, not as EBMC verdicts.
- Customer reads `PROVED-with-assume` as conditional-on-bridge-invariant, not as bare proof.
- Customer reads UNPROVEN-as-Lean as the v2.8 follow-up trajectory, not as a permanent gap.

Without these distinctions, the cert is a fabrication. With them, the customer-trust contract is honest and the v2.8 → v2.9 arc has a clear path forward.
