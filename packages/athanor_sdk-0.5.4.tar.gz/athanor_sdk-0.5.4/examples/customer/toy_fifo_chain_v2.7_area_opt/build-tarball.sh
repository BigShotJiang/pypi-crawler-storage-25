#!/usr/bin/env bash
# v2.7 toy_fifo_chain closed-loop area-optimization customer-block-
# certificate build script. Mirror of v2.5 build-tarball.sh + new
# v2.7-specific gates per ATH-1057 + ATH-1058:
#   - Gate 4c: claimed-vs-verified disclaimer presence (asabi receipt-5 finding 3)
#   - Gate 4d: UNPROVEN-as-Lean disclosure (cert MUST disclose bridge invariants
#              UNPROVEN as Lean theorems in v2.7; v2.8 follow-up flips them)
#   - Gate 4f: cross-document staleness audit STALE_TOKENS scan (build-time-pin
#              against canonical-flip-cross-document-propagation drift class)
#   - Gate 7:  dry-run customer_block_certificate_complete Pydantic-validate
#   - Gate 8:  dry-run iteration-arc event Pydantic-validate (6 event types)
#   - Gate 9:  bridge-label name-match between cert prose + engine emit
#   - Gate 10: cluster-discipline carry-through tag (cert names every meta-rule
#              applied)
#   - Gate 11: structural cross-document audit via kairos.cert._bundle_audit
#              (NEW per ATH-1058 Layer 1); defense-in-depth alongside Gate 4f

set -euo pipefail

SCAFFOLD_DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-/tmp/v2.7-toy-fifo-chain-tarball.tgz}"
CANONICAL_RUN_ID="4d9f013c-4a60-49ae-ad86-347ce1f5454c"

REQUIRED_FILES=(
  README.md
  01-customer-block-certificate-v2.7.md
  02-iteration-arc-discharge.md
  03-honest-framing-v2.7.md
  demo_driver.py
  inputs/gold.sv
  inputs/gate.v
  inputs/signature.json
)

# Per Aidan 2026-05-06 directive: customer-bound tarballs ship engine
# output verbatim. Per-iteration EBMC subprocess output captured into
# _sec_work/iter_N_bundle/_sec_work/ alongside the miter.sv. Gate 1
# fails-loud if any captured artifact goes missing for the canonical
# run.
REQUIRED_EBMC_CAPTURES=(
  _sec_work/iter_0_bundle/_sec_work/miter.sv
  _sec_work/iter_0_bundle/_sec_work/ebmc_bmc.stdout
  _sec_work/iter_0_bundle/_sec_work/ebmc_bmc.stderr
  _sec_work/iter_0_bundle/_sec_work/ebmc_bmc.exitcode
  _sec_work/iter_0_bundle/_sec_work/ebmc_bmc.cmdline
  _sec_work/iter_0_bundle/_sec_work/ebmc_kinduction_bare.stdout
  _sec_work/iter_0_bundle/_sec_work/ebmc_kinduction_bare.cmdline
  _sec_work/iter_1_bundle/_sec_work/miter.sv
  _sec_work/iter_1_bundle/_sec_work/ebmc_bmc.stdout
  _sec_work/iter_1_bundle/_sec_work/ebmc_bmc.cmdline
  _sec_work/iter_2_bundle/_sec_work/miter.sv
  _sec_work/iter_2_bundle/_sec_work/ebmc_bmc.stdout
  _sec_work/iter_2_bundle/_sec_work/ebmc_bmc.cmdline
)

echo "==> Gate 1: required-files"
for f in "${REQUIRED_FILES[@]}"; do
  if [[ ! -f "$SCAFFOLD_DIR/$f" ]]; then
    echo "MISSING: $f"
    exit 1
  fi
done
for f in "${REQUIRED_EBMC_CAPTURES[@]}"; do
  if [[ ! -f "$SCAFFOLD_DIR/$f" ]]; then
    echo "MISSING (engine output capture): $f"
    echo "  per Aidan 2026-05-06 directive, customer-bound tarball MUST ship"
    echo "  EBMC subprocess output verbatim. Re-run demo_driver.py to capture."
    exit 1
  fi
done
echo "OK ($(echo "${REQUIRED_FILES[@]}" | wc -w) cert + $(echo "${REQUIRED_EBMC_CAPTURES[@]}" | wc -w) engine-capture files present)"

echo "==> Gate 2: AI-fingerprint"
BANNED='load-bearing|harness|leverage|next generation|elided|delve|tapestry|seamlessly|in conclusion|comprehensive solution'
if grep -REil "$BANNED" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: AI-fingerprint phrases detected above"
  exit 1
fi
echo "OK (no banned phrases)"

echo "==> Gate 3: internal-codename"
CODENAMES='asabi|kairos\.observe|hongsksam|aidanby|athanor-builder|athanor-platform|athanor-sdk'
# allow citation of agent-issued tickets (ATH-NNNN) but not raw repo names
violations=$(grep -REinl "$CODENAMES" "$SCAFFOLD_DIR"/*.md || true)
filtered=$(echo "$violations" | grep -v '^$' || true)
if [[ -n "$filtered" ]]; then
  echo "FAIL: internal codename leaked in:"
  echo "$filtered"
  grep -REin "$CODENAMES" $filtered || true
  exit 1
fi
echo "OK (no internal codenames in customer-facing md)"

echo "==> Gate 4a: vacuous-overclaim phrases"
OVERCLAIM='formally verified|mathematically proven|machine-checked theorem|absolute correctness|guaranteed correct'
if grep -REil "$OVERCLAIM" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: vacuous-overclaim phrases detected above"
  exit 1
fi
echo "OK (no overclaim phrases)"

echo "==> Gate 4b: ACCEPTED-as-headline-label (NEW v2.7)"
# v2.5 Gate 4b banned bare PROVED in headlines; v2.7 carries that
# forward + adds bare ACCEPTED (the v2.7-specific verdict-class label).
LABEL_BAN='\| *PROVED *\||\| *ACCEPTED *\||Verdict[^|]*\| *PROVED|^Accepted by|\| *Accepted by'
if grep -REn "$LABEL_BAN" "$SCAFFOLD_DIR"/*.md; then
  echo "FAIL: bare PROVED/ACCEPTED used as headline verdict label above"
  exit 1
fi
echo "OK (no bare PROVED/ACCEPTED headline labels)"

echo "==> Gate 4c: claimed-vs-verified disclaimer presence (NEW v2.7 per asabi receipt-5 finding 3)"
# Cert MUST distinguish claimed-area-delta from EBMC-verified-equivalence.
# Without this disclaimer the cert is a fabrication-class claim.
REQUIRED_DISCLAIMER='claimed.*NOT.*verified|claimed -[0-9]+\.[0-9]+|claimed pre-synthesis|Area delta verification.*synthesis-tool|claimed.*proposer.*estimate'
if ! grep -REil "$REQUIRED_DISCLAIMER" "$SCAFFOLD_DIR"/01-customer-block-certificate-v2.7.md > /dev/null; then
  echo "FAIL: 01-customer-block-certificate-v2.7.md missing claimed-vs-verified disclaimer"
  echo "  per asabi 2026-05-06 receipt-5 finding 3, cert MUST distinguish"
  echo "  proposer-claimed area delta from EBMC-verified semantic equivalence"
  exit 1
fi
echo "OK (claimed-vs-verified disclaimer present in cert prose)"

echo "==> Gate 4d: UNPROVEN-as-Lean disclosure (NEW v2.7)"
# Cert MUST disclose that the v2.7 accepted-iteration bridge invariants are
# UNPROVEN as a Lean theorem in v2.7 (v2.8 follow-up closes via mirror
# of v2.6 pythia#93 pattern). Without this disclosure customer reads
# PROVED-with-assume as PROVED-via-Lean which is a fabrication.
REQUIRED_UNPROVEN='UNPROVEN as a Lean theorem|UNPROVEN — assumed|UNPROVEN-as-Lean|currently UNPROVEN'
if ! grep -REil "$REQUIRED_UNPROVEN" "$SCAFFOLD_DIR"/*.md > /dev/null; then
  echo "FAIL: cert prose missing UNPROVEN-as-Lean disclosure"
  echo "  per asabi 2026-05-06 receipt-5, cert MUST disclose bridge"
  echo "  invariants UNPROVEN as Lean theorems in v2.7"
  exit 1
fi
echo "OK (UNPROVEN-as-Lean disclosure present)"

echo "==> Gate 4f: cross-document staleness audit (build-time-pin per asabi 2026-05-06)"
# Build-time-pin lift on the canonical-flip-cross-document-propagation
# class (3 instances on v2.7: b4cdac9a -> d92430e9 -> 4d9f013c). Every
# canonical-flip on a v2.7 cert risks leaving stale numerical / bridge-
# name references in README + 03-honest-framing while only the directly-
# touched 01-cert + 02-discharge get updated. This gate scans EVERY
# .md file in the bundle for old-canonical's known stale tokens and
# fails-loud if any survive.
#
# When canonical flips, append the previous canonical's stale tokens
# below + reset on next flip. Customer-bound tarball MUST NOT ship with
# any prior-canonical numbers / bridge names anywhere in the bundle.
STALE_TOKENS=(
  # Prior canonical b4cdac9a's iter-2 bridge label
  'inv_state_and_mem_eq'
  # Prior canonical d92430e9's iter-1 bridge label (different from
  # 4d9f013c's iter-1 inv_sr_matches_circular_buf)
  'inv_fifo_state_match'
  # Prior canonical d92430e9's iter-2 bridge label (different from
  # 4d9f013c's iter-0 inv_fifo_state_bridge)
  'inv_state_bridge\b'
  # Prior canonical d92430e9's accepted area deltas
  '12\.0%|-12%'
  '7\.0%(?! verified)'  # avoid hitting unrelated 70%
  # Prior canonical d92430e9's refuted area delta
  '9\.0%(?! verified)'
  # Prior canonical b4cdac9a's accepted area delta
  '6\.0%(?! verified|.*claimed.*-6\.0)'
  # Prior canonical run_ids
  'b4cdac9a-c1d6-4786-b663-ebae53899940|b4cdac9a'
  'd92430e9-9a5d-465b-8103-d587425d0052|d92430e9'
)
stale_found=0
for tok in "${STALE_TOKENS[@]}"; do
  hits=$(grep -nE "$tok" "$SCAFFOLD_DIR"/*.md 2>/dev/null || true)
  if [[ -n "$hits" ]]; then
    # Skip the false-positive on -6.0%/-9.0%/-7.0% inside historical
    # context paragraphs (e.g. references to v2.5 / v2.6 prior runs).
    # Filter out lines explicitly framed as historical.
    real_hits=$(echo "$hits" | grep -v 'historical\|v2\.5\|v2\.6\|v2\.6_sec\|prior canonical\|previously\|earlier mint' || true)
    if [[ -n "$real_hits" ]]; then
      echo "STALE token '$tok' found:"
      echo "$real_hits"
      stale_found=1
    fi
  fi
done
if [[ $stale_found -eq 1 ]]; then
  echo "FAIL: cross-document staleness audit caught prior-canonical refs"
  echo "  per asabi 2026-05-06 directive: customer-bound tarball MUST NOT"
  echo "  ship with prior-canonical numbers / bridge names anywhere in"
  echo "  the bundle. Update STALE_TOKENS list when canonical flips."
  exit 1
fi
echo "OK (no prior-canonical references in cert prose; cross-document propagation clean)"

echo "==> Gate 5: cert-vs-engine cross-check (canonical run_id $CANONICAL_RUN_ID)"
# Verify the cert's claim of `1 accepted, 1 refuted, 1 inconclusive`
# matches the engine emit in Supabase. Skip cleanly when SUPABASE env
# unset (customer reproducing locally without telemetry credentials);
# fail loud when env IS set but the cross-check disagrees.
if [[ -z "${SUPABASE_URL:-}" || -z "${SUPABASE_SERVICE_ROLE_KEY:-}${ATHANOR_SYNC_TOKEN:-}" ]]; then
  echo "SKIPPED (Supabase env unset; engine cross-check requires SUPABASE_URL + SERVICE_ROLE_KEY or ATHANOR_SYNC_TOKEN)"
else
  echo "  (Supabase env present; cross-check would query sdk_agent_events for $CANONICAL_RUN_ID)"
  echo "  (deferred to a Python verifier; flagged as build-time-pin in v2.8 follow-up)"
fi
echo "OK (Gate 5 placeholder; canonical run_id pinned in cert + reproducible via re-run)"

echo "==> Gate 6: outcome-distribution count cross-check"
# Cert summary claims '3 transformations proposed -> 2 accepted, 1
# refuted, 0 inconclusive'. Verify the 2+1+0=3 arithmetic + that the
# sum matches the proposed count.
if ! grep -E '3 transformation(s|\(s\)) proposed.*2 accepted.*1 refuted.*0 inconclusive' "$SCAFFOLD_DIR"/01-customer-block-certificate-v2.7.md > /dev/null; then
  echo "FAIL: cert summary aggregator does not match canonical run 4d9f013c's outcome distribution"
  echo "  expected: '3 transformation[s|(s)] proposed -> 2 accepted, 1 refuted, 0 inconclusive'"
  exit 1
fi
echo "OK (outcome distribution 2+1+0=3 matches canonical run 4d9f013c)"

echo "==> Gate 7: dry-run customer_block_certificate_complete Pydantic-validate"
# Mirror of v2.6 Gate 7 (ATH-1042 instance #10-A): construct sample
# customer_block_certificate_complete payload + validate against the
# Pydantic model in kairos.trace_schema. Catches shape drift between
# cert event emit + the strict schema before tarball ship.
python3 - <<'PYEOF'
import sys
sys.path.insert(0, "/home/azureuser/agents/qa/athanor-sdk/src")
from kairos.trace_schema import validate_payload

sample = {
    "block_name": "fifo_widget",
    "verdict_summary": "3 transformations proposed -> 2 accepted, 1 refuted, 0 inconclusive, 0 errored. Final area delta: -12.0%.",
    "per_property_verdicts": [
        {"property": "iter_0_structural", "verdict": "PROVED-with-assume",
         "bridge_invariant": "gold.head == gate.head && ... mem renaming + count derivation",
         "bridge_label": "inv_state_sync", "diagnostic_class": None},
        {"property": "iter_1_impl_swap", "verdict": "REFUTED",
         "bridge_invariant": None, "bridge_label": "inv_fifo_state_match",
         "diagnostic_class": "bmc_counterexample"},
        {"property": "iter_2_structural", "verdict": "PROVED-with-assume",
         "bridge_invariant": "gate.cnt == (5'b1 << gold.count) && ... mem equality + head/tail",
         "bridge_label": "inv_state_bridge", "diagnostic_class": None},
    ],
    "assumption_stack": [
        "inv_state_sync (iter_0_structural) [UNPROVEN -- assumed; v2.7 D-spike]",
        "inv_state_bridge (iter_2_structural) [UNPROVEN -- assumed; v2.7 D-spike]",
    ],
    "lean_proves_obligations": [],
    "n_proved": 2,
    "n_refuted": 1,
    "n_inconclusive": 0,
    "total_properties": 3,
    "discharge_engine": "EBMC BMC + k-induction with LLM-driven bridge invariants",
    "bundle_path": "examples/customer/toy_fifo_chain_v2.7_area_opt",
}
r = validate_payload("theorem_proving", "customer_block_certificate_complete", sample)
if not r.ok:
    print("FAIL: cert event Pydantic-validate failed")
    for v in r.violations:
        print(f"  - {v}")
    sys.exit(1)
print("OK (cert event payload validates against _CustomerBlockCertificateComplete)")
PYEOF

echo "==> Gate 8: dry-run iteration-arc events Pydantic-validate (NEW v2.7 per ATH-1057)"
# Mirror of Gate 7 for each of the 6 v2.7 iteration-arc event types.
# Build canonical samples + validate.
python3 - <<'PYEOF'
import sys
sys.path.insert(0, "/home/azureuser/agents/qa/athanor-sdk/src")
from kairos.trace_schema import validate_payload

PRID = "4d9f013c-4a60-49ae-ad86-347ce1f5454c"
samples = {
    "transformation_proposed": {
        "iteration_index": 2, "parent_run_id": PRID,
        "transformation_class": "impl_swap",
        "transformation_description": "Replace flop-array with packed register",
        "proposer_model": "anthropic/claude-sonnet-4-6",
        "estimated_area_delta_pct": -6.0,
    },
    "verify_attempt": {
        "iteration_index": 2, "parent_run_id": PRID,
        "engine": "ebmc_kinduction", "bound": 10, "result": "PASS",
        "diagnostic_class": None, "elapsed_sec": 5.0,
    },
    "bridge_invariant_proposed": {
        "iteration_index": 2, "parent_run_id": PRID,
        "bridge_label": "inv_state_and_mem_eq",
        "bridge_text": "gold.head == gate.head && ...",
        "proposer_model": "anthropic/claude-sonnet-4-6",
        "lean_theorem_ref": None,
    },
    "iteration_verdict": {
        "iteration_index": 2, "parent_run_id": PRID,
        "outcome": "accepted",
        "outcome_reason": "k-induction PASS under bridge",
        "area_delta_pct": -6.0,
        "bridges_used": ["inv_state_and_mem_eq"],
    },
    "iteration_complete": {
        "iteration_index": 2, "parent_run_id": PRID,
        "halt_reason": "proved_equivalent_variant_found",
    },
    "bridge_lean_closed": {
        "iteration_index": 2, "parent_run_id": PRID,
        "bridge_label": "inv_state_and_mem_eq",
        "lean_theorem_ref": "Pythia.Hardware.SEC.FifoWidget.invStateAndMemEq_holds_at_every_co_step",
        "axiom_audit_clean": True,
        "discharge_pr": "pythia#NN (v2.8 follow-up)",
    },
}
fail = False
for evt, payload in samples.items():
    r = validate_payload("theorem_proving", evt, payload)
    if not r.ok:
        print(f"FAIL: {evt} Pydantic-validate: {r.violations}")
        fail = True
if fail:
    sys.exit(1)
print(f"OK (all {len(samples)} v2.7 iteration-arc events validate against strict Pydantic models)")
PYEOF

echo "==> Gate 9: bridge-label name-match between cert prose + canonical engine emit"
# Cert prose names two bridge invariants from canonical run 4d9f013c:
# 'inv_state_bridge' (iter 0, refuted) + 'inv_state_and_mem_eq' (iter 2,
# accepted). Both must appear verbatim in the cert prose. Catches
# silent rename drift between engine emit + cert authoring.
EXPECTED_BRIDGES=("inv_fifo_state_bridge" "inv_sr_matches_circular_buf" "inv_state_sync")
for label in "${EXPECTED_BRIDGES[@]}"; do
  if ! grep -E "\b${label}\b" "$SCAFFOLD_DIR"/02-iteration-arc-discharge.md > /dev/null; then
    echo "FAIL: bridge label $label missing from 02-iteration-arc-discharge.md"
    echo "  cert prose must name every bridge invariant from the canonical run's iteration-arc emit"
    exit 1
  fi
done
echo "OK (both bridge labels from canonical run 4d9f013c present in cert prose)"

echo "==> Gate 10: cluster-discipline carry-through tag (cert names every meta-rule applied)"
# Cluster meta-rules from v2.5/v2.6 must be visibly applied in v2.7
# cert prose. Customer reads the discipline carry-through transparently.
REQUIRED_TAGS=(
  "engine-cross-check"
  "render-then-screenshot-post-emit"
  "three-arm defense-in-depth"
  "claimed-vs-verified"
  "source-truth-holder"
)
for tag in "${REQUIRED_TAGS[@]}"; do
  if ! grep -E "$tag" "$SCAFFOLD_DIR"/*.md > /dev/null; then
    echo "FAIL: cluster-discipline tag '$tag' missing from cert prose"
    exit 1
  fi
done
echo "OK (all 5 cluster-discipline carry-through tags present)"

echo "==> Gate 11: structural cross-document audit via kairos.cert._bundle_audit (per ATH-1058 Layer 1 + scope-extension)"
# Build-time-pin via the audit module. Three sibling checks aggregated;
# fails-loud on ANY finding across all three:
#   (1) cross_check_bundle_against_engine_emit: every (iter_index, field)
#       claim in cert prose verified against canonical engine emit.
#       Catches new-canonical-vs-stale-prose drift.
#   (2) cross_check_build_script_consistency: header-comment Gate-N
#       descriptions vs actual gate-echo flow keyword-overlap-match.
#       Catches stale-header-vs-rewired-flow drift (PR #508 receipt-3
#       fourth-pass FIX 1 class).
#   (3) cross_check_gate_count_assertions: cert-prose hardcoded gate-count
#       references (e.g. "Gates 1-N") cross-checked vs actual echo-gate
#       count. Catches stale-gate-count-prose drift (FIX 2 class).
# Defense-in-depth per asabi LLM-defense thesis + Aidan tests-and-automation
# directive 2026-05-06 ("never trust llm memory").
python3 - <<'PYEOF'
import sys
from pathlib import Path
sys.path.insert(0, "/home/azureuser/agents/qa/athanor-sdk/src")
from kairos.cert._bundle_audit import (
    cross_check_build_script_consistency,
    cross_check_bundle_against_engine_emit,
    cross_check_gate_count_assertions,
)

# Canonical engine emit for run_id 4d9f013c-4a60-49ae-ad86-347ce1f5454c.
# Sourced verbatim from the iteration_verdict + iteration_complete
# events in Supabase sdk_agent_events. Update when canonical re-mints.
ENGINE_EMIT = {
    "run_id": "4d9f013c-4a60-49ae-ad86-347ce1f5454c",
    "halt_reason": "proved_equivalent_variant_found",
    "iterations": [
        {
            "iteration_index": 0,
            "transformation_class": "structural",
            "estimated_area_delta_pct": -8.0,
            "bridge_label": "inv_fifo_state_bridge",
            "outcome": "accepted",
        },
        {
            "iteration_index": 1,
            "transformation_class": "impl_swap",
            "estimated_area_delta_pct": -6.0,
            "bridge_label": "inv_sr_matches_circular_buf",
            "outcome": "refuted",
        },
        {
            "iteration_index": 2,
            "transformation_class": "structural",
            "estimated_area_delta_pct": -5.5,
            "bridge_label": "inv_state_sync",
            "outcome": "accepted",
        },
    ],
}

bundle = Path("/home/azureuser/agents/qa/athanor-sdk/examples/customer/toy_fifo_chain_v2.7_area_opt")
results = [
    ("engine-emit cross-check", cross_check_bundle_against_engine_emit(bundle, ENGINE_EMIT)),
    ("build-script consistency", cross_check_build_script_consistency(bundle)),
    ("gate-count assertions", cross_check_gate_count_assertions(bundle)),
]
total_findings = sum(len(r.findings) for _, r in results)
if total_findings:
    print(f"FAIL: {total_findings} cross-document drift findings across 3 sibling checks:")
    for label, r in results:
        if r.findings:
            print(f"  [{label}] {len(r.findings)} findings:")
            for f in r.findings:
                print(f"    - {f.explanation}")
    sys.exit(1)
clean_summary = ", ".join(f"{label}=0" for label, _ in results)
print(f"OK (audit clean across 3 sibling checks: {clean_summary})")
PYEOF

echo "==> Building tarball"
TAR_NAME="$(basename "$OUT")"
TMP_STAGE="$(mktemp -d)"
STAGE_DIR="$TMP_STAGE/toy_fifo_chain_v2.7_area_opt"
cp -r "$SCAFFOLD_DIR" "$STAGE_DIR"
# Strip __pycache__ + scratch _sec_work (latter regenerated by demo_driver)
find "$STAGE_DIR" -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true
find "$STAGE_DIR" -name '*.pyc' -delete 2>/dev/null || true

tar -czf "$OUT" -C "$TMP_STAGE" toy_fifo_chain_v2.7_area_opt
rm -rf "$TMP_STAGE"

echo "Wrote: $OUT"
ls -lh "$OUT"
