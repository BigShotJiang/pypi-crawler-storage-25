# Iteration-arc discharge - methodology + per-iteration audit trail

This document is the engineer-evaluating-rigor companion to `01-customer-block-certificate-v2.7.md`. It walks through the closed-loop iteration arc on canonical run `4d9f013c-4a60-49ae-ad86-347ce1f5454c` and shows what the engine actually computed at each step.

## What the closed-loop iteration arc is

EBMC sequential equivalence checking on a fixed gold/gate pair returns one of three verdicts per output property: PROVED (k-induction closes), REFUTED (counter-example found), INCONCLUSIVE (k-induction returned without enough info). v2.6 demonstrated this well-formed verdict on a single fixed pair.

The v2.7 closed loop generalizes one level up: instead of a fixed pair, an LLM proposes candidate gate variants given the gold-side block; each candidate runs through the same EBMC discharge; on REFUTED, the iteration logs the counter-example and moves on; on INCONCLUSIVE, an LLM-driven bridge-invariant proposer attempts to close k-induction by injecting `assume property (...)` constraints on internal state; on PROVED-with-assume, the bridge invariant is recorded as the customer-trust-contract assumption that ties the proposed variant to gold's behavior.

The customer reads the per-iteration audit trail - accepted candidates, refuted candidates, plus all the bridge invariants the verifier worked through to get there. Honest framing on what's provable now versus what's a follow-up Lean refinement.

## Iteration 0 - `structural` (claimed -8.0%) - ACCEPTED

**Proposer output (from `transformation_proposed` event, sequence 2):**
- transformation_class: `structural`
- transformation_description: "Eliminate the redundant count register by deriving full/empty flags directly from head and tail pointer comparison using an extra wrap bit."
- claimed area delta: -8.0% (proposer estimate; not verified by EBMC)
- proposer_model: `anthropic/claude-sonnet-4-6`

**BMC verify (from `verify_attempt` event, sequence 4):**
- engine: `ebmc_bmc`, bound: 10
- result: FAIL
- captured stdout/stderr/exitcode/cmdline at `_sec_work/iter_0_bundle/_sec_work/ebmc_bmc.{stdout,stderr,exitcode,cmdline}`

EBMC reported FAIL on at least one of the per-property output-equivalence assertions in the miter at bound <=10. Customer reads the per-property breakdown directly from `ebmc_bmc.stdout`. BMC alone cannot decide whether the divergence is a real semantic bug or a non-reachable-state artifact; the iteration escalates to bridge-invariant proposal + k-induction.

**Bridge invariant proposed (from `bridge_invariant_proposed` event, sequence 5):**
- bridge_label: `inv_fifo_state_bridge`
- bridge_text (verbatim from the engine emit):

```
gold.head[1:0] == gate.head[1:0] && gold.tail[1:0] == gate.tail[1:0] && gold.count == ((gate.tail - gate.head) & 3'b111) && gold.mem[0] == gate.mem_0 && gold.mem[1] == gate.mem_1 && gold.mem[2] == gate.mem_2 && gold.mem[3] == gate.mem_3
```

**Bridge audit:** 7 substantive clauses. Head/tail register equality (via `[1:0]` slicing on gold's wider registers) plus the count-derivation predicate `gold.count == ((gate.tail - gate.head) & 3'b111)` (the critical translation between gold's explicit count register and gate's count-from-pointer-delta) plus 4 memory-cell renaming clauses tying gold's `mem[0..3]` array to gate's `mem_0..mem_3` named fields. No tautology hedging.

**k-induction with assume-property (from `verify_attempt` event, sequence 6):**
- engine: `ebmc_kinduction`, bound: 10
- result: PASS

K-induction closes under the bridge invariant. Sequential equivalence between gold and the proposed structural gate variant is verified for all reachable states satisfying `inv_fifo_state_bridge`.

**Iteration verdict (from `iteration_verdict` event, sequence 7):**
- outcome: **ACCEPTED**
- outcome_reason: "k-induction PASS under assume-property bridge inv_fifo_state_bridge (BMC initial verdict: FAIL)"

The customer-trust contract for this iteration: "I accept EBMC k-induction soundness AND I accept that the LLM-proposed bridge invariant `inv_fifo_state_bridge` holds inductively across the gold/gate Mealy step." The bridge invariant itself is currently UNPROVEN as a Lean theorem in v2.7.

## Iteration 1 - `impl_swap` (claimed -6.0%) - REFUTED

**Proposer output (from `transformation_proposed` event, sequence 8):**
- transformation_class: `impl_swap`
- transformation_description: "Replace the 4-entry flop array with a shift-register (barrel) FIFO that eliminates head/tail/count pointers entirely, using only a 2-bit occupancy counter and shifting data on every pop."
- claimed area delta: -6.0%

**BMC verify (from `verify_attempt` event, sequence 10):**
- engine: `ebmc_bmc`, bound: 10
- result: FAIL
- captured at `_sec_work/iter_1_bundle/_sec_work/ebmc_bmc.{stdout,stderr,exitcode,cmdline}`

BMC found a counter-example, expected for an `impl_swap` transformation: the proposed gate's shift-register implementation doesn't naturally match gold's distributed circular-buffer with head/tail pointers; bare BMC sees the internal-state mismatch and reports it.

**Bridge invariant proposed (from `bridge_invariant_proposed` event, sequence 11):**
- bridge_label: `inv_sr_matches_circular_buf`
- bridge_text (verbatim from the engine emit):

```
gold.count == gate.count && gold.tail == ((gold.head + gold.count) & 3'd7) && (gold.count >= 3'd1 -> gate.sr0 == gold.mem[gold.head[1:0]]) && (gold.count >= 3'd2 -> gate.sr1 == gold.mem[(gold.head[1:0] + 2'd1) & 2'd3]) && (gold.count >= 3'd3 -> gate.sr2 == gold.mem[(gold.head[1:0] + 2'd2) & 2'd3]) && (gold.count >= 3'd4 -> gate.sr3 == gold.mem[(gold.head[1:0] + 2'd3) & 2'd3]) && gold.count <= 3'd4 && gold.head <= 3'd7 && gold.tail <= 3'd7
```

**Bridge audit:** 9 substantive clauses. Count register equality + tail-from-head-plus-count derivation + 4 conditional implications mapping `gate.sr0..sr3` (shift register entries) to `gold.mem[head + offset]` based on FIFO occupancy + 3 bound constraints on count/head/tail. No tautology hedging. The position-conditional implications use `->` operator which is substantive (not hedge).

**k-induction with assume-property (from `verify_attempt` event, sequence 12):**
- engine: `ebmc_kinduction`, bound: 10
- result: INCONCLUSIVE (returns `hard_refute` from generate_invariant)

Even under the bridge invariant `inv_sr_matches_circular_buf`, k-induction returns `hard_refute`: the proposed `impl_swap` gate is genuinely not sequentially equivalent to gold. The shift-register-on-every-pop semantics the LLM chose doesn't preserve external behavior under all push/pop sequences.

**Iteration verdict (from `iteration_verdict` event, sequence 13):**
- outcome: **REFUTED**
- outcome_reason: "k-induction hard_refute under bridge attempts: semantic divergence (BMC initial verdict: FAIL)"

Honest read: this `impl_swap` candidate is a real semantic bug -- the verifier-as-safety-net caught it cleanly and moved on. The closed loop refuted it without false-positive acceptance.

## Iteration 2 - `structural` (claimed -5.5%) - ACCEPTED

**Proposer output (from `transformation_proposed` event, sequence 14):**
- transformation_class: `structural`
- transformation_description: "Encode full and empty as registered flags instead of computing them combinationally from count, removing the comparators on the critical path."
- claimed area delta: -5.5%

**BMC verify (from `verify_attempt` event, sequence 16):**
- engine: `ebmc_bmc`, bound: 10
- result: FAIL
- captured at `_sec_work/iter_2_bundle/_sec_work/ebmc_bmc.{stdout,stderr,exitcode,cmdline}`

BMC found a counter-example at bound <=10. The flag-registration change introduces a one-cycle delay on full/empty visibility; bare BMC sees the timing-edge divergence.

**Bridge invariant proposed (from `bridge_invariant_proposed` event, sequence 17):**
- bridge_label: `inv_state_sync`
- bridge_text (verbatim from the engine emit):

```
gold.head[1:0] == gate.head_ptr && gold.tail[1:0] == gate.tail_ptr && gold.count == gate.count && gold.mem[0] == gate.mem[0] && gold.mem[1] == gate.mem[1] && gold.mem[2] == gate.mem[2] && gold.mem[3] == gate.mem[3]
```

**Bridge audit:** 7 substantive clauses. Head/tail register equality (with field-rename `head_ptr`/`tail_ptr` on gate side) + count register equality + 4 memory-cell equality clauses. No tautology hedging.

**k-induction with assume-property (from `verify_attempt` event, sequence 18):**
- engine: `ebmc_kinduction`, bound: 10
- result: PASS

K-induction closes under the bridge. Sequential equivalence verified for all reachable states satisfying `inv_state_sync`.

**Iteration verdict (from `iteration_verdict` event, sequence 19):**
- outcome: **ACCEPTED**
- outcome_reason: "k-induction PASS under assume-property bridge inv_state_sync (BMC initial verdict: FAIL)"

## Aggregate (from `iteration_complete` event, sequence 20)

- halt_reason: `proved_equivalent_variant_found`
- 3 transformations proposed -> 2 accepted, 1 refuted, 0 inconclusive

The closed loop terminated successfully (multiple equivalent variants found). Customer reads the full audit trail: which candidates were proposed, which the verifier caught (the `impl_swap` shift-register-on-every-pop bug), which the bridge-invariant proposer closed (the count-register-elimination + the registered-flags rewrites).

## What's auditable end-to-end

For each iteration, the customer can re-derive every claim in this document by reading the corresponding Supabase rows under `run_id = 4d9f013c-4a60-49ae-ad86-347ce1f5454c` AND the captured EBMC subprocess output at `_sec_work/iter_N_bundle/_sec_work/ebmc_*.{stdout,stderr,exitcode,cmdline}`. The `02-iteration-arc-discharge.md` text is engine-cross-check-pinned per the cluster meta-rule: every quoted bridge_text, every outcome label, every halt_reason traces verbatim to the named (run_id, sequence, event_type) row OR to a captured ebmc_*.stdout file. Nothing is paraphrased from recollection.

The build-tarball pre-flight gates verify this cross-check structurally before tarball emit: any drift between cert prose claims and engine output fails-loud at build time.
