"""End-to-end demo driver for the v2.7 closed-loop area-optimization
arc on toy_fifo_chain.

ATH-1053 (parent epic) / ATH-1055 (qa SDK lane) /
ATH-1063 (Phase 0a-wiring; commit 2c carry-through).

Per Aidan 2026-05-06 directive ("not fast, always slow. Never scaffold!"):
this driver runs the real propose-verify-bridge-iterate loop end-to-end
against the v2.7 inputs. No --dry-run mode. Real LLM proposer call. Real
EBMC verify per proposal. Real generate_invariant() for INCONCLUSIVE
escalation. Real Supabase emit. Mints the canonical v2.7 run_id.

Implementation note (ATH-1063 Phase 0a-wiring 2c)
-------------------------------------------------

The orchestration logic lives in
:func:`kairos.sec.closed_loop.run_closed_loop_orchestration` so MCP
`kairos_optimize_block` and any future cert-mint script reuse the same
code path the v2.7 demo dogfooded. This driver is a thin CLI surface
over that library function: input-presence check, arg-parse, call,
print canonical run_id + summary.

Usage
-----

    python3 examples/customer/toy_fifo_chain_v2.7_area_opt/demo_driver.py

Requires `ANTHROPIC_API_KEY` (Azure-routed at apmartin-2613 per
~/keys.md), `ATHANOR_SYNC_TOKEN` (or `SUPABASE_SERVICE_ROLE_KEY`), and
EBMC binary on `$PATH`.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from kairos.sec.closed_loop import run_closed_loop_orchestration

HERE = Path(__file__).resolve().parent
INPUTS_DIR = HERE / "inputs"
WORK_DIR = HERE / "_sec_work"
REPO_ROOT = HERE.parent.parent.parent


def _verify_inputs_present() -> None:
    for fname in ("gold.sv", "gate.v", "signature.json"):
        path = INPUTS_DIR / fname
        if not path.exists():
            raise FileNotFoundError(
                f"missing input: {path.relative_to(REPO_ROOT)}",
            )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--block-name",
        default="fifo_widget",
        help="block name + target module for proposer + cert payload",
    )
    parser.add_argument(
        "--max-proposals",
        type=int,
        default=3,
        help="number of candidates to ask the LLM proposer for",
    )
    parser.add_argument(
        "--model",
        default="anthropic/claude-opus-4-6",
        help="LLM model id for proposer + invariant_gen calls",
    )
    parser.add_argument(
        "--bound",
        type=int,
        default=32,
        help=(
            "EBMC BMC + k-induction bound. Default 32 per Aidan 2026-05-07 "
            "fleet directive: push higher k-induction bound whenever possible. "
            "Customers re-running this demo against the shipped Todd-bound "
            "cert get stronger soundness than the originally-minted k=10 "
            "captured in _sec_work/ebmc_*.stdout (which remains the audit-of-record)."
        ),
    )
    parser.add_argument(
        "--timeout-sec",
        type=int,
        default=120,
        help="per-EBMC-mode wall-clock timeout (seconds)",
    )
    args = parser.parse_args()

    _verify_inputs_present()

    print(
        f"firing closed-loop orchestration "
        f"(model={args.model}, max_proposals={args.max_proposals}, "
        f"k_induction_bound={args.bound}) ...",
        file=sys.stderr,
    )

    result = run_closed_loop_orchestration(
        bundle_path=INPUTS_DIR,
        target_module=args.block_name,
        block_name=args.block_name,
        model=args.model,
        max_proposals=args.max_proposals,
        k_induction_bound=args.bound,
        timeout_sec=args.timeout_sec,
        work_dir=WORK_DIR,
        repo_root=REPO_ROOT,
        fleet_agent_role=os.environ.get("KAIROS_FLEET_ROLE", "qa"),
        task_id="toy_fifo_chain_v2.7_area_opt",
    )

    print(f"v2.7 demo run_id = {result.parent_run_id}")

    if result.halt_reason == "proposer_halt":
        print(
            f"proposer halted before any proposal: {result.proposer_halt_reason}",
            file=sys.stderr,
        )
        return 3

    for s in result.iteration_summaries:
        print(
            f"  iter {s['iteration_index']}: {s['outcome']} "
            f"({s['transformation_class']}, "
            f"{s['claimed_area_delta_pct']:+.1f}%)",
            file=sys.stderr,
        )

    print(f"\nv2.7 canonical run_id = {result.parent_run_id}", file=sys.stderr)
    print(
        f"navigate to /analytics/silicon-blocks/{result.parent_run_id}",
        file=sys.stderr,
    )
    print(f"halt_reason = {result.halt_reason}", file=sys.stderr)
    print(
        f"summary: {result.cert_payload.get('verdict_summary', '(no cert)')}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
