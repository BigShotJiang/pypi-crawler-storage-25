# Athanor toy_fifo_chain v2.7 closed-loop area-optimization demo

ATH-1053 (parent epic) / ATH-1055 (qa SDK lane) / ATH-1057 (cert template).

## What v2.7 demonstrates

v2.6 cert delivered the *verification side* of Todd's ask. The fixed
`gold.sv` (flop-array) :left_right_arrow: `gate.v` (packed-mem) pair gets verified
under EBMC k-induction with LLM-proposed bridge invariants and Lean
kernel-checked refinement.

But Todd's central ask was *closed-loop area optimization*: propose
structural transformation, verify equivalence, iterate. v2.6 demo runs
against a fixed pair and never demonstrates the propose-area-transform
iteration.

v2.7 closes this gap. The demo driver:

1. takes `gold.sv` as the input RTL block (the original flop-array
   FIFO);
2. invokes the LLM proposer (`kairos.sec.closed_loop._proposer`) on
   the block to discover area-optimization candidates;
3. for each proposed transformation, runs SEC verification (BMC then
   k-induction);
4. on `INCONCLUSIVE` k-induction, calls
   `kairos.sec.closed_loop._invariant_gen` to propose a
   bridge invariant + re-verifies under `assume property`;
5. emits one `transformation_proposed`, `verify_attempt`,
   `bridge_invariant_proposed`, `iteration_verdict`,
   `iteration_complete`, and (if Aristotle/Pythia retroactively
   discharges a bridge) `bridge_lean_closed` event per iteration step;
6. mints a canonical v2.7 `run_id` for cross-arm reference;
7. builds the cert prose with full iteration trace + before/after area
   delta + per-iteration bridges + Lean theorem refs.

## What the customer reads

`/analytics/silicon-blocks/[v2.7-run_id]` renders the iteration arc:

* **Aggregate headline**: "N transformations proposed -> M accepted ->
  final area delta X% (verified to bound Y under bridge Z,
  kernel-checked Lean refinement)"
* **Per-iteration row**: transformation chip (proposer output) +
  verdict chip (accepted / refuted / inconclusive) + bridge invariant
  text + Lean theorem ref (when present) + diagnostic_class on
  REFUTED + area-delta-pct estimate.
* **Honest framing section**: distinguishes accepted transformations
  (final cert claim) from rejected proposals (audit trail).

## Why this design uses the v2.6 inputs

The v2.6 `gold.sv` :left_right_arrow: `gate.v` pair is *already* a
parameterization-class transformation: flop-array
(`logic [27:0] mem [4]`) :left_right_arrow: packed-mem
(`reg [111:0] mem`) with the depth-of-4 FIFO contract preserved. The
proposer should *discover* this pair without being told. That is the
demo: the LLM proposer reasons about FIFO-vs-memory tradeoffs from the
block alone and proposes the same structural rewrite the v2.6 cert
already verified.

If the proposer arrives at a different transformation, the iteration
arc records the candidate + the verify-attempt outcome + carries the
audit trail. Honest framing is by-construction: rejected proposals
land in the cert audit trail alongside the accepted final claim.

## Three-arm defense-in-depth carries through

Mirroring the v2.6 cluster meta-rule:

| Arm | Surface |
|---|---|
| emit-time | `kairos.trace_schema` Pydantic models for the 6 iteration-arc event types (PR #500 merged) |
| render-time | platform `V27IterationArcPanel` + DOM tests |
| boundary-time | platform cross-arm contract test (15 strict-schema validations against canonical fixture) |

Drift on either arm fails CI on both arms via the shared JSON schemas
(`schemas/transformation_proposed.{schema,strict.schema}.json` plus 5
companions on the SDK side; vendored on the platform side via
`scripts/sync-schemas.sh`).

## How to read this package

| File | Audience |
|---|---|
| `README.md` (this file) | Engineer-reading-the-output |
| `01-customer-block-certificate-v2.7.md` | Customer one-pager (lands when the demo run mints) |
| `02-iteration-arc-discharge.md` | Engineer-evaluating-rigor (per-iteration audit trail) |
| `demo_driver.py` | The runner script |
| `inputs/` | gold.sv + gate.v + signature.json (reused from v2.6) |

## Cluster-discipline carry-through

Every meta-rule shipped by v2.6 applies by-construction:

* engine-cross-check on cert headlines (ATH-1018)
* render-then-screenshot-post-emit (instance #10)
* three-arm defense-in-depth (instance #10-A)
* sorry-position-coverage on Aristotle imports (ATH-1051)
* source-truth-holder field-name-pin between SDK emit + dashboard read

By v2.7 the discipline is by-construction, not an iterative-catch
process.

## Customer ship

Off until @aidan green-lights the v2.7 bundle. No Todd ping until
then. Bundle ready when iteration arc renders cleanly + cert reads
honestly + cluster-meta-rule discipline visibly applied.

## Status

Canonical v2.7 run_id minted: `4d9f013c-4a60-49ae-ad86-347ce1f5454c` (2026-05-06).
Outcome distribution from the engine emit: 3 transformations proposed -> 2 accepted (structural -8.0% via bridge invariant `inv_fifo_state_bridge` + structural -5.5% via bridge invariant `inv_state_sync`), 1 refuted (impl_swap -6.0%, real semantic divergence under k-induction hard_refute on bridge `inv_sr_matches_circular_buf`), 0 inconclusive. Halt reason: `proved_equivalent_variant_found`.

Customer-trust contract: PROVED-with-assume on both accepted iterations (EBMC k-induction PASS under bridge invariants `inv_fifo_state_bridge` and `inv_state_sync`, both currently UNPROVEN as Lean theorems; v2.8 follow-up closes each via mirror of v2.6 pythia#93 pattern). claimed area deltas -8.0% and -5.5% are proposer estimates, NOT verified by EBMC (synthesis-tool job).

See `01-customer-block-certificate-v2.7.md` for the one-pager + `03-honest-framing-v2.7.md` for the claimed-vs-verified + UNPROVEN-as-Lean distinctions.
