module fifo_widget_gate(
  input wire        clk,
  input wire        rst_n,
  input wire        push,
  input wire [27:0] push_data,
  output wire       full,
  input wire        pop,
  output wire [27:0] pop_data,
  output wire       empty
);

  // Shift-register FIFO: entry 0 is always the head
  reg [27:0] sr0, sr1, sr2, sr3;
  reg [2:0]  count;

  assign full     = (count == 3'd4);
  assign empty    = (count == 3'd0);
  assign pop_data = sr0;

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sr0   <= 28'd0;
      sr1   <= 28'd0;
      sr2   <= 28'd0;
      sr3   <= 28'd0;
      count <= 3'd0;
    end else begin
      if (do_pop && !do_push) begin
        // Shift down
        sr0   <= sr1;
        sr1   <= sr2;
        sr2   <= sr3;
        sr3   <= 28'd0;
        count <= count - 3'd1;
      end else if (do_push && !do_pop) begin
        // Write to slot[count]
        case (count)
          3'd0: sr0 <= push_data;
          3'd1: sr1 <= push_data;
          3'd2: sr2 <= push_data;
          default: sr3 <= push_data;
        endcase
        count <= count + 3'd1;
      end else if (do_push && do_pop) begin
        // Simultaneously pop (shift) and push into freed slot
        sr0 <= sr1;
        sr1 <= sr2;
        sr2 <= sr3;
        // count-1 is new write index after shift
        case (count - 3'd1)
          3'd0: sr0 <= push_data;
          3'd1: begin sr0 <= sr1; sr1 <= push_data; end
          3'd2: begin sr0 <= sr1; sr1 <= sr2; sr2 <= push_data; end
          default: begin sr0 <= sr1; sr1 <= sr2; sr2 <= sr3; sr3 <= push_data; end
        endcase
        // count unchanged
      end
    end
  end

endmodule