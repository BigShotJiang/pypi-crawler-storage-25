module fifo_widget_gate(
  input wire        clk,
  input wire        rst_n,
  input wire        push,
  input wire [27:0] push_data,
  output wire       full,
  input wire        pop,
  output wire [27:0] pop_data,
  output wire       empty
);

  reg [27:0] mem [0:3];
  reg [1:0]  head_ptr;
  reg [1:0]  tail_ptr;
  reg [2:0]  count;
  reg        full_r;
  reg        empty_r;

  assign full     = full_r;
  assign empty    = empty_r;
  assign pop_data = mem[head_ptr];

  wire do_push = push && !full_r;
  wire do_pop  = pop  && !empty_r;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head_ptr <= 2'd0;
      tail_ptr <= 2'd0;
      count    <= 3'd0;
      full_r   <= 1'b0;
      empty_r  <= 1'b1;
    end else begin
      if (do_push && !do_pop) begin
        mem[tail_ptr] <= push_data;
        tail_ptr <= tail_ptr + 2'd1;
        count    <= count + 3'd1;
        empty_r  <= 1'b0;
        full_r   <= (count == 3'd3);
      end else if (do_pop && !do_push) begin
        head_ptr <= head_ptr + 2'd1;
        count    <= count - 3'd1;
        full_r   <= 1'b0;
        empty_r  <= (count == 3'd1);
      end else if (do_push && do_pop) begin
        mem[tail_ptr] <= push_data;
        tail_ptr <= tail_ptr + 2'd1;
        head_ptr <= head_ptr + 2'd1;
        // count unchanged, full and empty unchanged
      end
    end
  end

endmodule