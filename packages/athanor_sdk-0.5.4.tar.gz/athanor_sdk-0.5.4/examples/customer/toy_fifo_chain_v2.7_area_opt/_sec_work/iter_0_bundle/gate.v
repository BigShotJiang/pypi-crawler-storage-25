module fifo_widget_gate(
  input wire        clk,
  input wire        rst_n,
  input wire        push,
  input wire [27:0] push_data,
  output wire       full,
  input wire        pop,
  output wire [27:0] pop_data,
  output wire       empty
);

  reg [27:0] mem_0;
  reg [27:0] mem_1;
  reg [27:0] mem_2;
  reg [27:0] mem_3;

  reg [2:0] head;
  reg [2:0] tail;

  // empty: pointers equal (including wrap bit)
  // full:  lower bits equal but wrap bits differ
  assign empty = (head == tail);
  assign full  = (head[1:0] == tail[1:0]) && (head[2] != tail[2]);

  // read port: select from flat registers
  assign pop_data = (head[1:0] == 2'd0) ? mem_0 :
                    (head[1:0] == 2'd1) ? mem_1 :
                    (head[1:0] == 2'd2) ? mem_2 :
                                          mem_3;

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head  <= 3'd0;
      tail  <= 3'd0;
      mem_0 <= 28'd0;
      mem_1 <= 28'd0;
      mem_2 <= 28'd0;
      mem_3 <= 28'd0;
    end else begin
      if (do_push) begin
        case (tail[1:0])
          2'd0: mem_0 <= push_data;
          2'd1: mem_1 <= push_data;
          2'd2: mem_2 <= push_data;
          default: mem_3 <= push_data;
        endcase
        tail <= (tail == 3'd7) ? 3'd4 : tail + 3'd1;
      end
      if (do_pop) begin
        head <= (head == 3'd7) ? 3'd4 : head + 3'd1;
      end
    end
  end

endmodule