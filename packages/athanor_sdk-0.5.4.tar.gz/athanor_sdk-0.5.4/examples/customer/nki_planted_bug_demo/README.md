# NKI planted-bug demo (what bug-catching looks like in practice)

This kernel is an intentionally-buggy port. It demonstrates the kind
of bug Athanor's NKI verification pipeline catches that empirical
end-to-end testing typically misses.

## What's wrong with `kernel.py`

The kernel computes a row-wise dot product `y[i] = sum_k A[i,k] * v[k]`
using a tile-PSUM accumulation pattern (the standard pattern an
engineer uses when porting a CUDA reduction loop into NKI). One line
in the per-tile accumulation step **subtracts** the second tile's
contribution where it should **add** it.

The bug is reachable for any input where:

* `K > PARTITION_SIZE` (so tiling is exercised), AND
* The second tile (`k in [128, 256)`) has at least one non-zero
  product `A[i,k] * v[k]`.

For random inputs at `K=256`, that's ~100% of trials. The bug is
*not* reachable when `K <= PARTITION_SIZE` because no tiling happens.

## What the pipeline did

`verify.py` runs five test classes: `basic_shape`, `zero_input`,
`scalar_unit`, `single_tile_passthrough`, and
`differential_against_reference`. The first four pass. The
differential test fails on every one of 32 random trials at `K=256`.

The verifier exits non-zero. `reports/summary.json` reports
`passed: false` with a rationale string explaining exactly which
test class fired and what input pattern triggers the bug.

The `kairos.verticals.neuron_nki.NeuronNKIPlugin` reads
`reports/summary.json` and turns it into a `Verdict` with
`outcome="refuted"`. That is the same Verdict shape Annapurna
leadership sees on the dashboard's per-kernel page.

## Why this matters

* **Empirical end-to-end testing rarely catches this**. The kernel
  produces plausibly-shaped output of the right magnitude. Aggregate
  loss curves look correct. The bug only shows when you compare
  per-row output against a reference implementation under random
  inputs with sufficient K, which is exactly what `verify.py` does.

* **Production CUDA-to-NKI ports hit this class of bug**. Off-by-sign
  and off-by-one errors in tile-PSUM accumulation are common when
  an engineer transliterates a CUDA reduction loop into NKI. The
  pattern is hand-bridged today; the next iteration auto-extracts
  from a Lean spec to eliminate the transliteration step entirely.

* **The customer should reproduce this**. Run
  `python3 verify.py` from this directory. Read
  `reports/summary.json`. Read `reports/test_report.json` for the
  per-trial divergence detail. The output is byte-identical across
  reruns (seed=42).

## How to run

```bash
$ cd examples/customer/nki_planted_bug_demo
$ python3 verify.py
{
  "passed": false,
  "n_tests": 5,
  "n_passed": 4,
  "n_failed": 1,
  ...
}
$ echo $?
1
```

Or via the SDK adapter (emits a `nki_kernel_verified` trace event so
the run shows up on the Verification Coverage card):

```python
from kairos.nki import run_bundle
result = run_bundle("examples/customer/nki_planted_bug_demo")
# result.verdict_outcome == "refuted"
# result.run_id is the dashboard run_id
```

## Customer-discipline note

This kernel is **NOT** a real NKI kernel. It does not compile
through `neuronxcc.nki` or run on Trainium hardware. It is a
Python mock with the structural shape of an NKI tile-PSUM port,
constructed to demonstrate the pipeline's bug-catching behavior on
any machine without requiring the NKI toolchain.

A real Trainium-side reproduction of this same pattern would replace
`kernel.py` with `nki.simulate_kernel(...)` against an actual
NKI-compiled kernel. The verification flow plus the catch shape are
identical; only the kernel-execution layer differs. The catalog
entries platform produces under
`solve/neuron/catalog/<date>/<slug>/` use the real NKI flow.
