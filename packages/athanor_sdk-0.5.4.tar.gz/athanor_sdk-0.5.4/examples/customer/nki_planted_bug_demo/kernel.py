"""kernel.py — DEMONSTRATION KERNEL WITH AN INTENTIONALLY-PLANTED BUG.

This file IS NOT a correct kernel. It contains a deliberate sign error
in the PSUM accumulation step. The sign error is the kind of bug that
slips past empirical end-to-end testing (the output looks plausibly
shaped, magnitudes are within tolerance for many input distributions,
the sign only flips when at least one tile contains a specific
input pattern).

The bug pattern is from real-world experience with hand-written
kernel ports: when an engineer transliterates a CUDA reduction loop
into NKI's tile + PSUM accumulator model, off-by-sign and
off-by-one errors are the most common silent failures.

The accompanying ``verify.py`` runs property + differential tests
against ``reference.py`` (a numerically-correct PyTorch implementation
of the same operation) and SHOULD report a mismatch in
``reports/summary.json``. That mismatch is the demonstration: the
verification harness catches a bug that produces plausibly-shaped
output, before the kernel ships.

Operation
---------

A row-wise dot product over a (M, K) input matrix ``A`` and a
(K,) vector ``v``, producing a (M,) output ``y[i] = sum_k A[i,k] * v[k]``.

Tiling pattern
--------------

NKI tiles ``A`` along the K dimension into PARTITION_SIZE-wide tiles
(here PARTITION_SIZE=128 conceptually; we run on a Python mock so
the partition is purely structural). For each tile, we accumulate
the per-tile dot product into a PSUM register; at the end we sum
the per-tile partials into the output.

The bug
-------

In the per-tile accumulation step, one tile's contribution is
SUBTRACTED instead of added (line marked PLANTED-BUG below).

NB: this kernel does NOT run on a real Trainium / NKI simulator —
it is a Python mock that mirrors the structural pattern of an NKI
port. Real NKI customer kernels in the catalog use
``neuronxcc.nki.simulate_kernel`` or hardware. The pipeline shape
the demo exercises is identical regardless.
"""
from __future__ import annotations

from typing import Sequence

PARTITION_SIZE = 128


def kernel(A: Sequence[Sequence[float]], v: Sequence[float]) -> list[float]:
    """Row-wise dot product, tile-PSUM-style. Returns y[i] = sum_k A[i,k] * v[k].

    INTENTIONALLY BUGGY: line marked PLANTED-BUG below subtracts a
    tile contribution that should have been added. The bug is
    reachable for any input where the second tile (k in [128, 256))
    is non-zero on at least one row.
    """
    if not A:
        return []
    K = len(A[0])

    # Partition K into PARTITION_SIZE-wide tiles.
    tiles: list[range] = []
    start = 0
    while start < K:
        stop = min(start + PARTITION_SIZE, K)
        tiles.append(range(start, stop))
        start = stop

    output: list[float] = []
    for row_idx, row in enumerate(A):
        psum: float = 0.0
        for tile_idx, tile in enumerate(tiles):
            tile_partial = 0.0
            for k in tile:
                tile_partial += row[k] * v[k]
            # PLANTED-BUG: tile_idx == 1 contribution is SUBTRACTED
            # instead of ADDED. Reachable for any K > PARTITION_SIZE.
            if tile_idx == 1:
                psum -= tile_partial
            else:
                psum += tile_partial
        output.append(psum)
    return output
