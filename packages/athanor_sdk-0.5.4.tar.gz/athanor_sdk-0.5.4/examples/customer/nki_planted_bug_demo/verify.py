"""verify.py — verification harness for the planted-bug demo kernel.

Compatible with the kairos.verticals.neuron_nki.NeuronNKIPlugin
contract: this file lives at <bundle>/verify.py, exits 0 on overall
pass + non-zero on overall fail, and writes per-class JSON reports
under <bundle>/reports/. The plugin reads those reports + the exit
code to compose a single Verdict.

Test classes
------------

1. **basic_shape** — kernel output has correct shape for trivial input.
2. **zero_input** — kernel output is all-zeros for all-zeros input.
3. **scalar_unit_test** — single-element input is a passthrough multiply.
4. **differential_against_reference** — many random inputs; kernel
   output matches ``reference.reference`` within fp64 tolerance.
   THIS IS THE TEST THAT CATCHES THE PLANTED BUG.
5. **single_tile_passthrough** — when K <= PARTITION_SIZE, no tiling
   happens; kernel matches reference (this passes — bug is in tile
   index 1 which only exists when K > PARTITION_SIZE).

Reports written
---------------

* ``reports/summary.json`` — overall pass/fail + per-test summary.
* ``reports/test_report.json`` — per-test detailed pass/fail.

Reproducibility
---------------

Random tests use ``random.Random(seed=42)`` for byte-identical
reruns. The planted bug is reachable for ~50% of randomly-generated
inputs at K=256 (any input where tile-1 dot product is non-zero).
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path
from typing import Any

from kernel import kernel
from reference import reference


HERE = Path(__file__).resolve().parent
REPORTS_DIR = HERE / "reports"
REPORTS_DIR.mkdir(exist_ok=True)


def _close_enough(a: list[float], b: list[float], tol: float = 1e-9) -> bool:
    """Pointwise tolerance check; returns False if any element diverges."""
    if len(a) != len(b):
        return False
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def test_basic_shape() -> tuple[bool, str]:
    """Kernel output shape matches input batch dimension."""
    A = [[1.0] * 128]
    v = [1.0] * 128
    out = kernel(A, v)
    if len(out) != 1:
        return False, f"expected output length 1, got {len(out)}"
    return True, "shape ok"


def test_zero_input() -> tuple[bool, str]:
    """All-zeros input produces all-zeros output."""
    A = [[0.0] * 256, [0.0] * 256]
    v = [0.0] * 256
    out = kernel(A, v)
    if not all(x == 0.0 for x in out):
        return False, f"expected zeros, got {out}"
    return True, "zero ok"


def test_scalar_unit() -> tuple[bool, str]:
    """Single-element rows: y[i] = A[i,0] * v[0]."""
    A = [[3.0], [-2.0], [0.5]]
    v = [4.0]
    out = kernel(A, v)
    expected = [12.0, -8.0, 2.0]
    if not _close_enough(out, expected):
        return False, f"expected {expected}, got {out}"
    return True, "scalar ok"


def test_single_tile_passthrough() -> tuple[bool, str]:
    """K <= PARTITION_SIZE means no tiling; kernel = reference."""
    rng = random.Random(42)
    K = 64  # < PARTITION_SIZE=128
    A = [[rng.uniform(-1, 1) for _ in range(K)] for _ in range(8)]
    v = [rng.uniform(-1, 1) for _ in range(K)]
    out = kernel(A, v)
    expected = reference(A, v)
    if not _close_enough(out, expected, tol=1e-9):
        return False, f"diverged at K={K}: kernel={out[:3]}... ref={expected[:3]}..."
    return True, "single-tile ok"


def test_differential_against_reference() -> dict[str, Any]:
    """Random inputs at K > PARTITION_SIZE; differential against reference.

    THIS IS THE TEST THAT CATCHES THE PLANTED BUG. Returns a dict with
    detailed first-divergence info for the report rather than just a
    pass/fail tuple.
    """
    rng = random.Random(42)
    K = 256  # > PARTITION_SIZE=128, so tiling is exercised
    M = 16
    n_iters = 32

    failures: list[dict[str, Any]] = []
    for trial in range(n_iters):
        A = [[rng.uniform(-1, 1) for _ in range(K)] for _ in range(M)]
        v = [rng.uniform(-1, 1) for _ in range(K)]
        out = kernel(A, v)
        expected = reference(A, v)
        # Find divergent rows.
        diverged_rows = []
        for i, (a, b) in enumerate(zip(out, expected)):
            if abs(a - b) > 1e-9:
                diverged_rows.append({
                    "row": i,
                    "kernel_output": a,
                    "reference_output": b,
                    "abs_error": abs(a - b),
                })
        if diverged_rows:
            failures.append({
                "trial": trial,
                "M": M,
                "K": K,
                "n_diverged_rows": len(diverged_rows),
                "first_divergence": diverged_rows[0],
            })

    return {
        "passed": len(failures) == 0,
        "n_trials": n_iters,
        "n_failed_trials": len(failures),
        "first_failure": failures[0] if failures else None,
    }


def main() -> int:
    test_results: list[dict[str, Any]] = []

    # Pass/fail tests.
    for name, fn in [
        ("basic_shape", test_basic_shape),
        ("zero_input", test_zero_input),
        ("scalar_unit", test_scalar_unit),
        ("single_tile_passthrough", test_single_tile_passthrough),
    ]:
        try:
            ok, detail = fn()
        except Exception as exc:  # noqa: BLE001
            ok, detail = False, f"raised: {type(exc).__name__}: {exc}"
        test_results.append({"test": name, "passed": ok, "detail": detail})

    # Differential test (gets its own structured detail).
    diff = test_differential_against_reference()
    test_results.append({
        "test": "differential_against_reference",
        "passed": diff["passed"],
        "detail": (
            f"{diff['n_failed_trials']} of {diff['n_trials']} random trials "
            f"diverged from reference"
            if not diff["passed"]
            else f"{diff['n_trials']} trials all matched reference"
        ),
        "first_failure": diff["first_failure"],
    })

    overall_passed = all(r["passed"] for r in test_results)

    test_report = {"results": test_results}
    (REPORTS_DIR / "test_report.json").write_text(
        json.dumps(test_report, indent=2)
    )

    summary = {
        "passed": overall_passed,
        "n_tests": len(test_results),
        "n_passed": sum(1 for r in test_results if r["passed"]),
        "n_failed": sum(1 for r in test_results if not r["passed"]),
        "kernel": "nki_planted_bug_demo",
        "rationale": (
            "Pipeline correctly identified planted sign-error in "
            "tile-1 PSUM accumulation. The differential test against "
            "the reference fails on ~50% of random trials at K=256 "
            "(any input where the second tile's dot product is "
            "non-zero). Lower-K tests pass because the tiling pattern "
            "doesn't trigger when K ≤ PARTITION_SIZE."
            if not overall_passed
            else "All tests passed (no bug present in this run)."
        ),
    }
    (REPORTS_DIR / "summary.json").write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))
    return 0 if overall_passed else 1


if __name__ == "__main__":
    sys.exit(main())
