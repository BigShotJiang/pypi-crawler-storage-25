"""reference.py — numerically-correct row-wise dot product.

The ``kernel.py`` sibling is intentionally buggy; this file is the
ground truth ``verify.py`` differentials against. No tiling pattern
here — just a direct nested-loop implementation that's easy to read
and trust.
"""
from __future__ import annotations

from typing import Sequence


def reference(A: Sequence[Sequence[float]], v: Sequence[float]) -> list[float]:
    """Row-wise dot product. Returns y[i] = sum_k A[i,k] * v[k]."""
    if not A:
        return []
    output: list[float] = []
    for row in A:
        s = 0.0
        for k, x in enumerate(row):
            s += x * v[k]
        output.append(s)
    return output
