module AP_REG_FIFO_US_gate
(
   fifo_dout_y, fifo_full_x, fifo_afull_x, fifo_empty_y,
   fifo_overrun_err_x,
   fifo_din_x, fifo_push_x, fifo_pop_y, clk, reset_n, fifo_enable
);

   parameter DATA_WIDTH = 32;
   parameter FIFO_DEPTH = 0;
   parameter AFULL_LIMIT = 1;
   parameter EARLY_VALID_SET = 1'b0;
   parameter FIFO_RST_EN = 1'b0;
   parameter DISABLE_EOS_ASSERTION = 1'b0;
   parameter DISABLE_X_WHEN_EMPTY = 1'b0;
   parameter DV_FORCE_RAND_FULL = 1'b1;
   parameter DV_FORCE_RAND_EMPTY = 1'b1;

   input  wire [DATA_WIDTH-1:0] fifo_din_x;
   output wire [DATA_WIDTH-1:0] fifo_dout_y;

   input  wire fifo_push_x;
   input  wire fifo_pop_y;

   output wire fifo_full_x;
   output wire fifo_afull_x;
   output wire fifo_empty_y;
   output wire fifo_overrun_err_x;

   input  wire clk;
   input  wire reset_n;
   input  wire fifo_enable;

   wire dv_force_full;
   wire dv_force_empty;
   assign dv_force_full = 1'b0;
   assign dv_force_empty = 1'b0;

   wire fifo_push_x_qual;
   wire fifo_pop_y_qual;
   assign fifo_push_x_qual = fifo_push_x & ~dv_force_full;
   assign fifo_pop_y_qual = fifo_pop_y & ~dv_force_empty;

   // Push Pointer
   wire [FIFO_DEPTH-1:0] fifo_push_ptr_x;
   wire [FIFO_DEPTH-1:0] fifo_push_ptr_nxt;
   wire fifo_push_load_en;
   assign fifo_push_load_en = fifo_push_x_qual | (~fifo_enable & FIFO_RST_EN);

   generate
      if (FIFO_DEPTH > 1) begin : FIFO_DEEPER
         assign fifo_push_ptr_nxt = (~fifo_enable & FIFO_RST_EN) ?
                  {{(FIFO_DEPTH-1){1'b0}}, 1'b1} :
                  {fifo_push_ptr_x[FIFO_DEPTH-2:0], fifo_push_ptr_x[FIFO_DEPTH-1]};

         reg [FIFO_DEPTH-1:0] fifo_push_ptr_r;
         always @(posedge clk or negedge reset_n) begin
            if (!reset_n)
               fifo_push_ptr_r <= {{(FIFO_DEPTH-1){1'b0}}, 1'b1};
            else if (fifo_push_load_en)
               fifo_push_ptr_r <= fifo_push_ptr_nxt;
         end
         assign fifo_push_ptr_x = fifo_push_ptr_r;
      end else begin : FIFO_DEPTH_1
         assign fifo_push_ptr_nxt[0] = 1'b1;
         assign fifo_push_ptr_x[0] = 1'b1;
      end
   endgenerate

   // Valid Vector
   wire [FIFO_DEPTH-1:0] fifo_wr_en_x;
   assign fifo_wr_en_x = {FIFO_DEPTH{fifo_push_x_qual}} & fifo_push_ptr_x;

   wire [FIFO_DEPTH-1:0] fifo_valid_x;
   wire [FIFO_DEPTH-1:0] fifo_rd_en_y;

   wire [FIFO_DEPTH-1:0] fifo_set_x;
   wire [FIFO_DEPTH-1:0] fifo_clr_x;
   assign fifo_set_x = fifo_wr_en_x & {FIFO_DEPTH{fifo_enable | ~FIFO_RST_EN}};
   assign fifo_clr_x = fifo_rd_en_y | {FIFO_DEPTH{~fifo_enable & FIFO_RST_EN}};

   wire [FIFO_DEPTH-1:0] fifo_valid_nxt_x;
   wire [FIFO_DEPTH-1:0] fifo_valid_early;
   assign fifo_valid_nxt_x = (fifo_set_x | fifo_valid_x) & ~fifo_clr_x;
   assign fifo_valid_early = fifo_set_x | fifo_valid_x;

   reg [FIFO_DEPTH-1:0] fifo_valid_x_r;
   always @(posedge clk or negedge reset_n) begin
      if (!reset_n)
         fifo_valid_x_r <= {FIFO_DEPTH{1'b0}};
      else
         fifo_valid_x_r <= fifo_valid_nxt_x;
   end
   assign fifo_valid_x = fifo_valid_x_r;

   assign fifo_overrun_err_x = |(fifo_wr_en_x & fifo_valid_x);
   assign fifo_full_x = (|(fifo_push_ptr_x & fifo_valid_x)) | ~fifo_enable | dv_force_full;

   // Almost Full
   wire [FIFO_DEPTH-1:0] fifo_afull_vec;
   generate
      if (FIFO_DEPTH > 1) begin : AFULL_ASSEMBLY
         assign fifo_afull_vec = {fifo_valid_x >> AFULL_LIMIT} | {fifo_valid_x[AFULL_LIMIT-1:0], {(FIFO_DEPTH-AFULL_LIMIT){1'b0}}};
      end else begin : AFULL_SINGLE_ENTRY
         assign fifo_afull_vec = {FIFO_DEPTH{1'b1}};
      end
   endgenerate
   assign fifo_afull_x = (|(fifo_afull_vec & fifo_push_ptr_x)) | fifo_full_x;

   // FIFO Data Registers - inlined AP_LDFF_US
   reg [DATA_WIDTH-1:0] fifo_data [0:FIFO_DEPTH-1];

   genvar gi;
   generate
      for (gi = 0; gi < FIFO_DEPTH; gi = gi + 1) begin : FIFO_DATA_REG
         always @(posedge clk) begin
            if (fifo_wr_en_x[gi])
               fifo_data[gi] <= fifo_din_x;
         end
      end
   endgenerate

   // Pop Pointer
   wire [FIFO_DEPTH-1:0] fifo_pop_ptr_y;
   wire [FIFO_DEPTH-1:0] fifo_pop_ptr_nxt;
   wire fifo_pop_load_en;
   assign fifo_pop_load_en = fifo_pop_y_qual | (~fifo_enable & FIFO_RST_EN);

   generate
      if (FIFO_DEPTH > 1) begin : POP_FIFO_DEPTH_GT1
         assign fifo_pop_ptr_nxt = (~fifo_enable & FIFO_RST_EN) ?
                     {{(FIFO_DEPTH-1){1'b0}}, 1'b1} :
                     {fifo_pop_ptr_y[FIFO_DEPTH-2:0], fifo_pop_ptr_y[FIFO_DEPTH-1]};

         reg [FIFO_DEPTH-1:0] fifo_pop_ptr_r;
         always @(posedge clk or negedge reset_n) begin
            if (!reset_n)
               fifo_pop_ptr_r <= {{(FIFO_DEPTH-1){1'b0}}, 1'b1};
            else if (fifo_pop_load_en)
               fifo_pop_ptr_r <= fifo_pop_ptr_nxt;
         end
         assign fifo_pop_ptr_y = fifo_pop_ptr_r;
      end else begin : POP_FIFO_DEPTH_EQ1
         assign fifo_pop_ptr_nxt[0] = 1'b1;
         assign fifo_pop_ptr_y[0] = 1'b1;
      end
   endgenerate

   assign fifo_rd_en_y = {FIFO_DEPTH{fifo_pop_y_qual}} & fifo_pop_ptr_y;

   // Valid for Y-side
   wire [FIFO_DEPTH-1:0] fifo_valid_y;
   assign fifo_valid_y = fifo_valid_x;

   wire fifo_is_valid_y;
   assign fifo_is_valid_y = (EARLY_VALID_SET) ? (|(fifo_pop_ptr_y & fifo_valid_early)) : (|(fifo_pop_ptr_y & fifo_valid_y));
   assign fifo_empty_y = ~fifo_is_valid_y | ~fifo_enable | dv_force_empty;

   // Output Mux - one-hot mux matching gold exactly
   reg [DATA_WIDTH-1:0] fifo_dout;
   integer idx;
   always @(*) begin
      fifo_dout = {DATA_WIDTH{1'b0}};
      for (idx = 0; idx < FIFO_DEPTH; idx = idx + 1) begin
         if (fifo_pop_ptr_y[idx])
            fifo_dout = fifo_data[idx];
      end
   end

   assign fifo_dout_y = (EARLY_VALID_SET & ~|fifo_valid_y) ? fifo_din_x : fifo_dout;

endmodule
