# AP_REG_FIFO_US bundle (Annapurna basic_cells)

ATH-1062 Phase 1 substantive demo target (~200 LoC body + 8 hand-written formal-flow invariants).

Source: `/tmp/annapurna-rtl/common/rtl/anpa_lib_us/basic_cells/rtl/AP_REG_FIFO_US.v` (Author: Gil Stoler, 2011; All Rights Reserved to Annapurna Labs Ltd 2011).

## Why this is the substantive demo

Lines 234-275 of the gold-side RTL contain a `formal_sst_verif_only` ifdef block with 8 hand-written invariants Gil Stoler's formal team uses internally. Per Aidan ambition pin: kairos extends Annapurna's existing formal flow rather than parallel-implementing one.

These 8 invariants are extracted into `signature.json` `formal_invariants_primer[]` (verbatim, with kind / expr or antec+cons / source_line / intent). The LLM proposer reads them in the user prompt as a starter set. Demonstrates the SDK plugs into Annapurna's flow with their own engineers' work as the foundation, not cold-starting.

## What's in this bundle

- `inputs/AP_REG_FIFO_US.v` : verbatim gold-side RTL.
- `signature.json` : hand-extracted port + parameter + clocking metadata + 8 Gil Stoler invariants in `formal_invariants_primer[]`. Cross-validated by `kairos.sec.signature_gen` test suite (PR #513 dedicated test confirms all 8 invariants extract verbatim with correct kind + shape).

## What lands when

- **Phase 1 mint** (after ATH-1063 Phase 0a-wiring + Phase 0b + Phase 0c land on main): closed-loop run produces an iteration arc, EBMC subprocess captures appear in `_sec_work/`, cert markdown authored against the real arc with Gil's invariants seeding the proposer's bridge-invariant-primer set.
- **Phase 2 re-mint** (after ATH-1060 Layer D yosys synth hook lands): cert prose flips from `claimed -X%` to `verified -N gates` with synth log shipped in the bundle.
- **Phase 5 omnibus**: aggregated into `examples/customer/annapurna_demo_v1/` for the Todd-bound chief-architect-readable package.

## Cross-refs

- Parent bundle: ATH-1062.
- Foundation: ATH-1063 (kairos MCP + signature generator + synth hook).
- Ambition pin: ATH-1061.
- Annapurna formal-flow invariants source: gold-side lines 234-275.
