# AP_ALU_US bundle (Annapurna basic_cells)

ATH-1062 Phase 1 domain-generality target (combinational ALU, 148 LoC).

Source: `/tmp/annapurna-rtl/common/rtl/anpa_lib_us/basic_cells/rtl/AP_ALU_US.sv` (Author: Ofer Naaman, 2014; All Rights Reserved to Annapurna Labs Ltd 2011).

## Why this is in Phase 1

Different domain than the FIFO targets : purely combinational (no clk/reset/registers). Demonstrates the SDK closed-loop pipeline isn't only-good-for-FIFOs.

Different proof shape:

- FIFOs: sequential equivalence, k-induction at bound 12, bridge invariants on internal-state correspondence.
- ALU: combinational equivalence, BMC at bound 0, no temporal flow, no bridge invariant needed (output equality across all input combinations).

This drives a known gap surfaced for ATH-1063 dogfood: the generalized demo_driver must handle `is_combinational: true` from `signature.json` to skip clock/reset assumptions and use `ebmc_bound=0` + `bmc_combinational` mode. Auto-generator (Phase 0b) needs to detect combinational-ness from the RTL absence of `always @(posedge clk)`.

Structural transformation candidates the LLM proposer should produce:

- Tree-balance the multi-input mux (`AP_MUX_US` instances).
- Carry-lookahead vs ripple-carry on the ADD/SUB ops.
- Combine SHL/SHR into a single barrel shifter with direction bit.
- Replace per-op-level intermediate registers with combinational forwarding.

## What's in this bundle

- `inputs/AP_ALU_US.sv` : verbatim gold-side RTL.
- `signature.json` : hand-extracted ports + parameters + derived parameter expressions + `is_combinational: true` + `ebmc_bound: 0` + `bmc_combinational` mode flag. Cross-validated by `kairos.sec.signature_gen` test suite (PR #513 detects combinational-ness from absence of clocked patterns + clk port).

## What lands when

- **Phase 1 mint** (after ATH-1063 Phase 0a-wiring + Phase 0b + Phase 0c land): combinational SEC run produces an iteration arc, BMC bound-0 captures appear in `_sec_work/`, cert markdown authored against the real arc.
- **Phase 2 re-mint**: cert prose flips from `claimed -X%` to `verified -N gates` with yosys synth log shipped.
- **Phase 5 omnibus**: aggregated into `examples/customer/annapurna_demo_v1/` Todd-bound package.

## Cross-refs

- Parent bundle: ATH-1062.
- Foundation: ATH-1063 (kairos MCP + signature generator + synth hook).
- Ambition pin: ATH-1061.
