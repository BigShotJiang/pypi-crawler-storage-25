`timescale 1ns/10ps
//===============================================================
// Description: AP_MUX_US (not one hot) 
//
//
//
// Author: Guy Nakibly
// 
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
module AP_MUX_US
(
   // inputs
   din,
   sel,
   // output
   dout
  );
`include "ap_func_US.inc"
   parameter DATA_WIDTH = 1 ;
   parameter NUM_INPUTS = 2 ;
   parameter SEL_WIDTH = AP_LOG2(NUM_INPUTS);

   // inputs
   input [DATA_WIDTH*NUM_INPUTS-1:0] din;
   
   input [SEL_WIDTH-1:0] 	     sel;
   
   // output
   output [DATA_WIDTH-1:0] 	     dout;
   
   
   wire [DATA_WIDTH*NUM_INPUTS-1:0] mux_dout;

   assign mux_dout[DATA_WIDTH-1:0] = (sel == 0) ? din[DATA_WIDTH-1:0] : {DATA_WIDTH{1'b0}};
   
   genvar 		   i;
   generate

   for (i = 1 ; i< NUM_INPUTS ; i=i+1)
     begin : MUX
        assign mux_dout[i*DATA_WIDTH +: DATA_WIDTH] = ((sel == i) ? din[i*DATA_WIDTH +: DATA_WIDTH] : {DATA_WIDTH{1'b0}}) | mux_dout[(i-1)*DATA_WIDTH +: DATA_WIDTH];
     end
   endgenerate   

   assign dout[DATA_WIDTH-1:0] = mux_dout[(NUM_INPUTS-1)*DATA_WIDTH +: DATA_WIDTH];

endmodule // AP_MUX_US



