`timescale 1ns/10ps
//===============================================================
// Description: Arithmetic Logic Unit
//
// opcode:[5]   - ~b Bitwise-inverter on input b
//        [4]   - ~a Bitwise-inverter on input a
//        [3:0] - 0000 = Keep (a)
//                0001 = Arithmetic Add (a+b)
//                0010 = Arithmetic Subtract (a-b)
//                0011 = Bitwise And (a & b)
//                0100 = Bitwise Or (a | b)
//                0101 = Shift Right (a >> b)
//                0110 = Shift Left (a << b)
//                0111 = Bitwise Xor (a ^ b)
//                1000 = mask_lsb (a[b-1:  0]=0)
//                1001 = mask_msb (a[N-1:N-b]=0)
//
//  - Support 1 or 2(*) levels of operation (NUM_OF_OP_LEVELS)
//  - No overflow/underflow guard on arithmetic operations
//  - example ( (a + b) ^ (a' - b') )
//    opsel [0          +: OPSEL_W ] selects input a
//    opsel [OPSEL_W    +: OPSEL_W ] selects input b
//    opsel [OPSEL_W*2  +: OPSEL_W ] selects input a'
//    opsel [OPSEL_W*3  +: OPSEL_W ] selects input b'
//    opcode[0          +:       4 ] selects Add operation
//    opcode[OPCODE_W*1 +:       4 ] selects Subtract operation
//    opcode[OPCODE_W*2 +:       4 ] selects Xor operation
//       __________
//  >---|.a        |
//      |    opcode|
//  >---|.b    0   |------\          ___________
//      |__________|       \        |.a"  (*)   |
//       __________          -------|    opcode |----->
//  >---|.a' (*)   |         -------|.b"    2   |
//      |   opcode |       /        |___________|
//  >---|.b'  1    |------/
//      |__________|
//
//
//
// Author: Ofer Naaman
// Date:   2/Feb/2014
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
`include "ap_func_US.inc"

module AP_ALU_US
#(
        parameter DATA_WIDTH            = 32                            ,
        parameter NUM_OF_INPUTS         = 32                            ,
        parameter NUM_OF_OP_LEVELS      = 2                             ,// 1 or 2

        //implied parameters - do not override
        parameter NUM_OF_OPS            = ((NUM_OF_OP_LEVELS * 2) -1)   ,
        parameter NUM_OF_MUX            = (NUM_OF_OP_LEVELS * 2)        ,
        parameter OPSEL_W               = AP_LOG2(NUM_OF_INPUTS)        ,
        parameter OPCODE_W              = (4 + 2)
)
(/*AUTOARG*/
   output [DATA_WIDTH   - 1 : 0]                                data_out        ,

   input [(NUM_OF_INPUTS * DATA_WIDTH)          - 1 : 0]        data_in         ,
   input [(NUM_OF_MUX * OPSEL_W)                - 1 : 0]        opsel           ,
   input [(NUM_OF_OPS * OPCODE_W)               - 1 : 0]        opcode
   );

   localparam OPCODE_KEEP        = 4'b0000;
   localparam OPCODE_ADD         = 4'b0001;
   localparam OPCODE_SUB         = 4'b0010;
   localparam OPCODE_AND         = 4'b0011;
   localparam OPCODE_OR          = 4'b0100;
   localparam OPCODE_SHR         = 4'b0101;
   localparam OPCODE_SHL         = 4'b0110;
   localparam OPCODE_XOR         = 4'b0111;
   localparam OPCODE_MASK_LSB    = 4'b1000;
   localparam OPCODE_MASK_MSB    = 4'b1001;

   localparam OPCODE_ANOT_OFFSET = 4;
   localparam OPCODE_BNOT_OFFSET = 5;

   //
   wire [(NUM_OF_MUX * DATA_WIDTH)              - 1 : 0]        mux_out                 ;
   wire [(NUM_OF_MUX * DATA_WIDTH)              - 1 : 0]        op_in                   ;
   reg  [(NUM_OF_OP_LEVELS * DATA_WIDTH)        - 1 : 0]        op_out                  ;
   reg  [DATA_WIDTH                             - 1 : 0]        second_op_level_out     ;
   wire [(2 * DATA_WIDTH)                       - 1 : 0]        second_op_level_in      ;

   genvar       i,j;

   generate
   for (i = 0 ; i< NUM_OF_MUX ; i=i+1)
    begin : MUX_OUT_VEC
        AP_MUX_US #(.DATA_WIDTH(DATA_WIDTH), .NUM_INPUTS(NUM_OF_INPUTS)) AP_MUX_US(.dout(mux_out[i * DATA_WIDTH +: DATA_WIDTH]), .din(data_in), .sel(opsel[i * OPSEL_W +: OPSEL_W]));
    end
   endgenerate

   generate
   for (j = 0 ; j< NUM_OF_OP_LEVELS ; j=j+1)
    begin : OP_NUM
        assign op_in[(((j * 2)    ) * DATA_WIDTH) +: DATA_WIDTH] = (opcode[(j * OPCODE_W) + OPCODE_ANOT_OFFSET] == 1'b1) ? ~mux_out[(((j * 2)    ) * DATA_WIDTH) +: DATA_WIDTH] : mux_out[(((j * 2)    ) * DATA_WIDTH) +: DATA_WIDTH];
        assign op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH] = (opcode[(j * OPCODE_W) + OPCODE_BNOT_OFFSET] == 1'b1) ? ~mux_out[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH] : mux_out[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];

always @(*)
        case (opcode[(j * OPCODE_W) +: 4])
          OPCODE_ADD      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] + op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_SUB      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] - op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_AND      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] & op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_OR       : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] | op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_SHR      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] >>op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_SHL      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] <<op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_XOR      : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] ^ op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH];
          OPCODE_MASK_LSB : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] & ({DATA_WIDTH{1'b1}} << op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH] );
          OPCODE_MASK_MSB : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH] & ({DATA_WIDTH{1'b1}} >> op_in[(((j * 2) + 1) * DATA_WIDTH) +: DATA_WIDTH] );
          default         : op_out[j*DATA_WIDTH +: DATA_WIDTH] = op_in[((j * 2) * DATA_WIDTH) +: DATA_WIDTH];
        endcase

    end
   endgenerate

   generate
   if(NUM_OF_OP_LEVELS == 2)
    begin : SECOND_OP_LEVEL
        assign second_op_level_in[0             +: DATA_WIDTH] = (opcode[(2 * OPCODE_W) + OPCODE_ANOT_OFFSET] == 1'b1) ? ~op_out[0              +: DATA_WIDTH] : op_out[0               +: DATA_WIDTH];
        assign second_op_level_in[DATA_WIDTH    +: DATA_WIDTH] = (opcode[(2 * OPCODE_W) + OPCODE_BNOT_OFFSET] == 1'b1) ? ~op_out[DATA_WIDTH     +: DATA_WIDTH] : op_out[DATA_WIDTH      +: DATA_WIDTH];

always @(*)
        case (opcode[(2 * OPCODE_W) +: 4])
          OPCODE_ADD      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] + second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_SUB      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] - second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_AND      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] & second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_OR       : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] | second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_SHR      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] >>second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_SHL      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] <<second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_XOR      : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] ^ second_op_level_in[DATA_WIDTH +: DATA_WIDTH];
          OPCODE_MASK_LSB : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] & ({DATA_WIDTH{1'b1}} << second_op_level_in[DATA_WIDTH +: DATA_WIDTH]);
          OPCODE_MASK_MSB : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH] & ({DATA_WIDTH{1'b1}} >> second_op_level_in[DATA_WIDTH +: DATA_WIDTH]);
          default         : second_op_level_out [0 +: DATA_WIDTH] = second_op_level_in[0 +: DATA_WIDTH];
        endcase
        assign data_out = second_op_level_out;

    end else begin : NO_SECOND_OP_LEVEL
        assign data_out = op_out[0 +: DATA_WIDTH];
    end
   endgenerate


endmodule
