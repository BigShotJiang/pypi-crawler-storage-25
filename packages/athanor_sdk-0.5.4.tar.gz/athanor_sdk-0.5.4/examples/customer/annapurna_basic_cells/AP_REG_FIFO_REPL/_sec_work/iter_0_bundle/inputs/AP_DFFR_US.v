`timescale 1ns/10ps
//===============================================================
// Description: Basic Flop with negative polarity async reset.
//
// Author: Gil Stoler
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
`ifndef qdelay
 `define qdelay 0.1
`endif
 
module AP_DFFR_US
(/*AUTOARG*/
   // Outputs
   dout,
   // Inputs
   din, clk, reset_n
   );
//
   parameter DATA_WIDTH = 1 ;
   parameter INIT_VAL = {DATA_WIDTH{1'b0}} ;  
//      
input  [DATA_WIDTH-1:0] din;
output [DATA_WIDTH-1:0] dout;
input clk;
input reset_n;

// Code start:
   reg [DATA_WIDTH-1:0] dout;
   
always @ (posedge clk or negedge reset_n)
`ifdef ANPA_SIM_FAST
  if (~reset_n) dout <= INIT_VAL ;
  else dout <= din ;
`else
  if (~reset_n) dout <= #`qdelay  INIT_VAL ;
  else dout <= #`qdelay din ;
`endif   // ANPA_SIM_FAST

endmodule // AP_DFFR_US

	       



   
