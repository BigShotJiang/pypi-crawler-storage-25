`timescale 1ns/10ps
//===============================================================
// Description: Synchronous Fifo with One-Hot triggers
//
// Notes/Restrictions:
//   1. Push is asserted ONLY if place is available.
//      Asserting Push when no entry avaliability - results in Error Assertion.
//
//
// Author: Gil Stoler
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
module AP_REG_FIFO_US
(/*AUTOARG*/
   // Outputs
   fifo_dout_y, fifo_full_x, fifo_afull_x, fifo_empty_y,
   fifo_overrun_err_x,
   // Inputs
   fifo_din_x, fifo_push_x, fifo_pop_y, clk, reset_n, fifo_enable
   );
//
   parameter DATA_WIDTH = 32 ;
   parameter FIFO_DEPTH = 0 ; // must be overridden
   parameter AFULL_LIMIT = 1 ;
   parameter EARLY_VALID_SET = 1'b0 ;
   parameter FIFO_RST_EN = 1'b0;
   parameter DISABLE_EOS_ASSERTION = 1'b0;
   parameter DISABLE_X_WHEN_EMPTY= 1'b0;
   parameter DV_FORCE_RAND_FULL=1'b1;
   parameter DV_FORCE_RAND_EMPTY=1'b1;

//
   input  [DATA_WIDTH-1:0] fifo_din_x;
   output [DATA_WIDTH-1:0] fifo_dout_y;

   input 		fifo_push_x ;
   input 		fifo_pop_y ;

   output 		fifo_full_x ;
   output 		fifo_afull_x ;
   output 		fifo_empty_y ;
   output 		fifo_overrun_err_x;


   input 		 clk;
   input 		 reset_n;

   input 		 fifo_enable;

   // Check parameters values:
   // synopsys translate_off
   if(FIFO_DEPTH == 0)
      $error("elab Error: FIFO_DEPTH was not overridden");
   // synopsys translate_on

// Code start:

// X-Side
   //
   logic fifo_push_x_qual, fifo_pop_y_qual;
   logic dv_force_full, dv_force_empty;

   assign fifo_push_x_qual = fifo_push_x & ~dv_force_full;
   assign fifo_pop_y_qual = fifo_pop_y & ~dv_force_empty;

   // Push Pointer:
   wire [FIFO_DEPTH-1:0] fifo_push_ptr_x ;
   wire [FIFO_DEPTH-1:0] fifo_push_ptr_nxt ;
   wire fifo_push_load_en = fifo_push_x_qual | ( ~fifo_enable &  FIFO_RST_EN) ;

   generate
      if (FIFO_DEPTH > 1)
	begin : FIFO_DEEPER
	   assign fifo_push_ptr_nxt =  ( ~fifo_enable &  FIFO_RST_EN) ?
			 {{(FIFO_DEPTH-1){1'b0}},1'b1} :
			 {fifo_push_ptr_x[FIFO_DEPTH-2:0],fifo_push_ptr_x[FIFO_DEPTH-1]};

	   AP_LDFFR_US #(.DATA_WIDTH(FIFO_DEPTH), .INIT_VAL({{(FIFO_DEPTH-1){1'b0}},1'b1})) fifo_push_ptr_scr (.dout(fifo_push_ptr_x[FIFO_DEPTH-1:0]),
							    .din(fifo_push_ptr_nxt[FIFO_DEPTH-1:0]),
							    .clk(clk), .load(fifo_push_load_en), .reset_n(reset_n));
	end else begin : FIFO_DEPTH_1
	   assign fifo_push_ptr_nxt[0] = 1'b1;
	   assign fifo_push_ptr_x[0] = 1'b1;
	end
   endgenerate


   // Valid Vector
   wire [FIFO_DEPTH-1: 0] fifo_wr_en_x = {FIFO_DEPTH{fifo_push_x_qual}} & fifo_push_ptr_x;
   wire [FIFO_DEPTH-1:0] fifo_valid_x ;
   wire [FIFO_DEPTH-1:0] fifo_rd_en_y ;

   wire [FIFO_DEPTH-1:0] fifo_set_x  = fifo_wr_en_x & {FIFO_DEPTH{fifo_enable | ~FIFO_RST_EN}}; // single write per clock.
   wire [FIFO_DEPTH-1:0] fifo_clr_x  = fifo_rd_en_y | {FIFO_DEPTH{~fifo_enable & FIFO_RST_EN}}; // may be multiple clears per clock if accumulated...

   wire [FIFO_DEPTH-1:0] fifo_valid_nxt_x = (fifo_set_x | fifo_valid_x) & ~fifo_clr_x ; // Clr Wins.
   wire [FIFO_DEPTH-1:0] fifo_valid_early = fifo_set_x | fifo_valid_x ; // Set Wins.


   AP_DFFR_US #(.DATA_WIDTH(FIFO_DEPTH)) fifo_valid_x_scr (.dout(fifo_valid_x),.din(fifo_valid_nxt_x), .clk(clk), .reset_n(reset_n));
   //
   assign fifo_overrun_err_x = |(fifo_wr_en_x & fifo_valid_x) ; // This is stronger than "full" only.
     // if clear happens to access multiple entries, and create a hole-pattern, attempt to write into a valid entry
     // still results in error report, while "ANDING" all valids to state "Full" will not be asserted at "holes" scenario.
   assign fifo_full_x = (|(fifo_push_ptr_x & fifo_valid_x)) | ~fifo_enable  | dv_force_full;
     // Again - protected against "holes" scenario.
     // Force full indication while Y-Side is not out of reset.

   // Fifo Almost Full Tracker.
   wire [FIFO_DEPTH-1:0] fifo_afull_vec ;

   generate
      if (FIFO_DEPTH >1)
	begin : AFULL_ASSEMBLY
	   assign fifo_afull_vec = { fifo_valid_x >> AFULL_LIMIT } | {fifo_valid_x[AFULL_LIMIT-1:0], {(FIFO_DEPTH-AFULL_LIMIT){1'b0}}};
	end
      else
	begin : AFULL_SINGLE_ENTRY
	   assign fifo_afull_vec = {FIFO_DEPTH{1'b1}} ;
	end
   endgenerate
   assign fifo_afull_x = (|(fifo_afull_vec & fifo_push_ptr_x)) | fifo_full_x ;

   //-------------------------------
   // Comments for the Cross-Sides X/Y):
   //
   // Transferring the Wr_En vector to the Y-Side.
   // Though wr_en is one hot at the x_side, it can be Multi-asserted at the Y-Side, leading to count that is more than increment-by-1.
   // For that purpose, the wr_en vector is fully sync (bit by bit) to the Y-Side.
   // Same applies for Pop indication delived as single pop at Y-side and may appear as Multi-pop at X-Side.

   // Fifo-Registers.
   // SA - converting to 2D unpacked
   // wire [DATA_WIDTH*FIFO_DEPTH -1: 0] fifo_data ;
   wire [FIFO_DEPTH-1:0] [DATA_WIDTH -1: 0] fifo_data;

   genvar 		 i ;
   generate
      for (i=0 ; i<FIFO_DEPTH ; i=i+1)
	begin : FIFO_ENTRY_PACK
	   // Fifo Entry (data)
      // SA - converting to 2D unpacked
	   // AP_LDFF_US #(.DATA_WIDTH(DATA_WIDTH)) fifo_entry (.dout(fifo_data[i*DATA_WIDTH +: DATA_WIDTH]), .din(fifo_din_x),.load(fifo_wr_en_x[i]), .clk(clk));
      AP_LDFF_US #(.DATA_WIDTH(DATA_WIDTH)) fifo_entry (.dout(fifo_data[i]), .din(fifo_din_x),.load(fifo_wr_en_x[i]), .clk(clk));
   	end
   endgenerate

// Y-Side
   // Fifo Output Mux:
   // Note: pointed out info is steady by using the pop pointer. No condition on actual POP-Y to avoid timing issues and as there is not issue
   // in having the data available at all times.
   // Usage of this data is the responsibility of the user, taking into account the empty/valid information.
   //
   // Pop Pointer:
   wire [FIFO_DEPTH-1:0] fifo_pop_ptr_y ;
   wire [FIFO_DEPTH-1:0] fifo_pop_ptr_nxt ;
   wire fifo_pop_load_en = fifo_pop_y_qual | ( ~fifo_enable &  FIFO_RST_EN) ;
   generate
      if (FIFO_DEPTH > 1)
	begin : POP_FIFO_DEPTH_GT1
	   assign fifo_pop_ptr_nxt =  ( ~fifo_enable &  FIFO_RST_EN) ?
				      {{(FIFO_DEPTH-1){1'b0}},1'b1} :
				      {fifo_pop_ptr_y[FIFO_DEPTH-2:0],fifo_pop_ptr_y[FIFO_DEPTH-1]};

	   AP_LDFFR_US #(.DATA_WIDTH(FIFO_DEPTH), .INIT_VAL({{(FIFO_DEPTH-1){1'b0}},1'b1})) fifo_pop_ptr_scr (.dout(fifo_pop_ptr_y[FIFO_DEPTH-1:0]),
													   .din(fifo_pop_ptr_nxt[FIFO_DEPTH-1:0]),
													   .clk(clk), .load(fifo_pop_load_en), .reset_n(reset_n));
	end else begin : POP_FIFO_DEPTH_EQ1
	   assign fifo_pop_ptr_nxt[0] = 1'b1 ;
	   assign fifo_pop_ptr_y[0] = 1'b1;
	end
   endgenerate

   // Assembling real "read/pop" condition for transferring the "clear" info to the X-Side.
   assign fifo_rd_en_y = {FIFO_DEPTH{fifo_pop_y_qual}} & fifo_pop_ptr_y ;

   // Valid for usage at Y-Side:

   wire [FIFO_DEPTH-1:0] fifo_valid_y = fifo_valid_x;

   wire 		 fifo_is_valid_y = (EARLY_VALID_SET) ? (|(fifo_pop_ptr_y & fifo_valid_early)) : (|(fifo_pop_ptr_y & fifo_valid_y));
   //                    provision for "not empty" indication right when out of SYNC, or conservative when logged in local valid vector at Y-Side.
   assign fifo_empty_y = ~fifo_is_valid_y | ~fifo_enable | dv_force_empty;

                        // Force empty condition while X-side is not out of reset yet.

   // Final Data Out Muxing:
   logic [DATA_WIDTH-1:0] fifo_dout;
   // SA - converting to 2D unpacked
   // AP_ONEHOTMUX_US #(.DATA_WIDTH(DATA_WIDTH), .NUM_INPUTS(FIFO_DEPTH)) fifo_dout_mux (.dout(fifo_dout), .din(fifo_data), .sel(fifo_pop_ptr_y));
   always_comb begin
     fifo_dout = {DATA_WIDTH{1'b0}};
     `ifdef assert_code
     if (fifo_empty_y && !DISABLE_X_WHEN_EMPTY) begin
         fifo_dout = {DATA_WIDTH{1'bx}};
     end else
     `endif
     for(int i=0; i<FIFO_DEPTH; i++)
       if(fifo_pop_ptr_y[i])
         fifo_dout = fifo_data[i];
   end
   assign fifo_dout_y = (EARLY_VALID_SET & ~|fifo_valid_y) ? fifo_din_x : fifo_dout;


`ifdef assert_code
  wire reset=!reset_n;
  wire enable=1'b1;

  //coverage
  logic 		 at_least_one_push;

  always @(posedge clk) begin
    if(reset) at_least_one_push<=1'b0;
  	else if (fifo_push_x_qual & fifo_enable)
  	  at_least_one_push<=1'b1;
  end


  COVER_PROP fifo_full_cover (.expr(fifo_enable && fifo_full_x),.*);
  COVER_PROP fifo_almost_full_cover (.expr(fifo_enable && fifo_afull_x),.*);
  COVER_PROP fifo_empty_cover (.expr( fifo_enable && at_least_one_push & fifo_empty_y),.*);

  ASSERT_NEVER never_pop_when_fifo_is_empty(.expr(fifo_enable & fifo_empty_y & fifo_pop_y),.*);
  ASSERT_NEVER never_push_when_fifo_is_full(.expr(fifo_enable & fifo_full_x & fifo_push_x),.*);

  `ifdef check_end_of_sim_asserts
    if(!DISABLE_EOS_ASSERTION) begin
      ASSERT_IMPL quiesce_eos(.antec(`end_of_sim_signal),.cons(fifo_empty_y),.*);
    end
  `endif

  `ifdef formal_sst_verif_only
    ASSERT_NEVER invar_fifo_empty_status(.expr(fifo_enable && fifo_empty_y && |fifo_valid_x),.*);
    ASSERT_NEVER invar_fifo_full_status (.expr(fifo_enable && fifo_full_x && fifo_valid_x!={FIFO_DEPTH{1'b1}}),.*);
    ASSERT_ALWAYS invar_fifo_push_next_ptr_onehot (.expr($onehot(fifo_push_ptr_nxt)),.*);
    ASSERT_ALWAYS invar_fifo_pop_next_ptr_onehot (.expr($onehot(fifo_pop_ptr_nxt)),.*);


    ASSERT_IMPL invar_fifo_full_empty_ptrs (.antec(fifo_full_x || fifo_empty_y),.cons(fifo_push_ptr_x==fifo_pop_ptr_y),.*);
    ASSERT_IMPL invar_fifo_not_full_ptr (.antec(!fifo_full_x),.cons((fifo_push_ptr_x & fifo_valid_x)=='0),.*);
    ASSERT_IMPL invar_fifo_not_empty_ptr (.antec(!fifo_empty_y),.cons((fifo_pop_ptr_y & fifo_valid_x)!='0),.*);

    localparam FIFO_DEPTH_LG2=$clog2(FIFO_DEPTH);

    logic [FIFO_DEPTH_LG2:0] push_ptr;
    logic [FIFO_DEPTH_LG2:0] pop_ptr;
    always_comb begin
      for(int i=0;i<FIFO_DEPTH;i++) begin
        if(fifo_push_ptr_x[i]) push_ptr=i;
        if(fifo_pop_ptr_y[i]) pop_ptr=i;
      end
    end

    logic [FIFO_DEPTH-1:0] expected_valid_vector;
    always_comb begin
      expected_valid_vector='0;
      if(fifo_full_x) expected_valid_vector={FIFO_DEPTH{1'b1}};
      if(push_ptr>pop_ptr) begin
        for(int i=0;i<FIFO_DEPTH;i++) begin
          if(i<push_ptr && i>=pop_ptr) expected_valid_vector[i]=1'b1;
        end
      end
      if(push_ptr<pop_ptr) begin
       for(int i=0;i<FIFO_DEPTH;i++) begin
         if(i<push_ptr) expected_valid_vector[i]=1'b1;
         if(i>=pop_ptr) expected_valid_vector[i]=1'b1;
       end
      end
    end

    ASSERT_ALWAYS invar_fifo_valid_vec (.expr(fifo_valid_x==expected_valid_vector),.*);


  `endif

`ifndef ZEBU_BUILD
`ifdef staller_enable
  string hier_path;
  logic not_notific_inst;
  logic not_peb_sp_splitter;
  logic enable_dv_gen;
  logic not_user_errtrig_aw_req_fifo;
  logic not_user_errtrig_regular_fifo;
  logic not_user_errtrig_axi_aw_cmd_fifo;
  logic not_tpb_arr_seq_sfifo;
  logic dv_force_full_gen;

  `ifdef SIMULATION
   import uvm_pkg::*;
   `include "uvm_macros.svh"
   initial begin
     hier_path = $psprintf("%m");
     // TODO *notific* is too common of a string to waive all instances with that string,
     //    but placed here for now for cayman-4089
     // not_notific_inst = uvm_pkg::uvm_re_match(".*notific.*", hier_path);
     not_notific_inst = uvm_pkg::uvm_re_match(".*use_coal_gen.u_notific_coalescer.bresp_fifo.*", hier_path);
     // cayman-4420: fifo_full signal is used by splitter RTL and causes issues
     // while combining split txn responses
     not_peb_sp_splitter = uvm_pkg::uvm_re_match(".*u_peb_sp_m_splitter.u_ap_axi_rob_split_v5.rresp_fifo.*", hier_path);

     not_user_errtrig_aw_req_fifo = uvm_pkg::uvm_re_match(".*msix_write_gen.AWREQ_FIFO.axi_req_fifo.*",hier_path);

     not_user_errtrig_regular_fifo = uvm_pkg::uvm_re_match(".*msix_write_gen.REGULAR_FIFO.axi_wdata_fifo.*",hier_path);

     not_user_errtrig_axi_aw_cmd_fifo = uvm_pkg::uvm_re_match(".*msix_write_gen.axi_aw_cmd_fifo.*",hier_path);

     not_tpb_arr_seq_sfifo = uvm_pkg::uvm_re_match(".*tpb_array_sequencer_sbuf_rd_rsp_bus.u_ind_off_sfifo.*",hier_path);

     enable_dv_gen = not_notific_inst
                     & not_peb_sp_splitter
                     & not_user_errtrig_aw_req_fifo
                     & not_user_errtrig_regular_fifo
                     & not_user_errtrig_axi_aw_cmd_fifo
                     & not_tpb_arr_seq_sfifo
                     ;

     //$display("SDMA handling:not");
     //$display(hier_path);
   end
  `endif //SIMULATION

  `ifdef formal_verif_only_staller
   assign enable_dv_gen = 1'b1;
  `endif

  generate if (DV_FORCE_RAND_FULL) begin: b_ff
      rand_staller force_full (.clk(clk), .resetn(reset_n), .stall(dv_force_full_gen));
      assign dv_force_full = dv_force_full_gen & enable_dv_gen;
  end else begin
      assign dv_force_full = 1'b0;
  end
  endgenerate
  `ifdef cover_code_anpa_basic
      COVER_PROP dv_force_full_asserted (.clk(clk), .reset(~reset_n), .enable(1'b1), .expr(dv_force_full));
  `endif
`else
      assign dv_force_full = 1'b0;
`endif
`else
      assign dv_force_full = 1'b0;
`endif//ZEBU_BUILD


//`ifdef staller_enable
  //generate if (DV_FORCE_RAND_EMPTY) begin: b_fe
      //rand_staller force_empty (.clk(clk), .resetn(reset_n), .stall(dv_force_empty));
  //end else begin
      //assign dv_force_empty= 1'b0;
  //end
  //endgenerate
//`else
      //assign dv_force_empty = 1'b0;
//`endif
  assign dv_force_empty= 1'b0;


`else
     assign dv_force_full = 1'b0;
     assign dv_force_empty= 1'b0;
`endif

`ifdef cover_code
  common_sync_fifo_coverage
  #(.HAS_AFULL(1))
  u_ap_reg_fifo_v1_fifo_cov
  (
    // Clocks and Resets
    .clk     (clk),
    .reset_n (reset_n),

    // FIFO Signals
    .dv_force_full    (dv_force_full),
    .fifo_afull       (fifo_afull_x),
    .fifo_enable      (fifo_enable),
    .fifo_empty       (fifo_empty_y),
    .fifo_full        (fifo_full_x),
    .fifo_push        (fifo_push_x)
  );
`endif

endmodule //
