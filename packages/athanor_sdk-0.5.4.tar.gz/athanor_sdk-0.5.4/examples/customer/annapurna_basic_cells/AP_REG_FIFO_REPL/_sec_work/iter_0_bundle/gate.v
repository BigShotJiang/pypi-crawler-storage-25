`timescale 1ns/10ps
module AP_REG_FIFO_REPL_gate #(
       parameter DATA_WIDTH             = 32,
       parameter FIFO_DEPTH             = 0,
       parameter AFULL_LIMIT            = 1,
       parameter EARLY_VALID_SET        = 1'b0,
       parameter FIFO_RST_EN            = 1'b0,
       parameter DISABLE_EOS_ASSERTION  = 1'b0,
       parameter DISABLE_X_WHEN_EMPTY   = 1'b0,
       parameter DV_FORCE_RAND_FULL     = 1'b1,
       parameter DV_FORCE_RAND_EMPTY    = 1'b1,
       parameter FIFO_REPL_BITS         = 512
)
(
   fifo_dout_y, fifo_full_x, fifo_afull_x, fifo_empty_y,
   fifo_overrun_err_x,
   fifo_din_x, fifo_push_x, fifo_pop_y, clk, reset_n, fifo_enable
);

   input  [DATA_WIDTH-1:0] fifo_din_x;
   output [DATA_WIDTH-1:0] fifo_dout_y;

   input                   fifo_push_x;
   input                   fifo_pop_y;

   output                  fifo_full_x;
   output                  fifo_afull_x;
   output                  fifo_empty_y;
   output                  fifo_overrun_err_x;

   input                   clk;
   input                   reset_n;
   input                   fifo_enable;

   AP_REG_FIFO_US #(
      .DATA_WIDTH              (DATA_WIDTH),
      .FIFO_DEPTH              (FIFO_DEPTH),
      .AFULL_LIMIT             (AFULL_LIMIT),
      .EARLY_VALID_SET         (EARLY_VALID_SET),
      .FIFO_RST_EN             (FIFO_RST_EN),
      .DISABLE_EOS_ASSERTION   (DISABLE_EOS_ASSERTION),
      .DISABLE_X_WHEN_EMPTY    (DISABLE_X_WHEN_EMPTY),
      .DV_FORCE_RAND_FULL      (DV_FORCE_RAND_FULL),
      .DV_FORCE_RAND_EMPTY     (DV_FORCE_RAND_EMPTY)
   ) reg_fifo_single (
      .fifo_din_x              (fifo_din_x),
      .fifo_dout_y             (fifo_dout_y),
      .fifo_push_x             (fifo_push_x),
      .fifo_pop_y              (fifo_pop_y),
      .fifo_full_x             (fifo_full_x),
      .fifo_afull_x            (fifo_afull_x),
      .fifo_empty_y            (fifo_empty_y),
      .fifo_overrun_err_x      (fifo_overrun_err_x),
      .clk                     (clk),
      .reset_n                 (reset_n),
      .fifo_enable             (fifo_enable)
   );

endmodule
