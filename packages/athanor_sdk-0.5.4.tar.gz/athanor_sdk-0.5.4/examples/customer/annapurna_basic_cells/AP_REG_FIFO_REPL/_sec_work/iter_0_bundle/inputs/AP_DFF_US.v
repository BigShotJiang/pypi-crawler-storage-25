`timescale 1ns/10ps
//===============================================================
// Description: Basic Flop without reset.
//
// Author: Gil Stoler
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================

`ifndef qdelay
 `define qdelay 0.1
`endif
 
module AP_DFF_US
(/*AUTOARG*/
   // Outputs
   dout,
   // Inputs
   din, clk
   );

  
   parameter DATA_WIDTH = 1 ;
//      
input  [DATA_WIDTH-1:0] din;
output [DATA_WIDTH-1:0] dout;
input clk;

// Code start:
   reg [DATA_WIDTH-1:0] dout;
   
`ifdef ANPA_SIM_FAST
always @ (posedge clk) dout <= din ;
`else
always @ (posedge clk) dout <= #`qdelay din ;
`endif   // ANPA_SIM_FAST

endmodule 

	       



   
