`timescale 1ns/10ps
//=====================================================================
// Description: Basic Flop with async reset and load.
//
// Author: Gil Stoler
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//=====================================================================
`ifndef qdelay
 `define qdelay 0.1
`endif

module AP_LDFFR_US
(/*AUTOARG*/
   // Outputs
   dout,
   // Inputs
   din, clk, reset_n, load
   );
//
   parameter DATA_WIDTH = 1 ;
   parameter INIT_VAL = {DATA_WIDTH{1'b0}} ;
//
   input  [DATA_WIDTH-1:0] din;
   output [DATA_WIDTH-1:0] dout;
   input clk;
   input reset_n;
   input load ;

// Code start:
   reg [DATA_WIDTH-1:0] dout;
   `ifdef X2RANDOM

	integer seed;
	initial
	begin
		seed = $get_initial_random_seed();
		void'($urandom(seed));
	end
    `endif

always @ (posedge clk or negedge reset_n)
`ifdef ANPA_SIM_FAST
  if (~reset_n) dout <= INIT_VAL ;
  else if (load) dout <= din ;
`else
  if (~reset_n) dout <= #`qdelay INIT_VAL ;
  else if (load) dout <= #`qdelay din ;
`endif   // ANPA_SIM_FAST
`ifndef AL_EMULATION_COMPILE
// synopsys translate_off
`ifdef ANPA_SIM_FAST
	else if (~load) dout <= dout ;
	else  if(din === dout)           dout <= din ;  // Relax X propogation
`else
	else if (~load) dout <= #`qdelay dout ;
	else  if(din === dout)           dout <= #`qdelay din ;  // Relax X propogation
`endif   // ANPA_SIM_FAST
`ifdef X2RANDOM
	else begin
		for (integer i=0; i<DATA_WIDTH;i = i+1) begin
			dout[i] <= #`qdelay ($urandom()%2);
		end
	end
`else
`ifdef ANPA_SIM_FAST
	else             dout <= {DATA_WIDTH{1'bx}} ;  // Cover X' and Z' cases.
`else
	else             dout <= #`qdelay {DATA_WIDTH{1'bx}} ;  // Cover X' and Z' cases.
`endif   // ANPA_SIM_FAST
`endif
// synopsys translate_on
`endif
endmodule




