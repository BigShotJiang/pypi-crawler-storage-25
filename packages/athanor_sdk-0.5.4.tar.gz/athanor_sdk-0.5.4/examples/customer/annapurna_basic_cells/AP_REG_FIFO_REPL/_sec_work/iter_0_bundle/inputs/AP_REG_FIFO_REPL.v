`timescale 1ns/10ps
//===============================================================
// Description: Synchronous Fifo with One-Hot triggers
//
// Notes/Restrictions:
//   1. Push is asserted ONLY if place is available.
//      Asserting Push when no entry avaliability - results in Error Assertion.
//
//
// Author: rudreshz
// Date:   2025
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
module AP_REG_FIFO_REPL #(
       parameter DATA_WIDTH             = 32,
       parameter FIFO_DEPTH             = 0, // must be overridden
       parameter AFULL_LIMIT            = 1,
       parameter EARLY_VALID_SET        = 1'b0,
       parameter FIFO_RST_EN            = 1'b0,
       parameter DISABLE_EOS_ASSERTION  = 1'b0,
       parameter DISABLE_X_WHEN_EMPTY   = 1'b0,
       parameter DV_FORCE_RAND_FULL     = 1'b1,
       parameter DV_FORCE_RAND_EMPTY    = 1'b1,
   
       //replication boundary width 
       parameter FIFO_REPL_BITS         = 512
)
(
   // Outputs
   fifo_dout_y, fifo_full_x, fifo_afull_x, fifo_empty_y,
   fifo_overrun_err_x,
   // Inputs
   fifo_din_x, fifo_push_x, fifo_pop_y, clk, reset_n, fifo_enable
);

   input  [DATA_WIDTH-1:0] fifo_din_x;
   output [DATA_WIDTH-1:0] fifo_dout_y;

   input                   fifo_push_x;
   input                   fifo_pop_y;

   output                  fifo_full_x;
   output                  fifo_afull_x;
   output                  fifo_empty_y;
   output                  fifo_overrun_err_x;

   input                   clk;
   input                   reset_n;
   input                   fifo_enable;
   
   parameter MOD        = (DATA_WIDTH % FIFO_REPL_BITS) != 0 ? (DATA_WIDTH % FIFO_REPL_BITS)   : FIFO_REPL_BITS;
   parameter LOOP_COUNT = (DATA_WIDTH % FIFO_REPL_BITS) != 0 ? (DATA_WIDTH/FIFO_REPL_BITS) + 1 : DATA_WIDTH/FIFO_REPL_BITS;
   generate
     for(genvar fifo_inst = 0; fifo_inst < LOOP_COUNT; fifo_inst++) begin: fifo
       if(fifo_inst == LOOP_COUNT - 1) begin: last_fifo
          AP_REG_FIFO_US #(
             .DATA_WIDTH              (MOD),
             .FIFO_DEPTH              (FIFO_DEPTH),
             .AFULL_LIMIT             (AFULL_LIMIT),
             .EARLY_VALID_SET         (EARLY_VALID_SET),
             .FIFO_RST_EN             (FIFO_RST_EN),
             .DISABLE_EOS_ASSERTION   (DISABLE_EOS_ASSERTION),
             .DISABLE_X_WHEN_EMPTY    (DISABLE_X_WHEN_EMPTY),
             .DV_FORCE_RAND_FULL      (DV_FORCE_RAND_FULL),
             .DV_FORCE_RAND_EMPTY     (DV_FORCE_RAND_EMPTY)
         ) reg_fifo 
           (
             .fifo_din_x                    (fifo_din_x [FIFO_REPL_BITS * fifo_inst +: MOD]),  
             .fifo_dout_y                   (fifo_dout_y[FIFO_REPL_BITS * fifo_inst +: MOD]),  
             .fifo_push_x                   (fifo_push_x    ),  
             .fifo_pop_y                    (fifo_pop_y     ),  
             .fifo_full_x                   (fifo_full_x),  
             .fifo_afull_x                  (fifo_afull_x),  
             .fifo_empty_y                  (fifo_empty_y),  
             .fifo_overrun_err_x            (fifo_overrun_err_x),  
             .clk                           (clk            ),  
             .reset_n                       (reset_n        ),  
             .fifo_enable                   (fifo_enable    )   
           );
       end: last_fifo
       else begin: other_fifo
         AP_REG_FIFO_US #(
           .DATA_WIDTH                (FIFO_REPL_BITS),
           .FIFO_DEPTH                (FIFO_DEPTH),
           .AFULL_LIMIT               (AFULL_LIMIT),
           .EARLY_VALID_SET           (EARLY_VALID_SET),
           .FIFO_RST_EN               (FIFO_RST_EN),
           .DISABLE_EOS_ASSERTION     (DISABLE_EOS_ASSERTION),
           .DISABLE_X_WHEN_EMPTY      (DISABLE_X_WHEN_EMPTY),
           .DV_FORCE_RAND_FULL        (0), //last_fifo takes care of stalling
           .DV_FORCE_RAND_EMPTY       (0)
         ) reg_fifo 
           (
             .fifo_din_x                    (fifo_din_x [FIFO_REPL_BITS * fifo_inst +: FIFO_REPL_BITS]),  
             .fifo_dout_y                   (fifo_dout_y[FIFO_REPL_BITS * fifo_inst +: FIFO_REPL_BITS]),  
             .fifo_push_x                   (fifo_push_x    ),  
             .fifo_pop_y                    (fifo_pop_y     ),  
             .fifo_full_x                   (/*Not Used*/),  
             .fifo_afull_x                  (/*Not Used*/),  
             .fifo_empty_y                  (/*Not Used*/),  
             .fifo_overrun_err_x            (/*Not Used*/),  
             .clk                           (clk            ),  
             .reset_n                       (reset_n        ),  
             .fifo_enable                   (fifo_enable    )   
           );
       end: other_fifo
     end: fifo
   endgenerate
endmodule
