`timescale 1ns/10ps
//===============================================================
// Description: Basic Flop with Enable but without reset.
//
// Author: Gil Stoler
// Date:   4/Jul/2011
//
// All Rights Reserved to Annapurna Labs Ltd, 2011.
//===============================================================
`ifndef qdelay
 `define qdelay 0.1
`endif

module AP_LDFF_US
(/*AUTOARG*/
   // Outputs
   dout,
   // Inputs
   din, load, clk
   );
//
   parameter DATA_WIDTH = 1 ;
//
input  [DATA_WIDTH-1:0] din;
output [DATA_WIDTH-1:0] dout;
   input 		load;

input clk;

// Code start:
   reg [DATA_WIDTH-1:0] dout;
   `ifdef X2RANDOM

	integer seed;
	initial
	begin
		seed = $get_initial_random_seed();
		void'($urandom(seed));
	end
    `endif

// synopsys translate_off
`ifdef X2RANDOM
	initial begin
		for (integer i=0; i<DATA_WIDTH;i = i+1) begin
			dout[i] =  ($urandom()%2);
		end
	end
`endif
// synopsys translate_on

`ifdef ANPA_SIM_FAST
always @ (posedge clk) if (load) dout <= din ;
`else
always @ (posedge clk) if (load) dout <= #`qdelay din ;
`endif   // ANPA_SIM_FAST
`ifndef AL_EMULATION_COMPILE
// synopsys translate_off
`ifdef ANPA_SIM_FAST
	else if (~load) dout <= dout ;
	else  if(din === dout)           dout <= din ;  // Relax X propogation
`else
	else if (~load) dout <= #`qdelay dout ;
	else  if(din === dout)           dout <= #`qdelay din ;  // Relax X propogation
`endif   // ANPA_SIM_FAST
`ifdef X2RANDOM
	else begin
		for (integer i=0; i<DATA_WIDTH;i = i+1) begin
`ifdef ANPA_SIM_FAST
			dout[i] <= ($urandom()%2);
`else
			dout[i] <= #`qdelay  ($urandom()%2);
`endif   // ANPA_SIM_FAST
		end
	end
`else
`ifdef ANPA_SIM_FAST
	else             dout <= {DATA_WIDTH{1'bx}} ;  // Cover X' and Z' cases.
`else
	else             dout <= #`qdelay {DATA_WIDTH{1'bx}} ;  // Cover X' and Z' cases.
`endif   // ANPA_SIM_FAST
`endif
// synopsys translate_on
`endif
endmodule
