# AP_REG_FIFO_REPL bundle (Annapurna basic_cells)

ATH-1062 Phase 1 first-dogfood target. Smallest standalone FIFO in the AP family (110 LoC).

Source: `/tmp/annapurna-rtl/common/rtl/anpa_lib_us/basic_cells/rtl/AP_REG_FIFO_REPL.v` (Author: rudreshz, 2025; All Rights Reserved to Annapurna Labs Ltd 2011).

## What's in this bundle

- `inputs/AP_REG_FIFO_REPL.v` : verbatim gold-side RTL from Annapurna common_rtl.
- `signature.json` : hand-extracted port + parameter + clocking metadata. Cross-validated by the auto-generator at `kairos.sec.signature_gen` (PR #513 ships parametrized fixture-based test against this exact signature).

## What lands when

- **Phase 1 mint** (after ATH-1063 Phase 0a-wiring + Phase 0b + Phase 0c land on main): closed-loop run produces an iteration arc, EBMC subprocess captures appear in `_sec_work/`, cert markdown (`01-customer-block-certificate-v2.8.md`, `02-iteration-arc-discharge.md`, `03-honest-framing.md`) authored against the real iteration arc.
- **Phase 2 re-mint** (after ATH-1060 Layer D yosys synth hook lands): cert prose flips from `claimed -X%` to `verified -N gates` with synth log shipped in the bundle.
- **Phase 5 omnibus** aggregates this bundle plus AP_REG_FIFO_US + AP_ALU_US into `examples/customer/annapurna_demo_v1/` for the Todd-bound chief-architect-readable package.

## Cross-refs

- Parent bundle: ATH-1062 (Phase 1 dogfood).
- Foundation: ATH-1063 (kairos MCP + signature generator + synth hook).
- Ambition pin: ATH-1061.
