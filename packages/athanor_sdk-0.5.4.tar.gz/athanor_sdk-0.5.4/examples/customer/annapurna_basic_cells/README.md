# Annapurna basic_cells bundles (ATH-1062 Phase 1)

Per-block customer-block-certificate bundles for Annapurna's `common/rtl/anpa_lib_us/basic_cells/rtl/` library. ATH-1062 Phase 1 dogfood targets.

## Bundles

| Bundle | LoC | Class | Author | Why |
|--------|-----|-------|--------|-----|
| [`AP_REG_FIFO_REPL/`](AP_REG_FIFO_REPL/) | 110 | FIFO | rudreshz, 2025 | First-dogfood: smallest standalone FIFO. Validates pipeline holds against real RTL. |
| [`AP_REG_FIFO_US/`](AP_REG_FIFO_US/) | 200+invariants | FIFO | Gil Stoler, 2011 | Substantive demo: 8 hand-written `formal_sst_verif_only` invariants ingested as bridge-invariant primers. |
| [`AP_ALU_US/`](AP_ALU_US/) | 148 | combinational ALU | Ofer Naaman, 2014 | Domain generality: combinational, not FIFO. Different proof shape (BMC bound 0). |

## What's in each bundle today

Each per-block directory ships:

- `inputs/<gold>.{v,sv}` : verbatim RTL copied from `/tmp/annapurna-rtl/`.
- `signature.json` : hand-extracted port + parameter + clocking metadata, cross-validated by the `kairos.sec.signature_gen` test suite (PR #513 parametrized fixture-based test against these exact signatures).
- `README.md` : per-block context, source attribution, ATH-1063 phase mapping.

## What lands per phase (real artifacts, not pending stubs)

After ATH-1063 Phase 0a-wiring + Phase 0b + Phase 0c land on main:

- **Phase 1 mint**: closed-loop run produces an iteration arc, EBMC subprocess captures land verbatim under `_sec_work/` per Aidan path-a directive, `demo_driver.py` invokes the orchestration library, `build-tarball.sh` runs the v2.7 11-gate shape + Gate 11 Layer 1 audit (engine-emit cross-check + build-script consistency + gate-count assertions), cert markdown (`01-customer-block-certificate-v2.8.md`, `02-iteration-arc-discharge.md`, `03-honest-framing.md`) authored against the real arc.
- **Phase 2 re-mint**: cert prose flips from `claimed -X%` to `verified -N gates` with yosys synth log shipped in the bundle.

## Phase 1 mint sequence (post-Phase-0a + Phase-0b + Phase-0c land)

1. `AP_REG_FIFO_REPL` first (smallest, validates pipeline holds).
2. `AP_REG_FIFO_US` second (substantive demo with Gil's invariants as primers).
3. `AP_ALU_US` third (domain generality).

After all three close, certs flip from `claimed -X%` to `verified -N gates` once Phase 2 (Layer D yosys synth hook) lands and re-mints with synthesis pass.

Final omnibus aggregator at `examples/customer/annapurna_demo_v1/` (Phase 5) bundles all three per-block certs + cross-block summary + verified totals into the chief-architect-readable Todd-bound package.

## Cross-refs

- Parent dogfood: ATH-1062.
- Foundation: ATH-1063 (Phase 0a `kairos.mcp`, Phase 0b signature generator, Phase 0c yosys hook, Phase 0e customer guide).
- Ambition pin: ATH-1061 (chief-architect-grade demo, real Annapurna code, verified-not-claimed gate count).
- Pressure-points inventory: ATH-1060.
- Classification doc: `docs/internal/v28-annapurna-basic-cells-classification.md`.
