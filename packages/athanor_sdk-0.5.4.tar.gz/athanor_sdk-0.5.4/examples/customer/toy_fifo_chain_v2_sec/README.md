# toy_fifo_chain v2: SEC equivalence checking with EBMC (post-Todd-pivot)

This bundle is the v2 successor to `examples/customer/toy_fifo_chain/`,
re-engineered around **Sequential Equivalence Checking with EBMC**
instead of the v1 EQY-based combinational equivalence.

## Why v2

The v1 demo refuted 8 forwarding obligations on the customer dashboard.
Investigation traced the refutations to EQY's `-set-init-undef` flag in
its sat strategy (hard-coded; not user-configurable without forking
EQY), which makes the SAT solver explore unconstrained post-reset
register states regardless of upstream `prep` configuration.

Todd's 2026-05-04 lock-in: switch the SEC engine from EQY to EBMC, fix
uninitialized-flops handling, defer ACL2. Direct quote:

> "i would do proper SEC. ACL2 can be skipped for now. EBMC fine for
> now. flow can be advanced later for hard SEC problems. honestly your
> likely just missing basic uninitialized flops handling is about it,
> the the EBMC with and without induction would work"
>
> [direct quote, with one word dropped for md-lint compliance]

## What's in this bundle

| File | Role |
|------|------|
| `gold.sv` | The reference fifo_widget. Body byte-identical to v1 with the parameterized type specialized to `logic [27:0]` so yosys + EBMC parse cleanly. |
| `gate.v` | Clash-emitted Verilog from the v1 `clash_gates/FifoWidget.hs`, with the top module renamed from `fifo_widget` to `fifo_widget_gate` to avoid the multiple-definition error EBMC would otherwise emit. |
| `signature.json` | Port list + module names + reset polarity, the schema `kairos.sec.run_sec_bundle` reads. |
| `spec/` | Reserved for asabi's Pythia/Hardware/SEC contract layer (FifoContract.lean lives here once ATH-984 lands). |
| `docs/` | Reserved for the customer-facing v2 certificate output. |

## How to verify

End-to-end through the SDK:

```python
from kairos.sec import run_sec_bundle
result = run_sec_bundle("examples/customer/toy_fifo_chain_v2_sec")
print("BMC:", result.bmc_result.proved)
print("Induction:", result.induction_result.proved)
print("Run id:", result.run_id)
```

Or directly with `kairos.sec.verify_sec` for one-mode invocation.

## What this bundle proves (when both modes pass)

* Each output port (pop_data, full, empty) of the gold matches the
  corresponding output of the gate at every cycle, modulo the
  reset-asserted window.
* Both BMC depth-bounded and k-induction proofs close on the same
  miter, so the equivalence holds for arbitrary input traces, not
  just up to the bound.

## Open scope (not in this bundle)

* `add_header` packet transform : Yosys parser limitation on the
  function-returning-struct + parameterized-type SV signature.
  Stays gated until the SDK's SystemVerilog preprocessor fix lands.
* `arb_widget` round-robin: temporal property; the safety form is
  k-induction-tractable as a refinement against an abstract
  RoundRobin spec (asabi's lane in ATH-984 covers the abstract spec
  side, this bundle covers the per-block SEC of the round-robin
  arbiter once that contract is in place).
* Composition lemmas chaining per-block contracts into a top-level
  `toy_fifo_chain` end-to-end claim. Lives in
  `Pythia/Hardware/SEC/ChainComposition.lean` per ATH-984.

## Cross-refs

* ATH-983 (parent SEC pivot ticket).
* ATH-984 (asabi child: Pythia/Hardware/SEC contract layer).
* ATH-985 (lint+template gate, separate lane, unowned).
* `kairos.sec` namespace (engine wiring, `src/kairos/sec/`).
* v1 bundle at `examples/customer/toy_fifo_chain/` (preserved for
  comparison; do NOT delete: it documents the EQY-era artifact set).
