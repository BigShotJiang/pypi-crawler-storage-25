"""Real `@nki.jit` causal-attention baseline (offline softmax).

Mirror of upstream `attn_fwd_v3` shape with causal mask applied via
`nisa.affine_select` on the QK matrix before softmax. Used as the
equivalence target for `improved_nki.py` (causal online-softmax).

Same offline two-pass softmax pattern as upstream attn_fwd_v3, just
with the mask layered in at the qk-tile level.
"""
from __future__ import annotations

import neuronxcc.nki as nki
import neuronxcc.nki.isa as nisa
import neuronxcc.nki.language as nl


@nki.jit
def attn_fwd_v3_causal_baseline(q, k, v):
    """Causal offline-softmax attention. Inputs (d_head, seqlen),
    output (seqlen, d_head). Causal mask `j ≤ i` applied via
    `affine_select`.
    """
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q

    PMAX = nl.tile_size.pmax

    assert q.shape == k.shape == v.shape
    assert d_head == PMAX
    assert seqlen_q >= 256
    assert seqlen_q % PMAX == 0

    num_tile_q = seqlen_q // PMAX
    num_tile_kv = seqlen_kv // PMAX

    kernel_out = nl.ndarray((seqlen_q, d_head), dtype=q.dtype, buffer=nl.shared_hbm)

    q_sbuf = nl.load(q)
    k_sbuf = nl.load(k)
    v_sbuf = nl.load(v)

    # Pre-transpose v into v_t for matmul
    v_t = nl.ndarray(
        (num_tile_kv, PMAX, d_head),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_kv in range(num_tile_kv):
        v_psum_t = nisa.nc_transpose(data=v_sbuf[:, nl.ds(i_tile_kv * PMAX, PMAX)])
        v_sbuf_t = nisa.tensor_copy(v_psum_t)
        nl.store(v_t[i_tile_kv], v_sbuf_t[:, :])

    # Per query tile, do two-pass softmax with causal mask
    for i_tile_q in range(num_tile_q):
        # Pass 1: compute QK_row, apply mask, find row_max, sum exp
        qk_row = nl.ndarray((PMAX, seqlen_kv), dtype=nl.float32, buffer=nl.sbuf)

        for i_tile_kv in range(num_tile_kv):
            qk_psum = nisa.nc_matmul(
                stationary=q_sbuf[0:PMAX, nl.ds(i_tile_q * PMAX, PMAX)],
                moving=k_sbuf[0:PMAX, nl.ds(i_tile_kv * PMAX, PMAX)],
            )
            qk_sbuf = nisa.tensor_copy(qk_psum)

            if i_tile_kv > i_tile_q:
                # Upper-triangular tile: fully masked
                masked = nisa.tensor_scalar(
                    data=qk_sbuf, op0=nl.multiply, operand0=0.0,
                    op1=nl.add, operand1=-1.0e30,
                )
                qk_row[:, nl.ds(i_tile_kv * PMAX, PMAX)] = masked
            elif i_tile_kv == i_tile_q:
                # Diagonal tile: per-element mask r >= c (r,c are tile-local indices)
                i_p, i_f = nl.mgrid[0:PMAX, 0:PMAX]
                masked = nisa.affine_select(
                    pred=(i_p - i_f >= 0),
                    on_true_tile=qk_sbuf,
                    on_false_value=-1.0e30,
                )
                qk_row[:, nl.ds(i_tile_kv * PMAX, PMAX)] = masked
            else:
                # Lower-triangular: no mask needed
                qk_row[:, nl.ds(i_tile_kv * PMAX, PMAX)] = qk_sbuf

        # Row max (across full kv axis)
        row_max = nisa.tensor_reduce(op=nl.maximum, data=qk_row, axis=(1,))

        # Subtract row_max + exp + sum, fused (same fusion pattern as upstream v6+)
        sum_row_kv = nl.ndarray((PMAX, num_tile_kv), dtype=nl.float32, buffer=nl.sbuf)
        exp_row = nl.ndarray((PMAX, seqlen_kv), dtype=nl.float32, buffer=nl.sbuf)
        neg_row_max = nisa.tensor_scalar(
            data=row_max, op0=nl.multiply, operand0=-1.0,
        )
        for i_tile_kv in range(num_tile_kv):
            tile_sum = nl.ndarray((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
            exp_tile = nisa.activation(
                op=nl.exp,
                data=qk_row[:, nl.ds(i_tile_kv * PMAX, PMAX)],
                bias=neg_row_max,
                reduce_op=nl.add,
                reduce_res=tile_sum,
                reduce_cmd=nisa.reduce_cmd.reset_reduce,
            )
            exp_row[:, nl.ds(i_tile_kv * PMAX, PMAX)] = exp_tile
            sum_row_kv[:, nl.ds(i_tile_kv, 1)] = tile_sum

        # Total row sum
        sum_row = nisa.tensor_reduce(op=nl.add, data=sum_row_kv, axis=(1,))
        inverse_sum = nisa.reciprocal(data=sum_row)

        # Compute attn_out = exp_row @ v_t, with division at the end
        attn_out_psum = nl.zeros((PMAX, PMAX), dtype=nl.float32, buffer=nl.psum)
        for i_tile_kv in range(num_tile_kv):
            # Transpose exp tile for matmul
            exp_t_psum = nisa.nc_transpose(
                data=exp_row[:, nl.ds(i_tile_kv * PMAX, PMAX)],
            )
            exp_t_sbuf = nisa.tensor_copy(exp_t_psum)

            v_t_sbuf = nl.load(v_t[i_tile_kv, :, :])

            attn_out_psum += nisa.nc_matmul(
                stationary=exp_t_sbuf, moving=v_t_sbuf,
            )

        attn_out_sbuf = nisa.tensor_copy(attn_out_psum)
        out_tile = nisa.tensor_scalar(
            data=attn_out_sbuf, op0=nl.multiply, operand0=inverse_sum,
        )
        nl.store(dst=kernel_out[nl.ds(i_tile_q * PMAX, PMAX), :], value=out_tile)

    return kernel_out
