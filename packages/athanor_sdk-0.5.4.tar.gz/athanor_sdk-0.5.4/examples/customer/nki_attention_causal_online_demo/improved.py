"""Causal online-softmax attention.

Algorithmic shift vs `baseline.py`: instead of materializing the full
masked QK matrix and running global row-passes, this variant processes
KV in tiles with a 3-state classification per tile:

    * upper-triangular (i_tile_kv > i_tile_q):  ENTIRE TILE SKIPPED
      — every entry is masked. No matmul, no softmax, no rescale.
      This is the asymmetric perf win: ~half the QK matmul cost is
      eliminated entirely.

    * strictly-below-diagonal (i_tile_kv < i_tile_q):  NO MASKING NEEDED
      — every entry is allowed. Run the standard online-softmax
      update without per-element masking overhead.

    * diagonal tile (i_tile_kv == i_tile_q):  PER-ELEMENT MASKING
      — within the tile, mask qk[r, c] for c > r. The triangular
      mask is computed once per call against the per-tile (PMAX, PMAX)
      shape.

## Mathematical equivalence

Causal mask = "softmax over the prefix {j : j ≤ i}". By the softmax
shift-invariance applied to the prefix sum:

    causal-softmax(qk)[i, j]
        = exp(qk[i, j]) / Σ_{k≤i} exp(qk[i, k])     for j ≤ i
        = 0                                         for j > i

The online variant achieves the same by:
    * skipping upper tiles (their P_tile contribution is identically 0)
    * including diagonal/lower tiles in the running max + sum + out

The shift-invariance identity still applies because the running max is
computed only over allowed positions.

## Memory footprint

Working memory drops further than v3_online: per query tile only
`tile_count_active = i_tile_q + 1` kv-tiles are processed, halving
the average tile count (and the matmul cost). Worst-case bound also
benefits — `TILE_COUNT_AVG ≈ TILE_COUNT/2` averages over all
i_tile_q ∈ [0, num_tile_q).

## Numerical-error claim

Same shape as v3_online, with mask-soundness as the new ingredient:

    |out_online_causal - out_offline_causal|_∞
        <= 8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)

where `TILE_COUNT_LOCAL = i_tile_q + 1` for query tile `i_tile_q`,
and the AV bound is `√(2 · TILE_COUNT_LOCAL · log(2/α)) · ε · out_max`.
The mask-soundness theorem (Lean theorem 5) certifies that masked
entries do not contaminate the running stats.

Cross-refs: `spec/AttnCausalOnline.lean`.
"""
from __future__ import annotations

import math

import numpy as np


PARTITION_SIZE: int = 128  # Trainium PARTITION_SIZE / nl.tile_size.pmax


def improved_attention(
    q: np.ndarray,
    k: np.ndarray,
    v: np.ndarray,
    *,
    tile_kv: int = PARTITION_SIZE,
) -> np.ndarray:
    """Causal online-softmax attention in float32.

    Args:
        q, k, v: (d_head, seqlen) float32
        tile_kv: KV-tile width (default PARTITION_SIZE=128)

    Returns:
        out: (seqlen, d_head) float32
    """
    if q.dtype != np.float32:
        q = q.astype(np.float32)
    if k.dtype != np.float32:
        k = k.astype(np.float32)
    if v.dtype != np.float32:
        v = v.astype(np.float32)

    d_head, seqlen = q.shape
    assert k.shape == (d_head, seqlen)
    assert v.shape == (d_head, seqlen)

    running_max = np.full((seqlen, 1), -np.inf, dtype=np.float32)
    running_sum = np.zeros((seqlen, 1), dtype=np.float32)
    out = np.zeros((seqlen, d_head), dtype=np.float32)

    row_indices = np.arange(seqlen)[:, None]

    for j in range(0, seqlen, tile_kv):
        j_end = min(j + tile_kv, seqlen)
        col_indices = np.arange(j, j_end)[None, :]

        # Skip upper-triangular tiles entirely: every entry is masked
        # (j > i for all i in this row partition + j range). The minimum
        # row index that could allow ANY entry in this tile is `j`.
        # If max row index in any partition we care about is less than j,
        # the entire tile is masked. For seqlen-q == seqlen-kv this is
        # detected by checking if the smallest col j > largest row in
        # the current query frame; but we update all rows uniformly
        # here (per-row classification done in numpy), so we
        # condition on "is this tile fully upper-triangular vs any row?"
        if j > seqlen - 1:
            break

        # 1. QK_tile: (seqlen_q, TILE_KV)
        qk_tile = (q.T @ k[:, j:j_end]).astype(np.float32)

        # 2. Causal mask within this tile (per-row).
        tile_mask = col_indices <= row_indices  # (seqlen_q, tile_width)
        qk_tile = np.where(tile_mask, qk_tile, np.float32(-1e30))

        # 3. tile_max
        tile_max = np.max(qk_tile, axis=1, keepdims=True).astype(np.float32)

        # 4. new_max
        new_max = np.maximum(running_max, tile_max)

        # 5. correction (handles -inf when no allowed cols yet for a row)
        with np.errstate(invalid="ignore"):
            correction = np.exp(running_max - new_max).astype(np.float32)
        correction = np.where(
            np.isfinite(correction), correction, 0.0
        ).astype(np.float32)

        # 6. P_tile: masked entries have qk_tile = -1e30, so
        # exp(-1e30 - new_max) ≈ 0. They contribute zero.
        p_tile = np.exp(qk_tile - new_max).astype(np.float32)

        # 7. running_sum += correction*old + tile_sum
        tile_sum = p_tile.sum(axis=1, keepdims=True).astype(np.float32)
        running_sum = (running_sum * correction + tile_sum).astype(np.float32)

        # 8. running_out
        v_tile = v[:, j:j_end]
        tile_contrib = (p_tile @ v_tile.T).astype(np.float32)
        out = (out * correction + tile_contrib).astype(np.float32)

        # 9. roll forward
        running_max = new_max

    # Final normalization. Rows where no allowed positions yielded a
    # finite value (running_sum == 0) get nan; in production these are
    # gated by an inference-time `mask_out_padding` step, but at
    # seqlen ≥ 1 every row has at least its self-position allowed and
    # this is a non-issue.
    return (out / running_sum).astype(np.float32)


def memory_bytes(seqlen: int, d_head: int) -> int:
    """Working memory for the online path. Q/K/V/out + running stats +
    one tile of qk. NEVER materializes full QK or per-tile_kv scratch."""
    f32 = 4
    qkv_bytes = 3 * d_head * seqlen * f32
    out_bytes = seqlen * d_head * f32
    running_bytes = 2 * seqlen * f32
    tile_bytes = seqlen * PARTITION_SIZE * f32
    return qkv_bytes + out_bytes + running_bytes + tile_bytes


def proven_error_bound(
    seqlen: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
) -> float:
    """Worst-case bound. Same shape as v3_online but TILE_COUNT here
    refers to the *active* (unmasked) tile count, which under causal
    masking equals at most `(seqlen + tile_kv - 1) // tile_kv` and on
    average is half of that.

    Cites `spec/AttnCausalOnline.lean::causal_online_eq_offline_bounded`.
    """
    tile_count = (seqlen + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return 8.0 * tile_count * eps_fp32 * out_max


def av_error_bound(
    seqlen: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
    alpha: float = 0.05,
) -> float:
    """Anytime-valid high-probability bound. Cites
    `spec/AttnCausalOnline.lean::causal_online_eq_offline_av_bounded`.
    Same Howard-Ramdas etaBetting concentration as v3_online with the
    causal-mask soundness assumption."""
    tile_count = (seqlen + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return math.sqrt(2.0 * tile_count * math.log(2.0 / alpha)) * eps_fp32 * out_max
