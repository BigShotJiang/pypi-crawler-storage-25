# nki_attention_causal_online_demo

Engineer-facing entry. For customer-facing pitch see `CUSTOMER_README.md`.

## What

Causal online-softmax attention kernel. Sibling to `nki_attention_v3_online_demo/` with causal mask added at the per-tile layer.

- Upper-triangular tiles skipped entirely (no nc_matmul).
- Diagonal tile masked via `nisa.affine_select`.
- Lower-triangular tiles run unmasked online-softmax.

Same trust stack as v3_online: numpy + @nki.jit + Lean spec + AV bound + simulator validation + upstream-PR shape.

## Files

```
nki_attention_causal_online_demo/
├── README.md                       ← this file
├── CUSTOMER_README.md              ← customer-facing pitch
├── baseline.py                     ← causal offline-softmax numpy
├── improved.py                     ← causal online-softmax numpy
├── baseline_nki.py                 ← real @nki.jit causal offline
├── improved_nki.py                 ← real @nki.jit causal online
├── reference.py                    ← float64 ground truth + mask
├── verify.py                       ← 7 numpy test classes
├── verify_nki.py                   ← nki.simulate_kernel trials
├── spec/
│   └── AttnCausalOnline.lean       ← 5 theorems
├── reports/
│   ├── summary.json
│   ├── test_report.json
│   ├── nki_summary.json
│   └── nki_test_report.json
└── upstream_pr_proposal/           ← drop-in PR shape for aws-neuron/nki-samples
```

## Run

```bash
cd examples/customer/nki_attention_causal_online_demo
python3 verify.py            # numpy, ~1s
python3 verify_nki.py        # NKI simulator, ~1s/trial at seqlen=512
```

## Status

- numpy verify.py: 7/7 PASS (basic_shape / causal_first_position / tiny_seqlen / one_tile_boundary / differential_seqlen_512 / differential_seqlen_2048 / memory_savings)
- NKI simulator verify_nki.py: 5/5 PASS at seqlen=512, online-vs-offline error ~4.8e-7 on Trainium ISA semantics, both bounds hold
- Lean theorems: 5 statements compile standalone, proof bodies sorry-flagged. Gates on Pythia PR #96 + the attention-module sequel adding `causal_mask_eq_partial_softmax` (research-owned per ATH-1093 fleet split).

## Lean theorem set

1. `softmax_shift_invariance`
2. `causal_mask_eq_partial_softmax` — soundness of upper-tile-skip + diagonal-mask
3. `causal_online_eq_offline_exact`
4. `causal_online_eq_offline_bounded` — worst-case `8 · TILE_COUNT_LOCAL · ε · out_max`
5. `causal_online_eq_offline_av_bounded` — anytime-valid `√(2N · log(2/α)) · ε · out_max`

## Per-tile classification (the architectural pedagogy of this kernel)

```
i_tile_kv > i_tile_q     →  upper-triangular: SKIP entirely (no work)
i_tile_kv == i_tile_q    →  diagonal: per-element mask via affine_select
i_tile_kv < i_tile_q     →  lower-triangular: unmasked online-softmax
```

The skip-upper-tiles optimization is what drives the ~50% matmul-cost reduction for the average query tile. None of upstream `attn_fwd_v3..v8a` exhibit this pattern.

## NOT auto-merging

Customer-bound artifact. Aidan greenlight required before any ship.

## Cross-refs

- ATH-1093 (Linear) — Neuron NKI flagship epic
- Sibling: `examples/customer/nki_attention_v3_online_demo/`
- Pythia PR #96 + attention-module sequel
