"""Differential verification — causal-online vs causal-offline vs FP64
reference. Same 6 test classes as v3_online, plus one mask-soundness
consistency check.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from baseline import baseline_attention, memory_bytes as baseline_memory_bytes  # noqa: E402
from improved import (  # noqa: E402
    av_error_bound,
    improved_attention,
    memory_bytes as improved_memory_bytes,
    proven_error_bound,
)
from reference import reference_attention  # noqa: E402


REPORTS_DIR = HERE / "reports"
N_RANDOM_TRIALS = 32
RNG = np.random.default_rng(seed=20260507)
D_HEAD = 128


def _max_err(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.max(np.abs(a - b)))


def _trial(d_head: int, seqlen: int) -> dict:
    q = RNG.standard_normal((d_head, seqlen)).astype(np.float32)
    k = RNG.standard_normal((d_head, seqlen)).astype(np.float32)
    v = RNG.standard_normal((d_head, seqlen)).astype(np.float32)

    ref = reference_attention(q, k, v)
    base = baseline_attention(q, k, v)
    impr = improved_attention(q, k, v)

    err_impr_vs_ref = _max_err(impr, ref)
    err_impr_vs_base = _max_err(impr, base)
    err_base_vs_ref = _max_err(base, ref)
    out_max = float(np.max(np.abs(base)))
    bound_wc = proven_error_bound(seqlen, out_max=out_max)
    bound_av = av_error_bound(seqlen, out_max=out_max, alpha=0.05)

    return {
        "d_head": d_head,
        "seqlen": seqlen,
        "err_impr_vs_ref": err_impr_vs_ref,
        "err_impr_vs_base": err_impr_vs_base,
        "err_base_vs_ref": err_base_vs_ref,
        "proven_bound_worst_case": bound_wc,
        "proven_bound_av_alpha_0_05": bound_av,
        "within_bound_vs_base": bool(err_impr_vs_base <= bound_wc),
        "within_av_bound_vs_base": bool(err_impr_vs_base <= bound_av),
    }


def test_basic_shape() -> dict:
    seqlen = D_HEAD
    q = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    k = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    v = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    out = improved_attention(q, k, v)
    expected_shape = (seqlen, D_HEAD)
    return {
        "name": "basic_shape",
        "passed": out.shape == expected_shape,
        "details": f"out.shape={out.shape}, expected={expected_shape}",
    }


def test_causal_first_position() -> dict:
    """Position 0 attends only to position 0 — no contribution from
    later positions. Output[0] == V.T[0] regardless of K[1:] or V[1:]."""
    seqlen = 256
    q = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    k = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    v = RNG.standard_normal((D_HEAD, seqlen)).astype(np.float32)

    impr = improved_attention(q, k, v)
    expected_row0 = v[:, 0]
    err = float(np.max(np.abs(impr[0] - expected_row0)))

    return {
        "name": "causal_first_position",
        "passed": err <= 1e-5,
        "details": f"|out[0] - v[:, 0]|_inf = {err:.6e}",
    }


def test_tiny_seqlen() -> dict:
    row = _trial(D_HEAD, 128)
    return {
        "name": "tiny_seqlen",
        "passed": row["within_bound_vs_base"],
        "row": row,
    }


def test_one_tile_boundary() -> dict:
    row = _trial(D_HEAD, 129)
    return {
        "name": "one_tile_boundary",
        "passed": row["within_bound_vs_base"],
        "row": row,
    }


def _random_differential_at_seqlen(seqlen: int, n_trials: int = N_RANDOM_TRIALS) -> dict:
    rows = []
    all_ok = True
    for _ in range(n_trials):
        row = _trial(D_HEAD, seqlen)
        rows.append(row)
        if not row["within_bound_vs_base"]:
            all_ok = False
    n_within_av = sum(1 for r in rows if r["within_av_bound_vs_base"])
    return {
        "name": f"differential_seqlen_{seqlen}",
        "passed": all_ok,
        "n_trials": n_trials,
        "n_within_bound": sum(
            1 for r in rows if r["within_bound_vs_base"]
        ),
        "n_within_av_bound": n_within_av,
        "av_bound_holds_pct": 100.0 * n_within_av / n_trials,
        "max_empirical_err_vs_ref": max(r["err_impr_vs_ref"] for r in rows),
        "max_empirical_err_vs_base": max(r["err_impr_vs_base"] for r in rows),
        "rows": rows,
    }


def test_medium_seqlen() -> dict:
    return _random_differential_at_seqlen(512)


def test_large_seqlen() -> dict:
    return _random_differential_at_seqlen(2048)


def test_memory_savings() -> dict:
    seqlen = 4096
    base_bytes = baseline_memory_bytes(seqlen, D_HEAD)
    impr_bytes = improved_memory_bytes(seqlen, D_HEAD)
    ratio = base_bytes / impr_bytes if impr_bytes else float("inf")
    return {
        "name": "memory_savings",
        "passed": impr_bytes < base_bytes,
        "details": (
            f"seqlen=4096 d_head=128: baseline={base_bytes / 1024**2:.2f} MiB, "
            f"improved={impr_bytes / 1024**2:.2f} MiB, ratio={ratio:.1f}x"
        ),
        "baseline_bytes": base_bytes,
        "improved_bytes": impr_bytes,
        "ratio": ratio,
    }


TESTS = (
    test_basic_shape,
    test_causal_first_position,
    test_tiny_seqlen,
    test_one_tile_boundary,
    test_medium_seqlen,
    test_large_seqlen,
    test_memory_savings,
)


def main() -> int:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for t in TESTS:
        r = t()
        results.append(r)
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  [{status}] {r['name']}")

    n_pass = sum(1 for r in results if r["passed"])
    n_fail = len(results) - n_pass
    summary = {
        "passed": n_fail == 0,
        "n_tests": len(results),
        "n_passed": n_pass,
        "n_failed": n_fail,
        "kernel": "nki_attention_causal_online_demo",
        "lean_spec": "spec/AttnCausalOnline.lean",
    }

    (REPORTS_DIR / "summary.json").write_text(json.dumps(summary, indent=2))
    (REPORTS_DIR / "test_report.json").write_text(
        json.dumps({"summary": summary, "tests": results}, indent=2, default=str)
    )
    print(json.dumps(summary, indent=2))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
