"""Causal-attention baseline (offline softmax, mirror of upstream `attn_fwd_v3`
with causal mask applied).

Algorithmic shape:
    1. QK = Q.T @ K               # (seqlen_q, seqlen_kv)
    2. Apply causal mask: qk[i, j] = -inf for j > i
    3. row_max = max(QK, axis=1)
    4. exp = np.exp(QK - row_max[:, None])
    5. sum = exp.sum(axis=1, keepdims=True)
    6. scores = exp / sum
    7. out = scores @ V.T

The mask is the only change from `nki_attention_v3_online_demo/baseline.py`.
Materializes the full QK matrix and processes row-pass globally — same
working-memory profile as upstream non-causal `attn_fwd_v3`.

Used as the equivalence target for `improved.py` (causal online softmax).
"""
from __future__ import annotations

import numpy as np


def causal_mask(seqlen_q: int, seqlen_kv: int) -> np.ndarray:
    """Boolean mask of shape (seqlen_q, seqlen_kv); True at allowed
    positions (j ≤ i), False at masked (j > i)."""
    rows = np.arange(seqlen_q)[:, None]
    cols = np.arange(seqlen_kv)[None, :]
    return cols <= rows


def baseline_attention(
    q: np.ndarray, k: np.ndarray, v: np.ndarray
) -> np.ndarray:
    """Causal offline-softmax attention, float32.

    Args:
        q, k, v: (d_head, seqlen) float32

    Returns:
        out: (seqlen_q, d_head) float32
    """
    if q.dtype != np.float32:
        q = q.astype(np.float32)
    if k.dtype != np.float32:
        k = k.astype(np.float32)
    if v.dtype != np.float32:
        v = v.astype(np.float32)

    d_head, seqlen = q.shape

    qk = (q.T @ k).astype(np.float32)
    mask = causal_mask(seqlen, seqlen)
    qk = np.where(mask, qk, np.float32(-1e30))

    row_max = np.max(qk, axis=1, keepdims=True)
    exp = np.exp(qk - row_max).astype(np.float32)
    row_sum = exp.sum(axis=1, keepdims=True).astype(np.float32)
    scores = (exp / row_sum).astype(np.float32)

    return (scores @ v.T).astype(np.float32)


def memory_bytes(seqlen: int, d_head: int) -> int:
    """Working memory for the offline path: Q + K + V + QK matrix +
    norm/exp/scores intermediates."""
    f32 = 4
    qkv_bytes = 3 * d_head * seqlen * f32
    qk_bytes = seqlen * seqlen * f32
    norm_bytes = seqlen * seqlen * f32
    exp_bytes = seqlen * seqlen * f32
    scores_bytes = seqlen * seqlen * f32
    out_bytes = seqlen * d_head * f32
    return qkv_bytes + qk_bytes + norm_bytes + exp_bytes + scores_bytes + out_bytes
