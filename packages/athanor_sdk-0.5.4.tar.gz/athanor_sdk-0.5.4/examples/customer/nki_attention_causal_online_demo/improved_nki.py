"""Real `@nki.jit` causal online-softmax attention.

Three-tier per-tile classification:
    * upper-triangular (i_tile_kv > i_tile_q): tile entirely skipped.
      No nc_matmul, no softmax, no rescale. ~half the kv-tile cost
      eliminated for the average query tile.
    * strictly-below-diagonal (i_tile_kv < i_tile_q): no masking
      needed; standard online-softmax update.
    * diagonal (i_tile_kv == i_tile_q): per-element causal mask via
      `nisa.affine_select` with predicate `i_p >= i_f` (tile-local
      row >= col).

The mask preserves softmax correctness because masked entries' exp
values become 0 in the running stats — they contribute identically
zero to running_sum and running_out.

Memory + runtime savings over `baseline_nki.py` are larger than the
non-causal v3_online savings: per query tile, only `i_tile_q + 1`
kv-tiles are processed (vs all `num_tile_kv`), averaging ~half the
matmul cost across the full kernel.

See `spec/AttnCausalOnline.lean` for the Lean spec (5 theorems).
"""
from __future__ import annotations

import neuronxcc.nki as nki
import neuronxcc.nki.isa as nisa
import neuronxcc.nki.language as nl


@nki.jit
def attn_fwd_v3_causal_online(q, k, v):
    """Causal online-softmax attention. Inputs (d_head, seqlen),
    output (seqlen, d_head).
    """
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q

    PMAX = nl.tile_size.pmax

    assert q.shape == k.shape == v.shape
    assert d_head == PMAX
    assert seqlen_q >= 256
    assert seqlen_q % PMAX == 0

    NEG_INF = -1.0e30
    num_tile_q = seqlen_q // PMAX
    num_tile_kv = seqlen_kv // PMAX

    kernel_out = nl.ndarray((seqlen_q, d_head), dtype=q.dtype, buffer=nl.shared_hbm)

    q_sbuf = nl.load(q)
    k_sbuf = nl.load(k)
    v_sbuf = nl.load(v)

    # Pre-transpose v for the p_t @ v_t matmul layout
    v_t = nl.ndarray(
        (num_tile_kv, PMAX, d_head),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_kv in range(num_tile_kv):
        v_psum_t = nisa.nc_transpose(data=v_sbuf[:, nl.ds(i_tile_kv * PMAX, PMAX)])
        v_sbuf_t = nisa.tensor_copy(v_psum_t)
        nl.store(v_t[i_tile_kv], v_sbuf_t[:, :])

    # Outer loop is plain Python so the inner range can depend on i_tile_q
    for i_tile_q in range(num_tile_q):
        running_max = nl.full((PMAX, 1), NEG_INF, dtype=nl.float32, buffer=nl.sbuf)
        running_sum = nl.zeros((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
        running_out = nl.zeros((PMAX, d_head), dtype=nl.float32, buffer=nl.sbuf)

        # Only iterate kv tiles that aren't fully upper-triangular
        for i_tile_kv in range(i_tile_q + 1):
            qk_psum = nisa.nc_matmul(
                stationary=q_sbuf[0:PMAX, nl.ds(i_tile_q * PMAX, PMAX)],
                moving=k_sbuf[0:PMAX, nl.ds(i_tile_kv * PMAX, PMAX)],
            )
            qk_sbuf = nisa.tensor_copy(qk_psum)

            # Diagonal-tile causal mask (per-element). Lower tiles unmodified.
            if i_tile_kv == i_tile_q:
                i_p, i_f = nl.mgrid[0:PMAX, 0:PMAX]
                masked = nisa.affine_select(
                    pred=(i_p - i_f >= 0),
                    on_true_tile=qk_sbuf,
                    on_false_value=NEG_INF,
                )
                qk_sbuf[:, :] = masked[:, :]

            tile_max = nisa.tensor_reduce(
                op=nl.maximum, data=qk_sbuf, axis=(1,),
            )
            new_max = nl.maximum(running_max, tile_max)
            neg_new_max = nisa.tensor_scalar(
                data=new_max, op0=nl.multiply, operand0=-1.0,
            )
            correction = nisa.activation(
                op=nl.exp, data=running_max, bias=neg_new_max,
            )

            tile_sum = nl.ndarray((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
            p_sbuf = nisa.activation(
                op=nl.exp, data=qk_sbuf, bias=neg_new_max,
                reduce_op=nl.add, reduce_res=tile_sum,
                reduce_cmd=nisa.reduce_cmd.reset_reduce,
            )

            new_sum = nisa.scalar_tensor_tensor(
                data=running_sum,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_sum,
            )

            p_t_psum = nisa.nc_transpose(data=p_sbuf)
            p_t_sbuf = nisa.tensor_copy(p_t_psum)
            v_t_sbuf = nl.load(v_t[i_tile_kv, :, :])

            tile_out_psum = nisa.nc_matmul(
                stationary=p_t_sbuf, moving=v_t_sbuf,
            )
            tile_out = nisa.tensor_copy(tile_out_psum)

            new_out = nisa.scalar_tensor_tensor(
                data=running_out,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_out,
            )

            running_max[:, :] = new_max[:, :]
            running_sum[:, :] = new_sum[:, :]
            running_out[:, :] = new_out[:, :]

        inverse_sum = nisa.reciprocal(data=running_sum)
        out_tile = nisa.tensor_scalar(
            data=running_out, op0=nl.multiply, operand0=inverse_sum,
        )
        nl.store(dst=kernel_out[nl.ds(i_tile_q * PMAX, PMAX), :], value=out_tile)

    return kernel_out
