"""Layer 5 — Z3 finite-precision spot-check for attn_causal_online.

Causal attention variant: each query tile i_tile_q only attends to
KV tiles [0..i_tile_q], so TILE_COUNT_LOCAL = i_tile_q + 1.

Bound: |err|_∞ ≤ 8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)

Z3 checks the bound for the worst-case query tile (last one,
TILE_COUNT_LOCAL = num_tile_q) and an interior tile.

Run:
    python3 bench_z3.py [--timeout 120]
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from z3 import RealVal, Real, Solver, sat, unsat, If

HERE = Path(__file__).resolve().parent
REPORTS_DIR = HERE / "reports"

EPS_FP32 = 2.0 ** -23
TILE_KV = 128

SHAPES = [
    {"seqlen": 16, "d_head": 8, "note": "last q-tile (worst-case)"},
    {"seqlen": 32, "d_head": 8, "note": "last q-tile"},
    {"seqlen": 64, "d_head": 8, "note": "last q-tile"},
    {"seqlen": 64, "d_head": 8, "i_tile_q": 0, "note": "first q-tile (best-case, 1 KV tile)"},
]

INPUT_MAGNITUDE_BOUND = 10.0


def z3_abs(x):
    return If(x >= 0, x, -x)


def check_bound(seqlen: int, d_head: int, i_tile_q: int | None = None,
                timeout_s: int = 120) -> dict:
    num_tile_q = max(1, seqlen // TILE_KV)
    if i_tile_q is None:
        i_tile_q = num_tile_q - 1
    tile_count_local = i_tile_q + 1

    eps = RealVal(EPS_FP32)
    bound_coeff = RealVal(8 * tile_count_local) * eps

    s = Solver()
    s.set("timeout", timeout_s * 1000)

    out_max = Real("out_max")
    s.add(out_max > 0)
    s.add(out_max <= INPUT_MAGNITUDE_BOUND)

    err_accum = RealVal(0)
    for tile_idx in range(tile_count_local):
        tile_err = Real(f"tile_err_{tile_idx}")
        correction = Real(f"correction_{tile_idx}")

        s.add(z3_abs(tile_err) <= eps * out_max)
        s.add(correction >= 0)
        s.add(correction <= 1)

        err_accum = err_accum * correction + tile_err

    proven_bound = bound_coeff * out_max
    s.add(z3_abs(err_accum) > proven_bound)

    t0 = time.monotonic()
    result = s.check()
    elapsed = time.monotonic() - t0

    verdict = {
        "shape": f"seqlen={seqlen}, d_head={d_head}, i_tile_q={i_tile_q}",
        "tile_count_local": tile_count_local,
        "result": str(result),
        "elapsed_s": round(elapsed, 3),
    }

    if result == sat:
        model = s.model()
        verdict["counterexample"] = {
            str(d): str(model[d]) for d in model.decls()
        }
        verdict["status"] = "FAIL"
    elif result == unsat:
        verdict["status"] = "PASS"
    else:
        verdict["status"] = "UNKNOWN"

    return verdict


def main():
    parser = argparse.ArgumentParser(description="Z3 FP bound spot-check (Layer 5)")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    REPORTS_DIR.mkdir(exist_ok=True)
    results = []
    all_pass = True

    print("=" * 60)
    print("Layer 5 — Z3 spot-check: attn_causal_online")
    print(f"Bound: |err|_∞ ≤ 8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)")
    print("=" * 60)

    for shape in SHAPES:
        itq = shape.get("i_tile_q")
        note = shape.get("note", "")
        print(f"\nChecking seqlen={shape['seqlen']}, d_head={shape['d_head']}"
              f"{f', i_tile_q={itq}' if itq is not None else ''} ({note})...")
        verdict = check_bound(shape["seqlen"], shape["d_head"], itq, args.timeout)
        results.append(verdict)

        status = verdict["status"]
        print(f"  tile_count_local={verdict['tile_count_local']}, "
              f"result={verdict['result']}, elapsed={verdict['elapsed_s']}s → {status}")

        if status != "PASS":
            all_pass = False
            if "counterexample" in verdict:
                print(f"  COUNTEREXAMPLE: {verdict['counterexample']}")

    summary = {
        "bundle": "attn_causal_online",
        "layer": 5,
        "prover": "Z3",
        "bound": "8 * TILE_COUNT_LOCAL * eps_fp32 * out_max",
        "note": "TILE_COUNT_LOCAL = i_tile_q + 1 (causal mask)",
        "all_pass": all_pass,
        "shapes": results,
    }

    out_path = REPORTS_DIR / "z3_summary.json"
    out_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(f"\nSummary written to {out_path}")

    if all_pass:
        print("\n✓ ALL SHAPES UNSAT — bound holds.")
    else:
        print("\n✗ SOME SHAPES SAT OR UNKNOWN.")
        sys.exit(1)


if __name__ == "__main__":
    main()
