"""Trainium-simulator differential check for the causal kernels.

Runs both `attn_fwd_v3_causal_baseline` (offline + masked) and
`attn_fwd_v3_causal_online` (online + masked-tile-aware) through
`nki.simulate_kernel` and confirms equivalence within the proven bound.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import neuronxcc.nki as nki  # noqa: E402

from baseline_nki import attn_fwd_v3_causal_baseline  # noqa: E402
from improved import av_error_bound, proven_error_bound  # noqa: E402
from improved_nki import attn_fwd_v3_causal_online  # noqa: E402
from reference import reference_attention  # noqa: E402


REPORTS_DIR = HERE / "reports"
D_HEAD = 128
DEFAULT_SEQLEN = 512
DEFAULT_TRIALS = 3
DEFAULT_SEED = 20260507


def _max_err(a, b):
    return float(np.max(np.abs(a - b)))


def _trial(seqlen, trial_idx, rng):
    q = rng.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    k = rng.standard_normal((D_HEAD, seqlen)).astype(np.float32)
    v = rng.standard_normal((D_HEAD, seqlen)).astype(np.float32)

    t0 = time.time()
    base = nki.simulate_kernel(attn_fwd_v3_causal_baseline, q, k, v)
    t_base = time.time() - t0

    t0 = time.time()
    impr = nki.simulate_kernel(attn_fwd_v3_causal_online, q, k, v)
    t_impr = time.time() - t0

    ref = reference_attention(q, k, v)

    err_impr_vs_base = _max_err(impr, base)
    err_impr_vs_ref = _max_err(impr, ref)
    err_base_vs_ref = _max_err(base, ref)
    out_max = float(np.max(np.abs(base)))
    bound_wc = proven_error_bound(seqlen, out_max=out_max)
    bound_av = av_error_bound(seqlen, out_max=out_max, alpha=0.05)

    return {
        "trial_idx": trial_idx,
        "seqlen": seqlen,
        "err_impr_vs_base": err_impr_vs_base,
        "err_impr_vs_ref": err_impr_vs_ref,
        "err_base_vs_ref": err_base_vs_ref,
        "out_max": out_max,
        "proven_bound_worst_case": bound_wc,
        "proven_bound_av_alpha_0_05": bound_av,
        "within_bound_vs_base": bool(err_impr_vs_base <= bound_wc),
        "within_av_bound_vs_base": bool(err_impr_vs_base <= bound_av),
        "sim_time_baseline_s": t_base,
        "sim_time_improved_s": t_impr,
    }


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--seqlen", type=int, default=DEFAULT_SEQLEN)
    parser.add_argument("--n-trials", type=int, default=DEFAULT_TRIALS)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    args = parser.parse_args(argv)

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    print(
        f"[verify_nki/causal] seqlen={args.seqlen} d_head={D_HEAD} "
        f"trials={args.n_trials} seed={args.seed}"
    )

    rows = []
    all_ok = True
    for i in range(args.n_trials):
        print(f"[verify_nki/causal] trial {i + 1}/{args.n_trials} simulating...", flush=True)
        row = _trial(args.seqlen, i, rng)
        rows.append(row)
        wc_ok = row["within_bound_vs_base"]
        av_ok = row["within_av_bound_vs_base"]
        status = "PASS" if wc_ok else "FAIL"
        av_marker = "AV-PASS" if av_ok else "AV-fail"
        print(
            f"  [{status}/{av_marker}] trial {i + 1}: "
            f"err={row['err_impr_vs_base']:.3e}  "
            f"WC={row['proven_bound_worst_case']:.3e}  "
            f"AV={row['proven_bound_av_alpha_0_05']:.3e}  "
            f"out_max={row['out_max']:.3f}  "
            f"sim={row['sim_time_baseline_s']:.1f}+{row['sim_time_improved_s']:.1f}s"
        )
        if not wc_ok:
            all_ok = False

    summary = {
        "passed": all_ok,
        "kernel": "nki_attention_causal_online_demo (real @nki.jit)",
        "simulator": "neuronxcc.nki.simulate_kernel",
        "seqlen": args.seqlen,
        "d_head": D_HEAD,
        "n_trials": args.n_trials,
        "n_within_bound_vs_base": sum(1 for r in rows if r["within_bound_vs_base"]),
        "n_within_av_bound_vs_base": sum(
            1 for r in rows if r["within_av_bound_vs_base"]
        ),
        "max_err_impr_vs_base": max(r["err_impr_vs_base"] for r in rows),
        "max_err_impr_vs_ref": max(r["err_impr_vs_ref"] for r in rows),
        "max_err_base_vs_ref": max(r["err_base_vs_ref"] for r in rows),
    }

    (REPORTS_DIR / "nki_summary.json").write_text(json.dumps(summary, indent=2))
    (REPORTS_DIR / "nki_test_report.json").write_text(
        json.dumps({"summary": summary, "trials": rows}, indent=2, default=str)
    )
    print(json.dumps(summary, indent=2))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
