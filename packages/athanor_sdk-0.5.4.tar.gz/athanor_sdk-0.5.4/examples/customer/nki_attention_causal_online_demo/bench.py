"""Static op-count + cycle-cost analysis for causal attention:
    - upstream `attn_fwd_v3` (offline, no causal mask, ~mirror)
    - this bundle's `attn_fwd_v3_causal_online` (online + causal)

The dominant gain is matmul-count reduction from skipping upper-
triangular tiles entirely. Per query tile, only `i_tile_q + 1` kv-tiles
are processed, averaging N/2 over all query tiles.

Reference cost annotations: NKI ISA reference.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Reuse the cost helpers from the v3_online bundle's bench
HERE = Path(__file__).resolve().parent
SIBLING = HERE.parent / "nki_attention_v3_online_demo"
sys.path.insert(0, str(SIBLING))

from bench import (  # noqa: E402
    PMAX, FMAX_STATIONARY, FMAX_MOVING,
    cycles_nc_matmul_fp32, cycles_tensor_copy, cycles_tensor_reduce,
    cycles_tensor_scalar, cycles_activation, cycles_nc_transpose,
    cycles_reciprocal, cycles_scalar_tensor_tensor,
    hbm_bytes_load, hbm_bytes_store, cost_v3_baseline,
)


def cost_v3_causal_online(seqlen: int, d_head: int = 128) -> dict:
    """Causal online-softmax variant from this bundle.

    Per query tile, only `i_tile_q + 1` kv-tiles are processed. For
    the diagonal tile we apply `nisa.affine_select` (per-element mask).
    """
    num_tile_q = seqlen // PMAX
    num_tile_kv = seqlen // PMAX

    te_cycles = 0
    ve_cycles = 0
    se_cycles = 0
    hbm_bytes = 0

    hbm_bytes += 3 * hbm_bytes_load(d_head, seqlen)

    # Pre-transpose v
    te_cycles += num_tile_kv * cycles_nc_transpose(PMAX, PMAX)
    se_cycles += num_tile_kv * cycles_tensor_copy(PMAX)
    hbm_bytes += num_tile_kv * hbm_bytes_store(PMAX, d_head)

    for i_tile_q in range(num_tile_q):
        # Only i_tile_q + 1 kv-tiles are processed
        for i_tile_kv in range(i_tile_q + 1):
            te_cycles += cycles_nc_matmul_fp32(PMAX, PMAX, PMAX)
            se_cycles += cycles_tensor_copy(PMAX)

            # affine_select adds GpSimd cost on diagonal tile only
            if i_tile_kv == i_tile_q:
                # ~150 + N GpSimd cycles
                ve_cycles += 150 + PMAX

            ve_cycles += cycles_tensor_reduce(PMAX)
            ve_cycles += PMAX  # nl.maximum
            ve_cycles += cycles_tensor_scalar(1)
            se_cycles += cycles_activation(1)
            se_cycles += cycles_activation(PMAX)
            ve_cycles += cycles_scalar_tensor_tensor(1)
            te_cycles += cycles_nc_transpose(PMAX, PMAX)
            se_cycles += cycles_tensor_copy(PMAX)
            hbm_bytes += hbm_bytes_load(PMAX, d_head)
            te_cycles += cycles_nc_matmul_fp32(PMAX, PMAX, PMAX)
            se_cycles += cycles_tensor_copy(d_head)
            ve_cycles += cycles_scalar_tensor_tensor(d_head)
            se_cycles += cycles_tensor_copy(1) + cycles_tensor_copy(1) + cycles_tensor_copy(d_head)

        ve_cycles += cycles_reciprocal(1)
        ve_cycles += cycles_tensor_scalar(d_head)
        hbm_bytes += hbm_bytes_store(PMAX, d_head)

    n_active_tiles = num_tile_q * (num_tile_q + 1) // 2

    return {
        "kernel": "attn_fwd_v3_causal_online (this bundle)",
        "te_cycles": te_cycles,
        "ve_cycles": ve_cycles,
        "se_cycles": se_cycles,
        "hbm_bytes": hbm_bytes,
        "hbm_mib": hbm_bytes / (1024**2),
        "qk_matmul_count": n_active_tiles,
        "attn_matmul_count": n_active_tiles,
        "tile_skip_ratio": 1.0 - (n_active_tiles / (num_tile_q * num_tile_kv)),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seqlen", type=int, default=4096)
    parser.add_argument("--d-head", type=int, default=128)
    args = parser.parse_args(argv)

    base = cost_v3_baseline(args.seqlen, args.d_head)
    causal = cost_v3_causal_online(args.seqlen, args.d_head)

    print(f"## Causal-attention cycle-cost analysis")
    print(f"   seqlen={args.seqlen}  d_head={args.d_head}")
    print()
    print(f"  {'metric':<20} {'baseline (v3)':>15} {'causal_online':>20} {'ratio':>10}")
    print(f"  {'-'*20} {'-'*15} {'-'*20} {'-'*10}")
    for label in ("te_cycles", "ve_cycles", "se_cycles"):
        b = base[label]
        c = causal[label]
        ratio = b / c if c else float("inf")
        print(f"  {label:<20} {b:>15,} {c:>20,} {ratio:>9.2f}x")
    print(f"  {'hbm_bytes':<20} {base['hbm_mib']:>13.2f} MiB {causal['hbm_mib']:>18.2f} MiB {base['hbm_bytes']/causal['hbm_bytes']:>9.2f}x")
    print()
    print(f"  Tile skip ratio: {causal['tile_skip_ratio']*100:.1f}% of (i_tile_q, i_tile_kv) pairs are masked + skipped")
    print(f"  Matmul savings: baseline qk+attn = {base['qk_matmul_count'] + base['attn_matmul_count']}, "
          f"causal_online = {causal['qk_matmul_count'] + causal['attn_matmul_count']} ({(base['qk_matmul_count'] + base['attn_matmul_count']) / (causal['qk_matmul_count'] + causal['attn_matmul_count']):.2f}x)")

    out = {
        "seqlen": args.seqlen,
        "d_head": args.d_head,
        "baseline": base,
        "causal_online": causal,
    }
    (HERE / "reports" / "bench_summary.json").write_text(json.dumps(out, indent=2))

    return 0


if __name__ == "__main__":
    sys.exit(main())
