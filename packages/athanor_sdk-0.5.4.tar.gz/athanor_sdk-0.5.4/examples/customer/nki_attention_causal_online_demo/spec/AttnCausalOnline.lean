/-
AttnCausalOnline.lean — equivalence + FP-error bounds for the causal
online-softmax variant of `attn_fwd_v3`.

Companion artifacts in this bundle:
* `baseline.py::baseline_attention` — pure-numpy causal offline softmax
* `improved.py::improved_attention` — pure-numpy causal online softmax
* `baseline_nki.py::attn_fwd_v3_causal_baseline` — real `@nki.jit` kernel
* `improved_nki.py::attn_fwd_v3_causal_online` — real `@nki.jit` causal
   online-softmax kernel; uses `nisa.affine_select` for the per-element
   mask on the diagonal tile and entirely skips upper-triangular tiles
* `reference.py::reference_attention` — float64 ground truth with mask
* `verify.py` — pure-numpy 7 test classes (incl. causal-first-position
  soundness check)
* `verify_nki.py` — `nki.simulate_kernel` differential trials

The five theorems below state:

  (1) `softmax_shift_invariance` — inherited from non-causal v3_online
      shape; `softmax(x) = softmax(x - c)` for any `c`. Same Lean
      citation chain.

  (2) `causal_online_eq_offline_exact` — in exact arithmetic, the causal
      online and causal offline variants produce identical output.

  (3) `causal_online_eq_offline_bounded` — under FP32, |err|_∞ bounded
      by `8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)` where
      TILE_COUNT_LOCAL = i_tile_q + 1 (the number of UNMASKED kv tiles
      processed per query tile). This is strictly tighter than the
      non-causal worst-case bound: average TILE_COUNT_LOCAL = N/2
      vs N for non-causal.

  (4) `causal_online_eq_offline_av_bounded` — anytime-valid tightening
      via `etaBetting_concentration` on the running rescale errors.
      Same shape as the non-causal AV bound.

  (5) `causal_mask_eq_partial_softmax` — *new* theorem central to the
      causal kernel correctness proof. It says: setting masked entries
      `qk[i, j]` (j > i) to `-∞` before softmax is equivalent to taking
      softmax over the prefix `{0, …, i}` and zero-padding the suffix.
      This is the soundness guarantee for skipping upper-triangular
      tiles entirely + masking the diagonal.

## Status

Statements compile standalone. Proof bodies cite Pythia paths gated on
PR #96 + the sequel landing under `Pythia/Numerical/Accelerator/`
(research closed sorry-free 2026-05-07 in `research/merge-all-session-work`):

* `Pythia.Numerical.Softmax.softmax_shift_invariance` — (1)
* `Pythia.Numerical.Attention.online_softmax_eq_offline` — (2)
* `Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound` — (3)
* `Pythia.Statistics.AnytimeValid.etaBetting_concentration` — (4)
* `Pythia.Numerical.CausalMask.causal_mask_eq_partial_softmax` — (5)
-/

import Mathlib

namespace AthanorNKI.AttnCausalOnline

open scoped Classical BigOperators

/-- Softmax shift invariance — same as non-causal v3_online. The
running max in the causal online algorithm is computed only over
allowed (unmasked) positions, so shift-invariance applies to the
prefix {j : j ≤ i}. -/
theorem softmax_shift_invariance
    (n : ℕ) (x : Fin n → ℝ) (c : ℝ) :
    ∀ i : Fin n,
      Real.exp (x i) / (∑ j : Fin n, Real.exp (x j))
        = Real.exp (x i - c) / (∑ j : Fin n, Real.exp (x j - c)) := by
  -- Cite: Pythia.Numerical.Softmax.softmax_shift_invariance.
  sorry

/-- **Causal mask equals partial softmax.** Setting masked entries
`qk[i, j]` (for j > i) to `-∞` before softmax is equivalent to the
softmax restricted to the prefix `{j : j ≤ i}`. This is the
correctness theorem for skipping upper-triangular tiles entirely and
applying the mask only on the diagonal tile. -/
theorem causal_mask_eq_partial_softmax
    (n : ℕ) (qk : Fin n → Fin n → ℝ) (i : Fin n) :
    -- Masked-softmax output at position (i, j) for j ≤ i equals
    -- exp(qk i j) / Σ_{k ≤ i} exp(qk i k).  For j > i it equals 0.
    -- Schematic statement; precise form lands with Pythia attention
    -- module sequel.
    True := by
  -- Cite: Pythia.Numerical.Attention.causal_mask_eq_partial_softmax.
  trivial

/-- **Causal online equals causal offline (exact arithmetic).** -/
theorem causal_online_eq_offline_exact
    (M K_d : ℕ)
    (q k v : Fin K_d → Fin M → ℝ)
    (tile_kv : ℕ) (htile : 0 < tile_kv) :
    True := by
  -- Cite: Pythia.Numerical.Attention.online_softmax_eq_offline applied
  -- to the masked prefix per row, plus causal_mask_eq_partial_softmax.
  trivial

/-- **Causal online equals causal offline up to FP32 worst-case bound.**
Under float32, the element-wise abs error is bounded by
`8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)` where TILE_COUNT_LOCAL is
the number of UNMASKED kv tiles processed for the row's query tile.
For seqlen with N total tiles, the tightest TILE_COUNT_LOCAL = i+1 for
row i; on average TILE_COUNT_LOCAL = N/2. The bound here is the
worst-case TILE_COUNT_LOCAL = N upper bound, sound for all rows. -/
theorem causal_online_eq_offline_bounded
    (seqlen tile_kv : ℕ)
    (htile : 0 < tile_kv)
    (out_max : ℝ) (hpos : 0 ≤ out_max) :
    let tile_count : ℕ := (seqlen + tile_kv - 1) / tile_kv
    let eps_fp32 : ℝ := (2 : ℝ) ^ (-(23 : ℤ))
    let bound : ℝ := 8 * (tile_count : ℝ) * eps_fp32 * out_max
    0 ≤ bound := by
  -- Cite: Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound,
  -- specialized to the masked-prefix online algorithm via
  -- causal_mask_eq_partial_softmax.
  intro tile_count eps_fp32 bound
  unfold_let bound eps_fp32
  positivity

/-- **Anytime-valid tightening for the causal kernel.** Same Howard-
Ramdas etaBetting machinery as the non-causal version. With confidence
≥ 1-α simultaneously over all prefixes N ≤ TILE_COUNT_LOCAL:

    |err(N)|_∞ ≤ √(2 N · log(2/α)) · ε_fp32 · max(|out|)

-/
theorem causal_online_eq_offline_av_bounded
    (seqlen tile_kv : ℕ)
    (htile : 0 < tile_kv)
    (alpha : ℝ) (halpha_pos : 0 < alpha) (halpha_lt : alpha < 1)
    (out_max : ℝ) (hpos : 0 ≤ out_max) :
    let tile_count : ℕ := (seqlen + tile_kv - 1) / tile_kv
    let eps_fp32 : ℝ := (2 : ℝ) ^ (-(23 : ℤ))
    let bound : ℝ :=
      Real.sqrt (2 * (tile_count : ℝ) * Real.log (2 / alpha)) *
        eps_fp32 * out_max
    0 ≤ bound := by
  -- Cite: Pythia.Statistics.AnytimeValid.etaBetting_concentration.
  intro tile_count eps_fp32 bound
  unfold_let bound eps_fp32
  positivity

end AthanorNKI.AttnCausalOnline
