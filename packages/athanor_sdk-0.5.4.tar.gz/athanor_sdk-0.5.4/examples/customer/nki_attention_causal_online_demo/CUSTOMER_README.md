# Causal online-softmax kernel for `attn_fwd_v3` — 1.92x Tensor Engine reduction, 18x HBM bandwidth reduction at seqlen=4096

## Headline numbers vs upstream `attn_fwd_v3`

Static op-count + cycle-cost analysis from NKI ISA cost annotations (`bench.py`):

| seqlen | TE cycles ratio | HBM bandwidth ratio | Tile skip ratio |
|---|---|---|---|
| 1024 | **1.72x** | **10.63x** | 43.8% upper-triangular skipped |
| 2048 | **1.85x** | **14.59x** | 46.9% |
| 4096 | **1.92x** | **18.09x** | 48.4% |
| 8192 | **1.96x** | **20.61x** | 49.2% |

Causal masking + skip-upper-triangular optimization: ~half the (i_tile_q, i_tile_kv) pairs are masked entirely, no `nc_matmul` executed for them. Upstream `attn_fwd_v1..v8a` all run the full kv sweep regardless of causality.

## What this package proposes

The upstream `attention_fwd_performance` tutorial line (`attn_fwd_v1` through `attn_fwd_v8a`) ships eight bidirectional self-attention kernels — none with a causal mask. Every decoder-only LLM in production (Llama, Qwen, Mistral, Claude, GPT) uses causal attention. This package proposes `attn_fwd_v3_causal_online`:

- **Causal mask via `nisa.affine_select`** on the diagonal tile only; upper-triangular tiles are skipped entirely (no nc_matmul, no softmax, no rescale).
- **Online softmax** running stats — same algorithmic shift as the v3_online sibling package. No QK matrix materialization in HBM.
- **~half the matmul cost** of non-causal: only `i_tile_q + 1` kv-tiles are processed per query tile, averaging N/2 over the full kernel vs N for non-causal.
- **Bit-equivalent in exact arithmetic** to a hand-coded causal offline-softmax baseline. Bounded under FP32 by `8 · TILE_COUNT_LOCAL · ε_fp32 · max(|out|)` (worst-case) and `√(2N · log(2/α)) · ε_fp32 · max(|out|)` anytime-valid at α=0.05.

## Why this matters for production NKI

Production decoder serving has TWO bottlenecks the upstream v1-v8a kernels don't address:
1. *Causal mask.* The upper triangle is wasted compute. Skipping it is ~50% latency reduction for decoder forward passes.
2. *Causal-aware online softmax.* The online algorithm composes with causal masking — the running max/sum/output are computed only over allowed positions, no per-row branching needed.

This package proposes the causal variant of `attn_fwd_v3_online` (sibling package), keeping the same Trainium ISA primitives plus `nisa.affine_select` for the per-element mask on the diagonal.

## What's in this package

| File | Role |
|---|---|
| `baseline.py` | Pure-numpy causal offline softmax. Algorithmic shape mirroring upstream `attn_fwd_v3` + np.where mask. |
| `improved.py` | Pure-numpy causal online softmax with 3-tier per-tile classification (skip / unmasked / diagonal-masked). |
| `baseline_nki.py` | Real `@nki.jit` kernel, causal offline softmax with `nisa.affine_select` mask. |
| `improved_nki.py` | Real `@nki.jit` kernel, causal online softmax. Skips upper tiles entirely + masks diagonal via `affine_select`. |
| `reference.py` | float64 ground truth with mask. |
| `spec/AttnCausalOnline.lean` | Lean 4 source-of-truth: 5 theorems including `causal_mask_eq_partial_softmax`. Statements compile standalone; proof bodies cite Pythia paths gated on PR #96 and the attention-module sequel. |
| `verify.py` | Pure-numpy 7 test classes (incl. `causal_first_position` soundness check). 7/7 PASS. |
| `verify_nki.py` | Trainium-simulator differential trials. 5/5 PASS at seqlen=512 with both bounds. |
| `upstream_pr_proposal/` | Drop-in PR shape for `aws-neuron/nki-samples` adding `attn_fwd_v3_causal_online`. |

## How to run

```bash
$ cd examples/customer/nki_attention_causal_online_demo
$ python3 verify.py
  [PASS] basic_shape
  [PASS] causal_first_position
  [PASS] tiny_seqlen
  [PASS] one_tile_boundary
  [PASS] differential_seqlen_512
  [PASS] differential_seqlen_2048
  [PASS] memory_savings

$ python3 verify_nki.py --seqlen 512 --n-trials 5
  [PASS/AV-PASS] trial 1: err=4.768e-07  WC=1.494e-05  AV=2.536e-06  ...
  ...
```

## Lean theorems

1. `softmax_shift_invariance` — inherited from v3_online.
2. `causal_mask_eq_partial_softmax` — *new*. Setting `qk[i, j]` for `j > i` to `-∞` is equivalent to softmax over the prefix `{j : j ≤ i}`. Soundness theorem for upper-triangular tile skipping + diagonal mask.
3. `causal_online_eq_offline_exact` — bit-exact equivalence in real arithmetic.
4. `causal_online_eq_offline_bounded` — worst-case FP32 bound `8 · TILE_COUNT_LOCAL · ε · out_max`.
5. `causal_online_eq_offline_av_bounded` — anytime-valid `√(2N · log(2/α)) · ε · out_max`.

All five compile standalone. Proof bodies become verbatim citation chains post-Pythia attention-module sequel.

## Cross-references

- **Sibling kernel**: `examples/customer/nki_attention_v3_online_demo/` — non-causal v3_online (same trust stack, different mask)
- **Source kernel line**: `aws-neuron/nki-samples/src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py::attn_fwd_v3` … `attn_fwd_v8a`
- **`nisa.affine_select` upstream**: documented in NKI ISA reference as the preferred causal-mask op
- **Pythia PR #96**: <https://github.com/athanor-ai/pythia/pull/96>
- **Anytime-valid concentration**: Howard-Ramdas etaBetting submartingale construction
