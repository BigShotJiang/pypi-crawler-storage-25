"""float64 reference for causal attention. Used as ground truth in
verify.py differential checks."""
from __future__ import annotations

import numpy as np


def causal_mask(seqlen_q: int, seqlen_kv: int) -> np.ndarray:
    rows = np.arange(seqlen_q)[:, None]
    cols = np.arange(seqlen_kv)[None, :]
    return cols <= rows


def reference_attention(
    q: np.ndarray, k: np.ndarray, v: np.ndarray
) -> np.ndarray:
    """Causal attention in float64; output cast back to float32 to match
    baseline/improved input-dtype contract."""
    q64 = q.astype(np.float64)
    k64 = k.astype(np.float64)
    v64 = v.astype(np.float64)
    d_head, seqlen = q64.shape
    qk = q64.T @ k64
    mask = causal_mask(seqlen, seqlen)
    qk = np.where(mask, qk, -1e30)
    row_max = np.max(qk, axis=1, keepdims=True)
    exp = np.exp(qk - row_max)
    row_sum = exp.sum(axis=1, keepdims=True)
    scores = exp / row_sum
    return (scores @ v64.T).astype(np.float32)
