"""Baseline — pure-numpy reproduction of aws-neuron/nki-samples
attn_fwd_v3: tiled Q@K matmul + offline row-wise softmax + scores@V.

This module mirrors the algorithmic shape of `attn_fwd_v3` (the
canonical "large seqlen with tiling + offline softmax" pattern in
the official AWS Neuron NKI tutorial) without the NKI-specific
hardware ops (nl.load / nisa.nc_matmul / nisa.tensor_reduce / etc).

The point is to expose the **algorithmic decision** that the
companion `improved.py` module overturns: this baseline materializes
the FULL `(seqlen_q, seqlen_kv)` QK matrix in memory before computing
softmax. For seqlen_kv = 4096 + d_head = 128 + fp32, that's
4096 * 4096 * 4 = 64 MiB per attention head — multiple HBM round-trips
to read for the row-max + row-sum + division passes.

The `improved.py` online-softmax variant proves equivalent to within
a tight FP-precision bound while reducing the working memory to
O(seqlen_q * d_head) — for the same shape, ~512 KiB instead of 64 MiB.

Cross-refs:

* Source kernel: `aws-neuron/nki-samples/src/nki_samples/tutorials/
  attention_fwd_performance/attention_kernels.py::attn_fwd_v3`
* Improved variant: `improved.py` in this bundle
* Lean theorem: `spec/AttnFwdV3Online.lean::baseline_eq_improved_bounded`
"""
from __future__ import annotations

import numpy as np


def baseline_attention(q: np.ndarray, k: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Offline-softmax attention in float32.

    Pure-numpy mirror of attn_fwd_v3. Allocates the full QK matrix
    (this is the memory-traffic bottleneck the improved variant fixes).

    Args:
        q: (d_head, seqlen) float32
        k: (d_head, seqlen) float32
        v: (d_head, seqlen) float32

    Returns:
        out: (seqlen, d_head) float32
    """
    if q.dtype != np.float32:
        q = q.astype(np.float32)
    if k.dtype != np.float32:
        k = k.astype(np.float32)
    if v.dtype != np.float32:
        v = v.astype(np.float32)

    d_head, seqlen = q.shape
    assert k.shape == (d_head, seqlen), f"K shape {k.shape} != Q {q.shape}"
    assert v.shape == (d_head, seqlen), f"V shape {v.shape} != Q {q.shape}"

    # Tile-PSUM matmul (PARTITION_SIZE=128 matches NKI nl.tile_size.pmax)
    qk = (q.T @ k).astype(np.float32)              # (seqlen, seqlen) — full matrix in HBM

    # Offline softmax — three full-row passes
    row_max = np.max(qk, axis=1, keepdims=True)    # pass 1: read full QK row
    qk_norm = qk - row_max                          # pass 2: read again, subtract
    exp_qk = np.exp(qk_norm)                        # in-place after subtract
    row_sum = np.sum(exp_qk, axis=1, keepdims=True) # pass 3: read again, reduce
    p = exp_qk / row_sum                            # in-place after sum
    out = (p @ v.T).astype(np.float32)              # (seqlen, d_head)
    return out


def memory_bytes(seqlen: int, d_head: int) -> int:
    """Working-memory footprint estimate for offline path.

    The QK matrix dominates: seqlen * seqlen * sizeof(float32). The
    O(seqlen * d_head) Q/K/V/out buffers are flat overhead.
    """
    f32 = 4
    qk_bytes = seqlen * seqlen * f32
    qkv_bytes = 3 * d_head * seqlen * f32
    out_bytes = seqlen * d_head * f32
    return qk_bytes + qkv_bytes + out_bytes
