"""Real `@nki.jit` improved kernel: online-softmax variant of `attn_fwd_v3`.

Algorithm: process kv-tiles incrementally with running max + running sum +
running output. Never materializes the full QK matrix in HBM.

Per i_tile_q:
    Initialize running_max=-inf, running_sum=0, running_out=0.
    For each i_tile_kv (PMAX wide):
        1. qk_tile = q_tile @ k_tile           (PMAX_q, PMAX_kv) PSUM
        2. tile_max = max(qk_tile, axis=1)     (PMAX, 1)
        3. new_max = max(running_max, tile_max)
        4. correction = exp(running_max - new_max)
        5. p = exp(qk_tile - new_max) and tile_sum = sum(p, axis=1)
           (fused via `nisa.activation` with reduce_op=nl.add)
        6. running_sum = correction * running_sum + tile_sum
           (single Vector Engine op: `scalar_tensor_tensor`)
        7. tile_out = p_t @ v_t                (PMAX_q, d_head) PSUM
        8. running_out = correction * running_out + tile_out
           (single Vector Engine op: `scalar_tensor_tensor`)
        9. running_max = new_max
    out_tile = running_out / running_sum
    store kernel_out[i_tile_q*PMAX : (i_tile_q+1)*PMAX, :] = out_tile

Working memory vs upstream `attn_fwd_v3` at seqlen=4096/d_head=128/fp32:
    v3 HBM scratch:  qk + norm_row + exp_row + scores  ≈ 4 * 64 MiB = 256 MiB
    online HBM:      v_t pre-transpose only             ≈ 8 MiB
                                                          ~32x HBM reduction

Equivalence: identity in exact arithmetic (softmax shift-invariance);
bounded by `8 · TILE_COUNT · ε_fp32 · max(|out|)` worst-case under FP32
arithmetic; tighter `O(√TILE_COUNT · log(1/α) · ε_fp32 · max(|out|))`
high-probability via anytime-valid concentration on the running-rescale
errors (Howard-Ramdas etaBetting bound).

See `spec/AttnFwdV3Online.lean` for the formal statements.
"""
from __future__ import annotations

import neuronxcc.nki as nki
import neuronxcc.nki.isa as nisa
import neuronxcc.nki.language as nl


@nki.jit
def attn_fwd_v3_online(q, k, v):
    """Online-softmax attention, drop-in shape-compatible with `attn_fwd_v3`.

    Inputs (d_head, seqlen). Output (seqlen_q, d_head). d_head must equal
    PMAX=128. seqlen must be ≥ 256 and divisible by PMAX.
    """
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q

    PMAX = nl.tile_size.pmax

    assert q.shape == k.shape == v.shape
    assert d_head == PMAX
    assert seqlen_q >= 256
    assert seqlen_q % PMAX == 0

    NEG_INF = -1.0e30
    num_tile_q = seqlen_q // PMAX
    num_tile_kv = seqlen_kv // PMAX

    kernel_out = nl.ndarray((seqlen_q, d_head), dtype=q.dtype, buffer=nl.shared_hbm)

    q_sbuf = nl.load(q)
    k_sbuf = nl.load(k)
    v_sbuf = nl.load(v)

    v_t = nl.ndarray(
        (num_tile_kv, PMAX, d_head),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_kv in nl.affine_range(num_tile_kv):
        v_psum_t = nisa.nc_transpose(data=v_sbuf[:, nl.ds(i_tile_kv * PMAX, PMAX)])
        v_sbuf_t = nisa.tensor_copy(v_psum_t)
        nl.store(v_t[i_tile_kv], v_sbuf_t[:, :])

    for i_tile_q in nl.sequential_range(num_tile_q):
        running_max = nl.full((PMAX, 1), NEG_INF, dtype=nl.float32, buffer=nl.sbuf)
        running_sum = nl.zeros((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
        running_out = nl.zeros((PMAX, d_head), dtype=nl.float32, buffer=nl.sbuf)

        for i_tile_kv in nl.sequential_range(num_tile_kv):
            qk_psum = nisa.nc_matmul(
                stationary=q_sbuf[0:PMAX, nl.ds(i_tile_q * PMAX, PMAX)],
                moving=k_sbuf[0:PMAX, nl.ds(i_tile_kv * PMAX, PMAX)],
            )
            qk_sbuf = nisa.tensor_copy(qk_psum)

            tile_max = nisa.tensor_reduce(
                op=nl.maximum, data=qk_sbuf, axis=(1,),
            )

            new_max = nl.maximum(running_max, tile_max)

            neg_new_max = nisa.tensor_scalar(
                data=new_max,
                op0=nl.multiply, operand0=-1.0,
            )
            correction = nisa.activation(
                op=nl.exp, data=running_max, bias=neg_new_max,
            )

            tile_sum = nl.ndarray((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
            p_sbuf = nisa.activation(
                op=nl.exp, data=qk_sbuf, bias=neg_new_max,
                reduce_op=nl.add, reduce_res=tile_sum,
                reduce_cmd=nisa.reduce_cmd.reset_reduce,
            )

            new_sum = nisa.scalar_tensor_tensor(
                data=running_sum,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_sum,
            )

            p_t_psum = nisa.nc_transpose(data=p_sbuf)
            p_t_sbuf = nisa.tensor_copy(p_t_psum)

            v_t_sbuf = nl.load(v_t[i_tile_kv, :, :])

            tile_out_psum = nisa.nc_matmul(
                stationary=p_t_sbuf, moving=v_t_sbuf,
            )
            tile_out = nisa.tensor_copy(tile_out_psum)

            new_out = nisa.scalar_tensor_tensor(
                data=running_out,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_out,
            )

            running_max[:, :] = new_max[:, :]
            running_sum[:, :] = new_sum[:, :]
            running_out[:, :] = new_out[:, :]

        inverse_sum = nisa.reciprocal(data=running_sum)
        out_tile = nisa.tensor_scalar(
            data=running_out,
            op0=nl.multiply, operand0=inverse_sum,
        )
        nl.store(dst=kernel_out[nl.ds(i_tile_q * PMAX, PMAX), :], value=out_tile)

    return kernel_out
