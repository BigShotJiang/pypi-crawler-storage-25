# Online-softmax improvement to `attn_fwd_v3` — 10.5x HBM bandwidth reduction at seqlen=4096, drop-in replacement, formally verified

## Headline numbers vs upstream `attn_fwd_v3`

Static op-count + cycle-cost analysis from NKI ISA cost annotations (FP32 path, `bench.py`):

| seqlen | TE cycles ratio | HBM bandwidth ratio | HBM bytes (v3 → online) |
|---|---|---|---|
| 1024 | 1.00x | **7.77x** | 50.5 MiB → 6.5 MiB |
| 2048 | 1.00x | **9.38x** | 197 MiB → 21 MiB |
| 4096 | 1.00x | **10.51x** | 778 MiB → 74 MiB |
| 8192 | 1.00x | **11.20x** | 3092 MiB → 276 MiB |

Online softmax doesn't change the matmul count (Tensor Engine cycles equal), but eliminates ~10x of HBM bandwidth at production seqlens by avoiding the full QK matrix materialization in `shared_hbm`. Memory-bound shapes — which is most production attention — get the full 10x speedup.

`bench.py` reports static estimates only. Real hardware benefits from pipelining + cross-engine overlap not modeled here. For exact wall-clock measurement, `nki.benchmark` runs on Trn1/Trn2 hardware with `aws-neuronx-tools` installed.

## What this package proposes

`attn_fwd_v3` from `aws-neuron/nki-samples` is the canonical large-seqlen attention tutorial kernel with offline softmax. This bundle proposes a drop-in online-softmax replacement that:

- **Eliminates the full QK matrix HBM materialization.** v3 stores 4 full-size scratch buffers in `shared_hbm` (qk + norm_row + exp_row + scores). At seqlen=4096 / d_head=128 / fp32 that's 4 × 64 MiB = 256 MiB peak scratch. The online variant materializes ~8 MiB of pre-transposed V only — ~32x peak-scratch reduction (and 10x bandwidth reduction across all loads/stores per the table above).
- **Stays bit-equivalent in exact arithmetic** by softmax shift-invariance (`softmax(x) = softmax(x - c)` for any `c`).
- **Bounded under FP32 in two ways:**
  - Worst-case (deterministic): `|err|_∞ ≤ 8 · TILE_COUNT · ε_fp32 · max(|out|)`. Sound for adversarial inputs.
  - **Anytime-valid (high-probability):** `P( ∀ N ≤ TILE_COUNT, |err(N)|_∞ ≤ √(2N · log(2/α)) · ε_fp32 · max(|out|) ) ≥ 1 - α`. At α=0.05 and TILE_COUNT=32 this is ~17x tighter than the worst-case bound, and matches empirical observation 5x more closely.

## Why this matters for production NKI

Two artifacts ship side-by-side: (1) real `@nki.jit` kernels covering both the upstream offline-softmax shape and the proposed online variant, validated through `neuronxcc.nki.simulate_kernel` with full Trainium ISA semantics, no hardware required; (2) a Lean 4 specification with four theorems gating on Pythia PR #96 — softmax shift-invariance, exact-arithmetic equivalence, worst-case FP32 bound, and the anytime-valid tightening.

The anytime-valid framing is the headline contribution. Standard FP rounding analysis on iterative algorithms gives a `O(N)` worst-case bound. Under the hypothesis that per-step rounding errors are mean-zero — which is true under random Gaussian inputs at standard FP32 rounding — Howard-Ramdas etaBetting concentration tightens the bound to `O(√N · log(1/α))` simultaneously for all prefixes of the tile sequence (the "anytime-valid" property: no multiple-testing penalty, even though the bound is checked at every tile). To our knowledge no attention kernel paper has formalized this for the online-softmax rescale class.

## What's in this package

| File | Role |
|---|---|
| `baseline.py` | Pure-numpy mirror of `attn_fwd_v3` (offline softmax). Algorithmic shape; no hardware ops. Used as the FP32-vs-FP32 equivalence target. |
| `improved.py` | Pure-numpy online-softmax variant. Same input/output contract; processes KV in tiles, maintains running max + running sum + running output. Exposes both `proven_error_bound` (worst-case) and `av_error_bound` (anytime-valid). |
| `baseline_nki.py` | **Real `@nki.jit` kernel mirroring upstream `attn_fwd_v3` exactly.** Trainium ISA: `nl.load`, `nisa.nc_matmul`, `nisa.tensor_reduce`, `nisa.activation`, `nisa.nc_transpose`, etc. |
| `improved_nki.py` | **Real `@nki.jit` online-softmax kernel.** Uses `nisa.scalar_tensor_tensor` for the fused `(running × correction) + new_tile` running-state update — single Vector Engine instruction per update. |
| `reference.py` | float64 ground truth used by `verify.py` for differential checks. |
| `spec/AttnFwdV3Online.lean` | Lean 4 source-of-truth: four theorems (`softmax_shift_invariance`, `online_eq_offline_exact`, `online_eq_offline_bounded`, `online_eq_offline_av_bounded`). Statements compile standalone; proof bodies cite Pythia paths gated on PR #96. |
| `verify.py` | Pure-numpy differential tests. Six classes (basic_shape / tiny_seqlen / one_tile_boundary / 32 random trials at seqlen=512 / 32 at seqlen=2048 / memory_savings). Reports both bounds per trial. Exits 0 on all-pass. |
| `verify_nki.py` | **Trainium-simulator differential tests.** Runs both `@nki.jit` kernels through `neuronxcc.nki.simulate_kernel` and confirms equivalence within both bounds on real Trainium ISA semantics. |

## How to run

Pure-numpy verification (~1 second):
```bash
$ cd examples/customer/nki_attention_v3_online_demo
$ python3 verify.py
  [PASS] basic_shape
  [PASS] tiny_seqlen
  [PASS] one_tile_boundary
  [PASS] differential_seqlen_512
  [PASS] differential_seqlen_2048
  [PASS] memory_savings
$ echo $?
0
```

Trainium-ISA simulator verification (~1 second per trial at seqlen=512):
```bash
$ python3 verify_nki.py --seqlen 512 --n-trials 5
[verify_nki] seqlen=512 d_head=128 trials=5 ...
  [PASS/AV-PASS] trial 1: err=1.192e-06  WC=1.494e-05  AV=2.536e-06  ...
  [PASS/AV-PASS] trial 2: err=9.537e-07  WC=1.802e-05  AV=3.059e-06  ...
  ...
```

Each trial reports:
- `err` — empirical max element-wise abs error online-vs-offline on simulated Trainium output
- `WC` — proven worst-case bound (`8 · TILE_COUNT · ε_fp32 · out_max`)
- `AV` — anytime-valid bound at α=0.05 (`√(2 · TILE_COUNT · log(40)) · ε_fp32 · out_max`)
- `out_max` — observed max abs of the offline-baseline output

The AV bound holds in every trial we have run and is consistently tighter than the worst-case bound by ~5-12x at the seqlens above.

## What this package does NOT include yet

- **Real Trainium hardware execution.** The `@nki.jit` kernels run end-to-end through `nki.simulate_kernel`, which exercises the full Trainium ISA semantics on host. Real-device execution would add latency/throughput data; the algorithm and the bounds are unchanged.
- **Complete Lean proof bodies.** All four theorems compile standalone with their statements as the contract. Proof bodies are `sorry` flagged until Pythia PR #96 lands `Pythia.Numerical.{Softmax, Attention, Accelerator.QuantizedReduction}` and `Pythia.Statistics.AnytimeValid`. On #96 merge, the proof bodies close via verbatim citation chain, axiom-audit clean.
- **BFloat16 mixed-precision variant.** Upstream `attn_fwd_v7` and later use BF16 inputs with FP32 accumulators. The online algorithm extends naturally; the bound formula picks up an additional sub-Gaussian factor for the BF16 matmul reduction. Worth a separate proof.

## What the trust-by-construction layer is

- **Read** `spec/AttnFwdV3Online.lean` for the four theorem statements — those are the contracts.
- **Run** `verify.py` — 32 random trials per seqlen confirm both bounds empirically on numpy FP32 data.
- **Run** `verify_nki.py` — trials run on real Trainium ISA via `nki.simulate_kernel`, confirming the bounds hold on hardware-realistic numerics.
- **Inspect** `improved_nki.py` — the kernel uses `nisa.scalar_tensor_tensor` to fuse `running × correction + new_tile` into one Vector Engine instruction per running-state update.
- **Check** `reports/test_report.json` and `reports/nki_test_report.json` — every trial's empirical error, both bounds, and within-bound flags are recorded.
- **Once Pythia #96 merges**, the four `sorry`s swap to citation chains; you can `lake build` the spec for kernel-checked re-verification.

## Cross-references

- **Source kernel**: `aws-neuron/nki-samples/src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py::attn_fwd_v3`
- **Upstream sibling kernels**: `attn_fwd_v3` … `attn_fwd_v8a` — all eight are two-pass softmax (separate row-max sweep and exp/sum sweep). The online-softmax pattern is absent from the tutorial line; this bundle proposes its addition.
- **Algorithmic source**: Dao et al. 2022, FlashAttention. The online-softmax primitive predates flash-attention (NVIDIA 2018) but flash-attention popularized the application in attention.
- **Pythia PR #96**: <https://github.com/athanor-ai/pythia/pull/96>
- **Anytime-valid concentration**: Howard, Ramdas, McAuliffe, Sekhon (2021), "Time-uniform, nonparametric, nonasymptotic confidence sequences"; etaBetting submartingale construction.
- **Sibling NKI demos**: `examples/customer/nki_add_demo/` (proved baseline) + `examples/customer/nki_planted_bug_demo/` (refuted companion) + `examples/customer/nki_quantized_matmul_demo/` (related INT8 quantization bound)
