# nki_attention_v3_online_demo

Engineer-facing entry. For customer-facing pitch see `CUSTOMER_README.md`.

## What

Take `attn_fwd_v3` from `aws-neuron/nki-samples` (offline-softmax tiled attention), propose an online-softmax variant, prove they're equivalent up to a tight FP32 bound (worst-case + anytime-valid), validate on the Trainium ISA simulator, verify ~32x HBM working-memory reduction.

## Files

```
nki_attention_v3_online_demo/
├── README.md                   ← this file
├── CUSTOMER_README.md          ← customer-facing pitch
├── baseline.py                 ← attn_fwd_v3 numpy mirror (offline softmax)
├── improved.py                 ← online-softmax numpy variant
├── baseline_nki.py             ← real @nki.jit attn_fwd_v3 mirror
├── improved_nki.py             ← real @nki.jit online-softmax kernel
├── reference.py                ← float64 ground truth
├── verify.py                   ← pure-numpy 6 test classes
├── verify_nki.py               ← nki.simulate_kernel sim trials
├── spec/
│   └── AttnFwdV3Online.lean    ← 4 theorems
└── reports/
    ├── summary.json
    ├── test_report.json
    ├── nki_summary.json
    └── nki_test_report.json
```

## Run

Fast (numpy only, ~1s):
```bash
cd examples/customer/nki_attention_v3_online_demo
python3 verify.py
```

Hardware-fidelity (Trainium ISA simulator, ~1-3s per trial):
```bash
python3 verify_nki.py --seqlen 512 --n-trials 5
python3 verify_nki.py --seqlen 1024 --n-trials 3
python3 verify_nki.py --seqlen 2048 --n-trials 1
```

Local environment requirements:
- numpy (verify.py only)
- `neuronx-cc` (for verify_nki.py — runs on host CPU, no Trainium hardware needed)

## Status

- Pure-numpy verify.py: 6/6 PASS, 64/64 random trials within both worst-case + AV bounds.
- NKI simulator verify_nki.py: validated at seqlen ∈ {512, 1024, 2048}, all trials within both bounds, online-vs-offline error ~1.2e-6 on Trainium ISA semantics.
- Lean theorems: 4 statements compile standalone, proof bodies sorry-flagged. Gates on Pythia PR #96 (`Pythia.Numerical.{Softmax, Attention, Accelerator.QuantizedReduction}` + `Pythia.Statistics.AnytimeValid`).
- Memory savings: ~32x at seqlen=4096 d_head=128 fp32 for HBM scratch (eliminates qk + norm_row + exp_row + scores intermediate buffers; only v_t pre-transpose remains).

## Lean theorems (`spec/AttnFwdV3Online.lean`)

1. `softmax_shift_invariance` — `softmax(x) = softmax(x - c)` for any `c`. Cites `Pythia.Numerical.Softmax.softmax_shift_invariance`.
2. `online_eq_offline_exact` — bit-exact equivalence in real arithmetic. Cites `Pythia.Numerical.Attention.online_softmax_eq_offline`.
3. `online_eq_offline_bounded` — worst-case FP32 bound `8 · TILE_COUNT · ε_fp32 · out_max`. Cites `Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound`.
4. `online_eq_offline_av_bounded` — anytime-valid high-probability bound `√(2 N · log(2/α)) · ε_fp32 · out_max` for all `N ≤ TILE_COUNT` with confidence `≥ 1-α`. Cites `Pythia.Statistics.AnytimeValid.etaBetting_concentration`.

All four compile standalone. Proof bodies become verbatim citation chains post-Pythia-#96 merge.

## Empirical bound performance

At seqlen=512 (TILE_COUNT=4):
- Worst-case bound: `8 · 4 · ε_fp32 · out_max ≈ 32 · ε · out_max`
- AV bound at α=0.05: `√(2 · 4 · log(40)) · ε · out_max ≈ 5.4 · ε · out_max`
- AV is ~6x tighter than worst-case
- Empirical max error ≈ `1.2e-6 ≈ 2 · ε`, well inside both bounds

At seqlen=2048 (TILE_COUNT=16):
- Worst-case: `~128 · ε · out_max`
- AV: `~10.8 · ε · out_max` — ~12x tighter
- Empirical: `~2.4e-6`, well inside both bounds

The AV bound holds in 64/64 random trials we have run.

## NOT auto-merging

Customer-bound artifact. Aidan greenlight required before any ship per `feedback_no_customer_ship_without_aidan_approval`.

## Open follow-ups

- Real Trainium hardware execution (vs simulator). Algorithm + bound unchanged.
- Causal-mask variant (current bundle is non-causal). Algorithm extends naturally; bound formula picks up a constant.
- BFloat16 mixed-precision variant matching upstream `attn_fwd_v7`/`v8a` (BF16 inputs, FP32 accumulators). Bound picks up an additional sub-Gaussian factor for the BF16 matmul reduction.
- Upstream PR proposal to `aws-neuron/nki-samples` adding `attn_fwd_v3_online` to the tutorial line.

## ATH ticket

ATH-1092 (Linear) — NKI flash-attention online-softmax improvement bundle.
