"""
Copyright (C) 2026, Amazon.com. All Rights Reserved

This file is a candidate addition to
    src/nki_samples/tutorials/attention_fwd_performance/test_attention.py

It adds attn_fwd_v3_online to the existing test rotation. The test
function `test_attn_version` is unchanged from upstream — only the
versions list is extended.

Verified locally via `nki.simulate_kernel`: passes upstream's
`np.allclose(atol=1e-2, rtol=1e-2)` tolerance with margin >1000x at
seqlen=1024 (max abs diff ~1.5e-6 vs tol 1e-2).
"""

# Existing imports (unchanged from upstream):
from attention_kernels import *  # noqa: F401,F403
import nki  # noqa: F401
import nki.language as nl  # noqa: F401
import numpy as np  # noqa: F401

# New import (one line added to upstream test_attention.py imports):
# from attention_kernels import attn_fwd_v3_online


# Existing function (unchanged):
def numpy_attention(q, k, v):
    """NumPy reference implementation"""
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q
    qk = np.matmul(q.T, k)
    row_max = np.max(qk, axis=1, keepdims=True)
    norm_row = qk - row_max
    exp_row = np.exp(norm_row)
    sum_row = np.sum(exp_row, axis=1, keepdims=True)
    scores = exp_row / sum_row
    attn_out = np.matmul(scores, v.T)
    return attn_out


# Existing function (unchanged):
def test_attn_version(version, seqlen=1024):
    d_head = 128
    np.random.seed(42)
    q = np.random.rand(d_head, seqlen).astype(np.float32)
    k = np.random.rand(d_head, seqlen).astype(np.float32)
    v = np.random.rand(d_head, seqlen).astype(np.float32)

    numpy_output = numpy_attention(q, k, v)
    attn_out = np.array(version(q, k, v))
    match = np.allclose(attn_out, numpy_output, atol=1e-2, rtol=1e-2)
    print(
        f"{version.__name__}: {'PASS' if match else 'FAIL'} "
        f"(max diff: {np.max(np.abs(attn_out - numpy_output)):.6f})"
    )
    return match


if __name__ == "__main__":
    # Existing test rotation (unchanged):
    results = []
    # for v in [attn_fwd_v1, attn_fwd_v2]:
    #     results.append(test_attn_version(v, seqlen=128))
    # for v in [attn_fwd_v3, attn_fwd_v4, attn_fwd_v5, attn_fwd_v6,
    #           attn_fwd_v7, attn_fwd_v8, attn_fwd_v8a]:
    #     results.append(test_attn_version(v, seqlen=1024))

    # NEW (one entry added; same test_attn_version harness):
    # results.append(test_attn_version(attn_fwd_v3_online, seqlen=1024))

    passed = sum(results)
    total = len(results)
    print(f"\n{passed}/{total} versions passed")
