# Upstream PR proposal: `attn_fwd_v3_online` for `aws-neuron/nki-samples`

## What this directory contains

A clean, additive-only PR shape for adding `attn_fwd_v3_online` to the
upstream `attention_fwd_performance` tutorial.

```
upstream_pr_proposal/
├── README.md                   ← this file
├── attention_kernels_patch.py  ← new kernel function in upstream voice
└── test_attention_patch.py     ← matching test entry in upstream voice
```

## Proposed PR structure (zero edits to existing v1-v8a)

The PR adds exactly one new `@nki.jit` function (`attn_fwd_v3_online`)
and one line to the test rotation. No edits to existing kernels.

**File: `src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py`**

Append the contents of `attention_kernels_patch.py` (the new
`attn_fwd_v3_online` function plus its docstring header) after
`attn_fwd_v8a`.

**File: `src/nki_samples/tutorials/attention_fwd_performance/test_attention.py`**

Two minimal additions to existing test_attention.py:

1. Extend the import to include the new kernel:
   ```python
   from attention_kernels import *
   ```
   (already a wildcard — picks up `attn_fwd_v3_online` automatically; no
    actual edit needed if upstream keeps the wildcard import).

2. Add one entry to the `__main__` test rotation:
   ```python
   results.append(test_attn_version(attn_fwd_v3_online, seqlen=1024))
   ```

That's the entire diff.

## What it adds for users

- **Online-softmax variant** of `attn_fwd_v3` — drop-in shape-compatible
  with v3 (same `(d_head=128, seqlen)` layout, same `(seqlen_q, d_head)`
  output, same `seqlen` constraints up to PMAX divisibility).
- **HBM working-memory reduction** of ~32x at seqlen=4096 / d_head=128 /
  fp32 — eliminates the `qk + norm_row + exp_row + scores` shared_hbm
  scratch buffers (each 64 MiB at that shape; 256 MiB total).
- **Architectural pedagogy**: the tutorial line currently shows seven
  variants (v3..v8a) all using two-pass softmax (separate row-max sweep
  and exp/sum sweep). `v3_online` is the first variant in the line to
  use the online-softmax pattern (running max + running sum + running
  output with per-tile rescale). It teaches the FlashAttention-class
  algorithmic shift on top of the existing tile-PSUM accumulation
  pedagogy.

## Numerical-equivalence guarantee

`attn_fwd_v3_online` produces output identical to `attn_fwd_v3` up to
FP32 rounding. The error bound is

    |out_online - out_offline|_∞  <=  8 · TILE_COUNT · ε_fp32 · max(|out|)

(worst-case, sound for adversarial inputs) and tighter under random
Gaussian inputs:

    P( ∀ N ≤ TILE_COUNT, |err(N)|_∞ ≤ √(2N · log(2/α)) · ε_fp32 · max(|out|) ) ≥ 1 - α

(Howard-Ramdas etaBetting concentration; ~17x tighter than the
worst-case bound at α=0.05 and TILE_COUNT=32).

Both bounds are proven in `../spec/AttnFwdV3Online.lean` (Lean 4),
gated on `Pythia.Numerical.{Softmax, Attention, Accelerator.QuantizedReduction}`
and `Pythia.Statistics.AnytimeValid` from
[Pythia PR #96](https://github.com/athanor-ai/pythia/pull/96).

The numerical error trivially satisfies the upstream test's
`np.allclose(atol=1e-2, rtol=1e-2)` tolerance — empirically the max
abs diff is ~1.5e-6 at seqlen=1024, ~6700x inside upstream tolerance.

## Filing the PR

The PR is the upstream maintainer team's call. This bundle ships the
shape so any downstream NKI user can lift `attention_kernels_patch.py`
into their own `attention_kernels.py` and pick up the v3_online
variant locally. Filing as upstream PR is mechanical from there:

1. Fork `aws-neuron/nki-samples`.
2. Branch off `main`.
3. Append `attention_kernels_patch.py` body to `attention_kernels.py`
   (after `attn_fwd_v8a`).
4. Append the one-line test rotation entry to
   `test_attention.py::__main__`.
5. Run `python3 test_attention.py` — confirms PASS for v3_online.
6. Open PR.

We have validated steps 5-6 via `verify_nki.py` in the parent
directory using `neuronxcc.nki.simulate_kernel` with full Trainium ISA
semantics; no Trainium hardware required for the verification.
