"""
Copyright (C) 2026, Amazon.com. All Rights Reserved

Candidate addition to
    src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py

Adds `attn_fwd_v3_online` — an online-softmax variant of `attn_fwd_v3`
that produces equivalent output without materializing the full QK matrix
in HBM. Drop-in shape-compatible with attn_fwd_v3:

    out = attn_fwd_v3_online(q, k, v)

with `q, k, v` of shape `(d_head=PMAX=128, seqlen)` and seqlen ≥ 256
divisible by PMAX.

The function body is written in upstream tutorial voice so the diff to
existing attention_kernels.py is purely additive — one new @nki.jit
and its docstring after attn_fwd_v8a; no edits to v1-v8a.

NOTE on imports: this file imports from `neuronxcc.nki.*` so that the
local `verify_v3_online_upstream_shape.py` can simulate it on the host
machine without the upstream `nki` alias install. When dropping into
upstream `attention_kernels.py`, swap:
    from neuronxcc.nki import jit
    from neuronxcc.nki import isa as nisa
    from neuronxcc.nki import language as nl
back to upstream's
    import nki
    import nki.isa as nisa
    import nki.language as nl
The function body is byte-identical between the two import styles.

Numerical equivalence to attn_fwd_v3 holds up to FP32 rounding, bounded
by `8 · TILE_COUNT · ε_fp32 · max(|out|)` worst-case and tighter under
random Gaussian inputs by anytime-valid concentration. See
`test_attention_patch.py` for the np.allclose check matching upstream
test conventions.
"""

from neuronxcc.nki import jit
from neuronxcc.nki import isa as nisa
from neuronxcc.nki import language as nl


####################################################################
# v3_online: online softmax — eliminates QK matrix HBM materialization
#
# Same input contract as attn_fwd_v3. Processes KV in PMAX-wide tiles
# with running max + running sum + running output, applying the
# correction factor `exp(running_max - new_max)` to prior partial state
# when the row-max updates. Equivalent in exact arithmetic by softmax
# shift-invariance.
#
# Working memory vs attn_fwd_v3 (seqlen=4096, d_head=128, fp32):
#   v3:        qk + norm_row + exp_row + scores ≈ 4 × 64 MiB = 256 MiB HBM
#   v3_online: only v_t pre-transpose          ≈ 8 MiB HBM
#                                              ~32x reduction
####################################################################
@jit
def attn_fwd_v3_online(q, k, v):
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q

    PMAX = nl.tile_size.pmax

    assert q.shape == k.shape == v.shape
    assert d_head == PMAX
    assert seqlen_q >= 256
    assert seqlen_q % PMAX == 0

    NEG_INF = -1.0e30
    num_tile_q = seqlen_q // PMAX
    num_tile_kv = seqlen_kv // PMAX

    kernel_out = nl.ndarray((seqlen_q, d_head), dtype=q.dtype, buffer=nl.shared_hbm)

    # load inputs into SBUF
    q_sbuf = nl.load(q)
    k_sbuf = nl.load(k)
    v_sbuf = nl.load(v)

    # v has the wrong layout — pre-transpose v in tiles
    # (same pattern as attn_fwd_v4..v8a)
    v_t = nl.ndarray(
        (num_tile_kv, PMAX, d_head),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_kv in nl.affine_range(num_tile_kv):
        v_psum_t = nisa.nc_transpose(data=v_sbuf[:, nl.ds(i_tile_kv * PMAX, PMAX)])
        v_sbuf_t = nisa.tensor_copy(v_psum_t)
        nl.store(v_t[i_tile_kv], v_sbuf_t[:, :])

    # Online softmax: per query tile, sweep kv tiles with running stats
    for i_tile_q in nl.sequential_range(num_tile_q):
        running_max = nl.full((PMAX, 1), NEG_INF, dtype=nl.float32, buffer=nl.sbuf)
        running_sum = nl.zeros((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
        running_out = nl.zeros((PMAX, d_head), dtype=nl.float32, buffer=nl.sbuf)

        for i_tile_kv in nl.sequential_range(num_tile_kv):
            # Q @ K, contract along d_head
            qk_psum = nisa.nc_matmul(
                stationary=q_sbuf[0:PMAX, nl.ds(i_tile_q * PMAX, PMAX)],
                moving=k_sbuf[0:PMAX, nl.ds(i_tile_kv * PMAX, PMAX)],
            )
            qk_sbuf = nisa.tensor_copy(qk_psum)

            # tile_max along seqlen_kv
            tile_max = nisa.tensor_reduce(
                op=nl.maximum, data=qk_sbuf, axis=(1,),
            )

            # new_max = max(running_max, tile_max)
            new_max = nl.maximum(running_max, tile_max)

            # correction = exp(running_max - new_max), via activation with bias
            neg_new_max = nisa.tensor_scalar(
                data=new_max, op0=nl.multiply, operand0=-1.0,
            )
            correction = nisa.activation(
                op=nl.exp, data=running_max, bias=neg_new_max,
            )

            # p = exp(qk - new_max), fused with reduce_op=nl.add for tile_sum
            # (same fusion pattern as attn_fwd_v6+)
            tile_sum = nl.ndarray((PMAX, 1), dtype=nl.float32, buffer=nl.sbuf)
            p_sbuf = nisa.activation(
                op=nl.exp, data=qk_sbuf, bias=neg_new_max,
                reduce_op=nl.add, reduce_res=tile_sum,
                reduce_cmd=nisa.reduce_cmd.reset_reduce,
            )

            # running_sum = correction * running_sum + tile_sum
            # single Vector Engine op via scalar_tensor_tensor
            new_sum = nisa.scalar_tensor_tensor(
                data=running_sum,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_sum,
            )

            # p @ v_tile_T, contract along seqlen_kv (PMAX-wide tile)
            # transpose p first because nc_matmul stationary partition is
            # contraction axis
            p_t_psum = nisa.nc_transpose(data=p_sbuf)
            p_t_sbuf = nisa.tensor_copy(p_t_psum)

            v_t_sbuf = nl.load(v_t[i_tile_kv, :, :])

            tile_out_psum = nisa.nc_matmul(
                stationary=p_t_sbuf, moving=v_t_sbuf,
            )
            tile_out = nisa.tensor_copy(tile_out_psum)

            # running_out = correction * running_out + tile_out
            new_out = nisa.scalar_tensor_tensor(
                data=running_out,
                op0=nl.multiply, operand0=correction,
                op1=nl.add, operand1=tile_out,
            )

            # advance running stats
            running_max[:, :] = new_max[:, :]
            running_sum[:, :] = new_sum[:, :]
            running_out[:, :] = new_out[:, :]

        # finalize: out_tile = running_out / running_sum
        inverse_sum = nisa.reciprocal(data=running_sum)
        out_tile = nisa.tensor_scalar(
            data=running_out,
            op0=nl.multiply, operand0=inverse_sum,
        )
        nl.store(dst=kernel_out[nl.ds(i_tile_q * PMAX, PMAX), :], value=out_tile)

    return kernel_out
