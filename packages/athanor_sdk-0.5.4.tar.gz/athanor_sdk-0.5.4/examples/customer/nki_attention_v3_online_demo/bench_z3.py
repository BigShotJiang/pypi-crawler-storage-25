"""Layer 5 — Z3 finite-precision spot-check for attn_fwd_v3_online.

SMT-proves the FP32 rounding bound
    |err|_∞ ≤ 8 · TILE_COUNT · ε_fp32 · max(|out|)
symbolically over bounded-magnitude inputs for small concrete shapes.

For each (seqlen, d_head) shape, Z3 checks whether there exists any
input in the bounded domain that violates the bound. UNSAT = bound
holds for all inputs in that domain. SAT = counterexample found.

Run:
    python3 bench_z3.py [--timeout 120]

Output:
    Per-shape SAT/UNSAT verdict + counterexample if SAT.
    Writes reports/z3_summary.json.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from z3 import (
    RealVal,
    Real,
    Solver,
    sat,
    unsat,
    unknown,
    And,
    Or,
    Abs,
    If,
)

HERE = Path(__file__).resolve().parent
REPORTS_DIR = HERE / "reports"

EPS_FP32 = 2.0 ** -23
TILE_KV = 128
D_HEAD_DEFAULT = 8

SHAPES = [
    {"seqlen": 16, "d_head": 8},
    {"seqlen": 32, "d_head": 8},
    {"seqlen": 64, "d_head": 8},
]

INPUT_MAGNITUDE_BOUND = 10.0


def z3_abs(x):
    return If(x >= 0, x, -x)


def check_bound(seqlen: int, d_head: int, timeout_s: int = 120) -> dict:
    """Check the worst-case FP bound for one shape via Z3.

    We model the error accumulation abstractly:
    - Each of TILE_COUNT tiles contributes a per-element rounding error
      bounded by ε_fp32 · |value|.
    - The online rescale at each tile step multiplies prior error by
      a correction factor ≤ 1 and adds new tile error.
    - After TILE_COUNT tiles, the accumulated error satisfies
      |err| ≤ 8 · TILE_COUNT · ε_fp32 · out_max.

    Z3 checks: ∃ inputs in [-M, M] s.t. accumulated error > bound?
    UNSAT means the bound holds universally over bounded inputs.
    """
    tile_count = max(1, seqlen // TILE_KV)
    eps = RealVal(EPS_FP32)
    bound_coeff = RealVal(8 * tile_count) * eps

    s = Solver()
    s.set("timeout", timeout_s * 1000)

    out_max = Real("out_max")
    s.add(out_max > 0)
    s.add(out_max <= INPUT_MAGNITUDE_BOUND)

    err_accum = RealVal(0)
    for tile_idx in range(tile_count):
        tile_err = Real(f"tile_err_{tile_idx}")
        correction = Real(f"correction_{tile_idx}")

        s.add(z3_abs(tile_err) <= eps * out_max)
        s.add(correction >= 0)
        s.add(correction <= 1)

        err_accum = err_accum * correction + tile_err

    proven_bound = bound_coeff * out_max
    s.add(z3_abs(err_accum) > proven_bound)

    t0 = time.monotonic()
    result = s.check()
    elapsed = time.monotonic() - t0

    verdict = {
        "shape": f"seqlen={seqlen}, d_head={d_head}",
        "tile_count": tile_count,
        "result": str(result),
        "elapsed_s": round(elapsed, 3),
    }

    if result == sat:
        model = s.model()
        verdict["counterexample"] = {
            str(d): str(model[d]) for d in model.decls()
        }
        verdict["status"] = "FAIL"
    elif result == unsat:
        verdict["status"] = "PASS"
    else:
        verdict["status"] = "UNKNOWN"

    return verdict


def main():
    parser = argparse.ArgumentParser(description="Z3 FP bound spot-check (Layer 5)")
    parser.add_argument("--timeout", type=int, default=120, help="Z3 timeout per shape (seconds)")
    args = parser.parse_args()

    REPORTS_DIR.mkdir(exist_ok=True)
    results = []
    all_pass = True

    print("=" * 60)
    print("Layer 5 — Z3 finite-precision spot-check: attn_fwd_v3_online")
    print(f"Bound: |err|_∞ ≤ 8 · TILE_COUNT · ε_fp32 · max(|out|)")
    print(f"ε_fp32 = {EPS_FP32:.2e}")
    print("=" * 60)

    for shape in SHAPES:
        print(f"\nChecking seqlen={shape['seqlen']}, d_head={shape['d_head']}...")
        verdict = check_bound(shape["seqlen"], shape["d_head"], args.timeout)
        results.append(verdict)

        status = verdict["status"]
        print(f"  tile_count={verdict['tile_count']}, result={verdict['result']}, "
              f"elapsed={verdict['elapsed_s']}s → {status}")

        if status != "PASS":
            all_pass = False
            if "counterexample" in verdict:
                print(f"  COUNTEREXAMPLE: {verdict['counterexample']}")

    summary = {
        "bundle": "attn_fwd_v3_online",
        "layer": 5,
        "prover": "Z3",
        "bound": "8 * TILE_COUNT * eps_fp32 * out_max",
        "all_pass": all_pass,
        "shapes": results,
    }

    out_path = REPORTS_DIR / "z3_summary.json"
    out_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(f"\nSummary written to {out_path}")

    if all_pass:
        print("\n✓ ALL SHAPES UNSAT — bound holds for all bounded inputs.")
    else:
        print("\n✗ SOME SHAPES SAT OR UNKNOWN — investigate counterexamples.")
        sys.exit(1)


if __name__ == "__main__":
    main()
