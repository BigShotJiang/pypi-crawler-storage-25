"""Static op-count + theoretical cycle-cost analysis for `attn_fwd_v3`
(offline, mirror of upstream) vs `attn_fwd_v3_online` (this bundle).

Cycle costs come from the NKI ISA reference (cost annotations per op).
This is a deterministic analysis — no simulator timing involved. The
output is a side-by-side comparison of:

    - Tensor Engine (TE) cycles: dominated by `nisa.nc_matmul`
    - Vector Engine (VE) cycles: `tensor_reduce`, `tensor_scalar`, etc.
    - Scalar Engine (SE) cycles: `activation`, `tensor_copy` from PSUM
    - HBM round-trip volume: bytes through `nl.load` + `nl.store`

For Trainium hardware, the dominant bottleneck is typically TE (matmul)
or HBM bandwidth, depending on the kernel's arithmetic intensity. Both
are reported.

Numbers are upper-bound static estimates — actual hardware behavior
benefits from pipelining and parallel-engine overlap that this
analysis does not model. Treat as algorithmic floor, not exact wall-
clock.

Usage:
    python3 bench.py [--seqlen 4096]

References:
    NKI ISA cost annotations:
    https://awsdocs-neuron.readthedocs-hosted.com/en/latest/nki/api/nki.isa.html
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


# ISA cost constants (from NKI ISA reference, FP32 path).
# Shape conventions: (P_partition, F_free) where P ≤ 128 = PMAX.
def cycles_nc_matmul_fp32(p: int, f_stationary: int, f_moving: int) -> int:
    # `4 * max(min(64, N_stationary), N_moving)` for FP32.
    return 4 * max(min(64, f_stationary), f_moving)


def cycles_tensor_copy(n: int) -> int:
    # Approximate: 1 cycle per element per partition, from Scalar Engine.
    return n


def cycles_tensor_reduce(n: int) -> int:
    # ~N cycles on Vector Engine.
    return n


def cycles_tensor_scalar(n: int) -> int:
    # ~N cycles on Vector Engine for the standard 1-op form. 2N for
    # the dual-op form.
    return 2 * n


def cycles_activation(n: int) -> int:
    # ~N cycles on Scalar Engine (with optional fused reduce).
    return n


def cycles_nc_transpose(p: int, f: int) -> int:
    # Implemented via nc_matmul with identity, so ~ matmul cost.
    return 4 * max(min(64, p), f)


def cycles_reciprocal(n: int) -> int:
    # ~N cycles on Vector Engine.
    return n


def cycles_scalar_tensor_tensor(n: int) -> int:
    # 2*N cycles on Vector Engine.
    return 2 * n


def hbm_bytes_load(p: int, f: int, dtype_bytes: int = 4) -> int:
    return p * f * dtype_bytes


def hbm_bytes_store(p: int, f: int, dtype_bytes: int = 4) -> int:
    return p * f * dtype_bytes


PMAX = 128
FMAX_STATIONARY = 128
FMAX_MOVING = 512


def cost_v3_baseline(seqlen: int, d_head: int = 128) -> dict:
    """Mirror of upstream `attn_fwd_v3`."""
    num_tile_q_FMAX = seqlen // FMAX_STATIONARY
    num_tile_kv_FMAX = seqlen // FMAX_MOVING
    num_tile_q_PMAX = seqlen // PMAX
    num_tile_kv_PMAX = seqlen // PMAX

    te_cycles = 0
    ve_cycles = 0
    se_cycles = 0
    hbm_bytes = 0

    # Initial loads of Q, K, V into SBUF
    hbm_bytes += 3 * hbm_bytes_load(d_head, seqlen)

    # 1. QK matmul: nc_matmul (FMAX_STATIONARY, FMAX_MOVING) per (q-tile, kv-tile)
    qk_matmul_count = num_tile_q_FMAX * num_tile_kv_FMAX
    te_cycles += qk_matmul_count * cycles_nc_matmul_fp32(PMAX, FMAX_STATIONARY, FMAX_MOVING)
    se_cycles += qk_matmul_count * cycles_tensor_copy(FMAX_MOVING)
    hbm_bytes += qk_matmul_count * hbm_bytes_store(PMAX, FMAX_MOVING)

    # 2. Row-max sweep: dma_copy + tensor_reduce per (q-tile, kv-tile)
    row_max_iters = num_tile_q_PMAX * num_tile_kv_FMAX
    hbm_bytes += row_max_iters * hbm_bytes_load(PMAX, FMAX_MOVING)
    ve_cycles += row_max_iters * cycles_tensor_reduce(FMAX_MOVING)
    ve_cycles += num_tile_q_PMAX * cycles_tensor_reduce(num_tile_kv_FMAX)

    # 3. Subtract row-max: dma_copy + tensor_scalar per (q-tile, kv-tile)
    sub_iters = num_tile_q_PMAX * num_tile_kv_FMAX
    hbm_bytes += sub_iters * hbm_bytes_load(PMAX, FMAX_MOVING)
    ve_cycles += sub_iters * cycles_tensor_scalar(FMAX_MOVING)
    hbm_bytes += num_tile_q_PMAX * hbm_bytes_store(PMAX, seqlen)

    # 4. Exp activation: per query tile
    se_cycles += num_tile_q_PMAX * cycles_activation(seqlen)
    hbm_bytes += num_tile_q_PMAX * (
        hbm_bytes_load(PMAX, seqlen) + hbm_bytes_store(PMAX, seqlen)
    )

    # 5. Sum row, reciprocal, divide-then-store scores
    ve_cycles += num_tile_q_PMAX * cycles_tensor_reduce(seqlen)
    ve_cycles += cycles_reciprocal(num_tile_q_PMAX)
    ve_cycles += num_tile_q_PMAX * cycles_tensor_scalar(seqlen)
    hbm_bytes += num_tile_q_PMAX * (
        hbm_bytes_load(PMAX, seqlen) + hbm_bytes_store(PMAX, seqlen)
    )

    # 6. Pre-transpose v
    te_cycles += num_tile_kv_PMAX * cycles_nc_transpose(PMAX, PMAX)
    se_cycles += num_tile_kv_PMAX * cycles_tensor_copy(PMAX)
    hbm_bytes += num_tile_kv_PMAX * hbm_bytes_store(PMAX, d_head)

    # 7. Transpose scores per (q-tile, kv-tile)
    scores_t_count = num_tile_q_PMAX * num_tile_kv_PMAX
    te_cycles += scores_t_count * cycles_nc_transpose(PMAX, PMAX)
    se_cycles += scores_t_count * cycles_tensor_copy(PMAX)
    hbm_bytes += scores_t_count * (
        hbm_bytes_load(PMAX, PMAX) + hbm_bytes_store(PMAX, PMAX)
    )

    # 8. Final attn_out matmul + store
    attn_matmul_count = num_tile_q_PMAX * num_tile_kv_PMAX
    te_cycles += attn_matmul_count * cycles_nc_matmul_fp32(PMAX, PMAX, PMAX)
    hbm_bytes += attn_matmul_count * (
        hbm_bytes_load(PMAX, PMAX) + hbm_bytes_load(PMAX, d_head)
    )
    se_cycles += num_tile_q_PMAX * cycles_tensor_copy(d_head)
    hbm_bytes += num_tile_q_PMAX * hbm_bytes_store(PMAX, d_head)

    return {
        "kernel": "attn_fwd_v3 (upstream baseline)",
        "te_cycles": te_cycles,
        "ve_cycles": ve_cycles,
        "se_cycles": se_cycles,
        "hbm_bytes": hbm_bytes,
        "hbm_mib": hbm_bytes / (1024**2),
        "qk_matmul_count": qk_matmul_count,
        "attn_matmul_count": attn_matmul_count,
    }


def cost_v3_online(seqlen: int, d_head: int = 128) -> dict:
    """Online-softmax variant from this bundle (improved_nki.py)."""
    num_tile_q = seqlen // PMAX
    num_tile_kv = seqlen // PMAX

    te_cycles = 0
    ve_cycles = 0
    se_cycles = 0
    hbm_bytes = 0

    # Initial Q, K, V loads
    hbm_bytes += 3 * hbm_bytes_load(d_head, seqlen)

    # Pre-transpose v (same as baseline)
    te_cycles += num_tile_kv * cycles_nc_transpose(PMAX, PMAX)
    se_cycles += num_tile_kv * cycles_tensor_copy(PMAX)
    hbm_bytes += num_tile_kv * hbm_bytes_store(PMAX, d_head)

    # Per-(q-tile, kv-tile) online update
    for _ in range(num_tile_q):
        # Initialize running stats: lightweight, count once
        for _ in range(num_tile_kv):
            # qk matmul
            te_cycles += cycles_nc_matmul_fp32(PMAX, PMAX, PMAX)
            se_cycles += cycles_tensor_copy(PMAX)
            # tile_max via tensor_reduce
            ve_cycles += cycles_tensor_reduce(PMAX)
            # new_max via nl.maximum (treat as 1 VE op on (PMAX, 1))
            ve_cycles += PMAX
            # neg_new_max via tensor_scalar
            ve_cycles += cycles_tensor_scalar(1)  # (PMAX, 1) tile
            # correction via activation
            se_cycles += cycles_activation(1)
            # p + tile_sum via fused activation
            se_cycles += cycles_activation(PMAX)
            # new_sum via scalar_tensor_tensor on (PMAX, 1)
            ve_cycles += cycles_scalar_tensor_tensor(1)
            # transpose p
            te_cycles += cycles_nc_transpose(PMAX, PMAX)
            se_cycles += cycles_tensor_copy(PMAX)
            # load v_tile
            hbm_bytes += hbm_bytes_load(PMAX, d_head)
            # tile_out matmul
            te_cycles += cycles_nc_matmul_fp32(PMAX, PMAX, PMAX)
            se_cycles += cycles_tensor_copy(d_head)
            # new_out via scalar_tensor_tensor on (PMAX, d_head)
            ve_cycles += cycles_scalar_tensor_tensor(d_head)
            # advance running stats (3 tensor_copy ops, lightweight)
            se_cycles += cycles_tensor_copy(1) + cycles_tensor_copy(1) + cycles_tensor_copy(d_head)

        # Finalize per query tile
        ve_cycles += cycles_reciprocal(1)
        ve_cycles += cycles_tensor_scalar(d_head)
        hbm_bytes += hbm_bytes_store(PMAX, d_head)

    return {
        "kernel": "attn_fwd_v3_online (this bundle)",
        "te_cycles": te_cycles,
        "ve_cycles": ve_cycles,
        "se_cycles": se_cycles,
        "hbm_bytes": hbm_bytes,
        "hbm_mib": hbm_bytes / (1024**2),
        "qk_matmul_count": num_tile_q * num_tile_kv,
        "attn_matmul_count": num_tile_q * num_tile_kv,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seqlen", type=int, default=4096)
    parser.add_argument("--d-head", type=int, default=128)
    args = parser.parse_args(argv)

    base = cost_v3_baseline(args.seqlen, args.d_head)
    online = cost_v3_online(args.seqlen, args.d_head)

    rows = []
    for label in ("te_cycles", "ve_cycles", "se_cycles", "hbm_bytes"):
        b = base[label]
        o = online[label]
        ratio = b / o if o else float("inf")
        rows.append((label, b, o, ratio))

    print(f"## Static op-count + cycle-cost analysis")
    print(f"   seqlen={args.seqlen}  d_head={args.d_head}")
    print()
    print(f"  {'metric':<20} {'baseline (v3)':>15} {'online (v3_online)':>20} {'ratio':>10}")
    print(f"  {'-'*20} {'-'*15} {'-'*20} {'-'*10}")
    for label, b, o, ratio in rows:
        if label == "hbm_bytes":
            print(f"  {label:<20} {b/1024**2:>13.2f} MiB {o/1024**2:>18.2f} MiB {ratio:>9.2f}x")
        else:
            print(f"  {label:<20} {b:>15,} {o:>20,} {ratio:>9.2f}x")
    print()
    print(f"  matmul counts: baseline qk={base['qk_matmul_count']} attn={base['attn_matmul_count']} | online qk={online['qk_matmul_count']} attn={online['attn_matmul_count']}")
    print()
    print("  Notes:")
    print("    - Static estimates from NKI ISA cost annotations (FP32 path).")
    print("    - Real hardware benefits from pipelining + parallel-engine overlap not modeled here.")
    print("    - HBM bandwidth (bytes) is the dominant bottleneck for memory-bound kernels.")
    print("    - Tensor Engine (matmul) is the dominant bottleneck for compute-bound kernels.")

    out = {
        "seqlen": args.seqlen,
        "d_head": args.d_head,
        "baseline": base,
        "online": online,
        "ratios": {label: ratio for label, _, _, ratio in rows},
    }
    Path(__file__).resolve().parent.joinpath(
        "reports", "bench_summary.json"
    ).write_text(json.dumps(out, indent=2))

    return 0


if __name__ == "__main__":
    sys.exit(main())
