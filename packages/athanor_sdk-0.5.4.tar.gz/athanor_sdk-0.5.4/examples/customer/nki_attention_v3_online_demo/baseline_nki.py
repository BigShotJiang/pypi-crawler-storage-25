"""Real `@nki.jit` baseline: mirror of upstream `attn_fwd_v3` from
`aws-neuron/nki-samples/src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py`.

Used by `verify_nki.py` as the equivalence target for the online-softmax
improvement (`improved_nki.py`). Runs through `nki.simulate_kernel` —
no Trainium hardware required.

Algorithm (offline softmax, two-pass over kv tiles):
    1. for each (i_tile_q, i_tile_kv): compute qk_tile via nc_matmul,
       store to HBM. Full (seqlen_q, seqlen_kv) QK matrix materialized.
    2. for each tile_q: scan all kv-tiles to compute row_max.
    3. for each tile_q: scan all kv-tiles, subtract row_max, exp,
       accumulate row_sum.
    4. for each tile_q: scan all kv-tiles, divide exp by row_sum to
       produce scores.
    5. transpose scores; transpose v; nc_matmul scores @ v_t into
       attn_out PSUM, store back to HBM.

The full QK materialization is the working-memory cost online softmax
eliminates. Identity-equal in exact arithmetic; equal up to FP32
rounding bound on real hardware.
"""
from __future__ import annotations

import neuronxcc.nki as nki
import neuronxcc.nki.isa as nisa
import neuronxcc.nki.language as nl


@nki.jit
def attn_fwd_v3_baseline(q, k, v):
    """Mirror of upstream `attn_fwd_v3` — offline softmax, full QK in HBM.

    Inputs have shape (d_head, seqlen) — the upstream tutorial's layout.
    Returns (seqlen_q, d_head) attention output.
    """
    d_head, seqlen_q = q.shape
    seqlen_kv = seqlen_q

    PMAX = nl.tile_size.pmax
    FMAX_STATIONARY = nl.tile_size.gemm_stationary_fmax
    FMAX_MOVING = nl.tile_size.gemm_moving_fmax

    assert q.shape == k.shape == v.shape
    assert d_head == PMAX
    assert seqlen_q >= 512

    kernel_out = nl.ndarray((seqlen_q, d_head), dtype=q.dtype, buffer=nl.shared_hbm)

    q_sbuf = nl.load(q)
    k_sbuf = nl.load(k)
    v_sbuf = nl.load(v)

    qk = nl.ndarray(
        (seqlen_q // PMAX, seqlen_kv // FMAX_MOVING, PMAX, FMAX_MOVING),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_q in nl.affine_range(seqlen_q // FMAX_STATIONARY):
        for i_tile_kv in nl.affine_range(seqlen_kv // FMAX_MOVING):
            qk_psum = nisa.nc_matmul(
                stationary=q_sbuf[0:PMAX, nl.ds(i_tile_q * FMAX_STATIONARY, FMAX_STATIONARY)],
                moving=k_sbuf[0:PMAX, nl.ds(i_tile_kv * FMAX_MOVING, FMAX_MOVING)],
            )
            qk_sbuf = nisa.tensor_copy(qk_psum)
            nisa.dma_copy(dst=qk[i_tile_q, i_tile_kv, :, :], src=qk_sbuf)

    row_max = nl.ndarray((PMAX, seqlen_q // PMAX), dtype=nl.float32, buffer=nl.sbuf)
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        row_max_kv = nl.ndarray((PMAX, seqlen_kv // FMAX_MOVING), dtype=nl.float32, buffer=nl.sbuf)
        for i_tile_kv in nl.affine_range(seqlen_kv // FMAX_MOVING):
            qk_tile = nl.ndarray((PMAX, FMAX_MOVING), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=qk_tile, src=qk[i_tile_q, i_tile_kv, :, :])
            tile_red = nisa.tensor_reduce(op=nl.maximum, data=qk_tile, axis=(1,))
            row_max_kv[:, nl.ds(i_tile_kv, 1)] = tile_red
        row_red = nisa.tensor_reduce(op=nl.maximum, data=row_max_kv[:, :], axis=(1,))
        row_max[:, nl.ds(i_tile_q, 1)] = row_red

    norm_row = nl.ndarray(
        (seqlen_q // PMAX, PMAX, seqlen_kv),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        norm_buf = nl.ndarray((PMAX, seqlen_kv), dtype=nl.float32, buffer=nl.sbuf)
        for i_tile_kv in nl.affine_range(seqlen_kv // FMAX_MOVING):
            qk_tile_sub = nl.ndarray((PMAX, FMAX_MOVING), dtype=nl.float32, buffer=nl.sbuf)
            nisa.dma_copy(dst=qk_tile_sub, src=qk[i_tile_q, i_tile_kv, :, :])
            sub_res = nisa.tensor_scalar(
                data=qk_tile_sub, op0=nl.subtract,
                operand0=row_max[:, nl.ds(i_tile_q, 1)],
            )
            norm_buf[:, nl.ds(i_tile_kv * FMAX_MOVING, FMAX_MOVING)] = sub_res
        nl.store(norm_row[i_tile_q], norm_buf[:, :])

    exp_row = nl.ndarray(
        (seqlen_q // PMAX, PMAX, seqlen_kv),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        norm_buf = nl.load(norm_row[i_tile_q])
        exp_buf = nisa.activation(op=nl.exp, data=norm_buf)
        nl.store(exp_row[i_tile_q], exp_buf[:, :])

    sum_row = nl.ndarray((PMAX, seqlen_q // PMAX), dtype=nl.float32, buffer=nl.sbuf)
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        exp_buf = nl.load(exp_row[i_tile_q])
        s_red = nisa.tensor_reduce(op=nl.add, data=exp_buf, axis=(1,))
        sum_row[:, nl.ds(i_tile_q, 1)] = s_red

    inverse_sum_row = nisa.reciprocal(data=sum_row)

    scores = nl.ndarray(
        (seqlen_q // PMAX, PMAX, seqlen_kv),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        exp_buf = nl.load(exp_row[i_tile_q])
        scores_buf = nisa.tensor_scalar(
            data=exp_buf,
            op0=nl.multiply, operand0=inverse_sum_row[:, i_tile_q],
        )
        nl.store(scores[i_tile_q], scores_buf[:, :])

    v_t = nl.ndarray(
        (seqlen_kv // PMAX, PMAX, d_head),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_kv in nl.affine_range(seqlen_kv // PMAX):
        v_psum_t = nisa.nc_transpose(data=v_sbuf[:, nl.ds(i_tile_kv * PMAX, PMAX)])
        v_sbuf_t = nisa.tensor_copy(v_psum_t)
        nl.store(v_t[i_tile_kv], v_sbuf_t[:, :])

    scores_t = nl.ndarray(
        (seqlen_kv // PMAX, seqlen_q // PMAX, PMAX, PMAX),
        dtype=nl.float32, buffer=nl.shared_hbm,
    )
    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        for i_tile_kv in nl.affine_range(seqlen_kv // PMAX):
            scores_buf = nl.load(scores[i_tile_q, :, nl.ds(i_tile_kv * PMAX, PMAX)])
            scores_psum_t = nisa.nc_transpose(data=scores_buf)
            scores_sbuf_t = nisa.tensor_copy(scores_psum_t)
            nl.store(scores_t[i_tile_kv, i_tile_q, :, :], scores_sbuf_t)

    for i_tile_q in nl.affine_range(seqlen_q // PMAX):
        attn_out_psum = nl.zeros((PMAX, PMAX), dtype=nl.float32, buffer=nl.psum)
        for i_tile_kv in nl.affine_range(seqlen_kv // PMAX):
            scores_sbuf_t = nl.load(scores_t[i_tile_kv, i_tile_q, :, :])
            v_sbuf_t = nl.load(v_t[i_tile_kv, :, :])
            attn_out_psum += nisa.nc_matmul(
                stationary=scores_sbuf_t,
                moving=v_sbuf_t,
            )
        attn_out = nisa.tensor_copy(attn_out_psum)
        nl.store(dst=kernel_out[nl.ds(i_tile_q * PMAX, PMAX), :], value=attn_out[:, :])

    return kernel_out
