"""FP64 reference attention — the ground truth both baseline and improved
variants are differentially tested against.

Computation: standard scaled dot-product attention, no causal mask, no
masking. Pure numpy in float64 for maximum precision.
"""
from __future__ import annotations

import numpy as np


def reference_attention(q: np.ndarray, k: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Compute attention(Q, K, V) in float64.

    Conventions match aws-neuron/nki-samples attn_fwd_v3:
    - q, k shape: (d_head, seqlen)
    - v shape: (d_head, seqlen)
    - Output: (seqlen, d_head)

    Computation:
        QK = Q.T @ K              # (seqlen, seqlen)
        row_max = max(QK, axis=1)
        QK_norm = QK - row_max[:, None]
        exp_QK = exp(QK_norm)
        row_sum = sum(exp_QK, axis=1)
        P = exp_QK / row_sum[:, None]
        out = P @ V.T             # (seqlen, d_head)

    Caller convention: pass in float32 inputs; this function casts to
    float64 internally and returns float32 (the reference value that
    the FP32 kernel implementations approximate).
    """
    q64 = q.astype(np.float64)
    k64 = k.astype(np.float64)
    v64 = v.astype(np.float64)

    qk = q64.T @ k64                                # (seqlen, seqlen)
    row_max = np.max(qk, axis=1, keepdims=True)     # (seqlen, 1)
    qk_norm = qk - row_max
    exp_qk = np.exp(qk_norm)
    row_sum = np.sum(exp_qk, axis=1, keepdims=True) # (seqlen, 1)
    p = exp_qk / row_sum                            # (seqlen, seqlen)
    out = p @ v64.T                                 # (seqlen, d_head)
    return out.astype(np.float32)
