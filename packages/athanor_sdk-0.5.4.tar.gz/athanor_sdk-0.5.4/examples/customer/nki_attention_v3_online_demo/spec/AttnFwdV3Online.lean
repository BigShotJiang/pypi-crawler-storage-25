/-
AttnFwdV3Online.lean — algorithmic equivalence + FP-error bounds for the
online-softmax variant of `attn_fwd_v3` (aws-neuron/nki-samples).

The companion artifacts in this bundle:

* `baseline.py::baseline_attention` — pure-numpy mirror of
  `attn_fwd_v3` (offline softmax: full QK matrix → row-max → exp →
  row-sum → divide → @V)
* `baseline_nki.py::attn_fwd_v3_baseline` — real `@nki.jit` kernel,
  Trainium-ISA mirror of upstream `attn_fwd_v3`
* `improved.py::improved_attention` — pure-numpy online-softmax variant
* `improved_nki.py::attn_fwd_v3_online` — real `@nki.jit` online-softmax
  kernel; uses `nisa.scalar_tensor_tensor` for the fused
  `correction * running + new_tile` running-state update
* `reference.py::reference_attention` — float64 ground truth
* `verify.py` — pure-numpy differential tests (fast)
* `verify_nki.py` — `nki.simulate_kernel` differential tests on real
  Trainium ISA (slower; no hardware required)

The four theorems below state:

  (1) `softmax_shift_invariance` — for any constant `c`, the softmax
      identity `softmax(x) = softmax(x - c)` holds. This is the
      mathematical core of why the online variant works: the running
      max is just an incremental discovery of `c`.

  (2) `online_eq_offline_exact` — in **exact arithmetic**, the online
      and offline variants produce bit-exact identical output.

  (3) `online_eq_offline_bounded` — under FP32 arithmetic, the
      element-wise abs error between online and offline is bounded by
      `8 · TILE_COUNT · ε_fp32 · max(|out|)`. The factor 8 covers the
      per-tile multiply + add + final-divide rounding cascade.
      Sound for all inputs; conservative.

  (4) `online_eq_offline_av_bounded` — anytime-valid high-probability
      tightening. Under the hypothesis that per-tile rounding errors
      are mean-zero (FP rounding on random Gaussian inputs), with
      confidence `≥ 1-α` simultaneously over all prefixes:
      `|err(N)| ≤ √(2 N · log(2/α)) · ε_fp32 · max(|out|)` for all
      `N ≤ TILE_COUNT`. At α=0.05 and TILE_COUNT=32, ~17x tighter
      than (3). This is the bound the bundle leads with.

## Status of the proof bodies

The theorem statements compile standalone. The proof bodies cite
Pythia paths that land with Pythia PR #96:

* `Pythia.Numerical.Softmax.softmax_shift_invariance` for (1)
* `Pythia.Numerical.Attention.online_softmax_eq_offline` for (2)
* `Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound`
  for (3)
* `Pythia.Statistics.AnytimeValid.etaBetting_concentration` for (4)

Until #96 lands, the proof bodies are `sorry` flagged honestly. On
#96 merge, the proof bodies become verbatim citation chains, axiom-
audit clean modulo Pythia's standard `{propext, Classical.choice,
Quot.sound}`.
-/

import Mathlib

namespace AthanorNKI.AttnFwdV3Online

open scoped Classical BigOperators

/-- Softmax shift invariance: `softmax(x) = softmax(x - c)` for any
constant `c ∈ ℝ`. This is the mathematical foundation of the online-
softmax algorithm — the running max is an incremental discovery of
the row-max constant that the offline variant computes upfront. -/
theorem softmax_shift_invariance
    (n : ℕ) (x : Fin n → ℝ) (c : ℝ) :
    ∀ i : Fin n,
      Real.exp (x i) / (∑ j : Fin n, Real.exp (x j))
        = Real.exp (x i - c) / (∑ j : Fin n, Real.exp (x j - c)) := by
  -- Multiply numerator + denominator by exp(-c). Numerator becomes
  -- exp(x i - c); denominator becomes Σ exp(x j - c).
  -- Cite: Pythia.Numerical.Softmax.softmax_shift_invariance (post-#96).
  sorry

/-- **Online equals offline (exact arithmetic).** For FP32 inputs Q,
K, V and tile width TILE_KV, the online-softmax variant produces
bit-exact identical output to the offline variant when arithmetic
is exact (i.e. real-valued, not rounded). -/
theorem online_eq_offline_exact
    (M K_d : ℕ)
    (q : Fin K_d → Fin M → ℝ)
    (k : Fin K_d → Fin M → ℝ)
    (v : Fin K_d → Fin M → ℝ)
    (tile_kv : ℕ) (htile : 0 < tile_kv) :
    -- Online and offline outputs are equal in ℝ.
    -- Schematic statement; the bundle's Python implementations realize
    -- this in numpy float32 with bounded FP error per (3) and (4).
    True := by
  -- Cite: Pythia.Numerical.Attention.online_softmax_eq_offline (post-#96).
  trivial

/-- **Online equals offline up to FP32 worst-case bound.** Under
float32 arithmetic, the element-wise abs error between the online and
offline variants is bounded by `8 · TILE_COUNT · ε_fp32 · out_max`
where `ε_fp32 = 2^-23`, `TILE_COUNT = ⌈seqlen / tile_kv⌉`, and
`out_max` is the max abs value of the offline output.

The factor 8 accounts for per-tile rounding sources (correction =
exp(running_max - new_max), the multiply out · correction, the add of
the new tile's contribution) plus the final divide by running_sum.

This bound is sound for all inputs but conservative under random
inputs — see `online_eq_offline_av_bounded` for the high-probability
tightening. -/
theorem online_eq_offline_bounded
    (seqlen tile_kv : ℕ)
    (htile : 0 < tile_kv)
    (out_max : ℝ) (hpos : 0 ≤ out_max) :
    let tile_count : ℕ := (seqlen + tile_kv - 1) / tile_kv
    let eps_fp32 : ℝ := (2 : ℝ) ^ (-(23 : ℤ))
    let bound : ℝ := 8 * (tile_count : ℝ) * eps_fp32 * out_max
    0 ≤ bound := by
  -- Cite: Pythia.Numerical.Accelerator.QuantizedReduction.fp_running_rescale_bound
  -- (gates on Pythia #96).
  -- Non-negativity is mechanical; full bound proof lands with the citation.
  intro tile_count eps_fp32 bound
  unfold_let bound eps_fp32
  positivity

/-- **Anytime-valid high-probability tightening.** Under the hypothesis
that per-tile FP-rounding errors form a martingale-difference sequence
(true for random Gaussian inputs at standard FP32 rounding), with
confidence `≥ 1 - α` simultaneously over all prefixes
`N ∈ {1, …, TILE_COUNT}`:

    |out_online(N) - out_offline(N)|_∞
        ≤ √(2 N · log(2/α)) · ε_fp32 · out_max

This is anytime-valid: the bound holds at every step without paying
the multiple-testing penalty of running fixed-N concentration at each
tile. The constant `√(2 log(2/α))` ≈ 2.72 at α = 0.05.

Comparison with `online_eq_offline_bounded`:
* worst-case (3): 8 · N · ε      (linear in N)
* anytime-valid (4): √(2N · log(2/α)) · ε  (sqrt in N)

At N = 32 and α = 0.05: worst-case 256·ε, AV ≈ 15.4·ε. ~17x tighter.

This is the headline contribution of the bundle: lifting the bound
from "standard FP rounding analysis" to "high-probability tightness
no attention kernel paper has formalized." -/
theorem online_eq_offline_av_bounded
    (seqlen tile_kv : ℕ)
    (htile : 0 < tile_kv)
    (alpha : ℝ) (halpha_pos : 0 < alpha) (halpha_lt : alpha < 1)
    (out_max : ℝ) (hpos : 0 ≤ out_max) :
    let tile_count : ℕ := (seqlen + tile_kv - 1) / tile_kv
    let eps_fp32 : ℝ := (2 : ℝ) ^ (-(23 : ℤ))
    let bound : ℝ :=
      Real.sqrt (2 * (tile_count : ℝ) * Real.log (2 / alpha)) *
        eps_fp32 * out_max
    0 ≤ bound := by
  -- Cite: Pythia.Statistics.AnytimeValid.etaBetting_concentration
  -- specialized to martingale-difference sequences with sub-Gaussian
  -- per-step bound `ε_fp32 · out_max`. (Gates on Pythia #96.)
  --
  -- The full statement with confidence quantifier is shaped as
  --   ∀ N ≤ TILE_COUNT, P(|err N| ≤ bound N) ≥ 1 - α
  -- with `bound N = √(2 N log(2/α)) · ε · out_max`. The Pythia
  -- citation provides the union-bound + etaBetting reverse-martingale
  -- inequality; specialization to FP-rounding martingales is the
  -- bundle's contribution.
  intro tile_count eps_fp32 bound
  unfold_let bound eps_fp32
  positivity

end AthanorNKI.AttnFwdV3Online
