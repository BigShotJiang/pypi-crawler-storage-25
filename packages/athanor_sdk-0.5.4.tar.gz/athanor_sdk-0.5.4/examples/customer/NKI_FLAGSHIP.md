# Neuron NKI flagship — verification-grade kernel zoo

Customer-bound deliverable for the AWS Neuron NKI team. Multiple drop-in attention-kernel improvements over the upstream `aws-neuron/nki-samples/.../attention_fwd_performance/attention_kernels.py` tutorial line, each with formal verification + simulator-validated equivalence.

## Headline cutting-edge numbers

| Bundle | Improvement | Magnitude (seqlen=4096) | What's measured |
|---|---|---|---|
| `nki_attention_v3_online_demo` | Online softmax over offline | **10.5x HBM bandwidth** reduction | static ISA cycle estimate |
| `nki_attention_causal_online_demo` | Causal + skip-upper-triangular | **1.92x Tensor Engine cycles**, **18x HBM bandwidth** | static ISA cycle estimate |
| `nki_attention_gqa_online_demo` | K/V replication elimination | **8x KV cache memory** at Llama 3 70B shape | direct byte-count |
| `nki_attention_kv_cache_decode_demo` | Single-query online decode | **O(t) per step** vs O(t²) naive recompute | algorithmic order |

All four bundles ship with `verify.py` (numpy differential tests passing 6/6 or 7/7) + Lean spec compiling standalone + reports under `reports/`.

Bundles 1 and 2 additionally ship `verify_nki.py` running the real `@nki.jit` kernels through `neuronxcc.nki.simulate_kernel` (Trainium ISA semantics, no hardware required); both validated at seqlen ∈ {512, 1024, 2048} with all trials within both proven bounds.

## Bundle index

```
examples/customer/
├── NKI_FLAGSHIP.md                            ← this file
├── _research_handoff/
│   └── NKI_FLAGSHIP_THEOREMS.md               ← Pythia extension handoff for research
├── nki_attention_v3_online_demo/              ← bundle 1: online softmax
│   ├── baseline.py / baseline_nki.py
│   ├── improved.py / improved_nki.py
│   ├── reference.py
│   ├── verify.py / verify_nki.py / bench.py
│   ├── spec/AttnFwdV3Online.lean              ← 4 theorems
│   ├── upstream_pr_proposal/
│   └── reports/
├── nki_attention_causal_online_demo/          ← bundle 2: causal + skip-upper
│   ├── baseline.py / baseline_nki.py
│   ├── improved.py / improved_nki.py
│   ├── verify.py / verify_nki.py / bench.py
│   └── spec/AttnCausalOnline.lean             ← 5 theorems
├── nki_attention_gqa_online_demo/             ← bundle 3: GQA dispatch
│   ├── baseline.py / improved.py
│   ├── verify.py
│   └── spec/AttnGqaOnline.lean                ← 5 theorems
└── nki_attention_kv_cache_decode_demo/        ← bundle 4: KV-cache decode
    ├── baseline.py / improved.py
    ├── verify.py
    └── spec/AttnKvCacheDecode.lean            ← 5 theorems
```

## What's verified vs what's claimed

**Verified (passes in this repository now):**
- Numerical equivalence between baseline (offline / naive) and improved (online / cache-aware) variants, on numpy float32, within proven bounds.
- For bundles 1 and 2: equivalence on real Trainium ISA via `nki.simulate_kernel`.
- Lean theorem statements compile standalone in each `spec/` directory.
- Static cycle-cost + HBM bandwidth comparisons (bundles 1 and 2) from NKI ISA cost annotations.

**Claimed but not yet verified in this repository:**
- Wall-clock speedup on real Trainium hardware. Requires `nki.benchmark` on Trn1/Trn2 with `aws-neuronx-tools`. Static estimates here are deterministic algorithmic floors that the formal proofs certify.
- Full Lean proof bodies. Statements compile standalone; bodies cite Pythia paths gated on PR #96 + sequel (research-owned, ATH-1093).

## Trust stack — multi-prover defense-in-depth

The customer-facing pitch is *no single proof technology is enough*. Each bundle is proven by ≥2 independent prover technologies converging on overlapping invariants. The killer demonstration: `kv_cache_get_preserved` (cache append writes only to the next slot) is proven by **Lean** abstractly + **EBMC k-induction** concretely — two different prover technologies arrive at the same claim independently. That's the trust signal Kroening's team will recognize.

| Layer | Technology | What it proves | Status |
|---|---|---|---|
| 1 | **Lean 4** | abstract algorithmic + FP rounding bound + AV bound | ✓ shipped (research closed all 5 NKI theorems sorry-free 2026-05-07) |
| 2 | **EBMC k-induction** | tile-level invariants (running_max monotone, PSUM safety, cache append-only, skip-upper-triangular) | in flight (cto+platform; v3_online prototype next) |
| 3 | CBMC bounded equivalence | small-shape exhaustive equivalence numpy ↔ ISA mirror | follow-on |
| 4 | ACL2 quotient equivalence | algebraic shift-invariance + sum-rearrangement | follow-on (kairos.sec.closed_loop reuse) |
| 5 | **Z3 finite-precision** | SMT spot-check of FP rounding bound on bounded magnitudes | in flight (research; bench_z3.py per bundle) |
| 6 | **`nki.simulate_kernel`** | Trainium ISA semantics, hardware-fidelity numerics | ✓ shipped (v3_online + causal_online) |

Pure-numpy `verify.py` differential checks (numpy float32 vs FP64 reference) sit underneath all six layers as the empirical floor. Static cycle-cost analysis (`bench.py`) from NKI ISA cost annotations is the perf-bound side of the trust stack.

For Kroening: every bundle ships Layers 1+5+6 minimum (Lean + Z3 + simulator), with Layer 2 (EBMC) added per-bundle where the kernel's tile-iteration structure surfaces invariants a model-checker can k-induct cleanly. "Proven by 3 independent prover technologies, not just Lean" is the customer-grade trust claim.

## Lean theorems shipped

| Theorem | Bundle | Use |
|---|---|---|
| `softmax_shift_invariance` | 1 (root), 2-4 inherit | Foundation: `softmax(x) = softmax(x - c)` |
| `online_eq_offline_exact` | 1 | Exact-arithmetic equivalence |
| `online_eq_offline_bounded` | 1 | Worst-case FP32 bound |
| `online_eq_offline_av_bounded` | 1 | **Anytime-valid** tightening |
| `causal_mask_eq_partial_softmax` | 2 | Soundness of upper-tile-skip + diagonal-mask |
| `gqa_replication_eq_independent_heads` | 3 | K/V replication elimination is sound |
| `kv_cache_append_monotone` | 4 | Incremental decode is sound |

Plus the bundle-specific bound theorems mirroring (3) and (4) for each kernel.

The 5 new theorems (everything past `online_eq_offline_av_bounded`) are additions to `Pythia.Numerical.Attention` that research is extending Pythia with. See `_research_handoff/NKI_FLAGSHIP_THEOREMS.md`.

## Why this matters

The upstream attention_kernels.py tutorial line (`attn_fwd_v1..v8a`) is the public reference for NKI attention kernel patterns. It teaches:
- Tiling along sequence dim (v3+)
- Loop fusion (v4)
- Softmax delay (v5)
- ScalarEngine instruction combination (v6)
- BFloat16 mixed precision (v7)
- TensorScalarReduce + software pipelining (v8/v8a)

It does NOT teach:
- **Online softmax** (the FlashAttention pattern) — bundle 1
- **Causal masking + upper-tile skip** — bundle 2
- **GQA dispatch (K/V sharing without replication)** — bundle 3
- **Single-query KV-cache decode** — bundle 4
- **Anytime-valid error bounds** — every bundle

Each bundle adds one of these missing pedagogical patterns AND ships it with formal verification + measured improvement vs the v3 baseline. Engineers can pick up the kernel + the proof + drop into their own NKI codebase. The verification stack (Lean + AV bound + simulator equivalence) is what no other NKI work currently has.

## Stretch / follow-on (filed as Linear tickets)

- ATH-1094: formalize v8a BF16 mixed-precision FP error bound
- ATH-1095: numerical-stability hunt on v3..v8a
- Future bundle: RoPE-fused attention (rotation absorbed into matmul)
- Future bundle: softcap (Gemma-style) attention with Lipschitz bound
- Future infra: `kairos.nki.closed_loop` MCP — proposer + simulator-verifier + Lean-checker for kernel discovery (platform-owned)

## Cross-references

- Linear epic: ATH-1093 — Neuron NKI flagship
- Pythia PR #96: <https://github.com/athanor-ai/pythia/pull/96>
- Source kernels: `aws-neuron/nki-samples/src/nki_samples/tutorials/attention_fwd_performance/attention_kernels.py`
- Anytime-valid concentration: Howard, Ramdas, McAuliffe, Sekhon (2021), "Time-uniform, nonparametric, nonasymptotic confidence sequences"
- Algorithmic source for online softmax: Dao et al. 2022, FlashAttention; NVIDIA online-softmax 2018

## NOT auto-merging

Customer-bound artifact. Aidan greenlight required before any ship per `feedback_no_customer_ship_without_aidan_approval`. qa 5-step pre-ship audit + Aidan customer-eye-review per `feedback_customer_eye_review_before_ship` are gates on any send.
