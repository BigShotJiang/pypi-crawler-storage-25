# nki_attention_gqa_online_demo

Engineer-facing entry. For customer-facing pitch see `CUSTOMER_README.md`.

## What

Grouped-query attention (GQA) dispatch pattern: per-head call into single-head online-softmax with shared (non-replicated) K/V. Eliminates K/V replication used by naive MHA.

Key contribution at the SDK level — the inner per-head kernel is the existing `attn_fwd_v3_online` from sibling bundle 1. The GQA "kernel" is a Python head-loop dispatch over that, not a new `@nki.jit`. This is intentional — GQA's value is in the dispatch pattern + KV cache memory savings, not a new ISA-level kernel.

## Files

```
nki_attention_gqa_online_demo/
├── README.md                       ← this file
├── CUSTOMER_README.md              ← customer-facing pitch
├── baseline.py                     ← naive MHA (explicit K/V replication)
├── improved.py                     ← GQA dispatch (no replication)
├── reference.py                    ← float64 ground truth
├── verify.py                       ← 7 test classes (MQA / MHA / Llama 3 / random)
├── spec/
│   └── AttnGqaOnline.lean          ← 5 theorems incl. gqa_replication_eq_independent_heads
└── reports/
    ├── summary.json
    └── test_report.json
```

## Run

```bash
cd examples/customer/nki_attention_gqa_online_demo
python3 verify.py
```

## Status

- numpy verify.py: 7/7 PASS — basic_shape / mqa_limit / mha_limit / llama3_shape / differential_seqlen_512_g4 / differential_seqlen_2048_g4 / memory_savings_llama3_70b
- Lean theorems: 5 statements compile standalone, proof bodies sorry-flagged. Gates on Pythia PR #96 sequel adding `gqa_replication_eq_independent_heads`.
- KV cache memory savings at Llama 3 70B shape: 8x reduction (256 MiB → 32 MiB per layer at seqlen=4096).

## Lean theorems

1. `softmax_shift_invariance` — inherited
2. `gqa_replication_eq_independent_heads` — *new* fundamental theorem: K/V replication elimination is sound
3. `gqa_online_eq_replicated_exact` — exact equivalence
4. `gqa_online_eq_replicated_bounded` — worst-case FP32 bound
5. `gqa_online_eq_replicated_av_bounded` — anytime-valid bound

## Why no @nki.jit?

GQA's contribution is at the dispatch layer, not the per-head ISA-level kernel. The inner per-head attention is the existing `attn_fwd_v3_online` (sibling bundle 1) — already `nki.simulate_kernel`-validated on Trainium ISA at full trust stack. The GQA dispatch wraps that with a Python head loop; per-head simulator validation transfers identically.

## Cross-refs

- ATH-1093 (Linear) — Neuron NKI flagship epic
- Sibling: `examples/customer/nki_attention_v3_online_demo/` (inner per-head kernel)
- Sibling: `examples/customer/nki_attention_causal_online_demo/` (causal mask, combines naturally with this dispatch)
- Algorithmic source: Ainslie et al. 2023, "GQA: Training Generalized Multi-Query Transformer Models from Multi-Head Checkpoints"
