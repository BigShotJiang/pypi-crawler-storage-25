"""GQA online-softmax variant — eliminates K/V replication.

Each kv-head is shared across `group_size` query heads. The improved
kernel processes each query head independently but reads the SHARED
(non-replicated) K/V tensors directly. No physical replication, so:

    k.shape == (n_heads_kv, d_head, seqlen)   (NOT replicated to n_heads_q)
    v.shape == (n_heads_kv, d_head, seqlen)

KV-cache memory savings vs replicated baseline: factor of `group_size`.

For Llama 3 70B (n_heads_q=64, n_heads_kv=8, group_size=8): 8x KV cache
reduction. For Mistral 7B (n_heads_q=32, n_heads_kv=8, group_size=4):
4x reduction. For PaLM 2's MQA limit case (n_heads_q=N, n_heads_kv=1):
N-fold reduction.

Inside each query head, the attention kernel is the same
online-softmax pattern as `nki_attention_v3_online_demo/improved.py`.
The Lean theorem `gqa_replication_eq_independent_heads` certifies that
the no-replication kernel produces bit-exact identical output to the
replicated baseline.
"""
from __future__ import annotations

import math

import numpy as np


PARTITION_SIZE: int = 128


def improved_attention(
    q: np.ndarray,
    k: np.ndarray,
    v: np.ndarray,
    *,
    tile_kv: int = PARTITION_SIZE,
) -> np.ndarray:
    """GQA online-softmax. Same I/O contract as `baseline_attention`
    but does NOT replicate K/V — reads them shared across the head
    group.
    """
    if q.dtype != np.float32:
        q = q.astype(np.float32)
    if k.dtype != np.float32:
        k = k.astype(np.float32)
    if v.dtype != np.float32:
        v = v.astype(np.float32)

    n_heads_q = q.shape[0]
    n_heads_kv = k.shape[0]
    assert n_heads_q % n_heads_kv == 0
    group_size = n_heads_q // n_heads_kv

    d_head, seqlen = q.shape[1], q.shape[2]

    out = np.empty((n_heads_q, seqlen, d_head), dtype=np.float32)

    for i_head_q in range(n_heads_q):
        i_head_kv = i_head_q // group_size
        q_h = q[i_head_q]
        k_h = k[i_head_kv]
        v_h = v[i_head_kv]

        running_max = np.full((seqlen, 1), -np.inf, dtype=np.float32)
        running_sum = np.zeros((seqlen, 1), dtype=np.float32)
        out_h = np.zeros((seqlen, d_head), dtype=np.float32)

        for j in range(0, seqlen, tile_kv):
            j_end = min(j + tile_kv, seqlen)

            qk_tile = (q_h.T @ k_h[:, j:j_end]).astype(np.float32)
            tile_max = np.max(qk_tile, axis=1, keepdims=True).astype(np.float32)
            new_max = np.maximum(running_max, tile_max)

            with np.errstate(invalid="ignore"):
                correction = np.exp(running_max - new_max).astype(np.float32)
            correction = np.where(np.isfinite(correction), correction, 0.0).astype(np.float32)

            p_tile = np.exp(qk_tile - new_max).astype(np.float32)
            tile_sum = p_tile.sum(axis=1, keepdims=True).astype(np.float32)
            running_sum = (running_sum * correction + tile_sum).astype(np.float32)

            v_tile = v_h[:, j:j_end]
            tile_contrib = (p_tile @ v_tile.T).astype(np.float32)
            out_h = (out_h * correction + tile_contrib).astype(np.float32)

            running_max = new_max

        out[i_head_q] = (out_h / running_sum).astype(np.float32)

    return out


def memory_bytes(seqlen: int, d_head: int, n_heads_q: int, n_heads_kv: int) -> int:
    """Working memory WITHOUT K/V replication. Q is per-head; K/V are
    shared across the group, so n_heads_kv K/V tensors total. Inner
    online-softmax has zero-QK-materialization."""
    f32 = 4
    q_bytes = n_heads_q * d_head * seqlen * f32
    k_bytes = n_heads_kv * d_head * seqlen * f32
    v_bytes = n_heads_kv * d_head * seqlen * f32
    out_bytes = n_heads_q * seqlen * d_head * f32
    running_bytes = n_heads_q * 2 * seqlen * f32
    return q_bytes + k_bytes + v_bytes + out_bytes + running_bytes


def proven_error_bound(
    seqlen: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
) -> float:
    """Worst-case bound. Per query head, same as v3_online — GQA's
    head-independence means the bound is per-head and uniform.

    Cites `spec/AttnGqaOnline.lean::gqa_online_eq_replicated_bounded`.
    """
    tile_count = (seqlen + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return 8.0 * tile_count * eps_fp32 * out_max


def av_error_bound(
    seqlen: int,
    *,
    tile_kv: int = PARTITION_SIZE,
    out_max: float = 1.0,
    alpha: float = 0.05,
) -> float:
    """Anytime-valid bound, same shape as v3_online and causal_online.

    Cites `spec/AttnGqaOnline.lean::gqa_online_eq_replicated_av_bounded`.
    """
    tile_count = (seqlen + tile_kv - 1) // tile_kv
    eps_fp32 = 2.0 ** -23
    return math.sqrt(2.0 * tile_count * math.log(2.0 / alpha)) * eps_fp32 * out_max
