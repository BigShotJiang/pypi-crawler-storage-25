# GQA dispatch pattern — eliminate K/V replication, prove soundness

## What this package proposes

Grouped-query attention (GQA) is the multi-head sharing pattern used by Llama 3, Mistral, Qwen, and most modern serving stacks. The naive implementation REPLICATES K and V tensors `group_size` times to match the query-head count, then runs standard multi-head attention. Production kernels skip the replication and read K/V SHARED across the group.

This package proves the eliminate-the-replication transformation is bit-equivalent to the replicate-and-MHA baseline, and shows the SDK dispatch pattern that achieves it on top of the existing single-head `attn_fwd_v3_online` kernel.

The novel piece is the Lean theorem `gqa_replication_eq_independent_heads`:

> Given query heads {1, …, n_heads_q} and shared K/V heads {1, …, n_heads_kv} with `n_heads_q = group_size · n_heads_kv`, the per-query-head attention output computed with the SHARED K/V (group-indexed by `i_head_q // group_size`) equals the per-head attention output computed with REPLICATED K/V (each kv head duplicated `group_size` times).

This is the soundness theorem for eliminating the K/V replication step.

## Why this matters for production NKI

Every modern decoder-only LLM uses GQA or its limit case MQA. Concrete shapes:
- Llama 3 8B: `n_heads_q=32, n_heads_kv=8, group_size=4`
- Llama 3 70B: `n_heads_q=64, n_heads_kv=8, group_size=8`
- Mistral 7B: `n_heads_q=32, n_heads_kv=8, group_size=4`
- PaLM 2 (MQA): `n_heads_kv=1` (every Q head shares one K, V)

KV cache memory at seqlen=4096, d_head=128, fp32 (per layer):
- Naive MHA-with-replication: `n_heads_q × seqlen × d_head × 4 × 2 (K+V) = 64 × 4096 × 128 × 8 = 256 MiB` for Llama 3 70B
- GQA without replication: `n_heads_kv × seqlen × d_head × 4 × 2 = 8 × 4096 × 128 × 8 = 32 MiB`
- **8x KV cache reduction**

That's the cost saving the upstream NKI tutorial line (`attn_fwd_v3..v8a`) doesn't pedagogically address — every variant assumes single-head shape.

## What's in this package

| File | Role |
|---|---|
| `baseline.py` | Naive-MHA: explicit K/V replication then per-head attention. |
| `improved.py` | GQA dispatch: per-head attention with shared (non-replicated) K/V. Inner kernel is the same online-softmax pattern as `nki_attention_v3_online_demo`. |
| `reference.py` | float64 ground truth via explicit replication. |
| `spec/AttnGqaOnline.lean` | 5-theorem Lean spec including `gqa_replication_eq_independent_heads`. |
| `verify.py` | 7 test classes covering MQA / MHA / Llama 3 limit cases + 32 random trials at multiple seqlens + memory savings claim for Llama 3 70B shape. |

The `improved.py` dispatch pattern is the SDK contribution. The `@nki.jit` kernel reuse is the same `attn_fwd_v3_online` from sibling bundle 1; no new kernel needed because GQA's contribution is at the dispatch layer, not the per-head attention.

## How to run

```bash
$ cd examples/customer/nki_attention_gqa_online_demo
$ python3 verify.py
  [PASS] basic_shape
  [PASS] mqa_limit            ← MQA (n_heads_kv=1), PaLM 2 shape
  [PASS] mha_limit            ← MHA (group_size=1, no sharing)
  [PASS] llama3_shape         ← group_size=4, Llama 3 / Mistral
  [PASS] differential_seqlen_512_g4
  [PASS] differential_seqlen_2048_g4
  [PASS] memory_savings_llama3_70b
{
  "passed": true,
  "n_tests": 7,
  ...
}
```

## Lean theorems

1. `softmax_shift_invariance` — inherited from sibling v3_online.
2. `gqa_replication_eq_independent_heads` — *new*. The fundamental soundness theorem for K/V replication elimination.
3. `gqa_online_eq_replicated_exact` — exact-arithmetic equivalence GQA dispatch ↔ replicated MHA.
4. `gqa_online_eq_replicated_bounded` — worst-case FP32 bound (per-head uniform).
5. `gqa_online_eq_replicated_av_bounded` — anytime-valid bound.

All five compile standalone. Proof bodies sorry-flagged honestly until Pythia PR #96 sequel lands the `Pythia.Numerical.Attention.gqa_replication_eq_independent_heads` citation.

## What's NOT here

- Real Trainium hardware execution. The dispatch pattern uses the existing `attn_fwd_v3_online` kernel from sibling bundle 1, which is `nki.simulate_kernel`-validated end-to-end on Trainium ISA. The GQA dispatch wraps that with a Python head loop; the per-head simulator validation transfers.
- Causal-mask GQA. Combining this dispatch with the `nki_attention_causal_online_demo` causal kernel is mechanical — replace the inner per-head call with the causal variant. Worth a separate bundle for cleanliness.

## Cross-references

- **Sibling kernel**: `examples/customer/nki_attention_v3_online_demo/` — the inner per-head online-softmax kernel
- **Sibling kernel**: `examples/customer/nki_attention_causal_online_demo/` — causal mask variant (combines naturally with this GQA dispatch)
- **Algorithmic source**: Ainslie et al. 2023, "GQA: Training Generalized Multi-Query Transformer Models from Multi-Head Checkpoints"
- **Production deployments**: Llama 3 (Meta), Mistral 7B, Qwen, Gemma 2
- **Pythia PR #96**: <https://github.com/athanor-ai/pythia/pull/96>
- **ATH-1093 (Linear)**: NKI flagship epic
