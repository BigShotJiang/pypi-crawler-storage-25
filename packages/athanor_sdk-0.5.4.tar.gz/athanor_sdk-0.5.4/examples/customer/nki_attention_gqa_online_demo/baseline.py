"""GQA (grouped-query attention) baseline — offline softmax with K/V
replicated to every query head.

This is the "naive MHA" implementation of GQA: the K/V tensors are
PHYSICALLY replicated to match the query-head count, then the kernel
runs as if it were standard multi-head attention. Used as the
equivalence target for `improved.py` (which avoids the replication
and shares K/V directly across the group).

Algorithm:
    1. Replicate k → k_replicated of shape (n_heads_q, d_head, seqlen)
       by repeating each k-head `group_size` times.
    2. Replicate v similarly.
    3. For each i_head_q ∈ [0, n_heads_q):
        run standard attention with q[i_head_q], k_replicated[i_head_q],
        v_replicated[i_head_q].

The output is (n_heads_q, seqlen, d_head). The replication step is the
inefficiency that GQA-aware kernels eliminate.
"""
from __future__ import annotations

import numpy as np


def baseline_attention(
    q: np.ndarray,  # (n_heads_q, d_head, seqlen)
    k: np.ndarray,  # (n_heads_kv, d_head, seqlen)
    v: np.ndarray,  # (n_heads_kv, d_head, seqlen)
) -> np.ndarray:
    """GQA offline-softmax via explicit K/V replication."""
    if q.dtype != np.float32:
        q = q.astype(np.float32)
    if k.dtype != np.float32:
        k = k.astype(np.float32)
    if v.dtype != np.float32:
        v = v.astype(np.float32)

    n_heads_q = q.shape[0]
    n_heads_kv = k.shape[0]
    assert n_heads_q % n_heads_kv == 0, (
        f"n_heads_q={n_heads_q} not divisible by n_heads_kv={n_heads_kv}"
    )
    group_size = n_heads_q // n_heads_kv

    d_head, seqlen = q.shape[1], q.shape[2]
    assert k.shape == (n_heads_kv, d_head, seqlen)
    assert v.shape == (n_heads_kv, d_head, seqlen)

    out = np.empty((n_heads_q, seqlen, d_head), dtype=np.float32)

    for i_head_q in range(n_heads_q):
        i_head_kv = i_head_q // group_size
        q_head = q[i_head_q]                      # (d_head, seqlen)
        k_head = k[i_head_kv]                     # (d_head, seqlen) — shared
        v_head = v[i_head_kv]                     # (d_head, seqlen) — shared

        qk = (q_head.T @ k_head).astype(np.float32)
        row_max = np.max(qk, axis=1, keepdims=True)
        exp = np.exp(qk - row_max).astype(np.float32)
        row_sum = exp.sum(axis=1, keepdims=True).astype(np.float32)
        scores = (exp / row_sum).astype(np.float32)
        out[i_head_q] = (scores @ v_head.T).astype(np.float32)

    return out


def memory_bytes(seqlen: int, d_head: int, n_heads_q: int, n_heads_kv: int) -> int:
    """Working memory if K/V are replicated to match Q heads (the
    naive-MHA shape)."""
    f32 = 4
    q_bytes = n_heads_q * d_head * seqlen * f32
    k_replicated_bytes = n_heads_q * d_head * seqlen * f32
    v_replicated_bytes = n_heads_q * d_head * seqlen * f32
    qk_per_head = seqlen * seqlen * f32
    qk_total_bytes = n_heads_q * qk_per_head
    out_bytes = n_heads_q * seqlen * d_head * f32
    return q_bytes + k_replicated_bytes + v_replicated_bytes + qk_total_bytes + out_bytes
