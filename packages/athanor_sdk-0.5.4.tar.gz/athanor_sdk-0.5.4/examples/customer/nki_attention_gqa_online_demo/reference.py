"""float64 reference for GQA. Used as ground truth for verify.py."""
from __future__ import annotations

import numpy as np


def reference_attention(
    q: np.ndarray, k: np.ndarray, v: np.ndarray
) -> np.ndarray:
    """GQA in float64 with explicit K/V replication."""
    q64 = q.astype(np.float64)
    k64 = k.astype(np.float64)
    v64 = v.astype(np.float64)

    n_heads_q = q64.shape[0]
    n_heads_kv = k64.shape[0]
    assert n_heads_q % n_heads_kv == 0
    group_size = n_heads_q // n_heads_kv

    seqlen = q64.shape[2]
    d_head = q64.shape[1]
    out = np.empty((n_heads_q, seqlen, d_head), dtype=np.float32)

    for i_head_q in range(n_heads_q):
        i_head_kv = i_head_q // group_size
        q_h = q64[i_head_q]
        k_h = k64[i_head_kv]
        v_h = v64[i_head_kv]
        qk = q_h.T @ k_h
        row_max = np.max(qk, axis=1, keepdims=True)
        exp = np.exp(qk - row_max)
        row_sum = exp.sum(axis=1, keepdims=True)
        scores = exp / row_sum
        out[i_head_q] = (scores @ v_h.T).astype(np.float32)

    return out
