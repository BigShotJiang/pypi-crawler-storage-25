"""Differential verification — GQA improved (no replication) vs baseline
(explicit replication) vs FP64 reference. Same 6-test-class shape as
v3_online + 1 GQA-specific test (group-size invariance)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from baseline import baseline_attention, memory_bytes as baseline_memory_bytes  # noqa: E402
from improved import (  # noqa: E402
    av_error_bound,
    improved_attention,
    memory_bytes as improved_memory_bytes,
    proven_error_bound,
)
from reference import reference_attention  # noqa: E402


REPORTS_DIR = HERE / "reports"
N_RANDOM_TRIALS = 16
RNG = np.random.default_rng(seed=20260507)
D_HEAD = 128


def _max_err(a, b):
    return float(np.max(np.abs(a - b)))


def _trial(seqlen: int, n_heads_q: int, n_heads_kv: int) -> dict:
    q = RNG.standard_normal((n_heads_q, D_HEAD, seqlen)).astype(np.float32)
    k = RNG.standard_normal((n_heads_kv, D_HEAD, seqlen)).astype(np.float32)
    v = RNG.standard_normal((n_heads_kv, D_HEAD, seqlen)).astype(np.float32)

    ref = reference_attention(q, k, v)
    base = baseline_attention(q, k, v)
    impr = improved_attention(q, k, v)

    err_impr_vs_ref = _max_err(impr, ref)
    err_impr_vs_base = _max_err(impr, base)
    err_base_vs_ref = _max_err(base, ref)
    out_max = float(np.max(np.abs(base)))
    bound_wc = proven_error_bound(seqlen, out_max=out_max)
    bound_av = av_error_bound(seqlen, out_max=out_max, alpha=0.05)

    return {
        "seqlen": seqlen,
        "n_heads_q": n_heads_q,
        "n_heads_kv": n_heads_kv,
        "group_size": n_heads_q // n_heads_kv,
        "err_impr_vs_ref": err_impr_vs_ref,
        "err_impr_vs_base": err_impr_vs_base,
        "err_base_vs_ref": err_base_vs_ref,
        "proven_bound_worst_case": bound_wc,
        "proven_bound_av_alpha_0_05": bound_av,
        "within_bound_vs_base": bool(err_impr_vs_base <= bound_wc),
        "within_av_bound_vs_base": bool(err_impr_vs_base <= bound_av),
    }


def test_basic_shape() -> dict:
    seqlen = 256
    n_heads_q = 4
    n_heads_kv = 2
    q = RNG.standard_normal((n_heads_q, D_HEAD, seqlen)).astype(np.float32)
    k = RNG.standard_normal((n_heads_kv, D_HEAD, seqlen)).astype(np.float32)
    v = RNG.standard_normal((n_heads_kv, D_HEAD, seqlen)).astype(np.float32)
    out = improved_attention(q, k, v)
    expected = (n_heads_q, seqlen, D_HEAD)
    return {
        "name": "basic_shape",
        "passed": out.shape == expected,
        "details": f"out.shape={out.shape}, expected={expected}",
    }


def test_mqa_limit() -> dict:
    """MQA = GQA with n_heads_kv=1 (every Q head shares the same K, V).
    PaLM-2-style. Important limit case."""
    row = _trial(seqlen=256, n_heads_q=4, n_heads_kv=1)
    return {
        "name": "mqa_limit",
        "passed": row["within_bound_vs_base"],
        "row": row,
    }


def test_mha_limit() -> dict:
    """MHA = GQA with n_heads_kv == n_heads_q (group_size=1, no sharing).
    Standard pre-GQA shape. Should be bit-identical to per-head v3_online."""
    row = _trial(seqlen=256, n_heads_q=4, n_heads_kv=4)
    return {
        "name": "mha_limit",
        "passed": row["within_bound_vs_base"],
        "row": row,
    }


def test_llama3_shape() -> dict:
    """Llama 3 GQA shape: 4 query heads per kv head (group_size=4)."""
    row = _trial(seqlen=256, n_heads_q=8, n_heads_kv=2)
    return {
        "name": "llama3_shape",
        "passed": row["within_bound_vs_base"],
        "row": row,
    }


def _random_differential(seqlen: int, n_heads_q: int, n_heads_kv: int, n_trials: int = N_RANDOM_TRIALS) -> dict:
    rows = []
    all_ok = True
    for _ in range(n_trials):
        row = _trial(seqlen, n_heads_q, n_heads_kv)
        rows.append(row)
        if not row["within_bound_vs_base"]:
            all_ok = False
    n_within_av = sum(1 for r in rows if r["within_av_bound_vs_base"])
    return {
        "name": f"differential_seqlen_{seqlen}_g{n_heads_q // n_heads_kv}",
        "passed": all_ok,
        "n_trials": n_trials,
        "n_within_bound": sum(1 for r in rows if r["within_bound_vs_base"]),
        "n_within_av_bound": n_within_av,
        "max_empirical_err_vs_base": max(r["err_impr_vs_base"] for r in rows),
        "rows": rows,
    }


def test_medium_seqlen_g4() -> dict:
    return _random_differential(seqlen=512, n_heads_q=8, n_heads_kv=2)


def test_large_seqlen_g4() -> dict:
    return _random_differential(seqlen=2048, n_heads_q=8, n_heads_kv=2)


def test_memory_savings() -> dict:
    """Llama 3 70B shape: n_heads_q=64, n_heads_kv=8, group_size=8."""
    seqlen = 4096
    n_heads_q = 64
    n_heads_kv = 8
    base_bytes = baseline_memory_bytes(seqlen, D_HEAD, n_heads_q, n_heads_kv)
    impr_bytes = improved_memory_bytes(seqlen, D_HEAD, n_heads_q, n_heads_kv)
    ratio = base_bytes / impr_bytes if impr_bytes else float("inf")
    return {
        "name": "memory_savings_llama3_70b",
        "passed": impr_bytes < base_bytes,
        "details": (
            f"seqlen=4096 d_head=128 n_heads_q=64 n_heads_kv=8: "
            f"baseline (KV replicated)={base_bytes / 1024**2:.2f} MiB, "
            f"improved (KV shared)={impr_bytes / 1024**2:.2f} MiB, "
            f"ratio={ratio:.2f}x"
        ),
        "baseline_bytes": base_bytes,
        "improved_bytes": impr_bytes,
        "ratio": ratio,
    }


TESTS = (
    test_basic_shape,
    test_mqa_limit,
    test_mha_limit,
    test_llama3_shape,
    test_medium_seqlen_g4,
    test_large_seqlen_g4,
    test_memory_savings,
)


def main() -> int:
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for t in TESTS:
        r = t()
        results.append(r)
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  [{status}] {r['name']}")

    n_pass = sum(1 for r in results if r["passed"])
    n_fail = len(results) - n_pass
    summary = {
        "passed": n_fail == 0,
        "n_tests": len(results),
        "n_passed": n_pass,
        "n_failed": n_fail,
        "kernel": "nki_attention_gqa_online_demo",
        "lean_spec": "spec/AttnGqaOnline.lean",
    }

    (REPORTS_DIR / "summary.json").write_text(json.dumps(summary, indent=2))
    (REPORTS_DIR / "test_report.json").write_text(
        json.dumps({"summary": summary, "tests": results}, indent=2, default=str)
    )
    print(json.dumps(summary, indent=2))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
