"""verify.py — verification harness for the nki_add demo kernel.

Compatible with the kairos.verticals.neuron_nki.NeuronNKIPlugin
contract: lives at <bundle>/verify.py, exits 0 on overall pass +
non-zero on overall fail, writes per-class JSON reports under
<bundle>/reports/. This is the W1.C bundle that pairs with the
W1.B planted-bug bundle — same pipeline shape, opposite verdict.

Test classes
------------

1. **basic_shape** — output length matches input length.
2. **shape_mismatch_raises** — kernel raises on input length mismatch.
3. **identity_zero** — adding all-zeros produces input passthrough.
4. **identity_neg** — adding the additive inverse produces zeros.
5. **commutativity** — kernel(a, b) == kernel(b, a) for random pairs.
6. **differential_against_reference** — many random inputs; kernel
   output matches ``reference.reference`` within fp64 tolerance.
7. **per_element_identity** — for every index ``i``, output[i] equals
   ``add_at(a, b, i)`` (Lean spec's central correctness predicate).
8. **boundary_lengths** — kernels at lengths 1, 127, 128, 129, 256
   (around the typical PARTITION_SIZE) all match reference.

All eight should PASS on a correct kernel — this is the catalog's
clean-bundle baseline. If any test fails, the harness exits 1 and
the dashboard surfaces the kernel as `refuted` (same as the
planted-bug demo, opposite expected outcome).

Reproducibility: ``random.Random(seed=42)``. Byte-identical
re-runs.
"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path
from typing import Any

from kernel import add_at, kernel
from reference import reference


HERE = Path(__file__).resolve().parent
REPORTS_DIR = HERE / "reports"
REPORTS_DIR.mkdir(exist_ok=True)


def _close_enough(a: list[float], b: list[float], tol: float = 1e-12) -> bool:
    """Pointwise tolerance. Float add at this size is exact for
    well-spaced inputs; we allow 1e-12 to be safe."""
    if len(a) != len(b):
        return False
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def test_basic_shape() -> tuple[bool, str]:
    out = kernel([1.0, 2.0], [3.0, 4.0])
    if len(out) != 2:
        return False, f"expected output length 2, got {len(out)}"
    return True, "shape ok"


def test_shape_mismatch_raises() -> tuple[bool, str]:
    try:
        kernel([1.0], [1.0, 2.0])
    except ValueError:
        return True, "raised as expected"
    return False, "kernel accepted mismatched input lengths"


def test_identity_zero() -> tuple[bool, str]:
    a = [1.5, -2.0, 0.0, 7.25]
    z = [0.0] * len(a)
    out = kernel(a, z)
    if not _close_enough(out, a):
        return False, f"expected {a}, got {out}"
    return True, "zero identity ok"


def test_identity_neg() -> tuple[bool, str]:
    a = [1.5, -2.0, 0.0, 7.25]
    neg = [-x for x in a]
    out = kernel(a, neg)
    if not all(x == 0.0 for x in out):
        return False, f"expected zeros, got {out}"
    return True, "neg identity ok"


def test_commutativity() -> tuple[bool, str]:
    rng = random.Random(42)
    for trial in range(16):
        n = rng.randint(1, 200)
        a = [rng.uniform(-1, 1) for _ in range(n)]
        b = [rng.uniform(-1, 1) for _ in range(n)]
        if not _close_enough(kernel(a, b), kernel(b, a)):
            return False, f"trial {trial}: kernel(a,b) != kernel(b,a) at n={n}"
    return True, "commutative across 16 random trials"


def test_per_element_identity() -> tuple[bool, str]:
    """For every index i, kernel(a,b)[i] == add_at(a,b,i)."""
    rng = random.Random(42)
    n = 64
    a = [rng.uniform(-1, 1) for _ in range(n)]
    b = [rng.uniform(-1, 1) for _ in range(n)]
    out = kernel(a, b)
    for i in range(n):
        expected = add_at(a, b, i)
        if abs(out[i] - expected) > 1e-12:
            return False, f"index {i}: out={out[i]} != add_at={expected}"
    return True, "per-element identity ok"


def test_boundary_lengths() -> tuple[bool, str]:
    rng = random.Random(42)
    for n in (1, 127, 128, 129, 256):
        a = [rng.uniform(-1, 1) for _ in range(n)]
        b = [rng.uniform(-1, 1) for _ in range(n)]
        if not _close_enough(kernel(a, b), reference(a, b)):
            return False, f"divergence at boundary length n={n}"
    return True, "lengths {1, 127, 128, 129, 256} ok"


def test_differential_against_reference() -> dict[str, Any]:
    """Random inputs at varied sizes; differential against reference."""
    rng = random.Random(42)
    n_iters = 32
    failures: list[dict[str, Any]] = []
    for trial in range(n_iters):
        n = rng.randint(1, 256)
        a = [rng.uniform(-100, 100) for _ in range(n)]
        b = [rng.uniform(-100, 100) for _ in range(n)]
        out = kernel(a, b)
        expected = reference(a, b)
        diverged = []
        for i, (x, y) in enumerate(zip(out, expected)):
            if abs(x - y) > 1e-12:
                diverged.append({"i": i, "kernel": x, "reference": y})
        if diverged:
            failures.append({
                "trial": trial,
                "n": n,
                "first_divergence": diverged[0],
            })
    return {
        "passed": len(failures) == 0,
        "n_trials": n_iters,
        "n_failed_trials": len(failures),
        "first_failure": failures[0] if failures else None,
    }


def main() -> int:
    test_results: list[dict[str, Any]] = []

    for name, fn in [
        ("basic_shape", test_basic_shape),
        ("shape_mismatch_raises", test_shape_mismatch_raises),
        ("identity_zero", test_identity_zero),
        ("identity_neg", test_identity_neg),
        ("commutativity", test_commutativity),
        ("per_element_identity", test_per_element_identity),
        ("boundary_lengths", test_boundary_lengths),
    ]:
        try:
            ok, detail = fn()
        except Exception as exc:  # noqa: BLE001
            ok, detail = False, f"raised: {type(exc).__name__}: {exc}"
        test_results.append({"test": name, "passed": ok, "detail": detail})

    diff = test_differential_against_reference()
    test_results.append({
        "test": "differential_against_reference",
        "passed": diff["passed"],
        "detail": (
            f"{diff['n_failed_trials']} of {diff['n_trials']} trials diverged"
            if not diff["passed"]
            else f"{diff['n_trials']} trials all matched reference"
        ),
        "first_failure": diff["first_failure"],
    })

    overall_passed = all(r["passed"] for r in test_results)

    (REPORTS_DIR / "test_report.json").write_text(
        json.dumps({"results": test_results}, indent=2)
    )

    summary = {
        "passed": overall_passed,
        "n_tests": len(test_results),
        "n_passed": sum(1 for r in test_results if r["passed"]),
        "n_failed": sum(1 for r in test_results if not r["passed"]),
        "kernel": "nki_add_demo",
        "lean_spec": "spec/AddNKI.lean",
        "rationale": (
            "All 8 test classes pass: kernel mirrors the Lean spec "
            "(spec/AddNKI.lean) one-to-one. Per-element identity, "
            "boundary lengths around PARTITION_SIZE=128, commutativity, "
            "and 32 random differential trials against the reference "
            "all match within fp64 tolerance."
            if overall_passed
            else f"{sum(1 for r in test_results if not r['passed'])} test(s) failed; bundle is REFUTED"
        ),
    }
    (REPORTS_DIR / "summary.json").write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))
    return 0 if overall_passed else 1


if __name__ == "__main__":
    sys.exit(main())
