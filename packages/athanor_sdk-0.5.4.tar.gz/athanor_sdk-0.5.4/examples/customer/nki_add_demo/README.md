# NKI element-wise add demo (Lean spec end-to-end)

Simplest possible end-to-end demonstration of the
**Lean spec to manually-bridged Python NKI mock to verify-and-disclose**
methodology applied to a single NKI kernel: element-wise tensor add.

This bundle is the W1.C clean-baseline counterpart to the W1.B
planted-bug demo. Same pipeline shape, same dashboard render, but
the verdict is `proved` (eight test classes pass) rather than
`refuted`. Together they show what catalog entries look like at
both ends of the verdict mix.

## What the kernel does

For two equal-shape input tiles `a` and `b` of length `n`, produce
output tile `c` where `c[i] = a[i] + b[i]` for every `i in [0, n)`.

That is the whole contract. No accumulator state. No tile-boundary
effects. The bridge from the Lean spec to the Python mock is
one-to-one and auditable in two screenfuls.

## The four files in this bundle

| File | Role |
|------|------|
| `spec/AddNKI.lean` | Lean source-of-truth contract. Defines `Tile`, `Input`, `Output`, `addAt`, `kernel`. Trailing comment lists the natural theorem pins for the next-iteration Lake project. |
| `kernel.py` | Manually-bridged Python mock of the Lean `kernel`. One `add_at` function, one `kernel` function, both pure. |
| `reference.py` | Numerically-correct nested-loop ground truth. `verify.py` differentials against this. |
| `verify.py` | Eight-test verification driver (basic_shape, shape_mismatch_raises, identity_zero, identity_neg, commutativity, per_element_identity, boundary_lengths, differential_against_reference). Writes `reports/summary.json` plus `reports/test_report.json`. Exits 0 on all-pass. |

## How to run

```bash
$ cd examples/customer/nki_add_demo
$ python3 verify.py
{
  "passed": true,
  "n_tests": 8,
  "n_passed": 8,
  "n_failed": 0,
  ...
}
$ echo $?
0
```

Or via the SDK adapter (emits a `nki_kernel_verified` trace event so
the run shows up on the Verification Coverage card under the
`lean_proven` bucket):

```python
from kairos.nki import run_bundle
result = run_bundle("examples/customer/nki_add_demo")
# result.verdict_outcome == "proved"
# result.run_id is the dashboard run_id
```

## What the eight test classes cover

1. **basic_shape**: output length matches input length.
2. **shape_mismatch_raises**: kernel raises `ValueError` on input length mismatch.
3. **identity_zero**: adding all-zeros is a passthrough (`a + 0 = a`).
4. **identity_neg**: adding the additive inverse produces zeros (`a + (-a) = 0`).
5. **commutativity**: `kernel(a, b) == kernel(b, a)` across 16 random pairs.
6. **per_element_identity**: for every index `i`, `kernel(a, b)[i] == add_at(a, b, i)`.
   This is the central correctness predicate from the Lean spec.
7. **boundary_lengths**: kernel matches reference at lengths 1, 127, 128, 129, 256
   (around the typical PARTITION_SIZE boundary).
8. **differential_against_reference**: 32 random trials at random sizes
   in `[1, 256]`. All match within fp64 tolerance.

The first seven exercise specific properties named in the Lean spec.
The eighth is a randomized sweep that catches anything the first
seven might miss.

## What this demo does NOT include

* A checked Lean theorem. The spec at `spec/AddNKI.lean` declares
  the contract (Mealy-machine convention, structural definitions)
  but the directory is not a Lake project so theorem bodies would
  be unchecked. The natural theorem pins are listed in the trailing
  comment of `AddNKI.lean`. They become checked theorems in the
  next iteration when this directory is hoisted to a sibling
  `examples/pure-rtl-roundtrip/`-style setup with a real Lake
  project.

* Tile-independence under arbitrary partitioning. Element-wise add
  is trivially tile-independent because there are no cross-tile
  effects, but the next-iteration spec adds a tile-independence
  theorem that holds under any legal decomposition. That pin is
  named in the spec's trailing comment as the central claim
  Annapurna's runtime portability story rests on.

* Real Trainium hardware execution. This kernel does not compile
  through `neuronxcc.nki` or run on Trainium. It is a Python mock
  with the structural shape of an NKI port. A real Trainium-side
  reproduction replaces `kernel.py` with `nki.simulate_kernel(...)`
  against a true NKI-compiled kernel. The verification flow plus
  the dashboard render are identical; only the kernel-execution
  layer differs.

## Cross-references

* Sibling planted-bug bundle at
  `examples/customer/nki_planted_bug_demo/`. Same pipeline, opposite
  verdict.
* PureRTL methodology precedent at
  `examples/customer/toy_fifo_chain/spec/FifoWidget.lean`
  (silicon-block version of the Lean spec to executable image
  bridge).
* SDK adapter `kairos.nki.run_bundle` (see `src/kairos/nki/`).
* Customer-facing dashboard: `/analytics/nki-kernels/[run_id]`.
