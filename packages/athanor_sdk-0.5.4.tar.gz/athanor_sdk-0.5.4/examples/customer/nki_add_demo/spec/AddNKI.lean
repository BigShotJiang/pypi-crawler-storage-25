/-
  AddNKI.lean — Lean source-of-truth for an element-wise add NKI
  kernel.

  This is the simplest possible end-to-end demonstration of the
  Lean → Clash-style-bridge → executable image methodology applied
  to NKI: a per-element pure function whose tile decomposition is
  trivial and whose contract is auditable in a single screenful.

  Methodology shared with examples/customer/toy_fifo_chain/spec/
  (silicon block) and examples/pure-rtl-roundtrip/Spec.lean
  (cpu_adder demo): every block is a pure function over a register
  record (or, in NKI's case, a tile shape). Lean is the contract;
  Python (mocking what real Clash-extracted-NKI would emit) is the
  manually-bridged executable image; the verification harness
  validates differential equivalence against a numerically-correct
  reference implementation.

  Customer claim contracted by this spec: for any input tile-pair
  (a : Vec n) (b : Vec n), the kernel produces an output tile c
  where c[i] = a[i] + b[i] for every valid index i. No tile-boundary
  effects, no accumulator state, no rounding past the underlying
  numeric type's epsilon.

  v0 limitations (intentional, documented):

  1. **Spec directory is not a Lake project.** Theorem bodies would
     be unchecked, so they're omitted in v0 and the natural pins
     listed in trailing comments.

  2. **Manual Lean → Python bridge.** The Python kernel mock at
     ../kernel.py is hand-authored to mirror this Lean spec verbatim.
     The bridge is auditable by inspection; full automation via
     kairos.pure_rtl.lean_extractor's NKI fork is the next iteration.

  3. **Numeric type is `Float` (Lean's IEEE-754 binding).** Real NKI
     kernels target `bf16` / `fp16` / `fp32` / `fp8` per kernel-class.
     The spec is parametric over the numeric type; the v0 instance
     uses Float to keep the contract type-uniform with the reference
     PyTorch implementation in ../verify.py.
-/

namespace AddNKI

/-- Tile shape: a vector of `n` elements of type `T`. NKI's tile-PSUM
    pattern decomposes (M, K) inputs into PARTITION_SIZE-wide tiles;
    for element-wise add the tile is one-dimensional and the
    partition dimension is irrelevant. The contract holds per-element
    regardless of how the runtime tiles. -/
structure Tile (T : Type) (n : Nat) where
  data : Array T
  size_eq : data.size = n
  deriving Repr

/-- Inputs at one kernel invocation: two tiles of equal shape. -/
structure Input (T : Type) (n : Nat) where
  a : Tile T n
  b : Tile T n
  deriving Repr

/-- Outputs at one kernel invocation: one tile of the same shape. -/
structure Output (T : Type) (n : Nat) where
  c : Tile T n
  deriving Repr

/--
  Element-wise add at index `i`. Pure, total over valid indices.

  This is the per-element correctness predicate. The Lean kernel
  function below applies it to every index in [0, n).
-/
def addAt {T : Type} [Add T] (a b : Tile T n) (i : Fin n) : T :=
  a.data[i.val]'(by rw [a.size_eq]; exact i.isLt) +
  b.data[i.val]'(by rw [b.size_eq]; exact i.isLt)

/--
  The kernel function: for input tiles `a` and `b` of shape `n`,
  produce output tile `c` where `c[i] = a[i] + b[i]` for every i.

  Specified as a pure function from `Input T n` to `Output T n`.
  No state, no tile-boundary effects, no rounding past the
  underlying numeric type's epsilon (which the spec inherits from
  `Add T`).

  The Python mock at ../kernel.py implements this contract
  one-to-one: a single loop computing `out[i] = a[i] + b[i]`.
-/
def kernel {T : Type} [Add T] [Inhabited T] (inp : Input T n) : Output T n :=
  let cData : Array T := Array.ofFn (n := n) (fun i =>
    addAt inp.a inp.b i)
  ⟨⟨cData, by simp [Array.size_ofFn]⟩⟩

/-
  Theorems / proofs intentionally NOT in this file: the spec
  directory does not currently host a Lake project, so any theorem
  body would be unchecked. The structural ``kernel`` definition above
  is the contract. When this directory is upgraded to a Lake project
  (or moved into ``examples/pure-rtl-roundtrip/``-style setup), the
  natural pins are:

  * ``∀ inp i, (kernel inp).c.data[i] = addAt inp.a inp.b i``
    -- per-element identity (the central correctness claim)

  * ``∀ inp, (kernel inp).c.size_eq = inp.a.size_eq``
    -- output shape preserved

  * ``∀ inp i, addAt inp.a inp.b i = addAt inp.b inp.a i``
    (when ``[CommGroup T]`` or ``[CommSemigroup T]`` available)
    -- input commutativity at the per-element level

  * ``∀ a b, kernel ⟨a, b⟩ = kernel ⟨b, a⟩``
    (when ``[Add T]`` is commutative)
    -- whole-kernel commutativity

  * ``∀ inp, ∀ k m, (kernel ⟨inp.a, inp.b⟩).c.data[k] =
                     (kernel ⟨inp.a.tileAt k m, inp.b.tileAt k m⟩).c.data[0]``
    -- TILE-INDEPENDENCE: kernel result at index k under any
    legal tile decomposition equals the result at index 0 of the
    sub-tile starting at k. This is the central pin for
    Annapurna's claim that NKI tile-PSUM tiling preserves semantics.

  These are the obligations the hand-authored Python mock was
  reviewed against; making them checked theorems is the natural
  next iteration after the spec directory is hoisted to a Lake
  project. The tile-independence pin in particular is what
  separates 'correct on tile boundaries chosen at compile time'
  from 'correct under any legal tile-decomposition the runtime
  picks' — a real customer concern when the same kernel runs
  across Trainium SKUs with different SBUF sizes.
-/

end AddNKI
