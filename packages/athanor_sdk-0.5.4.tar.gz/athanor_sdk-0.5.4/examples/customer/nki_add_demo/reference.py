"""reference.py — numerically-correct element-wise tile add.

Same operation as ``kernel.py``, written without any tile-PSUM
pretense. ``verify.py`` differentials kernel.py's output against
this implementation for property-based and randomized inputs.
"""
from __future__ import annotations

from typing import Sequence


def reference(a: Sequence[float], b: Sequence[float]) -> list[float]:
    """Element-wise add: ``y[i] = a[i] + b[i]``."""
    if len(a) != len(b):
        raise ValueError(f"input tiles must have equal shape: {len(a)} vs {len(b)}")
    return [x + y for x, y in zip(a, b)]
