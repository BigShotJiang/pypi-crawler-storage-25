"""kernel.py — element-wise tile add, manually-bridged from AddNKI.lean.

Mirrors the Lean spec at ``spec/AddNKI.lean`` one-to-one. For the
v0 demonstration this is a Python mock with the structural shape
of an NKI tile-PSUM port; the real customer-side equivalent uses
``neuronxcc.nki.simulate_kernel`` against a true NKI-compiled
kernel. The verification + bridge audit shape is identical.

Bridge contract (read alongside spec/AddNKI.lean):

* ``addAt(a, b, i) -> a[i] + b[i]``       -- per-element op
* ``kernel((a, b)) -> c`` where ``c[i] = addAt(a, b, i)`` for every
  valid index ``i``                        -- whole-tile op

Both functions are pure, total over valid indices, and have no
tile-boundary effects: the Lean ``addAt`` doesn't see `i` as a
tile-relative index, and neither does the Python implementation.
This is the simplest correctness shape in the NKI catalog and is
intended to set the precedent for the W3-W6 5-kernel pilot.
"""
from __future__ import annotations

from typing import Sequence


def add_at(a: Sequence[float], b: Sequence[float], i: int) -> float:
    """Element-wise add at index ``i``. Pure, total over valid indices."""
    return a[i] + b[i]


def kernel(a: Sequence[float], b: Sequence[float]) -> list[float]:
    """Element-wise tile add: returns ``c`` where ``c[i] = a[i] + b[i]``.

    Mirrors :func:`AddNKI.kernel` from the Lean spec verbatim:
    one loop, per-element apply, no tile-boundary state.

    :raises ValueError: when input tiles have different shapes.
    """
    if len(a) != len(b):
        raise ValueError(f"input tiles must have equal shape: {len(a)} vs {len(b)}")
    return [add_at(a, b, i) for i in range(len(a))]
