# Lean specs for toy_fifo_chain (Phase 2)

Lean source-of-truth contracts for the two non-arbiter widgets
(`fifo_widget` + `add_header`) on Todd's `toy_fifo_chain.sv` demo.
Phase 2 of the per-widget discharge pipeline (Phase 1 was the
hand-authored Clash gate at `../clash_gates/`).

## Trust shift

Before this directory:

- `../clash_gates/FifoWidget.hs` and `../clash_gates/AddHeader.hs`
  were hand-authored by an Athanor engineer.
- The customer-facing claim was *"the gate is what an Athanor
  engineer wrote, take our word for it."*
- Auditors had to read Haskell to understand the contract.

After this directory:

- `FifoWidget.lean` and `AddHeader.lean` are the customer-auditable
  source-of-truth contracts.
- The Phase 1 `.hs` files in `../clash_gates/` are the manually
  bridged executable images of the same contracts -- one-to-one
  structural correspondence by inspection.
- The customer-facing claim is now *"the contract is in this Lean
  file (you can read it), the Clash gate is the manually-bridged
  executable form (you can audit the bridge by inspection), and EQY
  proves the original SV implements the contract structurally."*

## Files

| File | What it is |
|---|---|
| `FifoWidget.lean` | Mealy-machine contract for the FIFO. Mirrors the count-only Phase-1.5 simplification. |
| `AddHeader.lean` | Pure-function contract for the packet-header transform. |

## Reset polarity contract (ATH-975)

The Lean spec uses canonical Bool semantics: `Input.rst : Bool`
where `rst = True` means reset is asserted. The SV widget uses
`rst_n` (active-low: `rst_n = 0` means asserted). The Clash gate
at `../clash_gates/FifoWidget.hs` inverts at the SV-port boundary
via `unsafeFromActiveLow`, so the Lean spec stays in canonical
form. The bridge audit confirms: when SV `rst_n = 0` AND Lean
`rst = True`, both produce the same next-state (count = 0,
empty = True, full = False). The polarity inversion is mechanical
and lives in one place (the Clash topEntity boundary).

## v0 limitations (intentional, documented)

1. **Spec directory is not a Lake project.** Theorem bodies would be
   unchecked, so they're omitted in v0 and the natural pins listed
   in trailing comments. Future iteration: hoist these specs into a
   sibling `examples/pure-rtl-roundtrip/`-style setup with a real
   Lake project + checked theorems.

2. **Manual Lean → Clash bridge.** The `.hs` files in
   `../clash_gates/` were authored by hand to mirror these `.lean`
   files. The bridge is auditable by inspection; full automation via
   `kairos.pure_rtl.lean_extractor` lands in a future ticket.

3. **FIFO state is ring-buffer faithful (ATH-976 update).** Earlier
   iterations of this spec used a count-only state machine with
   passthrough `pop_data = push_data`, matching the v0 Clash gate;
   the matching simplification produced REFUTED counter-examples
   from EQY against the SV gold. The current spec models the real
   SV body: `mem` array + `head` + `tail` + `count` registers; push
   writes `mem[tail & 3]`; pop reads `mem[head & 3]`
   combinationally; SV last-assignment-wins idiom on simultaneous
   push + pop preserved.

4. **Arbiter not specified.** `arb_widget` round-robin per-source
   ordering is a temporal property; EQY is the wrong tool. Stays
   gated in `../certificate_stub.md` with the per-source-ordering
   caveat. A separate Lean spec + temporal-property checker is the
   right shape for the arbiter discharge.

## Next iteration

When this directory upgrades to a Lake project + checked theorems:

- Promote the trailing-comment obligations in each `.lean` to
  actual theorems with proofs.
- Wire `kairos.pure_rtl.lean_extractor` to consume these specs +
  generate the Clash side automatically (deletes `../clash_gates/`).
- Run `kairos.eqy.verify` per-instance against the SV body; flip
  the corresponding `obligations.json` entry from `gated_on_eqy` to
  `discharged`.

## Cross-refs

- `../certificate_stub.md` -- per-path certificate language.
- `../obligations.json` -- per-widget obligation enumeration.
- `../clash_gates/` -- platform's Phase 1 hand-authored Clash gates.
- `../discharge_obligations.py` -- platform's discharge orchestrator.
- `examples/pure-rtl-roundtrip/Spec.lean` -- the methodology
  precedent (Todd 2026-05-01 Mealy-machine framing).
