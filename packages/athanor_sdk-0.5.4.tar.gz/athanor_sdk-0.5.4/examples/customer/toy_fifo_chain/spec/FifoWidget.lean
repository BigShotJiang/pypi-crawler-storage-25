/-
  FifoWidget.lean -- Lean source-of-truth for the toy_fifo_chain
  fifo_widget block.

  ATH-976 Phase 2 (faithful ring-buffer): this file extends the
  prior count-only v0 spec to model the SV fifo_widget block
  faithfully -- mem array + head + tail + count registers, with
  push writing mem[tail & 3] and pop reading mem[head & 3]. The
  matching Clash gate at ../clash_gates/FifoWidget.hs is extended
  with the same ring-buffer state so EQY discharge against the SV
  gold flips from REFUTED -> discharged.

  Methodology shared with examples/pure-rtl-roundtrip/Spec.lean
  (cpu_adder demo): every block is a Mealy machine
  ``step : (state, inputs) -> (state', outputs)`` over a register
  record ``REG``. Lean is the contract; Clash is the codegen target;
  EQY proves the regenerated RTL equivalent to the original.

  Customer claim contracted by this spec: data presented at push
  port is stored at the tail position of the ring buffer; data
  released at pop port is read from the head position; full / empty
  / count signals are consistent with the documented capacity bound
  (DEPTH=4). Path-A forwarding-identity in the certificate stub
  at ../certificate_stub.md cites this contract as its source.

  Reset polarity: the Lean spec uses canonical ``rst : Bool`` (asserted
  = True). The Clash gate at ../clash_gates/FifoWidget.hs inverts
  active-low SV ``rst_n`` at the topEntity boundary via
  ``unsafeFromActiveLow`` so the Lean stays canonical (ATH-975).
-/

namespace FifoWidget

/-- Capacity of the ring buffer. The SV ``fifo_widget`` is
    parameterised with ``DEPTH = 4`` for the toy demo; this Lean
    spec hardcodes the same depth so the bridge is one-to-one with
    the Phase-1.8 Clash gate (which Synthesize-annotates a single
    DEPTH=4 instance per asabi simplification). -/
def DEPTH : Nat := 4

/-- Pointer mask: ``head[$clog2(DEPTH)-1:0]`` in SV. For DEPTH=4,
    that's ``head & 3``. Hoisted as a definition so the bridge
    audit checks it once. -/
def ptrMask (p : UInt8) : Nat := p.toNat % DEPTH

/-- Register state mirrored from SV ``fifo_widget`` body:

    * ``mem``   -- DEPTH-wide array of 32-bit packet bodies. The SV
      type is ``T mem [DEPTH]`` with T parameterised; the toy demo
      uses ``packet_t`` which is 28 bits (id 8 + payload 16 + tag 4)
      widened to ``UInt32`` (32 bits) on the Clash side per the
      Phase-1 widening convention.
    * ``head`` -- read pointer; wraps at DEPTH via ``ptrMask``.
    * ``tail`` -- write pointer; same wrap.
    * ``count`` -- occupancy counter; saturates at DEPTH.

    All three pointer / counter fields are 3-bit (``[$clog2(DEPTH):0]``
    in SV) and stored as ``UInt8`` here for the smallest-convenient-
    carrier convention shared with the cpu_adder Spec.lean. -/
structure REG where
  mem   : Array UInt32  -- length DEPTH; v0 enforced by init / step
  head  : UInt8
  tail  : UInt8
  count : UInt8
  deriving Repr

/-- Inputs at one clock edge.

    ATH-975 sync: ``rst : Bool`` mirrors the SV ``rst_n`` reset port
    semantically (Lean canonical convention: ``rst = True`` means
    reset is asserted; the SV / Clash boundary inverts the
    active-low ``rst_n`` to match this canonical sense). -/
structure Input where
  rst       : Bool
  push      : Bool
  pushData  : UInt32  -- packet_t body widened to 32 bits
  pop       : Bool
  deriving Repr

/-- Outputs at one clock edge. -/
structure Output where
  popData : UInt32
  full    : Bool
  empty   : Bool
  deriving Repr

/-- Initial register state at reset: empty buffer, head and tail
    at position 0, count 0. The mem array is zero-initialised; the
    SV gold leaves uninitialised garbage in mem until the first
    push, but the count==0 invariant means an EQY consumer that
    respects the empty signal cannot observe the difference. -/
def init : REG :=
  { mem   := Array.mkArray DEPTH 0
  , head  := 0
  , tail  := 0
  , count := 0 }

/--
  Step function: pure F : (REG, Input) -> (REG, Output).

  Mirrors the SV ``fifo_widget`` always_ff body faithfully:

  ``pop_data`` is combinational (assign) and reads the current
  ``mem[head & 3]`` BEFORE the clock-edge update. The count signal
  uses the SV last-assignment-wins idiom: when push and pop fire
  in the same cycle, the explicit ``count <= count`` line at the
  end of the always_ff block wins over the conditional
  ``count <= count +/- 1`` lines.

  Reset path: ``inp.rst = True`` (canonical sense; SV ``rst_n = 0``
  via the Clash gate's ``unsafeFromActiveLow``) clears head, tail,
  count to 0. mem is left as-is (matches SV: only head/tail/count
  reset).
-/
def step (reg : REG) (inp : Input) : REG × Output :=
  -- Combinational outputs first (read pre-edge state).
  let isFull   : Bool   := reg.count = (DEPTH.toUInt8)
  let isEmpty  : Bool   := reg.count = 0
  let popData  : UInt32 := reg.mem.getD (ptrMask reg.head) 0
  let outputs  : Output := { popData := popData, full := isFull, empty := isEmpty }
  if inp.rst then
    -- Reset path: clear pointers + count; mem left alone (matches SV).
    ({ mem := reg.mem, head := 0, tail := 0, count := 0 }, outputs)
  else
    let pushEff : Bool := inp.push && !isFull
    let popEff  : Bool := inp.pop  && !isEmpty
    let mem'    : Array UInt32 :=
      if pushEff then reg.mem.set! (ptrMask reg.tail) inp.pushData
                 else reg.mem
    let head'   : UInt8 := if popEff  then reg.head + 1 else reg.head
    let tail'   : UInt8 := if pushEff then reg.tail + 1 else reg.tail
    -- count: SV last-assignment-wins. Simultaneous push+pop holds
    -- count steady; otherwise +1 on push-only, -1 on pop-only.
    let count'  : UInt8 :=
      if pushEff && popEff then reg.count
      else if pushEff then reg.count + 1
      else if popEff  then reg.count - 1
      else reg.count
    ({ mem := mem', head := head', tail := tail', count := count' }, outputs)

/-
  Theorems / proofs intentionally NOT in this file: the spec
  directory does not currently host a Lake project, so any theorem
  body would be unchecked. The structural ``step`` definition above
  is the contract. Natural pins for the future Lake-project
  iteration:

  * ``init.count = 0``                                                -- reset establishes empty
  * ``∀ reg inp, ¬(out.empty ∧ out.full)``                            -- mutual exclusion
  * ``∀ reg inp, count' ≤ DEPTH``                                     -- capacity bound preserved
  * ``∀ reg inp, inp.rst -> (step reg inp).fst.count = 0``            -- reset clears count (ATH-975)
  * ``∀ reg inp, inp.rst -> (step reg inp).snd.empty = true``         -- reset reports empty (ATH-975)
  * ``∀ reg inp, ¬inp.rst ∧ pushEff -> mem'[tail & 3] = pushData``    -- push writes mem (ATH-976)
  * ``∀ reg inp, ¬inp.rst ∧ popEff -> popData = mem[head & 3]``       -- pop reads mem (ATH-976)
  * ``∀ reg inp, mem.size = DEPTH``                                   -- buffer length invariant (ATH-976)

  These are the obligations the Phase-2 Clash gate is reviewed
  against; making them checked theorems is the natural next
  iteration after the ring-buffer Lean → Clash bridge lands and
  EQY discharge flips REFUTED -> discharged on the toolchain-installed
  runner.
-/

end FifoWidget
