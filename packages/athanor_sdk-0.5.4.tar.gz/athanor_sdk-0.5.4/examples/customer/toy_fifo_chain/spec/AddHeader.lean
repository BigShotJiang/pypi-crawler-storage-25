/-
  AddHeader.lean -- Lean source-of-truth for the toy_fifo_chain
  add_header transform on Path B.

  Phase 2 lane (post-ATH-946 Phase 1 hand-authored Clash gate):
  the Lean spec is the customer-auditable contract; the Clash gate
  at ../clash_gates/AddHeader.hs is the manually-bridged executable
  image. EQY proves that the original SV ``add_header`` function
  on Path B implements the contract structurally.

  add_header is a pure combinational transform (no register state)
  that prepends a 16-bit header field to a 32-bit packet body. Its
  combinational nature means the Mealy-machine framing degenerates
  to a pure function ``Input -> Output``; a trivial unit-state
  ``REG`` is included for shape-consistency with the FIFO spec
  next to it.

  Customer claim contracted by this spec: for every packet body
  ``b`` and header value ``h``, the output is the concatenation
  ``b || h`` -- field preservation is explicit because the type
  changes from ``packet_t`` (32 bits) to ``packet_hdr_t`` (48 bits).
  Path-B partial-integrity in the certificate stub at
  ../certificate_stub.md cites this contract as its source.
-/

namespace AddHeader

/-- Trivial unit-state register record. add_header is purely
    combinational; the unit state keeps the structural shape
    consistent with the sibling FifoWidget spec. -/
structure REG where
  unit : Unit := ()
  deriving Repr

/-- Inputs at one clock edge. -/
structure Input where
  body : UInt32  -- 32-bit packet body (id || payload || tag, packed)
  hdr  : UInt32  -- 16-bit header value, low half used; widened to UInt32
  deriving Repr

/-- Outputs at one clock edge. -/
structure Output where
  packed : UInt64  -- 48-bit (body || hdr_low_16) widened to UInt64 carrier
  deriving Repr

/-- Initial register state. -/
def init : REG := { }

/--
  Step function: pure F : (REG, Input) -> (REG, Output).

  Mirrors the Phase 1 Clash gate body verbatim:
  - ``out = (body || hdr)`` -- bit-level concatenation
  - hdr is the low 16 bits of the input ``hdr`` widened
  - state is unit (no registers)

  The bit-concatenation is encoded here as an arithmetic shift +
  OR which the Clash codegen expresses as ``body ++# hdr``. EQY
  matches the structural shape on the SV side.
-/
def step (reg : REG) (inp : Input) : REG × Output :=
  let bodyU64  : UInt64 := inp.body.toUInt64
  let hdrLowU64 : UInt64 := inp.hdr.toUInt64 &&& 0xFFFF
  let packed : UInt64 := (bodyU64 <<< 16) ||| hdrLowU64
  (reg, { packed := packed })

/-
  Theorems / proofs intentionally NOT in this file (matching the
  sibling FifoWidget.lean): the spec directory is a contract source,
  not a Lake project. The natural pins for a future checked
  iteration:

  * ``∀ reg inp, (step reg inp).snd.packed >>> 16 = body_widened``
    -- field preservation of the body half.
  * ``∀ reg inp, (step reg inp).snd.packed &&& 0xFFFF = hdr & 0xFFFF``
    -- field preservation of the header half.
  * ``∀ reg inp, (step reg inp).fst = reg``
    -- combinational: state is invariant.

  These obligations are the customer-readable claim; the Phase 1
  Clash gate at ../clash_gates/AddHeader.hs is the executable image
  to which EQY discharges them.
-/

end AddHeader
