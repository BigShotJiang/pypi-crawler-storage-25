"""ATH-946 Phase 1: discharge gated_on_eqy obligations + reclassify temporal-property obligations.

Phase 1 (this PR):
  1. Reclassify arb_widget round-robin obligations from gated_on_eqy to
     gated_on_temporal_verifier (per asabi 2026-05-04: temporal claims discharge
     via k-induction or BMC, not EQY combinational equivalence).
  2. Wire the discharge orchestrator end-to-end: Clash compile (cabal v2-exec)
     + EQY config + invocation + status flip.
  3. Hand-authored Clash gates (clash_gates/) — fixed-DEPTH=4, plain Signal dom T,
     reviewed-by-engineer (not Lean-extracted).

Real bottleneck found during Phase 1 end-to-end: Yosys 0.44 cannot parse SV
files using `parameter type T = packet_t` or `function ... return result`
inline-struct returns. EQY's read_gold step fails before SAT runs. The Phase 1
gates compile to Verilog correctly via Clash + cabal; the gold side needs
SV-source preprocessing (kairos.sv.flatten doesn't yet strip type-parameters).

Status enum after Phase 1:
  - "ready"                              — mechanical discharge (11 obligations, unchanged)
  - "discharged_against_handauthored_clash" — Phase 1 success (0 today, blocked)
  - "gated_on_temporal_verifier"         — temporal property, EQY wrong tool (1 obligation)
  - "gated_on_yosys_sv_parse"            — Yosys SV-syntax gap (filed as Phase 1.5 follow-up)
  - "extraction_failed"                  — Clash compile failed (0 today)
  - "refuted_by_eqy"                     — EQY counter-example (0 today)

Phase 1.5 (immediate next, ATH-NNN): SV-source preprocessing to make
toy_fifo_chain.sv yosys-parseable (strip type-parameters, flatten function-with-
struct-return). Once that lands, Phase 1's discharge orchestrator runs end-to-end
against the 8 fifo_widget + 1 add_header obligations.

Phase 2 (separate ATH): replace hand-authored Clash with Clash extracted from
customer-supplied Lean specs via kairos.pure_rtl.lean_extractor.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

EXAMPLE_DIR = Path(__file__).resolve().parent
OBLIGATIONS_PATH = EXAMPLE_DIR / "obligations.json"
CLASH_GATES_DIR = EXAMPLE_DIR / "clash_gates"

_GATE_MAP = {
    "fifo_widget": ("FifoWidget.hs", "fifo_widget"),
    "add_header":  ("AddHeader.hs",  "add_header"),
}

_TEMPORAL_GATE = {
    "arb_widget": (
        "round-robin per-source ordering is a temporal property over N cycles; "
        "EQY does combinational equivalence — temporal claims discharge via "
        "k-induction or BMC (kairos.sv.ebmc) instead. Different verifier class."
    ),
}


def _toolchain_present() -> bool:
    return all(shutil.which(t) for t in ("yosys", "clash", "eqy"))


def _compile_clash_gate(gate_hs: Path, work_dir: Path, top: str) -> Path | None:
    work_dir.mkdir(parents=True, exist_ok=True)
    cabal_project = CLASH_GATES_DIR
    try:
        subprocess.run(
            ["cabal", "v2-exec", "clash", "--", "--verilog", gate_hs.name],
            cwd=cabal_project, check=True, timeout=180, capture_output=True,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None
    # Phase 1.8: Synthesize annotation produces verilog/<Module>.<top>/<top>.v
    # Match the file by the top name rather than picking [0].
    verilog = list((cabal_project / "verilog").glob(f"**/{top}.v"))
    return verilog[0] if verilog else None


def _flatten_sv(sv_path: Path, work_dir: Path) -> Path | None:
    """Run kairos.sv.flatten on the SV gold to strip type-params + functions.

    Returns the flattened .sv path or None if flatten itself fails. When None,
    caller flips obligation status to flatten_failed so the customer sees the
    explicit failure-mode classification.
    """
    try:
        from kairos.sv.flatten import flatten_file
        flat = flatten_file(str(sv_path))
        # Additional Yosys-compat preprocessing (type-params, function-returns-struct)
        # not yet in kairos.sv.flatten (filed as Phase 1.5 follow-up).
        import re
        flat = re.sub(r'^\s*parameter\s+type\s+(\w+)\s*=\s*(\w+)\s*,?\s*$', '', flat, flags=re.MULTILINE)
        out = work_dir / sv_path.name
        out.write_text(flat)
        return out
    except Exception:
        return None


def _yosys_can_parse(sv_path: Path, top: str) -> bool:
    """Quick probe: can yosys read this SV + select a top? Returns False if SV
    uses parameter-types or function-returns-struct that yosys 0.44 doesn't
    support."""
    try:
        result = subprocess.run(
            ["yosys", "-p", f"read -sv {sv_path}; hierarchy -check -top {top}"],
            capture_output=True, timeout=30, text=True,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def _run_eqy(gold_sv: Path, gate_v: Path, work_dir: Path, top: str) -> str:
    eqy_outdir = work_dir / "discharge"
    if eqy_outdir.exists():
        shutil.rmtree(eqy_outdir)
    eqy_config = work_dir / "discharge.eqy"
    # Rename Clash's topEntity → gold's module name so EQY's combine
    # step accepts both as the same logical top.
    # Phase 1.8: Clash gates have Synthesize annotations producing
    # modules named after the SV widget (fifo_widget, add_header).
    # No rename needed — gate already uses the correct top.
    eqy_config.write_text(f"""[gold]
read -sv {gold_sv.name}
prep -top {top}

[gate]
read -sv {gate_v.name}
prep -top {top}

[strategy basic]
use sat
depth 4
""")
    if gold_sv.resolve() != (work_dir / gold_sv.name).resolve():
        shutil.copy(gold_sv, work_dir / gold_sv.name)
    if gate_v.resolve() != (work_dir / gate_v.name).resolve():
        shutil.copy(gate_v, work_dir / gate_v.name)
    try:
        result = subprocess.run(
            ["eqy", "--jobs", "1", "discharge.eqy"],
            cwd=work_dir, capture_output=True, timeout=300, text=True,
        )
        if result.returncode == 0:
            return "discharged"
        if "FAIL" in result.stdout or "FAIL" in result.stderr:
            return "refuted"
        return "error"
    except subprocess.TimeoutExpired:
        return "error"


def main() -> int:
    if not OBLIGATIONS_PATH.is_file():
        print(f"obligations.json not found at {OBLIGATIONS_PATH}")
        return 1

    data = json.loads(OBLIGATIONS_PATH.read_text())
    obligations = data["obligations"]
    instances = {i["name"]: i for i in data["instances"]}

    if not _toolchain_present():
        print("Clash + Yosys + EQY not on PATH. Run scripts/install-purertl-toolchain.sh first.")
        return 1

    print(f"[ath-946-discharge] {len(obligations)} obligations; toolchain installed")
    discharged = 0
    refuted = 0
    temporal_gated = 0
    yosys_gated = 0
    extraction_failed = 0
    still_gated = 0

    sv_parseable_cache: dict[str, bool] = {}

    for o in obligations:
        if o["status"] != "gated_on_eqy":
            continue
        widget = o["widget"]
        instance = instances.get(widget, {})
        module = instance.get("module", "")

        if module in _TEMPORAL_GATE:
            o["status"] = "gated_on_temporal_verifier"
            o["rationale_phase1"] = _TEMPORAL_GATE[module]
            temporal_gated += 1
            print(f"  {o['id']}: gated_on_temporal_verifier ({module})")
            continue

        if module not in _GATE_MAP:
            still_gated += 1
            print(f"  {o['id']}: no gate available for {module!r}")
            continue

        work_dir = EXAMPLE_DIR / "_discharge_work" / o["id"]
        work_dir.mkdir(parents=True, exist_ok=True)

        # Preprocess gold SV via kairos.sv.flatten (composes the existing
        # battle-tested EBMC preprocessing into the EQY pipeline). Per asabi
        # 2026-05-04: flatten will run on Phase 2's Clash-extracted Verilog
        # too — symmetric preprocessing across the gold/gate pair.
        raw_gold = EXAMPLE_DIR / "toy_fifo_chain.sv"
        gold_sv = _flatten_sv(raw_gold, work_dir)
        if gold_sv is None:
            o["status"] = "flatten_failed"
            o["rationale_phase1"] = "kairos.sv.flatten threw on gold SV preprocessing"
            extraction_failed += 1
            print(f"  {o['id']}: flatten_failed")
            continue

        # Probe yosys against the MODULE name, not the instance name
        # (`widget` in obligations.json is the instance like `fifo_1`).
        if module not in sv_parseable_cache:
            sv_parseable_cache[module] = _yosys_can_parse(gold_sv, module)
        if not sv_parseable_cache[module]:
            o["status"] = "gated_on_yosys_sv_parse"
            o["rationale_phase1"] = (
                "Even after kairos.sv.flatten, Yosys 0.44 cannot parse this "
                "SV widget. Phase 1.5 follow-up: extend flatten to handle "
                "function-returns-struct + remaining parameter-type cases."
            )
            yosys_gated += 1
            print(f"  {o['id']}: gated_on_yosys_sv_parse")
            continue

        gate_file, gate_top = _GATE_MAP[module]
        gate_hs = CLASH_GATES_DIR / gate_file
        if not gate_hs.is_file():
            o["status"] = "extraction_failed"
            o["rationale_phase1"] = f"hand-authored gate {gate_file} not found"
            extraction_failed += 1
            print(f"  {o['id']}: extraction_failed (no gate file)")
            continue

        verilog = _compile_clash_gate(gate_hs, work_dir, top=module)
        if verilog is None:
            o["status"] = "extraction_failed"
            o["rationale_phase1"] = "Clash compile failed"
            extraction_failed += 1
            print(f"  {o['id']}: extraction_failed (clash compile)")
            continue

        verdict = _run_eqy(gold_sv, verilog, work_dir, top=module)
        if verdict == "discharged":
            o["status"] = "discharged_against_handauthored_clash"
            o["rationale_phase1"] = (
                "EQY-verified equivalent to hand-authored Clash reference module; "
                "the reference module is reviewed-by-engineer, not extracted from a Lean spec"
            )
            discharged += 1
            print(f"  {o['id']}: DISCHARGED (vs {gate_file})")
        elif verdict == "refuted":
            o["status"] = "refuted_by_eqy"
            o["rationale_phase1"] = "EQY found a counter-example"
            refuted += 1
            print(f"  {o['id']}: REFUTED")
        else:
            o["status"] = "extraction_failed"
            o["rationale_phase1"] = f"EQY error: {verdict}"
            extraction_failed += 1
            print(f"  {o['id']}: extraction_failed ({verdict})")

    data["toolchain_status"]["clash_yosys_eqy_installed"] = True
    data["toolchain_status"]["discharged_count"] = sum(
        1 for o in obligations if o["status"].startswith("discharged")
    )
    data["toolchain_status"]["temporal_gated_count"] = sum(
        1 for o in obligations if o["status"] == "gated_on_temporal_verifier"
    )
    data["toolchain_status"]["yosys_parse_gated_count"] = sum(
        1 for o in obligations if o["status"] == "gated_on_yosys_sv_parse"
    )
    data["toolchain_status"]["refuted_count"] = sum(
        1 for o in obligations if o["status"] == "refuted_by_eqy"
    )
    data["toolchain_status"]["extraction_failed_count"] = sum(
        1 for o in obligations if o["status"] == "extraction_failed"
    )
    data["toolchain_status"]["flatten_failed_count"] = sum(
        1 for o in obligations if o["status"] == "flatten_failed"
    )

    OBLIGATIONS_PATH.write_text(json.dumps(data, indent=2))
    print()
    print(f"=== Phase 1 discharge summary ===")
    print(f"  discharged:           {discharged}")
    print(f"  refuted:              {refuted}")
    print(f"  gated_on_temporal:    {temporal_gated}")
    print(f"  gated_on_yosys_parse: {yosys_gated}")
    print(f"  extraction_failed:    {extraction_failed}")
    print(f"  still_gated:          {still_gated}")
    print(f"obligations.json updated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
