"""Tests for examples/customer/toy_fifo_chain/pipeline_run.py.

Pins the contract that the obligations.json producer emits:

* All 9 module instances + the add_header synthetic function row.
* add_header has a non-empty module field (regression for platform's
  2026-05-04 discharge end-to-end finding: empty-module-field bug).
* paths[] covers all instances including add_header (Path B).
* obligations[] enumeration count + per-shape coverage.
"""
from __future__ import annotations

from pathlib import Path

import sys

# pipeline_run.py lives next to this test file, not on sys.path.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import pipeline_run  # noqa: E402


def test_parse_top_instances_yields_add_header_row():
    src = (_HERE / "toy_fifo_chain.sv").read_text()
    instances = pipeline_run.parse_top_instances(src, top_module="toy_fifo_chain")
    names = {inst.name for inst in instances}
    assert "add_header" in names, (
        "add_header function-call site must be present in instances[] "
        "so the discharge orchestrator can bind the OBL_path_B_add_header_"
        "translation obligation to a non-empty module field."
    )


def test_add_header_instance_has_non_empty_module():
    """Regression for platform's 2026-05-04 discharge end-to-end
    finding: add_header obligation referenced an instance with an
    empty ``module`` field.
    """
    src = (_HERE / "toy_fifo_chain.sv").read_text()
    instances = pipeline_run.parse_top_instances(src, top_module="toy_fifo_chain")
    add_header_rows = [i for i in instances if i.name == "add_header"]
    assert len(add_header_rows) == 1
    inst = add_header_rows[0]
    assert inst.module == "add_header"
    assert inst.module != ""


def test_paths_assigns_add_header_to_path_b():
    src = (_HERE / "toy_fifo_chain.sv").read_text()
    instances = pipeline_run.parse_top_instances(src, top_module="toy_fifo_chain")
    paths = pipeline_run.assign_paths(instances)
    assert paths["add_header"] == "B"


def test_full_pipeline_produces_21_obligations():
    """Full mechanical pipeline still produces the expected obligation
    enumeration (11 ready / 10 gated_on_eqy)."""
    src = (_HERE / "toy_fifo_chain.sv").read_text()
    instances = pipeline_run.parse_top_instances(src, top_module="toy_fifo_chain")
    paths = pipeline_run.assign_paths(instances)
    classifications = pipeline_run.classify(instances, transforms_on_path_b=True)
    obligations = pipeline_run.generate_obligations(
        instances, classifications, paths,
    )
    assert len(obligations) == 21
    ready = [o for o in obligations if o.status == "ready"]
    gated = [o for o in obligations if o.status == "gated_on_eqy"]
    assert len(ready) == 11
    assert len(gated) == 10


def test_no_duplicate_add_header_classification():
    """The path-B transform append fires once even though add_header
    is now an Instance (the in-loop classify() falls through fifo /
    arb_widget tests for module=='add_header' and the outside-loop
    transforms_on_path_b appends exactly once).
    """
    src = (_HERE / "toy_fifo_chain.sv").read_text()
    instances = pipeline_run.parse_top_instances(src, top_module="toy_fifo_chain")
    classifications = pipeline_run.classify(instances, transforms_on_path_b=True)
    add_header_class = [c for c in classifications if c.instance == "add_header"]
    assert len(add_header_class) == 1
    assert add_header_class[0].classification == "MODIFIES"
