{-# LANGUAGE DataKinds #-}
{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE NoImplicitPrelude #-}
{-# LANGUAGE TypeApplications #-}
-- ATH-976 Phase 2 + ATH-979 Phase 3 + ATH-983 W3: ring-buffer faithful
-- Clash gate for fifo_widget. Latest revision (W3) preserves
-- flop names from the SV gold so EBMC k-induction can map invariants
-- derived from the Clash graph back via flop-name correspondence.
-- Per Todd's 2026-05-04 directive: combinational signal names do not
-- matter for the SEC harness, only flops. The four state registers
-- below bind to the same Haskell-level names the SV gold uses for
-- its registers (head, tail, count, mem); Clash's default codegen
-- emits Verilog register declarations with the binding name verbatim,
-- producing ``wire [2:0] head;`` etc in the gate that match the
-- gold's ``logic [2:0] head;``.
--
-- Phase 3 implementation pattern (preserved): split state and output.
-- Four separate ``register`` instantiations carry mem / head / tail /
-- count. The output triple (pop_data, full, empty) is a combinational
-- function of the current register signals — mirrors the SV gold:
--
--   assign full     = (count == DEPTH);
--   assign empty    = (count == 0);
--   assign pop_data = mem[head[$clog2(DEPTH)-1:0]];
--
-- Earlier ``mealy mealyStep initState`` form caused EQY to refute the
-- 8 forwarding obligations on the v1 toy_fifo_chain demo because the
-- Clash codegen for the boxed Mealy combinator placed the output
-- behind a register-style boundary that did not match the SV gold's
-- pure combinational read.

module FifoWidget where

import Clash.Prelude
import Clash.Annotations.TopEntity
import Clash.XException (deepErrorX)
import Data.Bits ((.&.))
import Clash.Signal (unsafeFromActiveLow)

-- | Hand-authored Clash gate for fifo_widget. Generated Verilog ports
-- match SV gold exactly: (clk, rst_n, push, push_data, pop) ->
-- (pop_data, full, empty). rst_n is active-low matching SV.
--
-- Width = 28 matches the SV ``packet_t`` native width (id 8 +
-- payload 16 + tag 4 = 28 bits packed). The Lean spec carrier is
-- UInt32 for convenience; the bridge audit confirms 28-bit values
-- round-trip cleanly through the 32-bit carrier.
--
-- Phase 3 implementation pattern: split state and output. Four
-- separate ``register`` instantiations carry mem / head / tail /
-- count. The output triple (pop_data, full, empty) is a pure
-- combinational function of the current register signals — mirrors
-- the SV gold:
--
--   assign full     = (count == DEPTH);
--   assign empty    = (count == 0);
--   assign pop_data = mem[head[$clog2(DEPTH)-1:0]];
--
-- The ``always_ff @(posedge clk or negedge rst_n)`` body in the SV
-- gold maps one-to-one onto the four ``register`` next-state
-- expressions below.
topEntity
  :: Clock System
  -> Signal System Bool                    -- rst_n (active-low)
  -> Signal System Bool                    -- push
  -> Signal System (BitVector 28)          -- push_data
  -> Signal System Bool                    -- pop
  -> ( Signal System (BitVector 28)        -- pop_data
     , Signal System Bool                  -- full
     , Signal System Bool                  -- empty
     )
topEntity clk rst_n push pushData pop = (popData, full, empty)
  where
    rst = unsafeFromActiveLow rst_n

    -- Combinational guards from current register signals. ``full`` /
    -- ``empty`` are direct outputs (matching SV ``assign`` lines);
    -- ``pushEff`` / ``popEff`` gate the next-state arithmetic.
    --
    -- Note: combinational signal names (full, empty, pushEff, popEff,
    -- headIx, tailIx) are NOT subject to the flop-name-preservation
    -- requirement. Only flop registers (head, tail, count, mem)
    -- need to match the SV gold's register names verbatim.
    full    = fmap (== 4) count
    empty   = fmap (== 0) count
    pushEff = liftA2 (&&) push (fmap not full)
    popEff  = liftA2 (&&) pop  (fmap not empty)

    -- Pointer-to-index narrowing. SV: ``head[$clog2(DEPTH)-1:0]`` —
    -- take the lower 2 bits of the 3-bit pointer; the same pattern
    -- for ``tail``. ``fromIntegral . (.&. 3)`` produces an Index 4
    -- under ghc-8.8.4 without the ``CLog 2 4 ↔ 2`` unification snag
    -- the direct ``bitCoerce`` route hits.
    headIx :: Signal System (Index 4)
    headIx = fmap (fromIntegral . (.&. 3)) head
    tailIx :: Signal System (Index 4)
    tailIx = fmap (fromIntegral . (.&. 3)) tail

    -- Combinational output: ``pop_data = mem[head[1:0]]``. The
    -- output Signal is a pure ``liftA2`` of the current ``mem`` and
    -- ``headIx`` Signals — no extra register on the output path.
    popData = liftA2 (!!) mem headIx

    -- mem register: writes ``push_data`` into ``mem[tail[1:0]]`` on
    -- ``pushEff``; otherwise unchanged. SV last-assignment-wins is
    -- captured by the ``if pushEff then ... else mem``.
    --
    -- X-propagation alignment: SV declares ``T mem [DEPTH];`` with no
    -- initialization, so post-reset cells are X until the first
    -- write. The matching Clash idiom is ``deepErrorX`` for the
    -- register's reset value — generates an X bit-vector at synthesis
    -- time that the SEC engine can unify with SV's uninitialized
    -- cells via don't-care semantics. Only ``mem`` uses the X reset
    -- value; ``head`` / ``tail`` / ``count`` keep ``0`` because the
    -- SV gold explicitly assigns ``head <= '0;`` etc on ``!rst_n``.
    mem :: Signal System (Vec 4 (BitVector 28))
    mem = exposeClockResetEnable
            (register
               (deepErrorX "fifo_widget mem uninitialized at reset (matches SV)")
               memNext)
            clk rst enableGen
    memNext = (\m pe ti pd -> if pe then replace ti pd m else m)
            <$> mem <*> pushEff <*> tailIx <*> pushData

    -- head pointer (3-bit, wraps 0..7). Increments on ``popEff``.
    -- Bound name MUST be ``head`` (not ``hd``) so the Clash-emitted
    -- Verilog declares ``wire [2:0] head;`` matching the SV gold's
    -- ``logic [2:0] head;``. NoImplicitPrelude is enabled so the
    -- local binding does not collide with Clash.Prelude's ``head``.
    head :: Signal System (Unsigned 3)
    head = exposeClockResetEnable (register 0 headNext) clk rst enableGen
    headNext = (\h pe -> if pe then h + 1 else h) <$> head <*> popEff

    -- tail pointer (3-bit, wraps 0..7). Increments on ``pushEff``.
    -- Same flop-name-preservation rationale as ``head``.
    tail :: Signal System (Unsigned 3)
    tail = exposeClockResetEnable (register 0 tailNext) clk rst enableGen
    tailNext = (\t pe -> if pe then t + 1 else t) <$> tail <*> pushEff

    -- count register (3-bit). Simultaneous push+pop holds count
    -- steady; otherwise +/- 1. Matches SV last-assignment-wins
    -- ordering of the three ``count <= ...`` lines.
    count :: Signal System (Unsigned 3)
    count = exposeClockResetEnable (register 0 countNext) clk rst enableGen
    countNext = (\c pe po ->
                    if pe && po then c
                    else if pe  then c + 1
                    else if po  then c - 1
                    else c)
                <$> count <*> pushEff <*> popEff

{-# ANN topEntity
  (Synthesize
    { t_name   = "fifo_widget"
    , t_inputs =
        [ PortName "clk"
        , PortName "rst_n"
        , PortName "push"
        , PortName "push_data"
        , PortName "pop"
        ]
    , t_output = PortProduct ""
        [ PortName "pop_data"
        , PortName "full"
        , PortName "empty"
        ]
    }
  ) #-}
