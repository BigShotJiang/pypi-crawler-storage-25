#include <cstdlib>

#include <verilated.h>

#include "Vfifo_widget.h"

int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);

  Vfifo_widget *top = new Vfifo_widget;

  while(!Verilated::gotFinish()) {
    top->eval();
  }

  top->final();

  delete top;

  return EXIT_SUCCESS;
}

