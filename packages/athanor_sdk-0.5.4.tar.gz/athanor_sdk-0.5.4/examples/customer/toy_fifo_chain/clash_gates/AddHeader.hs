{-# LANGUAGE DataKinds #-}
{-# LANGUAGE NoImplicitPrelude #-}
-- ATH-946 Phase 1.8: Synthesize-annotated AddHeader gate matching SV
-- add_header function port-list. Pure combinational, no state.

module AddHeader where

import Clash.Prelude
import Clash.Annotations.TopEntity

-- | add_header: prepend hdr (8 bits) onto pkt body (28 bits) → 36-bit
-- packet_hdr_t. Pure function; matches the SV `function add_header`.
topEntity
  :: Signal System (BitVector 28)   -- pkt
  -> Signal System (BitVector 8)    -- hdr_val
  -> Signal System (BitVector 36)   -- result (pkt || hdr_val)
topEntity pkt hdr = liftA2 (\b h -> b ++# h) pkt hdr

{-# ANN topEntity
  (Synthesize
    { t_name   = "add_header"
    , t_inputs =
        [ PortName "pkt"
        , PortName "hdr_val"
        ]
    , t_output = PortName "result"
    }
  ) #-}
