module miter (
  input  [  0:0] \__pi_clk ,
  input  [  0:0] \__pi_empty ,
  input  [  0:0] \__pi_full ,
  input  [  0:0] \__pi_pop ,
  input  [  0:0] \__pi_push ,
  input  [ 27:0] \__pi_push_data ,
  input  [  0:0] \__pi_rst_n ,
`ifdef DIRECT_CROSS_POINTS
`else
`endif
  output [ 27:0] \__po_pop_data__gold ,
  output [ 27:0] \__po_pop_data__gate
);
  \gold.fifo_widget.pop_data gold (
    .\__pi_clk (\__pi_clk ),
    .\__pi_empty (\__pi_empty ),
    .\__pi_full (\__pi_full ),
    .\__pi_pop (\__pi_pop ),
    .\__pi_push (\__pi_push ),
    .\__pi_push_data (\__pi_push_data ),
    .\__pi_rst_n (\__pi_rst_n ),
`ifdef DIRECT_CROSS_POINTS
`else
`endif
    .\__po_pop_data (\__po_pop_data__gold )
  );
  \gate.fifo_widget.pop_data gate (
    .\__pi_clk (\__pi_clk ),
    .\__pi_empty (\__pi_empty ),
    .\__pi_full (\__pi_full ),
    .\__pi_pop (\__pi_pop ),
    .\__pi_push (\__pi_push ),
    .\__pi_push_data (\__pi_push_data ),
    .\__pi_rst_n (\__pi_rst_n ),
`ifdef DIRECT_CROSS_POINTS
`else
`endif
    .\__po_pop_data (\__po_pop_data__gate )
  );
`ifdef ASSUME_DEFINED_INPUTS
  miter_def_prop #(1, "assume") \__pi_clk__assume (\__pi_clk );
  miter_def_prop #(1, "assume") \__pi_empty__assume (\__pi_empty );
  miter_def_prop #(1, "assume") \__pi_full__assume (\__pi_full );
  miter_def_prop #(1, "assume") \__pi_pop__assume (\__pi_pop );
  miter_def_prop #(1, "assume") \__pi_push__assume (\__pi_push );
  miter_def_prop #(28, "assume") \__pi_push_data__assume (\__pi_push_data );
  miter_def_prop #(1, "assume") \__pi_rst_n__assume (\__pi_rst_n );
`endif
`ifndef DIRECT_CROSS_POINTS
`endif
`ifdef CHECK_MATCH_POINTS
`endif
`ifdef CHECK_OUTPUTS
  miter_cmp_prop #(28, "assert") \__po_pop_data__assert (\__po_pop_data__gold , \__po_pop_data__gate );
`endif
`ifdef COVER_DEF_CROSS_POINTS
  `ifdef DIRECT_CROSS_POINTS
  `else
  `endif
`endif
`ifdef COVER_DEF_GOLD_MATCH_POINTS
`endif
`ifdef COVER_DEF_GATE_MATCH_POINTS
`endif
`ifdef COVER_DEF_GOLD_OUTPUTS
  miter_def_prop #(28, "cover") \__po_pop_data__gold_cover (\__po_pop_data__gold );
`endif
`ifdef COVER_DEF_GATE_OUTPUTS
  miter_def_prop #(28, "cover") \__po_pop_data__gate_cover (\__po_pop_data__gate );
`endif
endmodule
module miter_cmp_prop #(parameter WIDTH=1, parameter TYPE="assert") (input [WIDTH-1:0] in_gold, in_gate);
  reg okay;
  integer i;
  always @* begin
    okay = 1;
    for (i = 0; i < WIDTH; i = i+1)
      okay = okay && (in_gold[i] === 1'bx || in_gold[i] === in_gate[i]);
  end
  generate
    if (TYPE == "assert") always @* assert(okay);
    if (TYPE == "assume") always @* assume(okay);
    if (TYPE == "cover")  always @* cover(okay);
  endgenerate
endmodule
module miter_def_prop #(parameter WIDTH=1, parameter TYPE="assert") (input [WIDTH-1:0] in);
  wire okay = ^in !== 1'bx;
  generate
    if (TYPE == "assert") always @* assert(okay);
    if (TYPE == "assume") always @* assume(okay);
    if (TYPE == "cover")  always @* cover(okay);
  endgenerate
endmodule
module \gold.fifo_widget.pop_data (
  input  [  0:0] \__pi_clk ,
  input  [  0:0] \__pi_empty ,
  input  [  0:0] \__pi_full ,
  input  [  0:0] \__pi_pop ,
  input  [  0:0] \__pi_push ,
  input  [ 27:0] \__pi_push_data ,
  input  [  0:0] \__pi_rst_n ,
  output [ 27:0] \__po_pop_data
);
endmodule
module \gate.fifo_widget.pop_data (
  input  [  0:0] \__pi_clk ,
  input  [  0:0] \__pi_empty ,
  input  [  0:0] \__pi_full ,
  input  [  0:0] \__pi_pop ,
  input  [  0:0] \__pi_push ,
  input  [ 27:0] \__pi_push_data ,
  input  [  0:0] \__pi_rst_n ,
  output [ 27:0] \__po_pop_data
);
endmodule
