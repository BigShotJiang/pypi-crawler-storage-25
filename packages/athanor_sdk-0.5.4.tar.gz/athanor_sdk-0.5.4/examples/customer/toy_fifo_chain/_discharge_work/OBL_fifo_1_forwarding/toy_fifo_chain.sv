// ============================================================
// Toy: 3-path FIFO chain with data integrity scenarios
// ============================================================

// --- Packet types ---
// [flattened] packet_t removed

// [flattened] packet_hdr_t removed

// ============================================================
// FIFO module — black-box for graph analysis
// ============================================================
module fifo_widget #(

  parameter int  DEPTH = 4
)(
  input  logic clk,
  input  logic rst_n,
  input  logic push,
  input  logic [27:0]     push_data,
  output logic full,
  input  logic pop,
  output logic [27:0]     pop_data,
  output logic empty
);
  logic [27:0] mem [DEPTH];
  logic [$clog2(DEPTH):0] head, tail, count;

  assign full  = (count == DEPTH);
  assign empty = (count == 0);
  assign pop_data = mem[head[$clog2(DEPTH)-1:0]];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      head  <= '0;
      tail  <= '0;
      count <= '0;
    end else begin
      if (push && !full) begin
        mem[tail[$clog2(DEPTH)-1:0]] <= push_data;
        tail  <= tail + 1;
        count <= count + 1;
      end
      if (pop && !empty) begin
        head  <= head + 1;
        count <= count - 1;
      end
      if (push && !full && pop && !empty)
        count <= count;  // push and pop same cycle
    end
  end
endmodule

// ============================================================
// Arbiter module — black-box for graph analysis
// ============================================================
module arb_widget #(

)(
  input  logic clk,
  input  logic rst_n,
  // Port X
  input  logic x_valid,
  input  logic [27:0]     x_data,
  output logic x_ready,
  // Port Y
  input  logic y_valid,
  input  logic [27:0]     y_data,
  output logic y_ready,
  // Output
  output logic out_valid,
  output logic [27:0]     out_data,
  input  logic out_ready
);
  logic robin;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      robin <= 1'b0;
    else if (out_valid && out_ready)
      robin <= ~robin;
  end

  always_comb begin
    x_ready   = 1'b0;
    y_ready   = 1'b0;
    out_valid = 1'b0;
    out_data  = x_data;

    if (x_valid && y_valid) begin
      out_valid = 1'b1;
      if (robin) begin
        out_data = y_data;
        y_ready  = out_ready;
      end else begin
        out_data = x_data;
        x_ready  = out_ready;
      end
    end else if (x_valid) begin
      out_valid = 1'b1;
      out_data  = x_data;
      x_ready   = out_ready;
    end else if (y_valid) begin
      out_valid = 1'b1;
      out_data  = y_data;
      y_ready   = out_ready;
    end
  end
endmodule

// ============================================================
// Transform: adds header to packet (pure function)
// ============================================================
// [flattened] function add_header returning struct packet_hdr_t removed

// ============================================================
// Top module: 3 paths
//
// Path A: immutable packet through 3 FIFOs (data integrity free)
//   input_a → FIFO_1 → FIFO_2 → FIFO_3 → output_a
//
// Path B: packet modified between FIFOs (needs function verification)
//   input_b → FIFO_4 → add_header → FIFO_5 → output_b
//
// Path C: two streams merge (ordering question at arbiter)
//   input_x → FIFO_6 ─┐
//                       ├→ arbiter → FIFO_7 → output_c
//   input_y → FIFO_8 ─┘
// ============================================================
module toy_fifo_chain (
  input  logic    clk,
  input  logic    rst_n,

  // Path A: immutable forwarding
  input  logic    a_push,
  input  logic [27:0] a_data,
  output logic    a_full,
  input  logic    a_pop,
  output logic [27:0] a_out,
  output logic    a_empty,

  // Path B: data transform
  input  logic    b_push,
  input  logic [27:0] b_data,
  input  logic [7:0] b_hdr_val,
  output logic    b_full,
  input  logic    b_pop,
  output logic [35:0] b_out,
  output logic    b_empty,

  // Path C: merge
  input  logic    cx_push,
  input  logic [27:0] cx_data,
  output logic    cx_full,
  input  logic    cy_push,
  input  logic [27:0] cy_data,
  output logic    cy_full,
  input  logic    c_pop,
  output logic [27:0] c_out,
  output logic    c_empty
);

  // ---- Path A: FIFO_1 → FIFO_2 → FIFO_3 ----
  logic    f1_pop, f1_empty, f2_push, f2_full, f2_pop, f2_empty;
  logic    f3_push, f3_full;
  logic [27:0] f1_out, f2_out;

  fifo_widget #(.DEPTH(4)) fifo_1 (
    .clk, .rst_n,
    .push(a_push), .push_data(a_data), .full(a_full),
    .pop(f1_pop), .pop_data(f1_out), .empty(f1_empty)
  );

  assign f1_pop  = !f1_empty && !f2_full;
  assign f2_push = f1_pop;

  fifo_widget #(.DEPTH(4)) fifo_2 (
    .clk, .rst_n,
    .push(f2_push), .push_data(f1_out), .full(f2_full),
    .pop(f2_pop), .pop_data(f2_out), .empty(f2_empty)
  );

  assign f2_pop  = !f2_empty && !f3_full;
  assign f3_push = f2_pop;

  fifo_widget #(.DEPTH(4)) fifo_3 (
    .clk, .rst_n,
    .push(f3_push), .push_data(f2_out), .full(f3_full),
    .pop(a_pop), .pop_data(a_out), .empty(a_empty)
  );

  // ---- Path B: FIFO_4 → transform → FIFO_5 ----
  logic       f4_pop, f4_empty, f5_push, f5_full;
  logic [27:0]    f4_out;
  logic [35:0] transformed;

  fifo_widget #(.DEPTH(4)) fifo_4 (
    .clk, .rst_n,
    .push(b_push), .push_data(b_data), .full(b_full),
    .pop(f4_pop), .pop_data(f4_out), .empty(f4_empty)
  );

  assign f4_pop      = !f4_empty && !f5_full;
  assign f5_push     = f4_pop;
  assign transformed = {36{1'b0}};

  fifo_widget #(.DEPTH(4)) fifo_5 (
    .clk, .rst_n,
    .push(f5_push), .push_data(transformed), .full(f5_full),
    .pop(b_pop), .pop_data(b_out), .empty(b_empty)
  );

  // ---- Path C: FIFO_6 + FIFO_8 → arbiter → FIFO_7 ----
  logic    f6_pop, f6_empty, f8_pop, f8_empty;
  logic    f7_push, f7_full;
  logic [27:0] f6_out, f8_out;
  logic    arb_out_valid;
  logic [27:0] arb_out_data;
  logic    arb_x_ready, arb_y_ready;

  fifo_widget #(.DEPTH(4)) fifo_6 (
    .clk, .rst_n,
    .push(cx_push), .push_data(cx_data), .full(cx_full),
    .pop(f6_pop), .pop_data(f6_out), .empty(f6_empty)
  );

  fifo_widget #(.DEPTH(4)) fifo_8 (
    .clk, .rst_n,
    .push(cy_push), .push_data(cy_data), .full(cy_full),
    .pop(f8_pop), .pop_data(f8_out), .empty(f8_empty)
  );

  assign f6_pop = arb_x_ready;
  assign f8_pop = arb_y_ready;

  arb_widget  arbiter (
    .clk, .rst_n,
    .x_valid(!f6_empty), .x_data(f6_out), .x_ready(arb_x_ready),
    .y_valid(!f8_empty), .y_data(f8_out), .y_ready(arb_y_ready),
    .out_valid(arb_out_valid), .out_data(arb_out_data),
    .out_ready(!f7_full)
  );

  assign f7_push = arb_out_valid && !f7_full;

  fifo_widget #(.DEPTH(4)) fifo_7 (
    .clk, .rst_n,
    .push(f7_push), .push_data(arb_out_data), .full(f7_full),
    .pop(c_pop), .pop_data(c_out), .empty(c_empty)
  );

endmodule
