.DEFAULT_GOAL := all

strategies/fifo_widget.pop_data/basic/status:
	@echo "Running strategy 'basic' on 'fifo_widget.pop_data'.."
	@bash -c "cd strategies/fifo_widget.pop_data/basic; source run.sh"

strategies/fifo_widget.full/basic/status:
	@echo "Running strategy 'basic' on 'fifo_widget.full'.."
	@bash -c "cd strategies/fifo_widget.full/basic; source run.sh"

strategies/fifo_widget.empty/basic/status:
	@echo "Running strategy 'basic' on 'fifo_widget.empty'.."
	@bash -c "cd strategies/fifo_widget.empty/basic; source run.sh"

.PHONY: all summary
all: strategies/fifo_widget.empty/basic/status strategies/fifo_widget.full/basic/status strategies/fifo_widget.pop_data/basic/status
	$(MAKE) -f strategies.mk summary
summary:
	@rc=0 ; \
	while read f; do \
		p=$${f#strategies/} ; p=$${p%/*/status} ; \
		if grep -q "PASS" $$f ; then \
			echo "* Successfully proved equivalence of partition $$p" ; \
		else \
			echo "* Failed to prove equivalence of partition $$p" ; rc=1 ; \
		fi ; \
	done < summary_targets.list ; \
	if [ "$$rc" -eq 0 ] ; then \
		echo "* Successfully proved designs equivalent" ; \
	fi
