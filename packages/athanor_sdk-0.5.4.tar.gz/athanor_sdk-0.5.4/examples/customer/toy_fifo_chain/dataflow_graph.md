# Dataflow graph + per-widget classification

Generated mechanically from `toy_fifo_chain.sv`. Each instance is labelled with its module type and its FORWARDS / MODIFIES classification.

## Path A: immutable forwarding (3-FIFO chain)

    input_a → fifo_1 → fifo_2 → fifo_3 → output_a

Per-widget classification:

  fifo_1 (fifo_widget, FORWARDS)
  fifo_2 (fifo_widget, FORWARDS)
  fifo_3 (fifo_widget, FORWARDS)

## Path B: pure-function transform between FIFOs

    input_b → fifo_4 → add_header → fifo_5 → output_b

Type changes from ``packet_t`` to ``packet_hdr_t`` at the ``add_header`` step. Per-widget classification:

  fifo_4 (fifo_widget, FORWARDS)
  fifo_5 (fifo_widget, FORWARDS)
  add_header (add_header, MODIFIES)
  add_header (function, MODIFIES)

## Path C: round-robin merge of two streams

    input_x → fifo_6 ─┐
                       ├→ arbiter → fifo_7 → output_c
    input_y → fifo_8 ─┘

Per-widget classification:

  fifo_6 (fifo_widget, FORWARDS)
  fifo_8 (fifo_widget, FORWARDS)
  arbiter (arb_widget, MODIFIES)
  fifo_7 (fifo_widget, FORWARDS)

## Notes

* `MODIFIES` on the arbiter does NOT mean it changes packet   contents: it means total ordering across X and Y is   interleaved by round-robin, so the equivalence claim   must be quoted as per-source ordering only.
* Path B's data type changes between fifo_4 (packet_t) and   fifo_5 (packet_hdr_t). The transform is a pure function so   the equivalence claim is field-preservation (id, payload,   tag) plus the new derived field (header).
