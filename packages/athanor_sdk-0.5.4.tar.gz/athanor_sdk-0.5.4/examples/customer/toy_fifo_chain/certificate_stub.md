# Equivalence certificate stub (per-path)

Certificate language is per-path; each path makes a different shape of claim and customers reading the certificate should be able to point at the exact claim being made.

## Path A: immutable forwarding

*Claim:* For every packet `p` enqueued on `input_a` at cycle `t`, there exists a cycle `t' ≥ t` at which `p` is dequeued on `output_a` byte-identical to its input form, modulo total chain depth. No fields are inspected, no fields are modified: the claim is data-integrity-via-FORWARDS-composition across the three FIFO instances.

## Path B: pure-function transform with field preservation

*Claim:* For every packet `p : packet_t` enqueued on `input_b` with header value `h`, the packet `p' : packet_hdr_t` dequeued on `output_b` satisfies

    p'.id      ≡ p.id
    p'.payload ≡ p.payload
    p'.tag     ≡ p.tag
    p'.header  ≡ h

The certificate quotes field-preservation EXPLICITLY because the type changes: no naive byte-equality claim is valid.

## Path C: per-source ordering preservation

*Claim:* For every pair of packets `p₁, p₂` arriving at `fifo_6` with `p₁` strictly before `p₂` in source-X order, `p₁` appears strictly before `p₂` in `output_c`. The same claim holds independently for source Y. NO claim is made about the relative ordering of an X-source packet vs a Y-source packet: the round-robin arbiter licenses the per-source claim only, NOT a total-arrival-time claim.

## Five choke-points the equivalence stage must surface

These are the LLM idiom-recognition tests embedded in the design; the certificate must quote each one explicitly so an auditor can verify the stage handled it.

1. **FIFO `count` SV-last-assignment-wins idiom.** The    `always_ff` block's `if (push && !full && pop && !empty)    count <= count;` line is the actual winner of the    procedural-assignment race against the conditional    `count <= count + 1` and `count <= count - 1`. The Lean    extraction must preserve this priority, not naively    merge the conditionals.
2. **3-stage combinational backpressure chain (path A).**    `f1_pop = !f1_empty && !f2_full;` and similar for f2→f3    create a same-cycle stall propagation. Per-instance    `push && !full` precondition on every successful enqueue    is what discharges silent-data-drop safety.
3. **`add_header` clean translation.** The pure-function    semantics must round-trip cleanly through Clash → Lean    → SV without any field reordering or insertion of    intermediate scratchpad signals.
4. **Arbiter round-robin scope.** The `robin` toggle    advances on `out_valid && out_ready` only. The    per-source ordering claim depends on this scope being    exact: no advance on backpressure-stalled cycles.
5. **Unconditional `out_data = x_data` default.** The    first line of the arbiter `always_comb` block is the    fall-through default. In the case where neither input    is valid, `out_valid = 0` and the consumer is required    by the interface contract to gate on `out_valid` before    reading `out_data`. The certificate must surface this    as a consumer-side obligation, not a producer-side bug.

## Obligation status: 11 ready, 10 gated

Mechanical pipeline (parse + classify + per-widget obligation enumeration) produced **11** obligations the current toolchain can discharge or assert today. The remaining **10** obligations are gated on the upstream Clash + Yosys/EQY install (already a tracked dependency). They are SURFACED as outstanding so the certificate does NOT silently emit a fake-equivalence claim.

### Ready obligations

* **OBL_fifo_1_count_idiom**: path A, widget fifo_1, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_2_count_idiom**: path A, widget fifo_2, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_3_count_idiom**: path A, widget fifo_3, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_4_count_idiom**: path B, widget fifo_4, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_5_count_idiom**: path B, widget fifo_5, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_6_count_idiom**: path C, widget fifo_6, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_fifo_8_count_idiom**: path C, widget fifo_8, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_arbiter_default_safety**: path C, widget arbiter, shape `arbiter_default_safety`
  * The unconditional ``out_data = x_data;`` at the start of the always_comb block produces a concrete output when ALL of {x_valid, y_valid} are zero. Certificate language: in that fall-through case, ``out_valid = 0``, so downstream consumers MUST gate on out_valid before reading out_data: this is an interface contract on the consumer, surfaced explicitly.
* **OBL_fifo_7_count_idiom**: path C, widget fifo_7, shape `count_idiom_correctness`
  * SV last-assignment-wins idiom on the ``count`` signal: when push and pop both fire in the same cycle, the procedural sequence increments then decrements, but the explicit ``count <= count;`` at the end of the always_ff block is the actual winner. Mechanical check: textual presence of the ``count <= count`` line in the same-cycle branch: verified.
* **OBL_path_A_backpressure**: path A, widget <path-level>, shape `backpressure_safety`
  * Combinational backpressure chain on path A: each FIFO's ``pop`` is wired to the next FIFO's ``!full``, so a downstream stall propagates upstream in the same cycle. Per-instance safety: at each FIFO, ``push && !full`` is the precondition for a successful enqueue; the upstream pop only asserts when the downstream is not full, so no silent-data-drop is possible.
* **OBL_path_B_backpressure**: path B, widget <path-level>, shape `backpressure_safety`
  * Combinational backpressure chain on path B: each FIFO's ``pop`` is wired to the next FIFO's ``!full``, so a downstream stall propagates upstream in the same cycle. Per-instance safety: at each FIFO, ``push && !full`` is the precondition for a successful enqueue; the upstream pop only asserts when the downstream is not full, so no silent-data-drop is possible.

### Gated obligations (require upstream toolchain)

* **OBL_fifo_1_forwarding**: path A, widget fifo_1, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_2_forwarding**: path A, widget fifo_2, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_3_forwarding**: path A, widget fifo_3, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_4_forwarding**: path B, widget fifo_4, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_5_forwarding**: path B, widget fifo_5, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_6_forwarding**: path C, widget fifo_6, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_fifo_8_forwarding**: path C, widget fifo_8, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_arbiter_per_source_order**: path C, widget arbiter, shape `per_source_ordering_preserved`
  * Round-robin merge preserves per-source ordering: for any two packets from the same source S, their arrival order at the arbiter output equals their arrival order at the arbiter input. Total ordering across S=X and S=Y is interleaved by the round-robin selector and is NOT a claim the certificate makes.
* **OBL_fifo_7_forwarding**: path C, widget fifo_7, shape `forwarding_identity`
  * EQY equivalence between this FIFO instance and the Lean-extracted reference implementation; discharge blocked on the upstream Clash + Yosys/EQY toolchain.
* **OBL_path_B_add_header_translation**: path B, widget add_header, shape `transform_field_preservation`
  * Lean translation of ``add_header`` must preserve the field-by-field semantics: id, payload, tag forwarded verbatim; header is the customer-supplied derived field. Discharge blocked on the upstream Clash extraction + Lean refinement-witness generation.

## Toolchain dependency note

The equivalence-discharge stage requires Clash + Yosys/EQY installed in the runner environment. Until that install is in place, gated obligations remain visible-but-undischarged in the certificate so an auditor can see exactly what is claimed and what is outstanding. This is the deliberate discipline against silent-fake-certificate failures.
