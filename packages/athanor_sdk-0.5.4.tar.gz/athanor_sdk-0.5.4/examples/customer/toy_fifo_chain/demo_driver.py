"""End-to-end demo driver for the toy_fifo_chain block.

ATH-979. Aidan 2026-05-04 completion-requirement-tonight: launch a
full end-to-end kairos run with the agent fleet so Todd can be
pointed at /analytics/silicon-blocks/<run_id> and see the
customer-block certificate card live with the actual flip count.

What this script does
---------------------

1. Opens a kairos.session() context that traces to the configured
   sink (Supabase via ATHANOR_SYNC_TOKEN by default; NoopTraceSink
   when offline).
2. Runs the mechanical pipeline (pipeline_run.py) to enumerate the
   21 obligations.
3. Optionally runs the discharge orchestrator (discharge_obligations.py)
   to invoke EQY end-to-end if the toolchain is installed; skips
   gracefully when not.
4. Emits a single ``customer_block_certificate_complete`` trace
   event with the full obligations array + certificate language +
   toolchain status + path summaries as payload.
5. Prints the run_id so the customer (or Todd) can navigate to
   /analytics/silicon-blocks/<run_id>.

Usage
-----

    python3 examples/customer/toy_fifo_chain/demo_driver.py
    python3 examples/customer/toy_fifo_chain/demo_driver.py --no-discharge

Environment
-----------

* ``ATHANOR_SYNC_TOKEN`` -- when set, traces flow to the Athanor
  dashboard. When absent, runs locally with NoopTraceSink (zero
  phone-home).
* ``ATHANOR_DEMO_BLOCK_NAME`` -- override the block name in the
  payload. Defaults to "toy_fifo_chain".

Honest framing
--------------

The demo driver does NOT silently skip the discharge step when the
toolchain is missing -- it emits the event with
``toolchain_status.clash_yosys_eqy_installed=False`` so the
dashboard renders the gated badge transparently. Same
no-fake-certificate discipline as the certificate stub.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
SV_PATH = HERE / "toy_fifo_chain.sv"
OBLIGATIONS_PATH = HERE / "obligations.json"
CERTIFICATE_PATH = HERE / "certificate_stub.md"
PIPELINE_RUN = HERE / "pipeline_run.py"
DISCHARGE_RUN = HERE / "discharge_obligations.py"


def _toolchain_present() -> bool:
    return all(shutil.which(t) for t in ("yosys", "clash", "eqy"))


def _run_pipeline_enumerate() -> dict[str, Any]:
    """Run pipeline_run.py to (re)generate obligations.json + the
    sibling artifacts. Returns the parsed obligations.json dict.
    """
    proc = subprocess.run(
        [sys.executable, str(PIPELINE_RUN)],
        capture_output=True, text=True, cwd=str(HERE),
    )
    if proc.returncode != 0:
        print(
            f"[demo_driver] pipeline_run.py failed (rc={proc.returncode}):\n"
            f"  stdout: {proc.stdout}\n  stderr: {proc.stderr}",
            file=sys.stderr,
        )
        sys.exit(1)
    return json.loads(OBLIGATIONS_PATH.read_text())


def _run_discharge() -> None:
    """Run discharge_obligations.py. Updates obligations.json
    in-place with the per-obligation discharge status.
    """
    proc = subprocess.run(
        [sys.executable, str(DISCHARGE_RUN)],
        capture_output=True, text=True, cwd=str(HERE),
    )
    if proc.returncode != 0:
        print(
            f"[demo_driver] discharge_obligations.py exited "
            f"non-zero (rc={proc.returncode}). Continuing -- the "
            f"obligations.json status fields reflect what the run "
            f"produced.\n  stdout (tail): {proc.stdout[-2000:]}\n"
            f"  stderr (tail): {proc.stderr[-1000:]}",
            file=sys.stderr,
        )


def _summarize_paths(obligations: list[dict[str, Any]]) -> dict[str, Any]:
    """Per-path summaries: counts of each status."""
    summaries: dict[str, dict[str, int]] = {}
    for o in obligations:
        path = o.get("path", "?")
        status = o.get("status", "unknown")
        if path not in summaries:
            summaries[path] = {}
        summaries[path][status] = summaries[path].get(status, 0) + 1
    return summaries


def main() -> int:
    parser = argparse.ArgumentParser(
        description="End-to-end demo driver for toy_fifo_chain (ATH-979).",
    )
    parser.add_argument(
        "--no-discharge",
        action="store_true",
        help="Skip discharge_obligations.py invocation (faster; the "
             "obligations.json status remains gated_on_eqy).",
    )
    parser.add_argument(
        "--block-name",
        default=os.environ.get("ATHANOR_DEMO_BLOCK_NAME", "toy_fifo_chain"),
        help="Customer block name carried in the trace event payload.",
    )
    args = parser.parse_args()

    print("[demo_driver] step 1/4: mechanical pipeline enumeration")
    _run_pipeline_enumerate()

    if args.no_discharge:
        print(
            "[demo_driver] step 2/4: discharge SKIPPED (--no-discharge); "
            "obligations.json remains pre-discharge"
        )
    elif not _toolchain_present():
        print(
            "[demo_driver] step 2/4: discharge SKIPPED (yosys / clash / "
            "eqy not on PATH); install via "
            "scripts/install-purertl-toolchain.sh to run end-to-end"
        )
    else:
        print("[demo_driver] step 2/4: running discharge_obligations.py "
              "(this invokes the full EQY pipeline; allow several minutes)")
        _run_discharge()

    obligations_data = json.loads(OBLIGATIONS_PATH.read_text())
    obligations = obligations_data.get("obligations", [])
    toolchain_status = obligations_data.get("toolchain_status", {})

    print(
        f"[demo_driver] step 3/4: emitting "
        f"customer_block_certificate_complete event with "
        f"{len(obligations)} obligations"
    )

    # Open a kairos.observe.observe() context so the trace flows to
    # the configured sink. observe() is the free-tier wrapper (no
    # license gate); paid customers can swap to kairos.prove.session()
    # for the parent solve_runs row + license-scoped features.
    certificate_text = (
        CERTIFICATE_PATH.read_text() if CERTIFICATE_PATH.is_file() else ""
    )

    # Force-load kairos.observe then reach the module via sys.modules.
    # ``kairos/__init__.py`` rebinds ``kairos.observe`` to the
    # ``observe`` function (so ``import kairos.observe; kairos.observe``
    # is the function, not the module). Use ``sys.modules`` to get
    # the actual module so we can call its ``emit``.
    import kairos.observe  # noqa: F401 -- force-load
    import sys as _sys
    obs = _sys.modules["kairos.observe"]
    from kairos.trace import default_sink_from_env

    sink = default_sink_from_env()
    with obs.observe(
        sink=sink,
        run_subtype="theorem_proving",
        task_id=args.block_name,
        vertical="hardware_verification",
    ) as ctx:
        run_id = ctx.run_id
        # Emit the certificate-complete event with the full payload.
        payload: dict[str, Any] = {
            "block_name": args.block_name,
            "obligations": obligations,
            "instances": obligations_data.get("instances", []),
            "paths": obligations_data.get("paths", {}),
            "classifications": obligations_data.get("classifications", []),
            "path_summaries": _summarize_paths(obligations),
            "toolchain_status": toolchain_status,
            "total_obligations": len(obligations),
            "certificate_first_8k": certificate_text[:8000],
        }
        obs.emit(
            "customer_block_certificate_complete",
            payload,
            run_subtype="theorem_proving",
            silent_if_no_session=False,
        )

    print(f"[demo_driver] step 4/4: complete")
    print(f"[demo_driver] run_id: {run_id}")
    dashboard_host = os.environ.get(
        "ATHANOR_DASHBOARD_HOST", "tahoe.athanor-ai.com"
    )
    print(
        f"[demo_driver] dashboard: "
        f"https://{dashboard_host}/analytics/silicon-blocks/{run_id}"
    )
    print(
        f"[demo_driver] customer artifact: "
        f"{len(obligations)} obligations enumerated; per-path summary:"
    )
    for path, status_counts in _summarize_paths(obligations).items():
        bits = ", ".join(f"{n} {s}" for s, n in sorted(status_counts.items()))
        print(f"  Path {path}: {bits}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
