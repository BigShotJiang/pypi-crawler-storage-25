# Free-tier Pythia example

End-to-end example using `kairos.simple_prove_template()`. No license required.
No API key needed for the built-in patterns.

The example exercises the five v0 templates against the public
[Pythia](https://github.com/athanor-ai/pythia) Lean 4 statistics
library. sharp-constant theorems, `Pythia.Time` resolution, and a
toolchain smoke test.

## Run

```bash
pip install athanor-kairos
python examples/free-tier-pythia/prove_pythia_constants.py
```

Expected output:

```
=== Pythia free-tier ===

→ "prove c_vector_sharp is positive"
   pattern: sharp_constant_positive
   summary: ✓ proved. c_vector_sharp is strictly positive (Pythia.MatchingConstants).

→ "prove c_aCS_sharp <= c_vector_sharp"
   pattern: sharp_constant_ranking
   summary: ✓ proved. the aCS sharp constant is at most the vector sharp constant ...

→ "prove c_vector_sharp equals sqrt 2 times c_HR_sharp"
   pattern: sharp_constant_equivalence
   summary: ✓ proved. the vector sharp constant equals sqrt(2) times the Howard-Ramdas sharp constant ...

→ "prove Pythia.Time is a natural number"
   pattern: bit_precision_time
   summary: ✓ proved. Pythia.Time abbreviates to ℕ (the natural numbers).

→ "verify the Pythia API"
   pattern: pythia_smoke
   summary: ✓ proved. Pythia.API loads and trivial is provable (smoke test).
```

(Actual `summary` lines depend on the toolchain. If `lake` is not on
PATH or the Pythia package isn't in your project manifest, the summary
starts with `✗ could not verify`. that's still a valid response from
the SDK; it tells you exactly what's missing.)

## What this example demonstrates

1. **Zero-friction setup.** No license, no API key, no Lean files
   you have to write by hand.
2. **The five built-in Pythia template patterns.** One example each:
   `sharp_constant_positive`, `sharp_constant_ranking`,
   `sharp_constant_equivalence`, `bit_precision_time`, `pythia_smoke`.
3. **Result inspection.** How to read `SimpleProveResult.summary`,
   `.pattern_id`, `.spec_path`.

## What it doesn't demonstrate (yet)

- BYO LLM key path (set `ANTHROPIC_API_KEY` and pass an off-template
  hypothesis to see the LLM-fill fallback). See
  `docs/free-tier-quickstart.md`.
- Paid tier. for that, see `examples/sv-multi-bbr3/` etc.

## See also

- [`docs/free-tier-quickstart.md`](../../docs/free-tier-quickstart.md)
- [`docs/INDEX.md`](../../docs/INDEX.md)
- [`docs/sdk-tier-model.md`](../../docs/sdk-tier-model.md)
- [Pythia repo](https://github.com/athanor-ai/pythia)
