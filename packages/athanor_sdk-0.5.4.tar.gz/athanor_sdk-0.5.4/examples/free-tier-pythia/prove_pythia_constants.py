"""Free-tier `kairos.simple_prove_template()` example against the
public Pythia Lean 4 statistics library.

Run:

    python examples/free-tier-pythia/prove_pythia_constants.py

No license required. No API key required for the built-in templates.
The SDK matches each hypothesis against a Pythia template, generates
a Lean spec that imports `Pythia.API`, runs `lake build`, and
translates the verdict back to plain English. The customer never
reads or writes a Lean file.

Expected runtime: a few seconds per hypothesis (Lean compile
dominates).
"""
from kairos import simple_prove_template


HYPOTHESES = [
    # sharp_constant_positive — picks c_vector_sharp_pos
    "prove c_vector_sharp is positive",
    # sharp_constant_ranking — c_aCS_sharp <= c_vector_sharp
    "prove c_aCS_sharp <= c_vector_sharp",
    # sharp_constant_equivalence — c_vector = sqrt(2) * c_HR
    "prove c_vector_sharp equals sqrt 2 times c_HR_sharp",
    # bit_precision_time — Pythia.Time = ℕ
    "prove Pythia.Time is a natural number",
    # pythia_smoke — toolchain sanity test
    "verify the Pythia API",
]


def main() -> None:
    print("=== Pythia free-tier ===\n")
    for h in HYPOTHESES:
        result = simple_prove_template(h)
        print(f"→ {h!r}")
        print(f"   pattern: {result.pattern_id}")
        print(f"   summary: {result.summary}")
        if result.spec_path is not None:
            print(f"   (Lean spec stashed at {result.spec_path})")
        print()


if __name__ == "__main__":
    main()
