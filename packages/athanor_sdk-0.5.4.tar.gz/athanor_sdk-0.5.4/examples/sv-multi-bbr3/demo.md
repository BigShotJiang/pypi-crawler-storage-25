# `athanor sv-multi` on BBRv3 TelosReno (ATH-412a)

Real-world multi-abstraction demo against the BBRv3 TelosReno
SystemVerilog fixture (`telos_reno_k10.sv`). Layers span **functional**
invariants (cwnd bounds + half-on-loss + grow-on-ack) and a
**performance** invariant (k=10 growth-from-floor).

## What this shows

**Honest coverage reporting.** The telos_reno spec uses multi-cycle SVA
operators (`|=>`, `$past`, `##N`, `[*k]`) that EBMC's `--k-induction`
and `--ic3` engines reject. The dispatcher still runs every declared
backend and reports the truth: layers degrade to `PARTIAL` rather than
pretending a single-engine proof is a sandwich.

This is the shape customers actually see on modern CCA specs. Pure
safety-only properties (see `sv-multi-sandwich-toy/`) get full
`SANDWICH_PROVED`; SVA-heavy ones get `PARTIAL` with a machine-readable
diagnostic of which (assertion, backend) pairs were missing.

## Files

- `telos_reno_k10.sv` - TelosReno CCA model (from
  `bbr3-starvation-bench/proofs/solve-runs/telos_reno/`). Uses `|=>`
  throughout; not IC3/k-induction compatible.
- `spec.yaml` - two layers, each using `ebmc` default + one alternate
  engine (`ebmc_kind` / `ebmc_ic3`).

## Run

```sh
athanor sv-multi --spec examples/sv-multi-bbr3/spec.yaml
```

## Expected output

```
multi-abstraction: reno_cca (telos_reno_k10.sv)
  ? functional: PARTIAL - 3 (assertion, backend) pair(s) missing from EBMC output: ...
      p_cwnd_ge_mss: ebmc=PROVED, ebmc_kind=MISSING
      p_cwnd_halves_on_loss: ebmc=PROVED, ebmc_kind=MISSING
      p_cwnd_grows_on_ack: ebmc=PROVED, ebmc_kind=MISSING
  ? performance: PARTIAL - 1 (assertion, backend) pair(s) missing from EBMC output: ...
      p_k10_growth_from_floor: ebmc=PROVED, ebmc_ic3=MISSING
overall: PARTIAL
```

Exit code 1 (any layer not `SANDWICH_PROVED` / `SINGLE_PROVED`).

## How to graduate this to SANDWICH_PROVED

The multi-cycle SVA operators are the blocker. Two paths:

1. **Use a future `dafny` or `lean` backend.** Once those register
   under `athanor.sv.multi`, swap `ebmc_kind` → `dafny` (or `lean`)
   in the YAML. Both tools accept `|=>`-style obligations via
   first-order-logic translation.
2. **Rewrite the spec in single-cycle SVA.** The CCA invariants can
   be encoded without `$past` by introducing an explicit delayed
   register; then `ebmc_kind` + `ebmc_ic3` both become viable.

Path 1 is the customer-facing answer; path 2 is a research detour
(useful for proving spec-equivalence between the two encodings).

## Python API

```python
from athanor.sv.multi import run_multi
r = run_multi("examples/sv-multi-bbr3/spec.yaml")
assert r.overall == "PARTIAL"
for layer in r.layers:
    print(f"{layer.name}: {layer.outcome}")
    for v in layer.per_assertion_verdicts:
        if v.verdict != "PROVED":
            print(f"  missing: {v.assertion} @ {v.backend}")
```

## Related

- `sv-multi-sandwich-toy/` - minimal fixture earning `SANDWICH_PROVED`.
- ATH-412 umbrella - Part A (multi-abstraction, this demo) + Part B
  (HB-graph extraction, WIP).
