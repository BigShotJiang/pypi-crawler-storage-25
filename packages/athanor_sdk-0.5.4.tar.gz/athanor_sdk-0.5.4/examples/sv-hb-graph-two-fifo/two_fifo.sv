// Two-FIFO composition — toy dogfood for ATH-412 Part B.
//
// A classic producer/consumer pattern where two processes each own
// a FIFO-backed data path. Used as the runnable example for the
// happens-before graph extractor + PO-violation detector.
//
// Each `always_ff` block maintains a single-entry FIFO (valid + data).
// The handshake signals (`a_valid` / `a_ready` / `b_valid` / `b_ready`)
// follow standard ready/valid handshake semantics.

module two_fifo (
  input clk,
  input rst,
  input  a_valid,
  output reg a_ready,
  input  [7:0] a_data,
  output reg b_valid,
  input  b_ready,
  output reg [7:0] b_data
);

  always_ff @(posedge clk) begin
    if (rst) a_ready <= 1'b0;
    else if (a_valid && !a_ready) a_ready <= 1'b1;
  end

  always_ff @(posedge clk) begin
    if (rst) b_valid <= 1'b0;
    else if (a_valid && a_ready) b_valid <= 1'b1;
  end

  always_ff @(posedge clk) begin
    if (rst) b_data <= 8'd0;
    else if (a_valid && a_ready) b_data <= a_data;
  end

endmodule
