# `kairos sv-hb-graph` on two-FIFO composition (ATH-412 Part B)

Happens-before graph extraction + PO-violation detection + SVA-witness
emission on a two-FIFO producer/consumer composition. Demonstrates the
full Part B pipeline: **SV source → HBGraph → Tarjan SCC → SVA
witnesses** that EBMC can cross-check against the RTL.

Canned output captured in [`canned_run.json`](./canned_run.json).

## What this shows

**The happy path - a clean design produces no witnesses.** The
two-FIFO RTL as shipped has no HB cycle: the ready/valid handshake
is strictly one-way (A → B via `a_valid && a_ready` gating `b_valid`
/ `b_data`). The extractor records 16 events + 15 edges; Tarjan
reports zero violations; the emitter returns empty.

**The value path - when we inject a circular dependency, the
pipeline finds it + emits an SVA witness.** By synthetically adding
an OBSERVATION edge from the last event back to the first (simulating
a buggy bidirectional handshake), the tool detects the cycle,
reports its size, and lowers it to a concrete SVA assertion the
customer can paste into the RTL + feed EBMC.

## Files

- `two_fifo.sv` - toy two-FIFO RTL, 3 `always_ff` blocks, clean
  ready/valid handshake
- `canned_run.json` - captured clean + injected-cycle outputs

## Run

```sh
# Clean case - exit 0
kairos sv-hb-graph --spec examples/sv-hb-graph-two-fifo/two_fifo.sv

# With reset-disable wrapping on emitted SVA
kairos sv-hb-graph \
    --spec examples/sv-hb-graph-two-fifo/two_fifo.sv \
    --clock clk --disable-iff rst \
    --out-sva /tmp/hb_witnesses.sv
```

Or via the Python API:

```python
from kairos.sv.hb_extract import extract_hb_graph
from kairos.sv.hb_graph import find_po_violations
from kairos.sv.hb_sva_emit import emit_all_sva

g = extract_hb_graph(open("two_fifo.sv").read())
violations = find_po_violations(g)
print(f"{len(violations)} PO violation(s)")
if violations:
    print(emit_all_sva(g, clock="clk", disable_signal="rst"))
```

## Captured output (from `canned_run.json`)

```
hb-graph: 16 event(s), 15 edge(s)
po-violations: 0
Clean DAG - no HB cycles.
```

Exit code 0. The two-FIFO handshake is well-founded; no HB witness
is needed.

### Injected-cycle case

```
# After adding a synthetic OBSERVATION back-edge:
po-violations: 1
SVA witnesses written to /tmp/hb_witnesses.sv
```

Excerpt from the emitted SVA:

```systemverilog
// =====================================================
// ATH-412 Part B: 1 HB cycle witness(es)
// =====================================================

// ATH-412 HB cycle witness over 4 event(s):
//   _init [init: @ <initial>]
//   ff_0#e1 [handshake:a_ready @ ff_0]
//   ...
hb_witness__init__ff_0_e1__ff_0_e2:
  assert property (@(posedge clk) disable iff (rst)
    (!$stable(1'b1)) |-> (a_ready) && (rst) ##1 ...);
```

Feeding this assertion to EBMC against the original RTL:

- **EBMC proves the assertion** → the HB cycle IS realizable; design
  is broken, assertion is an actionable customer-facing bug report
- **EBMC refutes** → the cycle was introduced by a modeling artifact
  in the extractor (e.g. a spuriously-injected edge); the RTL
  actually guards against it; triage the extractor

## How the pipeline composes

```
           ┌─────────────────┐
    SV ──▶│ hb_extract      │──▶ HBGraph
           │ (slice 2)       │
           └─────────────────┘
                    │
                    ▼
           ┌─────────────────┐
           │ find_po_violations │──▶ POViolation[]
           │ Tarjan SCC      │
           │ (slice 1)       │
           └─────────────────┘
                    │
                    ▼
           ┌─────────────────┐
           │ emit_all_sva    │──▶ SVA witnesses
           │ (slice 3)       │
           └─────────────────┘
```

Each slice is an independent library module (see
`src/kairos/sv/hb_*.py`). External tooling can plug in at any layer
- e.g., import `HBGraph` + `find_po_violations` directly from your
own parser without using `hb_extract`.

## Scope notes

The extractor in slice 2 handles a constrained SV subset (single
module, always_ff / always @(*), plain if-else). It raises
`HBExtractError` on unsupported constructs (case / for /
generate / multi-module / clock-domain crossings) with actionable
source-line pointers. See `athanor-sdk/src/kairos/sv/hb_extract.py`
module docstring for the full in-scope / out-of-scope list.

## Related

- `sv-multi-bbr3/` - multi-abstraction sandwich-rule demo (ATH-412a)
- `sv-invariants-telos-reno/` - reverse-mutation-kill discovery (ATH-411)
- ATH-412 umbrella - Part A (multi-abstraction, shipped) + Part B
  (HB graph, this demo closes it)
