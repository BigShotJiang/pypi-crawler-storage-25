# `athanor sv-multi` - sandwich rule demo (ATH-412a)

Cross-prove a SystemVerilog safety invariant using three distinct EBMC
decision procedures (BMC, k-induction, IC3) under the sandwich rule:
every assertion must be `PROVED` by at least 2 distinct backends with
zero refutations to earn **`SANDWICH_PROVED`**.

## What this shows

- **YAML-first surface.** One `spec.yaml` declares the module, the spec
  file, and the layer → (assertions × backends) matrix. No Python.
- **Real EBMC, not stubs.** Every verdict comes from `/usr/bin/ebmc`
  running three different solver flags.
- **Three genuine proof techniques.** BMC (SAT unrolling), k-induction
  (inductive invariant inference), IC3 (property-directed reachability).
  A property both SAT-unrolled *and* induction-closed *and* IC3-closed
  is materially more trustworthy than one closed by only one technique.

## Files

- `combinational_safety.sv` - 4-bit saturating counter with the safety
  invariant `counter <= 4'd15`. Inductive; every EBMC engine closes it.
- `spec.yaml` - layer declaration pointing at `ebmc`, `ebmc_kind`,
  `ebmc_ic3`.

## Run

From the SDK repo root:

```sh
athanor sv-multi --spec examples/sv-multi-sandwich-toy/spec.yaml
```

## Expected output

```
multi-abstraction: sandwich_toy (combinational_safety.sv)
  ✓✓ safety: SANDWICH_PROVED - every assertion proved by ≥2 backends
      p_counter_bounded: ebmc=PROVED, ebmc_kind=PROVED, ebmc_ic3=PROVED
overall: SANDWICH_PROVED
```

Exit code 0.

## Python API

```python
from athanor.sv.multi import run_multi
r = run_multi("examples/sv-multi-sandwich-toy/spec.yaml")
print(r.overall)  # "SANDWICH_PROVED"
for layer in r.layers:
    for v in layer.per_assertion_verdicts:
        print(v.assertion, v.backend, v.verdict)
```

## Extending to more backends

When Dafny, Lean, or Hypothesis backends land, add them under any
layer's `backends:` list. The sandwich rule auto-graduates - two
backends agreeing is the bar, three is bonus evidence.

```yaml
layers:
  safety:
    assertions: [p_counter_bounded]
    backends: [ebmc, ebmc_kind, ebmc_ic3, dafny, hypothesis]
```

Registration for custom backends:

```python
from athanor.sv.multi import register_multi_backend

def my_backend(sv_file, top_module, bound, timeout_sec):
    # ... call your tool, return an EbmcResult-compatible dataclass ...
    ...

register_multi_backend("my_backend", my_backend)
```

## Constraints on SVA operator coverage

EBMC's `--k-induction` and `--ic3` engines reject multi-cycle SVA
operators (`|=>`, `##N`, `$past`, `[*k]`). A spec using those operators
can still run through `sv-multi`, but only the default BMC engine
will return verdicts - the layer degrades to `SINGLE_PROVED` rather
than `SANDWICH_PROVED`. See the companion `sv-multi-bbr3` demo for a
real BBRv3 SV fixture that exhibits this behaviour honestly.

## Related

- `sv-multi-bbr3/` - BBRv3 TelosReno demo (SVA-rich; reports `PARTIAL`).
- ATH-412 umbrella - Part A (this demo) + Part B (HB-graph extraction, WIP).
- ATH-408 customer-asks umbrella.
