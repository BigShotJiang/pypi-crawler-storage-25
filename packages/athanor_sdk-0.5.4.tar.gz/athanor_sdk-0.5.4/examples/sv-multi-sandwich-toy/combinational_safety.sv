// Minimal SV fixture whose safety property every EBMC engine closes:
// BMC default, --k-induction, --ic3. Used to validate the ATH-412a
// multi-abstraction sandwich rule end-to-end against real EBMC.
//
// Constraints the fixture satisfies:
//   - At least one reg (IC3 rejects pure combinational).
//   - Pure safety (no |=>, no $past, no multi-cycle SVA).
//   - Inductive invariant all three engines close in one step.

module sandwich_toy(
  input       clk,
  input       reset,
  input       inc
);

  reg [3:0] counter;

  initial counter = 4'd0;

  always @(posedge clk) begin
    if (reset)
      counter <= 4'd0;
    else if (inc && counter != 4'd15)
      counter <= counter + 4'd1;
  end

  // Safety: counter never exceeds the 4-bit bit-width maximum.
  // Trivially inductive due to the saturating increment at counter
  // == 4'd15. BMC unrolls to bound 10, k-induction closes in one
  // step, IC3 infers the invariant directly.
  p_counter_bounded:
    assert property (@(posedge clk) counter <= 4'd15);

endmodule
