# `athanor sv-invariants` corpus dogfood (ATH-423)

Pattern for running `kairos.sv.invariants.discover_invariants` over a
task corpus. Useful for CI gating, regression sweeps, or demoing
the dispatcher across a real customer's spec collection.

The mainline integration test
(`tests/integration/test_sv_invariants_corpus.py`) iterates the same
shape on every hw-cbmc env task with property names declared, using a
deterministic stub proposer. This demo shows the customer-facing
form: replace the stub with a real LLM proposer, point at your spec
directory, and turn the loop into a coverage sweep.

## What this shows

**Dispatch reliability across heterogeneous specs.** Every task in
the corpus produces a well-formed `InvariantDiscoveryResult`. The
dispatcher never crashes, even on broken-by-design student starters
or specs whose mutations all turn out semantically equivalent.

**Cap discipline.** `max_mutants` caps how many enumerated mutants
get processed per task; processed (killed-by-existing + surviving)
respects the cap. This keeps a 28-task corpus run under a few
minutes even with realistic per-EBMC budgets.

**Cost containment.** With a stub proposer the corpus runs at zero
LLM cost. Swap in `kairos.sv.invariants.make_proposer(model=...)` for
a real-LLM dogfood; budget visible in `result.total_cost_usd` per task.

## Customer pattern

```python
import json
from pathlib import Path

from kairos.sv.invariants import discover_invariants, make_proposer

# Customer's spec corpus (replace with your own glob).
SPEC_ROOT = Path("/path/to/your/specs")
proposer = make_proposer(model="anthropic/claude-sonnet-4-6")

results = []
for task_json in sorted(SPEC_ROOT.glob("configs/*.json")):
    cfg = json.loads(task_json.read_text())
    if not cfg.get("property_names"):
        continue
    sv = SPEC_ROOT / "specs" / Path(cfg["sv_file"]).name
    if not sv.is_file():
        continue

    r = discover_invariants(
        sv,
        top_module=cfg["top_module"],
        bound=cfg.get("bound", 10),
        max_mutants=10,
        max_proposals_per_mutant=2,
        timeout_sec=60,
        proposer=proposer,
    )
    results.append({
        "task_id": cfg["task_id"],
        "overall": r.overall,
        "mutants_enumerated": r.mutants_enumerated,
        "killed_by_existing": r.mutants_killed_by_existing,
        "surviving": r.mutants_surviving,
        "accepted_proposals": sum(1 for p in r.proposals if p.accepted),
        "cost_usd": r.total_cost_usd,
    })

# CI assertion: every task dispatches without crashing.
print(json.dumps(results, indent=2))
```

## Cross-refs

- `tests/integration/test_sv_invariants_corpus.py`: the mainline
  integration test that exercises this exact shape with a stub
  proposer (no LLM cost). 21 hw-cbmc tasks dispatch in roughly 2s.
- `tests/integration/test_hw_cbmc_corpus.py` (PR #71): sibling
  pattern for `run_ebmc` + `run_multi`. Re-uses the same env-discovery
  helpers (`_load_task_configs`, `_resolve_sv`).
- ATH-411 (`discover_invariants` feature, PR #67): the surface this
  corpus tests.
