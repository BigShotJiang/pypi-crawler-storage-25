# Changelog

All notable changes to athanor-sdk are documented here.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning: [SemVer](https://semver.org/spec/v2.0.0.html).

## [Unreleased] - v1.0 pre-stage

The v1.0 line is the first enterprise-customer-deliverable state of the
SDK. Lands when ATH-688 (customer onboarding) ratifies + ATH-689
(Sam-OPS GPG key provisioning) closes the signature-verification grace
period. Scope below is the work shipped on `main` ahead of those two
gates.

### Soundness (BREAKING)

- **`SimpleProveResult.proved` semantics flipped to mean SOUND.** ATH-949
  (PR forthcoming). Pre-fix, `result.proved=True` whenever the kernel
  accepted the proof, even if the post-build audit detected a custom
  axiom (`axiom_clean=False`) or a macro-bodied `sorry` (`vacuous_clean=False`).
  Customer code that read `if result.proved:` mistakenly took the
  unsound path. Post-fix, `result.proved=True` only when kernel-accepted
  AND `axiom_audit_clean is not False` AND `vacuous_truth_clean is not False`.
  New `result.kernel_accepted: bool` field carries the raw lake-build
  signal for the rare consumer who wants it under a name that doesn't
  lie. **Migration:** if you currently read `result.proved` and want to
  preserve old behavior (kernel-accept regardless of audit), switch to
  `result.kernel_accepted`. Otherwise the field-name match is the fix
  and no code change is needed.
- **`router._lean_prove_cascade` verdict synthesis now gates on the
  audit fields.** ATH-949. Pre-fix, the cascade synthesised
  `verification_status="machine_verified"` from `compiles + not has_sorry`
  alone, discarding `banned` and `axiom_clean` from the `lean_audit`
  step. Post-fix, machine_verified requires the full audit to pass, and
  the `lean_audit` step is REQUIRED for the cascade to mint a verified
  verdict at all.
- **`reject_vacuous=True` deprecated.** ATH-949. The flag is now
  redundant on the `proved` field (which is sound-by-default).
  Setting it emits `DeprecationWarning`; the explicit `rejected_reason`
  telemetry surface is still controlled by it. Removal scheduled for
  next minor.

### Security

- **License gate is fail-closed at every paid-tier callsite.**
  ATH-686 (PR `#221`). Pre-fix, a missing `~/.athanor/license.json`
  silently returned a permissive sentinel and granted every paid
  feature for free. Post-fix, missing license raises
  `LicenseScopeError`; the only legitimate bypass is the explicit
  `KAIROS_DEV_NO_LICENSE=1` env var (internal CI only). Programmatic
  Python API gates added at the function-entry of:
  - `kairos.prove.prove`
  - `kairos.prove.session`
  - `kairos.fleet.Orchestrator.__init__`
  - `kairos.sv.prove.prove`
  - `kairos.sv.cegar.cegar`
  - `kairos.sv.swarm.state_swarm`
  - `kairos.sv.swarm.cycle_swarm`
  - `kairos.sv.multi.run_multi`
  - `kairos.sv.invariants.discover_invariants`
  - `kairos.sv.ebmc.run_ebmc` (bottom-of-stack defense in depth)

  CLI subcommands (`athanor solve`, `cegar`, `sv-prove`) and
  `Environment(...)` were already gated; this closes the import-
  bypass that `from kairos.sv import ...; sv.cegar(...)` used to
  hit before reaching any gate.

- **Forged dev-bypass via `__dev_bypass__: true` in `license.json` is
  no longer a thing.** The dev-bypass marker moved off the raw-dict
  reflection path to a constructor-only `_internal_dev_bypass`
  dataclass field that `_parse` never sets. Customer crafting
  `{"__dev_bypass__": true, "products": []}` in their license.json
  now parses as a normal license with empty products and is denied.

- **`expires_at` is timezone-aware.** A naive timestamp like
  `"2027-01-01"` would have TypeErrored at the
  `parsed.expires_at < datetime.now(tz=UTC)` comparison; now the
  parser rejects naive timestamps up front with a clean
  `LicenseScopeError`.

- **License-gate decisions are audited.** ATH-690 (PR `#222`).
  Every `require_product` / `require_env_access` / `load_license`
  call emits one `AuditEvent` to a local JSONL journal at
  `~/.athanor/audit.jsonl` (always-on) plus, when
  `ATHANOR_SYNC_TOKEN` + Supabase URL are configured, the
  `license_gate_decisions` table on the platform Supabase. The
  audit emit is best-effort and never affects gate outcome.
  Inspect locally with `athanor audit show`.

- **Threat-model documentation at `docs/security-model.md`.**
  ATH-691 (PR `#223`). Two-layer gate description (cryptographic
  + policy), threat table with status + future plan per row,
  honest disclosure of the `KEYS_PROVISIONED=False` grace period.

- **`kairos.sv.{ebmc, prove}` un-gated for the free tier.**
  ATH-704 (PR `#239`). Both surfaces previously called
  `require_product("solve")`; the OSS Sledgehammer chain is
  free-tier scope, so the gate was lifted at the function entry.
  Paid-tier coverage (`kairos.sv.cegar`, `swarm`, `multi`,
  `invariants`, `kairos.prove`, `kairos.fleet.Orchestrator`) is
  unaffected.

- **Trace floor is JSONL, not Noop.** ATH-707 (PR `#245`).
  `default_sink_from_env` now falls through to `JsonlTraceSink`
  (`~/.athanor/traces/run-*.jsonl`) when no Supabase token is
  configured, instead of the silent `NoopTraceSink`. Free-tier
  customers always get a local trace on disk; opt-out via
  `KAIROS_NO_TRACE=1`.

### Added

- **`kairos init --lean-pythia <dest>`.** ATH-682 (PR `#278`). Free-tier
  bootstrap: scaffolds a working Lake project (lakefile, lean-toolchain,
  Examples/Smoke.lean) wired to the vendored Pythia + lean-machines + Mathlib.
  First-touch onboarding under 30 seconds: `kairos init --lean-pythia foo &&
  cd foo && lake build && lake env lean Examples/Smoke.lean` closes two
  trivial proofs via `by pythia` once Mathlib oleans land.

- **`kairos verify-batch <dir>`.** ATH-679 (PR `#276`). Free-tier bulk
  verifier: walks a tree of `.lean` files (respects `.gitignore`),
  verifies each via `kairos.lean.verify_proof`, writes a CSV with
  `path, compiles, has_sorry, sorry_count, score, banned, errors_first_line,
  elapsed_sec`. Parallel via `--workers`; supports `--lake-project` to point
  at a Lake root; survives Ctrl-C with partial CSV intact.

- **`kairos report <run_id>`.** ATH-680 (PR `#279`). Free-tier HTML
  report renderer over the `~/.athanor/runs/<run_id>/` layout from
  ATH-681. One self-contained HTML file (inline CSS, no external deps);
  sections for run metadata, per-event timeline, generated artefacts,
  EBMC outputs, refinement chain status. Missing optional sections render
  cleanly as empty.

- **`kairos.cedar` + `kairos.telos` registration stubs +
  `[cedar]` / `[telos]` extras.** ATH-684 (PR `#280`). Two new optional
  extras in `pyproject.toml`. `from kairos import cedar` (or `telos`)
  raises `CedarNotInstalledError` (or `TelosNotInstalledError`) with an
  install-hint when the extra is not installed; gives the surface a
  stable name customers can import-test against ahead of the v1.x
  vendor-and-wrap work.

- **§11 audit table appendix on `docs/sdk-tier-model.md`.** ATH-676
  (PR `#265`). Source-of-truth audit of `kairos.__all__` (23 entries) +
  10 public methods on exported classes. Each row classifies tier (free /
  paid solve / paid envs / mixed) + gate status (already-gated /
  transitively-gated / needs-gate / n/a) with a `file:line` source ref.

- **Documentation audit.** ATH-687 (PR `#282`). Per-doc verdict on
  every `.md` under `docs/` (9 customer-facing + 15 internal). Four
  stale session-note / closed-PR snapshots deleted (`capability-vs-cheat-dedup`,
  `e2e-3-verticals`, `pr-10-autoformalize-design`,
  `pr-10-autoformalize-drafter-prompts`). Wheel-leak check confirmed:
  `pyproject.toml` ships only `src/kairos/**`, never `docs/**`.

- **Per-attempt token + cost on `_SwarmAttempt`.** ATH-783 / ATH-784
  (PR `#283`). The trace schema now carries `prompt_tokens`,
  `completion_tokens`, `cost_usd`, the picked `candidate`, and a
  4 KB `prompt_first_4k` slice on every per-attempt event so platform
  cost tracking can roll up by attempt instead of by run. Capture
  cap bumped accordingly.

- **`kairos.__all__` docstring sweep + tier-classification regression test.**
  ATH-787 (PR `#284`). Every exported name + class now carries a
  free-vs-paid annotation in its docstring (`Tier classification: free`
  / `paid (require_product("solve"))`). New `tests/test_public_surface_docstrings.py`
  audits the live `__all__` at runtime and fails CI when an exported
  symbol is missing the annotation, drifts from the §11 audit table,
  or claims paid-tier without a real `require_product` gate at the
  function-entry.

- **`SimpleProveResult.next_actions` + `kairos.NextAction`.** ATH-728
  Phase 1. Failed `simple_prove_template` results now carry a list of
  typed retry suggestions (`TacticName`, `RegisterLemma`,
  `AddHypothesis`, `RephraseHypothesis`) so an agent loop can pick a
  structured action instead of regexing prose. Sourced from pythia's
  tagged-failure JSON (`[pythia.failure] {... next_actions: [...]}`,
  emitted under `set_option pythia.machineFormat true`) when present;
  falls back to a regex pass over raw lake stderr covering the five
  most common Lean error classes (unknown identifier / unknown
  constant, type mismatch, failed to synthesize, unsolved goals,
  tactic failed). Empty list on `proved=True`.

- **`simple_prove_template(refine_on_failure=True, max_refine_iterations=N)`
  + `kairos.RefinementStep`.** ATH-728 Phase 2. Opt-in BYO-LLM
  refinement loop: when the initial proof attempt fails and
  `refine_on_failure=True`, the SDK feeds the lake error + parsed
  `next_actions` back to the customer's configured BYO-LLM
  (Anthropic / OpenAI / Gemini) and asks for a revised Lean source,
  then re-verifies. Bounded by `max_refine_iterations` (default 3),
  short-circuits on the first success, and runs at `temperature=0`
  for determinism. Each iteration writes one `RefinementStep` to
  `result.refinement_history` (iteration, proved, lean_source,
  error, next_actions, wall_sec) plus a `run_dir/refine_<N>.lean`
  artifact for offline inspection. Graceful degradation when no
  BYO-LLM key is configured: the loop is skipped and a synthetic
  `[no-llm]` `RephraseHypothesis` action is prepended to
  `next_actions` telling the customer which env var to set.
  Transient LLM transport failures record a step and continue
  rather than aborting the loop. The winning (or final) source is
  persisted to `result.spec_path` so the customer can read what
  was actually proved.

- **Free vs paid tier model documented at `docs/sdk-tier-model.md`.**
  ATH-675 (PR `#220`). Source-of-truth doc for what the free tier
  ships (Lean verification, lean-machines, Cython scoring/lint,
  observability primitives, simple_prove, batch verify, local
  report rendering) and what the paid tier adds (Orchestrator,
  full prove pipeline, kairos.sv.* research stack, Supabase trace
  upload to athanor-ai.com).

- **`kairos.local_output.LocalOutputTraceSink`** + **`kairos.trace.MultiSink`**
  (ATH-681 followup). LocalOutputTraceSink is a `TraceSink` Protocol
  adapter over the existing `LocalOutputDir` storage primitive: it
  routes per-event TraceEvents to `traces.jsonl` and writes
  `manifest.json` on session exit. MultiSink is a fan-out adapter
  that dispatches every TraceSink call to a list of inner sinks +
  contains errors so one flaky inner sink doesn't poison the others.
  Used by `kairos.session()` to dual-write paid runs to both
  SupabaseTraceSink (cloud) and LocalOutputTraceSink (local backup).

- **`kairos.simple_prove` + BYO-LLM template registry.** ATH-697.
  Free-tier entry point: customer hands the SDK a natural-
  language hypothesis, the SDK matches it against a registry of
  Pythia-API templates and (when no template fits) routes through
  a BYO-LLM autoformalization step that reads the customer's own
  `OPENAI_API_KEY` / `ANTHROPIC_API_KEY` from `os.environ` only.
  No Athanor key, no token charge, no centralized completion
  proxy. Vendored Pythia templates (13 total) cover the
  Pythia-Quantization + HR-CS + SubGaussian-MG + MatchingConstants
  surface: `sharp_constant_equivalence`, `sharp_constant_ranking`,
  `sharp_constant_positive`, `bit_precision_time`, `pythia_smoke`,
  `eta_hr_nonneg`, `eta_hr_monotone`, `eta_betting_positive`,
  `exp_process_supermartingale`, `ville_inequality`,
  `hr_stopping_admissible`, `quantization_error_bound`,
  `equivalence_break`. ATH-714 (PR `#249`) added a natural-English
  keyword fallback for the 10 patterns whose templates need no
  per-call bindings.

- **Pythia Lake auto-bootstrap.** ATH-702 (PR `#238`). On first
  `simple_prove(...)` call, the SDK clones `pythia` to
  `~/.athanor/pythia-runs/`, pins `leanprover/lean4:v4.28.0`, and
  runs `lake build` so the customer's "30-second proof" claim in
  the README actually clears the Lean kernel. Honors
  `KAIROS_SIMPLE_PROVE_SKIP_VERIFY=1` for hermetic test runs.

- **Batch verify CLI + programmatic API.** ATH-700 / ATH-701.
  `athanor verify-batch <hypotheses.jsonl>` runs `simple_prove`
  across a batch and emits a JSONL result stream + a
  human-readable summary. Programmatic equivalent at
  `kairos.simple_prove.verify_batch`.

- **OSS Sledgehammer adapter chain.** ATH-705 / ATH-706 (PRs
  `#240`-`#243`). New free-tier adapters wrapping the Lean kernel
  reconstruction targets: `kairos.sv.cvc5.run_cvc5` (SMT-LIB),
  `kairos.sv.cbmc.run_cbmc` (C bounded model checking),
  `kairos.sv.vampire.run_vampire` + `kairos.sv.eprover.run_eprover`
  (TPTP first-order), `kairos.sv.dafny.run_dafny`. Each adapter
  owns its binary's invocation contract, returns a normalized
  result dataclass with verdict + transcript + structured error,
  and surfaces a clean error when the binary is not on PATH.

- **Goal-shape dispatcher.** ATH-708 (PR `#247`).
  `kairos.sv.dispatch.dispatch(goal_text, *, force_adapter,
  timeout_sec)` pattern-matches a goal payload against the
  adapter chain (smt2 -> cvc5, tptp -> vampire, sv -> ebmc,
  c -> cbmc, dafny -> dafny), reads `Path` inputs, and surfaces
  `DispatchError` for ambiguous shapes. Static-import audit
  fences the dispatcher off the paid surface.

- **Vendored `lean-machines` corpus + EBMC bridge.** ATH-657. New
  free-tier feature: customer writes high-level functional spec as
  a Lean Machine, SDK auto-generates SystemVerilog assertions for
  EBMC verification of customer RTL. Public surface:
  `kairos.lean_machines.{to_sva, k_induction_strengthen,
  splice_strengthening, parse_cex_trace, cex_to_lean_refutation,
  run_refinement_chain}`.

- **Batched event INSERTs in `SupabaseTraceSink`.** ATH-779 (PR `#281`).
  Per-event INSERTs to `sdk_agent_events` are batched (default 25
  events per batch, 2-second age cap) with flush triggers on batch-full,
  age, `close_run`, `flush()`, and `atexit`. Cuts the platform-side
  request rate without changing the at-most-once delivery contract.

- **Lazy `SupabaseTraceSink.open_run`.** ATH-759 (PR `#273`). The
  initial run-row INSERT now defers until the first event emit, so
  free-tier sessions that never emit (just construct + close)
  no longer hit the platform.

- **`kairos.observe` ContextVar fan-out fallback.** ATH-738 (PR `#258`).
  When `litellm_trace_session` runs across worker threads,
  `_LATEST_SESSION` (module-global) lets the inner trace context
  reach LLM call sites whose ContextVar copy was lost on thread
  spawn. Closes the silent-trace-loss class on threaded fan-out.

- **Anti-LLM-slop markdown lint** at `tools/md_lint.py` +
  `.github/workflows/md-lint.yml`. Mirror of the canonical pattern
  from `kairos-cedar` / `kairos-stats-lean`. Catches em-dashes,
  triple-hyphens in prose, and a vocabulary deny-list at commit
  time. 26 existing `.md` files swept clean in PR `#224`.
  Hotfix in PR `#244` blanks markdown table separators
  (`| --- |`) and standalone `---` dividers before the
  triple-hyphen check, so legitimate Markdown structure is no
  longer flagged.

### Changed

- **`kairos.session()` now writes to `~/.athanor/runs/<session_id>/`
  by default.** ATH-681 followup. Pre-change, a session opened without
  an explicit `trace_sink` was a no-op observability-wise (no events
  captured, no files written). Post-change, the session auto-installs
  `kairos.local_output.LocalOutputTraceSink` so every event lands in
  `traces.jsonl` and a `manifest.json` lands on session exit. Privacy
  is preserved (local-only writes; no phone-home). When the caller
  passes `trace_sink=SupabaseTraceSink()`, the session composes a
  `kairos.trace.MultiSink` that fans out to BOTH the caller's sink
  AND a `LocalOutputTraceSink` so paid runs get cloud + local backup
  per `docs/sdk-tier-model.md` §3.6. Customers who want zero-
  filesystem behavior set `KAIROS_LOCAL_OUTPUT_DISABLE=1`. The SDK's
  own pytest suite auto-disables the wrap (detected via
  `PYTEST_CURRENT_TEST`) unless `KAIROS_LOCAL_OUTPUT_DIR` is set,
  so existing test suites + CI runs don't pollute disk.

- `kairos.license_scope.License.is_dev_bypass` no longer reflects a
  raw-dict claim; it is now an internal-state property tied to the
  module-level `_DEV_BYPASS_LICENSE` singleton. Migration: callers
  comparing `license.raw.get("__dev_bypass__")` need to switch to
  `license.is_dev_bypass`.

- `_parse_expires_at` now requires the parsed datetime to be
  timezone-aware. Customer license files dated as date-only strings
  must be reissued with `Z` or `+HH:MM` suffixes. Migration: Sam-OPS
  re-issues affected customer licenses; until then those licenses
  fail at gate-load with a clear "must include a timezone offset"
  reason.

### Deprecated

- The legacy "RL environment access" customer onboarding flow under
  `/api/admin/invite` (organization + auth.users + organization_environments
  triple). ATH-688 directs all new customers through the SDK-license
  flow without env-grant; the legacy endpoint stays for existing
  customers but is not the path forward.

### Pending v1.0 release gates

- ATH-688 - Sam ratify on Q1/Q4/Q5 of customer-onboarding flow.
  Blocks the dashboard skeleton, slimmer admin endpoint, and the
  SDK-side `org_id` claim parsing.
- ATH-689 - Sam-OPS provisions the real Athanor GPG key + flips
  `kairos._keys.KEYS_PROVISIONED = True`. Blocks customer #1.
  Until this lands, license signature verification is *skipped*
  with a WARNING log every load; the policy gate alone defends.



## [0.4.2] - 2026-04-25

### Fixed

- `default_sink_from_env` accepts `ATHANOR_SYNC_TOKEN` as
  auth-equivalent to `SUPABASE_SERVICE_ROLE_KEY`. Pre-fix, customers
  rotating via the sync-token path silently fell through to
  `NoopTraceSink` (ATH-650 finding #1, PR `#202`).
- `KAIROS_TRACE_STRICT=1` raises on `close_run` PATCH failures, not
  just initial open (ATH-647 finding #5, PR `#201`).

### Changed

- Stale `OpusOrchestrator` forward-references scrubbed from public
  surfaces; `kairos.fleet.Orchestrator` is the only orchestrator
  shape (ATH-651 P2.7, PR `#208`).



## Earlier

Prior history is documented inline in commit messages and Linear
issues; see `git log` and the ATH-* references therein.
