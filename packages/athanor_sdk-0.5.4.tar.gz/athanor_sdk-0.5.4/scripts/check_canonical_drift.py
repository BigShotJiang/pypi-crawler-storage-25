#!/usr/bin/env python3
"""ATH-358 canonical-drift CI check.

Verifies that `src/kairos/spec_v1.py`, `spec_compiler.py`,
`spec_validate.py`, `spec_schema.json` match the canonical copies in
`athanor-builder/solve/shared/`.

Two facts make this non-trivial:

  1. `spec_compiler.py` (SDK) vs `spec_compile.py` (canonical): same
     content modulo an `import` rewrite
     (`solve.shared.spec_v1` → `athanor.spec_v1`).
  2. `spec_validate.py` same deal — single-line `import` rewrite.
  3. `spec_v1.py` and `spec_schema.json` are byte-identical.

The check:

  * For `spec_v1.py` and `spec_schema.json`: SDK local sha256 must
    match the pinned canonical hash.
  * For `spec_compiler.py` and `spec_validate.py`: SDK local content,
    with `from athanor.` rewritten back to `from solve.shared.`,
    must match the pinned canonical hash.

Pinned hashes live in `schemas/canonical-hashes.txt`. To update after a
legitimate canonical change, see the header of that file.

The optional `--fetch-canonical` mode (only run on `main` in CI, not
PRs) fetches the canonical files directly from athanor-builder main
and recomputes hashes to catch the case where the pin is itself
stale. Requires network + a fetch token; for PRs we trust the pin.

Exit codes:
  0 — all four files match the pin
  1 — at least one file drifted
  2 — missing SDK file or pin file
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent.parent
SDK_DIR = REPO_ROOT / "src" / "kairos"
PIN_FILE = REPO_ROOT / "schemas" / "canonical-hashes.txt"

# SDK filename → canonical filename. When different, we re-rewrite
# the import before hashing.
MIRROR_MAP = {
    "spec_v1.py":        ("spec_v1.py", False),
    "spec_compiler.py":  ("spec_compile.py", True),
    "spec_validate.py":  ("spec_validate.py", True),
    "spec_schema.json":  ("spec_schema.json", False),
}


def _un_rewrite_imports(content: bytes) -> bytes:
    """Reverse the SDK-side `solve.shared.* → athanor.*` import
    rewrite so the SDK copy hashes to the canonical content."""
    return content.replace(
        b"from kairos.spec_v1 import",
        b"from solve.shared.spec_v1 import",
    )


def _load_pinned_hashes() -> dict[str, str]:
    if not PIN_FILE.is_file():
        print(f"FATAL: pin file not found: {PIN_FILE}", file=sys.stderr)
        sys.exit(2)
    pins: dict[str, str] = {}
    for line in PIN_FILE.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2:
            continue
        pins[parts[1]] = parts[0]
    return pins


def main() -> int:
    pins = _load_pinned_hashes()

    drifted: list[str] = []
    missing: list[str] = []
    for sdk_name, (canonical_name, needs_rewrite) in MIRROR_MAP.items():
        sdk_path = SDK_DIR / sdk_name
        if not sdk_path.is_file():
            missing.append(str(sdk_path))
            continue
        content = sdk_path.read_bytes()
        if needs_rewrite:
            content = _un_rewrite_imports(content)
        actual = hashlib.sha256(content).hexdigest()
        expected = pins.get(canonical_name)
        if expected is None:
            drifted.append(
                f"{sdk_name}: no pinned hash for canonical {canonical_name!r}"
            )
            continue
        if actual != expected:
            drifted.append(
                f"{sdk_name}: expected {expected} (canonical {canonical_name}), "
                f"got {actual}"
            )

    if missing:
        print("FATAL: SDK file(s) missing:")
        for m in missing:
            print(f"  {m}")
        return 2

    if drifted:
        print("FAIL: SDK mirrors drifted from canonical:")
        for d in drifted:
            print(f"  {d}")
        print()
        print("See schemas/canonical-hashes.txt header for the re-sync recipe.")
        return 1

    print(f"OK — all {len(MIRROR_MAP)} SDK mirror(s) match pinned canonical hashes.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
