#!/usr/bin/env python3
"""DSPv2 historical-results backfill → Supabase via kairos SDK trace sink.

ATH-510 follow-up. Research has ~50 historical files on the research VM
at /home/aidayang/ath-510-verification-capability-ladder/{results,logs}/
that predate the kairos.session() instrumentation Aidan asked for. This
script ports them into Supabase so /solve-runs at tahoe.athanor-ai.com
shows the full DSPv2 sweep history, not just the runs going forward.

Two input shapes (run with --csv-glob, --json-glob, or both):

1. Per-target CSV — `results/dspv2_*.csv`:
   header: target,capability,drafter,attempt,sampler,closed,build_ok,
           axioms_clean,wall_sec,candidate
   Each row is one attempt against `target`. Rows are grouped by
   target → one solve_runs row per target, one sdk_agent_events row
   per attempt.

2. Per-target JSON — `logs/<tid>-<precision>-<ts>.json`:
   top-level: theorem_id, precision, timestamp, statement_header,
              aristotle_proof, prompt, attempts
   per-attempt: attempt_idx, sampler, raw_output_full, candidate_clean,
                verify_result, closed, proof_match
   verify_result: tid, build_ok, build_wall_sec, build_stdout_tail,
                  build_stderr_tail, axioms_clean, axioms_detail,
                  dead_tactic_count, proof_length_chars, total_wall_sec
   File → one solve_runs row, attempts → one sdk_agent_events row each.

## Idempotence

Each solve_run gets a deterministic run_id derived from
(source_filename, tid, precision). Re-running the script with the same
files produces the same run_ids; SupabaseTraceSink.open_run upserts on
the id, so re-running is a clean no-op.

## Usage (research VM)

    export SUPABASE_URL=...           # or NEXT_PUBLIC_SUPABASE_URL
    export SUPABASE_SERVICE_ROLE_KEY=...

    # Dry-run — print what would be written, don't POST.
    python3 scripts/dspv2_backfill_to_supabase.py \\
        --csv-glob "/home/aidayang/ath-510-verification-capability-ladder/results/dspv2_*.csv" \\
        --json-glob "/home/aidayang/ath-510-verification-capability-ladder/logs/*.json" \\
        --dry-run

    # Real run — drop --dry-run.
    python3 scripts/dspv2_backfill_to_supabase.py \\
        --csv-glob "/home/aidayang/ath-510-verification-capability-ladder/results/dspv2_*.csv" \\
        --json-glob "/home/aidayang/ath-510-verification-capability-ladder/logs/*.json"

## Notes

* vertical="other" until athanor-platform PR #282 (theorem_proving + lean
  CHECK widen) lands in prod. After that, switch to vertical="theorem_proving".
* run_subtype="theorem_proving" on every event (matches the SDK registry).
* event_type="dspv2_attempt" — not in the kairos.trace_schema registry yet;
  emits with payload preserved as-is per the zero-data-loss contract
  (one-shot WARN per session is fine for backfill).
* Cost is not estimated for backfill rows (we don't have prompt/completion
  token counts on disk uniformly). token_cost_usd left as None.
"""
from __future__ import annotations

import argparse
import csv
import glob as glob_module
import hashlib
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterator

# Lazy import — keep the script runnable for --dry-run without the SDK
# installed (so research can preview output before installing the wheel).
try:
    from kairos.trace import (
        EscalationEvent,  # noqa: F401 — pulled into scope so SupabaseTraceSink works
        TraceEvent,
        SupabaseTraceSink,
    )
except ImportError:
    TraceEvent = None  # type: ignore[assignment, misc]
    SupabaseTraceSink = None  # type: ignore[assignment, misc]


def _stable_run_id(source: str, tid: str, precision: str | None) -> str:
    """Deterministic run_id for backfill upsert idempotence.

    Format: dspv2-backfill-<sha256[:12]> where the hash is over the
    ordered triple (source_filename, tid, precision). SDK's open_run
    upserts on (id), so re-running the backfill without changing source
    files is a clean no-op.
    """
    h = hashlib.sha256()
    h.update(source.encode("utf-8"))
    h.update(b"\x00")
    h.update(tid.encode("utf-8"))
    h.update(b"\x00")
    h.update((precision or "").encode("utf-8"))
    return f"dspv2-backfill-{h.hexdigest()[:12]}"


def _parse_csv_row(row: dict[str, str]) -> dict[str, Any]:
    """Coerce CSV-row strings into the typed payload."""
    def _maybe_int(s: str) -> int | None:
        try:
            return int(s)
        except (TypeError, ValueError):
            return None

    def _maybe_float(s: str) -> float | None:
        try:
            return float(s)
        except (TypeError, ValueError):
            return None

    def _maybe_bool(s: str) -> bool | None:
        if s is None:
            return None
        v = s.strip().lower()
        if v in ("true", "1", "yes", "t"):
            return True
        if v in ("false", "0", "no", "f"):
            return False
        return None

    return {
        "tid": row.get("target", ""),
        "capability": row.get("capability", ""),
        "drafter": row.get("drafter", ""),
        "attempt_idx": _maybe_int(row.get("attempt", "")),
        "sampler": row.get("sampler", ""),
        "closed": _maybe_bool(row.get("closed", "")),
        "build_ok": _maybe_bool(row.get("build_ok", "")),
        "axioms_clean": _maybe_bool(row.get("axioms_clean", "")),
        "wall_sec": _maybe_float(row.get("wall_sec", "")),
        "candidate_first_500": (row.get("candidate", "") or "")[:500],
    }


def _csv_groups(csv_path: Path) -> Iterator[tuple[str, list[dict[str, Any]]]]:
    """Yield (target_tid, [attempt_payloads]) for each unique target in a CSV.

    Preserves CSV-row order within a group so attempt ordering is stable
    across re-runs (downstream `sequence` field assigned by enumerate).
    """
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    with csv_path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            tid = row.get("target", "").strip()
            if not tid:
                continue
            groups[tid].append(_parse_csv_row(row))
    for tid, attempts in groups.items():
        yield tid, attempts


def _per_target_close_kwargs(attempts: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate per-target close-run kwargs from a list of attempts."""
    any_closed = any(a.get("closed") is True for a in attempts)
    total_wall = sum(
        a["wall_sec"] for a in attempts
        if isinstance(a.get("wall_sec"), (int, float))
    )
    return {
        "status": "succeeded" if any_closed else "failed",
        "wall_time_seconds": float(total_wall) if total_wall > 0 else None,
        "outcome_verdict": {
            "closed": any_closed,
            "n_attempts": len(attempts),
            "n_build_ok": sum(1 for a in attempts if a.get("build_ok") is True),
            "samplers": sorted(
                {a.get("sampler") for a in attempts if a.get("sampler")}
            ),
        },
    }


def _emit_csv_target(
    sink: Any,
    csv_path: Path,
    tid: str,
    attempts: list[dict[str, Any]],
    *,
    dry_run: bool,
) -> None:
    """Open, emit, close one target's run from CSV rows."""
    run_id = _stable_run_id(str(csv_path.name), tid, precision=None)
    target_label = f"dspv2-csv-{tid}"
    open_kwargs = dict(
        run_id=run_id,
        vertical="other",
        builder_model=None,
        target=target_label,
        pipeline_version="kairos-sdk-backfill",
    )
    if dry_run:
        print(
            f"[DRY-RUN] open_run {run_id} target={target_label!r} "
            f"({len(attempts)} attempts)"
        )
    else:
        sink.open_run(**open_kwargs)

    for seq, attempt in enumerate(attempts):
        payload = dict(attempt)
        payload["session_id"] = run_id
        if dry_run:
            print(
                f"[DRY-RUN]   emit seq={seq} event=dspv2_attempt "
                f"sampler={attempt.get('sampler')!r} "
                f"closed={attempt.get('closed')!r}"
            )
        else:
            event = TraceEvent(
                run_id=run_id,
                run_type="sdk_orchestration",
                run_subtype="theorem_proving",
                event_type="dspv2_attempt",
                sequence=seq,
                payload=payload,
            )
            sink.emit(event)

    close_kwargs = _per_target_close_kwargs(attempts)
    if dry_run:
        print(
            f"[DRY-RUN] close_run {run_id} status={close_kwargs['status']} "
            f"wall={close_kwargs['wall_time_seconds']} "
            f"verdict={close_kwargs['outcome_verdict']!r}"
        )
    else:
        sink.close_run(run_id=run_id, **close_kwargs)


_JSON_FILENAME_RE = re.compile(
    r"^(?P<tid>.+?)-(?P<precision>fp16|fp32|int4|int8|gptq_int4|gptq_int8)-"
    r"(?P<ts>[\d_TZ:-]+)\.json$"
)


def _parse_json_attempts(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Project the per-attempt fields of a logs/<tid>-…json file."""
    attempts_raw = data.get("attempts") or []
    out: list[dict[str, Any]] = []
    for raw in attempts_raw:
        verify = raw.get("verify_result") or {}
        out.append({
            "tid": data.get("theorem_id"),
            "precision": data.get("precision"),
            "drafter": raw.get("drafter") or data.get("drafter"),
            "attempt_idx": raw.get("attempt_idx"),
            "sampler": raw.get("sampler"),
            "closed": raw.get("closed"),
            "proof_match": raw.get("proof_match"),
            "build_ok": verify.get("build_ok"),
            "axioms_clean": verify.get("axioms_clean"),
            "axioms_detail": verify.get("axioms_detail"),
            "dead_tactic_count": verify.get("dead_tactic_count"),
            "proof_length_chars": verify.get("proof_length_chars"),
            "wall_sec": (
                verify.get("total_wall_sec")
                or verify.get("build_wall_sec")
            ),
            "build_stdout_tail": verify.get("build_stdout_tail"),
            "build_stderr_tail": verify.get("build_stderr_tail"),
            "candidate_first_500": (raw.get("candidate_clean", "") or "")[:500],
        })
    return out


def _emit_json_file(sink: Any, json_path: Path, *, dry_run: bool) -> bool:
    """Open, emit, close one target's run from a per-target JSON file.

    Returns False when the file shape isn't recognized; caller logs +
    skips. True when the run was emitted (or dry-run-printed).
    """
    try:
        data = json.loads(json_path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[skip] {json_path.name}: parse error {exc}", file=sys.stderr)
        return False
    tid = data.get("theorem_id")
    precision = data.get("precision")
    if not tid:
        m = _JSON_FILENAME_RE.match(json_path.name)
        if m:
            tid = m.group("tid")
            precision = precision or m.group("precision")
    if not tid:
        print(f"[skip] {json_path.name}: no theorem_id", file=sys.stderr)
        return False

    attempts = _parse_json_attempts(data)
    if not attempts:
        print(f"[skip] {json_path.name}: no attempts", file=sys.stderr)
        return False

    run_id = _stable_run_id(str(json_path.name), tid, precision)
    target_label = (
        f"dspv2-json-{tid}-{precision}" if precision else f"dspv2-json-{tid}"
    )
    open_kwargs = dict(
        run_id=run_id,
        vertical="other",
        builder_model=None,
        target=target_label,
        pipeline_version="kairos-sdk-backfill",
    )
    if dry_run:
        print(
            f"[DRY-RUN] open_run {run_id} target={target_label!r} "
            f"({len(attempts)} attempts)"
        )
    else:
        sink.open_run(**open_kwargs)

    for seq, attempt in enumerate(attempts):
        payload = dict(attempt)
        payload["session_id"] = run_id
        if dry_run:
            print(
                f"[DRY-RUN]   emit seq={seq} event=dspv2_attempt "
                f"sampler={attempt.get('sampler')!r} "
                f"closed={attempt.get('closed')!r}"
            )
        else:
            event = TraceEvent(
                run_id=run_id,
                run_type="sdk_orchestration",
                run_subtype="theorem_proving",
                event_type="dspv2_attempt",
                sequence=seq,
                payload=payload,
            )
            sink.emit(event)

    close_kwargs = _per_target_close_kwargs(attempts)
    if dry_run:
        print(
            f"[DRY-RUN] close_run {run_id} status={close_kwargs['status']} "
            f"wall={close_kwargs['wall_time_seconds']}"
        )
    else:
        sink.close_run(run_id=run_id, **close_kwargs)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Backfill DSPv2 historical CSV+JSON files into Supabase "
                    "via the kairos SDK trace sink. ATH-510 / ATH-545 follow-up.",
    )
    parser.add_argument(
        "--csv-glob", action="append", default=[],
        help="Glob for CSV files. Repeatable. e.g. /path/to/dspv2_*.csv",
    )
    parser.add_argument(
        "--json-glob", action="append", default=[],
        help="Glob for per-target JSON files. Repeatable.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print what would be POSTed; don't open a sink or hit Supabase.",
    )
    args = parser.parse_args()

    if not args.csv_glob and not args.json_glob:
        parser.error("provide at least one --csv-glob or --json-glob")

    if not args.dry_run:
        if SupabaseTraceSink is None:
            print(
                "kairos.trace.SupabaseTraceSink unavailable — "
                "install athanor-sdk + run with credentials, or pass --dry-run",
                file=sys.stderr,
            )
            return 1
        if not (
            os.environ.get("SUPABASE_URL")
            or os.environ.get("NEXT_PUBLIC_SUPABASE_URL")
        ):
            print(
                "Set SUPABASE_URL (or NEXT_PUBLIC_SUPABASE_URL) before running. "
                "Pass --dry-run to skip the credential check.",
                file=sys.stderr,
            )
            return 1
        if not os.environ.get("SUPABASE_SERVICE_ROLE_KEY"):
            print(
                "Set SUPABASE_SERVICE_ROLE_KEY before running.",
                file=sys.stderr,
            )
            return 1
        sink = SupabaseTraceSink()
    else:
        sink = None  # dry-run path doesn't need a real sink

    csv_targets = 0
    json_files = 0

    for pat in args.csv_glob:
        for raw in sorted(glob_module.glob(pat)):
            csv_path = Path(raw)
            if not csv_path.is_file():
                continue
            for tid, attempts in _csv_groups(csv_path):
                _emit_csv_target(
                    sink, csv_path, tid, attempts, dry_run=args.dry_run,
                )
                csv_targets += 1

    for pat in args.json_glob:
        for raw in sorted(glob_module.glob(pat)):
            json_path = Path(raw)
            if not json_path.is_file():
                continue
            ok = _emit_json_file(sink, json_path, dry_run=args.dry_run)
            if ok:
                json_files += 1

    print(
        f"\n{'[DRY-RUN] ' if args.dry_run else ''}"
        f"backfill summary: {csv_targets} CSV-target groups, "
        f"{json_files} JSON files",
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
