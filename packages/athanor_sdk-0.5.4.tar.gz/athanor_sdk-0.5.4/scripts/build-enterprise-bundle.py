#!/usr/bin/env python3
"""ATH-390 — Build a per-customer enterprise delivery tarball.

Reads a signed `license.json` and assembles a tarball that contains
ONLY the components that customer's license grants. Envs-only
customers do NOT receive the `athanor-builder` tarball (Tier-1 IP);
solve-licensed customers do. Scoring containers are filtered to
`license.envs[]` so we don't ship envs the customer can't use.

Rationale (Aidan 2026-04-20): "why do we ship the private builder to
customers if it's our IP?" — structural answer is "we only ship it to
customers who need it." This script is the ship-time enforcement;
`license_scope.require_product()` is the install-time enforcement;
both are needed.

## Usage

    python3 scripts/build-enterprise-bundle.py \\
        --license       /path/to/customer/license.json \\
        --license-sig   /path/to/customer/license.json.sig \\
        --sdk-tarball   /path/to/athanor-sdk-0.4.0.tar.gz \\
        --sdk-sig       /path/to/athanor-sdk-0.4.0.tar.gz.sig \\
        --install-sh    scripts/install.sh \\
        --install-sh-sig /path/to/install.sh.sig \\
        --pubkey        /path/to/pubkey.asc \\
        [--builder-tarball   /path/to/athanor-builder-0.4.0.tar.gz] \\
        [--builder-sig       /path/to/athanor-builder-0.4.0.tar.gz.sig] \\
        [--scoring-containers-dir  /path/to/scoring-containers/] \\
        --output        /dist/athanor-enterprise-acme-0.4.0.tar.gz

## Inclusion rules

| Asset | Always | `products` includes | Per-env filter |
|-------|--------|---------------------|----------------|
| `install.sh` (+sig) | ✓ |  |  |
| `pubkey.asc` | ✓ |  |  |
| `license.json` (+sig) | ✓ |  |  |
| `athanor-sdk-*.tar.gz` (+sig) | ✓ |  |  |
| `athanor-builder-*.tar.gz` (+sig) |  | `"solve"` |  |
| `scoring-containers/<env>.tar` | | `"envs"` (or `"solve"`) | ✓ `env in license.envs[]` |
| `manifest.json` | ✓ (generated) |  |  |

## Exit codes

    0 — bundle written
    1 — invariant violation (missing required flag, missing referenced file,
        license grants solve but --builder-tarball not provided, etc.)
    2 — bad CLI invocation (argparse-level)

## Security notes

Detached `.sig` files are INCLUDED ALONGSIDE each signed artifact if
provided. install.sh verifies them against the pinned pubkey
fingerprint (ATH-369). This script does NOT re-sign anything — it's
a re-packaging layer only. The upstream signing pipeline must have
already produced the `.sig` files before we run.

This script is INTERNAL — it runs in our build environment, never
on a customer machine. Don't ship it in the bundle.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path


# ─── License parsing ────────────────────────────────────────────────────

def _parse_license(license_path: Path) -> dict:
    """Parse + minimally validate the license file.

    Raises SystemExit(1) on any structural issue. Full signature
    verification happens at install time via install.sh; we just
    need products[] and envs[] to drive packaging.
    """
    if not license_path.is_file():
        _fatal(f"license file not found: {license_path}")
    try:
        raw = json.loads(license_path.read_text())
    except json.JSONDecodeError as exc:
        _fatal(f"{license_path} is not valid JSON: {exc}")
    if not isinstance(raw, dict):
        _fatal(f"{license_path} must be a JSON object")

    products = raw.get("products", [])
    envs = raw.get("envs", [])
    if not isinstance(products, list) or not all(isinstance(p, str) for p in products):
        _fatal(f"license.products must be list[str]; got {products!r}")
    if not isinstance(envs, list) or not all(isinstance(e, str) for e in envs):
        _fatal(f"license.envs must be list[str]; got {envs!r}")
    return raw


# ─── Tarball assembly ───────────────────────────────────────────────────

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _add_file(tar: tarfile.TarFile, src: Path, arcname: str) -> dict:
    """Add a file to the tarball and return a manifest entry."""
    if not src.is_file():
        _fatal(f"referenced file does not exist: {src}")
    tar.add(src, arcname=arcname)
    return {
        "path": arcname,
        "size": src.stat().st_size,
        "sha256": _sha256(src),
    }


def build_bundle(
    *,
    license_path: Path,
    license_sig: Path,
    sdk_tarball: Path,
    sdk_sig: Path,
    install_sh: Path,
    install_sh_sig: Path,
    pubkey: Path,
    builder_tarball: Path | None,
    builder_sig: Path | None,
    scoring_containers_dir: Path | None,
    output: Path,
) -> dict:
    """Assemble the enterprise bundle. Returns the generated manifest."""
    license_data = _parse_license(license_path)
    products = set(license_data.get("products", []))
    envs = list(license_data.get("envs", []))
    org = license_data.get("org", "unknown")

    # Invariant: solve in products ⇒ builder tarball required.
    if "solve" in products and builder_tarball is None:
        _fatal(
            "license grants 'solve' but --builder-tarball was not provided. "
            "solve requires the builder; refusing to ship a broken bundle."
        )
    # Invariant: if builder is included, its sig must be too (install.sh
    # will refuse to extract an unsigned builder).
    if builder_tarball is not None and builder_sig is None:
        _fatal(
            "--builder-tarball provided but --builder-sig missing. "
            "install.sh will fail signature verification at install time."
        )
    # Invariant: solve is the only product that meaningfully uses the
    # builder; shipping a builder to an envs-only customer defeats the
    # point of this script. Refuse explicitly.
    if builder_tarball is not None and "solve" not in products:
        _fatal(
            "--builder-tarball provided but license.products does not "
            f"include 'solve' (products={sorted(products)}). Refusing — "
            "envs-only customers don't need the builder (that's the whole "
            "point of ATH-390)."
        )

    manifest: dict = {
        "schema": "athanor-enterprise-bundle/v1",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "license": {
            "org": org,
            "products": sorted(products),
            "envs": sorted(envs),
        },
        "contents": [],
        "excluded": [],
    }

    output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(output, "w:gz") as tar:
        # ─── Always-included ──────────────────────────────────────────
        manifest["contents"].append(_add_file(tar, install_sh, "install.sh"))
        manifest["contents"].append(_add_file(tar, install_sh_sig, "install.sh.sig"))
        manifest["contents"].append(_add_file(tar, pubkey, "pubkey.asc"))
        manifest["contents"].append(_add_file(tar, license_path, "license.json"))
        manifest["contents"].append(_add_file(tar, license_sig, "license.json.sig"))
        manifest["contents"].append(_add_file(tar, sdk_tarball, sdk_tarball.name))
        manifest["contents"].append(_add_file(tar, sdk_sig, sdk_sig.name))

        # ─── Conditional: builder (solve license) ─────────────────────
        if "solve" in products:
            assert builder_tarball is not None and builder_sig is not None
            manifest["contents"].append(_add_file(tar, builder_tarball, builder_tarball.name))
            manifest["contents"].append(_add_file(tar, builder_sig, builder_sig.name))
        else:
            manifest["excluded"].append({
                "reason": "license.products does not include 'solve'",
                "asset": "athanor-builder-*.tar.gz",
            })

        # ─── Per-env scoring containers ───────────────────────────────
        # Rule: include only <env>.tar where env ∈ license.envs[]. A
        # shipping dir may contain more containers than we license; we
        # silently skip the extras and record them in manifest.excluded.
        if scoring_containers_dir is not None:
            if not scoring_containers_dir.is_dir():
                _fatal(f"--scoring-containers-dir does not exist: {scoring_containers_dir}")
            present = {p.stem: p for p in scoring_containers_dir.glob("*.tar")}
            licensed_set = set(envs)
            for env, path in sorted(present.items()):
                if env in licensed_set:
                    arcname = f"scoring-containers/{env}.tar"
                    manifest["contents"].append(_add_file(tar, path, arcname))
                else:
                    manifest["excluded"].append({
                        "reason": f"env '{env}' not in license.envs[]",
                        "asset": f"scoring-containers/{env}.tar",
                    })
            # Record any licensed envs for which no container was found
            # — not fatal (might be handled elsewhere), but worth flagging.
            missing = sorted(licensed_set - set(present.keys()))
            if missing:
                manifest["excluded"].append({
                    "reason": "no scoring container found on disk",
                    "asset": [f"scoring-containers/{e}.tar" for e in missing],
                })

        # ─── Manifest (always last; references every other entry) ─────
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False,
        ) as tmp:
            json.dump(manifest, tmp, indent=2, sort_keys=True)
            tmp_path = Path(tmp.name)
        try:
            tar.add(tmp_path, arcname="manifest.json")
        finally:
            tmp_path.unlink(missing_ok=True)

    return manifest


# ─── Helpers + CLI ──────────────────────────────────────────────────────

def _fatal(msg: str) -> None:
    print(f"build-enterprise-bundle: {msg}", file=sys.stderr)
    sys.exit(1)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Build a per-customer enterprise delivery tarball.",
    )
    # Required: license, sdk, install.sh, pubkey.
    p.add_argument("--license", type=Path, required=True,
                   help="Path to customer's license.json")
    p.add_argument("--license-sig", type=Path, required=True,
                   help="Detached GPG signature of license.json")
    p.add_argument("--sdk-tarball", type=Path, required=True,
                   help="Path to the SDK source tarball")
    p.add_argument("--sdk-sig", type=Path, required=True,
                   help="Detached GPG signature of the SDK tarball")
    p.add_argument("--install-sh", type=Path, required=True,
                   help="Path to the install.sh that will run on the customer's host")
    p.add_argument("--install-sh-sig", type=Path, required=True,
                   help="Detached GPG signature of install.sh")
    p.add_argument("--pubkey", type=Path, required=True,
                   help="Public key file (pubkey.asc) for customer verification")
    # Optional — presence depends on license.products.
    p.add_argument("--builder-tarball", type=Path, default=None,
                   help="Path to athanor-builder tarball (required iff license grants 'solve')")
    p.add_argument("--builder-sig", type=Path, default=None,
                   help="Detached GPG signature of builder tarball")
    p.add_argument("--scoring-containers-dir", type=Path, default=None,
                   help="Directory containing <env>.tar scoring containers")
    p.add_argument("--output", type=Path, required=True,
                   help="Where to write the bundle tarball")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    manifest = build_bundle(
        license_path=args.license,
        license_sig=args.license_sig,
        sdk_tarball=args.sdk_tarball,
        sdk_sig=args.sdk_sig,
        install_sh=args.install_sh,
        install_sh_sig=args.install_sh_sig,
        pubkey=args.pubkey,
        builder_tarball=args.builder_tarball,
        builder_sig=args.builder_sig,
        scoring_containers_dir=args.scoring_containers_dir,
        output=args.output,
    )

    print(f"bundle written → {args.output}")
    print(f"  org:       {manifest['license']['org']}")
    print(f"  products:  {manifest['license']['products']}")
    print(f"  envs:      {manifest['license']['envs']}")
    print(f"  contents:  {len(manifest['contents'])} files")
    print(f"  excluded:  {len(manifest['excluded'])} entries (see manifest.json)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
