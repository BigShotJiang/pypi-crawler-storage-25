#!/usr/bin/env python3
"""ATH-575 — CI gate: every live ``(run_subtype, event_type)`` pair
observed in Supabase must have a :mod:`kairos.trace_schema` REGISTRY entry.

Forward-looking gate: it NEVER drops prod events. ATH-574's emit-time
validation handles prod lenient-warn behavior (unknown pairs pass through
with a one-shot warn). This script just fails CI so a PR that introduces
a new ``event_type`` without also adding a registry entry can't merge.

Exit codes:

* ``0`` — every observed pair is covered, or Supabase creds absent (skip).
* ``1`` — at least one uncovered pair; report + diff printed.
* ``2`` — transport / query failure (treated as hard error; CI should
  investigate, not silently pass).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Iterable

# REGISTRY + wildcard key convention. Import by string path to avoid
# pulling pydantic in at CI-job top-level (the trace_schema module imports
# fine when the wheel is installed).
from kairos.trace_schema import REGISTRY


_DEFAULT_LOOKBACK_DAYS = 7
_DEFAULT_INVERSE_LOOKBACK_DAYS = 30


def _fetch_live_pairs(
    supabase_url: str,
    service_role_key: str,
    lookback_days: int = _DEFAULT_LOOKBACK_DAYS,
) -> list[tuple[str, str]]:
    """Fetch distinct ``(run_subtype, event_type)`` pairs observed in
    ``sdk_agent_events`` over the last ``lookback_days`` days.

    Uses PostgREST's ``select=run_subtype,event_type&distinct`` on the
    ``sdk_agent_events`` table. The ``created_at`` filter is server-side so
    the distinct-scan doesn't pull the full history.

    Raises :class:`RuntimeError` on transport failure — the caller converts
    that to exit code 2.
    """
    cutoff = f"now() - interval '{lookback_days} days'"
    # PostgREST accepts literal interval expressions via query args that
    # start with a column. We instead use the CREATED_AT filter in ISO
    # form computed client-side for portability.
    import datetime

    cutoff_iso = (
        datetime.datetime.now(datetime.timezone.utc)
        - datetime.timedelta(days=lookback_days)
    ).isoformat()
    params = urllib.parse.urlencode(
        {
            "select": "run_subtype,event_type",
            "created_at": f"gte.{cutoff_iso}",
        }
    )
    url = f"{supabase_url}/rest/v1/sdk_agent_events?{params}"
    req = urllib.request.Request(
        url,
        headers={
            "apikey": service_role_key,
            "Authorization": f"Bearer {service_role_key}",
            # ATH-575: 1000-row default + PostgREST pagination — we ask for
            # the full range via ``Prefer: count=exact`` and page if needed.
            # For distinct pairs (typically <50) one page suffices.
            "Prefer": "count=exact",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise RuntimeError(
            f"Supabase HTTP {exc.code}: {exc.read().decode('utf-8', 'replace')[:200]}"
        ) from exc
    except Exception as exc:
        raise RuntimeError(f"Supabase transport error: {exc}") from exc
    rows = json.loads(raw)
    # Deduplicate client-side since PostgREST distinct-via-header is spotty
    # across versions. 1000-row cap is fine — we're expecting <50 pairs.
    seen: set[tuple[str, str]] = set()
    for row in rows:
        pair = (row.get("run_subtype") or "", row.get("event_type") or "")
        seen.add(pair)
    return sorted(seen)


def _covered_by_registry(run_subtype: str, event_type: str) -> bool:
    """True when the registry has either an exact or wildcard entry.

    Matches :func:`kairos.trace_schema.validate_payload` lookup semantics so
    this gate doesn't fail for pairs the sink would have happily validated.
    """
    return (run_subtype, event_type) in REGISTRY or ("*", event_type) in REGISTRY


def _check_coverage(
    pairs: Iterable[tuple[str, str]],
) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
    """Split pairs into (covered, uncovered)."""
    covered: list[tuple[str, str]] = []
    uncovered: list[tuple[str, str]] = []
    for pair in pairs:
        (covered if _covered_by_registry(*pair) else uncovered).append(pair)
    return covered, uncovered


def _registry_entries_without_traffic(
    observed_pairs: Iterable[tuple[str, str]],
) -> list[tuple[str, str]]:
    """Registry entries that showed ZERO traffic in the observation window.

    Informational only — helps identify dead registry entries. Not a hard
    failure.
    """
    observed = set(observed_pairs)
    dead: list[tuple[str, str]] = []
    for key in REGISTRY:
        if key == ("*", key[1]):
            # Wildcard entry — only dead if no pair matches its event_type.
            if not any(p[1] == key[1] for p in observed):
                dead.append(key)
        elif key not in observed:
            dead.append(key)
    return sorted(dead)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--lookback-days",
        type=int,
        default=_DEFAULT_LOOKBACK_DAYS,
        help="Observe pairs over last N days (default: 7).",
    )
    parser.add_argument(
        "--skip-inverse",
        action="store_true",
        help="Suppress the informational dead-registry-entry warning.",
    )
    args = parser.parse_args(argv)

    supabase_url = os.environ.get("NEXT_PUBLIC_SUPABASE_URL") or os.environ.get(
        "SUPABASE_URL", ""
    )
    service_role_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    if not supabase_url or not service_role_key:
        print(
            "ATH-575: Supabase creds not configured — skipping coverage gate. "
            "Set SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY (or NEXT_PUBLIC_SUPABASE_URL) "
            "to enable.",
            file=sys.stderr,
        )
        return 0

    try:
        pairs = _fetch_live_pairs(
            supabase_url, service_role_key, lookback_days=args.lookback_days
        )
    except RuntimeError as exc:
        print(f"ATH-575: Supabase query failed — {exc}", file=sys.stderr)
        return 2

    if not pairs:
        print(
            f"ATH-575: zero events in last {args.lookback_days} days — "
            "registry coverage trivially satisfied.",
        )
        return 0

    covered, uncovered = _check_coverage(pairs)

    print(
        f"ATH-575 coverage report (last {args.lookback_days} days):\n"
        f"  observed pairs = {len(pairs)}\n"
        f"  registered     = {len(covered)}\n"
        f"  uncovered      = {len(uncovered)}"
    )

    if uncovered:
        print("\nUncovered (run_subtype, event_type) pairs:", file=sys.stderr)
        for sub, evt in uncovered:
            print(f"  • ({sub!r}, {evt!r})", file=sys.stderr)
        print(
            "\nAction: add a Pydantic model for each uncovered pair in "
            "src/kairos/trace_schema.py REGISTRY. See neighboring entries "
            "(_LLMCallSuccess, _GeneratorSynthesisRound) for shape.",
            file=sys.stderr,
        )
        return 1

    if not args.skip_inverse:
        # Informational: registry entries with zero production traffic.
        dead = _registry_entries_without_traffic(pairs)
        if dead:
            print(
                f"\nATH-575 inverse check (informational, does NOT fail CI): "
                f"{len(dead)} registry entries with zero traffic over "
                f"{args.lookback_days} days:",
            )
            for sub, evt in dead:
                print(f"  • ({sub!r}, {evt!r}) — consider removing if unused")

    return 0


if __name__ == "__main__":
    sys.exit(main())
