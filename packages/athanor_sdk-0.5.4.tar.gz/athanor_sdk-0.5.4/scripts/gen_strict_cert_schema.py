#!/usr/bin/env python3
"""Generate a strict (additionalProperties=false) JSON schema variant of
``customer_block_certificate_complete`` for the cross-arm contract test.

Why a separate strict schema?
-----------------------------

The customer-facing schema at
``schemas/customer_block_certificate_complete.schema.json`` keeps
``additionalProperties=true`` (Pydantic's ``extra='allow'``) so customer
emit sites can ship forward-compatible payloads with extra fields without
failing validation. That tradeoff hides typos like ``diagnostic_clas``.

The strict schema flips every ``additionalProperties=true`` to ``false``
so the platform-side ajv-validator catches typo drift on either arm
when the canonical fixture is checked against it. Per platform PR #498
LGTM 2026-05-06: "stricter drift detection... separate strict-export
schema; keep the current one as customer-facing".

Usage::

    python3 scripts/gen_strict_cert_schema.py

Reads the strict shape from ``kairos.trace_schema.REGISTRY``. Writes to
``schemas/customer_block_certificate_complete.strict.schema.json``.

CI check (``trace-schema-coverage`` job) regenerates and diffs to detect
drift between the model and committed schema artifact.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

from kairos.trace_schema import REGISTRY  # noqa: E402


def _walk_strict(node: object) -> object:
    """Walk a JSON-schema tree, flipping additionalProperties to False
    on every object subschema. Idempotent."""
    if isinstance(node, dict):
        out = {k: _walk_strict(v) for k, v in node.items()}
        if out.get("type") == "object" or "properties" in out:
            out["additionalProperties"] = False
        return out
    if isinstance(node, list):
        return [_walk_strict(x) for x in node]
    return node


def main() -> int:
    model = REGISTRY[("*", "customer_block_certificate_complete")]
    loose = model.model_json_schema()
    strict = _walk_strict(loose)
    strict["title"] = strict.get("title", "") + " (strict)"
    strict["description"] = (
        "STRICT variant of customer_block_certificate_complete schema. "
        "additionalProperties=false on every object subschema. Used by the "
        "cross-arm contract test to catch typo drift on either arm. The "
        "customer-facing schema at "
        "customer_block_certificate_complete.schema.json keeps "
        "additionalProperties=true for forward-compat. See "
        "scripts/gen_strict_cert_schema.py."
    )

    out_path = REPO_ROOT / "schemas" / "customer_block_certificate_complete.strict.schema.json"
    out_path.write_text(json.dumps(strict, indent=2) + "\n")
    print(f"wrote {out_path.relative_to(REPO_ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
