#!/usr/bin/env python3
"""ATH-384 + ATH-450 — SDK IP-leak regression gate.

Greps `src/kairos/` (production code only) for patterns that would
indicate proprietary content has leaked into the public-facing SDK
surface. Complements two narrower gates already in CI:

  * `tls-verification` (ATH-369 #1)     — blocks TLS-verify-disable footguns
  * `canonical-spec-drift`              — pins 4 byte-mirrored files
                                          to athanor-builder's canonical

## Two modes

* **Default** — regex + prompt-marker scan of src/kairos/. Runs on
  every PR. ATH-384.
* **--publish-gate** — additionally asserts no deny-listed file paths
  exist anywhere under src/kairos/. Intended for the future
  PyPI-publish workflow (ATH-345 is currently disabling publish; this
  gate is step 1 of re-enabling it safely). Files listed in
  DENY_LIST_PATH_SUFFIXES are SV research code that must never ship to
  the public `athanor-kairos` bundle. ATH-450.

## Override

In publish-gate mode, `ATHANOR_SDK_IP_OVERRIDE=1` + a GPG-signed HEAD
commit together let a deliberate exception through with a warning +
audit-log append. Both conditions must hold — the env var alone is
not enough. Logged at `scripts/check_sdk_ip_override_audit.log`.

This script is the broad catch-all. Patterns checked:

  1. **Builder-namespace imports** — `from solve.shared.*`,
     `from solve.<vertical>.*`, `import solve.shared`. Builder code must
     never be imported at SDK runtime; byte-mirrors sit at
     `src/kairos/spec_*.py`, not behind an `import solve.shared`.

  2. **Env-reference paths** — `environments/<env>/root_data/eval/`,
     `solve/<vertical>/catalog/`. Internal artifact paths with no
     place in customer-facing code.

  3. **Hardcoded scoring weights as plain literals** — the ATH-382
     scoring tuple `(1.0, 0.35, 0.25, 0.0)` showing up as a bare
     Python literal in SDK source means Cython compilation (ATH-382)
     either hasn't happened or regressed.

  4. **Internal-only identifiers** — `SPECIALE_`, `HERO_v2`, `KAIROS`,
     `speciale_adapter`, per CLAUDE.md's "no athanor-internal terms in
     customer-facing files" rule. Includes prompt-template markers
     from the redactor's FORBIDDEN list (re-applied to source as
     belt-and-braces).

Exit codes:
  0 — clean; no leaks
  1 — one or more leaks found

Usage:
  python3 scripts/check_sdk_ip.py [--verbose]

Updating the pattern list: when a new proprietary identifier lands in
athanor-builder that we want to guard against, add it to the relevant
PATTERNS list below and run locally. The test at
`tests/test_check_sdk_ip.py` round-trips a fixture leak through the
script to prove the new pattern actually trips CI.
"""
from __future__ import annotations

import argparse
import io
import os
import re
import subprocess
import sys
import tokenize
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


REPO_ROOT = Path(__file__).resolve().parent.parent
SRC_DIR = REPO_ROOT / "src" / "kairos"
BASELINE_FILE = REPO_ROOT / "scripts" / "check_sdk_ip_baseline.txt"
OVERRIDE_AUDIT_LOG = REPO_ROOT / "scripts" / "check_sdk_ip_override_audit.log"


# ─── Deny-list (ATH-450, publish-gate mode only) ──────────────────────────

# Files that must NEVER ship in the public `athanor-kairos` PyPI bundle.
# Matched by path suffix against every file under src/kairos/ — so the
# SV research code can't be hidden behind a rename or subdirectory move.
#
# When adding: use the two-segment suffix form (`sv/foo.py`) rather than
# the bare basename, because names like `invariants.py` / `multi.py` are
# generic enough to collide with benign future SDK modules.
# DENY_LIST — enriched schema (ATH-451 + ATH-452 refactor, qa review
# 2026-04-22): each entry carries either `paper_gated_by` (paper ID that
# lifts the block on arXiv-posting) or `permanent=True` (never lifts —
# ATH-453 permanent-enterprise-gate decision OR no paper planned).
#
# The plain-tuple form DENY_LIST_PATH_SUFFIXES is derived below for any
# legacy consumer + find_deny_list_hits(), but new checks should read
# DENY_LIST directly so they can see the gating semantics.
DENY_LIST: tuple[dict[str, object], ...] = (
    # HB-stack — ATH-453 decision pending. Default = permanent. When
    # decision lands, flip `permanent` → False and add to PAPER_FILE_MAP.
    {"suffix": "sv/hb_extract.py",  "paper_gated_by": None,    "permanent": True,
     "desc": "HB-graph extractor (pending ATH-453)"},
    {"suffix": "sv/hb_graph.py",    "paper_gated_by": None,    "permanent": True,
     "desc": "HB-graph core (pending ATH-453)"},
    {"suffix": "sv/hb_sva_emit.py", "paper_gated_by": None,    "permanent": True,
     "desc": "HB-graph SVA emitter (pending ATH-453)"},
    # Paper-priority gated — block lifts on arXiv-posting of the parent paper.
    {"suffix": "sv/invariants.py",  "paper_gated_by": "ATH-411", "permanent": False,
     "desc": "Reverse-mutation-kill invariant discovery"},
    {"suffix": "sv/swarm.py",       "paper_gated_by": "ATH-412", "permanent": False,
     "desc": "State-swarm EBMC + multi-abstraction sandwich"},
    {"suffix": "sv/multi.py",       "paper_gated_by": "ATH-412", "permanent": False,
     "desc": "State-swarm EBMC + multi-abstraction sandwich"},
)

DENY_LIST_PATH_SUFFIXES: tuple[str, ...] = tuple(
    entry["suffix"] for entry in DENY_LIST  # type: ignore[misc]
)


# ─── Paper-priority gates (ATH-451 + ATH-452, publish-gate mode only) ────

# Paper ID → list of file-suffixes that unblock when the paper hits arXiv.
# Derived from DENY_LIST entries where `paper_gated_by` is set.
#
# Mechanism: set KAIROS_PAPER_<ATH-ID>_ARXIV_ID (or ATHANOR_*) to the
# published arXiv ID (e.g. "2412.12345" or "2412.12345v2"). Publish-gate
# then exempts every file listed under that paper + records the ID in
# the audit log. Publishing the implementation before arXiv voids our
# novelty claim (reviewers see "code was public two months before
# submission"); arXiv-posting establishes priority publicly.
#
# arXiv ID format: per https://info.arxiv.org/help/arxiv_identifier.html
# the modern form is YYMM.NNNN (4 digits, pre-2015) or YYMM.NNNNN
# (5 digits, post-2015), optionally suffixed with "v1", "v2", etc.
# Both are accepted. We regex-validate but do NOT phone home to arxiv.org
# — CI must work offline, and someone with a signed commit + regex-valid
# ID is trusted (audit log catches post-hoc fraud).
PAPER_FILE_MAP: dict[str, tuple[str, ...]] = {}
for entry in DENY_LIST:  # build from DENY_LIST so shapes never drift
    if entry.get("paper_gated_by"):  # type: ignore[arg-type]
        paper_id = entry["paper_gated_by"]  # type: ignore[assignment]
        PAPER_FILE_MAP.setdefault(paper_id, ())  # type: ignore[arg-type]
        PAPER_FILE_MAP[paper_id] = PAPER_FILE_MAP[paper_id] + (entry["suffix"],)  # type: ignore[operator]

ARXIV_ID_PATTERN = re.compile(r"^\d{4}\.\d{4,5}(v\d+)?$")


def _paper_env_var_names(paper_id: str) -> tuple[str, str]:
    """Return (preferred, legacy_fallback) env var names for a paper ID.

    Dual-accept per ATH-407: KAIROS_* preferred, ATHANOR_* accepted with
    DeprecationWarning. Paper IDs are normalized (ATH-411 → ATH411) so
    the env var name is greppable without dashes.
    """
    slug = paper_id.replace("-", "")
    return (
        f"KAIROS_PAPER_{slug}_ARXIV_ID",
        f"ATHANOR_PAPER_{slug}_ARXIV_ID",
    )


def _read_paper_arxiv_id(paper_id: str) -> tuple[str, str] | None:
    """Return (arxiv_id, env_var_used) if a valid arXiv ID is set for
    this paper via either the preferred or legacy env var; None otherwise.

    Emits a DeprecationWarning to stderr if only the legacy ATHANOR_*
    form is set — customer should migrate to KAIROS_* per ATH-407.
    """
    preferred, legacy = _paper_env_var_names(paper_id)
    for env_var in (preferred, legacy):
        val = os.environ.get(env_var, "").strip()
        if not val:
            continue
        if not ARXIV_ID_PATTERN.match(val):
            # Set but malformed — treat as not set (caller will fail-gate).
            # This is stricter than silently accepting; a malformed ID
            # means someone tried to override and failed, not that the
            # paper is unreleased.
            continue
        if env_var == legacy:
            print(
                f"[check_sdk_ip] DeprecationWarning: {legacy} is legacy; "
                f"prefer {preferred} (ATH-407 dual-accept).",
                file=sys.stderr,
            )
        return (val, env_var)
    return None


# ─── Pattern lists ───────────────────────────────────────────────────────

# Patterns are applied to TOKENIZE-reassembled source where each token
# is separated by a single space. That means `solve.shared` appears as
# `solve . shared` (the `.` is a separate OP token). Patterns below
# tolerate whitespace around dots + slashes to match both shapes.

# 1. Builder-namespace imports. Any of these in SDK source means the
#    ATH-337 byte-mirror discipline has broken — we're runtime-importing
#    from the private repo.
BUILDER_IMPORT_PATTERNS: list[tuple[str, str]] = [
    (r"\bfrom\s+solve\s*\.\s*shared\b", "import from solve.shared (builder namespace)"),
    (r"\bfrom\s+solve\s*\.\s*(bbr3|action_cred|sysverilog|neuron|bio|lean|custom)\b",
     "import from solve.<vertical> (builder namespace)"),
    (r"\bimport\s+solve\s*\.", "direct import of solve.* (builder namespace)"),
    (r"\bimport\s+athanor_builder\b", "import athanor_builder (wrong package name)"),
]

# 2. Internal artifact paths. These paths only make sense inside
#    athanor-builder or in CI. Appearing in SDK source is a leak.
#    NOTE: path patterns usually appear only inside string literals
#    (tokenize strips those), so these mostly catch paths built at
#    token-level via division operators or f-string fragments. Rare
#    but possible.
INTERNAL_PATH_PATTERNS: list[tuple[str, str]] = [
    (r"environments\s*/\s*[a-z\-]+\s*/\s*root_data\s*/\s*eval\s*/", "internal env-ref path"),
    (r"solve\s*/\s*[a-z_]+\s*/\s*catalog\s*/", "internal catalog path"),
    (r"/\s*opt\s*/\s*athanor\s*/\s*builder\s*/\s*solve\s*/", "internal builder install path (use ATHANOR_BUILDER_ROOT)"),
]

# 3. Scoring-weight literals. The canonical scoring tuple for
#    three-layer scoring is (1.0, 0.35, 0.25, 0.0). If it appears as a
#    bare Python literal in SDK source, Cython hasn't been applied.
#    We match the sequence with small formatting tolerance. Tests +
#    this script itself are allowed to mention the numbers in docstrings;
#    the check is "no Python tuple literal containing this exact sequence".
SCORING_LITERAL_PATTERNS: list[tuple[str, str]] = [
    (r"\(\s*1\.0\s*,\s*0\.35\s*,\s*0\.25\s*,\s*0\.0\s*\)",
     "hardcoded scoring-weight tuple — should live in compiled .so per ATH-382"),
]

# 4. Internal-only identifiers. Per CLAUDE.md: "No athanor-internal
#    terms in customer-facing files." Includes the prompt markers the
#    redactor (builder #77) already guards; we apply them in SDK source
#    as a belt-and-braces invariant that nobody copy-pasted a prompt
#    into a comment.
INTERNAL_IDENT_PATTERNS: list[tuple[str, str]] = [
    (r"\bSPECIALE_\w+\b", "internal identifier: SPECIALE_*"),
    (r"\bHERO[-_]v2\b", "internal identifier: HERO-v2"),
    (r"\bKAIROS\b", "internal identifier: KAIROS"),
    (r"\bspeciale_adapter\b", "internal module: speciale_adapter"),
]

# Prompt-template markers (mirrors bundle.py FORBIDDEN_MARKERS). Kept
# here so this script is a one-stop SDK-source audit; keep in sync with
# bundle.FORBIDDEN_MARKERS when updating either.
PROMPT_MARKER_PATTERNS: list[tuple[str, str]] = [
    ("You are a coding agent that solves tasks", "prompt template leaked"),
    ("You MUST use the provided tools",          "prompt template leaked"),
    ("Do NOT just describe what you would do",   "prompt template leaked"),
    ("NKI (Neuron Kernel Interface) kernel",     "prompt template leaked"),
    ("Workflow: read the task files",            "prompt template leaked"),
    ("You are a Lean 4 theorem prover",          "prompt template leaked"),
    ("Before accepting a hypothesis",            "prompt template leaked"),
    ("unsatisfiable and closes every conclusion","prompt template leaked"),
    ("SystemVerilog Assertions (SVA)",           "prompt template leaked"),
    ("assert property (@(posedge clk)",          "prompt template leaked"),
    ("never `assume property`",                  "prompt template leaked"),
    ("You are the Phase -1 planner",             "prompt template leaked"),
    ("Banned constructs:",                       "prompt template leaked"),
    ("is the fifth element that binds",          "prompt template leaked"),
]


ALL_REGEX_PATTERNS = (
    BUILDER_IMPORT_PATTERNS
    + INTERNAL_PATH_PATTERNS
    + SCORING_LITERAL_PATTERNS
    + INTERNAL_IDENT_PATTERNS
)


# ─── Scan ────────────────────────────────────────────────────────────────


@dataclass
class Leak:
    file: Path
    line_no: int
    pattern_desc: str
    matched_text: str

    def format(self, root: Path) -> str:
        rel = self.file.relative_to(root)
        return f"  {rel}:{self.line_no}: {self.pattern_desc}\n    → {self.matched_text.strip()}"


def _iter_source_files(src_dir: Path) -> Iterable[Path]:
    """Yield every .py file under src/ except __pycache__."""
    for path in src_dir.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        yield path


def _executable_source_by_line(path: Path) -> dict[int, str]:
    """Return a {line_no: reassembled-code-on-that-line} map with
    comments + string literals stripped via `tokenize`.

    Multi-line strings (docstrings) are handled correctly — their
    content is dropped, not leaked into the output. Docstring mentions
    of banned identifiers ("from solve.shared") therefore don't trip
    the regex patterns. Same approach as `scripts/check_tls_verify.py`.
    """
    try:
        raw = path.read_bytes()
    except OSError:
        return {}

    by_line: dict[int, list[str]] = {}
    try:
        for tok in tokenize.tokenize(io.BytesIO(raw).readline):
            if tok.type in (
                tokenize.COMMENT, tokenize.STRING,
                tokenize.NL, tokenize.NEWLINE,
                tokenize.INDENT, tokenize.DEDENT,
                tokenize.ENCODING, tokenize.ENDMARKER,
            ):
                continue
            by_line.setdefault(tok.start[0], []).append(tok.string)
    except tokenize.TokenizeError:
        # Malformed file — skip silently. The py_compile lint job
        # catches syntax errors on its own.
        return {}

    return {ln: " ".join(toks) for ln, toks in by_line.items()}


def _scan_file(path: Path) -> list[Leak]:
    """Scan one source file for all pattern classes. Returns a list of
    Leak objects (empty list = clean file)."""
    leaks: list[Leak] = []
    try:
        content = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return leaks

    lines = content.splitlines()

    # Regex patterns — only scan executable code via tokenize, so
    # docstring / comment / string-literal mentions of the banned
    # patterns don't trip the check. Correct-by-construction relative
    # to the old line-based stripper.
    exec_source = _executable_source_by_line(path)
    for lineno, code in exec_source.items():
        for pattern, desc in ALL_REGEX_PATTERNS:
            m = re.search(pattern, code)
            if m:
                raw = lines[lineno - 1] if lineno - 1 < len(lines) else code
                leaks.append(Leak(path, lineno, desc, raw))

    # Prompt-marker patterns — STILL scan raw content. Unlike the
    # import / path / identifier patterns above, prompt phrases
    # legitimately exist ONLY as string content in Python. If we
    # tokenize-stripped them out we'd exempt the real leaks in
    # eval_harness.py's prompt assignments (ATH-383). The baseline
    # file carries the per-file exemptions where this scan produces
    # unavoidable false positives — e.g. bundle.py's FORBIDDEN_MARKERS
    # enforcement list (legitimate, permanent exemption).
    for marker, desc in PROMPT_MARKER_PATTERNS:
        if marker in content:
            for lineno, raw in enumerate(lines, 1):
                if marker in raw:
                    leaks.append(Leak(path, lineno, desc, raw))
                    break

    return leaks


def scan() -> list[Leak]:
    """Scan the whole SDK src/ directory. Returns all leaks found."""
    if not SRC_DIR.is_dir():
        sys.stderr.write(f"FATAL: src dir not found: {SRC_DIR}\n")
        sys.exit(2)
    all_leaks: list[Leak] = []
    for path in _iter_source_files(SRC_DIR):
        all_leaks.extend(_scan_file(path))
    return all_leaks


# ─── Deny-list scan (ATH-450) ───────────────────────────────────────────


@dataclass
class DenyHit:
    file: Path
    suffix: str

    def format(self, root: Path) -> str:
        rel = self.file.relative_to(root)
        return f"  {rel}  ← deny-listed suffix: {self.suffix}"


def find_deny_list_hits() -> list[DenyHit]:
    """Walk src/kairos/ and return every file whose path ends with one
    of the DENY_LIST_PATH_SUFFIXES. Case-sensitive POSIX suffix match.

    Matches on the repo-relative POSIX path so a subdirectory rename
    (e.g. `sv/` → `hardware/sv/`) still trips.
    """
    if not SRC_DIR.is_dir():
        return []
    hits: list[DenyHit] = []
    for path in _iter_source_files(SRC_DIR):
        rel = path.relative_to(REPO_ROOT).as_posix()
        for suffix in DENY_LIST_PATH_SUFFIXES:
            if rel.endswith("/" + suffix) or rel.endswith(suffix):
                hits.append(DenyHit(path, suffix))
                break
    return hits


def _is_head_gpg_signed(cwd: Path) -> bool:
    """Return True iff `git verify-commit HEAD` succeeds at `cwd`.

    Test escape hatch: if `ATHANOR_SDK_IP_OVERRIDE_STUB_VERIFIED=1` is
    set, return True without running git. Used by the test suite,
    which cannot produce a GPG-signed commit in a tmp_path repo.
    The audit log records `stub=true` when this path is taken.
    """
    if os.environ.get("ATHANOR_SDK_IP_OVERRIDE_STUB_VERIFIED") == "1":
        return True
    try:
        proc = subprocess.run(
            ["git", "verify-commit", "HEAD"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return proc.returncode == 0


def _head_sha(cwd: Path) -> str:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(cwd), capture_output=True, text=True, timeout=5,
        )
        if proc.returncode == 0:
            return proc.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return "<unknown>"


def _write_override_audit(hits: list[DenyHit], stubbed: bool) -> None:
    """Append one line to the override audit log each time --publish-gate
    lets a deny-list hit through via the override path. Best-effort:
    if the log can't be written (read-only FS etc.) we still let the
    build proceed — the warning on stdout is the primary signal.
    """
    try:
        OVERRIDE_AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        sha = _head_sha(REPO_ROOT)
        files = ",".join(h.suffix for h in hits)
        line = (
            f"{ts}\tsha={sha}\tstub={'true' if stubbed else 'false'}"
            f"\tfiles={files}\n"
        )
        with open(OVERRIDE_AUDIT_LOG, "a") as f:
            f.write(line)
    except OSError:
        pass


def _write_paper_override_audit(
    exemptions: list[tuple[DenyHit, str, str]],
) -> None:
    """Append one line per paper-priority exemption to the audit log.
    Each line records the paper ID + arXiv ID that lifted the block —
    post-hoc the commit log + this file together explain every publish.
    """
    if not exemptions:
        return
    try:
        OVERRIDE_AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        sha = _head_sha(REPO_ROOT)
        with open(OVERRIDE_AUDIT_LOG, "a") as f:
            for hit, paper_id, arxiv_id in exemptions:
                f.write(
                    f"{ts}\tsha={sha}\tpaper_override=true"
                    f"\tpaper={paper_id}\tarxiv_id={arxiv_id}"
                    f"\tfile={hit.suffix}\n"
                )
    except OSError:
        pass


def load_baseline() -> set[tuple[str, str]]:
    """Return the set of (repo-relative-path, pattern_desc) pairs
    that are exempted from the check. Missing baseline file = empty set."""
    if not BASELINE_FILE.is_file():
        return set()
    pairs: set[tuple[str, str]] = set()
    for line in BASELINE_FILE.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        path, desc = line.split(":", 1)
        pairs.add((path.strip(), desc.strip()))
    return pairs


# ─── Main ────────────────────────────────────────────────────────────────


def _leak_to_json(leak: Leak) -> dict:
    return {
        "file":         str(leak.file.relative_to(REPO_ROOT)),
        "line":         leak.line_no,
        "pattern":      leak.pattern_desc,
        "matched_text": leak.matched_text.rstrip("\n"),
    }


def _paper_exemption_for_hit(hit: DenyHit) -> tuple[str, str, str] | None:
    """Return (paper_id, arxiv_id, env_var) if this hit is exempted by a
    paper-priority arXiv release (ATH-451/452). None if not exempted —
    either the file isn't gated on a paper at all (permanent deny) or
    the paper's arXiv ID hasn't been set.
    """
    paper_id: str | None = None
    for entry in DENY_LIST:
        if entry["suffix"] != hit.suffix:
            continue
        paper_id = entry.get("paper_gated_by")  # type: ignore[assignment]
        break
    if not paper_id:
        return None
    resolved = _read_paper_arxiv_id(paper_id)
    if resolved is None:
        return None
    arxiv_id, env_var = resolved
    return (paper_id, arxiv_id, env_var)


def _evaluate_publish_gate() -> tuple[list[DenyHit], str, bool, list[tuple[DenyHit, str, str]]]:
    """Resolve deny-list hits + override state.

    Returns (hits, state, stubbed, paper_exemptions).

    state ∈ {"clean", "fail", "override", "paper_override"}:
      * "clean"           — no deny-list hits; publish path is safe.
      * "paper_override"  — every hit is exempted by a valid paper-
                            priority arXiv release (ATH-451/452). No
                            GPG signature required — the arXiv ID is
                            the priority anchor. Audit-logged.
      * "override"        — hits remain after paper-priority filtering,
                            BUT manual override is valid (env var +
                            signed HEAD). Warning + audit-log.
      * "fail"            — hits remain after paper-priority filtering
                            AND manual override is invalid/absent.

    paper_exemptions lists the (hit, paper_id, arxiv_id) triples that
    lifted via paper-priority path — caller uses this for audit log
    entries + user-visible "these released via arXiv" messaging.
    """
    hits = find_deny_list_hits()
    if not hits:
        return hits, "clean", False, []

    # Split hits: paper-priority-exempt vs still-blocking.
    paper_exemptions: list[tuple[DenyHit, str, str]] = []
    still_blocking: list[DenyHit] = []
    for hit in hits:
        exemption = _paper_exemption_for_hit(hit)
        if exemption is None:
            still_blocking.append(hit)
        else:
            paper_id, arxiv_id, _env_var = exemption
            paper_exemptions.append((hit, paper_id, arxiv_id))

    if not still_blocking:
        return hits, "paper_override", False, paper_exemptions

    # Still have blocking hits — consult the legacy manual-override path.
    override_env = os.environ.get("ATHANOR_SDK_IP_OVERRIDE") == "1"
    if not override_env:
        return hits, "fail", False, paper_exemptions

    stubbed = os.environ.get("ATHANOR_SDK_IP_OVERRIDE_STUB_VERIFIED") == "1"
    if _is_head_gpg_signed(REPO_ROOT):
        return hits, "override", stubbed, paper_exemptions
    return hits, "fail", False, paper_exemptions


# ─── Anti-cheat detector gate (ATH-499 Tier 1, 2026-04-23) ────────────────

# Publish-gate additionally runs every source file under src/kairos/
# through the Tier-1 AST detectors (stub_body / literal_verdict /
# reference_module_import / witness_file_check / macro_sorry). The
# detector import is deferred so PR-CI runs of check_sdk_ip.py without
# --publish-gate stay decoupled from the runtime detector package.
#
# Files that deliberately embed forbidden patterns for negative tests
# are exempt via prefix match against _DETECTOR_EXEMPT_PATH_PREFIXES.


_DETECTOR_EXEMPT_PATH_PREFIXES: tuple[str, ...] = (
    # The detector modules themselves contain the regexes that match —
    # scanning them would self-trip.
    "src/kairos/verify/plugin/detectors/",
    # ATH-657 / 658 vendored Apache-2.0 lean-machines source. Upstream
    # uses `axiom` declarations as the canonical Event-B framework
    # primitive; we ship the source unmodified per Apache-2.0 §4(c)
    # and can't audit upstream axioms. Vendoring policy: NOTICE.md +
    # LICENSE preserved at `src/kairos/_vendor/lean_machines{,_examples}/`.
    "src/kairos/_vendor/",
)

# SDK-core files that legitimately match a detector pattern but are
# NOT plugin code. These are first-party SDK surface; their inclusion
# here is a documented carve-out, not a silent exemption. Extending
# this list requires a comment explaining which detector matched + why
# the match is a false positive for this file.
_DETECTOR_EXEMPT_FILES: tuple[tuple[str, str, str], ...] = (
    # (path, fingerprint, rationale)
    (
        "src/kairos/trace.py",
        "literal_verdict",
        "NoopTraceSink.emit / emit_escalation are the canonical null "
        "sink (customer-privacy default). Returning None unconditionally "
        "is the contract, not effort-gaming.",
    ),
    (
        "src/kairos/scoring.py",
        "reference_module_import",
        "Public facade that re-exports kairos._scoring_impl (Cython-"
        "compiled). The _impl split is the IP-protection seam — the "
        "public module IS allowed to import its private sibling.",
    ),
    (
        "src/kairos/lint.py",
        "reference_module_import",
        "Same rationale as scoring.py — public facade over kairos._lint_impl.",
    ),
    (
        "src/kairos/license_scope.py",
        "reference_module_import",
        "ATH-686: license_scope is the SDK-core security gate, not a "
        "plugin. It imports kairos._keys (bundled GPG pubkey + expected "
        "fingerprint) to verify license signatures. The _keys module IS "
        "the public seam for the bundled key material — the import is "
        "load-bearing, not a leak.",
    ),
    (
        "src/kairos/audit_log.py",
        "stub_detection",
        "ATH-690: NoopAuditSink.emit is a `pass` body BY CONTRACT — "
        "it is the canonical null sink for license-gate audit events. "
        "Same rationale as NoopTraceSink in trace.py: a customer or "
        "test that explicitly opts out of audit logging gets this "
        "sink, and dropping every event IS the contract, not "
        "effort-gaming. Detector cannot distinguish 'plugin stub' "
        "(bad) from 'documented null sink' (intentional).",
    ),
    (
        "src/kairos/simple_prove_template.py",
        "reference_module_import",
        "ATH-702: simple_prove imports kairos._pythia_lake (the auto-"
        "bootstrapped Pythia Lake project helper). _pythia_lake is the "
        "public seam for the on-disk Lake-project state, similar to "
        "kairos._keys for the bundled GPG material. The import is "
        "load-bearing for the customer-onboard 'pip install + 30-second "
        "proof' contract.",
    ),
)


@dataclass
class DetectorGateHit:
    """One anti-cheat-detector match surfaced at publish-gate."""

    file: Path
    fingerprint: str
    line: int
    reason: str

    def format(self, repo_root: Path) -> str:
        rel = self.file.relative_to(repo_root)
        return f"  {rel}:{self.line}  [{self.fingerprint}] {self.reason}"


def _evaluate_detector_gate() -> list[DetectorGateHit]:
    """Run every Tier-1 AST/regex detector against every source file
    under src/kairos/ + return the concatenated matches.

    Publish-gate-only. Import of kairos.verify.plugin.detectors is
    deferred into this function so (a) the script still runs when the
    package isn't installed in the CI venv, (b) PR-CI without
    --publish-gate doesn't pay the import cost.
    """
    try:
        from kairos.verify.plugin.detectors import run_all_detectors
    except ImportError as exc:
        # Detector package unavailable in this venv — fail-closed: we
        # treat a missing detector as "cannot certify the ship" rather
        # than silently waving through.
        raise SystemExit(
            f"publish-gate: kairos.verify.plugin.detectors is not "
            f"importable ({exc}). Install athanor-kairos in editable mode "
            f"(`pip install -e .`) before running --publish-gate."
        ) from None

    hits: list[DetectorGateHit] = []
    # Scan Python + Lean; extend as verticals add more file types.
    for src_dir in (SRC_DIR,):
        for path in src_dir.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix not in {".py", ".lean"}:
                continue
            if "__pycache__" in path.parts:
                continue
            rel_str = str(path.relative_to(REPO_ROOT))
            if any(
                rel_str.startswith(prefix)
                for prefix in _DETECTOR_EXEMPT_PATH_PREFIXES
            ):
                continue
            try:
                source = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for match in run_all_detectors(source, rel_str):
                if any(
                    rel_str == exempt_path
                    and match.fingerprint == exempt_fingerprint
                    for (exempt_path, exempt_fingerprint, _rationale)
                    in _DETECTOR_EXEMPT_FILES
                ):
                    continue
                hits.append(
                    DetectorGateHit(
                        file=path,
                        fingerprint=match.fingerprint,
                        line=match.line,
                        reason=match.reason,
                    )
                )
    return hits


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--verbose", action="store_true",
                        help="print every file scanned")
    parser.add_argument(
        "--format", choices=("text", "json"), default="text",
        help="output format. 'json' emits a single JSON object to stdout "
             "(for audit-pipeline consumption); 'text' is the default "
             "human-readable report. Exit codes are identical in both modes.",
    )
    parser.add_argument(
        "--publish-gate", action="store_true",
        help="ATH-450: additionally fail if any DENY_LIST_PATH_SUFFIXES file "
             "exists under src/kairos/. Intended for the PyPI-publish "
             "workflow; default PR CI does NOT set this flag.",
    )
    args = parser.parse_args()

    if args.verbose:
        for path in _iter_source_files(SRC_DIR):
            print(f"scan {path.relative_to(REPO_ROOT)}", file=sys.stderr)

    leaks = scan()
    baseline = load_baseline()

    # Partition leaks: exempted (in baseline) vs new (not in baseline).
    def key_of(leak: Leak) -> tuple[str, str]:
        return (str(leak.file.relative_to(REPO_ROOT)), leak.pattern_desc)

    new_leaks = [leak for leak in leaks if key_of(leak) not in baseline]
    exempted = [leak for leak in leaks if key_of(leak) in baseline]

    # Publish-gate deny-list — evaluated only when --publish-gate is set.
    deny_hits: list[DenyHit] = []
    deny_state = "clean"
    deny_stubbed = False
    paper_exemptions: list[tuple[DenyHit, str, str]] = []
    detector_hits: list[DetectorGateHit] = []
    if args.publish_gate:
        deny_hits, deny_state, deny_stubbed, paper_exemptions = _evaluate_publish_gate()
        if deny_state == "override":
            _write_override_audit(deny_hits, deny_stubbed)
        if deny_state in ("override", "paper_override"):
            # Always audit paper-priority exemptions, even when a full
            # manual override also fires — two paths, two records.
            _write_paper_override_audit(paper_exemptions)
        # ATH-499 Tier-1 anti-cheat detectors — fail-closed on any match.
        detector_hits = _evaluate_detector_gate()

    n_files = sum(1 for _ in _iter_source_files(SRC_DIR))

    fail = bool(new_leaks) or deny_state == "fail" or bool(detector_hits)

    if args.format == "json":
        import json as _json
        result = {
            "status":            "ok" if not fail else "fail",
            "files_scanned":     n_files,
            "new_leaks":         [_leak_to_json(l) for l in new_leaks],
            "baseline_exempted": [_leak_to_json(l) for l in exempted],
            "baseline_file":     str(BASELINE_FILE.relative_to(REPO_ROOT)),
            "publish_gate": {
                "enabled":     args.publish_gate,
                "state":       deny_state,
                "override_stubbed": deny_stubbed,
                "hits": [
                    {
                        "file":   str(h.file.relative_to(REPO_ROOT)),
                        "suffix": h.suffix,
                    }
                    for h in deny_hits
                ],
                "paper_exemptions": [
                    {
                        "file":     str(h.file.relative_to(REPO_ROOT)),
                        "suffix":   h.suffix,
                        "paper":    pid,
                        "arxiv_id": aid,
                    }
                    for (h, pid, aid) in paper_exemptions
                ],
                "detector_hits": [
                    {
                        "file":        str(h.file.relative_to(REPO_ROOT)),
                        "fingerprint": h.fingerprint,
                        "line":        h.line,
                        "reason":      h.reason,
                    }
                    for h in detector_hits
                ],
            },
        }
        print(_json.dumps(result, indent=2, sort_keys=True))
        return 0 if not fail else 1

    # Text format — IP-leak section first, deny-list second.
    if new_leaks:
        print(f"FAIL — {len(new_leaks)} new IP leak(s) found in SDK source:")
        for leak in new_leaks:
            print(leak.format(REPO_ROOT))
        print()
        print(
            "These are NOT in scripts/check_sdk_ip_baseline.txt. Either fix them, "
            "or add them to the baseline with a TODO/ticket reference explaining why."
        )
        if exempted:
            print(f"\n({len(exempted)} other leak(s) are baseline-exempted.)")
    else:
        msg = f"OK — scanned {n_files} file(s) under src/kairos/; no new IP leaks."
        if exempted:
            msg += f" ({len(exempted)} baseline-exempted leaks pending removal.)"
        print(msg)

    if args.publish_gate:
        exempt_suffixes = {h.suffix for (h, _p, _a) in paper_exemptions}
        if deny_state == "fail":
            print()
            blocking = [h for h in deny_hits if h.suffix not in exempt_suffixes]
            print(f"FAIL (publish-gate) — {len(blocking)} deny-listed file(s) "
                  f"present under src/kairos/:")
            for h in blocking:
                print(h.format(REPO_ROOT))
            print()
            print(
                "These files must NOT ship in the public `athanor-kairos` "
                "PyPI bundle. Three ways to clear:\n"
                "  1. Remove them from src/kairos/ before publishing.\n"
                "  2. (paper-priority) Set KAIROS_PAPER_<ATH-ID>_ARXIV_ID "
                "once the corresponding paper lands on arXiv — the file's "
                "block lifts automatically.\n"
                "  3. Set ATHANOR_SDK_IP_OVERRIDE=1 on a GPG-signed HEAD "
                "to manually override (logged to "
                "scripts/check_sdk_ip_override_audit.log)."
            )
            if paper_exemptions:
                print()
                print(f"Note: {len(paper_exemptions)} hit(s) are already "
                      f"paper-priority-exempt via arXiv release:")
                for h, pid, aid in paper_exemptions:
                    print(f"  {h.suffix}  ← {pid} released (arXiv {aid})")
        elif deny_state == "override":
            print()
            print(f"WARN (publish-gate) — {len(deny_hits)} deny-listed file(s) "
                  f"present; manual override accepted:")
            for h in deny_hits:
                marker = ""
                for (eh, pid, aid) in paper_exemptions:
                    if eh.suffix == h.suffix:
                        marker = f"  (would also lift via {pid} arXiv {aid})"
                        break
                print(h.format(REPO_ROOT) + marker)
            stub_note = " (test stub)" if deny_stubbed else ""
            print(f"Override env set, HEAD signature verified{stub_note}. "
                  f"Logged to {OVERRIDE_AUDIT_LOG.relative_to(REPO_ROOT)}.")
        elif deny_state == "paper_override":
            print()
            print(f"OK (publish-gate) — {len(paper_exemptions)} deny-listed "
                  f"file(s) present, all paper-priority-exempt via arXiv "
                  f"release:")
            for h, pid, aid in paper_exemptions:
                print(f"  {h.suffix}  ← {pid} released (arXiv {aid})")
            print(f"Logged to {OVERRIDE_AUDIT_LOG.relative_to(REPO_ROOT)}.")
        else:
            print()
            print("OK (publish-gate) — no deny-listed files under src/kairos/.")

        # Anti-cheat detector gate (ATH-499 Tier 1, 2026-04-23).
        if detector_hits:
            print()
            print(
                f"FAIL (publish-gate) — {len(detector_hits)} anti-cheat "
                f"detector match(es) under src/kairos/:"
            )
            for dh in detector_hits:
                print(dh.format(REPO_ROOT))
            print()
            print(
                "These are caught by the Tier-1 source-code anti-cheat "
                "detectors (stub_body / literal_verdict / "
                "reference_module_import / witness_file_check / "
                "macro_sorry). Fix the plugin source, or — if the match "
                "is a deliberate fixture — add the path prefix to "
                "_DETECTOR_EXEMPT_PATH_PREFIXES in scripts/check_sdk_ip.py."
            )
        else:
            print()
            print("OK (publish-gate) — anti-cheat detectors all clean.")

    return 0 if not fail else 1


if __name__ == "__main__":
    sys.exit(main())
