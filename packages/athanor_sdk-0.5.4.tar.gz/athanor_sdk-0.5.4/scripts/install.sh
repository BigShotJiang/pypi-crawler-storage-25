#!/usr/bin/env bash
# ATH-369 — Athanor SDK installer with sudo minimization + GPG sig verification.
#
# Run this script from an unpacked enterprise-delivery tarball. Expected
# layout of the working directory:
#
#   install.sh              (this file)
#   install.sh.sig          detached GPG sig of install.sh, signed by us
#   pubkey.asc              our signing public key (ships IN the tarball,
#                           NEVER fetched from a keyserver)
#   athanor-sdk-*.tar.gz    the SDK Python source distribution
#   kairos-*.tar.gz.sig  detached GPG sig of the SDK tarball
#   license.json            per-customer signed license (optional at install)
#   license.json.sig        detached GPG sig of license.json (optional)
#
# Security model (see docs/sdk-roadmap.md §6.a.1):
#
#   1. The pubkey fingerprint below is HARD-CODED. The out-of-band
#      delivery channels (signed contract PDF + direct email from Aidan)
#      give the customer a way to verify the fingerprint printed here
#      matches the one they were told to expect. If those two don't
#      match, abort — this tarball didn't come from us.
#
#   2. GPG verification uses an EPHEMERAL GNUPGHOME (mktemp -d) so we
#      never touch the customer's existing keyring. Import → verify →
#      delete.
#
#   3. The pubkey is imported from ./pubkey.asc shipped in the tarball.
#      We never run `gpg --recv-keys` — a compromised keyserver with a
#      colliding fingerprint would silently defeat the chain.
#
#   4. Most install actions run as the invoking user. Only the optional
#      `--prefix /opt/athanor` copy step uses sudo, and only if that
#      flag was passed. Default: install everything into ~/.athanor/ +
#      `pip install --user`.
#
#   5. --dry-run prints every action without executing. Customer should
#      run with --dry-run first, sanity-check, then re-run without it.
#
# Usage:
#   ./install.sh --dry-run         # preview
#   ./install.sh                   # install to ~/.athanor + user site-pkgs
#   ./install.sh --prefix /opt/athanor    # sudo install to system prefix
#
set -euo pipefail

# ─── Hard-coded key material (DO NOT change without re-ship) ─────────────
#
# Fingerprint of the Athanor AI signing key. Verify this matches the
# fingerprint on the first page of your signed contract PDF and the
# Aidan-sent onboarding email BEFORE running this script. If they don't
# match, stop and contact aidan@athanorl.com.
#
# TODO(ATH-369 phase 2): replace with the real fingerprint generated
# during ATH-340 customer provisioning key-gen. Until replaced, the
# regex check in verify_pubkey_fingerprint will hard-fail — real GPG
# fingerprints are 40 uppercase hex characters; this placeholder is
# deliberately not. Do not ship to any real customer until this is
# resolved.
readonly EXPECTED_FPR="REPLACE_WITH_40_HEX_CHAR_GPG_FINGERPRINT_PER_ATH340"

# ─── Config ──────────────────────────────────────────────────────────────

DRY_RUN=0
PREFIX=""                 # empty → user install; set → sudo system install
VERBOSE=0
SKIP_SIG_FOR_TESTS=0      # ONLY set by the test harness. Never exposed as a flag.
WORK_DIR="${PWD}"
GPG_HOME=""               # set by setup_gpg_home; cleaned up by trap

# ATH-404 state (populated by parse_license_scope):
LICENSE_PRODUCTS=""       # space-separated, e.g. "envs solve"
LICENSE_ENVS=""           # space-separated, e.g. "neuron-nki sysverilog"
BUILDER_STATE="skipped"   # "installed" | "skipped" | "missing-but-required"
INSTALLED_CONTAINERS=""   # space-separated list of env slugs we extracted


# ─── Helpers ─────────────────────────────────────────────────────────────

log() {
  printf '[athanor-install] %s\n' "$*" >&2
}

fatal() {
  printf '[athanor-install][ERROR] %s\n' "$*" >&2
  exit 1
}

run_cmd() {
  # Print the command; if not dry-run, execute it.
  local label="$1"; shift
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[DRY-RUN] %s: %s\n' "$label" "$*" >&2
    return 0
  fi
  if [[ "$VERBOSE" -eq 1 ]]; then
    printf '[exec] %s: %s\n' "$label" "$*" >&2
  fi
  "$@"
}

cleanup_gpg_home() {
  if [[ -n "$GPG_HOME" && -d "$GPG_HOME" ]]; then
    rm -rf "$GPG_HOME"
  fi
}
trap cleanup_gpg_home EXIT


# ─── CLI ─────────────────────────────────────────────────────────────────

usage() {
  cat <<'EOF'
Athanor SDK installer.

Usage:
  install.sh [OPTIONS]

Options:
  --dry-run            Print every action; execute nothing.
  --prefix DIR         Install to DIR (e.g. /opt/athanor). Requires sudo.
                       Default: install to the user's home + user site-packages,
                       no sudo needed.
  --verbose            Print each command as it executes.
  -h, --help           Show this help and exit.

Security:
  This installer verifies the SDK tarball against a GPG signature using a
  fingerprint hard-coded into this script. Before running, open the signed
  contract PDF or Aidan's onboarding email — the fingerprint shown at the
  start of this script run must match the one you were sent out-of-band.
  Never skip that step.

  The installer uses an ephemeral GNUPGHOME, so it does not touch your
  existing GPG keyring.
EOF
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dry-run)        DRY_RUN=1; shift ;;
      --verbose)        VERBOSE=1; shift ;;
      --prefix)
        [[ $# -ge 2 ]] || fatal "--prefix requires an argument"
        PREFIX="$2"; shift 2 ;;
      --prefix=*)       PREFIX="${1#*=}"; shift ;;
      -h|--help)        usage; exit 0 ;;
      # Undocumented; used by the test harness only. Presence of this
      # flag is visible in --dry-run output, so a misuser sees it.
      --__skip-sig-for-tests)
        SKIP_SIG_FOR_TESTS=1; shift ;;
      *)                fatal "Unknown argument: $1. See --help." ;;
    esac
  done
}


# ─── Precheck ────────────────────────────────────────────────────────────

precheck() {
  # Required tools. Note we don't install anything for the customer — if
  # their system is missing gpg we fail loudly rather than reaching for
  # apt-get silently.
  command -v gpg >/dev/null 2>&1 || fatal \
    "gpg not found. Install it (e.g. \`apt-get install gnupg\`) and retry."
  command -v python3 >/dev/null 2>&1 || fatal \
    "python3 not found. Python 3.10+ is required."

  # Python version — bail early if too old.
  local py_major py_minor
  py_major=$(python3 -c 'import sys; print(sys.version_info.major)')
  py_minor=$(python3 -c 'import sys; print(sys.version_info.minor)')
  if [[ "$py_major" -lt 3 ]] || { [[ "$py_major" -eq 3 ]] && [[ "$py_minor" -lt 10 ]]; }; then
    fatal "Python 3.10+ required; found ${py_major}.${py_minor}."
  fi

  # Working-directory layout.
  [[ -f "${WORK_DIR}/pubkey.asc" ]] || fatal \
    "Missing ${WORK_DIR}/pubkey.asc. Run this installer from an unpacked tarball."
  local sdk_tarball
  sdk_tarball=$(find "${WORK_DIR}" -maxdepth 1 -name 'kairos-*.tar.gz' | head -n 1)
  [[ -n "$sdk_tarball" ]] || fatal \
    "No kairos-*.tar.gz found in ${WORK_DIR}. Tarball is incomplete."
  [[ -f "${sdk_tarball}.sig" ]] || fatal \
    "Missing ${sdk_tarball}.sig. SDK tarball is unsigned — refusing to install."
}


# ─── GPG verification ────────────────────────────────────────────────────

setup_gpg_home() {
  # Use an ephemeral GNUPGHOME so we don't pollute ~/.gnupg.
  GPG_HOME=$(mktemp -d -t athanor-install-XXXXXX)
  chmod 0700 "$GPG_HOME"
  export GNUPGHOME="$GPG_HOME"
  if [[ "$VERBOSE" -eq 1 || "$DRY_RUN" -eq 1 ]]; then
    log "Ephemeral GNUPGHOME: $GPG_HOME"
  fi
}

verify_pubkey_fingerprint() {
  # Import the pubkey into the ephemeral home, then sanity-check its
  # fingerprint against the hard-coded value. Real GPG fingerprints are
  # exactly 40 uppercase-hex characters; anything else (including the
  # placeholder above) hard-fails.
  if ! [[ "$EXPECTED_FPR" =~ ^[A-F0-9]{40}$ ]]; then
    fatal \
      "EXPECTED_FPR does not look like a real GPG fingerprint " \
      "(expected 40 uppercase hex chars; got '$EXPECTED_FPR'). " \
      "This installer is likely a pre-release template — do not use " \
      "to install a real SDK delivery."
  fi

  run_cmd gpg-import gpg --batch --import "${WORK_DIR}/pubkey.asc"

  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[DRY-RUN] fingerprint-check: would verify imported key matches %s\n' \
      "$EXPECTED_FPR" >&2
    return 0
  fi

  # Extract the first fingerprint from the keyring. --with-colons is
  # scriptable; field 10 of the `fpr` record is the full fingerprint.
  local actual_fpr
  actual_fpr=$(gpg --batch --list-keys --with-colons 2>/dev/null \
    | awk -F: '/^fpr:/ { print $10; exit }')
  [[ -n "$actual_fpr" ]] || fatal \
    "Failed to read fingerprint from imported pubkey."
  if [[ "$actual_fpr" != "$EXPECTED_FPR" ]]; then
    fatal \
      "Fingerprint mismatch. Expected: $EXPECTED_FPR. Imported: $actual_fpr. " \
      "This tarball was NOT signed by the key Athanor told you to expect. " \
      "Stop and contact aidan@athanorl.com."
  fi
  log "Pubkey fingerprint OK: $actual_fpr"
}

verify_sig() {
  # $1 = file to verify, $2 = detached-sig file.
  local file="$1" sig="$2"
  if [[ "$SKIP_SIG_FOR_TESTS" -eq 1 ]]; then
    log "SKIP_SIG_FOR_TESTS set — bypassing signature verification for $file"
    return 0
  fi
  run_cmd gpg-verify gpg --batch --verify "$sig" "$file"
}

verify_tarball_sigs() {
  local sdk_tarball
  sdk_tarball=$(find "${WORK_DIR}" -maxdepth 1 -name 'kairos-*.tar.gz' | head -n 1)
  verify_sig "$sdk_tarball" "${sdk_tarball}.sig"

  # License is optional at install time — may land post-install via a
  # separate delivery. Verify only if present.
  if [[ -f "${WORK_DIR}/license.json" ]]; then
    [[ -f "${WORK_DIR}/license.json.sig" ]] || fatal \
      "license.json present but license.json.sig missing — refusing to install."
    verify_sig "${WORK_DIR}/license.json" "${WORK_DIR}/license.json.sig"
  fi

  # ATH-404: builder tarball sig verified only when it's present; we
  # don't require its presence yet — install_builder decides based on
  # license scope. If the tarball is present, its sig MUST be too.
  local builder_tarball
  builder_tarball=$(find "${WORK_DIR}" -maxdepth 1 -name 'athanor-builder-*.tar.gz' | head -n 1)
  if [[ -n "$builder_tarball" ]]; then
    [[ -f "${builder_tarball}.sig" ]] || fatal \
      "builder tarball $builder_tarball present but .sig missing — refusing to install."
    verify_sig "$builder_tarball" "${builder_tarball}.sig"
  fi
}


# ─── ATH-404: license-scope-aware install paths ───────────────────────────

parse_license_scope() {
  # Populate LICENSE_PRODUCTS + LICENSE_ENVS from license.json. No-op when
  # the delivery has no license (dev-mode SDK install).
  if [[ ! -f "${WORK_DIR}/license.json" ]]; then
    return 0
  fi
  # Use python3 for robust JSON parsing. Python is already a precheck
  # requirement so no new dependency.
  LICENSE_PRODUCTS=$(python3 -c "
import json, sys
try:
    d = json.load(open('${WORK_DIR}/license.json'))
    print(' '.join(d.get('products', [])))
except Exception as e:
    print(f'parse error: {e}', file=sys.stderr)
    sys.exit(1)
")
  LICENSE_ENVS=$(python3 -c "
import json, sys
try:
    d = json.load(open('${WORK_DIR}/license.json'))
    print(' '.join(d.get('envs', [])))
except Exception as e:
    print(f'parse error: {e}', file=sys.stderr)
    sys.exit(1)
")
  log "License scope: products=[${LICENSE_PRODUCTS}] envs=[${LICENSE_ENVS}]"
}

contains_word() {
  # $1 = haystack (space-separated words), $2 = needle.
  # Returns 0 if needle is a whole word in haystack.
  local haystack="$1" needle="$2"
  [[ " $haystack " == *" $needle "* ]]
}

install_builder() {
  # Extract athanor-builder tarball to $prefix/builder iff license grants
  # "solve". An envs-only license silently skips (the packager at ATH-390
  # shouldn't have shipped a builder anyway; if one is present we note it
  # but don't install it).
  local builder_tarball
  builder_tarball=$(find "${WORK_DIR}" -maxdepth 1 -name 'athanor-builder-*.tar.gz' | head -n 1)

  # License absent = dev-mode SDK install → install builder iff present
  # (backward-compatible behavior). This keeps internal VMs working.
  if [[ -z "$LICENSE_PRODUCTS" ]]; then
    if [[ -z "$builder_tarball" ]]; then
      BUILDER_STATE="skipped"
      return 0
    fi
    # No license, builder present — install it.
  elif ! contains_word "$LICENSE_PRODUCTS" "solve"; then
    # Envs-only license: skip builder entirely, even if delivered.
    if [[ -n "$builder_tarball" ]]; then
      log "Builder tarball present but license.products=[${LICENSE_PRODUCTS}] does not grant 'solve' — skipping extraction."
    fi
    BUILDER_STATE="skipped"
    return 0
  else
    # Solve-licensed: builder is REQUIRED.
    if [[ -z "$builder_tarball" ]]; then
      BUILDER_STATE="missing-but-required"
      fatal \
        "License grants 'solve' but no athanor-builder-*.tar.gz found in delivery. " \
        "This is a broken bundle — contact aidan@athanorl.com."
    fi
  fi

  # Extract to the install target.
  local builder_target
  if [[ -z "$PREFIX" ]]; then
    builder_target="$HOME/.athanor/builder"
    run_cmd mkdir-builder-home mkdir -p "$builder_target"
  else
    builder_target="$PREFIX/builder"
    run_cmd mkdir-builder-prefix sudo mkdir -p "$builder_target"
  fi
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '[DRY-RUN] extract-builder: would tar -xzf %s -C %s\n' \
      "$builder_tarball" "$builder_target" >&2
  elif [[ -z "$PREFIX" ]]; then
    tar -xzf "$builder_tarball" -C "$builder_target"
  else
    sudo tar -xzf "$builder_tarball" -C "$builder_target"
  fi
  BUILDER_STATE="installed"
  log "Builder installed to $builder_target"
}

install_scoring_containers() {
  # Copy scoring-containers/<env>.tar for each env in license.envs[] into
  # $prefix/scoring-containers/. Containers outside license.envs are
  # skipped (defense in depth over ATH-390's ship-time filter).
  local sc_dir="${WORK_DIR}/scoring-containers"
  if [[ ! -d "$sc_dir" ]]; then
    return 0
  fi

  local sc_target
  if [[ -z "$PREFIX" ]]; then
    sc_target="$HOME/.athanor/scoring-containers"
    run_cmd mkdir-sc-home mkdir -p "$sc_target"
  else
    sc_target="$PREFIX/scoring-containers"
    run_cmd mkdir-sc-prefix sudo mkdir -p "$sc_target"
  fi

  local tar env_name
  # Use a nullglob-safe loop so the pattern works even with no matches.
  shopt -s nullglob
  for tar in "$sc_dir"/*.tar; do
    env_name=$(basename "$tar" .tar)
    # License absent = install anything that was delivered (internal VMs).
    if [[ -n "$LICENSE_ENVS" ]] && ! contains_word "$LICENSE_ENVS" "$env_name"; then
      log "Scoring container '$env_name' not in license.envs[] — skipping."
      continue
    fi
    if [[ "$DRY_RUN" -eq 1 ]]; then
      printf '[DRY-RUN] copy-sc: would cp %s %s\n' "$tar" "$sc_target/" >&2
    elif [[ -z "$PREFIX" ]]; then
      cp "$tar" "$sc_target/"
      chmod 0644 "$sc_target/$(basename "$tar")"
    else
      sudo cp "$tar" "$sc_target/"
      sudo chmod 0644 "$sc_target/$(basename "$tar")"
    fi
    INSTALLED_CONTAINERS="$INSTALLED_CONTAINERS $env_name"
  done
  shopt -u nullglob
  INSTALLED_CONTAINERS="${INSTALLED_CONTAINERS# }"  # trim leading space
}

print_config_summary() {
  log "────────────────────────────────────────────"
  log "Install complete. Configuration applied:"
  log "  products:   ${LICENSE_PRODUCTS:-<no license>}"
  log "  envs:       ${LICENSE_ENVS:-<no license>}"
  log "  builder:    ${BUILDER_STATE}"
  log "  containers: ${INSTALLED_CONTAINERS:-<none>}"
  log "────────────────────────────────────────────"
}


# ─── Install steps (user-scoped unless --prefix) ─────────────────────────

install_sdk_python() {
  local sdk_tarball
  sdk_tarball=$(find "${WORK_DIR}" -maxdepth 1 -name 'kairos-*.tar.gz' | head -n 1)
  if [[ -z "$PREFIX" ]]; then
    # User install — no sudo.
    run_cmd pip-user-install python3 -m pip install --user --no-deps --no-index \
      "$sdk_tarball"
  else
    # Prefix install — sudo copy + site-packages into PREFIX.
    run_cmd mkdir-prefix sudo mkdir -p "$PREFIX/lib"
    run_cmd pip-prefix-install sudo python3 -m pip install --target "$PREFIX/lib" \
      --no-deps --no-index "$sdk_tarball"
  fi
}

install_artifacts() {
  # Write signed copies of pubkey + license to ~/.athanor/ (or PREFIX) so
  # the runtime can re-verify license signatures on every `athanor spec
  # submit` (ATH-369 Med #8).
  local target
  if [[ -z "$PREFIX" ]]; then
    target="$HOME/.athanor"
    run_cmd mkdir-home mkdir -p "$target"
    run_cmd chmod-home chmod 0700 "$target"
  else
    target="$PREFIX"
    run_cmd mkdir-prefix sudo mkdir -p "$target"
  fi

  run_cmd copy-pubkey install_file "${WORK_DIR}/pubkey.asc" "$target/pubkey.asc" 0600
  if [[ -f "${WORK_DIR}/license.json" ]]; then
    run_cmd copy-license install_file "${WORK_DIR}/license.json" \
      "$target/license.json" 0600
    run_cmd copy-license-sig install_file "${WORK_DIR}/license.json.sig" \
      "$target/license.json.sig" 0600
  fi
}

install_file() {
  # Helper — reads args file, dest, mode. Sudo if the dest is privileged.
  local src="$1" dst="$2" mode="$3"
  if [[ -z "$PREFIX" ]]; then
    cp "$src" "$dst"
    chmod "$mode" "$dst"
  else
    sudo cp "$src" "$dst"
    sudo chmod "$mode" "$dst"
  fi
}


# ─── Main ────────────────────────────────────────────────────────────────

main() {
  parse_args "$@"
  log "Starting Athanor SDK install (dry-run=${DRY_RUN}, prefix=${PREFIX:-<user>})"
  precheck
  setup_gpg_home
  verify_pubkey_fingerprint
  verify_tarball_sigs
  parse_license_scope          # ATH-404
  install_sdk_python
  install_artifacts
  install_builder              # ATH-404 — conditional on license.products
  install_scoring_containers   # ATH-404 — filtered by license.envs
  print_config_summary         # ATH-404
  log "Run \`athanor --version\` to confirm."
}

# Only run main if this script is being executed (not sourced by tests).
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
fi
