#!/usr/bin/env python3
"""ATH-369 #1 — TLS-verify-disable CI gate.

Replaces the bash `grep` that lived in `.github/workflows/ci.yml` as
the `tls-verification` job. The bash version has a documented
limitation: it can't distinguish code from comments/docstrings, so
any `.py` file whose docstring mentions the footgun-pattern trips the
check on itself (bit check_sdk_ip.py on 2026-04-19 — its docstring
said 'verify=False' literally).

This Python replacement uses the `tokenize` module to enumerate
executable tokens only, skipping COMMENT and STRING token classes.
A file's docstring can say whatever it wants; the check only fires
when the pattern appears in real code.

## Patterns guarded

  1. `verify=False` / `verify = False` — `requests.get(url, verify=False)`
     and similar, which disable TLS certificate verification on the
     per-call or per-session level.
  2. `PYTHONHTTPSVERIFY=0` as an env-var assignment — globally
     disables TLS verification for all stdlib HTTPS.
  3. `SSL_CERT_FILE=/dev/null` — pointing the CA bundle at nothing,
     a trick sometimes used in tests.

Any of these in `src/` or `scripts/` executable code fails CI. Tests
can legitimately exercise disabled-verify behavior and should live
under `tests/`.

## Exit codes

  0 — clean
  1 — at least one hit

Usage:

  python3 scripts/check_tls_verify.py [--verbose]
"""
from __future__ import annotations

import argparse
import io
import re
import sys
import tokenize
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


REPO_ROOT = Path(__file__).resolve().parent.parent
SRC_DIRS = [REPO_ROOT / "src", REPO_ROOT / "scripts"]


# ─── Patterns ────────────────────────────────────────────────────────────

# Each pattern matches the FOOTGUN as it appears in real executable
# Python code. Expressed as regex because `tokenize` returns tokens,
# not parsed AST — we reassemble executable-token source and then
# regex-search it. Patterns must therefore tolerate whitespace
# variations but don't need to handle string/comment cases (those
# are stripped by tokenize before we see them).
PATTERNS: list[tuple[str, str]] = [
    (r"\bverify\s*=\s*False\b",
     "requests call with verify=False disables TLS cert verification"),
    (r"PYTHONHTTPSVERIFY\s*=\s*['\"]?0\b",
     "PYTHONHTTPSVERIFY=0 disables stdlib HTTPS cert verification"),
    (r"SSL_CERT_FILE\s*=\s*['\"]?/dev/null\b",
     "SSL_CERT_FILE=/dev/null points CA bundle at nothing"),
]


# ─── Extract executable tokens ──────────────────────────────────────────


@dataclass
class Hit:
    file: Path
    line_no: int
    pattern_desc: str
    matched_text: str

    def format(self, root: Path) -> str:
        rel = self.file.relative_to(root)
        return f"  {rel}:{self.line_no}: {self.pattern_desc}\n    → {self.matched_text.strip()}"


def _executable_source(path: Path) -> list[tuple[int, str]]:
    """Return a list of (line_no, code_on_that_line) pairs with
    comments + string literals stripped out.

    Uses tokenize so multi-line strings (docstrings) are handled
    correctly — their content doesn't leak into the returned text.
    """
    try:
        raw = path.read_bytes()
    except OSError:
        return []

    lines: dict[int, list[str]] = {}
    try:
        tokens = tokenize.tokenize(io.BytesIO(raw).readline)
        for tok in tokens:
            if tok.type in (
                tokenize.COMMENT,
                tokenize.STRING,
                tokenize.NL,
                tokenize.NEWLINE,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENCODING,
                tokenize.ENDMARKER,
            ):
                continue
            start_line = tok.start[0]
            lines.setdefault(start_line, []).append(tok.string)
    except tokenize.TokenizeError:
        # Malformed file — skip silently. CI will catch via py_compile
        # job anyway.
        return []

    # Reassemble each line's tokens with a single space separator.
    # This loses precise whitespace but keeps regex patterns working
    # for the `foo = False` class of hits.
    return [
        (line_no, " ".join(toks))
        for line_no, toks in sorted(lines.items())
    ]


def _scan_file(path: Path) -> list[Hit]:
    hits: list[Hit] = []
    for line_no, code in _executable_source(path):
        for pattern, desc in PATTERNS:
            m = re.search(pattern, code)
            if m:
                hits.append(Hit(path, line_no, desc, m.group(0)))
    return hits


def _iter_py_files(dirs: Iterable[Path]) -> Iterable[Path]:
    for d in dirs:
        if not d.is_dir():
            continue
        for p in d.rglob("*.py"):
            if "__pycache__" in p.parts:
                continue
            yield p


# ─── Main ────────────────────────────────────────────────────────────────


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--verbose", action="store_true",
                        help="print every file scanned")
    args = parser.parse_args()

    if args.verbose:
        for p in _iter_py_files(SRC_DIRS):
            print(f"scan {p.relative_to(REPO_ROOT)}", file=sys.stderr)

    hits: list[Hit] = []
    n_files = 0
    for p in _iter_py_files(SRC_DIRS):
        n_files += 1
        hits.extend(_scan_file(p))

    if not hits:
        scopes = " + ".join(
            str(d.relative_to(REPO_ROOT)) for d in SRC_DIRS if d.is_dir()
        )
        print(f"✓ No TLS-verify-disable footguns in {scopes} ({n_files} files scanned).")
        return 0

    print(f"FAIL — {len(hits)} TLS-verify-disable footgun(s) found:")
    for h in hits:
        print(h.format(REPO_ROOT))
    print()
    print(
        "This is a Critical security finding (ATH-369 #1). If you need to "
        "disable verification for a legitimate test, put that code under "
        "tests/ (this gate only scans src/ + scripts/)."
    )
    return 1


if __name__ == "__main__":
    sys.exit(main())
