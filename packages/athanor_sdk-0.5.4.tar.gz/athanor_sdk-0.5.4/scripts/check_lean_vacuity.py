#!/usr/bin/env python3
"""ATH-1149: Pre-commit vacuity detector for Lean theorem files.

Text-level static analysis that catches the patterns Aristotle uses
to generate type-correct but vacuous proofs. Runs in CI without
lake build. Complements the Lean meta-program (layer 2) that does
semantic checking after build.

Patterns detected:
1. Conclusion is literal `True` or `trivial`
2. Conclusion appears verbatim in hypotheses (tautology)
3. Hypothesis with `_` prefix (unused variable convention)
4. Match/if branches all returning the same value
5. Definition body is `True` or `fun _ => True`

Exit code 0 = clean, 1 = vacuity detected.
"""
from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VacuityHit:
    file: str
    line: int
    pattern: str
    detail: str


def check_file(path: Path) -> list[VacuityHit]:
    """Check one .lean file for vacuity patterns."""
    hits: list[VacuityHit] = []
    text = path.read_text()
    lines = text.splitlines()

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        # Pattern 1: conclusion is literal True
        if re.search(r":\s*True\s*:?=", stripped):
            hits.append(VacuityHit(
                str(path), i, "conclusion_true",
                f"Theorem conclusion is literal True: {stripped[:80]}",
            ))
        if re.search(r":=\s*trivial\s*$", stripped):
            hits.append(VacuityHit(
                str(path), i, "proof_trivial",
                f"Proof body is `trivial`: {stripped[:80]}",
            ))

        # Pattern 3: unused hypothesis (_h prefix)
        if re.match(r"\s*\(_\w+\s*:", stripped) and "noqa" not in stripped:
            # Check if the variable is actually used in subsequent lines
            var_match = re.match(r"\s*\((_\w+)\s*:", stripped)
            if var_match:
                var_name = var_match.group(1)
                rest = "\n".join(lines[i:min(i + 20, len(lines))])
                if var_name not in rest:
                    hits.append(VacuityHit(
                        str(path), i, "unused_hypothesis",
                        f"Hypothesis {var_name} appears unused in proof body",
                    ))

    # Pattern 4: match/if with all branches returning same value
    match_blocks = re.finditer(
        r"match\s+\w+\s+with((?:\s*\|[^\n]+)+)", text,
    )
    for m in match_blocks:
        block = m.group(1)
        branch_results = re.findall(r"=>\s*(.+?)(?:\s*$|\s*\|)", block, re.MULTILINE)
        if len(branch_results) >= 2:
            unique = set(r.strip() for r in branch_results)
            if len(unique) == 1:
                line_no = text[:m.start()].count("\n") + 1
                hits.append(VacuityHit(
                    str(path), line_no, "all_branches_same",
                    f"All match branches return same value: {unique.pop()[:60]}",
                ))

    # Pattern 5: definition body is True
    for m in re.finditer(r"def\s+(\w+).*?:=\s*(True|fun\s+_\s*=>\s*True)", text):
        line_no = text[:m.start()].count("\n") + 1
        hits.append(VacuityHit(
            str(path), line_no, "def_always_true",
            f"Definition `{m.group(1)}` body is always True",
        ))

    # Pattern 2: conclusion = hypothesis (tautology)
    for m in re.finditer(
        r"theorem\s+(\w+).*?\((\w+)\s*:\s*([^)]+)\).*?:\s*(\S[^:=]+?)\s*:=",
        text, re.DOTALL,
    ):
        hyp_type = m.group(3).strip()
        conclusion = m.group(4).strip()
        if hyp_type == conclusion:
            line_no = text[:m.start()].count("\n") + 1
            hits.append(VacuityHit(
                str(path), line_no, "conclusion_equals_hypothesis",
                f"Theorem `{m.group(1)}`: conclusion equals hypothesis type (tautology)",
            ))

    return hits


def main() -> int:
    scan_dirs = sys.argv[1:] or ["."]
    all_hits: list[VacuityHit] = []

    for scan_dir in scan_dirs:
        for lean_file in sorted(Path(scan_dir).rglob("*.lean")):
            if ".lake" in str(lean_file):
                continue
            hits = check_file(lean_file)
            all_hits.extend(hits)

    if not all_hits:
        print(f"OK — no vacuity detected.")
        return 0

    print(f"VACUITY DETECTED — {len(all_hits)} hit(s):\n")
    for h in all_hits:
        print(f"  {h.file}:{h.line} [{h.pattern}]")
        print(f"    {h.detail}")
        print()

    return 1


if __name__ == "__main__":
    sys.exit(main())
