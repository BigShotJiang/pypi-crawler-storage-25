#!/usr/bin/env bash
# ATH-946: install Clash + Yosys + EQY on the tahoe runner.
#
# Composes with kairos.pure_rtl + kairos.eqy + kairos.silicon_review
# verticals. Once installed:
#   - tests/integration/test_pure_rtl_eqy.py skipif tests start passing
#   - examples/pure-rtl-roundtrip/run_demo.py runs end-to-end
#   - examples/customer/toy_fifo_chain/pipeline_run.py discharges the
#     10 currently-gated obligations against actual EQY
#
# Idempotent: skip-if-already-installed checks at each step.

set -euo pipefail

INSTALL_LOG=/tmp/purertl-toolchain-install.log
echo "[ATH-946] starting toolchain install at $(date -u +%FT%TZ)" | tee "$INSTALL_LOG"

# Retry helper for network-flake operations (apt/cabal/git mirrors).
retry() {
    local n=0
    local max=3
    until [ "$n" -ge "$max" ]; do
        if "$@" 2>&1 | tee -a "$INSTALL_LOG"; then
            return 0
        fi
        n=$((n + 1))
        echo "[ATH-946] retry $n/$max for: $*" | tee -a "$INSTALL_LOG"
        sleep $((10 * n))
    done
    return 1
}

# ─── Step 1: Yosys (built from source — apt 0.9 lacks yosys-config) ─
# EQY requires yosys-config which is in yosys >= 0.30. Ubuntu 22.04
# apt ships 0.9 which lacks it. Build yosys from source to get a
# version EQY can link against.
if command -v yosys-config >/dev/null 2>&1; then
    echo "[ATH-946] yosys-config already on PATH: $(yosys -V 2>&1 | head -1)" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] building yosys from source (apt 0.9 lacks yosys-config for EQY)" | tee -a "$INSTALL_LOG"
    sudo apt-get install -y build-essential clang bison flex libreadline-dev gawk \
        tcl-dev libffi-dev pkg-config python3 libboost-system-dev libboost-python-dev \
        libboost-filesystem-dev zlib1g-dev 2>&1 | tee -a "$INSTALL_LOG"
    YOSYS_SRC="${YOSYS_SRC:-/tmp/yosys-build}"
    if [ ! -d "$YOSYS_SRC" ]; then
        git clone --depth 1 --branch yosys-0.44 https://github.com/YosysHQ/yosys.git "$YOSYS_SRC" 2>&1 | tee -a "$INSTALL_LOG"
    fi
    cd "$YOSYS_SRC"
    git submodule update --init --recursive 2>&1 | tee -a "$INSTALL_LOG"
    make -j$(nproc) config-clang 2>&1 | tee -a "$INSTALL_LOG"
    make -j$(nproc) 2>&1 | tee -a "$INSTALL_LOG" || {
        echo "[ATH-946] FAIL: yosys build" | tee -a "$INSTALL_LOG"
        exit 1
    }
    sudo make install 2>&1 | tee -a "$INSTALL_LOG"
    cd -
fi

# ─── Step 2: GHC + cabal (Haskell toolchain for Clash) ──────────────
if command -v ghc >/dev/null 2>&1 && command -v cabal >/dev/null 2>&1; then
    echo "[ATH-946] ghc + cabal already on PATH: $(ghc --numeric-version)" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] installing ghc + cabal-install via apt" | tee -a "$INSTALL_LOG"
    sudo apt-get install -y ghc cabal-install 2>&1 | tee -a "$INSTALL_LOG" || {
        echo "[ATH-946] FAIL: ghc/cabal install" | tee -a "$INSTALL_LOG"
        exit 1
    }
fi

# ─── Step 3: Clash (cabal install) ──────────────────────────────────
if command -v clash >/dev/null 2>&1; then
    echo "[ATH-946] clash already on PATH: $(clash --numeric-version 2>&1 || echo unknown)" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] installing clash via cabal" | tee -a "$INSTALL_LOG"
    retry cabal update
    echo "[ATH-946] WARNING: clash install via cabal takes 15-20 min — do not kill" | tee -a "$INSTALL_LOG"
    cabal install --installdir="$HOME/.cabal/bin" --overwrite-policy=always clash-ghc 2>&1 | tee -a "$INSTALL_LOG" || {
        echo "[ATH-946] FAIL: clash install" | tee -a "$INSTALL_LOG"
        exit 1
    }
    export PATH="$HOME/.cabal/bin:$PATH"
fi

# ─── Step 4: EQY (clone + build from SymbiYosys) ────────────────────
if command -v eqy >/dev/null 2>&1; then
    echo "[ATH-946] eqy already on PATH" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] installing eqy from source" | tee -a "$INSTALL_LOG"
    EQY_SRC="${EQY_SRC:-/tmp/eqy-build}"
    if [ ! -d "$EQY_SRC" ]; then
        git clone https://github.com/YosysHQ/eqy.git "$EQY_SRC" 2>&1 | tee -a "$INSTALL_LOG"
    fi
    cd "$EQY_SRC"
    # Pin to EQY tag matching yosys-0.44 (main branch needs newer yosys API)
    git checkout yosys-0.44 2>&1 | tee -a "$INSTALL_LOG"
    sudo make install 2>&1 | tee -a "$INSTALL_LOG" || {
        echo "[ATH-946] FAIL: eqy install" | tee -a "$INSTALL_LOG"
        exit 1
    }
    cd -
fi

# ─── Step 5: Smoke tests ────────────────────────────────────────────
echo "[ATH-946] smoke tests..." | tee -a "$INSTALL_LOG"

YOSYS_VER=$(yosys -V 2>&1 | head -1 || echo "MISSING")
GHC_VER=$(ghc --numeric-version 2>&1 || echo "MISSING")
CLASH_VER=$(clash --numeric-version 2>&1 || echo "MISSING")
EQY_HELP=$(eqy --help 2>&1 | head -1 || echo "MISSING")

echo "  yosys: $YOSYS_VER" | tee -a "$INSTALL_LOG"
echo "  ghc:   $GHC_VER" | tee -a "$INSTALL_LOG"
echo "  clash: $CLASH_VER" | tee -a "$INSTALL_LOG"
echo "  eqy:   $EQY_HELP" | tee -a "$INSTALL_LOG"

# ─── Step 6: Trivial Clash compile (end-to-end smoke) ───────────────
TRIVIAL_DIR=$(mktemp -d)
cat > "$TRIVIAL_DIR/Trivial.hs" <<'EOF'
module Trivial where
import Clash.Prelude

topEntity :: Signal System Bit -> Signal System Bit
topEntity = id
EOF

echo "[ATH-946] smoke: clash compile of trivial id-circuit" | tee -a "$INSTALL_LOG"
cd "$TRIVIAL_DIR"
if clash --verilog Trivial.hs 2>&1 | tee -a "$INSTALL_LOG"; then
    echo "[ATH-946] smoke: clash compile PASSED" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] smoke: clash compile FAILED" | tee -a "$INSTALL_LOG"
    exit 1
fi
cd -
rm -rf "$TRIVIAL_DIR"

# ─── Step 7: EQY end-to-end smoke (proves runtime links against yosys) ──
EQY_SMOKE_DIR=$(mktemp -d)
cat > "$EQY_SMOKE_DIR/gold.v" <<'EOF'
module gold(input a, input b, output o); assign o = a & b; endmodule
EOF
cat > "$EQY_SMOKE_DIR/gate.v" <<'EOF'
module gate(input a, input b, output o); assign o = b & a; endmodule
EOF
cat > "$EQY_SMOKE_DIR/trivial.eqy" <<'EOF'
[gold]
read -sv gold.v
prep -top gold

[gate]
read -sv gate.v
prep -top gate

[strategy basic]
use sat
depth 1
EOF
echo "[ATH-946] smoke: eqy end-to-end on trivially-equivalent and-gate" | tee -a "$INSTALL_LOG"
cd "$EQY_SMOKE_DIR"
if eqy --jobs 1 trivial.eqy 2>&1 | tee -a "$INSTALL_LOG"; then
    echo "[ATH-946] smoke: eqy end-to-end PASSED" | tee -a "$INSTALL_LOG"
else
    echo "[ATH-946] smoke: eqy end-to-end FAILED — yosys/eqy link issue" | tee -a "$INSTALL_LOG"
    exit 1
fi
cd -
rm -rf "$EQY_SMOKE_DIR"

echo "[ATH-946] toolchain install complete at $(date -u +%FT%TZ)" | tee -a "$INSTALL_LOG"
echo "[ATH-946] full log: $INSTALL_LOG"
