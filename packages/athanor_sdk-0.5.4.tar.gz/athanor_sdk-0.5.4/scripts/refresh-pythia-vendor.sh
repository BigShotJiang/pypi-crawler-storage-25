#!/usr/bin/env bash
# Refresh the vendored Pythia snapshot from a local Pythia repo.
#
# Usage:
#   ./scripts/refresh-pythia-vendor.sh /path/to/pythia
#
# Writes PYTHIA_COMMIT into the vendor dir so the SDK's engine-version
# probe can report which Pythia commit is bundled (ATH-936).

set -euo pipefail

PYTHIA_SRC="${1:?Usage: refresh-pythia-vendor.sh /path/to/pythia}"
VENDOR_DIR="$(cd "$(dirname "$0")/.." && pwd)/src/kairos/_vendor/pythia"

if [ ! -d "$PYTHIA_SRC/.git" ]; then
    echo "error: $PYTHIA_SRC is not a git repository" >&2
    exit 1
fi

# Capture the commit hash before rsync
COMMIT=$(git -C "$PYTHIA_SRC" rev-parse --short=12 HEAD)
COMMIT_FULL=$(git -C "$PYTHIA_SRC" rev-parse HEAD)
COMMIT_DATE=$(git -C "$PYTHIA_SRC" log -1 --format=%ci HEAD)
BRANCH=$(git -C "$PYTHIA_SRC" rev-parse --abbrev-ref HEAD)

echo "[refresh-pythia-vendor] source: $PYTHIA_SRC"
echo "[refresh-pythia-vendor] commit: $COMMIT ($BRANCH, $COMMIT_DATE)"
echo "[refresh-pythia-vendor] target: $VENDOR_DIR"

# Rsync the snapshot (exclude .git, build artifacts)
rsync -a --delete \
    --exclude='.git' \
    --exclude='.lake' \
    --exclude='build' \
    --exclude='__pycache__' \
    "$PYTHIA_SRC/" "$VENDOR_DIR/"

# Write the commit manifest
cat > "$VENDOR_DIR/PYTHIA_COMMIT" <<EOF
$COMMIT_FULL
$BRANCH
$COMMIT_DATE
EOF

echo "[refresh-pythia-vendor] wrote PYTHIA_COMMIT: $COMMIT"
echo "[refresh-pythia-vendor] done"
