#!/usr/bin/env python3
"""Generate forward-compat + strict JSON schemas for the v2.7 iteration-arc
event types (ATH-1053 / ATH-1055).

Six event types pinned for the v2.7 closed-loop area-optimization demo:

* transformation_proposed
* verify_attempt
* bridge_invariant_proposed
* iteration_verdict
* iteration_complete
* bridge_lean_closed

Per platform PR #413 LGTM 2026-05-06 + asabi v0.1 sign-off: every cert /
iteration-arc event ships with TWO schemas. The forward-compat
(``additionalProperties=true``) variant matches the Pydantic ``extra='allow'``
runtime behavior; the strict (``additionalProperties=false``) variant
catches typo drift via the cross-arm contract test on the platform side.

Usage::

    python3 scripts/gen_iteration_arc_schemas.py

Writes 12 files (6 events x 2 variants) under ``schemas/``::

    schemas/transformation_proposed.schema.json
    schemas/transformation_proposed.strict.schema.json
    schemas/verify_attempt.schema.json
    schemas/verify_attempt.strict.schema.json
    ... (etc)

CI check via ``tests/test_iteration_arc_schemas_in_sync.py`` regenerates
in-memory + diffs against committed files. Pydantic model edits trigger
the drift alarm until you regen + commit the diff.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT / "src"))

from kairos.trace_schema import REGISTRY  # noqa: E402


ITERATION_ARC_EVENT_TYPES = (
    "transformation_proposed",
    "verify_attempt",
    "bridge_invariant_proposed",
    "iteration_verdict",
    "iteration_complete",
    "bridge_lean_closed",
)


def walk_strict(node: object) -> object:
    """Walk a JSON-schema tree, flipping additionalProperties to False
    on every object subschema. Idempotent.

    ATH-1083 Phase A: skip flipping when ``additionalProperties`` is
    already a non-bool schema. Pydantic's ``dict[str, T]`` emits the
    value-shape under ``additionalProperties``; nuking that to ``False``
    breaks the dict shape (claim "object with extra keys" is the same
    as "object that must be empty"). The flip only applies when the
    schema author hasn't already declared a value-shape.
    """
    if isinstance(node, dict):
        out = {k: walk_strict(v) for k, v in node.items()}
        if out.get("type") == "object" or "properties" in out:
            ap = out.get("additionalProperties")
            # Force-flip only when unset or explicitly True — preserve
            # value-shape schemas (dict[str, T]) and existing False.
            if ap is None or ap is True:
                out["additionalProperties"] = False
        return out
    if isinstance(node, list):
        return [walk_strict(x) for x in node]
    return node


def main() -> int:
    schemas_dir = REPO_ROOT / "schemas"
    schemas_dir.mkdir(exist_ok=True)

    for event_type in ITERATION_ARC_EVENT_TYPES:
        model = REGISTRY.get(("*", event_type))
        if model is None:
            print(f"ERROR: ('*', {event_type!r}) not in REGISTRY")
            return 1

        loose = model.model_json_schema()
        strict = walk_strict(model.model_json_schema())
        strict["title"] = strict.get("title", "") + " (strict)"
        strict["description"] = (
            f"STRICT variant of {event_type} schema. additionalProperties=false "
            "on every object subschema. Used by the cross-arm contract test to "
            "catch typo drift on either arm. The forward-compat variant at "
            f"{event_type}.schema.json keeps additionalProperties=true for "
            "forward-compat. See scripts/gen_iteration_arc_schemas.py."
        )

        loose_path = schemas_dir / f"{event_type}.schema.json"
        strict_path = schemas_dir / f"{event_type}.strict.schema.json"
        loose_path.write_text(json.dumps(loose, indent=2) + "\n")
        strict_path.write_text(json.dumps(strict, indent=2) + "\n")
        print(f"wrote {loose_path.relative_to(REPO_ROOT)}")
        print(f"wrote {strict_path.relative_to(REPO_ROOT)}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
