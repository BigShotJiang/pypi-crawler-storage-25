"""Athanor AI — Lean 4 proof verification as RL training signal."""
# ATH-837: free-tier-fence preservation in the package init.
#
# Pre-fix this file eagerly imported paid-tier modules
# (`kairos.fleet`, `kairos.prove`, `kairos.sorry_swarm`) at top
# level. Python loads `kairos/__init__.py` whenever ANY submodule is
# imported, so `import kairos.mcp` (free-tier surface) ended up
# pulling 8 paid modules into sys.modules at import time. The
# ATH-727 / ATH-829 architectural fence (paid features only imported
# inside function bodies after a license probe) was being silently
# defeated at the package-init layer.
#
# Fix: PEP 562 module-level `__getattr__` for paid re-exports.
# Free-tier surfaces stay eager (no leak — those modules don't
# import paid code transitively); paid surfaces resolve lazily on
# first attribute access. Customer code that types
# `kairos.Orchestrator(...)` / `kairos.prove(...)` /
# `kairos.SorrySwarmConfig(...)` continues to work unchanged.
#
# See `tests/test_mcp_paid_extensions.py
# ::test_kairos_mcp_import_does_not_pull_paid_modules` for the
# regression guard.

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

# ── Free-tier eager imports (no paid-module dependencies) ──────────
#
# These modules + their transitive imports do NOT pull `kairos.fleet`,
# `kairos.prove`, `kairos.sorry_swarm`, or `kairos.lean_cycle`. Verified
# 2026-04-28 via grep + the ATH-837 fence audit. If a future change
# adds a paid import to any of these, the fence audit catches it.
from kairos.env import Environment
from kairos.types import ScoreResult, TaskConfig
from kairos.lean import verify_proof, check_sorry, score_proof, ProofResult
# ATH-697 free-tier — template-driven flow: NL → Pythia template →
# Lean → verdict → NL. Lean stays hidden from the customer.
# ATH-678 (2026-04-27) renamed the original `simple_prove` to
# `simple_prove_template` so the more general single-LLM helper can
# live at the canonical name. Both are free; pick by use case.
from kairos.simple_prove_template import (
    NextAction,
    RefinementStep,
    SimpleProveResult,
    simple_prove_template,
)
# ATH-678 free-tier — single-LLM single-shot helper. Customer brings
# a Lean target_file with a sorry; one litellm.completion drafts the
# completion; verify_proof checks it. Returns the same ProveResult
# shape as the paid `kairos.prove`. Wrapped in kairos.observe() to
# satisfy the ATH-614 instrumentation gate without paid-gating.
from kairos.simple_prove import simple_prove
from kairos.observe import litellm_trace_session, observe
# ATH-599: post-decode helper for HF byte-level BPE edge cases (DeepSeek-Prover
# and similar where tokenizer.decode() returns the GPT-2 alphabet form, not
# UTF-8). Top-level re-export so consumers type `kairos.gpt2_bpe_to_utf8(s)`
# from the post-decode site without learning the submodule path.
from kairos.tokenizer import gpt2_bpe_to_utf8
# ATH-657 / 658: lean-machines × EBMC integration. Customer MVP. The
# module ships the vendored Apache-2.0 corpus + the to_sva() bridge
# (sub-a). `from kairos import lean_machines` works regardless; the
# explicit re-export of `to_sva` here keeps the headline API typeable
# at the top level (`kairos.to_sva(...)`) without a deep import.
from kairos import lean_machines
from kairos.lean_machines import SvaAssertion, to_sva
# ATH-1037: customer-onboarding programmatic surface — re-export the
# preflight helpers from kairos.doctor so customer code can call
# `kairos.help()` / `kairos.list_available_models()` from a notebook
# before any prove() call. CLI-equivalent: `python -m kairos doctor`.
from kairos.doctor import (
    AvailableModel,
    detect_routing_collisions,
    help,
    list_available_models,
)


# ── Paid-tier lazy imports (PEP 562) ───────────────────────────────
#
# Customers running ONLY free-tier surfaces (`kairos.mcp` server in
# free mode, `kairos.simple_prove`, `kairos.verify_proof`) never pay
# the cost of loading the paid module graph. Each entry below is
# resolved on first attribute access via `__getattr__` and cached on
# the module so subsequent accesses skip the lookup.
#
# Tier 1 customer-agent API + ATH-570 fleet orchestration are
# paid (require_product("solve")). The cto-handoff sorry_swarm
# config/result/factory dataclasses ship from kairos.sorry_swarm —
# importing the module itself pulls fleet + lean_cycle (its own
# top-level imports), so we lazy-load to keep the fence intact.

_LAZY_PAID: dict[str, tuple[str, str]] = {
    # Tier 1 — `kairos.{prove, session, ProveResult, Session}`.
    "prove":        ("kairos.prove", "prove"),
    "session":      ("kairos.prove", "session"),
    "ProveResult":  ("kairos.prove", "ProveResult"),
    "Session":      ("kairos.prove", "Session"),
    # ATH-570 fleet orchestration.
    "Orchestrator": ("kairos.fleet", "Orchestrator"),
    "orchestrate":  ("kairos.fleet", "orchestrate"),
    # cto-handoff 2026-04-27 sorry_swarm aux dataclasses + factory.
    # The function itself stays at `kairos.sorry_swarm.sorry_swarm`
    # (see comment block below) — these are config/result types
    # callers reference at the kairos namespace.
    "PYTHIA_DEFAULT_AXIOM_ALLOWLIST": (
        "kairos.sorry_swarm", "PYTHIA_DEFAULT_AXIOM_ALLOWLIST",
    ),
    "SorrySwarmConfig": ("kairos.sorry_swarm", "SorrySwarmConfig"),
    "SorrySwarmResult": ("kairos.sorry_swarm", "SorrySwarmResult"),
    "TargetOutcome":    ("kairos.sorry_swarm", "TargetOutcome"),
    "default_axiom_audit": (
        "kairos.sorry_swarm", "default_axiom_audit",
    ),
    # ATH-1132: customer plugin registration.
    "register_engine": (
        "kairos.sec.closed_loop.engine_registry", "register_engine",
    ),
}


def __getattr__(name: str):
    """PEP 562 module-level attribute lookup.

    Defers paid-tier imports until first access so the package init
    doesn't leak paid modules into sys.modules at load time. See the
    ATH-837 module docstring + the regression test.
    """
    if name in _LAZY_PAID:
        module_path, attr_name = _LAZY_PAID[name]
        module = importlib.import_module(module_path)
        value = getattr(module, attr_name)
        # Cache on this module so subsequent accesses skip __getattr__.
        globals()[name] = value
        return value
    raise AttributeError(
        f"module 'kairos' has no attribute {name!r}"
    )


def __dir__() -> list[str]:
    """Preserve tab-completion + `dir(kairos)` introspection.

    Without this, `dir(kairos)` would only list eagerly-bound names
    (the lazy paid surfaces wouldn't appear until first access).
    """
    return sorted(set(list(globals()) + list(_LAZY_PAID) + list(__all__)))


# ── Submodule-name-collision fix ───────────────────────────────────
#
# `kairos.prove` is BOTH a lazy paid attribute (the function) AND a
# submodule (kairos/prove.py). When customer code does
# `from kairos.prove import X` (the submodule path), Python registers
# `kairos.prove` as the submodule on the package — and PEP 562
# `__getattr__` does NOT fire when the attr is already in __dict__.
# Without this fix `kairos.prove` would silently switch from the
# function (after our lazy resolve) to the submodule (after the
# customer's submodule import), breaking the documented top-level
# API.
#
# Fix: swap the package's class to a subclass whose
# `__getattribute__` detects the collision (`name in _LAZY_PAID` AND
# the cached value is a ModuleType) and replaces the cached attr
# with the real function/class. Hot path is one dict lookup +
# isinstance check; the swap intercept is a no-op for every other
# attribute access.
import sys as _sys
import types as _types


class _KairosLazyModule(_types.ModuleType):
    def __getattribute__(self, name):
        val = super().__getattribute__(name)
        # Collision detection: name has a lazy-paid binding AND the
        # current attr is a submodule (means a `from kairos.X import`
        # registered the submodule, shadowing the function).
        if name in _LAZY_PAID and isinstance(val, _types.ModuleType):
            module_path, attr_name = _LAZY_PAID[name]
            real_value = getattr(val, attr_name)
            self.__dict__[name] = real_value
            return real_value
        return val


_sys.modules[__name__].__class__ = _KairosLazyModule


# Static-analyser visibility for the lazy paid surfaces. `mypy`,
# `pyright`, IDE autocomplete, and `from kairos import X` all see
# these as eagerly available; runtime uses __getattr__ above.
if TYPE_CHECKING:
    from kairos.fleet import Orchestrator, orchestrate  # noqa: F401
    from kairos.prove import (  # noqa: F401
        ProveResult,
        Session,
        prove,
        session,
    )
    from kairos.sorry_swarm import (  # noqa: F401
        PYTHIA_DEFAULT_AXIOM_ALLOWLIST,
        SorrySwarmConfig,
        SorrySwarmResult,
        TargetOutcome,
        default_axiom_audit,
    )


__version__ = "0.5.0"


def make(env_name: str, task: str | None = None, **kwargs) -> Environment:
    """Create an Athanor environment.

    Args:
        env_name: Environment image name (e.g. 'neuron-nki-kernels').
        task: Optional task ID to start with.
        **kwargs: Passed to Environment (image=, timeout=).

    Returns:
        Environment instance ready for reset()/score() calls.

    Tier classification: paid (requires the ``envs`` product —
    distinct from ``solve``). The :class:`Environment` constructor
    calls :func:`kairos.license_scope.require_env_access` and raises
    :class:`kairos.license_scope.LicenseScopeError` when the loaded
    license doesn't grant access to ``env_name``. Each environment
    is licensed individually; ``make("neuron-nki-kernels")`` and
    ``make("congestion-control")`` need separate ``envs[]`` claims.
    """
    return Environment(env_name, task=task, **kwargs)


__all__ = [
    "make", "Environment", "ScoreResult", "TaskConfig",
    "verify_proof", "check_sorry", "score_proof", "ProofResult",
    # Free-tier helpers (no license required).
    # ATH-678 single-LLM helper — customer brings target_file + hypothesis.
    "simple_prove",
    # ATH-697 template-driven helper — customer types English; Pythia
    # templates match. SimpleProveResult is template-flow specific.
    # NextAction (ATH-728 Phase 1) carries typed retry suggestions on
    # failed verdicts so an agent loop can drive refinement.
    # RefinementStep (ATH-728 Phase 2) records each iteration of the
    # opt-in BYO-LLM in-SDK refinement loop.
    "simple_prove_template", "SimpleProveResult",
    "NextAction", "RefinementStep",
    # Tier 1 API — customer agents call these directly.
    # ATH-837: lazy-resolved via __getattr__ to preserve the free-tier
    # fence (importing kairos.mcp must not pull kairos.prove).
    "prove", "session", "ProveResult", "Session",
    # Observability — capture raw litellm.completion() + native Anthropic
    # SDK calls outside kairos.prove()/session() into the TraceSink
    # pipeline. ``observe`` is the unified wrapper (ATH-524) and the
    # recommended entry; ``litellm_trace_session`` is the litellm-only
    # variant.
    "litellm_trace_session", "observe",
    # ATH-570 fleet orchestration — LLM-backed tier/worker planning.
    # ATH-837: lazy-resolved.
    "Orchestrator", "orchestrate",
    # ATH-599 tokenizer-side helper — HF byte-level BPE post-decode.
    "gpt2_bpe_to_utf8",
    # ATH-657 / 658 lean-machines × EBMC integration (customer MVP).
    "lean_machines", "to_sva", "SvaAssertion",
    # cto-handoff 2026-04-27 — generic batch sorry-closer. Caller
    # provides drafters; SDK ships zero defaults so internal +
    # customer use are exactly the same code path. The function
    # itself is at ``kairos.sorry_swarm.sorry_swarm`` (we don't
    # top-level-shadow the module name); these names are the
    # config + result dataclasses + audit factory.
    # ATH-837: lazy-resolved (kairos.sorry_swarm imports
    # kairos.fleet + kairos.lean_cycle at top level, so eager
    # re-export would leak both).
    "SorrySwarmConfig", "SorrySwarmResult",
    "TargetOutcome", "default_axiom_audit",
    "PYTHIA_DEFAULT_AXIOM_ALLOWLIST",
    "__version__",
]
