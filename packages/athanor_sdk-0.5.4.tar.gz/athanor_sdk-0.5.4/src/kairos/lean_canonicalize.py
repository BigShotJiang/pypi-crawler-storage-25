"""kairos.lean_canonicalize — single-source helper for Lean identifier safety.

ATH-963. Hoist of ``_canonicalize_lean_identifier`` originally introduced
in :mod:`kairos.security` (ATH-962) and copied verbatim into
:mod:`kairos.carbon_aware` (ATH-965) and :mod:`kairos.inference_serving`
(ATH-964). One canonical home prevents drift across verticals — when
the regex needs to evolve (e.g. for new customer-supplied identifier
shapes), it evolves in one place.

The original ASCII-only regex ``[^A-Za-z0-9_]`` stripped Lean-valid
Unicode (Greek letters, math operators commonly used in customer
specs: ε, λ, δ, π, σ, ...). This hoist also relaxes the regex to
preserve any Unicode word character (Python 3 ``\\w`` is Unicode-aware
for ``str`` patterns by default), so customer identifiers like
``ε_bound`` or ``λ_loss`` survive canonicalization with semantic
content intact.

Customers see legible diagnostics ("spec did not define
``ε_bound_property``") instead of mangled ones ("spec did not define
``__bound_property``").

Per ATH-961: dots, brackets, leading digits, and any character outside
the Unicode word class still get normalized so the generated Lean
theorem template never produces invalid syntax.

Cross-ref
---------
* :mod:`kairos.security` — pilot caller, migrated in ATH-963.
* :mod:`kairos.carbon_aware` — bulk-refactor target (post-pilot).
* :mod:`kairos.inference_serving` — bulk-refactor target (post-pilot).
* ``feedback_no_vacuous_proves_multi_layer.md`` — Layer 3 of the
  defense template (theorem template integrity); this helper is part
  of how Layer 3 stays robust against arbitrary customer input.
"""
from __future__ import annotations

import re

# Strip anything outside Unicode-aware [letter | digit | underscore].
# Python 3 str patterns are Unicode-aware by default; ``re.UNICODE``
# is included explicitly for documentation purposes — it does NOT
# change behavior on str patterns. Greek (α β γ ε λ π σ φ), Hebrew,
# Cyrillic, CJK, mathematical alphanumeric symbols, subscripts, and
# combining marks all survive; punctuation, whitespace, brackets,
# operators, and ASCII symbols become ``_``.
_LEAN_INVALID_CHAR_RE = re.compile(r"\W", re.UNICODE)


def canonicalize_lean_identifier(name: str) -> str:
    """Canonicalize ``name`` into a valid Lean 4 identifier.

    Replaces any non-(letter / digit / underscore) character with
    ``_``. Letters from any Unicode script are kept (Greek, Hebrew,
    Cyrillic, CJK, etc.) — Lean 4's identifier lexer accepts them, so
    no reason to strip them. If the result starts with a digit (which
    Lean rejects), prefixes with ``_``. Empty input becomes
    ``_unnamed`` so the generated theorem still parses, and the
    customer sees a clear "spec did not define ``_unnamed_property``"
    diagnostic instead of an opaque parse error.

    Examples
    --------
    >>> canonicalize_lean_identifier("constant_time_execution")
    'constant_time_execution'
    >>> canonicalize_lean_identifier("no-secret-leak")
    'no_secret_leak'
    >>> canonicalize_lean_identifier("eps_bound_0.5")
    'eps_bound_0_5'
    >>> canonicalize_lean_identifier("0day_leak")
    '_0day_leak'
    >>> canonicalize_lean_identifier("")
    '_unnamed'
    >>> canonicalize_lean_identifier("ε_bound")
    'ε_bound'
    >>> canonicalize_lean_identifier("λ.loss")
    'λ_loss'
    """
    cleaned = _LEAN_INVALID_CHAR_RE.sub("_", name)
    if not cleaned:
        return "_unnamed"
    if cleaned[0].isdigit():
        cleaned = "_" + cleaned
    return cleaned


__all__ = ["canonicalize_lean_identifier"]
