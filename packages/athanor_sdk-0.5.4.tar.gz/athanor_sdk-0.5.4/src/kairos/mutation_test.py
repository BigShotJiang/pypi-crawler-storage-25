"""kairos.mutation_test — mutation testing harness.

ATH-886: inject faults into a verified design, verify the proof/test
suite catches them. Generalizes the existing kairos.sv.mutations +
kairos.sv.invariants pattern to a top-level MCP tool.

Paid tier — uses LLM for mutant generation.

Usage::

    from kairos.mutation_test import mutation_test

    result = mutation_test(
        spec="cpu_equiv_wrapper.sv",
        test_suite=["assert_gpr_match"],
    )
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class Mutant:
    """A single mutation applied to the design."""
    id: int
    description: str
    location: str
    original: str
    mutated: str
    killed: bool = False
    killer: str | None = None


@dataclass
class MutationTestResult:
    """Result of mutation testing."""
    mutants: list[Mutant] = field(default_factory=list)
    total: int = 0
    killed: int = 0
    survived: int = 0
    kill_rate: float = 0.0
    elapsed_sec: float = 0.0
    verification_status: str = "machine_verified"

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "killed": self.killed,
            "survived": self.survived,
            "kill_rate": round(self.kill_rate, 3),
            "elapsed_sec": round(self.elapsed_sec, 2),
            "verification_status": self.verification_status,
            "surviving_mutants": [
                {"id": m.id, "description": m.description, "location": m.location}
                for m in self.mutants if not m.killed
            ],
        }


MutantGeneratorFn = Callable[[str], list[tuple[str, str, str]]]
MutantCheckerFn = Callable[[str, str], tuple[bool, str | None]]


def mutation_test(
    spec: str | Path,
    *,
    test_suite: list[str] | None = None,
    mutant_generator: MutantGeneratorFn | None = None,
    checker: MutantCheckerFn | None = None,
    max_mutants: int = 20,
) -> MutationTestResult:
    """Run mutation testing on a design.

    For each mutant:
    1. Apply mutation to the spec
    2. Run the test suite / proof
    3. If test passes on mutant → mutant survived (test gap)
    4. If test fails on mutant → mutant killed (test adequate)

    Args:
        spec: path to the spec/design file.
        test_suite: list of test/property names to check.
        mutant_generator: function that generates (location, original, mutated)
            tuples from spec text. Default: uses kairos.sv.mutations if available.
        checker: function that checks if a mutant is killed. Takes (spec_path,
            mutant_spec_text) and returns (killed, killer_name).
        max_mutants: cap on number of mutants to test.

    Returns:
        MutationTestResult with per-mutant kill status.
    """
    from kairos.observe import emit

    t0 = time.monotonic()
    result = MutationTestResult()

    spec_path = Path(spec)
    spec_text = spec_path.read_text()

    # Generate mutants
    if mutant_generator is not None:
        raw_mutants = mutant_generator(spec_text)[:max_mutants]
    else:
        try:
            from kairos.sv.mutations import enumerate_mutants
            sv_mutants = enumerate_mutants(spec_text)[:max_mutants]
            raw_mutants = [
                (f"line {m.line}", m.original, m.mutated)
                for m in sv_mutants
            ]
        except ImportError:
            raw_mutants = []

    # Build mutant objects
    for i, (loc, orig, mut) in enumerate(raw_mutants):
        result.mutants.append(Mutant(
            id=i, description=f"Mutate {orig} → {mut}",
            location=loc, original=orig, mutated=mut,
        ))

    # Check each mutant
    if checker is not None:
        for m in result.mutants:
            mutated_text = spec_text.replace(m.original, m.mutated, 1)
            killed, killer = checker(str(spec_path), mutated_text)
            m.killed = killed
            m.killer = killer

    result.total = len(result.mutants)
    result.killed = sum(1 for m in result.mutants if m.killed)
    result.survived = result.total - result.killed
    result.kill_rate = result.killed / result.total if result.total > 0 else 0.0
    result.elapsed_sec = time.monotonic() - t0

    emit("mutation_test_result", {
        "spec": str(spec_path),
        "total": result.total,
        "killed": result.killed,
        "survived": result.survived,
        "kill_rate": round(result.kill_rate, 3),
        "verification_status": result.verification_status,
    }, run_subtype="differential_test")

    return result
