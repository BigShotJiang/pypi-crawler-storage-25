"""kairos.flow_schema -- Pydantic-validated declarative flow configs.

ATH-912 Phase 1 foundation: cascades like ``_sv_prove_cascade`` /
``_lean_prove_cascade`` / ``_acl2_prove`` move from hardcoded Python to
versioned YAML files in ``src/kairos/flows/``. The router executes the
config; new cascades land via a YAML commit, not a Python edit.

Phase 1 scope (what this module covers):

* :class:`FlowConfig` -- top-level flow with ``name``, ``version``,
  ``defaults``, ``steps[]``.
* :class:`FlowStep` -- single step with ``kind`` + per-step ``params``.
* :func:`load_flow` -- read a YAML file from disk, validate, return a
  ``FlowConfig``. Filename must match ``{name}-v{version}.yaml`` so the
  registry walker can derive name + version without parsing.
* :func:`list_flows` -- walk ``src/kairos/flows/``, return all
  registered flows.
* :func:`emit_flow_config` -- emit the ``flow_config`` trace event at
  session open with the inline YAML payload (asabi 2026-05-01 ruling:
  inline-YAML over hash-reference for audit self-containedness).

Phase 2 (separate ticket): step-level typed I/O contracts, compose
primitives, ``on_fail`` step-reference. Phase 1 keeps the schema small
enough for the half-day prototype PR; cascades that need fallback today
abort and let the caller retry with a different flow.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator


# Filename convention: ``{slug}-v{semver}.yaml`` so the registry walker
# can derive name + version without parsing. Slug uses lowercase
# alphanumerics + hyphens; semver follows the standard MAJOR.MINOR.PATCH
# (no pre-release / build metadata in Phase 1).
_FILENAME_RE = re.compile(
    r"^(?P<name>[a-z0-9][a-z0-9\-]*)-v(?P<version>\d+\.\d+\.\d+)\.yaml$"
)
_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9\-]*$")
_VERSION_RE = re.compile(r"^\d+\.\d+\.\d+$")


class FlowStep(BaseModel):
    """A single step in a flow.

    ``kind`` names the step kind (e.g. ``ebmc_kinduction``,
    ``cegar_loop``, ``pythia_hammer``, ``acl2_fgl``); the router maps
    kinds to handlers. ``params`` carries step-specific parameters,
    merged with the flow's ``defaults`` at execution time (per-step
    overrides win).

    ``inputs`` is an optional list of input designators (file paths
    or symbolic refs) the step operates on.  Most current step kinds
    take a single target (resolved from the flow caller's target
    argument) and leave ``inputs`` empty; multi-input steps like the
    Phase 2 ``acl2_equivalence_check`` cascade declare two or more
    designs explicitly.  Forward-compat per asabi 2026-05-01 — adding
    the field now avoids a schema refactor when Phase 2 lands.
    """

    model_config = ConfigDict(extra="forbid")

    kind: str = Field(min_length=1)
    params: dict[str, Any] = Field(default_factory=dict)
    inputs: list[str] = Field(default_factory=list)

    @field_validator("kind")
    @classmethod
    def _kind_lower_alnum(cls, v: str) -> str:
        if not re.fullmatch(r"[a-z][a-z0-9_]*", v):
            raise ValueError(
                f"step kind must be lowercase snake_case alphanumeric, "
                f"got: {v!r}"
            )
        return v


class FlowConfig(BaseModel):
    """Top-level declarative flow.

    Loaded from ``src/kairos/flows/{name}-v{version}.yaml``. The router
    executes ``steps`` in order; each step gets its params merged with
    ``defaults`` (step's params win). Phase 1 has no ``on_fail`` --
    every step succeeds or aborts the flow.
    """

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    version: str = Field(min_length=1)
    description: str = ""
    defaults: dict[str, Any] = Field(default_factory=dict)
    steps: list[FlowStep] = Field(min_length=1)

    @field_validator("name")
    @classmethod
    def _name_format(cls, v: str) -> str:
        if not _NAME_RE.fullmatch(v):
            raise ValueError(
                f"flow name must be lowercase alphanumeric+hyphens, got: {v!r}"
            )
        return v

    @field_validator("version")
    @classmethod
    def _version_semver(cls, v: str) -> str:
        if not _VERSION_RE.fullmatch(v):
            raise ValueError(
                f"flow version must be MAJOR.MINOR.PATCH semver, got: {v!r}"
            )
        return v

    def merged_params(self, step_index: int) -> dict[str, Any]:
        """Return the effective parameter set for ``steps[step_index]``:
        flow ``defaults`` overlaid with the step's own ``params``."""
        if not 0 <= step_index < len(self.steps):
            raise IndexError(
                f"step_index {step_index} out of range for {len(self.steps)} steps"
            )
        merged = dict(self.defaults)
        merged.update(self.steps[step_index].params)
        return merged


class FlowLoadError(RuntimeError):
    """Raised when a YAML file fails parse / schema / filename validation."""


def _flows_dir() -> Path:
    """Locate ``src/kairos/flows/``. Returns the path even if absent so
    the caller can decide how to surface a missing-registry case."""
    return Path(__file__).resolve().parent / "flows"


def _parse_filename(filename: str) -> tuple[str, str]:
    """Extract ``(name, version)`` from a flow YAML filename.

    Raises :class:`FlowLoadError` if the filename does not match the
    convention.
    """
    m = _FILENAME_RE.match(filename)
    if not m:
        raise FlowLoadError(
            f"flow filename does not match {{name}}-v{{semver}}.yaml: {filename!r}"
        )
    return m.group("name"), m.group("version")


def load_flow(yaml_path: str | Path) -> FlowConfig:
    """Load a flow YAML, validate against :class:`FlowConfig`, and
    confirm the filename matches the embedded ``name`` + ``version``.

    Raises :class:`FlowLoadError` on any of: missing file, YAML parse
    error, schema violation, filename mismatch.
    """
    path = Path(yaml_path).resolve()
    if not path.is_file():
        raise FlowLoadError(f"flow file not found: {path}")

    try:
        import yaml
    except ImportError as e:
        raise FlowLoadError(
            "PyYAML required to load flows. Install: pip install pyyaml"
        ) from e

    try:
        raw = yaml.safe_load(path.read_text())
    except yaml.YAMLError as e:
        raise FlowLoadError(f"YAML parse error in {path}: {e}") from e

    if not isinstance(raw, dict):
        raise FlowLoadError(
            f"flow YAML root must be a mapping, got {type(raw).__name__}"
        )

    try:
        flow = FlowConfig.model_validate(raw)
    except ValidationError as e:
        raise FlowLoadError(f"flow schema violation in {path}:\n{e}") from e

    name, version = _parse_filename(path.name)
    if flow.name != name or flow.version != version:
        raise FlowLoadError(
            f"filename / content mismatch for {path}: "
            f"file says {name}-v{version}, "
            f"YAML says {flow.name}-v{flow.version}"
        )
    return flow


def list_flows(flows_dir: str | Path | None = None) -> list[FlowConfig]:
    """Walk ``flows_dir`` (default ``src/kairos/flows/``), return every
    valid :class:`FlowConfig` found. Files that fail validation raise --
    a registry with a malformed entry must not silently degrade."""
    base = Path(flows_dir) if flows_dir is not None else _flows_dir()
    if not base.is_dir():
        return []
    return [load_flow(p) for p in sorted(base.glob("*.yaml"))]


def emit_flow_config(
    flow: FlowConfig,
    *,
    run_subtype: str = "autoformalize",
) -> None:
    """Emit the ``flow_config`` trace event at session open.

    Per asabi 2026-05-01: inline-YAML in the event payload (full
    self-containedness) over hash-reference. ``run_subtype`` matches the
    cascade's own subtype so the analytics page groups naturally; the
    meta-query "all flow_config events" works on
    ``event_type='flow_config'`` regardless of subtype.
    """
    from kairos.observe import emit

    emit("flow_config", {
        "flow_name": flow.name,
        "flow_version": flow.version,
        "flow_description": flow.description,
        "flow_step_kinds": [s.kind for s in flow.steps],
        "flow_yaml_inline": flow.model_dump(),
        "step_count": len(flow.steps),
    }, run_subtype=run_subtype)
