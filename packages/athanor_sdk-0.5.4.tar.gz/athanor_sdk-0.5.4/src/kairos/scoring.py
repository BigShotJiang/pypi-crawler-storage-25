"""ATH-382 Cython shim for the scoring module.

Real implementation in `_scoring_impl.pyx`, compiled to
`_scoring_impl.cpython-*-x86_64-linux-gnu.so`. This shim re-exports
the public surface so existing callers (`env.py`, tests, customer
code) don't need to change imports.

See `docs/ath-382-cython-design.md` for the end-to-end rationale.

Build: `python3 build_cython.py` at the repo root.
"""
from __future__ import annotations

try:
    from kairos._scoring_impl import (  # type: ignore[import-not-found]
        _find_docker,
        score,
    )
except ImportError:
    # Dev fallback: compile _scoring_impl.pyx on-demand via pyximport.
    # Never fires in the shipped wheel (.pyx excluded; .so present).
    import pyximport  # type: ignore[import-not-found]
    pyximport.install(language_level=3)
    from kairos._scoring_impl import (  # type: ignore[import-not-found,no-redef]
        _find_docker,
        score,
    )


__all__ = ["score", "_find_docker"]
