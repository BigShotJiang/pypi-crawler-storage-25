"""ATH-358 / ATH-337 — SDK-side detection of local athanor-builder.

The SDK ships publicly; athanor-builder ships only to licensed
enterprise customers via signed tarball. Several SDK commands
(`athanor spec submit`, `athanor spec validate --stage B`) require
the builder to actually execute. This module is the runtime probe:
is the builder on this machine, and if not, what's the user-
actionable error?

The logic is SDK-only — the canonical builder never checks for its
own presence — so it lives outside the byte-mirrored spec_*.py
surface.

Detection priority:
    1. `$KAIROS_BUILDER_ROOT` (or `$ATHANOR_BUILDER_ROOT` legacy fallback)
       points at a directory → yes.
    2. `/opt/athanor/builder` directory exists (install.sh default) → yes.
    3. `mode_fleet` is on PATH (`shutil.which`) → yes.
    4. Otherwise → no.

Env-var dual-accept per ATH-407 layer 4: KAIROS_BUILDER_ROOT wins;
ATHANOR_BUILDER_ROOT honored as fallback with a one-time
DeprecationWarning. Customer migrates at their maintenance window.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from kairos.envvars import getenv_dual


def _has_builder() -> bool:
    """Return True if athanor-builder looks installed on this host."""
    root = getenv_dual("BUILDER_ROOT")
    if root and Path(root).is_dir():
        return True
    if Path("/opt/athanor/builder").is_dir():
        return True
    return shutil.which("mode_fleet") is not None


def builder_required_error() -> str:
    """User-facing error text when a command requires the builder."""
    return (
        "athanor-builder is required for this command but is not installed "
        "locally. Contact @athanor-ai to receive a licensed delivery "
        "(signed tarball or private GHCR credentials). See "
        "https://athanor-ai.com/contact for details."
    )


__all__ = ["_has_builder", "builder_required_error"]
