"""kairos.model_invariants — LLM model architectural invariant verifier.

ATH-958 (W2-W4 scaffold for ATH-950 v4 Bet H — research flagship for
NeurIPS 2026 "Formally verified attention" paper). Compose on existing
Pythia primitives (``Pythia.MatrixBernstein`` + ``Pythia.MatrixLieb`` +
``Pythia.MatchingConstants`` + ``Pythia.PhiTransform``) and
:func:`kairos.lean.verify_proof` to prove ML-architectural invariants:
attention permutation equivariance, LayerNorm scale-invariance,
RoPE compositional correctness, optimizer convergence.

Compounds with :mod:`kairos.quantization` (platform's lane) for the
W4-W6 Annapurna pitch claim:

  *"Your attention layer is invariant under quantization-bounded
  perturbation: equivariance proven structurally, bias bounded
  numerically."*

Architecture
------------
Same orchestrator shape as :mod:`kairos.silicon_review` (ATH-951): no
new verifier logic; thin compose-existing-primitives only. Customer
brings a Lean spec for their model architecture + a list of invariants
to prove; orchestrator dispatches each invariant to
:func:`kairos.lean.verify_proof` and aggregates.

The composite verdict requires ALL enumerated invariants to return
``proved`` — silent-success defense at the composite level (matches
ATH-947 + ATH-948 + ATH-949 + ATH-951 discipline).

Verdict precedence (top-to-bottom, fail-safe):

* Any invariant returns ``error`` → composite ``error``.
* Any invariant returns ``refuted`` → composite ``refuted``.
* Any invariant returns ``unknown`` → composite ``unknown``.
* All invariants return ``proved`` → composite ``proved``.

Trace emit
----------
``model_invariants_complete`` event registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Walker-visible emit. Composes with platform's Verification Coverage
card (zero net-new infra).

Cross-ref
---------
* :mod:`kairos.silicon_review` — orchestrator pattern reference (Bet E).
* :func:`kairos.lean.verify_proof` — per-invariant Lean proof checker.
* :mod:`kairos.lean_machines` — refinement chains for compositional
  invariants (LayerNorm, RoPE).
* :mod:`kairos.quantization` — platform's sibling vertical for Bet B
  (compounds for Annapurna pitch).
* Pythia primitives:
    * ``Pythia.MatrixBernstein`` — Tropp 2012, attention concentration.
    * ``Pythia.MatrixLieb`` — Lieb 1973, attention spectral bounds.
    * ``Pythia.MatchingConstants`` — sharp constants for ε-bounds.
    * ``Pythia.PhiTransform`` — softmax derivative bounds.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence


# Known invariant kinds. Customers can pass arbitrary strings; the
# orchestrator dispatches uniformly via verify_proof. This list is
# advisory + helps the Lean prover prompt the right tactic library.
KNOWN_INVARIANT_KINDS = (
    "permutation_equivariance",       # attention's output is permutation-equivariant in queries
    "layer_norm_scale_invariance",    # LayerNorm output is invariant to input scaling
    "rope_compositional",             # RoPE rotations compose correctly
    "optimizer_convergence",          # AdamW etc. converges under standard assumptions
    "softmax_normalization",          # softmax output sums to 1
    "attention_concentration",        # attention weights concentrate via Matrix Bernstein
)


@dataclass
class InvariantOutcome:
    """Per-invariant verdict + proof artifact."""

    invariant_name: str
    verdict: str
    """One of ``"proved" / "refuted" / "unknown" / "error"``."""

    proof_artifact_path: Path | None = None
    elapsed_sec: float = 0.0
    error_message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModelInvariantsResult:
    """Composite outcome from one model-invariants verification pass."""

    architecture: str
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    all_invariants_proven: bool
    """True iff every enumerated invariant returned ``proved``. THIS
    is the customer-facing claim Annapurna / NeurIPS reviewers
    care about — partial proofs are not enough."""

    invariant_outcomes: list[InvariantOutcome] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def proved_invariants(self) -> list[str]:
        """Names of invariants that returned ``proved``."""
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict == "proved"]

    @property
    def failed_invariants(self) -> list[str]:
        """Names of invariants that did NOT return ``proved``."""
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict != "proved"]


def _classify_composite(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[str, bool]:
    """Map per-invariant verdicts → (composite_verdict, all_proven).

    Precedence (silent-success defense): error > refuted > unknown >
    proved. ``all_proven`` is True iff every invariant returned
    ``proved``. An empty outcome list safe-defaults to error, NOT
    silent-proved (same defense as ATH-951 _classify_composite).
    """
    if not outcomes:
        return "error", False
    verdicts = [o.verdict for o in outcomes]
    if any(v == "error" for v in verdicts):
        return "error", False
    if any(v == "refuted" for v in verdicts):
        return "refuted", False
    if any(v == "unknown" for v in verdicts):
        return "unknown", False
    if all(v == "proved" for v in verdicts):
        return "proved", True
    # Mixed proved + something-else — should be caught by the
    # error/refuted/unknown branches above. If we reach here, an
    # unexpected verdict string was emitted by an invariant.
    return "error", False


def _build_invariant_theorem(
    invariant_name: str,
    architecture: str,
    spec_source: str,
) -> str:
    """Construct a Lean theorem statement for the named invariant.

    **Honest scaffold contract (ATH-958 review fix per asabi 2026-05-03).**

    The pre-fix template returned ``theorem foo_holds : True := trivial``,  # noqa: vacuous-proof-ok
    which compiled regardless of ``spec_source`` — score=1.0,
    axiom_clean=True, no sorry, no banned. The verdict mapping then
    returned ``proved`` for *every* invariant against *any* spec.
    Same silent-success class as ATH-948 reintroduced at the
    module-template boundary (orchestrator-level defenses don't
    catch it because per-invariant verdicts honestly returned
    "proved" for the tautology theorem).

    Fix: the generated theorem references identifiers the customer
    spec is required to define. Empty / missing / wrong-shaped spec
    → compile error → ``refuted`` (honest scaffold contract).

    Customer spec must define:

    * ``{invariant_name}_property : Prop`` — the property statement.
    * ``{invariant_name}_proof : {invariant_name}_property`` — the
      customer-supplied proof.

    The orchestrator's theorem then trivially closes via
    ``exact {invariant_name}_proof``, which type-checks only when
    both identifiers are defined. The architecture is stamped into
    the theorem name for traceability.

    For v0 the proof responsibility lives in the customer's spec,
    not the orchestrator. Future deepening (when asabi's
    autoformalization research lands W8-W12) lets the LLM author
    the property + proof from the architecture description; v0
    requires explicit spec.
    """
    safe_arch = architecture.replace("-", "_").replace(" ", "_")
    safe_inv = invariant_name.replace("-", "_").replace(" ", "_")
    return (
        f"{spec_source}\n\n"
        f"-- ATH-958 invariant: {invariant_name} for {architecture}.\n"
        f"-- Honest scaffold contract: the spec is required to define\n"
        f"--   {safe_inv}_property : Prop\n"
        f"--   {safe_inv}_proof : {safe_inv}_property\n"
        f"-- Empty / missing / wrong-shaped spec → compile error → refuted.\n"
        f"theorem {safe_inv}_verified_for_{safe_arch} : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def verify(
    architecture: str,
    *,
    invariants: Sequence[str],
    model_lean_spec: str | Path | None = None,
    workdir: str | Path,
    lake_project: str | Path | None = None,
    timeout_sec_per_invariant: int = 300,
    emit_trace: bool = True,
) -> ModelInvariantsResult:
    """Verify ML-architectural invariants against ``architecture``'s Lean spec.

    Args:
        architecture: human-readable architecture name (e.g.
            ``"transformer_block"``, ``"flash_attention_v2"``).
            Stamped into trace + result.
        invariants: list of invariant names to prove. Use values from
            :data:`KNOWN_INVARIANT_KINDS` for the most prompt-friendly
            tactic library; arbitrary strings work too (verify_proof
            dispatches uniformly).
        model_lean_spec: path to Lean source describing the
            architecture (``AttentionBlock.lean``, etc.). When None,
            invariants run against an empty spec — useful for testing
            the orchestrator's verdict aggregation but not the
            customer flow.
        workdir: scratch directory for per-invariant artifacts.
        lake_project: optional Lake project to verify against.
            ``None`` → use the verify_proof container path.
        timeout_sec_per_invariant: per-invariant Lean wall-clock.
        emit_trace: when True (default), emit
            ``model_invariants_complete`` on completion.

    Returns:
        :class:`ModelInvariantsResult`. Never raises for missing
        toolchain or per-invariant failure — those surface as
        ``composite_verdict='error'`` / per-invariant verdict.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not invariants:
        result = ModelInvariantsResult(
            architecture=architecture,
            composite_verdict="error",
            all_invariants_proven=False,
            invariant_outcomes=[],
            total_elapsed_sec=0.0,
            error_message="no invariants enumerated — review() requires ≥1",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    spec_source = ""
    if model_lean_spec is not None:
        spec_path = Path(model_lean_spec).resolve()
        if not spec_path.exists():
            return ModelInvariantsResult(
                architecture=architecture,
                composite_verdict="error",
                all_invariants_proven=False,
                error_message=f"model_lean_spec does not exist: {spec_path}",
            )
        spec_source = spec_path.read_text()

    t0 = time.monotonic()
    outcomes: list[InvariantOutcome] = []

    # Defer import so the module imports cleanly even on minimal
    # toolchain (matches kairos.silicon_review pattern).
    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001 — broad: kairos.lean import surface
        result = ModelInvariantsResult(
            architecture=architecture,
            composite_verdict="error",
            all_invariants_proven=False,
            error_message=f"kairos.lean unavailable: {e}",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    for inv_name in invariants:
        inv_t0 = time.monotonic()
        theorem_source = _build_invariant_theorem(
            invariant_name=inv_name,
            architecture=architecture,
            spec_source=spec_source,
        )
        try:
            proof_result = verify_proof(
                theorem_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_invariant,
            )
        except Exception as e:  # noqa: BLE001 — verify_proof surface is broad
            outcomes.append(InvariantOutcome(
                invariant_name=inv_name,
                verdict="error",
                elapsed_sec=round(time.monotonic() - inv_t0, 3),
                error_message=f"verify_proof raised: {e}",
            ))
            continue

        # Verdict mapping (matches ATH-948 ProofResult.status precedence):
        # banned > axiom_leak > full_proof > partial_proof > compile_error.
        # Map to invariant-level proved / refuted / unknown / error.
        if not proof_result.compiles:
            verdict = "refuted"
            err = (
                (proof_result.errors or [""])[0][:200]
                if proof_result.errors
                else "lean compile error"
            )
        elif proof_result.has_sorry:
            verdict = "refuted"
            err = "proof has sorry — incomplete"
        elif proof_result.banned:
            verdict = "refuted"
            err = f"banned construct: {proof_result.banned}"
        elif proof_result.axiom_clean is False:
            # ATH-948 silent-success defense: forbidden-axiom leak →
            # refuted, not silent error.
            verdict = "refuted"
            err = (
                f"axiom leak: {list(proof_result.forbidden_axioms or [])[:3]}"
            )
        elif proof_result.score >= 1.0:
            verdict = "proved"
            err = None
        else:
            verdict = "error"
            err = (
                f"unexpected ProofResult shape: compiles=True, no sorry, "
                f"no banned, axiom_clean!=False, score={proof_result.score}"
            )

        outcomes.append(InvariantOutcome(
            invariant_name=inv_name,
            verdict=verdict,
            elapsed_sec=round(time.monotonic() - inv_t0, 3),
            error_message=err,
            details={
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "score": proof_result.score,
                "axiom_clean": proof_result.axiom_clean,
            },
        ))

    composite_verdict, all_proven = _classify_composite(outcomes)
    total_elapsed = round(time.monotonic() - t0, 3)

    result = ModelInvariantsResult(
        architecture=architecture,
        composite_verdict=composite_verdict,
        all_invariants_proven=all_proven,
        invariant_outcomes=outcomes,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        _emit_complete(result)

    return result


def _emit_complete(result: ModelInvariantsResult) -> None:
    """Best-effort trace emit. Never raises — same TraceSink contract
    as :func:`kairos.silicon_review.review`."""
    try:
        from kairos.observe import emit
        emit(
            "model_invariants_complete",
            {
                "architecture": result.architecture,
                "composite_verdict": result.composite_verdict,
                "all_invariants_proven": result.all_invariants_proven,
                "invariants_proved": result.proved_invariants,
                "invariants_failed": result.failed_invariants,
                "total_elapsed_sec": result.total_elapsed_sec,
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break verify()
        pass


__all__ = [
    "InvariantOutcome",
    "ModelInvariantsResult",
    "KNOWN_INVARIANT_KINDS",
    "verify",
]
