"""Single source of truth for model identifiers used by the SDK.

Aidan 2026-04-28 (#dev-sdk 01:09Z) directive: **never hardcode models
in primitive logic; always flag-driven.** The internal "known good"
combo (Goedel-V2-Q6_K + Gemini 3 Flash + Sonnet-4-6) lives here as a
named preset internal scripts can opt into; customers ignore it and
pass their own model strings.

Two surfaces:

#. **Named presets** — model lists internal scripts compose with.
   Customers don't import these; they pass their own model strings
   directly to the primitives.
#. **Default constants** — the literal a primitive uses when the
   caller passes no model. Lifted out of inline `\"claude-...\"`
   strings inside other modules so the values can drift here without
   touching primitive code, and so the no-hardcode CI lint can pass
   the rest of the SDK without false-positives.

Adding a new preset / default: append below + add a test in
``tests/test_model_presets.py`` pinning the entry. CI will fail any
PR that introduces a new model literal in `src/kairos/**/*.py`
outside this module (see ``tools/check_no_hardcoded_models.py``).
"""
from __future__ import annotations

from typing import Final

# ─── Internal "known good" combos ─────────────────────────────────────
#
# These are the combinations our internal experiments converged on for
# Lean / theorem-proving dogfood (Pythia sweep, etc.). They're NOT
# customer recommendations — customers run the SDK with their own
# preferred model loadouts. The combo is documented here so internal
# scripts (research's swarm_pythia.py, qa's smoke harnesses) compose
# against a single named source rather than re-deriving the list.

#: Internal Pythia sweep — Goedel for cheap autocomplete, Gemini 3
#: Flash for first-pass fanout, Sonnet 4-6 for refinement. Validated
#: 2026-04-27 in the post-PR-#293 compose-test.
PRESET_INTERNAL_PYTHIA: Final[tuple[str, ...]] = (
    "goedel-v2-q6_k",
    "gemini/gemini-3-flash-preview",
    "anthropic/claude-sonnet-4-6",
)

# ─── Customer convenience presets ─────────────────────────────────────
#
# Single-model loadouts that match how most paid customers actually
# run today (per Aidan 2026-04-28: "customers will likely just use
# opus4.6 or 4.7 for everything"). Customers can ignore these and
# pass their own model lists; they're here for the documentation /
# discovery value.

PRESET_CUSTOMER_OPUS_4_6: Final[tuple[str, ...]] = (
    "anthropic/claude-opus-4-6",
)

PRESET_CUSTOMER_OPUS_4_7: Final[tuple[str, ...]] = (
    "anthropic/claude-opus-4-7",
)

PRESET_CUSTOMER_SONNET_4_6: Final[tuple[str, ...]] = (
    "anthropic/claude-sonnet-4-6",
)

# ─── Default-model constants (single source of truth) ─────────────────
#
# These are the values primitive code uses when the caller passes no
# model. Pulled out of inline literals so:
#   - the default can drift without touching primitive logic
#   - the no-hardcode CI lint can scan `src/kairos/**/*.py` and only
#     flag NEW literals (these constants are the only allowed sites)
#   - the value is reviewable in one place

#: Default for free-tier ``kairos.simple_prove`` — cheap, fast,
#: customer-friendly. Migrated 2026-04-28 from the inline literal in
#: ``simple_prove.DEFAULT_MODEL``.
DEFAULT_SIMPLE_PROVE_MODEL: Final[str] = "anthropic/claude-haiku-4-5"

#: Default for the runner's `solve` job loop. Used when the caller's
#: ``task_config["model"]`` is unset. Migrated 2026-04-28 from the
#: 5 inline literals in ``runner.py``.
DEFAULT_RUNNER_MODEL: Final[str] = "anthropic/claude-opus-4-6"

#: Default model used by ``runner._call_anthropic`` for the
#: spec-generation phase. Spec generation needs the deepest reasoning;
#: Opus is canonical here. Migrated 2026-04-28 from the 3 inline
#: ``"claude-opus-4-6"`` literals in the spec-generation phase calls.
DEFAULT_SPEC_GENERATION_MODEL: Final[str] = "claude-opus-4-6"

#: Final-iteration escalation target for ``generator_synthesize`` when
#: ``escalate_opus=True``. The escalation POLICY (when to escalate)
#: stays in ``generator_synthesize.py`` — it's primitive logic, not a
#: model selection. The model STRING moves here so the literal isn't
#: baked into the branch.
ESCALATION_OPUS: Final[str] = "anthropic/claude-opus-4-7"

#: Final-iteration escalation target for ``generator_synthesize`` when
#: ``escalate_opus=False``. See ``ESCALATION_OPUS`` for the rationale
#: on policy-vs-model-string split.
ESCALATION_SONNET: Final[str] = "anthropic/claude-sonnet-4-6"

# ── Phase 2 (ATH-816) — additional default constants ──────────────────

#: Default first-pass model for ``kairos.generator_synthesize``.
#: Cheap-reasoning baseline; Anthropic escalation kicks in on the
#: final iteration via the ESCALATION_* constants above. Uses
#: haiku-4-5 as a universally available default (the internal fleet
#: overrides to kimi-k2.6 via task config when available).
DEFAULT_GENERATOR_MODEL: Final[str] = "anthropic/claude-haiku-4-5"

#: Default for ``kairos.fleet.orchestrator.DEFAULT_PLANNER_MODEL``.
#: The orchestrator's tier-planner needs deep reasoning; Opus is
#: canonical. Migrated 2026-04-28 from the inline literal at
#: ``fleet/orchestrator.py:50``.
DEFAULT_PLANNER_MODEL: Final[str] = "anthropic/claude-opus-4-6"

#: Default ``ProveSpec.drafter_model`` — the LLM that drafts proof
#: candidates per round in the paid prove pipeline. Sonnet picked
#: for cost-vs-quality balance; reviewer (below) does the deeper
#: cross-check. Migrated 2026-04-28 from ``spec/types.py:392``.
DEFAULT_PROVE_DRAFTER_MODEL: Final[str] = "anthropic/claude-sonnet-4-6"

#: Default ``ProveSpec.reviewer_model`` — Opus for the reviewer pass.
#: Migrated 2026-04-28 from ``spec/types.py:393``.
DEFAULT_PROVE_REVIEWER_MODEL: Final[str] = "anthropic/claude-opus-4-6"

#: Default primary model for ``kairos.spec.health_check.health_check``.
#: Sonnet drives the primary semantic-coherence pass; Kimi (below) is
#: the secondary cross-check at ~10× lower cost. Migrated 2026-04-28
#: from ``spec/health_check.py:189``.
DEFAULT_HEALTH_CHECK_PRIMARY_MODEL: Final[str] = "anthropic/claude-sonnet-4-6"

#: Default secondary model for ``health_check``. Migrated 2026-04-28
#: from ``spec/health_check.py:190``.
DEFAULT_HEALTH_CHECK_SECONDARY_MODEL: Final[str] = "openai/kimi-k2.5"

#: Default proposer model for ``kairos.sv.invariants.make_proposer``.
#: Sonnet is the cost-vs-quality sweet spot for invariant generation
#: (validated under ATH-399). Migrated 2026-04-28 from
#: ``sv/invariants.py:202``.
DEFAULT_INVARIANT_PROPOSER_MODEL: Final[str] = "anthropic/claude-sonnet-4-6"

#: Default model declared in the MCP server's `default_model` JSON
#: schema field. Migrated 2026-04-28 from ``mcp/schemas.py:43``.
DEFAULT_MCP_MODEL: Final[str] = "claude-haiku-4-5"


def resolve_models(name_or_list: str | list[str] | tuple[str, ...]) -> list[str]:
    """Normalize a preset name OR a model string OR a list to a list.

    Convenience for callers that want to accept "give me a preset name
    or a list, I don't care which" and get a uniform list out.

    Args:
        name_or_list: one of:
            - preset name like ``"INTERNAL_PYTHIA"`` (case-insensitive,
              optional ``PRESET_`` prefix) → returns the matching tuple
              as a list.
            - model string like ``"anthropic/claude-opus-4-6"`` →
              returns ``[that_string]``.
            - list/tuple of model strings → returns ``list(input)``.

    Raises:
        ValueError: when ``name_or_list`` is a string that doesn't
            match any preset AND doesn't look like a model identifier
            (no ``/`` separator and no recognized prefix). Returning
            ``[the_string]`` would silently let typo'd preset names
            through; better to fail loudly.
    """
    if isinstance(name_or_list, (list, tuple)):
        return list(name_or_list)
    if not isinstance(name_or_list, str):
        raise TypeError(
            f"resolve_models: expected str / list / tuple, got "
            f"{type(name_or_list).__name__}"
        )
    s = name_or_list.strip()
    # Try preset name lookup first (case-insensitive, with or without
    # PRESET_ prefix).
    upper = s.upper()
    for prefix in ("PRESET_", ""):
        key = prefix + upper if not upper.startswith("PRESET_") else upper
        preset = globals().get(key)
        if isinstance(preset, tuple) and key.startswith("PRESET_"):
            return list(preset)
    # Looks like a model identifier? Accept anything containing `/`
    # (provider-prefixed) or a known bare-name prefix that the SDK
    # recognizes elsewhere (claude-*, kimi-*, goedel-*).
    if (
        "/" in s
        or s.startswith(("claude-", "kimi-", "goedel-", "gemini-"))
    ):
        return [s]
    raise ValueError(
        f"resolve_models: {name_or_list!r} doesn't match any PRESET_* "
        f"and doesn't look like a model identifier. Pass a preset name "
        f"(e.g. 'INTERNAL_PYTHIA') or a model string with a provider "
        f"prefix (e.g. 'anthropic/claude-opus-4-6')."
    )


__all__ = [
    # Presets
    "PRESET_INTERNAL_PYTHIA",
    "PRESET_CUSTOMER_OPUS_4_6",
    "PRESET_CUSTOMER_OPUS_4_7",
    "PRESET_CUSTOMER_SONNET_4_6",
    # Defaults — phase 1
    "DEFAULT_SIMPLE_PROVE_MODEL",
    "DEFAULT_RUNNER_MODEL",
    "DEFAULT_SPEC_GENERATION_MODEL",
    "ESCALATION_OPUS",
    "ESCALATION_SONNET",
    # Defaults — phase 2 (ATH-816)
    "DEFAULT_GENERATOR_MODEL",
    "DEFAULT_PLANNER_MODEL",
    "DEFAULT_PROVE_DRAFTER_MODEL",
    "DEFAULT_PROVE_REVIEWER_MODEL",
    "DEFAULT_HEALTH_CHECK_PRIMARY_MODEL",
    "DEFAULT_HEALTH_CHECK_SECONDARY_MODEL",
    "DEFAULT_INVARIANT_PROPOSER_MODEL",
    "DEFAULT_MCP_MODEL",
    # Resolver
    "resolve_models",
]
