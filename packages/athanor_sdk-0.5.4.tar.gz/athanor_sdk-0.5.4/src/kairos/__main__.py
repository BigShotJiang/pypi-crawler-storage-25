"""Allow `python -m kairos` to invoke the CLI."""
from kairos.cli import main

main()
