"""kairos.flow_contracts -- typed step I/O contracts (ATH-914).

Phase 2 foundation for ATH-912.  Each step kind declares Pydantic
``InputModel`` and ``OutputModel`` shapes; the cascade dispatcher
pre-flight-validates that consecutive steps' shapes are compatible
before invoking any handler.

Compatibility rule
==================

Step A's output is compatible with step B's input iff every required
field of ``B.InputModel`` is present in ``A.OutputModel`` with a
type-compatible annotation.  Extra fields in the output are tolerated
(B simply ignores them).

Type-compatibility (Phase 2 v1):

* Same annotation type ``T`` -> compatible.
* ``T`` -> ``Optional[T]`` -> compatible (Optional accepts non-None).
* ``Optional[T]`` -> ``T`` -> NOT compatible (output may be None;
  required input cannot accept None).
* Different non-overlapping types -> NOT compatible.

Phase 2 stretch goals (separate tickets): structural subtyping (e.g.
``BaseModel`` subclass relationships), variance over generic
parameters.  Today's checker is conservative-by-design: false negatives
(rejecting some fine compositions) are acceptable; false positives
(accepting unsound compositions) are not.

Verification of the checker itself
==================================

Per Aidan 2026-05-01: apply tests + PBT + SMT + Lean to ensure quality
of our own code.  This module ships with hypothesis-style PBT in
``tests/test_flow_contracts.py`` that generates random Pydantic model
pairs (subset / superset / disjoint / partially overlapping) and
asserts the checker's verdict matches a hand-derived ground truth.

A Lean refinement-of-checker proof is the natural follow-up via the
LeanMachines surface but is deferred to a separate scoping round.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional, Union, get_args, get_origin

from pydantic import BaseModel


@dataclass(frozen=True)
class StepContract:
    """Declared input + output shapes for a step kind.

    ``input_model``: required + optional fields the step expects in
    its ``**ctx`` keyword arguments.

    ``output_model``: fields the step writes back into ctx (or returns
    via the cascade dispatcher's update merge).
    """

    kind: str
    input_model: type[BaseModel]
    output_model: type[BaseModel]


_REGISTRY: dict[str, StepContract] = {}


def register_step_contract(kind: str) -> Callable[[type], type]:
    """Decorator: register a class as the contract for ``kind``.

    The decorated class must define two inner classes ``InputModel``
    and ``OutputModel``, each a Pydantic ``BaseModel`` subclass.

    Example::

        @register_step_contract("ebmc_bmc")
        class EbmcBmcContract:
            class InputModel(BaseModel):
                all_files: list[str]
                top_module: str
                bound: int = 10
            class OutputModel(BaseModel):
                bmc_result: Any
                verification_status: str = "unverified"
    """

    def _wrap(cls: type) -> type:
        if not hasattr(cls, "InputModel") or not hasattr(cls, "OutputModel"):
            raise TypeError(
                f"step contract {kind!r} must declare InputModel + "
                f"OutputModel as inner classes"
            )
        if not (isinstance(cls.InputModel, type)
                and issubclass(cls.InputModel, BaseModel)):
            raise TypeError(
                f"step contract {kind!r} InputModel must subclass BaseModel"
            )
        if not (isinstance(cls.OutputModel, type)
                and issubclass(cls.OutputModel, BaseModel)):
            raise TypeError(
                f"step contract {kind!r} OutputModel must subclass BaseModel"
            )
        if kind in _REGISTRY:
            raise ValueError(
                f"step contract for kind {kind!r} already registered"
            )
        _REGISTRY[kind] = StepContract(
            kind=kind,
            input_model=cls.InputModel,
            output_model=cls.OutputModel,
        )
        return cls

    return _wrap


def get_step_contract(kind: str) -> StepContract | None:
    """Return the registered contract for ``kind`` or None if unregistered."""
    return _REGISTRY.get(kind)


def list_step_contracts() -> list[StepContract]:
    """Return all registered contracts (sorted by kind for stability)."""
    return [_REGISTRY[k] for k in sorted(_REGISTRY)]


# ── Compatibility checking ───────────────────────────────────────────


@dataclass(frozen=True)
class CompatibilityResult:
    """Outcome of checking step A's OutputModel against step B's InputModel."""

    compatible: bool
    missing_fields: tuple[str, ...] = ()
    type_mismatches: tuple[tuple[str, str, str], ...] = ()  # (field, A_type, B_type)

    @property
    def reason(self) -> str:
        parts = []
        if self.missing_fields:
            parts.append(
                f"missing fields in upstream output: "
                f"{', '.join(self.missing_fields)}"
            )
        if self.type_mismatches:
            for field, a_t, b_t in self.type_mismatches:
                parts.append(
                    f"field {field!r} has incompatible types: "
                    f"output={a_t} vs input={b_t}"
                )
        return "; ".join(parts) if parts else "compatible"


def _is_optional_of(annotation: Any, inner: Any) -> bool:
    """True if ``annotation`` is ``Optional[inner]`` (i.e. ``Union[inner, None]``)."""
    origin = get_origin(annotation)
    if origin is Union:
        args = get_args(annotation)
        return type(None) in args and inner in args
    return False


def _types_compatible(output_type: Any, input_type: Any) -> bool:
    """True iff a value of ``output_type`` can flow into a slot
    requiring ``input_type``.

    Conservative rules (Phase 2 v1).  See module docstring.
    """
    if output_type == input_type:
        return True
    # T -> Optional[T] is fine (the Optional just adds None as an
    # accepted value).
    if _is_optional_of(input_type, output_type):
        return True
    # Optional[T] -> T is NOT fine (output may be None; required slot
    # cannot accept None).
    if _is_optional_of(output_type, input_type):
        return False
    # Conservative: different annotations are incompatible unless
    # explicitly handled above.
    return False


def check_compatibility(
    upstream_output: type[BaseModel],
    downstream_input: type[BaseModel],
) -> CompatibilityResult:
    """Check that ``upstream_output`` can flow into ``downstream_input``.

    Compatible iff every REQUIRED field of ``downstream_input`` exists
    in ``upstream_output`` with a type-compatible annotation.  Optional
    downstream fields are not required to be present upstream.
    """
    missing: list[str] = []
    mismatches: list[tuple[str, str, str]] = []

    out_fields = upstream_output.model_fields
    in_fields = downstream_input.model_fields

    for field_name, info in in_fields.items():
        if not info.is_required():
            continue  # Optional in the input -> upstream needn't supply.
        if field_name not in out_fields:
            missing.append(field_name)
            continue
        out_type = out_fields[field_name].annotation
        in_type = info.annotation
        if not _types_compatible(out_type, in_type):
            mismatches.append((
                field_name, repr(out_type), repr(in_type),
            ))

    compatible = not missing and not mismatches
    return CompatibilityResult(
        compatible=compatible,
        missing_fields=tuple(missing),
        type_mismatches=tuple(mismatches),
    )


# ── Flow-level validation ────────────────────────────────────────────


@dataclass(frozen=True)
class FlowValidationResult:
    """Outcome of pre-flight-validating an entire flow."""

    valid: bool
    pair_violations: tuple[tuple[str, str, CompatibilityResult], ...] = ()
    unknown_kinds: tuple[str, ...] = ()

    @property
    def violation_count(self) -> int:
        return len(self.pair_violations) + len(self.unknown_kinds)


def validate_flow_contracts(
    step_kinds: list[str],
    *,
    cascade_entry_fields: dict[str, Any] | None = None,
    require_all_registered: bool = False,
) -> FlowValidationResult:
    """Walk a flow's step kinds in order and check that each step's
    required input fields are satisfiable from the cascade's accumulated
    namespace.

    The cascade dispatcher in :mod:`kairos.router` doesn't pipe outputs
    one-to-one between adjacent steps; it merges every step's update
    into a shared ctx dict.  Required input fields therefore must be
    satisfied by EITHER:

    * The cascade-entry context (the kwargs the cascade itself
      populates: ``target_path``, ``top_module``, ``timeout_sec``, ...)
    * OR any prior step's ``OutputModel``.

    Args:
        step_kinds: kinds in execution order, as the cascade dispatcher
            iterates them.
        cascade_entry_fields: ``{field_name: type_annotation}`` mapping
            for the cascade-entry context.  If None, defaults to the
            union of ALL registered step contracts' input fields with
            defaults — i.e. assume the cascade entry provides any
            commonly-needed field.  Override for stricter validation.
        require_all_registered: when True, any step kind not in the
            registry is reported as an ``unknown_kinds`` violation.
            When False (default for backward-compat with Phase 1), an
            unregistered step is silently skipped — it cannot violate
            a contract it doesn't have.

    Returns:
        :class:`FlowValidationResult` with per-step violations + any
        unknown-kind reports.  A pair_violations entry's ``upstream``
        field reads ``"<entry-or-prior>"`` since the missing field
        could come from any upstream source.
    """
    pair_violations: list[tuple[str, str, CompatibilityResult]] = []
    unknown_kinds: list[str] = []

    if cascade_entry_fields is None:
        # Default: the canonical fields the kairos.router cascades
        # populate at entry.  Hardcoded rather than auto-populated
        # from contract input models because doing the latter creates
        # a circular satisfiability loop (a sabotaged contract that
        # requires a fresh unsatisfiable field would auto-satisfy
        # itself by adding the field to cascade_entry_fields via the
        # registry walk).  This list mirrors what the SV / ACL2 / Lean
        # cascade entry blocks in src/kairos/router.py actually pass.
        cascade_entry_fields = {
            "target_path": Any,
            "target": Any,
            "source_files": list[str],
            "top_module": str,
            "all_files": list[str],
            "source": str,
            "lake_project": Optional[str],
            "goal_class": str,
            "registry": list[Any],
            "timeout_sec": int,
            "flatten": bool,
            "reset_expr": Optional[str],
            "extra_args": Optional[list[str]],
            "acl2_script": Optional[str],
            "verification_status": str,
        }

    # Track the running namespace of (field -> annotation).  Starts
    # with the cascade-entry context; each step's outputs add / replace.
    namespace: dict[str, Any] = dict(cascade_entry_fields)

    for kind in step_kinds:
        contract = _REGISTRY.get(kind)
        if contract is None:
            if require_all_registered:
                unknown_kinds.append(kind)
            continue

        missing: list[str] = []
        mismatches: list[tuple[str, str, str]] = []
        for fname, finfo in contract.input_model.model_fields.items():
            if not finfo.is_required():
                continue
            if fname not in namespace:
                missing.append(fname)
                continue
            if not _types_compatible(namespace[fname], finfo.annotation):
                mismatches.append((
                    fname, repr(namespace[fname]), repr(finfo.annotation),
                ))

        if missing or mismatches:
            pair_violations.append((
                "<entry-or-prior>", kind,
                CompatibilityResult(
                    compatible=False,
                    missing_fields=tuple(missing),
                    type_mismatches=tuple(mismatches),
                ),
            ))

        # Step's outputs join the namespace.  Override any prior
        # field of the same name (later wins).
        for fname, finfo in contract.output_model.model_fields.items():
            namespace[fname] = finfo.annotation

    valid = not pair_violations and not unknown_kinds
    return FlowValidationResult(
        valid=valid,
        pair_violations=tuple(pair_violations),
        unknown_kinds=tuple(unknown_kinds),
    )


def emit_flow_contract_violation(
    flow_name: str,
    flow_version: str,
    result: FlowValidationResult,
    *,
    run_subtype: str = "autoformalize",
) -> None:
    """Emit ``flow_contract_violation`` trace event when validation
    fails.  Caller decides whether to abort the cascade or warn-and-
    continue based on the result."""
    from kairos.observe import emit

    emit("flow_contract_violation", {
        "flow_name": flow_name,
        "flow_version": flow_version,
        "violation_count": result.violation_count,
        "pair_violations": [
            {"upstream": a, "downstream": b, "reason": r.reason}
            for a, b, r in result.pair_violations
        ],
        "unknown_kinds": list(result.unknown_kinds),
    }, run_subtype=run_subtype)


# ── Built-in contracts for existing step kinds ──────────────────────
#
# Phase 1.1 / 1.2 step kinds get explicit contracts here so the cascade
# dispatcher can pre-flight-validate.  Field shapes derived from the
# handler bodies in src/kairos/router.py.


@register_step_contract("sv_flatten")
class _SvFlattenContract:
    class InputModel(BaseModel):
        all_files: list[str]

    class OutputModel(BaseModel):
        all_files: list[str]


@register_step_contract("ebmc_bmc")
class _EbmcBmcContract:
    class InputModel(BaseModel):
        all_files: list[str]
        top_module: str
        timeout_sec: int = 300
        bounds: list[int] | None = None
        reset_expr: str | None = None
        extra_args: list[str] | None = None
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        bmc_result: Any = None
        verification_status: str = "unverified"
        engine_used: str | None = None


@register_step_contract("ebmc_kinduction")
class _EbmcKinductionContract:
    class InputModel(BaseModel):
        all_files: list[str]
        top_module: str
        timeout_sec: int = 300
        k_max: int = 10
        reset_expr: str | None = None
        extra_args: list[str] | None = None
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        kind_result: Any = None
        verification_status: str = "unverified"
        engine_used: str | None = None


@register_step_contract("cegar_loop")
class _CegarLoopContract:
    class InputModel(BaseModel):
        all_files: list[str]
        top_module: str
        timeout_sec: int = 300
        max_iter: int = 5
        bound: int = 10
        reset_expr: str | None = None
        extra_args: list[str] | None = None
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        cegar_result: Any = None
        verification_status: str = "unverified"
        engine_used: str | None = None


@register_step_contract("acl2_fgl_refinement")
class _Acl2FglRefinementContract:
    class InputModel(BaseModel):
        all_files: list[str]
        top_module: str
        timeout_sec: int = 1200
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        fgl_result: Any = None
        verification_status: str = "unverified"
        engine_used: str | None = None


@register_step_contract("sv_orchestrate")
class _SvOrchestrateContract:
    """v1.0.0 fallback opaque-mode handler — single-step cascade."""

    class InputModel(BaseModel):
        target_path: Any
        top_module: str
        source_files: list[str] | None = None
        flatten: bool = True
        reset_expr: str | None = None
        extra_args: list[str] | None = None
        acl2_script: str | None = None
        timeout_sec: int = 300

    class OutputModel(BaseModel):
        # Returned directly to the cascade body, not a ctx update.
        all_proved: bool = False


@register_step_contract("acl2_verify")
class _Acl2VerifyContract:
    """v1.0.0 fallback opaque-mode handler."""

    class InputModel(BaseModel):
        target: Any
        timeout_sec: int = 300

    class OutputModel(BaseModel):
        all_proved: bool = False


@register_step_contract("vl_load")
class _VlLoadContract:
    class InputModel(BaseModel):
        target: Any
        source_files: list[str] | None = None
        top_module: str = ""
        timeout_sec: int = 120
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        vl_load_attempted: bool = False
        verification_status: str = "unverified"


@register_step_contract("vl_to_svex")
class _VlToSvexContract:
    class InputModel(BaseModel):
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        vl_to_svex_attempted: bool = False
        verification_status: str = "unverified"


@register_step_contract("fgl_bit_blast")
class _FglBitBlastContract:
    class InputModel(BaseModel):
        target: Any
        source_files: list[str] | None = None
        top_module: str = ""
        target_signal: str = "halted"
        timeout_sec: int = 600
        verification_status: str = "unverified"

    class OutputModel(BaseModel):
        fgl_result: Any = None
        verification_status: str = "unverified"
        engine_used: str | None = None


@register_step_contract("pythia_hammer")
class _PythiaHammerContract:
    class InputModel(BaseModel):
        target_path: Any
        source: str
        lake_project: str | None = None
        timeout_sec: int = 300

    class OutputModel(BaseModel):
        # Boolean-returning handler — output goes to a local var in
        # the cascade, not into ctx.  Nothing to declare upward.
        pass


@register_step_contract("pythia_lookup")
class _PythiaLookupContract:
    class InputModel(BaseModel):
        goal_class: str = ""
        registry: list[Any] = []

    class OutputModel(BaseModel):
        # Returns list of entries; cascade body assigns it to a local.
        pass


@register_step_contract("lean_audit")
class _LeanAuditContract:
    class InputModel(BaseModel):
        target_path: Any
        lake_project: str | None = None

    class OutputModel(BaseModel):
        # Returns dict; cascade body assigns it.
        pass
