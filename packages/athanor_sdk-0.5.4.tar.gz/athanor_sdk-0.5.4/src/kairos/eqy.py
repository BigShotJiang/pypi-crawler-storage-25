"""kairos.eqy — equivalence verification via the YosysHQ ``eqy`` tool.

ATH-944 (PureRTL round-trip v0): subprocess wrapper around ``eqy`` for
proving two SystemVerilog designs are sequentially equivalent. Used by
:mod:`kairos.pure_rtl.roundtrip` to close the loop on
``original SV ≡ Clash-regenerated SV``.

Mirrors the shape of :func:`kairos.sv.ebmc.run_ebmc` so callers that
already know that surface have a near-zero learning curve:

* :class:`EqyResult` — structured verdict + transcript + timing.
* :func:`verify` — the call. Takes the spec + impl SV, writes a recipe,
  shells out, parses ``eqy``'s last-line summary.

Why ``eqy`` (not SLEC) by default:

  * Open-source (Yosys ecosystem, ISC license) — works in CI without a
    commercial license. SLEC (Synopsys) is the obvious paid upgrade for
    Customer-2 (Annapurna/Todd) once they ask; the same module surface
    can dispatch to a SLEC backend in v1.

Trace emit:

  * On every call, emits the ``pure_rtl_eqy_verify`` event (registered in
    :data:`kairos.trace_schema.REGISTRY`). Payload carries verdict,
    elapsed_sec, properties_proved, properties_refuted. No-op outside a
    ``with observe()`` / ``with session()`` block — auto-bootstraps a
    free-tier context (see :func:`kairos.observe.emit`).

Errors:

  * Missing ``eqy`` binary → ``EqyResult(verdict='error', stderr=<msg>)``.
    Never raises FileNotFoundError up to the caller — same contract as
    :func:`kairos.sv.ebmc.run_ebmc`. Integration tests gate on the
    binary being on PATH (skipif).

Cross-ref:
  * :mod:`kairos.pure_rtl.clash_codegen` — produces the regenerated SV
    that ``verify`` is asked to equiv-check against the original.
  * :mod:`kairos.pure_rtl.roundtrip` — the orchestrator that composes
    Clash codegen + this module.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence


# ── Verdict regexes ─────────────────────────────────────────────────
#
# eqy's tail line looks like one of:
#   Successfully proved designs equivalent
#   Failed to prove equivalence
#   Unknown
# Plus per-property lines from the gate-graph traversal.

EQY_PROVED_RE = re.compile(
    r"Successfully\s+proved.*equivalent",
    re.IGNORECASE,
)
EQY_REFUTED_RE = re.compile(
    r"(?:Failed\s+to\s+prove\s+equivalence|FAIL\b|not\s+equivalent)",
    re.IGNORECASE,
)
EQY_UNKNOWN_RE = re.compile(
    r"(?:UNKNOWN|inconclusive|gave\s+up)",
    re.IGNORECASE,
)
# Per-property lines: "Successfully proved property foo" / "Failed to prove property foo"
EQY_PROP_PROVED_RE = re.compile(
    r"Successfully\s+proved\s+(?:property\s+)?(\S+)",
    re.IGNORECASE,
)
EQY_PROP_REFUTED_RE = re.compile(
    r"(?:Failed\s+to\s+prove|Disproved)\s+(?:property\s+)?(\S+)",
    re.IGNORECASE,
)


@dataclass
class EqyResult:
    """Structured outcome from a single ``eqy`` invocation."""

    verdict: str
    """One of ``"proved"``, ``"refuted"``, ``"unknown"``, ``"error"``."""

    exit_code: int
    elapsed_sec: float
    properties_proved: int
    properties_refuted: int
    stdout: str
    stderr: str
    timed_out: bool = False
    property_verdicts: dict[str, str] = field(default_factory=dict)

    @property
    def proved(self) -> bool:
        return self.verdict == "proved"


def _build_recipe(
    spec_sv: Path,
    impl_sv: Path,
    *,
    top_module: str,
    spec_top: str | None = None,
    impl_top: str | None = None,
    extra_options: Sequence[str] = (),
) -> str:
    """Construct an ``eqy`` recipe (.eqy) targeting the two SV files.

    The ``[gold]`` and ``[gate]`` sections each ``read_verilog`` one of
    the inputs and prep the design for equivalence; ``[strategy sat]``
    is the default solver. Recipe format reference:
    https://github.com/YosysHQ/eqy/blob/main/docs/source/intro.rst.

    Top-module names default to ``top_module`` for both sides; pass
    ``spec_top`` / ``impl_top`` when the regenerated implementation
    lives under a different module name.
    """
    spec_top = spec_top or top_module
    impl_top = impl_top or top_module
    extra_options_block = "\n".join(extra_options) if extra_options else ""
    return f"""\
[gold]
read -sv {spec_sv}
prep -top {spec_top}

[gate]
read -sv {impl_sv}
prep -top {impl_top}

[strategy sat]
use sat
depth 10
{extra_options_block}
"""


def _classify_verdict(stdout: str, stderr: str, exit_code: int) -> str:
    """Map ``eqy`` output lines + exit code to one of the four verdicts.

    Precedence (deliberate): refuted > unknown > proved > error. A
    refutation must dominate a stale ``Successfully proved …`` line
    from an earlier section of the transcript; an UNKNOWN must not
    silently degrade to proved.
    """
    blob = (stdout or "") + "\n" + (stderr or "")
    if EQY_REFUTED_RE.search(blob):
        return "refuted"
    if EQY_UNKNOWN_RE.search(blob):
        return "unknown"
    if EQY_PROVED_RE.search(blob):
        return "proved"
    if exit_code != 0:
        return "error"
    return "unknown"


def _parse_property_verdicts(stdout: str) -> dict[str, str]:
    """Extract per-property verdicts from ``eqy`` stdout."""
    verdicts: dict[str, str] = {}
    for m in EQY_PROP_PROVED_RE.finditer(stdout):
        verdicts[m.group(1)] = "PROVED"
    for m in EQY_PROP_REFUTED_RE.finditer(stdout):
        verdicts[m.group(1)] = "REFUTED"
    return verdicts


def verify(
    spec_sv: str | Path,
    impl_sv: str | Path,
    *,
    top_module: str,
    spec_top: str | None = None,
    impl_top: str | None = None,
    timeout_sec: int = 600,
    workdir: str | Path | None = None,
    extra_options: Sequence[str] = (),
    emit_trace: bool = True,
) -> EqyResult:
    """Prove ``spec_sv`` and ``impl_sv`` are sequentially equivalent.

    Args:
        spec_sv: path to the gold/spec SystemVerilog source. For the
            PureRTL round-trip this is the original hand-written block
            ("the one we already proved correct").
        impl_sv: path to the gate/implementation SystemVerilog source.
            For the round-trip this is the Clash-regenerated SV.
        top_module: the common top-module name. When the regenerated
            module is renamed (e.g. ``cpu_single_issue_clash``), pass
            ``spec_top`` and ``impl_top`` explicitly.
        spec_top: override top module for the spec side.
        impl_top: override top module for the impl side.
        timeout_sec: hard wall-clock cap on the ``eqy`` subprocess.
        workdir: directory to write the recipe + ``eqy``'s scratch
            files into. None → temp dir (caller doesn't care about the
            artifact). Pass an explicit path for CI artifacts.
        extra_options: extra recipe lines appended to the
            ``[strategy sat]`` block. Use sparingly.
        emit_trace: when True (default), emit a
            ``pure_rtl_eqy_verify`` trace event on completion. Set to
            False for tests / nested invocations that don't want their
            own trace row.

    Returns:
        :class:`EqyResult` with the verdict + transcript + per-property
        verdicts. Never raises for missing binary or timeout — those
        surface as ``verdict='error'`` / ``timed_out=True``.
    """
    spec_path = Path(spec_sv).resolve()
    impl_path = Path(impl_sv).resolve()
    if not spec_path.exists():
        return EqyResult(
            verdict="error",
            exit_code=-1,
            elapsed_sec=0.0,
            properties_proved=0,
            properties_refuted=0,
            stdout="",
            stderr=f"spec_sv does not exist: {spec_path}",
        )
    if not impl_path.exists():
        return EqyResult(
            verdict="error",
            exit_code=-1,
            elapsed_sec=0.0,
            properties_proved=0,
            properties_refuted=0,
            stdout="",
            stderr=f"impl_sv does not exist: {impl_path}",
        )

    eqy_bin = shutil.which("eqy")
    if not eqy_bin:
        return EqyResult(
            verdict="error",
            exit_code=-1,
            elapsed_sec=0.0,
            properties_proved=0,
            properties_refuted=0,
            stdout="",
            stderr="eqy binary not found on PATH (install YosysHQ/eqy)",
        )

    if workdir is None:
        workdir_path = Path(tempfile.mkdtemp(prefix="kairos_eqy_"))
    else:
        workdir_path = Path(workdir)
        workdir_path.mkdir(parents=True, exist_ok=True)

    recipe_text = _build_recipe(
        spec_path,
        impl_path,
        top_module=top_module,
        spec_top=spec_top,
        impl_top=impl_top,
        extra_options=extra_options,
    )
    recipe_path = workdir_path / "equiv.eqy"
    recipe_path.write_text(recipe_text)

    cmd = [eqy_bin, "-f", str(recipe_path)]

    t0 = time.monotonic()
    timed_out = False
    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            cwd=str(workdir_path),
        )
        elapsed = time.monotonic() - t0
        stdout = res.stdout or ""
        stderr = res.stderr or ""
        exit_code = res.returncode
    except subprocess.TimeoutExpired:
        elapsed = float(timeout_sec)
        stdout = ""
        stderr = f"eqy timed out after {timeout_sec}s"
        exit_code = -1
        timed_out = True

    verdict = "unknown" if timed_out else _classify_verdict(stdout, stderr, exit_code)
    property_verdicts = _parse_property_verdicts(stdout)
    properties_proved = sum(1 for v in property_verdicts.values() if v == "PROVED")
    properties_refuted = sum(1 for v in property_verdicts.values() if v == "REFUTED")

    result = EqyResult(
        verdict=verdict,
        exit_code=exit_code,
        elapsed_sec=round(elapsed, 3),
        properties_proved=properties_proved,
        properties_refuted=properties_refuted,
        stdout=stdout,
        stderr=stderr,
        timed_out=timed_out,
        property_verdicts=property_verdicts,
    )

    if emit_trace:
        try:
            from kairos.observe import emit
            emit(
                "pure_rtl_eqy_verify",
                {
                    "spec_sv": str(spec_path),
                    "impl_sv": str(impl_path),
                    "top_module": top_module,
                    "verdict": verdict,
                    "elapsed_sec": result.elapsed_sec,
                    "properties_proved": properties_proved,
                    "properties_refuted": properties_refuted,
                    "timed_out": timed_out,
                    "exit_code": exit_code,
                },
            )
        except Exception:  # noqa: BLE001 — trace emit must never break verify()
            pass

    return result


__all__ = ["EqyResult", "verify"]
