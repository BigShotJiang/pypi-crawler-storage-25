"""ATH-369 — SDK security utilities.

Three small helpers for the SDK's runtime-security story, each mapping
to one ATH-369 umbrella Medium-severity item:

1. `secure_runs_dir(run_id)` — creates `~/.athanor/runs/<run-id>/` with
   mode 0o700. Any file written into it by the caller should use
   `atomic_write_secure()` or be followed by `chmod 0o600`. Prevents
   a world-readable runs dir from exposing customer traces.

2. `intent_tempfile(intent: dict)` — writes an IntentV1 blob to a
   tempfile created via `tempfile.mkstemp(mode=0o600)` instead of a
   predictable `/tmp/intent.json` path. Avoids the classic
   `/tmp/<file>` symlink race + mode exposure. Returns a context
   manager so cleanup is automatic on exceptions. Used when the
   intent JSON exceeds argv's 128KB limit and must go via file.

3. `verify_license_signature(license_path, pubkey_path, expected_fpr)` —
   runs `gpg --verify` on the detached signature of `license.json`
   every time `athanor spec submit` is called. ~10ms; cached for
   60s on unchanged mtime to avoid hammering gpg on rapid resubmits.
   Rejects the submit if signature is invalid, pubkey fingerprint
   does not match, or license file mtime is in the future (clock-
   skew probe).

All three are importable without needing the rest of the SDK plumbing
(spec_compiler, cli, etc.) so they can land ahead of #26's spec-submit
integration. #26 imports them when it lands.
"""
from __future__ import annotations

import contextlib
import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Iterator, Optional


# ─── Config ──────────────────────────────────────────────────────────────

RUNS_DIR_MODE = 0o700
RUNS_FILE_MODE = 0o600
INTENT_TEMPFILE_MODE = 0o600
LICENSE_CACHE_TTL_SECONDS = 60

# Real GPG fingerprints are 40 uppercase hex chars. Any value that
# doesn't match is treated as a misconfigured placeholder.
_GPG_FPR_RE = re.compile(r"^[A-F0-9]{40}$")


# ─── 1. Secure runs directory ────────────────────────────────────────────


def secure_runs_dir(run_id: str, home: Optional[Path] = None) -> Path:
    """Create `~/.athanor/runs/<run_id>/` with mode 0o700 and return it.

    If the directory already exists with looser perms (e.g. 0o755 from
    a prior manual `mkdir`), it is tightened to 0o700. Same for the
    parent `~/.athanor/runs/` and `~/.athanor/`.

    Raises `ValueError` on a malformed run_id — we reject anything that
    would let `run_id` escape the runs dir (path separators, `..`,
    leading `-`). This is the only caller-supplied string; everything
    else is derived.
    """
    if not run_id or not isinstance(run_id, str):
        raise ValueError(f"run_id must be a non-empty string; got {run_id!r}")
    if any(c in run_id for c in ("/", "\\", "\0")) or ".." in run_id:
        raise ValueError(f"run_id contains disallowed characters: {run_id!r}")
    if run_id.startswith("-"):
        raise ValueError(f"run_id must not start with '-': {run_id!r}")

    base = (home or Path.home()) / ".athanor"
    runs_dir = base / "runs"
    run_dir = runs_dir / run_id

    for d in (base, runs_dir, run_dir):
        d.mkdir(mode=RUNS_DIR_MODE, exist_ok=True)
        # Tighten mode even if pre-existing (mkdir's `mode=` is ignored
        # on existing dirs).
        os.chmod(d, RUNS_DIR_MODE)

    return run_dir


def atomic_write_secure(path: Path, content: bytes | str) -> None:
    """Write `content` to `path` atomically with mode 0o600.

    Write to a sibling .tmp, fsync, then `os.replace`. Avoids a
    partial-write window where a reader could see truncated content
    at default umask.
    """
    if isinstance(content, str):
        content = content.encode("utf-8")
    path = Path(path)
    path.parent.mkdir(mode=RUNS_DIR_MODE, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(str(tmp), flags, RUNS_FILE_MODE)
    try:
        os.write(fd, content)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, path)
    # Defensive re-chmod — `os.replace` should preserve mode on Linux,
    # but cheap to be explicit.
    os.chmod(path, RUNS_FILE_MODE)


# ─── 2. Intent tempfile ──────────────────────────────────────────────────


# argv + env share ~128KB (ARG_MAX on Linux; lower on some shells).
# Intents above ~100KB spill the limit once the subprocess flags and
# env are counted. Below the threshold, pass the JSON inline for
# simplicity and one-fewer-file.
INTENT_ARGV_THRESHOLD_BYTES = 100 * 1024


@contextlib.contextmanager
def intent_tempfile(intent: dict) -> Iterator[Path]:
    """Context-manager that yields a path to a temp file containing
    `json.dumps(intent)`, created with mode 0o600 via `mkstemp`.

    On exit, the file is deleted — even on exception paths. Callers
    should consume the file before the `with` block ends.

    Use this when the intent blob exceeds `INTENT_ARGV_THRESHOLD_BYTES`
    and cannot safely go via argv. For smaller intents, inline argv is
    preferred (no filesystem touch).
    """
    # mkstemp returns an fd + path. The fd is already created with the
    # requested mode atomically (we pre-chmod the umask during the
    # call).
    old_umask = os.umask(0o077)
    try:
        fd, path_str = tempfile.mkstemp(prefix="athanor-intent-", suffix=".json")
    finally:
        os.umask(old_umask)

    path = Path(path_str)
    try:
        os.fchmod(fd, INTENT_TEMPFILE_MODE)
        os.write(fd, json.dumps(intent).encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)

    try:
        yield path
    finally:
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def should_use_intent_tempfile(intent: dict) -> bool:
    """Return True if the intent's serialized JSON exceeds the argv
    threshold and must go via file. Callers decide whether to pass
    `--intent-json <str>` (inline) or `--intent-json-file <path>`."""
    size = len(json.dumps(intent).encode("utf-8"))
    return size > INTENT_ARGV_THRESHOLD_BYTES


# ─── 3. License signature verification (cached) ──────────────────────────


class LicenseVerifyError(RuntimeError):
    """Raised when license.json fails signature verification.

    Exit-code convention in the CLI: `athanor spec submit` prints the
    message and exits non-zero. Never re-raise silently — a bad license
    is a hard stop per ATH-369.
    """


# Per-process cache: (license_path, mtime) → (verified_bool, cached_at).
# Per-process is fine because the worst case is one extra gpg call per
# new process; we're not caching across invocations by design (don't
# want a stale cache surviving a license rotation).
_license_cache: dict[tuple[str, float], tuple[bool, float]] = {}


def verify_license_signature(
    license_path: Path,
    pubkey_path: Path,
    expected_fpr: str,
    sig_path: Optional[Path] = None,
    cache_ttl: float = LICENSE_CACHE_TTL_SECONDS,
) -> None:
    """Verify `license_path` has a valid detached GPG signature.

    Steps:
      1. Fingerprint gate: expected_fpr must be 40 uppercase hex chars.
         (Placeholder values fail — real fingerprints always match this
         shape.)
      2. Clock-skew gate: license mtime must not be in the future.
      3. Cache lookup on (path, mtime) — skip gpg if hit within TTL.
      4. Import pubkey into an ephemeral GNUPGHOME (mktemp -d, 0o700).
      5. Assert imported key's fingerprint matches expected_fpr.
      6. Run `gpg --verify <sig> <license>`.
      7. Clean up the ephemeral home.

    On any failure → raise `LicenseVerifyError` with a customer-
    actionable message. On success → return None and cache the result.
    """
    license_path = Path(license_path)
    pubkey_path = Path(pubkey_path)
    if sig_path is None:
        sig_path = license_path.with_suffix(license_path.suffix + ".sig")
    sig_path = Path(sig_path)

    if not _GPG_FPR_RE.match(expected_fpr or ""):
        raise LicenseVerifyError(
            f"expected_fpr is not a valid GPG fingerprint "
            f"(40 uppercase hex chars); got {expected_fpr!r}. "
            "Installer or config is misconfigured — do not submit."
        )

    if not license_path.is_file():
        raise LicenseVerifyError(f"license file not found: {license_path}")
    if not sig_path.is_file():
        raise LicenseVerifyError(
            f"license signature missing: {sig_path}. "
            "Unsigned license is refused — re-install from a signed "
            "enterprise tarball."
        )
    if not pubkey_path.is_file():
        raise LicenseVerifyError(f"pubkey file not found: {pubkey_path}")

    # Clock-skew probe — a future-dated license mtime could be an
    # attempt to extend an expired license by touching the file. The
    # mtime is a weak signal (attacker can still set it backward), but
    # this catches the trivial forward-set case.
    mtime = license_path.stat().st_mtime
    if mtime > time.time() + 60:  # 60s slack for NTP skew
        raise LicenseVerifyError(
            f"license mtime is in the future ({mtime}). Clock skew or "
            "tampering — refusing to verify."
        )

    cache_key = (str(license_path), mtime)
    if cache_key in _license_cache:
        cached, cached_at = _license_cache[cache_key]
        if time.time() - cached_at < cache_ttl and cached:
            return

    gpg_home = tempfile.mkdtemp(prefix="athanor-license-verify-")
    try:
        os.chmod(gpg_home, 0o700)
        env = {**os.environ, "GNUPGHOME": gpg_home}

        subprocess.run(
            ["gpg", "--batch", "--import", str(pubkey_path)],
            env=env, check=True, capture_output=True,
        )

        # Sanity-check imported fingerprint matches expected.
        result = subprocess.run(
            ["gpg", "--batch", "--list-keys", "--with-colons"],
            env=env, check=True, capture_output=True, text=True,
        )
        imported_fpr = None
        for line in result.stdout.splitlines():
            if line.startswith("fpr:"):
                imported_fpr = line.split(":")[9]
                break
        if imported_fpr != expected_fpr:
            raise LicenseVerifyError(
                f"pubkey fingerprint mismatch: expected {expected_fpr}, "
                f"imported {imported_fpr}. Not the Athanor key — do not "
                "submit. Re-install from a signed tarball."
            )

        verify_result = subprocess.run(
            ["gpg", "--batch", "--verify", str(sig_path), str(license_path)],
            env=env, capture_output=True, text=True,
        )
        if verify_result.returncode != 0:
            raise LicenseVerifyError(
                f"license signature verification failed. "
                f"gpg stderr: {verify_result.stderr.strip()}"
            )
    finally:
        # Best-effort cleanup; never propagate cleanup failures.
        try:
            import shutil
            shutil.rmtree(gpg_home, ignore_errors=True)
        except Exception:  # noqa: BLE001 — cleanup, rmtree(ignore_errors=True) already swallows OSError; double-belt for shutil import edge-cases
            pass

    _license_cache[cache_key] = (True, time.time())


def clear_license_cache() -> None:
    """Drop the in-process license-verify cache. Useful for tests."""
    _license_cache.clear()


__all__ = [
    "RUNS_DIR_MODE",
    "RUNS_FILE_MODE",
    "INTENT_TEMPFILE_MODE",
    "INTENT_ARGV_THRESHOLD_BYTES",
    "LICENSE_CACHE_TTL_SECONDS",
    "LicenseVerifyError",
    "secure_runs_dir",
    "atomic_write_secure",
    "intent_tempfile",
    "should_use_intent_tempfile",
    "verify_license_signature",
    "clear_license_cache",
]
