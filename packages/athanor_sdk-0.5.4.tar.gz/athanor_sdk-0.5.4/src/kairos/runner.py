"""Self-hosted runner — polls the Athanor platform for jobs and executes them locally.

Usage:
    athanor run --token <sync-token>
    athanor run --token <sync-token> --platform https://tahoe.athanor-ai.com

The runner:
1. Registers with the platform
2. Polls for jobs (score, solve, evaluate, build)
3. Pulls the scoring container from GHCR
4. Runs scoring locally with Docker
5. Reports results back to the platform

Requirements: Docker, Python 3.10+, outbound HTTPS
"""

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.request

from kairos import __version__ as _VERSION
from kairos.filenames import task_slug_to_lean_filename
from kairos.envvars import getenv_dual
# ATH-815 (Aidan 2026-04-28 directive): every model identifier the
# runner uses is sourced from ``kairos.model_presets`` so the literal
# lives in one auditable place. ``DEFAULT_RUNNER_MODEL`` is the
# customer-facing solve-job default; ``DEFAULT_SPEC_GENERATION_MODEL``
# is the bare Anthropic API model id used for the spec-generation
# phase (which calls the API directly, not via litellm, so no
# provider prefix). Behavior is unchanged from the pre-migration
# inline literals.
from kairos.model_presets import (
    DEFAULT_RUNNER_MODEL,
    DEFAULT_SPEC_GENERATION_MODEL,
)

logger = logging.getLogger(__name__)

# Regex to redact API key material from error messages before they reach the
# platform or logs. Matches common token shapes: sk- prefixed keys, AIza
# Google keys, and long base64-ish blobs.
_REDACT_RE = re.compile(
    r"(?i)(?:"
    r"sk-[A-Za-z0-9_-]{20,}"
    r"|AIza[0-9A-Za-z_-]{35}"
    r"|(?:api[_-]?key|token|secret|password|bearer)\s*[=:]\s*[^\s,;'\"]{8,}"
    r"|[A-Za-z0-9+/]{40,}={0,2}"
    r")"
)


def _sanitize_error(msg: str) -> str:
    """Remove API key material from an error string before reporting or logging.

    Uses a conservative regex to redact values that look like tokens/secrets.
    The result is safe to send to the platform and surface in the UI.
    """
    return _REDACT_RE.sub("[REDACTED]", msg)


class ModelProviderError(RuntimeError):
    """Raised when a model API call fails due to auth, config, or network issues.

    Distinct from scoring / container errors so ``execute_job`` and
    ``run_forever`` can mark the job ``status=failed`` instead of
    ``status=completed`` with a silent score-0.

    The message stored here is already sanitized (no key material).
    """


def _classify_model_exception(exc: BaseException) -> str | None:
    """Return a human-readable provider error string, or None if not a provider error.

    Recognises:
    - litellm.AuthenticationError         — bad/missing API key
    - litellm.NotFoundError               — model not found / wrong model string
    - litellm.InvalidRequestError         — malformed request (incl. unsupported model)
    - litellm.BadRequestError             — 400 from provider (auth/quota/policy)
    - litellm.APIConnectionError          — network error reaching provider
    - litellm.Timeout                     — provider call timed out
    - litellm.ServiceUnavailableError     — provider 503/overload
    - ImportError containing 'litellm'    — multi-model extra not installed
    - ValueError with 'Unknown model provider' — providers.py guard (lines 99-104)
    - urllib.error.HTTPError code 401/403  — Anthropic native API auth failure
    - urllib.error.URLError               — network unreachable for Anthropic native
    """
    import urllib.error as _ue

    # urllib errors from _call_anthropic (native Anthropic path)
    if isinstance(exc, _ue.HTTPError):
        if exc.code in (401, 403):
            return f"Model call failed: Anthropic API authentication error (HTTP {exc.code})"
        return f"Model call failed: Anthropic API returned HTTP {exc.code}"
    if isinstance(exc, _ue.URLError):
        return f"Model call failed: network error reaching Anthropic API — {exc.reason}"

    # ImportError from _require_litellm (multi-model extra not installed)
    if isinstance(exc, ImportError) and "litellm" in str(exc):
        return f"Model call failed: {exc}"

    # ValueError from unknown-model guard in providers.call_model
    if isinstance(exc, ValueError) and "Unknown model provider" in str(exc):
        return f"Model call failed: {exc}"

    # litellm exceptions — lazy import to avoid hard dep at module load
    try:
        import litellm as _ll
        if isinstance(exc, _ll.AuthenticationError):
            return f"Model call failed: litellm AuthenticationError — {exc}"
        if isinstance(exc, _ll.NotFoundError):
            return f"Model call failed: litellm NotFoundError (unknown model?) — {exc}"
        if isinstance(exc, _ll.InvalidRequestError):
            return f"Model call failed: litellm InvalidRequestError — {exc}"
        if isinstance(exc, _ll.BadRequestError):
            return f"Model call failed: litellm BadRequestError — {exc}"
        if isinstance(exc, _ll.APIConnectionError):
            return f"Model call failed: litellm APIConnectionError — {exc}"
        if isinstance(exc, _ll.Timeout):
            return f"Model call failed: litellm Timeout — {exc}"
        if isinstance(exc, _ll.ServiceUnavailableError):
            return f"Model call failed: litellm ServiceUnavailableError — {exc}"
    except ImportError:
        pass  # litellm not installed; ImportError case above already handled

    return None  # not a known provider error


def _stream_tool_for_model(model: str) -> str:
    """Map a litellm-style model ID to a renderer-friendly tool label.

    ATH-395: the renderer's Tool literal accepts 'opus' | 'sonnet' |
    'kimi' | 'gemini' | 'lean' | 'ebmc' | ... . We emit whichever
    short label most cleanly identifies the model without leaking
    provider prefix clutter. Unknown IDs fall back to 'sonnet' (the
    most common legacy-solve model) rather than raising — the tool
    field is forward-compat and the renderer left-pads unknowns.
    """
    m = model.lower()
    if "opus" in m:
        return "opus"
    if "sonnet" in m:
        return "sonnet"
    if "haiku" in m:
        return "haiku"
    if "kimi" in m:
        return "kimi"
    if "gemini" in m:
        return "gemini"
    if "mistral" in m:
        return "mistral"
    if "gpt" in m:
        return "sonnet"  # no distinct gpt Tool slot; renderer tolerates
    return "sonnet"


def _stream_tool_args_summary(tool_name: str, tool_args: dict) -> str:
    """Produce an <80-char arg preview for emit_tool_use.

    Domain-aware: for the few tools legacy cmd_solve uses
    (read_file, write_file, run_bash, score) we extract the most
    salient arg (path / cmd) rather than json-dumping the whole
    dict which clutters the renderer.
    """
    if not isinstance(tool_args, dict):
        return str(tool_args)[:80]
    if tool_name in ("read_file", "write_file") and "path" in tool_args:
        return str(tool_args["path"])[:80]
    if tool_name == "run_bash" and "command" in tool_args:
        return str(tool_args["command"])[:80]
    # Fallback: compact JSON.
    import json as _json
    try:
        return _json.dumps(tool_args, separators=(",", ":"))[:80]
    except Exception:  # noqa: BLE001 — guard returns fallback value on any error
        return str(tool_args)[:80]


class GHCRLoginError(RuntimeError):
    """Raised when GHCR login fails at runner startup.

    The message is safe to log — it never contains token material.
    """


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Prevent urllib from following redirects (which drops the Authorization header)."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(newurl, code, msg, headers, fp)


class Runner:
    def __init__(self, token: str, platform_url: str = "https://tahoe.athanor-ai.com", name: str = "default"):
        # ATH-388: Runner is inherently non-local — it polls our platform
        # for jobs. If the SDK is configured for local-only mode, refuse
        # to construct a Runner rather than silently emit network calls.
        from kairos.config import is_local_mode
        if is_local_mode():
            raise RuntimeError(
                "Runner is not supported in local mode (ATHANOR_MODE=local). "
                "Runner polls tahoe.athanor-ai.com for jobs; local mode "
                "skips platform traffic. Use `athanor solve` / `athanor score` "
                "for local-only flows instead."
            )
        self.token = token
        self.platform_url = platform_url.rstrip("/")
        self.name = name
        self.runner_id: str | None = None
        self.docker_bin = shutil.which("docker") or shutil.which("podman")
        if not self.docker_bin:
            raise RuntimeError("Docker or Podman is required. Install Docker and try again.")
        self._opener = urllib.request.build_opener(_NoRedirectHandler)

    def _emit_phase(self, job_id: str | None, phase: str, **extra) -> None:
        """Best-effort phase-event emit for ATH-95 build-trace timeline UI.

        Posts one `{phase, ...extra}` event to POST /api/runner/build-trace
        (server fills in `ts`). All failures swallowed — the build-trace
        timeline is UX, not load-bearing: a trace outage must not fail a
        build. See docs/ATH-95-runner-build-trace.md on athanor-platform for
        the event schema and phase vocabulary.

        Uses a short per-call timeout (5s) so an unresponsive platform
        doesn't serialize into the build's critical path. The final
        /api/runner/results submission is where real work lands.
        """
        if not job_id:
            return  # fail-closed when we don't have a job_id (e.g., CLI run)
        try:
            body = json.dumps({"job_id": job_id, "phase": phase, **extra}).encode()
            req = urllib.request.Request(
                f"{self.platform_url}/api/runner/build-trace",
                data=body,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                    "User-Agent": f"athanor-runner/{_VERSION}",
                },
                method="POST",
            )
            self._opener.open(req, timeout=5).read()
        except Exception:  # noqa: BLE001 — broad-catch fallback
            pass  # trace is advisory; never block the build

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        url = f"{self.platform_url}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": f"athanor-runner/{_VERSION}",
            },
            method=method,
        )
        try:
            resp = self._opener.open(req, timeout=35)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            if e.code == 401:
                raise RuntimeError("Authentication failed. Check your sync token (--token or ATHANOR_TOKEN).")
            if e.code == 403:
                raise RuntimeError(
                    "Access denied. Your token may not have permission for this operation, "
                    "or the endpoint requires additional access configuration."
                )
            if e.code == 404:
                raise RuntimeError(f"Not found: {path}. Check that the environment/task exists.")
            raise RuntimeError(f"API error {e.code}: {body[:200]}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Cannot reach platform at {self.platform_url}: {e.reason}")

    def register(self):
        """Register this runner with the platform."""
        result = self._request("POST", "/api/runner", {"name": self.name})
        self.runner_id = result.get("runner_id")
        print(f"Runner registered: {self.runner_id}")
        return self.runner_id

    def poll(self) -> dict | None:
        """Poll for the next job. Returns None if no jobs queued."""
        result = self._request("GET", f"/api/runner/poll?runner_id={self.runner_id}")
        return result.get("job")

    def report(self, job_id: str, result: dict | None = None, error: str | None = None):
        """Report job results back to the platform."""
        self._request("POST", "/api/runner/results", {
            "job_id": job_id,
            "status": "failed" if error else "completed",
            "result": result,
            "error": error,
        })

    def pull_image(self, image: str):
        """Pull a container image if not already present."""
        check = subprocess.run(
            [self.docker_bin, "image", "inspect", image],
            capture_output=True,
        )
        if check.returncode != 0:
            print(f"  Pulling {image}...")
            result = subprocess.run(
                [self.docker_bin, "pull", image],
                capture_output=True, text=True,
            )
            if result.returncode != 0:
                stderr = result.stderr.strip()[:300]
                if "not found" in stderr.lower() or "manifest unknown" in stderr.lower():
                    raise RuntimeError(
                        f"Container image not found: {image}\n"
                        f"Check that the environment exists at ghcr.io/athanor-ai/"
                    )
                raise RuntimeError(f"Failed to pull {image}: {stderr}")

    def run_score(self, image: str, task_config: dict, student_code: str | None = None,
                  data_dir: str | None = None, shared_dir: str | None = None) -> dict:
        """Run scoring in a container and return the result.

        If data_dir is provided, scores files in-place (used by run_solve).
        Otherwise creates a temp dir and optionally writes student_code.
        """
        cleanup = False
        if data_dir is None:
            tmpdir = tempfile.mkdtemp(prefix="athanor-score-")
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            cleanup = True

            # Write student code if provided
            stub_filename = task_config.get("stub_filename", "solution.py")
            if student_code:
                with open(os.path.join(data_dir, stub_filename), "w") as f:
                    f.write(student_code)

        if shared_dir is None:
            shared_dir = os.path.join(os.path.dirname(data_dir), "shared")
            os.makedirs(shared_dir, exist_ok=True)

        task_slug = task_config.get("task_slug", "unknown")
        config_path = f"/root_data/eval/configs/{task_slug}.json"

        result = subprocess.run(
            [
                self.docker_bin, "run", "--rm", "--user", "root",
                "--network=none", "--memory=4g", "--pids-limit=256",
                "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                "-v", f"{data_dir}:/workdir/data",
                "-v", f"{shared_dir}:/workdir/shared:ro",
                image, "bash", "-c",
                # Run scoring, capture stderr for feedback, then output score JSON + errors
                f"/root/.venv/bin/python /root_data/eval/scoring.py "
                f"{config_path} /tmp/score.json 2>/tmp/score_err.txt; "
                f"echo '---SCORE_JSON---'; "
                f"cat /tmp/score.json 2>/dev/null || "
                f'echo \'{{"score": 0.0, "metadata": {{"error": "scoring crashed"}}}}\'; '
                f"echo '---SCORE_STDERR---'; "
                f"head -100 /tmp/score_err.txt 2>/dev/null",
            ],
            capture_output=True, text=True, timeout=300,
        )

        try:
            stdout = result.stdout.strip()
            # Split on markers to get score JSON and stderr separately
            score_json_str = stdout
            scoring_stderr = ""
            if "---SCORE_JSON---" in stdout:
                parts = stdout.split("---SCORE_JSON---", 1)
                rest = parts[1] if len(parts) > 1 else ""
                if "---SCORE_STDERR---" in rest:
                    json_part, stderr_part = rest.split("---SCORE_STDERR---", 1)
                    score_json_str = json_part.strip()
                    scoring_stderr = stderr_part.strip()[:3000]
                else:
                    score_json_str = rest.strip()

            json_start = score_json_str.find("{")
            if json_start >= 0:
                score_data = json.loads(score_json_str[json_start:])
            else:
                score_data = json.loads(score_json_str)
        except (json.JSONDecodeError, ValueError):
            score_data = {"score": 0.0, "metadata": {"error": f"Parse error: {result.stdout[:300]}"}}
            scoring_stderr = ""

        # Inject captured stderr (Lean errors, compilation errors) into metadata
        if scoring_stderr:
            meta = score_data.get("metadata", {})
            existing = meta.get("compilation_errors", "")
            if scoring_stderr not in str(existing):
                meta["compilation_errors"] = (str(existing) + "\n" + scoring_stderr).strip()
            score_data["metadata"] = meta

        # Post-score diagnostics: get actual compiler errors when compilation fails
        score_meta = score_data.get("metadata", {})
        if score_meta.get("full_compilation") is False or (score_meta.get("error") and score_data.get("score", 0) < 0.1):
            lean_file = score_meta.get("lean_file", "")
            if lean_file and lean_file.startswith("/workdir/data/"):
                fname = os.path.basename(lean_file)
                if os.path.exists(os.path.join(data_dir, fname)):
                    try:
                        diag = subprocess.run(
                            [self.docker_bin, "run", "--rm", "--user", "root",
                             "--network=none", "--memory=4g",
                             "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                             "-v", f"{data_dir}:/workdir/data",
                             "-v", f"{shared_dir}:/workdir/shared:ro",
                             image, "bash", "-c",
                             f"cd /workdir && lean data/{fname} 2>&1 | grep -E 'error|Error|unknown' | head -20"],
                            capture_output=True, text=True, timeout=120,
                        )
                        if diag.stdout.strip():
                            score_meta["lean_errors"] = diag.stdout.strip()[:2000]
                            score_data["metadata"] = score_meta
                    except Exception:  # noqa: BLE001 — diagnostic Lean stderr scrape; skip on docker/lean failure rather than fail the whole run
                        pass

        # Read student files after scoring
        student_files = {}
        for f in os.listdir(data_dir):
            fpath = os.path.join(data_dir, f)
            if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                try:
                    student_files[f"data/{f}"] = open(fpath).read()
                except Exception:  # noqa: BLE001 — file read into student_files; skip unreadable
                    pass

        if cleanup:
            import shutil as _shutil
            _shutil.rmtree(tmpdir, ignore_errors=True)

        return {
            "task": task_slug,
            "score": score_data.get("score", 0.0),
            "scoring_metadata": score_data.get("metadata", {}),
            "student_files": student_files,
            "tool_calls_total": 0,
            "time_seconds": 0,
        }

    # Tool definitions for the agent solve loop (Anthropic tool_use format)
    SOLVE_TOOLS = [
        {
            "name": "read_file",
            "description": "Read a file from the working directory. Paths are relative to /workdir/ (e.g. 'data/solution.py', 'shared/reference.txt').",
            "input_schema": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path relative to /workdir/"}},
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write content to a file in /workdir/data/. Only files in data/ can be written.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path relative to /workdir/data/ (e.g. 'solution.py')"},
                    "content": {"type": "string", "description": "Full file content to write"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "bash",
            "description": "Run a bash command inside the scoring container. Network is disabled. Timeout 30s.",
            "input_schema": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Command to execute"}},
                "required": ["command"],
            },
        },
    ]

    def _call_anthropic(self, messages: list, api_key: str, model: str,
                        tools: list | None = None, api_base: str | None = None,
                        max_tokens: int = 200000) -> dict:
        """Call the Anthropic Messages API and return the raw response.

        Default ``max_tokens=200_000`` per Aidan 2026-04-23: Anthropic
        routes get the full ceiling so reasoning + tool-chains don't
        truncate. Wall-clock timeout + cost-cap guardrails (Stream D
        cost_tracker + SpecPipeline budget_usd) are the actual spend
        limiter. Callers that know their task is small can override
        downward.
        """
        base = api_base or os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com"
        base = base.rstrip("/")
        url = f"{base}/v1/messages"

        # The Anthropic API expects a bare model ID (claude-sonnet-4-6),
        # not the LiteLLM-style provider-prefixed form
        # (anthropic/claude-sonnet-4-6). Callers may pass either;
        # normalize here so the dispatch site in run_solve can keep the
        # full prefixed form for LiteLLM-vs-native routing decisions.
        if model.startswith("anthropic/"):
            model = model[len("anthropic/"):]

        payload: dict = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": messages,
        }
        if tools:
            payload["tools"] = tools

        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
                "User-Agent": f"athanor-runner/{_VERSION}",
            },
        )
        resp = urllib.request.urlopen(req, timeout=180)
        return json.loads(resp.read())

    def _exec_tool(self, name: str, args: dict, data_dir: str, shared_dir: str, image: str) -> str:
        """Execute a tool call and return the result string."""
        if name == "read_file":
            path = args.get("path", "")
            # Resolve to data/ or shared/
            if path.startswith("data/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            elif path.startswith("shared/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            else:
                full = os.path.join(data_dir, path)
            if not os.path.isfile(full):
                return f"Error: file not found: {path}"
            try:
                content = open(full).read()
                return content[:30000]
            except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
                return f"Error reading file: {e}"

        elif name == "write_file":
            path = args.get("path", "")
            content = args.get("content", "")
            # Only write to data/
            full = os.path.join(data_dir, os.path.basename(path))
            with open(full, "w") as f:
                f.write(content)
            return f"Written {len(content)} chars to data/{os.path.basename(path)}"

        elif name == "bash":
            cmd = args.get("command", "")
            try:
                result = subprocess.run(
                    [
                        self.docker_bin, "run", "--rm", "--user", "root",
                        "--network=none", "--memory=4g", "--pids-limit=256",
                        "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                        "-v", f"{data_dir}:/workdir/data",
                        "-v", f"{shared_dir}:/workdir/shared:ro",
                        image, "bash", "-c", cmd,
                    ],
                    capture_output=True, text=True, timeout=30,
                )
                output = result.stdout[:5000]
                if result.stderr:
                    output += f"\nSTDERR:\n{result.stderr[:2000]}"
                if result.returncode != 0:
                    output += f"\n(exit code {result.returncode})"
                return output or "(no output)"
            except subprocess.TimeoutExpired:
                return "Error: command timed out (30s)"
            except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
                return f"Error: {e}"

        return f"Unknown tool: {name}"

    def run_solve(self, image: str, task_config: dict, model: str = DEFAULT_RUNNER_MODEL,
                   api_key: str | None = None, max_turns: int = 30) -> dict:
        """Run a full agent solve loop with tool use: read/write files, bash, score, retry."""
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return {"error": "ANTHROPIC_API_KEY required for solve"}

        task_slug = task_config.get("task_slug", "unknown")
        stub_code = task_config.get("stub_code", "")
        stub_filename = task_config.get("stub_filename", "solution.py")
        description = task_config.get("task_description", "")

        print(f"  Solving {task_slug} with {model}...")

        # ATH-395: emit stream events so `athanor stream` can render
        # the legacy (non-`--vertical`) solve path. Pure passthrough —
        # print lines stay for direct-terminal callers; the emit_*
        # helpers are mode-gated via env, so quiet-mode is
        # unchanged.
        from kairos.stream_schema import (
            emit_phase_start, emit_phase_summary, emit_verdict,
            emit_thinking_start, emit_thinking_end,
            emit_tool_use, emit_tool_result, emit_bug_found,
            emit_token_tick,
        )
        stream_tool = _stream_tool_for_model(model)
        stream_stage = "phase_0"  # legacy solve is a single phase
        stream_agent_id = f"solve-{task_slug}"
        emit_phase_start(
            stream_stage, stream_tool,
            headline=f"solve {task_slug} ({model}, max_turns={max_turns})",
        )

        # Set up workdir
        tmpdir = tempfile.mkdtemp(prefix="athanor-solve-")
        data_dir = os.path.join(tmpdir, "data")
        shared_dir = os.path.join(tmpdir, "shared")
        os.makedirs(data_dir)
        os.makedirs(shared_dir)

        # Write stub file(s)
        student_path = os.path.join(data_dir, stub_filename)
        with open(student_path, "w") as f:
            f.write(stub_code)

        # Write additional stub files if present (multi-file tasks)
        extra_files = task_config.get("extra_files", {})
        for fname, content in extra_files.items():
            with open(os.path.join(data_dir, fname), "w") as f:
                f.write(content)

        # Copy shared data from container
        subprocess.run(
            [self.docker_bin, "run", "--rm", image, "tar", "-cf", "-", "-C", "/workdir/shared", "."],
            stdout=open(os.path.join(tmpdir, "shared.tar"), "wb"),
            timeout=30,
        )
        subprocess.run(["tar", "-xf", os.path.join(tmpdir, "shared.tar"), "-C", shared_dir], timeout=10)

        # List available files for context
        data_files = os.listdir(data_dir)
        shared_files = []
        try:
            shared_files = os.listdir(shared_dir)
        except OSError:
            pass

        # Build system prompt
        system = (
            "You are solving a coding task. Use the provided tools to read files, write solutions, "
            "and run commands.\n\n"
            f"Task: {description}\n\n"
            f"Files in data/ (editable): {', '.join(data_files)}\n"
            f"Files in shared/ (read-only): {', '.join(shared_files[:20])}\n\n"
            f"Primary file to edit: data/{stub_filename}\n"
            "Write your solution using write_file, then I will score it automatically."
        )

        messages: list[dict] = [
            {"role": "user", "content": (
                f"Solve this task by editing the file(s) in data/.\n\n"
                f"--- data/{stub_filename} ---\n{stub_code}\n\n"
                "Start by reading any shared/ reference files you need, then write your solution."
            )},
        ]

        best_score = 0.0
        best_files: dict[str, str] = {}
        tool_call_count = 0
        score_result: dict = {}
        score_history: list[dict] = []
        start_time = time.time()
        # ATH-406: running token totals fed into emit_token_tick after
        # each LLM call. providers.call_model already normalizes usage
        # into {input_tokens, output_tokens} (providers.py:409). Native
        # Anthropic path returns the same shape via _call_anthropic.
        tokens_in_total = 0
        tokens_out_total = 0

        for turn in range(max_turns):
            # Call LLM — multi-provider dispatch. Native Anthropic OR
            # anything without a known litellm prefix → _call_anthropic.
            # Known non-Anthropic providers (openai/, gemini/, bedrock/, ...)
            # go through litellm via providers.call_model.
            turn_t0 = time.time()
            emit_thinking_start(
                stream_stage, stream_tool,
                agent_id=stream_agent_id, model=model,
                headline=f"turn {turn + 1}/{max_turns}",
            )
            try:
                from kairos.providers import call_model, _LITELLM_PREFIXES
                if any(model.startswith(p) for p in _LITELLM_PREFIXES):
                    resp = call_model(
                        model, messages,
                        api_key=api_key,
                        tools=self.SOLVE_TOOLS,
                    )
                else:
                    resp = self._call_anthropic(
                        messages, api_key, model,
                        tools=self.SOLVE_TOOLS,
                    )
            except Exception as e:
                provider_err = _classify_model_exception(e)
                if provider_err is not None:
                    safe_msg = _sanitize_error(provider_err)
                    raise ModelProviderError(safe_msg) from e
                # Non-provider exception (e.g. JSON decode bug, unexpected error):
                # log and break so the caller gets whatever partial work was done.
                print(f"    Turn {turn + 1}: API error: {e}")
                emit_bug_found(
                    stream_stage, stream_tool,
                    severity="critical",
                    headline=f"turn {turn + 1} API error: {type(e).__name__}",
                )
                break
            emit_thinking_end(
                stream_stage, stream_tool,
                agent_id=stream_agent_id,
                elapsed_sec=time.time() - turn_t0,
            )

            # ATH-406: accumulate usage across turns + emit a running
            # token_tick. usage is {"input_tokens": N, "output_tokens": M}
            # for both litellm-normalized and native-Anthropic paths.
            # Missing/partial responses skip silently (provider returned
            # no usage) rather than fail the solve.
            usage = resp.get("usage") or {}
            tokens_in_total += int(usage.get("input_tokens") or 0)
            tokens_out_total += int(usage.get("output_tokens") or 0)
            if tokens_in_total or tokens_out_total:
                emit_token_tick(
                    tokens_in=tokens_in_total,
                    tokens_out=tokens_out_total,
                    stage=stream_stage,
                    tool=stream_tool,
                )

            stop_reason = resp.get("stop_reason", "end_turn")
            content_blocks = resp.get("content", [])

            # Build assistant message for conversation history
            assistant_content = []
            for block in content_blocks:
                if block.get("type") == "text":
                    assistant_content.append({"type": "text", "text": block["text"]})
                elif block.get("type") == "tool_use":
                    assistant_content.append(block)

            messages.append({"role": "assistant", "content": assistant_content})

            # Process tool calls
            tool_results = []
            has_tool_use = False
            for block in content_blocks:
                if block.get("type") != "tool_use":
                    continue
                has_tool_use = True
                tool_call_count += 1
                tool_name = block["name"]
                tool_args = block.get("input", {})
                emit_tool_use(
                    stream_stage, stream_tool,
                    agent_id=stream_agent_id,
                    tool_use_id=block["id"],
                    tool_name=tool_name,
                    tool_args=_stream_tool_args_summary(tool_name, tool_args),
                )
                result_text = self._exec_tool(tool_name, tool_args, data_dir, shared_dir, image)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block["id"],
                    "content": result_text[:10000],
                })
                emit_tool_result(
                    stream_stage, stream_tool,
                    agent_id=stream_agent_id,
                    tool_use_id=block["id"],
                    ok=not result_text.startswith("ERROR"),
                    preview=result_text[:200],
                )

            if tool_results:
                messages.append({"role": "user", "content": tool_results})
                continue  # Let the model keep using tools

            # No tool calls — model is done with this attempt. Score it.
            score_result = self.run_score(image, task_config, data_dir=data_dir, shared_dir=shared_dir)
            score = score_result.get("score", 0.0)
            meta = score_result.get("scoring_metadata", {})
            print(f"    Turn {turn + 1}: score={score:.3f} (tools={tool_call_count})")

            score_history.append({
                "iteration": len(score_history) + 1,
                "turn": turn + 1,
                "score": score,
                "tool_calls": tool_call_count,
                "time": round(time.time() - start_time, 1),
                "sorry_count": meta.get("sorry_count"),
                "compilation": meta.get("full_compilation"),
            })

            if score > best_score:
                best_score = score
                best_files = {}
                for f in os.listdir(data_dir):
                    fpath = os.path.join(data_dir, f)
                    if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                        try:
                            best_files[f"data/{f}"] = open(fpath).read()
                        except Exception:  # noqa: BLE001 — file read into best_files; skip unreadable
                            pass

            emit_phase_summary(
                stream_stage, stream_tool,
                headline=f"turn {turn + 1} score={score:.3f} tools={tool_call_count}",
                elapsed_sec=time.time() - start_time,
            )

            if score >= 0.95:
                print(f"  Solved! Score: {score:.3f}")
                emit_verdict(
                    stream_stage, stream_tool,
                    headline=f"SOLVED score={score:.3f} turns={turn + 1}",
                    elapsed_sec=time.time() - start_time,
                )
                break

            # Build detailed retry feedback — give the agent everything it needs
            feedback_parts = [f"Score: {score:.3f} (previous best: {best_score:.3f})."]

            # Error summary
            if meta.get("error"):
                feedback_parts.append(f"Error: {meta['error']}")

            # Property test results (integer counts or fraction-based)
            if meta.get("checks_passed") is not None:
                total = meta.get("checks_total", "?")
                feedback_parts.append(f"Property checks: {meta['checks_passed']}/{total} passed.")
            elif meta.get("checks_passed_fraction") is not None:
                frac = meta["checks_passed_fraction"]
                total = meta.get("total_checks", "?")
                feedback_parts.append(f"Property checks: {frac:.0%} passed ({total} total).")

            # Property gate (neuroscience-style)
            if meta.get("property_gate") is False:
                feedback_parts.append(f"Property gate FAILED: {meta.get('gate_reason', 'unknown')}")

            # Failed check details — extract from check_details if no failed_checks list
            if meta.get("failed_checks"):
                failed = meta["failed_checks"]
                if isinstance(failed, list):
                    feedback_parts.append(f"Failed checks: {', '.join(str(f) for f in failed[:10])}")
            elif meta.get("check_details"):
                details = meta["check_details"]
                if isinstance(details, list):
                    failed = [d for d in details if d.get("status") in ("fail", "missing")]
                    if failed:
                        summary = []
                        for d in failed[:8]:
                            key = d.get("key", "?")
                            if "student" in d and "expected" in d:
                                summary.append(f"{key}: got {d['student']}, expected {d['expected']}")
                            elif "fraction_correct" in d:
                                summary.append(f"{key}: {d['fraction_correct']:.0%} correct")
                            elif "reason" in d:
                                summary.append(f"{key}: {d['reason']}")
                            else:
                                summary.append(f"{key}: {d.get('status', 'fail')}")
                        feedback_parts.append("Failed checks:\n  " + "\n  ".join(summary))

            # Property tests array (neuroscience-style detailed)
            if meta.get("property_tests"):
                tests = meta["property_tests"]
                if isinstance(tests, list):
                    failed_tests = [t for t in tests if t.get("status") != "pass"]
                    if failed_tests:
                        test_msgs = []
                        for t in failed_tests[:5]:
                            msg = f"{t.get('type', '?')}/{t.get('key', '?')}: {t.get('status', 'fail')}"
                            if t.get("reason"):
                                msg += f" — {t['reason']}"
                            if t.get("rel_err") is not None:
                                msg += f" (rel_err={t['rel_err']:.4f})"
                            test_msgs.append(msg)
                        feedback_parts.append("Property test failures:\n  " + "\n  ".join(test_msgs))

            # Lean-specific feedback
            if meta.get("sorry_count") is not None:
                feedback_parts.append(f"Sorry count: {meta['sorry_count']}/{meta.get('sorry_denominator', '?')}")
            if meta.get("full_compilation") is False:
                feedback_parts.append("Lean compilation FAILED.")
            if meta.get("completeness") is not None:
                feedback_parts.append(f"Completeness: {meta['completeness']:.0%}")
            if meta.get("signatures_matched") is not None:
                feedback_parts.append(
                    f"Signatures matched: {meta['signatures_matched']}/{meta.get('signatures_total', '?')}")
            # Lean proof status (neuroscience/NKI-style)
            if meta.get("lean_status"):
                feedback_parts.append(f"Lean proof: {meta['lean_status']}")
                if meta.get("lean_error"):
                    feedback_parts.append(f"Lean error: {meta['lean_error'][:500]}")
            # Actual Lean compiler errors (from diagnostic step)
            if meta.get("lean_errors"):
                feedback_parts.append(f"Lean compiler output:\n{meta['lean_errors'][:1500]}")

            # Numerical results (NKI-style: max_error, mean_error, correctness)
            if meta.get("max_error") is not None:
                feedback_parts.append(f"Max error: {meta['max_error']:.6f} (tolerance: {meta.get('tolerance', '?')})")
            if meta.get("mean_error") is not None:
                feedback_parts.append(f"Mean error: {meta['mean_error']:.6f}")
            if meta.get("mse") is not None:
                feedback_parts.append(f"MSE: {meta['mse']:.6f}")
            if meta.get("relative_error") is not None:
                feedback_parts.append(f"Relative error: {meta['relative_error']:.6f}")
            if meta.get("correctness") is not None:
                feedback_parts.append(f"Correctness: {meta['correctness']:.3f}")

            # Compilation / stderr errors (Lean errors, Python tracebacks, etc.)
            if meta.get("compilation_errors"):
                errors = str(meta["compilation_errors"])
                # Filter noise, keep actionable errors
                error_lines = [l for l in errors.split("\n")
                               if l.strip() and "warning: failed to query" not in l]
                if error_lines:
                    feedback_parts.append(f"Errors:\n{chr(10).join(error_lines[:30])}")

            feedback = "\n".join(feedback_parts)
            messages.append({"role": "user", "content": (
                f"{feedback}\n\nFix the issues above and try again. Use the tools to read error "
                "messages, edit your code, and test."
            )})

        elapsed = time.time() - start_time

        # Collect final student files
        student_files = best_files or {}
        if not student_files:
            for f in os.listdir(data_dir):
                fpath = os.path.join(data_dir, f)
                if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                    try:
                        student_files[f"data/{f}"] = open(fpath).read()
                    except Exception:  # noqa: BLE001 — file read into student_files; skip unreadable
                        pass

        # Clean up
        import shutil as _shutil
        _shutil.rmtree(tmpdir, ignore_errors=True)

        # ATH-395: final verdict — distinguishes success (score≥0.95
        # emitted inside the loop), partial success (best_score<0.95
        # after all turns), and retry-exhausted.
        if best_score < 0.95:
            emit_verdict(
                stream_stage, stream_tool,
                headline=f"DONE best_score={best_score:.3f} turns={tool_call_count}",
                severity="warning" if best_score > 0 else "info",
                elapsed_sec=round(elapsed, 1),
            )

        return {
            "task": task_slug,
            "score": best_score,
            "scoring_metadata": score_result.get("scoring_metadata", {}),
            "student_files": student_files,
            "tool_calls_total": tool_call_count,
            "time_seconds": round(elapsed, 1),
            "score_history": score_history,
            # ATH-198: full agent conversation for trace upload.
            # Included so execute_job can emit it to /api/runs/<id>/traces.
            "trajectory": messages,
        }

    # ---------- Task Builder (Option A) ----------

    @staticmethod
    def _slugify_task(name: str) -> str:
        """Convert a task name to a canonical snake_case slug (underscores only)."""
        import re as _re
        s = name.strip().lower()
        s = _re.sub(r"[^a-z0-9_]+", "_", s)
        s = _re.sub(r"_+", "_", s).strip("_")
        return s

    @staticmethod
    def _find_env_checkout(env_slug: str, config: dict) -> str:
        """Locate the env checkout directory on the runner's local filesystem.

        Order: config override → ~/athanor-envs/<slug> → ~/athanor-ai-repos/environments/<slug>
        """
        override = config.get("env_checkout_path")
        if override:
            path = os.path.abspath(os.path.expanduser(override))
            if not os.path.isdir(path):
                raise RuntimeError(f"env_checkout_path does not exist: {path}")
            return path

        # Default search paths — customers typically keep envs under
        # ~/athanor-envs/ after `athanor pull`. Override with env var
        # ATHANOR_ENVS_DIR or by passing env_checkout_path in the build config.
        base = getenv_dual("ENVS_DIR", os.path.expanduser("~/athanor-envs"))
        candidates = [os.path.join(base, env_slug)]
        for path in candidates:
            if os.path.isdir(path):
                return path
        raise RuntimeError(
            f"Env checkout not found for '{env_slug}'. Tried:\n  "
            + "\n  ".join(candidates)
            + f"\nRun `athanor pull --env {env_slug}` or pass env_checkout_path in config."
        )

    @staticmethod
    def _load_fewshot_example(checkout: str) -> dict | None:
        """Pick an existing task from the checkout to use as a few-shot example."""
        configs_dir = os.path.join(checkout, "root_data", "eval", "configs")
        student_dir = os.path.join(checkout, "student_data")
        if not os.path.isdir(configs_dir):
            return None
        config_files = sorted(f for f in os.listdir(configs_dir) if f.endswith(".json"))
        if not config_files:
            return None
        cfg_name = config_files[0]
        try:
            with open(os.path.join(configs_dir, cfg_name)) as f:
                cfg = json.load(f)
        except Exception:  # noqa: BLE001 — task config json may be malformed — return None
            return None
        task_slug = cfg.get("task_id", cfg_name.replace(".json", ""))
        stub_filename = os.path.basename(cfg.get("student_file", "")) or f"{task_slug}.py"
        stub_path = os.path.join(student_dir, stub_filename)
        stub_code = ""
        if os.path.isfile(stub_path):
            try:
                with open(stub_path) as f:
                    stub_code = f.read()
            except Exception:  # noqa: BLE001 — stub file may be absent — stub_code stays empty
                pass
        return {
            "task_id": task_slug,
            "config": cfg,
            "stub_filename": stub_filename,
            "stub_code": stub_code,
        }

    def _docker_build(self, checkout: str, tag: str, timeout: int = 900,
                       no_cache: bool = False) -> None:
        """Build a container image from the env checkout, tagged with `tag`.

        Auto-detects Containerfile (the Podman/Buildah convention used by
        Athanor envs) then falls back to Dockerfile. Docker BuildKit defaults
        to `Dockerfile` only, so we always pass `-f` explicitly.
        """
        dockerfile = None
        for candidate in ("Containerfile", "Dockerfile"):
            if os.path.isfile(os.path.join(checkout, candidate)):
                dockerfile = candidate
                break
        if dockerfile is None:
            raise RuntimeError(
                f"No Containerfile or Dockerfile found in {checkout}"
            )

        argv = [
            self.docker_bin, "build",
            "-t", tag,
            "-f", os.path.join(checkout, dockerfile),
        ]
        if no_cache:
            argv.append("--no-cache")
        argv.extend(["-q", checkout])

        result = subprocess.run(
            argv, capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"docker build failed ({dockerfile}):\n"
                f"{(result.stderr or result.stdout).strip()[-2000:]}"
            )

    def _verify_file_in_image(self, tag: str, container_path: str,
                               timeout: int = 30) -> bool:
        """Return True if `container_path` exists inside the image `tag`.
        Used by run_build to catch stale-cache COPY failures BEFORE stub
        scoring crashes with FileNotFoundError (ATH-99).

        Must run as uid 0 — /root_data is chmod 0700 root-owned across
        all envs, so the default `USER student` from the Containerfile
        can't even stat into the directory. Without --user 0:0 the test
        returns false-negative on every real config and triggers a
        spurious --no-cache rebuild.
        """
        result = subprocess.run(
            [self.docker_bin, "run", "--rm", "--user", "0:0",
             "--entrypoint", "test", tag, "-f", container_path],
            capture_output=True, text=True, timeout=timeout,
        )
        return result.returncode == 0

    def _docker_tag(self, src: str, dst: str) -> None:
        """Retag a local image (docker tag src dst)."""
        result = subprocess.run(
            [self.docker_bin, "tag", src, dst],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode != 0:
            raise RuntimeError(f"docker tag failed: {result.stderr.strip()[:500]}")

    def _docker_rmi(self, tag: str) -> None:
        """Best-effort remove a local image tag (ignores errors)."""
        try:
            subprocess.run(
                [self.docker_bin, "rmi", "-f", tag],
                capture_output=True, text=True, timeout=30,
            )
        except Exception:  # noqa: BLE001 — docker rmi cleanup best-effort
            pass

    def _docker_image_sha(self, tag: str) -> str | None:
        """Return the 12-char short sha256 digest for a local image tag,
        or None on error. Used in ATH-95 build-trace events so the
        platform UI can tie each build run to a specific image artefact.
        """
        try:
            r = subprocess.run(
                [self.docker_bin, "image", "inspect", "-f", "{{.Id}}", tag],
                capture_output=True, text=True, timeout=10,
            )
            if r.returncode != 0:
                return None
            digest = r.stdout.strip()  # e.g., "sha256:abc123..."
            if digest.startswith("sha256:"):
                return digest[7:19]  # short form, 12 chars
            return digest[:12] or None
        except Exception:  # noqa: BLE001 — image digest parse; missing/malformed → return None
            return None

    def run_build(self, image: str, config: dict, api_key: str,
                  job_id: str | None = None) -> dict:
        """Generate and validate a new task using Opus 4.6 (Option A).

        Flow:
          1. Locate the env checkout and load a few-shot example task.
          2. Check slug collision (config + stub file).
          3. Call Opus with the customer's key to generate stub + reference + config.
          4. Write files to canonical paths (root_data/eval/configs/, student_data/).
          5. Build a fresh local image from the checkout.
          6. Score stub (expect low) and reference (expect high) against the fresh image.
          7. On success, retag the fresh image as the env image so subsequent jobs see it.
             On failure, roll back the file writes and drop the build tag.

        Returns metadata only — generated content stays on the customer's machine.

        When `job_id` is passed (from execute_job's `job["id"]`), emits per-phase
        trace events to POST /api/runner/build-trace. Platform UI
        (src/app/tasks/build/page.tsx) renders a live PhaseTimeline from these
        events. See ATH-95 for the contract. All emits are best-effort — a
        trace outage never fails a build.
        """
        env_slug = config.get("environment", "") or image.rsplit("/", 1)[-1].split(":", 1)[0]
        task_name = (config.get("task_name") or "").strip()
        if not task_name:
            return {"error": "task_name is required"}

        description = config.get("description", "")
        difficulty = config.get("difficulty", "medium")
        category = config.get("category", "implementation")
        proof_backend = config.get("proof_backend", "none")
        scoring_type = config.get("scoring_type", "property_tests")
        scoring_details = config.get("scoring_details", "")
        additional_context = config.get("additional_context", "")

        task_id = self._slugify_task(task_name)
        if not task_id:
            return {"error": f"Could not derive a valid slug from task_name: {task_name!r}"}

        # ATH-110: stub filename must match what scoring.py will read inside
        # the container. Lean envs: scoring.py reads `config["lean_file"]`
        # (a /workdir/data/<PascalCase>.lean path); any other stub filename
        # makes the file invisible to scoring even if it's written. Derive
        # canonically from task_slug via the shared helper — do NOT trust
        # LLM-emitted stub_filename for Lean tasks.
        is_lean = proof_backend in ("lean", "lean4")
        stub_filename = (
            task_slug_to_lean_filename(task_id) if is_lean else f"{task_id}.py"
        )

        # 1. Locate checkout
        try:
            checkout = self._find_env_checkout(env_slug, config)
        except RuntimeError as e:
            return {"error": str(e), "task_id": task_id, "status": "failed"}

        config_path = os.path.join(checkout, "root_data", "eval", "configs", f"{task_id}.json")
        stub_path = os.path.join(checkout, "student_data", stub_filename)

        # 2. Slug collision check
        if os.path.exists(config_path):
            return {"error": f"Task slug '{task_id}' already exists at {config_path}",
                    "task_id": task_id, "status": "failed"}
        if os.path.exists(stub_path):
            return {"error": f"Stub file '{stub_filename}' already exists at {stub_path}",
                    "task_id": task_id, "status": "failed"}

        # 3. Load few-shot
        example = self._load_fewshot_example(checkout)
        if not example:
            return {"error": f"No existing tasks found in {checkout}/root_data/eval/configs/ "
                             "to use as a few-shot example. Add at least one task first.",
                    "task_id": task_id, "status": "failed"}

        example_json = json.dumps(example["config"], indent=2)
        example_stub = example["stub_code"][:6000]

        print(f"  Building task '{task_id}' in {env_slug}")
        print(f"  Checkout: {checkout}")
        print(f"  Few-shot from: {example['task_id']}")

        # 4. Build prompt
        prompt = (
            f'Generate a new training task for the "{env_slug}" environment.\n\n'
            f"TASK SPEC:\n"
            f"  name: {task_name}\n"
            f"  slug (canonical): {task_id}\n"
            f"  description: {description}\n"
            f"  difficulty: {difficulty}\n"
            f"  category: {category}\n"
            f"  proof_backend: {proof_backend}\n"
            f"  scoring_type: {scoring_type}\n"
            + (f"  scoring_details: {scoring_details}\n" if scoring_details else "")
            + (f"  additional_context: {additional_context}\n" if additional_context else "")
            + "\n"
            f"FEW-SHOT EXAMPLE from this environment (task '{example['task_id']}'):\n\n"
            f"--- EXAMPLE CONFIG ({example['task_id']}.json) ---\n{example_json}\n\n"
            f"--- EXAMPLE STUB ({example['stub_filename']}) ---\n{example_stub}\n\n"
            "YOUR JOB: Generate a NEW task following the SAME config schema and the SAME stub "
            "file layout as the example. Preserve every env-specific field in the config "
            "(scoring parameters, etc.) — copy the shape but pick appropriate values for the new task.\n\n"
            "CRITICAL RULES:\n"
            "  - The stub must parse and import cleanly but produce a LOW score (< 0.5).\n"
            "  - **Every method in the stub MUST contain real code, even if buggy.**\n"
            "    NEVER use `pass` or an empty body. The environment runs an anti-cheat\n"
            "    detector that rejects empty method bodies as `null_implementation`\n"
            "    and gives the stub 0. Write plausible-looking wrong code, not placeholders.\n"
            "  - The reference must produce a HIGH score (>= 0.5), clearly beating the stub.\n"
            f"  - scoring_config.task_id must be exactly: {task_id}\n"
            f"  - scoring_config.student_file must be exactly: /workdir/data/{stub_filename}\n"
            "  - **COPY `scenario_file` and ANY other file-path reference EXACTLY from the\n"
            "    few-shot example.** Do not invent new file paths — any file you reference\n"
            "    must already exist in the container. You are only creating the stub and the\n"
            "    scoring config; you are NOT creating new scenario/data/shared files.\n"
            "  - You MAY retune scoring parameters (sigmoid_center, sigmoid_scale, decay\n"
            "    factors, seed, description, category, difficulty) to suit the new task.\n"
            "  - stub_code and reference_code must both be valid Python the scoring script can import.\n\n"
            "OUTPUT FORMAT: Respond with ONLY a single JSON object (no prose, no markdown fences) "
            "with these keys:\n"
            "  scoring_config : object, same schema as the example config\n"
            "  stub_code      : string, full Python source for the stub\n"
            "  reference_code : string, full Python source for a working reference solution\n"
            "  proof_template : string or null (only required if proof_backend != 'none')\n"
        )

        # 5. Call Opus
        self._emit_phase(job_id, "spec_generation_started", model=DEFAULT_SPEC_GENERATION_MODEL)
        try:
            resp = self._call_anthropic(
                [{"role": "user", "content": prompt}],
                api_key, DEFAULT_SPEC_GENERATION_MODEL,
                # Anthropic = 200k per Aidan 2026-04-23; spec-generation
                # is a heavy reasoning+tool call
                max_tokens=200000,
            )
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            self._emit_phase(job_id, "failed",
                             phase_failed="spec_generation", stderr=str(e)[:1500])
            return {"error": f"Anthropic API call failed: {e}",
                    "task_id": task_id, "status": "failed"}
        self._emit_phase(job_id, "spec_generation_complete",
                         model=DEFAULT_SPEC_GENERATION_MODEL,
                         tokens=resp.get("usage", {}).get("output_tokens"))

        text = "".join(
            b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text"
        )
        if not text:
            return {"error": "Empty response from Opus",
                    "task_id": task_id, "status": "failed"}

        # Parse JSON (strip markdown fence if present, else take outermost braces)
        import re as _re
        fence = _re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
        if fence:
            json_text = fence.group(1)
        else:
            start = text.find("{")
            end = text.rfind("}")
            if start < 0 or end <= start:
                return {"error": "No JSON object found in Opus response",
                        "raw": text[:2000], "task_id": task_id, "status": "failed"}
            json_text = text[start:end + 1]

        try:
            task_data = json.loads(json_text)
        except json.JSONDecodeError as e:
            return {"error": f"JSON parse failed: {e}",
                    "raw": json_text[:2000], "task_id": task_id, "status": "failed"}

        scoring_config = task_data.get("scoring_config")
        stub_code = task_data.get("stub_code", "")
        reference_code = (
            task_data.get("reference_code")
            or task_data.get("reference_solution")
            or task_data.get("solution")
            or ""
        )
        proof_template = task_data.get("proof_template")

        if not isinstance(scoring_config, dict):
            return {"error": "Opus response missing 'scoring_config' object",
                    "task_id": task_id, "status": "failed"}
        if not stub_code:
            return {"error": "Opus response missing 'stub_code'",
                    "task_id": task_id, "status": "failed"}
        if not reference_code:
            return {"error": "Opus response missing 'reference_code' (required for validation)",
                    "task_id": task_id, "status": "failed"}

        # Force canonical fields (Opus occasionally drifts).
        # ATH-110: for Lean tasks scoring.py reads `lean_file`, not
        # `student_file` — if this is a Lean task, overwrite both to the
        # canonical /workdir/data/<PascalCase>.lean path so scoring finds
        # the stub+reference files run_score writes during validation.
        scoring_config["task_id"] = task_id
        canonical_student_path = f"/workdir/data/{stub_filename}"
        scoring_config["student_file"] = canonical_student_path
        if is_lean:
            scoring_config["lean_file"] = canonical_student_path
        scoring_config.setdefault("description", description or task_name)
        if category:
            scoring_config.setdefault("category", category)
        if difficulty:
            scoring_config.setdefault("difficulty", difficulty)

        # 6. Write files + build + validate, with rollback on failure
        written_files: list[str] = []
        build_tag = f"athanor-build-{task_id}:validate"
        validation: dict = {}

        # Track which phase is in flight so `failed` emits can report it.
        _phase_in_flight = "setup"
        try:
            _phase_in_flight = "file_write"
            self._emit_phase(job_id, "file_write_started")
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            os.makedirs(os.path.dirname(stub_path), exist_ok=True)

            with open(config_path, "w") as f:
                json.dump(scoring_config, f, indent=2)
            written_files.append(config_path)

            with open(stub_path, "w") as f:
                f.write(stub_code)
            written_files.append(stub_path)

            # Optional proof template
            if proof_template and proof_backend and proof_backend != "none":
                proof_dir = os.path.join(checkout, "root_data", "eval", "proofs")
                os.makedirs(proof_dir, exist_ok=True)
                proof_path = os.path.join(proof_dir, f"{task_id}.template")
                with open(proof_path, "w") as f:
                    f.write(proof_template)
                written_files.append(proof_path)

            self._emit_phase(job_id, "file_write_complete",
                             files=[os.path.relpath(p, checkout) for p in written_files])

            _phase_in_flight = "container_build"
            self._emit_phase(job_id, "container_build_started")
            print(f"  Building image {build_tag}...")
            _t0 = time.monotonic()
            self._docker_build(checkout, build_tag)

            # ATH-99 defensive verification: confirm the freshly-written
            # config actually landed inside the image. If it didn't, a
            # stale COPY layer is being reused — rebuild once with
            # --no-cache and re-check. If still missing, fail with a
            # clear error instead of letting stub scoring crash on
            # FileNotFoundError. The --no-cache rebuild counts toward
            # container_build wall time for ATH-95 emit purposes.
            expected_in_image = f"/root_data/eval/configs/{task_id}.json"
            if not self._verify_file_in_image(build_tag, expected_in_image):
                print(f"  WARN: {expected_in_image} missing from image; "
                      f"rebuilding with --no-cache")
                self._docker_rmi(build_tag)
                self._docker_build(checkout, build_tag, no_cache=True)
                if not self._verify_file_in_image(build_tag, expected_in_image):
                    raise RuntimeError(
                        f"Config {expected_in_image} not in built image after "
                        f"--no-cache rebuild. Checkout={checkout} — confirm "
                        f"Containerfile has `COPY root_data/ /root_data/` and "
                        f"that {config_path} exists on disk."
                    )

            self._emit_phase(job_id, "container_build_complete",
                             duration_s=round(time.monotonic() - _t0, 2),
                             image_sha=self._docker_image_sha(build_tag))

            _phase_in_flight = "validation"
            self._emit_phase(job_id, "validation_started")
            task_cfg = {"task_slug": task_id, "stub_filename": stub_filename}

            print("  Scoring stub...")
            stub_result = self.run_score(build_tag, task_cfg, student_code=stub_code)
            stub_score = float(stub_result.get("score", 0.0) or 0.0)

            print("  Scoring reference...")
            ref_result = self.run_score(build_tag, task_cfg, student_code=reference_code)
            reference_score = float(ref_result.get("score", 0.0) or 0.0)

            # Validation thresholds — the actual values come from env config
            # (via BUILD_VALIDATION_* envvars or per-env overrides). Fallback
            # defaults are intentionally reasonable but NOT the production
            # calibration — see your env's build pipeline docs.
            ref_min = float(getenv_dual("BUILD_REF_MIN", "0.5"))
            stub_max = float(getenv_dual("BUILD_STUB_MAX", "0.5"))
            delta_min = float(getenv_dual("BUILD_DELTA_MIN", "0.2"))

            validation = {
                "stub_score": round(stub_score, 4),
                "reference_score": round(reference_score, 4),
                "stub_metadata": stub_result.get("scoring_metadata", {}),
                "reference_metadata": ref_result.get("scoring_metadata", {}),
            }
            passed = (
                reference_score >= ref_min
                and stub_score < stub_max
                and reference_score > stub_score + delta_min
            )
            validation["passed"] = passed
            print(f"  Stub={stub_score:.3f}  Reference={reference_score:.3f}  passed={passed}")
            self._emit_phase(job_id, "validation_complete",
                             stub_score=round(stub_score, 4),
                             reference_score=round(reference_score, 4),
                             passed=passed)

            if not passed:
                raise RuntimeError(
                    f"Validation failed: stub={stub_score:.3f}, reference={reference_score:.3f}. "
                    "Task did not meet the build-pipeline thresholds."
                )

            # Success: retag the validated image as the env's main local tag so
            # subsequent score/solve jobs on this runner pick up the new task.
            _phase_in_flight = "upload_metadata"
            self._emit_phase(job_id, "upload_metadata")
            try:
                self._docker_tag(build_tag, image)
            except RuntimeError as e:
                print(f"  WARN: could not retag to {image}: {e}")
            self._docker_rmi(build_tag)

            # Success return shape matches the platform UI contract
            # (src/app/tasks/build/page.tsx → BuildResult).
            return {
                "task_slug": task_id,
                "env_slug": env_slug,
                "task_name": task_name,
                "status": "validated",
                "validation": validation,
                "files_written": [os.path.relpath(p, checkout) for p in written_files],
            }

        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            self._emit_phase(job_id, "failed",
                             phase_failed=_phase_in_flight, stderr=str(e)[:1500])
            # Roll back files so the checkout is left clean
            for p in written_files:
                try:
                    os.remove(p)
                except Exception:  # noqa: BLE001 — cleanup os.remove on written_files; tolerate already-removed
                    pass
            self._docker_rmi(build_tag)
            return {
                "error": f"Build failed: {e}",
                "task_slug": task_id,
                "env_slug": env_slug,
                "task_name": task_name,
                "status": "failed",
                "validation": validation,
            }

    def _emit_trace(
        self,
        run_id: str,
        task_id: str,
        messages: list,
        score: float | None,
        model: str,
        phase: int | None = 1,
    ) -> None:
        """Best-effort POST of an agent conversation transcript to the platform.

        Sends the full ``messages`` list (the agent trajectory) to
        ``POST /api/runs/<run_id>/traces`` so the platform's run-detail
        page can display the transcript for BYOC jobs (ATH-198).

        Auth: same ``ATHANOR_TOKEN`` bearer used by ``/api/runner/results``.
        The route (ATH-139 / ATH-63 era) handles Storage upload itself; the
        runner only needs to POST inline.

        Failure semantics: any exception is logged at WARN and swallowed.
        A trace outage must never regress job-level reliability.

        Safety: ``messages`` are shallow-copied and auth headers are stripped
        before sending, so no token material leaks in the trace blob.
        """
        if not run_id:
            return  # no run_id means CLI invocation — nowhere to send

        # Sanitize: strip Authorization headers echoed into tool-result
        # content (e.g. if the agent read a config file that contained the
        # token). We do a conservative string-level redaction on the
        # JSON-serialized blob rather than deep-traversing the message tree.
        try:
            raw_blob = json.dumps(messages)
            safe_blob = _REDACT_RE.sub("[REDACTED]", raw_blob)
            safe_messages = json.loads(safe_blob)
        except Exception:  # noqa: BLE001 — broad-catch fallback
            # Fallback: send an empty list rather than risk leaking data.
            safe_messages = []

        payload: dict = {
            "trace": {
                "task_id": task_id,
                "messages": safe_messages,
                "score": score,
                "token_count": len(safe_messages),
                "phase": phase,
                # cost_usd_estimate: BYOC runner uses direct urllib (not
                # LiteLLM), so no per-call cost metadata is available.
                # The platform column accepts NULL; omit the field.
            },
        }

        try:
            body = json.dumps(payload).encode()
            req = urllib.request.Request(
                f"{self.platform_url}/api/runs/{run_id}/traces",
                data=body,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                    "User-Agent": f"athanor-runner/{_VERSION}",
                },
                method="POST",
            )
            self._opener.open(req, timeout=30).read()
            logger.debug("trace uploaded for run_id=%s task=%s", run_id, task_id)
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.warning(
                "trace upload failed for run_id=%s task=%s — %s (job still succeeded)",
                run_id, task_id, exc,
            )

    def execute_job(self, job: dict) -> dict:
        """Execute a job and return the result."""
        job_type = job["type"]
        image = job["image"]
        config = job.get("config", {})
        run_id: str = job.get("run_id", "")

        print(f"  Job {job['id'][:8]}: {job_type} on {job['environment']}")

        self.pull_image(image)

        if job_type == "score":
            student_code = config.get("student_code")
            result = self.run_score(image, config, student_code)
            print(f"  Score: {result['score']:.3f}")
            # score jobs have no agent trajectory — nothing to trace
            return result

        elif job_type == "solve":
            model = config.get("model", DEFAULT_RUNNER_MODEL)
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            max_turns = config.get("max_turns", 30)
            result = self.run_solve(image, config, model=model, api_key=api_key, max_turns=max_turns)
            print(f"  Score: {result.get('score', 0):.3f} ({result.get('tool_calls_total', 0)} turns)")
            # ATH-198: emit transcript so run-detail page shows agent trace.
            # Wrapped in try/except so a buggy _emit_trace override never
            # surfaces as a job failure.
            if run_id and "trajectory" in result:
                try:
                    self._emit_trace(
                        run_id=run_id,
                        task_id=config.get("task_slug", ""),
                        messages=result["trajectory"],
                        score=result.get("score"),
                        model=model,
                    )
                except Exception as _te:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                    logger.warning("trace emit error (job unaffected): %s", _te)
            return result

        elif job_type == "evaluate":
            model = config.get("model", DEFAULT_RUNNER_MODEL)
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise RuntimeError("ANTHROPIC_API_KEY required for evaluate jobs")
            task_slugs = config.get("task_slugs") or config.get("tasks") or []
            if not task_slugs:
                # Discover tasks from container
                ls_result = subprocess.run(
                    [self.docker_bin, "run", "--rm", image, "ls", "/root_data/eval/configs/"],
                    capture_output=True, text=True, timeout=30,
                )
                if ls_result.returncode == 0:
                    task_slugs = [
                        f.replace(".json", "")
                        for f in ls_result.stdout.strip().split("\n")
                        if f.endswith(".json")
                    ]
            results = []
            for task_slug in task_slugs:
                stub_filename = f"{task_slug}.py"
                stub_result = subprocess.run(
                    [self.docker_bin, "run", "--rm", image, "cat", f"/workdir/data/{stub_filename}"],
                    capture_output=True, text=True, timeout=15,
                )
                stub_code = stub_result.stdout if stub_result.returncode == 0 else ""
                task_config = {
                    "task_slug": task_slug,
                    "task_description": task_slug,
                    "stub_code": stub_code,
                    "stub_filename": stub_filename,
                }
                try:
                    result = self.run_solve(image, task_config, model=model, api_key=api_key)
                    results.append(result)
                    print(f"  {task_slug}: score={result.get('score', 0):.3f}")
                    # ATH-198: emit per-task trace for evaluate jobs
                    if run_id and "trajectory" in result:
                        try:
                            self._emit_trace(
                                run_id=run_id,
                                task_id=task_slug,
                                messages=result["trajectory"],
                                score=result.get("score"),
                                model=model,
                            )
                        except Exception as _te:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                            logger.warning("trace emit error (job unaffected): %s", _te)
                except Exception as e:  # noqa: BLE001 — broad-catch fallback
                    results.append({
                        "task": task_slug,
                        "score": 0.0,
                        "scoring_metadata": {"error": str(e)},
                        "student_files": {},
                        "tool_calls_total": 0,
                        "time_seconds": 0,
                    })
            scores = [r.get("score", 0.0) for r in results]
            mean_score = sum(scores) / len(scores) if scores else 0.0
            return {
                "job_type": "evaluate",
                "model": model,
                "results": results,
                "mean_score": round(mean_score, 4),
                "task_count": len(results),
            }

        elif job_type == "build":
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                return {"error": "ANTHROPIC_API_KEY required for build jobs"}
            # Inject the env slug from the job-level field so run_build doesn't
            # have to derive it from the image name.
            if not config.get("environment"):
                config = {**config, "environment": job.get("environment", "")}
            # Thread job["id"] through to run_build so _emit_phase can tie
            # per-phase trace events to the runner_jobs row (ATH-95). When
            # invoked via CLI without a platform job, job_id is None and
            # _emit_phase no-ops.
            result = self.run_build(image, config, api_key=api_key,
                                    job_id=job.get("id"))
            print(f"  Build: {result.get('task_slug', 'unknown')} ({result.get('status', '?')})")
            return result

        return {"error": f"Unknown job type: {job_type}"}

    def _ensure_ghcr_login(self) -> None:
        """Fetch a short-lived GHCR PAT from the platform and run docker login.

        Called once at runner startup before the poll loop so that subsequent
        ``docker pull`` calls succeed on a fresh BYOC VM.

        Safety invariant: the token is NEVER logged or included in exception
        messages — only ``registry`` and HTTP status codes appear in output.
        """
        url = f"{self.platform_url}/api/runner/ghcr-token"
        req = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": f"athanor-runner/{_VERSION}",
            },
            method="GET",
        )
        try:
            resp = self._opener.open(req, timeout=15)
            payload = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            if e.code == 401:
                raise GHCRLoginError(
                    "Onboarding error: the platform rejected this runner's sync token "
                    "(HTTP 401 from /api/runner/ghcr-token). "
                    "Check that ATHANOR_TOKEN is correct and the token has not been revoked."
                )
            raise GHCRLoginError(
                f"Onboarding error: could not fetch GHCR token from platform "
                f"(HTTP {e.code} from /api/runner/ghcr-token). "
                "Verify platform connectivity and try again."
            )
        except urllib.error.URLError as e:
            raise GHCRLoginError(
                f"Onboarding error: cannot reach platform at {self.platform_url} "
                f"to fetch GHCR token: {e.reason}"
            )

        ghcr_token: str = payload["token"]
        registry: str = payload["registry"]
        username: str = payload["username"]

        # Pass token via stdin only — never in argv or log output.
        result = subprocess.run(
            [self.docker_bin, "login", registry, "-u", username, "--password-stdin"],
            input=ghcr_token,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            # Sanitised error: status code only, no token material.
            raise GHCRLoginError(
                f"docker login to {registry} failed (status={result.returncode}). "
                "Check that the GHCR PAT returned by the platform is valid."
            )
        print(f"GHCR login OK ({registry})")

    def run_forever(self):
        """Main loop — poll for jobs and execute them."""
        if not self.runner_id:
            self.register()

        # Authenticate with GHCR once at startup so docker pull succeeds on
        # fresh BYOC VMs.  GHCRLoginError is intentionally not caught here —
        # it bubbles to the caller so the process exits non-zero and
        # systemd/k8s restarts it with a clear onboarding error message.
        self._ensure_ghcr_login()

        print(f"Runner '{self.name}' ready. Polling {self.platform_url}...")
        print(f"Docker: {self.docker_bin}")
        print()

        consecutive_empty = 0
        while True:
            try:
                job = self.poll()
                if job:
                    consecutive_empty = 0
                    try:
                        result = self.execute_job(job)
                        self.report(job["id"], result=result)
                    except ModelProviderError as e:
                        # Provider / auth / network error before scoring ran.
                        # Log at ERROR level for journalctl visibility, then
                        # report the job as failed with the sanitized message.
                        logger.error("job %s failed at model call: %s", job["id"], e)
                        print(f"  Job failed (provider error): {e}")
                        self.report(job["id"], error=str(e))
                    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
                        print(f"  Job failed: {e}")
                        self.report(job["id"], error=str(e))
                else:
                    consecutive_empty += 1
                    # Back off: 2s → 5s → 10s
                    delay = min(2 * consecutive_empty, 10)
                    time.sleep(delay)

            except KeyboardInterrupt:
                print("\nShutting down...")
                break
            except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
                print(f"Poll error: {e}")
                time.sleep(10)
