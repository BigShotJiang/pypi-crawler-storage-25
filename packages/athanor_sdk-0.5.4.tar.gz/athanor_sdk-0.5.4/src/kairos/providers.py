"""Multi-provider model dispatch.

Resolves `--model` strings to API providers:
  - claude/anthropic → native Anthropic Messages API (no extra deps)
  - anything else → LiteLLM (if installed) covers openai, gemini, bedrock,
    azure, mistral, xai, groq, openrouter, ollama, vertex-ai, etc.

Install the multi-provider extra to enable non-Anthropic models:
    pip install "athanor-ai[multi-model]"

Design: the SDK stays anthropic-only by default (no litellm import at
module load) so `pip install athanor-ai` remains a light dependency. When
a user passes e.g. `openai/gpt-5` or `bedrock/anthropic.claude-3-sonnet`,
we import litellm lazily and dispatch through it. Unknown providers
raise a clear error telling them to install the extra.

Supported model-ID prefixes (all via litellm unless noted):
  - anthropic/*       (native path, no litellm)
  - claude-*          (native path, no litellm)
  - openai/*          — OpenAI API
  - gemini/*          — Google AI Studio (direct)
  - vertex_ai/*       — Google Vertex AI
  - bedrock/*         — AWS Bedrock (claude, llama, titan, etc.)
  - azure/*           — Azure OpenAI
  - azure_ai/*        — Azure AI Foundry (inc. Claude, Mistral)
  - mistral/*         — Mistral La Plateforme
  - xai/*             — xAI grok
  - groq/*            — Groq
  - openrouter/*      — OpenRouter
  - ollama/*          — Ollama local
  - cohere/*          — Cohere
"""
from __future__ import annotations

import os
from typing import Any


# Model-ID prefixes that can be handled by Runner._call_anthropic directly
# (Anthropic native API, no litellm needed).
_NATIVE_ANTHROPIC_PREFIXES = ("anthropic/", "claude-")

# Model-ID prefixes we know about and dispatch through litellm.
_LITELLM_PREFIXES = (
    "openai/", "gemini/", "google/", "vertex_ai/", "bedrock/",
    "azure/", "azure_ai/", "mistral/", "xai/", "groq/",
    "openrouter/", "ollama/", "cohere/", "together/", "fireworks/",
    "databricks/", "replicate/", "perplexity/", "deepseek/",
    "sambanova/", "cerebras/",
)


def is_native_anthropic(model: str) -> bool:
    """True if this model goes through Runner._call_anthropic (no litellm)."""
    return model.startswith(_NATIVE_ANTHROPIC_PREFIXES)


# ATH-399 (2026-04-20) — model-aware max_tokens defaults.
#
# Reasoning models (kimi, gemini-2.5-*, o1, o3, deepseek-r1, ...) burn
# the `max_tokens` budget on an internal `reasoning_content` phase
# BEFORE they start emitting user-visible `content`. A 2000-token
# budget on flash produces a ~500-char truncated response because the
# first 1400+ tokens went to reasoning. Same for kimi — worse, because
# kimi is more verbose in its reasoning.
#
# Concrete evidence from 2026-04-20 qa CEGAR dogfood:
#   - kimi-k2.5 at max_tokens=8000 on a 3k-token prompt: used 3592
#     completion tokens (3414 reasoning + 178 content). content=None
#     at max_tokens=1500; barely-fits at 8000.
#   - gemini-2.5-flash at max_tokens=4000 on the same prompt: content
#     truncated at 599 chars mid-JSON; at 8000, emitted 578 chars
#     complete. Reasoning consumed ~3400 tokens.
#   - Non-reasoning models (sonnet-4-6, opus-4-6, gpt-5) hit the
#     existing 2000-8000 budget just fine.
#
# Aidan 2026-04-20 2115Z: "bump up tokens we must not lose agent
# progress due to this issue that is extremely wasteful. But also
# needs to be model aware" — hence this table rather than a blanket bump.
#
# Budget is per-call max_tokens. Retry/loop orchestration is out of
# scope; this just prevents silent truncation inside one call.
_MAX_TOKENS_BY_MODEL_PREFIX: dict[str, int] = {
    # Reasoning models — need 8k+ budget to survive the internal
    # reasoning pass and still emit meaningful content.
    "openai/kimi":             16000,
    "openai/o1":                16000,
    "openai/o3":                16000,
    "openai/gpt-5-reasoning":   16000,
    "gemini/gemini-2.5-flash":   8000,
    "gemini/gemini-2.5-pro":    16000,
    "gemini/gemini-3":          16000,  # 3.x family (flash, pro, pro-preview)
    "deepseek/deepseek-r1":     16000,
    "deepseek/r1":              16000,
    # Non-reasoning models — the existing 8192 default is fine.
    # Entries here are explicit overrides for clarity; falls back to
    # DEFAULT_MAX_TOKENS for anything not listed.
}

# Conservative non-reasoning default. Previously hard-coded as
# max_tokens=8192 in call_model's signature; kept at the same value
# so behavior is unchanged for Sonnet/Opus/GPT callers.
DEFAULT_MAX_TOKENS = 8192


# ------------------------------------------------------------------
# Per-model concurrency cap (ATH-400).
# ------------------------------------------------------------------
#
# Azure-hosted model endpoints have per-deployment concurrent-request
# limits. Exceeding them returns 429 "Server at maximum concurrent
# capacity" — our retry loop below absorbs it, but the retry costs
# time and (on longer outages) exhausts. Better to throttle client-
# side so we never hit the cap in the first place.
#
# Evidence from qa 2026-04-20 CEGAR dogfood:
#   - Azure Kimi deployment: cap = 8 concurrent. Fleet-wide parallel
#     evaluation bursts trigger 429s.
#   - Azure Gemini deployment: lower; conservative 4.
#   - Anthropic (Sonnet/Opus via apmartin): higher; 16 is safe.
#
# Implementation: one threading.Semaphore per longest-prefix match in
# `_CONCURRENCY_CAP`. Unmatched models are unlimited (no throttle).
# Env override: `ATHANOR_MAX_CONCURRENT_<SLUG>` (SLUG = prefix with
# non-alphanumeric → '_', upper-cased), e.g.
#   ATHANOR_MAX_CONCURRENT_OPENAI_KIMI=12
#
# Gate is per-prefix, not per-exact-model, so
# `openai/kimi-k2.5` and `openai/kimi-large` share the same Azure
# deployment's 8-concurrent limit (they're the same endpoint).
_CONCURRENCY_CAP: dict[str, int] = {
    "openai/kimi":             8,   # Azure Kimi endpoint = 8 concurrent
    "openai/mistral":          8,   # Same Azure athanor endpoint as Kimi
    "openai/deepseek":         8,   # Same Azure athanor endpoint
    "gemini/":                 4,   # Conservative; Google AI has lower caps
    "azure_ai/claude":        16,   # apmartin endpoint handles more
}

# Lazy semaphore registry: one per prefix that's ever been hit.
# Import-order-safe (built on first use, not module load).
_SEMAPHORE_LOCK = None  # created lazily to avoid threading import at load
_SEMAPHORES: dict[str, "object"] = {}  # actually threading.Semaphore


def _prefix_env_slug(prefix: str) -> str:
    """Turn a model prefix into its env-override slug.

    `openai/kimi` -> `OPENAI_KIMI`; `gemini/` -> `GEMINI`;
    `azure_ai/claude` -> `AZURE_AI_CLAUDE`.
    """
    slug = "".join(c if c.isalnum() else "_" for c in prefix)
    return slug.strip("_").upper()


def _concurrency_cap_for(model: str) -> tuple[str, int] | None:
    """Return (matched_prefix, cap) or None if the model is unthrottled.

    Longest-prefix match, then env override by prefix slug.
    """
    best_prefix = ""
    best_cap = 0
    for prefix, cap in _CONCURRENCY_CAP.items():
        if model.startswith(prefix) and len(prefix) > len(best_prefix):
            best_prefix = prefix
            best_cap = cap
    if not best_prefix:
        return None
    env_name = f"ATHANOR_MAX_CONCURRENT_{_prefix_env_slug(best_prefix)}"
    override = os.environ.get(env_name)
    if override is not None:
        try:
            override_int = int(override)
            if override_int > 0:
                best_cap = override_int
        except ValueError:
            pass  # ignore bad values; use table default
    return best_prefix, best_cap


def _get_semaphore_for(model: str):
    """Return a threading.Semaphore for model's prefix, or None.

    None = unthrottled (caller should not enter a context manager).
    """
    import threading
    global _SEMAPHORE_LOCK
    if _SEMAPHORE_LOCK is None:
        _SEMAPHORE_LOCK = threading.Lock()

    match = _concurrency_cap_for(model)
    if match is None:
        return None
    prefix, cap = match
    with _SEMAPHORE_LOCK:
        sem = _SEMAPHORES.get(prefix)
        if sem is None:
            sem = threading.Semaphore(cap)
            _SEMAPHORES[prefix] = sem
        return sem


def default_max_tokens_for(model: str) -> int:
    """Return the recommended max_tokens for a model ID.

    Longest-prefix match against `_MAX_TOKENS_BY_MODEL_PREFIX`. If no
    entry matches, returns `DEFAULT_MAX_TOKENS`.

    Callers should use this only as a DEFAULT — explicit max_tokens
    passed by the caller always wins. The point is to avoid silent
    truncation on reasoning models when the caller doesn't know to
    override.
    """
    # Longest prefix wins so `openai/kimi-k2.5` picks the `openai/kimi`
    # entry rather than anything shorter.
    best_prefix = ""
    best_budget = DEFAULT_MAX_TOKENS
    for prefix, budget in _MAX_TOKENS_BY_MODEL_PREFIX.items():
        if model.startswith(prefix) and len(prefix) > len(best_prefix):
            best_prefix = prefix
            best_budget = budget
    return best_budget


def _require_litellm():
    """Lazy import. Raises a clear error if the multi-model extra isn't installed."""
    try:
        import litellm
        return litellm
    except ImportError as e:
        raise ImportError(
            "Multi-provider model support requires litellm. Install with:\n"
            "    pip install 'athanor-ai[multi-model]'\n"
            "Or use an Anthropic model (anthropic/claude-* or claude-*) which "
            "works without litellm."
        ) from e


def call_model(
    model: str,
    messages: list[dict],
    *,
    api_key: str | None = None,
    tools: list[dict] | None = None,
    max_tokens: int | None = None,
    temperature: float = 0.0,
    extra: dict | None = None,
) -> dict:
    """Dispatch a chat-completion call to the right provider.

    For native Anthropic models, the caller should use Runner._call_anthropic
    directly — this function dispatches everything else through litellm.

    Returns a dict in Anthropic-ish shape:
      {"content": [...], "stop_reason": str, "usage": {...}}

    litellm's `completion()` returns OpenAI-shape; we convert for
    consistency with the rest of the SDK.

    ATH-399: `max_tokens=None` (the default) resolves to a
    model-aware value via `default_max_tokens_for()`. Reasoning
    models (kimi, gemini-2.5-*, o1/o3, r1) get 8000-16000; non-
    reasoning models get 8192 (unchanged). Callers can still pass
    an explicit int to override.
    """
    if is_native_anthropic(model):
        raise ValueError(
            f"Model '{model}' is native Anthropic — call Runner._call_anthropic "
            "directly instead of going through providers.call_model()."
        )

    if not any(model.startswith(p) for p in _LITELLM_PREFIXES):
        raise ValueError(
            f"Unknown model provider: {model!r}. Known prefixes: "
            f"{_NATIVE_ANTHROPIC_PREFIXES + _LITELLM_PREFIXES}. "
            "If this is a real litellm-supported model, add its prefix to "
            "_LITELLM_PREFIXES in athanor/providers.py."
        )

    litellm = _require_litellm()

    # ATH-399: resolve max_tokens against the model-aware table if
    # the caller passed None. Explicit int still wins.
    if max_tokens is None:
        max_tokens = default_max_tokens_for(model)

    # Build the litellm call kwargs. LiteLLM handles provider-specific
    # auth via env vars (ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY,
    # AWS_ACCESS_KEY_ID, AZURE_OPENAI_API_KEY, etc.)
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if api_key:
        kwargs["api_key"] = api_key
    if tools:
        # litellm accepts OpenAI-shape tools. If caller passed Anthropic-shape,
        # we translate. Anthropic tools have input_schema; OpenAI tools have
        # parameters nested under function.
        kwargs["tools"] = _normalize_tools_to_openai(tools)
    if extra:
        kwargs.update(extra)

    # Retry loop with exponential backoff + jitter on transient failures.
    # Azure's openai-compat endpoint throttles at 8 concurrent with
    # RateLimitError (HTTP 429). Real customers running env.run() alongside
    # any other fleet workload hit this; giving up on the first 429 burns
    # their run. Anthropic's own retry loop in evaluate.py does 5 attempts;
    # we match that shape with 3 attempts here (per-turn retries, not
    # per-task, so a bit less aggressive). qa dogfood 2026-04-20 (bug #2).
    import random
    import time

    RETRIABLE_EXC_NAMES = (
        "RateLimitError",           # 429
        "ServiceUnavailableError",  # 503
        "APIConnectionError",       # transient network
        "Timeout",                  # provider timeout
        "InternalServerError",      # 500 from provider
    )

    # ATH-400: acquire per-model concurrency semaphore to stay under
    # capped endpoints' (e.g. Azure Kimi = 8) provisioned limit. The
    # retry loop below is the backstop for transient 429s; this gate
    # avoids the 429 in the first place.
    sem = _get_semaphore_for(model)
    last_exc: Exception | None = None
    for attempt in range(3):
        try:
            if sem is not None:
                with sem:
                    response = litellm.completion(**kwargs)
            else:
                response = litellm.completion(**kwargs)
            return _openai_to_anthropic(response)
        except Exception as exc:
            # Match on class name so we don't need to import litellm's
            # exception hierarchy at module load time.
            if type(exc).__name__ not in RETRIABLE_EXC_NAMES:
                raise
            last_exc = exc
            if attempt == 2:
                break
            # Backoff: 2^attempt + random jitter in [0, 1). So
            # attempt 0 sleeps ~1-2s, attempt 1 sleeps ~2-3s, attempt 2
            # doesn't sleep (we break instead).
            delay = (2 ** attempt) + random.random()
            time.sleep(delay)
    # Out of retries — re-raise the last error so the caller sees the
    # provider-classified exception class, not a wrapping one.
    assert last_exc is not None
    raise last_exc


def _normalize_tools_to_openai(tools: list[dict]) -> list[dict]:
    """Accept Anthropic-shape OR OpenAI-shape tools; return OpenAI-shape."""
    out = []
    for t in tools:
        if t.get("type") == "function":
            out.append(t)  # already OpenAI-shape
            continue
        # Anthropic-shape: {name, description, input_schema}
        out.append({
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema", {"type": "object"}),
            },
        })
    return out


def _openai_to_anthropic(response: Any) -> dict:
    """Convert a litellm/OpenAI ChatCompletion to Anthropic Messages shape."""
    choice = response.choices[0]
    msg = choice.message
    content_blocks: list[dict] = []

    # Text content
    if getattr(msg, "content", None):
        content_blocks.append({"type": "text", "text": msg.content})

    # Tool calls
    for tc in getattr(msg, "tool_calls", None) or []:
        import json as _json
        try:
            args = _json.loads(tc.function.arguments) if isinstance(tc.function.arguments, str) else tc.function.arguments
        except Exception:  # noqa: BLE001 — broad-catch fallback
            args = {}
        content_blocks.append({
            "type": "tool_use",
            "id": tc.id,
            "name": tc.function.name,
            "input": args,
        })

    # Stop reason mapping
    finish_reason = getattr(choice, "finish_reason", None)
    stop_map = {"stop": "end_turn", "length": "max_tokens",
                "tool_calls": "tool_use", "function_call": "tool_use"}
    stop_reason = stop_map.get(finish_reason, finish_reason or "end_turn")

    usage = getattr(response, "usage", None)
    usage_dict = {}
    if usage:
        usage_dict = {
            "input_tokens": getattr(usage, "prompt_tokens", 0),
            "output_tokens": getattr(usage, "completion_tokens", 0),
        }

    return {
        "content": content_blocks,
        "stop_reason": stop_reason,
        "usage": usage_dict,
    }
