"""ATH-690 — license-gate decision audit log.

Stamps every license-gate decision (`require_product`,
`require_env_access`, and the fail-closed branches of `load_license`)
to a local JSONL journal + (optionally) the Supabase
`license_gate_decisions` table. Designed as a forensic /
support-visibility surface, NOT a second enforcement layer — the gate
decision is ALREADY made by license_scope; this module just records it.

## Two sinks

1. `JsonlAuditSink` — always-on. Appends one line per decision to
   `~/.athanor/audit.jsonl`. Local-first: this works with no network,
   no token, no platform configured. Customers can `tail -f` it.
2. `SupabaseAuditSink` — opt-in. When `ATHANOR_SYNC_TOKEN` (or the
   legacy `SUPABASE_SERVICE_ROLE_KEY`) is set + a Supabase URL is
   configured, every decision ALSO POSTs a row to
   `license_gate_decisions`. Best-effort: a failed POST logs at WARNING
   and never raises from the gate.

## Schema (platform-pinned)

The row shape mirrors `license_gate_decisions` (platform PR #307,
migration `20260426084900_ath686_license_gate_decisions.sql`). CHECK
constraints on `gate_name`, `decision`, and `reason` are pinned to the
public surface of `kairos.license_scope` — when a new gate or denial
reason lands, the SDK schema gate (planned ATH-686 PR 4) catches drift
in CI.

## Privacy

The audit row carries decision metadata only: gate_name, gate_argument,
license_subject, decision, reason, call_site, run_id, plus a free-shape
`context` jsonb with non-sensitive enrichment (granted_products,
granted_envs, expires_at, keys_provisioned, error_class). It NEVER
captures input data — hypothesis text, file content, intent payloads —
because those are sensitive and irrelevant to the audit purpose.

## Failure mode

`emit_decision` swallows every exception. The license gate's
correctness is the source of truth; if the audit log breaks, the
customer's call still succeeds (or fails) as the policy requires.
The journal is best-effort observability, not control plane.

## Retention semantics (v1 contract, asabi 2026-04-26)

Deny-decision rows (`reason in {no_license_file, license_expired,
signature_verify_failed, product_not_granted, env_not_granted,
envs_product_missing}`) are FORENSICALLY LOAD-BEARING and must NOT be
retention-trimmed alongside allow-decision rows when v2 retention
policy lands. Deny rows are the abuse-detection signal; allow rows
are convenience telemetry. Platform-side retention trimming should
key on `decision` and treat `decision='deny'` as long-retention.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable
from uuid import uuid4

logger = logging.getLogger(__name__)

AUDIT_JOURNAL_PATH = ".athanor/audit.jsonl"

_SYNC_TOKEN_ENV = "ATHANOR_SYNC_TOKEN"


# Pinned to platform's CHECK enum on license_gate_decisions.gate_name.
GateName = Literal[
    "require_product",
    "require_env_access",
    "load_license",
]

# Pinned to platform's CHECK enum on license_gate_decisions.decision.
Decision = Literal["allow", "deny", "dev_bypass"]

# Pinned to platform's CHECK enum on license_gate_decisions.reason.
# Empty string is permitted for the allow/dev_bypass paths.
Reason = Literal[
    "",
    "no_license_file",
    "license_expired",
    "signature_verify_failed",
    "product_not_granted",
    "env_not_granted",
    "envs_product_missing",
]


@dataclass
class AuditEvent:
    """One license-gate decision. Mirrors `license_gate_decisions` row.

    Field names match the platform contract exactly so
    `SupabaseAuditSink._post` ships `asdict(event)` with no rename.
    """

    gate_name: str  # GateName literal
    gate_argument: str
    decision: str  # Decision literal
    reason: str = ""  # Reason literal — "" for allow / dev_bypass
    license_subject: str | None = None
    organization_id: str | None = None
    call_site: str = ""
    run_id: str | None = None
    context: dict[str, Any] = field(default_factory=dict)
    # Field name matches platform's `license_gate_decisions.created_at`
    # column. PostgREST rejects unknown JSON keys, so the SDK MUST send
    # `created_at` (or omit it). Client-side default is a fallback for
    # the JSONL journal; on Supabase insert the DB `DEFAULT NOW()` wins
    # because the same column accepts a passed value or default-stamps.
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    id: str = field(default_factory=lambda: str(uuid4()))


@runtime_checkable
class AuditSink(Protocol):
    """Sink for AuditEvents. MUST NOT raise from `emit`."""

    def emit(self, event: AuditEvent) -> None: ...


class NoopAuditSink:
    """Drop every event. Used in tests + by callers who explicitly
    opt out of audit logging."""

    def emit(self, event: AuditEvent) -> None:  # pragma: no cover
        pass


class JsonlAuditSink:
    """Append one JSONL line per event to a local journal.

    Default path is `~/.athanor/audit.jsonl`. Each line is a single
    JSON object with all `AuditEvent` fields. No rotation, no size
    cap — customers wanting either of those can `logrotate` the file
    or set `path` to a logrotate-managed file.

    Thread-safe via a per-instance lock around the file write.
    """

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or (Path.home() / AUDIT_JOURNAL_PATH)
        self._lock = threading.Lock()

    def emit(self, event: AuditEvent) -> None:
        try:
            line = json.dumps(asdict(event), default=str) + "\n"
            with self._lock:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with self.path.open("a", encoding="utf-8") as f:
                    f.write(line)
        except OSError as e:
            logger.warning("JsonlAuditSink: failed to append event: %s", e)


class SupabaseAuditSink:
    """POST every event to the Supabase `license_gate_decisions` table.

    Reads URL + auth token from env on every emit so a rotated token
    picks up without process restart. Auth token resolution mirrors
    `kairos.trace.SupabaseTraceSink`: prefer `ATHANOR_SYNC_TOKEN`,
    fall back to `SUPABASE_SERVICE_ROLE_KEY`.

    Best-effort: any HTTP / network failure is logged at WARNING + the
    event is NOT retried. This is forensic infra, not transactional.
    The local JsonlAuditSink remains the source of truth on the
    customer machine; Supabase is a convenience for fleet-side
    aggregation.
    """

    TABLE = "license_gate_decisions"

    def emit(self, event: AuditEvent) -> None:
        # 2026-04-27 (research smoke compose-test): silence the loud
        # WARNING noise when KAIROS_DEV_NO_LICENSE=1 is in effect.
        # Dev-bypass runs hit a Supabase config where the
        # `license_gate_decisions` table isn't provisioned, so every
        # audit emit returned 404 → loud WARNING. The local
        # JsonlAuditSink remains the source of truth for forensics;
        # the Supabase fan-out is a convenience that's safe to skip
        # on dev_bypass runs.
        if os.environ.get("KAIROS_DEV_NO_LICENSE") == "1":
            logger.debug(
                "SupabaseAuditSink: KAIROS_DEV_NO_LICENSE=1 — skipping POST "
                "(JsonlAuditSink remains the local source of truth)"
            )
            return
        try:
            url = os.environ.get("SUPABASE_URL") or os.environ.get(
                "NEXT_PUBLIC_SUPABASE_URL"
            )
            key = os.environ.get(_SYNC_TOKEN_ENV) or os.environ.get(
                "SUPABASE_SERVICE_ROLE_KEY"
            )
            if not url or not key:
                logger.debug(
                    "SupabaseAuditSink: URL or token unset — skipping POST"
                )
                return
            self._post(url, key, asdict(event))
        except Exception as e:  # noqa: BLE001 — best-effort, never raise
            # 2026-04-27: 404 → debug (table not provisioned in this
            # Supabase config, safe to ignore on dev / preview runs).
            # Other errors stay at warning so real network / auth /
            # schema-drift issues remain visible.
            msg = str(e)
            if "404" in msg or "Not Found" in msg:
                logger.debug(
                    "SupabaseAuditSink: POST 404 — license_gate_decisions "
                    "table not provisioned for this Supabase config"
                )
            else:
                logger.warning("SupabaseAuditSink: POST failed: %s", e)

    @staticmethod
    def _post(url: str, key: str, row: dict[str, Any]) -> None:
        # Lazy import — keep `requests` out of the cold path when the
        # sink isn't configured. The SDK already depends on requests
        # via SupabaseTraceSink, so this is a no-op for any install
        # that has SupabaseTraceSink working.
        import requests

        endpoint = f"{url.rstrip('/')}/rest/v1/{SupabaseAuditSink.TABLE}"
        headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Prefer": "return=minimal",
        }
        resp = requests.post(endpoint, json=row, headers=headers, timeout=5)
        resp.raise_for_status()


class CompositeAuditSink:
    """Fan out events to multiple sinks. Each sink emits independently;
    one sink raising does not skip the others."""

    def __init__(self, *sinks: AuditSink) -> None:
        self.sinks = sinks

    def emit(self, event: AuditEvent) -> None:
        for sink in self.sinks:
            try:
                sink.emit(event)
            except Exception:  # noqa: BLE001
                logger.exception(
                    "CompositeAuditSink: %s.emit raised",
                    type(sink).__name__,
                )


# Process-wide default sink. First call to `default_audit_sink` builds
# it; subsequent calls return the cached instance. Tests can override
# via `set_audit_sink(...)`.
_default_sink_lock = threading.Lock()
_default_sink: AuditSink | None = None


def default_audit_sink() -> AuditSink:
    """Return the SDK's default audit sink for this process.

    Two-way detection on first call:
    - If a Supabase URL + auth token are present in env → return a
      `CompositeAuditSink(JsonlAuditSink, SupabaseAuditSink)`. Customer
      gets local journal AND Supabase rows.
    - Otherwise → return `JsonlAuditSink` alone. Local-first, zero
      phone-home.

    Customers wanting fully-silent audit can call
    `set_audit_sink(NoopAuditSink())` at process start, but the
    default is local journal because journals on customer disk are
    NOT phone-home — they're forensics the customer themselves owns.
    """
    global _default_sink
    with _default_sink_lock:
        if _default_sink is not None:
            return _default_sink
        url = os.environ.get("SUPABASE_URL") or os.environ.get(
            "NEXT_PUBLIC_SUPABASE_URL"
        )
        key = os.environ.get(_SYNC_TOKEN_ENV) or os.environ.get(
            "SUPABASE_SERVICE_ROLE_KEY"
        )
        if url and key:
            _default_sink = CompositeAuditSink(
                JsonlAuditSink(),
                SupabaseAuditSink(),
            )
        else:
            _default_sink = JsonlAuditSink()
        return _default_sink


def set_audit_sink(sink: AuditSink | None) -> None:
    """Override the process-wide default. Pass `None` to reset."""
    global _default_sink
    with _default_sink_lock:
        _default_sink = sink


def emit_decision(
    *,
    gate_name: str,
    gate_argument: str,
    decision: str,
    reason: str = "",
    license_subject: str | None = None,
    organization_id: str | None = None,
    call_site: str = "",
    run_id: str | None = None,
    context: dict[str, Any] | None = None,
) -> None:
    """Build an AuditEvent + emit through the default sink.

    NEVER raises. Called from `kairos.license_scope` on every gate
    decision (after the policy decision is made, before raising on
    denial; for `load_license` fail-closed branches, called before
    raising). The license gate's correctness must not depend on this
    function — it is best-effort observability.
    """
    try:
        event = AuditEvent(
            gate_name=gate_name,
            gate_argument=gate_argument,
            decision=decision,
            reason=reason,
            license_subject=license_subject,
            organization_id=organization_id,
            call_site=call_site,
            run_id=run_id,
            context=context or {},
        )
        default_audit_sink().emit(event)
    except Exception:  # noqa: BLE001
        logger.exception("emit_decision: caught exception, swallowing")


__all__ = [
    "AUDIT_JOURNAL_PATH",
    "AuditEvent",
    "AuditSink",
    "CompositeAuditSink",
    "Decision",
    "GateName",
    "JsonlAuditSink",
    "NoopAuditSink",
    "Reason",
    "SupabaseAuditSink",
    "default_audit_sink",
    "emit_decision",
    "set_audit_sink",
]
