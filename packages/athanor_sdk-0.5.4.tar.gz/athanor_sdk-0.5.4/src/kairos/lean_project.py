"""kairos.lean_project — drift-safe introspection of a Lean lake project.

Customer drivers that pair a logical-name slate (e.g.
``{"theorem_id": "X", "module": "Quantization"}``) with a Lean lake
project must translate the slate's module name into an actual Lean
import path. Without help, the obvious failure mode is to snapshot
the translation in a hand-coded ``MODULE_MAP`` — which then drifts
every time the lake project renames or refactors.

We learned this in production on 2026-04-28: a research driver lost
~5 hours of GPU time + repeated re-fires to two drift bugs that
shared one root cause. Stale ``MODULE_MAP`` after a
``Kairos.Stats → Pythia`` rename; lake said ``unknown target`` for
every verify; every attempt scored ``type_fail`` and the row silently
zeroed. Same pattern customers will hit when they extend pythia for
their own theorems or run their own slate-vs-lake-project loops.

This module ships the SDK-side fix (ATH-864): drift-safe
introspection of the active lake project, with typed
:class:`~kairos.errors.LakeModuleNotFoundError` /
:class:`~kairos.errors.LakeTargetUnknownError` for the two drift
classes, plus a ``scaffold_smoke_test()`` one-call preflight that
exercises the full write → lake-build → axiom-audit pipeline on a
known-correct proof and reports loud failure if any layer regresses.

Quick start::

    from kairos.lean_project import LakeProject, ProjectModule, MathlibCanon, NotFound

    project = LakeProject("/path/to/lean/repo")
    print(project.package_name)        # e.g. "HowardBridge" or "Pythia"
    print(len(project.known_modules))  # e.g. 13

    match project.resolve_module(slate_row["module"]):
        case ProjectModule(import_path=p):
            # use this as the project-side import in the verify scaffold
            ...
        case MathlibCanon():
            # no project import needed; Mathlib is transitive
            ...
        case NotFound(suggestions=s):
            # caller chooses: raise, skip target, or report
            raise LakeModuleNotFoundError(...)

Or for raise-on-miss ergonomics::

    import_path = project.resolve_module_strict("Quantization")
    # raises LakeModuleNotFoundError if miss; returns None for Mathlib-canon

Architectural rule: ``LakeProject`` is **derived** at construction
from the live filesystem + lakefile, never snapshotted. Customers
extending pythia or running their own slate-vs-lake loops should
re-instantiate (or call :meth:`LakeProject.refresh`) on every fire so
renames are caught at preflight time, not silently mid-sweep.
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Union

from .errors import LakeModuleNotFoundError, LakeTargetUnknownError


# ─── Discriminated-union return type for resolve_module ────────────────


@dataclass(frozen=True)
class ProjectModule:
    """Slate module resolved to a project-side Lean import path.

    ``import_path`` is the fully-qualified ``<package>.<module>`` form
    the caller writes in their scratch file's ``import`` clause.
    """

    import_path: str


@dataclass(frozen=True)
class MathlibCanon:
    """Slate module is the literal string ``"Mathlib"`` — Mathlib-only
    target, no project-side import needed (caller emits a single
    ``import Mathlib`` line and skips any project-specific import).

    A separate type from ``ProjectModule`` so callers can't confuse
    "Mathlib-canon, intentionally no project import" with
    "lookup-failed, defer to caller". Discriminated union, not
    overloaded ``str | None``.
    """


@dataclass(frozen=True)
class NotFound:
    """Slate module does not match any known module in the active
    project. Suggestions are nearby project modules by prefix overlap
    (no full Levenshtein — not worth the dep). Caller decides whether
    to raise :class:`~kairos.errors.LakeModuleNotFoundError`, skip the
    target, or report-and-continue.
    """

    short_name: str
    suggestions: list[str] = field(default_factory=list)


ModuleResolution = Union[ProjectModule, MathlibCanon, NotFound]


# ─── LakeProject introspection ─────────────────────────────────────────


_PACKAGE_LINE_RE = re.compile(
    r"^\s*package\s+(?:«([^»]+)»|(\w+))",
    re.MULTILINE,
)


@dataclass
class LakeProject:
    """Drift-safe introspection of a Lean lake project at ``root``.

    Reads the package name from ``<root>/lakefile.lean`` and walks
    ``<root>/<package>/`` to enumerate top-level ``.lean`` files
    (``known_modules``). Validates eagerly at construction so the
    customer hits a typed error at instantiation, not on the first
    method call mid-sweep.

    For long-lived fleet sessions that may edit the lakefile or add
    modules mid-run, call :meth:`refresh` to invalidate the cached
    ``known_modules`` and re-walk. Without refresh, you'd reintroduce
    the snapshot-drift class through the back door.

    :param root: lake project root (the directory containing
        ``lakefile.lean``).
    :raises FileNotFoundError: if ``<root>/lakefile.lean`` doesn't
        exist. We raise eagerly so the customer never gets a partly-
        constructed object that silently no-ops on every method call.
    :raises ValueError: if ``lakefile.lean`` exists but contains no
        ``package <name>`` clause we can parse.
    """

    root: Path
    package_name: str = field(init=False)
    known_modules: frozenset[str] = field(init=False)

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        lakefile = self.root / "lakefile.lean"
        if not lakefile.is_file():
            raise FileNotFoundError(
                f"no lakefile.lean at {lakefile} — pass the lake "
                f"project root (the directory containing "
                f"lakefile.lean), not a subdirectory"
            )
        text = lakefile.read_text()
        m = _PACKAGE_LINE_RE.search(text)
        if not m:
            raise ValueError(
                f"lakefile.lean at {lakefile} has no parseable "
                f"`package <name>` clause"
            )
        self.package_name = m.group(1) or m.group(2)
        self._refresh_known_modules()

    def _refresh_known_modules(self) -> None:
        """Re-walk the package directory; invalidate + reset
        ``known_modules``. Iteration order is hash-stable within a
        process but not across; consumers needing order should call
        ``sorted(known_modules)``.
        """
        pkg_dir = self.root / self.package_name
        modules: set[str] = set()
        if pkg_dir.is_dir():
            for p in pkg_dir.glob("*.lean"):
                if p.is_file():
                    modules.add(p.stem)
        # Direct assignment (mirrors self.package_name in __init__).
        # The dataclass is non-frozen so this is the natural form;
        # earlier drafts used object.__setattr__ as a future-proofing
        # guard against switching to frozen=True, which we don't.
        self.known_modules = frozenset(modules)

    def refresh(self) -> None:
        """Invalidate the cached ``known_modules`` and re-walk the
        filesystem. Call after the customer adds or removes Lean files
        in the active project, or in long-lived fleet sessions where
        the lake project may evolve mid-run.
        """
        self._refresh_known_modules()

    # ── Resolution ────────────────────────────────────────────────────

    def resolve_module(self, short_name: str) -> ModuleResolution:
        """Translate a slate row's bare module name to a discriminated
        :class:`ModuleResolution` value.

        Three outcomes:

        * ``ProjectModule(import_path=...)`` — the slate's module
          exists under this project; ``import_path`` is the fully-
          qualified ``<package>.<module>`` form.
        * ``MathlibCanon()`` — the slate's module is **exactly** the
          literal string ``"Mathlib"`` (Mathlib-only target, no
          project import needed). Nested imports like
          ``"Mathlib.Analysis"`` are NOT recognized here and fall
          through to ``NotFound`` by design — customers needing
          those should add a wrapper module to their lake project
          and reference it by its short project name.
        * ``NotFound(short_name, suggestions=[...])`` — neither.
          Caller decides whether to raise (use
          :meth:`resolve_module_strict` for raise-on-miss).

        This method is total over the input domain: every string has
        exactly one of the three outcomes. No silent ``str | None``
        overloads; the discriminated union makes lookup-failure-vs-
        defer-to-Mathlib unambiguous.
        """
        if short_name == "Mathlib":
            return MathlibCanon()
        if short_name in self.known_modules:
            return ProjectModule(
                import_path=f"{self.package_name}.{short_name}",
            )
        return NotFound(
            short_name=short_name,
            suggestions=self._suggest_close_modules(short_name),
        )

    def resolve_module_strict(self, short_name: str) -> Optional[str]:
        """Raise-on-miss convenience wrapper around
        :meth:`resolve_module`.

        :returns: the import path string for ``ProjectModule``, or
            ``None`` for ``MathlibCanon``.
        :raises LakeModuleNotFoundError: when the slate's module is
            not in the active project.
        """
        match self.resolve_module(short_name):
            case ProjectModule(import_path=p):
                return p
            case MathlibCanon():
                return None
            case NotFound(short_name=s, suggestions=sug):
                raise LakeModuleNotFoundError(
                    short_name=s,
                    package_name=self.package_name,
                    suggestions=sug,
                    known_modules_sample=sorted(self.known_modules)[:8],
                )
        # Unreachable; satisfies mypy on older Python versions.
        raise AssertionError("unreachable")

    def _suggest_close_modules(self, short_name: str) -> list[str]:
        """Tiny prefix-overlap suggester. Picks any known module whose
        first 3 chars (case-insensitive) match the input. Sorted for
        determinism. Capped at a few results so error messages stay
        scannable.

        The 3-char prefix length and lack of edit-distance scoring
        are deliberate — full Levenshtein is deferred (would pull a
        dep for marginal benefit at this scale). If a future
        maintainer wants to upgrade, swap to ``rapidfuzz`` and keep
        the same call site; the discriminated-union return type
        from :meth:`resolve_module` is already designed to carry
        better suggestions without API change.
        """
        if not short_name or not self.known_modules:
            return []
        prefix = short_name[:3].lower()
        return sorted(
            m for m in self.known_modules
            if m.lower().startswith(prefix)
        )[:3]


# ─── Scaffold smoke test ───────────────────────────────────────────────


@dataclass(frozen=True)
class ScaffoldSmokeResult:
    """Outcome of :func:`scaffold_smoke_test`.

    ``closed AND axiom_clean`` is the strict pass — the entire scaffold
    (file write, lake target naming, build, axiom audit) works on a
    known-correct input. Any other combination indicates a regression
    in some layer.
    """

    closed: bool
    axiom_clean: Optional[bool]
    lake_returncode: int
    lake_stderr_tail: str = ""


def scaffold_smoke_test(
    project: LakeProject,
    target_name: str,
    theorem_signature: str,
    reference_proof: str,
    *,
    project_module: Optional[str] = None,
    scratch_subdir: str = "_kairos_smoke",
    keep_artifacts: bool = False,
    lake_timeout: int = 240,
) -> ScaffoldSmokeResult:
    """Exercise the full write-file → lake-build → axiom-audit pipeline
    on a hand-crafted closing proof, in a tempdir under the lake env
    that auto-cleans on every exit path (success, exception, KeyboardInterrupt).

    A single call covers the scaffold drift classes:

    * scratch path under lake's namespace tree (catches
      ``unknown target`` → :class:`LakeTargetUnknownError`)
    * import resolution (catches stale-module-map → caller's
      :class:`LakeModuleNotFoundError` raised by upstream
      :meth:`LakeProject.resolve_module_strict`)
    * axiom audit pipeline (catches drift in ``#print axioms`` parsing)

    If this returns ``ScaffoldSmokeResult(closed=True, axiom_clean=True)``,
    the scaffold is structurally sound for the given target shape and
    customers can run their full sweep with confidence.

    :param project: active :class:`LakeProject` to verify against.
    :param target_name: theorem identifier (without ``_test`` suffix).
        Used to construct the lake target name and the
        ``#print axioms`` audit query.
    :param theorem_signature: everything between ``theorem foo : `` and
        ``:=``. e.g. ``"(a b : ℝ) → 0 ≤ a → 0 ≤ b → 0 ≤ a * b"``.
    :param reference_proof: hand-crafted closing proof body, including
        the leading ``:= ``. e.g.
        ``":= by intro a b ha hb; exact mul_nonneg ha hb"``.
    :param project_module: optional project-side import (e.g.
        ``"HowardBridge.Quantization"``). ``None`` for Mathlib-only
        targets.
    :param scratch_subdir: subdir name under
        ``<project_root>/<package>/Scratch/`` for the test artifact.
        Auto-cleaned unless ``keep_artifacts=True``.
    :param keep_artifacts: leave the scratch file on disk for
        debugging. Default ``False`` so first-run customers don't
        pollute their project tree.
    :param lake_timeout: hard cap on ``lake build``.
    :raises LakeTargetUnknownError: when lake reports ``unknown target``
        (scratch path outside the lake namespace tree).
    """
    safe = re.sub(r"[^A-Za-z0-9_]", "_", target_name)
    if safe and safe[0].isdigit():
        safe = "_" + safe
    if not safe:
        raise ValueError(f"target_name {target_name!r} has no Lean-ident chars")
    scratch_dir = (
        project.root / project.package_name / "Scratch" / scratch_subdir / safe
    )
    scratch_dir.mkdir(parents=True, exist_ok=True)
    scratch_file = scratch_dir / f"{safe}.lean"
    audit_file = scratch_dir / f"{safe}_audit.lean"
    project_imp = f"import {project_module}\n" if project_module else ""
    body = (
        f"{project_imp}import Mathlib\n\n"
        f"open {project.package_name}\n\n"
        f"theorem {safe}_test : {theorem_signature} {reference_proof}\n"
    )
    target_qname = (
        f"{project.package_name}.Scratch.{scratch_subdir}.{safe}.{safe}"
    )
    audit_qname = (
        f"{project.package_name}.Scratch.{scratch_subdir}.{safe}.{safe}_audit"
    )
    audit_body = (
        f"import {target_qname}\n"
        f"open {project.package_name}\n"
        f"#print axioms {safe}_test\n"
    )

    try:
        scratch_file.write_text(body)
        try:
            r = subprocess.run(
                ["lake", "build", target_qname],
                cwd=str(project.root),
                capture_output=True, text=True,
                timeout=lake_timeout,
            )
        except subprocess.TimeoutExpired:
            return ScaffoldSmokeResult(
                closed=False, axiom_clean=None, lake_returncode=124,
                lake_stderr_tail=f"timeout after {lake_timeout}s",
            )
        combined = (r.stdout or "") + "\n" + (r.stderr or "")
        if "unknown target" in combined:
            raise LakeTargetUnknownError(
                target=target_qname,
                scratch_path=str(scratch_file),
                lake_stderr_tail=combined[-1000:],
            )
        if r.returncode != 0:
            return ScaffoldSmokeResult(
                closed=False,
                axiom_clean=None,
                lake_returncode=r.returncode,
                lake_stderr_tail=(r.stderr or "")[-800:],
            )

        # Build succeeded — run axiom audit.
        audit_file.write_text(audit_body)
        try:
            ra = subprocess.run(
                ["lake", "build", audit_qname],
                cwd=str(project.root),
                capture_output=True, text=True,
                timeout=lake_timeout,
            )
            audit_combined = (ra.stdout or "") + "\n" + (ra.stderr or "")
        except subprocess.TimeoutExpired:
            audit_combined = ""
        m = re.search(r"depends on axioms:\s*\[(.+?)\]", audit_combined)
        axiom_clean: Optional[bool] = None
        if m:
            ax = {a.strip() for a in m.group(1).split(",")}
            axiom_clean = not (
                ax - {"propext", "Classical.choice", "Quot.sound"}
            )
        elif "does not depend on any axioms" in audit_combined:
            axiom_clean = True

        return ScaffoldSmokeResult(
            closed=True, axiom_clean=axiom_clean,
            lake_returncode=0,
        )
    finally:
        if not keep_artifacts:
            for f in (scratch_file, audit_file):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass
            # Best-effort: remove empty scratch dir + ancestors up to
            # the Scratch/ subdir to avoid polluting the project tree.
            # Each rmdir is independent — OSError on one (e.g.
            # sibling test still has artifacts) doesn't block the
            # next level. The third rmdir cleans Scratch/<subdir>/
            # itself if this was the last test in a session.
            for level in (scratch_dir, scratch_dir.parent,
                          scratch_dir.parent.parent):
                try:
                    level.rmdir()
                except OSError:
                    pass


__all__ = [
    "LakeProject",
    "ModuleResolution",
    "ProjectModule",
    "MathlibCanon",
    "NotFound",
    "ScaffoldSmokeResult",
    "scaffold_smoke_test",
]
