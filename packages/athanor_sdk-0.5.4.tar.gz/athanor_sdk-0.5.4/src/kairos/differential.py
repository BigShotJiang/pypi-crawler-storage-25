"""Generic differential-testing primitive.

Same shape drives Cedar (cedar-policy vs cedar-go), hw-ebmc (ebmc vs jasper),
and neuron NKI (trainium-sim vs xla-reference) diff campaigns. Caller plugs
in a sampler, an optional yield-gate (parse+typecheck filter), and two or
more implementations; the primitive runs N samples through them, emits one
:data:`differential_test_tuple` event per valid sample, and returns a
:class:`DifferentialSummary` with yield rate + agreement rate + disagreement
list.

Dogfood pattern (paper §8 Table 4 row 2, byte-level arbitrary-sampler row):

    from kairos.differential import run, Implementation, arbitrary_bytes

    summary = run(
        run_id="ath-529-cedar-bytes-n10k",
        sampler=arbitrary_bytes(n_bytes=4096),
        yield_gate=cedar_parse_and_validate,           # platform-owned
        impls=[
            Implementation("cedar-policy", cedar_cli_invoker),
            Implementation("cedar-go", cedar_go_invoker),
        ],
        n_samples=10000,
    )
    print(f"yield={summary.yield_rate:.3f}  "
          f"disagreements={summary.disagreement_count}")

Generalization: the sampler and yield-gate are arbitrary callables; the
SDK holds no Cedar-specific logic. hw-ebmc / neuron NKI customers pass
their own sampler + gate + impls and get the same summary shape +
differential_test_tuple events.

The primitive emits events into the active :func:`kairos.session` when
one is set; outside a session it runs compute-only (zero phone-home),
matching the :mod:`kairos.lean` contract.
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

_logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════
# Public types
# ═══════════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class Implementation:
    """One implementation participating in the diff campaign.

    ``invoke`` receives the parsed/validated input (the output of the
    yield-gate if present, otherwise the raw sample) and returns a short
    verdict string (``"allow"``, ``"deny"``, ``"error"``, ``"proved"``,
    ``"match"``, etc. — caller-defined).
    """

    name: str
    invoke: Callable[[Any], str]


@dataclass(frozen=True)
class YieldGateResult:
    """Outcome of the optional parse + type-check filter.

    ``valid=True`` → the sample passes; ``parsed`` feeds every
    :class:`Implementation`.  ``valid=False`` → skip this sample; the
    summary's ``yield_rate`` reflects the drop.  ``reason`` is a short
    human tag (``"parse_fail"``, ``"typecheck_fail"``, ...) used in the
    summary's breakdown.
    """

    valid: bool
    parsed: Any = None
    reason: str = ""


@dataclass(frozen=True)
class Disagreement:
    """One tuple where the implementations disagreed."""

    sample_id: str
    verdicts: dict[str, str]  # impl_name → verdict
    input_hashes: dict[str, str]


@dataclass(frozen=True)
class DifferentialSummary:
    """Roll-up of one :func:`run` campaign."""

    run_id: str
    n_samples: int
    parse_ok_count: int
    typecheck_ok_count: int  # passed yield_gate (or equal to n_samples when no gate)
    gate_fail_breakdown: dict[str, int]  # reason → count
    agreement_count: int
    disagreement_count: int
    disagreements: list[Disagreement] = field(default_factory=list)
    wall_time_seconds: float = 0.0
    per_impl_elapsed: dict[str, float] = field(default_factory=dict)

    @property
    def yield_rate(self) -> float:
        """Fraction of sampled tuples that passed the yield gate."""
        if self.n_samples == 0:
            return 0.0
        return self.typecheck_ok_count / self.n_samples

    @property
    def agreement_rate(self) -> float:
        """Fraction of *yield-passing* tuples where all impls agreed."""
        tested = self.agreement_count + self.disagreement_count
        if tested == 0:
            return 0.0
        return self.agreement_count / tested


# ═══════════════════════════════════════════════════════════════════════
# Core run loop
# ═══════════════════════════════════════════════════════════════════════


def run(
    *,
    run_id: str,
    sampler: Callable[[int], Any],
    impls: Sequence[Implementation],
    n_samples: int,
    yield_gate: Callable[[Any], YieldGateResult] | None = None,
    hash_input: Callable[[Any], dict[str, str]] | None = None,
) -> DifferentialSummary:
    """Run ``n_samples`` through ``impls`` with an optional yield gate.

    Args:
        run_id: identifier for this diff campaign — appears on every
            emitted event as ``sample_id`` prefix and in the summary.
        sampler: ``seed → input``. Called once per sample with an integer
            seed; output shape is caller-defined (bytes, dict, AST node,
            ...). Must be deterministic so reruns reproduce.
        impls: two-or-more implementations to diff. Verdicts are
            string-compared for agreement.
        n_samples: campaign size.
        yield_gate: optional pre-flight filter. When present, a sample
            whose gate returns ``valid=False`` is skipped — ``impls`` do
            not run on it; the sample counts toward
            ``gate_fail_breakdown[reason]`` but not ``agreement_count`` or
            ``disagreement_count``. When absent, every sample is fed to
            every impl directly (no yield drop).
        hash_input: optional ``parsed → {name: sha256hex}`` mapper used
            to populate per-event ``input_hashes``.  Defaults to a single
            ``"sample"`` SHA256 of ``str(parsed)`` so events remain
            queryable even when the caller doesn't name components.

    Returns:
        :class:`DifferentialSummary` with yield + agreement rates,
        disagreements list, and wall-clock stats.

    Side effects:
        When called inside a :func:`kairos.session`, emits one
        :data:`differential_test_tuple` event per yield-passing sample
        (pairwise: for N>2 impls only the first two are emitted on each
        event; future work via ATH-570 extends to N-ary diff).
    """
    if len(impls) < 2:
        raise ValueError(
            f"differential.run requires >=2 implementations, got {len(impls)}"
        )
    if n_samples < 0:
        raise ValueError(f"n_samples must be >=0, got {n_samples}")
    hash_fn = hash_input or _default_hash_input

    t0 = time.monotonic()
    parse_ok = 0
    typecheck_ok = 0
    gate_fail: dict[str, int] = {}
    agreement = 0
    disagreement = 0
    disagreements: list[Disagreement] = []
    per_impl_elapsed: dict[str, float] = {impl.name: 0.0 for impl in impls}

    for seed in range(n_samples):
        sample_id = f"{run_id}-s{seed:08d}"
        sample = sampler(seed)

        if yield_gate is None:
            parsed = sample
            parse_ok += 1
            typecheck_ok += 1
        else:
            gate = yield_gate(sample)
            if not gate.valid:
                reason = gate.reason or "gate_fail"
                gate_fail[reason] = gate_fail.get(reason, 0) + 1
                continue
            parsed = gate.parsed if gate.parsed is not None else sample
            parse_ok += 1
            typecheck_ok += 1

        verdicts: dict[str, str] = {}
        elapsed: dict[str, float] = {}
        for impl in impls:
            ti = time.monotonic()
            try:
                v = impl.invoke(parsed)
            except Exception as exc:  # noqa: BLE001 — broad-catch fallback
                v = f"error:{type(exc).__name__}"
            elapsed[impl.name] = time.monotonic() - ti
            verdicts[impl.name] = str(v)
            per_impl_elapsed[impl.name] += elapsed[impl.name]

        unique = set(verdicts.values())
        diff_found = len(unique) > 1
        if diff_found:
            disagreement += 1
        else:
            agreement += 1

        hashes = hash_fn(parsed)
        if diff_found:
            disagreements.append(
                Disagreement(
                    sample_id=sample_id,
                    verdicts=dict(verdicts),
                    input_hashes=dict(hashes),
                )
            )

        _emit_tuple(
            sample_id=sample_id,
            impls=impls,
            verdicts=verdicts,
            elapsed=elapsed,
            diff_found=diff_found,
            input_hashes=hashes,
        )

    wall = time.monotonic() - t0
    return DifferentialSummary(
        run_id=run_id,
        n_samples=n_samples,
        parse_ok_count=parse_ok,
        typecheck_ok_count=typecheck_ok,
        gate_fail_breakdown=dict(
            sorted(gate_fail.items(), key=lambda kv: (-kv[1], kv[0]))
        ),
        agreement_count=agreement,
        disagreement_count=disagreement,
        disagreements=disagreements,
        wall_time_seconds=wall,
        per_impl_elapsed=per_impl_elapsed,
    )


# ═══════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════


def _default_hash_input(parsed: Any) -> dict[str, str]:
    """Fallback hash function when the caller doesn't name input parts."""
    try:
        buf = parsed if isinstance(parsed, (bytes, bytearray)) else str(parsed).encode(
            "utf-8", errors="replace"
        )
    except Exception:  # noqa: BLE001 — broad-catch fallback
        buf = b""
    return {"sample": hashlib.sha256(buf).hexdigest()}


def _emit_tuple(
    *,
    sample_id: str,
    impls: Sequence[Implementation],
    verdicts: dict[str, str],
    elapsed: dict[str, float],
    diff_found: bool,
    input_hashes: dict[str, str],
) -> None:
    """Emit one ``differential_test_tuple`` event into the active session.

    Pairwise: only the first two implementations populate impl_a / impl_b
    fields. For N>2 callers, extend after ATH-570 lands an N-ary event
    shape; for now the paper's use-case is N=2 so we keep the registered
    shape minimal.
    """
    # ATH-971 Phase 3: route through kairos.observe.emit with
    # silent_if_no_session=True. Privacy-fence preserved (silent
    # outside an active session); legacy CURRENT_SESSION still
    # bridged through observe._try_legacy_session_context until
    # Phase 4.
    import sys as _sys
    _observe_mod = _sys.modules.get("kairos.observe")
    if _observe_mod is None:  # pragma: no cover
        from kairos import observe as _observe_mod  # type: ignore[no-redef]

    a, b = impls[0], impls[1]
    diff_details: str | None = None
    if diff_found:
        diff_details = (
            f"{a.name}={verdicts.get(a.name)} {b.name}={verdicts.get(b.name)}"
        )

    payload = {
        "sample_id": sample_id,
        "impl_a_name": a.name,
        "impl_a_verdict": verdicts.get(a.name, ""),
        "impl_a_elapsed_sec": float(elapsed.get(a.name, 0.0)),
        "impl_b_name": b.name,
        "impl_b_verdict": verdicts.get(b.name, ""),
        "impl_b_elapsed_sec": float(elapsed.get(b.name, 0.0)),
        "diff_found": bool(diff_found),
        "input_hashes": dict(input_hashes),
    }
    if diff_details is not None:
        payload["diff_details"] = diff_details

    ctx = _observe_mod.active_session_context(run_subtype="differential_test")
    if ctx is not None and ctx.session_id and "session_id" not in payload:
        payload["session_id"] = ctx.session_id

    _observe_mod.emit(
        "differential_test_tuple",
        payload,
        run_subtype="differential_test",  # type: ignore[arg-type]
        silent_if_no_session=True,
    )


# ═══════════════════════════════════════════════════════════════════════
# Built-in samplers
# ═══════════════════════════════════════════════════════════════════════


def arbitrary_bytes(*, n_bytes: int, seed_salt: bytes = b"") -> Callable[[int], bytes]:
    """Byte-level sampler — seeds a deterministic RNG + returns ``n_bytes``.

    Used by Cedar's cedar-drt-style baseline (paper §8 Table 4 row 2).
    Generalizes to any fuzzing customer with a byte→parse boundary: the
    caller's yield-gate is what rejects most samples as parse_fail /
    typecheck_fail; the sampler itself is content-free.

    Args:
        n_bytes: how many bytes per sample.
        seed_salt: optional bytes mixed into the seed so distinct
            campaigns (same N, same n_bytes) don't produce identical
            sample sequences. Default empty ⇒ fully reproducible from
            the seed integer alone.
    """
    if n_bytes <= 0:
        raise ValueError(f"n_bytes must be positive, got {n_bytes}")
    import random

    def _sample(seed: int) -> bytes:
        rng = random.Random()
        rng.seed(seed_salt + seed.to_bytes(8, "big", signed=False))
        return rng.randbytes(n_bytes)

    return _sample


__all__ = [
    "Disagreement",
    "DifferentialSummary",
    "Implementation",
    "YieldGateResult",
    "arbitrary_bytes",
    "run",
]
