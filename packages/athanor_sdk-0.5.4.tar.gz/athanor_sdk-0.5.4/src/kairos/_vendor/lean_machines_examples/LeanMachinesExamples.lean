-- This module serves as the root of the `LeanMachinesExamples` library.
-- Vendored under athanor-sdk for the lean-machines × EBMC integration
-- (ATH-657). Narrowed to the Buffer chain — the IFM2024 paper-grade
-- demonstration of Event-B-style refinement (Buffer0 abstract →
-- Buffer1 list-non-det → Buffer2 list-priority-functional). Other
-- example chains (MQueue, EventB, VDM, Algebraic) were dropped from
-- this vendor; full corpus is at github.com/lean-machines-central.

import LeanMachinesExamples.Buffer.Buffer2
import LeanMachinesExamples.Buffer.PushBuffer
