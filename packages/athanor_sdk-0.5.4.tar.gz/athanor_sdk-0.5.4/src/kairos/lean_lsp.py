"""kairos.lean_lsp — Lean LSP goal-state queries via the leanclient library.

Lets a refinement loop see what the proof actually still has to prove.
A parse error like ``BonferroniFwer.lean:24:16: expected token`` is
useless to the model without the surrounding goal. ``goal_at(...)``
returns the rendered goal string at a position so the cycle-engine
refinement prompt can include it alongside the lake error.

This module is an optional adapter around the upstream
``leanclient`` package (PyPI). ``leanclient>=0.9.4`` is the same
LSP-pump library that ``cameronfreer/lean-lsp-mcp`` wraps for Claude
Code; using it directly removes the MCP / Claude Code layer for SDK
callers.

Usage:

    from kairos.lean_lsp import goal_at, LSP_AVAILABLE

    if LSP_AVAILABLE:
        snippet = goal_at(
            lake_project="/path/to/pythia",
            module_path="Pythia.Scratch.Foo",
            line=24, character=16,
            timeout=30,
        )
        # `snippet` is the rendered goal as Lean prints it, e.g.
        #   "case h\nx : Nat\n⊢ 0 ≤ x"
        # or None if the LSP returned no goal at that position
        # (often means the proof is complete OR the position is in
        # a parse error region).

The first call against a given ``lake_project`` cold-starts a Lean LSP
server and waits for Mathlib oleans to load (5–30 s). Subsequent calls
against the same project reuse the server via the module-global cache
keyed on resolved ``lake_project`` path. The cache holds at most 4
servers; opening a 5th evicts the oldest.

The cache is process-local. ``close_all()`` shuts down all warm
servers (call from a finally-block in long-lived agents to avoid
leaving Lean processes around).
"""
from __future__ import annotations

import logging
import os
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Optional

_logger = logging.getLogger(__name__)


try:
    from leanclient import LeanLSPClient  # type: ignore[import-not-found]
    LSP_AVAILABLE = True
except ImportError:
    LeanLSPClient = None  # type: ignore[assignment, misc]
    LSP_AVAILABLE = False


# Module-global cache: project_path → live LeanLSPClient. OrderedDict
# so we can evict the LRU server when the cache fills.
_LSP_CACHE_MAX = 4
_lsp_cache: "OrderedDict[str, LeanLSPClient]" = OrderedDict()
_lsp_cache_lock = threading.Lock()


def _get_or_create_client(lake_project: str) -> Optional["LeanLSPClient"]:
    """Resolve the lake_project to an absolute string and return a
    cached LeanLSPClient. Cold-starts a fresh server on cache miss.

    Returns None if leanclient isn't installed OR the LSP failed to
    start (e.g. project has no lean-toolchain). Callers should treat
    the absence of LSP as a soft fallback rather than an error.
    """
    if not LSP_AVAILABLE:
        return None
    project = str(Path(lake_project).resolve())
    with _lsp_cache_lock:
        if project in _lsp_cache:
            # Move to end = mark as most recently used.
            _lsp_cache.move_to_end(project)
            return _lsp_cache[project]
        if len(_lsp_cache) >= _LSP_CACHE_MAX:
            evicted_path, evicted_client = _lsp_cache.popitem(last=False)
            try:
                evicted_client.close()
            except Exception:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                _logger.debug("LSP cache: ignored close error for %s", evicted_path)
        try:
            client = LeanLSPClient(project_path=project, max_opened_files=4)
        except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.warning(
                "lean_lsp: cold-start failed for %s — %s: %s",
                project, type(e).__name__, e,
            )
            return None
        _lsp_cache[project] = client
        return client


def goal_at(
    lake_project: str | os.PathLike[str],
    module_path: str,
    line: int,
    character: int = 0,
    *,
    timeout: int = 30,
) -> Optional[str]:
    """Return the Lean goal at (line, character) of the candidate's
    module file, formatted as Lean's plainGoal renderer prints it.

    Args:
        lake_project: directory holding lakefile.{lean,toml} +
            lean-toolchain. The Lean LSP runs inside this project so
            Mathlib + project deps are in scope.
        module_path: dotted Lean name, same shape ``verify_proof``
            takes (e.g. ``"Pythia.Scratch.SwarmDogfood.Foo"``).
            Resolved to ``<lake_project>/Pythia/Scratch/SwarmDogfood/
            Foo.lean``.
        line: 1-indexed line number where the cursor sits (matches
            Lean diagnostic line numbers).
        character: 0-indexed column. Default 0 = start of line, which
            is usually fine — the goal at a position is the goal that
            HOLDS at that position, not after the tactic at that
            column runs.
        timeout: total wall-clock budget for cold-start + the goal
            query. Mathlib's first load can hit 30 s on a cold cache;
            subsequent calls in the same process are sub-second.

    Returns the rendered goal as a string (Lean's plainGoal format),
    or None if:
        - leanclient is not installed (LSP_AVAILABLE is False)
        - the LSP failed to start
        - the position has no goal (proof complete, parse error, or
          out-of-bounds)

    Never raises. Callers should treat None as "fall back to your
    other context"; the cycle-engine threads the lake error block
    instead.
    """
    if not LSP_AVAILABLE:
        return None
    client = _get_or_create_client(str(lake_project))
    if client is None:
        return None
    rel_file = module_path.replace(".", "/") + ".lean"
    try:
        # Lean LSP is 0-indexed for both line and character; our
        # ``line`` parameter is 1-indexed (matches Lean diagnostic
        # output and human counting), so subtract 1.
        result = client.get_goal(rel_file, line - 1, character)
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.debug(
            "lean_lsp: get_goal(%s, %d, %d) raised %s: %s",
            rel_file, line, character, type(e).__name__, e,
        )
        return None
    if not result:
        return None
    # leanclient returns {"rendered": "<lean-printed text>", "goals":
    # [...]} for a non-empty goal state. Prefer the human-rendered
    # form for prompt threading; fall back to a JSON-shaped goal list.
    if isinstance(result, dict):
        rendered = result.get("rendered")
        if isinstance(rendered, str) and rendered.strip():
            return rendered
        goals = result.get("goals")
        if isinstance(goals, list) and goals:
            return "\n\n".join(str(g) for g in goals)
    return None


def close_all() -> None:
    """Shut down every cached LSP server. Safe to call at program
    exit; raises nothing.
    """
    with _lsp_cache_lock:
        for path, client in list(_lsp_cache.items()):
            try:
                client.close()
            except Exception:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                _logger.debug("lean_lsp: ignored close error for %s", path)
        _lsp_cache.clear()
