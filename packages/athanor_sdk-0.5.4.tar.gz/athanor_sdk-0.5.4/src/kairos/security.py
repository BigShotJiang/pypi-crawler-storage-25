"""kairos.security — side-channel security verification (Bet J scaffold).

ATH-962. AWS sells confidential ML inference as a product surface.
Athanor makes it provably timing-safe + cache-leak-free via formal
verification of inference kernels' constant-time execution + cache-line
invariants.

Compose on existing primitives + asabi's Pythia.SideChannel parallel
research-track stub (per ATH-950 v4 reset — research-track stubs grow
primitives in Q3 even if customer-visible artifact ships Q4).

Same orchestrator template as :mod:`kairos.silicon_review` (ATH-951),
:mod:`kairos.model_invariants` (ATH-958), :mod:`kairos.sparsity`
(ATH-959). No new verifier logic; thin compose-existing-primitives
only.

Customer claim
--------------

  *"Inference kernel `attention_v2_int8` is provably timing-safe +
  cache-leak-free under multi-tenant isolation."*

4-layer vacuous-proves defense
------------------------------
Per ``feedback_no_vacuous_proves_multi_layer.md``:

1. Per-invariant verdict mapping (banned > axiom_clean=False > sorry
   > compile_error > full_proof) — ATH-948 lineage.
2. Composite precedence (error > refuted > unknown > proved; empty
   list → error not silent-proved) — ATH-951/958/959 shape.
3. Theorem template references customer-spec
   ``{invariant_name}_property`` + ``{invariant_name}_proof``
   identifiers. Empty/missing/wrong-shaped spec → compile error →
   refuted.
4. Source-text + behavioral pins (test layer).

Plus: dot-aware identifier canonicalization (ATH-961 follow-up
applied from day one in this module to avoid the latent edge case
asabi flagged on ATH-959).

Trace emit
----------
``security_verify_complete`` event registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Walker-visible emit. Composes with platform's Verification Coverage
card.

Cross-ref
---------
* :mod:`kairos.silicon_review` — orchestrator template (Bet E).
* :mod:`kairos.model_invariants` — sibling pattern (Bet H).
* :mod:`kairos.sparsity` — sibling pattern (Bet F).
* :func:`kairos.lean.verify_proof` — per-invariant proof checker.
* ``Pythia.SideChannel`` — parallel research-track stub (asabi
  ATH-937 / ATH-950 v4 W1-W6 lane).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.lean_canonicalize import canonicalize_lean_identifier as _canonicalize_lean_identifier


KNOWN_ISOLATION_POLICIES = (
    "single_tenant",      # one customer, one process; baseline
    "multi_tenant",       # multiple customers, shared GPU/inference
    "confidential",       # SEV / TDX / Nitro Enclave isolation
    "federated",          # multi-party computation across tenants
)


KNOWN_INVARIANT_KINDS = (
    "constant_time_execution",     # no secret-dependent timing
    "cache_line_invariance",       # cache access pattern independent of secrets
    "no_secret_dependent_branch",  # control flow independent of secrets
    "no_secret_dependent_memory",  # memory access addresses independent of secrets
    "no_speculative_leak",         # Spectre / Meltdown class
    "tenant_isolation",            # cross-tenant memory + CPU isolation
)


# Lean identifier canonicalization moved to :mod:`kairos.lean_canonicalize`
# (ATH-963 hoist). Re-imported above as ``_canonicalize_lean_identifier``
# to preserve the existing internal API; callers in this module are
# unchanged. The shared helper additionally relaxes the regex to keep
# Lean-valid Unicode letters (ε, λ, δ, π, σ, ...) — strict superset of
# the prior ASCII-only behavior.


@dataclass
class InvariantOutcome:
    """Per-invariant verdict + proof artifact."""

    invariant_name: str
    verdict: str
    """One of ``"proved" / "refuted" / "unknown" / "error"``."""

    proof_artifact_path: Path | None = None
    elapsed_sec: float = 0.0
    error_message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class SecurityResult:
    """Composite outcome from one security-invariant verification pass."""

    isolation_policy: str
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    timing_safe: bool
    """True iff every timing-related invariant returned ``proved``.
    Customer-facing claim handle."""

    no_cache_leak: bool
    """True iff every cache-related invariant returned ``proved``.
    Customer-facing claim handle."""

    all_invariants_proven: bool
    """True iff every enumerated invariant returned ``proved``.
    Composite-layer silent-success defense."""

    invariant_outcomes: list[InvariantOutcome] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def proved_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict == "proved"]

    @property
    def failed_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict != "proved"]


_TIMING_INVARIANT_NAMES = frozenset({
    "constant_time_execution",
    "no_secret_dependent_branch",
})

_CACHE_INVARIANT_NAMES = frozenset({
    "cache_line_invariance",
    "no_secret_dependent_memory",
    "no_speculative_leak",
})


def _classify_composite(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[str, bool]:
    """Map per-invariant verdicts → (composite_verdict, all_proven).

    Layer-2 of the 4-layer defense: precedence error > refuted >
    unknown > proved; empty list → error not silent-proved.
    """
    if not outcomes:
        return "error", False
    verdicts = [o.verdict for o in outcomes]
    if any(v == "error" for v in verdicts):
        return "error", False
    if any(v == "refuted" for v in verdicts):
        return "refuted", False
    if any(v == "unknown" for v in verdicts):
        return "unknown", False
    if all(v == "proved" for v in verdicts):
        return "proved", True
    return "error", False


def _compute_property_handles(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[bool, bool]:
    """Compute (timing_safe, no_cache_leak) handles.

    ``timing_safe`` is True iff every timing-class invariant returned
    ``proved``. Same defense as composite: any timing invariant
    refuted / unknown / error → timing_safe=False.

    Empty intersection (no timing invariants enumerated) defaults to
    False — silent-success defense: customer must explicitly enumerate
    the invariant for it to count as proven.
    """
    timing_outcomes = [
        o for o in outcomes if o.invariant_name in _TIMING_INVARIANT_NAMES
    ]
    cache_outcomes = [
        o for o in outcomes if o.invariant_name in _CACHE_INVARIANT_NAMES
    ]
    timing_safe = bool(timing_outcomes) and all(
        o.verdict == "proved" for o in timing_outcomes
    )
    no_cache_leak = bool(cache_outcomes) and all(
        o.verdict == "proved" for o in cache_outcomes
    )
    return timing_safe, no_cache_leak


def _build_invariant_theorem(
    invariant_name: str,
    isolation_policy: str,
    spec_source: str,
) -> str:
    """Construct a Lean theorem statement for the named security invariant.

    **Honest scaffold contract** (layer-3 of the 4-layer defense):

    Generated theorem references identifiers the customer spec is
    required to define:

    * ``{invariant_name}_property : Prop``
    * ``{invariant_name}_proof : {invariant_name}_property``

    Empty / missing / wrong-shaped spec → compile error → refuted.

    Identifier canonicalization (ATH-961 applied day one): non-
    alphanumeric chars → ``_``; leading digit gets ``_`` prefix.
    Dots, hyphens, spaces, brackets, Unicode all handled.

    NOT a ``: True := trivial`` tautology. Not ``:= rfl``. Not  # noqa: vacuous-proof-ok
    ``:= sorry``.
    """
    safe_inv = _canonicalize_lean_identifier(invariant_name)
    safe_pol = _canonicalize_lean_identifier(isolation_policy)
    return (
        f"{spec_source}\n\n"
        f"-- ATH-962 security invariant: {invariant_name} under "
        f"{isolation_policy} isolation.\n"
        f"-- Honest scaffold contract: the spec is required to define\n"
        f"--   {safe_inv}_property : Prop\n"
        f"--   {safe_inv}_proof : {safe_inv}_property\n"
        f"-- Empty / missing / wrong-shaped spec → compile error → refuted.\n"
        f"theorem {safe_inv}_verified_for_{safe_pol}_isolation : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def verify(
    isolation_policy: str,
    *,
    invariants: Sequence[str],
    kernel_lean_spec: str | Path | None = None,
    workdir: str | Path,
    lake_project: str | Path | None = None,
    timeout_sec_per_invariant: int = 300,
    emit_trace: bool = True,
) -> SecurityResult:
    """Verify side-channel security invariants against ``kernel_lean_spec``.

    Args:
        isolation_policy: isolation regime name (e.g. ``"multi_tenant"``,
            ``"confidential"``). Use values from
            :data:`KNOWN_ISOLATION_POLICIES` for max prompt-friendliness.
        invariants: list of invariant names to prove. Use values from
            :data:`KNOWN_INVARIANT_KINDS` for the prompt-friendly tactic
            library; arbitrary strings dispatched uniformly.
        kernel_lean_spec: path to Lean source describing the inference
            kernel + customer's invariant property/proof definitions.
        workdir: scratch directory.
        lake_project: optional Lake project to verify against.
        timeout_sec_per_invariant: per-invariant Lean wall-clock.
        emit_trace: when True (default), emit
            ``security_verify_complete`` on completion.

    Returns:
        :class:`SecurityResult`. Never raises for missing toolchain
        or per-invariant failure.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not invariants:
        result = SecurityResult(
            isolation_policy=isolation_policy,
            composite_verdict="error",
            timing_safe=False,
            no_cache_leak=False,
            all_invariants_proven=False,
            error_message="no invariants enumerated — verify() requires ≥1",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    spec_source = ""
    if kernel_lean_spec is not None:
        spec_path = Path(kernel_lean_spec).resolve()
        if not spec_path.exists():
            return SecurityResult(
                isolation_policy=isolation_policy,
                composite_verdict="error",
                timing_safe=False,
                no_cache_leak=False,
                all_invariants_proven=False,
                error_message=f"kernel_lean_spec does not exist: {spec_path}",
            )
        spec_source = spec_path.read_text()

    t0 = time.monotonic()
    outcomes: list[InvariantOutcome] = []

    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001
        result = SecurityResult(
            isolation_policy=isolation_policy,
            composite_verdict="error",
            timing_safe=False,
            no_cache_leak=False,
            all_invariants_proven=False,
            error_message=f"kairos.lean unavailable: {e}",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    for inv_name in invariants:
        inv_t0 = time.monotonic()
        theorem_source = _build_invariant_theorem(
            invariant_name=inv_name,
            isolation_policy=isolation_policy,
            spec_source=spec_source,
        )
        try:
            proof_result = verify_proof(
                theorem_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_invariant,
            )
        except Exception as e:  # noqa: BLE001
            outcomes.append(InvariantOutcome(
                invariant_name=inv_name,
                verdict="error",
                elapsed_sec=round(time.monotonic() - inv_t0, 3),
                error_message=f"verify_proof raised: {e}",
            ))
            continue

        # Layer-1 verdict mapping (ATH-948 lineage).
        if not proof_result.compiles:
            verdict = "refuted"
            err = (
                (proof_result.errors or [""])[0][:200]
                if proof_result.errors
                else "lean compile error"
            )
        elif proof_result.has_sorry:
            verdict = "refuted"
            err = "proof has sorry — incomplete"
        elif proof_result.banned:
            verdict = "refuted"
            err = f"banned construct: {proof_result.banned}"
        elif proof_result.axiom_clean is False:
            verdict = "refuted"
            err = (
                f"axiom leak: {list(proof_result.forbidden_axioms or [])[:3]}"
            )
        elif proof_result.score >= 1.0:
            verdict = "proved"
            err = None
        else:
            verdict = "error"
            err = (
                f"unexpected ProofResult shape: compiles=True, no sorry, "
                f"no banned, axiom_clean!=False, score={proof_result.score}"
            )

        outcomes.append(InvariantOutcome(
            invariant_name=inv_name,
            verdict=verdict,
            elapsed_sec=round(time.monotonic() - inv_t0, 3),
            error_message=err,
            details={
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "score": proof_result.score,
                "axiom_clean": proof_result.axiom_clean,
            },
        ))

    composite_verdict, all_proven = _classify_composite(outcomes)
    timing_safe, no_cache_leak = _compute_property_handles(outcomes)
    total_elapsed = round(time.monotonic() - t0, 3)

    result = SecurityResult(
        isolation_policy=isolation_policy,
        composite_verdict=composite_verdict,
        timing_safe=timing_safe,
        no_cache_leak=no_cache_leak,
        all_invariants_proven=all_proven,
        invariant_outcomes=outcomes,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        _emit_complete(result)

    return result


def _emit_complete(result: SecurityResult) -> None:
    """Best-effort trace emit. Never raises."""
    try:
        from kairos.observe import emit
        emit(
            "security_verify_complete",
            {
                "isolation_policy": result.isolation_policy,
                "composite_verdict": result.composite_verdict,
                "timing_safe": result.timing_safe,
                "no_cache_leak": result.no_cache_leak,
                "all_invariants_proven": result.all_invariants_proven,
                "invariants_proved": result.proved_invariants,
                "invariants_failed": result.failed_invariants,
                "total_elapsed_sec": result.total_elapsed_sec,
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break verify()
        pass


__all__ = [
    "InvariantOutcome",
    "SecurityResult",
    "KNOWN_ISOLATION_POLICIES",
    "KNOWN_INVARIANT_KINDS",
    "verify",
]
