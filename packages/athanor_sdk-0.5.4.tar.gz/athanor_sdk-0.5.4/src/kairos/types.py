"""Athanor SDK data types."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ScoreResult:
    """Result from scoring a student submission against a task.

    Tier classification: paid surface — produced by
    :class:`kairos.Environment` runs (which gate on the ``envs``
    product). The dataclass itself isn't gated; the gate fires on
    :class:`Environment` construction. See
    :class:`kairos.license_scope.LicenseScopeError` for the
    raised-on-no-license behavior.
    """

    score: float
    metadata: dict = field(default_factory=dict)
    student_files: dict = field(default_factory=dict)

    @property
    def lean_status(self) -> str | None:
        """Lean proof verification status, if applicable."""
        return self.metadata.get("lean_status")

    @property
    def checks_passed(self) -> int:
        """Number of correctness checks passed."""
        return self.metadata.get("checks_passed", 0)

    @property
    def checks_total(self) -> int:
        """Total number of correctness checks."""
        return self.metadata.get("checks_total", 0)


@dataclass
class TaskConfig:
    """Metadata for a single task within an environment.

    Tier classification: paid surface — task configs come from
    :class:`kairos.Environment` runs, which gate on the ``envs``
    product. Building a TaskConfig in isolation is unrestricted;
    fetching one from a real environment fires
    :class:`kairos.license_scope.LicenseScopeError` if the license
    doesn't grant the env.
    """

    task_id: str
    description: str
    difficulty: str
    solution_file: str
    lean_file: str | None = None
