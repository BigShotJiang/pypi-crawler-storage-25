"""ATH-388 — local-only mode for customers who don't use our platform.

Reads the deployment mode from two sources, in order:

1. `$ATHANOR_MODE` env var (env wins — easier for CI + one-off overrides).
2. `~/.athanor/config.json` `mode` key (persisted via `athanor config --set mode=local`).

Modes:

- `"local"` — skip all uploads to tahoe.athanor-ai.com; artifacts + traces
  stay under `~/.athanor/runs/<id>/`. No network calls beyond LLM API
  providers the customer configures themselves. Correct posture for
  customers with their own storage, air-gapped deployments, or anyone who
  simply doesn't want telemetry flowing to us.
- `"platform"` (default) — existing behavior. Traces + run summaries POST
  to the platform per `$ATHANOR_PLATFORM_URL`. Required for internal fleet
  runs + customer dashboards.

The ATH-388 follow-up will add pluggable storage backends (S3/GCS/Azure).
This ticket is the narrower "skip remote upload entirely" mode — small,
low-risk, unblocks customer-facing local workflows tonight.
"""
from __future__ import annotations

import json

from kairos.envvars import getenv_dual
from pathlib import Path


MODE_LOCAL = "local"
MODE_PLATFORM = "platform"
_VALID_MODES = frozenset({MODE_LOCAL, MODE_PLATFORM})


def _read_config_mode() -> str | None:
    """Read `mode` from `~/.athanor/config.json` if present."""
    path = Path.home() / ".athanor" / "config.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None
    mode = data.get("mode")
    if isinstance(mode, str) and mode in _VALID_MODES:
        return mode
    return None


def current_mode() -> str:
    """Resolve the SDK deployment mode. Defaults to `"platform"`."""
    env_mode = getenv_dual("MODE", "").strip().lower()
    if env_mode in _VALID_MODES:
        return env_mode
    config_mode = _read_config_mode()
    if config_mode is not None:
        return config_mode
    return MODE_PLATFORM


def is_local_mode() -> bool:
    """True iff the SDK is configured to skip all platform uploads."""
    return current_mode() == MODE_LOCAL


__all__ = ["MODE_LOCAL", "MODE_PLATFORM", "current_mode", "is_local_mode"]
