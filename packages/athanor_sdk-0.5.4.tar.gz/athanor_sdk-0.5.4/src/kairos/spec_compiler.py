"""solve/shared/spec_compile.py — Pure SpecV1 → IntentV1 transform (ATH-358).

Mirrored byte-identical at `athanor-sdk/src/athanor/spec_compiler.py`
(except for the `solve.shared.*` → `athanor.*` import rewrite on the
SDK side). The CI drift check (ATH-358 follow-up) hashes the body
minus the import preamble.

Rules:
  - Pure data transform. No LLM calls. No prompt template rendering.
  - Validates SpecV1 shape is well-formed before transforming. Use
    `solve.shared.spec_validate` for full schema validation first;
    this module trusts its input.
  - Applies defaults (budget / artifacts / retry_policy) to fill out
    IntentV1 fields the customer omitted.
  - Extension object is narrowed: only the sub-object matching the
    spec's `vertical` is forwarded as `vertical_hints`. Cross-vertical
    extensions are dropped silently (they're advisory, not contractual).

Called from:
  - `athanor-sdk/src/athanor/cli.py` — on `athanor spec submit` (before
    handing IntentV1 to the local mode_fleet process).
  - `solve.shared.modes.mode_fleet._expand_intent` — on receipt of an
    IntentV1 JSON via stdin/file.

SpecCompileError is used by both the SDK + builder as the shared
exception type for invalid-input-shape errors the compiler raises
when its assumption of a schema-valid input doesn't hold. Callers
should run `spec_validate.stage_a(spec)` first and only hit this
path on programmer error.
"""

from __future__ import annotations

import copy
from typing import cast


class SpecCompileError(ValueError):
    """Raised with field-level context when compile() hits a malformed
    SpecV1 that slipped past Stage-A validation (programmer error).

    Mirrors the `spec_validate.Defect` shape so the SDK can re-raise
    Stage-A defects through the same exception type without
    vocabulary drift:

        raise SpecCompileError(
            field="budget", severity="error",
            message="budget must include both wall_seconds and usd",
        )

    Callers that want the structured fields can catch + read
    `.field / .severity / .message`; callers that just want the text
    get `str(exc)`.
    """

    def __init__(self, field: str, message: str, severity: str = "error"):
        self.field = field
        self.message = message
        self.severity = severity
        super().__init__(f"[{severity}] {field}: {message}")

from kairos.spec_v1 import (
    DEFAULT_ARTIFACTS,
    DEFAULT_AXIOM_AUDIT,
    DEFAULT_BANNED_TACTICS,
    DEFAULT_BUDGET,
    DEFAULT_MAX_ITERATIONS,
    DEFAULT_ON_COUNTEREXAMPLE,
    DEFAULT_THRESHOLDS,
    DEFAULT_VERIFICATION,
    EXTENSION_TO_KIND,
    SPEC_VERSION,
    VERTICAL_TO_PLANNER_ROLE,
    IntentV1,
    SpecV1,
    TargetKind,
    _Budget,
    _IntentGoal,
    _IntentTarget,
    _Thresholds,
    _Verification,
)


def _infer_target_kind(target_file: str, vertical: str) -> TargetKind:
    """Best-effort kind inference from file extension.

    The spec itself doesn't carry target.kind (it lives in target_name
    + target_file), so compile infers it. If the file extension isn't
    in the map, fall back on vertical-based default.
    """
    for ext, kind in EXTENSION_TO_KIND.items():
        if target_file.endswith(ext):
            return kind
    # Vertical-based fallback.
    if vertical == "sysverilog":
        return "rtl_fix"
    if vertical == "neuron":
        return "kernel"
    return "theorem"


def _compile_goal(spec: SpecV1) -> _IntentGoal:
    """Translate acceptance_criteria into the IntentV1 goal shape.

    The customer's spec can set multiple acceptance criteria (e.g. a
    lean run with both zero-sorry and no-counterexample). IntentV1
    keeps them all — the planner uses whichever applies to the
    vertical.
    """
    ac = spec.get("acceptance_criteria", {}) or {}
    goal: _IntentGoal = {}
    if ac.get("zero_sorry", True):
        goal["lemma_closed"] = True
    axioms = ac.get("axiom_audit_match", DEFAULT_AXIOM_AUDIT)
    if axioms:
        goal["zero_sorry_axiom_match"] = list(axioms)
    if ac.get("kernel_verify_py_exits_zero"):
        goal["kernel_verified_no_cex"] = True
    if ac.get("rtl_ebmc_no_refutation"):
        goal["rtl_fixed_no_refutation"] = True
    return goal


def _narrow_extension(spec: SpecV1) -> dict:
    """Keep only the sub-object matching the spec's vertical.

    Customer convenience: they can embed per-vertical hints under
    `extension: {bbr3: {...}, sysverilog: {...}}` even though only
    one applies. Compile narrows to avoid confusing the planner.
    """
    ext = spec.get("extension") or {}
    vertical = spec["vertical"]
    if vertical in ext and isinstance(ext[vertical], dict):
        return dict(ext[vertical])
    # No vertical-specific sub-object; forward the whole thing in
    # case the customer used a flat extension layout.
    return dict(ext)


def _merge_budget(spec: SpecV1) -> _Budget:
    b = dict(DEFAULT_BUDGET)
    b.update(spec.get("budget", {}) or {})
    return cast(_Budget, b)


def _merge_verification(spec: SpecV1) -> _Verification:
    """Merge customer overrides onto DEFAULT_VERIFICATION. Omitted keys
    default to True — the full-verification path — so a spec without a
    `verification` object gets the same pipeline as every previous run.
    """
    v = dict(DEFAULT_VERIFICATION)
    v.update(spec.get("verification", {}) or {})
    return cast(_Verification, v)


def _merge_thresholds(spec: SpecV1) -> _Thresholds:
    t = dict(DEFAULT_THRESHOLDS)
    t.update(spec.get("thresholds", {}) or {})
    return cast(_Thresholds, t)


def compile(spec: SpecV1) -> IntentV1:
    """SpecV1 → IntentV1.

    Assumes `spec` is schema-valid. Callers run `spec_validate` first.
    """
    vertical = spec["vertical"]
    target_file = spec["target_file"]
    hints = spec.get("hints", {}) or {}
    retry = dict(spec.get("retry_policy", {}) or {})
    retry.setdefault("max_iterations", DEFAULT_MAX_ITERATIONS)
    retry.setdefault("on_counterexample", DEFAULT_ON_COUNTEREXAMPLE)

    target: _IntentTarget = {
        "file":  target_file,
        "name":  spec["target_name"],
        "kind":  _infer_target_kind(target_file, vertical),
    }

    intent: IntentV1 = {
        "intent_version":        SPEC_VERSION,
        "planner_role":          VERTICAL_TO_PLANNER_ROLE.get(
            vertical, "generic_closer"
        ),
        "target":                target,
        "goal":                  _compile_goal(spec),
        "hypotheses":            copy.deepcopy(spec.get("known_hypotheses", []) or []),
        "budget":                _merge_budget(spec),
        "vertical":              vertical,
        "vertical_hints":        _narrow_extension(spec),
        "banned_tactics":        list(hints.get("banned_tactics", DEFAULT_BANNED_TACTICS)),
        "preferred_lemmas":      list(hints.get("preferred_lemmas", []) or []),
        "free_text_hint":        hints.get("free_text", "") or "",
        "artifacts_expected":    list(spec.get("artifacts_expected", DEFAULT_ARTIFACTS)),
        "retry_policy":          cast("IntentV1", retry),  # type: ignore[typeddict-item]
        "phase_model_overrides": copy.deepcopy(spec.get("phase_model_overrides", {}) or {}),
        "operational":           copy.deepcopy(spec.get("operational", {}) or {}),
        "verification":          _merge_verification(spec),
        "thresholds":            _merge_thresholds(spec),
    }
    return intent
