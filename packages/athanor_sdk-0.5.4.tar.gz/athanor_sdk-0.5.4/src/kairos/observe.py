"""kairos.observe — capture raw litellm calls into the TraceSink pipeline.

Gap closed (2026-04-23): ``kairos.trace.SupabaseTraceSink`` + the
athanor-builder ``trace_uploader`` sidecar are solid, but nothing wires
arbitrary ``litellm.completion(...)`` calls into them. Agent scripts that
call litellm directly (outside ``kairos.prove()`` / ``kairos.session()``)
were losing every trace — the ATH-510 driver sweep tripped this.

Fix: a context manager that wraps ``litellm.completion`` within its
``with`` block, emitting one TraceEvent per call to the configured
:class:`TraceSink` and optionally appending a JSONL line to
``events_path`` for the ``trace_uploader`` sidecar. Scoped via
``contextvars`` so concurrent ``with`` blocks with different ``run_id``s
do not cross-contaminate, and zero-cost outside any active session.

Why monkey-patch instead of ``litellm.callbacks`` / ``success_callback``:
empirically, in litellm 1.83.7, the Anthropic and Azure-Anthropic
handlers bypass the CustomLogger dispatch for sync calls — a registered
``log_success_event`` is never invoked. Wrapping ``litellm.completion``
directly is provider-agnostic and survives litellm's internal routing
refactors. The wrapper is installed only inside the ``with`` block and
restored on exit (thread-safe via a lock on the install/uninstall
path; the wrapped completion is re-entrant-safe via contextvars).

Usage (fleet-internal, with Supabase sink)::

    from kairos.observe import litellm_trace_session
    from kairos.trace import SupabaseTraceSink

    sink = SupabaseTraceSink()  # reads SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY
    with litellm_trace_session(
        run_id="ath-510-track-b",
        sink=sink,
        events_path="/tmp/ath-510/events.jsonl",
        run_type="sdk_orchestration",
        run_subtype="autoformalize",
    ):
        import litellm
        resp = litellm.completion(model="anthropic/claude-opus-4-6", messages=[...])

Nests ``kairos.model_client.get_client(...).call(...)`` transparently —
that path calls ``litellm.completion`` internally, so the wrapper fires
the same way.

Purity: IMPURE_SIDE_EFFECTFUL (network/file writes via the sink).
Errors: swallowed — matches ``TraceSink`` contract. A flaky sink must
not break the user's ``litellm.completion`` call.
"""

from __future__ import annotations

import contextvars
import json
import logging
import os
import threading
import warnings
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from time import monotonic
from typing import Any, Iterator, Mapping
from uuid import uuid4

from kairos.trace import NoopTraceSink, RunSubtype, RunType, TraceEvent, TraceSink


_logger = logging.getLogger(__name__)


@dataclass
class _ObserveContext:
    run_id: str
    session_id: str | None
    sink: TraceSink
    events_path: Path | None
    run_type: RunType
    run_subtype: RunSubtype
    sequence_counter: int = 0
    sequence_lock: threading.Lock = field(default_factory=threading.Lock)
    # ATH-971 Phase 2: prove-session fields hoisted from the legacy
    # kairos.trace.CURRENT_SESSION dict-shape onto the canonical
    # observe context. Default ``None`` keeps existing callsites
    # unchanged. Per the Phase 2 design (no caller changes), these
    # are populated when the writer (``kairos.prove.session()``) or
    # the legacy bridge (``_try_legacy_session_context``) constructs
    # the context. The 5 direct CURRENT_SESSION readers stay on the
    # legacy contextvar through Phase 3.
    task_id: str | None = None
    vertical: str | None = None
    # ATH-1027: pipeline I/O artifact URIs surfaced on the canonical
    # agent-arc events (agent_start carries input_artifact_uris;
    # pipeline_complete carries output_artifact_uris). Inputs known
    # at session start; outputs settable on the ctx during the
    # session (callers append to output_artifact_uris as they
    # produce artifacts). Per asabi 2026-05-05 ATH-1024 epic.
    input_artifact_uris: list[str] = field(default_factory=list)
    output_artifact_uris: list[str] = field(default_factory=list)
    # ATH-1026: spawn_reason answers "why was this agent spawned?".
    # Required at the observe() public API level; surfaces in the
    # auto-emitted agent_start payload so the dashboard renders it
    # above-the-fold without parsing prose.
    spawn_reason: str = "manual_launch"
    # ATH-1041: parent_run_id links a child observe() session to its
    # parent for the customer-as-orchestrator pattern (per Aidan
    # 2026-05-05 directive). When the customer decomposes a theorem +
    # dispatches sub-lemmas via MCP `lean_race`/`lean_solve`, each
    # child run carries parent_run_id so the dashboard can render a
    # tree (RecursiveDecompositionPanel). Surfaced via payload-first
    # / hoist-later pattern (mirrors ATH-1027 input_artifact_uris):
    # stamped in agent_start payload; platform-side schema migration
    # to a top-level column is deferred.
    parent_run_id: str | None = None
    # ATH-1038 Gap 4: fleet_agent_role is cached on the ctx at
    # observe() enter (resolved from kwarg or KAIROS_FLEET_ROLE env
    # ONCE) and stamped on every TraceEvent emitted within this
    # session. Pre-fix: TraceEvent.default_factory read env per-event
    # at __init__ time, so a session whose env was unset at first
    # event emit time would have null on every event forever.
    fleet_agent_role: str | None = None
    # ATH-1063 Phase 0f: invocation_path tags how the trace event was
    # invoked. "mcp" = engineer's dev agent hit a kairos.mcp server
    # tool; "sdk" = direct kairos.* function call from a script /
    # notebook; "cli" = `kairos` terminal command. Resolved once at
    # observe() enter (kwarg > KAIROS_INVOCATION_PATH env > None) and
    # cached on ctx; stamped on every TraceEvent. Powers platform-side
    # /analytics/your-runs/[org_id] surface that distinguishes
    # engineer-via-MCP from SDK-direct from CLI.
    invocation_path: str | None = None
    # ATH-1038: pipeline outcome derivation. The customer-visible
    # outcome on `pipeline_complete` derives from (a) caller-explicit
    # mark via `mark_pipeline_outcome` (highest priority); (b) emitted
    # verdict events scanned at session close; (c) default
    # ("succeeded") only when neither path indicates failure.
    # Pre-fix: outcome defaulted to "succeeded" + only flipped to
    # "failed" on with-block raise — silent-success-on-actually-errored
    # honest-framing violation.
    pipeline_outcome: str | None = None
    pipeline_outcome_reason: str | None = None
    _emitted_event_types: set[str] = field(default_factory=set)
    _verdict_observations: list[dict[str, Any]] = field(default_factory=list)
    _start_monotonic: float = field(default_factory=lambda: __import__('time').monotonic())
    _total_prompt_tokens: int = 0
    _total_completion_tokens: int = 0

    def accumulate_tokens(self, prompt: int, completion: int) -> None:
        """Track LLM token usage for cost estimation."""
        self._total_prompt_tokens += prompt
        self._total_completion_tokens += completion

    def mark_pipeline_outcome(self, outcome: str, reason: str | None = None) -> None:
        """Caller-explicit override for the pipeline_complete.outcome.

        Highest priority over derived-from-events outcome resolution.
        Use from inside a `with observe()` block when the wrapped
        helper finished without raising but produced a non-success
        result the customer must see (e.g. ``ProveResult(outcome="errored")``).

        Allowed values: ``"succeeded" | "failed" | "errored" | "refuted"``.
        Other strings pass through but the dashboard render-layer may
        not have a chip for them. ``reason`` surfaces in the
        ``pipeline_complete`` payload as ``outcome_reason`` for
        customer-readable disclosure.
        """
        self.pipeline_outcome = outcome
        if reason is not None:
            self.pipeline_outcome_reason = reason

    def next_sequence(self) -> int:
        """Return the next per-run monotonic sequence number + bump
        the counter. Thread-safe via ``sequence_lock`` so concurrent
        wrapped calls emit distinct sequences within one run_id.
        """
        with self.sequence_lock:
            seq = self.sequence_counter
            self.sequence_counter = seq + 1
        return seq


_CURRENT_CONTEXT: contextvars.ContextVar[_ObserveContext | None] = contextvars.ContextVar(
    "kairos_observe_current_context", default=None
)

# ATH-738: module-global fallback for thread fan-out. ContextVar isn't
# inherited by ThreadPoolExecutor / threading.Thread workers, so worker
# threads inside an active litellm_trace_session see _CURRENT_CONTEXT
# as None. Wrapper falls back to _LATEST_SESSION when ContextVar is
# empty, so customers with thread-pool fan-out get traced events
# transparently. Single-thread case unchanged.
_LATEST_SESSION: _ObserveContext | None = None
_LATEST_SESSION_LOCK = threading.Lock()

_WRAPPER_INSTALLED = False
_ORIGINAL_COMPLETION: Any = None
_INSTALL_LOCK = threading.Lock()
_ACTIVE_SESSIONS = 0  # refcount — unwrap on the last exit


def _install_completion_wrapper() -> None:
    """Wrap ``litellm.completion`` so that calls made inside an active
    :func:`litellm_trace_session` block emit a trace event. Idempotent;
    refcounted so nested sessions restore the wrapper correctly.
    """
    global _WRAPPER_INSTALLED, _ORIGINAL_COMPLETION, _ACTIVE_SESSIONS
    with _INSTALL_LOCK:
        _ACTIVE_SESSIONS += 1
        if _WRAPPER_INSTALLED:
            return
        try:
            import litellm
        except ImportError:
            _logger.debug("litellm not installed; litellm_trace_session is a no-op")
            return
        _ORIGINAL_COMPLETION = litellm.completion

        def wrapped_completion(*args: Any, **kwargs: Any) -> Any:
            """Replacement for ``litellm.completion`` active only
            inside a :func:`litellm_trace_session` ``with`` block.
            When no active context exists (outside any session), the
            wrapper is transparent — forwards to the original call
            unchanged. Exceptions from the original call are
            re-raised + the failure is still emitted to the sink.
            """
            ctx = _CURRENT_CONTEXT.get()
            if ctx is None:
                # ATH-738: ContextVar is empty on worker threads spawned
                # by ThreadPoolExecutor / threading.Thread (Python doesn't
                # propagate ContextVar across thread boundaries). Fall
                # back to the module-global active session so worker
                # threads inside a litellm_trace_session still emit
                # events. Truly-no-session case keeps passthrough.
                with _LATEST_SESSION_LOCK:
                    ctx = _LATEST_SESSION
                if ctx is None:
                    return _ORIGINAL_COMPLETION(*args, **kwargs)
            start = monotonic()
            exc: BaseException | None = None
            response: Any = None
            try:
                response = _ORIGINAL_COMPLETION(*args, **kwargs)
                return response
            except BaseException as e:
                exc = e
                raise
            finally:
                try:
                    _emit_completion_event(
                        ctx,
                        kwargs=kwargs,
                        args=args,
                        response=response,
                        exc=exc,
                        wall_sec=monotonic() - start,
                    )
                except Exception:
                    _logger.exception("observe: _emit_completion_event failed")

        litellm.completion = wrapped_completion
        _WRAPPER_INSTALLED = True


def _uninstall_completion_wrapper() -> None:
    """Refcount-decrement. Restore the original ``litellm.completion`` when
    the last active session exits."""
    global _WRAPPER_INSTALLED, _ORIGINAL_COMPLETION, _ACTIVE_SESSIONS
    with _INSTALL_LOCK:
        _ACTIVE_SESSIONS = max(0, _ACTIVE_SESSIONS - 1)
        if _ACTIVE_SESSIONS > 0:
            return
        if not _WRAPPER_INSTALLED:
            return
        try:
            import litellm
            if _ORIGINAL_COMPLETION is not None:
                litellm.completion = _ORIGINAL_COMPLETION
        except ImportError:
            pass
        _WRAPPER_INSTALLED = False
        _ORIGINAL_COMPLETION = None


# ─────────────────────────────────────────────────────────────────────
# Native-provider wrappers (ATH-519). Closes the observability gap
# identified in PR #131 review: CustomLogger callbacks don't fire for
# Anthropic/Azure sync paths in litellm, and customers calling native
# provider SDKs (anthropic.Anthropic().messages.create, etc.) skip
# litellm entirely so `litellm_trace_session` doesn't see them either.
#
# Design: monkey-patch the provider SDK's method-on-class so *every*
# Client instance inherits the trace wrapping. Refcounted + install-
# locked, same pattern as _install_completion_wrapper.
# ─────────────────────────────────────────────────────────────────────


# Per-provider state. Key = provider name, value = (cls, attr, original).
# None value means not installed. Stored separately from the litellm
# globals so concurrent litellm_trace_session and anthropic_trace_session
# don't step on each other.
_PROVIDER_WRAPPERS: dict[str, tuple[type, str, Any] | None] = {
    "anthropic": None,
    # V2 follow-ups documented but not implemented this slice:
    #   "openai": None,     # openai.resources.chat.completions.Completions.create
    #   "gemini": None,     # google.genai.types.Client.models.generate_content
}
_PROVIDER_ACTIVE_SESSIONS: dict[str, int] = {k: 0 for k in _PROVIDER_WRAPPERS}


def _extract_anthropic_tokens(response: Any) -> tuple[int, int, float]:
    """Extract (prompt_tokens, completion_tokens, cost_usd) from an
    Anthropic ``Message`` response. Shape:

        Message.usage.input_tokens : int
        Message.usage.output_tokens: int
        Message.usage.cache_creation_input_tokens: int (optional)
        Message.usage.cache_read_input_tokens: int (optional)

    Cost comes from litellm if installed (it knows Anthropic pricing);
    otherwise 0.0 + the Verdict's user can compute from tokens
    themselves.
    """
    prompt = completion = 0
    try:
        usage = getattr(response, "usage", None)
        if usage is not None:
            prompt = int(getattr(usage, "input_tokens", 0) or 0)
            completion = int(getattr(usage, "output_tokens", 0) or 0)
    except Exception:  # noqa: BLE001 — usage attribute shape varies across SDK versions; default to 0
        pass
    cost = 0.0
    try:
        import litellm
        cost = float(
            litellm.completion_cost(completion_response=response) or 0.0
        )
    except Exception:  # noqa: BLE001 — litellm import or cost-table miss; default to 0
        pass
    return prompt, completion, cost


def _extract_anthropic_model(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
    """Anthropic messages.create takes ``model`` as a kwarg. Args form
    is rare (client.messages.create(model=..., ...) dominates)."""
    m = kwargs.get("model")
    if m:
        return str(m)
    return ""


def _install_anthropic_wrapper() -> None:
    """Patch ``anthropic.resources.messages.Messages.create`` so every
    call within an active :func:`anthropic_trace_session` emits a
    TraceEvent. Class-level patch → all Anthropic Client instances
    inherit the wrapping. Idempotent; refcounted.

    Async variant (``AsyncMessages.create``) follows the same pattern
    but requires an async wrapper — deferred to a V2 slice when we
    have a real async consumer. For now we explicitly document the
    gap: ``await client.messages.create(...)`` calls are NOT traced.
    """
    with _INSTALL_LOCK:
        _PROVIDER_ACTIVE_SESSIONS["anthropic"] += 1
        if _PROVIDER_WRAPPERS["anthropic"] is not None:
            return
        try:
            from anthropic.resources.messages import Messages
        except ImportError:
            _logger.debug(
                "anthropic SDK not installed; anthropic_trace_session "
                "is a no-op"
            )
            return
        original = Messages.create

        def wrapped_create(self, *args, **kwargs):
            ctx = _CURRENT_CONTEXT.get()
            if ctx is None:
                return original(self, *args, **kwargs)
            start = monotonic()
            exc: BaseException | None = None
            response: Any = None
            try:
                response = original(self, *args, **kwargs)
                return response
            except BaseException as e:
                exc = e
                raise
            finally:
                try:
                    _emit_provider_event(
                        ctx,
                        provider="anthropic",
                        model=_extract_anthropic_model(args, kwargs),
                        response=response,
                        exc=exc,
                        wall_sec=monotonic() - start,
                        extract_fn=_extract_anthropic_tokens,
                        # ATH-626 sub-1: pass messages so full-body capture
                        # can serialise the prompt when KAIROS_TRACE_FULL=1.
                        messages=kwargs.get("messages"),
                    )
                except Exception:
                    _logger.exception(
                        "observe.anthropic: emit_provider_event raised"
                    )

        Messages.create = wrapped_create  # type: ignore[method-assign]
        _PROVIDER_WRAPPERS["anthropic"] = (Messages, "create", original)


def _uninstall_anthropic_wrapper() -> None:
    """Refcount-decrement. Restore Messages.create on last session exit."""
    with _INSTALL_LOCK:
        _PROVIDER_ACTIVE_SESSIONS["anthropic"] = max(
            0, _PROVIDER_ACTIVE_SESSIONS["anthropic"] - 1
        )
        if _PROVIDER_ACTIVE_SESSIONS["anthropic"] > 0:
            return
        entry = _PROVIDER_WRAPPERS["anthropic"]
        if entry is None:
            return
        cls, attr, original = entry
        setattr(cls, attr, original)
        _PROVIDER_WRAPPERS["anthropic"] = None


def _emit_provider_event(
    ctx: _ObserveContext,
    *,
    provider: str,
    model: str,
    response: Any,
    exc: BaseException | None,
    wall_sec: float,
    extract_fn: Any,
    messages: Any = None,
) -> None:
    """Shared emit path for native-provider wrappers. Mirrors
    :func:`_emit_completion_event` but uses provider-specific extractor
    + stamps ``provider`` into the TraceEvent payload.
    """
    ok = exc is None
    if ok:
        prompt_tokens, completion_tokens, cost = extract_fn(response)
    else:
        prompt_tokens = completion_tokens = 0
        cost = 0.0

    seq = ctx.next_sequence()
    # ATH-736: payload field names match kairos.trace_schema canonical
    # (`tokens_in` / `tokens_out` / `elapsed_sec`). Pre-fix the wrapper
    # emitted `prompt_tokens` / `completion_tokens` / `wall_sec`, which
    # the ATH-574 strict-mode validator rejected → zero rows in
    # sdk_agent_events despite real LLM calls. Discovered via research
    # swarm dogfood 2026-04-27.
    payload: dict[str, Any] = {
        "provider": provider,
        "model": model,
        "tokens_in": prompt_tokens,
        "tokens_out": completion_tokens,
        "cost_usd": round(cost, 6),
        "elapsed_sec": round(wall_sec, 4),
        "ok": ok,
    }
    if ctx.session_id:
        payload["session_id"] = ctx.session_id
    if not ok and exc is not None:
        payload["error"] = f"{type(exc).__name__}: {str(exc)[:300]}"

    # ATH-626 sub-1+2: full bodies + tool_calls when KAIROS_TRACE_FULL=1
    payload.update(_extract_full_bodies(messages=messages, response=response))

    event = TraceEvent(
        run_id=ctx.run_id,
        run_type=ctx.run_type,
        run_subtype=ctx.run_subtype,
        event_type="llm_call_success" if ok else "llm_call_failure",
        sequence=seq,
        payload=payload,
    )
    try:
        ctx.sink.emit(event)
    except Exception:
        _logger.exception("observe: sink.emit raised — swallowing")

    if ctx.events_path is not None:
        try:
            line = json.dumps(
                {
                    "event": "llm_call" if ok else "llm_call_failed",
                    "stage": "observe",
                    "provider": provider,
                    "tool": model,
                    "severity": "info" if ok else "error",
                    "headline": (
                        f"{provider}/{model}: "
                        f"{completion_tokens} tokens, ${cost:.4f}"
                    ),
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "cost_usd": round(cost, 6),
                    "elapsed_sec": round(wall_sec, 4),
                    "run_id": ctx.run_id,
                    "sequence": seq,
                }
            )
            with open(ctx.events_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            _logger.exception(
                "observe: events.jsonl write raised — swallowing"
            )


def _extract_model(args: tuple[Any, ...], kwargs: dict[str, Any]) -> str:
    if "model" in kwargs:
        return str(kwargs["model"] or "")
    if args:
        first = args[0]
        if isinstance(first, str):
            return first
    return ""


def _extract_tokens_and_cost(response: Any) -> tuple[int, int, float]:
    prompt_tokens = completion_tokens = 0
    try:
        usage = getattr(response, "usage", None)
        if usage is not None:
            prompt_tokens = int(getattr(usage, "prompt_tokens", 0) or 0)
            completion_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
    except Exception:  # noqa: BLE001 — OpenAI/Gemini/etc. usage shape varies; default to 0
        pass
    cost = 0.0
    try:
        import litellm
        cost = float(litellm.completion_cost(completion_response=response) or 0.0)
    except Exception:  # noqa: BLE001 — litellm import or cost-table miss; default to 0
        pass
    return prompt_tokens, completion_tokens, cost


def _is_trace_full_enabled() -> bool:
    """ATH-626 sub-1/2 + 2026-04-25 emergency + ATH-799 (2026-04-27):
    resolve full-body capture state.

    Resolution order:
      1. Explicit env override always wins:
           KAIROS_TRACE_FULL=1/true/yes/on  → True
           KAIROS_TRACE_FULL=0/false/no/off → False
      2. Env unset: default-on for any of the three "this run will be
         seen by Athanor or paid for by the customer" signals:
           a. ``ATHANOR_SYNC_TOKEN`` is set (fleet/upload context, the
              original ATH-626 sub-2 signal)
           b. A paid-tier license is loaded (``products`` claim grants
              ``solve``). Paid customers see their own runs on the
              dashboard; the prompt+completion is what makes the
              dashboard useful. ATH-799 (Aidan: "if i'm dispatching an
              agent i want to see how it thinks").
      3. Env unset + no sync token + no paid license: default-off
         (free-tier privacy — zero-phone-home + zero-prompt-leak
         preserved).

    Background: from 2026-04-17 through 2026-04-25 19:32Z, fleet VMs
    ran without KAIROS_TRACE_FULL set, silently emitting summary-stub
    sdk_agent_events without LLM prompts/responses/tool_calls. The
    operator-side fix added KAIROS_TRACE_FULL=1 to fleet ~/.bashrc;
    this code-side fix makes it impossible to silently regress.

    Function (not a module constant) so test runners can monkey-patch
    os.environ + license_scope between tests.
    """
    import os
    explicit = os.environ.get("KAIROS_TRACE_FULL", "").strip().lower()
    if explicit in ("1", "true", "yes", "on"):
        return True
    if explicit in ("0", "false", "no", "off"):
        return False
    # Env unset: default-on iff we're in a fleet/upload context.
    if os.environ.get("ATHANOR_SYNC_TOKEN", "").strip():
        return True
    # Or a paid-tier license is loaded — paid customers see their own
    # runs on the dashboard and want the bodies. Best-effort import +
    # check; license_scope load failures (missing file, expired, bad
    # signature) fall through to default-off so free-tier wheels stay
    # zero-phone-home.
    try:
        from kairos import license_scope as _ls
        _license = _ls.load_license()
        if "solve" in _license.products:
            return True
    except Exception:  # noqa: BLE001 — license probe; telemetry default to free-tier on any error
        pass
    return False


def _truncate_str(s: str, cap: int) -> str:
    """Truncate a payload string at byte ceiling to stay under JSONB
    practical limits. cap is in characters, not bytes — Postgres TOAST
    sizes get hairy beyond ~1 MB compressed; we stay well clear at 100KB
    char cap (≈100KB UTF-8 bytes for ASCII, more for multibyte).
    """
    if len(s) <= cap:
        return s
    return s[: cap - 12] + "...[truncated]"


def _extract_full_bodies(
    *,
    messages: Any,
    response: Any,
) -> dict[str, Any]:
    """ATH-626 sub-1 + sub-2: when KAIROS_TRACE_FULL is enabled, extract
    full prompt body + completion body + tool_calls from a litellm or
    Anthropic-SDK response. Returns an empty dict when the env flag is
    off, so the caller can unconditionally `payload.update(...)`.

    Capture cap: 100,000 characters per field. JSONB practical ceiling
    is ~1 MB compressed; keeping each field at 100KB leaves headroom for
    multiple fields + lifecycle metadata in the same row.
    """
    if not _is_trace_full_enabled():
        return {}

    CAP = 100_000
    out: dict[str, Any] = {}

    # Prompt body — messages= kwarg / positional. Best-effort serialise.
    try:
        if messages is not None:
            import json as _json
            out["prompt_body"] = _truncate_str(
                _json.dumps(messages, default=str, ensure_ascii=False), CAP,
            )
    except Exception:  # noqa: BLE001 — broad-catch fallback
        pass  # best-effort — never break the wrapped call

    # Completion body + tool_calls — duck-typed across litellm /
    # Anthropic SDK / OpenAI SDK shapes.
    try:
        if response is not None:
            # litellm + OpenAI: response.choices[0].message.{content, tool_calls}
            choices = getattr(response, "choices", None)
            if choices:
                msg = getattr(choices[0], "message", None) or {}
                content = getattr(msg, "content", None) if not isinstance(msg, dict) else msg.get("content")
                if isinstance(content, str) and content:
                    out["completion_body"] = _truncate_str(content, CAP)
                tc = getattr(msg, "tool_calls", None) if not isinstance(msg, dict) else msg.get("tool_calls")
                if tc:
                    import json as _json
                    out["tool_calls"] = _truncate_str(
                        _json.dumps(tc, default=str, ensure_ascii=False), CAP,
                    )
            # Anthropic SDK: response.content is a list of {type, text|name|input}.
            anth_content = getattr(response, "content", None)
            if isinstance(anth_content, list) and not out.get("completion_body"):
                texts = []
                tools = []
                for block in anth_content:
                    btype = getattr(block, "type", None) or (
                        block.get("type") if isinstance(block, dict) else None
                    )
                    if btype == "text":
                        t = getattr(block, "text", None) or (
                            block.get("text") if isinstance(block, dict) else ""
                        )
                        if t:
                            texts.append(t)
                    elif btype == "tool_use":
                        name = getattr(block, "name", None) or (
                            block.get("name") if isinstance(block, dict) else None
                        )
                        inp = getattr(block, "input", None) or (
                            block.get("input") if isinstance(block, dict) else None
                        )
                        tools.append({"name": name, "input": inp})
                if texts:
                    out["completion_body"] = _truncate_str("".join(texts), CAP)
                if tools:
                    import json as _json
                    out["tool_calls"] = _truncate_str(
                        _json.dumps(tools, default=str, ensure_ascii=False), CAP,
                    )
    except Exception:  # noqa: BLE001 — tool_calls serialization for trace; truncation must not break observe
        pass

    return out


def _emit_completion_event(
    ctx: _ObserveContext,
    *,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    response: Any,
    exc: BaseException | None,
    wall_sec: float,
) -> None:
    ok = exc is None
    model = _extract_model(args, kwargs)
    if ok:
        prompt_tokens, completion_tokens, cost = _extract_tokens_and_cost(response)
    else:
        prompt_tokens = completion_tokens = 0
        cost = 0.0

    seq = ctx.next_sequence()
    # ATH-736: payload field names match kairos.trace_schema canonical
    # (`tokens_in` / `tokens_out` / `elapsed_sec`). Pre-fix the wrapper
    # emitted `prompt_tokens` / `completion_tokens` / `wall_sec`, which
    # the ATH-574 strict-mode validator rejected → zero rows in
    # sdk_agent_events despite real LLM calls. Discovered via research
    # swarm dogfood 2026-04-27.
    payload: dict[str, Any] = {
        "model": model,
        "tokens_in": prompt_tokens,
        "tokens_out": completion_tokens,
        "cost_usd": round(cost, 6),
        "elapsed_sec": round(wall_sec, 4),
        "ok": ok,
    }
    if ctx.session_id:
        payload["session_id"] = ctx.session_id
    if not ok and exc is not None:
        payload["error"] = f"{type(exc).__name__}: {str(exc)[:300]}"

    # ATH-626 sub-1+2: full bodies + tool_calls when KAIROS_TRACE_FULL=1
    payload.update(
        _extract_full_bodies(
            messages=kwargs.get("messages"),
            response=response,
        )
    )

    event = TraceEvent(
        run_id=ctx.run_id,
        run_type=ctx.run_type,
        run_subtype=ctx.run_subtype,
        event_type="llm_call_success" if ok else "llm_call_failure",
        sequence=seq,
        payload=payload,
    )
    try:
        ctx.sink.emit(event)
    except Exception:
        _logger.exception("observe: sink.emit raised — swallowing")

    if ctx.events_path is not None:
        try:
            line = json.dumps(
                {
                    "event": "llm_call" if ok else "llm_call_failed",
                    "stage": "observe",
                    "tool": model,
                    "severity": "info" if ok else "error",
                    "headline": f"{model}: {completion_tokens} tokens, ${cost:.4f}",
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "cost_usd": round(cost, 6),
                    "elapsed_sec": round(wall_sec, 4),
                    "run_id": ctx.run_id,
                    "sequence": seq,
                }
            )
            with open(ctx.events_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            _logger.exception("observe: events.jsonl write raised — swallowing")


@contextmanager
def litellm_trace_session(
    *,
    run_id: str | None = None,
    session_id: str | None = None,
    sink: TraceSink | None = None,
    events_path: str | Path | None = None,
    run_type: RunType = "sdk_orchestration",
    run_subtype: RunSubtype = "autoformalize",
) -> Iterator[_ObserveContext]:
    """Capture ``litellm.completion()`` calls made within the ``with`` block.

    Each call emits:
      * one :class:`kairos.trace.TraceEvent` to ``sink`` (default
        :class:`NoopTraceSink`)
      * one JSONL line to ``events_path`` if provided — compatible with
        ``athanor-builder/solve/shared/trace_uploader.py``

    Scoped via ``contextvars`` so concurrent ``with`` blocks with
    different ``run_id``s do not cross-contaminate.

    Args:
        run_id: stable run id (UUID string recommended). Auto-generated if None.
        session_id: optional Session UUID (from ``kairos.session()``), stamped
            into each TraceEvent.payload for grouping in Supabase.
        sink: where to send TraceEvents. Defaults to :class:`NoopTraceSink`.
        events_path: optional path to append a JSONL event line per call
            (picked up by the trace_uploader sidecar).
        run_type: "sdk_orchestration" (default) | "solve_run" | "plugin_verifier".
        run_subtype: "autoformalize" (default) | "spec_pipeline" | "cegar" | "swarm".

    Yields:
        The active :class:`_ObserveContext` — opaque, carries ``run_id``,
        ``sink``, ``events_path`` for callers that want to emit their own
        side-channel events.
    """
    _install_completion_wrapper()

    resolved_sink = sink if sink is not None else NoopTraceSink()
    resolved_events_path: Path | None = None
    if events_path is not None:
        resolved_events_path = Path(events_path)
        try:
            resolved_events_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            _logger.exception(
                "observe: failed to mkdir %s — JSONL writes will be dropped",
                resolved_events_path.parent,
            )
            resolved_events_path = None

    ctx = _ObserveContext(
        run_id=run_id or str(uuid4()),
        session_id=session_id,
        sink=resolved_sink,
        events_path=resolved_events_path,
        run_type=run_type,
        run_subtype=run_subtype,
    )
    token = _CURRENT_CONTEXT.set(ctx)
    # ATH-738: also publish to the module-global so thread-pool
    # workers (where ContextVar is empty) can fall back to it.
    global _LATEST_SESSION
    with _LATEST_SESSION_LOCK:
        _previous_latest = _LATEST_SESSION
        _LATEST_SESSION = ctx
    try:
        yield ctx
    finally:
        _CURRENT_CONTEXT.reset(token)
        with _LATEST_SESSION_LOCK:
            # Restore the previous "latest" so nested or sequential
            # sessions don't leak across `with` blocks. If a parallel
            # session reassigned _LATEST_SESSION while we were active,
            # leave that alone — it's the customer's intent.
            if _LATEST_SESSION is ctx:
                _LATEST_SESSION = _previous_latest
        try:
            ctx.sink.flush()
        except Exception:
            _logger.exception("observe: sink.flush raised — swallowing")
        _uninstall_completion_wrapper()


@contextmanager
def anthropic_trace_session(
    *,
    run_id: str | None = None,
    session_id: str | None = None,
    sink: TraceSink | None = None,
    events_path: str | Path | None = None,
    run_type: RunType = "sdk_orchestration",
    run_subtype: RunSubtype = "autoformalize",
) -> Iterator[_ObserveContext]:
    """Capture ``anthropic.Anthropic().messages.create()`` calls made
    within the ``with`` block.

    Closes the gap identified in PR #131 review: customer agents calling
    the **native** Anthropic SDK (not through litellm) get zero traces
    without this. Same interface + semantics as :func:`litellm_trace_session`
    so they compose — nesting both wrappers in a single ``with`` block
    traces litellm.completion + Anthropic native calls simultaneously.

    Sync-only in this slice. ``AsyncMessages.create`` await-calls are
    **NOT** traced yet — track under a follow-up ticket when we have a
    real async consumer.

    Args / Yields: see :func:`litellm_trace_session`.

    Scope note on ``shared contextvar``: both wrappers read from
    ``_CURRENT_CONTEXT``. Nested ``with litellm_trace_session(): with
    anthropic_trace_session():`` works but the inner enter overrides
    the outer ``run_id``. In practice callers set the same run_id on
    both, or use :func:`kairos.session` (ATH-524 will auto-wrap both
    from the session layer).
    """
    _install_anthropic_wrapper()

    resolved_sink = sink if sink is not None else NoopTraceSink()
    resolved_events_path: Path | None = None
    if events_path is not None:
        resolved_events_path = Path(events_path)
        try:
            resolved_events_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            _logger.exception(
                "observe: failed to mkdir %s — JSONL writes will be dropped",
                resolved_events_path.parent,
            )
            resolved_events_path = None

    ctx = _ObserveContext(
        run_id=run_id or str(uuid4()),
        session_id=session_id,
        sink=resolved_sink,
        events_path=resolved_events_path,
        run_type=run_type,
        run_subtype=run_subtype,
    )
    token = _CURRENT_CONTEXT.set(ctx)
    try:
        yield ctx
    finally:
        _CURRENT_CONTEXT.reset(token)
        try:
            ctx.sink.flush()
        except Exception:
            _logger.exception("observe: sink.flush raised — swallowing")
        _uninstall_anthropic_wrapper()


_VERDICT_OUTCOME_HIERARCHY = ("failed", "errored", "refuted", "succeeded")
"""Severity ordering. When deriving pipeline_complete.outcome from
emitted verdict events, the most-severe observation wins. ``failed`` is
reserved for raised-from-with-block; ``errored`` is the orchestrator-
fallback / auth-failure shape; ``refuted`` is a clean SAT counter-
example to a property; ``succeeded`` is the default when no
verdict-event observation was made."""


def _resolve_pipeline_outcome(
    ctx: _ObserveContext,
    *,
    with_block_raised: bool,
    exit_reason: str | None,
) -> tuple[str, str | None]:
    """Pick the customer-visible pipeline_complete.outcome at session close.

    Resolution order (ATH-1038):
    1. ``with_block_raised=True`` → ``"failed"`` with the exception class
       in ``outcome_reason``.
    2. ``ctx.pipeline_outcome`` set via ``mark_pipeline_outcome`` →
       caller-explicit value wins over derivation.
    3. Verdict observations recorded during the session: pick the
       most-severe along ``_VERDICT_OUTCOME_HIERARCHY``.
    4. Default ``"succeeded"`` only when no other signal indicates
       failure — preserves back-compat for existing callsites that
       genuinely succeeded.

    Returns ``(outcome, reason_or_None)``.
    """
    if with_block_raised:
        return ("failed", exit_reason)
    if ctx.pipeline_outcome is not None:
        return (ctx.pipeline_outcome, ctx.pipeline_outcome_reason)
    if not ctx._verdict_observations:
        return ("succeeded", None)
    most_severe_idx = len(_VERDICT_OUTCOME_HIERARCHY)
    most_severe_reason: str | None = None
    for obs in ctx._verdict_observations:
        verdict = str(obs.get("outcome", "")).lower()
        try:
            idx = _VERDICT_OUTCOME_HIERARCHY.index(verdict)
        except ValueError:
            continue
        if idx < most_severe_idx:
            most_severe_idx = idx
            most_severe_reason = obs.get("reason")
    if most_severe_idx == len(_VERDICT_OUTCOME_HIERARCHY):
        return ("succeeded", None)
    return (_VERDICT_OUTCOME_HIERARCHY[most_severe_idx], most_severe_reason)


# ATH-1038: event types whose payloads include an `outcome` key the
# pipeline outcome derivation should observe. Limited closed-set so
# emit-side tracking is cheap + the contract is auditable.
_VERDICT_EVENT_TYPES: frozenset[str] = frozenset({
    "tier_verdict",
    "ebmc_verdict",
    "verify_proof_attempt",
    "cycle_prove_attempt",
    "lean_solve_attempt",
    "lean_race_attempt",
    "predicate_verify_result",
    "sec_block_verified",
})


def _record_verdict_observation(ctx: _ObserveContext, event_type: str, payload: Mapping[str, Any]) -> None:
    """Track verdict-bearing event payloads on the ctx.

    Called from ``emit()`` after a successful sink emit. Only payloads
    of ``_VERDICT_EVENT_TYPES`` are recorded; non-verdict events are
    ignored to keep the per-emit cost trivial. The recorded list is
    consumed by :func:`_resolve_pipeline_outcome` at session close.
    """
    if event_type not in _VERDICT_EVENT_TYPES:
        return
    raw_outcome = payload.get("outcome")
    if raw_outcome is None:
        # `verify_proof_attempt` carries `compiles` instead of `outcome`;
        # reduce to a verdict bucket so the same hierarchy applies.
        compiles = payload.get("compiles")
        if compiles is False:
            raw_outcome = "errored"
        elif payload.get("refuted") is True:
            raw_outcome = "refuted"
        elif payload.get("proved") is True:
            raw_outcome = "succeeded"
    if raw_outcome is None:
        return
    ctx._verdict_observations.append({
        "event_type": event_type,
        "outcome": raw_outcome,
        "reason": payload.get("reason") or payload.get("error"),
    })


@contextmanager
def observe(
    *,
    run_id: str | None = None,
    session_id: str | None = None,
    sink: TraceSink | None = None,
    events_path: str | Path | None = None,
    run_type: RunType = "sdk_orchestration",
    run_subtype: RunSubtype = "autoformalize",
    task_id: str | None = None,
    vertical: str | None = None,
    input_artifact_uris: list[str] | None = None,
    spawn_reason: str | None = None,
    fleet_agent_role: str | None = None,
    parent_run_id: str | None = None,
    invocation_path: str | None = None,
) -> Iterator[_ObserveContext]:
    """Unified trace-observation wrapper — captures BOTH ``litellm.completion``
    AND native ``anthropic.Anthropic().messages.create`` calls with one
    shared :class:`_ObserveContext` (ATH-524).

    Before ATH-524, customers who hit both litellm + native Anthropic had
    to nest :func:`litellm_trace_session` inside :func:`anthropic_trace_session`
    (or vice versa). That nesting worked but the inner block's calls used
    the inner ``run_id`` / ``sink`` / ``session_id``, never the outer's —
    because ``_CURRENT_CONTEXT.set`` overrode. Side-effect: cross-provider
    runs produced TWO trace streams with disjoint run_ids + a customer had
    to stitch them.

    :func:`observe` installs both wrappers against a single context,
    so every LLM call in the ``with`` block — litellm, Anthropic native,
    or routed through :func:`kairos.model_client.get_client` — emits to
    the same ``run_id``. Single stream, one stitch.

    Composability: nesting :func:`observe` inside another :func:`observe`
    (or inside one of the provider-specific wrappers) sets a fresh context
    in the inner block; contextvar.reset restores the outer on exit.
    Refcount on ``_ACTIVE_SESSIONS`` + the anthropic twin keeps the
    underlying monkey-patches stable across nested enters.

    Args / Yields: see :func:`litellm_trace_session`.
    """
    # ATH-1026: spawn_reason answers "why was this agent spawned?".
    # Two-tier enforcement:
    #   - Default (warn-mode): missing spawn_reason logs a warning +
    #     defaults to "unspecified" so existing callers don't break.
    #     Customer code is incentivized to add an explicit value via
    #     the warning.
    #   - Strict mode (KAIROS_STRICT_SPAWN_REASON=1, ATH-1026 strict
    #     acceptance): missing spawn_reason raises ValueError —
    #     fail-loud rather than null-default per asabi 2026-05-05
    #     ATH-1024 epic acceptance criterion. CI flips this env var
    #     on to enforce the discipline structurally.
    #
    # Allowed values are free-form to leave room for future
    # customer-canonical taxonomies; recommended canonical strings:
    #   - "manual_launch"           — direct human-driven invocation
    #   - "cron_trigger"            — scheduled automation
    #   - "slack_mention"           — fleet-agent reply to a Slack ping
    #   - "cross_agent_handoff"     — one kairos pipeline calling another
    #   - "automated_fleet_sweep"   — periodic fleet-wide audit
    # ATH-1028 SDK#4 tightens this to a Literal enum once the
    # canonical taxonomy stabilizes.
    if (
        spawn_reason is None
        or not isinstance(spawn_reason, str)
        or not spawn_reason.strip()
    ):
        if os.environ.get("KAIROS_STRICT_SPAWN_REASON") == "1":
            raise ValueError(
                "kairos.observe.observe() requires an explicit "
                "spawn_reason kwarg per ATH-1026 in strict mode "
                "(KAIROS_STRICT_SPAWN_REASON=1). Pass one of: "
                "'manual_launch', 'cron_trigger', 'slack_mention', "
                "'cross_agent_handoff', 'automated_fleet_sweep', or "
                "a customer-canonical string. spawn_reason answers "
                "'why was this agent spawned?' on the customer-facing "
                "dashboard; the discipline is explicit-or-fail-loud "
                "rather than null-default."
            )
        else:
            _logger.warning(
                "kairos.observe.observe() called without explicit "
                "spawn_reason; defaulting to 'unspecified'. ATH-1026: "
                "pass spawn_reason='manual_launch' (or similar) to "
                "answer 'why was this agent spawned?' on the dashboard. "
                "Set KAIROS_STRICT_SPAWN_REASON=1 to flip this warning "
                "to a hard error."
            )
            spawn_reason = "unspecified"

    # ATH-1038 Gap 4: resolve fleet_agent_role ONCE on observe enter.
    # Caller-kwarg wins; otherwise read KAIROS_FLEET_ROLE env. If
    # neither is set, log a warning so the customer notices a null
    # fleet-classification chip on the dashboard immediately rather
    # than discovering it 600 events later. The resolved value is
    # cached on ctx (below) + stamped on every TraceEvent emitted
    # within this session. Pre-fix: TraceEvent default_factory read
    # env per-event lazily — a session that began with env unset
    # had null on every event even after the env was later set.
    if fleet_agent_role is None or not (
        isinstance(fleet_agent_role, str) and fleet_agent_role.strip()
    ):
        env_role = os.environ.get("KAIROS_FLEET_ROLE", "").strip()
        if env_role:
            fleet_agent_role = env_role
        else:
            _logger.warning(
                "kairos.observe.observe() called without explicit "
                "fleet_agent_role kwarg AND KAIROS_FLEET_ROLE env unset; "
                "every TraceEvent in this session will have "
                "fleet_agent_role=null and the dashboard will not "
                "render a fleet-classification chip. Pass "
                "fleet_agent_role='qa' (or your role) to observe(), "
                "or `export KAIROS_FLEET_ROLE=qa` before launching."
            )
            fleet_agent_role = None
    else:
        fleet_agent_role = fleet_agent_role.strip()

    # ATH-1063 Phase 0f: invocation_path resolution — kwarg > env > None.
    # Allowed values are "mcp" / "sdk" / "cli"; anything else is treated
    # as None with a warning. Mirror of the fleet_agent_role pattern but
    # without the warn-on-missing since invocation_path is purely a
    # provenance-on-dashboard tag (None just means the chip renders as
    # "—" placeholder; no functional impact).
    _ALLOWED_INVOCATION_PATHS = ("mcp", "sdk", "cli")
    if invocation_path is None or not (
        isinstance(invocation_path, str) and invocation_path.strip()
    ):
        env_path = os.environ.get("KAIROS_INVOCATION_PATH", "").strip()
        if env_path:
            invocation_path = env_path
        else:
            invocation_path = None
    else:
        invocation_path = invocation_path.strip()
    if invocation_path is not None and invocation_path not in _ALLOWED_INVOCATION_PATHS:
        _logger.warning(
            "kairos.observe.observe() invocation_path=%r not in allowed "
            "set %s; clearing to None. Pass one of 'mcp' / 'sdk' / 'cli' "
            "via kwarg or KAIROS_INVOCATION_PATH env.",
            invocation_path,
            _ALLOWED_INVOCATION_PATHS,
        )
        invocation_path = None

    # ATH-1043: when no caller-supplied sink, resolve from env via the
    # same waterfall the auto-bootstrap context uses (Supabase →
    # JsonlTraceSink → Noop on opt-out). Pre-fix: default was
    # NoopTraceSink() which silently dropped every event from any
    # explicit observe() call without a sink kwarg — research's
    # 2026-05-05 dogfood lost ~30 min of events because the
    # customer-as-orchestrator pattern uses explicit observe()
    # wrapping (`observe(run_id=child_id, parent_run_id=parent_id)`)
    # without specifying a sink. Auto-bootstrap had the right
    # default; explicit observe() did not — opt-out-by-default on the
    # API surface inverted the customer's clear intent.
    #
    # Sink resolution happens BEFORE installing the litellm /
    # anthropic wrappers. Pre-fix this PR: install fired first, then
    # default_sink_from_env() raised TraceSinkUnavailable in strict
    # mode → wrapper state leaked because __exit__ never ran (no
    # decrement of _ACTIVE_SESSIONS, _WRAPPER_INSTALLED stuck at True
    # so subsequent tests / sessions saw stale _ORIGINAL_COMPLETION).
    # Resolve sink first; install wrappers only after sink is in hand.
    if sink is not None:
        resolved_sink: TraceSink = sink
    else:
        # ATH-1043 (Aidan 2026-05-05 directive): three-tier waterfall —
        # try Supabase → fallback to JsonlTraceSink (always-available
        # filesystem write) → loud-error if BOTH fail. NEVER silent-drop
        # to NoopTraceSink. The fall-back-to-Noop pre-fix path was the
        # silent-bug class that lost research's ~30 min of trace data.
        # Lazy-import to avoid circular-import pitfall.
        from kairos.trace import (
            default_sink_from_env as _default_sink_from_env,
        )
        # default_sink_from_env() returns Jsonl as Rung 3 default (never
        # raises in non-strict mode). Under KAIROS_TRACE_STRICT=1 with
        # missing creds it raises TraceSinkUnavailable — let that
        # propagate as the loud-error per Aidan's directive, do NOT
        # catch + fall back to Noop. Customer running strict mode wants
        # the failure surfaced; same shape as the no-vacuous-success
        # discipline.
        resolved_sink = _default_sink_from_env()

    _install_completion_wrapper()
    _install_anthropic_wrapper()
    resolved_events_path: Path | None = None
    if events_path is not None:
        resolved_events_path = Path(events_path)
        try:
            resolved_events_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            _logger.exception(
                "observe: failed to mkdir %s — JSONL writes will be dropped",
                resolved_events_path.parent,
            )
            resolved_events_path = None

    ctx = _ObserveContext(
        run_id=run_id or str(uuid4()),
        session_id=session_id,
        sink=resolved_sink,
        events_path=resolved_events_path,
        run_type=run_type,
        run_subtype=run_subtype,
        task_id=task_id,
        vertical=vertical,
        input_artifact_uris=list(input_artifact_uris) if input_artifact_uris else [],
        spawn_reason=spawn_reason,
        fleet_agent_role=fleet_agent_role,
        parent_run_id=parent_run_id,
        invocation_path=invocation_path,
    )
    token = _CURRENT_CONTEXT.set(ctx)
    # ATH-1042: also publish to the module-global so worker threads
    # inside this session (FleetOrchestrator's drafter race, asyncio
    # ThreadPoolExecutor fan-out, etc.) can fall back to it. ContextVar
    # is empty in worker threads (not copied across thread boundaries —
    # see ATH-738), so without this update worker emits would fall
    # through to _LATEST_SESSION → if that is stale (e.g. an earlier
    # auto-bootstrap context) every event from a parallel race lands
    # under the WRONG run_id. Same pattern as `litellm_trace_session`
    # at line 815-818. Discovered in research dogfood 2026-05-05 run
    # 843f36fa where 4 sub-lemma race() calls captured 15 events
    # flat under one auto-bootstrap context instead of 4 distinct
    # parent_run_id-linked child contexts.
    global _LATEST_SESSION
    with _LATEST_SESSION_LOCK:
        _previous_latest_session_1042 = _LATEST_SESSION
        _LATEST_SESSION = ctx
    # ATH-1025: auto-emit canonical agent_start at session begin +
    # pipeline_complete at session end. Closes the 1-of-600 emit
    # ratio per platform's ATH-1024 audit (render layer ready;
    # emit layer dominantly empty pre-fix).
    #
    # Status flag tracks whether the with-block exited cleanly so
    # pipeline_complete carries an honest outcome=succeeded vs
    # outcome=failed disclosure.
    # ATH-1038: pipeline outcome derived at session close from (a)
    # explicit caller mark via ctx.mark_pipeline_outcome (highest
    # priority); (b) emitted verdict events scanned at close;
    # (c) default "succeeded" only when neither path indicates failure.
    # `_with_block_raised` marks (b)→fall-through-to-failed when the
    # with-block exited via exception.
    _with_block_raised = False
    _exit_reason: str | None = None
    try:
        agent_start_payload: dict[str, Any] = {
            "run_type": run_type,
            "run_subtype": run_subtype,
            "vertical": vertical,
            "task_id": task_id,
            "input_artifact_uris": list(ctx.input_artifact_uris),
            "spawn_reason": ctx.spawn_reason,
        }
        if ctx.parent_run_id is not None:
            # ATH-1041: stamp parent linkage in payload (hoist to a
            # top-level column once platform's schema migration lands).
            agent_start_payload["parent_run_id"] = ctx.parent_run_id
        emit("agent_start", agent_start_payload)
    except Exception:
        # Defensive: never let an emit failure kill the wrapped
        # work. Trace coverage is best-effort; the customer's
        # actual pipeline must still run.
        _logger.exception("observe: agent_start emit raised — swallowing")
    try:
        yield ctx
    except BaseException as exc:
        _with_block_raised = True
        _exit_reason = f"{type(exc).__name__}: {str(exc)[:200]}"
        raise
    finally:
        outcome, outcome_reason = _resolve_pipeline_outcome(
            ctx,
            with_block_raised=_with_block_raised,
            exit_reason=_exit_reason,
        )
        try:
            from time import monotonic as _mono
            wall_time = round(_mono() - ctx._start_monotonic, 2)
            payload: dict[str, Any] = {
                "run_type": run_type,
                "run_subtype": run_subtype,
                "vertical": vertical,
                "task_id": task_id,
                "outcome": outcome,
                "output_artifact_uris": list(ctx.output_artifact_uris),
                "wall_time_seconds": wall_time,
                "total_prompt_tokens": ctx._total_prompt_tokens,
                "total_completion_tokens": ctx._total_completion_tokens,
            }
            if ctx._total_prompt_tokens > 0:
                from kairos.model_prices import estimate_cost_usd
                try:
                    cost = estimate_cost_usd(
                        ctx._total_prompt_tokens,
                        ctx._total_completion_tokens,
                    )
                    payload["estimated_cost_usd"] = round(cost, 4)
                except Exception:  # noqa: BLE001
                    pass
            if outcome_reason is not None:
                payload["outcome_reason"] = outcome_reason
            emit("pipeline_complete", payload)
        except Exception:
            _logger.exception(
                "observe: pipeline_complete emit raised — swallowing"
            )
        _CURRENT_CONTEXT.reset(token)
        # ATH-1042: restore the previous _LATEST_SESSION so nested or
        # sequential observe() blocks don't leak across `with` boundaries.
        # If a parallel session reassigned _LATEST_SESSION while we were
        # active, leave it alone — that's the customer's intent.
        with _LATEST_SESSION_LOCK:
            if _LATEST_SESSION is ctx:
                _LATEST_SESSION = _previous_latest_session_1042
        try:
            ctx.sink.flush()
        except Exception:
            _logger.exception("observe: sink.flush raised — swallowing")
        _uninstall_anthropic_wrapper()
        _uninstall_completion_wrapper()


# ═══════════════════════════════════════════════════════════════════════
# ATH-841 — default-on trace upload at SDK boundary
# ═══════════════════════════════════════════════════════════════════════
#
# Pre-fix `kairos.lean.verify_proof` and friends emitted to the trace
# sink only when wrapped in an explicit `kairos.observe()` /
# `kairos.session()` context. Bespoke driver scripts
# (`nohup python3 driver.py` with `from kairos.lean import verify_proof;
# verify_proof(...)`) silently bypassed the observability surface — no
# attribution, cost tracking, or safety-relevant signal reached the
# platform. Customers writing their own driver scripts hit this exact
# pattern; we just dogfooded it ourselves on the 2026-04-28 calibration
# sweep.
#
# Fix shape:
# 1. Public `kairos.observe.emit(event_type, payload, ...)` helper.
#    Uses the active `_ObserveContext` when one exists; otherwise lazy-
#    bootstraps a free-tier observe-only context using
#    `default_sink_from_env()` (the ATH-707 waterfall: Supabase if
#    token, else local JSONL at `~/.athanor/runs/<run_id>/events.jsonl`).
# 2. Auto-bootstrap is OBSERVE-LEVEL, not session-level. Free-tier
#    customers calling `verify_proof` outside any context don't get
#    license-blocked (per qa flag #1 — `kairos.session()` is
#    paid-gated; observe is free-tier).
# 3. atexit hook flushes the auto-bootstrapped context on process exit
#    so a driver that exits before opening any session still gets
#    traces persisted (per qa flag #3 — without atexit, a queue-and-
#    flush-later approach loses everything when the process dies first).
# 4. JSONL backstop already lives in `default_sink_from_env`'s
#    JsonlTraceSink path; auto-bootstrap inherits that.
#
# verify_proof / cycle_prove / lean_orchestrate.race+solve call
# `emit_default` on entry so a bespoke `nohup python3 driver.py`
# pattern produces a trace by default.


_AUTO_BOOTSTRAPPED_CONTEXT: _ObserveContext | None = None
_AUTO_BOOTSTRAPPED_LOCK = threading.Lock()
_ATEXIT_REGISTERED = False


def _auto_bootstrap_context(
    *,
    run_subtype: RunSubtype = "theorem_proving",
) -> _ObserveContext:
    """Lazy-create an observe context when no caller-supplied one exists.

    ATH-841 + qa flag #1: this is OBSERVE-level (free-tier), NOT a
    paid `kairos.session()` — so a customer with no paid license still
    gets traces from `verify_proof`. The session() escalation path stays
    a separate, license-gated affordance.

    Sink: :func:`kairos.trace.default_sink_from_env`'s waterfall
    (Supabase when token + URL configured, else JSONL backstop at
    ``~/.athanor/runs/<run_id>/events.jsonl``). Customer can opt
    out via ``KAIROS_NO_TRACE=1`` (per ATH-707).

    Stashed in `_AUTO_BOOTSTRAPPED_CONTEXT` (module-global) so all
    subsequent `emit` calls in this process share the same run_id +
    sink. Idempotent — first call creates, later calls reuse.

    Registers an `atexit` hook on first call so the sink is flushed
    when the process exits (catches the bypass-pattern + bare-script
    case where no `with observe()` block ever opens).
    """
    global _AUTO_BOOTSTRAPPED_CONTEXT, _ATEXIT_REGISTERED
    with _AUTO_BOOTSTRAPPED_LOCK:
        if _AUTO_BOOTSTRAPPED_CONTEXT is not None:
            return _AUTO_BOOTSTRAPPED_CONTEXT

        # Lazy-import default_sink_from_env to avoid a top-level cycle.
        # Catch TraceSinkUnavailable: when KAIROS_TRACE_STRICT=1 is set
        # and trace-sink env vars are missing (a fleet-VM operational
        # mis-config), default_sink_from_env raises. Auto-bootstrap
        # catches that case + falls back to NoopTraceSink with a loud
        # stderr warning — preserves verify_proof's return contract
        # while still alerting the operator that traces aren't landing.
        from kairos.trace import (
            NoopTraceSink as _NoopTraceSink,
            TraceSinkUnavailable as _TraceSinkUnavailable,
            default_sink_from_env,
        )
        try:
            sink = default_sink_from_env()
        except _TraceSinkUnavailable as exc:
            try:
                import sys as _sys
                print(
                    f"[kairos.observe] auto-bootstrap could not resolve "
                    f"a trace sink ({exc.__class__.__name__}: {exc}). "
                    f"Falling back to NoopTraceSink — events from "
                    f"this process will NOT reach Supabase or local "
                    f"JSONL. To restore traces: unset "
                    f"KAIROS_TRACE_STRICT or set the missing env vars.",
                    file=_sys.stderr,
                )
            except Exception:  # pragma: no cover  # noqa: BLE001 — best-effort; failure swallowed
                pass
            sink = _NoopTraceSink()

        # ATH-1040 Gap B: cache fleet_agent_role on the auto-bootstrap
        # ctx so emit-side stamping picks it up. Pre-fix: bootstrap ctx
        # had role=None + emit-side stamping (ATH-1038) only fired on
        # ctx-cached values — net result: fleet_agent_role=null on every
        # event from a direct solve()/sorry_swarm()/sv.prove call. Same
        # env-read shape as the explicit observe() kwarg path.
        env_role = os.environ.get("KAIROS_FLEET_ROLE", "").strip() or None
        ctx = _ObserveContext(
            run_id=str(uuid4()),
            session_id=None,
            sink=sink,
            events_path=None,
            run_type="sdk_orchestration",
            run_subtype=run_subtype,
            fleet_agent_role=env_role,
        )
        _AUTO_BOOTSTRAPPED_CONTEXT = ctx

        if not _ATEXIT_REGISTERED:
            import atexit
            atexit.register(_atexit_flush_auto_bootstrap)
            _ATEXIT_REGISTERED = True

        # One-line announce so the customer knows where to find their
        # trace. stderr so it doesn't pollute stdout pipelines. Quiet
        # under KAIROS_NO_TRACE — that's the explicit opt-out.
        if os.environ.get("KAIROS_NO_TRACE") != "1":
            sink_name = type(sink).__name__
            try:
                import sys as _sys
                print(
                    f"[kairos.observe] auto-bootstrap context "
                    f"run_id={ctx.run_id[:8]} sink={sink_name} — "
                    f"set KAIROS_NO_TRACE=1 to silence",
                    file=_sys.stderr,
                )
            except Exception:  # pragma: no cover — defensive  # noqa: BLE001 — best-effort; failure swallowed
                pass

        return ctx


def _atexit_flush_auto_bootstrap() -> None:
    """ATH-841 process-exit safety net.

    Fires on Python interpreter shutdown; drains the
    auto-bootstrapped context's sink so events queued in-memory
    (e.g. SupabaseTraceSink batches not yet POSTed) reach durable
    storage before the process dies.

    Defensive: any exception during flush is swallowed — atexit
    handlers must not raise, and a noisy crash on shutdown helps
    no one.
    """
    ctx = _AUTO_BOOTSTRAPPED_CONTEXT
    if ctx is None:
        return
    try:
        ctx.sink.flush()
    except Exception:  # noqa: BLE001 — logged + re-raised in alternate form
        # Atexit must not raise. Log to stderr for visibility.
        try:
            import sys as _sys
            print(
                "[kairos.observe] atexit flush raised — events may "
                "be journalled but not yet uploaded; replay via "
                "`kairos trace replay`",
                file=_sys.stderr,
            )
        except Exception:  # pragma: no cover  # noqa: BLE001 — best-effort; failure swallowed
            pass


# ATH-971 Phase 4: legacy CURRENT_SESSION bridge deleted. Phase 3 added
# the bridge with a once-per-process DeprecationWarning to mark the
# start of the deprecation cycle; Phase 4 closes that cycle. The
# kairos.prove.session() writer no longer populates CURRENT_SESSION
# (only _CURRENT_CONTEXT via the with _observe(...) block), so the
# bridge has nothing left to bridge. The contextvar definition itself
# stays in kairos.trace through one release cycle for any out-of-tree
# callers that still import the symbol; it can be deleted in a later
# release.


def _resolve_emit_context(
    *,
    run_subtype: RunSubtype = "theorem_proving",
    silent_if_no_session: bool = False,
) -> _ObserveContext | None:
    """Find or create the observe context for an `emit` call.

    Priority order (post-ATH-971 Phase 4 -- bridge step removed):
    1. ``_CURRENT_CONTEXT`` -- caller is inside a ``with observe()`` /
       ``with session()`` block; use that ctx.
    2. ``_LATEST_SESSION`` -- thread fan-out fallback (ATH-738);
       worker thread sees the parent's session.
    3. Auto-bootstrap -- no active context anywhere; lazy-create one
       per process so subsequent emits share the run_id + sink.

    When ``silent_if_no_session`` is True (sv-* migrated callers +
    public ``active_session_context``), step 3 is skipped and the
    function returns ``None``. Privacy-fence commitment preserved:
    callers that emit only "if a session is active" must NOT cause
    auto-bootstrap.
    """
    ctx = _CURRENT_CONTEXT.get()
    if ctx is not None:
        return ctx
    with _LATEST_SESSION_LOCK:
        ctx = _LATEST_SESSION
    if ctx is not None:
        return ctx
    if silent_if_no_session:
        return None
    return _auto_bootstrap_context(run_subtype=run_subtype)


def emit(
    event_type: str,
    payload: dict[str, Any],
    *,
    run_subtype: RunSubtype = "theorem_proving",
    silent_if_no_session: bool = False,
) -> str | None:
    """Emit a trace event from an SDK-boundary helper (ATH-841).

    Public emit surface for SDK-level helpers (``verify_proof``,
    ``cycle_prove``, ``lean_orchestrate.race`` / ``solve``) so a
    bespoke driver that calls these without an explicit observe
    context still produces traces.

    Behavior:
    - Caller inside a ``with observe()`` / ``with session()`` block:
      emit goes to that context's sink + run_id.
    - Caller outside any context (e.g. ``nohup python3 driver.py``):
      auto-bootstraps a free-tier observe context (NOT a paid session)
      using ``default_sink_from_env()``. Subsequent emits in the same
      process share the run_id + sink; atexit flushes on shutdown.
    - ``KAIROS_NO_TRACE=1``: explicit opt-out per ATH-707 -- sink is
      ``NoopTraceSink``, no events written, no banner printed.
    - ATH-969: legacy ``kairos.prove.session()`` contexts (which set
      :data:`kairos.trace.CURRENT_SESSION` rather than
      ``_CURRENT_CONTEXT``) are now bridged read-only so this emit
      surface sees them; sv-* helpers can migrate via the
      ``silent_if_no_session`` flag below.

    Args:
        event_type: the event type identifier (e.g.
            ``"verify_proof_attempt"``). Should be permissively
            registered in :mod:`kairos.trace_schema` (or it'll log
            a warning and pass through under ``KAIROS_TRACE_STRICT=0``,
            the default).
        payload: structured event data -- keep small + JSON-friendly.
            Big strings should be reduced via
            :func:`kairos.trace.reduce_long_arg` before being passed.
        run_subtype: drives the auto-bootstrap path's
            ``solve_runs.run_subtype`` (and downstream
            ``vertical='theorem_proving'`` mapping). Default
            ``"theorem_proving"`` per qa flag #2 (don't lose customer
            attribution to the lossy ``"other"`` default).
        silent_if_no_session: when True (ATH-969 sv-* helper
            migration path), skip auto-bootstrap and return ``None``
            if no session is active anywhere (``_CURRENT_CONTEXT``
            empty AND ``_LATEST_SESSION`` empty AND legacy
            ``kairos.trace.CURRENT_SESSION`` empty). Preserves the
            privacy-fence commitment in
            :mod:`kairos.sv._trace_helpers` -- ``pip install
            athanor-sdk`` followed by ``import kairos`` must NOT
            phone home unless the customer explicitly opens a
            session.

    Returns:
        The ``run_id`` the event was emitted under. Customers / SDK
        callers can log this so the customer knows where to find
        their trace on ``/solve-runs/<run_id>``. Returns ``None``
        when ``silent_if_no_session`` is True and no session was
        active.
    """
    ctx = _resolve_emit_context(
        run_subtype=run_subtype,
        silent_if_no_session=silent_if_no_session,
    )
    if ctx is None:
        return None
    sequence = ctx.next_sequence()
    event = TraceEvent(
        run_id=ctx.run_id,
        event_type=event_type,
        sequence=sequence,
        run_type=ctx.run_type,
        run_subtype=ctx.run_subtype,
        payload=dict(payload),
    )
    # ATH-1038 Gap 4: stamp the ctx-cached fleet_agent_role so the
    # session-resolved value wins over TraceEvent.default_factory's
    # env-time read. Caller-intent (kwarg or env-at-observe-enter)
    # over per-event-env-at-emit-time.
    if ctx.fleet_agent_role is not None:
        event.fleet_agent_role = ctx.fleet_agent_role
    # ATH-1063 Phase 0f: stamp invocation_path from ctx so the
    # platform /analytics/your-runs/[org_id] surface can distinguish
    # engineer-via-MCP from SDK-direct from CLI. Same caller-intent
    # discipline as fleet_agent_role above.
    if ctx.invocation_path is not None:
        event.invocation_path = ctx.invocation_path
    try:
        ctx.sink.emit(event)
    except Exception:
        _logger.exception(
            "observe.emit: sink.emit raised on event_type=%s -- "
            "swallowed per TraceSink Protocol",
            event_type,
        )
    # ATH-1038: track verdict-bearing events so the pipeline_complete
    # outcome can be derived at session close. Best-effort — never
    # raises into the customer's emit() callsite.
    try:
        ctx._emitted_event_types.add(event_type)
        _record_verdict_observation(ctx, event_type, payload)
    except Exception:
        _logger.exception(
            "observe.emit: verdict-observation tracking raised — swallowing"
        )
    return ctx.run_id


def active_session_context(
    *,
    run_subtype: RunSubtype = "theorem_proving",
) -> _ObserveContext | None:
    """ATH-971 Phase 3 public helper: return the active observe
    context, or ``None`` if no session is active anywhere.

    Resolution order matches :func:`_resolve_emit_context` with
    ``silent_if_no_session=True``: ``_CURRENT_CONTEXT`` -> module-
    global ``_LATEST_SESSION`` -> legacy ``CURRENT_SESSION`` bridge.
    Auto-bootstrap is NOT triggered.

    The canonical replacement for ``kairos.trace.CURRENT_SESSION.get()``
    callers that need to detect "is there an active session" or read
    fields off the active session. Phase 3 migrated callers:
    :mod:`kairos.lean`, :mod:`kairos.differential`,
    :mod:`kairos.generator_synthesize`, :mod:`kairos.sv.cegar`. The
    direct CURRENT_SESSION readers in those modules now go through
    this helper; the legacy contextvar stays alive through one
    deprecation cycle (a once-per-process DeprecationWarning fires
    when the legacy bridge produces the context).
    """
    return _resolve_emit_context(
        run_subtype=run_subtype, silent_if_no_session=True,
    )


__all__ = [
    "litellm_trace_session", "anthropic_trace_session", "observe",
    # ATH-841: default-on emit at SDK boundary.
    "emit",
    # ATH-971 Phase 3: canonical session detector for the migrated
    # CURRENT_SESSION readers.
    "active_session_context",
]
