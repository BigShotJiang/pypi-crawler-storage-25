"""ATH-690 follow-up — `kairos audit show` CLI for customer self-service.

Tail-reads `~/.athanor/audit.jsonl` and prints a filtered view of
license-gate decisions. Customer-facing (per ATH-690 acceptance: "just
a CLI for now: kairos audit show --since 7d"). Internals stay
unchanged — this is just a render layer over the local JSONL journal.

## Usage

    kairos audit show                    # all decisions, oldest-first
    kairos audit show --since 7d         # decisions in the last 7 days
    kairos audit show --since 1h         # decisions in the last hour
    kairos audit show --denied           # only deny decisions
    kairos audit show --json             # raw JSONL (each line a row)
    kairos audit show --path /tmp/x.jsonl  # alternate journal path

## Output shape (default tabular)

    TIMESTAMP                  GATE                 ARG          DECISION    REASON                  CALL_SITE
    2026-04-26T08:32:18+00:00  require_product      solve        allow                                kairos.prove.prove
    2026-04-26T08:33:01+00:00  require_env_access   sysverilog   deny        env_not_granted          kairos.env.Environment.__init__
    2026-04-26T08:34:05+00:00  load_license         /home/x/.../  deny        no_license_file          kairos.fleet.Orchestrator.__init__

## Privacy

This CLI reads ONLY the local journal at `~/.athanor/audit.jsonl`. It
never phones home and never reads the Supabase mirror. Customers
control retention by editing or rotating that file. Per the
ATH-686 PR 3 threat-model doc, this is a customer-owned forensic
surface — not a control plane.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from kairos.audit_log import AUDIT_JOURNAL_PATH


def _parse_since(spec: str) -> timedelta:
    """Parse a `--since` spec like `7d`, `1h`, `30m`, `45s`.

    Returns a `timedelta`. Raises `ValueError` on malformed input.
    """
    if not spec:
        raise ValueError("empty --since spec")
    unit = spec[-1].lower()
    try:
        n = int(spec[:-1])
    except ValueError as e:
        raise ValueError(
            f"--since must be <integer><unit>; got {spec!r}"
        ) from e
    if n < 0:
        raise ValueError(f"--since must be non-negative; got {spec!r}")
    if unit == "s":
        return timedelta(seconds=n)
    if unit == "m":
        return timedelta(minutes=n)
    if unit == "h":
        return timedelta(hours=n)
    if unit == "d":
        return timedelta(days=n)
    raise ValueError(
        f"--since unit must be one of s/m/h/d; got {unit!r} in {spec!r}"
    )


def _read_journal(path: Path) -> Iterable[dict]:
    """Yield one parsed JSON object per non-empty line.

    Skips blank lines + bad-JSON lines (logged to stderr) so a single
    corrupt line doesn't break the rest of the report.
    """
    if not path.is_file():
        return
    with path.open("r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as e:
                print(
                    f"warning: skipping malformed line {lineno}: {e}",
                    file=sys.stderr,
                )


def _filter_events(
    events: Iterable[dict],
    *,
    since: timedelta | None,
    denied_only: bool,
    gate: str | None = None,
) -> list[dict]:
    """Apply --since + --denied + --gate filters; return list."""
    cutoff = (
        datetime.now(timezone.utc) - since if since is not None else None
    )
    out = []
    for ev in events:
        if denied_only and ev.get("decision") != "deny":
            continue
        if gate is not None and ev.get("gate_name") != gate:
            continue
        if cutoff is not None:
            # AuditEvent renamed `ts` → `created_at` to match platform's
            # license_gate_decisions column (PostgREST column-name pin).
            # Fall back to legacy `ts` so pre-rename JSONL rows in a
            # customer's existing journal still parse.
            ts = ev.get("created_at") or ev.get("ts")
            if not ts:
                continue
            try:
                event_ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except ValueError:
                continue
            if event_ts < cutoff:
                continue
        out.append(ev)
    return out


def _render_tabular(events: list[dict]) -> str:
    """Render events as a fixed-width table for terminal viewing."""
    if not events:
        return "(no decisions match filter)"
    # Header.
    header = (
        "TIMESTAMP", "GATE", "ARG", "DECISION", "REASON", "CALL_SITE",
    )
    # Build rows.
    rows = []
    for ev in events:
        rows.append((
            (ev.get("created_at") or ev.get("ts", ""))[:25],
            ev.get("gate_name", ""),
            ev.get("gate_argument", "") or "-",
            ev.get("decision", ""),
            ev.get("reason", "") or "-",
            ev.get("call_site", "") or "-",
        ))
    # Column widths (header vs rows).
    widths = [
        max(len(header[i]), *(len(r[i]) for r in rows))
        for i in range(len(header))
    ]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    lines = [fmt.format(*header)]
    lines.extend(fmt.format(*r) for r in rows)
    return "\n".join(lines)


def cmd_audit_show(args: argparse.Namespace) -> int:
    """`kairos audit show` entry. Returns shell exit code."""
    path = Path(args.path) if args.path else (
        Path.home() / AUDIT_JOURNAL_PATH
    )
    if not path.is_file():
        print(
            f"audit journal not found at {path}. "
            "Either no license-gate decisions have been made yet, or "
            "the SDK was reinstalled and the local journal was wiped.",
            file=sys.stderr,
        )
        return 0

    since: timedelta | None = None
    if args.since:
        try:
            since = _parse_since(args.since)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2

    events = _filter_events(
        _read_journal(path),
        since=since,
        denied_only=args.denied,
        gate=args.gate,
    )

    if args.json:
        for ev in events:
            print(json.dumps(ev))
    else:
        print(_render_tabular(events))
    return 0


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Register `audit` + `audit show` on a top-level subparsers action."""
    p_audit = sub.add_parser(
        "audit",
        help="Inspect the local license-gate decision journal (ATH-690)",
    )
    audit_sub = p_audit.add_subparsers(dest="audit_sub")
    p_show = audit_sub.add_parser(
        "show",
        help="Tail-read ~/.athanor/audit.jsonl with optional filters",
    )
    p_show.add_argument(
        "--since", default=None,
        help="Show only events from the last <N><unit> "
             "(e.g. 7d, 1h, 30m, 45s)",
    )
    p_show.add_argument(
        "--denied", action="store_true",
        help="Show only deny decisions (forensic abuse-detection view)",
    )
    p_show.add_argument(
        "--gate", default=None,
        choices=("require_product", "require_env_access", "load_license"),
        help="Show only decisions for the named gate",
    )
    p_show.add_argument(
        "--json", action="store_true",
        help="Emit raw JSONL (one object per line) instead of the table",
    )
    p_show.add_argument(
        "--path", default=None,
        help="Alternate journal path (default: ~/.athanor/audit.jsonl)",
    )


__all__ = [
    "add_subparser",
    "cmd_audit_show",
]
