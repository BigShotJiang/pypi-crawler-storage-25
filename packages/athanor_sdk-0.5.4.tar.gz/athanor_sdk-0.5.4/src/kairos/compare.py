"""Compare two runs — diff per-task scores, compute improvement metrics."""
from __future__ import annotations

import json
from pathlib import Path


def load_run(path: str | Path) -> dict[str, float]:
    """Load a run file and return task_id -> score.

    Supports both {results: [...]} (batch eval) and single task dicts (solve).
    """
    data = json.loads(Path(path).read_text())
    results = data.get("results")
    if results is None and "score" in data and "task" in data:
        results = [data]
    elif results is None:
        results = []
    result: dict[str, float] = {}
    for r in results:
        task = r.get("task") or r.get("task_id")
        score = r.get("score")
        if task and isinstance(score, (int, float)):
            result[task] = float(score)
    return result


def compare_runs(run_a: str | Path, run_b: str | Path) -> dict:
    """Compare two run files task-by-task.

    Returns a dict with:
        - tasks: list of {task, score_a, score_b, delta}
        - mean_a, mean_b, mean_delta
        - improved: list of task_ids where b > a
        - regressed: list of task_ids where b < a
        - unchanged: list of task_ids where a == b
        - missing_in_a: tasks only in b
        - missing_in_b: tasks only in a
    """
    a = load_run(run_a)
    b = load_run(run_b)

    all_tasks = set(a.keys()) | set(b.keys())
    common = set(a.keys()) & set(b.keys())

    tasks = []
    improved: list[str] = []
    regressed: list[str] = []
    unchanged: list[str] = []

    for task in sorted(all_tasks):
        sa = a.get(task)
        sb = b.get(task)
        if sa is not None and sb is not None:
            delta = sb - sa
            tasks.append({
                "task": task,
                "score_a": round(sa, 4),
                "score_b": round(sb, 4),
                "delta": round(delta, 4),
            })
            if delta > 0.001:
                improved.append(task)
            elif delta < -0.001:
                regressed.append(task)
            else:
                unchanged.append(task)
        elif sa is not None:
            tasks.append({"task": task, "score_a": round(sa, 4), "score_b": None, "delta": None})
        else:
            tasks.append({"task": task, "score_a": None, "score_b": round(sb, 4), "delta": None})

    mean_a = sum(a.values()) / len(a) if a else 0.0
    mean_b = sum(b.values()) / len(b) if b else 0.0
    # Mean delta over common tasks only
    common_deltas = [b[t] - a[t] for t in common]
    mean_delta = sum(common_deltas) / len(common_deltas) if common_deltas else 0.0

    return {
        "tasks": tasks,
        "mean_a": round(mean_a, 4),
        "mean_b": round(mean_b, 4),
        "mean_delta": round(mean_delta, 4),
        "improved": improved,
        "regressed": regressed,
        "unchanged": unchanged,
        "missing_in_a": sorted(set(b.keys()) - set(a.keys())),
        "missing_in_b": sorted(set(a.keys()) - set(b.keys())),
    }
