"""kairos.ebmc — SystemVerilog EBMC verifier module (top-level).

ATH-566 rename (2026-04-24 Aidan directive): promoted from
``kairos.verticals.sv_cbmc`` to the top-level ``kairos.ebmc`` namespace.
Verticals are for application areas (``neuron_nki``, ``cedar``,
``bio``, ``action_cred``); EBMC is a general-purpose prover/verifier —
belongs next to ``kairos.lean`` at the top level.

ATH-829 Phase 2 (2026-04-28): adds the customer-facing
``verify`` + ``solve`` orchestration surface that mirrors
:func:`kairos.lean_orchestrate.race` + :func:`kairos.lean_orchestrate.solve`
shape. Both gated via :func:`kairos.license_scope.require_product`
(``"solve"``) per Aidan/asabi-locked Q4: hardware verification is
paid by default. See the ATH-829 Phase 2 surface section at the
bottom of this module.

Public surface::

    from kairos.ebmc import SysVerilogEBMCPlugin, TIER_NAME
    from kairos.ebmc import verify, solve  # paid-tier orchestration (ATH-829 P2)

Registered under tier_name ``bmc_bounded``. Wraps :mod:`kairos.sv.ebmc`
as a :class:`VerifierPlugin`-shaped object so the built-in pipeline can
dispatch to EBMC when the customer's intent calls for a bounded-model-
check vertical (BBRv3 starvation, CUBIC/Reno congestion-control
properties, HW-verification toy targets like arbiter/FIFO/CAM).

The plugin reads the witness dict for:

* ``sv_file`` (required) — absolute or cwd-relative path to the SV source.
* ``top_module`` (required) — module whose properties EBMC should prove.
* ``bound`` (optional, default 10) — BMC depth.
* ``timeout_sec`` (optional, default 60) — wall-clock timeout.

Verdict mapping:

* all declared properties proved → ``Verdict.outcome='proved'``,
  ``details['bound_k']`` carries the k that EBMC certified to.
* any property refuted → ``outcome='refuted'``, ``details['counterexample']``
  carries the raw EBMC counterexample block.
* EBMC timed out or returned UNKNOWN → ``outcome='unknown'``,
  ``details['timed_out']`` / ``details['exit_code']`` for triage.
* SV file missing, ebmc binary unavailable, parse error →
  ``outcome='error'``, ``reason`` has the exception message.

End-to-end example (overnight Aidan directive 2026-04-23):

    import kairos.verticals
    from kairos.spec.pipeline import SpecPipeline
    from kairos.spec.defaults import DefaultRoundRobinOrchestrator
    from kairos.spec.types import KairosConfig

    kairos.verticals.register_defaults()
    config = KairosConfig()
    pipeline = SpecPipeline(
        orchestrator=DefaultRoundRobinOrchestrator(config),
        config=config,
    )
    result = pipeline.run(
        {
            "intent_version": "1.1",
            "vertical": "ebmc",
            "target": {"file": "bbr3_patched_trace.sv",
                       "name": "starves_within", "kind": "theorem"},
            "evidence_tier": "bmc_bounded",
        },
        witness={
            "sv_file": "bbr3_patched_trace.sv",
            "top_module": "bbr3_patched_trace",
            "bound": 30,
        },
    )
    # result.verdicts_by_tier['bmc_bounded'].outcome = 'proved' / 'refuted' / ...

Cross-ref:
  * kairos.sv.ebmc / kairos.sv.prove  — the actual EBMC wrapper (ATH-387)
  * kairos.spec.types.VerifierPlugin  — Protocol contract (Gate 5 / ATH-497)
  * kairos.spec.pipeline.DEFAULT_REGISTRY — shared module registry
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from kairos.spec.types import Counterexample, Verdict


TIER_NAME = "bmc_bounded"


def _sv_auto_detect_top(sv_file_path) -> str | None:
    """Extract the first `module <name>` declaration from an SV source
    file so `kairos prove --nl` doesn't force the user to name the
    top-module when the SV has exactly one. Returns None on any
    failure (missing file, unreadable, no module in file).

    Same pattern as `kairos prove` CLI dispatcher — kept in one place
    so an RTL author who renames their top module doesn't have to
    update both.
    """
    import re
    if not sv_file_path:
        return None
    try:
        p = Path(sv_file_path)
        if not p.exists():
            return None
        m = re.search(r"^\s*module\s+(\w+)", p.read_text(), re.MULTILINE)
        return m.group(1) if m else None
    except OSError:
        return None


class SysVerilogEBMCPlugin:
    """VerifierPlugin that runs EBMC over a SystemVerilog target.

    :purity: IMPURE_SIDE_EFFECTFUL  — shells out to the ``ebmc`` binary,
             reads the SV source file, writes no persistent state.
    """

    tier_name: str = TIER_NAME
    # ATH-526: real verifier — shells out to ebmc + parses real verdicts.
    is_stub: bool = False

    def verify(
        self,
        intent: Mapping[str, Any],
        witness: Mapping[str, Any],
        *,
        timeout_sec: float | None = None,
    ) -> Verdict:
        """Dispatch EBMC against the witness-supplied SV target.

        The intent's ``evidence_tier`` must be ``bmc_bounded`` (or the
        orchestrator will route elsewhere). Witness fields drive the
        EBMC invocation; see module docstring for shape.
        """
        try:
            from kairos.sv.ebmc import run_ebmc
        except ImportError as exc:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"kairos.sv.ebmc not importable ({exc})",
                details={"exception": type(exc).__name__},
            )

        # Witness keys take priority; fall back to IntentV1 fields
        # so the NL-entry flow (kairos prove --nl) works without the
        # caller fabricating a witness dict. IntentV1 from nl_frontend
        # carries `target.file` + `target.name` — we pull from there.
        intent_target = intent.get("target", {}) if isinstance(intent, Mapping) else {}
        sv_file = witness.get("sv_file") or intent_target.get("file")
        top_module = (
            witness.get("top_module")
            or intent_target.get("name")
            or _sv_auto_detect_top(sv_file)
        )
        if not sv_file:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "neither witness['sv_file'] nor intent.target.file set — "
                    "cannot run EBMC. Pass one of them."
                ),
                details={"missing_field": "sv_file"},
            )
        if not top_module:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=(
                    "neither witness['top_module'] nor intent.target.name "
                    "set, and auto-detect from the SV source failed."
                ),
                details={"missing_field": "top_module"},
            )

        sv_path = Path(sv_file)
        if not sv_path.exists():
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"SV file not found: {sv_file!r}",
                details={"sv_file": str(sv_file)},
            )
        if sv_path.stat().st_size == 0:
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"SV file is empty: {sv_file!r}",
                details={"sv_file": str(sv_file)},
            )

        bound = int(witness.get("bound", intent.get("bound_k", 10)))
        resolved_timeout = int(
            timeout_sec if timeout_sec is not None
            else witness.get("timeout_sec", 60)
        )

        try:
            ebmc_result = run_ebmc(
                sv_path,
                top_module=str(top_module),
                bound=bound,
                timeout_sec=resolved_timeout,
            )
        except Exception as exc:  # noqa: BLE001 — guard returns fallback value on any error
            return Verdict(
                source=TIER_NAME, outcome="error",
                reason=f"run_ebmc raised {type(exc).__name__}: {exc}",
                details={"exception": type(exc).__name__},
            )

        if ebmc_result.timed_out:
            return Verdict(
                source=TIER_NAME, outcome="unknown",
                reason=(
                    f"EBMC timed out after {resolved_timeout}s at "
                    f"bound={bound}. Raise bound / timeout to retry."
                ),
                details={
                    "timed_out": True,
                    "exit_code": ebmc_result.exit_code,
                    "bound_k": bound,
                    "elapsed_sec": ebmc_result.elapsed_sec,
                },
            )

        # Property-level verdict mapping — proved vs refuted vs mixed.
        if ebmc_result.refuted > 0:
            summary = ebmc_result.refutation_summary() or (
                f"EBMC refuted {ebmc_result.refuted}/{ebmc_result.total} "
                f"propert{'y' if ebmc_result.refuted == 1 else 'ies'} at bound={bound}"
            )
            return Verdict(
                source=TIER_NAME, outcome="refuted",
                reason=(
                    f"EBMC refuted {ebmc_result.refuted}/{ebmc_result.total} "
                    f"property(ies) at bound={bound}. See "
                    f"details['counterexample'].payload['trace'] for the trace."
                ),
                details={
                    "proved": ebmc_result.proved,
                    "refuted": ebmc_result.refuted,
                    "bound_k": bound,
                    "counterexample": Counterexample(
                        kind="bmc_trace",
                        summary=summary,
                        payload={
                            "trace": ebmc_result.counterexample,
                            "property_verdicts": ebmc_result.property_verdicts,
                            "bound_k": bound,
                        },
                    ),
                    "property_verdicts": ebmc_result.property_verdicts,
                    "elapsed_sec": ebmc_result.elapsed_sec,
                },
            )
        if ebmc_result.proved > 0:
            return Verdict(
                source=TIER_NAME, outcome="proved",
                reason=(
                    f"EBMC proved {ebmc_result.proved} "
                    f"propert{'y' if ebmc_result.proved == 1 else 'ies'} "
                    f"up to bound={bound}."
                ),
                details={
                    "proved": ebmc_result.proved,
                    "refuted": 0,
                    "bound_k": bound,
                    "property_verdicts": ebmc_result.property_verdicts,
                    "elapsed_sec": ebmc_result.elapsed_sec,
                },
            )

        # Neither proved nor refuted — e.g. no properties declared,
        # ebmc exited cleanly with zero work. Customer likely forgot
        # the `assert property` — flag as error + guide them.
        return Verdict(
            source=TIER_NAME, outcome="error",
            reason=(
                "EBMC returned without proving or refuting any property. "
                "Likely cause: the SV source has no `assert property (...)` "
                "declarations. Add at least one SVA property to drive BMC."
            ),
            details={
                "proved": 0,
                "refuted": 0,
                "exit_code": ebmc_result.exit_code,
                "bound_k": bound,
                "stdout_tail": ebmc_result.stdout[-500:] if ebmc_result.stdout else "",
            },
        )


# ═══════════════════════════════════════════════════════════════════════
# ATH-829 Phase 2 — paid-tier verify + solve consolidation
# ═══════════════════════════════════════════════════════════════════════
#
# Customer-facing entry point for hardware verification that mirrors
# the kairos.lean Phase 1 (race + solve) shape. Both gated via
# kairos.license_scope.require_product("solve").
#
# Conceptual map vs kairos.lean Phase 1:
#
#   Lean side                        EBMC side
#   ──────────────────────           ──────────────────────────
#   target = (theorem, source)       target = (sv_file, top_module)
#   drafters = list[Drafter]         modes = ["bmc", "k_induction"]
#   race = fan-out drafters          cascade = try modes in order
#   solve = race + decompose         solve = cascade + decompose
#   DecomposeHint                    EbmcDecomposeHint (refinement to Lean)
#
# The "drafter" abstraction doesn't fit EBMC: it's a deterministic
# verifier, not a stochastic prover. So `solve`'s orchestration is a
# deterministic cascade across modes, falling back to a refinement-
# decomposition hint when neither closes (refinement = "this RTL
# refines a Lean abstract spec via kairos.lean_machines"; the
# customer's outer agent picks up the hint via the lean_machines
# bridge).

import time as _time
from dataclasses import dataclass, field
from typing import Literal

from kairos.errors import OrchestrationError, ProverError
from kairos.license_scope import require_product
from kairos.sv.ebmc import EbmcResult, run_ebmc as _run_ebmc
from kairos.observe import emit as _observe_emit
from kairos.sv._trace_helpers import (
    emit_function_inputs_with_sv_source,
)

_TRACE_PREVIEW_CAP = 16000


# ── EBMC-specific exceptions (ATH-829 Phase 2) ──────────────────────


class EbmcRunTimeoutError(ProverError):
    """EBMC subprocess hit its wall-clock timeout.

    Carries ``timeout_seconds`` + ``rtl_file`` + the verification
    ``mode`` so customer-Opus orchestrators can branch on "BMC timed
    out → try k-induction" vs "k-induction timed out → fallback to
    refinement decompose".
    """

    def __init__(
        self,
        timeout_seconds: float,
        *,
        rtl_file: str | None = None,
        mode: str | None = None,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.rtl_file = rtl_file
        self.mode = mode
        msg = f"ebmc {mode or ''} timed out after {timeout_seconds:.0f}s"
        if rtl_file:
            msg += f" on {rtl_file}"
        super().__init__(msg.strip())


class EbmcRunFailure(ProverError):
    """EBMC returned a non-zero exit with no proved/refuted properties.

    Typically a parser error (malformed SV) or backend failure
    (Z3/CVC died). Distinct from a refuted verdict — that's a
    successful EBMC run that found a counterexample. This is the
    EBMC-itself-failed case.
    """

    def __init__(
        self,
        exit_code: int,
        *,
        stderr_head: str = "",
        rtl_file: str | None = None,
    ) -> None:
        self.exit_code = exit_code
        self.stderr_head = stderr_head[:300]
        self.rtl_file = rtl_file
        msg = f"ebmc failed (exit={exit_code})"
        if rtl_file:
            msg += f" on {rtl_file}"
        if stderr_head:
            msg += f": {stderr_head[:120]!r}"
        super().__init__(msg)


class EbmcCascadeExhausted(OrchestrationError):
    """:func:`solve`'s cascade exhausted every mode without closure.

    Reserved for future phases; current :func:`solve` returns a
    decompose-hint result instead of raising when ``internal_planner_model
    is None``, and raises NotImplementedError when it's set (CEGAR
    is Phase 2.5 follow-up). Kept here for forward-compat so customer
    code that wants to ``except`` on cascade-exhaustion gets a
    stable class to import.
    """

    def __init__(
        self,
        modes_attempted: list[str],
        *,
        last_verdict: str | None = None,
    ) -> None:
        self.modes_attempted = list(modes_attempted)
        self.last_verdict = last_verdict
        msg = (
            f"ebmc cascade exhausted after modes {modes_attempted}; "
            f"last verdict: {last_verdict or 'unknown'}"
        )
        super().__init__(msg)


# ── Result types (mirror kairos.lean_orchestrate Phase 1 shape) ─────


@dataclass(frozen=True)
class EbmcVerifyResult:
    """Outcome of one :func:`verify` call.

    Mirrors :class:`kairos.lean_orchestrate.RaceResult` semantically
    but for the EBMC deterministic-verifier shape (single subprocess,
    no drafter race).

    Attributes:
        proved: True iff every property in scope was proved AND no
            property was refuted.
        refuted: True iff at least one property was refuted by EBMC.
        bound_k: The bound depth EBMC ran with. For
            ``mode="k_induction"`` and ``proved=True``, the result
            is unbounded.
        mode: ``"bmc"`` or ``"k_induction"``.
        property_verdicts: ``{property_label → "PROVED" | "REFUTED" |
            "UNKNOWN"}`` per-property breakdown so customers can
            attribute partial-pass results.
        counterexample: Raw EBMC counterexample trace when refuted,
            else None.
        elapsed_seconds: Wall-clock time for this EBMC invocation.
        rtl_file: SV file path verified (echoed for trace).
        top_module: Top module name (echoed for trace).
    """
    proved: bool
    refuted: bool
    bound_k: int
    mode: str
    property_verdicts: dict[str, str] = field(default_factory=dict)
    counterexample: str | None = None
    elapsed_seconds: float = 0.0
    rtl_file: str = ""
    top_module: str = ""

    @property
    def n_proved(self) -> int:
        return sum(
            1 for v in self.property_verdicts.values()
            if v.upper() == "PROVED"
        )

    @property
    def n_refuted(self) -> int:
        return sum(
            1 for v in self.property_verdicts.values()
            if v.upper() in ("REFUTED", "FAILED")
        )


@dataclass(frozen=True)
class EbmcDecomposeHint:
    """Actionable suggestion for an outer agent to decompose an EBMC
    target after :func:`solve` returns ``proved=False``.

    Mirrors :class:`kairos.lean_orchestrate.DecomposeHint` semantics
    for the HW verification shape. The most common decomposition
    direction is REFINEMENT — proving the customer's RTL refines an
    abstract Lean spec via :mod:`kairos.lean_machines`. The hint
    points the outer agent at that bridge.

    Attributes:
        sub_property: Suggested SVA property name or expression that
            isolates the unverified slice.
        why_blocked: Plain-text rationale for why the parent target
            wasn't closed and how this sub-property unblocks it.
        refinement_target: Optional Lean module path the customer can
            point :func:`kairos.lean_machines.to_sva` at to derive an
            inductive invariant. None when the suggested decomposition
            is purely SV-side (property partitioning).
        suggested_mode: Optional verification mode hint
            (``"bmc"`` / ``"k_induction"``). None means "use the
            same cascade as the parent".
    """
    sub_property: str
    why_blocked: str
    refinement_target: str | None = None
    suggested_mode: str | None = None


@dataclass(frozen=True)
class EbmcSolveResult:
    """Outcome of one :func:`solve` call — full cascade-and-decompose.

    Mirrors :class:`kairos.lean_orchestrate.SolveResult` shape so
    customers see consistent return-shape across verifiers.

    Attributes:
        proved: True iff the cascade closed all properties cleanly.
        closing_mode: Which mode produced the close
            (``"bmc"`` | ``"k_induction"``), or None when nothing
            closed.
        verify_result: The :class:`EbmcVerifyResult` from the
            closing leg (for inspectability), or the LAST attempt
            when nothing closed.
        decompose_hints: Populated when ``proved=False`` AND
            ``internal_planner_model is None``. Empty when proved
            or when an internal planner was supplied (Phase 2.5).
        path_taken: ``"bmc"`` | ``"k_induction"`` | ``"decompose"``
            | ``"failed"`` — terminal cascade leg.
        modes_attempted: Ordered list of modes tried.
        total_elapsed_seconds: Wall-clock across all cascade legs.
        total_cost_usd: Aggregate API cost (zero when no internal
            planner ran; CEGAR Phase 2.5 will populate this).
    """
    proved: bool
    closing_mode: str | None
    verify_result: EbmcVerifyResult | None
    decompose_hints: list[EbmcDecomposeHint] = field(default_factory=list)
    path_taken: str = "failed"
    modes_attempted: list[str] = field(default_factory=list)
    total_elapsed_seconds: float = 0.0
    total_cost_usd: float = 0.0


# ── Atomic verify ────────────────────────────────────────────────────


def verify(
    rtl_file,
    *,
    top_module: str,
    bound: int = 10,
    mode: Literal["bmc", "k_induction", "ic3", "bdd"] = "bmc",
    reset_expr: str | None = None,
    timeout_sec: int = 60,
    extra_args: list[str] | None = None,
    filelist: "str | Path | None" = None,
    flatten: bool = False,
) -> EbmcVerifyResult:
    """Atomic EBMC verify — single subprocess, structured result.

    Paid-tier (requires ``solve``). Wraps :func:`kairos.sv.ebmc.run_ebmc`
    in the customer-facing :class:`EbmcVerifyResult` shape.

    Args:
        rtl_file: Path(s) to the SystemVerilog source(s).
        top_module: Top module name (passed as ``--module``).
        bound: BMC depth (``--bound``).
        mode: ``"bmc"`` (default) or ``"k_induction"``. K-induction
            with PROVED is unbounded.
        reset_expr: Reset signal expression (passed as ``--reset``).
            Pass the module's reset name when verifying invariants
            that only hold from reset.
        timeout_sec: Hard wall timeout.
        extra_args: Extra CLI flags appended verbatim.
        filelist: Path to an EBMC-style filelist (``-f``).

    Returns:
        :class:`EbmcVerifyResult` with proved/refuted counts +
        per-property verdicts + counterexample (when refuted).

    Raises:
        :exc:`kairos.errors.LicenseScopeError`: When the loaded license
            doesn't grant the ``solve`` product.
        :exc:`EbmcRunTimeoutError`: When EBMC exceeds ``timeout_sec``.
        :exc:`EbmcRunFailure`: When EBMC exits non-zero with no
            proved/refuted properties (parser error / backend crash).

    Tier classification: paid (requires ``solve``).
    """
    require_product("solve")

    if isinstance(rtl_file, (str, Path)):
        _sv_path = Path(rtl_file).resolve()
    else:
        _sv_path = Path(rtl_file[0]).resolve() if rtl_file else Path(".")
    emit_function_inputs_with_sv_source(
        _sv_path,
        function_name="kairos.ebmc.verify",
        args={
            "top_module": top_module,
            "bound": bound,
            "mode": mode,
            "reset_expr": reset_expr,
            "timeout_sec": timeout_sec,
            "extra_args": list(extra_args) if extra_args else None,
            "filelist": str(filelist) if filelist else None,
        },
    )

    raw: EbmcResult = _run_ebmc(
        rtl_file,
        top_module=top_module,
        bound=bound,
        mode=mode,
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
        filelist=filelist,
        flatten=flatten,
    )

    cex = None
    try:
        cex = raw.counterexample
    except Exception:  # noqa: BLE001 — broad-catch fallback
        cex = None
    _observe_emit("ebmc_verdict", silent_if_no_session=True, payload={
        "function": "kairos.ebmc.verify",
        "top_module": top_module,
        "bound": bound,
        "mode": mode,
        "exit_code": raw.exit_code,
        "elapsed_sec": raw.elapsed_sec,
        "timed_out": raw.timed_out,
        "proved": raw.proved,
        "refuted": raw.refuted,
        "property_verdicts": dict(raw.property_verdicts or {}),
        "transcript_first_4k": (raw.stdout or "")[:_TRACE_PREVIEW_CAP],
        "stderr_first_4k": (raw.stderr or "")[:_TRACE_PREVIEW_CAP],
        "counterexample_first_4k": (cex[:_TRACE_PREVIEW_CAP] if cex else None),
    })

    if raw.timed_out:
        raise EbmcRunTimeoutError(
            timeout_seconds=float(timeout_sec),
            rtl_file=str(rtl_file),
            mode=mode,
        )
    if raw.exit_code != 0 and raw.total == 0:
        raise EbmcRunFailure(
            exit_code=raw.exit_code,
            stderr_head=raw.stderr or raw.stdout,
            rtl_file=str(rtl_file),
        )

    return EbmcVerifyResult(
        proved=(raw.proved > 0 and raw.refuted == 0),
        refuted=(raw.refuted > 0),
        bound_k=bound,
        mode=mode,
        property_verdicts=dict(raw.property_verdicts or {}),
        counterexample=raw.counterexample if raw.refuted > 0 else None,
        elapsed_seconds=raw.elapsed_sec,
        rtl_file=str(rtl_file),
        top_module=top_module,
    )


# ── Solve — paid orchestration cascade ──────────────────────────────


_DEFAULT_KINDUCTION_BOUND_MULTIPLIER = 2


def solve(
    rtl_file,
    *,
    top_module: str,
    bound: int = 10,
    reset_expr: str | None = None,
    internal_planner_model: str | None = None,
    timeout_sec: int = 300,
    extra_args: list[str] | None = None,
    filelist: "str | Path | None" = None,
    flatten: bool = False,
) -> EbmcSolveResult:
    """Paid-tier EBMC orchestration — cascade + decompose-or-bail.

    Mirrors :func:`kairos.lean_orchestrate.solve` semantically. Cascade
    order:

    1. **BMC** at the customer-supplied bound. If proved, return.
    2. **K-induction** at ``bound × 2``. If proved, return; this is
       the unbounded close.
    3. **Decompose**: when neither mode closes AND
       ``internal_planner_model is None``, return decompose hints
       pointing at refinement to a Lean abstract spec via
       :mod:`kairos.lean_machines`. The customer's outer agent picks
       up the hint and drives next-step.

    Args:
        rtl_file: Path to the SystemVerilog source.
        top_module: Top module name.
        bound: Initial BMC depth. K-induction uses 2× this.
        reset_expr: Reset signal expression.
        internal_planner_model: When set, would call this model
            internally to propose strengthening invariants for CEGAR.
            **Phase 2 stub**: kwarg accepted but the CEGAR loop is
            not yet wired (Phase 2.5 follow-up). When set AND the
            cascade fails, raises NotImplementedError so customers
            don't silently lose the decompose-or-bail signal. Call
            without this kwarg to get the current decompose-hint
            behavior.
        timeout_sec: Hard wall timeout.

    Returns:
        :class:`EbmcSolveResult` with ``proved`` + ``closing_mode`` +
        per-mode trail + decompose hints when nothing closes.

    Raises:
        :exc:`kairos.errors.LicenseScopeError`: license gate.
        :exc:`NotImplementedError`: When ``internal_planner_model`` is
            set AND the cascade fails — Phase 2.5 follow-up.

    Tier classification: paid (requires ``solve``).
    """
    require_product("solve")

    t_start = _time.time()
    modes_attempted: list[str] = []

    # 1. BMC.
    modes_attempted.append("bmc")
    try:
        bmc_result = verify(
            rtl_file,
            top_module=top_module,
            bound=bound,
            mode="bmc",
            reset_expr=reset_expr,
            timeout_sec=timeout_sec,
            extra_args=extra_args,
            filelist=filelist,
            flatten=flatten,
        )
    except EbmcRunTimeoutError:
        bmc_result = None
    if bmc_result is not None and bmc_result.proved:
        return EbmcSolveResult(
            proved=True,
            closing_mode="bmc",
            verify_result=bmc_result,
            path_taken="bmc",
            modes_attempted=modes_attempted,
            total_elapsed_seconds=_time.time() - t_start,
        )

    # 2. K-induction at bound × 2.
    modes_attempted.append("k_induction")
    try:
        k_result = verify(
            rtl_file,
            top_module=top_module,
            bound=bound * _DEFAULT_KINDUCTION_BOUND_MULTIPLIER,
            mode="k_induction",
            reset_expr=reset_expr,
            timeout_sec=timeout_sec,
            extra_args=extra_args,
            filelist=filelist,
            flatten=flatten,
        )
    except EbmcRunTimeoutError:
        k_result = None
    if k_result is not None and k_result.proved:
        return EbmcSolveResult(
            proved=True,
            closing_mode="k_induction",
            verify_result=k_result,
            path_taken="k_induction",
            modes_attempted=modes_attempted,
            total_elapsed_seconds=_time.time() - t_start,
        )

    # 3. Cascade exhausted. Decompose-or-bail.
    if internal_planner_model is None:
        last = k_result or bmc_result
        decompose_hints = _build_decompose_hints(
            top_module=top_module,
            last_verify_result=last,
        )
        return EbmcSolveResult(
            proved=False,
            closing_mode=None,
            verify_result=last,
            decompose_hints=decompose_hints,
            path_taken="decompose",
            modes_attempted=modes_attempted,
            total_elapsed_seconds=_time.time() - t_start,
        )

    # internal_planner_model set: CEGAR strengthening is Phase 2.5
    # follow-up. Refuse to silently swallow the failure — fail-loud
    # per ATH-843 design discipline (don't pretend a feature is wired
    # when it isn't).
    raise NotImplementedError(
        "kairos.ebmc.solve(internal_planner_model=...) is not wired "
        "yet — CEGAR strengthening loop ships in ATH-829 Phase 2.5. "
        "Call solve() without internal_planner_model to drive "
        "decomposition from your outer agent loop via the returned "
        "decompose_hints."
    )


def _build_decompose_hints(
    *,
    top_module: str,
    last_verify_result: EbmcVerifyResult | None,
) -> list[EbmcDecomposeHint]:
    """Produce decompose hints when the cascade exhausts.

    Phase 2 hints are minimal but actionable: one general "consider
    refinement to a Lean spec" hint + one per refuted property (the
    customer's outer agent can target each refutation individually
    with stronger preconditions or property partitioning).
    """
    hints: list[EbmcDecomposeHint] = []

    hints.append(EbmcDecomposeHint(
        sub_property=f"{top_module}.refines_lean_spec",
        why_blocked=(
            "BMC + k-induction both failed at the chosen bound. "
            "Consider proving refinement against an abstract Lean "
            "spec via kairos.lean_machines.to_sva — the inductive "
            "invariant from the Lean side often closes what direct "
            "BMC can't."
        ),
        refinement_target=None,  # customer fills in their Lean module
        suggested_mode="k_induction",
    ))

    if last_verify_result is not None:
        for prop_name, verdict in last_verify_result.property_verdicts.items():
            if verdict.upper() in ("REFUTED", "FAILED", "UNKNOWN"):
                hints.append(EbmcDecomposeHint(
                    sub_property=prop_name,
                    why_blocked=(
                        f"property {prop_name!r} returned "
                        f"{verdict.upper()} at bound k="
                        f"{last_verify_result.bound_k}. Try "
                        f"strengthening preconditions or partitioning "
                        f"into per-state assertions."
                    ),
                    refinement_target=None,
                ))

    return hints


__all__ = [
    # Pre-existing plugin surface (ATH-566).
    "SysVerilogEBMCPlugin", "TIER_NAME",
    # ATH-829 Phase 2 customer-facing surface.
    "verify", "solve",
    "EbmcVerifyResult", "EbmcSolveResult", "EbmcDecomposeHint",
    "EbmcRunTimeoutError", "EbmcRunFailure", "EbmcCascadeExhausted",
]
