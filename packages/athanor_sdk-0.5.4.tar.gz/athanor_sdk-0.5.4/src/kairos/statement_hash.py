"""kairos.statement_hash — canonical hash of a theorem statement.

ATH-859 SDK-side primitive (L14 of the 2026-04-28 anti-cheat review).

The 13-layer SDK stack catches banned constructs, sorry/admit, axiom
leaks, and vacuous-DAG cheats. L14 closes the **statement-replacement
attack**:

::

    -- benchmark target says:
    theorem hard_thm (n : Nat) : <complicated_property n> := ...

    -- attacker emits:
    theorem hard_thm (n : Nat) : True := trivial

The proof compiles, has no sorry, axiom-clean, no banned constructs —
but the model rewrote the theorem statement to ``True`` before
proving it. Layers 1-13 don't catch this because they only look at
the proof body, not the goal.

L14 closes the hole by hashing ``{target_id, theorem_statement_canonical}``
on every solve_run. Platform's ``/api/sync`` (ATH-859) compares the
emitted hash against the canonical hash from ``benchmark.jsonl`` and
rejects mismatches.

## Canonicalization rules

The canonicalization is intentionally **strict** — even alpha-renaming
the bound variables (``∀ n``  → ``∀ m``) produces a different hash. The
benchmark target is THE reference; any deviation is treated as
suspect. False positives are acceptable (the customer can re-emit
with the canonical statement) but false negatives mean a cheat slips
through, so we err strict.

What gets stripped:

* Block comments (``/- ... -/``)
* Line comments (``-- ...``)
* Leading + trailing whitespace
* Internal whitespace runs collapsed to a single space

What does NOT get touched:

* Variable names (alpha-renaming → different hash)
* Argument order (commutative-rewrite → different hash)
* Universe annotations
* Notation choices (``Nat`` vs ``ℕ`` → different hash)

## Cross-links

* ATH-845 (axiom audit) — orthogonal; that's about WHICH axioms in
  the DAG, not WHICH theorem you proved
* ATH-855 (L15 entropy classifier) — orthogonal; that's about HOW
  the proof body composes, not WHAT the goal is
* ATH-859 (platform-side gate) — consumes the hash via the
  ``statement_hash`` trace event the SDK emits + a new
  ``solve_runs.statement_hash`` column
* 2026-04-28 anti-cheat review #dev-platform ts=1777398105.887289
"""
from __future__ import annotations

import hashlib
import re
from typing import Final


# ── Canonicalization regexes ─────────────────────────────────────────


_BLOCK_COMMENT_RE: Final = re.compile(r"/-.*?-/", re.DOTALL)
_LINE_COMMENT_RE: Final = re.compile(r"--[^\n]*")
_WHITESPACE_RE: Final = re.compile(r"\s+")


def canonicalize_statement(statement: str) -> str:
    """Stable string representation of a Lean theorem statement.

    Strips comments + whitespace ONLY. Does not normalize variable
    names, argument order, universe annotations, or notation
    choices — see the module-level docstring for the full rule.

    Idempotent: ``canonicalize(canonicalize(x)) == canonicalize(x)``.
    """
    # Strip block comments first; line-comment regex would otherwise
    # misread `--` sequences nested inside a block comment.
    s = _BLOCK_COMMENT_RE.sub(" ", statement)
    s = _LINE_COMMENT_RE.sub(" ", s)
    s = _WHITESPACE_RE.sub(" ", s).strip()
    return s


def hash_statement(statement: str) -> str:
    """Return SHA-256 hex digest of ``canonicalize_statement(statement)``.

    Use ``compute_target_hash`` when the target id is known — the
    platform gate (ATH-859) hashes ``{target_id || canonical}`` not
    just the canonical statement, so a customer running a
    statement-only ``hash_statement`` and a server expecting the
    target-bound hash will mismatch. This bare helper is exposed for
    tests + for callers who genuinely just want the canonical text
    digest.
    """
    canonical = canonicalize_statement(statement)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def compute_target_hash(*, target_id: str, theorem_statement: str) -> str:
    """SHA-256 over ``target_id || "\\n" || canonical(theorem_statement)``.

    The platform gate (ATH-859) compares this hash against the
    canonical entry in ``benchmark.jsonl``. Including ``target_id`` in
    the hashed input means a customer who proves the WRONG benchmark
    target with the right canonical-statement-of-some-OTHER-target
    still gets caught — the target id is part of the contract.

    Args:
        target_id: The benchmark target identifier. Stable string;
            usually ``<env>/<task>`` or a UUID.
        theorem_statement: The Lean theorem statement (text). Will be
            canonicalized; pass either the raw source or the
            already-canonical form (idempotent).

    Returns:
        Lowercase hex SHA-256 digest, 64 chars.
    """
    canonical = canonicalize_statement(theorem_statement)
    h = hashlib.sha256()
    h.update(target_id.encode("utf-8"))
    h.update(b"\n")
    h.update(canonical.encode("utf-8"))
    return h.hexdigest()


__all__ = [
    "canonicalize_statement",
    "compute_target_hash",
    "hash_statement",
]
