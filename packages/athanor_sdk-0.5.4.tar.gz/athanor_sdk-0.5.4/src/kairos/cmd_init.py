"""ATH-682 — `kairos init` bootstrap CLI.

Scaffolds a starter project from a template under
``src/kairos/_templates/init/<variant>/``. First variant: ``--lean-pythia``,
which wires a working Lean 4 project to the vendored Pythia tactic
library + Mathlib. asabi's "killer demo": customer closes a Lean
theorem with ``by pythia`` in a single line; first-touch is under
30 seconds (modulo Mathlib oleans).

Future variants (room reserved): ``--cedar``, ``--telos`` — same
template-copy machinery, different deps.

## Usage

    kairos init --lean-pythia                  # writes to ./pythia-starter/
    kairos init --lean-pythia --dest ./demo    # writes to ./demo/
    kairos init --lean-pythia --dry-run        # lists files, writes nothing

Refuses to clobber a non-empty destination.

## Tier classification

Free. ``kairos init`` ships in the default wheel and has no license
gate (per ``docs/sdk-tier-model.md`` §11).
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path
from typing import Iterable, Optional


# Tokens substituted into copied files. Anything else copies verbatim.
_TOKEN_PYTHIA_PATH = "{{PYTHIA_PATH}}"
_TOKEN_LEAN_MACHINES_PATH = "{{LEAN_MACHINES_PATH}}"

_TEMPLATES_ROOT = Path(__file__).resolve().parent / "_templates" / "init"


def _template_root(variant: str) -> Path:
    """Path to the template directory for ``variant``. Doesn't check
    existence; the caller validates."""
    return _TEMPLATES_ROOT / variant


def _resolve_substitutions(variant: str) -> dict[str, str]:
    """Build the token → value map for ``variant``. The lean-pythia
    variant needs concrete vendor paths; future variants will plug
    their own resolvers in here."""
    if variant == "lean-pythia":
        from kairos.pythia import vendor_path as pythia_vendor_path
        from kairos.lean_machines import vendor_path as lm_vendor_path
        return {
            _TOKEN_PYTHIA_PATH: str(pythia_vendor_path()),
            _TOKEN_LEAN_MACHINES_PATH: str(lm_vendor_path()),
        }
    return {}


def _walk_template(root: Path) -> Iterable[Path]:
    """Yield every regular file under ``root``, in deterministic order."""
    if not root.is_dir():
        return
    for p in sorted(root.rglob("*")):
        if p.is_file():
            yield p


def _target_path(template_file: Path, template_root: Path, dest: Path) -> Path:
    """Map a source file under ``template_root`` to its destination
    path under ``dest``. ``.tmpl`` suffixes are stripped — the
    rendered file lands at the unsuffixed path."""
    rel = template_file.relative_to(template_root).as_posix()
    if rel.endswith(".tmpl"):
        rel = rel[: -len(".tmpl")]
    return dest / rel


def _is_dest_empty(dest: Path) -> bool:
    """True iff ``dest`` does not exist OR exists and is an empty dir.
    A dest that's a file is treated as non-empty (caller refuses)."""
    if not dest.exists():
        return True
    if not dest.is_dir():
        return False
    return next(dest.iterdir(), None) is None


def _render_file(
    src: Path, dst: Path, substitutions: dict[str, str],
) -> None:
    """Copy ``src`` to ``dst``, substituting any token in
    ``substitutions``. Binary files (no token in source) copy verbatim
    via ``shutil.copyfile`` so we don't accidentally re-encode them."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        text = src.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Binary file — copy as-is.
        shutil.copyfile(src, dst)
        return
    for token, value in substitutions.items():
        text = text.replace(token, value)
    dst.write_text(text, encoding="utf-8")


def cmd_init(args: argparse.Namespace) -> int:
    """``kairos init`` entry. Returns shell exit code."""
    variant = _selected_variant(args)
    if variant is None:
        print(
            "error: no variant selected. Pass --lean-pythia.",
            file=sys.stderr,
        )
        return 2
    template_root = _template_root(variant)
    if not template_root.is_dir():
        print(
            f"error: template not found for variant {variant!r} "
            f"(expected at {template_root})",
            file=sys.stderr,
        )
        return 2

    dest = Path(args.dest) if args.dest else _default_dest(variant)

    if not _is_dest_empty(dest):
        print(
            f"error: destination {dest} is not empty. Pass --dest "
            f"to a fresh path.",
            file=sys.stderr,
        )
        return 2

    files = list(_walk_template(template_root))
    if not files:
        print(
            f"error: template {variant!r} is empty at {template_root}",
            file=sys.stderr,
        )
        return 2

    substitutions = _resolve_substitutions(variant)

    if args.dry_run:
        print(f"would write {len(files)} file(s) to {dest}:")
        for src in files:
            target = _target_path(src, template_root, dest)
            print(f"  {target}")
        return 0

    dest.mkdir(parents=True, exist_ok=True)
    written = 0
    for src in files:
        target = _target_path(src, template_root, dest)
        _render_file(src, target, substitutions)
        written += 1

    print(f"wrote {written} file(s) to {dest}")
    print(f"\nnext: cd {dest} && lake build && lake env lean Examples/Smoke.lean")
    return 0


def _selected_variant(args: argparse.Namespace) -> Optional[str]:
    """Pick the variant flag from ``args``. Today: only ``--lean-pythia``.
    Returns the template directory name (kebab-case)."""
    if getattr(args, "lean_pythia", False):
        return "lean-pythia"
    return None


def _default_dest(variant: str) -> Path:
    """Default destination when ``--dest`` omitted: ``./<variant>-starter``
    for ``lean-pythia``, ``./<variant>-starter`` likewise for any
    future variant."""
    return Path(f"./{variant}-starter")


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Register ``init`` on a top-level subparsers action."""
    p = sub.add_parser(
        "init",
        help="Scaffold a starter project (free tier).",
    )
    p.add_argument(
        "--lean-pythia", action="store_true", dest="lean_pythia",
        help="Bootstrap a Lean 4 project wired to the vendored Pythia "
             "library + Mathlib + lean-machines.",
    )
    p.add_argument(
        "--dest", metavar="PATH", default=None,
        help="Destination directory. Default: ./<variant>-starter "
             "(e.g. ./lean-pythia-starter). Refuses to clobber a "
             "non-empty path.",
    )
    p.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help="List the files that would be written; don't write.",
    )


__all__ = [
    "add_subparser",
    "cmd_init",
]
