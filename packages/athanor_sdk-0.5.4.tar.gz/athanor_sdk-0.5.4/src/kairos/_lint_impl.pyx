"""Client-side Lean anti-cheat linter.

Fail-fast for developers: check their Lean submission for banned
constructs before submitting. The real enforcement runs in the
scoring container — this just catches obvious mistakes early.
"""
from __future__ import annotations

import re
from pathlib import Path


# Public list of banned constructs. The comprehensive list with
# detailed justifications lives in the scoring containers.
BANNED_LEAN_CONSTRUCTS = [
    (r'@\[init\b', "@[init] runs arbitrary IO during Lean compilation"),
    (r'\bIO\s*\.\s*FS\b', "IO.FS allows filesystem access"),
    (r'\bIO\s*\.\s*Process\b', "IO.Process allows spawning processes"),
    (r'^\s*import\s+Lean\b', "import Lean gives metaprogramming access"),
    (r'^\s*import\s+Mathlib\b', "import Mathlib is not available in the container"),
    (r'\baxiom\b', "axiom bypasses proof obligation"),
    (r'\bconstant\b', "constant bypasses proof obligation"),
    (r'\bopaque\b', "opaque declaration bypasses proof obligation"),
    (r'\bunsafe\b', "unsafe bypasses type safety"),
    (r'^#exit\b', "#exit stops type-checking"),
    (r'@\[implementedBy\b', "@[implementedBy] bypasses termination checking"),
]


def _strip_comments(source: str) -> str:
    """Remove Lean comments so we don't flag constructs that appear in them."""
    # Block comments /- ... -/
    source = re.sub(r'/-.*?-/', '', source, flags=re.DOTALL)
    # Line comments --
    source = re.sub(r'--.*$', '', source, flags=re.MULTILINE)
    return source


def lint_lean(source: str) -> dict:
    """Lint a Lean source string for banned constructs.

    Returns a list of violations:
        [{"pattern": str, "message": str, "line": int, "text": str}, ...]
    """
    stripped = _strip_comments(source)
    lines = stripped.split("\n")
    violations = []

    for pattern, message in BANNED_LEAN_CONSTRUCTS:
        for line_num, line in enumerate(lines, start=1):
            flags = re.MULTILINE if pattern.startswith("^") else 0
            match = re.search(pattern, line, flags=flags)
            if match:
                violations.append({
                    "pattern": pattern,
                    "message": message,
                    "line": line_num,
                    "text": line.strip()[:100],
                })
                break  # Only report first match per pattern

    # Check for sorry (warning, not error — sorries are allowed but scored low)
    sorry_count = len(re.findall(r'\bsorry\b', stripped))

    return {
        "violations": violations,
        "sorry_count": sorry_count,
        "clean": len(violations) == 0,
    }


def lint_file(path: str | Path) -> dict:
    """Lint a Lean file on disk."""
    p = Path(path)
    if not p.exists():
        return {"error": f"File not found: {path}", "clean": False, "violations": [], "sorry_count": 0}
    source = p.read_text()
    result = lint_lean(source)
    result["file"] = str(p)
    return result
