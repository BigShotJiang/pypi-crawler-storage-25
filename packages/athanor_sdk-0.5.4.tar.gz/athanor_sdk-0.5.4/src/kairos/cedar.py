"""kairos.cedar — Cedar policy verification vertical (ATH-684 v1.9).

Customer entrypoint for the Cedar vertical. Requires the
``[cedar]`` install extra (``pip install athanor-sdk[cedar]``).

## v1 status (2026-04-27)

This module is a **registration stub**: it defines the public API
shape + raises a structured :class:`CedarNotInstalledError` from
every entry point so customers who try ``from kairos import cedar``
without the extra get a clear install-hint instead of a confusing
ImportError on a downstream symbol.

The real Cedar vertical (vendored Lean source + diff harness)
lands in a follow-up under ATH-684 once the upstream
``athanor-ai/kairos-cedar`` snapshot is pruned to the ≤2 MB target
and license-attributed.

## Customer install

    pip install athanor-sdk[cedar]      # ← future: pulls vendor
    pip install athanor-sdk             # default, Cedar absent

## Tier classification

Free at the ``kairos.cedar`` wrapper level. The underlying paid
solver path (``kairos.verticals.cedar`` VerifierPlugin) gates on
``require_product("solve")`` per the §11 audit — that path is
unaffected by this wrapper.
"""
from __future__ import annotations

from pathlib import Path


_VENDOR_DIR = Path(__file__).resolve().parent / "_vendor" / "cedar"


class CedarNotInstalledError(ImportError):
    """Raised when the customer has not installed the ``[cedar]``
    extra. Subclasses :class:`ImportError` so existing
    ``except ImportError:`` handlers in customer agent code catch it
    naturally."""
    def __init__(self) -> None:
        super().__init__(
            "kairos.cedar requires the [cedar] install extra. Run:\n"
            "    pip install athanor-sdk[cedar]\n"
            "(ATH-684 — the cedar vertical is registered as an "
            "optional extra so customers who don't need policy "
            "verification skip the heavier vendor payload.)"
        )


def _require_cedar_vendor() -> Path:
    """Return the path to the vendored Cedar Lean source. Raises
    :class:`CedarNotInstalledError` when the vendor isn't present
    (i.e. customer didn't install the ``[cedar]`` extra OR is on the
    pre-v1.9 SDK that ships the registration stub but not the source)."""
    if not _VENDOR_DIR.is_dir():
        raise CedarNotInstalledError()
    # Once vendor source lands, _VENDOR_DIR will contain a
    # `lakefile.lean` + `Cedar/` tree. Sanity-check both so a
    # half-extracted vendor (e.g. mid-pip-install crash) raises
    # cleanly instead of failing at lake-build time.
    if not (_VENDOR_DIR / "lakefile.lean").is_file():
        raise CedarNotInstalledError()
    return _VENDOR_DIR


def vendor_path() -> Path:
    """Path to the vendored Cedar Lean source. Same shape as
    :func:`kairos.pythia.vendor_path` so customer lakefiles can
    write ``require cedar from path "..."`` symmetrically.

    Raises :class:`CedarNotInstalledError` when the ``[cedar]``
    extra is not installed.
    """
    return _require_cedar_vendor()


def is_available() -> bool:
    """Cheap check whether the Cedar vertical is usable in this
    install. Returns ``False`` instead of raising — useful in
    customer code that wants to feature-flag a cedar code path."""
    try:
        _require_cedar_vendor()
        return True
    except CedarNotInstalledError:
        return False


__all__ = [
    "CedarNotInstalledError",
    "vendor_path",
    "is_available",
]
