"""kairos.solve — Tier 2 Python API over the solve/core chassis (ATH-437).

Programmatic wrapper around the same `athanor solve --vertical` dispatch
the Tier-1 CLI uses. Ships for customers who want to drive the chassis
from their own orchestration code without writing subprocess calls.

Shape (per the ATH-418 RFC §Tier 2, solve/docs/ath-418-sdk-expose-rfc.md
on athanor-builder main):

    from kairos.solve import run_vertical, list_verticals, Result

    result = run_vertical(
        vertical="sysverilog-fleet",
        target="toy_counter",
        extra={"sv_file": "...", "top_module": "toy_counter", "bound": 10},
    )
    if result.proved:
        print(result.cost_usd, result.iterations)

Implementation contract:

- Subprocess-shells into `$ATHANOR_BUILDER_ROOT/solve/core/run.sh`
  with verbatim flag passthrough — identical codepath to Tier 1, so
  both paths honor the same chassis semantics (workdir semantics,
  exit codes, manifest.json shape).
- Parses `<workdir>/manifest.json` per v0.2 schema. If workdir isn't
  set explicitly, the chassis picks a default; `Result.artifacts_dir`
  surfaces whatever the chassis wrote.
- `Result` is a derived view over `manifest.phases` + canonical keys
  from the RFC §"Canonical details keys" section.
- Evidence-of-work guard (RFC Q2 defense-in-depth): if
  `overall_passed=True` but no phase emits a non-zero `proved_count`,
  `verdict` is downgraded to `"unknown"` with `antecedent_failed=True`.

License / builder gates mirror cmd_solve_vertical in cli.py — same
exit-2 error shape, just raised as Python exceptions instead of
sys.exit().
"""
from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence


# ─── Public result types ─────────────────────────────────────────────


@dataclass
class PhaseEvent:
    """One phase from the chassis manifest.json — 1:1 mapping.

    Fields mirror the chassis `phases[i]` shape exactly. The `details`
    dict is free-form per RFC §Canonical details keys; customers should
    read via `.get(key, default)` rather than `[key]` since not every
    phase emits every canonical key.
    """
    name: str
    outcome: str           # "proved" | "refuted" | "error" | "vacuous" | "timeout"
    source: str
    reason: str
    elapsed_sec: float
    skipped: bool
    details: dict[str, Any]


@dataclass
class Evidence:
    """Rolled-up evidence-of-work view over phases[*].details.

    Read-only; constructed by `Result` from the raw manifest. Customers
    gating on `proved_count > 0` get the strongest signal that the
    chassis actually did work (vs vacuous/early-exit proves).
    """
    proved_count: int = 0
    property_verdicts: dict[str, str] = field(default_factory=dict)
    mutation_kill_rate: float | None = None
    axiom_audit_clean: bool | None = None


@dataclass
class Result:
    """Derived view over `manifest.json`. Stable customer contract.

    Breaking changes to these fields require an SDK major version bump.
    The raw `manifest` dict is exposed for customers who need fields
    that haven't been promoted to the canonical view yet.
    """
    verdict: str            # "proved" | "refuted" | "unknown" | "error" | "stopped"
    proved: bool
    artifacts_dir: Path
    exit_reason: str        # "completed" | "exception" | "stop_on_error"
    exit_code: int
    elapsed_sec: float
    cost_usd: float
    iterations: int
    phase_events: list[PhaseEvent]
    evidence: Evidence
    exception: dict[str, str] | None
    antecedent_failed: bool = False
    manifest: dict[str, Any] = field(default_factory=dict)


class SolveError(Exception):
    """Raised when the SDK cannot even dispatch to the chassis.

    Covers: missing license, missing $ATHANOR_BUILDER_ROOT, missing
    run.sh, subprocess-launch OSError. A chassis crash at runtime
    does NOT raise this — it populates Result.exit_code +
    Result.exit_reason instead, matching Tier 1 CLI semantics.
    """


# ─── Internal helpers ────────────────────────────────────────────────


_CANONICAL_INT_KEYS = ("iterations", "proved_count", "mutants_killed")
_CANONICAL_FLOAT_KEYS = ("cost_usd", "mutation_kill_rate", "kill_rate")


def _sum_phase_int(phases: list[dict[str, Any]], key: str) -> int:
    total = 0
    for p in phases:
        v = p.get("details", {}).get(key)
        if isinstance(v, int):
            total += v
        elif isinstance(v, float):
            total += int(v)
    return total


def _sum_phase_float(phases: list[dict[str, Any]], key: str) -> float:
    total = 0.0
    for p in phases:
        v = p.get("details", {}).get(key)
        if isinstance(v, (int, float)):
            total += float(v)
    return total


def _merge_phase_dict(phases: list[dict[str, Any]], key: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for p in phases:
        v = p.get("details", {}).get(key)
        if isinstance(v, dict):
            out.update({str(k): str(val) for k, val in v.items()})
    return out


def _first_phase_value(phases: list[dict[str, Any]], key: str) -> Any:
    for p in phases:
        v = p.get("details", {}).get(key)
        if v is not None:
            return v
    return None


def _derive_verdict(manifest: dict[str, Any]) -> tuple[str, bool]:
    """Map manifest → (verdict, antecedent_failed).

    Rules (per RFC §Evidence-of-work contract):
    - If any phase has outcome="refuted" → verdict="refuted"
    - elif overall_passed=True AND proved_count>0 → verdict="proved"
    - elif overall_passed=True AND proved_count==0 → verdict="unknown"
      (antecedent_failed=True) — chassis claimed success with no
      evidence; surface as unknown so customer CI doesn't false-pass
    - elif exit_reason="exception" → verdict="error"
    - elif exit_reason="stop_on_error" → verdict="stopped"
    - else → verdict="unknown"
    """
    phases = manifest.get("phases", [])
    overall = bool(manifest.get("overall_passed", False))
    exit_reason = manifest.get("exit_reason", "completed")

    for p in phases:
        if p.get("outcome") == "refuted" and not p.get("skipped"):
            return ("refuted", False)

    if overall:
        proved_count = _sum_phase_int(phases, "proved_count")
        if proved_count > 0:
            return ("proved", False)
        return ("unknown", True)

    if exit_reason == "exception":
        return ("error", False)
    if exit_reason == "stop_on_error":
        return ("stopped", False)
    return ("unknown", False)


def _build_result(
    manifest: dict[str, Any],
    exit_code: int,
    workdir: Path,
) -> Result:
    phases = manifest.get("phases", [])
    verdict, antecedent_failed = _derive_verdict(manifest)
    return Result(
        verdict=verdict,
        proved=(verdict == "proved"),
        artifacts_dir=workdir,
        exit_reason=manifest.get("exit_reason", "completed"),
        exit_code=exit_code,
        elapsed_sec=float(manifest.get("elapsed_sec", 0.0)),
        cost_usd=_sum_phase_float(phases, "cost_usd"),
        iterations=_sum_phase_int(phases, "iterations"),
        phase_events=[
            PhaseEvent(
                name=p.get("name", ""),
                outcome=p.get("outcome", ""),
                source=p.get("source", ""),
                reason=p.get("reason", ""),
                elapsed_sec=float(p.get("elapsed_sec", 0.0)),
                skipped=bool(p.get("skipped", False)),
                details=dict(p.get("details", {})),
            )
            for p in phases
        ],
        evidence=Evidence(
            proved_count=_sum_phase_int(phases, "proved_count"),
            property_verdicts=_merge_phase_dict(phases, "property_verdicts"),
            mutation_kill_rate=_first_phase_value(phases, "mutation_kill_rate"),
            axiom_audit_clean=_first_phase_value(phases, "axiom_audit_clean"),
        ),
        exception=manifest.get("exception"),
        antecedent_failed=antecedent_failed,
        manifest=manifest,
    )


def _resolve_builder_root() -> Path:
    from kairos.builder_check import _has_builder, builder_required_error
    from kairos.envvars import getenv_dual
    from kairos.license_scope import require_product, LicenseScopeError

    try:
        require_product("solve")
    except LicenseScopeError as exc:
        raise SolveError(f"license: {exc}") from exc

    if not _has_builder():
        raise SolveError(f"builder: {builder_required_error()}")

    root = Path(getenv_dual("BUILDER_ROOT", "/opt/athanor/builder"))
    run_sh = root / "solve" / "core" / "run.sh"
    if not run_sh.is_file():
        raise SolveError(
            f"solve/core/run.sh not found at {run_sh}. "
            f"Set $KAIROS_BUILDER_ROOT (or legacy $ATHANOR_BUILDER_ROOT) "
            f"to your athanor-builder install root, or upgrade to a "
            f"builder that ships solve/core/."
        )
    return root


def _build_cmd(
    *,
    run_sh: Path,
    vertical: str,
    target: str | None,
    workdir: Path,
    verifier: Sequence[str] | None,
    dry_run: bool,
    max_cost_usd: float | None,
    max_iter: int | None,
    skip_phases: Sequence[str] | None,
    only_phases: Sequence[str] | None,
    resume: bool,
    force: bool,
    list_verticals: bool,
    extra: dict[str, Any] | None,
) -> list[str]:
    cmd: list[str] = [str(run_sh), "--vertical", vertical]
    if target:
        cmd += ["--target", target]
    cmd += ["--workdir", str(workdir)]
    if resume:
        cmd += ["--resume"]
    if force:
        cmd += ["--force"]
    if verifier:
        cmd += ["--verifier", ",".join(verifier)]
    if dry_run:
        cmd += ["--dry-run"]
    if max_cost_usd is not None:
        cmd += ["--max-cost", str(max_cost_usd)]
    if max_iter is not None:
        cmd += ["--max-iter", str(max_iter)]
    if skip_phases:
        cmd += ["--skip-phases", ",".join(skip_phases)]
    if only_phases:
        cmd += ["--only-phases", ",".join(only_phases)]
    if list_verticals:
        cmd += ["--list-verticals"]
    if extra:
        for k, v in extra.items():
            cmd += ["--extra", f"{k}={v}"]
    return cmd


# ─── Public API ──────────────────────────────────────────────────────


def run_vertical(
    vertical: str,
    target: str | None = None,
    *,
    workdir: str | Path | None = None,
    verifier: Sequence[str] | None = None,
    dry_run: bool = False,
    max_cost_usd: float | None = None,
    max_iter: int | None = None,
    skip_phases: Sequence[str] | None = None,
    only_phases: Sequence[str] | None = None,
    resume: bool = False,
    force: bool = False,
    extra: dict[str, Any] | None = None,
) -> Result:
    """Run a registered chassis vertical end-to-end.

    Args:
        vertical: registered vertical name. Call `list_verticals()` to
            enumerate current options. Today: sysverilog-fleet,
            neuron-fleet, cross-accel-fleet, action-cred-fleet,
            bio-fleet, two-agent-fleet, toy.
        target: task slug / theorem label. Passed through as
            `--target` to run.sh. Optional for `--list-verticals`.
        workdir: pipeline workdir. If None, creates a temp dir under
            `/tmp/athanor-solve-<pid>-<N>/`. Customer reads the
            `Result.artifacts_dir` afterwards to collect artifacts.
        verifier: tuple of backend names to attach ('ebmc', 'lean',
            'hypothesis'). If None, the vertical's default set is used.
        dry_run: chassis dry-run mode — skips real verifier / LLM calls.
        max_cost_usd: LLM cost cap in USD.
        max_iter: max refinement iterations (e.g. CEGAR iteration budget).
        skip_phases: phase names to skip via `_DONE` marker preseeding.
            Mutually exclusive with `only_phases`.
        only_phases: phase names to run; all others pre-seeded skipped.
            Mutually exclusive with `skip_phases`.
        resume: explicit resume (equivalent to auto-detect when workdir
            has existing `_DONE` markers).
        force: wipe workdir before run.
        extra: dict of `KEY=VALUE` pairs passed into chassis `ctx.extra`.
            Each vertical documents its required keys (sysverilog-fleet
            needs `sv_file` / `top_module` / `bound`, etc.).

    Returns:
        Result — derived view over `manifest.json`. See `Result` for fields.

    Raises:
        SolveError: on license/builder/run.sh-missing — dispatch did not
            reach the chassis. Chassis runtime failures populate
            `Result.exit_code` + `Result.exit_reason` without raising.
        TypeError: on mutually-exclusive flag misuse (skip_phases +
            only_phases together, resume + force together).
    """
    if skip_phases and only_phases:
        raise TypeError("skip_phases and only_phases are mutually exclusive")
    if resume and force:
        raise TypeError("resume and force are mutually exclusive")

    root = _resolve_builder_root()
    run_sh = root / "solve" / "core" / "run.sh"

    if workdir is None:
        import tempfile
        workdir_path = Path(tempfile.mkdtemp(prefix="athanor-solve-"))
    else:
        workdir_path = Path(workdir)

    cmd = _build_cmd(
        run_sh=run_sh,
        vertical=vertical,
        target=target,
        workdir=workdir_path,
        verifier=verifier,
        dry_run=dry_run,
        max_cost_usd=max_cost_usd,
        max_iter=max_iter,
        skip_phases=skip_phases,
        only_phases=only_phases,
        resume=resume,
        force=force,
        list_verticals=False,
        extra=extra,
    )

    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    try:
        proc = subprocess.run(cmd, cwd=str(root))
    except OSError as exc:
        raise SolveError(
            f"could not launch {run_sh}: {exc}"
        ) from exc

    manifest_path = workdir_path / "manifest.json"
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            manifest = {
                "overall_passed": False,
                "exit_reason": "exception",
                "exception": {
                    "type": type(exc).__name__,
                    "message": f"manifest.json unreadable: {exc}",
                },
                "phases": [],
                "elapsed_sec": 0.0,
            }
    else:
        manifest = {
            "overall_passed": False,
            "exit_reason": "exception",
            "exception": {
                "type": "MissingManifest",
                "message": f"manifest.json not written at {manifest_path}",
            },
            "phases": [],
            "elapsed_sec": 0.0,
        }

    return _build_result(manifest, proc.returncode, workdir_path)


def list_verticals() -> list[str]:
    """Return the chassis registered-vertical names.

    Calls `solve/core/run.sh --list-verticals`. Raises SolveError on
    license / builder / run.sh gate failures.

    Note: chassis argparse (`solve/core/dispatch.py`) requires
    `--vertical` + `--target` even with `--list-verticals`, so we
    pass harmless placeholders. The `--list-verticals` branch
    short-circuits before vertical lookup.
    """
    root = _resolve_builder_root()
    run_sh = root / "solve" / "core" / "run.sh"
    try:
        proc = subprocess.run(
            [str(run_sh),
             "--vertical", "_list_placeholder",
             "--target", "_list_placeholder",
             "--list-verticals"],
            cwd=str(root),
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise SolveError(f"could not launch {run_sh}: {exc}") from exc
    if proc.returncode != 0:
        raise SolveError(
            f"run.sh --list-verticals exited {proc.returncode}: "
            f"{proc.stderr.strip()}"
        )
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


__all__ = [
    "run_vertical",
    "list_verticals",
    "Result",
    "PhaseEvent",
    "Evidence",
    "SolveError",
]
