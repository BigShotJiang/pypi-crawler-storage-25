"""kairos.sparsity — pruned-model invariant verifier (Bet F scaffold).

ATH-959 (W2-W4 scaffold for ATH-950 v4 Bet F). Compose on existing
Pythia primitives — ``Pythia.MatchingConstants`` (sub-Gaussian moment
bounds for L1/L2 ε-bounds) + ``Pythia.MatrixBernstein`` (concentration
of pruned weight matrices) + ``Pythia.MatrixLieb`` (spectral bounds)
+ :func:`kairos.lean.verify_proof`.

Customer claim (Annapurna pitch):

    *"Your 70%-sparse model has provably bounded L1/L2 norm
    preservation + weight concentration. Once Pythia.PACBayes lands,
    the accuracy-loss bound ε ≤ 0.5% becomes auditable."*

Compounds with :mod:`kairos.silicon_review` (ATH-951) +
:mod:`kairos.model_invariants` (ATH-958) + platform's
``kairos.quantization`` for the W4-W6 Annapurna pitch — proven silicon,
bounded quantization, invariant attention, bounded sparsity loss.

Architecture
------------
Same orchestrator shape as :mod:`kairos.silicon_review` (ATH-951) and
:mod:`kairos.model_invariants` (ATH-958). No new verifier logic; thin
compose-existing-primitives only.

The 4-layer vacuous-proves defense (per ``feedback_no_vacuous_proves_multi_layer.md``):

1. **Per-invariant verdict mapping** (banned > axiom_clean=False >
   sorry > compile_error > full_proof). ATH-948 lineage.
2. **Composite precedence** (error > refuted > unknown > proved;
   empty list → error not silent-proved). ATH-951/958 shape.
3. **Theorem template structural integrity** — generated theorem
   references customer-spec-defined identifiers
   (``{invariant_name}_property`` + ``{invariant_name}_proof``).
   Empty/missing/wrong-shaped spec → compile error → refuted.
4. **Source-text contract test** — behavioral pin against tautology
   regression at the test layer.

Trace emit
----------
``sparsity_verify_complete`` event registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Walker-visible emit. Composes with platform's Verification Coverage
card (zero net-new infra).

Cross-ref
---------
* :mod:`kairos.silicon_review` — orchestrator template (Bet E).
* :mod:`kairos.model_invariants` — sibling pattern (Bet H).
* :func:`kairos.lean.verify_proof` — per-invariant proof checker.
* Pythia primitives:
    * ``Pythia.MatchingConstants`` — sub-Gaussian moment bounds.
    * ``Pythia.MatrixBernstein`` — Tropp 2012 matrix concentration.
    * ``Pythia.MatrixLieb`` — spectral bounds.
    * (deepens with) ``Pythia.PACBayes`` — accuracy-loss bound when
      asabi's ATH-937 work-stream lands.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence


KNOWN_PRUNING_SCHEMES = (
    "magnitude",          # weights with smallest |w| pruned
    "structured",         # whole rows / columns / channels pruned
    "unstructured",       # individual weights at random
    "lottery_ticket",     # iterative magnitude with rewinding
    "movement",           # gradient-based pruning
)


KNOWN_INVARIANT_KINDS = (
    "l1_norm_preservation",       # ‖W_pruned‖₁ within ε of ‖W‖₁ on retained mass
    "l2_norm_preservation",       # ‖W_pruned‖₂ within ε of ‖W‖₂
    "weight_concentration",       # surviving weights concentrate via Matrix Bernstein
    "sparsity_target_achieved",   # actual sparsity ≥ target_sparsity
    "spectral_preservation",      # singular values within ε of dense baseline
    # Q3 W6+ (gated on Pythia.PACBayes):
    "accuracy_loss_bounded",      # acc(pruned) ≥ acc(dense) - ε via PAC-Bayes
)


@dataclass
class InvariantOutcome:
    """Per-invariant verdict + proof artifact."""

    invariant_name: str
    verdict: str
    """One of ``"proved" / "refuted" / "unknown" / "error"``."""

    proof_artifact_path: Path | None = None
    elapsed_sec: float = 0.0
    error_message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class SparsityResult:
    """Composite outcome from one sparsity-invariant verification pass."""

    pruning_scheme: str
    target_sparsity: float
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    all_invariants_proven: bool
    """True iff every enumerated invariant returned ``proved``."""

    invariant_outcomes: list[InvariantOutcome] = field(default_factory=list)
    loss_bound_eps: float | None = None
    """Populated when Pythia.PACBayes branch lands + accuracy_loss_bounded
    invariant proven. ``None`` for v0."""

    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def proved_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict == "proved"]

    @property
    def failed_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict != "proved"]


def _classify_composite(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[str, bool]:
    """Map per-invariant verdicts → (composite_verdict, all_proven).

    Layer-2 of the 4-layer vacuous-proves defense (per
    ``feedback_no_vacuous_proves_multi_layer.md``):

    - Precedence: error > refuted > unknown > proved.
    - Empty outcome list safe-defaults to error, NOT silent-proved.
      Same defense as ATH-951/958 _classify_composite.
    """
    if not outcomes:
        return "error", False
    verdicts = [o.verdict for o in outcomes]
    if any(v == "error" for v in verdicts):
        return "error", False
    if any(v == "refuted" for v in verdicts):
        return "refuted", False
    if any(v == "unknown" for v in verdicts):
        return "unknown", False
    if all(v == "proved" for v in verdicts):
        return "proved", True
    return "error", False


def _build_invariant_theorem(
    invariant_name: str,
    pruning_scheme: str,
    target_sparsity: float,
    spec_source: str,
) -> str:
    """Construct a Lean theorem statement for the named sparsity invariant.

    **Honest scaffold contract** (layer-3 of the 4-layer defense, per
    ``feedback_no_vacuous_proves_multi_layer.md`` + ATH-958 review fix):

    The generated theorem references identifiers the customer spec is
    required to define. Empty / missing / wrong-shaped spec → compile
    error → refuted (honest).

    Customer spec must define:

    * ``{invariant_name}_property : Prop`` — the property statement.
    * ``{invariant_name}_proof : {invariant_name}_property`` — the proof.

    NOT a ``: True := trivial`` tautology. Not ``:= rfl``. Not  # noqa: vacuous-proof-ok
    ``:= sorry``. The customer's spec carries the verification
    obligation.
    """
    safe_inv = invariant_name.replace("-", "_").replace(" ", "_")
    safe_scheme = pruning_scheme.replace("-", "_").replace(" ", "_")
    return (
        f"{spec_source}\n\n"
        f"-- ATH-959 sparsity invariant: {invariant_name} for "
        f"{pruning_scheme} pruning at {target_sparsity:.2f} target.\n"
        f"-- Honest scaffold contract: the spec is required to define\n"
        f"--   {safe_inv}_property : Prop\n"
        f"--   {safe_inv}_proof : {safe_inv}_property\n"
        f"-- Empty / missing / wrong-shaped spec → compile error → refuted.\n"
        f"theorem {safe_inv}_verified_for_{safe_scheme}_pruning : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def verify(
    pruning_scheme: str,
    target_sparsity: float,
    *,
    invariants: Sequence[str],
    model_lean_spec: str | Path | None = None,
    workdir: str | Path,
    lake_project: str | Path | None = None,
    timeout_sec_per_invariant: int = 300,
    emit_trace: bool = True,
) -> SparsityResult:
    """Verify sparsity invariants against ``model_lean_spec``.

    Args:
        pruning_scheme: pruning scheme name (e.g. ``"magnitude"``).
            Use values from :data:`KNOWN_PRUNING_SCHEMES` for the most
            prompt-friendly tactic library; arbitrary strings work.
        target_sparsity: target sparsity fraction (0.0-1.0). Stamped
            into trace + result.
        invariants: list of invariant names to prove. Use values from
            :data:`KNOWN_INVARIANT_KINDS` for max reuse; arbitrary
            strings dispatched uniformly via verify_proof.
        model_lean_spec: path to Lean source describing the pruned
            architecture + customer's invariant property/proof
            definitions. When None, invariants run against an empty
            spec — useful for testing the orchestrator's verdict
            aggregation but not the customer flow.
        workdir: scratch directory.
        lake_project: optional Lake project to verify against.
        timeout_sec_per_invariant: per-invariant Lean wall-clock.
        emit_trace: when True (default), emit
            ``sparsity_verify_complete`` on completion.

    Returns:
        :class:`SparsityResult`. Never raises for missing toolchain
        or per-invariant failure — those surface as
        ``composite_verdict='error'`` / per-invariant verdict.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not invariants:
        result = SparsityResult(
            pruning_scheme=pruning_scheme,
            target_sparsity=target_sparsity,
            composite_verdict="error",
            all_invariants_proven=False,
            invariant_outcomes=[],
            error_message="no invariants enumerated — verify() requires ≥1",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    if not (0.0 <= target_sparsity <= 1.0):
        result = SparsityResult(
            pruning_scheme=pruning_scheme,
            target_sparsity=target_sparsity,
            composite_verdict="error",
            all_invariants_proven=False,
            error_message=(
                f"target_sparsity must be in [0.0, 1.0]; got {target_sparsity}"
            ),
        )
        if emit_trace:
            _emit_complete(result)
        return result

    spec_source = ""
    if model_lean_spec is not None:
        spec_path = Path(model_lean_spec).resolve()
        if not spec_path.exists():
            return SparsityResult(
                pruning_scheme=pruning_scheme,
                target_sparsity=target_sparsity,
                composite_verdict="error",
                all_invariants_proven=False,
                error_message=f"model_lean_spec does not exist: {spec_path}",
            )
        spec_source = spec_path.read_text()

    t0 = time.monotonic()
    outcomes: list[InvariantOutcome] = []

    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001 — kairos.lean import surface
        result = SparsityResult(
            pruning_scheme=pruning_scheme,
            target_sparsity=target_sparsity,
            composite_verdict="error",
            all_invariants_proven=False,
            error_message=f"kairos.lean unavailable: {e}",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    for inv_name in invariants:
        inv_t0 = time.monotonic()
        theorem_source = _build_invariant_theorem(
            invariant_name=inv_name,
            pruning_scheme=pruning_scheme,
            target_sparsity=target_sparsity,
            spec_source=spec_source,
        )
        try:
            proof_result = verify_proof(
                theorem_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_invariant,
            )
        except Exception as e:  # noqa: BLE001
            outcomes.append(InvariantOutcome(
                invariant_name=inv_name,
                verdict="error",
                elapsed_sec=round(time.monotonic() - inv_t0, 3),
                error_message=f"verify_proof raised: {e}",
            ))
            continue

        # Layer-1 of the 4-layer defense: per-invariant verdict
        # mapping. Same shape as ATH-948 ProofResult.status precedence
        # + ATH-958 model_invariants verify(). Soundness violations
        # (banned, axiom_leak) → refuted, NEVER silent error.
        if not proof_result.compiles:
            verdict = "refuted"
            err = (
                (proof_result.errors or [""])[0][:200]
                if proof_result.errors
                else "lean compile error"
            )
        elif proof_result.has_sorry:
            verdict = "refuted"
            err = "proof has sorry — incomplete"
        elif proof_result.banned:
            verdict = "refuted"
            err = f"banned construct: {proof_result.banned}"
        elif proof_result.axiom_clean is False:
            verdict = "refuted"
            err = (
                f"axiom leak: {list(proof_result.forbidden_axioms or [])[:3]}"
            )
        elif proof_result.score >= 1.0:
            verdict = "proved"
            err = None
        else:
            verdict = "error"
            err = (
                f"unexpected ProofResult shape: compiles=True, no sorry, "
                f"no banned, axiom_clean!=False, score={proof_result.score}"
            )

        outcomes.append(InvariantOutcome(
            invariant_name=inv_name,
            verdict=verdict,
            elapsed_sec=round(time.monotonic() - inv_t0, 3),
            error_message=err,
            details={
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "score": proof_result.score,
                "axiom_clean": proof_result.axiom_clean,
            },
        ))

    composite_verdict, all_proven = _classify_composite(outcomes)
    total_elapsed = round(time.monotonic() - t0, 3)

    result = SparsityResult(
        pruning_scheme=pruning_scheme,
        target_sparsity=target_sparsity,
        composite_verdict=composite_verdict,
        all_invariants_proven=all_proven,
        invariant_outcomes=outcomes,
        # loss_bound_eps stays None until Pythia.PACBayes lands.
        loss_bound_eps=None,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        _emit_complete(result)

    return result


def _emit_complete(result: SparsityResult) -> None:
    """Best-effort trace emit. Never raises — same TraceSink contract
    as :func:`kairos.silicon_review.review` and
    :func:`kairos.model_invariants.verify`."""
    try:
        from kairos.observe import emit
        emit(
            "sparsity_verify_complete",
            {
                "pruning_scheme": result.pruning_scheme,
                "target_sparsity": result.target_sparsity,
                "composite_verdict": result.composite_verdict,
                "all_invariants_proven": result.all_invariants_proven,
                "invariants_proved": result.proved_invariants,
                "invariants_failed": result.failed_invariants,
                "loss_bound_eps": result.loss_bound_eps,
                "total_elapsed_sec": result.total_elapsed_sec,
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break verify()
        pass


__all__ = [
    "InvariantOutcome",
    "SparsityResult",
    "KNOWN_PRUNING_SCHEMES",
    "KNOWN_INVARIANT_KINDS",
    "verify",
]
