"""Statistics helpers — aggregate scores across runs.

All functions are pure Python, no numpy dependency.
"""
from __future__ import annotations

import json
import math
from pathlib import Path


def mean(values: list[float]) -> float:
    if not values:
        return 0.0
    return sum(values) / len(values)


def stdev(values: list[float]) -> float:
    """Sample standard deviation (N-1 denominator)."""
    n = len(values)
    if n < 2:
        return 0.0
    m = mean(values)
    variance = sum((v - m) ** 2 for v in values) / (n - 1)
    return math.sqrt(variance)


def percentile(values: list[float], p: float) -> float:
    """Compute the p-th percentile (0..100) using linear interpolation."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    if p <= 0:
        return sorted_vals[0]
    if p >= 100:
        return sorted_vals[-1]
    k = (len(sorted_vals) - 1) * (p / 100.0)
    lo = math.floor(k)
    hi = math.ceil(k)
    if lo == hi:
        return sorted_vals[int(k)]
    return sorted_vals[lo] * (hi - k) + sorted_vals[hi] * (k - lo)


def summarize(values: list[float]) -> dict:
    """Compute full summary statistics for a list of scores."""
    if not values:
        return {
            "count": 0, "mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0,
            "p25": 0.0, "p50": 0.0, "p75": 0.0, "p90": 0.0,
        }
    sorted_vals = sorted(values)
    return {
        "count": len(values),
        "mean": round(mean(values), 4),
        "std": round(stdev(values), 4),
        "min": round(sorted_vals[0], 4),
        "max": round(sorted_vals[-1], 4),
        "p25": round(percentile(values, 25), 4),
        "p50": round(percentile(values, 50), 4),
        "p75": round(percentile(values, 75), 4),
        "p90": round(percentile(values, 90), 4),
    }


def aggregate_runs(run_paths: list[str | Path]) -> dict:
    """Aggregate scores across multiple run files.

    Returns a dict keyed by task_id with per-task stats, plus an overall
    summary across all runs.
    """
    per_task: dict[str, list[float]] = {}
    overall: list[float] = []

    for path in run_paths:
        data = json.loads(Path(path).read_text())
        # Support both {results: [...]} (evaluate output) and single task dict (solve output)
        results = data.get("results")
        if results is None and "score" in data and "task" in data:
            results = [data]
        elif results is None:
            results = []
        for r in results:
            task = r.get("task") or r.get("task_id") or "unknown"
            score = r.get("score")
            if isinstance(score, (int, float)):
                per_task.setdefault(task, []).append(float(score))
                overall.append(float(score))

    return {
        "overall": summarize(overall),
        "per_task": {t: summarize(s) for t, s in per_task.items()},
        "num_runs": len(run_paths),
        "num_tasks": len(per_task),
    }
