"""Filename canonicalization helpers for Athanor environments.

The authoritative rule for each environment lives in the scoring container.
Functions here mirror that logic exactly — platform and runner must use these
helpers to stay in sync with what scoring.py expects to find on disk.
"""


def task_slug_to_lean_filename(task_slug: str) -> str:
    """Convert a snake_case task slug to the canonical Lean stub filename.

    Authoritative source:
        environments/lean-theorem-proving/root_data/eval/configs/*.json
        Each config has a ``lean_file`` field set at task creation time.
        The scoring container (scoring.py line 524) reads this field directly;
        it does NOT re-derive the filename at runtime from task_slug.

    The construction rule, as observed across all 28 lean-theorem-proving
    tasks and confirmed in the scaffold (scaffold-lean/src/environment/tasks/
    example_task/__init__.py):

        1. Strip the ``_builder_verifier`` suffix if present.
        2. Convert the remaining snake_case slug to PascalCase by capitalizing
           the first letter of each ``_``-separated word.
        3. Append ``.lean``.

    Examples:
        "fib_add_formula"                 -> "FibAddFormula.lean"
        "binary_search_builder_verifier"  -> "BinarySearch.lean"
        "sqrt2_irrational"                -> "Sqrt2Irrational.lean"
        "two_sum"                         -> "TwoSum.lean"

    Args:
        task_slug: Snake_case task identifier (e.g. ``sum_odds_equals_n_squared``).

    Returns:
        Lean filename (basename only, no path prefix) e.g. ``SumOddsEqualsNSquared.lean``.
    """
    # Step 1: strip builder_verifier suffix
    slug = task_slug
    if slug.endswith("_builder_verifier"):
        slug = slug[: -len("_builder_verifier")]

    # Step 2: snake_case -> PascalCase
    pascal = "".join(word.capitalize() for word in slug.split("_"))

    # Step 3: append .lean
    return pascal + ".lean"
