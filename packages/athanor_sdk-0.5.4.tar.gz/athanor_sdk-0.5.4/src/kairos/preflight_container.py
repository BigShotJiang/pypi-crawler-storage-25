"""Alias module — re-exports from `kairos.preflight`.

The historical `kairos.preflight` module is a container preflight (verifies
a Docker scoring image, not model reachability). `kairos.preflight_fleet`
was added in 0.3.5 for fleet model-reachability checks.

This alias exists so code that wants to be explicit about which preflight
it's calling can `from kairos import preflight_container`. The underlying
implementation still lives in `kairos.preflight` to keep existing tests
and mock paths working.
"""
from kairos.preflight import preflight  # noqa: F401

__all__ = ["preflight"]
