"""Property check framework — lightweight decorator-based property tests.

Usage:

    from kairos.property import check, run_checks

    @check("output shape matches")
    def check_shape(student_fn, ref_fn, inputs):
        return student_fn(*inputs).shape == ref_fn(*inputs).shape

    @check("output values within tolerance", weight=2)
    def check_values(student_fn, ref_fn, inputs):
        import numpy as np
        return np.allclose(student_fn(*inputs), ref_fn(*inputs), atol=1e-6)

    result = run_checks(student_fn=my_fn, ref_fn=reference, inputs=(x, y))
    # result: {"passed": 1, "total": 2, "details": [...], "score": 0.333}
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class CheckSpec:
    """A registered property check."""
    name: str
    func: Callable
    weight: float = 1.0
    timeout: float | None = None


# Global registry of checks
_CHECK_REGISTRY: list[CheckSpec] = []


def check(name: str, *, weight: float = 1.0, timeout: float | None = None):
    """Decorator to register a property check.

    The decorated function should return True (pass), False (fail),
    or raise an exception (fail with error message).

    Args:
        name: human-readable name for the check
        weight: relative weight for weighted scoring (default 1.0)
        timeout: per-check timeout in seconds (None = no timeout)
    """
    def decorator(func: Callable) -> Callable:
        _CHECK_REGISTRY.append(CheckSpec(name=name, func=func, weight=weight, timeout=timeout))
        return func
    return decorator


def clear_checks() -> None:
    """Clear the global check registry. Useful for tests."""
    _CHECK_REGISTRY.clear()


def get_checks() -> list[CheckSpec]:
    """Return a copy of the current registered checks."""
    return list(_CHECK_REGISTRY)


@dataclass
class CheckResult:
    name: str
    passed: bool
    weight: float
    error: str | None = None


@dataclass
class RunResult:
    passed: int
    total: int
    weighted_passed: float
    weighted_total: float
    score: float  # weighted_passed / weighted_total
    details: list[CheckResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "total": self.total,
            "weighted_passed": round(self.weighted_passed, 4),
            "weighted_total": round(self.weighted_total, 4),
            "score": round(self.score, 4),
            "details": [
                {"name": d.name, "passed": d.passed, "weight": d.weight, "error": d.error}
                for d in self.details
            ],
        }


def run_checks(*args: Any, checks: list[CheckSpec] | None = None, **kwargs: Any) -> RunResult:
    """Run all registered (or provided) checks with the given arguments.

    Each check is called as `check(*args, **kwargs)`. Must return a bool
    or raise. All exceptions are caught and reported as failures.

    Args:
        *args, **kwargs: forwarded to each check function
        checks: optional explicit list of checks to run (default: global registry)

    Returns:
        RunResult summarizing pass/fail and weighted score.
    """
    specs = checks if checks is not None else _CHECK_REGISTRY
    details: list[CheckResult] = []
    passed_count = 0
    weighted_passed = 0.0
    weighted_total = 0.0

    for spec in specs:
        weighted_total += spec.weight
        try:
            result = spec.func(*args, **kwargs)
            if bool(result):
                passed_count += 1
                weighted_passed += spec.weight
                details.append(CheckResult(name=spec.name, passed=True, weight=spec.weight))
            else:
                details.append(CheckResult(name=spec.name, passed=False, weight=spec.weight, error="returned False"))
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            details.append(CheckResult(
                name=spec.name, passed=False, weight=spec.weight, error=f"{type(e).__name__}: {e}"
            ))

    total = len(specs)
    score = weighted_passed / weighted_total if weighted_total > 0 else 0.0
    return RunResult(
        passed=passed_count,
        total=total,
        weighted_passed=weighted_passed,
        weighted_total=weighted_total,
        score=score,
        details=details,
    )
