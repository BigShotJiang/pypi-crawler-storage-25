"""Lean 4 proof verification utilities.

Helpers for domain engineers who want verifiable proofs on their code
without needing to build full RL environments.

Usage:
    from kairos.lean import verify_proof, check_sorry, score_proof

    # Verify a Lean 4 proof compiles
    result = verify_proof("theorem add_comm (a b : Nat) : a + b = b + a := by omega")

    # Check for sorry (incomplete proof markers)
    has_sorry, count = check_sorry(proof_code)

    # Score a proof: 1.0 (full), 0.35 (sorry), 0.25 (broken), 0.0 (banned)
    score = score_proof(proof_code)
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kairos.signing import SignedVerdict

_logger = logging.getLogger(__name__)


@dataclass
class ProofResult:
    """Result of verifying a Lean 4 proof.

    ATH-569: when ``verify_proof`` is invoked with ``aristotle=True``
    and dispatch succeeds, the immediate return is a ProofResult with
    ``aristotle_status="submitted"`` + ``aristotle_project_id=<uuid>``
    (the proof itself has NOT been verified yet — the caller polls via
    :func:`kairos.aristotle.poll_project` or the sweep cron).
    """
    compiles: bool
    has_sorry: bool = False
    sorry_count: int = 0
    score: float = 0.0
    errors: list[str] = field(default_factory=list)
    banned: str | None = None
    # ATH-829 / 2026-04-28 dogfood: transitive axiom audit. After lake
    # build, the verify path runs `#print axioms <theorem>` and parses
    # the dependency list. ``axiom_clean=True`` iff every dependency is
    # in :data:`AXIOM_ALLOWLIST`. ``None`` when the audit was skipped
    # (build failed, theorem name not extractable, or audit_axioms=False).
    # ``forbidden_axioms`` lists the non-allowlist names — non-empty
    # means the proof leaked sorryAx or another axiom (the wald_wolfowitz
    # vacuous-self-reference catch).
    axiom_clean: bool | None = None
    forbidden_axioms: list[str] = field(default_factory=list)
    # ATH-569: Aristotle dispatch surface. Populated only when caller
    # passed ``aristotle=True`` AND the CLI + API key resolved. None on
    # the normal (non-Aristotle) path.
    aristotle_project_id: str | None = None
    aristotle_status: str | None = None  # "submitted" | "complete" | "failed" | "timeout"
    # ATH-853 (Q2 anti-cheat): cryptographic provenance for paid-tier
    # closed-and-clean verdicts. Populated automatically by
    # :func:`verify_proof` when the customer's org has
    # ``signed_verdict_required=true`` (preflight gate). Free-tier orgs
    # + ``KAIROS_NO_TRACE=1`` always see ``None`` here. Customers /
    # third-party auditors verify offline via
    # :func:`kairos.signing.verify_signed_verdict`.
    signed_verdict: "SignedVerdict | None" = None

    @property
    def status(self) -> str:
        """Derived outcome label — one of the :data:`PROOF_STATES`
        values. Precedence (top-to-bottom):

        * ``banned`` — construct-level bypass (axiom decl, unsafe def,
          Mathlib import, etc. caught at the source-text level).
        * ``axiom_leak`` — ATH-948: compiles cleanly + no sorry + no
          banned construct, but the transitive axiom audit found a
          forbidden axiom (e.g. ``sorryAx`` leak via vacuous self-
          reference). Same soundness class as ``banned``; surfaced as
          its own status so consumers can emit precise messages.
        * ``aristotle_pending`` — dispatched, awaiting result.
        * ``full_proof`` — compiles, no sorry, no banned, axiom-clean.
        * ``partial_proof`` — compiles with sorry.
        * ``compile_error`` — does not compile.
        """
        if self.banned:
            return "banned"
        # ATH-948 fix: axiom_clean=False is silent-success-failure-mode
        # if not surfaced — without this branch, a proof leaking
        # sorryAx via vacuous self-reference would be reported as
        # full_proof. Customer-facing simple_prove + lean_cycle's
        # closed= determination both inherited this bug.
        if self.axiom_clean is False:
            return "axiom_leak"
        if self.aristotle_status == "submitted":
            return "aristotle_pending"
        if self.compiles and not self.has_sorry:
            return "full_proof"
        if self.compiles and self.has_sorry:
            return "partial_proof"
        return "compile_error"


# Banned constructs that bypass proof obligations
BANNED_PATTERNS = [
    (r"^\s*(?:private\s+|protected\s+)?axiom\s", "axiom declarations bypass proof"),
    (r"^import\s+Mathlib\b", "Mathlib imports can bring uncontrolled axioms"),
    (r"^import\s+Lean\b", "Lean meta-programming imports"),
    (r"unsafe\s+def", "unsafe definitions bypass type checking"),
    (r"@\[init\]", "init attributes execute at import time"),
]

# ─── Proof-body normalization ─────────────────────────────────────────


def normalize_proof_body(code: str) -> str:
    """Normalize drafter-produced Lean 4 proof code before verification.

    Prevents false ``type_fail`` rejections caused by cosmetic formatting
    differences between what a drafter emits and what Lean 4's parser
    accepts. Every normalization preserves semantics — a correct proof
    stays correct, an incorrect proof stays incorrect.

    Applied automatically inside :func:`verify_proof` so customer agents
    never need to call this manually. Exposed as a public helper for
    callers who want to inspect what normalization happened, or who
    build their own verify path outside the SDK.

    Current normalizations:

    1. **Tactic-block newline.** ``":= by <stuff>"`` on one line →
       ``":= by\\n  <stuff>"``. Lean 4 treats ``by <tactic>`` on the
       same line as the theorem header as a closed single-line tactic
       block. Subsequent-line tactics become orphaned commands
       (``"unexpected token; expected command"``). The rewrite puts
       ``by`` on its own line so the tactic block gets a proper
       indented scope. Both forms are valid Lean 4 when the proof is
       correct; this just prevents a format-dependent false rejection.
       Only fires on the FIRST occurrence (count=1), so internal
       ``have h := by exact foo`` inside the proof body is untouched.

    2. **Windows line endings.** ``\\r\\n`` → ``\\n``.
    """
    code = code.replace("\r\n", "\n")
    if ":= by " in code:
        code = code.replace(":= by ", ":= by\n  ", 1)
    return code


# Proof-state categories. The authoritative reward values live in each
# env's scoring container — these SDK-side defaults are approximate,
# useful for client-side estimation only. Your container's scoring.py
# is the source of truth.
PROOF_STATES = (
    "full_proof",     # compiles, no sorry, no banned, axiom-clean
    "partial_proof",  # compiles with sorry
    "compile_error",  # does not compile
    "banned",         # contains banned construct (axiom/unsafe/etc.)
    "axiom_leak",     # ATH-948: compiles + no sorry + no banned, but
                      # transitive axiom audit found a forbidden axiom
                      # (e.g. sorryAx via vacuous self-reference).
                      # Same soundness class as `banned` — refuted, not
                      # full_proof.
    "no_proof",       # nothing submitted
)

# Client-side approximate reward map. Do not rely on exact values — the
# container is authoritative. Used internally by `score_proof()` for
# local estimates. Kept private (underscore prefix) so consumers don't
# take a dependency on these specific values.
_APPROX_SCORES = {
    "full_proof": 1.0,
    "partial_proof": 0.35,
    "compile_error": 0.25,
    "banned": 0.0,
    "axiom_leak": 0.0,  # ATH-948 soundness class — same as banned
    "no_proof": 0.15,
}


def check_banned(code: str, *, allow_project_imports: bool = False) -> str | None:
    """Check for banned constructs. Returns the reason or None.

    Args:
        code: Lean 4 source to scan.
        allow_project_imports: when True, skip the ``import Mathlib`` /
            ``import Lean`` bans. Lake-project mode passes True because
            the project's ``lakefile.toml`` / ``lean-toolchain`` is the
            trust boundary — the project owner has already decided
            which dependencies are legitimate. Axiom + unsafe + init
            bans still apply because those represent a soundness
            bypass inside the submitted proof code itself.
    """
    for pattern, reason in BANNED_PATTERNS:
        if allow_project_imports and "import" in reason.lower():
            continue
        if re.search(pattern, code, re.MULTILINE):
            return reason
    return None


def check_sorry(code: str) -> tuple[bool, int]:
    """Check for sorry in proof code.

    Returns:
        (has_sorry, count) — whether sorry appears and how many times.
    """
    # Match 'sorry' as a standalone tactic, not inside strings or comments
    matches = re.findall(r'\bsorry\b', code)
    return (len(matches) > 0, len(matches))


#: Default wall-clock seconds for ``verify_proof``.
#:
#: 600s (10 min) is the lake-project cold-cache floor — first
#: ``lake build`` of a Mathlib-using project like ``cedar-spec``
#: takes ~5 min on a warm host (ATH-513 dogfood). Bare-file mode
#: finishes in milliseconds for trivial proofs, so 600s is
#: generous but harmless headroom. Customers with known-long proofs
#: (full Mathlib build, complex tactic search) still override
#: explicitly.
#:
#: ATH-522 bumped this from 120s → 600s on 2026-04-23 after
#: customer-confusion reports from first-run lake-mode timeouts.
DEFAULT_VERIFY_TIMEOUT_SEC = 600

# ATH-829 / 2026-04-28: transitive axiom-audit allowlist.
#
# These three are Lean's classical / kernel axioms that Mathlib accepts
# as the trust base. ANY other axiom in the dependency tree means the
# "proof" has been short-circuited — typically `sorryAx` (`sorry` /
# `admit` somewhere transitively), occasionally a custom `axiom` decl
# the candidate or one of its imports introduced.
#
# The dogfood that surfaced this 2026-04-28: a sweep emit of
# `:= by exact <imported_sorry_having_name>` compiles clean and has no
# `sorry` token in the candidate text — but `#print axioms` shows
# `sorryAx` because the imported declaration was itself `:= sorry`.
# Without this allowlist gate at verify time, the closure judgment is
# vacuous-tolerant.
AXIOM_ALLOWLIST = frozenset({"propext", "Classical.choice", "Quot.sound"})

# Lean prints axiom dependencies in TWO shapes:
#   (a) depends on axioms: [a, b, c]      — typical case, list of axioms
#   (b) does not depend on any axioms     — pure-kernel proof, list empty
# Both indicate the proof type-checked. We need to distinguish "no
# match found" (audit didn't fire / regex missed) from "matched (b)
# with empty list" (axiom-clean confirmed).
_AXIOM_PRINT_RE = re.compile(
    r"depends on axioms:\s*\[([^\]]*)\]",
    re.MULTILINE,
)
_AXIOM_NONE_RE = re.compile(
    r"does not depend on any axioms",
    re.MULTILINE,
)
# Last `theorem`/`lemma` declaration name in a Lean source — used to
# auto-target `#print axioms` when the caller doesn't supply a name.
_LAST_DECL_RE = re.compile(
    r"(?:theorem|lemma)\s+(\w+)",
    re.MULTILINE,
)
# Active namespace at the end of the source — the `#print axioms`
# directive lands AFTER `end <ns>`, so the bare theorem name is no
# longer in scope and Lake fails with "Unknown constant <name>". We
# match the OUTERMOST `namespace <X>` (must be paired with a later
# `end <X>` outside the audit zone) and prefix the print target with
# `<X>.<theorem>`. Multi-namespace files use the deepest containing
# namespace at decl time; we approximate with the LAST `namespace`
# that has no trailing `end <X>` — for a typical scratch module
# that's the single wrapper.
_NAMESPACE_RE = re.compile(
    r"^\s*namespace\s+([A-Za-z_][A-Za-z0-9_.]*)",
    re.MULTILINE,
)


def _emit_to_active_session(event_type: str, payload: dict) -> None:
    """ATH-587 slice D: emit a trace event to the active kairos.session,
    if one is set.

    ATH-971 Phase 3 migration: routed through
    :func:`kairos.observe.emit` with ``silent_if_no_session=True`` so
    the unified emit pathway sees these events. Behavior preserved
    verbatim:

    * No active session anywhere -> silent return.
    * Active session's sink is None or NoopTraceSink -> silent return
      (privacy-fence).
    * Sink emit raises -> swallowed per the TraceSink Protocol.

    Adds ``session_id`` to the payload from the active context so
    per-event grouping works without the caller threading it through.
    """
    import sys as _sys
    _observe_mod = _sys.modules.get("kairos.observe")
    if _observe_mod is None:  # pragma: no cover -- always loaded in practice
        from kairos import observe as _observe_mod  # type: ignore[no-redef]

    payload = dict(payload)
    # Auto-stamp session_id from the active context (legacy or
    # canonical) into the payload for grouping continuity.
    ctx = _observe_mod.active_session_context(run_subtype="generator_synthesis")
    if ctx is not None and ctx.session_id and "session_id" not in payload:
        payload["session_id"] = ctx.session_id

    _observe_mod.emit(
        event_type,
        payload,
        run_subtype="generator_synthesis",  # type: ignore[arg-type]
        silent_if_no_session=True,
    )


def _try_dispatch_aristotle(code: str, timeout_sec: int) -> ProofResult | None:
    """ATH-569: submit ``code`` to Aristotle and return a
    submitted-pending :class:`ProofResult`, or None to fall through.

    Returns None in these cases (the caller proceeds with normal lean
    verification):

    * ``ARISTOTLE_API_KEY`` not set — logs WARN, does not raise.
    * ``aristotle`` CLI missing from PATH — logs WARN, does not raise.
    * Submit succeeds after CLI invocation but returns no project_id —
      logs ERROR + returns None so the caller still gets a proof result.

    Returns a :class:`ProofResult` with ``aristotle_status="submitted"``
    when dispatch succeeded. The caller is expected to poll via
    :func:`kairos.aristotle.poll_project` or let the sweep cron
    drain it. ``compiles=False`` + ``has_sorry=False`` signal "not
    verified yet — see aristotle_*" fields; dashboards render the
    ``aristotle_pending`` status (see ProofResult.status).

    Pure side-effect: subprocess call to the ``aristotle`` binary.
    """
    # Local import so kairos.lean stays importable when the aristotle
    # module can't load (e.g. missing pydantic-like optional deps —
    # aristotle.py itself is stdlib-only so this is defensive).
    from kairos import aristotle as _aristotle

    api_key = _aristotle.find_api_key()
    if not api_key:
        _logger.warning(
            "ATH-569 aristotle=True requested but ARISTOTLE_API_KEY not "
            "set — falling through to non-Aristotle verification path. "
            "Set the key to enable dispatch.",
        )
        return None

    try:
        submission = _aristotle.submit_tarball(
            code, timeout_sec=min(timeout_sec, 300),
        )
    except _aristotle.AristotleCLIMissingError as exc:
        _logger.warning(
            "ATH-569 aristotle CLI not available (%s) — falling through "
            "to non-Aristotle verification.",
            exc,
        )
        return None

    if submission.ok:
        _logger.info(
            "ATH-569 dispatched to Aristotle: project_id=%s (poll via "
            "kairos.aristotle.poll_project or sweep cron; 1h default "
            "timeout).",
            submission.project_id,
        )
        return ProofResult(
            compiles=False,
            has_sorry=False,
            sorry_count=0,
            score=0.0,
            errors=[],
            banned=None,
            aristotle_project_id=submission.project_id,
            aristotle_status="submitted",
        )

    _logger.error(
        "ATH-569 aristotle submit failed: %s — falling through.",
        submission.error,
    )
    return None


def verify_proof(
    code: str,
    *,
    lake_project: str | Path | None = None,
    module_path: str | None = None,
    timeout: int = DEFAULT_VERIFY_TIMEOUT_SEC,
    lean_bin: str | None = None,
    aristotle: bool = False,
    aristotle_timeout: int = 3600,
    audit_axioms: bool = True,
    audit_theorem_name: str | None = None,
    target_id: str | None = None,
    theorem_statement: str | None = None,
) -> ProofResult:
    """ATH-841 wrapper — emit a `verify_proof_attempt` trace event for
    every call so a bespoke driver that bypasses ``kairos.observe()`` /
    ``kairos.session()`` still produces traces.

    Calls :func:`_verify_proof_impl` (the real verification logic) and
    emits the result via :func:`kairos.observe.emit`. When the caller is
    inside an explicit observe/session block the event lands in that
    context's sink + run_id; otherwise observe.emit auto-bootstraps a
    free-tier context using ``default_sink_from_env()`` (Supabase if
    token + URL configured, else local JSONL backstop).

    Args (post-base):
        target_id: The benchmark target identifier (``<env>/<task>`` or
            UUID). When supplied alongside ``theorem_statement``, the
            wrapper emits a ``statement_hash`` trace event for the
            ATH-859 platform-side L14 gate. Optional — leave as None
            for ad-hoc proofs that aren't bench targets.
        theorem_statement: The raw theorem statement source the
            customer is claiming to prove. Will be canonicalized
            (comments + whitespace stripped) before hashing. Pass
            either the raw text or the already-canonical form
            (idempotent). Optional, paired with ``target_id``.

    See :func:`_verify_proof_impl` for the rest of the parameter +
    return contract.
    """
    import time as _time

    start = _time.monotonic()
    result = _verify_proof_impl(
        code,
        lake_project=lake_project,
        module_path=module_path,
        timeout=timeout,
        lean_bin=lean_bin,
        aristotle=aristotle,
        aristotle_timeout=aristotle_timeout,
        audit_axioms=audit_axioms,
        audit_theorem_name=audit_theorem_name,
    )
    elapsed = _time.monotonic() - start

    # ATH-841 emit. Best-effort — observe.emit is non-raising per
    # the TraceSink Protocol; any sink-side failure is logged and
    # swallowed so verify_proof's return contract is preserved.
    try:
        from kairos.observe import emit as _emit
        from kairos.trace import reduce_long_arg as _reduce
        _emit(
            "verify_proof_attempt",
            {
                "compiles": result.compiles,
                "has_sorry": result.has_sorry,
                "sorry_count": result.sorry_count,
                "score": result.score,
                "banned": result.banned,
                "errors_head": (
                    list(result.errors[:3]) if result.errors else []
                ),
                "wall_seconds": round(elapsed, 4),
                "lake_mode": lake_project is not None,
                "module_path": module_path,
                # Code preview reduces to digest+preview for files
                # that would blow up the row size (long lake-mode
                # closures, paper-proof literal text). 500-char cap
                # appropriate for proof source.
                "code_preview": _reduce(code, preview_cap=500),
                # Aristotle dispatch leaves these populated — useful
                # for downstream filtering on the trace timeline.
                "aristotle_project_id": getattr(
                    result, "aristotle_project_id", None,
                ),
                "aristotle_status": getattr(
                    result, "aristotle_status", None,
                ),
            },
            run_subtype="theorem_proving",
        )
    except Exception:
        _logger.exception(
            "verify_proof: ATH-841 emit failed — swallowing so the "
            "verification result is still returned to the caller"
        )

    # ATH-853 (Q2 anti-cheat): on closed-and-clean verdicts, request
    # a cryptographic signature from kairos.io's sign-verdict endpoint
    # for orgs with signed_verdict_required=true. Best-effort,
    # non-raising — fail-open since signing is additive provenance,
    # not a correctness gate. Free-tier orgs + KAIROS_NO_TRACE=1 + any
    # network failure leave result.signed_verdict=None.
    if (
        result.compiles
        and not result.has_sorry
        and result.banned is None
        and result.axiom_clean is not False
    ):
        try:
            from kairos.signing import maybe_sign_verdict
            sv = maybe_sign_verdict(
                {
                    "proved": True,
                    "compiles": result.compiles,
                    "has_sorry": result.has_sorry,
                    "axiom_clean": result.axiom_clean,
                    "forbidden_axioms": list(result.forbidden_axioms),
                    "audit_theorem_name": audit_theorem_name,
                    "module_path": module_path,
                },
                proof_artifact=code,
            )
            if sv is not None:
                result.signed_verdict = sv
        except Exception:
            _logger.exception(
                "verify_proof: ATH-853 sign-verdict failed — leaving "
                "signed_verdict=None and returning the result"
            )

    # ATH-855 (L15 anti-cheat): on closed-and-clean verdicts, run the
    # tactic-vocabulary entropy classifier and emit the verdict so
    # platform's AntiCheatPanel can light up the L15 row. Advisory
    # signal — does NOT mutate result.compiles or fail the proof.
    # Best-effort, non-raising; any classifier failure is swallowed.
    if (
        result.compiles
        and not result.has_sorry
        and result.banned is None
    ):
        try:
            from kairos.closure_classifier import classify_closure
            from kairos.observe import emit as _emit
            verdict = classify_closure(
                proof_body=code,
                goal=audit_theorem_name,
            )
            _emit(
                "tactic_vocabulary_entropy",
                {
                    "tactic_count": verdict.tactic_count,
                    "unique_tactics": verdict.unique_tactics,
                    "shannon_entropy_bits": verdict.shannon_entropy_bits,
                    "applied_lemmas": list(verdict.applied_lemmas),
                    "is_alpha_rename": verdict.is_alpha_rename,
                    "is_trivial": verdict.is_trivial,
                    "trivial_reason": verdict.trivial_reason,
                    "threshold_min_entropy_bits": (
                        verdict.threshold_min_entropy_bits
                    ),
                    "threshold_min_tactic_tokens": (
                        verdict.threshold_min_tactic_tokens
                    ),
                },
                run_subtype="theorem_proving",
            )
        except Exception:
            _logger.exception(
                "verify_proof: ATH-855 classifier emit failed — "
                "swallowing so the verification result is preserved"
            )

    # ATH-859 (L14 anti-cheat): when the caller supplies both
    # target_id and theorem_statement, emit a ``statement_hash`` event
    # that the platform sync gate compares against the canonical
    # benchmark.jsonl hash. Catches the statement-replacement attack
    # (rewrite `theorem hard_thm : <complicated>` to `: True := trivial`
    # before proving). Best-effort, non-raising — when target_id /
    # theorem_statement are absent the event is simply not emitted
    # (ad-hoc proofs aren't gated).
    if target_id is not None and theorem_statement is not None:
        try:
            from kairos.observe import emit as _emit
            from kairos.statement_hash import (
                canonicalize_statement,
                compute_target_hash,
            )
            canonical = canonicalize_statement(theorem_statement)
            stmt_hash = compute_target_hash(
                target_id=target_id, theorem_statement=theorem_statement,
            )
            _emit(
                "statement_hash",
                {
                    "target_id": target_id,
                    "statement_canonical": canonical,
                    "statement_hash": stmt_hash,
                    "hash_algorithm": "sha256",
                },
                run_subtype="theorem_proving",
            )
        except Exception:
            _logger.exception(
                "verify_proof: ATH-859 statement_hash emit failed — "
                "swallowing so verification result is preserved"
            )

    return result


def _verify_proof_impl(
    code: str,
    *,
    lake_project: str | Path | None = None,
    module_path: str | None = None,
    timeout: int = DEFAULT_VERIFY_TIMEOUT_SEC,
    lean_bin: str | None = None,
    aristotle: bool = False,
    aristotle_timeout: int = 3600,
    audit_axioms: bool = True,
    audit_theorem_name: str | None = None,
) -> ProofResult:
    """Verify a Lean 4 proof compiles.

    Two modes are supported:

    1. **Bare-file mode** (``lake_project=None``, default). Writes the
       code to a temp file and runs ``lean <file>`` directly. No
       imports beyond core Lean available. Fast path for standalone
       proofs (``theorem foo : 1 = 1 := rfl``). Bans Mathlib / Lean
       meta imports because they'd fail to resolve anyway.

    2. **Lake-project mode** (``lake_project`` set, 2026-04-23 Cedar-
       fleet unblock). Writes the code to ``<lake_project>/<module>.lean``
       (module path mapped dot-to-slash), then runs ``lake build
       <module_path>`` in the project root. The project's
       ``lean-toolchain`` + ``lakefile.toml`` / ``lakefile.lean``
       define the trust boundary — Mathlib + any declared
       dependencies are available. This is the shape customers need
       for cedar-spec / action_cred / any Mathlib-using proof.

       Both ``lake_project`` AND ``module_path`` must be set to use
       this mode. The module file is backed up before writing +
       restored after verification so the project is left unchanged.
       When ``module_path`` already existed before the call, its
       original contents are restored; when the call created the file,
       it is deleted again.

    Args:
        code: Lean 4 source code. In lake-project mode, this is
            written to the module file before building.
        lake_project: absolute or cwd-relative path to a Lake project
            directory (must contain ``lakefile.lean`` or
            ``lakefile.toml``). When unset, bare-file mode is used.
        module_path: dotted Lean module name (e.g. ``"MyProj.Proofs"``
            maps to ``<lake_project>/MyProj/Proofs.lean``). Required
            when ``lake_project`` is set.
        timeout: max seconds to wait for compilation / lake build.
        lean_bin: path to lean binary (auto-detected if None). Ignored
            in lake-project mode — lake resolves its own toolchain.

    Returns:
        ProofResult with compilation status, sorry detection, and score.

    Raises:
        ValueError: if ``lake_project`` is set without ``module_path``
            (or vice versa). We refuse to guess.
    """
    if (lake_project is None) != (module_path is None):
        raise ValueError(
            "lake_project and module_path must be set together. Pass "
            "BOTH for lake-project mode, or NEITHER for bare-file mode."
        )

    # ATH-569: Aristotle dispatch — submit + return immediately with
    # aristotle_project_id. Caller polls via kairos.aristotle.poll_project
    # or waits on the sweep cron. Missing API key logs WARN + falls
    # through to the normal verification path (Aidan 2026-04-24 06:20Z:
    # "in most cases sonnet/opus agents should close the proof
    # themselves; aristotle only for the hardest solves").
    if aristotle:
        dispatch = _try_dispatch_aristotle(code, aristotle_timeout)
        if dispatch is not None:
            return dispatch

    is_lake_mode = lake_project is not None

    # Check banned constructs first. Lake mode allows project-declared
    # imports (Mathlib etc.) because the lakefile is the trust boundary;
    # axiom / unsafe / init bans still apply.
    banned = check_banned(code, allow_project_imports=is_lake_mode)
    if banned:
        return ProofResult(
            compiles=False,
            banned=banned,
            score=_APPROX_SCORES["banned"],
            errors=[f"Banned construct: {banned}"],
        )

    # Check sorry
    has_sorry, sorry_count = check_sorry(code)

    if is_lake_mode:
        return _verify_in_lake_project(
            code=code,
            lake_project=Path(lake_project),  # type: ignore[arg-type]
            module_path=module_path,  # type: ignore[arg-type]
            timeout=timeout,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            audit_axioms=audit_axioms,
            audit_theorem_name=audit_theorem_name,
        )

    # Find lean binary
    if lean_bin is None:
        lean_bin = shutil.which("lean")
    if lean_bin is None:
        # Try inside a Docker container
        docker_bin = shutil.which("docker") or shutil.which("podman")
        if docker_bin:
            return _verify_in_container(code, timeout, docker_bin, has_sorry, sorry_count)
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=0.0,
            errors=["Lean 4 not found. Install Lean or use Docker."],
        )

    # Normalize before writing to prevent false type_fail from cosmetic
    # formatting (tactic-block indentation, Windows line endings).
    code = normalize_proof_body(code)

    # Write to temp file and compile
    with tempfile.NamedTemporaryFile(suffix=".lean", mode="w", delete=False) as f:
        f.write(code)
        f.flush()
        lean_file = f.name

    try:
        result = subprocess.run(
            [lean_bin, lean_file],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        compiles = result.returncode == 0
        errors = []
        if not compiles:
            err_text = (result.stderr or result.stdout)[:500]
            errors = [line for line in err_text.split("\n") if line.strip()]

        # Also check compiler output for sorry warnings
        if "sorry" in (result.stdout + result.stderr).lower():
            has_sorry = True

        status = "full_proof" if compiles and not has_sorry else \
                 "partial_proof" if compiles else "compile_error"

        return ProofResult(
            compiles=compiles,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=_APPROX_SCORES[status],
            errors=errors,
        )
    except subprocess.TimeoutExpired:
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[f"Compilation timed out ({timeout}s)"],
        )
    finally:
        Path(lean_file).unlink(missing_ok=True)


def _verify_in_container(
    code: str,
    timeout: int,
    docker_bin: str,
    has_sorry: bool,
    sorry_count: int,
) -> ProofResult:
    """Verify proof using a Lean Docker container."""
    code = normalize_proof_body(code)
    with tempfile.NamedTemporaryFile(suffix=".lean", mode="w", delete=False) as f:
        f.write(code)
        f.flush()
        lean_file = Path(f.name)

    try:
        result = subprocess.run(
            [
                docker_bin, "run", "--rm",
                "--network=none",
                "-v", f"{lean_file}:/tmp/proof.lean:ro",
                "ghcr.io/leanprover/lean4:latest",
                "lean", "/tmp/proof.lean",
            ],
            capture_output=True,
            text=True,
            timeout=timeout + 30,  # extra time for container startup
        )
        compiles = result.returncode == 0
        errors = []
        if not compiles:
            err_text = (result.stderr or result.stdout)[:500]
            errors = [line for line in err_text.split("\n") if line.strip()]

        if "sorry" in (result.stdout + result.stderr).lower():
            has_sorry = True

        status = "full_proof" if compiles and not has_sorry else \
                 "partial_proof" if compiles else "compile_error"

        return ProofResult(
            compiles=compiles,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=_APPROX_SCORES[status],
            errors=errors,
        )
    except subprocess.TimeoutExpired:
        return ProofResult(
            compiles=False,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=["Container verification timed out"],
        )
    finally:
        lean_file.unlink(missing_ok=True)


def _verify_in_lake_project(
    code: str,
    lake_project: Path,
    module_path: str,
    timeout: int,
    has_sorry: bool,
    sorry_count: int,
    audit_axioms: bool = True,
    audit_theorem_name: str | None = None,
) -> ProofResult:
    """Write ``code`` into the Lake project at ``module_path`` and
    build it.

    Rollback contract: the project's filesystem state is restored on
    return regardless of build outcome. If ``module_path`` existed
    before, its original bytes are written back; if we created it,
    we delete it. Parent directories we created are left in place —
    a Mathlib project that already had ``Foo/`` will keep it. We
    never delete directories to avoid accidentally removing customer
    work that happens to share a path.

    Lake's own ``build/`` cache is not touched; lake manages its own
    invalidation via the lean file's mtime.
    """
    lake_project = lake_project.resolve()
    if not lake_project.is_dir():
        return ProofResult(
            compiles=False, has_sorry=has_sorry, sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[f"lake_project does not exist: {lake_project}"],
        )
    has_lakefile = (
        (lake_project / "lakefile.lean").exists()
        or (lake_project / "lakefile.toml").exists()
    )
    if not has_lakefile:
        return ProofResult(
            compiles=False, has_sorry=has_sorry, sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[
                f"no lakefile.lean or lakefile.toml in {lake_project}; "
                f"not a Lake project"
            ],
        )

    # Resolve module path. `Foo.Bar` → `<proj>/Foo/Bar.lean`. Refuse
    # module names that would escape the project root — caller can't
    # point us at ../../etc/passwd.
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$", module_path):
        return ProofResult(
            compiles=False, has_sorry=has_sorry, sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[
                f"invalid module_path {module_path!r}; must be dotted "
                f"identifier (e.g. 'Foo.Bar.Baz')"
            ],
        )

    target_file = lake_project / (module_path.replace(".", "/") + ".lean")
    lake_bin = shutil.which("lake")
    if lake_bin is None:
        return ProofResult(
            compiles=False, has_sorry=has_sorry, sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[
                "lake not found on PATH. Install elan "
                "(https://leanprover.github.io/installation/)."
            ],
        )

    # ATH-829 / 2026-04-28: append `#print axioms <theorem>` to the
    # candidate before writing so lake emits the transitive axiom
    # dependency list. We resolve the theorem name from the candidate
    # itself (last `theorem`/`lemma` decl) unless the caller passed an
    # explicit `audit_theorem_name`. The audit fires only when
    # `audit_axioms=True`; callers that want the fast path (no audit,
    # legacy behavior) can opt out.
    audit_name: str | None = None
    augmented_code = code
    if audit_axioms:
        if audit_theorem_name:
            audit_name = audit_theorem_name
        else:
            decls = _LAST_DECL_RE.findall(code)
            audit_name = decls[-1] if decls else None
        if audit_name:
            # Namespace fix (2026-04-28 dogfood): when the candidate
            # source has `namespace X` ... `end X` block, the
            # `#print axioms` directive lands AFTER `end X`, so the
            # bare theorem name is no longer in scope and Lake fails
            # with "Unknown constant <name>". Detect the OUTERMOST
            # namespace and qualify the print target with `<X>.<name>`.
            ns_matches = _NAMESPACE_RE.findall(code)
            if ns_matches:
                # Use the LAST `namespace X` declaration (cycle-engine
                # writes a single wrapper namespace; multi-namespace
                # files would need a paren-aware ns tracker but those
                # don't currently arise from our drivers).
                qualified_name = f"{ns_matches[-1]}.{audit_name}"
            else:
                qualified_name = audit_name
            # Store for separate wrapper-file audit after main build.
            # We do NOT append to the source — that corrupts modules
            # with doc-comments after `end Namespace`.
            pass

    # Backup + write.
    existed = target_file.exists()
    backup: str | None = target_file.read_text() if existed else None
    created_parents: list[Path] = []
    try:
        # Create parent dirs (tracking what we created for cleanup).
        parent = target_file.parent
        while parent != lake_project and not parent.exists():
            created_parents.append(parent)
            parent = parent.parent
        target_file.parent.mkdir(parents=True, exist_ok=True)
        target_file.write_text(augmented_code)

        # Run lake build <module_path>. Use lake env to inherit project
        # toolchain; cwd=lake_project so lake resolves the project.
        result = subprocess.run(
            [lake_bin, "build", module_path],
            cwd=str(lake_project),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        compiles = result.returncode == 0
        errors: list[str] = []
        if not compiles:
            # Lake writes most diagnostics to stdout (Lean compiler
            # output, the `error: <file>:<line>: Tactic ...` block);
            # stderr usually just has a terse `error: build failed`.
            # We need BOTH — stderr-only misses the Lean diagnostic,
            # stdout-only can miss network/filesystem errors.
            combined_err = f"{result.stdout}\n{result.stderr}"[:8000]
            errors = [line for line in combined_err.split("\n") if line.strip()]

        # Lake echoes lean's compiler output. Sorry warnings can come from
        # the candidate's own module OR from any imported module whose
        # source still contains a sorry (a stubbed theorem in a downstream
        # library, an Aristotle-pending lemma, etc.). Only count sorries
        # whose Lake-emitted file path matches the candidate's module —
        # otherwise an unrelated stub anywhere in the import tree falsifies
        # every closure attempt against this project.
        candidate_file_rel = module_path.replace(".", "/") + ".lean"
        # Build a regex that requires the candidate's file path right
        # before the diagnostic, e.g. `Foo/Bar.lean:31:8: declaration uses 'sorry'`
        # or `Foo/Bar.lean:31:8: warning: declaration uses 'sorry'`.
        candidate_sorry_re = re.compile(
            re.escape(candidate_file_rel)
            + r":\d+:\d+:.*?declaration uses .?sorry.?",
            re.IGNORECASE,
        )
        combined = result.stdout + result.stderr
        if candidate_sorry_re.search(combined):
            has_sorry = True

        # ATH-829 axiom audit via a SEPARATE wrapper file.
        # We do NOT append `#print axioms` to the source — that
        # corrupts modules with doc-comments after `end Namespace`.
        # Instead, write a temp file: `import <module>` + `#print axioms`.
        axiom_clean: bool | None = None
        forbidden_axioms: list[str] = []
        if audit_axioms and audit_name and compiles:
            # Run axiom audit via a separate wrapper file.
            _audit_wrapper = target_file.parent / "_kairos_axiom_audit_.lean"
            try:
                _audit_wrapper.write_text(
                    f"import {module_path}\n"
                    f"#print axioms {qualified_name}\n"
                )
                _audit_result = subprocess.run(
                    [lake_bin, "env", "lean", str(_audit_wrapper)],
                    cwd=str(lake_project),
                    capture_output=True, text=True, timeout=30,
                )
                combined = _audit_result.stdout + _audit_result.stderr
            except Exception:  # noqa: BLE001 — broad-catch fallback
                combined = ""
            finally:
                _audit_wrapper.unlink(missing_ok=True)

            # Lean's `#print axioms` prints in two shapes:
            #   (a) `... depends on axioms: [a, b, c]` — list present
            #   (b) `... does not depend on any axioms` — pure-kernel proof
            # Match (a) first; fall back to (b) for the empty case.
            m = _AXIOM_PRINT_RE.search(combined)
            if m:
                listed = [
                    a.strip() for a in m.group(1).split(",") if a.strip()
                ]
                forbidden_axioms = [a for a in listed if a not in AXIOM_ALLOWLIST]
                axiom_clean = not forbidden_axioms
            elif _AXIOM_NONE_RE.search(combined):
                # Term-mode proofs that don't reach Classical etc. land here.
                forbidden_axioms = []
                axiom_clean = True
            else:
                # No #print output — could mean Lean optimized it out
                # or the theorem name didn't match. Conservative: leave
                # axiom_clean=None (caller can decide what unknown means).
                axiom_clean = None

        status = "full_proof" if compiles and not has_sorry else \
                 "partial_proof" if compiles else "compile_error"
        return ProofResult(
            compiles=compiles,
            has_sorry=has_sorry,
            sorry_count=sorry_count,
            score=_APPROX_SCORES[status],
            errors=errors,
            axiom_clean=axiom_clean,
            forbidden_axioms=forbidden_axioms,
        )
    except subprocess.TimeoutExpired:
        return ProofResult(
            compiles=False, has_sorry=has_sorry, sorry_count=sorry_count,
            score=_APPROX_SCORES["compile_error"],
            errors=[f"lake build timed out ({timeout}s) for {module_path}"],
        )
    finally:
        # Restore project filesystem state.
        if existed and backup is not None:
            target_file.write_text(backup)
        elif not existed:
            target_file.unlink(missing_ok=True)
            # Remove directories we created, bottom-up, but only if empty.
            for created in created_parents:
                try:
                    created.rmdir()
                except OSError:
                    # Not empty — customer had something else there. Leave.
                    break


def check_signature(
    stmt: str,
    *,
    imports: list[str] | None = None,
    opens: list[str] | None = None,
    lake_project: str | Path | None = None,
    timeout: int = 60,
) -> dict:
    """Type-check a Lean 4 statement (theorem signature) without proving it.

    Builds a `theorem _sigcheck : <stmt> := by sorry` stub against the
    given imports + opens, then calls :func:`verify_proof` to ask lake
    whether the signature parses + type-checks. The proof body is
    `sorry`, so a well-typed stub returns ``compiles=True, has_sorry=True``.
    A malformed signature returns ``compiles=False`` with parse / type
    errors in ``errors``.

    Use this when an agent (or the kairos decomposer loop) wants to
    refute a Lean type expression *cheaply* — without committing to a
    full proof attempt. ATH-829 Phase 1.4 uses it to gate decomposer
    output: if a sub-lemma's type doesn't even type-check, reject and
    re-prompt.

    :param stmt: the type expression to check (right-hand side of `:`).
    :param imports: Lean imports to prepend (e.g. ``["Mathlib"]``).
    :param opens: ``open`` namespaces.
    :param lake_project: path to the lake project. REQUIRED for
        Mathlib-using statements (bare-file lean can't resolve
        ``import Mathlib``). When ``None``, the function returns
        ``{ok: True, errors: [], skipped: True}`` — the caller is
        responsible for deciding whether to proceed without a check.
    :param timeout: per-check lake timeout in seconds.
    :returns: ``{ok: bool, errors: list[str], skipped: bool}``.
        ``ok=True`` means the signature is well-typed.
    """
    if not lake_project:
        return {"ok": True, "errors": [], "skipped": True}

    imports = imports or []
    opens = opens or []
    stub_lines = [f"import {m}" for m in imports]
    if opens:
        stub_lines.append("")
        stub_lines += [f"open {o}" for o in opens]
    stub_lines.append("")
    stub_lines.append(f"theorem _sigcheck : {stmt} := by sorry")
    stub_code = "\n".join(stub_lines) + "\n"

    # ATH-829 dogfood 2026-04-28: verify_proof in lake mode requires
    # BOTH lake_project AND module_path. Each sig-check needs its own
    # module so concurrent/sequential calls don't clobber each other's
    # files in the lake project. Use a hash-stable name under the
    # project's scratch namespace so the same stmt re-checks idempotently.
    import hashlib
    stmt_hash = hashlib.md5(stub_code.encode("utf-8")).hexdigest()[:12]
    sigcheck_module = f"Pythia.Scratch.Sigcheck.M{stmt_hash}"

    try:
        result = verify_proof(
            code=stub_code,
            lake_project=lake_project,
            module_path=sigcheck_module,
            timeout=timeout,
        )
    except Exception as e:  # noqa: BLE001 — guard returns empty container on any error
        return {
            "ok": False,
            "errors": [f"check raised {type(e).__name__}: {str(e)[:200]}"],
            "skipped": False,
        }

    compiles = getattr(result, "compiles", False)
    err_list = getattr(result, "errors", None) or []
    return {
        "ok": bool(compiles),
        "errors": [str(e)[:300] for e in err_list[:5]],
        "skipped": False,
    }


def score_proof(
    code: str, *, timeout: int = DEFAULT_VERIFY_TIMEOUT_SEC,
) -> float:
    """Convenience: verify and return just the score float.

    Returns:
        Float in [0, 1]. Full proof = 1.0, sorry = 0.35, broken = 0.25, banned = 0.0.
    """
    if not code or not code.strip():
        return _APPROX_SCORES["no_proof"]
    return verify_proof(code, timeout=timeout).score


# ─────────────────────────────────────────────────────────────────────
# predicate_verify — ATH-534 (PLDI '27 paper track, platform ATH-529)
# ─────────────────────────────────────────────────────────────────────


@dataclass
class PredicateResult:
    """Result of verifying a Lean 4 decidable predicate against a term.

    Shape matches the contract platform specified in the cedar-paper-
    track-reshape-sdk-asks msg (2026-04-23 ts=1776980870):

        verified     — True iff the predicate held on the supplied term
                       (i.e. the `decide` tactic closed the goal)
        reason       — one-line human-readable summary; for failures,
                       extracts the specific Lean error that shot down
                       `decide` (e.g. "decide failed", "type mismatch:
                       expected bool, got int")
        eval_output  — tail of lake/lean stdout+stderr, for paper-
                       reproducibility replay traces. Capped at 4KB.
    """

    verified: bool
    reason: str
    eval_output: str


# Trailing match the specific Lean errors we want to classify
# cleanly. Order matters: first match wins.
# Regex note: Lean's error messages use backticks around tactic names
# (e.g. ``Tactic `decide` proved ...``), which we match via backtick
# OR straight-quote to survive version drift.
_DECIDE_FAIL_PATTERNS = [
    (re.compile(
        r"tactic\s+[`']?decide[`']?\s+"
        r"(?:failed|proved that the proposition.*is false)",
        re.IGNORECASE | re.DOTALL),
     "decide failed — predicate does not hold on this term"),
    (re.compile(r"type mismatch", re.IGNORECASE),
     "type mismatch — term's type does not match predicate's expected argument"),
    (re.compile(r"unknown identifier '([^']+)'", re.IGNORECASE),
     "unknown identifier — term uses a name not in scope"),
    (re.compile(r"unknown constant '([^']+)'", re.IGNORECASE),
     "unknown constant — likely missing import"),
    (re.compile(r"failed to synthesize.*Decidable",
                re.IGNORECASE | re.DOTALL),
     "predicate is not Decidable — cannot use `by decide` to verify"),
]


def predicate_verify(
    workspace: str | Path,
    module_path: str,
    predicate_name: str,
    term_source: str,
    *,
    timeout_sec: int = DEFAULT_VERIFY_TIMEOUT_SEC,
    imports: list[str] | None = None,
) -> PredicateResult:
    """Verify a decidable Lean 4 predicate holds on a supplied term.

    Builds a scratch theorem inside the caller's Lake project:

        {imports...}

        theorem __kairos_check : {predicate_name} {term_source} := by
          decide

    and runs ``lake build`` on it. The ``decide`` tactic succeeds iff
    the predicate holds (the Lean kernel closes the proof by
    computation). Failure cases are classified into human-readable
    reasons via :data:`_DECIDE_FAIL_PATTERNS`.

    Args:
        workspace: absolute or cwd-relative path to the customer's
            Lake project. Must contain ``lakefile.lean`` or
            ``lakefile.toml``.
        module_path: dotted Lean module name to write the scratch
            theorem to. Pick something unique per run (e.g. a
            uuid-suffixed name) to avoid collisions.
        predicate_name: the predicate to evaluate. Prefix-called with
            the term (``predicate_name term``). Must be decidable +
            in scope for the imports.
        term_source: Lean expression text for the term the predicate
            is tested against. The SDK embeds it in parentheses to
            protect precedence.
        timeout_sec: wall-clock cap for the lake build. Default is
            :data:`DEFAULT_VERIFY_TIMEOUT_SEC` (600s after ATH-522).
        imports: optional list of import statements to prepend.
            Defaults to a minimum Cedar bridge import + the
            predicate's module (derived from ``module_path`` parent).
            Pass explicit imports to override.

    Returns:
        A :class:`PredicateResult`.

    Raises:
        ValueError: when inputs fail basic sanity (empty term_source,
            invalid module_path shape). Actual Lean-side errors are
            caught and returned as ``verified=False`` instead.

    Example::

        from pathlib import Path
        from kairos.lean import predicate_verify

        r = predicate_verify(
            workspace=Path("kairos-cedar/cedar-spec-bridge"),
            module_path="CedarBridge.KairosCheck.Well123",
            predicate_name="isWellTyped",
            term_source="(env := stdEnv) (Expr.litBool true)",
        )
        assert r.verified
    """
    if not term_source or not term_source.strip():
        raise ValueError("term_source must be a non-empty Lean expression")
    if not re.match(
        r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$",
        module_path,
    ):
        raise ValueError(
            f"invalid module_path {module_path!r}; must be a dotted "
            f"identifier (e.g. 'Foo.Bar.Baz')"
        )

    # ATH-587 slice D: invocation boundary marker for /solve-runs detail
    # page. Session-scoped; no-op outside a kairos.session.
    import time as _time
    _emit_to_active_session(
        "predicate_verify_invocation",
        {"target": module_path},
    )
    _t0 = _time.monotonic()

    def _emit_result(verified: bool | None, error: bool = False) -> None:
        verdict = (
            "error" if error
            else ("holds" if verified else "fails")
        )
        _emit_to_active_session(
            "predicate_verify_result",
            {
                "target": module_path,
                "verdict": verdict,
                "elapsed_sec": _time.monotonic() - _t0,
            },
        )

    workspace_path = Path(workspace).resolve()
    # Resolve imports. Default minimum: the common CedarBridge root if
    # workspace looks like cedar-spec-bridge; else no imports (caller's
    # project toolchain decides). Callers with custom predicates should
    # pass `imports=` explicitly.
    resolved_imports = list(imports) if imports is not None else [
        # Default: import whatever shares the workspace's default
        # target. Cedar-spec-bridge exposes CedarBridge.Predicates.
        "CedarBridge.Predicates",
    ]
    import_block = "\n".join(f"import {i}" for i in resolved_imports)

    # Only `open CedarBridge` when the caller imports a CedarBridge
    # submodule — otherwise the `open` fails at parse time.
    open_line = (
        "open CedarBridge\n"
        if any(i.startswith("CedarBridge") for i in resolved_imports)
        else ""
    )
    code = (
        f"-- Auto-generated by kairos.predicate_verify (ATH-534).\n"
        f"-- Evaluates: {predicate_name} <term> via `by decide`.\n"
        f"{import_block}\n"
        f"\n"
        f"{open_line}"
        f"\n"
        f"theorem __kairos_check : {predicate_name} ({term_source}) := by\n"
        f"  decide\n"
    )

    # Reuse the existing verify_proof lake-mode path. Get back a
    # ProofResult; translate to PredicateResult + classify the error.
    result = verify_proof(
        code,
        lake_project=workspace_path,
        module_path=module_path,
        timeout=timeout_sec,
    )

    if result.status == "full_proof":
        _emit_result(verified=True)
        return PredicateResult(
            verified=True,
            reason="decide succeeded — predicate holds on the term",
            eval_output="",  # success path produces no interesting stdout
        )

    # Failure path — classify from error list.
    err_text = "\n".join(result.errors or [])[:4000]
    reason = "unknown lean error"
    for pattern, label in _DECIDE_FAIL_PATTERNS:
        m = pattern.search(err_text)
        if m:
            reason = label
            break
    if result.status == "banned":
        reason = (
            f"banned construct ({result.banned}) — predicate_verify "
            f"refuses to run against code with axioms/unsafe/init"
        )
    elif result.status == "axiom_leak":
        # ATH-948: predicate_verify_invocation must NOT silently
        # accept an axiom-leak as success. Treat as non-verified.
        forbidden = list(result.forbidden_axioms or [])
        reason = (
            f"axiom leak detected (forbidden: {forbidden[:3]}) — "
            "predicate_verify refuses to ratify a decision that "
            "depends on a forbidden axiom (e.g. sorryAx via vacuous "
            "self-reference)"
        )
    elif result.status == "partial_proof":
        # Only possible if the predicate body itself has `sorry`,
        # which shouldn't happen for a decidable-predicate check
        # built from a term. Treat as non-verified + flag.
        reason = (
            "partial proof (sorry present) — predicate cannot be "
            "verified without a sorry-free decision"
        )

    _emit_result(verified=False)
    return PredicateResult(
        verified=False,
        reason=reason,
        eval_output=err_text,
    )


# ─────────────────────────────────────────────────────────────────────
# sample_generator — ATH-546 Lean-native term sampler
# ─────────────────────────────────────────────────────────────────────


@dataclass
class SampleGeneratorResult:
    """Result of running a Lean generator harness and capturing samples.

    :field terms: list of rendered term strings, one per IO.println line
        from the harness's ``main``. Length is ``<= n`` (short when the
        generator yielded fewer values than requested).
    :field stdout_tail: tail of the harness's captured stdout+stderr
        (capped at 4KB) — useful for debugging when the harness crashes
        or returns zero samples.
    :field error: empty string on success; human-readable one-liner on
        setup / build / runtime failure (lake not found, module_path
        invalid, lake build failed, lean --run timeout, etc.).
    """

    terms: list[str]
    stdout_tail: str = ""
    error: str = ""


_LAKE_DOCKER_IMAGE_ENV = "KAIROS_LAKE_DOCKER_IMAGE"


def _run_lake_in_container(
    *,
    workspace: Path,
    docker_bin: str,
    docker_image: str,
    shell_cmd: str,
    timeout_sec: int,
    workspace_root: Path | None = None,
) -> subprocess.CompletedProcess:
    """Run ``bash -c "<shell_cmd>"`` inside ``docker_image``.

    Mount-and-cwd model:

    * ``workspace_root=None`` (default): mount ``workspace -> /work``,
      cwd = ``/work``. Works for self-contained Lake projects (ATH-552).
    * ``workspace_root=<ancestor>``: mount ``workspace_root -> /work``,
      cwd = ``/work/<relpath(workspace, workspace_root)>``. Required when
      the workspace has relative ``path = "../sibling"`` Lake requires
      that resolve outside the single-dir mount (ATH-557).

    The caller is responsible for passing a ``workspace_root`` that is
    an actual ancestor of ``workspace``; we assert this at the
    :func:`sample_generator` layer before dispatching here.

    Does NOT swallow errors — the caller inspects ``returncode`` +
    stdout/stderr the same way it does for a host subprocess.
    """
    if workspace_root is not None:
        mount_src = workspace_root
        rel = workspace.relative_to(workspace_root)
        cwd_in_container = "/work" if str(rel) == "." else f"/work/{rel.as_posix()}"
    else:
        mount_src = workspace
        cwd_in_container = "/work"

    return subprocess.run(
        [
            docker_bin, "run", "--rm",
            "-v", f"{mount_src}:/work",
            "-w", cwd_in_container,
            docker_image,
            "bash", "-c", shell_cmd,
        ],
        capture_output=True,
        text=True,
        timeout=timeout_sec + 30,  # extra budget for container startup
    )


def sample_generator(
    workspace: str | Path,
    module: str,
    term_type: str,
    generator_expr: str,
    *,
    n: int = 20,
    render_expr: str = "toString",
    extra_imports: list[str] | None = None,
    timeout_sec: int = DEFAULT_VERIFY_TIMEOUT_SEC,
    docker_image: str | None = None,
    workspace_root: str | Path | None = None,
    prelude: str | None = None,
) -> SampleGeneratorResult:
    """Run a Lean generator inside the caller's Lake project and capture
    ``n`` sampled terms.

    Writes a scratch driver module at ``<workspace>/_KairosSample.lean``
    with this shape::

        import {module}
        {extra_imports...}

        def main : IO Unit := do
          let samples : List ({term_type}) ← ({generator_expr} : IO (List {term_type}))
          for e in samples.take {n} do
            IO.println (({render_expr}) e)

    then runs ``lake build {module}`` followed by
    ``lake env lean --run _KairosSample.lean``. Each IO.println line
    in stdout becomes one element of ``SampleGeneratorResult.terms``.

    Rollback contract: the scratch driver file is removed on exit
    regardless of outcome. The target module built by ``lake build``
    is the caller's own module — we never touch it.

    **Contract on ``generator_expr``**: the expression must produce
    ``IO (List {term_type})``. Common adapters:

    - ``Gen α = List α`` style (e.g. CedarFull.Gen): pass
      ``"pure (genWellTyped env τ)"``.
    - ``Gen α`` as Palamedes monad with ``sampleN``:
      ``"sampleN {n} (genWellTyped env τ)"``.
    - Pre-computed list in pure Lean: ``"pure myList"``.

    :param workspace: absolute or cwd-relative path to the Lake project.
    :param module: dotted Lean module name of the generator's definition
        (e.g. ``"CedarFull.Expr"``). Built before the driver runs.
    :param term_type: the Lean type of each sampled value (e.g.
        ``"Cedar.Spec.Expr"``). Injected into the ``: List (...)``
        type annotation in the driver's ``main``.
    :param generator_expr: Lean expression of type
        ``IO (List {term_type})``. See adapters above.
    :param n: upper bound on returned sample count. Default 20.
    :param render_expr: Lean expression of type ``{term_type} → String``
        applied to each sample before ``IO.println``. Default
        ``"toString"`` — most types have a ``ToString`` instance in
        scope. Pass a custom ctor-renderer for round-trip-safe output.
    :param extra_imports: optional additional ``import`` lines (e.g.
        ``["CedarBridge"]`` to get ``Cedar.Spec`` + ``Cedar.Validation``
        into scope).
    :param timeout_sec: wall-clock cap for the whole sequence (build +
        run). Default :data:`DEFAULT_VERIFY_TIMEOUT_SEC`.
    :param docker_image: when provided (or when ``KAIROS_LAKE_DOCKER_IMAGE``
        env is set), route ``lake build`` + ``lake env lean --run``
        through ``docker run`` inside ``docker_image`` with
        ``workspace`` bind-mounted at ``/work``. Use this when the
        caller's host lacks a usable ``lake`` toolchain but the
        workbench container (e.g. ``ghcr.io/athanor-ai/kairos-cedar:latest``)
        has it — ATH-552. Explicit kwarg wins over env override; when
        neither is set, execution stays on the host (status quo).
    :param workspace_root: ancestor directory to bind-mount into the
        container instead of ``workspace`` itself (ATH-557). Required
        when ``workspace/lakefile.toml`` carries relative-path
        ``[[require]]`` entries pointing at sibling Lake packages
        (e.g. ``path = "../palamedes-lean"``). With the default
        single-dir mount those siblings resolve to paths outside the
        container and lake fails. Passing ``workspace_root`` mounts
        the parent, and the effective cwd inside the container becomes
        ``/work/<relpath(workspace, workspace_root)>`` so lake runs
        from the sub-project as before. Must be an ancestor of
        ``workspace``. Ignored when ``docker_image`` is not in play
        (host path doesn't need mount manipulation). Default: ``None``
        (single-dir mount, pre-ATH-557 behaviour).
    :param prelude: optional Lean source text to inline into the
        scratch driver above the ``def main`` (ATH-561). Use this when
        ``generator_expr`` references definitions that DON'T live in
        ``module`` or in any of ``extra_imports`` — e.g. an
        LLM-written generator whose source hasn't been compiled into
        a Lake module yet. The prelude is written verbatim into the
        driver; the caller is responsible for providing valid Lean.
        Opens scope inline: the driver has access to ``prelude``
        bindings + ``module``'s exports + ``extra_imports``
        combined. Default: ``None`` (driver emits only imports + main,
        pre-ATH-561 behaviour).

    :returns: :class:`SampleGeneratorResult`.

    Example::

        from kairos.lean import sample_generator

        r = sample_generator(
            workspace="/path/to/kairos-cedar/cedar-full",
            module="CedarFull.Expr",
            term_type="Cedar.Spec.Expr",
            generator_expr="pure (genWellTyped {} .bool)",
            n=10,
            extra_imports=["CedarBridge"],
        )
        for t in r.terms:
            # t is a Lean-rendered Cedar.Spec.Expr string
            ...
    """
    workspace_path = Path(workspace).resolve()
    if not workspace_path.is_dir():
        return SampleGeneratorResult(
            terms=[], error=f"workspace does not exist: {workspace_path}",
        )
    has_lakefile = (
        (workspace_path / "lakefile.lean").exists()
        or (workspace_path / "lakefile.toml").exists()
    )
    if not has_lakefile:
        return SampleGeneratorResult(
            terms=[],
            error=f"no lakefile in {workspace_path}; not a Lake project",
        )
    if not re.match(
        r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$",
        module,
    ):
        return SampleGeneratorResult(
            terms=[],
            error=f"invalid module {module!r}; must be dotted identifier",
        )
    if not generator_expr or not generator_expr.strip():
        return SampleGeneratorResult(
            terms=[], error="generator_expr must be non-empty",
        )
    if n <= 0:
        return SampleGeneratorResult(
            terms=[], error=f"n must be positive, got {n}",
        )

    # ATH-552: resolve execution path — explicit docker_image kwarg wins
    # over KAIROS_LAKE_DOCKER_IMAGE env, which falls back to host lake.
    effective_docker_image = docker_image or os.environ.get(
        _LAKE_DOCKER_IMAGE_ENV, "",
    ).strip() or None

    # ATH-557: validate workspace_root is an ancestor of workspace. Fail
    # loud rather than letting the `relative_to` call inside the docker
    # helper raise at the wrong layer with a confusing stack trace.
    workspace_root_path: Path | None = None
    if workspace_root is not None:
        workspace_root_path = Path(workspace_root).resolve()
        if not workspace_root_path.is_dir():
            return SampleGeneratorResult(
                terms=[],
                error=f"workspace_root does not exist: {workspace_root_path}",
            )
        try:
            workspace_path.relative_to(workspace_root_path)
        except ValueError:
            return SampleGeneratorResult(
                terms=[],
                error=(
                    f"workspace_root {workspace_root_path} is not an "
                    f"ancestor of workspace {workspace_path}"
                ),
            )
        if effective_docker_image is None:
            # Host path doesn't need mount manipulation; silently ignore
            # workspace_root rather than fail, but log a warning line so
            # callers notice the kwarg was a no-op.
            import warnings as _warnings
            _warnings.warn(
                "workspace_root passed but docker_image / "
                f"{_LAKE_DOCKER_IMAGE_ENV} not set — host execution "
                "ignores workspace_root. ATH-557.",
                stacklevel=2,
            )

    docker_bin: str | None = None
    if effective_docker_image:
        docker_bin = shutil.which("docker") or shutil.which("podman")
        if docker_bin is None:
            return SampleGeneratorResult(
                terms=[],
                error=(
                    f"docker_image={effective_docker_image!r} requested "
                    "but neither docker nor podman found on PATH."
                ),
            )

    lake_bin: str | None = None
    if effective_docker_image is None:
        lake_bin = shutil.which("lake")
        if lake_bin is None:
            return SampleGeneratorResult(
                terms=[],
                error=(
                    "lake not found on PATH. Install elan "
                    "(https://leanprover.github.io/installation/) "
                    "or pass docker_image= / set "
                    f"{_LAKE_DOCKER_IMAGE_ENV} to use a container."
                ),
            )

    # Build the driver module. Scratch name chosen to be unlikely to
    # collide with a caller's module + safe to reference in the harness.
    driver_name = "_KairosSample"
    driver_path = workspace_path / f"{driver_name}.lean"

    imports_block = f"import {module}\n"
    for extra in (extra_imports or []):
        imports_block += f"import {extra}\n"

    # ATH-561: inline prelude source above main so LLM-written
    # generators compile in the driver's namespace without needing a
    # separate Lake module. The prelude sits between imports and main.
    prelude_block = ""
    if prelude and prelude.strip():
        prelude_block = f"\n-- ATH-561 prelude (caller-supplied)\n{prelude.strip()}\n"

    harness = (
        f"{imports_block}"
        f"{prelude_block}"
        f"\ndef main : IO Unit := do\n"
        f"  let samples : List ({term_type}) ← "
        f"({generator_expr} : IO (List ({term_type})))\n"
        f"  for e in samples.take {n} do\n"
        f"    IO.println (({render_expr}) e)\n"
    )

    try:
        driver_path.write_text(harness)

        # Phase 1: build the target module so its .olean is on disk.
        # `lake env lean --run` does not auto-resolve dependencies;
        # it only loads prebuilt olean outputs.
        if effective_docker_image:
            build_result = _run_lake_in_container(
                workspace=workspace_path,
                docker_bin=docker_bin,  # type: ignore[arg-type]
                docker_image=effective_docker_image,
                shell_cmd=f"lake build {module}",
                timeout_sec=timeout_sec,
                workspace_root=workspace_root_path,
            )
        else:
            build_result = subprocess.run(
                [lake_bin, "build", module],  # type: ignore[list-item]
                cwd=str(workspace_path),
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
        if build_result.returncode != 0:
            combined = f"{build_result.stdout}\n{build_result.stderr}"[:4000]
            return SampleGeneratorResult(
                terms=[],
                stdout_tail=combined,
                error=f"lake build {module} failed (exit={build_result.returncode})",
            )

        # Phase 2: run the harness driver.
        if effective_docker_image:
            run_result = _run_lake_in_container(
                workspace=workspace_path,
                docker_bin=docker_bin,  # type: ignore[arg-type]
                docker_image=effective_docker_image,
                shell_cmd=f"lake env lean --run {driver_name}.lean",
                timeout_sec=timeout_sec,
                workspace_root=workspace_root_path,
            )
        else:
            run_result = subprocess.run(
                [lake_bin, "env", "lean", "--run", f"{driver_name}.lean"],  # type: ignore[list-item]
                cwd=str(workspace_path),
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
        combined = f"{run_result.stdout}\n{run_result.stderr}"
        stdout_tail = combined[-4000:]
        if run_result.returncode != 0:
            return SampleGeneratorResult(
                terms=[],
                stdout_tail=stdout_tail,
                error=(
                    f"lake env lean --run {driver_name}.lean failed "
                    f"(exit={run_result.returncode})"
                ),
            )

        # Parse stdout: each non-empty line is one sample.
        terms = [
            line for line in run_result.stdout.splitlines()
            if line.strip()
        ]
        # Lake may prepend build-log noise before our IO.println lines
        # when the harness depends on freshly-built .oleans. Trim lines
        # that look like lake progress (starting with build markers like
        # `✔`, `ℹ`, or `warning:` / `error:`). We keep lines that don't
        # look like lake chatter.
        _LAKE_NOISE = (
            "✔ ", "ℹ ", "warning:", "error:", "[", "info:",
        )
        terms = [t for t in terms if not any(t.startswith(p) for p in _LAKE_NOISE)]
        return SampleGeneratorResult(
            terms=terms[:n],
            stdout_tail=stdout_tail,
            error="",
        )
    except subprocess.TimeoutExpired:
        return SampleGeneratorResult(
            terms=[],
            error=f"sample_generator timed out ({timeout_sec}s)",
        )
    except Exception as exc:  # noqa: BLE001 — guard returns fallback value on any error
        return SampleGeneratorResult(
            terms=[],
            error=f"sample_generator raised {type(exc).__name__}: {exc}"[:2000],
        )
    finally:
        driver_path.unlink(missing_ok=True)
