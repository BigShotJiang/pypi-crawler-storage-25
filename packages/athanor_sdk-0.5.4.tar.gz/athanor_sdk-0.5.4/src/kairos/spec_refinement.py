"""kairos.spec_refinement -- iterative-VCF spec-refinement wrapper.

ATH-978. Customer-1 / Todd's documented pain point in
#project-annapurna 2026-05-03: *"iteratively refining the spec when
VCF returns spurious counter-examples is the actual day-to-day
cost."*

Per asabi 4-decision-point analysis: the iteration loop is

    SPEC -> VCF -> CEX
                   |
                   v
        ( cex_projection      )
        ( pattern_recognition )
        ( classifier_mutation )
        ( convergence_check   )
                   |
                   v
              proposed spec diff

Athanor's wrapper takes ``(DUT, classifier, vcf_cex)`` and produces
the structured outputs without running formal -- measurement-only
iteration so the per-iteration LLM value can be quantified before
automating the full loop.

Architecture (matches the now-canonical vertical-orchestrator
template across silicon_review / quantization / sparsity / security
/ inference_serving / carbon_aware / model_invariants):

    1. Per-decision-point verdict mapping (projection / pattern /
       diff / convergence each return a structured outcome with a
       verdict in {"resolved", "needs_input", "no_progress",
       "error"}).
    2. Composite precedence (error > no_progress > needs_input >
       resolved; empty list -> error not silent-resolved).
    3. Honest scaffold contract: the proposed_diff body references
       customer-spec-defined identifiers (no ``: True := trivial``
       placeholders; the layer-5 vacuous-proof CI lint enforces).
    4. Source-text + behavioral pins via tests.
    5. Layer-5 cross-cutting CI lint (already in place from ATH-960).
    6. Property-handle ``bool(subset) and all(...)`` guard against
       Python ``all([]) == True`` silent-resolution.

NO formal verifier invocation in v0
-----------------------------------
The wrapper does NOT run VCF / EBMC / Aristotle. Inputs are an
existing cex (from the customer's prior VCF run) plus the customer-
supplied classifier callable; outputs are structured proposals the
customer-or-LLM can act on. v1 may add an integration helper that
re-runs the customer's verifier after applying the proposed diff
to measure convergence; that integration is gated on per-iteration
LLM-value measurement landing first.

Trace event
-----------
``spec_refinement_iteration`` registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Walker-visible emit. Composes with the customer-block certificate
card surface.

Cross-refs
----------
* ATH-978 -- this ticket.
* asabi 4-decision-point analysis in #project-annapurna 2026-05-03.
* :mod:`kairos.silicon_review` -- sibling vertical orchestrator
  pattern.
* ``feedback_no_vacuous_proves_multi_layer.md`` -- 6-layer defense
  template applied to per-decision-point verdict mapping.
"""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# Public verdict enum for each of the 4 decision points + the
# composite. Stays as plain strings for JSON-friendliness with the
# trace-event payload + the customer-block certificate card.
KNOWN_DECISION_POINTS = (
    "cex_projection",        # minimal SV slice that reproduces the cex
    "pattern_recognition",   # cex-class label from the customer classifier
    "classifier_mutation",   # candidate spec diff
    "convergence_check",     # is the proposed diff making progress
)


# Per-decision-point verdict precedence (error > no_progress >
# needs_input > resolved; empty list -> error). Matches the
# composite-precedence pattern from silicon_review / model_invariants
# etc.
_VERDICT_PRECEDENCE = (
    "error",
    "no_progress",
    "needs_input",
    "resolved",
)


@dataclass
class DecisionOutcome:
    """One decision-point's structured outcome."""

    decision_point: str
    """One of :data:`KNOWN_DECISION_POINTS`."""

    verdict: str
    """One of ``error / no_progress / needs_input / resolved``."""

    detail: dict[str, Any] = field(default_factory=dict)
    """Decision-point-specific fields. Convention:
    * ``cex_projection`` -> ``{"projected_slice_path": ...,
       "involved_signals": [...], "max_depth": int}``.
    * ``pattern_recognition`` -> ``{"pattern_class": str,
       "classifier_confidence": float | None}``.
    * ``classifier_mutation`` -> ``{"proposed_diff_text": str,
       "soundness_obligation_list": [str]}``.
    * ``convergence_check`` -> ``{"prior_iteration_count": int,
       "novelty_score": float, "convergence_signal": bool}``.
    """

    elapsed_sec: float = 0.0


@dataclass
class SpecRefinementResult:
    """Composite outcome from one ``refine`` call."""

    composite_verdict: str
    """``error / no_progress / needs_input / resolved``."""

    projected_slice: Path | None
    """Minimal SV slice that contains the cex; ``None`` on error."""

    pattern_class: str | None
    """Classifier-supplied label, or ``None`` if classifier abstained."""

    proposed_diff: str | None
    """Candidate spec edit body, or ``None`` if no progress was made."""

    soundness_obligation_list: list[str] = field(default_factory=list)
    """Obligations the customer must verify if accepting the diff.
    Empty list distinct from ``None``: empty means no obligations
    needed (rare; usually means the wrapper hit no_progress)."""

    decision_outcomes: list[DecisionOutcome] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def all_decisions_resolved(self) -> bool:
        """Property-handle (Layer-6 bool guard): True iff every
        decision-point produced a resolved verdict.

        ``bool(decision_outcomes) and all(...)`` defends against
        Python ``all([]) == True`` silent-resolution -- if no
        decision points ran, this is False, NOT True.
        """
        return bool(self.decision_outcomes) and all(
            o.verdict == "resolved" for o in self.decision_outcomes
        )


def _classify_composite(outcomes: list[DecisionOutcome]) -> str:
    """Layer-2 composite precedence over per-decision-point
    verdicts. Empty list -> error (silent-resolved defense).
    """
    if not outcomes:
        return "error"
    verdicts = {o.verdict for o in outcomes}
    for v in _VERDICT_PRECEDENCE:
        if v in verdicts:
            return v
    return "error"  # unknown verdict shape


# ── Decision-point primitive stubs ───────────────────────────────────
#
# v0 ships structural shape only -- the LLM heavy lifting is a
# future iteration. Each primitive accepts the typed inputs +
# returns a DecisionOutcome with the structured detail dict.
# Customers can override any primitive by passing ``*_fn`` overrides
# to ``refine``; the default implementations below are minimal so
# the wrapper has measurement-mode utility on day one.


def _default_cex_projection(
    *,
    dut_path: Path,
    vcf_cex_path: Path,
) -> DecisionOutcome:
    """Default cex_projection: parse the cex file, extract the set
    of involved signals + the max depth, write a copy of the DUT to
    a sibling ``.projected.sv`` file. v0 returns a needs_input
    verdict if the cex format is unrecognised (the customer should
    supply a custom projection callable).
    """
    t0 = time.monotonic()
    if not vcf_cex_path.is_file():
        return DecisionOutcome(
            decision_point="cex_projection",
            verdict="error",
            detail={"error": f"vcf_cex not found: {vcf_cex_path}"},
            elapsed_sec=time.monotonic() - t0,
        )
    # v0 placeholder: surface the inputs without doing real
    # projection. Real projection requires customer-specific
    # cex-format parsing (VCF / Jasper / SymbiYosys all differ).
    return DecisionOutcome(
        decision_point="cex_projection",
        verdict="needs_input",
        detail={
            "projected_slice_path": str(dut_path),
            "involved_signals": [],
            "max_depth": 0,
            "note": "v0 default: pass projection_fn for custom cex format",
        },
        elapsed_sec=time.monotonic() - t0,
    )


def _default_classifier_mutation(
    *,
    pattern_class: str | None,
) -> DecisionOutcome:
    """Default classifier_mutation: emit a placeholder diff naming
    the pattern_class so the customer or downstream LLM has the
    handle. v0 returns needs_input (no LLM in the wrapper).
    """
    t0 = time.monotonic()
    if pattern_class is None:
        return DecisionOutcome(
            decision_point="classifier_mutation",
            verdict="no_progress",
            detail={
                "proposed_diff_text": "",
                "soundness_obligation_list": [],
                "note": "classifier did not classify the cex",
            },
            elapsed_sec=time.monotonic() - t0,
        )
    return DecisionOutcome(
        decision_point="classifier_mutation",
        verdict="needs_input",
        detail={
            "proposed_diff_text": (
                f"-- ATH-978 v0 placeholder: pattern_class={pattern_class}\n"
                f"-- TODO: customer or LLM proposes the actual spec diff\n"
            ),
            "soundness_obligation_list": [
                f"customer must verify pattern_class={pattern_class} "
                f"diff preserves all prior-proven properties",
            ],
            "note": "v0 default: pass mutation_fn for LLM-driven diff",
        },
        elapsed_sec=time.monotonic() - t0,
    )


def _default_convergence_check(
    *,
    prior_iteration_count: int,
    proposed_diff_text: str,
) -> DecisionOutcome:
    """Default convergence_check: novelty_score is 1.0 if
    prior_iteration_count == 0 (first iteration always novel) and
    0.5 otherwise (placeholder; customer supplies real diff-history
    comparison via convergence_fn).
    """
    t0 = time.monotonic()
    novelty = 1.0 if prior_iteration_count == 0 else 0.5
    return DecisionOutcome(
        decision_point="convergence_check",
        verdict="needs_input",
        detail={
            "prior_iteration_count": prior_iteration_count,
            "novelty_score": novelty,
            "convergence_signal": False,
            "note": "v0 default: pass convergence_fn for diff-history compare",
        },
        elapsed_sec=time.monotonic() - t0,
    )


# ── Public entry point ───────────────────────────────────────────────


def refine(
    *,
    dut_path: str | Path,
    vcf_cex_path: str | Path,
    classifier: Callable[[Path], str | None],
    prior_iteration_count: int = 0,
    projection_fn: Callable[..., DecisionOutcome] | None = None,
    mutation_fn: Callable[..., DecisionOutcome] | None = None,
    convergence_fn: Callable[..., DecisionOutcome] | None = None,
    emit_trace: bool = True,
) -> SpecRefinementResult:
    """Iterative-VCF spec-refinement entry point.

    Per asabi 4-decision-point analysis: runs cex projection ->
    classifier-driven pattern recognition -> proposed diff ->
    convergence check, returning the structured outputs. NO
    formal-verifier invocation in v0 (measurement-only).

    Args:
        dut_path: path to the customer's SV under test.
        vcf_cex_path: path to the VCF / Jasper / SymbiYosys
            counter-example file.
        classifier: customer-supplied callable that takes a
            projected-cex Path and returns a ``pattern_class`` label
            (or ``None`` if the classifier abstains).
        prior_iteration_count: how many prior refine calls have run
            in this customer session. Drives the convergence check.
        projection_fn / mutation_fn / convergence_fn: optional
            customer overrides for the per-decision-point primitives.
            Default implementations return ``needs_input`` verdicts
            so the wrapper has utility on day one without requiring
            customer plumbing.
        emit_trace: if True (default), emit a
            ``spec_refinement_iteration`` event into the active
            kairos.observe context. Honest no-fake-discharge: the
            event payload includes the composite verdict so a
            ``no_progress`` iteration is surfaced in the customer
            dashboard rather than silently elided.

    Returns:
        :class:`SpecRefinementResult` carrying the composite verdict
        + the per-decision-point outcomes.
    """
    dut_p = Path(dut_path)
    cex_p = Path(vcf_cex_path)

    t0 = time.monotonic()

    # 1. cex projection
    proj_fn = projection_fn or (
        lambda: _default_cex_projection(dut_path=dut_p, vcf_cex_path=cex_p)
    )
    proj_outcome = proj_fn()

    # 2. pattern recognition (customer classifier)
    pattern_t0 = time.monotonic()
    pattern_class: str | None
    if proj_outcome.verdict == "error":
        pattern_class = None
        pattern_outcome = DecisionOutcome(
            decision_point="pattern_recognition",
            verdict="no_progress",
            detail={"note": "skipped due to projection error"},
            elapsed_sec=time.monotonic() - pattern_t0,
        )
    else:
        proj_path = Path(
            proj_outcome.detail.get("projected_slice_path", str(dut_p))
        )
        try:
            pattern_class = classifier(proj_path)
            pattern_outcome = DecisionOutcome(
                decision_point="pattern_recognition",
                verdict="resolved" if pattern_class else "needs_input",
                detail={
                    "pattern_class": pattern_class,
                    "classifier_confidence": None,
                },
                elapsed_sec=time.monotonic() - pattern_t0,
            )
        except Exception as exc:  # noqa: BLE001 -- customer callable
            pattern_class = None
            pattern_outcome = DecisionOutcome(
                decision_point="pattern_recognition",
                verdict="error",
                detail={"error": f"classifier raised: {exc}"},
                elapsed_sec=time.monotonic() - pattern_t0,
            )

    # 3. classifier mutation (proposed diff)
    mut_fn = mutation_fn or (
        lambda: _default_classifier_mutation(pattern_class=pattern_class)
    )
    mut_outcome = mut_fn()

    # 4. convergence check
    conv_fn = convergence_fn or (
        lambda: _default_convergence_check(
            prior_iteration_count=prior_iteration_count,
            proposed_diff_text=mut_outcome.detail.get(
                "proposed_diff_text", "",
            ),
        )
    )
    conv_outcome = conv_fn()

    outcomes = [proj_outcome, pattern_outcome, mut_outcome, conv_outcome]
    composite = _classify_composite(outcomes)

    result = SpecRefinementResult(
        composite_verdict=composite,
        projected_slice=Path(
            proj_outcome.detail.get("projected_slice_path", str(dut_p))
        ) if proj_outcome.verdict != "error" else None,
        pattern_class=pattern_class,
        proposed_diff=mut_outcome.detail.get("proposed_diff_text") or None,
        soundness_obligation_list=list(
            mut_outcome.detail.get("soundness_obligation_list", [])
        ),
        decision_outcomes=outcomes,
        total_elapsed_sec=time.monotonic() - t0,
    )

    if emit_trace:
        try:
            # Lazy import for circular-import safety: kairos.observe
            # pulls litellm wrapper machinery + may re-enter this
            # module transitively during init.
            import sys as _sys
            obs = _sys.modules.get("kairos.observe")
            if obs is None:  # pragma: no cover
                from kairos import observe as obs  # type: ignore
            obs.emit(
                "spec_refinement_iteration",
                {
                    "dut_path": str(dut_p),
                    "vcf_cex_path": str(cex_p),
                    "composite_verdict": composite,
                    "pattern_class": pattern_class,
                    "prior_iteration_count": prior_iteration_count,
                    "all_decisions_resolved": result.all_decisions_resolved,
                    "total_elapsed_sec": round(result.total_elapsed_sec, 3),
                },
                silent_if_no_session=True,
            )
        except Exception:  # noqa: BLE001 -- telemetry must not break solve
            pass

    return result


__all__ = [
    "DecisionOutcome",
    "SpecRefinementResult",
    "KNOWN_DECISION_POINTS",
    "refine",
]
