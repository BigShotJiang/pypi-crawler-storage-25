"""kairos.trace_schema — sdk_agent_events body construction, schema gate, and
per-event-type payload registry.

Two concerns, one module (kept together so the ATH-520 CI gate and the
ATH-574 registry can cross-validate):

  * **ATH-520 gate** (unchanged): :func:`build_sdk_agent_event_body` produces
    the wire dict POSTed to ``public.sdk_agent_events``; :func:`load_sdk_agent_events_schema`
    returns the authoritative JSON Schema for the row shape. Checked-in schema
    file is source-of-truth. Round-trip test in
    ``tests/test_sdk_agent_events_schema.py`` catches drift.
  * **ATH-574 registry**: :data:`REGISTRY` maps
    ``(run_subtype, event_type) → Pydantic model`` so emit-time validation
    can check payload shape. :func:`validate_payload` returns
    :class:`ValidationResult` — never raises. Rate-limited WARN logging +
    optional ``KAIROS_STRICT_PAYLOAD_SCHEMA=1`` raise-mode handled inside the
    sink, not here; this module stays side-effect-free.

Zero-data-loss guarantee (Aidan 2026-04-24 06:58Z)
--------------------------------------------------

The registry enforces a schema but NEVER drops events:

1. Default :class:`kairos.trace.SupabaseTraceSink.emit` path — Pydantic
   validation failure logs WARNING and the event still POSTs with payload
   preserved as-is. The sink raises ONLY on HTTP failures (caught by the
   ATH-553 journal); schema mismatches never raise, never drop.
2. Unknown ``(run_subtype, event_type)`` pairs miss the registry — event
   emits with payload unchanged; one-shot ``unknown_event_type`` warning fires
   per ``(session_id, event_type)`` pair.
3. Rate-limit is MAX-3 WARN emissions per ``(session_id, event_type)`` per
   session; violations still counted silently for the session-close summary.
4. ``KAIROS_STRICT_PAYLOAD_SCHEMA=1`` flips validation to raise mode — used
   in CI + dev, never in prod.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from kairos.trace import EscalationEvent, TraceEvent


# ═══════════════════════════════════════════════════════════════════════
# ATH-520 — sdk_agent_events row body + schema helpers (unchanged)
# ═══════════════════════════════════════════════════════════════════════


_SCHEMA_FILENAME = "sdk_agent_events.schema.json"

# Resolve the repo-root schemas/ dir. SDK layout:
#   athanor-sdk/src/kairos/trace_schema.py   ← this file
#   athanor-sdk/schemas/sdk_agent_events.schema.json
_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent.parent / "schemas" / _SCHEMA_FILENAME
)

# ATH-537: solve_run_escalations table schema gate. Companion to the
# sdk_agent_events gate above; same drift-detection pattern.
_ESCALATIONS_SCHEMA_FILENAME = "solve_run_escalations.schema.json"
_ESCALATIONS_SCHEMA_PATH = (
    Path(__file__).resolve().parent.parent.parent
    / "schemas"
    / _ESCALATIONS_SCHEMA_FILENAME
)


def build_sdk_agent_event_body(event: TraceEvent) -> dict[str, Any]:
    """Return the exact dict POSTed to ``public.sdk_agent_events`` for ``event``.

    Mirrors :meth:`kairos.trace.SupabaseTraceSink.emit` — the session_id hoist
    from payload onto the top-level column happens here too. Kept pure so the
    ATH-520 schema-drift test can validate body shape without mocking urllib.

    Caller contract: ``event.payload`` is treated as read-only; a shallow copy
    is made before the hoist. Downstream consumers MUST NOT mutate the returned
    dict — the emit() call treats it as the wire body.

    ATH-818 G2: ``session_id`` is now ALWAYS a top-level key (set to ``None``
    when payload has no session_id), not just when payload carries one.
    PostgREST's bulk INSERT requires uniform keys across every row in the
    batch — pre-fix, mixing events whose payload had session_id (e.g.
    ``predicate_verify_result``) with events whose payload lacked it (e.g.
    ``generator_synthesis_round``) yielded PGRST102 ``All object keys must
    match`` on the batch POST, journalling all events for replay. Now every
    body has the same key set; nullability is preserved by the schema column
    being ``["string", "null"]``.
    """
    body: dict[str, Any] = {
        "id": event.id,
        "run_id": event.run_id,
        "run_type": event.run_type,
        "run_subtype": event.run_subtype,
        "event_type": event.event_type,
        "sequence": event.sequence,
        "payload": dict(event.payload),
    }
    sid = body["payload"].get("session_id")
    body["session_id"] = sid if sid else None
    # ATH-1028 Part A: fleet_agent_role surfaces in the wire body
    # under payload (rather than as a top-level column) so the
    # platform-side schema migration is deferred — same payload-
    # first / hoist-later pattern as ATH-934 engine_versions and
    # ATH-1027 input/output_artifact_uris. Once platform's schema
    # migration adds the column, hoist via _fleet_agent_role_supported()
    # opt-in check (modeled on engine_versions).
    role = getattr(event, "fleet_agent_role", None)
    if role is not None:
        body["payload"]["fleet_agent_role"] = role
    # ATH-1063 Phase 0f: invocation_path surfaces via payload (same
    # payload-first / hoist-later pattern as fleet_agent_role above).
    # Powers /analytics/your-runs/[org_id] chip distinguishing
    # MCP-driven from SDK-direct from CLI.
    invocation_path = getattr(event, "invocation_path", None)
    if invocation_path is not None:
        body["payload"]["invocation_path"] = invocation_path
    return body


def load_sdk_agent_events_schema() -> Mapping[str, Any]:
    """Load the checked-in JSON Schema for ``public.sdk_agent_events`` rows.

    The schema is the source-of-truth for the ATH-520 CI gate. Update it only
    when the server-side table changes — and update the SDK emitter in the
    same PR so the round-trip test stays green.
    """
    with _SCHEMA_PATH.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def build_solve_run_escalation_body(event: EscalationEvent) -> dict[str, Any]:
    """ATH-537: return the exact dict POSTed to ``public.solve_run_escalations``.

    Mirrors :meth:`kairos.trace.SupabaseTraceSink.emit_escalation`. Pure so
    the schema-drift test can validate body shape without mocking urllib.

    Caller contract: ``event.context`` is treated as read-only; a shallow
    copy is made.
    """
    return {
        "id": event.id,
        "run_id": event.run_id,
        "theorem_id": event.theorem_id,
        "trigger": event.trigger,
        "plugin_type": event.plugin_type,
        "context": dict(event.context),
    }


def load_solve_run_escalations_schema() -> Mapping[str, Any]:
    """ATH-537: load the checked-in JSON Schema for
    ``public.solve_run_escalations`` rows. Source-of-truth for the
    ATH-537 CI gate. Update only when the server-side table changes.
    """
    with _ESCALATIONS_SCHEMA_PATH.open("r", encoding="utf-8") as fh:
        return json.load(fh)


# ═══════════════════════════════════════════════════════════════════════
# ATH-574 — per-event-type payload registry
# ═══════════════════════════════════════════════════════════════════════


# Registry schema version. Embedded as ``event_schema_version`` on each
# sdk_agent_events row emitted through SupabaseTraceSink. Bump on breaking
# shape changes; consumers support old versions (forward-compatible).
EVENT_SCHEMA_VERSION = 1


class PayloadSchemaError(Exception):
    """Raised by emit-time validation when ``KAIROS_STRICT_PAYLOAD_SCHEMA=1``.

    Never raised by :func:`validate_payload` itself — that always returns
    :class:`ValidationResult`. The exception is the sink's strict-mode
    conversion.
    """


@dataclass(frozen=True)
class ValidationResult:
    """Outcome of :func:`validate_payload`.

    ``ok=True`` means either the payload validated cleanly against a registered
    model, or the ``(run_subtype, event_type)`` pair was unknown to the
    registry (the caller treats unknown as lenient-pass). ``unknown`` disambiguates
    so the sink can emit the one-shot ``unknown_event_type`` warning.
    """

    ok: bool
    violations: tuple[str, ...] = ()
    unknown: bool = False


class EventEnvelope(BaseModel):
    """Common fields every registered event MUST carry.

    Every registry entry subclasses this. Dashboard consumers render these
    fields uniformly without vertical-specific branching.

    * ``model``: LLM model ID for LLM-call events, tool name for tool_call,
      verifier name (``cbmc`` / ``ebmc`` / ``lean`` / ``verus`` / ``dafny``)
      for verify events.
    * ``tokens_in`` / ``tokens_out``: token counts (LLM-shaped events).
    * ``cost_usd``: per-event cost attribution.
    * ``elapsed_sec``: wall-clock duration.
    * ``tool``: fine-grained tool or subcommand inside a ``model`` family.
    * ``session_id``: parent :class:`kairos.prove.Session` id when the event
      belongs to a grouped orchestration run.
    * ``fleet_agent_role``: ATH-1028 envelope field hoisted by
      :class:`kairos.trace.SupabaseTraceSink` from
      ``KAIROS_FLEET_AGENT_ROLE`` env var. Surfaced as a top-level wire
      column post-migration.
    * ``spawn_reason`` / ``parent_run_id``: ATH-1026 / ATH-1041 observe()
      kwargs cached on ``_ObserveContext`` and stamped on agent_start
      payload (parent_run_id) for tree-render of customer-as-orchestrator.
    * ``outcome_reason`` / ``error``: per-event diagnostic strings
      stamped at error / completion paths in :mod:`kairos.observe`.

    All fields are optional. Not every event has every field. Per-event
    models tighten this by making subsets required.

    Platform PR #412 cross-arm contract test 2026-05-06 surfaced the
    envelope-completeness gap — strict schema export rejected real
    envelope fields (``fleet_agent_role`` first; asabi flagged
    ``spawn_reason`` / ``parent_run_id`` should also be permitted).
    Adding them here lets the strict schema accept them natively
    without per-arm filter-out workarounds.
    """

    model_config = ConfigDict(extra="allow")

    model: str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None
    cost_usd: float | None = None
    elapsed_sec: float | None = None
    tool: str | None = None
    session_id: str | None = None
    fleet_agent_role: str | None = None
    spawn_reason: str | None = None
    parent_run_id: str | None = None
    outcome_reason: str | None = None
    error: str | None = None
    # ATH-1063 Phase 0f: invocation_path tags how the trace event was
    # invoked. "mcp" = call originated from kairos.mcp server tool
    # invocation (engineer's dev agent); "sdk" = direct kairos.* function
    # call from a script / notebook; "cli" = `kairos` terminal command.
    # Powers the platform-side /analytics/your-runs/[org_id] surface
    # that distinguishes engineer-via-MCP from SDK-direct from CLI.
    # Stamped by kairos.observe.observe() context-manager based on the
    # entry-point detection: the wrapping context sets KAIROS_INVOCATION_PATH
    # (or accepts an explicit `invocation_path=` kwarg) and observe()
    # picks it up. None when unset (free-tier observe() without context).
    invocation_path: Literal["mcp", "sdk", "cli"] | None = None


# ── Per-event-type models ────────────────────────────────────────────────
#
# Each model subclasses EventEnvelope. Fields beyond the envelope are the
# distinguishing shape for that event. Add new entries below + a REGISTRY
# line + a test case in tests/test_trace_schema_registry.py.


class _LLMCallSuccess(EventEnvelope):
    """LLM call that returned a response (any vertical)."""

    model: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    elapsed_sec: float


class _LLMCallFailure(EventEnvelope):
    """LLM call that raised or exceeded retries (any vertical)."""

    model: str
    error: str
    elapsed_sec: float


class _ToolCall(EventEnvelope):
    """kairos.observe wrapping any LLM tool call (any vertical)."""

    model: str
    tool: str
    elapsed_sec: float


class _GeneratorSynthesisRound(EventEnvelope):
    """One round of kairos.generator_synthesize iterate-refine loop.

    Emitted by any vertical running the LLM-Lean sampler loop (autoformalize,
    spec_pipeline, generator_synthesis). The registry maps this event_type via
    wildcard so new verticals adopting the primitive pass validation without
    a registry update.

    Required fields kept minimal — ``round`` + ``verdict`` are the only shape
    invariants; proposer/sample_count are commonly present but optional to
    accommodate pre-ATH-550 callers that skipped them.
    """

    round: int
    verdict: str


class _GeneratorSynthesisRunAggregate(EventEnvelope):
    """Session-close aggregate from kairos.generator_synthesize (ATH-563).

    Fields reflect the summary shape emitted at run-close — rounds_total,
    best valid-sample rate, final verdict. Shape intentionally loose — the
    emitter may add new fields without triggering a registry update.
    """

    verdict: str


class _LooseProbe(EventEnvelope):
    """Catch-all for probe / smoke events. These are lightweight "did we
    get here" markers emitted by drivers — shape varies, envelope fields
    cover the metrics that matter. Intentionally free-form so drivers can
    add probe variants without a registry bump.
    """


class _CertPerPropertyVerdict(BaseModel):
    """One per-property entry in `customer_block_certificate_complete`.

    Pinned per ATH-1042 v2.6 cluster meta-rule instance #10-A
    (build-time-pin lift). Platform's CustomerBlockCertificateCard
    + SecVerdictMatrix render this verbatim; drift on either side
    fails CI on both sides.
    """
    model_config = ConfigDict(extra="allow")

    property: str
    verdict: str  # "PROVED-with-assume" | "PROVED-standalone" | "REFUTED" | "REFUTED-carry-over" | "INCONCLUSIVE"
    bridge_invariant: str | None = None
    bridge_label: str | None = None
    diagnostic_class: str | None = None  # e.g. "x_init_aliasing"


class _CertLeanProvesObligation(BaseModel):
    """One per-property Lean theorem reference in
    `customer_block_certificate_complete.lean_proves_obligations`.

    Pinned per ATH-1042 v2.6. The `theorem` field is the fully-qualified
    Lean theorem name (e.g. `Pythia.Hardware.SEC.FifoWidget.bridge*Inv_
    holds_at_every_co_step`). The `status` field carries the human-
    readable disclosure ("PROVED via X" / "stage-1-stub-pending-merge"
    / etc.) that the dashboard renders verbatim.
    """
    model_config = ConfigDict(extra="allow")

    property: str
    theorem: str
    status: str


class _CustomerBlockCertificateComplete(EventEnvelope):
    """ATH-1042 v2.6 — strict shape pin for customer-facing cert event.

    Promoted from `_LooseProbe` per asabi 2026-05-06 cluster-discipline
    meta-rule "runtime-catch → build-time-pin lift" (instance #10-A).
    Platform PR #410 caught a 2-stacked render gap that originated
    from shape divergence between SDK emit and dashboard render
    (legacy obligations.reduce + per_property_verdicts ARRAY-vs-OBJECT).
    This Pydantic model + the Gate 7 build-tarball pre-emit validation
    + the JSON schema export for cross-arm contract test together
    extinguish the failure-class structurally.

    Every customer-facing cert event MUST carry these fields. Optional
    fields (bundle_path, live_render_url) extend the customer-trust
    surface without being load-bearing for render.
    """
    model_config = ConfigDict(extra="allow")

    block_name: str
    verdict_summary: str
    per_property_verdicts: list[_CertPerPropertyVerdict]
    assumption_stack: list[str]
    lean_proves_obligations: list[_CertLeanProvesObligation]
    n_proved: int
    n_refuted: int
    total_properties: int
    discharge_engine: str
    # Optional extensions
    bundle_path: str | None = None
    live_render_url: str | None = None
    n_inconclusive: int = 0
    cert_tarball_path: str | None = Field(
        default=None,
        description="ATH-1101 — absolute path to the kairos cert tarball if one was built for this fire.",
    )
    cert_tarball_sha256: str | None = Field(
        default=None,
        description="ATH-1101 — hex sha256 of the cert tarball file bytes.",
    )
    cert_tarball_size_bytes: int | None = Field(
        default=None,
        description="ATH-1101 — file size of the cert tarball in bytes.",
    )
    cert_tarball_format_version: str | None = Field(
        default=None,
        description="ATH-1101 — cert tarball format version.",
    )


# ── v2.7 closed-loop iteration-arc events (ATH-1053 / ATH-1055) ──────────
#
# 6 strict event-type models for the v2.7 closed-loop area-optimization
# demo. Iteration arc on toy_fifo_chain: propose -> verify -> bridge ->
# verdict -> iteration_complete, with bridge_lean_closed firing when
# Aristotle/Pythia retroactively closes a previously-proposed bridge as
# a kernel-checked Lean theorem.
#
# Source-truth-holder discipline (asabi 2026-05-06 v0.1 sign-off): enum
# values + nullability documented IN the Pydantic model + JSON schema,
# not on a separate doc page that drifts. Platform's RecursiveDecomp-
# Panel iteration-arc renderer scaffolds against the verbatim shape
# below; field names + enum values are the cross-arm contract.
#
# Join key for tree-render: (parent_run_id, iteration_index, sequence).
# `parent_run_id` is envelope-level (ATH-1041 carry-through). `sequence`
# is the TraceEvent top-level wire field (agent_traces.sequence column),
# NOT the payload field. `iteration_index` is the iteration boundary;
# `sequence` orders sub-events within an iteration (e.g. multiple
# bridge_invariant_proposed before settling).


class _TransformationProposed(EventEnvelope):
    """v2.7 iteration-arc: LLM proposer step output for one iteration.

    Fired once per iteration when the closed_loop proposer (ATH-989)
    emits a candidate area-optimization transformation. ``parent_run_id``
    is required (envelope override): it links this event to the v2.7
    root run for tree-render. ``transformation_class`` enum tracks
    `kairos.sec.closed_loop._proposer.TransformationClass` 1:1.
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    transformation_class: Literal["parameterization", "structural", "impl_swap"]
    transformation_description: str
    proposer_model: str
    estimated_area_delta_pct: float | None = None
    parent_run_id: str  # envelope override: required for iteration-arc events
    # ATH-1083 Phase A: effective concrete_for_sec parameter values applied to
    # yosys_elaborate when this transformation was equivalence-checked. Powers
    # the platform-side IterationRow 3-way render: (a) params surfaced verbatim,
    # (b) parameter-free silent, (c) parameterized RTL emit WITHOUT overrides
    # → "(default parameters)" warn-class chip. Surfacing the FIFO_DEPTH=0
    # silently-vacuous class from the dashboard is the architectural lift
    # against the no-vacuous-proves discipline (ATH-1082 lesson).
    parameter_overrides: dict[str, str | int] | None = None
    # Disambiguates the 3-way render: parameter_overrides=None alone can't
    # tell (b) param-free RTL from (c) parameterized RTL with no overrides.
    # rtl_parameter_count = total count of entries in signature.parameters
    # regardless of whether concrete_for_sec is set. Dashboard reads:
    #   count == 0                                       → silent (b)
    #   count > 0 + overrides empty/None                 → full WARN (c)
    #   count > 0 + overrides len < count                → partial WARN
    #   count > 0 + overrides len == count               → verbatim (a)
    # Default 0 stays backwards-compat with legacy v2.7 fixtures.
    rtl_parameter_count: int = 0


class _VerifyAttempt(EventEnvelope):
    """v2.7 iteration-arc: BMC or k-induction discharge attempt.

    Fires when EBMC runs against a proposed transformation. ``engine``
    distinguishes the verifier mode; ``result`` is the per-property
    discharge outcome. ``diagnostic_class`` is set when result=FAIL or
    INCONCLUSIVE; carry-through from v2.6's
    ``customer_block_certificate_complete.per_property_verdicts.diagnostic_class``.
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    engine: Literal[
        "ebmc_bmc", "ebmc_kinduction",
        "yosys_dual_engine", "yosys_equiv", "yosys_equiv_only",
        "yosys_sat_miter", "ebmc_bmc_confirmatory",
        "mock_yosys_equiv", "mock_yosys_dual_engine",
    ]
    bound: int
    result: Literal["PASS", "FAIL", "INCONCLUSIVE", "SETUP_ERROR"]
    diagnostic_class: (
        Literal[
            "x_init_aliasing",
            "missing_inductive_invariant",
            "bmc_counterexample",
            "kinduction_inconclusive",
            "setup_error",
            "verifier_unavailable",
            "yosys_combo_equiv",
            "yosys_combo_refuted",
            "yosys_combo_inconclusive",
            "combo_ebmc_confirmatory",
            "bmc_proved",
            "empty_verdicts",
        ]
        | None
    ) = None
    elapsed_sec: float
    parent_run_id: str


class _BridgeInvariantProposed(EventEnvelope):
    """v2.7 iteration-arc: LLM-proposed bridge invariant for k-induction
    escalation when a `verify_attempt` returned INCONCLUSIVE.

    ``bridge_label`` is the join key shared with later
    ``bridge_lean_closed`` events that retroactively discharge the bridge
    as a Lean theorem. ``lean_theorem_ref`` is set IF the proposer
    already had a known Lean theorem; otherwise None and a future
    ``bridge_lean_closed`` event fills it in.
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    bridge_label: str
    bridge_text: str
    proposer_model: str
    lean_theorem_ref: str | None = None
    parent_run_id: str


class _IterationVerdict(EventEnvelope):
    """v2.7 iteration-arc: per-iteration verdict at the iteration boundary.

    Renamed from `verdict` in shape v0.1 to disambiguate from existing
    `verdict` payload-field usage in other event types (e.g.
    ``tier_verdict``, eqy.py:318). ``outcome`` enum distinguishes
    accepted (final cert claim) from refuted/inconclusive (audit trail).
    ``bridges_used`` lists `bridge_label` values that the iteration
    relied on (join key into ``bridge_invariant_proposed`` events).

    ATH-1063 Phase 0a-wiring: claim-vs-verify pair fields. The proposer
    reports its pre-synth ``area_delta_pct`` estimate; when the yosys
    synth hook (``kairos.synth.yosys_gate_count``) runs the proposed
    gate variant against gold, the resulting verified count + delta
    populate ``verified_gate_count_*`` + ``synth_log_path``. Cert prose
    renders both side-by-side per the chief-architect-grade honest
    framing locked in #dev-sdk slack ts 1778113050. Mismatch between
    claimed and verified is itself a calibration signal worth
    surfacing (>5% absolute gap triggers a tooltip flag in the
    dashboard render).
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    outcome: Literal["accepted", "refuted", "inconclusive", "errored"]
    outcome_reason: str | None = None
    area_delta_pct: float | None = None
    verified_gate_count_delta_gates: int | None = None
    verified_gate_count_delta_pct: float | None = None
    synth_log_path: str | None = None
    bridges_used: list[str] = []
    parent_run_id: str


class _IterationComplete(EventEnvelope):
    """v2.7 iteration-arc: iteration boundary end marker.

    ``halt_reason`` is None when the loop continues to the next
    iteration; set to one of ``OrchestratorHaltReason`` values when the
    closed_loop terminates at this iteration. Enum tracks
    `kairos.sec.closed_loop._orchestrator.OrchestratorHaltReason` 1:1.
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    halt_reason: (
        Literal[
            "proved_equivalent_variant_found",
            "no_proposal_closed",
            "max_iterations",
            "human_review_needed",
        ]
        | None
    ) = None
    parent_run_id: str


class _BridgeLeanClosed(EventEnvelope):
    """v2.7 iteration-arc: retroactive Lean-discharge of a proposed bridge.

    Fires when Aristotle/Pythia closes a previously-proposed bridge as a
    kernel-checked Lean theorem AFTER the original
    ``bridge_invariant_proposed`` event landed. ``iteration_index``
    references the ORIGINAL iteration where the bridge was proposed (not
    the iteration where it was discharged). Dashboard renders this as a
    state-transition badge on the original iteration row (badge swap
    from PROVED-with-assume to PROVED-via-Lean).
    """

    model_config = ConfigDict(extra="allow")

    iteration_index: int
    bridge_label: str  # join key matching bridge_invariant_proposed.bridge_label
    lean_theorem_ref: str  # required: fully-qualified `Pythia.Hardware.SEC.*`
    axiom_audit_clean: bool
    discharge_pr: str | None = None  # citation, e.g. pythia#93
    parent_run_id: str


class _SessionOpen(EventEnvelope):
    """ATH-587: session boundary start — emitted at kairos.session enter.

    Carries the caller-supplied + auto-resolved config snapshot so the
    /solve-runs detail page can render the session setup without reading
    it back from the parent solve_runs row. Required fields are minimal
    so kairos.session callers who omit builder_model / vertical still
    pass validation.
    """

    task_id: str
    vertical: str
    run_type: str
    run_subtype: str


class _SessionClose(EventEnvelope):
    """ATH-587: session boundary end — emitted at kairos.session exit.

    ``status`` mirrors the solve_runs.status value we PATCH to. Aggregate
    stats populate from the session itself, not re-queried from the DB.
    Envelope-level ``cost_usd`` + ``elapsed_sec`` carry the rolled-up
    totals for uniform dashboard rendering.
    """

    task_id: str
    status: str
    prove_count: int
    wall_time_seconds: float


class _RetryAttempt(EventEnvelope):
    """ATH-587 slice B: one-shot summary of a retried emit.

    Emitted exactly once per ``_post_upsert`` invocation that actually
    retried (attempts > 1). Carries the table + attempt count + final
    outcome so dashboards can surface transient-failure patterns without
    correlating retry log lines. Emitted via a dedicated path that
    bypasses the retry loop itself to avoid recursive retries.
    """

    table: str
    attempts: int
    final_status: str  # "success" | "journalled_http" | "journalled_transport"


class _SessionReconciliation(EventEnvelope):
    """ATH-587 slice B: session-close reconciliation outcome.

    Emitted from :meth:`SupabaseTraceSink._reconcile_session` (ATH-585).
    Carries the comparison between in-memory emit counter + DB row count.
    """

    emitted_count: int
    in_db_count: int | None = None  # None when DB unreachable
    status: str  # "matched" | "drift" | "db_unreachable" | "skipped_empty"


class _LeanTPIteration(EventEnvelope):
    """One iteration of kairos.lean theorem-proving loop."""

    iteration: int
    obligations_open: int
    obligations_closed: int
    verdict: str


class _VerusVerify(EventEnvelope):
    """kairos.verus verification attempt (ATH-567)."""

    spec_file: str
    verdict: str
    elapsed_sec: float


class _DafnyVerify(EventEnvelope):
    """kairos.dafny verification attempt (ATH-568)."""

    spec_file: str
    verdict: str
    elapsed_sec: float


class _CBMCCheck(EventEnvelope):
    """kairos.cbmc hardware model-check (ATH-566)."""

    target: str
    verdict: str
    elapsed_sec: float


class _EBMCCheck(EventEnvelope):
    """kairos.ebmc hardware model-check (ATH-566)."""

    target: str
    verdict: str
    elapsed_sec: float


class _SorryAttempt(EventEnvelope):
    """kairos.fleet.orchestrate attempting to close a Lean sorry (ATH-570)."""

    theorem_id: str
    attempt: int


class _SorryClosed(EventEnvelope):
    """kairos.fleet.orchestrate closed a Lean sorry (ATH-570)."""

    theorem_id: str
    attempts_taken: int


class _SorrySkipped(EventEnvelope):
    """kairos.fleet.orchestrate skipped a Lean sorry (ATH-570)."""

    theorem_id: str
    reason: str


class _AristotleDispatched(EventEnvelope):
    """kairos.lean dispatched a tarball to Aristotle (ATH-569)."""

    theorem_id: str
    project_id: str


class _AristotleComplete(EventEnvelope):
    """Aristotle returned a verdict for a previously dispatched theorem
    (ATH-569)."""

    theorem_id: str
    project_id: str
    verdict: str
    elapsed_sec: float


class _SwarmAttempt(EventEnvelope):
    """ATH-625: one per-attempt row from a multi-drafter theorem-proving
    swarm sweep.

    Surfaced 2026-04-25 by research's DSPv2 vllm-int8 sweep. The swarm
    fans out N drafters × K samplers per target, each producing one
    `swarm_attempt` row. Schema captures the dimensions a dashboard
    needs to roll up:

    * `att` — 1-indexed attempt number within the (drafter, sampler) cell
    * `tid` — target id (theorem identifier)
    * `drafter` / `drafter_model` — agent + concrete model id
    * `sampler` — sampling strategy ('temp0.7', 'beam_search', etc.)
    * `swarm_topology` — '4_agent_heterogeneous', '8_agent_homogeneous'
    * `wall_sec` / `closed` — outcome metrics
    * `target_module` — qualifying module ('HowardBridge.Quantization',
      etc.); cross-module sweeps incoming after this run.

    ATH-783 / ATH-784 (2026-04-27): three new optional fields for
    cost rollup + agent-talk capture. All optional with sentinel
    defaults so legacy emit sites stay valid.

    * `prompt_tokens` / `completion_tokens` / `cost_usd` (ATH-783)
      — the litellm response carries these on every attempt; the
      emit site needs to thread them through. The dashboard cost
      rollup at solve_runs close summed `payload->>'cost_usd'`
      across the run's events; pre-fix every value was None and the
      total stayed at $0 even for 200s/$0.05 runs (Aidan-flagged
      via solve_run 1d1b277a 2026-04-27). Optional in the schema so
      emit sites can adopt incrementally; required-in-fact once the
      builder-side emit-site PR lands.
    * `candidate` (ATH-784) — full drafter response with a 4 KB
      cap (truncated payloads carry a "[truncated]" marker at the
      end). Replaces the 300-char `candidate_first_300` truncation
      that cut the model mid-sentence. Old field stays for one
      release as a back-compat alias; emit sites SHOULD populate
      both during the transition window.
    * `prompt_first_4k` (ATH-784) — the prompt the model received,
      same 4 KB cap. Pre-fix only the response was captured;
      reading the dashboard mid-run, you couldn't tell what the
      agent was asked.

    Wheel-side note: the field names match the litellm response
    shape (`prompt_tokens`, `completion_tokens`) so emit sites just
    pass `getattr(resp, '...', 0)` without renaming. `cost_usd`
    matches the canonical solve_runs column name.
    """

    att: int
    tid: str
    drafter: str
    drafter_model: str
    sampler: str
    swarm_topology: str
    wall_sec: float
    closed: bool
    candidate_first_300: str | None = None
    target_module: str | None = None
    # ATH-783: token + cost emit. Optional so emit sites adopt
    # incrementally without breaking the schema-coverage gate.
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    cost_usd: float | None = None
    # ATH-784: capture bump (300-char truncation → 4 KB cap, plus
    # prompt). `candidate_first_300` stays for one release as a
    # back-compat alias; new emit sites populate both.
    candidate: str | None = None
    prompt_first_4k: str | None = None


# ── ATH-587 slice C: verify/generator/lake + prompt invocation events ──


class _PromptBuilt(EventEnvelope):
    """ATH-587 slice C: prompt-assembly boundary event.

    Emitted once per prompt build. ``sha256`` + ``char_count`` + optional
    ``section_count`` let dashboards group identical prompts (diff-replay)
    without storing full prompt text in the events table.
    """

    sha256: str
    char_count: int


class _PredicateVerifyInvocation(EventEnvelope):
    """ATH-587 slice C: kairos.lean.predicate_verify invocation start.

    ``target`` is the dotted module path being verified (e.g.
    ``"CedarMicro.WellTyped"``). Paired with :class:`_PredicateVerifyResult`.
    """

    target: str


class _PredicateVerifyResult(EventEnvelope):
    """ATH-587 slice C: kairos.lean.predicate_verify invocation end.

    ``verdict`` ∈ ``{"holds", "fails", "timeout", "error"}``.
    ``elapsed_sec`` is the wall-clock spent in lake build.
    """

    target: str
    verdict: str
    elapsed_sec: float


class _SampleGeneratorInvocation(EventEnvelope):
    """ATH-587 slice C: kairos.lean.sample_generator invocation start."""

    module: str


class _SampleGeneratorResult(EventEnvelope):
    """ATH-587 slice C: kairos.lean.sample_generator invocation end.

    ``sample_count`` is how many terms the Lake-native sampler returned.
    """

    module: str
    sample_count: int
    elapsed_sec: float


class _LakeBuildInvocation(EventEnvelope):
    """ATH-587 slice C: lake-build invocation start (any caller)."""

    lake_project: str
    module_path: str


class _LakeBuildResult(EventEnvelope):
    """ATH-587 slice C: lake-build invocation end.

    ``exit_code`` 0 → success. ``elapsed_sec`` may be large on cold caches
    (first Mathlib build ≈ 5-10 min).
    """

    lake_project: str
    module_path: str
    exit_code: int
    elapsed_sec: float


class _DifferentialTestTuple(EventEnvelope):
    """One differential-test tuple: same input through two implementations,
    diff the verdicts.

    Generic across verticals (Aidan 2026-04-24 directive: generalize to hw-ebmc
    + neuron NKI customers, not just Cedar). Usage examples:

    * Cedar: ``impl_a_name="cedar-policy"``, ``impl_b_name="cedar-go"``,
      ``input_hashes={"policy": ..., "schema": ..., "request": ...}``.
    * hw-ebmc: ``impl_a_name="ebmc"``, ``impl_b_name="jasper"``,
      ``input_hashes={"rtl": ..., "sva": ...}``, verdicts ``"proved"/"bug"/"unknown"``.
    * neuron NKI: ``impl_a_name="trainium-sim"``, ``impl_b_name="xla-reference"``,
      ``input_hashes={"kernel": ..., "shapes": ...}``, verdicts ``"match"/"mismatch"``.

    ``diff_found=True`` is the bug-finding signal; ``diff_details`` carries
    the human-readable comparison when populated. ``input_hashes`` is an
    open dict so each vertical names its own input shape without a registry
    bump per vertical.
    """

    sample_id: str
    impl_a_name: str  # e.g. "cedar-policy", "ebmc", "trainium-sim"
    impl_a_verdict: str
    impl_a_elapsed_sec: float
    impl_b_name: str  # e.g. "cedar-go", "jasper", "xla-reference"
    impl_b_verdict: str
    impl_b_elapsed_sec: float
    diff_found: bool
    input_hashes: dict[str, str]  # SHA256 per named input artefact
    diff_details: str | None = None  # populated when diff_found=True


# ── Registry map ────────────────────────────────────────────────────────


# Key shape: (run_subtype, event_type). Use ``"*"`` for run_subtype when an
# event_type applies across all verticals.
#
# Lookup order in :func:`validate_payload`:
#   1. Exact (run_subtype, event_type) match.
#   2. Wildcard ("*", event_type) match.
#   3. Unknown — return ValidationResult(ok=True, unknown=True).
REGISTRY: dict[tuple[str, str], type[EventEnvelope]] = {
    ("*", "llm_call_success"): _LLMCallSuccess,
    ("*", "llm_call_failure"): _LLMCallFailure,
    ("*", "tool_call"): _ToolCall,
    ("*", "generator_synthesis_round"): _GeneratorSynthesisRound,
    ("*", "generator_synthesis_run_aggregate"): _GeneratorSynthesisRunAggregate,
    ("*", "probe"): _LooseProbe,
    ("*", "smoke"): _LooseProbe,
    # 2026-04-25: generic run/phase lifecycle markers used across fleet
    # drivers (cedar diff-runner, byte-level baseline, cedar-micro diff).
    # Deliberately permissive via _LooseProbe so drivers stamp arbitrary
    # phase-specific metrics without a schema bump per driver. Each emit
    # still stamps elapsed_sec + phase name in payload for dashboards.
    ("*", "run_start"): _LooseProbe,
    ("*", "run_complete"): _LooseProbe,
    ("*", "phase_start"): _LooseProbe,
    ("*", "phase_complete"): _LooseProbe,
    ("*", "phase_error"): _LooseProbe,
    # ('*', 'differential_test_tuple') is registered with the strict
    # _DifferentialTestTuple model further down (line ~646).  The
    # earlier _LooseProbe entry was dead code (later assignment wins
    # in dict construction); removed during the 2026-05-01 audit pass.
    ("*", "session_open"): _SessionOpen,
    ("*", "session_close"): _SessionClose,
    ("*", "prompt_built"): _PromptBuilt,
    ("*", "predicate_verify_invocation"): _PredicateVerifyInvocation,
    ("*", "predicate_verify_result"): _PredicateVerifyResult,
    ("*", "sample_generator_invocation"): _SampleGeneratorInvocation,
    ("*", "sample_generator_result"): _SampleGeneratorResult,
    ("*", "lake_build_invocation"): _LakeBuildInvocation,
    ("*", "lake_build_result"): _LakeBuildResult,
    ("*", "retry_attempt"): _RetryAttempt,
    ("*", "session_reconciliation"): _SessionReconciliation,
    ("theorem_proving", "lean_tp_iteration"): _LeanTPIteration,
    ("theorem_proving", "verus_verify"): _VerusVerify,
    ("theorem_proving", "dafny_verify"): _DafnyVerify,
    ("theorem_proving", "cbmc_check"): _CBMCCheck,
    ("theorem_proving", "ebmc_check"): _EBMCCheck,
    ("theorem_proving", "aristotle_dispatched"): _AristotleDispatched,
    ("theorem_proving", "aristotle_complete"): _AristotleComplete,
    ("theorem_proving", "swarm_attempt"): _SwarmAttempt,
    ("fleet_orchestration", "sorry_attempt"): _SorryAttempt,
    ("fleet_orchestration", "sorry_closed"): _SorryClosed,
    ("fleet_orchestration", "sorry_skipped"): _SorrySkipped,
    ("*", "differential_test_tuple"): _DifferentialTestTuple,
    # ATH-657 sub-b: refinement-chain dispatch in SpecPipeline.run.
    # Permissive via _LooseProbe — the chain dispatcher emits arbitrary
    # per-hop metadata (lean_module, ebmc_target, outcome, cost_usd)
    # whose shape grows as customers wire new tier plugins. KAIROS_TRACE_
    # STRICT (ATH-647) loud-raises on unknown pairs, so registering them
    # up-front keeps research's dspv2 dogfood + customer EBMC × Lean
    # runs from tripping the gate.
    ("*", "refinement_hop_verdict"): _LooseProbe,
    ("*", "refinement_chain_halted"): _LooseProbe,
    # ATH-818 G1 — the three SpecPipeline event types that emit from
    # `kairos.spec.pipeline.SpecPipeline._emit_trace` (orchestrator pick,
    # per-tier verdict, integrity gate). Permissive via _LooseProbe for
    # the same reason as the refinement-chain entries: payload shape
    # depends on which orchestrator + verifier plugins are active, and
    # we don't want a schema bump every time a plugin author adds a
    # rationale field. Pre-fix every prove --nl run logged
    # `unknown event_type` warnings for these and would have crashed
    # under KAIROS_TRACE_STRICT=1. See ATH-818 G1 for the live
    # evidence run (run_id=e3ee2474-2efc-4f4a-be84-d59e61dde755).
    ("*", "orchestration_choice"): _LooseProbe,
    ("*", "tier_verdict"): _LooseProbe,
    ("*", "integrity_violation"): _LooseProbe,
    # ATH-819 — function input snapshot. Emitted once per tracked SDK
    # helper near function entry; payload carries the canonical
    # `function` name + an `args` dict (helper-specific keys, big
    # strings reduced to {sha256, length, preview_first_300}).
    # Permissive _LooseProbe because each helper's args differ — the
    # render contract is on the platform side, not the schema side.
    # See ATH-819 for the helper-by-helper coverage table.
    ("*", "function_inputs"): _LooseProbe,
    # ATH-841 — default-on emit at SDK boundary.
    # `verify_proof_attempt` fires from kairos.lean.verify_proof on
    # every call, regardless of whether the caller is inside a
    # session/observe block. Permissive shape: payload carries
    # {compiles, has_sorry, sorry_count, score, banned, errors_head,
    #  wall_seconds, lake_mode, module_path, code_preview,
    #  aristotle_project_id?, aristotle_status?}. Customer pattern:
    # `nohup python3 driver.py` with bare verify_proof calls now
    # produces traces by default (auto-bootstrap via default_sink_
    # from_env's waterfall).
    ("*", "verify_proof_attempt"): _LooseProbe,
    # ATH-841 — cycle_prove + lean_orchestrate.race / solve emit
    # default events at boundary. Same permissive shape pattern as
    # verify_proof_attempt.
    ("*", "cycle_prove_attempt"): _LooseProbe,
    ("*", "lean_solve_attempt"): _LooseProbe,
    ("*", "lean_race_attempt"): _LooseProbe,
    # ATH-818 G4 — emitted when an LLM-backed orchestrator
    # (kairos.fleet.Orchestrator) fails to call its model and degrades
    # to DefaultRoundRobinOrchestrator. Surfaces the failure to
    # /solve-runs/[id] so customers see WHY the round-robin tier
    # dispatch happened instead of an LLM-planned one. Permissive
    # _LooseProbe — payload carries primary_model + fallback_to +
    # reason ("<ExcType>: <truncated message>"), but exact reason
    # text varies (key-missing vs network vs JSON-parse failures).
    ("*", "orchestrator_fallback"): _LooseProbe,
    # ATH-851 — kairos.sv.prove verdict snapshot. Emitted once per
    # prove() call (PROVED, REFUTED, UNKNOWN, timed out, or exit-nonzero
    # — the verdict fires regardless of which raise-branch the caller
    # ultimately sees). Payload carries proved/refuted counts, the full
    # property_verdicts map, exit_code + elapsed_sec, and previews of
    # transcript / stderr / counterexample (first 4k each). Permissive
    # _LooseProbe — the platform render contract is on the page side
    # (FunctionInputsView + a future EbmcVerdictView), not the schema
    # side. See ATH-851 for evidence run + the visibility-gap context.
    ("*", "ebmc_verdict"): _LooseProbe,
    # ATH-863 — kairos.sv.cegar per-iteration summary + terminal
    # verdict. Emitted from kairos.sv.cegar.cegar() after the
    # cegar.sh subprocess returns (see _emit_per_iteration_summaries +
    # _emit_to_active_session in kairos.sv.cegar). One
    # `cegar_iteration_summary` per iter dir on disk (carries
    # candidate hypothesis_sv, classification, vacuity_reason,
    # ebmc_proved/refuted, transcript_first_4k); one
    # `cegar_terminated` at the end (terminated_reason, total cost +
    # elapsed, final_spec preview). Permissive _LooseProbe — payload
    # shape will grow as ATH-863 follow-ups add per-stage events
    # (cegar_proposer_call, cegar_vacuity_check) which need the
    # subprocess env-var passthrough that v1 deferred.
    ("*", "cegar_iteration_summary"): _LooseProbe,
    ("*", "cegar_terminated"): _LooseProbe,
    # ATH-871 — Todd CPU refinement proof: orchestrator + enforcement
    # gates + proof obligations + ACL2 + PORT reverse-engineering events.
    ("*", "orchestrate_step"): _LooseProbe,
    ("*", "orchestrate_summary"): _LooseProbe,
    ("*", "enforcement_gates"): _LooseProbe,
    ("*", "proof_obligations"): _LooseProbe,
    ("*", "acl2_proof_result"): _LooseProbe,
    ("*", "acl2_refinement_result"): _LooseProbe,
    ("*", "acl2_refinement_start"): _LooseProbe,
    ("*", "acl2_invariant_import_start"): _LooseProbe,
    ("*", "acl2_invariant_import_result"): _LooseProbe,
    ("*", "acl2_two_module_refinement_start"): _LooseProbe,
    ("*", "acl2_two_module_refinement_result"): _LooseProbe,
    # ATH-913 Mode B: cycle-equivalence under arbitrary input traces.
    # Customer-facing equivalence claim; today drives EBMC k-induction
    # via incremental_cegar (trust root: VL+EBMC).  acl2-fgl variant
    # deferred behind unpacked-array-port blocker.
    ("*", "acl2_cycle_equivalence_start"): _LooseProbe,
    ("*", "acl2_cycle_equivalence_result"): _LooseProbe,
    # incremental_cegar (ATH-907) emits its own family of events.
    # Registered here so live runs of refinement_prove_cycle_equivalence
    # don't trip ATH-574 unknown-event warnings.
    ("*", "cegar_incremental_start"): _LooseProbe,
    ("*", "cegar_incremental_proved"): _LooseProbe,
    ("*", "cegar_incremental_timeout"): _LooseProbe,
    ("*", "cegar_incremental_summary"): _LooseProbe,
    ("*", "cegar_incremental_iter"): _LooseProbe,
    ("*", "ghost_tag_instrumented"): _LooseProbe,
    # ATH-908 Pattern 1: cegar/loop.py emits one event per accepted
    # invariant.  Payload follows the EbmcInvariant dataclass shape
    # so kairos.acl2.import_ebmc_invariants_from_events can replay
    # them through the FGL refinement proof.
    ("*", "cegar_invariant_accepted"): _LooseProbe,
    # ATH-912 declarative flows: flow_config emitted at session open
    # carries the full inline YAML so a recorded run is reproducible
    # without trusting the registry hasn't drifted.  Single ('*', ...)
    # entry; the cascade's run_subtype groups the event naturally on
    # the analytics page (matches asabi's 2026-05-01 ruling).
    ("*", "flow_config"): _LooseProbe,
    # ATH-914 Phase 2: pre-flight contract violation surfaced when a
    # cascade's step input shape can't be satisfied by the entry ctx
    # union prior steps' outputs.  Cascade may abort or warn-and-
    # continue depending on caller config.
    ("*", "flow_contract_violation"): _LooseProbe,
    # ATH-932: caught by emit-to-registry gate on first run.
    ("*", "mutation_test_result"): _LooseProbe,
    ("*", "diff_test_result"): _LooseProbe,
    ("*", "acl2_invariant_import_skipped"): _LooseProbe,
    ("*", "counterexample_explanation"): _LooseProbe,
    ("*", "ncs_control_verify"): _LooseProbe,
    ("*", "ncs_compute_verify"): _LooseProbe,
    ("*", "ncs_composition_verified"): _LooseProbe,
    # PureRTL methodology (Todd / asabi 2026-05-01).  Registered ahead of
    # implementation so emit() during scaffolding does not warn.  Events
    # group cleanly under the pure_rtl_* prefix on the analytics page.
    ("*", "pure_rtl_clash_codegen"): _LooseProbe,
    ("*", "pure_rtl_eqy_verify"): _LooseProbe,
    ("*", "pure_rtl_slec_verify"): _LooseProbe,
    ("*", "pure_rtl_lean_extraction"): _LooseProbe,
    ("*", "pure_rtl_optimization_proposal"): _LooseProbe,
    # ATH-944 round-trip orchestrator (qa 2026-05-03): composite event
    # carrying the codegen verdict + eqy equivalence verdict + total
    # wall-clock for one round-trip pass on a single block.
    ("*", "pure_rtl_roundtrip_complete"): _LooseProbe,
    # ATH-947 SV→Lean extraction (qa 2026-05-03): per-iteration verdicts
    # (each LLM round + gate 1 + gate 2 outcomes) and the composite
    # extraction-complete event carrying the final verdict + chosen spec.
    ("*", "pure_rtl_lean_extraction_iter"): _LooseProbe,
    ("*", "pure_rtl_lean_extraction_complete"): _LooseProbe,
    # ATH-951 silicon_review orchestrator (qa 2026-05-03 / Bet E W1
    # anchor): composite event combining pure_rtl + ebmc + acl2
    # per-engine verdicts into a tape-out-ready boolean. Front-door
    # pitch artifact for Annapurna leadership demo.
    ("*", "silicon_review_complete"): _LooseProbe,
    # ATH-958 model_invariants orchestrator (qa 2026-05-03 / Bet H
    # scaffold): per-invariant verdicts (attention permutation
    # equivariance, LayerNorm scale-invariance, RoPE compositional)
    # composing on Pythia matrix-theory primitives + verify_proof.
    # Compounds with kairos.quantization for the Annapurna pitch
    # claim "attention is invariant + quantized gradients have
    # bounded bias."
    ("*", "model_invariants_complete"): _LooseProbe,
    # ATH-959 sparsity orchestrator (qa 2026-05-03 / Bet F scaffold):
    # per-invariant verdicts (L1/L2 norm preservation, weight
    # concentration, sparsity target achieved) composing on
    # Pythia.MatchingConstants + Pythia.MatrixBernstein for v0.
    # PAC-Bayes accuracy bound deepens when asabi's Pythia.PACBayes
    # work-stream lands.
    ("*", "sparsity_verify_complete"): _LooseProbe,
    # ATH-955 quantization correctness (platform 2026-05-03 / Bet B):
    ("*", "quantization_correctness_certificate"): _LooseProbe,
    # ATH-962 security orchestrator (qa 2026-05-03 / Bet J scaffold):
    # per-invariant verdicts (constant-time execution, cache-line
    # invariance, no-secret-dependent-branch) composing on
    # Pythia.SideChannel parallel research-track stub from asabi's
    # Q3 W1-W6 work. AWS confidential ML inference makes this a
    # customer-visible product surface.
    ("*", "security_verify_complete"): _LooseProbe,
    # ATH-964 inference_serving orchestrator (qa 2026-05-03 / Bet G
    # scaffold): per-invariant verdicts (tail_latency_bounded,
    # kv_cache_consistency, continuous_batching_causality,
    # speculative_decoding_equivalence, request_isolation,
    # replica_consistency) composing on Pythia.MatrixBernstein for
    # latency-tail concentration. Joint-claim with model_invariants:
    # "tail latency bounded + served model invariant."
    ("*", "inference_serving_verify_complete"): _LooseProbe,
    # ATH-965 carbon_aware orchestrator (qa 2026-05-03 / Bet I scaffold):
    # per-invariant verdicts (power_envelope_bounded,
    # energy_accuracy_pareto_frontier, carbon_cost_bounded,
    # thermal_safe, throttle_correctness) composing on
    # Pythia.PowerAnalysis (shipped, h_slack quantization-transport
    # bounds). Joint claim: "training schedule provably within ε of
    # energy-accuracy Pareto-frontier."
    ("*", "carbon_aware_verify_complete"): _LooseProbe,
    # ATH-979 -- end-to-end demo driver emits a single
    # customer_block_certificate_complete event per discharge run
    # with the full obligations array + certificate language +
    # toolchain status as payload. Powers the per-run-keyed
    # /analytics/silicon-blocks/[run_id] route on the dashboard
    # (filtered by run_id + event_type). One event per run.
    ("*", "customer_block_certificate_complete"): _CustomerBlockCertificateComplete,
    # ATH-1053 / ATH-1055 — v2.7 closed-loop area-optimization iteration
    # arc. Six event types pin the propose-verify-bridge-verdict-complete
    # cycle on toy_fifo_chain. bridge_lean_closed fires on retroactive
    # Aristotle/Pythia closure of a previously-proposed bridge as a
    # kernel-checked Lean theorem. Source-truth-holder pin: dashboard
    # iteration-arc renderer scaffolds against the verbatim shapes
    # below; field names + enum values are the cross-arm contract.
    ("*", "transformation_proposed"): _TransformationProposed,
    ("*", "verify_attempt"): _VerifyAttempt,
    ("*", "bridge_invariant_proposed"): _BridgeInvariantProposed,
    ("*", "iteration_verdict"): _IterationVerdict,
    ("*", "iteration_complete"): _IterationComplete,
    ("*", "bridge_lean_closed"): _BridgeLeanClosed,
    # ATH-1077 Phase B — kairos.sec.smoke.smoke_validate emits one
    # kairos_smoke_validation_complete event per call when fired
    # inside an observe() context. Payload is the SmokeValidationResult
    # dict (overall + steps + remediation). Powers the platform-side
    # KairosSmokeValidationPanel above the iteration arc on
    # /analytics/silicon-blocks/[run_id]. Loose-probe envelope; the
    # detailed schema lives at schemas/kairos_smoke_validation.schema.json
    # for cross-arm contract validation.
    ("*", "kairos_smoke_validation_complete"): _LooseProbe,
    # ATH-890 / Bet A -- kairos.nki.run_bundle emits one
    # nki_kernel_verified event per catalog-bundle verification run
    # with the verdict triple (outcome/source/reason) + bundle path
    # + per-report pass flags + exit code. Powers the NKI counter on
    # the Verification Coverage card (filtered by vertical=neuron_nki
    # and event_type). One event per run.
    ("*", "nki_kernel_verified"): _LooseProbe,
    # ATH-983 / SEC harness — kairos.sec.run_sec_bundle emits one
    # sec_block_verified event per bundle verification with the
    # dual-mode (BMC + k_induction) verdict triple per primary
    # output. Powers the v2 silicon-block per-block dashboard render
    # post-Todd-pivot.
    ("*", "sec_block_verified"): _LooseProbe,
    ("theorem_proving", "optimization_result_saved"): _LooseProbe,
    # ATH-1025 — canonical agent-arc events emitted by every kairos
    # pipeline that opens a kairos.observe.observe() context.
    # agent_start fires at session begin; pipeline_complete fires
    # at session end with outcome=succeeded/failed. agent_handoff
    # fires at every cross-pipeline transition (e.g. closed_loop
    # calling invariant_gen). agent_message is for cross-agent
    # prose between fleet agents (qa->cto via agent-msg, etc).
    # Closes platform's 1-of-600 emit ratio per ATH-1024 audit.
    ("*", "agent_start"): _LooseProbe,
    ("*", "agent_handoff"): _LooseProbe,
    ("*", "pipeline_complete"): _LooseProbe,
    # ATH-1028 Part B — agent-msg CLI + slack-cto-bot emit
    # fleet_agent_message TraceEvents on cross-agent Slack posts.
    # Payload: from_role / to_role / channel / thread_ts / content
    # (truncated to 4 KiB) / content_full_length / message_kind.
    # Powers the dashboard's cross-agent coordination timeline at
    # the run level.
    ("*", "fleet_agent_message"): _LooseProbe,
    # ATH-978 -- kairos.spec_refinement.refine emits one
    # spec_refinement_iteration event per call. Payload carries the
    # composite verdict + per-decision-point outcomes (cex_projection,
    # pattern_recognition, classifier_mutation, convergence_check)
    # so the customer-block certificate card surfaces no_progress /
    # needs_input iterations honestly rather than silently eliding.
    ("*", "spec_refinement_iteration"): _LooseProbe,
    # ATH-575 coverage gate ratchet (qa 2026-05-03): production-observed
    # events (autoformalize / differential_test / theorem_proving) that
    # were emitting without a REGISTRY entry. Wildcard since the same
    # event_type lands under all three run_subtypes per the coverage
    # report on PR #426 CI run.
    ("*", "tactic_vocabulary_entropy"): _LooseProbe,
    ("*", "statement_hash"): _LooseProbe,
    ("*", "port_reverse_engineer"): _LooseProbe,
    ("*", "port_states_extracted"): _LooseProbe,
    ("*", "port_operations_extracted"): _LooseProbe,
    ("*", "port_ports_extracted"): _LooseProbe,
    ("*", "port_conflicts_derived"): _LooseProbe,
    ("*", "agent_message"): _LooseProbe,
    ("*", "flatten_result"): _LooseProbe,
    ("*", "proof_summary"): _LooseProbe,
    ("*", "customer_block_certificate_complete"): _CustomerBlockCertificateComplete,
    # ATH-989 / closed-loop invariant generation (qa 2026-05-05): emitted
    # by kairos.sec.closed_loop._invariant_gen.generate_invariant inside
    # observe(). _start carries the proposer model + module under test;
    # _attempt carries the per-attempt prompt + draft preview;
    # _result carries verdict (accepted | rejected | timeout) + the
    # accepted invariant text on success. Permissive _LooseProbe — payload
    # shape will grow as the closed-loop arc adds vacuity-check + ebmc
    # bridge stages.
    ("*", "invariant_gen_start"): _LooseProbe,
    ("*", "invariant_gen_attempt"): _LooseProbe,
    ("*", "invariant_gen_result"): _LooseProbe,
    # ATH-1087 Phase B — kairos.sec.closed_loop.mine_assumptions emits one
    # assumption_mining_complete event per call when fired inside an
    # observe() context. Payload is the AssumptionMiningResult.to_dict()
    # output (bundle_path, target_module, model, max_assertions,
    # max_inner_retries, k_bound, proved/refuted/inconclusive/parse_errors
    # arrays, elapsed_sec_total, timestamp). Powers the platform-side
    # AssumptionsMinedSection per ATH-1079 delta 2. Loose-probe envelope;
    # the detailed schema lives at
    # schemas/kairos_assumption_mining_complete.schema.json (flex) and
    # schemas/kairos_assumption_mining_complete.strict.schema.json (strict)
    # for cross-arm contract validation.
    # PAID-tier: mine_assumptions makes LLM calls + EBMC subprocess calls.
    ("*", "assumption_mining_complete"): _LooseProbe,
}


def validate_payload(
    run_subtype: str,
    event_type: str,
    payload: Mapping[str, Any],
) -> ValidationResult:
    """Validate ``payload`` against the registered model for
    ``(run_subtype, event_type)``.

    Never raises. Returns:

    * ``ValidationResult(ok=True)`` — payload matches a registered model.
    * ``ValidationResult(ok=False, violations=(...,))`` — registered model
      rejected the payload. Violations are human-readable strings summarising
      each Pydantic error.
    * ``ValidationResult(ok=True, unknown=True)`` — no registry entry for the
      pair; caller should treat as pass-through and emit a one-shot
      ``unknown_event_type`` warning at most once per session.

    Wildcard lookup: if the exact ``(run_subtype, event_type)`` key misses,
    falls back to ``("*", event_type)`` before declaring unknown.
    """
    model_cls = REGISTRY.get((run_subtype, event_type)) or REGISTRY.get(
        ("*", event_type)
    )
    if model_cls is None:
        return ValidationResult(ok=True, unknown=True)
    try:
        model_cls(**dict(payload))
    except ValidationError as exc:
        violations = tuple(_summarise_error(e) for e in exc.errors())
        return ValidationResult(ok=False, violations=violations)
    return ValidationResult(ok=True)


def _summarise_error(err: Mapping[str, Any]) -> str:
    """Flatten a Pydantic error dict into a one-line human summary."""
    loc = ".".join(str(p) for p in err.get("loc", ()))
    msg = err.get("msg", "")
    return f"{loc}: {msg}" if loc else msg


# ── Rate-limited warn bookkeeping ────────────────────────────────────────


@dataclass
class SessionValidationState:
    """Per-session bookkeeping for rate-limited warn + session-close summary.

    Owned by the sink. One instance per active session. On session close the
    sink reports ``total_violations`` so no violation count is lost even after
    the WARN rate-limit kicks in.
    """

    # (session_id, event_type) → count of WARN emissions already logged
    warn_counts: dict[tuple[str, str], int] = field(default_factory=dict)
    # (session_id, event_type) → count of violations seen (warned + silent)
    total_violations: dict[tuple[str, str], int] = field(default_factory=dict)
    # (session_id, event_type) → True once the unknown-event warn has fired
    unknown_warned: set[tuple[str, str]] = field(default_factory=set)

    max_warns_per_pair: int = 3

    def should_warn(self, session_id: str, event_type: str) -> bool:
        """Return True if a WARN should fire (under rate limit).

        Always increments the total-violations counter. Increments the warn
        count only when the WARN is allowed. Callers MUST call this before
        logging so the bookkeeping stays consistent.
        """
        key = (session_id, event_type)
        self.total_violations[key] = self.total_violations.get(key, 0) + 1
        warned = self.warn_counts.get(key, 0)
        if warned < self.max_warns_per_pair:
            self.warn_counts[key] = warned + 1
            return True
        return False

    def should_warn_unknown(self, session_id: str, event_type: str) -> bool:
        """Return True the first time an unknown (run_subtype, event_type)
        pair is seen for this session; False thereafter.
        """
        key = (session_id, event_type)
        if key in self.unknown_warned:
            return False
        self.unknown_warned.add(key)
        return True

    def close_summary(self) -> list[str]:
        """Return one summary line per (session_id, event_type) that had
        violations, suitable for logging at session close. Empty list when
        no violations fired.
        """
        lines: list[str] = []
        for (session_id, event_type), total in self.total_violations.items():
            warned = self.warn_counts.get((session_id, event_type), 0)
            silent = total - warned
            lines.append(
                f"session={session_id} event_type={event_type} "
                f"violations_total={total} warned={warned} silent={silent}"
            )
        return lines


__all__ = [
    # ATH-520 helpers
    "build_sdk_agent_event_body",
    "load_sdk_agent_events_schema",
    # ATH-537 helpers
    "build_solve_run_escalation_body",
    "load_solve_run_escalations_schema",
    # ATH-574 registry
    "EVENT_SCHEMA_VERSION",
    "EventEnvelope",
    "REGISTRY",
    "ValidationResult",
    "PayloadSchemaError",
    "SessionValidationState",
    "validate_payload",
]
