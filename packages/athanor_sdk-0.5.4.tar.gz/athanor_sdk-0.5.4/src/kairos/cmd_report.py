"""ATH-680 — `kairos report <run_id>` local HTML report renderer.

Reads a per-run on-disk directory written by
:class:`kairos.local_output.LocalOutputDir` (ATH-681 / §4 of the
tier-model doc) and renders a single-page HTML report.

## Layout consumed

    ~/.athanor/runs/<run_id>/
    ├── manifest.json    — run metadata
    ├── traces.jsonl     — per-event timeline
    ├── generated/       — SVA / Lean / refutation artefacts
    │   ├── sva/
    │   ├── lean/
    │   └── ...
    ├── ebmc/            — raw EBMC stdout/stderr per call
    └── lake/            — raw lake build output for Lean tasks

## Usage

    kairos report <run_id>                      # writes ./<run_id>.html
    kairos report <run_id> --out report.html
    kairos report <run_id> --open               # also opens in browser

## Tier classification

Free. The renderer is pure-stdlib (``string.Template`` + inline CSS,
no external deps). No license gate.
"""
from __future__ import annotations

import argparse
import html
import json
import string
import sys
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_TEMPLATE_PATH = (
    Path(__file__).resolve().parent / "_templates" / "report.html.tmpl"
)


# ── Layout reads (resilient to missing pieces per ATH-680 acceptance) ─


def _read_manifest(run_dir: Path) -> dict[str, Any]:
    """Read ``manifest.json``. Returns ``{}`` on any failure — manifest
    is optional (a partially-written run might lack it)."""
    p = run_dir / "manifest.json"
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _read_events(run_dir: Path) -> list[dict[str, Any]]:
    """Read ``traces.jsonl``. Skips unparseable lines (logs a count to
    stderr) so a partial-write doesn't tank the whole report."""
    p = run_dir / "traces.jsonl"
    if not p.is_file():
        return []
    events: list[dict[str, Any]] = []
    bad_lines = 0
    try:
        with p.open(encoding="utf-8") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    bad_lines += 1
    except OSError:
        return []
    if bad_lines:
        print(
            f"warn: skipped {bad_lines} unparseable line(s) in "
            f"{p.name}", file=sys.stderr,
        )
    return events


def _list_artefacts(run_dir: Path) -> dict[str, list[Path]]:
    """Return a mapping of category → sorted file paths under
    ``generated/<category>/``. Empty dict when the dir is absent."""
    base = run_dir / "generated"
    if not base.is_dir():
        return {}
    out: dict[str, list[Path]] = {}
    for cat_dir in sorted(p for p in base.iterdir() if p.is_dir()):
        files = sorted(p for p in cat_dir.rglob("*") if p.is_file())
        if files:
            out[cat_dir.name] = files
    return out


def _list_subprocess_dir(run_dir: Path, kind: str) -> list[Path]:
    """List files under ``<run_dir>/<kind>/`` (``ebmc`` or ``lake``)."""
    base = run_dir / kind
    if not base.is_dir():
        return []
    return sorted(p for p in base.iterdir() if p.is_file())


# ── HTML rendering helpers ───────────────────────────────────────────


def _verdict_class(value: Any) -> str:
    """Map a manifest verdict / status string to a CSS class."""
    s = str(value or "").lower()
    if s in ("proved", "succeeded", "passed", "ok"):
        return "verdict-proved"
    if s in ("failed", "error", "refuted"):
        return "verdict-failed"
    return "verdict-unknown"


def _render_metadata_cards(manifest: dict[str, Any]) -> str:
    """Render manifest as a grid of meta-cards. Stable card set: the
    ATH-681 §4 schema (run_id, started_at, finished_at, total_cost_usd,
    outcome, tier, license_subject) plus any extras present."""
    canonical_order = (
        "run_id", "started_at", "finished_at",
        "total_cost_usd", "outcome", "status",
        "tier", "license_subject", "vertical",
    )
    seen: set[str] = set()
    cards: list[str] = []
    for key in canonical_order:
        if key in manifest:
            cards.append(_meta_card(key, manifest[key]))
            seen.add(key)
    # Surface any extras not in the canonical set.
    for key in sorted(manifest.keys()):
        if key in seen:
            continue
        cards.append(_meta_card(key, manifest[key]))
    if not cards:
        cards.append(
            '<div class="meta-card"><div class="label">manifest</div>'
            '<div class="value empty">(no manifest.json found)</div></div>'
        )
    return "\n".join(cards)


def _meta_card(label: str, value: Any) -> str:
    """One metadata card. Verdict-shaped values get a color class."""
    cls = ""
    if label in ("outcome", "status", "verdict"):
        cls = f" {_verdict_class(value)}"
    val = (
        json.dumps(value, default=str, indent=2)
        if isinstance(value, (dict, list))
        else str(value)
    )
    return (
        f'    <div class="meta-card">'
        f'<div class="label">{html.escape(label)}</div>'
        f'<div class="value{cls}">{html.escape(val)}</div></div>'
    )


def _render_events_section(events: list[dict[str, Any]]) -> str:
    """Render the per-event timeline. session_open / session_close
    sequences (sentinel 999999) get the boundary styling that
    /solve-runs/[id] uses (ATH-672)."""
    if not events:
        return '<div class="empty">(no events recorded)</div>'
    rows: list[str] = ['<div class="events">']
    for ev in events:
        seq = ev.get("sequence")
        event_type = str(ev.get("event_type") or "?")
        is_close = event_type == "session_close"
        is_open = event_type == "session_open"
        if is_close:
            seq_label = "end"
            seq_cls = "boundary"
        elif is_open:
            seq_label = "start"
            seq_cls = "boundary"
        else:
            seq_label = f"#{seq if seq is not None else '?'}"
            seq_cls = ""
        payload = ev.get("payload") or {}
        payload_text = ""
        if isinstance(payload, dict) and payload:
            payload_text = json.dumps(payload, default=str, indent=2)
        rows.append(
            f'  <div class="event-row">\n'
            f'    <div class="event-seq {seq_cls}">{html.escape(seq_label)}</div>\n'
            f'    <div>\n'
            f'      <div class="event-type">{html.escape(event_type)}</div>\n'
            + (
                f'      <pre class="event-payload">{html.escape(payload_text)}</pre>\n'
                if payload_text else ""
            )
            + '    </div>\n  </div>'
        )
    rows.append("</div>")
    return "\n".join(rows)


def _render_artefacts_section(
    artefacts: dict[str, list[Path]], run_dir: Path,
) -> str:
    """Render generated/ as collapsible <details> blocks per category."""
    if not artefacts:
        return '<div class="empty">(no artefacts under generated/)</div>'
    blocks: list[str] = []
    for category, files in artefacts.items():
        for f in files:
            rel = f.relative_to(run_dir).as_posix()
            content = _read_file_safe(f)
            blocks.append(
                f'<details>\n'
                f'  <summary>{html.escape(category)} — {html.escape(rel)}'
                f' <span style="color:var(--fg-dim)">'
                f'({len(content)} bytes)</span></summary>\n'
                f'  <pre>{html.escape(content)}</pre>\n'
                f'</details>'
            )
    return "\n".join(blocks)


def _render_subprocess_section(files: list[Path], run_dir: Path) -> str:
    """Render ebmc/ or lake/ files as collapsible <details> blocks."""
    if not files:
        return '<div class="empty">(no outputs)</div>'
    blocks: list[str] = []
    for f in files:
        rel = f.relative_to(run_dir).as_posix()
        content = _read_file_safe(f)
        blocks.append(
            f'<details>\n'
            f'  <summary>{html.escape(rel)} '
            f'<span style="color:var(--fg-dim)">'
            f'({len(content)} bytes)</span></summary>\n'
            f'  <pre>{html.escape(content)}</pre>\n'
            f'</details>'
        )
    return "\n".join(blocks)


def _read_file_safe(p: Path, max_bytes: int = 200_000) -> str:
    """Read a file with a size cap so a multi-MB log doesn't bloat the
    HTML report. Truncated reads carry a marker line at the end."""
    try:
        data = p.read_bytes()
    except OSError as e:
        return f"(read failed: {e})"
    truncated = len(data) > max_bytes
    if truncated:
        data = data[:max_bytes]
    try:
        text = data.decode("utf-8", errors="replace")
    except UnicodeDecodeError:
        return "(binary file; not rendered)"
    if truncated:
        text += (
            f"\n\n[truncated; showing first {max_bytes} of "
            f"{p.stat().st_size} bytes]"
        )
    return text


# ── Top-level render ─────────────────────────────────────────────────


def render_report(run_dir: Path, run_id: str) -> str:
    """Render an HTML report from a populated run directory.

    Resilient to missing optional sections — manifest.json,
    traces.jsonl, generated/, ebmc/, lake/ are all optional. An
    entirely empty run dir produces a report with empty sections,
    not an error.
    """
    template = _TEMPLATE_PATH.read_text(encoding="utf-8")
    manifest = _read_manifest(run_dir)
    events = _read_events(run_dir)
    artefacts = _list_artefacts(run_dir)
    ebmc_files = _list_subprocess_dir(run_dir, "ebmc")
    lake_files = _list_subprocess_dir(run_dir, "lake")
    subs = {
        "RUN_ID": html.escape(run_id),
        "METADATA_CARDS": _render_metadata_cards(manifest),
        "EVENTS_SECTION": _render_events_section(events),
        "ARTEFACTS_SECTION": _render_artefacts_section(artefacts, run_dir),
        "EBMC_SECTION": _render_subprocess_section(ebmc_files, run_dir),
        "LAKE_SECTION": _render_subprocess_section(lake_files, run_dir),
        "GENERATED_AT": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    return string.Template(template).safe_substitute(subs)


# ── CLI ──────────────────────────────────────────────────────────────


def cmd_report(args: argparse.Namespace) -> int:
    """``kairos report <run_id>`` entry. Returns shell exit code."""
    run_id = args.run_id
    from kairos.local_output import get_run_dir

    run_dir = get_run_dir(run_id)
    if not run_dir.is_dir():
        print(
            f"error: run directory not found: {run_dir}\n"
            f"hint: kairos report reads from ~/.athanor/runs/<run_id>/ "
            f"(override via KAIROS_LOCAL_OUTPUT_DIR).",
            file=sys.stderr,
        )
        return 2

    out_path = (
        Path(args.out) if args.out else Path.cwd() / f"{run_id}.html"
    )
    try:
        html_text = render_report(run_dir, run_id)
    except Exception as e:  # noqa: BLE001
        print(f"error: render failed: {e}", file=sys.stderr)
        return 1

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html_text, encoding="utf-8")
    print(f"wrote report: {out_path}")

    if args.open_browser:
        try:
            webbrowser.open(out_path.resolve().as_uri())
        except Exception as e:  # noqa: BLE001
            # Don't fail the command on a missing GUI / no $BROWSER.
            print(f"warn: could not open browser: {e}", file=sys.stderr)
    return 0


def add_subparser(sub: argparse._SubParsersAction) -> None:
    """Register ``report`` on a top-level subparsers action."""
    p = sub.add_parser(
        "report",
        help="Render a single-page HTML report for one run (free tier).",
    )
    p.add_argument(
        "run_id",
        help="Run id — directory name under ~/.athanor/runs/.",
    )
    p.add_argument(
        "--out", default=None,
        help="Output HTML path. Default: ./<run_id>.html.",
    )
    p.add_argument(
        "--open", action="store_true", dest="open_browser",
        help="Open the rendered report in the default browser after writing.",
    )


__all__ = [
    "add_subparser",
    "cmd_report",
    "render_report",
]
