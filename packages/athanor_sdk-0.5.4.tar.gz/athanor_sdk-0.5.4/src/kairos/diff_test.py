"""kairos.diff_test — differential testing across two implementations.

ATH-885: run N generated test cases across two implementations,
compare outputs. Generalizes the Cedar diff-fleet pattern to any
pair of implementations.

Paid tier — uses LLM for test generation.

Usage::

    from kairos.diff_test import diff_test

    result = diff_test(
        impl_a="cpu_single_issue.sv",
        impl_b="cpu_pipelined.sv",
        generator="random_programs",
    )
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class DiffCase:
    """A single differential test case."""
    input_data: str
    output_a: str
    output_b: str
    match: bool
    case_id: int = 0


@dataclass
class DiffTestResult:
    """Result of differential testing."""
    cases: list[DiffCase] = field(default_factory=list)
    total: int = 0
    matches: int = 0
    mismatches: int = 0
    elapsed_sec: float = 0.0
    verification_status: str = "machine_verified"

    @property
    def all_match(self) -> bool:
        return self.mismatches == 0 and self.total > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "matches": self.matches,
            "mismatches": self.mismatches,
            "all_match": self.all_match,
            "elapsed_sec": round(self.elapsed_sec, 2),
            "verification_status": self.verification_status,
            "first_mismatch": next(
                ({"case_id": c.case_id, "input": c.input_data[:100],
                  "output_a": c.output_a[:100], "output_b": c.output_b[:100]}
                 for c in self.cases if not c.match),
                None,
            ),
        }


GeneratorFn = Callable[[int], list[str]]
RunnerFn = Callable[[str, str], str]


def diff_test(
    impl_a: str | Path,
    impl_b: str | Path,
    *,
    test_inputs: list[str] | None = None,
    generator: GeneratorFn | None = None,
    runner_a: RunnerFn | None = None,
    runner_b: RunnerFn | None = None,
    n_cases: int = 10,
    comparator: Callable[[str, str], bool] | None = None,
) -> DiffTestResult:
    """Run differential testing across two implementations.

    Args:
        impl_a: path to implementation A.
        impl_b: path to implementation B.
        test_inputs: explicit test inputs (overrides generator).
        generator: function that generates n test input strings.
        runner_a: function that runs impl_a on an input, returns output.
        runner_b: function that runs impl_b on an input, returns output.
        n_cases: number of test cases to generate.
        comparator: custom comparison (default: string equality).

    Returns:
        DiffTestResult with per-case match/mismatch.
    """
    from kairos.observe import emit

    t0 = time.monotonic()
    result = DiffTestResult()

    if test_inputs is None:
        if generator is not None:
            test_inputs = generator(n_cases)
        else:
            test_inputs = [f"test_case_{i}" for i in range(n_cases)]

    cmp = comparator or (lambda a, b: a.strip() == b.strip())
    default_runner: RunnerFn = lambda impl, inp: f"output_of_{Path(impl).stem}({inp})"
    ra = runner_a or default_runner
    rb = runner_b or default_runner

    for i, inp in enumerate(test_inputs):
        out_a = ra(str(impl_a), inp)
        out_b = rb(str(impl_b), inp)
        match = cmp(out_a, out_b)
        result.cases.append(DiffCase(
            input_data=inp, output_a=out_a, output_b=out_b,
            match=match, case_id=i,
        ))

    result.total = len(result.cases)
    result.matches = sum(1 for c in result.cases if c.match)
    result.mismatches = result.total - result.matches
    result.elapsed_sec = time.monotonic() - t0

    emit("diff_test_result", {
        "impl_a": str(impl_a),
        "impl_b": str(impl_b),
        "total": result.total,
        "matches": result.matches,
        "mismatches": result.mismatches,
        "all_match": result.all_match,
        "verification_status": result.verification_status,
    }, run_subtype="differential_test")

    return result
