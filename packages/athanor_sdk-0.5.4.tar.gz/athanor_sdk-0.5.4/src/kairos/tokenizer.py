"""ATH-599: tokenizer-side helpers for HuggingFace byte-level BPE edge cases.

Some HF tokenizers (DeepSeek-Prover-V2 confirmed; possibly other Llama-family
models) return the GPT-2 byte-level BPE encoding form from
`tokenizer.decode()` instead of decoded UTF-8. Lean Unicode characters
(∀ ℕ ℝ ≤ subscripts) come out as `âĪĢ âĦķ âĦĿ âī¤ hâĤĢ` and downstream
`lake build` silently rejects the file.

`gpt2_bpe_to_utf8(text)` is the post-decode step. Use it whenever
`tok.backend_tokenizer.decoder` is not the `ByteLevel` decoder.

Naive workarounds like:

    text.replace("Ġ", " ").replace("Ċ", "\\n")

cover only 2 of ~68 byte-level chars and miss all Unicode. The function
below builds the full 256-entry alphabet from the canonical GPT-2 vocab
construction routine and decodes character-by-character.
"""

from __future__ import annotations

from typing import Final


def _build_byte_decoder() -> dict[str, int]:
    """Construct the inverse of GPT-2's byte-level BPE alphabet.

    GPT-2's pre-tokenization maps each of 256 byte values to a printable
    Unicode character. The mapping starts from the printable ASCII range
    (33–126) plus the printable Latin-1 range (161–172, 174–255) — these
    bytes map to themselves. Remaining 68 bytes (control + space + a few
    Latin-1 holes) get mapped to U+0100, U+0101, U+0102, … in order.

    This function builds the {char_str: byte_int} reverse lookup so we
    can decode a "Ġ"-style token-string back into the original bytes.

    Reference: GPT-2 paper Appendix B + the OpenAI gpt2 vocab init code.
    """
    bs: list[int] = (
        list(range(ord("!"), ord("~") + 1))
        + list(range(ord("¡"), ord("¬") + 1))
        + list(range(ord("®"), ord("ÿ") + 1))
    )
    cs: list[int] = bs[:]
    n = 0
    for b in range(2 ** 8):
        if b not in bs:
            bs.append(b)
            cs.append(2 ** 8 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


# Precomputed once at module load — ~256 entries, no need to rebuild
# on every call. Final[] makes it clear this is intentionally global
# state and shouldn't be mutated by callers.
_BYTE_DECODER: Final[dict[str, int]] = _build_byte_decoder()


def gpt2_bpe_to_utf8(text: str) -> str:
    """Reverse a GPT-2 byte-level BPE encoding into UTF-8 text.

    For each character in ``text``:
      * If the char is in the GPT-2 byte alphabet, append the
        corresponding raw byte to a buffer.
      * Otherwise (already UTF-8, or a token-special char outside the
        alphabet), append the char's UTF-8 bytes directly.

    The accumulated bytes are decoded as UTF-8 with ``errors="replace"``
    so a single bad byte doesn't crash the whole decode. In practice
    well-formed BPE strings round-trip cleanly.

    Idempotent on already-decoded UTF-8 text — chars not in the alphabet
    pass through their own utf-8 bytes. So:

        gpt2_bpe_to_utf8(gpt2_bpe_to_utf8(s)) == gpt2_bpe_to_utf8(s)

    Use this whenever ``tok.backend_tokenizer.decoder`` is not the
    ``ByteLevel`` decoder; HF won't apply the byte-decode step itself.

    >>> gpt2_bpe_to_utf8("Ġhello")
    ' hello'
    >>> gpt2_bpe_to_utf8("plain ASCII")
    'plain ASCII'
    """
    out = bytearray()
    for ch in text:
        if ch in _BYTE_DECODER:
            out.append(_BYTE_DECODER[ch])
        else:
            out.extend(ch.encode("utf-8"))
    return out.decode("utf-8", errors="replace")


__all__ = ["gpt2_bpe_to_utf8"]
