"""ATH-697 — bring-your-own-key LLM dispatcher for the free tier.

Goal: customers using free-tier `kairos.simple_prove_template()` who want
NL-to-spec extraction beyond the deterministic template can plug in
their own Anthropic / OpenAI / Gemini key. The SDK never phones home,
never sends tokens through Athanor infra, never bills the customer
for our LLM calls. Customer pays cents-per-call directly to whichever
provider they already have.

## Detection order

First non-empty key wins. Customer overrides selection by setting
`KAIROS_LLM_PROVIDER` (`anthropic` | `openai` | `gemini`) explicitly.

1. `ANTHROPIC_API_KEY` → `claude-haiku-4-5` (fast, cheap default)
2. `OPENAI_API_KEY` → `gpt-4o-mini`
3. `GEMINI_API_KEY` → `gemini-2.5-flash`

Override the model with `KAIROS_LLM_MODEL`. Override the provider
with `KAIROS_LLM_PROVIDER`.

## Fallback

If no key is set, `complete()` raises `LLMUnavailable`. Callers MUST
handle that and fall back to the deterministic-template path. Free
tier MUST work with no key — the LLM hop is optional augmentation,
not a hard dependency.

## Privacy

The customer's hypothesis text + Pythia template prompt are sent to
the customer's chosen provider. NEVER to Athanor infra. The SDK does
not log or store the LLM input/output beyond what the customer's
provider already retains per their own privacy policy.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Literal

logger = logging.getLogger(__name__)


Provider = Literal["anthropic", "openai", "gemini"]


# Default model per provider — small/fast/cheap. Customer overrides via
# `KAIROS_LLM_MODEL`.
_DEFAULT_MODELS: dict[Provider, str] = {
    "anthropic": "claude-haiku-4-5",
    "openai": "gpt-4o-mini",
    "gemini": "gemini-2.5-flash",
}

_PROVIDER_ENV_VARS: dict[Provider, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "gemini": "GEMINI_API_KEY",
}


class LLMUnavailable(RuntimeError):
    """No BYO key was found in env. Caller MUST fall back to a non-LLM path."""


@dataclass(frozen=True, repr=False)
class LLMConfig:
    """Resolved provider + model + key. Built by `resolve_config()`.

    ATH-715: dataclass auto-`__repr__` was leaking the raw `api_key`
    into any caller that logged or pickled an `LLMConfig`. We override
    `__repr__` to mask the key (last-4 only) so customer keys never
    reach logs / `str(cfg)` / debug traces.
    """

    provider: Provider
    model: str
    api_key: str

    def __repr__(self) -> str:
        masked = (
            f"...{self.api_key[-4:]}"
            if self.api_key and len(self.api_key) >= 4
            else "<empty>"
        )
        return (
            f"LLMConfig(provider={self.provider!r}, model={self.model!r}, "
            f"api_key={masked!r})"
        )


def resolve_config() -> LLMConfig:
    """Return the resolved LLM config from env. Raises `LLMUnavailable`
    if no provider key is set.

    Selection logic:
        - `KAIROS_LLM_PROVIDER` (if set + valid): force that provider.
          Raises `LLMUnavailable` if the provider's key isn't also set.
        - Otherwise: walk providers in order (anthropic → openai → gemini)
          and return the first one whose key is non-empty.
    """
    forced = os.environ.get("KAIROS_LLM_PROVIDER", "").strip().lower()
    if forced:
        if forced not in _PROVIDER_ENV_VARS:
            raise LLMUnavailable(
                f"KAIROS_LLM_PROVIDER={forced!r} is not one of "
                f"{tuple(_PROVIDER_ENV_VARS)}; unset it or pick a "
                f"supported provider."
            )
        provider: Provider = forced  # type: ignore[assignment]
        key = os.environ.get(_PROVIDER_ENV_VARS[provider], "").strip()
        if not key:
            raise LLMUnavailable(
                f"KAIROS_LLM_PROVIDER={provider!r} but "
                f"{_PROVIDER_ENV_VARS[provider]} is not set."
            )
        return _build_config(provider, key)

    for provider in ("anthropic", "openai", "gemini"):
        key = os.environ.get(
            _PROVIDER_ENV_VARS[provider], ""  # type: ignore[index]
        ).strip()
        if key:
            return _build_config(provider, key)  # type: ignore[arg-type]

    raise LLMUnavailable(
        "No BYO LLM key found. Set one of "
        f"{tuple(_PROVIDER_ENV_VARS.values())} in your environment "
        "or .env file. The SDK never phones home — your hypothesis "
        "is sent only to the provider whose key you provide."
    )


def _build_config(provider: Provider, key: str) -> LLMConfig:
    model = os.environ.get("KAIROS_LLM_MODEL", "").strip() or _DEFAULT_MODELS[provider]
    return LLMConfig(provider=provider, model=model, api_key=key)


def is_available() -> bool:
    """True iff `resolve_config()` would succeed. Cheap probe — no
    network call. Use this to gate optional LLM augmentation paths."""
    try:
        resolve_config()
        return True
    except LLMUnavailable:
        return False


def complete(prompt: str, *, max_tokens: int = 1024,
             temperature: float = 0.0) -> str:
    """Send `prompt` to the resolved provider's chat-completion API.
    Returns the raw model response text.

    Defaults to temperature=0 for determinism — the customer's free-tier
    flow benefits from the same hypothesis producing the same spec.

    Raises:
        LLMUnavailable: no key configured.
        RuntimeError: API call failed (network, auth, rate-limit, etc).

    The HTTP call goes directly from the customer's machine to the
    customer's chosen provider. SDK is a thin wrapper that formats
    the request body for each provider's chat-completions schema.
    """
    cfg = resolve_config()
    if cfg.provider == "anthropic":
        return _complete_anthropic(cfg, prompt, max_tokens, temperature)
    if cfg.provider == "openai":
        return _complete_openai(cfg, prompt, max_tokens, temperature)
    if cfg.provider == "gemini":
        return _complete_gemini(cfg, prompt, max_tokens, temperature)
    raise RuntimeError(f"unreachable: unknown provider {cfg.provider!r}")


def _complete_anthropic(cfg: LLMConfig, prompt: str,
                          max_tokens: int, temperature: float) -> str:
    import requests
    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        json={
            "model": cfg.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}],
        },
        headers={
            "x-api-key": cfg.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        timeout=60,
    )
    resp.raise_for_status()
    body = resp.json()
    # Anthropic shape: {content: [{type: "text", text: "..."}], ...}
    parts = body.get("content", [])
    if parts and isinstance(parts, list):
        for p in parts:
            if isinstance(p, dict) and p.get("type") == "text":
                return p.get("text", "")
    return ""


def _complete_openai(cfg: LLMConfig, prompt: str,
                       max_tokens: int, temperature: float) -> str:
    import requests
    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        json={
            "model": cfg.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}],
        },
        headers={
            "Authorization": f"Bearer {cfg.api_key}",
            "content-type": "application/json",
        },
        timeout=60,
    )
    resp.raise_for_status()
    body = resp.json()
    # OpenAI shape: {choices: [{message: {content: "..."}}]}
    choices = body.get("choices", [])
    if choices:
        msg = choices[0].get("message", {})
        return msg.get("content", "")
    return ""


def _complete_gemini(cfg: LLMConfig, prompt: str,
                       max_tokens: int, temperature: float) -> str:
    # Gemini's REST API takes the key as a URL query param per Google's
    # design — `?key=<api_key>`. Customers who route Gemini calls through
    # an HTTP proxy that logs request URLs (corporate gateways, naive
    # mitmproxy setups) will see the key in those logs. The key never
    # leaves the request itself; this is a Gemini-API-shape caveat, not
    # an SDK bug. If your environment proxies BYO-LLM traffic, prefer
    # ANTHROPIC_API_KEY or OPENAI_API_KEY (Authorization-header transport).
    import requests
    resp = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{cfg.model}:generateContent",
        params={"key": cfg.api_key},
        json={
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        },
        headers={"content-type": "application/json"},
        timeout=60,
    )
    resp.raise_for_status()
    body = resp.json()
    # Gemini shape: {candidates: [{content: {parts: [{text: "..."}]}}]}
    candidates = body.get("candidates", [])
    if candidates:
        parts = candidates[0].get("content", {}).get("parts", [])
        if parts:
            return parts[0].get("text", "")
    return ""


__all__ = [
    "LLMConfig",
    "LLMUnavailable",
    "Provider",
    "complete",
    "is_available",
    "resolve_config",
]
