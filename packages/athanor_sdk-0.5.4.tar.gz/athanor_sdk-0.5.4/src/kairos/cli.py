"""Athanor CLI — the platform in your terminal.

Usage:
    athanor run --token <token>                     # Start runner
    athanor score --task <slug> --file solution.py  # Score a file
    athanor solve --env <env> --task <slug>         # Solve a task with a model
    athanor evaluate --env <env>                    # Batch evaluate all tasks
    athanor pull --env <env>                        # Download environment tarball
    athanor runs --env <env>                        # List recent evaluation runs
    athanor proofs --env <env>                      # List verified proofs
    athanor config --set KEY=VALUE                  # Set config
"""

import argparse
import json
import os
import re
import sys

from kairos import __version__ as _VERSION
from kairos.runner import _NoRedirectHandler
from kairos.envvars import getenv_dual
# ATH-816: model literals sourced from the central preset module so
# the SDK has one auditable place for default models.
from kairos.model_presets import (
    DEFAULT_RUNNER_MODEL,
    DEFAULT_SPEC_GENERATION_MODEL,
)


# ATH-832 — `kairos prove --nl --vertical <X>` template names are
# CLI-facing taxonomy ("ebmc", "lean") and don't always match the
# `solve_runs.vertical` CHECK enum on the platform side. Without
# this mapping, `--vertical ebmc` triggers a 23514 CHECK violation
# during `session.open_run()` and the customer's run never gets
# a parent row (events POST as orphans into `sdk_agent_events`).
#
# Keep the mapping exhaustive over `_VERTICAL_TEMPLATES` from
# `kairos.verticals.nl_frontend`; new CLI verticals MUST register
# both an nl_frontend template + an entry here. The
# `test_nl_vertical_to_solve_runs_vertical_exhaustive` test pins
# this contract.
_NL_VERTICAL_TO_SOLVE_RUNS_VERTICAL: dict[str, str] = {
    # CLI flag value → solve_runs.vertical CHECK enum value.
    # Allowed enum: {neuron, bio, action_cred, sysverilog, auth,
    # networking, distributed_systems, systems_migration, hardware,
    # theorem_proving, lean, other}.
    "ebmc": "sysverilog",  # SystemVerilog BMC fits the sysverilog bucket
    "lean": "lean",        # already valid; identity for clarity
}


def _resolve_solve_runs_vertical(nl_vertical: str) -> str:
    """ATH-832: map a CLI --vertical flag value to the corresponding
    `solve_runs.vertical` CHECK enum value. Falls back to ``"other"``
    for unknown values rather than raising — keeps the CLI working
    for verticals that haven't been mapped yet, just at the cost of
    less-specific platform filtering.
    """
    return _NL_VERTICAL_TO_SOLVE_RUNS_VERTICAL.get(nl_vertical, "other")


# ------------------------------------------------------------------
# ATH-358 spec subcommands (template, submit; validate + new land
# via asabi + qa PRs).
# ------------------------------------------------------------------

_SPEC_TEMPLATE = {
    "# Comment": "Required fields (no defaults). Fill all four.",
    "target_file": "path/to/target.lean",
    "target_name": "my_theorem_name",
    "vertical": "lean",
    "budget": {"wall_seconds": 3600, "usd": 6.0},

    "# Comment 2": "Defaulted fields (defaults applied if omitted).",
    "acceptance_criteria": "zero_sorry_axiom_match",
    "known_hypotheses": [],
    "hints": {"banned_tactics": [], "preferred_lemmas": [], "free_text": ""},
    "artifacts_expected": ["proof", "counterexample", "bundle", "audit"],
    "phase_model_overrides": [],
    "operational": {"priority": "medium", "retry_policy": 3, "customer_note": ""},

    "# Comment 3": "Verification layer toggles. Default: all on. Unset what you don't want.",
    "verification": {
        "property_tests": True,   # Phase 1 Hypothesis sweep
        "simulator": True,        # Phase 2 CPU sim
        "mutation_sweep": True,   # Phase 2 deterministic mutation catalogue
        "bmc": True,              # Phase 3 EBMC k-induction (sysverilog)
        "lean_proof": True,       # Phase 3+4 Aristotle / lean / action_cred / bbr3
        "triple_audit": True,     # Phase 5 opus / sonnet / gemini voices
    },

    "# Comment 4": "Per-layer acceptance gates + limits.",
    "thresholds": {
        "mutation_kill_rate_min": 0.75,
        "bmc_k_bound": 10,
        "property_test_count": 100,
        "aristotle_wall_seconds": 1200,
        "audit_voices": 3,
    },

    "# Comment 5": "Per-vertical extension bag. Keys match `vertical`.",
    "extension": {},
}


def cmd_spec_template(args):
    """Emit a commented SpecV1 JSON template to stdout."""
    # Preserve the comment-keys so a human can read the file.
    print(json.dumps(_SPEC_TEMPLATE, indent=2))


def cmd_spec_submit(args):
    """Dispatch a validated SpecV1 to the local athanor-builder.

    Flow (ATH-358 + ATH-369):
      1. Builder presence check.
      2. Load spec.json (strip template comment keys).
      3. Stage-A schema + rule validation (local; no builder needed).
      4. License signature verification (ATH-369 Med #8) — if
         ~/.athanor/license.json exists; skipped in dev where it
         doesn't.
      5. Compile spec → IntentV1 (pure data transform).
      6. Create the run directory with 0o700 perms (ATH-369 Med #6).
      7. Dispatch: large intents → tempfile 0o600 (Med #7), small
         intents → inline argv. Builder owns the rest.

    Exits non-zero with a customer-actionable error on any failure.
    """
    import subprocess
    from pathlib import Path as _Path

    from kairos.builder_check import _has_builder, builder_required_error
    from kairos.spec_compiler import SpecCompileError, compile as compile_spec
    from kairos.spec_validate import validate_stage_a as stage_a
    from kairos.sdk_security import (
        LicenseVerifyError,
        intent_tempfile,
        secure_runs_dir,
        should_use_intent_tempfile,
        verify_license_signature,
    )

    if not args.spec or not os.path.exists(args.spec):
        print(f"Error: spec file not found: {args.spec}")
        sys.exit(1)

    if not _has_builder():
        print(f"Error: {builder_required_error()}")
        sys.exit(2)

    try:
        spec = json.loads(open(args.spec).read())
        # Strip out comment keys the template emits.
        spec = {k: v for k, v in spec.items() if not k.startswith("#")}
    except json.JSONDecodeError as exc:
        print(f"Error: {args.spec} is not valid JSON: {exc}")
        sys.exit(1)

    # Stage-A validation (local schema + rule floor; no LLM, no builder).
    result = stage_a(spec)
    if not result.ok:
        print(f"Error: spec failed Stage-A validation ({len(result.defects)} defects):")
        for d in result.defects:
            print(f"  [{d.severity}] {d.field}: {d.message}")
        sys.exit(1)

    # License signature re-check on every submit (ATH-369 Med #8).
    # Only runs if a license has been installed; dev/test envs without
    # one skip the check.
    license_path = _Path.home() / ".athanor" / "license.json"
    pubkey_path = _Path.home() / ".athanor" / "pubkey.asc"
    expected_fpr = getenv_dual("PUBKEY_FPR", "")
    if license_path.is_file() and expected_fpr:
        try:
            verify_license_signature(license_path, pubkey_path, expected_fpr)
        except LicenseVerifyError as exc:
            print(f"Error: license verification failed: {exc}")
            sys.exit(3)

    # Compile spec → intent.
    try:
        intent = compile_spec(spec)
    except SpecCompileError as exc:
        print(f"Error: {exc}")
        sys.exit(1)

    # Create run dir with 0o700 perms (ATH-369 Med #6).
    # Use a timestamp-based run_id; the builder will write events into
    # this directory on its own.
    run_id = getattr(args, "run_id", None) or _gen_run_id()
    try:
        secure_runs_dir(run_id)
    except ValueError as exc:
        print(f"Error: invalid run_id: {exc}")
        sys.exit(1)

    builder_bin = getenv_dual("BUILDER_BIN", "mode_fleet")

    # Large intents go via secure tempfile (ATH-369 Med #7); small
    # intents go inline via argv (one-fewer-file, simpler trace).
    try:
        if should_use_intent_tempfile(intent):
            with intent_tempfile(intent) as intent_path:
                subprocess.run(
                    [builder_bin, "--intent-json-file", str(intent_path),
                     "--run-id", run_id],
                    check=False,
                )
        else:
            subprocess.run(
                [builder_bin, "--intent-json", json.dumps(intent),
                 "--run-id", run_id],
                check=False,
            )
    except FileNotFoundError:
        print(f"Error: {builder_required_error()}")
        sys.exit(2)


def _gen_run_id() -> str:
    """Generate a timestamp-slug run_id matching builder convention."""
    import datetime
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        "spec-%Y%m%dT%H%M%SZ"
    )


def cmd_spec_bundle(args):
    """Pack a completed run's artifacts into a customer-facing
    bundle.tar.gz.

    Standalone post-hoc command — for runs that finished but didn't
    auto-bundle, or for re-packing after a redaction fix. The bundle
    is written to `~/.athanor/runs/<run_id>/bundle.tar.gz` at 0o600.

    Exit codes:
      0 — bundle written
      1 — invariant violation (missing run.json, path escape, size cap)
      4 — redaction gate tripped (IP leak in run artifacts)
    """
    from pathlib import Path as _Path

    from kairos.bundle import (
        BundleError,
        BundleInvariantError,
        RedactionGateError,
        create_bundle,
    )

    run_dir = _Path.home() / ".athanor" / "runs" / args.run_id
    if not run_dir.is_dir():
        print(f"Error: run_dir not found: {run_dir}")
        sys.exit(1)

    try:
        out = create_bundle(run_dir)
    except RedactionGateError as exc:
        print(f"Error: IP-leak guard blocked bundle — {exc}")
        sys.exit(4)
    except BundleInvariantError as exc:
        print(f"Error: bundle invariant violated — {exc}")
        sys.exit(1)
    except BundleError as exc:
        print(f"Error: bundle failed — {exc}")
        sys.exit(1)

    print(f"Bundle: {out}")


def cmd_spec_verify_bundle(args):
    """Verify a bundle.tar.gz's manifest checksums match its contents.

    Useful for customer-side re-verification (e.g. after transfer) or
    for our own regression tests on archived bundles.

    Exit codes:
      0 — all checksums match
      1 — manifest mismatch, missing file, or unreadable bundle
    """
    from pathlib import Path as _Path

    from kairos.bundle import BundleError, verify_bundle

    bundle_path = _Path(args.bundle)
    if not bundle_path.is_file():
        print(f"Error: bundle not found: {bundle_path}")
        sys.exit(1)
    try:
        verify_bundle(bundle_path)
    except BundleError as exc:
        print(f"Error: bundle verification failed — {exc}")
        sys.exit(1)
    print(f"OK — {bundle_path} checksums match manifest.")


def cmd_verify_cert(args):
    """ATH-854 (Q3) — verify a proof-certificate bundle.

    Verifies the embedded SignedVerdict against the JWKS snapshot
    inside the bundle (offline by default). Pass ``--live-jwks`` to
    fetch the current JWKS from kairos.io instead — useful when an
    auditor wants to confirm the embedded snapshot matches what
    kairos.io publishes today.

    Exit codes:
      0 — signature valid, all checksums match, verdict-bytes pin OK
      1 — manifest / checksum / verdict-mismatch / signature-invalid
      2 — bundle path not found / size cap exceeded
    """
    from pathlib import Path as _Path

    from kairos.cert import (
        CertChecksumMismatch,
        CertError,
        CertManifestError,
        CertSignatureInvalid,
        CertVerdictMismatch,
        verify_proof_certificate,
    )

    cert_path = _Path(args.cert)
    if not cert_path.is_file():
        print(f"Error: certificate not found: {cert_path}")
        sys.exit(2)

    jwks_url = (
        "https://kairos.io/.well-known/signing-keys.json"
        if args.live_jwks
        else None
    )

    try:
        result = verify_proof_certificate(cert_path, jwks_url=jwks_url)
    except CertSignatureInvalid as exc:
        print(f"Error: signature invalid — {exc}")
        sys.exit(1)
    except CertVerdictMismatch as exc:
        print(f"Error: verdict bytes don't match signed shape — {exc}")
        sys.exit(1)
    except CertChecksumMismatch as exc:
        print(f"Error: bundle tampered — {exc}")
        sys.exit(1)
    except CertManifestError as exc:
        print(f"Error: manifest invalid — {exc}")
        sys.exit(1)
    except CertError as exc:
        print(f"Error: {exc}")
        sys.exit(2)

    print(f"OK — proof certificate {cert_path} is valid.")
    print(f"  kairos_key_id:  {result.kairos_key_id}")
    print(f"  signed_at:      {result.signed_verdict.signed_at}")
    print(f"  algorithm:      {result.signed_verdict.key_algorithm}")
    print(f"  bundle_version: {result.bundle_format_version}")
    if args.json:
        import json as _json
        print(_json.dumps({
            "verdict": result.verdict,
            "signed_verdict": result.signed_verdict.to_dict(),
            "kairos_key_id": result.kairos_key_id,
            "bundle_format_version": result.bundle_format_version,
        }, indent=2))


def cmd_stream(args):
    """ATH-357 render athanor-builder JSONL stream as ANSI."""
    from kairos.cli_renderer import render_stream, resolve_mode

    mode = resolve_mode(args.mode)
    color = None if not args.no_color else False
    if args.file:
        with open(args.file) as f:
            render_stream(f, mode=mode, color=color)
    else:
        render_stream(sys.stdin, mode=mode, color=color)


def cmd_run(args):
    """Start the runner."""
    from kairos.runner import Runner

    token = args.token or getenv_dual("TOKEN")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    runner = Runner(
        token=token,
        platform_url=args.platform,
        name=args.name,
    )
    runner.run_forever()


def cmd_score(args):
    """Score a file against a task."""
    from kairos.runner import Runner

    # Token is not required for score — it only uses local Docker
    token = args.token or getenv_dual("TOKEN") or "local"

    if not args.file or not os.path.exists(args.file):
        print(f"Error: file not found: {args.file}")
        sys.exit(1)

    student_code = open(args.file).read()

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    result = runner.run_score(
        image=image,
        task_config={"task_slug": args.task, "stub_filename": os.path.basename(args.file)},
        student_code=student_code,
    )

    print(json.dumps(result, indent=2))


def cmd_sv_invariants(args):
    """`athanor sv-invariants` — reverse-mutation-kill invariant discovery (ATH-411).

    Enumerates mutants of the customer's spec, finds the ones the
    current property suite fails to catch, and proposes new
    `assert property` invariants that would catch them. Each
    candidate passes two gates (holds-on-original + kills-mutant)
    before reaching the customer.

    Exit codes:
      0 = at least one accepted invariant proposed, or no surviving mutants
      1 = there are surviving mutants but no candidate passed both gates
      2 = CLI validation error
    """
    from kairos.sv import discover_invariants
    from pathlib import Path

    spec = Path(args.spec)
    if not spec.is_file():
        print(f"Error: spec file not found: {spec}", file=sys.stderr)
        sys.exit(2)

    try:
        r = discover_invariants(
            spec,
            top_module=args.top,
            bound=args.bound,
            max_mutants=args.max_mutants,
            max_proposals_per_mutant=args.max_proposals_per_mutant,
            timeout_sec=args.timeout_sec,
            model=args.model,
            is_smv=args.smv,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    for line in r.summary_lines():
        print(line)

    if r.overall == "NO_PROPOSALS" and r.mutants_surviving > 0:
        sys.exit(1)
    sys.exit(0)


def cmd_sv_swarm(args):
    """`athanor sv-swarm` — state-swarm EBMC bug-hunting (ATH-409).

    Zero LLM. Given a spec + list of cover expressions, for each cover:
    run EBMC to check reachability (stage 1), extract the hit-state
    from the counterexample, then re-run the original assertions with
    the initial state pinned to the hit state (stage 2). Effectively
    doubles the reachable depth without the solver blowing up.

    Exit codes:
      0 = all covers reachable and no new refutations in any chain
      1 = at least one chain produced a refutation (real finding)
      2 = CLI validation error (missing spec, bad covers, no endmodule)
    """
    from kairos.sv import state_swarm
    from pathlib import Path

    spec = Path(args.spec)
    if not spec.is_file():
        print(f"Error: spec file not found: {spec}", file=sys.stderr)
        sys.exit(2)

    covers = [c.strip() for c in args.covers.split(";;") if c.strip()]
    if not covers:
        print("Error: --covers must list at least one SV expression "
              "(separator is `;;`)", file=sys.stderr)
        sys.exit(2)

    try:
        r = state_swarm(
            spec,
            top_module=args.top,
            covers=covers,
            bound=args.bound,
            chain_depth=args.chain_depth,
            timeout_sec=args.timeout_sec,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    for line in r.summary_lines():
        print(line)

    if r.overall == "NEW_REFUTATION":
        sys.exit(1)
    sys.exit(0)


def cmd_sv_cycle_swarm(args):
    """`athanor sv-cycle-swarm` — cycle-indexed EBMC bug-hunting (ATH-410).

    Zero LLM. For each cycle k in `--cycles`, rewrite every assertion
    as `(cycle_count == k) |-> BODY`, then run EBMC on each variant.
    Refutations point at cycle-specific invariants that a mono-bound
    run would mask behind k-induction.

    Exit codes:
      0 = every variant's assertions PROVED
      1 = at least one variant REFUTED
      2 = CLI validation error
    """
    from kairos.sv.swarm import cycle_swarm
    from pathlib import Path

    spec = Path(args.spec)
    if not spec.is_file():
        print(f"Error: spec file not found: {spec}", file=sys.stderr)
        sys.exit(2)

    try:
        cycles = [int(c.strip()) for c in args.cycles.split(",") if c.strip()]
    except ValueError as e:
        print(f"Error: --cycles must be comma-separated integers ({e})",
              file=sys.stderr)
        sys.exit(2)
    if not cycles:
        print("Error: --cycles must list at least one integer cycle",
              file=sys.stderr)
        sys.exit(2)

    try:
        r = cycle_swarm(
            spec,
            top_module=args.top,
            cycles=cycles,
            bound=args.bound,
            timeout_sec=args.timeout_sec,
            counter_width=args.counter_width,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    for line in r.summary_lines():
        print(line)

    if r.overall == "NEW_REFUTATION":
        sys.exit(1)
    sys.exit(0)


def cmd_sv_multi(args):
    """`athanor sv-multi` — multi-abstraction verification with the sandwich rule (ATH-412a).

    Customer writes one YAML file declaring N layers (functional /
    performance / block), each with an assertion set + backends list.
    The SDK dispatches per-layer, then aggregates under the sandwich
    rule: every named assertion must be PROVED by ≥2 distinct backends
    with zero refutations to earn SANDWICH_PROVED.

    Exit codes:
      0 = every layer SANDWICH_PROVED (or SINGLE_PROVED when a layer
          only declares one backend — explicit degraded status)
      1 = any layer REFUTED / ERROR / PARTIAL
      2 = CLI validation error (missing YAML, bad schema)
    """
    from kairos.sv.multi import run_multi
    from pathlib import Path

    yaml_path = Path(args.spec_yaml)
    if not yaml_path.is_file():
        print(f"Error: spec YAML not found: {yaml_path}", file=sys.stderr)
        sys.exit(2)

    try:
        r = run_multi(yaml_path)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)

    for line in r.summary_lines():
        print(line)

    # SANDWICH_PROVED + SINGLE_PROVED are both "no refutations". The
    # CLI exit is green (0) for both so CI gates wrap this cleanly;
    # the text output distinguishes the two for the reviewer.
    if r.overall in ("SANDWICH_PROVED", "SINGLE_PROVED"):
        sys.exit(0)
    sys.exit(1)


def cmd_sv_hb_graph(args):
    """`kairos sv-hb-graph` — happens-before graph + PO-violation detection (ATH-412 Part B).

    Walks a SystemVerilog source, builds the happens-before graph,
    runs Tarjan's SCC for cycle detection, and (optionally) emits
    SVA witnesses for each detected cycle.

    Customer mental model: "my design has two processes talking over
    FIFOs; does my handshake protocol have a hidden HB cycle? If yes,
    give me an SVA assertion I can feed EBMC to confirm it's realizable
    under the RTL."

    Exit codes:
      0 = no PO violations detected (clean DAG)
      1 = violations detected; SVA witnesses emitted to stdout (or
          --out-sva file). Caller pastes into the SV source + runs
          EBMC to cross-check.
      2 = CLI validation error (missing spec, parse error)
    """
    from pathlib import Path

    from kairos.sv.hb_extract import HBExtractError, extract_hb_graph
    from kairos.sv.hb_graph import find_po_violations
    from kairos.sv.hb_sva_emit import emit_all_sva

    spec_path = Path(args.spec)
    if not spec_path.is_file():
        print(f"Error: spec file not found: {spec_path}", file=sys.stderr)
        sys.exit(2)

    try:
        graph = extract_hb_graph(spec_path.read_text())
    except HBExtractError as exc:
        line = f" (line {exc.source_line})" if exc.source_line else ""
        print(f"Error: {exc}{line}", file=sys.stderr)
        sys.exit(2)

    violations = find_po_violations(graph)

    print(f"hb-graph: {len(graph)} event(s), "
          f"{sum(1 for _ in graph.all_edges())} edge(s)")
    print(f"po-violations: {len(violations)}")

    if not violations:
        print("Clean DAG — no HB cycles.")
        sys.exit(0)

    # Violations found — emit SVA witnesses
    sva = emit_all_sva(
        graph,
        clock=args.clock,
        disable_signal=args.disable_iff,
    )
    if args.out_sva:
        out = Path(args.out_sva)
        out.write_text(sva)
        print(f"SVA witnesses written to {out}")
    else:
        print()
        print(sva)
    sys.exit(1)


def cmd_sv_prove(args):
    """`kairos sv-prove` — run EBMC against a SystemVerilog spec, no LLM.

    Thin CLI over `kairos.sv.prove`. Zero agent, zero orchestration
    — just the SDK's EBMC wrapper with a terminal-friendly frontend.

    Exit codes:
      0 = every declared property PROVED
      1 = one or more REFUTED / UNKNOWN / timeout / EBMC error
      2 = CLI validation error (missing spec, etc.)
    """
    from kairos.sv import prove, EbmcError
    from pathlib import Path

    spec = Path(args.spec)
    if not spec.is_file():
        print(f"Error: spec file not found: {spec}", file=sys.stderr)
        sys.exit(2)

    try:
        r = prove(
            spec,
            top_module=args.top,
            bound=args.bound,
            mode=getattr(args, "mode", "bmc"),
            reset_expr=getattr(args, "reset", None),
            timeout_sec=args.timeout_sec,
        )
    except EbmcError as e:
        # Refutation / unknown / timeout. Print one line per refuted
        # property (names only — full transcript is on stderr for
        # machine pipelines).
        for item in e.result.refutation_summary():
            print(f"REFUTED: {item['name']}")
        print(f"({e.result.proved} proved, {e.result.refuted} refuted)")
        if args.verbose:
            _print_verbose_result(e.result, bound=args.bound)
        if getattr(args, "transcript", False):
            print(f"\n--- EBMC transcript ---", file=sys.stderr)
            print(e.result.transcript, file=sys.stderr)
        sys.exit(1)

    print(f"PROVED: {r.proved}, REFUTED: {r.refuted}")
    if args.verbose:
        _print_verbose_result(r, bound=args.bound)
    if getattr(args, "transcript", False):
        print(f"\n--- EBMC transcript ---", file=sys.stderr)
        print(r.transcript, file=sys.stderr)
    sys.exit(0)


# ANSI color codes for --verbose rendering. Applied only when output is
# a TTY AND the `NO_COLOR` env var is unset (http://no-color.org convention).
# Customers piping into a log file or scraping the output don't get colors.
_ANSI_RESET = "\033[0m"
_ANSI_BOLD = "\033[1m"
_ANSI_DIM = "\033[2m"
_ANSI_RED = "\033[31m"
_ANSI_GREEN = "\033[32m"
_ANSI_YELLOW = "\033[33m"
_ANSI_CYAN = "\033[36m"


def _color_enabled() -> bool:
    """True when it's safe to emit ANSI colors to stdout."""
    if os.environ.get("NO_COLOR"):
        return False
    return sys.stdout.isatty()


def _c(text: str, code: str) -> str:
    """Wrap `text` in ANSI `code` + reset iff color is enabled."""
    if not _color_enabled():
        return text
    return f"{code}{text}{_ANSI_RESET}"


# Regexes for extracting structured info from the EBMC transcript.
# EBMC's output is stable across versions but not versioned; keep these
# scoped + fall back to empty/default if a match fails.
_SOLVER_RE = re.compile(r"^Using\s+(.+?)\s+with", re.MULTILINE)
# `[reno_cca.assume.1] <expr>: ASSUMED` — one entry per active `assume property`.
_ASSUMED_RE = re.compile(r"^\[([^\]]+)\]\s+(.+?):\s*ASSUMED\s*$", re.MULTILINE)
# `[reno_cca.p_name] <assertion expr>: REFUTED` — one per refuted property.
_REFUTED_RE = re.compile(
    r"^\[([^\]]+)\]\s+(.+?):\s*(REFUTED|FAILED)\s*$", re.MULTILINE
)
# CEX state block header: `State N file <path> line <ln> ...`
_CEX_STATE_RE = re.compile(
    r"^State\s+(\d+)(?:\s+file\s+(\S+)(?:\s+line\s+(\d+))?)?",
    re.MULTILINE,
)
# Variable assignment inside a state block: `  var = value`
_CEX_ASSIGN_RE = re.compile(r"^\s+(\S+)\s*=\s*(.+?)\s*$", re.MULTILINE)


def _parse_solver(transcript: str) -> str | None:
    # Defensive: callers pass `result.transcript` which is a MagicMock
    # auto-attribute under test stubs. Force to str before regex.
    if not isinstance(transcript, str) or not transcript:
        return None
    m = _SOLVER_RE.search(transcript)
    return m.group(1).strip() if m else None


def _parse_active_assumptions(transcript: str) -> list[tuple[str, str]]:
    """Return a list of (name, expression) tuples for every ASSUMED line
    in the transcript — one per active `assume property`. Empty list if
    none (common for specs without CEGAR-spliced hypotheses)."""
    if not isinstance(transcript, str) or not transcript:
        return []
    return [(m.group(1).strip(), m.group(2).strip())
            for m in _ASSUMED_RE.finditer(transcript)]


def _parse_refuted_assertions(transcript: str) -> dict[str, str]:
    """Map property name → the assertion expression EBMC checked.

    Pulled from the `[prop_name] <expr>: REFUTED` line so --verbose can
    show the expression that actually failed, not just the name.
    Returns empty dict when no REFUTED/FAILED lines match.
    """
    if not isinstance(transcript, str) or not transcript:
        return {}
    return {m.group(1).strip(): m.group(2).strip()
            for m in _REFUTED_RE.finditer(transcript)}


def _parse_cex_trace(cex: str) -> list[dict]:
    """Parse an EBMC Counterexample block into a list of state dicts.

    Each state dict: {
        "cycle": int,              # State number (cycle index)
        "location": "file:line",    # Source pointer or "" when absent
        "assignments": {var: value}  # Signal = value pairs
    }

    Returns [] when the input doesn't look like a CEX (parser is
    tolerant: on any error we fall back to the raw-dump codepath).
    """
    if not isinstance(cex, str) or not cex.strip():
        return []
    # Find every `State N` header + slice the body between consecutive ones.
    starts = [(m.start(), m) for m in _CEX_STATE_RE.finditer(cex)]
    if not starts:
        return []
    states: list[dict] = []
    for i, (pos, m) in enumerate(starts):
        cycle = int(m.group(1))
        src_file = m.group(2) or ""
        src_line = m.group(3) or ""
        location = (
            f"{src_file}:{src_line}" if src_file and src_line
            else src_file or ""
        )
        body_start = m.end()
        body_end = starts[i + 1][0] if i + 1 < len(starts) else len(cex)
        body = cex[body_start:body_end]
        assignments: dict[str, str] = {}
        for a in _CEX_ASSIGN_RE.finditer(body):
            var = a.group(1).strip()
            val = a.group(2).strip()
            # Skip the separator line of dashes that EBMC prints.
            if var.strip("-") == "" or val.strip("-") == "":
                continue
            assignments[var] = val
        states.append({
            "cycle": cycle, "location": location,
            "assignments": assignments,
        })
    return states


def _print_cex_table(states: list[dict]) -> None:
    """Render a list of state dicts as a compact side-by-side table.

    Columns = cycles (State 0, 1, 2, ...). Rows = signals. Small
    terminals won't wrap well if many signals × many cycles; we cap
    at 6 cycles to keep the table readable. A customer wanting the
    full trace can use `--transcript`.
    """
    if not states:
        return
    MAX_CYCLES = 6
    if len(states) > MAX_CYCLES:
        shown = states[:MAX_CYCLES]
        elided = len(states) - MAX_CYCLES
    else:
        shown = states
        elided = 0

    # Collect all signals across the shown states (union), in the
    # order they first appear. Keeps variable order stable.
    signals: list[str] = []
    seen: set[str] = set()
    for st in shown:
        for var in st["assignments"]:
            if var not in seen:
                seen.add(var)
                signals.append(var)

    if not signals:
        return

    # Column widths: signal-name column + one per cycle.
    sig_width = max(len(s) for s in signals)
    col_widths = []
    for st in shown:
        hdr = f"cycle {st['cycle']}"
        max_val = max(
            (len(str(st["assignments"].get(s, "-"))) for s in signals),
            default=0,
        )
        col_widths.append(max(len(hdr), max_val))

    # Header row.
    header_cells = [" " * sig_width] + [
        _c(f"cycle {st['cycle']:<{col_widths[i] - 6}}", _ANSI_CYAN)
        for i, st in enumerate(shown)
    ]
    print("  " + "  ".join(header_cells))

    # Rows: one per signal.
    for sig in signals:
        row_cells = [_c(f"{sig:<{sig_width}}", _ANSI_DIM)]
        for i, st in enumerate(shown):
            val = st["assignments"].get(sig, "-")
            row_cells.append(f"{val:<{col_widths[i]}}")
        print("  " + "  ".join(row_cells))

    if elided:
        print(_c(f"  ... (+{elided} more cycle(s); use --transcript for full trace)",
                 _ANSI_DIM))


def _print_verbose_result(result, *, bound: int) -> None:
    """Pretty-print an EbmcResult's per-property verdicts + CEX summary.

    Replaces the old raw-transcript dump in `sv-prove --verbose`. Raw
    EBMC output has ~30 lines of solver chatter (Converting / Type-
    checking / MiniSAT / Solving) before the one section customers
    care about (the `** Results:` per-property verdict table). This
    helper shows only the structured signal:

      * Per-property verdict table (aligned, color-coded PROVED/REFUTED)
      * Counterexample block for the first refuted property, if any
      * Run metadata: elapsed wall-clock + solver backend
      * Active `assume property` constraints (when any; shows what
        CEGAR / the customer added to make the proof go through)

    Raw transcript is still reachable via `--transcript` for deep
    debugging / pipelines that want the full EBMC output.

    Colors respect `NO_COLOR` env + isatty — safe for pipes + logs.
    """
    verdicts = result.property_verdicts or {}
    if verdicts:
        print()
        print(_c("Per-property verdicts:", _ANSI_BOLD))
        name_width = max((len(n) for n in verdicts), default=0)
        for name, verdict in verdicts.items():
            vu = verdict.upper()
            if vu in ("PROVED", "OK"):
                marker_colored = _c(f"{'PROVED':<8}", _ANSI_GREEN + _ANSI_BOLD)
                suffix = _c(f" (up to bound {bound})", _ANSI_DIM)
            elif vu in ("REFUTED", "FAILED"):
                marker_colored = _c(f"{'REFUTED':<8}", _ANSI_RED + _ANSI_BOLD)
                suffix = ""
            else:
                marker_colored = _c(f"{vu:<8}", _ANSI_YELLOW + _ANSI_BOLD)
                suffix = ""
            print(f"  {marker_colored}  {name:<{name_width}}{suffix}")

    # Run metadata — elapsed + solver. Shown right after the verdict
    # table so a customer reading cold sees "N seconds, MiniSAT 2.2.1".
    transcript = getattr(result, "transcript", "") or getattr(result, "stdout", "") or ""
    elapsed = getattr(result, "elapsed_sec", None)
    solver = _parse_solver(transcript)
    meta_lines = []
    if isinstance(elapsed, (int, float)) and elapsed > 0:
        meta_lines.append(f"  elapsed: {_c(f'{elapsed:.2f}s', _ANSI_CYAN)}")
    if solver:
        meta_lines.append(f"  solver:  {_c(solver, _ANSI_CYAN)}")
    meta_lines.append(
        f"  bound:   {_c(str(bound), _ANSI_CYAN)} "
        f"{_c(f'(EBMC checked all input sequences up to {bound} clock cycles)', _ANSI_DIM)}"
    )
    if meta_lines:
        print()
        print(_c("Run:", _ANSI_BOLD))
        for line in meta_lines:
            print(line)

    # Active assume-property constraints — critical for the CEGAR
    # demo: customer should see the constraint the proposer spliced in.
    assumptions = _parse_active_assumptions(transcript)
    if assumptions:
        print()
        print(_c("Active constraints:", _ANSI_BOLD))
        name_width = max((len(n) for n, _ in assumptions), default=0)
        for name, expr in assumptions:
            print(f"  {_c(name, _ANSI_YELLOW):<{name_width}}  {expr}")

    cex = getattr(result, "counterexample", None)
    if isinstance(cex, str) and cex.strip():
        # Which property failed? Prefer the verdicts dict (authoritative);
        # fall back to transcript parsing when the caller didn't populate it.
        refuted_names = [
            n for n, v in (verdicts or {}).items()
            if str(v).upper() in ("REFUTED", "FAILED")
        ]
        refuted_exprs = _parse_refuted_assertions(transcript)
        states = _parse_cex_trace(cex)

        print()
        print(_c("Why REFUTED:", _ANSI_RED + _ANSI_BOLD))
        if refuted_names:
            for name in refuted_names:
                expr = refuted_exprs.get(name)
                if expr:
                    print(f"  property: {_c(name, _ANSI_YELLOW)}")
                    print(f"  asserts:  {expr}")
                else:
                    print(f"  property: {_c(name, _ANSI_YELLOW)}")
        else:
            # Fallback: no verdicts dict populated, still show the block.
            print(f"  (property name unavailable — see --transcript)")

        # Require at least one state with actual signal assignments
        # — matched-but-empty state blocks mean the CEX format drifted
        # from EBMC's canonical shape (or someone's stub is minimal).
        # Fall back to raw dump in that case so customers always see
        # something actionable.
        parser_produced_content = bool(
            states and any(s["assignments"] for s in states)
        )
        if parser_produced_content:
            print()
            print(_c("Trace (counterexample):", _ANSI_BOLD))
            _print_cex_table(states)
        else:
            print()
            print(_c("Counterexample (raw):", _ANSI_BOLD))
            for line in cex.splitlines():
                print(f"  {line}")


def _cmd_prove_nl_entry(args) -> None:
    """`kairos prove --nl "..."` — NL-entry mode.

    Takes free-text hypothesis + vertical + target_file, calls
    kairos.verticals.nl_frontend.nl_to_intent() to render an
    IntentV1, dispatches through SpecPipeline.run, renders the
    resulting Verdict(s) as a one-screen summary.

    Exit codes:
      0 — any tier returned proved or refuted (both are legitimate answers)
      1 — all tiers returned unknown/error
      2 — input validation problem (missing --target-file, bad vertical)
    """
    from kairos.verticals import register_defaults
    from kairos.verticals.nl_frontend import nl_to_intent
    from kairos.spec.pipeline import SpecPipeline
    from pathlib import Path

    target_file = args.nl_target_file or args.spec
    if not target_file:
        print(
            "Error: --nl requires --target-file (path to the spec/kernel/"
            "proof file the IntentV1 references). Or pass it as the `spec` "
            "positional argument.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Register the 3 built-in verticals into DEFAULT_REGISTRY.
    register_defaults()

    # For ebmc: if target_name not explicitly passed, auto-detect
    # the top module from the SV file rather than letting nl_frontend
    # synthesize a slugified hypothesis name (which won't match any
    # module in the source → EBMC finds no properties → error).
    resolved_target_name = args.nl_target_name
    if resolved_target_name is None and args.nl_vertical == "ebmc":
        import re as _re
        try:
            _text = Path(target_file).read_text()
            _m = _re.search(r"^\s*module\s+(\w+)", _text, _re.MULTILINE)
            if _m:
                resolved_target_name = _m.group(1)
                if args.verbose:
                    print(
                        f"[prove --nl] auto-detected target_name "
                        f"from {target_file}: {resolved_target_name!r}",
                        file=sys.stderr,
                    )
        except OSError:
            pass  # fall through to nl_frontend's default

    try:
        intent = nl_to_intent(
            args.nl_hypothesis,
            vertical=args.nl_vertical,
            target_file=str(target_file),
            target_name=resolved_target_name,
        )
    except Exception as exc:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: nl_to_intent failed ({type(exc).__name__}: {exc})",
              file=sys.stderr)
        sys.exit(2)

    if args.verbose:
        import json as _json
        print("[prove --nl] derived IntentV1:", file=sys.stderr)
        print(_json.dumps(intent, indent=2), file=sys.stderr)
        print(f"[prove --nl] dispatching through SpecPipeline "
              f"(vertical={args.nl_vertical}, budget={args.cost_budget_usd})",
              file=sys.stderr)

    # ATH-818 G2 + ATH-819: when a non-Noop trace sink is configured,
    # wrap the SpecPipeline run in `kairos.session()` so a `solve_runs`
    # parent row gets created and `/solve-runs/[id]` can render the run.
    # All SpecPipeline events (function_inputs, orchestration_choice,
    # tier_verdict, refinement_*) thread under the session's session_id,
    # which becomes the run_id on every child row.
    #
    # `kairos.session()` is paid-tier-gated. License missing → catch
    # LicenseScopeError and degrade to the legacy unwrapped path with a
    # clear stderr warning. Same shape as today: events still emit (just
    # orphaned), the CLI still produces a verdict.
    from kairos.trace import (
        NoopTraceSink, default_sink_from_env, emit_function_inputs,
        reduce_long_arg,
    )
    _resolved_sink = default_sink_from_env()
    _have_remote_sink = (
        _resolved_sink is not None
        and not isinstance(_resolved_sink, NoopTraceSink)
    )

    # ATH-833: when --planner-model is set, build an Orchestrator pinned
    # to that model and pass it into SpecPipeline. Without this, the
    # SpecPipeline's default Orchestrator uses DEFAULT_PLANNER_MODEL,
    # which may not be JSON-reliable on every customer's provider
    # routing (e.g. our Azure-hosted Anthropic deployment returns non-
    # JSON to Opus 4.6's strict-JSON tier prompt and the orchestrator
    # falls back instead of showing a real LLM-tier rationale).
    _planner_orchestrator = None
    if getattr(args, "nl_planner_model", None):
        from kairos.fleet.orchestrator import Orchestrator as _Orchestrator
        _planner_orchestrator = _Orchestrator(model=args.nl_planner_model)
        if args.verbose:
            print(
                f"[prove --nl] planner model overridden via "
                f"--planner-model={args.nl_planner_model!r}",
                file=sys.stderr,
            )

    # ATH-836: read the target_file's content so the function_inputs
    # event carries a preview the customer can scan on /solve-runs/[id]
    # without leaving the page. Best-effort — missing/unreadable files
    # silently fall through to None (preserves pre-fix path-only render).
    # Uses reduce_long_arg to digest long source files (preview + sha256
    # + length) so payload sizes stay bounded even for multi-kLoC RTL.
    _target_file_content: str = ""
    try:
        _target_file_content = Path(target_file).read_text(errors="replace")
    except (OSError, UnicodeDecodeError):
        pass
    _target_file_preview = (
        reduce_long_arg(_target_file_content, preview_cap=2000)
        if _target_file_content else None
    )

    def _run_pipeline(captured_run_id, sink_for_events):
        # Common helper: emit function_inputs, then dispatch the
        # pipeline under the captured run_id. Used by both the
        # session-wrapped path and the legacy fallback.
        emit_function_inputs(
            sink_for_events,
            run_id=captured_run_id,
            run_subtype="spec_pipeline",
            function_name="kairos.cli.prove_nl",
            args={
                "hypothesis": args.nl_hypothesis,
                "vertical": args.nl_vertical,
                "target_file": str(target_file),
                # ATH-836: source preview alongside the path so customers
                # reading /solve-runs/[id] for an unfamiliar run can see
                # what the file actually contains. None when the file
                # was unreadable; full string for short files; digest
                # dict {sha256, length, preview_first_300, truncated}
                # for files >2000 chars.
                "target_file_preview": _target_file_preview,
                "target_name": resolved_target_name,
                "cost_budget_usd": args.cost_budget_usd,
                "planner_model_override": getattr(
                    args, "nl_planner_model", None,
                ),
            },
        )
        # ATH-833: thread the override-Orchestrator (or None to keep
        # SpecPipeline's default) into the pipeline.
        _pipeline_kwargs: dict = {"trace_sink": sink_for_events}
        if _planner_orchestrator is not None:
            _pipeline_kwargs["orchestrator"] = _planner_orchestrator
        return SpecPipeline(**_pipeline_kwargs).run(
            intent, run_id=captured_run_id,
            cost_budget_usd=args.cost_budget_usd,
        )

    result = None
    if _have_remote_sink:
        try:
            from kairos.prove import session as _kairos_session
        except ImportError:
            _kairos_session = None

        if _kairos_session is not None:
            try:
                _display = (args.nl_hypothesis or str(target_file))[:80]
                with _kairos_session(
                    task_id=f"prove-nl-{args.nl_vertical}",
                    trace_sink=_resolved_sink,
                    run_subtype="spec_pipeline",
                    # ATH-832: map CLI nl_vertical → solve_runs.vertical
                    # CHECK enum value. Pre-fix, args.nl_vertical='ebmc'
                    # tripped 23514 and lost the parent solve_runs row.
                    vertical=_resolve_solve_runs_vertical(args.nl_vertical),
                    name_for_display=_display,
                ) as _sess:
                    # The session's session_id becomes the run_id on
                    # every event so all children thread under the
                    # solve_runs row that session.open_run created.
                    result = _run_pipeline(_sess.session_id, _resolved_sink)
            except Exception as exc:  # noqa: BLE001
                # Most likely cause: LicenseScopeError from session()'s
                # paid-tier gate. Degrade so the CLI still produces a
                # verdict — events emit orphaned (no solve_runs row).
                exc_name = type(exc).__name__
                if "LicenseScope" in exc_name:
                    print(
                        f"[prove --nl] license check failed ({exc}); "
                        "running without a /solve-runs row. Install "
                        "~/.athanor/license.json with `solve` access "
                        "or set KAIROS_DEV_NO_LICENSE=1 to enable "
                        "platform observability.",
                        file=sys.stderr,
                    )
                else:
                    print(
                        f"[prove --nl] session wrap failed "
                        f"({exc_name}: {exc}); falling back to "
                        "no-session run. Trace events will land but "
                        "/solve-runs/[id] won't render this run.",
                        file=sys.stderr,
                    )
                result = None  # fall through to the unwrapped path

    if result is None:
        # Legacy unwrapped path. Use the intent's run_id when present so
        # the function_inputs row threads under the same run_id
        # SpecPipeline.run() will use. Falls back to a fresh UUID
        # otherwise.
        import uuid as _uuid
        _captured_run_id = (
            intent.get("run_id") if isinstance(intent, dict) else None
        ) or str(_uuid.uuid4())
        result = _run_pipeline(_captured_run_id, _resolved_sink)

    # ── Render the result ────────────────────────────────────────────
    print(f"\n=== Verdict ({args.nl_vertical}) ===")
    if not result.verdicts_by_tier:
        print("  (no tier dispatched — check orchestrator configuration)")
    for tier, v in result.verdicts_by_tier.items():
        print(f"  {tier}: {v.outcome.upper()}")
        if v.reason:
            print(f"    {v.reason}")
        if args.verbose and v.details:
            import json as _json
            print(f"    details: {_json.dumps(v.details, default=str)[:400]}")
    print(f"\n  score:       {result.score}")
    print(f"  cost_usd:    ${result.cost_usd:.4f}")
    if result.budget_exhausted:
        print(f"  BUDGET EXHAUSTED — cap was ${args.cost_budget_usd}")
    if result.escalations:
        print(f"  escalations: {len(result.escalations)}")
        for ev in result.escalations:
            print(f"    - {ev.trigger}: {ev.context.get('reason', '')}")

    # Exit-code semantics: proved OR refuted = 0, else 1.
    outcomes = {v.outcome for v in result.verdicts_by_tier.values()}
    if outcomes & {"proved", "refuted"}:
        sys.exit(0)
    sys.exit(1)


def cmd_prove(args):
    """`kairos prove <spec>` OR `kairos prove --nl "..."` — unified entry point.

    File-dispatch mode (ATH-513):
      .sv  → cmd_sv_prove (pure EBMC) OR cmd_cegar (if --with-cegar)
      .py  → NKI verify.py if adjacent + file imports nki

    NL-entry mode (added 2026-04-23):
      --nl "<hypothesis>" + --vertical + --target-file → nl_frontend.
      nl_to_intent() → SpecPipeline.run → renders Verdict.

    Extracts the top-module name from the .sv file if --top not set
    so `kairos prove reno.sv` works without the user naming the module.

    Exit codes inherit from the dispatched tool; NL-entry path exits
    0 on proved/refuted (both are successful runs — refuted is a
    legitimate answer), 1 on error/unknown, 2 on input-validation
    problems.
    """
    import re
    from pathlib import Path
    from types import SimpleNamespace

    # ── NL-entry mode ────────────────────────────────────────────────
    if args.nl_hypothesis is not None:
        return _cmd_prove_nl_entry(args)

    # ── File-dispatch mode (existing ATH-513 path) ───────────────────
    if args.spec is None:
        print(
            "Error: `kairos prove` requires either a spec file path or "
            "--nl \"<hypothesis>\". See `kairos prove --help`.",
            file=sys.stderr,
        )
        sys.exit(2)

    spec_path = Path(args.spec).resolve()
    if not spec_path.exists():
        print(f"Error: spec file not found: {args.spec}", file=sys.stderr)
        sys.exit(2)

    suffix = spec_path.suffix.lower()

    # SystemVerilog path.
    if suffix in (".sv", ".v"):
        top = args.top
        if top is None:
            # Auto-detect top module: first `module <name>` declaration.
            match = re.search(
                r"^\s*module\s+(\w+)", spec_path.read_text(), re.MULTILINE
            )
            if match:
                top = match.group(1)
                if args.verbose:
                    print(f"[prove] auto-detected top module: {top}",
                          file=sys.stderr)
            else:
                print("Error: could not auto-detect top module; "
                      "pass --top MODULE", file=sys.stderr)
                sys.exit(2)

        if args.with_cegar:
            # Dispatch to cegar — needs a few extra kwargs.
            cegar_args = SimpleNamespace(
                spec=str(spec_path),
                top=top,
                bound=args.bound,
                max_iter=args.max_iter,
                auto_accept_environmental=True,
                verbose=args.verbose,
                budget_usd=None,
                wall_time_sec=None,
                workdir=None,
                reset_expr="reset",
                transcript=False,
            )
            return cmd_cegar(cegar_args)

        # Default: pure EBMC via sv-prove.
        sv_args = SimpleNamespace(
            spec=str(spec_path),
            top=top,
            bound=args.bound,
            timeout_sec=60,
            transcript=False,
            verbose=args.verbose,
        )
        return cmd_sv_prove(sv_args)

    # NKI / Python kernel path.
    if suffix == ".py":
        # Look for verify.py adjacent; if present, run it.
        parent = spec_path.parent
        verify_py = parent / "verify.py"
        if verify_py.exists() and (parent / "kernel.py").exists():
            import subprocess
            if args.verbose:
                print(f"[prove] detected NKI kernel bundle at {parent}, "
                      f"running verify.py", file=sys.stderr)
            res = subprocess.run(
                [sys.executable, str(verify_py)],
                cwd=str(parent),
            )
            sys.exit(res.returncode)
        print(f"Error: .py spec at {spec_path} is not a recognized NKI "
              "kernel bundle (missing adjacent verify.py + kernel.py). "
              "Pass a .sv spec for hardware verification instead.",
              file=sys.stderr)
        sys.exit(2)

    print(f"Error: unsupported spec extension {suffix!r}. Supported: .sv, .v, .py",
          file=sys.stderr)
    sys.exit(2)


def cmd_spec_refine(args):
    """Run iterative spec refinement: DUT + spec -> verify -> refine -> converge."""
    from kairos.spec.refine import refine_spec
    from pathlib import Path

    initial_spec = Path(args.spec).read_text()
    result = refine_spec(
        dut_path=args.dut,
        initial_spec=initial_spec,
        verify_engine=args.engine,
        refine_model=args.model,
        max_iterations=args.max_iterations,
        timeout_sec=args.timeout,
        top_module=args.top,
    )
    print(f"Converged: {result.converged}")
    print(f"Iterations: {result.n_iterations()}")
    print(f"Halt: {result.halt_reason}")
    print(f"Compression moves: {', '.join(result.compression_moves_used) or 'none'}")
    if result.converged:
        print(f"\nFinal spec ({len(result.final_spec)} chars):")
        print(result.final_spec[:500])


def cmd_optimize(args):
    """Run one-command RTL optimization: propose + verify + measure."""
    from kairos.sec.closed_loop.optimize_cli import optimize
    import json

    param_dict = {}
    if args.params:
        for kv in args.params.split(","):
            if "=" in kv:
                k, v = kv.split("=", 1)
                param_dict[k.strip()] = int(v.strip())

    result = optimize(
        rtl_path=args.rtl,
        dep_paths=args.deps or None,
        param_overrides=param_dict or None,
        model=args.model,
        max_proposals=args.max_proposals,
        timeout_sec=args.timeout,
        config_path=args.config,
    )
    print(result.summary())
    print()
    if result.n_accepted() > 0 or result.iteration_summaries:
        print(f"Details ({len(result.iteration_summaries)} proposals):")
        for s in result.iteration_summaries:
            delta = s.get("measured_delta_pct", s.get("claimed_area_delta_pct", "?"))
            print(f"  iter {s['iteration_index']}: {s['outcome']} delta={delta}%")


def cmd_cegar(args):
    """Dispatch `athanor cegar` → athanor-builder's cegar.sh shell wrapper.

    CEGAR loop — spec-layer hypothesis strengthening (Mode B, customer-port).
    Subprocess-shells to `$ATHANOR_BUILDER_ROOT/solve/sysverilog/cegar.sh`
    with verbatim flag passthrough. Exit codes 0-4 are propagated per
    the shell wrapper's contract:

      0 = all_proved
      1 = max_iter / budget / walltime cap hit
      2 = validation error (missing flags, missing spec, missing builder)
      3 = genuine_bug (customer should triage RTL)
      4 = user_stop

    CEGAR shares the "solve" license product for MVP (pricing split later
    if tiers diverge). Interactive accept/reject inherits stdin/stdout
    from the SDK process; non-interactive CI path is
    `--auto-accept-environmental`. See ATH-398 + athanor-builder PR #82.
    """
    import subprocess
    from pathlib import Path
    from kairos.builder_check import _has_builder, builder_required_error
    from kairos.license_scope import require_product, LicenseScopeError

    # ATH-389: license-scope gate. Dev-mode (no license file) passes.
    # Confirmed 2026-04-20 (cegar-mvp-split thread): share "solve".
    try:
        require_product("solve")
    except LicenseScopeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(2)

    if not _has_builder():
        print(f"Error: {builder_required_error()}", file=sys.stderr)
        sys.exit(2)

    # ATH-457: precheck customer setup BEFORE spawning cegar.sh. The
    # top-level `_check_litellm_for_command` in main() handles CLI
    # entry; calling it here too keeps direct programmatic callers
    # (cli.cmd_cegar(ns)) covered without diverging the message.
    _check_litellm_for_command("cegar")

    if not os.environ.get("ANTHROPIC_API_KEY"):
        print(
            "Error: kairos cegar needs ANTHROPIC_API_KEY to call the proposer LLM.\n"
            "  Set it before running cegar:\n"
            "      export ANTHROPIC_API_KEY=<your-key>\n"
            "  If your key is an Azure-hosted Anthropic bearer token, also set:\n"
            "      export ANTHROPIC_BASE_URL=<your-foundry-host>",
            file=sys.stderr,
        )
        sys.exit(2)

    builder_root = getenv_dual("BUILDER_ROOT", "/opt/athanor/builder")
    cegar_sh = Path(builder_root) / "solve" / "sysverilog" / "cegar.sh"
    if not cegar_sh.is_file():
        print(
            f"Error: cegar.sh not found at {cegar_sh}. "
            f"Set $ATHANOR_BUILDER_ROOT to your athanor-builder install root.",
            file=sys.stderr,
        )
        sys.exit(2)

    # ATH-443: subprocess runs with cwd=builder_root, so relative path
    # args would be resolved against that (not the customer's pwd).
    # Absolutize every path-flavored arg BEFORE building the cmd.
    spec_abs = str(Path(args.spec).resolve())
    workdir_abs = str(Path(args.workdir).resolve()) if args.workdir else None

    cmd = [str(cegar_sh), "--spec", spec_abs, "--top", args.top]
    if args.bound is not None:
        cmd += ["--bound", str(args.bound)]
    if args.max_iter is not None:
        cmd += ["--max-iter", str(args.max_iter)]
    if args.budget_usd is not None:
        cmd += ["--budget-usd", str(args.budget_usd)]
    if args.walltime_sec is not None:
        cmd += ["--walltime-sec", str(args.walltime_sec)]
    if workdir_abs:
        cmd += ["--workdir", workdir_abs]
    if args.auto_accept_environmental:
        cmd += ["--auto-accept-environmental"]
    if args.clk:
        cmd += ["--clk", args.clk]
    if getattr(args, "reset", None) is not None:
        cmd += ["--reset", args.reset]
    if getattr(args, "verbose", False):
        cmd += ["--verbose"]

    print(f"$ {' '.join(cmd)}", file=sys.stderr)

    # Inherit stdin for interactive accept/reject prompts; inherit stdout
    # (builder emits per-iter human-readable log + final JSON summary);
    # stderr passes through for builder diagnostics.
    proc = subprocess.run(cmd, cwd=str(Path(builder_root)))
    sys.exit(proc.returncode)


def cmd_solve(args):
    """Dispatch: `athanor solve --vertical <name>` → core chassis; else legacy.

    The solve verb fronts two distinct backends:

    1. **Legacy single-shot** (`athanor solve --env X --task Y --model M`):
       pulls a Docker image, runs a single agent loop against one task.
       No orchestration chassis. Predates ATH-413.

    2. **Core vertical** (`athanor solve --vertical sysverilog-fleet
       --target fix_booth_mul`, ATH-418 Phase 4): subprocess-shells to
       `$ATHANOR_BUILDER_ROOT/solve/core/run.sh` which dispatches through
       the ATH-413 Pipeline + VerifierBackend chassis. Full 10-phase
       chain (spec_validate → ebmc → cegar → lean → audit → bundle).

    `--vertical` presence is the switch. Other flags are shared where
    meaningful (--workdir, --max-cost, --max-iter) and vertical-specific
    otherwise.
    """
    if getattr(args, "vertical", None):
        return cmd_solve_vertical(args)
    return _cmd_solve_legacy(args)


def cmd_solve_vertical(args):
    """Dispatch `athanor solve --vertical X` → solve/core/run.sh (ATH-418).

    Thin subprocess-shell into the core chassis. Flag passthrough is
    verbatim against the shell wrapper's documented surface:

        --vertical <name>          [required]
        --target <slug>            [required unless --list-verticals]
        --workdir <path>
        --resume | --force         [workdir collision handling, ATH-418 Q4]
        --verifier <comma,list>
        --dry-run
        --max-cost <usd>
        --max-iter <N>
        --skip-phases <comma,list>
        --list-verticals
        --extra <key>=<value>      [repeatable, ATH-426 QC30 — ctx.extra passthrough]

    Exit code is propagated from the shell wrapper.

    Same pattern as `athanor cegar` (ATH-398) + `athanor sv-swarm`. The
    customer-facing surface stays thin; all orchestration lives behind
    the builder boundary.
    """
    import subprocess
    from pathlib import Path
    from kairos.builder_check import _has_builder, builder_required_error
    from kairos.license_scope import require_product, LicenseScopeError

    # ATH-389 license gate. `solve` product covers the core chassis.
    # License_scope runs in permissive dev-mode when no license file.
    try:
        require_product("solve")
    except LicenseScopeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(2)

    if not _has_builder():
        print(f"Error: {builder_required_error()}", file=sys.stderr)
        sys.exit(2)

    builder_root = getenv_dual("BUILDER_ROOT", "/opt/athanor/builder")
    run_sh = Path(builder_root) / "solve" / "core" / "run.sh"
    if not run_sh.is_file():
        print(
            f"Error: solve/core/run.sh not found at {run_sh}. "
            f"Requires athanor-builder post-ATH-415. Set $ATHANOR_BUILDER_ROOT "
            f"to your athanor-builder install root, or upgrade the installed "
            f"builder to a version that ships solve/core/.",
            file=sys.stderr,
        )
        sys.exit(2)

    cmd: list[str] = [str(run_sh), "--vertical", args.vertical]
    if args.target:
        cmd += ["--target", args.target]
    if args.workdir:
        cmd += ["--workdir", args.workdir]
    if getattr(args, "resume", False):
        cmd += ["--resume"]
    if getattr(args, "force", False):
        cmd += ["--force"]
    if args.verifier:
        cmd += ["--verifier", args.verifier]
    if args.dry_run:
        cmd += ["--dry-run"]
    if args.max_cost is not None:
        cmd += ["--max-cost", str(args.max_cost)]
    if args.max_iter is not None:
        cmd += ["--max-iter", str(args.max_iter)]
    if args.skip_phases:
        cmd += ["--skip-phases", args.skip_phases]
    if getattr(args, "only_phases", None):
        cmd += ["--only-phases", args.only_phases]
    if args.list_verticals:
        cmd += ["--list-verticals"]
    for kv in getattr(args, "extra", None) or []:
        cmd += ["--extra", kv]
    if getattr(args, "spec_config_path", None):
        cmd += ["--extra", f"spec_config_path={args.spec_config_path}"]

    print(f"$ {' '.join(cmd)}", file=sys.stderr)

    # ATH-394: auto-pipe subprocess stdout through cli_renderer so
    # customers get the ANSI-rendered live trace without typing
    # `| athanor stream`. Three opt-outs layered defensively:
    #
    #   1. `--raw` explicit flag → always emit JSONL verbatim.
    #   2. `--list-verticals` → one-shot `{name: [...]}` JSON dump;
    #      not a stream, skip the renderer.
    #   3. stdout not a TTY → cli_renderer.render_stream auto-degrades
    #      to plain text (no ANSI) but still filters + formats.
    #
    # Stream-mode + quiet honored via existing `resolve_mode()` which
    # reads KAIROS_STREAM_MODE / KAIROS_QUIET (+ legacy ATHANOR_* via
    # getenv_dual per ATH-407 layer 4).
    use_renderer = (
        not getattr(args, "raw", False)
        and not args.list_verticals
    )

    try:
        if use_renderer:
            from kairos.cli_renderer import render_stream, resolve_mode
            # Stream subprocess stdout line-by-line into render_stream.
            # bufsize=1 → line-buffered; encoding forced to text mode.
            # stdin inherits from parent (None) — passing sys.stdin
            # breaks under pytest which uses a pseudofile without
            # fileno(). Terminal sessions still get interactive stdin
            # inheritance.
            proc = subprocess.Popen(
                cmd,
                cwd=str(Path(builder_root)),
                stdout=subprocess.PIPE,
                stderr=None,  # passthrough builder diagnostics verbatim
                bufsize=1,
                text=True,
            )
            assert proc.stdout is not None
            try:
                render_stream(proc.stdout, mode=resolve_mode())
            finally:
                proc.stdout.close()
                proc.wait()
            sys.exit(proc.returncode)
        else:
            # --raw OR --list-verticals: inherit stdout verbatim so
            # customers parsing JSONL / JSON-dump get the canonical bytes.
            proc = subprocess.run(cmd, cwd=str(Path(builder_root)))
            sys.exit(proc.returncode)
    except OSError as exc:
        # e.g. run.sh exists but not executable, or interpreter absent.
        # Surface as clean exit 2 rather than a Python traceback.
        print(f"Error: could not launch {run_sh}: {exc}", file=sys.stderr)
        sys.exit(2)


def _cmd_solve_legacy(args):
    """Solve a task with a model — full agent loop with retry."""
    from kairos.runner import Runner

    # --env and --task are only required on the legacy path. cmd_solve
    # dispatches to cmd_solve_vertical when --vertical is present and
    # neither flag is needed there.
    if not args.env or not args.task:
        print(
            "Error: `athanor solve` requires --env and --task (legacy path) "
            "OR --vertical (core chassis, ATH-418). See `athanor solve --help`.",
            file=sys.stderr,
        )
        sys.exit(2)

    # Token is not required for solve — it only uses local Docker
    token = args.token or getenv_dual("TOKEN") or "local"
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("Error: ANTHROPIC_API_KEY env var required for solve")
        sys.exit(1)

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    # Fetch task info from platform
    print(f"Solving {args.task} on {args.env} with {args.model}...")
    try:
        task_info = runner._request("GET", f"/api/tasks?slug={args.task}&env={args.env}")
        if isinstance(task_info, list) and task_info:
            task_data = task_info[0]
        elif isinstance(task_info, dict) and task_info.get("data"):
            task_data = task_info["data"][0]
        else:
            task_data = {}
    except Exception:  # noqa: BLE001 — broad-catch fallback
        task_data = {}

    task_config = {
        "task_slug": args.task,
        "task_description": task_data.get("description", args.task),
        "stub_code": (task_data.get("metadata") or {}).get("stub_code", ""),
        "stub_filename": (task_data.get("metadata") or {}).get("stub_filename", f"{args.task}.py"),
    }

    if not task_config["stub_code"]:
        # Try extracting from container
        import subprocess
        result = subprocess.run(
            [runner.docker_bin, "run", "--rm", image, "cat", f"/workdir/data/{task_config['stub_filename']}"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            task_config["stub_code"] = result.stdout

    result = runner.run_solve(image, task_config, model=args.model, api_key=api_key)
    print(f"\nFinal score: {result.get('score', 0):.3f}")
    print(f"Turns: {result.get('tool_calls_total', 0)}")
    print(f"Time: {result.get('time_seconds', 0):.1f}s")

    # Save results
    output = args.output or f"{args.task}_solve.json"
    json.dump(result, open(output, "w"), indent=2)
    print(f"Saved: {output}")


def cmd_build(args):
    """Build a task using Opus 4.6."""
    token = args.token or getenv_dual("TOKEN")
    api_key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")

    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: --api-key required or set ANTHROPIC_API_KEY env var")
        print("Task Builder uses YOUR Opus 4.6 API key.")
        sys.exit(1)

    print(f"Building task: {args.name}")
    print(f"  Environment: {args.env}")
    print(f"  Difficulty: {args.difficulty}")
    print(f"  Proof backend: {args.proof_backend}")
    print(f"  Description: {args.description[:100]}...")
    print()

    # Call Opus to generate the task
    try:
        import urllib.request
        prompt = f"""Generate a verified training task for the "{args.env}" environment.

Task name: {args.name}
Description: {args.description}
Difficulty: {args.difficulty}
Category: {args.category}
Proof backend: {args.proof_backend}
Scoring: {args.scoring}

Generate:
1. A student stub file (the starting code the agent edits)
2. A scoring configuration (sigmoid_center, sigmoid_scale, checks)
3. A proof template if proof_backend is not "none"

Output as JSON with keys: stub_code, scoring_config, proof_template (or null), description, task_id
"""
        payload = json.dumps({
            # ATH-816: model literal sourced from preset module. The
            # spec-generation phase uses the bare-API id (no provider
            # prefix); ``DEFAULT_SPEC_GENERATION_MODEL`` matches.
            "model": DEFAULT_SPEC_GENERATION_MODEL,
            # 200_000 per Aidan 2026-04-23 directive for anything
            # Anthropic-routed. Reasoning + tool-chain headroom. Wall-
            # clock + cost-cap guardrails elsewhere are the actual spend
            # limiter (cf. SpecPipeline.run cost_budget_usd).
            "max_tokens": 200000,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=120).read())
        content = resp.get("content", [{}])[0].get("text", "")
        print("=== Opus 4.6 Output ===")
        print(content[:2000])

        # Try to parse JSON from the response
        try:
            # Find JSON block in response
            import re
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                task_data = json.loads(json_match.group())
                print(f"\nTask generated: {task_data.get('task_id', args.name)}")
                print(f"Stub code: {len(task_data.get('stub_code', ''))} chars")
                print(f"Proof template: {'Yes' if task_data.get('proof_template') else 'No'}")

                # Save to files
                out_dir = args.output or "."
                os.makedirs(out_dir, exist_ok=True)
                if task_data.get("stub_code"):
                    stub_file = os.path.join(out_dir, f"{args.name}.py")
                    open(stub_file, "w").write(task_data["stub_code"])
                    print(f"Saved: {stub_file}")
                if task_data.get("scoring_config"):
                    cfg_file = os.path.join(out_dir, f"{args.name}.json")
                    json.dump(task_data["scoring_config"], open(cfg_file, "w"), indent=2)
                    print(f"Saved: {cfg_file}")
                if task_data.get("proof_template"):
                    ext = ".lean" if args.proof_backend == "lean4" else ".dfy" if args.proof_backend == "dafny" else ".proof"
                    proof_file = os.path.join(out_dir, f"{args.name}{ext}")
                    open(proof_file, "w").write(task_data["proof_template"])
                    print(f"Saved: {proof_file}")
        except (json.JSONDecodeError, ValueError):
            print("\nCould not parse structured output — review the raw text above.")

    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error calling Opus: {e}")
        sys.exit(1)


def _normalize_task_id(tid: str) -> str:
    """Normalize task ID: lowercase + hyphens→underscores."""
    return tid.lower().replace("-", "_")


def _discover_tasks(docker_bin: str, image: str) -> list[dict]:
    """Extract task configs from the container. Returns list of dicts
    with task_slug, solution_file, lean_filename, description, extra_files."""
    import subprocess
    # Dump all config JSONs from the container in one shot
    result = subprocess.run(
        [docker_bin, "run", "--rm", "--user", "root", image, "bash", "-c",
         "for f in /root_data/eval/configs/*.json; do "
         "echo '---ATHANOR_CONFIG_SEP---'; basename \"$f\"; cat \"$f\"; done"],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        return []

    tasks = []
    chunks = result.stdout.split("---ATHANOR_CONFIG_SEP---")[1:]  # skip before first sep
    for chunk in chunks:
        lines = chunk.strip().splitlines()
        if not lines:
            continue
        filename = lines[0].strip()
        json_str = "\n".join(lines[1:])
        try:
            cfg = json.loads(json_str)
        except json.JSONDecodeError:
            continue

        slug = _normalize_task_id(cfg.get("task_id", filename.replace(".json", "")))
        # Resolve solution file from config (kernel_file, sv_file, solution_file, student_file)
        sf = (cfg.get("kernel_file") or cfg.get("sv_file") or
              cfg.get("solution_file") or cfg.get("student_file") or "")
        sf = sf.replace("/workdir/data/", "").lstrip("/")
        lean = cfg.get("lean_file", "").replace("/workdir/data/", "").lstrip("/")
        desc = cfg.get("description", slug)
        tasks.append({
            "task_slug": slug,
            "solution_file": sf,
            "lean_filename": lean,
            "description": desc,
            "config": cfg,
        })
    return tasks


def _build_header(solution_file: str, lean_filename: str) -> str:
    """Build the agent task header. Matches builder's _build_task_header."""
    lines = []
    if solution_file:
        lines.append(f"Edit /workdir/data/{solution_file} to solve this task.")
    if lean_filename:
        verb = "Also complete" if lines else "Complete"
        lines.append(
            f"{verb} the Lean 4 proof in /workdir/data/{lean_filename} — "
            f"replace every `sorry` with a valid proof. Do not modify theorem "
            f"statements (only fill in the proofs); see the file's header "
            f"comment for any per-task tactic restrictions."
        )
    if not lines:
        lines.append("Read files in /workdir/data/ to discover what needs to be done.")
    return "\n".join(lines)


def _save_incremental(output_path: str, model: str, result: dict):
    """Atomically patch/append a single task result to the output file."""
    import threading
    lock = getattr(_save_incremental, "_lock", None)
    if lock is None:
        _save_incremental._lock = threading.Lock()
        lock = _save_incremental._lock

    if result.get("score") is None:
        result = {**result, "score": 0.0}

    with lock:
        existing = {"model": model, "results": []}
        path = __import__("pathlib").Path(output_path)
        if path.exists():
            try:
                existing = json.loads(path.read_text())
            except (json.JSONDecodeError, OSError) as exc:
                # ATH-920: was a silent `pass`. Corrupt existing
                # results.json got silently overwritten with no signal
                # to the customer that prior progress was lost. Now we
                # warn (still continue — that's the existing contract,
                # the alternative is dropping the new result on a
                # corrupt file, which is worse).
                print(
                    f"warning: existing results file at {path} is "
                    f"unreadable ({exc}); overwriting with new run.",
                    file=sys.stderr,
                )

        replaced = False
        for i, r in enumerate(existing.get("results", [])):
            if r.get("task") == result.get("task"):
                existing_zero = r.get("score") in (None, 0.0)
                new_has_calls = result.get("tool_calls_total", 0) > 0
                if existing_zero or new_has_calls:
                    existing["results"][i] = result
                replaced = True
                break
        if not replaced:
            existing.setdefault("results", []).append(result)

        scores = [r.get("score", 0) for r in existing["results"]
                  if r.get("score") is not None]
        existing["summary"] = {
            "total": len(existing["results"]),
            "mean": round(sum(scores) / len(scores), 4) if scores else 0,
        }
        path.write_text(json.dumps(existing, indent=2))


def cmd_evaluate(args):
    """Batch evaluate all tasks in an environment.

    Supports:
      --tasks task_a,task_b   Run only specified tasks
      --patch FILE            Merge results into existing file (resume)
      --all-tasks             Run all tasks (default if no --tasks)
      -o / --output FILE      Output path (default: runs/<model>_run1.json)
    """
    from kairos.runner import Runner
    import subprocess

    token = args.token or getenv_dual("TOKEN")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: ANTHROPIC_API_KEY env var required for evaluate")
        sys.exit(1)

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    # Discover tasks from container configs (config-driven, not hardcoded)
    print(f"Discovering tasks in {args.env}...")
    all_tasks = _discover_tasks(runner.docker_bin, image)
    if not all_tasks:
        print("No task configs found in container.")
        sys.exit(1)

    # Filter tasks if --tasks specified
    if args.tasks:
        requested = {_normalize_task_id(t) for t in args.tasks.split(",")}
        tasks = [t for t in all_tasks if t["task_slug"] in requested]
        missing = requested - {t["task_slug"] for t in tasks}
        if missing:
            print(f"Warning: tasks not found in container: {', '.join(sorted(missing))}")
    else:
        tasks = all_tasks

    print(f"Running {len(tasks)}/{len(all_tasks)} tasks with {args.model}\n")

    # If patching, seed from existing file
    output_path = args.output or f"runs/{args.model.replace('/', '-')}_run1.json"
    if args.patch:
        import shutil
        patch_src = args.patch
        if os.path.exists(patch_src) and patch_src != output_path:
            shutil.copy2(patch_src, output_path)

    # Extract ALL student_data from container (not just one file)
    # This gives the agent access to every file in /workdir/data
    student_tar = subprocess.run(
        [runner.docker_bin, "run", "--rm", image, "tar", "-cf", "-",
         "-C", "/workdir/data", "."],
        capture_output=True, timeout=30,
    )
    student_data_tar = student_tar.stdout if student_tar.returncode == 0 else b""

    for i, task in enumerate(tasks, 1):
        slug = task["task_slug"]
        sf = task["solution_file"]
        lean = task["lean_filename"]
        desc = task["description"]

        header = _build_header(sf, lean)
        full_desc = f"{header}\n\n{desc}" if desc != slug else header

        print(f"[{i}/{len(tasks)}] {slug}")

        # Build task config for runner.run_solve
        # Extract stub code from the student_data tar
        stub_code = ""
        if sf and student_data_tar:
            import tarfile
            import io
            try:
                with tarfile.open(fileobj=io.BytesIO(student_data_tar)) as tar:
                    for member in tar.getmembers():
                        if member.name.lstrip("./") == sf:
                            f = tar.extractfile(member)
                            if f:
                                stub_code = f.read().decode("utf-8", errors="replace")
                            break
            except Exception:  # noqa: BLE001 — tarfile extractfile may fail on truncated archive; stub stays empty
                pass

        # Also extract extra files (lean file, other student files)
        extra_files = {}
        if lean and student_data_tar:
            import tarfile
            import io
            try:
                with tarfile.open(fileobj=io.BytesIO(student_data_tar)) as tar:
                    for member in tar.getmembers():
                        name = member.name.lstrip("./")
                        if name == lean:
                            f = tar.extractfile(member)
                            if f:
                                extra_files[lean] = f.read().decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001 — tarfile extractfile may fail on truncated archive; extra_files entry skipped
                pass

        task_config = {
            "task_slug": slug,
            "task_description": full_desc,
            "stub_code": stub_code,
            "stub_filename": sf or f"{slug}.py",
            "extra_files": extra_files,
        }

        try:
            result = runner.run_solve(image, task_config, model=args.model, api_key=api_key)
            result["task"] = slug
            result["status"] = "PASS"
            _save_incremental(output_path, args.model, result)
            score = result.get("score", 0)
            print(f"  -> score={score:.3f}  time={result.get('time_seconds', 0):.1f}s  turns={result.get('tool_calls_total', 0)}")
        except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
            print(f"  -> FAILED: {e}")
            result = {
                "task": slug,
                "score": 0.0,
                "status": "FAIL",
                "scoring_metadata": {"error": str(e)},
                "student_files": {},
                "tool_calls_total": 0,
                "time_seconds": 0,
                "errors": [str(e)],
            }
            _save_incremental(output_path, args.model, result)

    # Final summary
    try:
        final = json.loads(open(output_path).read())
        results = final.get("results", [])
    except Exception:  # noqa: BLE001 — broad-catch fallback
        results = []

    scores = [r.get("score", 0) for r in results if r.get("score") is not None]
    mean_score = sum(scores) / len(scores) if scores else 0.0

    print(f"\n{'=' * 60}")
    print(f"  Environment: {args.env}")
    print(f"  Model:       {args.model}")
    print(f"  Tasks:       {len(results)}")
    print(f"  Mean:        {mean_score:.3f}")
    print(f"{'=' * 60}")
    print(f"Saved: {output_path}")


def cmd_pull(args):
    """Download an environment tarball from the platform."""
    import urllib.request

    token = args.token or getenv_dual("TOKEN")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    url = f"{platform}/api/download/{args.env}"
    output_path = args.output or f"{args.env}.tar.gz"

    print(f"Downloading {args.env} from {platform}...")

    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": f"athanor-cli/{_VERSION}",
        },
    )

    try:
        resp = urllib.request.urlopen(req, timeout=120)
        data = resp.read()
        with open(output_path, "wb") as f:
            f.write(data)

        size_mb = len(data) / (1024 * 1024)
        if size_mb >= 1.0:
            print(f"Downloaded: {output_path} ({size_mb:.1f} MB)")
        else:
            size_kb = len(data) / 1024
            print(f"Downloaded: {output_path} ({size_kb:.1f} KB)")
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)


def cmd_run_summary(args):
    """One-command pass-rate + cost + elapsed for a completed kairos session.

    Queries Supabase directly (solve_runs + sdk_agent_events); no platform
    API indirection. Prints human text by default; ``--json`` for pipelines.
    """
    from kairos.runs import render_json, render_text, summarize

    summary = summarize(
        args.run_id,
        supabase_url=args.supabase_url,
        supabase_key=args.supabase_key,
    )
    if summary is None:
        print(
            "Error: Supabase unconfigured — set SUPABASE_URL (or "
            "NEXT_PUBLIC_SUPABASE_URL) + SUPABASE_SERVICE_ROLE_KEY, or "
            "pass --supabase-url / --supabase-key."
        )
        sys.exit(1)
    if args.json:
        print(render_json(summary))
    else:
        print(render_text(summary))


def cmd_runs(args):
    """List recent evaluation runs from the platform."""
    import urllib.request

    token = args.token or getenv_dual("TOKEN")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    params = f"limit={args.limit}"
    if args.env:
        params += f"&env={args.env}"
    url = f"{platform}/api/cli/runs?{params}"

    opener = urllib.request.build_opener(_NoRedirectHandler)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": f"athanor-cli/{_VERSION}",
        },
    )

    try:
        resp = opener.open(req, timeout=30)
        data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    # Handle {runs: [...]}, {data: [...]}, or [...]
    if isinstance(data, list):
        runs = data
    elif isinstance(data, dict):
        runs = data.get("runs") or data.get("data") or []
    else:
        runs = []

    if not runs:
        print("No runs found.")
        return

    # Print table
    print(f"  {'Run ID':<10} {'Environment':<20} {'Model':<22} {'Tasks':>5} {'Mean Score':>10} {'Date':<12}")
    print(f"  {'-' * 10} {'-' * 20} {'-' * 22} {'-' * 5} {'-' * 10} {'-' * 12}")
    for r in runs:
        run_id = str(r.get("id", r.get("run_id", "")))[:8]
        env = str(r.get("environment", r.get("env", "")))[:20]
        model = str(r.get("model", ""))[:22]
        tasks = r.get("tasks", r.get("task_count", ""))
        mean = r.get("mean_score", r.get("score", ""))
        date = str(r.get("date", r.get("created_at", r.get("completed_at", ""))))[:12]
        score_str = f"{float(mean):.3f}" if mean != "" and mean is not None else ""
        print(f"  {run_id:<10} {env:<20} {model:<22} {str(tasks):>5} {score_str:>10} {date:<12}")


def cmd_proofs(args):
    """List verified proofs from the platform."""
    import urllib.request

    token = args.token or getenv_dual("TOKEN")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    params = f"limit={args.limit}"
    if args.env:
        params += f"&env={args.env}"
    url = f"{platform}/api/cli/proofs?{params}"

    opener = urllib.request.build_opener(_NoRedirectHandler)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": f"athanor-cli/{_VERSION}",
        },
    )

    try:
        resp = opener.open(req, timeout=30)
        data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    # Handle {proofs: [...]}, {data: [...]}, or [...]
    if isinstance(data, list):
        proofs = data
    elif isinstance(data, dict):
        proofs = data.get("proofs") or data.get("data") or []
    else:
        proofs = []

    if not proofs:
        print("No proofs found.")
        return

    # Print table
    print(f"  {'Task':<30} {'Environment':<20} {'Model':<22} {'Score':>7} {'Proof Backend':<14}")
    print(f"  {'-' * 30} {'-' * 20} {'-' * 22} {'-' * 7} {'-' * 14}")
    for p in proofs:
        task = str(p.get("task", p.get("task_slug", "")))[:30]
        env = str(p.get("environment", p.get("env", "")))[:20]
        model = str(p.get("model", ""))[:22]
        score = p.get("score", "")
        backend = str(p.get("proof_backend", p.get("backend", "")))[:14]
        score_str = f"{float(score):.3f}" if score != "" and score is not None else ""
        print(f"  {task:<30} {env:<20} {model:<22} {score_str:>7} {backend:<14}")


def cmd_calibrate(args):
    """Fit sigmoid parameters from a run file."""
    from kairos.calibrate import calibrate_run_file

    try:
        center, scale = calibrate_run_file(args.run, metric=args.metric)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    print(f"Fitted sigmoid for {args.run} (metric: {args.metric}):")
    print(f"  sigmoid_center: {center}")
    print(f"  sigmoid_scale:  {scale}")
    print()
    print("Add to your task config scoring block:")
    print(f'  "scoring": {{')
    print(f'    "sigmoid_center": {center},')
    print(f'    "sigmoid_scale": {scale}')
    print(f'  }}')


def cmd_stats(args):
    """Show aggregate statistics for one or more run files."""
    from kairos.stats import aggregate_runs

    try:
        summary = aggregate_runs(args.runs)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    overall = summary["overall"]
    print(f"{'=' * 60}")
    print(f"  Aggregate Stats ({summary['num_runs']} run file(s), {summary['num_tasks']} tasks)")
    print(f"{'=' * 60}")
    print(f"  Count:  {overall['count']}")
    print(f"  Mean:   {overall['mean']:.4f}")
    print(f"  Std:    {overall['std']:.4f}")
    print(f"  Min:    {overall['min']:.4f}")
    print(f"  Max:    {overall['max']:.4f}")
    print(f"  P25:    {overall['p25']:.4f}")
    print(f"  P50:    {overall['p50']:.4f}")
    print(f"  P75:    {overall['p75']:.4f}")
    print(f"  P90:    {overall['p90']:.4f}")
    if args.per_task:
        print(f"\n  Per-task:")
        for task, stats in sorted(summary["per_task"].items()):
            print(f"    {task:<30} n={stats['count']:<3} mean={stats['mean']:.3f} std={stats['std']:.3f}")


def cmd_compare(args):
    """Diff two run files."""
    from kairos.compare import compare_runs

    try:
        diff = compare_runs(args.run_a, args.run_b)
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    print(f"{'=' * 60}")
    print(f"  A: {args.run_a}")
    print(f"  B: {args.run_b}")
    print(f"{'=' * 60}")
    print(f"  Mean A:     {diff['mean_a']:.4f}")
    print(f"  Mean B:     {diff['mean_b']:.4f}")
    print(f"  Mean delta: {diff['mean_delta']:+.4f}")
    print(f"  Improved:   {len(diff['improved'])} tasks")
    print(f"  Regressed:  {len(diff['regressed'])} tasks")
    print(f"  Unchanged:  {len(diff['unchanged'])} tasks")
    print()
    print(f"  {'Task':<30} {'A':>8} {'B':>8} {'Δ':>9}")
    print(f"  {'-' * 30} {'-' * 8} {'-' * 8} {'-' * 9}")
    for row in diff["tasks"]:
        task = row["task"][:30]
        sa = f"{row['score_a']:.3f}" if row.get("score_a") is not None else "—"
        sb = f"{row['score_b']:.3f}" if row.get("score_b") is not None else "—"
        delta = row.get("delta")
        if delta is None:
            delta_str = "—"
        elif delta > 0:
            delta_str = f"+{delta:.3f}"
        elif delta < 0:
            delta_str = f"{delta:.3f}"
        else:
            delta_str = "0.000"
        print(f"  {task:<30} {sa:>8} {sb:>8} {delta_str:>9}")


def cmd_eval_status(args):
    """Show current state of all eval runs in an env's runs/ directory.

    Auto-discovers active evaluate.py processes via pgrep, joins with run
    files in <env_dir>/runs/, prints per-file status: tasks count, mean
    score, % below 0.5, count of ban-rejected results, last touch time,
    ALIVE marker if a live patch process is running.
    """
    from pathlib import Path
    from kairos.eval_status import render_status

    env_dir = Path(args.env_dir).resolve()
    runs_dir = env_dir / "runs"
    for line in render_status(runs_dir, verbose=args.verbose):
        print(line)


def cmd_preflight(args):
    """Run preflight checks — container image, model reachability, or both."""
    if not args.env and not args.fleet:
        print("Error: pass --env <image> for container preflight and/or --fleet <config|env_dir> for model preflight")
        sys.exit(1)

    exit_code = 0

    # Container preflight (if requested)
    if args.env:
        from kairos.preflight import preflight

        image = f"ghcr.io/athanor-ai/{args.env}:latest" if "/" not in args.env else args.env
        print(f"[container] Running preflight checks on {image}...\n")

        try:
            result = preflight(image)
        except RuntimeError as e:
            print(f"[container] Error: {e}")
            sys.exit(1)

        for check in result["checks"]:
            status = "✓" if check["passed"] else "✗"
            color = "\033[32m" if check["passed"] else "\033[31m"
            reset = "\033[0m"
            print(f"  {color}{status}{reset} {check['name']:<25} {check['message']}")

        print()
        if result["passed"]:
            print(f"\033[32m[container] All checks passed.\033[0m Container ready.")
            print(f"[container] Tasks available: {result['task_count']}")
        else:
            print(f"\033[31m[container] Preflight failed.\033[0m Fix the issues above before using this container.")
            exit_code = 1

    # Fleet preflight (if requested)
    if args.fleet:
        from kairos.preflight_fleet import main as fleet_main
        print()
        fleet_argv = [args.fleet]
        if args.fleet_task:
            fleet_argv.append(args.fleet_task)
        for m in args.extra_model:
            fleet_argv.extend(["--extra-model", m])
        fleet_argv.extend(["--timeout", str(args.timeout)])
        fleet_rc = fleet_main(fleet_argv)
        if fleet_rc != 0:
            exit_code = fleet_rc

    sys.exit(exit_code)


def _cmd_simple_prove(args) -> int:
    """ATH-697 — `kairos simple-prove "..."` CLI for the free-tier flow.

    Returns shell exit code: 0 on proved, 1 on disproved/undecided/no-match.
    """
    from kairos import simple_prove_template
    from kairos.verticals import pythia

    if args.list_patterns:
        for pid in pythia.list_patterns():
            print(pid)
        return 0
    if not args.hypothesis:
        print(
            "error: hypothesis is required (or pass --list-patterns)",
            file=sys.stderr,
        )
        return 2

    result = simple_prove_template(args.hypothesis, show_lean=args.show_lean)
    if args.json_out:
        import json as _json
        payload = {
            "summary": result.summary,
            "proved": result.proved,
            "pattern_id": result.pattern_id,
            "used_llm": result.used_llm,
            "spec_path": str(result.spec_path) if result.spec_path else None,
        }
        print(_json.dumps(payload))
    else:
        print(result.summary)
    return 0 if result.proved else 1


def cmd_lint(args):
    """Lint a Lean file for banned constructs."""
    from kairos.lint import lint_file

    result = lint_file(args.file)
    if "error" in result:
        print(f"Error: {result['error']}")
        sys.exit(1)

    if result["clean"]:
        print(f"\033[32m✓\033[0m {args.file}: no violations")
        if result["sorry_count"] > 0:
            print(f"  (contains {result['sorry_count']} sorry — these will reduce your score but are not banned)")
    else:
        print(f"\033[31m✗\033[0m {args.file}: {len(result['violations'])} violation(s)")
        for v in result["violations"]:
            print(f"  line {v['line']}: {v['message']}")
            print(f"    → {v['text']}")
        sys.exit(1)


def cmd_estimate(args):
    """Estimate API cost for an evaluation run."""
    from kairos.estimate import estimate_cost

    result = estimate_cost(args.model, args.tasks)
    if "error" in result:
        print(f"Error: {result['error']}")
        sys.exit(1)

    print(f"{'=' * 60}")
    print(f"  Cost Estimate: {result['model']} × {result['num_tasks']} tasks")
    print(f"{'=' * 60}")
    print(f"  Input tokens:   {result['input_tokens']:,}")
    print(f"  Output tokens:  {result['output_tokens']:,}")
    print(f"  Input cost:     ${result['input_cost_usd']:.4f}")
    print(f"  Output cost:    ${result['output_cost_usd']:.4f}")
    print(f"  {'─' * 40}")
    print(f"  Total:          ${result['total_cost_usd']:.4f}")
    print(f"  Per task:       ${result['cost_per_task_usd']:.4f}")
    print()
    print(f"  Pricing: ${result['pricing_per_1m']['input']}/1M input, "
          f"${result['pricing_per_1m']['output']}/1M output")
    print(f"  Assumes ~{2500} output tokens + ~{4000} input tokens per task, "
          f"with 2.5x retry multiplier.")


def cmd_task_info(args):
    """Show detailed info about a task."""
    from kairos.env import Environment

    try:
        env = Environment(
            args.env,
            image=f"ghcr.io/athanor-ai/{args.env}:latest",
        )
    except Exception as e:  # noqa: BLE001 — stderr-warned + recovered
        print(f"Error: {e}")
        sys.exit(1)

    if args.task not in env.tasks:
        print(f"Error: task '{args.task}' not found in {args.env}")
        print(f"Available tasks: {', '.join(env.tasks[:10])}")
        if len(env.tasks) > 10:
            print(f"  ... and {len(env.tasks) - 10} more")
        sys.exit(1)

    config = env.get_task_config(args.task)
    raw_config = env._load_task_config(args.task)

    print(f"{'=' * 60}")
    print(f"  Task: {config.task_id}")
    print(f"  Environment: {args.env}")
    print(f"{'=' * 60}")
    print(f"  Difficulty: {config.difficulty}")
    print(f"  Category:   {raw_config.get('category', '?')}")
    if config.solution_file:
        print(f"  Stub file:  {config.solution_file}")
    if config.lean_file:
        print(f"  Lean file:  {config.lean_file}")
    # Scoring configuration is intentionally not printed — the container
    # is authoritative. Customers fit their own via `athanor calibrate`.
    print()
    print(f"  Description:")
    for line in (config.description or "").split("\n"):
        print(f"    {line}")


def cmd_bootstrap(args):
    """Dispatch bootstrap subcommands."""
    from kairos import bootstrap as _bs
    sub = getattr(args, "bootstrap_sub", None)
    if sub == "set":
        _bs.cmd_bootstrap_set(args)
    elif sub == "refresh-ghcr":
        _bs.cmd_bootstrap_refresh_ghcr(args)
    elif sub == "start":
        _bs.cmd_bootstrap_start(args)
    elif sub == "stop":
        _bs.cmd_bootstrap_stop(args)
    elif sub == "status":
        _bs.cmd_bootstrap_status(args)
    elif sub == "reset":
        _bs.cmd_bootstrap_reset(args)
    else:
        _bs.cmd_bootstrap(args)


def cmd_config(args):
    """Manage configuration."""
    config_dir = os.path.expanduser("~/.athanor")
    config_file = os.path.join(config_dir, "config.json")
    os.makedirs(config_dir, exist_ok=True)

    config = {}
    if os.path.exists(config_file):
        config = json.load(open(config_file))

    if args.set:
        key, _, value = args.set.partition("=")
        config[key] = value
        json.dump(config, open(config_file, "w"), indent=2)
        print(f"Set {key}")
    else:
        for k, v in config.items():
            display = v[:8] + "..." if len(str(v)) > 20 else v
            print(f"  {k}={display}")


_LITELLM_FRIENDLY_HINT = (
    "Error: kairos requires `litellm` but it is not importable.\n"
    "  litellm has been a core dependency since athanor-kairos 0.4.1;\n"
    "  reinstall the SDK to pull it in:\n"
    "      pip install --upgrade 'athanor-sdk>=0.4.1'\n"
    "  Or install litellm directly:\n"
    "      pip install litellm\n"
    "  (If you are on 0.4.0 or earlier, litellm was an optional extra:\n"
    "   pip install 'athanor-sdk[multi-model]' will also work.)"
)


def _check_litellm_for_command(command: str | None) -> None:
    """Top-level guard for CLI commands that need litellm at runtime.

    ATH-652: a stale demo install (pre-0.4.1) silently failed when the
    `kairos` CLI tried to import litellm mid-flight, surfacing as a
    cryptic mid-iter `proposer_error` rather than a clear missing-dep
    message. This guard fires the friendly hint up-front for any
    command path that ultimately needs `litellm.completion` so the
    failure mode is "you see the fix at startup", not "kairos crashes
    300 lines into a session". Pure docstring/error UX; no behaviour
    change for installs that already have litellm.

    Maintained as a positive list of LITELLM-USING commands rather
    than a free-list because litellm-free commands vastly outnumber
    LLM-driven ones (DB read commands, lint, spec data-transform,
    config, bootstrap, trace replay, etc. — about 20 of them) so the
    free-list shape kept missing legitimate command paths.
    """
    LITELLM_USING = {
        "score", "solve", "prove",
        "sv-prove", "sv-inv", "sv-swarm", "sv-cycle", "sv-multi", "sv-hb",
        "cegar", "build", "evaluate", "preflight",
    }
    if command not in LITELLM_USING:
        return
    try:
        import litellm  # noqa: F401 — presence check only
    except ImportError:
        print(_LITELLM_FRIENDLY_HINT, file=sys.stderr)
        sys.exit(2)


def _build_parser():
    """Build the kairos CLI argument parser.

    Extracted from main() so tests can validate subcommand parsing
    without running the full dispatch loop (ATH-923).
    """
    parser = argparse.ArgumentParser(
        prog="kairos",
        description="Kairos — formal verification as agentic training signal",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"kairos {_VERSION}",
    )
    sub = parser.add_subparsers(dest="command")

    # run
    p_run = sub.add_parser("run", help="Start the self-hosted runner")
    p_run.add_argument("--token", help="Sync token (or set ATHANOR_TOKEN)")
    p_run.add_argument("--platform", default="https://tahoe.athanor-ai.com", help="Platform URL")
    p_run.add_argument("--name", default="default", help="Runner name")

    # run-summary
    p_run_summary = sub.add_parser(
        "run-summary",
        help="Summary of one kairos session (pass-rate, cost, elapsed)",
    )
    p_run_summary.add_argument("run_id", help="kairos session/run id")
    p_run_summary.add_argument(
        "--json", action="store_true",
        help="Machine-readable JSON instead of plain text",
    )
    p_run_summary.add_argument(
        "--supabase-url", default=None,
        help="Supabase URL (defaults to SUPABASE_URL / NEXT_PUBLIC_SUPABASE_URL env)",
    )
    p_run_summary.add_argument(
        "--supabase-key", default=None,
        help="Supabase service-role key (defaults to SUPABASE_SERVICE_ROLE_KEY env)",
    )

    # score
    p_score = sub.add_parser("score", help="Score a file against a task")
    p_score.add_argument("--token", help="Sync token")
    p_score.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_score.add_argument("--env", required=True, help="Environment slug")
    p_score.add_argument("--task", required=True, help="Task slug")
    p_score.add_argument("--file", required=True, help="Path to student file")

    # solve
    p_solve = sub.add_parser(
        "solve",
        help="Solve a task — legacy (--env/--task/--model) OR core chassis (--vertical/--target, ATH-418)",
    )
    # Legacy path flags (single-shot via Runner). `--env` and `--task`
    # are required for legacy but dropped when `--vertical` is set.
    # cmd_solve dispatches based on whether --vertical was passed;
    # _cmd_solve_legacy validates presence of --env and --task.
    p_solve.add_argument("--token", help="Sync token (legacy path only)")
    p_solve.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_solve.add_argument("--env", help="Environment slug (required for legacy; ignored with --vertical)")
    p_solve.add_argument("--task", help="Task slug (required for legacy; ignored with --vertical)")
    p_solve.add_argument("--model", default=DEFAULT_RUNNER_MODEL, help="Model (legacy path only)")
    p_solve.add_argument("--output", "-o", help="Output JSON path (legacy path only)")
    # ATH-418 Phase 4 core-chassis flags — forwarded verbatim to
    # $ATHANOR_BUILDER_ROOT/solve/core/run.sh when --vertical is set.
    p_solve.add_argument("--vertical", default=None,
                         help="Registered vertical name in solve/core/ (e.g. sysverilog-fleet, toy). Switches to core chassis; legacy flags ignored.")
    p_solve.add_argument("--target", default=None,
                         help="Task slug / theorem label / spec file for the vertical (core-chassis only)")
    p_solve.add_argument("--workdir", default=None,
                         help="Run workdir for core chassis (default: solve/core/runs/<stamp>-<target>)")
    p_solve.add_argument("--verifier", default="",
                         help="Comma-separated backend names (ebmc, lean, hypothesis, ...) for core chassis")
    p_solve.add_argument("--dry-run", dest="dry_run", action="store_true",
                         help="Core chassis only: no real verifier / LLM calls")
    p_solve.add_argument("--max-cost", dest="max_cost", type=float, default=None,
                         help="LLM cost cap in USD (core chassis only)")
    p_solve.add_argument("--max-iter", dest="max_iter", type=int, default=None,
                         help="Max refinement iterations (core chassis only)")
    p_solve.add_argument("--skip-phases", dest="skip_phases", default="",
                         help="Comma-separated phase names to skip (core chassis only)")
    # Companion to --skip-phases: inverse set; pre-seeds _DONE markers
    # for every phase NOT listed. Chassis (athanor-builder #131) enforces
    # mutual exclusion with --skip-phases.
    p_solve.add_argument("--only-phases", dest="only_phases", default="",
                         help="Comma-separated phase names to run; pre-seeds "
                              "_DONE markers for all others. Mutually exclusive "
                              "with --skip-phases (core chassis only).")
    p_solve.add_argument("--list-verticals", dest="list_verticals", action="store_true",
                         help="Enumerate registered verticals + exit (core chassis only)")
    # ATH-418 Q4 resume/force (asabi athanor-builder#117) — mutually exclusive.
    solve_resume = p_solve.add_mutually_exclusive_group()
    solve_resume.add_argument("--resume", action="store_true",
                              help="Resume an existing workdir; phases with _DONE markers skip (core chassis only)")
    solve_resume.add_argument("--force", action="store_true",
                              help="Wipe non-empty workdir before run (core chassis only)")
    # ATH-426 QC30: --extra KEY=VALUE (repeatable) → forwarded verbatim
    # for chassis ctx.extra. Required by real SV tasks (sv_file, top_module,
    # bound, timeout_sec).
    p_solve.add_argument("--extra", action="append", default=[], metavar="KEY=VALUE",
                         help="Pass key=value pair into chassis ctx.extra. Repeat for multiple (core chassis only). Example: --extra sv_file=/tmp/x.sv --extra top_module=foo")
    # ATH-315 follow-up: named --spec-config-path convenience shortcut for
    # ctx.extra['spec_config_path']. Exists because customers running the
    # chassis-wired Phase -2 validator need to point at a task config JSON;
    # --extra spec_config_path=... works too, but the named flag is more
    # discoverable in --help and CI scripts.
    p_solve.add_argument("--spec-config-path", dest="spec_config_path", default=None,
                         metavar="PATH",
                         help="Path to task_config.json for chassis Phase -2 spec_validate (core chassis only). Shortcut for --extra spec_config_path=PATH.")
    # ATH-394: auto-pipe opt-out. Default behaviour pipes subprocess
    # stdout through kairos.cli_renderer for ANSI-rendered live trace;
    # --raw emits JSONL verbatim for customers scripting against the
    # output or piping into their own renderer.
    p_solve.add_argument("--raw", action="store_true",
                         help="Emit raw JSONL on stdout instead of "
                              "auto-rendering through cli_renderer. Use when "
                              "piping into your own tooling or capturing events "
                              "for replay. Non-TTY detection already downgrades "
                              "ANSI → plain text automatically; --raw skips the "
                              "renderer entirely (core chassis only).")

    # prove (ATH-513) — unified NL-friendly entry point. Auto-dispatches
    # to the right underlying tool based on spec file extension, OR
    # with --nl runs NL → IntentV1 → SpecPipeline.run → Verdict in one go.
    p_prove = sub.add_parser(
        "prove",
        help="Prove a spec end-to-end (auto-dispatches: .sv → sv-prove/cegar, "
             ".py → neuron-verify, OR --nl free-text → IntentV1 → Verdict)",
    )
    # `spec` positional is optional: required for file-dispatch, omitted
    # for --nl entry (intent constructed from hypothesis + vertical).
    p_prove.add_argument("spec", nargs="?", default=None,
                         help="Path to spec file (.sv, .py, or dir). "
                              "Omit when using --nl.")
    p_prove.add_argument("--top", default=None,
                         help="For .sv: top module name. Defaults to the first "
                              "module declared in the file.")
    p_prove.add_argument("--bound", type=int, default=10,
                         help="For .sv: BMC bound k (default: 10)")
    p_prove.add_argument("--with-cegar", action="store_true",
                         help="For .sv: run the CEGAR LLM loop instead of "
                              "pure EBMC. Requires ANTHROPIC_API_KEY.")
    p_prove.add_argument("--max-iter", type=int, default=3,
                         help="For --with-cegar: max CEGAR iterations (default: 3)")
    # NL-entry mode: hypothesis → IntentV1 → SpecPipeline.run → Verdict.
    p_prove.add_argument("--nl", dest="nl_hypothesis", default=None,
                         help="Free-text hypothesis (e.g. 'prove reno_cca.cwnd "
                              "never drops below MSS on reset'). Triggers "
                              "NL-entry mode: kairos.verticals.nl_frontend."
                              "nl_to_intent() → SpecPipeline.run → Verdict. "
                              "Requires --vertical + --target-file; "
                              "--target-name is auto-inferred from --spec if "
                              "omitted.")
    p_prove.add_argument("--vertical", dest="nl_vertical", default="ebmc",
                         choices=("ebmc", "lean"),
                         help="For --nl: which nl_frontend template + tier "
                              "to dispatch (default: ebmc). "
                              "Additional verticals register via "
                              "kairos.verticals.nl_frontend._VERTICAL_TEMPLATES.")
    p_prove.add_argument("--target-file", dest="nl_target_file", default=None,
                         help="For --nl: path to the spec/kernel/proof file "
                              "the IntentV1 should reference. Defaults to "
                              "the value of `spec` if omitted.")
    p_prove.add_argument("--target-name", dest="nl_target_name", default=None,
                         help="For --nl: logical name of the target (property, "
                              "theorem, kernel). Optional.")
    p_prove.add_argument("--cost-budget-usd", type=float, default=None,
                         help="Optional cumulative LLM spend cap. Halts with "
                              "budget_exhausted escalation if exceeded. "
                              "Reports spend on every run regardless.")
    p_prove.add_argument("--planner-model", dest="nl_planner_model",
                         default=None,
                         help="ATH-833: For --nl: override the orchestrator's "
                              "tier-planning LLM model. Litellm-format model "
                              "id (e.g. 'openai/kimi-k2.5', "
                              "'azure_ai/kimi-k2.6-1', 'gemini/gemini-3-flash'). "
                              "When omitted, uses model_presets."
                              "DEFAULT_PLANNER_MODEL. Useful when the default "
                              "model's provider returns non-JSON to the "
                              "strict-JSON tier-planning prompt — pick a "
                              "JSON-reliable model and the orchestrator's "
                              "rationale appears on /solve-runs/[id] "
                              "instead of the orchestrator_fallback banner.")  # noqa: model-literal
    p_prove.add_argument("-v", "--verbose", action="store_true",
                         help="Per-property verdict table + diagnostics")

    # sv-prove — thin CLI over kairos.sv.prove. Zero LLM, zero agent;
    # just EBMC with a terminal-friendly frontend for one-shot verification.
    p_sv_prove = sub.add_parser(
        "sv-prove",
        help="Verify a SystemVerilog spec with EBMC (no LLM, no agent)",
    )
    p_sv_prove.add_argument("--spec", required=True,
                            help="Path to SystemVerilog spec file")
    p_sv_prove.add_argument("--top", "--top-module", dest="top", required=True,
                            help="Top module whose properties EBMC should prove")
    p_sv_prove.add_argument("--bound", type=int, default=10,
                            help="BMC bound k (default: 10)")
    p_sv_prove.add_argument(
        "--mode", choices=("bmc", "k_induction"), default="bmc",
        help="Proof engine. 'bmc' (default) = bounded model check, "
             "PROVED holds up to --bound. 'k_induction' = step-case "
             "induction, PROVED is unbounded.",
    )
    p_sv_prove.add_argument(
        "--reset", default=None,
        help="Reset signal expression (e.g. 'reset', 'rst', 'rst_n'). "
             "Passed to EBMC as `--reset <expr>` so the initial state "
             "is constrained by the reset assertion. Omit when "
             "verifying invariants that must hold from any state.",
    )
    p_sv_prove.add_argument("--timeout-sec", dest="timeout_sec", type=int, default=60,
                            help="EBMC wall-clock timeout (default: 60)")
    p_sv_prove.add_argument("--transcript", action="store_true",
                            help="Dump the raw EBMC stdout transcript to stderr "
                                 "(includes solver chatter). Use for deep "
                                 "debugging; normally redundant with --verbose.")
    p_sv_prove.add_argument("-v", "--verbose", action="store_true",
                            help="Also print per-property verdicts / EBMC transcript")

    # sv-invariants (ATH-411) — reverse-mutation-kill invariant discovery.
    p_sv_inv = sub.add_parser(
        "sv-invariants",
        help="Discover missing invariants via reverse-mutation-kill (LLM proposer)",
    )
    p_sv_inv.add_argument("--spec", required=True,
                          help="Path to SystemVerilog spec file")
    p_sv_inv.add_argument("--top", "--top-module", dest="top", required=True,
                          help="Top module EBMC should verify")
    p_sv_inv.add_argument("--bound", type=int, default=10,
                          help="BMC bound k (default: 10)")
    p_sv_inv.add_argument("--max-mutants", dest="max_mutants", type=int, default=20,
                          help="Cap on mutants enumerated (default: 20)")
    p_sv_inv.add_argument("--max-proposals-per-mutant", dest="max_proposals_per_mutant",
                          type=int, default=2,
                          help="Retry budget per surviving mutant (default: 2)")
    p_sv_inv.add_argument("--timeout-sec", dest="timeout_sec", type=int, default=60,
                          help="EBMC wall-clock timeout per invocation (default: 60)")
    p_sv_inv.add_argument("--smv", action="store_true",
                          help="Treat spec as NuSMV (uses SMV operator set)")
    # Example model names in the help text below are documentation,
    # not code-level model selections (ATH-816).
    p_sv_inv.add_argument(
        "--model", default=None,  # noqa: model-literal
        help="LLM model ID for the proposer (default: anthropic/claude-sonnet-4-6). "
             "Use `openai/kimi-k2.5` (~10x cheaper) or `gemini/gemini-2.5-flash` "
             "(~30x cheaper) for experiments. Reasoning models get model-aware "
             "max_tokens via ATH-399.",
    )

    # sv-swarm (ATH-409) — state-swarm EBMC bug-hunting.
    p_sv_swarm = sub.add_parser(
        "sv-swarm",
        help="State-swarm BMC chaining (cover → init-state → re-run, no LLM)",
    )
    p_sv_swarm.add_argument("--spec", required=True,
                            help="Path to SystemVerilog spec file")
    p_sv_swarm.add_argument("--top", "--top-module", dest="top", required=True,
                            help="Top module EBMC should verify")
    p_sv_swarm.add_argument(
        "--covers", required=True,
        help="SV expressions to check reachability for, separated by `;;`. "
             "Example: --covers 'cwnd == 8''d1;;loss == 1''b1'",
    )
    p_sv_swarm.add_argument("--bound", type=int, default=10,
                            help="Stage-1 BMC bound (cover reachability) (default: 10)")
    p_sv_swarm.add_argument("--chain-depth", dest="chain_depth", type=int, default=None,
                            help="Stage-2 BMC bound (post-splice re-run). "
                                 "Defaults to --bound.")
    p_sv_swarm.add_argument("--timeout-sec", dest="timeout_sec", type=int, default=60,
                            help="EBMC wall-clock timeout per invocation (default: 60)")

    # sv-cycle-swarm (ATH-410) — cycle-indexed assertion variants.
    p_sv_cycle = sub.add_parser(
        "sv-cycle-swarm",
        help="Cycle-indexed EBMC variants (cycle_count == k gating, no LLM)",
    )
    p_sv_cycle.add_argument("--spec", required=True,
                            help="Path to SystemVerilog spec file")
    p_sv_cycle.add_argument("--top", "--top-module", dest="top", required=True,
                            help="Top module EBMC should verify")
    p_sv_cycle.add_argument(
        "--cycles", required=True,
        help="Comma-separated integer cycle values, e.g. --cycles 3,7,10,15",
    )
    p_sv_cycle.add_argument("--bound", type=int, default=None,
                            help="BMC depth (default: max(cycles) + 2)")
    p_sv_cycle.add_argument("--timeout-sec", dest="timeout_sec", type=int, default=60,
                            help="EBMC wall-clock timeout per invocation (default: 60)")
    p_sv_cycle.add_argument("--counter-width", dest="counter_width", type=int, default=32,
                            help="Bit-width of the spliced cycle counter "
                                 "(default: 32). Narrow to tighten EBMC SAT scope.")

    # sv-multi (ATH-412a) — multi-abstraction verification with sandwich rule.
    p_sv_multi = sub.add_parser(
        "sv-multi",
        help="Multi-abstraction verification (YAML spec + sandwich rule, no LLM)",
    )
    p_sv_multi.add_argument(
        "--spec", dest="spec_yaml", required=True,
        help="Path to multi-abstraction YAML spec file",
    )

    # sv-hb-graph (ATH-412 Part B) — HB-graph + cycle detection + SVA witness.
    p_sv_hb = sub.add_parser(
        "sv-hb-graph",
        help="Happens-before graph + PO-violation detection (no LLM)",
    )
    p_sv_hb.add_argument("--spec", required=True,
                         help="Path to SystemVerilog source file")
    p_sv_hb.add_argument("--clock", default="clk",
                         help="Clock signal name for emitted SVA "
                              "(default: 'clk')")
    p_sv_hb.add_argument("--disable-iff", dest="disable_iff", default=None,
                         metavar="SIGNAL",
                         help="Disable-iff signal (e.g. 'rst'); wraps emitted "
                              "SVA in disable iff (SIGNAL) to avoid spurious "
                              "reset-time assertion fires")
    p_sv_hb.add_argument("--out-sva", dest="out_sva", default=None,
                         metavar="PATH",
                         help="Write emitted SVA witnesses to PATH "
                              "(default: stdout)")

    # cegar (ATH-398) — Mode B customer-port CEGAR loop via builder's cegar.sh
    p_optimize = sub.add_parser(
        "optimize",
        help="Optimize an RTL block — propose area/power improvements + formally verify equivalence",
    )
    p_optimize.add_argument("rtl", help="Path to gold RTL file (.v or .sv)")
    p_optimize.add_argument("--deps", nargs="*", default=[], help="Dependency RTL files")
    p_optimize.add_argument("--params", default="", help="Parameter overrides (KEY=VAL,KEY=VAL)")
    p_optimize.add_argument("--model", default="anthropic/claude-sonnet-4-6", help="LLM model for proposer")
    p_optimize.add_argument("--max-proposals", type=int, default=3, help="Number of optimization candidates")
    p_optimize.add_argument("--timeout", type=int, default=1800, help="Verification timeout (seconds)")
    p_optimize.add_argument("--config", default=None, help="Path to kairos.yaml flow config")

    p_spec_refine = sub.add_parser(
        "spec-refine",
        help="Iterative spec refinement — discover formal specs via counterexample-guided loop",
    )
    p_spec_refine.add_argument("dut", help="Path to DUT RTL file (.v or .sv)")
    p_spec_refine.add_argument("--spec", required=True, help="Path to initial classifier spec file")
    p_spec_refine.add_argument("--engine", default="ebmc", help="Verification engine (ebmc, or customer-registered)")
    p_spec_refine.add_argument("--model", default="anthropic/claude-sonnet-4-6", help="LLM model for spec refinement")
    p_spec_refine.add_argument("--max-iterations", type=int, default=10, help="Max refinement iterations")
    p_spec_refine.add_argument("--top", default="", help="Top module name")
    p_spec_refine.add_argument("--timeout", type=int, default=600, help="Total wall-clock timeout (seconds)")

    p_cegar = sub.add_parser(
        "cegar",
        help="CEGAR loop — spec-layer hypothesis strengthening (sysverilog, Mode B)",
    )
    p_cegar.add_argument("--spec", required=True,
                         help="Path to SystemVerilog spec file")
    p_cegar.add_argument("--top", "--top-module", dest="top", required=True,
                         help="Top module whose properties EBMC should prove")
    p_cegar.add_argument("--bound", type=int, default=None,
                         help="BMC bound k (default: 10)")
    p_cegar.add_argument("--max-iter", dest="max_iter", type=int, default=None,
                         help="Max CEGAR iterations (default: 5)")
    p_cegar.add_argument("--budget-usd", dest="budget_usd", type=float, default=None,
                         help="LLM cost cap in USD (default: 5.0)")
    p_cegar.add_argument("--walltime-sec", dest="walltime_sec", type=int, default=None,
                         help="Wall-time cap in seconds (default: 600)")
    p_cegar.add_argument("--workdir", default=None,
                         help="Artifact directory (default: tempdir under $TMPDIR)")
    p_cegar.add_argument("--auto-accept-environmental",
                         dest="auto_accept_environmental", action="store_true",
                         help="Non-interactive: auto-accept environmental-class candidates")
    p_cegar.add_argument("--clk", default=None,
                         help="Clock signal name (default: clk)")
    p_cegar.add_argument(
        "--reset", default=None,
        help="Reset signal expression (e.g. 'reset', 'rst', 'rst_n'). "
             "Passed through to EBMC's `--reset <expr>`. Omit (or pass "
             "the empty string) to drop the reset constraint and verify "
             "invariants from any state. CEGAR defaults to 'reset' on "
             "the builder side; pass this flag for non-canonical names.",
    )
    p_cegar.add_argument("-v", "--verbose", action="store_true",
                         help="Stream per-iteration progress to stderr "
                              "(ebmc verdict + proposer candidate + decision) "
                              "instead of waiting silently for the final summary")

    # build
    p_build = sub.add_parser("build", help="Build a task using Opus 4.6")
    p_build.add_argument("--token", help="Sync token")
    p_build.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_build.add_argument("--api-key", help="Anthropic API key for Opus 4.6")
    p_build.add_argument("--env", required=True, help="Environment slug")
    p_build.add_argument("--name", required=True, help="Task name (snake_case)")
    p_build.add_argument("--description", required=True, help="What the agent should do")
    p_build.add_argument("--difficulty", default="medium", choices=["easy", "medium", "hard"])
    p_build.add_argument("--category", default="implementation",
                         choices=["bug_fix", "implementation", "verification", "optimization", "translation"])
    p_build.add_argument("--proof-backend", default="none",
                         choices=["none", "lean4", "dafny", "ebmc", "verus"])
    p_build.add_argument("--scoring", default="property_tests",
                         choices=["property_tests", "simulation", "compilation", "output_match"])
    p_build.add_argument("--output", help="Output directory for generated files")

    # evaluate
    p_eval = sub.add_parser("evaluate", help="Batch evaluate all tasks in an environment")
    p_eval.add_argument("--token", help="Sync token")
    p_eval.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_eval.add_argument("--env", required=True, help="Environment slug")
    p_eval.add_argument("--model", default=DEFAULT_RUNNER_MODEL, help="Model to use")
    p_eval.add_argument("--output", "-o", help="Output JSON path")
    p_eval.add_argument("--tasks", help="Comma-separated task IDs (default: all)")
    p_eval.add_argument("--all-tasks", action="store_true", help="Run all tasks (default)")
    p_eval.add_argument("--patch", help="Merge results into existing run file (resume)")

    # pull
    p_pull = sub.add_parser("pull", help="Download an environment tarball")
    p_pull.add_argument("--token", help="Sync token")
    p_pull.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_pull.add_argument("--env", required=True, help="Environment slug")
    p_pull.add_argument("--output", "-o", help="Output path (default: {env}.tar.gz)")

    # runs
    p_runs = sub.add_parser("runs", help="List recent evaluation runs")
    p_runs.add_argument("--token", help="Sync token")
    p_runs.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_runs.add_argument("--env", default=None, help="Filter by environment slug")
    p_runs.add_argument("--limit", type=int, default=10, help="Max runs to show (default 10)")

    # proofs
    p_proofs = sub.add_parser("proofs", help="List verified proofs")
    p_proofs.add_argument("--token", help="Sync token")
    p_proofs.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_proofs.add_argument("--env", default=None, help="Filter by environment slug")
    p_proofs.add_argument("--limit", type=int, default=20, help="Max proofs to show (default 20)")

    # mcp — ATH-829 Phase 1.2: stdio MCP server for agent integration
    # doctor (ATH-844): one-shot env validation
    p_doctor = sub.add_parser(
        "doctor",
        help="Validate kairos environment (lake, license, models, supabase, ...) before running",
    )
    p_doctor.add_argument(
        "--no-live-ping",
        action="store_true",
        help="Skip the 1-token live model pings (env-presence check only)",
    )
    p_doctor.add_argument(
        "--check-vllm",
        action="store_true",
        help="Verify vllm install + nvidia-smi (opt-in; only needed for VLLMDrafter customers)",
    )
    p_doctor.add_argument(
        "--check-aristotle",
        action="store_true",
        help="Verify aristotle CLI + ARISTOTLE_API_KEY (opt-in; only needed for Aristotle integrations)",
    )
    p_doctor.add_argument(
        "--strict-sink-routing",
        action="store_true",
        help=(
            "ATH-1048: emit a synthetic test event + read it back from "
            "Supabase to confirm end-to-end routing works (catches the "
            "silent-emit-no-op class). Run once before first launch or "
            "when env changes; not for CI loops (each invocation costs "
            "~15s wall-clock)."
        ),
    )
    p_doctor.add_argument(
        "--strict",
        action="store_true",
        help="Exit with code 2 on any SKIPped check (default: only FAIL → exit 1)",
    )
    p_doctor.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output JSON-lines (one CheckResult per line) instead of pretty table",
    )

    p_mcp = sub.add_parser(
        "mcp",
        help="Run kairos MCP server for Claude Code / Cursor / Cline / OpenHands / Leanstral",
    )
    p_mcp_sub = p_mcp.add_subparsers(dest="mcp_sub")
    p_mcp_serve = p_mcp_sub.add_parser(
        "serve",
        help="Start the stdio MCP server. Free-tier customers see free tools; paid customers see free + paid.",
    )
    # Future: --http and --port for HTTP transport

    p_signature_gen = sub.add_parser(
        "signature-gen",
        help="Generate signature.json from an RTL module file (ATH-1063 Phase 0b).",
    )
    p_signature_gen.add_argument("rtl_path", help="Path to .v or .sv source file")
    p_signature_gen.add_argument(
        "--target-module",
        default=None,
        help="Module name to target (defaults to first module in file)",
    )
    p_signature_gen.add_argument(
        "-o", "--output",
        default=None,
        help="Output path (defaults to <rtl_dir>/../signature.json)",
    )

    # calibrate
    p_cal = sub.add_parser("calibrate", help="Fit sigmoid parameters from a run file")
    p_cal.add_argument("--run", required=True, help="Path to run JSON file")
    p_cal.add_argument("--metric", default="base_completeness_score",
                       help="Metadata key to use as raw score (default: base_completeness_score)")

    # stats
    p_stats = sub.add_parser("stats", help="Show aggregate statistics for run files")
    p_stats.add_argument("runs", nargs="+", help="One or more run JSON files")
    p_stats.add_argument("--per-task", action="store_true", help="Show per-task breakdown")

    # compare
    p_cmp = sub.add_parser("compare", help="Compare two run files")
    p_cmp.add_argument("run_a", help="First run file (baseline)")
    p_cmp.add_argument("run_b", help="Second run file (new)")

    # eval-status
    p_eval_status = sub.add_parser(
        "eval-status",
        help="Show real-time status of all eval runs in an env directory",
    )
    p_eval_status.add_argument("env_dir", nargs="?", default=".",
                               help="Path to env directory (default: cwd)")
    p_eval_status.add_argument("-v", "--verbose", action="store_true",
                               help="Show per-task scores in tier order")

    # preflight
    p_pre = sub.add_parser("preflight", help="Sanity-check a scoring container and/or task models")
    p_pre.add_argument("--env", help="Container preflight: environment slug or full image (e.g. hw-cbmc or ghcr.io/athanor-ai/hw-cbmc:latest)")
    p_pre.add_argument("--fleet", help="Fleet preflight: path to task config JSON OR env dir (pair with --fleet-task)")
    p_pre.add_argument("--fleet-task", help="Task slug, used with --fleet <env_dir>")
    p_pre.add_argument("--extra-model", action="append", default=[], help="Additional model to ping in fleet preflight (repeatable)")
    p_pre.add_argument("--timeout", type=int, default=30, help="Per-model ping timeout (seconds)")

    # lint
    p_lint = sub.add_parser("lint", help="Lint a Lean file for banned constructs")
    p_lint.add_argument("file", help="Path to Lean file")

    # ATH-697 simple-prove — free-tier NL → Lean → NL.
    p_simple = sub.add_parser(
        "simple-prove",
        help="Free-tier: prove a hypothesis in English, get an English answer "
             "back. Lean stays hidden. Set ANTHROPIC_API_KEY / OPENAI_API_KEY / "
             "GEMINI_API_KEY for the BYO LLM fallback when no template matches.",
    )
    p_simple.add_argument(
        "hypothesis", nargs="?", default=None,
        help="Free-text claim, e.g. 'prove cwnd never goes below MSS'. "
             "Omit when using --list-patterns.",
    )
    p_simple.add_argument(
        "--show-lean", action="store_true",
        help="Append the generated Lean source to the output (debug only).",
    )
    p_simple.add_argument(
        "--list-patterns", action="store_true",
        help="List the deterministic Pythia template patterns + exit.",
    )
    p_simple.add_argument(
        "--json", action="store_true", dest="json_out",
        help="Emit the result as a JSON object (for scripting). Default is "
             "human-readable summary text.",
    )

    # estimate
    p_est = sub.add_parser("estimate", help="Estimate API cost for an evaluation run")
    # noqa: model-literal — argparse help-text example, not a code-level selection (ATH-816).
    p_est.add_argument("--model", required=True, help="Model ID (e.g. claude-opus-4-6)")
    p_est.add_argument("--tasks", type=int, required=True, help="Number of tasks")

    # task-info
    p_ti = sub.add_parser("task-info", help="Show details about a task")
    p_ti.add_argument("--env", required=True, help="Environment slug")
    p_ti.add_argument("--task", required=True, help="Task ID")

    # bootstrap
    _DEFAULT_PLATFORM = "https://tahoe.athanor-ai.com"
    p_boot = sub.add_parser("bootstrap", help="Persistent VM state + systemd runner (ATH-122)")
    p_boot.add_argument(
        "--plaintext", action="store_true",
        help="(legacy) Write plaintext env file — now the default; kept for backwards compat",
    )
    p_boot.add_argument(
        "--encrypted", action="store_true",
        help="Write Fernet-encrypted env file (incompatible with `bootstrap start`)",
    )
    p_boot.add_argument("--platform", default=_DEFAULT_PLATFORM, help="Platform URL")
    p_boot.set_defaults(bootstrap_sub=None)
    boot_sub = p_boot.add_subparsers(dest="bootstrap_sub")

    # bootstrap set
    p_boot_set = boot_sub.add_parser("set", help="Update env file non-interactively")
    p_boot_set.add_argument("pairs", nargs="+", metavar="KEY=VALUE")
    p_boot_set.add_argument("--plaintext", action="store_true")
    p_boot_set.add_argument("--encrypted", action="store_true")
    p_boot_set.add_argument("--platform", default=_DEFAULT_PLATFORM)

    # bootstrap refresh-ghcr
    p_boot_ghcr = boot_sub.add_parser("refresh-ghcr", help="Re-fetch GHCR token + docker login (ATH-152)")
    p_boot_ghcr.add_argument("--plaintext", action="store_true")
    p_boot_ghcr.add_argument("--encrypted", action="store_true")
    p_boot_ghcr.add_argument("--platform", default=_DEFAULT_PLATFORM)

    # bootstrap start / stop / status
    boot_sub.add_parser("start", help="Install + start systemd user service")
    boot_sub.add_parser("stop", help="Stop systemd user service")
    boot_sub.add_parser("status", help="Show runner service status")

    # bootstrap reset
    boot_sub.add_parser("reset", help="Wipe env file + service + logs")

    # config
    p_config = sub.add_parser("config", help="Manage configuration")
    p_config.add_argument("--set", help="Set a config value (KEY=VALUE)")

    # spec (ATH-358) — new + validate land via qa + asabi PRs
    p_spec = sub.add_parser("spec", help="Compose, lint, and submit SpecV1 specs")
    spec_sub = p_spec.add_subparsers(dest="spec_sub")

    spec_sub.add_parser("template", help="Emit a commented SpecV1 JSON template to stdout")

    p_spec_submit = spec_sub.add_parser(
        "submit", help="Submit a validated SpecV1 to the local builder (builder required)"
    )
    p_spec_submit.add_argument("spec", help="Path to spec.json")

    p_spec_bundle = spec_sub.add_parser(
        "bundle",
        help="Pack a completed run's artifacts into a customer-facing tarball",
    )
    p_spec_bundle.add_argument(
        "run_id", help="Run id (subdir of ~/.athanor/runs/) to package",
    )

    p_spec_verify = spec_sub.add_parser(
        "verify-bundle",
        help="Verify a bundle.tar.gz's sha256 manifest matches its contents",
    )
    p_spec_verify.add_argument("bundle", help="Path to bundle.tar.gz")

    # verify (ATH-854 / Q3) — proof-certificate bundle audit. Distinct
    # from `spec verify-bundle` (which checks customer-support archives);
    # this verifies the cryptographic provenance of a single PROVEN
    # verdict from kairos.lean.solve / cycle_prove / ebmc.solve. The
    # bundle includes the embedded JWKS snapshot so verification is
    # fully offline by default — auditors run `kairos verify <cert>`
    # without needing kairos.io network access.
    p_verify = sub.add_parser(
        "verify",
        help="Verify a proof-certificate bundle (ATH-854)",
    )
    p_verify.add_argument(
        "cert", help="Path to a .tar.gz proof-certificate from kairos.cert.make_proof_certificate",
    )
    p_verify.add_argument(
        "--live-jwks", action="store_true",
        help="Fetch the live JWKS from kairos.io instead of using the embedded snapshot. Useful when an auditor wants to cross-check the embedded copy against the published one.",
    )
    p_verify.add_argument(
        "--json", action="store_true",
        help="Emit the verdict + signed_verdict as JSON to stdout after the OK line.",
    )

    # stream (ATH-357)
    p_stream = sub.add_parser(
        "stream", help="Render an athanor-builder JSONL event stream as ANSI"
    )
    p_stream.add_argument(
        "--mode", choices=("full", "terse", "quiet"), default=None,
        help="Override ATHANOR_STREAM_MODE (full|terse|quiet).",
    )
    p_stream.add_argument("--no-color", action="store_true", help="Disable ANSI.")
    p_stream.add_argument("--file", default=None, help="Read events from a file (default: stdin).")

    # ATH-554 — `kairos trace replay` drains ~/.kairos/failed_events.jsonl
    # after an outage. Journal is populated by ATH-553's fail-loud sink.
    p_trace = sub.add_parser(
        "trace",
        help="Operate on the SupabaseTraceSink fail-loud journal (ATH-553/554)",
    )
    trace_sub = p_trace.add_subparsers(dest="trace_sub")
    p_trace_replay = trace_sub.add_parser(
        "replay",
        help="Re-POST/PATCH every entry in ~/.kairos/failed_events.jsonl",
    )
    p_trace_replay.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help="Print what would be sent, don't POST or mutate the journal.",
    )
    p_trace_replay.add_argument(
        "--limit", type=int, default=None,
        help="Stop after N replay attempts (useful for cron).",
    )
    p_trace_replay.add_argument(
        "--path", default=None,
        help="Journal path (default: ~/.kairos/failed_events.jsonl or "
             "$KAIROS_FAILED_EVENTS_JOURNAL override).",
    )

    # ATH-690 follow-up — `kairos audit show` for customer self-service.
    from kairos.cmd_audit import add_subparser as _add_audit_subparser
    _add_audit_subparser(sub)

    # ATH-701 — `kairos verify-batch <dir>` for bulk Lean verification.
    from kairos.cmd_verify_batch import add_subparser as _add_vb_subparser
    _add_vb_subparser(sub)

    # ATH-680 — `kairos report <run_id>` HTML report renderer for the
    # local-output-dir layout from ATH-681.
    from kairos.cmd_report import add_subparser as _add_report_subparser
    _add_report_subparser(sub)

    # ATH-682 — `kairos init --lean-pythia` starter-project bootstrap.
    from kairos.cmd_init import add_subparser as _add_init_subparser
    _add_init_subparser(sub)

    return parser


def main():
    parser = _build_parser()
    args = parser.parse_args()
    _check_litellm_for_command(args.command)
    if args.command == "run":
        cmd_run(args)
    elif args.command == "score":
        cmd_score(args)
    elif args.command == "solve":
        cmd_solve(args)
    elif args.command == "optimize":
        cmd_optimize(args)
    elif args.command == "spec-refine":
        cmd_spec_refine(args)
    elif args.command == "cegar":
        cmd_cegar(args)
    elif args.command == "prove":
        cmd_prove(args)
    elif args.command == "sv-prove":
        cmd_sv_prove(args)
    elif args.command == "sv-swarm":
        cmd_sv_swarm(args)
    elif args.command == "sv-cycle-swarm":
        cmd_sv_cycle_swarm(args)
    elif args.command == "sv-multi":
        cmd_sv_multi(args)
    elif args.command == "sv-hb-graph":
        cmd_sv_hb_graph(args)
    elif args.command == "sv-invariants":
        cmd_sv_invariants(args)
    elif args.command == "build":
        cmd_build(args)
    elif args.command == "evaluate":
        cmd_evaluate(args)
    elif args.command == "pull":
        cmd_pull(args)
    elif args.command == "runs":
        cmd_runs(args)
    elif args.command == "run-summary":
        cmd_run_summary(args)
    elif args.command == "proofs":
        cmd_proofs(args)
    elif args.command == "calibrate":
        cmd_calibrate(args)
    elif args.command == "stats":
        cmd_stats(args)
    elif args.command == "compare":
        cmd_compare(args)
    elif args.command == "eval-status":
        cmd_eval_status(args)
    elif args.command == "preflight":
        cmd_preflight(args)
    elif args.command == "lint":
        cmd_lint(args)
    elif args.command == "simple-prove":
        raise SystemExit(_cmd_simple_prove(args))
    elif args.command == "estimate":
        cmd_estimate(args)
    elif args.command == "task-info":
        cmd_task_info(args)
    elif args.command == "config":
        cmd_config(args)
    elif args.command == "bootstrap":
        cmd_bootstrap(args)
    elif args.command == "spec":
        if args.spec_sub == "template":
            cmd_spec_template(args)
        elif args.spec_sub == "submit":
            cmd_spec_submit(args)
        elif args.spec_sub == "bundle":
            cmd_spec_bundle(args)
        elif args.spec_sub == "verify-bundle":
            cmd_spec_verify_bundle(args)
        else:
            p_spec.print_help()
    elif args.command == "verify":
        cmd_verify_cert(args)
    elif args.command == "stream":
        cmd_stream(args)
    elif args.command == "audit":
        if args.audit_sub == "show":
            from kairos.cmd_audit import cmd_audit_show
            raise SystemExit(cmd_audit_show(args))
        # No subcommand → print help.
        print("usage: kairos audit show [--since SPEC] [--denied] [--json] [--path P]",
              file=sys.stderr)
        raise SystemExit(2)
    elif args.command == "verify-batch":
        from kairos.cmd_verify_batch import cmd_verify_batch
        raise SystemExit(cmd_verify_batch(args))
    elif args.command == "report":
        from kairos.cmd_report import cmd_report
        raise SystemExit(cmd_report(args))
    elif args.command == "init":
        from kairos.cmd_init import cmd_init
        raise SystemExit(cmd_init(args))
    elif args.command == "trace":
        if args.trace_sub == "replay":
            from kairos.trace_replay import cmd_trace_replay
            raise SystemExit(cmd_trace_replay(args))
        else:
            p_trace.print_help()
    elif args.command == "mcp":
        if args.mcp_sub == "serve":
            from kairos.mcp.server import cli_serve
            raise SystemExit(cli_serve())
        else:
            p_mcp.print_help()
    elif args.command == "doctor":
        from kairos.doctor import run_doctor
        raise SystemExit(run_doctor(
            live_ping=not args.no_live_ping,
            check_vllm=args.check_vllm,
            check_aristotle=args.check_aristotle,
            strict_sink_routing=args.strict_sink_routing,
            strict=args.strict,
            json_output=args.json_output,
        ))
    elif args.command == "signature-gen":
        import json
        from pathlib import Path
        from kairos.sec.signature_gen import generate_signature
        sig = generate_signature(args.rtl_path, target_module=args.target_module)
        output = args.output
        if output is None:
            rtl_dir = Path(args.rtl_path).parent
            output = str(rtl_dir.parent / "signature.json")
        Path(output).write_text(json.dumps(sig, indent=2) + "\n")
        print(f"Wrote {output}")
        raise SystemExit(0)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
