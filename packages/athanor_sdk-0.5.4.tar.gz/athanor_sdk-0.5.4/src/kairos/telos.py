"""kairos.telos — telos YAML→multi-prover DSL vertical (ATH-684 v1.9).

Customer entrypoint for the telos vertical. Requires the
``[telos]`` install extra (``pip install athanor-sdk[telos]``).

## v1 status (2026-04-27)

Registration stub. Same shape as :mod:`kairos.cedar`: defines the
public API + raises :class:`TelosNotInstalledError` until the
vendor source lands.

Telos has a Docker dependency (multi-prover binaries) that stays
customer-side — we ship the Lean source + Dafny + EBMC integration
glue, the customer's own Docker daemon runs the heavy provers.
That's why telos lives behind the ``[telos]`` extra rather than the
default bundle.

## Customer install

    pip install athanor-sdk[telos]      # ← future: pulls vendor
    pip install athanor-sdk             # default, telos absent

## Tier classification

Free at the wrapper level. Heavy paid solver paths gate on
``require_product("solve")`` per the §11 audit (unchanged).
"""
from __future__ import annotations

import shutil
from pathlib import Path


_VENDOR_DIR = Path(__file__).resolve().parent / "_vendor" / "telos"


class TelosNotInstalledError(ImportError):
    """Raised when the customer has not installed the ``[telos]``
    extra OR is missing the Docker dependency. Subclasses
    :class:`ImportError` so existing ``except ImportError:`` blocks
    catch it naturally."""
    def __init__(self, reason: str = "") -> None:
        msg = (
            "kairos.telos requires the [telos] install extra. Run:\n"
            "    pip install athanor-sdk[telos]\n"
            "(ATH-684 — telos has a Docker dep for multi-prover "
            "execution; ship docker on the customer side and install "
            "the [telos] extra to wire it.)"
        )
        if reason:
            msg += f"\nDetail: {reason}"
        super().__init__(msg)


def _require_telos_vendor() -> Path:
    """Return the path to the vendored telos source. Raises
    :class:`TelosNotInstalledError` when the vendor isn't present."""
    if not _VENDOR_DIR.is_dir():
        raise TelosNotInstalledError()
    if not (_VENDOR_DIR / "lakefile.lean").is_file():
        raise TelosNotInstalledError()
    return _VENDOR_DIR


def _require_docker() -> str:
    """Return the path to the customer's docker / podman binary.
    Raises :class:`TelosNotInstalledError` when neither is found.
    Telos shells out to docker for multi-prover execution; without
    it the vertical can't function."""
    docker_bin = shutil.which("docker") or shutil.which("podman")
    if not docker_bin:
        raise TelosNotInstalledError(
            "neither `docker` nor `podman` was found on PATH. Telos "
            "shells out to a container runtime for multi-prover "
            "execution; install Docker or Podman and retry."
        )
    return docker_bin


def vendor_path() -> Path:
    """Path to the vendored telos source. Symmetric with
    :func:`kairos.cedar.vendor_path` and
    :func:`kairos.pythia.vendor_path`.

    Raises :class:`TelosNotInstalledError` when the ``[telos]``
    extra is not installed.
    """
    return _require_telos_vendor()


def is_available() -> bool:
    """Cheap feature-flag check. Returns ``False`` if either the
    vendor source OR the docker dep is missing — both are required
    for a working telos run."""
    try:
        _require_telos_vendor()
        _require_docker()
        return True
    except TelosNotInstalledError:
        return False


__all__ = [
    "TelosNotInstalledError",
    "vendor_path",
    "is_available",
]
