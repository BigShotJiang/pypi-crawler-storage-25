"""Read-side helpers for querying completed kairos sessions.

Companion to :mod:`kairos.trace` (which owns the write side). The public
entrypoint is :func:`summarize`, which fetches one ``solve_runs`` row and
its ``sdk_agent_events`` children, and returns a compact :class:`RunSummary`
suitable for both the ``kairos run-summary`` CLI and programmatic use
(paper-table generators, CI gates, per-run audits).

Platform dogfood pattern (kairos-cedar paper §8-§9):

    from kairos.runs import summarize
    summary = summarize(run_id)
    print(f"diff_found: {summary.diff_found_count}/{summary.diff_tested_count}")
    print(f"pass_rate:  {summary.predicate_verify_pass_rate:.2%}")

Queries PostgREST directly; no caching. One ``solve_runs`` GET + one
paginated ``sdk_agent_events`` GET per call. Tolerant of missing parent
rows (returns a summary keyed only on child events) so runs that closed
mid-flight still yield something useful.
"""

from __future__ import annotations

import json as _json
import logging
import os
import urllib.parse as _urlparse
import urllib.request as _urlreq
from dataclasses import dataclass
from typing import Any, Mapping

_logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RunSummary:
    """Compact summary of one kairos session.

    ``event_type_breakdown`` is ordered high-to-low by count so human
    readers see the dominant event types first. ``None`` fields indicate
    "no data in the session" — a session with zero predicate_verify
    events has ``predicate_verify_pass_rate=None``, not 0.0.
    """

    run_id: str
    task_id: str | None
    vertical: str | None
    status: str | None
    event_count: int
    event_type_breakdown: dict[str, int]
    token_cost_usd: float | None
    wall_time_seconds: float | None
    # Per-event-type rollups (all optional — populated only when
    # relevant events present in the session).
    predicate_verify_pass_rate: float | None = None
    predicate_verify_holds: int = 0
    predicate_verify_fails: int = 0
    diff_tested_count: int = 0
    diff_found_count: int = 0
    diff_found_rate: float | None = None
    llm_call_success_count: int = 0
    llm_call_failure_count: int = 0
    # Populated from aggregated child events when the parent row's
    # token_cost_usd is None/0 — mirrors ATH-548 close_run fallback.
    event_cost_usd_aggregate: float | None = None


class _PostgRESTClient:
    """Thin PostgREST GET wrapper. Split out so tests can patch
    ``_fetch`` without touching urllib globally."""

    def __init__(self, url: str, key: str) -> None:
        self._url = url.rstrip("/")
        self._key = key

    def _fetch(self, path: str) -> Any:
        req = _urlreq.Request(
            f"{self._url}{path}",
            headers={
                "apikey": self._key,
                "Authorization": f"Bearer {self._key}",
                "Accept": "application/json",
            },
            method="GET",
        )
        with _urlreq.urlopen(req, timeout=10) as resp:
            return _json.loads(resp.read().decode("utf-8"))

    def solve_run(self, run_id: str) -> Mapping[str, Any] | None:
        q = "id=eq." + _urlparse.quote(run_id, safe="")
        try:
            rows = self._fetch(f"/rest/v1/solve_runs?{q}&limit=1")
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.error(
                "kairos.runs.solve_run(run_id=%s) failed: %s: %s",
                run_id, type(exc).__name__, exc,
            )
            return None
        return rows[0] if rows else None

    def events(self, run_id: str) -> list[Mapping[str, Any]]:
        q = "run_id=eq." + _urlparse.quote(run_id, safe="")
        try:
            return list(
                self._fetch(
                    f"/rest/v1/sdk_agent_events?{q}"
                    "&select=event_type,payload"
                )
            )
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            _logger.error(
                "kairos.runs.events(run_id=%s) failed: %s: %s",
                run_id, type(exc).__name__, exc,
            )
            return []


def _resolve_credentials(
    supabase_url: str | None, supabase_key: str | None,
) -> tuple[str, str] | None:
    """Resolve URL + service-role key from args or env.

    Env-var fallback order for URL mirrors ATH-543:
      ``SUPABASE_URL`` → ``NEXT_PUBLIC_SUPABASE_URL``. Returns ``None``
    when no credentials are reachable — caller gets a clear "unconfigured"
    signal rather than a cryptic 401.
    """
    url = supabase_url or os.environ.get("SUPABASE_URL") or os.environ.get(
        "NEXT_PUBLIC_SUPABASE_URL"
    )
    key = supabase_key or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    if not url or not key:
        return None
    return url, key


def summarize(
    run_id: str,
    *,
    supabase_url: str | None = None,
    supabase_key: str | None = None,
) -> RunSummary | None:
    """Fetch a summary for one run. ``None`` when Supabase is unconfigured.

    Raises nothing on transport failure — failures flow through to empty
    event lists + a ``status="unknown"`` RunSummary so callers that pipe
    into a CLI don't need to wrap in try/except.
    """
    creds = _resolve_credentials(supabase_url, supabase_key)
    if creds is None:
        return None
    client = _PostgRESTClient(*creds)

    parent = client.solve_run(run_id) or {}
    events = client.events(run_id)
    return _build_summary(run_id, parent, events)


def _build_summary(
    run_id: str,
    parent: Mapping[str, Any],
    events: list[Mapping[str, Any]],
) -> RunSummary:
    """Pure function over the fetched rows — isolated for unit testing."""
    breakdown: dict[str, int] = {}
    pv_holds = 0
    pv_fails = 0
    diff_tested = 0
    diff_found = 0
    llm_success = 0
    llm_failure = 0
    event_cost_total = 0.0
    event_cost_found_any = False

    for row in events:
        et = str(row.get("event_type") or "")
        breakdown[et] = breakdown.get(et, 0) + 1
        payload = row.get("payload") or {}

        if et == "predicate_verify_result":
            verdict = payload.get("verdict")
            if verdict == "holds":
                pv_holds += 1
            elif verdict == "fails":
                pv_fails += 1
        elif et == "differential_test_tuple":
            diff_tested += 1
            if payload.get("diff_found") is True:
                diff_found += 1
        elif et == "llm_call_success":
            llm_success += 1
        elif et == "llm_call_failure":
            llm_failure += 1

        cost = payload.get("cost_usd")
        if cost is not None:
            try:
                event_cost_total += float(cost)
                event_cost_found_any = True
            except (TypeError, ValueError):
                pass

    ordered_breakdown = dict(
        sorted(breakdown.items(), key=lambda kv: (-kv[1], kv[0]))
    )

    pv_total = pv_holds + pv_fails
    pv_rate: float | None = (pv_holds / pv_total) if pv_total > 0 else None
    diff_rate: float | None = (
        diff_found / diff_tested if diff_tested > 0 else None
    )

    return RunSummary(
        run_id=run_id,
        task_id=parent.get("task_id") if parent else None,
        vertical=parent.get("vertical") if parent else None,
        status=parent.get("status") if parent else None,
        event_count=len(events),
        event_type_breakdown=ordered_breakdown,
        token_cost_usd=_as_float(parent.get("token_cost_usd")) if parent else None,
        wall_time_seconds=_as_float(parent.get("wall_time_seconds")) if parent else None,
        predicate_verify_pass_rate=pv_rate,
        predicate_verify_holds=pv_holds,
        predicate_verify_fails=pv_fails,
        diff_tested_count=diff_tested,
        diff_found_count=diff_found,
        diff_found_rate=diff_rate,
        llm_call_success_count=llm_success,
        llm_call_failure_count=llm_failure,
        event_cost_usd_aggregate=event_cost_total if event_cost_found_any else None,
    )


def _as_float(v: Any) -> float | None:
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def render_text(summary: RunSummary) -> str:
    """Human-readable plain-text rendering for the CLI.

    Paper-friendly columns: task + vertical + status at the top, rollups
    beneath. Missing data renders as ``—`` so the output lines up.
    """

    def _fmt_float(v: float | None, fmt: str = ".4f") -> str:
        return format(v, fmt) if v is not None else "—"

    def _fmt_pct(v: float | None) -> str:
        return f"{v * 100:.2f}%" if v is not None else "—"

    lines = [
        f"run_id:              {summary.run_id}",
        f"task_id:             {summary.task_id or '—'}",
        f"vertical:            {summary.vertical or '—'}",
        f"status:              {summary.status or '—'}",
        f"event_count:         {summary.event_count}",
        f"wall_time_seconds:   {_fmt_float(summary.wall_time_seconds, '.2f')}",
        f"token_cost_usd:      ${_fmt_float(summary.token_cost_usd)}",
    ]
    if summary.event_cost_usd_aggregate is not None and (
        summary.token_cost_usd is None or summary.token_cost_usd == 0.0
    ):
        lines.append(
            f"  (child-event aggregate: "
            f"${_fmt_float(summary.event_cost_usd_aggregate)})"
        )
    if summary.llm_call_success_count or summary.llm_call_failure_count:
        lines.append(
            f"llm_calls:           "
            f"{summary.llm_call_success_count} success / "
            f"{summary.llm_call_failure_count} failure"
        )
    if summary.predicate_verify_pass_rate is not None:
        lines.append(
            f"predicate_verify:    "
            f"{summary.predicate_verify_holds} holds / "
            f"{summary.predicate_verify_fails} fails "
            f"({_fmt_pct(summary.predicate_verify_pass_rate)} pass)"
        )
    if summary.diff_tested_count > 0:
        lines.append(
            f"differential_test:   "
            f"{summary.diff_found_count} diff / "
            f"{summary.diff_tested_count} tested "
            f"({_fmt_pct(summary.diff_found_rate)} diff rate)"
        )
    if summary.event_type_breakdown:
        lines.append("event_types:")
        for et, count in summary.event_type_breakdown.items():
            lines.append(f"  {et:<35} {count}")
    return "\n".join(lines)


def render_json(summary: RunSummary) -> str:
    """Machine-readable JSON rendering. Useful for paper-table pipelines."""
    return _json.dumps(
        {
            "run_id": summary.run_id,
            "task_id": summary.task_id,
            "vertical": summary.vertical,
            "status": summary.status,
            "event_count": summary.event_count,
            "event_type_breakdown": summary.event_type_breakdown,
            "token_cost_usd": summary.token_cost_usd,
            "wall_time_seconds": summary.wall_time_seconds,
            "predicate_verify_pass_rate": summary.predicate_verify_pass_rate,
            "predicate_verify_holds": summary.predicate_verify_holds,
            "predicate_verify_fails": summary.predicate_verify_fails,
            "diff_tested_count": summary.diff_tested_count,
            "diff_found_count": summary.diff_found_count,
            "diff_found_rate": summary.diff_found_rate,
            "llm_call_success_count": summary.llm_call_success_count,
            "llm_call_failure_count": summary.llm_call_failure_count,
            "event_cost_usd_aggregate": summary.event_cost_usd_aggregate,
        },
        indent=2,
    )


__all__ = [
    "RunSummary",
    "summarize",
    "render_text",
    "render_json",
]
