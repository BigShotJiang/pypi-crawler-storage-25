"""ATH-697 — `kairos.simple_prove_template()`: free-tier NL → Lean → NL flow.

The customer types a hypothesis in English, gets an answer in English.
Lean stays under the hood. Designed so a customer who has never
written Lean can use the SDK productively on day one.

## Flow

1. Match `hypothesis` against `kairos.verticals.pythia` deterministic
   templates. If a template fires, generate Lean from it.
2. If no template fires AND a BYO LLM key is configured, call
   `kairos.llm_byo` to fill a Pythia template from arbitrary prose.
3. If neither path produces a spec, return a clear English error
   asking the customer to rephrase or set a BYO key.
4. Run `kairos.lean.verify_proof` on the generated Lean (free tier,
   local-only).
5. Translate the verdict back to English. The returned
   `SimpleProveResult` carries a `summary` field that is the only
   thing a customer needs to read.

## Free tier guarantees

- Zero phone-home from the SDK side.
- LLM calls (when BYO key is set) go directly from the customer's
  machine to the customer's chosen provider.
- The generated Lean is stashed under `~/.athanor/runs/<run_id>/spec.lean`
  for debugging only — customer never has to read it.

## Customer entrypoint

    from kairos import simple_prove_template

    result = simple_prove_template("prove c_vector_sharp is positive")
    print(result.summary)
    # → "✓ proved. c_vector_sharp is strictly positive (Pythia.MatchingConstants)."

That's the entire customer surface for the happy path.
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

logger = logging.getLogger(__name__)


# ATH-728 Phase 1 — typed action vocabulary for failed-proof feedback.
# The four action kinds map onto what an agent loop can actually DO with
# a Lean failure: pick a tactic to try (TacticName), register a missing
# lemma in scope (RegisterLemma), strengthen the spec (AddHypothesis),
# or restate the claim (RephraseHypothesis). Kept closed (Literal) so
# downstream agents can branch on `action` without string-typo risk.
NextActionKind = Literal[
    "TacticName", "RegisterLemma", "AddHypothesis", "RephraseHypothesis",
]


@dataclass(frozen=True)
class NextAction:
    """A single typed retry suggestion attached to a failed proof.

    Sources, in priority order:
    - Pythia's own `[pythia.failure] {"next_actions": [...]}` tagged log
      line when `pythia.machineFormat=true` is in scope.
    - Regex fallback against raw lake stderr for the most common Lean
      error classes (unknown identifier / type mismatch / unsolved goals
      / failed to synthesize / tactic failed).

    Customers iterate this list in the order returned: the parser puts
    the most actionable suggestion first. Confidence is a 0..1 hint —
    None when the source didn't supply one (e.g. regex fallback)."""

    action: NextActionKind
    suggestion: str
    confidence: float | None = None


@dataclass(frozen=True)
class RefinementStep:
    """One iteration of the ATH-728 Phase 2 BYO-LLM refinement loop.

    Each step captures the Lean source the BYO-LLM produced for this
    attempt, the verdict on it, the parsed `next_actions`, and the
    wall-clock cost. Sequence of steps lives on
    :attr:`SimpleProveResult.refinement_history`; the trajectory is
    `[step_0, step_1, ...]` with `step_N` always representing the
    Nth refinement (initial proof attempt is *not* a step — it's the
    pre-loop verdict the loop is responding to).

    ``proved=True`` on the final step means the loop succeeded; the
    parent ``SimpleProveResult.proved`` will reflect that. A trailing
    ``proved=False`` means every iteration failed and the customer
    received the last-attempt verdict + the union of next_actions
    across the trajectory for further triage.
    """

    iteration: int
    """0-indexed refinement attempt. ``iteration=0`` is the FIRST
    refinement (after the initial proof attempt failed)."""

    proved: bool
    """True iff this iteration's Lean source verified."""

    lean_source: str
    """The revised Lean source the BYO-LLM produced for this
    iteration. Stashed under ``run_dir/refine_<N>.lean`` for
    debugging."""

    error: str | None
    """Lake build error tail when ``proved=False``. None on success."""

    next_actions: list[NextAction] = field(default_factory=list)
    """Typed suggestions extracted from this iteration's verdict.
    Drives the *next* iteration's prompt."""

    wall_sec: float = 0.0
    """Wall-clock seconds spent on this iteration (LLM call +
    verify). Useful for spotting refinement-cost-per-success when
    aggregating across runs."""


@dataclass(frozen=True)
class SimpleProveResult:
    """Customer-facing result of `simple_prove_template`. Read `summary`."""

    summary: str
    """One-paragraph English answer. The only field a customer needs."""

    proved: bool
    """True iff the proof is **sound** — the kernel accepted it AND the
    post-build audit found no soundness violations.

    ATH-949 fix (2026-05-03 asabi Option C): semantics flipped. Pre-fix,
    ``proved`` was True whenever the kernel accepted the proof, even if
    the audit detected a custom axiom (axiom_clean=False) or a macro-
    bodied sorry (vacuous_clean=False). That violated the contract
    customer code expects when reading ``if result.proved:`` — that
    pattern asks "is this proof valid?", not "did the kernel parse it?"

    Now: ``proved`` is True only when ALL of:

    * The kernel accepted the proof (lake build succeeded, no sorry).
    * ``axiom_audit_clean`` is True (no smuggled axioms).
    * ``vacuous_truth_clean`` is True (no macro-bodied sorry/admit).

    Customers who need the raw kernel-verdict signal use the lower-
    level :attr:`kernel_accepted` field explicitly. The opt-in
    ``reject_vacuous`` flag (still honored, kept for backward-compat)
    is now redundant on the proved path but still controls whether the
    failure is surfaced as ``rejected`` (with reason in summary) vs
    silently as ``proved=False`` — useful for telemetry differentiation.
    """

    pattern_id: str | None
    """Which Pythia template fired ('sharp_constant_positive',
    'sharp_constant_ranking', 'pythia_smoke', ...). None when the LLM
    path filled the template instead."""

    used_llm: bool
    """True iff the BYO-key LLM was called to fill the template.
    False when the deterministic template path matched directly."""

    spec_path: Path | None
    """Local path to the generated Lean source. Stashed under
    ~/.athanor/runs/<run_id>/spec.lean. Customer can inspect for
    debugging — they're not expected to."""

    raw: dict[str, Any] = field(default_factory=dict)
    """Underlying ProveResult dict + telemetry. Internal — customers
    shouldn't depend on the shape."""

    vacuous_truth_clean: bool | None = None
    """ATH-720 (Guard F). True iff the generated Lean source contains no
    macro-bodied `sorry`/`admit`. None when not checked (proof failed,
    so the question is moot). False ⇒ proof closed via a vacuous macro
    expansion; the customer should not trust the verdict.
    """

    axiom_audit_clean: bool | None = None
    """ATH-720 (Guard G). True iff the generated Lean source declares no
    `axiom` constructs. None when not checked. False ⇒ the proof
    smuggled a custom axiom; the result depends on a non-Mathlib trust
    base.
    """

    detector_matches: list[dict[str, Any]] = field(default_factory=list)
    """ATH-720. Structured per-violation records emitted by
    `kairos.verify.plugin.detectors.macro_sorry`. Each entry carries
    `fingerprint`, `line`, `reason`, `shape`. Empty list when the proof
    is clean. Customer-readable; intended for surfacing in CLI / IDE."""

    next_actions: list[NextAction] = field(default_factory=list)
    """ATH-728 Phase 1. Typed retry suggestions for failed proofs.
    Empty when `proved=True` (nothing to retry) or when the proof was
    skipped (no template match, spec health gate halted). Populated
    from Pythia's tagged-failure JSON when present, else from a regex
    pass over the lake stderr. Order is most-actionable first.

    Agents drive their refinement loop from this list: pick an entry,
    apply the suggestion, retry. The SDK can also drive the loop
    itself via ``simple_prove_template(..., refine_on_failure=True)``
    (see :attr:`refinement_history`)."""

    kernel_accepted: bool = False
    """ATH-949: the raw lake-build verdict (compiles + no sorry).
    Decoupled from :attr:`proved`, which carries the sound-and-trusted
    semantics. ``kernel_accepted=True`` + ``proved=False`` means the
    proof parsed but the audit caught a soundness violation. Customers
    auditing Lean infrastructure care about this signal; customers
    asking "did my hypothesis prove?" should read ``proved`` instead."""

    refinement_history: list[RefinementStep] = field(default_factory=list)
    """ATH-728 Phase 2. Trajectory of in-SDK refinement attempts when
    the customer opted into ``refine_on_failure=True``. Empty when
    the option was off, when the initial proof succeeded (nothing to
    refine), or when no BYO-LLM key was configured (graceful
    degradation: ``next_actions`` carries the env-var hint instead).

    Length is bounded by ``max_refine_iterations`` (default 3). The
    last step's ``proved`` flag mirrors the parent's ``proved``:
    success on any iteration short-circuits the loop and records that
    step as the terminal one."""


def simple_prove_template(
    hypothesis: str,
    *,
    show_lean: bool = False,
    runs_dir: Path | str | None = None,
    reject_vacuous: bool = False,
    spec_health_check: bool = True,
    spec_health_threshold: float = 0.6,
    refine_on_failure: bool = False,
    max_refine_iterations: int = 3,
) -> SimpleProveResult:
    """Prove a natural-language hypothesis using free-tier Pythia.

    Args:
        hypothesis: free-text claim mapped against the Pythia template
            registry, e.g.
            "prove c_vector_sharp is positive"
            "prove c_aCS_sharp <= c_vector_sharp"
            "prove c_vector_sharp equals sqrt 2 times c_HR_sharp"
            "prove Pythia.Time is a natural number"
            "verify the Pythia API"
        show_lean: when True, the returned summary includes the
            generated Lean source. Default False — Lean stays hidden.
        runs_dir: override the local runs directory (default
            `~/.athanor/runs/`). Useful for tests.
        reject_vacuous: ATH-720 opt-in fail-loud, **deprecated as of
            ATH-949 (2026-05-03)**. The flag is now redundant on the
            ``proved`` field — ``result.proved`` is True only when
            kernel-accepted AND axiom-clean AND non-vacuous regardless
            of this flag (asabi 2026-05-03 Option C). Setting
            ``reject_vacuous=True`` still emits the explicit
            "rejected" surface in ``verdict["rejected_reason"]`` and
            in the summary string, useful for telemetry differentiation
            between "kernel-rejected" and "audit-rejected" failures.
            Will emit ``DeprecationWarning`` when set; remove next
            minor.
        spec_health_check: ATH-743 auto-enabled gate. When True
            (default), runs `kairos.spec.health_check.health_check()`
            on the autoformalized Lean source BEFORE attempting the
            proof. If the health report's score falls below
            `spec_health_threshold` OR any block_on probe fails,
            simple_prove_template returns a `SimpleProveResult` with
            `proved=False` and a summary explaining the
            autoformalization problem so the customer sees it
            immediately. Cost: typically 1 extra LLM call (the
            cross-model agreement probe). Set to False to skip,
            e.g. when doing offline runs without BYO-LLM.
        spec_health_threshold: aggregate-score floor below which
            the gate halts the pipeline. Default 0.6.
        refine_on_failure: ATH-728 Phase 2. When True and the initial
            proof attempt fails, run a bounded BYO-LLM refinement
            loop: feed the lake error + parsed ``next_actions`` back
            to the customer's configured LLM and ask it to produce a
            revised Lean source, then re-verify. The loop is always
            BYO-LLM — when no provider key is configured, the call
            degrades gracefully to a one-shot result with a
            ``next_actions`` entry telling the customer to set
            ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY.
            Default False (one-shot, matches Phase 1 behaviour).
        max_refine_iterations: bound on the refinement loop. Default
            3. Each iteration costs one BYO-LLM call + one lake build,
            so 3 is a reasonable mid-point between giving the model
            enough turns to fix a typo cascade and not burning the
            customer's budget. Determinism: the BYO-LLM is called at
            ``temperature=0`` so the same hypothesis + same lake
            error reproduces.

    Returns:
        :class:`SimpleProveResult` with an English `summary`. That's
        the only thing a customer needs to look at.

    Examples:
        >>> from kairos import simple_prove_template
        >>> result = simple_prove_template("prove c_vector_sharp is positive")
        >>> print(result.summary)  # doctest: +SKIP
        ✓ proved. c_vector_sharp is strictly positive (Pythia.MatchingConstants).
    """
    run_id = str(uuid4())
    # ATH-716: accept str OR Path. Pre-fix, passing a str crashed with
    # TypeError "unsupported operand type(s) for /: 'str' and 'str'"
    # at the next line.
    runs_root = Path(runs_dir) if runs_dir else (Path.home() / ".athanor" / "runs")
    run_dir = runs_root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    spec, used_llm = _resolve_spec(hypothesis)
    if spec is None:
        return _no_match_result(hypothesis, run_dir)

    spec_path = run_dir / "spec.lean"
    spec_path.write_text(spec.lean_source)

    # ATH-743: spec health gate. Run BEFORE the proof attempt so the
    # customer sees autoformalization problems before burning compile
    # time. Defaults to ON; opt-out via spec_health_check=False.
    if spec_health_check:
        from kairos.spec.health_check import health_check as _health_check
        try:
            health_report = _health_check(
                spec.lean_source, intent_nl=hypothesis,
            )
        except Exception as e:  # noqa: BLE001 — warned + recovered
            # Don't let a probe bug crash the pipeline; degrade
            # gracefully and warn.
            health_report = None
            logger.warning(
                "spec_health_check raised %s: %s — skipping gate",
                type(e).__name__, e,
            )
        if health_report is not None and (
            health_report.block_on
            or health_report.score < spec_health_threshold
        ):
            return _spec_health_fail_result(
                hypothesis, run_dir, spec, health_report,
            )

    # ATH-702: Pythia templates `import Pythia.API`. That import only
    # resolves inside a Lake project that requires Pythia, so we
    # bootstrap one at ~/.athanor/pythia-runs/ on first call and run
    # `lake build` there. Falls back to plain `verify_proof` if the
    # bootstrap fails (e.g. no `lake` on PATH) so the customer gets a
    # clear error rather than a silent crash.
    verdict = _verify_in_pythia_project(spec.lean_source, run_id=run_id)
    current_lean_source = spec.lean_source

    # ATH-728 Phase 2: opt-in BYO-LLM refinement loop. Only fires when
    # the initial attempt failed; success short-circuits unchanged.
    refinement_history: list[RefinementStep] = []
    no_llm_hint: NextAction | None = None
    if refine_on_failure and not verdict.get("proved", False):
        from kairos import llm_byo as _llm_byo
        if not _llm_byo.is_available():
            # Graceful degradation: BYO-LLM key absent, can't refine.
            # Emit a single synthetic NextAction telling the customer
            # what to set, leave refinement_history empty, fall through
            # to the one-shot result. The verdict + ProveResult shape
            # are unchanged, so callers still get a useful response.
            no_llm_hint = NextAction(
                action="RephraseHypothesis",
                suggestion=(
                    "[no-llm] BYO-LLM key required for refine_on_failure; "
                    "set ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY "
                    "in the environment to enable in-SDK refinement."
                ),
                confidence=None,
            )
        else:
            verdict, current_lean_source, refinement_history = _refine_loop(
                hypothesis=hypothesis,
                initial_lean_source=spec.lean_source,
                initial_verdict=verdict,
                max_iterations=max_refine_iterations,
                run_id=run_id,
                run_dir=run_dir,
            )
            # Persist the winning (or final) source to spec.lean so
            # `result.spec_path` points at what was actually verified.
            spec_path.write_text(current_lean_source)

    # ATH-720 Guards F + G. Only run when lake build accepted the proof
    # — a failed verdict's vacuous/axiom status is moot. Pass the
    # current (post-refinement, when applicable) source so a successful
    # refinement is the one we audit for vacuous truth / smuggled axioms.
    vacuous_clean, axiom_clean, detector_records = _scan_lean_for_violations(
        current_lean_source, ran_check=verdict.get("proved", False)
    )

    # ATH-949 (2026-05-03 asabi Option C): the raw lake-build verdict
    # is the ``kernel_accepted`` signal; ``proved`` requires kernel-
    # accepted AND the audit gates clean. This makes ``if result.proved:``
    # safe by default — the field name now matches what consumer code
    # is asking ("is this proof valid?").
    kernel_accepted = bool(verdict.get("proved", False))
    proved_sound = (
        kernel_accepted
        and vacuous_clean is not False
        and axiom_clean is not False
    )

    if reject_vacuous:
        # ATH-949 deprecation: the flag is redundant on proved (which
        # is now sound-by-default), but kept for the explicit
        # rejected_reason telemetry. Warn loudly so customers update.
        import warnings as _warnings
        _warnings.warn(
            "reject_vacuous is deprecated as of ATH-949 (2026-05-03): "
            "result.proved is now sound-by-default (kernel-accepted "
            "AND axiom_clean AND vacuous_clean). The flag is a no-op "
            "for `if result.proved:` checks; it still controls the "
            "`verdict['rejected_reason']` telemetry field. Will be "
            "removed in the next minor release.",
            DeprecationWarning,
            stacklevel=2,
        )
    if reject_vacuous and (vacuous_clean is False or axiom_clean is False):
        # Existing opt-in semantics retained for callers who want the
        # explicit "rejected" surface (verdict["rejected_reason"] +
        # explicit refusal in the summary). ATH-949 makes the default
        # also fail-safe (proved=False) without requiring opt-in.
        verdict = {
            **verdict,
            "proved": False,
            "rejected_reason": (
                "vacuous_truth" if vacuous_clean is False else "custom_axiom"
            ),
        }

    summary = _verdict_to_nl(
        verdict, spec, show_lean=show_lean,
        vacuous_clean=vacuous_clean, axiom_clean=axiom_clean,
    )
    next_actions = _extract_next_actions(verdict)
    if no_llm_hint is not None:
        # ATH-728 Phase 2 graceful degradation: prepend the no-key
        # hint so it's the first action a customer sees.
        next_actions = [no_llm_hint, *next_actions]
    return SimpleProveResult(
        summary=summary,
        proved=proved_sound,
        kernel_accepted=kernel_accepted,
        pattern_id=spec.pattern_id,
        used_llm=used_llm or len(refinement_history) > 0,
        spec_path=spec_path,
        raw=verdict,
        vacuous_truth_clean=vacuous_clean,
        axiom_audit_clean=axiom_clean,
        detector_matches=detector_records,
        next_actions=next_actions,
        refinement_history=refinement_history,
    )


def _scan_lean_for_violations(
    lean_source: str, *, ran_check: bool,
) -> tuple[bool | None, bool | None, list[dict[str, Any]]]:
    """ATH-720. Run the macro_sorry detector against the generated Lean
    source. Returns `(vacuous_truth_clean, axiom_audit_clean, records)`.

    `ran_check=False` ⇒ the proof failed; we skip the scan and return
    `(None, None, [])` so the customer sees an unchecked status rather
    than a false-clean verdict.
    """
    if not ran_check:
        return None, None, []
    from kairos.verify.plugin.detectors.macro_sorry import detect as detect_macro_sorry
    matches = detect_macro_sorry(lean_source, filename="spec.lean")
    records = [
        {
            "fingerprint": m.fingerprint,
            "line": m.line,
            "reason": m.reason,
            "shape": m.metadata.get("shape"),
        }
        for m in matches
    ]
    vacuous_clean = not any(m.fingerprint == "macro_sorry" for m in matches)
    axiom_clean = not any(
        m.fingerprint == "banned_construct"
        and m.metadata.get("shape") == "axiom_decl"
        for m in matches
    )
    return vacuous_clean, axiom_clean, records


# ATH-728 Phase 1 — failed-proof feedback parsers.
#
# Pythia ships `[pythia.result]` / `[pythia.failure]` tagged log lines
# under `set_option pythia.machineFormat true` (pythia main 4154932,
# commit 077a50c). Sample at examples/08_pythia_machine_format.lean.
# The failure JSON carries a `next_actions` array; we pass it through.
#
# When pythia.machineFormat is off (older pythia, non-Pythia goals),
# fall back to regex against raw lake stderr — covers the five most
# common Lean error classes. The action tags map onto the ATH-728
# closed vocabulary.
_PYTHIA_TAG_LINE = re.compile(
    r"^\[pythia\.(result|failure)\] (.*)$", re.MULTILINE,
)

# Order matters: more specific patterns first. `failed to synthesize`
# precedes `unknown identifier` because the former often comes with a
# misleading identifier hint.
_LAKE_ERROR_PATTERNS: tuple[tuple[re.Pattern[str], NextActionKind, str], ...] = (
    (
        re.compile(r"failed to synthesize\b[^\n]*?\n?\s*([A-Z]\w[\w.]*)"),
        "AddHypothesis",
        "Add a typeclass instance hypothesis for `{0}` "
        "(failed to synthesize at the use site).",
    ),
    (
        re.compile(r"unknown (?:identifier|constant) ['`]([^'`\n]+)['`]"),
        "RegisterLemma",
        "Register or import `{0}` — it is referenced by the proof but "
        "is not in scope. Add an `import` for the module that defines "
        "it, or add the lemma to the Pythia registry if it is custom.",
    ),
    (
        re.compile(r"type mismatch[^\n]*\n[^\n]*?\n?\s*([^\n]{1,120})"),
        "RephraseHypothesis",
        "Type mismatch — rephrase the claim to match the expected "
        "type, or insert a coercion. Lean reported: {0}",
    ),
    (
        re.compile(r"unsolved goals?\s*\n([^\n]{1,200})"),
        "TacticName",
        "Unsolved goal `{0}` — try `exact?`, `aesop`, or split the "
        "goal with `constructor`/`refine` before closing.",
    ),
    (
        re.compile(r"tactic ['`]([^'`\n]+)['`] failed"),
        "TacticName",
        "`{0}` did not close the goal. Try a stronger tactic such as "
        "`exact?`, `decide`, `omega`, or `aesop`.",
    ),
)


def _parse_pythia_tagged_failure(output: str) -> list[NextAction]:
    """Extract `next_actions` from pythia's tagged-failure JSON lines.

    Returns an empty list when the tagged lines are absent or malformed —
    the caller falls back to the regex path. Confidence values, when
    pythia supplies them, are passed through verbatim.
    """
    if not output:
        return []
    actions: list[NextAction] = []
    for kind, payload in _PYTHIA_TAG_LINE.findall(output):
        if kind != "failure":
            continue
        try:
            record = json.loads(payload)
        except json.JSONDecodeError:
            logger.debug("simple_prove_template: malformed pythia tag JSON: %s", payload[:120])
            continue
        for entry in record.get("next_actions", []) or []:
            action = entry.get("action")
            suggestion = entry.get("suggestion") or entry.get("detail") or ""
            if action not in {
                "TacticName", "RegisterLemma",
                "AddHypothesis", "RephraseHypothesis",
            } or not suggestion:
                continue
            confidence = entry.get("confidence")
            if confidence is not None:
                try:
                    confidence = float(confidence)
                except (TypeError, ValueError):
                    confidence = None
            actions.append(NextAction(
                action=action, suggestion=suggestion, confidence=confidence,
            ))
    return actions


def _parse_lake_error_regex(stderr: str) -> list[NextAction]:
    """Regex fallback over raw lake stderr. Each pattern matches at most
    once per call so a single error doesn't drown the result with
    duplicate suggestions; agents iterate distinct error classes
    instead. No confidence is assigned (None) — the regex is a heuristic,
    not a signal."""
    if not stderr:
        return []
    actions: list[NextAction] = []
    seen_kinds: set[NextActionKind] = set()
    for pattern, kind, template in _LAKE_ERROR_PATTERNS:
        if kind in seen_kinds:
            continue
        m = pattern.search(stderr)
        if not m:
            continue
        suggestion = template.format(*m.groups())
        actions.append(NextAction(
            action=kind, suggestion=suggestion, confidence=None,
        ))
        seen_kinds.add(kind)
    return actions


def _extract_next_actions(verdict: dict[str, Any]) -> list[NextAction]:
    """Build the `next_actions` list for a verdict.

    Successful verdicts get an empty list — there's nothing to retry.
    Failed verdicts try the pythia tagged-failure JSON first (preferred:
    structured, often carries confidence); if that yields nothing, fall
    back to regex against the raw lake stderr.
    """
    if verdict.get("proved"):
        return []
    # Pythia emits its tagged lines on stdout; lake build also forwards
    # stderr. Concatenate both so we don't miss either source.
    haystack = "\n".join(
        s for s in (verdict.get("lake_stdout"), verdict.get("error"))
        if isinstance(s, str)
    )
    actions = _parse_pythia_tagged_failure(haystack)
    if actions:
        return actions
    return _parse_lake_error_regex(verdict.get("error") or "")


def _refine_loop(
    *,
    hypothesis: str,
    initial_lean_source: str,
    initial_verdict: dict[str, Any],
    max_iterations: int,
    run_id: str,
    run_dir: Path,
) -> tuple[dict[str, Any], str, list[RefinementStep]]:
    """ATH-728 Phase 2 — bounded BYO-LLM refinement loop.

    Repeatedly asks the customer's BYO-LLM to revise the Lean source
    given the lake error + parsed `next_actions`, re-verifies, and
    captures one ``RefinementStep`` per iteration. The loop short-
    circuits on the first ``proved=True`` verdict.

    Returns ``(final_verdict, final_lean_source, history)``:
    - ``final_verdict``: the lake-build verdict from the last attempt
      (winning iteration if any, else last failure).
    - ``final_lean_source``: the source matching ``final_verdict`` so
      the caller can persist it as ``spec.lean``.
    - ``history``: every iteration's ``RefinementStep``, in order.
      Always non-empty when this helper is called (the caller gates
      on ``llm_byo.is_available()`` + ``not initial_verdict.proved``).

    Each iteration writes ``run_dir/refine_<N>.lean`` for inspection
    even when the run ultimately fails. The loop never raises; LLM
    transport failures are captured as ``RefinementStep(proved=False,
    error="LLM call failed: ...")`` and do not abort the loop, since
    a transient provider blip shouldn't end a multi-iteration run.

    Determinism: BYO-LLM is invoked at ``temperature=0.0`` (the
    ``llm_byo.complete`` default), so the same hypothesis + same
    failure trajectory reproduces.
    """
    from kairos import llm_byo as _llm_byo

    history: list[RefinementStep] = []
    current_source = initial_lean_source
    current_verdict = initial_verdict

    for i in range(max_iterations):
        t_start = time.time()
        last_actions = _extract_next_actions(current_verdict)
        prompt = _build_refine_prompt(
            hypothesis=hypothesis,
            previous_lean=current_source,
            error=str(current_verdict.get("error") or ""),
            next_actions=last_actions,
        )
        try:
            raw = _llm_byo.complete(prompt, max_tokens=2048)
            revised_source = _strip_lean_fence(raw)
            if not revised_source.strip():
                revised_error = "BYO-LLM returned an empty completion"
                step = RefinementStep(
                    iteration=i,
                    proved=False,
                    lean_source=current_source,
                    error=revised_error,
                    next_actions=[],
                    wall_sec=time.time() - t_start,
                )
                history.append(step)
                continue
        except Exception as exc:  # noqa: BLE001 — transport failures are loop-survivable
            logger.warning(
                "simple_prove_template refine iter=%d: LLM call failed: %s",
                i, exc,
            )
            step = RefinementStep(
                iteration=i,
                proved=False,
                lean_source=current_source,
                error=f"LLM call failed: {type(exc).__name__}: {exc}",
                next_actions=[],
                wall_sec=time.time() - t_start,
            )
            history.append(step)
            continue

        # Persist the candidate so the customer can inspect every
        # attempt offline, then re-verify against the Pythia lake
        # project. The verdict shape matches `_verify_in_pythia_project`
        # so downstream code (vacuous-check, _verdict_to_nl, _extract_
        # next_actions) is unchanged.
        (run_dir / f"refine_{i}.lean").write_text(revised_source)
        new_verdict = _verify_in_pythia_project(revised_source, run_id=run_id)
        new_proved = bool(new_verdict.get("proved", False))
        step = RefinementStep(
            iteration=i,
            proved=new_proved,
            lean_source=revised_source,
            error=None if new_proved else str(new_verdict.get("error") or ""),
            next_actions=_extract_next_actions(new_verdict),
            wall_sec=time.time() - t_start,
        )
        history.append(step)
        current_source = revised_source
        current_verdict = new_verdict
        if new_proved:
            break

    return current_verdict, current_source, history


def _build_refine_prompt(
    *,
    hypothesis: str,
    previous_lean: str,
    error: str,
    next_actions: list[NextAction],
) -> str:
    """Compose the BYO-LLM refinement prompt.

    Lifts the error-line filter convention from
    ``kairos.lean_cycle._refinement_prompt``: cap raw lake stderr at
    ~30 lines / 4 KB so a verbose import-tree linter dump doesn't
    crowd out the actionable diagnostic. Threads the parsed
    ``next_actions`` in as structured guidance so the model isn't
    re-deriving suggestions the parser already produced.
    """
    err_lines: list[str] = []
    seen_chars = 0
    for line in (error or "").splitlines():
        if seen_chars > 4000 or len(err_lines) >= 30:
            break
        line = line.rstrip()
        if not line:
            continue
        err_lines.append(line)
        seen_chars += len(line) + 1
    err_block = "\n".join(err_lines) or "(no error captured)"

    if next_actions:
        actions_block = "\n".join(
            f"- [{a.action}] {a.suggestion}" for a in next_actions[:6]
        )
    else:
        actions_block = "(parser produced no typed suggestions)"

    return (
        "You are repairing a Lean 4 proof that failed lake build.\n\n"
        f"Customer hypothesis (English): {hypothesis}\n\n"
        "Previous Lean source (it failed verification):\n"
        f"```lean\n{previous_lean}\n```\n\n"
        "Lake build error (truncated):\n"
        f"```\n{err_block}\n```\n\n"
        "Typed suggestions from the SDK's error parser:\n"
        f"{actions_block}\n\n"
        "Produce a revised, complete Lean source that addresses the "
        "error. Output ONLY the Lean source — no prose, no markdown "
        "fences are required, but if you include a ```lean``` block "
        "the SDK will strip it. Keep imports + namespaces consistent "
        "with the previous source unless the error specifically "
        "demands a change."
    )


def _strip_lean_fence(text: str) -> str:
    """Pull the body of a fenced ```lean``` block when the model
    wraps its output. Falls through to the raw text otherwise."""
    import re as _re
    m = _re.search(r"```(?:lean)?\s*\n(.*?)\n?```", text, _re.DOTALL)
    if m:
        return m.group(1).strip()
    return text.strip()


def _resolve_spec(hypothesis: str):
    """Match against Pythia templates. Fall back to BYO LLM if no
    pattern fires + a key is configured. Returns (spec, used_llm)."""
    from kairos.verticals import pythia

    spec = pythia.match(hypothesis)
    if spec is not None:
        return spec, False

    # No deterministic match — try the BYO LLM augmentation if a key
    # is configured. This is opt-in: customers without a key get the
    # template-only path.
    from kairos import llm_byo

    if not llm_byo.is_available():
        return None, False

    try:
        spec = _llm_fill_template(hypothesis)
    except Exception as e:  # noqa: BLE001
        logger.warning("simple_prove_template: LLM fill failed: %s", e)
        return None, False
    return spec, True


def _llm_fill_template(hypothesis: str):
    """Ask the BYO LLM to map `hypothesis` to a Pythia template + bindings.

    The prompt is deliberately narrow: it asks the model to produce
    one of the existing pattern IDs + the bindings, NOT free-form Lean.
    Keeping the model's output structured means we can validate it
    against `pythia._PATTERNS` before generating Lean.
    """
    from kairos import llm_byo
    from kairos.verticals import pythia

    pattern_ids = pythia.list_patterns()
    prompt = (
        "You are a structured-output classifier for the Athanor SDK's "
        "Pythia free-tier verifier. Given a customer's natural-language "
        "hypothesis, pick the most appropriate template from this list:\n"
        f"{', '.join(pattern_ids)}\n"
        "Then extract the field/bound names mentioned in the hypothesis.\n"
        "Respond with ONLY a JSON object — no prose, no markdown fences:\n"
        '{"pattern_id": "<one_of_the_above>", '
        '"bindings": {"<name>": "<value>", ...}}\n\n'
        f"Hypothesis: {hypothesis}\n"
        "JSON:"
    )
    raw = llm_byo.complete(prompt, max_tokens=200)

    import json
    import re
    # Models sometimes still wrap output in ``` despite "no markdown".
    # Strip any code fences before parsing.
    stripped = re.sub(r"^```[a-z]*\n|```$", "", raw.strip(), flags=re.MULTILINE)
    parsed = json.loads(stripped)
    pattern_id = parsed["pattern_id"]
    bindings = parsed.get("bindings", {})

    # Look up the matching pattern + render its template with the
    # LLM-supplied bindings. We do NOT trust the LLM to produce Lean —
    # it only produces (pattern_id, bindings).
    for p in pythia._PATTERNS:
        if p.pattern_id != pattern_id:
            continue
        try:
            lean_source = p.template.format(**bindings)
            nl_summary = p.nl_template.format(**bindings)
        except KeyError as e:
            raise RuntimeError(
                f"LLM returned bindings for pattern {pattern_id!r} that "
                f"don't match the template's expected fields: missing {e}"
            )
        return pythia.PythiaSpec(
            lean_source=lean_source,
            nl_summary=nl_summary,
            pattern_id=pattern_id,
            bindings=bindings,
        )
    raise RuntimeError(
        f"LLM returned unknown pattern_id {pattern_id!r}; "
        f"valid IDs: {pattern_ids}"
    )


def _verify(lean_source: str) -> dict[str, Any]:
    """Run `kairos.lean.verify_proof` and normalise the result to a dict.

    Standalone path — used as fallback when the Pythia Lake project
    bootstrap fails. Doesn't resolve `import Pythia.X` (no project
    context); customers calling simple_prove_template generally hit
    `_verify_in_pythia_project` instead.
    """
    from kairos.lean import verify_proof

    try:
        result = verify_proof(lean_source)
    except Exception as e:  # noqa: BLE001
        return {
            "proved": False,
            "error": str(e),
            "error_class": type(e).__name__,
        }
    if hasattr(result, "__dict__"):
        return {**result.__dict__, "proved": getattr(result, "proved", False)}
    return {"proved": False, "raw": str(result)}


def _verify_in_pythia_project(
    lean_source: str, *, run_id: str,
) -> dict[str, Any]:
    """ATH-702: run `lake build` against the bootstrapped Pythia project.

    On bootstrap failure (no `lake` on PATH, network failure on first-
    run download, etc), surface a structured error in the verdict
    rather than crashing — the customer's `result.summary` then shows
    the actionable cause.

    Honors `KAIROS_SIMPLE_PROVE_SKIP_VERIFY=1` (tests set this to
    avoid spinning the real Pythia bootstrap during the SDK test
    suite). Returns a synthetic "skipped" verdict when set.
    """
    import os as _os
    if _os.environ.get("KAIROS_SIMPLE_PROVE_SKIP_VERIFY") == "1":
        return {
            "proved": False,
            "error": "verify skipped (KAIROS_SIMPLE_PROVE_SKIP_VERIFY=1)",
            "error_class": "SkippedForTest",
        }
    try:
        from kairos._pythia_lake import (
            BootstrapError,
            ensure_project,
            lake_build_run,
            write_run_file,
        )
        project = ensure_project()
        write_run_file(project, run_id, lean_source)
        success, stdout, stderr = lake_build_run(project, run_id)
        if success:
            return {"proved": True, "lake_stdout": stdout[:500]}
        return {
            "proved": False,
            "error": stderr.strip()[:500] or "lake build failed without stderr",
            "error_class": "LakeBuildError",
            "lake_stdout": stdout[:500],
        }
    except BootstrapError as e:
        return {
            "proved": False,
            "error": str(e),
            "error_class": "BootstrapError",
        }
    except Exception as e:  # noqa: BLE001
        return {
            "proved": False,
            "error": str(e),
            "error_class": type(e).__name__,
        }


def _verdict_to_nl(
    verdict: dict[str, Any], spec, *,
    show_lean: bool,
    vacuous_clean: bool | None = None,
    axiom_clean: bool | None = None,
) -> str:
    """Translate the structured verdict back into one-paragraph English."""
    if verdict.get("proved"):
        # ATH-949 (2026-05-03 asabi Option C): when the kernel accepted
        # the proof but the audit caught a soundness violation, the
        # customer-facing message must NOT lead with "proved". The
        # warning glyph alone (pre-fix) was a heuristic-cosmetic
        # defense; the structural claim ("proved") was unchanged. Now
        # the soundness verdict drives the head verb.
        if vacuous_clean is False:
            head = (
                f"✗ unsound (vacuous: macro-bodied sorry/admit "
                f"detected). {spec.nl_summary}. The kernel accepted "
                f"the proof but it closes via a macro that expands to "
                f"`sorry`; the verdict is not load-bearing. "
                f"`result.kernel_accepted=True`, `result.proved=False`."
            )
        elif axiom_clean is False:
            head = (
                f"✗ unsound (custom axiom smuggled). {spec.nl_summary}. "
                f"The kernel accepted the proof but it depends on a "
                f"non-Mathlib axiom declaration; the trust base is "
                f"wider than the standard "
                f"`{{propext, Classical.choice, Quot.sound}}` set. "
                f"`result.kernel_accepted=True`, `result.proved=False`."
            )
        else:
            head = f"✓ proved. {spec.nl_summary}."
    elif verdict.get("rejected_reason") == "vacuous_truth":
        head = (
            f"✗ rejected (vacuous proof). {spec.nl_summary}. The kernel "
            f"accepted the proof but `reject_vacuous=True` downgraded it: "
            f"a macro-bodied sorry/admit was detected."
        )
    elif verdict.get("rejected_reason") == "custom_axiom":
        head = (
            f"✗ rejected (custom axiom). {spec.nl_summary}. The proof "
            f"depends on a smuggled axiom declaration; "
            f"`reject_vacuous=True` downgraded the verdict."
        )
    elif "error" in verdict:
        head = (
            f"✗ could not verify. {spec.nl_summary}. "
            f"Lean reported: {verdict['error']}"
        )
    else:
        head = (
            f"✗ disproved or undecided. {spec.nl_summary}. "
            f"The Pythia spec did not provide a proof for this property; "
            f"check your spec's invariants."
        )
    if show_lean:
        return f"{head}\n\nGenerated Lean:\n{spec.lean_source}"
    return head


def _no_match_result(hypothesis: str, run_dir: Path) -> SimpleProveResult:
    """Customer's hypothesis didn't match any template + no BYO key."""
    from kairos import llm_byo
    from kairos.verticals import pythia

    available = ", ".join(pythia.list_patterns())
    example_shapes = (
        "'prove c_vector_sharp is positive', "
        "'prove c_aCS_sharp <= c_vector_sharp', "
        "'prove c_vector_sharp equals sqrt 2 times c_HR_sharp', "
        "'prove Pythia.Time is a natural number', "
        "'verify the Pythia API'"
    )
    if llm_byo.is_available():
        # LLM is configured but the fill failed — the LLM-fill exception
        # was already logged. Tell the customer plainly.
        msg = (
            f"could not map hypothesis to a Pythia template, even with "
            f"BYO LLM augmentation. Available templates: {available}. "
            f"Try rephrasing closer to one of: {example_shapes}."
        )
    else:
        msg = (
            f"no Pythia template matched your hypothesis. Available templates: "
            f"{available}. Either rephrase to match one of the supported "
            f"shapes ({example_shapes}), OR set "
            f"ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY in your "
            f"environment to enable the BYO LLM fallback."
        )
    return SimpleProveResult(
        summary=f"✗ {msg}",
        proved=False,
        pattern_id=None,
        used_llm=False,
        spec_path=None,
        raw={"hypothesis": hypothesis},
    )


def _spec_health_fail_result(
    hypothesis: str, run_dir: Path, spec, health_report,
) -> SimpleProveResult:
    """ATH-743: format a SimpleProveResult that conveys the spec
    health failure to the customer. We surface it as
    `proved=False` with a summary that names the probe that failed
    + the actionable detail; the customer sees the
    autoformalization problem before any proof attempt happens.
    """
    spec_path = run_dir / "spec.lean"
    summary_lines = [
        "✗ spec health gate halted: autoformalization is suspect",
        f"  hypothesis: {hypothesis!r}",
        f"  score={health_report.score:.2f} (threshold = 0.6)",
    ]
    if health_report.block_on:
        summary_lines.append(
            f"  blocked on: {', '.join(health_report.block_on)}"
        )
    for w in health_report.warnings[:5]:
        summary_lines.append(f"  · {w}")
    summary_lines.append(
        "  → fix the autoformalization (rephrase the English claim, "
        "or try `simple_prove_template(hypothesis, spec_health_check=False)` "
        "to bypass the gate at your own risk)."
    )
    return SimpleProveResult(
        summary="\n".join(summary_lines),
        proved=False,
        pattern_id=getattr(spec, "pattern_id", None),
        used_llm=True,  # the autoformalization step did invoke the LLM
        spec_path=spec_path,
        raw={
            "hypothesis": hypothesis,
            "spec_health_report": {
                "score": health_report.score,
                "block_on": health_report.block_on,
                "probes": [
                    {"name": p.name, "score": p.score,
                     "severity": p.severity, "detail": p.detail}
                    for p in health_report.probes
                ],
                "warnings": health_report.warnings,
            },
        },
    )


__all__ = [
    "NextAction",
    "RefinementStep",
    "SimpleProveResult",
    "simple_prove_template",
]
