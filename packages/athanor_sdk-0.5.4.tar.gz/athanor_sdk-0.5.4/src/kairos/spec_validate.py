"""solve/shared/spec_validate.py — Stage-A spec validator (ATH-358).

Runs the JSON Schema check + rule-based sanity checks a customer can
hit locally without the licensed builder tarball. Mirrored at
`athanor-sdk/src/athanor/spec_validate.py` so `pip install athanor-sdk`
alone exercises Stage A (ATH-358 prospect-flow).

Stage A returns:

    ValidateResult = {
        "ok": bool,
        "stage": "A",
        "defects": [{"field": str, "severity": str, "message": str}],
    }

Stage B (LLM coherence) lives in `solve.shared.phases.spec_validate_llm`
and is gated on builder presence — see `athanor.sdk._has_builder()` for
the runtime check.

Rule-based checks Stage A runs (all fast, deterministic, free):
  1. JSON Schema validation against spec_schema.json.
  2. target_file exists + readable on disk.
  3. target_name appears in target_file via a grep-style lookup
     (heuristic; misses on renamed-but-aliased definitions, which is
     OK — Stage B catches those).
  4. budget.wall_seconds and budget.usd are both positive.
  5. vertical is consistent with target_file extension (warning, not
     error — the extension map is advisory).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from kairos.spec_v1 import EXTENSION_TO_VERTICAL, REQUIRED_FIELDS, SPEC_VERSION

_SCHEMA_PATH = Path(__file__).with_name("spec_schema.json")


@dataclass
class Defect:
    field: str
    severity: str  # "error" | "warning"
    message: str


@dataclass
class ValidateResult:
    ok: bool
    stage: str  # "A" | "B" | "full"
    defects: List[Defect] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "ok":      self.ok,
            "stage":   self.stage,
            "defects": [
                {"field": d.field, "severity": d.severity, "message": d.message}
                for d in self.defects
            ],
        }


def _load_schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text())


def _validate_schema(spec: dict) -> List[Defect]:
    """Minimal JSON Schema check.

    We do NOT pull in `jsonschema` — it's a heavy runtime dep for a
    customer SDK. Instead, check the required fields + types we care
    about. Full JSON Schema is still authoritative (CI + the SDK copy
    both ship the .json file); this is the runtime slim check.
    """
    defects: List[Defect] = []
    if spec.get("spec_version") != SPEC_VERSION:
        defects.append(Defect(
            "spec_version", "error",
            f"expected '{SPEC_VERSION}', got {spec.get('spec_version')!r}",
        ))
    for f in REQUIRED_FIELDS:
        if f not in spec:
            defects.append(Defect(f, "error", "required field missing"))
    # Budget sub-check.
    if "budget" in spec:
        b = spec["budget"]
        if not isinstance(b, dict):
            defects.append(Defect("budget", "error", "must be an object"))
        else:
            if not isinstance(b.get("wall_seconds"), int) or b.get("wall_seconds", 0) <= 0:
                defects.append(Defect("budget.wall_seconds", "error",
                                      "must be a positive integer"))
            if not isinstance(b.get("usd"), (int, float)) or b.get("usd", 0) <= 0:
                defects.append(Defect("budget.usd", "error",
                                      "must be a positive number"))
    return defects


def _validate_target_file(spec: dict) -> List[Defect]:
    defects: List[Defect] = []
    target_file = spec.get("target_file")
    if not target_file:
        return defects  # schema check already flagged
    p = Path(target_file)
    if not p.exists():
        defects.append(Defect(
            "target_file", "error",
            f"file does not exist: {target_file}",
        ))
        return defects
    if not p.is_file():
        defects.append(Defect(
            "target_file", "error",
            f"not a regular file: {target_file}",
        ))
        return defects
    try:
        p.read_text()
    except (OSError, UnicodeDecodeError) as e:
        defects.append(Defect(
            "target_file", "error",
            f"unreadable: {e}",
        ))
    return defects


def _validate_target_name_in_file(spec: dict) -> List[Defect]:
    """Heuristic grep for target_name in target_file.

    Lean: `theorem|lemma|def` prefix. SV: `module|property|assertion`.
    Dafny: `theorem|lemma`. Python: `def|class`. The check is loose;
    false negatives are acceptable (Stage B catches those).
    """
    defects: List[Defect] = []
    tf = spec.get("target_file")
    tn = spec.get("target_name")
    if not tf or not tn:
        return defects
    try:
        body = Path(tf).read_text()
    except (OSError, UnicodeDecodeError):
        return defects  # target_file check already flagged
    ext = Path(tf).suffix.lower()
    if ext == ".lean":
        pattern = rf"^\s*(theorem|lemma|def|abbrev)\s+{re.escape(tn)}\b"
    elif ext in (".sv", ".svh", ".v"):
        pattern = rf"^\s*(module|property|assertion|assert\s+property)\s+[\w_]*{re.escape(tn)}"
    elif ext == ".dfy":
        pattern = rf"^\s*(theorem|lemma|method)\s+{re.escape(tn)}\b"
    elif ext == ".py":
        pattern = rf"^\s*(def|class)\s+{re.escape(tn)}\b"
    else:
        return defects  # unknown extension, skip this check
    if not re.search(pattern, body, re.MULTILINE):
        defects.append(Defect(
            "target_name", "warning",
            f"name '{tn}' not found in {tf} via heuristic lookup; "
            f"Stage B may flag this as incoherent",
        ))
    return defects


def _validate_vertical_extension_match(spec: dict) -> List[Defect]:
    defects: List[Defect] = []
    tf = spec.get("target_file")
    vertical = spec.get("vertical")
    if not tf or not vertical:
        return defects
    ext = Path(tf).suffix.lower()
    if ext in EXTENSION_TO_VERTICAL:
        expected = EXTENSION_TO_VERTICAL[ext]
        # .lean can map to any of (bbr3, action_cred, lean) — different
        # Kairos projects share the same extension. Allow any of the
        # lean-family verticals.
        lean_family = {"bbr3", "action_cred", "lean"}
        if expected == "lean" and vertical in lean_family:
            return defects
        if expected != vertical:
            defects.append(Defect(
                "vertical", "warning",
                f"vertical={vertical!r} doesn't match target_file "
                f"extension {ext} (expected {expected!r}); proceed "
                f"only if your setup genuinely crosses verticals",
            ))
    return defects


def validate_stage_a(spec: dict) -> ValidateResult:
    """Run all rule-based Stage A checks. SDK-only, no builder deps."""
    defects: List[Defect] = []
    defects.extend(_validate_schema(spec))
    # Only run file-level checks once the schema ones pass; otherwise
    # target_file may not even be set.
    if not any(d.severity == "error" and d.field.startswith("target_file") for d in defects):
        defects.extend(_validate_target_file(spec))
    defects.extend(_validate_target_name_in_file(spec))
    defects.extend(_validate_vertical_extension_match(spec))
    ok = not any(d.severity == "error" for d in defects)
    return ValidateResult(ok=ok, stage="A", defects=defects)


def validate_from_path(path: Path) -> ValidateResult:
    try:
        spec = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        return ValidateResult(
            ok=False, stage="A",
            defects=[Defect("<file>", "error", f"unreadable or not JSON: {e}")],
        )
    if not isinstance(spec, dict):
        return ValidateResult(
            ok=False, stage="A",
            defects=[Defect("<top>", "error", "spec.json root must be an object")],
        )
    return validate_stage_a(spec)
