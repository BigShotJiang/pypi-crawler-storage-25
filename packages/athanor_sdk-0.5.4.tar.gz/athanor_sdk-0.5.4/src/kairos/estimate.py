"""Cost estimation for evaluation runs (pre-run budget guide).

Estimates API cost based on task count, average tokens per task, and
model pricing. Pricing is approximate and meant as a budget guide.

ATH-540: rates source-of-truth is now :mod:`kairos.model_prices` —
before this consolidation, estimate.py carried its own ``MODEL_PRICING``
tuple table that drifted from ``model_prices.MODEL_PRICES`` (stale
Kimi K2.5 / missing K2.6 / missing azure_ai/ prefixes / inconsistent
Sonnet & Haiku rates). Pre-run estimates disagreed with per-run
reported cost. Now both paths read the same table.

Public surface retained for backward compat:
  * ``MODEL_PRICING`` — ``dict[str, tuple[input, output]]`` synthesised
    at import time from ``MODEL_PRICES``. Keyed by normalized model
    name (no provider prefix); first prefix-hit wins when multiple
    ``MODEL_PRICES`` entries share a normalized form.
  * ``estimate_cost(model, num_tasks, ...)`` — unchanged shape.
  * ``normalize_model(model)`` — unchanged.
"""
from __future__ import annotations

from kairos.model_prices import MODEL_PRICES


# Token defaults retained here — they're estimation-specific, not
# part of the per-phase pricing table.
DEFAULT_INPUT_TOKENS = 4000   # task description + stub + shared files
DEFAULT_OUTPUT_TOKENS = 2500  # agent thinking + code
DEFAULT_RETRY_MULTIPLIER = 2.5  # retries on average double the input tokens


# Provider prefixes we strip when matching a user-supplied model id
# against the underlying MODEL_PRICES keys. Order matters only for
# substring avoidance — longest prefix first is safest.
_PROVIDER_PREFIXES = (
    "anthropic/",
    "azure_ai/",
    "google/",
    "gemini/",
    "openai/",
    "azure/",
)


def normalize_model(model: str) -> str:
    """Strip provider prefix from model names.

    Matches the legacy pre-ATH-540 behavior — callers passing
    ``anthropic/claude-opus-4-6`` get back ``claude-opus-4-6`` so the
    estimate output shows the compact name. MODEL_PRICES lookups still
    happen against the fully-qualified form internally.
    """
    for prefix in _PROVIDER_PREFIXES:
        if model.lower().startswith(prefix):
            return model[len(prefix):]
    return model


def _build_compat_pricing() -> dict[str, tuple[float, float]]:
    """Synthesise the legacy ``MODEL_PRICING`` shape (normalized-name keys,
    ``(input, output)`` tuples) from the canonical
    :data:`kairos.model_prices.MODEL_PRICES` table.

    When multiple MODEL_PRICES entries share a normalized name (e.g.
    ``openai/kimi-k2.5`` + ``azure_ai/kimi-k2.5``), first one wins —
    they carry the same rates by ATH-528 invariant anyway.
    """
    out: dict[str, tuple[float, float]] = {}
    for key, rates in MODEL_PRICES.items():
        norm = normalize_model(key)
        if norm in out:
            # First hit wins — ATH-528 invariant keeps openai/ + azure_ai/
            # provider-prefix siblings at identical rates, so overwriting
            # would be a no-op, but the first-wins policy is cleaner.
            continue
        out[norm] = (float(rates["input"]), float(rates["output"]))
    return out


# Exposed symbol, retained for backward compat — cli.py + tests import it.
# Built once at module import; if MODEL_PRICES grows mid-process the
# dict is stale until the module reloads. That's fine — estimates are a
# pre-run budgeting tool, not a per-call hot path.
MODEL_PRICING: dict[str, tuple[float, float]] = _build_compat_pricing()


def _lookup_rates(model: str) -> tuple[float, float] | None:
    """Return ``(input_per_1m, output_per_1m)`` for ``model``.

    Priority:
      1. Exact MODEL_PRICES hit (prefixed form, e.g. ``openai/kimi-k2.5``).
      2. Normalized-name hit in the synthesised compat map.
      3. Partial-name substring match (legacy heuristic: ``opus`` matches
         ``claude-opus-4-6``). Preserved so the CLI keeps its friendly
         shorthand support.
    """
    if model in MODEL_PRICES:
        rates = MODEL_PRICES[model]
        return float(rates["input"]), float(rates["output"])

    normalized = normalize_model(model)
    # ATH-867: empty / whitespace-only model would match the partial-
    # heuristic below (``"" in any_string`` is always True), returning
    # whatever model iterates first. Guard before the loop so the
    # caller hits the unknown-model error path instead of getting an
    # arbitrary price quote.
    if not normalized.strip():
        return None
    if normalized in MODEL_PRICING:
        return MODEL_PRICING[normalized]

    # Partial-match heuristic — retained from pre-ATH-540 behavior.
    for key, p in MODEL_PRICING.items():
        if key in normalized or normalized in key:
            return p

    return None


def estimate_cost(
    model: str,
    num_tasks: int,
    *,
    avg_input_tokens: int = DEFAULT_INPUT_TOKENS,
    avg_output_tokens: int = DEFAULT_OUTPUT_TOKENS,
    retry_multiplier: float = DEFAULT_RETRY_MULTIPLIER,
) -> dict:
    """Estimate the cost of running N tasks on a model.

    Args:
        model: model id (with or without provider prefix)
        num_tasks: number of tasks to evaluate
        avg_input_tokens: average input tokens per task (default 4000)
        avg_output_tokens: average output tokens per task (default 2500)
        retry_multiplier: multiplier accounting for retries (default 2.5x)

    Returns:
        Dict with cost breakdown in USD, or a dict with an ``error`` key
        when the model is unknown.
    """
    normalized = normalize_model(model)
    pricing = _lookup_rates(model)

    if pricing is None:
        return {
            "model": model,
            "num_tasks": num_tasks,
            "error": (
                f"Unknown model: {model}. Supported: "
                f"{sorted(MODEL_PRICING.keys())}"
            ),
        }

    input_per_1m, output_per_1m = pricing

    total_input = num_tasks * avg_input_tokens * retry_multiplier
    total_output = num_tasks * avg_output_tokens * retry_multiplier

    input_cost = (total_input / 1_000_000) * input_per_1m
    output_cost = (total_output / 1_000_000) * output_per_1m
    total_cost = input_cost + output_cost

    return {
        "model": normalized,
        "num_tasks": num_tasks,
        "input_tokens": round(total_input),
        "output_tokens": round(total_output),
        "input_cost_usd": round(input_cost, 4),
        "output_cost_usd": round(output_cost, 4),
        "total_cost_usd": round(total_cost, 4),
        "cost_per_task_usd": round(total_cost / num_tasks, 4) if num_tasks else 0.0,
        "pricing_per_1m": {"input": input_per_1m, "output": output_per_1m},
    }
