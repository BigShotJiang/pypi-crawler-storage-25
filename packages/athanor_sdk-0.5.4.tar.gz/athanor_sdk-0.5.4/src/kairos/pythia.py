"""kairos.pythia — SDK-side wrapper over the vendored Pythia Lean library.

`Pythia` (Lean library, capitalized in upstream) is a Lean 4 tactic
library for closing proofs in probability and statistics. Specializes
Mathlib automation (`simp`, `linarith`, `aesop`, `bound`, `measurability`)
for statistical reasoning. Source: <https://github.com/athanor-ai/pythia>.

This module exposes the SDK-side wrapper around a vendored snapshot
of the upstream Lean source. The vendored copy lives under
`kairos/_vendor/pythia/` (zero modifications to upstream); the
snapshot may lag the upstream `Pythia` git head by days, synced each
minor SDK release.

Two consumption paths:

1. **Raw Lean (no SDK).** Drop `require pythia from git "https://github.com/athanor-ai/pythia.git" @ "v..."` in your lakefile and import the Lean modules directly. Use this if you're a Lean-native customer who just wants the proof library.

2. **SDK-integrated (this module).** `from kairos import pythia` exposes:
   - `pythia.vendor_path()` returns the absolute Path to the vendored
     Lean source (suitable for use as a lakefile `from path` dep).
   - Future: parsers, scaffolders, and batch-verify helpers (post-v1).

Vendoring policy: zero modifications to upstream. The vendored
snapshot is read-only; do not mutate files under `kairos/_vendor/pythia/`.

Tier classification (per `docs/sdk-tier-model.md` §11): **free** —
the vendored Apache-2.0 source ships in the default wheel and the
wrapper API has no license gate. Mathlib oleans are NOT vendored
(per Aidan-ratified Q1+Q2 ts=1777184500); customers pull Mathlib via
Lake at first build time.
"""
from __future__ import annotations

from pathlib import Path

_VENDOR_ROOT = Path(__file__).parent / "_vendor" / "pythia"


def vendor_path() -> Path:
    """Absolute path to the vendored Pythia Lean source root.

    Suitable for use as a lakefile `from path` dependency:

        require pythia from path "<vendor_path>"

    The returned path is read-only by convention; do not mutate
    files under it. Snapshot syncs land via SDK release commits, not
    in-place edits.

    Returns:
        Path to ``<sdk_install>/kairos/_vendor/pythia/`` containing
        the upstream `lakefile.lean`, `lean-toolchain`, the `Pythia/`
        Lean module tree, and the upstream `LICENSE` file.

    Raises:
        FileNotFoundError: if the vendored source is missing (the SDK
        install is incomplete or the wheel was built without vendored
        sources).
    """
    if not _VENDOR_ROOT.is_dir():
        raise FileNotFoundError(
            f"Vendored Pythia source not found at {_VENDOR_ROOT}. "
            "The SDK wheel may be missing its vendored Lean sources; "
            "reinstall via `pip install --force-reinstall athanor-sdk`."
        )
    return _VENDOR_ROOT


__all__ = ["vendor_path"]
