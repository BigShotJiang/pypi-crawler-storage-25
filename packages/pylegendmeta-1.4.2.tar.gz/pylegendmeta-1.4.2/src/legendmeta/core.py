# Copyright (C) 2022 Luigi Pertoldi <gipert@pm.me>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import copy
import logging
import os
import re
from getpass import getuser
from pathlib import Path
from tempfile import gettempdir

from dbetto import TextDB
from git import GitCommandError, InvalidGitRepositoryError, Repo
from packaging.version import Version

log = logging.getLogger(__name__)


class MetadataRepository(TextDB):
    """Base class for git-based metadata repositories.

    Class representing a metadata repository with utilities for fast access
    via git.

    If no valid path to an existing metadata directory is provided, will
    attempt to clone the repository via SSH and git-checkout the latest
    stable tag (vM.m.p format).

    Note
    ----
    This class is designed to be subclassed, not instantiated directly.
    Derived classes should provide the required repository configuration
    (repo_url, env_var, default_dir_name) via ``super().__init__()``.

    Parameters
    ----------
    path
        path to metadata repository. If not existing, will attempt a
        git-clone through SSH. If ``None``, metadata will be cloned
        in a temporary directory (see :func:`tempfile.gettempdir`).
    repo_url
        URL of the git repository to clone (e.g., "git@github.com:org/repo").
    env_var
        name of the environment variable to check for repository path.
    default_dir_name
        default directory name for cloning in temp directory.
    **kwargs
        further keyword arguments forwarded to :class:`TextDB.__init__`.
    """

    def __init__(
        self,
        path: str | None = None,
        repo_url: str = "",
        env_var: str = "",
        default_dir_name: str = "",
        **kwargs,
    ) -> None:
        self.__repo_url__ = repo_url
        self.__env_var__ = env_var
        self.__default_dir_name__ = default_dir_name

        if isinstance(path, (str, Path)):
            self.__repo_path__ = path
        else:
            self.__repo_path__ = os.getenv(env_var, "")

        if self.__repo_path__ == "":
            self.__repo_path__ = str(
                Path(gettempdir()) / (default_dir_name + getuser())
            )

        self.__repo_path__ = Path(self.__repo_path__)

        # self.__repo__: Repo =
        self._init_metadata_repo()

        super().__init__(self.__repo_path__, **kwargs)

    def _init_metadata_repo(self) -> None:
        """Clone metadata repository, if not existing, and checkout latest stable tag."""
        exp_path = os.path.expandvars(self.__repo_path__)
        while self.__repo_path__ != exp_path:
            self.__repo_path__ = exp_path
            exp_path = os.path.expandvars(self.__repo_path__)

        self.__repo_path__ = Path(self.__repo_path__)
        self.__repo_path__ = self.__repo_path__.resolve(strict=False)

        if self.__repo_path__.exists() and not self.__repo_path__.is_dir():
            msg = f"cannot initialize with a file: {self.__repo_path__}"
            raise ValueError(msg)

        if not self.__repo_path__.exists() or not any(self.__repo_path__.iterdir()):
            msg = f"Cloning {self.__repo_url__} in {self.__repo_path__}..."
            # set logging level as warning (default logging level), so it's
            # always printed and the user knows why it takes so long to initialize
            log.warning(msg)

            if not Path(self.__repo_path__).exists():
                msg = f"mkdir {self.__repo_path__}"
                log.debug(msg)
                Path(self.__repo_path__).mkdir()

            self.__repo__ = Repo.clone_from(
                self.__repo_url__,
                self.__repo_path__,
                multi_options=["--recurse-submodules"],
            )

            # checkout metadata at its latest stable tag
            if self.latest_stable_tag is not None:
                msg = (
                    f"Checking out the latest stable tag ({self.latest_stable_tag})..."
                )
                log.warning(msg)

                self.checkout(self.latest_stable_tag, rescan=False)
            else:
                msg = "No stable tags found, checking out the default branch"
                log.warning(msg)

        try:
            msg = f"trying to load Git repo in {self.__repo_path__}"
            log.debug(msg)
            self.__repo__ = Repo(self.__repo_path__)

        except InvalidGitRepositoryError:
            self.__repo__ = None

    def __copy__(self) -> MetadataRepository:
        cls = self.__class__
        new_obj = cls.__new__(cls)
        new_obj.__dict__.update(self.__dict__)
        return new_obj

    def __deepcopy__(self, memo: dict[int, object]) -> MetadataRepository:
        cls = self.__class__
        new_obj = cls.__new__(cls)
        memo[id(self)] = new_obj
        for key, value in self.__dict__.items():
            if key in {"_TextDB__rootdir", "__repo__", "__repo_path__"}:
                new_obj.__dict__[key] = value
            else:
                new_obj.__dict__[key] = copy.deepcopy(value, memo)
        return new_obj

    def __getstate__(self) -> dict:
        """Return state for pickling.

        GitPython's Repo object is not reliably pickleable, so we exclude it and
        recreate it on unpickle.
        """
        state = dict(self.__dict__)
        state["__repo__"] = None
        return state

    def __setstate__(self, state: dict) -> None:
        """Restore state from pickling.

        Re-initialize the Git repository handle so the instance is functional.
        """
        self.__dict__.update(state)

        # Ensure __repo_path__ is a Path before re-initializing the repo.
        self.__dict__["__repo_path__"] = Path(self.__dict__["__repo_path__"])

        # Recreate a functional Repo handle (and clone if needed).
        self._init_metadata_repo()

    @property
    def latest_stable_tag(self) -> Version | None:
        """Latest stable metadata tag (i.e. strictly numeric vM.m.p)"""
        self._except_if_not_git_repo()

        tag_list = [tag.name for tag in self.__repo__.tags]

        version_regex = re.compile(r"^v\d+\.\d+\.\d+$")
        version_tags = [t for t in tag_list if version_regex.match(t)]

        if not version_tags:
            log.warning(
                "No valid version tags (vM.m.p) found in this repository, "
                "defaulting to the current Git ref."
            )
            return None

        # drop the leading 'v'
        version_tags.sort(key=lambda t: Version(t[1:]))

        return version_tags[-1]

    def checkout(self, git_ref: str | Version, rescan: bool = True) -> None:
        """Select a metadata repository version."""
        self._except_if_not_git_repo()

        if isinstance(git_ref, Version):
            git_ref = "v" + str(git_ref)

        try:
            self.__repo__.git.checkout(git_ref)
            self.__repo__.git.submodule("update", "--init")
        except GitCommandError:
            self.__repo__.remote().pull()
            self.__repo__.git.checkout(git_ref)
            self.__repo__.git.submodule("update", "--init")

        # now reset this TextDB instance
        super().reset(rescan=rescan)

    @property
    def __version__(self) -> str:
        """Metadata repository version.

        Calculated with ``git describe``, looking for the closest tag with a
        name based on semantic versioning.
        """
        self._except_if_not_git_repo()

        return self.__repo__.git.describe(
            "--tags", "--always", "--match=v[0-9]*[0-9]*[0-9]*"
        )

    @property
    def __closest_tag__(self) -> Version:
        """Metadata repository Git tag closest to the current commit.

        Calculated with ``git describe``, looking for the closest tag with a
        name based on semantic versioning.
        """
        self._except_if_not_git_repo()

        return Version(
            self.__repo__.git.describe(
                "--tags", "--always", "--match=v[0-9]*[0-9]*[0-9]*", "--abbrev=0"
            )
        )

    def show_metadata_version(self) -> None:
        """Logs version info for metadata repository and all its submodules."""
        self._except_if_not_git_repo()

        print(f"{self.__repo__.working_dir}: {self.__version__}")  # noqa: T201

        submods = self.__repo__.submodules
        for i, s in enumerate(submods):
            char = "└──" if i == len(submods) - 1 else "├──"
            version = s.module().git.describe("--tags", "--always")
            print(f"{char} {s.name}: {version}")  # noqa: T201

    def _except_if_not_git_repo(self) -> None:
        if self.__repo__ is None:
            msg = f"{self.__repo_path__} is not a Git repository (.git folder missing)"
            raise InvalidGitRepositoryError(msg)

        try:
            self.__repo__.git.rev_parse("HEAD")
        except GitCommandError as e:
            if "fatal: detected dubious ownership" in e.stderr:
                msg = f"git raised dubious ownership error. Automatically called 'git config --global --add safe.directory {self.__repo_path__}`"
                log.warning(msg)
                with self.__repo__.config_writer("global") as c:
                    c.add_value("safe", "directory", str(self.__repo_path__))
