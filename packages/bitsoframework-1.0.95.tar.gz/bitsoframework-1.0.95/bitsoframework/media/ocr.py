from bitsoframework.utils.files import is_image, is_pdf


def compute_ocr_content(media):
    """
    Extracts text from a media file via OCR (images) or text extraction (PDFs).
    Returns the extracted string, or None if the type is unsupported or extraction fails.
    """
    content_type = getattr(media, 'content_type', None)
    filename = getattr(media, 'filename', None)

    if is_pdf(content_type, filename):
        return _extract_pdf(media)

    if is_image(content_type, filename):
        return _extract_image(media)

    return None


def _open_file(media):
    file_field = media.file
    if hasattr(file_field, 'storage'):
        return file_field.storage.open(file_field.name, 'rb')
    return open(file_field.name, 'rb')


def _extract_pdf(media):
    import pdftotext
    with _open_file(media) as f:
        pdf = pdftotext.PDF(f)
        return "\n\n".join(pdf).strip() or None


def _extract_image(media):
    import pytesseract
    from PIL import Image
    with _open_file(media) as f:
        text = pytesseract.image_to_string(Image.open(f), config=r'--oem 3 --psm 6')
        return text.strip() or None
