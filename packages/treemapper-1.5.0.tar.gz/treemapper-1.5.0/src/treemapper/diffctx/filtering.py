from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path

from .config.extensions import CODE_EXTENSIONS
from .graph import Graph
from .types import DiffHunk, Fragment, FragmentId

logger = logging.getLogger(__name__)

_PROXIMITY_FLOOR_MAX = 0.04
_PROXIMITY_HALF_DECAY = 50
_DEFINITION_PROXIMITY_HALF_DECAY = 5
_HUB_REVERSE_THRESHOLD = 2
_MAX_CONTEXT_FRAGMENTS_PER_FILE = 30
_LOW_RELEVANCE_THRESHOLD = 0.015
_SIZE_PENALTY_BASE_TOKENS = 100
_SIZE_PENALTY_EXPONENT = 0.5


def _fragment_hunk_gap(frag_start: int, frag_end: int, hunk_start: int, hunk_end: int) -> int:
    if frag_end < hunk_start:
        return hunk_start - frag_end
    if frag_start > hunk_end:
        return frag_start - hunk_end
    return 0


def _proximity_score(frag: Fragment, file_hunks: list[tuple[int, int]]) -> float:
    min_gap = min(_fragment_hunk_gap(frag.start_line, frag.end_line, h_start, h_end) for h_start, h_end in file_hunks)
    half_decay = _DEFINITION_PROXIMITY_HALF_DECAY if frag.kind == "definition" else _PROXIMITY_HALF_DECAY
    return _PROXIMITY_FLOOR_MAX / (1.0 + min_gap / half_decay)


def _effective_relevance_threshold(token_count: int) -> float:
    size_factor: float = max(1.0, token_count / _SIZE_PENALTY_BASE_TOKENS) ** _SIZE_PENALTY_EXPONENT
    return _LOW_RELEVANCE_THRESHOLD * size_factor


def _apply_hunk_proximity_bonus(
    rel: dict[FragmentId, float],
    core_ids: set[FragmentId],
    fragments: list[Fragment],
    hunks: list[DiffHunk],
) -> None:
    hunks_by_path: dict[Path, list[tuple[int, int]]] = defaultdict(list)
    for h in hunks:
        h_start, h_end = h.core_selection_range
        hunks_by_path[h.path].append((h_start, h_end))

    for frag in fragments:
        if frag.id in core_ids:
            continue
        file_hunks = hunks_by_path.get(frag.path)
        if not file_hunks:
            continue
        bonus = _proximity_score(frag, file_hunks)
        if rel.get(frag.id, 0.0) < bonus:
            rel[frag.id] = bonus


def _classify_semantic_edges(
    graph: Graph,
    changed_paths: set[Path],
) -> tuple[dict[Path, set[Path]], set[Path]]:
    reverse_deps: dict[Path, set[Path]] = defaultdict(set)
    direct_edge_paths: set[Path] = set()
    for (src, dst), category in graph.edge_categories.items():
        if category != "semantic":
            continue
        src_changed = src.path in changed_paths
        dst_changed = dst.path in changed_paths
        if not (src_changed ^ dst_changed):
            continue

        changed_frag = src if src_changed else dst
        other_frag = dst if src_changed else src

        fwd_w = graph.adjacency.get(changed_frag, {}).get(other_frag, 0.0)
        rev_w = graph.adjacency.get(other_frag, {}).get(changed_frag, 0.0)

        if rev_w > fwd_w:
            reverse_deps[changed_frag.path].add(other_frag.path)
        else:
            direct_edge_paths.add(other_frag.path)
    return reverse_deps, direct_edge_paths


def _find_hub_noise_paths(
    graph: Graph,
    changed_paths: set[Path],
) -> set[Path]:
    reverse_deps, direct_edge_paths = _classify_semantic_edges(graph, changed_paths)

    changed_dirs = {p.parent for p in changed_paths}
    noise_counts: dict[Path, int] = {}
    for hub_path, deps in reverse_deps.items():
        if hub_path in changed_paths:
            continue
        if len(deps) >= _HUB_REVERSE_THRESHOLD:
            for dep in deps:
                noise_counts[dep] = noise_counts.get(dep, 0) + 1
    return {p for p, count in noise_counts.items() if count >= 1 and p not in direct_edge_paths and p.parent not in changed_dirs}


def _find_config_generic_code_files(
    graph: Graph,
    changed_paths: set[Path],
) -> set[Path]:
    has_real_edge: set[Path] = set()
    has_generic_config: set[Path] = set()
    generic_edge_count: dict[Path, int] = {}
    config_stems: set[str] = {p.stem.lower() for p in changed_paths}
    for (src, dst), category in graph.edge_categories.items():
        src_changed = src.path in changed_paths
        dst_changed = dst.path in changed_paths
        if not (src_changed ^ dst_changed):
            continue
        other_path = (dst if src_changed else src).path
        if category == "config_generic":
            has_generic_config.add(other_path)
            generic_edge_count[other_path] = generic_edge_count.get(other_path, 0) + 1
        elif category in ("semantic", "config"):
            has_real_edge.add(other_path)

    generic_only = has_generic_config - has_real_edge
    return {
        p
        for p in generic_only
        if p.suffix.lower() in CODE_EXTENSIONS and generic_edge_count.get(p, 0) <= 1 and p.stem.lower() not in config_stems
    }


def _filter_unrelated_fragments(
    fragments: list[Fragment],
    core_ids: set[FragmentId],
    graph: Graph,
) -> list[Fragment]:
    changed_paths = {fid.path for fid in core_ids}

    paths_to_remove = _find_hub_noise_paths(graph, changed_paths)
    paths_to_remove |= _find_config_generic_code_files(graph, changed_paths)
    paths_to_remove -= changed_paths

    if not paths_to_remove:
        return fragments

    kept = [f for f in fragments if f.path not in paths_to_remove]
    removed_count = len(fragments) - len(kept)
    if removed_count:
        logger.debug(
            "diffctx: filtered %d fragments from %d unrelated files",
            removed_count,
            len(paths_to_remove),
        )
    return kept


def _cap_context_fragments(
    fragments: list[Fragment],
    core_ids: set[FragmentId],
    rel: dict[FragmentId, float],
) -> list[Fragment]:
    changed_paths = {fid.path for fid in core_ids}

    ctx_by_path: dict[Path, list[Fragment]] = defaultdict(list)
    result: list[Fragment] = []

    for f in fragments:
        if f.path in changed_paths:
            result.append(f)
        else:
            ctx_by_path[f.path].append(f)

    for path, file_frags in ctx_by_path.items():
        if len(file_frags) <= _MAX_CONTEXT_FRAGMENTS_PER_FILE:
            result.extend(file_frags)
        else:
            file_frags.sort(key=lambda f: rel.get(f.id, 0.0), reverse=True)
            result.extend(file_frags[:_MAX_CONTEXT_FRAGMENTS_PER_FILE])
            logger.debug(
                "diffctx: capped %s from %d to %d fragments",
                path,
                len(file_frags),
                _MAX_CONTEXT_FRAGMENTS_PER_FILE,
            )

    return result


def _filter_low_relevance_fragments(
    fragments: list[Fragment],
    core_ids: set[FragmentId],
    rel: dict[FragmentId, float],
) -> list[Fragment]:
    kept = [f for f in fragments if f.id in core_ids or rel.get(f.id, 0.0) >= _effective_relevance_threshold(f.token_count)]
    removed = len(fragments) - len(kept)
    if removed:
        thresholds = [_effective_relevance_threshold(f.token_count) for f in fragments if f.id not in core_ids]
        actual_threshold = min(thresholds) if thresholds else _LOW_RELEVANCE_THRESHOLD
        logger.debug("diffctx: filtered %d low-relevance fragments (min_threshold=%.4f)", removed, actual_threshold)
    return kept
