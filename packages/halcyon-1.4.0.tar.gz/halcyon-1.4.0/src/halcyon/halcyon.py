import json, logging, base64
import markdown, re
import asyncio
import time

from PIL import Image
import io
import blurhash

import halcyon.restrunner
from halcyon.message import *
from halcyon.room import *
from halcyon.enums import *
from halcyon.events import (Event, MemberEvent, ReactionEvent, RedactionEvent,
                            StickerEvent, TypingEvent, ReceiptEvent,
                            PresenceEvent, AccountDataEvent)
from halcyon.user import User
from halcyon.security import configure_security

class Client:
    """
        This is the general interface that is exposed to the user
    """
    def __init__(self, loop=None, ignoreFirstSync=True, security_mode='strict'):
        # Configure security mode for this client session
        configure_security(security_mode)
        
        # Fix deprecated event loop initialization
        if loop is None:
            try:
                # Try to get running loop first
                self.loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop - will be set in run()
                self.loop = None
        else:
            self.loop = loop
        self.logoutOnDeath = False
        self.loopPollInterval = 0.1#seconds
        self.long_poll_timeout = 10#seconds, up this value to be nicer to the server.
        #Bug/Thing I don't like: The client doesn't immediately close when you ctrl^c when you have this value high.
        #This is because requests is blocking, meaning that we have to wait for a return from the sever before we can handle the SIGs

        self.restrunner = None
        self.sinceToken = str()
        self.encryptedCurveCount = 0
        self.ignoreFirstSync = ignoreFirstSync
        self.firstSync = True
        self.revokeSessionTokenOnExit = False
        self.security_mode = security_mode
        self.auth_type = None

        self.roomCache = dict()
        self._cache_lock = None  # Will be initialized in async context

    def _ensure_async_lock(self):
        """Ensure the async lock is created"""
        if self._cache_lock is None:
            self._cache_lock = asyncio.Lock()

    def _encodeTokenDict(self, tokenDict):
        """
            Return a string encoded for the halcyon Token 

            @param tokenDict Dict the dict to encode

            @return the base64 string
        """
        return str(base64.b64encode(bytes(json.dumps(tokenDict, separators=(',', ':')), "utf-8")), "utf-8")

    def _decodeTokenDict(self, token):
        """
            Returns a dict from a base64 encoded string
            
            @param token String the base64 token to decode

            @return dict
        """

        try:
            return json.loads(str(base64.b64decode(token), "utf-8"))
        except Exception as e:
            print(token)
            logging.error("Cannot decode token dict, double check your token is okay?")
            exit()

    def _generateNewSessionToken(self, userID, password):
        return self.restrunner._passwordLogin(userID, password)

    def _init(self, halcyonToken=None, userID=None, password=None, homeserver=None):
        """
            We support two forms of login, halcyontoken and ol' userid+password. token is prefered, so you don't keep making valid tokens.
            
        """

        if halcyonToken:
            splitToken = halcyonToken.split(".")
            for token in splitToken:
                decodedToken = self._decodeTokenDict(token)

                if decodedToken["typ"] == "engine":
                    homeserver = decodedToken["hsvr"]
                    userID = decodedToken["user"]

                if decodedToken["typ"] == "valid-token":
                    accessToken = decodedToken["token"]
                    deviceID = decodedToken["device_id"]

            self.restrunner = halcyon.restrunner.Runner(homeserver=homeserver, user_id=userID, access_token=accessToken, device_id=deviceID)

            resp = self.restrunner.whoami()
            if "errcode" not in resp:
                self.auth_type = "token"
                return
            else:
                logging.error("error logging in with token")

        if userID and password:
            if homeserver:
                self.restrunner = halcyon.restrunner.Runner(homeserver=homeserver, user_id=userID)
                resp = self._generateNewSessionToken(userID, password)
                if "errcode" not in resp:
                    self.auth_type = "password"
                    self.logoutOnDeath = True
                    #TODO: state.json file
                    #accepts file location, we write state info there, and load data from it
                    #if can write to disk, leave session open
                    #else kill session on client unload
                    return

        logging.error("No valid login method found. Sudoku")
        exit(1)


    def _roomcacheinit(self, cachePublicRooms=False):
        """
            Build a cache of room info that can be linked into incoming messages
        """
        self.roomCache["cache_age"] = time.time_ns()#nanoseconds since epoch
        self.roomCache["rooms"] = dict()

        joined_rooms = self.restrunner.joinedRooms()
        for roomID in joined_rooms:
            self.roomCache["rooms"][roomID] = room(rawEvents=self.restrunner.getRoomState(roomID), roomID=roomID)

    async def _roomcacheinit_async(self, cachePublicRooms=False):
        """
            Build a cache of room info that can be linked into incoming messages - Async version
        """
        self._ensure_async_lock()
        async with self._cache_lock:
            self.roomCache["cache_age"] = time.time_ns()#nanoseconds since epoch
            self.roomCache["rooms"] = dict()

            joined_rooms = self.restrunner.joinedRooms()
            for roomID in joined_rooms:
                self.roomCache["rooms"][roomID] = room(rawEvents=self.restrunner.getRoomState(roomID), roomID=roomID)

    def _refreshRoomCache(self):
        """
            Used to refresh the room caches existing rooms
        """
        for roomID in self.roomCache["rooms"]:
            self._addRoomToCache(roomID)

    def _addRoomToCache(self, roomID):
        """
            Add a room to the room cache, can be used to refresh an old room cache
        """
        self.roomCache["rooms"][roomID] = room(rawEvents=self.restrunner.getRoomState(roomID), roomID=roomID)

    async def _addRoomToCache_async(self, roomID):
        """
            Add a room to the room cache, can be used to refresh an old room cache - Async version
        """
        self._ensure_async_lock()
        async with self._cache_lock:
            self.roomCache["rooms"][roomID] = room(rawEvents=self.restrunner.getRoomState(roomID), roomID=roomID)


    def _getRoom(self, roomID):
        """
            retrieve a room from the roomcache, caching if it is not already in the cache
            @param roomID String the room ID
        """
        if roomID in self.roomCache["rooms"]:
            return self.roomCache["rooms"][roomID]
        else:
            self._addRoomToCache(roomID)

            if roomID in self.roomCache["rooms"]:
                return self.roomCache["rooms"][roomID]
            else:
                return room()

    def _resolve_sender(self, sender_id, room_id):
        """Build a User from room cache member data, if available."""
        if not sender_id or not room_id:
            return None
        cached = self._ensure_cached_room(room_id)
        if sender_id in cached.member_details:
            member = cached.member_details[sender_id]
            return User(
                id=sender_id,
                displayname=member.displayname,
                avatar_url=member.avatar_url,
                membership=member.membership,
            )
        return User(id=sender_id)

    def _ensure_cached_room(self, room_id):
        """Return a cache entry for the room, creating a placeholder if needed."""
        if "rooms" not in self.roomCache:
            self.roomCache["rooms"] = {}

        if room_id not in self.roomCache["rooms"]:
            self._addRoomToCache(room_id)

        cached_room = self.roomCache["rooms"].get(room_id)
        if cached_room is None:
            cached_room = room(roomID=room_id)
            self.roomCache["rooms"][room_id] = cached_room
        elif cached_room.id is None:
            cached_room.id = room_id

        return cached_room

    def _destruction(self):
        if self.logoutOnDeath:
            logging.info("Logging out user")
            logging(str(self._logoutUser()))
        
        logging.info("Stopping main event loop")
        self.loop.stop()

    async def _async_destruction(self):
        """Async version of cleanup with proper resource management"""
        if self.logoutOnDeath:
            logging.info("Logging out user")
            logging.info(str(self._logoutUser()))
        
        # Close aiohttp session
        if self.restrunner:
            await self.restrunner._close_session()
        
        logging.info("Stopping main event loop")
        self.loop.stop()

    def _logoutUser(self, revokeAllTokens=False):
        """
            Revoke the specified access token, or all
            
            @param revokeAllTokens Bool Revoke every valid session token, on all devices.
        """

        return self.restrunner.revokeAccessToken(revokeAllTokens)


    async def _homeserverSync(self):
        resp = await self.restrunner.sync_async(since=self.sinceToken, timeout=self.long_poll_timeout)
        if "next_batch" not in resp:
            return

        self.sinceToken = resp["next_batch"]

        if "device_one_time_keys_count" in resp:
            if "signed_curve25519" in resp["device_one_time_keys_count"]:
                self.encryptedCurveCount = resp["device_one_time_keys_count"]["signed_curve25519"]

        if self.ignoreFirstSync and self.firstSync:
            self.firstSync = False
            return

        if "presence" in resp:
            await self._process_presence_events(resp["presence"])

        if "to_device" in resp:
            await self._process_to_device_events(resp["to_device"])

        if "account_data" in resp:
            await self._process_global_account_data(resp["account_data"])

        if "rooms" in resp:
            rooms = resp["rooms"]
            if "join" in rooms:
                await self._process_joined_rooms(rooms["join"])
            if "invite" in rooms:
                await self._process_invited_rooms(rooms["invite"])
            if "knock" in rooms:
                await self._process_knocked_rooms(rooms["knock"])
            if "leave" in rooms:
                await self._process_left_rooms(rooms["leave"])

    async def _process_joined_rooms(self, joined_rooms):
        for room_id, room_data in joined_rooms.items():
            if "state" in room_data:
                for event in room_data["state"].get("events", []):
                    await self._process_state_event(event, room_id)

            if "timeline" in room_data:
                for event in room_data["timeline"].get("events", []):
                    await self._process_timeline_event(event, room_id)

            if "ephemeral" in room_data:
                for event in room_data["ephemeral"].get("events", []):
                    await self._process_ephemeral_event(event, room_id)

            if "account_data" in room_data:
                for event in room_data["account_data"].get("events", []):
                    await self._process_room_account_data_event(event, room_id)

    async def _process_invited_rooms(self, invited_rooms):
        for room_id, room_data in invited_rooms.items():
            events = []
            if "invite_state" in room_data:
                events = room_data["invite_state"].get("events", [])
            if events:
                newRoom = room(rawEvents=events, roomID=room_id)
                await self.on_room_invite(newRoom)
                for event in events:
                    await self.on_event(Event(event, room_id=room_id, source="invite_state"))

    async def _process_knocked_rooms(self, knocked_rooms):
        for room_id, room_data in knocked_rooms.items():
            events = []
            if "knock_state" in room_data:
                events = room_data["knock_state"].get("events", [])
            for event in events:
                await self.on_event(Event(event, room_id=room_id, source="knock_state"))

    async def _process_left_rooms(self, left_rooms):
        for room_id, room_data in left_rooms.items():
            for event in room_data.get("state", {}).get("events", []):
                await self.on_event(Event(event, room_id=room_id, source="leave_state"))
            for event in room_data.get("timeline", {}).get("events", []):
                await self.on_event(Event(event, room_id=room_id, source="leave_timeline"))
            for event in room_data.get("account_data", {}).get("events", []):
                await self.on_event(AccountDataEvent(event, room_id=room_id, source="leave_account_data"))
            await self.on_room_leave(room_id)

    def _enrich_event(self, ev, room_id):
        """Attach sender_user to an event from room cache member data."""
        if ev.sender and room_id:
            ev.sender_user = self._resolve_sender(ev.sender, room_id)
        return ev

    async def _process_timeline_event(self, event, room_id):
        event_type = event.get("type")
        cached_room = self._ensure_cached_room(room_id)

        # Timeline events with state_key are state changes; apply to cache
        if "state_key" in event:
            cached_room.apply_state_event(event)

        if event_type == "m.room.message":
            newMsg = message(event, cached_room)
            if newMsg.edit:
                await self.on_message_edit(newMsg)
            else:
                await self.on_message(newMsg)
        elif event_type == "m.sticker":
            await self.on_message(message(event, cached_room))
            await self.on_event(self._enrich_event(StickerEvent(event, room_id=room_id, source="timeline"), room_id))
            return
        elif event_type == "m.reaction":
            ev = self._enrich_event(ReactionEvent(event, room_id=room_id, source="timeline"), room_id)
            await self.on_reaction(ev)
        elif event_type == "m.room.redaction":
            ev = self._enrich_event(RedactionEvent(event, room_id=room_id, source="timeline"), room_id)
            await self.on_redaction(ev)
        elif event_type == "m.room.member":
            ev = self._enrich_event(MemberEvent(event, room_id=room_id, source="timeline"), room_id)
            await self.on_room_member(ev)

        await self.on_event(self._enrich_event(Event(event, room_id=room_id, source="timeline"), room_id))

    async def _process_state_event(self, event, room_id):
        cached_room = self._ensure_cached_room(room_id)
        cached_room.apply_state_event(event)

        if event.get("type") == "m.room.member":
            ev = self._enrich_event(MemberEvent(event, room_id=room_id, source="state"), room_id)
            await self.on_room_member(ev)

        await self.on_event(self._enrich_event(Event(event, room_id=room_id, source="state"), room_id))

    async def _process_ephemeral_event(self, event, room_id):
        event_type = event.get("type")
        if event_type == "m.typing":
            await self.on_event(TypingEvent(event, room_id=room_id))
        elif event_type == "m.receipt":
            await self.on_event(ReceiptEvent(event, room_id=room_id))
        else:
            await self.on_event(Event(event, room_id=room_id, source="ephemeral"))

    async def _process_room_account_data_event(self, event, room_id):
        await self.on_event(AccountDataEvent(event, room_id=room_id, source="account_data"))

    async def _process_presence_events(self, presence_data):
        for event in presence_data.get("events", []):
            if event.get("type") == "m.presence":
                await self.on_event(PresenceEvent(event))
            else:
                await self.on_event(Event(event, source="presence"))

    async def _process_to_device_events(self, to_device_data):
        for event in to_device_data.get("events", []):
            await self.on_event(Event(event, source="to_device"))

    async def _process_global_account_data(self, account_data):
        for event in account_data.get("events", []):
            await self.on_event(AccountDataEvent(event, source="account_data"))

    async def send_message(self, roomID, body, textFormat=None, replyTo=None, isNotice=False):
        """
            Send a message to a specified room.

            @param roomID String the room to send the message to
            @param body String the text body to send. defaults to plain text
            @param textFormat String OPTIONAL If the string is formatted. Must be "markdown" or "html"
            @param replyTo String OPTIONAL The ID to the event you want to reply to
            @param isNotice bool OPTIONAL Send the message as a notice. slightly grey on desktop.

            @return dict contains 'event_id' of new message
        """
        """
            Supported HTML tags:
            font, del, h1, h2, h3, h4, h5, h6, blockquote, p, a, ul, ol, sup, sub, 
            li, b, i, u, strong, em, strike, code, hr, br, div, table, thead, tbody, 
            tr, th, td, caption, pre, span, img.
        """

        """
        content
            "msgtype": "io.element.effects.space_invaders",
        """
        messageType = "m.text"
        if isNotice:
            messageType = "m.notice"


        if textFormat:
            if textFormat == "markdown":
                formattedBody = markdown.markdown(body)
                body = re.sub('<[^<]+?>', '', formattedBody)

            if textFormat == "html":
                formattedBody = body
                body = re.sub('<[^<]+?>', '', body)

            messageContent = {
                "msgtype": messageType,
                "body": body,
                "format": "org.matrix.custom.html",
                "formatted_body" : formattedBody,
            }
        else:
            messageContent = {
                "msgtype": messageType,
                "body": body
            }


        if replyTo:
            messageContent["m.relates_to"] = {
                "m.in_reply_to": {
                    "event_id": replyTo
                }
            }

        return(await self.restrunner.sendEvent_async(roomID=roomID, eventType="m.room.message", eventPayload=messageContent))
    

    async def send_typing(self, roomID, seconds=None):
        """
            Send a typing event to a room. Useful when doing a lot of work in the background

            @param roomID String the room id that you want to type in
            @param seconds int OPTIONAL How many seconds you want to type for. Default 10
        """
        self.restrunner.sendTyping(roomID, seconds)


    async def _send_file(self, roomID, body, fileURL, messageType=None, info=None, fileName=None):
        """
            Send a file to a room
            @param roomID str Room to send to
            @param body String A description of the file, normally the filename,
            @param fileURL the MXC for the file message
            @param messageType msgType The type of message to send. Use the enums. Defaults to FILE
            @param info Dict OPTIONAL info on the file to send. File specific https://spec.matrix.org/latest/client-server-api/#mimage
            @param fileName String OPTIONAL the file name of the file to send
        """
        """
            Placeholder for the file form of the send_message command
            m.image
            m.audio
            m.file
            m.video
        """

        if not messageType:
            messageType = msgType.FILE

        messageContent = {
            "msgtype": messageType,
            "body": body,
            "url": fileURL
        }

        if info:
            messageContent["info"] = info

        if fileName:
            messageContent["filename"] = fileName

        return(await self.restrunner.sendEvent_async(roomID=roomID, eventType="m.room.message", eventPayload=messageContent))


    async def send_image(self, roomID, fileBuffer, fileName, generate_blurhash=True, generate_thumbnail=True):
        """
            Send an image file to a room
            @param roomID String the room to send to
            @param file BytesIO The file in bytes format
            @param fileName String the file name of the file
            @param generate_blurhash Bool Generate a Blurhash for the image. This is a blur used as filler while the image loads
            @param generate_thumbnail Bool Set to true to automatically downsize images over 640x640
        """
        fileBuffer = io.BytesIO(fileBuffer)

        resp = await self.upload_media(fileBuffer, fileName)
        loadedImage = Image.open(fileBuffer)

        if "content_uri" not in resp:
            logging.warning("error uploading file: " + str(resp))

        info = {
            "mimetype" : Image.MIME[loadedImage.format],
            "w": loadedImage.width,
            "h": loadedImage.height,
            "size": fileBuffer.getbuffer().nbytes
        }

        if generate_blurhash:
            info["xyz.amorgan.blurhash"] = blurhash.encode(fileBuffer, x_components=4, y_components=3)

        if generate_thumbnail:
            if loadedImage.height > 640 or loadedImage.width > 640:
                loadedImage.thumbnail((640,640))
                thumbnailBuffer = io.BytesIO()
                loadedImage.save(thumbnailBuffer, format='JPEG')

                thumbnailresp = await self.upload_media(thumbnailBuffer, fileName.split(".")[0] + "_thumbnail.jpeg")

                info["thumbnail_url"] = thumbnailresp["content_uri"]
                info["thumbnail_info"] = {
                    "w": loadedImage.size[0],
                    "h": loadedImage.size[1],
                    "mimetype": "image/jpeg",
                    "size": thumbnailBuffer.getbuffer().nbytes
                }

        loadedImage.close()#not sure if this is required, but might as well be safe
        return(await self._send_file(roomID=roomID, body=fileName, fileURL=resp["content_uri"], messageType=msgType.IMAGE, info=info, fileName=fileName))


    async def join_room(self, roomID):
        resp = self.restrunner.joinRoom(roomID)
        self._addRoomToCache(roomID)#update the cache, since we might be able to see more room info
        return resp


    async def change_presence(self, presence=None, statusMessage=None):
        """
            Set the bot presence and status message

            @param presence enum/string OPTIONAL The presence of the bot user
            @param statusMessage String the string to set the current users status to
        """

        #validation for presence value?
        #halcyon.Status.idle

        resp = self.restrunner.setUserPresence(presence=presence, statusMessage=statusMessage)
        # {'errcode': 'M_NOT_JSON', 'error': 'Content not JSON.'}
        if 'errcode' in resp:
            logging.error("Change presence error: " + resp["error"])
    

    async def download_media(self, mxc):
        """
            Returns a BytesIO file fetched from an MXC

            @param String MXC url

            @return BytesIO bufffer
        """
        return(await self.restrunner.getMediaFromMXC_async(mxc))

    async def upload_media(self, fileBuffer, fileName):
        """
            Upload a file

            @param file BytesIO object
            @param fileName filename for the object

            @return the MXC url
        """
        return(await self.restrunner.uploadMedia_async(fileData=fileBuffer, fileName=fileName))

    async def get_user_presence(self, userID=None):
        """
        Get a user's current presence/status information.

        @param userID String OPTIONAL full Matrix user ID. Defaults to the logged in bot user.
        @return PresenceEvent or error dict
        """
        resp = self.restrunner.getUserPresence(userID=userID)
        if isinstance(resp, dict) and "errcode" in resp:
            return resp
        raw = {
            "type": "m.presence",
            "sender": userID or self.restrunner.USER_ID,
            "content": resp,
        }
        return PresenceEvent(raw)

    async def get_user_profile(self, userID):
        """
        Get a user's profile information.

        @param userID String full Matrix user ID
        @return User or error dict
        """
        resp = self.restrunner.getUserProfile(userID)
        if isinstance(resp, dict) and "errcode" in resp:
            return resp
        return User(
            id=userID,
            displayname=resp.get("displayname"),
            avatar_url=resp.get("avatar_url"),
        )

    def get_bot_info(self):
        """
            Get comprehensive bot information

            @return Dict containing user_id, device_id, auth_type, and homeserver
        """
        if not self.restrunner:
            return {"user_id": None, "device_id": None, "auth_type": None, "homeserver": None}
        return {
            "user_id": self.restrunner.USER_ID,
            "device_id": self.restrunner.DEVICE_ID,
            "auth_type": self.auth_type,
            "homeserver": self.restrunner.HOMESERVER,
        }

    def event(self, coro):
        # Validation we don't need to worry about
        setattr(self, coro.__name__, coro)
        return coro

    async def __aenter__(self):
        """Async context manager entry"""
        self._ensure_async_lock()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - cleanup resources"""
        await self._async_destruction()

    async def on_ready(self):
        """on ready stub"""
        pass

    async def on_message(self, message):
        """on message stub"""
        pass

    async def on_message_edit(self, message):
        """on message edit stub"""
        pass

    async def on_room_invite(self, room):
        """on room invite stub. passed room object"""
        pass

    async def on_room_leave(self, roomID):
        """on room leave passes room id"""
        pass

    async def on_reaction(self, event):
        """Fired for m.reaction events. Receives a ReactionEvent."""
        pass

    async def on_redaction(self, event):
        """Fired for m.room.redaction events. Receives a RedactionEvent."""
        pass

    async def on_room_member(self, event):
        """Fired for m.room.member state changes. Receives a MemberEvent."""
        pass

    async def on_event(self, event):
        """Generic event hook. Receives an Event for every sync event."""
        pass

    async def _halcyonMainLoop(self):
        await self.on_ready()
        while True:
            await self._homeserverSync()

            #update room cache every hour
            if (time.time_ns() > (self.roomCache["cache_age"] + 3600000000000)):
                logging.debug("Updating room cache")
                self._ensure_async_lock()
                async with self._cache_lock:
                    self.roomCache["cache_age"] = time.time_ns()
                    self._refreshRoomCache()

            await asyncio.sleep(self.loopPollInterval)

    def run(self, halcyonToken=None, userID=None, password=None, homeserver=None, loopPollInterval=None, longPollTimeout=None):
        
        if loopPollInterval:
            print("loopPollInterval has been deprecated because of superior polling update, please set var 'longPollTimeout' instead.")
            logging.warning("loopPollInterval has been deprecated because of better polling, please set var 'longPollTimeout' instead.")

        if longPollTimeout:
            logging.info("Custom poll value set")
            self.long_poll_timeout = longPollTimeout

        #login
        self._init(halcyonToken, userID, password, homeserver)
        self._roomcacheinit()
        
        # Set up event loop properly
        if self.loop is None:
            try:
                self.loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop, create a new one
                self.loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.loop)
        
        loop = self.loop
        try:
            loop.add_signal_handler(2, lambda: asyncio.create_task(self._async_destruction()))#SIGINT
            loop.add_signal_handler(15, lambda: asyncio.create_task(self._async_destruction()))#SIGTERM
        except NotImplementedError:
            pass

        try:
            loop.create_task(self._halcyonMainLoop())
            loop.run_forever()
        except KeyboardInterrupt:
            logging.info('Keyboard says death')
        finally:
            loop.run_until_complete(self._async_destruction())
