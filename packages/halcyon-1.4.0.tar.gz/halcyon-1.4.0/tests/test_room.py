import pytest
from halcyon.room import room


class TestRoom:
    """Test the main room class"""
    
    def test_room_creation_empty(self):
        """Test creating an empty room"""
        test_room = room()
        assert bool(test_room) is False
        assert test_room._hasData is False
        assert test_room.id is None
        
    def test_room_creation_with_id(self):
        """Test creating room with just ID"""
        test_room = room(roomID="!test:matrix.org")
        assert test_room.id == "!test:matrix.org"
        assert bool(test_room) is False  # No events processed yet
        
    def test_room_creation_with_events(self, sample_room_create_events):
        """Test room creation with full event list"""
        test_room = room(sample_room_create_events, "!test:matrix.org")
        
        assert bool(test_room) is True
        assert test_room.id == "!test:matrix.org"
        assert test_room.creator == "@creator:matrix.org"
        assert test_room.version == "6"
        assert test_room.federated is True
        assert test_room.name == "Test Room"
        assert test_room.topic == "A test room for unit tests"
        assert test_room.joinRule == "invite"
        
    def test_room_predecessor(self, sample_room_create_events):
        """Test room predecessor parsing"""
        test_room = room(sample_room_create_events, "!test:matrix.org")
        
        assert test_room.predecessor is not None
        assert bool(test_room.predecessor) is True
        assert test_room.predecessor.room.id == "!oldroom:example.org"
        assert test_room.predecessor.event.id == "$something:example.org"
        
    def test_room_members(self, sample_room_create_events):
        """Test member list parsing"""
        test_room = room(sample_room_create_events, "!test:matrix.org")
        
        # Should have one joined member
        assert len(test_room.members) == 1
        assert "@user1:matrix.org" in test_room.members
        
        # Should have one invited member
        assert len(test_room.invited) == 1
        assert "@invited:matrix.org" in test_room.invited
        
        # No left members in our sample
        assert len(test_room.left) == 0
        
    def test_room_permissions(self, sample_room_create_events):
        """Test power levels parsing"""
        test_room = room(sample_room_create_events, "!test:matrix.org")
        
        assert test_room.permissions is not None
        assert bool(test_room.permissions) is True
        
        # Check admin/mod detection
        assert "@creator:matrix.org" in test_room.permissions.administrators
        assert "@moderator:matrix.org" in test_room.permissions.moderators
        
        # Check defaults
        assert test_room.permissions.user_value == 0
        assert test_room.permissions.events_value == 0
        assert test_room.permissions.state_value == 50
        
        # Check action levels
        assert test_room.permissions.invite_value == 50
        assert test_room.permissions.redact_value == 50
        
    def test_room_encryption(self, sample_room_create_events):
        """Test encryption settings parsing"""
        test_room = room(sample_room_create_events, "!test:matrix.org")
        
        assert test_room.encryption is not None
        assert bool(test_room.encryption) is True
        assert test_room.encryption.algorithm == "m.megolm.v1.aes-sha2"
        assert test_room.encryption.rotation_period_ms == 604800000
        assert test_room.encryption.rotation_period_msgs == 100
        
    def test_room_server_acl(self, sample_room_with_acl):
        """Test server ACL parsing"""
        test_room = room(sample_room_with_acl, "!acl:matrix.org")
        
        assert test_room.acl is not None
        assert bool(test_room.acl) is True
        assert test_room.acl.allow_ip_literals is False
        assert "matrix.org" in test_room.acl.allow
        assert "*.matrix.org" in test_room.acl.allow
        assert "bad.server.com" in test_room.acl.deny


class TestRoomPredecessor:
    """Test the roomPredecessor nested class"""
    
    def test_predecessor_with_data(self):
        """Test predecessor with valid data"""
        predecessor_data = {
            "event_id": "$event:server.org",
            "room_id": "!room:server.org"
        }
        
        predecessor = room.roomPredecessor(predecessor_data)
        assert bool(predecessor) is True
        assert predecessor.event.id == "$event:server.org"
        assert predecessor.room.id == "!room:server.org"
        
    def test_predecessor_empty(self):
        """Test predecessor with no data"""
        predecessor = room.roomPredecessor(None)
        assert bool(predecessor) is False
        assert predecessor.event is None
        assert predecessor.room is None
        
    def test_predecessor_partial_data(self):
        """Test predecessor with missing fields"""
        predecessor_data = {"event_id": "$event:server.org"}
        
        predecessor = room.roomPredecessor(predecessor_data)
        assert bool(predecessor) is True
        assert predecessor.event.id == "$event:server.org"
        assert predecessor.room.id is None


class TestRoomPermissions:
    """Test the roomPermissions nested class"""
    
    def test_permissions_basic(self):
        """Test basic permission parsing"""
        perms_data = {
            "users": {
                "@admin:matrix.org": 100,
                "@mod:matrix.org": 50,
                "@user:matrix.org": 0
            },
            "users_default": 0,
            "events_default": 0,
            "state_default": 50,
            "invite": 50,
            "redact": 50,
            "ban": 50,
            "kick": 50
        }
        
        perms = room.roomPermissions(perms_data)
        assert bool(perms) is True
        
        # Check synthetic fields
        assert len(perms.administrators) == 1
        assert "@admin:matrix.org" in perms.administrators
        assert len(perms.moderators) == 1
        assert "@mod:matrix.org" in perms.moderators
        
        # Check all users
        assert len(perms.users) == 3
        assert perms.users["@user:matrix.org"] == 0
        
    def test_permissions_with_events(self):
        """Test permissions with event-specific power levels"""
        perms_data = {
            "users": {"@admin:matrix.org": 100},
            "events": {
                "m.room.name": 50,
                "m.room.topic": 75,
                "m.room.power_levels": 100
            }
        }
        
        perms = room.roomPermissions(perms_data)
        assert perms.m_event_values is not None
        assert perms.m_event_values["m.room.name"] == 50
        assert perms.m_event_values["m.room.topic"] == 75
        
    def test_permissions_empty(self):
        """Test empty permissions"""
        perms = room.roomPermissions(None)
        assert bool(perms) is False


class TestRoomServerAcl:
    """Test the room_server_acl nested class"""
    
    def test_acl_full(self):
        """Test full ACL configuration"""
        acl_data = {
            "allow_ip_literals": False,
            "allow": ["good.server.com", "*.trusted.org"],
            "deny": ["bad.server.com", "*.evil.org"]
        }
        
        acl = room.room_server_acl(acl_data)
        assert bool(acl) is True
        assert acl.allow_ip_literals is False
        assert len(acl.allow) == 2
        assert "good.server.com" in acl.allow
        assert len(acl.deny) == 2
        assert "bad.server.com" in acl.deny
        
    def test_acl_minimal(self):
        """Test ACL with minimal data"""
        acl_data = {"allow_ip_literals": True}
        
        acl = room.room_server_acl(acl_data)
        assert bool(acl) is True
        assert acl.allow_ip_literals is True
        assert acl.allow == []  # Default empty list
        assert acl.deny == []   # Default empty list
        
    def test_acl_empty(self):
        """Test empty ACL"""
        acl = room.room_server_acl(None)
        assert bool(acl) is False


class TestRoomEncryption:
    """Test the room_encryption nested class"""
    
    def test_encryption_full(self):
        """Test full encryption configuration"""
        encryption_data = {
            "algorithm": "m.megolm.v1.aes-sha2",
            "rotation_period_ms": 604800000,
            "rotation_period_msgs": 100
        }
        
        encryption = room.room_encryption(encryption_data)
        assert bool(encryption) is True
        assert encryption.algorithm == "m.megolm.v1.aes-sha2"
        assert encryption.rotation_period_ms == 604800000
        assert encryption.rotation_period_msgs == 100
        
    def test_encryption_minimal(self):
        """Test encryption with just algorithm"""
        encryption_data = {"algorithm": "m.megolm.v1.aes-sha2"}
        
        encryption = room.room_encryption(encryption_data)
        assert bool(encryption) is True
        assert encryption.algorithm == "m.megolm.v1.aes-sha2"
        assert encryption.rotation_period_ms is None
        assert encryption.rotation_period_msgs is None
        
    def test_encryption_empty(self):
        """Test empty encryption"""
        encryption = room.room_encryption(None)
        assert bool(encryption) is False


class TestRoomAvatar:
    """Test the room_avatar nested class"""
    
    def test_avatar_with_url(self):
        """Test avatar with MXC URL"""
        avatar_data = {"url": "mxc://matrix.org/avatar123"}
        
        avatar = room.room_avatar(avatar_data)
        assert bool(avatar) is True
        assert avatar.url == "mxc://matrix.org/avatar123"
        
    def test_avatar_empty(self):
        """Test empty avatar"""
        avatar = room.room_avatar(None)
        assert bool(avatar) is False
        assert avatar.url is None


class TestRoomAlias:
    """Test the room_alias nested class"""
    
    def test_alias_with_canonical_and_alt(self):
        """Test alias with canonical and alternatives"""
        alias_data = {
            "alias": "#main:matrix.org",
            "alt_aliases": ["#alt1:matrix.org", "#alt2:matrix.org"]
        }
        
        alias = room.room_alias(alias_data)
        assert bool(alias) is True
        assert alias.canonical == "#main:matrix.org"
        assert len(alias.alt) == 2
        assert "#alt1:matrix.org" in alias.alt
        assert "#alt2:matrix.org" in alias.alt
        
    def test_alias_canonical_only(self):
        """Test alias with only canonical"""
        alias_data = {"alias": "#room:matrix.org"}
        
        alias = room.room_alias(alias_data)
        assert bool(alias) is True
        assert alias.canonical == "#room:matrix.org"
        assert len(alias.alt) == 0
        
    def test_alias_alt_only(self):
        """Test alias with only alternatives"""
        alias_data = {"alt_aliases": ["#alt:matrix.org"]}
        
        alias = room.room_alias(alias_data)
        assert bool(alias) is True
        assert alias.canonical is None
        assert len(alias.alt) == 1
        assert "#alt:matrix.org" in alias.alt
        
    def test_alias_empty(self):
        """Test empty alias"""
        alias = room.room_alias(None)
        assert bool(alias) is False
        assert alias.canonical is None
        assert len(alias.alt) == 0


class TestRoomDefaults:
    """Test default values according to Matrix spec"""
    
    def test_room_version_default(self):
        """Test room version defaults to string 1"""
        events = [{
            "type": "m.room.create",
            "content": {"creator": "@user:matrix.org"}  # No room_version
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.version == "1"  # Default per spec

    def test_room_creator_falls_back_to_sender(self):
        """Modern room create events may omit content.creator"""
        events = [{
            "type": "m.room.create",
            "sender": "@user:matrix.org",
            "content": {"room_version": "12"}
        }]

        test_room = room(events, "!test:matrix.org")
        assert test_room.creator == "@user:matrix.org"
        
    def test_federate_default(self):
        """Test m.federate defaults to True"""
        events = [{
            "type": "m.room.create",
            "content": {"creator": "@user:matrix.org"}  # No m.federate
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.federated is True  # Default per spec
        
    def test_guest_access_default(self):
        """Test guest access defaults to False"""
        test_room = room([], "!test:matrix.org")
        assert test_room.guestAccess is False  # Default
        
    def test_guest_access_can_join(self):
        """Test guest access with can_join"""
        events = [{
            "type": "m.room.guest_access",
            "content": {"guest_access": "can_join"}
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.guestAccess is True
        
    def test_guest_access_forbidden(self):
        """Test guest access with forbidden"""
        events = [{
            "type": "m.room.guest_access",
            "content": {"guest_access": "forbidden"}
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.guestAccess is False


class TestRoomMemberHandling:
    """Test room member event handling edge cases"""
    
    def test_member_join_with_user_id(self):
        """Test member join event with user_id field"""
        events = [{
            "type": "m.room.member",
            "content": {"membership": "join"},
            "user_id": "@user:matrix.org",
            "state_key": "@user:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@user:matrix.org" in test_room.members
        
    def test_member_join_without_user_id(self):
        """Test member join event without user_id field (invited rooms)"""
        events = [{
            "type": "m.room.member",
            "content": {"membership": "join"},
            "state_key": "@user:matrix.org"
            # No user_id field
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@user:matrix.org" in test_room.members
        
    def test_member_leave(self):
        """Test member leave event"""
        events = [{
            "type": "m.room.member",
            "content": {"membership": "leave"},
            "user_id": "@user:matrix.org",
            "state_key": "@user:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@user:matrix.org" in test_room.left
        
    def test_member_invite(self):
        """Test member invite event"""
        events = [{
            "type": "m.room.member",
            "content": {"membership": "invite"},
            "state_key": "@invited:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@invited:matrix.org" in test_room.invited


class TestNewRoomFields:
    """Test new room fields from Matrix spec compliance"""
    
    def test_room_create_with_type(self):
        """Test room creation with room type (spaces, etc.)"""
        events = [{
            "type": "m.room.create",
            "content": {
                "creator": "@creator:matrix.org",
                "room_version": "9",
                "type": "m.space"
            }
        }]
        
        test_room = room(events, "!space:matrix.org")
        assert test_room.creator == "@creator:matrix.org"
        assert test_room.version == "9"
        assert test_room.room_type == "m.space"
    
    def test_room_create_with_additional_creators(self):
        """Test room creation with additional creators (Matrix v1.16+)"""
        events = [{
            "type": "m.room.create",
            "content": {
                "creator": "@creator:matrix.org",
                "additional_creators": ["@co-creator1:matrix.org", "@co-creator2:matrix.org"]
            }
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.creator == "@creator:matrix.org"
        assert test_room.additional_creators == ["@co-creator1:matrix.org", "@co-creator2:matrix.org"]
    
    def test_join_rules_with_allow_conditions(self):
        """Test join rules with allow conditions for restricted rooms"""
        events = [{
            "type": "m.room.join_rules", 
            "content": {
                "join_rule": "restricted",
                "allow": [
                    {
                        "type": "m.room_membership",
                        "room_id": "!parent:matrix.org"
                    }
                ]
            }
        }]
        
        test_room = room(events, "!restricted:matrix.org")
        assert test_room.joinRule == "restricted"
        assert test_room.join_rule_allow is not None
        assert len(test_room.join_rule_allow) == 1
        assert test_room.join_rule_allow[0]["type"] == "m.room_membership"
        assert test_room.join_rule_allow[0]["room_id"] == "!parent:matrix.org"
    
    def test_topic_with_content_object(self):
        """Test topic with m.topic content object for MIME types"""
        events = [{
            "type": "m.room.topic",
            "content": {
                "topic": "Welcome to the room",
                "m.topic": {
                    "m.text": {
                        "body": "Welcome to the **room**",
                        "format": "org.matrix.custom.html",
                        "formatted_body": "Welcome to the <strong>room</strong>"
                    }
                }
            }
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.topic == "Welcome to the room"
        assert test_room.topic_content is not None
        assert "m.text" in test_room.topic_content
        assert test_room.topic_content["m.text"]["body"] == "Welcome to the **room**"
    
    def test_avatar_with_info_metadata(self):
        """Test avatar with detailed info metadata"""
        events = [{
            "type": "m.room.avatar",
            "content": {
                "url": "mxc://matrix.org/avatar123",
                "info": {
                    "h": 256,
                    "w": 256,
                    "mimetype": "image/png",
                    "size": 12345,
                    "thumbnail_url": "mxc://matrix.org/thumb123",
                    "thumbnail_info": {
                        "h": 64,
                        "w": 64,
                        "mimetype": "image/jpeg",
                        "size": 2048
                    }
                }
            }
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.avatar.url == "mxc://matrix.org/avatar123"
        assert test_room.avatar.info_height == 256
        assert test_room.avatar.info_width == 256
        assert test_room.avatar.info_mimetype == "image/png"
        assert test_room.avatar.info_size == 12345
        assert test_room.avatar.info_thumbnail_url == "mxc://matrix.org/thumb123"
        assert test_room.avatar.info_thumbnail_info["h"] == 64
    
    def test_power_levels_with_notifications(self):
        """Test power levels with notifications object"""
        events = [{
            "type": "m.room.power_levels",
            "content": {
                "users": {
                    "@admin:matrix.org": 100,
                    "@mod:matrix.org": 50
                },
                "users_default": 0,
                "events_default": 0,
                "state_default": 50,
                "notifications": {
                    "room": 50
                }
            }
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert test_room.permissions.notifications is not None
        assert test_room.permissions.notifications["room"] == 50
    
    def test_member_with_profile_info(self):
        """Test member with detailed profile information"""
        events = [{
            "type": "m.room.member",
            "content": {
                "membership": "join",
                "avatar_url": "mxc://matrix.org/user123",
                "displayname": "Alice Smith",
                "is_direct": False,
                "reason": "Joined via invite"
            },
            "state_key": "@alice:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@alice:matrix.org" in test_room.members
        assert "@alice:matrix.org" in test_room.member_details
        
        member = test_room.member_details["@alice:matrix.org"]
        assert member.user_id == "@alice:matrix.org"
        assert member.membership == "join"
        assert member.avatar_url == "mxc://matrix.org/user123"
        assert member.displayname == "Alice Smith"
        assert member.is_direct is False
        assert member.reason == "Joined via invite"
    
    def test_member_with_restricted_room_auth(self):
        """Test member with restricted room authorization"""
        events = [{
            "type": "m.room.member",
            "content": {
                "membership": "join",
                "displayname": "Bob",
                "join_authorised_via_users_server": "@parent-admin:matrix.org"
            },
            "state_key": "@bob:matrix.org"
        }]
        
        test_room = room(events, "!restricted:matrix.org")
        member = test_room.member_details["@bob:matrix.org"]
        assert member.join_authorised_via_users_server == "@parent-admin:matrix.org"
    
    def test_member_with_third_party_invite(self):
        """Test member with third party invite details"""
        events = [{
            "type": "m.room.member",
            "content": {
                "membership": "join",
                "third_party_invite": {
                    "display_name": "alice@example.com",
                    "signed": {
                        "signatures": {},
                        "token": "sometoken"
                    }
                }
            },
            "state_key": "@alice:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        member = test_room.member_details["@alice:matrix.org"]
        assert member.third_party_invite is not None
        assert member.third_party_invite["display_name"] == "alice@example.com"


class TestBackwardCompatibilityNewFields:
    """Test that new fields don't break existing functionality"""
    
    def test_room_without_new_fields_still_works(self):
        """Test room creation without new fields works as before"""
        events = [{
            "type": "m.room.create",
            "content": {
                "creator": "@creator:matrix.org"
            }
        }]
        
        test_room = room(events, "!simple:matrix.org")
        assert test_room.creator == "@creator:matrix.org"
        assert test_room.room_type is None
        assert test_room.additional_creators == []
        assert test_room.join_rule_allow is None
        assert test_room.topic_content is None
    
    def test_simple_member_events_still_work(self):
        """Test that simple member events work as before"""
        events = [{
            "type": "m.room.member",
            "content": {"membership": "join"},
            "state_key": "@simple:matrix.org"
        }]
        
        test_room = room(events, "!test:matrix.org")
        assert "@simple:matrix.org" in test_room.members
        assert "@simple:matrix.org" in test_room.member_details
        
        member = test_room.member_details["@simple:matrix.org"]
        assert member.user_id == "@simple:matrix.org"
        assert member.membership == "join"
        assert member.avatar_url is None
        assert member.displayname is None


class TestLiveStateUpdates:
    """Test apply_state_event for incremental live updates"""

    def test_apply_name_change(self):
        """Room name updates in place"""
        r = room([{"type": "m.room.name", "content": {"name": "Old"}}], "!r:m.org")
        assert r.name == "Old"

        r.apply_state_event({"type": "m.room.name", "content": {"name": "New"}})
        assert r.name == "New"

    def test_apply_topic_change(self):
        r = room([], "!r:m.org")
        r.apply_state_event({"type": "m.room.topic", "content": {"topic": "Updated"}})
        assert r.topic == "Updated"

    def test_apply_power_levels(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.power_levels",
            "content": {
                "users": {"@admin:m.org": 100},
                "users_default": 0,
                "ban": 50,
            }
        })
        assert r.permissions is not None
        assert r.permissions.ban_value == 50

    def test_apply_member_join(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.member",
            "state_key": "@alice:m.org",
            "content": {"membership": "join", "displayname": "Alice"}
        })
        assert "@alice:m.org" in r.members
        assert r.member_details["@alice:m.org"].displayname == "Alice"

    def test_apply_member_leave_removes_from_join(self):
        r = room([{
            "type": "m.room.member",
            "state_key": "@alice:m.org",
            "content": {"membership": "join"}
        }], "!r:m.org")
        assert "@alice:m.org" in r.members

        r.apply_state_event({
            "type": "m.room.member",
            "state_key": "@alice:m.org",
            "content": {"membership": "leave"}
        })
        assert "@alice:m.org" not in r.members
        assert "@alice:m.org" in r.left

    def test_apply_member_ban(self):
        r = room([{
            "type": "m.room.member",
            "state_key": "@bad:m.org",
            "content": {"membership": "join"}
        }], "!r:m.org")

        r.apply_state_event({
            "type": "m.room.member",
            "state_key": "@bad:m.org",
            "content": {"membership": "ban", "reason": "spam"}
        })
        assert "@bad:m.org" not in r.members
        assert "@bad:m.org" not in r.left
        assert "@bad:m.org" in r.banned
        assert r.member_details["@bad:m.org"].reason == "spam"

    def test_apply_member_knock(self):
        r = room([], "!r:m.org")

        r.apply_state_event({
            "type": "m.room.member",
            "state_key": "@visitor:m.org",
            "content": {"membership": "knock", "reason": "please"}
        })
        assert "@visitor:m.org" in r.knocked
        assert "@visitor:m.org" not in r.members
        assert "@visitor:m.org" not in r.left
        assert "@visitor:m.org" not in r.invited

    def test_apply_encryption(self):
        r = room([], "!r:m.org")
        assert r.encryption is None

        r.apply_state_event({
            "type": "m.room.encryption",
            "content": {"algorithm": "m.megolm.v1.aes-sha2"}
        })
        assert r.encryption.algorithm == "m.megolm.v1.aes-sha2"

    def test_apply_alias_change(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.canonical_alias",
            "content": {"alias": "#new:m.org", "alt_aliases": ["#old:m.org"]}
        })
        assert r.alias.canonical == "#new:m.org"
        assert "#old:m.org" in r.alias.alt

    def test_apply_pinned_events(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.pinned_events",
            "content": {"pinned": ["$ev1", "$ev2"]}
        })
        assert r.pinned_events == ["$ev1", "$ev2"]

    def test_apply_tombstone(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.tombstone",
            "content": {"body": "Room upgraded", "replacement_room": "!new:m.org"}
        })
        assert r.tombstone_body == "Room upgraded"
        assert r.tombstone_replacement_room == "!new:m.org"

    def test_apply_guest_access(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.guest_access",
            "content": {"guest_access": "can_join"}
        })
        assert r.guestAccess is True

        r.apply_state_event({
            "type": "m.room.guest_access",
            "content": {"guest_access": "forbidden"}
        })
        assert r.guestAccess is False

    def test_apply_server_acl(self):
        r = room([], "!r:m.org")
        r.apply_state_event({
            "type": "m.room.server_acl",
            "content": {"allow_ip_literals": False, "allow": ["*.good.org"], "deny": ["bad.org"]}
        })
        assert r.acl.allow_ip_literals is False
        assert "bad.org" in r.acl.deny
