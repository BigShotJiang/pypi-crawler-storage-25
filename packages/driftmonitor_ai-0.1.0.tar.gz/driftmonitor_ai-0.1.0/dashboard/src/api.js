/**
 * API client for Drift//Monitor FastAPI backend.
 */

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

async function request(path, options = {}) {
  const resp = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  if (!resp.ok) {
    const body = await resp.json().catch(() => ({}));
    throw new Error(body.detail || `API error: ${resp.status}`);
  }
  return resp.json();
}

export const api = {
  health: () => request("/health"),

  // Sessions
  listSessions: () => request("/sessions"),
  getSession: (id) => request(`/sessions/${id}`),
  deleteSession: (id) => request(`/sessions/${id}`, { method: "DELETE" }),

  // Events
  listEvents: (sessionId, { limit = 50, severity } = {}) => {
    const params = new URLSearchParams({ limit });
    if (severity) params.set("severity", severity);
    return request(`/sessions/${sessionId}/events?${params}`);
  },
  getLatest: (sessionId) => request(`/sessions/${sessionId}/latest`),
  getSummary: (sessionId) => request(`/sessions/${sessionId}/summary`),

  // Audit
  listAudit: ({ sessionId, action, limit = 100 } = {}) => {
    const params = new URLSearchParams({ limit });
    if (sessionId) params.set("session_id", sessionId);
    if (action) params.set("action", action);
    return request(`/audit?${params}`);
  },
};

/**
 * Connect to WebSocket for live drift score streaming.
 * Returns a cleanup function.
 */
export function connectWebSocket(sessionId, onEvent) {
  const wsUrl = BASE_URL.replace(/^http/, "ws");
  const ws = new WebSocket(`${wsUrl}/ws/${sessionId}`);

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === "drift_event") {
        onEvent(data.event);
      }
    } catch {
      // ignore parse errors
    }
  };

  ws.onopen = () => ws.send("ping");

  // Keep alive
  const interval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) ws.send("ping");
  }, 30000);

  return () => {
    clearInterval(interval);
    ws.close();
  };
}
