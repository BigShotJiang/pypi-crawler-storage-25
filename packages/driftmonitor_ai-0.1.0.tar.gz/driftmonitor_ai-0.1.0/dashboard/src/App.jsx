import { useState, useEffect, useCallback } from "react";
import { api, connectWebSocket } from "./api";
import SessionList from "./components/SessionList";
import EventPanel from "./components/EventPanel";
import AuditPanel from "./components/AuditPanel";
import { useSessions, useSessionEvents } from "./hooks/useSessions";

export default function App() {
  const { sessions, loading: sessionsLoading, refresh: refreshSessions } = useSessions();
  const [activeIndex, setActiveIndex] = useState(0);
  const [health, setHealth] = useState(null);
  const [eventsBySession, setEventsBySession] = useState({});

  const activeSession = sessions[activeIndex] || null;
  const activeId = activeSession?.session_id;

  const { events, summary, loading: eventsLoading, refresh: refreshEvents, setEvents } = useSessionEvents(activeId);

  // Fetch health
  useEffect(() => {
    api.health().then(setHealth).catch(() => {});
  }, []);

  // Preload event data for all sessions (for sparklines)
  useEffect(() => {
    sessions.forEach(async (s) => {
      try {
        const data = await api.listEvents(s.session_id, { limit: 20 });
        setEventsBySession((prev) => ({ ...prev, [s.session_id]: data.events }));
      } catch {
        // ignore
      }
    });
  }, [sessions]);

  // Also keep active session events in the cache
  useEffect(() => {
    if (activeId && events.length > 0) {
      setEventsBySession((prev) => ({ ...prev, [activeId]: events }));
    }
  }, [activeId, events]);

  // WebSocket for live updates
  useEffect(() => {
    if (!activeId) return;
    const cleanup = connectWebSocket(activeId, (event) => {
      setEvents((prev) => [...prev, event]);
      setEventsBySession((prev) => ({
        ...prev,
        [activeId]: [...(prev[activeId] || []), event],
      }));
    });
    return cleanup;
  }, [activeId, setEvents]);

  // Poll for new sessions every 10s
  useEffect(() => {
    const interval = setInterval(refreshSessions, 10000);
    return () => clearInterval(interval);
  }, [refreshSessions]);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#080c12",
      fontFamily: "var(--font-mono)",
      color: "#c8d8e8",
      backgroundImage: "radial-gradient(ellipse at 20% 50%, rgba(0,212,255,0.03) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(168,255,62,0.03) 0%, transparent 60%)",
    }}>
      {/* Header */}
      <div style={{ borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <div style={{
            width: "8px", height: "8px", borderRadius: "50%",
            background: health ? "#3bff8a" : "#ff2b2b",
            boxShadow: health ? "0 0 10px #3bff8a" : "0 0 10px #ff2b2b",
            animation: "pulse 2s infinite",
          }} />
          <span style={{ fontSize: "13px", letterSpacing: "0.2em", color: "#e0f0ff" }}>DRIFT//MONITOR</span>
          <span style={{ fontSize: "10px", color: "#445566", letterSpacing: "0.1em" }}>
            {health ? `v${health.version} \u00b7 LIVE` : "CONNECTING\u2026"}
          </span>
        </div>
        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          <span style={{ fontSize: "10px", color: "#445566" }}>
            {sessions.length} SESSIONS
          </span>
          <button
            onClick={() => { refreshSessions(); refreshEvents(); }}
            style={{
              background: "rgba(0,212,255,0.1)", border: "1px solid rgba(0,212,255,0.3)",
              color: "#00d4ff", padding: "6px 14px", borderRadius: "4px",
              fontSize: "10px", cursor: "pointer", letterSpacing: "0.1em",
              transition: "all 0.2s",
            }}
          >
            {"\u25C8"} REFRESH
          </button>
        </div>
      </div>

      {/* Three-Panel Layout */}
      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr 280px", height: "calc(100vh - 57px)" }}>
        <SessionList
          sessions={sessions}
          activeIndex={activeIndex}
          onSelect={setActiveIndex}
          eventsBySession={eventsBySession}
        />
        <EventPanel
          session={activeSession}
          events={events}
          summary={summary}
          loading={eventsLoading}
        />
        <AuditPanel sessions={sessions} />
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&display=swap');
        :root { --font-mono: 'JetBrains Mono', 'Fira Code', monospace; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: var(--font-mono); background: #080c12; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
        ::-webkit-scrollbar{width:4px} ::-webkit-scrollbar-track{background:transparent} ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:2px}
        button:hover{opacity:0.85;transform:translateY(-1px)}
      `}</style>
    </div>
  );
}
