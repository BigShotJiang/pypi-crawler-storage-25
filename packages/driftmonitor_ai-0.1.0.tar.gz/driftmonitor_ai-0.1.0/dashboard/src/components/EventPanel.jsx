import DriftBar, { DRIFT_TYPES, severityOf } from "./DriftBar";
import PolarDrift from "./PolarDrift";

export default function EventPanel({ session, events, summary, loading }) {
  if (!session) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: "#334455" }}>
        Select a session to view drift scores.
      </div>
    );
  }

  const latest = events[events.length - 1];
  const scores = latest?.scores || { persona: 0, goal: 0, instruction: 0, semantic: 0, composite: 0 };
  const sev = severityOf(scores.composite);

  return (
    <div style={{ overflowY: "auto", padding: "20px 24px" }}>
      {/* Session Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <div>
          <div style={{ fontSize: "18px", color: "#e0f0ff", letterSpacing: "0.05em", marginBottom: "4px" }}>
            {session.name || session.session_id}
          </div>
          <div style={{ fontSize: "10px", color: "#445566", letterSpacing: "0.1em" }}>
            {session.session_type} · {events.length} turns · ID: {session.session_id}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: sev.color, boxShadow: `0 0 8px ${sev.color}` }} />
          <span style={{ fontSize: "10px", color: sev.color, letterSpacing: "0.1em" }}>
            {loading ? "LOADING\u2026" : sev.label}
          </span>
        </div>
      </div>

      {/* Drift Scores + Radar */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 160px", gap: "20px", marginBottom: "20px" }}>
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "18px" }}>
          <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "16px" }}>DRIFT SCORES</div>
          {Object.entries(DRIFT_TYPES).map(([k, v]) => (
            <DriftBar key={k} value={scores[k] ?? 0} color={v.color} label={v.label} icon={v.icon} />
          ))}
          <div style={{ marginTop: "16px", paddingTop: "14px", borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: "10px", color: "#445566", letterSpacing: "0.1em" }}>COMPOSITE DRIFT</span>
            <span style={{ fontSize: "22px", color: sev.color, fontWeight: "700" }}>{Math.round(scores.composite)}</span>
          </div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "18px", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "12px", width: "100%", textAlign: "center" }}>RADAR</div>
          <PolarDrift scores={scores} />
        </div>
      </div>

      {/* Summary */}
      {summary && (
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "16px", marginBottom: "20px" }}>
          <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "10px" }}>SESSION SUMMARY</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: "12px" }}>
            <Stat label="Turns" value={summary.turn_count} />
            <Stat label="Avg" value={summary.avg_composite.toFixed(1)} />
            <Stat label="Max" value={summary.max_composite.toFixed(1)} />
            <Stat label="Severity" value={summary.overall_severity.toUpperCase()} color={severityOf(summary.avg_composite).color} />
          </div>
        </div>
      )}

      {/* Conversation Trace */}
      <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "8px", padding: "16px" }}>
        <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "14px" }}>
          EVENT LOG ({events.length} events)
        </div>
        <div style={{ maxHeight: "400px", overflowY: "auto" }}>
          {events.length === 0 && (
            <div style={{ fontSize: "11px", color: "#334455", textAlign: "center", padding: "20px 0" }}>
              No events recorded yet.
            </div>
          )}
          {events.map((e, i) => {
            const eSev = severityOf(e.scores.composite);
            return (
              <div key={e.event_id || i} style={{ marginBottom: "12px", padding: "10px", background: "rgba(255,255,255,0.02)", borderRadius: "6px", borderLeft: `2px solid ${eSev.color}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                  <span style={{ fontSize: "9px", color: "#6677aa" }}>
                    Turn {e.turn_number} · {e.timestamp?.slice(11, 19) || ""}
                  </span>
                  <span style={{ fontSize: "10px", color: eSev.color, fontWeight: "700" }}>
                    {e.scores.composite.toFixed(1)} {eSev.label}
                  </span>
                </div>
                {e.user_content && (
                  <div style={{ fontSize: "10px", color: "#8899aa", marginTop: "4px" }}>
                    <span style={{ color: "#a8ff3e", fontSize: "9px" }}>USER:</span> {e.user_content.slice(0, 120)}{e.user_content.length > 120 ? "\u2026" : ""}
                  </div>
                )}
                {e.assistant_content && (
                  <div style={{ fontSize: "10px", color: "#667788", marginTop: "2px" }}>
                    <span style={{ color: "#00d4ff", fontSize: "9px" }}>ASST:</span> {e.assistant_content.slice(0, 120)}{e.assistant_content.length > 120 ? "\u2026" : ""}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.1em", marginBottom: "4px" }}>{label}</div>
      <div style={{ fontSize: "14px", color: color || "#e0f0ff", fontWeight: "700" }}>{value}</div>
    </div>
  );
}
