import { useState, useEffect } from "react";

export const DRIFT_TYPES = {
  persona: { label: "Persona/Tone", icon: "\u25C8", color: "#00d4ff", desc: "Voice, formality, character consistency" },
  goal: { label: "Goal Alignment", icon: "\u25CE", color: "#ff6b35", desc: "Staying on original objective" },
  instruction: { label: "Instruction Follow", icon: "\u25C9", color: "#a8ff3e", desc: "Respecting earlier constraints" },
  semantic: { label: "Semantic Fidelity", icon: "\u25C7", color: "#ff3ea8", desc: "Alignment with source material" },
};

export function severityOf(score) {
  if (score > 70) return { label: "CRITICAL", color: "#ff2b2b" };
  if (score > 40) return { label: "ELEVATED", color: "#ff8c00" };
  if (score > 20) return { label: "LOW", color: "#ffd700" };
  return { label: "NOMINAL", color: "#3bff8a" };
}

export default function DriftBar({ value, color, label, icon }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const timer = setTimeout(() => setDisplay(value), 100);
    return () => clearTimeout(timer);
  }, [value]);

  const sev = severityOf(value);

  return (
    <div style={{ marginBottom: "14px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "5px" }}>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: "11px", color: "#8899aa", letterSpacing: "0.08em" }}>
          <span style={{ color }}>{icon}</span> {label.toUpperCase()}
        </span>
        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "10px", color: sev.color, letterSpacing: "0.12em" }}>{sev.label}</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "13px", color, fontWeight: "700" }}>{display.toFixed(1)}</span>
        </div>
      </div>
      <div style={{ height: "6px", background: "rgba(255,255,255,0.06)", borderRadius: "3px", overflow: "hidden" }}>
        <div style={{
          height: "100%",
          width: `${display}%`,
          background: `linear-gradient(90deg, ${color}88, ${color})`,
          borderRadius: "3px",
          transition: "width 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
          boxShadow: display > 40 ? `0 0 8px ${color}88` : "none",
        }} />
      </div>
    </div>
  );
}
