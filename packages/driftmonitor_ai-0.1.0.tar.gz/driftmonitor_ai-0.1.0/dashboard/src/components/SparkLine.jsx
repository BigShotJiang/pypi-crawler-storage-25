export default function SparkLine({ data, color }) {
  if (!data || data.length < 2) return null;
  const w = 120, h = 32;
  const max = Math.max(...data, 10);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - (v / max) * h}`).join(" ");
  return (
    <svg width={w} height={h} style={{ display: "block" }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" opacity="0.8" />
      <circle cx={w} cy={h - (data[data.length - 1] / max) * h} r="3" fill={color} />
    </svg>
  );
}
