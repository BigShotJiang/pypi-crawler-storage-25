import { useState, useEffect } from "react";
import { api } from "../api";
import { severityOf } from "./DriftBar";

export default function AuditPanel({ sessions }) {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listAudit({ limit: 50 })
      .then((data) => setEntries(data.entries))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const actionColor = {
    drift_detected: "#6677aa",
    gate_held: "#ff8c00",
    gate_released: "#3bff8a",
    gate_rejected: "#ff2b2b",
    correction_generated: "#00d4ff",
    alert_sent: "#ffd700",
    mode_changed: "#a8ff3e",
    session_started: "#445566",
    session_ended: "#445566",
  };

  return (
    <div style={{ borderLeft: "1px solid rgba(255,255,255,0.07)", padding: "16px", overflowY: "auto" }}>
      <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "14px" }}>
        AUDIT LOG
      </div>

      {loading && (
        <div style={{ fontSize: "11px", color: "#334455", textAlign: "center", padding: "20px 0" }}>
          Loading...
        </div>
      )}

      {!loading && entries.length === 0 && (
        <div style={{ fontSize: "11px", color: "#334455", textAlign: "center", padding: "40px 0" }}>
          No audit entries.<br />
          <span style={{ fontSize: "10px" }}>Start a monitored session to generate entries.</span>
        </div>
      )}

      {entries.map((e) => (
        <div key={e.entry_id} style={{
          marginBottom: "8px", padding: "10px",
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: "6px",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
            <span style={{ fontSize: "9px", color: actionColor[e.action] || "#6677aa", letterSpacing: "0.08em" }}>
              {e.action.replace(/_/g, " ").toUpperCase()}
            </span>
            <span style={{ fontSize: "9px", color: "#445566" }}>
              {e.timestamp?.slice(11, 19) || ""}
            </span>
          </div>
          {e.composite_score > 0 && (
            <div style={{ fontSize: "10px", color: severityOf(e.composite_score).color }}>
              Score: {e.composite_score.toFixed(1)}
            </div>
          )}
          {e.details && (
            <div style={{ fontSize: "10px", color: "#667788", marginTop: "2px", fontStyle: "italic" }}>
              {e.details.slice(0, 100)}
            </div>
          )}
          {e.operator && (
            <div style={{ fontSize: "9px", color: "#445566", marginTop: "2px" }}>
              by {e.operator}
            </div>
          )}
        </div>
      ))}

      {/* Severity Legend */}
      <div style={{ marginTop: "20px", paddingTop: "16px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "12px" }}>SEVERITY SCALE</div>
        {[["NOMINAL", "0\u201320", "#3bff8a"], ["LOW", "21\u201340", "#ffd700"], ["ELEVATED", "41\u201370", "#ff8c00"], ["CRITICAL", "71\u2013100", "#ff2b2b"]].map(([l, r, c]) => (
          <div key={l} style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: c }} />
              <span style={{ fontSize: "10px", color: c }}>{l}</span>
            </div>
            <span style={{ fontSize: "10px", color: "#445566" }}>{r}</span>
          </div>
        ))}
      </div>

      {/* Session Summary */}
      {sessions.length > 0 && (
        <div style={{ marginTop: "20px", paddingTop: "16px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.15em", marginBottom: "10px" }}>
            ALL SESSIONS
          </div>
          {sessions.map((s) => (
            <div key={s.session_id} style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px", alignItems: "center" }}>
              <span style={{ fontSize: "10px", color: "#6677aa" }}>{(s.name || s.session_id).slice(0, 18)}</span>
              <span style={{ fontSize: "10px", color: "#8899aa" }}>{s.event_count} turns</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
