import SparkLine from "./SparkLine";
import { severityOf } from "./DriftBar";

export default function SessionList({ sessions, activeIndex, onSelect, eventsBySession }) {
  return (
    <div style={{ borderRight: "1px solid rgba(255,255,255,0.07)", padding: "16px 0", overflowY: "auto" }}>
      <div style={{ padding: "0 16px 12px", fontSize: "9px", color: "#445566", letterSpacing: "0.15em" }}>
        ACTIVE SESSIONS ({sessions.length})
      </div>
      {sessions.length === 0 && (
        <div style={{ padding: "20px 16px", fontSize: "11px", color: "#334455", textAlign: "center" }}>
          No sessions found.<br />
          <span style={{ fontSize: "10px" }}>Wrap an Anthropic client with DriftAwareClient to start monitoring.</span>
        </div>
      )}
      {sessions.map((s, i) => {
        const events = eventsBySession[s.session_id] || [];
        const latest = events[events.length - 1];
        const composite = latest?.scores?.composite ?? 0;
        const sev = severityOf(composite);
        const history = events.map((e) => e.scores?.composite ?? 0);

        return (
          <div
            key={s.session_id}
            onClick={() => onSelect(i)}
            style={{
              padding: "12px 16px",
              cursor: "pointer",
              borderLeft: `2px solid ${activeIndex === i ? "#00d4ff" : "transparent"}`,
              background: activeIndex === i ? "rgba(0,212,255,0.05)" : "transparent",
              transition: "all 0.2s",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "6px" }}>
              <div>
                <div style={{ fontSize: "11px", color: activeIndex === i ? "#e0f0ff" : "#8899aa", marginBottom: "2px" }}>
                  {s.name || s.session_id}
                </div>
                <div style={{ fontSize: "9px", color: "#445566", letterSpacing: "0.08em" }}>
                  {s.session_type.toUpperCase()} · {s.event_count} turns
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: "14px", color: sev.color, fontWeight: "700", lineHeight: 1 }}>
                  {Math.round(composite)}
                </div>
                <div style={{ fontSize: "8px", color: sev.color, letterSpacing: "0.1em" }}>
                  {sev.label}
                </div>
              </div>
            </div>
            {history.length > 1 && <SparkLine data={history} color={sev.color} />}
          </div>
        );
      })}
    </div>
  );
}
