import { DRIFT_TYPES } from "./DriftBar";

export default function PolarDrift({ scores }) {
  const cx = 80, cy = 80, r = 60;
  const keys = Object.keys(DRIFT_TYPES);

  const points = keys.map((k, i) => {
    const angle = (i / keys.length) * Math.PI * 2 - Math.PI / 2;
    const val = (scores?.[k] ?? 0) / 100;
    return [cx + Math.cos(angle) * r * val, cy + Math.sin(angle) * r * val];
  });

  const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ") + "Z";

  const gridPts = (frac) => keys.map((_, i) => {
    const angle = (i / keys.length) * Math.PI * 2 - Math.PI / 2;
    return [cx + Math.cos(angle) * r * frac, cy + Math.sin(angle) * r * frac];
  });

  return (
    <svg width={160} height={160} style={{ display: "block", margin: "0 auto" }}>
      {[0.25, 0.5, 0.75, 1].map((f) => {
        const gpts = gridPts(f);
        const gpath = gpts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ") + "Z";
        return <path key={f} d={gpath} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="1" />;
      })}
      {keys.map((_, i) => {
        const angle = (i / keys.length) * Math.PI * 2 - Math.PI / 2;
        return <line key={i} x1={cx} y1={cy} x2={cx + Math.cos(angle) * r} y2={cy + Math.sin(angle) * r} stroke="rgba(255,255,255,0.08)" strokeWidth="1" />;
      })}
      <path d={path} fill="rgba(0,212,255,0.15)" stroke="#00d4ff" strokeWidth="1.5" strokeLinejoin="round" />
      {keys.map((k, i) => {
        const angle = (i / keys.length) * Math.PI * 2 - Math.PI / 2;
        const lx = cx + Math.cos(angle) * (r + 14);
        const ly = cy + Math.sin(angle) * (r + 14);
        const info = DRIFT_TYPES[k];
        return (
          <text key={k} x={lx} y={ly} textAnchor="middle" dominantBaseline="middle"
            style={{ fontSize: "8px", fill: info.color, fontFamily: "monospace", letterSpacing: "0.05em" }}>
            {info.icon}
          </text>
        );
      })}
    </svg>
  );
}
