import { useState, useEffect, useCallback } from "react";
import { api } from "../api";

export function useSessions() {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.listSessions();
      setSessions(data.sessions);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { sessions, loading, error, refresh };
}

export function useSessionEvents(sessionId) {
  const [events, setEvents] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!sessionId) return;
    try {
      setLoading(true);
      const [evtData, sumData] = await Promise.all([
        api.listEvents(sessionId, { limit: 50 }),
        api.getSummary(sessionId).catch(() => null),
      ]);
      setEvents(evtData.events);
      setSummary(sumData);
    } catch {
      // session may have no events
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { events, summary, loading, refresh, setEvents };
}
