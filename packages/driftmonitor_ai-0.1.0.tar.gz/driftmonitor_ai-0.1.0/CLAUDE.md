# CLAUDE.md — Drift//Monitor

## Project Overview

Real-time behavioral drift detection for AI systems. Drop-in SDK proxy that wraps the Anthropic client, scores output drift via local embeddings + SPC control charts, and logs everything to SQLite.

**Positioning**: The andon cord for language models.

## Current State

- **Version**: 0.1.0
- **Language**: Python 3.11+
- **Tests**: 238
- **Status**: Week 1-5 complete — full SDK, all five build spec weeks implemented

## Architecture

```
drift-monitor/
├── prototype/
│   └── drift-monitor.jsx          # Working React component (520 lines)
├── docs/
│   └── drift-monitor-build-spec.docx  # Full build spec
├── src/driftmonitor/
│   ├── __init__.py                # Public API exports
│   ├── _version.py                # Version constant
│   ├── models.py                  # Pydantic models (DriftScore, DriftEvent, SessionConfig)
│   ├── store.py                   # SQLite event store (WAL, sessions, events, anchors)
│   ├── embeddings.py              # sentence-transformers wrapper, cosine distance, axis scoring
│   ├── spc.py                     # Statistical Process Control engine (control limits, trends)
│   ├── explainer.py               # LLM-powered drift explanation + correction generation
│   ├── audit.py                   # Immutable audit log, OBSERVE/ALERT/GATE modes, CSV/JSON export
│   ├── client.py                  # DriftAwareClient Anthropic wrapper (drop-in proxy)
│   ├── cli.py                     # Typer CLI (sessions, scores, summary)
│   └── api/
│       ├── __init__.py
│       ├── app.py                 # FastAPI app (REST + WebSocket)
│       └── schemas.py             # API response models
├── tests/
│   ├── conftest.py                # Shared fixtures
│   ├── test_models.py             # 38 tests
│   ├── test_store.py              # 33 tests
│   ├── test_embeddings.py         # 25 tests
│   ├── test_spc.py                # 30 tests
│   ├── test_explainer.py          # 19 tests
│   ├── test_client.py             # 20 tests
│   ├── test_cli.py                # 11 tests
│   ├── test_api.py                # 24 tests
│   └── test_audit.py              # 29 tests (modes, audit, gate, export)
├── pyproject.toml                 # setuptools, src layout, ruff, pytest config
├── README.md
├── CLAUDE.md
└── .gitignore
```

## Three-Layer Architecture

| Layer | Function | Technology | Status |
|-------|----------|------------|--------|
| Layer 1: Capture | Intercept every LLM input/output via proxy SDK | Python package, drop-in client wrapper | In progress |
| Layer 2: Score | Embed + measure statistical deviation from anchor | sentence-transformers, SPC control charts | Done |
| Layer 3: Act | Alert, correct, gate, and log drift events | FastAPI, SQLite/Postgres, React dashboard | API done |

## Tech Stack

- **Language**: Python
- **Package Manager**: pip (setuptools)
- **Linters**: ruff
- **Formatters**: ruff
- **Type Checkers**: mypy
- **Test Frameworks**: pytest
- **Embeddings**: sentence-transformers (all-MiniLM-L6-v2 default)
- **Storage**: SQLite (WAL mode)
- **API Client**: anthropic (wrapped by DriftAwareClient)
- **CLI**: typer + rich
- **Deploy Target**: PyPI (SDK), Fly.io (API layer, future)

## Common Commands

```bash
# test
.venv/bin/python -m pytest tests/ -v

# test with coverage
.venv/bin/python -m pytest tests/ -v --cov=driftmonitor

# lint
.venv/bin/ruff check src/ tests/

# format
.venv/bin/ruff format src/ tests/

# install (dev)
pip install -e ".[dev]"
```

## Coding Standards

- **Naming**: snake_case
- **Quote Style**: double quotes
- **Type Hints**: present (strict mypy)
- **Imports**: absolute, from __future__ import annotations
- **Path Handling**: pathlib.Path
- **Line Length**: 100 characters
- **Error Handling**: specific exceptions, no bare except
- **Enums**: StrEnum (not str, Enum)
- **Timezone**: timezone.utc (not datetime.UTC — incompatible with `from __future__ import annotations`)

## Key Design Decisions

- **Embedding-first scoring**: Cosine distance from anchor embedding is the primary signal. LLM is invoked only to explain anomalies (keeps costs near zero)
- **SPC methodology**: Drift scores treated as process output. NOMINAL/LOW/ELEVATED/CRITICAL thresholds mapped to 1σ/2σ/3σ control limits
- **Transparent proxy**: DriftAwareClient returns responses unmodified. Scoring is async/non-blocking
- **SQLite WAL mode**: check_same_thread=False for FastAPI cross-thread usage
- **Anchor embedding**: First assistant response becomes the baseline. Configurable via reference document

## Anti-Patterns

- Do NOT store embeddings as raw floats in SQLite — use JSON-encoded blobs
- Do NOT invoke LLM for every turn's scoring — embeddings handle 99% of detection
- Do NOT block response delivery for scoring (except in GATE mode)
- Do NOT use `from __future__ import annotations` with `datetime.UTC` — it breaks at runtime on Python 3.12

## Severity Scale

| Level | Score Range | Default Action |
|-------|------------|----------------|
| NOMINAL | 0-20 | Log only |
| LOW | 21-40 | Dashboard flag |
| ELEVATED | 41-70 | Operator notification |
| CRITICAL | 71-100 | Andon cord — gate or halt |

## Git Conventions

- Commit messages: Conventional commits (`feat:`, `fix:`, `docs:`, `test:`, `refactor:`)
- Run tests before committing
- Branch naming: `feat/description`, `fix/description`
