# Publishing to PyPI

## Trusted Publisher Setup (one-time)

1. Go to https://pypi.org/manage/account/publishing/
2. Add a new pending publisher:
   - **PyPI project name**: `driftmonitor`
   - **Owner**: `AreteDriver`
   - **Repository**: `drift-monitor`
   - **Workflow name**: `publish.yml`
   - **Environment name**: `pypi`
3. Create a GitHub environment called `pypi` at:
   https://github.com/AreteDriver/drift-monitor/settings/environments

## Creating a Release

```bash
# Bump version in src/driftmonitor/_version.py and pyproject.toml
# Then:
git add -A && git commit -m "chore: bump version to 0.1.0"
git tag v0.1.0
git push origin main --tags

# Create GitHub release (triggers publish workflow)
gh release create v0.1.0 --title "v0.1.0" --notes "Initial release"
```

## Manual Publish (if needed)

```bash
pip install build twine
python -m build
twine upload dist/*
```

## Verify

```bash
pip install driftmonitor
python -c "from driftmonitor import __version__; print(__version__)"
driftmonitor version
```
