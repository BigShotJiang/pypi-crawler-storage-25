"""Statistical Process Control engine for drift monitoring.

Applies SPC methodology (the same principles used on Toyota assembly lines)
to drift scores, treating each turn's composite score as a process output.

Control limits are computed from rolling statistics:
- UCL (Upper Control Limit) = mean + k * stddev
- LCL (Lower Control Limit) = max(0, mean - k * stddev)

Severity thresholds map to sigma levels:
- NOMINAL: score < mean + 1σ
- LOW:     score ≥ mean + 1σ
- ELEVATED: score ≥ mean + 2σ
- CRITICAL: score ≥ mean + 3σ
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from driftmonitor.models import DriftScore, Severity


@dataclass
class ControlLimits:
    """SPC control limits computed from score history."""

    mean: float = 0.0
    stddev: float = 0.0
    ucl_1sigma: float = 0.0
    ucl_2sigma: float = 0.0
    ucl_3sigma: float = 0.0
    lcl_1sigma: float = 0.0
    sample_size: int = 0

    @property
    def is_valid(self) -> bool:
        """Control limits require at least 3 data points to be meaningful."""
        return self.sample_size >= 3

    def classify(self, score: float) -> Severity:
        """Classify a score against SPC control limits."""
        if not self.is_valid:
            return Severity.from_score(score)
        if score >= self.ucl_3sigma:
            return Severity.CRITICAL
        if score >= self.ucl_2sigma:
            return Severity.ELEVATED
        if score >= self.ucl_1sigma:
            return Severity.LOW
        return Severity.NOMINAL


@dataclass
class TrendResult:
    """Result of trend detection analysis."""

    trending_up: bool = False
    trending_down: bool = False
    run_length: int = 0
    consecutive_above_mean: int = 0
    consecutive_below_mean: int = 0

    @property
    def has_run(self) -> bool:
        """A run of 7+ points on same side of mean signals process shift."""
        return self.consecutive_above_mean >= 7 or self.consecutive_below_mean >= 7

    @property
    def has_trend(self) -> bool:
        """6+ consecutive increasing or decreasing points signals a trend."""
        return self.run_length >= 6


@dataclass
class SPCResult:
    """Combined SPC analysis result for a single score."""

    score: float
    severity: Severity
    limits: ControlLimits
    trend: TrendResult
    out_of_control: bool = False

    @property
    def needs_explanation(self) -> bool:
        """Whether this result warrants an LLM explanation call."""
        return (
            self.severity in (Severity.ELEVATED, Severity.CRITICAL)
            or self.out_of_control
            or self.trend.has_run
            or self.trend.has_trend
        )


class SPCEngine:
    """Statistical Process Control engine for drift score analysis.

    Maintains a rolling window of scores and computes control limits,
    detects out-of-control conditions, and identifies trends.
    """

    def __init__(self, window_size: int = 20, min_samples: int = 3) -> None:
        self.window_size = window_size
        self.min_samples = min_samples
        self._scores: list[float] = []
        self._axis_scores: dict[str, list[float]] = {
            "persona": [],
            "goal": [],
            "instruction": [],
            "semantic": [],
        }

    @property
    def scores(self) -> list[float]:
        """Current score history."""
        return list(self._scores)

    @property
    def sample_count(self) -> int:
        return len(self._scores)

    def add_score(self, drift_score: DriftScore) -> SPCResult:
        """Add a new drift score and return the SPC analysis.

        This is the main entry point. Call once per turn with the
        DriftScore from the embedding engine.
        """
        composite = drift_score.composite
        self._scores.append(composite)
        if len(self._scores) > self.window_size:
            self._scores = self._scores[-self.window_size :]

        # Track per-axis scores
        for axis in self._axis_scores:
            val = drift_score.axis_score(axis)
            self._axis_scores[axis].append(val)
            if len(self._axis_scores[axis]) > self.window_size:
                self._axis_scores[axis] = self._axis_scores[axis][-self.window_size :]

        limits = self.compute_limits()
        severity = limits.classify(composite)
        trend = self.detect_trend()
        out_of_control = self._check_out_of_control(composite, limits, trend)

        return SPCResult(
            score=composite,
            severity=severity,
            limits=limits,
            trend=trend,
            out_of_control=out_of_control,
        )

    def compute_limits(self, scores: list[float] | None = None) -> ControlLimits:
        """Compute control limits from score history."""
        data = scores if scores is not None else self._scores
        n = len(data)

        if n == 0:
            return ControlLimits()

        mean = sum(data) / n

        if n < 2:
            return ControlLimits(mean=mean, sample_size=n)

        variance = sum((x - mean) ** 2 for x in data) / (n - 1)
        stddev = math.sqrt(variance)

        return ControlLimits(
            mean=mean,
            stddev=stddev,
            ucl_1sigma=mean + stddev,
            ucl_2sigma=mean + 2 * stddev,
            ucl_3sigma=mean + 3 * stddev,
            lcl_1sigma=max(0.0, mean - stddev),
            sample_size=n,
        )

    def compute_axis_limits(self) -> dict[str, ControlLimits]:
        """Compute control limits for each drift axis independently."""
        return {axis: self.compute_limits(scores) for axis, scores in self._axis_scores.items()}

    def detect_trend(self, scores: list[float] | None = None) -> TrendResult:
        """Detect trends and runs in the score history.

        SPC rules checked:
        - Run: 7+ consecutive points above or below the mean
        - Trend: 6+ consecutive points in the same direction
        """
        data = scores if scores is not None else self._scores
        if len(data) < 2:
            return TrendResult()

        mean = sum(data) / len(data)

        # Count consecutive points above/below mean (from most recent)
        above = 0
        below = 0
        for val in reversed(data):
            if val > mean:
                if below > 0:
                    break
                above += 1
            elif val < mean:
                if above > 0:
                    break
                below += 1
            else:
                break

        # Count consecutive increasing/decreasing (from most recent)
        inc_run = 1
        dec_run = 1
        for i in range(len(data) - 1, 0, -1):
            if data[i] > data[i - 1]:
                if inc_run > 0:
                    inc_run += 1
                else:
                    break
            else:
                break

        for i in range(len(data) - 1, 0, -1):
            if data[i] < data[i - 1]:
                if dec_run > 0:
                    dec_run += 1
                else:
                    break
            else:
                break

        run_length = max(inc_run, dec_run)
        trending_up = inc_run >= 6
        trending_down = dec_run >= 6

        return TrendResult(
            trending_up=trending_up,
            trending_down=trending_down,
            run_length=run_length,
            consecutive_above_mean=above,
            consecutive_below_mean=below,
        )

    def _check_out_of_control(
        self, score: float, limits: ControlLimits, trend: TrendResult
    ) -> bool:
        """Determine if the process is out of control.

        Out-of-control conditions (Western Electric rules):
        1. Single point beyond 3σ
        2. Run of 7+ on same side of mean
        3. Trend of 6+ consecutive increasing/decreasing
        4. 2 of 3 consecutive points beyond 2σ
        """
        if not limits.is_valid:
            return False

        # Rule 1: Beyond 3σ
        if score >= limits.ucl_3sigma:
            return True

        # Rule 2: Run
        if trend.has_run:
            return True

        # Rule 3: Trend
        if trend.has_trend:
            return True

        # Rule 4: 2 of 3 beyond 2σ
        if len(self._scores) >= 3:
            recent = self._scores[-3:]
            beyond_2sigma = sum(1 for s in recent if s >= limits.ucl_2sigma)
            if beyond_2sigma >= 2:
                return True

        return False

    def reset(self) -> None:
        """Clear all score history and reset the engine."""
        self._scores.clear()
        for axis in self._axis_scores:
            self._axis_scores[axis].clear()
