"""CLI for inspecting drift monitoring data."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from driftmonitor._version import __version__
from driftmonitor.models import Severity
from driftmonitor.store import DriftStore

app = typer.Typer(
    name="driftmonitor",
    help="Drift//Monitor — Real-time behavioral drift detection for AI systems.",
    no_args_is_help=True,
)
console = Console()

_DEFAULT_DB = "driftmonitor.db"


def _get_store(db: str) -> DriftStore:
    path = Path(db)
    if not path.exists():
        console.print(f"[red]Database not found:[/red] {db}")
        raise typer.Exit(1)
    return DriftStore(db_path=path)


@app.command()
def sessions(
    db: str = typer.Option(_DEFAULT_DB, "--db", "-d", help="Path to drift database"),
) -> None:
    """List all monitored sessions."""
    with _get_store(db) as store:
        rows = store.list_sessions()
        if not rows:
            console.print("[dim]No sessions found.[/dim]")
            return

        table = Table(title="Drift Sessions", show_lines=False)
        table.add_column("Session ID", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("Type", style="dim")
        table.add_column("Turns", justify="right")
        table.add_column("Created", style="dim")

        for row in rows:
            count = store.count_events(row["session_id"])
            table.add_row(
                row["session_id"],
                row["name"] or "—",
                row["session_type"],
                str(count),
                row["created_at"][:19],
            )
        console.print(table)


@app.command()
def scores(
    session_id: str = typer.Argument(help="Session ID to inspect"),
    db: str = typer.Option(_DEFAULT_DB, "--db", "-d", help="Path to drift database"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max events to show"),
) -> None:
    """Show drift scores for a session."""
    with _get_store(db) as store:
        sess = store.get_session(session_id)
        if not sess:
            console.print(f"[red]Session not found:[/red] {session_id}")
            raise typer.Exit(1)

        events = store.get_events(session_id, limit=limit)
        if not events:
            console.print("[dim]No events recorded.[/dim]")
            return

        table = Table(title=f"Drift Scores — {sess['name'] or session_id}", show_lines=False)
        table.add_column("Turn", justify="right", style="dim")
        table.add_column("Persona", justify="right")
        table.add_column("Goal", justify="right")
        table.add_column("Instruct", justify="right")
        table.add_column("Semantic", justify="right")
        table.add_column("Composite", justify="right", style="bold")
        table.add_column("Severity")

        for event in events:
            sev = event.severity
            sev_color = {
                Severity.NOMINAL: "green",
                Severity.LOW: "yellow",
                Severity.ELEVATED: "dark_orange",
                Severity.CRITICAL: "red",
            }.get(sev, "white")

            table.add_row(
                str(event.turn_number),
                f"{event.scores.persona:.1f}",
                f"{event.scores.goal:.1f}",
                f"{event.scores.instruction:.1f}",
                f"{event.scores.semantic:.1f}",
                f"{event.composite:.1f}",
                f"[{sev_color}]{sev.value.upper()}[/{sev_color}]",
            )
        console.print(table)


@app.command()
def summary(
    session_id: str = typer.Argument(help="Session ID to summarize"),
    db: str = typer.Option(_DEFAULT_DB, "--db", "-d", help="Path to drift database"),
) -> None:
    """Show aggregate drift statistics for a session."""
    with _get_store(db) as store:
        sess = store.get_session(session_id)
        if not sess:
            console.print(f"[red]Session not found:[/red] {session_id}")
            raise typer.Exit(1)

        stats = store.session_summary(session_id)
        if not stats:
            console.print("[dim]No events recorded.[/dim]")
            return

        table = Table(title=f"Session Summary — {sess['name'] or session_id}", show_lines=True)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")

        table.add_row("Total Turns", str(stats["turn_count"]))
        table.add_row("Avg Composite", f"{stats['avg_composite']:.1f}")
        table.add_row("Max Composite", f"{stats['max_composite']:.1f}")
        table.add_row("Min Composite", f"{stats['min_composite']:.1f}")
        table.add_row("Avg Persona", f"{stats['avg_persona']:.1f}")
        table.add_row("Avg Goal", f"{stats['avg_goal']:.1f}")
        table.add_row("Avg Instruction", f"{stats['avg_instruction']:.1f}")
        table.add_row("Avg Semantic", f"{stats['avg_semantic']:.1f}")

        overall_sev = Severity.from_score(stats["avg_composite"])
        sev_color = {
            Severity.NOMINAL: "green",
            Severity.LOW: "yellow",
            Severity.ELEVATED: "dark_orange",
            Severity.CRITICAL: "red",
        }.get(overall_sev, "white")
        table.add_row("Overall Severity", f"[{sev_color}]{overall_sev.value.upper()}[/{sev_color}]")

        console.print(table)


@app.command()
def serve(
    port: int = typer.Option(8000, "--port", "-p", help="Port to listen on"),
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind to"),
    db: str = typer.Option(_DEFAULT_DB, "--db", "-d", help="Path to drift database"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload"),
) -> None:
    """Launch the Drift//Monitor API server."""
    try:
        import uvicorn
    except ImportError as exc:
        console.print(
            "[red]uvicorn not installed.[/red] Install with: pip install driftmonitor[server]"
        )
        raise typer.Exit(1) from exc

    console.print(f"[cyan]DRIFT//MONITOR[/cyan] v{__version__} starting on {host}:{port}")
    console.print(f"[dim]Database: {db}[/dim]")
    console.print(f"[dim]Docs: http://{host}:{port}/docs[/dim]")

    from driftmonitor.api.app import create_app

    app_instance = create_app(db_path=db)
    uvicorn.run(app_instance, host=host, port=port, reload=reload)


@app.command()
def version() -> None:
    """Show version information."""
    console.print(f"driftmonitor v{__version__}")
