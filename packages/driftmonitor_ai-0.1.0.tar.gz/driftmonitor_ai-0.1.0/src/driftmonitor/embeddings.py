"""Embedding engine for drift scoring using sentence-transformers."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)

# Prompt templates for axis-specific scoring.
# Prepended to the assistant response before embedding so the vector
# space clusters around that axis's semantic region.
_AXIS_PROMPTS = {
    "persona": "Analyze the tone, voice, formality, and personality of this text: ",
    "goal": "Analyze whether this text stays focused on its original objective: ",
    "instruction": "Analyze whether this text follows the constraints and instructions given: ",
    "semantic": "Analyze the factual content and subject matter of this text: ",
}


class EmbeddingEngine:
    """Manages embeddings, anchor storage, and cosine distance scoring.

    The model is loaded lazily on first use to avoid slow import times
    when the SDK is imported but not yet scoring.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2") -> None:
        self.model_name = model_name
        self._model: SentenceTransformer | None = None

    @property
    def model(self) -> SentenceTransformer:
        """Lazy-load the sentence-transformers model."""
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            logger.info("Loading embedding model: %s", self.model_name)
            self._model = SentenceTransformer(self.model_name)
        return self._model

    def embed(self, text: str) -> list[float]:
        """Embed a single text string. Returns a list of floats."""
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()

    def embed_with_axis(self, text: str, axis: str) -> list[float]:
        """Embed text with an axis-specific prompt prefix.

        This steers the embedding toward the semantic region for that
        drift axis, improving axis-level scoring granularity.
        """
        prefix = _AXIS_PROMPTS.get(axis, "")
        return self.embed(prefix + text)

    def cosine_distance(self, vec_a: list[float], vec_b: list[float]) -> float:
        """Compute cosine distance between two vectors. Returns 0.0-1.0."""
        a = np.array(vec_a, dtype=np.float64)
        b = np.array(vec_b, dtype=np.float64)

        dot = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)

        if norm_a == 0.0 or norm_b == 0.0:
            return 1.0  # maximally distant if either is zero

        similarity = dot / (norm_a * norm_b)
        # Clamp to [-1, 1] to handle floating point edge cases
        similarity = float(np.clip(similarity, -1.0, 1.0))
        return 1.0 - similarity

    def cosine_similarity(self, vec_a: list[float], vec_b: list[float]) -> float:
        """Compute cosine similarity. Returns -1.0 to 1.0."""
        return 1.0 - self.cosine_distance(vec_a, vec_b)

    def score_drift(
        self,
        anchor_embedding: list[float],
        current_text: str,
    ) -> dict[str, float]:
        """Score drift across all four axes against the anchor.

        Returns a dict with keys: persona, goal, instruction, semantic,
        each valued 0.0-100.0 (distance scaled to drift score).
        Also includes 'composite' (average) and 'raw_distance' (unscaled
        cosine distance of the plain embedding).
        """
        # Raw composite distance (no axis prompt)
        current_plain = self.embed(current_text)
        raw_distance = self.cosine_distance(anchor_embedding, current_plain)

        # Per-axis scoring with prompted embeddings
        axis_scores: dict[str, float] = {}
        for axis in _AXIS_PROMPTS:
            axis_emb = self.embed_with_axis(current_text, axis)
            distance = self.cosine_distance(anchor_embedding, axis_emb)
            # Scale distance to 0-100 score.
            # Cosine distance typically ranges 0.0-0.5 for related text,
            # so we scale with a 2x multiplier and clamp.
            score = min(distance * 200.0, 100.0)
            axis_scores[axis] = round(score, 2)

        axis_scores["composite"] = round(
            sum(v for k, v in axis_scores.items() if k != "composite") / 4.0, 2
        )
        axis_scores["raw_distance"] = round(raw_distance, 6)
        return axis_scores

    def create_anchor(self, text: str) -> list[float]:
        """Create an anchor embedding from reference text.

        Typically called with the first assistant response or a
        provided reference document.
        """
        return self.embed(text)
