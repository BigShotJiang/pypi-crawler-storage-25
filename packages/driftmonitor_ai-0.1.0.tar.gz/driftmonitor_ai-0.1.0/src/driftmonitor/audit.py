"""Immutable audit log and operational mode management.

Three operational modes give operators graduated control:
- OBSERVE: Log all drift events, no intervention
- ALERT: Notify operator on threshold breach, human decides
- GATE: Block response delivery until operator acknowledges

The audit log is append-only — entries cannot be modified or deleted.
Every drift detection, mode change, gate hold/release, and correction
is recorded with timestamp and attribution.
"""

from __future__ import annotations

import csv
import io
import json
import logging
import sqlite3  # noqa: TC003 (used at runtime)
from datetime import datetime, timezone
from enum import StrEnum

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class OperationMode(StrEnum):
    """Operational modes for drift response."""

    OBSERVE = "observe"
    ALERT = "alert"
    GATE = "gate"


class AuditAction(StrEnum):
    """Types of auditable actions."""

    DRIFT_DETECTED = "drift_detected"
    MODE_CHANGED = "mode_changed"
    GATE_HELD = "gate_held"
    GATE_RELEASED = "gate_released"
    GATE_REJECTED = "gate_rejected"
    CORRECTION_GENERATED = "correction_generated"
    CORRECTION_APPLIED = "correction_applied"
    ALERT_SENT = "alert_sent"
    SESSION_STARTED = "session_started"
    SESSION_ENDED = "session_ended"


class AuditEntry(BaseModel):
    """A single immutable audit log entry."""

    entry_id: int = 0
    session_id: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    action: str
    severity: str = ""
    turn_number: int = -1
    composite_score: float = 0.0
    details: str = ""
    operator: str = ""


class GateDecision(BaseModel):
    """An operator's decision on a gated response."""

    approved: bool
    operator: str = "operator"
    reason: str = ""


_CREATE_AUDIT = """
CREATE TABLE IF NOT EXISTS audit_log (
    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    action TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT '',
    turn_number INTEGER NOT NULL DEFAULT -1,
    composite_score REAL NOT NULL DEFAULT 0.0,
    details TEXT NOT NULL DEFAULT '',
    operator TEXT NOT NULL DEFAULT ''
)
"""

_CREATE_AUDIT_INDEX = """
CREATE INDEX IF NOT EXISTS idx_audit_session
ON audit_log(session_id, timestamp)
"""


class AuditLog:
    """Append-only audit log backed by SQLite.

    Entries cannot be modified or deleted — this is the compliance
    primitive that justifies the enterprise price point.
    """

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn
        self._conn.execute(_CREATE_AUDIT)
        self._conn.execute(_CREATE_AUDIT_INDEX)
        self._conn.commit()

    def append(self, entry: AuditEntry) -> AuditEntry:
        """Append an entry to the audit log. Returns entry with ID."""
        cursor = self._conn.execute(
            "INSERT INTO audit_log "
            "(session_id, timestamp, action, severity, "
            "turn_number, composite_score, details, operator) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                entry.session_id,
                entry.timestamp,
                entry.action,
                entry.severity,
                entry.turn_number,
                entry.composite_score,
                entry.details,
                entry.operator,
            ),
        )
        self._conn.commit()
        entry.entry_id = cursor.lastrowid or 0
        return entry

    def get_entries(
        self,
        session_id: str | None = None,
        action: str | None = None,
        limit: int = 100,
    ) -> list[AuditEntry]:
        """Query audit entries. Filters are optional."""
        query = "SELECT * FROM audit_log WHERE 1=1"
        params: list = []

        if session_id is not None:
            query += " AND session_id = ?"
            params.append(session_id)
        if action is not None:
            query += " AND action = ?"
            params.append(action)

        query += " ORDER BY entry_id DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def count(self, session_id: str | None = None) -> int:
        """Count audit entries."""
        if session_id:
            row = self._conn.execute(
                "SELECT COUNT(*) as cnt FROM audit_log WHERE session_id = ?",
                (session_id,),
            ).fetchone()
        else:
            row = self._conn.execute("SELECT COUNT(*) as cnt FROM audit_log").fetchone()
        return row["cnt"] if row else 0

    def export_json(self, session_id: str | None = None, limit: int = 1000) -> str:
        """Export audit entries as JSON string."""
        entries = self.get_entries(session_id=session_id, limit=limit)
        return json.dumps(
            [e.model_dump() for e in entries],
            indent=2,
        )

    def export_csv(self, session_id: str | None = None, limit: int = 1000) -> str:
        """Export audit entries as CSV string."""
        entries = self.get_entries(session_id=session_id, limit=limit)
        if not entries:
            return ""

        output = io.StringIO()
        fields = list(entries[0].model_dump().keys())
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for entry in entries:
            writer.writerow(entry.model_dump())
        return output.getvalue()

    @staticmethod
    def _row_to_entry(row: sqlite3.Row) -> AuditEntry:
        d = dict(row)
        return AuditEntry(**d)
