"""DriftAwareClient — transparent LLM client wrapper with drift scoring.

Supports Anthropic and OpenAI clients. Provider is auto-detected.
"""

from __future__ import annotations

import logging
from typing import Any

from driftmonitor.audit import AuditAction, AuditEntry, AuditLog, OperationMode
from driftmonitor.embeddings import EmbeddingEngine
from driftmonitor.explainer import DriftExplainer, Explanation
from driftmonitor.models import DriftEvent, DriftScore, SessionConfig, SessionState, Severity
from driftmonitor.providers import (
    create_messages,
    detect_provider,
    extract_text,
    extract_user_text,
)
from driftmonitor.spc import SPCEngine
from driftmonitor.store import DriftStore

logger = logging.getLogger(__name__)


class DriftAwareClient:
    """Drop-in replacement for anthropic.Anthropic that scores drift on every turn.

    Usage:
        import anthropic
        from driftmonitor import DriftAwareClient, SessionConfig

        base = anthropic.Anthropic()
        client = DriftAwareClient(base, config=SessionConfig(name="My Session"))

        # Use exactly like the base client — responses pass through unchanged
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        # Check drift scores
        print(client.state.latest_score)
    """

    def __init__(
        self,
        client: Any,
        config: SessionConfig | None = None,
    ) -> None:
        self.client = client
        self.config = config or SessionConfig()
        self.provider = detect_provider(client)
        self.state = SessionState(config=self.config)
        self._engine = EmbeddingEngine(model_name=self.config.embedding_model)
        self._store = DriftStore(db_path=self.config.db_path)
        self._store.create_session(
            session_id=self.config.session_id,
            name=self.config.name,
            session_type=self.config.session_type,
            embedding_model=self.config.embedding_model,
        )
        self._anchor_embedding: list[float] | None = None
        self._spc = SPCEngine()
        self._explainer = DriftExplainer(client=client)
        self._mode = OperationMode(self.config.mode)
        self._audit = AuditLog(self._store.conn)
        self._gate_pending: DriftEvent | None = None
        self._gate_response: Any = None
        self.messages = _MessagesProxy(self)

        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.SESSION_STARTED,
                details=f"mode={self._mode.value}",
            )
        )

    def _extract_text(self, response: Any) -> str:
        """Extract text content from a provider-specific response."""
        return extract_text(response, self.provider)

    def _ingest(self, messages: list[dict[str, Any]], response: Any) -> DriftEvent:
        """Score drift and store the event. Returns the DriftEvent."""
        assistant_text = self._extract_text(response)
        user_text = extract_user_text(messages)

        # Set anchor on first assistant response
        if self._anchor_embedding is None:
            self._anchor_embedding = self._engine.create_anchor(assistant_text)
            self._store.store_anchor(
                self.config.session_id,
                self._anchor_embedding,
                source_text=assistant_text[:500],
            )
            self.state.anchor_set = True
            logger.info("Anchor set for session %s", self.config.session_id)

        # Score drift
        scores_dict = self._engine.score_drift(self._anchor_embedding, assistant_text)
        raw_distance = scores_dict.pop("raw_distance", 0.0)
        scores_dict.pop("composite", None)

        drift_score = DriftScore(
            persona=scores_dict.get("persona", 0.0),
            goal=scores_dict.get("goal", 0.0),
            instruction=scores_dict.get("instruction", 0.0),
            semantic=scores_dict.get("semantic", 0.0),
        )

        event = DriftEvent(
            session_id=self.config.session_id,
            turn_number=self.state.turn_count,
            scores=drift_score,
            user_content=user_text[:2000],
            assistant_content=assistant_text[:2000],
            anchor_distance=raw_distance,
        )

        # SPC analysis
        spc_result = self._spc.add_score(drift_score)

        self._store.insert_event(event)
        self.state.events.append(event)
        self.state.turn_count += 1

        severity = spc_result.severity
        if severity == Severity.CRITICAL:
            logger.warning(
                "CRITICAL drift detected in session %s turn %d: composite=%.1f",
                self.config.session_id,
                event.turn_number,
                event.composite,
            )
        elif severity == Severity.ELEVATED:
            logger.warning(
                "ELEVATED drift in session %s turn %d: composite=%.1f",
                self.config.session_id,
                event.turn_number,
                event.composite,
            )

        # Audit: drift detected
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.DRIFT_DETECTED,
                severity=severity.value,
                turn_number=event.turn_number,
                composite_score=event.composite,
            )
        )

        # LLM explanation — only when SPC flags anomaly
        if self._explainer.should_explain(spc_result):
            explanation = self._explainer.explain(
                scores=drift_score,
                spc_result=spc_result,
                user_content=user_text,
                assistant_content=assistant_text,
                turn_number=event.turn_number,
            )
            if explanation:
                self._audit.append(
                    AuditEntry(
                        session_id=self.config.session_id,
                        action=AuditAction.CORRECTION_GENERATED,
                        turn_number=event.turn_number,
                        composite_score=event.composite,
                        details=explanation.correction[:500],
                    )
                )

        # Gate mode: flag for hold if severity >= ELEVATED
        if self._mode == OperationMode.GATE and severity in (Severity.ELEVATED, Severity.CRITICAL):
            self._gate_pending = event
            self._audit.append(
                AuditEntry(
                    session_id=self.config.session_id,
                    action=AuditAction.GATE_HELD,
                    severity=severity.value,
                    turn_number=event.turn_number,
                    composite_score=event.composite,
                    details="Response held pending operator review",
                )
            )
            logger.warning(
                "GATE: Response held for session %s turn %d",
                self.config.session_id,
                event.turn_number,
            )

        # Alert mode: log alert
        if self._mode == OperationMode.ALERT and severity in (Severity.ELEVATED, Severity.CRITICAL):
            self._audit.append(
                AuditEntry(
                    session_id=self.config.session_id,
                    action=AuditAction.ALERT_SENT,
                    severity=severity.value,
                    turn_number=event.turn_number,
                    composite_score=event.composite,
                )
            )

        return event

    def set_anchor(self, text: str) -> None:
        """Manually set the anchor embedding from reference text.

        Call this before any messages if you want to anchor against a
        reference document rather than the first assistant response.
        """
        self._anchor_embedding = self._engine.create_anchor(text)
        self._store.store_anchor(
            self.config.session_id,
            self._anchor_embedding,
            source_text=text[:500],
        )
        self.state.anchor_set = True

    @property
    def latest_score(self) -> DriftScore | None:
        """Most recent drift score."""
        return self.state.latest_score

    @property
    def latest_severity(self) -> Severity | None:
        """Most recent severity classification."""
        return self.state.latest_severity

    @property
    def composite_history(self) -> list[float]:
        """List of composite drift scores over time."""
        return self.state.composite_history

    @property
    def spc(self) -> SPCEngine:
        """Access the SPC engine for control limits and trend data."""
        return self._spc

    @property
    def latest_explanation(self) -> Explanation | None:
        """Most recent drift explanation, if any."""
        return self._explainer.latest

    @property
    def explanations(self) -> list[Explanation]:
        """All drift explanations generated this session."""
        return self._explainer.explanations

    @property
    def mode(self) -> OperationMode:
        """Current operational mode."""
        return self._mode

    @property
    def is_gated(self) -> bool:
        """Whether a response is currently held pending operator review."""
        return self._gate_pending is not None

    @property
    def audit(self) -> AuditLog:
        """Access the audit log."""
        return self._audit

    def set_mode(self, mode: OperationMode | str) -> None:
        """Change the operational mode at runtime."""
        new_mode = OperationMode(mode) if isinstance(mode, str) else mode
        old_mode = self._mode
        self._mode = new_mode
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.MODE_CHANGED,
                details=f"{old_mode.value} -> {new_mode.value}",
            )
        )
        logger.info(
            "Mode changed: %s -> %s for session %s",
            old_mode.value,
            new_mode.value,
            self.config.session_id,
        )

    def gate_approve(self, operator: str = "operator", reason: str = "") -> None:
        """Approve a gated response. Clears the hold."""
        if self._gate_pending is None:
            return
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.GATE_RELEASED,
                turn_number=self._gate_pending.turn_number,
                composite_score=self._gate_pending.composite,
                operator=operator,
                details=reason or "Approved",
            )
        )
        self._gate_pending = None

    def gate_reject(self, operator: str = "operator", reason: str = "") -> None:
        """Reject a gated response."""
        if self._gate_pending is None:
            return
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.GATE_REJECTED,
                turn_number=self._gate_pending.turn_number,
                composite_score=self._gate_pending.composite,
                operator=operator,
                details=reason or "Rejected",
            )
        )
        self._gate_pending = None

    def close(self) -> None:
        """Close the drift store connection."""
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.SESSION_ENDED,
            )
        )
        self._store.close()

    def __enter__(self) -> DriftAwareClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class _MessagesProxy:
    """Proxy for client.messages that intercepts create() calls."""

    def __init__(self, drift_client: DriftAwareClient) -> None:
        self._drift_client = drift_client

    def create(self, **kwargs: Any) -> Any:
        """Forward to the base client and score drift.

        All kwargs are passed through unchanged. The response is returned
        unmodified after drift scoring. Works with both Anthropic and OpenAI.
        """
        dc = self._drift_client
        response = create_messages(dc.client, dc.provider, **kwargs)
        messages = kwargs.get("messages", [])
        dc._ingest(messages, response)
        return response

    def __getattr__(self, name: str) -> Any:
        """Forward all other attribute access to the base client's messages."""
        return getattr(self._drift_client.client.messages, name)
