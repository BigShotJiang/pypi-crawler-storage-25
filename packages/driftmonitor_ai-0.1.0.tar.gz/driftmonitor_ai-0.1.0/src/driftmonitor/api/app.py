"""FastAPI application for Drift//Monitor dashboard API."""

from __future__ import annotations

import json
import logging
import typing
from contextlib import asynccontextmanager
from pathlib import Path

if typing.TYPE_CHECKING:
    from collections.abc import AsyncGenerator

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from driftmonitor._version import __version__
from driftmonitor.api.schemas import (
    AuditEntryResponse,
    AuditListResponse,
    DriftScoreResponse,
    EventListResponse,
    EventResponse,
    HealthResponse,
    SessionListResponse,
    SessionResponse,
    SummaryResponse,
)
from driftmonitor.audit import AuditLog
from driftmonitor.models import DriftEvent, Severity
from driftmonitor.store import DriftStore

logger = logging.getLogger(__name__)

_store: DriftStore | None = None
_audit: AuditLog | None = None
_ws_connections: dict[str, list[WebSocket]] = {}


def get_store() -> DriftStore:
    if _store is None:
        raise RuntimeError("Store not initialized")
    return _store


def get_audit() -> AuditLog:
    if _audit is None:
        raise RuntimeError("Audit log not initialized")
    return _audit


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    global _store, _audit
    db_path = Path(app.state.db_path) if hasattr(app.state, "db_path") else Path("driftmonitor.db")
    _store = DriftStore(db_path=db_path)
    _audit = AuditLog(_store.conn)
    logger.info("Drift//Monitor API started, db=%s", db_path)
    yield
    _store.close()
    _store = None
    _audit = None


def create_app(db_path: str = "driftmonitor.db") -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="Drift//Monitor API",
        description="Real-time behavioral drift detection for AI systems",
        version=__version__,
        lifespan=lifespan,
    )
    app.state.db_path = db_path

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(_build_router())
    return app


def _build_router():
    from fastapi import APIRouter

    router = APIRouter()

    @router.get("/health", response_model=HealthResponse)
    def health():
        store = get_store()
        sessions = store.list_sessions()
        return HealthResponse(
            version=__version__,
            sessions=len(sessions),
        )

    @router.get("/sessions", response_model=SessionListResponse)
    def list_sessions():
        store = get_store()
        rows = store.list_sessions()
        sessions = [
            SessionResponse(
                **row,
                event_count=store.count_events(row["session_id"]),
            )
            for row in rows
        ]
        return SessionListResponse(sessions=sessions, total=len(sessions))

    @router.get("/sessions/{session_id}", response_model=SessionResponse)
    def get_session(session_id: str):
        store = get_store()
        row = store.get_session(session_id)
        if not row:
            raise HTTPException(status_code=404, detail="Session not found")
        return SessionResponse(
            **row,
            event_count=store.count_events(session_id),
        )

    @router.delete("/sessions/{session_id}")
    def delete_session(session_id: str):
        store = get_store()
        deleted = store.delete_session(session_id)
        if deleted == 0:
            raise HTTPException(status_code=404, detail="Session not found")
        return {"deleted": True, "session_id": session_id}

    @router.get(
        "/sessions/{session_id}/events",
        response_model=EventListResponse,
    )
    def list_events(
        session_id: str,
        limit: int = Query(default=50, ge=1, le=500),
        severity: str | None = Query(default=None),
    ):
        store = get_store()
        sess = store.get_session(session_id)
        if not sess:
            raise HTTPException(status_code=404, detail="Session not found")

        sev = None
        if severity:
            try:
                sev = Severity(severity.lower())
            except ValueError as exc:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid severity: {severity}",
                ) from exc

        events = store.get_events(session_id, limit=limit, severity=sev)
        return EventListResponse(
            events=[_event_to_response(e) for e in events],
            total=len(events),
            session_id=session_id,
        )

    @router.get(
        "/sessions/{session_id}/latest",
        response_model=EventResponse,
    )
    def latest_event(session_id: str):
        store = get_store()
        sess = store.get_session(session_id)
        if not sess:
            raise HTTPException(status_code=404, detail="Session not found")
        event = store.get_latest_event(session_id)
        if not event:
            raise HTTPException(status_code=404, detail="No events recorded")
        return _event_to_response(event)

    @router.get(
        "/sessions/{session_id}/summary",
        response_model=SummaryResponse,
    )
    def session_summary(session_id: str):
        store = get_store()
        sess = store.get_session(session_id)
        if not sess:
            raise HTTPException(status_code=404, detail="Session not found")
        stats = store.session_summary(session_id)
        if not stats:
            raise HTTPException(status_code=404, detail="No events recorded")
        overall = Severity.from_score(stats["avg_composite"])
        return SummaryResponse(
            session_id=session_id,
            turn_count=stats["turn_count"],
            avg_composite=round(stats["avg_composite"], 2),
            max_composite=round(stats["max_composite"], 2),
            min_composite=round(stats["min_composite"], 2),
            avg_persona=round(stats["avg_persona"], 2),
            avg_goal=round(stats["avg_goal"], 2),
            avg_instruction=round(stats["avg_instruction"], 2),
            avg_semantic=round(stats["avg_semantic"], 2),
            overall_severity=overall.value,
        )

    @router.get("/audit", response_model=AuditListResponse)
    def list_audit(
        session_id: str | None = Query(default=None),
        action: str | None = Query(default=None),
        limit: int = Query(default=100, ge=1, le=1000),
    ):
        audit = get_audit()
        entries = audit.get_entries(session_id=session_id, action=action, limit=limit)
        return AuditListResponse(
            entries=[AuditEntryResponse(**e.model_dump()) for e in entries],
            total=len(entries),
        )

    @router.get("/audit/export/json")
    def export_audit_json(
        session_id: str | None = Query(default=None),
        limit: int = Query(default=1000, ge=1, le=10000),
    ):
        from fastapi.responses import Response

        audit = get_audit()
        data = audit.export_json(session_id=session_id, limit=limit)
        return Response(
            content=data,
            media_type="application/json",
            headers={"Content-Disposition": "attachment; filename=audit.json"},
        )

    @router.get("/audit/export/csv")
    def export_audit_csv(
        session_id: str | None = Query(default=None),
        limit: int = Query(default=1000, ge=1, le=10000),
    ):
        from fastapi.responses import Response

        audit = get_audit()
        data = audit.export_csv(session_id=session_id, limit=limit)
        return Response(
            content=data,
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=audit.csv"},
        )

    @router.websocket("/ws/{session_id}")
    async def websocket_scores(websocket: WebSocket, session_id: str):
        await websocket.accept()
        if session_id not in _ws_connections:
            _ws_connections[session_id] = []
        _ws_connections[session_id].append(websocket)
        logger.info("WebSocket connected for session %s", session_id)
        try:
            while True:
                # Keep connection alive, client can send pings
                await websocket.receive_text()
        except WebSocketDisconnect:
            _ws_connections[session_id].remove(websocket)
            if not _ws_connections[session_id]:
                del _ws_connections[session_id]
            logger.info("WebSocket disconnected for session %s", session_id)

    return router


async def broadcast_event(session_id: str, event: DriftEvent) -> None:
    """Broadcast a drift event to all WebSocket subscribers for a session."""
    connections = _ws_connections.get(session_id, [])
    if not connections:
        return
    payload = json.dumps(
        {
            "type": "drift_event",
            "event": _event_to_response(event).model_dump(),
        }
    )
    dead: list[WebSocket] = []
    for ws in connections:
        try:
            await ws.send_text(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        connections.remove(ws)


def _event_to_response(event: DriftEvent) -> EventResponse:
    """Convert a DriftEvent to an API response."""
    return EventResponse(
        event_id=event.event_id,
        session_id=event.session_id,
        turn_number=event.turn_number,
        timestamp=event.timestamp.isoformat(),
        scores=DriftScoreResponse(
            persona=event.scores.persona,
            goal=event.scores.goal,
            instruction=event.scores.instruction,
            semantic=event.scores.semantic,
            composite=round(event.scores.composite, 2),
            severity=event.scores.severity.value,
        ),
        anchor_distance=event.anchor_distance,
        user_content=event.user_content,
        assistant_content=event.assistant_content,
    )
