"""API response models."""

from __future__ import annotations

from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str
    sessions: int = 0


class SessionResponse(BaseModel):
    session_id: str
    name: str
    session_type: str
    created_at: str
    embedding_model: str
    event_count: int = 0


class SessionListResponse(BaseModel):
    sessions: list[SessionResponse]
    total: int


class DriftScoreResponse(BaseModel):
    persona: float
    goal: float
    instruction: float
    semantic: float
    composite: float
    severity: str


class EventResponse(BaseModel):
    event_id: str
    session_id: str
    turn_number: int
    timestamp: str
    scores: DriftScoreResponse
    anchor_distance: float
    user_content: str
    assistant_content: str


class EventListResponse(BaseModel):
    events: list[EventResponse]
    total: int
    session_id: str


class SummaryResponse(BaseModel):
    session_id: str
    turn_count: int
    avg_composite: float
    max_composite: float
    min_composite: float
    avg_persona: float
    avg_goal: float
    avg_instruction: float
    avg_semantic: float
    overall_severity: str


class ExplanationResponse(BaseModel):
    explanation: str
    correction: str
    dominant_axis: str
    risk_level: str
    turn_number: int


class CorrectionListResponse(BaseModel):
    corrections: list[ExplanationResponse]
    total: int
    session_id: str


class AuditEntryResponse(BaseModel):
    entry_id: int
    session_id: str
    timestamp: str
    action: str
    severity: str
    turn_number: int
    composite_score: float
    details: str
    operator: str


class AuditListResponse(BaseModel):
    entries: list[AuditEntryResponse]
    total: int
