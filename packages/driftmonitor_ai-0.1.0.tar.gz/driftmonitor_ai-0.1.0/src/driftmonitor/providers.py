"""Provider abstraction for multi-LLM support.

Detects whether the wrapped client is Anthropic or OpenAI and routes
method calls accordingly. Text extraction is provider-aware.
"""

from __future__ import annotations

import logging
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class ProviderType(StrEnum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    UNKNOWN = "unknown"


def detect_provider(client: Any) -> ProviderType:
    """Detect the LLM provider from the client object."""
    cls_name = type(client).__name__
    mod = type(client).__module__ or ""

    if "anthropic" in mod.lower() or cls_name in ("Anthropic", "AsyncAnthropic"):
        return ProviderType.ANTHROPIC
    if "openai" in mod.lower() or cls_name in ("OpenAI", "AsyncOpenAI"):
        return ProviderType.OPENAI
    return ProviderType.UNKNOWN


def extract_text(response: Any, provider: ProviderType) -> str:
    """Extract assistant text from a provider-specific response."""
    if provider == ProviderType.ANTHROPIC:
        return _extract_anthropic(response)
    if provider == ProviderType.OPENAI:
        return _extract_openai(response)
    return _extract_generic(response)


def create_messages(client: Any, provider: ProviderType, **kwargs: Any) -> Any:
    """Route a create call to the correct provider method."""
    if provider == ProviderType.ANTHROPIC:
        return client.messages.create(**kwargs)
    if provider == ProviderType.OPENAI:
        return _openai_create(client, **kwargs)
    return client.messages.create(**kwargs)


async def acreate_messages(client: Any, provider: ProviderType, **kwargs: Any) -> Any:
    """Async version of create_messages."""
    if provider == ProviderType.ANTHROPIC:
        return await client.messages.create(**kwargs)
    if provider == ProviderType.OPENAI:
        return await _openai_acreate(client, **kwargs)
    return await client.messages.create(**kwargs)


def extract_user_text(messages: list[dict[str, Any]]) -> str:
    """Extract the last user message content from a message list."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            return content if isinstance(content, str) else str(content)
    return ""


# --- Anthropic ---


def _extract_anthropic(response: Any) -> str:
    if hasattr(response, "content"):
        parts = []
        for block in response.content:
            if hasattr(block, "text"):
                parts.append(block.text)
        return "\n".join(parts)
    return str(response)


# --- OpenAI ---


def _openai_create(client: Any, **kwargs: Any) -> Any:
    """Translate Anthropic-style kwargs to OpenAI format and call."""
    oai_kwargs = _translate_kwargs(kwargs)
    return client.chat.completions.create(**oai_kwargs)


async def _openai_acreate(client: Any, **kwargs: Any) -> Any:
    oai_kwargs = _translate_kwargs(kwargs)
    return await client.chat.completions.create(**oai_kwargs)


def _translate_kwargs(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Translate Anthropic-style create kwargs to OpenAI format.

    Anthropic: model, max_tokens, system, messages
    OpenAI:    model, max_tokens, messages (system is a message)
    """
    oai = dict(kwargs)

    # Anthropic puts system as a separate param; OpenAI uses a system message
    system = oai.pop("system", None)
    messages = list(oai.get("messages", []))
    if system and not any(m.get("role") == "system" for m in messages):
        messages.insert(0, {"role": "system", "content": system})
    oai["messages"] = messages

    # max_tokens → max_tokens (same name, but Anthropic requires it)
    # OpenAI defaults to inf, so we pass it through if present
    return oai


def _extract_openai(response: Any) -> str:
    if hasattr(response, "choices") and response.choices:
        choice = response.choices[0]
        if hasattr(choice, "message") and hasattr(choice.message, "content"):
            return choice.message.content or ""
    return str(response)


# --- Generic fallback ---


def _extract_generic(response: Any) -> str:
    # Try Anthropic-style first, then OpenAI-style
    text = _extract_anthropic(response)
    if text != str(response):
        return text
    text = _extract_openai(response)
    if text != str(response):
        return text
    return str(response)
