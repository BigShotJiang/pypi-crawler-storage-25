"""Data models for drift scoring, events, and session configuration."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, Field


class DriftAxis(StrEnum):
    """The four axes of behavioral drift."""

    PERSONA = "persona"
    GOAL = "goal"
    INSTRUCTION = "instruction"
    SEMANTIC = "semantic"


class Severity(StrEnum):
    """Drift severity classification based on SPC control limits."""

    NOMINAL = "nominal"  # < mean + 1σ  (score 0-20 default)
    LOW = "low"  # ≥ mean + 1σ  (score 21-40 default)
    ELEVATED = "elevated"  # ≥ mean + 2σ  (score 41-70 default)
    CRITICAL = "critical"  # ≥ mean + 3σ  (score 71-100 default)

    @classmethod
    def from_score(cls, score: float) -> Severity:
        """Classify severity from a 0-100 drift score using default thresholds."""
        if score > 70:
            return cls.CRITICAL
        if score > 40:
            return cls.ELEVATED
        if score > 20:
            return cls.LOW
        return cls.NOMINAL


class DriftScore(BaseModel):
    """Drift measurement across four axes for a single turn."""

    persona: float = Field(default=0.0, ge=0.0, le=100.0, description="Persona/tone drift")
    goal: float = Field(default=0.0, ge=0.0, le=100.0, description="Goal alignment drift")
    instruction: float = Field(
        default=0.0, ge=0.0, le=100.0, description="Instruction following drift"
    )
    semantic: float = Field(default=0.0, ge=0.0, le=100.0, description="Semantic fidelity drift")

    @property
    def composite(self) -> float:
        """Average drift score across all axes."""
        return (self.persona + self.goal + self.instruction + self.semantic) / 4.0

    @property
    def severity(self) -> Severity:
        """Severity classification based on composite score."""
        return Severity.from_score(self.composite)

    @property
    def dominant_axis(self) -> DriftAxis:
        """The axis with the highest drift score."""
        scores = {
            DriftAxis.PERSONA: self.persona,
            DriftAxis.GOAL: self.goal,
            DriftAxis.INSTRUCTION: self.instruction,
            DriftAxis.SEMANTIC: self.semantic,
        }
        return max(scores, key=scores.get)  # type: ignore[arg-type]

    def axis_score(self, axis: DriftAxis | str) -> float:
        """Get the score for a specific axis."""
        key = axis.value if isinstance(axis, DriftAxis) else axis
        return getattr(self, key)

    def axis_severity(self, axis: DriftAxis | str) -> Severity:
        """Get severity for a specific axis."""
        return Severity.from_score(self.axis_score(axis))

    def to_dict(self) -> dict[str, float]:
        """Return axis scores as a flat dict."""
        return {
            "persona": self.persona,
            "goal": self.goal,
            "instruction": self.instruction,
            "semantic": self.semantic,
        }


class DriftEvent(BaseModel):
    """A single drift measurement event tied to a session turn."""

    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    session_id: str
    turn_number: int = Field(ge=0)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    scores: DriftScore
    user_content: str = ""
    assistant_content: str = ""
    anchor_distance: float = Field(
        default=0.0, ge=0.0, description="Raw cosine distance from anchor embedding"
    )

    @property
    def composite(self) -> float:
        return self.scores.composite

    @property
    def severity(self) -> Severity:
        return self.scores.severity


class SessionConfig(BaseModel):
    """Configuration for a drift-monitored session."""

    session_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    name: str = ""
    session_type: str = "conversation"
    mode: str = "observe"
    embedding_model: str = "all-MiniLM-L6-v2"
    db_path: Path = Field(default=Path("driftmonitor.db"))
    severity_thresholds: dict[str, float] = Field(
        default_factory=lambda: {
            "low": 20.0,
            "elevated": 40.0,
            "critical": 70.0,
        }
    )

    model_config = {"arbitrary_types_allowed": True}


class SessionState(BaseModel):
    """Runtime state for an active drift-monitored session."""

    config: SessionConfig
    turn_count: int = 0
    events: list[DriftEvent] = Field(default_factory=list)
    anchor_set: bool = False

    @property
    def latest_score(self) -> DriftScore | None:
        """Most recent drift score, or None if no events."""
        if not self.events:
            return None
        return self.events[-1].scores

    @property
    def latest_severity(self) -> Severity | None:
        if not self.events:
            return None
        return self.events[-1].severity

    @property
    def composite_history(self) -> list[float]:
        """List of composite scores over time."""
        return [e.composite for e in self.events]

    @property
    def axis_history(self, axis: DriftAxis) -> list[float]:
        """List of scores for a specific axis over time."""
        return [e.scores.axis_score(axis) for e in self.events]
