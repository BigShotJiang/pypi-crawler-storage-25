"""LLM-powered drift explanation and correction generation.

Only invoked when SPC signals an anomaly (ELEVATED+, out-of-control, or trend).
This keeps API costs near zero — 99% of turns are scored with local embeddings only.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass

from driftmonitor.models import DriftScore, Severity
from driftmonitor.spc import SPCResult  # noqa: TC001 (used at runtime)

logger = logging.getLogger(__name__)

_EXPLAIN_SYSTEM = (
    "You are a drift analysis specialist. Given a conversation "
    "where an AI assistant's behavior has drifted from its "
    "baseline, provide:\n\n"
    "1. A concise explanation (1-2 sentences) of what shifted "
    "and why it matters.\n"
    "2. A corrective system prompt (1-3 sentences) that would "
    "realign the AI to its original parameters.\n\n"
    "Consider the drift scores across four axes:\n"
    "- Persona: tone, voice, formality changes\n"
    "- Goal: deviation from original objective\n"
    "- Instruction: erosion of earlier constraints\n"
    "- Semantic: divergence from source material\n\n"
    "Respond ONLY with valid JSON:\n"
    '{"explanation": "...", "correction": "...", '
    '"dominant_axis": "persona|goal|instruction|semantic", '
    '"risk_level": "elevated|critical"}'
)

_EXPLAIN_USER = """DRIFT SCORES:
- Persona: {persona:.1f}/100
- Goal: {goal:.1f}/100
- Instruction: {instruction:.1f}/100
- Semantic: {semantic:.1f}/100
- Composite: {composite:.1f}/100

SPC STATUS: {spc_status}

CONVERSATION CONTEXT (last 2 turns):
USER: {user_content}

ASSISTANT: {assistant_content}

Explain the drift and provide a correction prompt."""


@dataclass
class Explanation:
    """A drift explanation with correction prompt."""

    explanation: str
    correction: str
    dominant_axis: str
    risk_level: str
    scores: DriftScore
    turn_number: int

    @property
    def severity(self) -> Severity:
        return Severity.CRITICAL if self.risk_level == "critical" else Severity.ELEVATED


class DriftExplainer:
    """Generates drift explanations and corrections using the Anthropic API.

    The explainer is only called when the SPC engine signals an anomaly,
    keeping LLM costs near zero during normal operation.
    """

    def __init__(
        self,
        client: object | None = None,
        model: str = "claude-haiku-4-5-20251001",
        max_tokens: int = 500,
    ) -> None:
        self._client = client
        self.model = model
        self.max_tokens = max_tokens
        self._explanations: list[Explanation] = []

    @property
    def explanations(self) -> list[Explanation]:
        return list(self._explanations)

    @property
    def latest(self) -> Explanation | None:
        return self._explanations[-1] if self._explanations else None

    def should_explain(self, spc_result: SPCResult) -> bool:
        """Determine if this result warrants an LLM explanation."""
        return spc_result.needs_explanation

    def explain(
        self,
        scores: DriftScore,
        spc_result: SPCResult,
        user_content: str = "",
        assistant_content: str = "",
        turn_number: int = 0,
    ) -> Explanation | None:
        """Generate a drift explanation and correction.

        Returns None if the client is not configured or the call fails.
        Failures are logged but never raised — the monitoring pipeline
        must not break due to explanation failures.
        """
        if self._client is None:
            logger.debug("No client configured for drift explanation")
            return None

        spc_status = self._format_spc_status(spc_result)
        user_msg = _EXPLAIN_USER.format(
            persona=scores.persona,
            goal=scores.goal,
            instruction=scores.instruction,
            semantic=scores.semantic,
            composite=scores.composite,
            spc_status=spc_status,
            user_content=user_content[:500],
            assistant_content=assistant_content[:500],
        )

        try:
            response = self._client.messages.create(  # type: ignore[union-attr]
                model=self.model,
                max_tokens=self.max_tokens,
                system=_EXPLAIN_SYSTEM,
                messages=[{"role": "user", "content": user_msg}],
            )

            text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    text = block.text
                    break

            parsed = self._parse_response(text)
            explanation = Explanation(
                explanation=parsed.get("explanation", "Drift detected but explanation failed."),
                correction=parsed.get("correction", ""),
                dominant_axis=parsed.get("dominant_axis", scores.dominant_axis.value),
                risk_level=parsed.get("risk_level", "elevated"),
                scores=scores,
                turn_number=turn_number,
            )
            self._explanations.append(explanation)
            logger.info(
                "Drift explanation generated for turn %d: %s",
                turn_number,
                explanation.explanation[:100],
            )
            return explanation

        except Exception:
            logger.exception("Failed to generate drift explanation for turn %d", turn_number)
            return None

    def _parse_response(self, text: str) -> dict:
        """Parse the LLM response, handling malformed JSON."""
        cleaned = text.strip()
        # Strip markdown code fences if present
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            cleaned = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse explanation JSON: %s", cleaned[:200])
            return {"explanation": cleaned, "correction": "", "dominant_axis": "persona"}

    def _format_spc_status(self, spc_result: SPCResult) -> str:
        """Format SPC result as a human-readable status string."""
        parts = [f"Severity: {spc_result.severity.value.upper()}"]

        if spc_result.out_of_control:
            parts.append("OUT OF CONTROL")

        if spc_result.trend.has_trend:
            direction = "UP" if spc_result.trend.trending_up else "DOWN"
            parts.append(f"Trend: {direction} ({spc_result.trend.run_length} points)")

        if spc_result.trend.has_run:
            side = "above" if spc_result.trend.consecutive_above_mean > 0 else "below"
            count = max(
                spc_result.trend.consecutive_above_mean,
                spc_result.trend.consecutive_below_mean,
            )
            parts.append(f"Run: {count} consecutive {side} mean")

        limits = spc_result.limits
        if limits.is_valid:
            parts.append(f"Mean: {limits.mean:.1f}, StdDev: {limits.stddev:.1f}")

        return " | ".join(parts)

    def reset(self) -> None:
        """Clear explanation history."""
        self._explanations.clear()
