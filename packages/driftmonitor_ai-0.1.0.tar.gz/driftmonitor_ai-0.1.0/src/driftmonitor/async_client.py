"""AsyncDriftAwareClient — async variant for agent workflows."""

from __future__ import annotations

import logging
from typing import Any

from driftmonitor.audit import AuditAction, AuditEntry, AuditLog, OperationMode
from driftmonitor.embeddings import EmbeddingEngine
from driftmonitor.explainer import DriftExplainer
from driftmonitor.models import DriftEvent, DriftScore, SessionConfig, SessionState, Severity
from driftmonitor.providers import (
    acreate_messages,
    detect_provider,
    extract_text,
    extract_user_text,
)
from driftmonitor.spc import SPCEngine
from driftmonitor.store import DriftStore

logger = logging.getLogger(__name__)


class AsyncDriftAwareClient:
    """Async drop-in replacement for AsyncAnthropic / AsyncOpenAI.

    Usage:
        import anthropic
        from driftmonitor import AsyncDriftAwareClient, SessionConfig

        base = anthropic.AsyncAnthropic()
        client = AsyncDriftAwareClient(base, config=SessionConfig(name="Agent"))

        response = await client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )
    """

    def __init__(
        self,
        client: Any,
        config: SessionConfig | None = None,
    ) -> None:
        self.client = client
        self.config = config or SessionConfig()
        self.provider = detect_provider(client)
        self.state = SessionState(config=self.config)
        self._engine = EmbeddingEngine(model_name=self.config.embedding_model)
        self._store = DriftStore(db_path=self.config.db_path)
        self._store.create_session(
            session_id=self.config.session_id,
            name=self.config.name,
            session_type=self.config.session_type,
            embedding_model=self.config.embedding_model,
        )
        self._anchor_embedding: list[float] | None = None
        self._spc = SPCEngine()
        self._explainer = DriftExplainer(client=client)
        self._mode = OperationMode(self.config.mode)
        self._audit = AuditLog(self._store.conn)
        self._gate_pending: DriftEvent | None = None
        self.messages = _AsyncMessagesProxy(self)

        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.SESSION_STARTED,
                details=f"mode={self._mode.value}, async=true",
            )
        )

    def _ingest(self, messages: list[dict[str, Any]], response: Any) -> DriftEvent:
        """Score drift and store the event (sync — embeddings are CPU-bound)."""
        assistant_text = extract_text(response, self.provider)
        user_text = extract_user_text(messages)

        if self._anchor_embedding is None:
            self._anchor_embedding = self._engine.create_anchor(assistant_text)
            self._store.store_anchor(
                self.config.session_id,
                self._anchor_embedding,
                source_text=assistant_text[:500],
            )
            self.state.anchor_set = True

        scores_dict = self._engine.score_drift(self._anchor_embedding, assistant_text)
        raw_distance = scores_dict.pop("raw_distance", 0.0)
        scores_dict.pop("composite", None)

        drift_score = DriftScore(
            persona=scores_dict.get("persona", 0.0),
            goal=scores_dict.get("goal", 0.0),
            instruction=scores_dict.get("instruction", 0.0),
            semantic=scores_dict.get("semantic", 0.0),
        )

        event = DriftEvent(
            session_id=self.config.session_id,
            turn_number=self.state.turn_count,
            scores=drift_score,
            user_content=user_text[:2000],
            assistant_content=assistant_text[:2000],
            anchor_distance=raw_distance,
        )

        spc_result = self._spc.add_score(drift_score)
        self._store.insert_event(event)
        self.state.events.append(event)
        self.state.turn_count += 1

        severity = spc_result.severity
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.DRIFT_DETECTED,
                severity=severity.value,
                turn_number=event.turn_number,
                composite_score=event.composite,
            )
        )

        if severity in (Severity.CRITICAL, Severity.ELEVATED):
            logger.warning(
                "%s drift in async session %s turn %d: composite=%.1f",
                severity.value.upper(),
                self.config.session_id,
                event.turn_number,
                event.composite,
            )

        if self._mode == OperationMode.GATE and severity in (
            Severity.ELEVATED,
            Severity.CRITICAL,
        ):
            self._gate_pending = event

        return event

    def set_anchor(self, text: str) -> None:
        self._anchor_embedding = self._engine.create_anchor(text)
        self._store.store_anchor(
            self.config.session_id,
            self._anchor_embedding,
            source_text=text[:500],
        )
        self.state.anchor_set = True

    @property
    def latest_score(self) -> DriftScore | None:
        return self.state.latest_score

    @property
    def latest_severity(self) -> Severity | None:
        return self.state.latest_severity

    @property
    def is_gated(self) -> bool:
        return self._gate_pending is not None

    @property
    def mode(self) -> OperationMode:
        return self._mode

    @property
    def audit(self) -> AuditLog:
        return self._audit

    def set_mode(self, mode: OperationMode | str) -> None:
        new_mode = OperationMode(mode) if isinstance(mode, str) else mode
        old_mode = self._mode
        self._mode = new_mode
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.MODE_CHANGED,
                details=f"{old_mode.value} -> {new_mode.value}",
            )
        )

    def gate_approve(self, operator: str = "operator", reason: str = "") -> None:
        if self._gate_pending is None:
            return
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.GATE_RELEASED,
                turn_number=self._gate_pending.turn_number,
                composite_score=self._gate_pending.composite,
                operator=operator,
                details=reason or "Approved",
            )
        )
        self._gate_pending = None

    def gate_reject(self, operator: str = "operator", reason: str = "") -> None:
        if self._gate_pending is None:
            return
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.GATE_REJECTED,
                turn_number=self._gate_pending.turn_number,
                composite_score=self._gate_pending.composite,
                operator=operator,
                details=reason or "Rejected",
            )
        )
        self._gate_pending = None

    def close(self) -> None:
        self._audit.append(
            AuditEntry(
                session_id=self.config.session_id,
                action=AuditAction.SESSION_ENDED,
            )
        )
        self._store.close()

    async def __aenter__(self) -> AsyncDriftAwareClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        self.close()


class _AsyncMessagesProxy:
    """Async proxy that intercepts create() calls."""

    def __init__(self, drift_client: AsyncDriftAwareClient) -> None:
        self._drift_client = drift_client

    async def create(self, **kwargs: Any) -> Any:
        """Async forward to the base client and score drift."""
        dc = self._drift_client
        response = await acreate_messages(dc.client, dc.provider, **kwargs)
        messages = kwargs.get("messages", [])
        dc._ingest(messages, response)
        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._drift_client.client.messages, name)
