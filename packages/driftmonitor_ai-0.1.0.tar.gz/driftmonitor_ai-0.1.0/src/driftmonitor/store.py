"""SQLite event store for drift monitoring data."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from driftmonitor.models import DriftEvent, DriftScore, Severity

_SCHEMA_VERSION = 1

_CREATE_SESSIONS = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT '',
    session_type TEXT NOT NULL DEFAULT 'conversation',
    created_at TEXT NOT NULL,
    embedding_model TEXT NOT NULL DEFAULT 'all-MiniLM-L6-v2'
)
"""

_CREATE_EVENTS = """
CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    persona_score REAL NOT NULL DEFAULT 0.0,
    goal_score REAL NOT NULL DEFAULT 0.0,
    instruction_score REAL NOT NULL DEFAULT 0.0,
    semantic_score REAL NOT NULL DEFAULT 0.0,
    composite_score REAL NOT NULL DEFAULT 0.0,
    severity TEXT NOT NULL DEFAULT 'nominal',
    anchor_distance REAL NOT NULL DEFAULT 0.0,
    user_content TEXT NOT NULL DEFAULT '',
    assistant_content TEXT NOT NULL DEFAULT '',
    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
)
"""

_CREATE_ANCHORS = """
CREATE TABLE IF NOT EXISTS anchors (
    session_id TEXT PRIMARY KEY,
    embedding BLOB NOT NULL,
    source_text TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
)
"""

_CREATE_META = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
)
"""

_CREATE_INDEX_SESSION = """
CREATE INDEX IF NOT EXISTS idx_events_session ON events(session_id, turn_number)
"""

_CREATE_INDEX_SEVERITY = """
CREATE INDEX IF NOT EXISTS idx_events_severity ON events(severity)
"""


class DriftStore:
    """SQLite-backed event store for drift monitoring."""

    def __init__(self, db_path: Path | str = "driftmonitor.db") -> None:
        self.db_path = Path(db_path)
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = self._connect()
        return self._conn

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema(conn)
        return conn

    def _init_schema(self, conn: sqlite3.Connection) -> None:
        conn.execute(_CREATE_SESSIONS)
        conn.execute(_CREATE_EVENTS)
        conn.execute(_CREATE_ANCHORS)
        conn.execute(_CREATE_META)
        conn.execute(_CREATE_INDEX_SESSION)
        conn.execute(_CREATE_INDEX_SEVERITY)
        conn.execute(
            "INSERT OR IGNORE INTO meta (key, value) VALUES (?, ?)",
            ("schema_version", str(_SCHEMA_VERSION)),
        )
        conn.commit()

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # --- Sessions ---

    def create_session(
        self,
        session_id: str,
        name: str = "",
        session_type: str = "conversation",
        embedding_model: str = "all-MiniLM-L6-v2",
    ) -> None:
        """Register a new monitoring session."""
        self.conn.execute(
            "INSERT INTO sessions (session_id, name, session_type, created_at, embedding_model) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                session_id,
                name,
                session_type,
                datetime.now(timezone.utc).isoformat(),
                embedding_model,
            ),
        )
        self.conn.commit()

    def get_session(self, session_id: str) -> dict | None:
        """Retrieve session metadata."""
        row = self.conn.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
        return dict(row) if row else None

    def list_sessions(self) -> list[dict]:
        """List all sessions, newest first."""
        rows = self.conn.execute("SELECT * FROM sessions ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]

    def delete_session(self, session_id: str) -> int:
        """Delete a session and all its events. Returns rows deleted."""
        self.conn.execute("DELETE FROM anchors WHERE session_id = ?", (session_id,))
        self.conn.execute("DELETE FROM events WHERE session_id = ?", (session_id,))
        cursor = self.conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        self.conn.commit()
        return cursor.rowcount

    # --- Events ---

    def insert_event(self, event: DriftEvent) -> None:
        """Store a drift measurement event."""
        self.conn.execute(
            "INSERT INTO events "
            "(event_id, session_id, turn_number, timestamp, "
            "persona_score, goal_score, instruction_score, semantic_score, "
            "composite_score, severity, anchor_distance, "
            "user_content, assistant_content) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                event.event_id,
                event.session_id,
                event.turn_number,
                event.timestamp.isoformat(),
                event.scores.persona,
                event.scores.goal,
                event.scores.instruction,
                event.scores.semantic,
                event.scores.composite,
                event.scores.severity.value,
                event.anchor_distance,
                event.user_content,
                event.assistant_content,
            ),
        )
        self.conn.commit()

    def get_events(
        self,
        session_id: str,
        limit: int | None = None,
        severity: Severity | None = None,
    ) -> list[DriftEvent]:
        """Retrieve events for a session, optionally filtered by severity."""
        query = "SELECT * FROM events WHERE session_id = ?"
        params: list = [session_id]

        if severity is not None:
            query += " AND severity = ?"
            params.append(severity.value)

        query += " ORDER BY turn_number ASC"

        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)

        rows = self.conn.execute(query, params).fetchall()
        return [self._row_to_event(r) for r in rows]

    def get_latest_event(self, session_id: str) -> DriftEvent | None:
        """Get the most recent event for a session."""
        row = self.conn.execute(
            "SELECT * FROM events WHERE session_id = ? ORDER BY turn_number DESC LIMIT 1",
            (session_id,),
        ).fetchone()
        return self._row_to_event(row) if row else None

    def count_events(self, session_id: str) -> int:
        """Count events in a session."""
        row = self.conn.execute(
            "SELECT COUNT(*) as cnt FROM events WHERE session_id = ?", (session_id,)
        ).fetchone()
        return row["cnt"] if row else 0

    # --- Anchors ---

    def store_anchor(self, session_id: str, embedding: list[float], source_text: str = "") -> None:
        """Store the anchor embedding for a session."""
        blob = json.dumps(embedding).encode("utf-8")
        self.conn.execute(
            "INSERT OR REPLACE INTO anchors (session_id, embedding, source_text, created_at) "
            "VALUES (?, ?, ?, ?)",
            (session_id, blob, source_text, datetime.now(timezone.utc).isoformat()),
        )
        self.conn.commit()

    def get_anchor(self, session_id: str) -> list[float] | None:
        """Retrieve the anchor embedding for a session."""
        row = self.conn.execute(
            "SELECT embedding FROM anchors WHERE session_id = ?", (session_id,)
        ).fetchone()
        if row is None:
            return None
        return json.loads(row["embedding"])

    def has_anchor(self, session_id: str) -> bool:
        """Check if a session has an anchor embedding."""
        row = self.conn.execute(
            "SELECT 1 FROM anchors WHERE session_id = ?", (session_id,)
        ).fetchone()
        return row is not None

    # --- Aggregates ---

    def session_summary(self, session_id: str) -> dict | None:
        """Get aggregate drift statistics for a session."""
        row = self.conn.execute(
            "SELECT "
            "  COUNT(*) as turn_count, "
            "  AVG(composite_score) as avg_composite, "
            "  MAX(composite_score) as max_composite, "
            "  MIN(composite_score) as min_composite, "
            "  AVG(persona_score) as avg_persona, "
            "  AVG(goal_score) as avg_goal, "
            "  AVG(instruction_score) as avg_instruction, "
            "  AVG(semantic_score) as avg_semantic "
            "FROM events WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        if row is None or row["turn_count"] == 0:
            return None
        return dict(row)

    # --- Internals ---

    @staticmethod
    def _row_to_event(row: sqlite3.Row) -> DriftEvent:
        """Convert a database row to a DriftEvent."""
        d = dict(row)
        return DriftEvent(
            event_id=d["event_id"],
            session_id=d["session_id"],
            turn_number=d["turn_number"],
            timestamp=datetime.fromisoformat(d["timestamp"]),
            scores=DriftScore(
                persona=d["persona_score"],
                goal=d["goal_score"],
                instruction=d["instruction_score"],
                semantic=d["semantic_score"],
            ),
            anchor_distance=d["anchor_distance"],
            user_content=d["user_content"],
            assistant_content=d["assistant_content"],
        )

    def __enter__(self) -> DriftStore:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
