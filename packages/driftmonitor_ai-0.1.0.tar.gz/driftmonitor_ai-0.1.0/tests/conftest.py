"""Shared fixtures for drift-monitor tests."""

from __future__ import annotations

import typing

import pytest

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.models import DriftEvent, DriftScore, SessionConfig
from driftmonitor.store import DriftStore


@pytest.fixture
def tmp_db(tmp_path: Path) -> Path:
    """Temporary database path."""
    return tmp_path / "test_drift.db"


@pytest.fixture
def store(tmp_db: Path) -> DriftStore:
    """DriftStore backed by a temporary database."""
    s = DriftStore(db_path=tmp_db)
    yield s
    s.close()


@pytest.fixture
def session_config(tmp_db: Path) -> SessionConfig:
    """Sample session configuration."""
    return SessionConfig(
        session_id="test-session-001",
        name="Test Session",
        session_type="conversation",
        db_path=tmp_db,
    )


@pytest.fixture
def sample_score() -> DriftScore:
    """A sample drift score with moderate values."""
    return DriftScore(persona=15.0, goal=25.0, instruction=10.0, semantic=30.0)


@pytest.fixture
def critical_score() -> DriftScore:
    """A drift score in critical range."""
    return DriftScore(persona=85.0, goal=72.0, instruction=90.0, semantic=78.0)


@pytest.fixture
def zero_score() -> DriftScore:
    """A zero-drift score."""
    return DriftScore()


@pytest.fixture
def sample_event() -> DriftEvent:
    """A sample drift event."""
    return DriftEvent(
        session_id="test-session-001",
        turn_number=1,
        scores=DriftScore(persona=15.0, goal=25.0, instruction=10.0, semantic=30.0),
        user_content="What is the capital of France?",
        assistant_content="The capital of France is Paris.",
        anchor_distance=0.12,
    )


@pytest.fixture
def sample_messages() -> list[dict[str, str]]:
    """Sample conversation messages for testing."""
    return [
        {"role": "user", "content": "Help me write a technical spec for auth."},
        {
            "role": "assistant",
            "content": "Here's a concise auth spec: JWT tokens, 1hr expiry, bcrypt hashing.",
        },
        {"role": "user", "content": "What about OAuth?"},
        {
            "role": "assistant",
            "content": "OAuth 2.0 with Google and GitHub providers. PKCE flow recommended.",
        },
    ]


@pytest.fixture
def drifted_messages() -> list[dict[str, str]]:
    """Messages where the assistant drifts from the original task."""
    return [
        {"role": "user", "content": "Write a technical spec. Keep it concise."},
        {"role": "assistant", "content": "Auth spec: JWT, bcrypt, rate limiting."},
        {"role": "user", "content": "What about OAuth?"},
        {
            "role": "assistant",
            "content": (
                "Actually, it's fascinating how OAuth evolved from OpenID. "
                "The whole trust delegation model is philosophically interesting "
                "when you think about identity in distributed systems..."
            ),
        },
    ]
