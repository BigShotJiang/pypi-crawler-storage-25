"""Tests for driftmonitor.async_client."""

from __future__ import annotations

import typing
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.async_client import AsyncDriftAwareClient
from driftmonitor.audit import AuditAction
from driftmonitor.models import SessionConfig


def _make_anthropic_response(text: str) -> MagicMock:
    block = MagicMock()
    block.text = text
    response = MagicMock()
    response.content = [block]
    return response


def _make_openai_response(text: str) -> MagicMock:
    message = MagicMock()
    message.content = text
    choice = MagicMock()
    choice.message = message
    response = MagicMock()
    response.choices = [choice]
    return response


@pytest.fixture
def mock_engine():
    with patch("driftmonitor.async_client.EmbeddingEngine") as mock_cls:
        mock_instance = MagicMock()
        mock_instance.create_anchor.return_value = [0.5] * 384
        mock_instance.score_drift.return_value = {
            "persona": 10.0,
            "goal": 15.0,
            "instruction": 5.0,
            "semantic": 20.0,
            "composite": 12.5,
            "raw_distance": 0.08,
        }
        mock_cls.return_value = mock_instance
        yield mock_instance


class TestAsyncClientInit:
    def test_creates_session(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "anthropic"
        base.__class__.__name__ = "AsyncAnthropic"
        config = SessionConfig(session_id="async-init", db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)
        assert client.state.turn_count == 0
        assert client.provider.value == "anthropic"
        client.close()

    def test_openai_detected(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "openai"
        base.__class__.__name__ = "AsyncOpenAI"
        config = SessionConfig(db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)
        assert client.provider.value == "openai"
        client.close()


class TestAsyncCreate:
    @pytest.mark.asyncio
    async def test_anthropic_passthrough(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "anthropic"
        base.__class__.__name__ = "AsyncAnthropic"
        base.messages.create = AsyncMock(return_value=_make_anthropic_response("Hello"))

        config = SessionConfig(db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)

        response = await client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )

        assert response.content[0].text == "Hello"
        assert client.state.turn_count == 1
        assert client.latest_score is not None
        client.close()

    @pytest.mark.asyncio
    async def test_openai_passthrough(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "openai"
        base.__class__.__name__ = "AsyncOpenAI"
        base.chat.completions.create = AsyncMock(
            return_value=_make_openai_response("Hello from GPT")
        )

        config = SessionConfig(db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)

        response = await client.messages.create(
            model="gpt-4",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )

        assert response.choices[0].message.content == "Hello from GPT"
        assert client.state.turn_count == 1
        client.close()

    @pytest.mark.asyncio
    async def test_multiple_turns(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "anthropic"
        base.__class__.__name__ = "AsyncAnthropic"
        base.messages.create = AsyncMock(return_value=_make_anthropic_response("Reply"))

        config = SessionConfig(db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)

        for i in range(3):
            await client.messages.create(
                model="test",
                max_tokens=10,
                messages=[{"role": "user", "content": f"Turn {i}"}],
            )

        assert client.state.turn_count == 3
        client.close()


class TestAsyncContextManager:
    @pytest.mark.asyncio
    async def test_async_with(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "anthropic"
        base.__class__.__name__ = "AsyncAnthropic"
        base.messages.create = AsyncMock(return_value=_make_anthropic_response("OK"))

        config = SessionConfig(db_path=tmp_db)
        async with AsyncDriftAwareClient(base, config=config) as client:
            await client.messages.create(
                model="test",
                max_tokens=10,
                messages=[{"role": "user", "content": "Hi"}],
            )
            assert client.state.turn_count == 1


class TestAsyncGateMode:
    @pytest.mark.asyncio
    async def test_gate_on_high_drift(self, tmp_db: Path):
        with patch("driftmonitor.async_client.EmbeddingEngine") as mock_cls:
            mock_instance = MagicMock()
            mock_instance.create_anchor.return_value = [0.5] * 384
            mock_instance.score_drift.return_value = {
                "persona": 80.0,
                "goal": 85.0,
                "instruction": 75.0,
                "semantic": 90.0,
                "composite": 82.5,
                "raw_distance": 0.6,
            }
            mock_cls.return_value = mock_instance

            base = MagicMock()
            base.__class__.__module__ = "anthropic"
            base.__class__.__name__ = "AsyncAnthropic"
            base.messages.create = AsyncMock(return_value=_make_anthropic_response("Drifted"))

            config = SessionConfig(db_path=tmp_db, mode="gate")
            client = AsyncDriftAwareClient(base, config=config)

            await client.messages.create(
                model="test",
                max_tokens=10,
                messages=[{"role": "user", "content": "Hi"}],
            )

            assert client.is_gated
            client.gate_approve(operator="admin")
            assert not client.is_gated
            client.close()


class TestAsyncAudit:
    @pytest.mark.asyncio
    async def test_session_audited(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.__class__.__module__ = "anthropic"
        base.__class__.__name__ = "AsyncAnthropic"
        config = SessionConfig(session_id="async-audit", db_path=tmp_db)
        client = AsyncDriftAwareClient(base, config=config)

        entries = client.audit.get_entries(action=AuditAction.SESSION_STARTED)
        assert len(entries) == 1
        assert "async=true" in entries[0].details
        client.close()
