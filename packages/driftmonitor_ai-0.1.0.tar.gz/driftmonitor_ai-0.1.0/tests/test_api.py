"""Tests for driftmonitor.api."""

from __future__ import annotations

import typing

import pytest
from fastapi.testclient import TestClient

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.api.app import create_app
from driftmonitor.models import DriftEvent, DriftScore
from driftmonitor.store import DriftStore


@pytest.fixture
def populated_app(tmp_db: Path):
    """Create a test client with a populated database."""
    store = DriftStore(db_path=tmp_db)
    store.create_session("sess-001", name="Test Session", session_type="conversation")
    store.create_session("sess-002", name="Agent Run", session_type="agent")

    for i in range(5):
        store.insert_event(
            DriftEvent(
                session_id="sess-001",
                turn_number=i,
                scores=DriftScore(
                    persona=float(i * 5),
                    goal=float(i * 10),
                    instruction=float(i * 3),
                    semantic=float(i * 8),
                ),
                user_content=f"User message {i}",
                assistant_content=f"Assistant response {i}",
                anchor_distance=i * 0.05,
            )
        )

    # Add one critical event
    store.insert_event(
        DriftEvent(
            session_id="sess-001",
            turn_number=5,
            scores=DriftScore(persona=80, goal=85, instruction=75, semantic=90),
            user_content="Trigger drift",
            assistant_content="Drifted response",
        )
    )
    store.close()

    app = create_app(db_path=str(tmp_db))
    with TestClient(app) as client:
        yield client


@pytest.fixture
def empty_app(tmp_db: Path):
    """Test client with empty database."""
    store = DriftStore(db_path=tmp_db)
    _ = store.conn
    store.close()

    app = create_app(db_path=str(tmp_db))
    with TestClient(app) as client:
        yield client


class TestHealth:
    def test_health(self, populated_app: TestClient):
        resp = populated_app.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert data["sessions"] == 2

    def test_health_empty(self, empty_app: TestClient):
        resp = empty_app.get("/health")
        assert resp.status_code == 200
        assert resp.json()["sessions"] == 0


class TestSessions:
    def test_list_sessions(self, populated_app: TestClient):
        resp = populated_app.get("/sessions")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["sessions"]) == 2

    def test_list_sessions_has_event_count(self, populated_app: TestClient):
        resp = populated_app.get("/sessions")
        sessions = resp.json()["sessions"]
        sess_001 = next(s for s in sessions if s["session_id"] == "sess-001")
        assert sess_001["event_count"] == 6

    def test_list_sessions_empty(self, empty_app: TestClient):
        resp = empty_app.get("/sessions")
        assert resp.status_code == 200
        assert resp.json()["total"] == 0

    def test_get_session(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "sess-001"
        assert data["name"] == "Test Session"
        assert data["event_count"] == 6

    def test_get_session_not_found(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/nope")
        assert resp.status_code == 404

    def test_delete_session(self, populated_app: TestClient):
        resp = populated_app.delete("/sessions/sess-002")
        assert resp.status_code == 200
        assert resp.json()["deleted"] is True
        # Verify gone
        resp2 = populated_app.get("/sessions/sess-002")
        assert resp2.status_code == 404

    def test_delete_not_found(self, populated_app: TestClient):
        resp = populated_app.delete("/sessions/nope")
        assert resp.status_code == 404


class TestEvents:
    def test_list_events(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/events")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "sess-001"
        assert data["total"] == 6
        assert len(data["events"]) == 6

    def test_list_events_with_limit(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/events?limit=3")
        assert resp.status_code == 200
        assert resp.json()["total"] == 3

    def test_list_events_filter_severity(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/events?severity=critical")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] >= 1
        for event in data["events"]:
            assert event["scores"]["severity"] == "critical"

    def test_list_events_invalid_severity(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/events?severity=bogus")
        assert resp.status_code == 400

    def test_list_events_not_found(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/nope/events")
        assert resp.status_code == 404

    def test_event_structure(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/events?limit=1")
        event = resp.json()["events"][0]
        assert "event_id" in event
        assert "turn_number" in event
        assert "timestamp" in event
        assert "scores" in event
        scores = event["scores"]
        assert "persona" in scores
        assert "goal" in scores
        assert "instruction" in scores
        assert "semantic" in scores
        assert "composite" in scores
        assert "severity" in scores

    def test_latest_event(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/latest")
        assert resp.status_code == 200
        data = resp.json()
        assert data["turn_number"] == 5
        assert data["scores"]["persona"] == 80.0

    def test_latest_event_not_found(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-002/latest")
        assert resp.status_code == 404

    def test_latest_session_not_found(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/nope/latest")
        assert resp.status_code == 404


class TestSummary:
    def test_summary(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-001/summary")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "sess-001"
        assert data["turn_count"] == 6
        assert "avg_composite" in data
        assert "max_composite" in data
        assert "overall_severity" in data

    def test_summary_not_found(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/nope/summary")
        assert resp.status_code == 404

    def test_summary_empty_session(self, populated_app: TestClient):
        resp = populated_app.get("/sessions/sess-002/summary")
        assert resp.status_code == 404


class TestWebSocket:
    def test_websocket_connect(self, populated_app: TestClient):
        with populated_app.websocket_connect("/ws/sess-001") as ws:
            # Connection established
            ws.send_text("ping")

    def test_websocket_disconnect(self, populated_app: TestClient):
        # Just verify clean connect/disconnect
        with populated_app.websocket_connect("/ws/test-ws") as ws:
            ws.send_text("hello")


class TestCORS:
    def test_cors_headers(self, populated_app: TestClient):
        resp = populated_app.options(
            "/health",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "GET",
            },
        )
        assert resp.status_code == 200
        assert "access-control-allow-origin" in resp.headers
