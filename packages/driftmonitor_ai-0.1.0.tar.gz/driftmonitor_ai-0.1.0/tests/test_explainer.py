"""Tests for driftmonitor.explainer."""

from __future__ import annotations

from unittest.mock import MagicMock

from driftmonitor.explainer import DriftExplainer, Explanation
from driftmonitor.models import DriftScore, Severity
from driftmonitor.spc import ControlLimits, SPCResult, TrendResult


def _make_spc_result(
    severity: Severity = Severity.ELEVATED,
    out_of_control: bool = False,
    needs_explanation: bool = True,
) -> SPCResult:
    return SPCResult(
        score=50.0,
        severity=severity,
        limits=ControlLimits(
            mean=20, stddev=10, ucl_1sigma=30, ucl_2sigma=40, ucl_3sigma=50, sample_size=10
        ),
        trend=TrendResult(),
        out_of_control=out_of_control,
    )


_DEFAULT_RESPONSE = (
    '{"explanation": "Test drift", "correction": "Fix it",'
    ' "dominant_axis": "persona", "risk_level": "elevated"}'
)


def _make_mock_client(
    response_text: str = _DEFAULT_RESPONSE,
) -> MagicMock:
    block = MagicMock()
    block.text = response_text
    response = MagicMock()
    response.content = [block]
    client = MagicMock()
    client.messages.create.return_value = response
    return client


class TestDriftExplainerInit:
    def test_no_client(self):
        explainer = DriftExplainer()
        assert explainer.latest is None
        assert explainer.explanations == []

    def test_with_client(self):
        client = _make_mock_client()
        explainer = DriftExplainer(client=client)
        assert explainer._client is client


class TestShouldExplain:
    def test_elevated_triggers(self):
        explainer = DriftExplainer()
        result = _make_spc_result(severity=Severity.ELEVATED)
        assert explainer.should_explain(result)

    def test_critical_triggers(self):
        explainer = DriftExplainer()
        result = _make_spc_result(severity=Severity.CRITICAL)
        assert explainer.should_explain(result)

    def test_nominal_does_not_trigger(self):
        explainer = DriftExplainer()
        result = SPCResult(
            score=5,
            severity=Severity.NOMINAL,
            limits=ControlLimits(),
            trend=TrendResult(),
        )
        assert not explainer.should_explain(result)

    def test_out_of_control_triggers(self):
        explainer = DriftExplainer()
        result = SPCResult(
            score=30,
            severity=Severity.LOW,
            limits=ControlLimits(),
            trend=TrendResult(),
            out_of_control=True,
        )
        assert explainer.should_explain(result)


class TestExplain:
    def test_returns_none_without_client(self):
        explainer = DriftExplainer(client=None)
        result = explainer.explain(
            scores=DriftScore(persona=50),
            spc_result=_make_spc_result(),
        )
        assert result is None

    def test_successful_explanation(self):
        client = _make_mock_client()
        explainer = DriftExplainer(client=client)

        result = explainer.explain(
            scores=DriftScore(persona=60, goal=40, instruction=30, semantic=50),
            spc_result=_make_spc_result(),
            user_content="Tell me about auth",
            assistant_content="Let me philosophize about identity...",
            turn_number=5,
        )

        assert result is not None
        assert result.explanation == "Test drift"
        assert result.correction == "Fix it"
        assert result.dominant_axis == "persona"
        assert result.turn_number == 5
        client.messages.create.assert_called_once()

    def test_explanation_stored(self):
        client = _make_mock_client()
        explainer = DriftExplainer(client=client)

        explainer.explain(
            scores=DriftScore(persona=60),
            spc_result=_make_spc_result(),
            turn_number=3,
        )

        assert len(explainer.explanations) == 1
        assert explainer.latest is not None
        assert explainer.latest.turn_number == 3

    def test_multiple_explanations(self):
        client = _make_mock_client()
        explainer = DriftExplainer(client=client)

        for i in range(3):
            explainer.explain(
                scores=DriftScore(persona=float(50 + i * 10)),
                spc_result=_make_spc_result(),
                turn_number=i,
            )

        assert len(explainer.explanations) == 3
        assert explainer.latest.turn_number == 2

    def test_handles_api_failure(self):
        client = MagicMock()
        client.messages.create.side_effect = RuntimeError("API down")
        explainer = DriftExplainer(client=client)

        result = explainer.explain(
            scores=DriftScore(persona=60),
            spc_result=_make_spc_result(),
        )
        assert result is None

    def test_handles_malformed_json(self):
        client = _make_mock_client("Not valid json text here")
        explainer = DriftExplainer(client=client)

        result = explainer.explain(
            scores=DriftScore(persona=60),
            spc_result=_make_spc_result(),
        )
        assert result is not None
        # Falls back to raw text as explanation
        assert result.explanation == "Not valid json text here"

    def test_handles_markdown_wrapped_json(self):
        json_text = (
            '```json\n{"explanation": "Wrapped", "correction": "Fix",'
            ' "dominant_axis": "goal", "risk_level": "critical"}\n```'
        )
        client = _make_mock_client(json_text)
        explainer = DriftExplainer(client=client)

        result = explainer.explain(
            scores=DriftScore(persona=60),
            spc_result=_make_spc_result(),
        )
        assert result is not None
        assert result.explanation == "Wrapped"
        assert result.risk_level == "critical"


class TestExplanationModel:
    def test_severity_elevated(self):
        exp = Explanation(
            explanation="test",
            correction="fix",
            dominant_axis="persona",
            risk_level="elevated",
            scores=DriftScore(),
            turn_number=0,
        )
        assert exp.severity == Severity.ELEVATED

    def test_severity_critical(self):
        exp = Explanation(
            explanation="test",
            correction="fix",
            dominant_axis="persona",
            risk_level="critical",
            scores=DriftScore(),
            turn_number=0,
        )
        assert exp.severity == Severity.CRITICAL


class TestFormatSPCStatus:
    def test_basic_format(self):
        explainer = DriftExplainer()
        result = _make_spc_result()
        status = explainer._format_spc_status(result)
        assert "ELEVATED" in status
        assert "Mean:" in status

    def test_out_of_control_included(self):
        explainer = DriftExplainer()
        result = _make_spc_result(out_of_control=True)
        status = explainer._format_spc_status(result)
        assert "OUT OF CONTROL" in status

    def test_trend_included(self):
        explainer = DriftExplainer()
        result = SPCResult(
            score=50,
            severity=Severity.ELEVATED,
            limits=ControlLimits(
                mean=20, stddev=10, sample_size=10, ucl_1sigma=30, ucl_2sigma=40, ucl_3sigma=50
            ),
            trend=TrendResult(trending_up=True, run_length=6),
        )
        status = explainer._format_spc_status(result)
        assert "Trend:" in status
        assert "UP" in status


class TestReset:
    def test_reset_clears_history(self):
        client = _make_mock_client()
        explainer = DriftExplainer(client=client)
        explainer.explain(
            scores=DriftScore(persona=60),
            spc_result=_make_spc_result(),
        )
        assert len(explainer.explanations) == 1
        explainer.reset()
        assert len(explainer.explanations) == 0
        assert explainer.latest is None
