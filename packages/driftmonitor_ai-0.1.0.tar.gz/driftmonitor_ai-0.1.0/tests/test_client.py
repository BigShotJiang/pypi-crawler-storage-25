"""Tests for driftmonitor.client."""

from __future__ import annotations

import typing
from unittest.mock import MagicMock, patch

import pytest

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.client import DriftAwareClient, _MessagesProxy
from driftmonitor.models import SessionConfig
from driftmonitor.store import DriftStore


def _make_response(text: str) -> MagicMock:
    """Create a mock Anthropic response with text content."""
    block = MagicMock()
    block.text = text
    block.type = "text"
    response = MagicMock()
    response.content = [block]
    return response


def _make_base_client(response_text: str = "Test response") -> MagicMock:
    """Create a mock Anthropic base client."""
    base = MagicMock()
    base.messages.create.return_value = _make_response(response_text)
    return base


@pytest.fixture
def mock_engine():
    """Patch EmbeddingEngine to avoid loading sentence-transformers."""
    with patch("driftmonitor.client.EmbeddingEngine") as mock_cls:
        mock_instance = MagicMock()
        mock_instance.create_anchor.return_value = [0.5] * 384
        mock_instance.score_drift.return_value = {
            "persona": 10.0,
            "goal": 15.0,
            "instruction": 5.0,
            "semantic": 20.0,
            "composite": 12.5,
            "raw_distance": 0.08,
        }
        mock_cls.return_value = mock_instance
        yield mock_instance


class TestDriftAwareClientInit:
    def test_creates_session_in_store(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(session_id="init-test", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        store = DriftStore(db_path=tmp_db)
        sess = store.get_session("init-test")
        assert sess is not None
        store.close()
        client.close()

    def test_default_config_generated(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        assert len(client.config.session_id) == 8
        client.close()

    def test_has_messages_proxy(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        assert isinstance(client.messages, _MessagesProxy)
        client.close()

    def test_initial_state(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        assert client.state.turn_count == 0
        assert client.state.anchor_set is False
        assert client.latest_score is None
        client.close()


class TestMessagesCreate:
    def test_passthrough_response(self, tmp_db: Path, mock_engine):
        base = _make_base_client("Hello world")
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hi"}],
        )

        assert response.content[0].text == "Hello world"
        base.messages.create.assert_called_once()
        client.close()

    def test_kwargs_forwarded(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=500,
            system="Be helpful",
            messages=[{"role": "user", "content": "test"}],
        )

        call_kwargs = base.messages.create.call_args.kwargs
        assert call_kwargs["model"] == "claude-sonnet-4-20250514"
        assert call_kwargs["max_tokens"] == 500
        assert call_kwargs["system"] == "Be helpful"
        client.close()

    def test_anchor_set_on_first_call(self, tmp_db: Path, mock_engine):
        base = _make_base_client("First response")
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test", max_tokens=10, messages=[{"role": "user", "content": "Hi"}]
        )

        assert client.state.anchor_set is True
        mock_engine.create_anchor.assert_called_once_with("First response")
        client.close()

    def test_drift_scored_on_each_call(self, tmp_db: Path, mock_engine):
        base = _make_base_client("Response")
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test", max_tokens=10, messages=[{"role": "user", "content": "Turn 1"}]
        )
        client.messages.create(
            model="test", max_tokens=10, messages=[{"role": "user", "content": "Turn 2"}]
        )

        assert client.state.turn_count == 2
        assert len(client.state.events) == 2
        assert mock_engine.score_drift.call_count == 2
        client.close()

    def test_event_stored_in_db(self, tmp_db: Path, mock_engine):
        base = _make_base_client("Stored response")
        config = SessionConfig(session_id="store-test", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Save me"}],
        )

        store = DriftStore(db_path=tmp_db)
        events = store.get_events("store-test")
        assert len(events) == 1
        assert events[0].scores.persona == 10.0
        assert events[0].user_content == "Save me"
        assert events[0].assistant_content == "Stored response"
        store.close()
        client.close()

    def test_scores_accessible(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test", max_tokens=10, messages=[{"role": "user", "content": "Hi"}]
        )

        score = client.latest_score
        assert score is not None
        assert score.persona == 10.0
        assert score.goal == 15.0
        client.close()

    def test_composite_history(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        for i in range(3):
            client.messages.create(
                model="test",
                max_tokens=10,
                messages=[{"role": "user", "content": f"Turn {i}"}],
            )

        history = client.composite_history
        assert len(history) == 3
        client.close()


class TestSetAnchor:
    def test_manual_anchor(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.set_anchor("Reference document text for anchoring.")
        assert client.state.anchor_set is True
        mock_engine.create_anchor.assert_called_once_with("Reference document text for anchoring.")
        client.close()

    def test_anchor_stored_in_db(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(session_id="anchor-db", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.set_anchor("Anchor text")

        store = DriftStore(db_path=tmp_db)
        assert store.has_anchor("anchor-db")
        store.close()
        client.close()


class TestContextManager:
    def test_context_manager(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        with DriftAwareClient(base, config=config) as client:
            client.messages.create(
                model="test", max_tokens=10, messages=[{"role": "user", "content": "Hi"}]
            )
            assert client.state.turn_count == 1


class TestMessagesProxy:
    def test_getattr_forwarded(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        base.messages.some_other_method = MagicMock(return_value="forwarded")
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        result = client.messages.some_other_method()
        assert result == "forwarded"
        client.close()


class TestExtractText:
    def test_single_text_block(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        response = _make_response("Hello")
        assert client._extract_text(response) == "Hello"
        client.close()

    def test_multiple_text_blocks(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        block1 = MagicMock()
        block1.text = "Part 1"
        block2 = MagicMock()
        block2.text = "Part 2"
        response = MagicMock()
        response.content = [block1, block2]

        assert client._extract_text(response) == "Part 1\nPart 2"
        client.close()

    def test_non_text_block_skipped(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        text_block = MagicMock()
        text_block.text = "Hello"
        tool_block = MagicMock(spec=[])  # no .text attribute
        response = MagicMock()
        response.content = [tool_block, text_block]

        assert client._extract_text(response) == "Hello"
        client.close()

    def test_fallback_to_str(self, tmp_db: Path, mock_engine):
        base = _make_base_client()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        assert client._extract_text("plain string") == "plain string"
        client.close()


class TestSeverityLogging:
    def test_critical_drift_logged(self, tmp_db: Path, caplog):
        with patch("driftmonitor.client.EmbeddingEngine") as mock_cls:
            mock_instance = MagicMock()
            mock_instance.create_anchor.return_value = [0.5] * 384
            mock_instance.score_drift.return_value = {
                "persona": 80.0,
                "goal": 85.0,
                "instruction": 75.0,
                "semantic": 90.0,
                "composite": 82.5,
                "raw_distance": 0.6,
            }
            mock_cls.return_value = mock_instance

            base = _make_base_client()
            config = SessionConfig(db_path=tmp_db)
            client = DriftAwareClient(base, config=config)

            import logging

            with caplog.at_level(logging.WARNING, logger="driftmonitor.client"):
                client.messages.create(
                    model="test",
                    max_tokens=10,
                    messages=[{"role": "user", "content": "Hi"}],
                )

            assert any("CRITICAL" in record.message for record in caplog.records)
            client.close()
