"""Tests for driftmonitor.audit — modes, audit log, and export."""

from __future__ import annotations

import csv
import io
import json
import sqlite3
import typing
from unittest.mock import MagicMock, patch

import pytest

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.audit import AuditAction, AuditEntry, AuditLog, OperationMode
from driftmonitor.client import DriftAwareClient
from driftmonitor.models import SessionConfig

# --- OperationMode ---


class TestOperationMode:
    def test_values(self):
        assert OperationMode.OBSERVE.value == "observe"
        assert OperationMode.ALERT.value == "alert"
        assert OperationMode.GATE.value == "gate"

    def test_from_string(self):
        assert OperationMode("observe") == OperationMode.OBSERVE
        assert OperationMode("gate") == OperationMode.GATE


class TestAuditAction:
    def test_all_actions_exist(self):
        assert len(AuditAction) == 10

    def test_values(self):
        assert AuditAction.DRIFT_DETECTED.value == "drift_detected"
        assert AuditAction.GATE_HELD.value == "gate_held"
        assert AuditAction.GATE_RELEASED.value == "gate_released"


# --- AuditLog ---


@pytest.fixture
def audit_db(tmp_db: Path):
    """SQLite connection with audit log."""
    conn = sqlite3.connect(str(tmp_db))
    conn.row_factory = sqlite3.Row
    return conn


@pytest.fixture
def audit(audit_db):
    """AuditLog instance."""
    log = AuditLog(audit_db)
    yield log
    audit_db.close()


class TestAuditLog:
    def test_append(self, audit):
        entry = AuditEntry(
            session_id="s1",
            action=AuditAction.SESSION_STARTED,
            details="mode=observe",
        )
        result = audit.append(entry)
        assert result.entry_id > 0

    def test_get_entries(self, audit):
        for i in range(5):
            audit.append(
                AuditEntry(
                    session_id="s1",
                    action=AuditAction.DRIFT_DETECTED,
                    turn_number=i,
                    composite_score=float(i * 10),
                )
            )
        entries = audit.get_entries(session_id="s1")
        assert len(entries) == 5

    def test_filter_by_action(self, audit):
        audit.append(AuditEntry(session_id="s1", action=AuditAction.SESSION_STARTED))
        audit.append(AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED))
        audit.append(AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED))

        entries = audit.get_entries(action=AuditAction.DRIFT_DETECTED)
        assert len(entries) == 2

    def test_filter_by_session(self, audit):
        audit.append(AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED))
        audit.append(AuditEntry(session_id="s2", action=AuditAction.DRIFT_DETECTED))

        entries = audit.get_entries(session_id="s1")
        assert len(entries) == 1

    def test_limit(self, audit):
        for _ in range(10):
            audit.append(AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED))
        entries = audit.get_entries(limit=3)
        assert len(entries) == 3

    def test_count(self, audit):
        assert audit.count() == 0
        for _ in range(5):
            audit.append(AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED))
        assert audit.count() == 5
        assert audit.count(session_id="s1") == 5
        assert audit.count(session_id="s2") == 0

    def test_ordering_newest_first(self, audit):
        for i in range(3):
            audit.append(
                AuditEntry(session_id="s1", action=AuditAction.DRIFT_DETECTED, turn_number=i)
            )
        entries = audit.get_entries()
        assert entries[0].turn_number == 2  # newest first

    def test_export_json(self, audit):
        audit.append(
            AuditEntry(
                session_id="s1",
                action=AuditAction.DRIFT_DETECTED,
                composite_score=42.5,
            )
        )
        data = json.loads(audit.export_json())
        assert len(data) == 1
        assert data[0]["composite_score"] == 42.5

    def test_export_csv(self, audit):
        audit.append(
            AuditEntry(
                session_id="s1",
                action=AuditAction.DRIFT_DETECTED,
                composite_score=42.5,
            )
        )
        csv_str = audit.export_csv()
        reader = csv.DictReader(io.StringIO(csv_str))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["session_id"] == "s1"

    def test_export_csv_empty(self, audit):
        assert audit.export_csv() == ""

    def test_export_json_empty(self, audit):
        data = json.loads(audit.export_json())
        assert data == []


# --- Modes in DriftAwareClient ---


def _make_response(text: str) -> MagicMock:
    block = MagicMock()
    block.text = text
    response = MagicMock()
    response.content = [block]
    return response


@pytest.fixture
def mock_engine():
    with patch("driftmonitor.client.EmbeddingEngine") as mock_cls:
        mock_instance = MagicMock()
        mock_instance.create_anchor.return_value = [0.5] * 384
        mock_instance.score_drift.return_value = {
            "persona": 10.0,
            "goal": 15.0,
            "instruction": 5.0,
            "semantic": 20.0,
            "composite": 12.5,
            "raw_distance": 0.08,
        }
        mock_cls.return_value = mock_instance
        yield mock_instance


@pytest.fixture
def high_drift_engine():
    with patch("driftmonitor.client.EmbeddingEngine") as mock_cls:
        mock_instance = MagicMock()
        mock_instance.create_anchor.return_value = [0.5] * 384
        mock_instance.score_drift.return_value = {
            "persona": 80.0,
            "goal": 85.0,
            "instruction": 75.0,
            "semantic": 90.0,
            "composite": 82.5,
            "raw_distance": 0.6,
        }
        mock_cls.return_value = mock_instance
        yield mock_instance


class TestClientModes:
    def test_default_mode_observe(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        assert client.mode == OperationMode.OBSERVE
        client.close()

    def test_set_mode(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        client.set_mode(OperationMode.GATE)
        assert client.mode == OperationMode.GATE
        client.close()

    def test_set_mode_from_string(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        client.set_mode("alert")
        assert client.mode == OperationMode.ALERT
        client.close()

    def test_mode_change_audited(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(session_id="mode-test", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        client.set_mode("gate")

        entries = client.audit.get_entries(action=AuditAction.MODE_CHANGED)
        assert len(entries) == 1
        assert "observe -> gate" in entries[0].details
        client.close()

    def test_config_mode(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)
        assert client.mode == OperationMode.GATE
        client.close()


class TestGateMode:
    def test_gate_holds_on_high_drift(self, tmp_db: Path, high_drift_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Drifted output")
        config = SessionConfig(db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )

        assert client.is_gated
        client.close()

    def test_gate_approve(self, tmp_db: Path, high_drift_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Drifted")
        config = SessionConfig(session_id="gate-approve", db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert client.is_gated

        client.gate_approve(operator="admin", reason="Acceptable drift")
        assert not client.is_gated

        entries = client.audit.get_entries(action=AuditAction.GATE_RELEASED)
        assert len(entries) == 1
        assert entries[0].operator == "admin"
        client.close()

    def test_gate_reject(self, tmp_db: Path, high_drift_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Bad output")
        config = SessionConfig(session_id="gate-reject", db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )
        client.gate_reject(operator="admin", reason="Too much drift")
        assert not client.is_gated

        entries = client.audit.get_entries(action=AuditAction.GATE_REJECTED)
        assert len(entries) == 1
        client.close()

    def test_no_gate_on_low_drift(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Normal output")
        config = SessionConfig(db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )
        assert not client.is_gated
        client.close()

    def test_gate_approve_noop_when_not_gated(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(db_path=tmp_db, mode="gate")
        client = DriftAwareClient(base, config=config)
        client.gate_approve()  # should not error
        client.close()


class TestAlertMode:
    def test_alert_audited_on_high_drift(self, tmp_db: Path, high_drift_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Drifted")
        config = SessionConfig(session_id="alert-test", db_path=tmp_db, mode="alert")
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )

        entries = client.audit.get_entries(action=AuditAction.ALERT_SENT)
        assert len(entries) == 1
        client.close()


class TestAuditIntegration:
    def test_session_start_audited(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(session_id="audit-start", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        entries = client.audit.get_entries(action=AuditAction.SESSION_STARTED)
        assert len(entries) == 1
        client.close()

    def test_session_end_audited(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        config = SessionConfig(session_id="audit-end", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)
        client.close()

        # Re-open to query
        from driftmonitor.store import DriftStore

        store = DriftStore(db_path=tmp_db)
        audit = AuditLog(store.conn)
        entries = audit.get_entries(action=AuditAction.SESSION_ENDED)
        assert len(entries) == 1
        store.close()

    def test_drift_detection_audited(self, tmp_db: Path, mock_engine):
        base = MagicMock()
        base.messages.create.return_value = _make_response("Response")
        config = SessionConfig(session_id="audit-drift", db_path=tmp_db)
        client = DriftAwareClient(base, config=config)

        client.messages.create(
            model="test",
            max_tokens=10,
            messages=[{"role": "user", "content": "Hi"}],
        )

        entries = client.audit.get_entries(action=AuditAction.DRIFT_DETECTED)
        assert len(entries) == 1
        client.close()
