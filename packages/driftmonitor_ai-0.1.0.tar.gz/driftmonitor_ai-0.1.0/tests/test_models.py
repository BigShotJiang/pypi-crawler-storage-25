"""Tests for driftmonitor.models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from driftmonitor.models import (
    DriftAxis,
    DriftEvent,
    DriftScore,
    SessionConfig,
    SessionState,
    Severity,
)

# --- Severity ---


class TestSeverity:
    def test_nominal_range(self):
        assert Severity.from_score(0) == Severity.NOMINAL
        assert Severity.from_score(10) == Severity.NOMINAL
        assert Severity.from_score(20) == Severity.NOMINAL

    def test_low_range(self):
        assert Severity.from_score(21) == Severity.LOW
        assert Severity.from_score(30) == Severity.LOW
        assert Severity.from_score(40) == Severity.LOW

    def test_elevated_range(self):
        assert Severity.from_score(41) == Severity.ELEVATED
        assert Severity.from_score(55) == Severity.ELEVATED
        assert Severity.from_score(70) == Severity.ELEVATED

    def test_critical_range(self):
        assert Severity.from_score(71) == Severity.CRITICAL
        assert Severity.from_score(85) == Severity.CRITICAL
        assert Severity.from_score(100) == Severity.CRITICAL

    def test_boundary_values(self):
        assert Severity.from_score(20.0) == Severity.NOMINAL
        assert Severity.from_score(20.1) == Severity.LOW
        assert Severity.from_score(40.0) == Severity.LOW
        assert Severity.from_score(40.1) == Severity.ELEVATED
        assert Severity.from_score(70.0) == Severity.ELEVATED
        assert Severity.from_score(70.1) == Severity.CRITICAL

    def test_enum_values(self):
        assert Severity.NOMINAL.value == "nominal"
        assert Severity.LOW.value == "low"
        assert Severity.ELEVATED.value == "elevated"
        assert Severity.CRITICAL.value == "critical"


# --- DriftAxis ---


class TestDriftAxis:
    def test_enum_values(self):
        assert DriftAxis.PERSONA.value == "persona"
        assert DriftAxis.GOAL.value == "goal"
        assert DriftAxis.INSTRUCTION.value == "instruction"
        assert DriftAxis.SEMANTIC.value == "semantic"

    def test_all_axes(self):
        assert len(DriftAxis) == 4


# --- DriftScore ---


class TestDriftScore:
    def test_defaults_to_zero(self, zero_score):
        assert zero_score.persona == 0.0
        assert zero_score.goal == 0.0
        assert zero_score.instruction == 0.0
        assert zero_score.semantic == 0.0

    def test_composite_calculation(self, sample_score):
        expected = (15.0 + 25.0 + 10.0 + 30.0) / 4.0
        assert sample_score.composite == expected

    def test_composite_zero(self, zero_score):
        assert zero_score.composite == 0.0

    def test_composite_max(self):
        score = DriftScore(persona=100, goal=100, instruction=100, semantic=100)
        assert score.composite == 100.0

    def test_severity_nominal(self, zero_score):
        assert zero_score.severity == Severity.NOMINAL

    def test_severity_low(self, sample_score):
        assert sample_score.severity == Severity.NOMINAL  # composite = 20.0

    def test_severity_critical(self, critical_score):
        assert critical_score.severity == Severity.CRITICAL

    def test_dominant_axis(self, sample_score):
        assert sample_score.dominant_axis == DriftAxis.SEMANTIC  # 30.0 is highest

    def test_dominant_axis_tie_returns_first(self):
        score = DriftScore(persona=50, goal=50, instruction=50, semantic=50)
        # When tied, max() returns the first one encountered
        assert score.dominant_axis in list(DriftAxis)

    def test_axis_score_lookup(self, sample_score):
        assert sample_score.axis_score(DriftAxis.PERSONA) == 15.0
        assert sample_score.axis_score(DriftAxis.GOAL) == 25.0
        assert sample_score.axis_score(DriftAxis.INSTRUCTION) == 10.0
        assert sample_score.axis_score(DriftAxis.SEMANTIC) == 30.0

    def test_axis_severity(self):
        score = DriftScore(persona=5, goal=35, instruction=55, semantic=80)
        assert score.axis_severity(DriftAxis.PERSONA) == Severity.NOMINAL
        assert score.axis_severity(DriftAxis.GOAL) == Severity.LOW
        assert score.axis_severity(DriftAxis.INSTRUCTION) == Severity.ELEVATED
        assert score.axis_severity(DriftAxis.SEMANTIC) == Severity.CRITICAL

    def test_to_dict(self, sample_score):
        d = sample_score.to_dict()
        assert d == {
            "persona": 15.0,
            "goal": 25.0,
            "instruction": 10.0,
            "semantic": 30.0,
        }

    def test_validation_min(self):
        with pytest.raises(ValidationError):
            DriftScore(persona=-1)

    def test_validation_max(self):
        with pytest.raises(ValidationError):
            DriftScore(persona=101)

    def test_serialization_roundtrip(self, sample_score):
        data = sample_score.model_dump()
        restored = DriftScore(**data)
        assert restored == sample_score


# --- DriftEvent ---


class TestDriftEvent:
    def test_creation(self, sample_event):
        assert sample_event.session_id == "test-session-001"
        assert sample_event.turn_number == 1
        assert sample_event.anchor_distance == 0.12

    def test_auto_event_id(self):
        e1 = DriftEvent(session_id="s1", turn_number=0, scores=DriftScore())
        e2 = DriftEvent(session_id="s1", turn_number=1, scores=DriftScore())
        assert e1.event_id != e2.event_id
        assert len(e1.event_id) == 12

    def test_auto_timestamp(self):
        event = DriftEvent(session_id="s1", turn_number=0, scores=DriftScore())
        assert event.timestamp is not None

    def test_composite_delegated(self, sample_event):
        assert sample_event.composite == sample_event.scores.composite

    def test_severity_delegated(self, sample_event):
        assert sample_event.severity == sample_event.scores.severity

    def test_turn_number_validation(self):
        with pytest.raises(ValidationError):
            DriftEvent(session_id="s1", turn_number=-1, scores=DriftScore())

    def test_serialization_roundtrip(self, sample_event):
        data = sample_event.model_dump()
        restored = DriftEvent(**data)
        assert restored.session_id == sample_event.session_id
        assert restored.scores.persona == sample_event.scores.persona


# --- SessionConfig ---


class TestSessionConfig:
    def test_defaults(self):
        config = SessionConfig()
        assert len(config.session_id) == 8
        assert config.embedding_model == "all-MiniLM-L6-v2"
        assert config.session_type == "conversation"

    def test_custom_values(self, session_config):
        assert session_config.session_id == "test-session-001"
        assert session_config.name == "Test Session"

    def test_severity_thresholds_default(self):
        config = SessionConfig()
        assert config.severity_thresholds["low"] == 20.0
        assert config.severity_thresholds["elevated"] == 40.0
        assert config.severity_thresholds["critical"] == 70.0

    def test_auto_session_id_unique(self):
        c1 = SessionConfig()
        c2 = SessionConfig()
        assert c1.session_id != c2.session_id


# --- SessionState ---


class TestSessionState:
    def test_initial_state(self, session_config):
        state = SessionState(config=session_config)
        assert state.turn_count == 0
        assert state.events == []
        assert state.anchor_set is False

    def test_latest_score_none_when_empty(self, session_config):
        state = SessionState(config=session_config)
        assert state.latest_score is None
        assert state.latest_severity is None

    def test_latest_score_returns_last(self, session_config, sample_event):
        state = SessionState(config=session_config, events=[sample_event])
        assert state.latest_score == sample_event.scores

    def test_composite_history(self, session_config):
        events = [
            DriftEvent(
                session_id="s1",
                turn_number=i,
                scores=DriftScore(persona=float(i * 10)),
            )
            for i in range(5)
        ]
        state = SessionState(config=session_config, events=events)
        history = state.composite_history
        assert len(history) == 5
        assert history[0] == 0.0
        assert history[4] == 10.0  # 40/4
