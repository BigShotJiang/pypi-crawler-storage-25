"""Tests for driftmonitor.providers — multi-LLM support."""

from __future__ import annotations

from unittest.mock import MagicMock

from driftmonitor.providers import (
    ProviderType,
    _translate_kwargs,
    detect_provider,
    extract_text,
    extract_user_text,
)

# --- Provider Detection ---


class TestDetectProvider:
    def test_anthropic_by_module(self):
        client = MagicMock()
        client.__class__.__module__ = "anthropic._client"
        client.__class__.__name__ = "Anthropic"
        assert detect_provider(client) == ProviderType.ANTHROPIC

    def test_openai_by_module(self):
        client = MagicMock()
        client.__class__.__module__ = "openai._client"
        client.__class__.__name__ = "OpenAI"
        assert detect_provider(client) == ProviderType.OPENAI

    def test_anthropic_by_name(self):
        client = MagicMock()
        client.__class__.__module__ = "some.module"
        client.__class__.__name__ = "Anthropic"
        assert detect_provider(client) == ProviderType.ANTHROPIC

    def test_async_anthropic(self):
        client = MagicMock()
        client.__class__.__module__ = "anthropic"
        client.__class__.__name__ = "AsyncAnthropic"
        assert detect_provider(client) == ProviderType.ANTHROPIC

    def test_async_openai(self):
        client = MagicMock()
        client.__class__.__module__ = "openai"
        client.__class__.__name__ = "AsyncOpenAI"
        assert detect_provider(client) == ProviderType.OPENAI

    def test_unknown(self):
        client = MagicMock()
        client.__class__.__module__ = "custom.llm"
        client.__class__.__name__ = "CustomClient"
        assert detect_provider(client) == ProviderType.UNKNOWN


# --- Text Extraction ---


class TestExtractText:
    def test_anthropic_response(self):
        block = MagicMock()
        block.text = "Hello from Claude"
        response = MagicMock()
        response.content = [block]
        assert extract_text(response, ProviderType.ANTHROPIC) == "Hello from Claude"

    def test_anthropic_multi_block(self):
        b1 = MagicMock()
        b1.text = "Part 1"
        b2 = MagicMock()
        b2.text = "Part 2"
        response = MagicMock()
        response.content = [b1, b2]
        assert extract_text(response, ProviderType.ANTHROPIC) == "Part 1\nPart 2"

    def test_openai_response(self):
        message = MagicMock()
        message.content = "Hello from GPT"
        choice = MagicMock()
        choice.message = message
        response = MagicMock()
        response.choices = [choice]
        assert extract_text(response, ProviderType.OPENAI) == "Hello from GPT"

    def test_openai_empty_choices(self):
        response = MagicMock()
        response.choices = []
        result = extract_text(response, ProviderType.OPENAI)
        assert isinstance(result, str)

    def test_unknown_fallback(self):
        response = MagicMock()
        response.content = []
        result = extract_text(response, ProviderType.UNKNOWN)
        assert isinstance(result, str)


# --- Kwargs Translation ---


class TestTranslateKwargs:
    def test_system_becomes_message(self):
        kwargs = {
            "model": "gpt-4",
            "max_tokens": 100,
            "system": "You are helpful",
            "messages": [{"role": "user", "content": "Hi"}],
        }
        result = _translate_kwargs(kwargs)
        assert result["messages"][0] == {"role": "system", "content": "You are helpful"}
        assert result["messages"][1] == {"role": "user", "content": "Hi"}
        assert "system" not in result

    def test_no_system(self):
        kwargs = {
            "model": "gpt-4",
            "messages": [{"role": "user", "content": "Hi"}],
        }
        result = _translate_kwargs(kwargs)
        assert len(result["messages"]) == 1

    def test_existing_system_not_duplicated(self):
        kwargs = {
            "model": "gpt-4",
            "system": "Extra",
            "messages": [
                {"role": "system", "content": "Already here"},
                {"role": "user", "content": "Hi"},
            ],
        }
        result = _translate_kwargs(kwargs)
        system_msgs = [m for m in result["messages"] if m["role"] == "system"]
        assert len(system_msgs) == 1
        assert system_msgs[0]["content"] == "Already here"


# --- User Text Extraction ---


class TestExtractUserText:
    def test_last_user_message(self):
        messages = [
            {"role": "user", "content": "First"},
            {"role": "assistant", "content": "Reply"},
            {"role": "user", "content": "Second"},
        ]
        assert extract_user_text(messages) == "Second"

    def test_no_user_message(self):
        messages = [{"role": "assistant", "content": "Reply"}]
        assert extract_user_text(messages) == ""

    def test_empty_messages(self):
        assert extract_user_text([]) == ""

    def test_non_string_content(self):
        messages = [{"role": "user", "content": ["structured", "content"]}]
        result = extract_user_text(messages)
        assert isinstance(result, str)


# --- Provider Enum ---


class TestProviderType:
    def test_values(self):
        assert ProviderType.ANTHROPIC.value == "anthropic"
        assert ProviderType.OPENAI.value == "openai"
        assert ProviderType.UNKNOWN.value == "unknown"
