"""Tests for driftmonitor.store."""

from __future__ import annotations

import pytest

from driftmonitor.models import DriftEvent, DriftScore, Severity
from driftmonitor.store import DriftStore


class TestStoreInit:
    def test_creates_db_file(self, tmp_db):
        store = DriftStore(db_path=tmp_db)
        _ = store.conn  # trigger connection
        assert tmp_db.exists()
        store.close()

    def test_wal_mode(self, store):
        row = store.conn.execute("PRAGMA journal_mode").fetchone()
        assert row[0] == "wal"

    def test_foreign_keys_enabled(self, store):
        row = store.conn.execute("PRAGMA foreign_keys").fetchone()
        assert row[0] == 1

    def test_schema_version(self, store):
        row = store.conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        assert row["value"] == "1"

    def test_tables_created(self, store):
        tables = store.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        names = [r["name"] for r in tables]
        assert "sessions" in names
        assert "events" in names
        assert "anchors" in names
        assert "meta" in names

    def test_context_manager(self, tmp_db):
        with DriftStore(db_path=tmp_db) as s:
            _ = s.conn
            assert tmp_db.exists()
        # Connection should be closed after exit
        assert s._conn is None

    def test_idempotent_schema(self, tmp_db):
        """Opening the same db twice doesn't error."""
        s1 = DriftStore(db_path=tmp_db)
        _ = s1.conn
        s1.close()
        s2 = DriftStore(db_path=tmp_db)
        _ = s2.conn
        s2.close()


class TestSessions:
    def test_create_session(self, store):
        store.create_session("sess-1", name="Test", session_type="conversation")
        sess = store.get_session("sess-1")
        assert sess is not None
        assert sess["name"] == "Test"
        assert sess["session_type"] == "conversation"

    def test_get_nonexistent(self, store):
        assert store.get_session("nope") is None

    def test_list_sessions_empty(self, store):
        assert store.list_sessions() == []

    def test_list_sessions_ordered(self, store):
        store.create_session("a", name="First")
        store.create_session("b", name="Second")
        sessions = store.list_sessions()
        assert len(sessions) == 2
        # Most recent first (b created after a)
        assert sessions[0]["session_id"] == "b"

    def test_delete_session(self, store):
        store.create_session("del-me")
        assert store.delete_session("del-me") == 1
        assert store.get_session("del-me") is None

    def test_delete_nonexistent(self, store):
        assert store.delete_session("nope") == 0

    def test_delete_cascades_events(self, store, sample_event):
        store.create_session(sample_event.session_id)
        store.insert_event(sample_event)
        assert store.count_events(sample_event.session_id) == 1
        store.delete_session(sample_event.session_id)
        assert store.count_events(sample_event.session_id) == 0

    def test_duplicate_session_raises(self, store):
        store.create_session("dupe")
        with pytest.raises(Exception, match="UNIQUE"):
            store.create_session("dupe")


class TestEvents:
    def test_insert_and_retrieve(self, store, sample_event):
        store.create_session(sample_event.session_id)
        store.insert_event(sample_event)
        events = store.get_events(sample_event.session_id)
        assert len(events) == 1
        assert events[0].event_id == sample_event.event_id
        assert events[0].scores.persona == 15.0

    def test_event_ordering(self, store):
        store.create_session("ordered")
        for i in range(5):
            event = DriftEvent(
                session_id="ordered",
                turn_number=i,
                scores=DriftScore(persona=float(i * 10)),
            )
            store.insert_event(event)
        events = store.get_events("ordered")
        assert len(events) == 5
        assert events[0].turn_number == 0
        assert events[4].turn_number == 4

    def test_event_limit(self, store):
        store.create_session("limited")
        for i in range(10):
            store.insert_event(DriftEvent(session_id="limited", turn_number=i, scores=DriftScore()))
        events = store.get_events("limited", limit=3)
        assert len(events) == 3

    def test_filter_by_severity(self, store):
        store.create_session("filtered")
        store.insert_event(
            DriftEvent(
                session_id="filtered",
                turn_number=0,
                scores=DriftScore(persona=5),  # nominal
            )
        )
        store.insert_event(
            DriftEvent(
                session_id="filtered",
                turn_number=1,
                scores=DriftScore(persona=80, goal=80, instruction=80, semantic=80),  # critical
            )
        )
        critical = store.get_events("filtered", severity=Severity.CRITICAL)
        assert len(critical) == 1
        assert critical[0].turn_number == 1

    def test_get_latest_event(self, store):
        store.create_session("latest")
        for i in range(3):
            store.insert_event(
                DriftEvent(
                    session_id="latest",
                    turn_number=i,
                    scores=DriftScore(persona=float(i * 20)),
                )
            )
        latest = store.get_latest_event("latest")
        assert latest is not None
        assert latest.turn_number == 2
        assert latest.scores.persona == 40.0

    def test_get_latest_empty(self, store):
        store.create_session("empty")
        assert store.get_latest_event("empty") is None

    def test_count_events(self, store):
        store.create_session("counted")
        assert store.count_events("counted") == 0
        for i in range(7):
            store.insert_event(DriftEvent(session_id="counted", turn_number=i, scores=DriftScore()))
        assert store.count_events("counted") == 7

    def test_content_stored(self, store, sample_event):
        store.create_session(sample_event.session_id)
        store.insert_event(sample_event)
        events = store.get_events(sample_event.session_id)
        assert events[0].user_content == "What is the capital of France?"
        assert events[0].assistant_content == "The capital of France is Paris."

    def test_anchor_distance_stored(self, store, sample_event):
        store.create_session(sample_event.session_id)
        store.insert_event(sample_event)
        events = store.get_events(sample_event.session_id)
        assert events[0].anchor_distance == pytest.approx(0.12)

    def test_empty_session_events(self, store):
        assert store.get_events("nonexistent") == []


class TestAnchors:
    def test_store_and_retrieve(self, store):
        store.create_session("anchored")
        embedding = [0.1, 0.2, 0.3, 0.4, 0.5]
        store.store_anchor("anchored", embedding, source_text="Hello world")
        result = store.get_anchor("anchored")
        assert result is not None
        assert len(result) == 5
        assert result[0] == pytest.approx(0.1)

    def test_has_anchor(self, store):
        store.create_session("check-anchor")
        assert store.has_anchor("check-anchor") is False
        store.store_anchor("check-anchor", [1.0, 2.0])
        assert store.has_anchor("check-anchor") is True

    def test_get_nonexistent_anchor(self, store):
        assert store.get_anchor("nope") is None

    def test_anchor_replace(self, store):
        store.create_session("replace")
        store.store_anchor("replace", [1.0, 2.0])
        store.store_anchor("replace", [3.0, 4.0])
        result = store.get_anchor("replace")
        assert result == [3.0, 4.0]

    def test_anchor_deleted_with_session(self, store):
        store.create_session("del-anchor")
        store.store_anchor("del-anchor", [1.0])
        store.delete_session("del-anchor")
        assert store.get_anchor("del-anchor") is None


class TestAggregates:
    def test_session_summary(self, store):
        store.create_session("summary")
        for i in range(5):
            store.insert_event(
                DriftEvent(
                    session_id="summary",
                    turn_number=i,
                    scores=DriftScore(
                        persona=float(i * 5),
                        goal=float(i * 10),
                        instruction=float(i * 3),
                        semantic=float(i * 7),
                    ),
                )
            )
        summary = store.session_summary("summary")
        assert summary is not None
        assert summary["turn_count"] == 5
        assert summary["avg_persona"] == pytest.approx(10.0)  # (0+5+10+15+20)/5
        assert summary["max_composite"] > 0

    def test_summary_empty(self, store):
        store.create_session("empty-summary")
        assert store.session_summary("empty-summary") is None

    def test_summary_nonexistent(self, store):
        assert store.session_summary("nope") is None
