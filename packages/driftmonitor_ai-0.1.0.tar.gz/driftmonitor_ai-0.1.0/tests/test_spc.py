"""Tests for driftmonitor.spc."""

from __future__ import annotations

import math

import pytest

from driftmonitor.models import DriftScore, Severity
from driftmonitor.spc import ControlLimits, SPCEngine, SPCResult, TrendResult


class TestControlLimits:
    def test_defaults(self):
        cl = ControlLimits()
        assert cl.mean == 0.0
        assert cl.stddev == 0.0
        assert cl.sample_size == 0

    def test_not_valid_under_3(self):
        assert not ControlLimits(sample_size=0).is_valid
        assert not ControlLimits(sample_size=1).is_valid
        assert not ControlLimits(sample_size=2).is_valid
        assert ControlLimits(sample_size=3).is_valid

    def test_classify_nominal(self):
        cl = ControlLimits(
            mean=10, stddev=5, ucl_1sigma=15, ucl_2sigma=20, ucl_3sigma=25, sample_size=10
        )
        assert cl.classify(12) == Severity.NOMINAL

    def test_classify_low(self):
        cl = ControlLimits(
            mean=10, stddev=5, ucl_1sigma=15, ucl_2sigma=20, ucl_3sigma=25, sample_size=10
        )
        assert cl.classify(16) == Severity.LOW

    def test_classify_elevated(self):
        cl = ControlLimits(
            mean=10, stddev=5, ucl_1sigma=15, ucl_2sigma=20, ucl_3sigma=25, sample_size=10
        )
        assert cl.classify(21) == Severity.ELEVATED

    def test_classify_critical(self):
        cl = ControlLimits(
            mean=10, stddev=5, ucl_1sigma=15, ucl_2sigma=20, ucl_3sigma=25, sample_size=10
        )
        assert cl.classify(26) == Severity.CRITICAL

    def test_classify_falls_back_when_invalid(self):
        cl = ControlLimits(sample_size=2)
        # Falls back to Severity.from_score
        assert cl.classify(75) == Severity.CRITICAL
        assert cl.classify(5) == Severity.NOMINAL


class TestTrendResult:
    def test_no_run_default(self):
        tr = TrendResult()
        assert not tr.has_run
        assert not tr.has_trend

    def test_has_run_above(self):
        tr = TrendResult(consecutive_above_mean=7)
        assert tr.has_run

    def test_has_run_below(self):
        tr = TrendResult(consecutive_below_mean=7)
        assert tr.has_run

    def test_no_run_at_6(self):
        tr = TrendResult(consecutive_above_mean=6)
        assert not tr.has_run

    def test_has_trend(self):
        tr = TrendResult(run_length=6)
        assert tr.has_trend

    def test_no_trend_at_5(self):
        tr = TrendResult(run_length=5)
        assert not tr.has_trend


class TestSPCResult:
    def test_needs_explanation_elevated(self):
        result = SPCResult(
            score=50, severity=Severity.ELEVATED, limits=ControlLimits(), trend=TrendResult()
        )
        assert result.needs_explanation

    def test_needs_explanation_critical(self):
        result = SPCResult(
            score=80, severity=Severity.CRITICAL, limits=ControlLimits(), trend=TrendResult()
        )
        assert result.needs_explanation

    def test_needs_explanation_out_of_control(self):
        result = SPCResult(
            score=30,
            severity=Severity.LOW,
            limits=ControlLimits(),
            trend=TrendResult(),
            out_of_control=True,
        )
        assert result.needs_explanation

    def test_needs_explanation_trend(self):
        result = SPCResult(
            score=15,
            severity=Severity.NOMINAL,
            limits=ControlLimits(),
            trend=TrendResult(run_length=6),
        )
        assert result.needs_explanation

    def test_needs_explanation_run(self):
        result = SPCResult(
            score=15,
            severity=Severity.NOMINAL,
            limits=ControlLimits(),
            trend=TrendResult(consecutive_above_mean=7),
        )
        assert result.needs_explanation

    def test_no_explanation_needed_nominal(self):
        result = SPCResult(
            score=10,
            severity=Severity.NOMINAL,
            limits=ControlLimits(),
            trend=TrendResult(),
        )
        assert not result.needs_explanation


class TestSPCEngine:
    def test_empty_engine(self):
        engine = SPCEngine()
        assert engine.sample_count == 0
        assert engine.scores == []

    def test_add_score_returns_result(self):
        engine = SPCEngine()
        result = engine.add_score(DriftScore(persona=10, goal=15, instruction=5, semantic=20))
        assert isinstance(result, SPCResult)
        assert result.score == 12.5  # (10+15+5+20)/4

    def test_sample_count_increments(self):
        engine = SPCEngine()
        for i in range(5):
            engine.add_score(DriftScore(persona=float(i)))
        assert engine.sample_count == 5

    def test_window_size_enforced(self):
        engine = SPCEngine(window_size=5)
        for i in range(10):
            engine.add_score(DriftScore(persona=float(i * 10)))
        assert engine.sample_count == 5

    def test_compute_limits_empty(self):
        engine = SPCEngine()
        limits = engine.compute_limits()
        assert limits.mean == 0.0
        assert limits.sample_size == 0

    def test_compute_limits_single(self):
        engine = SPCEngine()
        engine.add_score(DriftScore(persona=40))
        limits = engine.compute_limits()
        assert limits.mean == 10.0  # 40/4
        assert limits.sample_size == 1

    def test_compute_limits_known_values(self):
        engine = SPCEngine()
        # Add known values: composites will be 10, 20, 30, 40, 50
        for val in [10, 20, 30, 40, 50]:
            engine.add_score(
                DriftScore(
                    persona=float(val),
                    goal=float(val),
                    instruction=float(val),
                    semantic=float(val),
                )
            )
        limits = engine.compute_limits()
        assert limits.mean == pytest.approx(30.0)
        expected_std = math.sqrt(sum((x - 30) ** 2 for x in [10, 20, 30, 40, 50]) / 4)
        assert limits.stddev == pytest.approx(expected_std, abs=0.1)
        assert limits.ucl_1sigma == pytest.approx(30.0 + expected_std, abs=0.1)
        assert limits.ucl_2sigma == pytest.approx(30.0 + 2 * expected_std, abs=0.1)
        assert limits.ucl_3sigma == pytest.approx(30.0 + 3 * expected_std, abs=0.1)

    def test_lcl_floors_at_zero(self):
        engine = SPCEngine()
        # Low values with large stddev
        for val in [1, 2, 1, 50, 1]:
            engine.add_score(
                DriftScore(
                    persona=float(val),
                    goal=float(val),
                    instruction=float(val),
                    semantic=float(val),
                )
            )
        limits = engine.compute_limits()
        assert limits.lcl_1sigma >= 0.0

    def test_compute_axis_limits(self):
        engine = SPCEngine()
        for i in range(5):
            engine.add_score(
                DriftScore(
                    persona=float(i * 10),
                    goal=float(i * 5),
                    instruction=float(i * 3),
                    semantic=float(i * 8),
                )
            )
        axis_limits = engine.compute_axis_limits()
        assert "persona" in axis_limits
        assert "goal" in axis_limits
        assert axis_limits["persona"].mean > axis_limits["goal"].mean

    def test_severity_from_spc(self):
        engine = SPCEngine()
        # Build baseline with low scores
        for _ in range(10):
            engine.add_score(DriftScore(persona=5, goal=5, instruction=5, semantic=5))
        # Spike should be CRITICAL relative to baseline
        result = engine.add_score(DriftScore(persona=95, goal=95, instruction=95, semantic=95))
        assert result.severity in (Severity.ELEVATED, Severity.CRITICAL)

    def test_reset(self):
        engine = SPCEngine()
        for i in range(5):
            engine.add_score(DriftScore(persona=float(i)))
        engine.reset()
        assert engine.sample_count == 0
        assert engine.scores == []


class TestTrendDetection:
    def test_no_trend_with_few_points(self):
        engine = SPCEngine()
        engine.add_score(DriftScore(persona=10))
        trend = engine.detect_trend()
        assert not trend.has_trend

    def test_increasing_trend_detected(self):
        engine = SPCEngine()
        for i in range(8):
            engine.add_score(
                DriftScore(
                    persona=float(i * 5),
                    goal=float(i * 5),
                    instruction=float(i * 5),
                    semantic=float(i * 5),
                )
            )
        trend = engine.detect_trend()
        assert trend.trending_up

    def test_run_above_mean(self):
        engine = SPCEngine()
        # Start with low scores to set mean low
        for _ in range(3):
            engine.add_score(DriftScore(persona=5, goal=5, instruction=5, semantic=5))
        # Then 8 high scores — all above the new mean
        for _ in range(8):
            engine.add_score(DriftScore(persona=50, goal=50, instruction=50, semantic=50))
        trend = engine.detect_trend()
        assert trend.consecutive_above_mean >= 7

    def test_stable_process_no_flags(self):
        engine = SPCEngine()
        # Scores with natural variance — not identical
        values = [18, 22, 19, 21, 20, 23, 17, 20, 21, 19]
        for v in values:
            engine.add_score(
                DriftScore(persona=float(v), goal=float(v), instruction=float(v), semantic=float(v))
            )
        # A value well within the normal range
        result = engine.add_score(DriftScore(persona=20, goal=20, instruction=20, semantic=20))
        assert result.severity == Severity.NOMINAL
        assert not result.out_of_control


class TestOutOfControl:
    def test_beyond_3sigma(self):
        engine = SPCEngine()
        for _ in range(10):
            engine.add_score(DriftScore(persona=10, goal=10, instruction=10, semantic=10))
        result = engine.add_score(DriftScore(persona=100, goal=100, instruction=100, semantic=100))
        assert result.out_of_control

    def test_two_of_three_beyond_2sigma(self):
        engine = SPCEngine()
        # Build baseline
        for _ in range(10):
            engine.add_score(DriftScore(persona=10, goal=10, instruction=10, semantic=10))
        # Two high scores in a row (should trigger 2-of-3 rule)
        engine.add_score(DriftScore(persona=60, goal=60, instruction=60, semantic=60))
        result = engine.add_score(DriftScore(persona=60, goal=60, instruction=60, semantic=60))
        assert result.out_of_control

    def test_not_out_of_control_normal(self):
        engine = SPCEngine()
        # Scores with natural variance
        values = [18, 22, 19, 21, 20, 23, 17, 20, 21, 19]
        for v in values:
            engine.add_score(
                DriftScore(persona=float(v), goal=float(v), instruction=float(v), semantic=float(v))
            )
        # A value within the normal range
        result = engine.add_score(DriftScore(persona=21, goal=21, instruction=21, semantic=21))
        assert not result.out_of_control
