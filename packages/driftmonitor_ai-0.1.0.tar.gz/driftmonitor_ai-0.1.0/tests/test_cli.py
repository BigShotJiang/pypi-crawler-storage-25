"""Tests for driftmonitor.cli."""

from __future__ import annotations

import typing

import pytest
from typer.testing import CliRunner

if typing.TYPE_CHECKING:
    from pathlib import Path

from driftmonitor.cli import app
from driftmonitor.models import DriftEvent, DriftScore
from driftmonitor.store import DriftStore

runner = CliRunner()


@pytest.fixture
def populated_db(tmp_db: Path) -> Path:
    """Create a database with sample data."""
    store = DriftStore(db_path=tmp_db)
    store.create_session("sess-001", name="Test Session", session_type="conversation")
    store.create_session("sess-002", name="Agent Run", session_type="agent")

    for i in range(5):
        store.insert_event(
            DriftEvent(
                session_id="sess-001",
                turn_number=i,
                scores=DriftScore(
                    persona=float(i * 5),
                    goal=float(i * 10),
                    instruction=float(i * 3),
                    semantic=float(i * 8),
                ),
                user_content=f"User message {i}",
                assistant_content=f"Assistant response {i}",
                anchor_distance=i * 0.05,
            )
        )
    store.close()
    return tmp_db


class TestSessionsCommand:
    def test_sessions_lists_all(self, populated_db: Path):
        result = runner.invoke(app, ["sessions", "--db", str(populated_db)])
        assert result.exit_code == 0
        assert "sess-001" in result.output
        assert "sess-002" in result.output
        assert "Test Session" in result.output

    def test_sessions_empty_db(self, tmp_db: Path):
        # Must create the db file first so the CLI finds it
        store = DriftStore(db_path=tmp_db)
        _ = store.conn  # trigger schema creation
        store.close()
        result = runner.invoke(app, ["sessions", "--db", str(tmp_db)])
        assert result.exit_code == 0
        assert "No sessions found" in result.output

    def test_sessions_missing_db(self, tmp_path: Path):
        result = runner.invoke(app, ["sessions", "--db", str(tmp_path / "nope.db")])
        assert result.exit_code == 1
        assert "not found" in result.output


class TestScoresCommand:
    def test_scores_shows_events(self, populated_db: Path):
        result = runner.invoke(app, ["scores", "sess-001", "--db", str(populated_db)])
        assert result.exit_code == 0
        assert "Test Session" in result.output or "sess-001" in result.output

    def test_scores_with_limit(self, populated_db: Path):
        result = runner.invoke(
            app, ["scores", "sess-001", "--db", str(populated_db), "--limit", "2"]
        )
        assert result.exit_code == 0

    def test_scores_nonexistent_session(self, populated_db: Path):
        result = runner.invoke(app, ["scores", "nope", "--db", str(populated_db)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_scores_empty_session(self, populated_db: Path):
        result = runner.invoke(app, ["scores", "sess-002", "--db", str(populated_db)])
        assert result.exit_code == 0
        assert "No events" in result.output


class TestSummaryCommand:
    def test_summary_shows_stats(self, populated_db: Path):
        result = runner.invoke(app, ["summary", "sess-001", "--db", str(populated_db)])
        assert result.exit_code == 0
        assert "Total Turns" in result.output
        assert "Avg Composite" in result.output

    def test_summary_nonexistent_session(self, populated_db: Path):
        result = runner.invoke(app, ["summary", "nope", "--db", str(populated_db)])
        assert result.exit_code == 1
        assert "not found" in result.output

    def test_summary_empty_session(self, populated_db: Path):
        result = runner.invoke(app, ["summary", "sess-002", "--db", str(populated_db)])
        assert result.exit_code == 0
        assert "No events" in result.output


class TestServeCommand:
    def test_serve_shows_in_help(self):
        result = runner.invoke(app, ["serve", "--help"])
        assert result.exit_code == 0
        assert "Launch" in result.output or "API" in result.output


class TestVersionCommand:
    def test_version(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "driftmonitor v" in result.output


class TestNoArgsHelp:
    def test_no_args_shows_help(self):
        result = runner.invoke(app, [])
        # no_args_is_help causes exit code 0, but typer runner may use 2
        assert result.exit_code in (0, 2)
        output = result.output.lower()
        assert "drift" in output or "usage" in output or "commands" in output
