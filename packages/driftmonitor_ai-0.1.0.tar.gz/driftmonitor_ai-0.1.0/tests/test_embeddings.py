"""Tests for driftmonitor.embeddings."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from driftmonitor.embeddings import _AXIS_PROMPTS, EmbeddingEngine


class TestEmbeddingEngineLazyLoad:
    def test_model_not_loaded_on_init(self):
        engine = EmbeddingEngine()
        assert engine._model is None

    @patch("sentence_transformers.SentenceTransformer")
    def test_model_loaded_on_first_access(self, mock_cls):
        mock_cls.return_value = MagicMock()
        engine = EmbeddingEngine("test-model")
        _ = engine.model
        mock_cls.assert_called_once_with("test-model")

    @patch("sentence_transformers.SentenceTransformer")
    def test_model_cached_after_first_load(self, mock_cls):
        mock_cls.return_value = MagicMock()
        engine = EmbeddingEngine()
        _ = engine.model
        _ = engine.model
        mock_cls.assert_called_once()


class TestCosineDistance:
    def setup_method(self):
        self.engine = EmbeddingEngine.__new__(EmbeddingEngine)
        self.engine.model_name = "test"
        self.engine._model = None

    def test_identical_vectors(self):
        vec = [1.0, 0.0, 0.0]
        assert self.engine.cosine_distance(vec, vec) == pytest.approx(0.0, abs=1e-6)

    def test_orthogonal_vectors(self):
        a = [1.0, 0.0, 0.0]
        b = [0.0, 1.0, 0.0]
        assert self.engine.cosine_distance(a, b) == pytest.approx(1.0, abs=1e-6)

    def test_opposite_vectors(self):
        a = [1.0, 0.0, 0.0]
        b = [-1.0, 0.0, 0.0]
        assert self.engine.cosine_distance(a, b) == pytest.approx(2.0, abs=1e-6)

    def test_similar_vectors(self):
        a = [1.0, 1.0, 0.0]
        b = [1.0, 0.9, 0.1]
        dist = self.engine.cosine_distance(a, b)
        assert 0.0 < dist < 0.1

    def test_zero_vector_a(self):
        a = [0.0, 0.0, 0.0]
        b = [1.0, 1.0, 1.0]
        assert self.engine.cosine_distance(a, b) == 1.0

    def test_zero_vector_b(self):
        a = [1.0, 1.0, 1.0]
        b = [0.0, 0.0, 0.0]
        assert self.engine.cosine_distance(a, b) == 1.0

    def test_both_zero_vectors(self):
        z = [0.0, 0.0]
        assert self.engine.cosine_distance(z, z) == 1.0

    def test_high_dimensional(self):
        rng = np.random.default_rng(42)
        a = rng.random(384).tolist()
        b = rng.random(384).tolist()
        dist = self.engine.cosine_distance(a, b)
        assert 0.0 <= dist <= 2.0

    def test_symmetry(self):
        a = [1.0, 2.0, 3.0]
        b = [4.0, 5.0, 6.0]
        assert self.engine.cosine_distance(a, b) == pytest.approx(
            self.engine.cosine_distance(b, a), abs=1e-10
        )


class TestCosineSimilarity:
    def setup_method(self):
        self.engine = EmbeddingEngine.__new__(EmbeddingEngine)
        self.engine.model_name = "test"
        self.engine._model = None

    def test_identical(self):
        vec = [1.0, 2.0, 3.0]
        assert self.engine.cosine_similarity(vec, vec) == pytest.approx(1.0, abs=1e-6)

    def test_orthogonal(self):
        a = [1.0, 0.0]
        b = [0.0, 1.0]
        assert self.engine.cosine_similarity(a, b) == pytest.approx(0.0, abs=1e-6)

    def test_inverse_of_distance(self):
        a = [1.0, 2.0, 3.0]
        b = [3.0, 2.0, 1.0]
        dist = self.engine.cosine_distance(a, b)
        sim = self.engine.cosine_similarity(a, b)
        assert dist + sim == pytest.approx(1.0, abs=1e-10)


class TestEmbed:
    @patch("sentence_transformers.SentenceTransformer")
    def test_embed_returns_list(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.1, 0.2, 0.3])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        result = engine.embed("hello")
        assert isinstance(result, list)
        assert len(result) == 3
        assert result[0] == pytest.approx(0.1)

    @patch("sentence_transformers.SentenceTransformer")
    def test_embed_passes_text(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.0])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        engine.embed("test input")
        mock_model.encode.assert_called_once_with("test input", convert_to_numpy=True)

    @patch("sentence_transformers.SentenceTransformer")
    def test_embed_with_axis(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.0])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        engine.embed_with_axis("hello", "persona")
        call_args = mock_model.encode.call_args[0][0]
        assert call_args.startswith(_AXIS_PROMPTS["persona"])
        assert "hello" in call_args

    @patch("sentence_transformers.SentenceTransformer")
    def test_embed_with_unknown_axis(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.0])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        engine.embed_with_axis("hello", "unknown")
        call_args = mock_model.encode.call_args[0][0]
        assert call_args == "hello"


class TestScoreDrift:
    @patch("sentence_transformers.SentenceTransformer")
    def test_score_returns_all_axes(self, mock_cls):
        mock_model = MagicMock()
        # Return slightly different vectors each time to produce non-zero scores
        call_count = 0

        def fake_encode(text, convert_to_numpy=True):
            nonlocal call_count
            call_count += 1
            base = np.array([1.0, 0.0, 0.0])
            noise = np.array([0.0, 0.01 * call_count, 0.0])
            return base + noise

        mock_model.encode.side_effect = fake_encode
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        anchor = [1.0, 0.0, 0.0]
        result = engine.score_drift(anchor, "some text")

        assert "persona" in result
        assert "goal" in result
        assert "instruction" in result
        assert "semantic" in result
        assert "composite" in result
        assert "raw_distance" in result

    @patch("sentence_transformers.SentenceTransformer")
    def test_score_values_are_bounded(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.5, 0.5, 0.5])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        anchor = [1.0, 0.0, 0.0]
        result = engine.score_drift(anchor, "text")

        for axis in ["persona", "goal", "instruction", "semantic", "composite"]:
            assert 0.0 <= result[axis] <= 100.0

    @patch("sentence_transformers.SentenceTransformer")
    def test_identical_text_low_score(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([1.0, 0.0, 0.0])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        anchor = [1.0, 0.0, 0.0]
        result = engine.score_drift(anchor, "same text")

        assert result["composite"] < 10.0


class TestCreateAnchor:
    @patch("sentence_transformers.SentenceTransformer")
    def test_create_anchor(self, mock_cls):
        mock_model = MagicMock()
        mock_model.encode.return_value = np.array([0.5, 0.3, 0.2])
        mock_cls.return_value = mock_model

        engine = EmbeddingEngine()
        anchor = engine.create_anchor("reference text")
        assert isinstance(anchor, list)
        assert len(anchor) == 3


class TestAxisPrompts:
    def test_all_axes_have_prompts(self):
        for axis in ["persona", "goal", "instruction", "semantic"]:
            assert axis in _AXIS_PROMPTS
            assert len(_AXIS_PROMPTS[axis]) > 0

    def test_prompts_end_with_space(self):
        for prompt in _AXIS_PROMPTS.values():
            assert prompt.endswith(": ")
