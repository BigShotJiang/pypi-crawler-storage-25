from dataclasses import dataclass

from .SystemEvent import SystemEvent


@dataclass(frozen=True, kw_only=True)
class SystemShutdownEvent(SystemEvent):
    
    reason: str = "User exit"