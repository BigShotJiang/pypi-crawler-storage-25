from dataclasses import dataclass

from .SystemEvent import SystemEvent


@dataclass(frozen=True, kw_only=True)
class DiscoveryStartedEvent(SystemEvent):

    count: int