from dataclasses import dataclass
from typing import Any, Dict

from .SystemEvent import SystemEvent


@dataclass(frozen=True, kw_only=True)
class HealthReportEvent(SystemEvent):

    source: str  # e.g., "CPU", "RAM"
    data: Dict[str, Any]