from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True, kw_only=True)
class SystemEvent:

    timestamp: datetime = field(default_factory=datetime.now)
