from .CPUStatus import CPUStatus

__all__ = ["CPUStatus"]