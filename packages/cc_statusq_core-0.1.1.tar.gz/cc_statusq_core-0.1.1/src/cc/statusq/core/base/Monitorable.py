from typing import Protocol, runtime_checkable


@runtime_checkable
class Monitorable(Protocol):

    def get_id(self) -> str: ...
    def pulse(self) -> None: ...  
    def start_stream(self, interval: float) -> None: ...

    @property
    def requires_main_thread(self) -> bool:
        return False
