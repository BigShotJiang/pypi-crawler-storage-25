import json
import threading
import time
from collections import deque
from mcp.server.fastmcp import FastMCP

import paho.mqtt.client as mqtt

import os
import argparse
import sys

# --- Configuration (using environment variables) ---
MQTT_BROKER = os.getenv("MQTT_BROKER", "be18721454da4600b14a92424bb1181c.s1.eu.hivemq.cloud")
MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "meimeifarm/Spectrum")
MQTT_USER = os.getenv("MQTT_USER", "meimeifarm")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "Meimei83036666")

# Shared state updated by MQTT callback
latest_spectrum = {}
spectrum_history = deque(maxlen=100)  # 增加历史记录容量到100条
last_update_time = None
mqtt_connected = False

def _on_connect(client, userdata, flags, rc):
    global mqtt_connected
    if rc == 0:
        mqtt_connected = True
        client.subscribe(MQTT_TOPIC)
        print(f"[MQTT] Connected successfully, subscribed to {MQTT_TOPIC}", file=sys.stderr)
    else:
        mqtt_connected = False
        print(f"[MQTT] Connect failed with code {rc}", file=sys.stderr)

def _on_message(client, userdata, msg):
    global latest_spectrum, spectrum_history, last_update_time
    try:
        payload = msg.payload.decode('utf-8')
        data = json.loads(payload)
        if isinstance(data, dict):
            latest_spectrum = data
            last_update_time = time.time()
            
            # 记录当前时间并保存到历史记录
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            spectrum_history.append({
                "timestamp": timestamp,
                "channels": data.copy()
            })
            
            # 统计通道数量
            channel_count = len([k for k in data.keys() if k.startswith('channel')])
            print(f"[MQTT] Received spectrum data: {channel_count} channels at {timestamp}", file=sys.stderr)
    except Exception as e:
        print(f"[MQTT] Message parse error: {e}", file=sys.stderr)

def _on_disconnect(client, userdata, rc):
    global mqtt_connected
    mqtt_connected = False
    if rc != 0:
        print(f"[MQTT] Unexpected disconnection, code: {rc}", file=sys.stderr)
    else:
        print("[MQTT] Disconnected", file=sys.stderr)

def start_mqtt():
    client = mqtt.Client()
    if MQTT_USER:
        client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    
    # If using TLS port, enable TLS (use default CA certs)
    if MQTT_PORT == 8883:
        try:
            client.tls_set()
            print("[MQTT] TLS enabled for secure connection", file=sys.stderr)
        except Exception as e:
            print(f"[MQTT] TLS setup warning: {e}", file=sys.stderr)

    client.on_connect = _on_connect
    client.on_message = _on_message
    client.on_disconnect = _on_disconnect

    try:
        print(f"[MQTT] Connecting to {MQTT_BROKER}:{MQTT_PORT}...", file=sys.stderr)
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    except Exception as e:
        print(f"[MQTT] Connect error: {e}", file=sys.stderr)
        return None

    client.loop_start()
    return client


# --- FastMCP server exposing spectrum ---
mcp = FastMCP("Spectrum")

@mcp.resource("spectrum://latest")
def get_latest_spectrum() -> dict:
    """Return the latest spectrum payload received over MQTT with metadata."""
    if not latest_spectrum:
        return {
            "status": "no_data",
            "message": "No spectrum data received yet. Waiting for MQTT messages...",
            "mqtt_connected": mqtt_connected
        }
    
    return {
        "status": "ok",
        "data": latest_spectrum,
        "last_update": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_time)) if last_update_time else None,
        "mqtt_connected": mqtt_connected
    }

@mcp.resource("spectrum://history")
def get_spectrum_history_resource() -> dict:
    """Return the last 100 spectrum payloads received over MQTT."""
    if not spectrum_history:
        return {
            "status": "no_data",
            "message": "No historical data available yet.",
            "mqtt_connected": mqtt_connected
        }
    
    return {
        "status": "ok",
        "count": len(spectrum_history),
        "history": list(spectrum_history),
        "mqtt_connected": mqtt_connected
    }

@mcp.tool()
def get_spectrum_history(limit: int = 10) -> dict:
    """Tool to return the last N spectrum payloads received over MQTT.
    
    Args:
        limit: Number of historical records to return (default: 10, max: 100)
    """
    if not spectrum_history:
        return {
            "status": "no_data",
            "message": "Data is empty. The MCP server process has not received any MQTT data yet. Please wait for the hardware to upload the next message.",
            "mqtt_connected": mqtt_connected
        }
    
    # 限制返回数量
    limit = min(max(1, limit), 100)
    history_list = list(spectrum_history)[-limit:]
    
    return {
        "status": "ok",
        "count": len(history_list),
        "requested_limit": limit,
        "history": history_list,
        "mqtt_connected": mqtt_connected
    }

@mcp.tool()
def get_channel(name: str) -> dict:
    """Get an individual channel value by key, e.g. 'channel1'.
    
    Args:
        name: Channel name (e.g., 'channel1', 'channel2', etc.)
    
    Returns:
        Dictionary with channel value and metadata
    """
    if not latest_spectrum:
        return {
            "status": "no_data",
            "message": "No spectrum data available. Waiting for MQTT messages...",
            "mqtt_connected": mqtt_connected
        }
    
    if name not in latest_spectrum:
        available_channels = [k for k in latest_spectrum.keys() if k.startswith('channel')]
        return {
            "status": "error",
            "message": f"Channel '{name}' not found",
            "available_channels": available_channels
        }
    
    try:
        value = int(latest_spectrum.get(name, 0))
        return {
            "status": "ok",
            "channel": name,
            "value": value,
            "last_update": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_time)) if last_update_time else None
        }
    except (ValueError, TypeError):
        return {
            "status": "error",
            "message": f"Cannot convert channel '{name}' value to integer",
            "raw_value": latest_spectrum.get(name)
        }
@mcp.resource("spectrum://channels")
def get_all_channels() -> dict:
    """Return all channel values as ints when possible with metadata.

    This resource returns the full latest spectrum payload. It will try to
    convert numeric-looking values to `int`, and leave other values as-is.
    """
    if not latest_spectrum:
        return {
            "status": "no_data",
            "message": "No spectrum data available. Waiting for MQTT messages...",
            "mqtt_connected": mqtt_connected
        }
    
    out = {}
    for k, v in latest_spectrum.items():
        try:
            out[k] = int(v)
        except Exception:
            out[k] = v
    
    return {
        "status": "ok",
        "channels": out,
        "channel_count": len([k for k in out.keys() if k.startswith('channel')]),
        "last_update": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_time)) if last_update_time else None,
        "mqtt_connected": mqtt_connected
    }
@mcp.tool()
def get_all_spectrum() -> dict:
    """Tool to return the full latest spectrum payload with metadata.

    Tries to convert numeric-looking values to `int`, leaves others as-is.
    Returns comprehensive information about the spectrum data.
    """
    if not latest_spectrum:
        return {
            "status": "no_data",
            "message": "Data is empty. The MCP server process has not received any MQTT data yet. Please wait for the hardware to upload the next message.",
            "mqtt_connected": mqtt_connected
        }
    
    out = {}
    for k, v in latest_spectrum.items():
        try:
            out[k] = int(v)
        except Exception:
            out[k] = v
    
    return {
        "status": "ok",
        "channels": out,
        "channel_count": len([k for k in out.keys() if k.startswith('channel')]),
        "last_update": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_time)) if last_update_time else None,
        "mqtt_connected": mqtt_connected,
        "data_age_seconds": int(time.time() - last_update_time) if last_update_time else None
    }
@mcp.tool()
def get_server_status() -> dict:
    """Get the current status of the MCP server and MQTT connection.
    
    Returns information about server health, connection status, and data availability.
    """
    return {
        "status": "running",
        "mqtt_connected": mqtt_connected,
        "mqtt_broker": MQTT_BROKER,
        "mqtt_topic": MQTT_TOPIC,
        "has_data": bool(latest_spectrum),
        "history_count": len(spectrum_history),
        "last_update": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_update_time)) if last_update_time else None,
        "data_age_seconds": int(time.time() - last_update_time) if last_update_time else None
    }

def main():
    parser = argparse.ArgumentParser(description='Spectrum MCP Server - Stravision IoT Platform')
    parser.add_argument('--no-mqtt', action='store_true', help='Do not start MQTT client (for testing)')
    args = parser.parse_args()

    print("=" * 60, file=sys.stderr)
    print("Spectrum MCP Server - Stravision IoT Platform", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"MQTT Broker: {MQTT_BROKER}:{MQTT_PORT}", file=sys.stderr)
    print(f"MQTT Topic: {MQTT_TOPIC}", file=sys.stderr)
    print(f"Transport: {os.environ.get('MCP_TRANSPORT', 'stdio')}", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    
    mqtt_client = None
    if not args.no_mqtt:
        mqtt_client = start_mqtt()
        if mqtt_client:
            print("[Server] MQTT client started successfully", file=sys.stderr)
        else:
            print("[Server] WARNING: MQTT client failed to start", file=sys.stderr)
    else:
        print("[Server] Running in no-MQTT mode (testing)", file=sys.stderr)

    transport = os.environ.get('MCP_TRANSPORT', 'stdio')
    print(f"[Server] Starting MCP server with {transport} transport...", file=sys.stderr)
    
    try:
        mcp.run(transport=transport)
    except KeyboardInterrupt:
        print("\n[Server] Shutting down gracefully...", file=sys.stderr)
    except Exception as e:
        print(f"[Server] Error: {e}", file=sys.stderr)
    finally:
        if mqtt_client:
            mqtt_client.loop_stop()
            try:
                mqtt_client.disconnect()
                print("[Server] MQTT client disconnected", file=sys.stderr)
            except Exception:
                pass
        print("[Server] Shutdown complete", file=sys.stderr)


if __name__ == '__main__':
    main()
