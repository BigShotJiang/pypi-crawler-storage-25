import json
import re
import asyncio
from time import time
from urllib.parse import parse_qs

from .redis_config import KEY_PREFIX, get_redis
from .tenant.tenant import aset_tenant

_CHANNEL_NAME_RE = re.compile(r'^[A-Za-z0-9_\-.]{1,64}$')

try:
    from channels.generic.websocket import AsyncWebsocketConsumer
    _CHANNELS_AVAILABLE = True
except ImportError:
    AsyncWebsocketConsumer = object
    _CHANNELS_AVAILABLE = False


def _key(key):
    return f'{KEY_PREFIX}{key}'


class BaseWSConsumer(AsyncWebsocketConsumer):
    """
    Base WebSocket consumer for easyapi projects.

    Handles automatically:
    - Session auth via cookie
    - Tenant activation (aset_tenant)
    - Channel subscriptions (account, user, custom)
    - Redis pub/sub relay
    - Ping, subscribe, status messages
    - Online presence tracking (opt-in)
    - UUID fallback for unauthenticated flows (signup, etc.)
    - Cleanup on disconnect

    Override these hooks in your project:
    - on_connect(user)    — called after successful auth
    - on_message(data)    — called for unhandled message types
    - on_disconnect()     — called before cleanup
    - on_unauthenticated_connect(uuid) — called for UUID-based connections
    """

    # Config — override in subclass if needed
    cookie_name = None          # Set from settings.COOKIE_ID
    track_online = False        # Enable online presence tracking
    allow_unauthenticated = False  # Allow UUID-based connections (signup flow)

    # Internal state
    user_id = None
    user = None
    account_id = None
    account_db = None
    uuid = None
    _channels_groups = []
    _redis = None
    _pubsub = None
    _redis_task = None

    # ── Connection lifecycle ──────────────────────────────────────

    async def connect(self):
        if not _CHANNELS_AVAILABLE:
            raise RuntimeError(
                "BaseWSConsumer requires the 'channels' package to be installed"
            )
        cookie_id = self.cookie_name
        if not cookie_id:
            try:
                from settings.settings import COOKIE_ID
                cookie_id = COOKIE_ID
            except ImportError:
                cookie_id = 'sid'

        # Parse cookies from headers
        sid = self._get_cookie(cookie_id)

        if sid:
            session = await self._get_session(sid)
            if session:
                await self._setup_authenticated(session)
                return

        # Fallback: UUID-based connection
        query_string = self.scope.get('query_string', b'').decode()
        query_params = parse_qs(query_string)
        uuid = query_params.get('uuid', [None])[0]

        if uuid and self.allow_unauthenticated:
            await self._setup_unauthenticated(uuid)
            return

        # No auth, no UUID: reject
        await self.accept()
        await self.send(text_data=json.dumps({'action': 'reload'}))
        await self.close()

    async def disconnect(self, close_code):
        await self.on_disconnect()

        if self.user_id and self.track_online:
            await self._update_online(offline=True)

        for group in self._channels_groups:
            await self.channel_layer.group_discard(group, self.channel_name)

        if self._redis_task:
            self._redis_task.cancel()

    async def receive(self, text_data):
        data = json.loads(text_data)
        msg_type = data.get('type') or data.get('action')

        if msg_type == 'ping':
            if self.track_online and self.user_id:
                await self._update_online()
            return

        if msg_type == 'subscribe':
            channels = data.get('data', {}).get('channels', [])
            await self._subscribe_channels(channels)
            return

        if msg_type == 'status' and self.track_online and self.user_id:
            await self._update_status(data.get('message'))
            return

        # Delegate to project hook
        await self.on_message(data)

    # ── Channel layer handler ─────────────────────────────────────

    async def update_state(self, data):
        """Relay state updates from channel layer to client."""
        await self.send(text_data=json.dumps(data))

    # ── Hooks — override in your project ──────────────────────────

    async def on_connect(self, user):
        """Called after successful authentication. Override to send initial data."""
        pass

    async def on_message(self, data):
        """Called for messages not handled by base (ping, subscribe, status)."""
        pass

    async def on_disconnect(self):
        """Called before cleanup. Override for custom disconnect logic."""
        pass

    async def on_unauthenticated_connect(self, uuid):
        """Called for UUID-based connections (signup flow, etc.)."""
        pass

    async def allowed_channels(self, user):
        """Return iterable of channel suffix names this user may subscribe to.

        Suffix is the part after ``a{account_id}.``. Return ``None`` to allow
        any well-formed channel name (legacy default), an empty list to
        block all extra subscriptions, or an explicit allowlist.
        """
        return None

    # ── Helpers — use in your project ─────────────────────────────

    async def send_state(self, keys, values, update_state=True):
        """Send an update_state message to this client."""
        await self.send(text_data=json.dumps({
            'type': 'update_state',
            'action': 'update_state',
            'keys': keys,
            'values': values,
            'update_state': update_state,
        }))

    async def send_toast(self, message, type='success', auto_close=3000):
        """Send a toast notification to this client."""
        await self.send(text_data=json.dumps({
            'action': 'toast',
            'values': {
                'message': message,
                'type': type,
                'autoClose': auto_close,
            },
        }))

    async def broadcast(self, channel, data):
        """Send data to a channel group."""
        await self.channel_layer.group_send(channel, {
            'type': 'update_state',
            **data,
        })

    async def broadcast_state(self, channel, keys, values, update_state=True):
        """Broadcast a state update to a channel group."""
        await self.channel_layer.group_send(channel, {
            'type': 'update_state',
            'action': 'update_state',
            'keys': keys,
            'values': values,
            'update_state': update_state,
        })

    async def broadcast_toast(self, channel, message, type='success', auto_close=3000):
        """Broadcast a toast to a channel group."""
        await self.channel_layer.group_send(channel, {
            'type': 'update_state',
            'action': 'toast',
            'values': {
                'message': message,
                'type': type,
                'autoClose': auto_close,
            },
        })

    @property
    def account_channel(self):
        """Channel for all users in current account."""
        return f'a{self.account_id}'

    @property
    def user_channel(self):
        """Channel for current user only."""
        return f'a{self.account_id}.u{self.user_id}'

    # ── Internal ──────────────────────────────────────────────────

    def _get_cookie(self, cookie_name):
        headers = {}
        for header in self.scope.get('headers', []):
            name, value = header
            headers[name.decode('utf-8')] = value.decode('utf-8')

        cookies = headers.get('cookie', '')
        for cookie in cookies.split(';'):
            cookie = cookie.strip()
            if '=' not in cookie:
                continue
            name, value = cookie.split('=', 1)
            if name.strip() == cookie_name:
                return value.strip()
        return None

    async def _get_session(self, sid):
        r = get_redis()
        raw = await r.get(_key(f'sessions:{sid}'))
        if raw:
            return json.loads(raw)
        return None

    async def _setup_authenticated(self, session):
        self.user = session.get('user', {})
        self.user_id = self.user.get('id')
        self.account_id = session.get('account', {}).get('id')

        if self.account_id:
            self.account_db = await aset_tenant(self.account_id)

        self._channels_groups = [
            'all',
            f'a{self.account_id}',
            f'a{self.account_id}.u{self.user_id}',
        ]
        for group in self._channels_groups:
            await self.channel_layer.group_add(group, self.channel_name)

        self._redis_task = asyncio.create_task(self._listen_redis())

        await self.accept()

        if self.track_online:
            await self._update_online()

        await self.on_connect(self.user)

    async def _setup_unauthenticated(self, uuid):
        self.uuid = uuid
        self._channels_groups = [uuid]
        for group in self._channels_groups:
            await self.channel_layer.group_add(group, self.channel_name)

        self._redis_task = asyncio.create_task(self._listen_redis())
        await self.accept()
        await self.on_unauthenticated_connect(uuid)

    async def _subscribe_channels(self, channels):
        if not self.account_id:
            return
        allowlist = await self.allowed_channels(self.user)
        for ch in channels:
            if not isinstance(ch, str) or not _CHANNEL_NAME_RE.match(ch):
                continue
            if allowlist is not None and ch not in allowlist:
                continue
            sub = f'a{self.account_id}.{ch}'
            await self.channel_layer.group_add(sub, self.channel_name)
            if self._pubsub:
                await self._pubsub.subscribe(sub)
            self._channels_groups.append(sub)

    async def _listen_redis(self):
        self._redis = get_redis()
        self._pubsub = self._redis.pubsub()

        for channel in self._channels_groups:
            await self._pubsub.subscribe(channel)

        try:
            while True:
                message = await self._pubsub.get_message(
                    ignore_subscribe_messages=True, timeout=1.0,
                )
                if message and message.get('data'):
                    data = json.loads(message['data'])
                    await self.send(text_data=json.dumps({'type': 'update_state', **data}))
                else:
                    await asyncio.sleep(1)
        except (asyncio.CancelledError, asyncio.TimeoutError):
            pass
        finally:
            for group in self._channels_groups:
                try:
                    await self._pubsub.unsubscribe(group)
                except Exception:
                    pass
            try:
                await self._pubsub.aclose()
            except Exception:
                pass

    async def _update_online(self, offline=False):
        r = get_redis()
        key = f'online:{self.account_id}:{self.user_id}'
        online = await r.get(_key(key))
        if online:
            online = json.loads(online)
        else:
            online = {
                'id': self.user_id,
                'last_seen': int(time()),
                'status': None,
                'status_change': None,
                'status_id': 0,
            }

        online['last_seen'] = int(time()) - (60 if offline else 0)
        await r.set(_key(key), json.dumps(online))

    async def _update_status(self, message):
        r = get_redis()
        key = f'online:{self.account_id}:{self.user_id}'
        online = await r.get(_key(key))
        if online:
            online = json.loads(online)
        else:
            online = {
                'id': self.user_id,
                'last_seen': int(time()),
                'status': None,
                'status_change': None,
                'status_id': 0,
            }

        online['last_seen'] = int(time())
        online['status'] = message
        await r.set(_key(key), json.dumps(online))

        # Broadcast online users to this user
        keys = await r.keys(_key(f'online:{self.account_id}:*'))
        online_users = {}
        for k in keys:
            raw = await r.get(k)
            if raw:
                user = json.loads(raw)
                if user.get('id'):
                    online_users[str(user['id'])] = user

        await self.broadcast_state(
            self.user_channel,
            ['ws', 'online'],
            online_users,
            update_state=False,
        )
