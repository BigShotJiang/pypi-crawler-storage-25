import logging
import time

from redis import StrictRedis

from .redis_config import REDIS_SERVER, REDIS_DB, KEY_PREFIX

logger = logging.getLogger(__name__)


class RateLimit(StrictRedis):
    def __init__(self):
        super().__init__(host=REDIS_SERVER, db=REDIS_DB)

    def current_milli_time(self):
        return int(round(time.time() * 1000))

    def is_blocked(self, identifier, action):
        """Check whether the identifier is currently blocked."""
        block_key = f"{KEY_PREFIX}block:{action}:{identifier}"
        return self.exists(block_key) > 0

    def track_failure(self, identifier, action="login", max_attempts=5, block_duration=900000):
        """Track failures and block once max_attempts is exceeded."""
        failure_key = f"{KEY_PREFIX}failures:{action}:{identifier}"
        p = self.pipeline()
        p.incr(failure_key)
        p.expire(failure_key, block_duration // 1000)
        count, _ = p.execute()
        if count >= max_attempts:
            block_key = f"{KEY_PREFIX}block:{action}:{identifier}"
            self.setex(block_key, block_duration // 1000, "blocked")
            return {"blocked": True, "reason": "Too many failed attempts"}
        return {"blocked": False}

    def track_pattern(self, identifier, action="abuse"):
        """Detect regular request patterns indicative of abuse.

        Reports the signal but does NOT auto-write a block key. Frontends
        retrying after a server-side error look identical to a bot when
        you only consider request timing — auto-blocking that traffic
        locked legitimate users out and was opaque to debug. Callers may
        decide to escalate based on the returned ``suspicious`` flag plus
        other signals (e.g. authenticated identity, response codes).
        """
        pattern_key = f"{KEY_PREFIX}rate_limit:pattern:{action}:{identifier}"
        now = self.current_milli_time()
        last_req = self.get(f"{pattern_key}:last")
        last_req = int(last_req) if last_req else now
        interval = now - last_req
        self.set(f"{pattern_key}:last", now)

        p = self.pipeline()
        p.lpush(f"{pattern_key}:intervals", interval)
        p.ltrim(f"{pattern_key}:intervals", 0, 9)
        p.expire(f"{pattern_key}:intervals", 3600)
        p.execute()

        intervals = self.lrange(f"{pattern_key}:intervals", 0, -1)
        if len(intervals) > 5:
            intervals = [int(i) for i in intervals]
            mean = sum(intervals) / len(intervals)
            variance = sum((x - mean) ** 2 for x in intervals) / len(intervals)
            if variance < 100:
                logger.warning(
                    'rate_limit: suspicious request pattern from %s '
                    '(action=%s, mean_interval_ms=%.0f, variance=%.2f)',
                    identifier, action, mean, variance,
                )
                return {"suspicious": True, "reason": "Regular request intervals"}
        return {"suspicious": False}

    def check_limits(self, identifier, limits, limit_type=None):
        """Check rate and abuse limits."""
        if identifier == '127.0.0.1':
            return {
                "rate_limited": False,
                "abuse": False,
                "blocked": False
            }

        action = limit_type if limit_type else "api"
        if self.is_blocked(identifier, action):
            return {"rate_limited": True, "abuse": False, "blocked": True}

        if action in ["api", "login"]:
            # Pattern detection is recorded for observability but no
            # longer short-circuits to ``abuse=True``. Timing-only
            # signals caught legitimate retry traffic (frontends
            # retrying after server-side errors look identical to bots
            # when judged by intervals alone). Real abuse is caught by
            # the count thresholds below; pattern alone goes to logs.
            self.track_pattern(identifier, "abuse")

        now = self.current_milli_time()
        type_to_check = action
        key_prefix = f"{KEY_PREFIX}rate_limit:{type_to_check}"

        # Resolve the limit config for the specific type
        limit_configs = limits.get(type_to_check, limits["api"])
        if not isinstance(limit_configs, list):
            limit_configs = [limit_configs]
        limit_abuse_configs = limits["abuse"]

        p = self.pipeline()

        # Operations for the specific type (api or login)
        for config in limit_configs:
            key = f"{key_prefix}:{config['interval']}:{identifier}"
            p.zremrangebyscore(key, 0, now - config["interval"])
            p.zcard(key)
            p.zadd(key, {f"req_{now}": now})
            p.expire(key, int(config["interval"] / 1000) + 1)

        # Abuse-tracking operations
        abuse_results = []
        for config in limit_abuse_configs:
            abuse_key = f"{KEY_PREFIX}rate_limit:abuse:{config['interval']}:{identifier}"
            p.zremrangebyscore(abuse_key, 0, now - config["interval"])
            p.zcard(abuse_key)
            p.zadd(abuse_key, {f"req_{now}": now})
            p.expire(abuse_key, int(config["interval"] / 1000) + 1)
            abuse_results.append(config["limit"])

        pipeline_results = p.execute()

        # Specific-type results
        is_rate_limited = False
        for i, config in enumerate(limit_configs):
            count_type = pipeline_results[i * 4 + 1]
            if count_type >= config["limit"]:
                is_rate_limited = True

        # Abuse results
        is_abuse = False
        for i, config_limit in enumerate(abuse_results):
            count_abuse = pipeline_results[(len(limit_configs) * 4) + (i * 4) + 1]
            if count_abuse >= config_limit:
                is_abuse = True

        return {
            "rate_limited": is_rate_limited,
            "abuse": is_abuse,
            "blocked": False
        }

    def api_limited(self, identifier, limits):
        """Check rate limits for API requests."""
        return self.check_limits(identifier, limits, "api")

    def login_limited(self, identifier, limits):
        """Check rate limits for login attempts."""
        return self.check_limits(identifier, limits, "login")


RateLimiter = RateLimit()
