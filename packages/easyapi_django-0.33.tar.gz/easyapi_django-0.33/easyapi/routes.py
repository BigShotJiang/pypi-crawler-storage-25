import json
import re

from django.urls import path, re_path
from django.http import HttpResponse, JsonResponse

from .calc_resource import Metrics
from .openapi import SCALAR_HTML, build_spec
from .redis_config import KEY_PREFIX, get_redis
from .util import validate_session_key
from .tenant.tenant import get_api_session

try:
    from settings.settings import COOKIE_ID
except Exception:
    COOKIE_ID = 'sessionid'


def get_route(route, view):
    if hasattr(view, 'as_view'):
        return re_path(rf'{route}', view.as_view())
    return path(route, view)


async def _has_valid_session(request):
    """Lightweight auth check for /docs and /openapi.json. Accepts a valid
    session cookie or X-Api-Key. Avoids importing BaseResource here."""
    api_key = request.headers.get('X-Api-Key')
    if api_key:
        session = await get_api_session(api_key)
        return bool(session)

    session_key = validate_session_key(request.COOKIES.get(COOKIE_ID))
    if not session_key:
        return False
    redis = get_redis()
    raw = await redis.get(f'{KEY_PREFIX}sessions:{session_key}')
    return bool(raw)


def get_routes(endpoints, **kwargs):
    """Build the URL patterns for the given resources.

    Always registers ``/openapi.json`` and ``/docs``. Pass ``docs_public=True``
    to make them anonymous; default is ``False`` (requires the same auth as
    the rest of the API — session cookie or X-Api-Key).
    """
    spec_title = kwargs.get('title', 'easyapi')
    spec_version = kwargs.get('version', '1.0.0')
    spec_description = kwargs.get('description')
    docs_public = kwargs.get('docs_public', False)

    async def openapi_json(request, *args, **kwargs):
        if not docs_public and not await _has_valid_session(request):
            return JsonResponse(
                {'success': False, 'status': 401, 'detail': 'Not authorized'},
                status=401,
            )
        spec = build_spec(
            endpoints, title=spec_title, version=spec_version,
            description=spec_description,
        )
        return JsonResponse(spec, json_dumps_params={'indent': 2})

    async def docs_scalar(request, *args, **kwargs):
        if not docs_public and not await _has_valid_session(request):
            return JsonResponse(
                {'success': False, 'status': 401, 'detail': 'Not authorized'},
                status=401,
            )
        return HttpResponse(SCALAR_HTML)

    has_mcp = bool(kwargs.get('mcp'))

    async def index(request, *args, **kwargs):
        if not docs_public and not await _has_valid_session(request):
            return JsonResponse(
                {'success': False, 'status': 401, 'detail': 'Not authorized'},
                status=401,
            )
        return HttpResponse(_render_index_html(
            title=spec_title,
            version=spec_version,
            description=spec_description,
            endpoints=endpoints,
            has_mcp=has_mcp,
        ))

    routes = [
        get_route(key, value) for key, value in endpoints.items()
    ] + [
        path('metrics', Metrics.as_view()),
        path('openapi.json', openapi_json),
        path('docs', docs_scalar),
        path('', index),
    ]

    if kwargs.get('mcp'):
        try:
            from .mcp.resource import mcp_view
            from .mcp.tools import list_tools_public
        except ImportError:
            raise RuntimeError(
                'MCP support requires `pip install easyapi_django[mcp]`.'
            )

        async def mcp_tools_json(request, *args, **kwargs):
            if not docs_public and not await _has_valid_session(request):
                return JsonResponse(
                    {'success': False, 'status': 401, 'detail': 'Not authorized'},
                    status=401,
                )
            return JsonResponse(
                {'tools': list_tools_public(endpoints)},
                json_dumps_params={'indent': 2},
            )

        async def mcp_tools_html(request, *args, **kwargs):
            if not docs_public and not await _has_valid_session(request):
                return JsonResponse(
                    {'success': False, 'status': 401, 'detail': 'Not authorized'},
                    status=401,
                )
            tools = list_tools_public(endpoints)
            return HttpResponse(_render_mcp_tools_html(tools))

        routes += [
            path('mcp', mcp_view(endpoints)),
            path('mcp/tools.json', mcp_tools_json),
            path('mcp/tools', mcp_tools_html),
        ]

    return routes


_MCP_TOOLS_TEMPLATE = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<title>MCP tools — easyapi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body {{ font: 15px/1.5 system-ui, sans-serif; max-width: 960px; margin: 2rem auto; padding: 0 1rem; color: #1f2937; }}
  h1 {{ font-size: 1.5rem; margin-bottom: 0.25rem; }}
  .lead {{ color: #6b7280; margin-bottom: 2rem; }}
  .tool {{ border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem 1.25rem; margin-bottom: 1rem; }}
  .tool-name {{ font-family: ui-monospace, monospace; font-weight: 600; color: #0f766e; }}
  .tool-desc {{ margin: 0.5rem 0 0.75rem; color: #374151; }}
  details {{ margin-top: 0.5rem; }}
  summary {{ cursor: pointer; color: #6b7280; font-size: 0.875rem; }}
  pre {{ background: #f3f4f6; padding: 0.75rem; border-radius: 6px; overflow-x: auto; font-size: 0.8125rem; }}
  .meta {{ display: inline-block; padding: 0.125rem 0.5rem; background: #f0fdfa; color: #0f766e; border-radius: 4px; font-size: 0.75rem; margin-left: 0.5rem; }}
  .empty {{ color: #6b7280; font-style: italic; }}
</style>
</head><body>
<h1>MCP tools</h1>
<p class="lead">{count} tool(s) generated from your resources. <a href="tools.json">JSON</a> · <a href="../docs">REST docs</a></p>
{body}
</body></html>"""


def _render_mcp_tools_html(tools):
    if not tools:
        body = '<p class="empty">No MCP tools registered yet.</p>'
    else:
        body = ''.join(_render_tool(t) for t in tools)
    return _MCP_TOOLS_TEMPLATE.format(count=len(tools), body=body)


_INDEX_TEMPLATE = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<title>{title} — easyapi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body {{ font: 15px/1.5 system-ui, sans-serif; max-width: 760px; margin: 3rem auto; padding: 0 1rem; color: #1f2937; }}
  h1 {{ font-size: 1.75rem; margin-bottom: 0.25rem; }}
  .lead {{ color: #6b7280; margin-bottom: 2rem; }}
  .version {{ color: #9ca3af; font-size: 0.875rem; }}
  h2 {{ font-size: 1rem; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7280;
       margin: 2rem 0 0.5rem; }}
  ul {{ list-style: none; padding: 0; margin: 0; }}
  li {{ border-bottom: 1px solid #e5e7eb; padding: 0.75rem 0; }}
  li:last-child {{ border-bottom: none; }}
  a {{ color: #0f766e; text-decoration: none; font-family: ui-monospace, monospace; font-weight: 500; }}
  a:hover {{ text-decoration: underline; }}
  .desc {{ display: block; color: #6b7280; font-size: 0.875rem; font-family: system-ui, sans-serif;
           font-weight: normal; margin-top: 0.125rem; }}
  .badge {{ display: inline-block; padding: 0.125rem 0.5rem; background: #f0fdfa; color: #0f766e;
            border-radius: 4px; font-size: 0.7rem; margin-left: 0.5rem; vertical-align: middle; }}
  .empty {{ color: #9ca3af; font-style: italic; }}
  footer {{ margin-top: 3rem; padding-top: 1.5rem; border-top: 1px solid #e5e7eb;
            color: #9ca3af; font-size: 0.8125rem; }}
</style>
</head><body>
<h1>{title}</h1>
<p class="lead">{description}<span class="version"> · v{version}</span></p>

<h2>Documentation</h2>
<ul>
  <li><a href="docs">/docs</a> <span class="badge">Scalar UI</span>
    <span class="desc">Interactive REST API reference — try requests in the browser.</span></li>
  <li><a href="openapi.json">/openapi.json</a> <span class="badge">spec</span>
    <span class="desc">OpenAPI 3.0.3 spec — generated from your resources, ready for codegen.</span></li>
{mcp_section}
</ul>

<h2>Resources ({resource_count})</h2>
<ul>
{resources_list}
</ul>

<footer>
  Generated by <a href="https://github.com/ssjunior/easyapi-django">easyapi-django</a>.
</footer>
</body></html>"""


def _render_index_html(*, title, version, description, endpoints, has_mcp):
    description = description or 'REST API generated by easyapi-django.'

    if has_mcp:
        mcp_section = """
  <li><a href="mcp/tools">/mcp/tools</a> <span class="badge">agents</span>
    <span class="desc">MCP tool registry — what LLM agents see and can call.</span></li>
  <li><a href="mcp/tools.json">/mcp/tools.json</a> <span class="badge">spec</span>
    <span class="desc">Tool definitions in JSON format.</span></li>
  <li><a href="mcp">/mcp</a> <span class="badge">JSON-RPC</span>
    <span class="desc">JSON-RPC 2.0 endpoint (POST). Agents call tools through here.</span></li>"""
    else:
        mcp_section = ''

    if not endpoints:
        resources_list = '<li class="empty">No resources registered.</li>'
    else:
        items = []
        for pattern, view_cls in endpoints.items():
            base = pattern.rstrip('$')
            base = re.sub(r'\(\.\*\)$', '', base)
            base = base.rstrip('/')
            summary = getattr(view_cls, 'summary', None)
            desc = getattr(view_cls, 'description', None) or ''
            label = summary or view_cls.__name__
            items.append(
                f'<li><a href="{base}">/{base}</a> '
                f'<span class="desc">{label}{" — " + desc if desc else ""}</span></li>'
            )
        resources_list = '\n'.join(items)

    return _INDEX_TEMPLATE.format(
        title=title,
        version=version,
        description=description,
        mcp_section=mcp_section,
        resource_count=len(endpoints),
        resources_list=resources_list,
    )


def _render_tool(tool):
    name = tool.get('name', '')
    desc = tool.get('description', '') or '<span class="empty">no description</span>'
    input_schema = json.dumps(tool.get('inputSchema') or {}, indent=2, ensure_ascii=False)
    output_schema = tool.get('outputSchema')
    out = [
        '<div class="tool">',
        f'<div class="tool-name">{name}</div>',
        f'<div class="tool-desc">{desc}</div>',
        '<details><summary>inputSchema</summary>',
        f'<pre>{input_schema}</pre>',
        '</details>',
    ]
    if output_schema:
        out_str = json.dumps(output_schema, indent=2, ensure_ascii=False)
        out.append('<details><summary>outputSchema</summary>')
        out.append(f'<pre>{out_str}</pre></details>')
    out.append('</div>')
    return ''.join(out)
