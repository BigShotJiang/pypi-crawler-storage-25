"""Generate MCP tool definitions from a `get_routes`-style endpoints map.

A tool definition is a dict with ``name``, ``description``, ``inputSchema``
and (optional) ``outputSchema``. The format mirrors what the MCP SDK
expects, so we hand it straight through.
"""
import re

from ..openapi import (
    _build_body_schema,
    _build_response_schema,
    _list_parameters,
    _model_introspect_schema,
)
from ..schemas import is_pydantic_model

_VERB_TEMPLATES = {
    'list':   {'verb_method': 'get',    'expects_id': False, 'has_body': False, 'is_write': False},
    'get':    {'verb_method': 'get',    'expects_id': True,  'has_body': False, 'is_write': False},
    'create': {'verb_method': 'post',   'expects_id': False, 'has_body': True,  'is_write': True},
    'update': {'verb_method': 'patch',  'expects_id': True,  'has_body': True,  'is_write': True},
    'delete': {'verb_method': 'delete', 'expects_id': True,  'has_body': False, 'is_write': True},
}


def _resource_label(view_cls):
    """Return the lowercase noun used in tool names. Falls back to a
    snake_case version of the class name (``SpaceResource`` → ``space``)."""
    summary = getattr(view_cls, 'summary', None)
    if summary:
        return _slugify(summary)
    name = view_cls.__name__
    if name.endswith('Resource'):
        name = name[:-len('Resource')]
    return _slugify(name)


def _slugify(value):
    s = re.sub(r'(?<!^)(?=[A-Z])', '_', str(value)).lower()
    s = re.sub(r'[^a-z0-9_]+', '_', s).strip('_')
    return s or 'resource'


def _list_input_schema(view_cls):
    """Build the inputSchema for a list tool — search, ordering,
    pagination, plus every field in `filter_fields`."""
    properties = {}
    for p in _list_parameters(view_cls):
        if p.get('in') == 'query':
            properties[p['name']] = p['schema']
    filter_fields = getattr(view_cls, 'filter_fields', None) or []
    for field in filter_fields:
        properties.setdefault(field, {'type': 'string', 'description': f'Filter by {field}.'})
    return {'type': 'object', 'properties': properties, 'additionalProperties': True}


def _detail_input_schema():
    return {
        'type': 'object',
        'properties': {'id': {'type': 'string', 'description': 'Row id.'}},
        'required': ['id'],
    }


def _write_input_schema(view_cls, kind, components):
    body_schema = _build_body_schema(view_cls, components, kind=kind)
    if kind == 'update':
        merged = {
            'type': 'object',
            'properties': {'id': {'type': 'string', 'description': 'Row id.'}},
            'required': ['id'],
            'allOf': [body_schema],
        }
        return merged
    return body_schema


def _delete_input_schema():
    return _detail_input_schema()


def _verb_exposed(view_cls, verb, write_methods):
    """Honour `mcp_expose` (False = hide entirely; list = explicit verbs)
    and the resource's own `allowed_methods`."""
    expose = getattr(view_cls, 'mcp_expose', None)
    if expose is False:
        return False
    if isinstance(expose, (list, tuple, set)) and verb not in expose:
        return False
    template = _VERB_TEMPLATES[verb]
    if template['verb_method'] not in (view_cls.allowed_methods or []):
        return False
    return True


def _custom_route_tool(view_cls, route, label, components):
    func_name = route['func']
    inst = view_cls()
    handler = getattr(inst, func_name, None)
    meta = getattr(handler, '__openapi__', {}) if handler else {}

    summary = meta.get('summary') or func_name
    description = meta.get('description') or f'{summary} on {label}.'

    input_schema = {'type': 'object', 'properties': {}, 'additionalProperties': True}
    if meta.get('request') and is_pydantic_model(meta['request']):
        input_schema = meta['request'].model_json_schema(
            ref_template='#/components/schemas/{model}'
        )

    output_schema = None
    if meta.get('response') and is_pydantic_model(meta['response']):
        output_schema = meta['response'].model_json_schema(
            ref_template='#/components/schemas/{model}'
        )

    methods = route.get('allowed_methods') or ['get']
    is_write = any(m.lower() in ('post', 'patch', 'delete') for m in methods)

    tool_name = f'{_slugify(func_name)}_{label}'
    tool = {
        'name': tool_name,
        'description': description,
        'inputSchema': input_schema,
        'mcp_internal': {
            'kind': 'custom',
            'view_cls': view_cls,
            'route': route,
            'is_write': is_write,
        },
    }
    if output_schema:
        tool['outputSchema'] = output_schema
    return tool


def list_tools(endpoints):
    """Return a list of tool definitions for the given resources."""
    tools = []
    components = {'schemas': {}}
    write_methods = {'post', 'patch', 'delete'}

    for route_pattern, view_cls in endpoints.items():
        if getattr(view_cls, 'mcp_expose', None) is False:
            continue

        label = _resource_label(view_cls)
        description = getattr(view_cls, 'description', None) or f'{label} resource.'

        # Standard CRUD verbs
        for verb in ('list', 'get', 'create', 'update', 'delete'):
            if not _verb_exposed(view_cls, verb, write_methods):
                continue
            template = _VERB_TEMPLATES[verb]

            if verb == 'list':
                input_schema = _list_input_schema(view_cls)
                output_schema = {
                    'type': 'object',
                    'properties': {
                        'meta': {'type': 'object'},
                        'objects': {
                            'type': 'array',
                            'items': _build_response_schema(view_cls, components, kind='list'),
                        },
                    },
                }
            elif verb == 'get':
                input_schema = _detail_input_schema()
                output_schema = _build_response_schema(view_cls, components, kind='detail')
            elif verb == 'create':
                input_schema = _write_input_schema(view_cls, 'create', components)
                output_schema = _build_response_schema(view_cls, components, kind='detail')
            elif verb == 'update':
                input_schema = _write_input_schema(view_cls, 'update', components)
                output_schema = _build_response_schema(view_cls, components, kind='detail')
            else:  # delete
                input_schema = _delete_input_schema()
                output_schema = {'type': 'object'}

            tool_name = f'{verb}_{label}'
            tools.append({
                'name': tool_name,
                'description': description,
                'inputSchema': input_schema,
                'outputSchema': output_schema,
                'mcp_internal': {
                    'kind': verb,
                    'view_cls': view_cls,
                    'route_pattern': route_pattern,
                    'is_write': template['is_write'],
                },
            })

        # Custom routes with @openapi metadata
        for route in (view_cls.routes or []):
            tools.append(_custom_route_tool(view_cls, route, label, components))

    return tools


def list_tools_public(endpoints):
    """Same as `list_tools` but without the `mcp_internal` key — for
    inspection/registry endpoints."""
    return [
        {k: v for k, v in tool.items() if k != 'mcp_internal'}
        for tool in list_tools(endpoints)
    ]
