import asyncio
import os
import weakref

import redis.asyncio as aioredis

REDIS_SERVER = os.environ['REDIS_SERVER']
REDIS_DB = int(os.environ['REDIS_DB'])

try:
    from settings.env import REDIS_PREFIX
except ImportError:
    REDIS_PREFIX = os.environ.get('REDIS_PREFIX', '')

KEY_PREFIX = f'{REDIS_PREFIX}:' if REDIS_PREFIX else ''


# `redis.asyncio.Redis` ties its connection futures to the event loop
# it was created on. ASGI servers + ``async_to_sync`` bridges spin up
# multiple loops in the same process — a single process-global client
# crashes those calls with ``RuntimeError: got Future attached to a
# different loop``. We cache one client per loop in a WeakKeyDictionary
# so entries auto-clean when the loop is GC'd.
_clients = weakref.WeakKeyDictionary()

# Fallback for callers without a running loop (rare; sync contexts that
# manually drive the event loop). Created lazily.
_loopless_client = None


# Tests monkeypatch this attribute to inject a fake (e.g. fakeredis).
# When set, ``get_redis()`` returns it unconditionally. None in
# production, where per-loop caching takes over.
_redis_client = None


def get_redis():
    global _loopless_client

    # Test injection hook
    if _redis_client is not None:
        return _redis_client

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        if _loopless_client is None:
            _loopless_client = aioredis.Redis(
                host=REDIS_SERVER,
                db=REDIS_DB,
                decode_responses=True,
            )
        return _loopless_client

    client = _clients.get(loop)
    if client is None:
        client = aioredis.Redis(
            host=REDIS_SERVER,
            db=REDIS_DB,
            decode_responses=True,
        )
        try:
            _clients[loop] = client
        except TypeError:
            # Custom loop without weakref support — fall back to
            # returning a fresh client without caching.
            pass
    return client


async def get_cache_stats():
    redis = get_redis()
    hits = int(await redis.get(f'{KEY_PREFIX}cache_stats:hits') or 0)
    misses = int(await redis.get(f'{KEY_PREFIX}cache_stats:misses') or 0)
    total = hits + misses
    ratio = hits / total if total else 0.0

    pattern = f'{KEY_PREFIX}cache_stats:hits:*'
    by_model = {}
    async for key in redis.scan_iter(match=pattern):
        label = key.split(':hits:', 1)[1]
        h = int(await redis.get(key) or 0)
        m = int(await redis.get(f'{KEY_PREFIX}cache_stats:misses:{label}') or 0)
        t = h + m
        by_model[label] = {
            'hits': h,
            'misses': m,
            'total': t,
            'ratio': h / t if t else 0.0,
        }

    return {
        'hits': hits,
        'misses': misses,
        'total': total,
        'ratio': ratio,
        'by_model': by_model,
    }


async def reset_cache_stats():
    redis = get_redis()
    pattern = f'{KEY_PREFIX}cache_stats:*'
    keys = [k async for k in redis.scan_iter(match=pattern)]
    if keys:
        await redis.delete(*keys)
