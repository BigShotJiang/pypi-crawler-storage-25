from datetime import datetime

from django.core.serializers.json import DjangoJSONEncoder


class CustomJSONEncoder(DjangoJSONEncoder):
    timezone = 'UTC'

    @classmethod
    def with_timezone(cls, tz):
        cls.timezone = tz
        return cls

    def default(self, obj, **kwargs):
        if isinstance(obj, datetime):
            return obj.astimezone(self.timezone).strftime('%Y-%m-%d %H:%M:%S')
        return super().default(obj)
