"""WS subscription gating: regex on channel names + allowed_channels hook."""
import pytest

from easyapi.ws import BaseWSConsumer


class _FakeChannelLayer:
    def __init__(self):
        self.added = []

    async def group_add(self, group, channel_name):
        self.added.append(group)


class _FakePubSub:
    def __init__(self):
        self.subscribed = []

    async def subscribe(self, channel):
        self.subscribed.append(channel)


def _make_consumer(allowlist=None, account_id=42):
    consumer = BaseWSConsumer.__new__(BaseWSConsumer)
    consumer.account_id = account_id
    consumer.user = {'id': 1}
    consumer.channel_name = 'test-channel'
    consumer.channel_layer = _FakeChannelLayer()
    consumer._pubsub = _FakePubSub()
    consumer._channels_groups = []

    async def allowed_channels(user):
        return allowlist

    consumer.allowed_channels = allowed_channels
    return consumer


@pytest.mark.asyncio
async def test_default_allows_well_formed_names():
    c = _make_consumer(allowlist=None)
    await c._subscribe_channels(['inbox', 'team-7', 'topic.foo'])
    assert c.channel_layer.added == [
        'a42.inbox', 'a42.team-7', 'a42.topic.foo',
    ]
    assert c._channels_groups == [
        'a42.inbox', 'a42.team-7', 'a42.topic.foo',
    ]


@pytest.mark.asyncio
async def test_invalid_chars_rejected():
    c = _make_consumer(allowlist=None)
    await c._subscribe_channels(['ok', 'bad name', 'has/slash', 'has*glob'])
    assert c.channel_layer.added == ['a42.ok']


@pytest.mark.asyncio
async def test_too_long_rejected():
    c = _make_consumer(allowlist=None)
    long_name = 'a' * 65
    await c._subscribe_channels([long_name, 'ok'])
    assert c.channel_layer.added == ['a42.ok']


@pytest.mark.asyncio
async def test_non_string_rejected():
    c = _make_consumer(allowlist=None)
    await c._subscribe_channels([None, 123, {'x': 1}, 'ok'])
    assert c.channel_layer.added == ['a42.ok']


@pytest.mark.asyncio
async def test_allowlist_filters_channels():
    c = _make_consumer(allowlist=['inbox', 'alerts'])
    await c._subscribe_channels(['inbox', 'random', 'alerts', 'other'])
    assert c.channel_layer.added == ['a42.inbox', 'a42.alerts']


@pytest.mark.asyncio
async def test_empty_allowlist_blocks_all():
    c = _make_consumer(allowlist=[])
    await c._subscribe_channels(['inbox', 'team-7'])
    assert c.channel_layer.added == []


@pytest.mark.asyncio
async def test_no_account_short_circuits():
    c = _make_consumer(allowlist=None, account_id=None)
    await c._subscribe_channels(['inbox'])
    assert c.channel_layer.added == []


def test_allow_unauthenticated_default_is_false():
    assert BaseWSConsumer.allow_unauthenticated is False
