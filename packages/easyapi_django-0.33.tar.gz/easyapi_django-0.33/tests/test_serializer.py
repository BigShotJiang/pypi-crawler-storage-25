import json
from datetime import datetime
from decimal import Decimal
import zoneinfo

from easyapi.serializer import CustomJSONEncoder


def test_datetime_formatted_with_timezone():
    encoder = CustomJSONEncoder.with_timezone(zoneinfo.ZoneInfo('UTC'))
    out = json.dumps(
        {'at': datetime(2024, 1, 15, 12, 30, 45, tzinfo=zoneinfo.ZoneInfo('UTC'))},
        cls=encoder,
    )
    assert '2024-01-15 12:30:45' in out


def test_decimal_passthrough():
    encoder = CustomJSONEncoder.with_timezone(zoneinfo.ZoneInfo('UTC'))
    out = json.dumps({'v': Decimal('1.50')}, cls=encoder)
    assert '1.50' in out


def test_datetime_converted_to_target_tz():
    encoder = CustomJSONEncoder.with_timezone(zoneinfo.ZoneInfo('America/Sao_Paulo'))
    out = json.dumps(
        {'at': datetime(2024, 1, 15, 12, 0, 0, tzinfo=zoneinfo.ZoneInfo('UTC'))},
        cls=encoder,
    )
    assert '2024-01-15 09:00:00' in out
