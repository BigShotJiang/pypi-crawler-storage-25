"""ws.py must import even when ``channels`` is not installed."""
import subprocess
import sys


def test_import_without_channels(monkeypatch):
    code = (
        "import sys\n"
        "import builtins\n"
        "real_import = builtins.__import__\n"
        "def fake(name, *a, **kw):\n"
        "    if name.startswith('channels'):\n"
        "        raise ImportError('mock no channels')\n"
        "    return real_import(name, *a, **kw)\n"
        "builtins.__import__ = fake\n"
        "import easyapi.ws as ws\n"
        "assert ws._CHANNELS_AVAILABLE is False\n"
        "assert ws.BaseWSConsumer is not None\n"
    )
    result = subprocess.run(
        [sys.executable, '-c', code],
        capture_output=True,
        text=True,
        env={
            **__import__('os').environ,
            'DJANGO_SETTINGS_MODULE': 'settings.settings',
            'PYTHONPATH': 'tests:.',
        },
        cwd='/Users/ssjunior/Dev/django-easyapi',
    )
    assert result.returncode == 0, result.stderr
