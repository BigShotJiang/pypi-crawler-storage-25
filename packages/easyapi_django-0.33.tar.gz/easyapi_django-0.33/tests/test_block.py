import pytest

from easyapi.base import BaseResource
from easyapi.blocking import block_key
from easyapi.exception import HTTPException
from easyapi.redis_config import get_redis
from tests.testapp.models import Space


class Res(BaseResource):
    model = Space


@pytest.mark.asyncio
async def test_check_is_blocked_no_key(fake_redis):
    res = Res()
    await res.check_is_blocked('1.2.3.4')


@pytest.mark.asyncio
async def test_check_is_blocked_blocked(fake_redis):
    redis = get_redis()
    await redis.set(block_key('1.2.3.4'), '1')
    res = Res()
    with pytest.raises(HTTPException) as exc:
        await res.check_is_blocked('1.2.3.4')
    assert exc.value.args[0] == 403


@pytest.mark.asyncio
async def test_block_sets_key_with_ttl(fake_redis):
    res = Res()
    with pytest.raises(HTTPException):
        await res.block('5.6.7.8')

    redis = get_redis()
    key = block_key('5.6.7.8')
    assert await redis.get(key) == 'api_rate_limit'
    ttl = await redis.ttl(key)
    assert 0 < ttl <= 86400
