import pytest

from easyapi.base import BaseResource
from easyapi.redis_config import KEY_PREFIX, get_redis
from tests.testapp.models import Space


class CachedResource(BaseResource):
    model = Space
    cache = True
    cache_ttl = 60


@pytest.mark.asyncio
async def test_save_cache_writes_setex_and_namespace_set(fake_redis):
    res = CachedResource()
    res.cache = True
    res.cache_key = f'{KEY_PREFIX}cache:/spaces'
    res.cache_namespace = 'list:testapp.space'

    await res.save_cache({'objects': []})

    redis = get_redis()
    assert await redis.get(res.cache_key) is not None
    members = await redis.smembers(f'{KEY_PREFIX}cache_ns:list:testapp.space')
    assert res.cache_key in members


@pytest.mark.asyncio
async def test_invalidate_cache_clears_namespace(fake_redis):
    res = CachedResource()
    res.cache = True
    res.cache_key = f'{KEY_PREFIX}cache:/spaces/5'
    res.cache_namespace = 'detail:testapp.space:5'
    await res.save_cache({'id': 5})

    redis = get_redis()
    assert await redis.get(res.cache_key) is not None

    await res.invalidate_cache(['detail:testapp.space:5'])

    assert await redis.get(res.cache_key) is None
    assert await redis.smembers(f'{KEY_PREFIX}cache_ns:detail:testapp.space:5') == set()


@pytest.mark.asyncio
async def test_invalidate_cache_multiple_namespaces(fake_redis):
    res_list = CachedResource()
    res_list.cache = True
    res_list.cache_key = f'{KEY_PREFIX}cache:/spaces'
    res_list.cache_namespace = 'list:testapp.space'
    await res_list.save_cache([{'id': 1}])

    res_detail = CachedResource()
    res_detail.cache = True
    res_detail.cache_key = f'{KEY_PREFIX}cache:/spaces/5'
    res_detail.cache_namespace = 'detail:testapp.space:5'
    await res_detail.save_cache({'id': 5})

    redis = get_redis()
    await res_list.invalidate_cache([
        'list:testapp.space',
        'detail:testapp.space:5',
    ])

    assert await redis.get(res_list.cache_key) is None
    assert await redis.get(res_detail.cache_key) is None


@pytest.mark.asyncio
async def test_invalidate_skips_when_no_namespaces(fake_redis):
    res = CachedResource()
    await res.invalidate_cache([])
    await res.invalidate_cache(None)


def test_cache_namespaces_list_only():
    res = CachedResource()
    assert res._cache_namespaces() == ['list:testapp.space']


def test_cache_namespaces_with_detail_id():
    res = CachedResource()
    assert res._cache_namespaces(include_detail_id=42) == [
        'list:testapp.space',
        'detail:testapp.space:42',
    ]


def test_cache_namespaces_no_model_returns_empty():
    res = BaseResource()
    assert res._cache_namespaces() == []


@pytest.mark.asyncio
async def test_save_cache_handles_datetime(fake_redis):
    from datetime import datetime
    import zoneinfo
    res = CachedResource()
    res.cache = True
    res.tz = zoneinfo.ZoneInfo('UTC')
    res.cache_key = f'{KEY_PREFIX}cache:/spaces/dt'
    res.cache_namespace = 'list:testapp.space'

    await res.save_cache({'created_at': datetime(2024, 1, 1, 12, 0, 0)})

    redis = get_redis()
    assert await redis.get(res.cache_key) is not None
