from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CovenantAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COVENANT_ACTION_UNSPECIFIED: _ClassVar[CovenantAction]
    COVENANT_ACTION_CLAIM: _ClassVar[CovenantAction]
    COVENANT_ACTION_OPEN: _ClassVar[CovenantAction]
    COVENANT_ACTION_BID: _ClassVar[CovenantAction]
    COVENANT_ACTION_REVEAL: _ClassVar[CovenantAction]
    COVENANT_ACTION_REDEEM: _ClassVar[CovenantAction]
    COVENANT_ACTION_REGISTER: _ClassVar[CovenantAction]
    COVENANT_ACTION_UPDATE: _ClassVar[CovenantAction]
    COVENANT_ACTION_RENEW: _ClassVar[CovenantAction]
    COVENANT_ACTION_TRANSFER: _ClassVar[CovenantAction]
    COVENANT_ACTION_FINALIZE: _ClassVar[CovenantAction]
    COVENANT_ACTION_REVOKE: _ClassVar[CovenantAction]
COVENANT_ACTION_UNSPECIFIED: CovenantAction
COVENANT_ACTION_CLAIM: CovenantAction
COVENANT_ACTION_OPEN: CovenantAction
COVENANT_ACTION_BID: CovenantAction
COVENANT_ACTION_REVEAL: CovenantAction
COVENANT_ACTION_REDEEM: CovenantAction
COVENANT_ACTION_REGISTER: CovenantAction
COVENANT_ACTION_UPDATE: CovenantAction
COVENANT_ACTION_RENEW: CovenantAction
COVENANT_ACTION_TRANSFER: CovenantAction
COVENANT_ACTION_FINALIZE: CovenantAction
COVENANT_ACTION_REVOKE: CovenantAction

class Covenant(_message.Message):
    __slots__ = ("action", "items")
    ACTION_FIELD_NUMBER: _ClassVar[int]
    ITEMS_FIELD_NUMBER: _ClassVar[int]
    action: CovenantAction
    items: _containers.RepeatedScalarFieldContainer[bytes]
    def __init__(self, action: _Optional[_Union[CovenantAction, str]] = ..., items: _Optional[_Iterable[bytes]] = ...) -> None: ...

class TxInput(_message.Message):
    __slots__ = ("txid", "output_index", "sequence", "witness")
    TXID_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_INDEX_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    WITNESS_FIELD_NUMBER: _ClassVar[int]
    txid: bytes
    output_index: int
    sequence: int
    witness: _containers.RepeatedScalarFieldContainer[bytes]
    def __init__(self, txid: _Optional[bytes] = ..., output_index: _Optional[int] = ..., sequence: _Optional[int] = ..., witness: _Optional[_Iterable[bytes]] = ...) -> None: ...

class TxOutput(_message.Message):
    __slots__ = ("value", "address", "covenant")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    COVENANT_FIELD_NUMBER: _ClassVar[int]
    value: int
    address: bytes
    covenant: Covenant
    def __init__(self, value: _Optional[int] = ..., address: _Optional[bytes] = ..., covenant: _Optional[_Union[Covenant, _Mapping]] = ...) -> None: ...

class Transaction(_message.Message):
    __slots__ = ("version", "vin", "vout", "locktime", "hash", "witness_hash", "blockhash", "time")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    VIN_FIELD_NUMBER: _ClassVar[int]
    VOUT_FIELD_NUMBER: _ClassVar[int]
    LOCKTIME_FIELD_NUMBER: _ClassVar[int]
    HASH_FIELD_NUMBER: _ClassVar[int]
    WITNESS_HASH_FIELD_NUMBER: _ClassVar[int]
    BLOCKHASH_FIELD_NUMBER: _ClassVar[int]
    TIME_FIELD_NUMBER: _ClassVar[int]
    version: int
    vin: _containers.RepeatedCompositeFieldContainer[TxInput]
    vout: _containers.RepeatedCompositeFieldContainer[TxOutput]
    locktime: int
    hash: bytes
    witness_hash: bytes
    blockhash: bytes
    time: int
    def __init__(self, version: _Optional[int] = ..., vin: _Optional[_Iterable[_Union[TxInput, _Mapping]]] = ..., vout: _Optional[_Iterable[_Union[TxOutput, _Mapping]]] = ..., locktime: _Optional[int] = ..., hash: _Optional[bytes] = ..., witness_hash: _Optional[bytes] = ..., blockhash: _Optional[bytes] = ..., time: _Optional[int] = ...) -> None: ...

class Block(_message.Message):
    __slots__ = ("version", "previous_blockhash", "merkle_root", "witness_root", "tree_root", "reserved_root", "time", "bits", "nonce", "extra_nonce", "mask", "tx")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_BLOCKHASH_FIELD_NUMBER: _ClassVar[int]
    MERKLE_ROOT_FIELD_NUMBER: _ClassVar[int]
    WITNESS_ROOT_FIELD_NUMBER: _ClassVar[int]
    TREE_ROOT_FIELD_NUMBER: _ClassVar[int]
    RESERVED_ROOT_FIELD_NUMBER: _ClassVar[int]
    TIME_FIELD_NUMBER: _ClassVar[int]
    BITS_FIELD_NUMBER: _ClassVar[int]
    NONCE_FIELD_NUMBER: _ClassVar[int]
    EXTRA_NONCE_FIELD_NUMBER: _ClassVar[int]
    MASK_FIELD_NUMBER: _ClassVar[int]
    TX_FIELD_NUMBER: _ClassVar[int]
    version: int
    previous_blockhash: bytes
    merkle_root: bytes
    witness_root: bytes
    tree_root: bytes
    reserved_root: bytes
    time: int
    bits: int
    nonce: bytes
    extra_nonce: bytes
    mask: bytes
    tx: _containers.RepeatedCompositeFieldContainer[Transaction]
    def __init__(self, version: _Optional[int] = ..., previous_blockhash: _Optional[bytes] = ..., merkle_root: _Optional[bytes] = ..., witness_root: _Optional[bytes] = ..., tree_root: _Optional[bytes] = ..., reserved_root: _Optional[bytes] = ..., time: _Optional[int] = ..., bits: _Optional[int] = ..., nonce: _Optional[bytes] = ..., extra_nonce: _Optional[bytes] = ..., mask: _Optional[bytes] = ..., tx: _Optional[_Iterable[_Union[Transaction, _Mapping]]] = ...) -> None: ...
