import logging
from typing import Dict
from .repository_base import Repository
from utils import sparql

log = logging.getLogger(__name__)


class RepositoryResourceLinks(Repository):

    __links: Dict[str, set] = {}

    def init_repository(self):
        log.info("initialize resource links repository")
        sparql_query = """
        PREFIX n4e: <http://nfdi4earth.de/ontology/>
        PREFIX sdo: <http://schema.org/>

        SELECT * {
            VALUES ?predicate { n4e:hasOutcome n4e:hasContributedTo }
            ?project a sdo:ResearchProject .
            ?project ?predicate ?subject
        }
        OFFSET %d
        LIMIT %d
        """

        log.info(
            "query research projects for links at " + self.sparql_endpoint
        )
        limit = 5000
        i = 0
        links_per_projects: dict[str : list[str]] = {}
        while True:
            query_splitted = sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)

            for hit in hits:
                project = hit["project"]["value"]
                subject = hit["subject"]["value"]
                if project not in links_per_projects:
                    links_per_projects[project] = [subject]
                else:
                    links_per_projects[project].append(subject)

            i = i + 1
            if len(hits) < limit:
                break

        for links_per_project in links_per_projects.values():
            for link in links_per_project:
                links = set(
                    [link_ for link_ in links_per_project if link_ != link]
                )
                if len(links) > 0:
                    if link not in self.__links:
                        self.__links[link] = links
                    else:
                        self.__links[link].update(links)
        log.info("successfully retrieved {} links".format(len(self.__links)))
        log.info("successfully initialized links repository")

    def get_links(self, identifier: str):
        if self.__links is not None and identifier in self.__links:
            return self.__links[identifier]
        elif self.__links is not None and identifier not in self.__links:
            return None
        else:
            raise ValueError("resource links repository is not initialized")
