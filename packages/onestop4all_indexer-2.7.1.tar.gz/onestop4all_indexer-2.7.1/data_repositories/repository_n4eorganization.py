import logging

from utils import sparql, util
from .repository_base import Repository

log = logging.getLogger(__name__)

#lut for all organizations that are part are nfdi4earh member (or sub organization of a member)
class RepositoryN4EOrganization(Repository):

    __n4e_organizations = None #key = orga iri
    __n4e_organizations_rorID = None #key = rorID

    def init_repository(self):
        log.info("initialize n4e organizations repository")
        sparql_query = """
            PREFIX schema: <http://schema.org/>
            PREFIX org: <http://www.w3.org/ns/org#>
            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

            SELECT DISTINCT ?organization ?organizationName  ?rorID ?parentOrganization
            WHERE {
                ?nfdi4earthProject schema:url "https://nfdi4earth.de/"^^xsd:anyURI .
                {
                    # Organizations directly linked to the project
                    ?organization org:hasMembership ?membership .
                    ?membership org:organization ?nfdi4earthProject .
                    ?organization schema:name ?organizationName .
                    optional { ?organization <http://w3id.org/nfdi4ing/metadata4ing#hasRorId> ?rorID }

                }
                UNION
                {
                    # Sub-organizations of those organizations
                    ?parentOrganization org:hasMembership ?membership .
                    ?membership org:organization ?nfdi4earthProject .
                    ?organization org:subOrganizationOf ?parentOrganization .
                    ?organization schema:name ?organizationName .
                    optional { ?organization <http://w3id.org/nfdi4ing/metadata4ing#hasRorId> ?rorID }
                }
            }
            OFFSET %d
            LIMIT %d
        """
    
        self.__n4e_organizations = {}

        log.info("query n4e member organizations at " + self.sparql_endpoint)
        limit = 30000
        i = 0
        while True:
            query_splitted = sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)

            for hit in hits:
                org_iri = hit["organization"]["value"]
                org_name = hit["organizationName"]["value"]
                if ("xml:lang" not in hit["organizationName"]):
                    org_name_lang = "int" #if no lang tag it is the canonical, international name of the organization
                else:
                    org_name_lang = hit["organizationName"]["xml:lang"]

                rorID = hit["rorID"]["value"] if "rorID" in hit else None
                parent_org = hit["parentOrganization"]["value"] if "parentOrganization" in hit else None
                
                #duplicate organizations because of multiple languages, only store single entry
                if(org_iri not in self.__n4e_organizations): #first appearance 
                    self.__n4e_organizations[org_iri] = {"iri": org_iri, "name": org_name, "lang": org_name_lang, "rorID": rorID, "parent_org": parent_org}
                else: #override orga_name (priority: int > en > other)
                    current_lang = self.__n4e_organizations[org_iri]["lang"]
                    if current_lang != "int" and (org_name_lang == "int" or (current_lang != "en" and org_name_lang == "en")):
                        self.__n4e_organizations[org_iri] = {"iri": org_iri, "name": org_name, "lang": org_name_lang, "rorID": rorID, "parent_org": parent_org}

            i = i + 1
            if len(hits) < limit:
                break

        self.__n4e_organizations_rorID = self.__organizations_by_rorID() #create lut for organizations by their rorID (some organization do not have a rorID -> fewer entries than self.__n4e_organization)

        log.info("n4e member organizations repository is fully initialized")


    def get_n4e_organization(self, iri: str):
        if self.__n4e_organizations is not None and iri in self.__n4e_organizations:
            return self.__n4e_organizations[iri]
        elif self.__n4e_organizations is not None and iri not in self.__n4e_organizations:
            return None
        else:
            raise ValueError("n4e organizations repository is not initialized")

                        
    def get_n4e_organization_by_rorID(self, rorID: str):
        if self.__n4e_organizations_rorID is not None and rorID in self.__n4e_organizations_rorID:
            return self.__n4e_organizations_rorID[rorID]
        elif self.__n4e_organizations_rorID is not None and rorID not in self.__n4e_organizations_rorID:
            return None
        else:
            raise ValueError("n4e organizations (rorID) repository is not initialized")
        
    #creates lut (dict) for organizations by rorID
    def __organizations_by_rorID(self):
        organizations_rorID = {}
        for iri in self.__n4e_organizations:
            if self.__n4e_organizations[iri]["rorID"] is not None:
                rorID = self.__n4e_organizations[iri]["rorID"]
                organizations_rorID[rorID] = self.__n4e_organizations[iri]

        return organizations_rorID