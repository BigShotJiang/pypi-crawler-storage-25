import logging
from .repository_base import Repository
from utils import sparql

log = logging.getLogger(__name__)


class RepositoryTheme(Repository):
    __themes = None

    def init_repository(self):
        log.info("initialize themes repository")
        sparql_query = """
            prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>

            SELECT ?s ?o
            WHERE {
                ?s ?p ?o
                FILTER (?p  IN (rdfs:label))
            }
            OFFSET %d
            LIMIT %d
        """
        self.__themes = {}

        log.info("query themes at " + self.sparql_endpoint)
        limit = 5000
        i = 0
        while True:
            query_splitted = sparql_query % (limit * i, limit)
            hits = sparql.execute_query(
                self.sparql_endpoint, query_splitted
            )

            for hit in hits:
                uri = hit["s"]["value"]
                label = hit["o"]["value"]
                self.__themes[uri] = label

            i = i + 1
            if len(hits) < limit:
                break

        log.info(
            "successfully retrieved {} themes triples".format(
                len(self.__themes)
            )
        )
        log.info("successfully initialized themes repository")

    def get_theme(self, identifier: str):
        if self.__themes is not None and identifier in self.__themes:
            return self.__themes[identifier]
        elif self.__themes is not None and identifier not in self.__themes:
            return None
        else:
            raise ValueError("themes repository is not initialized")
