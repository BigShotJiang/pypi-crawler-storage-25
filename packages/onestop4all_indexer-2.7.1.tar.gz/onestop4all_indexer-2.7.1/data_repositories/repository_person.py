import logging

from utils import sparql, util
from .repository_base import Repository

log = logging.getLogger(__name__)


class RepositoryPerson(Repository):
    __persons = None

    def init_repository(self):
        log.info("initialize person repository")
        sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        SELECT ?subject ?predicate ?object
            WHERE {
                {
                ?subject rdf:type <http://schema.org/Person>.
                # Provisionally speed up havesting by adding the following filter
                # based on the fact that all persons related to Dataset objects
                # in the KH are internally stored as blank nodes and are being
                # retrieved together with the Dataset metadata from the REST endpoint
                # instead of from the triple store
                # -> this additional filter makes the query itself slower, however
                # reduces the result from about 6 Mio to 100K (as of Aug2024) therefore in total faster
                FILTER(!ISBLANK(?subject))
                ?subject ?predicate ?object
                FILTER (?predicate NOT IN (<http://schema.org/affiliation>))
                FILTER (!LANG(?object))
                }
            UNION{
                VALUES  ?predicate { <http://schema.org/affiliation> }
                ?subject rdf:type <http://schema.org/Person>;
                        <http://schema.org/affiliation> ?affiliation.
                ?affiliation <http://schema.org/name> ?object.
                FILTER (!LANG(?object))
                }
            }
        OFFSET %d
        LIMIT %d
        """

        self.__persons = {}

        log.info("query persons at " + self.sparql_endpoint)
        limit = 30000
        i = 0
        while True:
            query_splitted = sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)

            for hit in hits:
                subject = hit["subject"]["value"]
                predicate = hit["predicate"]["value"]
                object = hit["object"]["value"]

                if subject not in self.__persons:
                    self.__persons[subject] = {}
                    self.__persons[subject]["uri"] = subject
                    self.__persons[subject]["id"] = subject

                if predicate == "http://schema.org/name": #name
                    self.__persons[subject]["name"]  = object
                    self.__persons[subject]["mainTitle"]  = object
                elif predicate == "http://schema.org/email": #email
                    util.addValue(dict=self.__persons[subject], attribute="email", value = object)
                elif predicate == "http://w3id.org/nfdi4ing/metadata4ing#orcidId": #orcidId
                    util.addValue(dict=self.__persons[subject], attribute="orcidId", value = object)
                elif predicate == "http://schema.org/affiliation": #affiliation
                    util.addValue(dict=self.__persons[subject], attribute="affiliation", value = object)

            i = i + 1
            if len(hits) < limit:
                break
        log.info("successfully retrieved {} persons".format(len(self.__persons)))
        log.info("successfully initialized person repository")

    def get_person(self, identifier: str):
        if self.__persons is not None and identifier in self.__persons:
            return self.__persons[identifier]
        elif self.__persons is not None and identifier not in self.__persons:
            return None
        else:
            raise ValueError("person repository is not initialized")
