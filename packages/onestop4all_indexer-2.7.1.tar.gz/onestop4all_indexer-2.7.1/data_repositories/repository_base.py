import logging

from abc import ABC, abstractmethod
from typing import Optional

from utils import config

log = logging.getLogger(__name__)


class Repository(ABC):

    def __init__(
        self,
        sparql_endpoint: Optional[str] = None,
    ):
        self.sparql_endpoint = (
            sparql_endpoint if sparql_endpoint else config["sparql_endpoint"]
        )

        self.init_repository()

    @abstractmethod
    def init_repository(self):
        pass
