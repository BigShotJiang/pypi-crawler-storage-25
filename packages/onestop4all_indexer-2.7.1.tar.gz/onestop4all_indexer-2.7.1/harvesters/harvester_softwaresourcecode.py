import json
import logging
from .harvester_base import Harvester
from data_repositories import RepositoryPerson, RepositoryResourceLinks
from utils import sparql

log = logging.getLogger(__name__)


class Softwaresourcecode_Harvester(Harvester):
    sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX dct: <http://purl.org/dc/terms/>

        SELECT ?subject ?predicate ?object ?sourceSystem_homepage ?sourceSystem_title
        WHERE {
        {
        ?subject rdf:type <http://schema.org/SoftwareSourceCode>.
            ?subject ?predicate ?object
            FILTER (?predicate NOT IN (<http://schema.org/publisher>, <http://schema.org/audience>))
        }
        UNION{
            VALUES  ?predicate { <http://schema.org/publisher> }
            ?subject rdf:type <http://schema.org/SoftwareSourceCode>;
                    <http://schema.org/publisher> ?publisher.
            ?publisher <http://schema.org/name> ?object.
        }
        UNION{
            VALUES  ?predicate { <http://schema.org/audience> }
            ?subject rdf:type <http://schema.org/SoftwareSourceCode>;
                    <http://schema.org/audience> ?audience.
            ?audience dct:title ?object.
        }
        UNION{
            VALUES  ?predicate { n4e:sourceSystem }
            ?subject rdf:type <http://schema.org/SoftwareSourceCode>;
                    n4e:sourceSystem ?object.
            optional {?object dct:title ?sourceSystem_title.}
            optional {?object  foaf:homepage ?sourceSystem_homepage.}
            }
        }
        Order By ?subject ?predicate
        OFFSET %d
        LIMIT %d
    """

    def __init__(
        self,
        persons_repo: RepositoryPerson,
        links_repo: RepositoryResourceLinks,
        **kw,
    ):
        super().__init__(**kw)
        self.persons_repo = persons_repo
        self.links_repo = links_repo

    def harvest(self):
        limit = 5000
        softwares = {}  # all softwares dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, softwares)
            i = i + 1

            if len(hits) < limit:
                break

        softwares_list = []
        for (
            key,
            value,
        ) in (
            softwares.items()
        ):  # transform softwares dict to list for indexing
            software = value
            if "mainTitle" not in software and len(software["name"]) > 0:
                software["mainTitle"] = software["name"][0]
            software["mainTitle"] = software["mainTitle"].strip()
            softwares_list.append(software)

            links = self.links_repo.get_links(key)
            if links:
                software["relatedContent"] = [self.getID(l) for l in links]

        return softwares_list

    def parse_response(self, hits, softwares):
        for hit in hits:
            subject = hit["subject"]["value"]
            predicate = hit["predicate"]["value"]
            object = hit["object"]["value"]

            if subject not in softwares:  # init document/dict for new subject
                softwares[subject] = {}
                softwares[subject]["uri"] = subject
                softwares[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if predicate == "http://schema.org/name":  # name
                self.addValue(
                    dict=softwares[subject], attribute="name", value=object
                )
                if (
                    "xml:lang" not in hit["object"]
                    or hit["object"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    softwares[subject]["mainTitle"] = object
            elif predicate == "http://schema.org/author":  # author
                author = self.persons_repo.get_person(object)
                if author is not None:
                    if "author" not in softwares[subject]:
                        softwares[subject]["author"] = []
                    author["type"] = ["person_nested"]  # required
                    softwares[subject]["author"].append(author)
                    if "name" in author:
                        self.addValue(
                            dict=softwares[subject],
                            attribute="searchHelper",
                            value=author["name"],
                        )  # make author name searchable
            elif (
                predicate == "http://schema.org/additionalType"
            ):  # additionalType
                self.addValue(
                    dict=softwares[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif predicate == "http://schema.org/dateModified":  # dateModified
                softwares[subject]["dateModified"] = object
            elif predicate == "http://schema.org/description":  # description
                self.addValue(
                    dict=softwares[subject],
                    attribute="description",
                    value=object,
                )
            elif predicate == "http://schema.org/url":  # url
                self.addValue(
                    dict=softwares[subject], attribute="url", value=object
                )
            elif predicate == "http://schema.org/about":  # about
                self.addValue(
                    dict=softwares[subject], attribute="about", value=object
                )
            elif predicate == "http://schema.org/audience":  # audience
                self.addValue(
                    dict=softwares[subject], attribute="audience", value=object
                )
            elif (
                predicate == "http://schema.org/datePublished"
            ):  # datePublished
                softwares[subject]["datePublished"] = object
            elif predicate == "http://schema.org/inLanguage":  # language
                self.addValue(
                    dict=softwares[subject], attribute="language", value=object
                )
            elif predicate == "http://schema.org/isPartOf":  # isPartOf
                self.addValue(
                    dict=softwares[subject], attribute="isPartOf", value=object
                )
            elif predicate == "http://schema.org/keywords":  # keyword
                self.addValue(
                    dict=softwares[subject], attribute="keyword", value=object
                )
            elif predicate == "http://schema.org/license":  # license
                self.addValue(
                    dict=softwares[subject],
                    attribute="software_license",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=softwares[subject], attribute="type", value=object
                )
            elif (
                predicate == "http://schema.org/codeRepository"
            ):  # codeRepository
                softwares[subject]["codeRepository"] = object
            elif predicate == "http://schema.org/publisher":  # publisher
                if (
                    "xml:lang" not in hit["object"]
                ):  # use international name for publisher name
                    self.addValue(
                        dict=softwares[subject],
                        attribute="publisher",
                        value=object,
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in softwares[subject]
                    or object not in softwares[subject]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=softwares[subject],
                        attribute="publisher_alt",
                        value=object,
                    )
            elif (
                predicate == "http://schema.org/programmingLanguage"
            ):  # programmingLanguage
                self.addValue(
                    dict=softwares[subject],
                    attribute="programmingLanguage",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        softwares[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        softwares[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=softwares[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                self.addValue(
                    dict=softwares[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )
