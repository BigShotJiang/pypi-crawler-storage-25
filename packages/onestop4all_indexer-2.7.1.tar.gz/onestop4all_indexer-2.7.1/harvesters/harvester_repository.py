import logging
from .harvester_base import Harvester
from data_repositories.repository_theme import RepositoryTheme
from data_repositories.repository_n4eorganization import RepositoryN4EOrganization
from utils import sparql, util

log = logging.getLogger(__name__)


class Repository_Harvester(Harvester):
    sparql_query = """
        PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>
        prefix dcat: <http://www.w3.org/ns/dcat#>
        prefix dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

        SELECT ?subject ?predicate ?object ?contactpoint_email ?contactpoint_url ?distribution_conformsTo ?distribution_accessURL ?sourceSystem_homepage ?sourceSystem_title ?APIType ?APIURL ?publisher_homepage ?publisher_country ?metadataStandard_homepage ?publisher as ?publisherIRI
        WHERE {
        %SEEK_FILTER%

        VALUES ?type { n4e:Repository n4e:Aggregator }

        {
            ?subject rdf:type ?type.
            ?subject ?predicate ?object.
            FILTER (?predicate NOT IN (dct:publisher, dcat:distribution, dcat:contactPoint))
        }
        UNION{
            VALUES  ?predicate { dct:publisher }
            ?subject rdf:type ?type;
                    dct:publisher ?publisher.
            ?publisher <http://schema.org/name> ?object.
            optional {?publisher foaf:homepage ?publisher_homepage.}
            optional {?publisher vcard:country-name ?publisher_country.}
        }
        UNION{
            VALUES  ?predicate { n4e:supportsMetadataStandard }
            ?subject rdf:type ?type;
                    n4e:supportsMetadataStandard ?metadataStandard.
            ?metadataStandard dct:title ?object.
            optional {?metadataStandard n4e:hasWebsite ?metadataStandard_homepage.}
        }
        UNION {
            VALUES ?predicate { dcat:contactPoint }
            ?subject rdf:type ?type;
                     dcat:contactPoint ?contactpoint.
            optional { ?contactpoint vcard:hasEmail ?contactpoint_email. }
            optional { ?contactpoint vcard:hasURL ?contactpoint_url. }
        }
        UNION{
            VALUES  ?predicate { dcat:distribution }
            ?subject rdf:type ?type;
                     dcat:distribution ?distribution.
            ?distribution dct:conformsTo ?distribution_conformsTo.
        }
        UNION{
            VALUES  ?predicate { dcat:distribution }
            ?subject rdf:type ?type;
                     dcat:distribution ?distribution.
            ?distribution dcat:accessURL ?distribution_accessURL.
        }
        UNION{
            VALUES  ?predicate { n4e:sourceSystem }
            ?subject rdf:type ?type;
                    n4e:sourceSystem ?object.
            optional {?object dct:title ?sourceSystem_title.}
            optional {?object  foaf:homepage ?sourceSystem_homepage.}
            }
        UNION{
            VALUES  ?predicate { n4e:hasAPI }
            ?subject rdf:type ?type;
                    n4e:hasAPI ?api.
            optional {?api dct:conformsTo ?APIType.}
            optional {?api dcat:endpointURL ?APIURL.}
            }
        }
        ORDER BY ?subject ?predicate
        LIMIT %LIMIT%
    """

    def __init__(
        self,
        themes_repo: RepositoryTheme, 
        n4e_organizations_repo: RepositoryN4EOrganization, **kw
    ):
        super().__init__(**kw)
        self.themes_repo = themes_repo
        self.n4e_organizations_repo = n4e_organizations_repo

    def harvest(self):
        limit = 5000
        # convert to list of repo documents for indexing
        repos = {}  # repos dict

        # Seek pagination anchors
        last_subject = None
        last_predicate = None

        while True:

            # Create seek filter for first or subsequent pages
            if last_subject is None:
                seek_filter = "FILTER (true)"
            else:
                # Subsequent pages -> lexicographic "greater than"
                seek_filter = f"""
                    FILTER (
                        ?subject > <{last_subject}> ||
                        (?subject = <{last_subject}> && ?predicate > <{last_predicate}>)
                    )
                """

            # Build final SPARQL with dynamic seek filter + limit
            query = self.sparql_query.replace("%SEEK_FILTER%", seek_filter)
            query = query.replace("%LIMIT%", str(limit))

            hits = sparql.execute_query(self.sparql_endpoint, query)

            if not hits:
                break

            self.parse_response(hits, repos)

            if len(hits) < limit:
                break

            # Update seek keys using last row of this batch
            last = hits[-1]
            last_subject = last["subject"]["value"]
            last_predicate = last["predicate"]["value"]

        repos_list = []
        for (
            key,
            value,
        ) in repos.items():
            repo = value

            if "type" in repo:
                if repo["type"][0] == "http://nfdi4earth.de/ontology/Aggregator":
                    repo["type"][0] = "http://nfdi4earth.de/ontology/Repository"

            if "mainTitle" not in repo and len(repo["title"]) > 0:
                repo["mainTitle"] = repo["title"][0]
            repo["mainTitle"] = repo["mainTitle"].strip()
            repos_list.append(repo)
            if "relatedContent" in repo:  # replace related content uri with id
                related_content_ids = []
                for rc in repo["relatedContent"]:
                    standard_id = self.getID(rc)
                    related_content_ids.extend([standard_id])
                repo["relatedContent"] = related_content_ids

            #execute additional sparql query to determine if (some) datasets in this repository are harvested by n4e
            #key = subject
            has_harvested_datasets = self.request_has_harvested_datasets(repo_subject=key)
            repo["isHarvestedByNFDI4Earth"] = has_harvested_datasets 


        return repos_list

    def parse_response(self, hits, repos):
        for r in hits:
            if r["subject"]["value"] not in repos:
                repos[r["subject"]["value"]] = {}
                repos[r["subject"]["value"]]["uri"] = r["subject"]["value"]
                repos[r["subject"]["value"]]["id"] = self.getID(
                    r["subject"]["value"]
                )  # use ID from triple store also in Solr to ensure stable IDs

            if r["predicate"]["value"] == "http://purl.org/dc/terms/title":
                self.addValue(
                    repos[r["subject"]["value"]], "title", r["object"]["value"]
                )
                if (
                    "xml:lang" not in r["object"]
                    or r["object"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    repos[r["subject"]["value"]]["mainTitle"] = r["object"][
                        "value"
                    ]
            elif (
                r["predicate"]["value"] == "http://purl.org/dc/terms/publisher"
            ):  # publisher
                if (
                    "xml:lang" not in r["object"]
                ):  # use international name for publisher name
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "publisher",
                        r["object"]["value"],
                    )
                if "publisher_homepage" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "publisher" + self.flatten_separator + "homepage",
                        r["publisher_homepage"]["value"],
                    )
                if "publisher_country" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "countryName",
                        r["publisher_country"]["value"], True
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in repos[r["subject"]["value"]]
                    or r["object"]["value"]
                    not in repos[r["subject"]["value"]]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "publisher_alt",
                        r["object"]["value"],
                    )
                if "publisherIRI" in r: #isN4EOperated
                    if("isN4EOperated" not in repos[r["subject"]["value"]] or repos[r["subject"]["value"]]["isN4EOperated"] == False): #repo might have multiple publisher, no need to update if "isN4EOperated" is already set to "True"
                        n4e_organization = self.n4e_organizations_repo.get_n4e_organization(r["publisherIRI"]["value"]) #look up organization if is in n4e member LUT
                        if n4e_organization is not None:
                            repos[r["subject"]["value"]]["isN4EOperated"] = True
                            #only index if `True`, do not index if `False`
            elif (
                r["predicate"]["value"] == "http://purl.org/dc/terms/keyword"
            ):  # keyword
                self.addValue(
                    repos[r["subject"]["value"]],
                    "keyword",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://schema.org/description"
            ):  # description
                self.addValue(
                    repos[r["subject"]["value"]],
                    "description",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/maxUploadSizeMb"
            ):  # maxUploadSizeMb
                repos[r["subject"]["value"]]["maxUploadSizeMb"] = r["object"][
                    "value"
                ]
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/dataUploadType"
            ):  # dataUploadType
                self.addValue(
                    repos[r["subject"]["value"]],
                    "dataUploadType",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/dataUploadRestriction"
            ):  # dataUploadRestriction
                self.addValue(
                    repos[r["subject"]["value"]],
                    "dataUploadRestriction",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"] == "http://purl.org/dc/terms/type"
            ):  # type (dct:type)
                self.addValue(
                    repos[r["subject"]["value"]], "type", r["object"]["value"]
                )
            elif (
                r["predicate"]["value"] == "http://purl.org/dc/terms/language"
            ):  # language
                self.addValue(
                    repos[r["subject"]["value"]],
                    "language",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"] == "http://xmlns.com/foaf/0.1/homepage"
            ):  # homepage
                self.addValue(
                    repos[r["subject"]["value"]],
                    "homepage",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/assignsIdentifierScheme"
            ):  # assignsIdentifierScheme
                self.addValue(
                    repos[r["subject"]["value"]],
                    "assignsIdentifierScheme",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://www.w3.org/2004/02/skos/core#altLabel"
            ):  # altLabel
                self.addValue(
                    repos[r["subject"]["value"]],
                    "altLabel",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/catalogAccessType"
            ):  # catalogAccessType
                self.addValue(
                    repos[r["subject"]["value"]],
                    "catalogAccessType",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/catalogAccessRestriction"
            ):  # catalogAccessRestriction
                self.addValue(
                    repos[r["subject"]["value"]],
                    "catalogAccessRestriction",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/catalogLicense"
            ):  # catalogLicense
                self.addValue(
                    repos[r["subject"]["value"]],
                    "catalogLicense",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/dataAccessType"
            ):  # dataAccessType
                self.addValue(
                    repos[r["subject"]["value"]],
                    "dataAccessType",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/dataAccessRestriction"
            ):  # dataAccessRestriction
                self.addValue(
                    repos[r["subject"]["value"]],
                    "dataAccessRestriction",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/dataLicense"
            ):  # dataLicense
                self.addValue(
                    repos[r["subject"]["value"]],
                    "dataLicense",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/repositoryType"
            ):  # repositoryType
                self.addValue(
                    repos[r["subject"]["value"]],
                    "repositoryType",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/supportsMetadataStandard"
            ):  # supportsMetadataStandard
                if r["object"]["type"] == "literal":
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "supportsMetadataStandard",
                        r["object"]["value"],
                    )
                elif r["object"]["type"] == "uri":
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "relatedContent",
                        r["object"]["value"],
                    )
                if "metadataStandard_homepage" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "supportsMetadataStandard"
                        + self.flatten_separator
                        + "homepage",
                        r["metadataStandard_homepage"]["value"],
                    )
            elif (
                r["predicate"]["value"] == "http://purl.org/dc/terms/modified"
            ):  # dateModified
                repos[r["subject"]["value"]]["dateModified"] = r["object"][
                    "value"
                ]
            elif (
                r["predicate"]["value"]
                == "http://www.w3.org/ns/dcat#contactPoint"
            ):  # contactPoint
                if "contactpoint_email" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "contactPoint" + self.flatten_separator + "email",
                        r["contactpoint_email"]["value"],
                    )
                if "contactpoint_url" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "contactPoint" + self.flatten_separator + "url",
                        r["contactpoint_url"]["value"],
                    )
            elif (
                r["predicate"]["value"]
                == "http://www.w3.org/ns/dcat#distribution"
            ):  # distribution
                if "distribution_conformsTo" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "distribution" + self.flatten_separator + "conformsTo",
                        r["distribution_conformsTo"]["value"],
                    )
                if "distribution_accessURL" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "distribution" + self.flatten_separator + "accessURL",
                        r["distribution_accessURL"]["value"],
                    )
            elif (
                r["predicate"]["value"] == "https://nfdi.fiz-karlsruhe.de/ontology/subjectArea"
            ):  # theme
                theme_label = self.themes_repo.get_theme(
                    r["object"]["value"]
                )  # get label for theme id
                if theme_label is not None:
                    self.addValue(
                        repos[r["subject"]["value"]], "subjectArea", theme_label
                    )
            elif (
                r["predicate"]["value"]
                == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    repos[r["subject"]["value"]], "type", r["object"]["value"]
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        r["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "sourceSystem" + self.flatten_separator + "title",
                        r["sourceSystem_title"]["value"],
                    )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    repos[r["subject"]["value"]],
                    "sourceSystem" + self.flatten_separator + "id",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/hasCertificate"
            ):  # hasCertificate
                self.addValue(
                    repos[r["subject"]["value"]],
                    "hasCertificate",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/contentType"
            ):  # contentType
                self.addValue(
                    repos[r["subject"]["value"]],
                    "contentType",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/supportsVersioning"
            ):  # supportsVersioning
                self.addValue(
                    repos[r["subject"]["value"]],
                    "supportsVersioning",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                self.addValue(
                    repos[r["subject"]["value"]],
                    "sourceSystemURL",
                    r["object"]["value"],
                )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/hasAPI"
            ):  # hasAPI
                if "APIType" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "hasAPI" + self.flatten_separator + "conformsTo",
                        r["APIType"]["value"],
                    )
                if "APIURL" in r:
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "hasAPI" + self.flatten_separator + "url",
                        r["APIURL"]["value"],
                    )
            elif (
                r["predicate"]["value"]
                == "http://nfdi4earth.de/ontology/isNFDI4EarthLabelled"
            ):  # isNFDI4EarthLabelled
                #only add property to the indexed document it value is "true"
                if (util.is_truthy(r["object"]["value"])):
                    self.addValue(
                        repos[r["subject"]["value"]],
                        "isNFDI4EarthLabelled",
                        r["object"]["value"],
                    )

    def request_has_harvested_datasets(self, repo_subject): 
        sparql_query = """
        PREFIX n4e: <http://nfdi4earth.de/ontology/>
        select  COUNT(?s) AS ?datasetCount 
            where {
                ?s n4e:inCatalog <%SUBJECT%> .
            }
        """

        log.debug("run sparql query to determine of datasets of repository are harvested by n4e, repository: " + repo_subject)

        query = sparql_query.replace("%SUBJECT%", str(repo_subject))
        hits = sparql.execute_query(self.sparql_endpoint, query)

        if not hits or not hits[0]:
            return False
        else:
            count = int(hits[0]["datasetCount"]["value"])
            has_harvested_datasets = count > 0
            return has_harvested_datasets