import logging
from .harvester_base import Harvester
from data_repositories import RepositoryPerson, RepositoryResourceLinks
from utils import sparql

log = logging.getLogger(__name__)


# this harvester is for other (not Living Handbook) Articles (documents)
class Document_Harvester(Harvester):
    sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

        SELECT ?s ?p ?o ?sourceSystem_title ?sourceSystem_homepage
        WHERE {
                {
                ?s rdf:type <http://nfdi4earth.de/ontology/Publication>.
                ?s ?p ?o
                FILTER (?p NOT IN (<http://schema.org/publisher>, n4e:sourceSystem))
                }
                UNION{
                    VALUES  ?p { <http://schema.org/publisher> }
                    ?s rdf:type <http://nfdi4earth.de/ontology/Publication>;
                            <http://schema.org/publisher> ?publisher.
                    ?publisher foaf:name ?o.
                }
                UNION{
                    VALUES  ?p { n4e:sourceSystem }
                    ?s rdf:type <http://nfdi4earth.de/ontology/Publication>;
                            n4e:sourceSystem ?o.
                    optional {?o dct:title ?sourceSystem_title.}
                    optional {?o foaf:homepage ?sourceSystem_homepage.}
                }
                FILTER NOT EXISTS {
                    ?s n4e:sourceSystem <https://cordra.knowledgehub.nfdi4earth.de/objects/n4ekh/8fcc0af2b80d88d6b220>
                }
            }
            OFFSET %d
            LIMIT %d
    """

    def __init__(
        self,
        persons_repo: RepositoryPerson,
        links_repo: RepositoryResourceLinks,
        **kw,
    ):
        super().__init__(**kw)
        self.persons_repo = persons_repo
        self.links_repo = links_repo

    def harvest(self):
        limit = 5000
        documents = {}  # all documents dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, documents)
            i = i + 1

            if len(hits) < limit:
                break

        documents_list = []
        for (
            key,
            value,
        ) in (
            documents.items()
        ):  # transform documents dict to list for indexing
            document = value
            # ensure mainTitle
            if "mainTitle" not in document and len(document["name"]) > 0:
                document["mainTitle"] = document["name"][0]
            document["mainTitle"] = document["mainTitle"].strip()

            links = self.links_repo.get_links(key)
            if links:
                document["relatedContent"] = [self.getID(l) for l in links]

            if (
                "http://nfdi4earth.de/ontology/LHBArticle"
                not in document["type"]
            ):  # ignore LHBArticles
                documents_list.append(document)

        return documents_list

    def parse_response(self, hits, documents):
        for hit in hits:
            subject = hit["s"]["value"]
            predicate = hit["p"]["value"]
            object = hit["o"]["value"]

            if subject not in documents:  # init document/dict for new subject
                documents[subject] = {}
                documents[subject]["uri"] = subject
                documents[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if predicate == "http://schema.org/name":  # name
                self.addValue(
                    dict=documents[subject], attribute="name", value=object
                )
                if (
                    "xml:lang" not in hit["o"] or hit["o"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    documents[subject]["mainTitle"] = object
            elif predicate == "http://schema.org/author":  # author
                author = self.persons_repo.get_person(object)
                if author is not None:
                    if "author" not in documents[subject]:
                        documents[subject]["author"] = []
                    author["type"] = ["person_nested"]  # required
                    documents[subject]["author"].append(author)
                    if "name" in author:
                        self.addValue(
                            dict=documents[subject],
                            attribute="searchHelper",
                            value=author["name"],
                        )  # make author name searchable
            elif predicate == "http://schema.org/dateModified":  # dateModified
                documents[subject]["dateModified"] = object
            elif (
                predicate == "http://schema.org/additionalType"
            ):  # additionalType
                self.addValue(
                    dict=documents[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif predicate == "http://schema.org/description":  # description
                # temporary solution to bring funding statement to end
                if "description" in documents[subject]:
                    documents[subject]["description"].insert(0, object)
                else:
                    self.addValue(
                        dict=documents[subject],
                        attribute="description",
                        value=object,
                    )
            elif predicate == "http://schema.org/url":  # url
                self.addValue(
                    dict=documents[subject], attribute="url", value=object
                )
            elif predicate == "http://schema.org/about":  # about
                self.addValue(
                    dict=documents[subject], attribute="about", value=object
                )
            elif (
                predicate == "http://schema.org/datePublished"
            ):  # datePublished
                documents[subject]["datePublished"] = object
            elif predicate == "http://schema.org/inLanguage":  # language
                self.addValue(
                    dict=documents[subject], attribute="language", value=object
                )
            elif predicate == "http://schema.org/isPartOf":  # isPartOf
                self.addValue(
                    dict=documents[subject], attribute="isPartOf", value=object
                )
            elif predicate == "http://schema.org/keywords":  # keyword
                self.addValue(
                    dict=documents[subject], attribute="keyword", value=object
                )
            elif predicate == "http://schema.org/license":  # license
                self.addValue(
                    dict=documents[subject], attribute="license", value=object
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        documents[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        documents[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=documents[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=documents[subject], attribute="type", value=object
                )
            elif predicate == "http://schema.org/publisher":  # publisher
                if (
                    "xml:lang" not in hit["o"]
                ):  # use international name for publisher name
                    self.addValue(
                        dict=documents[subject],
                        attribute="publisher",
                        value=object,
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in documents[subject]
                    or object not in documents[subject]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=documents[subject],
                        attribute="publisher_alt",
                        value=object,
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                self.addValue(
                    dict=documents[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )
