import logging
from .harvester_base import Harvester
from data_repositories.repository_theme import RepositoryTheme
from utils import sparql

log = logging.getLogger(__name__)


class Metadatastandard_Harvester(Harvester):
    sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        prefix dcat: <http://www.w3.org/ns/dcat#>
        PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>

        SELECT ?s ?p ?o ?contactpoint_email ?contactpoint_url ?sourceSystem_homepage ?sourceSystem_title
        WHERE {
            {
            ?s rdf:type n4e:MetadataStandard.
            ?s ?p ?o
            }
        UNION{
            VALUES  ?p { n4e:hasChildStandard }
            ?s rdf:type n4e:MetadataStandard;
            n4e:hasChildStandard ?child.
            ?child dct:title ?o.
        }
        UNION{
            VALUES  ?p { n4e:hasParentStandard }
            ?s rdf:type n4e:MetadataStandard;
            n4e:hasParentStandard ?child.
            ?child dct:title ?o.
        }
        UNION{
            VALUES  ?p { dct:publisher }
            ?s rdf:type n4e:MetadataStandard;
                    dct:publisher ?publisher.
            ?publisher foaf:name ?o.
        }
        UNION {
            VALUES ?p { dcat:contactPoint }
            ?s rdf:type n4e:MetadataStandard;
                     dcat:contactPoint ?contactpoint.
            optional { ?contactpoint vcard:hasEmail ?contactpoint_email. }
            optional { ?contactpoint vcard:hasURL ?contactpoint_url. }
        }
        UNION{
            VALUES  ?p { n4e:sourceSystem }
            ?s rdf:type n4e:MetadataStandard;
                    n4e:sourceSystem ?o.
            optional {?o dct:title ?sourceSystem_title.}
            optional {?o  foaf:homepage ?sourceSystem_homepage.}
            }
        UNION{
            VALUES  ?p { "implementedBy" }
            ?repo rdf:type n4e:Repository;
                    n4e:supportsMetadataStandard ?s.
                BIND(?repo AS ?o)
            }
        }
        Order By ?s ?p
        OFFSET %d
        LIMIT %d
    """

    def __init__(
        self, themes_repo: RepositoryTheme, **kw
    ):
        super().__init__(**kw)
        self.themes_repo = themes_repo

    def harvest(self):
        limit = 5000
        metadatastandards = {}  # all metadatastandards dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, metadatastandards)
            i = i + 1

            if len(hits) < limit:
                break

        metadatastandards_list = []
        for (
            key,
            value,
        ) in (
            metadatastandards.items()
        ):  # transform metadatastandards dict to list for indexing
            standard = value
            # ensure mainTitle
            if "mainTitle" not in standard:
                if "title" in standard and len(standard["title"]) > 0:
                    standard["mainTitle"] = standard["title"][0]
                else:
                    log.warn(f'Invalid dataset - missing title: {standard}')
                    continue
            standard["mainTitle"] = standard["mainTitle"].strip()
            if (
                "relatedStandard" in standard
            ):  # add related standard (ids) to related content
                for rc in standard["relatedStandard"]:
                    if rc in metadatastandards:
                        self.addValue(
                            dict=standard,
                            attribute="relatedContent",
                            value=metadatastandards[rc]["id"],
                        )
                del standard["relatedStandard"]

            metadatastandards_list.append(standard)

        return metadatastandards_list

    def parse_response(self, hits, metadatastandards):
        for hit in hits:
            subject = hit["s"]["value"]
            predicate = hit["p"]["value"]
            object = hit["o"]["value"]
            object_type = hit["o"]["type"]

            if (
                subject not in metadatastandards
            ):  # init document/dict for new subject
                metadatastandards[subject] = {}
                metadatastandards[subject]["uri"] = subject
                metadatastandards[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if (
                predicate == "http://nfdi4earth.de/ontology/hasDocument"
            ):  # document
                metadatastandards[subject]["document"] = object
            elif (
                predicate == "http://nfdi4earth.de/ontology/hasWebsite"
            ):  # website
                metadatastandards[subject]["website"] = object
            elif (
                predicate == "http://purl.org/dc/terms/modified"
            ):  # dateModified
                metadatastandards[subject]["dateModified"] = object
            elif (
                predicate == "http://nfdi4earth.de/ontology/hasXSD"
            ):  # website
                metadatastandards[subject]["xsd"] = object
            elif (
                predicate == "http://nfdi4earth.de/ontology/hasParentStandard"
            ):  # parentStandard
                if object_type == "literal":
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="parentStandard",
                        value=object,
                    )
                elif object_type == "uri":
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="relatedStandard",
                        value=object,
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/hasChildStandard"
            ):  # childStandard
                if object_type == "literal":
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="childStandard",
                        value=object,
                    )
                elif object_type == "uri":
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="relatedStandard",
                        value=object,
                    )
            elif (
                predicate == "http://schema.org/description"
            ):  # description
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="description",
                    value=object,
                )
            elif (
                predicate == "http://purl.org/dc/terms/type"
            ):  # additionalType
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif predicate == "http://purl.org/dc/terms/keyword":  # keyword
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="keyword",
                    value=object,
                )
            elif predicate == "http://purl.org/dc/terms/language":  # language
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="language",
                    value=object,
                )
            elif predicate == "http://purl.org/dc/terms/title":  # title
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="title",
                    value=object,
                )
                if (
                    "xml:lang" not in hit["o"] or hit["o"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    metadatastandards[subject]["mainTitle"] = object
            elif (
                predicate == "http://purl.org/dc/terms/publisher"
            ):  # publisher
                if (
                    "xml:lang" not in hit["o"]
                ):  # use international name for publisher name
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="publisher",
                        value=object,
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in metadatastandards[subject]
                    or object
                    not in metadatastandards[subject]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="publisher_alt",
                        value=object,
                    )
            elif predicate == "https://nfdi.fiz-karlsruhe.de/ontology/subjectArea":  # theme
                theme_label = self.themes_repo.get_theme(
                    object
                )  # get label for theme id
                if theme_label is not None:
                    self.addValue(
                        dict=metadatastandards[subject],
                        attribute="subjectArea",
                        value=theme_label,
                    )
            elif (
                predicate == "http://www.w3.org/ns/dcat#contactPoint"
            ):  # contactPoint
                if "contactpoint_email" in hit:
                    self.addValue(
                        metadatastandards[subject],
                        "contactPoint" + self.flatten_separator + "email",
                        hit["contactpoint_email"]["value"],
                    )
                if "contactpoint_url" in hit:
                    self.addValue(
                        metadatastandards[subject],
                        "contactPoint" + self.flatten_separator + "url",
                        hit["contactpoint_url"]["value"],
                    )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="type",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        metadatastandards[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        metadatastandards[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif (
                predicate == "implementedBy"
            ):  # add repositories that implement this metadata standard to related content
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="relatedContent",
                    value=self.getID(object),
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL" 
            ):  # sourceSystemURL
                self.addValue(
                    dict=metadatastandards[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )
