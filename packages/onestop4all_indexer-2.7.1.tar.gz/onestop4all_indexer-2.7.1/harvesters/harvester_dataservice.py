import logging
from .harvester_base import Harvester
from data_repositories.repository_theme import RepositoryTheme
from data_repositories import RepositoryPerson
from utils import sparql
from geomet import wkt as geomet_wkt
from shapely import wkt as shapely_wkt
from utils import SolrValidator

log = logging.getLogger(__name__)


# harvester for DataServices https://nfdi4earth.pages.rwth-aachen.de/knowledgehub/nfdi4earth-kh-schema/DataService/
class DataService_Harvester(Harvester):
    sparql_query = """
        PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>
        prefix dcat: <http://www.w3.org/ns/dcat#>
        prefix dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

        SELECT  ?subject ?predicate ?object ?contactpoint_email ?contactpoint_url ?sourceSystem_title ?sourceSystem_homepage
        {
            {
                ?subject rdf:type dcat:DataService.
                ?subject ?predicate ?object.
                FILTER (?predicate NOT IN (<http://purl.org/dc/terms/publisher>, dct:spatial, dcat:contactPoint, n4e:sourceSystem))
            }
            UNION{
                VALUES  ?predicate { <http://purl.org/dc/terms/publisher> }
                ?subject rdf:type dcat:DataService;
                        <http://purl.org/dc/terms/publisher> ?publisher.
                ?publisher <http://schema.org/name> ?object.
            }
            UNION{
                VALUES  ?predicate { dct:spatial }
                ?subject rdf:type dcat:DataService;
                dct:spatial ?spatial.
                ?spatial dcat:bbox ?object
            }
            UNION {
                VALUES ?predicate { dcat:contactPoint }
                ?subject rdf:type dcat:DataService;
                        dcat:contactPoint ?object.
                optional { ?object vcard:hasEmail ?contactpoint_email. }
                optional { ?object vcard:hasURL ?contactpoint_url. }
            }
            UNION{
                VALUES  ?predicate { n4e:sourceSystem }
                ?subject rdf:type dcat:DataService;
                        n4e:sourceSystem ?object.
                optional {?object dct:title ?sourceSystem_title.}
                optional {?object  foaf:homepage ?sourceSystem_homepage.}
            }
        }
        OFFSET %d
        LIMIT %d
    """

    def __init__(
        self,
        themes_repo: RepositoryTheme,
        persons_repo: RepositoryPerson,
        solr_validation=True,
        iteration_start=0,
        iteration_end=None,
        page_size=10000,
        **kw,
    ):
        super().__init__(**kw)
        self.themes_repo = themes_repo
        self.persons_repo = persons_repo
        self.solr_validator = SolrValidator()
        self.solr_validation = solr_validation
        self.removed_geometries = []
        self.iteration_start = (
            int(iteration_start) if iteration_start is not None else 0
        )
        self.iteration_end = (
            int(iteration_end) if iteration_end is not None else None
        )
        self.page_size = int(page_size) if page_size is not None else 10000
        log.info(
            f"""
Initialized DataService_Harvester with:
page_size={self.page_size}
iter_start={self.iteration_start}
iter_end={self.iteration_end}"""
        )

    def harvest(self):
        limit = self.page_size
        # convert to list of repo documents for indexing
        services = {}  # repos dict

        i = self.iteration_start
        hits = {}
        # split sparql query
        while True:
            if self.iteration_end is not None and i >= self.iteration_end:
                break

            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, services)

            i = i + 1

            if len(hits) < limit:
                break

        self.solr_validator.close()

        services_list = []
        for (
            key,
            value,
        ) in services.items():  # transform repos dict to list for indexing
            service = value
            if "mainTitle" not in service:
                if len(service.get("title", [])) > 0:
                    service["mainTitle"] = service["title"][0]
                else:
                    log.warning(f"Service {service['id']} has no mainTitle")
                    continue  # skip services without mainTitle
            service["mainTitle"] = service["mainTitle"].strip()
            services_list.append(service)

        return services_list

    def parse_response(self, hits, services):
        for hit in hits:
            subject = hit["subject"]["value"]
            predicate = hit["predicate"]["value"]
            object = hit["object"]["value"]

            if subject not in services:
                services[subject] = {}
                services[subject]["uri"] = subject
                services[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if predicate == "http://purl.org/dc/terms/title":  # name
                if (
                    "xml:lang" not in hit["object"]
                    or hit["object"]["xml:lang"] == "en"
                ):  # use international name for orga name
                    self.addValue(
                        dict=services[subject],
                        attribute="title",
                        value=object,
                    )
                    services[subject]["mainTitle"] = object  # mainTitle
                if (
                    "title" not in services[subject]
                    or object not in services[subject]["title"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=services[subject],
                        attribute="title",
                        value=object,
                    )
            elif (
                predicate == "http://www.w3.org/ns/dcat#endpointURL"
            ):  # endPointURL
                self.addValue(
                    dict=services[subject],
                    attribute="endpointURL",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/ns/dcat#endpointDescription"
            ):  # endpointDescription
                self.addValue(
                    dict=services[subject],
                    attribute="endpointDescription",
                    value=object,
                )
            elif (
                predicate == "http://purl.org/dc/terms/conformsTo"
            ):  # conformsTo
                services[subject]["conformsTo"] = object
            elif (
                predicate == "http://schema.org/additionalType"
            ):  # additionalType
                self.addValue(
                    dict=services[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif (
                predicate == "http://purl.org/dc/terms/issued"
            ):  # datePublished
                services[subject]["datePublished"] = object
            elif predicate == "http://www.w3.org/ns/dcat#keyword":  # keyword
                self.addValue(
                    dict=services[subject],
                    attribute="keyword",
                    value=object,
                )
            elif predicate == "http://purl.org/dc/terms/language":  # language
                self.addValue(
                    dict=services[subject],
                    attribute="language",
                    value=object,
                )
            elif (
                predicate
                == "https://nfdi.fiz-karlsruhe.de/ontology/subjectArea"
            ):  # subjectArea
                theme = self.themes_repo.get_theme(object)
                if theme is not None:
                    if "subjectArea" not in services[subject]:
                        services[subject]["subjectArea"] = []
                    services[subject]["subjectArea"].append(theme)
            elif (
                predicate == "http://www.w3.org/ns/dcat#landingPage"
            ):  # landingPage
                services[subject]["landingPage"] = object
            elif (
                predicate == "http://purl.org/dc/terms/modified"
            ):  # dateModified
                services[subject]["dateModified"] = object
            elif (
                predicate == "http://nfdi4earth.de/ontology/originalDataSource"
            ):  # originalDataSource
                services[subject]["originalDataSource"] = object
            elif predicate == "http://schema.org/version":  # version
                services[subject]["version"] = object
            elif predicate == "http://schema.org/description":  # description
                self.addValue(
                    dict=services[subject],
                    attribute="description",
                    value=object,
                )
            elif predicate == "http://purl.org/dc/terms/creator":  # creator
                creator = self.persons_repo.get_person(object)
                if creator is not None:
                    if "creator" not in services[subject]:
                        services[subject]["author"] = []
                    creator["type"] = ["person_nested"]  # required
                    if "creator" not in services[subject]:
                        services[subject]["creator"] = []
                        log.info(f"Service {subject} had not list of creator")
                    services[subject]["creator"].append(creator)
                    if "name" in creator:
                        self.addValue(
                            dict=services[subject],
                            attribute="searchHelper",
                            value=creator["name"],
                        )  # make author name searchable
            elif predicate == "http://schema.org/publisher":  # publisher
                if (
                    "xml:lang" not in hit["object"]
                ):  # use international name for publisher name
                    self.addValue(
                        dict=services[subject],
                        attribute="publisher",
                        value=object,
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in services[subject]
                    or object not in services[subject]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=services[subject],
                        attribute="publisher_alt",
                        value=object,
                    )
            elif predicate == "http://purl.org/dc/terms/spatial":  # bbox wkt
                geometry = object
                if geometry is not None:
                    services[subject][
                        "geometry_wkt"
                    ] = geometry  # orig wkt string, stored but unindexed
                    adj_geom = self.adjust_geometry(geometry)
                    # check if adjusted geometry is valid in SOLR
                    # check only if not disabled by solr_validation
                    # otherwise always assume valid
                    valid_in_solr = (
                        self.solr_validator.geometry(
                            adj_geom, type="DataService"
                        )
                        if self.solr_validation is True
                        else True
                    )
                    if adj_geom and valid_in_solr:
                        services[subject][
                            "geometry"
                        ] = adj_geom  # modified geom to avoid pole wrap for indexing in SOLR
                    else:
                        log.info(
                            str(subject)
                            + " - discovered invalid pointgeom "
                            + str(geometry)
                        )
                        self.removed_geometries.append(str(subject))
                        rem_gem_count = len(self.removed_geometries)
                        log.info(f"Total removed {rem_gem_count} geometries")
                        log.info(f"Service: {hit}")
            elif predicate == "http://www.w3.org/ns/dcat#theme":  # theme
                theme_label = self.themes_repo.get_theme(
                    object
                )  # get label for theme id
                if theme_label is not None:
                    self.addValue(
                        dict=services[subject],
                        attribute="theme",
                        value=theme_label,
                    )
            elif (
                predicate == "http://www.w3.org/ns/dcat#contactPoint"
            ):  # contactPoint
                if "contactpoint_email" in hit:
                    self.addValue(
                        services[subject],
                        "contactPoint" + self.flatten_separator + "email",
                        hit["contactpoint_email"]["value"],
                    )
                if "contactpoint_url" in hit:
                    self.addValue(
                        services[subject],
                        "contactPoint" + self.flatten_separator + "url",
                        hit["contactpoint_url"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=services[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        services[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        services[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                self.addValue(
                    dict=services[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/2004/02/skos/core#altLabel"
            ):  # altLabel
                self.addValue(
                    dict=services[subject],
                    attribute="altLabel",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=services[subject], attribute="type", value=object
                )

    # preliminary solution to handle geometry with pole wrap (e.g global polygon)
    # needed because otherwise geometries cannot be indexed in SOLR
    def adjust_geometry(self, geom_wkt):
        geom_wtk_upper = geom_wkt.upper()
        geom = geomet_wkt.loads(geom_wtk_upper)

        if (
            geom["type"].lower() == "polygon"
            or geom["type"].lower() == "multipolygon"
        ):
            ext_ring = geom["coordinates"][0]
            decimal_round = 5
            for coords in ext_ring:
                if coords[0] > 179.9:
                    coords[0] = 179.9
                elif coords[0] < -179.9:
                    coords[0] = -179.9
                else:
                    coords[0] = round(coords[0], decimal_round)
                if coords[1] > 89.9:
                    coords[1] = 89.9
                elif coords[1] < -89.9:
                    coords[1] = -89.9
                else:
                    coords[1] = round(coords[1], decimal_round)

            geom_wkt_rounded = geomet_wkt.dumps(geom)
            # due to rounding the geometry might have become invalid, e.g.
            # very small polygons which now have overlapping (coplanar)
            # coordinates
            shapely_geom = shapely_wkt.loads(geom_wkt_rounded)
            if not shapely_geom.is_valid:
                # try to get the centroid of those invalid geometries
                # to convert them to a valid point geometry
                centroid = shapely_geom.centroid
                if centroid.is_valid:
                    return centroid.wkt
                else:
                    return None
            else:
                return geom_wkt_rounded
        elif (
            geom["type"].lower() == "point"
            or geom["type"].lower() == "multipoint"
        ):
            # work-around for invalid point geometries in the data source
            lng, lat = geom["coordinates"]
            if not (-180 <= lng <= 180) or not (-90 <= lat <= 90):
                return None
            else:
                return geom_wkt
        else:
            return geom_wkt
