import logging
from .harvester_base import Harvester
from utils import sparql
from data_repositories.repository_n4eorganization import RepositoryN4EOrganization

log = logging.getLogger(__name__)

#harvester for Services https://nfdi4earth.pages.rwth-aachen.de/knowledgehub/nfdi4earth-kh-schema/Service/
class Service_Harvester(Harvester):
    sparql_query = """
        PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>
        prefix dcat: <http://www.w3.org/ns/dcat#>
        prefix dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

        SELECT  ?subject ?predicate ?object ?contactpoint_email ?contactpoint_url 
        {
            {
                ?subject rdf:type <http://schema.org/Service>.
                ?subject ?predicate ?object
                FILTER (?predicate NOT IN (dcat:contactPoint, n4e:sourceSystem))
            }
            UNION {
                VALUES ?predicate { dcat:contactPoint }
                ?subject rdf:type <http://schema.org/Service>;
                        dcat:contactPoint ?object.
                optional { ?object vcard:hasEmail ?contactpoint_email. }
                optional { ?object vcard:hasURL ?contactpoint_url. }
            }
        }
        ORDER BY ?subject ?predicate
        OFFSET %d
        LIMIT %d
    """

    def __init__(self, n4e_organizations_repo: RepositoryN4EOrganization, **kw):
        super().__init__(**kw)
        self.n4e_organizations_repo = n4e_organizations_repo

    def harvest(self):
        limit = 5000
        # convert to list of repo documents for indexing
        services = {}  # repos dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, services)

            i = i + 1

            if len(hits) < limit:
                break

        services_list = []
        for (
            key,
            value,
        ) in services.items():  # transform repos dict to list for indexing
            service = value
            if "mainTitle" not in service and len(service["name"]) > 0:
                service["mainTitle"] = service["name"][0]
            service["mainTitle"] = service["mainTitle"].strip()
            services_list.append(service)

        return services_list

    def parse_response(
            self, hits, services
        ):
            for hit in hits:
                subject = hit["subject"]["value"]
                predicate = hit["predicate"]["value"]
                object = hit["object"]["value"]
                
                if subject not in services:
                    services[subject] = {}
                    services[subject]["uri"] = subject
                    services[subject]["id"] = self.getID(
                        subject
                    )  # use ID from triple store also in Solr to ensure stable IDs

                if predicate == "http://schema.org/name":  # name
                    if (
                        "xml:lang" not in hit["object"]
                        or hit["object"]["xml:lang"] == "en"
                    ):  # use international name for orga name
                        self.addValue(
                            dict=services[subject],
                            attribute="name",
                            value=object,
                        )
                        services[subject]["mainTitle"] = object  # mainTitle
                    if (
                        "name" not in services[subject]
                        or object not in services[subject]["name"]
                    ):  # prevent duplicates
                        self.addValue(
                            dict=services[subject],
                            attribute="name",
                            value=object,
                        )
                elif predicate == "http://schema.org/description":  # description
                    self.addValue(
                        dict=services[subject],
                        attribute="description",
                        value=object,
                    )
                elif predicate == "http://schema.org/additionalType":  # additionalType
                    self.addValue(
                        dict=services[subject],
                        attribute="additionalType",
                        value=object,
                    )
                elif predicate == "http://schema.org/keywords":  # keyword
                    self.addValue(
                        dict=services[subject],
                        attribute="keyword",
                        value=object,
                    )
                elif predicate == "http://schema.org/url":  # url
                    self.addValue(
                        dict=services[subject],
                        attribute="url",
                        value=object,
                    )
                elif predicate == "http://nfdi4earth.de/ontology/serviceType":  # serviceType
                    services[subject]["serviceType"] = object
                elif predicate == "http://nfdi4earth.de/ontology/serviceHost":  # serviceHost
                    services[subject]["serviceHost"] = object
                elif predicate == "http://www.w3.org/ns/dcat#contactPoint":  # contactPoint
                    if "contactpoint_email" in hit:
                        self.addValue(
                            services[subject],
                            "contactPoint" + self.flatten_separator + "email",
                            hit["contactpoint_email"]["value"],
                        )
                    if "contactpoint_url" in hit:
                        self.addValue(
                            services[subject],
                            "contactPoint" + self.flatten_separator + "url",
                            hit["contactpoint_url"]["value"],
                        )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
                ):  # sourceSystemID
                    self.addValue(
                        dict=services[subject],
                        attribute="sourceSystem" + self.flatten_separator + "id",
                        value=object,
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystem"
                ):  # sourceSystem
                    if "sourceSystem_homepage" in hit:
                        self.addValue(
                            services[subject],
                            "sourceSystem" + self.flatten_separator + "homepage",
                            hit["sourceSystem_homepage"]["value"],
                        )
                    if "sourceSystem_title" in hit:
                        self.addValue(
                            services[subject],
                            "sourceSystem" + self.flatten_separator + "title",
                            hit["sourceSystem_title"]["value"],
                        )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
                ):  # sourceSystemURL
                    self.addValue(
                        dict=services[subject],
                        attribute="sourceSystemURL",
                        value=object,
                    )
                elif (
                    predicate == "http://www.w3.org/2004/02/skos/core#altLabel"
                ):  # altLabel
                    self.addValue(
                        dict=services[subject],
                        attribute="altLabel",
                        value=object,
                    )
                elif (
                    predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
                ):  # type
                    self.addValue(
                        dict=services[subject], 
                        attribute="type", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceType"
                ):  # serviceType
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceType", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceCategory"
                ):  # serviceCategory
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceCategory", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/idHostingInstitution"
                ): #idHostingInstitution #hostingInstitution_name  #isN4EOperated
                    host_rorID = object
                    services[subject]["idHostingInstitution"] = host_rorID #idHostingInstitution

                    n4e_organization = self.n4e_organizations_repo.get_n4e_organization_by_rorID(host_rorID) #check if rorID belongs to a organization that is n4e member
                    if n4e_organization is not None:
                        services[subject]["isN4EOperated"] = True #isN4EOperated
                        services[subject]["hostingInstitution_name"] = n4e_organization["name"] #hostingInstitution_name  currently only for n4e operated services
                        #only index if `True`, do not index if `False`
