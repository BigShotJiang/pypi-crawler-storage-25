import logging
import requests

from datetime import datetime, timezone
from geomet import wkt as geomet_wkt
from shapely import wkt as shapely_wkt
from utils import SolrValidator


from data_repositories import RepositoryPerson, RepositoryResourceLinks
from harvesters.harvester_base import HarvesterCordra

log = logging.getLogger(__name__)


# this harvester is for other (not Living Handbook) Articles (documents)
class Dataset_Harvester(HarvesterCordra):

    def __init__(
        self,
        persons_repo: RepositoryPerson,
        links_repo: RepositoryResourceLinks,
        iteration_start=0,
        iteration_end=None,
        page_size=50000,
        query='type:"Dataset"',
        #query='id:"n4e/dthb-oai-pangaea.de-doi-10.1594-PANGAEA.981078"', #downloadURL: https://cordra.knowledgehub.test.n4e.geo.tu-dresden.de/objects/n4e/dthb-oai-pangaea.de-doi-10.1594-PANGAEA.981078
        #query='id:"n4e/dthb-GB_NERC_BAS_PDC_01994"', #accessURL: https://cordra.knowledgehub.test.n4e.geo.tu-dresden.de/objects/n4e/dthb-GB_NERC_BAS_PDC_01994
        #query='id:"n4e/dthb-6A0D8B9D-1BBD-441B-BA5C-6159EE41EE71"', #multiple accessURLs: https://cordra.knowledgehub.nfdi4earth.de/objects/n4e/dthb-6A0D8B9D-1BBD-441B-BA5C-6159EE41EE71,
        solr_validation=True,
        **kw,
    ):
        super().__init__(**kw)
        self.persons_repo = persons_repo
        self.links_repo = links_repo
        self.removed_geometries = []
        self.solr_validator = SolrValidator()
        self.iteration_start = int(iteration_start)
        self.iteration_end = int(iteration_end)
        self.page_size = int(page_size)
        self.query = query
        self.solr_validation = solr_validation
        log.info("#" * 20)
        log.info(f"Init harvesting datasets from {self.kh_cordra_search_url}")
        log.info(f"Query: {self.query}")
        log.info(f"Page size: {self.page_size}")
        log.info(f"Iteration start: {self.iteration_start}")
        log.info(f"Iteration end: {self.iteration_end}")
        log.info(f"Solr validation: {solr_validation}")

    def get_notes(self):
        return [f"Invalid geometry: {rg}" for rg in self.removed_geometries]

    def harvest(self):
        datasets = {}  # all datasets dict
        i = self.iteration_start
        page_size = self.page_size
        while True:
            response = requests.get(
                self.kh_cordra_search_url,
                params={
                    "query": self.query,
                    "pageSize": page_size,
                    "pageNum": i,
                },
            )
            response_body = response.json()
            self.parse_response(response_body["results"], datasets)
            if (
                self.iteration_end is not None and i >= self.iteration_end
            ) or ((i + 1) * page_size > response_body["size"]):
                break
            i = i + 1
            log.info(
                f"Dataset harvesting, retrieved {i*page_size} datasets from REST endpoint {self.kh_cordra_search_url}"
            )

        self.solr_validator.close()
        dataset_list = []

        for (
            key,
            value,
        ) in datasets.items():  # transform documents dict to list for indexing
            dataset = value
            # ensure mainTitle
            if "mainTitle" not in dataset:
                if "title" in dataset and len(dataset["title"]) > 0:
                    # title possibly multivalued
                    title = dataset["title"][0]
                    if isinstance(title, str) and len(title.strip()) > 0:
                        dataset["mainTitle"] = title.strip()
            if "mainTitle" not in dataset or dataset["mainTitle"] == "":
                log.warning(f"Invalid dataset - missing title: {dataset}")
                continue
            dataset_list.append(dataset)

            links = self.links_repo.get_links(key)
            if links:
                dataset["relatedContent"] = [self.getID(l) for l in links]

        return dataset_list

    def parse_response(self, hits, datasets):
        for hit in hits:
            kh_object = hit["content"]
            subject = self.kh_objects_base_uri + kh_object["id"]
            if subject not in datasets:  # init document/dict for new subject
                datasets[subject] = {}
                datasets[subject]["uri"] = subject
                datasets[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            for key, value in kh_object.items():
                if key == "title":  # title
                    maint_title = ""
                    other_titles = []
                    # multivalued
                    for title_literal in value:
                        if (
                            isinstance(title_literal, dict)
                            and "@language" in title_literal
                            and title_literal["@language"] == "en"
                        ):
                            maint_title = title_literal["@value"]
                        title_str = self.get_string_from_jsonld(
                            title_literal, subject
                        )
                        self.addValue(
                            dict=datasets[subject],
                            attribute="title",
                            value=title_str,
                        )
                        other_titles.append(title_str)
                    if len(maint_title) == 0:
                        maint_title = other_titles[0]
                        datasets[subject]["mainTitle"] = maint_title
                elif key == "creator":  # creator
                    # multivalued blank node (or IRI in theory)
                    for creator_obj in value:
                        if isinstance(creator_obj, str):
                            # in this case this is an IRI referencing a remote person object
                            creator_iri = (
                                self.kh_objects_base_uri + creator_obj
                            )
                            creator = self.persons_repo.get_person(creator_iri)
                        elif isinstance(creator_obj, dict):
                            # in this case this is a blank node in the jsonld object
                            creator = {}
                            # creator["uri"] = self.kh_objects_base_uri + creator_obj["id"]
                            # creator["id"] = self.kh_objects_base_uri + creator_obj["id"]
                            for key, value in creator_obj.items():
                                if key == "name":
                                    # multivalued literal
                                    for literal in value:
                                        val = self.get_string_from_jsonld(
                                            literal, subject
                                        )
                                        if val:
                                            creator["name"] = val
                                            creator["mainTitle"] = val
                                if key == "email":
                                    # multivalued literal
                                    for literal in value:
                                        val = self.get_string_from_jsonld(
                                            literal, subject
                                        )
                                        if val:
                                            creator["email"] = val
                                if key == "orcidId":
                                    # literal
                                    val = self.get_string_from_jsonld(
                                        value, subject
                                    )
                                    if val:
                                        creator["orcidId"] = val
                                if key == "affiliation":
                                    # multivalued literal
                                    for organization in value:
                                        if (
                                            isinstance(organization, dict)
                                            and "name" in organization
                                        ):
                                            for name in organization["name"]:
                                                # TODO: can the creator have multiple affiliations
                                                # in the SOLR schema? if yes this code here needs
                                                # to be adapted (currently only uses the last item
                                                # of the list)
                                                val = self.get_string_from_jsonld(
                                                    name, subject
                                                )
                                                if val:
                                                    creator["affiliation"] = (
                                                        val
                                                    )
                        if creator is not None:
                            if "creator" not in datasets[subject]:
                                datasets[subject]["creator"] = []
                            creator["type"] = ["person_nested"]  # required
                            datasets[subject]["creator"].append(creator)
                            if "name" in creator:
                                self.addValue(
                                    dict=datasets[subject],
                                    attribute="searchHelper",
                                    value=creator["name"],
                                )  # make creator name searchable
                elif key == "modified":  # dateModified
                    # literal
                    val = self.get_string_from_jsonld(value, subject)
                    datasets[subject]["dateModified"] = val
                elif key == "issued":  # datePublished
                    # literal
                    val = self.get_string_from_jsonld(value, subject)
                    datasets[subject]["datePublished"] = val
                elif key == "landingPage":  # homepage
                    # literal
                    val = self.get_string_from_jsonld(value, subject)
                    datasets[subject]["homepage"] = val
                elif key == "additionalType":  # additionalType
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="additionalType",
                                value=val,
                            )
                elif key == "description":  # description
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="description",
                                value=val,
                            )
                elif key == "conformsTo":  # conformsTo
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="conformsTo",
                                value=val,
                            )
                elif key == "altLabel":  # altLabel
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="altLabel",
                                value=val,
                            )
                elif key == "keyword":  # keyword
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="keyword",
                                value=val,
                            )
                elif key == "distribution":  # distribution
                    for distribution in value:
                        if "accessURL" in distribution:
                            for access_url in distribution["accessURL"]:
                                val = self.get_string_from_jsonld(
                                    access_url, subject
                                )
                                if val:
                                    self.addValue(
                                        dict=datasets[subject],
                                        attribute="distribution" + self.flatten_separator + "accessURL",
                                        value=val,
                                    )
                        if "title" in distribution:
                            for title in distribution["title"]:
                                val = self.get_string_from_jsonld(
                                    title, subject
                                )
                                if val:
                                    self.addValue(
                                        dict=datasets[subject],
                                        attribute="distribution" + self.flatten_separator + "title",
                                        value=val,
                                    )
                        if "downloadURL" in distribution:
                            for download_url in distribution["downloadURL"]:
                                val = self.get_string_from_jsonld(download_url, subject)
                                if val:
                                    self.addValue(
                                        dict=datasets[subject],
                                        attribute="distribution" + self.flatten_separator + "downloadURL",
                                        value=val,
                                    )
                elif key == "spatialCoverage":
                    for spatialCoverage in value:
                        if "geometry" in spatialCoverage:
                            datasets[subject]["geometry_wkt"] = value[
                                "geometry"
                            ]  # orig wkt string, stored but unindexed
                            adj_geom = self.adjust_geometry(value["geometry"])
                            # check if adjusted geometry is valid in SOLR
                            # check only if not disabled by solr_validation
                            # otherwise always assume valid
                            valid_in_solr = (
                                self.solr_validator.geometry(adj_geom)
                                if self.solr_validation is True
                                else True
                            )
                            if adj_geom and valid_in_solr:
                                datasets[subject][
                                    "geometry"
                                ] = adj_geom  # modified geom to avoid pole wrap for indexing in SOLR
                            else:
                                log.info(
                                    str(subject)
                                    + " - discovered invalid pointgeom "
                                    + str(value["geometry"])
                                )
                                self.removed_geometries.append(str(subject))
                                rem_gem_count = len(self.removed_geometries)
                                log.info(
                                    f"Total removed {rem_gem_count} geometries"
                                )
                                log.info(f"Dataset: {hit}")
                elif key == "temporal":  # temporal coverage
                    # multivalued according to kh schema v0.25.0, error, should be changed in the schema!
                    for period_of_time in value:
                        if "startDate" in period_of_time:
                            # literal
                            val = self.get_string_from_jsonld(
                                period_of_time["startDate"], subject
                            )
                            if val:
                                datasets[subject][
                                    "temporal"
                                    + self.flatten_separator
                                    + "startDate"
                                ] = val
                        if "endDate" in period_of_time:
                            # literal
                            val = self.get_string_from_jsonld(
                                period_of_time["endDate"], subject
                            )
                            if val:
                                datasets[subject][
                                    "temporal"
                                    + self.flatten_separator
                                    + "endDate"
                                ] = val
                elif key == "variableMeasured":  # variableMeasured
                    # multivalued literal
                    for literal in value:
                        val = self.get_string_from_jsonld(literal, subject)
                        if val:
                            self.addValue(
                                dict=datasets[subject],
                                attribute="variableMeasured",
                                value=val,
                            )
                # elif key == "publisher": #publisher
                #    self.addValue(dict=datasets[subject], attribute="publisher", value = object)
                # elif key == "theme": #theme
                #    self.addValue(dict=datasets[subject], attribute="theme", value = object)
                # elif key == "subjectArea": #subjectArea
                #    self.addValue(dict=datasets[subject], attribute="subjectArea", value = object)
                # elif key == "version": #version
                #    datasets[subject]["version"] = object
                elif key == "contactPoint":  # contactPoint
                    # multivalued
                    for contact_point in value:
                        # TODO: fullname fn (see https://nfdi4earth.pages.rwth-aachen.de/knowledgehub/nfdi4earth-kh-schema/Kind/)
                        if "hasEmail" in contact_point:
                            # multivalued literal
                            for email in contact_point["hasEmail"]:
                                val = self.get_string_from_jsonld(
                                    email, subject
                                )
                                if val:
                                    self.addValue(
                                        datasets[subject],
                                        "contactPoint"
                                        + self.flatten_separator
                                        + "email",
                                        val,
                                    )
                        if "hasURL" in contact_point:
                            # multivalued literal
                            for url in contact_point["hasURL"]:
                                val = self.get_string_from_jsonld(url, subject)
                                if val:
                                    self.addValue(
                                        datasets[subject],
                                        "contactPoint"
                                        + self.flatten_separator
                                        + "url",
                                        val,
                                    )
                elif key == "sourceSystem":  # sourceSystem
                    pass
                    # NOTE: the code below assumes that sourceSystem points to a KH object of type catalog/registry/ etc.
                    # however this is outdated. It is currently pointing to the KH objects for a harvesting system, and
                    # this info is not publicly visible so can be ommited in the OneStop4All
                    # This has to be improved somehow in the future if want to clearly state something like
                    # "dataset was harvested from XXX"
                    # However the property sourceSystemURL is available (for most classes) and should be used
                    """
                    if "sourceSystem_homepage" in hit:
                        self.addValue(datasets[subject], "sourceSystem" + self.flatten_separator +  "homepage", hit["sourceSystem_homepage"]["value"])
                    if "sourceSystem_title" in hit:
                        self.addValue(datasets[subject], "sourceSystem" + self.flatten_separator +  "title", hit["sourceSystem_title"]["value"])
                    """
                elif key == "sourceSystemID":  # sourceSystemID
                    self.addValue(
                        dict=datasets[subject],
                        attribute="sourceSystem"
                        + self.flatten_separator
                        + "id",
                        value=value,
                    )
                elif key == "@type":  # type
                    val = "http://www.w3.org/ns/dcat#Dataset"
                    self.addValue(
                        dict=datasets[subject], attribute="type", value=val
                    )

    def get_string_from_jsonld(self, jsonld_literal, subject):
        if isinstance(jsonld_literal, str):
            return jsonld_literal
        elif isinstance(jsonld_literal, dict) and "@value" in jsonld_literal:
            return jsonld_literal["@value"]
        log.warn(
            f"Could not parse literal: {jsonld_literal} on dataset {subject}"
        )

    # add common temporal attribute for search
    # function currently unused but potentially interesting for temporal search on research period
    def add_temp_search_attribute(self, dataset):
        searchAttr = "datePublished"
        start_UTC = None
        end_UTC = None
        if (
            "temporal" + self.flatten_separator + "startDate" in dataset
        ):  # has startDate
            start = dataset["temporal" + self.flatten_separator + "startDate"]
            start_UTC = (
                datetime.fromisoformat(start)
                .astimezone(timezone.utc)
                .isoformat()[:-6]
                + "Z"
            )
        if (
            "temporal" + self.flatten_separator + "endDate" in dataset
        ):  # has endDate
            end = dataset["temporal" + self.flatten_separator + "endDate"]
            end_UTC = (
                datetime.fromisoformat(end)
                .astimezone(timezone.utc)
                .isoformat()[:-6]
                + "Z"
            )
        if start_UTC is not None and end_UTC is not None:
            if start_UTC == end_UTC:
                dataset[searchAttr] = start_UTC
            else:
                dataset[searchAttr] = "[" + start_UTC + " TO " + end_UTC + "]"
            return
        elif start_UTC is not None:
            dataset[searchAttr] = "[" + start_UTC + " TO *]"
            return
        elif end_UTC is not None:
            dataset[searchAttr] = "[* TO " + end_UTC + "]"
            return

    # preliminary solution to handle geometry with pole wrap (e.g global polygon)
    # needed because otherwise geometries cannot be indexed in SOLR
    def adjust_geometry(self, geom_wkt):
        geom_wtk_upper = geom_wkt.upper()
        geom = geomet_wkt.loads(geom_wtk_upper)

        if (
            geom["type"].lower() == "polygon"
            or geom["type"].lower() == "multipolygon"
        ):
            ext_ring = geom["coordinates"][0]
            decimal_round = 5
            for coords in ext_ring:
                if coords[0] > 179.9:
                    coords[0] = 179.9
                elif coords[0] < -179.9:
                    coords[0] = -179.9
                else:
                    coords[0] = round(coords[0], decimal_round)
                if coords[1] > 89.9:
                    coords[1] = 89.9
                elif coords[1] < -89.9:
                    coords[1] = -89.9
                else:
                    coords[1] = round(coords[1], decimal_round)

            geom_wkt_rounded = geomet_wkt.dumps(geom)
            # due to rounding the geometry might have become invalid, e.g.
            # very small polygons which now have overlapping (coplanar)
            # coordinates
            shapely_geom = shapely_wkt.loads(geom_wkt_rounded)
            if not shapely_geom.is_valid:
                # try to get the centroid of those invalid geometries
                # to convert them to a valid point geometry
                centroid = shapely_geom.centroid
                if centroid.is_valid:
                    return centroid.wkt
                else:
                    return None
            else:
                return geom_wkt_rounded
        elif (
            geom["type"].lower() == "point"
            or geom["type"].lower() == "multipoint"
        ):
            # work-around for invalid point geometries in the data source
            lng, lat = geom["coordinates"]
            if not (-180 <= lng <= 180) or not (-90 <= lat <= 90):
                return None
            else:
                return geom_wkt
        else:
            return geom_wkt
