import logging
from .harvester_base import Harvester
from data_repositories.repository_person import RepositoryPerson
from data_repositories.repository_theme import RepositoryTheme
from utils import sparql

log = logging.getLogger(__name__)


class Learningresource_Harvester(Harvester):
    sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX dct: <http://purl.org/dc/terms/>
        PREFIX schema: <http://schema.org/>

        SELECT ?subject ?predicate ?object ?sourceSystem_homepage ?sourceSystem_title
        WHERE {
        {
        ?subject rdf:type <http://schema.org/LearningResource>.
            ?subject ?predicate ?object
            FILTER (?predicate NOT IN (dct:publisher, <http://schema.org/license>, <http://schema.org/about>, <http://schema.org/audience>))
        }
        UNION{
            VALUES  ?predicate { dct:publisher }
            ?subject rdf:type <http://schema.org/LearningResource>;
                    dct:publisher ?object.
        }
        UNION{
            VALUES  ?predicate { <http://schema.org/about> }
            ?subject rdf:type <http://schema.org/LearningResource>;
                    <http://schema.org/about> ?about.
            ?about dct:title ?object.
        }
        UNION{
            VALUES  ?predicate { <http://schema.org/audience> }
            ?subject rdf:type <http://schema.org/LearningResource>;
                    <http://schema.org/audience> ?audience.
            ?audience dct:title ?object.
        }
        UNION{
            VALUES  ?predicate { n4e:sourceSystem }
            ?subject rdf:type <http://schema.org/LearningResource>;
                    n4e:sourceSystem ?object.
            optional {?object dct:title ?sourceSystem_title.}
            optional {?object foaf:homepage ?sourceSystem_homepage.}
            }
             Union {
                VALUES  ?predicate { <http://schema.org/license> }
                ?subject rdf:type <http://schema.org/LearningResource>;
                         <http://schema.org/license> ?license.
                ?license <http://spdx.org/rdf/terms#licenseId> ?object.
            }
        }
        Order By ?subject ?predicate
        OFFSET %d
        LIMIT %d
    """

    def __init__(
        self,
        persons_repo: RepositoryPerson,
        themes_repo: RepositoryTheme,
        **kw,
    ):
        super().__init__(**kw)
        self.persons_repo = persons_repo
        self.themes_repo = themes_repo

    def harvest(self):
        limit = 5000
        resources = {}  # all resources dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (
                limit * i,
                limit,
            )
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, resources)
            i = i + 1

            if len(hits) < limit:
                break

        resources_list = []
        for (
            key,
            value,
        ) in (
            resources.items()
        ):  # transform resources dict to list for indexing
            resource = value
            # ensure mainTitle
            if "mainTitle" not in resource and len(resource["name"]) > 0:
                resource["mainTitle"] = resource["name"][0]
            resource["mainTitle"] = resource["mainTitle"].strip()
            resources_list.append(resource)

        return resources_list

    def parse_response(self, hits, resources):
        for hit in hits:
            subject = hit["subject"]["value"]
            predicate = hit["predicate"]["value"]
            object = hit["object"]["value"]

            if subject not in resources:  # init document/dict for new subject
                resources[subject] = {}
                resources[subject]["uri"] = subject
                resources[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if predicate == "http://schema.org/name":  # name
                self.addValue(
                    dict=resources[subject], attribute="name", value=object
                )
                if (
                    "xml:lang" not in hit["object"]
                    or hit["object"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    resources[subject]["mainTitle"] = object
            elif predicate == "http://schema.org/author":  # author
                author = self.persons_repo.get_person(object)
                if author is not None:
                    if "author" not in resources[subject]:
                        resources[subject]["author"] = []
                    author["type"] = ["person_nested"]  # required
                    resources[subject]["author"].append(author)
                    if "name" in author:
                        self.addValue(
                            dict=resources[subject],
                            attribute="searchHelper",
                            value=author["name"],
                        )  # make author name searchable
            elif (
                predicate
                == "https://nfdi.fiz-karlsruhe.de/ontology/subjectArea"
            ):  # subjectArea
                theme = self.themes_repo.get_theme(object)
                if theme is not None:
                    if "subjectArea" not in resources[subject]:
                        resources[subject]["subjectArea"] = []
                    resources[subject]["subjectArea"].append(theme)
            elif (
                predicate == "http://schema.org/additionalType"
            ):  # additionalType
                self.addValue(
                    dict=resources[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif predicate == "http://schema.org/dateModified":  # dateModified
                resources[subject]["dateModified"] = object
            elif predicate == "http://schema.org/description":  # description
                self.addValue(
                    dict=resources[subject],
                    attribute="description",
                    value=object,
                )
            elif predicate == "http://schema.org/url":  # url
                self.addValue(
                    dict=resources[subject], attribute="url", value=object
                )
            elif predicate == "http://schema.org/about":  # about
                self.addValue(
                    dict=resources[subject], attribute="about", value=object
                )
            elif predicate == "http://purl.org/dc/terms/publisher":  # publisher
                self.addValue(
                    dict=resources[subject], attribute="publisher", value=object
                )
            elif predicate == "http://schema.org/audience":  # audience
                self.addValue(
                    dict=resources[subject], attribute="audience", value=object
                )
            elif (
                predicate == "http://schema.org/datePublished"
            ):  # datePublished
                resources[subject]["datePublished"] = object
            elif predicate == "http://schema.org/inLanguage":  # language
                self.addValue(
                    dict=resources[subject], attribute="language", value=object
                )
            elif predicate == "http://schema.org/isPartOf":  # isPartOf
                self.addValue(
                    dict=resources[subject], attribute="isPartOf", value=object
                )
            elif predicate == "http://schema.org/keywords":  # keyword
                self.addValue(
                    dict=resources[subject], attribute="keyword", value=object
                )
            elif predicate == "http://schema.org/license":  # license
                self.addValue(
                    dict=resources[subject], attribute="license", value=object
                )
            elif (
                predicate == "http://schema.org/learningResourceType"
            ):  # learningResourceType
                self.addValue(
                    dict=resources[subject],
                    attribute="learningResourceType",
                    value=object,
                )
            elif (
                predicate == "http://schema.org/competencyRequired"
            ):  # competencyRequired
                self.addValue(
                    dict=resources[subject],
                    attribute="competencyRequired",
                    value=object,
                )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=resources[subject], attribute="type", value=object
                )
            #elif predicate == "http://schema.org/publisher":  # publisher
            #    if (
            #        "xml:lang" not in hit["object"]
            #    ):  # use international name for publisher name
            #        self.addValue(
            #            dict=resources[subject],
            #            attribute="publisher",
            #            value=object,
            #        )
            #    # index all versions of publisher name as alternative
            #    if (
            #        "publisher_alt" not in resources[subject]
            #        or object not in resources[subject]["publisher_alt"]
            #    ):  # prevent duplicates
             #       self.addValue(
            #            dict=resources[subject],
            #            attribute="publisher_alt",
            #            value=object,
            #        )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        resources[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        resources[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=resources[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                if object.startswith("https://edutrain"):
                    self.addValue(
                        dict=resources[subject],
                        attribute="isEdutrain",
                        value=True,
                    )
                else:
                    self.addValue(
                        dict=resources[subject],
                        attribute="isEdutrain",
                        value=False,
                    )
                
                self.addValue(
                    dict=resources[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )

