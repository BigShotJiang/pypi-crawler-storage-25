import logging

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from utils import config, addValue, id_from_uri

log = logging.getLogger(__name__)


class HarvesterBase(ABC):
    flatten_separator = "_"

    def addValue(self, dict, attribute, value, unique=False):
        addValue(dict, attribute, value, unique=unique)

    def getID(self, subject_id):
        return id_from_uri(subject_id)

    @abstractmethod
    def harvest(self) -> List[Dict]:
        pass

    def get_type(self):
        class_name = str(self.__class__)
        # find last dot
        dot_index = class_name.rfind(".")
        # take everything right behind last dot && leave away last 2 signs
        return class_name[(dot_index + 1) : -2]

    def get_notes(self):
        # to be implemented by each class
        # returns only an empty array, if unimplemented
        return []


class Harvester(HarvesterBase):

    def __init__(
        self,
        sparql_endpoint: Optional[str] = None,
        **kw,
    ):
        self.sparql_endpoint = (
            sparql_endpoint if sparql_endpoint else config["sparql_endpoint"]
        )


class HarvesterCordra(HarvesterBase):

    def __init__(self, cordra_endpoint: Optional[str] = None, **kw):
        self.cordra_endpoint = (
            cordra_endpoint if cordra_endpoint else config["cordra_endpoint"]
        )
        self.kh_objects_base_uri = f"{self.cordra_endpoint}/objects/"
        self.kh_cordra_search_url = f"{self.cordra_endpoint}/search"
