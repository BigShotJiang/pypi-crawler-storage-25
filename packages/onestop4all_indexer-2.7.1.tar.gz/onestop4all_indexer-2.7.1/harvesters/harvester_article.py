import logging
from .harvester_base import Harvester
from data_repositories import RepositoryPerson, RepositoryResourceLinks
from data_repositories.repository_theme import RepositoryTheme
from utils import sparql

log = logging.getLogger(__name__)


# this harvester is for Living Handbook (LHB) Articles
class Article_Harvester(Harvester):
    sparql_query = """
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

        SELECT ?s ?p ?o ?sourceSystem_homepage ?sourceSystem_title
        WHERE {
                {
                ?s rdf:type <http://nfdi4earth.de/ontology/LHBArticle>.
                ?s ?p ?o
                FILTER (?p NOT IN (<http://schema.org/publisher>, n4e:sourceSystem, <http://schema.org/audience>))
                }
                UNION{
                    VALUES  ?p { <http://schema.org/publisher> }
                    ?s rdf:type <http://nfdi4earth.de/ontology/LHBArticle>;
                            <http://schema.org/publisher> ?publisher.
                    ?publisher <http://schema.org/name> ?o.
                }
                UNION{
                    VALUES  ?p { <http://schema.org/audience> }
                    ?s rdf:type <http://nfdi4earth.de/ontology/LHBArticle>;
                            <http://schema.org/audience> ?audience.
                    ?audience dct:title ?o.
                }
                UNION{
                    VALUES  ?p { n4e:sourceSystem }
                    ?s rdf:type <http://nfdi4earth.de/ontology/LHBArticle>;
                            n4e:sourceSystem ?o.
                    optional {?o dct:title ?sourceSystem_title.}
                    optional {?o foaf:homepage ?sourceSystem_homepage.}
                }
            }
            Order By ?s ?p
            OFFSET %d
            LIMIT %d
    """

    def __init__(
        self,
        persons_repo: RepositoryPerson,
        links_repo: RepositoryResourceLinks,
        themes_repo: RepositoryTheme,
        **kw,
    ):
        super().__init__(**kw)
        self.persons_repo = persons_repo
        self.links_repo = links_repo
        self.themes_repo = themes_repo

    def harvest(self):
        limit = 5000
        articles = {}  # all articles dict

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(hits, articles)
            i = i + 1

            if len(hits) < limit:
                break

        articles_list = []
        for (
            key,
            value,
        ) in articles.items():  # transform articles dict to list for indexing
            article = value
            related_content_ids = []
            # ensure mainTitle
            if "mainTitle" not in article and len(article["name"]) > 0:
                article["mainTitle"] = article["name"][0]
            article["mainTitle"] = article["mainTitle"].strip()
            if "isPartOf" in article:  # resolve partens (isPartOf)
                parents_names = []
                for parent in article["isPartOf"]:
                    if parent in articles:
                        parents_names.extend(articles[parent]["name"])
                        parent_id = articles[parent]["id"]
                        related_content_ids.extend([parent_id])
                article["isPartOf"] = parents_names
            if "hasPart" in article:  # resolve children (hasPart)
                children_names = []
                for child in article["hasPart"]:
                    if child in articles:
                        children_names.extend(articles[child]["name"])
                        child_id = articles[child]["id"]
                        related_content_ids.extend([child_id])
                article["hasPart"] = children_names

            links = self.links_repo.get_links(key)
            if links:
                related_content_ids.extend([self.getID(l) for l in links])
            article["relatedContent"] = related_content_ids
            articles_list.append(article)

        return articles_list

    def parse_response(self, hits, articles):
        for hit in hits:
            subject = hit["s"]["value"]
            predicate = hit["p"]["value"]
            object = hit["o"]["value"]

            if subject not in articles:  # init document/dict for new subject
                articles[subject] = {}
                articles[subject]["uri"] = subject
                articles[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs

            if predicate == "http://schema.org/name":  # name
                self.addValue(
                    dict=articles[subject], attribute="name", value=object
                )
                if (
                    "xml:lang" not in hit["o"] or hit["o"]["xml:lang"] == "en"
                ):  # use international name for mainTitle
                    articles[subject]["mainTitle"] = object
            elif predicate == "http://schema.org/author":  # author
                author = self.persons_repo.get_person(object)
                if author is not None:
                    if "author" not in articles[subject]:
                        articles[subject]["author"] = []
                    author["type"] = ["person_nested"]  # required
                    articles[subject]["author"].append(author)
                    if "name" in author:
                        self.addValue(
                            dict=articles[subject],
                            attribute="searchHelper",
                            value=author["name"],
                        )  # make author name searchable
            elif predicate == "http://schema.org/dateModified":  # dateModified
                articles[subject]["dateModified"] = object
            elif predicate == "http://schema.org/articleBody":  # articleBody
                self.addValue(
                    dict=articles[subject],
                    attribute="articleBody",
                    value=object,
                )
            elif (
                predicate == "http://schema.org/additionalType"
            ):  # additionalType
                self.addValue(
                    dict=articles[subject],
                    attribute="additionalType",
                    value=object,
                )
            elif predicate == "http://schema.org/description":  # description
                self.addValue(
                    dict=articles[subject],
                    attribute="description",
                    value=object,
                )
            elif predicate == "http://schema.org/url":  # url
                self.addValue(
                    dict=articles[subject], attribute="url", value=object
                )
            elif predicate == "http://schema.org/about":  # about
                self.addValue(
                    dict=articles[subject], attribute="about", value=object
                )
            elif predicate == "http://schema.org/audience":  # audience
                self.addValue(
                    dict=articles[subject], attribute="audience", value=object
                )
            elif (
                predicate == "http://schema.org/datePublished"
            ):  # datePublished
                articles[subject]["datePublished"] = object
            elif predicate == "http://schema.org/inLanguage":  # language
                self.addValue(
                    dict=articles[subject], attribute="language", value=object
                )
            elif predicate == "http://schema.org/isPartOf":  # isPartOf
                self.addValue(
                    dict=articles[subject], attribute="isPartOf", value=object
                )
            elif predicate == "http://schema.org/keywords":  # keyword
                self.addValue(
                    dict=articles[subject], attribute="keyword", value=object
                )
            elif predicate == "http://schema.org/license":  # license
                self.addValue(
                    dict=articles[subject], attribute="license", value=object
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/targetGroup"
            ):  # targetGroup
                self.addValue(
                    dict=articles[subject],
                    attribute="targetGroup",
                    value=object,
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystem"
            ):  # sourceSystem
                if "sourceSystem_homepage" in hit:
                    self.addValue(
                        articles[subject],
                        "sourceSystem" + self.flatten_separator + "homepage",
                        hit["sourceSystem_homepage"]["value"],
                    )
                if "sourceSystem_title" in hit:
                    self.addValue(
                        articles[subject],
                        "sourceSystem" + self.flatten_separator + "title",
                        hit["sourceSystem_title"]["value"],
                    )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
            ):  # sourceSystemID
                self.addValue(
                    dict=articles[subject],
                    attribute="sourceSystem" + self.flatten_separator + "id",
                    value=object,
                )
            elif predicate == "http://schema.org/publisher":  # publisher
                if (
                    "xml:lang" not in hit["o"]
                ):  # use international name for publisher name
                    self.addValue(
                        dict=articles[subject],
                        attribute="publisher",
                        value=object,
                    )
                # index all versions of publisher name as alternative
                if (
                    "publisher_alt" not in articles[subject]
                    or object not in articles[subject]["publisher_alt"]
                ):  # prevent duplicates
                    self.addValue(
                        dict=articles[subject],
                        attribute="publisher_alt",
                        value=object,
                    )
            elif (
                predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
            ):  # type
                self.addValue(
                    dict=articles[subject], attribute="type", value=object
                )
            elif (
                predicate == "http://schema.org/isPartOf"
            ):  # isPartOf (store id, resolve name later)
                self.addValue(
                    dict=articles[subject], attribute="isPartOf", value=object
                )
            elif (
                predicate == "http://schema.org/hasPart"
            ):  # hasPart (store id, resolve name later)
                self.addValue(
                    dict=articles[subject], attribute="hasPart", value=object
                )
            elif (
                predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
            ):  # sourceSystemURL
                self.addValue(
                    dict=articles[subject],
                    attribute="sourceSystemURL",
                    value=object,
                )
            elif (
                predicate == "https://nfdi.fiz-karlsruhe.de/ontology/subjectArea"
            ): # subjectArea
                theme_label = self.themes_repo.get_theme(object)
                if theme_label is not None:
                    self.addValue(
                        dict=articles[subject],
                        attribute="subjectArea",
                        value=theme_label
                    )
