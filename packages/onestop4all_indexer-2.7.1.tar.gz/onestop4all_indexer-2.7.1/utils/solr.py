import logging

from pysolr import Solr as SolrBase
from requests.auth import HTTPBasicAuth
from typing import List, Dict, Optional, Literal
from urllib.parse import urljoin

from utils import config

log = logging.getLogger(__name__)


class Solr(object):
    def __init__(
        self,
        solr_url: Optional[str] = None,
        solr_core: Optional[str] = None,
        solr_auth: Optional[str] = None,
        always_commit: bool = False,
        timeout: int = 5 * 60,
    ) -> None:
        self.solr_url = solr_url
        self.solr_core = solr_core
        self.auth = solr_auth
        self.solr = SolrBase(
            self.endpoint,
            auth=self.authentication,
            always_commit=always_commit,
            timeout=timeout,
        )

    @property
    def endpoint(self):
        # using config-values (by default) OR
        # overwrite with initially given values
        solr_url = self.solr_url if self.solr_url else config["solr_url"]
        solr_core = self.solr_core if self.solr_core else config["solr_core"]
        return urljoin(solr_url, solr_core)

    @property
    def authentication(self):
        if self.auth or config["solr_auth"]:
            username, password = (
                self.auth.split(":")
                if self.auth
                else config["solr_auth"].split(":")
            )
            return HTTPBasicAuth(username, password)

    def index_documents(self, documents: List[Dict]) -> None:
        # solr_endpoint = coreurl(solr_url, solr_core)
        log.info(
            f"start indexing {len(documents)} documents to {self.endpoint}"
        )

        batch_size = 50000
        offset = 0
        iteration = 0
        while True:
            if len(documents) <= offset + batch_size:
                batch = documents[offset:]
            else:
                batch = documents[offset : (offset + batch_size)]

            if len(batch) == 0:
                break

            self.solr.ping()
            log.info("solr healtcheck successful")
            try:
                log.info(f"start adding batch of {len(batch)} documents")
                self.solr.add(batch)
                log.info(f"finished adding batch of {len(batch)} documents")
            except Exception as e:
                log.error(e)
            log.info(f"current iteration: {iteration}")
            offset = offset + batch_size
            iteration += 1

            if len(batch) < batch_size:
                break

        log.info("commit changes to index")
        self.solr.ping()
        log.info("solr healtcheck successful")
        self.solr.commit()
        log.info("sucessfully commited changes to index")
        log.info("finished indexing")

    def reset_index(self):
        log.info(f"reset index for: {self.endpoint}")
        self.solr.delete(q="*:*")
        self.solr.commit()


class SolrValidator(Solr):
    def geometry(
        self, geometry, type: Literal["Dataset", "Dataservice"] = "Dataset"
    ) -> bool:
        dataset = {
            "id": "geomValidationTest",
            "type": ([f"http://www.w3.org/ns/dcat#{type}"]),
            "geometry": geometry,
            "mainTitle": "Geometry Validation Test",
        }

        try:
            self.solr.add(dataset)
            return True
        except Exception as e:
            log.error(e)
            return False

    def close(self):
        self.solr.delete({"id": "geomValidationTest"})
