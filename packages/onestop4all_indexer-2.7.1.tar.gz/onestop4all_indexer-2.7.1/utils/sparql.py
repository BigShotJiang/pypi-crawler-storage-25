import logging

from SPARQLWrapper import SPARQLWrapper, JSON
from typing import List
import time

log = logging.getLogger(__name__)


def execute_query(sparql_endpoint: str, sparql_query: str) -> List:
    # init sparql client
    sparql = SPARQLWrapper(sparql_endpoint)
    sparql.setReturnFormat(JSON)
    sparql.setQuery(sparql_query)
    max_attempts = 5
    wait_time_seconds = 10

    for i in range(max_attempts): #retry
        try:
            log.info('execute sparql query {} at {}, attempt {} of {}'.format(sparql_query, sparql_endpoint, str(i+1), str(max_attempts)))
            response = sparql.queryAndConvert()
        except:
            log.error("request failed, attempt {} of {}".format(str(i+1), str(max_attempts)))
            if i < (max_attempts -1):
                log.info("wait for {} seconds until retry".format(str(wait_time_seconds)))
                time.sleep(wait_time_seconds)
                continue
            else:
                log.error("request failed ultimately")
                raise
        break #if succeeded no retry

    response = sparql.queryAndConvert()
    hits = response["results"]["bindings"]
    log.info("query returned {} triples ".format(len(hits)))
    return hits
