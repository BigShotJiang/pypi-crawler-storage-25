import os
from jproperties import Properties

app_properties = Properties()

with open("./application.properties", "rb") as config_file:
    app_properties.load(config_file)


def parse_bool_config(value):
    if value.lower() in ["false", "0", "f", "no", "n"]:
        return False
    elif value.lower() in ["true", "1", "t", "yes", "y"]:
        return True


# merge env variables and application.properties
# if env varible is set override application.properties
config = {
    "cordra_endpoint": os.getenv(
        "CORDRA_ENDPOINT", default=app_properties.get("cordra_endpoint").data
    ),
    "sparql_endpoint": os.getenv(
        "SPARQL_ENDPOINT", default=app_properties.get("sparql_endpoint").data
    ),
    "solr_auth": os.getenv(
        "SOLR_AUTH", default=app_properties.get("solr_auth").data
    ),
    "solr_core": os.getenv(
        "SOLR_CORE", default=app_properties.get("solr_core").data
    ),
    "solr_url": os.getenv(
        "SOLR_URL", default=app_properties.get("solr_url").data
    ),
    "mailserver_url": os.getenv(
        "MAILSERVER_URL", default=app_properties.get("mailserver_url").data
    ),
    "reset_index": parse_bool_config(
        os.getenv(
            "RESET_INDEX",
            default=app_properties.get("reset_index").data,
        )
    ),
}
