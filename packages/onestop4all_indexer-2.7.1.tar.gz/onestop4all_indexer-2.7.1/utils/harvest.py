import logging
import requests
import timeit
import traceback

from socket import gethostname
from typing import Optional

from data_repositories import (
    RepositoryTheme,
    RepositoryPerson,
    RepositoryResourceLinks,
    RepositoryN4EOrganization,
)
from harvesters import (
    Repository_Harvester,
    Organization_Harvester,
    Article_Harvester,
    Softwaresourcecode_Harvester,
    Learningresource_Harvester,
    Metadatastandard_Harvester,
    Document_Harvester,
    Dataset_Harvester,
    DataService_Harvester,
    Service_Harvester,
)
from utils import config, Solr

log = logging.getLogger(__name__)


def run(
    requested_harvester: Optional[tuple] = None,
    reset_index: Optional[bool] = None,
    dataset_options: Optional[dict] = {},
    dataservice_options: Optional[dict] = {},
):
    # init in memory data repos
    themes_repo = RepositoryTheme()
    persons_repo = RepositoryPerson()
    links_repo = RepositoryResourceLinks()
    n4e_orgas_repo = RepositoryN4EOrganization()

    solr = Solr()

    if reset_index:
        solr.reset_index()

    stats = {}

    _harvesters = {
        "Service": Service_Harvester(n4e_organizations_repo=n4e_orgas_repo),
        "DataService": DataService_Harvester(
            themes_repo, persons_repo, **dataservice_options
        ),
        "Repository": Repository_Harvester(
            themes_repo, n4e_organizations_repo=n4e_orgas_repo
        ),
        "Organization": Organization_Harvester(persons_repo),
        "Article": Article_Harvester(persons_repo, links_repo, themes_repo),
        "Softwaresourcecode": Softwaresourcecode_Harvester(
            persons_repo, links_repo
        ),
        "Learningresource": Learningresource_Harvester(
            persons_repo, themes_repo
        ),
        "Metadatastandard": Metadatastandard_Harvester(themes_repo),
        "Document": Document_Harvester(persons_repo, links_repo),
        "Dataset": Dataset_Harvester(
            persons_repo, links_repo, **dataset_options
        ),
    }
    i = 1
    document_count = 0
    try:
        for harvester_name in _harvesters:
            if (
                requested_harvester
                and harvester_name not in requested_harvester
            ):
                continue
            log.info(
                f"start harvester {harvester_name} ({i} of {len(_harvesters)}"
            )
            harvester = _harvesters[harvester_name]
            start_time = timeit.default_timer()
            documents = harvester.harvest()
            elapsed_time = timeit.default_timer() - start_time

            log.info(f"index harvested {len(documents)} documents")
            solr.index_documents(documents)
            document_count += len(documents)
            log.info(
                f"finished indexing for harvester {i} of {len(_harvesters)})"
            )
            stats[harvester.get_type()] = {
                "document_count": len(documents),
                "processing_time": round(elapsed_time, 4),
            }
            if harvester.get_notes():
                stats[harvester.get_type()]["notes"] = harvester.get_notes()
            i += 1
    except Exception as e:
        data = {
            "exception": str(e),
            "traceback": traceback.format_exc(),
            "hostname": gethostname(),
        }
        if config["mailserver_url"]:
            requests.post(config["mailserver_url"], json=data, verify=False)
    else:
        log.info(
            "harvesting completed, indexed {} documents".format(document_count)
        )
        requests.post(
            config["mailserver_url"],
            json={"stats": stats, "hostname": gethostname()},
            verify=False,
        )


if __name__ == "__main__":
    run()
