import logging

log = logging.getLogger(__name__)


def flatten_dict(d, parent_key="", sep="."):
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def addValue(dict, attribute, value, unique=False):
    if attribute not in dict:
        dict[attribute] = []
    if not unique or value not in dict[attribute]:
        dict[attribute].append(value)


def id_from_uri(subject_uri):
    # example: https://nfdi4earth-knowledgehub.geo.tu-dresden.de/api/objects/n4ekh/04a0811dd28bce7b87f7 -> 04a0811dd28bce7b87f7
    return subject_uri.split("/")[-1]


def cli_startup(log_level=logging.INFO, logfile=None):
    log_config = dict(
        level=log_level,
        format="%(asctime)s %(name)-10s %(levelname)-4s %(message)s",
    )
    if logfile:
        log_config["filename"] = logfile

    logging.basicConfig(**log_config)
    logging.getLogger("pysolr").setLevel(logging.WARNING)
    logging.getLogger("urllib3.connectionpool").setLevel(logging.INFO)

def is_truthy(value): 
    if (value == 1 or value == "1" or value == "true" or value == True):
        return True
    else:
        return False