#! /usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2024/11/1 8:55
# @Author  : dmj-11740
# @File    : test.py
# @Software: PyCharm
# @desc    :
import pyodbc
from loguru import logger

from DangQu import DangQuSDK




a = DangQuSDK("lab",'192.168.123.220','spider2020').send_dangqu_request("69d74f1682685484c2e7ff73", {})
print(a.json())
