import os

from setuptools import setup, find_packages

long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name='DangQu',
    version='0.1.13',
    description='dangqu sdk',
    long_description=long_description,
    author='DMJ-11740',
    author_email='rpa@lumi.com',
    packages=find_packages(),
    python_requires='>=3.7',
    install_requires=[
        "requests>=2.32.0",
        'oauthlib>=3.2.0',
        'requests-oauthlib>=2.0.0',
        "pillow>=11.0.0",
        'pyodbc>=5.0.0',
        'numpy>=1.24.0',
        'scipy>=1.10.0',
        'opencv-python>=4.8.0',
    ],
    extras_require={
        "ocr": ['ddddocr>=1.4.0'],
        "excel": ['pandas'],
        "dev": [
            'twine>=5.0.0',
            'setuptools>=75.0.0',
            'wheel>=0.44.0',
        ]
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
)
