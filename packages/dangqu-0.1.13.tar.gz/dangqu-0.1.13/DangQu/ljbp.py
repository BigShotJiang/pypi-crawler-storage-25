import copy
import json
import datetime
import functools
import time
from copy import deepcopy
from typing import Union, Dict, List

import requests
from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session


class TimedCache:
    def __init__(self, duration):
        self.cache = {}
        self.duration = datetime.timedelta(seconds=duration)

    def __call__(self, func):
        @functools.wraps(func)
        def wrapped(*args):
            now = datetime.datetime.now()
            if args in self.cache and now - self.cache[args][1] < self.duration:
                return self.cache[args][0]
            else:
                result = func(*args)
                self.cache[args] = (result, now)
                return result

        return wrapped


class DangQuBase:

    def __init__(self, domain, token_url, client_id, client_secret):
        self.domain = domain
        self.logical_url = f'{domain}/openapis/api/Workflow/Workflow/WorkflowInstance'

        self.client_id = client_id
        self.client_secret = client_secret
        self.token_url = token_url

        self.client = BackendApplicationClient(client_id=client_id)
        self.oauth = OAuth2Session(client=self.client)

    @property
    @TimedCache(60 * 60 * 2)
    def token(self):
        token = self.oauth.fetch_token(
            token_url=self.token_url,
            client_id=self.client_id,
            client_secret=self.client_secret
        )
        return token

    def execute_dangqu_request(self, host_tenant: str, unified_id: str, request_body: dict):
        body = {
            "isSync": True,
            "isReturnResult": True,
            "hostTenant": host_tenant,
            "unifiedId": unified_id,
            "inputParameterJson": json.dumps(request_body)
        }

        _headers = {'Authorization': 'Bearer %s' % self.token.get('access_token', ''), "alarmType": "LOGIC"}
        response = requests.post(self.logical_url, headers=_headers, json=body)

        return response


class DangQuSDK:
    def __init__(self, env, sql_ip, sql_pwd, sql_user='spider', sql_db='spider', sql_table='upload_ljbp'):
        self.sql_ip = sql_ip
        self.sql_pwd = sql_pwd
        self.sql_user = sql_user
        self.sql_db = sql_db
        self.sql_table = sql_table
        self.env = env
        _, domain, token_domain, self.host_tenant, client_id, client_secret = (
            self.get_ljbp_args()
        )
        token_url = f"{token_domain}/useridentity/connect/token"
        self.dangqu_api = DangQuBase(domain, token_url, client_id, client_secret)

    def get_ljbp_args(self):
        """
        向数据库请求调取逻辑编排的必要参数，分为test环境及prod环境
        :return:
        """
        try:
            import pyodbc
        except ImportError:
            raise Exception("请安装pyodbc")
        conn = pyodbc.connect(
            "DRIVER={SQL Server};"
            f"SERVER={self.sql_ip};"
            f"DATABASE={self.sql_db};"
            f"UID={self.sql_user};"
            f"PWD={self.sql_pwd}"
        )
        cursor = conn.cursor()
        try:
            sql = f"select * from [{self.sql_table}] where [env] = ?"
            cursor.execute(sql, (self.env,))
            res = cursor.fetchone()
            return res
        except Exception as e:
            raise Exception(f"获取args失败： {e}")
        finally:
            cursor.close()
            conn.close()

    def send_dangqu_request(self, unified_id: str, body: Dict, slice_size: int = 500, slice_key: str = "list",
                            discard_raise: bool = True):
        """
            调用逻辑编排
        :param unified_id: 逻辑编排ID
        :param body: 请求体
        :param slice_size: 数据切片大小
        :param slice_key: 数据切片key
        :param discard_raise: 抛弃请求时是否返回报错
        :return:
        """
        assert unified_id, "逻辑编排ID不能为空"
        results = []
        request_body_list = []
        if slice_key in body and slice_size > 0:
            data_list = body.pop(slice_key, [])
            for i in range(0, len(data_list), slice_size):
                body_ = copy.deepcopy(body)
                body_[slice_key] = data_list[i:i + slice_size]
                request_body_list.append(body_)
        else:
            request_body_list.append(body)
        for data in request_body_list:
            try:
                result = self._send_request(unified_id, data)
                results.append(result)
            except Exception:
                pass
        if discard_raise and len(results) != len(request_body_list):
            raise Exception(f"逻辑编排执行失败，只有 {len(results)}/{len(request_body_list)} 个请求成功！")
        return results if len(results) != 1 else results[0]

    def _send_request(self, unified_id: str, body: Union[Dict, List]):
        response = None
        for i in range(1, 4):
            try:
                response = self.dangqu_api.execute_dangqu_request(
                    self.host_tenant, unified_id, body
                )
                response.raise_for_status()
                if not response.json().get("isSucceed"):
                    raise Exception(response.text)
                print(f"\033[92m{response.json()}\033[0m")
                break
            except Exception as e:
                print(f"\033[91m[{i}]逻辑编排执行失败： {e}\033[0m")
                time.sleep(1)
                continue
        if not response:
            raise Exception("抛弃了一次逻辑编排调用！")
        return response
