from __future__ import annotations

from typing import TYPE_CHECKING

from cognite.client.data_classes.data_modeling import (
    ContainerApply,
    ContainerProperty,
    DirectRelation,
    Int32,
    Int64,
    Json,
    NodeApply,
    NodeOrEdgeData,
    SpaceApply,
    Text,
    Timestamp,
)
from cognite.client.data_classes.data_modeling.ids import ContainerId

if TYPE_CHECKING:
    from cognite.client import CogniteClient

    from cognite_data_quality.deploy import DeploymentSettings


def _ensure_space_exists(client: CogniteClient, space: str) -> None:
    """Ensure a space exists, creating it if necessary.

    Args:
        client: CogniteClient instance
        space: Space identifier
    """
    try:
        existing_space = client.data_modeling.spaces.retrieve(space)
        if existing_space:
            print(f"  ✓ Space '{space}' already exists")
        else:
            print(f"  • Space '{space}' does not exist, creating...")
            client.data_modeling.spaces.apply(SpaceApply(space=space, name=space))
            print(f"  ✓ Space '{space}' created successfully")
    except Exception:
        # Space doesn't exist, try to create it
        try:
            print(f"  • Space '{space}' not found, creating...")
            client.data_modeling.spaces.apply(SpaceApply(space=space, name=space))
            print(f"  ✓ Space '{space}' created successfully")
        except Exception as create_error:
            print(f"  ✗ Failed to create space '{space}': {create_error}")


def _safe_apply_container(client: CogniteClient, container: ContainerApply) -> None:
    """Apply a container only if it doesn't already exist.

    This avoids permission errors when trying to update existing containers.
    Logs the current status before attempting any operations.
    """
    container_id = f"{container.space}/{container.external_id}"

    try:
        existing = client.data_modeling.containers.retrieve((container.space, container.external_id))
        if existing:
            print(f"    ✓ Container {container_id} already exists, skipping creation")
            return
        else:
            print(f"    • Container {container_id} does not exist, creating...")
    except Exception:
        # Container doesn't exist or error checking, proceed with creation
        print(f"    • Container {container_id} not found, creating...")

    try:
        client.data_modeling.containers.apply(container)
        print(f"    ✓ Container {container_id} created successfully")
    except Exception as e:
        print(f"    ✗ Failed to create container {container_id}: {e}")


def _ensure_orchestration_state_container(client: CogniteClient, space: str, container_id: str) -> None:
    """Ensure the OrchestrationState container exists.

    Creates a container for tracking state of historic validation orchestrations,
    including partition management, progress tracking, and status monitoring.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically "dataQuality")
        container_id: Container external ID (typically "OrchestrationState")
    """
    # Define properties
    properties = {
        "orchestration_id": ContainerProperty(type=Text(), description="Unique ID for this orchestration job"),
        "view_external_id": ContainerProperty(type=Text(), description="View being validated"),
        "view_space": ContainerProperty(type=Text(), description="Space of the view"),
        "instance_space": ContainerProperty(type=Text(), description="Instance space being validated"),
        "rule_set_id": ContainerProperty(type=Text(), description="Rule set ID for validation results"),
        "workflow_external_id": ContainerProperty(
            type=Text(), description="Scheduled workflow managing this orchestration"
        ),
        "partition_count": ContainerProperty(type=Int32(), description="Total number of partitions"),
        "partition_field": ContainerProperty(type=Text(), description="Field used for partitioning"),
        "partition_ranges": ContainerProperty(
            type=Json(), description="Object mapping partition IDs to range configurations"
        ),
        "triggered_partitions": ContainerProperty(type=Json(), description="Object mapping partition IDs to boolean"),
        "completed_partitions": ContainerProperty(type=Json(), description="Object mapping partition IDs to boolean"),
        "failed_partitions": ContainerProperty(type=Json(), description="Object mapping partition IDs to boolean"),
        "partition_call_ids": ContainerProperty(
            type=Json(), description="Map of partition_id to latest function call_id"
        ),
        "partition_retry_count": ContainerProperty(
            type=Json(), description="Map of partition_id to current retry count"
        ),
        "total_instances": ContainerProperty(type=Int64(), description="Total instances discovered"),
        "validated_instances": ContainerProperty(type=Int64(), description="Total instances validated so far"),
        "total_violations": ContainerProperty(type=Int64(), description="Total violations found so far"),
        "status": ContainerProperty(
            type=Text(), description="Current status (initial | monitoring | completed | failed)"
        ),
        "created_time": ContainerProperty(type=Timestamp(), description="When orchestration was created"),
        "last_updated": ContainerProperty(type=Timestamp(), description="Last time state was updated"),
        "max_retries": ContainerProperty(type=Int32(), description="Maximum retries per partition"),
        "sync_trigger_external_id": ContainerProperty(
            type=Text(), description="Sync trigger created for ongoing validation"
        ),
        "historic_cutoff_date": ContainerProperty(
            type=Text(), description="Maximum date from historic partitions (ISO format)"
        ),
        "timestamp_collection_count": ContainerProperty(
            type=Int64(), description="Number of timestamps collected so far"
        ),
        "timestamp_collection_phase": ContainerProperty(
            type=Text(), description="Collection phase: 'collecting' | 'complete' | null"
        ),
        "timestamp_collection_started": ContainerProperty(
            type=Timestamp(), description="When timestamp collection started (for total time tracking)"
        ),
        "timestamps_file": ContainerProperty(
            type=DirectRelation(),
            description=(
                "CogniteFile node (dataQuality space) holding accumulated timestamps + cursor for resumable collection"
            ),
        ),
    }

    container = ContainerApply(
        space=space,
        external_id=container_id,
        name="Orchestration State",
        properties=properties,
        description="Tracks state for self-managing historic validation orchestrations",
        used_for="node",
    )

    _safe_apply_container(client, container)


def _ensure_function_validation_state_container(client: CogniteClient, space: str, container_id: str) -> None:
    """Ensure the FunctionValidationState container exists.

    Creates a container for storing cursor state for partitioned validation functions,
    enabling resumption after timeouts or failures.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically "dataQuality")
        container_id: Container external ID (typically "FunctionValidationState")
    """
    # Define properties
    properties = {
        "orchestration_id": ContainerProperty(type=Text(), description="Orchestration run this partition belongs to"),
        "partitionId": ContainerProperty(type=Text(), description="Unique partition ID"),
        "syncCursor": ContainerProperty(
            type=Text(), description="DMS sync cursor for resuming from last processed position"
        ),
        "processedCount": ContainerProperty(
            type=Int64(), description="Total number of instances processed so far in this partition"
        ),
        "lastUpdated": ContainerProperty(
            type=Int64(), description="Timestamp (milliseconds since epoch) of last cursor save"
        ),
    }

    container = ContainerApply(
        space=space,
        external_id=container_id,
        name="Function Validation State",
        properties=properties,
        description=(
            "Stores cursor state for partitioned validation functions to enable resumption after timeouts or failures"
        ),
        used_for="node",
    )

    _safe_apply_container(client, container)


def _ensure_raw_validation_state_container(client: CogniteClient, space: str, container_id: str) -> None:
    """Ensure the RawValidationState container exists.

    Creates a container for tracking incremental validation state of RAW tables,
    including last processed timestamp, row counts, and validation status.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically "dataQuality")
        container_id: Container external ID (typically "RawValidationState")
    """
    # Define properties
    properties = {
        "db_name": ContainerProperty(type=Text(), description="RAW database name"),
        "table_name": ContainerProperty(type=Text(), description="RAW table name"),
        "last_processed_timestamp": ContainerProperty(
            type=Int64(), description="Last updated time of most recently validated row (milliseconds)"
        ),
        "last_run_time": ContainerProperty(type=Timestamp(), description="Last validation run timestamp"),
        "rows_processed": ContainerProperty(type=Int64(), description="Number of rows processed in last run"),
        "last_validation_conforms": ContainerProperty(
            type=Text(), description="Whether last validation passed (true/false)"
        ),
        "last_violation_count": ContainerProperty(type=Int64(), description="Number of violations in last run"),
    }

    container = ContainerApply(
        space=space,
        external_id=container_id,
        name="Raw Validation State",
        properties=properties,
        description="Tracks incremental validation state for RAW tables",
        used_for="node",
    )

    _safe_apply_container(client, container)


def _ensure_data_quality_settings_container(client: CogniteClient, space: str, container_id: str) -> None:
    """Ensure the DataQualitySettings container exists.

    Stores the runtime-relevant subset of ``DeploymentSettings`` in DMS so
    that the ``data_product_sync`` handler can read settings without needing
    a CDF File upload.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically ``"dataQuality"``)
        container_id: Container external ID (typically ``"DataQualitySettings"``)
    """
    properties = {
        "function_external_id": ContainerProperty(type=Text(), description="CDF Function external ID"),
        "workflow_external_id_prefix": ContainerProperty(
            type=Text(), description="Prefix for per-view workflow external IDs"
        ),
        "workflow_version": ContainerProperty(type=Text(), description="Workflow version string"),
        "workflow_task_retries": ContainerProperty(type=Int32(), description="Task-level retries (0-10)"),
        "workflow_task_timeout": ContainerProperty(type=Int32(), description="Task timeout in seconds"),
        "workflow_task_on_failure": ContainerProperty(
            type=Text(), description="Task failure behaviour (abortWorkflow/skipTask)"
        ),
        "trigger_external_id_prefix": ContainerProperty(
            type=Text(), description="Prefix for per-view trigger external IDs"
        ),
        "trigger_batch_size": ContainerProperty(type=Int32(), description="Trigger batch size"),
        "trigger_batch_timeout": ContainerProperty(type=Int32(), description="Trigger batch timeout in seconds"),
        "records_space": ContainerProperty(type=Text(), description="DMS space for validation records"),
        "records_container": ContainerProperty(type=Text(), description="Container for validation records"),
        "records_stream_id": ContainerProperty(type=Text(), description="Records API stream ID"),
        "partition_retries": ContainerProperty(type=Int32(), description="Orchestrator partition retry limit"),
        "shacl_rules_dataset_external_id": ContainerProperty(
            type=Text(), description="Dataset external ID for SHACL rules files"
        ),
    }

    container = ContainerApply(
        space=space,
        external_id=container_id,
        name="Data Quality Settings",
        properties=properties,
        description="Runtime deployment settings for data product sync and validation handlers",
        used_for="node",
    )

    _safe_apply_container(client, container)


def _ensure_data_product_sync_state_container(client: CogniteClient, space: str, container_id: str) -> None:
    """Ensure the DataProductSyncState container exists.

    Tracks the last processed DataProduct version for each DataProduct so the
    sync handler knows when a new version requires workflow redeployment and
    historic re-validation.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically ``"dataQuality"``)
        container_id: Container external ID (typically ``"DataProductSyncState"``)
    """
    properties = {
        "data_product_external_id": ContainerProperty(type=Text(), description="DataProduct external ID"),
        "last_processed_version": ContainerProperty(
            type=Text(), description="Last semver that triggered workflow deployment"
        ),
        "last_sync_time": ContainerProperty(type=Timestamp(), description="Last successful sync timestamp"),
        "last_historic_triggered_at": ContainerProperty(
            type=Timestamp(), description="Last time historic validation was triggered"
        ),
    }

    container = ContainerApply(
        space=space,
        external_id=container_id,
        name="Data Product Sync State",
        properties=properties,
        description="Tracks per-DataProduct version state for the data product sync handler",
        used_for="node",
    )

    _safe_apply_container(client, container)


def _upsert_settings_to_dms(
    client: CogniteClient,
    space: str,
    container_id: str,
    settings: DeploymentSettings,
    node_external_id: str = "default",
) -> None:
    """Write deployment settings to the ``DataQualitySettings`` DMS container.

    Args:
        client: CogniteClient instance
        space: Space for the container (typically ``"dataQuality"``)
        container_id: Container external ID (typically ``"DataQualitySettings"``)
        settings: A ``DeploymentSettings`` instance.
        node_external_id: External ID of the node to upsert (default ``"default"``).
    """
    props = {
        "function_external_id": settings.function.external_id if settings.function else None,
        "workflow_external_id_prefix": settings.workflow.external_id_prefix,
        "workflow_version": settings.workflow.version,
        "workflow_task_retries": settings.workflow.task.retries,
        "workflow_task_timeout": settings.workflow.task.timeout,
        "workflow_task_on_failure": settings.workflow.task.on_failure,
        "trigger_external_id_prefix": settings.trigger.external_id_prefix,
        "trigger_batch_size": settings.trigger.batch_size,
        "trigger_batch_timeout": settings.trigger.batch_timeout,
        "records_space": settings.records.space,
        "records_container": settings.records.container,
        "records_stream_id": settings.records.stream_id,
        "partition_retries": settings.partition_retries,
        "shacl_rules_dataset_external_id": settings.shacl_rules.dataset_external_id if settings.shacl_rules else None,
    }

    node = NodeApply(
        space=space,
        external_id=node_external_id,
        sources=[NodeOrEdgeData(source=ContainerId(space, container_id), properties=props)],
    )

    client.data_modeling.instances.apply(nodes=[node])
    print(f"  ✓ Upserted settings node {space}/{node_external_id}")


def _load_settings_from_dms(
    client: CogniteClient,
    space: str,
    container_id: str = "DataQualitySettings",
    node_external_id: str = "default",
) -> dict:
    """Read deployment settings from the ``DataQualitySettings`` DMS container.

    Returns a flat dict of property values, or an empty dict if the node
    does not exist.
    """
    try:
        # DataQualitySettings container is exposed via DataQualitySettingsView (v1),
        # created by deploy_data_models. Use the ViewId so Properties.load() can
        # parse the response correctly (it requires the external_id/version format).
        from cognite.client.data_classes.data_modeling.ids import ViewId
        from cognite.client.exceptions import CogniteAPIError

        view_id = ViewId(space=space, external_id=f"{container_id}View", version="1")
        result = client.data_modeling.instances.retrieve(
            nodes=[(space, node_external_id)],
            sources=[view_id],
        )
        if result.nodes:
            props = result.nodes[0].properties.get(view_id)
            return dict(props) if props else {}
    except CogniteAPIError as e:
        print(f"  Warning: could not load settings from DMS: {e}")
    return {}


def build_deployment_settings_from_props(dms_props: dict) -> DeploymentSettings:
    """Reconstruct a DeploymentSettings from a flat DMS props dict.

    Used by both the data_product_sync handler (inside _function_code) and
    deploy_validation_pipeline (invoke.py) so the mapping lives in one place.
    """
    from cognite_data_quality.deploy import (
        DeploymentSettings,
        FunctionSettings,
        RecordsSettings,
        ShaclRulesSettings,
        TriggerSettings,
        WorkflowSettings,
        WorkflowTaskSettings,
    )

    task_kwargs: dict = {}
    if "workflow_task_retries" in dms_props:
        task_kwargs["retries"] = dms_props["workflow_task_retries"]
    if "workflow_task_timeout" in dms_props:
        task_kwargs["timeout"] = dms_props["workflow_task_timeout"]
    if "workflow_task_on_failure" in dms_props:
        task_kwargs["on_failure"] = dms_props["workflow_task_on_failure"]

    workflow_kwargs: dict = {"task": WorkflowTaskSettings(**task_kwargs)}
    if "workflow_external_id_prefix" in dms_props:
        workflow_kwargs["external_id_prefix"] = dms_props["workflow_external_id_prefix"]
    if "workflow_version" in dms_props:
        workflow_kwargs["version"] = dms_props["workflow_version"]

    trigger_kwargs: dict = {}
    if "trigger_external_id_prefix" in dms_props:
        trigger_kwargs["external_id_prefix"] = dms_props["trigger_external_id_prefix"]
    if "trigger_batch_size" in dms_props:
        trigger_kwargs["batch_size"] = dms_props["trigger_batch_size"]
    if "trigger_batch_timeout" in dms_props:
        trigger_kwargs["batch_timeout"] = dms_props["trigger_batch_timeout"]

    records_kwargs: dict = {}
    if "records_space" in dms_props:
        records_kwargs["space"] = dms_props["records_space"]
    if "records_container" in dms_props:
        records_kwargs["container"] = dms_props["records_container"]
    if "records_stream_id" in dms_props:
        records_kwargs["stream_id"] = dms_props["records_stream_id"]

    function_kwargs: dict = {}
    if "function_external_id" in dms_props:
        function_kwargs["external_id"] = dms_props["function_external_id"]

    return DeploymentSettings(
        function=FunctionSettings(**function_kwargs),
        workflow=WorkflowSettings(**workflow_kwargs),
        trigger=TriggerSettings(**trigger_kwargs),
        records=RecordsSettings(**records_kwargs),
        shacl_rules=ShaclRulesSettings(
            source_dir="shacl_rules",
            dataset_external_id=dms_props.get("shacl_rules_dataset_external_id"),
        ),
        **({"partition_retries": dms_props["partition_retries"]} if "partition_retries" in dms_props else {}),
    )
