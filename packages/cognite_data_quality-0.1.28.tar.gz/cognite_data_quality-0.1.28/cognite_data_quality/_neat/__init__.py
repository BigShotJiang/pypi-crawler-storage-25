from cognite.client import CogniteClient

from ._client import NeatClient
from ._constants import get_raw_namespace
from ._validate_instances import ValidateInstancesAPI


class NeatSession:
    """Entry point for SHACL-based data quality validation.

    Wraps a :class:`~cognite.client.CogniteClient` to expose the
    :attr:`validate_instances` API for validating DMS instances and RAW
    table rows against SHACL rules.

    Attributes:
        validate_instances: API for running SHACL validation.
            See :class:`~cognite_data_quality._neat._validate_instances.ValidateInstancesAPI`.

    Args:
        client: Authenticated Cognite client.
        verbose: Enable verbose output during validation. Default: ``True``.

    Example:
        from cognite.client import CogniteClient
        from cognite_data_quality._neat import NeatSession

        client = CogniteClient()
        neat = NeatSession(client)
        conforms, report_graph, report_text = neat.validate_instances.with_shacl(
            instance_space="my_space",
            shacl_rules=shacl_ttl_string,
            datamodel_space="my_space",
            datamodel_external_id="MyModel",
            datamodel_version="v1",
        )
    """

    def __init__(self, client: CogniteClient, verbose: bool = True) -> None:
        neat_client = NeatClient(client)
        self.validate_instances = ValidateInstancesAPI(neat_client)


__all__ = [
    "NeatSession",
    "get_raw_namespace",
]
