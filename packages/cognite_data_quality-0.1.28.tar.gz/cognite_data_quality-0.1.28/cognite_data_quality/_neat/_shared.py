from typing import TypeAlias

from rdflib import Literal, URIRef

Triple: TypeAlias = tuple[URIRef, URIRef, Literal | URIRef]
