from collections.abc import Iterable
from datetime import datetime
from typing import TypeVar

T_Element = TypeVar("T_Element")


def string_to_ideal_type(input_string: str) -> int | bool | float | datetime | str:
    try:
        return int(input_string)
    except ValueError:
        try:
            return float(input_string)  # type: ignore
        except ValueError:
            if input_string.lower() == "true":
                return True
            elif input_string.lower() == "false":
                return False
            else:
                try:
                    return datetime.fromisoformat(input_string)  # type: ignore
                except ValueError:
                    return input_string


def iterate_progress_bar(iterable: Iterable[T_Element], total: int, description: str) -> Iterable[T_Element]:
    """Show a progress bar for an iterable, using tqdm if available."""
    try:
        from tqdm import tqdm
    except ModuleNotFoundError:
        return iterable
    return tqdm(iterable, total=total, desc=description)
