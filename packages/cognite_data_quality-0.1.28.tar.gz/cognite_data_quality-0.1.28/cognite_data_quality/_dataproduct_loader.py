"""Build ``ViewConfig`` objects from CDF DataProduct API responses.

This module is used by the ``data_product_sync`` handler to convert a
DataProduct version (views + quality rules) into the ``ViewConfig``
objects that ``deploy_instance_workflows`` expects.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from cognite_data_quality._dataproduct_client import DataProductClient
from cognite_data_quality.deploy import (
    RecordsOverrides,
    ShaclRulesRef,
    ValidationSettings,
    ViewConfig,
    ViewRef,
)

if TYPE_CHECKING:
    from cognite.client import CogniteClient


def load_views_from_data_product(
    client: CogniteClient,
    external_id: str,
    version: str,
    *,
    version_data: dict[str, Any] | None = None,
) -> list[ViewConfig]:
    """Build ``ViewConfig`` list from a DataProduct version.

    Args:
        client: CogniteClient instance.
        external_id: DataProduct external ID.
        version: Semantic version string of the DataProduct version.
        version_data: Pre-fetched DataProduct version dict.  When provided
            the API call is skipped, avoiding a redundant fetch.

    Returns:
        One ``ViewConfig`` per view in the DataProduct version.  Returns
        an empty list when the version has no ``quality.rules``.
    """
    dp_version: dict[str, Any] = version_data or DataProductClient.get_version(client, external_id, version)

    # Extract quality rule references
    quality = dp_version.get("quality") or {}
    rules: list[dict] = quality.get("rules", [])
    if not rules:
        return []

    # Shared SHACL rules ref (all views use the same ruleset references)
    shacl_ref = ShaclRulesRef(ruleset_references=rules)

    # Shared records overrides
    records = RecordsOverrides(
        rule_set_id=external_id,
        rule_set_version=version,
        data_domain_external_id=external_id,
    )

    # Views are top-level in the DataProduct version (the dataModel wrapper was removed).
    # Each view entry carries its own space, externalId, version, and instanceSpaces.
    view_entries: list[dict] = dp_version.get("views") or []

    configs: list[ViewConfig] = []
    for view_entry in view_entries:
        view_space = view_entry.get("space") or ""
        view_ref = ViewRef(
            space=view_space,
            external_id=view_entry["externalId"],
            version=view_entry.get("version") or "",
        )

        # Instance spaces from the view's read permissions
        instance_spaces_data = view_entry.get("instanceSpaces") or {}
        instance_spaces = instance_spaces_data.get("read") or []
        if not instance_spaces:
            # Fall back to the view's own space if no explicit instance spaces
            instance_spaces = [view_space] if view_space else []

        config = ViewConfig(
            view=view_ref,
            instance_spaces=instance_spaces,
            shacl_rules=shacl_ref,
            validation=ValidationSettings(),
            records=records,
        )
        configs.append(config)

    return configs
