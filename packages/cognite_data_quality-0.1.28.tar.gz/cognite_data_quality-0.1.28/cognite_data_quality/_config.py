from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from cognite_data_quality._records import RecordsConfig, Violation


class DataModelConfig(BaseModel):
    """Identifies a CDF Data Model used during instance validation.

    Attributes:
        space: CDF space that contains the data model.
        external_id: External ID of the data model.
        version: Version string of the data model.
    """

    space: str
    external_id: str
    version: str


class CredentialsConfig(BaseModel):
    """CDF credentials loaded from a TOML config file.

    Attributes:
        project: CDF project name.
        tenant_id: Azure AD tenant ID.
        cdf_cluster: CDF cluster (e.g. ``"api"`` or ``"westeurope-1"``).
        client_id: Service principal client ID.
        client_secret: Service principal client secret.
        login_flow: Authentication flow. Default: ``"client_credentials"``.
    """

    project: str
    tenant_id: str
    cdf_cluster: str
    client_id: str
    client_secret: str
    login_flow: str = Field(default="client_credentials")


class RuleConfig(BaseModel):
    """Resolved validation rule configuration passed to a validation handler.

    Attributes:
        datamodel: Target data model for instance loading.
        instance_space: CDF space from which instances are read.
        auto_load_depth: Levels of referenced instances to auto-load (0-3).
            Default: 2.
        verbose: Enable verbose logging in the handler. Default: ``True``.
        records: Records API configuration for result ingestion.
    """

    datamodel: DataModelConfig | None = None
    instance_space: str | None = None
    auto_load_depth: int = Field(default=2)
    verbose: bool = Field(default=True)
    records: RecordsConfig | None = None


class ValidationInput(BaseModel):
    """Input payload consumed by validation handler functions.

    Attributes:
        instance_space: CDF space from which instances are fetched and
            validated.
        shacl_rules: Inline SHACL rules string (Turtle format). Mutually
            exclusive with *shacl_rules_file_external_id* and
            *ruleset_references*.
        shacl_rules_file_external_id: CDF Files external ID of the SHACL
            rules file to load at runtime. Mutually exclusive with
            *shacl_rules* and *ruleset_references*.
        ruleset_references: List of ``{"externalId": ..., "version": ...}``
            dicts pointing to CDF RuleSet API versions.  When set, SHACL
            rules are fetched from the RuleSet API at runtime.  Mutually
            exclusive with *shacl_rules* and *shacl_rules_file_external_id*.
        datamodel_space: Space of the data model used for instance loading.
        datamodel_external_id: External ID of the data model.
        datamodel_version: Version of the data model.
        verbose: Enable verbose logging. Default: ``True``.
        job_run_id: Unique identifier for this validation run, written to
            every record.  Auto-generated if ``None``.
        records_config: Records API configuration. Pass ``None`` to skip
            Records API ingestion.
    """

    instance_space: str
    shacl_rules: str | None = None
    shacl_rules_file_external_id: str | None = None
    ruleset_references: list[dict] | None = None
    datamodel_space: str | None = None
    datamodel_external_id: str | None = None
    datamodel_version: str | None = None
    verbose: bool = Field(default=True)
    job_run_id: str | None = None
    records_config: RecordsConfig | None = None


class ValidationResult(BaseModel):
    """Aggregated result returned by a validation handler.

    Attributes:
        conforms: ``True`` when no Violation-severity constraints failed.
        violations: List of individual constraint violations.
        report_text: Human-readable SHACL validation report text.
        instance_count: Number of instances that were validated.
        records: List of Records API payloads built from the violations.
        schema_issues: List of schema inconsistency dicts detected in the
            data model (e.g. missing properties, type mismatches).
    """

    conforms: bool
    violations: list[Violation] = Field(default_factory=list)
    report_text: str | None = None
    instance_count: int = 0
    records: list[dict] = Field(default_factory=list)
    schema_issues: list[dict] = Field(default_factory=list)  # Schema inconsistencies from data model


# Resolve forward references at runtime
from cognite_data_quality._records import RecordsConfig, Violation  # noqa: E402

RuleConfig.model_rebuild()
ValidationInput.model_rebuild()
ValidationResult.model_rebuild()
