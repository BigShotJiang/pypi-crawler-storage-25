"""Thin HTTP wrappers for the CDF DataProducts and RuleSets APIs.

Both APIs require the ``cdf-version: alpha`` header.  It is passed directly
to each ``client.get`` / ``client.post`` call via the ``headers`` keyword
argument, which the SDK merges with any default headers on the client.
This avoids mutating shared ``client.config.headers`` state.
"""

from __future__ import annotations

from typing import Any

# Header dict passed to every DataProducts / RuleSets API call.
_ALPHA: dict[str, str] = {"cdf-version": "alpha"}


def _base_url(client: Any) -> str:
    return f"/api/v1/projects/{client.config.project}"


# ---------------------------------------------------------------------------
# RuleSetClient
# ---------------------------------------------------------------------------


class RuleSetClient:
    """HTTP wrapper for ``/rulesets`` endpoints."""

    @staticmethod
    def list_all(client: Any, *, limit: int = 100) -> list[dict]:
        """List all rule sets (paginated)."""
        items: list[dict] = []
        cursor: str | None = None
        while True:
            params: dict[str, Any] = {"limit": limit}
            if cursor:
                params["cursor"] = cursor
            data = client.get(f"{_base_url(client)}/rulesets", params=params, headers=_ALPHA).json()
            items.extend(data.get("items", []))
            cursor = data.get("nextCursor")
            if not cursor:
                break
        return items

    @staticmethod
    def get(client: Any, external_id: str) -> dict:
        """Get a single rule set by external ID."""
        return client.get(f"{_base_url(client)}/rulesets/{external_id}", headers=_ALPHA).json()

    @staticmethod
    def create(client: Any, external_id: str, name: str) -> dict:
        """Create a new rule set."""
        resp = client.post(
            f"{_base_url(client)}/rulesets",
            json={"items": [{"externalId": external_id, "name": name}]},
            headers=_ALPHA,
        )
        return resp.json()["items"][0]

    @staticmethod
    def delete(client: Any, external_id: str) -> None:
        """Delete a rule set (must have no versions)."""
        client.post(
            f"{_base_url(client)}/rulesets/delete",
            json={"items": [{"externalId": external_id}]},
            headers=_ALPHA,
        )

    @staticmethod
    def list_versions(client: Any, external_id: str, *, limit: int = 10) -> list[dict]:
        """List all versions of a rule set (paginated)."""
        items: list[dict] = []
        cursor: str | None = None
        while True:
            params: dict[str, Any] = {"limit": limit}
            if cursor:
                params["cursor"] = cursor
            data = client.get(
                f"{_base_url(client)}/rulesets/{external_id}/versions", params=params, headers=_ALPHA
            ).json()
            items.extend(data.get("items", []))
            cursor = data.get("nextCursor")
            if not cursor:
                break
        return items

    @staticmethod
    def get_version(client: Any, external_id: str, version: str) -> dict:
        """Get a specific rule set version (includes ``rules`` list)."""
        return client.get(f"{_base_url(client)}/rulesets/{external_id}/versions/{version}", headers=_ALPHA).json()

    @staticmethod
    def create_version(client: Any, external_id: str, version: str, rules: list[str]) -> dict:
        """Create an immutable rule set version with SHACL rules."""
        resp = client.post(
            f"{_base_url(client)}/rulesets/{external_id}/versions",
            json={"items": [{"version": version, "rules": rules}]},
            headers=_ALPHA,
        )
        return resp.json()["items"][0]

    @staticmethod
    def delete_version(client: Any, external_id: str, version: str) -> None:
        """Delete a rule set version."""
        client.post(
            f"{_base_url(client)}/rulesets/{external_id}/versions/delete",
            json={"items": [{"version": version}]},
            headers=_ALPHA,
        )


# ---------------------------------------------------------------------------
# DataProductClient
# ---------------------------------------------------------------------------


class DataProductClient:
    """HTTP wrapper for ``/dataproducts`` endpoints."""

    @staticmethod
    def list_all(client: Any, *, limit: int = 100) -> list[dict]:
        """Page through all data products in the project."""
        items: list[dict] = []
        cursor: str | None = None
        while True:
            params: dict[str, Any] = {"limit": limit}
            if cursor:
                params["cursor"] = cursor
            data = client.get(f"{_base_url(client)}/dataproducts", params=params, headers=_ALPHA).json()
            items.extend(data.get("items", []))
            cursor = data.get("nextCursor")
            if not cursor:
                break
        return items

    @staticmethod
    def get(client: Any, external_id: str) -> dict:
        """Get a single data product."""
        return client.get(f"{_base_url(client)}/dataproducts/{external_id}", headers=_ALPHA).json()

    @staticmethod
    def create(
        client: Any,
        external_id: str,
        name: str,
        *,
        schema_space: str | None = None,
        description: str | None = None,
        is_governed: bool = False,
        tags: list[str] | None = None,
    ) -> dict:
        """Create a new data product.

        Args:
            schema_space: DMS space containing the data model referenced by this
                DataProduct.  The API defaults to the DataProduct's own
                ``externalId`` when omitted, which is usually wrong — pass the
                actual data-model space to avoid a 400 "data model does not exist
                in schema space" error.
        """
        item: dict[str, Any] = {"externalId": external_id, "name": name, "isGoverned": is_governed}
        if schema_space is not None:
            item["schemaSpace"] = schema_space
        if description is not None:
            item["description"] = description
        if tags is not None:
            item["tags"] = tags
        resp = client.post(f"{_base_url(client)}/dataproducts", json={"items": [item]}, headers=_ALPHA)
        return resp.json()["items"][0]

    @staticmethod
    def delete(client: Any, external_id: str) -> None:
        """Delete a data product (must have no versions)."""
        client.post(
            f"{_base_url(client)}/dataproducts/delete",
            json={"items": [{"externalId": external_id}]},
            headers=_ALPHA,
        )

    @staticmethod
    def list_versions(client: Any, external_id: str, *, limit: int = 10) -> list[dict]:
        """List all versions of a data product (paginated)."""
        items: list[dict] = []
        cursor: str | None = None
        while True:
            params: dict[str, Any] = {"limit": limit}
            if cursor:
                params["cursor"] = cursor
            data = client.get(
                f"{_base_url(client)}/dataproducts/{external_id}/versions", params=params, headers=_ALPHA
            ).json()
            items.extend(data.get("items", []))
            cursor = data.get("nextCursor")
            if not cursor:
                break
        return items

    @staticmethod
    def get_version(client: Any, external_id: str, version: str) -> dict:
        """Get a specific data product version."""
        return client.get(f"{_base_url(client)}/dataproducts/{external_id}/versions/{version}", headers=_ALPHA).json()

    @staticmethod
    def create_version(client: Any, external_id: str, version: str, payload: dict) -> dict:
        """Create a new data product version.

        Args:
            client: CogniteClient instance.
            external_id: Data product external ID.
            version: Semantic version string (e.g. ``"1.0.0"``).
            payload: Dict with ``views``, ``quality``, ``status``,
                ``description``, ``terms``.  Views are top-level in the
                payload — the ``dataModel`` wrapper was removed from the spec.
        """
        item = {"version": version, **payload}
        resp = client.post(
            f"{_base_url(client)}/dataproducts/{external_id}/versions",
            json={"items": [item]},
            headers=_ALPHA,
        )
        return resp.json()["items"][0]

    @staticmethod
    def update_version(client: Any, external_id: str, version: str, update: dict) -> dict:
        """Update a data product version (status, description, terms, add views)."""
        resp = client.post(
            f"{_base_url(client)}/dataproducts/{external_id}/versions/update",
            json={"items": [{"version": version, "update": update}]},
            headers=_ALPHA,
        )
        return resp.json()["items"][0]

    @staticmethod
    def delete_version(client: Any, external_id: str, version: str) -> None:
        """Delete a data product version."""
        client.post(
            f"{_base_url(client)}/dataproducts/{external_id}/versions/delete",
            json={"items": [{"version": version}]},
            headers=_ALPHA,
        )
