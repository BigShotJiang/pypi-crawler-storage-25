"""DataProduct sync handler.

Discovers all DataProducts in the CDF project, checks for version changes
against ``DataProductSyncState`` in DMS, and auto-deploys validation
workflows for DataProducts that have ``quality.rules``.

Runs as a scheduled CDF Function (typically hourly).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def _parse_semver(v: str) -> tuple[int, ...]:
    """Parse a semver string to a comparable 3-tuple, handling common variants.

    Strips a leading ``v`` prefix, pre-release suffixes (``-rc1``), and build
    metadata (``+build``).  Pads to at least 3 elements so that ``"1.2"`` and
    ``"1.2.0"`` compare as equal.
    """
    # Strip optional "v" prefix and pre-release / build metadata
    core = v.lstrip("v").split("-")[0].split("+")[0]
    parts = [int(p) for p in core.split(".") if p.isdigit()]
    # Pad to 3 elements (major.minor.patch)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _pick_latest_released(versions: list[dict]) -> dict | None:
    """Return the latest published version by semver, or ``None``."""
    released = [v for v in versions if v.get("status") == "published"]
    if not released:
        return None
    released.sort(key=lambda v: _parse_semver(v.get("version", "0.0.0")), reverse=True)
    return released[0]


def _semver_gt(a: str, b: str) -> bool:
    """Return True if semver *a* is strictly greater than *b*."""
    return _parse_semver(a) > _parse_semver(b)


def _load_sync_state(client: Any, space: str, dp_external_id: str) -> dict:
    """Load DataProductSyncState node from DMS.  Returns empty dict if absent."""
    from cognite.client.data_classes.data_modeling.ids import ViewId
    from cognite.client.exceptions import CogniteAPIError

    try:
        view_id = ViewId(space=space, external_id="DataProductSyncStateView", version="1")
        result = client.data_modeling.instances.retrieve(
            nodes=[(space, dp_external_id)],
            sources=[view_id],
        )
        if result.nodes:
            props = result.nodes[0].properties.get(view_id)
            return dict(props) if props else {}
    except CogniteAPIError as e:
        if e.code != 404:
            print(f"  Warning: failed to load sync state for {dp_external_id}: {e}")
    return {}


def _save_sync_state(client: Any, space: str, dp_external_id: str, version: str) -> None:
    """Upsert DataProductSyncState node in DMS."""
    from cognite.client.data_classes.data_modeling import NodeApply, NodeOrEdgeData
    from cognite.client.data_classes.data_modeling.ids import ContainerId

    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    props = {
        "data_product_external_id": dp_external_id,
        "last_processed_version": version,
        "last_sync_time": now_iso,
        "last_historic_triggered_at": now_iso,
    }
    node = NodeApply(
        space=space,
        external_id=dp_external_id,
        sources=[NodeOrEdgeData(source=ContainerId(space, "DataProductSyncState"), properties=props)],
    )
    client.data_modeling.instances.apply(nodes=[node])


def _load_settings_from_dms(client: Any, space: str) -> dict:
    """Load DeploymentSettings from DataQualitySettings DMS container."""
    from cognite.client.data_classes.data_modeling.ids import ViewId
    from cognite.client.exceptions import CogniteAPIError

    try:
        # DataQualitySettings container is exposed via DataQualitySettingsView (v1),
        # created by deploy_data_models. Use the ViewId so Properties.load() can
        # parse the response correctly (it requires the external_id/version format).
        view_id = ViewId(space=space, external_id="DataQualitySettingsView", version="1")
        result = client.data_modeling.instances.retrieve(
            nodes=[(space, "default")],
            sources=[view_id],
        )
        if result.nodes:
            props = result.nodes[0].properties.get(view_id)
            return dict(props) if props else {}
    except CogniteAPIError as e:
        print(f"  Warning: could not load settings from DMS: {e}")
    return {}


def _build_deployment_settings(dms_props: dict) -> Any:
    from cognite_data_quality._containers import build_deployment_settings_from_props

    return build_deployment_settings_from_props(dms_props)


def handle_data_product_sync(
    data: dict[str, Any], client: Any, secrets: dict[str, str] | None = None
) -> dict[str, Any]:
    """Sync DataProduct quality rules to validation workflows.

    Discovers all DataProducts in the project, identifies those with
    ``quality.rules``, and deploys instance validation workflows when
    a new version is detected.

    Args:
        data: Input payload with:
            - ``data_quality_space``: DMS space for state (default ``"dataQuality"``)
            - ``function_external_id``: fallback function ID
        client: CogniteClient instance
        secrets: Optional secrets dict (unused, present for handler signature compat)

    Returns:
        Summary dict with per-DataProduct results.
    """
    from cognite_data_quality._dataproduct_client import DataProductClient
    from cognite_data_quality._dataproduct_loader import load_views_from_data_product
    from cognite_data_quality._workflow_deployer import deploy_instance_workflows

    space = data.get("data_quality_space", "dataQuality")

    # Load deployment settings from DMS
    print("Loading deployment settings from DMS...")
    dms_props = _load_settings_from_dms(client, space)
    if not dms_props:
        return {
            "status": "error",
            "error": "No DataQualitySettings found in DMS. Run deploy_validation_infrastructure() first.",
        }
    settings = _build_deployment_settings(dms_props)
    print(f"  Settings loaded (function: {settings.function.external_id})")

    # Discover all DataProducts
    print("Discovering DataProducts...")
    all_dps = DataProductClient.list_all(client)
    print(f"  Found {len(all_dps)} DataProduct(s)")

    results: list[dict[str, Any]] = []
    deployed_count = 0
    skipped_count = 0

    for dp in all_dps:
        dp_id = dp["externalId"]
        dp_name = dp.get("name", dp_id)

        # List versions and pick latest RELEASED
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        if not latest:
            print(f"  {dp_name}: no published version, skipping")
            skipped_count += 1
            results.append({"dataProduct": dp_id, "status": "skipped", "reason": "no_released_version"})
            continue

        current_version = latest["version"]

        # Check for quality rules
        quality = latest.get("quality") or {}
        rules = quality.get("rules", [])
        if not rules:
            print(f"  {dp_name} v{current_version}: no quality rules, skipping")
            skipped_count += 1
            results.append({"dataProduct": dp_id, "status": "skipped", "reason": "no_quality_rules"})
            continue

        # Load sync state
        state = _load_sync_state(client, space, dp_id)
        last_version = state.get("last_processed_version")

        if last_version and not _semver_gt(current_version, last_version):
            print(f"  {dp_name} v{current_version}: up to date (last: {last_version})")
            skipped_count += 1
            results.append(
                {"dataProduct": dp_id, "status": "skipped", "reason": "up_to_date", "version": current_version}
            )
            continue

        # New or updated version -- deploy workflows
        print(f"  {dp_name} v{current_version}: deploying workflows ({len(rules)} rule ref(s))...")

        view_configs = load_views_from_data_product(client, dp_id, current_version, version_data=latest)
        if not view_configs:
            print("    No views to deploy")
            results.append({"dataProduct": dp_id, "status": "skipped", "reason": "no_views"})
            continue

        workflow_results = deploy_instance_workflows(
            client=client,
            settings=settings,
            views=view_configs,
            shacl_dir=None,
            force=True,
        )

        # Save updated sync state
        _save_sync_state(client, space, dp_id, current_version)

        deployed_count += 1
        results.append(
            {
                "dataProduct": dp_id,
                "version": current_version,
                "status": "deployed",
                "views": len(view_configs),
                "workflows": workflow_results,
            }
        )
        print(f"    Deployed {len(view_configs)} workflow(s)")

    summary = {
        "status": "completed",
        "total_data_products": len(all_dps),
        "deployed": deployed_count,
        "skipped": skipped_count,
        "results": results,
    }
    print(f"\nSync complete: {deployed_count} deployed, {skipped_count} skipped")
    return summary
