"""
SHACL utilities for loading rules and running validation.
"""


def load_shacl_from_file(client, external_id: str) -> str:
    """
    Load SHACL rules from a CDF File by external ID.

    Args:
        client: Cognite client instance
        external_id: External ID of the file containing SHACL rules

    Returns:
        SHACL rules as a string
    """
    file_bytes = client.files.download_bytes(external_id=external_id)
    return file_bytes.decode("utf-8")


def load_shacl_from_rulesets(client, refs: list) -> str:
    """Fetch SHACL rules from the CDF RuleSet API and combine them.

    Each ref is a dict with ``externalId`` and ``version`` keys pointing
    to a CDF RuleSet version.  The ``rules`` list from each version is
    concatenated with blank-line separators.

    Args:
        client: Cognite client instance
        refs: List of ``{"externalId": ..., "version": ...}`` dicts.

    Returns:
        Combined SHACL rules as a single Turtle string.
    """
    from cognite_data_quality._dataproduct_client import RuleSetClient

    parts: list[str] = []
    for ref in refs:
        version_data = RuleSetClient.get_version(client, ref["externalId"], ref["version"])
        parts.extend(version_data.get("rules", []))
    return "\n\n".join(parts)
