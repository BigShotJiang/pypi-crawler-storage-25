"""Migration utilities for publishing existing YAML/TTL configs to the CDF DataProduct + RuleSet APIs.

Usage example::

    from cognite_data_quality import (
        load_view_configs,
        publish_shacl_to_ruleset,
        publish_view_config_to_data_product,
    )

    # 1. Publish SHACL rules to a RuleSet
    publish_shacl_to_ruleset(
        client,
        shacl_path="config/environments/cog-ai/shacl_rules/equipment_shacl.ttl",
        ruleset_ext_id="equipment-rules",
        version="1.0.0",
    )

    # 2. Publish view configs to a DataProduct
    views = load_view_configs("config/environments/cog-ai/views")
    publish_view_config_to_data_product(
        client,
        view_configs=views,
        dp_ext_id="equipment-product",
        dp_version="1.0.0",
    )
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from cognite_data_quality._dataproduct_client import DataProductClient, RuleSetClient

if TYPE_CHECKING:
    from cognite.client import CogniteClient

    from cognite_data_quality.deploy import ViewConfig

# RuleSet API allows up to 100 rules per version, each up to 100,000 chars.
_MAX_RULE_CHARS = 100_000
_MAX_RULES_PER_VERSION = 100


def publish_shacl_to_ruleset(
    client: CogniteClient,
    shacl_path: str | Path,
    ruleset_ext_id: str,
    version: str,
    *,
    create_ruleset: bool = True,
    ruleset_name: str | None = None,
    dry_run: bool = False,
) -> dict:
    """Read a ``.ttl`` file and publish its content as a RuleSet version.

    The file is read as a single string.  If the content exceeds
    100,000 characters it is split on blank lines into multiple rule
    entries (the RuleSet API accepts up to 100 entries per version).

    Args:
        client: CogniteClient instance.
        shacl_path: Path to the SHACL Turtle file.
        ruleset_ext_id: External ID for the RuleSet.
        version: Semantic version string (e.g. ``"1.0.0"``).
        create_ruleset: Create the RuleSet if it doesn't exist.
        ruleset_name: Human-readable name (defaults to *ruleset_ext_id*).
        dry_run: Preview without writing.

    Returns:
        The created RuleSet version dict, or a dry-run summary.
    """
    content = Path(shacl_path).read_text(encoding="utf-8")

    # Split into chunks if needed
    rules: list[str]
    if len(content) <= _MAX_RULE_CHARS:
        rules = [content]
    else:
        # Split on double-newlines (shape boundaries)
        chunks = content.split("\n\n")
        rules = []
        current = ""
        for chunk in chunks:
            candidate = f"{current}\n\n{chunk}" if current else chunk
            if len(candidate) > _MAX_RULE_CHARS:
                if current:
                    rules.append(current)
                # If a single chunk exceeds the limit on its own, include it
                # as-is — the API will reject it with a clear error.
                if len(chunk) > _MAX_RULE_CHARS:
                    rules.append(chunk)
                    current = ""
                else:
                    current = chunk
            else:
                current = candidate
        if current:
            rules.append(current)

    if len(rules) > _MAX_RULES_PER_VERSION:
        raise ValueError(
            f"SHACL file produces {len(rules)} rule chunks, "
            f"but the RuleSet API allows at most {_MAX_RULES_PER_VERSION}."
        )

    if dry_run:
        return {
            "ruleset_ext_id": ruleset_ext_id,
            "version": version,
            "rule_count": len(rules),
            "total_chars": sum(len(r) for r in rules),
            "status": "dry_run",
        }

    if create_ruleset:
        try:
            RuleSetClient.create(client, ruleset_ext_id, ruleset_name or ruleset_ext_id)
            print(f"  Created RuleSet: {ruleset_ext_id}")
        except Exception:
            # Already exists
            print(f"  RuleSet {ruleset_ext_id} already exists")

    # RuleSet versions are immutable — skip creation if it already exists.
    try:
        existing = RuleSetClient.get_version(client, ruleset_ext_id, version)
        if existing:
            print(f"  RuleSet version {ruleset_ext_id}@{version} already exists, skipping")
            return existing
    except Exception:
        pass  # Version does not exist yet — proceed to create

    result = RuleSetClient.create_version(client, ruleset_ext_id, version, rules)
    print(f"  Published RuleSet version {ruleset_ext_id}@{version} ({len(rules)} rule(s))")
    return result


def publish_view_config_to_data_product(
    client: CogniteClient,
    view_configs: list[ViewConfig],
    dp_ext_id: str,
    dp_version: str,
    *,
    create_dp: bool = True,
    dp_name: str | None = None,
    schema_space: str | None = None,
    datamodel_external_id: str | None = None,
    status: str = "draft",
    description: str | None = None,
    dry_run: bool = False,
) -> dict:
    """Publish a set of ``ViewConfig`` objects as a DataProduct version.

    Each view config's ``shacl_rules`` must have either a
    ``ruleset_references`` or a ``file``/``external_id`` that has been
    published to a RuleSet first.

    Args:
        client: CogniteClient instance.
        view_configs: View configurations to include in the DataProduct.
        dp_ext_id: External ID for the DataProduct.
        dp_version: Semantic version string (e.g. ``"1.0.0"``).
        create_dp: Create the DataProduct if it doesn't exist.
        dp_name: Human-readable name (defaults to *dp_ext_id*).
        schema_space: DMS space for the DataProduct's ``schemaSpace`` field.
            Defaults to the first view's ``space`` when not set.
        datamodel_external_id: Deprecated — the DataProducts API no longer
            uses a ``dataModel`` wrapper.  Ignored if passed.
        status: Version status (``"draft"``, ``"published"``, ``"deprecated"``).
        description: Markdown description for the version.
        dry_run: Preview without writing.

    Returns:
        The created DataProduct version dict, or a dry-run summary.
    """
    if not view_configs:
        raise ValueError("view_configs must not be empty")

    # Space for the DataProduct's schemaSpace; falls back to the first view's space.
    dp_schema_space = schema_space or view_configs[0].view.space

    # Build the top-level views list.  Each entry carries its own space + version
    # (the dataModel wrapper was removed from the API spec).
    views: list[dict[str, Any]] = [
        {
            "space": vc.view.space,
            "externalId": vc.view.external_id,
            "version": vc.view.version,
            "instanceSpaces": {
                "read": vc.instance_spaces or [],
                "write": [],
            },
        }
        for vc in view_configs
    ]

    # Collect unique ruleset references
    rule_refs: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for vc in view_configs:
        refs = vc.shacl_rules.ruleset_references or []
        for ref in refs:
            key = (ref["externalId"], ref["version"])
            if key not in seen:
                seen.add(key)
                rule_refs.append(ref)

    if dry_run:
        return {
            "dp_ext_id": dp_ext_id,
            "dp_version": dp_version,
            "views": len(views),
            "quality_rules": len(rule_refs),
            "status": "dry_run",
        }

    if create_dp:
        # Ensure the schema space exists before creating the DataProduct —
        # the API returns a 400 if the space is absent.
        try:
            from cognite.client.data_classes.data_modeling import SpaceApply

            client.data_modeling.spaces.apply(SpaceApply(space=dp_schema_space, name=dp_schema_space))
        except Exception:
            pass  # space already exists or the client lacks spaces:write (non-fatal)

        try:
            DataProductClient.create(client, dp_ext_id, dp_name or dp_ext_id, schema_space=dp_schema_space)
            print(f"  Created DataProduct: {dp_ext_id} (schemaSpace={dp_schema_space})")
        except Exception:
            print(f"  DataProduct {dp_ext_id} already exists")

    payload: dict[str, Any] = {
        "views": views,
        "status": status,
    }
    if rule_refs:
        payload["quality"] = {"rules": rule_refs}
    if description:
        payload["description"] = description

    # DataProduct versions are immutable — skip creation if it already exists.
    try:
        existing = DataProductClient.get_version(client, dp_ext_id, dp_version)
        if existing:
            print(f"  DataProduct version {dp_ext_id}@{dp_version} already exists, skipping")
            return existing
    except Exception:
        pass  # Version does not exist yet — proceed to create

    result = DataProductClient.create_version(client, dp_ext_id, dp_version, payload)
    print(f"  Published DataProduct version {dp_ext_id}@{dp_version} ({len(views)} view(s), {len(rule_refs)} rule(s))")
    return result
