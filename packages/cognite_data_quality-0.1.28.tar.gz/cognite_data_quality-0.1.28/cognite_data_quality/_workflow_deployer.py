"""Lightweight workflow/trigger deployment for CDF instance validation.

This module contains only the logic needed to create or update CDF Workflows
and Triggers from ``ViewConfig`` objects.  It is intentionally kept separate
from ``deploy.py`` (which orchestrates full CI/CD deployments) so that the
``data_product_sync`` runtime handler can import just what it needs without
pulling in the full deployment toolchain.

Typical CI/CD usage (via ``deploy.py``)::

    from cognite_data_quality.deploy import deploy_instance_workflows

Runtime usage (from ``data_product_sync`` handler)::

    from cognite_data_quality._workflow_deployer import deploy_instance_workflows
"""

from __future__ import annotations

import hashlib
import json
import re
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

from cognite.client.data_classes.workflows import (
    FunctionTaskParameters,
    WorkflowDefinitionUpsert,
    WorkflowTask,
    WorkflowUpsert,
    WorkflowVersionUpsert,
)

if TYPE_CHECKING:
    from cognite.client import CogniteClient

    from cognite_data_quality.deploy import DeploymentSettings, ShaclRulesRef, ViewConfig


# ---------------------------------------------------------------------------
# CDF Files upload helpers (yaml mode only — skipped when ruleset_references)
# ---------------------------------------------------------------------------


def _upload_shacl_rules(
    client: CogniteClient,
    settings: DeploymentSettings,
    shacl_dir: Path,
    shacl_file: ShaclRulesRef,
    dry_run: bool,
    rule_set_id: str | None = None,
    rule_set_version: str | None = None,
) -> str:
    if not shacl_file.file or not shacl_file.external_id:
        raise ValueError("shacl_file must have both file and external_id set")
    file_path = shacl_dir / shacl_file.file
    if not file_path.exists():
        raise FileNotFoundError(f"SHACL rules file not found: {file_path}")
    if dry_run:
        return shacl_file.external_id
    dataset_external_id = settings.shacl_rules.dataset_external_id
    dataset_id = None
    if dataset_external_id:
        dataset = client.data_sets.retrieve(external_id=dataset_external_id)
        if dataset:
            dataset_id = dataset.id

    metadata: dict[str, str] = {}
    if rule_set_id:
        metadata["rule_set_id"] = rule_set_id
    if rule_set_version:
        metadata["rule_set_version"] = rule_set_version

    uploaded = client.files.upload(
        path=str(file_path),
        name=shacl_file.file,
        external_id=shacl_file.external_id,
        mime_type=settings.shacl_rules.mime_type,
        data_set_id=dataset_id,
        metadata=metadata if metadata else None,
        overwrite=True,
    )
    return uploaded.external_id


def _upload_view_config(
    client: CogniteClient,
    view_config: ViewConfig,
    dataset_id: int | None,
    dry_run: bool,
) -> str:
    """Upload a view config as YAML to CDF Files (reuses SHACL rules dataset).

    External ID scheme: ``{view_external_id}_view_config``
    e.g. ``Pump`` → ``Pump_view_config``
    """
    import yaml

    external_id = f"{view_config.view.external_id}_view_config"
    if dry_run:
        return external_id
    content = yaml.dump(view_config.model_dump(exclude_none=True), allow_unicode=True, sort_keys=False)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    try:
        client.files.upload(
            path=tmp_path,
            name=f"{view_config.view.external_id}_view_config.yaml",
            external_id=external_id,
            mime_type="application/x-yaml",
            data_set_id=dataset_id,
            overwrite=True,
        )
    finally:
        Path(tmp_path).unlink()
    return external_id


def _upload_settings(
    client: CogniteClient,
    settings: DeploymentSettings,
    dataset_id: int | None,
    dry_run: bool,
) -> str:
    """Upload deployment settings as YAML to CDF Files.

    External ID scheme: ``{function_external_id}_settings``
    """
    import yaml

    function_eid = settings.function.external_id if settings.function else "settings"
    external_id = f"{function_eid}_settings"
    if dry_run:
        return external_id
    content = yaml.dump(settings.model_dump(exclude_none=True), allow_unicode=True, sort_keys=False)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    try:
        client.files.upload(
            path=tmp_path,
            name="settings.yaml",
            external_id=external_id,
            mime_type="application/x-yaml",
            data_set_id=dataset_id,
            overwrite=True,
        )
    finally:
        Path(tmp_path).unlink()
    return external_id


# ---------------------------------------------------------------------------
# Hash-based change detection
# ---------------------------------------------------------------------------


def _compute_view_config_hash(view_config: ViewConfig, shacl_content: str) -> str:
    """Compute SHA-256 hash of view configuration for change detection.

    The hash covers the view identity, SHACL content, validation settings,
    records config, and partitioning settings.  It is embedded in the workflow
    description so subsequent deploys can skip unchanged views.
    """
    config_dict: dict[str, Any] = {
        "view": {
            "space": view_config.view.space,
            "external_id": view_config.view.external_id,
            "version": view_config.view.version,
        },
        "instance_spaces": view_config.instance_spaces,
        "shacl_rules": {
            "file": view_config.shacl_rules.file,
            "external_id": view_config.shacl_rules.external_id,
        },
        "validation": {
            "auto_load_depth": view_config.validation.auto_load_depth,
            "verbose": view_config.validation.verbose,
        },
        "records": {
            "rule_set_id": view_config.records.rule_set_id if view_config.records else None,
            "rule_set_version": view_config.records.rule_set_version if view_config.records else None,
            "data_domain_external_id": view_config.records.data_domain_external_id if view_config.records else None,
        },
        "max_concurrent_executions": view_config.max_concurrent_executions,
        "chunk_size": view_config.chunk_size,
        "sync_batch_size": view_config.sync_batch_size,
        "partition_count": view_config.partition_count,
        "partition_field": view_config.partition_field,
        "use_sync_cursor_mode": view_config.use_sync_cursor_mode,
        "shacl_content": shacl_content,
    }
    config_str = json.dumps(config_dict, sort_keys=True)
    return hashlib.sha256(config_str.encode()).hexdigest()[:12]


def _get_deployed_workflow_hash(client: CogniteClient, workflow_external_id: str) -> str | None:
    """Extract the config hash embedded in a deployed workflow's description.

    Hash format: ``"... [hash:abc123def456]"``
    Returns ``None`` if the workflow doesn't exist or carries no hash.
    """
    try:
        workflow = client.workflows.retrieve(external_id=workflow_external_id)
        if workflow and workflow.description:
            match = re.search(r"\[hash:([a-f0-9]+)\]", workflow.description)
            return match.group(1) if match else None
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def deploy_instance_workflows(
    *,
    client: CogniteClient,
    settings: DeploymentSettings,
    views: list[ViewConfig],
    shacl_dir: Path | None = None,
    force: bool = False,
    dry_run: bool = False,
    view_filter: list[str] | None = None,
    skip_unchanged: bool = True,
) -> list[dict[str, object]]:
    """Deploy CDF Workflows for instance validation.

    Each view in *views* gets one CDF Workflow (and one trigger if
    ``use_sync_cursor_mode`` is set).  SHACL rules are either uploaded to
    CDF Files (*shacl_dir* provided) or referenced via the RuleSet API
    (*view.shacl_rules.ruleset_references* set).

    Args:
        client: CogniteClient instance.
        settings: Deployment settings (workflow prefix, function external_id, …).
        views: View configurations to deploy workflows for.
        shacl_dir: Directory containing ``.ttl`` files.  ``None`` when views
            use ``ruleset_references`` (RuleSet API, no CDF Files upload).
        force: Force redeployment even when the config hash is unchanged.
        dry_run: Preview changes without writing to CDF.
        view_filter: Restrict deployment to these view external_ids.
        skip_unchanged: Skip a view when its hash matches the deployed workflow.

    Returns:
        List of per-view result dicts (``view``, ``workflow_external_id``,
        ``status``).
    """
    if view_filter:
        views = [v for v in views if v.view.external_id in view_filter]
        print(f"  Filtered to {len(views)} views")

    dataset_id = None
    if settings.shacl_rules.dataset_external_id:
        dataset = client.data_sets.retrieve(external_id=settings.shacl_rules.dataset_external_id)
        if dataset:
            dataset_id = dataset.id

    if shacl_dir is not None:
        settings_eid = _upload_settings(client, settings, dataset_id, dry_run=dry_run)
        print(f"  Uploaded settings → CDF Files: {settings_eid}")

    results: list[dict[str, object]] = []
    for view_config in views:
        view_name = view_config.view.external_id.lower()
        workflow_external_id = view_config.workflow_external_id or f"{settings.workflow.external_id_prefix}-{view_name}"

        # Compute current config hash for change detection
        if view_config.shacl_rules.ruleset_references:
            shacl_content = json.dumps(view_config.shacl_rules.ruleset_references, sort_keys=True)
        elif shacl_dir and view_config.shacl_rules.file:
            shacl_file_path = shacl_dir / view_config.shacl_rules.file
            shacl_content = shacl_file_path.read_text() if shacl_file_path.exists() else ""
        else:
            shacl_content = ""
        current_hash = _compute_view_config_hash(view_config, shacl_content)

        if not dry_run:
            deployed_hash = _get_deployed_workflow_hash(client, workflow_external_id)

            if skip_unchanged and not force and current_hash == deployed_hash:
                print(f"  Workflow {workflow_external_id} up to date (hash: {current_hash})")
                results.append(
                    {
                        "view": view_config.view.external_id,
                        "workflow_external_id": workflow_external_id,
                        "status": "skipped",
                        "reason": "unchanged",
                    }
                )
                continue

            if deployed_hash and deployed_hash != current_hash:
                print(f"  Config changed: {deployed_hash} -> {current_hash}")
            elif not deployed_hash:
                print(f"  New workflow (hash: {current_hash})")

        records = settings.records
        overrides = view_config.records
        if not view_config.shacl_rules.ruleset_references and shacl_dir:
            _upload_shacl_rules(
                client,
                settings,
                shacl_dir,
                view_config.shacl_rules,
                dry_run=dry_run,
                rule_set_id=overrides.rule_set_id if overrides else records.container,
                rule_set_version=overrides.rule_set_version if overrides else None,
            )
        if not view_config.shacl_rules.ruleset_references:
            view_config_eid = _upload_view_config(client, view_config, dataset_id, dry_run=dry_run)
            print(f"  Uploaded view config → CDF Files: {view_config_eid}")

        records_config = {
            "stream_id": records.stream_id,
            "rule_set_id": overrides.rule_set_id or f"{view_config.view.external_id}SHACL",
            "rule_set_version": overrides.rule_set_version or "1.0",
            "data_domain_external_id": overrides.data_domain_external_id or view_config.view.external_id,
            "records_space": records.space,
            "records_container": records.container,
            "use_instance_space": overrides.use_instance_space,
            "record_space": overrides.records_space,
        }

        shacl_source: dict[str, object] = {}
        if view_config.shacl_rules.ruleset_references:
            shacl_source["ruleset_references"] = view_config.shacl_rules.ruleset_references
        else:
            shacl_source["shacl_rules_file_external_id"] = view_config.shacl_rules.external_id

        if view_config.use_sync_cursor_mode:
            task_data: dict[str, object] = {
                "validation_type": "instance_sync_cursor",
                "view_space": view_config.view.space,
                "view_external_id": view_config.view.external_id,
                "view_version": view_config.view.version,
                "instance_spaces": view_config.instance_spaces,
                **shacl_source,
                "datamodel_space": view_config.view.space,
                "datamodel_external_id": view_config.view.external_id,
                "datamodel_version": view_config.view.version,
                "auto_load_depth": view_config.validation.auto_load_depth,
                "verbose": view_config.validation.verbose,
                "chunk_size": view_config.chunk_size,
                "data_quality_space": records.space,
                "records_config": records_config,
                "initial_sync_cutoff": None,
                "job_run_id": None,
            }
        else:
            task_data = {
                "validation_type": "instance",
                "instances": "${workflow.input}",
                **shacl_source,
                "datamodel_space": view_config.view.space,
                "datamodel_external_id": view_config.view.external_id,
                "datamodel_version": view_config.view.version,
                "auto_load_depth": view_config.validation.auto_load_depth,
                "verbose": view_config.validation.verbose,
                "max_retries": settings.partition_retries,
                "records_config": records_config,
            }

        task = WorkflowTask(
            external_id=f"validate-{view_name}",
            name=f"Validate {view_config.view.external_id} with SHACL",
            description=f"Validates {view_config.view.external_id} instances against SHACL rules",
            parameters=FunctionTaskParameters(
                external_id=settings.function.external_id if settings.function else "", data=task_data
            ),
            retries=settings.workflow.task.retries,
            timeout=settings.workflow.task.timeout,
            on_failure=settings.workflow.task.on_failure,
        )

        if not dry_run:
            print(f"  Creating/updating workflow: {workflow_external_id}")
            wf_upsert = WorkflowUpsert(
                external_id=workflow_external_id,
                description=f"SHACL validation workflow for {view_config.view.external_id} [hash:{current_hash}]",
                data_set_id=dataset_id,
            )
            if view_config.max_concurrent_executions is not None:
                wf_upsert.max_concurrent_executions = view_config.max_concurrent_executions
            client.workflows.upsert(wf_upsert)

            workflow_definition = WorkflowDefinitionUpsert(
                tasks=[task], description=f"Single-task workflow for {view_config.view.external_id}"
            )
            workflow_version = WorkflowVersionUpsert(
                workflow_external_id=workflow_external_id,
                version=settings.workflow.version,
                workflow_definition=workflow_definition,
            )
            client.workflows.versions.upsert(workflow_version)

        results.append(
            {
                "view": view_config.view.external_id,
                "workflow_external_id": workflow_external_id,
                "status": "deployed" if not dry_run else "dry_run",
            }
        )
    return results
