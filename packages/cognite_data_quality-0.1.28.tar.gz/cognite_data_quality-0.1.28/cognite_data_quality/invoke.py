"""
Invoke deployed Cognite Functions from Python.

Use these helpers to call the data quality validation functions from a notebook,
script, or any Python runtime. Each function is a thin wrapper around
client.functions.call().
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from cognite.client import CogniteClient

if TYPE_CHECKING:
    from cognite_data_quality.deploy import DeploymentSettings, ViewConfig


def call_validation(
    client: CogniteClient,
    validation_type: Literal["instance", "partitioned", "timeseries", "orchestrator", "test"],
    data: dict,
    *,
    wait: bool = True,
    external_id: str = "data-quality-validation",
) -> dict:
    """Call the unified SHACL validation function.

    The unified function consolidates all validation types into a single deployment.
    Use this function for new code. Legacy individual functions are still supported.

    Args:
        client: Cognite client instance.
        validation_type: Type of validation to perform:
            - "instance": Basic instance validation (real-time)
            - "partitioned": Partitioned historic instance validation
            - "timeseries": Time series validation (normal/backfill)
            - "orchestrator": Historic validation orchestrator
            - "test": Test SHACL rules without writing to Records API
        data: Payload dict. Contents depend on validation_type.
        wait: If True, block until the function returns.
        external_id: Function external ID (default: data-quality-validation).

    Returns:
        Response dict from the appropriate handler.

    Example:
        # Instance validation
        result = call_validation(
            client=client,
            validation_type="instance",
            data={
                "instances": {"items": [...]},
                "shacl_rules_file_external_id": "my_rules",
                "datamodel_space": "my_space",
                "datamodel_external_id": "MyModel",
                "datamodel_version": "v1",
                "records_config": {...}
            }
        )

        # Orchestrator
        result = call_validation(
            client=client,
            validation_type="orchestrator",
            data={
                "datamodel_space": "my_space",
                "view_external_id": "MyView",
                "instance_space": "my_instances",
                ...
            }
        )
    """
    payload = {"validation_type": validation_type, **data}
    call = client.functions.call(external_id=external_id, data=payload, wait=wait)
    return call.get_response() or {}


def _build_orchestrator_data(settings: DeploymentSettings, view_config: ViewConfig) -> dict:
    """Build the orchestrator data dict from deployment settings and a view config.

    Shared by the local-YAML and CDF-fetch modes of deploy_validation_pipeline.
    """
    records = settings.records
    function_external_id = settings.function.external_id
    data = {
        "datamodel_space": view_config.view.space,
        "datamodel_external_id": view_config.view.external_id,
        "datamodel_version": view_config.view.version,
        "view_space": view_config.view.space,
        "view_external_id": view_config.view.external_id,
        "view_version": view_config.view.version,
        "instance_spaces": view_config.instance_spaces,
        **(
            {"ruleset_references": view_config.shacl_rules.ruleset_references}
            if view_config.shacl_rules.ruleset_references
            else {"shacl_file_external_id": view_config.shacl_rules.external_id}
        ),
        "partition_count": view_config.partition_count,
        "partition_field": view_config.partition_field,
        "records_space": records.space,
        "records_container": records.container,
        "record_space": view_config.records.records_space,
        "stream_id": records.stream_id,
        "rule_set_id": view_config.records.rule_set_id or f"{view_config.view.external_id}SHACL",
        "rule_set_version": view_config.records.rule_set_version or "1.0",
        "auto_load_depth": view_config.validation.auto_load_depth,
        "chunk_size": view_config.chunk_size,
        "function_external_id": function_external_id,
        "data_quality_space": records.space,
        "max_retries": settings.partition_retries,
        "sync_batch_size": view_config.sync_batch_size
        if view_config.sync_batch_size is not None
        else (1000 if view_config.use_sync_cursor_mode else settings.trigger.batch_size),
        "sync_batch_timeout": settings.trigger.batch_timeout,
        "use_sync_cursor_mode": view_config.use_sync_cursor_mode,
    }
    # Compute sync_workflow_external_id using same pattern as deploy_instance_workflows
    view_name = view_config.view.external_id.lower()
    sync_workflow_id = view_config.workflow_external_id or f"{settings.workflow.external_id_prefix}-{view_name}"  # type: ignore[attr-defined]
    data["sync_workflow_external_id"] = sync_workflow_id
    return data


def deploy_validation_pipeline(
    client: CogniteClient,
    data: dict | None = None,
    *,
    settings_path: str | None = None,
    views_dir: str | None = None,
    view_external_id: str | list[str] | None = None,
    view_config_external_id: str | None = None,
    settings_external_id: str = "data-quality-validation_settings",
    data_product_external_id: str | None = None,
    data_product_version: str | None = None,
    wait: bool = True,
    external_id: str = "data-quality-validation",
) -> dict:
    """Deploy and run a full validation pipeline with batch and incremental validation.

    This function:
    1. Triggers partitioned batch load of all instances (splits data into partitions)
    2. Sets up sync trigger for ongoing incremental validation
    3. Creates scheduled workflow for monitoring progress
    4. Continuously manages orchestration (retries, cleanup)

    Convenience wrapper for call_validation(validation_type="orchestrator", ...).

    Three usage modes:

    **Mode 1: Pass data dict directly (legacy):**
        deploy_validation_pipeline(client, data={...}, wait=True)

    **Mode 2: Load from local YAML configs:**
        deploy_validation_pipeline(
            client,
            settings_path="config/environments/cog-sail/settings.yaml",
            view_external_id="SmallBoat",
            wait=True
        )

    **Mode 3: Load everything from CDF Files (no local files required):**
        deploy_validation_pipeline(
            client,
            view_config_external_id="pump_view_config",
        )

    Args:
        client: Cognite client instance.
        data: (Legacy) Payload dict. Typical keys: datamodel_space, datamodel_external_id,
            datamodel_version, view_space, view_external_id, view_version,
            instance_space, shacl_file_external_id, partition_count, partition_field,
            records_space, records_container, stream_id, rule_set_id, rule_set_version.
            If None, must provide settings_path or view_config_external_id.
        settings_path: Path to a local settings.yaml file. Optional when using
            view_config_external_id — settings are then fetched from CDF Files instead.
        views_dir: Directory containing view YAML configs. Defaults to settings_path parent / "views".
            Only used in mode 2.
        view_external_id: Specific view to deploy from local files (mode 2).
        view_config_external_id: External ID of a view config stored in CDF Files (mode 3).
            Uploaded during deployment via deploy_instance_workflows().
            External ID scheme: ``{view_external_id}_view_config`` e.g. ``Pump_view_config``.
        settings_external_id: External ID of the settings file stored in CDF Files.
            Defaults to ``data-quality-validation_settings`` (the ID used by deploy_instance_workflows).
            Only used in mode 3 when settings_path is not provided.
        wait: If True, block until the function returns.
        external_id: Function external ID (default: data-quality-validation).

    Returns:
        Response dict from the function.

    Example:
        # Mode 3: fully from CDF — no local files needed
        result = deploy_validation_pipeline(
            client,
            view_config_external_id="pump_view_config",
        )

        # Mode 3: override settings external ID
        result = deploy_validation_pipeline(
            client,
            view_config_external_id="pump_view_config",
            settings_external_id="my-function_settings",
        )

        # Mode 2: local YAML files
        result = deploy_validation_pipeline(
            client,
            settings_path="config/environments/cog-sail/settings.yaml",
            view_external_id="SmallBoat",
        )

        # Mode 1: legacy data dict
        result = deploy_validation_pipeline(
            client,
            data={"datamodel_space": "sailboat", ...}
        )
    """
    # Mode 1: data dict provided — legacy mode
    if data is not None:
        return call_validation(client, "orchestrator", data, wait=wait, external_id=external_id)

    from pathlib import Path

    import yaml

    from cognite_data_quality.deploy import DeploymentSettings, ViewConfig, load_settings

    # Mode 4: DataProduct + DMS — no local files, no CDF Files
    if data_product_external_id is not None:
        from cognite_data_quality._containers import (
            _load_settings_from_dms,
            build_deployment_settings_from_props,
        )
        from cognite_data_quality._dataproduct_client import DataProductClient
        from cognite_data_quality._dataproduct_loader import load_views_from_data_product

        dms_props = _load_settings_from_dms(client, space="dataQuality")
        settings_obj = build_deployment_settings_from_props(dms_props)

        if data_product_version is None:
            versions = DataProductClient.list_versions(client, data_product_external_id)
            if not versions:
                raise ValueError(f"No versions found for DataProduct {data_product_external_id}")
            released = [v for v in versions if v.get("status") == "RELEASED"]
            data_product_version = released[-1]["version"] if released else versions[-1]["version"]

        version_data = DataProductClient.get_version(client, data_product_external_id, data_product_version)
        view_configs = load_views_from_data_product(
            client, data_product_external_id, data_product_version, version_data=version_data
        )
        if view_external_id:
            ids = {view_external_id} if isinstance(view_external_id, str) else set(view_external_id)
            view_configs = [vc for vc in view_configs if vc.view.external_id in ids]

        # Fire all orchestrators with wait=False — each manages its own partitions,
        # retries and cursor resumption independently. CDF's function scheduler
        # queues excess invocations, so load is self-throttling.
        results = []
        for vc in view_configs:
            orchestrator_data = _build_orchestrator_data(settings_obj, vc)
            call = call_validation(
                client,
                "orchestrator",
                orchestrator_data,
                wait=False,
                external_id=settings_obj.function.external_id,
            )
            results.append({"view": vc.view.external_id, "call_id": call.id, "status": call.status})
            print(f"  Triggered {vc.view.external_id}: call_id={call.id}")
        return results

    # Mode 3: fetch both view config and settings from CDF Files — no local files needed
    if view_config_external_id is not None:
        settings_obj = (
            load_settings(Path(settings_path))
            if settings_path is not None
            else DeploymentSettings(
                **yaml.safe_load(client.files.download_bytes(external_id=settings_external_id).decode("utf-8")) or {}
            )
        )
        raw_view = client.files.download_bytes(external_id=view_config_external_id)
        view_config = ViewConfig(**yaml.safe_load(raw_view.decode("utf-8")) or {})
        data = _build_orchestrator_data(settings_obj, view_config)
        return call_validation(client, "orchestrator", data, wait=wait, external_id=settings_obj.function.external_id)

    # Mode 2: scan local YAML files
    if settings_path is None:
        raise ValueError("Must provide either 'data' dict, 'view_config_external_id', or 'settings_path'")

    if view_external_id is None:
        raise ValueError("Must provide 'view_external_id' or 'view_config_external_id' when using settings_path mode")

    settings_obj = load_settings(Path(settings_path))
    base_dir = Path(settings_path).parent
    if views_dir is None:
        views_dir_obj = base_dir / "views"
    else:
        views_dir_obj = Path(views_dir) if not isinstance(views_dir, Path) else views_dir

    view_config = None
    for config_file in views_dir_obj.glob("*.yaml"):
        config_data = yaml.safe_load(config_file.read_text(encoding="utf-8")) or {}
        config_data["_filename"] = config_file.name
        candidate = ViewConfig(**config_data)
        if candidate.view.external_id == view_external_id:
            view_config = candidate
            break

    if view_config is None:
        raise ValueError(
            f"View config for '{view_external_id}' not found in {views_dir_obj}. "
            f"Available views: {[f.stem for f in views_dir_obj.glob('*.yaml')]}"
        )

    data = _build_orchestrator_data(settings_obj, view_config)
    return call_validation(client, "orchestrator", data, wait=wait, external_id=settings_obj.function.external_id)


def call_validate_instances_shacl(
    client: CogniteClient,
    data: dict,
    *,
    wait: bool = True,
    external_id: str = "data-quality-validation",
) -> dict:
    """Call the instance SHACL validation function.

    Convenience wrapper for call_validation(validation_type="instance", ...).

    Args:
        client: Cognite client instance.
        data: Payload dict. Typical keys: instances (dict with items), shacl_rules or
            shacl_rules_file_external_id, datamodel_space, datamodel_external_id,
            datamodel_version, auto_load_depth, records_config (stream_id, rule_set_id, etc.).
        wait: If True, block until the function returns.
        external_id: Function external ID (default: data-quality-validation).

    Returns:
        Response dict with conforms, violations, instances_validated, etc.
    """
    return call_validation(client, "instance", data, wait=wait, external_id=external_id)


def call_validate_instances_shacl_partitioned(
    client: CogniteClient,
    data: dict,
    *,
    wait: bool = True,
    external_id: str = "data-quality-validation",
) -> dict:
    """Call the partitioned instance SHACL validation function (worker).

    Convenience wrapper for call_validation(validation_type="partitioned", ...).

    Args:
        client: Cognite client instance.
        data: Payload dict. Same shape as validate-instances-shacl; instances are
            typically provided by the orchestrator.
        wait: If True, block until the function returns.
        external_id: Function external ID (default: data-quality-validation).

    Returns:
        Response dict with status, conforms, violations, instances_validated, etc.
    """
    return call_validation(client, "partitioned", data, wait=wait, external_id=external_id)


def call_validate_timeseries_shacl(
    client: CogniteClient,
    data: dict,
    *,
    wait: bool = True,
    external_id: str = "data-quality-validation",
) -> dict:
    """Call the time series SHACL validation function.

    Convenience wrapper for call_validation(validation_type="timeseries", ...).

    Args:
        client: Cognite client instance.
        data: Payload dict. Typical keys: shacl_rules_file_external_id, datamodel_space,
            datamodel_external_id, datamodel_version, filter or instance_ids,
            records_config.
        wait: If True, block until the function returns.
        external_id: Function external ID (default: data-quality-validation).

    Returns:
        Response dict with validation results.
    """
    return call_validation(client, "timeseries", data, wait=wait, external_id=external_id)
