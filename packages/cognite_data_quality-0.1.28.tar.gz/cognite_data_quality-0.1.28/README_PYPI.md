# Cognite Data Quality

SHACL-based data quality validation for Cognite Data Fusion (CDF).

## Documentation

For full documentation, installation guides, deployment, and examples, see:

**[https://cognite-data-quality-validation.readthedocs-hosted.com/en/latest/](https://cognite-data-quality-validation.readthedocs-hosted.com/en/latest/)**

## Latest release

See [release notes](https://github.com/cognitedata/data-quality-validation/releases) for the latest changes. Latest: 0.1.28.

## Installation

```bash
pip install cognite-data-quality
```

## Quick Start

```python
from cognite_data_quality import DataModelConfig, run_validation, load_cognite_client_from_toml

client = load_cognite_client_from_toml("cog-sail.toml")

result = run_validation(
    client=client,
    rules_path="path/to/shacl_rules.ttl",
    rules_format="ttl",
    datamodel=DataModelConfig(space="my_space", external_id="MyModel", version="v1"),
    instance_space="my_space",
    limit=10,
)
print(result.conforms, result.instance_count, len(result.violations))
```

For YAML-based configuration, deployment, time series validation, and more, see the [documentation](https://cognite-data-quality-validation.readthedocs-hosted.com/en/latest/).

