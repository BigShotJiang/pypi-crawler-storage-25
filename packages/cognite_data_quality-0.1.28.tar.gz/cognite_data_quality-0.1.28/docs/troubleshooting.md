# Troubleshooting

## View function logs

```python
from cognite.client import CogniteClient

client = CogniteClient()

calls = client.functions.calls.list(
    function_external_id="data-quality-validation",
    limit=10,
)

logs = client.functions.calls.get_logs(call_id=calls[0].id)
print(logs)
```

## Check workflow execution status

```python
executions = client.workflows.executions.list(
    workflow_external_id="dq-shacl-equipment",
    limit=10,
)

for execution in executions:
    print(f"Status: {execution.status}, Started: {execution.started_at}")
```

---

## Workflow not triggering on data changes

**Symptoms:** Instance changes in DMS don't start the validation workflow.

**Check:**

1. Retrieve the trigger and verify it is active:
   ```python
   trigger = client.workflows.triggers.retrieve(external_id="dq-shacl-trigger-<view>")
   print(trigger.trigger_type, trigger.is_active)
   ```
2. Verify the instance space in the trigger filter matches the space where data changes occur.
3. Confirm the workflow version in the trigger matches the deployed workflow version.
4. If you deployed with `--skip-trigger`, redeploy without that flag.

---

## "Failed to load SHACL rules"

**Symptoms:** Function logs show an error loading rules.

**Check:**

1. Verify the SHACL file exists in CDF Files with the expected external ID.
2. Confirm the external ID in the view config (`shacl_rules.external_id`) matches the file.
3. Verify the file is in the correct CDF dataset (set in `settings.yaml` under `shacl_rules.dataset_external_id`).
4. Validate Turtle syntax locally:
   ```bash
   python scripts/validate_config.py
   ```

---

## "No instances to validate"

**Symptoms:** Validation completes with zero instances processed.

**Check:**

1. Confirm the DMS filter in the view config or time series config is correct.
2. Verify instances exist in the configured space.
3. Ensure the view external ID and version match the actual view in CDF.

---

## Zero violations when you expect some

**Symptoms:** Validation runs but produces no violations for a rule you expect to fire.

**Check:**

1. The `sh:targetClass` in the SHACL rule targets a **concrete view type**, not a CDF interface.  
   Interfaces (e.g. `MMSINumber`) are not used as `rdf:type` in the RDF graph — concrete view types (e.g. `NavigationAid`) are. A shape targeting an interface silently matches nothing.
2. Run with `print_output=True` and `verbose=True` to see per-instance output and zero-instance class warnings.
3. Check `auto_load_depth` — if the rule uses properties from referenced instances, depth `0` won't load them.

See [SHACL rules and CDF data models](usage/shacl_cdf_data_models.md) for details.

---

## Function dependency errors

**"ModuleNotFoundError: No module named 'cognite_data_quality'"**

The function was deployed before the package was published to PyPI, or is pinned to an old version.

1. Publish the latest package: `python -m build && twine upload dist/*`
2. Force redeploy: `python scripts/deploy_infrastructure.py --env <env> --force`

---

## RAW table validation issues

**"RAW table not found"**

- Verify the RAW database and table names in the config match what exists in CDF.
- Confirm the service principal has read access to the RAW table.

**"No rows updated since last run"**

Normal for incremental validation when no changes occurred. Check `RawValidationState` in the `dataQuality` DMS space for `last_processed_timestamp` to confirm.

**Cursor state not saving**

- Ensure the `dataQuality` space exists in CDF.
- Verify the service principal has write access to the `dataQuality` space.
- Run `python scripts/ensure_container.py` to create the `FunctionValidationState` container if missing.

---

## Records API returns no results

**Symptoms:** Filter queries return empty `items`.

**Check:**

1. Confirm `client.config.headers["cdf-version"] = "alpha"` is set before the request.
2. Verify the stream ID in the query matches `records.stream_id` in `settings.yaml`.
3. Check the time range — Records API filters use milliseconds since epoch. Widen `lastUpdatedTime` to confirm records exist.
