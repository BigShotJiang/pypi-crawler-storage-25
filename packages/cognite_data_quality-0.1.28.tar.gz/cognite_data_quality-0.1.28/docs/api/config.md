# Config

The `cognite_data_quality._config` module provides configuration data classes used across the package:

- `DataModelConfig` — identifies a CDF data model (space, external_id, version)
- `RecordsConfig` — configures Records API output (stream_id, rule_set_id, rule_set_version)
- `DeploymentSettings` — loaded from `settings.yaml` for deployment

Pass `DataModelConfig` and `RecordsConfig` to `run_validation()`. `DeploymentSettings` is loaded internally by `deploy_validation_infrastructure()` but can also be loaded manually with `load_settings()`.

See [Config (TOML and view config)](../quickstart/config.md) for TOML credentials and YAML view config structure.

::: cognite_data_quality._config
