# Runner

The `cognite_data_quality.runner` module provides `run_validation()` — the main entry point for running SHACL validation locally against CDF DMS instances. It requires only a Cognite client and a rules source (TTL, JSON, or YAML view config); no Cognite Functions or Workflows are needed.

Use `run_validation()` during development to iterate on SHACL rules before deploying infrastructure. Set `post_to_records=True` with a `RecordsConfig` to test the full pipeline including Records output.

See [Run validation](../usage/run_validation.md) for usage examples and parameter descriptions.

::: cognite_data_quality.runner
