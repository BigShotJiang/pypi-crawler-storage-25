# Records

The `cognite_data_quality._records` module provides helpers for posting validation results to the CDF Records API and for constructing `DataQualityValidationRecord` payloads.

Validation results written by `run_validation()` (when `post_to_records=True`) and by the deployed Cognite Functions all use these helpers. You typically do not call these directly — use `run_validation()` or the deployed function instead.

See [Records output](../usage/records_output.md) for how to query and filter records, and the record schema.

::: cognite_data_quality._records
