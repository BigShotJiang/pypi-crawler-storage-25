# Deployment API

The `cognite_data_quality.deploy` module provides a unified API for deploying data quality validation infrastructure to CDF. Function handler code is embedded in the package; no separate `function/` directory or `function_source_root` is required.

## Overview

- **`deploy_validation_infrastructure()`** – Ensures Records and state containers (OrchestrationState, FunctionValidationState), deploys the monitoring data model and views, the unified validation function, instance and (optionally) time series workflows and triggers.
- **`deploy_validation_pipeline()`** – Runs the full validation pipeline for a view (historic partitions, sync trigger, monitor schedule). Call after infrastructure is deployed.
- **`deploy_incremental()`** – Deploys function and workflow for a single view config (alternative to full infrastructure deploy).
- Component helpers: `deploy_functions()`, `deploy_instance_workflows()`, `deploy_timeseries_workflows()`, `deploy_data_models()`.

## Main Functions

### `deploy_validation_infrastructure()`

**Unified deployment** of all validation infrastructure (recommended). Uses `settings_path` and `views_dir`; function code is taken from the package.

```python
from pathlib import Path
from cognite_data_quality import deploy_validation_infrastructure, load_cognite_client_from_toml

client = load_cognite_client_from_toml("config.toml")

settings_path = Path("config/environments/my_env/settings.yaml")
views_dir = Path("config/environments/my_env/views")

deploy_validation_infrastructure(
    client=client,
    settings_path=settings_path,
    views_dir=views_dir,
    function_secrets={"client-id": "...", "client-secret": "..."},  # optional but required for orchestrator triggers
    force=False,
    dry_run=False,
)
```

### `deploy_validation_pipeline()`

Deploy and run the full validation pipeline for a view (historic data, sync trigger, monitor schedule):

```python
from cognite_data_quality import deploy_validation_pipeline

result = deploy_validation_pipeline(
    client,
    settings_path="config/environments/my_env/settings.yaml",
    view_external_id="MyView",
    wait=True,
)
# result: orchestration_id, partitions_triggered, sync_trigger_external_id, monitor_schedule_name, distribution, ...
```

### `deploy_incremental()`

Deploy function and workflow for a **single** view config (takes view config path and optional `config_env`):

```python
from cognite_data_quality import deploy_incremental

deploy_incremental(
    view_config_path="config/environments/my_env/views/my_view.yaml",
    client=client,
    force=False,
    dry_run=False,
)
```

## Component-Specific Functions

For fine-grained control, you can deploy individual components:

### `deploy_functions()`

Deploy Cognite Functions:

```python
from cognite_data_quality import deploy_functions, load_settings

settings = load_settings("config/environments/my_env/settings.yaml")

deploy_functions(
    client=client,
    settings=settings,
    env_name="my_env",
    force=False,
)
```

### `deploy_instance_workflows()`

Deploy instance validation workflows:

```python
from cognite_data_quality import deploy_instance_workflows, load_view_configs

view_configs = load_view_configs("config/environments/my_env/views")

deploy_instance_workflows(
    client=client,
    view_configs=view_configs,
    settings=settings,
    env_name="my_env",
    skip_trigger=False,
)
```

### `deploy_timeseries_workflows()`

Deploy time series validation workflows:

```python
from cognite_data_quality import deploy_timeseries_workflows, load_timeseries_configs

ts_configs = load_timeseries_configs("config/environments/my_env/timeseries")

deploy_timeseries_workflows(
    client=client,
    ts_configs=ts_configs,
    settings=settings,
    env_name="my_env",
)
```

### `deploy_data_models()`

Deploy data models (optional):

```python
from cognite_data_quality import deploy_data_models, DataModelId

data_models = [
    DataModelId(space="my_space", external_id="MyDataModel", version="v1"),
]

deploy_data_models(
    client=client,
    data_models=data_models,
    source_dir="data_models",
)
```

## Configuration Loaders

### `load_settings()`

Load environment settings from YAML:

```python
from cognite_data_quality import load_settings, DeploymentSettings

settings: DeploymentSettings = load_settings("config/environments/my_env/settings.yaml")
```

### `load_view_configs()`

Load instance validation configurations:

```python
from cognite_data_quality import load_view_configs

configs = load_view_configs("config/environments/my_env/views")
# Returns: dict[str, ViewConfig]
```

### `load_timeseries_configs()`

Load time series validation configurations:

```python
from cognite_data_quality import load_timeseries_configs

configs = load_timeseries_configs("config/environments/my_env/timeseries")
# Returns: dict[str, TimeSeriesConfig]
```

### `load_views_from_cdf()`

Load views directly from CDF DMS:

```python
from cognite_data_quality import load_views_from_cdf

views = load_views_from_cdf(
    client=client,
    space="my_space",
    data_model_external_id="MyDataModel",
    version="v1",
)
```

## Data Classes

### `DeploymentSettings`

Environment-specific deployment settings loaded from `settings.yaml`.

### `DataModelId`

Identifier for a CDF data model:

```python
from cognite_data_quality import DataModelId

dm_id = DataModelId(
    space="my_space",
    external_id="MyDataModel",
    version="v1",
)
```

## Module Reference

::: cognite_data_quality.deploy
