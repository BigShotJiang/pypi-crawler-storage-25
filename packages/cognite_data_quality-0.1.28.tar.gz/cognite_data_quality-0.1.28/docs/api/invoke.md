# Invoke

The `cognite_data_quality.invoke` module provides helpers for calling **already-deployed** Cognite Functions from Python. These helpers send a payload to the function running in CDF — they do not run validation locally.

- `call_validation()` — unified entry point, dispatches by `validation_type`
- `call_validate_instances_shacl()` — instance validation (type: `instance`)
- `call_validate_instances_shacl_partitioned()` — partitioned worker (type: `partitioned`)
- `call_validate_timeseries_shacl()` — time series validation (type: `timeseries`)
- `deploy_validation_pipeline()` — deploy and run the full validation pipeline (orchestrator)

See [Invoking validation functions](../usage/invoke.md) for usage examples and payload key descriptions.

::: cognite_data_quality.invoke
