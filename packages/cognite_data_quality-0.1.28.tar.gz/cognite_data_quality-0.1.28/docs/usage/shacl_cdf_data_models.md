# SHACL rules and CDF data models

When you run validation, instance data is loaded from CDF into an RDF graph using the data model’s **views** (containers). The graph uses **concrete view types** for `rdf:type`, not GraphQL interface names. This affects how you should target SHACL rules.

## Interfaces vs concrete types

In CDF Data Modeling:

- **Interfaces** (e.g. `MMSINumber`) are implemented by one or more **views** (e.g. `NavigationAid`, `ShoreStation`, `SARAircraft`).
- Instances are stored in **containers** (views). Each node in the RDF graph typically gets `rdf:type` set to the **view** it belongs to (e.g. `sb:NavigationAid`), not to the interface (e.g. `sb:MMSINumber`).

So a rule that uses `sh:targetClass sb:MMSINumber` will usually **not match any nodes**, because no node has that type in the graph. The rule will never run and you will not get violations.

## What to do

1. **Target concrete views**  
   Use `sh:targetClass` with the view(s) that implement the interface (e.g. `sb:NavigationAid`, `sb:ShoreStation`, `sb:SARAircraft`). You can use one shape per view with the same constraint, or repeat the same property shape under each.

2. **Use a SPARQL-based target**  
   Use `sh:target` with a SPARQL query that selects all nodes whose type is one of the implementing views. That way you still express “this rule applies to the interface” while matching how types appear in the graph.

## Validation-time warning

When you run validation with verbose output, the runner checks whether any rule targets a class that has **zero instances** in the loaded graph. If so, it prints a warning, for example:

```
  [WARNING] Some rules target a class that has no instances in the loaded graph:
    - MMSINumberShape targets MMSINumber (0 instances)
    This often happens when the target is a CDF *interface*: the graph uses concrete
    view types. Consider targeting the concrete views that implement the interface,
    or use a SPARQL-based sh:target to select all implementing types.
```

Use this warning to find rules that target an interface (or another class that has no instances) and then either target the concrete views or switch to a SPARQL target.

!!! tip "No violations doesn't mean the rule ran"
    If a rule produces zero violations and you expected some, check whether the target class has any instances. A shape that targets an interface (or an empty view) silently matches nothing and reports no violations — it won't error.

## Not all views have data

In many CDF data models, **not every view has instances**. Some views may show 0 instances (e.g. ORCCertificate, RegattaEntry, Race, Regatta) because that data simply isn’t loaded yet or doesn’t exist in that space.

When a rule targets a view that has **zero instances** in the loaded graph:

- The rule is still evaluated, but there are **no nodes** of that type to validate.
- You get **no violations** for that rule (there is nothing to fail).
- With verbose output, you see the **[WARNING] Some rules target a class that has no instances** message for that target class.

It’s normal to have rules for views with no data. Leave those rules in place; they will start reporting violations once instances exist. To silence warnings for known-empty views in your environment, remove or comment out the corresponding shapes.

!!! note "Troubleshooting unexpected zero violations"
    If a rule never produces violations when you expect it to, check three things:

    1. The shape targets a concrete view type, not an interface.
    2. Instances exist in the space and version you configured.
    3. The `auto_load_depth` is high enough to load properties used in the rule.

    Run with `print_output=True` and `verbose=True` to see per-instance results and any zero-instance class warnings.
