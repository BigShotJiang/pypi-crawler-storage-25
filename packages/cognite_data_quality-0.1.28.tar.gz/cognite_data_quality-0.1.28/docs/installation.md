# Installation

## Local / Notebook / Script (Python 3.10+)

From PyPI:

```bash
pip install cognite-data-quality
```

In a notebook:

```python
%pip install cognite-data-quality
```

After install, **restart the kernel or interpreter** so imports pick up the package. The package inlines SHACL validation code — no external dependencies required.

## Embedded function code

Function handler code is **embedded in the package**. There is no separate `function/` directory or `function_source_root` parameter. When you deploy with `deploy_validation_infrastructure()`, the function zip is built from `cognite_data_quality._function_code` automatically. You do not need to clone or copy handler code elsewhere.

To confirm embedded files are present:

```python
from cognite_data_quality.deploy import _get_embedded_function_files

embedded = _get_embedded_function_files()
print(f"Embedded function files: {len(embedded)}")
```

## Cognite Function (deployed in CDF)

When the validation runs inside a Cognite Function, dependencies are declared in the function’s `requirements.txt` (folder deploy) or via `[requirements]` tags in the handler (function_handle deploy). The deployment process that uses `deploy_validation_infrastructure()` builds the function bundle from the package and includes the correct dependencies.

If you deploy a custom function that uses this package, list it in requirements:

```text
cognite-data-quality
```

See [Deploy](usage/deploy.md) for full deployment examples and [Runtime options](usage/runtime_options.md) for usage contexts.
