"""Quick local smoke-test: read DataProducts and RuleSets from cog-ai.

Run from the test_and_deploy/ directory:

    uv run python test_dataproduct_read.py

Tests (read-only, no writes):
  1. List all DataProducts
  2. List versions for each, pick latest RELEASED
  3. Fetch quality rule refs from version
  4. Fetch each referenced RuleSet version and show rule lengths
  5. Call load_views_from_data_product() to build ViewConfigs
  6. Call handle_data_product_sync() in dry-run (read state, skip deploy)
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running from repo root or test_and_deploy/
REPO_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(REPO_ROOT))

import cognite_data_quality
from cognite_data_quality import DataProductClient, RuleSetClient
from cognite_data_quality._dataproduct_loader import load_views_from_data_product
from cognite_data_quality._function_code.handlers.data_product_sync import (
    _load_settings_from_dms,
    _load_sync_state,
    _pick_latest_released,
)

TOML_PATH = Path(__file__).parent / "cog-ai.toml"


def hr(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print("=" * 60)


def main() -> None:
    # ------------------------------------------------------------------ setup
    assert TOML_PATH.exists(), f"cog-ai.toml not found at {TOML_PATH}"
    client = cognite_data_quality.load_cognite_client_from_toml(str(TOML_PATH))
    print(f"Connected: {client.config.project} @ {client.config.base_url}")

    space = "dataQuality"

    # --------------------------------------------------- 1. list DataProducts
    hr("1. List all DataProducts")
    dps = DataProductClient.list_all(client)
    print(f"Found {len(dps)} DataProduct(s)")
    for dp in dps:
        print(f"  • {dp['externalId']}  name={dp.get('name', '-')}")

    if not dps:
        print("No DataProducts — nothing else to test.")
        return

    # --------------------------------------------------- 2. list versions
    hr("2. Versions per DataProduct")
    for dp in dps:
        dp_id = dp["externalId"]
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        status_str = f"latest RELEASED = {latest['version']}" if latest else "no RELEASED version"
        print(f"  {dp_id}: {len(versions)} version(s), {status_str}")

        if latest:
            quality = (latest.get("quality") or {})
            rules = quality.get("rules", [])
            views = latest.get("views", [])
            print(f"    views={len(views)}  quality.rules={len(rules)}")

    # --------------------------------------------------- 3. quality rules
    hr("3. Quality rule references")
    for dp in dps:
        dp_id = dp["externalId"]
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        if not latest:
            continue
        rules = (latest.get("quality") or {}).get("rules", [])
        if not rules:
            print(f"  {dp_id}: no quality rules")
            continue
        print(f"  {dp_id} v{latest['version']}:")
        for ref in rules:
            print(f"    ruleset={ref['externalId']}  version={ref['version']}")

    # --------------------------------------------------- 4. fetch RuleSet versions
    hr("4. Fetch RuleSet version content")
    seen_refs: set[tuple[str, str]] = set()
    for dp in dps:
        dp_id = dp["externalId"]
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        if not latest:
            continue
        for ref in (latest.get("quality") or {}).get("rules", []):
            key = (ref["externalId"], ref["version"])
            if key in seen_refs:
                continue
            seen_refs.add(key)
            try:
                rv = RuleSetClient.get_version(client, ref["externalId"], ref["version"])
                rule_chunks = rv.get("rules", [])
                total_chars = sum(len(r) for r in rule_chunks)
                print(f"  {ref['externalId']}@{ref['version']}: {len(rule_chunks)} chunk(s), {total_chars} chars total")
            except Exception as exc:
                print(f"  {ref['externalId']}@{ref['version']}: ERROR — {exc}")

    # --------------------------------------------------- 5. build ViewConfigs
    hr("5. Build ViewConfigs via load_views_from_data_product()")
    for dp in dps:
        dp_id = dp["externalId"]
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        if not latest:
            continue
        rules = (latest.get("quality") or {}).get("rules", [])
        if not rules:
            continue
        try:
            configs = load_views_from_data_product(client, dp_id, latest["version"], version_data=latest)
            print(f"  {dp_id}: {len(configs)} ViewConfig(s)")
            for vc in configs:
                print(f"    view={vc.view.space}/{vc.view.external_id}@{vc.view.version}  spaces={vc.instance_spaces}")
        except Exception as exc:
            print(f"  {dp_id}: ERROR — {exc}")

    # --------------------------------------------------- 6. DMS state
    hr("6. DMS deployment settings + sync state")
    dms_props = _load_settings_from_dms(client, space)
    if dms_props:
        print(f"  DataQualitySettings found: {list(dms_props.keys())}")
    else:
        print("  No DataQualitySettings in DMS (deploy_validation_infrastructure() not yet run)")

    for dp in dps:
        dp_id = dp["externalId"]
        versions = DataProductClient.list_versions(client, dp_id)
        latest = _pick_latest_released(versions)
        if not latest:
            continue
        state = _load_sync_state(client, space, dp_id)
        last = state.get("last_processed_version", "—")
        print(f"  {dp_id}: last_processed_version={last}")

    hr("Done — all reads succeeded")


if __name__ == "__main__":
    main()
