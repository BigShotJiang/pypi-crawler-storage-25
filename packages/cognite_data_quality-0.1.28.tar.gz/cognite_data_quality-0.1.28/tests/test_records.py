from __future__ import annotations

from cognite_data_quality._records import RecordsConfig, Violation, build_records, parse_focus_node_uri


def test_parse_focus_node_uri_simple() -> None:
    """Simple format: namespace_base + space + '/' + external_id (no 'space/' prefix)."""
    base = "http://purl.org/cognite/"
    assert parse_focus_node_uri(f"{base}sp/inst1", base) == ("sp", "inst1")
    assert parse_focus_node_uri(f"{base}mySpace/someExternalId", base) == ("mySpace", "someExternalId")


def test_parse_focus_node_uri_neat_format() -> None:
    """Neat format: namespace_base + 'space/' + instance_space + '#' + urlencoded(external_id)."""
    base = "http://purl.org/cognite/"
    uri = f"{base}space/sailboat#boat%3A%3A257553460"
    assert parse_focus_node_uri(uri, base) == ("sailboat", "boat::257553460")
    assert parse_focus_node_uri(f"{base}space/mySpace#id%2Fwith%2Fslashes", base) == (
        "mySpace",
        "id/with/slashes",
    )


def test_parse_focus_node_uri_invalid() -> None:
    base = "http://purl.org/cognite/"
    assert parse_focus_node_uri("", base) is None
    assert parse_focus_node_uri("http://other/space/x", base) is None
    assert parse_focus_node_uri(f"{base}space/no_hash", base) is None


def test_build_records_with_violation() -> None:
    instances = [{"space": "sp", "externalId": "inst1"}]
    violations = [
        Violation(
            focusNode="http://purl.org/cognite/sp/inst1",
            resultMessage="Missing field",
            resultSeverity="Violation",
            sourceConstraintComponent="sh:MaxCountConstraintComponent",
            resultPath="prop",
        )
    ]
    records_config = RecordsConfig(rule_set_id="Set", rule_set_version="1.0")

    items = build_records(
        instances,
        violations,
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert len(items) == 1
    properties = items[0]["sources"][0]["properties"]
    assert properties["ruleSetId"] == "Set"
    assert properties["failedConstraints"]


def test_build_records_with_warning_severity() -> None:
    instances = [{"space": "sp", "externalId": "inst1"}]
    violations = [
        Violation(
            focusNode="http://purl.org/cognite/sp/inst1",
            resultMessage="Warning message",
            resultSeverity="http://www.w3.org/ns/shacl#Warning",
            sourceConstraintComponent="sh:MaxCountConstraintComponent",
        )
    ]
    records_config = RecordsConfig(rule_set_id="Set", rule_set_version="1.0")

    items = build_records(
        instances,
        violations,
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    properties = items[0]["sources"][0]["properties"]
    assert properties["resultSeverity"] == ["Warning"]


def test_build_records_without_violations() -> None:
    instances = [{"space": "sp", "externalId": "inst1"}]
    records_config = RecordsConfig(rule_set_id="Set", rule_set_version="1.0")

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    properties = items[0]["sources"][0]["properties"]
    assert properties["passedValidation"] is True
    assert properties["validationReport"]["violationCount"] == 0


def test_build_records_record_space_override() -> None:
    """record_space controls where records land; container source space stays as records_space."""
    instances = [{"space": "sp_valhall", "externalId": "tag001"}]
    records_config = RecordsConfig(
        rule_set_id="Set",
        rule_set_version="1.0",
        records_space="dataQuality",
        record_space="my_custom_space",
    )

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert items[0]["space"] == "my_custom_space"
    assert items[0]["sources"][0]["source"]["space"] == "dataQuality"


def test_build_records_use_instance_space() -> None:
    """When use_instance_space=True, record node space equals the instance space."""
    instances = [{"space": "sp_valhall", "externalId": "tag001"}]
    records_config = RecordsConfig(
        rule_set_id="Set",
        rule_set_version="1.0",
        records_space="dataQuality",
        use_instance_space=True,
    )

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert items[0]["space"] == "sp_valhall"
    # Container reference must still point to the fixed container space
    assert items[0]["sources"][0]["source"]["space"] == "dataQuality"


def test_build_records_use_instance_space_false_uses_records_space() -> None:
    """When use_instance_space=False (default), record node space is records_space."""
    instances = [{"space": "sp_valhall", "externalId": "tag001"}]
    records_config = RecordsConfig(
        rule_set_id="Set",
        rule_set_version="1.0",
        records_space="dataQuality",
        use_instance_space=False,
    )

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert items[0]["space"] == "dataQuality"
    assert items[0]["sources"][0]["source"]["space"] == "dataQuality"


def test_build_records_use_instance_space_fallback_for_raw() -> None:
    """When use_instance_space=True but instance has no space (RAW rows), fall back to records_space."""
    instances = [{"space": "", "externalId": "row_key_001"}]
    records_config = RecordsConfig(
        rule_set_id="Set",
        rule_set_version="1.0",
        records_space="dataQuality",
        use_instance_space=True,
    )

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert items[0]["space"] == "dataQuality"


def test_build_records_use_instance_space_multiple_instances() -> None:
    """Each record gets its own instance space when use_instance_space=True."""
    instances = [
        {"space": "sp_alvheim", "externalId": "tag_a"},
        {"space": "sp_valhall", "externalId": "tag_b"},
    ]
    records_config = RecordsConfig(
        rule_set_id="Set",
        rule_set_version="1.0",
        records_space="dataQuality",
        use_instance_space=True,
    )

    items = build_records(
        instances,
        [],
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert len(items) == 2
    spaces_by_eid = {item["externalId"]: item["space"] for item in items}
    assert spaces_by_eid["dq_Set_tag_a_job1"] == "sp_alvheim"
    assert spaces_by_eid["dq_Set_tag_b_job1"] == "sp_valhall"
    # Container source space is always fixed
    for item in items:
        assert item["sources"][0]["source"]["space"] == "dataQuality"


def test_build_records_neat_format_focus_node() -> None:
    """Violations with neat-format focusNode match instances by (space, externalId)."""
    instances = [{"space": "sailboat", "externalId": "boat::257553460"}]
    violations = [
        Violation(
            focusNode="http://purl.org/cognite/space/sailboat#boat%3A%3A257553460",
            resultMessage="Missing field",
            resultSeverity="Violation",
            sourceConstraintComponent="sh:MaxCountConstraintComponent",
        )
    ]
    records_config = RecordsConfig(rule_set_id="Set", rule_set_version="1.0")

    items = build_records(
        instances,
        violations,
        job_run_id="job1",
        records_config=records_config,
        namespace_base="http://purl.org/cognite/",
    )

    assert len(items) == 1
    properties = items[0]["sources"][0]["properties"]
    assert properties["focusNodeInstance"] == {"space": "sailboat", "externalId": "boat::257553460"}
    assert properties["failedConstraints"]
    assert not properties["passedValidation"]
