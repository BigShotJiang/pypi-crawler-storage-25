"""
Tests for function handler routing.

Verifies that the main handler correctly routes requests to appropriate sub-handlers
based on validation_type parameter.
"""

from __future__ import annotations

from unittest.mock import Mock, patch


class TestHandlerRouting:
    """Test main handler routes requests correctly."""

    def test_route_to_instance_validation(self) -> None:
        """Test routing to instance validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "instance"}

        with patch("cognite_data_quality._function_code.handler.handle_instance_validation") as mock_handler:
            mock_handler.return_value = {"status": "success"}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["status"] == "success"

    def test_route_to_instance_sync_cursor(self) -> None:
        """Test routing to instance sync cursor validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "instance_sync_cursor"}

        with patch(
            "cognite_data_quality._function_code.handler.handle_instance_sync_cursor_validation"
        ) as mock_handler:
            mock_handler.return_value = {"status": "completed"}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["status"] == "completed"

    def test_route_to_raw_incremental(self) -> None:
        """Test routing to RAW incremental validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "raw_incremental"}

        with patch("cognite_data_quality._function_code.handler.handle_raw_validation_incremental") as mock_handler:
            mock_handler.return_value = {"conforms": True}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["conforms"] is True

    def test_route_to_raw_historic(self) -> None:
        """Test routing to RAW historic validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "raw_historic"}

        with patch("cognite_data_quality._function_code.handler.handle_raw_validation_historic") as mock_handler:
            mock_handler.return_value = {"completed": True}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["completed"] is True

    def test_missing_validation_type(self) -> None:
        """Test error handling when validation_type is missing."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data: dict = {}  # Missing validation_type

        result = handle(data, mock_client)

        assert result["status"] == "error"
        assert "Missing required parameter: validation_type" in result["error"]
        assert "raw_incremental" in result["valid_types"]
        assert "raw_historic" in result["valid_types"]

    def test_unknown_validation_type(self) -> None:
        """Test error handling for unknown validation type."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "unknown_type"}

        result = handle(data, mock_client)

        assert result["status"] == "error"
        assert "Unknown validation_type" in result["error"]
        assert "unknown_type" in result["error"]
        assert "raw_incremental" in result["valid_types"]
        assert "raw_historic" in result["valid_types"]

    def test_route_to_orchestrator(self) -> None:
        """Test routing to orchestrator handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        secrets = {"api_key": "test_key"}
        data = {"validation_type": "orchestrator"}

        with patch("cognite_data_quality._function_code.handler.handle_orchestrator") as mock_handler:
            mock_handler.return_value = {"status": "orchestration_started"}
            result = handle(data, mock_client, secrets)

        # Verify secrets are passed to orchestrator
        mock_handler.assert_called_once_with(data, mock_client, secrets)
        assert result["status"] == "orchestration_started"

    def test_route_to_partitioned(self) -> None:
        """Test routing to partitioned validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "partitioned"}

        with patch("cognite_data_quality._function_code.handler.handle_partitioned_validation") as mock_handler:
            mock_handler.return_value = {"completed": True}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["completed"] is True

    def test_route_to_timeseries(self) -> None:
        """Test routing to timeseries validation handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "timeseries"}

        with patch("cognite_data_quality._function_code.handler.handle_timeseries_validation") as mock_handler:
            mock_handler.return_value = {"conforms": True}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["conforms"] is True

    def test_route_to_test_rule(self) -> None:
        """Test routing to test rule handler."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data = {"validation_type": "test"}

        with patch("cognite_data_quality._function_code.handler.handle_test_rule") as mock_handler:
            mock_handler.return_value = {"test_result": "pass"}
            result = handle(data, mock_client)

        mock_handler.assert_called_once_with(data, mock_client)
        assert result["test_result"] == "pass"

    def test_all_validation_types_listed_in_error(self) -> None:
        """Test that error messages list all available validation types."""
        from cognite_data_quality._function_code.handler import handle

        mock_client = Mock()
        data: dict = {}  # Missing validation_type

        result = handle(data, mock_client)

        # Verify all validation types are listed
        expected_types = [
            "instance",
            "instance_sync_cursor",
            "partitioned",
            "timeseries",
            "orchestrator",
            "test",
            "raw_incremental",
            "raw_historic",
        ]

        for validation_type in expected_types:
            assert validation_type in result["valid_types"]
