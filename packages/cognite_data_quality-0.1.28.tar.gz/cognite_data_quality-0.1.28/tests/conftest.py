from __future__ import annotations

from pathlib import Path

import pytest
from cognite_data_quality._config import DataModelConfig


@pytest.fixture()
def datamodel_config() -> DataModelConfig:
    return DataModelConfig(space="sp", external_id="Model", version="v1")


@pytest.fixture()
def tmp_rules_dir(tmp_path: Path) -> Path:
    rules_dir = tmp_path / "rules"
    rules_dir.mkdir()
    return rules_dir


@pytest.fixture()
def sample_instances() -> list[dict[str, str]]:
    return [
        {"space": "sp", "externalId": "a"},
        {"space": "sp", "externalId": "b"},
    ]


@pytest.fixture()
def cognite_client():
    pytest.skip("Integration test requires real Cognite credentials")
