from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from typing import Any, Callable

from runtime_sdk.client import RuntimeAPIError, RuntimeClient
from runtime_sdk.config import (
    DEFAULT_BASE_URL,
    PendingSignup,
    RuntimeConfig,
    RuntimeConfigError,
    load_config,
    save_config,
)


# --------------------------------------------------------------------------- #
# TTY detection + lazy rich/questionary imports                               #
# --------------------------------------------------------------------------- #


def _interactive() -> bool:
    """True when we have a real terminal on both ends — enables fancy UI."""
    if os.environ.get("RUNTIME_NO_TTY"):
        return False
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


SPINNER = "aesthetic"  # unicode ▰▱ progress-bar style; single place to tweak.


def _with_spinner(label: str, fn: Callable[[], Any]) -> Any:
    """Run fn(), wrapped in a rich spinner when interactive."""
    if not _interactive():
        return fn()
    with _UI.console().status(f"[cyan]{label}[/cyan]", spinner=SPINNER):
        return fn()


class _UI:
    """Lazy holder for rich + questionary so non-TTY paths stay import-cheap."""

    _console: Any = None
    _err_console: Any = None
    _questionary: Any = None
    _questionary_style: Any = None
    _rich_mods: dict[str, Any] | None = None

    @classmethod
    def console(cls) -> Any:
        if cls._console is None:
            from rich.console import Console

            cls._console = Console()
        return cls._console

    @classmethod
    def err(cls) -> Any:
        if cls._err_console is None:
            from rich.console import Console

            cls._err_console = Console(stderr=True)
        return cls._err_console

    @classmethod
    def q(cls) -> Any:
        if cls._questionary is None:
            import questionary

            cls._questionary = questionary
        return cls._questionary

    @classmethod
    def style(cls) -> Any:
        if cls._questionary_style is None:
            cls._questionary_style = cls.q().Style(
                [
                    ("qmark", "fg:#22c55e bold"),
                    ("question", "bold fg:#e5e7eb"),
                    ("answer", "fg:#22c55e bold"),
                    ("pointer", "fg:#60a5fa bold"),
                    ("highlighted", "fg:#ffffff bg:#1f2937 bold"),
                    ("selected", "fg:#22c55e bold"),
                    ("separator", "fg:#4b5563"),
                    ("instruction", "fg:#94a3b8 italic"),
                    ("text", "fg:#d1d5db"),
                    ("disabled", "fg:#6b7280 italic"),
                ]
            )
        return cls._questionary_style

    @classmethod
    def rich(cls) -> dict[str, Any]:
        if cls._rich_mods is None:
            from rich.panel import Panel
            from rich.text import Text

            cls._rich_mods = {"Panel": Panel, "Text": Text}
        return cls._rich_mods


# --------------------------------------------------------------------------- #
# argparse                                                                    #
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="runtime")
    parser.add_argument("--base-url", help="Runtime API base URL")

    # Subcommand is optional: bare `runtime` defaults to `create`.
    subparsers = parser.add_subparsers(dest="command", required=False)

    signup = subparsers.add_parser("signup", help="Send an email verification code")
    signup.add_argument("email", nargs="?", default=None)
    signup.add_argument("--name", default=None)

    verify = subparsers.add_parser("verify", help="Verify an emailed code and save a fresh API key")
    verify.add_argument("code", nargs="?", default=None)
    verify.add_argument("--flow-id", type=int)

    login = subparsers.add_parser("login", help="Start email login or import an API key")
    login.add_argument(
        "identifier",
        nargs="?",
        default=None,
        help="Email address to send a code to, or an API key for backwards compatibility",
    )
    login.add_argument("--name", default=None, help="Optional display name for first-time email signup")
    login.add_argument(
        "--api-key",
        nargs="?",
        const="",
        default=None,
        help="Import an API key explicitly (prompts if omitted in interactive mode)",
    )

    subparsers.add_parser("whoami")
    subparsers.add_parser("logout")

    create_cmd = subparsers.add_parser("create", help="Create a new computer")
    create_cmd.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Subdomain name (e.g. redsox → redsox.runruntime.dev). Random if skipped.",
    )
    create_cmd.add_argument("--command", dest="startup_command", help="App startup command to run after create")
    create_cmd.add_argument("--cwd", help="Working directory for the startup command")
    create_cmd.add_argument("--port", type=int, help="App port to publish after startup")
    subparsers.add_parser("list", aliases=["ls"], help="List computers")

    info_cmd = subparsers.add_parser("info", help="Get computer details")
    info_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    delete_cmd = subparsers.add_parser("delete", aliases=["rm"], help="Delete a computer")
    delete_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    run_cmd = subparsers.add_parser("run", help="Run a command in a computer")
    run_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    run_cmd.add_argument(
        "run_command",
        metavar="command",
        nargs="?",
        default=None,
        help="Command to run",
    )
    run_cmd.add_argument("--uid", type=int, help="User ID")
    run_cmd.add_argument("--gid", type=int, help="Group ID")
    run_cmd.add_argument("--cwd", help="Working directory")
    run_cmd.add_argument("--shell", help="Shell to use")

    publish_cmd = subparsers.add_parser(
        "publish", help="Pin the public URL to a local app port"
    )
    publish_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    publish_cmd.add_argument("port", nargs="?", type=int, default=None, help="Local app port")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # Bare `runtime` → create flow.
    if args.command is None:
        args.command = "create"
        args.name = None

    try:
        config = load_config()
        base_url = (
            args.base_url
            or os.environ.get("RUNTIME_BASE_URL")
            or config.base_url
            or DEFAULT_BASE_URL
        )
        config.base_url = base_url

        if args.command == "signup":
            return handle_signup(config, args.email, args.name)
        if args.command == "verify":
            return handle_verify(config, args.code, args.flow_id)
        if args.command == "login":
            return handle_login(config, args.identifier, args.name, args.api_key)
        if args.command == "whoami":
            return handle_whoami(config)
        if args.command == "logout":
            return handle_logout(config)
        if args.command == "create":
            return handle_create(
                config,
                args.name,
                getattr(args, "startup_command", None),
                getattr(args, "cwd", None),
                getattr(args, "port", None),
            )
        if args.command in ("list", "ls"):
            return handle_list(config)
        if args.command == "info":
            return handle_info(config, args.id)
        if args.command in ("delete", "rm"):
            return handle_delete(config, args.id)
        if args.command == "run":
            return handle_run(
                config, args.id, args.run_command, args.uid, args.gid, args.cwd, args.shell
            )
        if args.command == "publish":
            return handle_publish(config, args.id, args.port)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except RuntimeConfigError as exc:
        return report_error(str(exc))
    except KeyboardInterrupt:
        if _interactive():
            UI = _UI.err()
            UI.print("\n[dim]cancelled[/dim]")
            return 130
        return report_error("cancelled")

    return report_error("unknown command")


# --------------------------------------------------------------------------- #
# Shared helpers                                                              #
# --------------------------------------------------------------------------- #


def write_json(payload: dict[str, Any], *, error: bool = False) -> int:
    stream = sys.stderr if error else sys.stdout
    stream.write(json.dumps(payload) + "\n")
    return 1 if error else 0


def report_error(message: str, *, status_code: int | None = None) -> int:
    """Error output — JSON in non-TTY mode, rich in TTY mode."""
    if _interactive():
        err = _UI.err()
        suffix = f" [dim](http {status_code})[/dim]" if status_code is not None else ""
        err.print(f"[bold red]✗[/bold red] {message}{suffix}")
        return 1
    payload: dict[str, Any] = {"success": False, "error": message}
    if status_code is not None:
        payload["status_code"] = status_code
    return write_json(payload, error=True)


def report_success(payload: dict[str, Any], renderer: Callable[[dict[str, Any]], None] | None = None) -> int:
    """Success output — rich renderer in TTY, JSON otherwise."""
    if _interactive() and renderer is not None:
        renderer(payload)
        return 0
    return write_json({"success": True, **payload})


def _require_api_key(config: RuntimeConfig) -> int | None:
    if config.api_key:
        return None
    return report_error("missing api key; run login or verify first")


def _prompt_text(message: str, *, default: str | None = None) -> str | None:
    """Ask for a line of text. Returns None if the user left it blank.

    Ctrl-C propagates as KeyboardInterrupt, handled centrally by main().
    """
    answer = _UI.q().text(message, default=default or "").unsafe_ask()
    return answer.strip() or None


def _prompt_password(message: str) -> str | None:
    answer = _UI.q().password(message).unsafe_ask()
    return answer.strip() or None


def _prompt_confirm(message: str, *, default: bool = False) -> bool:
    return bool(_UI.q().confirm(message, default=default).unsafe_ask())


def _display_width(value: Any, minimum: int, maximum: int) -> int:
    text = str(value or "")
    return max(minimum, min(len(text), maximum))


def _fit_cell(value: Any, width: int) -> str:
    text = str(value or "")
    if width <= 0:
        return ""
    if len(text) > width:
        if width == 1:
            return "…"
        text = text[: width - 1] + "…"
    return text.ljust(width)


def _computer_table_layout(computers: list[dict[str, Any]]) -> dict[str, int]:
    term_width = shutil.get_terminal_size((100, 20)).columns
    slug_width = max(
        _display_width(c.get("slug") or c.get("id") or "?", len("slug"), 24)
        for c in computers
    )
    status_width = max(
        _display_width(c.get("status") or "?", len("status"), 12)
        for c in computers
    )
    created_width = max(
        _display_width(c.get("created_at") or "", len("created"), 20)
        for c in computers
    )
    reserved = slug_width + status_width + created_width + len("  ") * 3
    url_budget = max(20, term_width - reserved)
    url_width = max(
        len("public url"),
        min(max(len(str(c.get("public_url") or "")) for c in computers), url_budget),
    )
    return {
        "slug": slug_width,
        "status": status_width,
        "public_url": url_width,
        "created_at": created_width,
    }


def _format_computer_row(c: dict[str, Any], widths: dict[str, int]) -> str:
    return " │ ".join(
        [
            _fit_cell(c.get("slug") or c.get("id") or "?", widths["slug"]),
            _fit_cell(c.get("status") or "?", widths["status"]),
            _fit_cell(c.get("public_url") or "", widths["public_url"]),
            _fit_cell(c.get("created_at") or "", widths["created_at"]),
        ]
    )


def _computer_table_prompt(prompt: str, computers: list[dict[str, Any]]) -> tuple[str, dict[str, int]]:
    widths = _computer_table_layout(computers)
    header = " │ ".join(
        [
            _fit_cell("slug", widths["slug"]),
            _fit_cell("status", widths["status"]),
            _fit_cell("public url", widths["public_url"]),
            _fit_cell("created", widths["created_at"]),
        ]
    )
    divider = "─" * len(header)
    return f"{prompt}\n{header}\n{divider}", widths


def _render_computer_summary(computers: list[dict[str, Any]]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    counts: dict[str, int] = {}
    for computer in computers:
        status = str(computer.get("status") or "unknown")
        counts[status] = counts.get(status, 0) + 1

    body = Text()
    body.append(f"total {len(computers)}", style="bold white")
    if counts:
        body.append("   ")
    first = True
    status_styles = {
        "running": "bold green",
        "cold": "bold cyan",
        "archiving": "bold yellow",
        "restoring": "bold yellow",
        "creating": "bold magenta",
        "orphaned": "bold red",
    }
    for status in sorted(counts):
        if not first:
            body.append("  •  ", style="dim")
        first = False
        body.append(status, style=status_styles.get(status, "bold white"))
        body.append(f" {counts[status]}", style="white")

    _UI.console().print(
        Panel(body, title="runtime", border_style="blue", expand=False, padding=(0, 1))
    )


def _select_prompt(message: str, choices: list[Any]) -> Any:
    return _UI.q().select(
        message,
        choices=choices,
        qmark="●",
        pointer="❯",
        instruction="↑/↓ move • Enter select • j/k also work",
        use_indicator=True,
        style=_UI.style(),
    )


def _pick_computer(config: RuntimeConfig, prompt: str) -> dict[str, Any] | None:
    """Fetch computers and let the user arrow-key through them.

    Returns the picked computer dict, or None if the list is empty or the user
    explicitly chose "← cancel". Ctrl-C propagates as KeyboardInterrupt.
    """
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = client.list_computers()
    computers = payload.get("computers") or []
    if not isinstance(computers, list) or not computers:
        _UI.err().print("[yellow]no computers found[/yellow]")
        return None

    questionary = _UI.q()
    message, widths = _computer_table_prompt(prompt, computers)
    choices = [
        questionary.Choice(title=_format_computer_row(c, widths), value=c) for c in computers
    ]
    choices.append(questionary.Choice(title="← cancel", value=None))
    picked = _select_prompt(message, choices).unsafe_ask()
    return picked if isinstance(picked, dict) else None


# --------------------------------------------------------------------------- #
# Rich renderers                                                              #
# --------------------------------------------------------------------------- #


def _render_computer_panel(c: dict[str, Any], *, title: str = "computer") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    for key in ("id", "slug", "status", "public_url", "created_at"):
        if key in c and c[key] is not None:
            body.append(f"{key:<12}", style="dim")
            body.append(f"{c[key]}\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False))


def _render_run_result(result: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel = mods["Panel"]
    console = _UI.console()
    stdout = result.get("stdout") or ""
    stderr = result.get("stderr") or ""
    exit_code = result.get("exit_code")
    if stdout:
        console.print(Panel(stdout.rstrip(), title="stdout", border_style="green", expand=False))
    if stderr:
        console.print(Panel(stderr.rstrip(), title="stderr", border_style="red", expand=False))
    color = "green" if exit_code == 0 else "red"
    console.print(f"[{color}]exit {exit_code}[/{color}]")


def _render_whoami_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    owner = payload.get("owner") or {}
    rows: list[tuple[str, Any]] = [
        ("email", owner.get("email")),
        ("name", owner.get("name")),
        ("account id", payload.get("account_id")),
        ("trust tier", payload.get("trust_tier")),
    ]
    body = Text()
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    _UI.console().print(Panel(body, title="whoami", border_style="cyan", expand=False))


# --------------------------------------------------------------------------- #
# Command handlers                                                            #
# --------------------------------------------------------------------------- #


def _looks_like_api_key(value: str | None) -> bool:
    candidate = (value or "").strip()
    return candidate.startswith("rt_live_")


def _start_verification_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if email is None:
        if not _interactive():
            return report_error("email is required")
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.start_verification(email, name)
    config.pending_signup = PendingSignup(
        flow_id=int(result["flow_id"]),
        email=email,
        expires_at=result.get("expires_at"),
    )
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
        )
        _UI.console().print(
            f"[dim]then run:[/dim] runtime verify <code>"
        )

    return report_success(result, render)


def _login_with_api_key(config: RuntimeConfig, api_key: str | None) -> int:
    if api_key is None or api_key == "":
        if not _interactive():
            return report_error("api key is required")
        api_key = _prompt_password("API key")
        if not api_key:
            return report_error("api key is required")

    client = RuntimeClient(base_url=config.base_url, api_key=api_key)
    whoami = client.whoami()
    config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(_: dict[str, Any]) -> None:
        owner = whoami.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] api key saved")

    return report_success({"message": "logged in", **whoami}, render)


def handle_signup(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    return _start_verification_flow(config, email, name)


def handle_verify(config: RuntimeConfig, code: str | None, flow_id: int | None) -> int:
    pending = config.pending_signup
    resolved_flow_id = flow_id or (pending.flow_id if pending else None)
    if not resolved_flow_id:
        return report_error("missing flow id; run login first or pass --flow-id")

    if code is None:
        if not _interactive():
            return report_error("verification code is required")
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.verify(resolved_flow_id, code)
    api_key = result.get("api_key")
    if api_key:
        config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        owner = payload.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] verified, logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] verified, api key saved")

    return report_success(result, render)


def handle_login(
    config: RuntimeConfig,
    identifier: str | None,
    name: str | None,
    api_key: str | None,
) -> int:
    if api_key is not None:
        if identifier is not None:
            return report_error("pass either an email/api key argument or --api-key, not both")
        return _login_with_api_key(config, api_key)

    if _looks_like_api_key(identifier):
        return _login_with_api_key(config, identifier)

    return _start_verification_flow(config, identifier, name)


def handle_whoami(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.whoami()
    return report_success(result, _render_whoami_panel)


def handle_logout(config: RuntimeConfig) -> int:
    had_api_key = config.api_key is not None
    revoked = False
    if config.api_key:
        try:
            RuntimeClient(base_url=config.base_url, api_key=config.api_key).logout()
            revoked = True
        except RuntimeAPIError:
            revoked = False

    config.api_key = None
    config.pending_signup = None
    save_config(config)

    message = "logged out"
    if had_api_key and not revoked:
        message = "logged out locally"

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] {message}")

    return report_success({"message": message}, render)


def handle_create(
    config: RuntimeConfig,
    name: str | None,
    startup_command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if name is None and _interactive():
        name = _prompt_text("Name your computer")

    if startup_command is None and port is not None:
        return report_error("startup command is required when port is provided")
    if startup_command is not None and port is None:
        return report_error("port is required when startup command is provided")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    label = "creating computer…"
    if startup_command is not None:
        label = f"creating computer and starting app on port {port}…"
    result = _with_spinner(
        label,
        lambda: client.create_computer(slug=name, command=startup_command, cwd=cwd, port=port),
    )

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="created")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    return report_success(result, render)


def handle_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if _interactive():
        return _interactive_list(config)

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_computers())


def handle_info(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.get_computer(computer_id)
    return report_success(result, lambda p: _render_computer_panel(p, title="computer"))


def handle_delete(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    interactive_pick = False
    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer to delete")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")
        interactive_pick = True

    if interactive_pick:
        if not _prompt_confirm(
            f"Delete {computer_id}? This cannot be undone.", default=False
        ):
            _UI.console().print("[dim]cancelled[/dim]")
            return 0

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    client.delete_computer(computer_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] deleted [bold]{computer_id}[/bold]")

    return report_success({"message": f"computer {computer_id} deleted"}, render)


def handle_run(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    uid: int | None,
    gid: int | None,
    cwd: str | None,
    shell: str | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if command is None:
        if not _interactive():
            return report_error("command is required")
        command = _prompt_text("Command to run")
        if not command:
            return report_error("command is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = _with_spinner(
        f"running on {computer_id}…",
        lambda: client.run_command(
            computer_id, command, uid=uid, gid=gid, cwd=cwd, shell=shell
        ),
    )
    return report_success(result, _render_run_result)


def handle_publish(config: RuntimeConfig, computer_id: str | None, port: int | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if port is None:
        if not _interactive():
            return report_error("port is required")
        port_text = _prompt_text("Port to publish", default="3000")
        if not port_text:
            return report_error("port is required")
        try:
            port = int(port_text)
        except ValueError:
            return report_error("port must be a number")

    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    _with_spinner(
        f"publishing port {port} on {computer_id}…",
        lambda: client.publish_port(computer_id, port),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] public url for [bold]{computer_id}[/bold] pinned to [bold]{port}[/bold]"
        )

    return report_success(
        {
            "message": f"computer {computer_id} published port {port}",
            "computer_id": computer_id,
            "port": port,
        },
        render,
    )


# --------------------------------------------------------------------------- #
# Interactive list → detail → action loop                                    #
# --------------------------------------------------------------------------- #


def _interactive_list(config: RuntimeConfig) -> int:
    """Nested menu: table → pick VM → action → back."""
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    questionary = _UI.q()

    while True:
        payload = _with_spinner("fetching computers…", client.list_computers)
        computers = payload.get("computers") or []
        if not isinstance(computers, list):
            computers = []

        if not computers:
            _UI.console().print("[dim]no computers yet. create one with `runtime create`.[/dim]")
            return 0

        _render_computer_summary(computers)
        message, widths = _computer_table_prompt("Pick a computer", computers)
        choices = [
            questionary.Choice(title=_format_computer_row(c, widths), value=c)
            for c in computers
        ]
        choices.append(questionary.Separator())
        choices.append(questionary.Choice(title="↻ refresh", value="__refresh__"))
        choices.append(questionary.Choice(title="✕ quit", value="__quit__"))

        picked = _select_prompt(message, choices).unsafe_ask()

        if picked == "__quit__":
            return 0
        if picked == "__refresh__":
            continue
        if not isinstance(picked, dict):
            continue

        action = _vm_detail_menu(client, picked)
        if action == "__quit__":
            return 0
        # otherwise: loop and refresh the list


def _vm_detail_menu(client: RuntimeClient, vm: dict[str, Any]) -> str:
    """Action menu for a single VM. Returns '__back__' or '__quit__'."""
    questionary = _UI.q()
    vm_id = vm.get("id") or vm.get("slug") or "?"
    slug = vm.get("slug") or vm_id

    while True:
        _render_computer_panel(vm, title=f"computer: {slug}")

        action = _select_prompt(
            f"What would you like to do with {slug}?",
            [
                questionary.Choice(title="▶ run a command", value="run"),
                questionary.Choice(title="⤴ publish a port", value="publish"),
                questionary.Choice(title="ℹ refresh info", value="info"),
                questionary.Choice(title="⧉ copy public url", value="url"),
                questionary.Choice(title="✕ delete", value="delete"),
                questionary.Separator(),
                questionary.Choice(title="← back", value="__back__"),
                questionary.Choice(title="✕ quit", value="__quit__"),
            ],
        ).unsafe_ask()

        if action == "__back__":
            return "__back__"
        if action == "__quit__":
            return "__quit__"

        if action == "run":
            command = _prompt_text("Command to run")
            if not command:
                continue
            result = _with_spinner(
                f"running on {slug}…", lambda: client.run_command(vm_id, command)
            )
            _render_run_result(result)
            continue

        if action == "publish":
            port_text = _prompt_text("Port to publish", default="3000")
            if not port_text:
                continue
            try:
                port = int(port_text)
            except ValueError:
                _UI.err().print("[red]port must be a number[/red]")
                continue
            if port <= 0 or port > 65535:
                _UI.err().print("[red]port must be between 1 and 65535[/red]")
                continue
            _with_spinner(
                f"publishing port {port} on {slug}…",
                lambda: client.publish_port(vm_id, port),
            )
            _UI.console().print(
                f"[green]✓[/green] public url for [bold]{slug}[/bold] pinned to [bold]{port}[/bold]"
            )
            continue

        if action == "info":
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "url":
            url = vm.get("public_url") or ""
            if not url:
                _UI.console().print("[yellow]no public url on this computer[/yellow]")
                continue
            _UI.console().print(f"[cyan]{url}[/cyan]")
            continue

        if action == "delete":
            if not _prompt_confirm(
                f"Delete {slug}? This cannot be undone.", default=False
            ):
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            _with_spinner(f"deleting {slug}…", lambda: client.delete_computer(vm_id))
            _UI.console().print(f"[green]✓[/green] deleted [bold]{slug}[/bold]")
            return "__back__"


if __name__ == "__main__":
    raise SystemExit(main())
