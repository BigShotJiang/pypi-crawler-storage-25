import asyncio
from pathlib import Path
from typing import List, Union, Optional, Dict
import logging
import os
import tempfile

from llama_index.core import Document

logger = logging.getLogger(__name__)

def get_parser_type_from_env() -> str:
    """Get parser type from environment variable, defaulting to docling"""
    parser = os.getenv('DOCUMENT_PARSER', 'docling').lower()
    if parser not in ['docling', 'llamaparse']:
        logger.warning(f"Unknown DOCUMENT_PARSER value '{parser}', defaulting to 'docling'")
        return 'docling'
    return parser

class DocumentProcessor:
    """Handles document conversion using Docling or LlamaParse before LlamaIndex processing"""
    
    def __init__(self, config=None, parser_type: str = "docling"):
        """
        Initialize DocumentProcessor with configurable parser.
        
        Args:
            config: Configuration object with timeout and API key settings
            parser_type: "docling" or "llamaparse" - which parser to use
        """
        self.config = config
        self.parser_type = parser_type.lower()
        
        # Store configuration for timeouts
        if self.parser_type == "docling":
            self._init_docling()
        elif self.parser_type == "llamaparse":
            self._init_llamaparse()
        else:
            raise ValueError(f"Unknown parser type: {parser_type}. Must be 'docling' or 'llamaparse'")
        
        logger.info(f"DocumentProcessor initialized with {self.parser_type} parser")
    
    def _init_docling(self):
        """Initialize Docling parser with GPU/device configuration"""
        try:
            from docling.document_converter import DocumentConverter, PdfFormatOption
            from docling.datamodel.base_models import InputFormat
            from docling.datamodel.pipeline_options import PdfPipelineOptions, TableStructureOptions
            from docling.datamodel.accelerator_options import AcceleratorDevice, AcceleratorOptions
            
            # Get device configuration from environment or config
            # Options: "auto" (default - uses GPU if available), "cpu", "cuda", "mps" (Mac)
            device_str = os.getenv('DOCLING_DEVICE', 'auto')
            if self.config:
                device_str = getattr(self.config, 'docling_device', 'auto')
            
            # Map string to Docling's AcceleratorDevice enum
            device_mapping = {
                'auto': AcceleratorDevice.AUTO,
                'cpu': AcceleratorDevice.CPU,
                'cuda': AcceleratorDevice.CUDA,
                'mps': AcceleratorDevice.MPS,
            }
            
            accelerator_device = device_mapping.get(device_str.lower(), AcceleratorDevice.AUTO)
            logger.info(f"Docling device configuration: {device_str} -> {accelerator_device}")
            
            # Create accelerator options with device selection
            accelerator_options = AcceleratorOptions(
                num_threads=8,  # Reasonable default for parallel processing
                device=accelerator_device
            )
            
            # Configure Docling for optimal PDF processing
            pdf_options = PdfPipelineOptions(
                do_table_structure=True,
                do_picture_classification=True,
                do_formula_enrichment=True,
                table_structure_options=TableStructureOptions(
                    do_cell_matching=True
                ),
                accelerator_options=accelerator_options  # Apply device configuration
            )
            
            # Configure all supported Docling formats
            self.converter = DocumentConverter(
                allowed_formats=[
                    InputFormat.PDF,
                    InputFormat.DOCX, 
                    InputFormat.PPTX,
                    InputFormat.HTML,
                    InputFormat.IMAGE,
                    InputFormat.XLSX,
                    InputFormat.MD,
                    InputFormat.ASCIIDOC,
                    InputFormat.CSV
                ],
                format_options={
                    InputFormat.PDF: PdfFormatOption(pipeline_options=pdf_options)
                }
            )
            
            # Log device info
            try:
                import torch
                if torch.cuda.is_available():
                    device_name = torch.cuda.get_device_name(0)
                    logger.info(f"Docling converter initialized - CUDA available: {device_name}")
                elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                    logger.info("Docling converter initialized - MPS (Apple Metal) available")
                else:
                    logger.info("Docling converter initialized - Running on CPU")
            except ImportError:
                logger.info("Docling converter initialized - PyTorch not available, using CPU")
                
        except ImportError as e:
            logger.error(f"Failed to import Docling: {e}")
            raise ImportError("Please install docling: pip install docling")
    
    def _create_llamaparse_parser(self):
        """Create a fresh LlamaParse parser instance.
        
        This is needed because LlamaParse creates async locks/events that get bound
        to the event loop at creation time. If the event loop changes, we need a new instance.
        """
        from llama_parse import LlamaParse
        
        # Get API key from config or environment
        api_key = None
        if self.config:
            api_key = getattr(self.config, 'llamaparse_api_key', None)
        
        if not api_key:
            api_key = os.getenv('LLAMAPARSE_API_KEY')
        
        if not api_key:
            raise ValueError("LLAMAPARSE_API_KEY not found in config or environment variables")
        
        parse_mode = os.getenv('LLAMAPARSE_MODE', 'parse_page_with_llm')
        result_type = "json"
        
        parser_kwargs = {
            "api_key": api_key,
            "result_type": result_type,
            "verbose": True,
            "language": "en",
            "parse_mode": parse_mode,
            "show_progress": True
        }
        
        if parse_mode == "parse_page_with_agent":
            model_name = os.getenv('LLAMAPARSE_AGENT_MODEL', 'openai-gpt-4-1-mini')
            parser_kwargs["model"] = model_name
        
        return LlamaParse(**parser_kwargs)
    
    def _init_llamaparse(self):
        """Initialize LlamaParse parser"""
        try:
            # parse_page_without_llm only produces text, not markdown
            parse_mode = os.getenv('LLAMAPARSE_MODE', 'parse_page_with_llm')
            if parse_mode == "parse_page_without_llm":
                logger.warning("parse_page_without_llm only produces text, no markdown - will use plaintext in the pipeline")
            
            self.parser = self._create_llamaparse_parser()
            
            # Log initialization
            if parse_mode == "parse_page_with_agent":
                model_name = os.getenv('LLAMAPARSE_AGENT_MODEL', 'openai-gpt-4-1-mini')
                logger.info(f"LlamaParse parser initialized with parse_mode={parse_mode}, model={model_name}, result_type=json")
            else:
                logger.info(f"LlamaParse parser initialized with parse_mode={parse_mode}, result_type=json")
        except ImportError as e:
            logger.error(f"Failed to import LlamaParse: {e}")
            raise ImportError("Please install llama-parse: pip install llama-parse")
        except Exception as e:
            logger.error(f"Failed to initialize LlamaParse: {e}")
            raise
    
    async def _run_with_cancellation_checks(self, loop, func, check_cancellation, timeout=None):
        """Run a function in executor with periodic cancellation checks"""
        import asyncio
        import concurrent.futures
        
        # Use configured timeout and check interval, or defaults
        if timeout is None:
            timeout = self.config.docling_timeout if self.config else 300
        check_interval = self.config.docling_cancel_check_interval if self.config else 0.5
        
        # Submit the task to executor
        future = loop.run_in_executor(None, func)
        
        elapsed = 0
        
        while not future.done():
            try:
                # Wait for a short period or task completion
                await asyncio.wait_for(asyncio.shield(future), timeout=check_interval)
                break  # Task completed
            except asyncio.TimeoutError:
                # Check for cancellation
                if check_cancellation():
                    logger.info("Cancelling Docling conversion due to user request")
                    future.cancel()
                    raise RuntimeError("Processing cancelled by user")
                
                # Check for overall timeout
                elapsed += check_interval
                if elapsed >= timeout:
                    logger.warning(f"Docling conversion timeout after {timeout} seconds")
                    future.cancel()
                    raise concurrent.futures.TimeoutError()
        
        return await future
    
    async def process_documents(self, file_paths: List[Union[str, Path]], processing_id: str = None, original_metadata: Dict[str, Dict] = None) -> List[Document]:
        """Convert documents to markdown using selected parser, then create LlamaIndex Documents
        
        Args:
            file_paths: List of file paths to process
            processing_id: Optional processing ID for cancellation checks
            original_metadata: Optional dict mapping file paths to original metadata (e.g., from cloud sources)
        """
        documents = []
        
        # Helper function to check cancellation
        def _check_cancellation():
            if processing_id:
                try:
                    from backend import PROCESSING_STATUS
                    return (processing_id in PROCESSING_STATUS and 
                            PROCESSING_STATUS[processing_id]["status"] == "cancelled")
                except ImportError:
                    return False
            return False
        
        if original_metadata is None:
            original_metadata = {}
        
        if self.parser_type == "docling":
            return await self._process_with_docling(file_paths, _check_cancellation, {}, original_metadata)
        elif self.parser_type == "llamaparse":
            return await self._process_with_llamaparse(file_paths, _check_cancellation, {}, original_metadata)
    
    async def _process_with_docling(self, file_paths: List[Union[str, Path]], check_cancellation, original_filenames: Dict[str, str] = None, original_metadata: Dict[str, Dict] = None) -> List[Document]:
        """Process documents using Docling
        
        Args:
            file_paths: List of file paths to process
            check_cancellation: Function to check if processing should be cancelled
            original_filenames: Optional dict mapping temp paths to original filenames
            original_metadata: Optional dict mapping file paths to original metadata from placeholder docs
        """
        documents = []
        
        if original_filenames is None:
            original_filenames = {}
        
        if original_metadata is None:
            original_metadata = {}
        
        # Provide a default no-op cancellation check if None
        if check_cancellation is None:
            check_cancellation = lambda: False
        
        # Process files in parallel for better performance with multiple files
        import asyncio
        from concurrent.futures import ThreadPoolExecutor
        
        async def process_single_file(file_path):
            """Process a single file and return Document or None"""
            # Check for cancellation before processing each file
            if check_cancellation():
                logger.info("Document processing cancelled by user")
                raise RuntimeError("Processing cancelled by user")
            try:
                path_obj = Path(file_path)
                
                # Check if file exists
                if not path_obj.exists():
                    logger.warning(f"File does not exist: {file_path}")
                    return None
                
                # Check if it's a supported file type by Docling
                docling_extensions = [
                    '.pdf', '.docx', '.xlsx', '.pptx',
                    '.html', '.htm', '.md', '.markdown', '.asciidoc', '.adoc',
                    '.png', '.jpg', '.jpeg', '.tiff', '.tif', '.bmp', '.webp',
                    '.csv', '.xml', '.json'
                ]
                if path_obj.suffix.lower() in docling_extensions:
                    # Check for cancellation before heavy processing
                    if check_cancellation():
                        logger.info("Document processing cancelled before Docling conversion")
                        raise RuntimeError("Processing cancelled by user")
                    
                    logger.info(f"Converting document with Docling: {file_path}")
                    
                    # Convert using Docling with cancellation support and proper async handling
                    import asyncio
                    import functools
                    import concurrent.futures
                    
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                    convert_func = functools.partial(self.converter.convert, str(file_path))
                    
                    # Run with periodic cancellation checks using configured timeout
                    try:
                        result = await self._run_with_cancellation_checks(
                            loop, convert_func, check_cancellation
                        )
                    except concurrent.futures.TimeoutError:
                        raise RuntimeError("Processing cancelled by user")
                    
                    # Final check for cancellation after Docling conversion
                    if check_cancellation():
                        logger.info("Document processing cancelled after Docling conversion")
                        raise RuntimeError("Processing cancelled by user")
                    
                    # Extract both markdown and plain text
                    markdown_content = result.document.export_to_markdown()
                    plain_text = result.document.export_to_text()
                    
                    # Smart format selection: use markdown if tables detected, otherwise plain text
                    has_tables = "|" in markdown_content and "---" in markdown_content  # Simple table detection
                    
                    # Determine which format to use for extraction
                    format_config = getattr(self.config, 'parser_format_for_extraction', 'auto') if self.config else 'auto'
                    
                    if format_config == 'markdown':
                        content_to_use = markdown_content
                        format_used = "markdown (forced by config)"
                    elif format_config == 'plaintext':
                        content_to_use = plain_text
                        format_used = "plaintext (forced by config)"
                    else:  # auto
                        if has_tables:
                            content_to_use = markdown_content
                            format_used = "markdown (tables detected)"
                        else:
                            content_to_use = plain_text
                            format_used = "plaintext (no tables)"
                    
                    # Save parsing output if configured (works for both Docling and LlamaParse)
                    if self.config and getattr(self.config, 'save_parsing_output', False):
                        try:
                            output_dir = Path("./parsing_output")
                            output_dir.mkdir(exist_ok=True)
                            
                            # Create output filename
                            base_name = path_obj.stem
                            markdown_file = output_dir / f"{base_name}_docling_markdown.md"
                            plaintext_file = output_dir / f"{base_name}_docling_plaintext.txt"
                            metadata_file = output_dir / f"{base_name}_docling_metadata.json"
                            
                            # Save both formats
                            with open(markdown_file, 'w', encoding='utf-8') as f:
                                f.write(markdown_content)
                            logger.info(f"Saved Docling markdown output to: {markdown_file}")
                            
                            with open(plaintext_file, 'w', encoding='utf-8') as f:
                                f.write(plain_text)
                            logger.info(f"Saved Docling plain text output to: {plaintext_file}")
                            
                            # Save metadata as JSON
                            import json
                            docling_metadata = {
                                "source": str(file_path),
                                "file_type": path_obj.suffix,
                                "file_name": path_obj.name,
                                "conversion_method": "docling",
                                "markdown_length": len(markdown_content),
                                "plaintext_length": len(plain_text),
                                "has_tables": has_tables,
                                "format_used_for_processing": "markdown" if has_tables else "plaintext",
                            }
                            with open(metadata_file, 'w', encoding='utf-8') as f:
                                json.dump(docling_metadata, f, indent=2, ensure_ascii=False)
                            logger.info(f"Saved Docling metadata to: {metadata_file}")
                            
                            # Check for parser errors in content
                            error_indicators = ['Parser Error', 'ParserError', 'Failed to parse', 'ERROR:', 'Exception:']
                            for indicator in error_indicators:
                                if indicator in markdown_content or indicator in plain_text:
                                    logger.warning(f"Possible parser error detected in {markdown_file} - content contains '{indicator}'")
                            
                            # Check for LaTeX/KaTeX rendering issues that might appear in preview
                            latex_issues = ['\\[', '\\]', '$$', '\\begin{', '\\end{']
                            has_latex = any(indicator in markdown_content for indicator in latex_issues)
                            if has_latex:
                                logger.info(f"Note: {markdown_file} contains LaTeX/math expressions - may show rendering errors in preview")
                            
                        except Exception as e:
                            logger.warning(f"Failed to save Docling parsing output: {e}")
                    
                    logger.info(f"Using {format_used} for {file_path}")
                    
                    # Log content length for debugging
                    logger.info(f"Docling extracted {len(content_to_use)} characters from {file_path}")
                    logger.debug(f"First 200 chars: {content_to_use[:200]}...")
                    
                    # Get original metadata if available (from cloud sources)
                    orig_meta = original_metadata.get(str(file_path), {})
                    
                    # Create LlamaIndex Document - merge original metadata with new fields
                    doc = Document(
                        text=content_to_use,
                        metadata={
                            **orig_meta,  # Include original metadata first (contains file id, etc.)
                            "source": str(file_path),  # Then override with processing metadata
                            "conversion_method": "docling",
                            "file_type": path_obj.suffix,
                            "file_name": orig_meta.get("file_name") or path_obj.name  # Prefer original name
                        }
                    )
                    return doc
                    
                elif path_obj.suffix.lower() in ['.txt', '.md']:
                    # Handle plain text files directly
                    logger.info(f"Reading text file directly: {file_path}")
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Log content length for debugging
                    logger.info(f"Direct read extracted {len(content)} characters from {file_path}")
                    logger.debug(f"First 200 chars: {content[:200]}...")
                    
                    # Get original metadata if available (from cloud sources)
                    orig_meta = original_metadata.get(str(file_path), {})
                    
                    # Create LlamaIndex Document - merge original metadata with new fields
                    doc = Document(
                        text=content,
                        metadata={
                            **orig_meta,  # Include original metadata first (contains file id, etc.)
                            "source": str(file_path),  # Then override with processing metadata
                            "conversion_method": "direct",
                            "file_type": path_obj.suffix,
                            "file_name": orig_meta.get("file_name") or path_obj.name  # Prefer original name
                        }
                    )
                    return doc
                
                else:
                    logger.warning(f"Unsupported file type: {file_path}")
                    return None
                
            except Exception as e:
                logger.error(f"Error processing {file_path}: {e}")
                return None
        
        # Process files in parallel using asyncio.gather
        logger.info(f"Processing {len(file_paths)} files with Docling in parallel...")
        tasks = [process_single_file(file_path) for file_path in file_paths]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out None results and exceptions
        documents = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Error processing file {file_paths[i]}: {result}")
            elif result is not None:
                documents.append(result)
        
        logger.info(f"Successfully processed {len(documents)} documents with Docling in parallel")
        return documents
    
    async def _process_with_llamaparse(self, file_paths: List[Union[str, Path]], check_cancellation, original_filenames: Dict[str, str] = None, original_metadata: Dict[str, Dict] = None) -> List[Document]:
        """Process documents using LlamaParse with JSON mode for markdown + plaintext + metadata
        
        Creates ONE Document per file (combining all pages) for proper document-level tracking.
        
        Args:
            file_paths: List of file paths to process (temp files already have meaningful names)
            check_cancellation: Optional function to check if processing should be cancelled
            original_filenames: Optional dict (kept for backward compatibility, but not needed anymore)
            original_metadata: Optional dict mapping file paths to original metadata from placeholder docs
        """
        documents = []
        
        if original_metadata is None:
            original_metadata = {}
        
        # Check for cancellation before starting
        if check_cancellation and check_cancellation():
            logger.info("Document processing cancelled by user")
            raise RuntimeError("Processing cancelled by user")
        
        # Verify parser is initialized
        if not hasattr(self, 'parser') or self.parser is None:
            error_msg = "LlamaParse parser not initialized. Check LLAMAPARSE_API_KEY in environment or config."
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        
        logger.info(f"Processing {len(file_paths)} files with LlamaParse in JSON mode...")
        
        # Recreate parser to avoid event loop conflicts
        # LlamaParse creates async locks that get bound to the event loop at creation time
        # If the event loop changes between calls, we need a fresh parser instance
        try:
            self.parser = self._create_llamaparse_parser()
            logger.debug("Recreated LlamaParse parser instance for this processing batch")
        except Exception as e:
            logger.warning(f"Could not recreate LlamaParse parser: {e} - using existing instance")
        
        try:
            # Process each file with LlamaParse JSON mode
            for file_path in file_paths:
                # Check for cancellation before each file
                if check_cancellation and check_cancellation():
                    logger.info("Document processing cancelled by user")
                    raise RuntimeError("Processing cancelled by user")
                
                file_path_str = str(file_path)
                logger.info(f"Processing {file_path} with LlamaParse...")
                
                # Log file size for debugging
                try:
                    file_size = Path(file_path).stat().st_size
                    logger.info(f"File size: {file_size} bytes")
                except Exception as e:
                    logger.warning(f"Could not determine file size: {e}")
                
                # Get JSON results from LlamaParse (returns list of dicts, one per file)
                try:
                    json_results = await self.parser.aget_json(file_path_str)
                except Exception as e:
                    logger.error(f"LlamaParse error for {Path(file_path).name}: {e}")
                    if "event loop" in str(e).lower():
                        logger.error("Event loop conflict detected - LlamaParse parser needs recreation")
                    logger.warning(f"Skipping {Path(file_path).name}")
                    continue  # Skip to next file
                
                # Check if LlamaParse returned empty results list
                if not json_results:
                    logger.warning(f"Parser returned empty results list for {Path(file_path).name}")
                    logger.warning(f"Skipping {Path(file_path).name}")
                    continue  # Skip to next file
                
                # Check for cancellation after parsing
                if check_cancellation and check_cancellation():
                    logger.info("Document processing cancelled after LlamaParse conversion")
                    raise RuntimeError("Processing cancelled by user")
                
                # Process each JSON result (usually one per file)
                for json_result in json_results:
                    # Extract pages and metadata from JSON result
                    pages = json_result.get("pages", [])
                    job_metadata = json_result.get("job_metadata", {})
                    
                    logger.info(f"LlamaParse returned {len(pages)} pages for {Path(file_path).name}")
                    
                    # Check if parser returned empty result
                    if len(pages) == 0:
                        logger.warning(f"Parser returned 0 pages for {Path(file_path).name}")
                        logger.warning(f"Skipping {Path(file_path).name}")
                        continue  # Skip this file, don't create a Document
                    
                    # Extract markdown and plaintext from all pages
                    markdown_parts = []
                    plaintext_parts = []
                    
                    for page in pages:
                        if "md" in page:
                            markdown_parts.append(page["md"])
                        if "text" in page:
                            plaintext_parts.append(page["text"])
                    
                    # Combine all pages into single content
                    markdown_content = "\n\n".join(markdown_parts)
                    plaintext_content = "\n\n".join(plaintext_parts)
                    
                    logger.info(f"LlamaParse extracted {len(markdown_content)} chars (markdown), {len(plaintext_content)} chars (plaintext) from {Path(file_path).name}")
                    
                    # Check if both markdown and plaintext are empty (failed extraction)
                    if not markdown_content.strip() and not plaintext_content.strip():
                        logger.warning(f"Parser extracted empty content for {Path(file_path).name}")
                        logger.warning(f"Skipping {Path(file_path).name}")
                        continue  # Skip this file, don't create a Document
                    
                    # Determine which format to use for the Document text
                    # (This will be chunked by SentenceSplitter downstream)
                    format_config = getattr(self.config, 'parser_format_for_extraction', 'auto') if self.config else 'auto'
                    
                    # Get parse_mode to check if using parse_page_without_llm
                    parse_mode = os.getenv('LLAMAPARSE_MODE', 'parse_page_with_llm')
                    
                    # Force plaintext for parse_page_without_llm (produces no markdown) - overrides config
                    if parse_mode == "parse_page_without_llm":
                        content_to_use = plaintext_content
                        format_used = "plaintext (parse_page_without_llm - forced)"
                        logger.info(f"Forcing plaintext format because parse_page_without_llm produces no markdown")
                    # Handle explicit config settings
                    elif format_config == 'plaintext':
                        content_to_use = plaintext_content
                        format_used = "plaintext (config)"
                    elif format_config == 'markdown':
                        content_to_use = markdown_content
                        format_used = "markdown (config)"
                    else:  # auto mode - smart selection based on content
                        # Smart selection: use markdown if tables detected, otherwise plaintext
                        has_tables = "|" in markdown_content and "---" in markdown_content
                        if has_tables:
                            content_to_use = markdown_content
                            format_used = "markdown (tables detected)"
                        else:
                            content_to_use = plaintext_content
                            format_used = "plaintext (no tables)"
                    
                    logger.info(f"Using {format_used} format for document processing (config: {format_config})")
                    
                    # Save parsing output if configured
                    if self.config and getattr(self.config, 'save_parsing_output', False):
                        try:
                            output_dir = Path("./parsing_output")
                            output_dir.mkdir(exist_ok=True)
                            
                            base_name = Path(file_path).stem
                            markdown_file = output_dir / f"{base_name}_llamaparse_output.md"
                            plaintext_file = output_dir / f"{base_name}_llamaparse_output.txt"
                            metadata_file = output_dir / f"{base_name}_llamaparse_metadata.json"
                            
                            # Save markdown
                            with open(markdown_file, 'w', encoding='utf-8') as f:
                                f.write(markdown_content)
                            logger.info(f"Saved LlamaParse markdown output to: {markdown_file}")
                            
                            # Save plaintext (native from LlamaParse, not regex-stripped)
                            with open(plaintext_file, 'w', encoding='utf-8') as f:
                                f.write(plaintext_content)
                            logger.info(f"Saved LlamaParse plaintext output to: {plaintext_file}")
                            
                            # Build comprehensive metadata
                            import json
                            llamaparse_metadata = {
                                "source": file_path_str,
                                "file_name": Path(file_path).name,
                                "file_type": Path(file_path).suffix,
                                "total_pages": len(pages),
                                "markdown_length": len(markdown_content),
                                "plaintext_length": len(plaintext_content),
                                "job_metadata": job_metadata,
                                "pages_with_markdown": sum(1 for p in pages if "md" in p),
                                "pages_with_text": sum(1 for p in pages if "text" in p),
                                "total_images": sum(len(p.get("images", [])) for p in pages),
                                "format_used_for_processing": format_used,
                            }
                            
                            with open(metadata_file, 'w', encoding='utf-8') as f:
                                json.dump(llamaparse_metadata, f, indent=2, ensure_ascii=False)
                            logger.info(f"Saved LlamaParse metadata to: {metadata_file}")
                            
                            # Check for parser errors in content
                            error_indicators = ['Parser Error', 'ParserError', 'Failed to parse', 'ERROR:', 'Exception:']
                            for indicator in error_indicators:
                                if indicator in markdown_content:
                                    logger.warning(f"Possible parser error detected in {markdown_file} - content contains '{indicator}'")
                            
                            # Check for LaTeX/KaTeX rendering issues that might appear in preview
                            latex_issues = ['\\[', '\\]', '$$', '\\begin{', '\\end{']
                            has_latex = any(indicator in markdown_content for indicator in latex_issues)
                            if has_latex:
                                logger.info(f"Note: {markdown_file} contains LaTeX/math expressions - may show rendering errors in preview")
                            
                        except Exception as e:
                            logger.warning(f"Failed to save LlamaParse parsing output: {e}")
                    
                    # Get original metadata if available (from cloud sources)
                    orig_meta = original_metadata.get(file_path_str, {})
                    
                    # Create ONE LlamaIndex Document per file (combining all pages)
                    # SentenceSplitter will chunk this downstream with proper overlap
                    doc = Document(
                        text=content_to_use,
                        metadata={
                            **orig_meta,  # Include original metadata first (contains file id, etc.)
                            "source": file_path_str,
                            "conversion_method": "llamaparse",
                            "file_type": Path(file_path).suffix,
                            "file_name": orig_meta.get("file_name") or Path(file_path).name,  # Prefer original name
                            "total_pages": len(pages),
                            "format_used": format_used,
                            # Add job metadata for tracking
                            "job_id": json_result.get("job_id"),
                        }
                    )
                    documents.append(doc)
                    logger.info(f"Created 1 Document for {Path(file_path).name} ({len(pages)} pages, {len(content_to_use)} chars)")
            
            logger.info(f"Successfully processed {len(file_paths)} files ({len(documents)} documents) with LlamaParse")
            
            # Warn if some files failed to produce documents
            if len(documents) < len(file_paths):
                failed_count = len(file_paths) - len(documents)
                logger.warning(f"Processing incomplete: {failed_count}/{len(file_paths)} files produced no documents")
            
            return documents
            
        except Exception as e:
            logger.error(f"Error processing files with LlamaParse: {e}")
            raise
    
    def process_text_content(self, content: str, source_name: str = "text_input") -> Document:
        """Create a LlamaIndex Document from text content"""
        return Document(
            text=content,
            metadata={
                "source": source_name,
                "conversion_method": "direct_text",
                "file_type": ".txt",
                "file_name": source_name
            }
        )
    
    async def process_documents_from_metadata(self, placeholder_docs: List[Document], check_cancellation=None) -> List[Document]:
        """
        Process documents that contain file_path and optionally _fs in metadata.
        If _fs is present, downloads the file from remote filesystem first.
        
        Args:
            placeholder_docs: List of placeholder documents with metadata containing:
                             - file_path: path to file (local or remote)
                             - _fs: optional filesystem object for remote files
            check_cancellation: Optional function to check if processing should be cancelled
        
        Returns:
            List[Document]: Processed documents with full content
        """
        temp_files = []  # Track temp files for cleanup
        original_filenames = {}  # Map temp paths to original filenames
        original_metadata = {}  # Map file paths to original metadata from placeholder docs
        
        try:
            # Process each placeholder document
            file_paths_to_process = []
            
            for doc in placeholder_docs:
                file_path = doc.metadata.get("file_path")
                fs = doc.metadata.get("_fs")
                
                if not file_path:
                    logger.warning("Placeholder document missing file_path in metadata")
                    continue
                
                # Store original metadata (excluding internal fields)
                # Filter out internal fields like _fs
                original_meta = {k: v for k, v in doc.metadata.items() if not k.startswith('_')}
                
                # If remote filesystem, download to temp
                if fs:
                    try:
                        from llama_index.core.readers.file.base import is_default_fs
                        
                        if not is_default_fs(fs):
                            logger.info(f"Downloading remote file {file_path} to temp location")
                            
                            # Get original filename
                            file_name = doc.metadata.get("file_name", Path(file_path).name)
                            
                            # Create temp file with original filename preserved
                            # Files from same source should have unique names already
                            temp_dir = tempfile.gettempdir()
                            temp_path = os.path.join(temp_dir, file_name)
                            
                            # Download file
                            with fs.open(str(file_path), 'rb') as remote_file:
                                with open(temp_path, 'wb') as local_file:
                                    local_file.write(remote_file.read())
                            
                            file_paths_to_process.append(temp_path)
                            temp_files.append(temp_path)
                            # Map temp path to original metadata
                            original_metadata[temp_path] = original_meta
                            logger.info(f"Downloaded {file_path} to {temp_path} (preserving original name: {file_name})")
                        else:
                            # Local filesystem - use path as-is
                            file_paths_to_process.append(file_path)
                            original_metadata[file_path] = original_meta
                    except Exception as e:
                        logger.error(f"Failed to download {file_path}: {e}")
                        # Skip this file but continue with others
                        continue
                else:
                    # No fs object - assume local path
                    file_paths_to_process.append(file_path)
                    original_metadata[file_path] = original_meta
            
            if not file_paths_to_process:
                logger.warning("No files to process after download phase")
                return []
            
            logger.info(f"Processing {len(file_paths_to_process)} files with {self.parser_type}")
            
            # Process files based on parser type
            if self.parser_type == "docling":
                documents = await self._process_with_docling(file_paths_to_process, check_cancellation, original_filenames, original_metadata)
            elif self.parser_type == "llamaparse":
                documents = await self._process_with_llamaparse(file_paths_to_process, check_cancellation, original_filenames, original_metadata)
            else:
                raise ValueError(f"Unknown parser type: {self.parser_type}")
            
            return documents
            
        finally:
            # Clean up temp files
            for temp_file in temp_files:
                try:
                    if os.path.exists(temp_file):
                        os.unlink(temp_file)
                        logger.debug(f"Cleaned up temp file: {temp_file}")
                except Exception as e:
                    logger.warning(f"Failed to clean up temp file {temp_file}: {e}")