import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, render, screen } from "@testing-library/react";
import { createMemoryRouter, Navigate, RouterProvider } from "react-router-dom";
import { afterEach, describe, expect, it, vi } from "vitest";
import { Placeholder } from "@/app/Placeholder";
import { ProjectShell } from "@/app/ProjectShell";
import { V2Placeholder } from "@/app/V2Placeholder";
import { __resetProjectWebSocketsForTests } from "@/lib/realtime/useProjectWebSocket";

// Avoid opening a real WebSocket when ProjectShell mounts — the router
// tests only care about the layout, not the live data path.
vi.mock("@/lib/realtime/websocketClient", () => ({
  createWebSocketClient: () => ({
    close: vi.fn(),
    getStatus: () => "connecting",
  }),
}));

afterEach(() => {
  cleanup();
  __resetProjectWebSocketsForTests();
});

function renderRoute(path: string) {
  const routes = [
    { path: "/projects", element: <Placeholder name="ProjectList" /> },
    {
      path: "/p/:projectId",
      element: <ProjectShell />,
      children: [
        { index: true, element: <Navigate to="board" replace /> },
        { path: "board", element: <Placeholder name="KanbanBoard" /> },
        { path: "graph", element: <Placeholder name="ConceptGraph" /> },
        { path: "sessions", element: <Placeholder name="SessionList" /> },
        { path: "orchestration", element: <Placeholder name="OrchestrationView" /> },
        { path: "messages", element: <V2Placeholder feature="Messages" /> },
        { path: "agents", element: <V2Placeholder feature="Agents" /> },
      ],
    },
  ];
  const router = createMemoryRouter(routes, { initialEntries: [path] });
  const queryClient = new QueryClient();
  return render(
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>,
  );
}

describe("Router", () => {
  it("renders ProjectList placeholder at /projects", () => {
    renderRoute("/projects");
    expect(screen.getByText("ProjectList")).toBeDefined();
    expect(screen.getByText("Coming in a later issue.")).toBeDefined();
  });

  it("renders ProjectShell with TopBar at /p/:projectId/board", () => {
    renderRoute("/p/proj-1/board");
    // TopBar renders the project name
    expect(screen.getByText("Project proj-1")).toBeDefined();
    // Board placeholder renders inside the outlet
    expect(screen.getByText("KanbanBoard")).toBeDefined();
  });

  it("renders V2Placeholder for /p/:projectId/messages", () => {
    renderRoute("/p/proj-1/messages");
    expect(screen.getByRole("heading", { name: "Messages" })).toBeDefined();
    expect(screen.getByText(/Coming in v2/)).toBeDefined();
  });

  it("renders V2Placeholder for /p/:projectId/agents", () => {
    renderRoute("/p/proj-1/agents");
    expect(screen.getByRole("heading", { name: "Agents" })).toBeDefined();
  });

  it("renders AgentStatusBar in the top bar", () => {
    renderRoute("/p/proj-1/board");
    expect(screen.getByText("0 agents running")).toBeDefined();
  });

  it("renders nav tabs in TopBar", () => {
    renderRoute("/p/proj-1/board");
    expect(screen.getByText("Board")).toBeDefined();
    expect(screen.getByText("Graph")).toBeDefined();
    expect(screen.getByText("Sessions")).toBeDefined();
    expect(screen.getByText("Orchestration")).toBeDefined();
  });
});
