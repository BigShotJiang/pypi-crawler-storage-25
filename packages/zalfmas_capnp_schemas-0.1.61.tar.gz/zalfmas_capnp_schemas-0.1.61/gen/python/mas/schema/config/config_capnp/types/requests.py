"""Runtime placeholder module for request helpers of `config.capnp`."""

# pyright: reportUnusedClass=none
