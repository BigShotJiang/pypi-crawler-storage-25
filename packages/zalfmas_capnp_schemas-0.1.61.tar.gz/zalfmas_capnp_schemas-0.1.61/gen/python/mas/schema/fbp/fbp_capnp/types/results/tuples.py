"""Runtime placeholder module for result tuple helpers of `fbp.capnp`."""

# pyright: reportUnusedClass=none

from typing import NamedTuple


class EndpointsResultTuple(NamedTuple):
    r: object
    w: object


class ReaderResultTuple(NamedTuple):
    r: object


class RegisterstatscallbackResultTuple(NamedTuple):
    unregisterCallback: object


class WriterResultTuple(NamedTuple):
    w: object


class ReadResultTuple(NamedTuple):
    value: object
    done: object
    noMsg: object


class ReadifmsgResultTuple(NamedTuple):
    value: object
    done: object
    noMsg: object


class UnregResultTuple(NamedTuple):
    success: object


class WriteifspaceResultTuple(NamedTuple):
    success: object


class ConfigentriesResultTuple(NamedTuple):
    config: object


class ConnectinportResultTuple(NamedTuple):
    connected: object
    disconnect: object


class ConnectoutportResultTuple(NamedTuple):
    connected: object
    disconnect: object


class InportsResultTuple(NamedTuple):
    ports: object


class OutportsResultTuple(NamedTuple):
    ports: object


class ProcessStartResultTuple(NamedTuple):
    started: object


class ProcessStopResultTuple(NamedTuple):
    stopped: object


class StateResultTuple(NamedTuple):
    currentState: object


class DisconnectResultTuple(NamedTuple):
    disconnected: object


class ProcessFactoryCreateResultTuple(NamedTuple):
    out: object


class AliveResultTuple(NamedTuple):
    alive: object


class ProcessHandleCloseResultTuple(NamedTuple):
    closed: object


class ProcessResultTuple(NamedTuple):
    process: object


class RunnableStartResultTuple(NamedTuple):
    success: object


class RunnableStopResultTuple(NamedTuple):
    success: object


class RunnableFactoryCreateResultTuple(NamedTuple):
    out: object


class StartChannelsServiceStartResultTuple(NamedTuple):
    startupInfos: object
    stop: object


__all__ = [
    "AliveResultTuple",
    "ConfigentriesResultTuple",
    "ConnectinportResultTuple",
    "ConnectoutportResultTuple",
    "DisconnectResultTuple",
    "EndpointsResultTuple",
    "InportsResultTuple",
    "OutportsResultTuple",
    "ProcessFactoryCreateResultTuple",
    "ProcessHandleCloseResultTuple",
    "ProcessResultTuple",
    "ProcessStartResultTuple",
    "ProcessStopResultTuple",
    "ReadResultTuple",
    "ReaderResultTuple",
    "ReadifmsgResultTuple",
    "RegisterstatscallbackResultTuple",
    "RunnableFactoryCreateResultTuple",
    "RunnableStartResultTuple",
    "RunnableStopResultTuple",
    "StartChannelsServiceStartResultTuple",
    "StateResultTuple",
    "UnregResultTuple",
    "WriteifspaceResultTuple",
    "WriterResultTuple",
]
