"""NanoBanana CLI core modules."""
