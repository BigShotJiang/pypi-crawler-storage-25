# ac-cli

Python CLI for AgencyCore. Built with Typer + httpx + Rich + Supabase auth.

## Setup

```bash
uv sync                    # Install all dependencies
uv sync --all-extras       # Install with dev dependencies (pytest, respx)
```

## Command Groups

`ac <group> <subcommand> [--json]` — all commands support `--json` for scripting.

| Group | Domain |
|-------|--------|
| `crm` | Companies, people, deals, activities, comms (incl. approvals), lists, imports |
| `envoy` | Sequences (incl. lifecycle), campaigns, steps, recipients, outbox, playbooks, battlecards, inbox |
| `files` | Image upload/delete |
| `workflows` | Runs, schedules, presets, csv-parse |
| `apps` | Organization app install/config |
| `chat` | AI chat threads (incl. send/escalate) and messages |
| `admin` | Users, orgs, queues, demo, onboarding, app-usage, ai-usage, platform-activity, legal-docs, resources, apps, chat-escalations, subscriptions, subscription-plans (super admin) |
| `profiles` | User profile (incl. set-organization, set-password, subscription) |
| `resources` | Knowledge base resource management |
| `styles` | Writing styles |
| `nylas` | Email integration, thread sync, attachment download |
| `messaging` | Messaging platform sessions and account linking |
| `hooks` | Platform hooks |
| `health` | Health checks |
| `env` | Environment switching (local, staging, production) |
| `legal-docs` | Legal document retrieval and acceptance |
| `tos` | Terms of service config, status, acceptance |
| `marketplace` | App marketplace browsing and developer listing |
| `network` | Referrals, news, Slack invites |
| `onboarding` | Managed onboarding config and completion |

Run `ac <group> --help` for full subcommand listing.

## Agent-Friendly Features

The CLI is designed to be consumed by AI agents and scripts:

- **Structured JSON errors**: When `--json` is active, errors return `{"error": true, "status_code": ..., "detail": ...}` instead of Rich text
- **Semantic exit codes**: `0`=success, `1`=general error, `2`=validation (422), `3`=not found (404), `4`=auth/permission (401/403), `5`=conflict (409)
- **`AC_YES=1` env var**: Skips all `typer.confirm()` prompts for non-interactive use
- **`--json` on all groups**: Every group callback calls `set_json_mode()` so errors also respect JSON mode

See `.claude/rules/code-patterns.md` for implementation details.

## Project Layout

```
src/ac_cli/
  main.py              → Entry point, registers all command groups
  client.py            → Authenticated httpx client from stored config
  config.py            → Multi-env config (~/.agencycore/config.json)
  formatting.py        → Shared output (print_table, print_detail, print_json)
  commands/            → Command modules (auth, env, crm/, envoy/, admin/, etc.)
    _helpers.py        → Shared helpers (_api_request, _build_body, _get_org_id, exit codes)
tests/                 → One test file per command group (test_<domain>_<group>.py)
scripts/               → bump.sh (manual version), auto-version-tag.sh (post-commit hook),
                         lint.sh (ruff lint + format), audit_endpoints.py (CLI vs API endpoint diff)
```

## Running Checks

```bash
uv run pytest                              # All tests
uv run pytest tests/test_crm_companies.py  # Single file
uv run python -m ac_cli.main --help        # Verify CLI loads
./scripts/lint.sh                          # Ruff lint + format check
./scripts/lint.sh --fix                    # Ruff auto-fix + format
uv run vulture src/                        # Dead-code scan
uv run deptry src/                         # Dependency hygiene
python scripts/audit_endpoints.py --strict # Diff CLI calls vs live OpenAPI
```

Pytest defaults (`pyproject.toml`): `-n auto --dist worksteal --maxfail=1 --cov-fail-under=90`. No mypy/type-check tooling is configured.

`audit_endpoints.py` requires the API on `localhost:8008` (or pass `--api-url`).
Run before merging changes that touch routers or `_api_request` calls — exits
nonzero on stale CLI paths or new API endpoints not yet covered.

## TDD Workflow

For `feat:` and `fix:` changes, write tests first. See parent `agencycore/.claude/rules/06-tdd-workflow.md`.

**Single test run:** `uv run pytest tests/test_<domain>_<group>.py -x`

**Watch mode:** `uv run ptw -- -x -q`

Every new command needs tests for: happy path, `--json` flag, error codes, and `--yes` on deletes.

## Critical Rules

- **Never hardcode a version** — managed by hatch-vcs from git tags. See `.claude/rules/versioning.md`.
- **Always use conventional commit prefixes** (`feat:`, `fix:`, `chore:`, etc.) — auto-bump and PyPI publishing depend on this.
- **Credentials in `~/.agencycore/config.json`** (file mode 0600) — never commit.
- **Dependencies**: use `uv add <pkg>` / `uv add --dev <pkg>`. Both `pyproject.toml` and `uv.lock` must stay in sync.

## API Domains Not Exposed in CLI

The following API domains are intentionally not covered by the CLI:

- `/test` — dev-only email simulation endpoints
- `/eval/*` — internal eval dashboard endpoints
- `/admin/demo/*-stream`, `/organizations/scrape-website-stream`,
  `/envoy/sequences/{id}/step-stats/stream`,
  `/workflows/{id}/runs/{id}/events`, `/resources/{id}/stream` — SSE streaming
- `/webhook`, `/nylas/webhook`, `/messaging/whatsapp/webhook`,
  `/messaging/slack/events` — server-side webhook handlers
- `/nylas/oauth/callback`, `/email/unsubscribe`, `/nylas/email/unsubscribe` —
  public/browser endpoints
- `/nylas/demo/*` — demo-only email simulation
- `/organizations/*` (non-admin), `/profiles` (admin list), `/envoy/outputs` —
  not surfaced via CLI today; admin equivalents exist under `ac admin orgs`
- `/orgs/{id}/activity-events` — frontend-only activity logger
- `/battlecards/*`, `/playbooks/*` mounted bare are duplicates of the
  `/envoy/*` variants — CLI uses the canonical path

The full list lives in `OUT_OF_SCOPE` inside `scripts/audit_endpoints.py`;
update that set when intentionally adding a new API endpoint that the CLI
shouldn't call.
