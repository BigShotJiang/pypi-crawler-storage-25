"""Envoy sequences commands."""

from __future__ import annotations

import typer
from rich import print as rprint

from ac_cli.commands._helpers import JSON_OPTION, _get_org_id, set_json_mode, should_skip_confirm
from ac_cli.commands.crm import _api_request, _build_body
from ac_cli.commands.envoy import _ENVOY
from ac_cli.formatting import print_detail, print_json, print_table

sequences_app = typer.Typer(help="Sequence operations")


@sequences_app.command("list")
def sequences_list(
    ctx: typer.Context,
    status: str | None = typer.Option(None, help="Filter by status"),
    json_output: bool = JSON_OPTION,
) -> None:
    """List outreach sequences."""
    set_json_mode(json_output)
    params: dict = {}
    if status:
        params["status_filter"] = status

    resp = _api_request("get", f"{_ENVOY}/sequences", params=params)

    data = resp.json()
    if json_output:
        print_json(data)
        return

    items = data if isinstance(data, list) else data.get("data", [])
    print_table(
        items,
        [
            ("name", "Name"),
            ("status", "Status"),
            ("execution_mode", "Mode"),
            ("id", "ID"),
        ],
        title=f"Sequences ({len(items)})",
    )


@sequences_app.command("get")
def sequences_get(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Get a sequence by ID."""
    set_json_mode(json_output)
    resp = _api_request("get", f"{_ENVOY}/sequences/{sequence_id}")

    data = resp.json()
    if json_output:
        print_json(data)
        return

    print_detail(
        data,
        [
            ("id", "ID"),
            ("name", "Name"),
            ("description", "Description"),
            ("status", "Status"),
            ("execution_mode", "Execution Mode"),
            ("writing_style_id", "Writing Style ID"),
            ("playbook_id", "Playbook ID"),
            ("crm_list_id", "CRM List ID"),
            ("created_at", "Created"),
            ("updated_at", "Updated"),
        ],
    )

    steps = data.get("steps", [])
    if steps:
        rprint(f"\n[bold]Steps ({len(steps)})[/bold]")
        print_table(
            steps,
            [
                ("step_order", "Order"),
                ("step_type", "Type"),
                ("id", "ID"),
            ],
        )


@sequences_app.command("create")
def sequences_create(
    ctx: typer.Context,
    name: str = typer.Option(..., help="Sequence name"),
    description: str | None = typer.Option(None, help="Description"),
    writing_style_id: str | None = typer.Option(
        None, "--writing-style-id", help="Writing style ID"
    ),
    playbook_id: str | None = typer.Option(None, "--playbook-id", help="Playbook ID"),
    crm_list_id: str | None = typer.Option(None, "--crm-list-id", help="CRM list ID"),
    execution_mode: str | None = typer.Option(None, "--execution-mode", help="Execution mode"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Create a new outreach sequence."""
    set_json_mode(json_output)
    body = _build_body(
        name=name,
        description=description,
        writing_style_id=writing_style_id,
        playbook_id=playbook_id,
        crm_list_id=crm_list_id,
        execution_mode=execution_mode,
    )

    body["organization_id"] = _get_org_id()

    resp = _api_request("post", f"{_ENVOY}/sequences", json=body)

    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Created sequence:[/green] {data['name']} ({data['id']})")


@sequences_app.command("update")
def sequences_update(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    name: str | None = typer.Option(None, help="Sequence name"),
    description: str | None = typer.Option(None, help="Description"),
    writing_style_id: str | None = typer.Option(
        None, "--writing-style-id", help="Writing style ID"
    ),
    playbook_id: str | None = typer.Option(None, "--playbook-id", help="Playbook ID"),
    crm_list_id: str | None = typer.Option(None, "--crm-list-id", help="CRM list ID"),
    execution_mode: str | None = typer.Option(None, "--execution-mode", help="Execution mode"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Update a sequence."""
    set_json_mode(json_output)
    body = _build_body(
        name=name,
        description=description,
        writing_style_id=writing_style_id,
        playbook_id=playbook_id,
        crm_list_id=crm_list_id,
        execution_mode=execution_mode,
    )

    if not body:
        rprint("[yellow]No fields to update.[/yellow]")
        raise typer.Exit(code=1)

    resp = _api_request("patch", f"{_ENVOY}/sequences/{sequence_id}", json=body)

    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Updated sequence:[/green] {data['name']} ({data['id']})")


@sequences_app.command("delete")
def sequences_delete(
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a sequence."""
    if not should_skip_confirm(yes):
        typer.confirm(f"Delete sequence {sequence_id}?", abort=True)

    _api_request("delete", f"{_ENVOY}/sequences/{sequence_id}")

    rprint(f"[green]Deleted sequence {sequence_id}[/green]")


@sequences_app.command("launch")
def sequences_launch(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    workflow_id: str = typer.Option(..., "--workflow-id", help="Workflow ID to launch with"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Launch a sequence."""
    set_json_mode(json_output)
    resp = _api_request(
        "post", f"{_ENVOY}/sequences/{sequence_id}/launch", json={"workflow_id": workflow_id}
    )

    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Launched sequence {sequence_id}[/green]")


@sequences_app.command("pause")
def sequences_pause(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Pause a running sequence."""
    set_json_mode(json_output)
    resp = _api_request("post", f"{_ENVOY}/sequences/{sequence_id}/pause")

    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Paused sequence {sequence_id}[/green]")


@sequences_app.command("resume")
def sequences_resume(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    workflow_id: str = typer.Option(..., "--workflow-id", help="Workflow ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Resume a paused sequence."""
    set_json_mode(json_output)
    resp = _api_request(
        "post", f"{_ENVOY}/sequences/{sequence_id}/resume", json={"workflow_id": workflow_id}
    )

    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Resumed sequence {sequence_id}[/green]")


@sequences_app.command("duplicate")
def sequences_duplicate(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Duplicate a sequence."""
    set_json_mode(json_output)
    resp = _api_request("post", f"{_ENVOY}/sequences/{sequence_id}/duplicate")
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Duplicated sequence:[/green] {data.get('name', '?')} ({data.get('id')})")


@sequences_app.command("archive")
def sequences_archive(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Archive a sequence."""
    set_json_mode(json_output)
    resp = _api_request("post", f"{_ENVOY}/sequences/{sequence_id}/archive")
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Archived sequence {sequence_id}[/green]")


@sequences_app.command("restore")
def sequences_restore(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Restore an archived sequence."""
    set_json_mode(json_output)
    resp = _api_request("post", f"{_ENVOY}/sequences/{sequence_id}/restore")
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Restored sequence {sequence_id}[/green]")


@sequences_app.command("impact-preview")
def sequences_impact_preview(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    step_id: list[str] = typer.Option(
        ..., "--step-id", help="Step ID about to delete (repeatable)"
    ),
    json_output: bool = JSON_OPTION,
) -> None:
    """Preview impact of deleting steps before saving."""
    set_json_mode(json_output)
    resp = _api_request(
        "post",
        f"{_ENVOY}/sequences/{sequence_id}/impact-preview",
        json={"step_ids": step_id},
    )
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(
            f"[bold]Impact preview:[/bold] "
            f"affected_recipients={data.get('affected_recipients', '?')}, "
            f"pending_drafts={data.get('pending_drafts', '?')}"
        )


@sequences_app.command("bulk-remove-recipients")
def sequences_bulk_remove_recipients(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    recipient_id: list[str] = typer.Option(..., "--recipient-id", help="Recipient ID (repeatable)"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Soft-delete a batch of recipients from a sequence."""
    set_json_mode(json_output)
    resp = _api_request(
        "post",
        f"{_ENVOY}/sequences/{sequence_id}/recipients/bulk-remove",
        json={"recipient_ids": recipient_id},
    )
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[green]Removed {data.get('removed', '?')} recipients from {sequence_id}[/green]")


@sequences_app.command("classify-step-subtype")
def sequences_classify_step_subtype(
    ctx: typer.Context,
    instruction: str = typer.Argument(..., help="Step instruction text to classify"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Classify the subtype of a sequence step from its instruction text."""
    set_json_mode(json_output)
    resp = _api_request(
        "post",
        f"{_ENVOY}/sequences/classify-step-subtype",
        json={"instruction": instruction},
    )
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(f"[bold]Subtype:[/bold] {data.get('subtype', '?')}")


@sequences_app.command("outputs")
def sequences_outputs(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    limit: int = typer.Option(50, help="Max results"),
    offset: int = typer.Option(0, help="Pagination offset"),
    json_output: bool = JSON_OPTION,
) -> None:
    """List sequence outputs (generated drafts/results)."""
    set_json_mode(json_output)
    resp = _api_request(
        "get",
        f"{_ENVOY}/sequences/{sequence_id}/outputs",
        params={"limit": limit, "offset": offset},
    )
    data = resp.json()
    if json_output:
        print_json(data)
        return
    items = data if isinstance(data, list) else data.get("data", [])
    print_table(
        items,
        [
            ("id", "ID"),
            ("step_id", "Step"),
            ("status", "Status"),
            ("created_at", "Created"),
        ],
        title=f"Outputs ({data.get('total', len(items))} total)",
    )


@sequences_app.command("for-prospect")
def sequences_for_prospect(
    ctx: typer.Context,
    prospect_id: str = typer.Argument(..., help="Prospect (person) ID"),
    json_output: bool = JSON_OPTION,
) -> None:
    """List sequences that include a given prospect."""
    set_json_mode(json_output)
    resp = _api_request("get", f"{_ENVOY}/sequences/by-prospect/{prospect_id}")

    data = resp.json()
    if json_output:
        print_json(data)
        return

    items = data if isinstance(data, list) else data.get("data", [])
    print_table(
        items,
        [
            ("name", "Name"),
            ("status", "Status"),
            ("execution_mode", "Mode"),
            ("id", "ID"),
        ],
        title=f"Sequences for prospect {prospect_id} ({len(items)})",
    )


@sequences_app.command("generate-drafts")
def sequences_generate_drafts(
    ctx: typer.Context,
    sequence_id: str = typer.Argument(..., help="Sequence ID"),
    step_id: str = typer.Argument(..., help="Step ID"),
    workflow_id: str = typer.Option(..., "--workflow-id", help="Workflow ID to run drafts under"),
    json_output: bool = JSON_OPTION,
) -> None:
    """Trigger draft generation for a sequence step."""
    set_json_mode(json_output)
    resp = _api_request(
        "post",
        f"{_ENVOY}/sequences/{sequence_id}/steps/{step_id}/generate-drafts",
        json={"workflow_id": workflow_id},
    )
    data = resp.json()
    if json_output:
        print_json(data)
    else:
        rprint(
            f"[green]Queued draft generation:[/green] "
            f"run={data.get('run_id', '?')} status={data.get('status', '?')}"
        )
