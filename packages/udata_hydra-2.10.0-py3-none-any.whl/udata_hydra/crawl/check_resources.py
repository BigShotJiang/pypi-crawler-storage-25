import asyncio
import logging
import time
from collections import defaultdict
from urllib.parse import urlparse

import aiohttp
from asyncpg import Record

from udata_hydra import config, context
from udata_hydra.crawl.helpers import (
    convert_headers,
    fix_surrogates,
    has_nice_head,
    is_domain_backoff,
)
from udata_hydra.crawl.preprocess_check_data import preprocess_check_data
from udata_hydra.db.resource import Resource
from udata_hydra.utils import queue
from udata_hydra.utils.http import CORS_HEADER_FIELDS, CORS_HEADER_PREFIX

RESOURCE_RESPONSE_STATUSES = {
    "OK": "ok",
    "TIMEOUT": "timeout",
    "ERROR": "error",
    "BACKOFF": "backoff",
}

log = logging.getLogger("udata-hydra")


results: defaultdict = defaultdict(int)


async def check_batch_resources(to_parse: list[Record]) -> None:
    """Check a batch of resources"""
    context.monitor().set_status("Checking resources...")
    tasks: list = []
    async with aiohttp.ClientSession(
        timeout=None,
        headers={"user-agent": config.USER_AGENT_FULL},
    ) as session:
        for row in to_parse:
            tasks.append(
                check_resource(
                    url=row["url"],
                    resource=row,
                    session=session,
                    worker_priority="default" if row["priority"] else "low",
                )
            )
        for task in asyncio.as_completed(tasks):
            result = await task
            results[result] += 1
            context.monitor().refresh(results)


async def check_resource(
    url: str,
    resource: Record,
    session,
    sleep: float = 0,
    method: str = "head",
    worker_priority: str = "default",
    force_analysis: bool = False,
) -> str:
    log.debug(f"check {url}, sleep {sleep}, method {method}")

    # Import here to avoid circular import issues
    from udata_hydra.analysis.resource import analyse_resource

    if sleep:
        await asyncio.sleep(sleep)

    url_parsed = urlparse(url)
    domain = url_parsed.netloc

    if not domain:
        log.warning(f"[warning] not netloc in url, skipping {url}")
        # Process the check data. If it has changed, it will be sent to udata
        await preprocess_check_data(
            dataset_id=resource["dataset_id"],
            check_data={
                "resource_id": str(resource["resource_id"]),
                "url": url,
                "error": "Not netloc in url",
                "timeout": False,
            },
        )
        return RESOURCE_RESPONSE_STATUSES["ERROR"]

    should_backoff, reason = await is_domain_backoff(domain)
    if should_backoff:
        log.info(f"backoff {domain} ({reason})")
        # skip this URL, it will come back in a next batch
        await Resource.update(
            str(resource["resource_id"]), data={"status": "BACKOFF", "priority": False}
        )
        return RESOURCE_RESPONSE_STATUSES["BACKOFF"]

    try:
        start = time.time()
        timeout = aiohttp.ClientTimeout(total=5)
        _method = getattr(session, method)
        async with _method(url, timeout=timeout, allow_redirects=True) as resp:
            end = time.time()
            if method != "get" and not has_nice_head(resp):
                return await check_resource(
                    url,
                    resource,
                    session,
                    force_analysis=force_analysis,
                    method="get",
                    worker_priority=worker_priority,
                )
            resp.raise_for_status()

            # Collect CORS headers via an OPTIONS preflight request before preprocessing check data.
            # Only store successful CORS probe results (status 200-399, no errors) in the database.
            # This filters out failed probes, timeouts, and non-permissive CORS configurations
            cors_probe_result: dict | None = await probe_cors(session, url)
            cors_headers: dict | None = None
            if cors_probe_result and not cors_probe_result.get("error"):
                status: int | None = cors_probe_result.get("status")
                if status is not None:
                    try:
                        # Only store CORS headers for successful preflight responses (2xx, 3xx status codes)
                        if 200 <= int(status) < 400:
                            cors_headers = {
                                "status": int(status),
                                "error": cors_probe_result.get("error"),
                                **{
                                    field: cors_probe_result.get(field)
                                    for field in CORS_HEADER_FIELDS
                                },
                            }
                    except (TypeError, ValueError):
                        # Skip invalid status values (should not happen, but handle gracefully)
                        pass

            # Preprocess the check data. If it has changed, it will be sent to udata
            new_check, last_check = await preprocess_check_data(
                dataset_id=resource["dataset_id"],
                check_data={
                    "resource_id": str(resource["resource_id"]),
                    "url": url,
                    "domain": domain,
                    "status": resp.status,
                    "headers": convert_headers(resp.headers),
                    "cors_headers": cors_headers,
                    "timeout": False,
                    "response_time": end - start,
                },
            )

            # Update resource status to TO_ANALYSE_RESOURCE
            await Resource.update(
                str(resource["resource_id"]), data={"status": "TO_ANALYSE_RESOURCE"}
            )

            # Enqueue the resource for analysis
            queue.enqueue(
                analyse_resource,
                check=new_check,
                last_check=last_check,
                force_analysis=force_analysis,
                worker_priority=worker_priority,
                _priority=worker_priority,
            )

            return RESOURCE_RESPONSE_STATUSES["OK"]

    except asyncio.exceptions.TimeoutError:
        # Process the check data. If it has changed, it will be sent to udata
        await preprocess_check_data(
            dataset_id=resource["dataset_id"],
            check_data={
                "resource_id": str(resource["resource_id"]),
                "url": url,
                "domain": domain,
                "timeout": True,
            },
        )

        # Reset resource status so that it's not forbidden to be checked again
        await Resource.update(str(resource["resource_id"]), data={"status": None})

        return RESOURCE_RESPONSE_STATUSES["TIMEOUT"]

    # Catch HTTP/HTTPS errors and related exceptions:
    # - ClientError: covers all aiohttp client exceptions (connection, SSL, DNS, etc.)
    # - AssertionError: can occur in aiohttp connector (e.g., "assert port is not None" in connector.py:991)
    # - UnicodeError: can occur when encoding domain names with IDNA codec (e.g., "label too long")
    #   Example problematic URL: http://%20Localisation%20des%20acc%C3%A8s%20des%20offices%20de%20tourisme
    # All errors are logged and saved to the database via preprocess_check_data()
    except (
        aiohttp.ClientError,
        AssertionError,
        UnicodeError,
    ) as e:
        # if we get a 404, it might be that the resource's URL has changed since last catalog load
        # we compare the actual URL to the one we have here to handle these cases
        if getattr(e, "status", None) == 404 and config.UDATA_URI:
            handled = await handle_wrong_resource_url(
                resource,
                session,
                url,
                force_analysis,
                worker_priority,
            )
            if handled is not None:
                return handled

        error = getattr(e, "message", None) or str(e)
        # Process the check data. If it has changed, it will be sent to udata
        await preprocess_check_data(
            dataset_id=resource["dataset_id"],
            check_data={
                "resource_id": str(resource["resource_id"]),
                "url": url,
                "domain": domain,
                "timeout": False,
                "error": fix_surrogates(error),
                "headers": convert_headers(getattr(e, "headers", {})),
                "status": getattr(e, "status", None),
            },
        )

        log.warning(f"Crawling error for url {url}", exc_info=e)

        # Reset resource status so that it's not forbidden to be checked again
        await Resource.update(str(resource["resource_id"]), data={"status": None})

        return RESOURCE_RESPONSE_STATUSES["ERROR"]


async def handle_wrong_resource_url(
    resource: Record,
    session,
    url: str,
    force_analysis: bool,
    worker_priority: str,
):
    resource_id = resource["resource_id"]
    stable_resource_url = f"{config.UDATA_URI.replace('api/2', 'api/1')}/datasets/r/{resource_id}"
    async with session.head(stable_resource_url) as resp:
        resp.raise_for_status()
        actual_url = resp.headers.get("location")
    if actual_url and url != actual_url:
        await Resource.update(resource_id, data={"url": actual_url})
        return await check_resource(
            actual_url,
            resource,
            session,
            force_analysis=force_analysis,
            method="head",
            worker_priority=worker_priority,
        )
    return


async def probe_cors(session, url: str) -> dict | None:
    """Send an OPTIONS preflight to collect CORS headers, skipping requests that lack a configured origin."""
    origin: str | None = getattr(config, "CORS_PROBE_ORIGIN", None)
    if not origin:
        return None

    request_headers: dict[str, str] = {
        "Origin": origin,
        "Access-Control-Request-Method": "GET",
    }
    request_header_names: list[str] | None = getattr(config, "CORS_PROBE_REQUEST_HEADERS", None)
    if request_header_names:
        request_headers["Access-Control-Request-Headers"] = ",".join(request_header_names)

    timeout_seconds = int(getattr(config, "CORS_PROBE_TIMEOUT_SECONDS", 5) or 5)
    probe_timeout = aiohttp.ClientTimeout(total=timeout_seconds)

    try:
        async with session.options(
            url,
            headers=request_headers,
            timeout=probe_timeout,
            allow_redirects=True,
        ) as cors_resp:
            cors_headers = convert_headers(cors_resp.headers)
            return {
                "status": cors_resp.status,
                **{
                    field: cors_headers.get(f"{CORS_HEADER_PREFIX}{field}")
                    for field in CORS_HEADER_FIELDS
                },
            }
    except asyncio.TimeoutError:
        return {"status": None, "error": "timeout"}
    except aiohttp.ClientError as exc:
        error: str = getattr(exc, "message", None) or str(exc)
        status: int | None = getattr(exc, "status", None)
        return {"status": status, "error": fix_surrogates(error)}
