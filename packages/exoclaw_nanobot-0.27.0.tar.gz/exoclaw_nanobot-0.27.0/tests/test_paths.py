"""Tests for exoclaw_nanobot.config.paths — ported from nanobot test_config_paths.py."""

from __future__ import annotations

from pathlib import Path

from exoclaw_nanobot.config.paths import (
    get_bridge_install_dir,
    get_cli_history_path,
    get_cron_dir,
    get_data_dir,
    get_legacy_sessions_dir,
    get_logs_dir,
    get_media_dir,
    get_runtime_subdir,
    get_workspace_path,
)


def test_runtime_dirs_follow_config_path(monkeypatch: object, tmp_path: Path) -> None:
    config_file = tmp_path / "instance-a" / "config.json"
    import exoclaw_nanobot.config.paths as _paths

    assert isinstance(monkeypatch, object)
    import unittest.mock as _mock

    with _mock.patch.object(_paths, "get_config_path", return_value=config_file):
        assert get_data_dir() == config_file.parent
        assert get_runtime_subdir("cron") == config_file.parent / "cron"
        assert get_cron_dir() == config_file.parent / "cron"
        assert get_logs_dir() == config_file.parent / "logs"


def test_media_dir_supports_channel_namespace(tmp_path: Path) -> None:
    config_file = tmp_path / "instance-b" / "config.json"
    import unittest.mock as _mock

    import exoclaw_nanobot.config.paths as _paths

    with _mock.patch.object(_paths, "get_config_path", return_value=config_file):
        assert get_media_dir() == config_file.parent / "media"
        assert get_media_dir("telegram") == config_file.parent / "media" / "telegram"


def test_shared_and_legacy_paths_remain_global() -> None:
    assert get_cli_history_path() == Path.home() / ".nanobot" / "history" / "cli_history"
    assert get_bridge_install_dir() == Path.home() / ".nanobot" / "bridge"
    assert get_legacy_sessions_dir() == Path.home() / ".nanobot" / "sessions"


def test_workspace_path_is_explicitly_resolved() -> None:
    assert get_workspace_path() == Path.home() / ".nanobot" / "workspace"
    assert get_workspace_path("~/custom-workspace") == Path.home() / "custom-workspace"


def test_ensure_dir_creates_directories(tmp_path: Path) -> None:
    config_file = tmp_path / "deep" / "nested" / "config.json"
    import unittest.mock as _mock

    import exoclaw_nanobot.config.paths as _paths

    with _mock.patch.object(_paths, "get_config_path", return_value=config_file):
        data = get_data_dir()
        assert data.exists()
        assert data.is_dir()
