from abc import abstractmethod
from typing import Generic, Iterable, Mapping, TypeVar, Union

from typing_extensions import Protocol, Self

from tp_interfaces.abstract.configuration.factory import ModelTypeFactory
from tp_interfaces.abstract.model import AbstractConfigConstructableModel
from tp_interfaces.abstract.model.composite import AbstractAsyncCompositeModel
from tp_interfaces.abstract.schema import ImmutableBaseModel
from .processor import AbstractProcessor


class UnionDeployConfig(ImmutableBaseModel):
    models: dict[str, dict]


_Config = TypeVar('_Config', bound=ImmutableBaseModel)
_Input = TypeVar('_Input')
_Output = TypeVar('_Output')


class ConfigurableModelWrapperProtocol(
    AbstractProcessor[_Config, _Input, _Output],
    AbstractConfigConstructableModel[Self],
    Protocol[_Config, _Input, _Output]
):
    pass


class AbstractUnionProcessorWrapper(
    AbstractAsyncCompositeModel[ConfigurableModelWrapperProtocol[_Config, _Input, _Output]],
    ConfigurableModelWrapperProtocol[_Config, _Input, _Output],
    Generic[_Config, _Input, _Output]
):
    def __init__(self, models: Iterable[ConfigurableModelWrapperProtocol[_Config, _Input, _Output]]):
        AbstractAsyncCompositeModel.__init__(self, models)

        self._config_type: type[_Config] | None = None
        self._models_mapping: Mapping[type[_Config], ConfigurableModelWrapperProtocol[_Config, _Input, _Output]] | None = None

    @classmethod
    @abstractmethod
    def _model_factories(cls) -> ModelTypeFactory[ConfigurableModelWrapperProtocol[_Config, _Input, _Output]]:
        pass

    async def __aenter__(self):
        await super().__aenter__()

        self._models_mapping = {model.config_type: model for model in self._models}
        config_types = tuple(self._models_mapping)
        if len(config_types) == 1:
            self._config_type = config_types[0]
        else:
            self._config_type = Union[config_types]

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._config_type = None
        self._models_mapping = None
        await super().__aexit__(exc_type, exc_val, exc_tb)

    @property
    def config_type(self) -> type[_Config]:
        if self._config_type is None:
            raise AttributeError
        return self._config_type

    async def process_doc(self, document: _Input, config: _Config) -> _Output:
        config_type = type(config)
        model = self._models_mapping[config_type]
        return await model.process_doc(document, config)

    @classmethod
    def from_config(cls, config: dict) -> Self:
        config = UnionDeployConfig.model_validate(config)
        type_factories = cls._model_factories()
        return cls(type_factories[name].from_config(cfg) for name, cfg in config.models.items())
