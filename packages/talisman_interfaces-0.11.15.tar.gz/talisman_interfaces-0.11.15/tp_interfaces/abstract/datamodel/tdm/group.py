import uuid
from dataclasses import dataclass

from tdm import TalismanDocument


@dataclass(frozen=True)
class TalismanDocumentGroup:
    documents: tuple[TalismanDocument, ...]
    id: str | None = None

    def __post_init__(self):
        if self.id is None:
            object.__setattr__(self, "id", str(uuid.uuid4()))
