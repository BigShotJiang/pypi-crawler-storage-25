import uuid
from dataclasses import dataclass


@dataclass(frozen=True)
class ConceptGroup:
    user_id: str
    concept_ids: tuple[str, ...]

    id: str | None = None

    def __post_init__(self):
        if self.id is None:
            object.__setattr__(self, "id", str(uuid.uuid4()))
