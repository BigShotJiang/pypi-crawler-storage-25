# vidit

A versatile Python library with multiple modules for different purposes.

# Installation:
```bash
pip install vidit
```

## Modules

### 1. PyQt5 Wrapper (pyqtm)

A simple PyQt5 wrapper with fluent chain-call API for easy GUI development.

**Features:**
- Chain calling support for cleaner code
- 20+ widgets including Label, Button, Input, Table
- Coordinate-based layout, simple and intuitive
- Window styling: background, fonts, opacity

**Quick Start:**
```python
import vidit

vidit.check()

vidit.pyqtm.create().show()
```

**Available Widgets:**
- Basic: label, button, input, textarea
- Selection: check, radio, combo
- Number: spin, dspin, slider, progress, dial, lcd
- Container: group, frame, tab, scroll
- Data: listwidget, table, tree
- Date/Time: dateedit, timeedit, datetimeedit

### 2. File Checker (check)

A utility module for checking required files in the project directory.

## License

MIT License
