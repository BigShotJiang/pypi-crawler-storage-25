from distutils.core import setup
setup(name="vidit", version="1.0.2", author="smellem")