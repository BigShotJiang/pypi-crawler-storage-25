import os
import inspect


caller_path = inspect.stack()[1].filename
root = os.path.dirname(os.path.abspath(caller_path))
a = [".vidit","init.py",".for"]
for f in a:
    if not os.path.exists(os.path.join(root,f)):
        print("not exist",f)

exit(1)