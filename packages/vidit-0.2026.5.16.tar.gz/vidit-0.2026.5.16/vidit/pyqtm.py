from PyQt5.QtWidgets import (QApplication,QWidget,QLabel,QPushButton,QLineEdit,QTextEdit,QCheckBox,
                             QRadioButton,QComboBox,QSpinBox,QDoubleSpinBox,QSlider,QProgressBar,
                             QGroupBox,QFrame,QDateEdit,QTimeEdit,QDateTimeEdit,QListWidget,
                             QTableWidget,QTreeWidget,QTabWidget,QScrollArea,QDial,QLCDNumber)
from PyQt5.QtCore import Qt,QDate,QTime,QDateTime
from PyQt5.QtGui import QFont

class Window:
    def __init__(self):
        self.app=QApplication([])
        self.win=QWidget()
        self.widgets={}
        self.win_font=QFont()

    def size(self,w,h):
        self.win.resize(w,h)
        return self
    def title(self,t):
        self.win.setWindowTitle(t)
        return self
    def pos(self,x,y):
        self.win.move(x,y)
        return self
    def bg(self,c):
        self.win.setStyleSheet(f"background-color:{c}")
        return self
    def font(self,family,size,bold=False):
        self.win_font.setFamily(family)
        self.win_font.setPointSize(size)
        self.win_font.setBold(bold)
        self.win.setFont(self.win_font)
        return self
    def opacity(self,val):
        self.win.setWindowOpacity(val)
        return self
    def resizable(self,flag):
        self.win.setFixedSize(self.win.size()) if not flag else None
        return self

    def label(self,name,text,x,y,w,h,align=Qt.AlignLeft):
        l=QLabel(text,self.win)
        l.setGeometry(x,y,w,h)
        l.setAlignment(align)
        self.widgets[name]=l
        return self
    def button(self,name,text,x,y,w,h,func=None):
        b=QPushButton(text,self.win)
        b.setGeometry(x,y,w,h)
        if func:b.clicked.connect(func)
        self.widgets[name]=b
        return self
    def input(self,name,x,y,w,h,placeholder=""):
        i=QLineEdit(self.win)
        i.setGeometry(x,y,w,h)
        i.setPlaceholderText(placeholder)
        self.widgets[name]=i
        return self
    def textarea(self,name,x,y,w,h):
        t=QTextEdit(self.win)
        t.setGeometry(x,y,w,h)
        self.widgets[name]=t
        return self
    def check(self,name,text,x,y,w,h):
        c=QCheckBox(text,self.win)
        c.setGeometry(x,y,w,h)
        self.widgets[name]=c
        return self
    def radio(self,name,text,x,y,w,h):
        r=QRadioButton(text,self.win)
        r.setGeometry(x,y,w,h)
        self.widgets[name]=r
        return self
    def combo(self,name,x,y,w,h,items=[]):
        cb=QComboBox(self.win)
        cb.setGeometry(x,y,w,h)
        cb.addItems(items)
        self.widgets[name]=cb
        return self
    def spin(self,name,x,y,w,h,min=0,max=100,val=0):
        s=QSpinBox(self.win)
        s.setGeometry(x,y,w,h)
        s.setRange(min,max)
        s.setValue(val)
        self.widgets[name]=s
        return self
    def dspin(self,name,x,y,w,h,min=0,max=100,val=0,dec=2):
        ds=QDoubleSpinBox(self.win)
        ds.setGeometry(x,y,w,h)
        ds.setRange(min,max)
        ds.setValue(val)
        ds.setDecimals(dec)
        self.widgets[name]=ds
        return self
    def slider(self,name,x,y,w,h,min=0,max=100,ori=Qt.Horizontal):
        sl=QSlider(ori,self.win)
        sl.setGeometry(x,y,w,h)
        sl.setRange(min,max)
        self.widgets[name]=sl
        return self
    def progress(self,name,x,y,w,h,val=0):
        p=QProgressBar(self.win)
        p.setGeometry(x,y,w,h)
        p.setValue(val)
        self.widgets[name]=p
        return self
    def group(self,name,title,x,y,w,h):
        g=QGroupBox(title,self.win)
        g.setGeometry(x,y,w,h)
        self.widgets[name]=g
        return self
    def frame(self,name,x,y,w,h):
        f=QFrame(self.win)
        f.setGeometry(x,y,w,h)
        self.widgets[name]=f
        return self
    def dateedit(self,name,x,y,w,h):
        d=QDateEdit(QDate.currentDate(),self.win)
        d.setGeometry(x,y,w,h)
        self.widgets[name]=d
        return self
    def timeedit(self,name,x,y,w,h):
        t=QTimeEdit(QTime.currentTime(),self.win)
        t.setGeometry(x,y,w,h)
        self.widgets[name]=t
        return self
    def datetimeedit(self,name,x,y,w,h):
        dt=QDateTimeEdit(QDateTime.currentDateTime(),self.win)
        dt.setGeometry(x,y,w,h)
        self.widgets[name]=dt
        return self
    def listwidget(self,name,x,y,w,h,items=[]):
        lw=QListWidget(self.win)
        lw.setGeometry(x,y,w,h)
        lw.addItems(items)
        self.widgets[name]=lw
        return self
    def table(self,name,x,y,w,h,rows=5,cols=3):
        tb=QTableWidget(rows,cols,self.win)
        tb.setGeometry(x,y,w,h)
        self.widgets[name]=tb
        return self
    def tree(self,name,x,y,w,h):
        tr=QTreeWidget(self.win)
        tr.setGeometry(x,y,w,h)
        self.widgets[name]=tr
        return self
    def tab(self,name,x,y,w,h):
        tb=QTabWidget(self.win)
        tb.setGeometry(x,y,w,h)
        self.widgets[name]=tb
        return self
    def scroll(self,name,x,y,w,h):
        sc=QScrollArea(self.win)
        sc.setGeometry(x,y,w,h)
        self.widgets[name]=sc
        return self
    def dial(self,name,x,y,w,h,min=0,max=100):
        d=QDial(self.win)
        d.setGeometry(x,y,w,h)
        d.setRange(min,max)
        self.widgets[name]=d
        return self
    def lcd(self,name,x,y,w,h,num=0):
        lcd=QLCDNumber(self.win)
        lcd.setGeometry(x,y,w,h)
        lcd.display(num)
        self.widgets[name]=lcd
        return self

    def get(self,name):
        return self.widgets.get(name)
    def show(self):
        self.win.show()
        self.app.exec_()

def create():
    return Window()