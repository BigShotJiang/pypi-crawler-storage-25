"""ArcadeDB interface -- read/write for the symbol knowledge graph (server mode).

Drop-in replacement for GraphStore (graph.py). Identical public method
signatures; internals use the arcadedb-python HTTP client against an external
ArcadeDB server process rather than KuzuDB.

Architecture
------------
All projects and branches share a single "codegraph" ArcadeDB database.
Isolation is achieved via two properties on every vertex:

  * ``branch``     — owning branch (e.g. "main", "feature/auth")
  * ``project_id`` — owning project (server-assigned, e.g. "myrepo")

Together (branch, project_id) forms the scope for every read and write.
Two projects can both have a "main" branch without data leakage.

  * **Reads** — try (branch, project_id) first, fall back to (parent_branch, project_id).
  * **Writes** — always write with branch=current_branch, project_id=self._project_id.

Composite indexes (id, branch) and (project_id, branch) allow efficient
per-project/branch lookups without full-table scans.

Key API differences from KuzuDB
--------------------------------
  - Connection: SyncClient(host, port) + DatabaseDao(client, "codegraph")
  - Reads:  db.query("sql", stmt)                    → list[dict]
  - Writes: db.query("sql", stmt, is_command=True)   → side-effecting
  - TX:     session_id = db.begin_transaction()
            db.query("sql", stmt, session_id=sid, is_command=True)
            db.commit_transaction(session_id)
            db.rollback_transaction(session_id)
  - Upsert: UPDATE Type SET ... UPSERT WHERE col='x' AND branch='b'
  - Edges:  SELECT @out.id, @in.id FROM EdgeType
  - BFS:    SELECT @out.id AS caller_id FROM Calls WHERE @in.id IN [...]
  - Delete: DELETE VERTEX FROM Symbol WHERE ...

Windows paths
-------------
  _esc() must escape backslashes BEFORE single quotes — always.
  C:\\Users\\... → C:\\\\Users\\\\...
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_BATCH = 500  # rows per transaction for bulk upserts

from ravmem.storage.schema import (
    ARCADE_DDL,
    Cluster,
    Edge,
    File,
    Symbol,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


class ArcadeGraphStore:
    """ArcadeDB-backed graph store with the same public API as GraphStore.

    Parameters
    ----------
    branch:
        The current branch name. All writes are tagged with this branch.
    parent_branch:
        The parent branch for CoW fallback reads. When a symbol is not found
        in ``branch``, the store transparently falls back to ``parent_branch``.
        Pass ``None`` for the default/main branch.
    """

    # Maps edge kind strings to ArcadeDB edge type names
    _EDGE_TYPE = {
        "calls": "Calls",
        "imports": "Imports",
        "inherits": "Inherits",
        "belongs_to": "BelongsTo",
        "contains": "Contains",
    }

    def __init__(
        self,
        branch: str,
        parent_branch: str | None = None,
        project_id: str = "default",
    ) -> None:
        from arcadedb_python import DatabaseDao, SyncClient
        from ravmem.config import ARCADE_DB_NAME, ARCADEDB_HOST, ARCADEDB_PASSWORD, ARCADEDB_PORT

        self._branch = branch
        self._parent_branch = parent_branch
        self._project_id = project_id
        # Per-thread transaction state — each thread has its own active session ID
        # so concurrent requests don't share or corrupt each other's TX handles.
        self._local = threading.local()

        client = SyncClient(ARCADEDB_HOST, ARCADEDB_PORT, username="root", password=ARCADEDB_PASSWORD)

        # Create the database if it doesn't exist yet (idempotent)
        if not DatabaseDao.exists(client, ARCADE_DB_NAME):
            DatabaseDao.create(client, ARCADE_DB_NAME)
            logger.info("Created ArcadeDB database '%s'", ARCADE_DB_NAME)

        self._db = DatabaseDao(client, ARCADE_DB_NAME)

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def initialize_schema(self) -> None:
        for stmt in ARCADE_DDL:
            try:
                self._db.query("sql", stmt, is_command=True)
            except Exception as exc:
                msg = str(exc).lower()
                if "already exist" in msg or "duplicate" in msg:
                    pass
                else:
                    logger.warning("DDL statement failed (non-fatal): %s — stmt: %.120s", exc, stmt)

    # ------------------------------------------------------------------
    # Transaction support
    # ------------------------------------------------------------------

    @property
    def _active_tx(self) -> str | None:
        return getattr(self._local, "tx", None)

    @_active_tx.setter
    def _active_tx(self, value: str | None) -> None:
        self._local.tx = value

    def begin_transaction(self) -> str:
        """Start a new transaction; all subsequent _cmd/_cmd_batch calls on this thread use it."""
        self._active_tx = self._db.begin_transaction()
        return self._active_tx

    def commit_transaction(self, session_id: str) -> None:
        """Commit the transaction. Clears the active TX state for this thread."""
        self._db.commit_transaction(session_id)
        if self._active_tx == session_id:
            self._active_tx = None

    def rollback_transaction(self, session_id: str) -> None:
        """Roll back the transaction. Clears the active TX state for this thread."""
        self._db.rollback_transaction(session_id)
        if self._active_tx == session_id:
            self._active_tx = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _q(self, sql: str) -> list[dict]:
        """Execute a read query and return list[dict]."""
        return self._db.query("sql", sql)

    def _cmd(self, sql: str, session_id: str | None = None) -> None:
        """Execute a write command.

        Uses session_id if provided, then self._active_tx if set, then
        auto-commits in its own single-statement transaction.
        """
        sid = session_id or self._active_tx
        if sid is not None:
            self._db.query("sql", sql, session_id=sid, is_command=True)
        else:
            self._db.query("sql", sql, is_command=True)

    def _cmd_batch(self, stmts: list[str], session_id: str | None = None) -> None:
        """Execute multiple write commands in a single transaction.

        If an active transaction is already open (session_id or self._active_tx),
        commands are appended to it. Otherwise a new auto-committed transaction
        is opened just for this batch.
        """
        if not stmts:
            return
        sid = session_id or self._active_tx
        if sid is not None:
            # Run inside the caller's (or active) transaction
            for sql in stmts:
                self._db.query("sql", sql, session_id=sid, is_command=True)
        else:
            # Auto-transaction: open, run, commit (or rollback on error)
            new_sid = self._db.begin_transaction()
            try:
                for sql in stmts:
                    self._db.query("sql", sql, session_id=new_sid, is_command=True)
                self._db.commit_transaction(new_sid)
            except Exception:
                self._db.rollback_transaction(new_sid)
                raise

    @staticmethod
    def _esc(value: str | None) -> str:
        """Escape backslashes and single quotes for inline ArcadeDB SQL.

        ArcadeDB SQL uses C-style escapes inside string literals:
          backslash  → \\\\  (must be doubled BEFORE single-quote escaping)
          single quote → \\'
        Windows paths like C:\\Users\\... break SQL if backslashes aren't doubled.
        None → empty string.
        """
        if not value:
            return ""
        # Backslashes first, then single quotes, then newlines — all break ArcadeDB SQL strings
        return (value.replace("\\", "\\\\")
                     .replace("'", "\\'")
                     .replace("\r\n", "\\n")
                     .replace("\n", "\\n")
                     .replace("\r", "\\n"))

    def _row_to_symbol(self, row: dict[str, Any]) -> Symbol:
        return Symbol(
            id=row["id"],
            name=row["name"],
            kind=row["kind"],
            file=row["file"],
            line_start=int(row.get("line_start") or 0),
            line_end=int(row.get("line_end") or 0),
            lang=row["lang"],
            cluster_id=row.get("cluster_id") or "",
            embedding_id=int(row.get("embedding_id") or -1),
            docstring=row.get("docstring") or "",
        )

    def _row_to_cluster(self, row: dict[str, Any]) -> Cluster:
        return Cluster(
            id=row["id"],
            label=row["label"],
            cohesion_score=float(row.get("cohesion_score") or 0.0),
            size=int(row.get("size") or 0),
        )

    def _bpf(self, branch: str | None = None) -> str:
        """Return 'branch=B AND project_id=P' for a single branch.

        Used in all point-lookup WHERE clauses to scope queries to both the
        correct branch and the correct project — preventing cross-project
        data leakage in the shared ArcadeDB database.
        """
        b = self._esc(branch or self._branch)
        p = self._esc(self._project_id)
        return f"branch='{b}' AND project_id='{p}'"

    def _branch_filter(self, include_parent: bool = True) -> str:
        """Return SQL IN clause for branch(es): 'IN [b1, b2]'.

        Used only in edge queries where the vertex alias is supplied externally
        (e.g. @out.branch {_branch_filter()}).  Project scoping for edge queries
        must be added at the call site as @alias.project_id='P'.
        """
        branches = [f"'{self._esc(self._branch)}'"]
        if include_parent and self._parent_branch:
            branches.append(f"'{self._esc(self._parent_branch)}'")
        return f"IN [{', '.join(branches)}]"

    # ------------------------------------------------------------------
    # Writes — Files
    # ------------------------------------------------------------------

    def _file_upsert_sql(self, f: File) -> str:
        now = _now_iso()
        return (
            f"UPDATE File SET path='{self._esc(f.path)}', lang='{self._esc(f.lang)}', "
            f"size_kb={f.size_kb}, checksum='{self._esc(f.checksum)}', "
            f"branch='{self._esc(self._branch)}', project_id='{self._esc(self._project_id)}', "
            f"branch_updated_at='{now}' "
            f"UPSERT WHERE path='{self._esc(f.path)}' AND {self._bpf()}"
        )

    def upsert_file(self, f: File) -> None:
        self._cmd(self._file_upsert_sql(f))

    def upsert_files(self, files: list[File]) -> None:
        for i in range(0, len(files), _BATCH):
            batch = files[i:i + _BATCH]
            stmts = [self._file_upsert_sql(f) for f in batch]
            self._cmd_batch(stmts)
            logger.info("  [graph] upsert_files: %d/%d", min(i + _BATCH, len(files)), len(files))

    # ------------------------------------------------------------------
    # Writes — Symbols
    # ------------------------------------------------------------------

    def _symbol_upsert_sql(self, s: Symbol) -> str:
        """Build branch- and project-aware UPDATE...UPSERT SQL for a Symbol."""
        doc = self._esc(s.docstring)
        now = _now_iso()
        return (
            f"UPDATE Symbol SET "
            f"id='{self._esc(s.id)}', name='{self._esc(s.name)}', kind='{self._esc(s.kind)}', "
            f"file='{self._esc(s.file)}', line_start={s.line_start}, line_end={s.line_end}, "
            f"lang='{self._esc(s.lang)}', cluster_id='{self._esc(s.cluster_id)}', "
            f"embedding_id={s.embedding_id}, docstring='{doc}', "
            f"branch='{self._esc(self._branch)}', project_id='{self._esc(self._project_id)}', "
            f"branch_updated_at='{now}' "
            f"UPSERT WHERE id='{self._esc(s.id)}' AND {self._bpf()}"
        )

    def upsert_symbol(self, s: Symbol) -> None:
        self._cmd(self._symbol_upsert_sql(s))

    def upsert_symbols(self, symbols: list[Symbol]) -> None:
        for i in range(0, len(symbols), _BATCH):
            batch = symbols[i:i + _BATCH]
            stmts = [self._symbol_upsert_sql(s) for s in batch]
            self._cmd_batch(stmts)
            logger.info("  [graph] upsert_symbols: %d/%d", min(i + _BATCH, len(symbols)), len(symbols))

    # ------------------------------------------------------------------
    # Writes — Clusters
    # ------------------------------------------------------------------

    def _cluster_upsert_sql(self, c: Cluster) -> str:
        return (
            f"UPDATE Cluster SET "
            f"id='{self._esc(c.id)}', label='{self._esc(c.label)}', "
            f"cohesion_score={c.cohesion_score}, size={c.size}, "
            f"branch='{self._esc(self._branch)}', project_id='{self._esc(self._project_id)}' "
            f"UPSERT WHERE id='{self._esc(c.id)}' AND {self._bpf()}"
        )

    def upsert_cluster(self, c: Cluster) -> None:
        self._cmd(self._cluster_upsert_sql(c))

    def upsert_clusters(self, clusters: list[Cluster]) -> None:
        total = len(clusters)
        for i in range(0, total, _BATCH):
            batch = clusters[i:i + _BATCH]
            stmts = [self._cluster_upsert_sql(c) for c in batch]
            self._cmd_batch(stmts)
            logger.info("  [graph] upsert_clusters: %d/%d", min(i + _BATCH, total), total)

    def update_symbol_cluster(self, symbol_id: str, cluster_id: str) -> None:
        self._cmd(
            f"UPDATE Symbol SET cluster_id='{self._esc(cluster_id)}' "
            f"WHERE id='{self._esc(symbol_id)}' AND {self._bpf()}"
        )

    def update_symbol_embedding_id(self, symbol_id: str, embedding_id: int) -> None:
        self._cmd(
            f"UPDATE Symbol SET embedding_id={embedding_id} "
            f"WHERE id='{self._esc(symbol_id)}' AND {self._bpf()}"
        )

    def update_symbol_clusters_bulk(self, updates: list[tuple[str, str]]) -> None:
        """Set cluster_id on many symbols at once. updates = [(symbol_id, cluster_id), ...]"""
        bpf = self._bpf()
        total = len(updates)
        for i in range(0, total, _BATCH):
            batch = updates[i:i + _BATCH]
            stmts = [
                f"UPDATE Symbol SET cluster_id='{self._esc(cid)}' "
                f"WHERE id='{self._esc(sid)}' AND {bpf}"
                for sid, cid in batch
            ]
            self._cmd_batch(stmts)
            logger.info("  [graph] cluster_id update: %d/%d", min(i + _BATCH, total), total)

    def update_symbol_embedding_ids_bulk(self, updates: list[tuple[str, int]]) -> None:
        """Set embedding_id on many symbols at once. updates = [(symbol_id, embedding_id), ...]"""
        bpf = self._bpf()
        total = len(updates)
        for i in range(0, total, _BATCH):
            batch = updates[i:i + _BATCH]
            stmts = [
                f"UPDATE Symbol SET embedding_id={eid} "
                f"WHERE id='{self._esc(sid)}' AND {bpf}"
                for sid, eid in batch
            ]
            self._cmd_batch(stmts)
            logger.info("  [graph] embedding_id update: %d/%d", min(i + _BATCH, total), total)

    # ------------------------------------------------------------------
    # Writes — Edges
    # ------------------------------------------------------------------

    def upsert_edge(self, edge: Edge) -> None:
        edge_type = self._EDGE_TYPE.get(edge.kind)
        if edge_type is None:
            return

        bpf = self._bpf()

        if edge.kind == "calls":
            src_type, dst_type = "Symbol", "Symbol"
            src_where = f"id='{self._esc(edge.src_id)}' AND {bpf}"
            dst_where = f"id='{self._esc(edge.dst_id)}' AND {bpf}"
            props = f"SET confidence={edge.confidence}, resolved={str(edge.resolved).lower()}"
        elif edge.kind == "imports":
            src_type, dst_type = "File", "File"
            src_where = f"path='{self._esc(edge.src_id)}' AND {bpf}"
            dst_where = f"path='{self._esc(edge.dst_id)}' AND {bpf}"
            props = f"SET binding='{self._esc(edge.binding)}'"
        elif edge.kind == "inherits":
            src_type, dst_type = "Symbol", "Symbol"
            src_where = f"id='{self._esc(edge.src_id)}' AND {bpf}"
            dst_where = f"id='{self._esc(edge.dst_id)}' AND {bpf}"
            props = ""
        elif edge.kind == "belongs_to":
            src_type, dst_type = "Symbol", "Cluster"
            src_where = f"id='{self._esc(edge.src_id)}' AND {bpf}"
            dst_where = f"id='{self._esc(edge.dst_id)}' AND {bpf}"
            props = f"SET branch='{self._esc(self._branch)}', project_id='{self._esc(self._project_id)}'"
        elif edge.kind == "contains":
            src_type, dst_type = "File", "Symbol"
            src_where = f"path='{self._esc(edge.src_id)}' AND {bpf}"
            dst_where = f"id='{self._esc(edge.dst_id)}' AND {bpf}"
            props = ""
        else:
            return

        sql = (
            f"CREATE EDGE {edge_type} "
            f"FROM (SELECT FROM {src_type} WHERE {src_where}) "
            f"TO (SELECT FROM {dst_type} WHERE {dst_where}) "
            f"{props}"
        ).strip()
        try:
            self._cmd(sql)
        except Exception as exc:
            logger.debug("upsert_edge skip (src/dst missing): %s", exc)

    def upsert_edges(self, edges: list[Edge]) -> None:
        by_kind: dict[str, list[Edge]] = {}
        for e in edges:
            by_kind.setdefault(e.kind, []).append(e)

        bpf = self._bpf()
        proj_q = self._esc(self._project_id)

        for kind, group in by_kind.items():
            for i in range(0, len(group), _BATCH):
                batch = group[i:i + _BATCH]
                stmts = []
                for e in batch:
                    edge_type = self._EDGE_TYPE.get(e.kind)
                    if edge_type is None:
                        continue
                    if e.kind == "calls":
                        stmts.append(
                            f"CREATE EDGE Calls "
                            f"FROM (SELECT FROM Symbol WHERE id='{self._esc(e.src_id)}' AND {bpf}) "
                            f"TO (SELECT FROM Symbol WHERE id='{self._esc(e.dst_id)}' AND {bpf}) "
                            f"SET confidence={e.confidence}, resolved={str(e.resolved).lower()}"
                        )
                    elif e.kind == "imports":
                        stmts.append(
                            f"CREATE EDGE Imports "
                            f"FROM (SELECT FROM File WHERE path='{self._esc(e.src_id)}' AND {bpf}) "
                            f"TO (SELECT FROM File WHERE path='{self._esc(e.dst_id)}' AND {bpf}) "
                            f"SET binding='{self._esc(e.binding)}'"
                        )
                    elif e.kind == "inherits":
                        stmts.append(
                            f"CREATE EDGE Inherits "
                            f"FROM (SELECT FROM Symbol WHERE id='{self._esc(e.src_id)}' AND {bpf}) "
                            f"TO (SELECT FROM Symbol WHERE id='{self._esc(e.dst_id)}' AND {bpf})"
                        )
                    elif e.kind == "belongs_to":
                        stmts.append(
                            f"CREATE EDGE BelongsTo "
                            f"FROM (SELECT FROM Symbol WHERE id='{self._esc(e.src_id)}' AND {bpf}) "
                            f"TO (SELECT FROM Cluster WHERE id='{self._esc(e.dst_id)}' AND {bpf}) "
                            f"SET branch='{self._esc(self._branch)}', project_id='{proj_q}'"
                        )
                    elif e.kind == "contains":
                        stmts.append(
                            f"CREATE EDGE Contains "
                            f"FROM (SELECT FROM File WHERE path='{self._esc(e.src_id)}' AND {bpf}) "
                            f"TO (SELECT FROM Symbol WHERE id='{self._esc(e.dst_id)}' AND {bpf})"
                        )

                if stmts:
                    try:
                        self._cmd_batch(stmts)
                    except Exception as exc:
                        logger.debug("Bulk edge upsert failed for kind=%s, falling back: %s", kind, exc)
                        for e in batch:
                            try:
                                self.upsert_edge(e)
                            except Exception:
                                pass

    def bulk_insert_edges(self, edges: list[Edge]) -> None:
        """Bulk insert edges for full re-index.

        Clears existing branch-local edges of each kind, then re-inserts.
        Only deletes edges whose endpoint vertices belong to the current branch
        — parent-branch edges are left untouched.
        """
        if not edges:
            return

        # Filter out file-path IDs (fallback from _nearest_symbol_id)
        valid: list[Edge] = []
        for e in edges:
            if e.kind in ("calls", "inherits") and (
                "/" in e.src_id or "\\" in e.src_id
                or "/" in e.dst_id or "\\" in e.dst_id
            ):
                continue
            valid.append(e)

        by_kind: dict[str, list[Edge]] = {}
        for e in valid:
            by_kind.setdefault(e.kind, []).append(e)

        branch_q = self._esc(self._branch)
        proj_q = self._esc(self._project_id)
        for kind in by_kind:
            edge_type = self._EDGE_TYPE.get(kind)
            if edge_type is None:
                continue
            try:
                # Delete only edges whose source vertex is on the current branch + project.
                # ArcadeDB uses DELETE FROM <EdgeType> (not DELETE EDGE).
                self._cmd(
                    f"DELETE FROM {edge_type} WHERE "
                    f"@out.branch='{branch_q}' AND @out.project_id='{proj_q}'"
                )
                logger.debug("  [graph] cleared %s edges for branch=%s project=%s",
                             kind, self._branch, self._project_id)
            except Exception as exc:
                logger.warning("Could not clear %s edges: %s", kind, exc)

        self.upsert_edges(valid)

    # ------------------------------------------------------------------
    # Reads — CoW fallback helpers
    # ------------------------------------------------------------------

    def _resolve_symbol_rows(self, rows_branch: list[dict], rows_parent: list[dict]) -> list[Symbol]:
        """Merge branch-local rows with parent rows, deduplicating by id.

        Branch-local rows take precedence over parent rows for the same id.
        """
        seen: set[str] = set()
        result: list[Symbol] = []
        for r in rows_branch:
            sid = r.get("id")
            if sid and sid not in seen:
                seen.add(sid)
                result.append(self._row_to_symbol(r))
        for r in rows_parent:
            sid = r.get("id")
            if sid and sid not in seen:
                seen.add(sid)
                result.append(self._row_to_symbol(r))
        return result

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    def get_symbol(self, symbol_id: str) -> Symbol | None:
        esc_id = self._esc(symbol_id)
        # Try branch-local first
        rows = self._q(
            f"SELECT FROM Symbol WHERE id='{esc_id}' AND {self._bpf()}"
        )
        if rows:
            return self._row_to_symbol(rows[0])
        # CoW fallback to parent branch
        if self._parent_branch:
            rows = self._q(
                f"SELECT FROM Symbol WHERE id='{esc_id}' AND {self._bpf(self._parent_branch)}"
            )
            return self._row_to_symbol(rows[0]) if rows else None
        return None

    def get_all_symbols(self) -> list[Symbol]:
        # Get branch-local symbols
        branch_rows = self._q(
            f"SELECT FROM Symbol WHERE {self._bpf()}"
        )
        if not self._parent_branch:
            return [self._row_to_symbol(r) for r in branch_rows]

        # Get parent symbols not shadowed by branch-local copies
        branch_ids = {r["id"] for r in branch_rows if r.get("id")}
        parent_rows = self._q(
            f"SELECT FROM Symbol WHERE {self._bpf(self._parent_branch)}"
        )
        parent_rows = [r for r in parent_rows if r.get("id") not in branch_ids]
        return self._resolve_symbol_rows(branch_rows, parent_rows)

    def get_callers(self, symbol_id: str, depth: int = 3) -> list[Symbol]:
        """BFS up the call graph with CoW branch fallback at each hop."""
        visited: set[str] = {symbol_id}
        frontier: set[str] = {symbol_id}
        result: list[Symbol] = []
        branch_filter = self._branch_filter()
        proj_q = self._esc(self._project_id)

        for _ in range(depth):
            if not frontier:
                break
            ids_str = ", ".join(f"'{self._esc(i)}'" for i in frontier)
            # Match edges where the in-vertex id is in frontier AND visible in this branch/project
            rows = self._q(
                f"SELECT @out.id AS caller_id FROM Calls "
                f"WHERE @in.id IN [{ids_str}] AND @in.branch {branch_filter} "
                f"AND @in.project_id='{proj_q}'"
            )
            next_frontier: set[str] = set()
            for row in rows:
                cid = row.get("caller_id")
                if cid and cid not in visited:
                    visited.add(cid)
                    next_frontier.add(cid)
            if next_frontier:
                nids_str = ", ".join(f"'{self._esc(i)}'" for i in next_frontier)
                # CoW resolution: branch-local first, then parent
                branch_rows = self._q(
                    f"SELECT FROM Symbol WHERE id IN [{nids_str}] AND {self._bpf()}"
                )
                found_ids = {r["id"] for r in branch_rows if r.get("id")}
                parent_rows: list[dict] = []
                if self._parent_branch:
                    missing = [i for i in next_frontier if i not in found_ids]
                    if missing:
                        mids = ", ".join(f"'{self._esc(i)}'" for i in missing)
                        parent_rows = self._q(
                            f"SELECT FROM Symbol WHERE id IN [{mids}] "
                            f"AND {self._bpf(self._parent_branch)}"
                        )
                for r in branch_rows + parent_rows:
                    if r.get("id"):
                        result.append(self._row_to_symbol(r))
            frontier = next_frontier

        return result

    def get_callees(self, symbol_id: str, depth: int = 3) -> list[Symbol]:
        """BFS down the call graph with CoW branch fallback at each hop."""
        visited: set[str] = {symbol_id}
        frontier: set[str] = {symbol_id}
        result: list[Symbol] = []
        branch_filter = self._branch_filter()
        proj_q = self._esc(self._project_id)

        for _ in range(depth):
            if not frontier:
                break
            ids_str = ", ".join(f"'{self._esc(i)}'" for i in frontier)
            rows = self._q(
                f"SELECT @in.id AS callee_id FROM Calls "
                f"WHERE @out.id IN [{ids_str}] AND @out.branch {branch_filter} "
                f"AND @out.project_id='{proj_q}'"
            )
            next_frontier: set[str] = set()
            for row in rows:
                cid = row.get("callee_id")
                if cid and cid not in visited:
                    visited.add(cid)
                    next_frontier.add(cid)
            if next_frontier:
                nids_str = ", ".join(f"'{self._esc(i)}'" for i in next_frontier)
                branch_rows = self._q(
                    f"SELECT FROM Symbol WHERE id IN [{nids_str}] AND {self._bpf()}"
                )
                found_ids = {r["id"] for r in branch_rows if r.get("id")}
                parent_rows: list[dict] = []
                if self._parent_branch:
                    missing = [i for i in next_frontier if i not in found_ids]
                    if missing:
                        mids = ", ".join(f"'{self._esc(i)}'" for i in missing)
                        parent_rows = self._q(
                            f"SELECT FROM Symbol WHERE id IN [{mids}] "
                            f"AND {self._bpf(self._parent_branch)}"
                        )
                for r in branch_rows + parent_rows:
                    if r.get("id"):
                        result.append(self._row_to_symbol(r))
            frontier = next_frontier

        return result

    def get_cluster_members(self, cluster_id: str) -> list[Symbol]:
        """Return symbols belonging to cluster_id with proper CoW branch resolution.

        Queries symbols directly by cluster_id property (branch+project_id scoped)
        rather than traversing BelongsTo edges, which avoids cross-branch symbol leakage
        in the shared ArcadeDB database.

        Resolution:
          1. Branch-local symbols (branch=current, project_id=this project)
          2. Parent-branch symbols for IDs not overridden locally
        """
        esc_cid = self._esc(cluster_id)

        branch_rows = self._q(
            f"SELECT FROM Symbol WHERE cluster_id='{esc_cid}' AND {self._bpf()}"
        )
        members = [self._row_to_symbol(r) for r in branch_rows if "id" in r]

        if self._parent_branch:
            branch_ids = {r["id"] for r in branch_rows if r.get("id")}
            parent_rows = self._q(
                f"SELECT FROM Symbol WHERE cluster_id='{esc_cid}' AND {self._bpf(self._parent_branch)}"
            )
            for r in parent_rows:
                if r.get("id") and r["id"] not in branch_ids:
                    members.append(self._row_to_symbol(r))

        return members

    def get_cluster(self, cluster_id: str) -> Cluster | None:
        esc_cid = self._esc(cluster_id)
        rows = self._q(
            f"SELECT FROM Cluster WHERE id='{esc_cid}' AND {self._bpf()}"
        )
        if rows:
            return self._row_to_cluster(rows[0])
        if self._parent_branch:
            rows = self._q(
                f"SELECT FROM Cluster WHERE id='{esc_cid}' AND {self._bpf(self._parent_branch)}"
            )
            return self._row_to_cluster(rows[0]) if rows else None
        return None

    def get_all_clusters(self) -> list[Cluster]:
        branch_rows = self._q(
            f"SELECT FROM Cluster WHERE {self._bpf()}"
        )
        if not self._parent_branch:
            return [self._row_to_cluster(r) for r in branch_rows]
        branch_ids = {r["id"] for r in branch_rows if r.get("id")}
        parent_rows = self._q(
            f"SELECT FROM Cluster WHERE {self._bpf(self._parent_branch)}"
        )
        result = [self._row_to_cluster(r) for r in branch_rows]
        for r in parent_rows:
            if r.get("id") not in branch_ids:
                result.append(self._row_to_cluster(r))
        return result

    def get_full_graph(self) -> tuple[list[dict], list[dict]]:
        """Return all visible Symbol nodes and Calls edges as plain dicts."""
        branch_filter = self._branch_filter()
        proj_q = self._esc(self._project_id)
        nodes_branch = self._q(f"SELECT FROM Symbol WHERE {self._bpf()}")
        nodes: list[dict] = list(nodes_branch)
        if self._parent_branch:
            branch_ids = {r.get("id") for r in nodes_branch}
            parent_nodes = self._q(
                f"SELECT FROM Symbol WHERE {self._bpf(self._parent_branch)}"
            )
            nodes.extend(r for r in parent_nodes if r.get("id") not in branch_ids)
        edges = self._q(
            f"SELECT @out.id AS src, @in.id AS dst, confidence, resolved FROM Calls "
            f"WHERE @out.branch {branch_filter} AND @out.project_id='{proj_q}'"
        )
        return nodes, edges

    def get_calls_edges(self) -> list[tuple[str, str]]:
        """Return (src_id, dst_id) pairs for all visible Calls edges — used by clustering."""
        branch_filter = self._branch_filter()
        proj_q = self._esc(self._project_id)
        rows = self._q(
            f"SELECT @out.id AS src, @in.id AS dst FROM Calls "
            f"WHERE @out.branch {branch_filter} AND @out.project_id='{proj_q}'"
        )
        return [(r["src"], r["dst"]) for r in rows if r.get("src") and r.get("dst")]

    # ------------------------------------------------------------------
    # Reads — file-scoped
    # ------------------------------------------------------------------

    def get_symbols_for_file(self, file_path: str) -> list[Symbol]:
        esc_path = self._esc(file_path)
        rows = self._q(
            f"SELECT FROM Symbol WHERE file='{esc_path}' AND {self._bpf()}"
        )
        if not rows and self._parent_branch:
            rows = self._q(
                f"SELECT FROM Symbol WHERE file='{esc_path}' AND {self._bpf(self._parent_branch)}"
            )
        return [self._row_to_symbol(r) for r in rows]

    def get_symbols_for_path_prefix(self, prefix: str) -> list[Symbol]:
        """Return all symbols whose file path starts with prefix (directory-scoped lookup).

        Use a directory path (e.g. 'src/auth/') to list all symbols under that folder.
        CoW fallback: if no branch-local symbols found, tries the parent branch.
        """
        esc_prefix = self._esc(prefix)
        branch_rows = self._q(
            f"SELECT FROM Symbol WHERE file LIKE '{esc_prefix}%' AND {self._bpf()}"
        )
        if branch_rows:
            return [self._row_to_symbol(r) for r in branch_rows]
        if self._parent_branch:
            parent_rows = self._q(
                f"SELECT FROM Symbol WHERE file LIKE '{esc_prefix}%' AND {self._bpf(self._parent_branch)}"
            )
            return [self._row_to_symbol(r) for r in parent_rows]
        return []

    # ------------------------------------------------------------------
    # Deletes — branch-scoped (only removes current branch's copies)
    # ------------------------------------------------------------------

    def delete_symbols_for_file(self, file_path: str) -> int:
        esc_path = self._esc(file_path)
        bpf = self._bpf()
        rows_before = self._q(
            f"SELECT FROM Symbol WHERE file='{esc_path}' AND {bpf}"
        )
        count = len(rows_before)
        if count:
            self._cmd(
                f"DELETE VERTEX FROM Symbol WHERE file='{esc_path}' AND {bpf}"
            )
        return count

    def delete_file(self, file_path: str) -> None:
        self._cmd(
            f"DELETE VERTEX FROM File WHERE path='{self._esc(file_path)}' AND {self._bpf()}"
        )

    def delete_orphan_clusters(self) -> None:
        """Remove branch-local Cluster nodes that have no symbols belonging to them."""
        bpf = self._bpf()
        all_clusters = self._q(f"SELECT id FROM Cluster WHERE {bpf}")
        orphan_ids = []
        for row in all_clusters:
            cid = row.get("id")
            if cid:
                members = self._q(
                    f"SELECT expand(in('BelongsTo')) FROM Cluster "
                    f"WHERE id='{self._esc(cid)}' AND {bpf}"
                )
                if not members:
                    orphan_ids.append(cid)
        if orphan_ids:
            ids_str = ", ".join(f"'{self._esc(i)}'" for i in orphan_ids)
            self._cmd(
                f"DELETE VERTEX FROM Cluster WHERE id IN [{ids_str}] AND {bpf}"
            )

    # ------------------------------------------------------------------
    # Raw query escape hatch
    # ------------------------------------------------------------------

    def query_cypher(self, cypher: str, params: dict | None = None) -> list[dict]:
        """Execute an openCypher query against ArcadeDB's native Cypher engine."""
        return self._db.query("cypher", cypher)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """No persistent file handles to release — HTTP client is stateless."""
        self._db = None  # type: ignore[assignment]
