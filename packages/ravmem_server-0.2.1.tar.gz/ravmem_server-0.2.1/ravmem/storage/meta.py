"""SQLite interface — repo registry, index job history, centrality cache."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from ravmem.storage.schema import File, SQLITE_DDL


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MetaStore:
    def __init__(self, db_path: str | Path) -> None:
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._initialize()

    def _initialize(self) -> None:
        cur = self._conn.cursor()
        for ddl in SQLITE_DDL:
            cur.execute(ddl)
        # Migration: add failure_reason column if it doesn't exist yet
        existing = {
            row[1]
            for row in cur.execute("PRAGMA table_info(index_jobs)").fetchall()
        }
        if "failure_reason" not in existing:
            cur.execute(
                "ALTER TABLE index_jobs ADD COLUMN failure_reason TEXT DEFAULT ''"
            )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Repos
    # ------------------------------------------------------------------

    def register_repo(
        self,
        repo_id: str,
        name: str,
        path: str,
        lang_list: list[str],
    ) -> None:
        cur = self._conn.cursor()
        cur.execute(
            "INSERT INTO repos (id, name, path, lang_list, indexed_at) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET "
            "name=excluded.name, path=excluded.path, "
            "lang_list=excluded.lang_list, indexed_at=excluded.indexed_at",
            (repo_id, name, path, ",".join(lang_list), _now()),
        )
        self._conn.commit()

    def update_repo_stats(
        self,
        repo_id: str,
        symbol_count: int,
        edge_count: int,
        last_commit: str = "",
    ) -> None:
        cur = self._conn.cursor()
        cur.execute(
            "UPDATE repos SET symbol_count=?, edge_count=?, last_commit=?, indexed_at=? "
            "WHERE id=?",
            (symbol_count, edge_count, last_commit, _now(), repo_id),
        )
        self._conn.commit()

    def get_repo(self, repo_id: str) -> dict | None:
        cur = self._conn.cursor()
        row = cur.execute("SELECT * FROM repos WHERE id=?", (repo_id,)).fetchone()
        return dict(row) if row else None

    def list_repos(self) -> list[dict]:
        cur = self._conn.cursor()
        rows = cur.execute("SELECT * FROM repos ORDER BY indexed_at DESC").fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Index jobs
    # ------------------------------------------------------------------

    def create_job(self, repo_id: str, mode: str = "full", diff_base: str = "") -> int:
        cur = self._conn.cursor()
        cur.execute(
            "INSERT INTO index_jobs (repo_id, started_at, status, mode, diff_base) "
            "VALUES (?, ?, 'running', ?, ?)",
            (repo_id, _now(), mode, diff_base),
        )
        self._conn.commit()
        return cur.lastrowid  # type: ignore[return-value]

    def finish_job(self, job_id: int, status: str = "done", reason: str = "") -> None:
        cur = self._conn.cursor()
        cur.execute(
            "UPDATE index_jobs SET ended_at=?, status=?, failure_reason=? WHERE id=?",
            (_now(), status, reason, job_id),
        )
        self._conn.commit()

    def get_last_commit(self, repo_id: str) -> str | None:
        row = self.get_repo(repo_id)
        return row["last_commit"] if row else None

    # ------------------------------------------------------------------
    # Centrality cache
    # ------------------------------------------------------------------

    def save_centrality(self, repo_id: str, scores: dict[str, float]) -> None:
        cur = self._conn.cursor()
        cur.execute("DELETE FROM centrality_cache WHERE repo_id=?", (repo_id,))
        cur.executemany(
            "INSERT INTO centrality_cache (repo_id, symbol_id, score) VALUES (?, ?, ?)",
            [(repo_id, sid, score) for sid, score in scores.items()],
        )
        self._conn.commit()

    def load_centrality(self, repo_id: str) -> dict[str, float]:
        cur = self._conn.cursor()
        rows = cur.execute(
            "SELECT symbol_id, score FROM centrality_cache WHERE repo_id=?", (repo_id,)
        ).fetchall()
        return {r["symbol_id"]: r["score"] for r in rows}

    # ------------------------------------------------------------------
    # File checksums (non-git fallback for incremental indexing)
    # ------------------------------------------------------------------

    def save_file_checksums(self, repo_id: str, files: list[File]) -> None:
        """Persist current checksums for all indexed files."""
        cur = self._conn.cursor()
        cur.executemany(
            "INSERT OR REPLACE INTO file_checksums (repo_id, file_path, checksum, indexed_at) "
            "VALUES (?, ?, ?, ?)",
            [(repo_id, f.path, f.checksum, _now()) for f in files],
        )
        self._conn.commit()

    def get_changed_files(
        self, repo_id: str, current_files: list[File]
    ) -> tuple[list[File], list[str]]:
        """Compare current checksums to stored ones.

        Returns (changed_or_new_files, deleted_file_paths).
        """
        cur = self._conn.cursor()
        stored: dict[str, str] = {
            row["file_path"]: row["checksum"]
            for row in cur.execute(
                "SELECT file_path, checksum FROM file_checksums WHERE repo_id=?", (repo_id,)
            ).fetchall()
        }
        current_paths = {f.path for f in current_files}
        changed = [
            f for f in current_files
            if stored.get(f.path) != f.checksum  # new or modified
        ]
        deleted = [p for p in stored if p not in current_paths]
        return changed, deleted

    def delete_file_checksums(self, repo_id: str, file_paths: list[str]) -> None:
        """Remove checksum records for deleted files."""
        cur = self._conn.cursor()
        cur.executemany(
            "DELETE FROM file_checksums WHERE repo_id=? AND file_path=?",
            [(repo_id, p) for p in file_paths],
        )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()
