"""Data model — dataclasses and DDL strings for all three storage backends."""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Python dataclasses
# ---------------------------------------------------------------------------

@dataclass
class File:
    path: str
    lang: str
    size_kb: float
    checksum: str


@dataclass
class Symbol:
    id: str                # "{file_path}::{name}" or stable hash
    name: str
    kind: str              # function | class | method | interface | constant
    file: str
    line_start: int
    line_end: int
    lang: str
    cluster_id: str = ""
    embedding_id: int = -1
    docstring: str = ""    # persisted in graph; used for embedding text


@dataclass
class Cluster:
    id: str
    label: str
    cohesion_score: float
    size: int


@dataclass
class Edge:
    src_id: str
    dst_id: str
    kind: str              # calls | imports | inherits | belongs_to | contains
    confidence: float = 1.0
    resolved: bool = True
    binding: str = ""      # for import edges


@dataclass
class SearchResult:
    symbol: Symbol
    score: float
    match_type: str        # bm25 | semantic | hybrid
    low_confidence: bool = False


@dataclass
class ImpactNode:
    symbol: Symbol
    depth: int
    path: list[str] = field(default_factory=list)  # chain of symbol IDs


@dataclass
class ImpactResult:
    root_symbol_id: str
    affected: list[ImpactNode] = field(default_factory=list)
    total_affected_count: int = 0


@dataclass
class SymbolContext:
    symbol: Symbol
    callers: list[Symbol]
    callees: list[Symbol]
    cluster: Cluster | None
    cluster_peers: list[Symbol]   # other symbols in same cluster (sample)


@dataclass
class SearchContext:
    query: str
    results: list[SearchResult]


# ---------------------------------------------------------------------------
# ArcadeDB DDL
# ---------------------------------------------------------------------------
# Key syntax differences from KuzuDB:
#   - Properties: CREATE PROPERTY Type.prop IF NOT EXISTS <datatype>
#   - Upsert:     UPDATE Type SET ... UPSERT WHERE id='x'  (requires indexed field)
#   - Edge query: SELECT @out.id, @in.id FROM EdgeType  (not out.id/in.id)
#   - BFS:        SELECT @out.id AS caller_id FROM Calls WHERE @in.id IN [...]
#   - Delete:     DELETE VERTEX FROM Symbol WHERE ...  (not DETACH DELETE)
#   - Writes need db.transaction() context; reads use db.query(); DDL uses db.command() without tx
#   - TRAVERSE and openCypher both work natively

ARCADE_DDL = [
    # Vertex types
    # Symbol — branch property tags each vertex to its branch (CoW isolation).
    # origin_rid stores the application-level id of the parent-branch copy (traceability).
    # branch_updated_at records when this branch-local copy was first written.
    "CREATE VERTEX TYPE Symbol IF NOT EXISTS",
    "CREATE PROPERTY Symbol.id IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.name IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.kind IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.file IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.line_start IF NOT EXISTS INTEGER",
    "CREATE PROPERTY Symbol.line_end IF NOT EXISTS INTEGER",
    "CREATE PROPERTY Symbol.lang IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.cluster_id IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.embedding_id IF NOT EXISTS INTEGER",
    "CREATE PROPERTY Symbol.docstring IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.branch IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.project_id IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.origin_rid IF NOT EXISTS STRING",
    "CREATE PROPERTY Symbol.branch_updated_at IF NOT EXISTS DATETIME",
    # Composite indexes for efficient project+branch scoped queries.
    # 3-column index covers UPSERT WHERE id=... AND branch=... AND project_id=...
    "CREATE INDEX IF NOT EXISTS ON Symbol (id, branch, project_id) UNIQUE",
    "CREATE INDEX IF NOT EXISTS ON Symbol (project_id, branch) NOTUNIQUE",

    # File — same CoW branch tagging as Symbol
    "CREATE VERTEX TYPE File IF NOT EXISTS",
    "CREATE PROPERTY File.path IF NOT EXISTS STRING",
    "CREATE PROPERTY File.lang IF NOT EXISTS STRING",
    "CREATE PROPERTY File.size_kb IF NOT EXISTS DOUBLE",
    "CREATE PROPERTY File.checksum IF NOT EXISTS STRING",
    "CREATE PROPERTY File.branch IF NOT EXISTS STRING",
    "CREATE PROPERTY File.project_id IF NOT EXISTS STRING",
    "CREATE PROPERTY File.origin_rid IF NOT EXISTS STRING",
    "CREATE PROPERTY File.branch_updated_at IF NOT EXISTS DATETIME",
    # Composite indexes: 3-column index covers UPSERT WHERE path=... AND branch=... AND project_id=...
    "CREATE INDEX IF NOT EXISTS ON File (path, branch, project_id) UNIQUE",
    "CREATE INDEX IF NOT EXISTS ON File (project_id, branch) NOTUNIQUE",

    # Cluster — branch-tagged so each branch has its own clustering view
    "CREATE VERTEX TYPE Cluster IF NOT EXISTS",
    "CREATE PROPERTY Cluster.id IF NOT EXISTS STRING",
    "CREATE PROPERTY Cluster.label IF NOT EXISTS STRING",
    "CREATE PROPERTY Cluster.cohesion_score IF NOT EXISTS DOUBLE",
    "CREATE PROPERTY Cluster.size IF NOT EXISTS INTEGER",
    "CREATE PROPERTY Cluster.branch IF NOT EXISTS STRING",
    "CREATE PROPERTY Cluster.project_id IF NOT EXISTS STRING",
    # Composite indexes for project+branch scoped cluster queries.
    # 3-column index covers UPSERT WHERE id=... AND branch=... AND project_id=...
    "CREATE INDEX IF NOT EXISTS ON Cluster (id, branch, project_id) UNIQUE",
    "CREATE INDEX IF NOT EXISTS ON Cluster (project_id, branch) NOTUNIQUE",

    # Edge types — Calls/Imports/Inherits/Contains are implicitly branch-scoped
    # because they connect branch-tagged vertices. BelongsTo carries branch explicitly
    # so cluster membership can be queried without vertex traversal.
    "CREATE EDGE TYPE Calls IF NOT EXISTS",
    "CREATE PROPERTY Calls.confidence IF NOT EXISTS DOUBLE",
    "CREATE PROPERTY Calls.resolved IF NOT EXISTS BOOLEAN",

    "CREATE EDGE TYPE Imports IF NOT EXISTS",
    "CREATE PROPERTY Imports.binding IF NOT EXISTS STRING",

    "CREATE EDGE TYPE Inherits IF NOT EXISTS",

    "CREATE EDGE TYPE BelongsTo IF NOT EXISTS",
    "CREATE PROPERTY BelongsTo.branch IF NOT EXISTS STRING",

    "CREATE EDGE TYPE Contains IF NOT EXISTS",
]

# ---------------------------------------------------------------------------
# SQLite DDL
# ---------------------------------------------------------------------------

SQLITE_DDL = [
    """CREATE TABLE IF NOT EXISTS repos (
        id           TEXT PRIMARY KEY,
        name         TEXT NOT NULL,
        path         TEXT NOT NULL,
        last_commit  TEXT,
        indexed_at   DATETIME,
        lang_list    TEXT,
        symbol_count INTEGER DEFAULT 0,
        edge_count   INTEGER DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS index_jobs (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        repo_id        TEXT NOT NULL,
        started_at     DATETIME NOT NULL,
        ended_at       DATETIME,
        status         TEXT NOT NULL DEFAULT 'running',
        mode           TEXT NOT NULL DEFAULT 'full',
        diff_base      TEXT,
        failure_reason TEXT DEFAULT '',
        FOREIGN KEY (repo_id) REFERENCES repos(id)
    )""",
    """CREATE TABLE IF NOT EXISTS centrality_cache (
        repo_id   TEXT NOT NULL,
        symbol_id TEXT NOT NULL,
        score     REAL NOT NULL,
        PRIMARY KEY (repo_id, symbol_id)
    )""",
    """CREATE TABLE IF NOT EXISTS file_checksums (
        repo_id    TEXT NOT NULL,
        file_path  TEXT NOT NULL,
        checksum   TEXT NOT NULL,
        indexed_at TEXT NOT NULL,
        PRIMARY KEY (repo_id, file_path)
    )""",
]
