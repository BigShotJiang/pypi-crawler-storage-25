"""KuzuDB interface — read/write for the symbol knowledge graph."""

from __future__ import annotations

import csv
import logging
import tempfile
from pathlib import Path
from typing import Any

import kuzu

logger = logging.getLogger(__name__)

_BATCH = 1000  # rows per UNWIND call — keeps memory bounded while minimising roundtrips

from ravmem.storage.schema import (
    Cluster,
    Edge,
    File,
    KUZU_DDL,
    Symbol,
)


class GraphStore:
    def __init__(self, db_path: str | Path, read_only: bool = False) -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = kuzu.Database(str(self._db_path), read_only=read_only)
        self._conn = kuzu.Connection(self._db)
        self._read_only = read_only

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def initialize_schema(self) -> None:
        if self._read_only:
            return  # cannot write schema in read-only mode
        for ddl in KUZU_DDL:
            try:
                self._conn.execute(ddl)
            except Exception:
                pass  # table already exists

        # Migration: add docstring column to existing Symbol tables that predate Iteration 3
        try:
            self._conn.execute("ALTER TABLE Symbol ADD docstring STRING DEFAULT ''")
            logger.info("Schema migration: added 'docstring' column to Symbol table")
        except Exception:
            pass  # column already exists (new installs) or ALTER not needed

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------

    def upsert_file(self, f: File) -> None:
        self._conn.execute(
            "MERGE (n:File {path: $path}) "
            "SET n.lang = $lang, n.size_kb = $size_kb, n.checksum = $checksum",
            {"path": f.path, "lang": f.lang, "size_kb": f.size_kb, "checksum": f.checksum},
        )

    def upsert_files(self, files: list[File]) -> None:
        for i in range(0, len(files), _BATCH):
            batch = files[i:i + _BATCH]
            self._conn.execute(
                "UNWIND $rows AS r "
                "MERGE (n:File {path: r.path}) "
                "SET n.lang=r.lang, n.size_kb=r.size_kb, n.checksum=r.checksum",
                {"rows": [{"path": f.path, "lang": f.lang,
                           "size_kb": f.size_kb, "checksum": f.checksum}
                          for f in batch]},
            )

    def upsert_symbol(self, s: Symbol) -> None:
        self._conn.execute(
            "MERGE (n:Symbol {id: $id}) "
            "SET n.name = $name, n.kind = $kind, n.file = $file, "
            "n.line_start = $line_start, n.line_end = $line_end, "
            "n.lang = $lang, n.cluster_id = $cluster_id, n.embedding_id = $embedding_id, "
            "n.docstring = $docstring",
            {
                "id": s.id,
                "name": s.name,
                "kind": s.kind,
                "file": s.file,
                "line_start": s.line_start,
                "line_end": s.line_end,
                "lang": s.lang,
                "cluster_id": s.cluster_id,
                "embedding_id": s.embedding_id,
                "docstring": s.docstring,
            },
        )

    def upsert_symbols(self, symbols: list[Symbol]) -> None:
        for i in range(0, len(symbols), _BATCH):
            batch = symbols[i:i + _BATCH]
            self._conn.execute(
                "UNWIND $rows AS r "
                "MERGE (n:Symbol {id: r.id}) "
                "SET n.name=r.name, n.kind=r.kind, n.file=r.file, "
                "n.line_start=r.line_start, n.line_end=r.line_end, "
                "n.lang=r.lang, n.cluster_id=r.cluster_id, "
                "n.embedding_id=r.embedding_id, n.docstring=r.docstring",
                {"rows": [{"id": s.id, "name": s.name, "kind": s.kind,
                           "file": s.file, "line_start": s.line_start,
                           "line_end": s.line_end, "lang": s.lang,
                           "cluster_id": s.cluster_id, "embedding_id": s.embedding_id,
                           "docstring": s.docstring or ""}
                          for s in batch]},
            )
            logger.info("  [graph] upsert_symbols: %d/%d", min(i + _BATCH, len(symbols)), len(symbols))

    def upsert_cluster(self, c: Cluster) -> None:
        self._conn.execute(
            "MERGE (n:Cluster {id: $id}) "
            "SET n.label = $label, n.cohesion_score = $cohesion_score, n.size = $size",
            {"id": c.id, "label": c.label, "cohesion_score": c.cohesion_score, "size": c.size},
        )

    def upsert_clusters(self, clusters: list[Cluster]) -> None:
        total = len(clusters)
        for i in range(0, total, _BATCH):
            batch = clusters[i:i + _BATCH]
            self._conn.execute(
                "UNWIND $rows AS r "
                "MERGE (n:Cluster {id: r.id}) "
                "SET n.label=r.label, n.cohesion_score=r.cohesion_score, n.size=r.size",
                {"rows": [{"id": c.id, "label": c.label,
                           "cohesion_score": c.cohesion_score, "size": c.size}
                          for c in batch]},
            )
            logger.info("  [graph] upsert_clusters: %d/%d", min(i + _BATCH, total), total)

    def update_symbol_cluster(self, symbol_id: str, cluster_id: str) -> None:
        self._conn.execute(
            "MATCH (s:Symbol {id: $sid}) SET s.cluster_id = $cid",
            {"sid": symbol_id, "cid": cluster_id},
        )

    def update_symbol_embedding_id(self, symbol_id: str, embedding_id: int) -> None:
        self._conn.execute(
            "MATCH (s:Symbol {id: $sid}) SET s.embedding_id = $eid",
            {"sid": symbol_id, "eid": embedding_id},
        )

    def upsert_edge(self, edge: Edge) -> None:
        if edge.kind == "calls":
            self._conn.execute(
                "MATCH (a:Symbol {id: $src}), (b:Symbol {id: $dst}) "
                "MERGE (a)-[r:Calls]->(b) "
                "SET r.confidence = $conf, r.resolved = $resolved",
                {"src": edge.src_id, "dst": edge.dst_id,
                 "conf": edge.confidence, "resolved": edge.resolved},
            )
        elif edge.kind == "imports":
            self._conn.execute(
                "MATCH (a:File {path: $src}), (b:File {path: $dst}) "
                "MERGE (a)-[r:Imports]->(b) SET r.binding = $binding",
                {"src": edge.src_id, "dst": edge.dst_id, "binding": edge.binding},
            )
        elif edge.kind == "inherits":
            self._conn.execute(
                "MATCH (a:Symbol {id: $src}), (b:Symbol {id: $dst}) "
                "MERGE (a)-[:Inherits]->(b)",
                {"src": edge.src_id, "dst": edge.dst_id},
            )
        elif edge.kind == "belongs_to":
            self._conn.execute(
                "MATCH (a:Symbol {id: $src}), (b:Cluster {id: $dst}) "
                "MERGE (a)-[:BelongsTo]->(b)",
                {"src": edge.src_id, "dst": edge.dst_id},
            )
        elif edge.kind == "contains":
            self._conn.execute(
                "MATCH (a:File {path: $src}), (b:Symbol {id: $dst}) "
                "MERGE (a)-[:Contains]->(b)",
                {"src": edge.src_id, "dst": edge.dst_id},
            )

    def upsert_edges(self, edges: list[Edge]) -> None:
        # Group by kind for bulk UNWIND — each kind has a different MATCH pattern
        by_kind: dict[str, list[Edge]] = {}
        for e in edges:
            by_kind.setdefault(e.kind, []).append(e)

        for kind, group in by_kind.items():
            for i in range(0, len(group), _BATCH):
                batch = group[i:i + _BATCH]
                rows = [{"src": e.src_id, "dst": e.dst_id,
                         "conf": e.confidence, "resolved": e.resolved,
                         "binding": e.binding or ""}
                        for e in batch]
                try:
                    if kind == "calls":
                        self._conn.execute(
                            "UNWIND $rows AS r "
                            "MATCH (a:Symbol {id: r.src}), (b:Symbol {id: r.dst}) "
                            "MERGE (a)-[rel:Calls]->(b) "
                            "SET rel.confidence=r.conf, rel.resolved=r.resolved",
                            {"rows": rows},
                        )
                    elif kind == "imports":
                        self._conn.execute(
                            "UNWIND $rows AS r "
                            "MATCH (a:File {path: r.src}), (b:File {path: r.dst}) "
                            "MERGE (a)-[rel:Imports]->(b) SET rel.binding=r.binding",
                            {"rows": rows},
                        )
                    elif kind == "inherits":
                        self._conn.execute(
                            "UNWIND $rows AS r "
                            "MATCH (a:Symbol {id: r.src}), (b:Symbol {id: r.dst}) "
                            "MERGE (a)-[:Inherits]->(b)",
                            {"rows": rows},
                        )
                    elif kind == "belongs_to":
                        self._conn.execute(
                            "UNWIND $rows AS r "
                            "MATCH (a:Symbol {id: r.src}), (b:Cluster {id: r.dst}) "
                            "MERGE (a)-[:BelongsTo]->(b)",
                            {"rows": rows},
                        )
                    elif kind == "contains":
                        self._conn.execute(
                            "UNWIND $rows AS r "
                            "MATCH (a:File {path: r.src}), (b:Symbol {id: r.dst}) "
                            "MERGE (a)-[:Contains]->(b)",
                            {"rows": rows},
                        )
                except Exception as exc:
                    # Fallback to individual upserts for this batch so partial failures don't
                    # drop the whole batch (e.g. a handful of missing nodes)
                    logger.debug("Bulk edge upsert failed for kind=%s, falling back: %s", kind, exc)
                    for e in batch:
                        try:
                            self.upsert_edge(e)
                        except Exception:
                            pass

    # ------------------------------------------------------------------
    # Bulk edge loading via COPY FROM (full-index only — INSERT, not MERGE)
    # ------------------------------------------------------------------

    _EDGE_TABLE = {
        "calls": "Calls",
        "imports": "Imports",
        "inherits": "Inherits",
        "belongs_to": "BelongsTo",
        "contains": "Contains",
    }

    def bulk_insert_edges(self, edges: list[Edge]) -> None:
        """Insert edges via COPY FROM CSV — ~150x faster than UNWIND for large sets.

        Clears existing edges of each kind first so this is safe for full re-index runs.
        Do NOT use for incremental updates (use upsert_edges instead).
        """
        if not edges:
            return

        # Group by kind; filter out edges whose src/dst look like file paths
        # (fallback IDs from _nearest_symbol_id when a file has no symbols)
        by_kind: dict[str, list[Edge]] = {}
        for e in edges:
            if e.kind in ("calls", "inherits") and (
                "/" in e.src_id or "\\" in e.src_id
                or "/" in e.dst_id or "\\" in e.dst_id
            ):
                continue  # src/dst is a file path, not a symbol ID — skip
            by_kind.setdefault(e.kind, []).append(e)

        for kind, group in by_kind.items():
            table = self._EDGE_TABLE.get(kind)
            if table is None:
                continue

            # Write temp CSV — columns must match the table schema
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".csv", delete=False, newline="", encoding="utf-8"
            ) as f:
                csv_path = f.name
                writer = csv.writer(f)
                if kind == "calls":
                    writer.writerow(["from", "to", "confidence", "resolved"])
                    for e in group:
                        writer.writerow([e.src_id, e.dst_id, e.confidence, e.resolved])
                elif kind == "imports":
                    writer.writerow(["from", "to", "binding"])
                    for e in group:
                        writer.writerow([e.src_id, e.dst_id, e.binding or ""])
                else:
                    # inherits, belongs_to, contains — no extra columns
                    writer.writerow(["from", "to"])
                    for e in group:
                        writer.writerow([e.src_id, e.dst_id])

            try:
                self._conn.execute(f"MATCH ()-[r:{table}]->() DELETE r")
                logger.debug("  [graph] cleared existing %s edges for full re-insert", kind)
                csv_uri = Path(csv_path).as_posix()
                self._conn.execute(
                    f'COPY {table} FROM "{csv_uri}" (HEADER=TRUE)'
                )
            except Exception as exc:
                logger.warning("COPY FROM failed for %s, falling back to UNWIND: %s", kind, exc)
                self.upsert_edges(group)
            finally:
                try:
                    Path(csv_path).unlink()
                except Exception:
                    pass

    def update_symbol_clusters_bulk(self, updates: list[tuple[str, str]]) -> None:
        """Set cluster_id on many symbols at once. updates = [(symbol_id, cluster_id), ...]"""
        total = len(updates)
        for i in range(0, total, _BATCH):
            batch = updates[i:i + _BATCH]
            self._conn.execute(
                "UNWIND $rows AS r MATCH (n:Symbol {id: r.id}) SET n.cluster_id=r.cid",
                {"rows": [{"id": sid, "cid": cid} for sid, cid in batch]},
            )
            logger.info("  [graph] cluster_id update: %d/%d", min(i + _BATCH, total), total)

    def update_symbol_embedding_ids_bulk(self, updates: list[tuple[str, int]]) -> None:
        """Set embedding_id on many symbols at once. updates = [(symbol_id, embedding_id), ...]"""
        total = len(updates)
        for i in range(0, total, _BATCH):
            batch = updates[i:i + _BATCH]
            self._conn.execute(
                "UNWIND $rows AS r MATCH (n:Symbol {id: r.id}) SET n.embedding_id=r.eid",
                {"rows": [{"id": sid, "eid": eid} for sid, eid in batch]},
            )
            logger.info("  [graph] embedding_id update: %d/%d", min(i + _BATCH, total), total)

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    @staticmethod
    def _result_to_dicts(result: Any) -> list[dict[str, Any]]:
        """Convert a KuzuDB QueryResult to a list of dicts without requiring pandas."""
        cols = result.get_column_names()
        return [dict(zip(cols, row)) for row in result.get_all()]

    def _row_to_symbol(self, row: dict[str, Any]) -> Symbol:
        return Symbol(
            id=row["id"],
            name=row["name"],
            kind=row["kind"],
            file=row["file"],
            line_start=row["line_start"],
            line_end=row["line_end"],
            lang=row["lang"],
            cluster_id=row.get("cluster_id", ""),
            embedding_id=row.get("embedding_id", -1),
            docstring=row.get("docstring") or "",
        )

    def get_symbol(self, symbol_id: str) -> Symbol | None:
        result = self._conn.execute(
            "MATCH (s:Symbol {id: $id}) RETURN s.*",
            {"id": symbol_id},
        )
        rows = self._result_to_dicts(result)
        if not rows:
            return None
        return self._row_to_symbol({(k[2:] if k.startswith("s.") else k): v for k, v in rows[0].items()})

    def get_all_symbols(self) -> list[Symbol]:
        result = self._conn.execute("MATCH (s:Symbol) RETURN s.*")
        return [
            self._row_to_symbol({(k[2:] if k.startswith("s.") else k): v for k, v in row.items()})
            for row in self._result_to_dicts(result)
        ]

    def get_callers(self, symbol_id: str, depth: int = 3) -> list[Symbol]:
        result = self._conn.execute(
            f"MATCH (caller:Symbol)-[:Calls*1..{depth}]->(s:Symbol {{id: $id}}) "
            "RETURN DISTINCT caller.*",
            {"id": symbol_id},
        )
        return [
            self._row_to_symbol({k.replace("caller.", ""): v for k, v in row.items()})
            for row in self._result_to_dicts(result)
        ]

    def get_callees(self, symbol_id: str, depth: int = 3) -> list[Symbol]:
        result = self._conn.execute(
            f"MATCH (s:Symbol {{id: $id}})-[:Calls*1..{depth}]->(callee:Symbol) "
            "RETURN DISTINCT callee.*",
            {"id": symbol_id},
        )
        return [
            self._row_to_symbol({k.replace("callee.", ""): v for k, v in row.items()})
            for row in self._result_to_dicts(result)
        ]

    def get_cluster_members(self, cluster_id: str) -> list[Symbol]:
        result = self._conn.execute(
            "MATCH (s:Symbol)-[:BelongsTo]->(c:Cluster {id: $id}) RETURN s.*",
            {"id": cluster_id},
        )
        return [
            self._row_to_symbol({(k[2:] if k.startswith("s.") else k): v for k, v in row.items()})
            for row in self._result_to_dicts(result)
        ]

    def get_cluster(self, cluster_id: str) -> Cluster | None:
        result = self._conn.execute(
            "MATCH (c:Cluster {id: $id}) RETURN c.*",
            {"id": cluster_id},
        )
        rows = self._result_to_dicts(result)
        if not rows:
            return None
        d = {k.replace("c.", ""): v for k, v in rows[0].items()}
        return Cluster(
            id=d["id"], label=d["label"],
            cohesion_score=d["cohesion_score"], size=d["size"]
        )

    def get_all_clusters(self) -> list[Cluster]:
        result = self._conn.execute("MATCH (c:Cluster) RETURN c.*")
        clusters = []
        for row in self._result_to_dicts(result):
            d = {k.replace("c.", ""): v for k, v in row.items()}
            clusters.append(Cluster(
                id=d["id"], label=d["label"],
                cohesion_score=d["cohesion_score"], size=d["size"]
            ))
        return clusters

    def get_full_graph(self) -> tuple[list[dict], list[dict]]:
        """Return all nodes and edges as plain dicts for JSON export."""
        nodes = [
            {(k[2:] if k.startswith("s.") else k): v for k, v in row.items()}
            for row in self._result_to_dicts(self._conn.execute("MATCH (s:Symbol) RETURN s.*"))
        ]
        edges = self._result_to_dicts(self._conn.execute(
            "MATCH (a:Symbol)-[r:Calls]->(b:Symbol) "
            "RETURN a.id AS src, b.id AS dst, r.confidence AS confidence, r.resolved AS resolved"
        ))
        return nodes, edges

    def get_calls_edges(self) -> list[tuple[str, str]]:
        """Return (src_id, dst_id) pairs for all Calls edges — used by clustering."""
        rows = self._result_to_dicts(self._conn.execute(
            "MATCH (a:Symbol)-[:Calls]->(b:Symbol) RETURN a.id AS src, b.id AS dst"
        ))
        return [(r["src"], r["dst"]) for r in rows]

    # ------------------------------------------------------------------
    # Deletes
    # ------------------------------------------------------------------

    def get_symbols_for_file(self, file_path: str) -> list[Symbol]:
        """Return all Symbol nodes whose file matches file_path."""
        result = self._conn.execute(
            "MATCH (s:Symbol {file: $file}) RETURN s.*", {"file": file_path}
        )
        return [
            self._row_to_symbol({(k[2:] if k.startswith("s.") else k): v for k, v in row.items()})
            for row in self._result_to_dicts(result)
        ]

    def delete_symbols_for_file(self, file_path: str) -> int:
        """DETACH DELETE all Symbol nodes for a file. Returns number deleted."""
        result = self._conn.execute(
            "MATCH (s:Symbol {file: $file}) DETACH DELETE s RETURN count(*) AS n",
            {"file": file_path},
        )
        rows = self._result_to_dicts(result)
        return int(rows[0]["n"]) if rows else 0

    def delete_file(self, file_path: str) -> None:
        """Remove a File node (and all its edges) from the graph."""
        self._conn.execute(
            "MATCH (f:File {path: $path}) DETACH DELETE f", {"path": file_path}
        )

    def delete_orphan_clusters(self) -> None:
        """Remove Cluster nodes that have no symbols belonging to them."""
        self._conn.execute(
            "MATCH (c:Cluster) WHERE NOT (()-[:BelongsTo]->(c)) DETACH DELETE c"
        )

    def query_cypher(self, cypher: str, params: dict | None = None) -> list[dict]:
        result = self._conn.execute(cypher, params or {})
        return self._result_to_dicts(result)

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass
        # Release the kuzu.Database lock so the directory can be renamed on Windows.
        self._conn = None  # type: ignore[assignment]
        self._db = None
