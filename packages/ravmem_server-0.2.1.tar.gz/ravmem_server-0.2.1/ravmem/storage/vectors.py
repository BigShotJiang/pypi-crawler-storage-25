"""usearch HNSW interface — vector storage and ANN search for symbol embeddings."""

from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np
from usearch.index import Index

logger = logging.getLogger(__name__)


class VectorStore:
    """Wraps a usearch HNSW index plus a parallel symbol-ID list."""

    def __init__(self, index_dir: str | Path, dim: int = 384) -> None:
        self._dir = Path(index_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._dim = dim
        self._index_path = self._dir / "usearch.bin"
        self._ids_path = self._dir / "ids.json"

        self._index: Index | None = None
        self._symbol_ids: list[str] = []   # position → symbol_id
        self._id_to_int: dict[str, int] = {}   # reverse map: symbol_id → int_id
        self._deleted_count: int = 0
        self._deleted_ids: set[str] = set()   # symbol_ids that have been removed

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self, max_elements: int = 100_000) -> None:  # max_elements kept for API compat
        """Create a fresh index or load an existing one."""
        legacy_path = self._dir / "hnsw.bin"
        if self._index_path.exists() and self._ids_path.exists():
            self._load()
        else:
            if legacy_path.exists():
                logger.warning(
                    "Found legacy hnsw.bin at %s but no usearch.bin — "
                    "re-index this branch to rebuild the vector store.",
                    self._dir,
                )
            self._index = self._new_index()
            self._symbol_ids = []
            self._id_to_int = {}
            self._deleted_count = 0
            self._deleted_ids = set()

    def _new_index(self) -> Index:
        return Index(
            ndim=self._dim,
            metric="cos",
            dtype="f32",
            connectivity=16,
            expansion_add=200,
            expansion_search=100,
        )

    def _load(self) -> None:
        self._index = self._new_index()
        self._index.load(str(self._index_path))
        with open(self._ids_path) as f:
            data = json.load(f)
        if isinstance(data, list):           # old format — bare list
            self._symbol_ids = data
            self._deleted_count = 0
            self._deleted_ids = set()
        else:                                # new format
            self._symbol_ids = data["symbol_ids"]
            self._deleted_count = data.get("deleted_count", 0)
            self._deleted_ids = set(data.get("deleted_ids", []))
        self._id_to_int = {
            sid: i for i, sid in enumerate(self._symbol_ids)
            if sid not in self._deleted_ids
        }

    def save(self) -> None:
        if self._index is None:
            return
        self._index.save(str(self._index_path))
        with open(self._ids_path, "w") as f:
            json.dump(
                {
                    "symbol_ids": self._symbol_ids,
                    "deleted_count": self._deleted_count,
                    "deleted_ids": list(self._deleted_ids),
                },
                f,
            )

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------

    def add_symbols(self, symbol_ids: list[str], embeddings: np.ndarray) -> list[int]:
        """Add embeddings and return their assigned integer IDs."""
        if self._index is None:
            raise RuntimeError("VectorStore not initialized — call initialize() first")

        current_count = len(self._symbol_ids)
        int_ids = list(range(current_count, current_count + len(symbol_ids)))

        # usearch grows dynamically — no resize needed
        self._index.add(np.array(int_ids, dtype=np.int64), embeddings)
        self._symbol_ids.extend(symbol_ids)
        for int_id, sid in zip(int_ids, symbol_ids):
            self._id_to_int[sid] = int_id
        return int_ids

    def remove_symbols(self, symbol_ids: list[str]) -> int:
        """Remove symbols from the HNSW index by symbol_id.

        Uses usearch remove() so deleted items are excluded from future queries.
        Silently skips IDs not found in the index (safe for re-parse ID collisions).
        Returns the count of symbols actually removed.
        """
        if self._index is None:
            return 0
        removed = 0
        for sid in symbol_ids:
            int_id = self._id_to_int.get(sid)
            if int_id is None:
                continue
            try:
                self._index.remove(int_id)
                del self._id_to_int[sid]
                self._deleted_ids.add(sid)
                self._deleted_count += 1
                removed += 1
            except Exception:
                pass
        return removed

    # ------------------------------------------------------------------
    # Reads
    # ------------------------------------------------------------------

    def search(self, query_embedding: np.ndarray, k: int = 20) -> list[tuple[str, float]]:
        """Return list of (symbol_id, distance) sorted by ascending distance."""
        if self._index is None or self.live_count == 0:
            return []
        k = min(k, self.live_count)
        matches = self._index.search(query_embedding, k)
        results = []
        for key, dist in zip(matches.keys, matches.distances):
            label = int(key)
            if label < len(self._symbol_ids):
                results.append((self._symbol_ids[label], float(dist)))
        return results

    def rebuild(self, symbol_ids: list[str], embeddings: np.ndarray) -> None:
        """Drop and recreate the HNSW index from scratch with the given symbols."""
        self._index = self._new_index()
        self._symbol_ids = []
        if symbol_ids:
            int_ids = np.arange(len(symbol_ids), dtype=np.int64)
            self._index.add(int_ids, embeddings)
            self._symbol_ids = list(symbol_ids)
        self._deleted_count = 0
        self._deleted_ids = set()
        self._id_to_int = {sid: i for i, sid in enumerate(symbol_ids)}
        self.save()

    def get_embedding(self, int_id: int) -> np.ndarray | None:
        if self._index is None:
            return None
        try:
            return self._index.get(int_id)
        except Exception:
            return None

    @property
    def deleted_count(self) -> int:
        """Number of soft-deleted slots in the HNSW index."""
        return self._deleted_count

    @property
    def live_count(self) -> int:
        """Number of active (non-deleted) symbols in the index."""
        return len(self._symbol_ids) - self._deleted_count

    @property
    def total_count(self) -> int:
        """Total allocated slots including soft-deleted ones."""
        return len(self._symbol_ids)

    @property
    def count(self) -> int:
        return len(self._symbol_ids)
