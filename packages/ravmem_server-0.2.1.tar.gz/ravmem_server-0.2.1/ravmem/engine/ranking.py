"""Centrality scoring — PageRank over the call graph, cached in SQLite."""

from __future__ import annotations

import networkx as nx

from ravmem.storage.graph_arcade import ArcadeGraphStore as GraphStore
from ravmem.storage.meta import MetaStore


def compute_centrality(
    graph: GraphStore,
    meta: MetaStore,
    repo_id: str,
    force: bool = False,
) -> dict[str, float]:
    """
    Compute PageRank over the Calls graph.
    Results are cached in SQLite and reused unless force=True.
    """
    if not force:
        cached = meta.load_centrality(repo_id)
        if cached:
            return cached

    call_pairs = graph.get_calls_edges()
    if not call_pairs:
        return {}

    G = nx.DiGraph()
    G.add_edges_from(call_pairs)
    scores: dict[str, float] = nx.pagerank(G, alpha=0.85)

    meta.save_centrality(repo_id, scores)
    return scores
