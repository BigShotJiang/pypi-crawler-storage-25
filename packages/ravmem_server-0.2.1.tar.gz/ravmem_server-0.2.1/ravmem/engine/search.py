"""Hybrid search engine — BM25 + semantic (usearch HNSW) merged via Reciprocal Rank Fusion."""

from __future__ import annotations

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

import numpy as np
from rank_bm25 import BM25Okapi

from ravmem._model_cache import get_embedding_model
from ravmem.config import EMBEDDING_MODEL, MODELS_DIR
from ravmem.storage.schema import SearchResult, Symbol
from ravmem.storage.vectors import VectorStore


class SearchEngine:
    def __init__(
        self,
        vector_store: VectorStore,
        bm25_path: Path,
        centrality: dict[str, float] | None = None,
    ) -> None:
        self._vectors = vector_store
        self._centrality = centrality or {}
        self._corpus: list[dict] = []   # [{id, text, name, file, kind}]
        self._bm25: BM25Okapi | None = None
        self._sym_id_to_corpus_idx: dict[str, int] = {}

        if bm25_path.exists():
            self._load_bm25(bm25_path)

    def _load_bm25(self, bm25_path: Path) -> None:
        self._corpus = json.loads(bm25_path.read_text())
        tokenized = [doc["text"].lower().split() for doc in self._corpus]
        self._bm25 = BM25Okapi(tokenized)
        self._sym_id_to_corpus_idx = {doc["id"]: i for i, doc in enumerate(self._corpus)}

    def _get_model(self):
        # Delegate to the module-level cache so that all SearchEngine instances
        # in the same process share a single loaded model (avoids ~8 s reload).
        return get_embedding_model(EMBEDDING_MODEL, str(MODELS_DIR))

    def _corpus_item_to_symbol(self, item: dict) -> Symbol:
        return Symbol(
            id=item["id"],
            name=item["name"],
            kind=item["kind"],
            file=item["file"],
            line_start=item.get("line_start", 0),
            line_end=item.get("line_end", 0),
            lang=item.get("lang", ""),
            cluster_id=item.get("cluster_id", ""),
        )

    def search(self, query: str, k: int = 20) -> list[SearchResult]:
        """Return top-k results via RRF(BM25, semantic) + centrality re-rank."""
        if not self._corpus:
            return []

        k_fetch = min(k * 3, len(self._corpus))  # fetch more, re-rank to k

        # --- BM25 scores ---
        bm25_ranks: dict[str, int] = {}
        if self._bm25 is not None:
            scores = self._bm25.get_scores(query.lower().split())
            ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
            for rank, idx in enumerate(ranked[:k_fetch]):
                bm25_ranks[self._corpus[idx]["id"]] = rank + 1

        # --- Semantic scores ---
        sem_ranks: dict[str, int] = {}
        try:
            model = self._get_model()
            qvec = np.array(list(model.embed([query])), dtype=np.float32)[0]
            sem_hits = self._vectors.search(qvec, k=k_fetch)
            for rank, (sym_id, _dist) in enumerate(sem_hits):
                sem_ranks[sym_id] = rank + 1
        except Exception as _sem_exc:
            logger.warning("Semantic search failed, falling back to BM25 only: %s", _sem_exc)

        # --- Reciprocal Rank Fusion ---
        K_RRF = 60
        all_ids = set(bm25_ranks) | set(sem_ranks)
        rrf_scores: dict[str, float] = {}
        for sid in all_ids:
            score = 0.0
            if sid in bm25_ranks:
                score += 1.0 / (K_RRF + bm25_ranks[sid])
            if sid in sem_ranks:
                score += 1.0 / (K_RRF + sem_ranks[sid])
            # Centrality boost (small, used as tiebreaker)
            score += self._centrality.get(sid, 0.0) * 0.01
            rrf_scores[sid] = score

        # Build results
        top_ids = sorted(rrf_scores, key=lambda sid: rrf_scores[sid], reverse=True)[:k]
        results: list[SearchResult] = []
        for sid in top_ids:
            idx = self._sym_id_to_corpus_idx.get(sid)
            if idx is None:
                logger.warning(
                    "search: symbol %s in vector/BM25 ranks but missing from corpus index"
                    " — corpus may be out of sync with vector store",
                    sid,
                )
                continue
            match_type = (
                "hybrid" if (sid in bm25_ranks and sid in sem_ranks)
                else "bm25" if sid in bm25_ranks
                else "semantic"
            )
            results.append(SearchResult(
                symbol=self._corpus_item_to_symbol(self._corpus[idx]),
                score=round(rrf_scores[sid], 6),
                match_type=match_type,
            ))

        # Detect low-confidence results: uniformly low scores OR tiny corpus
        _LOW_CONFIDENCE_THRESHOLD = 0.005
        _CORPUS_SIZE_THRESHOLD = 3
        top_score_too_low = bool(results) and results[0].score < _LOW_CONFIDENCE_THRESHOLD
        small_corpus = len(self._corpus) < _CORPUS_SIZE_THRESHOLD
        if top_score_too_low or small_corpus:
            results = [
                SearchResult(
                    symbol=r.symbol,
                    score=r.score,
                    match_type=r.match_type,
                    low_confidence=True,
                )
                for r in results
            ]

        return results
