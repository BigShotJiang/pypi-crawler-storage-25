"""Context assembly — builds rich structured context objects for MCP/AI consumption."""

from __future__ import annotations

from ravmem.engine.impact import ImpactEngine
from ravmem.engine.search import SearchEngine
from ravmem.storage.graph_arcade import ArcadeGraphStore as GraphStore
from ravmem.storage.schema import (
    Cluster,
    SearchContext,
    Symbol,
    SymbolContext,
)


class ContextEngine:
    def __init__(
        self,
        graph: GraphStore,
        search: SearchEngine,
        impact: ImpactEngine,
    ) -> None:
        self._graph = graph
        self._search = search
        self._impact = impact

    def assemble_symbol_context(
        self,
        symbol_id: str,
        caller_depth: int = 2,
        callee_depth: int = 2,
        max_cluster_peers: int = 5,
    ) -> SymbolContext | None:
        """
        Build a rich context object for a single symbol.
        Includes: callers, callees, cluster membership, cluster peers.
        Designed to give an LLM structural understanding of a symbol's role.
        """
        symbol = self._graph.get_symbol(symbol_id)
        if symbol is None:
            return None

        callers = self._graph.get_callers(symbol_id, depth=caller_depth)
        callees = self._graph.get_callees(symbol_id, depth=callee_depth)

        cluster: Cluster | None = None
        cluster_peers: list[Symbol] = []
        if symbol.cluster_id:
            cluster = self._graph.get_cluster(symbol.cluster_id)
            all_peers = self._graph.get_cluster_members(symbol.cluster_id)
            cluster_peers = [p for p in all_peers if p.id != symbol_id][:max_cluster_peers]

        return SymbolContext(
            symbol=symbol,
            callers=callers,
            callees=callees,
            cluster=cluster,
            cluster_peers=cluster_peers,
        )

    def assemble_search_context(
        self,
        query: str,
        limit: int = 10,
    ) -> SearchContext:
        """Run hybrid search and return top results."""
        results = self._search.search(query, k=limit)
        return SearchContext(query=query, results=results)
