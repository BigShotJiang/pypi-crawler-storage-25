"""Impact analysis — blast radius and call chain traversal via graph BFS."""

from __future__ import annotations

import re
from collections import deque

from ravmem.storage.graph_arcade import ArcadeGraphStore as GraphStore
from ravmem.storage.schema import ImpactNode, ImpactResult, Symbol


class ImpactEngine:
    def __init__(self, graph: GraphStore) -> None:
        self._graph = graph

    def get_impact(self, symbol_id: str, depth: int = 3) -> ImpactResult:
        """
        Return all symbols that depend on symbol_id (i.e. callers, transitively).
        BFS up the call graph.
        """
        visited: set[str] = set()
        queue: deque[tuple[str, int, list[str]]] = deque()
        queue.append((symbol_id, 0, [symbol_id]))
        affected: list[ImpactNode] = []

        while queue:
            current_id, current_depth, path = queue.popleft()
            if current_id in visited:
                continue
            visited.add(current_id)

            if current_depth > 0:
                sym = self._graph.get_symbol(current_id)
                if sym:
                    affected.append(ImpactNode(
                        symbol=sym, depth=current_depth, path=list(path)
                    ))

            if current_depth < depth:
                callers = self._graph.get_callers(current_id, depth=1)
                for caller in callers:
                    if caller.id not in visited:
                        queue.append((caller.id, current_depth + 1, path + [caller.id]))

        total = len(affected)
        return ImpactResult(root_symbol_id=symbol_id, affected=affected, total_affected_count=total)

    def get_call_chain(
        self,
        symbol_id: str,
        direction: str = "callees",
        depth: int = 5,
    ) -> "list[Symbol] | dict[str, list[Symbol]]":
        """
        Trace callers or callees from symbol_id up to `depth` hops.
        direction: "callers" | "callees" | "both"

        Returns list[Symbol] for "callers"/"callees", or
        {"callers": [...], "callees": [...]} for "both".
        """
        if direction == "both":
            return {
                "callers": self._graph.get_callers(symbol_id, depth=depth),
                "callees": self._graph.get_callees(symbol_id, depth=depth),
            }
        if direction == "callers":
            return self._graph.get_callers(symbol_id, depth=depth)
        return self._graph.get_callees(symbol_id, depth=depth)

    def diff_impact(self, diff_text: str) -> list[ImpactResult]:
        """
        Parse a unified diff and return impact results for all changed symbols.
        Matches function/class definition lines in the diff.
        """
        changed_names = _extract_changed_names(diff_text)
        results: list[ImpactResult] = []

        all_symbols = self._graph.get_all_symbols()
        name_to_ids: dict[str, list[str]] = {}
        for s in all_symbols:
            bare = s.name.split(".")[-1]
            name_to_ids.setdefault(bare, []).append(s.id)
            name_to_ids.setdefault(s.name, []).append(s.id)

        seen_ids: set[str] = set()
        for name in changed_names:
            for sid in name_to_ids.get(name, []):
                if sid not in seen_ids:
                    seen_ids.add(sid)
                    results.append(self.get_impact(sid))

        return results


# ---------------------------------------------------------------------------
# Diff parsing
# ---------------------------------------------------------------------------

_DEF_PATTERNS = [
    # Added lines (+ prefix)
    re.compile(r"^\+\s*(?:async\s+)?def\s+(\w+)\s*\("),       # Python function (added)
    re.compile(r"^\+\s*class\s+(\w+)\s*[:(]"),                  # Python class (added)
    re.compile(r"^\+\s*function\s+(\w+)\s*\("),                 # JS/TS function (added)
    re.compile(r"^\+\s*(?:export\s+)?class\s+(\w+)"),           # JS/TS class (added)
    re.compile(r"^\+\s*func\s+\w*\s*(\w+)\s*\("),               # Go function/method (added)
    # Deleted lines (- prefix) — also capture deleted symbol definitions
    re.compile(r"^-\s*(?:async\s+)?def\s+(\w+)\s*\("),          # Python function (deleted)
    re.compile(r"^-\s*class\s+(\w+)\s*[:(]"),                   # Python class (deleted)
    re.compile(r"^-\s*function\s+(\w+)\s*\("),                  # JS/TS function (deleted)
    re.compile(r"^-\s*(?:export\s+)?class\s+(\w+)"),            # JS/TS class (deleted)
    re.compile(r"^-\s*func\s+\w*\s*(\w+)\s*\("),                # Go function/method (deleted)
]

# Patterns to find enclosing function/class context lines (no +/- prefix, or context lines)
_CONTEXT_DEF_PATTERNS = [
    re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\("),           # Python function
    re.compile(r"^\s*class\s+(\w+)\s*[:(]"),                    # Python class
    re.compile(r"^\s*function\s+(\w+)\s*\("),                   # JS/TS function
    re.compile(r"^\s*(?:export\s+)?class\s+(\w+)"),             # JS/TS class
    re.compile(r"^\s*func\s+\w*\s*(\w+)\s*\("),                 # Go function/method
]


def _extract_changed_names(diff_text: str) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()
    lines = diff_text.splitlines()
    hunk_lines: list[str] = []  # lines in the current hunk (stripped of +/-)

    for i, line in enumerate(lines):
        # Track hunk boundaries
        if line.startswith("@@"):
            hunk_lines = []
            continue

        # Check for explicit def/class on added or removed lines
        matched = False
        for pattern in _DEF_PATTERNS:
            m = pattern.match(line)
            if m:
                name = m.group(1)
                if name not in seen:
                    seen.add(name)
                    names.append(name)
                matched = True
                break

        # If this is a changed body line (+ or -) with no def match,
        # scan backwards in the hunk context to find the enclosing function/class
        if not matched and line and line[0] in ("+", "-") and not line.startswith("+++") and not line.startswith("---"):
            # Strip the leading +/- and check preceding hunk_lines for context
            for prev_raw in reversed(hunk_lines):
                # prev_raw already has its +/- stripped
                for ctx_pat in _CONTEXT_DEF_PATTERNS:
                    cm = ctx_pat.match(prev_raw)
                    if cm:
                        name = cm.group(1)
                        if name not in seen:
                            seen.add(name)
                            names.append(name)
                        break
                else:
                    continue
                break

        # Accumulate the line (stripped of leading +/-) for context scanning
        if line and line[0] in ("+", "-") and not line.startswith("+++") and not line.startswith("---"):
            hunk_lines.append(line[1:])
        elif not line.startswith("@@"):
            # Context line (no +/-): add as-is for enclosing context detection
            hunk_lines.append(line)

    return names
