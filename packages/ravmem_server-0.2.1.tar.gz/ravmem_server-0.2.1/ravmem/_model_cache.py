"""Module-level embedding model cache shared across the whole process.

fastembed models cold-start in ~2 s and cache automatically on first use.
By caching at module level the model is loaded at most once per Python process
regardless of how many SearchEngine instances or embed-phase calls exist.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

_cache: dict[str, Any] = {}


def get_embedding_model(model_name: str, cache_folder: str) -> Any:
    """Return a cached ``fastembed.TextEmbedding`` instance.

    Loaded lazily on first call and reused on every subsequent call within the
    same process. fastembed caches the ONNX model automatically — no
    offline/online try-except needed.
    """
    if model_name not in _cache:
        logger.info("Loading embedding model '%s' (first use in this process)...", model_name)
        from fastembed import TextEmbedding  # noqa: PLC0415

        model = TextEmbedding(model_name=model_name, cache_dir=cache_folder)
        logger.info("Embedding model ready.")
        _cache[model_name] = model

    return _cache[model_name]
