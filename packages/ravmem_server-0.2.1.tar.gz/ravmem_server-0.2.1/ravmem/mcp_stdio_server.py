"""Stdio JSON-RPC MCP server for RavMem.

Exposes all 9 RavMem tools over the Model Context Protocol stdio transport,
making RavMem compatible with Claude Desktop, Cursor, and other MCP clients.

Usage:
    ravmem-mcp --repos-dir /path/to/repos
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level repos_dir — set by main() before server.run()
# ---------------------------------------------------------------------------

_repos_dir: Path | None = None

# ---------------------------------------------------------------------------
# Server instance
# ---------------------------------------------------------------------------

server = Server("ravmem")

# ---------------------------------------------------------------------------
# Tool definitions (mirrors routes_mcp.py MCP_TOOLS)
# ---------------------------------------------------------------------------

_TOOLS = [
    types.Tool(
        name="search_symbols",
        description="Hybrid BM25 + semantic search over all indexed symbols",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "repo": {"type": "string", "description": "Repo ID or path"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query", "repo"],
        },
    ),
    types.Tool(
        name="get_impact",
        description="Return all symbols that depend on a given symbol (blast radius)",
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
                "depth": {"type": "integer", "default": 3},
            },
            "required": ["symbol_id", "repo"],
        },
    ),
    types.Tool(
        name="get_call_chain",
        description="Trace full call chain from an entry point symbol",
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
                "direction": {
                    "type": "string",
                    "enum": ["callers", "callees"],
                    "default": "callees",
                },
                "depth": {"type": "integer", "default": 5},
            },
            "required": ["symbol_id", "repo"],
        },
    ),
    types.Tool(
        name="get_cluster",
        description="Return all symbols in a cluster / module group",
        inputSchema={
            "type": "object",
            "properties": {
                "cluster_id": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["cluster_id", "repo"],
        },
    ),
    types.Tool(
        name="get_symbol",
        description="Get full details and neighbours for a specific symbol",
        inputSchema={
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["symbol_id", "repo"],
        },
    ),
    types.Tool(
        name="diff_impact",
        description="Given a git diff, return all symbols affected and their blast radius",
        inputSchema={
            "type": "object",
            "properties": {
                "diff": {"type": "string", "description": "Unified diff text"},
                "repo": {"type": "string"},
            },
            "required": ["diff", "repo"],
        },
    ),
    types.Tool(
        name="list_repos",
        description="List all indexed repositories",
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    types.Tool(
        name="suggest_entry_points",
        description=(
            "Return top-N symbols by PageRank centrality — "
            "best starting points for codebase exploration"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo": {"type": "string"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["repo"],
        },
    ),
    types.Tool(
        name="get_file_context",
        description=(
            "Get all symbols in a file plus their callers and callees — "
            "natural entry point for agents reading diffs"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "file_path": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["file_path", "repo"],
        },
    ),
]

# ---------------------------------------------------------------------------
# Helpers (must match routes_mcp.py exactly)
# ---------------------------------------------------------------------------


def _symbol_dict(s) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "kind": s.kind,
        "file": s.file,
        "line_start": s.line_start,
        "line_end": s.line_end,
        "lang": s.lang,
        "cluster_id": s.cluster_id,
        "docstring": getattr(s, "docstring", ""),
    }


def _get_engines(repo: str, repos_dir: Path | None):
    from ravmem.server.app import get_repo_engines_readonly

    # Accept either a bare repo name or an absolute path
    if repos_dir and not repo.startswith("/") and not repo[1:3] == ":\\":
        repo_path = str(repos_dir / repo)
    else:
        repo_path = repo

    return get_repo_engines_readonly(repo_path)


# ---------------------------------------------------------------------------
# Tool dispatch logic (mirrors _dispatch_tool in routes_mcp.py)
# ---------------------------------------------------------------------------


async def _dispatch_tool(name: str, params: dict, repos_dir: Path | None) -> Any:
    if name == "search_symbols":
        engines = _get_engines(params["repo"], repos_dir)
        query = params["query"]
        limit = params.get("limit", 10)
        results = engines.search_engine.search(query, k=limit)
        return [
            {
                "symbol": _symbol_dict(r.symbol),
                "score": r.score,
                "match_type": r.match_type,
                "relevance_reason": f"Matched via {r.match_type} on '{query}'",
                "summary": (
                    f"{r.symbol.kind} {r.symbol.name} in "
                    f"{os.path.basename(r.symbol.file)}"
                ),
            }
            for r in results
        ]

    elif name == "get_impact":
        engines = _get_engines(params["repo"], repos_dir)
        depth = params.get("depth", 3)
        result = engines.impact_engine.get_impact(params["symbol_id"], depth=depth)
        return {
            "root_symbol_id": result.root_symbol_id,
            "usage_hint": (
                f"Changing this symbol affects {len(result.affected)} callers "
                "— review each before modifying"
            ),
            "total_affected_count": len(result.affected),
            "affected": [
                {
                    "symbol": _symbol_dict(n.symbol),
                    "depth": n.depth,
                    "path": n.path,
                    "confidence": n.confidence if hasattr(n, "confidence") else 1.0,
                }
                for n in result.affected
            ],
        }

    elif name == "get_call_chain":
        engines = _get_engines(params["repo"], repos_dir)
        direction = params.get("direction", "callees")
        depth = params.get("depth", 5)
        symbols = engines.impact_engine.get_call_chain(
            params["symbol_id"], direction=direction, depth=depth
        )
        return [_symbol_dict(s) for s in symbols]

    elif name == "get_cluster":
        engines = _get_engines(params["repo"], repos_dir)
        members = engines.graph.get_cluster_members(params["cluster_id"])
        cluster = engines.graph.get_cluster(params["cluster_id"])
        return {
            "cluster": {
                "id": cluster.id,
                "label": cluster.label,
                "cohesion_score": cluster.cohesion_score,
                "size": cluster.size,
            }
            if cluster
            else None,
            "members": [_symbol_dict(s) for s in members],
        }

    elif name == "get_symbol":
        engines = _get_engines(params["repo"], repos_dir)
        ctx = engines.context_engine.assemble_symbol_context(params["symbol_id"])
        if ctx is None:
            raise ValueError(f"Symbol not found: {params['symbol_id']}")
        callers_list = [_symbol_dict(s) for s in ctx.callers]
        callees_list = [_symbol_dict(s) for s in ctx.callees]
        return {
            "symbol": _symbol_dict(ctx.symbol),
            "callers": callers_list,
            "callees": callees_list,
            "incoming": {"calls": callers_list},
            "outgoing": {"calls": callees_list},
            "cluster": {
                "id": ctx.cluster.id,
                "label": ctx.cluster.label,
                "cohesion_score": ctx.cluster.cohesion_score,
            }
            if ctx.cluster
            else None,
            "cluster_peers": [_symbol_dict(s) for s in ctx.cluster_peers],
        }

    elif name == "diff_impact":
        engines = _get_engines(params["repo"], repos_dir)
        diff_text = params.get("diff") or params.get("diff_text", "")
        if not diff_text:
            raise ValueError("Missing required parameter: 'diff' (unified diff text)")
        impact_results = engines.impact_engine.diff_impact(diff_text)
        output = []
        for r in impact_results:
            affected_preview = r.affected[:20]
            total = (
                r.total_affected_count if r.total_affected_count > 0 else len(r.affected)
            )
            output.append(
                {
                    "root_symbol_id": r.root_symbol_id,
                    "total_affected_count": total,
                    "truncated": len(r.affected) > 20,
                    "affected": [
                        {"symbol": _symbol_dict(n.symbol), "depth": n.depth}
                        for n in affected_preview
                    ],
                }
            )
        deleted_or_unresolved = [
            r.root_symbol_id for r in impact_results if len(r.affected) == 0
        ]
        return {
            "results": output,
            "deleted_or_unresolved_symbols": deleted_or_unresolved,
            "usage_hint": (
                "Symbols with 0 affected may have been deleted from the codebase "
                "or were never indexed — check if they still exist in the graph"
            ),
        }

    elif name == "list_repos":
        from ravmem.storage.meta import MetaStore
        from ravmem.config import INDEX_DIR, META_DB_NAME

        repos_dir_path = repos_dir if repos_dir else Path(".")
        result = []
        if repos_dir_path.exists():
            for p in sorted(repos_dir_path.iterdir()):
                meta_db = p / INDEX_DIR / META_DB_NAME
                if p.is_dir() and meta_db.exists():
                    try:
                        ms = MetaStore(meta_db)
                        repos = ms.list_repos()
                        for r in repos:
                            r["repo_path"] = str(p)
                            result.append(r)
                    except Exception as exc:
                        result.append({"repo_path": str(p), "error": str(exc)})
        return result

    elif name == "suggest_entry_points":
        engines = _get_engines(params["repo"], repos_dir)
        limit = params.get("limit", 10)
        repo_path = (
            Path(params["repo"])
            if params["repo"].startswith("/")
            else (repos_dir / params["repo"] if repos_dir else Path(params["repo"]))
        )
        repo_id = repo_path.name
        centrality = engines.meta.load_centrality(repo_id)
        if not centrality:
            return {
                "entry_points": [],
                "hint": "Run ravmem analyze first to compute centrality",
            }
        sorted_ids = sorted(centrality, key=lambda k: centrality[k], reverse=True)[
            :limit
        ]
        entry_points = []
        for sid in sorted_ids:
            sym = engines.graph.get_symbol(sid)
            if sym:
                entry_points.append(
                    {**_symbol_dict(sym), "centrality_score": centrality[sid]}
                )
        return {"entry_points": entry_points}

    elif name == "get_file_context":
        engines = _get_engines(params["repo"], repos_dir)
        file_path = params["file_path"]
        symbols = engines.graph.get_symbols_for_file(file_path)
        file_symbols = []
        for sym in symbols:
            callers = engines.graph.get_callers(sym.id, depth=1)
            callees = engines.graph.get_callees(sym.id, depth=1)
            file_symbols.append(
                {
                    "symbol": _symbol_dict(sym),
                    "callers": [_symbol_dict(s) for s in callers],
                    "callees": [_symbol_dict(s) for s in callees],
                }
            )
        return {"file_path": file_path, "symbols": file_symbols}

    else:
        raise ValueError(f"Unknown MCP tool: {name}")


# ---------------------------------------------------------------------------
# MCP handler registrations
# ---------------------------------------------------------------------------


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return _TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    global _repos_dir
    try:
        result = await _dispatch_tool(name, arguments, _repos_dir)
        return [
            types.TextContent(
                type="text",
                text=json.dumps(result, default=str),
            )
        ]
    except Exception as exc:
        logger.exception("Error in tool %s", name)
        return [
            types.TextContent(
                type="text",
                text=f"Error: {exc}",
            )
        ]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _run(repos_dir: Path | None) -> None:
    global _repos_dir
    _repos_dir = repos_dir

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ravmem-mcp",
        description="RavMem stdio MCP server — compatible with Claude Desktop, Cursor, and other MCP clients.",
    )
    parser.add_argument(
        "--repos-dir",
        type=Path,
        default=None,
        help="Directory containing indexed repositories (each sub-directory is a repo).",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: WARNING).",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        # Log to stderr so stdout stays clean for JSON-RPC
        stream=sys.stderr,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    asyncio.run(_run(args.repos_dir))


if __name__ == "__main__":
    main()
