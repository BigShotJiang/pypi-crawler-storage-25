"""Audit logger — append-only JSON-lines file at $RAVMEM_DATA_DIR/audit.log.

Captured events: token.created, token.revoked, user.created, user.disabled,
user.enabled, role.assigned, admin.token_reset.

NOT captured: permission denied / auth failures (those go to standard server logs).
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

_audit_path: Path | None = None


def _get_path() -> Path:
    global _audit_path
    if _audit_path is None:
        from ravmem.config import SERVER_DATA_DIR
        _audit_path = SERVER_DATA_DIR / "audit.log"
    return _audit_path


def log(actor: str, action: str, target: str, ip: str | None = None) -> None:
    """Append one audit event as a JSON line."""
    event = {
        "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "actor": actor,
        "action": action,
        "target": target,
    }
    if ip:
        event["ip"] = ip
    try:
        path = _get_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
    except Exception as exc:
        logger.warning("Audit log write failed: %s", exc)


def query_entries(
    since: str | None = None,
    actor: str | None = None,
    action: str | None = None,
    limit: int = 100,
    page: int = 1,
) -> dict:
    """Return paginated audit entries, most-recent first."""
    path = _get_path()
    if not path.exists():
        return {"items": [], "total": 0, "page": page, "limit": limit}

    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except Exception as exc:
        logger.warning("Audit log read failed: %s", exc)
        return {"items": [], "total": 0, "page": page, "limit": limit}

    items = []
    for line in lines:
        if not line.strip():
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if since and entry.get("ts", "") < since:
            continue
        if actor and entry.get("actor") != actor:
            continue
        if action and entry.get("action") != action:
            continue
        items.append(entry)

    items.reverse()  # most-recent first
    total = len(items)
    start = (page - 1) * limit
    return {"items": items[start: start + limit], "total": total, "page": page, "limit": limit}


def rotate_entries(retain_days: int) -> dict:
    """Delete entries older than retain_days. Returns {retained, deleted}."""
    path = _get_path()
    if not path.exists():
        return {"retained": 0, "deleted": 0}

    cutoff = datetime.now(timezone.utc) - timedelta(days=retain_days)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        lines = path.read_text(encoding="utf-8").splitlines()
        kept, deleted = [], 0
        for line in lines:
            if not line.strip():
                continue
            try:
                ts = json.loads(line).get("ts", "")
                if ts >= cutoff_str:
                    kept.append(line)
                else:
                    deleted += 1
            except (json.JSONDecodeError, ValueError):
                kept.append(line)
        path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
        return {"retained": len(kept), "deleted": deleted}
    except Exception as exc:
        logger.warning("Audit log rotate failed: %s", exc)
        return {"retained": 0, "deleted": 0}


def cleanup_old_entries() -> None:
    """Remove audit log lines older than RAVMEM_AUDIT_LOG_RETENTION_DAYS."""
    from ravmem.config import RAVMEM_AUDIT_LOG_RETENTION_DAYS

    path = _get_path()
    if not path.exists():
        return

    cutoff = datetime.now(timezone.utc) - timedelta(days=RAVMEM_AUDIT_LOG_RETENTION_DAYS)
    cutoff_str = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        lines = path.read_text(encoding="utf-8").splitlines()
        kept = []
        for line in lines:
            try:
                ts = json.loads(line).get("ts", "")
                if ts >= cutoff_str:
                    kept.append(line)
            except (json.JSONDecodeError, ValueError):
                kept.append(line)  # keep malformed lines rather than silently drop
        path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
    except Exception as exc:
        logger.warning("Audit log cleanup failed: %s", exc)
