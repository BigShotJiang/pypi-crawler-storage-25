"""Admin token bootstrap — run once at server startup.

Three-case logic:
  1. RAVMEM_ADMIN_TOKEN set in env  → store/update SHA-256 hash in ravmem_system.
  2. env unset, hash exists in DB   → load silently (token was printed on first boot).
  3. env unset, no hash in DB       → generate rv_admin_<64hex>, print once, store hash.
"""

from __future__ import annotations

import hashlib
import logging
import os
import secrets
from datetime import datetime, timezone
from pathlib import Path

import requests

logger = logging.getLogger(__name__)

# Module-level hash — set during bootstrap, read by middleware on every request.
_admin_token_hash: str = ""


def get_admin_hash() -> str:
    return _admin_token_hash


def _set_admin_hash(h: str) -> None:
    global _admin_token_hash
    _admin_token_hash = h


def _base_url() -> str:
    from ravmem.config import ARCADEDB_HOST, ARCADEDB_PORT
    return f"http://{ARCADEDB_HOST}:{ARCADEDB_PORT}"


def _auth() -> tuple[str, str]:
    from ravmem.config import ARCADEDB_PASSWORD
    return ("root", ARCADEDB_PASSWORD)


def _ensure_system_db(system_db: str) -> None:
    r = requests.get(f"{_base_url()}/api/v1/databases", auth=_auth(), timeout=10)
    r.raise_for_status()
    if system_db not in r.json().get("result", []):
        r2 = requests.post(
            f"{_base_url()}/api/v1/server",
            auth=_auth(),
            json={"command": f"create database {system_db}"},
            timeout=10,
        )
        r2.raise_for_status()
        logger.info("Created ArcadeDB database '%s'", system_db)


def _apply_schema(system_db: str) -> None:
    schema_file = Path(__file__).parent.parent / "knowledge" / "schema" / "ravmem_system_init.sql"
    sql = schema_file.read_text()
    statements = [
        line for line in sql.splitlines()
        if line.strip() and not line.strip().startswith("--")
    ]
    for stmt in statements:
        r = requests.post(
            f"{_base_url()}/api/v1/command/{system_db}",
            auth=_auth(),
            json={"language": "sql", "command": stmt},
            timeout=10,
        )
        if r.status_code not in (200, 204):
            raise RuntimeError(f"DDL failed ({r.status_code}): {stmt!r}\n{r.text}")


def _query_existing_hash(system_db: str) -> str | None:
    r = requests.post(
        f"{_base_url()}/api/v1/query/{system_db}",
        auth=_auth(),
        json={"language": "sql", "command": "SELECT hash FROM AdminToken LIMIT 1"},
        timeout=10,
    )
    if r.status_code == 200:
        rows = r.json().get("result", [])
        if rows:
            return rows[0].get("hash")
    return None


def _upsert_hash(system_db: str, new_hash: str) -> None:
    now = datetime.now(timezone.utc).isoformat()
    # Delete old row then insert fresh (single-row table pattern).
    for stmt in [
        "DELETE FROM AdminToken",
        f"INSERT INTO AdminToken SET hash = '{new_hash}', updated_at = '{now}'",
    ]:
        r = requests.post(
            f"{_base_url()}/api/v1/command/{system_db}",
            auth=_auth(),
            json={"language": "sql", "command": stmt},
            timeout=10,
        )
        if r.status_code not in (200, 204):
            raise RuntimeError(f"Upsert failed ({r.status_code}): {stmt!r}\n{r.text}")


def _print_generated_token(token: str) -> None:
    print("==========================================================")
    print("RAVMEM ADMIN TOKEN (save this — it will not be shown again):")
    print(token)
    print("Set RAVMEM_ADMIN_TOKEN env var to persist across restarts.")
    print("==========================================================")


def bootstrap(system_db: str) -> None:
    """Bootstrap ravmem_system DB and resolve the admin token hash.

    Must be called during server startup before handling requests.
    Non-fatal if ArcadeDB is unreachable — admin token still works from env var.
    """
    env_token = os.environ.get("RAVMEM_ADMIN_TOKEN", "")

    try:
        _ensure_system_db(system_db)
        _apply_schema(system_db)

        if env_token:
            new_hash = hashlib.sha256(env_token.encode()).hexdigest()
            _upsert_hash(system_db, new_hash)
            _set_admin_hash(new_hash)
            logger.info("Admin token loaded from environment")
        else:
            existing_hash = _query_existing_hash(system_db)
            if existing_hash:
                _set_admin_hash(existing_hash)
                logger.info("Admin token hash loaded from ravmem_system")
            else:
                token = f"rv_admin_{secrets.token_hex(32)}"
                new_hash = hashlib.sha256(token.encode()).hexdigest()
                _upsert_hash(system_db, new_hash)
                _set_admin_hash(new_hash)
                _print_generated_token(token)

    except Exception as exc:
        logger.warning(
            "ravmem_system bootstrap failed — using in-memory fallback: %s", exc
        )
        if env_token:
            _set_admin_hash(hashlib.sha256(env_token.encode()).hexdigest())
            logger.info("Admin token loaded from environment (in-memory only — ArcadeDB unreachable)")
        else:
            # ArcadeDB unreachable and RAVMEM_ADMIN_TOKEN not set.
            # Generate an ephemeral token so auth is still enforced.
            # This token will NOT survive a restart; fix ArcadeDB connectivity.
            token = f"rv_admin_{secrets.token_hex(32)}"
            _set_admin_hash(hashlib.sha256(token.encode()).hexdigest())
            logger.error(
                "ArcadeDB unreachable and RAVMEM_ADMIN_TOKEN is not set. "
                "Auth is enforced with a TEMPORARY token that will change on restart. "
                "Fix ArcadeDB connectivity and restart the server to persist the admin token."
            )
            _print_generated_token(token)


def rotate_admin_token(system_db: str) -> str:
    """Generate a new admin token, store its hash, return the new token.

    Called by the reset-admin-token endpoint (requires current admin token to reach this).
    Prints to server stdout (visible via docker logs / journalctl) and returns token to caller.
    Old token is invalidated instantly.
    """
    token = f"rv_admin_{secrets.token_hex(32)}"
    new_hash = hashlib.sha256(token.encode()).hexdigest()
    _upsert_hash(system_db, new_hash)
    _set_admin_hash(new_hash)
    _print_generated_token(token)
    return token
