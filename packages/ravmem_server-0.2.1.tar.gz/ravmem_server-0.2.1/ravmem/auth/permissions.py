"""Permission string constants."""

# Code graph
BRANCH_READ   = "branch:read"
BRANCH_CREATE = "branch:create"
BRANCH_INDEX  = "branch:index"
BRANCH_DELETE = "branch:delete"

REPO_READ   = "repo:read"
REPO_UPDATE = "repo:update"
REPO_CREATE = "repo:create"
REPO_DELETE = "repo:delete"

JOB_READ   = "job:read"
JOB_CANCEL = "job:cancel"

METRICS_READ = "metrics:read"

# Knowledge graph
KG_READ         = "kg:read"
KG_WRITE        = "kg:write"
KG_WRITE_GLOBAL = "kg:write_global"
KG_CONFIGURE    = "kg:configure"
KG_VALIDATE     = "kg:validate"
KG_ADMIN        = "kg:admin"

# Auth management
AUTH_MANAGE = "auth:manage"
AUTH_READ   = "auth:read"

ALL_PERMISSIONS = {
    BRANCH_READ, BRANCH_CREATE, BRANCH_INDEX, BRANCH_DELETE,
    REPO_READ, REPO_UPDATE, REPO_CREATE, REPO_DELETE,
    JOB_READ, JOB_CANCEL,
    METRICS_READ,
    KG_READ, KG_WRITE, KG_WRITE_GLOBAL, KG_CONFIGURE, KG_VALIDATE, KG_ADMIN,
    AUTH_MANAGE, AUTH_READ,
}
