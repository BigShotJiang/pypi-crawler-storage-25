"""RBAC helpers — permission resolution and enforcement.

Usage in FastAPI route handlers:
    from ravmem.auth.rbac import require_permission
    from ravmem.auth import permissions as P

    @router.post("/projects")
    async def create_project(...):
        require_permission(P.REPO_CREATE)
        ...

Usage in MCP tools — returns a dict instead of raising:
    from ravmem.auth.rbac import check_permission_mcp

    err = check_permission_mcp(P.KG_WRITE)
    if err:
        return err   # MCPToolResult with isError=True
"""

from __future__ import annotations

import json
import logging

from fastapi import HTTPException

logger = logging.getLogger(__name__)


def require_permission(permission: str) -> None:
    """Check that the current request has *permission*.

    - No auth context (dev mode): allow (backward compat).
    - Admin: allow, bypasses all RBAC.
    - User token: must have *permission* in their union-of-roles permissions.

    Raises HTTPException(401 or 403) on denial.
    """
    from ravmem.auth.context import get_auth_context

    ctx = get_auth_context()
    if ctx is None:
        return  # auth disabled — open access
    if ctx.is_admin:
        return  # admin bypasses all RBAC
    if permission not in ctx.permissions:
        raise HTTPException(
            status_code=403,
            detail=f"Permission denied: '{permission}' is required for this action.",
        )


def check_permission_mcp(permission: str) -> dict | None:
    """Check permission for MCP tool dispatch.

    Returns None if allowed, or an MCP-compliant error dict if denied.
    """
    from ravmem.auth.context import get_auth_context

    ctx = get_auth_context()
    if ctx is None:
        return None  # auth disabled
    if ctx.is_admin:
        return None  # admin bypasses all RBAC
    if permission not in ctx.permissions:
        return {
            "isError": True,
            "content": [
                {"type": "text", "text": f"Permission denied: '{permission}' is required for this action."}
            ],
        }
    return None


def resolve_user_permissions(user_id: str) -> set[str]:
    """Return the union of all permissions across the user's roles.

    Called by the auth middleware after token validation.
    Returns empty set if ArcadeDB is unreachable (non-fatal — user still authenticated).
    """
    try:
        from ravmem.auth.service import get_user_permissions
        return get_user_permissions(user_id)
    except Exception as exc:
        logger.warning("Permission resolution failed for %s: %s — defaulting to no permissions", user_id, exc)
        return set()
