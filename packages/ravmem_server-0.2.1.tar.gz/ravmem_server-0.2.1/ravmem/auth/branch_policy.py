"""Branch name regex policy enforcement.

Policies attach to roles. No policy = allow all branches.
Multiple policies per (role, permission) use OR logic.
Regex validated at creation time with re.compile().
"""

from __future__ import annotations

import asyncio
import logging
import re
import secrets

from fastapi import HTTPException

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_pattern(pattern: str) -> None:
    """Validate a Python regex. Raises ValueError with a clear message on failure."""
    try:
        re.compile(pattern)
    except re.error as exc:
        raise ValueError(
            f"Invalid branch pattern '{pattern}' — re error: {exc}"
        )


# ---------------------------------------------------------------------------
# CRUD (sync — called via asyncio.to_thread from async routes)
# ---------------------------------------------------------------------------

def add_policy(role_name: str, permission: str, pattern: str) -> dict:
    """Add a branch policy for (role, permission, pattern). Validates pattern first."""
    from ravmem.auth.service import get_role_by_name, _cmd, _query, _esc, _now_iso
    from ravmem.auth.permissions import ALL_PERMISSIONS

    validate_pattern(pattern)

    if permission not in ALL_PERMISSIONS:
        raise ValueError(f"Unknown permission '{permission}'")

    role = get_role_by_name(role_name)
    if role is None:
        raise ValueError(f"Role '{role_name}' not found")

    # Idempotent: skip if identical record already exists
    existing = _query(
        f"SELECT id FROM BranchPolicy "
        f"WHERE role_id = '{_esc(role['id'])}' "
        f"AND permission = '{_esc(permission)}' "
        f"AND branch_pattern = '{_esc(pattern)}' LIMIT 1"
    )
    if existing:
        return {"id": existing[0]["id"], "role_id": role["id"], "role": role_name,
                "permission": permission, "branch_pattern": pattern}

    policy_id = f"bp_{secrets.token_hex(8)}"
    _cmd(
        f"INSERT INTO BranchPolicy SET "
        f"id = '{policy_id}', role_id = '{_esc(role['id'])}', "
        f"permission = '{_esc(permission)}', branch_pattern = '{_esc(pattern)}'"
    )
    return {"id": policy_id, "role_id": role["id"], "role": role_name,
            "permission": permission, "branch_pattern": pattern}


def remove_policy(role_name: str, permission: str, pattern: str) -> None:
    """Remove a branch policy. No-op if not found."""
    from ravmem.auth.service import get_role_by_name, _cmd, _esc

    role = get_role_by_name(role_name)
    if role is None:
        raise ValueError(f"Role '{role_name}' not found")

    _cmd(
        f"DELETE FROM BranchPolicy "
        f"WHERE role_id = '{_esc(role['id'])}' "
        f"AND permission = '{_esc(permission)}' "
        f"AND branch_pattern = '{_esc(pattern)}'"
    )


def list_policies(role_name: str) -> list[dict]:
    """List all branch policies for a role."""
    from ravmem.auth.service import get_role_by_name, _query, _esc

    role = get_role_by_name(role_name)
    if role is None:
        raise ValueError(f"Role '{role_name}' not found")

    rows = _query(
        f"SELECT id, role_id, permission, branch_pattern "
        f"FROM BranchPolicy WHERE role_id = '{_esc(role['id'])}' "
        f"ORDER BY permission"
    )
    for r in rows:
        r["role"] = role_name
    return rows


# ---------------------------------------------------------------------------
# Enforcement
# ---------------------------------------------------------------------------

def _check_sync(permission: str, branch_name: str) -> bool:
    """Sync branch policy check. True = allowed."""
    from ravmem.auth.context import get_auth_context
    from ravmem.auth.service import _query, _esc

    ctx = get_auth_context()
    if ctx is None or ctx.is_admin:
        return True

    user_roles = _query(f"SELECT role_id FROM UserRole WHERE user_id = '{_esc(ctx.user_id)}'")
    if not user_roles:
        return True  # no roles → no policies → allow

    role_ids = [r["role_id"] for r in user_roles]
    role_ids_sql = ", ".join(f"'{_esc(rid)}'" for rid in role_ids)

    policies = _query(
        f"SELECT branch_pattern FROM BranchPolicy "
        f"WHERE role_id IN [{role_ids_sql}] AND permission = '{_esc(permission)}'"
    )

    if not policies:
        return True  # no restrictions → allow all branches

    # OR logic: allow if ANY pattern matches
    for p in policies:
        try:
            if re.match(p.get("branch_pattern", ""), branch_name):
                return True
        except re.error:
            logger.warning("Skipping invalid stored branch pattern: %r", p.get("branch_pattern"))

    return False


async def require_branch_policy(permission: str, branch_name: str) -> None:
    """Async wrapper — call in FastAPI route handlers after require_permission().

    Raises HTTPException(403) if branch does not match any allowed pattern.
    No-op in dev mode (no auth context) or for admin.
    """
    allowed = await asyncio.to_thread(_check_sync, permission, branch_name)
    if not allowed:
        raise HTTPException(
            status_code=403,
            detail=(
                f"Permission denied: branch '{branch_name}' does not match "
                f"any allowed pattern for '{permission}'."
            ),
        )
