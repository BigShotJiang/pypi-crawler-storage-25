"""User and token CRUD against ravmem_system ArcadeDB.

All DB calls use the same requests-based pattern as knowledge/schema/apply_schema.py.
"""

from __future__ import annotations

import hashlib
import logging
import secrets
import time
from datetime import datetime, timezone, timedelta

import bcrypt
import requests

logger = logging.getLogger(__name__)

# In-memory cache for last_used_at throttle: {token_hash: epoch_seconds}
_last_used_cache: dict[str, float] = {}
_LAST_USED_TTL = 900  # 15 minutes


def _base_url() -> str:
    from ravmem.config import ARCADEDB_HOST, ARCADEDB_PORT
    return f"http://{ARCADEDB_HOST}:{ARCADEDB_PORT}"


def _auth() -> tuple[str, str]:
    from ravmem.config import ARCADEDB_PASSWORD
    return ("root", ARCADEDB_PASSWORD)


def _db() -> str:
    from ravmem.config import RAVMEM_SYSTEM_DB
    return RAVMEM_SYSTEM_DB


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _esc(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _cmd(sql: str, timeout: int = 10) -> list[dict]:
    r = requests.post(
        f"{_base_url()}/api/v1/command/{_db()}",
        auth=_auth(),
        json={"language": "sql", "command": sql},
        timeout=timeout,
    )
    if r.status_code not in (200, 204):
        raise RuntimeError(f"DB error ({r.status_code}): {sql!r}\n{r.text}")
    return r.json().get("result", [])


def _query(sql: str, timeout: int = 10) -> list[dict]:
    r = requests.post(
        f"{_base_url()}/api/v1/query/{_db()}",
        auth=_auth(),
        json={"language": "sql", "command": sql},
        timeout=timeout,
    )
    if r.status_code not in (200, 204):
        raise RuntimeError(f"DB error ({r.status_code}): {sql!r}\n{r.text}")
    return r.json().get("result", [])


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def _check_password(password: str, password_hash: str) -> bool:
    return bcrypt.checkpw(password.encode(), password_hash.encode())


def create_user(email: str, name: str, username: str | None = None, password: str | None = None) -> dict:
    """Create a new active user. Raises ValueError if email or username already exists."""
    rows = _query(f"SELECT id FROM User WHERE email = '{_esc(email)}' LIMIT 1")
    if rows:
        raise ValueError(f"User with email '{email}' already exists")

    effective_username = username or email.split("@")[0]
    rows = _query(f"SELECT id FROM User WHERE username = '{_esc(effective_username)}' LIMIT 1")
    if rows:
        raise ValueError(f"Username '{effective_username}' already taken")

    user_id = f"usr_{secrets.token_hex(8)}"
    now = _now_iso()
    pw_hash = _hash_password(password) if password else ""
    _cmd(
        f"INSERT INTO User SET id = '{user_id}', email = '{_esc(email)}', "
        f"username = '{_esc(effective_username)}', name = '{_esc(name)}', "
        f"password_hash = '{_esc(pw_hash)}', created_at = '{now}', status = 'active'"
    )
    return {
        "id": user_id,
        "email": email,
        "username": effective_username,
        "name": name,
        "created_at": now,
        "status": "active",
    }


def get_user_by_id(user_id: str) -> dict | None:
    rows = _query(
        f"SELECT id, email, username, name, created_at, status FROM User "
        f"WHERE id = '{_esc(user_id)}' LIMIT 1"
    )
    return rows[0] if rows else None


def get_user_by_email(email: str) -> dict | None:
    rows = _query(
        f"SELECT id, email, username, name, created_at, status FROM User "
        f"WHERE email = '{_esc(email)}' LIMIT 1"
    )
    return rows[0] if rows else None


def get_user_by_username(username: str) -> dict | None:
    rows = _query(
        f"SELECT id, email, username, name, password_hash, created_at, status FROM User "
        f"WHERE username = '{_esc(username)}' LIMIT 1"
    )
    return rows[0] if rows else None


def verify_password(username_or_email: str, password: str) -> dict | None:
    """Return user dict on success, None on failure. Constant-time on not-found."""
    if "@" in username_or_email:
        rows = _query(
            f"SELECT id, email, username, name, password_hash, created_at, status FROM User "
            f"WHERE email = '{_esc(username_or_email)}' LIMIT 1"
        )
    else:
        rows = _query(
            f"SELECT id, email, username, name, password_hash, created_at, status FROM User "
            f"WHERE username = '{_esc(username_or_email)}' LIMIT 1"
        )
    if not rows:
        # Constant-time dummy check to avoid timing oracle
        bcrypt.checkpw(b"dummy", bcrypt.hashpw(b"dummy", bcrypt.gensalt()))
        return None
    user = rows[0]
    pw_hash = user.get("password_hash", "")
    if not pw_hash or not _check_password(password, pw_hash):
        return None
    if user.get("status") != "active":
        return None
    user.pop("password_hash", None)
    return user


def list_users() -> list[dict]:
    users = _query("SELECT id, email, username, name, created_at, status FROM User ORDER BY created_at")
    for u in users:
        u["roles"] = get_user_roles(u["id"])
    return users


def delete_user(user_id: str) -> None:
    """Delete a user, all their tokens, and all their role assignments."""
    _cmd(f"DELETE FROM ApiToken WHERE user_id = '{_esc(user_id)}'")
    _cmd(f"DELETE FROM UserRole WHERE user_id = '{_esc(user_id)}'")
    _cmd(f"DELETE FROM User WHERE id = '{_esc(user_id)}'")


def set_user_status(user_id: str, status: str) -> None:
    """Enable or disable a user. Disabling eagerly revokes all their tokens."""
    if status not in ("active", "disabled"):
        raise ValueError(f"Invalid status: {status!r}")
    _cmd(f"UPDATE User SET status = '{status}' WHERE id = '{_esc(user_id)}'")
    if status == "disabled":
        _cmd(f"UPDATE ApiToken SET status = 'revoked' WHERE user_id = '{_esc(user_id)}'")


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------

def create_token(user_id: str, name: str, expires_at: datetime | None = None) -> tuple[str, dict]:
    """Generate a new API token. Returns (raw_token, token_record).

    raw_token is returned once — it is never stored plain in the DB.
    """
    raw = f"rvt_{secrets.token_hex(32)}"
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    token_id = f"tk_{secrets.token_hex(8)}"
    now = _now_iso()
    expires_str = expires_at.strftime("%Y-%m-%dT%H:%M:%SZ") if expires_at else ""

    _cmd(
        f"INSERT INTO ApiToken SET "
        f"id = '{token_id}', user_id = '{_esc(user_id)}', name = '{_esc(name)}', "
        f"hash = '{token_hash}', expires_at = '{expires_str}', "
        f"last_used_at = '', status = 'active', created_at = '{now}'"
    )
    record = {
        "id": token_id,
        "user_id": user_id,
        "name": name,
        "expires_at": expires_str or None,
        "created_at": now,
        "status": "active",
    }
    return raw, record


def revoke_token(token_id: str) -> bool:
    """Revoke a token by ID. Returns True if it existed."""
    rows = _query(f"SELECT id FROM ApiToken WHERE id = '{_esc(token_id)}' LIMIT 1")
    if not rows:
        return False
    _cmd(f"UPDATE ApiToken SET status = 'revoked' WHERE id = '{_esc(token_id)}'")
    return True


def revoke_all_tokens_for_user(user_id: str) -> int:
    """Revoke all active tokens for a user. Returns count revoked."""
    rows = _query(f"SELECT id FROM ApiToken WHERE user_id = '{_esc(user_id)}' AND status = 'active'")
    if not rows:
        return 0
    _cmd(f"UPDATE ApiToken SET status = 'revoked' WHERE user_id = '{_esc(user_id)}'")
    return len(rows)


def list_tokens(user_id: str | None = None) -> list[dict]:
    """List tokens. user_id=None returns all (admin view)."""
    if user_id:
        rows = _query(
            f"SELECT id, user_id, name, expires_at, last_used_at, status, created_at "
            f"FROM ApiToken WHERE user_id = '{_esc(user_id)}' ORDER BY created_at"
        )
    else:
        rows = _query(
            "SELECT id, user_id, name, expires_at, last_used_at, status, created_at "
            "FROM ApiToken ORDER BY created_at"
        )
    return rows


# ---------------------------------------------------------------------------
# Middleware lookup
# ---------------------------------------------------------------------------

def lookup_token(token_hash: str) -> dict | None:
    """Look up a token by its SHA-256 hash.

    Returns the token record if valid (active, not expired), else None.
    Raises requests.ConnectionError / requests.Timeout if ArcadeDB is unreachable.
    """
    rows = _query(
        f"SELECT id, user_id, expires_at, last_used_at, status "
        f"FROM ApiToken WHERE hash = '{_esc(token_hash)}' LIMIT 1"
    )
    if not rows:
        return None

    tok = rows[0]
    if tok.get("status") != "active":
        return None

    expires_str = tok.get("expires_at", "")
    if expires_str:
        try:
            exp = datetime.fromisoformat(expires_str.replace("Z", "+00:00"))
            if datetime.now(timezone.utc) > exp:
                return None
        except ValueError:
            pass

    # Verify user is still active
    user_rows = _query(f"SELECT status FROM User WHERE id = '{_esc(tok['user_id'])}' LIMIT 1")
    if not user_rows or user_rows[0].get("status") != "active":
        return None

    return tok


def update_last_used(token_id: str, token_hash: str) -> None:
    """Fire-and-forget last_used_at update — throttled to once per 15 minutes."""
    now_ts = time.time()
    last = _last_used_cache.get(token_hash, 0.0)
    if now_ts - last < _LAST_USED_TTL:
        return
    _last_used_cache[token_hash] = now_ts
    try:
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        _cmd(f"UPDATE ApiToken SET last_used_at = '{now_iso}' WHERE id = '{_esc(token_id)}'")
    except Exception as exc:
        logger.debug("last_used_at update failed (non-fatal): %s", exc)


# ---------------------------------------------------------------------------
# Roles (Phase 3)
# ---------------------------------------------------------------------------

import json as _json


def create_role(name: str) -> dict:
    """Create a new role with no permissions. Raises if name already exists."""
    rows = _query(f"SELECT id FROM Role WHERE name = '{_esc(name)}' LIMIT 1")
    if rows:
        raise ValueError(f"Role '{name}' already exists")
    role_id = f"role_{secrets.token_hex(8)}"
    _cmd(
        f"INSERT INTO Role SET id = '{role_id}', name = '{_esc(name)}', permissions = '[]'"
    )
    return {"id": role_id, "name": name, "permissions": []}


def get_role_by_name(name: str) -> dict | None:
    rows = _query(f"SELECT id, name, permissions FROM Role WHERE name = '{_esc(name)}' LIMIT 1")
    if not rows:
        return None
    r = rows[0]
    try:
        r["permissions"] = _json.loads(r.get("permissions") or "[]")
    except (ValueError, TypeError):
        r["permissions"] = []
    return r


def get_role_by_id(role_id: str) -> dict | None:
    rows = _query(f"SELECT id, name, permissions FROM Role WHERE id = '{_esc(role_id)}' LIMIT 1")
    if not rows:
        return None
    r = rows[0]
    try:
        r["permissions"] = _json.loads(r.get("permissions") or "[]")
    except (ValueError, TypeError):
        r["permissions"] = []
    return r


def list_roles() -> list[dict]:
    rows = _query("SELECT id, name, permissions FROM Role ORDER BY name")
    for r in rows:
        try:
            r["permissions"] = _json.loads(r.get("permissions") or "[]")
        except (ValueError, TypeError):
            r["permissions"] = []
    return rows


def delete_role(name: str) -> None:
    """Delete a role. Raises ValueError if any users are assigned to it."""
    role = get_role_by_name(name)
    if role is None:
        raise ValueError(f"Role '{name}' not found")
    assigned = _query(f"SELECT user_id FROM UserRole WHERE role_id = '{_esc(role['id'])}' LIMIT 1")
    if assigned:
        raise ValueError(f"Role '{name}' cannot be deleted — users are still assigned to it")
    _cmd(f"DELETE FROM Role WHERE id = '{_esc(role['id'])}'")


def add_permission_to_role(name: str, permission: str) -> dict:
    from ravmem.auth.permissions import ALL_PERMISSIONS
    if permission not in ALL_PERMISSIONS:
        raise ValueError(f"Unknown permission '{permission}'")
    role = get_role_by_name(name)
    if role is None:
        raise ValueError(f"Role '{name}' not found")
    perms: list = role["permissions"]
    if permission not in perms:
        perms.append(permission)
        _cmd(
            f"UPDATE Role SET permissions = '{_esc(_json.dumps(perms))}' "
            f"WHERE id = '{_esc(role['id'])}'"
        )
    role["permissions"] = perms
    return role


def remove_permission_from_role(name: str, permission: str) -> dict:
    role = get_role_by_name(name)
    if role is None:
        raise ValueError(f"Role '{name}' not found")
    perms: list = role["permissions"]
    if permission in perms:
        perms.remove(permission)
        _cmd(
            f"UPDATE Role SET permissions = '{_esc(_json.dumps(perms))}' "
            f"WHERE id = '{_esc(role['id'])}'"
        )
    role["permissions"] = perms
    return role


def assign_role(user_id: str, role_name: str, granted_by: str) -> None:
    role = get_role_by_name(role_name)
    if role is None:
        raise ValueError(f"Role '{role_name}' not found")
    existing = _query(
        f"SELECT user_id FROM UserRole WHERE user_id = '{_esc(user_id)}' "
        f"AND role_id = '{_esc(role['id'])}' LIMIT 1"
    )
    if existing:
        return  # already assigned — idempotent
    now = _now_iso()
    _cmd(
        f"INSERT INTO UserRole SET user_id = '{_esc(user_id)}', "
        f"role_id = '{_esc(role['id'])}', granted_at = '{now}', granted_by = '{_esc(granted_by)}'"
    )


def unassign_role(user_id: str, role_name: str) -> None:
    role = get_role_by_name(role_name)
    if role is None:
        raise ValueError(f"Role '{role_name}' not found")
    _cmd(
        f"DELETE FROM UserRole WHERE user_id = '{_esc(user_id)}' "
        f"AND role_id = '{_esc(role['id'])}'"
    )


def get_user_roles(user_id: str) -> list[str]:
    """Return list of role names assigned to the user."""
    user_roles = _query(f"SELECT role_id FROM UserRole WHERE user_id = '{_esc(user_id)}'")
    names = []
    for ur in user_roles:
        role = get_role_by_id(ur["role_id"])
        if role:
            names.append(role["name"])
    return names


def get_user_permissions(user_id: str) -> set[str]:
    """Return the union of all permissions across the user's assigned roles."""
    user_roles = _query(f"SELECT role_id FROM UserRole WHERE user_id = '{_esc(user_id)}'")
    if not user_roles:
        return set()
    all_perms: set[str] = set()
    for ur in user_roles:
        role = get_role_by_id(ur["role_id"])
        if role:
            all_perms.update(role.get("permissions", []))
    return all_perms


# ---------------------------------------------------------------------------
# Rate limit tiers (Phase 3)
# ---------------------------------------------------------------------------

_VALID_TIERS = {"high", "standard", "restricted"}
_ASSIGNABLE_TIERS = _VALID_TIERS  # 'admin' is never assignable


def set_role_tier(name: str, tier: str) -> dict:
    """Set the rate_limit_tier on a role. Returns the updated role dict."""
    if tier == "admin":
        raise ValueError("'admin' tier cannot be assigned to a role — it is automatic for the admin token")
    if tier not in _VALID_TIERS:
        raise ValueError(f"Invalid tier '{tier}' — must be one of: {', '.join(sorted(_VALID_TIERS))}")
    role = get_role_by_name(name)
    if role is None:
        raise ValueError(f"Role '{name}' not found")
    _cmd(f"UPDATE Role SET rate_limit_tier = '{_esc(tier)}' WHERE id = '{_esc(role['id'])}'")
    role["rate_limit_tier"] = tier
    return role


def get_role_tier(name: str) -> str:
    """Return the rate_limit_tier for a role (defaults to 'standard')."""
    rows = _query(f"SELECT rate_limit_tier FROM Role WHERE name = '{_esc(name)}' LIMIT 1")
    if not rows:
        return "standard"
    return rows[0].get("rate_limit_tier") or "standard"


def get_role_tiers_for_user(user_id: str) -> list[str]:
    """Return all rate_limit_tier values across the user's assigned roles."""
    user_roles = _query(f"SELECT role_id FROM UserRole WHERE user_id = '{_esc(user_id)}'")
    tiers: list[str] = []
    for ur in user_roles:
        rows = _query(f"SELECT rate_limit_tier FROM Role WHERE id = '{_esc(ur['role_id'])}' LIMIT 1")
        if rows:
            t = rows[0].get("rate_limit_tier")
            if t:
                tiers.append(t)
    return tiers or ["standard"]
