"""Auth context — propagates resolved identity through a request via ContextVar."""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field


@dataclass
class AuthContext:
    user_id: str
    permissions: set[str] = field(default_factory=set)
    is_admin: bool = False


_auth_ctx: ContextVar[AuthContext | None] = ContextVar("auth_ctx", default=None)


def get_auth_context() -> AuthContext | None:
    return _auth_ctx.get()


def set_auth_context(ctx: AuthContext) -> None:
    _auth_ctx.set(ctx)
