# Knowledge graph layer — isolated from codegraph
