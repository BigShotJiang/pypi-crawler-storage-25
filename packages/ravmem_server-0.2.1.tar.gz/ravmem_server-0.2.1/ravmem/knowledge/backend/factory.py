"""Backend factory — resolves RAVMEM_KG_BACKEND → KnowledgeBackend instance."""

from __future__ import annotations

import os

from ravmem.knowledge.backend.base import KnowledgeBackend


def create_backend() -> KnowledgeBackend:
    backend = os.environ.get("RAVMEM_KG_BACKEND", "arcade").lower()
    if backend == "arcade":
        from ravmem.knowledge.backend.arcade_backend import ArcadeBackend
        return ArcadeBackend()
    raise ValueError(f"Unknown KG backend: {backend!r}. Only 'arcade' is supported.")
