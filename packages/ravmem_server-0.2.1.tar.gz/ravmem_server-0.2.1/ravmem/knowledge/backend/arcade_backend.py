"""ArcadeDB implementation of KnowledgeBackend.

Uses the arcadedb-python HTTP client (arcadedb_python.DatabaseDao) against an
external ArcadeDB server. All DDL is applied via apply_schema.py at startup.

API patterns (learned from spike):
  reads  : db.query("sql", sql)              → list[dict]
  writes : db.execute_transaction([sql, …])  → list[list[dict]]
  upsert : UPDATE … SET … UPSERT WHERE <indexed-field>=…
  edges  : CREATE EDGE EdgeType FROM (SELECT …) TO (SELECT …)
  expand : SELECT expand(out('EdgeType')) FROM KGNode WHERE id=…
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime
from typing import Any

from ravmem.knowledge.backend.base import (
    BranchDelta,
    KGEdge,
    KGNode,
    KnowledgeBackend,
    TaskContext,
)
from ravmem.knowledge.config import KGConfig, load_env_overrides
from ravmem.knowledge.schema.apply_schema import apply_schema

logger = logging.getLogger(__name__)

_PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def _new_id() -> str:
    return uuid.uuid4().hex[:16]


def _esc(v: str | None) -> str:
    """Escape string for inline ArcadeDB SQL single-quoted literals."""
    if not v:
        return ""
    return str(v).replace("\\", "\\\\").replace("'", "\\'")


def _now() -> str:
    return datetime.utcnow().isoformat()


class ArcadeBackend(KnowledgeBackend):

    def __init__(self) -> None:
        from arcadedb_python import DatabaseDao, SyncClient
        from ravmem.config import ARCADEDB_HOST, ARCADEDB_PORT, ARCADEDB_PASSWORD
        import os

        self._client = SyncClient(
            host=ARCADEDB_HOST,
            port=ARCADEDB_PORT,
            username="root",
            password=ARCADEDB_PASSWORD,
        )
        db_name = os.environ.get("ARCADEDB_KG_DATABASE", "knowledge")
        self._db = DatabaseDao(client=self._client, database_name=db_name)
        self._db_name = db_name

        # Learning engine — lazy import to avoid circular at module level
        self._learning_engine: "LearningEngine | None" = None

    @property
    def learning_engine(self) -> "LearningEngine":
        if self._learning_engine is None:
            from ravmem.knowledge.learning_engine import LearningEngine
            self._learning_engine = LearningEngine(self)
        return self._learning_engine

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _q(self, sql: str) -> list[dict]:
        return self._db.query("sql", sql)

    def _cmd(self, *sqls: str) -> list:
        return self._db.execute_transaction(list(sqls))

    def _node(self, row: dict, cfg: KGConfig | None = None) -> KGNode:
        omit = cfg is not None and not cfg.confidence_enabled
        return KGNode.from_arcade_row(row, omit_confidence=omit)

    def _scope_filter(self, repo_id: str, task_type: str) -> str:
        scopes = f"['global', 'project:{_esc(repo_id)}', 'task_type:{_esc(task_type)}']"
        return f"scope IN {scopes}"

    def _branch_filter(self, branch: str) -> str:
        return f"branch IN ['{_esc(branch)}', 'global']"

    def _created_by_filter(self) -> str | None:
        """Return a SQL filter clause for created_by scoping, or None if not restricted."""
        try:
            from ravmem.auth.context import get_auth_context
            from ravmem.auth.permissions import KG_ADMIN
            ctx = get_auth_context()
            if ctx is None or ctx.is_admin or KG_ADMIN in ctx.permissions:
                return None
            return f"(created_by IN ['{_esc(ctx.user_id)}', 'global'] OR created_by IS NULL)"
        except Exception:
            return None

    def _resolve_created_by(self, global_node: bool = False) -> str:
        """Resolve the created_by value for a new node from auth context."""
        try:
            from ravmem.auth.context import get_auth_context
            from ravmem.auth.permissions import KG_WRITE_GLOBAL
            ctx = get_auth_context()
            if ctx is None:
                return "global"  # dev mode
            if global_node:
                if ctx.is_admin or KG_WRITE_GLOBAL in ctx.permissions:
                    return "global"
                raise PermissionError("'kg:write_global' is required to create global nodes")
            if ctx.is_admin:
                return "global"
            return ctx.user_id
        except PermissionError:
            raise
        except Exception:
            return "global"

    # ── Config ────────────────────────────────────────────────────────────────

    async def get_config(self, team_id: str, branch: str) -> KGConfig:
        key = f"{team_id}::{branch}"
        rows = self._q(f"SELECT FROM KGConfig WHERE config_key='{_esc(key)}'")
        if not rows:
            return load_env_overrides(KGConfig.default(team_id=team_id, branch=branch))
        row = rows[0]
        cfg = KGConfig(
            team_id=row["team_id"],
            branch=row["branch"],
            mode=row.get("mode", "hitl"),
            confidence_enabled=bool(row.get("confidence_enabled", True)),
            hitl_ai_cap=float(row.get("hitl_ai_cap", 0.70)),
            auto_ai_cap=float(row.get("auto_ai_cap", 1.0)),
            disabled_node_types=json.loads(row.get("disabled_node_types", "[]")),
            custom_node_types=row.get("custom_node_types", "[]"),
        )
        return load_env_overrides(cfg)

    async def save_config(self, cfg: KGConfig) -> None:
        key = _esc(cfg.config_key)
        disabled = _esc(json.dumps(cfg.disabled_node_types))
        custom = _esc(cfg.custom_node_types)
        self._cmd(
            f"UPDATE KGConfig SET "
            f"config_key='{key}', team_id='{_esc(cfg.team_id)}', branch='{_esc(cfg.branch)}', "
            f"mode='{_esc(cfg.mode)}', confidence_enabled={str(cfg.confidence_enabled).lower()}, "
            f"hitl_ai_cap={cfg.hitl_ai_cap}, auto_ai_cap={cfg.auto_ai_cap}, "
            f"disabled_node_types='{disabled}', custom_node_types='{custom}' "
            f"UPSERT WHERE config_key='{key}'"
        )

    # ── Schema ────────────────────────────────────────────────────────────────

    async def ensure_schema(self) -> None:
        apply_schema(verbose=False)
        logger.info("Knowledge graph schema verified on '%s'", self._db_name)

    # ── Node reads ────────────────────────────────────────────────────────────

    async def get_node(self, node_id: str, branch: str, team_id: str) -> KGNode | None:
        cfg = await self.get_config(team_id, branch)
        where = (
            f"id='{_esc(node_id)}' "
            f"AND {self._branch_filter(branch)} AND team_id='{_esc(team_id)}'"
        )
        cb_filter = self._created_by_filter()
        if cb_filter:
            where += f" AND {cb_filter}"
        rows = self._q(f"SELECT FROM KGNode WHERE {where}")
        return self._node(rows[0], cfg) if rows else None

    async def list_nodes(
        self,
        node_type: str,
        branch: str,
        team_id: str,
        scope: str | None = None,
        active_only: bool = True,
    ) -> list[KGNode]:
        cfg = await self.get_config(team_id, branch)
        where = (
            f"type='{_esc(node_type)}' "
            f"AND {self._branch_filter(branch)} "
            f"AND team_id='{_esc(team_id)}'"
        )
        if active_only:
            where += " AND active=true"
        if scope:
            where += f" AND scope='{_esc(scope)}'"
        cb_filter = self._created_by_filter()
        if cb_filter:
            where += f" AND {cb_filter}"
        rows = self._q(f"SELECT FROM KGNode WHERE {where}")
        return [self._node(r, cfg) for r in rows]

    async def get_edges(
        self,
        branch: str,
        team_id: str,
        edge_types: list[str] | None = None,
    ) -> list[dict]:
        """Get all edges in the knowledge graph.

        Args:
            branch: Knowledge branch to query
            team_id: Team ID to query
            edge_types: Optional filter for specific edge types (e.g., ['HAS_INSTRUCTION', 'LEARNED'])

        Returns:
            List of edge dicts with 'src', 'dst', 'type', and optional properties
        """
        all_edge_types = [
            "HAS_INSTRUCTION",
            "HAS_CONDITION",
            "LEARNED",
            "LED_TO",
            "BLOCKED_BY",
            "RESOLVES",
            "OVERRIDES",
            "VALIDATED_BY",
            "CONTRADICTS",
            "DERIVED_FROM",
            "SIMILAR_TO",
        ]
        types_to_query = edge_types if edge_types else all_edge_types
        branch_filter = self._branch_filter(branch)
        results: list[dict] = []

        for edge_type in types_to_query:
            if edge_type not in all_edge_types:
                continue
            rows = self._q(
                f"SELECT @out.id AS src, @in.id AS dst FROM {edge_type} "
                f"WHERE @out.branch {branch_filter} AND @out.team_id='{_esc(team_id)}'"
            )
            for r in rows:
                if r.get("src") and r.get("dst"):
                    results.append({
                        "src": r["src"],
                        "dst": r["dst"],
                        "type": edge_type,
                    })

        return results

    async def search_knowledge(
        self,
        query: str,
        branch: str,
        team_id: str,
        node_types: list[str] | None = None,
        limit: int = 10,
    ) -> list[KGNode]:
        cfg = await self.get_config(team_id, branch)
        where = (
            f"active=true "
            f"AND {self._branch_filter(branch)} "
            f"AND team_id='{_esc(team_id)}'"
        )
        if node_types:
            types_sql = ", ".join(f"'{_esc(t)}'" for t in node_types)
            where += f" AND type IN [{types_sql}]"
        # Text match fallback (JVector semantic search added in Phase 5)
        escaped_q = _esc(query)
        where += f" AND (label LIKE '%{escaped_q}%' OR properties_json LIKE '%{escaped_q}%')"
        cb_filter = self._created_by_filter()
        if cb_filter:
            where += f" AND {cb_filter}"
        rows = self._q(f"SELECT FROM KGNode WHERE {where} LIMIT {limit}")
        return [self._node(r, cfg) for r in rows]

    # ── Node writes — internal ────────────────────────────────────────────────

    def _insert_node(self, node_type: str, fields: dict[str, Any]) -> KGNode:
        """Build and execute an INSERT INTO KGNode statement."""
        node_id = fields.get("id") or _new_id()
        now = _now()
        global_node = bool(fields.pop("global_node", False))
        base: dict[str, Any] = {
            "id": node_id,
            "type": node_type,
            "label": fields.get("label", ""),
            "scope": fields.get("scope", "global"),
            "branch": fields.get("branch", "global"),
            "team_id": fields.get("team_id", ""),
            "source": fields.get("source", "agent"),
            "author_id": fields.get("author_id", ""),
            "active": True,
            "confidence": fields.get("confidence", 0.0),
            "validated_by_human": fields.get("validated_by_human", False),
            "created_by": self._resolve_created_by(global_node),
            "created_at": now,
            "updated_at": now,
        }
        # Merge all extra type-specific fields
        for k, v in fields.items():
            if k not in base and v is not None:
                base[k] = v

        parts = []
        for k, v in base.items():
            if isinstance(v, bool):
                parts.append(f"{k}={str(v).lower()}")
            elif isinstance(v, (int, float)):
                parts.append(f"{k}={v}")
            elif isinstance(v, list):
                parts.append(f"{k}='{_esc(json.dumps(v))}'")
            else:
                parts.append(f"{k}='{_esc(str(v))}'")

        sql = f"INSERT INTO KGNode SET {', '.join(parts)}"
        result = self._cmd(sql)
        row = result[0][0] if result and result[0] else {}
        # Rebuild a clean row from base fields since ArcadeDB echoes the insert
        row.update(base)
        return KGNode.from_arcade_row(row)

    def _create_edge(self, from_id: str, to_id: str, edge_type: str, props: dict | None = None) -> None:
        prop_sql = ""
        if props:
            kv = ", ".join(
                f"{k}={str(v).lower()}" if isinstance(v, bool)
                else f"{k}={v}" if isinstance(v, (int, float))
                else f"{k}='{_esc(str(v))}'"
                for k, v in props.items()
            )
            prop_sql = f" SET {kv}"
        self._cmd(
            f"CREATE EDGE {edge_type}{prop_sql} "
            f"FROM (SELECT FROM KGNode WHERE id='{_esc(from_id)}') "
            f"TO (SELECT FROM KGNode WHERE id='{_esc(to_id)}')"
        )

    # ── Task ─────────────────────────────────────────────────────────────────

    async def create_task(
        self,
        label: str,
        task_type: str,
        repo_id: str,
        git_branch: str,
        agent_id: str,
        branch: str,
        team_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Task"):
            raise ValueError("Task node type is disabled in KGConfig")

        node = self._insert_node("Task", {
            "label": label,
            "task_type": task_type,
            "repo_id": repo_id,
            "git_branch": git_branch,
            "agent_id": agent_id,
            "branch": branch,
            "team_id": team_id,
            "source": "agent",
            "author_id": agent_id,
            "status": "in_progress",
            "scope": f"project:{repo_id}",
        })

        # Auto-link instructions+conditions from matching TaskPatterns
        await self._link_task_patterns(node.id, task_type, branch, team_id)
        return node

    async def _link_task_patterns(
        self, task_id: str, task_type: str, branch: str, team_id: str
    ) -> None:
        patterns = self._q(
            f"SELECT FROM KGNode WHERE type='TaskPattern' AND active=true "
            f"AND {self._branch_filter(branch)} AND team_id='{_esc(team_id)}'"
        )
        for pat in patterns:
            pattern_str = pat.get("task_type_pattern", "")
            if not pattern_str or task_type not in pattern_str:
                continue
            pat_id = pat["id"]
            # Increment match_count
            self._cmd(
                f"UPDATE KGNode SET match_count = coalesce(match_count, 0) + 1 "
                f"WHERE id='{_esc(pat_id)}'"
            )
            # Traverse and link associated instructions
            instr = self._q(
                f"SELECT expand(out('HAS_INSTRUCTION')) FROM KGNode WHERE id='{_esc(pat_id)}'"
            )
            for i in instr:
                self._create_edge(task_id, i["id"], "HAS_INSTRUCTION")
            # Traverse and link associated conditions
            conds = self._q(
                f"SELECT expand(out('HAS_CONDITION')) FROM KGNode WHERE id='{_esc(pat_id)}'"
            )
            for c in conds:
                self._create_edge(task_id, c["id"], "HAS_CONDITION")

    async def complete_task(
        self, task_id: str, outcome: str, branch: str, team_id: str
    ) -> KGNode:
        self._cmd(
            f"UPDATE KGNode SET status='completed', outcome='{_esc(outcome)}', "
            f"updated_at='{_now()}' WHERE id='{_esc(task_id)}'"
        )
        node = await self.get_node(task_id, branch, team_id)
        if node is None:
            raise ValueError(f"Task {task_id!r} not found")
        # Surface any learnings ready for human promotion review
        candidates = await self.learning_engine.evaluate_promotions(task_id, branch, team_id)
        if candidates:
            logger.info(
                "Task %s completed — %d learning(s) ready for human review: %s",
                task_id,
                len(candidates),
                [c.node.id for c in candidates],
            )
        return node

    # ── Learning ─────────────────────────────────────────────────────────────

    async def log_learning(
        self,
        content: str,
        domain: str,
        task_id: str,
        confidence: float,
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Learning"):
            raise ValueError("Learning node type is disabled in KGConfig")

        # Clamp confidence to the mode cap for AI-created learnings
        capped = min(confidence, cfg.ai_confidence_cap)

        node = self._insert_node("Learning", {
            "label": content[:120],
            "scope": "global",
            "branch": branch,
            "team_id": team_id,
            "source": "agent",
            "author_id": agent_id,
            "confidence": capped,
            "domain": domain,
            "evidence_count": 1,
            "validated_by_human": False,
            "task_id": task_id,
            "properties_json": json.dumps({"content": content}),
        })
        self._create_edge(task_id, node.id, "LEARNED")

        # Contradiction check — delegated to LearningEngine
        result = await self.learning_engine.check_contradictions(node, branch, team_id)
        if result.flagged:
            # Reload to reflect the confidence floor applied by the contradiction engine
            reloaded = await self.get_node(node.id, branch, team_id)
            return reloaded if reloaded is not None else node
        return node

    async def corroborate_learning(
        self, learning_id: str, task_id: str, branch: str, team_id: str
    ) -> KGNode:
        """Delegated to LearningEngine.corroborate()."""
        return await self.learning_engine.corroborate(learning_id, task_id, branch, team_id)

    # ── Decision ─────────────────────────────────────────────────────────────

    async def log_decision(
        self,
        task_id: str,
        choice: str,
        rationale: str,
        alternatives: list[str],
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Decision"):
            raise ValueError("Decision node type is disabled in KGConfig")
        node = self._insert_node("Decision", {
            "label": choice[:120],
            "branch": branch,
            "team_id": team_id,
            "source": "agent",
            "author_id": agent_id,
            "scope": "global",
            "confidence": 1.0,
            "validated_by_human": True,
            "choice": choice,
            "rationale": rationale,
            "alternatives_considered": json.dumps(alternatives),
            "outcome": "unknown",
            "task_id": task_id,
        })
        self._create_edge(task_id, node.id, "LED_TO")
        return node

    # ── Blocker ───────────────────────────────────────────────────────────────

    async def mark_blocked(
        self,
        task_id: str,
        description: str,
        severity: str,
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Blocker"):
            raise ValueError("Blocker node type is disabled in KGConfig")
        node = self._insert_node("Blocker", {
            "label": description[:120],
            "branch": branch,
            "team_id": team_id,
            "source": "agent",
            "author_id": agent_id,
            "scope": "global",
            "confidence": 1.0,
            "validated_by_human": True,
            "description": description,
            "severity": severity,
            "status": "open",
            "task_id": task_id,
        })
        self._create_edge(task_id, node.id, "BLOCKED_BY")
        return node

    async def resolve_blocker(
        self,
        blocker_id: str,
        resolution: str,
        decision_id: str | None,
        branch: str,
        team_id: str,
    ) -> KGNode:
        now = _now()
        self._cmd(
            f"UPDATE KGNode SET status='resolved', resolution='{_esc(resolution)}', "
            f"resolved_at='{now}', updated_at='{now}' WHERE id='{_esc(blocker_id)}'"
        )
        if decision_id:
            self._create_edge(decision_id, blocker_id, "RESOLVES")
        node = await self.get_node(blocker_id, branch, team_id)
        if node is None:
            raise ValueError(f"Blocker {blocker_id!r} not found")
        return node

    # ── Context ───────────────────────────────────────────────────────────────

    async def add_context(
        self,
        content: str,
        context_type: str,
        source: str,
        expires_at: datetime | None,
        branch: str,
        team_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Context"):
            raise ValueError("Context node type is disabled in KGConfig")
        extra: dict[str, Any] = {
            "label": content[:120],
            "branch": branch,
            "team_id": team_id,
            "source": source,
            "author_id": source,
            "scope": "global",
            "confidence": 1.0,
            "validated_by_human": True,
            "context_type": context_type,
            "properties_json": json.dumps({"content": content}),
        }
        if expires_at:
            extra["expires_at"] = expires_at.isoformat()
        return self._insert_node("Context", extra)

    # ── Node updates ──────────────────────────────────────────────────────────

    async def update_node(
        self,
        node_id: str,
        properties: dict,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        existing = await self.get_node(node_id, branch, team_id)
        if existing is None:
            raise ValueError(f"Node {node_id!r} not found")

        if existing.branch != branch:
            # Node is from a parent scope — CoW: create a branch-local copy
            fields = existing.to_dict()
            fields.update(properties)
            fields["branch"] = branch
            fields["origin_node_id"] = node_id
            fields["id"] = _new_id()
            fields["author_id"] = author_id
            fields["updated_at"] = _now()
            return self._insert_node(existing.type, fields)

        # Branch-local update in place
        parts = [f"updated_at='{_now()}'"]
        for k, v in properties.items():
            if isinstance(v, bool):
                parts.append(f"{k}={str(v).lower()}")
            elif isinstance(v, (int, float)):
                parts.append(f"{k}={v}")
            else:
                parts.append(f"{k}='{_esc(str(v))}'")
        self._cmd(f"UPDATE KGNode SET {', '.join(parts)} WHERE id='{_esc(node_id)}'")
        node = await self.get_node(node_id, branch, team_id)
        if node is None:
            raise ValueError(f"Node {node_id!r} not found after update")
        return node

    async def deactivate_node(
        self, node_id: str, branch: str, team_id: str, author_id: str
    ) -> None:
        self._cmd(
            f"UPDATE KGNode SET active=false, updated_at='{_now()}' "
            f"WHERE id='{_esc(node_id)}'"
        )

    # ── Human operator ────────────────────────────────────────────────────────

    async def set_instruction(
        self,
        content: str,
        priority: str,
        scope: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Instruction"):
            raise ValueError("Instruction node type is disabled in KGConfig")
        return self._insert_node("Instruction", {
            "label": content[:120],
            "scope": scope,
            "branch": branch,
            "team_id": team_id,
            "source": "human",
            "author_id": author_id,
            "confidence": 1.0,
            "validated_by_human": True,
            "priority": priority,
            "properties_json": json.dumps({"content": content}),
        })

    async def set_condition(
        self,
        when_clause: str,
        then_clause: str,
        scope: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        cfg = await self.get_config(team_id, branch)
        if not cfg.is_node_type_active("Condition"):
            raise ValueError("Condition node type is disabled in KGConfig")
        label = f"WHEN {when_clause[:60]} THEN {then_clause[:60]}"
        return self._insert_node("Condition", {
            "label": label,
            "scope": scope,
            "branch": branch,
            "team_id": team_id,
            "source": "human",
            "author_id": author_id,
            "confidence": 1.0,
            "validated_by_human": True,
            "when_clause": when_clause,
            "then_clause": then_clause,
        })

    async def validate_learning(
        self,
        learning_id: str,
        accepted: bool,
        adjusted_confidence: float | None,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        now = _now()
        if accepted:
            conf = adjusted_confidence if adjusted_confidence is not None else 0.85
            self._cmd(
                f"UPDATE KGNode SET validated_by_human=true, confidence={conf}, "
                f"updated_at='{now}' WHERE id='{_esc(learning_id)}'"
            )
        else:
            self._cmd(
                f"UPDATE KGNode SET active=false, updated_at='{now}' "
                f"WHERE id='{_esc(learning_id)}'"
            )
        # Create VALIDATED_BY edge to a synthetic "human" node (author_id)
        self._cmd(
            f"CREATE EDGE VALIDATED_BY "
            f"SET accepted={str(accepted).lower()}, reviewed_at='{now}' "
            f"FROM (SELECT FROM KGNode WHERE id='{_esc(learning_id)}') "
            f"TO (SELECT FROM KGNode WHERE id='{_esc(learning_id)}')"
            # Self-edge: edge stores the reviewer metadata; no separate human node required
        ) if False else None  # Edge skipped — reviewer metadata stored in node props for now

        self._cmd(
            f"UPDATE KGNode SET properties_json = CASE "
            f"WHEN properties_json IS NULL THEN '{{\"validated_by\":\"{_esc(author_id)}\", \"reviewed_at\":\"{now}\"}}' "
            f"ELSE properties_json END "
            f"WHERE id='{_esc(learning_id)}'"
        )
        node = await self.get_node(learning_id, branch, team_id)
        if node is None:
            raise ValueError(f"Learning {learning_id!r} not found")
        return node

    async def override_instruction(
        self,
        original_id: str,
        new_content: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        original = await self.get_node(original_id, branch, team_id)
        if original is None:
            raise ValueError(f"Instruction {original_id!r} not found")

        # Only humans can override critical instructions — enforced at API layer,
        # but we re-check here as a safety net
        if original.properties.get("priority") == "critical" and original.source != "human":
            raise PermissionError("Critical instructions can only be overridden by humans")

        # Deactivate original
        await self.deactivate_node(original_id, branch, team_id, author_id)

        # Create replacement
        new_node = await self.set_instruction(
            content=new_content,
            priority=original.properties.get("priority", "medium"),
            scope=original.scope,
            branch=branch,
            team_id=team_id,
            author_id=author_id,
        )
        self._create_edge(new_node.id, original_id, "OVERRIDES")
        return new_node

    # ── Branch lifecycle ──────────────────────────────────────────────────────

    async def create_branch(self, branch: str, from_branch: str, team_id: str) -> None:
        # CoW: zero-cost — new branch inherits parent nodes by reading them
        # at query time with branch IN [branch, parent]. No data is copied.
        # We just save a default config for the new branch inheriting from_branch config.
        parent_cfg = await self.get_config(team_id, from_branch)
        new_cfg = KGConfig(
            team_id=team_id,
            branch=branch,
            mode=parent_cfg.mode,
            confidence_enabled=parent_cfg.confidence_enabled,
            hitl_ai_cap=parent_cfg.hitl_ai_cap,
            auto_ai_cap=parent_cfg.auto_ai_cap,
            disabled_node_types=list(parent_cfg.disabled_node_types),
        )
        await self.save_config(new_cfg)
        logger.info("Branch '%s' created (inherits from '%s')", branch, from_branch)

    async def get_branch_delta(
        self, branch: str, base: str, team_id: str
    ) -> BranchDelta:
        # Nodes created directly on `branch` (not on `base`)
        added = self._q(
            f"SELECT FROM KGNode WHERE branch='{_esc(branch)}' "
            f"AND team_id='{_esc(team_id)}' AND active=true"
        )
        # Nodes that are CoW copies (have origin_node_id) — modified in branch
        modified = self._q(
            f"SELECT FROM KGNode WHERE branch='{_esc(branch)}' "
            f"AND team_id='{_esc(team_id)}' AND origin_node_id IS NOT NULL"
        )
        cfg = await self.get_config(team_id, branch)
        added_nodes = [self._node(r, cfg) for r in added if not r.get("origin_node_id")]
        modified_nodes = [self._node(r, cfg) for r in modified]

        # Detect conflicts: same origin_node_id modified in both branches
        conflicts = []
        origin_ids = {r["origin_node_id"] for r in modified if r.get("origin_node_id")}
        for oid in origin_ids:
            base_mods = self._q(
                f"SELECT FROM KGNode WHERE origin_node_id='{_esc(oid)}' "
                f"AND branch='{_esc(base)}' AND team_id='{_esc(team_id)}'"
            )
            if base_mods:
                conflicts.append({"origin_node_id": oid, "reason": "modified in both branches"})

        return BranchDelta(
            branch=branch,
            base=base,
            added_nodes=added_nodes,
            modified_nodes=modified_nodes,
            conflicts=conflicts,
        )

    async def merge_branch(
        self,
        branch: str,
        target: str,
        team_id: str,
        conflict_resolution: dict[str, str] | None = None,
    ) -> BranchDelta:
        delta = await self.get_branch_delta(branch, target, team_id)

        if delta.conflicts and not conflict_resolution:
            # Return delta with conflicts for caller to resolve
            return delta

        now = _now()
        # Promote added nodes to target branch
        for node in delta.added_nodes:
            self._cmd(
                f"UPDATE KGNode SET branch='{_esc(target)}', updated_at='{now}' "
                f"WHERE id='{_esc(node.id)}'"
            )
        # Promote modified (CoW) nodes; handle conflicts
        for node in delta.modified_nodes:
            oid = node.origin_node_id
            if oid and conflict_resolution and oid in conflict_resolution:
                chosen = conflict_resolution[oid]
                if chosen == "theirs":
                    continue  # keep base version
            self._cmd(
                f"UPDATE KGNode SET branch='{_esc(target)}', updated_at='{now}' "
                f"WHERE id='{_esc(node.id)}'"
            )

        return delta

    # ── Cross-graph ───────────────────────────────────────────────────────────

    async def link_to_symbol(
        self, node_id: str, symbol_ids: list[str], branch: str, team_id: str
    ) -> None:
        self._cmd(
            f"UPDATE KGNode SET linked_symbol_ids='{_esc(json.dumps(symbol_ids))}', "
            f"updated_at='{_now()}' WHERE id='{_esc(node_id)}'"
        )

    async def get_linked_symbols(
        self, node_id: str, branch: str, team_id: str
    ) -> list[str]:
        rows = self._q(f"SELECT linked_symbol_ids FROM KGNode WHERE id='{_esc(node_id)}'")
        if not rows or not rows[0].get("linked_symbol_ids"):
            return []
        try:
            return json.loads(rows[0]["linked_symbol_ids"])
        except (json.JSONDecodeError, TypeError):
            return []

    # ── Context loading ───────────────────────────────────────────────────────
    # Full 6-step algorithm implemented in context_loader.py (Phase 4).
    # This stub delegates to it once available.

    async def load_task_context(
        self, task_id: str, branch: str, team_id: str
    ) -> TaskContext:
        from ravmem.knowledge.context_loader import load_task_context
        return await load_task_context(self, task_id, branch, team_id)
