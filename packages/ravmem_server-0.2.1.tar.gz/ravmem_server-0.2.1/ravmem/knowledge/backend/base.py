"""Knowledge graph abstract backend interface.

KnowledgeBackend defines the full contract any storage implementation must
satisfy. ArcadeBackend is the only concrete implementation.

All methods are async. Branch and team_id are always explicit parameters —
there is no implicit session state at this layer.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ravmem.knowledge.config import KGConfig


# ── Core dataclasses ──────────────────────────────────────────────────────────

@dataclass
class KGNode:
    """A vertex in the knowledge graph.

    `properties` holds type-specific fields (e.g. priority for Instruction,
    when_clause for Condition). Base fields are promoted to top-level attrs
    for fast access without dict lookups.
    """
    id: str
    type: str                       # Task | Instruction | Condition | Learning |
                                    # Decision | Blocker | Context | TaskPattern
    label: str
    scope: str                      # global | project:{repo_id} | task_type:{pattern}
    branch: str
    team_id: str
    source: str                     # "human" | "agent"
    author_id: str
    active: bool
    confidence: float               # 0.0–1.0; 1.0 for human-authored
    validated_by_human: bool
    created_at: datetime
    updated_at: datetime
    properties: dict[str, Any] = field(default_factory=dict)
    origin_node_id: str | None = None   # CoW parent reference

    def to_dict(self, omit_confidence: bool = False) -> dict:
        """Serialise to a plain dict, respecting the confidence toggle."""
        d: dict[str, Any] = {
            "id": self.id,
            "type": self.type,
            "label": self.label,
            "scope": self.scope,
            "branch": self.branch,
            "team_id": self.team_id,
            "source": self.source,
            "author_id": self.author_id,
            "active": self.active,
            "validated_by_human": self.validated_by_human,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "origin_node_id": self.origin_node_id,
            **self.properties,
        }
        if not omit_confidence:
            d["confidence"] = self.confidence
        return d

    @classmethod
    def from_arcade_row(cls, row: dict, omit_confidence: bool = False) -> "KGNode":
        """Construct a KGNode from a raw ArcadeDB query row."""
        base_fields = {
            "id", "type", "label", "scope", "branch", "team_id",
            "source", "author_id", "active", "confidence",
            "validated_by_human", "origin_node_id", "created_at",
            "updated_at", "embedding", "properties_json",
            "@rid", "@type", "@cat",
        }
        props: dict[str, Any] = {}
        for k, v in row.items():
            if k not in base_fields and not k.startswith("@"):
                if v is not None:
                    props[k] = v

        # Merge properties_json blob if present
        if row.get("properties_json"):
            try:
                props.update(json.loads(row["properties_json"]))
            except (json.JSONDecodeError, TypeError):
                pass

        def _dt(v: Any) -> datetime:
            if isinstance(v, datetime):
                return v
            if isinstance(v, (int, float)):
                return datetime.fromtimestamp(v / 1000)
            return datetime.fromisoformat(str(v))

        return cls(
            id=row["id"],
            type=row["type"],
            label=row.get("label", ""),
            scope=row.get("scope", "global"),
            branch=row.get("branch", "global"),
            team_id=row.get("team_id", ""),
            source=row.get("source", "agent"),
            author_id=row.get("author_id", ""),
            active=bool(row.get("active", True)),
            confidence=float(row.get("confidence", 0.0)) if not omit_confidence else 0.0,
            validated_by_human=bool(row.get("validated_by_human", False)),
            created_at=_dt(row.get("created_at", datetime.utcnow())),
            updated_at=_dt(row.get("updated_at", datetime.utcnow())),
            origin_node_id=row.get("origin_node_id"),
            properties=props,
        )


@dataclass
class KGEdge:
    """A directed edge between two KGNodes."""
    id: str
    from_id: str
    to_id: str
    relation: str                   # HAS_INSTRUCTION | LEARNED | LED_TO | ...
    branch: str
    properties: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "from_id": self.from_id,
            "to_id": self.to_id,
            "relation": self.relation,
            "branch": self.branch,
            **self.properties,
        }


@dataclass
class TaskContext:
    """Structured context packet returned by load_task_context().

    This is exactly what the agent receives at task start — no more, no less.
    All fields are already filtered by the 6-step context loading algorithm.
    """
    task: KGNode
    instructions: list[KGNode] = field(default_factory=list)
    conditions: list[KGNode] = field(default_factory=list)
    learnings: list[KGNode] = field(default_factory=list)
    decisions: list[KGNode] = field(default_factory=list)
    blockers: list[KGNode] = field(default_factory=list)
    context: list[KGNode] = field(default_factory=list)
    linked_symbols: list[str] = field(default_factory=list)
    similar_task_ids: list[str] = field(default_factory=list)
    config: KGConfig | None = None  # attached so serialiser knows confidence toggle state

    def to_dict(self) -> dict:
        omit = self.config is not None and not self.config.confidence_enabled
        return {
            "task": self.task.to_dict(omit_confidence=omit),
            "instructions": [n.to_dict(omit_confidence=omit) for n in self.instructions],
            "conditions": [n.to_dict(omit_confidence=omit) for n in self.conditions],
            "learnings": [n.to_dict(omit_confidence=omit) for n in self.learnings],
            "decisions": [n.to_dict(omit_confidence=omit) for n in self.decisions],
            "blockers": [n.to_dict(omit_confidence=omit) for n in self.blockers],
            "context": [n.to_dict(omit_confidence=omit) for n in self.context],
            "linked_symbols": self.linked_symbols,
            "similar_task_ids": self.similar_task_ids,
        }


@dataclass
class BranchDelta:
    """What changed in one knowledge branch relative to its base."""
    branch: str
    base: str
    added_nodes: list[KGNode] = field(default_factory=list)
    modified_nodes: list[KGNode] = field(default_factory=list)
    added_edges: list[KGEdge] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "branch": self.branch,
            "base": self.base,
            "added_nodes": [n.to_dict() for n in self.added_nodes],
            "modified_nodes": [n.to_dict() for n in self.modified_nodes],
            "added_edges": [e.to_dict() for e in self.added_edges],
            "conflicts": self.conflicts,
        }


# ── Abstract backend ──────────────────────────────────────────────────────────

class KnowledgeBackend(ABC):
    """Contract every KG storage backend must satisfy.

    Implementations must be safe to construct once and reuse across async
    requests. All methods are coroutines.
    """

    # ── Config ────────────────────────────────────────────────────────────────

    @abstractmethod
    async def get_config(self, team_id: str, branch: str) -> KGConfig:
        """Load the KGConfig for this team+branch. Returns default if not initialised."""

    @abstractmethod
    async def save_config(self, cfg: KGConfig) -> None:
        """Persist a KGConfig. Called by ravmem kg init and PATCH /api/knowledge/config."""

    # ── Schema ────────────────────────────────────────────────────────────────

    @abstractmethod
    async def ensure_schema(self) -> None:
        """Apply DDL schema to the database. Idempotent — safe to call at startup."""

    # ── Context loading ───────────────────────────────────────────────────────

    @abstractmethod
    async def load_task_context(
        self, task_id: str, branch: str, team_id: str
    ) -> TaskContext:
        """Run the 6-step context resolution algorithm and return a TaskContext."""

    @abstractmethod
    async def search_knowledge(
        self,
        query: str,
        branch: str,
        team_id: str,
        node_types: list[str] | None = None,
        limit: int = 10,
    ) -> list[KGNode]:
        """Semantic search over active knowledge nodes scoped to branch+team."""

    @abstractmethod
    async def get_node(
        self, node_id: str, branch: str, team_id: str
    ) -> KGNode | None:
        """Fetch a single node by ID. Returns None if not found or not in scope."""

    @abstractmethod
    async def list_nodes(
        self,
        node_type: str,
        branch: str,
        team_id: str,
        scope: str | None = None,
        active_only: bool = True,
    ) -> list[KGNode]:
        """List nodes of a given type, optionally filtered by scope."""

    # ── Write — agent ─────────────────────────────────────────────────────────

    @abstractmethod
    async def create_task(
        self,
        label: str,
        task_type: str,
        repo_id: str,
        git_branch: str,
        agent_id: str,
        branch: str,
        team_id: str,
    ) -> KGNode:
        """Register a new task. Auto-links matching TaskPattern instructions/conditions."""

    @abstractmethod
    async def log_learning(
        self,
        content: str,
        domain: str,
        task_id: str,
        confidence: float,
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        """Record a Learning. Triggers contradiction check. Links to task via LEARNED."""

    @abstractmethod
    async def log_decision(
        self,
        task_id: str,
        choice: str,
        rationale: str,
        alternatives: list[str],
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        """Record a Decision. Links to task via LED_TO."""

    @abstractmethod
    async def mark_blocked(
        self,
        task_id: str,
        description: str,
        severity: str,
        branch: str,
        team_id: str,
        agent_id: str,
    ) -> KGNode:
        """Create a Blocker. Links to task via BLOCKED_BY."""

    @abstractmethod
    async def resolve_blocker(
        self,
        blocker_id: str,
        resolution: str,
        decision_id: str | None,
        branch: str,
        team_id: str,
    ) -> KGNode:
        """Mark Blocker resolved. Optionally links resolving Decision via RESOLVES."""

    @abstractmethod
    async def add_context(
        self,
        content: str,
        context_type: str,
        source: str,
        expires_at: datetime | None,
        branch: str,
        team_id: str,
    ) -> KGNode:
        """Store an ephemeral or persistent Context node."""

    @abstractmethod
    async def complete_task(
        self,
        task_id: str,
        outcome: str,
        branch: str,
        team_id: str,
    ) -> KGNode:
        """Close a task with its outcome. Triggers learning promotion evaluation."""

    @abstractmethod
    async def update_node(
        self,
        node_id: str,
        properties: dict,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Update properties. Creates branch-local CoW copy if node is from parent scope."""

    @abstractmethod
    async def deactivate_node(
        self,
        node_id: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> None:
        """Soft-delete: set active=False. Preserves history and audit trail."""

    # ── Write — human operator ────────────────────────────────────────────────

    @abstractmethod
    async def set_instruction(
        self,
        content: str,
        priority: str,
        scope: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Create a human-authored Instruction. source='human', confidence=1.0."""

    @abstractmethod
    async def set_condition(
        self,
        when_clause: str,
        then_clause: str,
        scope: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Create a Condition (if/then rule). source='human', confidence=1.0."""

    @abstractmethod
    async def validate_learning(
        self,
        learning_id: str,
        accepted: bool,
        adjusted_confidence: float | None,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Human validates or rejects an AI learning.

        accepted=True  → validated_by_human=True, confidence set to adjusted_confidence.
        accepted=False → active=False (learning deactivated).
        """

    @abstractmethod
    async def override_instruction(
        self,
        original_id: str,
        new_content: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Replace an Instruction via OVERRIDES edge. Deactivates the original.
        Only humans can override instructions with priority=critical."""

    # ── Branch lifecycle ──────────────────────────────────────────────────────

    @abstractmethod
    async def create_branch(
        self, branch: str, from_branch: str, team_id: str
    ) -> None:
        """Fork a new branch. Inherits all nodes by reference (CoW, zero cost)."""

    @abstractmethod
    async def merge_branch(
        self,
        branch: str,
        target: str,
        team_id: str,
        conflict_resolution: dict[str, str] | None = None,
    ) -> BranchDelta:
        """Promote branch-local nodes into target. Returns conflicts if any."""

    @abstractmethod
    async def get_branch_delta(
        self, branch: str, base: str, team_id: str
    ) -> BranchDelta:
        """What changed in `branch` relative to `base`."""

    # ── Cross-graph (codegraph symbol linking) ────────────────────────────────

    @abstractmethod
    async def link_to_symbol(
        self,
        node_id: str,
        symbol_ids: list[str],
        branch: str,
        team_id: str,
    ) -> None:
        """Link a KG node to Symbol IDs from the codegraph database.
        Stored as a JSON property; resolved at query time (cross-DB reference)."""

    @abstractmethod
    async def get_linked_symbols(
        self, node_id: str, branch: str, team_id: str
    ) -> list[str]:
        """Return Symbol IDs linked to this node."""
