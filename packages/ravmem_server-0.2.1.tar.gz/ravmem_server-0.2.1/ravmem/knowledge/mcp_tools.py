"""Knowledge graph MCP tool definitions and handlers.

Mounted under the main FastAPI app at POST /api/knowledge/mcp.
Follows the same MCPRequest / MCPResponse envelope used by routes_mcp.py.

Session resolution:
  branch  — from X-KG-Branch header, defaults to "global"
  team_id — from X-KG-Team header, defaults to "default"

The agent never passes branch/team_id explicitly in tool parameters.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel

from ravmem.knowledge.backend.factory import create_backend

logger = logging.getLogger(__name__)

router = APIRouter(tags=["knowledge-mcp"])


# ── MCP envelope (shared with routes_mcp.py) ─────────────────────────────────

class MCPToolCall(BaseModel):
    name: str
    parameters: dict[str, Any] = {}


class MCPRequest(BaseModel):
    tool_calls: list[MCPToolCall]


class MCPContentItem(BaseModel):
    type: str = "text"
    text: str


class MCPToolResult(BaseModel):
    name: str
    content: list[MCPContentItem]
    isError: bool = False


class MCPResponse(BaseModel):
    results: list[MCPToolResult]


# ── Tool catalogue ────────────────────────────────────────────────────────────

KG_MCP_TOOLS = [
    # ── Agent read ────────────────────────────────────────────────────────────
    {
        "name": "load_task_context",
        "description": (
            "Primary agent entry point. Runs the 6-step context resolution algorithm "
            "and returns instructions, conditions, learnings, decisions, blockers, "
            "context nodes, and similar past task IDs for the given task."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "ID of the task to load context for"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "search_knowledge",
        "description": "Semantic search over active knowledge nodes in the agent's scope.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "node_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional filter: Task | Instruction | Condition | Learning | Decision | Blocker | Context | TaskPattern",
                },
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_instructions",
        "description": "List all active Instructions for the current scope, ordered by priority (critical first).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {"type": "string", "description": "Optional scope filter (global | project:{id} | task_type:{type})"},
            },
        },
    },
    {
        "name": "get_conditions",
        "description": "List all active Conditions that apply to the current scope.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scope": {"type": "string"},
            },
        },
    },
    {
        "name": "get_config",
        "description": "Return the current KGConfig (mode, confidence toggle, active node types) for this session.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    # ── Agent write ───────────────────────────────────────────────────────────
    {
        "name": "start_task",
        "description": "Register a new task. Auto-loads matching TaskPattern instructions and conditions. Returns task_id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Human-readable task description"},
                "task_type": {"type": "string", "description": "Task category (e.g. deploy, debug, refactor)"},
                "repo_id": {"type": "string", "description": "Repository identifier"},
                "git_branch": {"type": "string", "description": "Git branch being worked on"},
                "agent_id": {"type": "string", "description": "Agent identifier"},
            },
            "required": ["label", "task_type", "repo_id", "git_branch", "agent_id"],
        },
    },
    {
        "name": "log_learning",
        "description": "Record a new learning discovered during a task. Triggers contradiction check.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "content": {"type": "string", "description": "What was learned, in plain language"},
                "domain": {"type": "string", "description": "Knowledge domain (e.g. deployment, api, infra)"},
                "confidence": {"type": "number", "description": "Initial confidence 0.0–1.0 (capped by mode)"},
            },
            "required": ["task_id", "content", "domain"],
        },
    },
    {
        "name": "log_decision",
        "description": "Record a decision made during a task with choice, rationale, and alternatives.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "choice": {"type": "string"},
                "rationale": {"type": "string"},
                "alternatives": {"type": "array", "items": {"type": "string"}},
                "agent_id": {"type": "string"},
            },
            "required": ["task_id", "choice", "rationale", "agent_id"],
        },
    },
    {
        "name": "mark_blocked",
        "description": "Create a Blocker linked to the current task.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "description": {"type": "string"},
                "severity": {"type": "string", "enum": ["critical", "high", "medium", "low"]},
                "agent_id": {"type": "string"},
            },
            "required": ["task_id", "description", "severity", "agent_id"],
        },
    },
    {
        "name": "resolve_blocker",
        "description": "Mark a Blocker resolved. Optionally link the resolving Decision.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "blocker_id": {"type": "string"},
                "resolution": {"type": "string"},
                "decision_id": {"type": "string", "description": "Optional — ID of the Decision that resolved this"},
            },
            "required": ["blocker_id", "resolution"],
        },
    },
    {
        "name": "add_context",
        "description": "Store ephemeral or persistent context the agent wants the system to remember.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string"},
                "context_type": {"type": "string", "enum": ["env", "config", "system", "domain", "constraint"]},
                "expires_in_hours": {"type": "number", "description": "Optional TTL in hours. Omit for persistent context."},
            },
            "required": ["content", "context_type"],
        },
    },
    {
        "name": "complete_task",
        "description": "Close the task with its outcome. Triggers promotion evaluation for accumulated learnings.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string"},
                "outcome": {"type": "string", "enum": ["success", "partial", "failure"]},
            },
            "required": ["task_id", "outcome"],
        },
    },
    {
        "name": "link_to_code",
        "description": "Link a knowledge graph node to Symbol IDs from the codegraph database.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "symbol_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["node_id", "symbol_ids"],
        },
    },
    # ── Human operator ────────────────────────────────────────────────────────
    {
        "name": "set_instruction",
        "description": "Create a human-authored Instruction. Immediately active at full confidence.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string"},
                "priority": {"type": "string", "enum": ["critical", "high", "medium", "low"]},
                "scope": {"type": "string", "description": "global | project:{repo_id} | task_type:{pattern}"},
                "author_id": {"type": "string"},
            },
            "required": ["content", "priority", "scope", "author_id"],
        },
    },
    {
        "name": "set_condition",
        "description": "Create an if/then Condition rule.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "when_clause": {"type": "string"},
                "then_clause": {"type": "string"},
                "scope": {"type": "string"},
                "author_id": {"type": "string"},
            },
            "required": ["when_clause", "then_clause", "scope", "author_id"],
        },
    },
    {
        "name": "validate_learning",
        "description": "Accept or reject an AI-discovered learning. Adjusts confidence or deactivates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "learning_id": {"type": "string"},
                "accepted": {"type": "boolean"},
                "confidence": {"type": "number", "description": "Final confidence 0.7–1.0 (only when accepted=true)"},
                "author_id": {"type": "string"},
            },
            "required": ["learning_id", "accepted", "author_id"],
        },
    },
    {
        "name": "override_instruction",
        "description": "Replace an existing Instruction with new content. Creates OVERRIDES edge. Deactivates original.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "instruction_id": {"type": "string"},
                "new_content": {"type": "string"},
                "author_id": {"type": "string"},
            },
            "required": ["instruction_id", "new_content", "author_id"],
        },
    },
    # ── Config ────────────────────────────────────────────────────────────────
    {
        "name": "set_mode",
        "description": "Switch between hitl and auto mode. Only affects new confidence writes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mode": {"type": "string", "enum": ["hitl", "auto"]},
            },
            "required": ["mode"],
        },
    },
    {
        "name": "toggle_confidence",
        "description": "Enable or disable confidence scoring. When disabled, confidence field is omitted from responses.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "enabled": {"type": "boolean"},
            },
            "required": ["enabled"],
        },
    },
]


# ── Handler dispatch ──────────────────────────────────────────────────────────

def _ok(name: str, data: Any) -> MCPToolResult:
    return MCPToolResult(
        name=name,
        content=[MCPContentItem(text=json.dumps(data, default=str))],
    )


def _err(name: str, msg: str) -> MCPToolResult:
    return MCPToolResult(
        name=name,
        content=[MCPContentItem(text=msg)],
        isError=True,
    )


_MCP_TOOL_PERMISSIONS: dict[str, str] = {
    # Agent read
    "load_task_context": "kg:read",
    "search_knowledge":  "kg:read",
    "get_instructions":  "kg:read",
    "get_conditions":    "kg:read",
    "get_config":        "kg:read",
    # Agent write
    "start_task":        "kg:write",
    "log_learning":      "kg:write",
    "log_decision":      "kg:write",
    "mark_blocked":      "kg:write",
    "resolve_blocker":   "kg:write",
    "add_context":       "kg:write",
    "complete_task":     "kg:write",
    "link_to_code":      "kg:write",
    # Human / configure
    "set_instruction":   "kg:configure",
    "set_condition":     "kg:configure",
    "set_mode":          "kg:configure",
    # Human / validate
    "validate_learning": "kg:validate",
    "promote":           "kg:validate",
    # Admin
    "override_instruction": "kg:admin",
    "toggle_confidence":    "kg:admin",
}


async def _dispatch(
    call: MCPToolCall,
    backend,
    branch: str,
    team_id: str,
) -> MCPToolResult:
    p = call.parameters
    n = call.name

    # Permission check at dispatcher
    required_perm = _MCP_TOOL_PERMISSIONS.get(n)
    if required_perm:
        from ravmem.auth.rbac import check_permission_mcp
        err = check_permission_mcp(required_perm)
        if err:
            return MCPToolResult(
                name=n,
                content=[MCPContentItem(text=err["content"][0]["text"])],
                isError=True,
            )

    try:
        # ── Agent read ────────────────────────────────────────────────────────
        if n == "load_task_context":
            ctx = await backend.load_task_context(p["task_id"], branch, team_id)
            return _ok(n, ctx.to_dict())

        if n == "search_knowledge":
            nodes = await backend.search_knowledge(
                p["query"], branch, team_id,
                node_types=p.get("node_types"),
                limit=p.get("limit", 10),
            )
            cfg = await backend.get_config(team_id, branch)
            omit = not cfg.confidence_enabled
            return _ok(n, [nd.to_dict(omit_confidence=omit) for nd in nodes])

        if n == "get_instructions":
            nodes = await backend.list_nodes(
                "Instruction", branch, team_id,
                scope=p.get("scope"), active_only=True,
            )
            from ravmem.knowledge.context_loader import _sort_instructions
            return _ok(n, [nd.to_dict() for nd in _sort_instructions(nodes)])

        if n == "get_conditions":
            nodes = await backend.list_nodes(
                "Condition", branch, team_id,
                scope=p.get("scope"), active_only=True,
            )
            return _ok(n, [nd.to_dict() for nd in nodes])

        if n == "get_config":
            cfg = await backend.get_config(team_id, branch)
            return _ok(n, cfg.to_dict())

        # ── Agent write ───────────────────────────────────────────────────────
        if n == "start_task":
            node = await backend.create_task(
                label=p["label"],
                task_type=p["task_type"],
                repo_id=p["repo_id"],
                git_branch=p["git_branch"],
                agent_id=p["agent_id"],
                branch=branch,
                team_id=team_id,
            )
            return _ok(n, {"task_id": node.id, "label": node.label, "status": node.properties.get("status")})

        if n == "log_learning":
            node = await backend.log_learning(
                content=p["content"],
                domain=p["domain"],
                task_id=p["task_id"],
                confidence=float(p.get("confidence", 0.55)),
                branch=branch,
                team_id=team_id,
                agent_id=p.get("agent_id", "agent"),
            )
            cfg = await backend.get_config(team_id, branch)
            return _ok(n, node.to_dict(omit_confidence=not cfg.confidence_enabled))

        if n == "log_decision":
            node = await backend.log_decision(
                task_id=p["task_id"],
                choice=p["choice"],
                rationale=p["rationale"],
                alternatives=p.get("alternatives", []),
                branch=branch,
                team_id=team_id,
                agent_id=p["agent_id"],
            )
            return _ok(n, node.to_dict())

        if n == "mark_blocked":
            node = await backend.mark_blocked(
                task_id=p["task_id"],
                description=p["description"],
                severity=p["severity"],
                branch=branch,
                team_id=team_id,
                agent_id=p["agent_id"],
            )
            return _ok(n, {"blocker_id": node.id, "status": node.properties.get("status")})

        if n == "resolve_blocker":
            node = await backend.resolve_blocker(
                blocker_id=p["blocker_id"],
                resolution=p["resolution"],
                decision_id=p.get("decision_id"),
                branch=branch,
                team_id=team_id,
            )
            return _ok(n, {"blocker_id": node.id, "status": node.properties.get("status")})

        if n == "add_context":
            expires_at = None
            if p.get("expires_in_hours"):
                from datetime import timedelta
                expires_at = datetime.utcnow() + timedelta(hours=float(p["expires_in_hours"]))
            node = await backend.add_context(
                content=p["content"],
                context_type=p["context_type"],
                source="agent",
                expires_at=expires_at,
                branch=branch,
                team_id=team_id,
            )
            return _ok(n, {"context_id": node.id})

        if n == "complete_task":
            node = await backend.complete_task(
                task_id=p["task_id"],
                outcome=p["outcome"],
                branch=branch,
                team_id=team_id,
            )
            return _ok(n, {"task_id": node.id, "outcome": node.properties.get("outcome")})

        if n == "link_to_code":
            await backend.link_to_symbol(
                node_id=p["node_id"],
                symbol_ids=p["symbol_ids"],
                branch=branch,
                team_id=team_id,
            )
            return _ok(n, {"node_id": p["node_id"], "linked": len(p["symbol_ids"])})

        # ── Human operator ────────────────────────────────────────────────────
        if n == "set_instruction":
            node = await backend.set_instruction(
                content=p["content"],
                priority=p["priority"],
                scope=p["scope"],
                branch=branch,
                team_id=team_id,
                author_id=p["author_id"],
            )
            return _ok(n, node.to_dict())

        if n == "set_condition":
            node = await backend.set_condition(
                when_clause=p["when_clause"],
                then_clause=p["then_clause"],
                scope=p["scope"],
                branch=branch,
                team_id=team_id,
                author_id=p["author_id"],
            )
            return _ok(n, node.to_dict())

        if n == "validate_learning":
            node = await backend.validate_learning(
                learning_id=p["learning_id"],
                accepted=bool(p["accepted"]),
                adjusted_confidence=p.get("confidence"),
                branch=branch,
                team_id=team_id,
                author_id=p["author_id"],
            )
            return _ok(n, node.to_dict())

        if n == "override_instruction":
            node = await backend.override_instruction(
                original_id=p["instruction_id"],
                new_content=p["new_content"],
                branch=branch,
                team_id=team_id,
                author_id=p["author_id"],
            )
            return _ok(n, node.to_dict())

        # ── Config ────────────────────────────────────────────────────────────
        if n == "set_mode":
            cfg = await backend.get_config(team_id, branch)
            cfg.mode = p["mode"]
            await backend.save_config(cfg)
            return _ok(n, {"mode": cfg.mode})

        if n == "toggle_confidence":
            cfg = await backend.get_config(team_id, branch)
            cfg.confidence_enabled = bool(p["enabled"])
            await backend.save_config(cfg)
            return _ok(n, {"confidence_enabled": cfg.confidence_enabled})

        return _err(n, f"Unknown tool: {n!r}")

    except (ValueError, PermissionError) as exc:
        logger.warning("KG MCP tool %s error: %s", n, exc)
        return _err(n, str(exc))
    except Exception as exc:
        logger.exception("KG MCP tool %s unexpected error", n)
        return _err(n, f"Internal error: {exc}")


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/api/knowledge/mcp")
async def kg_mcp_list_tools():
    """Return the knowledge graph tool catalogue."""
    return {"tools": KG_MCP_TOOLS}


@router.post("/api/knowledge/mcp")
async def kg_mcp_call(
    request: MCPRequest,
    x_kg_branch: str = Header(default="global", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="default", alias="X-KG-Team"),
):
    """Execute one or more knowledge graph MCP tool calls."""
    backend = create_backend()

    results = []
    for call in request.tool_calls:
        result = await _dispatch(call, backend, x_kg_branch, x_kg_team)
        results.append(result)

    return MCPResponse(results=results)
