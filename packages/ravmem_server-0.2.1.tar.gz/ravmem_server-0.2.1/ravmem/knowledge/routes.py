"""REST API routes for the knowledge graph layer.

Mounted at /api/knowledge in the FastAPI app.

Session resolution (same as MCP):
  branch  — query param or X-KG-Branch header (default: "global")
  team_id — query param or X-KG-Team header   (default: "default")
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel, Field

from ravmem.auth import permissions as P
from ravmem.auth.rbac import require_permission
from ravmem.knowledge.backend.factory import create_backend
from ravmem.knowledge.config import KGConfig

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])


# ── Session helpers ────────────────────────────────────────────────────────────

def _session(
    branch: str = Query(default="global", description="Knowledge branch"),
    team_id: str = Query(default="default", description="Team identifier"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
) -> tuple[str, str]:
    """Resolve branch and team_id from query params or headers (params win)."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    return resolved_branch, resolved_team


# ── Request/response models ───────────────────────────────────────────────────

class ConfigBody(BaseModel):
    team_id: str
    branch: str
    mode: str = "hitl"
    confidence_enabled: bool = True
    hitl_ai_cap: float = 0.70
    auto_ai_cap: float = 1.0
    disabled_node_types: list[str] = Field(default_factory=list)


class CreateTaskBody(BaseModel):
    label: str
    task_type: str
    repo_id: str
    git_branch: str
    agent_id: str


class CompleteTaskBody(BaseModel):
    outcome: str  # success | partial | failure


class LogLearningBody(BaseModel):
    content: str
    task_id: str = ""
    domain: str = ""
    confidence: float = 0.55
    agent_id: str = "agent"


class ValidateLearningBody(BaseModel):
    accepted: bool
    confidence: float | None = None
    author_id: str


class CorroborateBody(BaseModel):
    task_id: str


class PromoteBody(BaseModel):
    priority: str  # critical | high | medium | low
    author_id: str


class LogDecisionBody(BaseModel):
    task_id: str
    choice: str
    rationale: str
    alternatives: list[str] = Field(default_factory=list)
    agent_id: str


class CreateInstructionBody(BaseModel):
    content: str
    priority: str  # critical | high | medium | low
    scope: str
    author_id: str


class OverrideInstructionBody(BaseModel):
    new_content: str
    author_id: str


class CreateConditionBody(BaseModel):
    when_clause: str
    then_clause: str
    scope: str
    author_id: str


class MarkBlockedBody(BaseModel):
    task_id: str
    description: str
    severity: str  # critical | high | medium | low
    agent_id: str


class ResolveBlockerBody(BaseModel):
    resolution: str
    decision_id: str | None = None


class AddContextBody(BaseModel):
    content: str
    context_type: str  # env | config | system | domain | constraint
    expires_in_hours: float | None = None


class LinkSymbolsBody(BaseModel):
    symbol_ids: list[str]


class UpdateNodeBody(BaseModel):
    properties: dict[str, Any]
    author_id: str = "api"


# ── Config endpoints ───────────────────────────────────────────────────────────

@router.get("/config")
async def get_config(
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Return the KGConfig for a team/branch. 404 if never configured."""
    require_permission(P.KG_READ)
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    return cfg.to_dict()


@router.post("/config", status_code=201)
async def save_config(body: ConfigBody):
    """Create or update KGConfig for a team/branch."""
    require_permission(P.KG_CONFIGURE)
    cfg = KGConfig(
        team_id=body.team_id,
        branch=body.branch,
        mode=body.mode,
        confidence_enabled=body.confidence_enabled,
        hitl_ai_cap=body.hitl_ai_cap,
        auto_ai_cap=body.auto_ai_cap,
        disabled_node_types=body.disabled_node_types,
    )
    db = create_backend()
    await db.save_config(cfg)
    return cfg.to_dict()


# ── Task endpoints ────────────────────────────────────────────────────────────

@router.post("/tasks", status_code=201)
async def create_task(
    body: CreateTaskBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Register a new task."""
    require_permission(P.KG_WRITE)
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    node = await db.create_task(
        label=body.label,
        task_type=body.task_type,
        repo_id=body.repo_id,
        git_branch=body.git_branch,
        agent_id=body.agent_id,
        branch=resolved_branch,
        team_id=resolved_team,
    )
    omit = not cfg.confidence_enabled
    return node.to_dict(omit_confidence=omit)


@router.get("/tasks/{task_id}/context")
async def get_task_context(
    task_id: str,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Run the 6-step context resolution algorithm for a task."""
    require_permission(P.KG_READ)
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        ctx = await db.load_task_context(task_id, resolved_branch, resolved_team)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return ctx.to_dict()


@router.post("/tasks/{task_id}/complete")
async def complete_task(
    task_id: str,
    body: CompleteTaskBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Close a task with its outcome. Returns promotion candidates."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.complete_task(
            task_id=task_id,
            outcome=body.outcome,
            branch=resolved_branch,
            team_id=resolved_team,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


# ── Learning endpoints ────────────────────────────────────────────────────────

@router.post("/learnings", status_code=201)
async def log_learning(
    body: LogLearningBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Record a new learning. Triggers contradiction check."""
    require_permission(P.KG_WRITE)
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    node = await db.log_learning(
        content=body.content,
        domain=body.domain,
        task_id=body.task_id,
        confidence=body.confidence,
        branch=resolved_branch,
        team_id=resolved_team,
        agent_id=body.agent_id,
    )
    return node.to_dict(omit_confidence=not cfg.confidence_enabled)


@router.post("/learnings/{learning_id}/validate")
async def validate_learning(
    learning_id: str,
    body: ValidateLearningBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Accept or reject a learning. Adjusts confidence or deactivates."""
    require_permission(P.KG_VALIDATE)
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.validate_learning(
            learning_id=learning_id,
            accepted=body.accepted,
            adjusted_confidence=body.confidence,
            branch=resolved_branch,
            team_id=resolved_team,
            author_id=body.author_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


@router.post("/learnings/{learning_id}/corroborate")
async def corroborate_learning(
    learning_id: str,
    body: CorroborateBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Increment evidence_count and nudge confidence up (mode-capped)."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.learning_engine.corroborate(
            learning_id=learning_id,
            task_id=body.task_id,
            branch=resolved_branch,
            team_id=resolved_team,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


@router.post("/learnings/{learning_id}/promote")
async def promote_learning(
    learning_id: str,
    body: PromoteBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Promote a validated Learning into an Instruction."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.learning_engine.promote_to_instruction(
            learning_id=learning_id,
            priority=body.priority,
            branch=resolved_branch,
            team_id=resolved_team,
            author_id=body.author_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return node.to_dict()


# ── Decision endpoints ────────────────────────────────────────────────────────

@router.post("/decisions", status_code=201)
async def log_decision(
    body: LogDecisionBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Record a decision made during a task."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    node = await db.log_decision(
        task_id=body.task_id,
        choice=body.choice,
        rationale=body.rationale,
        alternatives=body.alternatives,
        branch=resolved_branch,
        team_id=resolved_team,
        agent_id=body.agent_id,
    )
    return node.to_dict()


# ── Instruction endpoints ─────────────────────────────────────────────────────

@router.post("/instructions", status_code=201)
async def create_instruction(
    body: CreateInstructionBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Create a human-authored Instruction."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    node = await db.set_instruction(
        content=body.content,
        priority=body.priority,
        scope=body.scope,
        branch=resolved_branch,
        team_id=resolved_team,
        author_id=body.author_id,
    )
    return node.to_dict()


@router.post("/instructions/{instruction_id}/override")
async def override_instruction(
    instruction_id: str,
    body: OverrideInstructionBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Replace an Instruction. Deactivates original, links via OVERRIDES edge."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.override_instruction(
            original_id=instruction_id,
            new_content=body.new_content,
            branch=resolved_branch,
            team_id=resolved_team,
            author_id=body.author_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


# ── Condition endpoints ───────────────────────────────────────────────────────

@router.post("/conditions", status_code=201)
async def create_condition(
    body: CreateConditionBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Create an if/then Condition rule."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    node = await db.set_condition(
        when_clause=body.when_clause,
        then_clause=body.then_clause,
        scope=body.scope,
        branch=resolved_branch,
        team_id=resolved_team,
        author_id=body.author_id,
    )
    return node.to_dict()


# ── Blocker endpoints ─────────────────────────────────────────────────────────

@router.post("/blockers", status_code=201)
async def mark_blocked(
    body: MarkBlockedBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Create a Blocker linked to a task."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    node = await db.mark_blocked(
        task_id=body.task_id,
        description=body.description,
        severity=body.severity,
        branch=resolved_branch,
        team_id=resolved_team,
        agent_id=body.agent_id,
    )
    return node.to_dict()


@router.post("/blockers/{blocker_id}/resolve")
async def resolve_blocker(
    blocker_id: str,
    body: ResolveBlockerBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Mark a Blocker resolved."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.resolve_blocker(
            blocker_id=blocker_id,
            resolution=body.resolution,
            decision_id=body.decision_id,
            branch=resolved_branch,
            team_id=resolved_team,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


# ── Context node endpoints ────────────────────────────────────────────────────

@router.post("/context", status_code=201)
async def add_context(
    body: AddContextBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Store ephemeral or persistent context."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    from datetime import datetime, timedelta
    expires_at = None
    if body.expires_in_hours is not None:
        expires_at = datetime.utcnow() + timedelta(hours=body.expires_in_hours)
    db = create_backend()
    node = await db.add_context(
        content=body.content,
        context_type=body.context_type,
        source="api",
        expires_at=expires_at,
        branch=resolved_branch,
        team_id=resolved_team,
    )
    return node.to_dict()


# ── Node management endpoints ─────────────────────────────────────────────────

@router.get("/nodes/{node_id}")
async def get_node(
    node_id: str,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Fetch a single knowledge node by ID."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    node = await db.get_node(node_id, resolved_branch, resolved_team)
    if node is None:
        raise HTTPException(status_code=404, detail=f"Node not found: {node_id}")
    return node.to_dict(omit_confidence=not cfg.confidence_enabled)


@router.patch("/nodes/{node_id}")
async def update_node(
    node_id: str,
    body: UpdateNodeBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Update node properties. CoW: creates a branch-local copy if node is inherited."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    try:
        node = await db.update_node(
            node_id=node_id,
            properties=body.properties,
            branch=resolved_branch,
            team_id=resolved_team,
            author_id=body.author_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return node.to_dict()


@router.delete("/nodes/{node_id}", status_code=204)
async def deactivate_node(
    node_id: str,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Soft-delete (deactivate) a node."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    node = await db.get_node(node_id, resolved_branch, resolved_team)
    if node is None:
        raise HTTPException(status_code=404, detail=f"Node not found: {node_id}")
    await db.update_node(
        node_id=node_id,
        properties={"active": False},
        branch=resolved_branch,
        team_id=resolved_team,
        author_id="api",
    )


@router.get("/nodes")
async def list_nodes(
    node_type: str = Query(..., description="Node type to list (e.g. Learning, Instruction)"),
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    scope: str | None = Query(default=None),
    active_only: bool = Query(default=True),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """List nodes of a given type."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    nodes = await db.list_nodes(node_type, resolved_branch, resolved_team, scope=scope, active_only=active_only)
    omit = not cfg.confidence_enabled
    return [n.to_dict(omit_confidence=omit) for n in nodes]


@router.get("/edges")
async def list_edges(
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    edge_types: list[str] = Query(default=[]),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """List all edges in the knowledge graph.

    Returns edges with src/dst/type for visualisation.
    """
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    edges = await db.get_edges(
        branch=resolved_branch,
        team_id=resolved_team,
        edge_types=edge_types if edge_types else None,
    )
    return {"edges": edges}


# ── Symbol linking ────────────────────────────────────────────────────────────

@router.post("/nodes/{node_id}/link-symbols")
async def link_symbols(
    node_id: str,
    body: LinkSymbolsBody,
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Link a knowledge node to codegraph symbol IDs."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    await db.link_to_symbol(
        node_id=node_id,
        symbol_ids=body.symbol_ids,
        branch=resolved_branch,
        team_id=resolved_team,
    )
    return {"node_id": node_id, "linked": len(body.symbol_ids)}


# ── Search ────────────────────────────────────────────────────────────────────

@router.get("/search")
async def search_knowledge(
    q: str = Query(..., description="Search query"),
    node_types: list[str] = Query(default=[]),
    limit: int = Query(default=10),
    branch: str = Query(default="global"),
    team_id: str = Query(default="default"),
    x_kg_branch: str = Header(default="", alias="X-KG-Branch"),
    x_kg_team: str = Header(default="", alias="X-KG-Team"),
):
    """Keyword search over active knowledge nodes."""
    resolved_branch = branch if branch != "global" else (x_kg_branch or "global")
    resolved_team = team_id if team_id != "default" else (x_kg_team or "default")
    db = create_backend()
    cfg = await db.get_config(resolved_team, resolved_branch)
    nodes = await db.search_knowledge(
        q, resolved_branch, resolved_team,
        node_types=node_types or None,
        limit=limit,
    )
    omit = not cfg.confidence_enabled
    return [n.to_dict(omit_confidence=omit) for n in nodes]
