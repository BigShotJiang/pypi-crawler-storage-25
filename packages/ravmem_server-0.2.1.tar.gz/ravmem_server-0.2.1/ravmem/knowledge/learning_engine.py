"""Learning engine — confidence lifecycle, corroboration, contradiction detection.

Separated from ArcadeBackend so the logic is testable in isolation and does not
grow inside the storage layer. The backend delegates all learning lifecycle work
to this module.

Lifecycle:
  Agent discovers something
    → log_learning() → confidence = min(stated, ai_cap), validated=false
  Agent sees corroborating evidence
    → corroborate() → evidence_count++, confidence nudged up, still capped
  Human validates
    → ArcadeBackend.validate_learning() → confidence = human value, validated=true
  Human rejects
    → ArcadeBackend.validate_learning(accepted=False) → active=false
  Contradictory evidence found
    → CONTRADICTS edge created, both nodes flagged at 0.4 for human review
  Task completes
    → evaluate_promotions() surfaces learnings ready for human review
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ravmem.knowledge.backend.base import KGNode

if TYPE_CHECKING:
    from ravmem.knowledge.backend.arcade_backend import ArcadeBackend

logger = logging.getLogger(__name__)

# Minimum evidence corroborations before a learning is flagged promotion-ready
_PROMOTION_EVIDENCE_THRESHOLD = 3
# Minimum confidence (when enabled) for promotion-ready flag
_PROMOTION_CONFIDENCE_THRESHOLD = 0.7
# Confidence bump per corroboration
_CORROBORATION_BUMP = 0.05
# Confidence floor below which a learning is flagged contradicted
_CONTRADICTION_FLOOR = 0.4
# Minimum shared content words to consider a contradiction candidate
_CONTRADICTION_MIN_SHARED_WORDS = 3

_NEGATIONS = frozenset({
    "not", "never", "no", "don't", "dont",
    "shouldn't", "shouldnt", "cannot", "can't", "wont", "won't",
})


# ── Result types ──────────────────────────────────────────────────────────────

@dataclass
class ContradictionResult:
    new_node_id: str
    contradicting_ids: list[str] = field(default_factory=list)
    flagged: bool = False           # True if any contradiction was recorded


@dataclass
class PromotionCandidate:
    """A Learning that has accumulated enough evidence to warrant human review."""
    node: KGNode
    evidence_count: int
    reason: str                     # Human-readable explanation


# ── Contradiction detection ───────────────────────────────────────────────────

def _content_of(node: KGNode) -> str:
    return node.properties.get("content") or node.label or ""


def _has_negation(words: frozenset[str]) -> bool:
    return bool(words & _NEGATIONS)


def _contradiction_score(a: str, b: str) -> tuple[float, int]:
    """Return (score, shared_word_count) between two learning content strings.

    Score > 0 and shared >= threshold signals a potential contradiction when
    one content has a negation word and the other does not.
    """
    wa = frozenset(a.lower().split())
    wb = frozenset(b.lower().split())
    shared = wa & wb
    n_shared = len(shared)
    if n_shared < _CONTRADICTION_MIN_SHARED_WORDS:
        return 0.0, n_shared
    a_neg = _has_negation(wa)
    b_neg = _has_negation(wb)
    if a_neg == b_neg:
        # Same polarity — not a contradiction
        return 0.0, n_shared
    union = len(wa | wb)
    jaccard = n_shared / union if union else 0.0
    return jaccard, n_shared


def _esc(v: str) -> str:
    if not v:
        return ""
    return str(v).replace("\\", "\\\\").replace("'", "\\'")


# ── LearningEngine ────────────────────────────────────────────────────────────

class LearningEngine:
    """Manages the confidence lifecycle for Learning nodes.

    Instantiated once and reused. Holds no mutable state — all persistence
    is delegated to the ArcadeBackend it receives.
    """

    def __init__(self, db: "ArcadeBackend") -> None:
        self._db = db

    # ── Corroboration ─────────────────────────────────────────────────────────

    async def corroborate(
        self,
        learning_id: str,
        task_id: str,
        branch: str,
        team_id: str,
    ) -> KGNode:
        """Increment evidence_count and nudge confidence up (mode-capped).

        New confidence = min(current + BUMP, ai_cap) when not yet human-validated.
        Human-validated nodes are not nudged — their confidence is locked by the
        human reviewer.
        """
        cfg = await self._db.get_config(team_id, branch)
        cap = cfg.ai_confidence_cap

        from ravmem.knowledge.backend.arcade_backend import _now
        self._db._cmd(
            f"UPDATE KGNode SET "
            f"evidence_count = coalesce(evidence_count, 0) + 1, "
            f"confidence = CASE WHEN validated_by_human = false "
            f"THEN min(coalesce(confidence, 0.5) + {_CORROBORATION_BUMP}, {cap}) "
            f"ELSE confidence END, "
            f"updated_at='{_now()}' "
            f"WHERE id='{_esc(learning_id)}'"
        )
        # Link this task as additional evidence
        try:
            self._db._create_edge(task_id, learning_id, "LEARNED")
        except Exception:
            pass  # duplicate edge if task already linked — not critical

        node = await self._db.get_node(learning_id, branch, team_id)
        if node is None:
            raise ValueError(f"Learning {learning_id!r} not found after corroboration")

        logger.debug(
            "Corroborated learning %s: evidence=%s confidence=%.2f",
            learning_id,
            node.properties.get("evidence_count", "?"),
            node.confidence,
        )
        return node

    # ── Contradiction detection ───────────────────────────────────────────────

    async def check_contradictions(
        self,
        new_node: KGNode,
        branch: str,
        team_id: str,
    ) -> ContradictionResult:
        """Search active learnings for semantic contradictions with new_node.

        Uses a text-based heuristic (shared word count + negation polarity).
        JVector semantic search replaces this in Phase 5 once embeddings land.

        When a contradiction is found:
          - CONTRADICTS edge is created in both directions
          - Both nodes are flagged to confidence=0.4, validated_by_human=false
          - Human review is required before either learning is trusted again
        """
        from ravmem.knowledge.backend.arcade_backend import _now

        content = _content_of(new_node)
        if not content:
            return ContradictionResult(new_node_id=new_node.id)

        # Fetch all active learnings in branch scope and apply heuristic in Python.
        # search_knowledge uses LIKE which requires exact substring match — unsuitable
        # for contradiction detection where the texts differ by negation words.
        # JVector semantic search replaces this fetch in Phase 5.
        candidates = await self._db.list_nodes(
            "Learning", branch, team_id, active_only=True
        )

        result = ContradictionResult(new_node_id=new_node.id)
        now = _now()

        for candidate in candidates:
            if candidate.id == new_node.id:
                continue
            if not candidate.active:
                continue

            score, shared = _contradiction_score(content, _content_of(candidate))
            if score <= 0:
                continue

            logger.warning(
                "Contradiction detected (score=%.2f shared=%d): %s ↔ %s",
                score, shared, new_node.id, candidate.id,
            )

            # Bidirectional CONTRADICTS edges
            try:
                self._db._create_edge(new_node.id, candidate.id, "CONTRADICTS")
            except Exception:
                pass  # edge may already exist
            try:
                self._db._create_edge(candidate.id, new_node.id, "CONTRADICTS")
            except Exception:
                pass

            # Flag both to floor confidence and require re-review
            self._db._cmd(
                f"UPDATE KGNode SET "
                f"confidence={_CONTRADICTION_FLOOR}, "
                f"validated_by_human=false, "
                f"updated_at='{now}' "
                f"WHERE id IN ['{_esc(new_node.id)}', '{_esc(candidate.id)}']"
            )
            result.contradicting_ids.append(candidate.id)
            result.flagged = True

        return result

    # ── Promotion evaluation ──────────────────────────────────────────────────

    async def evaluate_promotions(
        self,
        task_id: str,
        branch: str,
        team_id: str,
    ) -> list[PromotionCandidate]:
        """Find learnings linked to this task that are ready for human review.

        A learning is promotion-ready when:
          - evidence_count >= PROMOTION_EVIDENCE_THRESHOLD (default 3)
          - validated_by_human = false (not yet reviewed)
          - active = true
          - No existing CONTRADICTS edges (clean record)
          - confidence > 0.4 (not flagged by contradiction)

        Returns candidates sorted by evidence_count descending.
        Intended to be called at task completion.
        """
        cfg = await self._db.get_config(team_id, branch)

        # Fetch learnings linked to this task via LEARNED edges
        rows = self._db._q(
            f"SELECT expand(out('LEARNED')) FROM KGNode WHERE id='{_esc(task_id)}'"
        )
        candidates: list[PromotionCandidate] = []

        for row in rows:
            node = self._db._node(row, cfg)
            if not node.active:
                continue
            if node.validated_by_human:
                continue

            evidence = int(node.properties.get("evidence_count") or 1)
            if evidence < _PROMOTION_EVIDENCE_THRESHOLD:
                continue
            if node.confidence <= _CONTRADICTION_FLOOR:
                continue  # flagged by contradiction — needs human resolution first

            # Check for open CONTRADICTS edges
            contradictions = self._db._q(
                f"SELECT count(*) as cnt FROM (SELECT expand(out('CONTRADICTS')) "
                f"FROM KGNode WHERE id='{_esc(node.id)}')"
            )
            if contradictions and contradictions[0].get("cnt", 0) > 0:
                continue  # still has unresolved contradictions

            reason = (
                f"evidence_count={evidence} "
                f"confidence={node.confidence:.2f} "
                f"domain={node.properties.get('domain', 'unknown')}"
            )
            candidates.append(PromotionCandidate(node=node, evidence_count=evidence, reason=reason))
            logger.info(
                "Promotion candidate: learning %s (%s)", node.id, reason
            )

        candidates.sort(key=lambda c: c.evidence_count, reverse=True)
        return candidates

    # ── Learning-to-Instruction promotion ────────────────────────────────────

    async def promote_to_instruction(
        self,
        learning_id: str,
        priority: str,
        branch: str,
        team_id: str,
        author_id: str,
    ) -> KGNode:
        """Promote a validated Learning into an Instruction.

        Creates a new Instruction node with source='agent' (promoted) and
        links the original Learning via DERIVED_FROM. The Learning itself
        remains active — it is not deactivated on promotion.

        Only call this on a human-validated learning (validated_by_human=true).
        """
        learning = await self._db.get_node(learning_id, branch, team_id)
        if learning is None:
            raise ValueError(f"Learning {learning_id!r} not found")
        if not learning.validated_by_human:
            raise ValueError(
                f"Learning {learning_id!r} has not been validated by a human — "
                "cannot promote to Instruction"
            )

        content = _content_of(learning)
        instruction = await self._db.set_instruction(
            content=content,
            priority=priority,
            scope=learning.scope,
            branch=branch,
            team_id=team_id,
            author_id=author_id,
        )
        # Override source — this was AI-promoted, not purely human-authored
        from ravmem.knowledge.backend.arcade_backend import _now, _esc as _e
        self._db._cmd(
            f"UPDATE KGNode SET source='agent', confidence={learning.confidence}, "
            f"updated_at='{_now()}' WHERE id='{_e(instruction.id)}'"
        )
        self._db._create_edge(instruction.id, learning_id, "DERIVED_FROM")

        # Reload to reflect the source override
        reloaded = await self._db.get_node(instruction.id, branch, team_id)
        if reloaded is None:
            raise ValueError(f"Instruction {instruction.id!r} not found after promotion")

        logger.info(
            "Learning %s promoted to Instruction %s (priority=%s)",
            learning_id, reloaded.id, priority,
        )
        return reloaded
