"""ravmem kg init — interactive wizard for knowledge graph initialisation.

Run once per team before first use. Stored result persists in ArcadeDB.
Re-running prints current config and offers reconfiguration.
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich import box

from ravmem.knowledge.config import KGConfig, BUILTIN_NODE_TYPES

console = Console()


def _prompt_mode() -> str:
    console.print("\n[bold]Operational mode:[/bold]")
    console.print("  [cyan][1][/cyan] HITL  — human validation required to reach full confidence [dim](recommended)[/dim]")
    console.print("  [cyan][2][/cyan] Auto  — AI agents can reach full confidence through continuous learning")
    choice = typer.prompt("Select", default="1")
    return "hitl" if choice.strip() != "2" else "auto"


def _prompt_hitl_cap() -> float:
    raw = typer.prompt("HITL AI confidence cap", default="0.70")
    try:
        val = float(raw)
        if not 0.0 < val <= 1.0:
            raise ValueError
        return val
    except ValueError:
        console.print("[yellow]Invalid value — using default 0.70[/yellow]")
        return 0.70


def _prompt_auto_cap() -> float:
    raw = typer.prompt("Auto AI confidence cap", default="1.0")
    try:
        val = float(raw)
        if not 0.0 < val <= 1.0:
            raise ValueError
        return val
    except ValueError:
        console.print("[yellow]Invalid value — using default 1.0[/yellow]")
        return 1.0


def _prompt_confidence_enabled() -> bool:
    return typer.confirm("Enable confidence scoring?", default=True)


def _prompt_node_types() -> list[str]:
    console.print("\n[bold]Active node types[/bold] (press ENTER to keep all, or enter numbers to disable):")
    for i, nt in enumerate(BUILTIN_NODE_TYPES, 1):
        console.print(f"  [cyan][{i}][/cyan] {nt}")
    raw = typer.prompt("Disable numbers (comma-separated) or ENTER to keep all", default="")
    if not raw.strip():
        return []
    disabled: list[str] = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            idx = int(part) - 1
            if 0 <= idx < len(BUILTIN_NODE_TYPES):
                disabled.append(BUILTIN_NODE_TYPES[idx])
    return disabled


def _show_current(cfg: KGConfig) -> None:
    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Setting", style="bold")
    table.add_column("Value")
    table.add_row("Mode", cfg.mode.upper())
    table.add_row("Confidence scoring", "enabled" if cfg.confidence_enabled else "disabled")
    table.add_row("HITL AI cap", str(cfg.hitl_ai_cap))
    table.add_row("Auto AI cap", str(cfg.auto_ai_cap))
    active = cfg.active_node_types
    disabled = cfg.disabled_node_types
    table.add_row("Active node types", ", ".join(active) if active else "none")
    if disabled:
        table.add_row("Disabled node types", ", ".join(disabled))
    console.print(table)


def run_init(
    team_id: str,
    branch: str,
    existing_cfg: KGConfig | None = None,
    save_fn=None,          # callable(KGConfig) → None — injected by CLI/server
) -> KGConfig:
    """Interactive init wizard.

    Args:
        team_id:      Team identifier for this KGConfig.
        branch:       Knowledge branch (default: "global").
        existing_cfg: If provided, shows current state and offers reconfiguration.
        save_fn:      Called with the final KGConfig to persist it. If None,
                      the config is returned but not saved (useful in tests).
    """
    console.rule("[bold cyan]Knowledge graph initialisation[/bold cyan]")

    if existing_cfg is not None:
        console.print("\n[bold]Current configuration:[/bold]")
        _show_current(existing_cfg)
        if not typer.confirm("\nReconfigure?", default=False):
            console.print("[green]No changes made.[/green]")
            return existing_cfg

    mode = _prompt_mode()
    hitl_cap = _prompt_hitl_cap() if mode == "hitl" else 0.70
    auto_cap = _prompt_auto_cap() if mode == "auto" else 1.0
    confidence_enabled = _prompt_confidence_enabled()
    disabled_node_types = _prompt_node_types()

    console.print("\n[dim]Custom node types: not available in this release. Reserved for v2.[/dim]")

    cfg = KGConfig(
        team_id=team_id,
        branch=branch,
        mode=mode,
        confidence_enabled=confidence_enabled,
        hitl_ai_cap=hitl_cap,
        auto_ai_cap=auto_cap,
        disabled_node_types=disabled_node_types,
    )

    console.print("\n[bold]Configuration summary:[/bold]")
    _show_current(cfg)

    if save_fn is not None:
        save_fn(cfg)
        console.print(
            f"\n[green]Knowledge graph initialised.[/green]\n"
            f"Config saved to ArcadeDB (branch: {branch}, team: {team_id})"
        )
    else:
        console.print("\n[yellow]Note: no save function provided — config not persisted.[/yellow]")

    return cfg
