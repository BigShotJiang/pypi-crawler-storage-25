"""Apply the knowledge graph DDL to ArcadeDB.

Called by ArcadeBackend.ensure_schema() at startup.
Can also be run standalone:
    python -m ravmem.knowledge.schema.apply_schema
"""

from __future__ import annotations

import os
from pathlib import Path

import requests

SCHEMA_FILE = Path(__file__).parent / "arcade_init.sql"

ARCADEDB_HOST = os.environ.get("ARCADEDB_HOST", "localhost")
ARCADEDB_PORT = int(os.environ.get("ARCADEDB_PORT", "2480"))
ARCADEDB_PASSWORD = os.environ.get("ARCADEDB_PASSWORD", "arcadedb")
ARCADEDB_KG_DATABASE = os.environ.get("ARCADEDB_KG_DATABASE", "knowledge")

_BASE = f"http://{ARCADEDB_HOST}:{ARCADEDB_PORT}"
_AUTH = ("root", ARCADEDB_PASSWORD)


def _ensure_database() -> None:
    """Create the knowledge database if it doesn't exist."""
    r = requests.get(f"{_BASE}/api/v1/databases", auth=_AUTH, timeout=10)
    r.raise_for_status()
    existing = r.json().get("result", [])
    if ARCADEDB_KG_DATABASE not in existing:
        r2 = requests.post(
            f"{_BASE}/api/v1/server",
            auth=_AUTH,
            json={"command": f"create database {ARCADEDB_KG_DATABASE}"},
            timeout=10,
        )
        r2.raise_for_status()


def _run_statement(statement: str) -> None:
    statement = statement.strip()
    if not statement:
        return
    r = requests.post(
        f"{_BASE}/api/v1/command/{ARCADEDB_KG_DATABASE}",
        auth=_AUTH,
        json={"language": "sql", "command": statement},
        timeout=10,
    )
    if r.status_code not in (200, 204):
        raise RuntimeError(f"DDL failed ({r.status_code}): {statement!r}\n{r.text}")


def apply_schema(verbose: bool = False) -> None:
    """Create the database and apply all DDL statements."""
    _ensure_database()
    sql = SCHEMA_FILE.read_text()
    statements = [
        line for line in sql.splitlines()
        if line.strip() and not line.strip().startswith("--")
    ]
    for stmt in statements:
        if verbose:
            print(f"  {stmt}")
        _run_statement(stmt)
    if verbose:
        print(f"Schema applied to '{ARCADEDB_KG_DATABASE}' on {_BASE}")


if __name__ == "__main__":
    apply_schema(verbose=True)
