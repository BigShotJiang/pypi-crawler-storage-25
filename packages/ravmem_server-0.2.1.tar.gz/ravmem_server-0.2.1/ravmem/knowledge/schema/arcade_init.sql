-- Knowledge graph schema — ArcadeDB DDL
-- Applied once at server startup via ArcadeBackend.ensure_schema().
-- Safe to re-run: all statements use IF NOT EXISTS.

-- ── KGConfig ──────────────────────────────────────────────────────────────────
-- One vertex per (team_id, branch) pair. Holds all operational config.

CREATE VERTEX TYPE KGConfig IF NOT EXISTS;
CREATE PROPERTY KGConfig.config_key          IF NOT EXISTS STRING;
CREATE PROPERTY KGConfig.team_id             IF NOT EXISTS STRING;
CREATE PROPERTY KGConfig.branch              IF NOT EXISTS STRING;
CREATE PROPERTY KGConfig.mode                IF NOT EXISTS STRING;
CREATE PROPERTY KGConfig.confidence_enabled  IF NOT EXISTS BOOLEAN;
CREATE PROPERTY KGConfig.hitl_ai_cap         IF NOT EXISTS DOUBLE;
CREATE PROPERTY KGConfig.auto_ai_cap         IF NOT EXISTS DOUBLE;
CREATE PROPERTY KGConfig.disabled_node_types IF NOT EXISTS STRING;
CREATE PROPERTY KGConfig.custom_node_types   IF NOT EXISTS STRING;
CREATE INDEX IF NOT EXISTS ON KGConfig (config_key) UNIQUE;

-- ── KGNode ────────────────────────────────────────────────────────────────────
-- Single vertex type for all knowledge node kinds (Task, Instruction, etc.).
-- Type-specific properties are nullable for irrelevant types.

CREATE VERTEX TYPE KGNode IF NOT EXISTS;

-- Base fields (enforced on every node)
CREATE PROPERTY KGNode.id                IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.type              IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.label             IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.scope             IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.branch            IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.team_id           IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.source            IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.author_id         IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.active            IF NOT EXISTS BOOLEAN;
CREATE PROPERTY KGNode.confidence        IF NOT EXISTS DOUBLE;
CREATE PROPERTY KGNode.validated_by_human IF NOT EXISTS BOOLEAN;
CREATE PROPERTY KGNode.origin_node_id    IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.embedding         IF NOT EXISTS LIST OF FLOAT;
CREATE PROPERTY KGNode.created_at        IF NOT EXISTS DATETIME;
CREATE PROPERTY KGNode.updated_at        IF NOT EXISTS DATETIME;
CREATE PROPERTY KGNode.properties_json   IF NOT EXISTS STRING;

-- Instruction
CREATE PROPERTY KGNode.priority          IF NOT EXISTS STRING;

-- Condition
CREATE PROPERTY KGNode.when_clause       IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.then_clause       IF NOT EXISTS STRING;

-- Learning
CREATE PROPERTY KGNode.domain            IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.evidence_count    IF NOT EXISTS INTEGER;
CREATE PROPERTY KGNode.contradicted_by   IF NOT EXISTS STRING;

-- Task + TaskPattern
CREATE PROPERTY KGNode.task_type         IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.task_type_pattern IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.status            IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.outcome           IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.repo_id           IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.git_branch        IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.agent_id          IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.linked_symbol_ids IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.match_count       IF NOT EXISTS INTEGER;

-- Decision
CREATE PROPERTY KGNode.choice            IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.rationale         IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.alternatives_considered IF NOT EXISTS STRING;

-- Blocker
CREATE PROPERTY KGNode.description       IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.severity          IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.resolution        IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.discovered_at     IF NOT EXISTS DATETIME;
CREATE PROPERTY KGNode.resolved_at       IF NOT EXISTS DATETIME;

-- Context
CREATE PROPERTY KGNode.context_type      IF NOT EXISTS STRING;
CREATE PROPERTY KGNode.expires_at        IF NOT EXISTS DATETIME;

-- Auth scoping (Phase 3)
CREATE PROPERTY KGNode.created_by IF NOT EXISTS STRING;

-- Indexes
CREATE INDEX IF NOT EXISTS ON KGNode (id) UNIQUE;
CREATE INDEX IF NOT EXISTS ON KGNode (created_by) NOTUNIQUE;
CREATE INDEX IF NOT EXISTS ON KGNode (branch, team_id) NOTUNIQUE;
CREATE INDEX IF NOT EXISTS ON KGNode (type, active, scope) NOTUNIQUE;
CREATE INDEX IF NOT EXISTS ON KGNode (task_type) NOTUNIQUE;

-- ── Edge types ────────────────────────────────────────────────────────────────

CREATE EDGE TYPE HAS_INSTRUCTION  IF NOT EXISTS;
CREATE EDGE TYPE HAS_CONDITION    IF NOT EXISTS;
CREATE EDGE TYPE LEARNED          IF NOT EXISTS;
CREATE EDGE TYPE LED_TO           IF NOT EXISTS;
CREATE EDGE TYPE BLOCKED_BY       IF NOT EXISTS;
CREATE EDGE TYPE RESOLVES         IF NOT EXISTS;
CREATE EDGE TYPE REQUIRES_CONTEXT IF NOT EXISTS;
CREATE EDGE TYPE DEPENDS_ON       IF NOT EXISTS;
CREATE EDGE TYPE SIMILAR_TO       IF NOT EXISTS;
CREATE PROPERTY SIMILAR_TO.score  IF NOT EXISTS DOUBLE;
CREATE EDGE TYPE APPLIES_TO       IF NOT EXISTS;
CREATE EDGE TYPE DERIVED_FROM     IF NOT EXISTS;
CREATE EDGE TYPE CONTRADICTS      IF NOT EXISTS;
CREATE EDGE TYPE OVERRIDES        IF NOT EXISTS;
CREATE EDGE TYPE VALIDATED_BY     IF NOT EXISTS;
CREATE PROPERTY VALIDATED_BY.accepted    IF NOT EXISTS BOOLEAN;
CREATE PROPERTY VALIDATED_BY.reviewed_at IF NOT EXISTS DATETIME;
