"""6-step context loading algorithm for the knowledge graph.

Called by ArcadeBackend.load_task_context(). Returns a fully-populated
TaskContext — the structured context packet an agent receives at task start.

Steps:
  1. Scoped instructions (ordered by priority)
  2. Conditions that apply to this task
  3. TaskPattern match → pattern-linked instructions + conditions + learnings
  4. Validated learnings (confidence-enabled: >= 0.7; disabled: human-gate only)
  5. Similar past tasks → their decisions and learnings (text fallback; JVector in Phase 5)
  6. Active, non-expired context nodes

All steps use branch-aware reads: branch IN [branch, 'global'].
Disabled node types (from KGConfig) are silently skipped — context is
assembled from whatever is active under the current config.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ravmem.knowledge.backend.base import KGNode, TaskContext

if TYPE_CHECKING:
    from ravmem.knowledge.backend.arcade_backend import ArcadeBackend

logger = logging.getLogger(__name__)

_PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def _esc(v: str) -> str:
    if not v:
        return ""
    return str(v).replace("\\", "\\\\").replace("'", "\\'")


def _branch_filter(branch: str) -> str:
    return f"branch IN ['{_esc(branch)}', 'global']"


def _scope_filter(repo_id: str, task_type: str) -> str:
    scopes = (
        f"['global', 'project:{_esc(repo_id)}', 'task_type:{_esc(task_type)}']"
    )
    return f"scope IN {scopes}"


def _sort_instructions(nodes: list[KGNode]) -> list[KGNode]:
    """Sort instructions: critical first, then by priority level."""
    return sorted(
        nodes,
        key=lambda n: _PRIORITY_ORDER.get(
            n.properties.get("priority", "low"), 3
        ),
    )


def _dedupe(nodes: list[KGNode]) -> list[KGNode]:
    """Remove duplicates by node id, preserving order."""
    seen: set[str] = set()
    result: list[KGNode] = []
    for n in nodes:
        if n.id not in seen:
            seen.add(n.id)
            result.append(n)
    return result


# ── Step implementations ──────────────────────────────────────────────────────

def _step1_instructions(
    db: "ArcadeBackend",
    repo_id: str,
    task_type: str,
    branch: str,
    team_id: str,
) -> list[KGNode]:
    """Load active Instructions scoped to this task, ordered by priority."""
    sql = (
        f"SELECT FROM KGNode WHERE type='Instruction' AND active=true "
        f"AND {_scope_filter(repo_id, task_type)} "
        f"AND {_branch_filter(branch)} "
        f"AND team_id='{_esc(team_id)}'"
    )
    rows = db._q(sql)
    nodes = [db._node(r) for r in rows]
    return _sort_instructions(nodes)


def _step2_conditions(
    db: "ArcadeBackend",
    repo_id: str,
    task_type: str,
    branch: str,
    team_id: str,
) -> list[KGNode]:
    """Load active Conditions scoped to this task."""
    sql = (
        f"SELECT FROM KGNode WHERE type='Condition' AND active=true "
        f"AND {_scope_filter(repo_id, task_type)} "
        f"AND {_branch_filter(branch)} "
        f"AND team_id='{_esc(team_id)}'"
    )
    rows = db._q(sql)
    return [db._node(r) for r in rows]


def _step3_task_patterns(
    db: "ArcadeBackend",
    task_type: str,
    branch: str,
    team_id: str,
) -> tuple[list[KGNode], list[KGNode], list[KGNode]]:
    """Match TaskPatterns and load their linked instructions, conditions, learnings.

    Returns (instructions, conditions, learnings) from all matching patterns.
    Pattern matching: task_type_pattern contains task_type (substring match;
    JVector-based fuzzy matching added in Phase 5).
    """
    patterns = db._q(
        f"SELECT FROM KGNode WHERE type='TaskPattern' AND active=true "
        f"AND {_branch_filter(branch)} AND team_id='{_esc(team_id)}'"
    )

    pat_instructions: list[KGNode] = []
    pat_conditions: list[KGNode] = []
    pat_learnings: list[KGNode] = []

    for pat in patterns:
        pattern_str = pat.get("task_type_pattern", "")
        if not pattern_str:
            continue
        # Substring match: task_type_pattern acts as a keyword list
        if task_type not in pattern_str and pattern_str not in task_type:
            continue

        pat_id = pat["id"]

        instr_rows = db._q(
            f"SELECT expand(out('HAS_INSTRUCTION')) FROM KGNode WHERE id='{_esc(pat_id)}'"
        )
        pat_instructions.extend(db._node(r) for r in instr_rows if r.get("active", True))

        cond_rows = db._q(
            f"SELECT expand(out('HAS_CONDITION')) FROM KGNode WHERE id='{_esc(pat_id)}'"
        )
        pat_conditions.extend(db._node(r) for r in cond_rows if r.get("active", True))

        # APPLIES_TO edges link learnings to patterns
        lrn_rows = db._q(
            f"SELECT expand(in('APPLIES_TO')) FROM KGNode WHERE id='{_esc(pat_id)}' "
            f"AND @type = 'KGNode'"
        )
        pat_learnings.extend(
            db._node(r) for r in lrn_rows
            if r.get("active", True) and r.get("type") == "Learning"
        )

    return (
        _sort_instructions(pat_instructions),
        pat_conditions,
        pat_learnings,
    )


def _step4_learnings(
    db: "ArcadeBackend",
    repo_id: str,
    task_type: str,
    branch: str,
    team_id: str,
    confidence_enabled: bool,
) -> list[KGNode]:
    """Load validated learnings. Confidence filter depends on the toggle.

    confidence_enabled=True  → confidence >= 0.7, ordered by confidence DESC
    confidence_enabled=False → validated_by_human=true only; confidence
                               field omitted from returned nodes
    """
    base = (
        f"type='Learning' AND active=true "
        f"AND {_scope_filter(repo_id, task_type)} "
        f"AND {_branch_filter(branch)} "
        f"AND team_id='{_esc(team_id)}'"
    )

    if confidence_enabled:
        sql = f"SELECT FROM KGNode WHERE {base} AND confidence >= 0.7"
        rows = db._q(sql)
        nodes = [db._node(r) for r in rows]
        # Sort by confidence descending
        return sorted(nodes, key=lambda n: n.confidence, reverse=True)
    else:
        sql = f"SELECT FROM KGNode WHERE {base} AND validated_by_human=true"
        rows = db._q(sql)
        # confidence field omitted: from_arcade_row called with omit_confidence=True
        return [KGNode.from_arcade_row(r, omit_confidence=True) for r in rows]


def _step5_similar_tasks(
    db: "ArcadeBackend",
    task: KGNode,
    repo_id: str,
    branch: str,
    team_id: str,
    confidence_enabled: bool,
    top_k: int = 3,
) -> tuple[list[str], list[KGNode]]:
    """Find similar past completed tasks via text overlap.

    Returns (similar_task_ids, decisions_from_similar_tasks).
    JVector semantic search will replace the text overlap in Phase 5
    once embeddings are wired up.
    """
    task_label = task.label.lower()
    task_type = task.properties.get("task_type", "")

    # Fetch completed tasks for the same repo
    rows = db._q(
        f"SELECT FROM KGNode WHERE type='Task' AND active=true "
        f"AND repo_id='{_esc(repo_id)}' "
        f"AND status='completed' "
        f"AND {_branch_filter(branch)} "
        f"AND team_id='{_esc(team_id)}'"
    )

    # Score by word overlap between labels
    scored: list[tuple[float, KGNode]] = []
    task_words = set(task_label.split())
    for r in rows:
        candidate = db._node(r)
        if candidate.id == task.id:
            continue
        cand_words = set(candidate.label.lower().split())
        shared = task_words & cand_words
        # Bonus for matching task_type
        type_bonus = 0.3 if candidate.properties.get("task_type") == task_type else 0.0
        score = len(shared) / max(len(task_words | cand_words), 1) + type_bonus
        if score > 0:
            scored.append((score, candidate))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_k]

    similar_ids: list[str] = []
    all_decisions: list[KGNode] = []

    for _, sim_task in top:
        similar_ids.append(sim_task.id)

        # Store SIMILAR_TO edge (best-effort — ignore if it already exists)
        try:
            db._create_edge(task.id, sim_task.id, "SIMILAR_TO", {"score": scored[0][0]})
        except Exception:
            pass  # duplicate edges are not critical

        # Fetch decisions made during this similar task
        dec_rows = db._q(
            f"SELECT expand(out('LED_TO')) FROM KGNode WHERE id='{_esc(sim_task.id)}'"
        )
        for d in dec_rows:
            if d.get("outcome") and d.get("outcome") != "unknown":
                all_decisions.append(db._node(d, None))

    return similar_ids, _dedupe(all_decisions)


def _step6_context(
    db: "ArcadeBackend",
    branch: str,
    team_id: str,
) -> list[KGNode]:
    """Load active, non-expired Context nodes."""
    sql = (
        f"SELECT FROM KGNode WHERE type='Context' AND active=true "
        f"AND (expires_at IS NULL OR expires_at > sysdate()) "
        f"AND {_branch_filter(branch)} "
        f"AND team_id='{_esc(team_id)}'"
    )
    rows = db._q(sql)
    return [db._node(r) for r in rows]


# ── Orchestrator ──────────────────────────────────────────────────────────────

async def load_task_context(
    db: "ArcadeBackend",
    task_id: str,
    branch: str,
    team_id: str,
) -> TaskContext:
    """Run all 6 steps and return a fully-populated TaskContext.

    Disabled node types are silently skipped — steps that require a disabled
    type return an empty list rather than raising.
    """
    # Load config first — drives step 4 behaviour and confidence omission
    cfg = await db.get_config(team_id, branch)

    # Fetch the task node itself
    task_rows = db._q(
        f"SELECT FROM KGNode WHERE id='{_esc(task_id)}' AND type='Task'"
    )
    if not task_rows:
        raise ValueError(f"Task {task_id!r} not found")
    task = db._node(task_rows[0], cfg)

    repo_id = task.properties.get("repo_id", "")
    task_type = task.properties.get("task_type", "")

    logger.debug(
        "load_task_context: task=%s type=%s repo=%s branch=%s",
        task_id, task_type, repo_id, branch,
    )

    # ── Step 1: Instructions ─────────────────────────────────────────────────
    instructions: list[KGNode] = []
    if cfg.is_node_type_active("Instruction"):
        instructions = _step1_instructions(db, repo_id, task_type, branch, team_id)
        logger.debug("Step 1: %d instructions", len(instructions))

    # ── Step 2: Conditions ───────────────────────────────────────────────────
    conditions: list[KGNode] = []
    if cfg.is_node_type_active("Condition"):
        conditions = _step2_conditions(db, repo_id, task_type, branch, team_id)
        logger.debug("Step 2: %d conditions", len(conditions))

    # ── Step 3: TaskPattern-linked knowledge ─────────────────────────────────
    pat_instructions: list[KGNode] = []
    pat_conditions: list[KGNode] = []
    pat_learnings: list[KGNode] = []
    if cfg.is_node_type_active("TaskPattern"):
        pat_instructions, pat_conditions, pat_learnings = _step3_task_patterns(
            db, task_type, branch, team_id
        )
        logger.debug(
            "Step 3: %d pat-instructions, %d pat-conditions, %d pat-learnings",
            len(pat_instructions), len(pat_conditions), len(pat_learnings),
        )

    # Merge step-3 results into step-1/2, deduped
    instructions = _dedupe(_sort_instructions(instructions + pat_instructions))
    conditions = _dedupe(conditions + pat_conditions)

    # ── Step 4: Learnings ────────────────────────────────────────────────────
    learnings: list[KGNode] = []
    if cfg.is_node_type_active("Learning"):
        direct = _step4_learnings(
            db, repo_id, task_type, branch, team_id, cfg.confidence_enabled
        )
        # Merge pattern learnings (already filtered active)
        all_learnings = _dedupe(direct + pat_learnings)
        # Re-sort if confidence enabled
        if cfg.confidence_enabled:
            all_learnings = sorted(all_learnings, key=lambda n: n.confidence, reverse=True)
        learnings = all_learnings
        logger.debug("Step 4: %d learnings", len(learnings))

    # ── Step 5: Similar tasks + their decisions ───────────────────────────────
    similar_task_ids: list[str] = []
    past_decisions: list[KGNode] = []
    if cfg.is_node_type_active("Task") and cfg.is_node_type_active("Decision"):
        similar_task_ids, past_decisions = _step5_similar_tasks(
            db, task, repo_id, branch, team_id, cfg.confidence_enabled
        )
        logger.debug(
            "Step 5: %d similar tasks, %d decisions", len(similar_task_ids), len(past_decisions)
        )

    # ── Step 6: Active context ────────────────────────────────────────────────
    context_nodes: list[KGNode] = []
    if cfg.is_node_type_active("Context"):
        context_nodes = _step6_context(db, branch, team_id)
        logger.debug("Step 6: %d context nodes", len(context_nodes))

    # Fetch open blockers for this specific task
    blockers: list[KGNode] = []
    if cfg.is_node_type_active("Blocker"):
        blocker_rows = db._q(
            f"SELECT expand(out('BLOCKED_BY')) FROM KGNode WHERE id='{_esc(task_id)}'"
        )
        blockers = [
            db._node(r, cfg) for r in blocker_rows
            if r.get("status") == "open"
        ]

    # Linked symbols stored on the task node
    linked_symbols = await db.get_linked_symbols(task_id, branch, team_id)

    return TaskContext(
        task=task,
        instructions=instructions,
        conditions=conditions,
        learnings=learnings,
        decisions=past_decisions,
        blockers=blockers,
        context=context_nodes,
        linked_symbols=linked_symbols,
        similar_task_ids=similar_task_ids,
        config=cfg,
    )
