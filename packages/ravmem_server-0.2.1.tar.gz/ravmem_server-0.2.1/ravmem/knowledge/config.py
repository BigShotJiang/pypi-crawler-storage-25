"""KGConfig — knowledge graph operational configuration.

Stored as a single KGConfig vertex in ArcadeDB (one per team+branch).
Loaded at server startup; reloaded on any PATCH /api/knowledge/config write.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field

# All built-in node types the user can enable or disable at init time.
BUILTIN_NODE_TYPES: list[str] = [
    "Task",
    "Instruction",
    "Condition",
    "Learning",
    "Blocker",
    "Context",
    "TaskPattern",
    "Decision",
]

# Fields enforced on every KGNode regardless of type — cannot be removed.
ENFORCED_NODE_FIELDS: list[str] = [
    "id",
    "type",
    "label",
    "scope",
    "branch",
    "team_id",
    "source",
    "author_id",
    "active",
    "confidence",
    "validated_by_human",
    "origin_node_id",
    "created_at",
    "updated_at",
]


@dataclass
class KGConfig:
    team_id: str
    branch: str

    # Operational mode
    mode: str = "hitl"              # "hitl" | "auto"

    # Confidence system
    confidence_enabled: bool = True
    hitl_ai_cap: float = 0.70       # AI corroboration ceiling in HITL mode
    auto_ai_cap: float = 1.0        # AI corroboration ceiling in Auto mode

    # Node type gating — types in this list are excluded from all operations
    disabled_node_types: list[str] = field(default_factory=list)

    # Reserved for v2: custom node type definitions
    custom_node_types: str = "[]"   # JSON string; empty array until v2

    # ── Derived helpers ────────────────────────────────────────────────────

    @property
    def active_node_types(self) -> list[str]:
        return [t for t in BUILTIN_NODE_TYPES if t not in self.disabled_node_types]

    @property
    def ai_confidence_cap(self) -> float:
        """Cap applied to AI-driven confidence writes under the current mode."""
        return self.hitl_ai_cap if self.mode == "hitl" else self.auto_ai_cap

    def is_node_type_active(self, node_type: str) -> bool:
        return node_type not in self.disabled_node_types

    # ── Serialisation ──────────────────────────────────────────────────────

    @property
    def config_key(self) -> str:
        """Synthetic unique key for ArcadeDB UPSERT (team_id::branch)."""
        return f"{self.team_id}::{self.branch}"

    def to_dict(self) -> dict:
        return {
            "config_key": self.config_key,
            "team_id": self.team_id,
            "branch": self.branch,
            "mode": self.mode,
            "confidence_enabled": self.confidence_enabled,
            "hitl_ai_cap": self.hitl_ai_cap,
            "auto_ai_cap": self.auto_ai_cap,
            "disabled_node_types": self.disabled_node_types,
            "custom_node_types": self.custom_node_types,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "KGConfig":
        return cls(
            team_id=d["team_id"],
            branch=d["branch"],
            mode=d.get("mode", "hitl"),
            confidence_enabled=d.get("confidence_enabled", True),
            hitl_ai_cap=d.get("hitl_ai_cap", 0.70),
            auto_ai_cap=d.get("auto_ai_cap", 1.0),
            disabled_node_types=d.get("disabled_node_types", []),
            custom_node_types=d.get("custom_node_types", "[]"),
        )

    @classmethod
    def default(cls, team_id: str = "default", branch: str = "global") -> "KGConfig":
        return cls(team_id=team_id, branch=branch)


# ── Env-var overrides (applied after init, useful for CI/Docker) ───────────────

def load_env_overrides(cfg: KGConfig) -> KGConfig:
    """Apply RAVMEM_KG_* env vars on top of a stored KGConfig.

    Env vars take effect without re-running init — useful in containerised
    environments where config is baked into the image.
    """
    mode = os.environ.get("RAVMEM_KG_MODE")
    if mode in ("hitl", "auto"):
        cfg.mode = mode

    conf = os.environ.get("RAVMEM_KG_CONFIDENCE_ENABLED")
    if conf is not None:
        cfg.confidence_enabled = conf.lower() not in ("0", "false", "no")

    hitl_cap = os.environ.get("RAVMEM_KG_HITL_CAP")
    if hitl_cap is not None:
        cfg.hitl_ai_cap = float(hitl_cap)

    auto_cap = os.environ.get("RAVMEM_KG_AUTO_CAP")
    if auto_cap is not None:
        cfg.auto_ai_cap = float(auto_cap)

    return cfg
