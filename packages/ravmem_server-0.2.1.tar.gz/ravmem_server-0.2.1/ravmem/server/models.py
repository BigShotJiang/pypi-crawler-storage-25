"""Pydantic models for the project/branch management API."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

IndexMode = Literal["mount", "upload", "clone"]


class ProjectCreate(BaseModel):
    """Request body for POST /api/projects.

    Exactly one source must be specified:

    - ``git_url`` → clone mode.  Private repos also need ``git_username`` + ``git_token``.
    - ``repo_path`` + ``mount=True`` → mount mode.  Path must exist on the server.
    - ``repo_path`` (``mount=False``, default) → upload mode.  CLI pushes files later.
    """

    # Clone mode
    git_url: str | None = Field(None, description="Git remote URL for server-side clone")
    git_username: str | None = Field(None, description="Username for private repos (clone mode)")
    git_token: str | None = Field(None, description="Token/password for private repos (clone mode)")

    # Mount / upload mode
    repo_path: str | None = Field(
        None,
        description="Server filesystem path (mount mode) or client path hint (upload mode)",
    )
    mount: bool = Field(
        False,
        description="Mark repo_path as a pre-mounted volume — selects mount mode",
    )

    # Shared
    name: str | None = Field(None, description="Display name (defaults to repo/directory name)")
    default_branch: str = Field("main", description="Primary branch to index first")
    langs: list[str] = Field(
        default_factory=lambda: ["python", "typescript", "javascript", "go"],
    )

    @model_validator(mode="after")
    def _validate_source(self) -> "ProjectCreate":
        has_git = bool(self.git_url)
        has_path = bool(self.repo_path)
        if not has_git and not has_path:
            raise ValueError(
                "Specify a source: --git-url <URL> for clone mode, "
                "or a local/server path for upload/mount mode."
            )
        if has_git and has_path:
            raise ValueError("Provide either --git-url or a path, not both.")
        if self.git_username and not self.git_url:
            raise ValueError("--git-username requires --git-url.")
        if self.git_token and not self.git_url:
            raise ValueError("--git-token requires --git-url.")
        if self.mount and not has_path:
            raise ValueError("--mount requires a repo path.")
        return self

    @property
    def resolved_index_mode(self) -> IndexMode:
        if self.git_url:
            return "clone"
        return "mount" if self.mount else "upload"


class ProjectInfo(BaseModel):
    """Response model for project details."""

    project_id: str
    name: str
    repo_path: str
    default_branch: str
    indexed_branches: list[BranchIndex] = []
    created_at: str
    updated_at: str


class BranchIndex(BaseModel):
    """Status of a single branch index."""

    branch: str
    last_commit: str = ""
    symbol_count: int = 0
    edge_count: int = 0
    status: str = "empty"  # empty | indexing | ready | failed | stale
    indexed_at: str | None = None


class ProjectUpdate(BaseModel):
    """Request body for PATCH /api/projects/{id}."""

    default_branch: str | None = Field(None, description="New default/parent branch for copy-from-base")
    index_mode: IndexMode | None = Field(None, description="Override index mode")
    workspace_path: str | None = Field(None, description="Override server workspace path")


class CredentialUpdate(BaseModel):
    """Request body for POST /api/projects/{id}/credentials."""

    git_username: str = Field(..., description="Git username")
    git_token: str = Field(..., description="Git token/password (stored encrypted)")


class IndexRequest(BaseModel):
    """Request body for POST /api/projects/{id}/branches/{branch}/index."""

    mode: str = Field("auto", description="full | incremental | auto")
    langs: list[str] | None = Field(None, description="Languages to index (None = use project default)")
    no_auto_sync: bool = Field(False, description="Skip automatic git fetch before indexing (clone-mode only)")


class UploadFile(BaseModel):
    """A single file in an upload batch."""

    path: str = Field(..., description="Repo-relative path, forward-slash separated")
    content: str = Field(..., description="File content, base64-encoded")


class UploadBatch(BaseModel):
    """One HTTP payload in a multi-batch upload (full or incremental).

    The CLI splits the local repo into N batches and POSTs each sequentially.
    For full uploads the server writes files to a fresh staging workspace.
    For incremental uploads the server copies the existing workspace to staging,
    applies the changed files and deletes the removed paths, then promotes.
    """

    branch: str = Field(..., description="Branch being indexed")
    parent_branch: str | None = Field(None, description="Parent branch for copy-from-base")
    to_commit: str = Field("", description="Client-side HEAD SHA recorded as last_indexed_commit")
    from_commit: str = Field("", description="Base commit for incremental upload (informational)")
    mode: Literal["full", "incremental"] = Field("full", description="Upload mode")
    batch_index: int = Field(..., ge=1, description="1-based index of this batch")
    batch_total: int = Field(..., ge=1, description="Total number of batches in this upload")
    files: list[UploadFile] = Field(default_factory=list, description="Files in this batch")
    deleted_paths: list[str] = Field(
        default_factory=list,
        description="Paths to remove from workspace (incremental, first batch only)",
    )
    langs: list[str] | None = Field(None, description="Languages to index (None = project default)")


class IndexJobStatus(BaseModel):
    """Response model for job status."""

    job_id: int
    project_id: str
    branch: str
    mode: str
    status: str  # queued | running | done | failed | cancelled
    progress_pct: int = 0
    current_phase: str = ""
    started_at: str | None = None
    ended_at: str | None = None
    failure_reason: str = ""


# Fix forward reference for ProjectInfo.indexed_branches
ProjectInfo.model_rebuild()
