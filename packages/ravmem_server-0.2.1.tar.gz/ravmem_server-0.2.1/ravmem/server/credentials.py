"""Encrypted credential storage for clone-mode projects.

Credentials (git username + token) are encrypted at rest using Fernet
symmetric encryption. The key is derived from the RAVMEM_SECRET_KEY
environment variable via PBKDF2-HMAC-SHA256.

Storage location: $RAVMEM_DATA_DIR/repos/{project_id}/.git-credentials
File permissions:  600 (owner read/write only)
"""

from __future__ import annotations

import base64
import json
import os
import stat
from pathlib import Path

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

_SALT = b"ravmem-credentials-v1"  # fixed salt — key uniqueness comes from RAVMEM_SECRET_KEY
_ITERATIONS = 480_000
_CRED_FILENAME = ".git-credentials"


class CredentialError(Exception):
    """Raised when credential operations fail."""


def _require_secret_key() -> bytes:
    key = os.environ.get("RAVMEM_SECRET_KEY", "")
    if not key:
        raise CredentialError(
            "Cannot store credentials: RAVMEM_SECRET_KEY is not set on the server. "
            "Ask the server admin to set this environment variable."
        )
    return key.encode()


def _derive_fernet(secret: bytes) -> Fernet:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=_SALT,
        iterations=_ITERATIONS,
    )
    key = base64.urlsafe_b64encode(kdf.derive(secret))
    return Fernet(key)


class CredentialStore:
    """Manages encrypted git credentials for a single project."""

    def __init__(self, project_data_dir: Path) -> None:
        self._cred_path = project_data_dir / _CRED_FILENAME

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def store(self, git_url: str, git_username: str, git_token: str) -> None:
        """Encrypt and persist credentials. Requires RAVMEM_SECRET_KEY."""
        secret = _require_secret_key()
        fernet = _derive_fernet(secret)
        payload = json.dumps(
            {"git_url": git_url, "git_username": git_username, "git_token": git_token}
        ).encode()
        encrypted = fernet.encrypt(payload)
        self._cred_path.parent.mkdir(parents=True, exist_ok=True)
        self._cred_path.write_bytes(encrypted)
        # Restrict to owner read/write only
        try:
            self._cred_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass  # Windows — best-effort

    def load(self) -> dict[str, str]:
        """Decrypt and return credentials as {git_url, git_username, git_token}.

        Raises CredentialError if not found or decryption fails.
        """
        if not self._cred_path.exists():
            raise CredentialError("No credentials stored for this project.")
        secret = _require_secret_key()
        fernet = _derive_fernet(secret)
        try:
            decrypted = fernet.decrypt(self._cred_path.read_bytes())
            return json.loads(decrypted)
        except Exception as exc:
            raise CredentialError(f"Failed to decrypt credentials: {exc}") from exc

    def delete(self) -> None:
        """Remove stored credentials. No-op if not present."""
        if self._cred_path.exists():
            self._cred_path.unlink()

    def exists(self) -> bool:
        """Return True if credentials are stored for this project."""
        return self._cred_path.exists()
