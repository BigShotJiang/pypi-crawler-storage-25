"""Git helper functions for server-side repository management."""

from __future__ import annotations

import logging
import subprocess
import time
from pathlib import Path
from urllib.parse import urlparse, urlunparse

logger = logging.getLogger(__name__)


class GitError(Exception):
    """Raised when a git command fails."""


def _run(args: list[str], cwd: Path, timeout: int = 60) -> str:
    """Run a git command and return its stdout, raising GitError on failure."""
    result = subprocess.run(
        args, cwd=str(cwd), capture_output=True, text=True, timeout=timeout,
    )
    if result.returncode != 0:
        raise GitError(
            f"git command failed: {' '.join(args)}\nstderr: {result.stderr.strip()}"
        )
    return result.stdout.strip()


def _inject_credentials(url: str, username: str, token: str) -> str:
    """Return the URL with username:token embedded (https only)."""
    parsed = urlparse(url)
    netloc = f"{username}:{token}@{parsed.hostname}"
    if parsed.port:
        netloc += f":{parsed.port}"
    return urlunparse(parsed._replace(netloc=netloc))


def clone_repo(url: str, dest: Path, bare: bool = False) -> None:
    """Clone a public git repository to *dest*."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["git", "clone"]
    if bare:
        cmd.append("--bare")
    cmd.extend([url, str(dest)])
    subprocess.run(cmd, capture_output=True, text=True, timeout=600, check=True)
    logger.info("Cloned %s → %s", url, dest)


def clone_with_credentials(
    url: str, dest: Path, username: str, token: str
) -> None:
    """Clone a private git repository using username/token auth."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    auth_url = _inject_credentials(url, username, token)
    result = subprocess.run(
        ["git", "clone", auth_url, str(dest)],
        capture_output=True, text=True, timeout=600,
    )
    if result.returncode != 0:
        # Strip the auth URL from the error message before raising
        safe_err = result.stderr.replace(auth_url, url)
        raise GitError(f"git clone failed: {safe_err.strip()}")
    logger.info("Cloned (authenticated) %s → %s", url, dest)


def get_branches(repo_path: Path) -> list[str]:
    """Return all local branch names for the repo."""
    out = _run(
        ["git", "branch", "--format=%(refname:short)"], cwd=repo_path,
    )
    return [b.strip() for b in out.splitlines() if b.strip()]


def get_remote_branches(repo_path: Path) -> list[str]:
    """Return all remote-tracking branch names (without 'origin/' prefix)."""
    out = _run(
        ["git", "branch", "-r", "--format=%(refname:short)"], cwd=repo_path,
    )
    branches = []
    for b in out.splitlines():
        b = b.strip()
        if b and "HEAD" not in b:
            # Strip remote prefix, e.g. "origin/main" → "main"
            branches.append(b.split("/", 1)[-1] if "/" in b else b)
    return sorted(set(branches))


def get_current_branch(repo_path: Path) -> str:
    """Return the current branch name, or empty string if detached."""
    try:
        return _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_path)
    except GitError:
        return ""


def get_head_commit(repo_path: Path, branch: str | None = None) -> str:
    """Return the HEAD commit hash, optionally for a specific branch."""
    ref = branch or "HEAD"
    return _run(["git", "rev-parse", ref], cwd=repo_path)


def get_merge_base(repo_path: Path, ref_a: str, ref_b: str) -> str:
    """Return the merge-base commit of two refs."""
    return _run(["git", "merge-base", ref_a, ref_b], cwd=repo_path)


def is_ancestor(repo_path: Path, ancestor: str, descendant: str) -> bool:
    """Return True if *ancestor* is an ancestor of *descendant*."""
    result = subprocess.run(
        ["git", "merge-base", "--is-ancestor", ancestor, descendant],
        cwd=str(repo_path), capture_output=True, timeout=10,
    )
    return result.returncode == 0


def diff_name_status(
    repo_path: Path, base_commit: str, target: str = "HEAD",
) -> tuple[set[str], set[str]]:
    """Return (modified_abs_paths, deleted_abs_paths) between two commits.

    Modified includes Added, Modified, Renamed, Copied.
    """
    out = _run(
        ["git", "diff", "--name-status", base_commit, target], cwd=repo_path,
    )
    modified: set[str] = set()
    deleted: set[str] = set()
    for line in out.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t", 1)
        if len(parts) != 2:
            continue
        status, name = parts[0].strip(), parts[1].strip()
        abs_path = str((repo_path / name).resolve())
        if status.startswith("D"):
            deleted.add(abs_path)
        else:
            modified.add(abs_path)
    return modified, deleted


def diff_stat(
    repo_path: Path, base_commit: str, target: str = "HEAD",
) -> dict[str, int]:
    """Return summary stats for the diff between two refs.

    Returns dict with keys: files_changed, insertions, deletions.
    """
    out = _run(
        ["git", "diff", "--stat", base_commit, target], cwd=repo_path,
    )
    # Last line is like: " 5 files changed, 42 insertions(+), 18 deletions(-)"
    result = {"files_changed": 0, "insertions": 0, "deletions": 0}
    lines = out.strip().splitlines()
    if not lines:
        return result
    summary = lines[-1]
    for token in summary.split(","):
        token = token.strip()
        if "file" in token:
            result["files_changed"] = int(token.split()[0])
        elif "insertion" in token:
            result["insertions"] = int(token.split()[0])
        elif "deletion" in token:
            result["deletions"] = int(token.split()[0])
    return result


def checkout_branch(repo_path: Path, branch: str) -> None:
    """Check out a branch. Creates local tracking branch if needed."""
    try:
        _run(["git", "checkout", branch], cwd=repo_path)
    except GitError:
        # Try creating a local branch tracking the remote
        _run(["git", "checkout", "-b", branch, f"origin/{branch}"], cwd=repo_path)


def fetch(repo_path: Path) -> None:
    """Fetch all remotes (unauthenticated / SSH key)."""
    _run(["git", "fetch", "--all", "--prune"], cwd=repo_path, timeout=120)


def _get_remote_refs(repo_path: Path) -> dict[str, str]:
    """Return {branch_name: sha} for all remote-tracking refs."""
    try:
        out = _run(
            ["git", "for-each-ref", "--format=%(refname:short) %(objectname:short)",
             "refs/remotes/origin/"],
            cwd=repo_path,
        )
    except GitError:
        return {}
    refs: dict[str, str] = {}
    for line in out.splitlines():
        parts = line.split()
        if len(parts) == 2:
            name = parts[0].removeprefix("origin/")
            if name != "HEAD":
                refs[name] = parts[1]
    return refs


def fetch_with_credentials(
    repo_path: Path,
    username: str,
    token: str,
    remote: str = "origin",
) -> None:
    """Fetch all branches from a remote using username/token auth.

    Temporarily rewrites the remote URL with embedded credentials, fetches,
    then restores the original URL — credentials never persist in git config.
    """
    original_url = _run(["git", "remote", "get-url", remote], cwd=repo_path)
    auth_url = _inject_credentials(original_url, username, token)
    try:
        _run(["git", "remote", "set-url", remote, auth_url], cwd=repo_path)
        _run(["git", "fetch", remote, "--prune"], cwd=repo_path, timeout=120)
    except GitError as exc:
        safe_err = str(exc).replace(auth_url, original_url)
        raise GitError(safe_err) from None
    finally:
        # Always restore original URL so credentials don't linger in git config
        try:
            _run(["git", "remote", "set-url", remote, original_url], cwd=repo_path)
        except GitError:
            pass


def sync_workspace(
    workspace_path: Path,
    cred_store=None,
) -> dict:
    """Fetch all remote refs into *workspace_path*.

    *cred_store* is an optional ``CredentialStore`` instance; when present and
    credentials are stored, fetch is authenticated.

    Returns a summary dict:
        {synced, fetched_branches, fetched_commits, workspace_head, duration_ms}
    """
    t0 = time.monotonic()

    before = _get_remote_refs(workspace_path)

    if cred_store is not None and cred_store.exists():
        creds = cred_store.load()
        fetch_with_credentials(
            workspace_path,
            username=creds["git_username"],
            token=creds["git_token"],
        )
    else:
        fetch(workspace_path)

    after = _get_remote_refs(workspace_path)

    new_branches = [b for b in after if b not in before]
    changed_commits = sum(
        1 for b, sha in after.items() if before.get(b) not in (sha, None)
    )
    total_fetched = len(new_branches) + changed_commits

    try:
        head = get_head_commit(workspace_path)[:7]
    except GitError:
        head = ""

    return {
        "synced": True,
        "fetched_branches": new_branches,
        "fetched_commits": total_fetched,
        "workspace_head": head,
        "duration_ms": round((time.monotonic() - t0) * 1000),
    }


def get_commit_message(repo_path: Path, sha: str) -> str | None:
    """Return the subject line of *sha*, or None if unavailable."""
    if not sha or not is_git_repo(repo_path):
        return None
    try:
        return _run(["git", "log", "--format=%s", "-1", sha], cwd=repo_path) or None
    except GitError:
        return None


def is_git_repo(path: Path) -> bool:
    """Return True if *path* is inside a git repository."""
    result = subprocess.run(
        ["git", "-C", str(path), "rev-parse", "--git-dir"],
        capture_output=True, timeout=5,
    )
    return result.returncode == 0
