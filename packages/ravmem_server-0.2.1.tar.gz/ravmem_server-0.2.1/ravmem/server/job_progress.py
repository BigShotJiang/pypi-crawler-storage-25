"""Job progress tracking — bridges IndexPipeline on_progress callbacks to the registry."""

from __future__ import annotations

import logging
import re

from ravmem.server.registry import ServerRegistry

logger = logging.getLogger(__name__)

# Map pipeline phase names to percentage ranges
_PHASE_RANGES = {
    "structure": (0, 20),
    "parse": (20, 40),
    "resolve": (40, 60),
    "cluster": (60, 75),
    "embed": (75, 90),
    "centrality": (90, 100),
}


def make_progress_callback(
    registry: ServerRegistry,
    job_id: int,
    project_id: str,
    branch: str,
) -> callable:
    """Return a callback function for IndexPipeline.on_progress.

    The callback parses progress messages from the pipeline and updates
    the job record in the registry with phase name and percentage.
    """
    def callback(message: str) -> None:
        phase = _extract_phase(message)
        if phase:
            pct_start, _ = _PHASE_RANGES.get(phase, (0, 0))
            try:
                registry.update_job(
                    job_id,
                    current_phase=phase,
                    progress_pct=pct_start,
                )
            except Exception:
                logger.warning("Failed to update job %d progress", job_id, exc_info=True)

        logger.info("[%s/%s job=%d] %s", project_id, branch, job_id, message)

    return callback


def make_progress_event_callback(
    registry: ServerRegistry,
    job_id: int,
    project_id: str,
    branch: str,
) -> callable:
    """Return a callback for IndexPipeline.on_progress_event that uses ProgressEvent."""
    def callback(event) -> None:  # event: ProgressEvent
        try:
            registry.update_job(
                job_id,
                current_phase=event.phase,
                progress_pct=event.pct,
            )
        except Exception:
            logger.warning("Failed to update job %d progress event", job_id, exc_info=True)
        logger.info(
            "[%s/%s job=%d] phase=%s pct=%d items=%d/%d",
            project_id, branch, job_id,
            event.phase, event.pct, event.items_done, event.items_total,
        )
    return callback


def _extract_phase(message: str) -> str | None:
    """Extract phase name from pipeline progress messages.

    Pipeline messages follow patterns like:
    - "Phase 1/5: Structure walk..."
    - "phase_structure: walking..."
    - "Structure: found 42 files"
    """
    msg_lower = message.lower()
    for phase_name in _PHASE_RANGES:
        if phase_name in msg_lower:
            return phase_name
    # Also match "Phase N/5" pattern
    m = re.match(r"phase\s+(\d)/", msg_lower)
    if m:
        phase_num = int(m.group(1))
        phases = list(_PHASE_RANGES.keys())
        if 1 <= phase_num <= len(phases):
            return phases[phase_num - 1]
    return None
