"""WebSocket route — pushes live graph diff events during reindex."""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter(tags=["websocket"])

# Simple in-process event bus: repo_id → list of connected WebSockets
_connections: dict[str, list[WebSocket]] = {}


async def broadcast(repo_id: str, event: dict[str, Any]) -> None:
    """Broadcast an event to all clients watching this repo."""
    sockets = _connections.get(repo_id, [])
    dead: list[WebSocket] = []
    for ws in sockets:
        try:
            await ws.send_json(event)
        except Exception:
            dead.append(ws)
    for ws in dead:
        sockets.remove(ws)


@router.websocket("/ws/repos/{repo_id}/graph")
async def graph_ws(websocket: WebSocket, repo_id: str) -> None:
    await websocket.accept()
    _connections.setdefault(repo_id, []).append(websocket)
    try:
        while True:
            # Keep alive — client can send pings
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        sockets = _connections.get(repo_id, [])
        if websocket in sockets:
            sockets.remove(websocket)
