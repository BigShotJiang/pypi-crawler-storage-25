"""MCP (Model Context Protocol) endpoint — 6 tools for AI agent integration."""

from __future__ import annotations

import json
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, model_validator

router = APIRouter(tags=["mcp"])


# ---------------------------------------------------------------------------
# MCP protocol models
# ---------------------------------------------------------------------------

class MCPToolCall(BaseModel):
    name: str
    arguments: dict[str, Any] = {}

    @model_validator(mode="before")
    @classmethod
    def _accept_parameters_alias(cls, data: Any) -> Any:
        """Accept 'parameters' as an alias for 'arguments' for backwards compatibility."""
        if isinstance(data, dict) and "parameters" in data and "arguments" not in data:
            data = dict(data)
            data["arguments"] = data.pop("parameters")
        return data


class MCPRequest(BaseModel):
    tool_calls: list[MCPToolCall]


class MCPContentItem(BaseModel):
    type: str = "text"
    text: str


class MCPToolResult(BaseModel):
    """Per-tool call result in MCP CallToolResult format."""
    name: str                          # kept for routing/debugging
    content: list[MCPContentItem]
    isError: bool = False


class MCPResponse(BaseModel):
    results: list[MCPToolResult]       # one entry per tool_call in the request


# ---------------------------------------------------------------------------
# Tool definitions (returned on GET /mcp)
# ---------------------------------------------------------------------------

MCP_TOOLS = [
    {
        "name": "search_symbols",
        "description": "Hybrid BM25 + semantic search over all indexed symbols",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "repo": {"type": "string", "description": "Repo ID or path"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["query", "repo"],
        },
    },
    {
        "name": "get_impact",
        "description": "Return all symbols that depend on a given symbol (blast radius)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
                "depth": {"type": "integer", "default": 3},
            },
            "required": ["symbol_id", "repo"],
        },
    },
    {
        "name": "get_call_chain",
        "description": "Trace full call chain from an entry point symbol",
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
                "direction": {"type": "string", "enum": ["callers", "callees", "both"], "default": "callees"},
                "depth": {"type": "integer", "default": 5},
            },
            "required": ["symbol_id", "repo"],
        },
    },
    {
        "name": "get_cluster",
        "description": "Return all symbols in a cluster / module group",
        "inputSchema": {
            "type": "object",
            "properties": {
                "cluster_id": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["cluster_id", "repo"],
        },
    },
    {
        "name": "get_symbol",
        "description": "Get full details and neighbours for a specific symbol",
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol_id": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["symbol_id", "repo"],
        },
    },
    {
        "name": "diff_impact",
        "description": "Given a git diff, return all symbols affected and their blast radius",
        "inputSchema": {
            "type": "object",
            "properties": {
                "diff": {"type": "string", "description": "Unified diff text"},
                "repo": {"type": "string"},
            },
            "required": ["diff", "repo"],
        },
    },
    {
        "name": "list_repos",
        "description": "List all indexed repositories",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "suggest_entry_points",
        "description": "Return top-N symbols by PageRank centrality — best starting points for codebase exploration",
        "inputSchema": {
            "type": "object",
            "properties": {
                "repo": {"type": "string"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["repo"],
        },
    },
    {
        "name": "get_file_context",
        "description": "Get all symbols in a file plus their callers and callees — natural entry point for agents reading diffs",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["file_path", "repo"],
        },
    },
    {
        "name": "sync_workspace",
        "description": (
            "Fetch the latest remote commits into the server-side workspace for a "
            "clone-mode project. Does not re-index — call the index tool afterwards."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "project_id": {
                    "type": "string",
                    "description": "Project ID to sync",
                },
            },
            "required": ["project_id"],
        },
    },
    {
        "name": "get_symbols_for_path",
        "description": "List all symbols in a file (exact) or directory (prefix). Use prefix=true with a directory path like 'src/auth/' to query all symbols under that folder.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path or directory prefix"},
                "repo": {"type": "string"},
                "prefix": {"type": "boolean", "default": False, "description": "If true, treat path as a prefix — returns all symbols in matching files"},
            },
            "required": ["path", "repo"],
        },
    },
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _symbol_dict(s) -> dict:
    return {
        "id": s.id, "name": s.name, "kind": s.kind,
        "file": s.file, "line_start": s.line_start,
        "line_end": s.line_end, "lang": s.lang,
        "cluster_id": s.cluster_id,
        "docstring": getattr(s, "docstring", ""),
    }


def _get_engines(repo: str, repos_dir):
    from ravmem.server.app import get_repo_engines
    from pathlib import Path

    # Accept either a bare repo name or an absolute path
    if repos_dir and not repo.startswith("/") and not repo[1:3] == ":\\":
        repo_path = str(repos_dir / repo)
    else:
        repo_path = repo

    return get_repo_engines(repo_path)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.get("/mcp")
async def mcp_tool_list() -> dict:
    """List available MCP tools."""
    return {"tools": MCP_TOOLS}


@router.post("/mcp", response_model=MCPResponse)
async def mcp_dispatch(request: Request, body: MCPRequest) -> MCPResponse:
    """Dispatch one or more MCP tool calls."""
    state = request.app.state
    results: list[MCPToolResult] = []

    for call in body.tool_calls:
        try:
            result = await _dispatch_tool(call.name, call.arguments, state)
            results.append(MCPToolResult(
                name=call.name,
                content=[MCPContentItem(type="text", text=json.dumps(result, default=str))],
                isError=False,
            ))
        except Exception as exc:
            results.append(MCPToolResult(
                name=call.name,
                content=[MCPContentItem(type="text", text=str(exc))],
                isError=True,
            ))

    return MCPResponse(results=results)


async def _dispatch_tool(name: str, params: dict, state) -> Any:
    repos_dir = getattr(state, "repos_dir", None)
    if name == "search_symbols":
        engines = _get_engines(params["repo"], repos_dir)
        query = params["query"]
        limit = params.get("limit", 10)
        results = engines.search_engine.search(query, k=limit)
        return [
            {
                "symbol": _symbol_dict(r.symbol),
                "score": r.score,
                "match_type": r.match_type,
                "relevance_reason": f"Matched via {r.match_type} on '{query}'",
                "summary": f"{r.symbol.kind} {r.symbol.name} in {os.path.basename(r.symbol.file)}",
            }
            for r in results
        ]

    elif name == "get_impact":
        engines = _get_engines(params["repo"], repos_dir)
        depth = params.get("depth", 3)
        result = engines.impact_engine.get_impact(params["symbol_id"], depth=depth)
        return {
            "root_symbol_id": result.root_symbol_id,
            "usage_hint": f"Changing this symbol affects {len(result.affected)} callers — review each before modifying",
            "total_affected_count": len(result.affected),
            "affected": [
                {
                    "symbol": _symbol_dict(n.symbol),
                    "depth": n.depth,
                    "path": n.path,
                    "confidence": n.confidence if hasattr(n, "confidence") else 1.0,
                }
                for n in result.affected
            ],
        }

    elif name == "get_call_chain":
        engines = _get_engines(params["repo"], repos_dir)
        direction = params.get("direction", "callees")
        depth = params.get("depth", 5)
        result = engines.impact_engine.get_call_chain(
            params["symbol_id"], direction=direction, depth=depth
        )
        if isinstance(result, dict):
            return {
                "callers": [_symbol_dict(s) for s in result["callers"]],
                "callees": [_symbol_dict(s) for s in result["callees"]],
            }
        return [_symbol_dict(s) for s in result]

    elif name == "get_cluster":
        engines = _get_engines(params["repo"], repos_dir)
        cid = params["cluster_id"]
        members = engines.graph.get_cluster_members(cid)
        cluster = engines.graph.get_cluster(cid)
        # Prefix indicates cluster origin: lc_=Leiden cross-file, fc_=file-based, c_=legacy Louvain
        if cid.startswith("lc_"):
            cluster_type = "leiden"
        elif cid.startswith("fc_"):
            cluster_type = "file"
        else:
            cluster_type = "legacy"
        return {
            "cluster": {
                "id": cluster.id, "label": cluster.label,
                "cohesion_score": cluster.cohesion_score, "size": cluster.size,
                "cluster_type": cluster_type,
            } if cluster else None,
            "members": [_symbol_dict(s) for s in members],
        }

    elif name == "get_symbol":
        engines = _get_engines(params["repo"], repos_dir)
        ctx = engines.context_engine.assemble_symbol_context(params["symbol_id"])
        if ctx is None:
            raise ValueError(f"Symbol not found: {params['symbol_id']}")
        callers_list = [_symbol_dict(s) for s in ctx.callers]
        callees_list = [_symbol_dict(s) for s in ctx.callees]
        return {
            "symbol": _symbol_dict(ctx.symbol),
            "callers": callers_list,
            "callees": callees_list,
            "incoming": {"calls": callers_list},
            "outgoing": {"calls": callees_list},
            "cluster": {
                "id": ctx.cluster.id, "label": ctx.cluster.label,
                "cohesion_score": ctx.cluster.cohesion_score,
            } if ctx.cluster else None,
            "cluster_peers": [_symbol_dict(s) for s in ctx.cluster_peers],
        }

    elif name == "diff_impact":
        engines = _get_engines(params["repo"], repos_dir)
        diff_text = params.get("diff") or params.get("diff_text", "")
        if not diff_text:
            raise ValueError("Missing required parameter: 'diff' (unified diff text)")
        impact_results = engines.impact_engine.diff_impact(diff_text)
        output = []
        for r in impact_results:
            affected_preview = r.affected[:20]
            total = r.total_affected_count if r.total_affected_count > 0 else len(r.affected)
            output.append({
                "root_symbol_id": r.root_symbol_id,
                "total_affected_count": total,
                "truncated": len(r.affected) > 20,
                "affected": [
                    {"symbol": _symbol_dict(n.symbol), "depth": n.depth}
                    for n in affected_preview
                ],
            })
        deleted_or_unresolved = [
            r.root_symbol_id for r in impact_results if len(r.affected) == 0
        ]
        return {
            "results": output,
            "deleted_or_unresolved_symbols": deleted_or_unresolved,
            "usage_hint": (
                "Symbols with 0 affected may have been deleted from the codebase "
                "or were never indexed — check if they still exist in the graph"
            ),
        }

    elif name == "list_repos":
        from pathlib import Path
        from ravmem.storage.meta import MetaStore
        from ravmem.config import INDEX_DIR, META_DB_NAME
        repos_dir_path = Path(repos_dir) if repos_dir else Path(".")
        result = []
        if repos_dir_path.exists():
            for p in sorted(repos_dir_path.iterdir()):
                meta_db = p / INDEX_DIR / META_DB_NAME
                if p.is_dir() and meta_db.exists():
                    try:
                        ms = MetaStore(meta_db)
                        repos = ms.list_repos()
                        for r in repos:
                            r["repo_path"] = str(p)
                            result.append(r)
                    except Exception as exc:
                        result.append({"repo_path": str(p), "error": str(exc)})
        return result

    elif name == "suggest_entry_points":
        from pathlib import Path
        engines = _get_engines(params["repo"], repos_dir)
        limit = params.get("limit", 10)
        # repo_id is the directory name, same as in app.py (repo_path.name)
        repo_path = Path(params["repo"]) if params["repo"].startswith("/") else (
            repos_dir / params["repo"] if repos_dir else Path(params["repo"])
        )
        repo_id = repo_path.name
        centrality = engines.meta.load_centrality(repo_id)
        if not centrality:
            return {
                "entry_points": [],
                "hint": "Run ravmem analyze first to compute centrality",
            }
        sorted_ids = sorted(centrality, key=lambda k: centrality[k], reverse=True)[:limit]
        entry_points = []
        for sid in sorted_ids:
            sym = engines.graph.get_symbol(sid)
            if sym:
                entry_points.append({**_symbol_dict(sym), "centrality_score": centrality[sid]})
        return {"entry_points": entry_points}

    elif name == "get_file_context":
        engines = _get_engines(params["repo"], repos_dir)
        file_path = params["file_path"]
        symbols = engines.graph.get_symbols_for_file(file_path)
        file_symbols = []
        for sym in symbols:
            callers = engines.graph.get_callers(sym.id, depth=1)
            callees = engines.graph.get_callees(sym.id, depth=1)
            file_symbols.append({
                "symbol": _symbol_dict(sym),
                "callers": [_symbol_dict(s) for s in callers],
                "callees": [_symbol_dict(s) for s in callees],
            })
        return {"file_path": file_path, "symbols": file_symbols}

    elif name == "sync_workspace":
        branch_manager = getattr(state, "branch_manager", None)
        if branch_manager is None:
            raise ValueError("branch_manager not available in server state")
        project_id = params["project_id"]
        import asyncio
        result = await asyncio.get_event_loop().run_in_executor(
            None, branch_manager.sync_project_workspace, project_id
        )
        return result

    elif name == "get_symbols_for_path":
        engines = _get_engines(params["repo"], repos_dir)
        path = params["path"]
        use_prefix = params.get("prefix", False)
        if use_prefix:
            symbols = engines.graph.get_symbols_for_path_prefix(path)
        else:
            symbols = engines.graph.get_symbols_for_file(path)
        return {"path": path, "prefix": use_prefix, "symbols": [_symbol_dict(s) for s in symbols]}

    else:
        raise ValueError(f"Unknown MCP tool: {name}")
