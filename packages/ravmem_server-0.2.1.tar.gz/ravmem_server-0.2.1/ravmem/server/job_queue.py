"""Async job queue for branch indexing.

Bounds concurrent index work to ``max_concurrent`` slots, prevents duplicate
jobs for the same project+branch, and recovers stale jobs across server
restarts.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Callable, Awaitable

from ravmem.server.registry import ServerRegistry

logger = logging.getLogger(__name__)


class IndexJobQueue:
    """Bounded async queue for indexing jobs.

    Parameters
    ----------
    registry:
        Server-level registry used to look up and update job records.
    max_concurrent:
        Maximum number of jobs that may run simultaneously (default: 2).
    """

    def __init__(
        self,
        registry: ServerRegistry,
        max_concurrent: int = int(os.environ.get("RAVMEM_MAX_CONCURRENT_JOBS", "2")),
    ) -> None:
        self._registry = registry
        self._max_concurrent = max_concurrent
        self._semaphore: asyncio.Semaphore | None = None
        self._queue: asyncio.Queue[tuple[int, Callable[[], Awaitable[None]]]] | None = None
        self._worker_task: asyncio.Task | None = None
        self._active: int = 0
        self._running = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Recover stale jobs from a previous server run, then start the worker loop."""
        self._semaphore = asyncio.Semaphore(self._max_concurrent)
        self._queue = asyncio.Queue()
        self._running = True

        # Mark any jobs that were left "running" as failed (server was restarted)
        stale_running = [
            j for j in self._registry.list_jobs(limit=1000)
            if j["status"] == "running"
        ]
        for job in stale_running:
            logger.warning(
                "Marking stale running job %d (%s/%s) as failed — server restarted",
                job["id"], job["project_id"], job["branch"],
            )
            self._registry.update_job(
                job["id"],
                status="failed",
                failure_reason="server restarted",
            )
            self._registry.update_branch_status(
                job["project_id"], job["branch"], status="failed",
            )

        self._worker_task = asyncio.ensure_future(self._worker_loop())
        logger.info("IndexJobQueue started (max_concurrent=%d)", self._max_concurrent)

    async def stop(self) -> None:
        """Drain the queue and shut down."""
        # Join first so in-flight jobs finish before we signal the worker to stop.
        if self._queue is not None:
            await self._queue.join()
        self._running = False
        if self._worker_task is not None:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        logger.info("IndexJobQueue stopped")

    # ------------------------------------------------------------------
    # Enqueue
    # ------------------------------------------------------------------

    async def enqueue(self, job_id: int, coro_factory: Callable[[], Awaitable[None]]) -> None:
        """Add a job to the queue.

        Parameters
        ----------
        job_id:
            The registry job id (already created in ``queued`` state).
        coro_factory:
            A no-arg callable that returns a coroutine to run the job.
        """
        if self._queue is None:
            raise RuntimeError("IndexJobQueue has not been started — call start() first")
        await self._queue.put((job_id, coro_factory))
        logger.debug("Enqueued job %d (queue depth now %d)", job_id, self._queue.qsize())

    # ------------------------------------------------------------------
    # Properties for health endpoint
    # ------------------------------------------------------------------

    @property
    def active_count(self) -> int:
        """Number of jobs currently executing."""
        return self._active

    @property
    def queued_count(self) -> int:
        """Number of jobs waiting in the queue."""
        if self._queue is None:
            return 0
        # qsize includes items being processed until task_done() is called;
        # subtract active to get truly waiting items.
        return max(0, self._queue.qsize() - self._active)

    # ------------------------------------------------------------------
    # Internal worker loop
    # ------------------------------------------------------------------

    async def _worker_loop(self) -> None:
        """Continuously pull jobs from the queue and execute them."""
        while self._running:
            try:
                job_id, coro_factory = await asyncio.wait_for(
                    self._queue.get(), timeout=1.0  # type: ignore[union-attr]
                )
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

            # Acquire the semaphore before spawning the task so we respect
            # max_concurrent.  We release it inside the spawned task.
            await self._semaphore.acquire()  # type: ignore[union-attr]
            self._active += 1
            asyncio.ensure_future(self._run_job(job_id, coro_factory))

    async def _run_job(
        self,
        job_id: int,
        coro_factory: Callable[[], Awaitable[None]],
    ) -> None:
        """Execute a single job and release the semaphore when done."""
        try:
            coro = coro_factory()
            await coro
        except Exception as exc:
            logger.error("Unhandled exception in job %d: %s", job_id, exc)
        finally:
            self._active -= 1
            self._semaphore.release()  # type: ignore[union-attr]
            if self._queue is not None:
                self._queue.task_done()
