"""Rate limiting middleware — sliding window, endpoint groups, auth brute-force protection.

Phase 1: in-memory sliding window per (identity, endpoint_group).
Phase 2: failure-weighted counter + per-endpoint overrides + IP lockout.
Phase 3: role-based tier resolution.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Endpoint group classification
# ---------------------------------------------------------------------------

_INDEX_SUFFIXES = ("/index", "/reindex")
_AUTH_PREFIX = "/api/auth"
_MCP_PATHS = {"/mcp", "/api/knowledge/mcp"}


def _classify_endpoint(method: str, path: str) -> str:
    """Return the rate-limit group for a request."""
    if path in _MCP_PATHS or path.startswith("/mcp/") or path.startswith("/api/knowledge/mcp"):
        return "mcp"
    if path.startswith(_AUTH_PREFIX):
        return "auth"
    if method in ("POST", "PUT", "PATCH", "DELETE") and any(path.endswith(s) for s in _INDEX_SUFFIXES):
        return "index"
    if method in ("POST", "PATCH", "DELETE"):
        return "write"
    return "read"


# ---------------------------------------------------------------------------
# Per-endpoint overrides (Phase 2 — tight limits on sensitive auth paths)
# ---------------------------------------------------------------------------

@dataclass
class _EndpointOverride:
    limit: int
    window: int  # seconds
    ip_keyed: bool = False  # True = ignore token, always key by IP


_ENDPOINT_OVERRIDES: dict[tuple[str, str], _EndpointOverride] = {
    ("POST", "/api/auth/admin/reset-token"): _EndpointOverride(3, 900, ip_keyed=True),
    ("POST", "/api/auth/tokens"): _EndpointOverride(10, 60),
    ("POST", "/api/auth/users"): _EndpointOverride(20, 60),
    ("DELETE", "/api/auth/tokens"): _EndpointOverride(30, 60),
}


def _get_endpoint_override(method: str, path: str) -> _EndpointOverride | None:
    override = _ENDPOINT_OVERRIDES.get((method, path))
    if override:
        return override
    # Prefix match for DELETE /api/auth/tokens/{id}
    if method == "DELETE" and path.startswith("/api/auth/tokens/"):
        return _ENDPOINT_OVERRIDES.get(("DELETE", "/api/auth/tokens"))
    return None


# ---------------------------------------------------------------------------
# Rate limit string parsing
# ---------------------------------------------------------------------------

_UNIT_SECS = {"sec": 1, "min": 60, "hour": 3600}


def parse_limit(spec: str) -> tuple[int, int]:
    """Parse '200/min' → (count, window_seconds)."""
    count_str, unit = spec.split("/")
    return int(count_str.strip()), _UNIT_SECS[unit.strip()]


# ---------------------------------------------------------------------------
# Sliding window counter
# ---------------------------------------------------------------------------

@dataclass
class _Window:
    limit: int
    window: int  # seconds
    _hits: Deque[float] = field(default_factory=deque)

    def add(self, weight: int = 1) -> None:
        now = time.monotonic()
        self._evict(now)
        for _ in range(weight):
            self._hits.append(now)

    def remaining(self) -> int:
        self._evict(time.monotonic())
        return max(0, self.limit - len(self._hits))

    def reset_at(self) -> float:
        """Unix timestamp when oldest hit expires."""
        if not self._hits:
            return time.time()
        oldest = self._hits[0]
        return time.time() + (oldest + self.window - time.monotonic())

    def is_exceeded(self) -> bool:
        self._evict(time.monotonic())
        return len(self._hits) >= self.limit

    def _evict(self, now: float) -> None:
        cutoff = now - self.window
        while self._hits and self._hits[0] < cutoff:
            self._hits.popleft()


# ---------------------------------------------------------------------------
# IP lockout tracker (Phase 2)
# ---------------------------------------------------------------------------

@dataclass
class _LockoutState:
    consecutive_429s: int = 0
    locked_until: float = 0.0

    def record_429(self, threshold: int, duration: int) -> None:
        self.consecutive_429s += 1
        if self.consecutive_429s >= threshold:
            self.locked_until = time.monotonic() + duration
            logger.warning("IP temporarily banned for %ds after %d consecutive 429s", duration, threshold)

    def is_locked(self) -> bool:
        return time.monotonic() < self.locked_until

    def reset(self) -> None:
        self.consecutive_429s = 0


# ---------------------------------------------------------------------------
# Tier resolution
# ---------------------------------------------------------------------------

TIER_ORDER = ["admin", "high", "standard", "restricted"]


def _most_permissive_tier(tiers: list[str]) -> str:
    """Return the most permissive (lowest index in TIER_ORDER) tier from a list."""
    if not tiers:
        return "standard"
    best_idx = len(TIER_ORDER)
    for t in tiers:
        try:
            idx = TIER_ORDER.index(t)
            best_idx = min(best_idx, idx)
        except ValueError:
            pass
    return TIER_ORDER[best_idx] if best_idx < len(TIER_ORDER) else "standard"


def _get_tier_limits(tier: str, group: str, cfg) -> tuple[int, int]:
    """Return (count, window_secs) for a tier + group using the loaded config."""
    tier_cfg = getattr(cfg.rate_limit.tiers, tier, None)
    if tier_cfg is None:
        tier_cfg = cfg.rate_limit.tiers.standard
    spec = getattr(tier_cfg, group, None) or getattr(cfg.rate_limit.limits, group, "1000/min")
    return parse_limit(spec)


# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding-window rate limiting middleware."""

    _EXEMPT_PATHS = {"/health", "/docs", "/openapi.json", "/redoc", "/metrics",
                     "/api/auth/oidc/config"}  # public pre-auth endpoint, must be rate-limit-free
    # Login path costs 1 hit on failure but must NOT get the 5x failure-weight penalty
    # (wrong passwords are expected; penalizing them blocks legitimate users quickly)
    _NO_FAILURE_WEIGHT_PATHS = {"/api/auth/login"}

    def __init__(self, app, **kwargs):
        super().__init__(app, **kwargs)
        # (identity, group) → _Window
        self._windows: dict[tuple[str, str], _Window] = {}
        # ip → _Window (for endpoint overrides)
        self._override_windows: dict[tuple[str, str, str], _Window] = {}
        # ip → _LockoutState
        self._lockouts: dict[str, _LockoutState] = {}

    def _get_window(self, key: tuple[str, str], limit: int, window: int) -> _Window:
        w = self._windows.get(key)
        if w is None or w.limit != limit or w.window != window:
            w = _Window(limit=limit, window=window)
            self._windows[key] = w
        return w

    def _get_override_window(self, key: tuple[str, str, str], override: _EndpointOverride) -> _Window:
        w = self._override_windows.get(key)
        if w is None:
            w = _Window(limit=override.limit, window=override.window)
            self._override_windows[key] = w
        return w

    def _lockout_for_ip(self, ip: str) -> _LockoutState:
        if ip not in self._lockouts:
            self._lockouts[ip] = _LockoutState()
        return self._lockouts[ip]

    def _client_ip(self, request: Request) -> str:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

    async def dispatch(self, request: Request, call_next):
        from ravmem.config_loader import get_config

        cfg = get_config()
        if not cfg.rate_limit.enabled:
            return await call_next(request)

        path = request.url.path
        if path in self._EXEMPT_PATHS:
            return await call_next(request)

        method = request.method
        client_ip = self._client_ip(request)
        lockout = self._lockout_for_ip(client_ip)

        # IP ban check
        if lockout.is_locked():
            return self._too_many(0, 60, cfg.rate_limit.lockout_duration)

        # Resolve identity and tier
        from ravmem.auth.context import get_auth_context
        auth_ctx = get_auth_context()
        if auth_ctx:
            identity = auth_ctx.user_id
            if auth_ctx.is_admin:
                tier = "admin"
            else:
                tier = self._resolve_user_tier(auth_ctx)
        else:
            identity = client_ip
            tier = "standard"

        # Check per-endpoint override first (Phase 2)
        override = _get_endpoint_override(method, path)
        if override:
            ov_identity = client_ip if override.ip_keyed else identity
            ov_key = (ov_identity, method, path)
            ov_window = self._get_override_window(ov_key, override)
            if ov_window.is_exceeded():
                remaining = ov_window.remaining()
                reset_at = int(ov_window.reset_at())
                lockout.record_429(cfg.rate_limit.lockout_threshold, cfg.rate_limit.lockout_duration)
                self._log_audit(path, ov_identity)
                return self._too_many(remaining, override.limit, reset_at)
            ov_window.add()

        # Standard sliding-window check
        group = _classify_endpoint(method, path)
        limit, window = _get_tier_limits(tier, group, cfg)
        win_key = (identity, group)
        window_obj = self._get_window(win_key, limit, window)

        if window_obj.is_exceeded():
            remaining = window_obj.remaining()
            reset_at = int(window_obj.reset_at())
            lockout.record_429(cfg.rate_limit.lockout_threshold, cfg.rate_limit.lockout_duration)
            if path.startswith(_AUTH_PREFIX):
                self._log_audit(path, identity)
            return self._too_many(remaining, limit, reset_at)

        lockout.reset()
        window_obj.add()

        response = await call_next(request)

        # Failure-weighted counter for auth endpoints (Phase 2)
        # Skip for login/OIDC paths — wrong credentials are expected and must not burn 5x the counter
        if (path.startswith(_AUTH_PREFIX)
                and path not in self._NO_FAILURE_WEIGHT_PATHS
                and response.status_code in (401, 403)):
            window_obj.add(weight=4)  # +5 total (1 already added above)

        # Inject rate-limit headers
        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(window_obj.remaining())
        response.headers["X-RateLimit-Reset"] = str(int(window_obj.reset_at()))
        return response

    def _resolve_user_tier(self, auth_ctx) -> str:
        """Look up role tiers from auth context roles (Phase 3)."""
        try:
            from ravmem.auth.service import get_role_tiers_for_user
            tiers = get_role_tiers_for_user(auth_ctx.user_id)
            return _most_permissive_tier(tiers)
        except Exception:
            return "standard"

    def _too_many(self, remaining: int, limit: int, reset_at: int) -> JSONResponse:
        retry_after = max(1, reset_at - int(time.time()))
        return JSONResponse(
            status_code=429,
            content={"detail": "Too many requests — rate limit exceeded."},
            headers={
                "Retry-After": str(retry_after),
                "X-RateLimit-Limit": str(limit),
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": str(reset_at),
            },
        )

    def _log_audit(self, path: str, actor: str) -> None:
        try:
            from ravmem.auth.audit import log
            log(actor=actor, action="ratelimit.blocked", target=path)
        except Exception:
            pass
