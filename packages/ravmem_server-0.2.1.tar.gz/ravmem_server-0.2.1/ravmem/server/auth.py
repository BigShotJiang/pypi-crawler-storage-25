"""Auth middleware — two-path token validation.

Path 1 (admin): SHA-256(token) compared in-memory — no DB, survives ArcadeDB outage.
Path 2 (users): SHA-256 lookup in ravmem_system ArcadeDB — 503 if unreachable.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os

import requests as _requests

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from ravmem.auth.context import AuthContext, set_auth_context

logger = logging.getLogger(__name__)

_EXEMPT_PATHS = {"/health", "/docs", "/openapi.json", "/redoc", "/api/auth/login",
                 "/api/auth/oidc/config", "/api/metrics"}  # public: needed by login page and Prometheus scrapers


class AuthMiddleware(BaseHTTPMiddleware):
    """Token validation middleware. Disabled when no admin hash is loaded."""

    async def dispatch(self, request: Request, call_next):
        from ravmem.auth.bootstrap import get_admin_hash

        admin_hash = get_admin_hash()

        # No hash means bootstrap did not set one (should not happen after startup).
        # Only bypass auth when RAVMEM_AUTH_DISABLED=true is explicitly set (dev mode).
        # Without that flag a missing hash is a server error, never a silent open door.
        if not admin_hash:
            if os.environ.get("RAVMEM_AUTH_DISABLED", "").lower() in ("1", "true", "yes"):
                return await call_next(request)
            return JSONResponse(
                status_code=503,
                content={"detail": "Auth service not initialized — server startup incomplete"},
            )

        if request.url.path in _EXEMPT_PATHS:
            return await call_next(request)

        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return JSONResponse(
                status_code=401,
                content={"detail": "Missing or malformed Authorization header"},
            )

        token = auth[7:]
        token_hash = hashlib.sha256(token.encode()).hexdigest()

        # --- Path 1: admin token (in-memory) ---
        if token_hash == admin_hash:
            set_auth_context(AuthContext(user_id="admin", is_admin=True))
            return await call_next(request)

        # --- Path 2: user tokens via ravmem_system ArcadeDB ---
        from ravmem.auth.service import lookup_token, update_last_used

        try:
            tok = await asyncio.to_thread(lookup_token, token_hash)
        except (_requests.ConnectionError, _requests.Timeout):
            return JSONResponse(
                status_code=503,
                content={"detail": "Auth service unavailable — ArcadeDB unreachable"},
            )
        except Exception as exc:
            logger.error("Token lookup error: %s", exc)
            return JSONResponse(
                status_code=503,
                content={"detail": "Auth service error"},
            )

        if tok is None:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or missing API key"},
            )

        from ravmem.auth.rbac import resolve_user_permissions
        permissions = await asyncio.to_thread(resolve_user_permissions, tok["user_id"])
        set_auth_context(AuthContext(user_id=tok["user_id"], permissions=permissions, is_admin=False))

        # Fire-and-forget last_used_at update (throttled to 15 min in service).
        asyncio.create_task(
            asyncio.to_thread(update_last_used, tok["id"], token_hash)
        )

        return await call_next(request)


# Backwards-compat alias so existing imports keep working.
ApiKeyMiddleware = AuthMiddleware
