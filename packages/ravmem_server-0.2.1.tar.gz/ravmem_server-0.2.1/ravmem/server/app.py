"""FastAPI application factory — wires storage, engine, and routes together."""

from __future__ import annotations

import json
import logging
import time
from contextlib import asynccontextmanager
from functools import lru_cache
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI

logger = logging.getLogger(__name__)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from ravmem.config import BM25_INDEX_NAME, GRAPH_SUBDIR, INDEX_DIR, META_DB_NAME, VECTORS_SUBDIR
from ravmem.engine.context import ContextEngine
from ravmem.engine.impact import ImpactEngine
from ravmem.engine.ranking import compute_centrality
from ravmem.engine.search import SearchEngine
from ravmem.storage.graph_arcade import ArcadeGraphStore as _GraphStoreImpl
from ravmem.storage.meta import MetaStore
from ravmem.storage.vectors import VectorStore


# ---------------------------------------------------------------------------
# Dependency: per-repo engine bundle
# ---------------------------------------------------------------------------

class RepoEngines:
    """Holds all storage + engine instances for a single repo branch."""

    def __init__(
        self,
        repo_path: Path,
        read_only: bool = False,
        index_dir: Path | None = None,
        repo_id: str | None = None,
        branch: str | None = None,
        parent_branch: str | None = None,
    ) -> None:
        self.repo_path = repo_path
        idx = index_dir or (repo_path / INDEX_DIR)
        self.index_dir = idx

        _branch = branch or "main"
        rid = repo_id or repo_path.name
        self.graph = _GraphStoreImpl(_branch, parent_branch, project_id=rid)
        self.graph.initialize_schema()

        self.vectors = VectorStore(idx / VECTORS_SUBDIR)
        self.vectors.initialize()

        self.meta = MetaStore(idx / META_DB_NAME)
        centrality = compute_centrality(self.graph, self.meta, rid)

        self.search_engine = SearchEngine(
            self.vectors,
            bm25_path=idx / BM25_INDEX_NAME,
            centrality=centrality,
        )
        self.impact_engine = ImpactEngine(self.graph)
        self.context_engine = ContextEngine(
            self.graph, self.search_engine, self.impact_engine
        )

    def close(self) -> None:
        """Release all storage connections so file locks are freed."""
        try:
            self.graph.close()
        except Exception:
            pass
        try:
            self.vectors.close()
        except Exception:
            pass
        try:
            self.meta.close()
        except Exception:
            pass


# Global registry — keyed by (project_id, branch) or legacy repo_path string
_engines: dict[str | tuple[str, str], RepoEngines] = {}
_engines_readonly: dict[str | tuple[str, str], RepoEngines] = {}


def get_repo_engines(repo_path: str) -> RepoEngines:
    """Get or create a writable RepoEngines for a legacy repo_path key."""
    if repo_path not in _engines:
        logger.info("Initializing engines for repo: %s", repo_path)
        _engines[repo_path] = RepoEngines(Path(repo_path))
    return _engines[repo_path]


def get_repo_engines_readonly(repo_path: str) -> RepoEngines:
    """Return a read-only RepoEngines instance — safe to use alongside the HTTP server."""
    if repo_path not in _engines_readonly:
        logger.info("Initializing read-only engines for repo: %s", repo_path)
        _engines_readonly[repo_path] = RepoEngines(Path(repo_path), read_only=True)
    return _engines_readonly[repo_path]


def get_branch_engines(
    project_id: str,
    branch: str,
    repo_path: Path,
    index_dir: Path,
    read_only: bool = True,
    parent_branch: str | None = None,
) -> RepoEngines:
    """Get or create RepoEngines for a specific project branch."""
    key = (project_id, branch)
    cache = _engines_readonly if read_only else _engines
    if key not in cache:
        logger.info("Initializing engines for %s/%s at %s", project_id, branch, index_dir)
        cache[key] = RepoEngines(
            repo_path,
            read_only=read_only,
            index_dir=index_dir,
            repo_id=project_id,
            branch=branch,
            parent_branch=parent_branch,
        )
    return cache[key]


def invalidate_engines(project_id: str, branch: str) -> None:
    """Close and remove cached engines for a branch so file locks are freed."""
    key = (project_id, branch)
    for cache in (_engines, _engines_readonly):
        eng = cache.pop(key, None)
        if eng is not None:
            eng.close()


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def _bootstrap_knowledge_schema() -> None:
    """Apply ArcadeDB knowledge graph schema on server startup.

    Non-fatal: logs a warning if ArcadeDB is unreachable so the codegraph
    side of the server keeps running normally.
    """
    try:
        from ravmem.knowledge.schema.apply_schema import apply_schema
        apply_schema(verbose=False)
        logger.info("Knowledge graph schema ready (ArcadeDB)")
    except Exception as exc:
        logger.warning(
            "Knowledge graph schema bootstrap failed — "
            "KG endpoints will be unavailable until ArcadeDB is reachable: %s",
            exc,
        )


def _bootstrap_auth_schema() -> None:
    """Bootstrap ravmem_system DB, resolve admin token, and clean up old audit entries."""
    from ravmem.config import RAVMEM_SYSTEM_DB
    from ravmem.auth.bootstrap import bootstrap
    from ravmem.auth.audit import cleanup_old_entries
    bootstrap(RAVMEM_SYSTEM_DB)
    cleanup_old_entries()


def create_app(repos_dir: Path | None = None, data_dir: Path | None = None) -> FastAPI:
    from ravmem.config import SERVER_DATA_DIR
    from ravmem.server.auth import AuthMiddleware
    from ravmem.server.branch_manager import BranchManager
    from ravmem.server.job_queue import IndexJobQueue
    from ravmem.server.registry import ServerRegistry

    effective_data_dir = data_dir or SERVER_DATA_DIR
    effective_data_dir.mkdir(parents=True, exist_ok=True)

    registry = ServerRegistry(effective_data_dir / "server.db")
    job_queue = IndexJobQueue(registry)
    branch_mgr = BranchManager(effective_data_dir, registry, job_queue=job_queue)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await job_queue.start()
        _bootstrap_auth_schema()
        _bootstrap_knowledge_schema()
        yield
        await job_queue.stop()

    app = FastAPI(
        title="RavMem",
        description="Code knowledge graph engine — REST + MCP API",
        version="0.2.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(AuthMiddleware)

    from ravmem.server.rate_limit import RateLimitMiddleware
    app.add_middleware(RateLimitMiddleware)

    # Set state synchronously so it's available before lifespan runs
    app.state.start_time = time.monotonic()
    app.state.repos_dir = repos_dir
    app.state.registry = registry
    app.state.branch_manager = branch_mgr
    app.state.data_dir = effective_data_dir
    app.state.job_queue = job_queue

    # Import and include routers
    from ravmem.server.routes_api import router as api_router
    from ravmem.server.routes_auth import router as auth_router
    from ravmem.server.routes_mcp import router as mcp_router
    from ravmem.server.routes_ws import router as ws_router
    from ravmem.knowledge.routes import router as kg_router
    from ravmem.knowledge.mcp_tools import router as kg_mcp_router

    app.include_router(api_router, prefix="/api")
    app.include_router(auth_router)
    app.include_router(mcp_router)
    app.include_router(ws_router)
    app.include_router(kg_router)
    app.include_router(kg_mcp_router)

    # Serve static console (if bundled)
    console_dir = Path(__file__).parent / "console"
    if console_dir.exists():
        app.mount("/", StaticFiles(directory=str(console_dir), html=True), name="console")

    @app.get("/health", tags=["meta"])
    async def health():
        try:
            uptime = round(time.monotonic() - app.state.start_time, 1)
            return {
                "status": "ok",
                "version": "0.2.0",
                "uptime_seconds": uptime,
                "projects_count": registry.count_projects(),
                "active_jobs": registry.count_active_jobs(),
                "queued_jobs": registry.count_queued_jobs(),
            }
        except Exception:
            return {
                "status": "degraded",
                "version": "0.2.0",
            }

    return app
