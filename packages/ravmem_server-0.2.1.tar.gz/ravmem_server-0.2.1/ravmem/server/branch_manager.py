"""Branch-aware indexing orchestration.

Manages per-branch index directories, decides between incremental and full
reindex, and implements the "copy closest branch + incremental" optimisation
for new branches.
"""

from __future__ import annotations

import asyncio
import base64
import gc
import logging
import os
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from ravmem.indexer.pipeline import IndexPipeline, PipelineConfig
from ravmem.server import git_ops
from ravmem.server.registry import ServerRegistry

if TYPE_CHECKING:
    from ravmem.server.job_queue import IndexJobQueue

logger = logging.getLogger(__name__)

# Divergence thresholds for deciding incremental vs full reindex
_DIVERGENCE_INCREMENTAL_MAX = 0.30   # <= 30% changed → incremental
_DIVERGENCE_FULL_MIN = 0.60          # > 60% changed → full reindex

# Thread pool for CPU-bound indexing work (avoids blocking the event loop)
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="index")

# Upload size limits (configurable via env vars)
_MAX_FILE_BYTES = int(os.environ.get("RAVMEM_MAX_FILE_SIZE_MB", "5")) * 1024 * 1024
_MAX_BATCH_BYTES = int(os.environ.get("RAVMEM_MAX_BATCH_SIZE_MB", "50")) * 1024 * 1024
_MAX_WORKSPACE_BYTES = int(os.environ.get("RAVMEM_MAX_WORKSPACE_SIZE_GB", "2")) * 1024 * 1024 * 1024

# Sentinel filename written to workspace root so _execute_index can record
# the client HEAD SHA for upload-mode projects (which have no .git/).
_HEAD_SENTINEL = ".ravmem_head"


@dataclass
class _UploadSession:
    staging_dir: Path
    branch: str
    parent_branch: str | None
    to_commit: str
    batch_total: int
    langs: list[str] | None
    mode: str = "full"
    deleted_paths: list[str] = field(default_factory=list)
    batches_received: int = 0
    files_written: int = 0


def _sanitize_branch(branch: str) -> str:
    """Make a branch name safe for use as a directory name."""
    return branch.replace("/", "__").replace("\\", "__")


def _promote_staging_dir(staging_dir: Path, index_dir: Path) -> None:
    """Atomically replace *index_dir* with *staging_dir*.

    On Windows, ``os.rename`` fails if the destination exists, and file locks
    held by ArcadeDB/usearch can persist briefly after ``close()`` due to
    deferred GC.  This helper:

    1. Moves the current *index_dir* to a ``*.old`` sibling (or removes it if
       that also fails due to locks — it only contains the previous index).
    2. Renames *staging_dir* → *index_dir* with up to 5 retries + back-off.
    """
    _IS_WINDOWS = sys.platform == "win32"
    _MAX_RETRIES = 5 if _IS_WINDOWS else 1
    _RETRY_DELAY = 0.5  # seconds

    # Remove or stash the existing index directory first.
    if index_dir.exists():
        old_dir = index_dir.parent / (index_dir.name + ".old")
        if old_dir.exists():
            shutil.rmtree(old_dir, ignore_errors=True)
        for attempt in range(_MAX_RETRIES):
            try:
                shutil.move(str(index_dir), str(old_dir))
                break
            except (OSError, shutil.Error):
                if attempt < _MAX_RETRIES - 1:
                    gc.collect()
                    time.sleep(_RETRY_DELAY)
                else:
                    # Last resort: wipe it in-place so the rename below can proceed.
                    shutil.rmtree(str(index_dir), ignore_errors=True)

    # Rename staging → index.
    for attempt in range(_MAX_RETRIES):
        try:
            os.rename(str(staging_dir), str(index_dir))
            break
        except OSError:
            if attempt < _MAX_RETRIES - 1:
                gc.collect()
                time.sleep(_RETRY_DELAY)
            else:
                # Fallback: copy then remove source.
                shutil.copytree(str(staging_dir), str(index_dir))
                shutil.rmtree(str(staging_dir), ignore_errors=True)

    # Clean up stash.
    old_dir = index_dir.parent / (index_dir.name + ".old")
    shutil.rmtree(str(old_dir), ignore_errors=True)


class BranchManager:
    """Orchestrates branch-aware indexing for all registered projects."""

    def __init__(
        self,
        data_dir: Path,
        registry: ServerRegistry,
        job_queue: IndexJobQueue | None = None,
    ) -> None:
        self._data_dir = data_dir
        self._registry = registry
        self._job_queue = job_queue
        # Per-project lock to serialise git operations (checkout)
        self._locks: dict[str, asyncio.Lock] = {}
        # Active upload sessions: (project_id, branch) → _UploadSession
        self._upload_sessions: dict[tuple[str, str], _UploadSession] = {}

    def _lock_for(self, project_id: str) -> asyncio.Lock:
        if project_id not in self._locks:
            self._locks[project_id] = asyncio.Lock()
        return self._locks[project_id]

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def project_dir(self, project_id: str) -> Path:
        return self._data_dir / "repos" / project_id

    def repo_path(self, project_id: str) -> Path:
        """Return the path to the source checkout for a project."""
        project = self._registry.get_project(project_id)
        if project:
            return Path(project["repo_path"])
        return self.project_dir(project_id) / "repo"

    def branch_index_dir(self, project_id: str, branch: str) -> Path:
        return self.project_dir(project_id) / "branches" / _sanitize_branch(branch)

    # ------------------------------------------------------------------
    # Divergence detection
    # ------------------------------------------------------------------

    def compute_divergence(
        self,
        project_id: str,
        branch: str,
        base_branch: str | None = None,
    ) -> dict:
        """Compute how much *branch* has diverged from *base_branch* (or its own last index).

        Returns::

            {
                "changed_files": int,
                "total_files": int,
                "ratio": float,
                "recommend": "skip" | "incremental" | "full",
                "force_push": bool,
                "parent_branch": str | None,
                "parent_behind": bool,
            }

        ``parent_behind`` is True when this is a new branch (copy-from-base path)
        and the parent branch's index is stale — its last indexed commit does not
        match the parent's current workspace HEAD.  The CLI uses this to warn the
        user before proceeding with an incremental index built on a stale baseline.
        """
        repo = self.repo_path(project_id)
        branch_rec = self._registry.get_branch(project_id, branch)

        # If this branch has never been indexed, compare against base_branch
        if branch_rec is None or branch_rec["status"] == "empty":
            return self._divergence_vs_base(project_id, branch, base_branch)

        last_commit = branch_rec["last_commit"]
        if not last_commit:
            return {
                "changed_files": 0, "total_files": 0, "ratio": 1.0,
                "recommend": "full", "force_push": False,
                "parent_branch": None, "parent_behind": False,
            }

        try:
            current_head = git_ops.get_head_commit(repo, branch)
        except git_ops.GitError:
            return {
                "changed_files": 0, "total_files": 0, "ratio": 1.0,
                "recommend": "full", "force_push": False,
                "parent_branch": None, "parent_behind": False,
            }

        if last_commit == current_head:
            return {
                "changed_files": 0, "total_files": 0, "ratio": 0.0,
                "recommend": "skip", "force_push": False,
                "parent_branch": None, "parent_behind": False,
            }

        # Detect force-push / rebase (last_commit is no longer an ancestor)
        force_push = not git_ops.is_ancestor(repo, last_commit, current_head)

        if force_push:
            return {
                "changed_files": 0, "total_files": branch_rec["symbol_count"],
                "ratio": 1.0, "recommend": "full", "force_push": True,
                "parent_branch": None, "parent_behind": False,
            }

        modified, deleted = git_ops.diff_name_status(repo, last_commit, current_head)
        changed_count = len(modified) + len(deleted)
        total = max(branch_rec["symbol_count"], 1)
        ratio = changed_count / total

        if ratio <= _DIVERGENCE_INCREMENTAL_MAX:
            rec = "incremental"
        elif ratio > _DIVERGENCE_FULL_MIN:
            rec = "full"
        else:
            rec = "incremental"  # middle range defaults to incremental

        return {
            "changed_files": changed_count,
            "total_files": total,
            "ratio": ratio,
            "recommend": rec,
            "force_push": False,
            "parent_branch": None,
            "parent_behind": False,
        }

    def _divergence_vs_base(
        self, project_id: str, branch: str, base_branch: str | None,
    ) -> dict:
        """Compute divergence of an unindexed branch vs the closest indexed branch."""
        project = self._registry.get_project(project_id)
        base = base_branch or (project["default_branch"] if project else "main")
        repo = self.repo_path(project_id)

        base_rec = self._registry.get_branch(project_id, base)
        if not base_rec or base_rec["status"] != "ready":
            # No base to compare against → must do full
            return {
                "changed_files": 0, "total_files": 0, "ratio": 1.0,
                "recommend": "full", "force_push": False,
                "parent_branch": base, "parent_behind": False,
            }

        # Phase 12: check whether the parent branch index is current.
        # If it is stale, an incremental copy-from-base will build on an outdated
        # baseline — warn the CLI so it can prompt the user.
        parent_behind = False
        parent_last = base_rec.get("last_commit", "")
        if parent_last and git_ops.is_git_repo(repo):
            try:
                parent_head = git_ops.get_head_commit(repo, base)
                parent_behind = parent_last != parent_head
            except git_ops.GitError:
                pass  # best-effort; don't block if we can't read HEAD

        try:
            merge_base = git_ops.get_merge_base(repo, base, branch)
            modified, deleted = git_ops.diff_name_status(repo, merge_base, branch)
        except git_ops.GitError:
            return {
                "changed_files": 0, "total_files": 0, "ratio": 1.0,
                "recommend": "full", "force_push": False,
                "parent_branch": base, "parent_behind": parent_behind,
            }

        changed_count = len(modified) + len(deleted)
        total = max(base_rec["symbol_count"], 1)
        ratio = changed_count / total

        if ratio <= _DIVERGENCE_INCREMENTAL_MAX:
            rec = "incremental"
        elif ratio > _DIVERGENCE_FULL_MIN:
            rec = "full"
        else:
            rec = "incremental"

        return {
            "changed_files": changed_count,
            "total_files": total,
            "ratio": ratio,
            "recommend": rec,
            "force_push": False,
            "parent_branch": base,
            "parent_behind": parent_behind,
        }

    # ------------------------------------------------------------------
    # Index orchestration
    # ------------------------------------------------------------------

    async def index_branch(
        self,
        project_id: str,
        branch: str,
        mode: str = "auto",
        langs: list[str] | None = None,
        auto_sync: bool = True,
    ) -> int:
        """Index a branch. Returns the server-level job_id.

        *mode* can be ``"full"``, ``"incremental"``, or ``"auto"``
        (auto uses divergence detection to decide).
        *auto_sync* controls whether clone-mode workspaces are synced (git fetch)
        before indexing — set to False when the caller just cloned the repo.
        """
        # Prevent duplicate jobs
        existing = self._registry.get_active_job(project_id, branch)
        if existing:
            return existing["id"]

        project = self._registry.get_project(project_id)
        if not project:
            raise ValueError(f"Unknown project: {project_id}")

        index_dir = self.branch_index_dir(project_id, branch)
        index_dir.mkdir(parents=True, exist_ok=True)
        parent_branch = project["default_branch"] if project else None
        self._registry.register_branch(project_id, branch, str(index_dir), parent_branch=parent_branch)

        # Decide mode
        if mode == "auto":
            div = self.compute_divergence(project_id, branch)
            mode = div["recommend"]
            if mode == "skip":
                logger.info("Branch %s/%s is up to date — skipping", project_id, branch)
                # Still create a job record so the caller gets a job_id
                job_id = self._registry.create_job(project_id, branch, "incremental")
                self._registry.update_job(job_id, status="done")
                return job_id

        job_id = self._registry.create_job(project_id, branch, mode)
        self._registry.update_branch_status(project_id, branch, status="indexing")

        # Copy-from-base optimisation for new branches
        branch_rec = self._registry.get_branch(project_id, branch)
        if mode == "incremental" and (
            branch_rec is None or branch_rec["status"] in ("empty", "indexing")
        ):
            self._maybe_copy_base_index(project_id, branch)
            # After copy the mode stays incremental — the pipeline will diff from
            # the copied branch's last_commit

        # Run indexing in a background thread (CPU-bound)
        import functools
        loop = asyncio.get_event_loop()
        lock = self._lock_for(project_id)

        async def _run() -> None:
            async with lock:
                fn = functools.partial(
                    self._execute_index,
                    project_id, branch, index_dir, mode, job_id, langs, auto_sync,
                )
                await loop.run_in_executor(_executor, fn)

        if self._job_queue is not None:
            await self._job_queue.enqueue(job_id, _run)
        else:
            asyncio.ensure_future(_run())
        return job_id

    # ------------------------------------------------------------------
    # Upload-based indexing (CLI pushes files in batches)
    # ------------------------------------------------------------------

    async def receive_upload_batch(
        self,
        project_id: str,
        body: "UploadBatch",
    ) -> dict:
        """Accept one file batch from the CLI.

        Returns ``{"pending": true, "batch_index": N}`` for intermediate batches
        and ``{"job_id": N}`` after the final batch triggers the pipeline.
        """
        from ravmem.server.models import UploadBatch  # local import to avoid circular

        session_key = (project_id, body.branch)

        # --- First batch: create session and staging dir ---
        if body.batch_index == 1:
            if session_key in self._upload_sessions:
                existing = self._upload_sessions[session_key]
                raise ValueError(
                    f"Upload already in progress for {project_id}/{body.branch} "
                    f"({existing.batches_received}/{existing.batch_total} batches received). "
                    "Wait for it to complete or call reset-workspace to cancel."
                )
            project = self._registry.get_project(project_id)
            if not project:
                raise ValueError(f"Unknown project: {project_id}")

            staging_dir = (
                self.project_dir(project_id)
                / f"workspace.upload.{_sanitize_branch(body.branch)}"
            )
            if staging_dir.exists():
                shutil.rmtree(staging_dir)

            if body.mode == "incremental":
                # Seed staging from the existing workspace so we only need to
                # apply the delta.  Fall back to full if no workspace exists yet.
                current_workspace = self.repo_path(project_id)
                if current_workspace.exists():
                    shutil.copytree(str(current_workspace), str(staging_dir))
                    # Remove the old head sentinel if present — we'll write the new one
                    (staging_dir / _HEAD_SENTINEL).unlink(missing_ok=True)
                else:
                    staging_dir.mkdir(parents=True, exist_ok=True)
                    logger.info(
                        "No existing workspace for %s — falling back to full upload", project_id
                    )
            else:
                staging_dir.mkdir(parents=True, exist_ok=True)

            self._upload_sessions[session_key] = _UploadSession(
                staging_dir=staging_dir,
                branch=body.branch,
                parent_branch=body.parent_branch,
                to_commit=body.to_commit,
                batch_total=body.batch_total,
                langs=body.langs,
                mode=body.mode,
            )

        session = self._upload_sessions.get(session_key)
        if session is None:
            raise ValueError(
                f"No upload session for {project_id}/{body.branch}. "
                "Re-send from batch_index=1."
            )

        # --- Write this batch's files to staging ---
        try:
            batch_bytes = 0
            for upload_file in body.files:
                try:
                    raw = base64.b64decode(upload_file.content)
                except Exception as exc:
                    raise ValueError(
                        f"Invalid base64 for {upload_file.path}: {exc}"
                    ) from exc

                if len(raw) > _MAX_FILE_BYTES:
                    logger.warning(
                        "Skipping %s — size %d MB exceeds limit %d MB",
                        upload_file.path,
                        len(raw) // (1024 * 1024),
                        _MAX_FILE_BYTES // (1024 * 1024),
                    )
                    continue

                batch_bytes += len(raw)
                if batch_bytes > _MAX_BATCH_BYTES:
                    raise ValueError(
                        f"Batch payload exceeds {_MAX_BATCH_BYTES // (1024*1024)} MB limit."
                    )

                # Security: normalise path and prevent directory traversal
                safe_rel = Path(upload_file.path.lstrip("/").replace("..", ""))
                dest = session.staging_dir / safe_rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(raw)
                session.files_written += 1

            # Accumulate deleted paths across batches (typically sent in batch 1)
            session.deleted_paths.extend(body.deleted_paths)

            session.batches_received += 1

        except Exception:
            # Clean up staging dir and drop the session on any write error
            self._upload_sessions.pop(session_key, None)
            if session.staging_dir.exists():
                shutil.rmtree(session.staging_dir, ignore_errors=True)
            raise

        # --- Last batch: promote workspace and enqueue pipeline ---
        if session.batches_received == session.batch_total:
            self._upload_sessions.pop(session_key, None)

            workspace = self.repo_path(project_id)

            # Incremental: remove deleted files from staging before promoting
            for del_path in session.deleted_paths:
                safe_rel = Path(del_path.lstrip("/").replace("..", ""))
                target = session.staging_dir / safe_rel
                if target.is_file():
                    target.unlink(missing_ok=True)

            # Enforce total workspace size limit before promoting
            staging_size = sum(
                f.stat().st_size
                for f in session.staging_dir.rglob("*")
                if f.is_file()
            )
            if staging_size > _MAX_WORKSPACE_BYTES:
                shutil.rmtree(session.staging_dir, ignore_errors=True)
                raise ValueError(
                    f"Workspace would exceed {_MAX_WORKSPACE_BYTES // (1024**3)} GB limit "
                    f"({staging_size // (1024**3)} GB uploaded)."
                )

            # Write sentinel so _execute_index can record the client HEAD SHA
            if session.to_commit:
                (session.staging_dir / _HEAD_SENTINEL).write_text(session.to_commit)

            _promote_staging_dir(session.staging_dir, workspace)
            logger.info(
                "Upload complete for %s/%s — %d files written, %d deleted, mode=%s",
                project_id, body.branch, session.files_written,
                len(session.deleted_paths), session.mode,
            )

            pipeline_mode = session.mode  # "full" or "incremental"
            job_id = await self.index_branch(
                project_id,
                body.branch,
                mode=pipeline_mode,
                langs=session.langs,
            )
            return {"job_id": job_id}

        return {"pending": True, "batch_index": body.batch_index, "batch_total": body.batch_total}

    def _clone_workspace(self, project_id: str, workspace: Path) -> None:
        """Git-clone the project's remote repo into *workspace*.

        Reads the git_url from the registry and credentials from
        ``CredentialStore`` when available (private repos).
        """
        from ravmem.server.credentials import CredentialStore

        project = self._registry.get_project(project_id)
        if not project:
            raise ValueError(f"Unknown project: {project_id}")

        git_url = project.get("git_url") or ""
        if not git_url:
            raise ValueError(
                f"Project {project_id} has no git_url — cannot clone. "
                "Re-register with `remote add --git-url <URL>`."
            )

        cred_store = CredentialStore(self.project_dir(project_id))
        if cred_store.exists():
            creds = cred_store.load()
            git_ops.clone_with_credentials(
                git_url, workspace,
                username=creds["git_username"],
                token=creds["git_token"],
            )
        else:
            git_ops.clone_repo(git_url, workspace)

        logger.info("Cloned %s → %s", git_url, workspace)

    def sync_project_workspace(self, project_id: str) -> dict:
        """Fetch remote changes for a clone-mode project's workspace.

        Only valid for clone-mode projects that have an existing git workspace.
        Returns the dict produced by ``git_ops.sync_workspace``:
        ``{synced, fetched_branches, fetched_commits, workspace_head, duration_ms}``.
        """
        from ravmem.server.credentials import CredentialStore

        project = self._registry.get_project(project_id)
        if not project:
            raise ValueError(f"Unknown project: {project_id}")
        if project.get("index_mode") != "clone":
            raise ValueError(
                f"Project '{project_id}' uses index_mode={project.get('index_mode')!r}. "
                "Workspace sync is only available for clone-mode projects."
            )
        workspace = Path(project["repo_path"])
        if not git_ops.is_git_repo(workspace):
            raise ValueError(
                f"Workspace for '{project_id}' has not been cloned yet. "
                "Run `ravmem remote clone --project <id>` or `ravmem analyze` first."
            )

        cred_store = CredentialStore(self.project_dir(project_id))
        return git_ops.sync_workspace(
            workspace,
            cred_store=cred_store if cred_store.exists() else None,
        )

    def reset_workspace(self, project_id: str) -> dict:
        """Delete the server-side workspace for a clone or upload project.

        Removes the workspace directory and any in-flight upload staging dirs,
        then marks all branch records as "empty" so fresh indexing can proceed.
        Returns ``{reset: True, removed_workspace: bool, branches_cleared: int}``.

        Raises ``ValueError`` for mount-mode projects (nothing to reset).
        """
        project = self._registry.get_project(project_id)
        if not project:
            raise ValueError(f"Unknown project: {project_id}")
        index_mode = project.get("index_mode") or "upload"
        if index_mode == "mount":
            raise ValueError(
                f"Project '{project_id}' uses mount mode — the workspace is managed "
                "externally and cannot be reset from ravmem."
            )

        # Cancel any in-flight upload sessions for this project
        to_remove = [k for k in self._upload_sessions if k[0] == project_id]
        for key in to_remove:
            session = self._upload_sessions.pop(key)
            try:
                shutil.rmtree(session.staging_dir, ignore_errors=True)
            except Exception:
                pass

        # Remove the workspace directory (clone workspace or upload workspace)
        workspace = Path(project["repo_path"])
        removed = False
        if workspace.exists():
            shutil.rmtree(workspace, ignore_errors=True)
            removed = True

        # Also wipe any leftover staging/upload dirs under the project dir
        proj_dir = self.project_dir(project_id)
        if proj_dir.exists():
            for child in list(proj_dir.iterdir()):
                if child.name.startswith("workspace.") and child.is_dir():
                    shutil.rmtree(child, ignore_errors=True)

        # Reset all branch records to "empty" so the next analyze starts fresh
        branches = self._registry.list_branches(project_id)
        for b in branches:
            self._registry.update_branch_status(project_id, b["branch"], status="empty")
        branches_cleared = len(branches)

        logger.info(
            "Workspace reset for project %s — removed=%s, branches_cleared=%d",
            project_id, removed, branches_cleared,
        )
        return {"reset": True, "removed_workspace": removed, "branches_cleared": branches_cleared}

    async def clone_and_index(
        self,
        project_id: str,
        branch: str,
        langs: list[str] | None = None,
    ) -> int:
        """Clone the remote repo (if needed) then index *branch*.

        Returns the server-level job_id.  Safe to call when the workspace
        already exists — clone is skipped and indexing proceeds normally.
        """
        project = self._registry.get_project(project_id)
        if not project:
            raise ValueError(f"Unknown project: {project_id}")
        workspace = Path(project["repo_path"])
        if not git_ops.is_git_repo(workspace):
            # Clone is a blocking operation; run it in the thread pool so we
            # don't stall the event loop during the initial setup.
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(_executor, self._clone_workspace, project_id, workspace)
        return await self.index_branch(project_id, branch, mode="full", langs=langs, auto_sync=False)

    def _sync_clone_workspace(
        self, project_id: str, workspace: Path, branch: str, current_mode: str,
    ) -> str:
        """Fetch remote changes for a clone-mode workspace.

        Returns the effective mode to use for indexing:
        - ``"incremental"`` — fetch succeeded, no force-push detected.
        - ``"full"`` — force-push detected, or workspace was re-cloned (fresh state).

        On unrecoverable fetch failure raises ``GitError``.
        """
        from ravmem.server.credentials import CredentialStore

        try:
            cred_store = CredentialStore(self.project_dir(project_id))
            if cred_store.exists():
                creds = cred_store.load()
                git_ops.fetch_with_credentials(
                    workspace,
                    username=creds["git_username"],
                    token=creds["git_token"],
                )
            else:
                git_ops.fetch(workspace)
        except git_ops.GitError as exc:
            logger.warning(
                "git fetch failed for %s — attempting re-clone: %s", project_id, exc
            )
            try:
                shutil.rmtree(workspace, ignore_errors=True)
                self._clone_workspace(project_id, workspace)
                logger.info("Re-clone succeeded for %s", project_id)
                return "full"
            except Exception as reclone_exc:
                raise git_ops.GitError(
                    f"git fetch failed and re-clone also failed for {project_id}: {reclone_exc}"
                ) from reclone_exc

        # Detect force-push: if last indexed commit is no longer an ancestor of
        # the remote branch tip, the history was rewritten — must do full reindex.
        if current_mode == "incremental":
            branch_rec = self._registry.get_branch(project_id, branch)
            last_commit = (branch_rec or {}).get("last_commit", "")
            if last_commit:
                try:
                    remote_ref = f"origin/{branch}"
                    remote_tip = git_ops.get_head_commit(workspace, remote_ref)
                    if not git_ops.is_ancestor(workspace, last_commit, remote_tip):
                        logger.info(
                            "Force-push detected on %s/%s — switching to full reindex",
                            project_id, branch,
                        )
                        return "full"
                except git_ops.GitError:
                    pass  # can't verify ancestry — keep original mode

        return current_mode

    def _maybe_copy_base_index(self, project_id: str, branch: str) -> None:
        """Prepare a new branch for incremental indexing.

        For KuzuDB: copies the default branch's on-disk index directory.
        For ArcadeDB: no file copying needed — the shared single database
        already contains the parent branch's data. Just record the parent
        relationship so the graph store knows which branch to fall back to
        on CoW reads.
        """
        project = self._registry.get_project(project_id)
        if not project:
            return
        base = project["default_branch"]
        base_rec = self._registry.get_branch(project_id, base)
        if not base_rec or base_rec["status"] != "ready":
            return

        # ArcadeDB: single shared database — no file copy required.
        # Record parent_branch in the registry so CoW reads can fall back.
        self._register_branch_parent(project_id, branch, base)
        logger.info(
            "ArcadeDB: registered branch parent %s/%s → %s (no file copy needed)",
            project_id, branch, base,
        )

    def _register_branch_parent(self, project_id: str, branch: str, parent_branch: str) -> None:
        """Ensure the branch index directory exists for ArcadeDB new-branch setup.

        The registry entry (including parent_branch) is already written by
        index_branch() before this method is called — this just creates the
        on-disk directory so the pipeline has a place to write meta.db / bm25.json.
        """
        dst = self.branch_index_dir(project_id, branch)
        dst.mkdir(parents=True, exist_ok=True)

    def _execute_index(
        self,
        project_id: str,
        branch: str,
        index_dir: Path,
        mode: str,
        job_id: int,
        langs: list[str] | None,
        auto_sync: bool = True,
    ) -> None:
        """Blocking function that runs the indexing pipeline (called in thread pool).

        For ``mode == "full"``, writes to a staging directory first, then
        atomically renames it over ``index_dir`` on success.  This keeps the
        existing index readable for queries throughout the reindex.
        """
        repo = self.repo_path(project_id)
        staging_dir: Path | None = None
        write_dir = index_dir

        try:
            self._registry.update_job(job_id, status="running")

            # Close any cached read-only engines for this branch before opening
            # the database for writing — avoids ArcadeDB/usearch file lock conflicts
            # on Windows when search/impact queries ran since the last index.
            from ravmem.server.app import invalidate_engines
            invalidate_engines(project_id, branch)
            gc.collect()  # encourage Windows to release file handles immediately

            # Clone-mode workspace management — must happen BEFORE staging setup
            # so the sync result can upgrade mode from incremental → full.
            project = self._registry.get_project(project_id)
            if project and project.get("index_mode") == "clone":
                if not git_ops.is_git_repo(repo):
                    self._clone_workspace(project_id, repo)
                elif auto_sync:
                    mode = self._sync_clone_workspace(project_id, repo, branch, mode)

            # Determine the effective write directory — staging for full mode
            # (set up after mode may have been upgraded above).
            if mode == "full":
                staging_dir = index_dir.parent / (index_dir.name + ".staging")
                if staging_dir.exists():
                    shutil.rmtree(staging_dir)
                staging_dir.mkdir(parents=True, exist_ok=True)
                write_dir = staging_dir

            # Checkout the target branch
            if git_ops.is_git_repo(repo):
                git_ops.checkout_branch(repo, branch)

            config = PipelineConfig()
            if langs:
                config.langs = langs

            from ravmem.server.job_progress import make_progress_callback, make_progress_event_callback
            progress_cb = make_progress_callback(self._registry, job_id, project_id, branch)
            progress_event_cb = make_progress_event_callback(self._registry, job_id, project_id, branch)

            branch_rec = self._registry.get_branch(project_id, branch)
            parent_branch = branch_rec.get("parent_branch") if branch_rec else None

            pipeline = IndexPipeline(
                repo_path=repo,
                config=config,
                on_progress=progress_cb,
                on_progress_event=progress_event_cb,
                index_dir=write_dir,
                repo_id=project_id,
                branch=branch,
                parent_branch=parent_branch,
            )

            if mode == "full":
                pipeline.run_full()
            else:
                pipeline.run_incremental()

            pipeline.close()

            # For full mode: atomically promote staging dir → index_dir
            if staging_dir is not None:
                # Invalidate any cached engine handles BEFORE rename to release
                # ArcadeDB/usearch file locks on Windows.
                from ravmem.server.app import invalidate_engines
                invalidate_engines(project_id, branch)
                # Give the GC a chance to release the handles we just invalidated.
                gc.collect()

                _promote_staging_dir(staging_dir, index_dir)
                staging_dir = None  # already promoted; skip cleanup in finally

            # Update registry — prefer .git HEAD, fall back to upload sentinel
            if git_ops.is_git_repo(repo):
                head = git_ops.get_head_commit(repo)
            else:
                sentinel = repo / _HEAD_SENTINEL
                head = sentinel.read_text().strip() if sentinel.exists() else ""
                if sentinel.exists():
                    sentinel.unlink(missing_ok=True)
            # Read final counts from the branch's own meta.db
            from ravmem.storage.meta import MetaStore
            meta = MetaStore(index_dir / "meta.db")
            repo_info = meta.get_repo(project_id)
            sym_count = repo_info["symbol_count"] if repo_info else 0
            edge_count = repo_info["edge_count"] if repo_info else 0
            meta.close()

            self._registry.update_branch_status(
                project_id, branch,
                status="ready",
                last_commit=head,
                symbol_count=sym_count,
                edge_count=edge_count,
            )
            self._registry.update_job(job_id, status="done", progress_pct=100)

            # Invalidate cached engines so queries pick up the new index
            from ravmem.server.app import invalidate_engines
            invalidate_engines(project_id, branch)

            logger.info(
                "Index complete: %s/%s — %d symbols, %d edges",
                project_id, branch, sym_count, edge_count,
            )

        except Exception as exc:
            logger.error("Indexing failed for %s/%s: %s", project_id, branch, exc)
            # Clean up the staging dir if the full reindex failed
            if staging_dir is not None and staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
            # Incremental upload failures leave the workspace in a partially
            # updated state — mark "stale" so the user knows to re-run analyze
            # rather than "failed" which implies a clean rollback.
            fail_status = (
                "stale"
                if mode == "incremental" and not git_ops.is_git_repo(repo)
                else "failed"
            )
            self._registry.update_branch_status(project_id, branch, status=fail_status)
            self._registry.update_job(
                job_id, status="failed", failure_reason=str(exc),
            )
