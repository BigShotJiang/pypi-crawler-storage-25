"""Auth REST endpoints — Phase 1: admin token rotation. Phase 2: users and tokens."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _require_admin(request: Request) -> None:
    from ravmem.auth.context import get_auth_context
    ctx = get_auth_context()
    if ctx is None or not ctx.is_admin:
        raise HTTPException(status_code=403, detail="Admin token required")


def _require_auth(request: Request):
    from ravmem.auth.context import get_auth_context
    ctx = get_auth_context()
    if ctx is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    return ctx


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else ""


def _parse_expires_in(expires_in: str | None) -> datetime | None:
    """Parse '30d', '24h', '60m' into a UTC datetime."""
    if not expires_in:
        return None
    unit = expires_in[-1].lower()
    try:
        value = int(expires_in[:-1])
    except ValueError:
        raise HTTPException(status_code=422, detail=f"Invalid expires_in format: {expires_in!r}. Use e.g. '30d', '24h', '60m'.")
    if unit == "d":
        delta = timedelta(days=value)
    elif unit == "h":
        delta = timedelta(hours=value)
    elif unit == "m":
        delta = timedelta(minutes=value)
    else:
        raise HTTPException(status_code=422, detail=f"Unknown time unit '{unit}'. Use d, h, or m.")
    return datetime.now(timezone.utc) + delta


# ---------------------------------------------------------------------------
# Admin token rotation
# ---------------------------------------------------------------------------

@router.post("/admin/reset-token")
async def reset_admin_token(request: Request):
    """Rotate the admin token. Requires a valid admin token.

    Returns the new token once. Store it — it cannot be retrieved again.
    The old token is invalidated immediately.
    """
    from ravmem.auth.bootstrap import rotate_admin_token
    from ravmem.auth import audit
    from ravmem.config import RAVMEM_SYSTEM_DB

    _require_admin(request)

    try:
        new_token = await asyncio.to_thread(rotate_admin_token, RAVMEM_SYSTEM_DB)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Token rotation failed: {exc}") from exc

    audit.log("admin", "admin.token_reset", "admin_token", ip=_client_ip(request))
    return {
        "token": new_token,
        "message": "Admin token rotated. Save this token — it will not be shown again.",
    }


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Login (password-based)
# ---------------------------------------------------------------------------

class LoginBody(BaseModel):
    username: str   # username or email
    password: str


@router.post("/login")
async def login(body: LoginBody, request: Request):
    """Authenticate with username/email + password. Returns a short-lived API token."""
    from ravmem.auth import service, audit

    try:
        user = await asyncio.to_thread(service.verify_password, body.username, body.password)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    if user is None:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Issue a session token valid for 8 hours
    expires_at = datetime.now(timezone.utc) + timedelta(hours=8)
    try:
        raw_token, record = await asyncio.to_thread(
            service.create_token, user["id"], "ui-session", expires_at
        )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    audit.log(user["id"], "user.login", user["id"], ip=_client_ip(request))
    return {"token": raw_token, "user": user, "expires_at": record["expires_at"]}


@router.get("/me")
async def get_me(request: Request):
    """Return the authenticated user's profile and roles."""
    from ravmem.auth import service
    from ravmem.auth.context import get_auth_context

    ctx = get_auth_context()
    if ctx is None:
        raise HTTPException(status_code=401, detail="Authentication required")

    if ctx.is_admin:
        return {"id": "admin", "username": "admin", "name": "Administrator", "email": "", "roles": ["admin"], "is_admin": True}

    try:
        user = await asyncio.to_thread(service.get_user_by_id, ctx.user_id)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    try:
        roles = await asyncio.to_thread(service.get_user_roles, ctx.user_id)
    except Exception:
        roles = []

    return {**user, "roles": roles, "is_admin": False}


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

class CreateUserBody(BaseModel):
    email: str
    name: str
    username: Optional[str] = None
    password: Optional[str] = None


@router.post("/users", status_code=201)
async def create_user(body: CreateUserBody, request: Request):
    """Create a new user (admin only)."""
    from ravmem.auth import service, audit

    _require_admin(request)
    try:
        user = await asyncio.to_thread(
            service.create_user, body.email, body.name, body.username, body.password
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    audit.log("admin", "user.created", user["id"], ip=_client_ip(request))
    return user


@router.get("/users")
async def list_users(request: Request):
    """List all users (admin only)."""
    from ravmem.auth import service

    _require_admin(request)
    try:
        return await asyncio.to_thread(service.list_users)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


class UpdateUserBody(BaseModel):
    status: str  # "active" | "disabled"


@router.delete("/users/{user_id}", status_code=200)
async def delete_user(user_id: str, request: Request):
    """Delete a user (admin only). Revokes all tokens and removes role assignments."""
    from ravmem.auth import service, audit

    _require_admin(request)
    try:
        user = await asyncio.to_thread(service.get_user_by_id, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail=f"User '{user_id}' not found")
        await asyncio.to_thread(service.delete_user, user_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    audit.log("admin", "user.deleted", user_id, ip=_client_ip(request))
    return {"id": user_id, "deleted": True}


@router.patch("/users/{user_id}")
async def update_user(user_id: str, body: UpdateUserBody, request: Request):
    """Enable or disable a user (admin only). Disabling eagerly revokes all their tokens."""
    from ravmem.auth import service, audit

    _require_admin(request)
    if body.status not in ("active", "disabled"):
        raise HTTPException(status_code=422, detail="status must be 'active' or 'disabled'")

    try:
        user = await asyncio.to_thread(service.get_user_by_id, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail=f"User '{user_id}' not found")
        await asyncio.to_thread(service.set_user_status, user_id, body.status)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    action = "user.disabled" if body.status == "disabled" else "user.enabled"
    audit.log("admin", action, user_id, ip=_client_ip(request))
    return {"id": user_id, "status": body.status}


# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------

class CreateTokenBody(BaseModel):
    user_id: str
    name: str
    expires_in: Optional[str] = None  # e.g. "30d", "24h"


@router.post("/tokens", status_code=201)
async def create_token(body: CreateTokenBody, request: Request):
    """Create an API token. Admin can create for any user; users for themselves only."""
    from ravmem.auth import service, audit

    ctx = _require_auth(request)
    if not ctx.is_admin and ctx.user_id != body.user_id:
        raise HTTPException(status_code=403, detail="Cannot create tokens for other users")

    expires_at = _parse_expires_in(body.expires_in)

    try:
        user = await asyncio.to_thread(service.get_user_by_id, body.user_id)
        if user is None:
            raise HTTPException(status_code=404, detail=f"User '{body.user_id}' not found")
        if user.get("status") != "active":
            raise HTTPException(status_code=409, detail="Cannot create token for a disabled user")
        raw_token, record = await asyncio.to_thread(
            service.create_token, body.user_id, body.name, expires_at
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    actor = ctx.user_id
    audit.log(actor, "token.created", record["id"], ip=_client_ip(request))
    return {"token": raw_token, **record}


@router.get("/tokens")
async def list_tokens(
    request: Request,
    user_id: Optional[str] = Query(None, description="Filter by user (admin only for other users)"),
):
    """List tokens. Admin sees all; users see only their own."""
    from ravmem.auth import service

    ctx = _require_auth(request)
    if ctx.is_admin:
        effective_user = user_id  # None = all
    else:
        if user_id and user_id != ctx.user_id:
            raise HTTPException(status_code=403, detail="Cannot list tokens for other users")
        effective_user = ctx.user_id

    try:
        return await asyncio.to_thread(service.list_tokens, effective_user)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.delete("/tokens/_all", status_code=200)
async def revoke_all_user_tokens(
    request: Request,
    user: str = Query(..., description="User ID — revoke all their tokens (admin only)"),
):
    """Revoke all tokens for a user (admin only)."""
    from ravmem.auth import service, audit

    ctx = _require_auth(request)
    _require_admin(request)

    try:
        count = await asyncio.to_thread(service.revoke_all_tokens_for_user, user)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    audit.log(ctx.user_id, "token.revoked", f"all:{user}", ip=_client_ip(request))
    return {"revoked": count}


@router.delete("/tokens/{token_id}", status_code=200)
async def revoke_token(token_id: str, request: Request):
    """Revoke a single token by ID. Admin can revoke any; users can revoke their own."""
    from ravmem.auth import service, audit

    ctx = _require_auth(request)

    try:
        rows = await asyncio.to_thread(
            service._query,
            f"SELECT id, user_id FROM ApiToken WHERE id = '{service._esc(token_id)}' LIMIT 1"
        )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    if not rows:
        raise HTTPException(status_code=404, detail=f"Token '{token_id}' not found")

    tok_owner = rows[0].get("user_id", "")
    if not ctx.is_admin and ctx.user_id != tok_owner:
        raise HTTPException(status_code=403, detail="Cannot revoke tokens belonging to other users")

    try:
        await asyncio.to_thread(service.revoke_token, token_id)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    audit.log(ctx.user_id, "token.revoked", token_id, ip=_client_ip(request))
    return {"id": token_id, "status": "revoked"}


# ---------------------------------------------------------------------------
# Roles (Phase 3)
# ---------------------------------------------------------------------------

class CreateRoleBody(BaseModel):
    name: str


class RolePermissionBody(BaseModel):
    permission: str


class AssignRoleBody(BaseModel):
    user_id: str
    role: str


@router.post("/roles", status_code=201)
async def create_role(body: CreateRoleBody, request: Request):
    """Create a new role with no permissions (admin only)."""
    from ravmem.auth import service, audit
    _require_admin(request)
    try:
        role = await asyncio.to_thread(service.create_role, body.name)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    audit.log("admin", "role.created", role["id"], ip=_client_ip(request))
    return role


@router.get("/roles")
async def list_roles(request: Request):
    """List all roles and their permissions (admin only)."""
    from ravmem.auth import service
    _require_admin(request)
    try:
        return await asyncio.to_thread(service.list_roles)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@router.get("/roles/{name}")
async def get_role(name: str, request: Request):
    """Get a single role by name (admin only)."""
    from ravmem.auth import service
    _require_admin(request)
    try:
        role = await asyncio.to_thread(service.get_role_by_name, name)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    if role is None:
        raise HTTPException(status_code=404, detail=f"Role '{name}' not found")
    return role


@router.post("/roles/assign", status_code=200)
async def assign_role(body: AssignRoleBody, request: Request):
    """Assign a role to a user (admin only)."""
    from ravmem.auth import service, audit
    ctx = _require_auth(request)
    _require_admin(request)
    try:
        await asyncio.to_thread(service.assign_role, body.user_id, body.role, ctx.user_id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    audit.log(ctx.user_id, "role.assigned", f"{body.user_id}:{body.role}", ip=_client_ip(request))
    return {"user_id": body.user_id, "role": body.role, "assigned": True}


@router.delete("/roles/assign", status_code=200)
async def unassign_role(body: AssignRoleBody, request: Request):
    """Unassign a role from a user (admin only)."""
    from ravmem.auth import service, audit
    ctx = _require_auth(request)
    _require_admin(request)
    try:
        await asyncio.to_thread(service.unassign_role, body.user_id, body.role)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    audit.log(ctx.user_id, "role.unassigned", f"{body.user_id}:{body.role}", ip=_client_ip(request))
    return {"user_id": body.user_id, "role": body.role, "unassigned": True}


@router.delete("/roles/{name}", status_code=200)
async def delete_role(name: str, request: Request):
    """Delete a role. Blocked if any users are assigned to it (admin only)."""
    from ravmem.auth import service
    _require_admin(request)
    try:
        await asyncio.to_thread(service.delete_role, name)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"name": name, "deleted": True}


@router.post("/roles/{name}/permissions", status_code=200)
async def add_permission(name: str, body: RolePermissionBody, request: Request):
    """Add a permission to a role (admin only)."""
    from ravmem.auth import service, audit
    _require_admin(request)
    try:
        role = await asyncio.to_thread(service.add_permission_to_role, name, body.permission)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    audit.log("admin", "role.permission_added", f"{name}:{body.permission}", ip=_client_ip(request))
    return role


@router.delete("/roles/{name}/permissions/{permission}", status_code=200)
async def remove_permission(name: str, permission: str, request: Request):
    """Remove a permission from a role (admin only)."""
    from ravmem.auth import service
    _require_admin(request)
    try:
        role = await asyncio.to_thread(service.remove_permission_from_role, name, permission)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return role


class RoleTierBody(BaseModel):
    tier: str  # "high" | "standard" | "restricted"


@router.put("/roles/{name}/tier", status_code=200)
async def set_role_tier(name: str, body: RoleTierBody, request: Request):
    """Set the rate-limit tier for a role (admin only).

    Valid tiers: high, standard, restricted.
    The 'admin' tier is reserved — it cannot be assigned to roles.
    """
    from ravmem.auth import service, audit
    _require_admin(request)
    try:
        role = await asyncio.to_thread(service.set_role_tier, name, body.tier)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    audit.log(
        "admin", "role.tier_changed", f"{name} → {body.tier}", ip=_client_ip(request)
    )
    return role


@router.get("/roles/{name}/tier", status_code=200)
async def get_role_tier(name: str, request: Request):
    """Get the current rate-limit tier for a role (admin only)."""
    from ravmem.auth import service
    _require_admin(request)
    try:
        tier = await asyncio.to_thread(service.get_role_tier, name)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"role": name, "tier": tier}


# ---------------------------------------------------------------------------
# Branch Policies (Phase 4)
# ---------------------------------------------------------------------------

class BranchPolicyBody(BaseModel):
    role: str
    permission: str
    pattern: str


@router.post("/branch-policies", status_code=201)
async def add_branch_policy(body: BranchPolicyBody, request: Request):
    """Add a branch name regex policy to a role (admin only).

    The pattern is validated with re.compile() and rejected if invalid.
    """
    from ravmem.auth import branch_policy
    _require_admin(request)
    try:
        result = await asyncio.to_thread(
            branch_policy.add_policy, body.role, body.permission, body.pattern
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return result


@router.delete("/branch-policies", status_code=200)
async def remove_branch_policy(body: BranchPolicyBody, request: Request):
    """Remove a branch policy from a role (admin only)."""
    from ravmem.auth import branch_policy
    _require_admin(request)
    try:
        await asyncio.to_thread(
            branch_policy.remove_policy, body.role, body.permission, body.pattern
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"role": body.role, "permission": body.permission, "pattern": body.pattern, "removed": True}


@router.get("/oidc/config")
async def oidc_config():
    """Return public OIDC config for the browser. Never includes client_secret."""
    from ravmem.config import OIDC_ENABLED, OIDC_ISSUER_URL, OIDC_CLIENT_ID, OIDC_SCOPES
    return {
        "enabled": OIDC_ENABLED and bool(OIDC_ISSUER_URL) and bool(OIDC_CLIENT_ID),
        "issuer_url": OIDC_ISSUER_URL,
        "client_id": OIDC_CLIENT_ID,
        "scopes": OIDC_SCOPES,
    }


class OIDCCallbackBody(BaseModel):
    code: str
    code_verifier: str
    redirect_uri: str


@router.post("/oidc/callback")
async def oidc_callback(request: Request, body: OIDCCallbackBody):
    """Exchange OIDC auth code for a ravmem session token. Provisions user on first login."""
    import httpx
    import jwt as pyjwt
    from ravmem.config import OIDC_ISSUER_URL, OIDC_CLIENT_ID, OIDC_CLIENT_SECRET
    from ravmem.auth import service, audit

    if not OIDC_ISSUER_URL or not OIDC_CLIENT_ID:
        raise HTTPException(status_code=503, detail="OIDC is not configured on this server")

    # 1. Fetch discovery document to get token + JWKS endpoints
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            disc = (await client.get(f"{OIDC_ISSUER_URL}/.well-known/openid-configuration")).json()
            token_endpoint: str = disc["token_endpoint"]
            jwks_uri: str = disc["jwks_uri"]

            # 2. Exchange code for tokens
            token_resp = await client.post(token_endpoint, data={
                "grant_type": "authorization_code",
                "code": body.code,
                "redirect_uri": body.redirect_uri,
                "client_id": OIDC_CLIENT_ID,
                "client_secret": OIDC_CLIENT_SECRET,
                "code_verifier": body.code_verifier,
            })
            if not token_resp.is_success:
                raise HTTPException(status_code=401, detail=f"Token exchange failed: {token_resp.text}")
            token_data = token_resp.json()

            # 3. Fetch JWKS to verify ID token signature
            jwks_data = (await client.get(jwks_uri)).json()
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"OIDC provider unreachable: {exc}")

    id_token: str = token_data.get("id_token", "")
    if not id_token:
        raise HTTPException(status_code=401, detail="No id_token returned by provider")

    # 4. Verify and decode ID token
    try:
        jwks = pyjwt.PyJWKClient.__new__(pyjwt.PyJWKClient)  # use from raw JWKS data
        signing_key = pyjwt.PyJWKClient(jwks_uri).get_signing_key_from_jwt(id_token)
        claims = pyjwt.decode(
            id_token,
            signing_key.key,
            algorithms=["RS256", "ES256"],
            audience=OIDC_CLIENT_ID,
        )
    except Exception as exc:
        raise HTTPException(status_code=401, detail=f"ID token verification failed: {exc}")

    email: str = claims.get("email", "")
    name: str = claims.get("name", "") or claims.get("preferred_username", "") or email
    username: str = (claims.get("preferred_username", "") or email.split("@")[0]).lower()

    if not email:
        raise HTTPException(status_code=401, detail="OIDC token missing email claim")

    # 5. Provision user on first login
    try:
        user = await asyncio.to_thread(service.get_user_by_email, email)
        if user is None:
            user = await asyncio.to_thread(
                service.create_user, email, name, username, None
            )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"User provisioning failed: {exc}")

    # 6. Issue ravmem session token
    try:
        raw_token, record = await asyncio.to_thread(
            service.create_token, user["id"], "oidc-session", None
        )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Token creation failed: {exc}")

    audit.log("oidc", "user.sso_login", user["id"], ip=_client_ip(request))
    return {"token": raw_token, "user": user}


@router.get("/audit")
async def list_audit_log(
    request: Request,
    since: Optional[str] = Query(None, description="ISO datetime lower bound, e.g. 2024-01-01T00:00:00Z"),
    actor: Optional[str] = Query(None),
    action: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    page: int = Query(1, ge=1),
):
    """List audit log entries, most-recent first (admin only)."""
    _require_admin(request)
    from ravmem.auth import audit
    return await asyncio.to_thread(audit.query_entries, since, actor, action, limit, page)


class RotateAuditBody(BaseModel):
    retain_days: int


@router.post("/audit/rotate", status_code=200)
async def rotate_audit_log(request: Request, body: RotateAuditBody):
    """Delete audit entries older than retain_days (admin only). retain_days must be 10, 30, or 90."""
    _require_admin(request)
    if body.retain_days not in (10, 30, 90):
        raise HTTPException(status_code=422, detail="retain_days must be 10, 30, or 90")
    from ravmem.auth import audit
    return await asyncio.to_thread(audit.rotate_entries, body.retain_days)


@router.get("/branch-policies")
async def list_branch_policies(
    request: Request,
    role: str = Query(..., description="Role name to list policies for"),
):
    """List all branch policies for a role (admin only)."""
    from ravmem.auth import branch_policy
    _require_admin(request)
    try:
        return await asyncio.to_thread(branch_policy.list_policies, role)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
