"""REST API routes — query endpoints for repos, symbols, search, and impact."""

from __future__ import annotations

import re
import shutil
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel

from ravmem.auth import permissions as P
from ravmem.auth.rbac import require_permission
from ravmem.auth.branch_policy import require_branch_policy
from ravmem.config import INDEX_DIR, META_DB_NAME
from ravmem.server.models import CredentialUpdate, IndexRequest, ProjectCreate, ProjectUpdate, UploadBatch
from ravmem.storage.meta import MetaStore

router = APIRouter(tags=["api"])


def _get_engines(repo_path_str: str):
    from ravmem.server.app import get_repo_engines
    try:
        return get_repo_engines(repo_path_str)
    except Exception as exc:
        raise HTTPException(status_code=404, detail=f"Repo not found or not indexed: {exc}")


def _symbol_dict(s) -> dict[str, Any]:
    return {
        "id": s.id, "name": s.name, "kind": s.kind,
        "file": s.file, "line_start": s.line_start,
        "line_end": s.line_end, "lang": s.lang,
        "cluster_id": s.cluster_id,
    }


def _get_branch_engines_from_request(request: Request, project_id: str, branch: str):
    """Helper to get RepoEngines for a project branch, with proper 404 handling."""
    from ravmem.server.app import get_branch_engines

    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")

    branch_rec = registry.get_branch(project_id, branch)
    if not branch_rec or branch_rec["status"] != "ready":
        raise HTTPException(
            status_code=404,
            detail=f"Branch index not found or not ready: {branch}",
        )

    return get_branch_engines(
        project_id, branch, Path(project["repo_path"]), Path(branch_rec["index_path"]),
        parent_branch=branch_rec.get("parent_branch"),
    )


# ---------------------------------------------------------------------------
# Repos listing (uses global registry.db if available, else scans repos_dir)
# ---------------------------------------------------------------------------

@router.get("/repos")
async def list_repos(request: Request) -> list[dict]:
    require_permission(P.REPO_READ)
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        return []
    results = []
    for repo_path in repos_dir.iterdir():
        meta_db = repo_path / INDEX_DIR / META_DB_NAME
        if meta_db.exists():
            try:
                meta = MetaStore(meta_db)
                repos = meta.list_repos()
                results.extend(repos)
            except Exception:
                pass
    return results


# ---------------------------------------------------------------------------
# Per-repo endpoints
# ---------------------------------------------------------------------------

@router.get("/repos/{repo_id}")
async def get_repo(repo_id: str, request: Request) -> dict:
    """Return metadata for a single indexed repo."""
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    repo = engines.meta.get_repo(repo_id)
    if not repo:
        raise HTTPException(status_code=404, detail="Repo not found")
    return repo


@router.get("/repos/{repo_id}/symbols/{symbol_id:path}")
async def get_symbol_by_id(repo_id: str, symbol_id: str, request: Request) -> dict:
    """Return full symbol details including callers, callees, and cluster."""
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    ctx = engines.context_engine.assemble_symbol_context(symbol_id)
    if ctx is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    return {
        "symbol": _symbol_dict(ctx.symbol),
        "callers": [_symbol_dict(s) for s in ctx.callers],
        "callees": [_symbol_dict(s) for s in ctx.callees],
        "cluster": {
            "id": ctx.cluster.id,
            "label": ctx.cluster.label,
            "cohesion_score": ctx.cluster.cohesion_score,
            "size": ctx.cluster.size,
        } if ctx.cluster else None,
        "cluster_peers": [_symbol_dict(s) for s in ctx.cluster_peers],
    }


@router.get("/repos/{repo_id}/graph")
async def get_graph(repo_id: str, request: Request) -> dict:
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    nodes, edges = engines.graph.get_full_graph()
    return {"nodes": nodes, "edges": edges}


@router.get("/repos/{repo_id}/search")
async def search_symbols(
    repo_id: str,
    request: Request,
    q: str = Query(..., description="Search query"),
    limit: int = Query(20, ge=1, le=100),
) -> list[dict]:
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    results = engines.search_engine.search(q, k=limit)
    return [
        {
            "symbol": _symbol_dict(r.symbol),
            "score": r.score,
            "match_type": r.match_type,
        }
        for r in results
    ]


@router.get("/repos/{repo_id}/symbol/{symbol_id:path}")
async def get_symbol(repo_id: str, symbol_id: str, request: Request) -> dict:
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    ctx = engines.context_engine.assemble_symbol_context(symbol_id)
    if ctx is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    return {
        "symbol": _symbol_dict(ctx.symbol),
        "callers": [_symbol_dict(s) for s in ctx.callers],
        "callees": [_symbol_dict(s) for s in ctx.callees],
        "cluster": {
            "id": ctx.cluster.id,
            "label": ctx.cluster.label,
            "cohesion_score": ctx.cluster.cohesion_score,
            "size": ctx.cluster.size,
        } if ctx.cluster else None,
        "cluster_peers": [_symbol_dict(s) for s in ctx.cluster_peers],
    }


@router.get("/repos/{repo_id}/impact/{symbol_id:path}")
async def get_impact(
    repo_id: str,
    symbol_id: str,
    request: Request,
    depth: int = Query(3, ge=1, le=10),
) -> dict:
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    result = engines.impact_engine.get_impact(symbol_id, depth=depth)
    return {
        "root_symbol_id": result.root_symbol_id,
        "affected": [
            {
                "symbol": _symbol_dict(node.symbol),
                "depth": node.depth,
                "path": node.path,
            }
            for node in result.affected
        ],
    }


@router.get("/repos/{repo_id}/clusters")
async def get_clusters(repo_id: str, request: Request) -> list[dict]:
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    clusters = engines.graph.get_all_clusters()
    return [
        {"id": c.id, "label": c.label,
         "cohesion_score": c.cohesion_score, "size": c.size}
        for c in clusters
    ]


@router.get("/repos/{repo_id}/files/symbols")
async def get_symbols_for_path(
    repo_id: str,
    request: Request,
    path: str = Query(..., description="File path or directory prefix"),
    prefix: bool = Query(False, description="If true, treat path as a prefix — returns all symbols under that directory"),
) -> dict:
    """Return all symbols in a file (exact) or directory (prefix=true).

    Examples:
      /repos/myrepo/files/symbols?path=src/auth/login.py
      /repos/myrepo/files/symbols?path=src/auth/&prefix=true
    """
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = str(repos_dir / repo_id)
    engines = _get_engines(repo_path)
    if prefix:
        symbols = engines.graph.get_symbols_for_path_prefix(path)
    else:
        symbols = engines.graph.get_symbols_for_file(path)
    return {"path": path, "prefix": prefix, "symbols": [_symbol_dict(s) for s in symbols]}


@router.post("/repos/{repo_id}/reindex")
async def reindex(
    repo_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
) -> dict:
    """Trigger incremental reindex in the background."""
    repos_dir: Path | None = request.app.state.repos_dir
    if repos_dir is None:
        raise HTTPException(status_code=400, detail="repos_dir not configured")
    repo_path = repos_dir / repo_id

    from ravmem.indexer.pipeline import IndexPipeline
    pipeline = IndexPipeline(repo_path)
    background_tasks.add_task(pipeline.run_incremental)
    return {"status": "reindex started", "repo_id": repo_id}


# ---------------------------------------------------------------------------
# Project management endpoints
# ---------------------------------------------------------------------------

@router.post("/projects", status_code=201)
async def create_project(body: ProjectCreate, request: Request) -> dict:
    """Register a new project.

    Mode is derived from the request:
    - ``git_url`` → clone mode; server will git-clone on first analyze.
    - ``repo_path`` + ``mount=True`` → mount mode; path must exist on the server.
    - ``repo_path`` + ``mount=False`` → upload mode; CLI pushes files via POST /index later.
    """
    require_permission(P.REPO_CREATE)

    registry = request.app.state.registry
    data_dir: Path = request.app.state.data_dir
    index_mode = body.resolved_index_mode

    # Derive project name and ID
    source_label = body.git_url or body.repo_path or ""
    raw_name = body.name or source_label.rstrip("/").rsplit("/", 1)[-1].removesuffix(".git")
    project_id = re.sub(r"[^a-z0-9-]", "-", raw_name.lower()).strip("-")[:50]
    if not project_id:
        project_id = "project"

    # Determine server-side workspace path
    if index_mode == "mount":
        # Workspace is the mounted path — must already exist on the server
        workspace = Path(body.repo_path)  # type: ignore[arg-type]
        if not workspace.exists():
            raise HTTPException(
                status_code=400,
                detail=f"Mount path does not exist on the server: {body.repo_path}",
            )
    else:
        # clone or upload — server manages a workspace directory
        workspace = data_dir / "repos" / project_id / "workspace"
        workspace.mkdir(parents=True, exist_ok=True)

    # Store credentials for private clone repos
    if index_mode == "clone" and body.git_username and body.git_token:
        from ravmem.server.credentials import CredentialStore, CredentialError
        try:
            CredentialStore(data_dir / "repos" / project_id).store(
                git_url=body.git_url,  # type: ignore[arg-type]
                git_username=body.git_username,
                git_token=body.git_token,
            )
        except CredentialError as exc:
            raise HTTPException(status_code=500, detail=str(exc))

    project = registry.create_project(
        project_id=project_id,
        name=raw_name,
        repo_path=str(workspace),
        default_branch=body.default_branch,
        index_mode=index_mode,
        workspace_path=str(workspace),
        git_url=body.git_url if index_mode == "clone" else None,
    )
    project["index_mode"] = index_mode
    return project


@router.get("/projects")
async def list_projects(request: Request) -> list[dict]:
    """List all registered projects."""
    require_permission(P.REPO_READ)
    registry = request.app.state.registry
    return registry.list_projects()


@router.get("/projects/{project_id}")
async def get_project(project_id: str, request: Request) -> dict:
    """Get project details including indexed branches."""
    require_permission(P.REPO_READ)
    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    project["indexed_branches"] = registry.list_branches(project_id)
    return project


@router.patch("/projects/{project_id}")
async def update_project(project_id: str, body: ProjectUpdate, request: Request) -> dict:
    """Update project metadata (e.g. change the default/parent branch)."""
    require_permission(P.REPO_UPDATE)
    registry = request.app.state.registry
    project = registry.update_project(
        project_id,
        default_branch=body.default_branch,
        index_mode=body.index_mode,
        workspace_path=body.workspace_path,
    )
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    return project


@router.delete("/projects/{project_id}")
async def delete_project(project_id: str, request: Request) -> dict:
    """Delete a project and clean up its index directories."""
    require_permission(P.REPO_DELETE)
    registry = request.app.state.registry
    branch_manager = request.app.state.branch_manager

    registry.delete_project(project_id)

    project_dir = branch_manager.project_dir(project_id)
    if project_dir.exists():
        shutil.rmtree(project_dir)

    return {"deleted": True}


# ---------------------------------------------------------------------------
# Upload-based indexing endpoint (CLI pushes file batches)
# ---------------------------------------------------------------------------

@router.post("/projects/{project_id}/index", status_code=202)
async def upload_index_batch(
    project_id: str,
    body: UploadBatch,
    request: Request,
) -> dict:
    """Receive one file batch from the CLI for upload-mode projects.

    Returns ``{"pending": true, "batch_index": N}`` for intermediate batches.
    Returns ``{"job_id": N}`` after the final batch — pipeline starts immediately.
    Returns 409 if another upload is already in progress for the same branch.
    Returns 400 if the project is not in upload mode.
    """
    require_permission(P.BRANCH_INDEX)
    await require_branch_policy(P.BRANCH_INDEX, body.branch)

    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    if project.get("index_mode") not in (None, "upload"):
        raise HTTPException(
            status_code=400,
            detail=(
                f"Project '{project_id}' uses index_mode={project['index_mode']!r}. "
                "File upload is only available for upload-mode projects."
            ),
        )

    branch_manager = request.app.state.branch_manager
    try:
        return await branch_manager.receive_upload_batch(project_id, body)
    except ValueError as exc:
        msg = str(exc)
        status = 409 if "already in progress" in msg else 400
        raise HTTPException(status_code=status, detail=msg)


# ---------------------------------------------------------------------------
# Workspace sync — git fetch for clone-mode projects
# ---------------------------------------------------------------------------

@router.post("/projects/{project_id}/workspace/sync")
async def sync_workspace(project_id: str, request: Request) -> dict:
    """Fetch the latest remote commits into the server-side workspace.

    Only valid for ``index_mode=clone`` projects with an existing workspace.
    Does NOT re-index — call ``POST /branches/{branch}/index`` afterwards to
    pick up changes.

    Returns ``{synced, fetched_branches, fetched_commits, workspace_head, duration_ms}``.
    """
    require_permission(P.REPO_READ)
    branch_manager = request.app.state.branch_manager
    try:
        result = branch_manager.sync_project_workspace(project_id)
    except ValueError as exc:
        msg = str(exc)
        status = 404 if "Unknown project" in msg or "not been cloned" in msg else 400
        raise HTTPException(status_code=status, detail=msg)
    return result


# ---------------------------------------------------------------------------
# Workspace reset — wipe server-side workspace (clone / upload projects)
# ---------------------------------------------------------------------------

@router.post("/projects/{project_id}/workspace/reset")
async def reset_workspace(project_id: str, request: Request) -> dict:
    """Delete the server-side workspace and clear all branch index records.

    Valid for ``clone`` and ``upload`` mode projects only.
    Mount-mode workspaces are managed externally — returns 400.

    After a reset, run ``ravmem analyze`` (upload) or
    ``POST /index/clone`` (clone) to rebuild from scratch.

    Returns ``{reset: True, removed_workspace: bool, branches_cleared: int}``.
    """
    require_permission(P.REPO_UPDATE)
    branch_manager = request.app.state.branch_manager
    try:
        return branch_manager.reset_workspace(project_id)
    except ValueError as exc:
        msg = str(exc)
        status = 404 if "Unknown project" in msg else 400
        raise HTTPException(status_code=status, detail=msg)


# ---------------------------------------------------------------------------
# Credential management — store / delete git credentials for clone projects
# ---------------------------------------------------------------------------

@router.get("/projects/{project_id}/credentials", status_code=200)
async def get_credentials(project_id: str, request: Request) -> dict:
    """Return whether credentials are stored for a clone-mode project.

    Never returns the raw token — only ``{stored: bool, secret_key_missing: bool}``.
    """
    require_permission(P.REPO_UPDATE)
    from ravmem.server.credentials import CredentialStore
    from ravmem.server.branch_manager import BranchManager
    import os
    branch_manager: BranchManager = request.app.state.branch_manager
    secret_key_missing = not os.environ.get("RAVMEM_SECRET_KEY")
    stored = CredentialStore(branch_manager.project_dir(project_id)).exists()
    return {"stored": stored, "secret_key_missing": secret_key_missing}


@router.post("/projects/{project_id}/credentials", status_code=200)
async def set_credentials(
    project_id: str, body: CredentialUpdate, request: Request,
) -> dict:
    """Store or replace encrypted git credentials for a clone-mode project.

    Requires ``RAVMEM_SECRET_KEY`` to be set on the server.
    Only valid for clone-mode projects.

    Returns ``{stored: True}``.
    """
    require_permission(P.REPO_UPDATE)
    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    if project.get("index_mode") != "clone":
        raise HTTPException(
            status_code=400,
            detail=(
                f"Project '{project_id}' uses index_mode={project.get('index_mode')!r}. "
                "Credential storage is only available for clone-mode projects."
            ),
        )
    from ravmem.server.credentials import CredentialStore, CredentialError
    from ravmem.server.branch_manager import BranchManager
    branch_manager: BranchManager = request.app.state.branch_manager
    git_url = project.get("git_url") or ""
    try:
        CredentialStore(branch_manager.project_dir(project_id)).store(
            git_url=git_url,
            git_username=body.git_username,
            git_token=body.git_token,
        )
    except CredentialError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"stored": True}


@router.delete("/projects/{project_id}/credentials", status_code=200)
async def delete_credentials(project_id: str, request: Request) -> dict:
    """Remove stored git credentials for a clone-mode project.

    No-op if no credentials are stored.  Returns ``{deleted: bool}``.
    """
    require_permission(P.REPO_UPDATE)
    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    from ravmem.server.credentials import CredentialStore
    from ravmem.server.branch_manager import BranchManager
    branch_manager: BranchManager = request.app.state.branch_manager
    cred_store = CredentialStore(branch_manager.project_dir(project_id))
    existed = cred_store.exists()
    cred_store.delete()
    return {"deleted": existed}


# ---------------------------------------------------------------------------
# Clone endpoint — triggers initial git clone + index for clone-mode projects
# ---------------------------------------------------------------------------

@router.post("/projects/{project_id}/index/clone", status_code=202)
async def clone_and_index(
    project_id: str,
    request: Request,
    branch: str | None = None,
) -> dict:
    """Clone the project's remote repository and kick off initial indexing.

    Only valid for ``index_mode=clone`` projects.  The clone is performed
    inside the server-managed workspace; subsequent ``analyze`` calls will
    use incremental indexing against the live workspace.

    *branch* defaults to the project's ``default_branch``.
    """
    require_permission(P.BRANCH_INDEX)
    registry = request.app.state.registry
    project = registry.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_id}")
    if project.get("index_mode") != "clone":
        raise HTTPException(
            status_code=400,
            detail=(
                f"Project '{project_id}' uses index_mode={project.get('index_mode')!r}. "
                "Clone is only available for clone-mode projects."
            ),
        )

    target_branch = branch or project.get("default_branch", "main")
    await require_branch_policy(P.BRANCH_INDEX, target_branch)

    branch_manager = request.app.state.branch_manager
    try:
        job_id = await branch_manager.clone_and_index(project_id, target_branch)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job_id": job_id}


# ---------------------------------------------------------------------------
# Branch indexing endpoints (server-side: mount / clone projects)
# ---------------------------------------------------------------------------

@router.post("/projects/{project_id}/branches/{branch:path}/index", status_code=202)
async def index_branch(
    project_id: str, branch: str, body: IndexRequest, request: Request,
) -> dict:
    """Trigger indexing for a specific branch."""
    require_permission(P.BRANCH_INDEX)
    await require_branch_policy(P.BRANCH_INDEX, branch)
    branch_manager = request.app.state.branch_manager
    try:
        job_id = await branch_manager.index_branch(
            project_id, branch,
            mode=body.mode,
            langs=body.langs,
            auto_sync=not body.no_auto_sync,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"job_id": job_id}


@router.get("/projects/{project_id}/branches")
async def list_branches(project_id: str, request: Request) -> list[dict]:
    """List all indexed branches for a project."""
    require_permission(P.REPO_READ)
    registry = request.app.state.registry
    return registry.list_branches(project_id)


@router.get("/projects/{project_id}/branches/{branch:path}/status")
async def get_branch_status(
    project_id: str, branch: str, request: Request,
) -> dict:
    """Get branch index status and active job info."""
    require_permission(P.REPO_READ)
    registry = request.app.state.registry

    branch_rec = registry.get_branch(project_id, branch)
    if not branch_rec:
        raise HTTPException(status_code=404, detail=f"Branch index not found: {branch}")

    project_rec = registry.get_project(project_id) or {}

    result: dict[str, Any] = dict(branch_rec)

    # Enrich with project-level fields
    result["index_mode"] = project_rec.get("index_mode", "mount")

    # Friendly aliases
    last_commit = result.get("last_commit", "")
    result["last_indexed_commit"] = last_commit
    result["last_indexed_at"] = result.get("indexed_at")

    # Commit message (best-effort, server-side repos only)
    workspace = project_rec.get("workspace_path") or project_rec.get("repo_path", "")
    commit_message: str | None = None
    if workspace and last_commit:
        from ravmem.server import git_ops
        commit_message = git_ops.get_commit_message(Path(workspace), last_commit)
    result["last_indexed_commit_message"] = commit_message

    # Parent branch last-indexed commit
    parent_branch = result.get("parent_branch")
    if parent_branch:
        parent_rec = registry.get_branch(project_id, parent_branch) or {}
        result["parent_last_indexed_commit"] = parent_rec.get("last_commit", "")
    else:
        result["parent_last_indexed_commit"] = None

    active_job = registry.get_active_job(project_id, branch)
    if active_job:
        result["active_job"] = active_job

    return result


@router.get("/projects/{project_id}/branches/{branch:path}/divergence")
async def get_branch_divergence(
    project_id: str, branch: str, request: Request,
) -> dict:
    """Pre-flight divergence check: how much has this branch changed since last index."""
    require_permission(P.REPO_READ)
    branch_manager = request.app.state.branch_manager
    try:
        return branch_manager.compute_divergence(project_id, branch)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.delete("/projects/{project_id}/branches/{branch:path}/index")
async def delete_branch_index(
    project_id: str, branch: str, request: Request,
) -> dict:
    """Delete a branch index and clean up its directory."""
    require_permission(P.BRANCH_DELETE)
    await require_branch_policy(P.BRANCH_DELETE, branch)
    from ravmem.server.app import invalidate_engines

    registry = request.app.state.registry
    branch_manager = request.app.state.branch_manager

    branch_rec = registry.get_branch(project_id, branch)
    registry.delete_branch(project_id, branch)
    invalidate_engines(project_id, branch)

    if branch_rec:
        index_dir = Path(branch_rec["index_path"])
        if index_dir.exists():
            shutil.rmtree(index_dir)

    return {"deleted": True}


# ---------------------------------------------------------------------------
# Branch query endpoints
# ---------------------------------------------------------------------------

@router.get("/projects/{project_id}/branches/{branch:path}/search")
async def branch_search(
    project_id: str,
    branch: str,
    request: Request,
    q: str = Query(..., description="Search query"),
    limit: int = Query(20, ge=1, le=100),
) -> list[dict]:
    """Search symbols within a branch index."""
    require_permission(P.BRANCH_READ)
    await require_branch_policy(P.BRANCH_READ, branch)
    engines = _get_branch_engines_from_request(request, project_id, branch)
    results = engines.search_engine.search(q, k=limit)
    return [
        {
            "symbol": _symbol_dict(r.symbol),
            "score": r.score,
            "match_type": r.match_type,
        }
        for r in results
    ]


@router.get("/projects/{project_id}/branches/{branch:path}/impact/{symbol_id:path}")
async def branch_impact(
    project_id: str,
    branch: str,
    symbol_id: str,
    request: Request,
    depth: int = Query(3, ge=1, le=10),
) -> dict:
    """Get blast-radius impact for a symbol within a branch index."""
    require_permission(P.BRANCH_READ)
    await require_branch_policy(P.BRANCH_READ, branch)
    engines = _get_branch_engines_from_request(request, project_id, branch)
    result = engines.impact_engine.get_impact(symbol_id, depth=depth)
    return {
        "root_symbol_id": result.root_symbol_id,
        "affected": [
            {
                "symbol": _symbol_dict(node.symbol),
                "depth": node.depth,
                "path": node.path,
            }
            for node in result.affected
        ],
    }


@router.get("/projects/{project_id}/branches/{branch:path}/symbols/{symbol_id:path}")
async def branch_symbol(
    project_id: str, branch: str, symbol_id: str, request: Request,
) -> dict:
    """Get full symbol context within a branch index."""
    engines = _get_branch_engines_from_request(request, project_id, branch)
    ctx = engines.context_engine.assemble_symbol_context(symbol_id)
    if ctx is None:
        raise HTTPException(status_code=404, detail="Symbol not found")
    return {
        "symbol": _symbol_dict(ctx.symbol),
        "callers": [_symbol_dict(s) for s in ctx.callers],
        "callees": [_symbol_dict(s) for s in ctx.callees],
        "cluster": {
            "id": ctx.cluster.id,
            "label": ctx.cluster.label,
            "cohesion_score": ctx.cluster.cohesion_score,
            "size": ctx.cluster.size,
        } if ctx.cluster else None,
        "cluster_peers": [_symbol_dict(s) for s in ctx.cluster_peers],
    }


@router.get("/projects/{project_id}/branches/{branch:path}/clusters")
async def branch_clusters(
    project_id: str, branch: str, request: Request,
) -> list[dict]:
    """Get all clusters within a branch index."""
    engines = _get_branch_engines_from_request(request, project_id, branch)
    clusters = engines.graph.get_all_clusters()
    return [
        {"id": c.id, "label": c.label,
         "cohesion_score": c.cohesion_score, "size": c.size}
        for c in clusters
    ]


@router.get("/projects/{project_id}/branches/{branch:path}/clusters/{cluster_id:path}")
async def branch_cluster_detail(
    project_id: str, branch: str, cluster_id: str, request: Request,
) -> dict:
    """Get a cluster and all its members within a branch index."""
    engines = _get_branch_engines_from_request(request, project_id, branch)
    cluster = engines.graph.get_cluster(cluster_id)
    if cluster is None:
        raise HTTPException(status_code=404, detail=f"Cluster not found: {cluster_id}")
    members = engines.graph.get_cluster_members(cluster_id)
    return {
        "id": cluster.id,
        "label": cluster.label,
        "cohesion_score": cluster.cohesion_score,
        "size": cluster.size,
        "members": [_symbol_dict(s) for s in members],
    }


@router.get("/projects/{project_id}/branches/{branch:path}/files/symbols")
async def branch_symbols_for_path(
    project_id: str,
    branch: str,
    request: Request,
    path: str = Query(..., description="File path or directory prefix"),
    prefix: bool = Query(False, description="If true, treat path as a directory prefix"),
) -> dict:
    """Return all symbols in a file (exact) or directory (prefix=true) for a branch."""
    engines = _get_branch_engines_from_request(request, project_id, branch)
    if prefix:
        symbols = engines.graph.get_symbols_for_path_prefix(path)
    else:
        symbols = engines.graph.get_symbols_for_file(path)
    return {"path": path, "prefix": prefix, "symbols": [_symbol_dict(s) for s in symbols]}


@router.get("/projects/{project_id}/branches/{branch:path}/graph")
async def branch_graph(
    project_id: str, branch: str, request: Request,
) -> dict:
    """Get full graph for a branch index."""
    engines = _get_branch_engines_from_request(request, project_id, branch)
    nodes, edges = engines.graph.get_full_graph()
    return {"nodes": nodes, "edges": edges}


class DiffImpactRequest(BaseModel):
    diff: str
    depth: int = 3


@router.post("/projects/{project_id}/branches/{branch:path}/diff-impact")
async def branch_diff_impact(
    project_id: str, branch: str, body: DiffImpactRequest, request: Request,
) -> dict:
    """Compute blast radius for all symbols changed in a unified diff."""
    require_permission(P.REPO_READ)
    engines = _get_branch_engines_from_request(request, project_id, branch)
    impact_results = engines.impact_engine.diff_impact(body.diff)
    output = []
    changed_symbols = []
    for r in impact_results:
        changed_symbols.append(r.root_symbol_id)
        affected_preview = r.affected[:20]
        total = r.total_affected_count if r.total_affected_count > 0 else len(r.affected)
        output.append({
            "root_symbol_id": r.root_symbol_id,
            "total_affected_count": total,
            "truncated": len(r.affected) > 20,
            "affected": [
                {"symbol": _symbol_dict(n.symbol), "depth": n.depth}
                for n in affected_preview
            ],
        })
    return {
        "changed_symbols": changed_symbols,
        "affected": [n for entry in output for n in entry["affected"]],
        "results": output,
    }


# ---------------------------------------------------------------------------
# Job status endpoint
# ---------------------------------------------------------------------------

@router.get("/jobs/{job_id}")
async def get_job(job_id: str, request: Request) -> dict:
    """Get status of an indexing job."""
    require_permission(P.JOB_READ)
    registry = request.app.state.registry
    job = registry.get_job(int(job_id))
    if not job:
        raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")
    return job


# ---------------------------------------------------------------------------
# Metrics endpoint (Prometheus-style text format)
# ---------------------------------------------------------------------------

@router.get("/metrics", tags=["meta"])
async def get_metrics(request: Request) -> Response:
    """Return Prometheus-style text metrics. Public endpoint — no auth required."""
    registry = request.app.state.registry
    start_time = request.app.state.start_time

    projects_total = registry.count_projects()
    jobs_active = registry.count_active_jobs()
    jobs_queued = registry.count_queued_jobs()
    uptime_seconds = round(time.monotonic() - start_time, 1)

    lines = [
        "# HELP ravmem_projects_total Total registered projects",
        "# TYPE ravmem_projects_total gauge",
        f"ravmem_projects_total {projects_total}",
        "# HELP ravmem_jobs_active Currently running indexing jobs",
        "# TYPE ravmem_jobs_active gauge",
        f"ravmem_jobs_active {jobs_active}",
        "# HELP ravmem_jobs_queued Jobs waiting to run",
        "# TYPE ravmem_jobs_queued gauge",
        f"ravmem_jobs_queued {jobs_queued}",
        "# HELP ravmem_uptime_seconds Server uptime in seconds",
        "# TYPE ravmem_uptime_seconds gauge",
        f"ravmem_uptime_seconds {uptime_seconds}",
    ]
    return Response(content="\n".join(lines) + "\n", media_type="text/plain")
