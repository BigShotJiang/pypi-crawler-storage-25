"""Server-level project and branch registry backed by SQLite."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_DDL = [
    """
    CREATE TABLE IF NOT EXISTS projects (
        id             TEXT PRIMARY KEY,
        name           TEXT NOT NULL,
        repo_path      TEXT NOT NULL,
        default_branch TEXT NOT NULL DEFAULT 'main',
        index_mode     TEXT NOT NULL DEFAULT 'mount',
        workspace_path TEXT,
        git_url        TEXT,
        created_at     TEXT NOT NULL,
        updated_at     TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS branch_indexes (
        project_id   TEXT NOT NULL,
        branch       TEXT NOT NULL,
        index_path   TEXT NOT NULL,
        last_commit  TEXT DEFAULT '',
        symbol_count INTEGER DEFAULT 0,
        edge_count   INTEGER DEFAULT 0,
        status       TEXT DEFAULT 'empty',
        indexed_at   TEXT,
        PRIMARY KEY (project_id, branch),
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS index_jobs_server (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id     TEXT NOT NULL,
        branch         TEXT NOT NULL,
        mode           TEXT NOT NULL DEFAULT 'full',
        status         TEXT NOT NULL DEFAULT 'queued',
        progress_pct   INTEGER DEFAULT 0,
        current_phase  TEXT DEFAULT '',
        started_at     TEXT,
        ended_at       TEXT,
        failure_reason TEXT DEFAULT '',
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
    )
    """,
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ServerRegistry:
    """Manages the server-level SQLite database for projects, branches, and jobs."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        for ddl in _DDL:
            self._conn.execute(ddl)
        self._conn.commit()
        # Migration: add parent_branch column if it doesn't exist yet
        cols = {row[1] for row in self._conn.execute("PRAGMA table_info(branch_indexes)")}
        if "parent_branch" not in cols:
            self._conn.execute(
                "ALTER TABLE branch_indexes ADD COLUMN parent_branch TEXT DEFAULT NULL"
            )
            self._conn.commit()

        # Migration: add index_mode + workspace_path to projects if absent
        proj_cols = {row[1] for row in self._conn.execute("PRAGMA table_info(projects)")}
        if "index_mode" not in proj_cols:
            self._conn.execute(
                "ALTER TABLE projects ADD COLUMN index_mode TEXT NOT NULL DEFAULT 'mount'"
            )
        if "workspace_path" not in proj_cols:
            self._conn.execute(
                "ALTER TABLE projects ADD COLUMN workspace_path TEXT"
            )
        if "git_url" not in proj_cols:
            self._conn.execute(
                "ALTER TABLE projects ADD COLUMN git_url TEXT"
            )
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Projects
    # ------------------------------------------------------------------

    def create_project(
        self,
        project_id: str,
        name: str,
        repo_path: str,
        default_branch: str = "main",
        index_mode: str = "mount",
        workspace_path: str | None = None,
        git_url: str | None = None,
    ) -> dict[str, Any]:
        now = _now()
        self._conn.execute(
            "INSERT INTO projects "
            "(id, name, repo_path, default_branch, index_mode, workspace_path, git_url, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (project_id, name, repo_path, default_branch, index_mode, workspace_path, git_url, now, now),
        )
        self._conn.commit()
        return self.get_project(project_id)  # type: ignore[return-value]

    def get_project(self, project_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        ).fetchone()
        return dict(row) if row else None

    def list_projects(self) -> list[dict[str, Any]]:
        rows = self._conn.execute("SELECT * FROM projects ORDER BY name").fetchall()
        return [dict(r) for r in rows]

    def delete_project(self, project_id: str) -> bool:
        cur = self._conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def update_project(
        self,
        project_id: str,
        default_branch: str | None = None,
        index_mode: str | None = None,
        workspace_path: str | None = None,
    ) -> dict[str, Any] | None:
        parts: list[str] = ["updated_at = ?"]
        vals: list[Any] = [_now()]
        if default_branch is not None:
            parts.append("default_branch = ?")
            vals.append(default_branch)
        if index_mode is not None:
            parts.append("index_mode = ?")
            vals.append(index_mode)
        if workspace_path is not None:
            parts.append("workspace_path = ?")
            vals.append(workspace_path)
        vals.append(project_id)
        self._conn.execute(
            f"UPDATE projects SET {', '.join(parts)} WHERE id = ?", vals
        )
        self._conn.commit()
        return self.get_project(project_id)

    def count_projects(self) -> int:
        row = self._conn.execute("SELECT COUNT(*) FROM projects").fetchone()
        return row[0]

    # ------------------------------------------------------------------
    # Branch indexes
    # ------------------------------------------------------------------

    def register_branch(
        self,
        project_id: str,
        branch: str,
        index_path: str,
        parent_branch: str | None = None,
    ) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO branch_indexes (project_id, branch, index_path, parent_branch) "
            "VALUES (?, ?, ?, ?)",
            (project_id, branch, index_path, parent_branch),
        )
        self._conn.commit()

    def update_branch_status(
        self,
        project_id: str,
        branch: str,
        *,
        status: str | None = None,
        last_commit: str | None = None,
        symbol_count: int | None = None,
        edge_count: int | None = None,
    ) -> None:
        parts: list[str] = []
        vals: list[Any] = []
        if status is not None:
            parts.append("status = ?")
            vals.append(status)
            if status == "ready":
                parts.append("indexed_at = ?")
                vals.append(_now())
        if last_commit is not None:
            parts.append("last_commit = ?")
            vals.append(last_commit)
        if symbol_count is not None:
            parts.append("symbol_count = ?")
            vals.append(symbol_count)
        if edge_count is not None:
            parts.append("edge_count = ?")
            vals.append(edge_count)
        if not parts:
            return
        vals.extend([project_id, branch])
        self._conn.execute(
            f"UPDATE branch_indexes SET {', '.join(parts)} "
            "WHERE project_id = ? AND branch = ?",
            vals,
        )
        self._conn.commit()

    def get_branch(self, project_id: str, branch: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM branch_indexes WHERE project_id = ? AND branch = ?",
            (project_id, branch),
        ).fetchone()
        return dict(row) if row else None

    def list_branches(self, project_id: str) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM branch_indexes WHERE project_id = ? ORDER BY branch",
            (project_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def delete_branch(self, project_id: str, branch: str) -> bool:
        cur = self._conn.execute(
            "DELETE FROM branch_indexes WHERE project_id = ? AND branch = ?",
            (project_id, branch),
        )
        self._conn.commit()
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    # Index jobs
    # ------------------------------------------------------------------

    def create_job(
        self,
        project_id: str,
        branch: str,
        mode: str = "full",
    ) -> int:
        cur = self._conn.execute(
            "INSERT INTO index_jobs_server (project_id, branch, mode, status, started_at) "
            "VALUES (?, ?, ?, 'queued', ?)",
            (project_id, branch, mode, _now()),
        )
        self._conn.commit()
        return cur.lastrowid  # type: ignore[return-value]

    def get_job(self, job_id: int) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM index_jobs_server WHERE id = ?", (job_id,)
        ).fetchone()
        return dict(row) if row else None

    def update_job(
        self,
        job_id: int,
        *,
        status: str | None = None,
        progress_pct: int | None = None,
        current_phase: str | None = None,
        failure_reason: str | None = None,
    ) -> None:
        parts: list[str] = []
        vals: list[Any] = []
        if status is not None:
            parts.append("status = ?")
            vals.append(status)
            if status in ("done", "failed", "cancelled"):
                parts.append("ended_at = ?")
                vals.append(_now())
        if progress_pct is not None:
            parts.append("progress_pct = ?")
            vals.append(progress_pct)
        if current_phase is not None:
            parts.append("current_phase = ?")
            vals.append(current_phase)
        if failure_reason is not None:
            parts.append("failure_reason = ?")
            vals.append(failure_reason)
        if not parts:
            return
        vals.append(job_id)
        self._conn.execute(
            f"UPDATE index_jobs_server SET {', '.join(parts)} WHERE id = ?",
            vals,
        )
        self._conn.commit()

    def get_active_job(self, project_id: str, branch: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM index_jobs_server "
            "WHERE project_id = ? AND branch = ? AND status IN ('queued', 'running') "
            "ORDER BY id DESC LIMIT 1",
            (project_id, branch),
        ).fetchone()
        return dict(row) if row else None

    def count_active_jobs(self) -> int:
        """Count jobs currently running."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM index_jobs_server WHERE status = 'running'"
        ).fetchone()
        return row[0]

    def count_queued_jobs(self) -> int:
        """Count jobs waiting to run."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM index_jobs_server WHERE status = 'queued'"
        ).fetchone()
        return row[0]

    def list_jobs(
        self, project_id: str | None = None, limit: int = 50
    ) -> list[dict[str, Any]]:
        if project_id:
            rows = self._conn.execute(
                "SELECT * FROM index_jobs_server WHERE project_id = ? "
                "ORDER BY id DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM index_jobs_server ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]
