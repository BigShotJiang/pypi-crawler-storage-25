"""Phase 3 — Resolve: cross-file import and call resolution."""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any

from ravmem.storage.schema import Edge, File, Symbol

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared parser cache (lazy init, one parser per language)
# ---------------------------------------------------------------------------

_LANG_PARSERS: dict[str, Any] = {}


def _get_lang_parser(lang: str) -> Any | None:
    """Return a cached Tree-sitter Parser for any supported language."""
    if lang in _LANG_PARSERS:
        return _LANG_PARSERS[lang]
    try:
        from tree_sitter import Language, Parser  # noqa: PLC0415
        if lang == "typescript":
            import tree_sitter_typescript as m  # noqa: PLC0415
            lang_obj = Language(m.language_typescript())
        elif lang == "javascript":
            import tree_sitter_typescript as m  # noqa: PLC0415
            lang_obj = Language(m.language_tsx())
        elif lang == "python":
            import tree_sitter_python as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "go":
            import tree_sitter_go as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "java":
            import tree_sitter_java as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "csharp":
            import tree_sitter_c_sharp as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "php":
            import tree_sitter_php as m  # noqa: PLC0415
            fn = getattr(m, "language_php", None) or m.language
            lang_obj = Language(fn())
        elif lang == "rust":
            import tree_sitter_rust as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "kotlin":
            import tree_sitter_kotlin as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "ruby":
            import tree_sitter_ruby as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "c":
            import tree_sitter_c as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        elif lang == "cpp":
            import tree_sitter_cpp as m  # noqa: PLC0415
            lang_obj = Language(m.language())
        else:
            _LANG_PARSERS[lang] = None
            return None
        p = Parser(lang_obj)
        _LANG_PARSERS[lang] = p
        return p
    except Exception as exc:
        logger.debug("tree-sitter not available for %s: %s", lang, exc)
        _LANG_PARSERS[lang] = None
        return None


# Backward-compat alias used by JS/TS AST call resolution below
_get_ts_parser = _get_lang_parser


# ---------------------------------------------------------------------------
# Index builders
# ---------------------------------------------------------------------------

def _build_name_index(symbols: list[Symbol]) -> dict[str, list[Symbol]]:
    """Map bare name → list of symbols with that name."""
    idx: dict[str, list[Symbol]] = {}
    for s in symbols:
        bare = s.name.split(".")[-1]
        idx.setdefault(bare, []).append(s)
        idx.setdefault(s.name, []).append(s)
    return idx


def _build_file_index(files: list[File]) -> dict[str, File]:
    return {f.path: f for f in files}


_JAVA_PACKAGE_RE = re.compile(r"^\s*package\s+([\w.]+)\s*;", re.MULTILINE)
_KOTLIN_PACKAGE_RE = re.compile(r"^\s*package\s+([\w.]+)", re.MULTILINE)


def _build_java_package_index(file_index: dict[str, File]) -> dict[str, list[str]]:
    """Map Java class by FQN ('com.example.Foo') and by stem ('Foo') → file paths.

    Reads only the first 512 bytes of each .java file to extract the package declaration.
    FQN keys are added when a package is found; stem keys are always added as a fallback.
    """
    idx: dict[str, list[str]] = {}
    for path in file_index:
        if not path.endswith(".java"):
            continue
        stem = Path(path).stem
        idx.setdefault(stem, []).append(path)
        try:
            with open(path, errors="replace") as fh:
                header = fh.read(512)
            pkg_m = _JAVA_PACKAGE_RE.search(header)
            if pkg_m:
                idx.setdefault(f"{pkg_m.group(1)}.{stem}", []).append(path)
        except Exception:
            pass
    return idx


def _build_kotlin_package_index(file_index: dict[str, File]) -> dict[str, list[str]]:
    """Map Kotlin class by FQN ('com.example.Foo') and by stem ('Foo') → file paths.

    Reads only the first 512 bytes of each .kt/.kts file to extract the package declaration.
    """
    idx: dict[str, list[str]] = {}
    for path in file_index:
        if not path.endswith((".kt", ".kts")):
            continue
        stem = Path(path).stem
        idx.setdefault(stem, []).append(path)
        try:
            with open(path, errors="replace") as fh:
                header = fh.read(512)
            pkg_m = _KOTLIN_PACKAGE_RE.search(header)
            if pkg_m:
                idx.setdefault(f"{pkg_m.group(1)}.{stem}", []).append(path)
        except Exception:
            pass
    return idx


_CS_NAMESPACE_RE = re.compile(r"^\s*namespace\s+([\w.]+)", re.MULTILINE)


def _build_namespace_index(files: list[File]) -> dict[str, list[str]]:
    """Build C# namespace → list of file paths index (read once per run)."""
    ns_index: dict[str, list[str]] = {}
    for f in files:
        if f.lang != "csharp":
            continue
        try:
            source = Path(f.path).read_text(errors="replace")
            for m in _CS_NAMESPACE_RE.finditer(source):
                ns = m.group(1)
                ns_index.setdefault(ns, []).append(f.path)
        except Exception:
            pass
    return ns_index


# ---------------------------------------------------------------------------
# Shared call-edge helpers
# ---------------------------------------------------------------------------

_MAX_CANDIDATES = 8


def _enclosing_sym_at_line(
    line: int,
    file_path: str,
    file_symbols: list[Symbol],
) -> str:
    """Return the ID of the tightest enclosing symbol at *line* (1-based)."""
    best: Symbol | None = None
    for sym in file_symbols:
        if sym.file == file_path and sym.line_start <= line <= sym.line_end:
            if best is None or sym.line_start > best.line_start:
                best = sym
    if best:
        return best.id
    before = [s for s in file_symbols if s.file == file_path and s.line_start <= line]
    if before:
        return max(before, key=lambda s: s.line_start).id
    return file_path


def _emit_call_edges_from_sites(
    call_sites: list[tuple[str, int]],
    file: File,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
    builtins: frozenset[str],
    confidence: float = 0.6,
) -> list[Edge]:
    """Turn (callee_name, line_1based) pairs into call edges."""
    if not file_symbols:
        return []
    edges: list[Edge] = []
    file_sym_ids = {s.id for s in file_symbols if s.file == file.path}
    seen: set[tuple[str, str]] = set()
    for callee_name, line in call_sites:
        if callee_name in builtins:
            continue
        candidates = name_index.get(callee_name, [])
        if not candidates or len(candidates) > _MAX_CANDIDATES:
            continue
        src_id = _enclosing_sym_at_line(line, file.path, file_symbols)
        for callee in candidates:
            if callee.id in file_sym_ids:
                continue
            pair = (src_id, callee.id)
            if pair in seen:
                continue
            seen.add(pair)
            edges.append(Edge(
                src_id=src_id, dst_id=callee.id, kind="calls",
                confidence=confidence, resolved=True,
            ))
    return edges


# ---------------------------------------------------------------------------
# Python import resolution
# ---------------------------------------------------------------------------

_PY_IMPORT_RE = re.compile(
    r"^(?:from\s+(\.+[\w.]*|[\w.]+)\s+import\s+([\w,\s*]+)|import\s+([\w.,\s]+))",
    re.MULTILINE,
)


def _resolve_python_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
    repo_root: Path,
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _PY_IMPORT_RE.finditer(source):
        module, names, plain = m.group(1), m.group(2), m.group(3)
        if module:
            if module.startswith("."):
                dot_count = len(module) - len(module.lstrip("."))
                rel_module = module.lstrip(".")
                base = Path(file.path).parent
                for _ in range(dot_count - 1):
                    base = base.parent
                if rel_module:
                    rel_path = rel_module.replace(".", "/")
                    candidates = [
                        base / f"{rel_path}.py",
                        base / rel_path / "__init__.py",
                    ]
                else:
                    candidates = [base / "__init__.py"]
            else:
                rel_path = module.replace(".", "/")
                candidates = [
                    repo_root / f"{rel_path}.py",
                    repo_root / rel_path / "__init__.py",
                ]
            for candidate in candidates:
                candidate_str = str(candidate.resolve())
                if candidate_str in file_index:
                    bindings = [n.strip() for n in names.split(",") if n.strip()] if names else []
                    edges.append(Edge(
                        src_id=file.path,
                        dst_id=candidate_str,
                        kind="imports",
                        binding=",".join(bindings),
                    ))
                    break
    return edges


# ---------------------------------------------------------------------------
# TypeScript/JavaScript import resolution
# ---------------------------------------------------------------------------

_TS_IMPORT_RE = re.compile(
    r"""(?:import\s+(?:\{[^}]*\}|\w+)\s+from\s+['"]([^'"]+)['"]|"""
    r"""require\s*\(\s*['"]([^'"]+)['"]\s*\))""",
    re.MULTILINE,
)


def _resolve_ts_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    edges: list[Edge] = []
    file_dir = Path(file.path).parent
    for m in _TS_IMPORT_RE.finditer(source):
        specifier = m.group(1) or m.group(2)
        if not specifier or not specifier.startswith("."):
            continue
        for ext in [".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.js"]:
            candidate = str((file_dir / (specifier + ext)).resolve())
            if candidate in file_index:
                edges.append(Edge(src_id=file.path, dst_id=candidate, kind="imports"))
                break
    return edges


# ---------------------------------------------------------------------------
# JS/TS call resolution — Tree-sitter AST-based
# ---------------------------------------------------------------------------

_JS_BUILTINS: frozenset[str] = frozenset({
    "console", "setTimeout", "setInterval", "clearTimeout", "clearInterval",
    "Promise", "Math", "Object", "Array", "JSON", "parseInt", "parseFloat",
    "isNaN", "isFinite", "encodeURIComponent", "decodeURIComponent",
    "encodeURI", "decodeURI", "eval", "String", "Number", "Boolean",
    "Date", "RegExp", "Error", "Map", "Set", "WeakMap", "WeakSet",
    "Symbol", "Proxy", "Reflect", "Intl", "fetch", "require", "exports",
    "module", "process", "Buffer", "global", "window", "document",
    "undefined", "null", "NaN", "Infinity", "super",
})


def _extract_callee_name(call_node: Any, source: bytes) -> str | None:
    func_node = call_node.child_by_field_name("function")
    if func_node is None:
        return None
    if func_node.type == "identifier":
        name = source[func_node.start_byte:func_node.end_byte].decode(errors="replace")
        return name if name not in _JS_BUILTINS else None
    if func_node.type == "member_expression":
        prop = func_node.child_by_field_name("property")
        if prop is None:
            return None
        obj = func_node.child_by_field_name("object")
        if obj is not None:
            obj_name = source[obj.start_byte:obj.end_byte].decode(errors="replace")
            if obj_name in _JS_BUILTINS:
                return None
        name = source[prop.start_byte:prop.end_byte].decode(errors="replace")
        return name if name not in _JS_BUILTINS else None
    return None


def _find_enclosing_function_sym(
    node: Any,
    file_path: str,
    file_symbols: list[Symbol],
) -> str:
    _FUNC_TYPES = frozenset({
        "function_declaration", "function_expression",
        "arrow_function", "method_definition",
    })
    parent = node.parent
    while parent is not None:
        if parent.type in _FUNC_TYPES:
            enclosing_line = parent.start_point[0] + 1
            best: Symbol | None = None
            for sym in file_symbols:
                if sym.file == file_path and sym.line_start <= enclosing_line <= sym.line_end:
                    if best is None or sym.line_start > best.line_start:
                        best = sym
            if best is not None:
                return best.id
            break
        parent = parent.parent
    call_line = node.start_point[0] + 1
    best = None
    for sym in file_symbols:
        if sym.file == file_path and sym.line_start <= call_line:
            if best is None or sym.line_start > best.line_start:
                best = sym
    return best.id if best else file_path


def _collect_call_expressions(node: Any, results: list[Any]) -> None:
    if node.type in ("call_expression", "new_expression"):
        results.append(node)
    for child in node.children:
        _collect_call_expressions(child, results)


def _resolve_js_ts_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    parser = _get_ts_parser(file.lang)
    if parser is None:
        return []
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.warning("Failed to parse %s for call resolution: %s", file.path, exc)
        return []

    call_nodes: list[Any] = []
    _collect_call_expressions(tree.root_node, call_nodes)

    edges: list[Edge] = []
    seen: set[tuple[str, str]] = set()

    for call_node in call_nodes:
        if call_node.type == "new_expression":
            constructor = call_node.child_by_field_name("constructor")
            if constructor is None:
                continue
            callee_name = source[constructor.start_byte:constructor.end_byte].decode(errors="replace")
            if callee_name in _JS_BUILTINS:
                continue
        else:
            callee_name = _extract_callee_name(call_node, source)
            if not callee_name:
                continue

        candidates = name_index.get(callee_name, [])
        if not candidates:
            continue

        src_id = _find_enclosing_function_sym(call_node, file.path, file_symbols)

        for callee_sym in candidates:
            if callee_sym.id == src_id:
                continue
            pair = (src_id, callee_sym.id)
            if pair in seen:
                continue
            seen.add(pair)
            edges.append(Edge(
                src_id=src_id,
                dst_id=callee_sym.id,
                kind="calls",
                confidence=0.6,
                resolved=True,
            ))

    return edges


# ---------------------------------------------------------------------------
# Python call resolution (regex-based)
# ---------------------------------------------------------------------------

_PY_CALL_RE = re.compile(r"(\w+)\s*\(")

_PY_BUILTINS: frozenset[str] = frozenset({
    "if", "for", "while", "with", "print", "len", "range", "isinstance",
    "type", "super", "self", "cls", "return", "yield", "lambda", "assert",
    "raise", "pass", "break", "continue", "del", "exec", "eval",
    "str", "int", "float", "bool", "list", "dict", "set", "tuple",
    "bytes", "bytearray", "memoryview", "object", "property",
    "staticmethod", "classmethod", "abs", "all", "any", "bin", "chr",
    "dir", "divmod", "enumerate", "filter", "format", "getattr", "globals",
    "hasattr", "hash", "hex", "id", "input", "iter", "locals", "map",
    "max", "min", "next", "oct", "open", "ord", "pow", "repr", "reversed",
    "round", "setattr", "slice", "sorted", "sum", "vars", "zip",
    "Exception", "ValueError", "TypeError", "KeyError", "IndexError",
    "AttributeError", "RuntimeError", "StopIteration", "NotImplementedError",
    "OSError", "IOError", "FileNotFoundError", "ImportError", "NameError",
})


def _resolve_python_calls(
    file: File,
    source: str,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    if not file_symbols:
        return []

    edges: list[Edge] = []
    file_sym_ids = {s.id for s in file_symbols if s.file == file.path}
    seen: set[tuple[str, str]] = set()

    for m in _PY_CALL_RE.finditer(source):
        callee_name = m.group(1)
        if callee_name in _PY_BUILTINS:
            continue
        candidates = name_index.get(callee_name, [])
        if not candidates or len(candidates) > _MAX_CANDIDATES:
            continue
        src_id = _nearest_symbol_id(file.path, m.start(), file_symbols, source)
        for callee in candidates:
            if callee.id in file_sym_ids:
                continue
            pair = (src_id, callee.id)
            if pair in seen:
                continue
            seen.add(pair)
            edges.append(Edge(
                src_id=src_id,
                dst_id=callee.id,
                kind="calls",
                confidence=0.6,
                resolved=True,
            ))
    return edges


def _nearest_symbol_id(
    file_path: str, byte_offset: int, symbols: list[Symbol], source: str = ""
) -> str:
    """Find the symbol whose line range encloses the given character offset.

    When source is provided (the file text), converts offset to line number and
    finds the innermost enclosing symbol. Falls back to last symbol in file when
    no enclosing match is found (handles code outside any function).
    """
    if source:
        line = source[:byte_offset].count("\n") + 1
        best: Symbol | None = None
        for s in symbols:
            if s.file == file_path and s.line_start <= line <= s.line_end:
                if best is None or s.line_start > best.line_start:
                    best = s
        if best:
            return best.id
    # Fallback: last-defined symbol in file (for callers that omit source)
    best = None
    for s in symbols:
        if s.file == file_path:
            if best is None or s.line_start > best.line_start:
                best = s
    return best.id if best else file_path


# ---------------------------------------------------------------------------
# Python inheritance
# ---------------------------------------------------------------------------

_PY_CLASS_RE = re.compile(r"^class\s+(\w+)\s*\(([^)]+)\)", re.MULTILINE)


def _resolve_python_inheritance(
    file: File,
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _PY_CLASS_RE.finditer(source):
        child_name = m.group(1)
        parents = [p.strip() for p in m.group(2).split(",")]
        child_syms = name_index.get(child_name, [])
        for parent_name in parents:
            parent_name = parent_name.split(".")[-1]
            parent_syms = name_index.get(parent_name, [])
            for child_sym in child_syms:
                for parent_sym in parent_syms:
                    if child_sym.id != parent_sym.id:
                        edges.append(Edge(
                            src_id=child_sym.id,
                            dst_id=parent_sym.id,
                            kind="inherits",
                        ))
    return edges


# ---------------------------------------------------------------------------
# Java resolution
# ---------------------------------------------------------------------------

_JAVA_IMPORT_RE = re.compile(r"^import\s+(?:static\s+)?([\w.]+);", re.MULTILINE)
_JAVA_EXTENDS_RE = re.compile(r"\bclass\s+(\w+)[^{]*?\bextends\s+([\w.]+)", re.DOTALL)
_JAVA_IMPLEMENTS_RE = re.compile(
    r"\bclass\s+(\w+)[^{]*?\bimplements\s+([\w\s,.]+?)(?=\{)", re.DOTALL
)
_JAVA_IEXTENDS_RE = re.compile(
    r"\binterface\s+(\w+)[^{]*?\bextends\s+([\w\s,.]+?)(?=\{)", re.DOTALL
)


def _resolve_java_imports(
    file: File,
    source: str,
    java_package_index: dict[str, list[str]],
) -> list[Edge]:
    """Resolve `import com.example.Foo` → Foo.java.

    Tries the full FQN first (package-aware), falls back to stem-only matching.
    Skips wildcards and lowercase (static/package-level) imports.
    """
    edges: list[Edge] = []
    for m in _JAVA_IMPORT_RE.finditer(source):
        fqn = m.group(1)
        class_name = fqn.split(".")[-1]
        if not class_name or class_name == "*" or class_name[0].islower():
            continue
        # FQN key first (e.g. "com.example.Foo") then stem fallback ("Foo")
        candidates = java_package_index.get(fqn) or java_package_index.get(class_name, [])
        for candidate_path in candidates:
            if candidate_path != file.path:
                edges.append(Edge(src_id=file.path, dst_id=candidate_path, kind="imports"))
    return edges


def _resolve_java_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _JAVA_EXTENDS_RE.finditer(source):
        child_name, parent_name = m.group(1), m.group(2).split(".")[-1]
        _add_inherits(child_name, [parent_name], name_index, edges)
    for m in _JAVA_IMPLEMENTS_RE.finditer(source):
        child_name = m.group(1)
        ifaces = [i.strip().split(".")[-1] for i in m.group(2).split(",") if i.strip()]
        _add_inherits(child_name, ifaces, name_index, edges)
    for m in _JAVA_IEXTENDS_RE.finditer(source):
        child_name = m.group(1)
        parents = [p.strip().split(".")[-1] for p in m.group(2).split(",") if p.strip()]
        _add_inherits(child_name, parents, name_index, edges)
    return edges


def _walk_java_calls(root: Any, source: bytes) -> list[tuple[str, int]]:
    """Collect (callee_name, line) for Java method_invocation and object_creation_expression."""
    sites: list[tuple[str, int]] = []

    def walk(node: Any) -> None:
        if node.type == "method_invocation":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = source[name_node.start_byte:name_node.end_byte].decode(errors="replace")
                sites.append((name, node.start_point[0] + 1))
        elif node.type == "object_creation_expression":
            type_node = node.child_by_field_name("type")
            if type_node:
                raw = source[type_node.start_byte:type_node.end_byte].decode(errors="replace")
                name = raw.split("<")[0].split(".")[-1].strip()
                if name:
                    sites.append((name, node.start_point[0] + 1))
        for child in node.children:
            walk(child)

    walk(root)
    return sites


def _resolve_java_ast_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    parser = _get_lang_parser("java")
    if parser is None:
        return _resolve_generic_calls(
            file, source.decode(errors="replace"),
            file_symbols, name_index, _LANG_BUILTINS["java"],
        )
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug("Java AST parse failed for %s: %s", file.path, exc)
        return []
    call_sites = _walk_java_calls(tree.root_node, source)
    return _emit_call_edges_from_sites(
        call_sites, file, file_symbols, name_index, _LANG_BUILTINS["java"], confidence=0.6,
    )


# ---------------------------------------------------------------------------
# C# resolution
# ---------------------------------------------------------------------------

_CS_USING_RE = re.compile(r"^using\s+(?:static\s+)?([\w.]+)\s*;", re.MULTILINE)
_CS_INHERITS_RE = re.compile(
    r"\b(?:class|struct|interface)\s+(\w+)[^:{]*:\s*([\w\s,<>.]+?)(?=\{|where\b)", re.DOTALL
)


def _resolve_csharp_imports(
    file: File,
    source: str,
    ns_index: dict[str, list[str]],
) -> list[Edge]:
    """Resolve C# `using MyNamespace;` to files that declare that namespace."""
    edges: list[Edge] = []
    for m in _CS_USING_RE.finditer(source):
        ns = m.group(1)
        for candidate_path in ns_index.get(ns, []):
            if candidate_path != file.path:
                edges.append(Edge(src_id=file.path, dst_id=candidate_path, kind="imports"))
    return edges


def _resolve_csharp_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _CS_INHERITS_RE.finditer(source):
        child_name = m.group(1)
        parents_raw = re.sub(r"<[^>]*>", "", m.group(2))
        parents = [p.strip() for p in parents_raw.split(",") if p.strip()]
        _add_inherits(child_name, parents, name_index, edges)
    return edges


def _walk_cs_calls(root: Any, source: bytes) -> list[tuple[str, int]]:
    """Collect (callee_name, line) for C# invocation_expression and object_creation_expression."""
    sites: list[tuple[str, int]] = []

    def walk(node: Any) -> None:
        if node.type == "invocation_expression":
            func_node = node.child_by_field_name("function")
            if func_node is not None:
                if func_node.type in ("identifier_name", "identifier"):
                    name = source[func_node.start_byte:func_node.end_byte].decode(errors="replace")
                    sites.append((name, node.start_point[0] + 1))
                elif func_node.type == "member_access_expression":
                    name_node = func_node.child_by_field_name("name")
                    if name_node:
                        name = source[name_node.start_byte:name_node.end_byte].decode(errors="replace")
                        sites.append((name, node.start_point[0] + 1))
        elif node.type == "object_creation_expression":
            type_node = node.child_by_field_name("type")
            if type_node:
                raw = source[type_node.start_byte:type_node.end_byte].decode(errors="replace")
                name = raw.split("<")[0].split(".")[-1].strip()
                if name:
                    sites.append((name, node.start_point[0] + 1))
        for child in node.children:
            walk(child)

    walk(root)
    return sites


def _resolve_cs_ast_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    parser = _get_lang_parser("csharp")
    if parser is None:
        return _resolve_generic_calls(
            file, source.decode(errors="replace"),
            file_symbols, name_index, _LANG_BUILTINS["csharp"],
        )
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug("C# AST parse failed for %s: %s", file.path, exc)
        return []
    call_sites = _walk_cs_calls(tree.root_node, source)
    return _emit_call_edges_from_sites(
        call_sites, file, file_symbols, name_index, _LANG_BUILTINS["csharp"], confidence=0.6,
    )


# ---------------------------------------------------------------------------
# PHP resolution
# ---------------------------------------------------------------------------

_PHP_LOCAL_RE = re.compile(
    r"""(?:require|require_once|include|include_once)\s*[\(]?\s*['"]([^'"]+)['"]\s*[\)]?\s*;""",
    re.MULTILINE,
)
_PHP_EXTENDS_RE = re.compile(r"\bclass\s+(\w+)[^{]*?\bextends\s+(\w+)", re.DOTALL)
_PHP_IMPLEMENTS_RE = re.compile(
    r"\bclass\s+(\w+)[^{]*?\bimplements\s+([\w\s,]+?)(?=\{)", re.DOTALL
)


def _resolve_php_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    edges: list[Edge] = []
    file_dir = Path(file.path).parent
    for m in _PHP_LOCAL_RE.finditer(source):
        target = m.group(1)
        if "/" in target or target.endswith(".php"):
            candidate = str((file_dir / target).resolve())
            if candidate in file_index:
                edges.append(Edge(src_id=file.path, dst_id=candidate, kind="imports"))
    return edges


def _resolve_php_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _PHP_EXTENDS_RE.finditer(source):
        _add_inherits(m.group(1), [m.group(2)], name_index, edges)
    for m in _PHP_IMPLEMENTS_RE.finditer(source):
        ifaces = [i.strip() for i in m.group(2).split(",") if i.strip()]
        _add_inherits(m.group(1), ifaces, name_index, edges)
    return edges


# ---------------------------------------------------------------------------
# Rust resolution
# ---------------------------------------------------------------------------

_RUST_MOD_RE = re.compile(
    r"^\s*(?:pub\s+(?:\([^)]*\)\s+)?)?mod\s+(\w+)\s*;", re.MULTILINE
)
_RUST_USE_RE = re.compile(r"^use\s+(crate|super|self)::([\w:{}*,\s]+);", re.MULTILINE)
_RUST_IMPL_TRAIT_RE = re.compile(
    r"\bimpl\s+(?:<[^>]*>\s+)?([\w:]+(?:<[^>]*>)?)\s+for\s+([\w:]+)", re.DOTALL
)


def _resolve_rust_mod_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    """Resolve `mod name;` → name.rs or name/mod.rs relative to this file."""
    edges: list[Edge] = []
    file_dir = Path(file.path).parent
    for m in _RUST_MOD_RE.finditer(source):
        mod_name = m.group(1)
        candidates = [
            file_dir / f"{mod_name}.rs",
            file_dir / mod_name / "mod.rs",
        ]
        for candidate in candidates:
            candidate_str = str(candidate.resolve())
            if candidate_str in file_index:
                edges.append(Edge(src_id=file.path, dst_id=candidate_str, kind="imports"))
                break
    return edges


def _find_rust_crate_src_root(file_path: str, file_index: dict[str, File]) -> Path | None:
    """Walk up from file_path to find the Rust crate src root.

    Returns the directory that contains lib.rs or main.rs (whichever is in the index).
    Returns None if the structure cannot be determined.
    """
    d = Path(file_path).parent
    seen: set[str] = set()
    while True:
        d_str = str(d.resolve())
        if d_str in seen:
            return None
        seen.add(d_str)
        for root_name in ("lib.rs", "main.rs"):
            if str((d / root_name).resolve()) in file_index:
                return d
        parent = d.parent
        if parent == d:
            return None
        d = parent


def _resolve_rust_use_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    """Resolve `use crate::a::b` → a/b.rs or a/b/mod.rs under the crate src root.

    Uses a longest-prefix-first search: `use crate::foo::Bar` tries foo/Bar.rs,
    foo/Bar/mod.rs, then foo.rs, then foo/mod.rs.  Only the most specific file
    found is emitted.  Brace-grouped imports (`use crate::foo::{A, B}`) are
    resolved to the common prefix module file.  super:: and self:: are skipped
    (require different relative resolution logic).
    """
    edges: list[Edge] = []
    src_root = _find_rust_crate_src_root(file.path, file_index)
    if src_root is None:
        return edges

    for m in _RUST_USE_RE.finditer(source):
        base, path_str = m.group(1), m.group(2).strip()
        if base != "crate":
            continue  # super:: / self:: require different relative resolution

        # Strip brace groups: `foo::{Bar, Baz}` → take "foo" prefix only
        if "{" in path_str:
            path_str = path_str.split("{")[0].rstrip(": \t")
        path_str = path_str.strip()
        if not path_str or "*" in path_str:
            continue

        segments = [s.strip() for s in path_str.split("::") if s.strip()]
        if not segments:
            continue

        # Try each prefix from longest to shortest; stop at the first file found
        found = False
        for length in range(len(segments), 0, -1):
            partial = "/".join(segments[:length])
            for candidate in (
                src_root / f"{partial}.rs",
                src_root / partial / "mod.rs",
            ):
                candidate_str = str(candidate.resolve())
                if candidate_str in file_index and candidate_str != file.path:
                    edges.append(Edge(src_id=file.path, dst_id=candidate_str, kind="imports"))
                    found = True
                    break
            if found:
                break

    return edges


def _resolve_rust_traits(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _RUST_IMPL_TRAIT_RE.finditer(source):
        trait_name = m.group(1).split("::")[-1].split("<")[0].strip()
        struct_name = m.group(2).split("::")[-1].strip()
        _add_inherits(struct_name, [trait_name], name_index, edges)
    return edges


def _walk_rust_calls(root: Any, source: bytes) -> list[tuple[str, int]]:
    """Collect (callee_name, line) for Rust call_expression and method_call_expression."""
    sites: list[tuple[str, int]] = []

    def walk(node: Any) -> None:
        if node.type == "call_expression":
            func_node = node.child_by_field_name("function")
            if func_node is not None:
                if func_node.type == "identifier":
                    name = source[func_node.start_byte:func_node.end_byte].decode(errors="replace")
                    sites.append((name, node.start_point[0] + 1))
                elif func_node.type == "scoped_identifier":
                    name_node = func_node.child_by_field_name("name")
                    if name_node:
                        name = source[name_node.start_byte:name_node.end_byte].decode(errors="replace")
                        sites.append((name, node.start_point[0] + 1))
                elif func_node.type == "field_expression":
                    field_node = func_node.child_by_field_name("field")
                    if field_node:
                        name = source[field_node.start_byte:field_node.end_byte].decode(errors="replace")
                        sites.append((name, node.start_point[0] + 1))
        elif node.type == "method_call_expression":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = source[name_node.start_byte:name_node.end_byte].decode(errors="replace")
                sites.append((name, node.start_point[0] + 1))
        for child in node.children:
            walk(child)

    walk(root)
    return sites


def _resolve_rust_ast_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    parser = _get_lang_parser("rust")
    if parser is None:
        return _resolve_generic_calls(
            file, source.decode(errors="replace"),
            file_symbols, name_index, _LANG_BUILTINS["rust"],
        )
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug("Rust AST parse failed for %s: %s", file.path, exc)
        return []
    call_sites = _walk_rust_calls(tree.root_node, source)
    return _emit_call_edges_from_sites(
        call_sites, file, file_symbols, name_index, _LANG_BUILTINS["rust"], confidence=0.6,
    )


# ---------------------------------------------------------------------------
# Kotlin resolution
# ---------------------------------------------------------------------------

_KOTLIN_IMPORT_RE = re.compile(r"^import\s+([\w.]+?)(?:\.\*)?\s*$", re.MULTILINE)
_KOTLIN_INHERITS_RE = re.compile(
    r"\b(?:class|interface|object)\s+(\w+)[^{:]*:\s*([\w\s,<>.()\n]+?)(?=\{|where\b|\n\{)", re.DOTALL
)


def _resolve_kotlin_imports(
    file: File,
    source: str,
    kotlin_package_index: dict[str, list[str]],
) -> list[Edge]:
    """Resolve `import com.example.Foo` → Foo.kt.

    Tries the full FQN first (package-aware), falls back to stem-only matching.
    """
    edges: list[Edge] = []
    for m in _KOTLIN_IMPORT_RE.finditer(source):
        fqn = m.group(1)
        class_name = fqn.split(".")[-1]
        if not class_name or class_name[0].islower():
            continue
        # FQN key first (e.g. "com.example.Foo") then stem fallback ("Foo")
        candidates = kotlin_package_index.get(fqn) or kotlin_package_index.get(class_name, [])
        for candidate_path in candidates:
            if candidate_path != file.path:
                edges.append(Edge(src_id=file.path, dst_id=candidate_path, kind="imports"))
    return edges


def _resolve_kotlin_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _KOTLIN_INHERITS_RE.finditer(source):
        child_name = m.group(1)
        parents_raw = re.sub(r"<[^>]*>|\([^)]*\)", "", m.group(2))
        parents = [p.strip() for p in parents_raw.split(",") if p.strip()]
        _add_inherits(child_name, parents, name_index, edges)
    return edges


def _walk_kotlin_calls(root: Any, source: bytes) -> list[tuple[str, int]]:
    """
    Collect (callee_name, line) for Kotlin call_expression nodes.
    Kotlin grammar: call_expression = callee_expr + call_suffix.
    The callee is the first child (simple_identifier or navigation_expression).
    """
    sites: list[tuple[str, int]] = []

    def walk(node: Any) -> None:
        if node.type == "call_expression":
            if node.child_count > 0:
                callee = node.children[0]
                if callee.type in ("simple_identifier", "identifier"):
                    name = source[callee.start_byte:callee.end_byte].decode(errors="replace")
                    sites.append((name, node.start_point[0] + 1))
                elif callee.type == "navigation_expression":
                    # obj.method(...) — take the rightmost simple_identifier
                    for child in reversed(callee.children):
                        if child.type in ("simple_identifier", "identifier"):
                            name = source[child.start_byte:child.end_byte].decode(errors="replace")
                            sites.append((name, node.start_point[0] + 1))
                            break
        for child in node.children:
            walk(child)

    walk(root)
    return sites


def _resolve_kotlin_ast_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    parser = _get_lang_parser("kotlin")
    if parser is None:
        return _resolve_generic_calls(
            file, source.decode(errors="replace"),
            file_symbols, name_index, _LANG_BUILTINS["kotlin"],
        )
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug("Kotlin AST parse failed for %s: %s", file.path, exc)
        return []
    call_sites = _walk_kotlin_calls(tree.root_node, source)
    return _emit_call_edges_from_sites(
        call_sites, file, file_symbols, name_index, _LANG_BUILTINS["kotlin"], confidence=0.6,
    )


# ---------------------------------------------------------------------------
# Ruby resolution
# ---------------------------------------------------------------------------

_RUBY_REQUIRE_RE = re.compile(r"""require_relative\s+['"]([^'"]+)['"]""", re.MULTILINE)
_RUBY_INHERITS_RE = re.compile(r"^class\s+(\w+)\s*<\s*([\w:]+)", re.MULTILINE)


def _resolve_ruby_imports(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    edges: list[Edge] = []
    file_dir = Path(file.path).parent
    for m in _RUBY_REQUIRE_RE.finditer(source):
        rel = m.group(1)
        for ext in [".rb", ""]:
            candidate = str((file_dir / (rel + ext)).resolve())
            if candidate in file_index:
                edges.append(Edge(src_id=file.path, dst_id=candidate, kind="imports"))
                break
    return edges


def _resolve_ruby_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    """Regex-based `class Foo < Bar` inheritance edges."""
    edges: list[Edge] = []
    for m in _RUBY_INHERITS_RE.finditer(source):
        child_name = m.group(1)
        parent_name = m.group(2).split("::")[-1]
        _add_inherits(child_name, [parent_name], name_index, edges)
    return edges


def _walk_ruby_calls_and_mixins(
    root: Any,
    source: bytes,
) -> tuple[list[tuple[str, int]], list[tuple[str, str]]]:
    """
    Walk Ruby AST and collect:
    - call_sites: (callee_name, line) for method calls
    - mixin_edges: (class_name, module_name) for include/extend/prepend with class context
    """
    call_sites: list[tuple[str, int]] = []
    mixin_edges: list[tuple[str, str]] = []
    _MIXIN_METHODS = frozenset({"include", "extend", "prepend"})

    def decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def walk(node: Any, class_ctx: str = "") -> None:
        if node.type == "class":
            name_node = node.child_by_field_name("name")
            if name_node:
                cname = decode(name_node)
                for child in node.children:
                    walk(child, class_ctx=cname)
                return
        elif node.type == "module":
            name_node = node.child_by_field_name("name")
            if name_node:
                mname = decode(name_node)
                for child in node.children:
                    walk(child, class_ctx=mname)
                return
        elif node.type == "call":
            receiver_node = node.child_by_field_name("receiver")
            method_node = node.child_by_field_name("method")
            if method_node is not None:
                method = decode(method_node)
                if receiver_node is None and method in _MIXIN_METHODS and class_ctx:
                    # include/extend/prepend inside a class body
                    args_node = node.child_by_field_name("arguments")
                    if args_node:
                        for arg in args_node.children:
                            if arg.type in ("constant", "scope_resolution"):
                                mod_name = decode(arg).split("::")[-1]
                                mixin_edges.append((class_ctx, mod_name))
                else:
                    call_sites.append((method, node.start_point[0] + 1))
        for child in node.children:
            walk(child, class_ctx=class_ctx)

    walk(root)
    return call_sites, mixin_edges


def _resolve_ruby_ast_calls(
    file: File,
    source: bytes,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    """AST-based: method call edges + include/extend/prepend → inherits edges."""
    parser = _get_lang_parser("ruby")
    if parser is None:
        return _resolve_generic_calls(
            file, source.decode(errors="replace"),
            file_symbols, name_index, _LANG_BUILTINS["ruby"],
        )
    try:
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug("Ruby AST parse failed for %s: %s", file.path, exc)
        return []

    call_sites, mixin_edges = _walk_ruby_calls_and_mixins(tree.root_node, source)

    edges = _emit_call_edges_from_sites(
        call_sites, file, file_symbols, name_index, _LANG_BUILTINS["ruby"], confidence=0.6,
    )
    for class_name, mod_name in mixin_edges:
        _add_inherits(class_name, [mod_name], name_index, edges)
    return edges


# ---------------------------------------------------------------------------
# C / C++ resolution
# ---------------------------------------------------------------------------

_C_INCLUDE_RE = re.compile(r'^#include\s+"([^"]+)"', re.MULTILINE)
_CPP_INHERITS_RE = re.compile(
    r"\bclass\s+(\w+)[^{;]*:\s*((?:(?:public|protected|private)\s+)?[\w:]+(?:\s*,\s*(?:public|protected|private)?\s*[\w:]+)*)",
    re.DOTALL,
)


def _resolve_c_includes(
    file: File,
    source: str,
    file_index: dict[str, File],
) -> list[Edge]:
    edges: list[Edge] = []
    file_dir = Path(file.path).parent
    for m in _C_INCLUDE_RE.finditer(source):
        header = m.group(1)
        candidate = str((file_dir / header).resolve())
        if candidate in file_index:
            edges.append(Edge(src_id=file.path, dst_id=candidate, kind="imports"))
    return edges


def _resolve_cpp_inheritance(
    source: str,
    name_index: dict[str, list[Symbol]],
) -> list[Edge]:
    edges: list[Edge] = []
    for m in _CPP_INHERITS_RE.finditer(source):
        child_name = m.group(1)
        parents_raw = re.sub(r"\b(?:public|protected|private)\b", "", m.group(2))
        parents_raw = re.sub(r"<[^>]*>", "", parents_raw)
        parents = [p.strip().split("::")[-1] for p in parents_raw.split(",") if p.strip()]
        _add_inherits(child_name, parents, name_index, edges)
    return edges


# ---------------------------------------------------------------------------
# Generic call resolution (regex-based, fallback for PHP / C / C++)
# ---------------------------------------------------------------------------

_GENERIC_CALL_RE = re.compile(r"(\w+)\s*\(")

_LANG_BUILTINS: dict[str, frozenset[str]] = {
    "java": frozenset({
        "if", "for", "while", "switch", "catch", "throw", "new", "return",
        "super", "this", "instanceof", "assert", "synchronized",
        "System", "String", "Integer", "Long", "Double", "Boolean",
        "Object", "Class", "Math", "Arrays", "List", "Map", "Set",
        "ArrayList", "HashMap", "HashSet", "Optional", "Stream",
        "StringBuilder", "StringBuffer", "Thread", "Exception",
        "RuntimeException", "IllegalArgumentException", "NullPointerException",
    }),
    "csharp": frozenset({
        "if", "for", "foreach", "while", "switch", "catch", "throw", "new",
        "return", "base", "this", "typeof", "nameof", "sizeof", "default",
        "string", "int", "long", "double", "float", "bool", "object",
        "var", "void", "async", "await", "Console", "Convert", "Math",
        "String", "Int32", "Exception", "List", "Dictionary", "Array",
        "Task", "Thread", "Enum", "Nullable",
    }),
    "php": frozenset({
        "if", "for", "foreach", "while", "switch", "catch", "throw",
        "new", "return", "echo", "print", "isset", "empty", "unset",
        "array", "count", "strlen", "substr", "strpos", "str_replace",
        "array_map", "array_filter", "array_push", "array_pop",
        "intval", "floatval", "strval", "is_null", "is_array", "is_string",
        "is_int", "is_bool", "header", "die", "exit", "include", "require",
    }),
    "rust": frozenset({
        "if", "for", "while", "loop", "match", "return", "break", "continue",
        "let", "mut", "fn", "impl", "trait", "struct", "enum", "use", "pub",
        "println", "print", "eprintln", "panic", "assert", "assert_eq",
        "assert_ne", "unwrap", "expect", "ok", "err", "map", "and_then",
        "or_else", "is_some", "is_none", "iter", "collect", "push", "pop",
        "len", "contains", "insert", "remove", "get", "new", "clone",
        "to_string", "from", "into", "as_ref", "as_mut",
        "Box", "Vec", "String", "HashMap", "HashSet", "Option", "Result",
        "Arc", "Mutex", "Rc", "RefCell",
    }),
    "kotlin": frozenset({
        "if", "for", "while", "when", "try", "catch", "throw", "return",
        "break", "continue", "super", "this", "it", "apply", "also",
        "let", "run", "with", "listOf", "mapOf", "setOf", "mutableListOf",
        "mutableMapOf", "arrayOf", "println", "print", "require", "check",
        "error", "TODO",
        "String", "Int", "Long", "Double", "Float", "Boolean", "Unit",
        "Any", "Nothing", "List", "Map", "Set", "Array",
    }),
    "ruby": frozenset({
        "if", "unless", "while", "until", "for", "each", "map", "select",
        "reject", "reduce", "inject", "puts", "print", "p", "pp",
        "require", "require_relative", "include", "extend", "attr_reader",
        "attr_writer", "attr_accessor", "raise", "rescue", "ensure",
        "new", "initialize", "super", "self",
        "String", "Integer", "Float", "Array", "Hash", "Symbol", "Range",
        "Regexp", "Proc", "Lambda", "IO", "File",
    }),
    "c": frozenset({
        "if", "for", "while", "switch", "return", "break", "continue",
        "sizeof", "malloc", "calloc", "realloc", "free", "printf", "fprintf",
        "scanf", "fopen", "fclose", "fread", "fwrite", "memcpy", "memset",
        "strlen", "strcpy", "strcat", "strcmp", "strncpy",
    }),
    "cpp": frozenset({
        "if", "for", "while", "switch", "return", "break", "continue",
        "sizeof", "new", "delete", "throw", "catch", "try",
        "malloc", "calloc", "realloc", "free", "printf", "fprintf",
        "cout", "cin", "endl", "std", "make_shared", "make_unique",
        "push_back", "emplace_back", "begin", "end", "size", "empty",
        "find", "insert", "erase", "clear", "at", "front", "back",
        "string", "vector", "map", "set", "pair", "tuple", "optional",
    }),
}


def _resolve_generic_calls(
    file: File,
    source: str,
    file_symbols: list[Symbol],
    name_index: dict[str, list[Symbol]],
    builtins: frozenset[str],
) -> list[Edge]:
    """
    Regex-based call resolution: any `word(` is a potential call site.
    Used for PHP / C / C++ where AST-based resolution is less practical,
    and as a fallback when a grammar package is not installed.
    """
    if not file_symbols:
        return []

    edges: list[Edge] = []
    file_sym_ids = {s.id for s in file_symbols if s.file == file.path}
    seen: set[tuple[str, str]] = set()

    for m in _GENERIC_CALL_RE.finditer(source):
        callee_name = m.group(1)
        if callee_name in builtins:
            continue
        candidates = name_index.get(callee_name, [])
        if not candidates or len(candidates) > _MAX_CANDIDATES:
            continue
        src_id = _nearest_symbol_id(file.path, m.start(), file_symbols, source)
        for callee in candidates:
            if callee.id in file_sym_ids:
                continue
            pair = (src_id, callee.id)
            if pair in seen:
                continue
            seen.add(pair)
            edges.append(Edge(
                src_id=src_id,
                dst_id=callee.id,
                kind="calls",
                confidence=0.5,
                resolved=True,
            ))
    return edges


# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------

def _add_inherits(
    child_name: str,
    parent_names: list[str],
    name_index: dict[str, list[Symbol]],
    edges: list[Edge],
) -> None:
    child_syms = name_index.get(child_name, [])
    for parent_name in parent_names:
        parent_syms = name_index.get(parent_name, [])
        for child_sym in child_syms:
            for parent_sym in parent_syms:
                if child_sym.id != parent_sym.id:
                    edges.append(Edge(
                        src_id=child_sym.id,
                        dst_id=parent_sym.id,
                        kind="inherits",
                    ))


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

_HEARTBEAT_SECS = 5.0
_HEARTBEAT_FILES = 100


def run(
    files: list[File],
    symbols: list[Symbol],
    repo_root: Path,
) -> list[Edge]:
    """Resolve cross-file imports, calls, and inheritance. Returns Edge list."""
    file_index = _build_file_index(files)
    name_index = _build_name_index(symbols)
    all_edges: list[Edge] = []

    # Pre-build per-language resolution indexes (built once, used per-file)
    java_package_index = _build_java_package_index(file_index)
    kotlin_package_index = _build_kotlin_package_index(file_index)
    ns_index = _build_namespace_index(files)

    total = len(files)
    last_log_time = time.monotonic()
    last_log_idx = 0

    for idx, f in enumerate(files):
        try:
            source = Path(f.path).read_text(errors="replace")
        except Exception as exc:
            logger.warning("Failed to read %s for resolution: %s", f.path, exc)
            continue

        file_symbols = [s for s in symbols if s.file == f.path]

        if f.lang == "python":
            all_edges.extend(_resolve_python_imports(f, source, file_index, repo_root))
            all_edges.extend(_resolve_python_calls(f, source, file_symbols, name_index))
            all_edges.extend(_resolve_python_inheritance(f, source, name_index))

        elif f.lang in ("typescript", "javascript"):
            all_edges.extend(_resolve_ts_imports(f, source, file_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_js_ts_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang == "java":
            all_edges.extend(_resolve_java_imports(f, source, java_package_index))
            all_edges.extend(_resolve_java_inheritance(source, name_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_java_ast_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang == "csharp":
            all_edges.extend(_resolve_csharp_imports(f, source, ns_index))
            all_edges.extend(_resolve_csharp_inheritance(source, name_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_cs_ast_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang == "php":
            all_edges.extend(_resolve_php_imports(f, source, file_index))
            all_edges.extend(_resolve_php_inheritance(source, name_index))
            all_edges.extend(_resolve_generic_calls(
                f, source, file_symbols, name_index, _LANG_BUILTINS["php"],
            ))

        elif f.lang == "rust":
            all_edges.extend(_resolve_rust_mod_imports(f, source, file_index))
            all_edges.extend(_resolve_rust_use_imports(f, source, file_index))
            all_edges.extend(_resolve_rust_traits(source, name_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_rust_ast_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang == "kotlin":
            all_edges.extend(_resolve_kotlin_imports(f, source, kotlin_package_index))
            all_edges.extend(_resolve_kotlin_inheritance(source, name_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_kotlin_ast_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang == "ruby":
            all_edges.extend(_resolve_ruby_imports(f, source, file_index))
            all_edges.extend(_resolve_ruby_inheritance(source, name_index))
            source_bytes = Path(f.path).read_bytes()
            all_edges.extend(_resolve_ruby_ast_calls(f, source_bytes, file_symbols, name_index))

        elif f.lang in ("c", "cpp"):
            all_edges.extend(_resolve_c_includes(f, source, file_index))
            if f.lang == "cpp":
                all_edges.extend(_resolve_cpp_inheritance(source, name_index))
            all_edges.extend(_resolve_generic_calls(
                f, source, file_symbols, name_index, _LANG_BUILTINS[f.lang],
            ))

        now = time.monotonic()
        files_since = idx - last_log_idx
        if files_since >= _HEARTBEAT_FILES or (now - last_log_time) >= _HEARTBEAT_SECS:
            logger.info(
                "  [resolve] %d/%d files processed, %d edges so far",
                idx + 1, total, len(all_edges),
            )
            last_log_time = now
            last_log_idx = idx

    logger.info("  [resolve] done — %d/%d files, %d edges total", total, total, len(all_edges))
    return all_edges
