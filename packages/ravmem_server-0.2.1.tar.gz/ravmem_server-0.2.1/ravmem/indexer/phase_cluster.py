"""Phase 4 — Cluster: Leiden (full index) + file-based (incremental).

Full index:   leidenalg (directed graph, deterministic) → Louvain fallback → file-based
Incremental:  file-based only (O(changed symbols), no graph construction)

Cluster ID prefixes
-------------------
  lc_<12hex>  — Leiden community (centroid-hash based, stable)
  fc_<12hex>  — file-based cluster (path-hash based, stable)
  c_<8hex>    — legacy Louvain cluster (kept when leidenalg unavailable)
"""

from __future__ import annotations

import hashlib
import logging
import time
from collections import Counter, defaultdict
from pathlib import Path

import networkx as nx

from ravmem.config import (
    CLUSTER_MAX_SIZE,
    CLUSTER_RESOLUTION,
    CLUSTER_SEED,
    CLUSTER_SUBCLUSTER_THRESHOLD,
)
from ravmem.storage.schema import Cluster, Edge, Symbol

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level availability check — logged once on first import
# ---------------------------------------------------------------------------

try:
    import igraph as ig
    import leidenalg
    _LEIDEN_AVAILABLE = True
    logger.info("[cluster] leidenalg available — full index will use Leiden")
except ImportError:
    ig = None  # type: ignore[assignment]
    leidenalg = None  # type: ignore[assignment]
    _LEIDEN_AVAILABLE = False
    logger.warning("[cluster] leidenalg not found — full index will fall back to Louvain")


# ---------------------------------------------------------------------------
# Stable ID helpers
# ---------------------------------------------------------------------------

def _stable_file_cluster_id(file_path: str) -> tuple[str, str]:
    """Return (cluster_id, label) for a file path.

    Package initializer files (__init__.py, index.ts, mod.rs, …) represent
    their package — cluster key is the parent directory so they share a cluster
    with the rest of the package when re-indexed together.
    """
    path = Path(file_path)
    if path.name in ("__init__.py", "__init__.ts", "mod.rs", "index.ts", "index.js"):
        key = str(path.parent)
        label = path.parent.name or path.stem
    else:
        key = file_path
        label = path.stem
    digest = hashlib.sha256(key.encode()).hexdigest()[:12]
    return f"fc_{digest}", label


def _stable_leiden_cluster_id(
    member_ids: list[str],
    ig_graph: "ig.Graph",
    node_to_id: dict[str, int],
) -> str:
    """Stable cluster ID anchored on the highest-in-degree (most-called) symbol.

    Tie-breaking: lexicographically smallest symbol ID among equal-indegree
    candidates — deterministic regardless of leidenalg version or iteration order.
    """
    centroid = min(
        member_ids,
        key=lambda sid: (
            -(ig_graph.indegree(node_to_id[sid]) if sid in node_to_id else 0),
            sid,
        ),
    )
    digest = hashlib.sha256(centroid.encode()).hexdigest()[:12]
    return f"lc_{digest}"


# ---------------------------------------------------------------------------
# Shared utilities
# ---------------------------------------------------------------------------

def _auto_label(member_ids: list[str], sym_map: dict[str, Symbol]) -> str:
    """Generate a human-readable cluster label from dominant symbol name fragments."""
    names = [sym_map[sid].name.split(".")[-1] for sid in member_ids if sid in sym_map]
    if not names:
        return "cluster"
    words: list[str] = []
    for name in names:
        parts = [p for p in name.replace("_", " ").split() if len(p) > 2]
        words.extend(parts)
    if not words:
        return names[0]
    most_common = Counter(words).most_common(2)
    return "_".join(w for w, _ in most_common)


def _cohesion_score(members: set[str], edges: list[Edge]) -> float:
    """Internal edge density = internal_edges / max_possible_directed_edges."""
    n = len(members)
    if n < 2:
        return 1.0
    internal = sum(
        1 for e in edges
        if e.src_id in members and e.dst_id in members
    )
    return internal / (n * (n - 1))


def _subcluster_large(
    members: list[Symbol],
    cluster_id: str,
    label: str,
    call_edges: list[Edge],
) -> tuple[list[Cluster], list[Edge]]:
    """Split an oversized cluster into sub-clusters capped at CLUSTER_SUBCLUSTER_THRESHOLD.

    Sub-clusters are built alphabetically (by symbol name) for determinism.
    IDs: <cluster_id>_0, <cluster_id>_1, …
    """
    members_sorted = sorted(members, key=lambda s: s.name)
    groups = [
        members_sorted[i:i + CLUSTER_SUBCLUSTER_THRESHOLD]
        for i in range(0, len(members_sorted), CLUSTER_SUBCLUSTER_THRESHOLD)
    ]
    clusters: list[Cluster] = []
    bt_edges: list[Edge] = []
    for idx, group in enumerate(groups):
        sub_id = f"{cluster_id}_{idx}"
        sub_label = f"{label}_{idx}"
        clusters.append(Cluster(
            id=sub_id,
            label=sub_label,
            cohesion_score=round(_cohesion_score({s.id for s in group}, call_edges), 4),
            size=len(group),
        ))
        for s in group:
            s.cluster_id = sub_id
            bt_edges.append(Edge(src_id=s.id, dst_id=sub_id, kind="belongs_to"))
    return clusters, bt_edges


# ---------------------------------------------------------------------------
# Algorithm implementations
# ---------------------------------------------------------------------------

def _run_file_based(symbols: list[Symbol]) -> tuple[list[Cluster], list[Edge]]:
    """O(n) file-path hash clustering. No graph construction needed.

    Every symbol is assigned to its source file's cluster. Package init files
    share the parent directory cluster. Clusters exceeding CLUSTER_MAX_SIZE
    are automatically subdivided.
    """
    if not symbols:
        return [], []

    file_groups: dict[str, list[Symbol]] = defaultdict(list)
    cid_label: dict[str, str] = {}
    for s in symbols:
        cid, lbl = _stable_file_cluster_id(s.file)
        file_groups[cid].append(s)
        cid_label[cid] = lbl

    clusters: list[Cluster] = []
    belongs_to_edges: list[Edge] = []

    for cid, members in file_groups.items():
        label = cid_label[cid]
        if len(members) > CLUSTER_MAX_SIZE:
            sub_c, sub_e = _subcluster_large(members, cid, label, [])
            clusters.extend(sub_c)
            belongs_to_edges.extend(sub_e)
        else:
            clusters.append(Cluster(
                id=cid,
                label=label,
                cohesion_score=1.0,
                size=len(members),
            ))
            for s in members:
                s.cluster_id = cid
                belongs_to_edges.append(Edge(src_id=s.id, dst_id=cid, kind="belongs_to"))

    return clusters, belongs_to_edges


def _run_leiden(
    symbols: list[Symbol],
    call_edges: list[Edge],
) -> tuple[list[Cluster], list[Edge]]:
    """Leiden community detection on a directed igraph.

    Stable IDs via centroid-hash (_stable_leiden_cluster_id).
    Large communities are subdivided by _subcluster_large.
    """
    sym_ids = {s.id for s in symbols}
    node_list = list(sym_ids)
    node_to_id = {nid: i for i, nid in enumerate(node_list)}

    ig_graph = ig.Graph(directed=True)
    ig_graph.add_vertices(len(node_list))
    valid_edges = [
        (node_to_id[e.src_id], node_to_id[e.dst_id])
        for e in call_edges
        if e.src_id in node_to_id and e.dst_id in node_to_id
    ]
    ig_graph.add_edges(valid_edges)

    logger.info(
        "  [cluster] Leiden: %d nodes, %d edges, resolution=%.2f, seed=%d",
        len(node_list), len(valid_edges), CLUSTER_RESOLUTION, CLUSTER_SEED,
    )
    t0 = time.monotonic()
    partition = leidenalg.find_partition(
        ig_graph,
        leidenalg.ModularityVertexPartition,
        seed=CLUSTER_SEED,
        n_iterations=-1,
    )
    logger.info(
        "  [cluster] Leiden done in %.1fs — %d communities",
        time.monotonic() - t0, len(partition),
    )

    # Group node indices → symbol IDs by community
    community_members: dict[int, list[str]] = {}
    for node_idx, comm_id in enumerate(partition.membership):
        sid = node_list[node_idx]
        community_members.setdefault(comm_id, []).append(sid)

    sym_map = {s.id: s for s in symbols}
    clusters: list[Cluster] = []
    belongs_to_edges: list[Edge] = []

    for comm_id, member_ids in community_members.items():
        cluster_id = _stable_leiden_cluster_id(member_ids, ig_graph, node_to_id)
        label = _auto_label(member_ids, sym_map)
        cohesion = _cohesion_score(set(member_ids), call_edges)

        if len(member_ids) > CLUSTER_MAX_SIZE:
            sub_c, sub_e = _subcluster_large(
                [sym_map[sid] for sid in member_ids if sid in sym_map],
                cluster_id, label, call_edges,
            )
            clusters.extend(sub_c)
            belongs_to_edges.extend(sub_e)
        else:
            clusters.append(Cluster(
                id=cluster_id,
                label=label,
                cohesion_score=round(cohesion, 4),
                size=len(member_ids),
            ))
            for sid in member_ids:
                belongs_to_edges.append(Edge(src_id=sid, dst_id=cluster_id, kind="belongs_to"))
                if sid in sym_map:
                    sym_map[sid].cluster_id = cluster_id

    return clusters, belongs_to_edges


def _run_louvain(
    symbols: list[Symbol],
    call_edges: list[Edge],
) -> tuple[list[Cluster], list[Edge]]:
    """Louvain community detection (python-louvain). Undirected graph.

    Fallback when leidenalg is unavailable. Uses legacy `c_` ID prefix.
    """
    import community as community_louvain  # may raise ImportError → propagated to caller

    sym_ids = {s.id for s in symbols}
    G = nx.Graph()
    G.add_nodes_from(sym_ids)
    for e in call_edges:
        if e.src_id in sym_ids and e.dst_id in sym_ids:
            G.add_edge(e.src_id, e.dst_id)

    logger.info("  [cluster] Louvain: %d nodes...", G.number_of_nodes())
    t0 = time.monotonic()
    partition: dict[str, int] = community_louvain.best_partition(G, random_state=CLUSTER_SEED)
    logger.info(
        "  [cluster] Louvain done in %.1fs — %d communities",
        time.monotonic() - t0, len(set(partition.values())),
    )

    community_members: dict[int, list[str]] = {}
    for sym_id, comm_id in partition.items():
        community_members.setdefault(comm_id, []).append(sym_id)

    sym_map = {s.id: s for s in symbols}
    clusters: list[Cluster] = []
    belongs_to_edges: list[Edge] = []

    for comm_id, member_ids in community_members.items():
        # Centroid-anchored ID (undirected degree as proxy)
        centroid = max(member_ids, key=lambda n: G.degree(n))
        sym = sym_map.get(centroid)
        if sym:
            key = f"{sym.file}::{sym.name}"
        else:
            key = ":".join(sorted(member_ids))
        cluster_id = "c_" + hashlib.sha256(key.encode()).hexdigest()[:8]

        label = _auto_label(member_ids, sym_map)
        cohesion = _cohesion_score(set(member_ids), call_edges)

        if len(member_ids) > CLUSTER_MAX_SIZE:
            sub_c, sub_e = _subcluster_large(
                [sym_map[sid] for sid in member_ids if sid in sym_map],
                cluster_id, label, call_edges,
            )
            clusters.extend(sub_c)
            belongs_to_edges.extend(sub_e)
        else:
            clusters.append(Cluster(
                id=cluster_id,
                label=label,
                cohesion_score=round(cohesion, 4),
                size=len(member_ids),
            ))
            for sid in member_ids:
                belongs_to_edges.append(Edge(src_id=sid, dst_id=cluster_id, kind="belongs_to"))
                if sid in sym_map:
                    sym_map[sid].cluster_id = cluster_id

    return clusters, belongs_to_edges


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(
    symbols: list[Symbol],
    edges: list[Edge],
) -> tuple[list[Cluster], list[Edge]]:
    """Full-index clustering entry point.

    Fallback chain: Leiden → Louvain → file-based (always available).
    Returns (clusters, belongs_to_edges).
    """
    call_edges = [e for e in edges if e.kind == "calls" and e.resolved]

    if len(call_edges) < 2:
        logger.warning(
            "[cluster] insufficient resolved call edges (%d) — using file-based clustering",
            len(call_edges),
        )
        return _run_file_based(symbols)

    if _LEIDEN_AVAILABLE:
        try:
            return _run_leiden(symbols, call_edges)
        except Exception as exc:
            logger.warning("[cluster] Leiden failed (%s) — falling back to Louvain", exc)

    try:
        return _run_louvain(symbols, call_edges)
    except ImportError:
        logger.error(
            "[cluster] neither leidenalg nor python-louvain found — "
            "using file-based clustering (reduced quality for full index)"
        )
        return _run_file_based(symbols)


def run_incremental(
    changed_symbols: list[Symbol],
) -> tuple[list[Cluster], list[Edge]]:
    """Incremental clustering entry point — file-based, O(changed symbols).

    Only the symbols from changed files are re-clustered. Unchanged inherited
    symbols keep their existing cluster_id (lc_* or fc_*) from the parent branch.
    No graph construction required.
    """
    if not changed_symbols:
        return [], []
    logger.info(
        "  [cluster] file-based clustering %d changed symbols...", len(changed_symbols)
    )
    return _run_file_based(changed_symbols)
