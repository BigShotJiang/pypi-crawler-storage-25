"""Phase 5 — Embed: generate vector embeddings and build BM25 index."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

import numpy as np

from ravmem._model_cache import get_embedding_model
from ravmem.config import EMBEDDING_MODEL, MODELS_DIR
from ravmem.storage.schema import Symbol
from ravmem.storage.vectors import VectorStore

logger = logging.getLogger(__name__)


def _build_embedding_text(s: Symbol) -> str:
    docstring = s.docstring.strip()[:200] if s.docstring else ""
    text = f"{s.kind} {s.name} in {Path(s.file).name}"
    if docstring:
        text += f": {docstring}"
    return text


def _load_model():
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    return get_embedding_model(EMBEDDING_MODEL, str(MODELS_DIR))


def run(
    symbols: list[Symbol],
    vector_store: VectorStore,
    bm25_path: Path,
    batch_size: int = 64,
) -> None:
    """Embed all symbols, store in VectorStore, and save BM25 corpus to disk."""
    if not symbols:
        return

    logger.info("  [embed] loading embedding model: %s", EMBEDDING_MODEL)
    t_model = time.monotonic()
    model = _load_model()
    logger.info("  [embed] model loaded in %.1fs", time.monotonic() - t_model)

    texts = [_build_embedding_text(s) for s in symbols]
    total_batches = (len(texts) + batch_size - 1) // batch_size
    logger.info(
        "  [embed] encoding %d symbols in %d batches of %d...",
        len(symbols), total_batches, batch_size,
    )

    # Generate embeddings in batches
    all_embeddings: list[np.ndarray] = []
    t_encode = time.monotonic()
    last_log = t_encode
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        batch_num = i // batch_size + 1
        embs = np.array(list(model.embed(batch)), dtype=np.float32)
        all_embeddings.append(embs)
        now = time.monotonic()
        if (now - last_log) >= 5.0 or batch_num == total_batches:
            logger.info(
                "  [embed] batch %d/%d done (%.1fs elapsed)",
                batch_num, total_batches, now - t_encode,
            )
            last_log = now

    embeddings = np.vstack(all_embeddings).astype(np.float32)

    symbol_ids = [s.id for s in symbols]
    int_ids = vector_store.add_symbols(symbol_ids, embeddings)
    vector_store.save()

    # Update embedding_id on each symbol
    for s, eid in zip(symbols, int_ids):
        s.embedding_id = eid

    # Persist BM25 corpus: list of {id, text, name, file, kind, line_start, line_end, lang}
    corpus = [
        {
            "id": s.id,
            "text": text,
            "name": s.name,
            "file": s.file,
            "kind": s.kind,
            "line_start": s.line_start,
            "line_end": s.line_end,
            "lang": s.lang,
            "cluster_id": s.cluster_id,
        }
        for s, text in zip(symbols, texts)
    ]
    bm25_path.write_text(json.dumps(corpus, indent=2))


def run_partial(
    removed_symbol_ids: list[str],
    new_symbols: list[Symbol],
    vector_store: VectorStore,
    bm25_path: Path,
    batch_size: int = 64,
) -> None:
    """Incrementally update the vector index and BM25 corpus.

    Only encodes ``new_symbols`` (symbols from modified/new files).
    Soft-deletes stale embeddings for ``removed_symbol_ids`` from the HNSW index.
    Patches the BM25 corpus JSON in-place rather than rewriting it from scratch.

    This is called by ``IndexPipeline._update_embed()`` during incremental runs.
    The existing ``run()`` function remains for full indexing.
    """
    # 1. Soft-delete stale embeddings from HNSW index
    removed = vector_store.remove_symbols(removed_symbol_ids)
    logger.info(
        "  [embed] partial: soft-deleted %d / %d stale embeddings",
        removed, len(removed_symbol_ids),
    )

    # 2. Load and patch BM25 corpus — remove stale entries
    removed_set = set(removed_symbol_ids)
    if bm25_path.exists():
        try:
            corpus: list[dict] = json.loads(bm25_path.read_text())
        except Exception:
            corpus = []
    else:
        corpus = []
    corpus = [entry for entry in corpus if entry.get("id") not in removed_set]

    # 3. Early exit if no new symbols to encode
    if not new_symbols:
        bm25_path.write_text(json.dumps(corpus, indent=2))
        vector_store.save()
        logger.info("  [embed] partial: no new symbols to encode — corpus patched only")
        return

    # 4. Load model and encode only new symbols
    logger.info("  [embed] partial: encoding %d new symbols...", len(new_symbols))
    t0 = time.monotonic()
    model = _load_model()
    texts = [_build_embedding_text(s) for s in new_symbols]
    total_batches = (len(texts) + batch_size - 1) // batch_size

    all_embeddings: list[np.ndarray] = []
    last_log = time.monotonic()
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        batch_num = i // batch_size + 1
        embs = np.array(list(model.embed(batch)), dtype=np.float32)
        all_embeddings.append(embs)
        now = time.monotonic()
        if (now - last_log) >= 5.0 or batch_num == total_batches:
            logger.info(
                "  [embed] partial: batch %d/%d (%.1fs)",
                batch_num, total_batches, now - t0,
            )
            last_log = now

    embeddings = np.vstack(all_embeddings).astype(np.float32)

    # 5. Add new embeddings to vector store and set embedding_id on symbols
    int_ids = vector_store.add_symbols([s.id for s in new_symbols], embeddings)
    for s, eid in zip(new_symbols, int_ids):
        s.embedding_id = eid

    # 6. Extend BM25 corpus with new entries and write back
    new_entries = [
        {
            "id": s.id,
            "text": text,
            "name": s.name,
            "file": s.file,
            "kind": s.kind,
            "line_start": s.line_start,
            "line_end": s.line_end,
            "lang": s.lang,
            "cluster_id": s.cluster_id,
        }
        for s, text in zip(new_symbols, texts)
    ]
    corpus.extend(new_entries)
    bm25_path.write_text(json.dumps(corpus, indent=2))

    # 7. Persist updated HNSW index
    vector_store.save()

    logger.info(
        "  [embed] partial: done — %d encoded, %d corpus entries total (%.1fs)",
        len(new_symbols), len(corpus), time.monotonic() - t0,
    )
