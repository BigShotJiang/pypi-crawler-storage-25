"""Indexing pipeline orchestrator — runs all 5 phases in sequence."""

from __future__ import annotations

import json
import logging
import subprocess
import time

import numpy as np
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

from ravmem.config import (
    BM25_INDEX_NAME,
    CONFIG_SNAPSHOT_NAME,
    DEFAULT_LANGS,
    GRAPH_SUBDIR,
    INDEX_DIR,
    META_DB_NAME,
    VECTORS_SUBDIR,
)
from ravmem.indexer import (
    phase_cluster,
    phase_embed,
    phase_parse,
    phase_resolve,
    phase_structure,
)
from ravmem.storage.graph_arcade import ArcadeGraphStore
from ravmem.storage.meta import MetaStore
from ravmem.storage.vectors import VectorStore

# Thresholds for triggering a full embedding rebuild during incremental indexing
_EMBED_DELETED_REBUILD_THRESHOLD = 0.30   # >30% of HNSW slots are soft-deleted
_EMBED_CHANGED_THRESHOLD = 0.50           # >50% of live symbols changed


@dataclass
class ProgressEvent:
    phase: str           # "structure" | "parse" | "resolve" | "cluster" | "embed" | "centrality" | "done"
    pct: int             # 0-100
    items_done: int = 0
    items_total: int = 0
    message: str = ""


@dataclass
class PipelineConfig:
    langs: list[str] = None  # type: ignore[assignment]
    embedding_model: str = "all-MiniLM-L6-v2"
    skip_embeddings: bool = False

    def __post_init__(self) -> None:
        if self.langs is None:
            self.langs = list(DEFAULT_LANGS)


class IndexPipeline:
    def __init__(
        self,
        repo_path: str | Path,
        config: PipelineConfig | None = None,
        on_progress: callable = None,  # type: ignore[assignment]
        on_progress_event: callable = None,  # type: ignore[assignment]  # NEW - receives ProgressEvent
        index_dir: Path | None = None,
        repo_id: str | None = None,
        branch: str | None = None,
        parent_branch: str | None = None,
    ) -> None:
        self.repo_path = Path(repo_path).resolve()
        self.config = config or PipelineConfig()
        self._on_progress = on_progress or (lambda msg: None)
        self._on_progress_event = on_progress_event

        # Allow callers to override repo_id (e.g. branch-aware server mode)
        self.repo_id = repo_id or self.repo_path.name

        # Allow callers to override the index directory (e.g. per-branch storage)
        self.index_dir = Path(index_dir) if index_dir else (self.repo_path / INDEX_DIR)
        self.index_dir.mkdir(parents=True, exist_ok=True)

        _branch = branch or "main"
        self.graph_store = ArcadeGraphStore(_branch, parent_branch, project_id=self.repo_id)
        self.graph_store.initialize_schema()

        self.vector_store = VectorStore(self.index_dir / VECTORS_SUBDIR)
        self.vector_store.initialize()

        self.meta_store = MetaStore(self.index_dir / META_DB_NAME)
        self.bm25_path = self.index_dir / BM25_INDEX_NAME

        # Prevent git from trying to track (and lock-conflict on) the index files
        gitignore = self.index_dir / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n")

    def close(self) -> None:
        """Close all storage handles (call on exit / after interruption)."""
        try:
            self.graph_store.close()
        except Exception:
            pass
        try:
            self.meta_store.close()
        except Exception:
            pass
        # Force CPython to release any deferred OS file handles (important on Windows).
        import gc
        gc.collect()

    def _log(self, msg: str) -> None:
        logger.info(msg)
        self._on_progress(msg)

    def _emit(self, event: ProgressEvent) -> None:
        if self._on_progress_event:
            self._on_progress_event(event)

    def _get_head_commit(self) -> str:
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_path), "rev-parse", "HEAD"],
                capture_output=True, text=True, timeout=5,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except Exception:
            return ""

    def run_full(self) -> None:
        """Run all 5 phases from scratch."""
        self.meta_store.register_repo(
            self.repo_id, self.repo_path.name,
            str(self.repo_path), self.config.langs,
        )
        job_id = self.meta_store.create_job(self.repo_id, mode="full")
        t_total = time.perf_counter()

        try:
            # Phase 1 — Structure
            t0 = time.perf_counter()
            self._emit(ProgressEvent("structure", 0, message="Walking file tree"))
            self._log("Phase 1/5: Walking file tree...")
            files = phase_structure.run(self.repo_path, langs=self.config.langs)
            self._log(f"  Found {len(files)} source files ({time.perf_counter()-t0:.1f}s)")
            self._emit(ProgressEvent("structure", 20, items_done=len(files), items_total=len(files)))
            self.graph_store.upsert_files(files)

            # Phase 2 — Parse
            t0 = time.perf_counter()
            self._emit(ProgressEvent("parse", 20, message="Parsing symbols"))
            self._log("Phase 2/5: Parsing symbols...")
            symbols, contains_edges = phase_parse.run(files)
            self._log(f"  Extracted {len(symbols)} symbols ({time.perf_counter()-t0:.1f}s)")
            self._emit(ProgressEvent("parse", 40, items_done=len(symbols), items_total=len(files)))
            t0 = time.perf_counter()
            self._log(f"  Persisting {len(symbols)} symbols to graph DB...")
            self.graph_store.upsert_symbols(symbols)
            self._log(f"  Persisting {len(contains_edges)} contains-edges to graph DB...")
            self.graph_store.bulk_insert_edges(contains_edges)
            self._log(f"  Graph writes done ({time.perf_counter()-t0:.1f}s)")

            # Phase 3 — Resolve
            t0 = time.perf_counter()
            self._emit(ProgressEvent("resolve", 40, message="Resolving edges"))
            self._log(f"Phase 3/5: Resolving cross-file references ({len(files)} files)...")
            resolve_edges = phase_resolve.run(files, symbols, self.repo_path)
            self._log(f"  Resolved {len(resolve_edges)} edges ({time.perf_counter()-t0:.1f}s)")
            self._emit(ProgressEvent("resolve", 60, items_done=len(resolve_edges)))
            t0 = time.perf_counter()
            self._log(f"  Persisting {len(resolve_edges)} resolve-edges to graph DB...")
            self.graph_store.bulk_insert_edges(resolve_edges)
            self._log(f"  Graph writes done ({time.perf_counter()-t0:.1f}s)")

            # Phase 4 — Cluster
            t0 = time.perf_counter()
            self._emit(ProgressEvent("cluster", 60, message="Clustering"))
            self._log(f"Phase 4/5: Clustering modules ({len(symbols)} symbols)...")
            all_edges = contains_edges + resolve_edges
            clusters, belongs_to_edges = phase_cluster.run(symbols, all_edges)
            self._log(f"  Found {len(clusters)} clusters ({time.perf_counter()-t0:.1f}s)")
            self._emit(ProgressEvent("cluster", 75, items_done=len(clusters)))
            t0 = time.perf_counter()
            self._log(f"  Persisting {len(clusters)} clusters + {len(belongs_to_edges)} edges to graph DB...")
            self.graph_store.upsert_clusters(clusters)
            self.graph_store.bulk_insert_edges(belongs_to_edges)
            # Persist updated cluster_ids
            self._log(f"  Updating cluster_id on {len(symbols)} symbols...")
            self.graph_store.update_symbol_clusters_bulk(
                [(s.id, s.cluster_id) for s in symbols if s.cluster_id]
            )
            self._log(f"  Graph writes done ({time.perf_counter()-t0:.1f}s)")

            # Phase 5 — Embed (optional)
            if self.config.skip_embeddings:
                self._log("Phase 5/5: Skipping embeddings (--skip-embeddings)")
            else:
                t0 = time.perf_counter()
                self._emit(ProgressEvent("embed", 75, message="Embedding"))
                self._log(f"Phase 5/5: Generating embeddings ({len(symbols)} symbols)...")
                phase_embed.run(symbols, self.vector_store, self.bm25_path)
                self._log(f"  Embedded {len(symbols)} symbols ({time.perf_counter()-t0:.1f}s)")
                self._emit(ProgressEvent("embed", 90, items_done=len(symbols)))
                # Persist embedding_ids
                t0 = time.perf_counter()
                self._log(f"  Updating embedding_id on {len(symbols)} symbols in graph DB...")
                self.graph_store.update_symbol_embedding_ids_bulk(
                    [(s.id, s.embedding_id) for s in symbols if s.embedding_id >= 0]
                )
                self._log(f"  Graph writes done ({time.perf_counter()-t0:.1f}s)")

            # Persist file checksums for incremental diffing
            self.meta_store.save_file_checksums(self.repo_id, files)

            # Stats
            self.meta_store.update_repo_stats(
                self.repo_id,
                symbol_count=len(symbols),
                edge_count=len(all_edges),
                last_commit=self._get_head_commit(),
            )

            # Snapshot config
            (self.index_dir / CONFIG_SNAPSHOT_NAME).write_text(
                json.dumps({
                    "langs": self.config.langs,
                    "embedding_model": self.config.embedding_model,
                    "skip_embeddings": self.config.skip_embeddings,
                }, indent=2)
            )

            # Phase 6 (implicit): compute centrality
            try:
                from ravmem.engine.ranking import compute_centrality
                t0 = time.perf_counter()
                self._log("Computing centrality scores...")
                centrality = compute_centrality(
                    self.graph_store, self.meta_store, self.repo_id, force=True
                )
                self._log(
                    f"Centrality computed and cached ({len(centrality)} nodes,"
                    f" {time.perf_counter()-t0:.1f}s)"
                )
            except Exception as e:
                self._log(f"Warning: centrality computation failed: {e}")
            self._emit(ProgressEvent("centrality", 100, message="Done"))

            self.meta_store.finish_job(job_id, "done")
            total_elapsed = time.perf_counter() - t_total
            self._log(
                f"Indexing complete: {len(symbols)} symbols, {len(clusters)} clusters"
                f" — total {total_elapsed:.1f}s"
            )

        except KeyboardInterrupt:
            self.meta_store.finish_job(job_id, "cancelled", "Interrupted by user (Ctrl+C)")
            self.close()
            raise
        except Exception as exc:
            self.meta_store.finish_job(job_id, "failed", str(exc))
            self.close()
            raise RuntimeError(f"Indexing failed: {exc}") from exc

    def _detect_changes(
        self, diff_base_commit: str | None
    ) -> tuple[set[str], set[str]]:
        """Return (modified_paths, deleted_paths) of absolute file paths.

        Tries git diff first; falls back to checksum comparison for non-git repos.
        """
        base = diff_base_commit or self.meta_store.get_last_commit(self.repo_id)
        if base:
            result = subprocess.run(
                ["git", "-C", str(self.repo_path), "diff", "--name-status", base, "HEAD"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0 and result.stdout.strip():
                modified: set[str] = set()
                deleted: set[str] = set()
                for line in result.stdout.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split("\t", 1)
                    if len(parts) != 2:
                        continue
                    status, name = parts[0].strip(), parts[1].strip()
                    abs_path = str((self.repo_path / name).resolve())
                    if status.startswith("D"):
                        deleted.add(abs_path)
                    else:  # M, A, R, C
                        modified.add(abs_path)
                return modified, deleted

        # Fallback: checksum-based comparison
        all_files = phase_structure.run(self.repo_path, langs=self.config.langs)
        changed, deleted_paths = self.meta_store.get_changed_files(self.repo_id, all_files)
        return {f.path for f in changed}, set(deleted_paths)

    def _rebuild_embed(self, all_symbols: list) -> None:
        """Rebuild the vector index and BM25 corpus from scratch for all symbols."""
        from ravmem.indexer.phase_embed import _load_model

        model = _load_model()
        texts = []
        for s in all_symbols:
            if not s.docstring:
                logger.debug(
                    "Symbol %s has no docstring — embedding quality may be reduced", s.id
                )
            texts.append(
                f"{s.kind} {s.name} in {Path(s.file).name}: {s.docstring.strip()[:200]}"
                if s.docstring
                else f"{s.kind} {s.name} in {Path(s.file).name}"
            )
        embeddings = np.array(list(model.embed(texts)), dtype=np.float32)
        ids = [s.id for s in all_symbols]
        self.vector_store.rebuild(ids, embeddings)

        corpus = [
            {
                "id": s.id,
                "text": text,
                "name": s.name,
                "file": s.file,
                "kind": s.kind,
                "line_start": s.line_start,
                "line_end": s.line_end,
                "lang": s.lang,
                "cluster_id": s.cluster_id,
            }
            for s, text in zip(all_symbols, texts)
        ]
        self.bm25_path.write_text(json.dumps(corpus))

        # Update embedding_ids in the graph
        self.graph_store.update_symbol_embedding_ids_bulk(
            [(s.id, idx) for idx, s in enumerate(all_symbols)]
        )

    def _update_embed(self, removed_symbol_ids: list[str], new_symbols: list) -> None:
        """Incrementally update the vector index and BM25 corpus.

        Encodes only ``new_symbols`` and soft-deletes stale embeddings identified
        by ``removed_symbol_ids``.  Falls back to a full rebuild automatically
        when thresholds are exceeded (see ``run_incremental``).
        """
        phase_embed.run_partial(
            removed_symbol_ids=removed_symbol_ids,
            new_symbols=new_symbols,
            vector_store=self.vector_store,
            bm25_path=self.bm25_path,
        )
        # Update embedding_ids in the graph only for the newly encoded symbols
        updates = [(s.id, s.embedding_id) for s in new_symbols if s.embedding_id >= 0]
        if updates:
            self.graph_store.update_symbol_embedding_ids_bulk(updates)

    def run_incremental(self, diff_base_commit: str | None = None) -> None:
        """Re-index only files changed since diff_base_commit (or last known commit)."""
        # Walk all current files first (needed for checksum fallback + modified filter)
        all_files = phase_structure.run(self.repo_path, langs=self.config.langs)

        modified_paths, deleted_paths = self._detect_changes(diff_base_commit)

        if not modified_paths and not deleted_paths:
            self._log("No indexed files changed — skipping")
            return

        # If this repo has never been indexed, run full instead
        if not self.meta_store.get_repo(self.repo_id):
            self._log("No previous index found — running full index")
            self.run_full()
            return

        base_commit = diff_base_commit or self.meta_store.get_last_commit(self.repo_id) or ""
        job_id = self.meta_store.create_job(
            self.repo_id, mode="incremental", diff_base=base_commit
        )

        t_total = time.perf_counter()

        # Begin a graph transaction if the backend supports it (ArcadeDB).
        # This makes graph mutations in steps 1–6 atomic: a mid-index crash
        # rolls back rather than leaving a partially-written state.
        _tx_sid: str | None = None
        if hasattr(self.graph_store, "begin_transaction"):
            _tx_sid = self.graph_store.begin_transaction()

        try:
            removed_symbol_ids: list[str] = []
            new_symbols: list = []
            self._emit(ProgressEvent("structure", 0, message="Walking file tree"))
            self._log(
                f"Incremental: {len(modified_paths)} modified, "
                f"{len(deleted_paths)} deleted"
            )
            self._emit(ProgressEvent("structure", 10, items_done=len(all_files), items_total=len(all_files)))

            # --- Step 1: Clean up deleted files ---
            for path in deleted_paths:
                stale = self.graph_store.get_symbols_for_file(path)
                removed_symbol_ids.extend(s.id for s in stale)
                n = self.graph_store.delete_symbols_for_file(path)
                self.graph_store.delete_file(path)
                self._log(f"  Removed {n} symbols from deleted file: {Path(path).name}")

            # --- Step 2: Clean stale symbols for modified files ---
            for path in modified_paths:
                stale = self.graph_store.get_symbols_for_file(path)
                removed_symbol_ids.extend(s.id for s in stale)
                self.graph_store.delete_symbols_for_file(path)

            # --- Step 3: Re-parse modified files ---
            changed_files = [f for f in all_files if f.path in modified_paths]
            if changed_files:
                t0 = time.perf_counter()
                self._emit(ProgressEvent("parse", 20, message="Parsing symbols"))
                self.graph_store.upsert_files(changed_files)
                new_symbols, contains_edges = phase_parse.run(changed_files)
                self._log(
                    f"  Parsed {len(new_symbols)} symbols from {len(changed_files)}"
                    f" changed files ({time.perf_counter()-t0:.1f}s)"
                )
                self._emit(ProgressEvent("parse", 35, items_done=len(new_symbols), items_total=len(changed_files)))
                self.graph_store.upsert_symbols(new_symbols)
                self.graph_store.upsert_edges(contains_edges)

                # --- Step 4: Re-resolve edges against ALL symbols in graph ---
                t0 = time.perf_counter()
                self._emit(ProgressEvent("resolve", 40, message="Resolving edges"))
                all_symbols = self.graph_store.get_all_symbols()
                self._log(
                    f"  Resolving edges for {len(changed_files)} changed files"
                    f" against {len(all_symbols)} total symbols..."
                )
                resolve_edges = phase_resolve.run(changed_files, all_symbols, self.repo_path)
                self._log(
                    f"  Resolved {len(resolve_edges)} edges ({time.perf_counter()-t0:.1f}s)"
                )
                self._emit(ProgressEvent("resolve", 55, items_done=len(resolve_edges)))
                self.graph_store.upsert_edges(resolve_edges)

                # --- Step 5: Re-cluster only changed symbols (file-based, O(changed)) ---
                t0 = time.perf_counter()
                self._emit(ProgressEvent("cluster", 60, message="Clustering"))
                self._log(f"  Clustering {len(new_symbols)} changed symbols (file-based)...")
                clusters, belongs_to_edges = phase_cluster.run_incremental(new_symbols)
                self._log(
                    f"  Found {len(clusters)} clusters ({time.perf_counter()-t0:.1f}s)"
                )
                self._emit(ProgressEvent("cluster", 70, items_done=len(clusters)))
                self.graph_store.upsert_clusters(clusters)
                self.graph_store.upsert_edges(belongs_to_edges)
                self.graph_store.update_symbol_clusters_bulk(
                    [(s.id, s.cluster_id) for s in new_symbols if s.cluster_id]
                )

            # --- Step 6: Clean up now-empty clusters ---
            self.graph_store.delete_orphan_clusters()

            # Commit graph mutations (steps 1–6) before non-graph phases
            if _tx_sid is not None:
                self.graph_store.commit_transaction(_tx_sid)
                _tx_sid = None

            # --- Step 7: Update or rebuild embeddings ---
            all_symbols_final = self.graph_store.get_all_symbols()
            if self.config.skip_embeddings:
                self._log("  Skipping embedding update (--skip-embeddings)")
            else:
                t0 = time.perf_counter()
                self._emit(ProgressEvent("embed", 75, message="Embedding"))
                vs = self.vector_store
                deleted_ratio = vs.deleted_count / max(vs.total_count, 1)
                changed_ratio = len(new_symbols) / max(vs.live_count, 1)

                if (
                    deleted_ratio > _EMBED_DELETED_REBUILD_THRESHOLD
                    or changed_ratio > _EMBED_CHANGED_THRESHOLD
                ):
                    self._log(
                        f"  Embed threshold exceeded (deleted={deleted_ratio:.0%},"
                        f" changed={changed_ratio:.0%}) — full rebuild of"
                        f" {len(all_symbols_final)} symbols"
                    )
                    self._rebuild_embed(all_symbols_final)
                    self._log(f"  Full embed rebuild done ({time.perf_counter()-t0:.1f}s)")
                else:
                    self._log(
                        f"  Partial embed update: {len(removed_symbol_ids)} stale removed,"
                        f" {len(new_symbols)} new symbols encoded"
                    )
                    self._update_embed(removed_symbol_ids, new_symbols)
                    self._log(f"  Partial embed done ({time.perf_counter()-t0:.1f}s)")
                self._emit(ProgressEvent("embed", 90, items_done=len(all_symbols_final)))

            # --- Step 8: Persist checksums + stats ---
            self.meta_store.save_file_checksums(self.repo_id, all_files)
            if deleted_paths:
                self.meta_store.delete_file_checksums(self.repo_id, list(deleted_paths))

            self.meta_store.update_repo_stats(
                self.repo_id,
                symbol_count=len(all_symbols_final),
                edge_count=len(self.graph_store.get_calls_edges()),
                last_commit=self._get_head_commit(),
            )
            # Phase implicit: compute centrality after re-indexing
            try:
                from ravmem.engine.ranking import compute_centrality
                t0 = time.perf_counter()
                centrality = compute_centrality(
                    self.graph_store, self.meta_store, self.repo_id, force=True
                )
                self._log(
                    f"Centrality computed and cached ({len(centrality)} nodes,"
                    f" {time.perf_counter()-t0:.1f}s)"
                )
            except Exception as e:
                self._log(f"Warning: centrality computation failed: {e}")
            self._emit(ProgressEvent("centrality", 100, message="Done"))

            self.meta_store.finish_job(job_id, "done")
            self._log(
                f"Incremental index complete: {len(all_symbols_final)} symbols total"
                f" — {time.perf_counter()-t_total:.1f}s"
            )

        except KeyboardInterrupt:
            if _tx_sid is not None:
                try:
                    self.graph_store.rollback_transaction(_tx_sid)
                except Exception:
                    pass
            self.meta_store.finish_job(job_id, "cancelled", "Interrupted by user (Ctrl+C)")
            self.close()
            raise
        except Exception as exc:
            if _tx_sid is not None:
                try:
                    self.graph_store.rollback_transaction(_tx_sid)
                except Exception:
                    pass
            self.meta_store.finish_job(job_id, "failed", str(exc))
            self.close()
            raise RuntimeError(f"Incremental index failed: {exc}") from exc
