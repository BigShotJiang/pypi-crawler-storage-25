"""Phase 2 — Parse: extract Symbol objects from source files via Tree-sitter."""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Any

from ravmem.storage.schema import Edge, File, Symbol

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Grammar loader — one Parser per language, loaded lazily and independently
# ---------------------------------------------------------------------------

_PARSERS: dict[str, Any] = {}
_MISSING_WARNED: set[str] = set()


def _load_language(lang: str) -> Any:
    """
    Import the tree-sitter Language object for *lang*.
    Each grammar is imported independently so a missing package for one language
    does not affect others.  Raises ImportError if the grammar is unavailable.
    """
    from tree_sitter import Language  # noqa: PLC0415

    if lang == "python":
        import tree_sitter_python as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "typescript":
        import tree_sitter_typescript as m  # noqa: PLC0415
        return Language(m.language_typescript())
    if lang == "javascript":
        import tree_sitter_typescript as m  # noqa: PLC0415
        return Language(m.language_tsx())
    if lang == "go":
        import tree_sitter_go as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "java":
        import tree_sitter_java as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "csharp":
        import tree_sitter_c_sharp as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "php":
        import tree_sitter_php as m  # noqa: PLC0415
        # tree-sitter-php >=0.22 exposes language_php(); older versions use language()
        fn = getattr(m, "language_php", None) or m.language
        return Language(fn())
    if lang == "rust":
        import tree_sitter_rust as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "kotlin":
        import tree_sitter_kotlin as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "ruby":
        import tree_sitter_ruby as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "c":
        import tree_sitter_c as m  # noqa: PLC0415
        return Language(m.language())
    if lang == "cpp":
        import tree_sitter_cpp as m  # noqa: PLC0415
        return Language(m.language())
    raise ImportError(f"No tree-sitter grammar registered for language: {lang!r}")


def _get_parser(lang: str) -> Any | None:
    """Return a cached Tree-sitter Parser, or None if the grammar is unavailable."""
    if lang in _PARSERS:
        return _PARSERS[lang]
    try:
        from tree_sitter import Parser  # noqa: PLC0415
        _PARSERS[lang] = Parser(_load_language(lang))
        return _PARSERS[lang]
    except ImportError:
        if lang not in _MISSING_WARNED:
            _MISSING_WARNED.add(lang)
            pkg = lang.replace("_", "-")
            logger.warning(
                "Tree-sitter grammar for '%s' is not installed — symbol extraction "
                "will be skipped for this language. "
                "Install with: pip install tree-sitter-%s",
                lang, pkg,
            )
        _PARSERS[lang] = None
        return None
    except Exception as exc:
        logger.debug("Failed to load parser for %s: %s", lang, exc)
        _PARSERS[lang] = None
        return None


def _symbol_id(file_path: str, name: str, line_start: int) -> str:
    raw = f"{file_path}::{name}::{line_start}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Language-specific extraction helpers
# ---------------------------------------------------------------------------

def _extract_python(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("python")
    if parser is None:
        return []
    tree = parser.parse(source)
    root = tree.root_node
    symbols: list[Symbol] = []

    def _docstring(node: Any) -> str:
        # Docstring is the first statement inside the function/class body (block node)
        for child in node.children:
            if child.type == "block":
                for stmt in child.children:
                    if stmt.type == "expression_statement":
                        for sub in stmt.children:
                            if sub.type == "string":
                                raw = source[sub.start_byte:sub.end_byte].decode(errors="replace")
                                for q in ('"""', "'''", '"', "'"):
                                    if raw.startswith(q) and raw.endswith(q) and len(raw) > 2 * len(q):
                                        return raw[len(q):-len(q)]
                                return raw.strip("'\"")
                        break  # Only the first statement can be a docstring
        return ""

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type in ("function_definition", "async_function_definition"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = source[name_node.start_byte:name_node.end_byte].decode()
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang, docstring=_docstring(node),
                ))
        elif node.type == "class_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                cname = source[name_node.start_byte:name_node.end_byte].decode()
                sid = _symbol_id(file_path, cname, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=cname, kind="class", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang, docstring=_docstring(node),
                ))
                for child in node.children:
                    _walk(child, class_name=cname)
                return
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(root)
    return symbols


def _extract_typescript(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser(lang)
    if parser is None:
        return []
    tree = parser.parse(source)
    root = tree.root_node
    symbols: list[Symbol] = []
    seen_ids: set[str] = set()

    def _append(sym: Symbol) -> None:
        if sym.id not in seen_ids:
            seen_ids.add(sym.id)
            symbols.append(sym)

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _handle_variable_decl(node: Any, class_name: str) -> None:
        """Extract symbols from variable_declaration / lexical_declaration nodes."""
        for declarator in node.children:
            if declarator.type != "variable_declarator":
                continue
            name_node = declarator.child_by_field_name("name")
            value_node = declarator.child_by_field_name("value")
            if not name_node or not value_node:
                continue
            if name_node.type not in ("identifier",):
                continue
            if value_node.type in ("arrow_function", "function_expression", "function"):
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                _append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                _append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        elif node.type == "method_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                _append(Symbol(
                    id=sid, name=full_name, kind="method", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        elif node.type in ("variable_declaration", "lexical_declaration"):
            _handle_variable_decl(node, class_name)
        elif node.type == "export_statement":
            for child in node.children:
                if child.type in ("variable_declaration", "lexical_declaration"):
                    _handle_variable_decl(child, class_name)
                elif child.type == "function_declaration":
                    _walk(child, class_name=class_name)
                elif child.type in ("class_declaration", "class_expression"):
                    _walk(child, class_name=class_name)
                elif child.type == "interface_declaration":
                    _walk(child, class_name=class_name)
            return
        elif node.type in ("class_declaration", "class_expression"):
            name_node = node.child_by_field_name("name")
            if name_node:
                cname = _decode(name_node)
                sid = _symbol_id(file_path, cname, node.start_point[0] + 1)
                _append(Symbol(
                    id=sid, name=cname, kind="class", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=cname)
                return
        elif node.type == "interface_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                _append(Symbol(
                    id=sid, name=name, kind="interface", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(root)
    return symbols


def _extract_go(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("go")
    if parser is None:
        return []
    tree = parser.parse(source)
    root = tree.root_node
    symbols: list[Symbol] = []

    def _walk(node: Any) -> None:
        if node.type == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = source[name_node.start_byte:name_node.end_byte].decode()
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind="function", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        elif node.type == "method_declaration":
            name_node = node.child_by_field_name("name")
            recv = node.child_by_field_name("receiver")
            recv_type = ""
            if recv:
                for child in recv.children:
                    if child.type == "parameter_declaration":
                        for sub in child.children:
                            if sub.type in ("type_identifier", "pointer_type"):
                                recv_type = source[sub.start_byte:sub.end_byte].decode()
                                break
            if name_node:
                name = source[name_node.start_byte:name_node.end_byte].decode()
                full_name = f"{recv_type}.{name}" if recv_type else name
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind="method", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        elif node.type == "type_declaration":
            for child in node.children:
                if child.type == "type_spec":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        name = source[name_node.start_byte:name_node.end_byte].decode()
                        sid = _symbol_id(file_path, name, child.start_point[0] + 1)
                        symbols.append(Symbol(
                            id=sid, name=name, kind="class", file=file_path,
                            line_start=child.start_point[0] + 1,
                            line_end=child.end_point[0] + 1,
                            lang=lang,
                        ))
        for child in node.children:
            _walk(child)

    _walk(root)
    return symbols


# ---------------------------------------------------------------------------
# Java
# ---------------------------------------------------------------------------

_JAVA_TYPE_KINDS = {
    "class_declaration": "class",
    "interface_declaration": "interface",
    "enum_declaration": "enum",
    "record_declaration": "class",
    "annotation_type_declaration": "interface",
}


def _extract_java(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("java")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type in _JAVA_TYPE_KINDS:
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                kind = _JAVA_TYPE_KINDS[node.type]
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type in ("method_declaration", "constructor_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# C#
# ---------------------------------------------------------------------------

_CS_TYPE_KINDS = {
    "class_declaration": "class",
    "interface_declaration": "interface",
    "enum_declaration": "enum",
    "struct_declaration": "struct",
    "record_declaration": "class",
}


def _extract_csharp(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("csharp")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type in _CS_TYPE_KINDS:
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                kind = _CS_TYPE_KINDS[node.type]
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type in ("method_declaration", "constructor_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# PHP
# ---------------------------------------------------------------------------

_PHP_TYPE_KINDS = {
    "class_declaration": "class",
    "interface_declaration": "interface",
    "trait_declaration": "trait",
    "enum_declaration": "enum",
}


def _extract_php(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("php")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type in _PHP_TYPE_KINDS:
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                kind = _PHP_TYPE_KINDS[node.type]
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type in ("function_definition", "method_declaration"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# Rust
# ---------------------------------------------------------------------------

_RUST_TYPE_KINDS = {
    "struct_item": "class",
    "enum_item": "enum",
    "trait_item": "interface",
    "type_item": "class",
}


def _extract_rust(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("rust")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, impl_type: str = "") -> None:
        if node.type in _RUST_TYPE_KINDS:
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                kind = _RUST_TYPE_KINDS[node.type]
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        elif node.type == "impl_item":
            # impl Foo { ... }  or  impl Trait for Foo { ... }
            # The `type` field is the implementing type (Foo in both cases)
            type_node = node.child_by_field_name("type")
            resolved_type = _decode(type_node).strip() if type_node else impl_type
            for child in node.children:
                _walk(child, impl_type=resolved_type)
            return
        elif node.type == "function_item":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{impl_type}.{name}" if impl_type else name
                kind = "method" if impl_type else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, impl_type=impl_type)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# Kotlin
# ---------------------------------------------------------------------------

def _kotlin_name(node: Any, source: bytes) -> str | None:
    """
    Kotlin class/function names may use 'identifier', 'simple_identifier', or a
    named 'name' field depending on the grammar version.  Try all three.
    """
    n = node.child_by_field_name("name")
    if n is not None:
        return source[n.start_byte:n.end_byte].decode(errors="replace")
    for child in node.children:
        if child.type in ("simple_identifier", "identifier"):
            return source[child.start_byte:child.end_byte].decode(errors="replace")
    return None


def _kotlin_is_interface(node: Any) -> bool:
    """
    In some tree-sitter-kotlin versions, interface declarations are represented
    as class_declaration nodes whose first keyword child is 'interface'.
    """
    for child in node.children:
        if child.type == "interface":
            return True
        # Stop at the name — don't scan the whole body
        if child.type in ("identifier", "simple_identifier"):
            break
    return False


_KOTLIN_TYPE_NODES = ("class_declaration", "object_declaration", "interface_declaration")


def _extract_kotlin(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("kotlin")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type in _KOTLIN_TYPE_NODES:
            name = _kotlin_name(node, source)
            if name:
                # interface_declaration OR class_declaration with 'interface' keyword
                is_iface = (node.type == "interface_declaration" or
                            (node.type == "class_declaration" and _kotlin_is_interface(node)))
                kind = "interface" if is_iface else "class"
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type == "function_declaration":
            name = _kotlin_name(node, source)
            if name:
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# Ruby
# ---------------------------------------------------------------------------

def _extract_ruby(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser("ruby")
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type == "class":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind="class", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type == "module":
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind="module", file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                for child in node.children:
                    _walk(child, class_name=name)
                return
        elif node.type in ("method", "singleton_method"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                full_name = f"{class_name}.{name}" if class_name else name
                kind = "method" if class_name else "function"
                sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=full_name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# C / C++
# ---------------------------------------------------------------------------

def _c_declarator_name(node: Any, source: bytes) -> str | None:
    """
    Recursively unwrap a C/C++ declarator chain to find the function identifier.
    Handles: identifier, function_declarator, pointer_declarator, qualified_identifier.
    """
    if node.type == "identifier":
        return source[node.start_byte:node.end_byte].decode(errors="replace")
    if node.type == "field_identifier":
        return source[node.start_byte:node.end_byte].decode(errors="replace")
    if node.type == "operator_name":
        return source[node.start_byte:node.end_byte].decode(errors="replace")
    if node.type == "destructor_name":
        return source[node.start_byte:node.end_byte].decode(errors="replace")
    # qualified_identifier: Foo::bar — use the rightmost name part
    if node.type == "qualified_identifier":
        name_node = node.child_by_field_name("name")
        if name_node:
            return _c_declarator_name(name_node, source)
    # Drill through declarator wrappers
    inner = node.child_by_field_name("declarator")
    if inner:
        return _c_declarator_name(inner, source)
    return None


def _extract_c_cpp(source: bytes, file_path: str, lang: str) -> list[Symbol]:
    parser = _get_parser(lang)
    if parser is None:
        return []
    tree = parser.parse(source)
    symbols: list[Symbol] = []

    def _decode(node: Any) -> str:
        return source[node.start_byte:node.end_byte].decode(errors="replace")

    def _walk(node: Any, class_name: str = "") -> None:
        if node.type == "function_definition":
            dec = node.child_by_field_name("declarator")
            if dec:
                name = _c_declarator_name(dec, source)
                if name:
                    full_name = f"{class_name}.{name}" if class_name else name
                    kind = "method" if class_name else "function"
                    sid = _symbol_id(file_path, full_name, node.start_point[0] + 1)
                    symbols.append(Symbol(
                        id=sid, name=full_name, kind=kind, file=file_path,
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        lang=lang,
                    ))
        elif node.type in ("struct_specifier", "class_specifier", "enum_specifier"):
            name_node = node.child_by_field_name("name")
            if name_node:
                name = _decode(name_node)
                kind = "enum" if node.type == "enum_specifier" else "class"
                sid = _symbol_id(file_path, name, node.start_point[0] + 1)
                symbols.append(Symbol(
                    id=sid, name=name, kind=kind, file=file_path,
                    line_start=node.start_point[0] + 1,
                    line_end=node.end_point[0] + 1,
                    lang=lang,
                ))
                # Walk body for C++ class members
                for child in node.children:
                    _walk(child, class_name=name)
                return
        for child in node.children:
            _walk(child, class_name=class_name)

    _walk(tree.root_node)
    return symbols


# ---------------------------------------------------------------------------
# Extractor registry + main entry point
# ---------------------------------------------------------------------------

_EXTRACTORS = {
    "python": _extract_python,
    "typescript": _extract_typescript,
    "javascript": _extract_typescript,
    "go": _extract_go,
    "java": _extract_java,
    "csharp": _extract_csharp,
    "php": _extract_php,
    "rust": _extract_rust,
    "kotlin": _extract_kotlin,
    "ruby": _extract_ruby,
    "c": _extract_c_cpp,
    "cpp": _extract_c_cpp,
}


def run(files: list[File]) -> tuple[list[Symbol], list[Edge]]:
    """Parse all files and return (symbols, contains_edges)."""
    all_symbols: list[Symbol] = []
    all_edges: list[Edge] = []

    for f in files:
        extractor = _EXTRACTORS.get(f.lang)
        if extractor is None:
            continue
        try:
            source = Path(f.path).read_bytes()
            symbols = extractor(source, f.path, f.lang)
            all_symbols.extend(symbols)
            for s in symbols:
                all_edges.append(Edge(
                    src_id=f.path, dst_id=s.id,
                    kind="contains",
                ))
        except Exception as exc:
            logger.warning("Failed to parse %s: %s", f.path, exc)
            continue

    return all_symbols, all_edges
