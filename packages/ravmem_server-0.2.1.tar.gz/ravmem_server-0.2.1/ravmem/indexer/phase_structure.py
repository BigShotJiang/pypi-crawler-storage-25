"""Phase 1 — Structure: walk the file tree, detect languages, emit File objects."""

from __future__ import annotations

import fnmatch
import hashlib
import logging
from pathlib import Path

from ravmem.config import (
    DEFAULT_IGNORE_PATTERNS,
    EXT_TO_LANG,
    MAX_FILE_SIZE_KB,
)
from ravmem.storage.schema import File

logger = logging.getLogger(__name__)


def _load_ignore_patterns(repo_path: Path) -> list[str]:
    patterns = list(DEFAULT_IGNORE_PATTERNS)
    ignore_file = repo_path / ".ravmemignore"
    if ignore_file.exists():
        for line in ignore_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    return patterns


def _is_ignored(path: Path, repo_root: Path, patterns: list[str]) -> bool:
    rel = path.relative_to(repo_root)
    parts = rel.parts
    for pattern in patterns:
        # Match against any path component or the full relative path
        for part in parts:
            if fnmatch.fnmatch(part, pattern):
                return True
        if fnmatch.fnmatch(str(rel), pattern):
            return True
    return False


def _checksum(path: Path) -> str:
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def run(
    repo_path: Path,
    langs: list[str] | None = None,
) -> list[File]:
    """Walk repo_path and return a list of File objects for indexable source files."""
    ignore_patterns = _load_ignore_patterns(repo_path)
    files: list[File] = []
    skipped_langs: set[str] = set()

    for fpath in repo_path.rglob("*"):
        if not fpath.is_file():
            continue
        if _is_ignored(fpath, repo_path, ignore_patterns):
            continue

        ext = fpath.suffix.lower()
        lang = EXT_TO_LANG.get(ext)
        if lang is None:
            continue
        if langs and lang not in langs:
            skipped_langs.add(lang)
            continue

        size_kb = fpath.stat().st_size / 1024
        if size_kb > MAX_FILE_SIZE_KB:
            logger.warning("Skipping large file (%.1f KB): %s", size_kb, fpath)
            continue

        files.append(File(
            path=str(fpath.resolve()),
            lang=lang,
            size_kb=round(size_kb, 2),
            checksum=_checksum(fpath),
        ))

    # Warn when known-language files are present but excluded by --langs
    for lang in sorted(skipped_langs):
        logger.warning(
            "Found %s source files but '%s' is not in the active lang list — "
            "pass --langs to include it (e.g. --langs %s)",
            lang, lang, ",".join((langs or []) + [lang]),
        )

    return files
