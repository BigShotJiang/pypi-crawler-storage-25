"""Comprehensive unit tests for ServerRegistry."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from ravmem.server.registry import ServerRegistry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def registry():
    """Yield a ServerRegistry backed by a real SQLite file in a temp dir."""
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "registry.db"
        reg = ServerRegistry(db_path)
        yield reg
        reg.close()


# Convenience helpers used across multiple tests
def _make_project(reg: ServerRegistry, pid: str = "proj-1", name: str = "MyProject") -> dict:
    return reg.create_project(pid, name, "/repos/myproject", default_branch="main")


# ---------------------------------------------------------------------------
# Projects — CRUD
# ---------------------------------------------------------------------------


class TestProjectCRUD:
    def test_create_returns_dict_with_expected_fields(self, registry):
        proj = _make_project(registry)
        assert proj["id"] == "proj-1"
        assert proj["name"] == "MyProject"
        assert proj["repo_path"] == "/repos/myproject"
        assert proj["default_branch"] == "main"
        assert proj["created_at"]
        assert proj["updated_at"]

    def test_create_custom_default_branch(self, registry):
        proj = registry.create_project("p2", "Dev", "/repos/dev", default_branch="develop")
        assert proj["default_branch"] == "develop"

    def test_get_existing_project(self, registry):
        _make_project(registry)
        proj = registry.get_project("proj-1")
        assert proj is not None
        assert proj["id"] == "proj-1"

    def test_get_nonexistent_project_returns_none(self, registry):
        result = registry.get_project("does-not-exist")
        assert result is None

    def test_list_projects_empty(self, registry):
        assert registry.list_projects() == []

    def test_list_projects_multiple_sorted_by_name(self, registry):
        registry.create_project("b", "Beta", "/b")
        registry.create_project("a", "Alpha", "/a")
        registry.create_project("c", "Gamma", "/c")
        projects = registry.list_projects()
        names = [p["name"] for p in projects]
        assert names == ["Alpha", "Beta", "Gamma"]

    def test_delete_existing_project_returns_true(self, registry):
        _make_project(registry)
        assert registry.delete_project("proj-1") is True

    def test_delete_removes_project(self, registry):
        _make_project(registry)
        registry.delete_project("proj-1")
        assert registry.get_project("proj-1") is None

    def test_delete_nonexistent_project_returns_false(self, registry):
        assert registry.delete_project("ghost") is False

    def test_count_projects_zero(self, registry):
        assert registry.count_projects() == 0

    def test_count_projects_increments(self, registry):
        registry.create_project("p1", "A", "/a")
        assert registry.count_projects() == 1
        registry.create_project("p2", "B", "/b")
        assert registry.count_projects() == 2

    def test_count_projects_decrements_on_delete(self, registry):
        registry.create_project("p1", "A", "/a")
        registry.create_project("p2", "B", "/b")
        registry.delete_project("p1")
        assert registry.count_projects() == 1


# ---------------------------------------------------------------------------
# Branch indexes
# ---------------------------------------------------------------------------


class TestBranchIndexes:
    def test_register_branch_and_get(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/indexes/proj-1/main")
        branch = registry.get_branch("proj-1", "main")
        assert branch is not None
        assert branch["project_id"] == "proj-1"
        assert branch["branch"] == "main"
        assert branch["index_path"] == "/indexes/proj-1/main"
        assert branch["status"] == "empty"
        assert branch["symbol_count"] == 0
        assert branch["edge_count"] == 0

    def test_register_branch_idempotent(self, registry):
        """INSERT OR IGNORE means a second call must not raise or overwrite."""
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/indexes/proj-1/main")
        # Registering again with a different path should be silently ignored
        registry.register_branch("proj-1", "main", "/other/path")
        branch = registry.get_branch("proj-1", "main")
        assert branch["index_path"] == "/indexes/proj-1/main"

    def test_get_nonexistent_branch_returns_none(self, registry):
        _make_project(registry)
        assert registry.get_branch("proj-1", "nonexistent") is None

    def test_list_branches_empty(self, registry):
        _make_project(registry)
        assert registry.list_branches("proj-1") == []

    def test_list_branches_sorted_by_name(self, registry):
        _make_project(registry)
        for b in ("main", "feature/z", "develop"):
            registry.register_branch("proj-1", b, f"/idx/{b}")
        branches = registry.list_branches("proj-1")
        names = [br["branch"] for br in branches]
        assert names == sorted(names)

    def test_list_branches_only_for_given_project(self, registry):
        registry.create_project("p1", "P1", "/p1")
        registry.create_project("p2", "P2", "/p2")
        registry.register_branch("p1", "main", "/idx/p1/main")
        registry.register_branch("p2", "main", "/idx/p2/main")
        assert len(registry.list_branches("p1")) == 1
        assert len(registry.list_branches("p2")) == 1

    def test_update_branch_status_field(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", status="indexing")
        assert registry.get_branch("proj-1", "main")["status"] == "indexing"

    def test_update_branch_status_ready_sets_indexed_at(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", status="ready")
        branch = registry.get_branch("proj-1", "main")
        assert branch["status"] == "ready"
        assert branch["indexed_at"] is not None

    def test_update_branch_non_ready_does_not_set_indexed_at(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", status="indexing")
        branch = registry.get_branch("proj-1", "main")
        assert branch["indexed_at"] is None

    def test_update_branch_last_commit(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", last_commit="abc123")
        assert registry.get_branch("proj-1", "main")["last_commit"] == "abc123"

    def test_update_branch_symbol_count(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", symbol_count=42)
        assert registry.get_branch("proj-1", "main")["symbol_count"] == 42

    def test_update_branch_edge_count(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status("proj-1", "main", edge_count=100)
        assert registry.get_branch("proj-1", "main")["edge_count"] == 100

    def test_update_branch_multiple_fields(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.update_branch_status(
            "proj-1", "main",
            status="ready",
            last_commit="deadbeef",
            symbol_count=77,
            edge_count=200,
        )
        branch = registry.get_branch("proj-1", "main")
        assert branch["status"] == "ready"
        assert branch["last_commit"] == "deadbeef"
        assert branch["symbol_count"] == 77
        assert branch["edge_count"] == 200
        assert branch["indexed_at"] is not None

    def test_update_branch_no_args_is_noop(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        # Must not raise, and nothing should change
        registry.update_branch_status("proj-1", "main")
        branch = registry.get_branch("proj-1", "main")
        assert branch["status"] == "empty"

    def test_delete_branch_returns_true(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        assert registry.delete_branch("proj-1", "main") is True

    def test_delete_branch_removes_record(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.delete_branch("proj-1", "main")
        assert registry.get_branch("proj-1", "main") is None

    def test_delete_nonexistent_branch_returns_false(self, registry):
        _make_project(registry)
        assert registry.delete_branch("proj-1", "ghost") is False


# ---------------------------------------------------------------------------
# Index jobs
# ---------------------------------------------------------------------------


class TestIndexJobs:
    def test_create_job_returns_integer_id(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        assert isinstance(job_id, int)
        assert job_id >= 1

    def test_create_job_default_mode_and_status(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        job = registry.get_job(job_id)
        assert job["status"] == "queued"
        assert job["mode"] == "full"
        assert job["project_id"] == "proj-1"
        assert job["branch"] == "main"
        assert job["progress_pct"] == 0
        assert job["current_phase"] == ""
        assert job["failure_reason"] == ""
        assert job["started_at"] is not None
        assert job["ended_at"] is None

    def test_create_job_incremental_mode(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main", mode="incremental")
        assert registry.get_job(job_id)["mode"] == "incremental"

    def test_get_nonexistent_job_returns_none(self, registry):
        assert registry.get_job(99999) is None

    def test_create_multiple_jobs_have_unique_ids(self, registry):
        _make_project(registry)
        ids = [registry.create_job("proj-1", "main") for _ in range(5)]
        assert len(set(ids)) == 5

    # Status transitions
    def test_update_job_status_to_running(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="running")
        assert registry.get_job(job_id)["status"] == "running"

    def test_update_job_status_done_sets_ended_at(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="done")
        job = registry.get_job(job_id)
        assert job["status"] == "done"
        assert job["ended_at"] is not None

    def test_update_job_status_failed_sets_ended_at(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="failed")
        job = registry.get_job(job_id)
        assert job["status"] == "failed"
        assert job["ended_at"] is not None

    def test_update_job_status_cancelled_sets_ended_at(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="cancelled")
        assert registry.get_job(job_id)["ended_at"] is not None

    def test_update_job_running_does_not_set_ended_at(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="running")
        assert registry.get_job(job_id)["ended_at"] is None

    def test_update_job_progress_pct(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, progress_pct=55)
        assert registry.get_job(job_id)["progress_pct"] == 55

    def test_update_job_current_phase(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, current_phase="parse")
        assert registry.get_job(job_id)["current_phase"] == "parse"

    def test_update_job_failure_reason(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="failed", failure_reason="disk full")
        job = registry.get_job(job_id)
        assert job["failure_reason"] == "disk full"
        assert job["status"] == "failed"

    def test_update_job_multiple_fields(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(
            job_id,
            status="running",
            progress_pct=30,
            current_phase="embed",
        )
        job = registry.get_job(job_id)
        assert job["status"] == "running"
        assert job["progress_pct"] == 30
        assert job["current_phase"] == "embed"

    def test_update_job_no_args_is_noop(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id)  # must not raise
        assert registry.get_job(job_id)["status"] == "queued"

    # get_active_job
    def test_get_active_job_returns_queued(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        active = registry.get_active_job("proj-1", "main")
        assert active is not None
        assert active["id"] == job_id

    def test_get_active_job_returns_running(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="running")
        active = registry.get_active_job("proj-1", "main")
        assert active is not None
        assert active["id"] == job_id

    def test_get_active_job_none_when_done(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="done")
        assert registry.get_active_job("proj-1", "main") is None

    def test_get_active_job_none_when_failed(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="failed")
        assert registry.get_active_job("proj-1", "main") is None

    def test_get_active_job_none_when_cancelled(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.update_job(job_id, status="cancelled")
        assert registry.get_active_job("proj-1", "main") is None

    def test_get_active_job_returns_latest_active(self, registry):
        """When multiple active jobs exist, the most recent (highest id) is returned."""
        _make_project(registry)
        job1 = registry.create_job("proj-1", "main")
        job2 = registry.create_job("proj-1", "main")
        active = registry.get_active_job("proj-1", "main")
        assert active["id"] == job2
        assert job1 < job2

    def test_get_active_job_scoped_to_project_and_branch(self, registry):
        registry.create_project("p1", "P1", "/p1")
        registry.create_project("p2", "P2", "/p2")
        registry.create_job("p1", "main")
        assert registry.get_active_job("p2", "main") is None

    def test_get_active_job_scoped_to_branch(self, registry):
        _make_project(registry)
        registry.create_job("proj-1", "main")
        assert registry.get_active_job("proj-1", "develop") is None

    # list_jobs
    def test_list_jobs_empty(self, registry):
        assert registry.list_jobs() == []

    def test_list_jobs_without_filter(self, registry):
        registry.create_project("p1", "P1", "/p1")
        registry.create_project("p2", "P2", "/p2")
        registry.create_job("p1", "main")
        registry.create_job("p2", "main")
        jobs = registry.list_jobs()
        assert len(jobs) == 2

    def test_list_jobs_with_project_filter(self, registry):
        registry.create_project("p1", "P1", "/p1")
        registry.create_project("p2", "P2", "/p2")
        registry.create_job("p1", "main")
        registry.create_job("p1", "develop")
        registry.create_job("p2", "main")
        p1_jobs = registry.list_jobs(project_id="p1")
        assert len(p1_jobs) == 2
        assert all(j["project_id"] == "p1" for j in p1_jobs)

    def test_list_jobs_ordered_descending_by_id(self, registry):
        _make_project(registry)
        ids = [registry.create_job("proj-1", "main") for _ in range(3)]
        jobs = registry.list_jobs(project_id="proj-1")
        returned_ids = [j["id"] for j in jobs]
        assert returned_ids == sorted(ids, reverse=True)

    def test_list_jobs_limit(self, registry):
        _make_project(registry)
        for _ in range(10):
            registry.create_job("proj-1", "main")
        jobs = registry.list_jobs(project_id="proj-1", limit=5)
        assert len(jobs) == 5

    def test_list_jobs_project_filter_no_match_returns_empty(self, registry):
        _make_project(registry)
        registry.create_job("proj-1", "main")
        assert registry.list_jobs(project_id="unknown-project") == []


# ---------------------------------------------------------------------------
# Edge cases and cascade deletes
# ---------------------------------------------------------------------------


class TestEdgeCasesAndCascade:
    def test_cascade_delete_project_removes_branches(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx/main")
        registry.register_branch("proj-1", "develop", "/idx/develop")
        registry.delete_project("proj-1")
        # Branches must be gone (FK ON DELETE CASCADE)
        assert registry.get_branch("proj-1", "main") is None
        assert registry.get_branch("proj-1", "develop") is None

    def test_cascade_delete_project_removes_jobs(self, registry):
        _make_project(registry)
        job_id = registry.create_job("proj-1", "main")
        registry.delete_project("proj-1")
        assert registry.get_job(job_id) is None

    def test_cascade_delete_removes_both_branches_and_jobs(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        job_id = registry.create_job("proj-1", "main")
        registry.delete_project("proj-1")
        assert registry.list_branches("proj-1") == []
        assert registry.get_job(job_id) is None
        assert registry.count_projects() == 0

    def test_deleting_one_project_does_not_affect_another(self, registry):
        registry.create_project("p1", "P1", "/p1")
        registry.create_project("p2", "P2", "/p2")
        registry.register_branch("p1", "main", "/idx/p1")
        registry.register_branch("p2", "main", "/idx/p2")
        j1 = registry.create_job("p1", "main")
        j2 = registry.create_job("p2", "main")
        registry.delete_project("p1")
        # p2 data intact
        assert registry.get_project("p2") is not None
        assert registry.get_branch("p2", "main") is not None
        assert registry.get_job(j2) is not None
        # p1 data gone
        assert registry.get_project("p1") is None
        assert registry.get_job(j1) is None

    def test_list_branches_returns_empty_after_all_branches_deleted(self, registry):
        _make_project(registry)
        registry.register_branch("proj-1", "main", "/idx")
        registry.delete_branch("proj-1", "main")
        assert registry.list_branches("proj-1") == []

    def test_registry_persists_across_reconnect(self):
        """Data written to the SQLite file survives a close/reopen cycle."""
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "registry.db"
            reg1 = ServerRegistry(db_path)
            reg1.create_project("proj-1", "MyProject", "/repos/myproject")
            reg1.close()

            reg2 = ServerRegistry(db_path)
            try:
                assert reg2.get_project("proj-1") is not None
                assert reg2.count_projects() == 1
            finally:
                reg2.close()

    def test_db_file_created_on_init(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "sub" / "dir" / "registry.db"
            reg = ServerRegistry(db_path)
            reg.close()
            assert db_path.exists()
